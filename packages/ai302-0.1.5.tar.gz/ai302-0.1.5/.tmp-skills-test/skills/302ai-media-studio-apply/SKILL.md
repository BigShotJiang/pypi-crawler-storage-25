---
name: 302ai-media-studio-apply
description: Use when the user wants to execute a 302AI media generation task. ALWAYS triggers after 302ai-media-studio-propose skill completes, or when user provides a task ID (timestamp) or says "execute task", "run task", "执行任务", "运行任务". This skill reads the task YAML file, executes the first pending step by calling ai302 CLI commands, and updates the task status based on CLI response.
metadata:
  author: 302.ai
  version: "1.0"
  generatedBy: "1.0.0"
---

# 302AI Media Studio Apply Skill

This skill executes 302AI media generation tasks by reading task YAML files, running CLI commands for pending steps, and updating task status based on results.

## Core Responsibilities

Your job is to:

1. Locate the target task YAML file (by provided ID, latest file, or after propose completes)
2. Find the first step with `status: pending`
3. Execute the corresponding ai302 CLI command with parameters
4. Update the YAML file based on CLI response (pending/failed)
5. Report status to the user in their language

## Task File Location

**Priority order for finding the task YAML:**

1. **Explicit task ID provided**: User provides timestamp like `2026-04-23T15-30-45` → use `302ai-media-studio/tasks/<timestamp>.yaml`
2. **Latest file**: No ID provided → use the most recently modified file in `302ai-media-studio/tasks/` (by mtime)
3. **After propose**: When triggered by propose skill, the task ID is passed implicitly

**Directory:** `302ai-media-studio/tasks/` (relative to project root)

**File naming format:** `YYYY-MM-DDTHH-MM-SS.yaml` (e.g., `2026-04-23T15-30-45.yaml`)

## Execution Scope

**Single step per invocation:** This skill ONLY executes the FIRST step with `status: pending`. It does NOT process multiple steps at once.

## CLI Command Mapping

Map operation types to their async CLI commands:

| Operation | CLI Command          |
| --------- | -------------------- |
| `t2i`     | `ai302 image create` |
| `i2i`     | `ai302 image create` |
| `t2v`     | `ai302 video create` |
| `i2v`     | `ai302 video create` |
| `v2v`     | `ai302 video create` |
| `tts`     | `ai302 tts create`   |

All operations use the async create commands. The `image create` command is async (returns `pending` status), not the sync `generate` command.

## Parameter Construction

### Basic Parameters

Convert YAML parameters to CLI flags:

```yaml
parameters:
  prompt: "a cat"
  model: "flux-kontext-max-t2i"
  width: 1024
  height: 1024
```

Becomes:

```bash
ai302 image create --prompt "a cat" --model "flux-kontext-max-t2i" --width 1024 --height 1024
```

### List Parameters (e.g., multiple images)

For list values like `image: [url1, url2]`, repeat the flag:

```yaml
parameters:
  image: ["https://example.com/img1.jpg", "https://example.com/img2.jpg"]
```

Becomes:

```bash
ai302 video create --image https://example.com/img1.jpg --image https://example.com/img2.jpg
```

### Step Result References `${steps.N.result.field}`

When a parameter references a previous step's result:

```yaml
parameters:
  image: "${steps.1.result.image_url}"
```

**Resolution process:**

1. Find step N in the YAML file
2. Read its `result` field (should be JSON from a previous CLI call)
3. Parse the JSON and extract the specified field (e.g., `image_url`)
4. Substitute into the CLI command

**If result is null:** The previous step hasn't completed yet. Report failure to user, telling them to wait for the previous step to complete (via fetch/poll).

**Example resolution:**

```yaml
# Step 1 result (from CLI fetch)
- step: 1
  result:
    { "status": "completed", "image_url": "https://cdn.example.com/abc123.jpg" }

# Step 2 parameters
- step: 2
  parameters:
    image: "${steps.1.result.image_url}" # Resolves to "https://cdn.example.com/abc123.jpg"
```

### Unsupported Features

- `extra` parameter: Not supported in this version
- For TTS: Do NOT pass `--provider` or `--voice` (CLI uses internal defaults)

## CLI Response Handling

### Success: `status: "pending"`

When the CLI returns `{"status": "pending", "taskid": "...", ...}`:

**Update the YAML via CLI (execute sequentially, NOT in parallel):**

```bash
# Command 1: Set task_id
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --set "workflow.steps[step=N].task_id=<taskid>"

# Command 2: Set status to running
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --set "workflow.steps[step=N].status=running"

# Command 3: Add step to running_steps
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --add "workflow.running_steps=N"

# Command 4: Remove step from pending_steps
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --remove "workflow.pending_steps=N"
```

**Critical:** Execute these commands **sequentially** (one after another). Do NOT run them in parallel. Each command must complete before the next starts.

Where:
- `<timestamp>` is the task file name (e.g., `2026-04-23T15-30-45`)
- `<taskid>` is from the CLI response
- `N` is the step number being executed

**Do NOT write to `step.result`** — that field is populated by a separate fetch skill.

**Reply to user:** Tell them the task is executing, in their language.

Examples:

- Chinese: "任务正在执行中..." / "Step N 已提交，正在处理中..."
- English: "Task is executing..." / "Step N submitted, now processing..."

**End skill execution.**

### Failure: `status: "failed"`

When the CLI returns `{"status": "failed", "error": "...", ...}`:

**Error classification and recovery:**

1. **Parameter error** (e.g., unrecognized flag):
   - Call `ai302 <video|image|tts> create -h` to see supported parameters
   - Attempt to fix the parameters
   - Retry the create command (max 3 retries total)

2. **Model not supported** (error indicates model invalid):
   - Do NOT retry with different model
   - Mark task as failed immediately
   - Tell user to re-propose with a valid model

3. **Other errors** (network, API issues, etc.):
   - Attempt self-repair once
   - If still fails after 1 retry → mark as failed

**Max retries:** 3 total attempts for parameter/auto-recoverable errors. After 3 failures, mark task as failed.

**Final failure handling (after retries exhausted):**

Update the YAML via CLI (execute sequentially, NOT in parallel):

```bash
# Command 1: Set step status to failed
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --set "workflow.steps[step=N].status=failed"

# Command 2: Set workflow status to failed
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --set "workflow.status=failed"

# Command 3: Remove step from running_steps (if present)
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --remove "workflow.running_steps=N"

# Command 4: Remove step from pending_steps
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --remove "workflow.pending_steps=N"

# Command 5: Add step to failed_steps
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --add "workflow.failed_steps=N"
```

**Critical:** Execute these commands **sequentially**. Do NOT run them in parallel.

**Reply to user:** Explain what failed and why, in their language.

Examples:

- Chinese: "任务执行失败：[error message]"
- English: "Task execution failed: [error message]"

**End skill execution.**

---

## YAML Update via CLI

This skill uses `ai302 task edit` for all YAML modifications. Never write YAML files manually.

### Critical: Sequential Execution

**ALWAYS execute commands sequentially, never in parallel.**

The `ai302 task edit` command lacks file locking. If multiple processes or commands execute simultaneously on the same file, the last write will overwrite previous changes, causing data loss.

**Correct pattern:**
```bash
# Execute one at a time, wait for each to complete
ai302 task edit --path "..." --set "field1=value1"
ai302 task edit --path "..." --set "field2=value2"
ai302 task edit --path "..." --add "array_field=item"
```

**Incorrect pattern:**
```bash
# NEVER combine multiple operations in one command
ai302 task edit --path "..." --set "field1=value1" --set "field2=value2" --add "array_field=item"

# NEVER run commands in parallel
ai302 task edit --path "..." --set "field1=value1" &  # Background/parallel execution
ai302 task edit --path "..." --set "field2=value2" &
```

### Path Convention

Always use relative paths from project root:

```bash
--path "302ai-media-studio/tasks/<timestamp>.yaml"
```

Examples:
- `--path "302ai-media-studio/tasks/2026-04-23T15-30-45.yaml"`
- `--path "302ai-media-studio/tasks/${TASK_ID}.yaml"` (if variable available)

### Operators

| Operator | Purpose | Example |
|----------|---------|---------|
| `--set "path=value"` | Set/override a field | `--set "workflow.status=running"` |
| `--add "path=value"` | Add element to array | `--add "workflow.running_steps=1"` |
| `--remove "path=value"` | Remove element from array | `--remove "workflow.pending_steps=1"` |

### Path Syntax for Steps

Use conditional selector to target specific steps:

```bash
# Update step 2's task_id
--set "workflow.steps[step=2].task_id=abc123"

# Update step N's status
--set "workflow.steps[step=${N}].status=running"
```

### Complete Examples

**Mark step as running (after successful CLI submission):**

```bash
# Execute sequentially - each command must complete before next starts
ai302 task edit --path "302ai-media-studio/tasks/2026-04-23T15-30-45.yaml" --set "workflow.steps[step=2].task_id=video-abc123"
ai302 task edit --path "302ai-media-studio/tasks/2026-04-23T15-30-45.yaml" --set "workflow.steps[step=2].status=running"
ai302 task edit --path "302ai-media-studio/tasks/2026-04-23T15-30-45.yaml" --add "workflow.running_steps=2"
ai302 task edit --path "302ai-media-studio/tasks/2026-04-23T15-30-45.yaml" --remove "workflow.pending_steps=2"
```

**Mark step as failed (after retries exhausted):**

```bash
# Execute sequentially
ai302 task edit --path "302ai-media-studio/tasks/2026-04-23T15-30-45.yaml" --set "workflow.steps[step=2].status=failed"
ai302 task edit --path "302ai-media-studio/tasks/2026-04-23T15-30-45.yaml" --set "workflow.status=failed"
ai302 task edit --path "302ai-media-studio/tasks/2026-04-23T15-30-45.yaml" --remove "workflow.running_steps=2"
ai302 task edit --path "302ai-media-studio/tasks/2026-04-23T15-30-45.yaml" --remove "workflow.pending_steps=2"
ai302 task edit --path "302ai-media-studio/tasks/2026-04-23T15-30-45.yaml" --add "workflow.failed_steps=2"
```

## Edge Cases

### Task Already Completed/Failed

If the loaded YAML has `workflow.status: completed` or `workflow.status: failed`:

- Tell user the task has already ended
- Do NOT modify the file
- End skill execution

### No Pending Steps

If all steps are `running` or `completed` (no `pending` steps exist):

- Tell user there are no steps to execute
- Suggest they may need to wait for current steps to complete or check status
- End skill execution

### Result References Not Resolvable

If a parameter uses `${steps.N.result.field}` but step N's `result` is `null`:

- Report failure: "Step N has not completed yet. Please wait for it to finish before executing this step."
- Do NOT execute the CLI command
- End skill execution

If the field doesn't exist in the result JSON:

- Report failure: "Field 'field' not found in step N's result. Available fields: [list keys from result]"
- End skill execution

## Language Detection

Detect user language from the conversation context:

- Chinese input → Chinese response
- English input → English response
- Mixed/uncertain → Match the language of the propose step or default to English

## CLI Command Examples

```bash
# Text to Image
ai302 image create --prompt "a cat" --model "flux-kontext-max-t2i"

# Image to Video with single image
ai302 video create --image "https://example.com/cat.jpg" --prompt "animate this"

# Image to Video with multiple images
ai302 video create --image "https://example.com/img1.jpg" --image "https://example.com/img2.jpg" --duration 5

# Text to Speech
ai302 tts create --text "Hello world"

# Video to Video
ai302 video create --video "https://example.com/source.mp4" --prompt "enhance quality"
```

## Workflow

1. **Locate task file** by ID or latest mtime
2. **Check workflow status** — if completed/failed, inform user and exit
3. **Find first pending step** — if none, inform user and exit
4. **Resolve parameters** — expand any `${steps.N.result.field}` references
5. **Build CLI command** based on operation type
6. **Execute CLI command**
7. **Parse response**:
   - `pending` → update YAML to `running`, add `task_id`, inform user
   - `failed` → attempt recovery/retry, or mark as failed
8. **Update YAML** via `ai302 task edit` CLI command
9. **Report to user** in their language

## Important Reminders

- Use `ai302 task edit --path` for all YAML updates (never write manually)
- **CRITICAL: Execute CLI commands sequentially, never in parallel** - no file locking means parallel writes cause data loss
- One operation per command (e.g., one `--set`, one `--add`, or one `--remove` per invocation)
- Path is relative to project root: `302ai-media-studio/tasks/<timestamp>.yaml`
- Async only: use `create` commands, not `generate`
- One step per invocation
- Don't touch `step.result` — that's for the fetch skill
- Retry up to 3 times for recoverable errors
- Model not supported → immediate failure, no retry
- Follow user's language for responses
