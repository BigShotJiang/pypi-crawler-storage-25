from ai302.cli.app import app


if __name__ == "__main__":
    app()
