"""Tests for researchloop.db.queries."""

import json

from researchloop.db import queries


class TestStudyQueries:
    async def test_create_and_get(self, db):
        study = await queries.create_study(
            db,
            name="my-study",
            cluster="hpc",
            description="A study",
            claude_md_path="/path/CLAUDE.md",
            sprints_dir="./sprints",
        )
        assert study["name"] == "my-study"
        assert study["cluster"] == "hpc"
        assert study["description"] == "A study"

        fetched = await queries.get_study(db, "my-study")
        assert fetched is not None
        assert fetched["name"] == "my-study"

    async def test_get_nonexistent(self, db):
        assert await queries.get_study(db, "nope") is None

    async def test_list_studies(self, db):
        await queries.create_study(db, "s1", "c1", None, None, "./sp1")
        await queries.create_study(db, "s2", "c2", None, None, "./sp2")
        studies = await queries.list_studies(db)
        assert len(studies) == 2

    async def test_update_study(self, db):
        await queries.create_study(db, "s1", "c1", "old desc", None, "./sp")
        updated = await queries.update_study(db, "s1", description="new desc")
        assert updated["description"] == "new desc"

    async def test_update_no_kwargs(self, db):
        await queries.create_study(db, "s1", "c1", None, None, "./sp")
        result = await queries.update_study(db, "s1")
        assert result["name"] == "s1"


class TestSprintQueries:
    async def test_create_and_get(self, db_with_study):
        sprint = await queries.create_sprint(
            db_with_study,
            id="sp-abc123",
            study_name="test-study",
            idea="test idea",
            directory="/tmp/sprint",
        )
        assert sprint["id"] == "sp-abc123"
        assert sprint["status"] == "pending"
        assert sprint["idea"] == "test idea"

    async def test_list_sprints(self, db_with_study):
        await queries.create_sprint(db_with_study, "sp-001", "test-study", "idea 1")
        await queries.create_sprint(db_with_study, "sp-002", "test-study", "idea 2")
        sprints = await queries.list_sprints(db_with_study)
        assert len(sprints) == 2

    async def test_list_sprints_filter_by_study(self, db_with_study):
        await queries.create_sprint(db_with_study, "sp-001", "test-study", "idea 1")
        sprints = await queries.list_sprints(db_with_study, study_name="test-study")
        assert len(sprints) == 1
        sprints = await queries.list_sprints(db_with_study, study_name="other")
        assert len(sprints) == 0

    async def test_list_sprints_filter_by_status(self, db_with_study):
        await queries.create_sprint(db_with_study, "sp-001", "test-study", "idea 1")
        await queries.update_sprint(db_with_study, "sp-001", status="running")
        sprints = await queries.list_sprints(db_with_study, status="running")
        assert len(sprints) == 1
        sprints = await queries.list_sprints(db_with_study, status="completed")
        assert len(sprints) == 0

    async def test_list_sprints_limit(self, db_with_study):
        for i in range(5):
            await queries.create_sprint(
                db_with_study, f"sp-{i:03d}", "test-study", f"idea {i}"
            )
        sprints = await queries.list_sprints(db_with_study, limit=3)
        assert len(sprints) == 3

    async def test_update_sprint(self, db_with_study):
        await queries.create_sprint(db_with_study, "sp-001", "test-study", "idea")
        updated = await queries.update_sprint(
            db_with_study,
            "sp-001",
            status="running",
            job_id="12345",
        )
        assert updated["status"] == "running"
        assert updated["job_id"] == "12345"

    async def test_get_active_sprints(self, db_with_study):
        await queries.create_sprint(db_with_study, "sp-001", "test-study", "idea 1")
        await queries.create_sprint(db_with_study, "sp-002", "test-study", "idea 2")
        await queries.update_sprint(db_with_study, "sp-001", status="running")
        active = await queries.get_active_sprints(db_with_study)
        assert len(active) == 1
        assert active[0]["id"] == "sp-001"


class TestDeleteSprint:
    async def test_delete_removes_sprint(self, db_with_study):
        await queries.create_sprint(db_with_study, "sp-del", "test-study", "idea")
        await queries.delete_sprint(db_with_study, "sp-del")
        assert await queries.get_sprint(db_with_study, "sp-del") is None

    async def test_delete_removes_related_artifacts_and_events(self, db_with_study):
        await queries.create_sprint(db_with_study, "sp-del", "test-study", "idea")
        await queries.create_artifact(db_with_study, "sp-del", "f.pdf", "/f.pdf")
        await queries.create_event(db_with_study, "sp-del", "test_event")
        await queries.delete_sprint(db_with_study, "sp-del")
        assert await queries.list_artifacts(db_with_study, "sp-del") == []
        assert await queries.list_events(db_with_study, sprint_id="sp-del") == []

    async def test_delete_removes_related_slack_sessions(self, db_with_study):
        """Ensure delete_sprint cleans up slack_sessions FK references."""
        await queries.create_sprint(db_with_study, "sp-del", "test-study", "idea")
        # Insert a slack_session referencing this sprint.
        await db_with_study.execute(
            "INSERT INTO slack_sessions (thread_ts, sprint_id, study_name) "
            "VALUES (?, ?, ?)",
            ("1234.5678", "sp-del", "test-study"),
        )
        # Verify it exists.
        row = await db_with_study.fetch_one(
            "SELECT * FROM slack_sessions WHERE sprint_id = ?", ("sp-del",)
        )
        assert row is not None

        await queries.delete_sprint(db_with_study, "sp-del")

        # Sprint and session should both be gone.
        assert await queries.get_sprint(db_with_study, "sp-del") is None
        row = await db_with_study.fetch_one(
            "SELECT * FROM slack_sessions WHERE sprint_id = ?", ("sp-del",)
        )
        assert row is None


class TestAutoLoopQueries:
    async def test_create_and_get(self, db_with_study):
        loop = await queries.create_auto_loop(
            db_with_study,
            id="loop-abc",
            study_name="test-study",
            total_count=5,
        )
        assert loop["id"] == "loop-abc"
        assert loop["total_count"] == 5
        assert loop["completed_count"] == 0
        assert loop["status"] == "running"

    async def test_update_auto_loop(self, db_with_study):
        await queries.create_auto_loop(db_with_study, "loop-1", "test-study", 3)
        updated = await queries.update_auto_loop(
            db_with_study,
            "loop-1",
            completed_count=1,
            current_sprint_id="sp-001",
        )
        assert updated["completed_count"] == 1
        assert updated["current_sprint_id"] == "sp-001"

    async def test_list_auto_loops(self, db_with_study):
        await queries.create_auto_loop(db_with_study, "loop-1", "test-study", 3)
        await queries.create_auto_loop(db_with_study, "loop-2", "test-study", 5)
        loops = await queries.list_auto_loops(db_with_study)
        assert len(loops) == 2

    async def test_list_auto_loops_filter(self, db_with_study):
        await queries.create_auto_loop(db_with_study, "loop-1", "test-study", 3)
        loops = await queries.list_auto_loops(db_with_study, study_name="test-study")
        assert len(loops) == 1
        loops = await queries.list_auto_loops(db_with_study, study_name="other")
        assert len(loops) == 0


class TestArtifactQueries:
    async def test_create_and_list(self, db_with_study):
        await queries.create_sprint(db_with_study, "sp-001", "test-study", "idea")
        art = await queries.create_artifact(
            db_with_study,
            sprint_id="sp-001",
            filename="report.md",
            path="/tmp/report.md",
            size=1024,
            content_type="text/markdown",
        )
        assert art["filename"] == "report.md"
        assert art["size"] == 1024

        arts = await queries.list_artifacts(db_with_study, "sp-001")
        assert len(arts) == 1

    async def test_get_artifact(self, db_with_study):
        await queries.create_sprint(db_with_study, "sp-001", "test-study", "idea")
        art = await queries.create_artifact(
            db_with_study,
            "sp-001",
            "file.pdf",
            "/tmp/file.pdf",
            2048,
        )
        fetched = await queries.get_artifact(db_with_study, art["id"])
        assert fetched is not None
        assert fetched["filename"] == "file.pdf"


class TestEventQueries:
    async def test_create_and_list(self, db_with_study):
        await queries.create_sprint(db_with_study, "sp-001", "test-study", "idea")
        evt = await queries.create_event(
            db_with_study,
            sprint_id="sp-001",
            event_type="status_change",
            data_json=json.dumps({"from": "pending", "to": "running"}),
        )
        assert evt["event_type"] == "status_change"

        events = await queries.list_events(db_with_study, sprint_id="sp-001")
        assert len(events) == 1

    async def test_list_events_limit(self, db_with_study):
        await queries.create_sprint(db_with_study, "sp-001", "test-study", "idea")
        for i in range(5):
            await queries.create_event(db_with_study, "sp-001", f"evt_{i}")
        events = await queries.list_events(db_with_study, limit=3)
        assert len(events) == 3

    async def test_list_all_events(self, db_with_study):
        await queries.create_sprint(db_with_study, "sp-001", "test-study", "idea")
        await queries.create_event(db_with_study, "sp-001", "evt_1")
        await queries.create_event(db_with_study, None, "system_evt")
        events = await queries.list_events(db_with_study)
        assert len(events) == 2
