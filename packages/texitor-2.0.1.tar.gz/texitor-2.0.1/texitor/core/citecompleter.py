# bib citation completer
# scans a directory for .bib files, parses them, provides key completions
# also accepts extra paths from config bib_files list

from pathlib import Path
import texitor.core.bibparser as _bib


def _first_author_last(author_str):
    first = author_str.split(" and ")[0].strip()
    if "," in first:
        return first.split(",")[0].strip()
    parts = first.rsplit(" ", 1)
    return parts[-1] if len(parts) > 1 else first


def _entry_desc(e):
    parts = []
    if e["author"]:
        parts.append(_first_author_last(e["author"]))
    if e["year"]:
        parts.append(e["year"])
    if e["title"]:
        t = e["title"]
        parts.append(t[:45] + "…" if len(t) > 45 else t)
    return "  ".join(parts) if parts else e["key"]


class CiteCompleter:

    def __init__(self):
        self._entries = []

    def loadDir(self, dir_path, extra_paths=None):
        self._entries = []
        seen = set()
        dirs_to_scan = [Path(dir_path)]

        for bib_path in (extra_paths or []):
            p = Path(bib_path).expanduser()
            if p.is_file():
                if p not in seen:
                    seen.add(p)
                    self._entries.extend(_bib.parse(p))
            elif p.is_dir():
                dirs_to_scan.append(p)

        for d in dirs_to_scan:
            for bib_file in sorted(d.glob("*.bib")):
                if bib_file not in seen:
                    seen.add(bib_file)
                    self._entries.extend(_bib.parse(bib_file))

    def getCompletions(self, prefix):
        pl = prefix.lower()
        exact, starts, contains = [], [], []
        for e in self._entries:
            kl = e["key"].lower()
            desc = _entry_desc(e)
            if kl == pl:
                exact.append((e["key"], desc))
            elif kl.startswith(pl):
                starts.append((e["key"], desc))
            elif pl and pl in kl:
                contains.append((e["key"], desc))
        return exact + starts + contains

    def isEmpty(self):
        return not self._entries

    def entryCount(self):
        return len(self._entries)
