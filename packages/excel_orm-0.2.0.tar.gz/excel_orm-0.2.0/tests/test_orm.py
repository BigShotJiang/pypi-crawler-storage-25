from __future__ import annotations

from datetime import date, datetime

import pytest
from openpyxl import load_workbook

from excel_orm import (
    Column,
    ExcelFile,
    PivotSheetSpec,
    RowBase,
    date_column,
    int_column,
    text_column,
)
from excel_orm.orm import SheetSpec


def test_generate_template_creates_sheet_and_titles_and_headers(tmp_path, excel_file):
    out = tmp_path / "template.xlsx"
    excel_file.generate_template(str(out))

    wb = load_workbook(out)
    assert "Cars" in wb.sheetnames
    ws = wb["Cars"]

    # Cars block: title row merged across A..C, title value "Cars"
    assert ws["A1"].value == "Cars"
    merged = [str(rng) for rng in ws.merged_cells.ranges]
    assert "A1:C1" in merged

    # Cars headers on row 2
    assert ws["A2"].value == "Make"
    assert ws["B2"].value == "Model"
    assert ws["C2"].value == "Year"

    # ManufacturingPlant block starts after 2-col gap: Cars ends at C, so start at F
    assert ws["F1"].value == "Manufacturing Plants"
    assert "F1:G1" in merged
    assert ws["F2"].value == "Factory Name"
    assert ws["G2"].value == "Location"


def test_load_data_end_to_end(tmp_path, excel_file):
    """
    Create a workbook that matches the template layout, fill a few rows,
    load it, and verify repositories.
    """
    out = tmp_path / "data.xlsx"
    excel_file.generate_template(str(out))

    # Fill data
    from openpyxl import load_workbook

    wb = load_workbook(out)
    ws = wb["Cars"]

    # Cars data at row 3+
    ws["A3"].value = "Toyota"
    ws["B3"].value = "Camry"
    ws["C3"].value = 2020

    ws["A4"].value = "Honda"
    ws["B4"].value = "Civic"
    ws["C4"].value = "2019"  # string should parse to int

    # Plants data at row 3+ (F,G)
    ws["F3"].value = "Plant 1"
    ws["G3"].value = "NJ"

    ws["F4"].value = "Plant 2"
    ws["G4"].value = "PA"

    wb.save(out)

    # Load
    excel_file.load_data(str(out))

    cars = excel_file.cars.all()
    plants = excel_file.manufacturing_plants.all()

    assert len(cars) == 2
    assert cars[0].make == "Toyota"
    assert cars[0].model == "Camry"
    assert cars[0].year == 2020
    assert cars[1].year == 2019

    assert len(plants) == 2
    assert plants[0].name == "Plant 1"
    assert plants[0].location == "NJ"


def test_load_data_missing_sheet_raises(tmp_path, excel_file):
    # Create a workbook with a different sheet name
    from openpyxl import Workbook

    p = tmp_path / "wrong.xlsx"
    wb = Workbook()
    wb.active.title = "NotCars"
    wb.save(p)

    with pytest.raises(ValueError):
        excel_file.load_data(str(p))


def _as_date(x) -> date:
    """openpyxl may return date or datetime depending on formatting; normalize."""
    if isinstance(x, datetime):
        return x.date()
    if isinstance(x, date):
        return x
    raise TypeError(f"Expected date/datetime, got {type(x)}: {x!r}")


def test_generate_template_pivot_sheet_layout(tmp_path, pivot_excel_file, demand_model):
    out = tmp_path / "pivot_template.xlsx"
    pivot_excel_file.generate_template(str(out))

    wb = load_workbook(out)
    assert "Demand" in wb.sheetnames
    ws = wb["Demand"]

    # Title merged across A..D (A for row header + 3 pivot columns -> B,C,D)
    assert ws["A1"].value == "Demands"
    merged = [str(rng) for rng in ws.merged_cells.ranges]
    assert "A1:D1" in merged

    # Corner header for row keys (Region)
    assert ws["A2"].value in {"Region"}  # explicit

    # Pivot headers across B2..D2
    assert _as_date(ws["B2"].value) == date(2025, 6, 1)
    assert _as_date(ws["C2"].value) == date(2025, 7, 1)
    assert _as_date(ws["D2"].value) == date(2025, 8, 1)

    # Seeded row values appear in A3, A4
    assert ws["A3"].value == "NA"
    assert ws["A4"].value == "EU"


def test_load_data_pivot_end_to_end_skips_blank_cells(tmp_path, pivot_excel_file):
    """
    Fill a demand pivot matrix:
      rows: NA, EU
      cols: Jun, Jul, Aug
    Leave one cell blank and verify it is not emitted (include_blanks=False).
    """
    out = tmp_path / "pivot_data.xlsx"
    pivot_excel_file.generate_template(str(out))

    wb = load_workbook(out)
    ws = wb["Demand"]

    # NA row at row 3
    ws["B3"].value = 10  # NA, Jun
    ws["C3"].value = 20  # NA, Jul
    ws["D3"].value = None  # NA, Aug (blank -> should skip)

    # EU row at row 4
    ws["B4"].value = 5  # EU, Jun
    ws["C4"].value = 0  # EU, Jul (explicit 0 should be included)
    ws["D4"].value = 15  # EU, Aug

    wb.save(out)

    pivot_excel_file.load_data(str(out))

    # Repo name is plural snake_case of Demand -> demands
    rows = pivot_excel_file.demands.all()
    assert len(rows) == 5  # 6 cells minus 1 blank = 5

    # Compare as a set of tuples to avoid ordering assumptions
    got = {(r.region, r.dt, r.value) for r in rows}
    expected = {
        ("NA", date(2025, 6, 1), 10),
        ("NA", date(2025, 7, 1), 20),
        # ("NA", date(2025, 8, 1), ?) skipped
        ("EU", date(2025, 6, 1), 5),
        ("EU", date(2025, 7, 1), 0),
        ("EU", date(2025, 8, 1), 15),
    }
    assert got == expected


def test_load_data_pivot_stops_at_blank_region_row(tmp_path, demand_model):
    """
    If the region cell is blank, parsing should stop (contiguous-block rule for row labels).
    """
    pivot_values = [date(2025, 6, 1), date(2025, 7, 1)]
    spec = PivotSheetSpec(
        name="Demand",
        model=demand_model,
        pivot_field="dt",
        row_fields=["region"],
        value_field="value",
        pivot_values=pivot_values,
        row_values=None,  # user-entered regions
    )
    xf = ExcelFile(sheets=[spec])

    out = tmp_path / "stop_rule.xlsx"
    xf.generate_template(str(out))

    wb = load_workbook(out)
    ws = wb["Demand"]

    # Row 3 has region, row 4 is blank region -> stop; row 5 should not be read
    ws["A3"].value = "NA"
    ws["B3"].value = 1
    ws["C3"].value = 2

    ws["A4"].value = ""  # stop condition

    ws["A5"].value = "EU"
    ws["B5"].value = 9
    ws["C5"].value = 9

    wb.save(out)

    xf.load_data(str(out))
    rows = xf.demands.all()  # ty:ignore[unresolved-attribute]

    got = {(r.region, r.dt, r.value) for r in rows}
    assert got == {
        ("NA", date(2025, 6, 1), 1),
        ("NA", date(2025, 7, 1), 2),
    }


def test_load_data_missing_pivot_sheet_raises(tmp_path, pivot_excel_file):
    # Create a workbook with a different sheet name
    from openpyxl import Workbook

    p = tmp_path / "wrong.xlsx"
    wb = Workbook()
    wb.active.title = "NotDemand"
    wb.save(p)

    with pytest.raises(ValueError):
        pivot_excel_file.load_data(str(p))


def test_pivot_two_row_fields_template_and_parse_end_to_end(tmp_path, demand_two_pivot):
    """
    Two row_fields case:
      row_fields: [region, product]
      pivot cols: Jun, Jul
      row_values seeded with composite keys (NA/ABC, EU/ABC)
    Validate:
      - template layout places row headers in A2,B2
      - pivot headers start at C2,D2
      - seeded keys appear in A3,B3 and A4,B4
      - parsing emits correct objects with BOTH row fields populated
    """
    pivot_values = [date(2025, 6, 1), date(2025, 7, 1)]
    spec = PivotSheetSpec(
        name="Demand",
        model=demand_two_pivot,
        pivot_field="dt",
        row_fields=["region", "product"],
        value_field="value",
        pivot_values=pivot_values,
        row_values=[("NA", "ABC"), ("EU", "ABC")],
        row_header_col=1,
        include_blanks=False,
    )
    xf = ExcelFile(sheets=[spec])

    out = tmp_path / "pivot_two_row_fields.xlsx"
    xf.generate_template(str(out))

    wb = load_workbook(out)
    ws = wb["Demand"]

    # Title merged across A..D (A,B row headers + C,D pivot headers)
    assert ws["A1"].value == "Demands"
    merged = [str(rng) for rng in ws.merged_cells.ranges]
    assert "A1:D1" in merged

    # Row field headers in A2,B2
    assert ws["A2"].value == "Region"
    assert ws["B2"].value == "Product"

    # Pivot headers start at C2..D2
    assert _as_date(ws["C2"].value) == date(2025, 6, 1)
    assert _as_date(ws["D2"].value) == date(2025, 7, 1)

    # Seeded composite keys appear across A/B
    assert ws["A3"].value == "NA"
    assert ws["B3"].value == "ABC"
    assert ws["A4"].value == "EU"
    assert ws["B4"].value == "ABC"

    # Fill matrix values: (row 3: NA/ABC), (row 4: EU/ABC)
    ws["C3"].value = 10  # NA/ABC, Jun
    ws["D3"].value = 20  # NA/ABC, Jul
    ws["C4"].value = 5  # EU/ABC, Jun
    ws["D4"].value = 0  # EU/ABC, Jul

    wb.save(out)

    xf.load_data(str(out))
    rows = xf.demands.all()  # repo name plural of Demand

    # Expect 4 objects (2 rows x 2 pivots)
    assert len(rows) == 4

    got = {(r.region, r.product, r.dt, r.value) for r in rows}
    expected = {
        ("NA", "ABC", date(2025, 6, 1), 10),
        ("NA", "ABC", date(2025, 7, 1), 20),
        ("EU", "ABC", date(2025, 6, 1), 5),
        ("EU", "ABC", date(2025, 7, 1), 0),
    }
    assert got == expected


def test_duplicate_header_names_do_not_clash(tmp_path, models):
    Car, _ = models

    class ManufacturingPlant(RowBase):
        name: Column[str] = text_column(header="Make", not_null=True)
        location: Column[str] = text_column(header="location")

    sheet = SheetSpec(name="Cars", models=[Car, ManufacturingPlant])
    file = ExcelFile(sheets=[sheet])
    out = tmp_path / "duplicate_headers.xlsx"
    file.generate_template(out)

    wb = load_workbook(out)
    ws = wb["Cars"]

    ws["A3"].value = "Acura"
    ws["B3"].value = "TSX"
    ws["C3"].value = 2005

    ws["F3"].value = "Duplicate"
    ws["G3"].value = "New Jersey"

    wb.save(out)

    file.load_data(out)

    cars = file.cars.all()
    plants = file.manufacturing_plants.all()

    assert plants[0].name == "Duplicate"
    assert plants[0].location == "New Jersey"


def test_write_manufacturing_plant(tmp_path):
    class ManufacturingPlant(RowBase):
        name: Column[str] = text_column(header="Make", not_null=True)
        location: Column[str] = text_column(header="location")

    sheet = SheetSpec(name="Plants", models=[ManufacturingPlant])
    file = ExcelFile(sheets=[sheet])

    name_location = [("Plant 1", "NJ"), ("Plant 2", "PA")]
    plants = [ManufacturingPlant(name=name, location=loc) for name, loc in name_location]

    file.add_data(plants)
    file.generate_template(tmp_path / "write_plants.xlsx")
    wb = load_workbook(tmp_path / "write_plants.xlsx")
    ws = wb["Plants"]

    assert ws["A3"].value == "Plant 1"
    assert ws["B3"].value == "NJ"
    assert ws["A4"].value == "Plant 2"
    assert ws["B4"].value == "PA"


# ============================================================
# Two-way binding (write) tests
# ============================================================


def test_add_data_raises_for_unregistered_model():
    """add_data() raises ValueError when the object's type is not registered."""

    class Plant(RowBase):
        name: Column[str] = text_column(header="Name")

    class Unrelated(RowBase):
        foo: Column[str] = text_column(header="Foo")

    sheet = SheetSpec(name="Plants", models=[Plant])
    file = ExcelFile(sheets=[sheet])

    with pytest.raises(ValueError, match="Unrelated"):
        file.add_data([Unrelated(foo="bar")])


def test_write_data_multi_model_same_sheet(tmp_path, models):
    """Both models in a multi-model sheet write to their correct column blocks."""
    Car, ManufacturingPlant = models
    sheet = SheetSpec(name="Cars", models=[Car, ManufacturingPlant])
    file = ExcelFile(sheets=[sheet])

    file.add_data(
        [
            Car(make="Toyota", model="Camry", year=2020),
            Car(make="Honda", model="Civic", year=2019),
        ]
    )
    file.add_data(
        [
            ManufacturingPlant(name="Plant 1", location="NJ"),
        ]
    )

    out = tmp_path / "multi_model.xlsx"
    file.generate_template(str(out))

    wb = load_workbook(out)
    ws = wb["Cars"]

    # Cars block: A-C starting at row 3
    assert ws["A3"].value == "Toyota"
    assert ws["B3"].value == "Camry"
    assert ws["C3"].value == 2020
    assert ws["A4"].value == "Honda"
    assert ws["B4"].value == "Civic"
    assert ws["C4"].value == 2019

    # ManufacturingPlant block: F-G (A-C = Cars, D-E = gap)
    assert ws["F3"].value == "Plant 1"
    assert ws["G3"].value == "NJ"
    # Only one plant — row 4 in the plant block is empty
    assert ws["F4"].value is None


def test_write_data_partial_repos(tmp_path, models):
    """When one repo is empty, its data rows stay blank; headers are still present."""
    Car, ManufacturingPlant = models
    sheet = SheetSpec(name="Cars", models=[Car, ManufacturingPlant])
    file = ExcelFile(sheets=[sheet])

    file.add_data([Car(make="Toyota", model="Camry", year=2020)])
    # No plants added

    out = tmp_path / "partial.xlsx"
    file.generate_template(str(out))

    wb = load_workbook(out)
    ws = wb["Cars"]

    # Car data is present
    assert ws["A3"].value == "Toyota"

    # Plant block headers are still written
    assert ws["F2"].value == "Factory Name"
    assert ws["G2"].value == "Location"

    # Plant data rows are absent
    assert ws["F3"].value is None
    assert ws["G3"].value is None


def test_write_data_round_trip(tmp_path, models):
    """Data written via add_data + generate_template round-trips through load_data."""
    Car, ManufacturingPlant = models
    sheet = SheetSpec(name="Cars", models=[Car, ManufacturingPlant])

    file = ExcelFile(sheets=[sheet])
    file.add_data(
        [
            Car(make="Toyota", model="Camry", year=2020),
            Car(make="Honda", model="Civic", year=2019),
        ]
    )
    file.add_data(
        [
            ManufacturingPlant(name="Plant A", location="NJ"),
            ManufacturingPlant(name="Plant B", location="CA"),
        ]
    )

    out = tmp_path / "round_trip.xlsx"
    file.generate_template(str(out))

    file2 = ExcelFile(sheets=[sheet])
    file2.load_data(str(out))

    cars = file2.cars.all()
    plants = file2.manufacturing_plants.all()

    assert len(cars) == 2
    assert cars[0].make == "Toyota"
    assert cars[0].model == "Camry"
    assert cars[0].year == 2020
    assert cars[1].make == "Honda"
    assert cars[1].year == 2019

    assert len(plants) == 2
    assert plants[0].name == "Plant A"
    assert plants[0].location == "NJ"
    assert plants[1].name == "Plant B"
    assert plants[1].location == "CA"


def test_write_data_direct_repo_append(tmp_path):
    """Appending directly to a repo attribute is reflected in generate_template."""

    class Plant(RowBase):
        name: Column[str] = text_column(header="Name")
        location: Column[str] = text_column(header="Location")

    sheet = SheetSpec(name="Plants", models=[Plant])
    file = ExcelFile(sheets=[sheet])

    file.plants.append(Plant(name="Direct Plant", location="TX"))  # type: ignore[attr-defined]

    out = tmp_path / "direct_append.xlsx"
    file.generate_template(str(out))

    wb = load_workbook(out)
    ws = wb["Plants"]
    assert ws["A3"].value == "Direct Plant"
    assert ws["B3"].value == "TX"


def test_write_data_text_renderer_none_becomes_empty_cell(tmp_path):
    """text_column renders None as '', which openpyxl stores as a blank cell (reads back as None)."""

    class Item(RowBase):
        name: Column[str] = text_column(header="Name", not_null=False)
        note: Column[str] = text_column(header="Note")

    sheet = SheetSpec(name="Items", models=[Item])
    file = ExcelFile(sheets=[sheet])
    file.add_data([Item(name="Widget", note=None)])

    out = tmp_path / "null_renderer.xlsx"
    file.generate_template(str(out))

    wb = load_workbook(out)
    ws = wb["Items"]
    assert ws["A3"].value == "Widget"
    # text_column renderer returns "" for None; openpyxl stores/reads that as None (blank cell)
    assert ws["B3"].value is None


def test_write_pivot_data_single_row_field(tmp_path):
    """Pivot sheet with a single row_field writes row keys and matrix values correctly."""

    class Demand(RowBase):
        region: Column[str] = text_column(header="Region", not_null=True)
        dt: Column[date] = date_column(header="Date")
        value: Column[int] = int_column(header="Value")

    spec = PivotSheetSpec(
        name="Demand",
        model=Demand,
        pivot_field="dt",
        row_fields=["region"],
        value_field="value",
        pivot_values=[date(2025, 6, 1), date(2025, 7, 1)],
    )
    file = ExcelFile(sheets=[spec])
    file.add_data(
        [
            Demand(region="NA", dt=date(2025, 6, 1), value=10),
            Demand(region="NA", dt=date(2025, 7, 1), value=20),
            Demand(region="EU", dt=date(2025, 6, 1), value=5),
            Demand(region="EU", dt=date(2025, 7, 1), value=15),
        ]
    )

    out = tmp_path / "pivot_write.xlsx"
    file.generate_template(str(out))

    wb = load_workbook(out)
    ws = wb["Demand"]

    assert ws["A3"].value == "NA"
    assert ws["A4"].value == "EU"
    assert ws["B3"].value == 10  # NA, Jun
    assert ws["C3"].value == 20  # NA, Jul
    assert ws["B4"].value == 5  # EU, Jun
    assert ws["C4"].value == 15  # EU, Jul


def test_write_pivot_data_infers_pivot_values_from_repo(tmp_path):
    """When pivot_values is None, effective columns are inferred from repo insertion order."""

    class Demand(RowBase):
        region: Column[str] = text_column(header="Region", not_null=True)
        dt: Column[date] = date_column(header="Date")
        value: Column[int] = int_column(header="Value")

    spec = PivotSheetSpec(
        name="Demand",
        model=Demand,
        pivot_field="dt",
        row_fields=["region"],
        value_field="value",
        pivot_values=None,
    )
    file = ExcelFile(sheets=[spec])
    file.add_data(
        [
            Demand(region="NA", dt=date(2025, 6, 1), value=10),
            Demand(region="NA", dt=date(2025, 7, 1), value=20),
            Demand(region="EU", dt=date(2025, 6, 1), value=5),
            # EU has no Jul entry
        ]
    )

    out = tmp_path / "pivot_inferred.xlsx"
    file.generate_template(str(out))

    wb = load_workbook(out)
    ws = wb["Demand"]

    # Pivot headers inferred in insertion order: Jun then Jul
    assert _as_date(ws["B2"].value) == date(2025, 6, 1)
    assert _as_date(ws["C2"].value) == date(2025, 7, 1)

    assert ws["A3"].value == "NA"
    assert ws["A4"].value == "EU"
    assert ws["B3"].value == 10  # NA, Jun
    assert ws["C3"].value == 20  # NA, Jul
    assert ws["B4"].value == 5  # EU, Jun
    assert ws["C4"].value is None  # EU has no Jul — missing entry writes None


def test_write_pivot_no_pivot_values_empty_repo_raises(tmp_path):
    """Raises ValueError when pivot_values is None and the repo is empty."""

    class Demand(RowBase):
        region: Column[str] = text_column(header="Region")
        dt: Column[date] = date_column(header="Date")
        value: Column[int] = int_column(header="Value")

    spec = PivotSheetSpec(
        name="Demand",
        model=Demand,
        pivot_field="dt",
        row_fields=["region"],
        value_field="value",
        pivot_values=None,
    )
    file = ExcelFile(sheets=[spec])

    with pytest.raises(ValueError):
        file.generate_template(str(tmp_path / "should_fail.xlsx"))


def test_write_pivot_data_round_trip(tmp_path):
    """Pivot data written via add_data + generate_template round-trips through load_data."""

    class Demand(RowBase):
        region: Column[str] = text_column(header="Region", not_null=True)
        dt: Column[date] = date_column(header="Date")
        value: Column[int] = int_column(header="Value")

    spec = PivotSheetSpec(
        name="Demand",
        model=Demand,
        pivot_field="dt",
        row_fields=["region"],
        value_field="value",
        pivot_values=[date(2025, 6, 1), date(2025, 7, 1)],
        include_blanks=False,
    )
    data_in = [
        Demand(region="NA", dt=date(2025, 6, 1), value=10),
        Demand(region="NA", dt=date(2025, 7, 1), value=20),
        Demand(region="EU", dt=date(2025, 6, 1), value=5),
        Demand(region="EU", dt=date(2025, 7, 1), value=0),
    ]

    file = ExcelFile(sheets=[spec])
    file.add_data(data_in)
    out = tmp_path / "pivot_round_trip.xlsx"
    file.generate_template(str(out))

    file2 = ExcelFile(sheets=[spec])
    file2.load_data(str(out))

    got = {(r.region, r.dt, r.value) for r in file2.demands.all()}
    assert got == {
        ("NA", date(2025, 6, 1), 10),
        ("NA", date(2025, 7, 1), 20),
        ("EU", date(2025, 6, 1), 5),
        ("EU", date(2025, 7, 1), 0),
    }


def test_write_pivot_data_two_row_fields(tmp_path, demand_two_pivot):
    """Pivot sheet with two row_fields writes row keys and matrix values correctly."""
    Demand = demand_two_pivot
    spec = PivotSheetSpec(
        name="Demand",
        model=Demand,
        pivot_field="dt",
        row_fields=["region", "product"],
        value_field="value",
        pivot_values=[date(2025, 6, 1), date(2025, 7, 1)],
        include_blanks=False,
    )
    file = ExcelFile(sheets=[spec])
    file.add_data(
        [
            Demand(region="NA", product="ABC", dt=date(2025, 6, 1), value=100),
            Demand(region="NA", product="ABC", dt=date(2025, 7, 1), value=200),
            Demand(region="EU", product="XYZ", dt=date(2025, 6, 1), value=50),
            Demand(region="EU", product="XYZ", dt=date(2025, 7, 1), value=75),
        ]
    )

    out = tmp_path / "pivot_two_row.xlsx"
    file.generate_template(str(out))

    wb = load_workbook(out)
    ws = wb["Demand"]

    # Composite row keys across A, B
    assert ws["A3"].value == "NA"
    assert ws["B3"].value == "ABC"
    assert ws["A4"].value == "EU"
    assert ws["B4"].value == "XYZ"

    # Matrix values (pivot headers start at C)
    assert ws["C3"].value == 100  # NA/ABC, Jun
    assert ws["D3"].value == 200  # NA/ABC, Jul
    assert ws["C4"].value == 50  # EU/XYZ, Jun
    assert ws["D4"].value == 75  # EU/XYZ, Jul
