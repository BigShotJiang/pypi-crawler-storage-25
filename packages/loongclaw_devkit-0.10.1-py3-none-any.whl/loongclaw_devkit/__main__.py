"""python -m loongclaw_devkit 入口"""

from loongclaw_devkit.server import main

main()
