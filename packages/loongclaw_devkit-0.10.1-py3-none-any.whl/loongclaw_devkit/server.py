"""LoongClaw DevKit MCP Server (AI-first)

面向 AI 的工具集，帮助开发者用对话式驱动完成 MCP 插件全生命周期：
创建项目 → 诊断 → 更新配置 → 发布 → 下架/重新上架。

设计原则（v0.9.0 起）：
- AI-first：所有工具都能只靠 JSON 参数调用完成，不依赖人工 input() / 终端交互
- 错误结构化：返回 {status, code, error, fix, ...}，AI 看 `code` 字段路由到
  auto-fix，文案仅供人类调试
- Fail-Close：关键字段缺失/非法立即拦截，不走"默认值兜底"
- 自包含：devkit 带一切发布逻辑，用户项目里不再有 publish.py 副本

工具索引：
  create_mcp_project        脚手架（写 server.py / AGENTS.md / requirements.txt / .publish.json）
  diagnose_mcp_project      不构建不上传的预检（配置合法性 + Cython 可行性 + 体积预估）
  update_mcp_config         按字段更新 .publish.json（author/access/version/bundleVendor 等）
  add_ignore_pattern        追加 .mcpignore 规则（不重复、保序）
  list_mcp_tools            列出项目里所有 @mcp.tool() 函数
  publish_mcp               加密打包 + 上传（subprocess 调 publish.py，带 code 透传）
  check_mcp_status          本地项目状态 + Cloud 商店注册表查询
  unpublish_mcp / republish_mcp  软下架 / 重新上架
"""

from __future__ import annotations

import ast
import json
import os
import re
import shutil
import subprocess
import sys
from importlib.resources import files as _resource_files
from pathlib import Path

from mcp.server.fastmcp import FastMCP

# 包目录（pip install 后 publish.py 和 templates/ 在同一目录下）
PACKAGE_DIR = Path(__file__).resolve().parent
PUBLISH_SCRIPT = PACKAGE_DIR / "publish.py"
TEMPLATES_DIR = PACKAGE_DIR / "templates"  # server_template.py / requirements_template.txt


def _load_agents_md_content() -> str:
    """读取作为用户项目 AGENTS.md 内容的 README。

    唯一事实源 = 仓库根 README.md。安装后（wheel）读包内副本；
    dev 模式（pip install -e .）包内无副本，fallback 到仓库根。
    """
    # 1. wheel 安装后：包内副本（由 hatchling force-include 复制）
    try:
        bundled = _resource_files("loongclaw_devkit") / "README.md"
        if bundled.is_file():
            return bundled.read_text(encoding="utf-8")
    except (FileNotFoundError, ModuleNotFoundError, AttributeError):
        pass
    # 2. dev fallback：仓库根（src/loongclaw_devkit/server.py → ../../../README.md）
    repo_root_readme = PACKAGE_DIR.parent.parent.parent / "README.md"
    if repo_root_readme.is_file():
        return repo_root_readme.read_text(encoding="utf-8")
    # 两路都不在 = devkit 安装损坏，Fail-Close
    raise FileNotFoundError(
        "无法定位 README.md（AGENTS.md 内容源）。"
        "wheel 未含包内副本且仓库根无源文件。"
    )


# ── 错误码（与 publish.py PublishErrorCode 对齐，AI 据此路由 auto-fix）─────
class ErrorCode:
    # 通用
    PROJECT_DIR_MISSING = "PROJECT_DIR_MISSING"
    PROJECT_DIR_NOT_EMPTY = "PROJECT_DIR_NOT_EMPTY"
    UNKNOWN = "UNKNOWN"
    # 配置
    CONFIG_INVALID = "CONFIG_INVALID"
    CONFIG_FIELD_UNKNOWN = "CONFIG_FIELD_UNKNOWN"
    CONFIG_FILE_MISSING = "CONFIG_FILE_MISSING"
    CONFIG_VALUE_INVALID = "CONFIG_VALUE_INVALID"
    RUNTIME_INVALID = "RUNTIME_INVALID"
    MCP_COMMAND_REQUIRED = "MCP_COMMAND_REQUIRED"
    BUILD_PLATFORM_REQUIRED = "BUILD_PLATFORM_REQUIRED"
    # 发布
    PUBLISH_SUBPROCESS_FAILED = "PUBLISH_SUBPROCESS_FAILED"
    PUBLISH_NO_JSON_OUTPUT = "PUBLISH_NO_JSON_OUTPUT"
    MISSING_TOKEN = "MISSING_TOKEN"
    # 文件操作
    FILE_NOT_FOUND = "FILE_NOT_FOUND"
    WRITE_FAILED = "WRITE_FAILED"
    SYNTAX_ERROR = "SYNTAX_ERROR"


mcp = FastMCP(
    "loongclaw-devkit",
    instructions=(
        "LoongClaw MCP 开发者工具包（AI-first）。"
        "帮助开发者通过对话式驱动完成 MCP 插件的创建、诊断、发布、下架。"
        "所有错误返回 {status, code, error, fix}：code 是稳定枚举用于 auto-fix，"
        "error/fix 是人类可读说明。下架不会影响已安装用户继续使用本地代码。"
    ),
)


# ══════════════════════════════════════════════════════════
# 辅助函数（非 MCP 工具）
# ══════════════════════════════════════════════════════════

def _ok(**kwargs) -> str:
    """返回成功响应。"""
    return json.dumps({"status": "success", **kwargs}, ensure_ascii=False, indent=2)


def _err(code: str, error: str, fix: str = "", **extra) -> str:
    """返回结构化错误响应。"""
    payload: dict = {"status": "error", "code": code, "error": error}
    if fix:
        payload["fix"] = fix
    payload.update(extra)
    return json.dumps(payload, ensure_ascii=False, indent=2)


def _resolve_token(token: str) -> str:
    """参数优先 > LOONGCLAW_STORE_KEY 环境变量。"""
    return token or os.environ.get("LOONGCLAW_STORE_KEY", "")


def _load_config(target: Path) -> tuple[dict | None, str | None]:
    """读取 .publish.json。返回 (config, error)。"""
    path = target / ".publish.json"
    if not path.exists():
        return None, f".publish.json 不存在于 {target}"
    try:
        return json.loads(path.read_text(encoding="utf-8")), None
    except json.JSONDecodeError as e:
        return None, f".publish.json 格式错误: {e}"


def _save_config(target: Path, config: dict) -> None:
    """写 .publish.json（不保存 token 字段）。"""
    safe = {k: v for k, v in config.items() if k != "token"}
    (target / ".publish.json").write_text(
        json.dumps(safe, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _call_cloud(endpoint: str, body: dict, token: str) -> dict:
    """POST JSON 到 Cloud API，返回解析后的 dict。"""
    import urllib.request
    import urllib.error

    url = f"https://api.loongclaw.net.cn{endpoint}"
    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            detail = json.loads(e.read().decode("utf-8"))
        except Exception:
            detail = {"message": str(e)}
        return {
            "status": "error",
            "http_status": e.code,
            "error": detail.get("error", detail),
        }
    except Exception as e:
        return {"status": "error", "error": str(e)}


def _is_mcp_tool_decorator(node) -> bool:
    """判断 AST 节点是否 mcp.tool 装饰器引用。"""
    if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name):
        return node.value.id == "mcp" and node.attr == "tool"
    return False


# ══════════════════════════════════════════════════════════
# MCP 工具
# ══════════════════════════════════════════════════════════

@mcp.tool()
def create_mcp_project(
    project_dir: str,
    plugin_id: str,
    plugin_name: str = "",
    description: str = "",
) -> str:
    """在指定目录创建新的 LoongClaw MCP 插件项目（AI 脚手架）。

    生成文件：
    - server.py           MCP 入口（已注册示例 hello 工具，替换为你的业务即可）
    - requirements.txt    Python 依赖清单
    - AGENTS.md           给 AI 看的开发指南
    - .publish.json       发布配置（author/access 必填留空，发布前调 update_mcp_config 填充）

    不再生成 publish.py ——发布逻辑由 devkit 的 publish_mcp 工具调用，
    用户项目保持精简。

    创建后推荐 AI 流程：
      1. 写业务逻辑（core.py / 其他模块，自动加密）
      2. 调 update_mcp_config 填 author + access
      3. 调 diagnose_mcp_project 预检
      4. 调 publish_mcp(upload=True) 发布

    Args:
        project_dir: 项目目录绝对路径（自动创建，但不能是非空目录）
        plugin_id: 插件 ID（字母数字和连字符，如 my-plugin）
        plugin_name: 显示名称（留空则用 plugin_id）
        description: 插件描述（留空则用 plugin_id）

    错误码：
      PROJECT_DIR_NOT_EMPTY - 目录已存在且非空
      WRITE_FAILED          - 写入失败（权限 / 磁盘空间）
    """
    target = Path(project_dir).resolve()

    if target.exists() and any(target.iterdir()):
        return _err(
            ErrorCode.PROJECT_DIR_NOT_EMPTY,
            f"目录 {target} 已存在且非空",
            fix="选择一个空目录或不存在的目录",
        )

    try:
        target.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        return _err(ErrorCode.WRITE_FAILED, f"创建目录失败: {e}")

    name = plugin_name or plugin_id
    files_created: list[str] = []

    try:
        # server.py
        server_template = TEMPLATES_DIR / "server_template.py"
        if server_template.exists():
            content = server_template.read_text(encoding="utf-8")
            content = content.replace("{{PLUGIN_ID}}", plugin_id)
            content = content.replace("{{PLUGIN_NAME}}", name)
            content = content.replace("{{PLUGIN_DESCRIPTION}}", description)
            (target / "server.py").write_text(content, encoding="utf-8")
            files_created.append("server.py")

        # AGENTS.md
        # 唯一事实源 = 仓库根 README.md（读取逻辑见 _load_agents_md_content）。
        # 运行时：wheel 安装 → 读包内副本；pip install -e → fallback 到仓库根。
        try:
            agents_content = _load_agents_md_content()
            (target / "AGENTS.md").write_text(agents_content, encoding="utf-8")
            files_created.append("AGENTS.md")
        except FileNotFoundError as e:
            return _err(ErrorCode.WRITE_FAILED, str(e))

        # requirements.txt
        req_template = TEMPLATES_DIR / "requirements_template.txt"
        if req_template.exists():
            shutil.copy2(req_template, target / "requirements.txt")
            files_created.append("requirements.txt")

        # .publish.json（Fail-Close：author / access 留空，强制显式填充）
        # v0.9.0 起不再复制 publish.py —— 发布逻辑在 devkit，用户项目保持纯净
        config = {
            "id": plugin_id,
            "name": name,
            "description": description,
            "version": "1.0.0",
            "author": "",     # ⚠️ 必填，AI 发布前调 update_mcp_config(field="author")
            "icon": "🔧",
            "access": "",     # ⚠️ 必填 "public" 或 "private"
            "upload": False,
            "bundleVendor": False,
        }
        (target / ".publish.json").write_text(
            json.dumps(config, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        files_created.append(".publish.json")
    except OSError as e:
        return _err(ErrorCode.WRITE_FAILED, f"写入模板失败: {e}", files_created=files_created)

    return _ok(
        project_dir=str(target),
        files_created=files_created,
        next_steps=[
            "编辑 server.py 添加你的 @mcp.tool() 函数（核心逻辑放独立 .py 会被自动加密）",
            "调 update_mcp_config 填充 author（字符串）和 access（public/private）",
            "调 diagnose_mcp_project 做预检，确认无 Cython 兼容性问题",
            "调 publish_mcp(upload=True, token=...) 一键发布到商店",
        ],
    )


@mcp.tool()
def diagnose_mcp_project(project_dir: str) -> str:
    """不构建不上传，对项目做全面预检。AI 应在调 publish_mcp 前调用本工具。

    检查项：
    - 目录结构（server.py / requirements.txt / .publish.json 是否存在）
    - .publish.json 字段完整性（author / access / version 等必填项）
    - server.py FastMCP 实例是否命名为 `mcp`（private 包壳模式约定）
    - .py 文件 Cython 可行性（文件名 / 参数名是否撞保留字）
    - @mcp.tool() 函数数量
    - 预估打包大小（未压缩，真实 zip 会更小）

    返回：ok=[...] 通过项，warnings=[...] 警告（不阻断），issues=[...] 必须修
    复才能发布的问题。

    Args:
        project_dir: 项目目录绝对路径
    """
    target = Path(project_dir).resolve()
    if not target.exists():
        return _err(ErrorCode.PROJECT_DIR_MISSING, f"目录不存在: {target}")

    ok: list[str] = []
    warnings: list[dict] = []
    issues: list[dict] = []

    # ── 结构检查
    for name in ("server.py", "requirements.txt", ".publish.json"):
        if (target / name).exists():
            ok.append(f"{name} 存在")
        else:
            issues.append({
                "code": ErrorCode.FILE_NOT_FOUND,
                "file": name,
                "fix": f"缺少 {name}；新项目请调 create_mcp_project 或补全此文件",
            })

    # ── 配置检查
    config, cfg_err = _load_config(target)
    if config is None and (target / ".publish.json").exists():
        issues.append({
            "code": ErrorCode.CONFIG_INVALID,
            "error": cfg_err or "unknown",
            "fix": "调 update_mcp_config 重建配置",
        })
    elif config:
        for f in ("id", "name", "version", "author", "access"):
            v = config.get(f, "")
            if isinstance(v, str) and not v.strip():
                issues.append({
                    "code": ErrorCode.CONFIG_INVALID,
                    "field": f,
                    "fix": f"调 update_mcp_config(field='{f}', value=...) 填充",
                })
        if config.get("access") and config["access"] not in {"public", "private"}:
            issues.append({
                "code": ErrorCode.CONFIG_VALUE_INVALID,
                "field": "access",
                "value": config["access"],
                "fix": "access 必须是 'public' 或 'private'",
            })

    # ── server.py 实例名（private 壳模式）+ 工具统计
    tool_count = 0
    entry = target / "server.py"
    if entry.exists():
        text = entry.read_text(encoding="utf-8", errors="replace")
        if "FastMCP" not in text:
            issues.append({
                "code": "ENTRYPOINT_NO_FASTMCP",
                "fix": "server.py 必须 from mcp.server.fastmcp import FastMCP 并实例化",
            })
        elif not re.search(r"^\s*mcp\s*(?::\s*\w+\s*)?=\s*FastMCP\s*\(", text, re.MULTILINE):
            is_private = bool(config and config.get("access") == "private")
            entry_msg = {
                "code": "ENTRYPOINT_INSTANCE_NAME",
                "fix": "把 FastMCP 实例改名为 `mcp = FastMCP(...)`，private 包壳模式要求",
            }
            (issues if is_private else warnings).append(entry_msg)
        else:
            ok.append("server.py FastMCP 实例命名正确（mcp）")
        tool_count = len(re.findall(r"@mcp\.tool\(", text))

    # ── Cython 可行性（借 publish.py 的函数，避免重复实现）
    try:
        if str(PACKAGE_DIR) not in sys.path:
            sys.path.insert(0, str(PACKAGE_DIR))
        # publish 是包内模块，用相对 import 形式也可；这里保持简单
        from publish import precheck_cython_compatibility, find_py_files  # type: ignore

        py_files = find_py_files(target)
        for s in precheck_cython_compatibility(target, py_files):
            issues.append({
                "code": "CYTHON_INCOMPAT",
                "detail": s,
                "fix": "按上方详情改源码，或加入 .mcpignore 排除出包",
            })
    except Exception as e:
        warnings.append({
            "code": "DIAGNOSE_CYTHON_SKIPPED",
            "reason": f"Cython 预检跳过: {e}",
        })

    if tool_count == 0 and entry.exists():
        warnings.append({
            "code": "NO_TOOLS_REGISTERED",
            "fix": "server.py 没有 @mcp.tool() 函数，AI 无法调用任何能力",
        })
    elif tool_count > 0:
        ok.append(f"已注册 {tool_count} 个 @mcp.tool() 函数")

    # ── 体积预估（已排除常见 ignore）
    size_bytes = 0
    ignored = {"__pycache__", ".git", ".venv", "venv", "_staging", "node_modules"}
    for f in target.rglob("*"):
        if not f.is_file():
            continue
        if any(p in ignored for p in f.relative_to(target).parts):
            continue
        try:
            size_bytes += f.stat().st_size
        except OSError:
            pass
    size_mb = size_bytes / 1024 / 1024
    if size_mb > 100:
        warnings.append({
            "code": "PROJECT_SIZE_LARGE",
            "size_mb": round(size_mb, 1),
            "fix": "项目体积较大，考虑在 .mcpignore 中排除测试数据、日志、缓存",
        })

    return json.dumps({
        "status": "success" if not issues else "issues_found",
        "project_dir": str(target),
        "summary": {
            "ok_count": len(ok),
            "warnings_count": len(warnings),
            "issues_count": len(issues),
            "tool_count": tool_count,
            "approx_size_mb": round(size_mb, 1),
        },
        "ok": ok,
        "warnings": warnings,
        "issues": issues,
        "ready_to_publish": len(issues) == 0,
    }, ensure_ascii=False, indent=2)


@mcp.tool()
def update_mcp_config(
    project_dir: str,
    field: str,
    value: str,
) -> str:
    """更新 .publish.json 的单个字段。AI 用此工具替代编辑 JSON 文件。

    允许的字段：id, name, description, version, author, icon, access, upload,
    bundleVendor。不能改 token（请用环境变量 LOONGCLAW_STORE_KEY 或 publish_mcp
    的 token 参数）。

    Args:
        project_dir: 项目目录绝对路径
        field: 要更新的字段名
        value: 新值（字符串；bool 字段传 "true"/"false"）

    错误码：
      CONFIG_FIELD_UNKNOWN  - 字段名不在允许列表
      CONFIG_VALUE_INVALID  - 值不合法（如 access 非 public/private）
    """
    target = Path(project_dir).resolve()
    if not target.exists():
        return _err(ErrorCode.PROJECT_DIR_MISSING, f"目录不存在: {target}")

    allowed_string = {"id", "name", "description", "version", "author", "icon", "access"}
    allowed_bool = {"upload", "bundleVendor", "usesPlatformLlm"}
    allowed = allowed_string | allowed_bool

    if field not in allowed:
        return _err(
            ErrorCode.CONFIG_FIELD_UNKNOWN,
            f"不允许的字段 `{field}`",
            fix=f"允许的字段：{sorted(allowed)}",
        )

    if field == "access" and value not in {"public", "private"}:
        return _err(
            ErrorCode.CONFIG_VALUE_INVALID,
            f"access 必须是 'public' 或 'private'，当前：{value!r}",
        )

    config, err = _load_config(target)
    if config is None:
        return _err(ErrorCode.CONFIG_FILE_MISSING, err or "unknown",
                    fix="先调 create_mcp_project 创建项目")

    if field in allowed_bool:
        if value.lower() in {"true", "1", "yes", "y"}:
            config[field] = True
        elif value.lower() in {"false", "0", "no", "n"}:
            config[field] = False
        else:
            return _err(
                ErrorCode.CONFIG_VALUE_INVALID,
                f"字段 `{field}` 是布尔，值必须是 true/false（收到：{value!r}）",
            )
    else:
        config[field] = value

    try:
        _save_config(target, config)
    except OSError as e:
        return _err(ErrorCode.WRITE_FAILED, f"写入 .publish.json 失败: {e}")

    return _ok(field=field, new_value=config[field], config=config)


@mcp.tool()
def add_ignore_pattern(
    project_dir: str,
    patterns: list[str],
) -> str:
    """追加规则到 .mcpignore（gitignore 语法），把非 MCP 运行时文件排除出打包。

    已存在的规则不会重复追加。文件不存在时自动创建。

    典型场景：
    - 测试数据 / 固件：`tests/fixtures/**`
    - 仪表板源码：`dashboard/`
    - 数据管道、日志、缓存：`data/`, `logs/`, `*.log`, `.cache/`
    - 大型二进制：`*.mp4`, `*.sqlite`

    Args:
        project_dir: 项目目录绝对路径
        patterns: 要追加的规则数组，gitignore 语法
    """
    target = Path(project_dir).resolve()
    if not target.exists():
        return _err(ErrorCode.PROJECT_DIR_MISSING, f"目录不存在: {target}")

    if not patterns:
        return _err(ErrorCode.CONFIG_VALUE_INVALID, "patterns 不能为空")

    ignore_path = target / ".mcpignore"
    existing_lines: list[str] = []
    if ignore_path.exists():
        existing_lines = ignore_path.read_text(encoding="utf-8").splitlines()

    existing_set = {
        l.strip() for l in existing_lines
        if l.strip() and not l.strip().startswith("#")
    }
    added: list[str] = []
    skipped: list[str] = []
    for p in patterns:
        p_stripped = p.strip()
        if not p_stripped:
            continue
        if p_stripped in existing_set:
            skipped.append(p_stripped)
        else:
            existing_lines.append(p_stripped)
            existing_set.add(p_stripped)
            added.append(p_stripped)

    try:
        ignore_path.write_text("\n".join(existing_lines) + "\n", encoding="utf-8")
    except OSError as e:
        return _err(ErrorCode.WRITE_FAILED, f"写入 .mcpignore 失败: {e}")

    return _ok(
        added=added,
        skipped_already_existing=skipped,
        total_rules=len(existing_set),
    )


@mcp.tool()
def list_mcp_tools(project_dir: str) -> str:
    """列出 server.py 中所有 @mcp.tool() 函数及其签名/docstring 摘要。

    AI 修改 server.py 后可调本工具自查工具是否齐全、参数签名是否符合预期。

    Args:
        project_dir: 项目目录绝对路径
    """
    target = Path(project_dir).resolve()
    if not target.exists():
        return _err(ErrorCode.PROJECT_DIR_MISSING, f"目录不存在: {target}")

    entry = target / "server.py"
    if not entry.exists():
        return _err(ErrorCode.FILE_NOT_FOUND, "server.py 不存在",
                    fix="先调 create_mcp_project 创建项目")

    try:
        tree = ast.parse(entry.read_text(encoding="utf-8", errors="replace"))
    except SyntaxError as e:
        return _err(ErrorCode.SYNTAX_ERROR,
                    f"server.py 第 {e.lineno} 行语法错误: {e.msg}",
                    fix="修复语法错误后重试",
                    line=e.lineno)

    tools: list[dict] = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        has_mcp_tool = any(
            (isinstance(d, ast.Call) and _is_mcp_tool_decorator(d.func))
            or _is_mcp_tool_decorator(d)
            for d in node.decorator_list
        )
        if not has_mcp_tool:
            continue

        params: list[dict] = []
        for arg in node.args.args:
            annotation = ast.unparse(arg.annotation) if arg.annotation else "Any"
            params.append({"name": arg.arg, "type": annotation})

        doc = ast.get_docstring(node) or ""
        summary = doc.strip().split("\n")[0] if doc else ""

        tools.append({
            "name": node.name,
            "line": node.lineno,
            "params": params,
            "summary": summary[:200],
        })

    return json.dumps({
        "status": "success",
        "project_dir": str(target),
        "tool_count": len(tools),
        "tools": tools,
    }, ensure_ascii=False, indent=2)


@mcp.tool()
def publish_mcp(
    project_dir: str,
    version: str = "",
    access: str = "",
    upload: bool = False,
    token: str = "",
) -> str:
    """一键加密打包并发布 MCP 插件到 LoongClaw 商店。

    自动流程：校验项目 → Cython 加密编译 → 打包 zip → 生成 manifest → 上传。
    推荐先调 diagnose_mcp_project 做预检，全绿后再调本工具。

    排除非运行时文件请用 add_ignore_pattern。v0.9.0 起已删除 skip_encrypt 参数
    ——保留明文既不安全又占体积，完全排除出包才是正确做法。

    Args:
        project_dir: 项目目录绝对路径
        version: 版本号（如 1.0.0），留空则用 .publish.json 里的值
        access: public 或 private，留空则用 .publish.json 里的值
        upload: 是否上传到 LoongClaw 商店
        token: LoongClaw Store Key（也可用 LOONGCLAW_STORE_KEY 环境变量）

    错误码（透传 publish.py 的 PublishErrorCode）：
      CONFIG_INVALID / PROJECT_STRUCTURE_INVALID - 预检失败，先调 diagnose
      CYTHON_INCOMPAT / CYTHON_COMPILE_FAILED    - 改源码或加 .mcpignore
      UPLOAD_NO_TOKEN / UPLOAD_HTTP_ERROR        - 检查 token 或响应
      PUBLISH_SUBPROCESS_FAILED                  - publish.py 异常退出
    """
    target = Path(project_dir).resolve()
    if not target.exists():
        return _err(ErrorCode.PROJECT_DIR_MISSING, f"目录不存在: {target}",
                    fix="检查路径是否正确")

    if not PUBLISH_SCRIPT.exists():
        return _err(ErrorCode.FILE_NOT_FOUND, "publish.py 未找到",
                    fix=f"确认 loongclaw-devkit 安装完整，预期位置: {PUBLISH_SCRIPT}")

    cmd = [sys.executable, str(PUBLISH_SCRIPT), "--auto", "--json-output",
           "--dir", str(target)]
    if version:
        cmd.extend(["--version", version])
    if access:
        cmd.extend(["--access", access])
    cmd.append("--upload" if upload else "--no-upload")
    if token:
        cmd.extend(["--token", token])

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, cwd=str(target))

        # publish.py --json-output 保证最后一行是 JSON
        lines = result.stdout.strip().split("\n")
        for line in reversed(lines):
            line = line.strip()
            if line.startswith("{"):
                try:
                    parsed = json.loads(line)
                    return json.dumps(parsed, ensure_ascii=False, indent=2)
                except json.JSONDecodeError:
                    continue

        # 没找到 JSON → 结构化错误
        return _err(
            ErrorCode.PUBLISH_NO_JSON_OUTPUT,
            "publish.py 没有输出 JSON 结果",
            fix="检查 stdout / stderr 诊断",
            returncode=result.returncode,
            stdout_tail=result.stdout[-2000:] if result.stdout else "",
            stderr_tail=result.stderr[-2000:] if result.stderr else "",
        )
    except Exception as e:
        return _err(
            ErrorCode.PUBLISH_SUBPROCESS_FAILED,
            str(e),
            fix="检查 Python 环境和 publish.py 是否可执行",
        )


@mcp.tool()
def check_mcp_status(plugin_id: str = "", project_dir: str = "") -> str:
    """查询 MCP 插件的状态。

    - 传 plugin_id 查 LoongClaw 商店注册表（需 LOONGCLAW_STORE_KEY）
    - 传 project_dir 查本地项目文件状态和 .publish.json

    两个参数可同时传。没有 token 时 Cloud 查询返回 MISSING_TOKEN，不静默降级。

    Args:
        plugin_id: 插件 ID
        project_dir: 项目目录绝对路径
    """
    if not plugin_id and not project_dir:
        return _err(
            ErrorCode.CONFIG_VALUE_INVALID,
            "请至少提供 plugin_id 或 project_dir",
        )

    result: dict = {"status": "ok"}

    if project_dir:
        target = Path(project_dir).resolve()
        if not target.exists():
            return _err(ErrorCode.PROJECT_DIR_MISSING, f"目录不存在: {target}")

        config, cfg_err = _load_config(target)
        if config is None and (target / ".publish.json").exists():
            result["config_error"] = cfg_err
        result["config"] = config
        result["files"] = {
            "server.py": (target / "server.py").exists(),
            "requirements.txt": (target / "requirements.txt").exists(),
            "AGENTS.md": (target / "AGENTS.md").exists(),
            "project.zip": (target / "project.zip").exists(),
            ".publish.json": (target / ".publish.json").exists(),
            ".mcpignore": (target / ".mcpignore").exists(),
        }
        ignored = {"__pycache__", ".git", ".venv", "venv", "_staging"}
        py_files = [
            f for f in target.rglob("*.py")
            if not any(p in ignored for p in f.relative_to(target).parts)
        ]
        result["py_file_count"] = len(py_files)

    if plugin_id:
        token = os.environ.get("LOONGCLAW_STORE_KEY", "")
        if not token:
            # v0.9.0：不再静默降级为 registry_note，AI 需要看到 code 决定是否
            # 触发 token 获取流程
            result["registry"] = {
                "status": "error",
                "code": ErrorCode.MISSING_TOKEN,
                "fix": "设置 LOONGCLAW_STORE_KEY 环境变量或调用方传入",
            }
        else:
            import urllib.request
            url = "https://api.loongclaw.net.cn/v1/store/mcp/registry.json"
            req = urllib.request.Request(
                url, headers={"Authorization": f"Bearer {token}"},
            )
            try:
                with urllib.request.urlopen(req, timeout=30) as resp:
                    registry = json.loads(resp.read().decode("utf-8"))
                    servers = registry.get("servers", [])
                    found = next((s for s in servers if s.get("id") == plugin_id), None)
                    result["registry"] = {
                        "status": "success",
                        "found": found is not None,
                        "entry": found,
                    }
            except Exception as e:
                result["registry"] = {"status": "error", "error": str(e)}

    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
def unpublish_mcp(
    plugin_id: str,
    store_type: str = "mcp",
    reason: str = "",
    token: str = "",
) -> str:
    """下架自己发布的 MCP 插件 / Skill（软下架）。

    - 新用户在商店里看不到该插件
    - **已安装的用户仍可继续使用本地代码**（不会强制卸载/禁用）
    - 重新上传同 id 的新版本不会自动复活，需要 republish_mcp

    只能下架自己发布的（服务端校验 uploadedBy == 当前 Store Key 的 userId）。

    Args:
        plugin_id: 插件 ID
        store_type: 'mcp' 或 'skill'
        reason: 下架原因（可选）
        token: LoongClaw Store Key
    """
    tok = _resolve_token(token)
    if not tok:
        return _err(ErrorCode.MISSING_TOKEN, "缺少 Store Key",
                    fix="传 token 参数或设置 LOONGCLAW_STORE_KEY 环境变量")

    body: dict = {"id": plugin_id, "storeType": store_type}
    if reason:
        body["reason"] = reason

    result = _call_cloud("/v1/store/unpublish", body, tok)
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
def republish_mcp(
    plugin_id: str,
    store_type: str = "mcp",
    token: str = "",
) -> str:
    """重新上架之前下架的 MCP 插件 / Skill。

    Args:
        plugin_id: 插件 ID
        store_type: 'mcp' 或 'skill'
        token: LoongClaw Store Key
    """
    tok = _resolve_token(token)
    if not tok:
        return _err(ErrorCode.MISSING_TOKEN, "缺少 Store Key",
                    fix="传 token 参数或设置 LOONGCLAW_STORE_KEY 环境变量")

    body = {"id": plugin_id, "storeType": store_type}
    result = _call_cloud("/v1/store/republish", body, tok)
    return json.dumps(result, ensure_ascii=False, indent=2)


def main():
    mcp.run(transport="stdio")
