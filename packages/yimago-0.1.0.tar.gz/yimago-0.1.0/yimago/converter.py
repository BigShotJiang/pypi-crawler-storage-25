from PIL import Image
import os

class YeanmitConverter:
    @staticmethod
    def to_format(y_image_instance, new_format, output_path=None):
        img = y_image_instance.image
        
        if new_format.lower() in ["jpg", "jpeg"]:
            if img.mode in ("RGBA", "P"):
                img = img.convert("RGB")
        
        if not output_path:
            base = os.path.splitext(y_image_instance.path)[0]
            output_path = f"{base}.{new_format.lower()}"
        
        img.save(output_path)
        print(f"Convertido exitosamente a {new_format}: {output_path}")
        return output_path