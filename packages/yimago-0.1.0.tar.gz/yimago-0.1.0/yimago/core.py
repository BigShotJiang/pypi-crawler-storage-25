from PIL import Image

class YImage:
    def __init__(self, path, debug_in=False):
        self.path = path
        self.image = Image.open(path)
        self.format = self.image.format
        self.size = self.image.size
        self.debug_in = debug_in

    def resize_to(self, width, height):
        self.image = self.image.resize((width, height), Image.LANCZOS)
        self.size = self.image.size
        if self.debug_in:
            print(f"Redimencionada a: {width}x{height}")
        return self

    def rotate_to(self, degrees):
        self.image = self.image.rotate(degrees, expand=True)
        if self.debug_in:
            print(f"Rotada: {degrees} grados")
        return self
    
    def convert_to(self, extension):
        from .converter import YeanmitConverter
        YeanmitConverter.to_format(self, extension)
        return self
    
    def grayscale(self):
        self.image = self.image.convert("L")
        if self.debug_in:
            print("Convertida a escala de grises")
        return self

    def save(self, output_path):
        if self.image.mode in ("RGBA", "P") and output_path.lower().endswith((".jpg", ".jpeg")):
            self.image = self.image.convert("RGB")
        self.image.save(output_path)
        if self.debug_in:
            print(f"Imagen guardada en: {output_path}")