import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
from PIL import ImageTk, Image
from .core import YImage
from tkinter import simpledialog

class YimagoGUI:
    def __init__(self, file_path=None):
        self.root = tk.Tk()
        self.root.title("Yimago Visual Editor")
        self.root.geometry("900x700")
        
        self.y_img = None
        self.tk_image = None

        self.canvas = tk.Canvas(self.root, bg="#2c3e50")
        self.canvas.pack(expand=True, fill="both")

        self.toolbar = tk.Frame(self.root, bg="#34495e")
        self.toolbar.pack(fill="x", side="bottom", ipady=10)

        self.btn_load = tk.Button(self.toolbar, text="📁 Abrir", command=self.open_image)
        self.btn_load.pack(side="left", padx=10)

        self.btn_rotate = tk.Button(self.toolbar, text="🔄 Rotar 90°", command=self.action_rotate)
        self.btn_rotate.pack(side="left", padx=10)

        self.btn_gray = tk.Button(self.toolbar, text="🌑 Gris", command=self.action_grayscale)
        self.btn_gray.pack(side="left", padx=10)

        self.btn_save = tk.Button(self.toolbar, text="💾 Guardar", command=self.action_save)
        self.btn_save.pack(side="right", padx=10)

        self.btn_resize = tk.Button(self.toolbar, text="📏 Redimensionar", command=self.action_resize)
        self.btn_resize.pack(side="left", padx=10)

        self.btn_convert = tk.Button(self.toolbar, text="🔄 Convertir", command=self.action_convert)
        self.btn_convert.pack(side="left", padx=10)

        if file_path:
            self.load_image_from_path(file_path)

        self.root.mainloop()

    def action_rotate(self):
        if self.y_img:
            self.y_img.rotate_to(90)
            self.update_view()

    def action_grayscale(self):
        if self.y_img:
            self.y_img.grayscale()
            self.update_view()

    def action_save(self):
        if self.y_img:
            save_path = filedialog.asksaveasfilename(defaultextension=".jpg")
            if save_path:
                self.y_img.save(save_path)

    def load_image_from_path(self, file_path):
        self.y_img = YImage(file_path)
        self.update_view()

    def open_image(self):
        file_path = filedialog.askopenfilename(filetypes=[("Imágenes", "*.jpg;*.png;*.webp")])
        if file_path:
            self.load_image_from_path(file_path)

    def update_view(self):
        if self.y_img:
            self.tk_image = ImageTk.PhotoImage(self.y_img.image)
            self.canvas.delete("all")
            self.root.update_idletasks() 
            width = self.canvas.winfo_width()
            height = self.canvas.winfo_height()
            self.canvas.create_image(width // 2, height // 2, image=self.tk_image)

    def action_resize(self):
        if self.y_img:
            w = simpledialog.askinteger("Redimensionar", "Nuevo Ancho (px):", parent=self.root)
            h = simpledialog.askinteger("Redimensionar", "Nuevo Alto (px):", parent=self.root)
            
            if w and h:
                self.y_img.resize_to(w, h)
                self.update_view()
                messagebox.showinfo("Yimago", f"Imagen redimensionada a {w}x{h}")

    def action_convert(self):
        if self.y_img:
            formato = simpledialog.askstring("Convertir", "Escribe el formato (png, jpg, webp):")
            if formato:
                self.y_img.convert_to(formato)
                messagebox.showinfo("Yimago", f"Convertido a {formato} exitosamente.")