from .core import YImage
from .gui import YimagoGUI
from .converter import YeanmitConverter

__version__ = "0.1.0"

print(f"Yimago v{__version__}")