import unittest
import os
from yimago import YImage

class TestYimagoCore(unittest.TestCase):
    def setUp(self):
        self.test_img_path = "examples/test.png"
        if not os.path.exists(self.test_img_path):
            from PIL import Image
            img = Image.new('RGB', (100, 100), color='red')
            img.save(self.test_img_path)

    def test_resize(self):
        """Prueba que el redimensionado funcione"""
        img = YImage(self.test_img_path)
        img.resize_to(50, 50)
        actual_size = img.size
        img.image.close() 
        self.assertEqual(actual_size, (50, 50))

    def test_grayscale_mode(self):
        """Prueba que la conversión a grises cambie el modo de la imagen"""
        img = YImage(self.test_img_path)
        img.grayscale()
        self.assertEqual(img.image.mode, "L")

    def test_debug_toggle(self):
        """Prueba que el nuevo campo debug_in se asigne correctamente"""
        img = YImage(self.test_img_path)
        img.debug_in = False
        self.assertFalse(img.debug_in)

if __name__ == "__main__":
    unittest.main()