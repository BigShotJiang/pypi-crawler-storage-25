\## Yimago v0.1.0 ##

Libreria de procesamiento de imagenes para Python. Permite manipular archivos mediante encadenamiento de metodos y una interfaz grafica integrada.



\# Características:

* Method Chaining: Rotar, escala de grises y redimensionar en una linea.



* Modo Debug: Control de mensajes en consola con el campo debug\_in.



* GUI: Editor visual basado en Tkinter.



* Formatos: Soporte para PNG, JPG y WEBP.



\# Instalacion

* pip install yimago



\# Ejemplo de uso

* from yimago import YImage



\# Procesamiento rapido

* (YImage("entrada.png").rotate\_to(90).grayscale().resize\_to(500, 500).save("salida.jpg"))



\# Interfaz Visual

* from yimago import YimagoGUI
* YimagoGUI("imagen.png")



\# Licencia

* MIT License. Codigo abierto para todos.

