from setuptools import setup, find_packages
import os

setup(
    name="yimago",
    version="0.1.0",
    author="Anthony",
    description="Librería de edición de imágenes en Python",
    long_description=open("README.md").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "Pillow==11.3.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.14",
)