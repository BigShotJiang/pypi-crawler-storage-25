from enum import StrEnum
from pydantic import BaseModel, Field
from typing import Annotated, Generic, Sequence, TypeVar
from nexo.types.string import ListOfStrs


class ShortServiceKey(StrEnum):
    STUDIO = "studio"
    LOCUS = "locus"
    TELEMETRY = "telemetry"
    IDENTITY = "identity"
    RESEARCH = "research"
    REGISTRY = "registry"
    SCRIBE = "scribe"
    CDS = "cds"
    IMAGING = "imaging"
    MCU = "mcu"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


ShortServiceKeyT = TypeVar("ShortServiceKeyT", bound=ShortServiceKey)
OptShortServiceKey = ShortServiceKey | None
OptShortServiceKeyT = TypeVar("OptShortServiceKeyT", bound=OptShortServiceKey)


class SimpleShortServiceKeyMixin(BaseModel, Generic[OptShortServiceKeyT]):
    key: Annotated[OptShortServiceKeyT, Field(..., description="Service Key")]


class FullShortServiceKeyMixin(BaseModel, Generic[OptShortServiceKeyT]):
    service_key: Annotated[OptShortServiceKeyT, Field(..., description="Service Key")]


ListOfShortServiceKeys = list[ShortServiceKey]
ListOfShortServiceKeysT = TypeVar(
    "ListOfShortServiceKeysT", bound=ListOfShortServiceKeys
)
OptListOfShortServiceKeys = ListOfShortServiceKeys | None
OptListOfShortServiceKeysT = TypeVar(
    "OptListOfShortServiceKeysT", bound=OptListOfShortServiceKeys
)


class SimpleShortServiceKeysMixin(BaseModel, Generic[OptListOfShortServiceKeysT]):
    keys: Annotated[OptListOfShortServiceKeysT, Field(..., description="Service Keys")]


class FullShortServiceKeysMixin(BaseModel, Generic[OptListOfShortServiceKeysT]):
    service_keys: Annotated[
        OptListOfShortServiceKeysT, Field(..., description="Service Keys")
    ]


SeqOfShortServiceKeys = Sequence[ShortServiceKey]
SeqOfShortServiceKeysT = TypeVar("SeqOfShortServiceKeysT", bound=SeqOfShortServiceKeys)
OptSeqOfShortServiceKeys = SeqOfShortServiceKeys | None
OptSeqOfShortServiceKeysT = TypeVar(
    "OptSeqOfShortServiceKeysT", bound=OptSeqOfShortServiceKeys
)


class ServiceKey(StrEnum):
    STUDIO = "maleo-studio"
    LOCUS = "maleo-locus"
    TELEMETRY = "maleo-telemetry"
    IDENTITY = "maleo-identity"
    RESEARCH = "maleo-research"
    REGISTRY = "maleo-registry"
    SCRIBE = "maleo-scribe"
    CDS = "maleo-cds"
    IMAGING = "maleo-imaging"
    MCU = "maleo-mcu"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


ServiceKeyT = TypeVar("ServiceKeyT", bound=ServiceKey)
OptServiceKey = ServiceKey | None
OptServiceKeyT = TypeVar("OptServiceKeyT", bound=OptServiceKey)


class SimpleServiceKeyMixin(BaseModel, Generic[OptServiceKeyT]):
    key: Annotated[OptServiceKeyT, Field(..., description="Service Key")]


class FullServiceKeyMixin(BaseModel, Generic[OptServiceKeyT]):
    service_key: Annotated[OptServiceKeyT, Field(..., description="Service Key")]


ListOfServiceKeys = list[ServiceKey]
ListOfServiceKeysT = TypeVar("ListOfServiceKeysT", bound=ListOfServiceKeys)
OptListOfServiceKeys = ListOfServiceKeys | None
OptListOfServiceKeysT = TypeVar("OptListOfServiceKeysT", bound=OptListOfServiceKeys)


class SimpleServiceKeysMixin(BaseModel, Generic[OptListOfServiceKeysT]):
    keys: Annotated[OptListOfServiceKeysT, Field(..., description="Service Keys")]


class FullServiceKeysMixin(BaseModel, Generic[OptListOfServiceKeysT]):
    service_keys: Annotated[
        OptListOfServiceKeysT, Field(..., description="Service Keys")
    ]


SeqOfServiceKeys = Sequence[ServiceKey]
SeqOfServiceKeysT = TypeVar("SeqOfServiceKeysT", bound=SeqOfServiceKeys)
OptSeqOfServiceKeys = SeqOfServiceKeys | None
OptSeqOfServiceKeysT = TypeVar("OptSeqOfServiceKeysT", bound=OptSeqOfServiceKeys)


class ShortServiceName(StrEnum):
    STUDIO = "Studio"
    LOCUS = "Locus"
    TELEMETRY = "Telemetry"
    IDENTITY = "Identity"
    RESEARCH = "Research"
    REGISTRY = "Registry"
    SCRIBE = "Scribe"
    CDS = "CDS"
    IMAGING = "Imaging"
    MCU = "MCU"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


ShortServiceNameT = TypeVar("ShortServiceNameT", bound=ShortServiceName)
OptShortServiceName = ShortServiceName | None
OptShortServiceNameT = TypeVar("OptShortServiceNameT", bound=OptShortServiceName)


class SimpleShortServiceNameMixin(BaseModel, Generic[OptShortServiceNameT]):
    name: Annotated[OptShortServiceNameT, Field(..., description="Service Name")]


class FullShortServiceNameMixin(BaseModel, Generic[OptShortServiceNameT]):
    service_name: Annotated[
        OptShortServiceNameT, Field(..., description="Service Name")
    ]


ListOfShortServiceNames = list[ShortServiceName]
ListOfShortServiceNamesT = TypeVar(
    "ListOfShortServiceNamesT", bound=ListOfShortServiceNames
)
OptListOfShortServiceNames = ListOfShortServiceNames | None
OptListOfShortServiceNamesT = TypeVar(
    "OptListOfShortServiceNamesT", bound=OptListOfShortServiceNames
)


class SimpleShortServiceNamesMixin(BaseModel, Generic[OptListOfShortServiceNamesT]):
    names: Annotated[
        OptListOfShortServiceNamesT, Field(..., description="Service Names")
    ]


class FullShortServiceNamesMixin(BaseModel, Generic[OptListOfShortServiceNamesT]):
    service_names: Annotated[
        OptListOfShortServiceNamesT, Field(..., description="Service Names")
    ]


SeqOfShortServiceNames = Sequence[ShortServiceName]
SeqOfShortServiceNamesT = TypeVar(
    "SeqOfShortServiceNamesT", bound=SeqOfShortServiceNames
)
OptSeqOfShortServiceNames = SeqOfShortServiceNames | None
OptSeqOfShortServiceNamesT = TypeVar(
    "OptSeqOfShortServiceNamesT", bound=OptSeqOfShortServiceNames
)


class ServiceName(StrEnum):
    STUDIO = "MaleoStudio"
    LOCUS = "MaleoLocus"
    TELEMETRY = "MaleoTelemetry"
    IDENTITY = "MaleoIdentity"
    RESEARCH = "MaleoResearch"
    REGISTRY = "MaleoRegistry"
    SCRIBE = "MaleoScribe"
    CDS = "MaleoCDS"
    IMAGING = "MaleoImaging"
    MCU = "MaleoMCU"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


ServiceNameT = TypeVar("ServiceNameT", bound=ServiceName)
OptServiceName = ServiceName | None
OptServiceNameT = TypeVar("OptServiceNameT", bound=OptServiceName)


class SimpleServiceNameMixin(BaseModel, Generic[OptServiceNameT]):
    name: Annotated[OptServiceNameT, Field(..., description="Service Name")]


class FullServiceNameMixin(BaseModel, Generic[OptServiceNameT]):
    service_name: Annotated[OptServiceNameT, Field(..., description="Service Name")]


ListOfServiceNames = list[ServiceName]
ListOfServiceNamesT = TypeVar("ListOfServiceNamesT", bound=ListOfServiceNames)
OptListOfServiceNames = ListOfServiceNames | None
OptListOfServiceNamesT = TypeVar("OptListOfServiceNamesT", bound=OptListOfServiceNames)


class SimpleServiceNamesMixin(BaseModel, Generic[OptListOfServiceNamesT]):
    names: Annotated[OptListOfServiceNamesT, Field(..., description="Service Names")]


class FullServiceNamesMixin(BaseModel, Generic[OptListOfServiceNamesT]):
    service_names: Annotated[
        OptListOfServiceNamesT, Field(..., description="Service Names")
    ]


SeqOfServiceNames = Sequence[ServiceName]
SeqOfServiceNamesT = TypeVar("SeqOfServiceNamesT", bound=SeqOfServiceNames)
OptSeqOfServiceNames = SeqOfServiceNames | None
OptSeqOfServiceNamesT = TypeVar("OptSeqOfServiceNamesT", bound=OptSeqOfServiceNames)
