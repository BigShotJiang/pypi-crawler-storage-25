"""
fusiontest/core/runner.py

The FusionTest main runner — orchestrates the full test loop:
  1. Parse the screen
  2. Ask the model what to do
  3. Run it through guardrails
  4. Execute
  5. Record and report
  6. Repeat until goal is complete or max_steps reached
"""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from fusiontest.core.action_model import Action, ActionBackend, ActionModel
from fusiontest.core.goal_verifier import GoalVerifier
from fusiontest.core.screen_parser import UIElement
from fusiontest.core.secrets import SecretResolver, resolve_goals
from fusiontest.core.tokens import TokenUsage
from fusiontest.guardrails.engine import GuardrailsConfig, GuardrailsEngine

logger = logging.getLogger("fusiontest.runner")


# ── Adapter protocol — mobile and desktop adapters must implement this ─────────

@runtime_checkable
class UIAdapter(Protocol):
    def get_screen(self) -> tuple[list[UIElement], str]: ...
    def get_screenshot(self) -> bytes: ...
    def execute(self, action: Action, elements: list[UIElement]) -> bool: ...


# ── Result types ───────────────────────────────────────────────────────────────

@dataclass
class StepResult:
    goal: str
    success: bool
    steps_taken: int
    actions: list[str] = field(default_factory=list)
    screenshots: list[bytes] = field(default_factory=list)
    error: str = ""
    duration_seconds: float = 0.0
    token_usage: TokenUsage = field(default_factory=TokenUsage)


@dataclass
class RunResult:
    name: str
    platform: str
    locale: str
    success: bool
    url: str = ""
    steps: list[StepResult] = field(default_factory=list)
    total_duration_seconds: float = 0.0
    bugs_detected: list[str] = field(default_factory=list)
    video_path: str = ""
    cancelled: bool = False

    @property
    def stability_score(self) -> float:
        if not self.steps:
            return 0.0
        return sum(1 for s in self.steps if s.success) / len(self.steps)

    @property
    def total_token_usage(self) -> TokenUsage:
        total = TokenUsage()
        for s in self.steps:
            total += s.token_usage
        return total


# ── Runner config ──────────────────────────────────────────────────────────────

@dataclass
class RunnerConfig:
    backend: ActionBackend = "gpt4o"
    model_path: str | None = None
    max_steps_per_goal: int = 25
    screenshot_on_every_step: bool = False
    screenshot_on_failure: bool = True
    guardrails: GuardrailsConfig = field(default_factory=GuardrailsConfig)
    verifier_confidence_threshold: float = 0.75
    # Hard per-goal wall-clock timeout. If a single goal exceeds this value the
    # watchdog force-closes the adapter (Playwright browser) to unwind any stuck
    # call, records the step as a timeout failure, and cancels the rest of the
    # run. Default 180 s keeps each goal bounded without cutting short
    # legitimate multi-step flows. Set to 0 to disable.
    max_goal_seconds: int = 180
    # Path to write step-level JSONL logs (used by the training pipeline)
    step_log_path: str | None = None
    # Video recording
    record_video: bool = False
    video_output_dir: str = "fusiontest-reports/videos"
    # Named secrets for {{VAR}} template resolution in goal strings.
    # Keys are variable names, values are secret strings.
    # Env vars are also searched automatically when a key is missing here.
    secrets: dict[str, str] = field(default_factory=dict)


# ── Runner ─────────────────────────────────────────────────────────────────────

class FusionTestRunner:
    """
    Orchestrates a full FusionTest run across multiple goal steps.

    Usage:
        runner = FusionTestRunner(adapter, config)
        result = runner.run(
            name="Onboarding smoke test",
            goals=["Log in", "Navigate to settings", "Update profile name"],
            platform="android",
            locale="en-US",
        )
    """

    def __init__(self, adapter: UIAdapter, config: RunnerConfig | None = None):
        self.adapter = adapter
        self.config = config or RunnerConfig()
        self.model = ActionModel(
            backend=self.config.backend,
            model_path=self.config.model_path,
        )
        self.guardrails = GuardrailsEngine(self.config.guardrails)
        self.verifier = GoalVerifier(
            backend=self.config.backend,
            confidence_threshold=self.config.verifier_confidence_threshold,
        )
        # Secret resolver — handles {{VAR}} substitution and redaction.
        self._secrets = SecretResolver(secrets=self.config.secrets)
        self._step_log = None
        if self.config.step_log_path:
            import pathlib  # noqa: PLC0415
            pathlib.Path(self.config.step_log_path).parent.mkdir(parents=True, exist_ok=True)
            self._step_log = open(self.config.step_log_path, "a")  # noqa: SIM115

        self._recorder = None
        if self.config.record_video:
            from fusiontest.recording.recorder import Recorder, RecordingConfig
            self._recorder = Recorder(
                platform=getattr(adapter, "_platform", "unknown"),
                config=RecordingConfig(output_dir=self.config.video_output_dir),
            )

    def run(
        self,
        goals: list[str],
        name: str = "FusionTest Run",
        platform: str = "unknown",
        locale: str = "en-US",
        url: str = "",
        goal_urls: list[str | None] | None = None,
        on_goal_done: Callable[[int, int, StepResult], None] | None = None,
        cancel_event: threading.Event | None = None,
    ) -> RunResult:
        """Run all goals sequentially.

        Args:
            on_goal_done: Optional callback invoked after *each* goal completes.
                          Receives (goal_index_1based, total_goals, step_result).
                          Use this for real-time progress reporting (e.g. flush to DB).
            cancel_event: Optional ``threading.Event`` used to cooperatively stop
                          the run from another thread. Checked before each goal
                          iteration. When set, the run returns early with
                          ``result.cancelled = True`` and the goals completed so
                          far preserved.
        """
        run_start = time.time()
        result = RunResult(name=name, platform=platform, locale=locale, success=True, url=url)

        if self._recorder:
            try:
                self._recorder.start(getattr(self.adapter, "_driver", self.adapter))
            except Exception as e:
                logger.warning(f"Could not start recorder: {e}")

        logger.info(f"Starting run: {name} ({len(goals)} goals)")

        # Resolve {{VAR}} placeholders before any goal is executed or logged.
        # resolved_goals — contain real values, used for execution only (never stored).
        # safe_goals     — values replaced with ***, safe for DB / logs / reports.
        resolved_goals, resolver = resolve_goals(goals, self.config.secrets)
        safe_goals = [resolver.redact(g) for g in resolved_goals]

        # Fail fast if any {{VAR}} could not be resolved — the LLM would
        # otherwise type the literal placeholder text into the UI.
        if resolver.unresolved_vars:
            missing = ", ".join(sorted(f"{{{{{v}}}}}" for v in resolver.unresolved_vars))
            raise ValueError(
                f"Unresolved secret variable(s): {missing}\n\n"
                f"Fix one of:\n"
                f"  1. Set the environment variable(s):  export EMAIL=your@email.com\n"
                f"  2. Add them to fusiontest.config.yaml under 'secrets:'\n"
                f"  3. Add them in the dashboard under Settings → Test Secrets\n\n"
                f"See: https://docs.fusiontest.fusionleap.io/secrets"
            )

        for i, (goal, safe_goal) in enumerate(zip(resolved_goals, safe_goals, strict=True), 1):
            # Cooperative cancellation check — run before starting the next goal
            # so the user sees partial results preserved in the dashboard.
            if cancel_event is not None and cancel_event.is_set():
                logger.info(f"Run cancelled by request before goal {i}/{len(goals)}")
                result.cancelled = True
                result.success = False
                break

            goal_url = (goal_urls[i - 1] if goal_urls and i - 1 < len(goal_urls) else None) or url
            logger.info(f"Goal {i}/{len(goals)}: {safe_goal}" + (f" [{goal_url}]" if goal_url else ""))

            # ── Per-goal watchdog ──────────────────────────────────────────────
            # If a single Playwright call wedges (e.g., selector timeout with
            # auto-retry, stuck network request, hanging JS dialog), the runner
            # has no way to notice. When the timer fires we force-close the
            # adapter which causes any in-flight Playwright call to throw — the
            # exception handlers in _run_goal then unwind and return a
            # StepResult with an error. The cancel_event flip aborts the rest
            # of the run.
            watchdog_fired = threading.Event()
            watchdog: threading.Timer | None = None
            if self.config.max_goal_seconds and self.config.max_goal_seconds > 0:
                # Bind loop-scoped values as default args so the closure
                # captures this iteration's state (rather than whatever happens
                # to be in scope if the timer fires during the next loop).
                def _on_timeout(
                    fired: threading.Event = watchdog_fired,
                    goal_num: int = i,
                    total_goals: int = len(goals),
                    limit: int = self.config.max_goal_seconds,
                ) -> None:
                    logger.error(
                        "Goal %d/%d exceeded %ds — force-aborting run",
                        goal_num, total_goals, limit,
                    )
                    fired.set()
                    if cancel_event is not None:
                        cancel_event.set()
                    try:
                        self.adapter.stop()
                    except Exception as stop_exc:  # noqa: BLE001
                        logger.debug("Adapter stop during watchdog raised: %s", stop_exc)

                watchdog = threading.Timer(self.config.max_goal_seconds, _on_timeout)
                watchdog.daemon = True
                watchdog.start()

            try:
                step_result = self._run_goal(goal, safe_goal=safe_goal, navigate_url=goal_url, resolver=resolver)
            finally:
                if watchdog is not None:
                    watchdog.cancel()

            # If the watchdog actually fired, record a clear timeout reason on
            # the step so the UI can show "goal_timeout" rather than whatever
            # generic Playwright error bubbled up. Also force-abort the rest of
            # the run since the adapter has been stopped and all subsequent
            # goals would fail instantly anyway.
            goal_timed_out = watchdog_fired.is_set()
            if goal_timed_out:
                step_result.success = False
                step_result.error = (
                    f"goal_timeout: exceeded {self.config.max_goal_seconds}s wall-clock limit"
                )
            result.steps.append(step_result)

            if not step_result.success:
                result.success = False
                logger.warning(f"Goal failed: {goal} — {step_result.error}")

            self.guardrails.reset_step()

            if on_goal_done is not None:
                try:
                    on_goal_done(i, len(goals), step_result)
                except Exception as cb_exc:  # noqa: BLE001
                    logger.warning("on_goal_done callback raised: %s", cb_exc)

            # Watchdog closed the adapter — no point attempting further goals.
            if goal_timed_out:
                result.cancelled = True
                result.success = False
                logger.error(
                    "Aborting remaining %d goal(s) after per-goal timeout",
                    len(goals) - i,
                )
                break

        if self._recorder:
            try:
                video_path = self._recorder.stop()
                if video_path:
                    result.video_path = str(video_path)
            except Exception as e:
                logger.warning(f"Could not stop recorder: {e}")

        result.total_duration_seconds = time.time() - run_start
        logger.info(
            f"Run complete: {'PASS' if result.success else 'FAIL'} "
            f"(stability={result.stability_score:.1%}, "
            f"duration={result.total_duration_seconds:.1f}s)"
        )

        return result

    def _run_goal(
        self,
        goal: str,
        safe_goal: str = "",
        navigate_url: str = "",
        resolver: SecretResolver | None = None,
    ) -> StepResult:
        start = time.time()
        # safe_goal has secrets replaced with *** — use for all storage/display.
        # goal has real values — used only for LLM prompts (never stored).
        _safe = safe_goal or goal
        step = StepResult(goal=_safe, success=False, steps_taken=0)
        history: list[str] = []

        def _redact(text: str) -> str:
            """Redact sensitive values from action strings before storing."""
            return resolver.redact(text) if resolver else text

        # Navigate to the goal's URL before starting (if provided)
        if navigate_url and hasattr(self.adapter, "navigate"):
            try:
                self.adapter.navigate(navigate_url)
                logger.info(f"  Navigated to: {navigate_url}")
            except Exception as e:
                logger.warning(f"  Navigation failed: {e}")

        for step_num in range(1, self.config.max_steps_per_goal + 1):
            step.steps_taken = step_num

            # Brief pause to let the page render after previous action
            if step_num > 1:
                time.sleep(0.8)

            # 1. Read the screen
            try:
                elements, screen_text = self.adapter.get_screen()
            except Exception as e:
                step.error = f"screen_read_error: {e}"
                break

            # NOTE: We record the screen hash AFTER the model decides, not
            # before. This prevents observation/verification goals from
            # triggering screen loop detection when the page doesn't change.

            # Log interactive element count for diagnostics
            interactive = [e for e in elements if e.is_interactive()]
            if step_num == 1:
                logger.info(f"  Screen: {len(elements)} total, {len(interactive)} interactive elements")
                for el in interactive[:10]:
                    logger.info(f"    {el.to_token()}")

            # Capture screenshot if configured
            if self.config.screenshot_on_every_step:
                try:
                    step.screenshots.append(self.adapter.get_screenshot())
                except Exception:
                    pass

            # 2. Ask the model for the best action.
            # Token optimization: we no longer run the verifier before every
            # step. The action model's "done" action already signals goal
            # completion (see 4a below), so the per-step verifier was a
            # redundant LLM call that doubled token use. The verifier still
            # runs once at max_steps_exceeded (the `else` branch of this
            # for-loop) as a last-chance rescue.
            actions = self.model.predict(
                screen_text=screen_text,
                goal=goal,
                history=history,
                invalid_actions=self.guardrails.get_invalid_actions(),
            )
            step.token_usage += getattr(self.model, "last_token_usage", TokenUsage())

            executed = False
            goal_done_by_model = False
            for action in actions:
                # 4a. Handle "done" action — model says goal is already achieved
                if action.action_type == "done":
                    logger.info(f"  Model signals goal complete: {action.reasoning}")
                    action_str = _redact(f"done: {action.reasoning}")
                    step.actions.append(action_str)
                    step.success = True
                    goal_done_by_model = True
                    self._write_step_log(_safe, screen_text, action_str, "success")
                    break

                # 4b. Run through guardrails
                gr = self.guardrails.check(action, elements, screen_text)

                if gr.should_backtrack:
                    logger.info(f"  Backtracking (step {step_num})")
                    self._backtrack(history)
                    break

                if gr.should_skip:
                    logger.debug(f"  Skipping action: {action} ({gr.reason})")
                    continue

                # 5. Execute the action
                success = self.adapter.execute(gr.action, elements)
                if success:
                    action_str = str(gr.action)
                    history.append(action_str)          # LLM context — real value ok
                    safe_action_str = _redact(action_str)
                    step.actions.append(safe_action_str)  # stored — secrets masked
                    self.guardrails.record_action(gr.action)
                    # Only record screen hash for actions that change the page.
                    # Scroll doesn't change DOM extraction (all elements captured
                    # regardless of viewport), so recording it causes false loops.
                    if gr.action.action_type not in ("scroll", "wait"):
                        self.guardrails.record_screen(screen_text)
                    logger.info(f"  Step {step_num}: {safe_action_str}")
                    executed = True
                    self._write_step_log(_safe, screen_text, safe_action_str, "success")
                    break
                else:
                    self._write_step_log(_safe, screen_text, _redact(str(action)), "failure")

            if goal_done_by_model:
                break

            if not executed:
                logger.warning(f"  No valid action found at step {step_num}")

        else:
            # Max steps reached without the model emitting "done". Before
            # giving up, run the verifier once on the final screen — this is
            # the only verifier call in the optimized flow and catches cases
            # where the goal is actually complete but the model failed to
            # recognize it. Token cost: ~1 small LLM call per failed goal,
            # versus ~max_steps verifier calls in the old flow.
            try:
                _, final_screen_text = self.adapter.get_screen()
            except Exception:
                final_screen_text = screen_text  # fall back to last known screen

            try:
                if self.verifier.is_complete(goal, final_screen_text, history):
                    step.success = True
                    step.error = None
                    logger.info(
                        f"  Goal verified complete at max_steps "
                        f"({self.config.max_steps_per_goal}) — last-chance check passed"
                    )
                else:
                    step.error = f"max_steps_exceeded ({self.config.max_steps_per_goal})"
            except Exception as exc:  # noqa: BLE001
                logger.warning(f"Last-chance verifier failed: {exc}")
                step.error = f"max_steps_exceeded ({self.config.max_steps_per_goal})"
            step.token_usage += getattr(self.verifier, "last_token_usage", TokenUsage())

        if not step.success and self.config.screenshot_on_failure:
            try:
                step.screenshots.append(self.adapter.get_screenshot())
            except Exception:
                pass

        step.duration_seconds = time.time() - start
        return step

    def _write_step_log(
        self, goal: str, screen_text: str, action: str, outcome: str
    ) -> None:
        if not self._step_log:
            return
        import json
        self._step_log.write(json.dumps({
            "goal": goal,
            "screen_text": screen_text,
            "action": action,
            "outcome": outcome,
        }) + "\n")
        self._step_log.flush()

    def _backtrack(self, history: list[str]) -> None:
        """Undo the last action (platform-specific — adapter should implement back)."""
        if history:
            history.pop()
        try:
            from fusiontest.core.action_model import Action
            back_action = Action(action_type="back", element_index=None, element_label="")
            self.adapter.execute(back_action, [])
        except Exception as e:
            logger.warning(f"Backtrack failed: {e}")
