"""OTel / W3C Trace Context propagation. Pass a traceparent through the SDK
and verify hostd attaches it to request spans."""

import os
import subprocess
import time
import uuid

import httpx
import pytest

from podflare import Sandbox
from podflare.client import Client


def _hostd_up() -> bool:
    try:
        return Client().healthz()
    except (httpx.HTTPError, OSError):
        return False


pytestmark = pytest.mark.skipif(not _hostd_up(), reason="hostd not running")


def _journal_tail(lines: int = 200) -> str:
    """Ssh into the Hetzner host and grab the last N hostd log lines. Used
    only by tests that verify hostd-side span/field output."""
    key = os.path.expanduser("~/.ssh/podflare_ed25519")
    try:
        r = subprocess.run(
            [
                "ssh",
                "-o", "BatchMode=yes",
                "-i", key,
                "root@157.180.107.158",
                f"journalctl -u podflare-hostd --no-pager -n {lines}",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return r.stdout
    except Exception:
        return ""


# Unique trace per test run so we don't false-positive on logs from earlier
# runs still in the journal.
TRACE = uuid.uuid4().hex  # 32 hex
SPAN = uuid.uuid4().hex[:16]  # 16 hex
TP = f"00-{TRACE}-{SPAN}-01"


def test_traceparent_is_forwarded_as_header():
    """SDK with traceparent produces a matching `traceparent` header on the
    exec HTTP call. Verify by inspecting hostd journal logs for the trace_id
    field on the request span."""
    with Sandbox(traceparent=TP) as s:
        r = s.run_code("print('hello traceparent')")
    assert r.stdout.strip() == "hello traceparent"

    # Wait a beat for journald to flush, then fetch recent hostd log.
    time.sleep(1.0)
    log = _journal_tail(lines=400)
    # hostd's MakeSpan attaches the trace_id field to the request span; with
    # the default text formatter it renders as `http_request{... trace_id=<hex> ...}`.
    assert TRACE in log, (
        f"trace_id {TRACE!r} not seen in last 400 hostd log lines. "
        f"Tail:\n{log[-2000:]}"
    )


def test_no_traceparent_defaults_to_empty_field():
    with Sandbox() as s:
        r = s.run_code("print(1)")
    assert r.exit_code == 0
    # No assertion on the log — just verify the absent-traceparent path
    # doesn't break anything.


def test_env_var_traceparent(monkeypatch):
    monkeypatch.setenv("PODFLARE_TRACEPARENT", TP)
    client = Client()
    assert client.traceparent == TP
    monkeypatch.delenv("PODFLARE_TRACEPARENT")
