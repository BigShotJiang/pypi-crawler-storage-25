"""Full fork -> diff -> merge_into flow."""

import httpx
import pytest

from podflare import Sandbox
from podflare.client import Client


def _fork_supported() -> bool:
    try:
        client = Client()
        if not client.healthz():
            return False
        sid = client.create_sandbox()
        try:
            client.fork_sandbox(sid, 1)
            return True
        except httpx.HTTPError:
            return False
        finally:
            client.destroy_sandbox(sid)
    except (httpx.HTTPError, OSError):
        return False


pytestmark = pytest.mark.skipif(
    not _fork_supported(), reason="hostd not running or executor doesn't support fork"
)


def test_diff_detects_divergent_writes():
    with Sandbox() as parent:
        a, b = parent.fork(n=2)
        try:
            a.run_code("echo from-a > /root/a.txt", language="bash")
            b.run_code("echo from-b > /root/b.txt", language="bash")
            d = a.diff(b)
            assert "/root/a.txt" in d["removed"], f"expected a.txt in removed: {d}"
            assert "/root/b.txt" in d["added"], f"expected b.txt in added: {d}"
        finally:
            a.close()
            b.close()


def test_merge_into_winner_becomes_parent():
    with Sandbox() as parent:
        # Establish a known state in parent so we can tell merge succeeded.
        parent.run_code("echo parent-only > /root/parent.txt", language="bash")
        [winner] = parent.fork(n=1)
        # winner diverges from parent
        winner.run_code("echo winner-state > /root/winner.txt && rm /root/parent.txt", language="bash")

        # Before merge: parent still has parent.txt, no winner.txt
        pre = parent.run_code("ls /root/", language="bash").stdout
        assert "parent.txt" in pre
        assert "winner.txt" not in pre

        parent.merge_into(winner)

        # After merge: parent.id now reflects winner's state
        post = parent.run_code("ls /root/", language="bash").stdout
        assert "winner.txt" in post, f"expected winner.txt in parent post-merge: {post!r}"
        assert "parent.txt" not in post, f"parent.txt should have been removed: {post!r}"

        # winner is defunct; close() is a no-op, don't double-destroy.
        winner.close()
