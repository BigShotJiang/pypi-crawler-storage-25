"""Bearer-token auth paths."""

import httpx
import pytest

from podflare import Sandbox
from podflare.client import Client


def _hostd_up() -> bool:
    try:
        return Client().healthz()
    except (httpx.HTTPError, OSError):
        return False


def _auth_enforced() -> bool:
    """True if hostd rejects unauthenticated /v1/sandboxes requests."""
    if not _hostd_up():
        return False
    try:
        r = httpx.post("http://127.0.0.1:7070/v1/sandboxes", json={}, timeout=5)
        return r.status_code == 401
    except httpx.HTTPError:
        return False


pytestmark = pytest.mark.skipif(not _hostd_up(), reason="hostd not running")


def test_healthz_is_public():
    """Healthz never requires auth."""
    r = httpx.get("http://127.0.0.1:7070/v1/healthz", timeout=5)
    assert r.status_code == 200
    assert r.text.strip() == "ok"


def test_client_sets_authorization_header():
    """When api_key is set, Client adds `Authorization: Bearer <key>`
    as a default header on every request."""
    client = Client(api_key="pk_test_client_header")
    assert client.api_key == "pk_test_client_header"
    assert client._http.headers.get("authorization") == "Bearer pk_test_client_header"


def test_env_var_api_key(monkeypatch):
    monkeypatch.setenv("PODFLARE_API_KEY", "pk_from_env")
    client = Client()
    assert client.api_key == "pk_from_env"


@pytest.mark.skipif(not _auth_enforced(), reason="hostd auth disabled (dev mode)")
def test_missing_key_rejected_when_auth_enforced():
    r = httpx.post("http://127.0.0.1:7070/v1/sandboxes", json={}, timeout=5)
    assert r.status_code == 401
    assert "error" in r.json()


@pytest.mark.skipif(not _auth_enforced(), reason="hostd auth disabled (dev mode)")
def test_wrong_key_rejected_when_auth_enforced():
    r = httpx.post(
        "http://127.0.0.1:7070/v1/sandboxes",
        json={},
        headers={"authorization": "Bearer pk_wrong"},
        timeout=5,
    )
    assert r.status_code == 401


def test_end_to_end_with_key_when_auth_enforced():
    """If auth is enforced, a Client with the right key should succeed.
    If auth is disabled, no-key also succeeds (dev mode). Either way, a
    Sandbox() should work as long as the SDK env/config lines up."""
    with Sandbox() as s:
        r = s.run_code("print(1+1)")
        assert r.exit_code == 0
        assert r.stdout.strip() == "2"
