"""Upload/download round-trip."""

import hashlib
import os

import httpx
import pytest

from podflare import Sandbox
from podflare.client import Client


def _hostd_up() -> bool:
    try:
        return Client().healthz()
    except (httpx.HTTPError, OSError):
        return False


pytestmark = pytest.mark.skipif(not _hostd_up(), reason="hostd not running")


def test_upload_download_text():
    with Sandbox() as s:
        s.upload(b"hello, world\nline two\n", "/root/hello.txt")
        got = s.download("/root/hello.txt")
        assert got == b"hello, world\nline two\n"


def test_upload_download_binary_roundtrip():
    # 256 KB of random-ish binary data (enough to exercise the base64 path).
    payload = os.urandom(256 * 1024)
    expected_sha = hashlib.sha256(payload).hexdigest()
    with Sandbox() as s:
        s.upload(payload, "/tmp/blob.bin")
        # Cross-check via in-VM sha256sum so we know upload wasn't lossy.
        # `cut` is in coreutils (always present); `awk` is not on the minimal rootfs.
        r = s.run_code("sha256sum /tmp/blob.bin | cut -d' ' -f1", language="bash")
        assert r.exit_code == 0
        assert r.stdout.strip() == expected_sha
        got = s.download("/tmp/blob.bin")
    assert got == payload
    assert hashlib.sha256(got).hexdigest() == expected_sha


def test_upload_creates_intermediate_dirs():
    with Sandbox() as s:
        s.upload(b"deep", "/root/a/b/c/nested.txt")
        r = s.run_code("cat /root/a/b/c/nested.txt", language="bash")
        assert r.stdout.strip() == "deep"
