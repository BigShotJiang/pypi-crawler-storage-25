"""Persistent Python REPL tests. State should survive across run_code calls."""

import httpx
import pytest

from podflare import Sandbox
from podflare.client import Client


def _hostd_up() -> bool:
    try:
        return Client().healthz()
    except (httpx.HTTPError, OSError):
        return False


pytestmark = pytest.mark.skipif(not _hostd_up(), reason="hostd not running")


def test_python_variable_persists_across_calls():
    with Sandbox() as s:
        r1 = s.run_code("x = 42; print('set')")
        assert r1.exit_code == 0
        assert "set" in r1.stdout
        r2 = s.run_code("print(x * 2)")
        assert r2.exit_code == 0
        assert r2.stdout.strip() == "84"


def test_python_import_persists_across_calls():
    with Sandbox() as s:
        r1 = s.run_code("import json; payload = {'a': 1}")
        assert r1.exit_code == 0
        # next call doesn't re-import; uses the already-loaded module
        r2 = s.run_code("print(json.dumps(payload))")
        assert r2.exit_code == 0
        assert r2.stdout.strip() == '{"a": 1}'


def test_python_exception_doesnt_poison_repl():
    with Sandbox() as s:
        r1 = s.run_code("1 / 0")
        assert r1.exit_code == 1
        assert "ZeroDivisionError" in r1.stderr
        # REPL should still work for subsequent calls
        r2 = s.run_code("print('alive')")
        assert r2.exit_code == 0
        assert r2.stdout.strip() == "alive"


def test_bash_still_uses_fresh_subprocess():
    """bash intentionally runs in a fresh subprocess (not a REPL), so shell
    variables do NOT persist across run_code calls."""
    with Sandbox() as s:
        s.run_code("X=hello", language="bash")
        r = s.run_code("echo ${X:-unset}", language="bash")
        assert r.stdout.strip() == "unset"


def test_fork_inherits_parent_repl_state():
    """The headline combo: set state in parent, fork, each child starts with
    that state already loaded in their Python REPL."""
    with Sandbox() as parent:
        parent.run_code("shared_config = {'model': 'gpt-5', 'temperature': 0.7}")
        parent.run_code("import json")
        children = parent.fork(n=3)
        try:
            for child in children:
                r = child.run_code("print(json.dumps(shared_config, sort_keys=True))")
                assert r.exit_code == 0
                assert r.stdout.strip() == '{"model": "gpt-5", "temperature": 0.7}'
        finally:
            for c in children:
                c.close()
