"""Per-sandbox event replay (ring buffer)."""

import httpx
import pytest

from podflare import Sandbox
from podflare.client import Client


def _hostd_up() -> bool:
    try:
        return Client().healthz()
    except (httpx.HTTPError, OSError):
        return False


pytestmark = pytest.mark.skipif(not _hostd_up(), reason="hostd not running")


def test_replay_before_any_exec_is_empty():
    with Sandbox() as s:
        events = s.replay()
    assert events == []


def test_replay_captures_stdout_and_exit():
    with Sandbox() as s:
        s.run_code("print(1); print(2); print(3)")
        events = s.replay()
    types = [e.type for e in events]
    # The exec marker (stderr) + three stdout lines + exit
    assert types.count("stdout") >= 3
    assert types[-1] == "exit"
    stdout_payloads = [e.data for e in events if e.type == "stdout"]
    assert stdout_payloads[-3:] == ["1", "2", "3"]


def test_replay_accumulates_across_exec_calls():
    with Sandbox() as s:
        s.run_code("print('first')")
        s.run_code("print('second')")
        events = s.replay()
    stdouts = [e.data for e in events if e.type == "stdout"]
    assert "first" in stdouts and "second" in stdouts


def test_replay_ring_buffer_bounded_at_1000():
    """Blast past the buffer cap; the oldest entries should be dropped."""
    with Sandbox() as s:
        # Produce ~1200 stdout lines in one exec. That's enough to push out
        # anything earlier. Implementation caps at 1000 per sandbox.
        s.run_code("for i in range(1200): print(i)")
        events = s.replay()
    assert len(events) <= 1000
    # Newest should still be present (the exit event is always last).
    types = [e.type for e in events]
    assert types[-1] == "exit"
