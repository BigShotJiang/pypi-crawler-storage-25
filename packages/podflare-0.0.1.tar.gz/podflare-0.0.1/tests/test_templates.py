"""Seed-tree templates. Verify `Sandbox(template=...)` draws from the right
pool and inherits the template's pre-imported REPL state."""

import httpx
import pytest

from podflare import Sandbox
from podflare.client import Client


def _hostd_up() -> bool:
    try:
        return Client().healthz()
    except (httpx.HTTPError, OSError):
        return False


def _template_exists(name: str) -> bool:
    if not _hostd_up():
        return False
    client = Client()
    try:
        sid = client.create_sandbox(template=name)
        client.destroy_sandbox(sid)
        return True
    except httpx.HTTPError:
        return False
    finally:
        client.close()


pytestmark = pytest.mark.skipif(not _hostd_up(), reason="hostd not running")


def test_default_template_still_works():
    with Sandbox() as s:
        r = s.run_code("print(1 + 1)")
        assert r.stdout.strip() == "2"


def test_unknown_template_is_rejected():
    with pytest.raises(httpx.HTTPStatusError) as exc:
        Sandbox(template="does-not-exist-ever-123")
    assert exc.value.response.status_code == 500


@pytest.mark.skipif(
    not _template_exists("python-datasci"),
    reason="python-datasci template not built; run scripts/build-template.sh",
)
def test_python_datasci_inherits_repl_state():
    """The template's build script imported pandas/numpy/scipy/matplotlib and
    stored their versions in a `VERSIONS` dict. Every VM in that pool
    should see those names without having to re-run the init code."""
    with Sandbox(template="python-datasci") as s:
        r = s.run_code("print(sorted(VERSIONS.keys()))")
        assert r.exit_code == 0
        assert r.stdout.strip() == "['matplotlib', 'numpy', 'pandas', 'scipy']"


@pytest.mark.skipif(
    not _template_exists("python-datasci"),
    reason="python-datasci template not built",
)
def test_python_datasci_pandas_is_preimported():
    """pd.DataFrame should work in a fresh sandbox without an explicit import."""
    with Sandbox(template="python-datasci") as s:
        r = s.run_code("print(pd.DataFrame({'x': [1, 2, 3]}).shape)")
        assert r.exit_code == 0
        assert r.stdout.strip() == "(3, 1)"


@pytest.mark.skipif(
    not _template_exists("python-datasci"),
    reason="python-datasci template not built",
)
def test_fork_from_template_child_inherits_too():
    """Template state → pool VM → fork child chain preserves all memory."""
    with Sandbox(template="python-datasci") as parent:
        parent.run_code("tenant = 'acme'")
        children = parent.fork(n=2)
        try:
            for c in children:
                r = c.run_code(
                    "print('pandas' in VERSIONS, tenant, pd.DataFrame({'a':[1]}).shape)"
                )
                assert r.exit_code == 0
                assert r.stdout.strip() == "True acme (1, 1)"
        finally:
            for c in children:
                c.close()
