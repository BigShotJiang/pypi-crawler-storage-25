"""Fork wedge test: pause parent, spawn N children from current state, each
runs distinct code. Skips if hostd isn't running or isn't using a fork-capable
executor (SubprocessExecutor returns 500 on /fork)."""

import httpx
import pytest

from podflare import Sandbox
from podflare.client import Client


def _hostd_up() -> bool:
    try:
        return Client().healthz()
    except (httpx.HTTPError, OSError):
        return False


def _fork_supported() -> bool:
    """Probe a throwaway sandbox to see if the backend supports fork."""
    if not _hostd_up():
        return False
    client = Client()
    try:
        sid = client.create_sandbox()
        try:
            client.fork_sandbox(sid, 1)
            return True
        except httpx.HTTPError:
            return False
        finally:
            client.destroy_sandbox(sid)
    finally:
        client.close()


pytestmark = pytest.mark.skipif(
    not _fork_supported(), reason="hostd not running or executor doesn't support fork"
)


def test_fork_n_children():
    with Sandbox() as parent:
        children = parent.fork(n=5)
        assert len(children) == 5
        ids = {c.id for c in children}
        assert len(ids) == 5  # all distinct
        assert parent.id not in ids

        try:
            # Each child runs distinct code; results should be independent.
            results = [c.run_code(f"print({i} * 111)") for i, c in enumerate(children)]
            for i, r in enumerate(results):
                assert r.exit_code == 0
                assert r.stdout.strip() == str(i * 111)
        finally:
            for c in children:
                c.close()


def test_fork_parent_survives_and_remains_usable():
    with Sandbox() as parent:
        # First run in parent establishes it works.
        r1 = parent.run_code("print(1 + 1)")
        assert r1.stdout.strip() == "2"

        children = parent.fork(n=2)
        try:
            # Parent still usable after fork.
            r2 = parent.run_code("print(7 * 7)")
            assert r2.exit_code == 0
            assert r2.stdout.strip() == "49"

            # Children work too.
            for c in children:
                assert c.run_code("print('hi from child')").stdout.strip() == "hi from child"
        finally:
            for c in children:
                c.close()
