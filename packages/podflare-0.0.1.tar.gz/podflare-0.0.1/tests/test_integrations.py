"""Shape tests for the framework adapters. No real LLM calls — we just verify
the factories produce the right shape and the execute callback runs against
a live Podflare hostd.
"""

import httpx
import pytest

from podflare import Sandbox
from podflare.client import Client


def _hostd_up() -> bool:
    try:
        return Client().healthz()
    except (httpx.HTTPError, OSError):
        return False


pytestmark = pytest.mark.skipif(not _hostd_up(), reason="hostd not running")


def test_anthropic_code_execution_helper_shape():
    """Given a fake tool_use block, we run it and produce a valid tool_result."""
    from podflare.integrations.anthropic import handle_code_execution_tool_use

    tool_use_block = {
        "type": "tool_use",
        "id": "toolu_fake_123",
        "name": "code_execution",
        "input": {"code": "print(6 * 7)"},
    }
    with Sandbox() as sbx:
        result = handle_code_execution_tool_use(tool_use_block, sbx)

    assert result["type"] == "tool_result"
    assert result["tool_use_id"] == "toolu_fake_123"
    assert result["is_error"] is False
    assert len(result["content"]) == 1
    text = result["content"][0]["text"]
    assert "42" in text  # 6*7 in stdout
    assert "exit_code: 0" in text


def test_anthropic_handles_nonzero_exit():
    from podflare.integrations.anthropic import handle_code_execution_tool_use

    tool_use_block = {
        "id": "toolu_x",
        "input": {"code": "import sys; sys.exit(2)"},
    }
    with Sandbox() as sbx:
        result = handle_code_execution_tool_use(tool_use_block, sbx)
    assert result["is_error"] is True
    assert "exit_code: 2" in result["content"][0]["text"]


def test_openai_agents_adapter_skips_if_not_installed():
    """The adapter should raise a clear ImportError when openai-agents isn't
    installed (it isn't in this test env)."""
    try:
        import agents  # noqa: F401

        installed = True
    except ImportError:
        installed = False

    from podflare.integrations.openai_agents import podflare_code_interpreter

    if not installed:
        with pytest.raises(ImportError, match="openai-agents"):
            podflare_code_interpreter()
    else:
        tool = podflare_code_interpreter()
        assert hasattr(tool, "close_podflare_sandbox")
