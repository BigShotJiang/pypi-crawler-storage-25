"""End-to-end smoke test.

Requires `podflare-hostd` to be running on http://127.0.0.1:7070.
Skips if hostd is unreachable.
"""

import httpx
import pytest

from podflare import Sandbox
from podflare.client import Client


def _hostd_up() -> bool:
    try:
        return Client().healthz()
    except (httpx.HTTPError, OSError):
        return False


pytestmark = pytest.mark.skipif(not _hostd_up(), reason="hostd not running")


def test_python_hello_world():
    with Sandbox() as s:
        r = s.run_code("print(sum(range(10)))")
    assert r.exit_code == 0
    assert r.stdout.strip() == "45"


def test_python_stderr_capture():
    with Sandbox() as s:
        r = s.run_code(
            "import sys; print('out'); print('err', file=sys.stderr); sys.exit(2)"
        )
    assert r.exit_code == 2
    assert "out" in r.stdout
    assert "err" in r.stderr


def test_bash_exec():
    with Sandbox() as s:
        r = s.run_code("echo from-bash", language="bash")
    assert r.exit_code == 0
    assert r.stdout.strip() == "from-bash"


def test_streaming_yields_events_in_order():
    with Sandbox() as s:
        events = list(s.run_code_stream("for i in range(3): print(i)"))
    types = [e.type for e in events]
    assert types[-1] == "exit"
    stdout_data = [e.data for e in events if e.type == "stdout"]
    assert stdout_data == ["0", "1", "2"]
