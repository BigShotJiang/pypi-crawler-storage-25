from __future__ import annotations

import json
import os
from typing import Iterator

import httpx

from podflare.types import Event, Language

DEFAULT_HOST = "http://127.0.0.1:7070"


class Client:
    """Thin HTTP transport for the hostd contract.

    One Client per process is fine; it owns an httpx.Client.
    """

    def __init__(
        self,
        host: str | None = None,
        timeout: float = 30.0,
        traceparent: str | None = None,
        api_key: str | None = None,
    ):
        """
        Args:
            traceparent: W3C Trace Context string. Sent as `traceparent`
                header; also read from ``PODFLARE_TRACEPARENT`` env.
            api_key: Bearer token sent as ``Authorization: Bearer <key>`` on
                every request. Also read from ``PODFLARE_API_KEY`` env.
        """
        self.host = (host or os.environ.get("PODFLARE_HOST") or DEFAULT_HOST).rstrip("/")
        self.traceparent = traceparent or os.environ.get("PODFLARE_TRACEPARENT") or None
        self.api_key = api_key or os.environ.get("PODFLARE_API_KEY") or None
        default_headers: dict[str, str] = {}
        if self.traceparent:
            default_headers["traceparent"] = self.traceparent
        if self.api_key:
            default_headers["authorization"] = f"Bearer {self.api_key}"
        self._http = httpx.Client(
            base_url=self.host,
            timeout=timeout,
            headers=default_headers or None,
        )

    def close(self) -> None:
        self._http.close()

    def healthz(self) -> bool:
        r = self._http.get("/v1/healthz")
        return r.status_code == 200 and r.text.strip() == "ok"

    def create_sandbox(self, template: str | None = None) -> str:
        body = {"template": template} if template else {}
        r = self._http.post("/v1/sandboxes", json=body)
        r.raise_for_status()
        return r.json()["id"]

    def destroy_sandbox(self, sandbox_id: str) -> None:
        r = self._http.delete(f"/v1/sandboxes/{sandbox_id}")
        if r.status_code not in (200, 204):
            r.raise_for_status()

    def fork_sandbox(self, sandbox_id: str, n: int = 1) -> list[str]:
        r = self._http.post(
            f"/v1/sandboxes/{sandbox_id}/fork",
            json={"n": n},
            timeout=60.0,
        )
        r.raise_for_status()
        return r.json()["children"]

    def merge_into(self, parent_id: str, winner_id: str) -> None:
        r = self._http.post(f"/v1/sandboxes/{parent_id}/merge_into/{winner_id}")
        if r.status_code not in (200, 204):
            r.raise_for_status()

    def replay(self, sandbox_id: str) -> list[Event]:
        r = self._http.get(f"/v1/sandboxes/{sandbox_id}/replay")
        r.raise_for_status()
        events: list[Event] = []
        for line in r.text.splitlines():
            line = line.strip()
            if not line:
                continue
            events.append(Event.from_json(json.loads(line)))
        return events

    def exec_stream(
        self, sandbox_id: str, code: str, language: Language = "python"
    ) -> Iterator[Event]:
        body = {"code": code, "language": language}
        with self._http.stream("POST", f"/v1/sandboxes/{sandbox_id}/exec", json=body) as r:
            r.raise_for_status()
            for line in r.iter_lines():
                if not line:
                    continue
                yield Event.from_json(json.loads(line))
