from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

Language = Literal["python", "bash"]
EventType = Literal["stdout", "stderr", "exit"]


@dataclass
class Event:
    type: EventType
    data: str | int
    seq: int
    ts: int

    @classmethod
    def from_json(cls, obj: dict) -> "Event":
        return cls(type=obj["type"], data=obj["data"], seq=obj["seq"], ts=obj["ts"])


@dataclass
class ExecResult:
    stdout: str
    stderr: str
    exit_code: int

    @property
    def ok(self) -> bool:
        return self.exit_code == 0
