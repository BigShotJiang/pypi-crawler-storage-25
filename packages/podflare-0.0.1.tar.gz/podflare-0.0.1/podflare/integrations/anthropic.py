"""Anthropic `code_execution`-shaped helper.

Anthropic's server-side `code_execution` hosted tool has a specific request/
response shape. When you're *self-hosting* the execution (agent loops through
tool_use blocks locally), you can use this helper to execute a `code_execution`
tool_use block against a Podflare sandbox and produce the matching
`tool_result` block.

Example:

    from anthropic import Anthropic
    from podflare import Sandbox
    from podflare.integrations.anthropic import handle_code_execution_tool_use

    client = Anthropic()
    with Sandbox() as sbx:
        messages = [{"role": "user", "content": "What's sqrt(12345)?"}]
        while True:
            resp = client.messages.create(
                model="claude-opus-4-7",
                max_tokens=1024,
                tools=[{"type": "code_execution_20250825", "name": "code_execution"}],
                messages=messages,
            )
            messages.append({"role": "assistant", "content": resp.content})
            if resp.stop_reason != "tool_use":
                break
            tool_results = [
                handle_code_execution_tool_use(block, sbx)
                for block in resp.content
                if getattr(block, "type", None) == "tool_use"
                and getattr(block, "name", None) == "code_execution"
            ]
            messages.append({"role": "user", "content": tool_results})
"""

from __future__ import annotations

from typing import Any

from podflare import Sandbox


def handle_code_execution_tool_use(
    tool_use_block: Any, sandbox: Sandbox
) -> dict:
    """Execute a single `code_execution` tool_use block and return the
    corresponding tool_result dict.

    `tool_use_block` can be an Anthropic SDK object (with .id / .input
    attributes) or a plain dict (with ["id"] / ["input"] keys).
    """

    def _get(obj: Any, key: str, default: Any = None) -> Any:
        if isinstance(obj, dict):
            return obj.get(key, default)
        return getattr(obj, key, default)

    tool_use_id = _get(tool_use_block, "id")
    tool_input = _get(tool_use_block, "input", {}) or {}
    code = (
        tool_input.get("code", "") if isinstance(tool_input, dict) else ""
    )

    result = sandbox.run_code(code, language="python")
    content = (
        f"stdout:\n{result.stdout}\n"
        f"stderr:\n{result.stderr}\n"
        f"exit_code: {result.exit_code}"
    )
    return {
        "type": "tool_result",
        "tool_use_id": tool_use_id,
        "content": [{"type": "text", "text": content}],
        "is_error": result.exit_code != 0,
    }
