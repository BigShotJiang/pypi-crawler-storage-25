"""Framework adapters. Each submodule is independently importable and keeps
its upstream SDK as an optional dep (imported lazily inside factories)."""
