"""OpenAI Agents SDK adapter.

Exposes `podflare_code_interpreter()` which returns a `FunctionTool` you can
pass straight to an `Agent`. The sandbox is lazily created on first call and
reused across tool invocations within the same tool instance.

Example:

    from agents import Agent, Runner
    from podflare.integrations.openai_agents import podflare_code_interpreter

    agent = Agent(
        name="assistant",
        instructions="Use the run_code tool to answer data questions.",
        tools=[podflare_code_interpreter()],
    )

    result = await Runner.run(agent, "what is 111 * 111?")
    print(result.final_output)
"""

from __future__ import annotations

from typing import Any

from podflare import Sandbox


def podflare_code_interpreter(
    *, host: str | None = None, template: str | None = None
) -> Any:
    """Return an OpenAI Agents SDK tool that runs code in a Podflare sandbox.

    Args:
        host: Podflare hostd URL. Defaults to PODFLARE_HOST env var or
              http://127.0.0.1:7070.
        template: Sandbox template name (pool flavor). None = default.

    The returned tool accepts `code` (str) and optional `language` ("python"
    or "bash"). It returns a dict with keys `stdout`, `stderr`, and
    `exit_code`.

    The sandbox is lazy — not created until the first call. Call
    `.close_podflare_sandbox()` on the returned tool to destroy it.
    """
    try:
        from agents import function_tool  # type: ignore
    except ImportError as e:
        raise ImportError(
            "The OpenAI Agents SDK is not installed. "
            "Install it with `pip install openai-agents`."
        ) from e

    state: dict[str, Sandbox | None] = {"sandbox": None}

    def _ensure() -> Sandbox:
        if state["sandbox"] is None:
            state["sandbox"] = Sandbox(host=host, template=template)
        return state["sandbox"]  # type: ignore[return-value]

    @function_tool  # type: ignore[misc]
    def run_code(code: str, language: str = "python") -> dict:
        """Execute code in an isolated Firecracker-backed sandbox. Use
        'python' for Python or 'bash' for shell commands. Returns
        {stdout, stderr, exit_code}. State does NOT persist across calls
        in v0 — each call runs a fresh subprocess.
        """
        sbx = _ensure()
        r = sbx.run_code(code, language=language)
        return {
            "stdout": r.stdout,
            "stderr": r.stderr,
            "exit_code": r.exit_code,
        }

    # Attach a cleanup hook the caller can invoke after their agent run.
    def _close() -> None:
        if state["sandbox"] is not None:
            state["sandbox"].close()  # type: ignore[union-attr]
            state["sandbox"] = None

    run_code.close_podflare_sandbox = _close  # type: ignore[attr-defined]
    return run_code
