"""JWT authentication for the Sygen API server.

Provides JWT-based multi-user authentication with username/password login.
Users are stored in ``~/.sygen/users.json`` with PBKDF2-hashed passwords.

Roles: admin (full access), operator (read + run tasks/crons),
viewer (read-only).  Each user can be restricted to specific agents
via the ``allowed_agents`` field (empty list = all agents).
"""

from __future__ import annotations

import base64
import functools
import hashlib
import hmac
import json
import logging
import os
import secrets
import struct
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

import jwt
from aiohttp import web

if TYPE_CHECKING:
    from collections.abc import Callable, Coroutine

    from sygen_bot.config import ApiConfig

logger = logging.getLogger(__name__)

# Defaults (overridable via config)
_ACCESS_TOKEN_EXPIRES = 15 * 60  # 15 min
_REFRESH_TOKEN_EXPIRES = 30 * 24 * 3600  # 30 d
_ALGORITHM = "HS256"

# Temp token expiry for 2FA flow (5 minutes)
_TEMP_TOKEN_EXPIRES = 5 * 60

# Paths that never require auth
_PUBLIC_PATHS = frozenset({
    "/health",
    "/api/auth/login",
    "/api/auth/refresh",
    "/api/auth/2fa/login",
})

# Role hierarchy: higher index = more privileges
ROLE_LEVELS = {"viewer": 0, "operator": 1, "admin": 2}

# Rate limiting defaults
_RATE_LIMIT_WINDOW = 60  # seconds
_RATE_LIMIT_MAX = 5  # max attempts per window

# Persistent paths
_SYGEN_DIR = Path(os.environ.get("SYGEN_HOME", Path.home() / ".sygen"))
_JWT_SECRET_PATH = _SYGEN_DIR / ".jwt_secret"
_JWT_BLACKLIST_PATH = _SYGEN_DIR / ".jwt_blacklist.json"
_USERS_PATH = _SYGEN_DIR / "users.json"
_AUDIT_LOG_PATH = _SYGEN_DIR / "audit.log"

# Max audit log size before rotation
_AUDIT_MAX_LINES = 10_000


# ---------------------------------------------------------------------------
# Password hashing (PBKDF2-SHA256, stdlib only)
# ---------------------------------------------------------------------------

def hash_password(password: str) -> str:
    """Hash a password with PBKDF2-SHA256. Returns 'salt:hash' hex string."""
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 260_000)
    return f"{salt}:{dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    """Verify a password against a 'salt:hash' string."""
    if ":" not in stored:
        return False
    salt, expected = stored.split(":", 1)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 260_000)
    return hmac.compare_digest(dk.hex(), expected)


# ---------------------------------------------------------------------------
# TOTP (RFC 6238, stdlib only)
# ---------------------------------------------------------------------------

def generate_totp_secret() -> str:
    """Generate a 160-bit base32-encoded TOTP secret."""
    raw = secrets.token_bytes(20)  # 160 bits
    return base64.b32encode(raw).decode("ascii")


def _hotp(secret_b32: str, counter: int) -> str:
    """Generate a 6-digit HOTP code (RFC 4226)."""
    key = base64.b32decode(secret_b32, casefold=True)
    msg = struct.pack(">Q", counter)
    h = hmac.new(key, msg, hashlib.sha1).digest()
    offset = h[-1] & 0x0F
    code = struct.unpack(">I", h[offset : offset + 4])[0] & 0x7FFFFFFF
    return str(code % 10**6).zfill(6)


def totp_code(secret_b32: str, *, now: float | None = None) -> str:
    """Generate the current TOTP code (30-second window, SHA1, 6 digits)."""
    t = int((now or time.time()) / 30)
    return _hotp(secret_b32, t)


def verify_totp(secret_b32: str, code: str, *, now: float | None = None) -> bool:
    """Verify a TOTP code allowing ±1 window drift."""
    t = int((now or time.time()) / 30)
    for offset in (-1, 0, 1):
        if hmac.compare_digest(_hotp(secret_b32, t + offset), code):
            return True
    return False


def build_otpauth_uri(username: str, secret_b32: str) -> str:
    """Build an otpauth:// URI for QR code generation."""
    return f"otpauth://totp/Sygen:{username}?secret={secret_b32}&issuer=Sygen"


# ---------------------------------------------------------------------------
# Users file management
# ---------------------------------------------------------------------------

def _read_users() -> list[dict[str, Any]]:
    """Read users from users.json. Returns empty list if missing."""
    try:
        data = json.loads(_USERS_PATH.read_text("utf-8"))
        return data.get("users", []) if isinstance(data, dict) else data
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return []


def _write_users(users: list[dict[str, Any]]) -> None:
    """Write users list to users.json atomically."""
    _USERS_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = _USERS_PATH.with_suffix(".tmp")
    tmp.write_text(
        json.dumps({"users": users}, indent=2, ensure_ascii=False),
        "utf-8",
    )
    tmp.replace(_USERS_PATH)
    try:
        os.chmod(_USERS_PATH, 0o600)
    except OSError:
        pass


def _find_user(username: str) -> dict[str, Any] | None:
    """Find a user by username."""
    for u in _read_users():
        if u.get("username") == username:
            return u
    return None


def _ensure_default_admin() -> None:
    """Create a default admin user if users.json is empty or missing."""
    users = _read_users()
    if users:
        return
    default = {
        "username": "admin",
        "password_hash": hash_password("admin"),
        "role": "admin",
        "display_name": "Administrator",
        "allowed_agents": [],
        "active": True,
        "created_at": time.time(),
    }
    _write_users([default])
    logger.info("Created default admin user (username=admin, password=admin)")


# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------

def write_audit(*, user: str, action: str, target: str = "", details: str = "") -> None:
    """Append an entry to the audit log. Rotates when exceeding _AUDIT_MAX_LINES."""
    ts = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
    line = json.dumps({
        "ts": ts,
        "user": user,
        "action": action,
        "target": target,
        "details": details,
    }, ensure_ascii=False)
    try:
        _AUDIT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with _AUDIT_LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
        # Rotate if over max lines
        _maybe_rotate_audit()
    except OSError:
        logger.warning("Could not write to audit log")


def _maybe_rotate_audit() -> None:
    """Keep only the last _AUDIT_MAX_LINES entries in the audit log."""
    try:
        lines = _AUDIT_LOG_PATH.read_text("utf-8").splitlines()
        if len(lines) <= _AUDIT_MAX_LINES:
            return
        # Keep last half of max to avoid rotating on every write
        keep = lines[-((_AUDIT_MAX_LINES * 3) // 4):]
        tmp = _AUDIT_LOG_PATH.with_suffix(".tmp")
        tmp.write_text("\n".join(keep) + "\n", "utf-8")
        tmp.replace(_AUDIT_LOG_PATH)
        logger.info("Rotated audit log: %d -> %d entries", len(lines), len(keep))
    except OSError:
        pass


def read_audit(limit: int = 200) -> list[dict[str, Any]]:
    """Read last N audit log entries."""
    try:
        lines = _AUDIT_LOG_PATH.read_text("utf-8").strip().splitlines()
    except (FileNotFoundError, OSError):
        return []
    entries = []
    for line in lines[-limit:]:
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    entries.reverse()
    return entries


def _load_or_create_secret(config_secret: str) -> str:
    """Load JWT secret from config, persistent file, or generate a new one."""
    if config_secret:
        return config_secret
    # Try reading from persistent file
    try:
        stored = _JWT_SECRET_PATH.read_text("utf-8").strip()
        if stored:
            return stored
    except (FileNotFoundError, OSError):
        pass
    # Generate and persist
    new_secret = secrets.token_hex(32)
    try:
        _JWT_SECRET_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = _JWT_SECRET_PATH.with_suffix(".tmp")
        tmp.write_text(new_secret, "utf-8")
        tmp.replace(_JWT_SECRET_PATH)
        os.chmod(_JWT_SECRET_PATH, 0o600)
    except OSError:
        logger.warning("Could not persist JWT secret to %s", _JWT_SECRET_PATH)
    return new_secret


def _load_blacklist() -> dict[str, float]:
    """Load persisted blacklist, discarding expired entries."""
    try:
        data = json.loads(_JWT_BLACKLIST_PATH.read_text("utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}
    now = time.time()
    return {jti: exp for jti, exp in data.items() if isinstance(exp, (int, float)) and exp > now}


def _persist_blacklist(blacklist: dict[str, float]) -> None:
    """Write blacklist to disk atomically."""
    try:
        _JWT_BLACKLIST_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = _JWT_BLACKLIST_PATH.with_suffix(".tmp")
        tmp.write_text(json.dumps(blacklist), "utf-8")
        tmp.replace(_JWT_BLACKLIST_PATH)
    except OSError:
        logger.warning("Could not persist JWT blacklist to %s", _JWT_BLACKLIST_PATH)


class JWTAuth:
    """JWT token manager and middleware for the API server."""

    def __init__(
        self,
        config: ApiConfig,
        *,
        access_expires: int = _ACCESS_TOKEN_EXPIRES,
        refresh_expires: int = _REFRESH_TOKEN_EXPIRES,
    ) -> None:
        self._config = config
        self._secret = _load_or_create_secret(getattr(config, "jwt_secret", "") or "")
        self._access_expires = access_expires
        self._refresh_expires = refresh_expires
        # Persisted blacklist for invalidated refresh tokens (jti -> exp)
        self._blacklist: dict[str, float] = _load_blacklist()
        # In-memory rate limiter: ip -> list of timestamps
        self._login_attempts: dict[str, list[float]] = {}
        # TOTP replay protection: "user:code" -> expiry timestamp
        self._used_totp_codes: dict[str, float] = {}

    # -- TOTP replay protection --------------------------------------------------

    def _check_totp_replay(self, username: str, code: str) -> bool:
        """Return True if this TOTP code was already used (replay attack)."""
        key = f"{username}:{code}"
        now = time.time()
        # Clean up expired entries periodically
        if len(self._used_totp_codes) > 1000:
            self._used_totp_codes = {
                k: exp for k, exp in self._used_totp_codes.items() if exp > now
            }
        return key in self._used_totp_codes and self._used_totp_codes[key] > now

    def _mark_totp_used(self, username: str, code: str) -> None:
        """Mark a TOTP code as used. Expires after 90 seconds (covers +-1 window)."""
        key = f"{username}:{code}"
        self._used_totp_codes[key] = time.time() + 90

    # -- Rate limiting -----------------------------------------------------------

    def _check_rate_limit(self, ip: str) -> bool:
        """Return True if the IP is rate-limited. Cleans up old entries."""
        now = time.time()
        cutoff = now - _RATE_LIMIT_WINDOW
        attempts = self._login_attempts.get(ip, [])
        # Remove old attempts
        attempts = [t for t in attempts if t > cutoff]
        self._login_attempts[ip] = attempts
        if len(attempts) >= _RATE_LIMIT_MAX:
            return True
        # Periodically purge stale IPs (every 100th call)
        if not hasattr(self, "_rl_counter"):
            self._rl_counter = 0
        self._rl_counter += 1
        if self._rl_counter >= 100:
            self._rl_counter = 0
            self._login_attempts = {
                k: [t for t in v if t > cutoff]
                for k, v in self._login_attempts.items()
                if any(t > cutoff for t in v)
            }
        return False

    def _record_attempt(self, ip: str) -> None:
        """Record a login attempt for rate limiting."""
        now = time.time()
        self._login_attempts.setdefault(ip, []).append(now)

    # -- Token creation -------------------------------------------------------

    def _create_token(
        self,
        sub: str,
        role: str,
        expires_in: int,
        *,
        token_type: str = "access",
        **extra: Any,
    ) -> str:
        now = time.time()
        payload: dict[str, Any] = {
            "sub": sub,
            "role": role,
            "type": token_type,
            "iat": now,
            "exp": now + expires_in,
            "jti": secrets.token_hex(16),
            **extra,
        }
        return jwt.encode(payload, self._secret, algorithm=_ALGORITHM)

    def create_token_pair(
        self,
        user_id: str = "api_user",
        role: str = "admin",
        allowed_agents: list[str] | None = None,
    ) -> dict[str, str]:
        """Return ``{"access_token": ..., "refresh_token": ...}``."""
        extra: dict[str, Any] = {}
        if allowed_agents:
            extra["allowed_agents"] = allowed_agents
        return {
            "access_token": self._create_token(
                user_id, role, self._access_expires, token_type="access", **extra,
            ),
            "refresh_token": self._create_token(
                user_id, role, self._refresh_expires, token_type="refresh", **extra,
            ),
        }

    # -- Token validation -----------------------------------------------------

    def decode(self, token: str, *, expected_type: str = "access") -> dict[str, Any]:
        """Decode and validate a JWT.  Raises ``jwt.PyJWTError`` on failure."""
        payload = jwt.decode(token, self._secret, algorithms=[_ALGORITHM])
        if payload.get("type") != expected_type:
            raise jwt.InvalidTokenError(
                f"Expected token type '{expected_type}', got '{payload.get('type')}'"
            )
        jti = payload.get("jti", "")
        if jti in self._blacklist:
            raise jwt.InvalidTokenError("Token has been revoked")
        return payload

    # -- Blacklist management -------------------------------------------------

    def revoke(self, token: str) -> None:
        """Add a refresh token's jti to the blacklist and persist."""
        try:
            payload = jwt.decode(
                token, self._secret, algorithms=[_ALGORITHM],
                options={"verify_exp": False},
            )
        except jwt.PyJWTError:
            return
        jti = payload.get("jti", "")
        exp = payload.get("exp", 0)
        if jti:
            self._blacklist[jti] = exp
            _persist_blacklist(self._blacklist)

    def cleanup_blacklist(self) -> None:
        """Remove expired entries from the blacklist and persist."""
        now = time.time()
        self._blacklist = {
            jti: exp for jti, exp in self._blacklist.items() if exp > now
        }
        _persist_blacklist(self._blacklist)

    # -- aiohttp middleware ---------------------------------------------------

    @web.middleware
    async def middleware(
        self,
        request: web.Request,
        handler: Callable[[web.Request], Coroutine[Any, Any, web.StreamResponse]],
    ) -> web.StreamResponse:
        """Check JWT (or legacy Bearer token) on ``/api/*`` routes.

        Public paths and non-``/api`` paths are passed through.
        If a valid legacy Bearer token is provided, the request proceeds
        with a synthetic ``admin`` identity for backward compatibility.
        """
        path = request.path
        if path in _PUBLIC_PATHS or not path.startswith("/api"):
            return await handler(request)

        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return web.json_response({"error": "missing Authorization header"}, status=401)

        raw_token = auth_header[7:]

        # Try legacy static token first (backward compatibility)
        if self._config.token and hmac.compare_digest(raw_token, self._config.token):
            request["jwt_user"] = {"sub": "legacy", "role": "admin"}
            return await handler(request)

        # Try JWT
        try:
            payload = self.decode(raw_token, expected_type="access")
        except jwt.PyJWTError:
            logger.debug("JWT decode failed for request to %s", path)
            return web.json_response({"error": "invalid token"}, status=401)

        request["jwt_user"] = payload
        return await handler(request)

    # -- Route handlers -------------------------------------------------------

    async def handle_login(self, request: web.Request) -> web.Response:
        """``POST /api/auth/login`` — authenticate with username+password or legacy token."""
        ip = request.remote or "unknown"
        if self._check_rate_limit(ip):
            return web.json_response(
                {"error": "too many login attempts, try again later"},
                status=429,
            )

        try:
            body = await request.json()
        except Exception:
            self._record_attempt(ip)
            return web.json_response({"error": "invalid JSON body"}, status=400)

        # --- Path 1: username + password login ---
        username = body.get("username", "")
        password = body.get("password", "")
        if username and password:
            user = _find_user(str(username))
            if not user or not verify_password(str(password), user.get("password_hash", "")):
                self._record_attempt(ip)
                return web.json_response({"error": "invalid credentials"}, status=401)
            if not user.get("active", True):
                self._record_attempt(ip)
                return web.json_response({"error": "account is disabled"}, status=403)

            # If 2FA is enabled, return a temp token instead of full tokens
            if user.get("totp_enabled"):
                temp_token = self._create_token(
                    str(username),
                    user.get("role", "viewer"),
                    _TEMP_TOKEN_EXPIRES,
                    token_type="2fa_temp",
                )
                logger.info("JWT login (2FA required): user=%s ip=%s", username, ip)
                return web.json_response({
                    "requires_2fa": True,
                    "temp_token": temp_token,
                })

            role = user.get("role", "viewer")
            allowed_agents = user.get("allowed_agents", [])
            tokens = self.create_token_pair(
                user_id=str(username),
                role=role,
                allowed_agents=allowed_agents,
            )
            write_audit(user=str(username), action="login", details=f"ip={ip}")
            logger.info("JWT login: user=%s role=%s ip=%s", username, role, ip)
            return web.json_response({
                **tokens,
                "user": {
                    "username": user.get("username"),
                    "role": role,
                    "display_name": user.get("display_name", ""),
                    "allowed_agents": allowed_agents,
                },
            })

        # --- Path 2: legacy token login (backward compatibility) ---
        token = body.get("token", "")
        if token and self._config.token and hmac.compare_digest(str(token), self._config.token):
            tokens = self.create_token_pair(user_id="legacy_admin", role="admin")
            write_audit(user="legacy_admin", action="login", details=f"ip={ip} method=token")
            logger.info("JWT login (legacy token): ip=%s", ip)
            return web.json_response({
                **tokens,
                "user": {
                    "username": "legacy_admin",
                    "role": "admin",
                    "display_name": "Legacy Admin",
                    "allowed_agents": [],
                },
            })

        self._record_attempt(ip)
        return web.json_response({"error": "invalid credentials"}, status=401)

    async def handle_refresh(self, request: web.Request) -> web.Response:
        """``POST /api/auth/refresh`` — issue new access token from refresh token.

        Re-reads user from users.json to check active status, current role,
        and allowed_agents — so changes take effect on next token refresh.
        """
        try:
            body = await request.json()
        except Exception:
            return web.json_response({"error": "invalid JSON body"}, status=400)

        refresh_token = body.get("refresh_token", "")
        if not refresh_token:
            return web.json_response({"error": "missing refresh_token"}, status=400)

        try:
            payload = self.decode(str(refresh_token), expected_type="refresh")
        except jwt.PyJWTError:
            logger.debug("Refresh token decode failed")
            return web.json_response({"error": "invalid refresh token"}, status=401)

        username = payload["sub"]

        # Legacy token users bypass user-db checks (exact match only)
        if username == "legacy_admin":
            access_token = self._create_token(
                username, "admin", self._access_expires, token_type="access",
            )
            return web.json_response({"access_token": access_token})

        # Re-check user status from users.json (role/active/allowed_agents may have changed)
        user = _find_user(username)
        if not user:
            return web.json_response({"error": "user no longer exists"}, status=401)
        if not user.get("active", True):
            return web.json_response({"error": "account is disabled"}, status=403)

        role = user.get("role", "viewer")
        allowed_agents = user.get("allowed_agents", [])
        extra: dict[str, Any] = {}
        if allowed_agents:
            extra["allowed_agents"] = allowed_agents

        access_token = self._create_token(
            username, role, self._access_expires, token_type="access", **extra,
        )
        return web.json_response({"access_token": access_token})

    async def handle_logout(self, request: web.Request) -> web.Response:
        """``POST /api/auth/logout`` — revoke a refresh token."""
        try:
            body = await request.json()
        except Exception:
            return web.json_response({"error": "invalid JSON body"}, status=400)

        refresh_token = body.get("refresh_token", "")
        if refresh_token:
            self.revoke(str(refresh_token))
            self.cleanup_blacklist()

        return web.json_response({"status": "ok"})

    async def handle_me(self, request: web.Request) -> web.Response:
        """``GET /api/auth/me`` — return current user info from users.json.

        Reads live data so role/allowed_agents changes are reflected immediately.
        """
        jwt_user = request.get("jwt_user")
        if not jwt_user:
            return web.json_response({"error": "unauthorized"}, status=401)

        username = jwt_user.get("sub", "")

        # Legacy token users don't have a users.json entry
        if username == "legacy_admin":
            return web.json_response({
                "username": username,
                "role": "admin",
                "display_name": "Legacy Admin",
                "allowed_agents": [],
            })

        user = _find_user(username)
        if not user:
            return web.json_response({"error": "user not found"}, status=401)

        return web.json_response({
            "username": user.get("username", ""),
            "role": user.get("role", "viewer"),
            "display_name": user.get("display_name", ""),
            "allowed_agents": user.get("allowed_agents", []),
            "totp_enabled": bool(user.get("totp_enabled", False)),
        })

    async def handle_update_profile(self, request: web.Request) -> web.Response:
        """``PUT /api/auth/profile`` — update own display_name or password.

        Accepts JSON body with optional fields:
        - ``display_name``: new display name
        - ``old_password`` + ``new_password``: change password

        Does NOT allow changing role, allowed_agents, or active status.
        """
        jwt_user = request.get("jwt_user")
        if not jwt_user:
            return web.json_response({"error": "unauthorized"}, status=401)

        username = jwt_user.get("sub", "")
        if username == "legacy_admin":
            return web.json_response(
                {"error": "legacy token users cannot update profile"},
                status=400,
            )

        try:
            body = await request.json()
        except Exception:
            return web.json_response({"error": "invalid JSON body"}, status=400)

        users = _read_users()
        user = None
        for u in users:
            if u.get("username") == username:
                user = u
                break
        if not user:
            return web.json_response({"error": "user not found"}, status=401)

        changes: list[str] = []

        # Display name
        new_display = body.get("display_name")
        if new_display is not None:
            user["display_name"] = str(new_display)
            changes.append("display_name")

        # Password change
        old_pw = body.get("old_password", "")
        new_pw = body.get("new_password", "")
        if old_pw or new_pw:
            if not old_pw or not new_pw:
                return web.json_response(
                    {"error": "both old_password and new_password are required"},
                    status=400,
                )
            if not verify_password(str(old_pw), user.get("password_hash", "")):
                return web.json_response(
                    {"error": "current password is incorrect"},
                    status=400,
                )
            if len(str(new_pw)) < 8:
                return web.json_response(
                    {"error": "new password must be at least 8 characters"},
                    status=400,
                )
            user["password_hash"] = hash_password(str(new_pw))
            changes.append("password")

        if not changes:
            return web.json_response({"error": "no changes provided"}, status=400)

        _write_users(users)
        write_audit(
            user=username,
            action="profile_updated",
            target=username,
            details=f"changed: {', '.join(changes)}",
        )

        return web.json_response({
            "username": user.get("username", ""),
            "role": user.get("role", "viewer"),
            "display_name": user.get("display_name", ""),
            "allowed_agents": user.get("allowed_agents", []),
        })

    # -- 2FA endpoints -----------------------------------------------------------

    async def handle_2fa_login(self, request: web.Request) -> web.Response:
        """``POST /api/auth/2fa/login`` — complete 2FA login with temp token + TOTP code."""
        ip = request.remote or "unknown"
        if self._check_rate_limit(ip):
            return web.json_response(
                {"error": "too many login attempts, try again later"},
                status=429,
            )

        try:
            body = await request.json()
        except Exception:
            return web.json_response({"error": "invalid JSON body"}, status=400)

        temp_token = body.get("temp_token", "")
        code = body.get("code", "")
        if not temp_token or not code:
            self._record_attempt(ip)
            return web.json_response({"error": "temp_token and code are required"}, status=400)

        try:
            payload = self.decode(str(temp_token), expected_type="2fa_temp")
        except jwt.PyJWTError:
            self._record_attempt(ip)
            return web.json_response({"error": "invalid or expired temp token"}, status=401)

        username = payload["sub"]
        user = _find_user(username)
        if not user:
            return web.json_response({"error": "user not found"}, status=401)
        if not user.get("active", True):
            return web.json_response({"error": "account is disabled"}, status=403)

        totp_secret = user.get("totp_secret", "")
        code_str = str(code)
        if not totp_secret or not verify_totp(totp_secret, code_str):
            self._record_attempt(ip)
            return web.json_response({"error": "invalid 2FA code"}, status=401)

        # TOTP replay protection: reject reused codes within their validity window
        if self._check_totp_replay(username, code_str):
            self._record_attempt(ip)
            return web.json_response({"error": "invalid 2FA code"}, status=401)
        self._mark_totp_used(username, code_str)

        # Revoke the temp token so it cannot be reused
        self.revoke(str(temp_token))

        role = user.get("role", "viewer")
        allowed_agents = user.get("allowed_agents", [])
        tokens = self.create_token_pair(
            user_id=username,
            role=role,
            allowed_agents=allowed_agents,
        )
        write_audit(user=username, action="login", details=f"ip={ip} 2fa=true")
        logger.info("JWT login (2FA): user=%s role=%s ip=%s", username, role, ip)
        return web.json_response({
            **tokens,
            "user": {
                "username": user.get("username"),
                "role": role,
                "display_name": user.get("display_name", ""),
                "allowed_agents": allowed_agents,
            },
        })

    async def handle_2fa_setup(self, request: web.Request) -> web.Response:
        """``POST /api/auth/2fa/setup`` — generate TOTP secret for the current user."""
        jwt_user = request.get("jwt_user")
        if not jwt_user:
            return web.json_response({"error": "unauthorized"}, status=401)

        username = jwt_user.get("sub", "")
        if username == "legacy_admin":
            return web.json_response(
                {"error": "legacy token users cannot enable 2FA"}, status=400,
            )

        user = _find_user(username)
        if not user:
            return web.json_response({"error": "user not found"}, status=401)

        if user.get("totp_enabled"):
            return web.json_response({"error": "2FA is already enabled"}, status=400)

        secret = generate_totp_secret()
        otpauth_uri = build_otpauth_uri(username, secret)

        # Store secret in pending field (not active until verified)
        users = _read_users()
        for u in users:
            if u.get("username") == username:
                u["totp_pending_secret"] = secret
                break
        _write_users(users)

        return web.json_response({
            "secret": secret,
            "otpauth_uri": otpauth_uri,
            "qr_data": otpauth_uri,
        })

    async def handle_2fa_verify(self, request: web.Request) -> web.Response:
        """``POST /api/auth/2fa/verify`` — verify TOTP code and enable 2FA."""
        jwt_user = request.get("jwt_user")
        if not jwt_user:
            return web.json_response({"error": "unauthorized"}, status=401)

        username = jwt_user.get("sub", "")
        try:
            body = await request.json()
        except Exception:
            return web.json_response({"error": "invalid JSON body"}, status=400)

        code = body.get("code", "")
        if not code:
            return web.json_response({"error": "code is required"}, status=400)

        users = _read_users()
        user = None
        for u in users:
            if u.get("username") == username:
                user = u
                break
        if not user:
            return web.json_response({"error": "user not found"}, status=401)

        totp_secret = user.get("totp_pending_secret", "") or user.get("totp_secret", "")
        if not totp_secret:
            return web.json_response({"error": "call /api/auth/2fa/setup first"}, status=400)

        if not verify_totp(totp_secret, str(code)):
            return web.json_response({"error": "invalid code"}, status=400)

        user["totp_secret"] = totp_secret
        user.pop("totp_pending_secret", None)
        user["totp_enabled"] = True
        _write_users(users)
        write_audit(user=username, action="2fa_enabled", target=username)
        return web.json_response({"status": "ok", "totp_enabled": True})

    async def handle_2fa_disable(self, request: web.Request) -> web.Response:
        """``POST /api/auth/2fa/disable`` — disable 2FA (requires current TOTP code)."""
        jwt_user = request.get("jwt_user")
        if not jwt_user:
            return web.json_response({"error": "unauthorized"}, status=401)

        username = jwt_user.get("sub", "")
        try:
            body = await request.json()
        except Exception:
            return web.json_response({"error": "invalid JSON body"}, status=400)

        code = body.get("code", "")
        if not code:
            return web.json_response({"error": "code is required"}, status=400)

        users = _read_users()
        user = None
        for u in users:
            if u.get("username") == username:
                user = u
                break
        if not user:
            return web.json_response({"error": "user not found"}, status=401)

        totp_secret = user.get("totp_secret", "")
        if not totp_secret or not user.get("totp_enabled"):
            return web.json_response({"error": "2FA is not enabled"}, status=400)

        if not verify_totp(totp_secret, str(code)):
            return web.json_response({"error": "invalid code"}, status=400)

        user["totp_enabled"] = False
        user["totp_secret"] = ""
        _write_users(users)
        write_audit(user=username, action="2fa_disabled", target=username)
        return web.json_response({"status": "ok", "totp_enabled": False})

    def register_routes(self, app: web.Application) -> None:
        """Add auth endpoints to the aiohttp application."""
        _ensure_default_admin()
        app.router.add_post("/api/auth/login", self.handle_login)
        app.router.add_post("/api/auth/refresh", self.handle_refresh)
        app.router.add_post("/api/auth/logout", self.handle_logout)
        app.router.add_get("/api/auth/me", self.handle_me)
        app.router.add_put("/api/auth/profile", self.handle_update_profile)
        # 2FA endpoints
        app.router.add_post("/api/auth/2fa/login", self.handle_2fa_login)
        app.router.add_post("/api/auth/2fa/setup", self.handle_2fa_setup)
        app.router.add_post("/api/auth/2fa/verify", self.handle_2fa_verify)
        app.router.add_post("/api/auth/2fa/disable", self.handle_2fa_disable)


# -- Role-based access decorator ----------------------------------------------


def require_role(
    minimum_role: str,
) -> Callable[
    [Callable[..., Coroutine[Any, Any, web.StreamResponse]]],
    Callable[..., Coroutine[Any, Any, web.StreamResponse]],
]:
    """Decorator that enforces a minimum role level on a handler.

    Usage::

        @require_role("operator")
        async def handle_run_task(request: web.Request) -> web.Response:
            ...
    """
    min_level = ROLE_LEVELS.get(minimum_role, 0)

    def decorator(
        fn: Callable[..., Coroutine[Any, Any, web.StreamResponse]],
    ) -> Callable[..., Coroutine[Any, Any, web.StreamResponse]]:
        @functools.wraps(fn)
        async def wrapper(
            *args: Any, **kwargs: Any,
        ) -> web.StreamResponse:
            # Find the request object (works for both plain functions and methods)
            request: web.Request | None = None
            for arg in args:
                if isinstance(arg, web.Request):
                    request = arg
                    break
            if request is None:
                request = kwargs.get("request")  # type: ignore[assignment]

            if request is None:
                return web.json_response({"error": "internal error"}, status=500)

            user = request.get("jwt_user")
            if not user:
                return web.json_response({"error": "unauthorized"}, status=401)

            user_level = ROLE_LEVELS.get(user.get("role", ""), -1)
            if user_level < min_level:
                return web.json_response(
                    {"error": f"insufficient permissions, requires '{minimum_role}' role"},
                    status=403,
                )
            return await fn(*args, **kwargs)

        return wrapper

    return decorator
