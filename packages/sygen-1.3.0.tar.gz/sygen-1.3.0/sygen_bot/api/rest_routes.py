"""REST API endpoints for Sygen system management.

Provides CRUD endpoints for agents, cron jobs, webhooks, tasks, sessions,
memory, and system status. Auth is handled by the JWT middleware in auth.py.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import signal
import sqlite3
import time
import uuid
from collections import deque
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from aiohttp import web

from sygen_bot.api.auth import (
    ROLE_LEVELS,
    _read_users,
    _write_users,
    hash_password,
    read_audit,
    require_role,
    write_audit,
)
import hashlib as _hashlib
import hmac as _hmac

logger = logging.getLogger(__name__)

_START_TIME = time.monotonic()

# Cache sygen home at import time (#18)
_SYGEN_HOME = Path(os.environ.get("SYGEN_HOME", Path.home() / ".sygen"))

# Per-file async locks for JSON R/W (#4)
_file_locks: dict[str, asyncio.Lock] = {}

# Valid agent name pattern (#1)
_AGENT_NAME_RE = re.compile(r"^[a-zA-Z0-9_-]+$")

# Fields to strip from agent data before returning to API clients (#11)
_AGENT_SECRET_KEYS = {"telegram_token", "bot_token", "token", "api_key", "secret"}

# Allowed fields for cron job and webhook creation (#10)
_CRON_ALLOWED_FIELDS = {"id", "title", "schedule", "agent", "enabled", "description", "task", "args"}
_WEBHOOK_ALLOWED_FIELDS = {"id", "url", "method", "headers", "agent", "enabled", "description", "secret"}
_CRON_SCHEDULE_RE = re.compile(
    r"^(\*|[0-9,/\-]+)\s+(\*|[0-9,/\-]+)\s+(\*|[0-9,/\-]+)\s+(\*|[0-9,/\-]+)\s+(\*|[0-9,/\-]+)$"
)


def _sygen_home() -> Path:
    return _SYGEN_HOME


async def _with_file_lock(path: Path) -> asyncio.Lock:
    """Get or create an asyncio.Lock for the given file path."""
    key = str(path)
    if key not in _file_locks:
        _file_locks[key] = asyncio.Lock()
    return _file_locks[key]


def _ok(data: Any) -> web.Response:
    return web.json_response({"ok": True, "data": data})


def _err(message: str, status: int = 400) -> web.Response:
    return web.json_response({"ok": False, "error": message}, status=status)


def _read_json(path: Path) -> Any:
    """Read a JSON file, return None if missing or invalid."""
    try:
        return json.loads(path.read_text("utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None


def _write_json(path: Path, data: Any) -> None:
    """Write data to a JSON file atomically."""
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False, default=str), "utf-8")
    tmp.replace(path)


def _filter_fields(body: dict[str, Any], allowed: set[str]) -> dict[str, Any]:
    """Return only allowed fields from the body."""
    return {k: v for k, v in body.items() if k in allowed}


def _read_last_lines(path: Path, n: int) -> list[str]:
    """Read the last N lines of a file efficiently without loading the whole file."""
    try:
        with path.open("rb") as f:
            f.seek(0, 2)
            size = f.tell()
            if size == 0:
                return []

            chunk_size = 8192
            collected: list[str] = []
            remainder = b""
            pos = size

            while pos > 0:
                read_size = min(chunk_size, pos)
                pos -= read_size
                f.seek(pos)
                chunk = f.read(read_size)
                chunk = chunk + remainder
                remainder = b""
                parts = chunk.split(b"\n")
                if pos > 0:
                    remainder = parts[0]
                    parts = parts[1:]
                for part in reversed(parts):
                    decoded = part.decode("utf-8", errors="replace")
                    if decoded:
                        collected.append(decoded)
                    if len(collected) >= n:
                        break
                if len(collected) >= n:
                    break

            if remainder and len(collected) < n:
                decoded = remainder.decode("utf-8", errors="replace")
                if decoded:
                    collected.append(decoded)

            collected.reverse()
            return collected[-n:]
    except OSError:
        return []


# ---------------------------------------------------------------------------
# Agents
# ---------------------------------------------------------------------------

def _get_allowed_agents(request: web.Request) -> list[str]:
    """Get allowed_agents from JWT payload (empty = all agents allowed)."""
    user = request.get("jwt_user", {})
    return user.get("allowed_agents", [])


def _filter_by_allowed_agents(
    items: list[dict[str, Any]], allowed: list[str], key: str = "name",
) -> list[dict[str, Any]]:
    """Filter items to only those the user has access to."""
    if not allowed:
        return items
    return [item for item in items if item.get(key) in allowed]


def _sanitize_agent(agent: dict[str, Any]) -> dict[str, Any]:
    """Strip secret fields from agent data before returning to clients."""
    return {k: v for k, v in agent.items() if k not in _AGENT_SECRET_KEYS}


async def get_agents(request: web.Request) -> web.Response:
    home = _sygen_home()
    data = _read_json(home / "agents.json")
    if data is None:
        return _ok([])

    agents = data if isinstance(data, list) else data.get("agents", [])

    sessions = _read_json(home / "sessions.json") or {}
    for agent in agents:
        name = agent.get("name", "")
        active = sum(1 for v in sessions.values() if v.get("agent") == name)
        agent["active_sessions"] = active

    # Per-agent access filtering
    allowed = _get_allowed_agents(request)
    if allowed:
        agents = _filter_by_allowed_agents(agents, allowed)

    # Strip secrets (tokens, api keys) from agent data
    return _ok([_sanitize_agent(a) for a in agents])


async def get_agent(request: web.Request) -> web.Response:
    name = request.match_info["name"]

    # Validate agent name to prevent unexpected input
    if not _AGENT_NAME_RE.match(name):
        return _err("invalid agent name", 400)

    # Enforce per-agent access
    allowed = _get_allowed_agents(request)
    if allowed and name not in allowed:
        return _err(f"agent '{name}' not found", 404)

    home = _sygen_home()
    data = _read_json(home / "agents.json")
    if data is None:
        return _err("agents.json not found", 404)

    agents = data if isinstance(data, list) else data.get("agents", [])
    for agent in agents:
        if agent.get("name") == name:
            return _ok(_sanitize_agent(agent))

    return _err(f"agent '{name}' not found", 404)


# ---------------------------------------------------------------------------
# Cron Jobs
# ---------------------------------------------------------------------------

async def get_cron_jobs(request: web.Request) -> web.Response:
    data = _read_json(_sygen_home() / "cron_jobs.json")
    if data is None:
        return _ok([])
    jobs = data.get("jobs", []) if isinstance(data, dict) else data

    # Filter by allowed_agents
    allowed = _get_allowed_agents(request)
    if allowed:
        jobs = _filter_by_allowed_agents(jobs, allowed, key="agent")

    return _ok(jobs)


@require_role("admin")
async def create_cron_job(request: web.Request) -> web.Response:
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    path = _sygen_home() / "cron_jobs.json"

    for field in ("id", "title", "schedule"):
        if field not in body:
            return _err(f"missing required field: {field}")

    # Validate schedule format (#10)
    schedule = str(body.get("schedule", ""))
    if not _CRON_SCHEDULE_RE.match(schedule):
        return _err("invalid cron schedule format (expected: '* * * * *')")

    # Filter to allowed fields only (#10)
    filtered = _filter_fields(body, _CRON_ALLOWED_FIELDS)

    # Enforce per-agent access on the job's agent
    allowed = _get_allowed_agents(request)
    job_agent = filtered.get("agent", "")
    if allowed and job_agent and job_agent not in allowed:
        return _err(f"agent '{job_agent}' is not in your allowed agents", 403)

    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path) or {"jobs": []}
        jobs = data.get("jobs", []) if isinstance(data, dict) else data

        if any(j.get("id") == filtered["id"] for j in jobs):
            return _err(f"cron job '{filtered['id']}' already exists", 409)

        jobs.append(filtered)
        if isinstance(data, dict):
            data["jobs"] = jobs
        else:
            data = {"jobs": jobs}
        _write_json(path, data)

    return _ok(filtered)


@require_role("admin")
async def update_cron_job(request: web.Request) -> web.Response:
    job_id = request.match_info["id"]
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    # Validate schedule if provided (#10)
    if "schedule" in body:
        schedule = str(body["schedule"])
        if not _CRON_SCHEDULE_RE.match(schedule):
            return _err("invalid cron schedule format (expected: '* * * * *')")

    # Filter to allowed fields (#10)
    filtered = _filter_fields(body, _CRON_ALLOWED_FIELDS)

    path = _sygen_home() / "cron_jobs.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("cron_jobs.json not found", 404)

        jobs = data.get("jobs", []) if isinstance(data, dict) else data
        allowed = _get_allowed_agents(request)
        for i, job in enumerate(jobs):
            if job.get("id") == job_id:
                # Enforce per-agent access on existing job
                if allowed and job.get("agent") and job["agent"] not in allowed:
                    return _err(f"cron job '{job_id}' not found", 404)
                jobs[i] = {**job, **filtered, "id": job_id}
                if isinstance(data, dict):
                    data["jobs"] = jobs
                _write_json(path, data)
                return _ok(jobs[i])

    return _err(f"cron job '{job_id}' not found", 404)


@require_role("admin")
async def delete_cron_job(request: web.Request) -> web.Response:
    job_id = request.match_info["id"]
    path = _sygen_home() / "cron_jobs.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("cron_jobs.json not found", 404)

        jobs = data.get("jobs", []) if isinstance(data, dict) else data

        # Enforce per-agent access: find the job first to check its agent
        allowed = _get_allowed_agents(request)
        if allowed:
            target_job = next((j for j in jobs if j.get("id") == job_id), None)
            if target_job is None:
                return _err(f"cron job '{job_id}' not found", 404)
            if target_job.get("agent") and target_job["agent"] not in allowed:
                return _err(f"cron job '{job_id}' not found", 404)

        original_len = len(jobs)
        jobs = [j for j in jobs if j.get("id") != job_id]

        if len(jobs) == original_len:
            return _err(f"cron job '{job_id}' not found", 404)

        if isinstance(data, dict):
            data["jobs"] = jobs
        else:
            data = {"jobs": jobs}
        _write_json(path, data)

    return _ok({"deleted": job_id})


@require_role("operator")
async def run_cron_job(request: web.Request) -> web.Response:
    job_id = request.match_info["id"]
    path = _sygen_home() / "cron_jobs.json"
    data = _read_json(path)
    if data is None:
        return _err("cron_jobs.json not found", 404)

    jobs = data.get("jobs", []) if isinstance(data, dict) else data
    for job in jobs:
        if job.get("id") == job_id:
            # Check allowed_agents before running
            allowed = _get_allowed_agents(request)
            if allowed and job.get("agent") not in allowed:
                return _err(f"cron job '{job_id}' not found", 404)

            if not _AGENT_NAME_RE.match(job_id):
                return _err("invalid job id format", 400)
            marker = _sygen_home() / "workspace" / "cron_tasks" / job_id / ".run_now"
            marker.parent.mkdir(parents=True, exist_ok=True)
            marker.write_text(str(time.time()))
            return _ok({"triggered": job_id})

    return _err(f"cron job '{job_id}' not found", 404)


# ---------------------------------------------------------------------------
# Webhooks
# ---------------------------------------------------------------------------

async def get_webhooks(request: web.Request) -> web.Response:
    data = _read_json(_sygen_home() / "webhooks.json")
    if data is None:
        return _ok([])
    hooks = data.get("webhooks", []) if isinstance(data, dict) else data

    # Filter by allowed_agents
    allowed = _get_allowed_agents(request)
    if allowed:
        hooks = _filter_by_allowed_agents(hooks, allowed, key="agent")

    return _ok(hooks)


@require_role("admin")
async def create_webhook(request: web.Request) -> web.Response:
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    if "id" not in body:
        return _err("missing required field: id")

    # Filter to allowed fields only (#10)
    filtered = _filter_fields(body, _WEBHOOK_ALLOWED_FIELDS)

    # Enforce per-agent access on the webhook's agent
    allowed = _get_allowed_agents(request)
    wh_agent = filtered.get("agent", "")
    if allowed and wh_agent and wh_agent not in allowed:
        return _err(f"agent '{wh_agent}' is not in your allowed agents", 403)

    path = _sygen_home() / "webhooks.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path) or {"webhooks": []}
        hooks = data.get("webhooks", []) if isinstance(data, dict) else data

        if any(h.get("id") == filtered["id"] for h in hooks):
            return _err(f"webhook '{filtered['id']}' already exists", 409)

        hooks.append(filtered)
        if isinstance(data, dict):
            data["webhooks"] = hooks
        else:
            data = {"webhooks": hooks}
        _write_json(path, data)

    return _ok(filtered)


@require_role("admin")
async def update_webhook(request: web.Request) -> web.Response:
    hook_id = request.match_info["id"]
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    # Filter to allowed fields (#10)
    filtered = _filter_fields(body, _WEBHOOK_ALLOWED_FIELDS)

    path = _sygen_home() / "webhooks.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("webhooks.json not found", 404)

        hooks = data.get("webhooks", []) if isinstance(data, dict) else data
        allowed = _get_allowed_agents(request)
        for i, hook in enumerate(hooks):
            if hook.get("id") == hook_id:
                # Enforce per-agent access on existing webhook
                if allowed and hook.get("agent") and hook["agent"] not in allowed:
                    return _err(f"webhook '{hook_id}' not found", 404)
                hooks[i] = {**hook, **filtered, "id": hook_id}
                if isinstance(data, dict):
                    data["webhooks"] = hooks
                _write_json(path, data)
                return _ok(hooks[i])

    return _err(f"webhook '{hook_id}' not found", 404)


@require_role("admin")
async def delete_webhook(request: web.Request) -> web.Response:
    hook_id = request.match_info["id"]
    path = _sygen_home() / "webhooks.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("webhooks.json not found", 404)

        hooks = data.get("webhooks", []) if isinstance(data, dict) else data

        # Enforce per-agent access: find the hook first to check its agent
        allowed = _get_allowed_agents(request)
        if allowed:
            target_hook = next((h for h in hooks if h.get("id") == hook_id), None)
            if target_hook is None:
                return _err(f"webhook '{hook_id}' not found", 404)
            if target_hook.get("agent") and target_hook["agent"] not in allowed:
                return _err(f"webhook '{hook_id}' not found", 404)

        original_len = len(hooks)
        hooks = [h for h in hooks if h.get("id") != hook_id]

        if len(hooks) == original_len:
            return _err(f"webhook '{hook_id}' not found", 404)

        if isinstance(data, dict):
            data["webhooks"] = hooks
        else:
            data = {"webhooks": hooks}
        _write_json(path, data)

    return _ok({"deleted": hook_id})


@require_role("operator")
async def verify_webhook_signature(request: web.Request) -> web.Response:
    """``POST /api/webhooks/{id}/verify`` — verify HMAC-SHA256 signature for a webhook payload."""
    hook_id = request.match_info["id"]
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    payload = body.get("payload", "")
    signature = body.get("signature", "")
    if not payload or not signature:
        return _err("payload and signature are required")

    # Find webhook and its secret
    data = _read_json(_sygen_home() / "webhooks.json")
    if data is None:
        return _err("webhooks.json not found", 404)

    hooks = data.get("webhooks", []) if isinstance(data, dict) else data
    hook = None
    for h in hooks:
        if h.get("id") == hook_id:
            hook = h
            break
    if hook is None:
        return _err(f"webhook '{hook_id}' not found", 404)

    # Enforce per-agent access
    allowed = _get_allowed_agents(request)
    if allowed and hook.get("agent") not in allowed:
        return _err(f"webhook '{hook_id}' not found", 404)

    secret = hook.get("secret", "")
    if not secret:
        return _err("webhook has no secret configured", 400)

    # Compute HMAC-SHA256
    payload_bytes = payload.encode("utf-8") if isinstance(payload, str) else payload
    expected = _hmac.new(
        secret.encode("utf-8"), payload_bytes, _hashlib.sha256,
    ).hexdigest()

    valid = _hmac.compare_digest(expected, str(signature))
    return _ok({"valid": valid})


# ---------------------------------------------------------------------------
# Tasks
# ---------------------------------------------------------------------------

async def get_tasks(request: web.Request) -> web.Response:
    data = _read_json(_sygen_home() / "tasks.json")
    if data is None:
        return _ok([])

    tasks = data.get("tasks", []) if isinstance(data, dict) else data

    # Filter by allowed_agents
    allowed = _get_allowed_agents(request)
    if allowed:
        tasks = [t for t in tasks if t.get("parent_agent", t.get("agent", "")) in allowed]

    status_filter = request.query.get("status")
    if status_filter:
        tasks = [t for t in tasks if t.get("status") == status_filter]

    limit = request.query.get("limit")
    if limit and limit.isdigit():
        tasks = tasks[-int(limit):]

    return _ok(tasks)


async def get_task(request: web.Request) -> web.Response:
    task_id = request.match_info["id"]
    data = _read_json(_sygen_home() / "tasks.json")
    if data is None:
        return _err("tasks.json not found", 404)

    tasks = data.get("tasks", []) if isinstance(data, dict) else data
    allowed = _get_allowed_agents(request)
    for task in tasks:
        if task.get("task_id") == task_id:
            # Enforce per-agent access
            if allowed:
                task_agent = task.get("parent_agent", task.get("agent", ""))
                if task_agent and task_agent not in allowed:
                    return _err(f"task '{task_id}' not found", 404)
            return _ok(task)

    return _err(f"task '{task_id}' not found", 404)


@require_role("operator")
async def cancel_task(request: web.Request) -> web.Response:
    task_id = request.match_info["id"]
    path = _sygen_home() / "tasks.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("tasks.json not found", 404)

        tasks = data.get("tasks", []) if isinstance(data, dict) else data
        allowed = _get_allowed_agents(request)
        for task in tasks:
            if task.get("task_id") == task_id:
                # Enforce per-agent access
                if allowed:
                    task_agent = task.get("parent_agent", task.get("agent", ""))
                    if task_agent and task_agent not in allowed:
                        return _err(f"task '{task_id}' not found", 404)
                if task.get("status") in ("done", "cancelled", "failed"):
                    return _err(f"task already {task['status']}", 400)
                task["status"] = "cancelled"
                if isinstance(data, dict):
                    data["tasks"] = tasks
                _write_json(path, data)

                # Attempt to signal the task process if pid is available (#13)
                pid = task.get("pid")
                signal_sent = False
                if pid and isinstance(pid, int):
                    try:
                        os.kill(pid, signal.SIGTERM)
                        signal_sent = True
                    except (ProcessLookupError, PermissionError, OSError):
                        pass

                return _ok({
                    "cancelled": task_id,
                    "note": "cancel is advisory (soft)" + ("; SIGTERM sent" if signal_sent else "; no process to signal"),
                })

    return _err(f"task '{task_id}' not found", 404)


@require_role("admin")
async def create_task(request: web.Request) -> web.Response:
    """Create a new task entry with status 'pending'.

    Accepts JSON with: name (required), agent, prompt, provider, model.
    The task is saved to tasks.json. An external runner or the internal
    task hub picks it up for execution.
    """
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    name = body.get("name")
    if not name or not isinstance(name, str) or not name.strip():
        return _err("missing or empty required field: name")

    prompt = body.get("prompt", "")
    agent = body.get("agent", "main")
    provider = body.get("provider", "claude")
    model = body.get("model", "")

    # Validate agent name
    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name (only alphanumeric, hyphens, and underscores allowed)", 400)

    # Enforce per-agent access
    allowed = _get_allowed_agents(request)
    if allowed and agent not in allowed:
        return _err(f"agent '{agent}' is not in your allowed agents", 403)

    task_id = f"{int(time.time()):08x}"

    entry = {
        "task_id": task_id,
        "name": name.strip(),
        "status": "pending",
        "parent_agent": agent,
        "prompt_preview": (prompt[:80] + "...") if len(prompt) > 80 else prompt,
        "prompt": prompt,
        "provider": provider,
        "model": model,
        "created_at": time.time(),
        "completed_at": None,
        "elapsed_seconds": 0,
        "error": "",
        "result_preview": "",
    }

    path = _sygen_home() / "tasks.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path) or {"tasks": []}
        tasks = data.get("tasks", []) if isinstance(data, dict) else data
        tasks.append(entry)
        if isinstance(data, dict):
            data["tasks"] = tasks
        else:
            data = {"tasks": tasks}
        _write_json(path, data)

    return _ok(entry)


# ---------------------------------------------------------------------------
# Sessions
# ---------------------------------------------------------------------------

async def get_sessions(request: web.Request) -> web.Response:
    data = _read_json(_sygen_home() / "sessions.json")
    if data is None:
        return _ok({})

    # Filter by allowed_agents
    allowed = _get_allowed_agents(request)
    if allowed and isinstance(data, dict):
        data = {
            k: v for k, v in data.items()
            if isinstance(v, dict) and v.get("agent", k) in allowed
        }

    return _ok(data)


@require_role("admin")
async def delete_session(request: web.Request) -> web.Response:
    session_id = request.match_info["id"]
    path = _sygen_home() / "sessions.json"
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("sessions.json not found", 404)

        if session_id not in data:
            return _err(f"session '{session_id}' not found", 404)

        # Enforce per-agent access
        allowed = _get_allowed_agents(request)
        session = data[session_id]
        if allowed and isinstance(session, dict):
            session_agent = session.get("agent", session_id)
            if session_agent not in allowed:
                return _err(f"session '{session_id}' not found", 404)

        del data[session_id]
        _write_json(path, data)

    return _ok({"deleted": session_id})


# ---------------------------------------------------------------------------
# Memory
# ---------------------------------------------------------------------------

async def get_memory(request: web.Request) -> web.Response:
    mem_path = _sygen_home() / "workspace" / "memory_system" / "MAINMEMORY.md"
    try:
        content = mem_path.read_text("utf-8")
    except FileNotFoundError:
        return _err("MAINMEMORY.md not found", 404)
    return _ok({"content": content})


@require_role("admin")
async def update_memory(request: web.Request) -> web.Response:
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    content = body.get("content")
    if content is None:
        return _err("missing 'content' field")
    if not isinstance(content, str):
        return _err("'content' must be a string")

    mem_path = _sygen_home() / "workspace" / "memory_system" / "MAINMEMORY.md"
    mem_path.parent.mkdir(parents=True, exist_ok=True)
    # Atomic write via tmp + rename (#15)
    tmp = mem_path.with_suffix(".tmp")
    tmp.write_text(content, "utf-8")
    tmp.replace(mem_path)
    return _ok({"updated": True})


async def get_memory_modules(request: web.Request) -> web.Response:
    mem_dir = _sygen_home() / "workspace" / "memory_system"
    if not mem_dir.is_dir():
        return _ok([])

    modules = []
    for f in sorted(mem_dir.iterdir()):
        if f.is_file() and f.suffix == ".md":
            modules.append({
                "name": f.stem,
                "filename": f.name,
                "size": f.stat().st_size,
            })
    return _ok(modules)


async def get_memory_module(request: web.Request) -> web.Response:
    """Read content of a specific memory module by filename."""
    filename = request.match_info["filename"]
    # Validate filename to prevent path traversal
    if "/" in filename or "\\" in filename or ".." in filename:
        return _err("invalid filename", 400)
    if not filename.endswith(".md"):
        return _err("only .md files are supported", 400)

    mem_dir = _sygen_home() / "workspace" / "memory_system"
    mem_path = mem_dir / filename
    # Resolve symlinks and verify the path stays within the memory directory
    try:
        if not mem_path.resolve().is_relative_to(mem_dir.resolve()):
            return _err("invalid filename", 400)
    except (ValueError, OSError):
        return _err("invalid filename", 400)
    if not mem_path.is_file():
        return _err(f"module '{filename}' not found", 404)

    try:
        content = mem_path.read_text("utf-8")
    except OSError:
        return _err("failed to read module", 500)

    return _ok({"filename": filename, "content": content})


@require_role("admin")
async def update_memory_module(request: web.Request) -> web.Response:
    """Update content of a specific memory module by filename."""
    filename = request.match_info["filename"]
    if "/" in filename or "\\" in filename or ".." in filename:
        return _err("invalid filename", 400)
    if not filename.endswith(".md"):
        return _err("only .md files are supported", 400)

    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    content = body.get("content")
    if content is None:
        return _err("missing 'content' field")
    if not isinstance(content, str):
        return _err("'content' must be a string")

    mem_dir = _sygen_home() / "workspace" / "memory_system"
    mem_path = mem_dir / filename
    mem_dir.mkdir(parents=True, exist_ok=True)
    # Resolve symlinks and verify the path stays within the memory directory
    try:
        if not mem_path.resolve().is_relative_to(mem_dir.resolve()):
            return _err("invalid filename", 400)
    except (ValueError, OSError):
        return _err("invalid filename", 400)
    tmp = mem_path.with_suffix(".tmp")
    tmp.write_text(content, "utf-8")
    tmp.replace(mem_path)
    return _ok({"updated": True})


# ---------------------------------------------------------------------------
# System
# ---------------------------------------------------------------------------

def _get_cpu_percent() -> float:
    """Read CPU usage from /proc/stat (Linux). Returns 0 on failure."""
    try:
        with open("/proc/stat") as f:
            line = f.readline()
        parts = line.split()
        idle = int(parts[4])
        total = sum(int(p) for p in parts[1:])
        if not hasattr(_get_cpu_percent, "_prev"):
            _get_cpu_percent._prev = (idle, total)  # type: ignore[attr-defined]
            return 0.0
        prev_idle, prev_total = _get_cpu_percent._prev  # type: ignore[attr-defined]
        _get_cpu_percent._prev = (idle, total)  # type: ignore[attr-defined]
        d_total = total - prev_total
        d_idle = idle - prev_idle
        if d_total == 0:
            return 0.0
        return round((1 - d_idle / d_total) * 100, 1)
    except Exception:
        return 0.0


def _get_memory_percent() -> float:
    """Read RAM usage from /proc/meminfo (Linux). Returns 0 on failure."""
    try:
        info: dict[str, int] = {}
        with open("/proc/meminfo") as f:
            for line in f:
                parts = line.split()
                if parts[0].rstrip(":") in ("MemTotal", "MemAvailable"):
                    info[parts[0].rstrip(":")] = int(parts[1])
        total = info.get("MemTotal", 0)
        avail = info.get("MemAvailable", 0)
        if total == 0:
            return 0.0
        return round((1 - avail / total) * 100, 1)
    except Exception:
        return 0.0


def _get_disk_percent() -> float:
    """Get disk usage for the root partition. Returns 0 on failure."""
    try:
        import shutil
        usage = shutil.disk_usage("/")
        return round(usage.used / usage.total * 100, 1)
    except Exception:
        return 0.0


async def get_system_status(request: web.Request) -> web.Response:
    home = _sygen_home()
    uptime_seconds = time.monotonic() - _START_TIME

    agents_data = _read_json(home / "agents.json")
    agent_count = 0
    if agents_data:
        agents = agents_data if isinstance(agents_data, list) else agents_data.get("agents", [])
        agent_count = len(agents)

    tasks_data = _read_json(home / "tasks.json")
    active_tasks = 0
    total_tasks = 0
    if tasks_data:
        tasks_list = tasks_data.get("tasks", []) if isinstance(tasks_data, dict) else tasks_data
        total_tasks = len(tasks_list)
        active_tasks = sum(1 for t in tasks_list if t.get("status") in ("running", "pending"))

    cron_data = _read_json(home / "cron_jobs.json")
    cron_count = 0
    if cron_data:
        jobs = cron_data.get("jobs", []) if isinstance(cron_data, dict) else cron_data
        cron_count = len(jobs)

    sessions_data = _read_json(home / "sessions.json")
    session_count = len(sessions_data) if sessions_data else 0

    return _ok({
        "uptime_seconds": round(uptime_seconds),
        "agents": agent_count,
        "sessions": session_count,
        "cron_jobs": cron_count,
        "tasks_total": total_tasks,
        "tasks_active": active_tasks,
        "cpu_percent": _get_cpu_percent(),
        "ram_percent": _get_memory_percent(),
        "disk_percent": _get_disk_percent(),
    })


@require_role("admin")
async def get_config(request: web.Request) -> web.Response:
    """Read the server config (sanitized — no secrets)."""
    config_path = _sygen_home() / "config" / "config.json"
    data = _read_json(config_path)
    if data is None:
        return _ok({})
    # Remove secrets
    sanitized = {}
    secret_keys = {"token", "bot_token", "api_key", "secret", "password", "jwt_secret"}
    for section_name, section_val in data.items():
        if isinstance(section_val, dict):
            sanitized[section_name] = {
                k: "***" if any(s in k.lower() for s in secret_keys) else v
                for k, v in section_val.items()
            }
        else:
            sanitized[section_name] = section_val
    return _ok(sanitized)


@require_role("operator")
async def get_logs(request: web.Request) -> web.Response:
    # Safe int parsing (#17)
    try:
        lines = int(request.query.get("lines", "100"))
    except (ValueError, TypeError):
        lines = 100
    lines = min(max(lines, 1), 5000)

    agent = request.query.get("agent", "main")

    # Validate agent name to prevent path traversal (#1)
    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name (only alphanumeric, hyphens, and underscores allowed)", 400)

    # Validate agent against allowed_agents
    allowed = _get_allowed_agents(request)
    if allowed and agent not in allowed:
        return _err(f"log file for agent '{agent}' not found", 404)

    log_path = _sygen_home() / "logs" / f"{agent}.log"
    if not log_path.is_file():
        return _err(f"log file for agent '{agent}' not found", 404)

    # Read only last N lines without loading entire file (#9)
    result = _read_last_lines(log_path, lines)

    return _ok({"agent": agent, "lines": result})


# ---------------------------------------------------------------------------
# Users (RBAC management)
# ---------------------------------------------------------------------------

_USERNAME_RE = re.compile(r"^[a-zA-Z0-9_.-]{2,50}$")

# Lock for users.json operations
_users_lock: asyncio.Lock | None = None


async def _get_users_lock() -> asyncio.Lock:
    global _users_lock
    if _users_lock is None:
        _users_lock = asyncio.Lock()
    return _users_lock


def _validate_allowed_agents(allowed_agents: list[Any]) -> str | None:
    """Validate allowed_agents items. Returns error message or None."""
    for item in allowed_agents:
        if not isinstance(item, str):
            return "allowed_agents items must be strings"
        if not _AGENT_NAME_RE.match(item):
            return f"invalid agent name in allowed_agents: '{item}'"
    return None


@require_role("admin")
async def get_users(request: web.Request) -> web.Response:
    """List all users (passwords excluded)."""
    users = _read_users()
    safe = []
    for u in users:
        safe.append({
            "username": u.get("username"),
            "role": u.get("role", "viewer"),
            "display_name": u.get("display_name", ""),
            "allowed_agents": u.get("allowed_agents", []),
            "active": u.get("active", True),
            "created_at": u.get("created_at"),
        })
    return _ok(safe)


@require_role("admin")
async def create_user(request: web.Request) -> web.Response:
    """Create a new user."""
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    username = str(body.get("username", "")).strip()
    password = str(body.get("password", ""))
    role = str(body.get("role", "viewer"))
    display_name = str(body.get("display_name", username))
    allowed_agents = body.get("allowed_agents", [])

    if not username or not _USERNAME_RE.match(username):
        return _err("invalid username (2-50 chars, alphanumeric/._-)")
    if not password or len(password) < 4:
        return _err("password must be at least 4 characters")
    if role not in ROLE_LEVELS:
        return _err(f"invalid role, must be one of: {', '.join(ROLE_LEVELS)}")
    if not isinstance(allowed_agents, list):
        return _err("allowed_agents must be a list")
    agents_err = _validate_allowed_agents(allowed_agents)
    if agents_err:
        return _err(agents_err)

    lock = await _get_users_lock()
    async with lock:
        users = _read_users()
        if any(u.get("username") == username for u in users):
            return _err(f"user '{username}' already exists", 409)

        user_entry = {
            "username": username,
            "password_hash": hash_password(password),
            "role": role,
            "display_name": display_name,
            "allowed_agents": allowed_agents,
            "active": True,
            "created_at": time.time(),
        }
        users.append(user_entry)
        _write_users(users)

    actor = request.get("jwt_user", {}).get("sub", "unknown")
    write_audit(user=actor, action="user_created", target=username, details=f"role={role}")

    return _ok({
        "username": username,
        "role": role,
        "display_name": display_name,
        "allowed_agents": allowed_agents,
        "active": True,
    })


@require_role("admin")
async def update_user(request: web.Request) -> web.Response:
    """Update user fields (role, display_name, allowed_agents, active, password)."""
    username = request.match_info["username"]
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    actor = request.get("jwt_user", {}).get("sub", "unknown")

    # Prevent admin from demoting or disabling themselves
    if username == actor:
        if "role" in body and str(body["role"]) != "admin":
            return _err("cannot demote yourself", 400)
        if "active" in body and not body["active"]:
            return _err("cannot disable yourself", 400)

    if "role" in body:
        role = str(body["role"])
        if role not in ROLE_LEVELS:
            return _err(f"invalid role, must be one of: {', '.join(ROLE_LEVELS)}")

    if "allowed_agents" in body:
        if not isinstance(body["allowed_agents"], list):
            return _err("allowed_agents must be a list")
        agents_err = _validate_allowed_agents(body["allowed_agents"])
        if agents_err:
            return _err(agents_err)

    if "password" in body:
        password = str(body["password"])
        if len(password) < 4:
            return _err("password must be at least 4 characters")

    lock = await _get_users_lock()
    async with lock:
        users = _read_users()
        target = None
        for u in users:
            if u.get("username") == username:
                target = u
                break

        if target is None:
            return _err(f"user '{username}' not found", 404)

        if "role" in body:
            target["role"] = str(body["role"])

        if "display_name" in body:
            target["display_name"] = str(body["display_name"])

        if "allowed_agents" in body:
            target["allowed_agents"] = body["allowed_agents"]

        if "active" in body:
            target["active"] = bool(body["active"])

        if "password" in body:
            target["password_hash"] = hash_password(str(body["password"]))

        _write_users(users)

    changes = [k for k in ("role", "display_name", "allowed_agents", "active", "password") if k in body]
    write_audit(user=actor, action="user_updated", target=username, details=f"changed={','.join(changes)}")

    return _ok({
        "username": target.get("username"),
        "role": target.get("role"),
        "display_name": target.get("display_name", ""),
        "allowed_agents": target.get("allowed_agents", []),
        "active": target.get("active", True),
    })


@require_role("admin")
async def delete_user(request: web.Request) -> web.Response:
    """Delete a user."""
    username = request.match_info["username"]
    actor = request.get("jwt_user", {}).get("sub", "unknown")

    if username == actor:
        return _err("cannot delete yourself", 400)

    lock = await _get_users_lock()
    async with lock:
        users = _read_users()
        original_len = len(users)
        users = [u for u in users if u.get("username") != username]

        if len(users) == original_len:
            return _err(f"user '{username}' not found", 404)

        _write_users(users)

    write_audit(user=actor, action="user_deleted", target=username)
    return _ok({"deleted": username})


# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------

@require_role("admin")
async def get_audit_log(request: web.Request) -> web.Response:
    """Return recent audit log entries."""
    try:
        limit = int(request.query.get("limit", "200"))
    except (ValueError, TypeError):
        limit = 200
    limit = min(max(limit, 1), 2000)
    entries = read_audit(limit)
    return _ok(entries)


# ---------------------------------------------------------------------------
# Chat Sessions
# ---------------------------------------------------------------------------

_CHAT_SESSIONS_ALLOWED_FIELDS = {"title"}

# Valid session ID: UUID or safe alphanumeric (no path separators)
_SESSION_ID_RE = re.compile(r"^[a-zA-Z0-9_-]+$")


def _chat_sessions_path() -> Path:
    return _sygen_home() / "chat_sessions.json"


def _chat_history_dir() -> Path:
    return _sygen_home() / "chat_history"


def _validate_session_id(session_id: str) -> web.Response | None:
    """Return an error response if session_id is invalid, else None."""
    if not session_id or not _SESSION_ID_RE.match(session_id):
        return _err("invalid session id", 400)
    return None


async def get_chat_sessions(request: web.Request) -> web.Response:
    """List chat sessions, optionally filtered by agent."""
    agent = request.query.get("agent")
    if agent and not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)

    # Validate agent param against allowed_agents
    allowed = _get_allowed_agents(request)
    if agent and allowed and agent not in allowed:
        return _ok([])

    data = _read_json(_chat_sessions_path())
    sessions = (data or {}).get("sessions", [])

    if agent:
        sessions = [s for s in sessions if s.get("agent") == agent]

    # Filter by allowed_agents if no specific agent was requested
    if not agent and allowed:
        sessions = _filter_by_allowed_agents(sessions, allowed, key="agent")

    sessions.sort(key=lambda s: s.get("updated_at", 0), reverse=True)
    return _ok(sessions)


@require_role("operator")
async def create_chat_session(request: web.Request) -> web.Response:
    """Create a new chat session."""
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    agent = str(body.get("agent", "main"))
    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)

    # Enforce per-agent access
    allowed = _get_allowed_agents(request)
    if allowed and agent not in allowed:
        return _err(f"agent '{agent}' is not in your allowed agents", 403)

    title = str(body.get("title", "")).strip()
    now = time.time()

    session = {
        "id": str(uuid.uuid4()),
        "agent": agent,
        "title": title or f"Chat {time.strftime('%Y-%m-%d %H:%M')}",
        "created_at": now,
        "updated_at": now,
    }

    path = _chat_sessions_path()
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path) or {"sessions": []}
        sessions = data.get("sessions", [])
        sessions.append(session)
        data["sessions"] = sessions
        _write_json(path, data)

    return _ok(session)


@require_role("operator")
async def delete_chat_session(request: web.Request) -> web.Response:
    """Delete a chat session and its message history."""
    session_id = request.match_info["id"]
    if err := _validate_session_id(session_id):
        return err

    path = _chat_sessions_path()
    lock = await _with_file_lock(path)
    async with lock:
        data = _read_json(path)
        if data is None:
            return _err("no chat sessions found", 404)

        sessions = data.get("sessions", [])

        # Find the session and enforce per-agent access
        target_session = None
        for s in sessions:
            if s.get("id") == session_id:
                target_session = s
                break
        if target_session is None:
            return _err(f"chat session '{session_id}' not found", 404)

        allowed = _get_allowed_agents(request)
        if allowed and target_session.get("agent") not in allowed:
            return _err(f"chat session '{session_id}' not found", 404)

        sessions = [s for s in sessions if s.get("id") != session_id]
        data["sessions"] = sessions
        _write_json(path, data)

    # Remove message history file if it exists
    history_file = _chat_history_dir() / f"{session_id}.json"
    if history_file.is_file():
        try:
            history_file.unlink()
        except OSError:
            pass

    return _ok({"deleted": session_id})


async def get_chat_messages(request: web.Request) -> web.Response:
    """Get message history for a chat session."""
    session_id = request.match_info["id"]
    if err := _validate_session_id(session_id):
        return err

    # Verify session exists and enforce per-agent access
    data = _read_json(_chat_sessions_path())
    sessions = (data or {}).get("sessions", [])
    target_session = next((s for s in sessions if s.get("id") == session_id), None)
    if target_session is None:
        return _err(f"chat session '{session_id}' not found", 404)

    allowed = _get_allowed_agents(request)
    if allowed and target_session.get("agent") not in allowed:
        return _err(f"chat session '{session_id}' not found", 404)

    history_file = _chat_history_dir() / f"{session_id}.json"
    messages = _read_json(history_file)
    if messages is None:
        return _ok([])

    msg_list = messages.get("messages", []) if isinstance(messages, dict) else messages
    return _ok(msg_list)


@require_role("operator")
async def save_chat_message(request: web.Request) -> web.Response:
    """Save a message to a chat session's history."""
    session_id = request.match_info["id"]
    if err := _validate_session_id(session_id):
        return err

    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    # Verify session exists and enforce per-agent access
    sessions_data = _read_json(_chat_sessions_path())
    sessions = (sessions_data or {}).get("sessions", [])
    target_session = next((s for s in sessions if s.get("id") == session_id), None)
    if target_session is None:
        return _err(f"chat session '{session_id}' not found", 404)

    allowed = _get_allowed_agents(request)
    if allowed and target_session.get("agent") not in allowed:
        return _err(f"chat session '{session_id}' not found", 404)

    messages = body.get("messages")
    if not isinstance(messages, list):
        return _err("'messages' must be a list")

    history_dir = _chat_history_dir()
    history_dir.mkdir(parents=True, exist_ok=True)
    history_file = history_dir / f"{session_id}.json"

    lock = await _with_file_lock(history_file)
    async with lock:
        _write_json(history_file, {"messages": messages})

    # Update session's updated_at timestamp
    sessions_path = _chat_sessions_path()
    sessions_lock = await _with_file_lock(sessions_path)
    async with sessions_lock:
        data = _read_json(sessions_path) or {"sessions": []}
        for s in data.get("sessions", []):
            if s.get("id") == session_id:
                s["updated_at"] = time.time()
                break
        _write_json(sessions_path, data)

    return _ok({"saved": len(messages)})


# ---------------------------------------------------------------------------
# Activity Feed (unified)
# ---------------------------------------------------------------------------


async def get_activity(request: web.Request) -> web.Response:
    """Return a unified activity feed from audit log, tasks, and sessions."""
    try:
        limit = int(request.query.get("limit", "50"))
    except (ValueError, TypeError):
        limit = 50
    limit = min(max(limit, 1), 200)

    events: list[dict[str, Any]] = []

    # 1. Audit log events (login, user CRUD)
    try:
        audit_entries = read_audit(100)
        for entry in audit_entries:
            action = entry.get("action", "")
            user = entry.get("user", "")
            target = entry.get("target", "")
            details = entry.get("details", "")

            if action == "login":
                message = f"User '{user}' logged in"
                event_type = "login"
            elif action == "user_created":
                message = f"User '{target}' created by {user}"
                event_type = "user"
            elif action == "user_updated":
                message = f"User '{target}' updated by {user}"
                event_type = "user"
            elif action == "user_deleted":
                message = f"User '{target}' deleted by {user}"
                event_type = "user"
            else:
                message = f"{action}: {target}" if target else action
                event_type = "system"

            events.append({
                "type": event_type,
                "message": message,
                "agent": "",
                "timestamp": entry.get("ts", ""),
                "details": details,
            })
    except Exception:
        pass

    # 2. Task events (completions/failures)
    try:
        tasks_data = _read_json(_sygen_home() / "tasks.json")
        if tasks_data:
            tasks_list = tasks_data.get("tasks", []) if isinstance(tasks_data, dict) else tasks_data
            for task in tasks_list:
                status = task.get("status", "")
                name = task.get("name", task.get("task_id", "unknown"))
                agent = task.get("parent_agent", task.get("agent", ""))

                if status in ("done", "completed"):
                    message = f"Task '{name}' completed"
                    event_type = "task"
                elif status == "failed":
                    message = f"Task '{name}' failed"
                    event_type = "task"
                elif status == "running":
                    message = f"Task '{name}' started"
                    event_type = "task"
                elif status == "cancelled":
                    message = f"Task '{name}' cancelled"
                    event_type = "task"
                else:
                    continue

                ts = task.get("completed_at") or task.get("created_at", 0)
                if isinstance(ts, (int, float)) and ts > 0:
                    ts_str = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(ts))
                else:
                    ts_str = str(ts)

                events.append({
                    "type": event_type,
                    "message": message,
                    "agent": agent,
                    "timestamp": ts_str,
                    "details": task.get("error", ""),
                })
    except Exception:
        pass

    # 3. Cron job events
    try:
        cron_data = _read_json(_sygen_home() / "cron_jobs.json")
        if cron_data:
            jobs = cron_data.get("jobs", []) if isinstance(cron_data, dict) else cron_data
            for job in jobs:
                last_run = job.get("last_run", "")
                if last_run and last_run != "-":
                    job_name = job.get("title", job.get("id", "unknown"))
                    agent = job.get("agent", "")
                    events.append({
                        "type": "cron",
                        "message": f"Cron '{job_name}' executed",
                        "agent": agent,
                        "timestamp": last_run,
                        "details": "",
                    })
    except Exception:
        pass

    # 4. Agent session events
    try:
        sessions_data = _read_json(_sygen_home() / "sessions.json")
        if sessions_data and isinstance(sessions_data, dict):
            for session_id, session in sessions_data.items():
                if isinstance(session, dict):
                    agent = session.get("agent", session_id)
                    started = session.get("started_at", session.get("created_at", ""))
                    if started:
                        if isinstance(started, (int, float)) and started > 0:
                            ts_str = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(started))
                        else:
                            ts_str = str(started)
                        events.append({
                            "type": "agent",
                            "message": f"Agent session '{session_id}' active",
                            "agent": agent,
                            "timestamp": ts_str,
                            "details": "",
                        })
    except Exception:
        pass

    # Filter by allowed_agents
    allowed = _get_allowed_agents(request)
    if allowed:
        events = [e for e in events if not e.get("agent") or e["agent"] in allowed]

    # Sort by timestamp descending
    events.sort(key=lambda e: e.get("timestamp", ""), reverse=True)

    return _ok(events[:limit])


# ---------------------------------------------------------------------------
# Export / Import configuration
# ---------------------------------------------------------------------------


@require_role("admin")
async def export_config(request: web.Request) -> web.Response:
    """Export cron_jobs, webhooks, and users (without password_hash) as a single JSON."""
    home = _sygen_home()

    cron_data = _read_json(home / "cron_jobs.json")
    cron_jobs = (cron_data.get("jobs", []) if isinstance(cron_data, dict) else cron_data) if cron_data else []

    wh_data = _read_json(home / "webhooks.json")
    webhooks = (wh_data.get("webhooks", []) if isinstance(wh_data, dict) else wh_data) if wh_data else []

    users_raw = _read_users()
    _user_secret_fields = {"password_hash", "totp_secret", "totp_enabled"}
    users_safe = []
    for u in users_raw:
        users_safe.append({
            k: v for k, v in u.items() if k not in _user_secret_fields
        })

    export_payload = {
        "version": 1,
        "exported_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "cron_jobs": cron_jobs,
        "webhooks": webhooks,
        "users": users_safe,
    }
    return _ok(export_payload)


@require_role("admin")
async def import_config(request: web.Request) -> web.Response:
    """Import configuration (merge mode: add new items, skip existing)."""
    try:
        body = await request.json()
    except (json.JSONDecodeError, ValueError):
        return _err("invalid JSON body")

    if not isinstance(body, dict):
        return _err("expected a JSON object")
    if body.get("version") != 1:
        return _err("unsupported export version (expected 1)")
    for key in ("cron_jobs", "webhooks", "users"):
        if key in body and not isinstance(body[key], list):
            return _err(f"'{key}' must be a list")

    import_cron = body.get("cron_jobs", [])
    import_webhooks = body.get("webhooks", [])
    import_users = body.get("users", [])

    home = _sygen_home()
    summary = {"cron_jobs_added": 0, "webhooks_added": 0, "users_added": 0, "skipped": 0}

    # --- Cron jobs (merge) ---
    if import_cron:
        cron_path = home / "cron_jobs.json"
        lock = await _with_file_lock(cron_path)
        async with lock:
            cron_data = _read_json(cron_path) or {"jobs": []}
            jobs = cron_data.get("jobs", []) if isinstance(cron_data, dict) else cron_data
            existing_ids = {j.get("id") for j in jobs}
            for cj in import_cron:
                if not isinstance(cj, dict) or not cj.get("id"):
                    summary["skipped"] += 1
                    continue
                if cj["id"] in existing_ids:
                    summary["skipped"] += 1
                    continue
                # Validate schedule if present
                schedule = str(cj.get("schedule", ""))
                if schedule and not _CRON_SCHEDULE_RE.match(schedule):
                    summary["skipped"] += 1
                    continue
                # Filter to allowed fields only
                filtered_cj = _filter_fields(cj, _CRON_ALLOWED_FIELDS)
                jobs.append(filtered_cj)
                summary["cron_jobs_added"] += 1
            if isinstance(cron_data, dict):
                cron_data["jobs"] = jobs
            else:
                cron_data = {"jobs": jobs}
            _write_json(cron_path, cron_data)

    # --- Webhooks (merge) ---
    if import_webhooks:
        wh_path = home / "webhooks.json"
        lock = await _with_file_lock(wh_path)
        async with lock:
            wh_data = _read_json(wh_path) or {"webhooks": []}
            whs = wh_data.get("webhooks", []) if isinstance(wh_data, dict) else wh_data
            existing_ids = {w.get("id") for w in whs}
            for wh in import_webhooks:
                if not isinstance(wh, dict) or not wh.get("id"):
                    summary["skipped"] += 1
                    continue
                if wh["id"] in existing_ids:
                    summary["skipped"] += 1
                    continue
                # Filter to allowed fields only
                filtered_wh = _filter_fields(wh, _WEBHOOK_ALLOWED_FIELDS)
                whs.append(filtered_wh)
                summary["webhooks_added"] += 1
            if isinstance(wh_data, dict):
                wh_data["webhooks"] = whs
            else:
                wh_data = {"webhooks": whs}
            _write_json(wh_path, wh_data)

    # --- Users (merge, skip existing usernames) ---
    if import_users:
        # Allowed user fields during import (strip secrets and sensitive fields)
        _import_user_allowed = {"username", "role", "display_name", "allowed_agents"}
        lock = await _get_users_lock()
        async with lock:
            users = _read_users()
            existing_usernames = {u.get("username") for u in users}
            for u in import_users:
                if not isinstance(u, dict) or not u.get("username"):
                    summary["skipped"] += 1
                    continue
                username = str(u["username"]).strip()
                if not _USERNAME_RE.match(username):
                    summary["skipped"] += 1
                    continue
                if username in existing_usernames:
                    summary["skipped"] += 1
                    continue
                # Only allow safe fields
                entry = {k: v for k, v in u.items() if k in _import_user_allowed}
                entry["username"] = username
                # Validate and constrain role
                role = str(entry.get("role", "viewer"))
                if role not in ROLE_LEVELS:
                    role = "viewer"
                entry["role"] = role
                # Imported users are always inactive (admin must activate manually)
                entry["active"] = False
                entry.setdefault("created_at", time.time())
                # Validate allowed_agents if present
                if "allowed_agents" in entry:
                    if not isinstance(entry["allowed_agents"], list):
                        entry["allowed_agents"] = []
                    else:
                        err = _validate_allowed_agents(entry["allowed_agents"])
                        if err:
                            entry["allowed_agents"] = []
                users.append(entry)
                summary["users_added"] += 1
            _write_users(users)

    jwt_user = request.get("jwt_user", {})
    username = jwt_user.get("sub", "unknown")
    write_audit(
        user=username,
        action="import_config",
        target="system",
        details=json.dumps(summary),
    )

    return _ok(summary)


# ---------------------------------------------------------------------------
# Live log polling
# ---------------------------------------------------------------------------


@require_role("operator")
async def get_logs_poll(request: web.Request) -> web.Response:
    """Return log lines after a given timestamp for live tail polling."""
    agent = request.query.get("agent", "main")

    if not _AGENT_NAME_RE.match(agent):
        return _err("invalid agent name", 400)

    # Validate agent against allowed_agents
    allowed = _get_allowed_agents(request)
    if allowed and agent not in allowed:
        return _ok({"agent": agent, "lines": [], "timestamp": time.time()})

    try:
        after = float(request.query.get("after", "0"))
    except (ValueError, TypeError):
        after = 0

    try:
        lines_limit = int(request.query.get("lines", "200"))
    except (ValueError, TypeError):
        lines_limit = 200
    lines_limit = min(max(lines_limit, 1), 5000)

    log_path = _sygen_home() / "logs" / f"{agent}.log"
    if not log_path.is_file():
        return _ok({"agent": agent, "lines": [], "timestamp": time.time()})

    try:
        mtime = log_path.stat().st_mtime
    except OSError:
        return _ok({"agent": agent, "lines": [], "timestamp": time.time()})

    now = time.time()

    if after > 0 and mtime <= after:
        return _ok({"agent": agent, "lines": [], "timestamp": now})

    result = _read_last_lines(log_path, lines_limit)
    return _ok({"agent": agent, "lines": result, "timestamp": now})


# ---------------------------------------------------------------------------
# Agent Metrics
# ---------------------------------------------------------------------------


def _get_traces_db_path() -> Path:
    return _sygen_home() / "logs" / "traces.db"


def _query_agent_metrics(db_path: Path, agent_name: str, since_iso: str) -> dict[str, Any]:
    """Query aggregated metrics for an agent from traces.db."""
    empty: dict[str, Any] = {
        "total_executions": 0,
        "avg_duration_seconds": 0.0,
        "error_count": 0,
        "success_rate": 100.0,
        "last_active": None,
        "tokens_used": None,
    }
    if not db_path.is_file():
        return empty

    try:
        conn = sqlite3.connect(str(db_path), timeout=5)
        conn.execute("PRAGMA journal_mode=WAL")
    except sqlite3.Error:
        return empty

    try:
        row = conn.execute(
            "SELECT COUNT(*), COALESCE(AVG(duration_sec), 0), "
            "SUM(CASE WHEN status != 'ok' THEN 1 ELSE 0 END), "
            "MAX(finished) "
            "FROM traces WHERE agent_name = ? AND started >= ?",
            (agent_name, since_iso),
        ).fetchone()

        if not row or row[0] == 0:
            return empty

        total = row[0]
        avg_dur = round(row[1], 2)
        errors = row[2] or 0
        last_active = row[3]
        success_rate = round(((total - errors) / total) * 100, 1) if total > 0 else 100.0

        return {
            "total_executions": total,
            "avg_duration_seconds": avg_dur,
            "error_count": errors,
            "success_rate": success_rate,
            "last_active": last_active,
            "tokens_used": None,
        }
    except sqlite3.Error:
        return empty
    finally:
        conn.close()


async def get_agent_metrics(request: web.Request) -> web.Response:
    """Return aggregated metrics for an agent over a time period."""
    name = request.match_info["name"]

    allowed = _get_allowed_agents(request)
    if allowed and name not in allowed:
        return _err(f"agent '{name}' not found", 404)

    period = request.query.get("period", "24h")
    now = datetime.now(timezone.utc)
    if period == "7d":
        since = now - timedelta(days=7)
    else:
        since = now - timedelta(hours=24)

    db_path = _get_traces_db_path()
    metrics = await asyncio.to_thread(
        _query_agent_metrics, db_path, name, since.isoformat(),
    )
    metrics["period"] = period
    return _ok(metrics)


def _query_agent_metrics_history(
    db_path: Path, agent_name: str, since_iso: str, group_format: str,
) -> list[dict[str, Any]]:
    """Query time-bucketed metrics history for charts."""
    if not db_path.is_file():
        return []

    try:
        conn = sqlite3.connect(str(db_path), timeout=5)
        conn.execute("PRAGMA journal_mode=WAL")
    except sqlite3.Error:
        return []

    try:
        rows = conn.execute(
            "SELECT strftime(?, started) AS bucket, "
            "COUNT(*) AS executions, "
            "SUM(CASE WHEN status != 'ok' THEN 1 ELSE 0 END) AS errors, "
            "ROUND(AVG(duration_sec), 2) AS avg_duration "
            "FROM traces WHERE agent_name = ? AND started >= ? "
            "GROUP BY bucket ORDER BY bucket",
            (group_format, agent_name, since_iso),
        ).fetchall()

        return [
            {
                "timestamp": r[0],
                "executions": r[1],
                "errors": r[2] or 0,
                "avg_duration": r[3] or 0.0,
            }
            for r in rows
        ]
    except sqlite3.Error:
        return []
    finally:
        conn.close()


async def get_agent_metrics_history(request: web.Request) -> web.Response:
    """Return time-bucketed metrics for chart rendering."""
    name = request.match_info["name"]

    allowed = _get_allowed_agents(request)
    if allowed and name not in allowed:
        return _err(f"agent '{name}' not found", 404)

    period = request.query.get("period", "24h")
    now = datetime.now(timezone.utc)
    if period == "7d":
        since = now - timedelta(days=7)
        group_format = "%Y-%m-%d"
    else:
        since = now - timedelta(hours=24)
        group_format = "%Y-%m-%dT%H:00"

    db_path = _get_traces_db_path()
    history = await asyncio.to_thread(
        _query_agent_metrics_history, db_path, name, since.isoformat(), group_format,
    )
    return _ok(history)


# ---------------------------------------------------------------------------
# Route registration
# ---------------------------------------------------------------------------

def setup_rest_routes(app: web.Application) -> None:
    """Register all REST API routes on the given aiohttp app.

    Auth is handled by the JWTAuth middleware already on the app.
    """
    # Agents
    app.router.add_get("/api/agents", get_agents)
    app.router.add_get("/api/agents/{name}/metrics", get_agent_metrics)
    app.router.add_get("/api/agents/{name}/metrics/history", get_agent_metrics_history)
    app.router.add_get("/api/agents/{name}", get_agent)

    # Cron
    app.router.add_get("/api/cron", get_cron_jobs)
    app.router.add_post("/api/cron", create_cron_job)
    app.router.add_put("/api/cron/{id}", update_cron_job)
    app.router.add_delete("/api/cron/{id}", delete_cron_job)
    app.router.add_post("/api/cron/{id}/run", run_cron_job)

    # Webhooks
    app.router.add_get("/api/webhooks", get_webhooks)
    app.router.add_post("/api/webhooks", create_webhook)
    app.router.add_put("/api/webhooks/{id}", update_webhook)
    app.router.add_delete("/api/webhooks/{id}", delete_webhook)
    app.router.add_post("/api/webhooks/{id}/verify", verify_webhook_signature)

    # Tasks
    app.router.add_get("/api/tasks", get_tasks)
    app.router.add_get("/api/tasks/{id}", get_task)
    app.router.add_post("/api/tasks", create_task)
    app.router.add_post("/api/tasks/{id}/cancel", cancel_task)

    # Sessions
    app.router.add_get("/api/sessions", get_sessions)
    app.router.add_delete("/api/sessions/{id}", delete_session)

    # Memory
    app.router.add_get("/api/memory", get_memory)
    app.router.add_put("/api/memory", update_memory)
    app.router.add_get("/api/memory/modules", get_memory_modules)
    app.router.add_get("/api/memory/modules/{filename}", get_memory_module)
    app.router.add_put("/api/memory/modules/{filename}", update_memory_module)

    # System
    app.router.add_get("/api/system/status", get_system_status)
    app.router.add_get("/api/config", get_config)
    app.router.add_get("/api/logs", get_logs)

    # Users (RBAC)
    app.router.add_get("/api/users", get_users)
    app.router.add_post("/api/users", create_user)
    app.router.add_put("/api/users/{username}", update_user)
    app.router.add_delete("/api/users/{username}", delete_user)

    # Chat sessions
    app.router.add_get("/api/chat/sessions", get_chat_sessions)
    app.router.add_post("/api/chat/sessions", create_chat_session)
    app.router.add_delete("/api/chat/sessions/{id}", delete_chat_session)
    app.router.add_get("/api/chat/sessions/{id}/messages", get_chat_messages)
    app.router.add_put("/api/chat/sessions/{id}/messages", save_chat_message)

    # Audit log
    app.router.add_get("/api/audit", get_audit_log)

    # Activity feed (unified)
    app.router.add_get("/api/activity", get_activity)

    # Export / Import
    app.router.add_get("/api/export", export_config)
    app.router.add_post("/api/import", import_config)

    # Live log polling
    app.router.add_get("/api/logs/poll", get_logs_poll)
