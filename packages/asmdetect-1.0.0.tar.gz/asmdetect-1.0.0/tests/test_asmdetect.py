"""34 unit tests for asmdetect library."""
import json, os, tempfile
import pandas as pd
import pytest
from asmdetect.preprocessing import (_is_valid_opcode, clean_text_input,
                                     extract_from_dataframe, extract_from_file)
from asmdetect.result  import DetectionResult
from asmdetect.version import __version__

def _make(prediction="malware", label=1, mal_p=0.95, risk="HIGH"):
    return DetectionResult(source="test.csv", prediction=prediction,
        label=label, confidence=mal_p, malware_probability=mal_p,
        benign_probability=round(1-mal_p,4), risk_level=risk,
        input_tokens=200, truncated=False, threshold_used=0.62,
        model_id="Swarnadharshini/codebert-malware-detector")

class TestDetectionResult:
    def test_is_malware_true(self):
        r = _make(); assert r.is_malware and not r.is_benign
    def test_is_benign_true(self):
        r = _make("benign",0,0.2,"LOW"); assert r.is_benign and not r.is_malware
    def test_to_dict_fields(self):
        d = _make().to_dict()
        for k in ["source","prediction","label","confidence","malware_probability",
                  "benign_probability","risk_level","input_tokens","truncated",
                  "threshold_used","model_id"]:
            assert k in d
    def test_to_json_roundtrip(self):
        assert json.loads(_make().to_json())["prediction"] == "malware"
    def test_str_contains_prediction(self):
        assert "malware" in str(_make()).lower()
    def test_repr_contains_class(self):
        assert "DetectionResult" in repr(_make())
    def test_risk_icons(self):
        assert _make(risk="HIGH").risk_icon   == "[HIGH]"
        assert _make(risk="MEDIUM").risk_icon == "[MED]"
        assert _make(risk="LOW").risk_icon    == "[LOW]"

class TestIsValidOpcode:
    def test_plain(self):
        for t in ["push","mov","xor","ret","call","nop"]:
            assert _is_valid_opcode(t)
    def test_att_suffixed(self):
        for t in ["pushl","movl","movq","subl"]:
            assert _is_valid_opcode(t)
    def test_rejects_sections(self):
        for t in [".text",".data",".bss"]:
            assert not _is_valid_opcode(t)
    def test_rejects_hex(self):
        for t in ["30","7d","00","8b","90"]:
            assert not _is_valid_opcode(t)
    def test_accepts_ff(self):
        assert _is_valid_opcode("ff")
    def test_rejects_empty(self):
        assert not _is_valid_opcode("") and not _is_valid_opcode("  ")

class TestCleanTextInput:
    def test_basic(self):
        assert clean_text_input("push mov xor") == "push mov xor"
    def test_uppercase(self):
        assert clean_text_input("PUSH MOV") == "push mov"
    def test_strips_hex(self):
        r = clean_text_input("402000 30 push mov")
        assert "push" in r and "402000" not in r
    def test_empty_raises(self):
        with pytest.raises(ValueError, match="empty"):
            clean_text_input("")
    def test_garbage_raises(self):
        with pytest.raises(ValueError):
            clean_text_input("123 456")
    def test_truncates(self):
        assert len(clean_text_input(" ".join(["mov"]*500)).split()) == 256

class TestExtractFromDataframe:
    def test_malware_format(self):
        df = pd.DataFrame({"Address":["402000:","402003:"],
            "Hex_Opcode":["30 7d","00 00"],"Opcode":["xor","add"]})
        assert extract_from_dataframe(df) == "xor add"
    def test_benign_format(self):
        df = pd.DataFrame({"Opcode":["pushl","movl"]})
        r  = extract_from_dataframe(df)
        assert r and "pushl" in r
    def test_no_col_returns_none(self):
        df = pd.DataFrame({"Address":["0x1"],"Hex":["90"]})
        assert extract_from_dataframe(df) is None
    def test_section_filtered(self):
        df = pd.DataFrame({"Opcode":[".text","push",".data","mov","ret"]})
        r  = extract_from_dataframe(df)
        assert r and ".text" not in r and "push" in r
    def test_case_insensitive_col(self):
        df = pd.DataFrame({"OPCODE":["push","mov"]})
        assert extract_from_dataframe(df) is not None
    def test_whitespace_col(self):
        df = pd.DataFrame({" Opcode ":["push","mov"]})
        assert extract_from_dataframe(df) is not None

class TestExtractFromFile:
    def test_not_found(self):
        with pytest.raises(FileNotFoundError):
            extract_from_file("/nonexistent/x.csv")
    def test_valid_csv(self):
        df = pd.DataFrame({"Opcode":["push","mov","xor","call","ret",
                                     "add","sub","lea","nop","pop"]})
        with tempfile.NamedTemporaryFile(suffix=".csv",mode="w",delete=False) as f:
            df.to_csv(f,index=False); tmp=f.name
        try:
            r = extract_from_file(tmp)
            assert "push" in r
        finally:
            os.unlink(tmp)
    def test_no_opcode_col_raises(self):
        df = pd.DataFrame({"Addr":["0x1"],"Hex":["90"]})
        with tempfile.NamedTemporaryFile(suffix=".csv",mode="w",delete=False) as f:
            df.to_csv(f,index=False); tmp=f.name
        try:
            with pytest.raises(ValueError):
                extract_from_file(tmp)
        finally:
            os.unlink(tmp)

class TestVersion:
    def test_is_string(self): assert isinstance(__version__,str)
    def test_semver(self):
        parts = __version__.split(".")
        assert len(parts)==3 and all(p.isdigit() for p in parts)

class TestPublicAPI:
    def test_imports(self):
        from asmdetect import MalwareDetector, DetectionResult, __version__
        assert all([MalwareDetector, DetectionResult, __version__])
    def test_default_model(self):
        from asmdetect.detector import DEFAULT_MODEL_ID
        assert DEFAULT_MODEL_ID == "Swarnadharshini/codebert-malware-detector"
    def test_default_threshold(self):
        from asmdetect.detector import DEFAULT_THRESHOLD
        assert 0 < DEFAULT_THRESHOLD < 1
    def test_model_id_in_result(self):
        r = _make()
        assert "Swarnadharshini" in r.model_id
