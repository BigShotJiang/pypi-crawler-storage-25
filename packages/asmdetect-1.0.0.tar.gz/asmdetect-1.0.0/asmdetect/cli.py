import argparse, json, sys, time
from .detector import MalwareDetector, DEFAULT_MODEL_ID, DEFAULT_THRESHOLD
from .version  import __version__

def _print_result(r, use_json=False):
    if use_json:
        print(r.to_json()); return
    icons = {"HIGH":"[HIGH]","MEDIUM":"[MED] ","LOW":"[LOW] "}
    print(f"\n  {'─'*46}")
    print(f"  File      : {r.source}")
    print(f"  Verdict   : {r.prediction.upper()}  {icons.get(r.risk_level,'')}")
    print(f"  Confidence: {r.confidence*100:.2f}%")
    print(f"  Malware P : {r.malware_probability*100:.2f}%")
    print(f"  Tokens    : {r.input_tokens}")
    print(f"  {'─'*46}")

def main():
    p = argparse.ArgumentParser(prog="asmdetect",
        description="Assembly-Level Malware Detector")
    p.add_argument("--file");  p.add_argument("--text")
    p.add_argument("--batch"); p.add_argument("--json", action="store_true")
    p.add_argument("--model",     default=DEFAULT_MODEL_ID)
    p.add_argument("--threshold", type=float, default=DEFAULT_THRESHOLD)
    p.add_argument("--version", action="version", version=f"asmdetect {__version__}")
    args = p.parse_args()
    if not any([args.file, args.text, args.batch]):
        p.print_help(); sys.exit(0)
    det = MalwareDetector.from_pretrained(args.model, args.threshold)
    t0  = time.perf_counter()
    if args.file:
        _print_result(det.predict_file(args.file), args.json)
    elif args.text:
        _print_result(det.predict_text(args.text), args.json)
    elif args.batch:
        results = det.predict_batch(args.batch)
        if args.json:
            print(json.dumps([r.to_dict() for r in results], indent=2))
        else:
            for r in results: _print_result(r)
    print(f"\n  Inference: {(time.perf_counter()-t0)*1000:.0f} ms")

if __name__ == "__main__":
    main()
