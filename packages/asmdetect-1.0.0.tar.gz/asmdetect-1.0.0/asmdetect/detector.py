"""
asmdetect/detector.py  — v2 (efficiency improvements)
------------------------------------------------------
Key improvements over v1:
  1. ONNX Runtime support  — 10x faster CPU inference
  2. Batch inference        — process multiple samples in one forward pass
  3. Result caching         — skip re-scanning identical opcode sequences
  4. Model warm-up          — pre-run a dummy pass on load (no cold-start lag)
  5. Thread-safe loading    — safe for watcher.py multi-thread use
  6. GPU auto-detection     — moves to CUDA automatically if available
"""

from __future__ import annotations

import glob
import hashlib
import os
import threading
import time
from functools import lru_cache
from typing import List

import numpy as np
import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer

from .preprocessing import clean_text_input, extract_from_file
from .result        import DetectionResult

DEFAULT_MODEL_ID  = "Swarnadharshini/codebert-malware-detector"
DEFAULT_THRESHOLD = 0.62
MAX_LENGTH        = 512
RISK_THRESHOLDS   = {"HIGH": 0.80, "MEDIUM": 0.55}

# LRU cache size — caches last N opcode sequences to avoid re-inference
_CACHE_SIZE = 256


class MalwareDetector:
    """
    SOC-ready malware detector — v2 with efficiency improvements.

    New parameters
    --------------
    use_onnx : bool
        Use ONNX Runtime instead of PyTorch for ~10x faster CPU inference.
        Requires: pip install optimum[onnxruntime]
    batch_size : int
        Number of samples per forward pass in predict_batch().
        Default 16 — increase on GPU, keep low on CPU.
    warm_up : bool
        Run a dummy inference pass on model load to eliminate cold-start lag.
        Default True.
    cache_results : bool
        Cache results for identical opcode sequences (LRU, size=256).
        Default True — saves time when same file is scanned repeatedly.
    """

    def __init__(
        self,
        model_id      : str   = DEFAULT_MODEL_ID,
        threshold     : float = DEFAULT_THRESHOLD,
        device        : str   = "auto",
        use_onnx      : bool  = False,
        batch_size    : int   = 16,
        warm_up       : bool  = True,
        cache_results : bool  = True,
    ) -> None:
        self.model_id      = model_id
        self.threshold     = threshold
        self.use_onnx      = use_onnx
        self.batch_size    = batch_size
        self.warm_up       = warm_up
        self.cache_results = cache_results

        self._model     = None
        self._tokenizer = None
        self._lock      = threading.Lock()

        if device == "auto":
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device

        # Result cache keyed by SHA-256 of opcode sequence
        self._cache: dict = {}

    # ── Constructors ──────────────────────────────────────────────────────

    @classmethod
    def from_pretrained(
        cls,
        model_id      : str   = DEFAULT_MODEL_ID,
        threshold     : float = DEFAULT_THRESHOLD,
        device        : str   = "auto",
        use_onnx      : bool  = False,
        batch_size    : int   = 16,
        warm_up       : bool  = True,
        cache_results : bool  = True,
    ) -> "MalwareDetector":
        """
        Load from HuggingFace Hub or local directory.

        Examples
        --------
        # Standard PyTorch (default)
        detector = MalwareDetector.from_pretrained()

        # ONNX Runtime — 10x faster on CPU
        detector = MalwareDetector.from_pretrained(use_onnx=True,
                       model_id="models/codebert-malware-onnx")

        # GPU with large batch
        detector = MalwareDetector.from_pretrained(device="cuda", batch_size=64)
        """
        instance = cls(
            model_id=model_id, threshold=threshold, device=device,
            use_onnx=use_onnx, batch_size=batch_size,
            warm_up=warm_up, cache_results=cache_results,
        )
        instance._load()
        return instance

    # ── Loading ───────────────────────────────────────────────────────────

    def _load(self) -> None:
        with self._lock:
            if self._model is not None:
                return

            print(f"Loading: {self.model_id}  [{self.device.upper()}]"
                  f"{'  [ONNX]' if self.use_onnx else ''}")

            self._tokenizer = AutoTokenizer.from_pretrained(self.model_id)

            if self.use_onnx:
                self._load_onnx()
            else:
                self._load_pytorch()

            if self.warm_up:
                self._warm_up()

            print(f"  Ready. threshold={self.threshold}  cache={self.cache_results}")

    def _load_pytorch(self) -> None:
        self._model = AutoModelForSequenceClassification.from_pretrained(self.model_id)
        self._model.eval()
        if self.device == "cuda":
            self._model = self._model.cuda()
        self._infer_fn = self._infer_pytorch

    def _load_onnx(self) -> None:
        try:
            from optimum.onnxruntime import ORTModelForSequenceClassification
        except ImportError:
            print("WARNING: optimum not installed. Falling back to PyTorch.")
            print("         pip install optimum[onnxruntime]")
            self._load_pytorch()
            return

        # Check for quantized model first (faster)
        q_path = self.model_id + "-quantized"
        if os.path.isdir(q_path):
            self._model = ORTModelForSequenceClassification.from_pretrained(
                q_path, file_name="model_quantized.onnx"
            )
            print(f"  Using quantized ONNX: {q_path}")
        else:
            self._model = ORTModelForSequenceClassification.from_pretrained(
                self.model_id, export=False
            )
        self._infer_fn = self._infer_onnx

    def _warm_up(self) -> None:
        """Run one dummy inference to JIT-compile and warm up the runtime."""
        dummy = "push mov xor call ret add sub nop push mov"
        enc   = self._tokenizer(
            dummy, max_length=MAX_LENGTH,
            truncation=True, padding="max_length", return_tensors="pt"
        )
        if self.use_onnx:
            _ = self._model(**enc)
        else:
            with torch.no_grad():
                if self.device == "cuda":
                    enc = {k: v.cuda() for k, v in enc.items()}
                _ = self._model(**enc)

    def _ensure_loaded(self) -> None:
        if self._model is None:
            self._load()

    # ── Core inference (single sample) ────────────────────────────────────

    def _cache_key(self, text: str) -> str:
        return hashlib.sha256(f"{text}{self.threshold}".encode()).hexdigest()

    def _infer(self, opcode_sequence: str, source: str = "input") -> DetectionResult:
        self._ensure_loaded()

        # Cache check
        if self.cache_results:
            key = self._cache_key(opcode_sequence)
            if key in self._cache:
                cached = self._cache[key]
                return DetectionResult(**{**cached.__dict__, "source": source})

        raw_len = len(
            self._tokenizer(opcode_sequence, truncation=False, padding=False)["input_ids"]
        )
        enc = self._tokenizer(
            opcode_sequence, max_length=MAX_LENGTH,
            truncation=True, padding="max_length", return_tensors="pt"
        )

        if self.use_onnx:
            logits = self._infer_onnx(enc)
        else:
            logits = self._infer_pytorch(enc)

        exp         = np.exp(logits - np.max(logits))
        probs       = exp / exp.sum()
        benign_prob = float(probs[0])
        mal_prob    = float(probs[1])
        label       = 1 if mal_prob >= self.threshold else 0
        prediction  = "malware" if label == 1 else "benign"
        confidence  = mal_prob if label == 1 else benign_prob

        risk = "LOW"
        if mal_prob >= RISK_THRESHOLDS["HIGH"]:   risk = "HIGH"
        elif mal_prob >= RISK_THRESHOLDS["MEDIUM"]: risk = "MEDIUM"

        result = DetectionResult(
            source=source, prediction=prediction, label=label,
            confidence=round(confidence, 4),
            malware_probability=round(mal_prob, 4),
            benign_probability=round(benign_prob, 4),
            risk_level=risk, input_tokens=raw_len,
            truncated=raw_len > MAX_LENGTH,
            threshold_used=self.threshold, model_id=self.model_id,
        )

        # Store in cache
        if self.cache_results:
            if len(self._cache) >= _CACHE_SIZE:
                # Evict oldest entry
                oldest = next(iter(self._cache))
                del self._cache[oldest]
            self._cache[key] = result

        return result

    def _infer_pytorch(self, enc: dict) -> np.ndarray:
        with torch.no_grad():
            if self.device == "cuda":
                enc = {k: v.cuda() for k, v in enc.items()}
            return self._model(**enc).logits.cpu().numpy()[0]

    def _infer_onnx(self, enc: dict) -> np.ndarray:
        return self._model(**enc).logits.numpy()[0]

    # ── Batch inference (NEW — processes multiple samples at once) ─────────

    def _infer_batch_raw(self, sequences: list[str]) -> list[np.ndarray]:
        """Tokenize and run a batch of sequences in one forward pass."""
        self._ensure_loaded()
        encodings = self._tokenizer(
            sequences,
            max_length=MAX_LENGTH, truncation=True,
            padding="max_length", return_tensors="pt"
        )
        if self.use_onnx:
            logits = self._model(**encodings).logits.numpy()
        else:
            with torch.no_grad():
                if self.device == "cuda":
                    encodings = {k: v.cuda() for k, v in encodings.items()}
                logits = self._model(**encodings).logits.cpu().numpy()
        return [logits[i] for i in range(len(sequences))]

    # ── Public API ────────────────────────────────────────────────────────

    def predict_file(self, filepath: str) -> DetectionResult:
        opcode_seq = extract_from_file(filepath)
        return self._infer(opcode_seq, source=os.path.basename(filepath))

    def predict_text(self, text: str) -> DetectionResult:
        opcode_seq = clean_text_input(text)
        return self._infer(opcode_seq, source="text_input")

    def predict_batch(
        self,
        folder      : str,
        pattern     : str  = "*.csv",
        sort_by_risk: bool = True,
    ) -> List[DetectionResult]:
        """
        Batch prediction with true batched inference.
        Processes self.batch_size samples per forward pass.
        """
        if not os.path.isdir(folder):
            raise FileNotFoundError(f"Folder not found: {folder}")

        csv_files = glob.glob(os.path.join(folder, pattern))
        if not csv_files:
            raise FileNotFoundError(f"No files matching '{pattern}' in: {folder}")

        self._ensure_loaded()

        # Extract all opcode sequences first
        seqs, sources, errors = [], [], []
        for fpath in csv_files:
            try:
                seq = extract_from_file(fpath)
                seqs.append(seq)
                sources.append(os.path.basename(fpath))
            except Exception as exc:
                errors.append(DetectionResult(
                    source=os.path.basename(fpath), prediction="error", label=-1,
                    confidence=0.0, malware_probability=0.0, benign_probability=0.0,
                    risk_level="LOW", input_tokens=0, truncated=False,
                    threshold_used=self.threshold, model_id=self.model_id,
                ))

        # Batch inference in chunks
        results = list(errors)
        for i in range(0, len(seqs), self.batch_size):
            batch_seqs    = seqs[i:i + self.batch_size]
            batch_sources = sources[i:i + self.batch_size]
            batch_logits  = self._infer_batch_raw(batch_seqs)

            for seq, src, logits in zip(batch_seqs, batch_sources, batch_logits):
                exp        = np.exp(logits - np.max(logits))
                probs      = exp / exp.sum()
                mal_prob   = float(probs[1])
                benign_p   = float(probs[0])
                label      = 1 if mal_prob >= self.threshold else 0
                conf       = mal_prob if label == 1 else benign_p
                risk       = ("HIGH" if mal_prob >= 0.80
                              else "MEDIUM" if mal_prob >= 0.55 else "LOW")
                raw_len    = len(self._tokenizer(seq, truncation=False,
                                                  padding=False)["input_ids"])
                results.append(DetectionResult(
                    source=src, prediction="malware" if label == 1 else "benign",
                    label=label, confidence=round(conf, 4),
                    malware_probability=round(mal_prob, 4),
                    benign_probability=round(benign_p, 4),
                    risk_level=risk, input_tokens=raw_len,
                    truncated=raw_len > MAX_LENGTH,
                    threshold_used=self.threshold, model_id=self.model_id,
                ))

        if sort_by_risk:
            results.sort(key=lambda r: r.malware_probability, reverse=True)
        return results

    # ── Utilities ─────────────────────────────────────────────────────────

    def set_threshold(self, threshold: float) -> None:
        if not 0.0 < threshold < 1.0:
            raise ValueError(f"Threshold must be in (0, 1), got {threshold}")
        self.threshold = threshold

    def clear_cache(self) -> None:
        """Clear the result cache."""
        self._cache.clear()

    def cache_info(self) -> dict:
        return {"size": len(self._cache), "max_size": _CACHE_SIZE}

    def benchmark(self, text: str = "push mov xor call ret", n: int = 10) -> dict:
        self._ensure_loaded()
        times = []
        for _ in range(n):
            t0 = time.perf_counter()
            self.predict_text(text)
            times.append((time.perf_counter() - t0) * 1000)
        return {
            "mean_ms": round(float(np.mean(times)), 2),
            "min_ms" : round(float(np.min(times)),  2),
            "max_ms" : round(float(np.max(times)),  2),
            "runs"   : n,
            "backend": "onnx" if self.use_onnx else "pytorch",
            "device" : self.device,
        }

    def __repr__(self) -> str:
        return (
            f"MalwareDetector(model_id={self.model_id!r}, "
            f"threshold={self.threshold}, device={self.device!r}, "
            f"backend={'onnx' if self.use_onnx else 'pytorch'}, "
            f"cache={len(self._cache)}/{_CACHE_SIZE}, "
            f"loaded={self._model is not None})"
        )
