from .detector     import MalwareDetector
from .result       import DetectionResult
from .version      import __version__
__all__    = ["MalwareDetector", "DetectionResult", "__version__"]
__author__ = "Swarnadharshini S"
__model__  = "Swarnadharshini/codebert-malware-detector"
