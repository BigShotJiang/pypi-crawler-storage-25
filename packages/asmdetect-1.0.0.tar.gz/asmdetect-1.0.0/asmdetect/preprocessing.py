from __future__ import annotations
import os
import pandas as pd

MAX_OPCODES = 256
MIN_OPCODES = 1
_ALPHA = set("abcdefghijklmnopqrstuvwxyz")

def _is_valid_opcode(token: str) -> bool:
    t = token.strip().lower()
    if not t or t[0] not in _ALPHA:
        return False
    return t.isalpha() or t.replace(".","").isalnum()

def extract_from_dataframe(df: pd.DataFrame) -> str | None:
    col = next((c for c in df.columns if c.strip().lower() == "opcode"), None)
    if col is None:
        return None
    ops = (df[col].dropna().astype(str).str.strip().str.lower().tolist())
    ops = [o for o in ops if _is_valid_opcode(o)][:MAX_OPCODES]
    return " ".join(ops) if len(ops) >= MIN_OPCODES else None

def extract_from_file(filepath: str) -> str:
    if not os.path.isfile(filepath):
        raise FileNotFoundError(f"File not found: {filepath}")
    try:
        df = pd.read_csv(filepath, on_bad_lines="skip", low_memory=False)
    except Exception as e:
        raise ValueError(f"Cannot parse CSV: {e}") from e
    seq = extract_from_dataframe(df)
    if not seq:
        raise ValueError(f"No valid opcodes in '{filepath}'.")
    return seq

def clean_text_input(text: str) -> str:
    if not text or not text.strip():
        raise ValueError("Input text is empty.")
    tokens = [t for t in text.strip().lower().split() if _is_valid_opcode(t)]
    tokens = tokens[:MAX_OPCODES]
    if not tokens:
        raise ValueError("No valid opcodes found in input text.")
    return " ".join(tokens)
