from __future__ import annotations
from dataclasses import dataclass, asdict
import json

@dataclass
class DetectionResult:
    source: str
    prediction: str
    label: int
    confidence: float
    malware_probability: float
    benign_probability: float
    risk_level: str
    input_tokens: int
    truncated: bool
    threshold_used: float
    model_id: str

    @property
    def is_malware(self): return self.label == 1
    @property
    def is_benign(self): return self.label == 0
    @property
    def risk_icon(self):
        return {"HIGH":"[HIGH]","MEDIUM":"[MED]","LOW":"[LOW]"}.get(self.risk_level,"")

    def to_dict(self): return asdict(self)
    def to_json(self, indent=2): return json.dumps(self.to_dict(), indent=indent)

    def __str__(self):
        return (f"DetectionResult(\n"
                f"  source     = {self.source}\n"
                f"  prediction = {self.prediction.upper()}  {self.risk_icon} {self.risk_level}\n"
                f"  confidence = {self.confidence*100:.2f}%\n"
                f"  malware_p  = {self.malware_probability*100:.2f}%\n"
                f"  tokens     = {self.input_tokens} (truncated={self.truncated})\n"
                f"  threshold  = {self.threshold_used}\n)")

    def __repr__(self):
        return (f"DetectionResult(prediction={self.prediction!r}, "
                f"confidence={self.confidence:.4f}, "
                f"risk_level={self.risk_level!r})")
