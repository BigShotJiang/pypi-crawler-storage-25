"""
HealChain Async Python SDK v0.2.0
Async/await REST API client using Python's built-in asyncio + urllib.

Works with Python 3.8+ — no external dependencies.
"""

from __future__ import annotations

import asyncio
import json
import urllib.parse
from typing import Any, Callable, Coroutine, Optional, Union

from .client import HealChainError, _to_hex, DEFAULT_API_URL, DEFAULT_POLL_INTERVAL, DEFAULT_POLL_TIMEOUT, DEFAULT_DATA_SHARDS, DEFAULT_PARITY_SHARDS


class AsyncHealChain:
    """
    Async HealChain API client for use with asyncio.

    Example::

        import asyncio
        from healchain import AsyncHealChain

        async def main():
            hc = AsyncHealChain(api_url="https://api.healchain.org")

            # Store data
            result = await hc.store("Hello World", label="my record")
            print(f"Stored as record #{result['record_id']}")

            # Retrieve
            record = await hc.retrieve(result["record_id"])
            print(record["text"])

            await hc.close()

        asyncio.run(main())

    Or use as an async context manager::

        async with AsyncHealChain() as hc:
            result = await hc.store("Hello World")
            record = await hc.retrieve(result["record_id"])
    """

    def __init__(
        self,
        api_url: str = DEFAULT_API_URL,
        *,
        api_key: Optional[str] = None,
        network: str = "auto",
        preference: str = "",
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        poll_timeout: float = DEFAULT_POLL_TIMEOUT,
        data_shards: int = DEFAULT_DATA_SHARDS,
        parity_shards: int = DEFAULT_PARITY_SHARDS,
        timeout: float = 30.0,
    ):
        self.api_url       = api_url.rstrip("/")
        self.api_key       = api_key
        self.network       = network
        self.preference    = preference
        self.poll_interval = poll_interval
        self.poll_timeout  = poll_timeout
        self.data_shards   = data_shards
        self.parity_shards = parity_shards
        self.timeout       = timeout
        self._reader       = None
        self._writer       = None

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    async def close(self):
        """No persistent connections to close — provided for context manager compatibility."""
        pass

    # ── Internal async request ────────────────────────────────────────────────

    async def _request(
        self,
        method: str,
        path: str,
        *,
        body: Optional[dict] = None,
    ) -> Any:
        """Make an async HTTP request using asyncio streams."""
        url_parts = urllib.parse.urlparse(f"{self.api_url}{path}")
        host      = url_parts.hostname
        port      = url_parts.port or (443 if url_parts.scheme == "https" else 80)
        use_ssl   = url_parts.scheme == "https"
        path_qs   = url_parts.path + (f"?{url_parts.query}" if url_parts.query else "")

        body_bytes = json.dumps(body).encode() if body is not None else b""

        headers = {
            "Host":           host,
            "Content-Type":   "application/json",
            "Accept":         "application/json",
            "User-Agent":     "healchain-sdk-python/0.2.0",
            "Content-Length": str(len(body_bytes)),
            "Connection":     "close",
        }
        if self.api_key:
            headers["X-API-Key"] = self.api_key

        header_str = "\r\n".join(f"{k}: {v}" for k, v in headers.items())
        request    = (
            f"{method} {path_qs} HTTP/1.1\r\n"
            f"{header_str}\r\n\r\n"
        ).encode() + body_bytes

        try:
            if use_ssl:
                import ssl
                ctx = ssl.create_default_context()
                reader, writer = await asyncio.wait_for(
                    asyncio.open_connection(host, port, ssl=ctx),
                    timeout=self.timeout,
                )
            else:
                reader, writer = await asyncio.wait_for(
                    asyncio.open_connection(host, port),
                    timeout=self.timeout,
                )
        except (OSError, asyncio.TimeoutError) as exc:
            raise HealChainError(
                f"Network error: {exc}", code="NETWORK_ERROR"
            ) from exc

        try:
            writer.write(request)
            await writer.drain()

            # Read response
            response_bytes = await asyncio.wait_for(
                reader.read(1024 * 1024),  # 1MB max
                timeout=self.timeout,
            )
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass

        # Parse HTTP response
        response_str = response_bytes.decode(errors="replace")
        header_end   = response_str.find("\r\n\r\n")
        if header_end == -1:
            raise HealChainError("Invalid HTTP response", code="PARSE_ERROR")

        header_part  = response_str[:header_end]
        body_part    = response_str[header_end + 4:]
        status_line  = header_part.split("\r\n")[0]
        status_code  = int(status_line.split(" ")[1])

        try:
            parsed = json.loads(body_part) if body_part.strip() else {}
        except json.JSONDecodeError:
            parsed = body_part

        if status_code >= 400:
            msg = (parsed.get("error") if isinstance(parsed, dict) else str(parsed)) or status_line
            raise HealChainError(msg, status=status_code, response=parsed)

        return parsed

    # ── health() ──────────────────────────────────────────────────────────────

    async def health(self) -> dict:
        """Check service health."""
        return await self._request("GET", "/health")

    # ── store() ───────────────────────────────────────────────────────────────

    async def store(
        self,
        data: Union[str, bytes, bytearray],
        *,
        label: str = "sdk upload",
        network: Optional[str] = None,
        preference: Optional[str] = None,
        data_shards: Optional[int] = None,
        parity_shards: Optional[int] = None,
        on_pending: Optional[Callable[[dict], Coroutine]] = None,
        on_fulfilled: Optional[Callable[[dict], Coroutine]] = None,
    ) -> dict:
        """
        Store data on-chain. Awaits oracle fulfillment asynchronously.

        Args:
            data:          Data to store (str or bytes)
            label:         Record label
            network:       Chain name or 'auto' (default)
            preference:    'cheapest' | 'fastest' | 'redundant' | ''
            on_pending:    Async callback when tx submitted
            on_fulfilled:  Async callback when oracle fulfills

        Returns:
            dict with record_id, request_id, tx, chain_id, original_size, encoded_size
        """
        hex_data = _to_hex(data)

        payload = {
            "data":         hex_data,
            "label":        label,
            "network":      network or self.network,
            "preference":   preference if preference is not None else self.preference,
            "dataShards":   data_shards  or self.data_shards,
            "parityShards": parity_shards or self.parity_shards,
        }

        submitted = await self._request("POST", "/storeOnChain", body=payload)

        # Devnet returns synchronously
        if submitted.get("status") == "success" and "recordId" in submitted:
            return self._normalise_store(submitted)

        request_id = submitted.get("requestId")
        tx         = submitted.get("tx")
        if not request_id:
            raise HealChainError("No requestId returned from store", response=submitted)

        if on_pending:
            await on_pending({"request_id": str(request_id), "tx": tx})

        return await self._poll_fulfillment(request_id, tx, on_fulfilled)

    async def _poll_fulfillment(
        self,
        request_id: str,
        tx: str,
        on_fulfilled,
    ) -> dict:
        deadline = asyncio.get_event_loop().time() + self.poll_timeout

        while asyncio.get_event_loop().time() < deadline:
            await asyncio.sleep(self.poll_interval)
            try:
                status = await self._request(
                    "GET",
                    f"/sepoliaStatus?requestId={urllib.parse.quote(str(request_id))}",
                )
            except HealChainError:
                continue

            if status.get("status") == "fulfilled":
                result = {
                    "record_id":    str(status.get("recordId", request_id)),
                    "request_id":   str(request_id),
                    "tx":           tx,
                    "chain_id":     status.get("chainId"),
                    "original_size": status.get("originalSize"),
                    "encoded_size":  status.get("encodedSize"),
                    "total_records": status.get("totalRecords"),
                }
                if on_fulfilled:
                    await on_fulfilled(result)
                return result

        raise HealChainError(
            f"Oracle fulfillment timed out after {self.poll_timeout}s "
            f"(request_id={request_id})",
            code="FULFILLMENT_TIMEOUT",
        )

    @staticmethod
    def _normalise_store(resp: dict) -> dict:
        return {
            "record_id":    str(resp.get("recordId", "")),
            "request_id":   resp.get("requestId"),
            "tx":           resp.get("tx"),
            "chain_id":     resp.get("chainId"),
            "original_size": resp.get("originalSize"),
            "encoded_size":  resp.get("encodedSize"),
        }

    # ── retrieve() ────────────────────────────────────────────────────────────

    async def retrieve(self, record_id: Union[str, int]) -> dict:
        """
        Retrieve a record by ID. Auto-discovers chain from GlobalRegistry.

        Returns:
            dict with record_id, data, text, bytes, chain_id
        """
        path   = f"/retrieve?id={urllib.parse.quote(str(record_id))}"
        result = await self._request("GET", path)
        return {
            "record_id": str(result.get("recordId", record_id)),
            "data":      result.get("data"),
            "text":      result.get("text"),
            "bytes":     result.get("bytes"),
            "chain_id":  result.get("chainId"),
        }

    # ── get_metadata() ────────────────────────────────────────────────────────

    async def get_metadata(self, record_id: Union[str, int]) -> dict:
        """Get record metadata without fetching the full data."""
        path   = f"/getMetadata?id={urllib.parse.quote(str(record_id))}"
        result = await self._request("GET", path)
        return {
            "record_id":    str(result.get("recordId", record_id)),
            "label":        result.get("label"),
            "owner":        result.get("owner"),
            "original_size": result.get("originalSize"),
            "encoded_size":  result.get("encodedSize"),
            "data_shards":   result.get("dataShards"),
            "parity_shards": result.get("parityShards"),
            "timestamp":     result.get("timestamp"),
            "data_hash":     result.get("dataHash"),
        }

    # ── list() ────────────────────────────────────────────────────────────────

    async def chain_scores(self) -> dict:
        """
        Get scored and ranked list of all available chains.
        No API key required — public endpoint.

        :returns: dict with 'status' and 'chains' list sorted by score descending
        :rtype: dict
        :raises HealChainError: on network error
        """
        return await self._get("/chainScores")

    async def list(self, page: int = 0, limit: int = 10) -> dict:
        """
        List records with pagination.

        Returns:
            dict with records, total, pages, page, limit
        """
        path   = f"/listRecords?page={page}&limit={limit}"
        result = await self._request("GET", path)
        return {
            "records": result.get("records", []),
            "total":   result.get("total", 0),
            "pages":   result.get("pages", 1),
            "page":    result.get("page", page),
            "limit":   result.get("limit", limit),
        }

   # ── get_billing_balance() ─────────────────────────────────────────────────

    async def get_billing_balance(self, wallet_address: str) -> dict:
        """Get credit balances for a wallet. No API key required."""
        path = f"/billing/balance?wallet={urllib.parse.quote(wallet_address)}"
        return await self._request("GET", path)

    # ── create_checkout() ─────────────────────────────────────────────────────

    async def create_checkout(self, wallet_address: str, amount_cents: int) -> dict:
        """Create a Stripe Checkout session for topping up credits."""
        return await self._request("POST", "/checkout/create", body={
            "wallet_address": wallet_address,
            "amount_cents":   amount_cents,
        })

    # ── request_testnet_credits() ─────────────────────────────────────────────

    async def request_testnet_credits(self, wallet_address: str) -> dict:
        """Request free testnet credits ($1.00 per wallet per 24 hours)."""
        return await self._request("POST", "/testnet/requestCredits", body={
            "wallet_address": wallet_address,
        })

    # ── store_many() ──────────────────────────────────────────────────────────

    async def store_many(
        self,
        items: list[tuple[Union[str, bytes], str]],
        *,
        network: Optional[str] = None,
        preference: Optional[str] = None,
        concurrency: int = 3,
    ) -> list[dict]:
        """
        Store multiple records concurrently.

        Args:
            items:       List of (data, label) tuples
            network:     Override network for all stores
            concurrency: Max concurrent store operations (default: 3)

        Returns:
            List of store results in the same order as items

        Example::

            results = await hc.store_many([
                ("Hello", "record 1"),
                ("World", "record 2"),
                (b"binary data", "record 3"),
            ])
        """
        semaphore = asyncio.Semaphore(concurrency)

        async def _store_one(data, label):
            async with semaphore:
                return await self.store(data, label=label, network=network, preference=preference)

        return await asyncio.gather(*[
            _store_one(data, label) for data, label in items
        ])

    # ── retrieve_many() ───────────────────────────────────────────────────────

    async def retrieve_many(
        self,
        record_ids: list[Union[str, int]],
        *,
        concurrency: int = 5,
    ) -> list[dict]:
        """
        Retrieve multiple records concurrently.

        Args:
            record_ids:  List of record IDs
            concurrency: Max concurrent retrieve operations (default: 5)

        Returns:
            List of retrieve results in the same order as record_ids

        Example::

            records = await hc.retrieve_many([0, 1, 2, 3, 4])
            for r in records:
                print(r["text"])
        """
        semaphore = asyncio.Semaphore(concurrency)

        async def _retrieve_one(record_id):
            async with semaphore:
                try:
                    return await self.retrieve(record_id)
                except HealChainError as e:
                    return {"record_id": str(record_id), "error": str(e)}

        return await asyncio.gather(*[
            _retrieve_one(rid) for rid in record_ids
        ])
