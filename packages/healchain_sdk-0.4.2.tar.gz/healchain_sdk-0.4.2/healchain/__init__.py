"""
HealChain Python SDK
Self-healing decentralized storage via Reed-Solomon erasure coding.

Quick start::

    from healchain import HealChain

    hc = HealChain(api_url="https://api.healchain.org")
    result = hc.store("Hello World", label="my record")
    record = hc.retrieve(result["record_id"])
    print(record["text"])  # Hello World
"""

from .client import HealChain, HealChainError
from .async_client import AsyncHealChain

__all__ = ["HealChain", "AsyncHealChain", "HealChainError"]
__version__ = "0.4.2"
