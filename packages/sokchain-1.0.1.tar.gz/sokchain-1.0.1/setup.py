import os
from setuptools import setup, find_packages

# --- Đọc nội dung file README.md để làm mô tả dài (Thực hành tốt) ---
try:
    with open(os.path.join(os.path.dirname(__file__), 'README.md'), encoding='utf-8') as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = 'Thư viện lõi cho hệ sinh thái Sokchain, bao gồm blockchain, ví, và các tác nhân AI.'

# === ĐỊNH NGHĨA CÁC THÔNG SỐ CHÍNH ===
setup(
    # --- Thông tin cơ bản ---
    name="sokchain_decent",
    version="1.0.692",
    author="AIO",
    author_email="admin@sok.io.vn",
    description="Thư viện lõi dùng để chạy node Sokchain và các dịch vụ phụ trợ.",
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://sok.io.vn', # (Tùy chọn) Thêm URL trang chủ dự án
    license='MIT',

    # --- Cấu hình Gói ---
    # Tự động tìm tất cả các gói con (sẽ tìm thấy 'sok')
    packages=find_packages(exclude=['app', 'tests*']),

    # === THƯ VIỆN PHỤ THUỘC (CỰC KỲ QUAN TRỌNG) ===
    # Liệt kê tất cả các thư viện mà gói 'sok' của bạn cần để hoạt động.
    # Khi người dùng chạy 'pip install your_package.whl', pip sẽ tự động cài các thư viện này.
    install_requires=[
        'requests',
        'Flask',
        'Flask-Cors',
        'waitress',
        'cryptography',
        'rich',
        'pynput',
        'pywin32; platform_system=="Windows"', # Chỉ cài trên Windows
        'colorama',
        'plotly',
        'google-generativeai',
        'python-dotenv', # Nếu bạn dùng .env cho API key
        'setuptools',
        'wheel',
        'build'
        'SQLAlchemy'
    ],

    # === Yêu cầu về Môi trường ===
    python_requires='>=3.10', # Nâng phiên bản Python tối thiểu để tương thích với các thư viện mới

    # --- Phân loại (dành cho PyPI) ---
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: System :: Distributed Computing",
    ],
)
