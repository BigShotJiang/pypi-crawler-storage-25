import json
import os
import re
import shutil
import subprocess
import sys

from pathlib import Path
from stat import S_ISFIFO

import rich_click as click
from dotmap import DotMap
from fp.fp import FreeProxy
from jinja2 import Template
from rich.live import Live
from rich.markdown import Markdown
from rich.rule import Rule
from rich.table import Table

from secator.config import CONFIG, ROOT_FOLDER, Config, default_config, config_path, download_files
from secator.click import OrderedGroup
from secator.cli_helper import register_runner
from secator.definitions import ADDONS_ENABLED, ASCII, DEV_PACKAGE, VERSION, STATE_COLORS
from secator.installer import ToolInstaller, fmt_health_table_row, get_health_table, get_version_info, get_distro_config
from secator.output_types import FINDING_TYPES, Info, Warning, Error
from secator.report import Report
from secator.rich import console
from secator.runners import Command, Runner
from secator.loader import get_configs_by_type, discover_tasks
from secator.utils import (
	debug,
	detect_host,
	print_version,
	get_file_timestamp,
	list_reports,
	get_info_from_report_path,
	human_to_timedelta,
	sanitize_folder_name,
	vhs_tap_to_tape,
	trim_gif,
	reduce_gif_frames,
	get_gif_info,
	humanize_date,
)
from contextlib import nullcontext


click.rich_click.USE_RICH_MARKUP = True
click.rich_click.STYLE_ARGUMENT = ''
click.rich_click.STYLE_OPTION_HELP = ''


FINDING_TYPES_LOWER = [c.__name__.lower() for c in FINDING_TYPES]
CONTEXT_SETTINGS = dict(help_option_names=['-h', '-help', '--help'])
TASKS = get_configs_by_type('task')
WORKFLOWS = get_configs_by_type('workflow')
SCANS = get_configs_by_type('scan')
PROFILES = get_configs_by_type('profile')


# -----#
# CLI #
# -----#


@click.group(cls=OrderedGroup, invoke_without_command=True, context_settings=CONTEXT_SETTINGS)
@click.option('--version', '-version', '-v', is_flag=True, default=False)
@click.option('--quiet', '-quiet', '-q', is_flag=True, default=False)
@click.pass_context
def cli(ctx, version, quiet):
	"""Secator CLI."""
	ctx.obj = {'piped_input': S_ISFIFO(os.fstat(0).st_mode), 'piped_output': not sys.stdout.isatty()}
	if not ctx.obj['piped_output'] and not quiet:
		console.print(ASCII, highlight=False)
	if ctx.invoked_subcommand is None:
		if version:
			print_version()
		else:
			ctx.get_help()


# ------#
# TASK #
# ------#


@cli.group(aliases=['x', 't', 'tasks'], invoke_without_command=True)
@click.pass_context
def task(ctx):
	"""Run a task."""
	if ctx.invoked_subcommand is None:
		ctx.get_help()


for config in TASKS:
	register_runner(task, config)

# ----------#
# WORKFLOW #
# ----------#


@cli.group(cls=OrderedGroup, aliases=['w', 'workflows'], invoke_without_command=True)
@click.pass_context
def workflow(ctx):
	"""Run a workflow."""
	if ctx.invoked_subcommand is None:
		ctx.get_help()


for config in WORKFLOWS:
	try:
		register_runner(workflow, config)
	except Exception as e:
		console.print(Warning(message=f'Skipping workflow {config.name!r}: {e}'))


# ------#
# SCAN #
# ------#


@cli.group(cls=OrderedGroup, aliases=['s', 'scans'], invoke_without_command=True)
@click.pass_context
def scan(ctx):
	"""Run a scan."""
	if ctx.invoked_subcommand is None:
		ctx.get_help()


for config in SCANS:
	try:
		register_runner(scan, config)
	except Exception as e:
		console.print(Warning(message=f'Skipping scan {config.name!r}: {e}'))


# --------#
# WORKER #
# --------#


@cli.command(name='worker', context_settings=dict(ignore_unknown_options=True), aliases=['wk'])
@click.option('-n', '--hostname', type=str, default='runner', help='Celery worker hostname (unique).')
@click.option('-c', '--concurrency', type=int, default=100, help='Number of child processes processing the queue.')
@click.option('-r', '--reload', is_flag=True, help='Autoreload Celery on code changes.')
@click.option('-Q', '--queue', type=str, default='', help='Listen to a specific queue.')
@click.option('-P', '--pool', type=str, default='gevent', help='Pool implementation.')
@click.option('--quiet', is_flag=True, default=False, help='Quiet mode.')
@click.option('--loglevel', type=str, default='INFO', help='Log level.')
@click.option('--check', is_flag=True, help='Check if Celery worker is alive.')
@click.option('--dev', is_flag=True, help='Start a worker in dev mode (celery multi).')
@click.option('--stop', is_flag=True, help='Stop a worker in dev mode (celery multi).')
@click.option('--show', is_flag=True, help='Show command (celery multi).')
@click.option('--use-command-runner', is_flag=True, default=False, help='Use command runner to run the command.')
@click.option('--without-gossip', is_flag=True)
@click.option('--without-mingle', is_flag=True)
@click.option('--without-heartbeat', is_flag=True)
def worker(hostname, concurrency, reload, queue, pool, quiet, loglevel, check, dev, stop, show, use_command_runner, without_gossip, without_mingle, without_heartbeat):  # noqa: E501
	"""Run a worker."""

	# Check Celery addon is installed
	if not ADDONS_ENABLED['worker']:
		console.print(Error(message='Missing worker addon: please run "secator install addons worker".'))
		sys.exit(1)

	# Check broken / backend addon is installed
	broker_protocol = CONFIG.celery.broker_url.split('://')[0]
	backend_protocol = CONFIG.celery.result_backend.split('://')[0]
	if CONFIG.celery.broker_url and (broker_protocol == 'redis' or backend_protocol == 'redis') and not ADDONS_ENABLED['redis']:  # noqa: E501
		console.print(Error(message='Missing redis addon: please run "secator install addons redis".'))
		sys.exit(1)

	# Debug Celery config
	from secator.celery import app, is_celery_worker_alive

	debug('conf', obj=dict(app.conf), obj_breaklines=True, sub='celery.app')
	debug('registered tasks', obj=list(app.tasks.keys()), obj_breaklines=True, sub='celery.app')

	if check:
		is_celery_worker_alive()
		return

	if not queue:
		queue = 'small,medium,large,extra_large,poll,' + ','.join(set([r['queue'] for r in app.conf.task_routes.values()]))

	app_str = 'secator.celery.app'
	celery = f'{sys.executable} -m celery'
	if quiet:
		celery += ' --quiet'

	if dev:
		subcmd = 'stop' if stop else 'show' if show else 'start'
		logfile = '%n.log'
		pidfile = '%n.pid'
		queues = '-Q:1 celery -Q:2 small -Q:3 medium -Q:4 large -Q:5 extra_large'
		concur = '-c:1 10 -c:2 100 -c:3 50 -c:4 20 -c:5 4'
		pool = 'gevent'
		cmd = f'{celery} -A {app_str} multi {subcmd} 5 {queues} -P {pool} {concur} --logfile={logfile} --pidfile={pidfile}'
	else:
		cmd = f'{celery} -A {app_str} worker -n {hostname} -Q {queue}'

	cmd += f' -P {pool}' if pool else ''
	cmd += f' -c {concurrency}' if concurrency else ''
	cmd += f' -l {loglevel}' if loglevel else ''
	cmd += ' --without-mingle' if without_mingle else ''
	cmd += ' --without-gossip' if without_gossip else ''
	cmd += ' --without-heartbeat' if without_heartbeat else ''

	if reload:
		# Check Celery addon is installed
		if not ADDONS_ENABLED['dev']:
			console.print(Error(message='Missing dev addon: please run "secator install addons dev".'))
			sys.exit(1)
		patterns = 'celery.py;tasks/*.py;runners/*.py;serializers/*.py;output_types/*.py;hooks/*.py;exporters/*.py'
		watchmedo_path = shutil.which('watchmedo') or str(Path(sys.executable).parent / 'watchmedo')
		cmd = f'{watchmedo_path} auto-restart --directory=./ --patterns="{patterns}" --recursive -- {cmd}'  # noqa: E501

	if use_command_runner:
		ret = Command.execute(cmd, name='secator_worker', cwd=Path(sys.executable).parent)
		sys.exit(ret.return_code)
	else:
		console.print(f'[bold red]{cmd}[/]')
		result = subprocess.run(cmd, shell=True, cwd=Path(sys.executable).parent)
		sys.exit(result.returncode)


# -------#
# UTILS #
# -------#


@cli.group(aliases=['u'])
def util():
	"""Run a utility."""
	pass


@util.command()
@click.option('--timeout', type=float, default=3, help='Proxy timeout (in seconds)')
@click.option('--number', '-n', type=int, default=1, help='Number of proxies')
def proxy(timeout, number):
	"""Get random proxies from FreeProxy."""
	import requests

	if CONFIG.offline_mode:
		console.print(Error(message='Cannot run this command in offline mode.'))
		sys.exit(1)
	proxy = FreeProxy(timeout=timeout, rand=True, anonym=True)
	proxy_str = 'proxy' if number == 1 else 'proxies'
	console.print(f'Searching for {number} {proxy_str} ...')
	for _ in range(number):
		proxy_ok = False
		attempts = 0
		while not proxy_ok and attempts < 5:
			attempts += 1
			url = proxy.get()
			console.print(f'Testing proxy {url} ...')
			try:
				req = requests.get('https://httpbin.org/ip', proxies={'http': url, 'https': url}, timeout=5)
				if not req.ok:
					continue
			except requests.exceptions.ProxyError:
				continue
			except (requests.exceptions.Timeout, requests.exceptions.ConnectionError, requests.exceptions.ReadTimeout):
				continue
			proxy_ok = True
			console.print(f'Proxy {url} tested successfully !')
			console.print(url)


@util.command()
@click.argument('name', type=str, default=None, required=False)
@click.option('--host', '-h', type=str, default=None, help='Specify LHOST for revshell, otherwise autodetected.')
@click.option('--port', '-p', type=int, default=9001, show_default=True, help='Specify PORT for revshell')
@click.option('--interface', '-i', type=str, help='Interface to use to detect IP')
@click.option('--listen', '-l', is_flag=True, default=False, help='Spawn netcat listener on specified port')
@click.option('--force', is_flag=True)
def revshell(name, host, port, interface, listen, force):
	"""Show reverse shell source codes and run netcat listener (-l)."""
	if host is None:  # detect host automatically
		host = detect_host(interface)
		if not host:
			console.print(Error(message=f'Interface "{interface}" could not be found. Run "ifconfig" to see the list of available interfaces'))  # noqa: E501
			sys.exit(1)
		else:
			console.print(Info(message=f'Detected host IP: {host}'))

	# Download reverse shells JSON from repo
	revshells_json = f'{CONFIG.dirs.revshells}/revshells.json'
	if not os.path.exists(revshells_json) or force:
		if CONFIG.offline_mode:
			console.print(Error(message='Cannot run this command in offline mode'))
			sys.exit(1)
		ret = Command.execute(
			f'wget https://raw.githubusercontent.com/freelabz/secator/main/scripts/revshells.json && mv revshells.json {CONFIG.dirs.revshells}',  # noqa: E501
			cls_attributes={'shell': True},
		)
		if not ret.return_code == 0:
			sys.exit(1)

	# Parse JSON into shells
	with open(revshells_json) as f:
		shells = json.loads(f.read())
		for sh in shells:
			sh['alias'] = '_'.join(
				sh['name'].lower().replace('-c', '').replace('-e', '').replace('-i', '').replace('c#', 'cs').replace('#', '').replace('(', '').replace(')', '').strip().split(' ')  # noqa: E501
			).replace('_1', '')
			cmd = re.sub(r'\s\s+', '', sh.get('command', ''), flags=re.UNICODE)
			cmd = cmd.replace('\n', ' ')
			sh['cmd_short'] = (cmd[:30] + '..') if len(cmd) > 30 else cmd

	shell = [shell for shell in shells if shell['name'] == name or shell['alias'] == name]
	if not shell:
		console.print('Available shells:', style='bold yellow')
		shells_str = ['[bold magenta]{alias:<20}[/][dim white]{name:<20}[/][dim gold3]{cmd_short:<20}[/]'.format(**sh) for sh in shells]  # noqa: E501
		console.print('\n'.join(shells_str))
	else:
		shell = shell[0]
		command = shell['command'].replace('[', r'\[')
		alias = shell['alias']
		name = shell['name']
		command_str = Template(command).render(ip=host, port=port, shell='bash')
		console.print(Rule(f'[bold gold3]{alias}[/] - [bold red]{name} REMOTE SHELL', style='bold red', align='left'))
		lang = shell.get('lang') or 'sh'
		if len(command.splitlines()) == 1:
			console.print(command_str, style='cyan', highlight=False, soft_wrap=True)
		else:
			md = Markdown(f'```{lang}\n{command_str}\n```')
			console.print(md)
			console.print(f'Save this script as rev.{lang} and run it on your target', style='dim italic')
		console.print()
		console.print(Rule(style='bold red'))

	if listen:
		console.print(Info(message=f'Starting netcat listener on port {port} ...'))
		cmd = f'nc -lvnp {port}'
		Command.execute(cmd)


@util.command()
@click.option('--directory', '-d', type=str, default=CONFIG.dirs.payloads, help='HTTP server directory')
@click.option('--host', '-h', type=str, default=None, help='HTTP host')
@click.option('--port', '-p', type=int, default=9001, help='HTTP server port')
@click.option('--interface', '-i', type=str, default=None, help='Interface to use to auto-detect host IP')
def serve(directory, host, port, interface):
	"""Run HTTP server to serve payloads."""
	fnames = list(os.listdir(directory))
	if not fnames:
		console.print(Warning(message=f'No payloads found in {directory}.'))
		download_files(CONFIG.payloads.templates, CONFIG.dirs.payloads, CONFIG.offline_mode, 'payload')
		fnames = list(os.listdir(directory))

	console.print(Rule())
	console.print(f'Available payloads in {directory}: ', style='bold yellow')
	fnames.sort()
	for fname in fnames:
		if not host:
			host = detect_host(interface)
			if not host:
				console.print(Error(message=f'Interface "{interface}" could not be found. Run "ifconfig" to see the list of interfaces.'))  # noqa: E501
				return
		console.print(f'{fname} [dim][/]', style='bold magenta')
		console.print(f'wget http://{host}:{port}/{fname}', style='dim italic')
		console.print('')
	console.print(Rule())
	console.print(Info(message=f'[bold yellow]Started HTTP server on port {port}, waiting for incoming connections ...[/]'))  # noqa: E501
	Command.execute(f'{sys.executable} -m http.server {port}', cwd=directory)


@util.command('completion')
@click.option('--shell', type=click.Choice(['bash', 'zsh', 'fish']), default='bash', help='Shell type')
@click.option('--install', is_flag=True, help='Install completion to shell config file')
def completion(shell, install):
	"""Show or install shell completion for secator."""
	# Get completion script
	env_var = '_SECATOR_COMPLETE'
	completion_cmd = f'{env_var}={shell}_source secator'

	try:
		result = subprocess.run(completion_cmd, shell=True, capture_output=True, text=True, env=os.environ.copy())
		completion_script = result.stdout

		if not completion_script:
			console.print(Error(message=f'Failed to generate completion script for {shell}'))
			sys.exit(1)

	except Exception as e:
		console.print(Error(message=f'Error generating completion: {str(e)}'))
		sys.exit(1)

	if install:
		# Determine shell config file
		shell_configs = {
			'bash': os.path.expanduser('~/.bashrc'),
			'zsh': os.path.expanduser('~/.zshrc'),
			'fish': os.path.expanduser('~/.config/fish/completions/secator.fish'),
		}

		config_file = shell_configs.get(shell)
		if not config_file:
			console.print(Error(message=f'Unsupported shell: {shell}'))
			sys.exit(1)

		# For fish, write directly to completion file
		if shell == 'fish':
			os.makedirs(os.path.dirname(config_file), exist_ok=True)
			with open(config_file, 'w') as f:
				f.write(completion_script)
			console.print(Info(message=f'Completion installed to {config_file}'))
		else:
			# For bash/zsh, add eval command to rc file
			eval_line = f'eval "$({env_var}={shell}_source secator)"'

			# Check if already installed
			if os.path.exists(config_file):
				with open(config_file, 'r') as f:
					content = f.read()
				if eval_line in content:
					console.print(Info(message=f'Completion already installed in {config_file}'))
					return

			# Add completion to config file
			with open(config_file, 'a') as f:
				f.write(f'\n# secator shell completion\n{eval_line}\n')
			console.print(Info(message=f'Completion installed to {config_file}'))
			console.print(Warning(message=f'Run "source {config_file}" or restart your shell to enable completion'))
	else:
		# Just print the completion script
		console.print(completion_script)


@util.command()
@click.argument('file', type=str, required=False)
@click.option('--name', '-n', type=str, default=None, help='Name for the output tape file (when recording interactively)')  # noqa: E501
@click.option('--width', '-w', type=int, default=1920, help='Terminal width (for .tap conversion)')
@click.option('--height', '-h', type=int, default=1080, help='Terminal height (for .tap conversion)')
@click.option('--font-size', '-fs', type=int, default=18, help='Font size (for .tap conversion)')
@click.option('--line-height', '-lh', type=float, default=1.4, help='Line height (for .tap conversion)')
@click.option('--output-dir', type=str, default=f'{ROOT_FOLDER}/images')
def record(file, name, width, height, font_size, line_height, output_dir):
	"""Record secator session using VHS.

	If a .tap file is provided, it will be converted to .tape and then run with VHS.
	If a .tape file is provided, it will be run directly with VHS.
	If no file is provided, VHS will start an interactive recording session.
	"""
	output_dir = Path(output_dir)
	output_dir.mkdir(parents=True, exist_ok=True)

	if file:
		file_path = Path(file)
		if not file_path.exists():
			console.print(Error(message=f'File not found: {file}'))
			sys.exit(1)

		# Use the input file's directory for output
		input_dir = file_path.parent
		# Output GIF will be in the same directory with the same base name
		output_gif = input_dir / f'{file_path.stem}.gif'

		# Check if it's a .tap file
		if file_path.suffix == '.tap':
			# Convert .tap to .tape in the same directory as the tap file
			tape_file = input_dir / file_path.with_suffix('.tape').name
			vhs_tap_to_tape(file_path, tape_file, width, height, font_size, line_height)
			# Run VHS with the converted tape file and specify output location
			with console.status(f'Running VHS with {tape_file}...'):
				Command.execute(f'vhs {tape_file} -o {output_gif}')
			console.print(Info(message=f'Generated GIF: {output_gif}'))
			# Optimize the GIF by trimming long pauses
			with console.status('Optimizing GIF...'):
				if trim_gif(output_gif, output_gif):
					console.print(Info(message=f'Optimized GIF: {output_gif}'))

		# Check if it's a .tape file
		elif file_path.suffix == '.tape':
			# Run VHS directly with the tape file and specify output location
			with console.status(f'Running VHS with {file_path}...'):
				Command.execute(f'vhs {file_path} -o {output_gif}')
			console.print(Info(message=f'Generated GIF: {output_gif}'))
			# Optimize the GIF by trimming long pauses
			with console.status('Optimizing GIF...'):
				if trim_gif(output_gif, output_gif):
					console.print(Info(message=f'Optimized GIF: {output_gif}'))

		else:
			console.print(Error(message=f'File must be a .tap or .tape file, got: {file_path.suffix}'))
			sys.exit(1)

	else:
		# No file provided - create a template tape file
		if not name:
			console.print(Error(message='--name option is required when creating a new tape file'))
			sys.exit(1)

		tape_file = output_dir / f'{name}.tape'
		# Create a template tape file
		template_lines = [
			f'Output {name}.gif',
			'Set Shell fish',
		]
		if width is not None:
			template_lines.append(f'Set Width {width}')
		if height is not None:
			template_lines.append(f'Set Height {height}')
		if font_size is not None:
			template_lines.append(f'Set FontSize {font_size}')
		template_lines.append(f'Set LineHeight {line_height}')
		template_lines.append('')
		template_lines.append('# Add your commands here')
		template_lines.append('')

		try:
			with open(tape_file, 'w') as f:
				f.write('\n'.join(template_lines) + '\n')
			console.print(Info(message=f'Created template tape file: {tape_file}'))
			console.print(Info(message='Edit the file and then run: vhs ' + str(tape_file)))
		except Exception as e:
			console.print(Error(message=f'Failed to create template file: {str(e)}'))
			sys.exit(1)


@util.group()
def gif():
	"""GIF manipulation commands."""
	if not ADDONS_ENABLED['dev']:
		console.print(Error(message='Missing dev addon: please run "secator install addons dev"'))
		sys.exit(1)
	pass


@gif.command()
@click.argument('input_gif', type=str)
@click.option('--output', '-o', type=str, default=None, help='Output GIF file path (default: input file with _reduced suffix)')  # noqa: E501
@click.option('--max-frames', '-f', type=int, default=500, help='Maximum number of frames to keep (default: 500)')
def reduce(input_gif, output, max_frames):
	"""Reduce the number of frames in a GIF by accelerating it.

	This command samples frames evenly and reduces their durations to accelerate the GIF,
	making it faster while reducing the file size.
	"""
	input_path = Path(input_gif)
	if not input_path.exists():
		console.print(Error(message=f'File not found: {input_gif}'))
		sys.exit(1)

	if not input_path.suffix.lower() == '.gif':
		console.print(Error(message=f'Input file must be a GIF file, got: {input_path.suffix}'))
		sys.exit(1)

	# Determine output path
	if output:
		output_path = Path(output)
	else:
		output_path = input_path.parent / f'{input_path.stem}_reduced{input_path.suffix}'

	with console.status(f'Reducing GIF frames to {max_frames}...'):
		if reduce_gif_frames(input_path, output_path, max_frames):
			console.print(Info(message=f'Reduced GIF saved to: {output_path}'))
		else:
			console.print(Warning(message='GIF frame reduction failed or was not needed.'))


@gif.command()
@click.argument('input_gif', type=str)
def info(input_gif):
	"""View information about a GIF file (dimensions, frames, total pixels).

	Displays the width, height, frame count, and total pixels (width × height × frames)
	for the specified GIF file.
	"""
	input_path = Path(input_gif)
	if not input_path.exists():
		console.print(Error(message=f'File not found: {input_gif}'))
		sys.exit(1)

	if not input_path.suffix.lower() == '.gif':
		console.print(Error(message=f'Input file must be a GIF file, got: {input_path.suffix}'))
		sys.exit(1)

	info = get_gif_info(input_path)
	if info:
		console.print('[bold gold3]GIF Information:[/]')
		console.print(f'  [bold blue]Width:[/] {info["width"]} pixels')
		console.print(f'  [bold blue]Height:[/] {info["height"]} pixels')
		console.print(f'  [bold blue]Frames:[/] {info["frame_count"]}')
		console.print(f'  [bold blue]Total pixels:[/] {info["total_pixels"]:,}')
	else:
		console.print(Error(message='Failed to read GIF information.'))
		sys.exit(1)


@util.command('build')
@click.option('--version', type=str, help='Override version specified in pyproject.toml')
def build(version):
	"""Build secator PyPI package."""
	if not DEV_PACKAGE:
		console.print(Error(message='You MUST use a development version of secator to make builds'))
		sys.exit(1)
	if not ADDONS_ENABLED['build']:
		console.print(Error(message='Missing build addon: please run "secator install addons build"'))
		sys.exit(1)

	# Update version in pyproject.toml if --version is explicitely passed
	if version:
		pyproject_toml_path = Path.cwd() / 'pyproject.toml'
		if not pyproject_toml_path.exists():
			console.print(Error(message='You must be in the secator root directory to make builds with --version'))
			sys.exit(1)
		console.print(Info(message=f'Updating version in pyproject.toml to {version}'))
		with open(pyproject_toml_path, 'r') as file:
			content = file.read()
		updated_content = re.sub(r'^\s*version\s*=\s*".*?"', f'version = "{version}"', content, flags=re.MULTILINE)
		with open(pyproject_toml_path, 'w') as file:
			file.write(updated_content)

	with console.status('[bold gold3]Building PyPI package...[/]'):
		ret = Command.execute(f'{sys.executable} -m hatch build', name='hatch build', cwd=ROOT_FOLDER)
		sys.exit(ret.return_code)


@util.command('publish')
def publish():
	"""Publish secator PyPI package."""
	if not DEV_PACKAGE:
		console.print(Error(message='You MUST use a development version of secator to publish builds.'))
		sys.exit(1)
	if not ADDONS_ENABLED['build']:
		console.print(Error(message='Missing build addon: please run "secator install addons build"'))
		sys.exit(1)
	os.environ['HATCH_INDEX_USER'] = '__token__'
	hatch_token = os.environ.get('HATCH_INDEX_AUTH')
	if not hatch_token:
		console.print(Error(message='Missing PyPI auth token (HATCH_INDEX_AUTH env variable).'))
		sys.exit(1)
	with console.status('[bold gold3]Publishing PyPI package...[/]'):
		ret = Command.execute(f'{sys.executable} -m hatch publish', name='hatch publish', cwd=ROOT_FOLDER)
		sys.exit(ret.return_code)


# --------#
# CONFIG #
# --------#


@cli.group(aliases=['c'])
def config():
	"""View or edit config."""
	pass


@config.command('get')
@click.option('--user/--full', is_flag=True, help='Show config (user/full)')
@click.argument('key', required=False)
def config_get(user, key=None):
	"""Get config value."""
	if key is None:
		partial = user and default_config != CONFIG
		CONFIG.print(partial=partial)
		return
	CONFIG.get(key)


@config.command('set')
@click.argument('key')
@click.argument('value')
def config_set(key, value):
	"""Set config value."""
	CONFIG.set(key, value)
	config = CONFIG.validate()
	if config:
		CONFIG.get(key)
		saved = CONFIG.save()
		if not saved:
			return
		console.print(f'[bold green]:tada: Saved config to [/]{CONFIG._path}')
	else:
		console.print(Error(message='Invalid config, not saving it.'))


@config.command('unset')
@click.argument('key')
def config_unset(key):
	"""Unset a config value."""
	CONFIG.unset(key)
	config = CONFIG.validate()
	if config:
		saved = CONFIG.save()
		if not saved:
			return
		console.print(f'[bold green]:tada: Saved config to [/]{CONFIG._path}')
	else:
		console.print(Error(message='Invalid config, not saving it.'))


@config.command('edit')
@click.option('--resume', is_flag=True)
def config_edit(resume):
	"""Edit config."""
	tmp_config = CONFIG.dirs.data / 'config.yml.patch'
	if not tmp_config.exists() or not resume:
		shutil.copyfile(config_path, tmp_config)
	click.edit(filename=str(tmp_config))
	config = Config.parse(path=tmp_config)
	if config:
		config.save(config_path)
		console.print(f'\n[bold green]:tada: Saved config to [/]{config_path}.')
		tmp_config.unlink()
	else:
		console.print('\n[bold green]Hint:[/] Run "secator config edit --resume" to edit your patch and fix issues.')


@config.command('default')
@click.option('--save', type=str, help='Save default config to file.')
def config_default(save):
	"""Get default config."""
	default_config.print(partial=False)
	if save:
		default_config.save(target_path=Path(save), partial=False)
		console.print(f'\n[bold green]:tada: Saved default config to [/]{save}.')


# TODO: implement reset method
# @_config.command('reset')
# @click.argument('key')
# def config_reset(key):
# 	"""Reset config value to default."""
# 	success = CONFIG.set(key, None)
# 	if success:
# 		CONFIG.print()
# 		CONFIG.save()
# 		console.print(f'\n[bold green]:tada: Saved config to [/]{CONFIG._path}')


# -----------#
# WORKSPACE #
# -----------#
@cli.group(aliases=['ws', 'workspaces'])
def workspace():
	"""Workspaces."""
	pass


@workspace.command('list')
def workspace_list():
	"""List workspaces."""
	workspaces = {}
	reports_dir = Path(CONFIG.dirs.reports)
	# Discover all workspace directories (including empty ones)
	if reports_dir.exists():
		for child in sorted(reports_dir.iterdir()):
			if child.is_dir():
				workspaces[child.name] = {'count': 0, 'path': str(child)}
	# Count reports per workspace
	json_reports = []
	for root, _, files in os.walk(CONFIG.dirs.reports):
		for file in files:
			if file.endswith('report.json'):
				path = Path(root) / file
				json_reports.append(path)
	json_reports = sorted(json_reports, key=lambda x: x.stat().st_mtime, reverse=False)
	for path in json_reports:
		ws, runner_type, number = str(path).split('/')[-4:-1]
		if ws not in workspaces:
			workspaces[ws] = {'count': 0, 'path': '/'.join(str(path).split('/')[:-3])}
		workspaces[ws]['count'] += 1

	# Build table
	table = Table()
	table.add_column('Workspace name', style='bold gold3')
	table.add_column('Run count', overflow='fold')
	table.add_column('Path')
	for workspace, config in workspaces.items():
		table.add_row(workspace, str(config['count']), config['path'])
	console.print(table)


@workspace.command(name='use', aliases=['create'])
@click.argument('name')
def workspace_use(name):
	"""Use a workspace (set as default)."""
	CONFIG.set('workspace.default', name)
	config = CONFIG.validate()
	if config:
		CONFIG.save()
		console.print(Info(message=f'Now using workspace: [bold]{name}[/]'))
	else:
		console.print(Error(message='Invalid config, not saving it.'))


@workspace.command('current')
def workspace_current():
	"""Show current default workspace."""
	current = CONFIG.workspace.default or 'default'
	console.print(f'Current workspace: [bold gold3]{current}[/]')


@workspace.command(name='rm', aliases=['remove', 'delete'])
@click.argument('name')
@click.option('--driver', type=click.Choice(['local', 'mongodb', 'api']), default='local', help='Query backend driver')
@click.option('-y', '--yes', is_flag=True, default=False, help='Skip confirmation prompt')
def workspace_delete(name, driver, yes):
	"""Delete a workspace and all associated reports. NAME: workspace name."""
	workspace_folder = Path(CONFIG.dirs.reports) / sanitize_folder_name(name)

	actions = []
	if workspace_folder.exists():
		actions.append(f'Remove workspace folder: {workspace_folder}')
	else:
		actions.append(f'[dim]Workspace folder not found (will skip): {workspace_folder}[/]')

	if driver == 'mongodb':
		actions.append(f'Delete all findings in MongoDB with workspace_id="{name}"')
		actions.append(f'Delete all runners in MongoDB with workspace_id="{name}"')
	elif driver == 'api':
		actions.append(f'Send DELETE to API: {CONFIG.addons.api.workspace_delete_endpoint.format(workspace_id=name)}')

	console.print('[bold]The following actions will be performed:[/]')
	for action in actions:
		console.print(f'  [dim]-[/] {action}')

	if not yes:
		click.confirm(f'\nAre you sure you want to delete workspace "{name}"?', abort=True)

	# 1. Remove workspace folder
	if workspace_folder.exists():
		shutil.rmtree(workspace_folder)
		console.print(Info(message=f'Removed workspace folder: {workspace_folder}'))
	else:
		console.print(Warning(message=f'Workspace folder not found: {workspace_folder}'))

	# 2. MongoDB backend
	if driver == 'mongodb':
		try:
			from secator.hooks.mongodb import get_mongodb_client

			client = get_mongodb_client()
			db = client.main
			findings_result = db.findings.delete_many({'_context.workspace_id': name})
			console.print(Info(message=f'Deleted {findings_result.deleted_count} findings from MongoDB'))
			for collection in ['tasks', 'workflows', 'scans']:
				result = db[collection].delete_many({'context.workspace_id': name})
				if result.deleted_count:
					console.print(Info(message=f'Deleted {result.deleted_count} {collection} from MongoDB'))
		except Exception as e:
			console.print(Error(message=f'MongoDB deletion failed: {e}'))

	# 3. API backend
	elif driver == 'api':
		try:
			from secator.hooks.api import _make_request

			endpoint = CONFIG.addons.api.workspace_delete_endpoint.format(workspace_id=name)
			_make_request('DELETE', endpoint)
			console.print(Info(message=f'Deleted workspace "{name}" from API'))
		except Exception as e:
			console.print(Error(message=f'API deletion failed: {e}'))


# ----------#
# PROFILES #
# ----------#


@cli.group(aliases=['p', 'profiles'])
@click.pass_context
def profile(ctx):
	"""Profiles"""
	pass


@profile.command('list')
def profile_list():
	table = Table()
	table.add_column('Profile name', style='bold gold3')
	table.add_column('Description', overflow='fold')
	table.add_column('Options', overflow='fold')
	for profile in PROFILES:
		opts_str = ', '.join(f'[yellow3]{k}[/]=[dim yellow3]{v}[/]' for k, v in profile.opts.items())
		table.add_row(profile.name, profile.description or '', opts_str)
	console.print(table)


# -------#
# ALIAS #
# -------#


@cli.group(aliases=['a', 'aliases'])
def alias():
	"""Aliases."""
	pass


@alias.command('enable')
@click.pass_context
def enable_aliases(ctx):
	"""Enable aliases."""
	fpath = f'{CONFIG.dirs.data}/.aliases'
	aliases = ctx.invoke(list_aliases, silent=True)
	aliases_str = '\n'.join(aliases)
	with open(fpath, 'w') as f:
		f.write(aliases_str)
	console.print('')
	console.print(f':file_cabinet: Alias file written to {fpath}', style='bold green')
	console.print('To load the aliases, run:')
	md = f"""
```sh
source {fpath}                     # load the aliases in the current shell
echo "source {fpath} >> ~/.bashrc" # or add this line to your ~/.bashrc to load them automatically
```
"""
	console.print(Markdown(md))
	console.print()


@alias.command('disable')
@click.pass_context
def disable_aliases(ctx):
	"""Disable aliases."""
	fpath = f'{CONFIG.dirs.data}/.unalias'
	aliases = ctx.invoke(list_aliases, silent=True)
	aliases_str = ''
	for alias in aliases:
		alias_name = alias.split('=')[0]
		if alias.strip().startswith('alias'):
			alias_name = 'un' + alias_name
			aliases_str += alias_name + '\n'
	console.print(f':file_cabinet: Unalias file written to {fpath}', style='bold green')
	console.print('To unload the aliases, run:')
	with open(fpath, 'w') as f:
		f.write(aliases_str)
	md = f"""
```sh
source {fpath}
```
"""
	console.print(Markdown(md))
	console.print()


@alias.command('list')
@click.option('--silent', is_flag=True, default=False, help='No print')
def list_aliases(silent):
	"""List aliases"""
	aliases = []
	aliases.append('\n# Global commands')
	aliases.append('alias x="secator tasks"')
	aliases.append('alias w="secator workflows"')
	aliases.append('alias s="secator scans"')
	aliases.append('alias wk="secator worker"')
	aliases.append('alias ut="secator util"')
	aliases.append('alias c="secator config"')
	aliases.append('alias ws="secator workspaces"')
	aliases.append('alias p="secator profiles"')
	aliases.append('alias a="secator alias"')
	aliases.append('alias r="secator reports"')
	aliases.append('alias h="secator health"')
	aliases.append('alias i="secator install"')
	aliases.append('alias update="secator update"')
	aliases.append('alias t="secator test"')
	aliases.append('alias cs="secator cheatsheet"')
	aliases.append('\n# Tasks')
	for task in [t for t in discover_tasks()]:
		alias_str = f'alias {task.__name__}="secator task {task.__name__}"'
		if task.__external__:
			alias_str += ' # external'
		aliases.append(alias_str)

	if silent:
		return aliases
	console.print('[bold gold3]:wrench: Aliases:[/]')
	for alias in aliases:
		alias_split = alias.split('=')
		if len(alias_split) != 2:
			console.print(f'[bold magenta]{alias}')
			continue
		alias_name, alias_cmd = alias_split[0].replace('alias ', ''), alias_split[1].replace('"', '')
		if '# external' in alias_cmd:
			alias_cmd = alias_cmd.replace('# external', ' [bold red]# external[/]')
		console.print(f'[bold gold3]{alias_name:<15}[/] [dim]->[/] [bold green]{alias_cmd}[/]')

	return aliases


# --------#
# REPORT #
# --------#


@cli.group(aliases=['r', 'reports'])
def report():
	"""Reports."""
	pass


def _apply_format(results, fmt):
	"""Apply a --format string to report results, returning formatted strings grouped by type.

	Args:
		results (dict): Report results keyed by type name.
		fmt (str): Format spec(s), optionally pipe-separated per type.
			E.g. '{tag.match}-{tag.name}' or '{port.host}:{port.port} || vulnerability.matched_at'

	Returns:
		dict: Results dict with items replaced by formatted strings (only matching types kept).
	"""
	specs = [s.strip() for s in re.split(r'\s*\|\|\s*', fmt) if s.strip()]
	new_results = {}

	for spec in specs:
		_field_only = False
		if '{' in spec and '}' in spec:
			if re.search(r'\{\w+\.\w+', spec):
				# Brace-style with type.field dot notation: {url.host} {port.port}
				m = re.search(r'\{(\w+)\.', spec)
				if not m:
					continue
				_type = m.group(1)
				_template = spec
			else:
				# Brace-style with direct field names: {url} {host} {status_code}
				# Only works when exactly one type is present in results.
				_field_only = True
				_type = None
				_template = spec
		else:
			parts = spec.split('.', 1)
			_type = parts[0]
			_field = parts[1] if len(parts) > 1 else None
			_template = '{' + _field + '}' if _field else None

		if _field_only:
			nonempty_types = [k for k, v in results.items() if v]
			if len(nonempty_types) != 1:
				console.print(f'[yellow]Warning: --format "{spec}" requires a single type in results, got: {nonempty_types}[/yellow]')  # noqa: E501
				continue
			_type = nonempty_types[0]
			items = results[_type]
			if not items:
				new_results[_type] = []
				continue
			formatted = []
			for item in items:
				d = item if isinstance(item, dict) else (item.toDict() if hasattr(item, 'toDict') else {})
				try:
					value = _template.format(**d)
					formatted.append(value)
				except (KeyError, AttributeError):
					pass
			new_results[_type] = formatted
			continue

		if _type not in results:
			if _template is None:
				# The spec is a plain field name (no type prefix). If there is exactly one
				# non-empty type, fall back to field lookup on that type.
				nonempty_types = [k for k, v in results.items() if v]
				if len(nonempty_types) == 1:
					_actual_type = nonempty_types[0]
					items = results[_actual_type]
					formatted = []
					for item in items:
						d = item if isinstance(item, dict) else (item.toDict() if hasattr(item, 'toDict') else {})
						val = d.get(_type)
						if val is not None:
							formatted.append(str(val))
					new_results[_actual_type] = formatted
				else:
					console.print(f'[yellow]Warning: --format type {_type!r} not found in results[/yellow]')
			# When _template is set the user gave an explicit type prefix — skip silently.
			continue

		items = results[_type]
		if not items:
			new_results[_type] = []
			continue

		if _template:
			formatted = []
			is_brace_style = '{' in spec and '}' in spec
			for item in items:
				d = item if isinstance(item, dict) else (item.toDict() if hasattr(item, 'toDict') else {})
				try:
					# Brace-style ({type.field}) needs DotMap for attribute access.
					# Dot-path style (type.field) uses direct field values to avoid clobbering.
					kwargs = {**d, _type: DotMap(d)} if is_brace_style else d
					value = _template.format(**kwargs)
					# DotMap returns an empty DotMap() for missing nested paths; skip such items.
					if 'DotMap()' in str(value):
						continue
					formatted.append(value)
				except (KeyError, AttributeError):
					pass
			new_results[_type] = formatted
		else:
			# No field specified — use each OutputType's __str__ for a clean primary-field repr.
			# Items from report.data['results'] may be raw dicts; reconstruct via OutputType.load().
			_otype_map = {cls.get_name(): cls for cls in FINDING_TYPES}
			otype_cls = _otype_map.get(_type)
			formatted = []
			for item in items:
				if isinstance(item, dict) and otype_cls:
					try:
						formatted.append(str(otype_cls.load(item)))
					except Exception:
						formatted.append(json.dumps(item))
				else:
					formatted.append(str(item))
			new_results[_type] = formatted

	return new_results


@report.command('show')
@click.argument('report_query', required=False)
@click.option('-o', '--output', type=str, default='console', help='Exporters')
@click.option('-d', '--time-delta', type=str, default=None, help='Keep results newer than time delta. E.g: 26m, 1d, 1y')  # noqa: E501
@click.option('-q', '--query', type=str, default=None, help='Filter results (Python-like or MongoDB JSON)')
@click.option('--format', '-f', 'fmt', type=str, default=None, help="Format string for results, e.g. '{tag.match}-{tag.name}' or '{port.host}:{port.port} || vulnerability.matched_at'")  # noqa: E501
@click.option('-w', '-ws', '--workspace', type=str, default=None, help='Filter by workspace name')
@click.option('--driver', type=click.Choice(['local', 'mongodb', 'api']), default='local', help='Query backend driver')
@click.option('--dedupe/--no-dedupe', default=None, help='Deduplicate findings (defaults to config value)')
@click.pass_context
def report_show(ctx, report_query, output, time_delta, query, fmt, workspace, driver, dedupe):
	"""Show report results. REPORT_QUERY: comma-separated runner paths (e.g. scans/5,tasks/3)."""
	from secator.query.utils import parse_report_paths, python_expr_to_mongo

	current = get_file_timestamp()
	workspace_name = workspace or CONFIG.workspace.default or 'default'

	# 1. Parse path-based runner filter
	runner_filter = parse_report_paths(report_query)
	debug('runner paths filter', sub='query', obj=runner_filter)

	# 2. Translate -q expression to MongoDB style
	debug('original query expr', sub='query', obj={'raw': query or ''})
	mongo_query = python_expr_to_mongo(query) if query else {}
	debug('converted mongo query', sub='query', obj=mongo_query)

	# 3. Merge filters
	overlap = set(runner_filter) & set(mongo_query)
	if overlap:
		# Preserve both constraints rather than letting one silently override
		full_query = {'$and': [runner_filter, mongo_query]}
	else:
		full_query = {**runner_filter, **mongo_query}
	debug('full query', sub='query', obj=full_query)

	# 4. Add time delta filter if provided
	if time_delta:
		delta = human_to_timedelta(time_delta)
		if delta:
			import datetime

			cutoff = datetime.datetime.now(datetime.timezone.utc) - delta
			full_query['_timestamp'] = {'$gte': cutoff.timestamp()}

	# 5. Build runner context for QueryEngine backend selection
	drivers = [driver] if driver and driver != 'local' else []
	runner = DotMap(
		{
			'config': DotMap({'name': f'consolidated_report_{current}', 'type': 'consolidated'}),
			'name': 'runner',
			'workspace_name': workspace_name,
			'errors': [],
			'context': {
				'workspace_id': workspace_name,
				'workspace_name': workspace_name,
				'drivers': drivers,
			},
			'reports_folder': Path.cwd(),
		}
	)
	runner.toDict = lambda: {
		'name': runner.name,
		'status': 'completed',
		'targets': [],
		'start_time': None,
		'end_time': None,
		'elapsed': None,
		'elapsed_human': None,
		'run_opts': {},
		'results_count': 0,
	}

	exporters = Runner.resolve_exporters(output)

	if fmt:
		non_console = [e.strip() for e in output.split(',') if e.strip() and e.strip() != 'console']
		if non_console:
			raise click.UsageError(f'--format (-f) is only supported with the console exporter; incompatible with: {", ".join(non_console)}')  # noqa: E501

	# 6. Build and send report via QueryEngine
	dedupe_effective = CONFIG.runners.remove_duplicates if dedupe is None else dedupe
	report = Report(runner, title=f'Consolidated report - {current}', exporters=exporters)
	report.build(query=full_query, dedupe=dedupe_effective)
	if fmt:
		report.data['results'] = _apply_format(report.data['results'], fmt)
	report.send()


def _load_report_data(path):
	"""Read report JSON to extract info section and count vulnerability severities."""
	info = {}
	vuln_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
	with open(path, 'r') as f:
		data = json.load(f)
	info = data.get('info', {})
	results = data.get('results', {})
	for vuln in results.get('vulnerability', []):
		severity = str(vuln.get('severity', '')).lower()
		if severity in vuln_counts:
			vuln_counts[severity] += 1
	return info, vuln_counts


def _format_vuln_counts(counts):
	"""Format vulnerability counts as a colored rich string like '2H|10M|5L'."""
	severity_labels = [
		('critical', 'C', 'bold red'),
		('high', 'H', 'red'),
		('medium', 'M', 'yellow'),
		('low', 'L', 'green'),
	]
	parts = []
	for severity, label, color in severity_labels:
		count = counts.get(severity, 0)
		if count > 0:
			parts.append(f'[{color}]{count}{label}[/]')
	return '|'.join(parts) if parts else '-'


@report.command('list')
@click.option('-ws', '-w', '--workspace', type=str)
@click.option('-r', '--runner-type', type=str, default=None, help='Filter by runner type. Choices: task, workflow, scan')  # noqa: E501
@click.option('-d', '--time-delta', type=str, default=None, help='Keep results newer than time delta. E.g: 26m, 1d, 1y')  # noqa: E501
@click.option('--show-all', is_flag=True, default=False, help='Show all columns including report path')
@click.pass_context
def report_list(ctx, workspace, runner_type, time_delta, show_all):
	"""List all secator reports."""
	paths = list_reports(workspace=workspace, type=runner_type, timedelta=human_to_timedelta(time_delta))
	paths = sorted(paths, key=lambda x: x.stat().st_mtime, reverse=False)

	# Build table
	table = Table()
	table.add_column("Workspace", style="bold gold3")
	table.add_column("Name")
	table.add_column("Id")
	table.add_column("Target")
	table.add_column("Profiles")
	table.add_column("Start Date")
	table.add_column("End Date")
	table.add_column("Elapsed")
	table.add_column("Status", style="green")
	table.add_column("Vulnerabilities")
	if show_all:
		table.add_column('Path')

	# Print paths if piped
	if ctx.obj['piped_output']:
		if not paths:
			console.print(Error(message='No reports found.'))
			return
		for path in paths:
			print(path)
		return

	# Load each report
	for path in paths:
		try:
			path_info = get_info_from_report_path(path)
			report_info, vuln_counts = _load_report_data(path)
			runner_id = path_info['type'] + '/' + path_info['id']
			targets = report_info.get('targets', [])
			first_target = str(targets[0]) if targets else ''
			if len(targets) > 1:
				first_target += f' (+{len(targets) - 1})'
			profiles = report_info.get('run_opts', {}).get('profiles', [])
			if isinstance(profiles, str):
				profiles = [p.strip() for p in profiles.split(',') if p.strip()]
			profiles_str = ', '.join(profiles) if profiles else ''
			status = report_info.get('status', '')
			status_color = STATE_COLORS[status] if status in STATE_COLORS else 'white'

			# Update table
			row = [
				path_info['workspace'],
				f"[bold blue]{report_info.get('name', '')}[/]",
				f'[link={Path(path).as_uri()}]{runner_id}[/link]',
				first_target,
				profiles_str,
				humanize_date(report_info.get('start_time')),
				humanize_date(report_info.get('end_time')),
				report_info.get('elapsed_human', ''),
				f"[{status_color}]{status}[/]",
				_format_vuln_counts(vuln_counts),
			]
			if show_all:
				row.append(str(path))
			table.add_row(*row)
		except Exception as e:
			console.print(Error(message=f'Could not load {path}: {str(e)}'))

	if len(paths) > 0:
		console.print(table)
		console.print(Info(message=f'Found {len(paths)} reports.'))
	else:
		console.print(Error(message='No reports found.'))


@report.command('info')
@click.argument('runner_id', type=str)
@click.option('-ws', '-w', '--workspace', type=str, default=None, help='Workspace name')
@click.option('--show-all', is_flag=True, default=False, help='Show all entries (do not truncate lists/dicts or errors)')  # noqa: E501
def report_info(runner_id, workspace, show_all):
	"""Show runner info from a report. RUNNER_ID: runner path (e.g. scans/0)."""
	MAX_ENTRIES = 20

	workspace_name = workspace or CONFIG.workspace.default or 'default'
	parts = runner_id.split('/')
	if len(parts) != 2:
		console.print(Error(message=f'Invalid runner ID: {runner_id!r}. Expected format: <type>/<id> (e.g. scans/0)'))
		return
	runner_type, runner_number = parts[0], parts[1]
	if not runner_type.endswith('s'):
		runner_type += 's'

	report_path = Path(CONFIG.dirs.reports) / workspace_name / runner_type / runner_number / 'report.json'
	if not report_path.exists():
		console.print(Error(message=f'Report not found: {report_path}'))
		return

	with open(report_path, 'r') as f:
		content = json.loads(f.read())

	info = dict(content.get('info', {}))
	errors_raw = info.pop('errors', [])

	table = Table(title=f'Info: {runner_id}', show_header=False, box=None, padding=(0, 1))
	table.add_column('Key', style='bold gold3', no_wrap=True)
	table.add_column('Value')

	def _format_value(value):
		if isinstance(value, list):
			if not show_all and len(value) > MAX_ENTRIES:
				items = value[:MAX_ENTRIES]
				tail = f'\n[dim]... and {len(value) - MAX_ENTRIES} more (use --show-all to see all)[/]'
			else:
				items = value
				tail = ''
			return '\n'.join(str(v) for v in items) + tail
		if isinstance(value, dict):
			if not show_all and len(value) > MAX_ENTRIES:
				pairs = list(value.items())[:MAX_ENTRIES]
				tail = f'\n[dim]... and {len(value) - MAX_ENTRIES} more (use --show-all to see all)[/]'
			else:
				pairs = list(value.items())
				tail = ''
			return '\n'.join(f'[bold]{k}[/]: {v}' for k, v in pairs) + tail
		return str(value) if value is not None else ''

	for key, value in info.items():
		table.add_row(key, _format_value(value))

	console.print(table)

	# Display errors as Error output types
	if errors_raw:
		errors_to_show = errors_raw if show_all else errors_raw[-1:]
		console.print()
		extra = ', showing last 1' if not show_all and len(errors_raw) > 1 else ''
		console.print(f'[bold]Errors[/] ({len(errors_raw)} total{extra}):')
		for err_data in errors_to_show:
			if isinstance(err_data, dict):
				try:
					err = Error.load(err_data)
				except (KeyError, TypeError, ValueError):
					err = Error(message=str(err_data))
			else:
				err = Error(message=str(err_data))
			console.print(err)
	else:
		console.print()
		console.print('[dim]No errors.[/]')


@report.command(name='delete', aliases=['rm', 'remove'])
@click.argument('runner_id')
@click.option('-ws', '-w', '--workspace', type=str, default=None, help='Workspace name')
@click.option('--driver', type=click.Choice(['local', 'mongodb', 'api']), default='local', help='Query backend driver')
@click.option('-y', '--yes', is_flag=True, default=False, help='Skip confirmation prompt')
def report_delete(runner_id, workspace, driver, yes):
	"""Delete a report. RUNNER_ID: runner path (e.g. tasks/24)."""
	workspace_name = workspace or CONFIG.workspace.default or 'default'

	parts = runner_id.split('/')
	if len(parts) != 2:
		console.print(Error(message=f'Invalid runner ID: {runner_id!r}. Expected format: <type>/<id> (e.g. tasks/24)'))
		return

	runner_type_raw, runner_number = parts[0], parts[1]
	allowed_types = {'task', 'tasks', 'workflow', 'workflows', 'scan', 'scans'}
	if runner_type_raw not in allowed_types:
		console.print(Error(message=f'Invalid runner type: {runner_type_raw!r}. Must be one of: task, workflow, scan.'))
		return
	if not runner_number.isdigit():
		console.print(Error(message=f'Invalid runner number: {runner_number!r}. Must be numeric.'))
		return
	runner_type_plural = runner_type_raw if runner_type_raw.endswith('s') else runner_type_raw + 's'
	runner_type_singular = runner_type_plural[:-1]  # tasks -> task, workflows -> workflow, scans -> scan

	report_folder = Path(CONFIG.dirs.reports) / sanitize_folder_name(workspace_name) / runner_type_plural / runner_number
	report_path = report_folder / 'report.json'

	# Read report context to get MongoDB/API IDs
	runner_db_id = None
	if report_path.exists():
		try:
			with open(report_path, 'r') as f:
				content = json.loads(f.read())
			context = content.get('info', {}).get('context', {})
			runner_db_id = context.get(f'{runner_type_singular}_id')
		except (json.JSONDecodeError, KeyError):
			pass

	actions = []
	if report_folder.exists():
		actions.append(f'Remove report folder: {report_folder}')
	else:
		actions.append(f'[dim]Report folder not found (will skip): {report_folder}[/]')

	if driver == 'mongodb':
		if runner_db_id:
			actions.append(f'Delete findings in MongoDB for {runner_type_singular}_id="{runner_db_id}"')
			actions.append(f'Delete {runner_type_singular} document in MongoDB (id="{runner_db_id}")')
		else:
			actions.append('[yellow]No MongoDB ID found in report — skipping MongoDB deletion[/]')
	elif driver == 'api':
		if runner_db_id:
			endpoint_preview = CONFIG.addons.api.runner_delete_endpoint.format(
				runner_type=runner_type_singular,
				runner_id=runner_db_id,
			)
			actions.append(f'Send DELETE to API: {endpoint_preview}')
		else:
			actions.append('[yellow]No API ID found in report — skipping API deletion[/]')

	console.print('[bold]The following actions will be performed:[/]')
	for action in actions:
		console.print(f'  [dim]-[/] {action}')

	if not yes:
		click.confirm(f'\nAre you sure you want to delete report "{workspace_name}/{runner_id}"?', abort=True)

	# 1. Remove report folder
	if report_folder.exists():
		shutil.rmtree(report_folder)
		console.print(Info(message=f'Removed report folder: {report_folder}'))
	else:
		console.print(Warning(message=f'Report folder not found: {report_folder}'))

	# 2. MongoDB backend
	if driver == 'mongodb' and runner_db_id:
		try:
			from bson.objectid import ObjectId
			from secator.hooks.mongodb import get_mongodb_client

			client = get_mongodb_client()
			db = client.main
			findings_result = db.findings.delete_many({f'_context.{runner_type_singular}_id': runner_db_id})
			console.print(Info(message=f'Deleted {findings_result.deleted_count} findings from MongoDB'))
			if ObjectId.is_valid(runner_db_id):
				runner_result = db[runner_type_plural].delete_one({'_id': ObjectId(runner_db_id)})
				if runner_result.deleted_count:
					console.print(Info(message=f'Deleted {runner_type_singular} document from MongoDB'))
			else:
				console.print(Warning(message=f'{runner_type_singular}_id "{runner_db_id}" is not a valid ObjectId — runner document was not deleted from MongoDB'))  # noqa: E501
		except Exception as e:
			console.print(Error(message=f'MongoDB deletion failed: {e}'))

	# 3. API backend
	elif driver == 'api' and runner_db_id:
		try:
			from secator.hooks.api import _make_request

			endpoint = CONFIG.addons.api.runner_delete_endpoint.format(runner_type=runner_type_singular, runner_id=runner_db_id)
			_make_request('DELETE', endpoint)
			console.print(Info(message=f'Deleted {runner_type_singular} from API'))
		except Exception as e:
			console.print(Error(message=f'API deletion failed: {e}'))


# --------#
# DEPLOY #
# --------#

# TODO: work on this
# @cli.group(aliases=['d'])
# def deploy():
# 	"""Deploy secator."""
# 	pass

# @deploy.command()
# def docker_compose():
# 	"""Deploy secator on docker-compose."""
# 	pass

# @deploy.command()
# @click.option('-t', '--target', type=str, default='minikube', help='Deployment target amongst minikube, gke')
# def k8s():
# 	"""Deploy secator on Kubernetes."""
# 	pass


# --------#
# HEALTH #
# --------#


@cli.command(name='health', aliases=['h'])
@click.option('--json', '-json', 'json_', is_flag=True, default=False, help='JSON lines output')
@click.option('--debug', '-debug', is_flag=True, default=False, help='Debug health output')
@click.option('--strict', '-strict', is_flag=True, default=False, help='Fail if missing tools')
@click.option('--bleeding', '-bleeding', is_flag=True, default=False, help='Check bleeding edge version of tools')
def health(json_, debug, strict, bleeding):
	"""Get health status."""
	tools = discover_tasks()
	upgrade_cmd = ''
	results = []
	messages = []

	# Abort if offline mode is enabled
	if CONFIG.offline_mode:
		console.print(Error(message='Cannot run this command in offline mode.'))
		sys.exit(1)

	# Check secator
	console.print(':wrench: [bold gold3]Checking secator ...[/]') if not json_ else None
	info = get_version_info('secator', '-version', 'freelabz/secator')
	info['_type'] = 'core'
	if info['outdated']:
		messages.append(f'secator is outdated (latest:{info["latest_version"]}).')
	results.append(info)
	table = get_health_table()
	contextmanager = Live(table, console=console) if not json_ else nullcontext()
	with contextmanager:
		row = fmt_health_table_row(info)
		table.add_row(*row)

	# Check addons
	console.print('\n:wrench: [bold gold3]Checking addons ...[/]') if not json_ else None
	table = get_health_table()
	contextmanager = Live(table, console=console) if not json_ else nullcontext()
	with contextmanager:
		for addon, installed in ADDONS_ENABLED.items():
			info = {
				'name': addon,
				'version': None,
				'status': 'ok' if installed else 'missing_ok',
				'latest_version': None,
				'installed': installed,
				'location': None,
			}
			info['_type'] = 'addon'
			results.append(info)
			row = fmt_health_table_row(info, 'addons')
			table.add_row(*row)
			if json_:
				print(json.dumps(info))

	# Check languages
	console.print('\n:wrench: [bold gold3]Checking languages ...[/]') if not json_ else None
	version_cmds = {'go': 'version', 'python3': '--version', 'ruby': '--version'}
	table = get_health_table()
	contextmanager = Live(table, console=console) if not json_ else nullcontext()
	with contextmanager:
		for lang, version_flag in version_cmds.items():
			info = get_version_info(lang, version_flag)
			row = fmt_health_table_row(info, 'langs')
			table.add_row(*row)
			info['_type'] = 'lang'
			results.append(info)
			if json_:
				print(json.dumps(info))

	# Check tools
	console.print('\n:wrench: [bold gold3]Checking tools ...[/]') if not json_ else None
	table = get_health_table()
	error = False
	contextmanager = Live(table, console=console) if not json_ else nullcontext()
	upgrade_cmd = 'secator install tools'
	with contextmanager:
		for tool in tools:
			if hasattr(tool, 'cmd'):
				info = get_version_info(
					tool.cmd.split(' ')[0],
					tool.version_flag or f'{tool.opt_prefix}version',
					tool.github_handle,
					tool.install_github_version_prefix,
					tool.install_cmd,
					tool.install_version,
					bleeding=bleeding,
				)
				info['_name'] = tool.__name__
				info['_type'] = 'tool'
				row = fmt_health_table_row(info, 'tools')
				table.add_row(*row)
				if not info['installed']:
					messages.append(f'{tool.__name__} is not installed.')
					info['next_version'] = tool.install_version
					error = True
				elif info['outdated']:
					msg = 'latest' if bleeding else 'supported'
					message = f'{tool.__name__} is outdated (current:{info["version"]}, {msg}:{info["latest_version"]}).'
					messages.append(message)
					info['upgrade'] = True
					info['next_version'] = info['latest_version']

				elif info['bleeding']:
					msg = 'latest' if bleeding else 'supported'
					message = f'{tool.__name__} is bleeding edge (current:{info["version"]}, {msg}:{info["latest_version"]}).'
					messages.append(message)
					info['downgrade'] = True
					info['next_version'] = info['latest_version']
			else:
				info = {
					'name': tool.__name__,
					'_type': 'python',
					'version': None,
					'status': 'ok',
					'latest_version': None,
					'installed': False,
					'location': None,
				}
				row = fmt_health_table_row(info, 'python')
				table.add_row(*row)
			results.append(info)
			if json_:
				print(json.dumps(info))
	console.print('') if not json_ else None

	if not json_ and messages:
		console.print('\n[bold red]Issues found:[/]')
		for message in messages:
			console.print(Warning(message=message))

	# Strict mode
	if strict:
		if error:
			sys.exit(1)
		console.print(Info(message='Strict healthcheck passed !')) if not json_ else None

	# Build upgrade command
	cmds = []
	tool_cmd = ''
	for info in results:
		if info['_type'] == 'core' and info['outdated']:
			cmds.append('secator update')
		elif info['_type'] == 'tool' and info.get('next_version'):
			tool_cmd += f',{info["_name"]}=={info["next_version"]}'

	if tool_cmd:
		tool_cmd = f'secator install tools {tool_cmd.lstrip(",")}'
		cmds.append(tool_cmd)
	upgrade_cmd = ' && '.join(cmds)
	console.print('') if not json_ else None
	if upgrade_cmd:
		console.print(Info(message='Run the following to upgrade secator and tools:')) if not json_ else None
		if json_:
			print(json.dumps({'upgrade_cmd': upgrade_cmd}))
		else:
			print(upgrade_cmd)
	else:
		console.print(Info(message='Everything is up to date !')) if not json_ else None


# ------------#
# CHEATSHEET #
# ------------#


@cli.command(name='cheatsheet', aliases=['cs'])
def cheatsheet():
	"""Display a cheatsheet of secator commands."""
	from rich.panel import Panel
	from rich import box

	kwargs = {
		'box': box.ROUNDED,
		'title_align': 'left',
		# 'style': 'bold blue3',
		'border_style': 'green',
		'padding': (0, 1, 0, 1),
		'highlight': False,
		'expand': False,
	}
	title_style = 'bold green'

	panel1 = Panel(
		r"""
[dim bold]:left_arrow_curving_right: Secator basic commands to get you started.[/]

secator [orange3]x[/]      [dim]# list tasks[/]
secator [orange3]w[/]      [dim]# list workflows[/]
secator [orange3]s[/]      [dim]# list scans[/]
secator [orange3]p[/]      [dim]# manage profiles[/]
secator [orange3]r[/]      [dim]# manage reports[/]
secator [orange3]c[/]      [dim]# manage configuration[/]
secator [orange3]ws[/]     [dim]# manage workspaces[/]
secator [orange3]update[/] [dim]# update secator[/]

[dim]# Running tasks, workflows or scans...[/]
secator \[[orange3]x[/]|[orange3]w[/]|[orange3]s[/]] [NAME] [OPTIONS] [INPUTS]   [dim]# run a task ([bold orange3]x[/]), workflow ([bold orange3]w[/]) or scan ([bold orange3]s[/])[/]
secator [orange3]x[/] [red]httpx[/] example.com                 [dim]# run an [bold red]httpx[/] task ([bold orange3]x[/] is for e[bold orange3]x[/]ecute)[/]
secator [orange3]w[/] [red]url_crawl[/] https://example.com     [dim]# run a [bold red]url crawl[/] workflow ([bold orange3]w[/])[/]
secator [orange3]s[/] [red]host[/] example.com                  [dim]# run a [bold red]host[/] scan ([bold orange3]s[/])[/]

[dim]# Show information on tasks, workflows or scans ...[/]
secator s host [blue]-dry[/]                         [dim]# show dry run (show exact commands that will be run)[/]
secator s host [blue]-tree[/]                        [dim]# show config tree (workflows and scans only)[/]
secator s host [blue]-yaml[/]                        [dim]# show config yaml (workflows and scans only)[/]

[dim]# Organize your results (workspace, database)[/]
secator s host [blue]-ws[/] [bright_magenta]prod[/] example.com         [dim]# save results to 'prod' workspace[/]
secator s host [blue]-driver[/] [bright_magenta]mongodb[/] example.com  [dim]# save results to mongodb database[/]

[dim]# Input types are flexible ...[/]
secator s host [cyan]example.com[/]                  [dim]# single input[/]
secator s host [cyan]host1,host2,host3[/]            [dim]# multiple inputs (comma-separated)[/]
secator s host [cyan]hosts.txt[/]                    [dim]# multiple inputs (txt file)[/]
[cyan]cat hosts.txt | [/]secator s host              [dim]# piped inputs[/]

[dim]# Options are mutualized ...[/]
secator s host [blue]-rl[/] [bright_magenta]10[/] [blue]-delay[/] [bright_magenta]1[/] [blue]-proxy[/] [bright_magenta]http://127.0.0.1:9090[/] example.com  [dim]# set rate limit, delay and proxy for all subtasks[/]
secator s host [blue]-pf[/] [bright_magenta]aggressive[/] example.com  [dim]# ... or use a profile to automatically set options[/]

[dim]:point_right: and [bold]YES[/], the above options and inputs work with any scan ([bold orange3]s[/]), workflow ([bold orange3]w[/]), and task ([bold orange3]x[/]), not just the host scan shown here![/]
""",  # noqa: E501
		title=f':shield: [{title_style}]Some basics[/]',
		**kwargs,
	)

	panel2 = Panel(
		r"""
[dim bold]:left_arrow_curving_right: Secator aliases are useful to stop typing [bold cyan]secator <something>[/] and focus on what you want to run. Aliases are a must to increase your productivity.[/]

[bold]To enable aliases:[/]

secator alias enable       [dim]# enable aliases[/]
source ~/.secator/.aliases [dim]# load aliases in current shell[/]

[dim]# Now you can use aliases...[/]
a list                                                   [dim]# list all aliases[/]
httpx                                                    [dim]# aliased httpx ![/]
nmap -sV -p 443 --script vulners example.com             [dim]# aliased nmap ![/]
w subdomain_recon                                        [dim]# aliased subdomain_recon ![/]
s domain                                                 [dim]# aliased domain scan ![/]
cat hosts.txt | subfinder | naabu | httpx | w url_crawl  [dim]# pipes to chain tasks ![/]
""",  # noqa: E501
		title=f':shorts: [{title_style}]Aliases[/]',
		**kwargs,
	)

	panel3 = Panel(
		r"""
[dim bold]:left_arrow_curving_right: Secator configuration is stored in a YAML file located at [bold cyan]~/.secator/config.yaml[/]. You can edit it manually or use the following commands to get/set values.[/]

c get         [dim]# get config value[/]
c get --user  [dim]# get user config value[/]
c edit        [dim]# edit user config in editor[/]
c set profiles.defaults aggressive                              [dim]# set 'aggressive' profile as default[/]
c set drivers.defaults mongodb                                  [dim]# set mongodb as default driver[/]
c set wordlists.defaults.http https://example.com/wordlist.txt  [dim]# set default wordlist for http fuzzing[/]
""",  # noqa: E501
		title=f':gear: [{title_style}]Configuration[/]',
		**kwargs,
	)

	panel4 = Panel(
		r"""
[dim bold]:left_arrow_curving_right: By default, tasks are run sequentially. You can use a worker to run tasks in parallel and massively speed up your scans.[/]

wk                         [dim]# or [bold cyan]secator worker[/] if you don't use aliases ...[/]
httpx testphp.vulnweb.com  [dim]# <-- will run in worker and output results normally[/]

[dim]:question: Want to use a remote worker ?[/]
[dim]:point_right: Spawn a Celery worker on your remote server, a Redis instance and set the following config values to connect to it, both in the worker and locally:[/]
c set celery.result_backend redis://<remote_ip>:6379/0          [dim]# set redis backend[/]
c set celery.broker_url redis://<remote_ip>:6379/0              [dim]# set redis broker[/]
[dim]:point_right: Then, run your tasks, workflows or scans like you would locally ![/]
""",  # noqa: E501
		title=f':zap: [{title_style}]Too slow ? Use a worker[/]',
		**kwargs,
	)

	panel5 = Panel(
		r"""
[dim bold]:left_arrow_curving_right: Reports are stored in the [bold cyan]~/.secator/reports[/] directory. You can list, show, and filter reports using the following commands.[/]

[dim]# List and filter reports...[/]
r list                    [dim]# list all reports[/]
r list [blue]-ws[/] [bright_magenta]prod[/]           [dim]# list reports from the workspace 'prod'[/]
r list [blue]-d[/] [bright_magenta]1h[/]              [dim]# list reports from the last hour[/]

[dim]# Show and filter results...[/]
r show [blue]-q[/] [bright_magenta]"vulnerability.severity_score >= 7"[/] [blue]-o[/] [bright_magenta]txt[/]                                      [dim]# show high-severity vulnerabilities, save to txt file[/]
r show tasks/10,tasks/11 [blue]-q[/] [bright_magenta]"port.state == 'open'"[/] [blue]-o[/] [bright_magenta]json[/]           [dim]# show open ports from tasks 10 and 11[/]
""",  # noqa: E501
		title=f':file_cabinet: [{title_style}]Digging into reports[/]',
		**kwargs,
	)

	panel6 = Panel(
		r"""
[dim bold]:left_arrow_curving_right: Commands to manage secator installation.[/]

update [dim]# update secator to the latest version[/]

[dim]:point_right: Tools are automatically installed when first running a task, workflow or scan, but you can still install them manually.[/]
i tools httpx    [dim]# install tool 'httpx'[/]
i tools          [dim]# install all tools[/]

[dim]:point_right: Addons are optional dependencies required to enable certain features.[/]
i addon redis    [dim]# install addon 'redis'[/]
i addon gcs      [dim]# install addon 'gcs'[/]
i addon worker   [dim]# install addon 'worker'[/]
i addon gdrive   [dim]# install addon 'gdrive'[/]
i addon mongodb  [dim]# install addon 'mongodb'[/]
""",  # noqa: E501
		title=f':wrench: [{title_style}]Updates[/]',
		**kwargs,
	)

	panel7 = Panel(
		r"""
[dim bold]:left_arrow_curving_right: Some useful scans and workflows we use day-to-day for recon.[/]

[orange3]:warning: Don't forget to add [bold blue]-dry[/] or [bold blue]-tree[/] before running your scans to see what will be done ![/]

[bold orange3]:trophy: Domain recon + Subdomain recon + Port scanning + URL crawl + URL vulns (XSS, SQLi, RCE, ...)[/]
s domain <DOMAIN>                [dim]# light[/]
s domain <DOMAIN> -pf all_ports  [dim]# light + full port scan[/]
s domain <DOMAIN> -pf full       [dim]# all features (full port scan, nuclei, pattern hunting, headless crawling, screenshots, etc.)[/]
s domain <DOMAIN> -pf passive    [dim]# passive (0 requests to targets)[/]

[bold orange3]:trophy: Subdomain recon[/]
w subdomain_recon <DOMAIN>                         [dim]# standard[/]
w subdomain_recon <DOMAIN> -brute-dns -brute-http  [dim]# bruteforce subdomains (DNS queries + HTTP Host header fuzzing)[/]
w subdomain_recon <DOMAIN> -pf passive             [dim]# passive (0 requests to targets)[/]

[bold orange3]:trophy: URL fuzzing[/]
w url_fuzz <URL>                                   [dim]# standard fuzzing (ffuf)[/]
w url_fuzz <URL> -hs                               [dim]# hunt secrets in HTTP responses (trufflehog)[/]
w url_fuzz <URL> -mc 200,301 -fs 204               [dim]# match 200, 301, and filter size equal to 204 bytes[/]
w url_fuzz -fuzzers ffuf,dirsearch <URL> -w <URL>  [dim]# choose fuzzers, use remote wordlist[/]

[bold orange3]:trophy: Vuln and secret scan:[/]
w code_scan <PATH>                                 [dim]# on a local path or git repo[/]
w code_scan https://github.com/freelabz/secator    [dim]# on a github repo[/]
w code_scan https://github.com/freelabz            [dim]# on a github org (all repos)[/]

[bold orange3]:trophy: Hunt user accounts[/]
w user_hunt elonmusk                               [dim]# by username[/]
w user_hunt elonmusk@tesla.com                     [dim]# by email[/]

[bold orange3]:trophy: Custom pipeline to find HTTP servers and fuzz alive ones[/]
subfinder vulnweb.com | naabu | httpx | ffuf -mc 200,301 -recursion
""",  # noqa: E501
		title=f':trophy: [{title_style}]Quick wins[/]',
		**kwargs,
	)

	console.print(panel1)
	console.print(panel2)
	console.print(panel3)
	console.print(panel4)
	console.print(panel5)
	console.print(panel6)
	console.print(panel7)


# ---------#
# INSTALL #
# ---------#


def run_install(title=None, cmd=None, packages=None, next_steps=None):
	if CONFIG.offline_mode:
		console.print(Error(message='Cannot run this command in offline mode.'))
		sys.exit(1)
	# with console.status(f'[bold yellow] Installing {title}...'):
	if cmd:
		import shlex
		from secator.installer import SourceInstaller

		# Quote the package specifier to prevent shell glob expansion of extras (e.g. secator[worker])
		if '-m pip install' in cmd:
			parts = cmd.rsplit(' ', 1)
			cmd = parts[0] + ' ' + shlex.quote(parts[1])
		status = SourceInstaller.install(cmd)
	elif packages:
		from secator.installer import PackageInstaller

		status = PackageInstaller.install(packages)
	return_code = 1
	if status.is_ok():
		return_code = 0
		if next_steps:
			console.print('[bold gold3]:wrench: Next steps:[/]')
			for ix, step in enumerate(next_steps):
				console.print(f'   :keycap_{ix}: {step}')
	sys.exit(return_code)


@cli.group(aliases=['i'])
def install():
	"""Install langs, tools and addons."""
	pass


@install.group()
def addons():
	"Install addons."
	pass


@addons.command('worker')
def install_worker():
	"Install Celery worker addon."
	run_install(
		cmd=f'{sys.executable} -m pip install secator[worker]',
		title='Celery worker addon',
		next_steps=[
			'Run [bold green4]secator worker[/] to run a Celery worker using the file system as a backend and broker.',
			'Run [bold green4]secator x httpx testphp.vulnweb.com[/] to admire your task running in a worker.',
			r'[dim]\[optional][/dim] Run [bold green4]secator install addons redis[/] to setup Redis backend / broker.',
		],
	)


@addons.command('gdrive')
def install_gdrive():
	"Install Google Drive addon."
	run_install(
		cmd=f'{sys.executable} -m pip install secator[google]',
		title='Google Drive addon',
		next_steps=[
			'Run [bold green4]secator config set addons.gdrive.credentials_path <VALUE>[/].',
			'Run [bold green4]secator config set addons.gdrive.drive_parent_folder_id <VALUE>[/].',
			'Run [bold green4]secator x httpx testphp.vulnweb.com -o gdrive[/] to send reports to Google Drive.',
		],
	)


@addons.command('gcs')
def install_gcs():
	"Install Google Cloud Storage addon."
	run_install(
		cmd=f'{sys.executable} -m pip install secator[gcs]',
		title='Google Cloud Storage addon',
		next_steps=[
			'Run [bold green4]secator config set addons.gcs.bucket_name <VALUE>[/].',
			'Run [bold green4]secator config set addons.gcs.credentials_path <VALUE>[/]. [dim](optional if using default credentials)[/]',  # noqa: E501
		],
	)


@addons.command('mongodb')
def install_mongodb():
	"Install MongoDB addon."
	run_install(
		cmd=f'{sys.executable} -m pip install secator[mongodb]',
		title='MongoDB addon',
		next_steps=[
			r'[dim]\[optional][/] Run [bold green4]docker run --name mongo -p 27017:27017 -d mongo:latest[/] to run a local MongoDB instance.',  # noqa: E501
			'Run [bold green4]secator config set addons.mongodb.url mongodb://<URL>[/].',
			'Run [bold green4]secator x httpx testphp.vulnweb.com -driver mongodb[/] to save results to MongoDB.',
		],
	)


@addons.command('redis')
def install_redis():
	"Install Redis addon."
	run_install(
		cmd=f'{sys.executable} -m pip install secator[redis]',
		title='Redis addon',
		next_steps=[
			r'[dim]\[optional][/] Run [bold green4]docker run --name redis -p 6379:6379 -d redis[/] to run a local Redis instance.',  # noqa: E501
			'Run [bold green4]secator config set celery.broker_url redis://<URL>[/]',
			'Run [bold green4]secator config set celery.result_backend redis://<URL>[/]',
			'Run [bold green4]secator worker[/] to run a worker.',
			'Run [bold green4]secator x httpx testphp.vulnweb.com[/] to run a test task.',
		],
	)


@addons.command('vulners')
def install_vulners():
	"Install Vulners addon."
	run_install(
		cmd=f'{sys.executable} -m pip install secator[vulners]',
		title='Vulners addon',
		next_steps=[
			'Run [bold green4]secator config set addons.vulners.api_key <API_KEY>[/].',
			'Set [bold green4]secator config set providers.cve_default_provider vulners[/].',
		],
	)


@addons.command('dev')
def install_dev():
	"Install dev addon."
	run_install(
		cmd=f'{sys.executable} -m pip install secator[dev]',
		title='dev addon',
		next_steps=[
			'Run [bold green4]secator test lint[/] to run lint tests.',
			'Run [bold green4]secator test unit[/] to run unit tests.',
			'Run [bold green4]secator test integration[/] to run integration tests.',
		],
	)


@addons.command('trace')
def install_trace():
	"Install trace addon."
	run_install(cmd=f'{sys.executable} -m pip install secator[trace]', title='trace addon', next_steps=[])


@addons.command('build')
def install_build():
	"Install build addon."
	run_install(
		cmd=f'{sys.executable} -m pip install secator[build]',
		title='build addon',
		next_steps=[
			'Run [bold green4]secator u build pypi[/] to build the PyPI package.',
			'Run [bold green4]secator u publish pypi[/] to publish the PyPI package.',
			'Run [bold green4]secator u build docker[/] to build the Docker image.',
			'Run [bold green4]secator u publish docker[/] to publish the Docker image.',
		],
	)


@addons.command('ai')
def install_ai():
	"Install AI addon."
	run_install(
		cmd=f'{sys.executable} -m pip install secator[ai]',
		title='AI addon',
		next_steps=[
			'Run [bold green4]secator x ai setup[/] to configure your AI model and API key.',
			'Run [bold green4]secator x ai -p "your prompt"[/] to run AI-powered pentesting.',
		],
	)


@install.group()
def langs():
	"Install languages."
	pass


@langs.command('go')
def install_go():
	"""Install Go."""
	run_install(
		cmd='wget -O - https://raw.githubusercontent.com/freelabz/secator/main/scripts/install_go.sh | sudo sh',
		title='Go',
		next_steps=['Add ~/go/bin to your $PATH'],
	)


@langs.command('ruby')
def install_ruby():
	"""Install Ruby."""
	run_install(
		packages={
			'apt': ['ruby-full', 'rubygems'],
			'apk': ['ruby', 'ruby-dev'],
			'pacman': ['ruby', 'ruby-dev'],
			'brew': ['ruby'],
		},
		title='Ruby',
	)


@install.command('tools')
@click.argument('cmds', required=False)
@click.option('--cleanup', is_flag=True, default=False, help='Clean up tools after installation.')
@click.option('--fail-fast', is_flag=True, default=False, help='Fail fast if any tool fails to install.')
def install_tools(cmds, cleanup, fail_fast):
	"""Install supported tools."""
	if CONFIG.offline_mode:
		console.print(Error(message='Cannot run this command in offline mode.'))
		sys.exit(1)
	tools = []
	if cmds is not None:
		cmds = cmds.split(',')
		for cmd in cmds:
			if '==' in cmd:
				cmd, version = tuple(cmd.split('=='))
			else:
				cmd, version = cmd, None
			cls = next((cls for cls in discover_tasks() if cls.__name__ == cmd), None)
			if cls:
				if version:
					if cls.install_version and cls.install_version.startswith('v') and not version.startswith('v'):
						version = f'v{version}'
					cls.install_version = version
				tools.append(cls)
			else:
				console.print(Warning(message=f'Tool {cmd} is not supported or inexistent.'))
	else:
		tools = discover_tasks()
	tools.sort(key=lambda x: x.__name__)
	return_code = 0
	if not tools:
		console.print(Error(message='No tools found for installing.'))
		return
	for ix, cls in enumerate(tools):
		# with console.status(f'[bold yellow][{ix + 1}/{len(tools)}] Installing {cls.__name__} ...'):
		status = ToolInstaller.install(cls)
		if not status.is_ok():
			return_code = 1
			if fail_fast:
				sys.exit(return_code)
		console.print()
	if cleanup:
		distro = get_distro_config()
		cleanup_cmds = [
			'go clean -cache',
			'go clean -modcache',
			'pip cache purge',
			'gem cleanup --user-install',
			'gem clean --user-install',
		]
		if distro.pm_finalizer:
			cleanup_cmds.append(f'sudo {distro.pm_finalizer}')
		cmd = ' && '.join(cleanup_cmds)
		Command.execute(cmd, cls_attributes={'shell': True}, quiet=False)
	sys.exit(return_code)


# --------#
# UPDATE #
# --------#


@cli.command('update')
@click.option('--all', '-a', is_flag=True, help='Update all secator dependencies (addons, tools, ...)')
def update(all):
	"""Update to latest version."""
	if CONFIG.offline_mode:
		console.print(Error(message='Cannot run this command in offline mode.'))
		sys.exit(1)

	# Check current and latest version
	info = get_version_info('secator', '-version', 'freelabz/secator', version=VERSION)
	latest_version = info['latest_version']
	do_update = True

	# Skip update if latest
	if info['status'] == 'latest':
		console.print(Info(message=f'secator is already at the newest version {latest_version} !'))
		do_update = False

	# Fail if unknown latest
	if not latest_version:
		console.print(Error(message='Could not fetch latest secator version.'))
		sys.exit(1)

	# Update secator
	if do_update:
		console.print(f'[bold gold3]:wrench: Updating secator from {VERSION} to {latest_version} ...[/]')
		if 'pipx' in sys.executable:
			ret = Command.execute(f'pipx install secator=={latest_version} --force')
		else:
			ret = Command.execute(f'{sys.executable} -m pip install secator=={latest_version}')
		if not ret.return_code == 0:
			sys.exit(1)

	# Update tools
	if all:
		return_code = 0
		for cls in discover_tasks():
			base_cmd = getattr(cls, 'cmd', None)
			if not base_cmd:
				continue
			cmd = base_cmd.split(' ')[0]
			version_flag = cls.get_version_flag()
			info = get_version_info(cmd, version_flag, cls.github_handle, cls.install_github_version_prefix)
			if not info['installed'] or info['outdated'] or not info['latest_version']:
				# with console.status(f'[bold yellow]Installing {cls.__name__} ...'):
				status = ToolInstaller.install(cls)
				if not status.is_ok():
					return_code = 1
		sys.exit(return_code)


# ------#
# TEST #
# ------#


@cli.group(cls=OrderedGroup)
def test():
	"""[dim]Run tests (dev build only)."""
	if not DEV_PACKAGE:
		console.print(Error(message='You MUST use a development version of secator to run tests.'))
		sys.exit(1)
	if not ADDONS_ENABLED['dev']:
		console.print(Error(message='Missing dev addon: please run "secator install addons dev"'))
		sys.exit(1)
	pass


def run_test(cmd, name=None, exit=True, verbose=False, use_command_runner=True):
	"""Run a test and return the result.

	Args:
		cmd (str): Command to run.
		name (str, optional): Name of the test.
		exit (bool, optional): Exit after running the test with the return code.
		verbose (bool, optional): Print verbose output.
		use_command_runner (bool, optional): Use Command.execute to run the command.

	Returns:
		Return code of the test.
	"""
	cmd_name = name + ' tests' if name else 'tests'
	if not use_command_runner:
		console.print(f'[bold red]{cmd}[/]')
		if not verbose:
			cmd += ' >/dev/null 2>&1'
		ret = subprocess.run(cmd, shell=True)
		if exit:
			sys.exit(ret.returncode)
		return ret.returncode
	else:
		result = Command.execute(cmd, name=cmd_name, cwd=ROOT_FOLDER, quiet=not verbose)
		if name:
			if result.return_code == 0:
				console.print(f':tada: {name.capitalize()} tests passed !', style='bold green')
			else:
				console.print(f':x: {name.capitalize()} tests failed !', style='bold red')
		if exit:
			sys.exit(result.return_code)
		return result.return_code


@test.command()
@click.option('--linter', '-l', type=click.Choice(['flake8', 'ruff', 'isort', 'pylint']), default='flake8', help='Linter to use')  # noqa: E501
def lint(linter):
	"""Run lint tests."""
	opts = ''
	if linter == 'pylint':
		opts = '--indent-string "\t" --max-line-length 160 --disable=R,C,W'
	elif linter == 'ruff':
		opts = ' check'
	cmd = f'{sys.executable} -m {linter} {opts} secator/'
	run_test(cmd, 'lint', verbose=True, use_command_runner=False)


@test.command()
@click.option('--tasks', type=str, default='', help='Secator tasks to test (comma-separated)')
@click.option('--workflows', type=str, default='', help='Secator workflows to test (comma-separated)')
@click.option('--scans', type=str, default='', help='Secator scans to test (comma-separated)')
@click.option('--test', '-t', type=str, help='Secator test to run')
@click.option('--no-coverage', is_flag=True, help='Disable coverage')
def unit(tasks, workflows, scans, test, no_coverage):
	"""Run unit tests."""
	os.environ['TEST_TASKS'] = tasks or ''
	os.environ['TEST_WORKFLOWS'] = workflows or ''
	os.environ['TEST_SCANS'] = scans or ''
	os.environ['SECATOR_DIRS_DATA'] = '/tmp/.secator'
	os.environ['SECATOR_OFFLINE_MODE'] = '1'
	os.environ['SECATOR_HTTP_STORE_RESPONSES'] = '0'
	os.environ['SECATOR_RUNNERS_SKIP_CVE_SEARCH'] = '1'

	if not test:
		if tasks:
			test = 'test_tasks'
		elif workflows:
			test = 'test_workflows'
		elif scans:
			test = 'test_scans'

	import shutil

	shutil.rmtree('/tmp/.secator', ignore_errors=True)
	if not no_coverage:
		cmd = f'{sys.executable} -m coverage run --omit="*test*" --data-file=.coverage.unit -m pytest -s -vv tests/unit --durations=5'  # noqa: E501
	else:
		cmd = f'{sys.executable} -m pytest -s -vv tests/unit --durations=5'
	if test:
		test_str = ' or '.join(test.split(','))
		cmd += f' -k "{test_str}"'
	run_test(cmd, 'unit', verbose=True, use_command_runner=False)


@test.command()
@click.option('--tasks', type=str, default='', help='Secator tasks to test (comma-separated)')
@click.option('--workflows', type=str, default='', help='Secator workflows to test (comma-separated)')
@click.option('--scans', type=str, default='', help='Secator scans to test (comma-separated)')
@click.option('--test', '-t', type=str, help='Secator test to run')
@click.option('--no-cleanup', '-nc', is_flag=True, help='Do not perform cleanup (keep lab running, faster for relaunching tests)')  # noqa: E501
def integration(tasks, workflows, scans, test, no_cleanup):
	"""Run integration tests."""
	os.environ['TEST_TASKS'] = tasks or ''
	os.environ['TEST_WORKFLOWS'] = workflows or ''
	os.environ['TEST_SCANS'] = scans or ''
	os.environ['SECATOR_DIRS_DATA'] = '/tmp/.secator'
	os.environ['SECATOR_RUNNERS_SKIP_CVE_SEARCH'] = '1'
	os.environ['TEST_NO_CLEANUP'] = '1' if no_cleanup else '0'

	if not test:
		if tasks:
			test = 'test_tasks'
		elif workflows:
			test = 'test_workflows'
		elif scans:
			test = 'test_scans'

	import shutil

	shutil.rmtree('/tmp/.secator', ignore_errors=True)

	cmd = f'{sys.executable} -m coverage run --omit="*test*" --data-file=.coverage.integration -m pytest -s -vv tests/integration --durations=5'  # noqa: E501
	if test:
		test_str = ' or '.join(test.split(','))
		cmd += f' -k "{test_str}"'
	run_test(cmd, 'integration', verbose=True, use_command_runner=False)


@test.command()
@click.option('--tasks', type=str, default='', help='Secator tasks to test (comma-separated)')
@click.option('--workflows', type=str, default='', help='Secator workflows to test (comma-separated)')
@click.option('--scans', type=str, default='', help='Secator scans to test (comma-separated)')
@click.option('--test', '-t', type=str, help='Secator test to run')
def template(tasks, workflows, scans, test):
	"""Run integration tests."""
	os.environ['TEST_TASKS'] = tasks or ''
	os.environ['TEST_WORKFLOWS'] = workflows or ''
	os.environ['TEST_SCANS'] = scans or ''
	os.environ['SECATOR_DIRS_DATA'] = '/tmp/.secator'
	os.environ['SECATOR_RUNNERS_SKIP_CVE_SEARCH'] = '1'

	if not test:
		if tasks:
			test = 'test_tasks'
		elif workflows:
			test = 'test_workflows'
		elif scans:
			test = 'test_scans'

	import shutil

	shutil.rmtree('/tmp/.secator', ignore_errors=True)

	cmd = f'{sys.executable} -m coverage run --omit="*test*" --data-file=.coverage.templates -m pytest -s -vv tests/template --durations=5'  # noqa: E501
	if test:
		test_str = ' or '.join(test.split(','))
		cmd += f' -k "{test_str}"'
	run_test(cmd, 'template', verbose=True)


@test.command()
@click.option('--tasks', type=str, default='', help='Secator tasks to test (comma-separated)')
@click.option('--workflows', type=str, default='', help='Secator workflows to test (comma-separated)')
@click.option('--scans', type=str, default='', help='Secator scans to test (comma-separated)')
@click.option('--test', '-t', type=str, help='Secator test to run')
def performance(tasks, workflows, scans, test):
	"""Run integration tests."""
	os.environ['TEST_TASKS'] = tasks or ''
	os.environ['TEST_WORKFLOWS'] = workflows or ''
	os.environ['TEST_SCANS'] = scans or ''
	os.environ['SECATOR_DIRS_DATA'] = '/tmp/.secator'
	os.environ['SECATOR_RUNNERS_SKIP_CVE_SEARCH'] = '1'

	# import shutil
	# shutil.rmtree('/tmp/.secator', ignore_errors=True)

	cmd = f'{sys.executable} -m coverage run --omit="*test*" --data-file=.coverage.performance -m pytest -s -v tests/performance'  # noqa: E501
	if test:
		test_str = ' or '.join(test.split(','))
		cmd += f' -k "{test_str}"'
	run_test(cmd, 'performance', verbose=True, use_command_runner=False)


@test.command()
@click.argument('name', type=str)
@click.option('--verbose', '-v', is_flag=True, default=False, help='Print verbose output')
@click.option('--check', '-c', is_flag=True, default=False, help='Check task semantics only (no unit + integration tests)')  # noqa: E501
@click.option('--system-exit', '-e', is_flag=True, default=True, help='Exit with system exit code')
def task(name, verbose, check, system_exit):
	"""Test a single task for semantics errors, and run unit + integration tests."""
	console.print(f'[bold gold3]:wrench: Testing task {name} ...[/]')
	task = [task for task in discover_tasks() if task.__name__ == name.strip()]
	warnings = []
	errors = []
	exit_code = 0

	# Check if task is correctly registered
	check_test(len(task) == 1, 'Check task is registered', 'Task is not registered. Please check your task name.', errors)
	if errors:
		if system_exit:
			sys.exit(1)
		else:
			return False

	task = task[0]
	task_name = task.__name__

	# Check task command is set
	cmd = getattr(task, 'cmd', None)
	if cmd:
		check_test(task.cmd, 'Check task command is set (cls.cmd)', 'Task has no cmd attribute.', errors)
	if errors:
		if system_exit:
			sys.exit(1)
		else:
			return False

	# Run install
	if hasattr(task, 'get_version_info'):
		cmd = f'secator install tools {task_name}'
		ret_code = Command.execute(cmd, name='install', quiet=not verbose, cwd=ROOT_FOLDER)
		version_info = task.get_version_info()
		if verbose:
			console.print(f'Version info:\n{version_info}')
		status = version_info['status']
		check_test(
			version_info['installed'],
			'Check task is installed',
			'Failed to install command. Fix your installation command.',
			errors,
		)
		check_test(
			any(cmd for cmd in [task.install_pre, task.install_cmd, task.github_handle]),
			'Check task installation command is defined',
			'Task has no installation command. Please define one or more of the following class attributes: `install_pre`, `install_cmd`, `install_post`, `github_handle`.',  # noqa: E501
			errors,
		)
		check_test(
			version_info['version'],
			'Check task version can be fetched',
			'Failed to detect current version. Consider updating your `version_flag` class attribute.',
			warnings,
			warn=True,
		)
		check_test(
			status != 'latest unknown',
			'Check latest version',
			'Failed to detect latest version.',
			warnings,
			warn=True,
		)
		check_test(
			not version_info['outdated'],
			'Check task version is up to date',
			f'Task is not up to date (current version: {version_info["version"]}, latest: {version_info["latest_version"]}). Consider updating your `install_version` class attribute.',  # noqa: E501
			warnings,
			warn=True,
		)

	# Run task-specific tests
	check_test(
		task.__doc__,
		'Check task description is set (cls.__doc__)',
		'Task has no description (class docstring).',
		errors,
	)
	check_test(
		task.input_types,
		'Check task input type is set (cls.input_type)',
		'Task has no input_type attribute.',
		warnings,
		warn=True,
	)
	check_test(
		task.output_types,
		'Check task output types is set (cls.output_types)',
		'Task has no output_types attribute. Consider setting some so that secator can load your task outputs.',
		warnings,
		warn=True,
	)
	if hasattr(task, 'install_version'):
		check_test(
			task.install_version,
			'Check task install_version is set (cls.install_version)',
			'Task has no install_version attribute. Consider setting it to pin the tool version and ensure it does not break in the future.',  # noqa: E501
			warnings,
			warn=True,
		)

	if not check:
		# Run unit tests
		cmd = f'secator test unit --tasks {name}'
		ret_code = run_test(cmd, exit=False, verbose=verbose)
		check_test(ret_code == 0, 'Check unit tests pass', 'Unit tests failed.', errors)

		# Run integration tests
		cmd = f'secator test integration --tasks {name}'
		ret_code = run_test(cmd, exit=False, verbose=verbose)
		check_test(ret_code == 0, 'Check integration tests pass', 'Integration tests failed.', errors)

	# Exit with exit code
	exit_code = 1 if len(errors) > 0 else 0
	if exit_code == 0:
		console.print(f':tada: Task {name} tests passed !', style='bold green')
	else:
		console.print('\n[bold gold3]Errors:[/]')
		for error in errors:
			console.print(error)
		console.print(Error(message=f'Task {name} tests failed. Please fix the issues above.'))

	if warnings:
		console.print('\n[bold gold3]Warnings:[/]')
		for warning in warnings:
			console.print(warning)

	console.print('\n')
	if system_exit:
		sys.exit(exit_code)
	else:
		return True if exit_code == 0 else False


@test.command()
@click.pass_context
@click.option('--check', '-c', is_flag=True, default=False, help='Check task semantics only (no unit + integration tests)')  # noqa: E501
@click.option('--verbose', '-v', is_flag=True, default=False, help='Print verbose output')
def tasks(ctx, check, verbose):
	"""Test all tasks for semantics errors, and run unit + integration tests."""
	results = []
	for cls in discover_tasks():
		success = ctx.invoke(task, name=cls.__name__, verbose=verbose, check=check, system_exit=False)
		results.append(success)

	if any(not success for success in results):
		console.print(Error(message='Tasks checks failed. Please check the output for more details.'))
		sys.exit(1)
	console.print(Info(message='All tasks checks passed.'))
	sys.exit(0)


def check_test(condition, message, fail_message, results=[], warn=False):
	console.print(f'[bold magenta]:zap: {message} ...[/]', end='')
	if not condition:
		if not warn:
			error = Error(message=fail_message)
			console.print(' [bold red]FAILED[/]', style='dim')
			results.append(error)
		else:
			warning = Warning(message=fail_message)
			console.print(' [bold yellow]WARNING[/]', style='dim')
			results.append(warning)
	else:
		console.print(' [bold green]OK[/]', style='dim')
	return True


@test.command()
@click.option('--unit-only', '-u', is_flag=True, default=False, help='Only generate coverage for unit tests')
@click.option('--integration-only', '-i', is_flag=True, default=False, help='Only generate coverage for integration tests')  # noqa: E501
@click.option('--template-only', '-t', is_flag=True, default=False, help='Only generate coverage for template tests')  # noqa: E501
def coverage(unit_only, integration_only, template_only):
	"""Run coverage combine + coverage report."""
	cmd = f'{sys.executable} -m coverage report -m --omit=*/site-packages/*,*/tests/*,*/templates/*'
	if unit_only:
		cmd += ' --data-file=.coverage.unit'
	elif integration_only:
		cmd += ' --data-file=.coverage.integration'
	elif template_only:
		cmd += ' --data-file=.coverage.template'
	else:
		Command.execute(f'{sys.executable} -m coverage combine --keep', name='coverage combine', cwd=ROOT_FOLDER)
	run_test(cmd, 'coverage', use_command_runner=False)
