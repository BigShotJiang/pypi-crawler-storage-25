import logging
import os
import re
import shlex

import xmltodict

from secator.config import CONFIG
from secator.decorators import task

# fmt: off
from secator.definitions import (
	CIDR_RANGE, DELAY, HOST, IP, OPT_NOT_SUPPORTED, OUTPUT_PATH, PORTS, PROXY, RATE_LIMIT, RETRIES, SCRIPT, STRING,
	THREADS, TIMEOUT, TOP_PORTS
)
# fmt: on
from secator.output_types import Error, Exploit, Info, Ip, Port, Technology, Vulnerability, Warning, Progress
from secator.tasks._categories import ReconPort, VulnMulti
from secator.utils import debug, traceback_as_string

logger = logging.getLogger(__name__)


NMAP_PROGRESS_REGEX_1 = re.compile(r'Stats: (\d+:\d+:\d+) elapsed; (\d+) hosts completed \((\d+) up\)')
NMAP_PROGRESS_REGEX_2 = re.compile(r'(.*) Timing: About (\d+\.\d+)% done; ETC: \d+:\d+ \((\d+:\d+:\d+) remaining\)')


@task()
class nmap(ReconPort):
	"""Network Mapper is a free and open source utility for network discovery and security auditing."""

	cmd = 'nmap'
	input_types = [HOST, IP, CIDR_RANGE, STRING]
	output_types = [Port, Ip, Vulnerability, Technology, Exploit, Progress]
	tags = ['port', 'scan']
	input_chunk_size = 1
	file_flag = '-iL'
	opt_prefix = '--'
	opts = {
		# Script scanning
		SCRIPT: {'type': str, 'default': None, 'help': 'NSE scripts'},
		'script_args': {'type': str, 'short': 'sargs', 'default': None, 'help': 'NSE script arguments (n1=v1,n2=v2,...)'},
		# Host discovery
		'skip_host_discovery': {'is_flag': True, 'short': 'Pn', 'default': False, 'help': 'Skip host discovery (no ping)'},
		'skip_dns_resolution': {'is_flag': True, 'short': 'n', 'default': False, 'help': 'Skip DNS resolution'},
		# Service and version detection
		'version_detection': {'is_flag': True, 'short': 'sV', 'default': False, 'help': 'Enable version detection (slow)'},
		'detect_all': {'is_flag': True, 'short': 'A', 'default': False, 'help': 'Enable OS detection, version detection, script scanning, and traceroute on open ports'},  # noqa: E501
		'detect_os': {'is_flag': True, 'short': 'O', 'default': False, 'help': 'Enable OS detection', 'requires_sudo': True},
		# Scan techniques
		'list_scan': {'is_flag': True, 'short': 'sL', 'default': False, 'help': 'List scan'},
		'tcp_syn_stealth': {'is_flag': True, 'short': 'sS', 'default': False, 'help': 'TCP SYN Stealth', 'requires_sudo': True},  # noqa: E501
		'tcp_connect': {'is_flag': True, 'short': 'sT', 'default': False, 'help': 'TCP Connect scan'},
		'udp_scan': {'is_flag': True, 'short': 'sU', 'default': False, 'help': 'UDP scan', 'requires_sudo': True},
		'tcp_null_scan': {'is_flag': True, 'short': 'sN', 'default': False, 'help': 'TCP Null scan', 'requires_sudo': True},
		'tcp_fin_scan': {'is_flag': True, 'short': 'sF', 'default': False, 'help': 'TCP FIN scan', 'requires_sudo': True},
		'tcp_xmas_scan': {'is_flag': True, 'short': 'sX', 'default': False, 'help': 'TCP Xmas scan', 'requires_sudo': True},
		'tcp_ack_scan': {'is_flag': True, 'short': 'sA', 'default': False, 'help': 'TCP ACK scan', 'requires_sudo': True},
		'tcp_window_scan': {'is_flag': True, 'short': 'sW', 'default': False, 'help': 'TCP Window scan', 'requires_sudo': True},  # noqa: E501
		'tcp_maimon_scan': {'is_flag': True, 'short': 'sM', 'default': False, 'help': 'TCP Maimon scan', 'requires_sudo': True},  # noqa: E501
		'sctp_init_scan': {'is_flag': True, 'short': 'sY', 'default': False, 'help': 'SCTP Init scan', 'requires_sudo': True},
		'sctp_cookie_echo_scan': {'is_flag': True, 'short': 'sZ', 'default': False, 'help': 'SCTP Cookie Echo scan', 'requires_sudo': True},  # noqa: E501
		'ping_scan': {'is_flag': True, 'short': 'sn', 'default': False, 'help': 'Ping scan (disable port scan)'},
		'ip_protocol_scan': {'type': str, 'short': 'sO', 'default': None, 'help': 'IP protocol scan', 'requires_sudo': True},
		'script_scan': {'is_flag': True, 'short': 'sC', 'default': False, 'help': 'Enable default scanning'},
		'zombie_host': {'type': str, 'short': 'sI', 'default': None, 'help': 'Use a zombie host for idle scan', 'requires_sudo': True},  # noqa: E501
		'ftp_relay_host': {'type': str, 'short': 'sB', 'default': None, 'help': 'FTP bounce scan relay host'},
		# Firewall / IDS evasion and spoofing
		'spoof_source_port': {'type': int, 'short': 'g', 'default': None, 'help': 'Send packets from a specific port'},
		'spoof_source_ip': {'type': str, 'short': 'S', 'default': None, 'help': 'Spoof source IP address'},
		'spoof_source_mac': {'type': str, 'short': 'spoofmac', 'default': None, 'help': 'Spoof MAC address'},
		'fragment': {'is_flag': True, 'short': 'fragment', 'default': False, 'help': 'Fragment packets', 'requires_sudo': True},  # noqa: E501
		'mtu': {'type': int, 'short': 'mtu', 'default': None, 'help': 'Fragment packets with given MTU', 'requires_sudo': True},  # noqa: E501
		'ttl': {'type': int, 'short': 'ttl', 'default': None, 'help': 'Set TTL', 'requires_sudo': True},
		'badsum': {'is_flag': True, 'short': 'badsum', 'default': False, 'help': 'Create a bad checksum in the TCP header', 'requires_sudo': True},  # noqa: E501
		'ipv6': {'is_flag': True, 'short': 'ipv6', 'default': False, 'help': 'Enable IPv6 scanning'},
		# Host discovery
		'traceroute': {'is_flag': True, 'short': 'traceroute', 'default': False, 'help': 'Traceroute', 'requires_sudo': True},
		'disable_arp_ping': {'is_flag': True, 'short': 'dap', 'default': False, 'help': 'Disable ARP ping'},
		# Misc
		'output_path': {'type': str, 'short': 'oX', 'default': None, 'help': 'Output XML file path', 'internal': True, 'display': False},  # noqa: E501
		'debug': {'is_flag': True, 'default': False, 'help': 'Enable debug mode'},
		'verbosity': {'type': int, 'short': 'vo', 'default': None, 'internal': True, 'display': True, 'help': 'Enable verbose mode (1, 2, 3)'},  # noqa: E501
		'timing': {'type': int, 'short': 'T', 'default': None, 'help': 'Timing template (0: paranoid, 1: sneaky, 2: polite, 3: normal, 4: aggressive, 5: insane)'},  # noqa: E501
	}
	opt_key_map = {
		DELAY: 'scan-delay',
		PROXY: None,  # TODO: supports --proxies but not in TCP mode [https://github.com/nmap/nmap/issues/1098]
		RATE_LIMIT: 'max-rate',
		RETRIES: 'max-retries',
		THREADS: OPT_NOT_SUPPORTED,
		TIMEOUT: 'max-rtt-timeout',
		PORTS: '-p',
		TOP_PORTS: 'top-ports',
		# Nmap opts
		'skip_host_discovery': '-Pn',
		'skip_dns_resolution': '-n',
		'version_detection': '-sV',
		'detect_all': '-A',
		'detect_os': '-O',
		'list_scan': '-sL',
		'tcp_syn_stealth': '-sS',
		'tcp_connect': '-sT',
		'tcp_window_scan': '-sW',
		'tcp_maimon_scan': '-sM',
		'udp_scan': '-sU',
		'tcp_null_scan': '-sN',
		'tcp_fin_scan': '-sF',
		'tcp_xmas_scan': '-sX',
		'tcp_ack_scan': '-sA',
		'sctp_init_scan': '-sY',
		'sctp_cookie_echo_scan': '-sZ',
		'ping_scan': '-sn',
		'ip_protocol_scan': '-sO',
		'script_scan': '-sC',
		'zombie_host': '-sI',
		'ftp_relay_host': '-b',
		'spoof_source_port': '-g',
		'spoof_source_ip': '-S',
		'spoof_source_mac': '--spoof-mac',
		'fragment': '-f',
		'mtu': '--mtu',
		'ttl': '--ttl',
		'badsum': '--badsum',
		'ipv6': '-6',
		'traceroute': '--traceroute',
		'disable_arp_ping': '--disable-arp-ping',
		'output_path': '-oX',
	}
	opt_value_map = {PORTS: lambda x: ','.join([str(p) for p in x]) if isinstance(x, list) else x}
	install_pre = {
		'apt|pacman|brew': ['nmap'],
		'apk': ['nmap', 'nmap-scripts'],
	}
	proxychains = True
	proxychains_flavor = 'proxychains4'
	proxy_socks5 = False
	proxy_http = False
	profile = 'small'
	disable_preexec = True

	@staticmethod
	def on_cmd(self):
		output_path = self.get_opt_value(OUTPUT_PATH)
		if not output_path:
			output_path = f'{self.reports_folder}/.outputs/{self.fqn}.xml'
		self.output_path = output_path
		self.cmd += f' -oX {shlex.quote(self.output_path)}'
		tcp_syn_stealth = self.cmd_options.get('tcp_syn_stealth')
		tcp_connect = self.cmd_options.get('tcp_connect')
		verbosity = self.get_opt_value('verbosity')
		if tcp_connect and tcp_syn_stealth:
			self._print('Options -sT (SYN stealth scan) and -sS (CONNECT scan) are conflicting. Keeping only -sS.', 'bold gold3')
			self.cmd = self.cmd.replace('-sT ', '')
		if verbosity:
			verbosity_str = int(verbosity) * 'v'
			self.cmd += f' -{verbosity_str}'
		if CONFIG.runners.progress_update_frequency != -1:
			self.cmd += f' --stats-every {CONFIG.runners.progress_update_frequency}s'
		self._progress = {}

	@staticmethod
	def on_line(self, line):
		match = NMAP_PROGRESS_REGEX_1.search(line)
		if match:
			self._progress.update(
				{
					'extra_data': {
						'elapsed': match.group(1),
						'hosts_completed': match.group(2),
						'hosts_up': match.group(3),
					},
				}
			)
			return
		match = NMAP_PROGRESS_REGEX_2.search(line)
		if match:
			self._progress.update({'percent': float(match.group(2))})
			self._progress['extra_data'].update({'scan_type': match.group(1), 'remaining_time': match.group(3)})
			pg = Progress(**self._progress)
			self._progress = {}
			yield pg
		yield line

	@staticmethod
	def on_cmd_done(self):
		if not os.path.exists(self.output_path):
			yield Error(message=f'Could not find XML results in {self.output_path}')
			return
		yield Info(message=f'XML results saved to {self.output_path}')
		yield from self.xml_to_json()

	def xml_to_json(self):
		results = []
		with open(self.output_path, 'r') as f:
			content = f.read()
			try:
				results = xmltodict.parse(content)  # parse XML to dict
			except Exception as exc:
				yield Error(
					message=f'Cannot parse XML output {self.output_path} to valid JSON.',
					traceback=traceback_as_string(exc),
				)
		yield from nmapData(results)


class nmapData(dict):
	def __iter__(self):
		datas = []
		ips = []
		scan_type = self._get_scan_type()
		hosts = self._get_hosts()
		techs = []
		for host in hosts:
			hostname = self._get_hostname(host)
			tags = []
			global_confidence = 'high'
			is_mass_scan = len(self._get_ports(host)) > 20
			if is_mass_scan:
				yield Warning(
					message=f'Unusual number of ports found for host {hostname}. There might be an IDS interfering with the scan.',
				)
				global_confidence = 'low'
				tags = ['ids']
			ip = self._get_ip(host)
			if ip and ip not in ips:
				yield Ip(ip=ip, alive=True, host=hostname, tags=tags + ['ping'])
				ips.append(ip)
			for port in self._get_ports(host):
				# Get port number
				port_number = port['@portid']
				if not port_number or not port_number.isdigit():
					continue
				port_number = int(port_number)

				# Get port state
				state = port.get('state', {}).get('@state', '')
				reason = port.get('state', {}).get('@reason', '')

				# Get extra data
				extra_data = self._get_extra_data(port)
				service_name = extra_data.get('service_name', '')
				version_exact = extra_data.get('version_exact', False)
				service_confidence = extra_data.get('confidence', 'low')
				if service_confidence != 'low':
					global_confidence = 'high'

				# Grab CPEs
				cpes = extra_data.get('cpe', [])

				# Get script output
				scripts = self._get_scripts(port)

				# Get port protocol
				protocol = port['@protocol'].lower()

				# Yield port data
				yield Port(
					port=port_number,
					ip=ip,
					host=hostname,
					state=state,
					service_name=service_name,
					protocol=protocol,
					extra_data=extra_data,
					confidence=global_confidence,
					service_confidence=service_confidence,
					tags=tags + [scan_type, reason],
				)

				# Technology
				if service_confidence == 'high' and extra_data.get('product'):
					techs.append(
						Technology(
							match=f'{ip}:{port_number}',
							product=extra_data['product'],
							version=extra_data.get('version'),
						)
					)

				# Parse each script output to get vulns
				for script in scripts:
					script_id = script['id']
					output = script['output']
					extra_data = {'script': script_id}
					if service_name:
						extra_data['service_name'] = service_name
					funcmap = {
						'vulscan': self._parse_vulscan_output,
						'vulners': self._parse_vulners_output,
					}
					func = funcmap.get(script_id)
					if not func:
						debug(f'Script output parser for "{script_id}" is not supported YET.', sub='cve.nmap')
						continue
					for data in func(output, cpes=cpes):
						data.matched_at = f'{hostname}:{port_number}'
						data.ip = ip
						data.extra_data.update(extra_data)
						confidence = global_confidence
						if 'cpe-match' in data.tags:
							confidence = 'high' if version_exact else 'medium'
						data.confidence = confidence
						if is_mass_scan:
							data.tags = list(set(data.tags + ['mass']))
						if CONFIG.runners.skip_cve_low_confidence and data.confidence == 'low':
							debug(f'{data.id}: ignored (low confidence).', sub='cve.nmap')
							continue
						if data in datas:
							continue
						yield data
						# datas.append(data)
		yield from techs

	# ---------------------#
	# XML FILE EXTRACTORS #
	# ---------------------#
	def _get_scan_type(self):
		return self.get('nmaprun', {}).get('scaninfo', {}).get('@type')

	def _get_hosts(self):
		hosts = self.get('nmaprun', {}).get('host', {})
		if isinstance(hosts, dict):
			hosts = [hosts]
		return hosts

	def _get_ports(self, host_cfg):
		ports = host_cfg.get('ports', {}).get('port', [])
		if isinstance(ports, dict):
			ports = [ports]
		return ports

	def _get_hostname(self, host_cfg):
		hostnames = host_cfg.get('hostnames', {})
		if hostnames:
			hostnames = hostnames.get('hostname', [])
			if isinstance(hostnames, dict):
				hostnames = [hostnames]
			if hostnames:
				hostname = hostnames[0]['@name']
		else:
			hostname = self._get_address(host_cfg).get('@addr', None)
		return hostname

	def _get_address(self, host_cfg):
		if isinstance(host_cfg.get('address', {}), list):
			addresses = host_cfg.get('address', {})
			for address in addresses:
				if address.get('@addrtype') == 'ipv4':
					return address
		return host_cfg.get('address', {})

	def _get_ip(self, host_cfg):
		return self._get_address(host_cfg).get('@addr', None)

	def _get_extra_data(self, port_cfg):
		extra_data = {k.lstrip('@'): v for k, v in port_cfg.get('service', {}).items()}

		# Strip product / version strings
		if 'product' in extra_data:
			extra_data['product'] = extra_data['product'].lower()

		# Get version and post-process it
		version = None
		if 'version' in extra_data:
			vsplit = extra_data['version'].split(' ')
			version_exact = True
			os = None
			if len(vsplit) == 3:
				version, os, extra_version = tuple(vsplit)
				if os == 'or' and extra_version == 'later':
					version_exact = False
					os = None
				version = f'{version}-{extra_version}'
			elif len(vsplit) == 2:
				version, os = tuple(vsplit)
			elif len(vsplit) == 1:
				version = vsplit[0]
			else:
				version = extra_data['version']
			if os:
				extra_data['os'] = os
			if version:
				extra_data['version'] = version
			extra_data['version_exact'] = version_exact

		# Grap service name
		product = extra_data.get('product', None) or extra_data.get('name', None)
		if product:
			service_name = product
			if version:
				service_name += f'/{version}'
			extra_data['service_name'] = service_name

		# Grab CPEs
		cpes = extra_data.get('cpe', [])
		if not isinstance(cpes, list):
			cpes = [cpes]
			extra_data['cpe'] = cpes
		if not cpes:
			debug(f'No CPEs found for {extra_data.get("product", "")} {extra_data.get("version", "")}', sub='cve.nmap')
		else:
			debug(f'Found CPEs: {",".join(cpes)}', sub='cve.nmap')

		# Grab confidence
		conf = int(extra_data.get('conf', 0))
		confidence = 'low'
		if conf > 7:
			confidence = 'high'
		elif conf > 4:
			confidence = 'medium'
		extra_data['confidence'] = confidence

		# Build custom CPE
		if product and version:
			vsplit = version.split('-')
			version_cpe = vsplit[0] if not version_exact else version
			cpe = VulnMulti.create_cpe_string(product, version_cpe)
			if cpe not in cpes:
				cpes.append(cpe)
				debug(f'Added new CPE from identified product and version: {cpe}', sub='cve.nmap')

		return extra_data

	def _get_scripts(self, port_cfg):
		scripts = port_cfg.get('script', [])
		if isinstance(scripts, dict):
			scripts = [scripts]
		scripts = [{k.lstrip('@'): v for k, v in script.items()} for script in scripts]
		return scripts

	# --------------#
	# VULN PARSERS #
	# --------------#
	def _parse_vulscan_output(self, out, cpes=[]):
		"""Parse nmap vulscan script output.

		Args:
			out (str): Vulscan script output.

		Yields:
			Vulnerability: Vulnerability object.
		"""
		provider_name = ''
		for line in out.splitlines():
			if not line:
				continue
			line = line.strip()
			if not line.startswith('[') and line != 'No findings':  # provider line
				provider_name, _ = tuple(line.split(' - '))
				continue
			reg = r'\[([ A-Za-z0-9_@./#&+-]*)\] (.*)'
			matches = re.match(reg, line)
			if not matches:
				continue
			vuln_id, vuln_title = matches.groups()
			vuln = Vulnerability(id=vuln_id, name=vuln_id, description=vuln_title, provider=provider_name, tags=[provider_name])
			if provider_name == 'MITRE CVE':
				vuln_lookup = VulnMulti.lookup_cve(vuln_id, *cpes)
				if vuln_lookup:
					vuln.merge_with(vuln_lookup)
				yield vuln
			else:
				debug(f'Vulscan provider {provider_name} is not supported YET.', sub='cve.nmap')
				continue

	def _parse_vulners_output(self, out, **kwargs):
		cpes = kwargs.get('cpes', [])
		provider_name = 'vulners'
		for line in out.splitlines():
			if not line:
				continue
			line = line.strip()
			if line.startswith('cpe:'):
				cpes.append(line.rstrip(':'))
				continue
			elems = tuple(line.split('\t'))

			if len(elems) == 4:  # exploit
				exploit_id, cvss_score, reference_url, _ = elems
				name = exploit_id
				# edb_id = name.split(':')[-1] if 'EDB-ID' in name else None
				exploit = Exploit(
					id=exploit_id,
					name=name,
					provider=provider_name,
					reference=reference_url,
					tags=[exploit_id, provider_name],
					confidence='low',
				)
				# TODO: lookup exploit in ExploitDB to find related CVEs
				# if edb_id:
				# 	print(edb_id)
				# 	exploit_data = VulnMulti.lookup_exploitdb(edb_id)
				yield exploit
				continue

			elif len(elems) == 3:  # vuln
				vuln = {}
				vuln_id, vuln_cvss, reference_url = tuple(line.split('\t'))
				vuln_cvss = float(vuln_cvss)
				vuln_id = vuln_id.split(':')[-1]
				vuln_type = vuln_id.split('-')[0]
				vuln = Vulnerability(
					id=vuln_id,
					name=vuln_id,
					provider=provider_name,
					cvss_score=vuln_cvss,
					references=[reference_url],
					tags=[provider_name],
					confidence='low',
				)
				if vuln_type == 'CVE' or vuln_type == 'PRION:CVE':
					vuln2 = VulnMulti.lookup_cve(vuln_id, *cpes)
					vuln.merge_with(vuln2)
					yield vuln
				else:
					debug(f'Vulners parser for "{vuln_type}" is not implemented YET.', sub='cve.nmap')
			else:
				debug(f'Unrecognized vulners output: {elems}', sub='cve.nmap')
