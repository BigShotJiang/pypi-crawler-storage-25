import json
import logging
import unittest
import unittest.mock

from secator.definitions import (DEBUG, HOST, OPT_NOT_SUPPORTED)
from secator.output_types import Url
from secator.runners import Command
from secator.tasks import httpx
from secator.utils import setup_logging
from secator.utils_test import (FIXTURES_TASKS, FIXTURES_DIR, INPUTS_TASKS,
							  TEST_TASKS, load_fixture, mock_subprocess_popen)

level = logging.DEBUG if DEBUG == ["1"] else logging.ERROR
setup_logging(level)


class FakeCmd(Command):
	opts = {
		'opt1': {'type': int, 'default': 10},
		'opt2': {'type': str, 'default': '1,2,3'},
		'opt3': {'is_flag': True, 'default': False}, # optional
		'opt_with_underscore': {'type': str}, # optional
		'opt-with-hyphen': {'type': str}
	}
	opt_prefix = '-' # all options have '-' as option char
	opt_key_map = {
		'opt3': '--opt3', # but opt3 has '--' prefix
		'opt4': OPT_NOT_SUPPORTED
	}
	opt_value_map = {
		'opt1': lambda x: float(x) # actually opt1 value should be cast to a float
	}


class TestCommandProcessOpts(unittest.TestCase):
	
	def setUp(self):
		self.maxDiff = None

	def test_process_opts_defaults(self):
		run_opts = {}
		opts = FakeCmd._process_opts(
			run_opts,
			FakeCmd.opts,
			FakeCmd.opt_key_map,
			FakeCmd.opt_value_map)
		opts_str = ' '.join([FakeCmd._build_opt_str(v) for k, v in opts.items()])
		self.assertEqual(opts_str, '-opt1 10.0 -opt2 1,2,3')

	def test_process_opts(self):
		run_opts = {
			'opt1': 41,
			'opt2': False, # intentionally omit arg, overriding default value
			'opt3': True
		}
		opts = FakeCmd._process_opts(
			run_opts,
			FakeCmd.opts,
			FakeCmd.opt_key_map,
			FakeCmd.opt_value_map)
		opts_str = ' '.join([FakeCmd._build_opt_str(v) for k, v in opts.items()])
		self.assertEqual(opts_str, '-opt1 41.0 --opt3')

	def test_process_opts_with_prefix(self):
		run_opts = {
			'fakecmd_opt1': 41, # should override opt1 below
			'opt1': 45,
			'opt2': False, # intentionally omit arg, overriding default value
			'opt3': True
		}
		opts = FakeCmd._process_opts(
			run_opts,
			FakeCmd.opts,
			FakeCmd.opt_key_map,
			FakeCmd.opt_value_map,
			opt_aliases=['fakecmd'])
		opts_str = ' '.join([FakeCmd._build_opt_str(v) for k, v in opts.items()])
		self.assertEqual(opts_str, '-opt1 41.0 --opt3')

	def test_process_opts_with_unsupported(self):
		run_opts = {
			'fakecmd_opt1': 41, # should override opt1 below
			'opt1': 45,
			'opt2': False, # intentionally omit arg, overriding default value
			'opt3': True,
			'opt4': 'test_unsupported'
		}
		opts = FakeCmd._process_opts(
			run_opts,
			FakeCmd.opts,
			FakeCmd.opt_key_map,
			FakeCmd.opt_value_map,
			opt_aliases=['fakecmd'])
		opts_str = ' '.join([FakeCmd._build_opt_str(v) for k, v in opts.items()])
		self.assertEqual(opts_str, '-opt1 41.0 --opt3')

	def test_process_opts_with_convert_underscore(self):
		run_opts = {
			'fakecmd_opt1': 41, # should override opt1 below
			'opt1': 45,
			'opt2': False, # intentionally omit arg, overriding default value
			'opt3': True,
			'opt4': 'test_unsupported',
			'opt_with_underscore': 'test'
		}
		opts = FakeCmd._process_opts(
			run_opts,
			FakeCmd.opts,
			FakeCmd.opt_key_map,
			FakeCmd.opt_value_map,
			opt_aliases=['fakecmd'])
		opts_str = ' '.join([FakeCmd._build_opt_str(v) for k, v in opts.items()])
		self.assertEqual(opts_str, '-opt1 41.0 --opt3 -opt-with-underscore test')

	def test_get_opt_value(self):
		run_opts = {
			'fakecmd_opt1': 41,
			'opt1': 45
		}
		opt_value = FakeCmd._get_opt_value(
			run_opts,
			opt_name='opt1',
			opt_aliases=['fakecmd'],
			default=10)
		self.assertEqual(opt_value, 41)

	def test_get_opt_value_false(self):
		run_opts = {
			'fakecmd_opt1': False,
			'opt1': 45
		}
		opt_value = FakeCmd._get_opt_value(
			run_opts,
			opt_name='opt1',
			opt_aliases=['fakecmd'],
			default=10)
		self.assertEqual(opt_value, False)

	def test_get_opt_value_not_supported(self):
		run_opts = {
			'fakecmd_opt1': False,
			'opt1': 45,
			'opt4': OPT_NOT_SUPPORTED
		}
		opt_value = FakeCmd._get_opt_value(
			run_opts,
			opt_name='opt4',
			opt_aliases=['fakecmd'],
			default=10)
		self.assertEqual(opt_value, None)

	# def test_httpx_build_cmd_defaults(self):
	# 	if httpx not in TEST_TASKS:
	# 		return
	# 	run_opts = {}
	# 	host = 'test.synology.me'
	# 	cls = httpx(host, **run_opts)
	# 	default_threads = cls.meta_opts[THREADS]['default']
	# 	expected_cmd = f'httpx {DEFAULT_HTTPX_FLAGS} -u {host} -json -rstr {CONFIG.http.response_max_size_bytes} -rsts {CONFIG.http.response_max_size_bytes} -threads {default_threads}'
	# 	self.assertEqual(cls.cmd, expected_cmd)
	# 	self.assertEqual(cls.print_line, False)
	# 	self.assertEqual(cls.print_item, False)

	# def test_httpx_build_cmd_with_opts(self):
	# 	if httpx not in TEST_TASKS:
	# 		return
	# 	run_opts = {
	# 		FOLLOW_REDIRECT: False,
	# 		DELAY: 1,
	# 		RATE_LIMIT: 120,
	# 		THREADS: 10,
	# 		TIMEOUT: 1,
	# 		HEADER: 'Content-Type: application/xml',
	# 		MATCH_CODES: False, # intentionally omit arg, overriding default value
	# 		'filter_codes': '500',
	# 		'filter_size': '23,33'
	# 	}
	# 	host = 'test.synology.me'
	# 	cls = httpx(host, **run_opts)
	# 	expected_cmd = f"httpx {DEFAULT_HTTPX_FLAGS} -u {host} -json -rstr {CONFIG.http.response_max_size_bytes} -rsts {CONFIG.http.response_max_size_bytes} -header 'Content-Type: application/xml' -delay 1s -rate-limit 120 -threads 10 -timeout 1 -filter-code 500 -filter-length 23,33"
	# 	self.assertEqual(cls.cmd, expected_cmd)
	# 	self.assertEqual(cls.print_line, False)
	# 	self.assertEqual(cls.print_item, False)

	# def test_httpx_build_cmd_with_opts_with_prefix(self):
	# 	if httpx not in TEST_TASKS:
	# 		return
	# 	run_opts = {
	# 		FOLLOW_REDIRECT: False,
	# 		DELAY: 1,
	# 		RATE_LIMIT: 120,
	# 		THREADS: 10,
	# 		TIMEOUT: 1,
	# 		HEADER: 'Content-Type: application/xml',
	# 		MATCH_CODES: False, # intentionally omit arg, overriding default value
	# 		'filter_code': '200',
	# 		'filter_length': 50,
	# 		'httpx.filter_codes': '500',    # prefixed option keys should override
	# 		'httpx_filter_size': '23,33' # prefixed option keys should override
	# 	}
	# 	host = 'test.synology.me'
	# 	cls = httpx(host, **run_opts)
	# 	expected_cmd = f"httpx {DEFAULT_HTTPX_FLAGS} -u {host} -json -rstr {CONFIG.http.response_max_size_bytes} -rsts {CONFIG.http.response_max_size_bytes} -header 'Content-Type: application/xml' -delay 1s -rate-limit 120 -threads 10 -timeout 1 -filter-code 500 -filter-length 23,33"
	# 	self.assertEqual(cls.cmd, expected_cmd)
	# 	self.assertEqual(cls.print_line, False)
	# 	self.assertEqual(cls.print_item, False)


class TestCommandHooks(unittest.TestCase):

	def test_cmd_hooks(self):
		if httpx not in TEST_TASKS:
			return

		def on_item_pre_convert(self, item):
			item['url'] = 'test_changed_url'
			return item

		def on_item(self, item):
			item.status_code = 500
			return item

		def on_end(self):
			self.results = [{'url': 'test_changed_result'}]

		def on_init(self):
			self.cmd = 'test_changed_cmd_init'
			self.run_opts = {}

		def on_start(self):
			self.cmd = 'test_changed_cmd_start'

		hooks = {
			'on_init': [on_init],
			'on_start': [on_start],
			'on_end': [on_end],
			'on_item_pre_convert': [on_item_pre_convert],
			'on_item': [on_item],
		}
		fixture = load_fixture('httpx_output', FIXTURES_DIR)
		with mock_subprocess_popen([json.dumps(fixture)]):
			input = INPUTS_TASKS[HOST]
			cls = httpx(input, hooks=hooks)
			self.assertEqual(cls.cmd.split(' ')[0], 'test_changed_cmd_init')
			items = cls.run()
			item = items[1]
			self.assertIsInstance(item, Url)
			self.assertEqual(item.status_code, 500)
			self.assertEqual(item.url, 'test_changed_url')
			self.assertEqual(cls.cmd.split(' ')[0], 'test_changed_cmd_start')
			self.assertEqual(cls.results, [{'url': 'test_changed_result'}])

	def test_cmd_failed_hook(self):
		if httpx not in TEST_TASKS:
			return

		def raise_exc(self):
			raise Exception('Test passed')

		hooks = {
			'on_init': [raise_exc]
		}
		fixture = FIXTURES_TASKS[httpx]
		with mock_subprocess_popen([json.dumps(fixture)]):
			with self.assertRaises(Exception, msg='Test passed'):
				input = INPUTS_TASKS[HOST]
				httpx(input, hooks=hooks, raise_on_error=True)


class TestCommandChunking(unittest.TestCase):

	def test_needs_chunking_disabled_with_minus_one(self):
		"""Test that input_chunk_size=-1 disables chunking in async mode."""
		class TestCmd(Command):
			cmd = 'test'
			input_chunk_size = -1
			file_flag = None

		# Test with async mode (sync=False) and many targets
		targets = ['target1', 'target2', 'target3', 'target4', 'target5']
		with unittest.mock.patch('secator.runners.task.Task.get_task_class', return_value=TestCmd):
			cmd = TestCmd(targets)
			self.assertFalse(cmd.needs_chunking(sync=False))

	def test_needs_chunking_with_default_size(self):
		"""Test that chunking works with default input_chunk_size."""
		class TestCmd(Command):
			cmd = 'test'
			input_chunk_size = 2  # Small chunk size for testing
			file_flag = None

		# Test with async mode (sync=False) and targets exceeding chunk size
		targets = ['target1', 'target2', 'target3']
		with unittest.mock.patch('secator.runners.task.Task.get_task_class', return_value=TestCmd):
			cmd = TestCmd(targets)
			self.assertTrue(cmd.needs_chunking(sync=False))

	def test_needs_chunking_under_chunk_size(self):
		"""Test that chunking doesn't happen when inputs are under chunk size."""
		class TestCmd(Command):
			cmd = 'test'
			input_chunk_size = 10
			file_flag = None

		# Test with async mode (sync=False) and targets under chunk size
		targets = ['target1', 'target2']
		with unittest.mock.patch('secator.runners.task.Task.get_task_class', return_value=TestCmd):
			cmd = TestCmd(targets)
			self.assertFalse(cmd.needs_chunking(sync=False))


class TestCommandConfigOverrides(unittest.TestCase):

	def test_config_override_input_chunk_size(self):
		"""Test that task-specific config overrides apply to instance attributes."""
		from secator.config import CONFIG

		class OverrideTestCmd(Command):
			cmd = 'test'
			input_chunk_size = 100
			file_flag = None

		targets = ['target1', 'target2', 'target3']
		original_overrides = CONFIG.tasks.overrides
		CONFIG.tasks.overrides = {'OverrideTestCmd': {'input_chunk_size': 2}}
		try:
			with unittest.mock.patch('secator.runners.task.Task.get_task_class', return_value=OverrideTestCmd):
				cmd = OverrideTestCmd(targets)
				self.assertEqual(cmd.input_chunk_size, 2)
				self.assertTrue(cmd.needs_chunking(sync=False))
		finally:
			CONFIG.tasks.overrides = original_overrides

	def test_config_override_does_not_affect_other_tasks(self):
		"""Test that config overrides for one task don't affect other tasks."""
		from secator.config import CONFIG

		class TaskOverrideA(Command):
			cmd = 'test_a'
			input_chunk_size = 100
			file_flag = None

		class TaskOverrideB(Command):
			cmd = 'test_b'
			input_chunk_size = 100
			file_flag = None

		targets = ['t1', 't2', 't3']
		original_overrides = CONFIG.tasks.overrides
		CONFIG.tasks.overrides = {'TaskOverrideA': {'input_chunk_size': 2}}
		try:
			with unittest.mock.patch(
				'secator.runners.task.Task.get_task_class',
				side_effect=lambda x: TaskOverrideA if x == 'TaskOverrideA' else TaskOverrideB
			):
				cmd_a = TaskOverrideA(targets)
				cmd_b = TaskOverrideB(targets)
				self.assertEqual(cmd_a.input_chunk_size, 2)
				self.assertEqual(cmd_b.input_chunk_size, 100)
		finally:
			CONFIG.tasks.overrides = original_overrides
