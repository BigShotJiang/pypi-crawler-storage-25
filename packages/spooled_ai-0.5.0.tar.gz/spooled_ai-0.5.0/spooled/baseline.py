"""Rolling baseline management for traces with intent-scoped baselines.

This module manages intent-scoped baselines (last N successful runs per behavioral pattern)
for comparison. Each intent is identified by a hash of its behavioral fingerprint.
"""

from __future__ import annotations

import fcntl
import json
import math
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


def make_env_fingerprint(environment: dict[str, Any]) -> str:
    """Build a stable string fingerprint of an execution environment.

    Used to detect when a current trace was captured in a different environment
    than the baseline (e.g. baseline on darwin/arm64, CI on linux/x86_64). This
    lets latency signals be downgraded when the comparison would be unfair.

    Returns a string like "darwin/arm64/python3.10" or "unknown" if env is empty.
    """
    if not environment or not isinstance(environment, dict):
        return "unknown"
    os_name = str(environment.get("os") or "unknown").lower()
    platform_str = str(environment.get("platform") or "")
    # Extract architecture from platform string (e.g. "macOS-14.0-arm64-arm-64bit" -> "arm64")
    arch = "unknown"
    for token in platform_str.lower().split("-"):
        if token in ("arm64", "aarch64", "x86_64", "amd64", "i386", "i686"):
            arch = token
            break
    py_version = str(environment.get("python_version") or "")
    py_short = ".".join(py_version.split(".")[:2]) if py_version else "py?"
    return f"{os_name}/{arch}/python{py_short}"


import structlog

from spooled.fingerprint import BehavioralFingerprint, hash_fingerprint
from spooled.models import (
    AgentBaseline,
    BaselineSummary,
    IntentSummary,
    InteractionType,
    RunStatistics,
)
from spooled.storage import get_trace_directory, load_trace_from_jsonl
from spooled.utils import get_auth_headers, sanitize_agent_id

logger = structlog.get_logger(__name__)


def _compute_latency_bounds(latencies: list[float]) -> dict[str, float]:
    """Compute latency bounds (min, p5, p50, p95, max, avg) from a list of values.

    Args:
        latencies: List of latency values in ms

    Returns:
        Dict with min_ms, p5_ms, p50_ms, p95_ms, max_ms, avg_ms keys
    """
    if not latencies:
        return {}
    sorted_lats = sorted(latencies)
    n = len(sorted_lats)

    def _percentile(p: float) -> float:
        idx = max(0, min(n - 1, int(n * p / 100.0)))
        return sorted_lats[idx]

    return {
        "min_ms": sorted_lats[0],
        "p5_ms": _percentile(5),
        "p50_ms": _percentile(50),
        "p95_ms": _percentile(95),
        "max_ms": sorted_lats[-1],
        "avg_ms": sum(sorted_lats) / n,
    }


def _parse_iso_datetime(s: str) -> datetime:
    """Parse ISO 8601 datetime string (handles Z suffix for Python < 3.11)."""
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    return datetime.fromisoformat(s)


class BaselineManager:
    """Manages intent-scoped rolling baselines for agent traces."""

    def __init__(self, agent_id: str, baseline_size: int = 10) -> None:
        """Initialize baseline manager.

        Args:
            agent_id: Agent identifier
            baseline_size: Number of successful runs to keep per intent baseline.
                          Can also be set via SPOOLED_BASELINE_WINDOW_SIZE env var.
                          Max 100.
        """
        self.agent_id = sanitize_agent_id(agent_id)
        # Resolve from env var if caller uses default
        env_size = os.getenv("SPOOLED_BASELINE_WINDOW_SIZE", "").strip()
        if env_size and baseline_size == 10:  # Only override if using default
            try:
                baseline_size = int(env_size)
            except ValueError:
                pass
        self.baseline_size = max(1, min(100, baseline_size))
        self.baseline_dir = get_trace_directory() / "baselines"
        self.baseline_dir.mkdir(parents=True, exist_ok=True)
        self._baseline: AgentBaseline | None = None
        self.tags: list[str] = []
        # Populated by pull_from_remote with a human-readable explanation when
        # the call returns False. CLIs read this to surface a useful message.
        self.last_pull_message: str | None = None

    def get_baseline_file(self) -> Path:
        """Get the baseline file path for this agent.

        Returns:
            Path to baseline file

        Raises:
            ValueError: If agent_id would escape the baseline directory
        """
        path = (self.baseline_dir / f"{self.agent_id}.json").resolve()
        if not str(path).startswith(str(self.baseline_dir.resolve())):
            raise ValueError(f"Invalid agent_id would escape baseline directory: {self.agent_id}")
        return path

    def _extract_component_identifier(self, interaction: dict[str, Any]) -> str | None:
        """Extract component identifier from an interaction.

        Args:
            interaction: Interaction dictionary

        Returns:
            Component identifier string (e.g., "llm:gpt-4", "tool:search", "http:GET"), or None
        """
        interaction_type = interaction.get("interaction_type", "")

        if interaction_type == InteractionType.LLM_CALL.value:
            # For LLM calls, use model name
            model = (
                (interaction.get("metadata") or {}).get("model")
                or (interaction.get("input") or {}).get("model")
                or "unknown"
            )
            return f"llm:{model}"

        elif interaction_type == InteractionType.TOOL_CALL.value:
            # For tool calls, use function name
            inp = interaction.get("input", {})
            function_name = inp.get("function") or inp.get("tool") or "unknown"
            return f"tool:{function_name}"

        elif interaction_type == InteractionType.HTTP_REQUEST.value:
            # For HTTP requests, use method and domain
            method = (interaction.get("input") or {}).get("method", "UNKNOWN")
            url = (interaction.get("input") or {}).get("url", "")
            if url:
                try:
                    parsed = urlparse(url)
                    domain = parsed.netloc or parsed.path.split("/")[0] or "unknown"
                    return f"http:{method}:{domain}"
                except Exception:
                    return f"http:{method}"
            return f"http:{method}"

        elif interaction_type == InteractionType.OTHER.value:
            # For other types, use a generic identifier
            other_type = (interaction.get("input") or {}).get("type", "unknown")
            return f"other:{other_type}"

        return None

    def load_baseline(self) -> AgentBaseline:
        """Load the baseline for this agent (Cold Start: no file = empty baseline).

        Works out of the box with zero existing baseline files; creates an empty
        intents dict on the fly so execution is never blocked.
        Returns:
            AgentBaseline model instance
        """
        if self._baseline is not None:
            return self._baseline

        baseline_file = self.get_baseline_file()

        if not baseline_file.exists():
            self._baseline = AgentBaseline(
                agent_id=self.agent_id,
                updated_at=datetime.now(timezone.utc),
                intents={},
            )
            return self._baseline

        try:
            with open(baseline_file) as f:
                data = json.load(f)

            # Handle migration from old format (backward compatibility)
            if "runs" in data and "intents" not in data:
                logger.info(
                    "Migrating baseline from old format to intent-scoped format",
                    agent_id=self.agent_id,
                )
                self._baseline = self._migrate_old_baseline(data)
            else:
                # Convert datetime strings and migrate old RunStatistics format
                if "updated_at" in data:
                    data["updated_at"] = _parse_iso_datetime(data["updated_at"])
                if "intents" in data:
                    for _intent_id, intent_data in data["intents"].items():
                        if "updated_at" in intent_data:
                            intent_data["updated_at"] = _parse_iso_datetime(
                                intent_data["updated_at"]
                            )
                        # Migrate old RunStatistics: add total_latency_ms, has_error to runs
                        for run in intent_data.get("runs", []):
                            if "total_latency_ms" not in run:
                                comp = run.get("component_latencies", {})
                                run["total_latency_ms"] = sum(
                                    v for v in comp.values() if isinstance(v, (int, float))
                                )
                                run["has_error"] = False
                        # Map avg_total_tokens -> avg_tokens for backward compat
                        if "avg_total_tokens" in intent_data and "avg_tokens" not in intent_data:
                            intent_data["avg_tokens"] = intent_data.get("avg_total_tokens") or 0.0
                        # Remove deprecated fields before Pydantic parse
                        intent_data.pop("intent_id", None)
                        intent_data.pop("avg_total_tokens", None)

                self._baseline = AgentBaseline(**data)
                # Recompute stats from runs (handles migrated data)
                for intent_stat in self._baseline.intents.values():
                    if intent_stat.runs:
                        self._update_intent_statistics(intent_stat)

            return self._baseline
        except Exception as e:
            logger.error(
                "Failed to load baseline, using empty baseline. "
                "This may indicate a corrupted baseline file.",
                error=str(e),
                baseline_file=str(self._baseline_file),
            )
            self._baseline = AgentBaseline(
                agent_id=self.agent_id,
                updated_at=datetime.now(timezone.utc),
                intents={},
            )
            return self._baseline

    def _migrate_old_baseline(self, old_data: dict[str, Any]) -> AgentBaseline:
        """Migrate old baseline format to new intent-scoped format.

        Args:
            old_data: Old baseline data with "runs" list

        Returns:
            AgentBaseline with migrated data
        """
        intents: dict[str, RunStatistics] = {}

        for run in old_data.get("runs", []):
            fingerprint = run.get("fingerprint", {})
            intent_id = hash_fingerprint(fingerprint)

            # Normalize run to new format (total_latency_ms, total_tokens, has_error)
            component_latencies = run.get("component_latencies", {})
            total_latency_ms = sum(
                v for v in component_latencies.values() if isinstance(v, (int, float))
            )
            entry = {
                "run_id": run.get("run_id"),
                "timestamp": run.get("timestamp"),
                "fingerprint": fingerprint,
                "total_tokens": run.get("total_tokens", 0),
                "total_latency_ms": total_latency_ms,
                "has_error": False,
                "component_latencies": component_latencies,
            }

            if intent_id not in intents:
                intents[intent_id] = RunStatistics(
                    fingerprint=fingerprint,
                    runs=[],
                    updated_at=datetime.now(timezone.utc),
                )

            intents[intent_id].runs.append(entry)

        # Keep only last N runs per intent
        for intent_stat in intents.values():
            intent_stat.runs = intent_stat.runs[-self.baseline_size :]
            self._update_intent_statistics(intent_stat)

        return AgentBaseline(
            agent_id=self.agent_id,
            updated_at=datetime.now(timezone.utc),
            intents=intents,
        )

    def save_baseline(self, baseline: AgentBaseline | None = None) -> None:
        """Save the baseline to disk with atomic write and file locking.

        Uses write-to-temp + os.replace() for crash safety, and fcntl.flock()
        to prevent concurrent writes from corrupting the file.

        Args:
            baseline: Optional AgentBaseline to save (uses cached if not provided)
        """
        if baseline is None:
            baseline = self.load_baseline()

        baseline_file = self.get_baseline_file()

        try:
            # Convert to JSON-serializable format
            data = baseline.model_dump(mode="json")

            # Atomic write: write to temp file, then rename
            baseline_file.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp_path = tempfile.mkstemp(
                dir=str(baseline_file.parent),
                prefix=f".{baseline_file.stem}_",
                suffix=".tmp",
            )
            try:
                with os.fdopen(fd, "w") as tmp_f:
                    # Acquire exclusive file lock with 5s timeout
                    try:
                        fcntl.flock(tmp_f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    except OSError:
                        # LOCK_NB failed — retry with blocking up to 5s
                        import signal

                        def _timeout_handler(signum, frame):
                            raise TimeoutError("Baseline file lock timed out after 5s")

                        old_handler = signal.signal(signal.SIGALRM, _timeout_handler)
                        signal.alarm(5)
                        try:
                            fcntl.flock(tmp_f.fileno(), fcntl.LOCK_EX)
                        finally:
                            signal.alarm(0)
                            signal.signal(signal.SIGALRM, old_handler)

                    json.dump(data, tmp_f, indent=2)

                # Atomic rename (same filesystem guaranteed by mkstemp in same dir)
                os.replace(tmp_path, str(baseline_file))
            except Exception:
                # Clean up temp file on failure
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
                raise

            self._baseline = baseline
        except Exception as e:
            logger.error("Failed to save baseline", error=str(e))
            raise

    def _update_intent_statistics(self, intent_stat: RunStatistics) -> None:
        """Update aggregated statistics for an intent from runs.

        Computes avg_latency, std_dev_latency, avg_tokens, error_rate, sample_count,
        and component_avg_latencies from the rolling runs list.

        Args:
            intent_stat: RunStatistics to update in place
        """
        if not intent_stat.runs:
            intent_stat.avg_latency = 0.0
            intent_stat.std_dev_latency = 0.0
            intent_stat.avg_tokens = 0.0
            intent_stat.error_rate = 0.0
            intent_stat.sample_count = 0
            intent_stat.component_avg_latencies = {}
            return

        intent_stat.sample_count = len(intent_stat.runs)

        # Latency stats (trace-level)
        latencies = [
            float(run.get("total_latency_ms", 0))
            for run in intent_stat.runs
            if run.get("total_latency_ms") is not None
        ]
        if latencies:
            avg = sum(latencies) / len(latencies)
            intent_stat.avg_latency = avg
            variance = sum((x - avg) ** 2 for x in latencies) / len(latencies)
            intent_stat.std_dev_latency = math.sqrt(variance) if variance > 0 else 0.0
        else:
            intent_stat.avg_latency = 0.0
            intent_stat.std_dev_latency = 0.0

        # Token stats
        token_values = [
            run.get("total_tokens", 0)
            for run in intent_stat.runs
            if run.get("total_tokens") is not None
        ]
        intent_stat.avg_tokens = sum(token_values) / len(token_values) if token_values else 0.0

        # Error rate
        error_count = sum(1 for run in intent_stat.runs if run.get("has_error", False))
        intent_stat.error_rate = error_count / len(intent_stat.runs)

        # Component latencies (for drift detection)
        component_latencies: dict[str, list[float]] = {}
        for run in intent_stat.runs:
            run_component_latencies = run.get("component_latencies", {})
            for component_id, avg_latency in run_component_latencies.items():
                if isinstance(avg_latency, (int, float)):
                    if component_id not in component_latencies:
                        component_latencies[component_id] = []
                    component_latencies[component_id].append(float(avg_latency))

        intent_stat.component_avg_latencies = {
            component_id: sum(latencies) / len(latencies)
            for component_id, latencies in component_latencies.items()
        }

        # Drift envelope: p5/p50/p95 from rolling runs window
        if latencies:
            intent_stat.latency_bounds = _compute_latency_bounds(latencies)

        # Per-tool presence rate: fraction of runs that used each tool.
        # Tools with rate < 1.0 are conditional (e.g., sanctions_screening
        # fires on 70% of runs for NovaPay). Missing a conditional tool is
        # normal variance; missing a mandatory tool (rate == 1.0) is a regression.
        tool_presence: dict[str, int] = {}
        for run in intent_stat.runs:
            fp = run.get("fingerprint") or {}
            tg = fp.get("tool_graph", {}) if isinstance(fp, dict) else {}
            for tool in tg.get("unique_tools", []):
                tool_presence[tool] = tool_presence.get(tool, 0) + 1
        n_runs = len(intent_stat.runs)
        if n_runs > 0:
            intent_stat.tool_presence_rate = {
                tool: round(count / n_runs, 2) for tool, count in sorted(tool_presence.items())
            }

        # Content-blind: aggregate decision distributions across runs
        merged_distributions: dict[str, dict[str, int]] = {}
        for run in intent_stat.runs:
            for field, counts in run.get("decision_counts", {}).items():
                if field not in merged_distributions:
                    merged_distributions[field] = {}
                for value, count in counts.items():
                    if isinstance(count, (int, float)):
                        merged_distributions[field][value] = merged_distributions[field].get(
                            value, 0
                        ) + int(count)
        intent_stat.decision_distributions = merged_distributions

        # Content-blind: aggregate score statistics across runs
        all_scores: dict[str, list[float]] = {}
        for run in intent_stat.runs:
            for field, values in run.get("score_values", {}).items():
                if isinstance(values, list):
                    if field not in all_scores:
                        all_scores[field] = []
                    all_scores[field].extend(
                        float(v) for v in values if isinstance(v, (int, float))
                    )
        score_stats: dict[str, dict[str, float]] = {}
        for field, values in all_scores.items():
            if values:
                avg = sum(values) / len(values)
                variance = sum((x - avg) ** 2 for x in values) / len(values)
                score_stats[field] = {
                    "avg": avg,
                    "std": math.sqrt(variance) if variance > 0 else 0.0,
                    "min": min(values),
                    "max": max(values),
                    "count": float(len(values)),
                }
        intent_stat.score_statistics = score_stats

    def add_trace(self, trace_data: dict[str, Any], status: str) -> None:
        """Add a trace to baseline if successful (intent-scoped, Cold Start safe).

        1. Calculate trace fingerprint_hash (intent_id).
        2. Initialize intents[hash] if it does not exist (Cold Start handling).
        3. Update rolling statistics for that intent only.

        Args:
            trace_data: Trace data dictionary
            status: Trace status (must be "SUCCESS" to be added)
        """
        self.add_to_baseline(trace_data, status)

    def add_to_baseline(self, trace_data: dict[str, Any], status: str) -> None:
        """Add a trace to baseline if it's successful. See add_trace for details."""
        if status != "SUCCESS":
            logger.debug("Skipping non-successful trace for baseline", status=status)
            return

        if not trace_data or not isinstance(trace_data, dict):
            logger.debug(
                "Skipping invalid trace_data for baseline",
                trace_data_type=type(trace_data).__name__,
            )
            return

        interactions = trace_data.get("interactions")
        if not interactions or not isinstance(interactions, list):
            logger.debug("Skipping trace with no interactions for baseline")
            return

        try:
            # Generate fingerprint
            fingerprint = BehavioralFingerprint(trace_data)
            fp_data = fingerprint.generate()

            # Calculate intent_id (hash of fingerprint)
            intent_id = hash_fingerprint(fp_data)

            # Calculate token usage and component latencies for this run
            interactions = trace_data.get("interactions", [])
            total_tokens = 0
            component_latencies: dict[str, list[float]] = {}

            for interaction in interactions:
                # Extract token usage from LLM calls
                if interaction.get("interaction_type") == InteractionType.LLM_CALL.value:
                    usage = (interaction.get("output") or {}).get("usage") or (
                        interaction.get("metadata") or {}
                    ).get("usage")
                    if usage and isinstance(usage, dict):
                        tokens = usage.get("total_tokens")
                        if tokens and isinstance(tokens, (int, float)):
                            total_tokens += tokens

                # Extract latency and component identifier
                metadata = interaction.get("metadata", {})
                latency_ms = metadata.get("latency_ms") or metadata.get("duration_ms")

                if latency_ms is not None:
                    try:
                        latency = float(latency_ms)
                        component_id = self._extract_component_identifier(interaction)
                        if component_id:
                            if component_id not in component_latencies:
                                component_latencies[component_id] = []
                            component_latencies[component_id].append(latency)
                    except (ValueError, TypeError):
                        logger.debug("Invalid latency value", latency=latency_ms)

            # Extract output schema (key names only) from TOOL_CALL outputs.
            # Key names are structural metadata — values are stripped.
            _SDK_META_KEYS = frozenset(
                {
                    "output_keys",
                    "output_types",
                    "content_length",
                    "payload_hash",
                    "redacted",
                    "content_hash",
                }
            )
            output_schemas: dict[str, list[str]] = {}

            for interaction in interactions:
                if interaction.get("interaction_type") == InteractionType.TOOL_CALL.value:
                    output = interaction.get("output") or {}
                    interaction.get("metadata") or {}
                    tool_name = (
                        (interaction.get("input") or {}).get("function")
                        or (interaction.get("input") or {}).get("tool")
                        or (interaction.get("input") or {}).get("tool_name")
                        or "unknown"
                    )

                    # Capture output schema (field names only — content-blind)
                    output_keys = output.get("output_keys", [])
                    if not output_keys and isinstance(output, dict):
                        output_keys = [k for k in output.keys() if k not in _SDK_META_KEYS]
                    if output_keys:
                        output_schemas[tool_name] = sorted(output_keys)

                    # Decision value extraction REMOVED (content-blind).
                    # The recorder no longer sets _decision_values.

                    # Score value extraction REMOVED (content-blind).
                    # The recorder no longer sets _score_values.

            # Load baseline
            baseline = self.load_baseline()

            # Get or create intent statistics
            if intent_id not in baseline.intents:
                baseline.intents[intent_id] = RunStatistics(
                    fingerprint=fp_data,
                    runs=[],
                    updated_at=datetime.now(timezone.utc),
                )

            intent_stat = baseline.intents[intent_id]

            # Sum total trace latency from component latencies
            run_component_avgs = {
                cid: sum(lats) / len(lats) for cid, lats in component_latencies.items()
            }
            total_latency_ms = sum(run_component_avgs.values())

            # Update output schema snapshots on intent (latest wins)
            if output_schemas:
                intent_stat.output_schema_snapshots = output_schemas

            # Capture environment fingerprint on first run for this intent.
            # Later comparisons will downgrade latency signals when the current
            # trace runs in a different environment (e.g., baseline on Mac, CI on Linux).
            if intent_stat.baseline_env_fingerprint is None:
                env = trace_data.get("trace", {}).get("environment") or {}
                intent_stat.baseline_env_fingerprint = make_env_fingerprint(env)

            # Add new entry with metrics
            entry = {
                "run_id": trace_data.get("trace", {}).get("run_id"),
                "timestamp": trace_data.get("trace", {}).get("timestamp"),
                "fingerprint": fp_data,
                "total_tokens": total_tokens,
                "total_latency_ms": total_latency_ms,
                "has_error": False,
                "component_latencies": run_component_avgs,
            }

            intent_stat.runs.append(entry)

            # Keep only last N runs
            intent_stat.runs = intent_stat.runs[-self.baseline_size :]

            # Update statistics
            intent_stat.updated_at = datetime.now(timezone.utc)
            self._update_intent_statistics(intent_stat)

            # Update baseline timestamp
            baseline.updated_at = datetime.now(timezone.utc)

            # Save baseline
            self.save_baseline(baseline)

            logger.info(
                "Added trace to baseline",
                agent_id=self.agent_id,
                run_id=entry["run_id"],
                intent_id=intent_id[:16] + "...",
                intent_baseline_size=len(intent_stat.runs),
                total_tokens=total_tokens,
                component_count=len(component_latencies),
            )

        except Exception as e:
            logger.warning("Failed to add trace to baseline", error=str(e), exc_info=True)

    def get_intent_id(self, trace_data: dict[str, Any]) -> str | None:
        """Get the intent_id (fingerprint hash) for a trace.

        Args:
            trace_data: Trace data dictionary

        Returns:
            Intent ID (SHA-256 hash of fingerprint), or None if fingerprint generation fails
        """
        try:
            fingerprint = BehavioralFingerprint(trace_data)
            fp_data = fingerprint.generate()
            return hash_fingerprint(fp_data)
        except Exception as e:
            logger.warning("Failed to generate intent_id", error=str(e))
            return None

    def get_intent_baseline(self, intent_id: str) -> RunStatistics | None:
        """Get baseline statistics for a specific intent.

        Args:
            intent_id: Intent identifier (fingerprint hash)

        Returns:
            RunStatistics for the intent, or None if not found
        """
        baseline = self.load_baseline()
        return baseline.intents.get(intent_id)

    def get_stats(self, trace_data: dict[str, Any]) -> RunStatistics | None:
        """Get baseline stats for a trace by its fingerprint_hash.

        Look up stats by trace.fingerprint_hash (intent_id). If not found,
        returns None; does not raise (Cold Start: no history yet for this pattern).

        Args:
            trace_data: Trace data dictionary

        Returns:
            RunStatistics for that intent, or None if no baseline exists for this fingerprint.
        """
        intent_id = self.get_intent_id(trace_data)
        if intent_id is None:
            return None
        return self.get_intent_baseline(intent_id)

    def get_avg_total_tokens(self, intent_id: str | None = None) -> float | None:
        """Get average total tokens for an intent, or across all intents if not specified.

        Args:
            intent_id: Optional intent identifier. If None, returns average across all intents.

        Returns:
            Average total tokens, or None if no baseline exists
        """
        baseline = self.load_baseline()

        if intent_id:
            intent_stat = baseline.intents.get(intent_id)
            return intent_stat.avg_tokens if intent_stat and intent_stat.sample_count > 0 else None

        # Aggregate across all intents
        token_values = [
            intent_stat.avg_tokens
            for intent_stat in baseline.intents.values()
            if intent_stat.sample_count > 0
        ]

        if not token_values:
            return None

        return sum(token_values) / len(token_values)

    def get_component_avg_latencies(self, intent_id: str | None = None) -> dict[str, float]:
        """Get average latency per component for an intent, or across all intents if not specified.

        Args:
            intent_id: Optional intent identifier. If None, returns averages across all intents.

        Returns:
            Dictionary mapping component identifiers to average latencies
        """
        baseline = self.load_baseline()

        if intent_id:
            intent_stat = baseline.intents.get(intent_id)
            return intent_stat.component_avg_latencies if intent_stat else {}

        # Aggregate across all intents
        component_latencies: dict[str, list[float]] = {}

        for intent_stat in baseline.intents.values():
            for component_id, avg_latency in intent_stat.component_avg_latencies.items():
                if component_id not in component_latencies:
                    component_latencies[component_id] = []
                component_latencies[component_id].append(avg_latency)

        return {
            component_id: sum(latencies) / len(latencies)
            for component_id, latencies in component_latencies.items()
        }

    def _from_summary(self, summary: BaselineSummary) -> AgentBaseline:
        """Reconstruct an AgentBaseline from a BaselineSummary.

        The summary doesn't carry the rolling ``runs`` window, so the resulting
        AgentBaseline has ``runs=[]`` for each intent — all aggregate stats are
        preserved.

        Sets ``self._baseline`` as a side effect so callers can treat this as
        "load this summary as the current baseline".
        """
        intents: dict[str, RunStatistics] = {}

        for intent_id, intent_summary in summary.intents.items():
            intents[intent_id] = RunStatistics(
                avg_latency=intent_summary.avg_latency,
                avg_tokens=intent_summary.avg_tokens,
                error_rate=intent_summary.error_rate,
                sample_count=intent_summary.run_count,
                fingerprint=intent_summary.fingerprint,
                fingerprint_hash=intent_summary.fingerprint_hash,
                accepted_fingerprints=intent_summary.accepted_fingerprints,
                accepted_variants=intent_summary.accepted_variants,
                similarity_trend=intent_summary.similarity_trend,
                step_count=intent_summary.step_count,
                tool_call_counts=intent_summary.tool_call_counts,
                tool_presence_rate=intent_summary.tool_presence_rate,
                token_totals=intent_summary.token_totals,
                latency_bounds=intent_summary.latency_bounds,
                component_avg_latencies=intent_summary.component_avg_latencies,
                baseline_env_fingerprint=intent_summary.baseline_env_fingerprint,
                runs=[],
                updated_at=summary.updated_at,
                decision_distributions=intent_summary.decision_distributions,
                output_schema_snapshots=intent_summary.output_schema_snapshots,
                score_statistics=intent_summary.score_statistics,
            )

        self._baseline = AgentBaseline(
            agent_id=summary.agent_id,
            updated_at=summary.updated_at,
            intents=intents,
        )
        return self._baseline

    def load_from_summary(self, summary_path: Path) -> AgentBaseline:
        """Load baseline from a compact summary JSON file (git-committable format).

        Args:
            summary_path: Path to the baseline summary JSON file

        Returns:
            AgentBaseline reconstructed from the summary
        """
        try:
            with open(summary_path) as f:
                data = json.load(f)
            return self._from_summary(BaselineSummary(**data))
        except Exception as e:
            logger.error("Failed to load baseline summary", path=str(summary_path), error=str(e))
            raise

    def _to_summary(self) -> BaselineSummary:
        """Convert the current in-memory AgentBaseline into a compact BaselineSummary.

        This is the canonical shape used for git commits and the SDK wire format
        for push/pull. The `runs` rolling window is dropped; everything else is
        either copied or derived (e.g. ``frequency_pct``, ``contributing_run_ids``).
        """
        baseline = self.load_baseline()
        intents: dict[str, IntentSummary] = {}

        # Compute total runs across all intents for frequency calculation
        total_runs = sum(len(ist.runs) for ist in baseline.intents.values())

        for intent_id, intent_stat in baseline.intents.items():
            # Compute latency bounds from runs if available
            latency_bounds = intent_stat.latency_bounds
            if not latency_bounds and intent_stat.runs:
                latencies = [
                    float(r.get("total_latency_ms", 0))
                    for r in intent_stat.runs
                    if r.get("total_latency_ms") is not None
                ]
                if latencies:
                    sorted_lats = sorted(latencies)
                    p95_idx = max(0, int(len(sorted_lats) * 0.95) - 1)
                    latency_bounds = {
                        "min_ms": sorted_lats[0],
                        "max_ms": sorted_lats[-1],
                        "avg_ms": intent_stat.avg_latency,
                        "p95_ms": sorted_lats[p95_idx],
                    }

            # Build accepted_fingerprints list (never self-reference the intent)
            accepted = [fp for fp in (intent_stat.accepted_fingerprints or []) if fp != intent_id]

            # Collect run_ids for lineage tracking
            run_ids = [r["run_id"] for r in intent_stat.runs if r.get("run_id")]

            # Compute Spooled Score from latest trend data
            intent_spooled_score = None
            if intent_stat.similarity_trend:
                from spooled.scoring import compute_spooled_score as _compute_score

                latest = intent_stat.similarity_trend[-1]
                _fp_status = (
                    latest.fingerprint_status
                    if hasattr(latest, "fingerprint_status")
                    else latest.get("fingerprint_status", "match")
                )
                _sim_score = (
                    latest.similarity_score
                    if hasattr(latest, "similarity_score")
                    else latest.get("similarity_score")
                )
                _raw = _compute_score(
                    fingerprint_status=_fp_status,
                    similarity_score=_sim_score,
                    signals={},  # signals not available at save time
                    metric_deltas={},
                    similarity_trend=intent_stat.similarity_trend,
                )
                from spooled.models import (
                    SpooledScore as _SpooledScore,
                )
                from spooled.models import (
                    SpooledScoreComponents as _SpooledScoreComponents,
                )

                intent_spooled_score = _SpooledScore(
                    score=_raw["score"],
                    grade=_raw["grade"],
                    confidence=_raw["confidence"],
                    components=_SpooledScoreComponents(**_raw["components"]),
                )

            # Compute structural fingerprint hash for rename-resilient matching
            structural_fp_hash = intent_stat.structural_fingerprint_hash
            if not structural_fp_hash and intent_stat.fingerprint:
                try:
                    from spooled.fingerprint import hash_fingerprint as _hash_fp

                    structural_fp_hash = _hash_fp(intent_stat.fingerprint, mode="structural")
                except Exception:
                    pass

            # Intent frequency: what % of total runs followed this pattern
            intent_run_count = len(intent_stat.runs)
            freq_pct = round((intent_run_count / total_runs) * 100, 1) if total_runs > 0 else 0.0

            intents[intent_id] = IntentSummary(
                fingerprint_hash=intent_stat.fingerprint_hash or intent_id,
                structural_fingerprint_hash=structural_fp_hash,
                accepted_fingerprints=accepted,
                accepted_variants=intent_stat.accepted_variants,
                similarity_trend=intent_stat.similarity_trend,
                spooled_score=intent_spooled_score,
                step_count=intent_stat.step_count,
                tool_call_counts=intent_stat.tool_call_counts,
                tool_presence_rate=intent_stat.tool_presence_rate,
                token_totals=intent_stat.token_totals,
                latency_bounds=latency_bounds,
                avg_latency=intent_stat.avg_latency,
                avg_tokens=intent_stat.avg_tokens,
                run_count=intent_stat.sample_count,
                frequency_pct=freq_pct,
                error_rate=intent_stat.error_rate,
                component_avg_latencies=intent_stat.component_avg_latencies,
                fingerprint=intent_stat.fingerprint,
                contributing_run_ids=run_ids,
                baseline_env_fingerprint=intent_stat.baseline_env_fingerprint,
                # Content-blind signal data
                decision_distributions=intent_stat.decision_distributions,
                output_schema_snapshots=intent_stat.output_schema_snapshots,
                score_statistics=intent_stat.score_statistics,
            )

        return BaselineSummary(
            agent_id=baseline.agent_id,
            tags=self.tags,
            updated_at=baseline.updated_at,
            intents=intents,
        )

    def save_summary(self, output_path: Path) -> BaselineSummary:
        """Save baseline as a compact summary JSON (git-committable format).

        Args:
            output_path: Path to write the summary JSON file

        Returns:
            The BaselineSummary that was written
        """
        summary = self._to_summary()

        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(summary.model_dump(mode="json"), f, indent=2)

        logger.info(
            "Baseline summary saved",
            path=str(output_path),
            agent_id=summary.agent_id,
            intent_count=len(summary.intents),
        )
        return summary

    @staticmethod
    def is_summary_file(path: Path) -> bool:
        """Check if a file is a baseline summary (vs full trace or baseline).

        Args:
            path: Path to check

        Returns:
            True if the file looks like a baseline summary JSON
        """
        if not path.exists() or path.suffix != ".json":
            return False
        try:
            with open(path) as f:
                data = json.load(f)
            return data.get("version") is not None and "intents" in data
        except Exception:
            return False

    # Backward compatibility methods
    def get_baseline_fingerprints(self) -> list[dict[str, Any]]:
        """Get all fingerprints from the baseline (for backward compatibility).

        Returns:
            List of fingerprint dictionaries (from all intents)
        """
        baseline = self.load_baseline()
        fingerprints = []
        for intent_stat in baseline.intents.values():
            fingerprints.extend([run.get("fingerprint", {}) for run in intent_stat.runs])
        return fingerprints

    def get_latest_baseline(self) -> dict[str, Any] | None:
        """Get the latest baseline fingerprint (for backward compatibility).

        Returns:
            Latest fingerprint dictionary, or None if no baseline exists
        """
        baseline = self.load_baseline()
        if not baseline.intents:
            return None

        # Get the most recently updated intent
        latest_intent = max(baseline.intents.values(), key=lambda x: x.updated_at)
        if not latest_intent.runs:
            return None

        return latest_intent.runs[-1].get("fingerprint")

    def push_to_remote(self, backend_url: str | None = None) -> bool:
        """Push the compact baseline summary to the remote backend.

        Wire format is ``BaselineSummary`` (the same shape that's committed to git).
        Fetches the remote summary first to merge any ``accepted_variant`` records
        approved elsewhere (e.g. via the UI or another machine) so they aren't
        clobbered by the POST.

        Args:
            backend_url: Backend API URL (defaults to env var SPOOLED_BACKEND_URL)

        Returns:
            True if successful, False otherwise
        """
        backend_url = backend_url or os.getenv("SPOOLED_BACKEND_URL")
        if not backend_url:
            logger.warning("No backend URL configured, cannot push baseline")
            return False

        try:
            import httpx
        except ImportError:
            logger.debug("httpx not available, cannot push baseline")
            return False

        try:
            from spooled.models import AcceptedVariant

            summary = self._to_summary()
            url = f"{backend_url}/api/baselines/{self.agent_id}"
            headers = {"Content-Type": "application/json", **get_auth_headers()}

            # Step 1: fetch remote summary and merge remote-only accepted_variants
            try:
                get_resp = httpx.get(url, timeout=10, headers=headers)
                if get_resp.status_code == 200:
                    remote_intents = get_resp.json().get("intents", {})
                    for intent_id, intent_summary in summary.intents.items():
                        remote_variants = remote_intents.get(intent_id, {}).get(
                            "accepted_variants", []
                        )
                        local_hashes = {
                            v.fingerprint_hash for v in intent_summary.accepted_variants
                        }
                        for rv in remote_variants:
                            if (
                                isinstance(rv, dict)
                                and rv.get("fingerprint_hash") not in local_hashes
                            ):
                                try:
                                    intent_summary.accepted_variants.append(AcceptedVariant(**rv))
                                except Exception:
                                    pass
            except Exception as e:
                logger.debug(
                    "Could not fetch remote baseline for merge (proceeding with local)",
                    error=str(e),
                )

            # Step 2: POST the merged summary
            data = summary.model_dump(mode="json")
            response = httpx.post(url, json=data, timeout=10, headers=headers)
            response.raise_for_status()

            logger.info(
                "Baseline pushed to remote", agent_id=self.agent_id, backend_url=backend_url
            )
            return True
        except Exception as e:
            logger.warning(
                "Failed to push baseline to remote", error=str(e), backend_url=backend_url
            )
            return False

    def pull_from_remote(self, backend_url: str | None = None, timeout: float = 5.0) -> bool:
        """Pull the compact baseline summary from the remote backend.

        Expects the wire format to be ``BaselineSummary`` (the same shape committed
        to git). If the backend has a record from an older client (pre-0.5 wire
        format, ``AgentBaseline`` shape), this returns False and logs a clear
        message — the user should re-push from a current client.

        Args:
            backend_url: Backend API URL (defaults to env var SPOOLED_BACKEND_URL)
            timeout: Request timeout in seconds

        Returns:
            True if successful, False otherwise
        """
        self.last_pull_message = None
        backend_url = backend_url or os.getenv("SPOOLED_BACKEND_URL")
        if not backend_url:
            self.last_pull_message = "No backend URL configured (set SPOOLED_BACKEND_URL)."
            logger.debug(self.last_pull_message)
            return False

        try:
            import httpx
        except ImportError:
            self.last_pull_message = "httpx not installed; cannot pull baseline."
            logger.debug(self.last_pull_message)
            return False

        try:
            url = f"{backend_url}/api/baselines/{self.agent_id}"

            response = httpx.get(
                url,
                timeout=timeout,
                headers={"Content-Type": "application/json", **get_auth_headers()},
            )
            response.raise_for_status()

            data = response.json()
        except httpx.TimeoutException:
            self.last_pull_message = f"Timeout pulling baseline (>{timeout}s)."
            logger.debug(self.last_pull_message)
            return False
        except httpx.HTTPError as e:
            self.last_pull_message = f"HTTP error pulling baseline: {e}"
            logger.debug(self.last_pull_message, backend_url=backend_url)
            return False

        # Detect pre-0.5 wire format (AgentBaseline shape, no "version" field).
        # Backend is schema-blind: anything pushed by an older client still sits in
        # DynamoDB as-is. Bail out with a clear message rather than silently
        # converting (the rich "runs" history would be lost in conversion and the
        # user should know they need to re-push).
        if isinstance(data, dict) and "version" not in data and "intents" in data:
            self.last_pull_message = (
                f"Remote baseline for '{self.agent_id}' is in pre-0.5 wire format and "
                "cannot be pulled. Re-push from a current Spooled client to upgrade the "
                "stored record: spooled baseline push <agent-id>"
            )
            logger.warning(self.last_pull_message, agent_id=self.agent_id)
            return False

        try:
            if "updated_at" in data:
                data["updated_at"] = _parse_iso_datetime(data["updated_at"])
            summary = BaselineSummary(**data)
            baseline = self._from_summary(summary)
            self.save_baseline(baseline)
        except Exception as e:
            self.last_pull_message = f"Failed to parse baseline from remote: {e}"
            logger.warning(self.last_pull_message)
            return False

        logger.info(
            "Baseline pulled from remote",
            agent_id=self.agent_id,
            intent_count=len(baseline.intents),
        )
        return True


def baseline_diff(old: BaselineSummary, new: BaselineSummary) -> dict[str, Any]:
    """Compute a structured diff between two BaselineSummary snapshots.

    Returns a dict with three keys:
    - added:   intents present in new but not old (new behavior patterns)
    - removed: intents present in old but not new (patterns no longer observed)
    - changed: intents in both where metrics shifted significantly

    Each "changed" entry includes delta values for avg_latency, avg_tokens, error_rate,
    and sample_count so callers can render a "what changed" narrative.

    Args:
        old: Previous BaselineSummary (the committed baseline)
        new: Newly generated BaselineSummary

    Returns:
        Dict with "added", "removed", "changed" lists
    """
    old_ids = set(old.intents.keys())
    new_ids = set(new.intents.keys())

    added = [
        {"intent_id": iid, "summary": new.intents[iid].model_dump(mode="json")}
        for iid in sorted(new_ids - old_ids)
    ]
    removed = [
        {"intent_id": iid, "summary": old.intents[iid].model_dump(mode="json")}
        for iid in sorted(old_ids - new_ids)
    ]

    changed = []
    for iid in sorted(old_ids & new_ids):
        o = old.intents[iid]
        n = new.intents[iid]

        deltas: dict[str, Any] = {}

        if o.avg_latency and o.avg_latency > 0:
            lat_delta_pct = (n.avg_latency - o.avg_latency) / o.avg_latency * 100
            if abs(lat_delta_pct) >= 5:
                deltas["avg_latency"] = {
                    "old": round(o.avg_latency, 1),
                    "new": round(n.avg_latency, 1),
                    "delta_pct": round(lat_delta_pct, 1),
                }

        if o.avg_tokens and o.avg_tokens > 0:
            tok_delta_pct = (n.avg_tokens - o.avg_tokens) / o.avg_tokens * 100
            if abs(tok_delta_pct) >= 5:
                deltas["avg_tokens"] = {
                    "old": round(o.avg_tokens, 1),
                    "new": round(n.avg_tokens, 1),
                    "delta_pct": round(tok_delta_pct, 1),
                }

        err_delta = n.error_rate - o.error_rate
        if abs(err_delta) >= 0.05:
            deltas["error_rate"] = {
                "old": round(o.error_rate, 3),
                "new": round(n.error_rate, 3),
                "delta": round(err_delta, 3),
            }

        sample_delta = n.run_count - o.run_count
        if sample_delta != 0:
            deltas["run_count"] = {
                "old": o.run_count,
                "new": n.run_count,
                "delta": sample_delta,
            }

        if deltas:
            changed.append({"intent_id": iid, "deltas": deltas})

    return {"added": added, "removed": removed, "changed": changed}


def cluster_intents(baseline: AgentBaseline, similarity_threshold: float = 0.8) -> list[list[str]]:
    """Group intents with similar behavioral fingerprints into clusters.

    Uses fingerprint_similarity() to compute pairwise structural distance.
    Intents above the threshold are grouped together — these are candidates
    for sharing an intent bucket via accept-variant.

    Args:
        baseline: AgentBaseline to cluster
        similarity_threshold: Minimum similarity to group intents (0.0-1.0, default 0.8)

    Returns:
        List of clusters; each cluster is a list of intent_id strings.
        Singleton clusters (no similar peers) are included.
    """
    from spooled.fingerprint import fingerprint_similarity

    intent_ids = list(baseline.intents.keys())
    assigned: set = set()
    clusters: list[list[str]] = []

    for i, id_a in enumerate(intent_ids):
        if id_a in assigned:
            continue
        fp_a = baseline.intents[id_a].fingerprint
        cluster = [id_a]
        assigned.add(id_a)

        for id_b in intent_ids[i + 1 :]:
            if id_b in assigned:
                continue
            fp_b = baseline.intents[id_b].fingerprint
            if fingerprint_similarity(fp_a, fp_b) >= similarity_threshold:
                cluster.append(id_b)
                assigned.add(id_b)

        clusters.append(cluster)

    return clusters


def auto_merge_intents(baseline: AgentBaseline, similarity_threshold: float = 0.8) -> int:
    """Automatically merge similar intents into clusters.

    For each cluster of similar intents, picks the one with the most runs
    as the primary, adds secondary intent hashes to the primary's
    accepted_fingerprints, merges runs, and removes secondary intents.

    Args:
        baseline: AgentBaseline to merge (modified in place).
        similarity_threshold: Minimum similarity to merge (0.0-1.0, default 0.8).

    Returns:
        Number of intents merged (removed).
    """
    clusters = cluster_intents(baseline, similarity_threshold)
    mergeable = [c for c in clusters if len(c) > 1]
    if not mergeable:
        return 0

    merged_count = 0
    for cluster in mergeable:
        # Pick intent with most runs as primary
        primary_id = max(cluster, key=lambda iid: baseline.intents[iid].sample_count)
        primary = baseline.intents[primary_id]

        for secondary_id in cluster:
            if secondary_id == primary_id:
                continue
            secondary = baseline.intents[secondary_id]

            # Add secondary hash to primary's accepted_fingerprints
            accepted = set(primary.accepted_fingerprints or [])
            accepted.add(secondary_id)
            # Also carry over any accepted_fingerprints from the secondary
            for fp in secondary.accepted_fingerprints or []:
                accepted.add(fp)
            primary.accepted_fingerprints = sorted(accepted)

            # Merge runs
            primary.runs = (primary.runs or []) + (secondary.runs or [])
            primary.sample_count += secondary.sample_count

            # Remove secondary intent
            del baseline.intents[secondary_id]
            merged_count += 1

    # Recalculate statistics on merged intents
    for cluster in mergeable:
        primary_id = max(cluster, key=lambda iid: iid in baseline.intents)
        if primary_id in baseline.intents:
            stat = baseline.intents[primary_id]
            if stat.runs:
                _update_merged_stats(stat)

    return merged_count


def _update_merged_stats(stat: RunStatistics) -> None:
    """Recalculate aggregate statistics after merging runs."""
    if not stat.runs:
        return
    latencies = [r.get("latency_ms", 0) for r in stat.runs if r.get("latency_ms")]
    tokens = [r.get("total_tokens", 0) for r in stat.runs if r.get("total_tokens")]
    if latencies:
        stat.avg_latency = sum(latencies) / len(latencies)
        if len(latencies) > 1:
            mean = stat.avg_latency
            stat.std_dev_latency = (sum((x - mean) ** 2 for x in latencies) / len(latencies)) ** 0.5
    if tokens:
        stat.avg_tokens = sum(tokens) / len(tokens)
    stat.sample_count = len(stat.runs)


def load_baseline_from_path(path: Path, agent_id: str) -> AgentBaseline:
    """Load a baseline from a path, auto-detecting format.

    Supports:
    - Baseline summary JSON (has "version" and "intents" keys)
    - Full AgentBaseline JSON
    - Trace JSONL file (used to build baseline)

    Args:
        path: Path to baseline file
        agent_id: Agent identifier

    Returns:
        AgentBaseline instance
    """
    manager = BaselineManager(agent_id)

    if BaselineManager.is_summary_file(path):
        return manager.load_from_summary(path)

    if path.suffix == ".json":
        with open(path) as f:
            data = json.load(f)
        # Check if it's an AgentBaseline
        if "intents" in data and "agent_id" in data:
            if "updated_at" in data:
                data["updated_at"] = _parse_iso_datetime(data["updated_at"])
            for intent_data in data.get("intents", {}).values():
                if "updated_at" in intent_data:
                    intent_data["updated_at"] = _parse_iso_datetime(intent_data["updated_at"])
            return AgentBaseline(**data)

    # Fall back to loading as trace and building baseline
    if path.suffix == ".jsonl":
        trace_data = load_trace_from_jsonl(path)
    else:
        with open(path) as f:
            trace_data = json.load(f)

    status = trace_data.get("trace", {}).get("status", "SUCCESS")
    manager.add_to_baseline(trace_data, status)
    return manager.load_baseline()


def create_baseline_from_trace(trace_file: Path, agent_id: str, baseline_size: int = 10) -> None:
    """Create or update baseline from a trace file.

    Args:
        trace_file: Path to trace file
        agent_id: Agent identifier
        baseline_size: Number of runs to keep in baseline
    """
    manager = BaselineManager(agent_id, baseline_size)

    # Load trace
    if trace_file.suffix == ".jsonl":
        trace_data = load_trace_from_jsonl(trace_file)
    else:
        with open(trace_file) as f:
            trace_data = json.load(f)

    status = trace_data.get("trace", {}).get("status", "UNKNOWN")
    manager.add_to_baseline(trace_data, status)
