"""Optional Prometheus metrics for Spooled SDK observability.

Metrics are lazily initialized and no-op when prometheus_client is not installed.

Install with: pip install "spooled[metrics]"
"""

from __future__ import annotations

from typing import Any


class _NoOpMetric:
    """Drop-in replacement when prometheus_client is not available."""

    def labels(self, *args: Any, **kwargs: Any) -> _NoOpMetric:
        return self

    def inc(self, amount: float = 1) -> None:
        pass

    def observe(self, amount: float) -> None:
        pass


_NO_OP = _NoOpMetric()

# Lazy singletons — created on first access
_traces_total: Any = None
_interactions_total: Any = None
_flush_duration: Any = None
_flush_errors: Any = None


def _ensure_metrics() -> bool:
    """Create Prometheus metric objects if prometheus_client is available.

    Returns True if metrics are available, False otherwise.
    """
    global _traces_total, _interactions_total, _flush_duration, _flush_errors

    if _traces_total is not None:
        return _traces_total is not _NO_OP

    try:
        from prometheus_client import Counter, Histogram

        _traces_total = Counter(
            "spooled_traces_total",
            "Total traces started",
            ["agent_id", "status"],
        )
        _interactions_total = Counter(
            "spooled_interactions_total",
            "Total interactions recorded",
            ["agent_id", "interaction_type"],
        )
        _flush_duration = Histogram(
            "spooled_flush_duration_seconds",
            "Time spent flushing interaction buffers",
            ["agent_id"],
        )
        _flush_errors = Counter(
            "spooled_flush_errors_total",
            "Total flush errors",
            ["agent_id", "error_type"],
        )
        return True
    except ImportError:
        _traces_total = _NO_OP
        _interactions_total = _NO_OP
        _flush_duration = _NO_OP
        _flush_errors = _NO_OP
        return False


def inc_traces(agent_id: str, status: str = "started") -> None:
    """Increment the traces counter."""
    _ensure_metrics()
    _traces_total.labels(agent_id=agent_id, status=status).inc()


def inc_interactions(agent_id: str, interaction_type: str) -> None:
    """Increment the interactions counter."""
    _ensure_metrics()
    _interactions_total.labels(agent_id=agent_id, interaction_type=interaction_type).inc()


def observe_flush_duration(agent_id: str, duration_seconds: float) -> None:
    """Record a flush duration."""
    _ensure_metrics()
    _flush_duration.labels(agent_id=agent_id).observe(duration_seconds)


def inc_flush_errors(agent_id: str, error_type: str = "unknown") -> None:
    """Increment the flush error counter."""
    _ensure_metrics()
    _flush_errors.labels(agent_id=agent_id, error_type=error_type).inc()
