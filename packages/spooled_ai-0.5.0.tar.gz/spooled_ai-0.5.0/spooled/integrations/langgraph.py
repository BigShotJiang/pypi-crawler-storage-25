"""LangGraph integration for Spooled.

Extends the LangChain callback handler with LangGraph-specific tracking:
- Node execution (start/end/error)
- State transitions between nodes
- Conditional edge routing
- Parallel node detection (tagged with parallel_group)
- Subgraph depth tracking
"""

from __future__ import annotations

import uuid
from typing import Any

import structlog

from spooled.models import InteractionType

logger = structlog.get_logger(__name__)

# Try importing LangGraph-specific types
try:
    from langchain_core.callbacks import BaseCallbackHandler  # type: ignore

    _LANGCHAIN_IMPORT_ERROR: Exception | None = None
except Exception as e:  # pragma: no cover
    try:
        from langchain.callbacks.base import BaseCallbackHandler  # type: ignore

        _LANGCHAIN_IMPORT_ERROR = None
    except Exception as inner:  # pragma: no cover
        BaseCallbackHandler = object  # type: ignore
        _LANGCHAIN_IMPORT_ERROR = inner or e

try:
    import langgraph  # type: ignore  # noqa: F401

    _LANGGRAPH_AVAILABLE = True
except ImportError:
    _LANGGRAPH_AVAILABLE = False


def _to_jsonable(value: Any) -> Any:
    """Convert value to JSON-serializable form."""
    if value is None:
        return None
    try:
        import json

        json.dumps(value)
        return value
    except Exception:
        return str(value)


class SpooledLangGraphCallbackHandler(BaseCallbackHandler):
    """LangGraph callback handler for Spooled.

    Extends base LangChain callback handling with LangGraph-specific
    node tracking, state transitions, conditional edges, and parallel
    node detection.

    Usage:
        from spooled.integrations.langgraph import SpooledLangGraphCallbackHandler

        handler = SpooledLangGraphCallbackHandler(recorder)
        graph = StateGraph(...)
        app = graph.compile()
        result = app.invoke(input, config={"callbacks": [handler]})
    """

    def __init__(self, recorder: Any) -> None:
        if _LANGCHAIN_IMPORT_ERROR is not None:
            raise ImportError(
                "LangChain/LangGraph is not installed. "
                "Install with: pip install langgraph langchain-core"
            ) from _LANGCHAIN_IMPORT_ERROR

        self.recorder = recorder

        # Stack-based tracking for nested calls
        self._llm_inputs: list[dict[str, Any]] = []
        self._tool_inputs: list[dict[str, Any]] = []
        self._chain_inputs: list[dict[str, Any]] = []
        self._retriever_inputs: list[dict[str, Any]] = []

        # LangGraph-specific tracking
        self._node_stack: list[dict[str, Any]] = []  # Track nested node execution
        self._active_nodes: set[str] = set()  # Currently executing nodes
        self._parallel_group: str | None = None  # Current parallel group ID
        self._subgraph_depth: int = 0  # Nesting depth for subgraphs
        self._state_transitions: list[dict[str, Any]] = []  # State transition log
        self._last_node: str | None = None  # Last completed node name

    # ── LLM callbacks ────────────────────────────────────────────────────

    def on_llm_start(self, serialized: dict, prompts: list[str], **kwargs: Any) -> None:  # type: ignore[override]
        model_name = (
            serialized.get("kwargs", {}).get("model_name")
            or serialized.get("name")
            or serialized.get("id", ["unknown"])[-1]
        )
        self._llm_inputs.append(
            {
                "model": model_name,
                "serialized": _to_jsonable(serialized),
                "prompts": _to_jsonable(prompts),
            }
        )

    def on_chat_model_start(self, serialized: dict, messages: list[Any], **kwargs: Any) -> None:  # type: ignore[override]
        model_name = (
            serialized.get("kwargs", {}).get("model_name")
            or serialized.get("name")
            or serialized.get("id", ["unknown"])[-1]
        )
        self._llm_inputs.append(
            {
                "model": model_name,
                "serialized": _to_jsonable(serialized),
                "messages": _to_jsonable(messages),
            }
        )

    def on_llm_end(self, response: Any, **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._llm_inputs.pop() if self._llm_inputs else {}
        model = input_data.pop("model", "unknown")
        output_data = {"response": _to_jsonable(response)}
        metadata: dict[str, Any] = {
            "source": "langgraph",
            "model": model,
        }
        if self._node_stack:
            metadata["langgraph_node"] = self._node_stack[-1].get("name")
        if self._subgraph_depth > 0:
            metadata["subgraph_depth"] = self._subgraph_depth

        record_kwargs: dict[str, Any] = {
            "interaction_type": InteractionType.LLM_CALL,
            "input_data": input_data,
            "output_data": output_data,
            "metadata": metadata,
        }
        if self._parallel_group:
            record_kwargs["parallel_group"] = self._parallel_group

        self.recorder.record_interaction(**record_kwargs)

    def on_llm_error(self, error: Exception, **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._llm_inputs.pop() if self._llm_inputs else {}
        input_data.pop("model", None)
        metadata: dict[str, Any] = {"source": "langgraph"}
        if self._node_stack:
            metadata["langgraph_node"] = self._node_stack[-1].get("name")
        self.recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data=input_data,
            error=str(error),
            metadata=metadata,
        )

    # ── Tool callbacks ───────────────────────────────────────────────────

    def on_tool_start(self, serialized: dict, input_str: str, **kwargs: Any) -> None:  # type: ignore[override]
        tool_name = serialized.get("name") or serialized.get("id") or kwargs.get("name")
        self._tool_inputs.append(
            {
                "function": tool_name,
                "input": _to_jsonable(input_str),
            }
        )

    def on_tool_end(self, output: str, **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._tool_inputs.pop() if self._tool_inputs else {}
        output_data = {"output": _to_jsonable(output)}
        metadata: dict[str, Any] = {"source": "langgraph"}
        if self._node_stack:
            metadata["langgraph_node"] = self._node_stack[-1].get("name")

        record_kwargs: dict[str, Any] = {
            "interaction_type": InteractionType.TOOL_CALL,
            "input_data": input_data,
            "output_data": output_data,
            "metadata": metadata,
        }
        if self._parallel_group:
            record_kwargs["parallel_group"] = self._parallel_group

        self.recorder.record_interaction(**record_kwargs)

    def on_tool_error(self, error: Exception, **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._tool_inputs.pop() if self._tool_inputs else {}
        metadata: dict[str, Any] = {"source": "langgraph"}
        if self._node_stack:
            metadata["langgraph_node"] = self._node_stack[-1].get("name")
        self.recorder.record_interaction(
            interaction_type=InteractionType.TOOL_CALL,
            input_data=input_data,
            error=str(error),
            metadata=metadata,
        )

    # ── Chain callbacks (used by LangGraph for node execution) ───────────

    def on_chain_start(self, serialized: dict, inputs: dict, **kwargs: Any) -> None:  # type: ignore[override]
        node_name = serialized.get("name") or (serialized.get("id") or ["unknown"])[-1]

        # Detect if this is a graph/subgraph node
        is_node = (
            any(
                k in serialized.get("id", [])
                for k in ("RunnableSequence", "RunnableLambda", "StateGraph")
            )
            or "graph" in node_name.lower()
        )

        # Track parallel execution: multiple active nodes = parallel
        if self._active_nodes and is_node:
            if self._parallel_group is None:
                self._parallel_group = str(uuid.uuid4())

        self._active_nodes.add(node_name)

        self._node_stack.append(
            {
                "name": node_name,
                "inputs": _to_jsonable(inputs),
                "is_node": is_node,
            }
        )
        self._chain_inputs.append(
            {
                "serialized": _to_jsonable(serialized),
                "inputs": _to_jsonable(inputs),
            }
        )

        # Track state transition
        if self._last_node and node_name != self._last_node:
            self._state_transitions.append(
                {
                    "from": self._last_node,
                    "to": node_name,
                }
            )

    def on_chain_end(self, outputs: dict, **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._chain_inputs.pop() if self._chain_inputs else {}
        node_info = self._node_stack.pop() if self._node_stack else {}
        node_name = node_info.get("name", "unknown")

        self._active_nodes.discard(node_name)
        self._last_node = node_name

        # Clear parallel group when no more active nodes
        if not self._active_nodes:
            self._parallel_group = None

        output_data = {"outputs": _to_jsonable(outputs)}
        metadata: dict[str, Any] = {
            "source": "langgraph",
            "langgraph_type": "node",
            "langgraph_node": node_name,
        }
        if self._subgraph_depth > 0:
            metadata["subgraph_depth"] = self._subgraph_depth
        if self._state_transitions:
            metadata["state_transitions"] = self._state_transitions[-3:]  # Last 3

        record_kwargs: dict[str, Any] = {
            "interaction_type": InteractionType.OTHER,
            "input_data": input_data,
            "output_data": output_data,
            "metadata": metadata,
        }
        if self._parallel_group:
            record_kwargs["parallel_group"] = self._parallel_group

        self.recorder.record_interaction(**record_kwargs)

    def on_chain_error(self, error: Exception, **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._chain_inputs.pop() if self._chain_inputs else {}
        node_info = self._node_stack.pop() if self._node_stack else {}
        node_name = node_info.get("name", "unknown")

        self._active_nodes.discard(node_name)

        metadata: dict[str, Any] = {
            "source": "langgraph",
            "langgraph_type": "node",
            "langgraph_node": node_name,
        }
        self.recorder.record_interaction(
            interaction_type=InteractionType.OTHER,
            input_data=input_data,
            error=str(error),
            metadata=metadata,
        )

    # ── Agent callbacks ──────────────────────────────────────────────────

    def on_agent_action(self, action: Any, **kwargs: Any) -> None:  # type: ignore[override]
        self.recorder.record_interaction(
            interaction_type=InteractionType.OTHER,
            input_data={"action": _to_jsonable(action)},
            output_data={},
            metadata={"source": "langgraph", "langgraph_type": "agent_action"},
        )

    def on_agent_finish(self, finish: Any, **kwargs: Any) -> None:  # type: ignore[override]
        self.recorder.record_interaction(
            interaction_type=InteractionType.OTHER,
            input_data={},
            output_data={"finish": _to_jsonable(finish)},
            metadata={"source": "langgraph", "langgraph_type": "agent_finish"},
        )

    # ── Retriever callbacks ──────────────────────────────────────────────

    def on_retriever_start(self, serialized: dict, query: str, **kwargs: Any) -> None:  # type: ignore[override]
        self._retriever_inputs.append(
            {
                "serialized": _to_jsonable(serialized),
                "query": _to_jsonable(query),
            }
        )

    def on_retriever_end(self, documents: list[Any], **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._retriever_inputs.pop() if self._retriever_inputs else {}
        output_data = {"documents": _to_jsonable(documents)}
        self.recorder.record_interaction(
            interaction_type=InteractionType.TOOL_CALL,
            input_data=input_data,
            output_data=output_data,
            metadata={"source": "langgraph", "langgraph_type": "retriever"},
        )

    def on_retriever_error(self, error: Exception, **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._retriever_inputs.pop() if self._retriever_inputs else {}
        self.recorder.record_interaction(
            interaction_type=InteractionType.TOOL_CALL,
            input_data=input_data,
            error=str(error),
            metadata={"source": "langgraph", "langgraph_type": "retriever"},
        )

    # ── Utility ──────────────────────────────────────────────────────────

    def get_state_transitions(self) -> list[dict[str, Any]]:
        """Return the recorded state transitions."""
        return list(self._state_transitions)
