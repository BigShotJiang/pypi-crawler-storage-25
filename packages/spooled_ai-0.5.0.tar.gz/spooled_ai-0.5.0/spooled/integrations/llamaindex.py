"""LlamaIndex integration for Spooled.

Provides a callback handler that records events via Spooled.
"""

from __future__ import annotations

import json
import uuid
from typing import Any

import structlog

from spooled.models import InteractionType

logger = structlog.get_logger(__name__)

try:
    from llama_index.core.callbacks import BaseCallbackHandler  # type: ignore

    _LLAMA_IMPORT_ERROR: Exception | None = None
except Exception as e:  # pragma: no cover - optional dependency
    try:
        from llama_index.callbacks import BaseCallbackHandler  # type: ignore

        _LLAMA_IMPORT_ERROR = None
    except Exception as inner:  # pragma: no cover
        BaseCallbackHandler = object  # type: ignore
        _LLAMA_IMPORT_ERROR = inner or e


def _to_jsonable(value: Any) -> Any:
    if value is None:
        return None
    try:
        json.dumps(value)
        return value
    except Exception:
        return str(value)


def _event_type_str(event_type: Any) -> str:
    if hasattr(event_type, "value"):
        return str(event_type.value)
    return str(event_type)


def _map_interaction_type(event_type: Any) -> InteractionType:
    name = _event_type_str(event_type).lower()
    if "llm" in name:
        return InteractionType.LLM_CALL
    if "tool" in name or "function" in name:
        return InteractionType.TOOL_CALL
    return InteractionType.OTHER


class SpooledLlamaIndexCallbackHandler(BaseCallbackHandler):
    """LlamaIndex callback handler for Spooled."""

    def __init__(self, recorder: Any) -> None:
        if _LLAMA_IMPORT_ERROR is not None:
            raise ImportError("LlamaIndex is not installed") from _LLAMA_IMPORT_ERROR

        self.recorder = recorder
        self._events: dict[str, dict[str, Any]] = {}

    def on_event_start(
        self, event_type: Any, payload: dict[str, Any] | None = None, **kwargs: Any
    ) -> str:  # type: ignore[override]
        event_id = kwargs.get("event_id") or str(uuid.uuid4())
        self._events[event_id] = {
            "event_type": _event_type_str(event_type),
            "payload": _to_jsonable(payload),
        }
        return event_id

    def on_event_end(
        self, event_type: Any, payload: dict[str, Any] | None = None, **kwargs: Any
    ) -> None:  # type: ignore[override]
        event_id = kwargs.get("event_id")
        start = self._events.pop(event_id, {}) if event_id else {}

        input_data = {
            "event_type": start.get("event_type") or _event_type_str(event_type),
            "payload": start.get("payload"),
        }
        output_data = {"payload": _to_jsonable(payload)}

        self.recorder.record_interaction(
            interaction_type=_map_interaction_type(event_type),
            input_data=input_data,
            output_data=output_data,
            metadata={"source": "llamaindex", "event_id": event_id},
        )

    def on_event_error(
        self,
        event_type: Any,
        payload: dict[str, Any] | None = None,
        error: Exception | None = None,
        **kwargs: Any,
    ) -> None:  # type: ignore[override]
        event_id = kwargs.get("event_id")
        start = self._events.pop(event_id, {}) if event_id else {}

        input_data = {
            "event_type": start.get("event_type") or _event_type_str(event_type),
            "payload": start.get("payload") or _to_jsonable(payload),
        }

        self.recorder.record_interaction(
            interaction_type=_map_interaction_type(event_type),
            input_data=input_data,
            error=str(error) if error else "Unknown error",
            metadata={"source": "llamaindex", "event_id": event_id},
        )
