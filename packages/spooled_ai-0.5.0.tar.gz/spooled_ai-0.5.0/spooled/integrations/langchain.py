"""LangChain integration for Spooled.

Provides a callback handler that records LLM and tool interactions via Spooled.
"""

from __future__ import annotations

import json
from typing import Any

import structlog

from spooled.models import InteractionType

logger = structlog.get_logger(__name__)

try:
    from langchain.callbacks.base import BaseCallbackHandler  # type: ignore

    _LANGCHAIN_IMPORT_ERROR: Exception | None = None
except Exception as e:  # pragma: no cover - optional dependency
    try:
        from langchain_core.callbacks import BaseCallbackHandler  # type: ignore

        _LANGCHAIN_IMPORT_ERROR = None
    except Exception as inner:  # pragma: no cover
        BaseCallbackHandler = object  # type: ignore
        _LANGCHAIN_IMPORT_ERROR = inner or e


def _to_jsonable(value: Any) -> Any:
    if value is None:
        return None
    try:
        json.dumps(value)
        return value
    except Exception:
        return str(value)


class SpooledLangChainCallbackHandler(BaseCallbackHandler):
    """LangChain callback handler for Spooled.

    Records LLM, tool, chain, agent, and retriever interactions as they flow
    through a LangChain pipeline.  Uses stack-based input tracking so that
    start/end pairs are correctly matched even when calls are nested.
    """

    def __init__(self, recorder: Any) -> None:
        if _LANGCHAIN_IMPORT_ERROR is not None:
            raise ImportError("LangChain is not installed") from _LANGCHAIN_IMPORT_ERROR

        self.recorder = recorder
        self._llm_inputs: list[dict[str, Any]] = []
        self._tool_inputs: list[dict[str, Any]] = []
        self._chain_inputs: list[dict[str, Any]] = []
        self._retriever_inputs: list[dict[str, Any]] = []

    # ── LLM callbacks ────────────────────────────────────────────────────

    def on_llm_start(self, serialized: dict, prompts: list[str], **kwargs: Any) -> None:  # type: ignore[override]
        self._llm_inputs.append(
            {
                "serialized": _to_jsonable(serialized),
                "prompts": _to_jsonable(prompts),
            }
        )

    def on_chat_model_start(self, serialized: dict, messages: list[Any], **kwargs: Any) -> None:  # type: ignore[override]
        self._llm_inputs.append(
            {
                "serialized": _to_jsonable(serialized),
                "messages": _to_jsonable(messages),
            }
        )

    def on_llm_end(self, response: Any, **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._llm_inputs.pop() if self._llm_inputs else {}
        output_data = {"response": _to_jsonable(response)}
        self.recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data=input_data,
            output_data=output_data,
            metadata={"source": "langchain"},
        )

    def on_llm_error(self, error: Exception, **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._llm_inputs.pop() if self._llm_inputs else {}
        self.recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data=input_data,
            error=str(error),
            metadata={"source": "langchain"},
        )

    # ── Tool callbacks ───────────────────────────────────────────────────

    def on_tool_start(self, serialized: dict, input_str: str, **kwargs: Any) -> None:  # type: ignore[override]
        tool_name = serialized.get("name") or serialized.get("id") or kwargs.get("name")
        self._tool_inputs.append(
            {
                "tool": tool_name,
                "input": _to_jsonable(input_str),
            }
        )

    def on_tool_end(self, output: str, **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._tool_inputs.pop() if self._tool_inputs else {}
        output_data = {"output": _to_jsonable(output)}
        self.recorder.record_interaction(
            interaction_type=InteractionType.TOOL_CALL,
            input_data=input_data,
            output_data=output_data,
            metadata={"source": "langchain"},
        )

    def on_tool_error(self, error: Exception, **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._tool_inputs.pop() if self._tool_inputs else {}
        self.recorder.record_interaction(
            interaction_type=InteractionType.TOOL_CALL,
            input_data=input_data,
            error=str(error),
            metadata={"source": "langchain"},
        )

    # ── Chain callbacks ──────────────────────────────────────────────────

    def on_chain_start(self, serialized: dict, inputs: dict, **kwargs: Any) -> None:  # type: ignore[override]
        self._chain_inputs.append(
            {
                "serialized": _to_jsonable(serialized),
                "inputs": _to_jsonable(inputs),
            }
        )

    def on_chain_end(self, outputs: dict, **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._chain_inputs.pop() if self._chain_inputs else {}
        output_data = {"outputs": _to_jsonable(outputs)}
        self.recorder.record_interaction(
            interaction_type=InteractionType.OTHER,
            input_data=input_data,
            output_data=output_data,
            metadata={"source": "langchain", "langchain_type": "chain"},
        )

    def on_chain_error(self, error: Exception, **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._chain_inputs.pop() if self._chain_inputs else {}
        self.recorder.record_interaction(
            interaction_type=InteractionType.OTHER,
            input_data=input_data,
            error=str(error),
            metadata={"source": "langchain", "langchain_type": "chain"},
        )

    # ── Agent callbacks ──────────────────────────────────────────────────

    def on_agent_action(self, action: Any, **kwargs: Any) -> None:  # type: ignore[override]
        self.recorder.record_interaction(
            interaction_type=InteractionType.OTHER,
            input_data={"action": _to_jsonable(action)},
            output_data={},
            metadata={"source": "langchain", "langchain_type": "agent_action"},
        )

    def on_agent_finish(self, finish: Any, **kwargs: Any) -> None:  # type: ignore[override]
        self.recorder.record_interaction(
            interaction_type=InteractionType.OTHER,
            input_data={},
            output_data={"finish": _to_jsonable(finish)},
            metadata={"source": "langchain", "langchain_type": "agent_finish"},
        )

    # ── Retriever callbacks ──────────────────────────────────────────────

    def on_retriever_start(self, serialized: dict, query: str, **kwargs: Any) -> None:  # type: ignore[override]
        self._retriever_inputs.append(
            {
                "serialized": _to_jsonable(serialized),
                "query": _to_jsonable(query),
            }
        )

    def on_retriever_end(self, documents: list[Any], **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._retriever_inputs.pop() if self._retriever_inputs else {}
        output_data = {"documents": _to_jsonable(documents)}
        self.recorder.record_interaction(
            interaction_type=InteractionType.TOOL_CALL,
            input_data=input_data,
            output_data=output_data,
            metadata={"source": "langchain", "langchain_type": "retriever"},
        )

    def on_retriever_error(self, error: Exception, **kwargs: Any) -> None:  # type: ignore[override]
        input_data = self._retriever_inputs.pop() if self._retriever_inputs else {}
        self.recorder.record_interaction(
            interaction_type=InteractionType.TOOL_CALL,
            input_data=input_data,
            error=str(error),
            metadata={"source": "langchain", "langchain_type": "retriever"},
        )
