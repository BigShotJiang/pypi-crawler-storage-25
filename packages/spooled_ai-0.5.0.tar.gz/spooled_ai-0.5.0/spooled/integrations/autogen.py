"""AutoGen integration for Spooled.

Provides a hook to capture AutoGen agent messages via monkey-patching.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import structlog

from spooled.models import InteractionType

logger = structlog.get_logger(__name__)

_original_methods: dict[str, Callable] = {}
_hook_installed = False


def _safe_str(value: Any) -> str:
    try:
        return str(value)
    except Exception:
        return "<unserializable>"


def _agent_name(agent: Any) -> str | None:
    return getattr(agent, "name", None)


def install_autogen_hook(recorder: Any) -> None:
    """Install monkey-patch for AutoGen ConversableAgent send/receive."""
    global _hook_installed

    if _hook_installed:
        logger.warning("AutoGen hook already installed")
        return

    try:
        import autogen  # type: ignore

        conversable = None
        try:
            conversable = autogen.agentchat.ConversableAgent  # type: ignore[attr-defined]
        except Exception:
            conversable = None

        if conversable is None:
            logger.warning("AutoGen ConversableAgent not found, hook not installed")
            return

        if hasattr(conversable, "send"):
            original_send = conversable.send
            _original_methods["send"] = original_send

            def patched_send(
                self: Any, message: Any, recipient: Any, *args: Any, **kwargs: Any
            ) -> Any:
                input_data = {
                    "event": "autogen.send",
                    "from": _agent_name(self),
                    "to": _agent_name(recipient),
                    "message": _safe_str(message),
                }
                try:
                    result = original_send(self, message, recipient, *args, **kwargs)
                    recorder.record_interaction(
                        interaction_type=InteractionType.OTHER,
                        input_data=input_data,
                        output_data={"result": _safe_str(result)},
                        metadata={"source": "autogen"},
                    )
                    return result
                except Exception as e:
                    recorder.record_interaction(
                        interaction_type=InteractionType.OTHER,
                        input_data=input_data,
                        error=str(e),
                        metadata={"source": "autogen"},
                    )
                    raise

            conversable.send = patched_send

        if hasattr(conversable, "receive"):
            original_receive = conversable.receive
            _original_methods["receive"] = original_receive

            def patched_receive(
                self: Any, message: Any, sender: Any, *args: Any, **kwargs: Any
            ) -> Any:
                input_data = {
                    "event": "autogen.receive",
                    "to": _agent_name(self),
                    "from": _agent_name(sender),
                    "message": _safe_str(message),
                }
                try:
                    result = original_receive(self, message, sender, *args, **kwargs)
                    recorder.record_interaction(
                        interaction_type=InteractionType.OTHER,
                        input_data=input_data,
                        output_data={"result": _safe_str(result)},
                        metadata={"source": "autogen"},
                    )
                    return result
                except Exception as e:
                    recorder.record_interaction(
                        interaction_type=InteractionType.OTHER,
                        input_data=input_data,
                        error=str(e),
                        metadata={"source": "autogen"},
                    )
                    raise

            conversable.receive = patched_receive

        _hook_installed = True
        logger.info("AutoGen hook installed", recorder_run_id=getattr(recorder, "run_id", None))

    except ImportError:
        logger.warning("autogen library not found, hook not installed")
    except Exception as e:
        logger.exception("Failed to install AutoGen hook", error=str(e))
        raise


def uninstall_autogen_hook() -> None:
    """Remove the AutoGen monkey-patch."""
    global _hook_installed

    if not _hook_installed:
        return

    try:
        import autogen  # type: ignore

        conversable = None
        try:
            conversable = autogen.agentchat.ConversableAgent  # type: ignore[attr-defined]
        except Exception:
            conversable = None

        if conversable is None:
            _original_methods.clear()
            _hook_installed = False
            return

        if "send" in _original_methods:
            conversable.send = _original_methods["send"]

        if "receive" in _original_methods:
            conversable.receive = _original_methods["receive"]

        _original_methods.clear()
        _hook_installed = False
        logger.info("AutoGen hook uninstalled")

    except Exception as e:
        logger.exception("Failed to uninstall AutoGen hook", error=str(e))
