"""CrewAI integration for Spooled.

Uses CrewAI's step_callback and task_callback interfaces to capture
agent task assignments, tool calls, and delegation between agents.
"""

from __future__ import annotations

from typing import Any

import structlog

from spooled.models import InteractionType

logger = structlog.get_logger(__name__)

# Try importing CrewAI
try:
    import crewai  # type: ignore  # noqa: F401

    _CREWAI_AVAILABLE = True
except ImportError:
    _CREWAI_AVAILABLE = False


def _to_jsonable(value: Any) -> Any:
    """Convert value to JSON-serializable form."""
    if value is None:
        return None
    try:
        import json

        json.dumps(value)
        return value
    except Exception:
        return str(value)


class SpooledCrewAIHandler:
    """CrewAI callback handler for Spooled.

    Designed to work with CrewAI's step_callback and task_callback hooks.
    Captures agent task assignments, tool calls within tasks, and
    delegation between agents.

    Usage:
        from spooled.integrations.crewai import SpooledCrewAIHandler

        handler = SpooledCrewAIHandler(recorder)

        crew = Crew(
            agents=[...],
            tasks=[...],
            step_callback=handler.on_step,
            task_callback=handler.on_task_complete,
        )
    """

    def __init__(self, recorder: Any) -> None:
        self.recorder = recorder
        self._current_agent: str | None = None
        self._current_task: str | None = None
        self._task_stack: list[dict[str, Any]] = []
        self._delegation_chain: list[str] = []

    def on_step(self, step_output: Any) -> None:
        """Called after each agent step (CrewAI step_callback).

        Records tool calls, LLM interactions, and delegation events.

        Args:
            step_output: The step output from CrewAI (AgentAction or similar)
        """
        try:
            # Extract step details
            step_type = type(step_output).__name__
            agent_name = self._current_agent or "unknown"

            # Handle different step output types
            if hasattr(step_output, "tool"):
                # Tool call step
                tool_name = getattr(step_output, "tool", "unknown")
                tool_input = getattr(step_output, "tool_input", {})
                tool_output = getattr(step_output, "result", None) or getattr(
                    step_output, "output", None
                )

                metadata: dict[str, Any] = {
                    "source": "crewai",
                    "crewai_type": "tool_call",
                    "agent": agent_name,
                }
                if self._current_task:
                    metadata["task"] = self._current_task

                self.recorder.record_interaction(
                    interaction_type=InteractionType.TOOL_CALL,
                    input_data={
                        "function": str(tool_name),
                        "arguments": (
                            _to_jsonable(tool_input)
                            if isinstance(tool_input, dict)
                            else {"input": _to_jsonable(tool_input)}
                        ),
                    },
                    output_data={"output": _to_jsonable(tool_output)} if tool_output else None,
                    metadata=metadata,
                )

            elif hasattr(step_output, "text") or hasattr(step_output, "output"):
                # LLM response step
                output_text = getattr(step_output, "text", None) or getattr(
                    step_output, "output", None
                )

                metadata = {
                    "source": "crewai",
                    "crewai_type": "llm_response",
                    "agent": agent_name,
                }
                if self._current_task:
                    metadata["task"] = self._current_task

                self.recorder.record_interaction(
                    interaction_type=InteractionType.LLM_CALL,
                    input_data={"agent": agent_name},
                    output_data={"response": _to_jsonable(output_text)},
                    metadata=metadata,
                )

            else:
                # Generic step
                metadata = {
                    "source": "crewai",
                    "crewai_type": "step",
                    "step_type": step_type,
                    "agent": agent_name,
                }
                self.recorder.record_interaction(
                    interaction_type=InteractionType.OTHER,
                    input_data={"step_type": step_type},
                    output_data={"output": _to_jsonable(step_output)},
                    metadata=metadata,
                )

            # Detect delegation (agent change)
            if hasattr(step_output, "agent") and step_output.agent:
                new_agent = str(getattr(step_output.agent, "role", step_output.agent))
                if new_agent != self._current_agent:
                    if self._current_agent:
                        self._delegation_chain.append(f"{self._current_agent} → {new_agent}")
                        self.recorder.record_interaction(
                            interaction_type=InteractionType.OTHER,
                            input_data={
                                "type": "delegation",
                                "from_agent": self._current_agent,
                                "to_agent": new_agent,
                            },
                            output_data={},
                            metadata={
                                "source": "crewai",
                                "crewai_type": "delegation",
                            },
                        )
                    self._current_agent = new_agent

        except Exception as e:
            logger.debug("Error recording CrewAI step", error=str(e))

    def on_task_complete(self, task_output: Any) -> None:
        """Called when a task completes (CrewAI task_callback).

        Args:
            task_output: The task output from CrewAI
        """
        try:
            task_desc = "unknown"
            agent_name = self._current_agent or "unknown"

            if hasattr(task_output, "description"):
                task_desc = str(task_output.description)[:200]
            elif hasattr(task_output, "task"):
                task_desc = str(getattr(task_output.task, "description", "unknown"))[:200]

            output_text = None
            if hasattr(task_output, "raw"):
                output_text = str(task_output.raw)[:500]
            elif hasattr(task_output, "output"):
                output_text = str(task_output.output)[:500]

            self.recorder.record_interaction(
                interaction_type=InteractionType.OTHER,
                input_data={
                    "type": "task_complete",
                    "task": task_desc,
                    "agent": agent_name,
                },
                output_data={"output": _to_jsonable(output_text)} if output_text else None,
                metadata={
                    "source": "crewai",
                    "crewai_type": "task_complete",
                    "agent": agent_name,
                },
            )

            # Update task tracking
            self._current_task = None

        except Exception as e:
            logger.debug("Error recording CrewAI task completion", error=str(e))

    def set_current_agent(self, agent_name: str) -> None:
        """Set the current agent name for attribution."""
        self._current_agent = agent_name

    def set_current_task(self, task_desc: str) -> None:
        """Set the current task description for context."""
        self._current_task = task_desc

    def get_delegation_chain(self) -> list[str]:
        """Return the recorded delegation chain."""
        return list(self._delegation_chain)
