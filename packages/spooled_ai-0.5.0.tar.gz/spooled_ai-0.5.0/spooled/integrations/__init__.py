"""Framework integrations for Spooled."""

from __future__ import annotations

from spooled.integrations.autogen import install_autogen_hook, uninstall_autogen_hook
from spooled.integrations.crewai import SpooledCrewAIHandler
from spooled.integrations.langchain import SpooledLangChainCallbackHandler
from spooled.integrations.langgraph import SpooledLangGraphCallbackHandler
from spooled.integrations.llamaindex import SpooledLlamaIndexCallbackHandler

__all__ = [
    "SpooledLangChainCallbackHandler",
    "SpooledLlamaIndexCallbackHandler",
    "SpooledCrewAIHandler",
    "SpooledLangGraphCallbackHandler",
    "install_autogen_hook",
    "uninstall_autogen_hook",
]
