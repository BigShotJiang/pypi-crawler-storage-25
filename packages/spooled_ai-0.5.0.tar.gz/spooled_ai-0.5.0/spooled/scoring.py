"""Spooled Score: composite behavioral stability metric (0-100).

Composes fingerprint similarity, signal health, metric stability, and
trend consistency into a single integer score per intent, plus an
agent-level aggregate.
"""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

# ---------------------------------------------------------------------------
# Weight configuration
# ---------------------------------------------------------------------------
WEIGHTS = {
    "structural": 0.40,
    "signal": 0.25,
    "metric": 0.20,
    "trend": 0.15,
}

# Signal severity -> penalty points
SIGNAL_PENALTIES: dict[str, int] = {
    "high": 25,
    "medium": 12,
    "low": 5,
    "info": 0,
}

# Grade thresholds (checked in descending order)
GRADE_THRESHOLDS = [
    (90, "A"),
    (75, "B"),
    (60, "C"),
    (40, "D"),
    (0, "F"),
]

# Metric delta penalty: 1 point per METRIC_PENALTY_STEP% over METRIC_DELTA_THRESHOLD%
METRIC_DELTA_THRESHOLD = 10.0
METRIC_PENALTY_STEP = 5.0

# Minimum trend points before using trend data (below this, default to 100)
MIN_TREND_POINTS = 3
# Maximum trend points to consider (most recent)
MAX_TREND_WINDOW = 10

# Confidence thresholds
CONFIDENCE_HIGH_THRESHOLD = 5
CONFIDENCE_MEDIUM_THRESHOLD = 2

# Hard cap on score when a blocking policy violation is detected. The verdict
# says FAIL — the grade should match (D, not A).
POLICY_FAIL_CAP = 59


def _score_to_grade(score: int) -> str:
    """Map a 0-100 score to a letter grade."""
    for threshold, grade in GRADE_THRESHOLDS:
        if score >= threshold:
            return grade
    return "F"


def _compute_structural(
    fingerprint_status: str,
    similarity_score: float | None,
) -> int | None:
    """Compute structural similarity component (0-100 or None for cold start)."""
    status = fingerprint_status.lower()
    if status in ("match", "accepted_variant"):
        return 100
    if status == "variant" and similarity_score is not None:
        return max(0, min(100, round(similarity_score * 100)))
    if status in ("new", "not_compared"):
        return 0
    # no_baseline -> cold start
    return None


def _compute_signal_health(signals: dict[str, Any]) -> int:
    """Compute signal health component (0-100). Higher is healthier."""
    penalty = 0
    for _key, value in signals.items():
        if not isinstance(value, dict):
            continue
        if not value.get("detected", False):
            continue
        severity = value.get("severity", "low")
        penalty += SIGNAL_PENALTIES.get(severity, 0)
    return max(0, 100 - penalty)


def _compute_metric_stability(metric_deltas: dict[str, Any]) -> int:
    """Compute metric stability component (0-100). Higher is more stable."""
    stability = 100.0
    for _metric_name, delta in metric_deltas.items():
        if not isinstance(delta, dict):
            continue
        pct = abs(delta.get("delta_pct", 0.0))
        if pct > METRIC_DELTA_THRESHOLD:
            stability -= (pct - METRIC_DELTA_THRESHOLD) / METRIC_PENALTY_STEP
    return max(0, min(100, round(stability)))


def _compute_trend_consistency(similarity_trend: list[Any]) -> int:
    """Compute trend consistency component (0-100).

    Uses average of last MAX_TREND_WINDOW similarity scores.
    Defaults to 100 if fewer than MIN_TREND_POINTS available.
    """
    if len(similarity_trend) < MIN_TREND_POINTS:
        return 100

    recent = similarity_trend[-MAX_TREND_WINDOW:]
    scores = []
    for point in recent:
        if isinstance(point, dict):
            s = point.get("similarity_score")
        else:
            s = getattr(point, "similarity_score", None)
        if s is not None:
            scores.append(s)

    if not scores:
        return 100

    avg = sum(scores) / len(scores)
    return max(0, min(100, round(avg * 100)))


def compute_spooled_score(
    fingerprint_status: str,
    similarity_score: float | None,
    signals: dict[str, Any],
    metric_deltas: dict[str, Any],
    similarity_trend: list[Any],
    policy_failed: bool = False,
    tools_removed: int = 0,
) -> dict[str, Any]:
    """Compute per-intent Spooled Score.

    Args:
        fingerprint_status: Match status from comparison
        similarity_score: Variant similarity (0.0-1.0)
        signals: Detected signals dict
        metric_deltas: Metric delta dict
        similarity_trend: Historical comparison trend
        policy_failed: True if any policy violation should block — caps score at POLICY_FAIL_CAP
        tools_removed: Number of tools dropped vs baseline — applies per-tool penalty

    Returns dict with: score (int 0-100), grade (str), confidence (str),
    components (dict with structural, signal, metric, trend).

    A policy failure caps the score at 59 (D) so the grade reflects the FAIL verdict.
    Each removed tool deducts 5 points.
    """
    structural = _compute_structural(fingerprint_status, similarity_score)
    signal_health = _compute_signal_health(signals)
    metric_stability = _compute_metric_stability(metric_deltas)
    trend_consistency = _compute_trend_consistency(similarity_trend)

    # Compute weighted score
    if structural is None:
        # Cold start: redistribute structural weight across remaining components
        remaining_weight = WEIGHTS["signal"] + WEIGHTS["metric"] + WEIGHTS["trend"]
        score = round(
            (signal_health * WEIGHTS["signal"] / remaining_weight)
            + (metric_stability * WEIGHTS["metric"] / remaining_weight)
            + (trend_consistency * WEIGHTS["trend"] / remaining_weight)
        )
        confidence = "low"
    else:
        score = round(
            structural * WEIGHTS["structural"]
            + signal_health * WEIGHTS["signal"]
            + metric_stability * WEIGHTS["metric"]
            + trend_consistency * WEIGHTS["trend"]
        )
        # Confidence based on trend history depth
        if len(similarity_trend) >= CONFIDENCE_HIGH_THRESHOLD:
            confidence = "high"
        elif len(similarity_trend) >= CONFIDENCE_MEDIUM_THRESHOLD:
            confidence = "medium"
        else:
            confidence = "low"

    # Per-tool penalty for dropped tools (5 points each)
    if tools_removed > 0:
        score -= tools_removed * 5

    # Hard cap when a policy failure should block — verdict says FAIL, grade
    # must match. Without this cap, dropping 3 critical tools could still show
    # as A (96/100) which is misleading.
    if policy_failed:
        score = min(score, POLICY_FAIL_CAP)

    score = max(0, min(100, score))

    return {
        "score": score,
        "grade": _score_to_grade(score),
        "confidence": confidence,
        "components": {
            "structural": structural,
            "signal": signal_health,
            "metric": metric_stability,
            "trend": trend_consistency,
        },
    }


def compute_agent_spooled_score(
    intent_scores: list[dict[str, Any]],
) -> dict[str, Any]:
    """Compute agent-level aggregate Spooled Score.

    Weighted average of per-intent scores, weighted by run_count
    (more-observed intents count more).
    """
    if not intent_scores:
        return {
            "score": None,
            "grade": "-",
            "confidence": "none",
            "intent_count": 0,
        }

    valid = [s for s in intent_scores if s.get("score") is not None]
    if not valid:
        return {
            "score": None,
            "grade": "-",
            "confidence": "none",
            "intent_count": len(intent_scores),
        }

    total_weight = 0
    weighted_sum = 0
    confidences = []
    for s in valid:
        weight = max(1, s.get("run_count", 1))
        weighted_sum += s["score"] * weight
        total_weight += weight
        confidences.append(s.get("confidence", "low"))

    agent_score = max(0, min(100, round(weighted_sum / total_weight)))

    # Agent confidence = lowest per-intent confidence
    if "low" in confidences:
        agent_confidence = "low"
    elif "medium" in confidences:
        agent_confidence = "medium"
    else:
        agent_confidence = "high"

    return {
        "score": agent_score,
        "grade": _score_to_grade(agent_score),
        "confidence": agent_confidence,
        "intent_count": len(valid),
    }


def format_badge_url(score: int, grade: str) -> str:
    """Return a shields.io badge URL for the given score."""
    if score >= 90:
        color = "brightgreen"
    elif score >= 75:
        color = "green"
    elif score >= 60:
        color = "yellow"
    elif score >= 40:
        color = "orange"
    else:
        color = "red"

    label = quote("Spooled Score")
    message = quote(f"{score} ({grade})")
    return f"https://img.shields.io/badge/{label}-{message}-{color}"


def format_badge_markdown(score: int, grade: str) -> str:
    """Return a markdown badge snippet for the given score."""
    url = format_badge_url(score, grade)
    return f"![Spooled Score]({url})"
