"""IO-schema-based tool signatures for rename-resilient fingerprinting.

Tool signatures capture the structural shape of a tool call (argument keys/types
and output keys/types) independent of the tool's name. This allows detecting
that a renamed tool (e.g. check_rates → query_rates) is functionally identical.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

from spooled.models import Interaction, InteractionType


def _get_type_name(value: Any) -> str:
    """Return a stable type name for a value."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "bool"
    if isinstance(value, int):
        return "int"
    if isinstance(value, float):
        return "float"
    if isinstance(value, str):
        return "str"
    if isinstance(value, list):
        return "list"
    if isinstance(value, dict):
        return "dict"
    return "other"


def extract_tool_signature(
    interaction: Interaction | dict[str, Any],
) -> dict[str, Any] | None:
    """Extract structural IO signature from a TOOL_CALL interaction.

    Returns dict with: name, arg_keys, arg_types, output_keys, output_types, structural_id.
    Returns None if the interaction is not a TOOL_CALL.

    Args:
        interaction: An Interaction instance or dict representing one.

    Returns:
        Signature dict or None if not a TOOL_CALL.
    """
    if isinstance(interaction, Interaction):
        itype = interaction.interaction_type
        if isinstance(itype, str):
            itype_val = itype
        else:
            itype_val = itype.value
        inp = interaction.input or {}
        out = interaction.output or {}
    else:
        itype_val = interaction.get("interaction_type", "")
        if hasattr(itype_val, "value"):
            itype_val = itype_val.value
        inp = interaction.get("input") or {}
        out = interaction.get("output") or {}

    if itype_val != InteractionType.TOOL_CALL.value:
        return None

    # Extract tool name
    name = inp.get("function") or inp.get("tool_name") or inp.get("tool") or "unknown"

    # Extract argument keys and types
    args = inp.get("arguments") or inp.get("args") or {}
    if isinstance(args, dict):
        arg_keys = sorted(args.keys())
        arg_types = {k: _get_type_name(v) for k, v in args.items()}
    else:
        arg_keys = []
        arg_types = {}

    # Extract output keys and types (populated by enrich_tool_result)
    output_keys = sorted(out.get("output_keys", []))
    output_types = out.get("output_types", {})

    # Compute structural_id: hash of IO schema only (name-independent)
    structural_data = {
        "arg_keys": arg_keys,
        "arg_types": {k: arg_types[k] for k in arg_keys},
        "output_keys": output_keys,
        "output_types": {k: output_types[k] for k in output_keys} if output_types else {},
    }
    structural_json = json.dumps(structural_data, sort_keys=True, ensure_ascii=False)
    structural_id = hashlib.sha256(structural_json.encode("utf-8")).hexdigest()[:16]

    return {
        "name": name,
        "arg_keys": arg_keys,
        "arg_types": arg_types,
        "output_keys": output_keys,
        "output_types": output_types,
        "structural_id": structural_id,
    }


def signature_similarity(sig_a: dict[str, Any], sig_b: dict[str, Any]) -> float:
    """Jaccard similarity of IO schemas (arg_keys + output_keys overlap).

    Args:
        sig_a: First tool signature dict (from extract_tool_signature).
        sig_b: Second tool signature dict.

    Returns:
        Similarity score in [0.0, 1.0]. 1.0 = identical IO schema.
    """
    keys_a = set(sig_a.get("arg_keys", [])) | set(sig_a.get("output_keys", []))
    keys_b = set(sig_b.get("arg_keys", [])) | set(sig_b.get("output_keys", []))

    if not keys_a and not keys_b:
        return 1.0

    union = keys_a | keys_b
    if not union:
        return 1.0

    intersection = keys_a & keys_b
    return len(intersection) / len(union)
