"""Audit bundle builder for attestation.

Assembles a self-contained, independently verifiable zip of evidence for a
single agent run: raw trace, hash chain verification, behavioral fingerprint,
provenance metadata, baseline comparison, and policy evaluation results.

Each file in the bundle has a SHA-256 checksum recorded in manifest.json.
"""

from __future__ import annotations

import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


def _to_json_bytes(data: Any) -> bytes:
    """Serialize to indented, sorted JSON bytes."""
    return json.dumps(data, indent=2, sort_keys=True, default=str, ensure_ascii=False).encode(
        "utf-8"
    )


def build_audit_bundle(
    trace_file: Path,
    out_path: Path,
    baseline_path: Path | None = None,
    policy_path: Path | None = None,
    attestation_receipt: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build an audit bundle zip from a trace file.

    The bundle (a zip) contains:
    - trace.jsonl         raw trace data (copy)
    - verification.json   hash chain verification result
    - fingerprint.json    behavioral fingerprint + hash
    - provenance.json     git hash/branch, model version, env fingerprint
    - baseline_diff.json  intent comparison against baseline (if --baseline provided)
    - policy.json         policy evaluation results (if policy file found)
    - attestation.json    signed attestation receipt (if provided)
    - manifest.json       index of all files with SHA-256 checksums

    Args:
        trace_file: Path to the source trace JSONL file
        out_path: Destination path for the zip file
        baseline_path: Optional path to a BaselineSummary JSON for comparison
        policy_path: Optional path to a policy YAML (auto-discovers if None)
        attestation_receipt: Optional signed attestation receipt dict

    Returns:
        Dict with bundle metadata: path, run_id, agent_id, chain_valid,
        fingerprint_hash, files list, manifest dict
    """
    from cli.commands.verify import verify_hash_chain
    from spooled.fingerprint import BehavioralFingerprint, hash_fingerprint
    from spooled.storage import load_trace_from_jsonl
    from spooled.utils import get_code_reference

    # Load trace
    trace_data = load_trace_from_jsonl(trace_file)
    run_id = trace_data.get("trace", {}).get("run_id", "unknown")
    agent_id = trace_data.get("trace", {}).get("agent_id", "unknown")

    # 1. Hash chain verification
    verification = verify_hash_chain(trace_file, verbose=True)

    # 2. Behavioral fingerprint
    fp = BehavioralFingerprint(trace_data)
    fp_data = fp.generate()
    fp_hash = hash_fingerprint(fp_data)
    fingerprint_bundle = {
        "fingerprint_hash": fp_hash,
        "fingerprint_hash_short": fp_hash[:16],
        "fingerprint": fp_data,
    }

    # 3. Provenance metadata
    code_ref = get_code_reference()
    provenance = {
        **code_ref,
        "run_id": run_id,
        "agent_id": agent_id,
        "trace_file": trace_file.name,
        "captured_at": datetime.now(timezone.utc).isoformat(),
    }

    # 4. Baseline comparison (optional)
    baseline_bundle: dict[str, Any] | None = None
    if baseline_path and baseline_path.exists():
        baseline_bundle = _build_baseline_comparison(trace_data, fp_data, fp_hash, baseline_path)

    # 5. Policy evaluation (optional — auto-discovers policy file if not specified)
    policy_bundle: dict[str, Any] | None = None
    resolved_policy = _resolve_policy_path(policy_path)
    if resolved_policy:
        policy_bundle = _run_policy_evaluation(trace_data, resolved_policy)

    # 6. Assemble file map
    files: dict[str, bytes] = {}
    files["trace.jsonl"] = trace_file.read_bytes()
    files["verification.json"] = _to_json_bytes(verification)
    files["fingerprint.json"] = _to_json_bytes(fingerprint_bundle)
    files["provenance.json"] = _to_json_bytes(provenance)
    if baseline_bundle is not None:
        files["baseline_diff.json"] = _to_json_bytes(baseline_bundle)
    if policy_bundle is not None:
        files["policy.json"] = _to_json_bytes(policy_bundle)
    if attestation_receipt is not None:
        files["attestation.json"] = _to_json_bytes(attestation_receipt)

    # 7. Manifest with per-file checksums
    manifest: dict[str, Any] = {
        "bundle_version": "1",
        "run_id": run_id,
        "agent_id": agent_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "chain_valid": verification["valid"],
        "fingerprint_hash": fp_hash[:16],
        "files": {name: hashlib.sha256(content).hexdigest() for name, content in files.items()},
    }
    if attestation_receipt is not None:
        manifest["attestation_id"] = attestation_receipt.get("attestation_id")
    files["manifest.json"] = _to_json_bytes(manifest)

    # 8. Write zip
    out_path.parent.mkdir(parents=True, exist_ok=True)
    bundle_dir = f"audit-{run_id[:8]}"
    with zipfile.ZipFile(out_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for name, content in files.items():
            zf.writestr(f"{bundle_dir}/{name}", content)

    logger.info(
        "Audit bundle created",
        path=str(out_path),
        run_id=run_id,
        chain_valid=verification["valid"],
        files=list(files.keys()),
    )

    return {
        "path": str(out_path),
        "run_id": run_id,
        "agent_id": agent_id,
        "chain_valid": verification["valid"],
        "fingerprint_hash": fp_hash[:16],
        "files": list(files.keys()),
        "manifest": manifest,
    }


def _build_baseline_comparison(
    trace_data: dict[str, Any],
    fp_data: dict[str, Any],
    fp_hash: str,
    baseline_path: Path,
) -> dict[str, Any]:
    """Compare trace fingerprint against a baseline summary and return comparison data."""
    try:
        with open(baseline_path) as f:
            raw = json.load(f)

        if not (raw.get("version") and "intents" in raw):
            return {"status": "unsupported_format", "baseline_path": str(baseline_path)}

        from spooled.models import BaselineSummary

        summary = BaselineSummary(**raw)

        # Find matching intent: exact hash match or accepted_fingerprints membership
        matched_id: str | None = None
        matched_intent = None
        for iid, intent_summary in summary.intents.items():
            accepted = intent_summary.accepted_fingerprints
            if (
                iid == fp_hash
                or iid == fp_hash[:16]
                or fp_hash in accepted
                or fp_hash[:16] in accepted
            ):
                matched_id = iid
                matched_intent = intent_summary
                break

        # Extract current run metrics
        interactions = trace_data.get("interactions", [])
        current_tokens = sum(
            (i.get("output") or {}).get("usage", {}).get("total_tokens", 0)
            for i in interactions
            if i.get("interaction_type") == "LLM_CALL"
        )
        current_latency_ms = sum(
            float(
                (i.get("metadata") or {}).get("latency_ms")
                or (i.get("metadata") or {}).get("duration_ms")
                or 0
            )
            for i in interactions
        )

        if matched_intent is None:
            return {
                "status": "no_match",
                "fingerprint_hash": fp_hash[:16],
                "available_intent_count": len(summary.intents),
                "message": "Trace fingerprint not found in baseline — new behavior pattern",
            }

        return {
            "status": "matched",
            "intent_id": matched_id,
            "baseline": {
                "avg_latency_ms": matched_intent.avg_latency,
                "avg_tokens": matched_intent.avg_tokens,
                "error_rate": matched_intent.error_rate,
                "run_count": matched_intent.run_count,
                "latency_bounds": matched_intent.latency_bounds,
                "contributing_run_ids": matched_intent.contributing_run_ids,
            },
            "current": {
                "total_latency_ms": current_latency_ms,
                "total_tokens": current_tokens,
            },
        }

    except Exception as e:
        return {"status": "error", "error": str(e), "baseline_path": str(baseline_path)}


def _resolve_policy_path(policy_path: Path | None) -> Path | None:
    """Find policy file: explicit path → .spooled/policy.yml → spooled-policy.yml."""
    if policy_path and policy_path.exists():
        return policy_path
    for candidate in [Path(".spooled/policy.yml"), Path("spooled-policy.yml")]:
        if candidate.exists():
            return candidate
    return None


def _run_policy_evaluation(
    trace_data: dict[str, Any],
    policy_file: Path,
) -> dict[str, Any]:
    """Run policy engine against the trace and return structured results."""
    try:
        from spooled.policy import PolicyEngine
        from spooled.signals import SignalDetector

        detector = SignalDetector(trace_data)
        signals = detector.detect_signals()

        engine = PolicyEngine(str(policy_file))
        result = engine.evaluate(signals, diff_result=None)

        return {
            "policy_file": str(policy_file),
            "should_block": result.get("should_block", False),
            "violations": result.get("violations", []),
            "warnings": result.get("warnings", []),
            "rules_evaluated": result.get("rules_evaluated", 0),
        }
    except Exception as e:
        return {"status": "error", "error": str(e), "policy_file": str(policy_file)}
