"""Context variable infrastructure for recorder propagation.

Uses contextvars for async-safe, nestable recorder tracking.
Decorators and wrappers resolve the active recorder from here.
"""

from __future__ import annotations

import contextvars
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from spooled.recorder import Recorder

_current_recorder: contextvars.ContextVar[Recorder | None] = contextvars.ContextVar(
    "spooled_current_recorder", default=None
)


def get_current_recorder() -> Recorder | None:
    """Return the context-local recorder, or None."""
    return _current_recorder.get()


def set_current_recorder(recorder: Recorder | None) -> contextvars.Token:
    """Set the context-local recorder. Returns a token for reset."""
    return _current_recorder.set(recorder)
