"""Policy engine for AI CI gating.

This module provides policy evaluation to gate merges based on behavioral changes.
Policies are defined in YAML and can be enabled/disabled globally.  Per-agent
policy profiles are also supported: when a ``profiles`` dict is present in the
YAML, each key maps an agent ID to its own set of ``block_merges`` and ``rules``
overrides.  A special ``default`` profile serves as the fallback for agents that
are not explicitly listed.  If no ``profiles`` section exists, the top-level
rules apply uniformly to every agent.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import structlog
import yaml

logger = structlog.get_logger(__name__)


class PolicyRule:
    """Represents a single policy rule."""

    def __init__(self, rule_config: dict[str, Any]) -> None:
        """Initialize policy rule from configuration.

        Args:
            rule_config: Dictionary with rule configuration
        """
        self.name = rule_config.get("name", "unnamed_rule")
        self.fail_if = rule_config.get("fail_if", {})
        self.warn_if = rule_config.get("warn_if", {})
        self.severity = rule_config.get("severity", "medium")
        self.description = rule_config.get("description", "")

    def evaluate(
        self,
        signals: dict[str, Any],
        diff_result: dict[str, Any] | None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Evaluate this rule against signals and diff.

        Args:
            signals: Detected signals from SignalDetector
            diff_result: Structural diff result if available
            context: Optional runtime context (e.g. fingerprint_status, similarity_score)

        Returns:
            Dictionary with evaluation result
        """
        violations = []
        warnings = []

        # Evaluate fail_if conditions
        if self.fail_if:
            violations.extend(
                self._evaluate_conditions(self.fail_if, signals, diff_result, "fail", context)
            )

        # Evaluate warn_if conditions
        if self.warn_if:
            warnings.extend(
                self._evaluate_conditions(self.warn_if, signals, diff_result, "warn", context)
            )

        return {
            "rule_name": self.name,
            "description": self.description,
            "severity": self.severity,
            "violations": violations,
            "warnings": warnings,
            "passed": len(violations) == 0,
        }

    def _evaluate_conditions(
        self,
        conditions: dict[str, Any],
        signals: dict[str, Any],
        diff_result: dict[str, Any] | None,
        condition_type: str,
        context: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Evaluate a set of conditions.

        Args:
            conditions: Dictionary of conditions to evaluate
            signals: Detected signals
            diff_result: Structural diff result
            condition_type: "fail" or "warn"

        Returns:
            List of violations/warnings
        """
        results = []

        # Check for new side effects
        if conditions.get("new_side_effects"):
            if signals.get("new_side_effects", {}).get("detected"):
                results.append(
                    {
                        "type": "new_side_effects",
                        "message": signals["new_side_effects"].get(
                            "message", "New side effects detected"
                        ),
                        "details": signals["new_side_effects"].get("details", {}),
                    }
                )

        # Check for latency spikes
        if conditions.get("latency_spike"):
            threshold = conditions["latency_spike"].get("threshold_percent", 50.0)
            if signals.get("latency_spikes", {}).get("detected"):
                spike_details = signals["latency_spikes"].get("details", {})
                increase = spike_details.get("increase_percent", 0)
                if increase >= threshold:
                    results.append(
                        {
                            "type": "latency_spike",
                            "message": signals["latency_spikes"].get(
                                "message", "Latency spike detected"
                            ),
                            "details": spike_details,
                        }
                    )

        # Check for retry explosions
        if conditions.get("retry_explosion"):
            threshold = conditions["retry_explosion"].get("threshold", 3)
            if signals.get("retry_explosions", {}).get("detected"):
                retry_details = signals["retry_explosions"].get("details", {})
                max_retries = retry_details.get("max_retries", 0)
                if max_retries >= threshold:
                    results.append(
                        {
                            "type": "retry_explosion",
                            "message": signals["retry_explosions"].get(
                                "message", "Retry explosion detected"
                            ),
                            "details": retry_details,
                        }
                    )

        # Check for error increases
        if conditions.get("error_increase"):
            threshold = conditions["error_increase"].get("threshold", 1)
            if signals.get("error_increases", {}).get("detected"):
                error_details = signals["error_increases"].get("details", {})
                increase = error_details.get("increase", 0)
                if increase >= threshold:
                    results.append(
                        {
                            "type": "error_increase",
                            "message": signals["error_increases"].get(
                                "message", "Error increase detected"
                            ),
                            "details": error_details,
                        }
                    )

        # Check for new tools
        if conditions.get("new_tools"):
            found_new_tools = False
            # Check signals (from ci compare path)
            if signals.get("new_side_effects", {}).get("detected"):
                new_tools = signals["new_side_effects"].get("new_tools", [])
                if new_tools:
                    found_new_tools = True
                    results.append(
                        {
                            "type": "new_tools",
                            "message": f"New tools detected: {', '.join(new_tools)}",
                            "details": {"new_tools": new_tools},
                        }
                    )
            # Fallback: check diff_result (from ci report path)
            if not found_new_tools and diff_result:
                structural_diff = diff_result.get("structural_diff", {})
                tool_changes = [
                    d
                    for d in structural_diff.get("differences", [])
                    if d.get("type") == "tool_usage_change"
                ]
                for change in tool_changes:
                    new_tools = change.get("new_tools", [])
                    if new_tools:
                        results.append(
                            {
                                "type": "new_tools",
                                "message": f"New tools detected: {', '.join(new_tools)}",
                                "details": {"new_tools": new_tools},
                            }
                        )

        # Check for tool usage changes
        if conditions.get("tool_usage_change"):
            threshold = conditions["tool_usage_change"].get("threshold_percent", 50.0)
            if signals.get("tool_usage_changes", {}).get("detected"):
                change_details = signals["tool_usage_changes"].get("details", {})
                change_percent = change_details.get("change_percent", 0)
                if change_percent >= threshold:
                    results.append(
                        {
                            "type": "tool_usage_change",
                            "message": signals["tool_usage_changes"].get(
                                "message", "Tool usage changed"
                            ),
                            "details": change_details,
                        }
                    )

        # Check for token usage spikes
        if conditions.get("token_usage_spike"):
            threshold = conditions["token_usage_spike"].get("threshold_percent", 50.0)
            if signals.get("token_usage_spike", {}).get("detected"):
                spike_details = signals["token_usage_spike"].get("details", {})
                increase = spike_details.get("increase_percent", 0)
                if increase >= threshold:
                    results.append(
                        {
                            "type": "token_usage_spike",
                            "message": signals["token_usage_spike"].get(
                                "message", "Token usage spike detected"
                            ),
                            "details": spike_details,
                        }
                    )

        # Check for component latency drift
        if conditions.get("component_latency_drift"):
            threshold = conditions["component_latency_drift"].get("threshold_percent", 100.0)
            if signals.get("component_latency_drift", {}).get("detected"):
                drift_details = signals["component_latency_drift"].get("details", {})
                drift_percent = drift_details.get("threshold_percent", 0)
                if drift_percent >= threshold:
                    results.append(
                        {
                            "type": "component_latency_drift",
                            "message": signals["component_latency_drift"].get(
                                "message", "Component latency drift detected"
                            ),
                            "details": drift_details,
                        }
                    )

        # Check for content filter rate change
        if conditions.get("content_filter_rate_change"):
            threshold = conditions["content_filter_rate_change"].get("threshold", 0.1)
            if signals.get("content_filter_rate_change", {}).get("detected"):
                filter_details = signals["content_filter_rate_change"].get("details", {})
                change = filter_details.get("filter_rate_change", 0)
                if change >= threshold:
                    results.append(
                        {
                            "type": "content_filter_rate_change",
                            "message": signals["content_filter_rate_change"].get(
                                "message", "Content filter rate change detected"
                            ),
                            "details": filter_details,
                        }
                    )

        # Check for tool overuse
        if conditions.get("tool_overuse"):
            threshold = conditions["tool_overuse"].get("threshold_percent", 50.0)
            if signals.get("tool_overuse", {}).get("detected"):
                overuse_details = signals["tool_overuse"].get("details", {})
                increase_ratio = overuse_details.get("increase_ratio", 0)
                if increase_ratio * 100 >= threshold:
                    results.append(
                        {
                            "type": "tool_overuse",
                            "message": signals["tool_overuse"].get(
                                "message", "Tool overuse detected"
                            ),
                            "details": overuse_details,
                        }
                    )

        # Check for retrieval regression
        if conditions.get("retrieval_regression"):
            threshold = conditions["retrieval_regression"].get("threshold", 0.2)
            if signals.get("retrieval_regression", {}).get("detected"):
                regression_details = signals["retrieval_regression"].get("details", {})
                quality_decrease = regression_details.get("quality_decrease", 0)
                if quality_decrease >= threshold:
                    results.append(
                        {
                            "type": "retrieval_regression",
                            "message": signals["retrieval_regression"].get(
                                "message", "Retrieval regression detected"
                            ),
                            "details": regression_details,
                        }
                    )

        # Check for required tools (compliance guardrails)
        if conditions.get("required_tools"):
            config = conditions["required_tools"]
            required = config.get("tools", []) if isinstance(config, dict) else []
            custom_message = config.get("message", "") if isinstance(config, dict) else ""

            # Extract tool names from context fingerprint or signals
            trace_tools: set = set()
            ctx = context or {}

            # From fingerprint tool_graph (CI compare path)
            fp = ctx.get("fingerprint", {})
            if isinstance(fp, dict):
                tool_graph = fp.get("tool_graph", {})
                if isinstance(tool_graph, dict):
                    trace_tools.update(tool_graph.get("unique_tools", []))
                    for t in tool_graph.get("sequence", []):
                        trace_tools.add(t)

            # From diff_result tool changes (CI report path)
            if diff_result:
                structural_diff = diff_result.get("structural_diff", {})
                for d in structural_diff.get("differences", []):
                    for t in d.get("current_tools", []):
                        trace_tools.add(t)
                # Also check tool_sequence in diff
                trace_tools.update(diff_result.get("current_tool_sequence", []))

            # From signals new_side_effects (fallback)
            nse = signals.get("new_side_effects", {})
            if isinstance(nse, dict):
                trace_tools.update(nse.get("current_tools", []))
                trace_tools.update(nse.get("baseline_tools", []))

            # From context tool_sequence (passed by CI compare)
            trace_tools.update(ctx.get("tool_sequence", []))

            if required and trace_tools:
                missing = [t for t in required if t not in trace_tools]
                if missing:
                    msg = (
                        custom_message
                        or f"Required tools missing from execution path: {', '.join(missing)}"
                    )
                    results.append(
                        {
                            "type": "required_tools",
                            "message": msg,
                            "details": {
                                "missing_tools": missing,
                                "required_tools": required,
                                "found_tools": sorted(trace_tools),
                            },
                        }
                    )
            elif required and not trace_tools:
                # No tool info available — can't verify, log warning-level
                logger.debug(
                    "required_tools: no tool data in context to verify against",
                    required=required,
                )

        # Check for decision distribution drift (content-blind)
        if conditions.get("decision_distribution_drift"):
            config = conditions["decision_distribution_drift"]
            if signals.get("decision_distribution_drift", {}).get("detected"):
                drift_details = signals["decision_distribution_drift"].get("details", {})
                threshold = config.get("threshold", 0.15) if isinstance(config, dict) else 0.15
                tracked_fields = (
                    config.get("tracked_fields", []) if isinstance(config, dict) else []
                )

                for field_drift in drift_details.get("drifted_fields", []):
                    if tracked_fields and field_drift.get("field") not in tracked_fields:
                        continue
                    if field_drift.get("jsd", 0) >= threshold:
                        results.append(
                            {
                                "type": "decision_distribution_drift",
                                "message": (
                                    f"Decision distribution drift on "
                                    f"'{field_drift['field']}' "
                                    f"(JSD: {field_drift['jsd']})"
                                ),
                                "details": field_drift,
                            }
                        )

        # Check for output schema drift (content-blind)
        if conditions.get("output_schema_drift"):
            config = conditions["output_schema_drift"]
            if signals.get("output_schema_drift", {}).get("detected"):
                schema_details = signals["output_schema_drift"].get("details", {})
                fail_on_removed = (
                    config.get("fail_on_removed", True) if isinstance(config, dict) else True
                )
                fail_on_added = (
                    config.get("fail_on_added", False) if isinstance(config, dict) else False
                )

                for change in schema_details.get("changes", []):
                    should_fire = False
                    if fail_on_removed and change.get("removed"):
                        should_fire = True
                    if fail_on_added and change.get("added"):
                        should_fire = True
                    if should_fire:
                        results.append(
                            {
                                "type": "output_schema_drift",
                                "message": (f"Output schema changed for '{change['tool']}'"),
                                "details": change,
                            }
                        )

        # Check for confidence/score drift (content-blind)
        if conditions.get("confidence_drift"):
            config = conditions["confidence_drift"]
            if signals.get("confidence_drift", {}).get("detected"):
                score_details = signals["confidence_drift"].get("details", {})
                threshold = (
                    config.get("threshold_drift_percent", 15.0)
                    if isinstance(config, dict)
                    else 15.0
                )
                tracked_scores = (
                    config.get("tracked_scores", []) if isinstance(config, dict) else []
                )

                for score_drift in score_details.get("drifted_scores", []):
                    if tracked_scores and score_drift.get("field") not in tracked_scores:
                        continue
                    if abs(score_drift.get("drift_percent", 0)) >= threshold:
                        results.append(
                            {
                                "type": "confidence_drift",
                                "message": (
                                    f"Score drift on '{score_drift['field']}': "
                                    f"{score_drift['drift_percent']:+.1f}%"
                                ),
                                "details": score_drift,
                            }
                        )

        # Check for behavioral variant
        if conditions.get("on_variant") is not None:
            cond = conditions["on_variant"]
            fp_status = (context or {}).get("fingerprint_status", "")
            if fp_status == "variant":
                similarity = float((context or {}).get("similarity_score") or 0.0)
                fires = False
                if isinstance(cond, bool) and cond:
                    fires = True  # any variant triggers
                elif isinstance(cond, dict):
                    min_sim = float(cond.get("min_similarity", 0.0))
                    fires = similarity < min_sim  # fires when agent drifted too far
                if fires:
                    results.append(
                        {
                            "type": "on_variant",
                            "message": f"Behavioral variant detected ({round(similarity * 100)}% similar)",
                            "details": {
                                "similarity_score": similarity,
                                "fingerprint_status": fp_status,
                            },
                        }
                    )

        if conditions.get("on_new_behavior") is not None:
            cond = conditions["on_new_behavior"]
            fp_status = (context or {}).get("fingerprint_status", "")
            if fp_status == "new":
                fires = False
                if isinstance(cond, bool) and cond:
                    fires = True
                if fires:
                    results.append(
                        {
                            "type": "on_new_behavior",
                            "message": "New behavior pattern detected (no matching baseline intent)",
                            "details": {"fingerprint_status": fp_status},
                        }
                    )

        return results


class Policy:
    """Represents a complete policy configuration."""

    def __init__(self, policy_config: dict[str, Any]) -> None:
        """Initialize policy from configuration.

        Args:
            policy_config: Dictionary with policy configuration
        """
        self.name = policy_config.get("name", "default_policy")
        self.enabled = policy_config.get("enabled", True)
        self.block_merges = policy_config.get("block_merges", False)  # Optional blocking
        self.rules = [PolicyRule(rule) for rule in policy_config.get("rules", [])]

        # Support flat format: top-level fail_if/warn_if without rules array
        if not self.rules and (policy_config.get("fail_if") or policy_config.get("warn_if")):
            self.rules = [
                PolicyRule(
                    {
                        "name": "default",
                        "fail_if": policy_config.get("fail_if", {}),
                        "warn_if": policy_config.get("warn_if", {}),
                    }
                )
            ]

        # Support "default:" section as a shorthand for a default profile.
        # Users may write block_merges/fail_if/warn_if under a top-level
        # "default:" key instead of using the rules array or profiles dict.
        default_section = policy_config.get("default")
        if isinstance(default_section, dict) and not self.rules:
            if not self.block_merges and default_section.get("block_merges"):
                self.block_merges = True
            default_fail_if = default_section.get("fail_if")
            default_warn_if = default_section.get("warn_if")
            if default_fail_if or default_warn_if:
                self.rules = [
                    PolicyRule(
                        {
                            "name": "default",
                            "severity": default_section.get("severity", "medium"),
                            "fail_if": default_fail_if or {},
                            "warn_if": default_warn_if or {},
                        }
                    )
                ]

        # Parse per-agent profiles if present
        self.profiles: dict[str, _ProfilePolicy] = {}
        raw_profiles = policy_config.get("profiles")
        if raw_profiles and isinstance(raw_profiles, dict):
            for profile_id, profile_cfg in raw_profiles.items():
                self.profiles[profile_id] = _ProfilePolicy(profile_cfg)

    def evaluate(
        self,
        signals: dict[str, Any],
        diff_result: dict[str, Any] | None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Evaluate all rules in this policy.

        Args:
            signals: Detected signals
            diff_result: Structural diff result
            context: Optional runtime context (e.g. fingerprint_status, similarity_score)

        Returns:
            Dictionary with policy evaluation results
        """
        if not self.enabled:
            return {
                "policy_name": self.name,
                "enabled": False,
                "block_merges": False,
                "should_block": False,
                "rules": [],
                "passed": True,
                "violations": [],
                "warnings": [],
            }

        rule_results = []
        all_violations = []
        all_warnings = []

        for rule in self.rules:
            result = rule.evaluate(signals, diff_result, context)
            rule_results.append(result)
            all_violations.extend(result["violations"])
            all_warnings.extend(result["warnings"])

        passed = len(all_violations) == 0
        should_block = self.block_merges and not passed

        return {
            "policy_name": self.name,
            "enabled": self.enabled,
            "block_merges": self.block_merges,
            "should_block": should_block,
            "rules": rule_results,
            "passed": passed,
            "violations": all_violations,
            "warnings": all_warnings,
            "violation_count": len(all_violations),
            "warning_count": len(all_warnings),
        }

    def evaluate_for_agent(
        self,
        agent_id: str,
        signals: dict[str, Any],
        diff_result: dict[str, Any] | None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Evaluate policy for a specific agent.

        Resolution order:
            1. ``self.profiles[agent_id]`` if it exists
            2. ``self.profiles["default"]`` as a fallback
            3. The global top-level rules (existing behaviour) when no
               profiles are defined at all

        Args:
            agent_id: Identifier of the agent to evaluate for
            signals: Detected signals
            diff_result: Structural diff result
            context: Optional runtime context

        Returns:
            Dictionary with policy evaluation results
        """
        if not self.enabled:
            return {
                "policy_name": self.name,
                "agent_id": agent_id,
                "enabled": False,
                "block_merges": False,
                "should_block": False,
                "rules": [],
                "passed": True,
                "violations": [],
                "warnings": [],
            }

        # If profiles are defined, resolve the appropriate one
        if self.profiles:
            profile = self.profiles.get(agent_id) or self.profiles.get("default")
            if profile is not None:
                result = profile.evaluate(signals, diff_result, context)
                result["policy_name"] = self.name
                result["agent_id"] = agent_id
                return result

        # No profiles (or no matching profile and no default) -- fall back to
        # the global top-level rules.
        result = self.evaluate(signals, diff_result, context)
        result["agent_id"] = agent_id
        return result


class _ProfilePolicy:
    """A lightweight policy-like object representing a single agent profile.

    Profiles share the same rule-evaluation logic as ``Policy`` but are
    scoped to a single agent.  They support their own ``block_merges``
    flag and ``rules`` list.
    """

    def __init__(self, profile_config: dict[str, Any]) -> None:
        self.block_merges = profile_config.get("block_merges", False)
        self.rules: list[PolicyRule] = [
            PolicyRule(rule) for rule in profile_config.get("rules", [])
        ]

        # Support flat format within a profile
        if not self.rules and (profile_config.get("fail_if") or profile_config.get("warn_if")):
            self.rules = [
                PolicyRule(
                    {
                        "name": "default",
                        "fail_if": profile_config.get("fail_if", {}),
                        "warn_if": profile_config.get("warn_if", {}),
                    }
                )
            ]

    def evaluate(
        self,
        signals: dict[str, Any],
        diff_result: dict[str, Any] | None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Evaluate all rules in this profile."""
        rule_results = []
        all_violations: list[dict[str, Any]] = []
        all_warnings: list[dict[str, Any]] = []

        for rule in self.rules:
            result = rule.evaluate(signals, diff_result, context)
            rule_results.append(result)
            all_violations.extend(result["violations"])
            all_warnings.extend(result["warnings"])

        passed = len(all_violations) == 0
        should_block = self.block_merges and not passed

        return {
            "policy_name": "",  # filled in by caller
            "enabled": True,
            "block_merges": self.block_merges,
            "should_block": should_block,
            "rules": rule_results,
            "passed": passed,
            "violations": all_violations,
            "warnings": all_warnings,
            "violation_count": len(all_violations),
            "warning_count": len(all_warnings),
        }


class PolicyEngine:
    """Policy engine for evaluating policies against traces."""

    def __init__(self, policy_file: Path | None = None) -> None:
        """Initialize policy engine.

        Args:
            policy_file: Optional path to policy YAML file
        """
        self.policy_file = policy_file or self._find_default_policy()
        self.policy: Policy | None = None

        if self.policy_file and self.policy_file.exists():
            self.load_policy(self.policy_file)

    def _find_default_policy(self) -> Path | None:
        """Find default policy file with priority order.

        Priority:
            1. SPOOLED_POLICY_FILE env var (highest)
            2. .spooled/policy.yml in cwd
            3. spooled-policy.yml in cwd
            4. Walk up parent directories for either file
            5. pyproject.toml [tool.spooled] policy_file reference

        Returns:
            Path to policy file if found, None otherwise
        """
        # 1. Environment variable (highest priority)
        env_policy = os.getenv("SPOOLED_POLICY_FILE")
        if env_policy:
            env_path = Path(env_policy)
            if env_path.exists():
                return env_path
            logger.debug("SPOOLED_POLICY_FILE set but file not found", path=env_policy)

        # 2-3. Check cwd first
        cwd = Path.cwd()
        for candidate in [cwd / ".spooled" / "policy.yml", cwd / "spooled-policy.yml"]:
            if candidate.exists():
                return candidate

        # 4. Walk up parent directories
        current = cwd.parent
        while current != current.parent:
            for candidate in [current / ".spooled" / "policy.yml", current / "spooled-policy.yml"]:
                if candidate.exists():
                    return candidate
            current = current.parent

        # 5. Check pyproject.toml for [tool.spooled] policy_file
        pyproject_policy = self._find_pyproject_policy(cwd)
        if pyproject_policy:
            return pyproject_policy

        return None

    @staticmethod
    def _find_pyproject_policy(start_dir: Path) -> Path | None:
        """Find policy file referenced in pyproject.toml.

        Walks up directories looking for pyproject.toml with a
        [tool.spooled] section containing a policy_file key.

        Args:
            start_dir: Directory to start searching from

        Returns:
            Path to policy file if found, None otherwise
        """
        try:
            import tomllib  # Python 3.11+
        except ImportError:
            try:
                import tomli as tomllib  # type: ignore[no-redef]
            except ImportError:
                return None

        current = start_dir
        while current != current.parent:
            pyproject = current / "pyproject.toml"
            if pyproject.exists():
                try:
                    with open(pyproject, "rb") as f:
                        data = tomllib.load(f)
                    policy_path = data.get("tool", {}).get("spooled", {}).get("policy_file")
                    if policy_path:
                        resolved = (current / policy_path).resolve()
                        if resolved.exists():
                            return resolved
                except Exception:
                    pass
            current = current.parent

        return None

    def load_policy(self, policy_file: Path) -> None:
        """Load policy from YAML file.

        Args:
            policy_file: Path to policy YAML file
        """
        try:
            with open(policy_file) as f:
                policy_config = yaml.safe_load(f)

            if not policy_config:
                logger.warning("Policy file is empty", path=str(policy_file))
                return

            self.policy = Policy(policy_config)
            logger.info("Policy loaded", path=str(policy_file), name=self.policy.name)

        except Exception as e:
            logger.error("Failed to load policy", path=str(policy_file), error=str(e))
            raise

    def evaluate(
        self,
        signals: dict[str, Any],
        diff_result: dict[str, Any] | None,
        context: dict[str, Any] | None = None,
        agent_id: str | None = None,
    ) -> dict[str, Any]:
        """Evaluate policy against signals and diff.

        Args:
            signals: Detected signals
            diff_result: Structural diff result
            context: Optional runtime context (e.g. fingerprint_status, similarity_score)
            agent_id: Optional agent identifier. When provided and the loaded
                policy contains per-agent profiles, the evaluation is scoped
                to the matching profile.

        Returns:
            Dictionary with evaluation results
        """
        if not self.policy:
            return {
                "policy_name": "no_policy",
                "enabled": False,
                "block_merges": False,
                "should_block": False,
                "passed": True,
                "violations": [],
                "warnings": [],
            }

        if agent_id is not None:
            return self.policy.evaluate_for_agent(agent_id, signals, diff_result, context)

        return self.policy.evaluate(signals, diff_result, context)
