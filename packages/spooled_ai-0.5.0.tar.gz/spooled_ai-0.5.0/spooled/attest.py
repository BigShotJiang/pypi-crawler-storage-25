"""Client-side attestation submission and offline receipt verification.

Provides a lightweight interface for submitting behavioral measurements
to the attestation service and verifying signed receipts offline using
the public key (no KMS/backend access needed for verification).
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
from typing import Any

import structlog

logger = structlog.get_logger(__name__)

# Local cache for the signing public key
_PUBLIC_KEY_CACHE_PATH = Path(".spooled/signing-public-key.pem")


def submit_attestation(
    agent_id: str,
    fingerprint_hash: str,
    chain_hash: str | None = None,
    drift_score: float | None = None,
    spooled_score: int | None = None,
    spooled_grade: str | None = None,
    metrics: dict[str, Any] | None = None,
    run_id: str | None = None,
    structural_fingerprint_hash: str | None = None,
    backend_url: str | None = None,
    api_key: str | None = None,
) -> dict[str, Any]:
    """Submit behavioral measurements for attestation.

    Sends measurements to the attestation API, which cryptographically
    signs them and returns a portable receipt.

    Args:
        agent_id: Agent identifier
        fingerprint_hash: Structural fingerprint hash
        chain_hash: Hash chain root (optional)
        drift_score: Similarity score 0.0-1.0 (optional)
        spooled_score: Composite score 0-100 (optional)
        spooled_grade: Letter grade A-F (optional)
        metrics: Hard metrics dict (optional)
        run_id: Trace run_id (optional)
        structural_fingerprint_hash: IO-schema hash (optional)
        backend_url: Backend URL (defaults to SPOOLED_BACKEND_URL env var)
        api_key: API key (defaults to SPOOLED_API_KEY env var)

    Returns:
        Dict with attestation_id and receipt

    Raises:
        RuntimeError: If backend is not configured or request fails
    """
    url = backend_url or os.getenv("SPOOLED_BACKEND_URL", "")
    if not url:
        raise RuntimeError("SPOOLED_BACKEND_URL not configured")

    key = api_key or os.getenv("SPOOLED_API_KEY", "")
    if not key:
        raise RuntimeError("SPOOLED_API_KEY not configured")

    try:
        import httpx
    except ImportError:
        raise RuntimeError("httpx is required for attestation submission (pip install httpx)")

    payload: dict[str, Any] = {
        "agent_id": agent_id,
        "fingerprint_hash": fingerprint_hash,
    }
    if run_id is not None:
        payload["run_id"] = run_id
    if chain_hash is not None:
        payload["chain_hash"] = chain_hash
    if drift_score is not None:
        payload["drift_score"] = drift_score
    if spooled_score is not None:
        payload["spooled_score"] = spooled_score
    if spooled_grade is not None:
        payload["spooled_grade"] = spooled_grade
    if metrics is not None:
        payload["metrics"] = metrics
    if structural_fingerprint_hash is not None:
        payload["structural_fingerprint_hash"] = structural_fingerprint_hash

    endpoint = f"{url.rstrip('/')}/api/attestations"
    headers = {
        "Content-Type": "application/json",
        "X-Api-Key": key,
    }

    with httpx.Client(timeout=30.0) as client:
        response = client.post(endpoint, json=payload, headers=headers)
        if response.status_code != 201:
            raise RuntimeError(f"Attestation failed (HTTP {response.status_code}): {response.text}")
        return response.json()


def verify_receipt(
    receipt: dict[str, Any],
    public_key_pem: str | None = None,
    backend_url: str | None = None,
) -> bool:
    """Verify an attestation receipt offline.

    Uses the cryptography library to verify the RSA signature without
    any AWS/KMS access. If public_key_pem is not provided, fetches it
    from the backend (or uses local cache).

    Args:
        receipt: The attestation receipt dict
        public_key_pem: PEM-encoded public key (optional, fetched if not provided)
        backend_url: Backend URL for fetching public key (defaults to env var)

    Returns:
        True if signature is valid, False otherwise
    """
    if not public_key_pem:
        public_key_pem = _get_cached_public_key(backend_url)

    if not public_key_pem:
        logger.warning("No public key available for verification")
        return False

    # Reconstruct the payload that was signed (measurement fields only)
    sign_payload: dict[str, Any] = {
        "attestation_id": receipt["attestation_id"],
        "agent_id": receipt["agent_id"],
        "timestamp": receipt["timestamp"],
        "fingerprint_hash": receipt["fingerprint_hash"],
    }
    for field in (
        "run_id",
        "structural_fingerprint_hash",
        "chain_hash",
        "drift_score",
        "spooled_score",
        "spooled_grade",
        "metrics",
    ):
        if receipt.get(field) is not None:
            sign_payload[field] = receipt[field]

    try:
        from backend.signing import verify_attestation

        return verify_attestation(
            sign_payload,
            receipt["signature"],
            public_key_pem,
        )
    except ImportError:
        # If backend.signing is not importable, do verification inline
        return _verify_signature_inline(sign_payload, receipt["signature"], public_key_pem)


def _verify_signature_inline(
    payload: dict[str, Any], signature_b64: str, public_key_pem: str
) -> bool:
    """Verify signature using cryptography library directly."""
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding, utils

        # Compute canonical digest (same logic as backend.signing)
        cleaned = _strip_none(payload)
        canonical = json.dumps(cleaned, sort_keys=True, separators=(",", ":"), default=str)
        digest_bytes = hashlib.sha256(canonical.encode("utf-8")).digest()

        signature_bytes = base64.b64decode(signature_b64)
        public_key = serialization.load_pem_public_key(public_key_pem.encode("utf-8"))

        public_key.verify(
            signature_bytes,
            digest_bytes,
            padding.PKCS1v15(),
            utils.Prehashed(hashes.SHA256()),
        )
        return True
    except ImportError:
        logger.warning("cryptography library not available for verification")
        return False
    except Exception:
        return False


def _strip_none(obj: Any) -> Any:
    """Recursively remove None values from dicts."""
    if isinstance(obj, dict):
        return {k: _strip_none(v) for k, v in obj.items() if v is not None}
    if isinstance(obj, list):
        return [_strip_none(v) for v in obj]
    return obj


def _get_cached_public_key(backend_url: str | None = None) -> str | None:
    """Get public key from local cache or fetch from backend.

    Cache is stored at .spooled/signing-public-key.pem.

    Args:
        backend_url: Backend URL (defaults to SPOOLED_BACKEND_URL env var)

    Returns:
        PEM-encoded public key string, or None if unavailable
    """
    # Try local cache first
    if _PUBLIC_KEY_CACHE_PATH.exists():
        try:
            pem = _PUBLIC_KEY_CACHE_PATH.read_text().strip()
            if pem.startswith("-----BEGIN PUBLIC KEY-----"):
                return pem
        except Exception:
            pass

    # Fetch from backend
    url = backend_url or os.getenv("SPOOLED_BACKEND_URL", "")
    if not url:
        return None

    try:
        import httpx

        endpoint = f"{url.rstrip('/')}/api/attestations/public-key"
        with httpx.Client(timeout=10.0) as client:
            response = client.get(endpoint)
            if response.status_code == 200:
                data = response.json()
                pem = data.get("public_key_pem", "")
                if pem:
                    # Cache locally
                    _PUBLIC_KEY_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
                    _PUBLIC_KEY_CACHE_PATH.write_text(pem)
                    return pem
    except Exception as e:
        logger.debug("Failed to fetch public key from backend", error=str(e))

    return None


def save_receipt(receipt: dict[str, Any], directory: Path | None = None) -> Path:
    """Save an attestation receipt to the local .spooled/attestations/ directory.

    Args:
        receipt: The attestation receipt dict
        directory: Output directory (defaults to .spooled/attestations/)

    Returns:
        Path to the saved receipt file
    """
    out_dir = directory or Path(".spooled/attestations")
    out_dir.mkdir(parents=True, exist_ok=True)

    attestation_id = receipt.get("attestation_id", "unknown")
    path = out_dir / f"{attestation_id}.json"
    path.write_text(json.dumps(receipt, indent=2, sort_keys=True, default=str))

    logger.info("Receipt saved", path=str(path), attestation_id=attestation_id)
    return path
