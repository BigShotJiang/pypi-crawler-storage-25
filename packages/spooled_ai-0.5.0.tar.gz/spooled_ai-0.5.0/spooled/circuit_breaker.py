"""Circuit breaker for backend HTTP calls.

Prevents unbounded retries, lock contention, and memory growth when the
backend is unreachable.  Three states:

    CLOSED  →  normal operation, failures counted
    OPEN    →  backend assumed down, requests skipped
    HALF_OPEN → one probe request allowed; success → CLOSED, failure → OPEN

Transition rules:
    CLOSED  → [threshold consecutive failures] → OPEN
    OPEN    → [recovery_timeout elapsed]       → HALF_OPEN
    HALF_OPEN → [success]                      → CLOSED
    HALF_OPEN → [failure]                      → OPEN
"""

from __future__ import annotations

import os
import threading
import time
from enum import Enum

import structlog

logger = structlog.get_logger(__name__)


class CircuitState(str, Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """Thread-safe circuit breaker for backend HTTP calls."""

    def __init__(
        self,
        failure_threshold: int | None = None,
        recovery_timeout: float | None = None,
    ) -> None:
        if failure_threshold is None:
            failure_threshold = int(os.getenv("SPOOLED_CB_FAILURE_THRESHOLD", "3"))
        if recovery_timeout is None:
            recovery_timeout = float(os.getenv("SPOOLED_CB_RECOVERY_TIMEOUT", "30"))

        self._failure_threshold = max(1, failure_threshold)
        self._recovery_timeout = max(0.0, recovery_timeout)

        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._opened_at: float = 0.0
        self._lock = threading.Lock()

    # ── public API ──────────────────────────────────────────────────────

    @property
    def state(self) -> CircuitState:
        """Current state, auto-transitioning OPEN → HALF_OPEN after timeout."""
        with self._lock:
            if (
                self._state is CircuitState.OPEN
                and time.monotonic() - self._opened_at >= self._recovery_timeout
            ):
                self._transition(CircuitState.HALF_OPEN)
            return self._state

    def allow_request(self) -> bool:
        """Return True if a backend request should be attempted."""
        current = self.state  # triggers auto-transition
        return current is not CircuitState.OPEN

    def record_success(self) -> None:
        """Record a successful backend call."""
        with self._lock:
            if self._state in (CircuitState.HALF_OPEN, CircuitState.CLOSED):
                self._failure_count = 0
                if self._state is not CircuitState.CLOSED:
                    self._transition(CircuitState.CLOSED)

    def record_failure(self) -> None:
        """Record a failed backend call."""
        with self._lock:
            if self._state is CircuitState.HALF_OPEN:
                self._transition(CircuitState.OPEN)
                return

            self._failure_count += 1
            if self._failure_count >= self._failure_threshold:
                self._transition(CircuitState.OPEN)

    def reset(self) -> None:
        """Force the circuit breaker back to CLOSED."""
        with self._lock:
            self._transition(CircuitState.CLOSED)
            self._failure_count = 0

    # ── internals ───────────────────────────────────────────────────────

    def _transition(self, new_state: CircuitState) -> None:
        """Transition to *new_state* (caller must hold ``_lock``)."""
        old = self._state
        if old is new_state:
            return
        self._state = new_state
        if new_state is CircuitState.OPEN:
            self._opened_at = time.monotonic()
        if new_state is CircuitState.CLOSED:
            self._failure_count = 0
        logger.warning(
            "Circuit breaker state change",
            old_state=old.value,
            new_state=new_state.value,
        )
