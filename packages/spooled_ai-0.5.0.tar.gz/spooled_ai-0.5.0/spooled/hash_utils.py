"""Utility functions for hash chain operations.

This module provides helper functions for working with hash chains,
including validation, calculation, and verification utilities.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


def calculate_payload_hash(
    input_data: dict[str, Any],
    output_data: dict[str, Any] | None,
    error: str | None,
    metadata: dict[str, Any],
) -> str:
    """Calculate SHA-256 hash of an interaction payload.

    Args:
        input_data: Input data dictionary
        output_data: Output data dictionary (optional)
        error: Error message (optional)
        metadata: Metadata dictionary

    Returns:
        SHA-256 hex digest (64 characters)
    """
    payload = {
        "input": input_data,
        "output": output_data,
        "error": error,
        "metadata": metadata,
    }
    payload_json = json.dumps(payload, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(payload_json.encode("utf-8")).hexdigest()


def calculate_interaction_signature(
    interaction_id: str,
    sequence: int,
    interaction_type: str,
    payload_hash: str,
    prev_hash: str | None,
) -> str:
    """Calculate the signature of an interaction for hash chaining.

    The signature is used to link interactions in the chain.

    Args:
        interaction_id: Unique interaction ID
        sequence: Sequence number
        interaction_type: Type of interaction
        payload_hash: Hash of the payload
        prev_hash: Hash of previous interaction's signature (None for first)

    Returns:
        SHA-256 hex digest of the interaction signature (64 characters)
    """
    signature_data = {
        "interaction_id": interaction_id,
        "sequence": sequence,
        "interaction_type": interaction_type,
        "payload_hash": payload_hash,
        "prev_hash": prev_hash or "",
    }
    signature_json = json.dumps(signature_data, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(signature_json.encode("utf-8")).hexdigest()


def validate_hash_format(hash_value: str | None) -> bool:
    """Validate that a hash value is in the correct format.

    Args:
        hash_value: The hash value to validate

    Returns:
        True if valid SHA-256 hex format (64 characters), False otherwise
    """
    if hash_value is None:
        return False
    if not isinstance(hash_value, str):
        return False
    if len(hash_value) != 64:
        return False
    # Check if it's valid hex
    try:
        int(hash_value, 16)
        return True
    except ValueError:
        return False


def verify_interaction_chain(interactions: list[dict[str, Any]]) -> dict[str, Any]:
    """Verify the integrity of a chain of interactions.

    Args:
        interactions: List of interaction dictionaries

    Returns:
        Dictionary with verification results:
        - valid: bool - Whether the chain is valid
        - errors: List[str] - List of error messages
        - final_signature: Optional[str] - The final interaction's signature
    """
    errors: list[str] = []
    prev_signature: str | None = None

    for i, interaction in enumerate(interactions):
        interaction_id = interaction.get("interaction_id", f"interaction_{i}")
        sequence = interaction.get("sequence", i)
        interaction_type = interaction.get("interaction_type", "OTHER")

        # Validate payload_hash
        payload_hash = interaction.get("payload_hash")
        if not payload_hash:
            errors.append(f"Interaction {sequence} ({interaction_id}): Missing payload_hash")
            continue

        if not validate_hash_format(payload_hash):
            errors.append(f"Interaction {sequence} ({interaction_id}): Invalid payload_hash format")
            continue

        # Verify payload_hash matches content
        expected_payload_hash = calculate_payload_hash(
            input_data=interaction.get("input", {}),
            output_data=interaction.get("output"),
            error=interaction.get("error"),
            metadata=interaction.get("metadata", {}),
        )

        if payload_hash != expected_payload_hash:
            errors.append(
                f"Interaction {sequence} ({interaction_id}): payload_hash mismatch. "
                f"Expected {expected_payload_hash[:16]}..., got {payload_hash[:16]}..."
            )

        # Validate prev_hash
        prev_hash = interaction.get("prev_hash")
        if i == 0:
            # First interaction should have prev_hash = None
            if prev_hash is not None:
                errors.append(
                    f"Interaction {sequence} ({interaction_id}): First interaction "
                    f"should have prev_hash=None, got {prev_hash[:16] if prev_hash else None}..."
                )
        else:
            # Subsequent interactions should link to previous
            if prev_hash != prev_signature:
                errors.append(
                    f"Interaction {sequence} ({interaction_id}): prev_hash mismatch. "
                    f"Expected {prev_signature[:16] if prev_signature else None}..., "
                    f"got {prev_hash[:16] if prev_hash else None}..."
                )

        # Calculate this interaction's signature
        interaction_signature = calculate_interaction_signature(
            interaction_id=interaction_id,
            sequence=sequence,
            interaction_type=interaction_type,
            payload_hash=payload_hash,
            prev_hash=prev_hash,
        )
        prev_signature = interaction_signature

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "final_signature": prev_signature,
    }
