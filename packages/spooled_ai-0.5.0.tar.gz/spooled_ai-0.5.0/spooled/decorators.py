"""Decorator-based API for Spooled tracing.

Provides @trace, @tool, and @observe decorators following the same
pattern as Langfuse @observe and Braintrust @traced.

Usage:
    import spooled
    from spooled.decorators import trace, tool

    @trace(agent_id="my_agent")
    def run_agent(query: str):
        result = call_llm(query)
        score = fetch_credit_score(user_id)
        return result

    @tool()
    def fetch_credit_score(user_id: str) -> dict:
        return db.query(...)
"""

from __future__ import annotations

import asyncio
import functools
import inspect
import time
from collections.abc import Callable
from typing import Any, TypeVar

from spooled._context import get_current_recorder, set_current_recorder
from spooled.models import InteractionType, TraceStatus

F = TypeVar("F", bound=Callable[..., Any])

# Max size for serialized argument values
_MAX_ARG_STR_LEN = 1000
_MAX_LIST_ITEMS = 50


def _safe_serialize(value: Any) -> Any:
    """Serialize a value for interaction input/output, with truncation."""
    if value is None:
        return None
    if isinstance(value, (str, int, float, bool)):
        if isinstance(value, str) and len(value) > _MAX_ARG_STR_LEN:
            return value[:_MAX_ARG_STR_LEN] + "...[truncated]"
        return value
    if isinstance(value, (list, tuple)):
        items = list(value[:_MAX_LIST_ITEMS])
        result = [_safe_serialize(i) for i in items]
        if len(value) > _MAX_LIST_ITEMS:
            result.append(f"...[{len(value) - _MAX_LIST_ITEMS} more items]")
        return result
    if isinstance(value, dict):
        return {str(k): _safe_serialize(v) for k, v in value.items()}
    # Non-serializable: use repr, truncated
    r = repr(value)
    if len(r) > _MAX_ARG_STR_LEN:
        r = r[:_MAX_ARG_STR_LEN] + "...[truncated]"
    return r


def _extract_args(fn: Callable, args: tuple, kwargs: dict) -> dict[str, Any]:
    """Extract function arguments as a serializable dict, skipping 'self'/'cls'."""
    sig = inspect.signature(fn)
    bound = sig.bind(*args, **kwargs)
    bound.apply_defaults()
    result = {}
    for name, value in bound.arguments.items():
        if name in ("self", "cls"):
            continue
        result[name] = _safe_serialize(value)
    return result


def _serialize_output(value: Any) -> dict[str, Any] | None:
    """Serialize a function return value as interaction output."""
    if value is None:
        return None
    if isinstance(value, dict):
        return {str(k): _safe_serialize(v) for k, v in value.items()}
    return {"result": _safe_serialize(value)}


def trace(
    agent_id: str | None = None,
    *,
    name: str | None = None,
    **recorder_kwargs: Any,
) -> Callable[[F], F]:
    """Decorator that marks a function as a trace boundary.

    If no active recorder exists, creates one (starts a trace).
    When the function returns, stops the trace with SUCCESS/FAILURE.

    If a recorder is already active (nested call), records an OTHER
    interaction instead of creating a new trace.

    Args:
        agent_id: Agent identifier. Required for outermost trace,
                  defaults to function name if nested.
        name: Display name for this span. Defaults to function.__qualname__.
        **recorder_kwargs: Passed to Recorder() (buffer_size, flush_interval, etc.)
    """

    def decorator(fn: F) -> F:
        span_name = name or fn.__qualname__

        if asyncio.iscoroutinefunction(fn):

            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                recorder = get_current_recorder()

                if recorder is None:
                    # Outermost trace: create recorder
                    from spooled.recorder import Recorder

                    resolved_id = agent_id or fn.__name__
                    recorder = Recorder(agent_id=resolved_id, **recorder_kwargs)
                    recorder.start()
                    set_current_recorder(recorder)
                    try:
                        result = await fn(*args, **kwargs)
                        recorder.stop(TraceStatus.SUCCESS)
                        return result
                    except Exception:
                        recorder.stop(TraceStatus.FAILURE)
                        raise
                    finally:
                        set_current_recorder(None)
                else:
                    # Nested: record as interaction
                    input_data = {
                        "function": span_name,
                        "arguments": _extract_args(fn, args, kwargs),
                    }
                    t0 = time.monotonic()
                    try:
                        result = await fn(*args, **kwargs)
                        latency_ms = (time.monotonic() - t0) * 1000
                        recorder.record_interaction(
                            interaction_type=InteractionType.OTHER,
                            input_data=input_data,
                            output_data=_serialize_output(result),
                            metadata={"latency_ms": round(latency_ms, 2), "decorator": "trace"},
                        )
                        return result
                    except Exception as e:
                        latency_ms = (time.monotonic() - t0) * 1000
                        recorder.record_interaction(
                            interaction_type=InteractionType.OTHER,
                            input_data=input_data,
                            error=str(e),
                            metadata={"latency_ms": round(latency_ms, 2), "decorator": "trace"},
                        )
                        raise

            return async_wrapper  # type: ignore[return-value]

        else:

            @functools.wraps(fn)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                recorder = get_current_recorder()

                if recorder is None:
                    # Outermost trace: create recorder
                    from spooled.recorder import Recorder

                    resolved_id = agent_id or fn.__name__
                    recorder = Recorder(agent_id=resolved_id, **recorder_kwargs)
                    recorder.start()
                    set_current_recorder(recorder)
                    try:
                        result = fn(*args, **kwargs)
                        recorder.stop(TraceStatus.SUCCESS)
                        return result
                    except Exception:
                        recorder.stop(TraceStatus.FAILURE)
                        raise
                    finally:
                        set_current_recorder(None)
                else:
                    # Nested: record as interaction
                    input_data = {
                        "function": span_name,
                        "arguments": _extract_args(fn, args, kwargs),
                    }
                    t0 = time.monotonic()
                    try:
                        result = fn(*args, **kwargs)
                        latency_ms = (time.monotonic() - t0) * 1000
                        recorder.record_interaction(
                            interaction_type=InteractionType.OTHER,
                            input_data=input_data,
                            output_data=_serialize_output(result),
                            metadata={"latency_ms": round(latency_ms, 2), "decorator": "trace"},
                        )
                        return result
                    except Exception as e:
                        latency_ms = (time.monotonic() - t0) * 1000
                        recorder.record_interaction(
                            interaction_type=InteractionType.OTHER,
                            input_data=input_data,
                            error=str(e),
                            metadata={"latency_ms": round(latency_ms, 2), "decorator": "trace"},
                        )
                        raise

            return sync_wrapper  # type: ignore[return-value]

    return decorator


def tool(
    name: str | None = None,
    *,
    parallel_group: str | None = None,
) -> Callable[[F], F]:
    """Decorator that records a function as a TOOL_CALL interaction.

    Requires an active recorder (inside a @trace or after spooled.init()).
    Captures function arguments as input and return value as output.

    The input_data uses {"function": name, "arguments": {...}} format
    to match fingerprint expectations.

    Args:
        name: Tool name. Defaults to function.__name__.
        parallel_group: Group ID for concurrent tool calls.
    """

    def decorator(fn: F) -> F:
        tool_name = name or fn.__name__

        if asyncio.iscoroutinefunction(fn):

            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                recorder = get_current_recorder()
                if recorder is None:
                    # Fall back to global recorder
                    from spooled.recorder import _global_recorder

                    recorder = _global_recorder
                if recorder is None:
                    raise RuntimeError(
                        f"No active Spooled recorder. Use @spooled.trace() or spooled.init() "
                        f"before calling @spooled.tool()-decorated function '{tool_name}'."
                    )

                input_data = {"function": tool_name, "arguments": _extract_args(fn, args, kwargs)}
                t0 = time.monotonic()
                try:
                    result = await fn(*args, **kwargs)
                    latency_ms = (time.monotonic() - t0) * 1000
                    recorder.record_interaction(
                        interaction_type=InteractionType.TOOL_CALL,
                        input_data=input_data,
                        output_data=_serialize_output(result),
                        metadata={"latency_ms": round(latency_ms, 2)},
                        parallel_group=parallel_group,
                    )
                    return result
                except Exception as e:
                    latency_ms = (time.monotonic() - t0) * 1000
                    recorder.record_interaction(
                        interaction_type=InteractionType.TOOL_CALL,
                        input_data=input_data,
                        error=str(e),
                        metadata={"latency_ms": round(latency_ms, 2)},
                        parallel_group=parallel_group,
                    )
                    raise

            return async_wrapper  # type: ignore[return-value]

        else:

            @functools.wraps(fn)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                recorder = get_current_recorder()
                if recorder is None:
                    from spooled.recorder import _global_recorder

                    recorder = _global_recorder
                if recorder is None:
                    raise RuntimeError(
                        f"No active Spooled recorder. Use @spooled.trace() or spooled.init() "
                        f"before calling @spooled.tool()-decorated function '{tool_name}'."
                    )

                input_data = {"function": tool_name, "arguments": _extract_args(fn, args, kwargs)}
                t0 = time.monotonic()
                try:
                    result = fn(*args, **kwargs)
                    latency_ms = (time.monotonic() - t0) * 1000
                    recorder.record_interaction(
                        interaction_type=InteractionType.TOOL_CALL,
                        input_data=input_data,
                        output_data=_serialize_output(result),
                        metadata={"latency_ms": round(latency_ms, 2)},
                        parallel_group=parallel_group,
                    )
                    return result
                except Exception as e:
                    latency_ms = (time.monotonic() - t0) * 1000
                    recorder.record_interaction(
                        interaction_type=InteractionType.TOOL_CALL,
                        input_data=input_data,
                        error=str(e),
                        metadata={"latency_ms": round(latency_ms, 2)},
                        parallel_group=parallel_group,
                    )
                    raise

            return sync_wrapper  # type: ignore[return-value]

    return decorator


def observe(
    name: str | None = None,
    *,
    agent_id: str | None = None,
    **recorder_kwargs: Any,
) -> Callable[[F], F]:
    """General-purpose decorator that auto-detects trace vs span.

    If no active recorder exists, behaves like @trace() (creates a trace).
    If a recorder is active, records an OTHER interaction (nested span).

    This is the "just works" decorator for users who don't want to think
    about whether they need @trace or @tool.

    Args:
        name: Span name. Defaults to function.__qualname__.
        agent_id: Agent ID for outermost trace. Defaults to function name.
        **recorder_kwargs: Passed to Recorder() when creating a trace.
    """
    # observe() is exactly trace() with the same nested/outermost behavior
    return trace(agent_id=agent_id, name=name, **recorder_kwargs)
