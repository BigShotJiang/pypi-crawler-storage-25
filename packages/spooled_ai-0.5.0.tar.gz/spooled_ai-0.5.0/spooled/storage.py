"""Local storage for traces using JSONL format.

This module implements append-only JSONL logging with crash safety.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


class JsonlWriter:
    """Append-only JSONL writer with crash safety.

    Writes events to a JSONL file with explicit flushing to ensure
    data is preserved even if the process crashes.
    """

    def __init__(self, file_path: Path) -> None:
        """Initialize the JSONL writer.

        Args:
            file_path: Path to the JSONL file
        """
        self.file_path = file_path
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        self._file_handle: Any | None = None

    def __enter__(self) -> JsonlWriter:
        """Context manager entry."""
        self._file_handle = open(self.file_path, "a", encoding="utf-8")
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Context manager exit."""
        if self._file_handle:
            self._file_handle.close()
            self._file_handle = None

    def write(self, data: dict[str, Any]) -> None:
        """Write a single JSON object as a line.

        Args:
            data: Dictionary to write as JSON
        """
        if not self._file_handle:
            raise RuntimeError("JsonlWriter not opened (use as context manager)")

        # Convert datetime objects to ISO format strings
        from datetime import datetime

        def json_serializer(obj: Any) -> Any:
            """Custom JSON serializer for datetime objects."""
            if isinstance(obj, datetime):
                return obj.isoformat()
            raise TypeError(f"Type {type(obj)} not serializable")

        line = json.dumps(data, ensure_ascii=False, default=json_serializer) + "\n"
        self._file_handle.write(line)
        self._file_handle.flush()  # Flush to OS buffer
        os.fsync(self._file_handle.fileno())  # Force write to disk

    def write_batch(self, items: list[dict[str, Any]]) -> None:
        """Write multiple JSON objects.

        Args:
            items: List of dictionaries to write
        """
        for item in items:
            self.write(item)


def get_trace_directory() -> Path:
    """Get the trace directory.

    Respects the SPOOLED_TRACE_DIR environment variable if set,
    otherwise defaults to .spooled/traces in the current directory.

    Returns:
        Path to the trace directory
    """
    env_dir = os.getenv("SPOOLED_TRACE_DIR")
    if env_dir:
        return Path(env_dir) / "traces"
    return Path.cwd() / ".spooled" / "traces"


def save_trace_locally(trace: dict[str, Any], run_id: str) -> Path:
    """Save a trace to local JSONL file.

    Args:
        trace: The trace data dictionary
        run_id: The trace run_id

    Returns:
        Path to the saved trace file
    """
    trace_dir = get_trace_directory()
    trace_file = trace_dir / f"{run_id}.jsonl"

    with JsonlWriter(trace_file) as writer:
        # Write trace metadata
        writer.write({"type": "trace", **trace})

    logger.info("Trace saved locally", run_id=run_id, path=str(trace_file))
    return trace_file


def save_interactions_locally(interactions: list[dict[str, Any]], run_id: str) -> Path:
    """Save interactions to local JSONL file.

    Args:
        interactions: List of interaction dictionaries
        run_id: The trace run_id

    Returns:
        Path to the saved trace file
    """
    trace_dir = get_trace_directory()
    trace_file = trace_dir / f"{run_id}.jsonl"

    with JsonlWriter(trace_file) as writer:
        for interaction in interactions:
            writer.write({"type": "interaction", **interaction})

    logger.debug("Interactions saved locally", run_id=run_id, count=len(interactions))
    return trace_file


def load_session_traces(
    session_id: str,
    trace_dir: Path | None = None,
) -> list[dict[str, Any]]:
    """Load all trace files with matching session_id, sorted by depth then timestamp.

    Scans all *.jsonl files in the trace directory, reads the first "trace"-type
    line from each, filters by session_id, and returns full trace data.

    Args:
        session_id: The session ID to filter by
        trace_dir: Optional trace directory (defaults to .spooled/traces)

    Returns:
        List of trace data dicts (each with 'trace' and 'interactions' keys),
        sorted by (depth, timestamp).
    """
    if trace_dir is None:
        trace_dir = get_trace_directory()

    if not trace_dir.exists():
        return []

    matching: list[dict[str, Any]] = []

    for jsonl_file in trace_dir.glob("*.jsonl"):
        try:
            trace_data = load_trace_from_jsonl(jsonl_file)
            trace_meta = trace_data.get("trace", {})
            if trace_meta.get("session_id") == session_id:
                matching.append(trace_data)
        except Exception as e:
            logger.debug("Skipping file in session scan", path=str(jsonl_file), error=str(e))

    # Sort by depth (ascending), then timestamp
    matching.sort(
        key=lambda t: (
            t.get("trace", {}).get("depth", 0),
            t.get("trace", {}).get("timestamp", ""),
        )
    )
    return matching


def load_trace_from_jsonl(file_path: Path) -> dict[str, Any]:
    """Load a trace from a JSONL file.

    Args:
        file_path: Path to the JSONL file

    Returns:
        Dictionary with 'trace' and 'interactions' keys
    """
    trace_data: dict[str, Any] | None = None
    interactions: list[dict[str, Any]] = []

    with open(file_path, encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue

            try:
                data = json.loads(line)
                if data.get("type") == "trace":
                    # Remove 'type' key and store as trace
                    trace_data = {k: v for k, v in data.items() if k != "type"}
                elif data.get("type") == "interaction":
                    # Remove 'type' key and store as interaction
                    interactions.append({k: v for k, v in data.items() if k != "type"})
            except json.JSONDecodeError as e:
                logger.warning("Failed to parse JSONL line", error=str(e), line=line[:100])

    if trace_data is None:
        raise ValueError(f"No trace metadata found in {file_path}")

    return {
        "trace": trace_data,
        "interactions": interactions,
    }
