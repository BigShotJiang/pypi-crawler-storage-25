"""Pydantic models for trace and interaction data.

This module defines the core data schema used across SDK, CLI, and Backend.
All models use Pydantic v2 for validation and serialization.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Annotated, Any

from pydantic import BaseModel, ConfigDict, Field, constr

SHA256_HEX_PATTERN = r"^[0-9a-f]{64}$"
SHA256Hash = Annotated[str, constr(pattern=SHA256_HEX_PATTERN)]


class TraceStatus(str, Enum):
    """Status of a trace execution."""

    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILURE = "FAILURE"


class InteractionType(str, Enum):
    """Type of interaction captured."""

    LLM_CALL = "LLM_CALL"
    TOOL_CALL = "TOOL_CALL"
    HTTP_REQUEST = "HTTP_REQUEST"
    OTHER = "OTHER"


class Trace(BaseModel):
    """Represents a single execution run of an agent.

    This is the parent record in our star schema.
    """

    run_id: str = Field(..., description="Unique identifier for the trace (UUID)")
    agent_id: str = Field(..., description="User-defined name for the agent")
    timestamp: datetime = Field(..., description="UTC start time of the trace")
    status: TraceStatus = Field(..., description="Current status of the trace")
    environment: dict[str, str | None] = Field(
        default_factory=dict, description="Environment metadata (OS, Python version, etc.)"
    )
    tags: list[str] = Field(default_factory=list, description="User-defined tags for filtering")
    user_id: str | None = Field(
        None, description="User who created this trace (for RBAC in Phase 2)"
    )
    chain_hash: SHA256Hash | None = Field(
        None,
        description=(
            "SHA-256 hex digest of the final interaction's signature in the chain. "
            "This represents the cryptographic root of the entire trace's evidence chain."
        ),
    )
    fingerprint_hash: str | None = Field(
        None,
        description="Structural hash of the execution path (for baseline lookup by intent).",
    )
    session_id: str | None = Field(
        None,
        description="Correlation ID linking traces in a multi-agent session. None for standalone traces.",
    )
    parent_run_id: str | None = Field(
        None,
        description="run_id of the parent trace that spawned this one. None for root/standalone traces.",
    )
    depth: int = Field(
        0,
        ge=0,
        description="Nesting depth in the session tree. Root = 0, first child = 1, etc.",
    )

    model_config = ConfigDict(use_enum_values=True)


class Interaction(BaseModel):
    """Represents an individual step within a trace.

    This is a child record that references a Trace via run_id.
    Examples: LLM call, tool invocation, HTTP request.
    """

    interaction_id: str = Field(..., description="Unique identifier for this interaction")
    run_id: str = Field(..., description="Parent trace ID")
    sequence: int = Field(..., description="Order of execution (0-indexed)")
    interaction_type: InteractionType = Field(..., description="Type of interaction")
    timestamp: datetime = Field(..., description="When this interaction occurred")
    input: dict[str, Any] = Field(..., description="Input data (e.g., prompt, function name, URL)")
    output: dict[str, Any] | None = Field(
        None, description="Output data (e.g., response, result, status code)"
    )
    error: str | None = Field(None, description="Error message if the interaction failed")
    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Additional context (latency, tokens, etc.)"
    )
    parent_interaction_id: str | None = Field(
        None,
        description="Parent interaction ID for lineage tracking (Phase 2: decision → inputs → tools → outputs)",
    )
    # Immutable evidence chain fields (AI CI - Evidence Capture)
    prev_hash: SHA256Hash | None = Field(
        None,
        description=(
            "SHA-256 hex digest of the previous interaction's signature. "
            "For the first interaction in a trace, this may be null. "
            "This creates the cryptographic chain linking interactions together."
        ),
    )
    payload_hash: SHA256Hash | None = Field(
        None,
        description=(
            "SHA-256 hex digest of this interaction's canonical payload (input/output/error/metadata). "
            "When redaction is enabled, this is the only persisted representation of sensitive content."
        ),
    )

    structural_hash: SHA256Hash | None = Field(
        None,
        description=(
            "SHA-256 hex digest of the saved structural data (post-strip input/output). "
            "Unlike payload_hash (computed pre-strip), this can be re-verified from the "
            "saved file to detect post-save tampering."
        ),
    )

    # Parallel execution support: interactions in the same group ran concurrently
    parallel_group: str | None = Field(
        None,
        description=(
            "Group ID for interactions that executed in parallel (e.g., concurrent tool calls). "
            "Interactions sharing a parallel_group are treated as unordered for fingerprinting."
        ),
    )

    # Backward-compatible field kept for older traces/docs (deprecated in favor of payload_hash).
    content_hash: SHA256Hash | None = Field(
        None,
        description="DEPRECATED: Use payload_hash. Historical cryptographic hash of interaction content.",
    )

    model_config = ConfigDict(use_enum_values=True)


class AcceptedVariant(BaseModel):
    """Provenance record for an accepted behavior variant.

    Stores who accepted a variant fingerprint, when, and why.
    """

    fingerprint_hash: str = Field(..., description="The accepted variant fingerprint hash")
    accepted_at: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat(),
        description="ISO timestamp when this variant was accepted",
    )
    reason: str | None = Field(
        None, description="Human-readable reason (e.g. 'prompt update', 'model upgrade')"
    )
    accepted_by: str | None = Field(
        None, description="Who accepted this (git user, 'cli', or GitHub Actions run)"
    )

    model_config = ConfigDict(use_enum_values=True)


class SimilarityTrendPoint(BaseModel):
    """One data point in a per-intent CI history series.

    Written by `ci compare` and aggregated by `update-baseline` into
    IntentSummary.similarity_trend (last ≤30 per intent).
    """

    timestamp: str = Field(..., description="ISO 8601 UTC timestamp of the comparison run")
    intent_id: str = Field(
        ..., description="Intent ID (baseline fingerprint hash) this point belongs to"
    )
    similarity_score: float = Field(..., ge=0.0, le=1.0, description="Similarity score (0-1)")
    fingerprint_status: str = Field(..., description="'match' | 'variant' | 'accepted_variant'")
    dominant_reason: str | None = Field(
        None, description="Primary drift dimension (reason_code), if any"
    )
    spooled_score: int | None = Field(
        None, ge=0, le=100, description="Spooled Score at this comparison point"
    )

    model_config = ConfigDict(use_enum_values=True)


class SpooledScoreComponents(BaseModel):
    """Breakdown of Spooled Score into its four weighted components."""

    structural: int | None = Field(
        None, ge=0, le=100, description="Structural similarity (0-100), None on cold start"
    )
    signal: int = Field(100, ge=0, le=100, description="Signal health (0-100)")
    metric: int = Field(100, ge=0, le=100, description="Metric stability (0-100)")
    trend: int = Field(100, ge=0, le=100, description="Trend consistency (0-100)")

    model_config = ConfigDict(use_enum_values=True)


class SpooledScore(BaseModel):
    """Composite behavioral stability score (0-100)."""

    score: int = Field(..., ge=0, le=100, description="Composite score 0-100")
    grade: str = Field(..., description="Letter grade: A/B/C/D/F")
    confidence: str = Field(..., description="Score confidence: high/medium/low")
    components: SpooledScoreComponents = Field(..., description="Per-component breakdown")

    model_config = ConfigDict(use_enum_values=True)


class RunStatistics(BaseModel):
    """Statistics for a specific intent (behavioral pattern) within a baseline.

    Aggregated metrics for runs that share the same behavioral fingerprint.
    Supports rolling-window computation via runs list.
    """

    avg_latency: float = Field(0.0, description="Average trace latency (ms) across runs")
    std_dev_latency: float = Field(0.0, description="Standard deviation of trace latency (ms)")
    avg_tokens: float = Field(0.0, description="Average total tokens across runs")
    error_rate: float = Field(
        0.0, ge=0.0, le=1.0, description="Fraction of runs with errors (0.0-1.0)"
    )
    sample_count: int = Field(0, ge=0, description="Number of runs in the sample")
    fingerprint: dict[str, Any] = Field(
        default_factory=dict,
        description="Behavioral fingerprint defining this intent (structural signature)",
    )
    fingerprint_hash: str | None = Field(
        None,
        description="SHA-256 hash of the fingerprint (intent_id). Set when baseline is created.",
    )
    structural_fingerprint_hash: str | None = Field(
        None,
        description=(
            "SHA-256 hash of the fingerprint based on IO-schema signatures (name-independent). "
            "Used for rename-resilient matching when name-based hash doesn't match."
        ),
    )
    accepted_fingerprints: list[str] = Field(
        default_factory=list,
        description=(
            "List of accepted fingerprint hashes for this intent. "
            "Any fingerprint in this set is treated as 'known behavior'. "
            "Defaults to [fingerprint_hash] when first created."
        ),
    )
    accepted_variants: list[AcceptedVariant] = Field(
        default_factory=list,
        description=(
            "Accepted variant records with provenance (who/when/why). "
            "Newer format alongside accepted_fingerprints; hashes are kept in sync."
        ),
    )
    similarity_trend: list[SimilarityTrendPoint] = Field(
        default_factory=list,
        description="Per-comparison similarity history (populated by update-baseline from ci-history).",
    )
    step_count: int = Field(0, ge=0, description="Number of interaction steps in typical runs")
    tool_call_counts: dict[str, int] = Field(
        default_factory=dict,
        description="Map of tool name -> call count in typical runs",
    )
    tool_presence_rate: dict[str, float] = Field(
        default_factory=dict,
        description="Map of tool name -> fraction of runs that used it (0.0-1.0). "
        "Tools with rate < 1.0 are conditional/optional.",
    )
    token_totals: dict[str, float] = Field(
        default_factory=dict,
        description="Token usage totals (prompt_tokens, completion_tokens, total_tokens)",
    )
    latency_bounds: dict[str, float] = Field(
        default_factory=dict,
        description="Latency bounds (min_ms, max_ms, avg_ms, p95_ms)",
    )
    runs: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Rolling window of run entries (total_latency_ms, total_tokens, has_error)",
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="Last time this intent baseline was updated",
    )
    # Backward compatibility: component-level latency for drift detection
    component_avg_latencies: dict[str, float] = Field(
        default_factory=dict,
        description="Average latency per component (llm:*, tool:*, etc.) for drift detection",
    )
    baseline_env_fingerprint: str | None = Field(
        None,
        description=(
            "Stable string fingerprint of the environment baseline runs were captured in "
            "(e.g. 'darwin/arm64/python3.10'). Used to detect when current trace runs in a "
            "different environment, so latency signals can be downgraded from regression to noise."
        ),
    )

    # Content-blind signal fields
    decision_distributions: dict[str, dict[str, int]] = Field(
        default_factory=dict,
        description="Histogram of tracked categorical output fields: field_name -> {value -> count}",
    )
    output_schema_snapshots: dict[str, list[str]] = Field(
        default_factory=dict,
        description="Map of tool name -> output field names for schema drift detection",
    )
    score_statistics: dict[str, dict[str, float]] = Field(
        default_factory=dict,
        description="Aggregate stats for tracked numeric output fields: field_name -> {avg, std, min, max, count}",
    )

    model_config = ConfigDict(use_enum_values=True)


class AgentBaseline(BaseModel):
    """Intent-scoped baseline for an agent (Cold Start friendly).

    No global stats; all statistics are bucketed by behavioral fingerprint.
    Key: fingerprint_hash (structural signature of the run).
    Value: RunStatistics for that intent (avg_latency, std_dev, token counts, etc.).
    Empty intents dict is valid: the system learns from history automatically
    and does not block when no history exists yet.
    """

    agent_id: str = Field(..., description="Agent identifier")
    updated_at: datetime = Field(..., description="Last time this baseline was updated")
    intents: dict[str, RunStatistics] = Field(
        default_factory=dict,
        description="Map of fingerprint_hash -> RunStatistics for that intent",
    )

    model_config = ConfigDict(use_enum_values=True)


class AttestationRecord(BaseModel):
    """A cryptographically signed behavioral measurement.

    Stores the full attestation record including the KMS signature,
    behavioral measurements, and metadata. This is the server-side record.
    """

    attestation_id: str = Field(..., description="UUID for this attestation")
    org_id: str = Field(..., description="Organization that owns this attestation")
    agent_id: str = Field(..., description="Agent being attested")
    run_id: str | None = Field(
        None, description="Trace run_id (optional — can attest baselines too)"
    )
    timestamp: str = Field(..., description="ISO 8601 UTC when attestation was created")

    # Behavioral measurements (what gets signed)
    fingerprint_hash: str = Field(..., description="Structural fingerprint hash")
    structural_fingerprint_hash: str | None = Field(
        None, description="IO-schema hash (rename-resilient)"
    )
    chain_hash: str | None = Field(None, description="Hash chain root (tamper-evident)")
    drift_score: float | None = Field(
        None, ge=0.0, le=1.0, description="Similarity to baseline (0.0-1.0)"
    )
    spooled_score: int | None = Field(None, ge=0, le=100, description="Composite score 0-100")
    spooled_grade: str | None = Field(None, description="Letter grade A-F")

    # Hard metrics
    metrics: dict[str, Any] = Field(
        default_factory=dict,
        description="Hard metrics: latency_ms, total_tokens, step_count, error_rate, tool_sequence",
    )

    # Signing
    signature: str | None = Field(None, description="Base64-encoded KMS signature")
    signing_key_id: str | None = Field(None, description="KMS key ARN used for signing")
    signing_algorithm: str = Field("RSASSA_PKCS1_V1_5_SHA_256", description="Signing algorithm")
    digest: str | None = Field(None, description="SHA-256 of the canonical payload that was signed")

    # Status
    status: str = Field("signed", description="'signed' | 'revoked'")

    model_config = ConfigDict(use_enum_values=True)


class AttestationReceipt(BaseModel):
    """Portable signed receipt returned to the client.

    Contains everything needed to independently verify the attestation
    without access to the backend.
    """

    attestation_id: str = Field(..., description="UUID for this attestation")
    agent_id: str = Field(..., description="Agent that was attested")
    timestamp: str = Field(..., description="ISO 8601 UTC when attestation was created")
    fingerprint_hash: str = Field(..., description="Structural fingerprint hash")
    chain_hash: str | None = Field(None, description="Hash chain root")
    drift_score: float | None = Field(None, description="Similarity to baseline")
    spooled_score: int | None = Field(None, description="Composite score 0-100")
    spooled_grade: str | None = Field(None, description="Letter grade A-F")
    metrics: dict[str, Any] = Field(default_factory=dict, description="Hard metrics snapshot")
    signature: str = Field(..., description="Base64 KMS signature")
    signing_key_id: str = Field(..., description="KMS key ARN")
    signing_algorithm: str = Field("RSASSA_PKCS1_V1_5_SHA_256", description="Signing algorithm")
    digest: str = Field(..., description="SHA-256 of canonical payload")
    verify_url: str | None = Field(None, description="URL to verify this receipt")

    model_config = ConfigDict(use_enum_values=True)


class BaselineIntent(BaseModel):
    """Per-intent baseline stats for UI and API contract.

    Keyed by fingerprint_hash in Baseline.intents.
    """

    fingerprint_hash: str = Field(..., description="Structural hash for this intent")
    accepted_fingerprints: list[str] = Field(
        default_factory=list,
        description="Accepted fingerprint hashes for this intent (known behavior variants)",
    )
    call_count: int = Field(0, ge=0, description="Number of runs in this intent")
    avg_duration: float = Field(0.0, description="Average trace duration (ms)")
    avg_tokens: float = Field(0.0, description="Average total tokens")
    error_rate: float = Field(0.0, ge=0.0, le=1.0, description="Fraction of runs with errors")
    last_seen: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="Last time this intent was observed",
    )

    model_config = ConfigDict(use_enum_values=True)


class Baseline(BaseModel):
    """Baseline summary for an agent (UI contract).

    intents is keyed by fingerprint_hash for baseline lookup.
    """

    agent_id: str = Field(..., description="Agent identifier")
    environment: str = Field("default", description="Environment name")
    updated_at: datetime = Field(..., description="Last baseline update")
    intents: dict[str, BaselineIntent] = Field(
        default_factory=dict,
        description="Map of fingerprint_hash -> BaselineIntent",
    )

    model_config = ConfigDict(use_enum_values=True)


class IntentSummary(BaseModel):
    """Compact per-intent summary for git-committable baseline files.

    Contains everything needed for CI comparison without full trace data.
    """

    fingerprint_hash: str = Field(..., description="Primary fingerprint hash (intent_id)")
    structural_fingerprint_hash: str | None = Field(
        None,
        description=(
            "SHA-256 hash of the fingerprint based on IO-schema signatures (name-independent). "
            "Used for rename-resilient matching when name-based hash doesn't match."
        ),
    )
    accepted_fingerprints: list[str] = Field(
        default_factory=list,
        description="All accepted fingerprint hashes (known behavior variants)",
    )
    step_count: int = Field(0, ge=0, description="Typical number of interaction steps")
    tool_call_counts: dict[str, int] = Field(
        default_factory=dict,
        description="Map of tool name -> typical call count",
    )
    tool_presence_rate: dict[str, float] = Field(
        default_factory=dict,
        description="Map of tool name -> fraction of baseline runs that used it (0.0-1.0). "
        "Tools with rate < 1.0 are conditional/optional.",
    )
    token_totals: dict[str, float] = Field(
        default_factory=dict,
        description="Token usage (prompt_tokens, completion_tokens, total_tokens)",
    )
    latency_bounds: dict[str, float] = Field(
        default_factory=dict,
        description="Latency bounds (min_ms, max_ms, avg_ms, p95_ms)",
    )
    avg_latency: float = Field(0.0, description="Average trace latency (ms)")
    avg_tokens: float = Field(0.0, description="Average total tokens")
    run_count: int = Field(0, ge=0, description="Number of runs used to build this summary")
    frequency_pct: float = Field(
        0.0,
        ge=0.0,
        le=100.0,
        description="Percentage of total agent runs that followed this intent pattern",
    )
    error_rate: float = Field(0.0, ge=0.0, le=1.0, description="Fraction of runs with errors")
    component_avg_latencies: dict[str, float] = Field(
        default_factory=dict,
        description="Average latency per component (llm:*, tool:*, etc.)",
    )
    fingerprint: dict[str, Any] = Field(
        default_factory=dict,
        description="Full behavioral fingerprint data for structural comparison",
    )
    contributing_run_ids: list[str] = Field(
        default_factory=list,
        description="run_ids of traces that contributed to this intent summary (lineage).",
    )
    accepted_variants: list[AcceptedVariant] = Field(
        default_factory=list,
        description=(
            "Accepted variant provenance records (who/when/why). "
            "Mirrors RunStatistics.accepted_variants; preserved through save_summary roundtrip."
        ),
    )
    similarity_trend: list[SimilarityTrendPoint] = Field(
        default_factory=list,
        description="Last ≤30 CI comparison results for this intent.",
    )
    spooled_score: SpooledScore | None = Field(
        None,
        description="Last computed Spooled Score (0-100) for this intent.",
    )
    baseline_env_fingerprint: str | None = Field(
        None,
        description=(
            "Stable string fingerprint of the environment baseline runs were captured in "
            "(e.g. 'darwin/arm64/python3.10'). Mirrored from RunStatistics for roundtrip."
        ),
    )

    # Content-blind signal fields (mirrored from RunStatistics for baseline summary roundtrip)
    decision_distributions: dict[str, dict[str, int]] = Field(
        default_factory=dict,
        description="Histogram of tracked categorical output fields: field_name -> {value -> count}",
    )
    output_schema_snapshots: dict[str, list[str]] = Field(
        default_factory=dict,
        description="Map of tool name -> output field names for schema drift detection",
    )
    score_statistics: dict[str, dict[str, float]] = Field(
        default_factory=dict,
        description="Aggregate stats for tracked numeric output fields: field_name -> {avg, std, min, max, count}",
    )

    model_config = ConfigDict(use_enum_values=True)


class BaselineSummary(BaseModel):
    """Compact, git-committable baseline file.

    This is the 'snapshot test' format: committed to git alongside code.
    Contains per-intent summaries with all data needed for CI comparison.
    """

    version: str = Field("1", description="Baseline summary format version")
    agent_id: str = Field(..., description="Agent identifier")
    tags: list[str] = Field(
        default_factory=list,
        description="User-defined tags for fleet grouping and filtering (e.g., ['payments', 'v2'])",
    )
    updated_at: datetime = Field(..., description="When this summary was generated")
    intents: dict[str, IntentSummary] = Field(
        default_factory=dict,
        description="Map of fingerprint_hash -> IntentSummary",
    )

    model_config = ConfigDict(use_enum_values=True)
