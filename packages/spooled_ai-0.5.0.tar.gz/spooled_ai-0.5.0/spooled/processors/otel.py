"""OTEL SpanProcessor that ingests spans into the Spooled pipeline.

Users with existing OpenTelemetry instrumentation can add this processor
to their TracerProvider to get Spooled fingerprinting, hash chains,
baselines, and policy gating without changing their instrumentation.

Usage:
    from spooled.processors.otel import SpooledSpanProcessor

    provider.add_span_processor(SpooledSpanProcessor(agent_id="my_agent"))
"""

from __future__ import annotations

import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import structlog

from spooled.models import Interaction, InteractionType, Trace, TraceStatus

logger = structlog.get_logger(__name__)

try:
    from opentelemetry.context import Context
    from opentelemetry.sdk.trace import ReadableSpan, Span
    from opentelemetry.sdk.trace.export import SpanProcessor  # noqa: F401

    HAS_OTEL = True
except ImportError:
    HAS_OTEL = False


# Default timeout before finalizing a trace (seconds of inactivity)
_DEFAULT_TRACE_TIMEOUT = 30.0
# Maximum age for a trace collector before forced finalization
_MAX_TRACE_AGE = 300.0


class _TraceCollector:
    """Collects OTEL spans for a single trace and converts to Spooled format.

    Groups spans by OTEL trace_id, then on finalization:
    1. Converts to Spooled Interactions
    2. Detects parallel groups
    3. Computes hash chains
    4. Generates behavioral fingerprint
    """

    def __init__(self, trace_id: int, agent_id: str) -> None:
        self.trace_id = trace_id
        self.agent_id = agent_id
        self.run_id = str(uuid.uuid4())
        self.spans: list[ReadableSpan] = []
        self.last_span_time = time.monotonic()
        self.created_at = time.monotonic()
        self._finalized = False

    def add_span(self, span: ReadableSpan) -> None:
        """Add a completed span to this collector."""
        self.spans.append(span)
        self.last_span_time = time.monotonic()

    def is_stale(self, timeout: float = _DEFAULT_TRACE_TIMEOUT) -> bool:
        """Check if this collector has been inactive for too long."""
        return (time.monotonic() - self.last_span_time) > timeout

    def is_expired(self, max_age: float = _MAX_TRACE_AGE) -> bool:
        """Check if this collector has exceeded maximum age."""
        return (time.monotonic() - self.created_at) > max_age

    def finalize(self, fingerprint_mode: str = "sequence") -> dict[str, Any]:
        """Convert collected spans to a Spooled trace with hash chains.

        Returns:
            Dict with "trace" (Trace) and "interactions" (list of Interaction)
        """
        if self._finalized:
            return {"trace": None, "interactions": []}
        self._finalized = True

        from spooled.processors._converter import detect_parallel_groups, span_to_interaction

        # Sort spans by start_time
        sorted_spans = sorted(
            self.spans,
            key=lambda s: s.start_time or 0,
        )

        # Detect parallel groups
        parallel_map = detect_parallel_groups(sorted_spans)

        # Convert spans to interactions
        interactions: list[Interaction] = []
        for i, span in enumerate(sorted_spans):
            interaction = span_to_interaction(
                span,
                sequence=i,
                parallel_group=parallel_map.get(i),
            )
            # Set run_id
            interaction.run_id = self.run_id
            interactions.append(interaction)

        if not interactions:
            return {"trace": None, "interactions": []}

        # Compute hash chains
        from spooled.recorder import Recorder

        prev_sig: str | None = None
        for interaction in interactions:
            # Calculate payload hash
            interaction.payload_hash = Recorder._calculate_payload_hash(
                input_data=interaction.input,
                output_data=interaction.output,
                error=interaction.error,
                metadata=interaction.metadata,
            )
            interaction.prev_hash = prev_sig

            # Calculate interaction signature for chain
            prev_sig = Recorder._calculate_interaction_signature(
                interaction_id=interaction.interaction_id,
                sequence=interaction.sequence,
                interaction_type=InteractionType(interaction.interaction_type),
                payload_hash=interaction.payload_hash,
                prev_hash=prev_sig,
            )

        chain_hash = prev_sig

        # Calculate fingerprint
        fingerprint_hash: str | None = None
        try:
            from spooled.fingerprint import calculate_fingerprint_hash

            fingerprint_hash = calculate_fingerprint_hash(interactions, mode=fingerprint_mode)
        except Exception as e:
            logger.debug("Failed to compute fingerprint from OTEL spans", error=str(e))

        # Build trace
        timestamp = interactions[0].timestamp if interactions else datetime.now(timezone.utc)
        trace = Trace(
            run_id=self.run_id,
            agent_id=self.agent_id,
            timestamp=timestamp,
            status=TraceStatus.SUCCESS,
            chain_hash=chain_hash,
            fingerprint_hash=fingerprint_hash,
        )

        return {"trace": trace, "interactions": interactions}


class SpooledSpanProcessor:
    """OTEL SpanProcessor that converts spans to Spooled traces.

    Implements the OTEL SpanProcessor interface. Add to any existing
    TracerProvider to get Spooled fingerprinting, hash chains, and
    policy gating on your existing OTEL-instrumented code.

    Args:
        agent_id: Agent identifier for all traces processed
        backend_url: Optional Spooled backend URL for pushing traces
        policy_file: Optional path to a spooled-policy.yml file
        local_storage: Whether to save traces locally (default: True)
        tags: Optional tags for fleet grouping
        fingerprint_mode: "sequence" (default) or "structural"
        trace_timeout: Seconds of inactivity before finalizing a trace
    """

    def __init__(
        self,
        agent_id: str,
        *,
        backend_url: str | None = None,
        policy_file: Path | None = None,
        local_storage: bool = True,
        tags: list[str] | None = None,
        fingerprint_mode: str = "sequence",
        trace_timeout: float = _DEFAULT_TRACE_TIMEOUT,
    ) -> None:
        if not HAS_OTEL:
            raise ImportError(
                "opentelemetry packages required. Install with: pip install spooled[otel]"
            )

        self.agent_id = agent_id
        self.backend_url = backend_url
        self.policy_file = policy_file
        self.local_storage = local_storage
        self.tags = tags or []
        self.fingerprint_mode = fingerprint_mode
        self.trace_timeout = trace_timeout

        # Trace collectors indexed by OTEL trace_id
        self._collectors: dict[int, _TraceCollector] = {}
        self._lock = threading.Lock()
        self._shutdown = False

        # Background thread to check for stale collectors
        self._reaper_event = threading.Event()
        self._reaper_thread = threading.Thread(target=self._reaper_loop, daemon=True)
        self._reaper_thread.start()

    def on_start(self, span: Span, parent_context: Context | None = None) -> None:
        """Called when a span starts. No-op — we process on end."""
        pass

    def on_end(self, span: ReadableSpan) -> None:
        """Called when a span ends. Convert and add to collector."""
        if self._shutdown:
            return

        trace_id = span.context.trace_id if span.context else 0
        if trace_id == 0:
            return

        with self._lock:
            if trace_id not in self._collectors:
                self._collectors[trace_id] = _TraceCollector(trace_id, self.agent_id)
            self._collectors[trace_id].add_span(span)

    def shutdown(self) -> None:
        """Finalize all pending collectors and stop the reaper thread."""
        self._shutdown = True
        self._reaper_event.set()
        self._reaper_thread.join(timeout=10.0)

        # Finalize remaining collectors
        with self._lock:
            for trace_id in list(self._collectors.keys()):
                self._finalize_collector(trace_id)

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force flush all pending collectors.

        Args:
            timeout_millis: Maximum time to wait (unused, included for interface compliance)

        Returns:
            True if all collectors were flushed successfully
        """
        with self._lock:
            for trace_id in list(self._collectors.keys()):
                self._finalize_collector(trace_id)
        return True

    def _reaper_loop(self) -> None:
        """Background thread that checks for stale/expired collectors."""
        while not self._reaper_event.wait(timeout=self.trace_timeout / 2):
            if self._shutdown:
                return
            self._check_stale_collectors()

    def _check_stale_collectors(self) -> None:
        """Finalize collectors that have been inactive or have expired."""
        with self._lock:
            stale_ids = [
                tid
                for tid, collector in self._collectors.items()
                if collector.is_stale(self.trace_timeout) or collector.is_expired()
            ]
            for trace_id in stale_ids:
                self._finalize_collector(trace_id)

    def _finalize_collector(self, trace_id: int) -> None:
        """Finalize a trace collector and push through the Spooled pipeline.

        Must be called with self._lock held.
        """
        collector = self._collectors.pop(trace_id, None)
        if collector is None:
            return

        try:
            result = collector.finalize(fingerprint_mode=self.fingerprint_mode)
            trace = result.get("trace")
            interactions = result.get("interactions", [])

            if trace is None or not interactions:
                return

            # Apply tags
            trace.tags = self.tags

            # Store locally
            if self.local_storage:
                self._store_locally(trace, interactions)

            # Evaluate policy
            if self.policy_file:
                self._evaluate_policy(trace, interactions)

            logger.info(
                "OTEL trace ingested",
                run_id=trace.run_id,
                agent_id=trace.agent_id,
                interaction_count=len(interactions),
                fingerprint_hash=trace.fingerprint_hash,
                chain_hash=trace.chain_hash[:16] + "..." if trace.chain_hash else None,
            )

        except Exception as e:
            logger.warning("Failed to finalize OTEL trace", error=str(e), trace_id=trace_id)

    def _store_locally(self, trace: Trace, interactions: list[Interaction]) -> None:
        """Save trace and interactions to local JSONL storage."""
        try:
            from spooled.storage import save_interactions_locally, save_trace_locally

            save_trace_locally(trace.model_dump(mode="json"), trace.run_id)
            interaction_dicts = [i.model_dump(mode="json") for i in interactions]
            save_interactions_locally(interaction_dicts, trace.run_id)
        except Exception as e:
            logger.warning("Failed to store OTEL trace locally", error=str(e))

        # Add to baseline
        try:
            from spooled.baseline import BaselineManager

            manager = BaselineManager(trace.agent_id)
            trace_data = {
                "trace": trace.model_dump(mode="json"),
                "interactions": [i.model_dump(mode="json") for i in interactions],
            }
            manager.add_to_baseline(trace_data, TraceStatus.SUCCESS.value)
        except Exception as e:
            logger.debug("Failed to add OTEL trace to baseline", error=str(e))

    def _evaluate_policy(self, trace: Trace, interactions: list[Interaction]) -> None:
        """Evaluate policy against the ingested trace."""
        try:
            from spooled.policy import PolicyEngine

            engine = PolicyEngine(self.policy_file)
            from spooled.signals import SignalDetector

            detector = SignalDetector()
            signals = detector.detect(trace, interactions)
            result = engine.evaluate(signals)

            if result.get("violations"):
                logger.warning(
                    "OTEL trace policy violations",
                    run_id=trace.run_id,
                    violations=result["violations"],
                )
        except Exception as e:
            logger.debug("Policy evaluation failed for OTEL trace", error=str(e))
