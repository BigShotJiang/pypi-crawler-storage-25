"""Spooled processors — ingest traces from external systems.

Available processors:
    SpooledSpanProcessor: Ingest OTEL spans into the Spooled pipeline.

Install OTEL support with: pip install spooled[otel]
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from spooled.processors.otel import SpooledSpanProcessor

__all__ = ["SpooledSpanProcessor"]


def __getattr__(name: str):  # type: ignore[no-untyped-def]
    if name == "SpooledSpanProcessor":
        from spooled.processors.otel import SpooledSpanProcessor

        return SpooledSpanProcessor
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
