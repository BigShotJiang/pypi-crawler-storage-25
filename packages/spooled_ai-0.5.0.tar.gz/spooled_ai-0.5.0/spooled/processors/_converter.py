"""Converts OTEL spans to Spooled Interaction objects.

This module provides the reverse mapping from OTEL semantic conventions
back to Spooled's Interaction model, enabling users with existing OTEL
instrumentation to feed traces into the Spooled pipeline.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any

import structlog

from spooled.exporters._semconv import (
    GEN_AI_REQUEST_MAX_TOKENS,
    GEN_AI_REQUEST_MODEL,
    GEN_AI_REQUEST_TEMPERATURE,
    GEN_AI_SYSTEM,
    GEN_AI_USAGE_INPUT_TOKENS,
    GEN_AI_USAGE_OUTPUT_TOKENS,
    HTTP_REQUEST_METHOD,
    HTTP_RESPONSE_STATUS_CODE,
    TOOL_ARGUMENTS,
    TOOL_CALL_ID,
    TOOL_NAME,
    URL_FULL,
)
from spooled.models import Interaction, InteractionType

logger = structlog.get_logger(__name__)

try:
    from opentelemetry.sdk.trace import ReadableSpan

    HAS_OTEL = True
except ImportError:
    HAS_OTEL = False


def classify_span(attrs: dict[str, Any]) -> InteractionType:
    """Classify an OTEL span as a Spooled InteractionType.

    Detection heuristics (in priority order):
    1. gen_ai.system or gen_ai.request.model -> LLM_CALL
    2. tool.name -> TOOL_CALL
    3. http.request.method or http.method -> HTTP_REQUEST
    4. Otherwise -> OTHER
    """
    if attrs.get(GEN_AI_SYSTEM) or attrs.get(GEN_AI_REQUEST_MODEL):
        return InteractionType.LLM_CALL
    if attrs.get(TOOL_NAME):
        return InteractionType.TOOL_CALL
    if attrs.get(HTTP_REQUEST_METHOD) or attrs.get("http.method"):
        return InteractionType.HTTP_REQUEST
    return InteractionType.OTHER


def span_to_interaction(
    span: ReadableSpan,
    sequence: int = 0,
    parallel_group: str | None = None,
) -> Interaction:
    """Convert an OTEL ReadableSpan to a Spooled Interaction.

    Args:
        span: The OTEL span to convert
        sequence: Sequence number within the trace
        parallel_group: Optional parallel group ID

    Returns:
        Spooled Interaction (without hash chain fields — caller computes those)
    """
    attrs = dict(span.attributes or {})
    itype = classify_span(attrs)

    # Calculate latency from span timestamps (nanoseconds -> milliseconds)
    latency_ms = 0.0
    if span.start_time is not None and span.end_time is not None:
        latency_ms = (span.end_time - span.start_time) / 1e6

    # Convert span timestamp to datetime
    if span.start_time is not None:
        timestamp = datetime.fromtimestamp(span.start_time / 1e9, tz=timezone.utc)
    else:
        timestamp = datetime.now(timezone.utc)

    # Build input/output/metadata based on interaction type
    input_data: dict[str, Any]
    output_data: dict[str, Any] | None = None
    metadata: dict[str, Any] = {"latency_ms": latency_ms}
    error: str | None = None

    if itype == InteractionType.LLM_CALL:
        input_data, output_data, metadata = _convert_llm_span(attrs, metadata)
    elif itype == InteractionType.TOOL_CALL:
        input_data, output_data, metadata = _convert_tool_span(attrs, metadata)
    elif itype == InteractionType.HTTP_REQUEST:
        input_data, output_data, metadata = _convert_http_span(attrs, metadata)
    else:
        input_data = {"span_name": span.name}

    # Capture error from span status
    if span.status is not None:
        from opentelemetry.trace import StatusCode

        if span.status.status_code == StatusCode.ERROR:
            error = span.status.description or "error"

    # Generate a deterministic interaction_id from span context
    span_id_hex = format(span.context.span_id, "016x") if span.context else str(uuid.uuid4())
    interaction_id = str(uuid.uuid5(uuid.NAMESPACE_OID, span_id_hex))

    return Interaction(
        interaction_id=interaction_id,
        run_id="",  # Caller sets this
        sequence=sequence,
        interaction_type=itype,
        timestamp=timestamp,
        input=input_data,
        output=output_data,
        error=error,
        metadata=metadata,
        parallel_group=parallel_group,
    )


def _convert_llm_span(
    attrs: dict[str, Any], metadata: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, Any] | None, dict[str, Any]]:
    """Convert LLM-related span attributes to Interaction fields."""
    model = attrs.get(GEN_AI_REQUEST_MODEL, "unknown")
    input_data: dict[str, Any] = {
        "model": model,
        "messages": [],  # OTEL typically doesn't carry full messages
    }

    temp = attrs.get(GEN_AI_REQUEST_TEMPERATURE)
    if temp is not None:
        input_data["temperature"] = float(temp)
    max_tok = attrs.get(GEN_AI_REQUEST_MAX_TOKENS)
    if max_tok is not None:
        input_data["max_tokens"] = int(max_tok)

    metadata["model"] = model

    output_data: dict[str, Any] | None = None
    input_tokens = attrs.get(GEN_AI_USAGE_INPUT_TOKENS)
    output_tokens = attrs.get(GEN_AI_USAGE_OUTPUT_TOKENS)
    if input_tokens is not None or output_tokens is not None:
        usage: dict[str, int] = {}
        if input_tokens is not None:
            usage["prompt_tokens"] = int(input_tokens)
            metadata["input_tokens"] = int(input_tokens)
        if output_tokens is not None:
            usage["completion_tokens"] = int(output_tokens)
            metadata["completion_tokens"] = int(output_tokens)
        total = (input_tokens or 0) + (output_tokens or 0)
        metadata["tokens"] = int(total)
        output_data = {"usage": usage}

    return input_data, output_data, metadata


def _convert_tool_span(
    attrs: dict[str, Any], metadata: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, Any] | None, dict[str, Any]]:
    """Convert tool-related span attributes to Interaction fields."""
    tool_name = attrs.get(TOOL_NAME, "unknown")
    input_data: dict[str, Any] = {"function": tool_name}

    arguments = attrs.get(TOOL_ARGUMENTS)
    if arguments is not None:
        try:
            input_data["arguments"] = (
                json.loads(arguments) if isinstance(arguments, str) else arguments
            )
        except (json.JSONDecodeError, TypeError):
            input_data["arguments"] = {"raw": str(arguments)}

    call_id = attrs.get(TOOL_CALL_ID)
    if call_id:
        input_data["call_id"] = call_id

    return input_data, None, metadata


def _convert_http_span(
    attrs: dict[str, Any], metadata: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, Any] | None, dict[str, Any]]:
    """Convert HTTP-related span attributes to Interaction fields."""
    method = attrs.get(HTTP_REQUEST_METHOD) or attrs.get("http.method", "GET")
    url = attrs.get(URL_FULL) or attrs.get("http.url", "")
    input_data: dict[str, Any] = {"method": method, "url": url}

    status_code = attrs.get(HTTP_RESPONSE_STATUS_CODE)
    if status_code is not None:
        metadata["status_code"] = int(status_code)

    return input_data, None, metadata


def detect_parallel_groups(
    spans: list[ReadableSpan],
) -> dict[int, str | None]:
    """Detect parallel execution groups from OTEL span timing.

    Spans sharing the same parent span with overlapping time ranges
    are assigned the same parallel_group ID.

    Args:
        spans: List of OTEL spans sorted by start_time

    Returns:
        Map of span index -> parallel_group (or None if sequential)
    """
    groups: dict[int, str | None] = dict.fromkeys(range(len(spans)))

    # Group spans by parent_span_id
    by_parent: dict[int, list[int]] = {}
    for i, span in enumerate(spans):
        parent_id = span.parent.span_id if span.parent else 0
        by_parent.setdefault(parent_id, []).append(i)

    for _parent_id, sibling_indices in by_parent.items():
        if len(sibling_indices) < 2:
            continue

        # Check for overlapping time ranges among siblings
        for i in range(len(sibling_indices)):
            for j in range(i + 1, len(sibling_indices)):
                si = sibling_indices[i]
                sj = sibling_indices[j]
                span_i = spans[si]
                span_j = spans[sj]

                if span_i.start_time is None or span_j.start_time is None:
                    continue
                if span_i.end_time is None or span_j.end_time is None:
                    continue

                # Overlapping if one starts before the other ends
                if span_i.start_time < span_j.end_time and span_j.start_time < span_i.end_time:
                    # Assign same parallel group
                    existing_i = groups[si]
                    existing_j = groups[sj]

                    if existing_i and existing_j:
                        # Merge: update all with group_j to use group_i
                        for k in groups:
                            if groups[k] == existing_j:
                                groups[k] = existing_i
                    elif existing_i:
                        groups[sj] = existing_i
                    elif existing_j:
                        groups[si] = existing_j
                    else:
                        pg = str(uuid.uuid4())
                        groups[si] = pg
                        groups[sj] = pg

    return groups
