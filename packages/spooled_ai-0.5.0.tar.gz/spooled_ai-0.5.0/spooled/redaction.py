"""Privacy Firewall: Redaction engine for scrubbing PII from traces.

This module provides a centralized RedactionEngine that sanitizes input/output
data based on configurable rules before data is stored or hashed.
"""

from __future__ import annotations

import os
import re
from re import Pattern
from typing import Any

import structlog

logger = structlog.get_logger(__name__)

# Field names that look like "token" but are LLM usage counts (never credentials).
# Only the *plural* form is whitelisted — singular `token_*` names are too close to
# credential conventions (e.g. `token_value`, `token_id`) and stay redacted.
# Matches:
#   * `<prefix>_tokens[_<suffix>]` — e.g. prompt_tokens, cache_read_tokens, completion_tokens_used
#   * `tokens[_<suffix>]`          — e.g. tokens, tokens_total, tokens_used
# Auth-token names (access_token, auth_token, bearer_token, api_token, refresh_token,
# token_value, token_id, prompt_token, etc.) do NOT match and remain redacted.
TOKEN_USAGE_KEY_PATTERN = re.compile(
    r"""
    ^
    (?:
        # <prefix>_tokens[_<suffix>] — e.g. prompt_tokens, cache_read_tokens, completion_tokens_used
        (?:prompt|completion|input|output|total|cached|cache_read|cache_write)
        _tokens
        (?:_(?:total|count|used|consumed|sum|usage|delta))?
        |
        # tokens (plural bare) or tokens_<suffix> — e.g. tokens_total, tokens_used
        tokens
        (?:_(?:total|count|used|consumed|sum|usage|delta|in|out))?
    )
    $
    """,
    re.VERBOSE,
)

# Default sensitive dictionary keys that should always be redacted
DEFAULT_SENSITIVE_KEYS = {
    "password",
    "passwd",
    "pwd",
    "secret",
    "api_key",
    "apikey",
    "api-key",
    "access_token",
    "access-token",
    "token",
    "authorization",
    "auth",
    "credential",
    "credentials",
    "private_key",
    "private-key",
    "privatekey",
    "secret_key",
    "secret-key",
    "secretkey",
    "ssn",
    "social_security_number",
    "credit_card",
    "creditcard",
    "card_number",
    "cardnumber",
    "cvv",
    "cvc",
    "pin",
    "arguments",
    "tool_input",
}

# HIPAA-specific sensitive keys (added when HIPAA patterns are enabled)
HIPAA_SENSITIVE_KEYS = {
    "patient_name",
    "patient_id",
    "mrn",
    "medical_record_number",
    "diagnosis",
    "treatment",
    "medication",
    "prescription",
    "insurance_id",
    "provider_id",
    "npi",
    "dea_number",
    "health_plan",
    "beneficiary",
}

# Default regex patterns for common PII
DEFAULT_PII_PATTERNS: list[tuple[str, str]] = [
    # Credit card numbers (13-19 digits, may have spaces/dashes)
    (
        "credit_card",
        r"\b(?:\d[ -]*?){13,19}\b",
    ),
    # SSN (XXX-XX-XXXX or XXX XX XXXX or XXXXXXXXX)
    (
        "ssn",
        r"\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b",
    ),
    # API keys starting with sk- (OpenAI, Anthropic, etc.)
    (
        "api_key_sk",
        r"\bsk-[a-zA-Z0-9]{20,}\b",
    ),
    # API keys starting with pk- (Stripe public keys, but we'll redact anyway)
    (
        "api_key_pk",
        r"\bpk_[a-zA-Z0-9]{20,}\b",
    ),
    # Email addresses
    (
        "email",
        r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b",
    ),
    # AWS access keys (AKIA...)
    (
        "aws_access_key",
        r"\bAKIA[0-9A-Z]{16}\b",
    ),
    # Generic API keys/tokens (long alphanumeric strings)
    (
        "generic_token",
        r"\b[a-zA-Z0-9]{32,}\b",
    ),
]

# HIPAA-specific PII patterns (opt-in only)
HIPAA_PII_PATTERNS: list[tuple[str, str]] = [
    # Medical Record Number (MRN: 123456 or MRN#123456 or MRN-123456)
    (
        "mrn",
        r"\bMRN[:\s#-]*\d{6,10}\b",
    ),
    # National Provider Identifier (10-digit number)
    (
        "npi",
        r"\bNPI[:\s#-]*\d{10}\b",
    ),
    # DEA Number (letter + letter + 7 digits)
    (
        "dea",
        r"\b[ABCDEFabcdef][A-Za-z]\d{7}\b",
    ),
    # ICD-10 diagnosis codes (letter + 2 digits + optional decimal + up to 4 digits)
    (
        "icd_code",
        r"\bICD[:\s#-]*[A-Z]\d{2}\.?\d{0,4}\b",
    ),
    # US phone numbers
    (
        "phone_us",
        r"\b\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}\b",
    ),
]

# Pattern names that are HIPAA-specific and opt-in only
_HIPAA_PATTERN_NAMES = frozenset(p[0] for p in HIPAA_PII_PATTERNS)

# Maximum recursion depth to prevent stack overflow
MAX_RECURSION_DEPTH = 50

# Redaction engine version for integrity tracking
REDACTION_VERSION = "1"


class RedactionEngine:
    """Engine for scrubbing PII and sensitive data from traces.

    The RedactionEngine recursively traverses data structures (dicts, lists, strings)
    and applies redaction rules:
    1. Dictionary keys matching sensitive patterns -> redact entire value
    2. String values matching regex patterns -> replace with [REDACTED:<type>]

    This ensures sensitive data is never stored or hashed.
    """

    def __init__(
        self,
        custom_patterns: list[tuple[str, str]] | None = None,
        custom_sensitive_keys: list[str] | None = None,
        enabled_patterns: dict[str, bool] | None = None,
    ) -> None:
        """Initialize the redaction engine.

        Args:
            custom_patterns: List of (name, regex_pattern) tuples for custom redaction rules
            custom_sensitive_keys: Additional dictionary keys to treat as sensitive
            enabled_patterns: Dict mapping pattern names to enabled/disabled state.
                             If None, loads from environment variables.
        """
        # Build sensitive keys set
        self.sensitive_keys = DEFAULT_SENSITIVE_KEYS.copy()
        if custom_sensitive_keys:
            self.sensitive_keys.update(key.lower() for key in custom_sensitive_keys)

        # Build patterns list
        self.patterns: list[tuple[str, Pattern[str]]] = []

        # Load enabled patterns from env vars if not provided
        if enabled_patterns is None:
            enabled_patterns = self._load_pattern_config_from_env()

        # Check if any HIPAA patterns are enabled and add HIPAA sensitive keys
        if any(enabled_patterns.get(name, False) for name in _HIPAA_PATTERN_NAMES):
            self.sensitive_keys.update(HIPAA_SENSITIVE_KEYS)

        # Compile default patterns (filtered by enabled_patterns)
        all_patterns = DEFAULT_PII_PATTERNS + HIPAA_PII_PATTERNS
        for pattern_name, pattern_regex in all_patterns:
            # Default patterns are on by default; HIPAA patterns are off by default
            default_enabled = pattern_name not in _HIPAA_PATTERN_NAMES
            if enabled_patterns.get(pattern_name, default_enabled):
                try:
                    compiled = re.compile(pattern_regex, re.IGNORECASE)
                    self.patterns.append((pattern_name, compiled))
                except re.error as e:
                    logger.warning(
                        "Failed to compile pattern",
                        pattern_name=pattern_name,
                        error=str(e),
                    )

        # Add custom patterns
        if custom_patterns:
            for pattern_name, pattern_regex in custom_patterns:
                try:
                    compiled = re.compile(pattern_regex, re.IGNORECASE)
                    self.patterns.append((pattern_name, compiled))
                except re.error as e:
                    logger.warning(
                        "Failed to compile custom pattern",
                        pattern_name=pattern_name,
                        error=str(e),
                    )

        logger.debug(
            "RedactionEngine initialized",
            pattern_count=len(self.patterns),
            sensitive_key_count=len(self.sensitive_keys),
        )

        self.version = REDACTION_VERSION

    @staticmethod
    def _load_pattern_config_from_env() -> dict[str, bool]:
        """Load pattern enable/disable configuration from environment variables.

        Environment variables follow the pattern: SPOOLED_REDACT_<PATTERN_NAME>=true/false
        Pattern names are converted to uppercase and hyphens become underscores.

        SPOOLED_HIPAA_MODE=true enables all HIPAA-specific patterns at once.
        Individual SPOOLED_REDACT_<name> overrides still apply on top.

        Returns:
            Dictionary mapping pattern names to enabled state
        """
        config: dict[str, bool] = {}

        # Check HIPAA mode toggle
        hipaa_mode = os.getenv("SPOOLED_HIPAA_MODE", "false").lower() in (
            "true",
            "1",
            "yes",
            "on",
        )

        # Check each default pattern (enabled by default)
        for pattern_name, _ in DEFAULT_PII_PATTERNS:
            env_var_name = f"SPOOLED_REDACT_{pattern_name.upper().replace('-', '_')}"
            env_value = os.getenv(env_var_name, "true").lower()
            config[pattern_name] = env_value in ("true", "1", "yes", "on")

        # Check each HIPAA pattern (disabled by default unless HIPAA mode)
        for pattern_name, _ in HIPAA_PII_PATTERNS:
            env_var_name = f"SPOOLED_REDACT_{pattern_name.upper().replace('-', '_')}"
            default = "true" if hipaa_mode else "false"
            env_value = os.getenv(env_var_name, default).lower()
            config[pattern_name] = env_value in ("true", "1", "yes", "on")

        return config

    def scrub(self, data: Any, depth: int = 0) -> Any:
        """Recursively scrub sensitive data from the input.

        This method traverses dictionaries, lists, and strings, applying redaction
        rules at each level. It handles nested structures safely with a depth limit.

        Args:
            data: The data to scrub (can be dict, list, str, or any other type)
            depth: Current recursion depth (used to prevent stack overflow)

        Returns:
            Scrubbed version of the data with sensitive values replaced
        """
        # Safety check: prevent infinite recursion
        if depth > MAX_RECURSION_DEPTH:
            logger.warning("Maximum recursion depth reached, returning data as-is")
            return data

        # Handle dictionaries
        if isinstance(data, dict):
            scrubbed: dict[str, Any] = {}
            for key, value in data.items():
                key_lower = str(key).lower()
                # Never redact LLM token-usage fields (counts, not credentials)
                if TOKEN_USAGE_KEY_PATTERN.match(key_lower):
                    scrubbed[key] = self.scrub(value, depth=depth + 1)
                # Check if key itself is sensitive (credentials, PII, etc.)
                elif any(sensitive in key_lower for sensitive in self.sensitive_keys):
                    scrubbed[key] = "[REDACTED:sensitive_key]"
                else:
                    scrubbed[key] = self.scrub(value, depth=depth + 1)
            return scrubbed

        # Handle lists and tuples
        if isinstance(data, (list, tuple)):
            scrubbed_list = [self.scrub(item, depth=depth + 1) for item in data]
            # Preserve tuple type if input was a tuple
            return tuple(scrubbed_list) if isinstance(data, tuple) else scrubbed_list

        # Handle strings
        if isinstance(data, str):
            return self._scrub_string(data)

        # For all other types (int, float, bool, None, etc.), return as-is
        return data

    def _scrub_string(self, text: str) -> str:
        """Scrub a string value by applying all regex patterns.

        Args:
            text: The string to scrub

        Returns:
            String with matched patterns replaced by [REDACTED:<type>]
        """
        result = text
        for pattern_name, pattern in self.patterns:
            # Replace all matches with redaction marker
            result = pattern.sub(f"[REDACTED:{pattern_name}]", result)

        return result
