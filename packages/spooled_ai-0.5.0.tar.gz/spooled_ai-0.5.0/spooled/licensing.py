"""License checking for Spooled (Task 11.2).

Checks SPOOLED_API_KEY against the backend to determine plan tier.
Caches validation results for 24 hours to minimize network calls.
Degrades gracefully on network failure (falls back to free tier).
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

import structlog

logger = structlog.get_logger(__name__)

# Cache duration: 24 hours
_CACHE_TTL_SECONDS = 86400


def _get_cache_file() -> Path:
    """Get the license cache file path."""
    traces_dir = os.getenv("SPOOLED_TRACES_DIR", ".spooled/traces")
    base_dir = Path(traces_dir).parent
    return base_dir / "license_cache.json"


def _get_backend_url() -> str:
    """Get the backend URL for license validation.

    Treats empty string as unset so the action's `SPOOLED_BACKEND_URL: ''`
    (which disables trace sync) doesn't break license validation.
    """
    url = os.getenv("SPOOLED_BACKEND_URL", "").strip()
    return url or "https://api.spooled.ai"


class LicenseChecker:
    """Checks and caches API key license status.

    License response structure:
    {
        "valid": true,
        "plan": "pro",
        "org_id": "org-123",
        "limits": {
            "traces_per_month": null,  # null = unlimited
            "agents": null,
            "comparisons_per_month": null
        }
    }
    """

    def __init__(
        self,
        api_key: str | None = None,
        cache_file: Path | None = None,
    ) -> None:
        self.api_key = api_key or os.getenv("SPOOLED_API_KEY")
        self._cache_file = cache_file or _get_cache_file()
        self._cached_result: dict[str, Any] | None = None

    def check(self) -> dict[str, Any]:
        """Check the license status.

        Returns:
            License info dict with 'valid', 'plan', 'limits' keys.
            Returns free tier defaults if no API key or on network failure.
        """
        if not self.api_key:
            return self._free_tier_result()

        # Check cache first
        cached = self._load_cache()
        if cached is not None:
            return cached

        # Validate against backend
        result = self._validate_remote()
        if result is not None:
            self._save_cache(result)
            return result

        # Network failure: degrade gracefully to free tier
        logger.debug("License validation failed, falling back to free tier")
        return self._free_tier_result()

    def _free_tier_result(self) -> dict[str, Any]:
        """Return free tier license info."""
        from spooled.usage import FREE_TIER_LIMITS

        return {
            "valid": True,
            "plan": "free",
            "org_id": None,
            "limits": FREE_TIER_LIMITS,
        }

    def _load_cache(self) -> dict[str, Any] | None:
        """Load cached license result if still valid."""
        if self._cached_result is not None:
            if time.time() - self._cached_result.get("_cached_at", 0) < _CACHE_TTL_SECONDS:
                return {k: v for k, v in self._cached_result.items() if not k.startswith("_")}

        if not self._cache_file.exists():
            return None

        try:
            with open(self._cache_file) as f:
                data = json.load(f)

            cached_at = data.get("_cached_at", 0)
            cached_key = data.get("_api_key_hash", "")

            # Check TTL and key match
            if time.time() - cached_at >= _CACHE_TTL_SECONDS:
                return None

            if cached_key != self._hash_key():
                return None

            self._cached_result = data
            return {k: v for k, v in data.items() if not k.startswith("_")}

        except (json.JSONDecodeError, OSError):
            return None

    def _save_cache(self, result: dict[str, Any]) -> None:
        """Save license result to cache."""
        cache_data = {
            **result,
            "_cached_at": time.time(),
            "_api_key_hash": self._hash_key(),
        }
        self._cached_result = cache_data

        try:
            self._cache_file.parent.mkdir(parents=True, exist_ok=True)
            tmp = self._cache_file.with_suffix(".tmp")
            with open(tmp, "w") as f:
                json.dump(cache_data, f)
            os.replace(str(tmp), str(self._cache_file))
        except OSError:
            pass  # Cache save failure is not critical

    def _hash_key(self) -> str:
        """Hash the API key for cache matching."""
        import hashlib

        return hashlib.sha256((self.api_key or "").encode()).hexdigest()[:16]

    def _validate_remote(self) -> dict[str, Any] | None:
        """Validate the API key against the backend.

        Uses header-based auth (x-api-key) to avoid leaking credentials
        in POST body logs (proxies, WAFs, load balancers).
        """
        headers = {"x-api-key": self.api_key} if self.api_key else {}
        try:
            import httpx

            url = f"{_get_backend_url()}/api/license/validate"
            response = httpx.post(
                url,
                json={},
                headers=headers,
                timeout=10.0,
            )

            if response.status_code == 200:
                return response.json()

            logger.debug(
                "License validation returned error",
                status=response.status_code,
            )
            return None

        except ImportError:
            # httpx not installed, try requests
            try:
                import requests

                url = f"{_get_backend_url()}/api/license/validate"
                response = requests.post(
                    url,
                    json={},
                    headers=headers,
                    timeout=10.0,
                )

                if response.status_code == 200:
                    return response.json()

                return None
            except Exception:
                return None

        except Exception:
            return None

    def is_paid(self) -> bool:
        """Check if the current license is a paid plan."""
        result = self.check()
        return result.get("plan", "free") != "free"

    def get_limits(self) -> dict[str, int] | None:
        """Get the usage limits for the current plan.

        Returns None for unlimited (paid plans).
        """
        result = self.check()
        limits = result.get("limits")
        if limits is None:
            return None

        # Check if all limits are None (unlimited)
        if all(v is None for v in limits.values()):
            return None

        return {k: v for k, v in limits.items() if v is not None}


def check_license_for_ci() -> dict[str, Any]:
    """Convenience function for CI commands to check license.

    Returns:
        Dict with 'allowed' (bool), 'message' (str), and 'plan' (str).
    """
    from spooled.usage import UsageTracker

    checker = LicenseChecker()
    license_info = checker.check()

    if checker.is_paid():
        return {
            "allowed": True,
            "message": f"Licensed: {license_info.get('plan', 'pro')} plan",
            "plan": license_info.get("plan", "pro"),
        }

    # Free tier: check usage limits
    tracker = UsageTracker()
    limit_check = tracker.check_limits(license_info.get("limits"))

    if limit_check["within_limits"]:
        return {
            "allowed": True,
            "message": "Free tier",
            "plan": "free",
            "usage": tracker.get_current_usage(),
        }

    # Over limit
    over_limits = [name for name, check in limit_check["checks"].items() if not check["ok"]]
    return {
        "allowed": False,
        "message": (
            f"Free tier limit exceeded ({', '.join(over_limits)}). "
            "Upgrade at https://spooled.ai/#pricing"
        ),
        "plan": "free",
        "usage": tracker.get_current_usage(),
    }
