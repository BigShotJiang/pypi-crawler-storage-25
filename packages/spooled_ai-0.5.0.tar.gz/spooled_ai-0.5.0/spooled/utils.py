"""Utility functions for metadata collection and backend access."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
import sys

import structlog

logger = structlog.get_logger(__name__)

# Env vars whose *presence* (set vs unset) we fingerprint — not their values.
_WATCHED_ENV_VARS = frozenset(
    {
        "OPENAI_API_KEY",
        "ANTHROPIC_API_KEY",
        "SPOOLED_API_KEY",
        "OPENAI_API_BASE",
        "OPENAI_BASE_URL",
        "ANTHROPIC_BASE_URL",
        "SPOOLED_BACKEND_URL",
        "SPOOLED_MODEL_VERSION",
        "SPOOLED_AGENT_ID",
    }
)


def get_git_hash() -> str | None:
    """Get the current git commit hash.

    Returns:
        Git commit hash, or None if not in a git repository
    """
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            check=True,
            timeout=5,
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        return None


def get_git_branch() -> str | None:
    """Get the current git branch name.

    Returns:
        Git branch name, or None if not in a git repository
    """
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            check=True,
            timeout=5,
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        return None


def get_env_fingerprint() -> str:
    """Compute a stable fingerprint of the execution environment.

    Hashes Python version, platform, and the *presence* (not values) of
    known AI/Spooled environment variables. Secrets are never included.

    Returns:
        16-char hex digest identifying this environment configuration
    """
    state: dict = {
        "python_version": sys.version.split()[0],
        "platform": f"{platform.system()}/{platform.machine()}",
    }
    for var in sorted(_WATCHED_ENV_VARS):
        state[var] = "<set>" if os.environ.get(var) else "<unset>"
    digest = hashlib.sha256(json.dumps(state, sort_keys=True).encode()).hexdigest()
    return digest[:16]


def get_code_reference() -> dict[str, str | None]:
    """Get code reference metadata (git hash, branch, model version, env fingerprint).

    Returns:
        Dictionary with git_hash, git_branch, model_version, env_fingerprint keys
    """
    return {
        "git_hash": get_git_hash(),
        "git_branch": get_git_branch(),
        "model_version": os.getenv("SPOOLED_MODEL_VERSION"),
        "env_fingerprint": get_env_fingerprint(),
    }


def sanitize_agent_id(agent_id: str) -> str:
    """Sanitize agent_id to prevent path traversal."""
    import re

    sanitized = re.sub(r"[/\\.\x00]", "_", agent_id)
    sanitized = sanitized.strip("_").strip()
    if not sanitized:
        sanitized = "unknown_agent"
    return sanitized[:256]


def get_auth_headers() -> dict[str, str]:
    """Get auth headers for backend requests.

    Uses SPOOLED_API_KEY if set. Returns an empty dict if not configured.
    """
    api_key = os.getenv("SPOOLED_API_KEY")
    if not api_key:
        return {}
    return {"X-Api-Key": api_key}
