"""Main recorder class for capturing agent execution traces."""

from __future__ import annotations

import asyncio
import functools
import hashlib
import json
import os
import platform
import random
import sys
import threading
import time
import uuid
from collections import deque
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse

import structlog
from dotenv import load_dotenv

from spooled import metrics as _metrics
from spooled.circuit_breaker import CircuitBreaker
from spooled.models import Interaction, InteractionType, Trace, TraceStatus
from spooled.redaction import RedactionEngine
from spooled.storage import save_interactions_locally, save_trace_locally
from spooled.utils import get_auth_headers, get_code_reference

# load_dotenv() moved into init()/start_trace() — importing spooled
# should not have side effects. See _ensure_dotenv_loaded() below.

logger = structlog.get_logger(__name__)


class Recorder:
    """Records agent execution traces and ships them to the backend.

    The recorder intercepts I/O operations (OpenAI calls, HTTP requests) and
    captures them in a buffer. A background thread flushes the buffer to the
    backend API asynchronously to avoid impacting agent performance.
    """

    def __init__(
        self,
        agent_id: str,
        backend_url: str | None = None,
        buffer_size: int = 100,
        flush_interval: float = 5.0,
        session_id: str | None = None,
        parent_run_id: str | None = None,
        correlation_context: dict[str, str] | None = None,
        sample_rate: float | None = None,
        tags: list[str] | None = None,
        fingerprint_mode: str | None = None,
        exporters: list[Any] | None = None,
    ) -> None:
        """Initialize the recorder.

        Args:
            agent_id: User-defined identifier for the agent
            backend_url: Backend API URL (defaults to env var SPOOLED_BACKEND_URL)
            buffer_size: Maximum number of interactions before forced flush
            flush_interval: Seconds between automatic flushes
            session_id: Correlation ID for multi-agent sessions
            parent_run_id: run_id of the parent trace that spawned this one
            correlation_context: Serializable dict with session_id, parent_run_id, depth
            sample_rate: Fraction of runs to record (0.0–1.0). Defaults to
                         SPOOLED_SAMPLE_RATE env var, or 1.0 (record all).
            tags: User-defined tags for fleet grouping (e.g., ["payments", "v2"]).
                  Defaults to SPOOLED_AGENT_TAGS env var (comma-separated).
            fingerprint_mode: Hash mode for fingerprinting: "structural" (default,
                  order-insensitive, good for ReAct loops) or "sequence"
                  (order-sensitive). Defaults to SPOOLED_FINGERPRINT_MODE env var,
                  or "structural".
            exporters: Optional list of exporter instances (e.g., SpooledOTELExporter).
                  Each exporter receives callbacks on interaction recording and trace end.
        """
        # Sanitize agent_id for safe use in file paths (baselines/{agent_id}.json)
        self.agent_id = agent_id.replace("/", "_").replace("\\", "_").replace("..", "_")
        self.backend_url = (backend_url or os.getenv("SPOOLED_BACKEND_URL", "")).rstrip("/")
        if self.backend_url and not self.backend_url.startswith("https://"):
            if self.backend_url.startswith("http://localhost") or self.backend_url.startswith(
                "http://127.0.0.1"
            ):
                logger.debug("Backend URL uses HTTP (localhost — OK for development)")
            else:
                logger.warning(
                    "Backend URL does not use HTTPS — data will be transmitted unencrypted",
                    backend_url=self.backend_url,
                )
        self.buffer_size = buffer_size
        self.flush_interval = flush_interval

        # Resolve tags: explicit arg > SPOOLED_AGENT_TAGS env var > empty
        if tags is not None:
            self.tags: list[str] = list(tags)
        else:
            env_tags = os.getenv("SPOOLED_AGENT_TAGS", "").strip()
            self.tags = [t.strip() for t in env_tags.split(",") if t.strip()] if env_tags else []

        # Resolve fingerprint_mode: explicit arg > SPOOLED_FINGERPRINT_MODE env var > "structural"
        self.fingerprint_mode: str = (
            fingerprint_mode or os.getenv("SPOOLED_FINGERPRINT_MODE", "").strip() or "structural"
        )

        # Resolve correlation context: explicit kwargs > correlation_context dict > env var
        ctx = correlation_context or {}
        if not ctx:
            env_ctx = os.getenv("SPOOLED_CORRELATION_CONTEXT")
            if env_ctx:
                try:
                    ctx = json.loads(env_ctx)
                except json.JSONDecodeError:
                    pass

        self.session_id: str | None = session_id or ctx.get("session_id")
        self.parent_run_id: str | None = parent_run_id or ctx.get("parent_run_id")
        self._depth: int = int(ctx.get("depth", 0))
        if self.parent_run_id and self._depth == 0:
            self._depth = 1

        # Resolve sample_rate: explicit arg > SPOOLED_SAMPLE_RATE env var > 1.0 (record all)
        if sample_rate is None:
            env_val = os.getenv("SPOOLED_SAMPLE_RATE", "").strip()
            sample_rate = float(env_val) if env_val else 1.0
        self.sample_rate: float = max(0.0, min(1.0, sample_rate))
        # Roll the dice once per run — this recorder either records or it doesn't
        self._sampled: bool = random.random() < self.sample_rate

        # Initialize redaction engine (always enabled for privacy firewall)
        self.redactor = RedactionEngine()

        self.run_id: str = str(uuid.uuid4())
        self.status = TraceStatus.RUNNING
        self.interactions: deque[Interaction] = deque(maxlen=buffer_size * 2)
        self.buffer: deque[dict[str, Any]] = deque()
        self._tool_call_index: dict[str, Interaction] = {}
        self.sequence = 0
        self.start_time = datetime.now(timezone.utc)
        # Track the previous interaction's signature for hash chaining
        self._prev_interaction_signature: str | None = None
        # Store chain_hash for trace
        self._chain_hash: str | None = None
        # Structural fingerprint hash for baseline lookup (set on stop())
        self._fingerprint_hash: str | None = None

        # Environment metadata with code reference
        code_ref = get_code_reference()
        self.environment = {
            "os": platform.system(),
            "python_version": sys.version.split()[0],
            "platform": platform.platform(),
            **code_ref,
        }

        # Local storage path
        self.local_storage_enabled = os.getenv("SPOOLED_LOCAL_STORAGE", "true").lower() == "true"

        # Circuit breaker for backend HTTP calls
        self._circuit_breaker = CircuitBreaker()

        # External exporters (e.g., OTEL)
        self._exporters: list[Any] = list(exporters) if exporters else []

        # Background thread for flushing
        self._flush_thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        # RLock (reentrant) prevents deadlock when record_interaction holds the lock
        # and then calls _flush_buffer (which also acquires the lock) on buffer-full.
        self._lock = threading.RLock()

        auth_headers = get_auth_headers()
        logger.info(
            "Recorder initialized",
            agent_id=self.agent_id,
            run_id=self.run_id,
            backend_url=self.backend_url,
            backend_auth_configured=bool(auth_headers),
        )

    # Keys in input/output dicts that carry structural metadata (safe to keep)
    _STRUCTURAL_KEYS = frozenset(
        {
            # Input keys
            "model",
            "function",
            "tool",
            "url",
            "method",
            "name",
            "call_id",
            "temperature",
            "max_tokens",
            "stream",
            # Output keys
            "usage",
            "tool_calls",
            "finish_reason",
            "stop_reason",
            "prompt_tokens",
            "completion_tokens",
            "total_tokens",
            "input_tokens",
            "output_tokens",
            # Shape keys (already hashed/structural)
            "output_keys",
            "output_types",
            "content_length",
            "redacted",
            "payload_hash",
            "content_hash",
        }
    )

    @staticmethod
    def _strip_to_structural(data: Any, payload_hash: str) -> Any:
        """Strip non-structural content from input/output data.

        Keeps only structural metadata keys (model, function, tool names, usage
        counts, etc.) and replaces everything else with a hash marker.
        This is the recorder-level defense-in-depth for structure-only mode.
        """
        if data is None:
            return None
        if not isinstance(data, dict):
            return {"redacted": True, "payload_hash": payload_hash}

        result: dict[str, Any] = {}
        for key, value in data.items():
            if key in Recorder._STRUCTURAL_KEYS:
                result[key] = value
            elif key == "messages":
                # Preserve message count and roles only
                if isinstance(value, list):
                    result["message_count"] = len(value)
                    result["message_roles"] = [
                        m.get("role", "unknown") if isinstance(m, dict) else "unknown"
                        for m in value
                    ]
                else:
                    result[key] = {"redacted": True, "payload_hash": payload_hash}
            else:
                # Non-structural key — drop it
                pass
        result["payload_hash"] = payload_hash
        return result

    @staticmethod
    def _strip_content_for_backend(interaction: dict[str, Any]) -> dict[str, Any]:
        """Strip content fields from an interaction for structural-mode backend push.

        Replaces input, output, and error with a redacted marker and the original
        payload_hash. Preserves all structural/metadata fields.

        Args:
            interaction: Interaction dict (from model_dump)

        Returns:
            New dict with content stripped
        """
        stripped = dict(interaction)
        payload_hash = stripped.get("payload_hash", "")

        for field in ("input", "output", "error"):
            if stripped.get(field) is not None:
                stripped[field] = {"redacted": True, "payload_hash": payload_hash}

        return stripped

    def is_backend_url(self, url: str) -> bool:
        """Return True if url points at the Spooled backend (so we skip recording it).

        HTTP calls to the backend (e.g. POST interactions, PUT chain_hash) are
        housekeeping; users care about agent behavior, not these internal calls.
        """
        if not (self.backend_url and self.backend_url.strip()):
            return False
        try:
            base = urlparse(self.backend_url.strip().rstrip("/"))
            req = urlparse(str(url).strip())
            if not base.scheme or not base.netloc or not req.scheme or not req.netloc:
                return False
            return (
                base.scheme.lower() == req.scheme.lower()
                and base.netloc.lower() == req.netloc.lower()
            )
        except Exception:
            return False

    def __enter__(self) -> Recorder:
        """Context manager entry — starts the recorder."""
        self.start()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Context manager exit — stops with FAILURE on exception, SUCCESS otherwise."""
        status = TraceStatus.FAILURE if exc_type else TraceStatus.SUCCESS
        self.stop(status)

    def start(self) -> None:
        """Start the recorder and begin capturing traces."""
        if self._flush_thread is not None:
            logger.warning("Recorder already started")
            return

        self.status = TraceStatus.RUNNING
        self.start_time = datetime.now(timezone.utc)
        self._stop_event.clear()

        if not self._sampled:
            logger.info(
                "Recorder started (not sampled — recording skipped)",
                run_id=self.run_id,
                agent_id=self.agent_id,
                sample_rate=self.sample_rate,
            )
            return

        _metrics.inc_traces(self.agent_id, status="started")

        self._flush_thread = threading.Thread(target=self._flush_loop, daemon=True)
        self._flush_thread.start()

        # Save initial trace metadata to local storage
        if self.local_storage_enabled:
            try:
                trace = self.get_trace()
                # Use mode='json' to get JSON-serializable data
                save_trace_locally(trace.model_dump(mode="json"), self.run_id)
            except Exception as e:
                logger.warning("Failed to save trace locally", error=str(e))

        logger.info("Recorder started", run_id=self.run_id)

    @staticmethod
    def _calculate_payload_hash(
        input_data: dict[str, Any],
        output_data: dict[str, Any] | None,
        error: str | None,
        metadata: dict[str, Any],
    ) -> str:
        """Calculate SHA-256 hash of the interaction payload.

        Args:
            input_data: Input data
            output_data: Output data
            error: Error message if any
            metadata: Additional metadata

        Returns:
            SHA-256 hex digest of the canonical payload
        """
        # Create canonical representation: sorted JSON for deterministic hashing
        payload = {
            "input": input_data,
            "output": output_data,
            "error": error,
            "metadata": metadata,
        }
        payload_json = json.dumps(payload, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(payload_json.encode("utf-8")).hexdigest()

    @staticmethod
    def _calculate_redaction_hash(
        input_data: dict[str, Any],
        output_data: dict[str, Any] | None,
        error: str | None,
    ) -> str:
        """Calculate SHA-256 hash of redacted payload content."""
        payload = {
            "input": input_data,
            "output": output_data,
            "error": error,
        }
        payload_json = json.dumps(payload, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(payload_json.encode("utf-8")).hexdigest()

    @staticmethod
    def _calculate_interaction_signature(
        interaction_id: str,
        sequence: int,
        interaction_type: InteractionType,
        payload_hash: str,
        prev_hash: str | None,
    ) -> str:
        """Calculate the signature of an interaction for hash chaining.

        The signature is used to link interactions in the chain.

        Args:
            interaction_id: Unique interaction ID
            sequence: Sequence number
            interaction_type: Type of interaction
            payload_hash: Hash of the payload
            prev_hash: Hash of previous interaction's signature

        Returns:
            SHA-256 hex digest of the interaction signature
        """
        signature_data = {
            "interaction_id": interaction_id,
            "sequence": sequence,
            "interaction_type": (
                interaction_type.value
                if hasattr(interaction_type, "value")
                else str(interaction_type)
            ),
            "payload_hash": payload_hash,
            "prev_hash": prev_hash or "",
        }
        signature_json = json.dumps(signature_data, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(signature_json.encode("utf-8")).hexdigest()

    def stop(self, status: TraceStatus = TraceStatus.SUCCESS) -> None:
        """Stop the recorder and flush remaining data.

        Args:
            status: Final status of the trace (SUCCESS or FAILURE)
        """
        self.status = status
        self._stop_event.set()

        if not self._sampled:
            logger.debug("Recorder stopped (not sampled)", run_id=self.run_id)
            return

        if self._flush_thread is not None:
            self._flush_thread.join(timeout=10.0)

        # Final flush
        self._flush_buffer()

        # Set chain_hash from the final interaction's signature
        # _prev_interaction_signature is already the signature of the last interaction
        with self._lock:
            self._chain_hash = self._prev_interaction_signature

        # Calculate structural fingerprint for baseline lookup (local-first, deterministic)
        try:
            from spooled.fingerprint import calculate_fingerprint_hash

            # If the deque hit its maxlen, interactions were evicted.
            # Read the full set from disk for an accurate fingerprint.
            all_interactions = list(self.interactions)
            if (
                self.interactions.maxlen is not None
                and self.sequence > self.interactions.maxlen
                and self.local_storage_enabled
            ):
                try:
                    from spooled.storage import get_trace_directory, load_trace_from_jsonl

                    trace_file = get_trace_directory() / f"{self.run_id}.jsonl"
                    if trace_file.exists():
                        trace_data = load_trace_from_jsonl(trace_file)
                        all_interactions = trace_data.get("interactions", all_interactions)
                except Exception:
                    pass  # Fall back to in-memory interactions

            self._fingerprint_hash = calculate_fingerprint_hash(
                all_interactions, mode=self.fingerprint_mode
            )
        except Exception as e:
            logger.debug("Failed to compute fingerprint_hash", error=str(e))

        trace = self.get_trace()

        # Notify exporters of trace end (never let failures break shutdown)
        for exporter in self._exporters:
            try:
                exporter.on_trace_end(trace)
            except Exception as e:
                logger.debug("Exporter on_trace_end failed", error=str(e))

        # Save final trace with chain_hash and fingerprint_hash
        if self.local_storage_enabled:
            try:
                save_trace_locally(trace.model_dump(mode="json"), self.run_id)
                from spooled.storage import get_trace_directory

                trace_path = get_trace_directory() / f"{self.run_id}.jsonl"
                logger.info(
                    "Trace saved",
                    path=str(trace_path),
                    agent_id=self.agent_id,
                    hint="Run 'spooled diff' to inspect behavior",
                )
            except Exception as e:
                logger.warning("Failed to save final trace locally", error=str(e))

        # Send chain_hash, fingerprint_hash, and full trace metadata to backend if available
        if self._chain_hash:
            try:
                trace_payload = trace.model_dump(mode="json")
                self._post_chain_hash_to_backend(
                    self._chain_hash,
                    fingerprint_hash=self._fingerprint_hash,
                    trace_payload=trace_payload,
                )
            except Exception as e:
                logger.warning("Failed to send chain_hash to backend", error=str(e))

        # Add to baseline if successful (Phase 2)
        if status == TraceStatus.SUCCESS and self.local_storage_enabled:
            try:
                from spooled.baseline import BaselineManager

                manager = BaselineManager(self.agent_id)
                trace_data = {
                    "trace": trace.model_dump(mode="json"),
                    "interactions": [i.model_dump(mode="json") for i in self.interactions],
                }
                manager.add_to_baseline(trace_data, status.value)
            except Exception as e:
                logger.debug("Failed to add to baseline", error=str(e))

        # Record usage for free tier enforcement
        try:
            from spooled.usage import UsageTracker

            tracker = UsageTracker()
            tracker.record_trace(self.agent_id)
        except Exception:
            pass  # Never block on usage tracking

        logger.info(
            "Recorder stopped",
            run_id=self.run_id,
            status=status,
            chain_hash=self._chain_hash[:8] + "..." if self._chain_hash else None,
        )

    def record_parallel_group(self) -> str:
        """Generate a new parallel_group ID for concurrent interactions.

        All interactions recorded with this group ID will be treated as
        unordered for fingerprinting purposes.

        Returns:
            A new parallel_group ID string
        """
        return str(uuid.uuid4())

    def record_interaction(
        self,
        interaction_type: InteractionType,
        input_data: dict[str, Any],
        output_data: dict[str, Any] | None = None,
        error: str | None = None,
        metadata: dict[str, Any] | None = None,
        parallel_group: str | None = None,
    ) -> Interaction:
        """Record a single interaction (LLM call, tool call, etc.).

        Implements hash chaining: each interaction links to the previous one via prev_hash,
        creating an immutable evidence chain.

        Args:
            interaction_type: Type of interaction
            input_data: Input data (prompt, function name, URL, etc.)
            output_data: Output data (response, result, status code)
            error: Error message if the interaction failed
            metadata: Additional context (latency, tokens, etc.)

        Returns:
            The created Interaction object with populated hash fields
        """
        # Fast no-op path when this run was not selected by sample_rate
        if not self._sampled:
            return Interaction(
                interaction_id="",
                run_id=self.run_id,
                sequence=0,
                interaction_type=interaction_type,
                timestamp=datetime.now(timezone.utc),
                input={},
            )

        with self._lock:
            interaction_id = str(uuid.uuid4())
            metadata_dict = metadata or {}

            # Privacy Firewall: Scrub PII BEFORE calculating hash or storing
            # This ensures we never hash or store raw secrets
            scrubbed_input = self.redactor.scrub(input_data)
            scrubbed_output = self.redactor.scrub(output_data) if output_data is not None else None
            scrubbed_error = self.redactor.scrub(error) if error is not None else None
            scrubbed_metadata = self.redactor.scrub(metadata_dict)
            if not isinstance(scrubbed_metadata, dict):
                scrubbed_metadata = {}

            redaction_hash = self._calculate_redaction_hash(
                input_data=scrubbed_input,
                output_data=scrubbed_output,
                error=scrubbed_error,
            )
            scrubbed_metadata["redaction"] = {
                "applied": True,
                "version": getattr(self.redactor, "version", "1"),
                "hash": redaction_hash,
            }

            # Calculate payload hash using SCRUBBED data
            # This ensures the hash is based on sanitized content, not raw secrets
            payload_hash = self._calculate_payload_hash(
                input_data=scrubbed_input,
                output_data=scrubbed_output,
                error=scrubbed_error,
                metadata=scrubbed_metadata,
            )

            # Get previous hash (None for first interaction)
            prev_hash = self._prev_interaction_signature

            # Extract output key names (schema shape) from TOOL_CALL outputs
            # BEFORE stripping. Key names are structural metadata, not content.
            if (
                interaction_type == InteractionType.TOOL_CALL
                and scrubbed_output is not None
                and isinstance(scrubbed_output, dict)
            ):
                # Keys to skip: SDK metadata + structural keys added by stripping
                _skip_keys = frozenset(
                    {
                        "output_keys",
                        "output_types",
                        "content_length",
                        "payload_hash",
                        "redacted",
                        "content_hash",
                    }
                )
                # Extract output key names (for schema drift)
                if "output_keys" not in scrubbed_output:
                    out_keys = [k for k in scrubbed_output.keys() if k not in _skip_keys]
                    if out_keys:
                        scrubbed_output["output_keys"] = sorted(out_keys)

                # Decision values and score values extraction removed (content-blind).
                # Structural signals (tool graph, timing, token counts) are the
                # only data extracted — this is by design, not a TODO.

            # Structure-only by architecture: strip content from input/output
            # unconditionally. Hooks already hash content, but this catches
            # manual record_interaction() calls too. Content never reaches
            # local JSONL or backend — this is not a toggle.
            scrubbed_input = self._strip_to_structural(scrubbed_input, payload_hash)
            scrubbed_output = (
                self._strip_to_structural(scrubbed_output, payload_hash)
                if scrubbed_output is not None
                else None
            )
            if scrubbed_error is not None:
                scrubbed_error = None  # errors may contain content

            redacted_input = scrubbed_input
            redacted_output = scrubbed_output

            # Compute structural_hash from the saved (post-strip) data so verify
            # can detect post-save tampering without needing the pre-strip content.
            structural_payload = {
                "input": {k: v for k, v in (redacted_input or {}).items() if k != "payload_hash"},
                "output": (
                    {k: v for k, v in (redacted_output or {}).items() if k != "payload_hash"}
                    if redacted_output
                    else None
                ),
                "interaction_type": (
                    interaction_type.value
                    if hasattr(interaction_type, "value")
                    else str(interaction_type)
                ),
            }
            structural_json = json.dumps(structural_payload, sort_keys=True, ensure_ascii=False)
            structural_hash = hashlib.sha256(structural_json.encode("utf-8")).hexdigest()

            interaction = Interaction(
                interaction_id=interaction_id,
                run_id=self.run_id,
                sequence=self.sequence,
                interaction_type=interaction_type,
                timestamp=datetime.now(timezone.utc),
                input=redacted_input,
                output=redacted_output,
                error=scrubbed_error,
                metadata=scrubbed_metadata,
                prev_hash=prev_hash,
                payload_hash=payload_hash,
                structural_hash=structural_hash,
                parallel_group=parallel_group,
            )

            # Calculate this interaction's signature for the next link in the chain
            interaction_signature = self._calculate_interaction_signature(
                interaction_id=interaction_id,
                sequence=self.sequence,
                interaction_type=interaction_type,
                payload_hash=payload_hash,
                prev_hash=prev_hash,
            )
            self._prev_interaction_signature = interaction_signature

            self.sequence += 1
            self.interactions.append(interaction)

            # Index TOOL_CALL interactions by call_id for later result enrichment
            if interaction_type == InteractionType.TOOL_CALL:
                call_id = (input_data or {}).get("call_id")
                if call_id:
                    self._tool_call_index[call_id] = interaction

            # Use mode='json' to get JSON-serializable data (converts datetime to strings)
            self.buffer.append(interaction.model_dump(mode="json"))

            # Force flush if buffer is full
            if len(self.buffer) >= self.buffer_size:
                self._flush_buffer()

        _metrics.inc_interactions(
            self.agent_id,
            interaction_type.value if hasattr(interaction_type, "value") else str(interaction_type),
        )

        # Notify exporters (never let export failures break recording)
        if self._exporters:
            trace_ctx = {
                "run_id": self.run_id,
                "agent_id": self.agent_id,
                "session_id": self.session_id,
            }
            for exporter in self._exporters:
                try:
                    exporter.on_interaction(interaction, trace_ctx)
                except Exception as e:
                    logger.debug("Exporter on_interaction failed", error=str(e))

        logger.debug(
            "Interaction recorded",
            interaction_type=interaction_type,
            sequence=interaction.sequence,
            payload_hash=payload_hash[:8] + "...",
        )

        return interaction

    def enrich_tool_result(self, call_id: str, output_shape: dict[str, Any]) -> None:
        """Enrich a previously recorded TOOL_CALL with its output shape.

        Called by hooks when they see tool results in subsequent LLM call messages.
        Thread-safe: enrichment happens inside self._lock.

        Args:
            call_id: The tool_call_id linking this result to the original TOOL_CALL
            output_shape: Structural shape dict (output_keys, output_types, content_length)
        """
        with self._lock:
            interaction = self._tool_call_index.get(call_id)
            if interaction is None:
                return
            if interaction.output is None:
                interaction.output = output_shape
            else:
                # Merge shape into existing output without overwriting
                interaction.output.update(output_shape)

    async def arecord_interaction(
        self,
        interaction_type: InteractionType,
        input_data: dict[str, Any],
        output_data: dict[str, Any] | None = None,
        error: str | None = None,
        metadata: dict[str, Any] | None = None,
        parallel_group: str | None = None,
    ) -> Interaction:
        """Async-safe version of record_interaction for use in async hooks.

        Runs the synchronous record_interaction in the default thread-pool
        executor so hash computations and lock acquisition do not block the
        asyncio event loop.

        Use this in any ``async def`` hook (aiohttp, AsyncAnthropic, etc.).

        Args:
            interaction_type: Type of interaction
            input_data: Input data
            output_data: Output data
            error: Error message if the interaction failed
            metadata: Additional context
            parallel_group: Group ID for concurrent interactions

        Returns:
            The created Interaction object
        """
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None,
            functools.partial(
                self.record_interaction,
                interaction_type=interaction_type,
                input_data=input_data,
                output_data=output_data,
                error=error,
                metadata=metadata,
                parallel_group=parallel_group,
            ),
        )

    def _flush_loop(self) -> None:
        """Background thread that periodically flushes the buffer."""
        while not self._stop_event.wait(self.flush_interval):
            self._flush_buffer()

    def _flush_buffer(self) -> None:
        """Flush buffered interactions to local storage and/or backend API."""
        if not self.buffer:
            return

        with self._lock:
            items_to_send = list(self.buffer)
            self.buffer.clear()

        if not items_to_send:
            return

        # Save to local storage (JSONL)
        if self.local_storage_enabled:
            try:
                save_interactions_locally(items_to_send, self.run_id)
            except Exception as e:
                logger.warning("Failed to save interactions locally", error=str(e))

        # Send to backend API (guarded by circuit breaker)
        if not self._circuit_breaker.allow_request():
            # Circuit is OPEN — skip POST entirely.
            # Data is safe in local JSONL; do NOT re-buffer (prevents unbounded memory growth).
            logger.debug("Circuit breaker open, skipping backend flush", run_id=self.run_id)
            return

        flush_start = time.monotonic()
        try:
            self._post_to_backend(items_to_send)
            _metrics.observe_flush_duration(self.agent_id, time.monotonic() - flush_start)
            self._circuit_breaker.record_success()
        except Exception as e:
            _metrics.observe_flush_duration(self.agent_id, time.monotonic() - flush_start)
            _metrics.inc_flush_errors(self.agent_id, type(e).__name__)
            self._circuit_breaker.record_failure()
            logger.error("Failed to flush buffer to backend", error=str(e), run_id=self.run_id)
            # Do NOT re-buffer for local retry: data is already saved to local JSONL
            # (line 822 above). Re-buffering caused duplicate interactions in the
            # local file, breaking hash chain verification. Backend retries are
            # handled separately by the circuit breaker on the next flush cycle.

    def _post_to_backend(self, interactions: list[dict[str, Any]]) -> None:
        """POST interactions to the backend API.

        Content fields (input, output, error) are always stripped and replaced
        with redaction markers before transmission. Only structural metadata
        (hashes, types, latencies) is sent to the backend.

        Args:
            interactions: List of interaction dictionaries to send
        """
        if not (self.backend_url and self.backend_url.strip()):
            return
        try:
            import requests

            # Always strip content — only structural metadata leaves the machine
            interactions = [self._strip_content_for_backend(i) for i in interactions]

            url = f"{self.backend_url}/api/traces/{self.run_id}/interactions"
            response = requests.post(
                url,
                json=interactions,
                timeout=10,
                headers={"Content-Type": "application/json", **get_auth_headers()},
            )
            response.raise_for_status()
            logger.debug("Flushed to backend", count=len(interactions), run_id=self.run_id)

        except ImportError:
            logger.debug("requests library not available, skipping backend flush")
        except Exception:
            # Don't log as error here - let caller handle retry logic
            raise

    # Fields allowed in the trace metadata sent to the backend
    TRACE_ALLOWLIST = frozenset(
        {
            "run_id",
            "agent_id",
            "timestamp",
            "status",
            "environment",
            "tags",
            "chain_hash",
            "fingerprint_hash",
            "session_id",
            "parent_run_id",
            "depth",
            "user_id",
        }
    )

    def _post_chain_hash_to_backend(
        self,
        chain_hash: str,
        fingerprint_hash: str | None = None,
        trace_payload: dict[str, Any] | None = None,
    ) -> None:
        """PUT chain_hash, fingerprint_hash, and full trace metadata to the backend API.

        The backend uses this to create or update the trace row so the UI has
        agent_id, timestamp, status, environment, etc., not just run_id/chain_hash/fingerprint_hash.

        Only fields in TRACE_ALLOWLIST are transmitted.

        Args:
            chain_hash: The chain hash to send
            fingerprint_hash: Structural hash for baseline lookup (set on stop)
            trace_payload: Full trace dict (agent_id, timestamp, status, environment, etc.)
        """
        if not (self.backend_url and self.backend_url.strip()):
            return
        if not self._circuit_breaker.allow_request():
            logger.debug("Circuit breaker open, skipping chain_hash update", run_id=self.run_id)
            return
        try:
            import requests

            url = f"{self.backend_url}/api/traces/{self.run_id}/chain_hash"
            # Filter trace payload to allowlisted fields only
            if trace_payload:
                body: dict[str, Any] = {
                    k: v for k, v in trace_payload.items() if k in self.TRACE_ALLOWLIST
                }
            else:
                body = {}
            body["chain_hash"] = chain_hash
            if fingerprint_hash:
                body["fingerprint_hash"] = fingerprint_hash
            response = requests.put(
                url,
                json=body,
                timeout=10,
                headers={"Content-Type": "application/json", **get_auth_headers()},
            )
            response.raise_for_status()
            self._circuit_breaker.record_success()
            logger.debug(
                "Chain hash sent to backend", run_id=self.run_id, chain_hash=chain_hash[:16] + "..."
            )

        except ImportError:
            logger.debug("requests library not available, skipping chain_hash update")
        except Exception as e:
            self._circuit_breaker.record_failure()
            logger.debug("Failed to send chain_hash to backend", error=str(e))

    def spawn(self, agent_id: str, **kwargs: Any) -> Recorder:
        """Create a child recorder inheriting this recorder's session context.

        The child gets its own run_id, hash chain, and flush thread.
        If no session_id exists yet, one is created from the parent's run_id.

        Args:
            agent_id: User-defined identifier for the child agent
            **kwargs: Additional arguments passed to Recorder.__init__

        Returns:
            A new Recorder linked to this one via session_id and parent_run_id
        """
        session_id = self.session_id or self.run_id
        if self.session_id is None:
            self.session_id = session_id  # Retroactively set on parent

        child = Recorder(
            agent_id=agent_id,
            backend_url=self.backend_url,
            session_id=session_id,
            parent_run_id=self.run_id,
            **kwargs,
        )
        child._depth = self._depth + 1
        return child

    def correlation_context(self) -> dict[str, str]:
        """Return a serializable context dict for cross-process correlation.

        Pass this dict to a subprocess via env var or constructor kwarg
        so the child recorder joins this session.

        Returns:
            Dict with session_id, parent_run_id, and depth
        """
        session_id = self.session_id or self.run_id
        if self.session_id is None:
            self.session_id = session_id
        return {
            "session_id": session_id,
            "parent_run_id": self.run_id,
            "depth": str(self._depth + 1),
        }

    def get_trace(self) -> Trace:
        """Get the current trace object with chain_hash and fingerprint_hash if available."""
        return Trace(
            run_id=self.run_id,
            agent_id=self.agent_id,
            timestamp=self.start_time,
            status=self.status,
            environment=self.environment,
            tags=self.tags,
            chain_hash=self._chain_hash,
            fingerprint_hash=self._fingerprint_hash,
            session_id=self.session_id,
            parent_run_id=self.parent_run_id,
            depth=self._depth,
        )


# Global recorder instance (for simple usage)
_global_recorder: Recorder | None = None


def start_trace(
    agent_id: str,
    install_hooks: bool = True,
    session_id: str | None = None,
    parent_run_id: str | None = None,
    correlation_context: dict[str, str] | None = None,
    **kwargs: Any,
) -> Recorder:
    """Start a global trace recorder.

    This is the zero-friction entry point: `start_trace("my_agent")`

    Args:
        agent_id: User-defined identifier for the agent
        install_hooks: Whether to automatically install OpenAI/requests hooks
        session_id: Correlation ID for multi-agent sessions
        parent_run_id: run_id of the parent trace that spawned this one
        correlation_context: Serializable dict with session_id, parent_run_id, depth
        **kwargs: Additional arguments passed to Recorder.__init__

    Returns:
        The Recorder instance
    """
    # Load .env here (not at import time) to avoid side effects on import
    load_dotenv()

    recorder = Recorder(
        agent_id=agent_id,
        session_id=session_id,
        parent_run_id=parent_run_id,
        correlation_context=correlation_context,
        **kwargs,
    )
    recorder.start()

    # Always set context var (thread-safe via contextvars)
    from spooled._context import set_current_recorder

    set_current_recorder(recorder)

    # Only set the global if no other recorder owns it — prevents
    # concurrent threads from stomping each other's global.
    global _global_recorder
    if _global_recorder is None:
        _global_recorder = recorder

    # Install hooks automatically
    if install_hooks:
        from spooled.hooks import install_all_hooks

        install_all_hooks(recorder)

    return recorder


def stop_trace(recorder_or_status=None, *, status: TraceStatus = TraceStatus.SUCCESS) -> None:
    """Stop the global trace recorder.

    Accepts an optional Recorder as the first argument (ignored — stops the
    global recorder regardless) so that ``stop_trace(recorder, status=...)``
    works without crashing.  The canonical pattern is simply
    ``stop_trace(status=TraceStatus.SUCCESS)``.

    Args:
        recorder_or_status: Optional Recorder instance (ignored) or TraceStatus.
        status: Final status of the trace.
    """
    # If the user passed a TraceStatus positionally, honour it.
    if isinstance(recorder_or_status, TraceStatus):
        status = recorder_or_status
    from spooled._context import get_current_recorder, set_current_recorder

    # Prefer context-var recorder (thread-safe); fall back to global
    ctx_recorder = get_current_recorder()
    global _global_recorder
    recorder_to_stop = ctx_recorder or _global_recorder

    if recorder_to_stop is not None:
        recorder_to_stop.stop(status=status)

        # Clear context var for this thread
        set_current_recorder(None)

        # Only clear global + uninstall hooks if we own the global
        if _global_recorder is recorder_to_stop:
            from spooled.hooks import uninstall_all_hooks

            uninstall_all_hooks()
            _global_recorder = None


def get_recorder() -> Recorder | None:
    """Get the current active recorder.

    Checks context var first (set by decorators), then falls back
    to the global recorder (set by start_trace/init).

    Returns:
        The Recorder instance, or None if not started
    """
    from spooled._context import get_current_recorder

    ctx_recorder = get_current_recorder()
    if ctx_recorder is not None:
        return ctx_recorder
    return _global_recorder
