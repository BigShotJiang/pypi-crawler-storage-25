"""Per-instance OpenAI client wrapper.

Intercepts chat.completions.create() on a specific client instance.
Does NOT monkey-patch globally — safe to use alongside other tools.
"""

from __future__ import annotations

from typing import Any

import structlog

logger = structlog.get_logger(__name__)


def _resolve_recorder(explicit_recorder: Any) -> Any:
    """Resolve the active recorder: explicit > context var > global."""
    if explicit_recorder is not None:
        return explicit_recorder
    from spooled._context import get_current_recorder

    recorder = get_current_recorder()
    if recorder is not None:
        return recorder
    from spooled.recorder import _global_recorder

    return _global_recorder


class _TracedCompletions:
    """Proxy for client.chat.completions that traces .create() calls."""

    def __init__(self, original_completions: Any, recorder: Any) -> None:
        self._original = original_completions
        self._recorder = recorder
        # Get the pre-hook unbound method to avoid double-recording when both
        # wrapper and global hooks are active (e.g., concurrent threads).
        from spooled.hooks.openai_hook import _original_methods

        pre_hook = _original_methods.get("sync_create")
        self._original_create = pre_hook or getattr(type(original_completions), "create", None)

    def create(self, *args: Any, **kwargs: Any) -> Any:
        recorder = _resolve_recorder(self._recorder)
        if recorder is None:
            return self._original.create(*args, **kwargs)

        from spooled.hooks.openai_hook import _intercept_call

        original = self._original_create or type(self._original).create
        return _intercept_call(recorder, original, self._original, *args, **kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class _TracedAsyncCompletions:
    """Proxy for async client.chat.completions that traces .create() calls."""

    def __init__(self, original_completions: Any, recorder: Any) -> None:
        self._original = original_completions
        self._recorder = recorder
        from spooled.hooks.openai_hook import _original_methods

        pre_hook = _original_methods.get("async_create")
        self._original_create = pre_hook or getattr(type(original_completions), "create", None)

    async def create(self, *args: Any, **kwargs: Any) -> Any:
        recorder = _resolve_recorder(self._recorder)
        if recorder is None:
            return await self._original.create(*args, **kwargs)

        from spooled.hooks.openai_hook import _intercept_call_async

        original = self._original_create or type(self._original).create
        return await _intercept_call_async(recorder, original, self._original, *args, **kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class _TracedChat:
    """Proxy for client.chat that intercepts .completions."""

    def __init__(self, original_chat: Any, recorder: Any, is_async: bool = False) -> None:
        self._original = original_chat
        self._recorder = recorder
        self._is_async = is_async

    @property
    def completions(self) -> Any:
        original_completions = self._original.completions
        if self._is_async:
            return _TracedAsyncCompletions(original_completions, self._recorder)
        return _TracedCompletions(original_completions, self._recorder)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class _TracedOpenAIClient:
    """Proxy for openai.Client that intercepts chat.completions.create()."""

    def __init__(self, client: Any, recorder: Any, is_async: bool = False) -> None:
        self._client = client
        self._recorder = recorder
        self._is_async = is_async

    @property
    def chat(self) -> _TracedChat:
        return _TracedChat(self._client.chat, self._recorder, is_async=self._is_async)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


def wrap_openai(client: Any, recorder: Any = None) -> Any:
    """Wrap an OpenAI client instance to trace all chat completion calls.

    The wrapped client has the same interface as the original. Only
    chat.completions.create() is intercepted; all other methods delegate
    directly to the original client.

    The recorder is resolved per-call: explicit arg > context var > global.
    This means the wrapper works inside @spooled.trace() without passing
    a recorder explicitly.

    Args:
        client: An openai.Client or openai.AsyncClient instance.
        recorder: Optional explicit Recorder. If None, uses context var / global.

    Returns:
        A wrapped client with the same interface.
    """
    # Detect sync vs async
    is_async = type(client).__name__ in ("AsyncOpenAI", "AsyncClient")
    return _TracedOpenAIClient(client, recorder, is_async=is_async)
