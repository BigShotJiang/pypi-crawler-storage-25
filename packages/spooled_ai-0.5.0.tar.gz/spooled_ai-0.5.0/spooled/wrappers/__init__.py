"""Explicit client wrappers for LLM providers.

These wrap a specific client instance rather than monkey-patching globally,
so multiple wrapped clients can coexist without conflicts.

Usage:
    from spooled.wrappers import wrap_openai, wrap_anthropic

    client = wrap_openai(openai.Client())
    # Every call through `client` is traced; other OpenAI clients are untouched.
"""

from __future__ import annotations

from spooled.wrappers.anthropic_wrapper import wrap_anthropic
from spooled.wrappers.openai_wrapper import wrap_openai

__all__ = ["wrap_openai", "wrap_anthropic"]
