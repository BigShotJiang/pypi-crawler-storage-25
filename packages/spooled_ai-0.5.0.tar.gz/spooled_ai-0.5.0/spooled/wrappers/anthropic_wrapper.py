"""Per-instance Anthropic client wrapper.

Intercepts messages.create() on a specific client instance.
Does NOT monkey-patch globally — safe to use alongside other tools.
"""

from __future__ import annotations

from typing import Any

import structlog

logger = structlog.get_logger(__name__)


def _resolve_recorder(explicit_recorder: Any) -> Any:
    """Resolve the active recorder: explicit > context var > global."""
    if explicit_recorder is not None:
        return explicit_recorder
    from spooled._context import get_current_recorder

    recorder = get_current_recorder()
    if recorder is not None:
        return recorder
    from spooled.recorder import _global_recorder

    return _global_recorder


class _TracedMessages:
    """Proxy for client.messages that traces .create() calls."""

    def __init__(self, original_messages: Any, recorder: Any) -> None:
        self._original = original_messages
        self._recorder = recorder

    def create(self, *args: Any, **kwargs: Any) -> Any:
        recorder = _resolve_recorder(self._recorder)
        if recorder is None:
            return self._original.create(*args, **kwargs)

        from spooled.hooks.anthropic_hook import _intercept_call

        original_method = type(self._original).create
        return _intercept_call(recorder, original_method, self._original, *args, **kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class _TracedAsyncMessages:
    """Proxy for async client.messages that traces .create() calls."""

    def __init__(self, original_messages: Any, recorder: Any) -> None:
        self._original = original_messages
        self._recorder = recorder

    async def create(self, *args: Any, **kwargs: Any) -> Any:
        recorder = _resolve_recorder(self._recorder)
        if recorder is None:
            return await self._original.create(*args, **kwargs)

        from spooled.hooks.anthropic_hook import _intercept_call_async

        original_method = type(self._original).create
        return await _intercept_call_async(
            recorder, original_method, self._original, *args, **kwargs
        )

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class _TracedAnthropicClient:
    """Proxy for anthropic.Anthropic that intercepts messages.create()."""

    def __init__(self, client: Any, recorder: Any, is_async: bool = False) -> None:
        self._client = client
        self._recorder = recorder
        self._is_async = is_async

    @property
    def messages(self) -> Any:
        original_messages = self._client.messages
        if self._is_async:
            return _TracedAsyncMessages(original_messages, self._recorder)
        return _TracedMessages(original_messages, self._recorder)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


def wrap_anthropic(client: Any, recorder: Any = None) -> Any:
    """Wrap an Anthropic client instance to trace all message creation calls.

    The wrapped client has the same interface as the original. Only
    messages.create() is intercepted; all other methods delegate
    directly to the original client.

    Args:
        client: An anthropic.Anthropic or anthropic.AsyncAnthropic instance.
        recorder: Optional explicit Recorder. If None, uses context var / global.

    Returns:
        A wrapped client with the same interface.
    """
    is_async = type(client).__name__ in ("AsyncAnthropic",)
    return _TracedAnthropicClient(client, recorder, is_async=is_async)
