"""OpenTelemetry span exporter for Spooled traces.

Converts Spooled Interaction objects into OTEL spans and exports them
via the OTLP protocol to any OTEL-compatible backend (Datadog, Grafana,
Honeycomb, Jaeger, etc.).

Usage:
    from spooled.exporters.otel import SpooledOTELExporter

    exporter = SpooledOTELExporter(endpoint="http://localhost:4318")
    spooled.init(agent_id="my_agent", exporters=[exporter])
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Protocol, runtime_checkable
from urllib.parse import urlparse

import structlog

from spooled.exporters._semconv import (
    GEN_AI_REQUEST_MAX_TOKENS,
    GEN_AI_REQUEST_MODEL,
    GEN_AI_REQUEST_TEMPERATURE,
    GEN_AI_RESPONSE_FINISH_REASONS,
    GEN_AI_RESPONSE_MODEL,
    GEN_AI_SYSTEM,
    GEN_AI_USAGE_INPUT_TOKENS,
    GEN_AI_USAGE_OUTPUT_TOKENS,
    HTTP_REQUEST_METHOD,
    HTTP_RESPONSE_STATUS_CODE,
    SERVER_ADDRESS,
    SPOOLED_AGENT_ID,
    SPOOLED_INTERACTION_ID,
    SPOOLED_PARALLEL_GROUP,
    SPOOLED_PAYLOAD_HASH,
    SPOOLED_PREV_HASH,
    SPOOLED_RUN_ID,
    SPOOLED_SEQUENCE,
    TOOL_ARGUMENTS,
    TOOL_CALL_ID,
    TOOL_NAME,
    URL_FULL,
    infer_gen_ai_system,
)
from spooled.models import Interaction, InteractionType, Trace

logger = structlog.get_logger(__name__)

try:
    from opentelemetry import trace as otel_trace
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import ReadableSpan, TracerProvider  # noqa: F401 (ReadableSpan)
    from opentelemetry.sdk.trace.export import (
        BatchSpanProcessor,
        SimpleSpanProcessor,
        SpanExporter,  # noqa: F401
    )
    from opentelemetry.trace import SpanKind, StatusCode

    try:
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
            OTLPSpanExporter as OTLPHttpExporter,
        )
    except ImportError:
        OTLPHttpExporter = None  # type: ignore[assignment,misc]

    try:
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
            OTLPSpanExporter as OTLPGrpcExporter,
        )
    except ImportError:
        OTLPGrpcExporter = None  # type: ignore[assignment,misc]

    HAS_OTEL = True
except ImportError:
    HAS_OTEL = False

# Maximum length for tool.arguments attribute value
_MAX_TOOL_ARGS_LEN = 4096


@runtime_checkable
class SpooledExporter(Protocol):
    """Protocol for Spooled exporters.

    Any class implementing these three methods can be used as an exporter
    in the Recorder's exporters list.
    """

    def on_interaction(self, interaction: Interaction, trace_context: dict[str, Any]) -> None:
        """Called after each interaction is recorded."""
        ...

    def on_trace_end(self, trace: Trace) -> None:
        """Called when the trace is stopped."""
        ...

    def shutdown(self) -> None:
        """Clean up resources."""
        ...


def _uuid_to_trace_id(uuid_str: str) -> int:
    """Convert a UUID string to a deterministic 128-bit OTEL trace_id."""
    digest = hashlib.sha256(uuid_str.encode()).digest()
    return int.from_bytes(digest[:16], "big")


def _uuid_to_span_id(uuid_str: str) -> int:
    """Convert a UUID string to a deterministic 64-bit OTEL span_id."""
    digest = hashlib.sha256(uuid_str.encode()).digest()
    return int.from_bytes(digest[:8], "big")


def interaction_to_span_attributes(
    interaction: Interaction,
) -> tuple[str, SpanKind, dict[str, Any]]:
    """Convert an Interaction to OTEL span name, kind, and attributes.

    Returns:
        Tuple of (span_name, span_kind, attributes_dict)
    """
    if not HAS_OTEL:
        raise ImportError(
            "opentelemetry packages required. Install with: pip install spooled[otel]"
        )

    attrs: dict[str, Any] = {}
    inp = interaction.input or {}
    out = interaction.output or {}
    meta = interaction.metadata or {}
    itype = (
        interaction.interaction_type
        if isinstance(interaction.interaction_type, str)
        else interaction.interaction_type.value
    )

    if itype == InteractionType.LLM_CALL.value:
        model = meta.get("model") or inp.get("model") or "unknown"
        span_name = f"gen_ai.chat {model}"
        span_kind = SpanKind.CLIENT

        system = infer_gen_ai_system(model)
        attrs[GEN_AI_SYSTEM] = system
        attrs[GEN_AI_REQUEST_MODEL] = model

        if inp.get("temperature") is not None:
            attrs[GEN_AI_REQUEST_TEMPERATURE] = float(inp["temperature"])
        if inp.get("max_tokens") is not None:
            attrs[GEN_AI_REQUEST_MAX_TOKENS] = int(inp["max_tokens"])

        # Response model (may differ from request model)
        resp_model = out.get("model")
        if resp_model:
            attrs[GEN_AI_RESPONSE_MODEL] = resp_model

        # Token usage — check multiple locations
        usage = out.get("usage") or {}
        input_tokens = (
            usage.get("prompt_tokens") or usage.get("input_tokens") or meta.get("input_tokens")
        )
        output_tokens = (
            usage.get("completion_tokens")
            or usage.get("output_tokens")
            or meta.get("completion_tokens")
        )
        if input_tokens is not None:
            attrs[GEN_AI_USAGE_INPUT_TOKENS] = int(input_tokens)
        if output_tokens is not None:
            attrs[GEN_AI_USAGE_OUTPUT_TOKENS] = int(output_tokens)

        # Finish reasons
        choices = out.get("choices")
        if isinstance(choices, list) and choices:
            reasons = [c.get("finish_reason") for c in choices if c.get("finish_reason")]
            if reasons:
                attrs[GEN_AI_RESPONSE_FINISH_REASONS] = reasons

    elif itype == InteractionType.TOOL_CALL.value:
        tool_name = inp.get("function") or inp.get("tool_name") or inp.get("tool") or "unknown"
        span_name = f"tool.{tool_name}"
        span_kind = SpanKind.INTERNAL

        attrs[TOOL_NAME] = tool_name
        arguments = inp.get("arguments")
        if arguments is not None:
            args_str = json.dumps(arguments) if not isinstance(arguments, str) else arguments
            if len(args_str) > _MAX_TOOL_ARGS_LEN:
                args_str = args_str[:_MAX_TOOL_ARGS_LEN] + "..."
            attrs[TOOL_ARGUMENTS] = args_str
        call_id = inp.get("call_id")
        if call_id:
            attrs[TOOL_CALL_ID] = call_id

    elif itype == InteractionType.HTTP_REQUEST.value:
        method = inp.get("method", "GET")
        url = inp.get("url", "")
        try:
            path = urlparse(url).path or "/"
        except Exception:
            path = "/"
        span_name = f"{method} {path}"
        span_kind = SpanKind.CLIENT

        attrs[HTTP_REQUEST_METHOD] = method
        if url:
            attrs[URL_FULL] = url
            try:
                attrs[SERVER_ADDRESS] = urlparse(url).hostname or ""
            except Exception:
                pass

        status_code = meta.get("status_code") or out.get("status_code")
        if status_code is not None:
            attrs[HTTP_RESPONSE_STATUS_CODE] = int(status_code)

    else:
        span_name = f"spooled.{itype.lower()}"
        span_kind = SpanKind.INTERNAL

    # Spooled-specific attributes (always added)
    if interaction.payload_hash:
        attrs[SPOOLED_PAYLOAD_HASH] = interaction.payload_hash
    if interaction.prev_hash:
        attrs[SPOOLED_PREV_HASH] = interaction.prev_hash
    attrs[SPOOLED_SEQUENCE] = interaction.sequence
    attrs[SPOOLED_INTERACTION_ID] = interaction.interaction_id
    if interaction.parallel_group:
        attrs[SPOOLED_PARALLEL_GROUP] = interaction.parallel_group

    return span_name, span_kind, attrs


class SpooledOTELExporter:
    """Exports Spooled Interactions as OpenTelemetry spans.

    Each interaction is converted to an OTEL span with appropriate semantic
    conventions (gen_ai.* for LLM calls, tool.* for tool calls, http.* for
    HTTP requests). Spooled-specific data (hashes, sequence) is attached
    as custom span attributes.

    Args:
        endpoint: OTLP endpoint URL (default: http://localhost:4318)
        service_name: OTEL service.name resource attribute
        resource_attributes: Additional OTEL resource attributes
        headers: Additional HTTP headers for the OTLP exporter
        protocol: Transport protocol — "http/protobuf" or "grpc"
        batch: If True (default), use BatchSpanProcessor for efficiency.
               If False, use SimpleSpanProcessor (useful for testing).
        span_exporter: Optional custom SpanExporter instance. If provided,
                       endpoint/headers/protocol are ignored.
    """

    def __init__(
        self,
        endpoint: str = "http://localhost:4318",
        service_name: str = "spooled-agent",
        resource_attributes: dict[str, str] | None = None,
        headers: dict[str, str] | None = None,
        protocol: str = "http/protobuf",
        batch: bool = True,
        span_exporter: Any | None = None,
    ) -> None:
        if not HAS_OTEL:
            raise ImportError(
                "opentelemetry packages required. Install with: pip install spooled[otel]"
            )

        # Warn if OTEL endpoint is not HTTPS (except localhost for dev)
        parsed_ep = urlparse(endpoint)
        if parsed_ep.scheme == "http" and parsed_ep.hostname not in ("localhost", "127.0.0.1"):
            logger.warning(
                "OTEL endpoint does not use HTTPS — spans will be transmitted unencrypted",
                endpoint=endpoint,
            )

        res_attrs = {"service.name": service_name}
        if resource_attributes:
            res_attrs.update(resource_attributes)
        resource = Resource.create(res_attrs)

        self._provider = TracerProvider(resource=resource)

        if span_exporter is not None:
            # Use the provided exporter (e.g., InMemorySpanExporter for testing)
            exporter = span_exporter
        elif protocol == "grpc":
            if OTLPGrpcExporter is None:
                raise ImportError(
                    "opentelemetry-exporter-otlp-proto-grpc required for gRPC protocol. "
                    "Install with: pip install opentelemetry-exporter-otlp-proto-grpc"
                )
            exporter = OTLPGrpcExporter(endpoint=endpoint, headers=headers or {})
        else:
            if OTLPHttpExporter is None:
                raise ImportError(
                    "opentelemetry-exporter-otlp-proto-http required for HTTP protocol. "
                    "Install with: pip install opentelemetry-exporter-otlp-proto-http"
                )
            exporter = OTLPHttpExporter(endpoint=endpoint, headers=headers or {})

        if batch:
            self._processor = BatchSpanProcessor(exporter)
        else:
            self._processor = SimpleSpanProcessor(exporter)  # type: ignore[assignment]
        self._provider.add_span_processor(self._processor)
        self._tracer = self._provider.get_tracer("spooled", "0.3.0")

        # Track root span per trace for parent-child linking
        self._root_spans: dict[str, Any] = {}  # run_id -> root span context
        self._started = True

    def on_interaction(self, interaction: Interaction, trace_context: dict[str, Any]) -> None:
        """Convert an Interaction to an OTEL span and export it.

        Args:
            interaction: The recorded Interaction
            trace_context: Dict with run_id, agent_id, session_id
        """
        if not self._started:
            return

        run_id = trace_context.get("run_id", interaction.run_id)
        agent_id = trace_context.get("agent_id", "")

        span_name, span_kind, attrs = interaction_to_span_attributes(interaction)

        # Add agent context
        attrs[SPOOLED_AGENT_ID] = agent_id
        attrs[SPOOLED_RUN_ID] = run_id

        # Deterministic IDs
        trace_id = _uuid_to_trace_id(run_id)
        span_id = _uuid_to_span_id(interaction.interaction_id)

        # Create OTEL span context
        otel_trace.SpanContext(
            trace_id=trace_id,
            span_id=span_id,
            is_remote=False,
            trace_flags=otel_trace.TraceFlags(otel_trace.TraceFlags.SAMPLED),
        )

        # Determine parent: use root span for this trace
        if run_id not in self._root_spans:
            # Create root span on first interaction
            root_span_id = _uuid_to_span_id(run_id + ":root")
            root_context = otel_trace.SpanContext(
                trace_id=trace_id,
                span_id=root_span_id,
                is_remote=False,
                trace_flags=otel_trace.TraceFlags(otel_trace.TraceFlags.SAMPLED),
            )
            self._root_spans[run_id] = root_context

            # Create and immediately end the root span
            root_span = otel_trace.NonRecordingSpan(root_context)
            ctx = otel_trace.set_span_in_context(root_span)
            with self._tracer.start_as_current_span(
                name=f"spooled.trace {agent_id}",
                kind=SpanKind.INTERNAL,
                context=ctx,
                attributes={
                    SPOOLED_AGENT_ID: agent_id,
                    SPOOLED_RUN_ID: run_id,
                },
            ) as root:
                self._root_spans[run_id] = root.get_span_context()

        # Create child span under root
        parent_context = self._root_spans[run_id]
        parent_span = otel_trace.NonRecordingSpan(parent_context)
        ctx = otel_trace.set_span_in_context(parent_span)

        with self._tracer.start_as_current_span(
            name=span_name,
            kind=span_kind,
            context=ctx,
            attributes=attrs,
        ) as span:
            # Set error status if interaction has an error
            if interaction.error:
                span.set_status(StatusCode.ERROR, interaction.error)

            # Add latency as span duration is handled by OTEL automatically,
            # but we store the original latency_ms for reference
            latency = (interaction.metadata or {}).get("latency_ms")
            if latency is not None:
                span.set_attribute("spooled.latency_ms", float(latency))

    def on_trace_end(self, trace: Trace) -> None:
        """Called when a trace ends. Flushes pending spans.

        Args:
            trace: The completed Trace object
        """
        if not self._started:
            return

        # The root span has already been created and ended.
        # We could update it, but OTEL spans are immutable after creation.
        # Instead, we flush to ensure all spans are exported.
        try:
            self._processor.force_flush(timeout_millis=5000)
        except Exception as e:
            logger.debug("Failed to flush OTEL spans", error=str(e))

    def shutdown(self) -> None:
        """Shutdown the OTEL provider and flush remaining spans."""
        if not self._started:
            return
        self._started = False
        try:
            self._provider.shutdown()
        except Exception as e:
            logger.debug("Failed to shutdown OTEL provider", error=str(e))

    def get_provider(self) -> TracerProvider:
        """Return the underlying TracerProvider (for advanced usage)."""
        return self._provider
