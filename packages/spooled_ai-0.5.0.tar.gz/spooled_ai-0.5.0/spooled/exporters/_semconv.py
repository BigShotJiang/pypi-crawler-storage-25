"""OpenTelemetry semantic convention constants for Spooled.

Centralizes all attribute keys so convention changes only require
updating this file. Follows the OpenTelemetry GenAI semantic conventions
(experimental) and stable HTTP conventions.
"""

# --- GenAI semantic conventions (OTEL GenAI SIG) ---
from __future__ import annotations

GEN_AI_SYSTEM = "gen_ai.system"
GEN_AI_REQUEST_MODEL = "gen_ai.request.model"
GEN_AI_REQUEST_TEMPERATURE = "gen_ai.request.temperature"
GEN_AI_REQUEST_MAX_TOKENS = "gen_ai.request.max_tokens"
GEN_AI_RESPONSE_MODEL = "gen_ai.response.model"
GEN_AI_RESPONSE_FINISH_REASONS = "gen_ai.response.finish_reasons"
GEN_AI_USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
GEN_AI_USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"

# --- Tool semantic conventions ---
TOOL_NAME = "tool.name"
TOOL_ARGUMENTS = "tool.arguments"
TOOL_CALL_ID = "tool.call_id"

# --- HTTP semantic conventions (stable) ---
HTTP_REQUEST_METHOD = "http.request.method"
HTTP_RESPONSE_STATUS_CODE = "http.response.status_code"
URL_FULL = "url.full"
SERVER_ADDRESS = "server.address"

# --- Spooled custom attributes ---
SPOOLED_PAYLOAD_HASH = "spooled.payload_hash"
SPOOLED_PREV_HASH = "spooled.prev_hash"
SPOOLED_SEQUENCE = "spooled.sequence"
SPOOLED_INTERACTION_ID = "spooled.interaction_id"
SPOOLED_PARALLEL_GROUP = "spooled.parallel_group"
SPOOLED_CHAIN_HASH = "spooled.chain_hash"
SPOOLED_FINGERPRINT_HASH = "spooled.fingerprint_hash"
SPOOLED_AGENT_ID = "spooled.agent_id"
SPOOLED_RUN_ID = "spooled.run_id"


# --- Model name to gen_ai.system mapping ---
_MODEL_SYSTEM_MAP = {
    "gpt": "openai",
    "o1": "openai",
    "o3": "openai",
    "o4": "openai",
    "davinci": "openai",
    "claude": "anthropic",
    "gemini": "google",
    "palm": "google",
    "command": "cohere",
    "mistral": "mistral",
    "mixtral": "mistral",
    "llama": "meta",
    "titan": "aws",
}


def infer_gen_ai_system(model_name: str) -> str:
    """Infer the gen_ai.system value from a model name.

    Args:
        model_name: The model name (e.g., "gpt-4", "claude-3-opus")

    Returns:
        The inferred system name, or "unknown" if not recognized.
    """
    lower = model_name.lower()
    for prefix, system in _MODEL_SYSTEM_MAP.items():
        if lower.startswith(prefix):
            return system
    return "unknown"
