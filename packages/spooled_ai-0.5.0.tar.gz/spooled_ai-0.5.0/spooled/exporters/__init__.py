"""Spooled exporters — send traces to external observability systems.

Available exporters:
    SpooledOTELExporter: Export Spooled traces as OpenTelemetry spans.
    WebhookExporter: POST trace completion notifications to webhook URLs.

Install OTEL support with: pip install spooled[otel]
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from spooled.exporters.otel import SpooledOTELExporter
    from spooled.exporters.webhook import WebhookExporter

__all__ = ["SpooledOTELExporter", "WebhookExporter"]


def __getattr__(name: str):  # type: ignore[no-untyped-def]
    if name == "SpooledOTELExporter":
        from spooled.exporters.otel import SpooledOTELExporter

        return SpooledOTELExporter
    if name == "WebhookExporter":
        from spooled.exporters.webhook import WebhookExporter

        return WebhookExporter
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
