"""Webhook exporter for Spooled trace completion notifications.

POSTs a privacy-safe structural summary to one or more webhook URLs
whenever a trace completes.  Supports plain JSON and Slack Block Kit
formats.

Usage:
    from spooled.exporters.webhook import WebhookExporter

    exporter = WebhookExporter(urls=["https://hooks.slack.com/..."], format="slack")
    spooled.init(agent_id="my_agent", exporters=[exporter])
"""

from __future__ import annotations

import os
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


class WebhookExporter:
    """Exporter that sends trace completion notifications to webhook URLs.

    Implements the SpooledExporter protocol: on_interaction, on_trace_end,
    shutdown.

    Configuration:
        urls: List of webhook URLs, or from SPOOLED_WEBHOOK_URLS env var
              (comma-separated).
        format: ``"json"`` (default) or ``"slack"`` (Slack Block Kit), or
                from SPOOLED_WEBHOOK_FORMAT.
        max_retries: Number of retry attempts (default 3).
        timeout: Request timeout in seconds (default 10).
    """

    def __init__(
        self,
        urls: list[str] | None = None,
        format: str = "json",
        max_retries: int = 3,
        timeout: float = 10.0,
    ) -> None:
        self.urls: list[str] = urls or [
            u.strip() for u in os.getenv("SPOOLED_WEBHOOK_URLS", "").split(",") if u.strip()
        ]
        self.format: str = os.getenv("SPOOLED_WEBHOOK_FORMAT", format)
        self.max_retries: int = max_retries
        self.timeout: float = timeout
        self._executor: ThreadPoolExecutor = ThreadPoolExecutor(
            max_workers=2, thread_name_prefix="spooled-webhook"
        )

    # ------------------------------------------------------------------
    # SpooledExporter protocol
    # ------------------------------------------------------------------

    def on_interaction(self, interaction: Any, trace_context: dict[str, Any]) -> None:
        """No-op — webhooks fire on trace completion, not per-interaction."""
        pass

    def on_trace_end(self, trace: Any) -> None:
        """POST notification to all configured URLs."""
        if not self.urls:
            return
        payload = self._build_payload(trace)
        for url in self.urls:
            self._executor.submit(self._send, url, payload)

    def shutdown(self) -> None:
        """Wait for pending webhooks to complete."""
        self._executor.shutdown(wait=True)

    # ------------------------------------------------------------------
    # Payload builders
    # ------------------------------------------------------------------

    def _build_payload(self, trace: Any) -> dict:
        """Build a privacy-safe payload from a trace.

        NEVER includes input/output/messages — only structural metadata.
        """
        ts = getattr(trace, "timestamp", None)
        if isinstance(ts, datetime):
            ts_str = ts.isoformat()
        elif ts is not None:
            ts_str = str(ts)
        else:
            ts_str = None

        base: dict[str, Any] = {
            "event": "trace.completed",
            "agent_id": getattr(trace, "agent_id", None),
            "run_id": getattr(trace, "run_id", None),
            "fingerprint_hash": getattr(trace, "fingerprint_hash", None),
            "chain_hash": getattr(trace, "chain_hash", None),
            "status": getattr(trace, "status", None),
            "timestamp": ts_str,
        }

        if self.format == "slack":
            return self._to_slack_blocks(base)
        return base

    def _to_slack_blocks(self, data: dict) -> dict:
        """Convert structural metadata to Slack Block Kit format."""
        status = data.get("status", "unknown")
        agent = data.get("agent_id", "unknown")
        fp = (data.get("fingerprint_hash") or "")[:16]
        run_id = (data.get("run_id") or "")[:8]

        return {
            "blocks": [
                {
                    "type": "header",
                    "text": {
                        "type": "plain_text",
                        "text": f"Spooled: {agent}",
                    },
                },
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": (
                            f"*Status:* {status}\n" f"*Fingerprint:* `{fp}`\n" f"*Run:* `{run_id}`"
                        ),
                    },
                },
            ]
        }

    # ------------------------------------------------------------------
    # Delivery
    # ------------------------------------------------------------------

    def _send(self, url: str, payload: dict) -> None:
        """POST with retry and exponential backoff."""
        import requests  # lazy import to keep sdk lightweight

        for attempt in range(self.max_retries):
            try:
                resp = requests.post(url, json=payload, timeout=self.timeout)
                resp.raise_for_status()
                return
            except Exception as exc:
                if attempt < self.max_retries - 1:
                    time.sleep(2**attempt)  # 1s, 2s, 4s
                else:
                    logger.warning(
                        "Webhook delivery failed",
                        url=url,
                        error=str(exc),
                    )
