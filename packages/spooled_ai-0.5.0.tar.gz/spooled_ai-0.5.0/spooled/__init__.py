"""Spooled SDK - Flight Recorder for AI Agents.

Zero-friction SDK to capture execution traces in production.

Usage:
    # Decorator-first (recommended):
    import spooled

    @spooled.trace(agent_id="my_agent")
    def run_agent(query: str):
        result = client.chat.completions.create(...)
        score = fetch_score(user_id)
        return result

    @spooled.tool()
    def fetch_score(user_id: str) -> dict:
        return db.query(...)

    # With explicit client wrappers (no monkey-patching):
    from spooled.wrappers import wrap_openai
    client = wrap_openai(openai.Client())

    # Auto-instrumentation (legacy, conflicts with other tools):
    spooled.init(agent_id="my_agent", auto_instrument=True)

    # Manual control (still supported):
    from spooled import start_trace, stop_trace
    recorder = start_trace("my_agent")
    recorder.record_interaction(...)
    stop_trace()
"""

from __future__ import annotations

import atexit
import logging
import os
from typing import Any, Optional

# Default SDK logging to WARNING so users don't see debug/info noise.
# Override with SPOOLED_LOG_LEVEL=DEBUG for troubleshooting.
_log_level = os.getenv("SPOOLED_LOG_LEVEL", "WARNING").upper()

_spooled_logger = logging.getLogger("spooled")
_spooled_logger.setLevel(getattr(logging, _log_level, logging.WARNING))
if not _spooled_logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setFormatter(logging.Formatter("%(message)s"))
    _spooled_logger.addHandler(_handler)
    _spooled_logger.propagate = False

import structlog

structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.dev.ConsoleRenderer(),
    ],
    wrapper_class=structlog.stdlib.BoundLogger,
    logger_factory=structlog.stdlib.LoggerFactory(),
)

from spooled.decorators import observe, tool, trace
from spooled.recorder import Recorder, get_recorder, start_trace, stop_trace

__version__ = "0.5.0"
__all__ = [
    "init",
    "shutdown",
    "spawn",
    "trace",
    "tool",
    "observe",
    "Recorder",
    "start_trace",
    "stop_trace",
    "get_recorder",
]


def init(
    agent_id: str | None = None,
    *,
    session_id: str | None = None,
    parent_run_id: str | None = None,
    correlation_context: dict[str, str] | None = None,
    sample_rate: float | None = None,
    tags: list | None = None,
    exporters: list | None = None,
    **kwargs: Any,
) -> Recorder:
    """Initialize Spooled and start a global recorder.

    Use explicit client wrappers for auto-capturing LLM calls:

        from spooled.wrappers import wrap_openai
        client = wrap_openai(openai.Client())

    Or use decorators for your own functions:

        @spooled.trace(agent_id="my_agent")
        def run_agent(query):
            ...

    Args:
        agent_id: Optional identifier for your agent. Defaults to SPOOLED_AGENT_ID
                  env var, or "default" if not set.
        session_id: Correlation ID for multi-agent sessions
        parent_run_id: run_id of the parent trace that spawned this one
        correlation_context: Serializable dict with session_id, parent_run_id, depth
        sample_rate: Fraction of runs to record (0.0–1.0). Defaults to
                     SPOOLED_SAMPLE_RATE env var, or 1.0 (record all runs).
        tags: Tags for fleet grouping (e.g., ["payments", "v2"]).
              Defaults to SPOOLED_AGENT_TAGS env var (comma-separated).
        exporters: Optional list of exporter instances (e.g., SpooledOTELExporter).
                   Each exporter receives callbacks on interaction recording and trace end.
        **kwargs: Additional arguments passed to Recorder (buffer_size, flush_interval, etc.)

    Returns:
        The Recorder instance (can be ignored for simple usage)

    Example:
        import spooled
        from spooled.wrappers import wrap_openai

        spooled.init(agent_id="my_agent")
        client = wrap_openai(openai.Client())
        # ... use client normally ...
        spooled.shutdown()
    """
    import structlog
    from dotenv import load_dotenv

    # Load .env at init time, not import time — importing spooled should
    # not have side effects like reading files or mutating os.environ.
    load_dotenv()

    logger = structlog.get_logger(__name__)

    # Check for an active parent recorder — auto-inherit linkage for
    # multi-agent workflows where a child calls init() without knowing
    # about the parent.
    from spooled._context import get_current_recorder
    from spooled.recorder import _global_recorder

    parent_recorder = get_current_recorder() or _global_recorder
    if parent_recorder is not None and parent_run_id is None:
        # There's an active recorder — this is a nested init (child agent).
        # Inherit parent linkage instead of destroying the parent.
        parent_run_id = parent_recorder.run_id
        session_id = session_id or parent_recorder.session_id
        logger.info(
            "spooled.init() inheriting parent context",
            parent_run_id=parent_run_id,
            session_id=session_id,
        )

    # Resolve agent_id: explicit > env var > default
    resolved_agent_id = agent_id or os.getenv("SPOOLED_AGENT_ID", "default")

    # Create and start the recorder
    recorder = start_trace(
        agent_id=resolved_agent_id,
        install_hooks=False,  # We'll handle hooks ourselves for more control
        session_id=session_id,
        parent_run_id=parent_run_id,
        correlation_context=correlation_context,
        sample_rate=sample_rate,
        tags=tags,
        exporters=exporters,
        **kwargs,
    )

    # Register atexit handler to flush traces if the user forgets to call shutdown()
    atexit.register(_atexit_shutdown)

    # Log privacy posture so users and auditors can see what flows where
    _log_privacy_posture(recorder, logger)

    return recorder


def _log_privacy_posture(recorder: Recorder, logger: Any) -> None:
    """Log a clear summary of what data goes where."""
    backend_configured = bool(recorder.backend_url and recorder.backend_url.strip())

    logger.info(
        "Spooled privacy posture",
        agent_id=recorder.agent_id,
        local_storage=recorder.local_storage_enabled,
        backend_url=recorder.backend_url if backend_configured else "(none — local only)",
        capture_mode="structure-only (content is never captured)",
        data_sent_to_backend=(
            "structural metadata only (hashes, types, latencies)"
            if backend_configured
            else "nothing — no backend configured"
        ),
    )


def shutdown(success: bool = True) -> None:
    """Shutdown Spooled and flush all captured data.

    Safe to call multiple times — subsequent calls are no-ops.
    If the current context has a child recorder (from spawn() or nested
    init()), shuts down the child only — the parent stays active.

    Args:
        success: Whether the agent run was successful (affects trace status)

    Example:
        import spooled
       spooled.init()

        try:
            run_agent()
           spooled.shutdown(success=True)
        except Exception:
           spooled.shutdown(success=False)
            raise
    """
    from spooled._context import get_current_recorder
    from spooled.recorder import _global_recorder

    ctx_recorder = get_current_recorder()
    active = ctx_recorder or _global_recorder
    if active is None:
        return  # Already shut down or never initialized

    from spooled.models import TraceStatus

    status = TraceStatus.SUCCESS if success else TraceStatus.FAILURE
    stop_trace(status=status)


def _atexit_shutdown() -> None:
    """Atexit handler — flushes traces if the user forgot to call shutdown()."""
    try:
        from spooled.recorder import _global_recorder

        if _global_recorder is not None:
            shutdown(success=True)
    except Exception:
        pass  # Never raise during interpreter shutdown


def spawn(agent_id: str, **kwargs: Any) -> Recorder:
    """Spawn a child recorder from the current active recorder.

    The child inherits the session context (session_id, parent_run_id)
    but gets its own run_id, hash chain, and flush thread.
    The child is started and set as the active context-var recorder
    so that subsequent wrap_openai() calls route to it.

    Args:
        agent_id: User-defined identifier for the child agent
        **kwargs: Additional arguments passed to Recorder.__init__

    Returns:
        A new Recorder linked to the parent via session_id and parent_run_id

    Raises:
        RuntimeError: If no active recorder exists (call init() first)
    """
    from spooled._context import get_current_recorder, set_current_recorder
    from spooled.recorder import _global_recorder

    parent = get_current_recorder() or _global_recorder
    if parent is None:
        raise RuntimeError("No active recorder. Call spooled.init() first.")

    child = parent.spawn(agent_id, **kwargs)
    child.start()
    set_current_recorder(child)
    return child


def _install_all_hooks(recorder: Recorder, logger: Any) -> None:
    """Install all available auto-instrumentation hooks."""
    from spooled.hooks import install_all_hooks

    install_all_hooks(recorder)
