"""Hook for intercepting HTTP requests via the requests library.

This module implements monkey-patching for the requests library to capture
HTTP requests made by agents (e.g., API calls, web scraping, etc.).
"""

from __future__ import annotations

import functools
from collections.abc import Callable
from typing import Any

import structlog

logger = structlog.get_logger(__name__)

# Store original methods for restoration
_original_methods: dict[str, Callable] = {}
_hook_installed = False


def install_requests_hook(recorder: Any) -> None:
    """Install monkey-patch for requests library.

    This intercepts calls to requests.get(), requests.post(), etc. and records them.

    Args:
        recorder: The Recorder instance to use for capturing interactions
    """
    global _hook_installed

    if _hook_installed:
        logger.warning("Requests hook already installed")
        return

    try:
        import requests  # noqa: F401
        from requests.adapters import HTTPAdapter  # noqa: F401
        from requests.sessions import Session

        # Patch Session.request() which is the core method used by all requests methods
        if hasattr(Session, "request"):
            original_request = Session.request
            _original_methods["session_request"] = original_request

            @functools.wraps(original_request)
            def patched_request(self: Any, method: str, url: str, *args: Any, **kwargs: Any) -> Any:
                """Intercept Session.request() calls."""
                return _intercept_request(
                    recorder, original_request, self, method, url, *args, **kwargs
                )

            Session.request = patched_request

        _hook_installed = True
        logger.info("Requests hook installed", recorder_run_id=recorder.run_id)

    except ImportError:
        logger.debug("requests library not found, hook not installed")
    except Exception as e:
        logger.exception("Failed to install requests hook", error=str(e))
        raise


def uninstall_requests_hook() -> None:
    """Remove the requests monkey-patch."""
    global _hook_installed

    if not _hook_installed:
        return

    try:
        from requests.sessions import Session

        if "session_request" in _original_methods:
            Session.request = _original_methods["session_request"]

        _original_methods.clear()
        _hook_installed = False
        logger.info("Requests hook uninstalled")

    except Exception as e:
        logger.exception("Failed to uninstall requests hook", error=str(e))


def _intercept_request(
    recorder: Any,
    original_method: Callable,
    session: Any,
    method: str,
    url: str,
    *args: Any,
    **kwargs: Any,
) -> Any:
    """Intercept an HTTP request.

    Args:
        recorder: The Recorder instance
        original_method: The original Session.request method
        session: The Session instance
        method: HTTP method (GET, POST, etc.)
        url: Request URL
        *args: Additional positional arguments
        **kwargs: Additional keyword arguments

    Returns:
        The Response object from the original method
    """
    import time
    from datetime import datetime, timezone

    from spooled.models import InteractionType

    start_time = time.time()

    # Structure-only: capture HTTP method, URL, and content-length — never body content
    request_data: dict[str, Any] = {
        "method": method.upper(),
        "url": url,
    }

    try:
        # Call the original method
        response = original_method(session, method, url, *args, **kwargs)

        latency_ms = (time.time() - start_time) * 1000

        # Skip recording HTTP calls to the Spooled backend (housekeeping only)
        if getattr(recorder, "is_backend_url", None) and recorder.is_backend_url(url):
            return response

        # Structure-only: capture status and content-length, never response body
        response_data = {
            "status_code": response.status_code,
            "content_length": len(response.content) if hasattr(response, "content") else None,
        }

        # Record the interaction
        recorder.record_interaction(
            interaction_type=InteractionType.HTTP_REQUEST,
            input_data=request_data,
            output_data=response_data,
            metadata={
                "latency_ms": latency_ms,
                "status_code": response.status_code,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        )

        return response

    except Exception as e:
        latency_ms = (time.time() - start_time) * 1000
        error_msg = str(e)

        # Skip recording HTTP calls to the Spooled backend
        if getattr(recorder, "is_backend_url", None) and recorder.is_backend_url(url):
            raise

        # Record the error
        recorder.record_interaction(
            interaction_type=InteractionType.HTTP_REQUEST,
            input_data=request_data,
            error=error_msg,
            metadata={
                "latency_ms": latency_ms,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        )

        raise
