"""Hooks for intercepting library calls (OpenAI, Anthropic, Bedrock, requests, etc.).

Provides a central registry for installing/uninstalling all hooks.
"""

from __future__ import annotations

from typing import Any

import structlog

logger = structlog.get_logger(__name__)

# Hook registry: (module_path, install_func_name, uninstall_func_name, display_name)
_HOOK_REGISTRY = [
    ("spooled.hooks.openai_hook", "install_openai_hook", "uninstall_openai_hook", "OpenAI"),
    (
        "spooled.hooks.anthropic_hook",
        "install_anthropic_hook",
        "uninstall_anthropic_hook",
        "Anthropic",
    ),
    ("spooled.hooks.requests_hook", "install_requests_hook", "uninstall_requests_hook", "requests"),
    ("spooled.hooks.httpx_hook", "install_httpx_hook", "uninstall_httpx_hook", "httpx"),
    ("spooled.hooks.aiohttp_hook", "install_aiohttp_hook", "uninstall_aiohttp_hook", "aiohttp"),
    ("spooled.hooks.bedrock_hook", "install_bedrock_hook", "uninstall_bedrock_hook", "Bedrock"),
]


def install_all_hooks(recorder: Any) -> None:
    """Install all available auto-instrumentation hooks.

    Silently skips hooks whose libraries are not installed.
    Never raises — hook failures should not break the user's code.
    """
    import importlib

    for module_path, install_name, _, display_name in _HOOK_REGISTRY:
        try:
            mod = importlib.import_module(module_path)
            install_fn = getattr(mod, install_name)
            install_fn(recorder)
        except ImportError:
            logger.debug(f"{display_name} not installed, skipping hook")
        except Exception as e:
            logger.warning(f"Failed to install {display_name} hook", error=str(e))


def uninstall_all_hooks() -> None:
    """Uninstall all currently active hooks.

    Silently skips hooks that were never installed.
    Never raises — hook failures should not break the user's code.
    """
    import importlib

    for module_path, _, uninstall_name, display_name in _HOOK_REGISTRY:
        try:
            mod = importlib.import_module(module_path)
            uninstall_fn = getattr(mod, uninstall_name)
            uninstall_fn()
        except Exception as e:
            logger.warning(f"Failed to uninstall {display_name} hook", error=str(e))


# Re-export individual hooks for backward compatibility
from spooled.hooks.aiohttp_hook import install_aiohttp_hook, uninstall_aiohttp_hook
from spooled.hooks.anthropic_hook import install_anthropic_hook, uninstall_anthropic_hook
from spooled.hooks.bedrock_hook import install_bedrock_hook, uninstall_bedrock_hook
from spooled.hooks.httpx_hook import install_httpx_hook, uninstall_httpx_hook
from spooled.hooks.openai_hook import install_openai_hook, uninstall_openai_hook
from spooled.hooks.requests_hook import install_requests_hook, uninstall_requests_hook

__all__ = [
    "install_all_hooks",
    "uninstall_all_hooks",
    "install_openai_hook",
    "uninstall_openai_hook",
    "install_anthropic_hook",
    "uninstall_anthropic_hook",
    "install_bedrock_hook",
    "uninstall_bedrock_hook",
    "install_requests_hook",
    "uninstall_requests_hook",
    "install_httpx_hook",
    "uninstall_httpx_hook",
    "install_aiohttp_hook",
    "uninstall_aiohttp_hook",
]
