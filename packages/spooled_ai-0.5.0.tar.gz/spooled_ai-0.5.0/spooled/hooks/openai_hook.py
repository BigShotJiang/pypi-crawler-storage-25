"""Hook for intercepting OpenAI API calls (v1+).

This module implements monkey-patching for OpenAI Python SDK v1.0.0+.
It intercepts both sync and async calls, including streaming responses.
"""

from __future__ import annotations

import functools
import json
from collections.abc import Callable
from typing import Any

import structlog

from spooled.hooks._privacy import (
    redact_messages,
    redact_output,
)

logger = structlog.get_logger(__name__)

# Store original methods for restoration
_original_methods: dict[str, Callable] = {}
_hook_installed = False

# Re-entrancy guard: prevent infinite recursion when both wrapper and hook
# are active (e.g., streaming calls that reconstruct responses internally).
import threading

_intercepting = threading.local()


def install_openai_hook(recorder: Any) -> None:
    """Install monkey-patch for OpenAI library (v1+).

    This intercepts calls to client.chat.completions.create() and records them.

    Args:
        recorder: The Recorder instance to use for capturing interactions
    """
    global _hook_installed

    if _hook_installed:
        logger.warning("OpenAI hook already installed")
        return

    try:
        import openai  # noqa: F401
        from openai.resources.chat import completions

        # Patch synchronous method
        if hasattr(completions.Completions, "create"):
            original_sync = completions.Completions.create
            _original_methods["sync_create"] = original_sync

            @functools.wraps(original_sync)
            def patched_create(self: Any, *args: Any, **kwargs: Any) -> Any:
                """Intercept sync chat completion creation."""
                from spooled.recorder import get_recorder

                active = get_recorder()
                if active is None:
                    return original_sync(self, *args, **kwargs)
                return _intercept_call(active, original_sync, self, *args, **kwargs)

            completions.Completions.create = patched_create

        # Patch asynchronous method
        if hasattr(completions.AsyncCompletions, "create"):
            original_async = completions.AsyncCompletions.create
            _original_methods["async_create"] = original_async

            @functools.wraps(original_async)
            async def patched_create_async(self: Any, *args: Any, **kwargs: Any) -> Any:
                """Intercept async chat completion creation."""
                from spooled.recorder import get_recorder

                active = get_recorder()
                if active is None:
                    return await original_async(self, *args, **kwargs)
                return await _intercept_call_async(active, original_async, self, *args, **kwargs)

            completions.AsyncCompletions.create = patched_create_async

        _hook_installed = True
        logger.info("OpenAI hook installed", recorder_run_id=recorder.run_id)

    except ImportError:
        logger.debug("OpenAI library not found, hook not installed")
    except Exception as e:
        logger.exception("Failed to install OpenAI hook", error=str(e))
        raise


def uninstall_openai_hook() -> None:
    """Remove the OpenAI monkey-patch."""
    global _hook_installed

    if not _hook_installed:
        return

    try:
        from openai.resources.chat import completions

        if "sync_create" in _original_methods:
            completions.Completions.create = _original_methods["sync_create"]

        if "async_create" in _original_methods:
            completions.AsyncCompletions.create = _original_methods["async_create"]

        _original_methods.clear()
        _hook_installed = False
        logger.info("OpenAI hook uninstalled")

    except Exception as e:
        logger.exception("Failed to uninstall OpenAI hook", error=str(e))


def _extract_output_shape(content: str) -> dict[str, Any]:
    """Extract structural shape from a tool result content string.

    Tries to parse as JSON and extracts top-level keys and value types.
    Never stores raw values — only structure.

    Args:
        content: The tool result content string

    Returns:
        Dict with output_keys, output_types, and content_length
    """
    shape: dict[str, Any] = {"content_length": len(content) if content else 0}
    if not content:
        return shape
    try:
        parsed = json.loads(content)
        if isinstance(parsed, dict):
            keys = sorted(parsed.keys())
            shape["output_keys"] = keys
            type_map = {}
            for k, v in parsed.items():
                if v is None:
                    type_map[k] = "null"
                elif isinstance(v, bool):
                    type_map[k] = "bool"
                elif isinstance(v, int):
                    type_map[k] = "int"
                elif isinstance(v, float):
                    type_map[k] = "float"
                elif isinstance(v, str):
                    type_map[k] = "str"
                elif isinstance(v, list):
                    type_map[k] = "list"
                elif isinstance(v, dict):
                    type_map[k] = "dict"
                else:
                    type_map[k] = "other"
            shape["output_types"] = type_map
    except (json.JSONDecodeError, TypeError, ValueError):
        pass
    return shape


def _extract_and_enrich_tool_results(recorder: Any, messages: list) -> None:
    """Scan messages for tool results and enrich prior TOOL_CALL interactions.

    In OpenAI's function calling flow, Call N records TOOL_CALL with output=None.
    Call N+1's messages contain role:"tool" with tool_call_id and the result.
    We extract the structural shape BEFORE redaction.

    Args:
        recorder: The Recorder instance
        messages: The messages list from the current API call kwargs
    """
    if not messages or not hasattr(recorder, "enrich_tool_result"):
        return
    for msg in messages:
        if not isinstance(msg, dict):
            continue
        if msg.get("role") != "tool":
            continue
        tool_call_id = msg.get("tool_call_id")
        content = msg.get("content", "")
        if tool_call_id and content:
            shape = _extract_output_shape(str(content))
            recorder.enrich_tool_result(tool_call_id, shape)


def _intercept_call(
    recorder: Any, original_method: Callable, instance: Any, *args: Any, **kwargs: Any
) -> Any:
    """Intercept a synchronous OpenAI API call.

    Includes a re-entrancy guard to prevent infinite recursion when both
    the wrapper and the global hook are active on the same call chain.
    """
    # Re-entrancy guard
    if getattr(_intercepting, "active", False):
        return original_method(instance, *args, **kwargs)
    _intercepting.active = True
    try:
        return _intercept_call_inner(recorder, original_method, instance, *args, **kwargs)
    finally:
        _intercepting.active = False


def _intercept_call_inner(
    recorder: Any, original_method: Callable, instance: Any, *args: Any, **kwargs: Any
) -> Any:
    """Inner intercept logic, protected by re-entrancy guard."""
    import time
    from datetime import datetime, timezone

    from spooled.models import InteractionType

    start_time = time.time()

    # Extract request data
    messages = kwargs.get("messages", [])

    # Enrich prior TOOL_CALL interactions with results from this call's messages
    # Must happen BEFORE redaction so we can parse raw tool result content
    _extract_and_enrich_tool_results(recorder, messages)

    # Always strip content for privacy
    messages = redact_messages(messages)

    request_data = {
        "model": kwargs.get("model", "unknown"),
        "messages": messages,
        "temperature": kwargs.get("temperature"),
        "max_tokens": kwargs.get("max_tokens"),
        "stream": kwargs.get("stream", False),
    }

    try:
        # Call the original method
        response = original_method(instance, *args, **kwargs)

        latency_ms = (time.time() - start_time) * 1000

        # Handle streaming responses
        if kwargs.get("stream", False):
            # Wrap the stream to capture content
            response = _wrap_stream(recorder, response, request_data, latency_ms)
        else:
            # Extract response data
            response_data = _extract_response_data(response)
            response_data = redact_output(response_data)

            # Record the interaction
            recorder.record_interaction(
                interaction_type=InteractionType.LLM_CALL,
                input_data=request_data,
                output_data=response_data,
                metadata={
                    "latency_ms": latency_ms,
                    "model": request_data["model"],
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                },
            )

            # If this was a function-calling turn, record each requested tool
            _record_tool_calls_from_response(recorder, response)

        return response

    except Exception as e:
        latency_ms = (time.time() - start_time) * 1000
        error_msg = str(e)

        # Record the error
        recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data=request_data,
            error=error_msg,
            metadata={
                "latency_ms": latency_ms,
                "model": request_data["model"],
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        )

        raise


async def _intercept_call_async(
    recorder: Any, original_method: Callable, instance: Any, *args: Any, **kwargs: Any
) -> Any:
    """Intercept an asynchronous OpenAI API call.

    Args:
        recorder: The Recorder instance
        original_method: The original async method to call
        instance: The instance (self) for the method
        *args: Positional arguments
        **kwargs: Keyword arguments

    Returns:
        The response from the original method
    """
    import time
    from datetime import datetime, timezone

    from spooled.models import InteractionType

    start_time = time.time()

    # Extract request data
    messages = kwargs.get("messages", [])

    # Enrich prior TOOL_CALL interactions with results from this call's messages
    # Must happen BEFORE redaction so we can parse raw tool result content
    _extract_and_enrich_tool_results(recorder, messages)

    # Always strip content for privacy
    messages = redact_messages(messages)

    request_data = {
        "model": kwargs.get("model", "unknown"),
        "messages": messages,
        "temperature": kwargs.get("temperature"),
        "max_tokens": kwargs.get("max_tokens"),
        "stream": kwargs.get("stream", False),
    }

    try:
        # Call the original method
        response = await original_method(instance, *args, **kwargs)

        latency_ms = (time.time() - start_time) * 1000

        # Handle streaming responses
        if kwargs.get("stream", False):
            # Wrap the async stream to capture content
            response = _wrap_stream_async(recorder, response, request_data, latency_ms)
        else:
            # Extract response data
            response_data = _extract_response_data(response)
            response_data = redact_output(response_data)

            # Record the interaction
            recorder.record_interaction(
                interaction_type=InteractionType.LLM_CALL,
                input_data=request_data,
                output_data=response_data,
                metadata={
                    "latency_ms": latency_ms,
                    "model": request_data["model"],
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                },
            )

            # If this was a function-calling turn, record each requested tool
            _record_tool_calls_from_response(recorder, response)

        return response

    except Exception as e:
        latency_ms = (time.time() - start_time) * 1000
        error_msg = str(e)

        # Record the error
        recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data=request_data,
            error=error_msg,
            metadata={
                "latency_ms": latency_ms,
                "model": request_data["model"],
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        )

        raise


def _record_tool_calls_from_response(recorder: Any, response: Any) -> None:
    """Extract and record TOOL_CALL interactions from a function-calling response.

    When the LLM responds with finish_reason="tool_calls", we record each
    requested tool as a separate TOOL_CALL interaction immediately after the
    LLM_CALL. This gives auto-instrumented agents the same rich structural
    fingerprints as manually-instrumented ones.

    Parallel-aware: when multiple tool_calls appear in a single completion,
    they share the same parallel_group ID for deterministic fingerprinting.

    Args:
        recorder: The Recorder instance
        response: The ChatCompletion response object
    """
    import uuid
    from datetime import datetime, timezone

    from spooled.models import InteractionType

    try:
        choices = getattr(response, "choices", []) or []
        for choice in choices:
            if getattr(choice, "finish_reason", None) != "tool_calls":
                continue
            message = getattr(choice, "message", None)
            tool_calls = getattr(message, "tool_calls", None) or []

            # Assign a shared parallel_group when multiple tool calls are requested
            parallel_group = None
            if len(tool_calls) > 1:
                parallel_group = str(uuid.uuid4())

            for tc in tool_calls:
                func = getattr(tc, "function", None)
                if not func:
                    continue
                tool_name = getattr(func, "name", "unknown")
                args_str = getattr(func, "arguments", "{}")
                try:
                    tool_args = json.loads(args_str)
                except Exception:
                    tool_args = {"_raw": args_str}

                # Pass parallel_group for concurrent tool calls
                record_kwargs = {
                    "interaction_type": InteractionType.TOOL_CALL,
                    "input_data": {
                        "function": tool_name,
                        "arguments": tool_args,
                        "call_id": getattr(tc, "id", None),
                    },
                    "output_data": None,
                    "metadata": {
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                        "source": "openai_function_calling",
                    },
                }
                if parallel_group is not None:
                    record_kwargs["parallel_group"] = parallel_group

                recorder.record_interaction(**record_kwargs)
    except Exception as e:
        logger.debug("Failed to extract tool calls from OpenAI response", error=str(e))


def _extract_response_data(response: Any) -> dict[str, Any]:
    """Extract response data from OpenAI ChatCompletion object.

    Args:
        response: The ChatCompletion response object

    Returns:
        Dictionary containing response data
    """
    try:
        # Handle Pydantic models (OpenAI v1+)
        if hasattr(response, "model_dump"):
            data = response.model_dump()
        elif hasattr(response, "dict"):
            data = response.dict()
        else:
            # Fallback to attributes
            data = {
                "id": getattr(response, "id", None),
                "model": getattr(response, "model", None),
                "choices": [
                    {
                        "index": getattr(choice, "index", None),
                        "message": {
                            "role": getattr(choice.message, "role", None),
                            "content": getattr(choice.message, "content", None),
                        },
                        "finish_reason": getattr(choice, "finish_reason", None),
                    }
                    for choice in getattr(response, "choices", [])
                ],
                "usage": (
                    {
                        "prompt_tokens": getattr(response.usage, "prompt_tokens", None),
                        "completion_tokens": getattr(response.usage, "completion_tokens", None),
                        "total_tokens": getattr(response.usage, "total_tokens", None),
                    }
                    if hasattr(response, "usage")
                    else None
                ),
            }

        return data

    except Exception as e:
        logger.warning("Failed to extract response data", error=str(e))
        return {"error": f"Failed to extract: {str(e)}"}


def _wrap_stream(recorder: Any, stream: Any, request_data: dict, latency_ms: float) -> Any:
    """Wrap a streaming response to capture content.

    This implements the "Tee" generator pattern: yields tokens immediately
    while buffering for logging.

    Args:
        recorder: The Recorder instance
        stream: The streaming response generator
        request_data: The original request data
        latency_ms: Latency in milliseconds

    Returns:
        A generator that yields chunks while logging
    """
    from datetime import datetime, timezone

    from spooled.models import InteractionType

    content_buffer: list[str] = []
    tool_calls_buffer: dict[int, dict[str, str]] = {}
    first_chunk_time = None
    stream_start = None
    finish_reason = None

    def wrapped_generator() -> Any:
        nonlocal first_chunk_time, stream_start, finish_reason
        import time

        if stream_start is None:
            stream_start = time.time()

        try:
            for chunk in stream:
                # Record time to first token
                if first_chunk_time is None:
                    first_chunk_time = time.time()

                # Extract content and tool_calls from chunk
                if hasattr(chunk, "choices") and chunk.choices:
                    choice = chunk.choices[0]
                    delta = choice.delta
                    if choice.finish_reason:
                        finish_reason = choice.finish_reason
                    if hasattr(delta, "content") and delta.content:
                        content_buffer.append(delta.content)
                    # Accumulate tool_calls across chunks
                    if hasattr(delta, "tool_calls") and delta.tool_calls:
                        for tc in delta.tool_calls:
                            idx = tc.index
                            if idx not in tool_calls_buffer:
                                tool_calls_buffer[idx] = {
                                    "id": "",
                                    "name": "",
                                    "arguments": "",
                                }
                            if tc.id:
                                tool_calls_buffer[idx]["id"] = tc.id
                            if tc.function:
                                if tc.function.name:
                                    tool_calls_buffer[idx]["name"] = tc.function.name
                                if tc.function.arguments:
                                    tool_calls_buffer[idx]["arguments"] += tc.function.arguments

                yield chunk

        finally:
            ttft_ms = (
                (first_chunk_time - stream_start) * 1000
                if first_chunk_time and stream_start
                else None
            )

            # Build tool_calls list for the response data
            accumulated_tool_calls = []
            for idx in sorted(tool_calls_buffer):
                tc = tool_calls_buffer[idx]
                accumulated_tool_calls.append(
                    {
                        "id": tc["id"],
                        "type": "function",
                        "function": {"name": tc["name"], "arguments": tc["arguments"]},
                    }
                )

            # Record the LLM_CALL interaction with accumulated content + tool_calls
            response_data = {
                "content": "".join(content_buffer) or None,
                "stream": True,
                "chunks": len(content_buffer),
                "finish_reason": finish_reason,
            }
            if accumulated_tool_calls:
                response_data["tool_calls"] = accumulated_tool_calls

            response_data = redact_output(response_data)

            recorder.record_interaction(
                interaction_type=InteractionType.LLM_CALL,
                input_data=request_data,
                output_data=response_data,
                metadata={
                    "latency_ms": latency_ms,
                    "ttft_ms": ttft_ms,
                    "model": request_data["model"],
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                },
            )

            # Record each tool_call as a separate TOOL_CALL interaction
            # so the fingerprint includes them (same as non-streaming path).
            for tc in accumulated_tool_calls:
                try:
                    args = json.loads(tc["function"]["arguments"])
                except (json.JSONDecodeError, KeyError):
                    args = {}
                recorder.record_interaction(
                    interaction_type=InteractionType.TOOL_CALL,
                    input_data={
                        "function": tc["function"]["name"],
                        "call_id": tc.get("id"),
                        **args,
                    },
                    output_data=None,  # Tool result recorded later via enrich
                    metadata={
                        "model": request_data["model"],
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    },
                )

    return wrapped_generator()


async def _wrap_stream_async(
    recorder: Any, stream: Any, request_data: dict, latency_ms: float
) -> Any:
    """Wrap an async streaming response to capture content.

    Args:
        recorder: The Recorder instance
        stream: The async streaming response
        request_data: The original request data
        latency_ms: Latency in milliseconds

    Returns:
        An async generator that yields chunks while logging
    """
    from datetime import datetime, timezone

    from spooled.models import InteractionType

    buffer = []
    first_chunk_time = None
    stream_start = None

    async def wrapped_async_generator() -> Any:
        nonlocal first_chunk_time, stream_start
        import time

        if stream_start is None:
            stream_start = time.time()

        try:
            async for chunk in stream:
                # Record time to first token
                if first_chunk_time is None:
                    first_chunk_time = time.time()
                    ttft_ms = (first_chunk_time - stream_start) * 1000
                else:
                    ttft_ms = None

                # Extract content from chunk
                if hasattr(chunk, "choices") and chunk.choices:
                    delta = chunk.choices[0].delta
                    if hasattr(delta, "content") and delta.content:
                        buffer.append(delta.content)

                yield chunk

        except StopAsyncIteration:
            pass
        finally:
            # Log the complete stream
            full_content = "".join(buffer)
            response_data = {
                "content": full_content,
                "stream": True,
                "chunks": len(buffer),
            }

            response_data = redact_output(response_data)

            ttft_ms = (first_chunk_time - stream_start) * 1000 if first_chunk_time else None

            recorder.record_interaction(
                interaction_type=InteractionType.LLM_CALL,
                input_data=request_data,
                output_data=response_data,
                metadata={
                    "latency_ms": latency_ms,
                    "ttft_ms": ttft_ms,
                    "model": request_data["model"],
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                },
            )

    return wrapped_async_generator()
