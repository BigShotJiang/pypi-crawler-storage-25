"""Privacy helpers: content is ALWAYS stripped from captured data.

Spooled is structure-only by architecture. These helpers replace prompt content,
system prompts, and LLM output with SHA-256 hash placeholders. This preserves
structural metadata (model, token counts, stop reason) while ensuring content
is never stored — not locally, not in transit, not anywhere.

This is not a toggle. There is no opt-in to content capture.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any


def _hash_content(data: Any) -> str:
    """SHA-256 hash of JSON-serialized data."""
    serialized = json.dumps(data, sort_keys=True, ensure_ascii=False, default=_json_default)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def _json_default(obj: Any) -> Any:
    """JSON fallback for Pydantic models and other non-serializable objects."""
    if hasattr(obj, "model_dump"):
        return obj.model_dump(mode="json")
    if hasattr(obj, "dict"):
        return obj.dict()
    if isinstance(obj, (set, frozenset)):
        return sorted(obj)
    if isinstance(obj, bytes):
        return obj.hex()
    return str(obj)


def redact_messages(messages: list | Any) -> list[dict[str, Any]]:
    """Replace a messages list with a single hash placeholder.

    Args:
        messages: List of message dicts (OpenAI/Anthropic format)

    Returns:
        Single-element list with role="redacted" and content_hash
    """
    if not messages:
        return messages
    return [{"role": "redacted", "content_hash": _hash_content(messages)}]


def redact_system_prompt(system: Any) -> dict[str, str] | None:
    """Replace a system prompt (string or list) with a hash placeholder.

    Args:
        system: System prompt string or list of content blocks

    Returns:
        Dict with redacted marker and hash, or None if no system prompt
    """
    if system is None:
        return None
    return {"redacted": True, "content_hash": _hash_content(system)}


def redact_output(output_data: dict[str, Any]) -> dict[str, Any]:
    """Redact LLM output content while preserving structural metadata.

    Preserves: id, model, usage, stop_reason, finish_reason, role, stream, chunks
    Replaces: content, choices, text with hash placeholders.

    Args:
        output_data: Parsed response dict from any LLM provider

    Returns:
        New dict with content fields replaced by hashes
    """
    if not output_data:
        return output_data

    # Keys that are safe to pass through (structural metadata)
    PASSTHROUGH_KEYS = {
        "id",
        "model",
        "usage",
        "stop_reason",
        "finish_reason",
        "role",
        "stream",
        "chunks",
        "object",
        "created",
        "system_fingerprint",
        "type",
    }

    result: dict[str, Any] = {}

    for key, value in output_data.items():
        if key in PASSTHROUGH_KEYS:
            result[key] = value
        elif key == "choices":
            # OpenAI format: redact message content inside choices
            result[key] = _redact_choices(value)
        elif key == "content":
            # Anthropic/Bedrock format: content can be string or list of blocks
            result[key] = {"redacted": True, "content_hash": _hash_content(value)}
        else:
            # Any other key with potential content — hash it
            result[key] = {"redacted": True, "content_hash": _hash_content(value)}

    return result


def _redact_choices(choices: Any) -> Any:
    """Redact content within OpenAI-style choices list."""
    if not isinstance(choices, list):
        return {"redacted": True, "content_hash": _hash_content(choices)}

    redacted = []
    for choice in choices:
        if not isinstance(choice, dict):
            redacted.append({"redacted": True, "content_hash": _hash_content(choice)})
            continue

        new_choice: dict[str, Any] = {}
        for k, v in choice.items():
            if k in ("index", "finish_reason", "logprobs"):
                new_choice[k] = v
            elif k == "message":
                # Preserve role and tool_calls structure, redact content
                new_choice[k] = _redact_message(v)
            elif k == "delta":
                new_choice[k] = _redact_message(v)
            else:
                new_choice[k] = {"redacted": True, "content_hash": _hash_content(v)}
        redacted.append(new_choice)

    return redacted


def _redact_message(message: Any) -> Any:
    """Redact content in an OpenAI message dict while keeping role and tool_calls structure."""
    if not isinstance(message, dict):
        return {"redacted": True, "content_hash": _hash_content(message)}

    result: dict[str, Any] = {}
    for k, v in message.items():
        if k == "role":
            result[k] = v
        elif k == "tool_calls":
            # Preserve tool call structure (name, id) but redact arguments
            result[k] = _redact_tool_calls(v)
        elif k == "content":
            if v is not None:
                result[k] = {"redacted": True, "content_hash": _hash_content(v)}
            else:
                result[k] = None
        elif k == "function_call":
            result[k] = {"redacted": True, "content_hash": _hash_content(v)}
        else:
            result[k] = v  # refusal, name, etc.
    return result


def _redact_tool_calls(tool_calls: Any) -> Any:
    """Preserve tool call structure but redact arguments."""
    if not isinstance(tool_calls, list):
        return tool_calls

    redacted = []
    for tc in tool_calls:
        if not isinstance(tc, dict):
            redacted.append(tc)
            continue
        new_tc = dict(tc)
        if "function" in new_tc and isinstance(new_tc["function"], dict):
            func = dict(new_tc["function"])
            if "arguments" in func:
                func["arguments"] = {
                    "redacted": True,
                    "content_hash": _hash_content(func["arguments"]),
                }
            new_tc["function"] = func
        redacted.append(new_tc)
    return redacted
