"""Hook for intercepting HTTP requests via the aiohttp library.

This module implements monkey-patching for aiohttp.ClientSession requests to capture
HTTP requests made by agents.
"""

from __future__ import annotations

import functools
from collections.abc import Callable
from typing import Any

import structlog

logger = structlog.get_logger(__name__)

_original_methods: dict[str, Callable] = {}
_hook_installed = False


def install_aiohttp_hook(recorder: Any) -> None:
    """Install monkey-patch for aiohttp library.

    Args:
        recorder: The Recorder instance to use for capturing interactions
    """
    global _hook_installed

    if _hook_installed:
        logger.warning("aiohttp hook already installed")
        return

    try:
        import aiohttp

        if hasattr(aiohttp.ClientSession, "_request"):
            original_request = aiohttp.ClientSession._request
            _original_methods["client_request"] = original_request

            @functools.wraps(original_request)
            async def patched_request(
                self: Any, method: str, url: Any, *args: Any, **kwargs: Any
            ) -> Any:
                return await _intercept_request(
                    recorder, original_request, self, method, url, *args, **kwargs
                )

            aiohttp.ClientSession._request = patched_request

        _hook_installed = True
        logger.info("aiohttp hook installed", recorder_run_id=recorder.run_id)

    except ImportError:
        logger.debug("aiohttp library not found, hook not installed")
    except Exception as e:
        logger.exception("Failed to install aiohttp hook", error=str(e))
        raise


def uninstall_aiohttp_hook() -> None:
    """Remove the aiohttp monkey-patch."""
    global _hook_installed

    if not _hook_installed:
        return

    try:
        import aiohttp

        if "client_request" in _original_methods:
            aiohttp.ClientSession._request = _original_methods["client_request"]

        _original_methods.clear()
        _hook_installed = False
        logger.info("aiohttp hook uninstalled")

    except Exception as e:
        logger.exception("Failed to uninstall aiohttp hook", error=str(e))


async def _intercept_request(
    recorder: Any,
    original_method: Callable,
    session: Any,
    method: str,
    url: Any,
    *args: Any,
    **kwargs: Any,
) -> Any:
    import time
    from datetime import datetime, timezone

    from spooled.models import InteractionType

    start_time = time.time()

    # Structure-only: capture HTTP method and URL — never body content
    request_data: dict[str, Any] = {
        "method": str(method).upper(),
        "url": str(url),
    }

    try:
        response = await original_method(session, method, url, *args, **kwargs)

        latency_ms = (time.time() - start_time) * 1000
        if getattr(recorder, "is_backend_url", None) and recorder.is_backend_url(str(url)):
            return response
        response_data = {
            "status_code": getattr(response, "status", None),
        }

        _record = getattr(recorder, "arecord_interaction", None)
        if _record is not None:
            await _record(
                interaction_type=InteractionType.HTTP_REQUEST,
                input_data=request_data,
                output_data=response_data,
                metadata={
                    "latency_ms": latency_ms,
                    "status_code": response_data.get("status_code"),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                },
            )
        else:
            recorder.record_interaction(
                interaction_type=InteractionType.HTTP_REQUEST,
                input_data=request_data,
                output_data=response_data,
                metadata={
                    "latency_ms": latency_ms,
                    "status_code": response_data.get("status_code"),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                },
            )

        return response

    except Exception as e:
        latency_ms = (time.time() - start_time) * 1000
        if getattr(recorder, "is_backend_url", None) and recorder.is_backend_url(str(url)):
            raise
        error_meta = {
            "latency_ms": latency_ms,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "error_type": type(e).__name__,
        }
        _record = getattr(recorder, "arecord_interaction", None)
        if _record is not None:
            await _record(
                interaction_type=InteractionType.HTTP_REQUEST,
                input_data=request_data,
                metadata=error_meta,
            )
        else:
            recorder.record_interaction(
                interaction_type=InteractionType.HTTP_REQUEST,
                input_data=request_data,
                metadata=error_meta,
            )
        raise
