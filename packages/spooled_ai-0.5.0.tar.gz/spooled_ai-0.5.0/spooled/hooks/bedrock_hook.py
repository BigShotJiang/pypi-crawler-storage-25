"""Hook for intercepting AWS Bedrock Runtime API calls.

This module implements monkey-patching for boto3's bedrock-runtime client.
It intercepts invoke_model, invoke_model_with_response_stream, converse,
and converse_stream calls, recording them as LLM_CALL interactions.

Supports multi-provider body formats: Anthropic/Claude, Meta/Llama, and Cohere.
"""

from __future__ import annotations

import functools
import json
import time
from collections.abc import Callable
from datetime import datetime, timezone
from typing import Any

import structlog

from spooled.hooks._privacy import redact_messages, redact_output, redact_system_prompt

logger = structlog.get_logger(__name__)

# Store original methods for restoration
_original_methods: dict[str, Callable] = {}
_hook_installed = False


def install_bedrock_hook(recorder: Any) -> None:
    """Install monkey-patch for AWS Bedrock Runtime client.

    This intercepts calls to bedrock-runtime client methods and records them.

    Args:
        recorder: The Recorder instance to use for capturing interactions
    """
    global _hook_installed

    if _hook_installed:
        logger.warning("Bedrock hook already installed")
        return

    try:
        import botocore.client

        original_create_client = botocore.client.ClientCreator.create_client
        _original_methods["create_client"] = original_create_client

        @functools.wraps(original_create_client)
        def patched_create_client(self: Any, *args: Any, **kwargs: Any) -> Any:
            """Intercept client creation to patch bedrock-runtime clients."""
            client = original_create_client(self, *args, **kwargs)

            # Determine service name from args
            # ClientCreator.create_client signature:
            #   create_client(service_model, region_name, is_secure, ...)
            # service_model.service_name gives us the service
            service_name = None
            if args:
                service_model = args[0]
                if hasattr(service_model, "service_name"):
                    service_name = service_model.service_name

            if service_name == "bedrock-runtime":
                _patch_bedrock_client(client, recorder)

            return client

        botocore.client.ClientCreator.create_client = patched_create_client

        _hook_installed = True
        logger.info("Bedrock hook installed", recorder_run_id=recorder.run_id)

    except ImportError:
        logger.debug("boto3/botocore not found, Bedrock hook not installed")
    except Exception as e:
        logger.exception("Failed to install Bedrock hook", error=str(e))
        raise


def uninstall_bedrock_hook() -> None:
    """Remove the Bedrock monkey-patch."""
    global _hook_installed

    if not _hook_installed:
        return

    try:
        import botocore.client

        if "create_client" in _original_methods:
            botocore.client.ClientCreator.create_client = _original_methods["create_client"]

        _original_methods.clear()
        _hook_installed = False
        logger.info("Bedrock hook uninstalled")

    except Exception as e:
        logger.exception("Failed to uninstall Bedrock hook", error=str(e))


def _patch_bedrock_client(client: Any, recorder: Any) -> None:
    """Patch a bedrock-runtime client instance with recording wrappers.

    Args:
        client: The boto3 bedrock-runtime client instance
        recorder: The Recorder instance
    """
    methods_to_patch = [
        ("invoke_model", _intercept_invoke_model),
        ("invoke_model_with_response_stream", _intercept_invoke_model_with_response_stream),
        ("converse", _intercept_converse),
        ("converse_stream", _intercept_converse_stream),
    ]

    for method_name, interceptor in methods_to_patch:
        if hasattr(client, method_name):
            original = getattr(client, method_name)
            _original_methods[f"client_{method_name}"] = original

            # Use a factory to capture the correct interceptor and original
            wrapped = _make_wrapper(original, interceptor, recorder)
            setattr(client, method_name, wrapped)


def _make_wrapper(original: Callable, interceptor: Callable, recorder: Any) -> Callable:
    """Create a wrapper function that calls the interceptor with the original method.

    Args:
        original: The original boto3 method
        interceptor: The interceptor function
        recorder: The Recorder instance

    Returns:
        Wrapped callable
    """

    @functools.wraps(original)
    def wrapper(**kwargs: Any) -> Any:
        return interceptor(recorder, original, **kwargs)

    return wrapper


# ---------------------------------------------------------------------------
# Body parsers for multi-provider invoke_model format
# ---------------------------------------------------------------------------


def _parse_invoke_body(body_str: str, model_id: str) -> dict[str, Any]:
    """Parse the JSON body from invoke_model for different providers.

    Extracts prompt/messages, model parameters, and any token info from the
    provider-specific body format.

    Args:
        body_str: The JSON-encoded body string
        model_id: The Bedrock modelId (e.g. "anthropic.claude-3-sonnet-...")

    Returns:
        Parsed request data dict
    """
    try:
        body = json.loads(body_str)
    except (json.JSONDecodeError, TypeError):
        return {"model": model_id, "raw_body": body_str}

    provider = _detect_provider(model_id)

    if provider == "anthropic":
        return _parse_anthropic_body(body, model_id)
    elif provider == "meta":
        return _parse_meta_body(body, model_id)
    elif provider == "cohere":
        return _parse_cohere_body(body, model_id)
    else:
        # Generic fallback
        return {
            "model": model_id,
            "provider": provider,
            "body": body,
        }


def _detect_provider(model_id: str) -> str:
    """Detect the provider from a Bedrock model ID.

    Args:
        model_id: e.g. "anthropic.claude-3-sonnet-20240229-v1:0"

    Returns:
        Provider name string
    """
    model_lower = model_id.lower()
    if model_lower.startswith("anthropic.") or "claude" in model_lower:
        return "anthropic"
    elif model_lower.startswith("meta.") or "llama" in model_lower:
        return "meta"
    elif model_lower.startswith("cohere.") or "command" in model_lower:
        return "cohere"
    elif model_lower.startswith("amazon.") or "titan" in model_lower:
        return "amazon"
    elif model_lower.startswith("ai21.") or "jamba" in model_lower:
        return "ai21"
    elif model_lower.startswith("mistral."):
        return "mistral"
    else:
        return "unknown"


def _parse_anthropic_body(body: dict, model_id: str) -> dict[str, Any]:
    """Parse Anthropic/Claude invoke_model body format.

    Body format:
        {
            "anthropic_version": "bedrock-2023-10-25",
            "messages": [...],
            "max_tokens": 1024,
            "temperature": 0.7,
            "system": "..."
        }
    """
    messages = body.get("messages", [])
    system = body.get("system")
    messages = redact_messages(messages)
    system = redact_system_prompt(system)

    return {
        "model": model_id,
        "provider": "anthropic",
        "messages": messages,
        "max_tokens": body.get("max_tokens"),
        "temperature": body.get("temperature"),
        "system": system,
        "anthropic_version": body.get("anthropic_version"),
    }


def _parse_meta_body(body: dict, model_id: str) -> dict[str, Any]:
    """Parse Meta/Llama invoke_model body format.

    Body format:
        {
            "prompt": "...",
            "max_gen_len": 512,
            "temperature": 0.7,
            "top_p": 0.9
        }
    """
    from spooled.hooks._privacy import _hash_content

    prompt = body.get("prompt", "")
    prompt = {"redacted": True, "content_hash": _hash_content(prompt)}

    return {
        "model": model_id,
        "provider": "meta",
        "prompt": prompt,
        "max_gen_len": body.get("max_gen_len"),
        "temperature": body.get("temperature"),
        "top_p": body.get("top_p"),
    }


def _parse_cohere_body(body: dict, model_id: str) -> dict[str, Any]:
    """Parse Cohere invoke_model body format.

    Body format:
        {
            "prompt": "...",
            "max_tokens": 400,
            "temperature": 0.75,
            "p": 0.01,
            "k": 0
        }
    """
    from spooled.hooks._privacy import _hash_content

    prompt = body.get("prompt", "")
    prompt = {"redacted": True, "content_hash": _hash_content(prompt)}

    return {
        "model": model_id,
        "provider": "cohere",
        "prompt": prompt,
        "max_tokens": body.get("max_tokens"),
        "temperature": body.get("temperature"),
    }


def _parse_invoke_response(response_body_str: str, model_id: str) -> dict[str, Any]:
    """Parse the response body from invoke_model for different providers.

    Args:
        response_body_str: The JSON-encoded response body
        model_id: The Bedrock modelId

    Returns:
        Parsed response data dict
    """
    try:
        body = json.loads(response_body_str)
    except (json.JSONDecodeError, TypeError):
        return {"raw_body": response_body_str}

    provider = _detect_provider(model_id)

    if provider == "anthropic":
        return _parse_anthropic_response(body)
    elif provider == "meta":
        return _parse_meta_response(body)
    elif provider == "cohere":
        return _parse_cohere_response(body)
    else:
        return body


def _parse_anthropic_response(body: dict) -> dict[str, Any]:
    """Parse Anthropic/Claude invoke_model response.

    Response format:
        {
            "id": "msg_...",
            "type": "message",
            "role": "assistant",
            "content": [{"type": "text", "text": "..."}],
            "stop_reason": "end_turn",
            "usage": {"input_tokens": 25, "output_tokens": 150}
        }
    """
    content_blocks = body.get("content", [])
    text_parts = []
    for block in content_blocks:
        if isinstance(block, dict) and block.get("type") == "text":
            text_parts.append(block.get("text", ""))

    return {
        "id": body.get("id"),
        "model": body.get("model"),
        "role": body.get("role"),
        "content": "\n".join(text_parts),
        "stop_reason": body.get("stop_reason"),
        "usage": body.get("usage"),
    }


def _parse_meta_response(body: dict) -> dict[str, Any]:
    """Parse Meta/Llama invoke_model response.

    Response format:
        {
            "generation": "...",
            "prompt_token_count": 15,
            "generation_token_count": 100,
            "stop_reason": "stop"
        }
    """
    return {
        "content": body.get("generation", ""),
        "usage": {
            "input_tokens": body.get("prompt_token_count"),
            "output_tokens": body.get("generation_token_count"),
        },
        "stop_reason": body.get("stop_reason"),
    }


def _parse_cohere_response(body: dict) -> dict[str, Any]:
    """Parse Cohere invoke_model response.

    Response format:
        {
            "generations": [{"text": "...", "finish_reason": "COMPLETE"}],
            ...
        }
    """
    generations = body.get("generations", [])
    text = generations[0].get("text", "") if generations else ""
    finish_reason = generations[0].get("finish_reason") if generations else None

    return {
        "content": text,
        "finish_reason": finish_reason,
    }


# ---------------------------------------------------------------------------
# Token usage extraction
# ---------------------------------------------------------------------------


def _extract_token_usage(response_data: dict[str, Any], model_id: str) -> dict[str, Any]:
    """Extract token usage from parsed response data.

    Args:
        response_data: Parsed response dict
        model_id: The Bedrock modelId

    Returns:
        Dict with input_tokens, output_tokens, total_tokens (if available)
    """
    usage = response_data.get("usage", {})
    if not usage or not isinstance(usage, dict):
        return {}

    result: dict[str, Any] = {}
    input_tokens = usage.get("input_tokens") or usage.get("prompt_token_count")
    output_tokens = usage.get("output_tokens") or usage.get("generation_token_count")

    if input_tokens is not None:
        result["input_tokens"] = input_tokens
    if output_tokens is not None:
        result["output_tokens"] = output_tokens
    if input_tokens is not None and output_tokens is not None:
        result["total_tokens"] = input_tokens + output_tokens

    return result


# ---------------------------------------------------------------------------
# Interceptors
# ---------------------------------------------------------------------------


def _intercept_invoke_model(recorder: Any, original_method: Callable, **kwargs: Any) -> Any:
    """Intercept invoke_model calls.

    Args:
        recorder: The Recorder instance
        original_method: The original invoke_model method
        **kwargs: Keyword arguments passed to invoke_model
    """
    from spooled.models import InteractionType

    start_time = time.time()
    model_id = kwargs.get("modelId", "unknown")

    # Parse request body
    body_str = kwargs.get("body", "{}")
    if isinstance(body_str, bytes):
        body_str = body_str.decode("utf-8")
    request_data = _parse_invoke_body(body_str, model_id)

    try:
        response = original_method(**kwargs)
        latency_ms = (time.time() - start_time) * 1000

        # Read the response body
        response_body_bytes = response.get("body", b"")
        if hasattr(response_body_bytes, "read"):
            response_body_str = response_body_bytes.read().decode("utf-8")
            # Re-wrap the body so the caller can still read it
            import io

            response["body"] = io.BytesIO(response_body_str.encode("utf-8"))
        else:
            response_body_str = (
                response_body_bytes.decode("utf-8")
                if isinstance(response_body_bytes, bytes)
                else str(response_body_bytes)
            )

        response_data = _parse_invoke_response(response_body_str, model_id)
        token_usage = _extract_token_usage(response_data, model_id)

        response_data = redact_output(response_data)

        recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data=request_data,
            output_data=response_data,
            metadata={
                "source": "bedrock",
                "latency_ms": latency_ms,
                "model": model_id,
                "provider": _detect_provider(model_id),
                "timestamp": datetime.now(timezone.utc).isoformat(),
                **token_usage,
            },
        )

        return response

    except Exception as e:
        latency_ms = (time.time() - start_time) * 1000
        recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data=request_data,
            error=str(e),
            metadata={
                "source": "bedrock",
                "latency_ms": latency_ms,
                "model": model_id,
                "provider": _detect_provider(model_id),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        )
        raise


def _intercept_invoke_model_with_response_stream(
    recorder: Any, original_method: Callable, **kwargs: Any
) -> Any:
    """Intercept invoke_model_with_response_stream calls.

    Args:
        recorder: The Recorder instance
        original_method: The original method
        **kwargs: Keyword arguments
    """
    from spooled.models import InteractionType

    start_time = time.time()
    model_id = kwargs.get("modelId", "unknown")

    # Parse request body
    body_str = kwargs.get("body", "{}")
    if isinstance(body_str, bytes):
        body_str = body_str.decode("utf-8")
    request_data = _parse_invoke_body(body_str, model_id)

    try:
        response = original_method(**kwargs)
        latency_ms = (time.time() - start_time) * 1000

        # Wrap the EventStream to capture chunks
        event_stream = response.get("body")
        if event_stream is not None:
            response["body"] = _wrap_invoke_stream(
                recorder, event_stream, request_data, model_id, latency_ms
            )

        return response

    except Exception as e:
        latency_ms = (time.time() - start_time) * 1000
        recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data=request_data,
            error=str(e),
            metadata={
                "source": "bedrock",
                "latency_ms": latency_ms,
                "model": model_id,
                "provider": _detect_provider(model_id),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        )
        raise


def _intercept_converse(recorder: Any, original_method: Callable, **kwargs: Any) -> Any:
    """Intercept converse calls.

    Args:
        recorder: The Recorder instance
        original_method: The original converse method
        **kwargs: Keyword arguments
    """
    from spooled.models import InteractionType

    start_time = time.time()
    model_id = kwargs.get("modelId", "unknown")

    messages = kwargs.get("messages", [])
    system = kwargs.get("system")
    messages = redact_messages(messages)
    system = redact_system_prompt(system)

    request_data = {
        "model": model_id,
        "provider": _detect_provider(model_id),
        "messages": messages,
        "system": system,
        "inferenceConfig": kwargs.get("inferenceConfig"),
        "toolConfig": kwargs.get("toolConfig"),
    }

    try:
        response = original_method(**kwargs)
        latency_ms = (time.time() - start_time) * 1000

        response_data = _extract_converse_response(response)
        token_usage = _extract_converse_token_usage(response)

        response_data = redact_output(response_data)

        recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data=request_data,
            output_data=response_data,
            metadata={
                "source": "bedrock",
                "latency_ms": latency_ms,
                "model": model_id,
                "provider": _detect_provider(model_id),
                "timestamp": datetime.now(timezone.utc).isoformat(),
                **token_usage,
            },
        )

        return response

    except Exception as e:
        latency_ms = (time.time() - start_time) * 1000
        recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data=request_data,
            error=str(e),
            metadata={
                "source": "bedrock",
                "latency_ms": latency_ms,
                "model": model_id,
                "provider": _detect_provider(model_id),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        )
        raise


def _intercept_converse_stream(recorder: Any, original_method: Callable, **kwargs: Any) -> Any:
    """Intercept converse_stream calls.

    Args:
        recorder: The Recorder instance
        original_method: The original converse_stream method
        **kwargs: Keyword arguments
    """
    from spooled.models import InteractionType

    start_time = time.time()
    model_id = kwargs.get("modelId", "unknown")

    messages = kwargs.get("messages", [])
    system = kwargs.get("system")
    messages = redact_messages(messages)
    system = redact_system_prompt(system)

    request_data = {
        "model": model_id,
        "provider": _detect_provider(model_id),
        "messages": messages,
        "system": system,
        "inferenceConfig": kwargs.get("inferenceConfig"),
        "toolConfig": kwargs.get("toolConfig"),
    }

    try:
        response = original_method(**kwargs)
        latency_ms = (time.time() - start_time) * 1000

        # Wrap the stream to capture events
        stream = response.get("stream")
        if stream is not None:
            response["stream"] = _wrap_converse_stream(
                recorder, stream, request_data, model_id, latency_ms
            )

        return response

    except Exception as e:
        latency_ms = (time.time() - start_time) * 1000
        recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data=request_data,
            error=str(e),
            metadata={
                "source": "bedrock",
                "latency_ms": latency_ms,
                "model": model_id,
                "provider": _detect_provider(model_id),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        )
        raise


# ---------------------------------------------------------------------------
# Converse response helpers
# ---------------------------------------------------------------------------


def _extract_converse_response(response: dict) -> dict[str, Any]:
    """Extract response data from a converse API response.

    Args:
        response: The converse API response dict

    Returns:
        Parsed response data
    """
    try:
        output = response.get("output", {})
        message = output.get("message", {})
        content_blocks = message.get("content", [])

        text_parts = []
        for block in content_blocks:
            if isinstance(block, dict) and "text" in block:
                text_parts.append(block["text"])

        return {
            "role": message.get("role"),
            "content": "\n".join(text_parts),
            "stop_reason": response.get("stopReason"),
            "usage": response.get("usage"),
        }
    except Exception as e:
        logger.warning("Failed to extract converse response", error=str(e))
        return {"error": f"Failed to extract: {str(e)}"}


def _extract_converse_token_usage(response: dict) -> dict[str, Any]:
    """Extract token usage from a converse API response.

    Args:
        response: The converse API response dict

    Returns:
        Dict with token counts
    """
    usage = response.get("usage", {})
    if not usage:
        return {}

    result: dict[str, Any] = {}
    input_tokens = usage.get("inputTokens")
    output_tokens = usage.get("outputTokens")
    total_tokens = usage.get("totalTokens")

    if input_tokens is not None:
        result["input_tokens"] = input_tokens
    if output_tokens is not None:
        result["output_tokens"] = output_tokens
    if total_tokens is not None:
        result["total_tokens"] = total_tokens
    elif input_tokens is not None and output_tokens is not None:
        result["total_tokens"] = input_tokens + output_tokens

    return result


# ---------------------------------------------------------------------------
# Stream wrappers
# ---------------------------------------------------------------------------


def _wrap_invoke_stream(
    recorder: Any,
    event_stream: Any,
    request_data: dict,
    model_id: str,
    latency_ms: float,
) -> Any:
    """Wrap an invoke_model_with_response_stream EventStream to capture chunks.

    Args:
        recorder: The Recorder instance
        event_stream: The boto3 EventStream
        request_data: The parsed request data
        model_id: The Bedrock modelId
        latency_ms: Time-to-first-byte latency

    Returns:
        A generator that yields events while recording
    """
    from spooled.models import InteractionType

    buffer = []
    first_chunk_time = None
    stream_start = time.time()

    def wrapped_generator() -> Any:
        nonlocal first_chunk_time

        try:
            for event in event_stream:
                if first_chunk_time is None:
                    first_chunk_time = time.time()

                # Extract chunk data from the event
                chunk = event.get("chunk", {})
                chunk_bytes = chunk.get("bytes", b"")
                if chunk_bytes:
                    try:
                        chunk_data = json.loads(chunk_bytes.decode("utf-8"))
                        # Anthropic streaming format
                        if "completion" in chunk_data:
                            buffer.append(chunk_data["completion"])
                        elif "delta" in chunk_data:
                            delta = chunk_data["delta"]
                            if isinstance(delta, dict) and "text" in delta:
                                buffer.append(delta["text"])
                        # Meta/Llama streaming format
                        elif "generation" in chunk_data:
                            buffer.append(chunk_data["generation"])
                    except (json.JSONDecodeError, UnicodeDecodeError):
                        pass

                yield event

        finally:
            full_content = "".join(buffer)
            response_data = {
                "content": full_content,
                "stream": True,
                "chunks": len(buffer),
            }

            response_data = redact_output(response_data)

            ttft_ms = (first_chunk_time - stream_start) * 1000 if first_chunk_time else None

            recorder.record_interaction(
                interaction_type=InteractionType.LLM_CALL,
                input_data=request_data,
                output_data=response_data,
                metadata={
                    "source": "bedrock",
                    "latency_ms": latency_ms,
                    "ttft_ms": ttft_ms,
                    "model": model_id,
                    "provider": _detect_provider(model_id),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                },
            )

    return wrapped_generator()


def _wrap_converse_stream(
    recorder: Any,
    event_stream: Any,
    request_data: dict,
    model_id: str,
    latency_ms: float,
) -> Any:
    """Wrap a converse_stream EventStream to capture text deltas.

    Args:
        recorder: The Recorder instance
        event_stream: The boto3 EventStream from converse_stream
        request_data: The parsed request data
        model_id: The Bedrock modelId
        latency_ms: Initial latency

    Returns:
        A generator that yields events while recording
    """
    from spooled.models import InteractionType

    buffer = []
    first_chunk_time = None
    stream_start = time.time()
    usage_data: dict[str, Any] = {}

    def wrapped_generator() -> Any:
        nonlocal first_chunk_time, usage_data

        try:
            for event in event_stream:
                if first_chunk_time is None:
                    first_chunk_time = time.time()

                # converse_stream events have specific shapes
                if "contentBlockDelta" in event:
                    delta = event["contentBlockDelta"].get("delta", {})
                    text = delta.get("text", "")
                    if text:
                        buffer.append(text)

                # Capture usage metadata from the final event
                if "metadata" in event:
                    meta = event["metadata"]
                    if "usage" in meta:
                        usage_data = meta["usage"]

                yield event

        finally:
            full_content = "".join(buffer)

            token_usage: dict[str, Any] = {}
            if usage_data:
                input_t = usage_data.get("inputTokens")
                output_t = usage_data.get("outputTokens")
                if input_t is not None:
                    token_usage["input_tokens"] = input_t
                if output_t is not None:
                    token_usage["output_tokens"] = output_t
                if input_t is not None and output_t is not None:
                    token_usage["total_tokens"] = input_t + output_t

            response_data = {
                "content": full_content,
                "stream": True,
                "chunks": len(buffer),
            }

            response_data = redact_output(response_data)

            ttft_ms = (first_chunk_time - stream_start) * 1000 if first_chunk_time else None

            recorder.record_interaction(
                interaction_type=InteractionType.LLM_CALL,
                input_data=request_data,
                output_data=response_data,
                metadata={
                    "source": "bedrock",
                    "latency_ms": latency_ms,
                    "ttft_ms": ttft_ms,
                    "model": model_id,
                    "provider": _detect_provider(model_id),
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    **token_usage,
                },
            )

    return wrapped_generator()
