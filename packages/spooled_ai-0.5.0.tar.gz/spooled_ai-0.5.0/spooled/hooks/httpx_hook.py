"""Hook for intercepting HTTP requests via the httpx library.

This module implements monkey-patching for httpx.Client and httpx.AsyncClient
requests to capture HTTP requests made by agents.
"""

from __future__ import annotations

import functools
from collections.abc import Callable
from typing import Any

import structlog

logger = structlog.get_logger(__name__)

_original_methods: dict[str, Callable] = {}
_hook_installed = False


def install_httpx_hook(recorder: Any) -> None:
    """Install monkey-patch for httpx library.

    Args:
        recorder: The Recorder instance to use for capturing interactions
    """
    global _hook_installed

    if _hook_installed:
        logger.warning("httpx hook already installed")
        return

    try:
        import httpx

        if hasattr(httpx.Client, "request"):
            original_request = httpx.Client.request
            _original_methods["client_request"] = original_request

            @functools.wraps(original_request)
            def patched_request(self: Any, method: str, url: Any, *args: Any, **kwargs: Any) -> Any:
                return _intercept_request(
                    recorder, original_request, self, method, url, *args, **kwargs
                )

            httpx.Client.request = patched_request

        if hasattr(httpx.AsyncClient, "request"):
            original_async_request = httpx.AsyncClient.request
            _original_methods["async_client_request"] = original_async_request

            @functools.wraps(original_async_request)
            async def patched_async_request(
                self: Any, method: str, url: Any, *args: Any, **kwargs: Any
            ) -> Any:
                return await _intercept_async_request(
                    recorder, original_async_request, self, method, url, *args, **kwargs
                )

            httpx.AsyncClient.request = patched_async_request

        _hook_installed = True
        logger.info("httpx hook installed", recorder_run_id=recorder.run_id)

    except ImportError:
        logger.debug("httpx library not found, hook not installed")
    except Exception as e:
        logger.exception("Failed to install httpx hook", error=str(e))
        raise


def uninstall_httpx_hook() -> None:
    """Remove the httpx monkey-patch."""
    global _hook_installed

    if not _hook_installed:
        return

    try:
        import httpx

        if "client_request" in _original_methods:
            httpx.Client.request = _original_methods["client_request"]

        if "async_client_request" in _original_methods:
            httpx.AsyncClient.request = _original_methods["async_client_request"]

        _original_methods.clear()
        _hook_installed = False
        logger.info("httpx hook uninstalled")

    except Exception as e:
        logger.exception("Failed to uninstall httpx hook", error=str(e))


def _intercept_request(
    recorder: Any,
    original_method: Callable,
    client: Any,
    method: str,
    url: Any,
    *args: Any,
    **kwargs: Any,
) -> Any:
    import time
    from datetime import datetime, timezone

    from spooled.models import InteractionType

    start_time = time.time()

    # Structure-only: capture HTTP method and URL — never body content
    request_data: dict[str, Any] = {
        "method": str(method).upper(),
        "url": str(url),
    }

    try:
        response = original_method(client, method, url, *args, **kwargs)

        latency_ms = (time.time() - start_time) * 1000
        if getattr(recorder, "is_backend_url", None) and recorder.is_backend_url(str(url)):
            return response

        response_data = {
            "status_code": response.status_code,
            "content_length": len(response.content) if hasattr(response, "content") else None,
        }

        recorder.record_interaction(
            interaction_type=InteractionType.HTTP_REQUEST,
            input_data=request_data,
            output_data=response_data,
            metadata={
                "latency_ms": latency_ms,
                "status_code": response.status_code,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        )

        return response

    except Exception as e:
        latency_ms = (time.time() - start_time) * 1000
        if getattr(recorder, "is_backend_url", None) and recorder.is_backend_url(str(url)):
            raise
        recorder.record_interaction(
            interaction_type=InteractionType.HTTP_REQUEST,
            input_data=request_data,
            metadata={
                "latency_ms": latency_ms,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "error_type": type(e).__name__,
            },
        )
        raise


async def _intercept_async_request(
    recorder: Any,
    original_method: Callable,
    client: Any,
    method: str,
    url: Any,
    *args: Any,
    **kwargs: Any,
) -> Any:
    import time
    from datetime import datetime, timezone

    from spooled.models import InteractionType

    start_time = time.time()

    request_data: dict[str, Any] = {
        "method": str(method).upper(),
        "url": str(url),
    }

    try:
        response = await original_method(client, method, url, *args, **kwargs)

        latency_ms = (time.time() - start_time) * 1000
        if getattr(recorder, "is_backend_url", None) and recorder.is_backend_url(str(url)):
            return response

        response_data = {
            "status_code": response.status_code,
            "content_length": len(response.content) if hasattr(response, "content") else None,
        }

        recorder.record_interaction(
            interaction_type=InteractionType.HTTP_REQUEST,
            input_data=request_data,
            output_data=response_data,
            metadata={
                "latency_ms": latency_ms,
                "status_code": response.status_code,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        )

        return response

    except Exception as e:
        latency_ms = (time.time() - start_time) * 1000
        if getattr(recorder, "is_backend_url", None) and recorder.is_backend_url(str(url)):
            raise
        recorder.record_interaction(
            interaction_type=InteractionType.HTTP_REQUEST,
            input_data=request_data,
            metadata={
                "latency_ms": latency_ms,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "error_type": type(e).__name__,
            },
        )
        raise
