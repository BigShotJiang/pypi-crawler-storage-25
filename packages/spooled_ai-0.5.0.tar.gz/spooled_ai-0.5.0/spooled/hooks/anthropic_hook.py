"""Hook for intercepting Anthropic API calls.

This module implements monkey-patching for Anthropic Python SDK.
It intercepts both sync and async calls, including streaming responses.
"""

from __future__ import annotations

import functools
import json
import time
from collections.abc import Callable
from datetime import datetime, timezone
from typing import Any

import structlog

from spooled.hooks._privacy import redact_messages, redact_output, redact_system_prompt

logger = structlog.get_logger(__name__)

# Store original methods for restoration
_original_methods: dict[str, Callable] = {}
_hook_installed = False


def install_anthropic_hook(recorder: Any) -> None:
    """Install monkey-patch for Anthropic library.

    This intercepts calls to client.messages.create() and records them.

    Args:
        recorder: The Recorder instance to use for capturing interactions
    """
    global _hook_installed

    if _hook_installed:
        logger.warning("Anthropic hook already installed")
        return

    try:
        import anthropic  # noqa: F401
        from anthropic.resources import messages

        # Patch synchronous method
        if hasattr(messages.Messages, "create"):
            original_sync = messages.Messages.create
            _original_methods["sync_create"] = original_sync

            @functools.wraps(original_sync)
            def patched_create(self: Any, *args: Any, **kwargs: Any) -> Any:
                """Intercept sync message creation."""
                return _intercept_call(recorder, original_sync, self, *args, **kwargs)

            messages.Messages.create = patched_create

        # Patch asynchronous method
        if hasattr(messages.AsyncMessages, "create"):
            original_async = messages.AsyncMessages.create
            _original_methods["async_create"] = original_async

            @functools.wraps(original_async)
            async def patched_create_async(self: Any, *args: Any, **kwargs: Any) -> Any:
                """Intercept async message creation."""
                return await _intercept_call_async(recorder, original_async, self, *args, **kwargs)

            messages.AsyncMessages.create = patched_create_async

        _hook_installed = True
        logger.info("Anthropic hook installed", recorder_run_id=recorder.run_id)

    except ImportError:
        logger.debug("Anthropic library not found, hook not installed")
    except Exception as e:
        logger.exception("Failed to install Anthropic hook", error=str(e))
        raise


def uninstall_anthropic_hook() -> None:
    """Remove the Anthropic monkey-patch."""
    global _hook_installed

    if not _hook_installed:
        return

    try:
        from anthropic.resources import messages

        if "sync_create" in _original_methods:
            messages.Messages.create = _original_methods["sync_create"]

        if "async_create" in _original_methods:
            messages.AsyncMessages.create = _original_methods["async_create"]

        _original_methods.clear()
        _hook_installed = False
        logger.info("Anthropic hook uninstalled")

    except Exception as e:
        logger.exception("Failed to uninstall Anthropic hook", error=str(e))


def _extract_output_shape(content: str) -> dict[str, Any]:
    """Extract structural shape from a tool result content string.

    Args:
        content: The tool result content string

    Returns:
        Dict with output_keys, output_types, and content_length
    """
    shape: dict[str, Any] = {"content_length": len(content) if content else 0}
    if not content:
        return shape
    try:
        parsed = json.loads(content)
        if isinstance(parsed, dict):
            keys = sorted(parsed.keys())
            shape["output_keys"] = keys
            type_map = {}
            for k, v in parsed.items():
                if v is None:
                    type_map[k] = "null"
                elif isinstance(v, bool):
                    type_map[k] = "bool"
                elif isinstance(v, int):
                    type_map[k] = "int"
                elif isinstance(v, float):
                    type_map[k] = "float"
                elif isinstance(v, str):
                    type_map[k] = "str"
                elif isinstance(v, list):
                    type_map[k] = "list"
                elif isinstance(v, dict):
                    type_map[k] = "dict"
                else:
                    type_map[k] = "other"
            shape["output_types"] = type_map
    except (json.JSONDecodeError, TypeError, ValueError):
        pass
    return shape


def _extract_and_enrich_tool_results(recorder: Any, messages: list) -> None:
    """Scan incoming messages for tool_result content blocks and enrich prior TOOL_CALL interactions.

    In Anthropic's tool use flow, the user sends back tool_result blocks with
    tool_use_id referencing the original tool_use block. We extract the structural
    shape and enrich the corresponding TOOL_CALL interaction.

    Args:
        recorder: The Recorder instance
        messages: The messages list from the current API call kwargs
    """
    if not messages or not hasattr(recorder, "enrich_tool_result"):
        return
    for msg in messages:
        if not isinstance(msg, dict):
            continue
        content = msg.get("content")
        if not isinstance(content, list):
            continue
        for block in content:
            if not isinstance(block, dict):
                continue
            if block.get("type") != "tool_result":
                continue
            tool_use_id = block.get("tool_use_id")
            result_content = block.get("content", "")
            if tool_use_id and result_content:
                if isinstance(result_content, str):
                    shape = _extract_output_shape(result_content)
                elif isinstance(result_content, list):
                    # Anthropic can return content as list of blocks
                    text_parts = []
                    for rb in result_content:
                        if isinstance(rb, dict) and rb.get("type") == "text":
                            text_parts.append(rb.get("text", ""))
                    shape = _extract_output_shape("".join(text_parts))
                else:
                    continue
                recorder.enrich_tool_result(tool_use_id, shape)


def _record_tool_calls_from_response(recorder: Any, response: Any) -> None:
    """Extract and record TOOL_CALL interactions from Anthropic tool_use response blocks.

    When the LLM responds with stop_reason="tool_use", we record each
    tool_use block as a separate TOOL_CALL interaction.

    Args:
        recorder: The Recorder instance
        response: The Anthropic Message response object
    """
    from spooled.models import InteractionType

    try:
        content = getattr(response, "content", []) or []
        for block in content:
            block_type = getattr(block, "type", None)
            if block_type != "tool_use":
                continue
            tool_name = getattr(block, "name", "unknown")
            tool_input = getattr(block, "input", {}) or {}
            call_id = getattr(block, "id", None)

            recorder.record_interaction(
                interaction_type=InteractionType.TOOL_CALL,
                input_data={
                    "function": tool_name,
                    "arguments": tool_input,
                    "call_id": call_id,
                },
                output_data=None,
                metadata={
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "source": "anthropic_tool_use",
                },
            )
    except Exception as e:
        logger.debug("Failed to extract tool_use blocks from Anthropic response", error=str(e))


def _intercept_call(
    recorder: Any, original_method: Callable, instance: Any, *args: Any, **kwargs: Any
) -> Any:
    """Intercept a synchronous Anthropic API call."""
    from spooled.models import InteractionType

    start_time = time.time()

    # Enrich prior TOOL_CALL interactions with results from this call's messages
    # Must happen BEFORE any redaction/processing
    messages = kwargs.get("messages", [])
    _extract_and_enrich_tool_results(recorder, messages)

    # Always strip content for privacy
    system = kwargs.get("system")
    messages = redact_messages(messages)
    system = redact_system_prompt(system)

    # Extract request data
    request_data = {
        "model": kwargs.get("model", "unknown"),
        "messages": messages,
        "max_tokens": kwargs.get("max_tokens"),
        "temperature": kwargs.get("temperature"),
        "system": system,
        "stream": kwargs.get("stream", False),
    }

    try:
        response = original_method(instance, *args, **kwargs)
        latency_ms = (time.time() - start_time) * 1000

        # Handle streaming responses
        if kwargs.get("stream", False):
            response = _wrap_stream(recorder, response, request_data, latency_ms)
        else:
            response_data = _extract_response_data(response)
            response_data = redact_output(response_data)
            recorder.record_interaction(
                interaction_type=InteractionType.LLM_CALL,
                input_data=request_data,
                output_data=response_data,
                metadata={
                    "latency_ms": latency_ms,
                    "model": request_data["model"],
                    "provider": "anthropic",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                },
            )

            # Record tool_use blocks as separate TOOL_CALL interactions
            _record_tool_calls_from_response(recorder, response)

        return response

    except Exception as e:
        latency_ms = (time.time() - start_time) * 1000
        recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data=request_data,
            error=str(e),
            metadata={
                "latency_ms": latency_ms,
                "model": request_data["model"],
                "provider": "anthropic",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        )
        raise


async def _intercept_call_async(
    recorder: Any, original_method: Callable, instance: Any, *args: Any, **kwargs: Any
) -> Any:
    """Intercept an asynchronous Anthropic API call."""
    from spooled.models import InteractionType

    start_time = time.time()

    # Enrich prior TOOL_CALL interactions with results from this call's messages
    messages = kwargs.get("messages", [])
    _extract_and_enrich_tool_results(recorder, messages)

    # Always strip content for privacy
    system = kwargs.get("system")
    messages = redact_messages(messages)
    system = redact_system_prompt(system)

    request_data = {
        "model": kwargs.get("model", "unknown"),
        "messages": messages,
        "max_tokens": kwargs.get("max_tokens"),
        "temperature": kwargs.get("temperature"),
        "system": system,
        "stream": kwargs.get("stream", False),
    }

    try:
        response = await original_method(instance, *args, **kwargs)
        latency_ms = (time.time() - start_time) * 1000

        if kwargs.get("stream", False):
            response = _wrap_stream_async(recorder, response, request_data, latency_ms)
        else:
            response_data = _extract_response_data(response)
            response_data = redact_output(response_data)
            _record = getattr(recorder, "arecord_interaction", None)
            if _record is not None:
                await _record(
                    interaction_type=InteractionType.LLM_CALL,
                    input_data=request_data,
                    output_data=response_data,
                    metadata={
                        "latency_ms": latency_ms,
                        "model": request_data["model"],
                        "provider": "anthropic",
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    },
                )
            else:
                recorder.record_interaction(
                    interaction_type=InteractionType.LLM_CALL,
                    input_data=request_data,
                    output_data=response_data,
                    metadata={
                        "latency_ms": latency_ms,
                        "model": request_data["model"],
                        "provider": "anthropic",
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    },
                )

            # Record tool_use blocks as separate TOOL_CALL interactions
            _record_tool_calls_from_response(recorder, response)

        return response

    except Exception as e:
        latency_ms = (time.time() - start_time) * 1000
        _record = getattr(recorder, "arecord_interaction", None)
        if _record is not None:
            await _record(
                interaction_type=InteractionType.LLM_CALL,
                input_data=request_data,
                error=str(e),
                metadata={
                    "latency_ms": latency_ms,
                    "model": request_data["model"],
                    "provider": "anthropic",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                },
            )
        else:
            recorder.record_interaction(
                interaction_type=InteractionType.LLM_CALL,
                input_data=request_data,
                error=str(e),
                metadata={
                    "latency_ms": latency_ms,
                    "model": request_data["model"],
                    "provider": "anthropic",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                },
            )
        raise


def _extract_response_data(response: Any) -> dict[str, Any]:
    """Extract response data from Anthropic Message object."""
    try:
        if hasattr(response, "model_dump"):
            data = response.model_dump()
        elif hasattr(response, "dict"):
            data = response.dict()
        else:
            # Fallback to attributes
            content_blocks = []
            for block in getattr(response, "content", []):
                if hasattr(block, "text"):
                    content_blocks.append({"type": "text", "text": block.text})
                elif hasattr(block, "type"):
                    content_blocks.append({"type": block.type})

            data = {
                "id": getattr(response, "id", None),
                "model": getattr(response, "model", None),
                "role": getattr(response, "role", None),
                "content": content_blocks,
                "stop_reason": getattr(response, "stop_reason", None),
                "usage": (
                    {
                        "input_tokens": getattr(response.usage, "input_tokens", None),
                        "output_tokens": getattr(response.usage, "output_tokens", None),
                    }
                    if hasattr(response, "usage")
                    else None
                ),
            }

        return data

    except Exception as e:
        logger.warning("Failed to extract Anthropic response data", error=str(e))
        return {"error": f"Failed to extract: {str(e)}"}


def _wrap_stream(recorder: Any, stream: Any, request_data: dict, latency_ms: float) -> Any:
    """Wrap a streaming response to capture content."""
    from spooled.models import InteractionType

    buffer = []
    first_chunk_time = None
    stream_start = time.time()

    def wrapped_generator() -> Any:
        nonlocal first_chunk_time

        try:
            for event in stream:
                if first_chunk_time is None:
                    first_chunk_time = time.time()

                # Extract text from content_block_delta events
                if hasattr(event, "type"):
                    if event.type == "content_block_delta":
                        if hasattr(event, "delta") and hasattr(event.delta, "text"):
                            buffer.append(event.delta.text)

                yield event

        finally:
            full_content = "".join(buffer)
            response_data = {
                "content": full_content,
                "stream": True,
                "chunks": len(buffer),
            }

            response_data = redact_output(response_data)

            ttft_ms = (first_chunk_time - stream_start) * 1000 if first_chunk_time else None

            recorder.record_interaction(
                interaction_type=InteractionType.LLM_CALL,
                input_data=request_data,
                output_data=response_data,
                metadata={
                    "latency_ms": latency_ms,
                    "ttft_ms": ttft_ms,
                    "model": request_data["model"],
                    "provider": "anthropic",
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                },
            )

    return wrapped_generator()


async def _wrap_stream_async(
    recorder: Any, stream: Any, request_data: dict, latency_ms: float
) -> Any:
    """Wrap an async streaming response to capture content."""
    from spooled.models import InteractionType

    buffer = []
    first_chunk_time = None
    stream_start = time.time()

    async def wrapped_async_generator() -> Any:
        nonlocal first_chunk_time

        try:
            async for event in stream:
                if first_chunk_time is None:
                    first_chunk_time = time.time()

                if hasattr(event, "type"):
                    if event.type == "content_block_delta":
                        if hasattr(event, "delta") and hasattr(event.delta, "text"):
                            buffer.append(event.delta.text)

                yield event

        finally:
            full_content = "".join(buffer)
            response_data = {
                "content": full_content,
                "stream": True,
                "chunks": len(buffer),
            }

            response_data = redact_output(response_data)

            ttft_ms = (first_chunk_time - stream_start) * 1000 if first_chunk_time else None
            _record = getattr(recorder, "arecord_interaction", None)
            if _record is not None:
                await _record(
                    interaction_type=InteractionType.LLM_CALL,
                    input_data=request_data,
                    output_data=response_data,
                    metadata={
                        "latency_ms": latency_ms,
                        "ttft_ms": ttft_ms,
                        "model": request_data["model"],
                        "provider": "anthropic",
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    },
                )
            else:
                recorder.record_interaction(
                    interaction_type=InteractionType.LLM_CALL,
                    input_data=request_data,
                    output_data=response_data,
                    metadata={
                        "latency_ms": latency_ms,
                        "ttft_ms": ttft_ms,
                        "model": request_data["model"],
                        "provider": "anthropic",
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    },
                )

    return wrapped_async_generator()
