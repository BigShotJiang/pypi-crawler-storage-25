"""Usage tracking for Spooled (Task 11.1).

Tracks traces, interactions, and CI comparisons for free tier enforcement.
Stores usage data in .spooled/usage.json with monthly rollover.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import structlog

logger = structlog.get_logger(__name__)

# Free tier limits — unlimited for local usage.
# Monetization gates on automation (ci run / GitHub Action), not usage counts.
# See docs/HOSTED_DASHBOARD_PRICING.md: "Gate on automation vs. manual, not agent count."
FREE_TIER_LIMITS: dict[str, int | None] = {
    "traces_per_month": None,
    "agents": None,
    "comparisons_per_month": None,
}


def _get_usage_file() -> Path:
    """Get the usage file path."""
    traces_dir = os.getenv("SPOOLED_TRACES_DIR", ".spooled/traces")
    base_dir = Path(traces_dir).parent
    return base_dir / "usage.json"


def _current_month_key() -> str:
    """Return the current month as YYYY-MM string."""
    return datetime.now(timezone.utc).strftime("%Y-%m")


class UsageTracker:
    """Tracks usage for free tier enforcement.

    Usage data structure:
    {
        "agent_ids": ["agent-1", "agent-2"],
        "months": {
            "2025-01": {
                "traces": 42,
                "comparisons": 10,
                "interactions": 1200
            }
        },
        "last_updated": "2025-01-15T12:00:00Z"
    }
    """

    def __init__(self, usage_file: Path | None = None) -> None:
        self._usage_file = usage_file or _get_usage_file()
        self._data: dict[str, Any] | None = None

    def _load(self) -> dict[str, Any]:
        """Load usage data from file."""
        if self._data is not None:
            return self._data

        if self._usage_file.exists():
            try:
                with open(self._usage_file) as f:
                    self._data = json.load(f)
            except (json.JSONDecodeError, OSError):
                logger.debug("Could not load usage file, starting fresh")
                self._data = self._empty_data()
        else:
            self._data = self._empty_data()

        return self._data

    def _empty_data(self) -> dict[str, Any]:
        """Return empty usage data structure."""
        return {
            "agent_ids": [],
            "months": {},
            "last_updated": datetime.now(timezone.utc).isoformat(),
        }

    def _save(self) -> None:
        """Save usage data to file."""
        if self._data is None:
            return

        self._data["last_updated"] = datetime.now(timezone.utc).isoformat()

        try:
            self._usage_file.parent.mkdir(parents=True, exist_ok=True)
            tmp = self._usage_file.with_suffix(".tmp")
            with open(tmp, "w") as f:
                json.dump(self._data, f, indent=2)
            os.replace(str(tmp), str(self._usage_file))
        except OSError as e:
            logger.debug("Could not save usage file", error=str(e))

    def _get_month(self, month_key: str | None = None) -> dict[str, int]:
        """Get or create a month's usage counters."""
        data = self._load()
        key = month_key or _current_month_key()
        if key not in data["months"]:
            data["months"][key] = {
                "traces": 0,
                "comparisons": 0,
                "interactions": 0,
            }
        return data["months"][key]

    def record_trace(self, agent_id: str) -> None:
        """Record a new trace."""
        data = self._load()
        month = self._get_month()
        month["traces"] += 1

        # Track agent_ids per month so experimenting with names
        # doesn't permanently consume the agent limit
        month_agents = month.setdefault("agent_ids", [])
        if agent_id not in month_agents:
            month_agents.append(agent_id)

        # Also maintain the global list for backwards compatibility
        if agent_id not in data["agent_ids"]:
            data["agent_ids"].append(agent_id)

        self._save()

    def record_comparison(self) -> None:
        """Record a CI comparison."""
        month = self._get_month()
        month["comparisons"] += 1
        self._save()

    def record_interactions(self, count: int) -> None:
        """Record interactions count."""
        month = self._get_month()
        month["interactions"] += count
        self._save()

    def get_current_usage(self) -> dict[str, Any]:
        """Get current month's usage stats."""
        data = self._load()
        month = self._get_month()
        # Use monthly agent_ids if available, fall back to global
        month_agents = month.get("agent_ids", data["agent_ids"])
        return {
            "traces": month["traces"],
            "comparisons": month["comparisons"],
            "interactions": month["interactions"],
            "agents": len(month_agents),
            "month": _current_month_key(),
        }

    def check_limits(self, limits: dict[str, Any] | None = None) -> dict[str, Any]:
        """Check if usage is within limits.

        Returns:
            Dict with 'within_limits' bool and details per limit.
            Limits with None values are treated as unlimited.
        """
        limits = limits or FREE_TIER_LIMITS
        usage = self.get_current_usage()

        checks = {}
        within = True

        trace_limit = limits.get("traces_per_month")
        if trace_limit is not None:
            ok = usage["traces"] < trace_limit
            checks["traces"] = {
                "current": usage["traces"],
                "limit": trace_limit,
                "ok": ok,
            }
            if not ok:
                within = False

        agent_limit = limits.get("agents")
        if agent_limit is not None:
            ok = usage["agents"] <= agent_limit
            checks["agents"] = {
                "current": usage["agents"],
                "limit": agent_limit,
                "ok": ok,
            }
            if not ok:
                within = False

        comparison_limit = limits.get("comparisons_per_month")
        if comparison_limit is not None:
            ok = usage["comparisons"] < comparison_limit
            checks["comparisons"] = {
                "current": usage["comparisons"],
                "limit": comparison_limit,
                "ok": ok,
            }
            if not ok:
                within = False

        return {
            "within_limits": within,
            "checks": checks,
            "month": usage["month"],
        }

    def reset(self) -> None:
        """Reset all usage data."""
        self._data = self._empty_data()
        self._save()
