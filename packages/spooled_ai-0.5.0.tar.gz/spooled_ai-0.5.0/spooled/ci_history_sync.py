"""Sync CI history to/from the Spooled backend API.

Provides push/pull utilities that are called by the CLI's `ci history`
command when --push or --pull flags are used.  Uses only the stdlib so
this module stays lightweight (no httpx/requests dependency at import).
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

# ─── helpers ──────────────────────────────────────────────────────────────────


def _backend_url() -> str | None:
    url = os.getenv("SPOOLED_BACKEND_URL", "").rstrip("/")
    return url if url else None


def _api_key() -> str | None:
    return (
        os.getenv("SPOOLED_API_KEY")
        or os.getenv("SPOOLED_API_KEYS", "").split(",")[0].split(":")[0].strip()
        or None
    )


def _request(
    method: str,
    url: str,
    api_key: str | None = None,
    body: dict[str, Any] | None = None,
    timeout: int = 15,
) -> tuple[int, dict[str, Any]]:
    """Minimal HTTP request helper using urllib (no third-party deps)."""
    data = json.dumps(body).encode("utf-8") if body is not None else None
    headers: dict[str, str] = {"Content-Type": "application/json", "Accept": "application/json"}
    if api_key:
        headers["x-api-key"] = api_key

    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            return resp.status, json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8") if e.fp else ""
        try:
            payload = json.loads(raw)
        except Exception:
            payload = {"error": raw or str(e)}
        return e.code, payload


# ─── public API ───────────────────────────────────────────────────────────────


def push_ci_history(
    agent_id: str,
    history_dir: Path,
    *,
    backend_url: str | None = None,
    api_key: str | None = None,
) -> tuple[bool, str]:
    """Push local CI history for *agent_id* to the backend.

    Reads ``history_dir/{agent_id}.jsonl``, sends all entries as a batch
    POST to ``/api/agents/{agent_id}/ci-history``.

    Args:
        agent_id: Agent identifier.
        history_dir: Directory containing ``*.jsonl`` history files.
        backend_url: Override backend URL (default: ``SPOOLED_BACKEND_URL`` env var).
        api_key: Override API key (default: ``SPOOLED_API_KEY`` env var).

    Returns:
        ``(success, message)`` tuple.
    """
    base = backend_url or _backend_url()
    if not base:
        return False, "SPOOLED_BACKEND_URL not set"

    key = api_key or _api_key()

    history_file = history_dir / f"{agent_id}.jsonl"
    if not history_file.exists():
        return False, f"No local history for {agent_id}"

    entries: list[dict[str, Any]] = []
    for line in history_file.read_text().splitlines():
        line = line.strip()
        if line:
            try:
                entries.append(json.loads(line))
            except Exception:
                pass

    if not entries:
        return True, "No entries to push"

    url = f"{base}/api/agents/{agent_id}/ci-history"
    status, resp = _request("POST", url, api_key=key, body={"entries": entries})
    if status in (200, 201):
        saved = resp.get("saved", len(entries))
        return True, f"Pushed {saved} entries"
    return False, f"Push failed ({status}): {resp.get('error', resp)}"


def pull_ci_history(
    agent_id: str,
    history_dir: Path,
    *,
    backend_url: str | None = None,
    api_key: str | None = None,
    since: str | None = None,
    limit: int = 500,
) -> tuple[bool, str]:
    """Pull CI history for *agent_id* from the backend and merge into local JSONL.

    Fetches entries from ``/api/agents/{agent_id}/ci-history``, deduplicates
    against the existing local file (by ``timestamp`` + ``intent_id``), and
    appends new entries.

    Args:
        agent_id: Agent identifier.
        history_dir: Directory containing ``*.jsonl`` history files.
        backend_url: Override backend URL.
        api_key: Override API key.
        since: Optional ISO timestamp lower bound for the query.
        limit: Max entries to fetch (default 500).

    Returns:
        ``(success, message)`` tuple.
    """
    base = backend_url or _backend_url()
    if not base:
        return False, "SPOOLED_BACKEND_URL not set"

    key = api_key or _api_key()

    params = f"?limit={limit}"
    if since:
        params += f"&since={since}"
    url = f"{base}/api/agents/{agent_id}/ci-history{params}"
    status, resp = _request("GET", url, api_key=key)
    if status != 200:
        return False, f"Pull failed ({status}): {resp.get('error', resp)}"

    remote_entries: list[dict[str, Any]] = resp.get("entries", [])
    if not remote_entries:
        return True, "No remote entries"

    # Build dedup set from existing local file
    history_file = history_dir / f"{agent_id}.jsonl"
    existing_keys: set = set()
    if history_file.exists():
        for line in history_file.read_text().splitlines():
            line = line.strip()
            if line:
                try:
                    e = json.loads(line)
                    existing_keys.add((e.get("timestamp", ""), e.get("intent_id", "")))
                except Exception:
                    pass

    new_entries = [
        e
        for e in remote_entries
        if (e.get("timestamp", ""), e.get("intent_id", "")) not in existing_keys
    ]

    if not new_entries:
        return True, "Already up to date"

    history_dir.mkdir(parents=True, exist_ok=True)
    with open(history_file, "a") as f:
        for entry in new_entries:
            f.write(json.dumps(entry) + "\n")

    return True, f"Pulled {len(new_entries)} new entries"
