"""Behavioral fingerprinting for traces.

This module extracts behavioral patterns from traces to enable
meaningful comparison without semantic judgment.
"""

from __future__ import annotations

import hashlib
from typing import Any

import structlog

from spooled.models import Interaction, InteractionType

logger = structlog.get_logger(__name__)


def _get_target_name(interaction: Interaction | dict[str, Any]) -> str:
    """Extract a structural target name from an interaction (for fingerprint signature).

    Ignores timestamps, latency, and payload values; only structure (type + target).
    """
    if isinstance(interaction, Interaction):
        itype = (
            interaction.interaction_type.value
            if hasattr(interaction.interaction_type, "value")
            else str(interaction.interaction_type)
        )
        inp = interaction.input or {}
        meta = interaction.metadata or {}
    else:
        itype = interaction.get("interaction_type") or interaction.get("kind") or "OTHER"
        if hasattr(itype, "value"):
            itype = itype.value
        itype = str(itype)
        inp = interaction.get("input") or {}
        meta = interaction.get("metadata") or {}

    if itype == InteractionType.LLM_CALL.value:
        return meta.get("model") or inp.get("model") or "llm"
    if itype == InteractionType.TOOL_CALL.value:
        return inp.get("function") or inp.get("tool_name") or inp.get("tool") or "tool"
    if itype == InteractionType.HTTP_REQUEST.value:
        method = inp.get("method", "GET")
        return f"http:{method}"
    return "other"


# Fingerprint hash algorithm version. Changing this constant will produce
# different hashes for the same interaction sequence, causing a clean
# baseline mismatch instead of silent invalidation.  Bump when the
# algorithm (field selection, ordering, or hash function) changes.
_FINGERPRINT_HASH_VERSION = "v2"


def _get_parallel_group(interaction: Interaction | dict[str, Any]) -> str | None:
    """Extract parallel_group from an interaction."""
    if isinstance(interaction, Interaction):
        return getattr(interaction, "parallel_group", None)
    return interaction.get("parallel_group")


def _get_arg_key_shape(interaction: Interaction | dict[str, Any]) -> str:
    """Extract sorted argument keys from a tool call for fingerprint hashing.

    Only includes the key names (not values), so search(query="X") and
    search(query="Y") produce the same shape, but search(query="X") and
    search(query="X", limit=10) produce different shapes.

    Returns empty string for non-tool interactions.
    """
    if isinstance(interaction, Interaction):
        inp = interaction.input or {}
    else:
        inp = interaction.get("input") or {}

    # Check for 'arguments' (OpenAI style) or 'args' (manual style)
    args = inp.get("arguments") or inp.get("args")
    if isinstance(args, dict) and args:
        return "(" + ",".join(sorted(args.keys())) + ")"
    return ""


def calculate_fingerprint_hash(
    interactions: list[Interaction | dict[str, Any]],
    mode: str = "sequence",
) -> str:
    """Generate a structural hash of the trace for baseline lookup.

    Hash is based only on the sequence of interaction types and targets (e.g. model, tool name).
    Ignores timestamps, latency, and specific payload values. Deterministic and local-first.

    Parallel-aware: interactions sharing the same parallel_group are sorted by
    their type:target string so that different execution orders produce the same hash.

    The hash includes an algorithm version salt so that future changes to the
    fingerprinting logic produce cleanly different hashes rather than silently
    invalidating existing baselines.

    Args:
        interactions: Ordered list of interactions (Interaction instances or dicts).
        mode: Hashing mode.
            "sequence" (default): hashes the full ordered sequence of interactions.
                Good for fixed-step pipelines where order and count matter.
            "structural": hashes only the sorted unique set of {type}:{target}
                pairs. Ignores repetition count and order. Good for ReAct-loop
                agents where the same tools are called a variable number of times.

    Returns:
        SHA-256 hex digest, truncated to 16 chars for intent_id / fingerprint_hash.
    """
    if not interactions:
        return hashlib.sha256(f"{_FINGERPRINT_HASH_VERSION}|empty".encode()).hexdigest()[:16]

    sorted_interactions = sorted(
        interactions,
        key=lambda x: x.sequence if isinstance(x, Interaction) else x.get("sequence", 0),
    )

    # Build parts with parallel group awareness
    parts: list[str] = []
    i = 0
    while i < len(sorted_interactions):
        interaction = sorted_interactions[i]
        pg = _get_parallel_group(interaction)

        if pg is not None:
            # Collect all interactions in this parallel group
            group_parts = []
            while (
                i < len(sorted_interactions) and _get_parallel_group(sorted_interactions[i]) == pg
            ):
                inter = sorted_interactions[i]
                itype = (
                    getattr(inter.interaction_type, "value", None) or str(inter.interaction_type)
                    if isinstance(inter, Interaction)
                    else (inter.get("interaction_type") or inter.get("kind") or "OTHER")
                )
                if hasattr(itype, "value"):
                    itype = itype.value
                target = _get_target_name(inter)
                arg_shape = _get_arg_key_shape(inter)
                group_parts.append(f"{itype}:{target}{arg_shape}")
                i += 1
            # Sort within parallel group for deterministic ordering
            group_parts.sort()
            parts.extend(group_parts)
        else:
            itype = (
                getattr(interaction.interaction_type, "value", None)
                or str(interaction.interaction_type)
                if isinstance(interaction, Interaction)
                else (interaction.get("interaction_type") or interaction.get("kind") or "OTHER")
            )
            if hasattr(itype, "value"):
                itype = itype.value
            target = _get_target_name(interaction)
            arg_shape = _get_arg_key_shape(interaction)
            parts.append(f"{itype}:{target}{arg_shape}")
            i += 1

    if mode == "structural":
        # Deduplicate and sort — variable iteration counts produce the same hash
        parts = sorted(set(parts))
        signature = f"{_FINGERPRINT_HASH_VERSION}:structural|" + "|".join(parts)
    else:
        signature = f"{_FINGERPRINT_HASH_VERSION}|" + "|".join(parts)

    full_hash = hashlib.sha256(signature.encode()).hexdigest()
    return full_hash[:16]


class BehavioralFingerprint:
    """Represents a behavioral fingerprint of an agent execution."""

    def __init__(self, trace_data: dict[str, Any]) -> None:
        """Initialize fingerprint from trace data.

        Args:
            trace_data: Trace data dictionary with trace and interactions.
                       Gracefully handles None, empty, or malformed data.
        """
        if not trace_data or not isinstance(trace_data, dict):
            self.trace_data = {}
            self.interactions = []
            self._fingerprint: dict[str, Any] | None = None
            return

        self.trace_data = trace_data
        raw_interactions = trace_data.get("interactions") or []
        self.interactions = []
        for i in raw_interactions:
            if not isinstance(i, dict):
                continue
            try:
                self.interactions.append(Interaction(**i))
            except Exception:
                # Skip malformed interactions rather than crashing
                logger.debug(
                    "Skipping malformed interaction in fingerprint", interaction=str(i)[:100]
                )
        self._fingerprint = None

    def _get_interaction_type_value(self, interaction: Interaction) -> str:
        """Get interaction type as string, handling both enum and string values.

        Args:
            interaction: Interaction instance

        Returns:
            Interaction type as string
        """
        itype = interaction.interaction_type
        # With use_enum_values=True, it might already be a string
        if isinstance(itype, str):
            return itype
        # Otherwise it's an enum, get its value
        return itype.value

    def generate(self) -> dict[str, Any]:
        """Generate the behavioral fingerprint.

        Returns:
            Dictionary containing fingerprint data
        """
        if self._fingerprint is not None:
            return self._fingerprint

        fingerprint = {
            "interaction_sequence": self._extract_sequence(),
            "model_sequence": self._extract_model_sequence(),
            "tool_graph": self._extract_tool_graph(),
            "branch_paths": self._extract_branch_paths(),
            "interaction_types": self._extract_interaction_types(),
            "metadata_patterns": self._extract_metadata_patterns(),
            "error_patterns": self._extract_error_patterns(),
        }

        self._fingerprint = fingerprint
        return fingerprint

    def _extract_sequence(self) -> list[str]:
        """Extract the ordered sequence of interaction types.

        Parallel-aware: interactions in the same parallel_group are sorted
        by type for canonical ordering regardless of execution order.

        Returns:
            List of interaction type strings in canonical order
        """
        result: list[str] = []
        i = 0
        while i < len(self.interactions):
            interaction = self.interactions[i]
            pg = getattr(interaction, "parallel_group", None)

            if pg is not None:
                # Collect all interactions in this parallel group
                group_types = []
                while (
                    i < len(self.interactions)
                    and getattr(self.interactions[i], "parallel_group", None) == pg
                ):
                    group_types.append(self._get_interaction_type_value(self.interactions[i]))
                    i += 1
                group_types.sort()
                result.extend(group_types)
            else:
                result.append(self._get_interaction_type_value(interaction))
                i += 1
        return result

    def _extract_model_sequence(self) -> list[str]:
        """Extract ordered sequence of model names from LLM calls.

        Returns the model name for each LLM_CALL interaction in order.
        This ensures model swaps (e.g., gpt-4o → gpt-4o-mini) change the
        fingerprint hash even when the interaction type sequence is identical.

        Returns:
            List of model name strings for LLM_CALL interactions.
        """
        models: list[str] = []
        for interaction in self.interactions:
            if self._get_interaction_type_value(interaction) == InteractionType.LLM_CALL.value:
                inp = interaction.input or {}
                meta = interaction.metadata or {}
                model = meta.get("model") or inp.get("model") or "unknown"
                models.append(model)
        return models

    def _extract_tool_graph(self) -> dict[str, Any]:
        """Extract ordered tool call graph with IO-schema-based signatures.

        Parallel-aware: tracks parallel_groups and sorts tools within each
        group for deterministic sequencing.

        Returns:
            Dictionary representing the tool call structure, including
            tool_signatures, signature-based sequences, and parallel_groups.
        """
        from spooled.tool_signature import extract_tool_signature

        tool_calls = []
        tool_call_sequence: list[str] = []
        tool_signatures = []
        signature_sequence = []
        parallel_groups: dict[str, list[str]] = {}

        for i, interaction in enumerate(self.interactions):
            if self._get_interaction_type_value(interaction) == InteractionType.TOOL_CALL.value:
                inp = interaction.input or {}
                tool_name = inp.get("function") or inp.get("tool") or "unknown"
                pg = getattr(interaction, "parallel_group", None)
                tool_calls.append(
                    {
                        "sequence": i,
                        "tool": tool_name,
                        "args_keys": list((inp.get("arguments") or inp.get("args") or {}).keys()),
                        "parallel_group": pg,
                    }
                )
                tool_call_sequence.append(tool_name)

                # Track parallel groups
                if pg is not None:
                    if pg not in parallel_groups:
                        parallel_groups[pg] = []
                    parallel_groups[pg].append(tool_name)

                # Compute IO-schema-based signature
                sig = extract_tool_signature(interaction)
                if sig:
                    tool_signatures.append(
                        {
                            "name": sig["name"],
                            "structural_id": sig["structural_id"],
                            "arg_keys": sig["arg_keys"],
                            "output_keys": sig["output_keys"],
                        }
                    )
                    signature_sequence.append(sig["structural_id"])

        unique_signature_ids = sorted(set(signature_sequence))

        return {
            "tools": tool_calls,
            "sequence": tool_call_sequence,
            "unique_tools": sorted(set(tool_call_sequence)),
            "tool_count": len(tool_calls),
            "tool_signatures": tool_signatures,
            "unique_signature_ids": unique_signature_ids,
            "signature_sequence": signature_sequence,
            "parallel_groups": {k: sorted(v) for k, v in parallel_groups.items()},
        }

    def _extract_branch_paths(self) -> list[dict[str, Any]]:
        """Extract branch paths (decision points and their outcomes).

        Classifies error recovery patterns:
        - retry: error followed by same tool
        - fallback: error followed by different tool
        - escalation: error followed by LLM call (model re-evaluation)
        - abort: error with no subsequent step

        Returns:
            List of branch path information
        """
        branches = []
        recovery_window = 3  # Look ahead N steps for recovery classification

        for i, interaction in enumerate(self.interactions):
            # Decision point: LLM call followed by tool call
            if self._get_interaction_type_value(interaction) == InteractionType.LLM_CALL.value:
                if i + 1 < len(self.interactions):
                    next_interaction = self.interactions[i + 1]
                    if (
                        self._get_interaction_type_value(next_interaction)
                        == InteractionType.TOOL_CALL.value
                    ):
                        branches.append(
                            {
                                "sequence": i,
                                "type": "llm_to_tool",
                                "llm_call": i,
                                "tool_call": i + 1,
                                "tool": (next_interaction.input or {}).get("function")
                                or (next_interaction.input or {}).get("tool")
                                or "unknown",
                            }
                        )

            # Error recovery classification
            if interaction.error:
                current_tool = (interaction.input or {}).get("function") or (
                    interaction.input or {}
                ).get("tool")
                recovery_steps = []
                recovery_type = "abort"

                # Look at the next N steps for recovery classification
                for offset in range(1, min(recovery_window + 1, len(self.interactions) - i)):
                    next_inter = self.interactions[i + offset]
                    next_type = self._get_interaction_type_value(next_inter)
                    next_tool = (next_inter.input or {}).get("function") or (
                        next_inter.input or {}
                    ).get("tool")
                    recovery_steps.append(f"{next_type}:{next_tool or next_type}")

                    if offset == 1:
                        # Classify based on immediate next step
                        if next_type == InteractionType.TOOL_CALL.value:
                            if next_tool == current_tool:
                                recovery_type = "retry"
                            else:
                                recovery_type = "fallback"
                        elif next_type == InteractionType.LLM_CALL.value:
                            recovery_type = "escalation"

                branches.append(
                    {
                        "sequence": i,
                        "type": "error",
                        "error": interaction.error,
                        "recovery": i + 1 < len(self.interactions),
                        "recovery_type": recovery_type,
                        "recovery_chain": recovery_steps,
                        "error_tool": current_tool,
                    }
                )

        return branches

    def _extract_interaction_types(self) -> dict[str, int]:
        """Extract interaction type counts.

        Returns:
            Dictionary mapping interaction types to counts
        """
        counts: dict[str, int] = {}
        for interaction in self.interactions:
            itype = self._get_interaction_type_value(interaction)
            counts[itype] = counts.get(itype, 0) + 1
        return counts

    def _extract_metadata_patterns(self) -> dict[str, Any]:
        """Extract metadata patterns (latency, tokens, etc.).

        Returns:
            Dictionary with metadata statistics
        """
        latencies = []
        token_counts = []

        for interaction in self.interactions:
            metadata = interaction.metadata or {}

            if "latency_ms" in metadata:
                try:
                    latencies.append(float(metadata["latency_ms"]))
                except (ValueError, TypeError):
                    pass

            if "tokens" in metadata:
                try:
                    token_counts.append(int(metadata["tokens"]))
                except (ValueError, TypeError):
                    pass

        patterns: dict[str, Any] = {}

        if latencies:
            patterns["latency"] = {
                "min": min(latencies),
                "max": max(latencies),
                "avg": sum(latencies) / len(latencies),
                "count": len(latencies),
            }

        if token_counts:
            patterns["tokens"] = {
                "min": min(token_counts),
                "max": max(token_counts),
                "avg": sum(token_counts) / len(token_counts),
                "total": sum(token_counts),
            }

        return patterns

    def _extract_error_patterns(self) -> dict[str, Any]:
        """Extract error patterns with recovery classification.

        Returns:
            Dictionary with error information and recovery types
        """
        errors = []
        error_types: set[str] = set()
        recovery_types: dict[str, int] = {}

        # Use branch_paths for recovery classification
        branch_paths = self._extract_branch_paths()
        error_branches = [b for b in branch_paths if b["type"] == "error"]

        for interaction in self.interactions:
            if interaction.error:
                error_entry: dict[str, Any] = {
                    "sequence": interaction.sequence,
                    "type": self._get_interaction_type_value(interaction),
                    "error": interaction.error,
                }

                # Find matching error branch for recovery info
                for eb in error_branches:
                    if eb["sequence"] == interaction.sequence:
                        error_entry["recovery_type"] = eb.get("recovery_type", "abort")
                        rtype = eb.get("recovery_type", "abort")
                        recovery_types[rtype] = recovery_types.get(rtype, 0) + 1
                        break

                errors.append(error_entry)
                # Try to extract error type (first word or common patterns)
                error_parts = interaction.error.split()
                if error_parts:
                    error_types.add(error_parts[0].lower())

        return {
            "error_count": len(errors),
            "errors": errors,
            "error_types": sorted(error_types),
            "has_errors": len(errors) > 0,
            "recovery_types": recovery_types,
        }

    def to_dict(self) -> dict[str, Any]:
        """Convert fingerprint to dictionary.

        Returns:
            Dictionary representation of the fingerprint
        """
        return self.generate()


def _lcs_length(seq_a: list[Any], seq_b: list[Any]) -> int:
    """Compute length of longest common subsequence between two sequences."""
    m, n = len(seq_a), len(seq_b)
    if m == 0 or n == 0:
        return 0
    # Use two-row DP to save memory
    prev = [0] * (n + 1)
    curr = [0] * (n + 1)
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if seq_a[i - 1] == seq_b[j - 1]:
                curr[j] = prev[j - 1] + 1
            else:
                curr[j] = max(prev[j], curr[j - 1])
        prev, curr = curr, [0] * (n + 1)
    return prev[n]


def _sequence_similarity(seq_a: list[Any], seq_b: list[Any]) -> float:
    """LCS-based sequence similarity in [0.0, 1.0].

    Returns 1.0 for identical sequences, 0.0 for completely disjoint ones.
    Uses normalized LCS: 2*|LCS| / (|A| + |B|).
    """
    if not seq_a and not seq_b:
        return 1.0
    if not seq_a or not seq_b:
        return 0.0
    lcs = _lcs_length(seq_a, seq_b)
    return (2 * lcs) / (len(seq_a) + len(seq_b))


def _tool_jaccard(fp_a: dict[str, Any], fp_b: dict[str, Any]) -> float:
    """Compute tool-set Jaccard, preferring signature-based when available."""
    tg_a = fp_a.get("tool_graph", {})
    tg_b = fp_b.get("tool_graph", {})
    sig_a = set(tg_a.get("unique_signature_ids", []))
    sig_b = set(tg_b.get("unique_signature_ids", []))

    # If BOTH fingerprints have signature IDs, use those (rename-resilient)
    if sig_a and sig_b:
        union = sig_a | sig_b
        return len(sig_a & sig_b) / len(union) if union else 1.0

    # Fall back to name-based
    tools_a = set(tg_a.get("unique_tools", []))
    tools_b = set(tg_b.get("unique_tools", []))
    if tools_a or tools_b:
        union = tools_a | tools_b
        return len(tools_a & tools_b) / len(union) if union else 1.0

    return 1.0


def fingerprint_similarity(fp_a: dict[str, Any], fp_b: dict[str, Any]) -> float:
    """Compute structural similarity between two behavioral fingerprints.

    Combines three dimensions:
    - Tool set Jaccard (prefers signature-based when available, falls back to name-based)
    - Interaction sequence LCS (is the execution flow similar?)
    - Error type Jaccard (do they fail in the same ways?)

    Args:
        fp_a: First behavioral fingerprint dict (from BehavioralFingerprint.generate())
        fp_b: Second behavioral fingerprint dict

    Returns:
        Similarity score in [0.0, 1.0]. 1.0 = structurally identical, 0.0 = completely different.
    """
    scores: list[float] = []

    # Dimension 1: tool set Jaccard similarity (signature-aware)
    tools_a = set(fp_a.get("tool_graph", {}).get("unique_tools", []))
    tools_b = set(fp_b.get("tool_graph", {}).get("unique_tools", []))
    if tools_a or tools_b:
        scores.append(_tool_jaccard(fp_a, fp_b))

    # Dimension 2: interaction type sequence LCS similarity
    seq_a = fp_a.get("interaction_sequence", [])
    seq_b = fp_b.get("interaction_sequence", [])
    if seq_a or seq_b:
        scores.append(_sequence_similarity(seq_a, seq_b))

    # Dimension 3: error type Jaccard similarity
    errors_a = set(fp_a.get("error_patterns", {}).get("error_types", []))
    errors_b = set(fp_b.get("error_patterns", {}).get("error_types", []))
    if errors_a or errors_b:
        union = len(errors_a | errors_b)
        scores.append(len(errors_a & errors_b) / union if union > 0 else 1.0)

    return sum(scores) / len(scores) if scores else 0.0


def fingerprint_similarity_detailed(fp_a: dict[str, Any], fp_b: dict[str, Any]) -> dict[str, Any]:
    """Compute per-dimension structural similarity between two behavioral fingerprints.

    Returns the same three dimensions as fingerprint_similarity() but with individual
    scores and a dominant_reason / reason_label explaining the primary driver of any drift.

    Signature-aware: when BOTH fingerprints have unique_signature_ids, the
    signature_jaccard dimension is computed and used to detect tool renames
    (name-based Jaccard low, signature-based Jaccard high).

    Args:
        fp_a: First behavioral fingerprint dict (from BehavioralFingerprint.generate())
        fp_b: Second behavioral fingerprint dict

    Returns:
        Dict with keys:
            overall (float): Weighted average of all dimensions (0.0-1.0)
            tool_jaccard (float): Tool-set Jaccard similarity (name-based)
            signature_jaccard (float|None): Signature-based Jaccard (None if unavailable)
            sequence_lcs (float): Interaction-sequence LCS similarity
            error_jaccard (float): Error-type Jaccard similarity
            dominant_reason (str): Machine-readable reason code for primary drift
            reason_label (str): Human-readable explanation of primary drift
    """
    # Dimension 1a: name-based tool set Jaccard
    tools_a = set(fp_a.get("tool_graph", {}).get("unique_tools", []))
    tools_b = set(fp_b.get("tool_graph", {}).get("unique_tools", []))
    if tools_a or tools_b:
        union = len(tools_a | tools_b)
        name_tool_jaccard = len(tools_a & tools_b) / union if union > 0 else 1.0
    else:
        name_tool_jaccard = 1.0

    # Dimension 1b: signature-based tool set Jaccard
    sig_a = set(fp_a.get("tool_graph", {}).get("unique_signature_ids", []))
    sig_b = set(fp_b.get("tool_graph", {}).get("unique_signature_ids", []))
    if sig_a and sig_b:
        sig_union = sig_a | sig_b
        signature_jaccard: float | None = len(sig_a & sig_b) / len(sig_union) if sig_union else 1.0
    else:
        signature_jaccard = None

    # For the internal SCORE, use signature-based Jaccard when available —
    # this makes the overall similarity resilient to tool renames (same IO
    # shape = same behavior, even if the function name changed).
    tool_jaccard_for_score = (
        signature_jaccard if signature_jaccard is not None else name_tool_jaccard
    )

    # For DISPLAY and dominant-reason labeling, always use name-based Jaccard.
    # This prevents the contradiction where tool_jaccard=1.0 is reported
    # alongside tool_diff showing removed tools (signature collapse hides
    # real removals when many tools share the same IO schema).
    tool_jaccard_for_report = name_tool_jaccard

    # Dimension 2: interaction-type sequence LCS
    seq_a = fp_a.get("interaction_sequence", [])
    seq_b = fp_b.get("interaction_sequence", [])
    if seq_a or seq_b:
        sequence_lcs = _sequence_similarity(seq_a, seq_b)
    else:
        sequence_lcs = 1.0

    # Dimension 3: error type Jaccard
    errors_a = set(fp_a.get("error_patterns", {}).get("error_types", []))
    errors_b = set(fp_b.get("error_patterns", {}).get("error_types", []))
    if errors_a or errors_b:
        union = len(errors_a | errors_b)
        error_jaccard = len(errors_a & errors_b) / union if union > 0 else 1.0
    else:
        error_jaccard = 1.0

    # Overall uses signature-aware jaccard (for scoring resilience)
    scores = [tool_jaccard_for_score, sequence_lcs, error_jaccard]
    overall = sum(scores) / len(scores)

    # Dominant reason uses name-based jaccard (for accurate labeling)
    dim_scores = {
        "tool_jaccard": tool_jaccard_for_report,
        "sequence_lcs": sequence_lcs,
        "error_jaccard": error_jaccard,
    }
    min_dim = min(dim_scores, key=lambda k: dim_scores[k])
    min_score = dim_scores[min_dim]

    if min_score >= 0.95:
        dominant_reason = "minor_drift"
        reason_label = "Minor variation across all dimensions"
    elif min_dim == "tool_jaccard":
        # Check if this is a tool rename (name-based low, signature-based high)
        if signature_jaccard is not None and name_tool_jaccard < 0.5 and signature_jaccard >= 0.8:
            dominant_reason = "tool_renamed"
            reason_label = "Tool renamed (same IO shape)"
        else:
            dominant_reason = "tool_set_change"
            reason_label = "Tooling change (new or removed tool)"
    elif min_dim == "sequence_lcs":
        dominant_reason = "execution_order_change"
        reason_label = "Reasoning/flow change"
    else:  # error_jaccard
        dominant_reason = "error_pattern_change"
        reason_label = "Error handling changed"

    return {
        "overall": round(overall, 4),
        "tool_jaccard": round(tool_jaccard_for_report, 4),
        "signature_jaccard": round(signature_jaccard, 4) if signature_jaccard is not None else None,
        "sequence_lcs": round(sequence_lcs, 4),
        "error_jaccard": round(error_jaccard, 4),
        "dominant_reason": dominant_reason,
        "reason_label": reason_label,
    }


def fingerprint_trace(trace_data: dict[str, Any]) -> dict[str, Any]:
    """Generate a behavioral fingerprint from trace data.

    Args:
        trace_data: Trace data dictionary

    Returns:
        Behavioral fingerprint dictionary
    """
    fp = BehavioralFingerprint(trace_data)
    return fp.generate()


def hash_fingerprint(fingerprint: dict[str, Any], mode: str = "name") -> str:
    """Calculate SHA-256 hash of a behavioral fingerprint to use as intent_id.

    This creates a deterministic identifier for behavioral patterns (intents).
    Traces with the same fingerprint will have the same intent_id, allowing
    intent-scoped baseline comparison.

    Only structural fields are hashed — latency/token metadata is excluded so
    that runs with identical tool sequences but different timing all map to the
    same intent_id.

    Args:
        fingerprint: Behavioral fingerprint dictionary
        mode: Hashing mode.
            "name" (default): hashes tool_sequence + unique_tools (backwards-compatible).
            "structural": hashes signature_sequence + unique_signature_ids (rename-resilient).

    Returns:
        SHA-256 hex digest (64 characters) representing the intent_id
    """
    import hashlib
    import json

    # Include model_sequence when present so model swaps change the hash.
    # Fingerprints generated before this field was added will have None here,
    # preserving backwards compatibility (None serialises the same as omitted
    # in sorted JSON when the key is always present).
    model_seq = fingerprint.get("model_sequence")

    if mode == "standard":
        # Order-tolerant: hashes on WHICH tools ran and HOW MANY TIMES,
        # not the exact sequence. Reordering = MATCH. Added/removed tool = VARIANT.
        # This is the recommended mode for unseeded agents.
        tool_graph = fingerprint.get("tool_graph", {})
        tool_seq = tool_graph.get("sequence", [])
        # Build {tool_name: call_count} — order-independent
        from collections import Counter

        tool_counts = dict(sorted(Counter(tool_seq).items()))
        structural = {
            "tool_counts": tool_counts,
            "unique_tools": sorted(tool_graph.get("unique_tools", [])),
            "error_types": sorted(fingerprint.get("error_patterns", {}).get("error_types", [])),
        }
    elif mode == "structural":
        tool_graph = fingerprint.get("tool_graph", {})
        structural = {
            "interaction_sequence": fingerprint.get("interaction_sequence"),
            "model_sequence": model_seq,
            "signature_sequence": tool_graph.get("signature_sequence", []),
            "unique_signature_ids": tool_graph.get("unique_signature_ids", []),
            "interaction_types": fingerprint.get("interaction_types"),
            "error_types": fingerprint.get("error_patterns", {}).get("error_types"),
        }
    else:
        # "name" mode (strict): exact sequence matching.
        # Use this when agents are seeded (deterministic tool ordering).
        structural = {
            "interaction_sequence": fingerprint.get("interaction_sequence"),
            "model_sequence": model_seq,
            "tool_sequence": fingerprint.get("tool_graph", {}).get("sequence"),
            "unique_tools": fingerprint.get("tool_graph", {}).get("unique_tools"),
            "interaction_types": fingerprint.get("interaction_types"),
            "error_types": fingerprint.get("error_patterns", {}).get("error_types"),
        }
    fingerprint_json = json.dumps(structural, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(fingerprint_json.encode("utf-8")).hexdigest()[:16]
