"""Signal detection for AI CI.

This module detects behavioral signals that should trigger warnings:
- New side effects (new tools, external writes)
- Latency spikes
- Retry explosions
- Token usage spikes
- Component latency drift
- Output schema drift (content-blind)
"""

from __future__ import annotations

import os
from typing import Any
from urllib.parse import urlparse

import structlog

from spooled.baseline import BaselineManager, make_env_fingerprint
from spooled.fingerprint import BehavioralFingerprint
from spooled.models import InteractionType

logger = structlog.get_logger(__name__)

# Signals that are inherently non-deterministic (LLM latency/token variance).
# Used by the CI 2-pass verification to decide whether a rerun is warranted.
METRIC_SENSITIVE_SIGNALS = frozenset(
    {
        "latency_spikes",
        "token_usage_spike",
        "component_latency_drift",
    }
)


def _interaction_has_error(interaction: dict[str, Any]) -> bool:
    """Check if an interaction represents an error.

    Works with structure-only traces where the error field is stripped.
    Falls back to metadata.status_code for HTTP errors.
    """
    if interaction.get("error"):
        return True
    meta = interaction.get("metadata") or {}
    status_code = meta.get("status_code")
    if isinstance(status_code, (int, float)) and status_code >= 400:
        return True
    return False


class SignalDetector:
    """Detects behavioral signals that may indicate issues."""

    def __init__(
        self,
        current_trace: dict[str, Any],
        baseline_trace: dict[str, Any] | None = None,
        thresholds: dict[str, float] | None = None,
        baseline_manager: BaselineManager | None = None,
        plan: str | None = None,
    ) -> None:
        """Initialize signal detector.

        Args:
            current_trace: Current trace data to analyze
            baseline_trace: Baseline trace for comparison (optional)
            thresholds: Optional custom thresholds (defaults to env vars or defaults)
            baseline_manager: Optional BaselineManager for accessing rolling baseline metrics
            plan: License plan tier ("free", "pro", "team", "enterprise").
                  Content-blind signals require "pro" or above.
                  Defaults to checking SPOOLED_API_KEY via LicenseChecker.
        """
        self.current_trace = current_trace if isinstance(current_trace, dict) else {}
        self.baseline_trace = baseline_trace if isinstance(baseline_trace, dict) else None
        self.current_fp = BehavioralFingerprint(self.current_trace)
        self.baseline_fp = (
            BehavioralFingerprint(self.baseline_trace) if self.baseline_trace else None
        )
        self.baseline_manager = baseline_manager
        self._plan = plan

        # Load thresholds from config or use defaults
        self.thresholds = thresholds or self._load_thresholds()

    def _content_blind_enabled(self) -> bool:
        """Check if content-blind signals are enabled for the current plan.

        Content-blind signals (output schema drift) are a Pro feature. Returns True for pro/team/enterprise
        plans, or when no licensing is configured (local/dev mode).
        """
        plan = self._plan
        if plan is None:
            # Local mode: no backend URL or no API key → no gating
            backend_url = os.getenv("SPOOLED_BACKEND_URL", "")
            api_key = os.getenv("SPOOLED_API_KEY")
            if not api_key or not backend_url:
                return True  # Local/dev mode — no gating
            try:
                from spooled.licensing import LicenseChecker

                plan = LicenseChecker(api_key).check().get("plan", "free")
            except Exception:
                return True  # License check failure — degrade gracefully
        return plan in ("pro", "team", "enterprise")

    def _load_thresholds(self) -> dict[str, float]:
        """Load thresholds from environment variables or use defaults.

        Returns:
            Dictionary of threshold values
        """
        return {
            "latency_increase_percent": float(
                os.getenv("SPOOLED_LATENCY_INCREASE_THRESHOLD", "50.0")
            ),
            "latency_max_multiplier": float(os.getenv("SPOOLED_LATENCY_MAX_MULTIPLIER", "2.0")),
            "latency_avg_absolute_ms": float(
                os.getenv("SPOOLED_LATENCY_AVG_ABSOLUTE_MS", "5000.0")
            ),
            "latency_max_absolute_ms": float(
                os.getenv("SPOOLED_LATENCY_MAX_ABSOLUTE_MS", "30000.0")
            ),
            "retry_explosion_threshold": float(
                os.getenv("SPOOLED_RETRY_EXPLOSION_THRESHOLD", "5.0")
            ),
            "retry_warning_threshold": float(os.getenv("SPOOLED_RETRY_WARNING_THRESHOLD", "3.0")),
            "tool_usage_change_percent": float(
                os.getenv("SPOOLED_TOOL_USAGE_CHANGE_THRESHOLD", "50.0")
            ),
            "token_usage_spike_threshold": float(
                os.getenv("SPOOLED_TOKEN_USAGE_SPIKE_THRESHOLD", "0.5")
            ),
            "component_latency_drift_threshold": float(
                os.getenv("SPOOLED_COMPONENT_LATENCY_DRIFT_THRESHOLD", "1.0")
            ),
            "content_filter_rate_change_threshold": float(
                os.getenv("SPOOLED_REFUSAL_POLICY_DRIFT_THRESHOLD", "0.1")
            ),
            "tool_overuse_threshold": float(os.getenv("SPOOLED_TOOL_OVERUSE_THRESHOLD", "0.5")),
            "retrieval_regression_threshold": float(
                os.getenv("SPOOLED_RETRIEVAL_REGRESSION_THRESHOLD", "0.2")
            ),
            "retry_exempt_tools": [
                t.strip()
                for t in os.getenv("SPOOLED_RETRY_EXEMPT_TOOLS", "").split(",")
                if t.strip()
            ],
            "retrieval_functions": {
                t.strip()
                for t in os.getenv(
                    "SPOOLED_RETRIEVAL_FUNCTIONS", "retrieve,vector_search,search,query"
                ).split(",")
                if t.strip()
            },
            # Content-blind signal thresholds (output schema drift only —
            # decision/confidence drift removed for content-blind compliance)
            "output_schema_fail_on_removed": os.getenv(
                "SPOOLED_OUTPUT_SCHEMA_FAIL_ON_REMOVED", "true"
            ).lower()
            in ("true", "1", "yes"),
            "output_schema_fail_on_added": os.getenv(
                "SPOOLED_OUTPUT_SCHEMA_FAIL_ON_ADDED", "false"
            ).lower()
            in ("true", "1", "yes"),
        }

    def detect_signals(self) -> dict[str, Any]:
        """Detect all signals.

        Returns:
            Dictionary with detected signals
        """
        new_behavior = self._detect_new_behavior_pattern()

        # Always compute new_side_effects so policy rules (e.g. new_tools,
        # required_tools) still have access to the tool data.  When the
        # entire behavior is new, we mark the signal as display-suppressed
        # so the UI can de-emphasise it, but the policy engine can still
        # evaluate conditions against it.
        new_side_effects = self._detect_new_side_effects()
        if new_behavior.get("detected") and new_side_effects.get("detected"):
            new_side_effects["suppressed_display"] = True
            new_side_effects["suppression_reason"] = "Entire behavior is new"

        signals = {
            "new_behavior_pattern": new_behavior,
            "new_side_effects": new_side_effects,
            "latency_spikes": self._detect_latency_spikes(),
            "retry_explosions": self._detect_retry_explosions(),
            "error_increases": self._detect_error_increases(),
            "tool_usage_changes": self._detect_tool_usage_changes(),
            "token_usage_spike": self._detect_token_usage_spike(),
            "component_latency_drift": self._detect_component_latency_drift(),
            "content_filter_rate_change": self._detect_content_filter_rate_change(),
            "tool_overuse": self._detect_tool_overuse(),
            "retrieval_regression": self._detect_retrieval_regression(),
            # Content-blind signals (Pro feature — gated by license plan)
            # NOTE: decision_distribution_drift and confidence_drift DISABLED —
            # they required extracting tool output values, which contradicted
            # the content-blind architecture. output_schema_drift is retained
            # as it only uses key names (structural), not values.
            "output_schema_drift": (
                self._detect_output_schema_drift()
                if self._content_blind_enabled()
                else {"detected": False, "reason": "Content-blind signals require Pro plan"}
            ),
            "sequence_drift": self._detect_sequence_drift(),
        }

        # Calculate severity (info-level signals do not count as warnings/blockers)
        signals["severity"] = self._calculate_severity(signals)
        signals["has_warnings"] = any(
            signal.get("detected", False) and signal.get("severity") not in ("info", None)
            for signal in signals.values()
            if isinstance(signal, dict)
        )

        return signals

    def _detect_new_behavior_pattern(self) -> dict[str, Any]:
        """Detect new behavior (Cold Start: intent not in baseline yet).

        When baseline_stats is None (no history for this fingerprint), check
        accepted_fingerprints across all intents. If the current fingerprint
        is in any intent's accepted set, treat it as known behavior.

        When truly new (not in any accepted set), return an INFO-level signal.
        This is purely informational—we are learning a new pattern; it must
        NOT be marked as a failure/blocker.
        """
        if not self.baseline_manager:
            return {"detected": False, "reason": "No baseline manager available"}

        baseline_stats = self.baseline_manager.get_stats(self.current_trace)
        if baseline_stats is not None:
            return {"detected": False}

        intent_id = self.baseline_manager.get_intent_id(self.current_trace)
        if intent_id is None:
            return {"detected": False, "reason": "Failed to generate intent_id"}

        # Check if this fingerprint is in any intent's accepted_fingerprints
        baseline = self.baseline_manager.load_baseline()
        for intent_stat in baseline.intents.values():
            if intent_id in intent_stat.accepted_fingerprints:
                return {"detected": False, "reason": "Fingerprint in accepted variants"}

        current_fp = self.current_fp.generate()
        tool_graph = current_fp.get("tool_graph", {})
        unique_tools = tool_graph.get("unique_tools", [])

        return {
            "detected": True,
            "severity": "info",
            "is_blocker": False,
            "message": (
                f"New behavior observed (intent_id: {intent_id[:16]}...). "
                "No baseline for this pattern yet; system is learning."
            ),
            "details": {
                "intent_id": intent_id,
                "interaction_sequence": current_fp.get("interaction_sequence", []),
                "unique_tools": unique_tools,
                "tool_count": len(unique_tools),
            },
        }

    def _detect_new_side_effects(self) -> dict[str, Any]:
        """Detect new side effects (new tools, external writes).

        Returns:
            Dictionary with detection results
        """
        current_fp_data = self.current_fp.generate()
        current_tools = set(current_fp_data.get("tool_graph", {}).get("unique_tools", []))

        # Get baseline tools from either full baseline trace or baseline manager summary
        baseline_tools: set = set()
        if self.baseline_fp:
            baseline_fp_data = self.baseline_fp.generate()
            baseline_tools = set(baseline_fp_data.get("tool_graph", {}).get("unique_tools", []))
        elif self.baseline_manager:
            # Fall back to fingerprint data stored in baseline summary
            baseline = self.baseline_manager.load_baseline()
            if baseline and baseline.intents:
                for intent_stat in baseline.intents.values():
                    fp = getattr(intent_stat, "fingerprint", None)
                    if fp:
                        baseline_tools.update(fp.get("tool_graph", {}).get("unique_tools", []))
            if not baseline_tools:
                return {"detected": False, "reason": "No baseline available"}
        else:
            return {"detected": False, "reason": "No baseline available"}

        new_tools = current_tools - baseline_tools

        if new_tools:
            return {
                "detected": True,
                "severity": "medium",
                "message": f"New tools detected: {', '.join(new_tools)}",
                "new_tools": list(new_tools),
                "details": {
                    "current_tools": list(current_tools),
                    "baseline_tools": list(baseline_tools),
                },
            }

        return {"detected": False}

    def _check_env_mismatch(self, baseline_stats: Any | None = None) -> dict[str, str] | None:
        """Return env mismatch info if current trace was captured in a different env than baseline.

        Returns None if envs match (or baseline has no recorded env). When envs differ,
        returns a dict with `current` and `baseline` fingerprints — callers should downgrade
        latency signal severity since cross-env latency comparisons are unfair.

        Checks the given baseline_stats first; falls back to scanning any baseline intent
        via the baseline_manager (handles variant traces where get_stats returns None).
        """
        # Try to find baseline env fingerprint from the given stats or any intent
        baseline_fp = None
        if baseline_stats and getattr(baseline_stats, "baseline_env_fingerprint", None):
            baseline_fp = baseline_stats.baseline_env_fingerprint
        elif self.baseline_manager:
            baseline = self.baseline_manager.load_baseline()
            for intent_stat in baseline.intents.values():
                if getattr(intent_stat, "baseline_env_fingerprint", None):
                    baseline_fp = intent_stat.baseline_env_fingerprint
                    break

        if not baseline_fp:
            return None

        current_env = (self.current_trace.get("trace") or self.current_trace).get(
            "environment"
        ) or {}
        current_fp = make_env_fingerprint(current_env)
        if current_fp == baseline_fp or current_fp == "unknown":
            return None
        return {"current": current_fp, "baseline": baseline_fp}

    def _detect_latency_spikes(self) -> dict[str, Any]:
        """Detect latency spikes. Error-level only when a baseline exists and threshold exceeded."""
        current_fp_data = self.current_fp.generate()
        current_metadata = current_fp_data.get("metadata_patterns", {})

        if "latency" not in current_metadata:
            return {"detected": False, "reason": "No latency data available"}

        current_avg_latency = current_metadata["latency"].get("avg", 0)
        current_max_latency = current_metadata["latency"].get("max", 0)

        # Intent-scoped baseline: only trigger comparative spike when baseline exists (Cold Start)
        baseline_stats = (
            self.baseline_manager.get_stats(self.current_trace) if self.baseline_manager else None
        )

        # Detect environment mismatch — if baseline was generated in a different env,
        # latency comparisons are unfair (e.g. baseline on Mac, CI on Linux).
        env_mismatch = self._check_env_mismatch(baseline_stats)
        env_severity_downgrade = "info" if env_mismatch else None
        env_note = (
            (
                f" [env mismatch: baseline={env_mismatch['baseline']}, current={env_mismatch['current']} — "
                "regenerate baselines in CI for accurate latency tracking]"
            )
            if env_mismatch
            else ""
        )

        if baseline_stats is not None and baseline_stats.sample_count > 0:
            baseline_avg = baseline_stats.avg_latency
            # Use std_dev for max threshold if available; else approximate from avg
            baseline_max = baseline_avg + baseline_stats.std_dev_latency * 2
            if baseline_max <= 0:
                baseline_max = baseline_avg * 2

            if baseline_avg > 0:
                latency_increase = (current_avg_latency - baseline_avg) / baseline_avg
                threshold = self.thresholds["latency_increase_percent"] / 100.0

                # Prefer p95 envelope from latency_bounds if available (more precise than avg+2σ)
                p95 = (
                    baseline_stats.latency_bounds.get("p95_ms")
                    if baseline_stats.latency_bounds
                    else None
                )
                envelope_label = f"p95={p95:.0f}ms" if p95 else f"avg={baseline_avg:.0f}ms"

                if latency_increase > threshold:
                    return {
                        "detected": True,
                        "severity": env_severity_downgrade or "high",
                        "message": (
                            f"Average latency increased by {latency_increase*100:.1f}% "
                            f"({baseline_avg:.2f}ms → {current_avg_latency:.2f}ms, envelope: {envelope_label})"
                            + env_note
                        ),
                        "details": {
                            "baseline_avg": baseline_avg,
                            "current_avg": current_avg_latency,
                            "increase_percent": latency_increase * 100,
                            "threshold_percent": self.thresholds["latency_increase_percent"],
                            "envelope": (
                                baseline_stats.latency_bounds
                                if baseline_stats.latency_bounds
                                else {}
                            ),
                            "env_mismatch": env_mismatch,
                        },
                    }

            # Check against p95 envelope if available (catches max spikes more precisely)
            p95 = (
                baseline_stats.latency_bounds.get("p95_ms")
                if baseline_stats.latency_bounds
                else None
            )
            if p95 and p95 > 0:
                multiplier = self.thresholds["latency_max_multiplier"]
                if current_max_latency > p95 * multiplier:
                    return {
                        "detected": True,
                        "severity": env_severity_downgrade or "high",
                        "message": f"Max latency spike: {current_max_latency:.2f}ms exceeds {multiplier:.1f}×p95 ({p95:.2f}ms)"
                        + env_note,
                        "details": {
                            "p95_ms": p95,
                            "current_max": current_max_latency,
                            "multiplier": multiplier,
                            "envelope": baseline_stats.latency_bounds,
                            "env_mismatch": env_mismatch,
                        },
                    }
            else:
                multiplier = self.thresholds["latency_max_multiplier"]
                if baseline_max > 0 and current_max_latency > baseline_max * multiplier:
                    return {
                        "detected": True,
                        "severity": env_severity_downgrade or "high",
                        "message": f"Max latency spike ({baseline_max:.2f}ms -> {current_max_latency:.2f}ms)"
                        + env_note,
                        "details": {
                            "baseline_max": baseline_max,
                            "current_max": current_max_latency,
                            "env_mismatch": env_mismatch,
                        },
                    }

        # Absolute thresholds only when no intent-scoped baseline (optional; do not block Cold Start)
        avg_threshold = self.thresholds["latency_avg_absolute_ms"]
        if current_avg_latency > avg_threshold:
            return {
                "detected": True,
                "severity": "medium",
                "message": f"High average latency: {current_avg_latency:.2f}ms (threshold: {avg_threshold}ms)",
                "details": {
                    "avg_latency": current_avg_latency,
                    "threshold_ms": avg_threshold,
                },
            }

        max_threshold = self.thresholds["latency_max_absolute_ms"]
        if current_max_latency > max_threshold:
            return {
                "detected": True,
                "severity": "high",
                "message": f"Very high max latency: {current_max_latency:.2f}ms",
                "details": {"max_latency": current_max_latency},
            }

        return {"detected": False}

    def _detect_retry_explosions(self) -> dict[str, Any]:
        """Detect retry explosions (excessive retries).

        Only flags retries that are:
        (a) consecutive identical inputs AND preceded by an error, OR
        (b) consecutive identical inputs exceeding the threshold even without error.

        Non-consecutive repeated calls (pagination, batch processing) and polling
        patterns (all-success consecutive) are NOT flagged at default thresholds.

        Returns:
            Dictionary with detection results
        """
        import json

        interactions = self.current_trace.get("interactions", [])
        if not interactions:
            return {"detected": False}

        # Load exempt tools from config
        retry_exempt_tools: list[str] = self.thresholds.get("retry_exempt_tools", [])

        # Scan for consecutive runs of identical inputs
        max_consecutive_after_error = 0
        max_consecutive_any = 0
        worst_tool = None

        i = 0
        while i < len(interactions):
            interaction = interactions[i]
            input_data = interaction.get("input", {})

            # Skip exempt tools
            tool_name = (
                input_data.get("function") or input_data.get("tool") or input_data.get("tool_name")
            )
            if tool_name and tool_name in retry_exempt_tools:
                i += 1
                continue

            # Compare structural identity (function/tool name + type + model),
            # excluding payload_hash and other per-interaction unique fields.
            structural_keys = ("function", "tool", "tool_name", "model", "method", "url", "name")
            input_identity = {
                k: input_data.get(k) for k in structural_keys if input_data.get(k) is not None
            }
            itype = interaction.get("interaction_type", "")
            input_identity["_type"] = itype
            input_str = json.dumps(input_identity, sort_keys=True)

            # Count consecutive identical inputs starting at i
            consecutive = 1
            has_preceding_error = _interaction_has_error(interaction)
            j = i + 1
            while j < len(interactions):
                next_input = interactions[j].get("input", {})
                next_identity = {
                    k: next_input.get(k) for k in structural_keys if next_input.get(k) is not None
                }
                next_identity["_type"] = interactions[j].get("interaction_type", "")
                next_input_str = json.dumps(next_identity, sort_keys=True)
                if next_input_str != input_str:
                    break
                consecutive += 1
                if _interaction_has_error(interactions[j]):
                    has_preceding_error = True
                j += 1

            if consecutive > 1:
                if has_preceding_error and consecutive > max_consecutive_after_error:
                    max_consecutive_after_error = consecutive
                    worst_tool = tool_name
                if consecutive > max_consecutive_any:
                    max_consecutive_any = consecutive
                    if not worst_tool:
                        worst_tool = tool_name

            i = j if j > i else i + 1

        # Only flag consecutive-after-error retries at warning threshold
        explosion_threshold = self.thresholds["retry_explosion_threshold"]
        warning_threshold = self.thresholds["retry_warning_threshold"]

        # Consecutive retries after error = strongest signal
        if max_consecutive_after_error >= explosion_threshold:
            return {
                "detected": True,
                "severity": "high",
                "message": (
                    f"Retry explosion detected: {max_consecutive_after_error} consecutive "
                    f"identical calls with errors (threshold: {int(explosion_threshold)})"
                ),
                "details": {
                    "max_consecutive_retries": max_consecutive_after_error,
                    "has_preceding_error": True,
                    "threshold": explosion_threshold,
                    "tool": worst_tool,
                },
            }

        if max_consecutive_after_error >= warning_threshold:
            return {
                "detected": True,
                "severity": "medium",
                "message": (
                    f"Retries detected: {max_consecutive_after_error} consecutive "
                    f"identical calls with errors"
                ),
                "details": {
                    "max_consecutive_retries": max_consecutive_after_error,
                    "has_preceding_error": True,
                    "tool": worst_tool,
                },
            }

        # Consecutive without error: only flag at double the explosion threshold
        # (allows polling loops at normal thresholds)
        no_error_threshold = explosion_threshold * 2
        if max_consecutive_any >= no_error_threshold:
            return {
                "detected": True,
                "severity": "medium",
                "message": (
                    f"Excessive repetition detected: {max_consecutive_any} consecutive "
                    f"identical calls without errors (threshold: {int(no_error_threshold)})"
                ),
                "details": {
                    "max_consecutive_retries": max_consecutive_any,
                    "has_preceding_error": False,
                    "threshold": no_error_threshold,
                    "tool": worst_tool,
                },
            }

        return {"detected": False}

    def _detect_error_increases(self) -> dict[str, Any]:
        """Detect error count increases.

        Returns:
            Dictionary with detection results
        """
        current_fp_data = self.current_fp.generate()
        current_errors = current_fp_data.get("error_patterns", {})
        current_error_count = current_errors.get("error_count", 0)

        if not self.baseline_fp:
            # No baseline: report errors at info level (cold start)
            if current_error_count > 0:
                return {
                    "detected": True,
                    "severity": "info",
                    "message": f"Errors detected (no baseline): {current_error_count}",
                    "details": {"error_count": current_error_count, "cold_start": True},
                }
            return {"detected": False}

        baseline_fp_data = self.baseline_fp.generate()
        baseline_errors = baseline_fp_data.get("error_patterns", {})
        baseline_error_count = baseline_errors.get("error_count", 0)

        if current_error_count > baseline_error_count:
            increase = current_error_count - baseline_error_count
            return {
                "detected": True,
                "severity": "high" if current_error_count > baseline_error_count * 2 else "medium",
                "message": f"Error count increased: {baseline_error_count} -> {current_error_count} (+{increase})",
                "details": {
                    "baseline_errors": baseline_error_count,
                    "current_errors": current_error_count,
                    "increase": increase,
                },
            }

        return {"detected": False}

    def _detect_tool_usage_changes(self) -> dict[str, Any]:
        """Detect significant tool usage pattern changes.

        Returns:
            Dictionary with detection results
        """
        if not self.baseline_fp:
            return {"detected": False, "reason": "No baseline available"}

        current_fp_data = self.current_fp.generate()
        baseline_fp_data = self.baseline_fp.generate()

        current_tool_count = current_fp_data.get("tool_graph", {}).get("tool_count", 0)
        baseline_tool_count = baseline_fp_data.get("tool_graph", {}).get("tool_count", 0)

        if baseline_tool_count > 0:
            change_ratio = abs(current_tool_count - baseline_tool_count) / baseline_tool_count
            threshold = self.thresholds["tool_usage_change_percent"] / 100.0
            if change_ratio > threshold:
                return {
                    "detected": True,
                    "severity": "medium",
                    "message": f"Tool usage changed significantly: {baseline_tool_count} -> {current_tool_count} ({change_ratio*100:.1f}% change, threshold: {self.thresholds['tool_usage_change_percent']}%)",
                    "details": {
                        "baseline_count": baseline_tool_count,
                        "current_count": current_tool_count,
                        "change_percent": change_ratio * 100,
                        "threshold_percent": self.thresholds["tool_usage_change_percent"],
                    },
                }

        return {"detected": False}

    def _extract_component_identifier(self, interaction: dict[str, Any]) -> str | None:
        """Extract component identifier from an interaction.

        Args:
            interaction: Interaction dictionary

        Returns:
            Component identifier string (e.g., "llm:gpt-4", "tool:search", "http:GET"), or None
        """
        interaction_type = interaction.get("interaction_type", "")

        if interaction_type == InteractionType.LLM_CALL.value:
            # For LLM calls, use model name
            model = (
                interaction.get("metadata", {}).get("model")
                or interaction.get("input", {}).get("model")
                or "unknown"
            )
            return f"llm:{model}"

        elif interaction_type == InteractionType.TOOL_CALL.value:
            # For tool calls, use function name
            function_name = interaction.get("input", {}).get("function", "unknown")
            return f"tool:{function_name}"

        elif interaction_type == InteractionType.HTTP_REQUEST.value:
            # For HTTP requests, use method and domain
            method = interaction.get("input", {}).get("method", "UNKNOWN")
            url = interaction.get("input", {}).get("url", "")
            if url:
                try:
                    parsed = urlparse(url)
                    domain = parsed.netloc or parsed.path.split("/")[0] or "unknown"
                    return f"http:{method}:{domain}"
                except Exception:
                    return f"http:{method}"
            return f"http:{method}"

        elif interaction_type == InteractionType.OTHER.value:
            # For other types, use a generic identifier
            other_type = interaction.get("input", {}).get("type", "unknown")
            return f"other:{other_type}"

        return None

    def _detect_token_usage_spike(self) -> dict[str, Any]:
        """Detect token usage spike (economic signal).

        Only triggers when an intent-scoped baseline exists (Cold Start: no error-level
        spike when no history for this fingerprint). Do not use aggregate fallback.
        """
        if not self.baseline_manager:
            return {"detected": False, "reason": "No baseline manager available"}

        # Get baseline stats for this specific intent (intent-scoped only; no aggregate fallback)
        stats = self.baseline_manager.get_stats(self.current_trace)
        if stats is None or stats.sample_count == 0:
            return {"detected": False, "reason": "No baseline for this intent (cold start)"}

        baseline_avg_tokens = stats.avg_tokens
        if baseline_avg_tokens is None or baseline_avg_tokens == 0:
            return {"detected": False, "reason": "No baseline token data for this intent"}

        # Calculate total tokens for current trace
        interactions = self.current_trace.get("interactions", [])
        current_total_tokens = 0
        for interaction in interactions:
            if interaction.get("interaction_type") == InteractionType.LLM_CALL.value:
                usage = interaction.get("output", {}).get("usage") or interaction.get(
                    "metadata", {}
                ).get("usage")
                if usage and isinstance(usage, dict):
                    tokens = usage.get("total_tokens")
                    if tokens and isinstance(tokens, (int, float)):
                        current_total_tokens += tokens

        intent_id = self.baseline_manager.get_intent_id(self.current_trace)

        # Check if current tokens exceed threshold
        threshold = self.thresholds["token_usage_spike_threshold"]
        threshold_tokens = baseline_avg_tokens * (1 + threshold)

        if current_total_tokens > threshold_tokens:
            increase_percent = (
                (current_total_tokens - baseline_avg_tokens) / baseline_avg_tokens
            ) * 100
            return {
                "detected": True,
                "severity": "high",
                "message": f"Token usage spike detected: {current_total_tokens:.0f} tokens (baseline avg: {baseline_avg_tokens:.0f}, +{increase_percent:.1f}%)",
                "details": {
                    "current_tokens": current_total_tokens,
                    "baseline_avg_tokens": baseline_avg_tokens,
                    "increase_percent": increase_percent,
                    "threshold_percent": threshold * 100,
                    "intent_id": intent_id[:16] + "..." if intent_id else None,
                },
            }

        return {"detected": False}

    def _detect_component_latency_drift(self) -> dict[str, Any]:
        """Detect component latency drift (granular signal).

        Returns:
            Dictionary with detection results
        """
        if not self.baseline_manager:
            return {"detected": False, "reason": "No baseline manager available"}

        # Get baseline stats for this specific intent (intent-scoped comparison)
        stats = self.baseline_manager.get_stats(self.current_trace)
        baseline_component_latencies = (
            stats.component_avg_latencies if stats and stats.sample_count > 0 else {}
        )

        # Fallback to aggregate if intent not found
        if not baseline_component_latencies:
            intent_id = self.baseline_manager.get_intent_id(self.current_trace)
            baseline_component_latencies = self.baseline_manager.get_component_avg_latencies(
                intent_id
            )
            if not baseline_component_latencies:
                baseline_component_latencies = self.baseline_manager.get_component_avg_latencies()

        if not baseline_component_latencies:
            return {"detected": False, "reason": "No baseline component latency data available"}

        # Analyze current trace interactions
        interactions = self.current_trace.get("interactions", [])
        threshold = self.thresholds["component_latency_drift_threshold"]
        drifted_components: list[dict[str, Any]] = []

        for interaction in interactions:
            metadata = interaction.get("metadata", {})
            latency_ms = metadata.get("latency_ms") or metadata.get("duration_ms")

            if latency_ms is None:
                continue

            try:
                current_latency = float(latency_ms)
                component_id = self._extract_component_identifier(interaction)

                if component_id and component_id in baseline_component_latencies:
                    baseline_avg_latency = baseline_component_latencies[component_id]
                    threshold_latency = baseline_avg_latency * (1 + threshold)

                    if current_latency > threshold_latency:
                        increase_percent = (
                            (current_latency - baseline_avg_latency) / baseline_avg_latency
                        ) * 100
                        drifted_components.append(
                            {
                                "component_id": component_id,
                                "current_latency": current_latency,
                                "baseline_avg_latency": baseline_avg_latency,
                                "increase_percent": increase_percent,
                            }
                        )
            except (ValueError, TypeError):
                logger.debug("Invalid latency value", latency=latency_ms, component_id=component_id)

        if drifted_components:
            # Find the worst offender
            worst = max(drifted_components, key=lambda x: x["increase_percent"])

            # Detect environment mismatch — downgrade severity if baseline was
            # generated in a different env than the current trace.
            env_mismatch = self._check_env_mismatch(stats)
            severity = "info" if env_mismatch else "medium"
            env_note = (
                (
                    f" [env mismatch: baseline={env_mismatch['baseline']}, current={env_mismatch['current']}]"
                )
                if env_mismatch
                else ""
            )

            return {
                "detected": True,
                "severity": severity,
                "message": (
                    f"Component latency drift detected: {worst['component_id']} is "
                    f"{worst['increase_percent']:.1f}% slower "
                    f"({worst['baseline_avg_latency']:.2f}ms -> {worst['current_latency']:.2f}ms)"
                    + env_note
                ),
                "details": {
                    "drifted_components": drifted_components,
                    "worst_component": worst["component_id"],
                    "threshold_percent": threshold * 100,
                    "env_mismatch": env_mismatch,
                },
            }

        return {"detected": False}

    def _detect_content_filter_rate_change(self) -> dict[str, Any]:
        """Detect content filter rate change (changes in content filtering rates).

        Returns:
            Dictionary with detection results
        """
        if not self.baseline_fp:
            return {"detected": False, "reason": "No baseline available"}

        # Count content filter hits in current trace
        interactions = self.current_trace.get("interactions", [])
        current_filtered = 0
        total_llm_calls = 0

        for interaction in interactions:
            if interaction.get("interaction_type") == InteractionType.LLM_CALL.value:
                total_llm_calls += 1
                output = interaction.get("output", {})
                choices = output.get("choices", [])
                if choices:
                    finish_reason = choices[0].get("finish_reason", "")
                    if finish_reason == "content_filter":
                        current_filtered += 1
                # Also check metadata
                metadata = interaction.get("metadata", {})
                if metadata.get("refusal_detected"):
                    current_filtered += 1

        if total_llm_calls == 0:
            return {"detected": False, "reason": "No LLM calls in current trace"}

        current_filter_rate = current_filtered / total_llm_calls

        # Count content filter hits in baseline
        baseline_interactions = (
            self.baseline_trace.get("interactions", []) if self.baseline_trace else []
        )
        baseline_filtered = 0
        baseline_total_llm_calls = 0

        for interaction in baseline_interactions:
            if interaction.get("interaction_type") == InteractionType.LLM_CALL.value:
                baseline_total_llm_calls += 1
                output = interaction.get("output", {})
                choices = output.get("choices", [])
                if choices:
                    finish_reason = choices[0].get("finish_reason", "")
                    if finish_reason == "content_filter":
                        baseline_filtered += 1
                metadata = interaction.get("metadata", {})
                if metadata.get("refusal_detected"):
                    baseline_filtered += 1

        if baseline_total_llm_calls == 0:
            return {"detected": False, "reason": "No LLM calls in baseline trace"}

        baseline_filter_rate = baseline_filtered / baseline_total_llm_calls

        # Check for significant change
        threshold = self.thresholds["content_filter_rate_change_threshold"]
        filter_rate_change = abs(current_filter_rate - baseline_filter_rate)

        if filter_rate_change > threshold:
            direction = (
                "more content filtering"
                if current_filter_rate > baseline_filter_rate
                else "less content filtering"
            )
            return {
                "detected": True,
                "severity": "high",
                "message": f"Content filter rate change detected: {direction} (baseline: {baseline_filter_rate:.2%}, current: {current_filter_rate:.2%}, change: {filter_rate_change:.2%})",
                "details": {
                    "baseline_filter_rate": baseline_filter_rate,
                    "current_filter_rate": current_filter_rate,
                    "filter_rate_change": filter_rate_change,
                    "threshold": threshold,
                    "baseline_filtered": baseline_filtered,
                    "current_filtered": current_filtered,
                    "direction": direction,
                },
            }

        return {"detected": False}

    def _detect_tool_overuse(self) -> dict[str, Any]:
        """Detect tool overuse (excessive tool calls).

        Returns:
            Dictionary with detection results
        """
        if not self.baseline_fp:
            return {"detected": False, "reason": "No baseline available"}

        # Count tool calls in current trace
        interactions = self.current_trace.get("interactions", [])
        current_tool_calls = sum(
            1
            for interaction in interactions
            if interaction.get("interaction_type") == InteractionType.TOOL_CALL.value
        )

        # Count tool calls in baseline
        baseline_interactions = (
            self.baseline_trace.get("interactions", []) if self.baseline_trace else []
        )
        baseline_tool_calls = sum(
            1
            for interaction in baseline_interactions
            if interaction.get("interaction_type") == InteractionType.TOOL_CALL.value
        )

        if baseline_tool_calls == 0:
            # If baseline has no tools, any tool usage might be overuse
            if current_tool_calls > 0:
                return {
                    "detected": True,
                    "severity": "medium",
                    "message": f"Tool overuse detected: {current_tool_calls} tool calls (baseline: 0)",
                    "details": {
                        "baseline_tool_calls": 0,
                        "current_tool_calls": current_tool_calls,
                        "increase": current_tool_calls,
                    },
                }
            return {"detected": False}

        # Check for significant increase
        threshold = self.thresholds["tool_overuse_threshold"]
        tool_increase_ratio = (current_tool_calls - baseline_tool_calls) / baseline_tool_calls

        if tool_increase_ratio > threshold:
            return {
                "detected": True,
                "severity": "medium",
                "message": f"Tool overuse detected: {current_tool_calls} tool calls (baseline: {baseline_tool_calls}, +{tool_increase_ratio*100:.1f}%)",
                "details": {
                    "baseline_tool_calls": baseline_tool_calls,
                    "current_tool_calls": current_tool_calls,
                    "increase_ratio": tool_increase_ratio,
                    "threshold": threshold,
                },
            }

        return {"detected": False}

    def _detect_retrieval_regression(self) -> dict[str, Any]:
        """Detect retrieval regression (degraded retrieval quality).

        Returns:
            Dictionary with detection results
        """
        if not self.baseline_fp:
            return {"detected": False, "reason": "No baseline available"}

        # Extract retrieval quality from current trace
        retrieval_fns = self.thresholds["retrieval_functions"]
        interactions = self.current_trace.get("interactions", [])
        current_retrieval_scores: list[float] = []
        current_num_results: list[int] = []

        for interaction in interactions:
            if interaction.get("interaction_type") == InteractionType.TOOL_CALL.value:
                input_data = interaction.get("input", {})
                fn_name = input_data.get("function", "")
                is_retrieval = (
                    fn_name in retrieval_fns
                    or interaction.get("metadata", {}).get("spooled_category") == "retrieval"
                )
                if is_retrieval:
                    metadata = interaction.get("metadata", {})
                    quality = metadata.get("retrieval_quality")
                    num_results = metadata.get("num_results")
                    if quality is not None:
                        try:
                            current_retrieval_scores.append(float(quality))
                        except (ValueError, TypeError):
                            pass
                    if num_results is not None:
                        try:
                            current_num_results.append(int(num_results))
                        except (ValueError, TypeError):
                            pass

        if not current_retrieval_scores:
            return {"detected": False, "reason": "No retrieval quality data available"}

        current_avg_quality = sum(current_retrieval_scores) / len(current_retrieval_scores)
        current_avg_results = (
            sum(current_num_results) / len(current_num_results) if current_num_results else 0
        )

        # Extract baseline retrieval quality
        baseline_interactions = (
            self.baseline_trace.get("interactions", []) if self.baseline_trace else []
        )
        baseline_retrieval_scores: list[float] = []
        baseline_num_results: list[int] = []

        for interaction in baseline_interactions:
            if interaction.get("interaction_type") == InteractionType.TOOL_CALL.value:
                input_data = interaction.get("input", {})
                fn_name = input_data.get("function", "")
                is_retrieval = (
                    fn_name in retrieval_fns
                    or interaction.get("metadata", {}).get("spooled_category") == "retrieval"
                )
                if is_retrieval:
                    metadata = interaction.get("metadata", {})
                    quality = metadata.get("retrieval_quality")
                    num_results = metadata.get("num_results")
                    if quality is not None:
                        try:
                            baseline_retrieval_scores.append(float(quality))
                        except (ValueError, TypeError):
                            pass
                    if num_results is not None:
                        try:
                            baseline_num_results.append(int(num_results))
                        except (ValueError, TypeError):
                            pass

        if not baseline_retrieval_scores:
            return {"detected": False, "reason": "No baseline retrieval quality data available"}

        baseline_avg_quality = sum(baseline_retrieval_scores) / len(baseline_retrieval_scores)
        baseline_avg_results = (
            sum(baseline_num_results) / len(baseline_num_results) if baseline_num_results else 0
        )

        # Check for regression (quality decrease or results decrease)
        threshold = self.thresholds["retrieval_regression_threshold"]
        quality_decrease = baseline_avg_quality - current_avg_quality
        results_decrease_ratio = (
            (baseline_avg_results - current_avg_results) / baseline_avg_results
            if baseline_avg_results > 0
            else 0
        )

        if quality_decrease > threshold or results_decrease_ratio > threshold:
            return {
                "detected": True,
                "severity": "high",
                "message": f"Retrieval regression detected: quality {current_avg_quality:.2f} (baseline: {baseline_avg_quality:.2f}, -{quality_decrease:.2f}), results {current_avg_results:.1f} (baseline: {baseline_avg_results:.1f})",
                "details": {
                    "baseline_avg_quality": baseline_avg_quality,
                    "current_avg_quality": current_avg_quality,
                    "quality_decrease": quality_decrease,
                    "baseline_avg_results": baseline_avg_results,
                    "current_avg_results": current_avg_results,
                    "results_decrease_ratio": results_decrease_ratio,
                    "threshold": threshold,
                },
            }

        return {"detected": False}

    # ── Content-blind signal detection ────────────────────────────────

    def _detect_output_schema_drift(self) -> dict[str, Any]:
        """Detect changes in output field names per tool.

        Content-blind: tracks field *names* (e.g., "regulatory_citation is missing"),
        not field *values*.
        """
        if not self.baseline_manager:
            return {"detected": False, "reason": "No baseline manager available"}

        stats = self.baseline_manager.get_stats(self.current_trace)
        if stats is None or stats.sample_count == 0:
            return {"detected": False, "reason": "No baseline for this intent (cold start)"}

        baseline_schemas = stats.output_schema_snapshots
        if not baseline_schemas:
            return {"detected": False, "reason": "No output schemas in baseline"}

        # Extract current schemas from fingerprint tool_signatures first
        current_fp_data = self.current_fp.generate()
        tool_signatures = current_fp_data.get("tool_graph", {}).get("tool_signatures", [])

        current_schemas: dict[str, list[str]] = {}
        for sig in tool_signatures:
            name = sig.get("name", "")
            output_keys = sig.get("output_keys", [])
            if name and output_keys:
                current_schemas[name] = sorted(output_keys)

        # Fallback: extract from raw interactions if tool_signatures didn't yield schemas
        if not current_schemas:
            interactions = self.current_trace.get("interactions", [])
            for interaction in interactions:
                if interaction.get("interaction_type") == InteractionType.TOOL_CALL.value:
                    tool_name = (
                        interaction.get("input", {}).get("function")
                        or interaction.get("input", {}).get("tool")
                        or interaction.get("input", {}).get("tool_name")
                    )
                    if not tool_name:
                        continue
                    output = interaction.get("output") or {}
                    # Prefer explicit output_keys if present; otherwise use output dict keys
                    output_keys = output.get("output_keys", [])
                    if not output_keys and isinstance(output, dict):
                        output_keys = [k for k in output.keys() if k != "output_keys"]
                    if output_keys:
                        current_schemas[tool_name] = sorted(output_keys)

        if not current_schemas:
            return {"detected": False, "reason": "No output schemas in current trace"}

        total_removed = 0
        total_added = 0
        changes: list[dict[str, Any]] = []
        for tool_name, baseline_keys in baseline_schemas.items():
            current_keys = current_schemas.get(tool_name)
            if current_keys is None:
                continue  # Tool absent from current trace; other signals cover this

            baseline_set = set(baseline_keys)
            current_set = set(current_keys)

            removed_fields = sorted(baseline_set - current_set)
            added_fields = sorted(current_set - baseline_set)

            if removed_fields or added_fields:
                total_removed += len(removed_fields)
                total_added += len(added_fields)
                changes.append(
                    {
                        "tool": tool_name,
                        "baseline_fields": sorted(baseline_set),
                        "current_fields": sorted(current_set),
                        "added_fields": added_fields,
                        "removed_fields": removed_fields,
                        # Keep short aliases for policy engine compatibility
                        "removed": removed_fields,
                        "added": added_fields,
                    }
                )

        if changes:
            has_removed = any(c["removed_fields"] for c in changes)
            severity = "high" if has_removed else "medium"

            primary = changes[0]
            msg_parts: list[str] = []
            if primary["removed_fields"]:
                dropped = ", ".join(f"'{f}'" for f in primary["removed_fields"])
                msg_parts.append(f"'{primary['tool']}' dropped field {dropped}")
            if primary["added_fields"]:
                added = ", ".join(f"'{f}'" for f in primary["added_fields"])
                msg_parts.append(f"'{primary['tool']}' added field {added}")

            return {
                "detected": True,
                "severity": severity,
                "message": f"Output schema changed: {'; '.join(msg_parts)}",
                "details": {
                    "changes": changes,
                    "total_removed": total_removed,
                    "total_added": total_added,
                },
            }

        return {"detected": False}

    def _detect_sequence_drift(self) -> dict[str, Any]:
        """Detect tool execution order changes within structurally matched intents.

        Fires when the structural fingerprint matches the baseline but the
        sequence fingerprint differs. This is informational only — tool ordering
        variance is expected for LLM-based agents.

        Returns:
            Signal dict with detected=True if sequence differs, severity=info.
        """
        if not self.baseline_manager:
            return {"detected": False}

        interactions = self.current_trace.get("interactions", [])
        if not interactions:
            return {"detected": False}

        baseline_stats = self.baseline_manager.get_stats(self.current_trace)
        if baseline_stats is None:
            return {"detected": False}

        from spooled.fingerprint import calculate_fingerprint_hash

        current_seq_hash = calculate_fingerprint_hash(interactions, mode="sequence")
        current_struct_hash = calculate_fingerprint_hash(interactions, mode="structural")

        baseline_struct_hash = getattr(baseline_stats, "structural_fingerprint_hash", None)

        # Only fires when structural hashes match (same tool set) but sequences differ
        if not baseline_struct_hash or baseline_struct_hash != current_struct_hash:
            return {"detected": False}

        # Check if the sequence hash matches any known fingerprint
        baseline_fp_hash = getattr(baseline_stats, "fingerprint_hash", None)
        accepted = set(baseline_stats.accepted_fingerprints or [])
        if baseline_fp_hash:
            accepted.add(baseline_fp_hash)

        if current_seq_hash in accepted:
            return {"detected": False}

        return {
            "detected": True,
            "severity": "info",
            "is_blocker": False,
            "message": "Tool execution order differs from baseline — expected variance for LLM agents",
            "current_sequence_hash": current_seq_hash[:16],
        }

    def _calculate_severity(self, signals: dict[str, Any]) -> str:
        """Calculate overall severity.

        Args:
            signals: Dictionary of detected signals

        Returns:
            Overall severity: "high", "medium", "low", or "none"
        """
        severities = []
        for signal in signals.values():
            if isinstance(signal, dict) and signal.get("detected"):
                severities.append(signal.get("severity", "low"))

        if "high" in severities:
            return "high"
        elif "medium" in severities:
            return "medium"
        elif severities:
            return "low"
        else:
            return "none"
