"""Spooled CLI - Command-line tool for replaying traces."""

from __future__ import annotations

__version__ = "0.5.0"
