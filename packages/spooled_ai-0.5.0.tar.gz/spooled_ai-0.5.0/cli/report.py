"""AI Behavior Diff Report generator for CI/CD."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import structlog

from cli.diff import TraceDiff
from spooled.baseline import BaselineManager, load_baseline_from_path
from spooled.fingerprint import (
    BehavioralFingerprint,
    fingerprint_similarity_detailed,
    hash_fingerprint,
)
from spooled.policy import PolicyEngine
from spooled.signals import SignalDetector
from spooled.storage import load_trace_from_jsonl

logger = structlog.get_logger(__name__)


class AIBehaviorReport:
    """Generates AI Behavior Diff Reports for CI/CD."""

    def __init__(
        self,
        trace_file: Path,
        agent_id: str,
        baseline_trace_file: Path | None = None,
        policy_file: Path | None = None,
    ) -> None:
        """Initialize report generator.

        Args:
            trace_file: Path to current trace file
            agent_id: Agent identifier
            baseline_trace_file: Optional path to baseline trace file
            policy_file: Optional path to policy YAML file
        """
        self.trace_file = trace_file
        self.agent_id = agent_id
        self.baseline_trace_file = baseline_trace_file
        self.policy_engine = PolicyEngine(policy_file)

    def generate(self) -> dict[str, Any]:
        """Generate the complete report.

        Returns:
            Dictionary with report data
        """
        # Load traces
        current_trace = self._load_trace(self.trace_file)
        baseline_trace = None

        baseline_manager = None
        baseline_data = None
        if self.baseline_trace_file:
            loaded = self._load_trace(self.baseline_trace_file)
            # Only use as full trace if it has a "trace" key (i.e., it's a JSONL trace).
            # BaselineSummary JSON files (e.g., .github/baselines/*.json) don't have "trace",
            # so we skip TraceDiff and load as AgentBaseline for fingerprint matching.
            if "trace" in loaded:
                baseline_trace = loaded
            else:
                logger.debug(
                    "Baseline file is a summary, loading as AgentBaseline for fingerprint matching",
                    path=str(self.baseline_trace_file),
                )
                try:
                    baseline_data = load_baseline_from_path(self.baseline_trace_file, self.agent_id)
                    baseline_manager = BaselineManager(self.agent_id)
                    baseline_manager._baseline = baseline_data
                except Exception as e:
                    logger.debug("Could not load baseline summary", error=str(e))
        else:
            # Try to get from baseline manager
            try:
                baseline_manager = BaselineManager(self.agent_id)

                # Phase 4: Try to pull from remote before analysis (with short timeout)
                try:
                    baseline_manager.pull_from_remote(timeout=5.0)
                    logger.debug("Baseline pulled from remote", agent_id=self.agent_id)
                except Exception as e:
                    logger.debug(
                        "Could not pull baseline from remote, using local",
                        error=str(e),
                        agent_id=self.agent_id,
                    )

                loaded_baseline = baseline_manager.load_baseline()
                if loaded_baseline and loaded_baseline.intents:
                    baseline_data = loaded_baseline
                    logger.debug("Baseline loaded from manager", agent_id=self.agent_id)
            except Exception as e:
                logger.debug("Could not load baseline", error=str(e))

        # Generate fingerprints
        current_fp = BehavioralFingerprint(current_trace).generate()
        current_fp_hash = hash_fingerprint(current_fp)

        # Fingerprint matching against baseline (same logic as ci compare)
        fingerprint_status = "no_baseline"
        similarity_score = None
        metric_deltas = {}
        baseline_fp_hash = None
        tool_diff = None

        if baseline_data and baseline_data.intents:
            if current_fp_hash in baseline_data.intents:
                fingerprint_status = "match"
                baseline_fp_hash = current_fp_hash
            else:
                # Check accepted variants
                for intent_id, intent_stat in baseline_data.intents.items():
                    if current_fp_hash in intent_stat.accepted_fingerprints:
                        fingerprint_status = "accepted_variant"
                        baseline_fp_hash = intent_id
                        break
                else:
                    fingerprint_status = "new"
                    baseline_fp_hash = next(iter(baseline_data.intents), None)

        # Variant detection via similarity (matches ci compare logic)
        if fingerprint_status == "new" and baseline_data and baseline_data.intents:
            best_detail = None
            best_intent = None
            for b_intent in baseline_data.intents.values():
                b_fp = b_intent.fingerprint if hasattr(b_intent, "fingerprint") else None
                if b_fp:
                    detail = fingerprint_similarity_detailed(current_fp, b_fp)
                    if best_detail is None or detail["overall"] > best_detail["overall"]:
                        best_detail = detail
                        best_intent = b_intent
            if best_detail and best_detail["overall"] >= 0.75:
                fingerprint_status = "variant"
                similarity_score = round(best_detail["overall"], 2)
            # Compute tool diff for variant/new
            if best_intent is not None:
                current_tools = set(current_fp.get("tool_graph", {}).get("unique_tools", []))
                baseline_tools = set(
                    best_intent.fingerprint.get("tool_graph", {}).get("unique_tools", [])
                    if hasattr(best_intent, "fingerprint") and best_intent.fingerprint
                    else []
                )
                tool_diff = {
                    "added": sorted(current_tools - baseline_tools),
                    "removed": sorted(baseline_tools - current_tools),
                    "baseline_sequence": (
                        best_intent.fingerprint.get("tool_graph", {}).get("sequence", [])
                        if hasattr(best_intent, "fingerprint") and best_intent.fingerprint
                        else []
                    ),
                    "current_sequence": current_fp.get("tool_graph", {}).get("sequence", []),
                }

        # Compute metric deltas from baseline stats
        if baseline_fp_hash and baseline_data and baseline_fp_hash in baseline_data.intents:
            bstat = baseline_data.intents[baseline_fp_hash]
            interactions = current_trace.get("interactions", [])
            # Token delta
            current_tokens = 0
            for interaction in interactions:
                if interaction.get("interaction_type") == "LLM_CALL":
                    usage = interaction.get("output", {}).get("usage") or interaction.get(
                        "metadata", {}
                    ).get("usage")
                    if usage and isinstance(usage, dict):
                        t = usage.get("total_tokens")
                        if t and isinstance(t, (int, float)):
                            current_tokens += t
            if bstat.avg_tokens > 0:
                token_delta = current_tokens - bstat.avg_tokens
                metric_deltas["tokens"] = {
                    "current": current_tokens,
                    "baseline_avg": bstat.avg_tokens,
                    "delta": token_delta,
                    "delta_pct": round((token_delta / bstat.avg_tokens) * 100, 1),
                }
            # Step count delta
            current_step_count = len(interactions)
            if bstat.step_count > 0:
                metric_deltas["step_count"] = {
                    "current": current_step_count,
                    "baseline": bstat.step_count,
                    "delta": current_step_count - bstat.step_count,
                }

        # Retrieve similarity trend from baseline
        similarity_trend: list = []
        if baseline_fp_hash and baseline_data and baseline_fp_hash in baseline_data.intents:
            similarity_trend = getattr(
                baseline_data.intents[baseline_fp_hash], "similarity_trend", []
            )

        # Detect signals (pass baseline_manager for token usage and component latency detection)
        signal_detector = SignalDetector(
            current_trace, baseline_trace, baseline_manager=baseline_manager
        )
        signals = signal_detector.detect_signals()

        # Generate diff if baseline available
        diff_result = None
        if baseline_trace:
            diff = TraceDiff(current_trace, baseline_trace)
            diff_result = diff.diff()

        # Evaluate policy if available
        policy_result = self.policy_engine.evaluate(signals, diff_result)

        # Compute Spooled Score (same inputs as ci compare)
        from spooled.scoring import compute_spooled_score

        spooled_score = compute_spooled_score(
            fingerprint_status=fingerprint_status,
            similarity_score=similarity_score,
            signals=signals,
            metric_deltas=metric_deltas,
            similarity_trend=similarity_trend,
        )

        # Build report
        report = {
            "agent_id": self.agent_id,
            "trace_file": str(self.trace_file),
            "run_id": current_trace.get("trace", {}).get("run_id"),
            "timestamp": current_trace.get("trace", {}).get("timestamp"),
            "status": current_trace.get("trace", {}).get("status"),
            "fingerprint": current_fp,
            "fingerprint_status": fingerprint_status,
            "signals": signals,
            "diff": diff_result,
            "tool_diff": tool_diff,
            "policy": policy_result,
            "spooled_score": spooled_score,
            "summary": self._generate_summary(signals, diff_result, policy_result),
        }

        return report

    def _load_trace(self, trace_file: Path) -> dict[str, Any]:
        """Load trace from file.

        Args:
            trace_file: Path to trace file

        Returns:
            Trace data dictionary
        """
        if trace_file.suffix == ".jsonl":
            return load_trace_from_jsonl(trace_file)
        else:
            with open(trace_file) as f:
                return json.load(f)

    def _generate_summary(
        self,
        signals: dict[str, Any],
        diff_result: dict[str, Any] | None,
        policy_result: dict[str, Any],
    ) -> dict[str, Any]:
        """Generate report summary.

        Args:
            signals: Detected signals
            diff_result: Diff result if available
            policy_result: Policy evaluation result

        Returns:
            Summary dictionary
        """
        summary = {
            "has_warnings": signals.get("has_warnings", False),
            "severity": signals.get("severity", "none"),
            "signal_count": sum(
                1 for s in signals.values() if isinstance(s, dict) and s.get("detected")
            ),
        }

        if diff_result:
            summary["structural_changes"] = diff_result.get("structural_diff", {}).get(
                "has_structural_changes", False
            )
            summary["total_differences"] = diff_result.get("summary", {}).get(
                "total_differences", 0
            )

        # Add policy information
        summary["policy_enabled"] = policy_result.get("enabled", False)
        summary["policy_passed"] = policy_result.get("passed", True)
        summary["should_block"] = policy_result.get("should_block", False)
        summary["policy_violations"] = len(policy_result.get("violations", []))

        return summary

    def to_markdown(self, report_data: dict[str, Any] | None = None) -> str:
        """Convert report to Markdown format.

        Args:
            report_data: Report data (if None, generates it)

        Returns:
            Markdown formatted string
        """
        if report_data is None:
            report_data = self.generate()

        lines = []
        lines.append("# AI Behavior Diff Report")
        lines.append("")
        lines.append(f"**Agent:** `{report_data['agent_id']}`")
        lines.append(f"**Run ID:** `{report_data['run_id']}`")
        lines.append(f"**Status:** `{report_data['status']}`")
        lines.append(f"**Timestamp:** `{report_data['timestamp']}`")
        lines.append("")

        # Summary
        summary = report_data["summary"]
        severity = summary["severity"]
        severity_emoji = {"high": "🔴", "medium": "🟡", "low": "🟢", "none": "✅"}.get(
            severity, "⚪"
        )

        lines.append(f"## Summary {severity_emoji}")
        lines.append("")
        lines.append(f"- **Severity:** {severity.upper()}")
        signal_count = summary["signal_count"]
        lines.append(f"- **Signals:** {signal_count}")
        lines.append(f"- **Has Warnings:** {'Yes' if signal_count > 0 else 'No'}")
        if "structural_changes" in summary:
            lines.append(
                f"- **Structural Changes:** {'Yes' if summary['structural_changes'] else 'No'}"
            )

        # Policy status
        if summary.get("policy_enabled"):
            policy_status = "🛡️ BLOCKED" if summary.get("should_block") else "✅ PASSED"
            lines.append(f"- **Policy Status:** {policy_status}")
            if summary.get("policy_violations", 0) > 0:
                lines.append(f"- **Policy Violations:** {summary['policy_violations']}")
        lines.append("")

        # Spooled Score
        spooled = report_data.get("spooled_score", {})
        if spooled and spooled.get("score") is not None:
            sc = spooled["score"]
            grade = spooled.get("grade", "-")
            confidence = spooled.get("confidence", "low")
            lines.append(f"## Spooled Score: {sc}/100 ({grade})")
            lines.append("")
            comps = spooled.get("components", {})
            lines.append("| Component | Score | Weight |")
            lines.append("|-----------|-------|--------|")
            lines.append(f"| Structural Similarity | {comps.get('structural', 'N/A')} | 40% |")
            lines.append(f"| Signal Health | {comps.get('signal', 'N/A')} | 25% |")
            lines.append(f"| Metric Stability | {comps.get('metric', 'N/A')} | 20% |")
            lines.append(f"| Trend Consistency | {comps.get('trend', 'N/A')} | 15% |")
            lines.append("")
            lines.append(f"*Confidence: {confidence}*")
            lines.append("")

        # Tool Changes (from fingerprint comparison)
        tool_diff = report_data.get("tool_diff")
        fp_status = report_data.get("fingerprint_status", "")
        if tool_diff and (tool_diff.get("added") or tool_diff.get("removed")):
            lines.append("## 🔧 Changes Detected")
            lines.append("")
            if tool_diff.get("removed"):
                for tool in tool_diff["removed"]:
                    lines.append(f"- ➖ `{tool}` removed")
            if tool_diff.get("added"):
                for tool in tool_diff["added"]:
                    lines.append(f"- ➕ `{tool}` added")
            if tool_diff.get("baseline_sequence") or tool_diff.get("current_sequence"):
                lines.append("")
                if tool_diff.get("baseline_sequence"):
                    seq = " → ".join(f"`{t}`" for t in tool_diff["baseline_sequence"])
                    lines.append(f"**Baseline:** {seq}")
                if tool_diff.get("current_sequence"):
                    seq = " → ".join(f"`{t}`" for t in tool_diff["current_sequence"])
                    lines.append(f"**Current:** {seq}")
            lines.append("")
        elif fp_status and fp_status not in ("match", "accepted_variant", "no_baseline"):
            lines.append("## 🔧 Changes Detected")
            lines.append("")
            lines.append(f"- Fingerprint status: **{fp_status.upper()}**")
            lines.append("")

        # Signals
        signals = report_data["signals"]
        detected_signals = [
            (name, signal)
            for name, signal in signals.items()
            if isinstance(signal, dict) and signal.get("detected")
        ]

        if detected_signals:
            lines.append("## ⚠️ Detected Signals")
            lines.append("")

            for signal_name, signal_data in detected_signals:
                severity = signal_data.get("severity", "unknown")
                message = signal_data.get("message", "Signal detected")
                lines.append(f"### {signal_name.replace('_', ' ').title()}")
                lines.append(f"**Severity:** {severity.upper()}")
                lines.append(f"**Message:** {message}")
                if "details" in signal_data:
                    lines.append("")
                    lines.append("```json")
                    lines.append(json.dumps(signal_data["details"], indent=2))
                    lines.append("```")
                lines.append("")

        # Structural Diff
        if report_data.get("diff"):
            diff_result = report_data["diff"]
            structural_diff = diff_result.get("structural_diff", {})

            if structural_diff.get("has_structural_changes"):
                lines.append("## 🔍 Structural Changes")
                lines.append("")

                for diff in structural_diff.get("differences", []):
                    diff_type = diff.get("type", "unknown")
                    description = diff.get("description", "")
                    lines.append(f"- **{diff_type}:** {description}")

                    if diff_type == "tool_sequence_change":
                        for tool_diff in diff.get("differences", []):
                            lines.append(f"  - {tool_diff.get('description', '')}")
                    elif diff_type == "tool_usage_change":
                        if diff.get("new_tools"):
                            lines.append(f"  - New tools: {', '.join(diff['new_tools'])}")
                        if diff.get("removed_tools"):
                            lines.append(f"  - Removed tools: {', '.join(diff['removed_tools'])}")

                lines.append("")

        # Policy Evaluation
        policy_result = report_data.get("policy", {})
        if policy_result.get("enabled"):
            lines.append("## 🛡️ Policy Evaluation")
            lines.append("")
            lines.append(f"- **Policy:** `{policy_result.get('policy_name', 'unknown')}`")
            lines.append(
                f"- **Status:** {'❌ FAILED' if not policy_result.get('passed') else '✅ PASSED'}"
            )
            lines.append(
                f"- **Block Merges:** {'Yes' if policy_result.get('block_merges') else 'No'}"
            )
            lines.append(
                f"- **Should Block:** {'Yes' if policy_result.get('should_block') else 'No'}"
            )
            lines.append(f"- **Violations:** {len(policy_result.get('violations', []))}")
            lines.append(f"- **Warnings:** {len(policy_result.get('warnings', []))}")
            lines.append("")

            if policy_result.get("violations"):
                lines.append("### Policy Violations")
                lines.append("")
                for violation in policy_result["violations"]:
                    lines.append(
                        f"- **{violation.get('type', 'unknown')}:** {violation.get('message', '')}"
                    )
                lines.append("")

            if policy_result.get("warnings"):
                lines.append("### Policy Warnings")
                lines.append("")
                for warning in policy_result["warnings"]:
                    lines.append(
                        f"- **{warning.get('type', 'unknown')}:** {warning.get('message', '')}"
                    )
                lines.append("")

        # Fingerprint Summary
        fp = report_data["fingerprint"]
        lines.append("## 📊 Behavioral Fingerprint")
        lines.append("")
        lines.append(f"- **Total Interactions:** {len(fp.get('interaction_sequence', []))}")
        unique_tools = fp.get("tool_graph", {}).get("unique_tools", [])
        lines.append(f"- **Unique Tools:** {len(unique_tools)}")
        if unique_tools:
            lines.append(f"- **Tool Names:** {', '.join(f'`{t}`' for t in unique_tools)}")
        tool_sequence = fp.get("tool_graph", {}).get("sequence", [])
        if tool_sequence:
            lines.append(f"- **Tool Sequence:** {' → '.join(f'`{t}`' for t in tool_sequence)}")
        lines.append(f"- **Tool Calls:** {fp.get('tool_graph', {}).get('tool_count', 0)}")
        lines.append(f"- **Errors:** {fp.get('error_patterns', {}).get('error_count', 0)}")
        lines.append("")

        return "\n".join(lines)

    def save(self, output_path: Path, format: str = "markdown") -> None:
        """Save report to file.

        Args:
            output_path: Path to save report
            format: Format to save ("markdown" or "json")
        """
        report_data = self.generate()

        if format == "json":
            with open(output_path, "w") as f:
                json.dump(report_data, f, indent=2)
        else:  # markdown
            markdown = self.to_markdown(report_data)
            with open(output_path, "w") as f:
                f.write(markdown)

        logger.info("Report saved", path=str(output_path), format=format)
