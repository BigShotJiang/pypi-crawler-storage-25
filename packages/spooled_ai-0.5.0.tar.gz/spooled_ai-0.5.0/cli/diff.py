"""Basic execution diffing for comparing two traces."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import structlog

from spooled.fingerprint import BehavioralFingerprint
from spooled.models import Interaction, Trace
from spooled.storage import load_trace_from_jsonl

logger = structlog.get_logger(__name__)


class TraceDiff:
    """Compare two traces and identify differences."""

    def __init__(self, trace1: dict[str, Any], trace2: dict[str, Any]) -> None:
        """Initialize the trace diff.

        Args:
            trace1: First trace data
            trace2: Second trace data
        """
        self.trace1 = Trace(**trace1.get("trace", {}))
        self.trace2 = Trace(**trace2.get("trace", {}))
        self.interactions1 = [Interaction(**i) for i in trace1.get("interactions", [])]
        self.interactions2 = [Interaction(**i) for i in trace2.get("interactions", [])]
        # Generate behavioral fingerprints
        self.fingerprint1 = BehavioralFingerprint(trace1)
        self.fingerprint2 = BehavioralFingerprint(trace2)

    def diff(self) -> dict[str, Any]:
        """Compute the diff between two traces.

        Returns:
            Dictionary containing diff results
        """
        fp1 = self.fingerprint1.generate()
        fp2 = self.fingerprint2.generate()

        result: dict[str, Any] = {
            "trace_metadata": self._diff_trace_metadata(),
            "interaction_count": {
                "trace1": len(self.interactions1),
                "trace2": len(self.interactions2),
                "difference": len(self.interactions1) - len(self.interactions2),
            },
            "interactions": self._diff_interactions(),
            "structural_diff": self._diff_structural(fp1, fp2),
            "fingerprints": {
                "trace1": fp1,
                "trace2": fp2,
            },
            "summary": {},
        }

        # Generate summary
        result["summary"] = {
            "total_differences": self._count_differences(result),
            "interaction_count_match": len(self.interactions1) == len(self.interactions2),
            "trace_metadata_match": result["trace_metadata"]["match"],
            "structural_changes": self._count_structural_changes(result["structural_diff"]),
        }

        return result

    def _diff_trace_metadata(self) -> dict[str, Any]:
        """Compare trace metadata.

        Returns:
            Dictionary with metadata differences
        """
        differences = []
        matches = []

        # Compare agent_id
        if self.trace1.agent_id != self.trace2.agent_id:
            differences.append(
                {
                    "field": "agent_id",
                    "trace1": self.trace1.agent_id,
                    "trace2": self.trace2.agent_id,
                }
            )
        else:
            matches.append("agent_id")

        # Compare status
        if self.trace1.status != self.trace2.status:
            differences.append(
                {
                    "field": "status",
                    "trace1": self.trace1.status,
                    "trace2": self.trace2.status,
                }
            )
        else:
            matches.append("status")

        # Compare environment
        env_diff = self._diff_dicts(self.trace1.environment, self.trace2.environment)
        if env_diff:
            differences.append({"field": "environment", "differences": env_diff})
        else:
            matches.append("environment")

        return {
            "match": len(differences) == 0,
            "differences": differences,
            "matches": matches,
        }

    def _diff_interactions(self) -> list[dict[str, Any]]:
        """Compare interactions between traces.

        Returns:
            List of interaction diffs
        """
        diffs = []
        max_len = max(len(self.interactions1), len(self.interactions2))

        for i in range(max_len):
            if i >= len(self.interactions1):
                diffs.append(
                    {
                        "sequence": i,
                        "type": "missing_in_trace1",
                        "interaction": self.interactions2[i].model_dump(),
                    }
                )
            elif i >= len(self.interactions2):
                diffs.append(
                    {
                        "sequence": i,
                        "type": "missing_in_trace2",
                        "interaction": self.interactions1[i].model_dump(),
                    }
                )
            else:
                interaction_diff = self._diff_single_interaction(
                    self.interactions1[i], self.interactions2[i]
                )
                if interaction_diff:
                    diffs.append({"sequence": i, **interaction_diff})

        return diffs

    def _diff_single_interaction(
        self, interaction1: Interaction, interaction2: Interaction
    ) -> dict[str, Any]:
        """Compare a single interaction.

        Args:
            interaction1: First interaction
            interaction2: Second interaction

        Returns:
            Dictionary with differences, or empty if they match
        """
        differences = []

        # Compare interaction type
        if interaction1.interaction_type != interaction2.interaction_type:
            differences.append(
                {
                    "field": "interaction_type",
                    "trace1": interaction1.interaction_type,
                    "trace2": interaction2.interaction_type,
                }
            )

        # Compare input
        input_diff = self._diff_dicts(interaction1.input, interaction2.input)
        if input_diff:
            differences.append({"field": "input", "differences": input_diff})

        # Compare output
        output_diff = self._diff_dicts(interaction1.output, interaction2.output)
        if output_diff:
            differences.append({"field": "output", "differences": output_diff})

        # Compare error
        if interaction1.error != interaction2.error:
            differences.append(
                {
                    "field": "error",
                    "trace1": interaction1.error,
                    "trace2": interaction2.error,
                }
            )

        # Compare metadata
        metadata_diff = self._diff_dicts(interaction1.metadata, interaction2.metadata)
        if metadata_diff:
            differences.append({"field": "metadata", "differences": metadata_diff})

        if differences:
            return {"type": "different", "differences": differences}
        return {}

    def _diff_dicts(self, dict1: dict[str, Any], dict2: dict[str, Any]) -> list[dict[str, Any]]:
        """Compare two dictionaries.

        Args:
            dict1: First dictionary
            dict2: Second dictionary

        Returns:
            List of differences
        """
        differences = []
        dict1 = dict1 or {}
        dict2 = dict2 or {}
        all_keys = set(dict1.keys()) | set(dict2.keys())

        for key in all_keys:
            val1 = dict1.get(key)
            val2 = dict2.get(key)

            if val1 != val2:
                differences.append(
                    {
                        "key": key,
                        "trace1": val1,
                        "trace2": val2,
                    }
                )

        return differences

    def _count_differences(self, diff_result: dict[str, Any]) -> int:
        """Count total number of differences.

        Args:
            diff_result: The diff result dictionary

        Returns:
            Total count of differences
        """
        count = 0

        # Count trace metadata differences
        count += len(diff_result["trace_metadata"]["differences"])

        # Count interaction differences
        count += len(diff_result["interactions"])

        return count

    def _diff_structural(self, fp1: dict[str, Any], fp2: dict[str, Any]) -> dict[str, Any]:
        """Compare structural differences using fingerprints.

        Args:
            fp1: First fingerprint
            fp2: Second fingerprint

        Returns:
            Dictionary with structural differences
        """
        differences = []

        # Compare interaction sequence
        seq1 = fp1.get("interaction_sequence", [])
        seq2 = fp2.get("interaction_sequence", [])
        if seq1 != seq2:
            differences.append(
                {
                    "type": "sequence_change",
                    "description": "Interaction sequence differs",
                    "trace1_sequence": seq1,
                    "trace2_sequence": seq2,
                }
            )

        # Compare tool graph
        tool_graph1 = fp1.get("tool_graph", {})
        tool_graph2 = fp2.get("tool_graph", {})
        tool_seq1 = tool_graph1.get("sequence", [])
        tool_seq2 = tool_graph2.get("sequence", [])

        if tool_seq1 != tool_seq2:
            # Find specific differences
            tool_diffs = self._diff_tool_sequences(tool_seq1, tool_seq2)
            differences.append(
                {
                    "type": "tool_sequence_change",
                    "description": "Tool call sequence differs",
                    "differences": tool_diffs,
                }
            )

        # Compare unique tools
        unique_tools1 = set(tool_graph1.get("unique_tools", []))
        unique_tools2 = set(tool_graph2.get("unique_tools", []))
        new_tools = unique_tools2 - unique_tools1
        removed_tools = unique_tools1 - unique_tools2

        if new_tools or removed_tools:
            differences.append(
                {
                    "type": "tool_usage_change",
                    "description": "Tool usage changed",
                    "new_tools": list(new_tools),
                    "removed_tools": list(removed_tools),
                }
            )

        # Compare branch paths
        branches1 = fp1.get("branch_paths", [])
        branches2 = fp2.get("branch_paths", [])
        if len(branches1) != len(branches2):
            differences.append(
                {
                    "type": "branch_count_change",
                    "description": f"Branch count changed: {len(branches1)} -> {len(branches2)}",
                }
            )

        # Compare error patterns
        errors1 = fp1.get("error_patterns", {})
        errors2 = fp2.get("error_patterns", {})
        if errors1.get("error_count", 0) != errors2.get("error_count", 0):
            differences.append(
                {
                    "type": "error_count_change",
                    "description": f"Error count changed: {errors1.get('error_count', 0)} -> {errors2.get('error_count', 0)}",
                }
            )

        return {
            "has_structural_changes": len(differences) > 0,
            "differences": differences,
        }

    def _diff_tool_sequences(self, seq1: list[str], seq2: list[str]) -> list[dict[str, Any]]:
        """Compare two tool sequences and find specific differences.

        Args:
            seq1: First tool sequence
            seq2: Second tool sequence

        Returns:
            List of specific differences
        """
        diffs = []
        max_len = max(len(seq1), len(seq2))

        for i in range(max_len):
            if i >= len(seq1):
                diffs.append(
                    {
                        "position": i,
                        "type": "inserted",
                        "tool": seq2[i],
                        "description": f"Tool '{seq2[i]}' inserted at position {i}",
                    }
                )
            elif i >= len(seq2):
                diffs.append(
                    {
                        "position": i,
                        "type": "removed",
                        "tool": seq1[i],
                        "description": f"Tool '{seq1[i]}' removed at position {i}",
                    }
                )
            elif seq1[i] != seq2[i]:
                diffs.append(
                    {
                        "position": i,
                        "type": "changed",
                        "tool1": seq1[i],
                        "tool2": seq2[i],
                        "description": f"Tool changed at position {i}: '{seq1[i]}' -> '{seq2[i]}'",
                    }
                )

        return diffs

    def _count_structural_changes(self, structural_diff: dict[str, Any]) -> int:
        """Count structural changes.

        Args:
            structural_diff: Structural diff dictionary

        Returns:
            Number of structural changes
        """
        return len(structural_diff.get("differences", []))

    def format_diff(self, diff_result: dict[str, Any], verbose: bool = False) -> str:
        """Format the diff result as a human-readable string.

        Args:
            diff_result: The diff result dictionary
            verbose: Whether to show detailed differences

        Returns:
            Formatted string
        """
        lines = ["Trace Diff Summary", "=" * 50, ""]

        # Summary
        summary = diff_result["summary"]
        lines.append(f"Total Differences: {summary['total_differences']}")
        lines.append(f"Interaction Count Match: {summary['interaction_count_match']}")
        lines.append(f"Trace Metadata Match: {summary['trace_metadata_match']}")
        lines.append("")

        # Trace metadata differences
        if diff_result["trace_metadata"]["differences"]:
            lines.append("Trace Metadata Differences:")
            for diff in diff_result["trace_metadata"]["differences"]:
                if verbose:
                    import json

                    val1 = (
                        json.dumps(diff.get("trace1"), indent=2)
                        if diff.get("trace1") is not None
                        else "None"
                    )
                    val2 = (
                        json.dumps(diff.get("trace2"), indent=2)
                        if diff.get("trace2") is not None
                        else "None"
                    )
                    lines.append(f"  - {diff['field']}:")
                    lines.append(f"    Trace 1: {val1}")
                    lines.append(f"    Trace 2: {val2}")
                else:
                    lines.append(
                        f"  - {diff['field']}: {diff.get('trace1')} vs {diff.get('trace2')}"
                    )
            lines.append("")

        # Structural differences (Phase 2)
        if "structural_diff" in diff_result:
            structural = diff_result["structural_diff"]
            if structural.get("has_structural_changes"):
                lines.append("Structural Differences (Behavioral Fingerprint):")
                for diff in structural.get("differences", []):
                    diff_type = diff.get("type", "unknown")
                    description = diff.get("description", "")
                    lines.append(f"  [{diff_type}] {description}")

                    if diff_type == "tool_sequence_change" and verbose:
                        for tool_diff in diff.get("differences", []):
                            lines.append(f"    - {tool_diff.get('description', '')}")
                    elif diff_type == "tool_usage_change":
                        if diff.get("new_tools"):
                            lines.append(f"    New tools: {', '.join(diff['new_tools'])}")
                        if diff.get("removed_tools"):
                            lines.append(f"    Removed tools: {', '.join(diff['removed_tools'])}")
                lines.append("")

        # Interaction differences
        if diff_result["interactions"]:
            lines.append(f"Interaction Differences ({len(diff_result['interactions'])}):")
            limit = len(diff_result["interactions"]) if verbose else 10
            for interaction_diff in diff_result["interactions"][:limit]:
                seq = interaction_diff.get("sequence", "?")
                diff_type = interaction_diff.get("type", "unknown")
                lines.append(f"  Sequence {seq}: {diff_type}")
                if verbose:
                    details = interaction_diff.get("details", {})
                    if details:
                        import json

                        lines.append(f"    Details: {json.dumps(details, indent=4)}")
            if not verbose and len(diff_result["interactions"]) > 10:
                lines.append(
                    f"  ... and {len(diff_result['interactions']) - 10} more (use --verbose to see all)"
                )

        return "\n".join(lines)


def diff_traces(trace_file1: Path, trace_file2: Path) -> dict[str, Any]:
    """Compare two trace files.

    Args:
        trace_file1: Path to first trace file
        trace_file2: Path to second trace file

    Returns:
        Dictionary containing diff results
    """
    # Load traces
    if trace_file1.suffix == ".jsonl":
        trace_data1 = load_trace_from_jsonl(trace_file1)
    else:
        import json

        with open(trace_file1) as f:
            trace_data1 = json.load(f)

    if trace_file2.suffix == ".jsonl":
        trace_data2 = load_trace_from_jsonl(trace_file2)
    else:
        import json

        with open(trace_file2) as f:
            trace_data2 = json.load(f)

    # Compute diff
    diff = TraceDiff(trace_data1, trace_data2)
    return diff.diff()
