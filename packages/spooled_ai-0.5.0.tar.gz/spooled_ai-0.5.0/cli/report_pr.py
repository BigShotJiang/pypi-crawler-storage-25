"""PR-ready markdown report generator for CI pipeline output.

Generates compact, actionable markdown designed to be posted as
GitHub PR comments via `gh pr comment`.
"""

from __future__ import annotations

import os
from typing import Any


def build_pr_markdown(
    ci_summary: dict[str, Any],
    results: list[dict[str, Any]],
    baseline_dir: str = "baselines",
) -> str:
    """Build a PR-ready markdown report from CI results.

    Args:
        ci_summary: Aggregate CI summary
        results: Per-trace comparison results

    Returns:
        Markdown string suitable for PR comment
    """
    lines: list[str] = []
    ui_url = os.environ.get("SPOOLED_UI_URL", "").rstrip("/")

    # Header with status emoji and Spooled Score
    overall = ci_summary.get("overall_result", "PASS")
    badge = "PASS" if overall == "PASS" else "FAIL"
    status_emoji = "\u2705" if overall == "PASS" else "\u274c"
    agent_score = ci_summary.get("spooled_score", {})
    score_val = agent_score.get("score") if agent_score else None
    score_grade = agent_score.get("grade", "-") if agent_score else "-"
    ci_report_id = ci_summary.get("ci_report_id")
    view_link = (
        f" \u00b7 [View \u2192]({ui_url}/ci/{ci_report_id})" if ui_url and ci_report_id else ""
    )
    if score_val is not None:
        score_dot = _score_dot(score_val)
        lines.append(f"## {status_emoji} Spooled Behavioral CI: **{badge}**")
        lines.append(f"> **Spooled Score: {score_val}/100 ({score_grade})** {score_dot}{view_link}")
    else:
        lines.append(f"## {status_emoji} Spooled Behavioral CI: **{badge}**")
        if view_link:
            _strip_chars = " \u00b7 "
            lines.append(f"> {view_link.lstrip(_strip_chars)}")
    lines.append("")

    # Summary metrics — compact inline format
    total = ci_summary.get("total_traces", 0)
    passed = ci_summary.get("passed", 0)
    new_beh = ci_summary.get("new_behavior", 0)
    policy_fail = ci_summary.get("policy_failures", 0)

    parts = [f"**{total}** traces analyzed"]
    if passed > 0:
        parts.append(f"\u2705 **{passed}** passed")
    if new_beh > 0:
        parts.append(f"\U0001f7e1 **{new_beh}** new behavior")
    if policy_fail > 0:
        parts.append(f"\u274c **{policy_fail}** policy failures")
    lines.append("  |  ".join(parts))
    lines.append("")

    # No-baseline guidance (first run)
    no_baseline_count = ci_summary.get("no_baseline", 0)
    if no_baseline_count > 0 and no_baseline_count == total:
        lines.append("> [!NOTE]")
        lines.append("> **No baselines found.** First run! Generate and commit baselines:")
        lines.append("> ```bash")
        lines.append(f"> spooled ci update-baseline --out {baseline_dir}/")
        lines.append(f"> git add {baseline_dir}/ && git commit -m 'Add AI baselines'")
        lines.append("> ```")
        lines.append("")

    # Multi-Agent Sessions (if present)
    sessions = ci_summary.get("sessions")
    if sessions:
        lines.append("### Multi-Agent Sessions")
        lines.append("")
        lines.append("| Session | Agents | Traces | Status |")
        lines.append("|---------|--------|--------|--------|")
        for sess in sessions:
            sid = sess.get("session_id", "")[:8]
            agents_str = ", ".join(sess.get("agents", []))
            count = sess.get("trace_count", 0)
            status = sess.get("status", "?")
            status_icon = {
                "PASS": "\u2705 PASS",
                "FAIL": "\u274c FAIL",
                "WARN": "\u26a0\ufe0f WARN",
            }.get(status, status)
            lines.append(f"| `{sid}...` | {agents_str} | {count} | {status_icon} |")
        lines.append("")

    # Per-trace details
    if results:
        lines.append("### Trace Results")
        lines.append("")
        lines.append("| Agent | Fingerprint | Status | Score | Signals | Tokens |")
        lines.append("|-------|-------------|--------|-------|---------|--------|")

        for r in results:
            agent = r.get("agent_id", "unknown")
            fp = r.get("fingerprint_hash", "")[:12]
            status = r.get("fingerprint_status", "unknown")

            status_icon = {
                "match": "\u2705 Pass",
                "accepted_variant": "\u2705 Pass (variant)",
                "new": "\U0001f195 New behavior (no baseline match)",
                "no_baseline": "\u2796 no baseline",
                "not_compared": "\u2796 policy-only",
                "variant": "\u26a0\ufe0f Variant",
            }.get(status, status)

            signal_count = r.get("summary", {}).get("signal_count", 0)
            severity = r.get("summary", {}).get("severity", "none")
            signal_str = f"{signal_count} ({severity})" if signal_count > 0 else "none"

            # Token delta with arrows
            token_str = "-"
            deltas = r.get("metric_deltas", {})
            if "tokens" in deltas:
                t = deltas["tokens"]
                token_str = _format_token_delta(t)

            # Append reason_label to variant status
            reason_label = r.get("reason_label")
            if status == "variant" and reason_label:
                status_icon = f"\u26a0\ufe0f Variant \u00b7 {reason_label}"

            # Link to UI if available
            run_id = r.get("run_id", "")
            if ui_url and run_id:
                agent_link = f"[{agent}]({ui_url}/traces/{run_id})"
            else:
                agent_link = agent

            trace_score = (
                r.get("spooled_score", {}).get("score")
                if isinstance(r.get("spooled_score"), dict)
                else r.get("summary", {}).get("spooled_score")
            )
            score_str = str(trace_score) if trace_score is not None else "-"

            lines.append(
                f"| {agent_link} | `{fp}...` | {status_icon} | {score_str} | {signal_str} | {token_str} |"
            )

        lines.append("")

    # Callouts — GitHub markdown alerts
    if new_beh > 0:
        lines.append("> [!WARNING]")
        lines.append(
            f"> **{new_beh} new behavior pattern(s) detected.** Intentional? Accept below. Bug? Fix the agent code."
        )
        lines.append("")
    if policy_fail > 0:
        lines.append("> [!CAUTION]")
        lines.append(
            f"> **{policy_fail} policy violation(s) will block merge.** Review below or update the policy."
        )
        lines.append("")

    # Tool diff section — surface tool changes from trace results
    tool_diff_traces = []
    for r in results:
        td = r.get("tool_diff")
        if td and (td.get("added") or td.get("removed")):
            tool_diff_traces.append(r)

    if tool_diff_traces:
        lines.append("<details>")
        lines.append(
            f"<summary>\U0001f527 Tool Changes ({len(tool_diff_traces)} trace(s))</summary>"
        )
        lines.append("")
        for r in tool_diff_traces:
            agent = r.get("agent_id", "unknown")
            td = r.get("tool_diff", {})
            lines.append(f"**{agent}**")
            if td.get("added"):
                for tool in td["added"]:
                    lines.append(f"- \u2795 `{tool}` added")
            if td.get("removed"):
                for tool in td["removed"]:
                    lines.append(f"- \u2796 `{tool}` removed")
            if td.get("current_sequence"):
                seq = " \u2192 ".join(f"`{t}`" for t in td["current_sequence"])
                lines.append(f"- Sequence: {seq}")
            lines.append("")
        lines.append("</details>")
        lines.append("")

    # Intent distribution — show behavioral branching for agents with multiple intents
    agents_with_distribution = []
    for r in results:
        dist = r.get("intent_distribution", [])
        if len(dist) >= 2:
            agents_with_distribution.append(r)

    if agents_with_distribution:
        lines.append("<details>")
        lines.append("<summary>Behavior Distribution</summary>")
        lines.append("")
        for r in agents_with_distribution:
            agent = r.get("agent_id", "unknown")
            dist = r.get("intent_distribution", [])
            lines.append(f"**{agent}**")
            lines.append("")
            for entry in dist:
                iid = entry["intent_id"][:12]
                pct = entry["frequency_pct"]
                runs = entry["run_count"]
                is_current = entry.get("is_current", False)
                seq = entry.get("tool_sequence", [])
                bar_len = max(1, round(pct / 5))  # 1 char per 5%
                bar = "\u2588" * bar_len
                marker = " **(this run)**" if is_current else ""
                seq_str = ""
                if seq:
                    seq_str = " " + " \u2192 ".join(f"`{t}`" for t in seq)
                lines.append(f"- `{iid}` {bar} {pct}% ({runs} runs){marker}{seq_str}")
            lines.append("")
        lines.append("</details>")
        lines.append("")

    # Detected signals detail (only for non-trivial signals)
    significant_signals = []
    for r in results:
        signals = r.get("signals", {})
        for name, signal in signals.items():
            if (
                isinstance(signal, dict)
                and signal.get("detected")
                and signal.get("severity") not in ("info", None)
            ):
                significant_signals.append(
                    {
                        "agent_id": r.get("agent_id"),
                        "name": name,
                        "severity": signal.get("severity"),
                        "message": signal.get("message", ""),
                    }
                )

    # Human-readable labels for signal names
    _SIGNAL_LABELS = {
        "latency_spike": "Latency spike",
        "token_spike": "Token usage spike",
        "new_behavior_pattern": "New behavior pattern",
        "tool_sequence_change": "Tool sequence changed",
        "error_rate_increase": "Error rate increased",
        "new_tool_call": "New tool call detected",
        "removed_tool_call": "Tool call removed",
        "model_change": "Model changed",
        "new_http_endpoint": "New HTTP endpoint",
        "side_effect_change": "Side effect changed",
        "cost_spike": "Cost spike",
        "schema_drift": "Output schema drift",
    }

    _SEVERITY_EMOJI = {
        "high": "\U0001f534",
        "medium": "\U0001f7e1",
        "low": "\U0001f7e2",
    }

    if significant_signals:
        lines.append("<details>")
        lines.append(f"<summary>Signals ({len(significant_signals)} detected)</summary>")
        lines.append("")
        for sig in significant_signals:
            sev = sig["severity"]
            sev_emoji = _SEVERITY_EMOJI.get(sev, "\u26aa")
            label = _SIGNAL_LABELS.get(sig["name"], sig["name"].replace("_", " ").title())
            lines.append(
                f"- {sev_emoji} **{sev.upper()}** `{sig['agent_id']}` \u2014 {label}: {sig['message']}"
            )
        lines.append("")
        lines.append("</details>")
        lines.append("")

    # Policy violations
    all_violations = []
    for r in results:
        policy = r.get("policy", {})
        for v in policy.get("violations", []):
            all_violations.append({"agent_id": r.get("agent_id"), **v})

    if all_violations:
        lines.append("<details>")
        lines.append(f"<summary>Policy Violations ({len(all_violations)})</summary>")
        lines.append("")
        for v in all_violations:
            lines.append(
                f"- `{v.get('agent_id')}` - **{v.get('type', 'unknown')}**: {v.get('message', '')}"
            )
        lines.append("")
        lines.append("</details>")
        lines.append("")

    # How to resolve
    if new_beh > 0 or policy_fail > 0:
        lines.append("<details>")
        lines.append("<summary>How to resolve</summary>")
        lines.append("")
        if new_beh > 0:
            lines.append(
                "**New behavior detected:** If this change is intentional, update the baseline:"
            )
            lines.append("```bash")
            lines.append("spooled ci update-baseline --out baselines/")
            lines.append("git add baselines/ && git commit -m 'Update AI baselines'")
            lines.append("```")
            lines.append("")
        if policy_fail > 0:
            lines.append("**Policy violation:** Review the signals above and either:")
            lines.append("1. Fix the agent behavior to match the baseline")
            lines.append(
                "2. Accept the new variant: `spooled ci accept-variant --intent <id> --fingerprint <hash> --baseline baselines/<agent>.json`"
            )
            lines.append("3. Update the policy to allow this behavior")
            lines.append("")
        lines.append("</details>")
        lines.append("")

    # Quick approve section: pre-filled commands for new-behavior traces
    new_behavior_results = [r for r in results if r.get("fingerprint_status") == "new"]
    if new_behavior_results:
        lines.append("> [!TIP]")
        lines.append(
            f"> **Quick approve** \u2014 accept {len(new_behavior_results)} new pattern(s) without pulling the branch locally."
        )
        lines.append("")
        lines.append("<details open>")
        lines.append(
            f"<summary>Quick approve ({len(new_behavior_results)} new pattern(s))</summary>"
        )
        lines.append("")
        lines.append("Run one command per agent, or trigger from GitHub Actions UI.")
        lines.append("")
        for r in new_behavior_results:
            agent = r.get("agent_id", "unknown")
            fp_hash = r.get("fingerprint_hash", "")
            baseline_file = f"{baseline_dir}/{agent}.json"
            lines.append(f"**{agent}** \u2014 fingerprint `{fp_hash[:16]}...`")
            lines.append("")
            lines.append("CLI:")
            lines.append("```bash")
            lines.append(
                f"spooled ci accept-variant \\\n"
                f"  --intent {fp_hash} \\\n"
                f"  --fingerprint {fp_hash} \\\n"
                f"  --baseline {baseline_file}"
            )
            lines.append("```")
            lines.append("")
            lines.append("Or via GitHub Actions (no local checkout needed):")
            lines.append("```bash")
            lines.append(
                f"gh workflow run spooled-approve-variant.yml \\\n"
                f"  -f intent_id={fp_hash} \\\n"
                f"  -f fingerprint_hash={fp_hash} \\\n"
                f"  -f baseline_file={baseline_file} \\\n"
                f"  -f agent_id={agent}"
            )
            lines.append("```")
            lines.append("")
        lines.append("</details>")
        lines.append("")

    # CI report link
    ci_report_id = ci_summary.get("ci_report_id")
    if ui_url and ci_report_id:
        lines.append(f"[View full CI report in Spooled]({ui_url}/ci/{ci_report_id})")
        lines.append("")

    # GitHub Actions artifact download link
    gh_server_url = os.environ.get("GITHUB_SERVER_URL", "")
    gh_repository = os.environ.get("GITHUB_REPOSITORY", "")
    gh_run_id = os.environ.get("GITHUB_RUN_ID", "")
    if gh_server_url and gh_repository and gh_run_id:
        lines.append(
            f"[Download full CI report]({gh_server_url}/{gh_repository}/actions/runs/{gh_run_id})"
        )
        lines.append("")

    # Footer
    lines.append("---")
    lines.append(
        "*[Spooled](https://spooled.ai) \u2014 CI for AI agents* | [Docs](https://spooled.ai/docs) | [GitHub](https://github.com/spooled-ai/spooled)"
    )

    return "\n".join(lines)


def _score_dot(score: int) -> str:
    """Return a colored dot emoji based on score value."""
    if score >= 80:
        return "\U0001f7e2"
    elif score >= 60:
        return "\U0001f7e1"
    else:
        return "\U0001f534"


def _format_token_delta(t: dict[str, Any]) -> str:
    """Format token delta with arrow indicators."""
    delta_pct = t.get("delta_pct", 0)
    current = t.get("current", 0)
    if abs(delta_pct) < 3:
        arrow = "\u2194\ufe0f"
    elif delta_pct > 0:
        arrow = "\U0001f53a" if delta_pct > 10 else "\u2197\ufe0f"
    else:
        arrow = "\U0001f53b" if delta_pct < -10 else "\u2198\ufe0f"
    sign = "+" if t.get("delta", 0) >= 0 else ""
    return f"{arrow} {current:.0f} ({sign}{delta_pct}%)"
