"""Main CLI entry point using Typer."""

from __future__ import annotations

import sys

import structlog
import typer
from dotenv import load_dotenv
from rich.console import Console

from cli import __version__, commands
from spooled.utils import get_auth_headers

# Load .env file if it exists
load_dotenv()

# Configure structlog for CLI — only show warnings and above
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.dev.ConsoleRenderer(),
    ],
    wrapper_class=structlog.stdlib.BoundLogger,
    logger_factory=structlog.stdlib.LoggerFactory(),
)

# Set root log level to WARNING so info/debug messages don't leak to console
import logging

logging.basicConfig(format="%(message)s", level=logging.WARNING)

logger = structlog.get_logger(__name__)
console = Console()


def _version_callback(value: bool) -> None:
    if value:
        console.print(f"spooled version {__version__}")
        raise typer.Exit()


app = typer.Typer(
    name="spooled",
    help="Flight Recorder for AI Agents - capture and replay execution traces",
    add_completion=False,
    pretty_exceptions_enable=False,
)


@app.callback(invoke_without_command=True)
def app_callback(
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show the version number.",
    ),
) -> None:
    """Flight Recorder for AI Agents - capture and replay execution traces."""


# Register subcommands
app.add_typer(commands.pull.app, name="pull", help="Pull a trace from the backend")
app.add_typer(commands.replay.app, name="replay", help="Replay a trace locally")
app.add_typer(commands.diff.app, name="diff", help="Compare two traces")
app.add_typer(commands.view.app, name="view", help="View and pretty-print traces")
app.add_typer(commands.list.app, name="list", help="List traces (local and remote)")
app.add_typer(commands.init.app, name="init", help="Initialize a project for Spooled")
app.add_typer(commands.verify.app, name="verify", help="Verify hash chain integrity")
app.add_typer(commands.baseline.app, name="baseline", help="Manage behavioral baselines")
app.add_typer(commands.fingerprint.app, name="fingerprint", help="Generate behavioral fingerprints")
app.add_typer(commands.ci.app, name="ci", help="CI/CD integration commands")
app.add_typer(commands.fleet.app, name="fleet", help="Fleet-level agent management")
app.add_typer(commands.policy.app, name="policy", help="Policy management commands")

app.add_typer(commands.keys.app, name="keys", help="Manage API keys (admin)")
app.add_typer(commands.session.app, name="session", help="View multi-agent trace sessions")
app.add_typer(commands.doctor.app, name="doctor", help="Check Spooled setup health")
app.add_typer(commands.attest.app, name="attest", help="Manage behavioral attestations")
app.add_typer(commands.traces.app, name="traces", help="Manage local traces")
app.add_typer(commands.new_agent.app, name="new-agent", help="Scaffold a new agent for Spooled")
app.add_typer(commands.demo.app, name="demo", help="See Spooled in action (zero setup)")
app.add_typer(commands.watch.app, name="watch", help="Watch traces in real time")
app.add_typer(commands.ingest.app, name="ingest", help="Import traces from external systems")
app.add_typer(commands.analyze.app, name="analyze", help="Analyze agent behavioral stability")


@app.command()
def version() -> None:
    """Show the version number."""
    console.print(f"spooled version {__version__}")


@app.command()
def status(
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend API URL (overrides env var)"
    ),
) -> None:
    """Show the status of the spooled backend connection."""
    import os

    try:
        import httpx
    except ImportError:
        console.print("[yellow]⚠[/yellow] httpx not installed, cannot check backend status")
        console.print("Install with: pip install httpx")
        return

    url = backend_url or os.getenv("SPOOLED_BACKEND_URL", "https://api.spooled.ai")
    health_url = f"{url.rstrip('/')}/api/health"

    try:
        with httpx.Client(timeout=5.0) as client:
            response = client.get(health_url)
    except httpx.ConnectError:
        console.print(f"[red]✗[/red] Cannot connect to backend at {url}")
        console.print("Make sure the backend is running or check the URL")
        return
    except httpx.TimeoutException:
        console.print(f"[red]✗[/red] Backend at {url} timed out")
        return
    except Exception as e:
        logger.debug("Status check failed", error=str(e))
        console.print(f"[red]✗[/red] Status check failed: {str(e)}")
        return

    if response.status_code != 200:
        console.print(
            f"[red]✗[/red] Backend at {url} is not healthy "
            f"(HTTP {response.status_code} from /api/health)"
        )
        return

    try:
        body = response.json()
    except Exception:
        console.print(
            f"[red]✗[/red] {url} responded but didn't return JSON — "
            "this doesn't look like a Spooled backend"
        )
        return

    if not isinstance(body, dict) or body.get("status") != "healthy":
        console.print(
            f"[red]✗[/red] {url}/api/health responded but didn't report status=healthy — "
            "this doesn't look like a Spooled backend"
        )
        return

    console.print(f"[green]✓[/green] Backend connection healthy ({url})")


@app.command()
def whoami(
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend API URL (overrides env var)"
    ),
) -> None:
    """Show the org context for the current API key."""
    import os

    try:
        try:
            import httpx
        except ImportError:
            console.print("[yellow]⚠[/yellow] httpx not installed, cannot check identity")
            console.print("Install with: pip install httpx")
            return

        url = backend_url or os.getenv("SPOOLED_BACKEND_URL", "https://api.spooled.ai")
        whoami_url = f"{url.rstrip('/')}/api/whoami"
        headers = {"Accept": "application/json", **get_auth_headers()}

        if "X-Api-Key" not in headers:
            console.print("[red]✗[/red] Missing API key (set SPOOLED_API_KEY)")
            return

        with httpx.Client(timeout=5.0) as client:
            response = client.get(whoami_url, headers=headers)
            response.raise_for_status()
            data = response.json()

        console.print(f"[green]✓[/green] org_id: {data.get('org_id')}")
    except Exception as e:
        logger.debug("Whoami failed", error=str(e))
        console.print(f"[red]✗[/red] Whoami failed: {str(e)}")


def main() -> None:
    """Main entry point for the CLI."""
    try:
        app()
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user[/yellow]")
        sys.exit(130)
    except Exception as e:
        logger.debug("Unhandled error", error=str(e))
        console.print(f"[red]Error:[/red] {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
