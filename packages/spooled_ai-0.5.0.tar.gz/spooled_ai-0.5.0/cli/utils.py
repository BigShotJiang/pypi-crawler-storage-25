"""Shared CLI utilities."""

from __future__ import annotations

from pathlib import Path


def resolve_trace_path(arg: str, trace_file_override: Path | None = None) -> Path | None:
    """Resolve a trace argument that could be a file path or a run ID.

    Checks in order:
    1. If trace_file_override is given (--file flag), use it directly.
    2. If arg looks like a file path (contains / or ends with .jsonl/.json) and exists, use it.
    3. Try resolving as a run ID: .spooled/traces/{arg}.jsonl, then traces/{arg}.jsonl,
       then traces/{arg}.json.
    4. Return None if nothing found.
    """
    if trace_file_override is not None:
        return trace_file_override

    arg_path = Path(arg)

    # If it looks like a file path and exists, use it directly
    if arg_path.exists():
        return arg_path

    # Try resolving as a run ID
    candidates = [
        Path(".spooled") / "traces" / f"{arg}.jsonl",
        Path("traces") / f"{arg}.jsonl",
        Path("traces") / f"{arg}.json",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate

    return None


def extract_run_id(arg: str) -> str:
    """Extract a clean run ID from a trace argument.

    If arg is a file path like '.spooled/traces/abc-123.jsonl', returns 'abc-123'.
    If arg is already a run ID, returns it unchanged.
    """
    p = Path(arg)
    stem = p.stem
    # Handle double extensions like .jsonl -> stem still has the name
    if stem.endswith(".json"):
        stem = Path(stem).stem
    return stem
