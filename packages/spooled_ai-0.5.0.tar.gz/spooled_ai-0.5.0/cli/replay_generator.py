"""Generate pytest test files from trace data with proper ChatCompletion reconstruction."""

from __future__ import annotations

import json
from typing import Any

from spooled.models import Interaction, InteractionType, Trace


class ReplayGenerator:
    """Generates pytest test files that replay captured traces.

    The generated tests use unittest.mock to monkey-patch I/O operations
    (OpenAI calls, HTTP requests) and replay the exact execution path.
    """

    def __init__(self, run_id: str, trace_data: dict[str, Any]) -> None:
        """Initialize the replay generator.

        Args:
            run_id: The trace run_id
            trace_data: The trace data dictionary (from JSON/JSONL)
        """
        self.run_id = run_id
        self.trace = Trace(**trace_data.get("trace", {}))
        self.interactions: list[Interaction] = [
            Interaction(**i) for i in trace_data.get("interactions", [])
        ]

    def generate(self) -> str:
        """Generate the pytest test code.

        Returns:
            The complete pytest test file as a string
        """
        lines = [
            '"""Replay test generated from trace.',
            f"Run ID: {self.run_id}",
            f"Agent ID: {self.trace.agent_id}",
            f"Status: {self.trace.status}",
            f"Timestamp: {self.trace.timestamp}",
            '"""',
            "",
            "import pytest",
            "from unittest.mock import MagicMock, patch",
            "",
            "",
            f"class TestReplay_{self.run_id.replace('-', '_')}:",
            '    """Replay test for trace execution."""',
            "",
            "    def test_replay(self):",
            '        """Replay the exact execution captured in the trace."""',
        ]

        # Add mock setup for each interaction type
        openai_mocks = []
        requests_mocks = []

        for interaction in sorted(self.interactions, key=lambda x: x.sequence):
            if interaction.interaction_type == InteractionType.LLM_CALL:
                openai_mocks.append(interaction)
            elif interaction.interaction_type == InteractionType.HTTP_REQUEST:
                requests_mocks.append(interaction)

        # Generate OpenAI mocks with proper ChatCompletion reconstruction
        if openai_mocks:
            lines.extend(self._generate_openai_mocks(openai_mocks))

        # Generate requests mocks
        if requests_mocks:
            lines.extend(self._generate_requests_mocks(requests_mocks))

        # Add assertion
        lines.extend(
            [
                "        # Assert that all expected interactions occurred",
                f"        # Total interactions in trace: {len(self.interactions)}",
                "        # TODO: Add assertions based on expected outputs",
            ]
        )

        return "\n".join(lines)

    def _generate_openai_mocks(self, interactions: list[Interaction]) -> list[str]:
        """Generate mock setup code for OpenAI interactions with proper ChatCompletion reconstruction.

        Args:
            interactions: List of LLM call interactions

        Returns:
            List of code lines for the mock setup
        """
        lines = [
            "        # Reconstruct ChatCompletion objects from trace",
            "        from openai.types.chat import ChatCompletion, ChatCompletionMessage",
            "        from openai.types.chat.chat_completion import Choice, CompletionUsage",
            "",
            "        def reconstruct_chat_completion(output_data: dict) -> ChatCompletion:",
            '            """Reconstruct a ChatCompletion object from logged data."""',
            "            if not output_data:",
            "                return None",
            "",
            "            # Handle streaming responses",
            '            if output_data.get("stream"):',
            "                # For streaming, create a mock that yields chunks",
            "                # This is simplified - full implementation would reconstruct chunks",
            "                return MagicMock()",
            "",
            "            # Reconstruct from standard response format",
            "            choices_data = output_data.get('choices', [])",
            "            choices = []",
            "            for choice_data in choices_data:",
            "                message_data = choice_data.get('message', {})",
            "                message = ChatCompletionMessage(",
            '                    role=message_data.get("role", "assistant"),',
            '                    content=message_data.get("content", ""),',
            "                )",
            "                choice = Choice(",
            '                    index=choice_data.get("index", 0),',
            "                    message=message,",
            '                    finish_reason=choice_data.get("finish_reason"),',
            "                )",
            "                choices.append(choice)",
            "",
            "            usage_data = output_data.get('usage', {})",
            "            usage = CompletionUsage(",
            '                prompt_tokens=usage_data.get("prompt_tokens", 0),',
            '                completion_tokens=usage_data.get("completion_tokens", 0),',
            '                total_tokens=usage_data.get("total_tokens", 0),',
            "            ) if usage_data else None",
            "",
            "            return ChatCompletion(",
            '                id=output_data.get("id", ""),',
            '                object="chat.completion",',
            '                created=output_data.get("created", 0),',
            '                model=output_data.get("model", ""),',
            "                choices=choices,",
            "                usage=usage,",
            "            )",
            "",
            "        # Build mock responses in sequence",
            "        mock_responses = [",
        ]

        for interaction in interactions:
            if interaction.output:
                # Serialize the output data as a Python dict literal
                output_str = json.dumps(interaction.output, indent=12)
                lines.append(f"            reconstruct_chat_completion({output_str}),")
            else:
                lines.append("            None,  # No output recorded")

        lines.extend(
            [
                "        ]",
                "",
                "        # Patch OpenAI client",
                '        with patch("openai.resources.chat.completions.Completions.create") as mock_create:',
                "            mock_create.side_effect = mock_responses",
                "",
                "            # TODO: Import and run the actual agent code here",
                "            # Example:",
                "            # from your_agent import run_agent",
                "            # result = run_agent()",
                "            # assert result == expected_output",
                "",
                "            # Verify all mocks were called",
                f"            assert mock_create.call_count == {len(interactions)}",
            ]
        )

        return lines

    def _generate_requests_mocks(self, interactions: list[Interaction]) -> list[str]:
        """Generate mock setup code for HTTP requests interactions.

        Args:
            interactions: List of HTTP request interactions

        Returns:
            List of code lines for the mock setup
        """
        lines = [
            "        # Mock HTTP requests",
            "        from unittest.mock import Mock",
            "",
            "        def create_mock_response(output_data: dict):",
            '            """Create a mock response object from logged data."""',
            "            mock_response = Mock()",
            "            if output_data:",
            "                mock_response.json.return_value = output_data",
            "                mock_response.status_code = output_data.get('status_code', 200)",
            "                mock_response.text = json.dumps(output_data)",
            "            return mock_response",
            "",
            "        mock_responses = [",
        ]

        for interaction in interactions:
            if interaction.output:
                output_str = json.dumps(interaction.output, indent=12)
                lines.append(f"            create_mock_response({output_str}),")
            else:
                lines.append("            Mock(),  # No output recorded")

        lines.extend(
            [
                "        ]",
                "",
                '        with patch("requests.Session.request") as mock_request:',
                "            mock_request.side_effect = mock_responses",
                "",
                "            # TODO: Import and run the actual agent code here",
                "",
                "            # Verify all mocks were called",
                f"            assert mock_request.call_count == {len(interactions)}",
            ]
        )

        return lines
