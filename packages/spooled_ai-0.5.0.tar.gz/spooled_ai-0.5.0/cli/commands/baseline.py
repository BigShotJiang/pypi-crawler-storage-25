"""Command to manage baselines for behavioral comparison."""

from __future__ import annotations

from pathlib import Path

import structlog
import typer
from rich.console import Console
from rich.table import Table

from spooled.baseline import BaselineManager, create_baseline_from_trace
from spooled.storage import get_trace_directory, load_trace_from_jsonl

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="baseline", help="Manage behavioral baselines")


@app.command()
def add(
    trace_file: Path = typer.Argument(..., help="Path to trace file to add to baseline"),
    agent_id: str = typer.Option(..., "--agent-id", "-a", help="Agent identifier"),
    size: int = typer.Option(10, "--size", "-s", help="Number of runs to keep in baseline"),
) -> None:
    """Add a trace to the baseline for an agent.

    Only successful traces are added to the baseline.

    Example:
       spooled baseline add .spooled/traces/run-123.jsonl --agent-id my_agent
    """
    try:
        if not trace_file.exists():
            console.print(f"[red]✗[/red] Trace file not found: {trace_file}")
            raise typer.Exit(code=1)

        create_baseline_from_trace(trace_file, agent_id, baseline_size=size)
        console.print(f"[green]✓[/green] Added trace to baseline for agent: {agent_id}")

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to add to baseline", error=str(e))
        console.print(f"[red]✗[/red] Failed to add to baseline: {str(e)}")
        raise typer.Exit(code=1)


@app.command()
def show(
    agent_id: str = typer.Argument(..., help="Agent identifier"),
    baseline_dir: Path | None = typer.Option(
        None,
        "--baseline-dir",
        "-b",
        help="Directory containing baseline JSON files (auto-discovers .github/baselines/ and baselines/)",
    ),
) -> None:
    """Show the current baseline for an agent.

    Example:
       spooled baseline show my_agent
       spooled baseline show my_agent --baseline-dir .github/baselines/
    """
    try:
        baseline = None

        # Try explicit --baseline-dir first
        if baseline_dir:
            bf = baseline_dir / f"{agent_id}.json"
            if bf.exists():
                import json as _json

                from spooled.models import BaselineSummary

                with open(bf) as f:
                    baseline = BaselineSummary(**_json.load(f))
                console.print(f"[dim]Loaded from {bf}[/dim]")

        # Auto-discover common baseline directories
        if baseline is None:
            for candidate_dir in [
                Path(".github/baselines"),
                Path("baselines"),
            ]:
                bf = candidate_dir / f"{agent_id}.json"
                if bf.exists():
                    import json as _json

                    from spooled.models import BaselineSummary

                    with open(bf) as f:
                        baseline = BaselineSummary(**_json.load(f))
                    console.print(f"[dim]Loaded from {bf}[/dim]")
                    break

        # Fall back to SDK baseline cache
        if baseline is None:
            manager = BaselineManager(agent_id)
            baseline = manager.load_baseline()

        if not baseline.intents:
            console.print(f"[yellow]No baseline found for agent: {agent_id}[/yellow]")
            console.print("\n[yellow]💡 Tip:[/yellow] Add traces to baseline with:")
            console.print(
                f"    [cyan]spooled baseline add <trace_file> --agent-id {agent_id}[/cyan]"
            )
            return

        # Display baseline info per intent
        for intent_id, intent_stat in baseline.intents.items():
            # Handle both full (AgentBaseline) and compact (BaselineSummary) formats
            has_runs = hasattr(intent_stat, "runs") and intent_stat.runs

            if has_runs:
                table = Table(title=f"Baseline for {agent_id} (intent {intent_id[:12]}...)")
                table.add_column("Run ID", style="cyan")
                table.add_column("Timestamp", style="green")
                table.add_column("Interactions", style="yellow")
                table.add_column("Tools", style="magenta")
                table.add_column("Tokens", style="green")
                table.add_column("Latency (ms)", style="yellow")

                for run in intent_stat.runs:
                    fp = run.get("fingerprint", {})
                    tool_graph = fp.get("tool_graph", {})
                    table.add_row(
                        str(run.get("run_id", "unknown"))[:16] + "...",
                        str(run.get("timestamp", "unknown"))[:19],
                        str(len(fp.get("interaction_sequence", []))),
                        str(len(tool_graph.get("unique_tools", []))),
                        str(run.get("total_tokens", "—")),
                        str(run.get("total_latency_ms", "—")),
                    )

                console.print(table)
            else:
                # Compact BaselineSummary format
                table = Table(title=f"Baseline for {agent_id} (intent {intent_id[:12]}...)")
                table.add_column("Field", style="cyan")
                table.add_column("Value", style="green")

                table.add_row("Steps", str(intent_stat.step_count))
                table.add_row(
                    "Tools",
                    (
                        ", ".join(intent_stat.tool_call_counts.keys())
                        if intent_stat.tool_call_counts
                        else "—"
                    ),
                )
                table.add_row(
                    "Runs",
                    str(
                        getattr(intent_stat, "run_count", getattr(intent_stat, "sample_count", "—"))
                    ),
                )
                table.add_row("Avg Tokens", f"{intent_stat.avg_tokens:.0f}")
                table.add_row("Avg Latency", f"{intent_stat.avg_latency:.0f}ms")
                if intent_stat.accepted_fingerprints:
                    table.add_row("Accepted Variants", str(len(intent_stat.accepted_fingerprints)))

                console.print(table)

            console.print(
                f"[dim]Intent stats: avg_latency={intent_stat.avg_latency:.0f}ms, "
                f"avg_tokens={intent_stat.avg_tokens:.0f}, "
                f"sample_count={getattr(intent_stat, 'sample_count', getattr(intent_stat, 'run_count', 0))}[/dim]\n"
            )

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to show baseline", error=str(e))
        console.print(f"[red]✗[/red] Failed to show baseline: {str(e)}")
        raise typer.Exit(code=1)


@app.command()
def compare(
    trace_file: Path = typer.Argument(..., help="Path to trace file to compare"),
    agent_id: str = typer.Option(..., "--agent-id", "-a", help="Agent identifier"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed comparison"),
) -> None:
    """Compare a trace against the baseline.

    Example:
       spooled baseline compare .spooled/traces/run-123.jsonl --agent-id my_agent
    """
    try:
        if not trace_file.exists():
            console.print(f"[red]✗[/red] Trace file not found: {trace_file}")
            raise typer.Exit(code=1)

        # Load trace
        if trace_file.suffix == ".jsonl":
            trace_data = load_trace_from_jsonl(trace_file)
        else:
            import json

            with open(trace_file) as f:
                trace_data = json.load(f)

        # Get baseline and stats for this trace's fingerprint
        manager = BaselineManager(agent_id)
        stats = manager.get_stats(trace_data)

        if stats is None:
            # No baseline for this fingerprint (new behavior or empty baseline)
            baseline = manager.load_baseline()
            intent_id = manager.get_intent_id(trace_data)
            from spooled.fingerprint import BehavioralFingerprint

            current_fp = BehavioralFingerprint(trace_data).generate()
            current_seq = current_fp.get("interaction_sequence", [])
            current_tools = current_fp.get("tool_graph", {}).get("unique_tools", [])

            console.print(f"\n[bold]Comparing trace against baseline for {agent_id}[/bold]\n")
            if not baseline.intents:
                console.print("[yellow]No baseline found for this agent.[/yellow]\n")
                console.print("Add traces to establish a baseline:")
            else:
                console.print(
                    "[yellow]⚠ New behavior pattern detected[/yellow] "
                    f"(intent_id: {intent_id[:16] if intent_id else 'unknown'}...)\n"
                )
                console.print(
                    "This trace has a different behavioral fingerprint than any baseline."
                )
            console.print(f"  • Interaction sequence: {current_seq}")
            console.print(f"  • Unique tools: {current_tools}")
            console.print("\n[dim]Add this trace to baseline:[/dim]")
            console.print(
                f"    [cyan]spooled baseline add {trace_file} --agent-id {agent_id}[/cyan]"
            )
            return

        # Intent found - compare current trace metrics with baseline stats
        from spooled.fingerprint import BehavioralFingerprint

        current_fp = BehavioralFingerprint(trace_data).generate()

        # Extract current trace metrics
        interactions = trace_data.get("interactions", [])
        current_tokens = 0
        for i in interactions:
            if i.get("interaction_type") == "LLM_CALL":
                usage = (i.get("output") or {}).get("usage") or (i.get("metadata") or {}).get(
                    "usage"
                )
                if usage and isinstance(usage, dict):
                    tok = usage.get("total_tokens")
                    if isinstance(tok, (int, float)):
                        current_tokens += tok
        current_latency = 0.0
        for i in interactions:
            meta = i.get("metadata") or {}
            lm = meta.get("latency_ms") or meta.get("duration_ms")
            if lm is not None:
                try:
                    current_latency += float(lm)
                except (ValueError, TypeError):
                    pass

        console.print(f"\n[bold]Comparing trace against baseline for {agent_id}[/bold]\n")

        table = Table(title="Intent-Scoped Comparison")
        table.add_column("Metric", style="cyan")
        table.add_column("Current", style="green")
        table.add_column("Baseline", style="yellow")
        table.add_column("Status", style="magenta")

        table.add_row(
            "Avg Latency (ms)",
            f"{current_latency:.0f}",
            f"{stats.avg_latency:.0f}",
            "✓" if abs(current_latency - stats.avg_latency) < stats.std_dev_latency * 2 else "⚠",
        )
        table.add_row(
            "Total Tokens",
            str(current_tokens),
            f"{stats.avg_tokens:.0f}",
            "✓" if stats.avg_tokens == 0 or current_tokens <= stats.avg_tokens * 1.5 else "⚠",
        )
        table.add_row(
            "Sample Count",
            "—",
            str(stats.sample_count),
            "",
        )

        console.print(table)
        console.print("\n[green]✓ Behavioral fingerprint matches known intent[/green]")

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to compare with baseline", error=str(e))
        console.print(f"[red]✗[/red] Failed to compare: {str(e)}")
        raise typer.Exit(code=1)


@app.command()
def push(
    agent_id_arg: str | None = typer.Argument(None, help="Agent identifier"),
    agent_id: str | None = typer.Option(
        None, "--agent-id", "-a", help="Agent identifier (alternative to positional)"
    ),
    backend_url: str | None = typer.Option(
        None,
        "--backend-url",
        "-u",
        help="Backend API URL (defaults to SPOOLED_BACKEND_URL env var)",
    ),
) -> None:
    """Push baseline to remote backend.

    Example:
       spooled baseline push my_agent
       spooled baseline push --agent-id my_agent
       spooled baseline push my_agent --backend-url https://api.example.com
    """
    try:
        resolved_id = agent_id_arg or agent_id
        if not resolved_id:
            console.print("[red]✗[/red] Agent ID required. Usage: spooled baseline push <agent_id>")
            raise typer.Exit(code=1)
        manager = BaselineManager(resolved_id)

        if manager.push_to_remote(backend_url):
            console.print(f"[green]✓[/green] Baseline pushed to remote for agent: {resolved_id}")
        else:
            console.print("[yellow]⚠[/yellow] Failed to push baseline (check logs for details)")
            raise typer.Exit(code=1)

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to push baseline", error=str(e))
        console.print(f"[red]✗[/red] Failed to push baseline: {str(e)}")
        raise typer.Exit(code=1)


@app.command()
def pull(
    agent_id_arg: str | None = typer.Argument(None, help="Agent identifier"),
    agent_id: str | None = typer.Option(
        None, "--agent-id", "-a", help="Agent identifier (alternative to positional)"
    ),
    backend_url: str | None = typer.Option(
        None,
        "--backend-url",
        "-u",
        help="Backend API URL (defaults to SPOOLED_BACKEND_URL env var)",
    ),
    timeout: float = typer.Option(5.0, "--timeout", "-t", help="Request timeout in seconds"),
) -> None:
    """Pull baseline from remote backend.

    Example:
       spooled baseline pull my_agent
       spooled baseline pull --agent-id my_agent
       spooled baseline pull my_agent --backend-url https://api.example.com
    """
    try:
        resolved_id = agent_id_arg or agent_id
        if not resolved_id:
            console.print("[red]✗[/red] Agent ID required. Usage: spooled baseline pull <agent_id>")
            raise typer.Exit(code=1)
        manager = BaselineManager(resolved_id)

        if manager.pull_from_remote(backend_url, timeout):
            baseline = manager.load_baseline()
            intent_count = len(baseline.intents)
            output_path = manager.get_baseline_file()
            console.print(f"[green]✓[/green] Baseline pulled from remote for agent: {resolved_id}")
            console.print(f"[dim]Loaded {intent_count} intent(s) → {output_path}[/dim]")
        else:
            reason = manager.last_pull_message or "(no details available)"
            console.print(f"[yellow]⚠[/yellow] Failed to pull baseline: {reason}")
            console.print("[dim]Falling back to local baseline if available[/dim]")

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to pull baseline", error=str(e))
        console.print(f"[red]✗[/red] Failed to pull baseline: {str(e)}")
        raise typer.Exit(code=1)


@app.command()
def generate(
    trace_dir: Path | None = typer.Option(
        None, "--from", "-f", help="Trace directory (default: .spooled/traces/)"
    ),
    out: Path = typer.Option(
        Path(".github/baselines"), "--out", "-o", help="Output directory for baselines"
    ),
    agent_id: str | None = typer.Option(None, "--agent-id", "-a", help="Filter to specific agent"),
) -> None:
    """Generate baselines from existing traces.

    Reads traces, groups by agent, computes fingerprints and metrics,
    and writes git-committable baseline summary JSON files.

    Example:
       spooled baseline generate
       spooled baseline generate --from .spooled/traces/ --out .github/baselines/
       spooled baseline generate --agent-id my_agent
    """
    from cli.commands.ci import _enrich_baseline_stats, _find_all_traces, _load_trace

    try:
        source_dir = trace_dir or get_trace_directory()
        if not source_dir.exists():
            console.print(f"[red]✗[/red] Trace directory not found: {source_dir}")
            raise typer.Exit(code=1)

        trace_files = _find_all_traces(source_dir)
        if not trace_files:
            console.print(f"[red]✗[/red] No trace files found in: {source_dir}")
            raise typer.Exit(code=1)

        console.print(f"[dim]Found {len(trace_files)} trace files in {source_dir}[/dim]")

        agents: dict[str, BaselineManager] = {}
        processed = 0
        skipped = 0

        for tf in trace_files:
            try:
                trace_data = _load_trace(tf)
                trace_agent_id = trace_data.get("trace", {}).get("agent_id", "unknown")

                if agent_id and trace_agent_id != agent_id:
                    continue

                if trace_agent_id not in agents:
                    agents[trace_agent_id] = BaselineManager(trace_agent_id)

                status = trace_data.get("trace", {}).get("status", "UNKNOWN")
                agents[trace_agent_id].add_to_baseline(trace_data, status)
                _enrich_baseline_stats(agents[trace_agent_id], trace_data)

                processed += 1
            except Exception as e:
                logger.debug("Skipping trace file", path=str(tf), error=str(e))
                skipped += 1

        if not agents:
            console.print("[red]✗[/red] No traces matched the filter criteria")
            raise typer.Exit(code=1)

        out.mkdir(parents=True, exist_ok=True)
        written = []
        for aid, manager in agents.items():
            output_path = out / f"{aid}.json"
            summary = manager.save_summary(output_path)
            written.append((aid, output_path, len(summary.intents)))

        console.print(
            f"\n[green]Baselines generated[/green] ({processed} traces processed, {skipped} skipped)"
        )
        for aid, path, intent_count in written:
            console.print(f"  {aid}: {path} ({intent_count} intents)")

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Baseline generate failed", error=str(e))
        console.print(f"[red]✗[/red] Failed: {e}")
        raise typer.Exit(code=1)


@app.command("update-all")
def update_all(
    trace_dir: Path | None = typer.Option(
        None, "--from", "-f", help="Trace directory (default: .spooled/traces/)"
    ),
    out: Path = typer.Option(
        Path("baselines"), "--out", "-o", help="Output directory for baseline summaries"
    ),
    min_runs: int = typer.Option(0, "--min-runs", help="Minimum runs per intent (0 = no gate)"),
    push_remote: bool = typer.Option(
        False, "--push", help="Push all updated baselines to remote after generation"
    ),
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend URL for --push (defaults to SPOOLED_BACKEND_URL)"
    ),
) -> None:
    """Rebuild all baselines from traces in one command.

    Clears baseline cache, rebuilds from raw traces for all agents,
    preserves accepted variants, and optionally pushes to remote.

    This is a convenience wrapper around `ci update-baseline` with
    sensible defaults for batch operations.

    Example:
       spooled baseline update-all
       spooled baseline update-all --from .spooled/traces/ --out .github/baselines/
       spooled baseline update-all --min-runs 3 --push
    """
    import json as _json
    import shutil
    from datetime import datetime, timezone

    from spooled.models import AgentBaseline, BaselineSummary

    try:
        from cli.commands.ci import _enrich_baseline_stats, _find_all_traces, _load_trace

        source_dir = trace_dir or get_trace_directory()
        if not source_dir.exists():
            console.print(f"[red]✗[/red] Trace directory not found: {source_dir}")
            raise typer.Exit(code=1)

        trace_files = _find_all_traces(source_dir)
        if not trace_files:
            console.print(f"[red]✗[/red] No trace files found in: {source_dir}")
            raise typer.Exit(code=1)

        # Clear baseline cache to prevent double-counting
        cache_dir = source_dir / "baselines"
        if cache_dir.exists():
            shutil.rmtree(cache_dir)
            cache_dir.mkdir(parents=True, exist_ok=True)

        console.print(
            f"[dim]Rebuilding baselines from {len(trace_files)} traces in {source_dir}[/dim]"
        )

        # Load existing summaries for variant preservation
        old_summaries: dict[str, BaselineSummary] = {}
        out.mkdir(parents=True, exist_ok=True)
        for existing_file in sorted(out.glob("*.json")):
            try:
                with open(existing_file) as f:
                    old_summaries[existing_file.stem] = BaselineSummary(**_json.load(f))
            except Exception:
                pass

        # Group traces by agent and build baselines
        agents: dict[str, BaselineManager] = {}
        processed = 0
        skipped = 0

        for tf in trace_files:
            try:
                trace_data = _load_trace(tf)
                trace_agent_id = trace_data.get("trace", {}).get("agent_id", "unknown")

                if trace_agent_id not in agents:
                    mgr = BaselineManager(trace_agent_id)
                    mgr._baseline = AgentBaseline(
                        agent_id=trace_agent_id,
                        updated_at=datetime.now(timezone.utc),
                        intents={},
                    )
                    agents[trace_agent_id] = mgr

                # Collect tags
                trace_tags = trace_data.get("trace", {}).get("tags", [])
                if trace_tags:
                    existing_tags = set(agents[trace_agent_id].tags)
                    for t in trace_tags:
                        if t not in existing_tags:
                            agents[trace_agent_id].tags.append(t)
                            existing_tags.add(t)

                status = trace_data.get("trace", {}).get("status", "UNKNOWN")
                agents[trace_agent_id].add_to_baseline(trace_data, status)
                _enrich_baseline_stats(agents[trace_agent_id], trace_data)
                processed += 1
            except Exception as e:
                logger.debug("Skipping trace", path=str(tf), error=str(e))
                skipped += 1

        if not agents:
            console.print("[red]✗[/red] No traces found")
            raise typer.Exit(code=1)

        # Apply quality gates and variant preservation, then save
        written: list[str] = []
        held_back_total = 0

        for aid, manager in sorted(agents.items()):
            baseline = manager.load_baseline()

            # Quality gate: filter intents by min_runs
            if min_runs > 0:
                promoted = {
                    iid: stat
                    for iid, stat in baseline.intents.items()
                    if stat.sample_count >= min_runs
                }
                held = len(baseline.intents) - len(promoted)
                held_back_total += held
                if not promoted:
                    console.print(
                        f"  [yellow]{aid}[/yellow]: no intents meet --min-runs {min_runs} (held {held})"
                    )
                    continue
                baseline.intents = promoted
                manager._baseline = baseline

            # Preserve accepted variants from old summaries
            if aid in old_summaries:
                old = old_summaries[aid]
                for iid, stat in baseline.intents.items():
                    old_intent = old.intents.get(iid)
                    if old_intent:
                        existing_fps = set(stat.accepted_fingerprints or [])
                        for fp in old_intent.accepted_fingerprints or []:
                            existing_fps.add(fp)
                        stat.accepted_fingerprints = sorted(existing_fps)
                        existing_av_hashes = {
                            av.fingerprint_hash for av in (stat.accepted_variants or [])
                        }
                        for av in old_intent.accepted_variants or []:
                            if av.fingerprint_hash not in existing_av_hashes:
                                stat.accepted_variants.append(av)
                # Merge tags from old summary
                existing_tags = set(manager.tags)
                for t in old.tags:
                    if t not in existing_tags:
                        manager.tags.append(t)
                        existing_tags.add(t)

            output_path = out / f"{aid}.json"
            summary = manager.save_summary(output_path)
            written.append(aid)
            console.print(f"  [green]✓[/green] {aid}: {len(summary.intents)} intents")

        console.print(
            f"\n[green]Updated {len(written)} baselines[/green] ({processed} traces, {skipped} skipped)"
        )
        if held_back_total:
            console.print(f"[dim]{held_back_total} intents held back by quality gates[/dim]")

        # Optionally push to remote
        if push_remote and written:
            console.print("\n[dim]Pushing baselines to remote...[/dim]")
            pushed = 0
            for aid in written:
                try:
                    mgr = BaselineManager(aid)
                    if mgr.push_to_remote(backend_url):
                        pushed += 1
                    else:
                        console.print(f"  [yellow]⚠[/yellow] Failed to push {aid}")
                except Exception as e:
                    console.print(f"  [yellow]⚠[/yellow] Push failed for {aid}: {e}")
            console.print(f"[green]✓[/green] Pushed {pushed}/{len(written)} baselines")

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Baseline update-all failed", error=str(e))
        console.print(f"[red]✗[/red] Failed: {e}")
        raise typer.Exit(code=1)
