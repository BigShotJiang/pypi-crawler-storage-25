"""CI comparison engine — core logic for behavioral CI/CD pipeline.

Extracted from ci.py. Contains comparison, scoring, policy evaluation,
session grouping, and CI report building logic.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import structlog

from spooled.baseline import (
    BaselineManager,
)
from spooled.fingerprint import (
    BehavioralFingerprint,
    fingerprint_similarity_detailed,
    hash_fingerprint,
)
from spooled.policy import PolicyEngine
from spooled.signals import METRIC_SENSITIVE_SIGNALS, SignalDetector

logger = structlog.get_logger(__name__)

try:
    from rich.console import Console

    console = Console(stderr=True)
except ImportError:
    console = None  # type: ignore


def _compute_comparison(
    current_trace: dict[str, Any],
    baseline_data: Any,
    agent_id: str,
    policy_engine: PolicyEngine | None = None,
    policy_only: bool = False,
) -> dict[str, Any]:
    """Core comparison logic used by both `compare` and `run`.

    Args:
        current_trace: Current trace data
        baseline_data: AgentBaseline or None
        agent_id: Agent identifier
        policy_engine: Optional policy engine
        policy_only: If True, skip fingerprint comparison; only run signal detection + policy

    Returns:
        Comparison result dictionary
    """

    # Generate current fingerprint
    current_fp = BehavioralFingerprint(current_trace)
    current_fp_data = current_fp.generate()
    current_fp_hash = hash_fingerprint(current_fp_data)

    # Build a baseline manager from the baseline data
    baseline_manager = BaselineManager(agent_id)
    if baseline_data is not None:
        baseline_manager._baseline = baseline_data

    # Detect signals
    signal_detector = SignalDetector(current_trace, None, baseline_manager=baseline_manager)
    signals = signal_detector.detect_signals()

    # Check fingerprint against baseline
    fingerprint_status = "unknown"
    fingerprint_match = False
    baseline_fp_hash = None

    if policy_only:
        # Skip fingerprint comparison entirely; treat as "not compared"
        fingerprint_status = "not_compared"
        fingerprint_match = True  # don't block on fingerprint in policy_only mode
        baseline_fp_hash = (
            next(iter(baseline_data.intents), None)
            if baseline_data and baseline_data.intents
            else None
        )
    elif baseline_data and baseline_data.intents:
        # Check direct match
        if current_fp_hash in baseline_data.intents:
            fingerprint_status = "match"
            fingerprint_match = True
            baseline_fp_hash = current_fp_hash
        else:
            # Check accepted variants (prefix-aware: accept-variant may
            # store truncated hashes while current_fp_hash is full 64-char)
            for intent_id, intent_stat in baseline_data.intents.items():
                if any(
                    current_fp_hash == afp
                    or current_fp_hash.startswith(afp)
                    or afp.startswith(current_fp_hash)
                    for afp in (intent_stat.accepted_fingerprints or [])
                ):
                    fingerprint_status = "accepted_variant"
                    fingerprint_match = True
                    baseline_fp_hash = intent_id
                    break
            else:
                # Standard mode: order-tolerant matching via tool-set Jaccard.
                # If tool sets are >=85% similar (<=1 tool difference on a
                # 10-tool agent), treat as MATCH. Absorbs natural non-determinism
                # (conditional branches that fire inconsistently) without hiding
                # real regressions (tool deprecation, new capabilities).
                n_intents = len(baseline_data.intents)
                cross_intent_presence: dict[str, float] = {}
                if n_intents > 0:
                    tool_intent_count: dict[str, int] = {}
                    for ist in baseline_data.intents.values():
                        b = ist.fingerprint if hasattr(ist, "fingerprint") else None
                        if b:
                            for t in b.get("tool_graph", {}).get("unique_tools", []):
                                tool_intent_count[t] = tool_intent_count.get(t, 0) + 1
                    cross_intent_presence = {
                        t: count / n_intents for t, count in tool_intent_count.items()
                    }

                best_jaccard = 0.0
                best_jaccard_intent = None
                best_mandatory_removed = set()
                for intent_id, intent_stat in baseline_data.intents.items():
                    b_fp = intent_stat.fingerprint if hasattr(intent_stat, "fingerprint") else None
                    if b_fp:
                        current_tools = set(
                            current_fp_data.get("tool_graph", {}).get("unique_tools", [])
                        )
                        baseline_tools = set(b_fp.get("tool_graph", {}).get("unique_tools", []))
                        union = len(current_tools | baseline_tools)
                        jaccard = len(current_tools & baseline_tools) / union if union > 0 else 1.0
                        removed = baseline_tools - current_tools
                        mandatory_removed = {
                            t for t in removed if cross_intent_presence.get(t, 1.0) >= 1.0
                        }
                        if jaccard > best_jaccard:
                            best_jaccard = jaccard
                            best_jaccard_intent = intent_id
                            best_mandatory_removed = mandatory_removed

                if best_jaccard_intent and not best_mandatory_removed:
                    fingerprint_status = "match"
                    fingerprint_match = True
                    baseline_fp_hash = best_jaccard_intent
                else:
                    # Check structural (IO-schema) hash match — catches tool renames
                    current_structural_hash = hash_fingerprint(current_fp_data, mode="structural")
                    for intent_id, intent_stat in baseline_data.intents.items():
                        baseline_structural = getattr(
                            intent_stat, "structural_fingerprint_hash", None
                        )
                        if baseline_structural and baseline_structural == current_structural_hash:
                            fingerprint_status = "structural_match"
                            fingerprint_match = True
                            baseline_fp_hash = intent_id
                            break
                    else:
                        fingerprint_status = "new"
                        # Find closest intent for comparison (first one if exists)
                        baseline_fp_hash = next(iter(baseline_data.intents), None)
    else:
        fingerprint_status = "no_baseline"

    # Compute metric deltas if we have a matching baseline intent
    metric_deltas = {}
    if baseline_fp_hash and baseline_fp_hash in (baseline_data.intents if baseline_data else {}):
        baseline_stat = baseline_data.intents[baseline_fp_hash]
        # Token delta
        interactions = current_trace.get("interactions", [])
        current_tokens = 0
        for interaction in interactions:
            if interaction.get("interaction_type") == "LLM_CALL":
                usage = interaction.get("output", {}).get("usage") or interaction.get(
                    "metadata", {}
                ).get("usage")
                if usage and isinstance(usage, dict):
                    t = usage.get("total_tokens")
                    if t and isinstance(t, (int, float)):
                        current_tokens += t

        if baseline_stat.avg_tokens > 0:
            token_delta = current_tokens - baseline_stat.avg_tokens
            token_delta_pct = (token_delta / baseline_stat.avg_tokens) * 100
            metric_deltas["tokens"] = {
                "current": current_tokens,
                "baseline_avg": baseline_stat.avg_tokens,
                "delta": token_delta,
                "delta_pct": round(token_delta_pct, 1),
            }

        # Step count delta
        current_step_count = len(interactions)
        if baseline_stat.step_count > 0:
            step_delta = current_step_count - baseline_stat.step_count
            metric_deltas["step_count"] = {
                "current": current_step_count,
                "baseline": baseline_stat.step_count,
                "delta": step_delta,
            }

    # Similarity-aware VARIANT classification for "new" fingerprints
    similarity_score = None
    similarity_dimensions: dict[str, Any] | None = None
    reason_code: str | None = None
    reason_label: str | None = None
    tool_diff: dict[str, Any] | None = None
    if fingerprint_status == "new" and baseline_data and baseline_data.intents:
        best_detail = None
        best_intent = None
        for b_intent in baseline_data.intents.values():
            b_fp = b_intent.fingerprint if hasattr(b_intent, "fingerprint") else None
            if b_fp:
                detail = fingerprint_similarity_detailed(current_fp_data, b_fp)
                if best_detail is None or detail["overall"] > best_detail["overall"]:
                    best_detail = detail
                    best_intent = b_intent
        if best_detail and best_detail["overall"] >= 0.75:
            fingerprint_status = "variant"
            similarity_score = round(best_detail["overall"], 2)
            similarity_dimensions = {
                "tool_jaccard": best_detail["tool_jaccard"],
                "sequence_lcs": best_detail["sequence_lcs"],
                "error_jaccard": best_detail["error_jaccard"],
            }
            reason_code = best_detail["dominant_reason"]
            reason_label = best_detail["reason_label"]
        if fingerprint_status in ("variant", "new") and best_intent is not None:
            current_tools = set(current_fp_data.get("tool_graph", {}).get("unique_tools", []))
            baseline_tools = set(
                best_intent.fingerprint.get("tool_graph", {}).get("unique_tools", [])
                if hasattr(best_intent, "fingerprint") and best_intent.fingerprint
                else []
            )
            tool_diff = {
                "added": sorted(current_tools - baseline_tools),
                "removed": sorted(baseline_tools - current_tools),
                "baseline_sequence": (
                    best_intent.fingerprint.get("tool_graph", {}).get("sequence", [])
                    if hasattr(best_intent, "fingerprint") and best_intent.fingerprint
                    else []
                ),
                "current_sequence": current_fp_data.get("tool_graph", {}).get("sequence", []),
            }

    # Also compute latency delta when we have a baseline match/variant
    if baseline_fp_hash and baseline_fp_hash in (baseline_data.intents if baseline_data else {}):
        baseline_stat = baseline_data.intents[baseline_fp_hash]
        current_latency_ms = current_trace.get("trace", {}).get("total_latency_ms", 0)
        if not current_latency_ms:
            # Try to sum from interactions
            interactions = current_trace.get("interactions", [])
            current_latency_ms = sum(float(i.get("latency_ms", 0) or 0) for i in interactions)
        if baseline_stat.avg_latency > 0 and current_latency_ms > 0:
            lat_delta = current_latency_ms - baseline_stat.avg_latency
            lat_delta_pct = (lat_delta / baseline_stat.avg_latency) * 100
            metric_deltas["latency"] = {
                "current_ms": current_latency_ms,
                "baseline_avg_ms": baseline_stat.avg_latency,
                "delta_ms": lat_delta,
                "delta_pct": round(lat_delta_pct, 1),
            }

    # Evaluate policy
    policy_result = {}
    if policy_engine:
        policy_result = policy_engine.evaluate(
            signals,
            None,
            context={
                "fingerprint_status": fingerprint_status,
                "similarity_score": similarity_score,
            },
            agent_id=agent_id,
        )

    # Gather baseline stats for downstream consumers
    baseline_stats: dict[str, Any] = {}
    intent_trend: list[Any] = []
    intent_distribution: list[dict[str, Any]] = []
    if baseline_data and baseline_data.intents:
        # Compute intent frequency distribution across the whole agent
        total_runs = sum(
            getattr(ist, "sample_count", 0) or len(getattr(ist, "runs", []))
            for ist in baseline_data.intents.values()
        )
        if total_runs > 0:
            for iid, ist in baseline_data.intents.items():
                rc = getattr(ist, "sample_count", 0) or len(getattr(ist, "runs", []))
                tool_seq = (
                    ist.fingerprint.get("tool_graph", {}).get("sequence", [])
                    if hasattr(ist, "fingerprint") and ist.fingerprint
                    else []
                )
                intent_distribution.append(
                    {
                        "intent_id": iid,
                        "run_count": rc,
                        "frequency_pct": round((rc / total_runs) * 100, 1),
                        "tool_sequence": tool_seq,
                        "is_current": iid == current_fp_hash,
                    }
                )
            intent_distribution.sort(key=lambda x: x["frequency_pct"], reverse=True)

    if baseline_fp_hash and baseline_data and baseline_fp_hash in baseline_data.intents:
        bstat = baseline_data.intents[baseline_fp_hash]
        baseline_stats = {
            "sample_count": getattr(bstat, "sample_count", 0),
            "error_rate": getattr(bstat, "error_rate", 0.0),
            "avg_latency": getattr(bstat, "avg_latency", 0.0),
            "avg_tokens": getattr(bstat, "avg_tokens", 0.0),
            "latency_bounds": getattr(bstat, "latency_bounds", None),
        }
        intent_trend = getattr(bstat, "similarity_trend", [])

    # Compute Spooled Score
    from spooled.scoring import compute_spooled_score

    # Pull policy violation info + tool removal count for the score adjustments
    policy_failed = bool(policy_result.get("should_block")) if policy_result else False
    tools_removed_count = len(tool_diff.get("removed", [])) if tool_diff else 0

    spooled_score = compute_spooled_score(
        fingerprint_status=fingerprint_status,
        similarity_score=similarity_score,
        signals=signals,
        metric_deltas=metric_deltas,
        similarity_trend=intent_trend,
        policy_failed=policy_failed,
        tools_removed=tools_removed_count,
    )

    result = {
        "agent_id": agent_id,
        "run_id": current_trace.get("trace", {}).get("run_id"),
        "timestamp": current_trace.get("trace", {}).get("timestamp"),
        "status": current_trace.get("trace", {}).get("status"),
        "fingerprint": current_fp_data,
        "fingerprint_hash": current_fp_hash,
        "fingerprint_status": fingerprint_status,
        "fingerprint_match": fingerprint_match,
        "baseline_fingerprint_hash": baseline_fp_hash,
        "signals": signals,
        "metric_deltas": metric_deltas,
        "baseline_stats": baseline_stats,
        "intent_distribution": intent_distribution,
        "similarity_score": similarity_score,
        "similarity_dimensions": similarity_dimensions,
        "reason_code": reason_code,
        "reason_label": reason_label,
        "tool_diff": tool_diff,
        "policy": policy_result,
        "spooled_score": spooled_score,
        "summary": {
            "has_warnings": signals.get("has_warnings", False),
            "severity": signals.get("severity", "none"),
            "signal_count": sum(
                1 for s in signals.values() if isinstance(s, dict) and s.get("detected")
            ),
            "fingerprint_match": fingerprint_match,
            "fingerprint_status": fingerprint_status,
            "policy_enabled": policy_result.get("enabled", False),
            "policy_passed": policy_result.get("passed", True),
            "should_block": policy_result.get("should_block", False),
            "policy_violations": len(policy_result.get("violations", [])),
            "spooled_score": spooled_score.get("score"),
            "spooled_grade": spooled_score.get("grade"),
        },
    }

    return result


def _determine_exit_code(result: dict[str, Any], enable_blocking: bool = True) -> int:
    """Determine exit code from comparison result.

    Returns 0 for pass, 1 for failure/block.
    New behavior (fingerprint_status == "new") blocks by default when
    enable_blocking is True, regardless of whether a policy file is loaded.
    """
    summary = result.get("summary", {})

    # Policy-based blocking
    if enable_blocking and summary.get("should_block"):
        return 1

    # New behavior blocks when blocking is enabled UNLESS policy explicitly
    # allows it (on_new_behavior: false means new intents are permitted).
    if enable_blocking and summary.get("fingerprint_status") == "new":
        # If policy evaluated and didn't block, respect that decision
        if not summary.get("should_block"):
            # Check if there's actually a policy with on_new_behavior: false
            policy_result = summary.get("policy_result") or {}
            if policy_result.get("passed", False):
                return 0  # Policy explicitly passed new behavior
        return 1

    return 0


# ─── ci-history helpers ──────────────────────────────────────────────────────


def _append_ci_history(result: dict[str, Any], cwd: Path) -> None:
    """Append one comparison result to the per-agent CI history JSONL file.

    Only records statuses that carry a similarity signal (match, variant,
    accepted_variant). 'new', 'no_baseline', etc. are ignored since they
    don't contribute to a meaningful trend series.
    """
    status = result.get("fingerprint_status", "")
    if status not in ("match", "variant", "accepted_variant"):
        return
    intent_id = result.get("baseline_fingerprint_hash") or ""
    if not intent_id:
        return
    agent_id = result.get("agent_id", "unknown")
    score = result.get("similarity_score")
    if score is None:
        score = 1.0 if status == "match" else 0.0
    entry = {
        "timestamp": result.get("timestamp") or datetime.now(timezone.utc).isoformat(),
        "intent_id": intent_id,
        "similarity_score": score,
        "fingerprint_status": status,
        "dominant_reason": result.get("reason_code"),
        "spooled_score": result.get("spooled_score", {}).get("score"),
    }
    history_dir = cwd / ".spooled" / "ci-history"
    history_dir.mkdir(parents=True, exist_ok=True)
    with open(history_dir / f"{agent_id}.jsonl", "a") as f:
        f.write(json.dumps(entry) + "\n")


# ─── history ─────────────────────────────────────────────────────────────────


def _submit_ci_attestation(result: dict[str, Any], trace_data: dict[str, Any]) -> None:
    """Submit attestation after CI comparison if backend is configured."""
    backend_url = os.getenv("SPOOLED_BACKEND_URL", "")
    api_key = os.getenv("SPOOLED_API_KEY", "")
    if not backend_url or not api_key:
        console.print(
            "[dim]  Attestation skipped: SPOOLED_BACKEND_URL or SPOOLED_API_KEY not set[/dim]"
        )
        return

    try:
        from spooled.attest import save_receipt, submit_attestation

        agent_id = result.get("agent_id", "unknown")
        fp_hash = result.get("fingerprint_hash", "")
        chain_hash = trace_data.get("trace", {}).get("chain_hash")
        run_id = trace_data.get("trace", {}).get("run_id")

        # Extract scores from result
        spooled = result.get("spooled_score", {})
        spooled_score_val = spooled.get("score") if isinstance(spooled, dict) else None
        spooled_grade_val = spooled.get("grade") if isinstance(spooled, dict) else None

        drift_score = None
        similarity = result.get("similarity_score")
        if similarity is not None:
            drift_score = float(similarity)

        # Extract metrics
        deltas = result.get("metric_deltas", {})
        metrics: dict[str, Any] = {}
        if "tokens" in deltas:
            metrics["total_tokens"] = deltas["tokens"].get("current", 0)
        if "step_count" in deltas:
            metrics["step_count"] = deltas["step_count"].get("current", 0)

        att_result = submit_attestation(
            agent_id=agent_id,
            fingerprint_hash=fp_hash,
            chain_hash=chain_hash,
            drift_score=drift_score,
            spooled_score=spooled_score_val,
            spooled_grade=spooled_grade_val,
            metrics=metrics,
            run_id=run_id,
            backend_url=backend_url,
            api_key=api_key,
        )

        att_id = att_result.get("attestation_id", "unknown")
        receipt = att_result.get("receipt", {})
        save_receipt(receipt)
        console.print(f"  [green]Attestation submitted: {att_id}[/green]")

    except Exception as e:
        console.print(f"  [yellow]Attestation failed (non-blocking): {e}[/yellow]")


def _enrich_baseline_stats(manager: BaselineManager, trace_data: dict[str, Any]) -> None:
    """Enrich baseline stats with step_count, tool_call_counts, etc.

    Called after add_to_baseline to fill in the new fields.
    """
    baseline = manager.load_baseline()
    interactions = trace_data.get("interactions", [])
    fp = BehavioralFingerprint(trace_data)
    fp_data = fp.generate()
    intent_id = hash_fingerprint(fp_data)

    if intent_id not in baseline.intents:
        return

    stat = baseline.intents[intent_id]

    # Step count (use latest)
    stat.step_count = len(interactions)

    # Fingerprint hash
    if not stat.fingerprint_hash:
        stat.fingerprint_hash = intent_id

    # Accepted fingerprints (initialize if empty)
    if not stat.accepted_fingerprints:
        stat.accepted_fingerprints = [intent_id]

    # Tool call counts
    tool_counts: dict[str, int] = {}
    total_prompt = 0
    total_completion = 0
    total_tokens = 0
    for interaction in interactions:
        if interaction.get("interaction_type") == "TOOL_CALL":
            tool_name = interaction.get("input", {}).get("function", "unknown")
            tool_counts[tool_name] = tool_counts.get(tool_name, 0) + 1
        if interaction.get("interaction_type") == "LLM_CALL":
            usage = interaction.get("output", {}).get("usage") or interaction.get(
                "metadata", {}
            ).get("usage")
            if usage and isinstance(usage, dict):
                total_prompt += usage.get("prompt_tokens", 0)
                total_completion += usage.get("completion_tokens", 0)
                total_tokens += usage.get("total_tokens", 0)

    stat.tool_call_counts = tool_counts
    stat.token_totals = {
        "prompt_tokens": total_prompt,
        "completion_tokens": total_completion,
        "total_tokens": total_tokens,
    }

    # Latency bounds from runs
    if stat.runs:
        latencies = [
            float(r.get("total_latency_ms", 0))
            for r in stat.runs
            if r.get("total_latency_ms") is not None
        ]
        if latencies:
            sorted_lats = sorted(latencies)
            p95_idx = max(0, int(len(sorted_lats) * 0.95) - 1)
            stat.latency_bounds = {
                "min_ms": sorted_lats[0],
                "max_ms": sorted_lats[-1],
                "avg_ms": stat.avg_latency,
                "p95_ms": sorted_lats[p95_idx],
            }

    manager.save_baseline(baseline)


# ─── run ─────────────────────────────────────────────────────────────────────


def _run_test_suite(suite: Path) -> int:
    """Execute a test suite.

    Args:
        suite: Path to test module or directory

    Returns:
        Exit code from test execution
    """
    if suite.is_dir():
        cmd = [sys.executable, "-m", "pytest", str(suite), "-v", "--tb=short"]
    elif suite.suffix == ".py":
        cmd = [sys.executable, str(suite)]
    else:
        cmd = [sys.executable, "-m", "pytest", str(suite), "-v", "--tb=short"]

    try:
        result = subprocess.run(
            cmd,
            capture_output=False,
            timeout=300,
        )
        return result.returncode
    except subprocess.TimeoutExpired:
        console.print("[red]✗[/red] Test suite timed out (300s)")
        return 124
    except Exception as e:
        console.print(f"[red]✗[/red] Failed to run test suite: {e}")
        return 1


def _are_failures_metric_only(results: list[dict[str, Any]]) -> bool:
    """Check whether all policy violations are from metric-sensitive signals.

    Returns True only when every violation type is in METRIC_SENSITIVE_SIGNALS.
    Structural changes (new fingerprint, new side effects) always return False.
    """
    for result in results:
        # Structural change is never metric-only
        if result.get("fingerprint_status") == "new":
            return False

        policy = result.get("policy", {})
        for violation in policy.get("violations", []):
            vtype = violation.get("type", "")
            if vtype not in METRIC_SENSITIVE_SIGNALS:
                return False

    return True


def _clear_traces(trace_dir: Path) -> None:
    """Remove all .jsonl trace files from a directory for rerun."""
    if not trace_dir.exists():
        return
    for f in trace_dir.glob("*.jsonl"):
        f.unlink()


def _build_session_groups(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Group results by session_id for multi-agent session reporting.

    Args:
        results: Per-trace comparison results

    Returns:
        List of session group dicts with session_id, agents, status, and trace refs
    """
    from collections import defaultdict

    sessions: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for r in results:
        session_id = r.get("session_id")
        if session_id:
            sessions[session_id].append(r)

    groups = []
    for session_id, session_results in sessions.items():
        agents = sorted({r["agent_id"] for r in session_results})
        all_pass = all(r["fingerprint_match"] for r in session_results)
        any_block = any(r["summary"].get("should_block") for r in session_results)
        status = "FAIL" if any_block else ("PASS" if all_pass else "WARN")
        groups.append(
            {
                "session_id": session_id,
                "agents": agents,
                "trace_count": len(session_results),
                "status": status,
                "traces": [
                    {
                        "agent_id": r["agent_id"],
                        "fingerprint_status": r["fingerprint_status"],
                        "should_block": r["summary"].get("should_block", False),
                    }
                    for r in session_results
                ],
            }
        )

    return groups


def _sanitize_artifact_result(result: dict[str, Any]) -> dict[str, Any]:
    """Sanitize a per-trace CI result before writing to disk.

    Strips error strings from fingerprint data that could leak
    sensitive information (stack traces, file paths, internal state).
    Preserves structural fields (sequence, type, recovery_type).

    Args:
        result: Per-trace comparison result dict

    Returns:
        Sanitized copy of the result
    """
    import copy

    sanitized = copy.deepcopy(result)

    fp = sanitized.get("fingerprint", {})
    if not isinstance(fp, dict):
        return sanitized

    # Redact error strings in error_patterns
    error_patterns = fp.get("error_patterns", {})
    if isinstance(error_patterns, dict):
        errors = error_patterns.get("errors", [])
        if isinstance(errors, list):
            for entry in errors:
                if isinstance(entry, dict) and "error" in entry:
                    entry["error"] = "[REDACTED]"

    # Redact error strings in branch_paths
    branch_paths = fp.get("branch_paths", [])
    if isinstance(branch_paths, list):
        for path_entry in branch_paths:
            if isinstance(path_entry, dict) and "error" in path_entry:
                path_entry["error"] = "[REDACTED]"

    return sanitized


def _build_ci_summary(results: list[dict[str, Any]]) -> dict[str, Any]:
    """Build aggregate CI summary from per-trace results."""
    from spooled.scoring import compute_agent_spooled_score

    total = len(results)
    passed = sum(1 for r in results if r["fingerprint_match"])
    new_behavior = sum(1 for r in results if r["fingerprint_status"] in ("new", "variant"))
    no_baseline = sum(1 for r in results if r["fingerprint_status"] == "no_baseline")
    policy_failures = sum(1 for r in results if r["summary"].get("should_block"))
    has_warnings = any(r["summary"]["has_warnings"] for r in results)

    max_severity = "none"
    for r in results:
        s = r["summary"]["severity"]
        if s == "high":
            max_severity = "high"
            break
        elif s == "medium" and max_severity != "high":
            max_severity = "medium"
        elif s == "low" and max_severity == "none":
            max_severity = "low"

    # Compute agent-level Spooled Score
    intent_scores = []
    for r in results:
        ss = r.get("spooled_score")
        if ss:
            intent_scores.append(
                {
                    "score": ss.get("score"),
                    "confidence": ss.get("confidence", "low"),
                    "run_count": r.get("baseline_stats", {}).get("sample_count", 1),
                }
            )
    agent_score = compute_agent_spooled_score(intent_scores)

    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "total_traces": total,
        "passed": passed,
        "new_behavior": new_behavior,
        "no_baseline": no_baseline,
        "policy_failures": policy_failures,
        "has_warnings": has_warnings,
        "max_severity": max_severity,
        "overall_result": "FAIL" if policy_failures > 0 else "PASS",
        "spooled_score": agent_score,
        "traces": [
            {
                "trace_file": (
                    os.path.basename(r.get("trace_file", "")) if r.get("trace_file") else None
                ),
                "agent_id": r["agent_id"],
                "fingerprint_hash": r.get("fingerprint_hash", "")[:16],
                "fingerprint_status": r["fingerprint_status"],
                "severity": r["summary"]["severity"],
                "should_block": r["summary"].get("should_block", False),
                "token_delta_pct": r.get("metric_deltas", {})
                .get("tokens", {})
                .get("delta_pct", 0.0),
                "latency_delta_pct": r.get("metric_deltas", {})
                .get("latency", {})
                .get("delta_pct", 0.0),
                "baseline_run_count": r.get("baseline_stats", {}).get("sample_count", 0),
                "similarity_score": r.get("similarity_score"),
                "reason_code": r.get("reason_code"),
                "reason_label": r.get("reason_label"),
                "similarity_dimensions": r.get("similarity_dimensions"),
                "tool_diff": r.get("tool_diff"),
                "spooled_score": r.get("spooled_score", {}).get("score"),
                "spooled_grade": r.get("spooled_score", {}).get("grade"),
            }
            for r in results
        ],
    }


def _build_ci_markdown(
    ci_summary: dict[str, Any],
    results: list[dict[str, Any]],
    baseline_dir: str = "baselines",
) -> str:
    """Build CI markdown report for PR comments."""
    from cli.report_pr import build_pr_markdown

    return build_pr_markdown(ci_summary, results, baseline_dir=baseline_dir)


def _push_ci_report(
    ci_summary: dict[str, Any],
    results: list[dict[str, Any]],
    backend_url: str | None = None,
    run_id: str | None = None,
) -> None:
    """Push CI report to the backend."""

    try:
        import httpx
    except ImportError:
        console.print("[yellow]![/yellow] httpx not installed — skipping push (pip install httpx)")
        return

    from spooled.utils import get_auth_headers

    url = backend_url or os.getenv("SPOOLED_BACKEND_URL")
    if not url:
        console.print("[yellow]![/yellow] No backend URL configured — skipping push")
        console.print("  Set SPOOLED_BACKEND_URL or use --backend-url")
        return

    run_id = run_id or str(uuid.uuid4())
    agent_ids = list({r["agent_id"] for r in results})
    agent_id = agent_ids[0] if len(agent_ids) == 1 else "multi-agent"

    # Build signals list from results
    signals = []
    for r in results:
        raw_signals = r.get("signals", {})
        if isinstance(raw_signals, dict):
            for name, sig_data in raw_signals.items():
                if isinstance(sig_data, dict) and sig_data.get("detected"):
                    signals.append({"name": name, **sig_data})
        elif isinstance(raw_signals, list):
            signals.extend(raw_signals)

    # Build policy result
    policy_result = {
        "passed": ci_summary.get("policy_failures", 0) == 0,
        "violations": [],
    }
    for r in results:
        policy_data = r.get("policy", {})
        for v in policy_data.get("violations", []):
            policy_result["violations"].append(v)

    # Payload is the BatchCIRun shape directly (so GET /api/ci-reports/{id}
    # returns something isBatchReport() recognises without unwrapping).
    payload = {
        # BatchCIRun fields at top level
        "timestamp": ci_summary["timestamp"],
        "total_traces": ci_summary.get("total_traces", len(results)),
        "passed": ci_summary.get("passed", 0),
        "new_behavior": ci_summary.get("new_behavior", 0),
        "no_baseline": ci_summary.get("no_baseline", 0),
        "policy_failures": ci_summary.get("policy_failures", 0),
        "has_warnings": ci_summary.get("has_warnings", False),
        "max_severity": ci_summary.get("max_severity", "none"),
        "overall_result": ci_summary.get("overall_result", "PASS"),
        "traces": ci_summary.get("traces", []),
        # Extra backend fields (not part of BatchCIRun but useful for queries)
        "run_id": run_id,
        "agent_id": agent_id,
        "signals": signals,
        "policy_result": policy_result,
    }

    api_url = f"{url.rstrip('/')}/api/ci-reports"
    try:
        with httpx.Client(timeout=30) as client:
            response = client.post(
                api_url,
                json=payload,
                headers={"Content-Type": "application/json", **get_auth_headers()},
            )
            response.raise_for_status()
            console.print(f"  [green]Pushed CI report:[/green] {run_id}")
    except httpx.HTTPStatusError as e:
        console.print(f"[yellow]![/yellow] Failed to push CI report: {e.response.status_code}")
        logger.debug("Push failed", status=e.response.status_code, body=e.response.text)
    except Exception as e:
        console.print(f"[yellow]![/yellow] Failed to push CI report: {e}")
        logger.debug("Push failed", error=str(e))


# ─── accept-variant ──────────────────────────────────────────────────────────
