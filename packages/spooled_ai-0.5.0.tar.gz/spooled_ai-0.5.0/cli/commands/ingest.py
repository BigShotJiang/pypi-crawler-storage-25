"""Command to import OTEL spans from a JSON file into Spooled traces."""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import structlog
import typer
from rich.console import Console
from rich.table import Table

from spooled.fingerprint import BehavioralFingerprint, hash_fingerprint
from spooled.hash_utils import calculate_interaction_signature, calculate_payload_hash
from spooled.models import Interaction, InteractionType, Trace, TraceStatus
from spooled.processors._converter import classify_span
from spooled.storage import JsonlWriter, save_interactions_locally, save_trace_locally

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="ingest", help="Import traces from external systems")


def _read_spans(file_path: Path) -> list[dict[str, Any]]:
    """Read span dicts from a JSON file.

    Accepts either a JSON array of span dicts or a single object with a
    ``"spans"`` key.

    Args:
        file_path: Path to the JSON file.

    Returns:
        List of span dictionaries.

    Raises:
        typer.BadParameter: If the file cannot be parsed or has unexpected shape.
    """
    try:
        raw = file_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise typer.BadParameter(f"Cannot read file: {exc}") from exc

    if not raw.strip():
        raise typer.BadParameter("File is empty")

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise typer.BadParameter(f"Invalid JSON: {exc}") from exc

    if isinstance(data, list):
        return data
    if isinstance(data, dict) and "spans" in data:
        spans = data["spans"]
        if isinstance(spans, list):
            return spans
        raise typer.BadParameter("'spans' key must contain a JSON array")

    raise typer.BadParameter("Expected a JSON array of spans or an object with a 'spans' key")


def _extract_attrs(span: dict[str, Any]) -> dict[str, Any]:
    """Extract the attributes dict from a span, trying common locations."""
    attrs = span.get("attributes") or {}
    # Some OTEL exporters nest attributes under resource
    if not attrs and isinstance(span.get("resource"), dict):
        attrs = span["resource"].get("attributes", {})
    return attrs


def _span_to_interaction(
    span: dict[str, Any],
    sequence: int,
    run_id: str,
) -> Interaction:
    """Convert a span dict to a Spooled Interaction.

    Uses ``classify_span`` from the existing converter to determine the
    interaction type, then manually extracts fields from the span dict.
    """
    attrs = _extract_attrs(span)
    itype = classify_span(attrs)

    # Latency from span timestamps (nanosecond or raw integer)
    start = span.get("start_time", span.get("startTimeUnixNano", 0))
    end = span.get("end_time", span.get("endTimeUnixNano", 0))
    try:
        start_ns = int(start)
        end_ns = int(end)
    except (TypeError, ValueError):
        start_ns = 0
        end_ns = 0
    latency_ms = max((end_ns - start_ns) / 1e6, 0.0)

    # Timestamp
    if start_ns > 0:
        timestamp = datetime.fromtimestamp(start_ns / 1e9, tz=timezone.utc)
    else:
        timestamp = datetime.now(timezone.utc)

    # Build fields based on type
    input_data: dict[str, Any] = {}
    output_data: dict[str, Any] | None = None
    metadata: dict[str, Any] = {"latency_ms": latency_ms}
    error: str | None = None

    if itype == InteractionType.LLM_CALL:
        model = attrs.get("gen_ai.request.model", "unknown")
        input_data = {"model": model, "messages": []}
        temp = attrs.get("gen_ai.request.temperature")
        if temp is not None:
            input_data["temperature"] = float(temp)
        max_tok = attrs.get("gen_ai.request.max_tokens")
        if max_tok is not None:
            input_data["max_tokens"] = int(max_tok)
        metadata["model"] = model

        in_tok = attrs.get("gen_ai.usage.input_tokens")
        out_tok = attrs.get("gen_ai.usage.output_tokens")
        if in_tok is not None or out_tok is not None:
            usage: dict[str, int] = {}
            if in_tok is not None:
                usage["prompt_tokens"] = int(in_tok)
                metadata["input_tokens"] = int(in_tok)
            if out_tok is not None:
                usage["completion_tokens"] = int(out_tok)
                metadata["completion_tokens"] = int(out_tok)
            total = (int(in_tok) if in_tok else 0) + (int(out_tok) if out_tok else 0)
            metadata["tokens"] = total
            output_data = {"usage": usage}

    elif itype == InteractionType.TOOL_CALL:
        tool_name = attrs.get("tool.name", "unknown")
        input_data = {"function": tool_name}
        arguments = attrs.get("tool.arguments")
        if arguments is not None:
            try:
                input_data["arguments"] = (
                    json.loads(arguments) if isinstance(arguments, str) else arguments
                )
            except (json.JSONDecodeError, TypeError):
                input_data["arguments"] = {"raw": str(arguments)}
        call_id = attrs.get("tool.call_id")
        if call_id:
            input_data["call_id"] = call_id

    elif itype == InteractionType.HTTP_REQUEST:
        method = attrs.get("http.request.method") or attrs.get("http.method", "GET")
        url = attrs.get("url.full") or attrs.get("http.url", "")
        input_data = {"method": method, "url": url}
        status_code = attrs.get("http.response.status_code")
        if status_code is not None:
            metadata["status_code"] = int(status_code)

    else:
        input_data = {"span_name": span.get("name", "unknown")}

    # Check for error in span status
    status = span.get("status", {})
    if isinstance(status, dict):
        status_code_val = status.get("status_code", status.get("code", ""))
        if str(status_code_val).upper() in ("ERROR", "2"):
            error = status.get("description") or status.get("message") or "error"

    interaction_id = str(uuid.uuid4())

    return Interaction(
        interaction_id=interaction_id,
        run_id=run_id,
        sequence=sequence,
        interaction_type=itype,
        timestamp=timestamp,
        input=input_data,
        output=output_data,
        error=error,
        metadata=metadata,
    )


def _build_hash_chain(interactions: list[Interaction]) -> list[Interaction]:
    """Compute payload_hash and prev_hash for each interaction, returning updated copies."""
    chained: list[Interaction] = []
    prev_signature: str | None = None

    for interaction in interactions:
        payload_hash = calculate_payload_hash(
            input_data=interaction.input,
            output_data=interaction.output,
            error=interaction.error,
            metadata=interaction.metadata,
        )

        prev_hash = prev_signature

        signature = calculate_interaction_signature(
            interaction_id=interaction.interaction_id,
            sequence=interaction.sequence,
            interaction_type=(
                interaction.interaction_type.value
                if hasattr(interaction.interaction_type, "value")
                else str(interaction.interaction_type)
            ),
            payload_hash=payload_hash,
            prev_hash=prev_hash,
        )

        updated = interaction.model_copy(
            update={
                "payload_hash": payload_hash,
                "prev_hash": prev_hash,
            }
        )
        chained.append(updated)
        prev_signature = signature

    return chained


@app.command()
def otel(
    from_file: Path = typer.Option(..., "--from", "-f", help="JSON file of exported OTEL spans"),
    agent_id: str = typer.Option(
        ..., "--agent-id", "-a", help="Agent identifier for the imported trace"
    ),
    policy_file: Path | None = typer.Option(None, "--policy", "-p", help="Policy YAML to evaluate"),
    out_dir: Path | None = typer.Option(
        None, "--out", "-o", help="Output directory (default: .spooled/traces/)"
    ),
) -> None:
    """Import OTEL spans from a JSON file into a Spooled trace."""

    # --- Validate input file ---
    if not from_file.exists():
        console.print(f"[red]Error:[/red] File not found: {from_file}")
        raise typer.Exit(code=1)

    try:
        spans = _read_spans(from_file)
    except typer.BadParameter as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1)

    if not spans:
        console.print("[yellow]No spans found in file — nothing to import.[/yellow]")
        raise typer.Exit(code=0)

    # --- Convert spans to interactions ---
    run_id = str(uuid.uuid4())
    interactions: list[Interaction] = []
    for idx, span in enumerate(spans):
        try:
            interaction = _span_to_interaction(span, sequence=idx, run_id=run_id)
            interactions.append(interaction)
        except Exception as exc:
            logger.debug("Skipping malformed span", index=idx, error=str(exc))

    if not interactions:
        console.print("[yellow]No valid interactions could be extracted from spans.[/yellow]")
        raise typer.Exit(code=0)

    # --- Build hash chain ---
    interactions = _build_hash_chain(interactions)
    chain_hash = None
    if interactions:
        last = interactions[-1]
        chain_hash = calculate_interaction_signature(
            interaction_id=last.interaction_id,
            sequence=last.sequence,
            interaction_type=(
                last.interaction_type.value
                if hasattr(last.interaction_type, "value")
                else str(last.interaction_type)
            ),
            payload_hash=last.payload_hash or "",
            prev_hash=last.prev_hash,
        )

    # --- Compute fingerprint ---
    interaction_dicts = [i.model_dump() for i in interactions]
    trace_data_for_fp = {"interactions": interaction_dicts}
    fp = BehavioralFingerprint(trace_data_for_fp)
    fingerprint = fp.generate()
    fp_hash = hash_fingerprint(fingerprint)

    # --- Build trace metadata ---
    trace = Trace(
        run_id=run_id,
        agent_id=agent_id,
        timestamp=interactions[0].timestamp if interactions else datetime.now(timezone.utc),
        status=TraceStatus.SUCCESS,
        chain_hash=chain_hash,
        fingerprint_hash=fp_hash,
    )

    # --- Save trace ---
    trace_dict = trace.model_dump()
    if out_dir:
        out_dir.mkdir(parents=True, exist_ok=True)
        trace_file = out_dir / f"{run_id}.jsonl"
        with JsonlWriter(trace_file) as writer:
            writer.write({"type": "trace", **trace_dict})
            for idict in interaction_dicts:
                writer.write({"type": "interaction", **idict})
        saved_path = trace_file
    else:
        save_trace_locally(trace_dict, run_id)
        save_interactions_locally(interaction_dicts, run_id)
        saved_path = Path(".spooled") / "traces" / f"{run_id}.jsonl"

    # --- Policy evaluation (optional) ---
    policy_result: dict[str, Any] | None = None
    if policy_file:
        try:
            from spooled.policy import PolicyEngine

            engine = PolicyEngine(policy_file)
            policy_result = engine.evaluate(
                signals={},
                diff_result=None,
                context={"fingerprint": fingerprint},
                agent_id=agent_id,
            )
        except Exception as exc:
            console.print(f"[yellow]Warning:[/yellow] Policy evaluation failed: {exc}")

    # --- Print summary ---
    console.print()
    table = Table(title="OTEL Ingest Summary", show_header=False, border_style="dim")
    table.add_column("Field", style="bold")
    table.add_column("Value")
    table.add_row("Agent ID", agent_id)
    table.add_row("Run ID", run_id)
    table.add_row("Interactions", str(len(interactions)))
    table.add_row("Fingerprint", fp_hash)
    table.add_row("Chain hash", (chain_hash or "")[:16] + "...")
    console.print(table)

    if policy_result:
        passed = policy_result.get("passed", True)
        status_str = "[green]PASS[/green]" if passed else "[red]FAIL[/red]"
        console.print(f"\nPolicy: {status_str}")
        for v in policy_result.get("violations", []):
            console.print(f"  [red]FAIL[/red] {v.get('message', '')}")
        for w in policy_result.get("warnings", []):
            console.print(f"  [yellow]WARN[/yellow] {w.get('message', '')}")

    console.print(f"\nTrace saved to {saved_path}")
