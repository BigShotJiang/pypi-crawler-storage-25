"""Command to view and pretty-print traces."""

from __future__ import annotations

import structlog
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from cli.utils import resolve_trace_path
from spooled.storage import load_trace_from_jsonl

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="view", help="View and pretty-print traces")


@app.command()
def trace(
    trace_file: str = typer.Argument(..., help="Path to trace file or run_id"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed interaction data"),
) -> None:
    """Pretty-print a trace file.

    Example:
       spooled view .spooled/traces/abc-123.jsonl
       spooled view abc-123
       spooled view trace.jsonl --verbose
    """
    try:
        resolved = resolve_trace_path(trace_file)
        if resolved is None:
            console.print(f"[red]✗[/red] Trace file not found: {trace_file}")
            raise typer.Exit(code=1)
        trace_file = resolved

        # Load trace
        if trace_file.suffix == ".jsonl":
            trace_data = load_trace_from_jsonl(trace_file)
        else:
            import json

            with open(trace_file) as f:
                trace_data = json.load(f)

        # Display trace
        _display_trace(trace_data, verbose)

    except FileNotFoundError:
        console.print(f"[red]✗[/red] Trace file not found: {trace_file}")
        console.print("\n[yellow]💡 Tips:[/yellow]")
        console.print("   1. List available traces: [cyan]spooled list traces[/cyan]")
        console.print("   2. Pull from backend: [cyan]spooled pull trace <run_id>[/cyan]")
        console.print("   3. Check file path and permissions")
        raise typer.Exit(code=1)
    except ValueError as e:
        console.print(f"[red]✗[/red] Invalid trace format: {str(e)}")
        console.print(
            "\n[yellow]💡 Tip:[/yellow] Ensure the trace file is valid JSONL or JSON format"
        )
        if verbose:
            logger.debug("Trace format error", error=str(e))
        raise typer.Exit(code=1)
    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to view trace", error=str(e))
        console.print(f"[red]✗[/red] Failed to view trace: {str(e)}")
        if verbose:
            import traceback

            console.print("\n[dim]Full traceback:[/dim]")
            console.print(traceback.format_exc())
        else:
            console.print(
                "\n[yellow]💡 Tip:[/yellow] Use [cyan]--verbose[/cyan] for detailed error information"
            )
        raise typer.Exit(code=1)


def _display_trace(trace_data: dict, verbose: bool = False) -> None:
    """Display trace information in a formatted way.

    Args:
        trace_data: The trace data dictionary
        verbose: Whether to show detailed interaction data
    """
    trace = trace_data.get("trace", {})
    interactions = trace_data.get("interactions", [])

    # Trace metadata table
    metadata_table = Table(title="Trace Metadata", show_header=True, header_style="bold blue")
    metadata_table.add_column("Field", style="cyan")
    metadata_table.add_column("Value", style="green")

    metadata_table.add_row("Run ID", trace.get("run_id", "N/A"))
    metadata_table.add_row("Agent ID", trace.get("agent_id", "N/A"))
    metadata_table.add_row("Status", trace.get("status", "N/A"))
    metadata_table.add_row("Timestamp", trace.get("timestamp", "N/A"))

    # Environment info
    env = trace.get("environment", {})
    if env:
        env_str = ", ".join(f"{k}={v}" for k, v in env.items() if v)
        metadata_table.add_row(
            "Environment", env_str[:100] + "..." if len(env_str) > 100 else env_str
        )

    tags = trace.get("tags", [])
    if tags:
        metadata_table.add_row("Tags", ", ".join(tags))

    metadata_table.add_row("Interactions", str(len(interactions)))

    console.print(metadata_table)
    console.print()

    # Interactions table
    if interactions:
        interactions_table = Table(
            title=f"Interactions ({len(interactions)})", show_header=True, header_style="bold blue"
        )
        interactions_table.add_column("Seq", style="cyan", width=4)
        interactions_table.add_column("Type", style="yellow", width=12)
        interactions_table.add_column("Summary", style="white")

        for interaction in sorted(interactions, key=lambda x: x.get("sequence", 0)):
            seq = interaction.get("sequence", "?")
            interaction_type = interaction.get("interaction_type", "UNKNOWN")

            # Create summary based on type
            summary = _get_interaction_summary(interaction, verbose)
            interactions_table.add_row(str(seq), interaction_type, summary)

        console.print(interactions_table)

        # Verbose mode: show full interaction details
        if verbose:
            console.print()
            for interaction in sorted(interactions, key=lambda x: x.get("sequence", 0)):
                _display_interaction_details(interaction)


def _get_interaction_summary(interaction: dict, verbose: bool = False) -> str:
    """Get a summary string for an interaction.

    Args:
        interaction: The interaction dictionary
        verbose: Whether to include more details

    Returns:
        Summary string
    """
    interaction_type = interaction.get("interaction_type", "")
    input_data = interaction.get("input", {})
    output_data = interaction.get("output")
    error = interaction.get("error")

    if error:
        return f"[red]Error: {error[:50]}[/red]"

    if interaction_type == "LLM_CALL":
        model = input_data.get("model", "unknown")
        messages = input_data.get("messages", [])
        if messages:
            first_msg = messages[0] if isinstance(messages, list) else messages
            prompt = (
                first_msg.get("content", "")[:60]
                if isinstance(first_msg, dict)
                else str(messages)[:60]
            )
        else:
            prompt = "N/A"

        if output_data and isinstance(output_data, dict):
            choices = output_data.get("choices", [])
            if choices and isinstance(choices, list) and len(choices) > 0:
                choice = choices[0]
                if isinstance(choice, dict):
                    content = (
                        choice.get("message", {}).get("content", "")[:60]
                        if isinstance(choice.get("message"), dict)
                        else ""
                    )
                else:
                    content = ""
            else:
                content = (
                    output_data.get("content", "")[:60]
                    if isinstance(output_data.get("content"), str)
                    else ""
                )
        else:
            content = ""

        return f"Model: {model} | Prompt: {prompt}... | Response: {content}..."

    elif interaction_type == "HTTP_REQUEST":
        method = input_data.get("method", "?")
        url = input_data.get("url", "?")
        if output_data:
            status = output_data.get("status_code", "?")
            return f"{method} {url} → {status}"
        return f"{method} {url}"

    elif interaction_type == "TOOL_CALL":
        func = input_data.get("function", "?")
        args = input_data.get("args", {})
        if output_data:
            result = str(output_data.get("result", ""))[:40]
            return f"{func}({args}) → {result}..."
        return f"{func}({args})"

    else:
        return f"Type: {interaction_type}"


def _display_interaction_details(interaction: dict) -> None:
    """Display full details of an interaction.

    Args:
        interaction: The interaction dictionary
    """
    import json

    seq = interaction.get("sequence", "?")
    interaction_type = interaction.get("interaction_type", "UNKNOWN")

    title = f"Interaction {seq}: {interaction_type}"
    content_lines = []

    # Input
    input_data = interaction.get("input", {})
    if input_data:
        content_lines.append("[bold]Input:[/bold]")
        content_lines.append(json.dumps(input_data, indent=2))

    # Output
    output_data = interaction.get("output")
    if output_data:
        content_lines.append("\n[bold]Output:[/bold]")
        content_lines.append(json.dumps(output_data, indent=2))

    # Error
    error = interaction.get("error")
    if error:
        content_lines.append(f"\n[bold red]Error:[/bold red] {error}")

    # Metadata
    metadata = interaction.get("metadata", {})
    if metadata:
        content_lines.append("\n[bold]Metadata:[/bold]")
        content_lines.append(json.dumps(metadata, indent=2))

    console.print(Panel("\n".join(content_lines), title=title, border_style="blue"))
    console.print()
