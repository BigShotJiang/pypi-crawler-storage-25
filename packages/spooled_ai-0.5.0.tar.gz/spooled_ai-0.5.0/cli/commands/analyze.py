"""Behavioral stability test: discover how non-deterministic your agent is.

Analyzes recent traces for an agent and produces a tool reliability report
showing which tools are called consistently and which are flaky.

Usage:
    spooled test --agent-id my_agent              # Analyze existing traces
    spooled test --agent-id my_agent --runs 5     # Expected runs for % calculation
"""

from __future__ import annotations

from collections import Counter
from pathlib import Path

import structlog
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from spooled.fingerprint import calculate_fingerprint_hash
from spooled.storage import get_trace_directory, load_trace_from_jsonl

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="analyze", help="Analyze agent behavioral stability")


def _load_traces_for_agent(trace_dir: Path, agent_id: str, limit: int = 20) -> list:
    """Load recent traces for a specific agent_id."""
    traces = []
    for trace_file in sorted(
        trace_dir.glob("*.jsonl"), key=lambda f: f.stat().st_mtime, reverse=True
    ):
        try:
            trace_data = load_trace_from_jsonl(trace_file)
            # agent_id can be at top level or nested under "trace"
            aid = trace_data.get("agent_id") or trace_data.get("trace", {}).get("agent_id")
            if aid == agent_id:
                trace_data["_source_file"] = str(trace_file.name)
                traces.append(trace_data)
                if len(traces) >= limit:
                    break
        except Exception:
            continue
    return list(reversed(traces))  # oldest first


def _extract_tool_sequence(trace_data: dict) -> list[str]:
    """Extract the tool call names from a trace's interactions."""
    tools = []
    for interaction in trace_data.get("interactions", []):
        itype = interaction.get("interaction_type", "")
        if itype == "TOOL_CALL":
            inp = interaction.get("input") or {}
            name = inp.get("function") or inp.get("tool_name") or inp.get("tool") or "unknown_tool"
            tools.append(name)
    return tools


def _extract_all_interaction_types(trace_data: dict) -> list[str]:
    """Extract all interaction type:target pairs from a trace."""
    parts = []
    for interaction in trace_data.get("interactions", []):
        itype = interaction.get("interaction_type", "OTHER")
        inp = interaction.get("input") or {}
        if itype == "TOOL_CALL":
            name = inp.get("function") or inp.get("tool_name") or inp.get("tool") or "tool"
            parts.append(f"TOOL:{name}")
        elif itype == "LLM_CALL":
            model = inp.get("model") or "llm"
            parts.append(f"LLM:{model}")
        elif itype == "HTTP_REQUEST":
            method = inp.get("method", "GET")
            parts.append(f"HTTP:{method}")
        else:
            parts.append("OTHER")
    return parts


@app.callback(invoke_without_command=True)
def test_stability(
    agent_id: str = typer.Option(..., "--agent-id", "-a", help="Agent ID to analyze"),
    trace_dir: str | None = typer.Option(
        None, "--from", help="Trace directory (default: .spooled/traces/)"
    ),
    runs: int = typer.Option(
        0, "--runs", "-n", help="Number of runs to analyze (0 = all available)"
    ),
    output: str = typer.Option(
        "table", "--output", "-o", help="Output format: table, json, or csv"
    ),
    wide: bool = typer.Option(
        False, "--wide", "-w", help="Wide output — full tool names, no truncation"
    ),
):
    """Analyze agent behavioral stability across recent runs.

    Shows how non-deterministic your agent is: which tools are called
    consistently, which are flaky, and how many unique behavioral
    fingerprints exist across runs.
    """
    # Wide mode: use wider console; otherwise use module-level default.
    # Must be assigned before first use to avoid F823 (referenced before assignment).
    if wide:
        console = Console(width=300)
    else:
        console = Console()

    # Resolve trace directory
    if trace_dir:
        td = Path(trace_dir)
    else:
        td = get_trace_directory()

    if not td.exists():
        console.print(f"[red]Trace directory not found:[/red] {td}")
        console.print("[dim]Run your agent a few times first to generate traces.[/dim]")
        raise typer.Exit(code=1)

    # Load traces
    limit = runs if runs > 0 else 20
    traces = _load_traces_for_agent(td, agent_id, limit=limit)

    if not traces:
        console.print(f"[red]No traces found for agent:[/red] {agent_id}")
        console.print(f"[dim]Looking in: {td}[/dim]")
        console.print(f'[dim]Make sure your agent uses agent_id="{agent_id}"[/dim]')
        raise typer.Exit(code=1)

    n_runs = len(traces)

    # --- Fingerprint analysis ---
    seq_fingerprints = []
    struct_fingerprints = []
    tool_sequences = []
    all_tools_seen = set()

    for trace in traces:
        interactions = trace.get("interactions", [])
        seq_fp = calculate_fingerprint_hash(interactions, mode="sequence")
        struct_fp = calculate_fingerprint_hash(interactions, mode="structural")
        seq_fingerprints.append(seq_fp)
        struct_fingerprints.append(struct_fp)

        tools = _extract_tool_sequence(trace)
        tool_sequences.append(tools)
        all_tools_seen.update(tools)

    seq_unique = len(set(seq_fingerprints))
    struct_unique = len(set(struct_fingerprints))

    # Calculate tool frequencies for all output formats
    tool_freq: dict[str, int] = Counter()
    for tools in tool_sequences:
        for t in set(tools):
            tool_freq[t] += 1
    sorted_tools = sorted(all_tools_seen, key=lambda t: (-tool_freq[t], t))

    # --- JSON / CSV output (early return) ---
    if output in ("json", "csv"):
        import json as _json

        rows = []
        for tool in sorted_tools:
            freq = tool_freq[tool]
            row = {
                "tool": tool,
                "reliability_pct": round(freq / n_runs * 100, 1),
                "called": freq,
                "total_runs": n_runs,
                "runs": [tool in ts for ts in tool_sequences],
            }
            rows.append(row)

        if output == "json":
            result = {
                "agent_id": agent_id,
                "runs_analyzed": n_runs,
                "unique_sequence_fingerprints": seq_unique,
                "unique_structural_fingerprints": struct_unique,
                "tools": rows,
            }
            typer.echo(_json.dumps(result, indent=2))
        else:
            typer.echo("tool,reliability_pct,called,total_runs")
            for row in rows:
                typer.echo(
                    f"{row['tool']},{row['reliability_pct']},{row['called']},{row['total_runs']}"
                )
        return

    # --- Fingerprint summary ---
    fp_table = Table(show_header=False, box=None, padding=(0, 2))
    fp_table.add_column("Metric", style="bold")
    fp_table.add_column("Value")

    fp_table.add_row("Runs analyzed", str(n_runs))
    fp_table.add_row("Unique tool graphs (sequence)", f"{seq_unique} of {n_runs}")
    fp_table.add_row("Unique tool sets (structural)", f"{struct_unique} of {n_runs}")

    if seq_unique == 1:
        stability = "[green]Fully deterministic[/green] — identical tool graph on every run"
    elif struct_unique == 1:
        stability = "[green]Structurally stable[/green] — same tools, different ordering"
    elif struct_unique <= n_runs * 0.3:
        stability = "[yellow]Moderately stable[/yellow] — some tool set variation"
    else:
        stability = "[red]Highly non-deterministic[/red] — tool sets vary across runs"

    fp_table.add_row("Stability", stability)
    console.print(fp_table)

    console.print(f"\n[bold]Behavioral Stability Report: {agent_id}[/bold]")
    console.print(f"[dim]Analyzing {n_runs} recent run(s) from {td}[/dim]\n")

    # --- Tool reliability matrix ---
    if all_tools_seen:
        console.print("\n[bold]Tool Reliability[/bold]\n")

        # Build the matrix table
        matrix = Table(show_header=True, header_style="bold", padding=(0, 1))
        matrix.add_column("Tool", min_width=20, no_wrap=wide)
        matrix.add_column("Reliability", justify="right", min_width=10)

        # Add run columns (limit to 10 for display)
        display_runs = min(n_runs, 10)
        for i in range(display_runs):
            matrix.add_column(f"R{i+1}", justify="center", width=3)
        if n_runs > display_runs:
            matrix.add_column("...", justify="center", width=3)

        for tool in sorted_tools:
            freq = tool_freq[tool]
            pct = freq / n_runs * 100

            if pct >= 100:
                pct_str = f"[green]{pct:.0f}%[/green]"
            elif pct >= 80:
                pct_str = f"[green]{pct:.0f}%[/green]"
            elif pct >= 50:
                pct_str = f"[yellow]{pct:.0f}%[/yellow]"
            else:
                pct_str = f"[red]{pct:.0f}%[/red]"

            row = [tool, pct_str]

            for i in range(display_runs):
                tools_in_run = tool_sequences[i]
                if tool in tools_in_run:
                    row.append("[green]●[/green]")
                else:
                    row.append("[red]○[/red]")

            if n_runs > display_runs:
                remaining = sum(1 for i in range(display_runs, n_runs) if tool in tool_sequences[i])
                total_remaining = n_runs - display_runs
                if remaining == total_remaining:
                    row.append("[green]●[/green]")
                elif remaining == 0:
                    row.append("[red]○[/red]")
                else:
                    row.append("[yellow]~[/yellow]")

            matrix.add_row(*row)

        console.print(matrix)

    # --- Per-run summary ---
    console.print("\n[bold]Per-Run Detail[/bold]\n")

    run_table = Table(show_header=True, header_style="bold", padding=(0, 1))
    run_table.add_column("Run", justify="right", width=4)
    run_table.add_column("Tools", justify="right", width=5)
    run_table.add_column("Fingerprint", width=16)
    run_table.add_column("Structural", width=16)
    run_table.add_column("Tool Sequence")

    for i, _trace in enumerate(traces[:display_runs]):
        tools = tool_sequences[i]
        seq_fp = seq_fingerprints[i]
        struct_fp = struct_fingerprints[i]

        # Color the fingerprint based on frequency
        seq_count = seq_fingerprints.count(seq_fp)
        fp_color = "green" if seq_count >= 3 else "yellow" if seq_count >= 2 else "dim"

        seq_short = " → ".join(tools)
        if len(seq_short) > 60:
            seq_short = seq_short[:57] + "..."

        run_table.add_row(
            str(i + 1),
            str(len(tools)),
            f"[{fp_color}]{seq_fp}[/{fp_color}]",
            struct_fp,
            f"[dim]{seq_short}[/dim]",
        )

    console.print(run_table)

    # --- Recommendations ---
    console.print()
    recs = []

    if seq_unique == n_runs and n_runs >= 3:
        recs.append(
            "Every run produces a unique tool graph. This is common for LLM-based agents. "
            "Spooled uses [bold]structural fingerprints[/bold] (tool set, ignoring order) "
            "to group runs into stable baselines."
        )

    flaky_tools = [t for t in sorted_tools if 0 < tool_freq[t] < n_runs]
    if flaky_tools:
        flaky_str = ", ".join(f"[yellow]{t}[/yellow]" for t in flaky_tools[:5])
        recs.append(
            f"Flaky tools (called on some runs, not others): {flaky_str}. "
            "Consider adding these as required_tools in your policy to enforce consistency."
        )

    always_called = [t for t in sorted_tools if tool_freq[t] == n_runs]
    if always_called and flaky_tools:
        recs.append(
            f"[green]{len(always_called)}[/green] tools are called 100% of the time. "
            f"[yellow]{len(flaky_tools)}[/yellow] tools are flaky. "
            "Run [bold]spooled ci update-baseline[/bold] to capture the behavioral envelope."
        )

    if not recs:
        recs.append(
            "Agent behavior looks stable. Build a baseline with: "
            "[bold]spooled ci update-baseline --from .spooled/traces/[/bold]"
        )

    rec_text = "\n\n".join(recs)
    console.print(
        Panel(rec_text, title="[bold]Recommendations[/bold]", border_style="cyan", padding=(1, 2))
    )
