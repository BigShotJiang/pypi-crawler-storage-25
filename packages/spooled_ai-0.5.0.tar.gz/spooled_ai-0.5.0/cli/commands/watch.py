"""Watch command — live-tail .spooled/traces/ and compare against baselines.

Usage:
    spooled watch                         # watch default trace dir
    spooled watch -b baselines/agent.json # compare against baseline
    spooled watch -a my_agent -i 1        # filter agent, 1s poll
"""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Any

import structlog
import typer
from rich.console import Console

from spooled.fingerprint import BehavioralFingerprint, hash_fingerprint
from spooled.storage import load_trace_from_jsonl

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="watch", help="Watch traces in real time")


def _resolve_trace_dir(trace_dir: Path | None) -> Path:
    """Resolve trace directory from argument, env var, or default."""
    if trace_dir is not None:
        return trace_dir
    env_dir = os.getenv("SPOOLED_TRACE_DIR")
    if env_dir:
        return Path(env_dir) / "traces"
    return Path.cwd() / ".spooled" / "traces"


def _build_known_files(trace_dir: Path) -> dict[Path, float]:
    """Scan trace_dir for *.jsonl and return {path: mtime} map."""
    known: dict[Path, float] = {}
    if not trace_dir.exists():
        return known
    for p in trace_dir.glob("*.jsonl"):
        try:
            known[p] = p.stat().st_mtime
        except OSError:
            pass
    return known


def _process_new_trace(
    path: Path,
    agent_id_filter: str | None,
    baseline_data: Any,
) -> dict[str, Any] | None:
    """Load a single trace file and optionally compare against a baseline.

    Returns a small result dict (for summary tracking), or None if the
    trace was skipped (e.g. agent_id filter mismatch or load error).
    """
    try:
        trace_data = load_trace_from_jsonl(path)
    except Exception as exc:
        console.print(f"[dim]  skip {path.name}: {exc}[/dim]")
        return None

    trace_agent_id = trace_data.get("trace", {}).get("agent_id", "unknown")

    # Apply agent_id filter
    if agent_id_filter and trace_agent_id != agent_id_filter:
        return None

    fp = BehavioralFingerprint(trace_data)
    fp_data = fp.generate()
    fp_hash = hash_fingerprint(fp_data)
    step_count = len(trace_data.get("interactions", []))

    result: dict[str, Any] = {
        "agent_id": trace_agent_id,
        "fingerprint_hash": fp_hash,
        "step_count": step_count,
        "path": str(path),
        "compared": False,
        "signals": [],
    }

    if baseline_data is not None:
        try:
            from cli.commands.ci import _compute_comparison, _display_compare_results

            comparison = _compute_comparison(
                current_trace=trace_data,
                baseline_data=baseline_data,
                agent_id=trace_agent_id,
            )
            _display_compare_results(comparison)
            result["compared"] = True
            result["signals"] = comparison.get("signals", [])
        except Exception as exc:
            console.print(f"[yellow]  compare error: {exc}[/yellow]")
    else:
        console.print(
            f"[cyan]New trace:[/cyan] agent={trace_agent_id}  "
            f"fingerprint={fp_hash[:16]}  steps={step_count}  "
            f"file={path.name}"
        )

    return result


def _print_summary(results: list[dict[str, Any]]) -> None:
    """Print a short summary after Ctrl-C."""
    if not results:
        console.print("\n[dim]No new traces observed.[/dim]")
        return

    unique_fps: set[str] = {r["fingerprint_hash"] for r in results}
    total_signals = sum(len(r.get("signals", [])) for r in results)

    console.print("\n[bold]Watch summary[/bold]")
    console.print(f"  Traces seen:         {len(results)}")
    console.print(f"  Unique fingerprints: {len(unique_fps)}")
    console.print(f"  Signals detected:    {total_signals}")


@app.callback(invoke_without_command=True)
def traces(
    ctx: typer.Context,
    baseline: Path | None = typer.Option(
        None, "--baseline", "-b", help="Baseline file or directory"
    ),
    agent_id: str | None = typer.Option(None, "--agent-id", "-a", help="Filter by agent ID"),
    interval: float = typer.Option(2.0, "--interval", "-i", help="Poll interval in seconds"),
    trace_dir: Path | None = typer.Option(None, "--dir", "-d", help="Trace directory to watch"),
) -> None:
    """Watch .spooled/traces/ for new trace files and compare in real time."""
    resolved_dir = _resolve_trace_dir(trace_dir)

    if not resolved_dir.exists():
        console.print(f"[red]Error:[/red] Trace directory does not exist: {resolved_dir}")
        raise typer.Exit(code=1)

    # Optionally load baseline
    baseline_data = None
    if baseline is not None:
        if agent_id is None:
            console.print("[red]Error:[/red] --agent-id is required when using --baseline")
            raise typer.Exit(code=1)
        try:
            from spooled.baseline import load_baseline_from_path

            baseline_data = load_baseline_from_path(baseline, agent_id)
            console.print(f"[green]Baseline loaded[/green] from {baseline}")
        except Exception as exc:
            console.print(f"[red]Error loading baseline:[/red] {exc}")
            raise typer.Exit(code=1)

    # Build initial known set
    known = _build_known_files(resolved_dir)
    console.print(
        f"[bold]Watching[/bold] {resolved_dir} ({len(known)} existing traces, Ctrl-C to stop)"
    )

    results: list[dict[str, Any]] = []

    try:
        while True:
            current_files: dict[Path, float] = {}
            for p in resolved_dir.glob("*.jsonl"):
                try:
                    current_files[p] = p.stat().st_mtime
                except OSError:
                    continue

            for path, mtime in current_files.items():
                if path not in known or known[path] < mtime:
                    res = _process_new_trace(path, agent_id, baseline_data)
                    if res is not None:
                        results.append(res)

            known = current_files
            time.sleep(interval)
    except KeyboardInterrupt:
        _print_summary(results)
