"""Command to manage local traces (cleanup, retention)."""

from __future__ import annotations

import time
from pathlib import Path

import structlog
import typer
from rich.console import Console
from rich.table import Table

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="traces", help="Manage local traces")


@app.command()
def cleanup(
    older_than: int = typer.Option(..., "--older-than", help="Delete traces older than N days"),
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Show what would be deleted without deleting"
    ),
    keep_latest: int = typer.Option(
        0, "--keep-latest", help="Always keep the N most recent traces"
    ),
    traces_dir: Path = typer.Option(
        None, "--dir", "-d", help="Traces directory (default: .spooled/traces)"
    ),
) -> None:
    """Delete old local trace files based on age.

    Examples:
        spooled traces cleanup --older-than 30
        spooled traces cleanup --older-than 7 --dry-run
        spooled traces cleanup --older-than 14 --keep-latest 5
    """
    try:
        if older_than < 0:
            console.print("[red]✗[/red] --older-than must be non-negative")
            raise typer.Exit(code=1)

        # Resolve traces directory
        if traces_dir is None:
            traces_dir = Path(".spooled") / "traces"
        traces_dir = traces_dir.resolve()

        if not traces_dir.exists():
            console.print(f"[yellow]⚠[/yellow] Traces directory not found: {traces_dir}")
            return

        # Collect all trace files sorted by mtime (newest first)
        trace_files = sorted(
            traces_dir.glob("*.jsonl"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )

        if not trace_files:
            console.print("No trace files found.")
            return

        # Determine cutoff time
        cutoff = time.time() - (older_than * 86400)

        # Split into keep-latest and candidates
        protected = set()
        if keep_latest > 0:
            for f in trace_files[:keep_latest]:
                protected.add(f)

        # Find files to delete
        to_delete = []
        for f in trace_files:
            if f in protected:
                continue
            if f.stat().st_mtime < cutoff:
                to_delete.append(f)

        if not to_delete:
            console.print(
                f"No traces older than {older_than} day(s) to clean up "
                f"({len(trace_files)} total, {len(protected)} protected)."
            )
            return

        # Show table
        table = Table(
            title="Traces to delete" if not dry_run else "Traces that would be deleted (dry run)"
        )
        table.add_column("File", style="cyan")
        table.add_column("Age (days)", justify="right")
        table.add_column("Size", justify="right")

        total_size = 0
        now = time.time()
        for f in to_delete:
            age_days = (now - f.stat().st_mtime) / 86400
            size = f.stat().st_size
            total_size += size
            table.add_row(f.name, f"{age_days:.1f}", _format_size(size))

        console.print(table)

        if dry_run:
            console.print(
                f"\n[yellow]Dry run:[/yellow] Would delete {len(to_delete)} file(s), "
                f"freeing {_format_size(total_size)}"
            )
            return

        # Actually delete
        deleted = 0
        for f in to_delete:
            f.unlink()
            deleted += 1

        console.print(
            f"\n[green]✓[/green] Deleted {deleted} trace(s), freed {_format_size(total_size)}"
        )

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to clean up traces", error=str(e))
        console.print(f"[red]✗[/red] Cleanup failed: {e}")
        raise typer.Exit(code=1)


def _format_size(size_bytes: int) -> str:
    """Format a byte count as human-readable string."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    else:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
