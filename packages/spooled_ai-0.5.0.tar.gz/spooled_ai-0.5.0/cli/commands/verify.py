"""Command to verify hash chain integrity of traces."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import structlog
import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from cli.utils import resolve_trace_path

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="verify", help="Verify hash chain integrity of traces")


@app.command()
def trace(
    trace_ref: str = typer.Argument(
        ..., help="Run ID or path to trace file (.jsonl)", metavar="TRACE"
    ),
    trace_file: Path | None = typer.Option(
        None, "--file", "-f", help="Explicit path to trace JSONL file"
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed output"),
) -> None:
    """Verify the hash chain integrity of a trace.

    This command validates that:
    1. Each interaction's payload_hash matches its content
    2. Each interaction's prev_hash links correctly to the previous interaction
    3. The trace's chain_hash matches the final interaction's signature

    Example:
       spooled verify abc-123-def
       spooled verify .spooled/traces/abc-123-def.jsonl
       spooled verify abc-123-def --file ./traces/abc-123-def.jsonl
    """
    from cli.utils import extract_run_id

    display_name = extract_run_id(trace_ref) if "/" in trace_ref else trace_ref

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task(f"Verifying hash chain for {display_name}...", total=None)

        try:
            # Resolve trace file path (accepts both run IDs and file paths)
            trace_file = resolve_trace_path(trace_ref, trace_file)

            if trace_file is None or not trace_file.exists():
                console.print(f"[red]✗[/red] Trace not found: {trace_ref}")
                console.print("\n[yellow]Tips:[/yellow]")
                console.print("   1. List available traces: [cyan]spooled list traces[/cyan]")
                console.print(
                    f"   2. Pull from backend: [cyan]spooled pull trace {display_name}[/cyan]"
                )
                raise typer.Exit(code=1)

            # Load and verify
            result = verify_hash_chain(trace_file, verbose)

            progress.update(task, completed=True)

            # Display results
            if result["valid"]:
                console.print(f"[green]✓[/green] Hash chain verification passed for {display_name}")
                console.print(
                    "[dim]Note: payload hashes are verified transitively via the chain "
                    "(content is not stored — privacy by architecture).[/dim]"
                )
                if verbose:
                    _display_verification_details(result)
            else:
                console.print(f"[red]✗[/red] Hash chain verification failed for {display_name}")
                _display_verification_errors(result)
                raise typer.Exit(code=1)

        except FileNotFoundError as e:
            console.print(f"[red]✗[/red] File not found: {str(e)}")
            raise typer.Exit(code=1)
        except typer.Exit:
            raise
        except Exception as e:
            logger.debug("Verification failed", trace=trace_ref, error=str(e))
            console.print(f"[red]✗[/red] Verification failed: {str(e)}")
            if verbose:
                import traceback

                console.print("\n[dim]Full traceback:[/dim]")
                console.print(traceback.format_exc())
            raise typer.Exit(code=1)


def verify_hash_chain(trace_file: Path, verbose: bool = False) -> dict:
    """Verify the hash chain integrity of a trace.

    Args:
        trace_file: Path to the trace JSONL file
        verbose: Whether to include detailed information

    Returns:
        Dictionary with verification results
    """
    from spooled.storage import load_trace_from_jsonl

    # Load trace data
    trace_data = load_trace_from_jsonl(trace_file)
    interactions = trace_data.get("interactions", [])

    if not interactions:
        return {
            "valid": False,
            "errors": ["No interactions found in trace"],
            "interactions_checked": 0,
        }

    errors = []
    prev_signature: str | None = None

    # Verify each interaction
    for i, interaction in enumerate(interactions):
        interaction_id = interaction.get("interaction_id", f"interaction_{i}")
        sequence = interaction.get("sequence", i)

        # 1. Verify payload_hash presence
        actual_payload_hash = interaction.get("payload_hash")
        if not actual_payload_hash:
            errors.append(f"Interaction {sequence} ({interaction_id}): missing payload_hash")

        # 1b. Verify structural_hash (post-strip content integrity)
        stored_structural_hash = interaction.get("structural_hash")
        if stored_structural_hash:
            input_data = interaction.get("input") or {}
            output_data = interaction.get("output")
            structural_payload = {
                "input": {k: v for k, v in input_data.items() if k != "payload_hash"},
                "output": (
                    {k: v for k, v in output_data.items() if k != "payload_hash"}
                    if output_data
                    else None
                ),
                "interaction_type": interaction.get("interaction_type", "OTHER"),
            }
            structural_json = json.dumps(structural_payload, sort_keys=True, ensure_ascii=False)
            recomputed = hashlib.sha256(structural_json.encode("utf-8")).hexdigest()
            if recomputed != stored_structural_hash:
                errors.append(
                    f"Interaction {sequence} ({interaction_id}): structural_hash mismatch — "
                    f"saved data has been modified after recording"
                )

        # 2. Verify prev_hash links correctly
        expected_prev_hash = prev_signature
        actual_prev_hash = interaction.get("prev_hash")

        if i == 0:
            # First interaction should have prev_hash = None
            if actual_prev_hash is not None:
                errors.append(
                    f"Interaction {sequence} ({interaction_id}): First interaction should have "
                    f"prev_hash=None, got {actual_prev_hash[:16] if actual_prev_hash else None}..."
                )
        else:
            # Subsequent interactions should link to previous
            if actual_prev_hash != expected_prev_hash:
                errors.append(
                    f"Interaction {sequence} ({interaction_id}): prev_hash mismatch. "
                    f"Expected {expected_prev_hash[:16] if expected_prev_hash else None}..., "
                    f"got {actual_prev_hash[:16] if actual_prev_hash else None}..."
                )

        # 3. Calculate this interaction's signature for next link
        if actual_payload_hash:
            interaction_signature = _calculate_interaction_signature(
                interaction_id=interaction_id,
                sequence=sequence,
                interaction_type=interaction.get("interaction_type", "OTHER"),
                payload_hash=actual_payload_hash,
                prev_hash=actual_prev_hash,
            )
            prev_signature = interaction_signature
        else:
            errors.append(
                f"Interaction {sequence} ({interaction_id}): Missing payload_hash, "
                "cannot verify chain integrity"
            )
            prev_signature = None

    # 4. Verify chain_hash matches final signature
    trace_chain_hash = trace_data.get("trace", {}).get("chain_hash")
    if trace_chain_hash:
        if prev_signature and trace_chain_hash != prev_signature:
            errors.append(
                f"Trace chain_hash mismatch. Expected {prev_signature[:16]}..., "
                f"got {trace_chain_hash[:16]}..."
            )
        elif not prev_signature:
            errors.append(
                "Trace has chain_hash but final interaction signature could not be calculated"
            )
    elif prev_signature and verbose:
        # Not an error, but note if chain_hash is missing
        pass

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "interactions_checked": len(interactions),
        "final_signature": prev_signature,
        "trace_chain_hash": trace_chain_hash,
    }


def _strip_verification_fields(data: dict | None) -> dict | None:
    """Remove fields that were added after hash computation.

    The recorder computes payload_hash from the raw input/output, then
    adds the hash itself into the stripped data before saving. When
    re-verifying, we must remove these added fields to recompute
    the original hash.
    """
    if data is None or not isinstance(data, dict):
        return data
    return {k: v for k, v in data.items() if k != "payload_hash"}


def _calculate_payload_hash(
    input_data: dict,
    output_data: dict | None,
    error: str | None,
    metadata: dict,
) -> str:
    """Calculate SHA-256 hash of the interaction payload."""
    payload = {
        "input": _strip_verification_fields(input_data),
        "output": _strip_verification_fields(output_data),
        "error": error,
        "metadata": metadata,
    }
    payload_json = json.dumps(payload, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(payload_json.encode("utf-8")).hexdigest()


def _calculate_redaction_hash(
    input_data: dict,
    output_data: dict | None,
    error: str | None,
) -> str:
    payload = {
        "input": _strip_verification_fields(input_data),
        "output": _strip_verification_fields(output_data),
        "error": error,
    }
    payload_json = json.dumps(payload, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(payload_json.encode("utf-8")).hexdigest()


def _calculate_interaction_signature(
    interaction_id: str,
    sequence: int,
    interaction_type: str,
    payload_hash: str,
    prev_hash: str | None,
) -> str:
    """Calculate the signature of an interaction for hash chaining."""
    signature_data = {
        "interaction_id": interaction_id,
        "sequence": sequence,
        "interaction_type": interaction_type,
        "payload_hash": payload_hash,
        "prev_hash": prev_hash or "",
    }
    signature_json = json.dumps(signature_data, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(signature_json.encode("utf-8")).hexdigest()


def _display_verification_details(result: dict) -> None:
    """Display detailed verification results."""
    table = Table(title="Verification Details")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("Interactions Checked", str(result["interactions_checked"]))
    if result.get("final_signature"):
        table.add_row("Final Signature", result["final_signature"][:32] + "...")
    if result.get("trace_chain_hash"):
        table.add_row("Trace Chain Hash", result["trace_chain_hash"][:32] + "...")

    console.print("\n")
    console.print(table)


def _display_verification_errors(result: dict) -> None:
    """Display verification errors."""
    console.print(f"\n[red]Found {len(result['errors'])} error(s):[/red]\n")
    for error in result["errors"]:
        console.print(f"  • {error}")


# ─── audit-bundle ─────────────────────────────────────────────────────────────


@app.command("audit-bundle")
def audit_bundle(
    trace_ref: str = typer.Argument(
        ..., help="Run ID or path to trace file (.jsonl)", metavar="TRACE"
    ),
    out: Path | None = typer.Option(
        None, "--out", "-o", help="Output path for the zip (default: audit-<id[:8]>.zip)"
    ),
    trace_file: Path | None = typer.Option(
        None, "--file", "-f", help="Explicit path to trace JSONL file"
    ),
    baseline: Path | None = typer.Option(
        None, "--baseline", "-b", help="Path to baseline summary JSON for comparison"
    ),
    policy: Path | None = typer.Option(
        None,
        "--policy",
        "-p",
        help="Path to policy YAML (auto-discovers .spooled/policy.yml if not set)",
    ),
) -> None:
    """Export a trace as a self-contained audit bundle zip.

    The bundle contains the raw trace, hash chain verification results,
    behavioral fingerprint, provenance metadata (git hash, branch, env
    fingerprint), optional baseline comparison, and optional policy evaluation.

    Each file in the zip has a SHA-256 checksum in manifest.json, making
    the bundle independently verifiable without spooled tooling.

    Example:
       spooled verify audit-bundle abc-123
       spooled verify audit-bundle .spooled/traces/abc-123.jsonl
       spooled verify audit-bundle abc-123 --baseline baselines/my_agent.json
       spooled verify audit-bundle abc-123 --out reports/audit.zip
    """
    from cli.utils import extract_run_id
    from spooled.attestation import build_audit_bundle

    display_name = extract_run_id(trace_ref) if "/" in trace_ref else trace_ref

    # Resolve trace file path (accepts both run IDs and file paths)
    resolved_file = resolve_trace_path(trace_ref, trace_file)

    if not resolved_file or not resolved_file.exists():
        console.print(f"[red]✗[/red] Trace not found: {trace_ref}")
        console.print("\n[yellow]Tips:[/yellow]")
        console.print("  List traces: [cyan]spooled list traces[/cyan]")
        console.print(
            f"  Specify file: [cyan]spooled verify audit-bundle {trace_ref} --file path/to/trace.jsonl[/cyan]"
        )
        raise typer.Exit(code=1)

    out_path = out or Path(f"audit-{display_name[:8]}.zip")

    try:
        result = build_audit_bundle(
            trace_file=resolved_file,
            out_path=out_path,
            baseline_path=baseline,
            policy_path=policy,
        )

        chain_status = "[green]VALID[/green]" if result["chain_valid"] else "[red]INVALID[/red]"
        console.print(f"\n[green]Audit bundle created:[/green] {result['path']}")
        console.print(f"  run_id:          {result['run_id']}")
        console.print(f"  agent_id:        {result['agent_id']}")
        console.print(f"  chain integrity: {chain_status}")
        console.print(f"  fingerprint:     {result['fingerprint_hash']}")
        console.print("  contents:")
        for fname in result["files"]:
            checksum = result["manifest"]["files"].get(fname, "")[:16]
            console.print(f"    {fname}  [dim]{checksum}...[/dim]")

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Audit bundle failed", run_id=display_name, error=str(e))
        console.print(f"[red]✗[/red] Failed: {e}")
        raise typer.Exit(code=1)
