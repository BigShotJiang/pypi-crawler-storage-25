"""Attestation commands for behavioral certification.

Commands:
    create  - Submit a trace for attestation and receive a signed receipt
    verify  - Verify an attestation receipt offline
    list    - List attestations from the backend
    show    - Show full attestation details
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import structlog
import typer
from rich.console import Console
from rich.table import Table

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="attest", help="Manage behavioral attestations")


@app.command("create")
def create(
    trace: Path = typer.Argument(..., help="Path to trace file (.jsonl)"),
    baseline: Path | None = typer.Option(
        None, "--baseline", "-b", help="Path to baseline (for drift score computation)"
    ),
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend URL (overrides SPOOLED_BACKEND_URL)"
    ),
    out: Path | None = typer.Option(
        None, "--out", "-o", help="Save receipt to specific path (default: .spooled/attestations/)"
    ),
) -> None:
    """Submit a trace for attestation and receive a signed receipt.

    Reads the trace, computes fingerprint, drift score, and spooled score,
    then sends measurements to the attestation API for cryptographic signing.

    Example:
        spooled attest create .spooled/traces/run-123.jsonl
        spooled attest create trace.jsonl --baseline baselines/agent.json
    """
    from spooled.attest import save_receipt, submit_attestation
    from spooled.fingerprint import BehavioralFingerprint, hash_fingerprint
    from spooled.storage import load_trace_from_jsonl

    if not trace.exists():
        console.print(f"[red]✗[/red] Trace not found: {trace}")
        raise typer.Exit(code=1)

    try:
        # Load trace
        trace_data = load_trace_from_jsonl(trace)
        agent_id = trace_data.get("trace", {}).get("agent_id", "unknown")
        run_id = trace_data.get("trace", {}).get("run_id")
        chain_hash = trace_data.get("trace", {}).get("chain_hash")

        # Compute fingerprint
        fp = BehavioralFingerprint(trace_data)
        fp_data = fp.generate()
        fp_hash = hash_fingerprint(fp_data)

        # Compute metrics
        interactions = trace_data.get("interactions", [])
        total_tokens = 0
        total_latency = 0.0
        for i in interactions:
            output = i.get("output") or {}
            usage = output.get("usage") or {}
            total_tokens += int(usage.get("total_tokens", 0))
            meta = i.get("metadata") or {}
            lat = meta.get("latency_ms") or meta.get("duration_ms") or 0
            total_latency += float(lat)

        metrics = {
            "step_count": len(interactions),
            "total_tokens": total_tokens,
            "latency_ms": round(total_latency, 1),
        }

        # Compute drift score if baseline provided
        drift_score = None
        spooled_score_val = None
        spooled_grade_val = None
        if baseline and baseline.exists():
            try:
                from spooled.baseline import load_baseline_from_path
                from spooled.fingerprint import fingerprint_similarity_detailed

                baseline_data = load_baseline_from_path(baseline, agent_id)
                if baseline_data and baseline_data.intents:
                    # Find matching intent
                    for intent_id, stats in baseline_data.intents.items():
                        if (
                            intent_id == fp_hash
                            or intent_id == fp_hash[:16]
                            or fp_hash in stats.accepted_fingerprints
                        ):
                            base_fp = stats.fingerprint
                            if base_fp:
                                result = fingerprint_similarity_detailed(base_fp, fp_data)
                                drift_score = result.get("overall_similarity")
                            break
            except Exception as e:
                logger.debug("Could not compute drift score", error=str(e))

        console.print(f"  Agent: {agent_id}")
        console.print(f"  Fingerprint: {fp_hash[:16]}...")
        if drift_score is not None:
            console.print(f"  Drift Score: {drift_score:.2f}")
        console.print("  Submitting attestation...")

        # Submit
        result = submit_attestation(
            agent_id=agent_id,
            fingerprint_hash=fp_hash,
            chain_hash=chain_hash,
            drift_score=drift_score,
            spooled_score=spooled_score_val,
            spooled_grade=spooled_grade_val,
            metrics=metrics,
            run_id=run_id,
            backend_url=backend_url,
        )

        receipt = result.get("receipt", {})
        attestation_id = result.get("attestation_id", "unknown")

        # Save receipt
        if out:
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(json.dumps(receipt, indent=2, sort_keys=True, default=str))
            console.print(f"  Receipt saved: {out}")
        else:
            saved_path = save_receipt(receipt)
            console.print(f"  Receipt saved: {saved_path}")

        console.print(f"\n[green]Attestation created: {attestation_id}[/green]")

    except RuntimeError as e:
        console.print(f"[red]✗[/red] {e}")
        raise typer.Exit(code=1)
    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Attestation create failed", error=str(e))
        console.print(f"[red]✗[/red] Attestation failed: {e}")
        raise typer.Exit(code=1)


@app.command("verify")
def verify(
    receipt_path: Path = typer.Argument(..., help="Path to receipt JSON file"),
    public_key: Path | None = typer.Option(
        None, "--public-key", "-k", help="Path to public key PEM file"
    ),
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend URL for fetching public key"
    ),
) -> None:
    """Verify an attestation receipt offline.

    Loads the receipt JSON, fetches or uses the provided public key,
    and verifies the cryptographic signature locally.

    Example:
        spooled attest verify .spooled/attestations/abc-123.json
        spooled attest verify receipt.json --public-key signing-key.pem
    """
    from spooled.attest import verify_receipt

    if not receipt_path.exists():
        console.print(f"[red]✗[/red] Receipt not found: {receipt_path}")
        raise typer.Exit(code=1)

    try:
        receipt = json.loads(receipt_path.read_text())
    except json.JSONDecodeError as e:
        console.print(f"[red]✗[/red] Invalid JSON: {e}")
        raise typer.Exit(code=1)

    # Load public key if provided
    pem = None
    if public_key and public_key.exists():
        pem = public_key.read_text()

    attestation_id = receipt.get("attestation_id", "unknown")
    agent_id = receipt.get("agent_id", "unknown")
    timestamp = receipt.get("timestamp", "unknown")
    fp_hash = receipt.get("fingerprint_hash", "")[:16]

    console.print(f"  Attestation: {attestation_id}")
    console.print(f"  Agent: {agent_id}")
    console.print(f"  Timestamp: {timestamp}")
    console.print(f"  Fingerprint: {fp_hash}...")
    console.print("  Verifying signature...")

    valid = verify_receipt(receipt, public_key_pem=pem, backend_url=backend_url)

    if valid:
        console.print("\n[green]VERIFIED - Signature is valid[/green]")
    else:
        console.print("\n[red]INVALID - Signature verification failed[/red]")
        raise typer.Exit(code=1)


@app.command("list")
def list_attestations(
    agent_id: str = typer.Option(..., "--agent-id", "-a", help="Agent identifier"),
    limit: int = typer.Option(20, "--limit", "-n", help="Maximum number to show"),
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend URL (overrides SPOOLED_BACKEND_URL)"
    ),
) -> None:
    """List attestations for an agent.

    Example:
        spooled attest list --agent-id my_agent
    """
    url = backend_url or os.getenv("SPOOLED_BACKEND_URL", "")
    if not url:
        console.print("[red]✗[/red] SPOOLED_BACKEND_URL not configured")
        raise typer.Exit(code=1)

    try:
        import httpx
    except ImportError:
        console.print("[red]✗[/red] httpx required (pip install httpx)")
        raise typer.Exit(code=1)

    from spooled.utils import get_auth_headers

    headers = {"Accept": "application/json", **get_auth_headers()}
    endpoint = f"{url.rstrip('/')}/api/attestations?agent_id={agent_id}&limit={limit}"

    try:
        with httpx.Client(timeout=15.0) as client:
            response = client.get(endpoint, headers=headers)
            response.raise_for_status()
            data = response.json()
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]✗[/red] Failed to list attestations: {e}")
        raise typer.Exit(code=1)

    attestations = data.get("attestations", [])
    if not attestations:
        console.print(f"No attestations found for agent: {agent_id}")
        return

    table = Table(title=f"Attestations for {agent_id}")
    table.add_column("ID", style="dim", max_width=12)
    table.add_column("Timestamp")
    table.add_column("Fingerprint", max_width=18)
    table.add_column("Score")
    table.add_column("Grade")
    table.add_column("Status")

    for att in attestations:
        att_id = att.get("attestation_id", "")[:12]
        ts = att.get("timestamp", "")[:19]
        fp = att.get("fingerprint_hash", "")[:16]
        score = str(att.get("spooled_score", "-"))
        grade = att.get("spooled_grade", "-")
        status = att.get("status", "signed")
        status_color = "green" if status == "signed" else "red"
        table.add_row(att_id, ts, fp, score, grade, f"[{status_color}]{status}[/{status_color}]")

    console.print(table)


@app.command("show")
def show(
    attestation_id: str = typer.Argument(..., help="Attestation ID"),
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend URL (overrides SPOOLED_BACKEND_URL)"
    ),
) -> None:
    """Show full attestation details.

    Example:
        spooled attest show abc-def-123
    """
    url = backend_url or os.getenv("SPOOLED_BACKEND_URL", "")
    if not url:
        console.print("[red]✗[/red] SPOOLED_BACKEND_URL not configured")
        raise typer.Exit(code=1)

    try:
        import httpx
    except ImportError:
        console.print("[red]✗[/red] httpx required (pip install httpx)")
        raise typer.Exit(code=1)

    from spooled.utils import get_auth_headers

    headers = {"Accept": "application/json", **get_auth_headers()}
    endpoint = f"{url.rstrip('/')}/api/attestations/{attestation_id}"

    try:
        with httpx.Client(timeout=15.0) as client:
            response = client.get(endpoint, headers=headers)
            if response.status_code == 404:
                console.print(f"[red]✗[/red] Attestation not found: {attestation_id}")
                raise typer.Exit(code=1)
            response.raise_for_status()
            data = response.json()
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]✗[/red] Failed to get attestation: {e}")
        raise typer.Exit(code=1)

    console.print(json.dumps(data, indent=2, default=str))
