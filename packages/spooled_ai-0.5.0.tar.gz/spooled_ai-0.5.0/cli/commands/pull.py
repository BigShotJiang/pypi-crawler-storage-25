"""Command to pull traces from the backend."""

from __future__ import annotations

from pathlib import Path

import structlog
import typer
from dotenv import load_dotenv
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from spooled.utils import get_auth_headers

# Load .env file if it exists
load_dotenv()

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="pull", help="Pull a trace from the backend")


@app.command()
def trace(
    run_id: str = typer.Argument(..., help="The trace run_id to pull"),
    output_dir: Path = typer.Option(
        Path("traces"), "--output-dir", "-o", help="Directory to save the trace"
    ),
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend API URL (overrides env var)"
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed output"),
) -> None:
    """Pull a trace from the backend and save it locally.

    Example:
       spooled pull abc-123-def
       spooled pull abc-123-def --output-dir ./my-traces
    """
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task(f"Pulling trace {run_id}...", total=None)

        try:
            # Fetch from backend
            trace_data = fetch_trace_from_backend(run_id, backend_url)

            # Save as JSONL (preferred) or JSON
            output_path = output_dir / f"{run_id}.jsonl"
            save_trace(trace_data, output_path)

            progress.update(task, completed=True)
            console.print(f"[green]✓[/green] Trace {run_id} pulled successfully")
            console.print(f"Saved to: {output_path}")

        except ImportError as e:
            console.print(f"[red]✗[/red] Missing dependency: {str(e)}")
            console.print("\n[yellow]💡 Tip:[/yellow] Install missing dependencies:")
            console.print("   [cyan]pip install httpx[/cyan]")
            raise typer.Exit(code=1)
        except ValueError as e:
            console.print(f"[red]✗[/red] {str(e)}")
            if "not found" in str(e).lower():
                console.print("\n[yellow]💡 Tips:[/yellow]")
                console.print("   1. Verify the run_id is correct")
                console.print(
                    "   2. Check if the trace exists: [cyan]spooled list traces --remote-only[/cyan]"
                )
                console.print("   3. Ensure backend URL is configured: [cyan]spooled status[/cyan]")
            raise typer.Exit(code=1)
        except ConnectionError as e:
            console.print(f"[red]✗[/red] Connection failed: {str(e)}")
            console.print("\n[yellow]💡 Tips:[/yellow]")
            console.print("   1. Check backend status: [cyan]spooled status[/cyan]")
            console.print("   2. Verify backend URL in .env or use --backend-url")
            console.print("   3. Ensure backend is deployed and accessible")
            if verbose:
                logger.debug("Connection error details", run_id=run_id, error=str(e))
            raise typer.Exit(code=1)
        except typer.Exit:
            raise
        except Exception as e:
            logger.debug("Failed to pull trace", run_id=run_id, error=str(e))
            console.print(f"[red]✗[/red] Failed to pull trace: {str(e)}")
            if verbose:
                import traceback

                console.print("\n[dim]Full traceback:[/dim]")
                console.print(traceback.format_exc())
            else:
                console.print(
                    "\n[yellow]💡 Tip:[/yellow] Use [cyan]--verbose[/cyan] for detailed error information"
                )
            raise typer.Exit(code=1)


def fetch_trace_from_backend(run_id: str, backend_url: str | None = None) -> dict:
    """Fetch a trace from the backend API.

    Args:
        run_id: The trace ID to fetch
        backend_url: Backend API URL

    Returns:
        The trace data as a dictionary

    Raises:
        ConnectionError: If backend is unreachable
        ValueError: If trace not found or invalid response
    """
    import os

    try:
        import httpx
    except ImportError:
        raise ImportError(
            "httpx is required for backend API integration. Install with: pip install httpx"
        )

    # Get backend URL from parameter, env var, or default
    url = backend_url or os.getenv("SPOOLED_BACKEND_URL", "https://api.spooled.ai")
    api_url = f"{url.rstrip('/')}/api/traces/{run_id}"

    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                api_url, headers={"Accept": "application/json", **get_auth_headers()}
            )
            response.raise_for_status()

            trace_data = response.json()

            # Validate response structure
            if "trace" not in trace_data:
                raise ValueError("Invalid response format: missing 'trace' key")

            # Ensure interactions list exists
            if "interactions" not in trace_data:
                trace_data["interactions"] = []

            interaction_count = len(trace_data.get("interactions", []))
            logger.info(
                "Trace fetched from backend", run_id=run_id, interaction_count=interaction_count
            )
            return trace_data

    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            raise ValueError(f"Trace not found: {run_id}")
        raise ConnectionError(f"Backend API error: {e.response.status_code} - {e.response.text}")
    except httpx.ConnectError as e:
        raise ConnectionError(f"Failed to connect to backend at {url}: {str(e)}")
    except httpx.TimeoutException:
        raise ConnectionError(f"Request to backend timed out: {url}")
    except Exception as e:
        raise ConnectionError(f"Unexpected error fetching trace: {str(e)}")


def save_trace(trace_data: dict, output_path: Path) -> None:
    """Save trace data to a JSONL or JSON file.

    Args:
        trace_data: The trace data dictionary
        output_path: Path to save the trace file
    """
    from spooled.storage import JsonlWriter

    output_path.parent.mkdir(parents=True, exist_ok=True)

    if output_path.suffix == ".jsonl":
        # Save as JSONL
        with JsonlWriter(output_path) as writer:
            writer.write({"type": "trace", **trace_data.get("trace", {})})
            for interaction in trace_data.get("interactions", []):
                writer.write({"type": "interaction", **interaction})
    else:
        # Fallback to JSON
        import json

        with open(output_path, "w") as f:
            json.dump(trace_data, f, indent=2)
