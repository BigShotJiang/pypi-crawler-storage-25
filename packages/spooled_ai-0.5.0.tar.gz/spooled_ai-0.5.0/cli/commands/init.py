"""Command to initialize a project for Spooled."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import structlog
import typer
from rich.console import Console
from rich.panel import Panel

from cli.templates.demo_agent import DEMO_AGENT_TEMPLATE
from cli.templates.github_workflow import ACCEPT_VARIANT_WORKFLOW_TEMPLATE, GITHUB_WORKFLOW_TEMPLATE
from cli.templates.sample_policy import SAMPLE_POLICY_TEMPLATE

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="init", help="Initialize a project for Spooled")


@app.command()
def project(
    project_dir: Path = typer.Option(
        Path("."), "--dir", "-d", help="Project directory to initialize"
    ),
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend API URL to configure"
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing configuration"),
    with_demo: bool = typer.Option(
        False, "--with-demo", help="Generate demo agent, baseline, policy, and CI workflow"
    ),
) -> None:
    """Initialize a project for Spooled trace capture.

    This command:
    - Creates .spooled/ directory structure
    - Creates .env file from .env.example (if it exists)
    - Sets up basic configuration

    With --with-demo:
    - Scaffolds a working demo agent (no API keys needed)
    - Runs it to generate a live trace
    - Creates a golden baseline
    - Adds a policy file and GitHub Actions workflow

    Examples:
       spooled init project
       spooled init project --with-demo
       spooled init project --backend-url https://api.example.com
       spooled init project --dir ./my-project
    """
    try:
        project_path = Path(project_dir).resolve()

        if not project_path.exists():
            console.print(f"[red]✗[/red] Directory does not exist: {project_path}")
            raise typer.Exit(code=1)

        # Python version check

        console.print(f"[cyan]Initializing Spooled in: {project_path}[/cyan]\n")

        # Create .spooled directory structure
        spooled_dir = project_path / ".spooled"
        traces_dir = spooled_dir / "traces"

        created_dirs = []
        if not traces_dir.exists():
            traces_dir.mkdir(parents=True, exist_ok=True)
            created_dirs.append(str(traces_dir))
            console.print(f"[green]✓[/green] Created directory: {traces_dir}")
        else:
            console.print(f"[dim]Directory already exists: {traces_dir}[/dim]")

        # Create .env file from .env.example if it doesn't exist
        env_example = project_path / ".env.example"
        env_file = project_path / ".env"

        if env_example.exists():
            if not env_file.exists() or force:
                # Read .env.example
                env_content = env_example.read_text()

                # Override backend URL if provided
                if backend_url:
                    # Replace or add SPOOLED_BACKEND_URL
                    lines = env_content.split("\n")
                    new_lines = []
                    found = False
                    for line in lines:
                        if line.startswith("SPOOLED_BACKEND_URL="):
                            new_lines.append(f"SPOOLED_BACKEND_URL={backend_url}")
                            found = True
                        else:
                            new_lines.append(line)
                    if not found:
                        new_lines.append(f"SPOOLED_BACKEND_URL={backend_url}")
                    env_content = "\n".join(new_lines)

                env_file.write_text(env_content)
                console.print(f"[green]✓[/green] Created .env file: {env_file}")
            else:
                console.print(
                    "[yellow]⚠[/yellow] .env file already exists (use --force to overwrite)"
                )
        else:
            # Create basic .env file
            if not env_file.exists() or force:
                env_content = "# Spooled Configuration\n"
                if backend_url:
                    env_content += f"SPOOLED_BACKEND_URL={backend_url}\n"
                else:
                    env_content += "# SPOOLED_BACKEND_URL=https://your-api-url.execute-api.us-east-1.amazonaws.com/prod/\n"
                env_content += "# SPOOLED_API_KEY=your-api-key\n"
                env_content += "\n# Optional: Set log level\n"
                env_content += "# SPOOLED_LOG_LEVEL=INFO\n"

                env_file.write_text(env_content)
                console.print(f"[green]✓[/green] Created .env file: {env_file}")
            else:
                console.print(
                    "[yellow]⚠[/yellow] .env file already exists (use --force to overwrite)"
                )

        # Create .gitignore entry if .gitignore exists
        gitignore = project_path / ".gitignore"
        if gitignore.exists():
            gitignore_content = gitignore.read_text()
            if ".spooled/" not in gitignore_content:
                gitignore.write_text(gitignore_content + "\n# Spooled traces\n.spooled/\n")
                console.print("[green]✓[/green] Updated .gitignore")
        else:
            # Create basic .gitignore
            gitignore.write_text("# Spooled traces\n.spooled/\n")
            console.print("[green]✓[/green] Created .gitignore")

        # Scaffold demo if requested
        if with_demo:
            _scaffold_demo(project_path)
            return

        # Show next steps (non-demo path)
        console.print()
        console.print(
            Panel.fit(
                "[bold green]✓ Project initialized successfully![/bold green]\n\n"
                "[bold]Next steps:[/bold]\n"
                "1. Configure your backend URL and API key in .env (if not already set)\n"
                "2. Start capturing traces in your code:\n"
                "   [cyan]import spooled[/cyan]\n"
                "   [cyan]spooled.init(agent_id='my_agent')[/cyan]\n"
                "   [cyan]# ... your agent code ...[/cyan]\n"
                "   [cyan]spooled.shutdown()[/cyan]\n\n"
                "3. View traces: [cyan]spooled list traces[/cyan]\n"
                "4. Generate replay tests: [cyan]spooled replay <run_id>[/cyan]\n\n"
                "[dim]Tip: Run [cyan]spooled init project --with-demo[/cyan] for a working demo in seconds[/dim]",
                title="Setup Complete",
                border_style="green",
            )
        )

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to initialize project", error=str(e))
        console.print(f"[red]✗[/red] Failed to initialize project: {str(e)}")
        raise typer.Exit(code=1)


def _scaffold_demo(project_path: Path) -> None:
    """Scaffold a complete working demo: agent, policy, baseline, and CI workflow.

    Args:
        project_path: Root project directory (already initialized with .spooled/)
    """
    agent_id = "demo_agent"
    agent_filename = f"{agent_id}.py"

    # 1. Write demo agent
    agent_path = project_path / agent_filename
    agent_path.write_text(DEMO_AGENT_TEMPLATE.format(agent_id=agent_id))
    console.print(f"[green]✓[/green] Created demo agent: {agent_filename}")

    # 2. Write policy
    policy_path = project_path / "spooled-policy.yml"
    policy_path.write_text(SAMPLE_POLICY_TEMPLATE)
    console.print("[green]✓[/green] Created policy: spooled-policy.yml")

    # 2b. Write requirements.txt if it doesn't exist
    reqs_path = project_path / "requirements.txt"
    if not reqs_path.exists():
        reqs_path.write_text("spooled>=0.2.0\n")
        console.print("[green]✓[/green] Created requirements.txt")

    # 3. Run the demo agent to generate a trace
    console.print("\n[cyan]Running demo agent...[/cyan]")
    result = subprocess.run(
        [sys.executable, str(agent_path)],
        cwd=str(project_path),
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        console.print(f"[red]✗[/red] Demo agent failed:\n{result.stderr}")
        return
    console.print("[green]✓[/green] Demo agent ran successfully")
    if result.stdout.strip():
        import re

        # Match structlog lines: "2024-01-15 10:30:45" or "2024-01-15T10:30:45"
        _structlog_re = re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}")
        for line in result.stdout.strip().split("\n"):
            stripped = line.strip()
            if _structlog_re.match(stripped):
                continue
            if stripped:
                console.print(f"  [dim]{stripped}[/dim]")

    # 4. Find the generated trace and build a baseline
    traces_dir = project_path / ".spooled" / "traces"
    trace_files = sorted(traces_dir.glob("*.jsonl"), key=lambda p: p.stat().st_mtime)
    if not trace_files:
        console.print("[red]✗[/red] No trace file generated — cannot create baseline")
        return

    trace_file = trace_files[-1]  # most recent
    console.print(f"[green]✓[/green] Trace captured: {trace_file.name}")

    # Build baseline
    from cli.commands.ci import _enrich_baseline_stats
    from spooled.baseline import BaselineManager
    from spooled.storage import load_trace_from_jsonl

    trace_data = load_trace_from_jsonl(trace_file)
    manager = BaselineManager(agent_id)
    status = trace_data.get("trace", {}).get("status", "SUCCESS")

    # Suppress structlog noise during baseline creation
    import io

    _devnull = io.StringIO()
    _old_stdout, _old_stderr = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = _devnull, _devnull
    try:
        manager.add_to_baseline(trace_data, status)
        _enrich_baseline_stats(manager, trace_data)

        baselines_dir = project_path / "baselines"
        baselines_dir.mkdir(parents=True, exist_ok=True)
        baseline_path = baselines_dir / f"{agent_id}.json"
        manager.save_summary(baseline_path)
    finally:
        sys.stdout, sys.stderr = _old_stdout, _old_stderr
    console.print(f"[green]✓[/green] Baseline created: baselines/{agent_id}.json")

    # 5. Write GitHub Actions workflow
    workflows_dir = project_path / ".github" / "workflows"
    workflows_dir.mkdir(parents=True, exist_ok=True)
    workflow_path = workflows_dir / "ai-baseline.yml"
    workflow_path.write_text(GITHUB_WORKFLOW_TEMPLATE.format(agent_script=agent_filename))
    console.print("[green]✓[/green] Created CI workflow: .github/workflows/ai-baseline.yml")

    approve_path = workflows_dir / "spooled-approve-variant.yml"
    approve_path.write_text(ACCEPT_VARIANT_WORKFLOW_TEMPLATE)
    console.print(
        "[green]✓[/green] Created approve-variant workflow: .github/workflows/spooled-approve-variant.yml"
    )

    # Show next steps
    console.print()
    console.print(
        Panel.fit(
            "[bold green]✓ Demo scaffolded successfully![/bold green]\n\n"
            "[bold]What was created:[/bold]\n"
            f"  {agent_filename}              Demo agent (3-step: classify -> route -> respond)\n"
            "  spooled-policy.yml          Policy (blocks new side effects)\n"
            f"  baselines/{agent_id}.json         Golden baseline\n"
            "  .github/workflows/ai-baseline.yml  CI workflow\n\n"
            "[bold]Try it now:[/bold]\n"
            f"  1. Re-run the agent:    [cyan]python {agent_filename}[/cyan]\n"
            f"  2. Compare to baseline: [cyan]spooled ci compare .spooled/traces/{trace_file.name} --baseline baselines/[/cyan]\n"
            f"  3. Break it on purpose: paste this before [cyan]spooled.shutdown()[/cyan] in {agent_filename}:\n"
            "     [cyan]recorder.record_interaction(\n"
            "         interaction_type=InteractionType.TOOL_CALL,\n"
            '         input_data={"function": "send_email", "args": {"to": "admin"}},\n'
            '         output_data={"sent": True},\n'
            "     )[/cyan]\n"
            "     Then re-run and compare to see the drift!\n"
            "  4. Commit & push:       [cyan]git add -A && git commit -m 'Add Spooled CI'[/cyan]\n\n"
            "[dim]See docs/QUICKSTART.md for a full walkthrough[/dim]",
            title="Demo Ready",
            border_style="green",
        )
    )

    console.print()
    console.print(
        Panel.fit(
            "[bold]To monitor your real agent:[/bold]\n\n"
            "  1. Add [cyan]spooled.init()[/cyan] as the first line of your agent script\n"
            "  2. Run your agent (traces auto-captured to .spooled/traces/)\n"
            "  3. [cyan]spooled ci update-baseline --out baselines/[/cyan]\n"
            "  4. [cyan]git add baselines/ && git commit -m 'Add AI baselines'[/cyan]\n\n"
            "Run [cyan]spooled doctor[/cyan] to check setup at any time.",
            title="Real agent path",
            border_style="cyan",
        )
    )
