"""Admin commands to manage API keys."""

from __future__ import annotations

import os

import structlog
import typer
from dotenv import load_dotenv
from rich.console import Console
from rich.table import Table

# Load .env file if it exists
load_dotenv()

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="keys", help="Manage API keys (admin) via the backend")


def _get_backend_url(backend_url: str | None) -> str:
    return backend_url or os.getenv("SPOOLED_BACKEND_URL", "https://api.spooled.ai")


def _get_admin_key(admin_key: str | None) -> str:
    return admin_key or os.getenv("SPOOLED_ADMIN_API_KEY", "")


@app.command()
def create(
    org_id: str = typer.Option(..., "--org-id", help="Organization identifier"),
    name: str = typer.Option("", "--name", help="Optional key name"),
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend API URL (overrides env var)"
    ),
    admin_key: str | None = typer.Option(
        None, "--admin-key", help="Admin API key (overrides env var)"
    ),
) -> None:
    """Create an API key for an org."""
    try:
        try:
            import httpx
        except ImportError:
            console.print("[yellow]⚠[/yellow] httpx not installed, cannot manage keys")
            console.print("Install with: pip install httpx")
            raise typer.Exit(code=1)

        url = _get_backend_url(backend_url)
        key = _get_admin_key(admin_key)
        if not key:
            console.print(
                "[red]✗[/red] Missing admin key (set SPOOLED_ADMIN_API_KEY or --admin-key)"
            )
            raise typer.Exit(code=1)

        api_url = f"{url.rstrip('/')}/api/admin/keys"
        headers = {"Content-Type": "application/json", "X-Admin-Key": key}

        with httpx.Client(timeout=30.0) as client:
            response = client.post(api_url, json={"org_id": org_id, "name": name}, headers=headers)
            response.raise_for_status()
            data = response.json()

        console.print("[green]✓[/green] API key created")
        console.print(f"org_id: {data.get('org_id')}")
        console.print(f"key_id: {data.get('key_id')}")
        if data.get("name"):
            console.print(f"name: {data.get('name')}")
        console.print(f"created_at: {data.get('created_at')}")
        console.print("api_key:")
        console.print(data.get("api_key"))
    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to create API key", error=str(e))
        console.print(f"[red]✗[/red] Failed to create API key: {str(e)}")
        raise typer.Exit(code=1)


@app.command()
def revoke(
    key_id: str | None = typer.Option(None, "--key-id", help="Key ID to revoke"),
    api_key: str | None = typer.Option(None, "--api-key", help="Raw API key to revoke"),
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend API URL (overrides env var)"
    ),
    admin_key: str | None = typer.Option(
        None, "--admin-key", help="Admin API key (overrides env var)"
    ),
) -> None:
    """Revoke an API key by key_id or api_key."""
    if not key_id and not api_key:
        console.print("[red]✗[/red] Provide --key-id or --api-key")
        raise typer.Exit(code=1)

    try:
        try:
            import httpx
        except ImportError:
            console.print("[yellow]⚠[/yellow] httpx not installed, cannot manage keys")
            console.print("Install with: pip install httpx")
            raise typer.Exit(code=1)

        url = _get_backend_url(backend_url)
        key = _get_admin_key(admin_key)
        if not key:
            console.print(
                "[red]✗[/red] Missing admin key (set SPOOLED_ADMIN_API_KEY or --admin-key)"
            )
            raise typer.Exit(code=1)

        api_url = f"{url.rstrip('/')}/api/admin/keys/revoke"
        headers = {"Content-Type": "application/json", "X-Admin-Key": key}
        payload = {"key_id": key_id, "api_key": api_key}

        with httpx.Client(timeout=30.0) as client:
            response = client.post(api_url, json=payload, headers=headers)
            response.raise_for_status()
            data = response.json()

        console.print("[green]✓[/green] API key revoked")
        console.print(f"key_id: {data.get('key_id')}")
    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to revoke API key", error=str(e))
        console.print(f"[red]✗[/red] Failed to revoke API key: {str(e)}")
        raise typer.Exit(code=1)


@app.command("list")
def list_keys(
    org_id: str = typer.Option(..., "--org-id", help="Organization identifier"),
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend API URL (overrides env var)"
    ),
    admin_key: str | None = typer.Option(
        None, "--admin-key", help="Admin API key (overrides env var)"
    ),
) -> None:
    """List API keys for an org."""
    try:
        try:
            import httpx
        except ImportError:
            console.print("[yellow]⚠[/yellow] httpx not installed, cannot manage keys")
            console.print("Install with: pip install httpx")
            raise typer.Exit(code=1)

        url = _get_backend_url(backend_url)
        key = _get_admin_key(admin_key)
        if not key:
            console.print(
                "[red]✗[/red] Missing admin key (set SPOOLED_ADMIN_API_KEY or --admin-key)"
            )
            raise typer.Exit(code=1)

        api_url = f"{url.rstrip('/')}/api/admin/keys"
        headers = {"X-Admin-Key": key}

        with httpx.Client(timeout=30.0) as client:
            response = client.get(api_url, params={"org_id": org_id}, headers=headers)
            response.raise_for_status()
            data = response.json()

        records = data.get("keys", [])
        if not records:
            console.print("No API keys found.")
            return

        table = Table(title=f"API Keys for {org_id}")
        table.add_column("Key ID")
        table.add_column("Name")
        table.add_column("Status")
        table.add_column("Created")
        table.add_column("Revoked")

        for record in records:
            table.add_row(
                str(record.get("key_id", "")),
                str(record.get("name", "")),
                str(record.get("status", "")),
                str(record.get("created_at", "")),
                str(record.get("revoked_at", "")),
            )

        console.print(table)
    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to list API keys", error=str(e))
        console.print(f"[red]✗[/red] Failed to list API keys: {str(e)}")
        raise typer.Exit(code=1)


@app.command("delete-org")
def delete_org(
    org_id: str = typer.Option(..., "--org-id", help="Organization identifier"),
    yes: bool = typer.Option(False, "--yes", help="Confirm deletion"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be deleted"),
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend API URL (overrides env var)"
    ),
    admin_key: str | None = typer.Option(
        None, "--admin-key", help="Admin API key (overrides env var)"
    ),
) -> None:
    """Delete all data for an org (irreversible)."""
    if not dry_run and not yes:
        console.print("[red]✗[/red] Deletion requires --yes confirmation")
        raise typer.Exit(code=1)

    try:
        try:
            import httpx
        except ImportError:
            console.print("[yellow]⚠[/yellow] httpx not installed, cannot manage keys")
            console.print("Install with: pip install httpx")
            raise typer.Exit(code=1)

        url = _get_backend_url(backend_url)
        key = _get_admin_key(admin_key)
        if not key:
            console.print(
                "[red]✗[/red] Missing admin key (set SPOOLED_ADMIN_API_KEY or --admin-key)"
            )
            raise typer.Exit(code=1)

        api_url = f"{url.rstrip('/')}/api/admin/orgs/{org_id}/delete"
        headers = {"Content-Type": "application/json", "X-Admin-Key": key}
        payload: dict[str, bool] = {}
        if dry_run:
            payload["dry_run"] = True
        else:
            payload["confirm"] = True

        with httpx.Client(timeout=60.0) as client:
            response = client.post(api_url, json=payload, headers=headers)
            response.raise_for_status()
            data = response.json()

        if data.get("dry_run"):
            console.print("[green]✓[/green] Dry run complete")
            console.print(f"org_id: {data.get('org_id')}")
            console.print(f"traces_count: {data.get('traces_count')}")
            console.print(f"interactions_count: {data.get('interactions_count')}")
            console.print(f"baselines_count: {data.get('baselines_count')}")
            console.print(f"api_keys_count: {data.get('api_keys_count')}")
        else:
            console.print("[green]✓[/green] Org data deleted")
            console.print(f"org_id: {data.get('org_id')}")
            console.print(f"traces_deleted: {data.get('traces_deleted')}")
            console.print(f"interactions_deleted: {data.get('interactions_deleted')}")
            console.print(f"baselines_deleted: {data.get('baselines_deleted')}")
            console.print(f"api_keys_deleted: {data.get('api_keys_deleted')}")
    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to delete org", error=str(e))
        console.print(f"[red]✗[/red] Failed to delete org: {str(e)}")
        raise typer.Exit(code=1)
