"""Command to generate and export behavioral fingerprints."""

from __future__ import annotations

from pathlib import Path

import structlog
import typer
from rich.console import Console
from rich.json import JSON
from rich.table import Table

from cli.utils import resolve_trace_path
from spooled.fingerprint import BehavioralFingerprint
from spooled.storage import load_trace_from_jsonl

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="fingerprint", help="Generate and export behavioral fingerprints")


@app.command()
def generate(
    trace_file: str = typer.Argument(..., help="Path to trace file or run_id"),
    output: Path | None = typer.Option(
        None, "--output", "-o", help="Output file path (JSON format)"
    ),
    format: str = typer.Option(
        "table", "--format", "-f", help="Output format: table, json, markdown"
    ),
) -> None:
    """Generate a behavioral fingerprint from a trace.

    Example:
       spooled fingerprint generate .spooled/traces/run-123.jsonl
       spooled fingerprint generate abc-123-def
       spooled fingerprint generate .spooled/traces/run-123.jsonl --output fp.json --format json
    """
    try:
        resolved = resolve_trace_path(trace_file)
        if resolved is None:
            console.print(f"[red]✗[/red] Trace file not found: {trace_file}")
            raise typer.Exit(code=1)
        trace_file = resolved

        # Load trace
        if trace_file.suffix == ".jsonl":
            trace_data = load_trace_from_jsonl(trace_file)
        else:
            import json

            with open(trace_file) as f:
                trace_data = json.load(f)

        # Generate fingerprint
        fingerprint = BehavioralFingerprint(trace_data)
        fp_data = fingerprint.generate()

        # Display or save
        import json

        if format == "json":
            output_data = json.dumps(fp_data, indent=2)
            if output:
                with open(output, "w") as f:
                    f.write(output_data)
                console.print(f"[green]✓[/green] Fingerprint saved to: {output}")
            else:
                console.print(JSON(output_data))
        elif format == "markdown":
            markdown = _format_fingerprint_markdown(fp_data, trace_data)
            if output:
                with open(output, "w") as f:
                    f.write(markdown)
                console.print(f"[green]✓[/green] Fingerprint saved to: {output}")
            else:
                console.print(markdown)
        else:  # table format
            _display_fingerprint_table(fp_data)
            if output:
                import json

                with open(output, "w") as f:
                    json.dump(fp_data, f, indent=2)
                console.print(f"[green]✓[/green] Fingerprint saved to: {output}")

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to generate fingerprint", error=str(e))
        console.print(f"[red]✗[/red] Failed to generate fingerprint: {str(e)}")
        raise typer.Exit(code=1)


def _display_fingerprint_table(fp_data: dict) -> None:
    """Display fingerprint as a table.

    Args:
        fp_data: Fingerprint data dictionary
    """
    console.print("\n[bold]Behavioral Fingerprint[/bold]\n")

    # Interaction sequence
    seq = fp_data.get("interaction_sequence", [])
    console.print(f"[cyan]Interaction Sequence:[/cyan] {' → '.join(seq)}")
    console.print(f"  Total interactions: {len(seq)}\n")

    # Tool graph
    tool_graph = fp_data.get("tool_graph", {})
    tools = tool_graph.get("unique_tools", [])
    tool_seq = tool_graph.get("sequence", [])

    if tools:
        console.print("[cyan]Tool Usage:[/cyan]")
        console.print(f"  Unique tools: {', '.join(tools)}")
        console.print(f"  Tool sequence: {' → '.join(tool_seq) if tool_seq else 'None'}")
        console.print(f"  Total tool calls: {tool_graph.get('tool_count', 0)}\n")

    # Interaction types
    types = fp_data.get("interaction_types", {})
    if types:
        table = Table(title="Interaction Types")
        table.add_column("Type", style="cyan")
        table.add_column("Count", style="green")
        for itype, count in types.items():
            table.add_row(itype, str(count))
        console.print(table)
        console.print()

    # Branch paths
    branches = fp_data.get("branch_paths", [])
    if branches:
        console.print(f"[cyan]Branch Paths:[/cyan] {len(branches)}")
        for branch in branches[:5]:  # Show first 5
            branch_type = branch.get("type", "unknown")
            seq_num = branch.get("sequence", "?")
            console.print(f"  [{seq_num}] {branch_type}")
        if len(branches) > 5:
            console.print(f"  ... and {len(branches) - 5} more\n")

    # Error patterns
    errors = fp_data.get("error_patterns", {})
    if errors.get("has_errors"):
        console.print(f"[yellow]⚠ Errors:[/yellow] {errors.get('error_count', 0)}")
        error_types = errors.get("error_types", [])
        if error_types:
            console.print(f"  Error types: {', '.join(error_types)}")
        console.print()

    # Metadata patterns
    metadata = fp_data.get("metadata_patterns", {})
    if metadata:
        console.print("[cyan]Performance Metrics:[/cyan]")
        if "latency" in metadata:
            lat = metadata["latency"]
            console.print(
                f"  Latency: avg={lat.get('avg', 0):.2f}ms, min={lat.get('min', 0):.2f}ms, max={lat.get('max', 0):.2f}ms"
            )
        if "tokens" in metadata:
            tokens = metadata["tokens"]
            console.print(
                f"  Tokens: total={tokens.get('total', 0)}, avg={tokens.get('avg', 0):.2f}"
            )


def _format_fingerprint_markdown(fp_data: dict, trace_data: dict) -> str:
    """Format fingerprint as Markdown.

    Args:
        fp_data: Fingerprint data dictionary
        trace_data: Original trace data

    Returns:
        Markdown formatted string
    """
    lines = []
    lines.append("# Behavioral Fingerprint")
    lines.append("")

    trace_info = trace_data.get("trace", {})
    lines.append(f"**Run ID:** `{trace_info.get('run_id', 'unknown')}`")
    lines.append(f"**Agent ID:** `{trace_info.get('agent_id', 'unknown')}`")
    lines.append(f"**Status:** `{trace_info.get('status', 'unknown')}`")
    lines.append("")

    # Interaction sequence
    seq = fp_data.get("interaction_sequence", [])
    lines.append("## Interaction Sequence")
    lines.append(f"Total interactions: {len(seq)}")
    lines.append("")
    lines.append("```")
    lines.append(" → ".join(seq))
    lines.append("```")
    lines.append("")

    # Tool graph
    tool_graph = fp_data.get("tool_graph", {})
    if tool_graph.get("unique_tools"):
        lines.append("## Tool Usage")
        lines.append(f"Unique tools: {len(tool_graph.get('unique_tools', []))}")
        lines.append(f"Total tool calls: {tool_graph.get('tool_count', 0)}")
        lines.append("")
        lines.append("### Tool Sequence")
        lines.append("```")
        lines.append(" → ".join(tool_graph.get("sequence", [])))
        lines.append("```")
        lines.append("")

    # Interaction types
    types = fp_data.get("interaction_types", {})
    if types:
        lines.append("## Interaction Types")
        lines.append("")
        lines.append("| Type | Count |")
        lines.append("|------|-------|")
        for itype, count in types.items():
            lines.append(f"| {itype} | {count} |")
        lines.append("")

    # Error patterns
    errors = fp_data.get("error_patterns", {})
    if errors.get("has_errors"):
        lines.append("## Error Patterns")
        lines.append(f"Error count: {errors.get('error_count', 0)}")
        error_types = errors.get("error_types", [])
        if error_types:
            lines.append(f"Error types: {', '.join(error_types)}")
        lines.append("")

    return "\n".join(lines)
