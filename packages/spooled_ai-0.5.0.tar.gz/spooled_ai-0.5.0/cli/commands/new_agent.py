"""Scaffold Spooled integration for a new agent."""

from __future__ import annotations

from pathlib import Path

import structlog
import typer
from rich.console import Console
from rich.panel import Panel

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="new-agent", help="Scaffold Spooled integration for a new agent")


# Template for the agent wrapper snippet
_AGENT_TEMPLATE = '''\
"""Agent: {agent_id}

Instrumented with Spooled for behavioral tracking.
Run this to generate traces, then build baselines with:

    spooled ci update-baseline --out .github/baselines/

"""

import spooled
from spooled.models import InteractionType

# ─── Your agent code below ───────────────────────────────────────────────
# Replace this with your actual agent logic.
# Spooled auto-captures OpenAI, Anthropic, requests, and httpx calls.

from openai import OpenAI

client = OpenAI()


{decorator_line}
def run():
    recorder = spooled.get_recorder()
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {{"role": "system", "content": "You are a helpful assistant."}},
            {{"role": "user", "content": "Hello!"}},
        ],
    )
    print(response.choices[0].message.content)


if __name__ == "__main__":
    run()
'''


_POLICY_TEMPLATE = """\
# Spooled Policy for {agent_id}
# See: https://spooled.ai/docs/policy

name: "{agent_id}_policy"
enabled: true
block_merges: true

rules:
  - name: "structural_safety"
    description: "Block on new side effects or tools"
    severity: "high"
    fail_if:
      new_side_effects: true
      new_tools: true
      retry_explosion:
        threshold: 5

  - name: "metric_drift"
    description: "Warn on metric changes"
    severity: "medium"
    warn_if:
      latency_spike:
        threshold_percent: 50.0
      token_usage_spike:
        threshold_percent: 50.0
      on_variant:
        min_similarity: 0.85
"""


_MAKEFILE_TARGETS = """\

# ─── Spooled targets for {agent_id} ─────────────────────────────────────

.PHONY: trace-{agent_id} baseline-{agent_id} ci-{agent_id}

trace-{agent_id}:  ## Run {agent_id} and capture a trace
\tpython {agent_file}

baseline-{agent_id}:  ## Rebuild baseline for {agent_id}
\tspooled ci update-baseline --from .spooled/traces/ --out .github/baselines/ --agent-id {agent_id}

ci-{agent_id}:  ## Run CI comparison for {agent_id}
\tspooled ci compare $$(ls -t .spooled/traces/*.jsonl | head -1) --baseline .github/baselines/ --policy {policy_file}
"""


@app.command()
def scaffold(
    agent_id: str = typer.Argument(..., help="Agent identifier (e.g., 'payment_processor')"),
    output_dir: Path = typer.Option(Path("."), "--dir", "-d", help="Directory to create files in"),
    tags: list[str] | None = typer.Option(
        None, "--tag", "-t", help="Tags for fleet grouping (repeatable)"
    ),
    policy: str = typer.Option(
        "moderate", "--policy", "-p", help="Policy template: strict, moderate, permissive"
    ),
    with_agent_file: bool = typer.Option(
        True, "--agent-file/--no-agent-file", help="Generate agent template file"
    ),
    with_makefile: bool = typer.Option(False, "--makefile", help="Append Makefile targets"),
) -> None:
    """Scaffold Spooled integration for a new agent.

    Creates:
    - Agent template file with @spooled.trace decorator pre-wired
    - Per-agent policy file
    - Baselines directory
    - Optional Makefile targets

    Example:
       spooled new-agent scaffold my_agent
       spooled new-agent scaffold payment_processor --tag payments --tag v2
       spooled new-agent scaffold code_reviewer --policy strict --makefile
    """
    try:
        output_path = Path(output_dir).resolve()

        if not output_path.exists():
            console.print(f"[red]x[/red] Directory does not exist: {output_path}")
            raise typer.Exit(code=1)

        created_files = []

        # Build decorator line with tags
        if tags:
            tags_str = ", ".join(f'"{t}"' for t in tags)
            decorator_line = f'@spooled.trace(agent_id="{agent_id}", tags=[{tags_str}])'
        else:
            decorator_line = f'@spooled.trace(agent_id="{agent_id}")'

        # 1. Agent template file
        agent_file = f"agents/{agent_id}.py"
        if with_agent_file:
            agent_path = output_path / agent_file
            if agent_path.exists():
                console.print(
                    f"[yellow]![/yellow] Agent file already exists: {agent_file} (skipping)"
                )
            else:
                agent_path.parent.mkdir(parents=True, exist_ok=True)
                agent_path.write_text(
                    _AGENT_TEMPLATE.format(agent_id=agent_id, decorator_line=decorator_line)
                )
                created_files.append(agent_file)
                console.print(f"[green]v[/green] Created agent: {agent_file}")

        # 2. Policy file
        policy_file = f"policies/{agent_id}_policy.yml"
        policy_path = output_path / policy_file

        if policy_path.exists():
            console.print(f"[yellow]![/yellow] Policy already exists: {policy_file} (skipping)")
        else:
            if policy in ("strict", "moderate", "permissive"):
                from cli.templates.policy_templates import get_template

                policy_content = get_template(policy)
                # Replace the generic name with agent-specific name
                policy_content = policy_content.replace(
                    f'name: "{policy}_policy"',
                    f'name: "{agent_id}_policy"',
                )
            else:
                policy_content = _POLICY_TEMPLATE.format(agent_id=agent_id)

            policy_path.parent.mkdir(parents=True, exist_ok=True)
            policy_path.write_text(policy_content)
            created_files.append(policy_file)
            console.print(f"[green]v[/green] Created policy: {policy_file}")

        # 3. Baselines directory (.github/baselines/ for CI/CD convention)
        baselines_dir = output_path / ".github" / "baselines"
        if not baselines_dir.exists():
            baselines_dir.mkdir(parents=True, exist_ok=True)
            created_files.append(".github/baselines/")
            console.print("[green]v[/green] Created directory: .github/baselines/")

        # 4. Ensure .spooled/traces/ exists
        traces_dir = output_path / ".spooled" / "traces"
        if not traces_dir.exists():
            traces_dir.mkdir(parents=True, exist_ok=True)
            console.print("[green]v[/green] Created directory: .spooled/traces/")

        # 5. Makefile targets (optional)
        if with_makefile:
            makefile_path = output_path / "Makefile"
            targets = _MAKEFILE_TARGETS.format(
                agent_id=agent_id,
                agent_file=agent_file,
                policy_file=policy_file,
            )

            if makefile_path.exists():
                existing = makefile_path.read_text()
                if f"trace-{agent_id}" in existing:
                    console.print(f"[yellow]![/yellow] Makefile already has targets for {agent_id}")
                else:
                    with open(makefile_path, "a") as f:
                        f.write(targets)
                    console.print(f"[green]v[/green] Appended Makefile targets for {agent_id}")
            else:
                makefile_path.write_text(targets.lstrip("\n"))
                created_files.append("Makefile")
                console.print(f"[green]v[/green] Created Makefile with targets for {agent_id}")

        # Summary
        if not created_files:
            console.print(f"\n[yellow]All files already exist for {agent_id}[/yellow]")
            return

        console.print()
        console.print(
            Panel.fit(
                f"[bold green]Agent '{agent_id}' scaffolded[/bold green]\n\n"
                "[bold]Next steps:[/bold]\n"
                f"1. Edit [cyan]{agent_file}[/cyan] with your agent logic\n"
                f"2. Run it:         [cyan]python {agent_file}[/cyan]\n"
                "3. Build baseline: [cyan]spooled ci update-baseline --out .github/baselines/[/cyan]\n"
                f"4. Test CI:        [cyan]spooled ci compare <trace> --baseline .github/baselines/ "
                f"--policy {policy_file}[/cyan]\n"
                "5. Commit:         [cyan]git add .github/baselines/ " + policy_file + "[/cyan]",
                title="Ready",
                border_style="green",
            )
        )

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("new-agent scaffold failed", error=str(e))
        console.print(f"[red]x[/red] Failed: {e}")
        raise typer.Exit(code=1)
