"""Fleet management commands for multi-agent teams.

Commands:
    status  - One-line-per-agent overview of all agents
    report  - Aggregate PR report with collapsible per-agent sections
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import structlog
import typer
from rich.console import Console
from rich.table import Table

from spooled.baseline import load_baseline_from_path
from spooled.storage import get_trace_directory

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="fleet", help="Fleet-level agent management")

# Sentinel used to detect when --baseline-dir is not explicitly provided.
_BASELINE_DIR_SENTINEL = Path("__sentinel__")


def _resolve_baseline_dir(baseline_dir: Path) -> Path:
    """Resolve the baseline directory with smart defaults.

    If the caller passed an explicit --baseline-dir, use it as-is.
    Otherwise, prefer ``.github/baselines/`` when it exists and contains
    JSON files, falling back to ``baselines/``.
    """
    if baseline_dir != _BASELINE_DIR_SENTINEL:
        return baseline_dir

    gh_dir = Path(".github/baselines")
    if gh_dir.exists() and list(gh_dir.glob("*.json")):
        return gh_dir

    return Path("baselines")


def _find_agent_policy(agent_id: str) -> Path | None:
    """Try to find a per-agent policy file.

    Checks common conventions:
        agents/{agent_id}_policy.yml
        policies/{agent_id}_policy.yml
        policies/{agent_id}.yml
    """
    cwd = Path.cwd()
    for pattern in [
        cwd / "agents" / f"{agent_id}_policy.yml",
        cwd / "agents" / f"{agent_id}_policy.yaml",
        cwd / "policies" / f"{agent_id}_policy.yml",
        cwd / "policies" / f"{agent_id}_policy.yaml",
        cwd / "policies" / f"{agent_id}.yml",
        cwd / "policies" / f"{agent_id}.yaml",
    ]:
        if pattern.exists():
            return pattern
    return None


def _find_baseline_files(baseline_dir: Path) -> list[Path]:
    """Find all baseline JSON files in a directory."""
    if not baseline_dir.exists():
        return []
    return sorted(baseline_dir.glob("*.json"))


def _load_tags_from_summary(path: Path) -> list[str]:
    """Load tags from a baseline summary file without full parsing."""
    try:
        with open(path) as f:
            data = json.load(f)
        return data.get("tags", [])
    except Exception:
        return []


def _matches_group(agent_id: str, tags: list[str], group: str) -> bool:
    """Check if an agent matches a group filter.

    Matches against tags first (exact match), then falls back to
    substring matching on agent_id for backward compatibility.
    """
    group_lower = group.lower()
    # Exact tag match
    if any(t.lower() == group_lower for t in tags):
        return True
    # Substring match on agent_id (backward compat)
    return group_lower in agent_id.lower()


def _find_latest_trace_for_agent(trace_dir: Path, agent_id: str) -> Path | None:
    """Find the most recent trace file for a given agent."""
    candidates = []
    for f in trace_dir.glob("*.jsonl"):
        try:
            with open(f) as fh:
                for line in fh:
                    data = json.loads(line)
                    if data.get("type") == "trace" and data.get("agent_id") == agent_id:
                        candidates.append(f)
                    break  # only read first line
        except Exception:
            continue
    if not candidates:
        return None
    return max(candidates, key=lambda p: p.stat().st_mtime)


@app.command()
def status(
    baseline_dir: Path = typer.Option(
        _BASELINE_DIR_SENTINEL,
        "--baseline-dir",
        "-b",
        help="Directory containing baseline files (default: .github/baselines/ or baselines/)",
    ),
    trace_dir: Path | None = typer.Option(
        None, "--trace-dir", help="Trace directory (default: .spooled/traces/)"
    ),
    group: str | None = typer.Option(None, "--group", "-g", help="Filter by agent group tag"),
) -> None:
    """Show one-line status for every agent in the fleet.

    Reads baseline files to list all known agents with their intent count,
    sample count, latest score, and status.

    Example:
       spooled fleet status
       spooled fleet status --baseline-dir .github/baselines/
    """
    baseline_dir = _resolve_baseline_dir(baseline_dir)
    baseline_files = _find_baseline_files(baseline_dir)

    if not baseline_files:
        console.print(f"[red]✗[/red] No baseline files found in: {baseline_dir}")
        console.print("\n[dim]Generate baselines first:[/dim]")
        console.print(f"  spooled ci update-baseline --out {baseline_dir}/")
        raise typer.Exit(code=1)

    trace_dir or get_trace_directory()

    table = Table(title="Fleet Status", show_lines=False)
    table.add_column("Agent", style="cyan", no_wrap=True)
    table.add_column("Tags", style="dim")
    table.add_column("Intents", justify="right")
    table.add_column("Runs", justify="right")
    table.add_column("Avg Latency", justify="right")
    table.add_column("Avg Tokens", justify="right")
    table.add_column("Error Rate", justify="right")
    table.add_column("Status", justify="center")

    agent_count = 0
    total_intents = 0

    for bf in baseline_files:
        agent_id = bf.stem
        agent_tags = _load_tags_from_summary(bf)
        if group:
            if not _matches_group(agent_id, agent_tags, group):
                continue

        try:
            baseline = load_baseline_from_path(bf, agent_id)
        except Exception as e:
            logger.debug("Failed to load baseline", path=str(bf), error=str(e))
            tags_str = ", ".join(agent_tags) if agent_tags else ""
            table.add_row(agent_id, tags_str, "-", "-", "-", "-", "-", "[red]ERROR[/red]")
            continue

        if not baseline or not baseline.intents:
            tags_str = ", ".join(agent_tags) if agent_tags else ""
            table.add_row(agent_id, tags_str, "0", "0", "-", "-", "-", "[dim]empty[/dim]")
            continue

        intent_count = len(baseline.intents)
        total_runs = sum(
            getattr(s, "sample_count", 0) or len(getattr(s, "runs", []))
            for s in baseline.intents.values()
        )

        # Aggregate metrics across intents
        latencies = [s.avg_latency for s in baseline.intents.values() if s.avg_latency > 0]
        tokens = [s.avg_tokens for s in baseline.intents.values() if s.avg_tokens > 0]
        error_rates = [s.error_rate for s in baseline.intents.values()]

        avg_lat = f"{sum(latencies) / len(latencies):.0f}ms" if latencies else "-"
        avg_tok = f"{sum(tokens) / len(tokens):.0f}" if tokens else "-"
        avg_err = f"{sum(error_rates) / len(error_rates):.0%}" if error_rates else "-"

        # Determine status from error rate
        max_err = max(error_rates) if error_rates else 0
        if max_err > 0.5:
            status_str = "[red]DEGRADED[/red]"
        elif max_err > 0.1:
            status_str = "[yellow]WARN[/yellow]"
        else:
            status_str = "[green]HEALTHY[/green]"

        tags_str = ", ".join(agent_tags) if agent_tags else ""
        table.add_row(
            agent_id,
            tags_str,
            str(intent_count),
            str(total_runs),
            avg_lat,
            avg_tok,
            avg_err,
            status_str,
        )
        agent_count += 1
        total_intents += intent_count

    console.print(table)
    console.print(f"\n[dim]{agent_count} agents, {total_intents} total intents[/dim]")


@app.command()
def report(
    baseline_dir: Path = typer.Option(
        _BASELINE_DIR_SENTINEL,
        "--baseline-dir",
        "-b",
        help="Directory containing baseline files (default: .github/baselines/ or baselines/)",
    ),
    trace_dir: Path | None = typer.Option(
        None, "--trace-dir", help="Trace directory (default: .spooled/traces/)"
    ),
    output: Path | None = typer.Option(
        None, "--output", "-o", help="Output file (default: stdout)"
    ),
    policy_file: Path | None = typer.Option(
        None, "--policy", "-p", help="Policy file for evaluation"
    ),
    group: str | None = typer.Option(None, "--group", "-g", help="Filter by agent group tag"),
) -> None:
    """Generate an aggregate fleet report comparing all agents against baselines.

    Runs comparison for every agent that has both a baseline and recent traces,
    then outputs a single markdown report with a summary table and collapsible
    per-agent details.

    Example:
       spooled fleet report
       spooled fleet report --baseline-dir .github/baselines/ -o fleet-report.md
    """
    baseline_dir = _resolve_baseline_dir(baseline_dir)

    from cli.commands.ci import _compute_comparison, _find_all_traces, _load_trace
    from spooled.policy import PolicyEngine

    tdir = trace_dir or get_trace_directory()
    if not tdir.exists():
        console.print(f"[red]✗[/red] Trace directory not found: {tdir}")
        raise typer.Exit(code=1)

    baseline_files = _find_baseline_files(baseline_dir)
    if not baseline_files:
        console.print(f"[red]✗[/red] No baseline files found in: {baseline_dir}")
        raise typer.Exit(code=1)

    # Global policy (if --policy given), else auto-discover per-agent below
    global_policy_engine = PolicyEngine(policy_file) if policy_file else None

    # Find all traces and group by agent
    all_traces = _find_all_traces(tdir)
    traces_by_agent: dict[str, list[Path]] = {}
    for tf in all_traces:
        try:
            trace_data = _load_trace(tf)
            aid = trace_data.get("trace", {}).get("agent_id", "unknown")
            traces_by_agent.setdefault(aid, []).append(tf)
        except Exception:
            continue

    # Build set of agents to report on (intersection of baselines and traces)
    baseline_agents = {bf.stem: bf for bf in baseline_files}
    report_agents = []
    for aid, bf in baseline_agents.items():
        if group:
            agent_tags = _load_tags_from_summary(bf)
            if not _matches_group(aid, agent_tags, group):
                continue
        report_agents.append(aid)

    if not report_agents:
        console.print("[yellow]No agents match the filter criteria[/yellow]")
        raise typer.Exit(code=1)

    # Run comparisons per agent
    agent_results: dict[str, dict[str, Any]] = {}
    all_results: list[dict[str, Any]] = []

    with console.status("[bold]Comparing agents against baselines..."):
        for aid in sorted(report_agents):
            bf = baseline_agents[aid]
            agent_traces = traces_by_agent.get(aid, [])

            try:
                baseline_data = load_baseline_from_path(bf, aid)
            except Exception as e:
                agent_results[aid] = {"error": str(e), "results": []}
                continue

            if not agent_traces:
                agent_results[aid] = {"error": None, "results": [], "no_traces": True}
                continue

            # Resolve policy: global flag > per-agent file > None
            agent_policy = global_policy_engine
            if not agent_policy:
                agent_policy_path = _find_agent_policy(aid)
                if agent_policy_path:
                    try:
                        agent_policy = PolicyEngine(agent_policy_path)
                    except Exception:
                        pass  # skip invalid policy files

            # Compare each trace for this agent
            results = []
            for tf in agent_traces:
                try:
                    trace_data = _load_trace(tf)
                    result = _compute_comparison(
                        trace_data, baseline_data, aid, policy_engine=agent_policy
                    )
                    result["trace_file"] = str(tf)
                    results.append(result)
                    all_results.append(result)
                except Exception as e:
                    logger.debug("Comparison failed", agent=aid, trace=str(tf), error=str(e))

            agent_results[aid] = {"error": None, "results": results}

    # Build aggregate summary
    total_agents = len(report_agents)
    sum(1 for a in agent_results.values() if a.get("results"))
    total_traces = len(all_results)
    total_passed = sum(1 for r in all_results if r.get("fingerprint_match"))
    total_variants = sum(
        1 for r in all_results if r.get("fingerprint_status") in ("new", "variant")
    )
    total_blocked = sum(1 for r in all_results if r.get("summary", {}).get("should_block"))
    overall_pass = total_blocked == 0

    # Build markdown
    lines = _build_fleet_markdown(
        report_agents,
        agent_results,
        all_results,
        total_agents,
        total_traces,
        total_passed,
        total_variants,
        total_blocked,
        overall_pass,
        baseline_dir=str(baseline_dir),
    )

    markdown = "\n".join(lines)

    if output:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(markdown)
        console.print(f"[green]✓[/green] Fleet report written to {output}")
    else:
        console.print(markdown)

    # Print summary to stderr
    status_str = "[green]PASS[/green]" if overall_pass else "[red]FAIL[/red]"
    console.print(
        f"\n{status_str} — {total_agents} agents, {total_traces} traces, {total_passed} passed, {total_variants} variants, {total_blocked} blocked"
    )

    if not overall_pass:
        raise typer.Exit(code=1)


def _build_fleet_markdown(
    agents: list[str],
    agent_results: dict[str, dict[str, Any]],
    all_results: list[dict[str, Any]],
    total_agents: int,
    total_traces: int,
    total_passed: int,
    total_variants: int,
    total_blocked: int,
    overall_pass: bool,
    baseline_dir: str = "baselines",
) -> list[str]:
    """Build fleet-level markdown report with summary table and per-agent details."""
    from spooled.scoring import compute_agent_spooled_score

    lines: list[str] = []
    status_emoji = "\u2705" if overall_pass else "\u274c"
    badge = "PASS" if overall_pass else "FAIL"

    lines.append(f"## {status_emoji} Spooled Fleet Report: **{badge}**")
    lines.append("")
    parts = [f"**{total_agents}** agents"]
    parts.append(f"**{total_traces}** traces")
    if total_passed:
        parts.append(f"\u2705 **{total_passed}** passed")
    if total_variants:
        parts.append(f"\u26a0\ufe0f **{total_variants}** variants")
    if total_blocked:
        parts.append(f"\u274c **{total_blocked}** blocked")
    lines.append("  |  ".join(parts))
    lines.append("")

    # Summary table — one row per agent
    lines.append("### Agent Summary")
    lines.append("")
    lines.append("| Agent | Traces | Status | Score | Variants | Blocked |")
    lines.append("|-------|--------|--------|-------|----------|---------|")

    for aid in sorted(agents):
        ar = agent_results.get(aid, {})
        results = ar.get("results", [])

        if ar.get("error"):
            lines.append(f"| {aid} | - | \u274c Error | - | - | - |")
            continue
        if ar.get("no_traces"):
            lines.append(f"| {aid} | 0 | \u2796 No traces | - | - | - |")
            continue

        trace_count = len(results)
        passed = sum(1 for r in results if r.get("fingerprint_match"))
        variants = sum(1 for r in results if r.get("fingerprint_status") in ("new", "variant"))
        blocked = sum(1 for r in results if r.get("summary", {}).get("should_block"))

        # Compute per-agent score
        intent_scores = []
        for r in results:
            ss = r.get("spooled_score")
            if ss:
                intent_scores.append(
                    {
                        "score": ss.get("score"),
                        "confidence": ss.get("confidence", "low"),
                        "run_count": r.get("baseline_stats", {}).get("sample_count", 1),
                    }
                )
        agent_score = compute_agent_spooled_score(intent_scores)
        score_val = agent_score.get("score")
        score_str = f"{score_val}/100" if score_val is not None else "-"

        if blocked > 0:
            status_str = "\u274c FAIL"
        elif variants > 0:
            status_str = "\u26a0\ufe0f Variant"
        elif passed == trace_count:
            status_str = "\u2705 Pass"
        else:
            status_str = "\u2796 -"

        lines.append(
            f"| {aid} | {trace_count} | {status_str} | {score_str} | {variants} | {blocked} |"
        )

    lines.append("")

    # Per-agent details — collapsible sections
    for aid in sorted(agents):
        ar = agent_results.get(aid, {})
        results = ar.get("results", [])

        if not results:
            continue

        variants = sum(1 for r in results if r.get("fingerprint_status") in ("new", "variant"))
        blocked = sum(1 for r in results if r.get("summary", {}).get("should_block"))

        # Only expand sections with issues
        open_attr = " open" if (variants > 0 or blocked > 0) else ""
        lines.append(f"<details{open_attr}>")
        summary_parts = [f"**{aid}**"]
        if blocked > 0:
            summary_parts.append(f"\u274c {blocked} blocked")
        elif variants > 0:
            summary_parts.append(f"\u26a0\ufe0f {variants} variant(s)")
        else:
            summary_parts.append("\u2705 all passing")
        lines.append(f"<summary>{' — '.join(summary_parts)}</summary>")
        lines.append("")

        # Per-trace table for this agent
        lines.append("| Fingerprint | Status | Score | Signals | Tool Changes |")
        lines.append("|-------------|--------|-------|---------|--------------|")

        for r in results:
            fp = r.get("fingerprint_hash", "")[:12]
            fp_status = r.get("fingerprint_status", "unknown")
            status_icon = {
                "match": "\u2705 Pass",
                "accepted_variant": "\u2705 Pass",
                "new": "\U0001f7e1 New",
                "no_baseline": "\u2796 -",
                "variant": "\u26a0\ufe0f Variant",
            }.get(fp_status, fp_status)

            score = r.get("spooled_score", {}).get("score")
            score_str = str(score) if score is not None else "-"

            signal_count = r.get("summary", {}).get("signal_count", 0)
            signal_str = str(signal_count) if signal_count > 0 else "none"

            td = r.get("tool_diff")
            tool_str = "none"
            if td:
                parts = []
                if td.get("removed"):
                    parts.append(f"\u2796 {', '.join(f'`{t}`' for t in td['removed'])}")
                if td.get("added"):
                    parts.append(f"\u2795 {', '.join(f'`{t}`' for t in td['added'])}")
                if parts:
                    tool_str = " ".join(parts)

            lines.append(f"| `{fp}...` | {status_icon} | {score_str} | {signal_str} | {tool_str} |")

        lines.append("")
        lines.append("</details>")
        lines.append("")

    # Footer
    lines.append("---")
    lines.append("*[Spooled](https://spooled.ai) — CI for AI agents*")

    return lines
