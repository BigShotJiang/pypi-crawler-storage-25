"""Session commands for viewing multi-agent trace sessions.

Commands:
    list  - List all sessions found in local traces
    show  - Show detailed tree view of a session
"""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

import structlog
import typer
from rich.console import Console
from rich.table import Table
from rich.tree import Tree

from spooled.storage import get_trace_directory, load_session_traces, load_trace_from_jsonl

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="session", help="View multi-agent trace sessions")


@app.command("list")
def list_sessions(
    trace_dir: Path | None = typer.Option(
        None,
        "--trace-dir",
        "-t",
        help="Directory containing trace files (default: .spooled/traces)",
    ),
) -> None:
    """List all multi-agent sessions found in local traces.

    Scans trace files, groups by session_id, and displays a summary table.
    Only shows traces that have a session_id (standalone traces are excluded).

    Example:
       spooled session list
       spooled session list --trace-dir .spooled/traces
    """
    try:
        source_dir = trace_dir or get_trace_directory()
        if not source_dir.exists():
            console.print(f"[red]✗[/red] Trace directory not found: {source_dir}")
            raise typer.Exit(code=1)

        trace_files = list(source_dir.glob("*.jsonl"))
        if not trace_files:
            console.print(f"[red]✗[/red] No trace files found in: {source_dir}")
            raise typer.Exit(code=1)

        # Group by session_id
        sessions: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for tf in trace_files:
            try:
                data = load_trace_from_jsonl(tf)
                trace_meta = data.get("trace", {})
                session_id = trace_meta.get("session_id")
                if session_id:
                    sessions[session_id].append(trace_meta)
            except Exception:
                continue

        if not sessions:
            console.print("[dim]No multi-agent sessions found (all traces are standalone)[/dim]")
            raise typer.Exit(code=0)

        # Build table
        table = Table(title="Multi-Agent Sessions")
        table.add_column("Session (short)", style="cyan")
        table.add_column("Agents")
        table.add_column("Traces", justify="right")
        table.add_column("Status")
        table.add_column("Timestamp")

        for session_id, traces in sorted(sessions.items()):
            short_id = session_id[:8]
            agents = sorted({t.get("agent_id", "?") for t in traces})
            agent_str = ", ".join(agents[:3])
            if len(agents) > 3:
                agent_str += f".. (+{len(agents) - 3})"

            statuses = {t.get("status", "UNKNOWN") for t in traces}
            if all(s == "SUCCESS" for s in statuses):
                status_str = "[green]SUCCESS[/green]"
            elif "FAILURE" in statuses:
                status_str = "[red]FAILURE[/red]"
            elif "RUNNING" in statuses:
                status_str = "[yellow]RUNNING[/yellow]"
            else:
                status_str = ", ".join(statuses)

            timestamps = [t.get("timestamp", "") for t in traces if t.get("timestamp")]
            ts_str = min(timestamps)[:19] if timestamps else "-"

            table.add_row(short_id, agent_str, str(len(traces)), status_str, ts_str)

        console.print(table)
        console.print(f"\n[dim]{len(sessions)} session(s) found[/dim]")

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Session list failed", error=str(e))
        console.print(f"[red]✗[/red] Failed: {e}")
        raise typer.Exit(code=1)


@app.command("show")
def show_session(
    session_id: str = typer.Argument(..., help="Session ID (full or prefix)"),
    trace_dir: Path | None = typer.Option(
        None, "--trace-dir", "-t", help="Directory containing trace files"
    ),
    output_json: bool = typer.Option(False, "--json", help="Output machine-readable JSON"),
) -> None:
    """Show detailed tree view of a multi-agent session.

    Displays the parent/child hierarchy, interaction counts, and token usage
    for all traces in the session.

    Example:
       spooled session show a1b2c3d4
       spooled session show a1b2c3d4 --json
    """
    try:
        source_dir = trace_dir or get_trace_directory()

        # Support prefix matching: find full session_id
        resolved_session_id = _resolve_session_id(session_id, source_dir)
        if resolved_session_id is None:
            console.print(f"[red]✗[/red] Session not found: {session_id}")
            raise typer.Exit(code=1)

        traces = load_session_traces(resolved_session_id, trace_dir=source_dir)
        if not traces:
            console.print(f"[red]✗[/red] No traces found for session: {resolved_session_id}")
            raise typer.Exit(code=1)

        if output_json:
            _show_json(resolved_session_id, traces)
        else:
            _show_tree(resolved_session_id, traces)

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Session show failed", error=str(e))
        console.print(f"[red]✗[/red] Failed: {e}")
        raise typer.Exit(code=1)


def _resolve_session_id(prefix: str, trace_dir: Path) -> str | None:
    """Resolve a session ID prefix to the full session ID."""
    if not trace_dir.exists():
        return None

    seen_sessions: set = set()
    for tf in trace_dir.glob("*.jsonl"):
        try:
            data = load_trace_from_jsonl(tf)
            sid = data.get("trace", {}).get("session_id")
            if sid:
                seen_sessions.add(sid)
        except Exception:
            continue

    # Exact match
    if prefix in seen_sessions:
        return prefix

    # Prefix match
    matches = [s for s in seen_sessions if s.startswith(prefix)]
    if len(matches) == 1:
        return matches[0]
    return None


def _show_tree(session_id: str, traces: list[dict[str, Any]]) -> None:
    """Render a rich tree view of the session."""
    # Build lookup by run_id
    by_run_id: dict[str, dict[str, Any]] = {}
    for t in traces:
        meta = t.get("trace", {})
        run_id = meta.get("run_id", "?")
        interactions = t.get("interactions", [])
        tokens = _count_tokens(interactions)
        by_run_id[run_id] = {
            "agent_id": meta.get("agent_id", "?"),
            "run_id": run_id,
            "status": meta.get("status", "UNKNOWN"),
            "depth": meta.get("depth", 0),
            "parent_run_id": meta.get("parent_run_id"),
            "interaction_count": len(interactions),
            "tokens": tokens,
        }

    # Find root(s)
    roots = [info for info in by_run_id.values() if info["depth"] == 0]
    if not roots:
        roots = [info for info in by_run_id.values() if info["parent_run_id"] is None]
    if not roots:
        roots = [list(by_run_id.values())[0]]

    # Build children map
    children_map: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for info in by_run_id.values():
        parent = info.get("parent_run_id")
        if parent and parent in by_run_id:
            children_map[parent].append(info)

    console.print(f"\n[bold]Session:[/bold] {session_id}")

    for root in roots:
        tree = Tree(_format_node(root))
        _add_children(tree, root["run_id"], children_map)
        console.print(tree)

    total_interactions = sum(info["interaction_count"] for info in by_run_id.values())
    total_tokens = sum(info["tokens"] for info in by_run_id.values())
    console.print(
        f"\n[dim]Total: {len(traces)} traces, {total_interactions} interactions, {total_tokens} tokens[/dim]"
    )


def _add_children(
    tree: Tree,
    parent_run_id: str,
    children_map: dict[str, list[dict[str, Any]]],
) -> None:
    """Recursively add children to the tree."""
    children = children_map.get(parent_run_id, [])
    for child in sorted(children, key=lambda c: c["agent_id"]):
        subtree = tree.add(_format_node(child))
        _add_children(subtree, child["run_id"], children_map)


def _format_node(info: dict[str, Any]) -> str:
    """Format a tree node label."""
    status = info["status"]
    status_color = {"SUCCESS": "green", "FAILURE": "red", "RUNNING": "yellow"}.get(status, "white")
    parts = [
        f"[bold]{info['agent_id']}[/bold]",
        f"(run_id: {info['run_id'][:8]}...)",
        f"[{status_color}][{status}][/{status_color}]",
    ]
    details = []
    if info["interaction_count"]:
        details.append(f"{info['interaction_count']} interactions")
    if info["tokens"]:
        details.append(f"{info['tokens']} tokens")
    if details:
        parts.append(" ".join(details))
    return "  ".join(parts)


def _count_tokens(interactions: list[dict[str, Any]]) -> int:
    """Count total tokens across interactions."""
    total = 0
    for interaction in interactions:
        if interaction.get("interaction_type") == "LLM_CALL":
            usage = interaction.get("output", {}).get("usage") or interaction.get(
                "metadata", {}
            ).get("usage")
            if usage and isinstance(usage, dict):
                t = usage.get("total_tokens")
                if t and isinstance(t, (int, float)):
                    total += int(t)
    return total


def _show_json(session_id: str, traces: list[dict[str, Any]]) -> None:
    """Output machine-readable JSON for the session."""
    output = {
        "session_id": session_id,
        "trace_count": len(traces),
        "traces": [],
    }
    total_interactions = 0
    total_tokens = 0

    for t in traces:
        meta = t.get("trace", {})
        interactions = t.get("interactions", [])
        tokens = _count_tokens(interactions)
        total_interactions += len(interactions)
        total_tokens += tokens

        output["traces"].append(
            {
                "run_id": meta.get("run_id"),
                "agent_id": meta.get("agent_id"),
                "status": meta.get("status"),
                "depth": meta.get("depth", 0),
                "parent_run_id": meta.get("parent_run_id"),
                "interaction_count": len(interactions),
                "tokens": tokens,
            }
        )

    output["total_interactions"] = total_interactions
    output["total_tokens"] = total_tokens

    console.print(json.dumps(output, indent=2, default=str))
