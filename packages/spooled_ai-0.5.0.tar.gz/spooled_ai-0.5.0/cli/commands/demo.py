"""Zero-setup demo command: see Spooled catch a regression in 10 seconds.

Runs a baseline agent, then a variant agent, compares them, and shows what
Spooled detects — all without touching your project files.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import structlog
import typer
from rich.console import Console
from rich.panel import Panel

from cli.templates.demo_agent import DEMO_AGENT_TEMPLATE
from cli.templates.demo_variant import DEMO_VARIANT_TEMPLATE

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="demo", help="See Spooled in action (zero setup)")


def _execute_demo(keep: bool) -> None:
    """Shared implementation for both `spooled demo` and `spooled demo run`."""
    agent_id = "demo_agent"

    # Set up working directory
    if keep:
        work_dir = Path(".spooled") / "demo"
        work_dir.mkdir(parents=True, exist_ok=True)
    else:
        work_dir = Path(tempfile.mkdtemp(prefix="spooled-demo-"))

    try:
        _run_demo(work_dir, agent_id)
    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]Demo failed:[/red] {e}")
        logger.debug("Demo failed", error=str(e))
        raise typer.Exit(code=1)
    finally:
        if not keep and work_dir.exists():
            shutil.rmtree(work_dir, ignore_errors=True)


@app.callback(invoke_without_command=True)
def demo_callback(
    ctx: typer.Context,
    keep: bool = typer.Option(False, "--keep", help="Keep generated files in .spooled/demo/"),
) -> None:
    """Run a live demo: baseline agent -> variant agent -> compare.

    Shows Spooled catching a regression in seconds. No API keys, no setup,
    no files left behind (unless --keep).

    What happens:
      1. Runs a 3-step agent (classify -> route -> respond)
      2. Runs a variant with an extra send_email side effect
      3. Compares them and shows what Spooled caught
    """
    if ctx.invoked_subcommand is not None:
        return
    _execute_demo(keep)


@app.command("run")
def run(
    keep: bool = typer.Option(False, "--keep", help="Keep generated files in .spooled/demo/"),
) -> None:
    """Run a live demo: baseline agent -> variant agent -> compare.

    Shows Spooled catching a regression in seconds. No API keys, no setup,
    no files left behind (unless --keep).

    What happens:
      1. Runs a 3-step agent (classify -> route -> respond)
      2. Runs a variant with an extra send_email side effect
      3. Compares them and shows what Spooled caught
    """
    _execute_demo(keep)


def _run_demo(work_dir: Path, agent_id: str) -> None:
    """Execute the full demo flow."""
    console.print()
    console.print("[bold cyan]Spooled Demo[/bold cyan]")
    console.print("[dim]Watch Spooled catch a behavioral regression in real time.[/dim]")
    console.print()

    # Ensure traces dir exists inside the work dir
    traces_dir = work_dir / ".spooled" / "traces"
    traces_dir.mkdir(parents=True, exist_ok=True)

    # Step 1: Run baseline agent
    console.print("[bold]Step 1:[/bold] Running baseline agent (classify -> route -> respond)")
    baseline_path = work_dir / "demo_baseline.py"
    baseline_path.write_text(DEMO_AGENT_TEMPLATE.format(agent_id=agent_id))

    baseline_result = _run_agent(baseline_path, work_dir)
    if baseline_result is None:
        return

    baseline_trace = _find_latest_trace(traces_dir, agent_id)
    if baseline_trace is None:
        console.print("[red]  No trace generated — cannot continue[/red]")
        raise typer.Exit(code=1)

    console.print(f"[green]  Trace captured[/green] [dim]({baseline_trace.name})[/dim]")

    # Step 2: Build baseline
    console.print()
    console.print("[bold]Step 2:[/bold] Building golden baseline from that trace")

    from spooled.baseline import BaselineManager
    from spooled.storage import load_trace_from_jsonl

    trace_data = load_trace_from_jsonl(baseline_trace)
    manager = BaselineManager(agent_id)
    status = trace_data.get("trace", {}).get("status", "SUCCESS")
    manager.add_to_baseline(trace_data, status)

    baseline_file = work_dir / f"{agent_id}.json"
    manager.save_summary(baseline_file)
    console.print(f"[green]  Baseline saved[/green] [dim]({baseline_file.name})[/dim]")

    # Step 3: Run variant agent
    console.print()
    console.print(
        "[bold]Step 3:[/bold] Running variant agent "
        "(classify -> route -> [red]send_email[/red] -> respond)"
    )
    variant_path = work_dir / "demo_variant.py"
    variant_path.write_text(DEMO_VARIANT_TEMPLATE.format(agent_id=agent_id))

    variant_result = _run_agent(variant_path, work_dir)
    if variant_result is None:
        return

    variant_trace = _find_latest_trace(traces_dir, agent_id)
    if variant_trace is None:
        console.print("[red]  No variant trace generated[/red]")
        raise typer.Exit(code=1)

    console.print(f"[green]  Variant trace captured[/green] [dim]({variant_trace.name})[/dim]")

    # Step 4: Compare
    console.print()
    console.print("[bold]Step 4:[/bold] Comparing variant against baseline")
    console.print()

    from cli.commands.ci import _compute_comparison, _display_compare_results
    from spooled.baseline import load_baseline_from_path

    variant_data = load_trace_from_jsonl(variant_trace)
    baseline_data = load_baseline_from_path(baseline_file, agent_id)

    result = _compute_comparison(variant_data, baseline_data, agent_id)
    _display_compare_results(result)

    # Step 5: Explain what happened
    console.print()
    _print_explanation(result)


def _run_agent(script_path: Path, work_dir: Path) -> dict | None:
    """Run a demo agent script and return parsed output."""
    import os

    # Ensure the spooled package is importable in the subprocess
    env = {**os.environ, "SPOOLED_LOCAL_STORAGE": "true", "SPOOLED_BACKEND_URL": ""}
    project_root = Path(__file__).resolve().parent.parent.parent
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = f"{project_root}{os.pathsep}{existing}" if existing else str(project_root)
    # Point traces to work_dir so they're isolated
    # Note: get_trace_directory() appends /traces to SPOOLED_TRACE_DIR
    env["SPOOLED_TRACE_DIR"] = str(work_dir / ".spooled")

    result = subprocess.run(
        [sys.executable, str(script_path)],
        cwd=str(work_dir),
        capture_output=True,
        text=True,
        timeout=30,
        env=env,
    )
    if result.returncode != 0:
        stderr = result.stderr.strip()
        # Filter structlog noise
        import re

        _structlog_re = re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}")
        error_lines = [
            line
            for line in stderr.split("\n")
            if line.strip() and not _structlog_re.match(line.strip())
        ]
        if error_lines:
            console.print(f"[red]  Agent failed:[/red] {error_lines[-1]}")
        else:
            console.print(f"[red]  Agent failed[/red] (exit code {result.returncode})")
        return None
    return {"ok": True}


def _find_latest_trace(traces_dir: Path, agent_id: str) -> Path | None:
    """Find the most recent trace file for the given agent_id."""
    traces = sorted(traces_dir.glob("*.jsonl"), key=lambda f: f.stat().st_mtime)
    for t in reversed(traces):
        try:
            first_line = t.read_text().splitlines()[0]
            data = json.loads(first_line)
            if data.get("agent_id") == agent_id:
                return t
        except Exception:
            continue
    return None


def _print_explanation(result: dict) -> None:
    """Print the 'what just happened' explanation."""
    fp_status = result.get("fingerprint_status", "unknown")
    signals = result.get("signals", {})
    detected_signals = [
        name for name, sig in signals.items() if isinstance(sig, dict) and sig.get("detected")
    ]

    explanation = (
        "[bold]What just happened?[/bold]\n\n"
        "  1. Spooled ran a 3-step agent     (classify -> route -> respond)\n"
        "  2. Spooled ran a variant agent     (classify -> route -> [red]send_email[/red] -> respond)\n"
        "  3. Spooled compared them and found:\n"
    )

    if fp_status in ("variant", "new"):
        explanation += (
            f"     [yellow]Fingerprint: {fp_status.upper()}[/yellow] — structural change detected\n"
        )
    if "new_side_effects" in detected_signals:
        explanation += "     [red]New tool:[/red] send_email (not in baseline)\n"
    if detected_signals:
        explanation += f"     [yellow]Signals:[/yellow] {len(detected_signals)} detected\n"

    explanation += (
        "\n"
        "  In CI, this would [bold]block the merge[/bold] before reaching production.\n\n"
        "[dim]To add Spooled to your project:[/dim]  [cyan]spooled init project --with-demo[/cyan]\n"
        "[dim]Full docs:[/dim]                       [cyan]https://spooled.ai/docs[/cyan]"
    )

    console.print(
        Panel(
            explanation,
            title="Spooled caught the regression",
            border_style="green",
        )
    )
