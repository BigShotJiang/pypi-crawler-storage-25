"""Command to diff two traces."""

from __future__ import annotations

from pathlib import Path

import structlog
import typer
from rich.console import Console
from rich.panel import Panel

from cli.diff import TraceDiff
from cli.utils import resolve_trace_path

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="diff", help="Compare two traces")


@app.command()
def traces(
    trace1: str = typer.Argument(..., help="Path to first trace file or run_id"),
    trace2: str = typer.Argument(..., help="Path to second trace file or run_id"),
    output: Path = typer.Option(None, "--output", "-o", help="Save diff to file (optional)"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed diff information"),
) -> None:
    """Compare two traces and show differences.

    Example:
       spooled diff trace1.jsonl trace2.jsonl
       spooled diff abc-123 def-456
       spooled diff .spooled/traces/run1.jsonl .spooled/traces/run2.jsonl
    """
    try:
        resolved1 = resolve_trace_path(trace1)
        if resolved1 is None:
            console.print(f"[red]✗[/red] Trace file not found: {trace1}")
            console.print("\n[yellow]💡 Tips:[/yellow]")
            console.print("   1. List available traces: [cyan]spooled list traces[/cyan]")
            console.print("   2. Pull from backend: [cyan]spooled pull trace <run_id>[/cyan]")
            console.print("   3. Check file path and permissions")
            raise typer.Exit(code=1)
        trace1 = resolved1

        resolved2 = resolve_trace_path(trace2)
        if resolved2 is None:
            console.print(f"[red]✗[/red] Trace file not found: {trace2}")
            console.print("\n[yellow]💡 Tips:[/yellow]")
            console.print("   1. List available traces: [cyan]spooled list traces[/cyan]")
            console.print("   2. Pull from backend: [cyan]spooled pull trace <run_id>[/cyan]")
            console.print("   3. Check file path and permissions")
            raise typer.Exit(code=1)
        trace2 = resolved2

        # Load and diff traces
        import json

        from spooled.storage import load_trace_from_jsonl

        if trace1.suffix == ".jsonl":
            trace_data1 = load_trace_from_jsonl(trace1)
        else:
            with open(trace1) as f:
                trace_data1 = json.load(f)

        if trace2.suffix == ".jsonl":
            trace_data2 = load_trace_from_jsonl(trace2)
        else:
            with open(trace2) as f:
                trace_data2 = json.load(f)

        diff = TraceDiff(trace_data1, trace_data2)
        diff_result = diff.diff()

        # Display results
        formatted_diff = diff.format_diff(diff_result, verbose=verbose)
        console.print(Panel(formatted_diff, title="Trace Diff", border_style="blue"))

        # Save to file if requested
        if output:
            with open(output, "w") as f:
                import json

                json.dump(diff_result, f, indent=2, default=str)
            console.print(f"[green]✓[/green] Diff saved to: {output}")

    except FileNotFoundError as e:
        console.print(f"[red]✗[/red] File not found: {str(e)}")
        console.print("\n[yellow]💡 Tip:[/yellow] Ensure both trace files exist and are readable")
        raise typer.Exit(code=1)
    except ValueError as e:
        console.print(f"[red]✗[/red] Invalid trace format: {str(e)}")
        console.print(
            "\n[yellow]💡 Tip:[/yellow] Ensure trace files are valid JSONL or JSON format"
        )
        if verbose:
            logger.debug("Trace format error", error=str(e))
        raise typer.Exit(code=1)
    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to diff traces", error=str(e))
        console.print(f"[red]✗[/red] Failed to diff traces: {str(e)}")
        if verbose:
            import traceback

            console.print("\n[dim]Full traceback:[/dim]")
            console.print(traceback.format_exc())
        else:
            console.print(
                "\n[yellow]💡 Tip:[/yellow] Use [cyan]--verbose[/cyan] for detailed error information"
            )
        raise typer.Exit(code=1)
