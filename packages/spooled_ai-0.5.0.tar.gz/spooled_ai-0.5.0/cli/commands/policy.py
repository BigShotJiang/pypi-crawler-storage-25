"""Policy management commands."""

from __future__ import annotations

from pathlib import Path

import structlog
import typer
from rich.console import Console
from rich.panel import Panel

from spooled.policy import PolicyEngine

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="policy", help="Policy management commands")


@app.command()
def validate(
    policy_file: Path = typer.Argument(..., help="Path to policy YAML file"),
) -> None:
    """Validate a policy YAML file.

    Example:
       spooled policy validate spooled-policy.yml
    """
    try:
        engine = PolicyEngine(policy_file)
        if engine.policy:
            console.print(f"[green]✓[/green] Policy file is valid: {policy_file}")
            console.print(f"  Policy name: {engine.policy.name}")
            console.print(f"  Enabled: {engine.policy.enabled}")
            console.print(f"  Block merges: {engine.policy.block_merges}")
            console.print(f"  Rules: {len(engine.policy.rules)}")
        else:
            console.print(
                f"[yellow]⚠[/yellow] Policy file loaded but no policy found: {policy_file}"
            )
            raise typer.Exit(code=1)
    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to validate policy", error=str(e))
        console.print(f"[red]✗[/red] Failed to validate policy: {str(e)}")
        raise typer.Exit(code=1)


@app.command()
def show(
    policy_file_arg: Path | None = typer.Argument(
        None, help="Path to policy YAML file (auto-detects if not provided)"
    ),
    policy_file: Path | None = typer.Option(
        None, "--file", "-f", help="Path to policy YAML file (alternative to positional)"
    ),
) -> None:
    """Show policy configuration.

    Example:
       spooled policy show
       spooled policy show spooled-policy.yml
       spooled policy show --file custom-policy.yml
    """
    try:
        resolved_file = policy_file_arg or policy_file
        engine = PolicyEngine(resolved_file)
        if not engine.policy:
            console.print("[yellow]⚠[/yellow] No policy file found")
            console.print("\n[yellow]💡 Tips:[/yellow]")
            console.print(
                "   1. Create a policy file: [cyan].spooled/policy.yml[/cyan] or [cyan]spooled-policy.yml[/cyan]"
            )
            console.print("   2. See example: [cyan]spooled policy init[/cyan]")
            raise typer.Exit(code=0)

        policy = engine.policy
        content = []
        content.append(f"[bold]Policy Name:[/bold] {policy.name}")
        content.append(f"[bold]Enabled:[/bold] {policy.enabled}")
        content.append(f"[bold]Block Merges:[/bold] {policy.block_merges}")
        content.append(f"[bold]Rules:[/bold] {len(policy.rules)}")
        content.append("")

        for i, rule in enumerate(policy.rules, 1):
            content.append(f"[bold]Rule {i}:[/bold] {rule.name}")
            if rule.description:
                content.append(f"  {rule.description}")
            content.append(f"  [bold]Severity:[/bold] {rule.severity}")
            if rule.fail_if:
                content.append(f"  [bold]Fail If:[/bold] {rule.fail_if}")
            if rule.warn_if:
                content.append(f"  [bold]Warn If:[/bold] {rule.warn_if}")
            content.append("")

        console.print(Panel("\n".join(content), title="Policy Configuration", border_style="blue"))

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to show policy", error=str(e))
        console.print(f"[red]✗[/red] Failed to show policy: {str(e)}")
        raise typer.Exit(code=1)


@app.command()
def init(
    output_file: Path = typer.Option(
        Path("spooled-policy.yml"), "--output", "-o", help="Output file path"
    ),
    template: str = typer.Option(
        "moderate", "--template", "-t", help="Policy template: strict, moderate, or permissive"
    ),
) -> None:
    """Initialize a new policy file from a template.

    Templates:
        strict      - All 12 signals block with tight thresholds
        moderate    - Critical signals block, others warn (recommended)
        permissive  - All signals warn with relaxed thresholds, nothing blocks

    Example:
       spooled policy init
       spooled policy init --template strict
       spooled policy init --template permissive --output .spooled/policy.yml
    """
    try:
        from cli.templates.policy_templates import get_template

        if output_file.exists():
            console.print(f"[yellow]![/yellow] Policy file already exists: {output_file}")
            if not typer.confirm("Overwrite existing file?"):
                raise typer.Exit(code=0)

        try:
            policy_content = get_template(template)
        except ValueError as e:
            console.print(f"[red]✗[/red] {e}")
            raise typer.Exit(code=1)

        output_file.parent.mkdir(parents=True, exist_ok=True)
        with open(output_file, "w") as f:
            f.write(policy_content)

        console.print(
            f"[green]OK[/green] Policy file created: {output_file} (template: {template})"
        )
        console.print("\n[yellow]Next steps:[/yellow]")
        step = 1
        console.print(f"   {step}. Review and customize the policy rules")
        if template == "permissive":
            step += 1
            console.print(f"   {step}. Set `block_merges: true` when ready to enforce")
        step += 1
        console.print(
            f"   {step}. Validate with: [cyan]spooled policy validate {output_file}[/cyan]"
        )

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to initialize policy", error=str(e))
        console.print(f"[red]✗[/red] Failed to initialize policy: {str(e)}")
        raise typer.Exit(code=1)
