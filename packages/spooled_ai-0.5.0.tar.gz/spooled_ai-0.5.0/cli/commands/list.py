"""Command to list local traces."""

from __future__ import annotations

import structlog
import typer
from dotenv import load_dotenv
from rich.console import Console
from rich.table import Table

# Load .env file if it exists
load_dotenv()

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="list", help="List local traces")


@app.command()
def traces() -> None:
    """List available traces from local storage.

    Examples:
       spooled list traces
    """
    try:
        local_traces = list_local_traces()
        traces_list = [(trace, "local") for trace in local_traces]

        # Display results
        if not traces_list:
            console.print("[yellow]No traces found[/yellow]")
            console.print("Try running an agent to create traces.")
            return

        # Create table
        table = Table(title="Available Traces")
        table.add_column("Run ID", style="cyan", no_wrap=True)
        table.add_column("Source", style="magenta")
        table.add_column("Agent ID", style="green")
        table.add_column("Status", style="yellow")
        table.add_column("Interactions", justify="right", style="blue")
        table.add_column("Timestamp", style="dim")

        # Sort by timestamp (newest first)
        traces_list.sort(key=lambda x: x[0].get("timestamp", ""), reverse=True)

        for trace, source in traces_list:
            run_id = trace.get("run_id", "unknown")
            agent_id = trace.get("agent_id", "unknown")
            status = trace.get("status", "unknown")
            interaction_count = trace.get("interaction_count", len(trace.get("interactions", [])))
            timestamp = trace.get("timestamp", "unknown")

            table.add_row(
                run_id,
                source,
                agent_id,
                status,
                str(interaction_count),
                timestamp,
            )

        console.print(table)
        console.print(f"\n[dim]Total: {len(traces_list)} trace(s)[/dim]")

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to list traces", error=str(e))
        console.print(f"[red]✗[/red] Failed to list traces: {str(e)}")
        raise typer.Exit(code=1)


def list_local_traces() -> list[dict]:
    """List all local trace files.

    Returns:
        List of trace dictionaries with metadata
    """
    import json

    from spooled.storage import get_trace_directory

    trace_dir = get_trace_directory()
    traces = []

    if not trace_dir.exists():
        return traces

    # Find all JSONL files
    for trace_file in trace_dir.glob("*.jsonl"):
        try:
            # Read all lines: use the LAST trace-type line for metadata
            # (first trace line has status RUNNING, last has final status)
            trace_data = None
            interaction_count = 0
            with trace_file.open("r") as f:
                for line in f:
                    if not line.strip():
                        continue
                    data = json.loads(line)
                    if data.get("type") == "trace":
                        trace_data = data
                    elif data.get("type") == "interaction":
                        interaction_count += 1

            if trace_data is not None:
                trace_data["interaction_count"] = interaction_count
                traces.append(trace_data)
        except Exception as e:
            logger.warning("Failed to read trace file", file=str(trace_file), error=str(e))
            continue

    return traces
