"""CI commands for behavioral CI/CD pipeline.

Commands:
    report          - Generate AI Behavior Diff Report (existing)
    compare         - Compare current trace/summary against a baseline
    update-baseline - Generate compact baseline summary from traces
    run             - Orchestrate full CI loop (run tests + compare + report)
    batch-compare   - Compare all traces in a directory against baselines (no test execution)
    accept-variant  - Add a fingerprint variant to an intent's accepted set
    approve         - Accept variants + regenerate baseline + optional git commit
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import structlog
import typer
from rich.console import Console

from cli.commands.ci_display import (  # noqa: F401
    _display_compare_results as _display_compare_results_v2,
)

# Engine and display logic extracted to separate modules for maintainability.
# Functions remain in this file for backward compatibility during migration.
# New code should import from ci_engine and ci_display directly.
from cli.commands.ci_engine import (  # noqa: F401
    _compute_comparison as _compute_comparison_v2,
)
from cli.report import AIBehaviorReport
from spooled.baseline import (
    BaselineManager,
    baseline_diff,
    cluster_intents,
    load_baseline_from_path,
)
from spooled.fingerprint import (
    BehavioralFingerprint,
    fingerprint_similarity_detailed,
    hash_fingerprint,
)
from spooled.licensing import check_license_for_ci
from spooled.models import AgentBaseline
from spooled.policy import PolicyEngine
from spooled.signals import METRIC_SENSITIVE_SIGNALS, SignalDetector
from spooled.storage import get_trace_directory, load_trace_from_jsonl

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="ci", help="CI/CD integration commands")


def _check_paywall() -> bool:
    """Check license and display banner if over free tier limits.

    Returns True if the command is allowed to proceed.
    Used by `ci compare` (free tier — always allowed, shows upsell).
    """
    try:
        result = check_license_for_ci()
        if result["allowed"]:
            return True

        console.print(
            f"\n[yellow]⚠ {result['message']}[/yellow]\n"
            "[dim]Your CI pipeline will continue, but results may be limited.[/dim]\n"
        )
        return False
    except Exception:
        # Never block CI on license check failures
        return True


def _require_pro(command_name: str) -> bool:
    """Require Pro plan for backend-using operations.

    Free tier is fully featured for local-only workflows. The Pro gate only
    applies to operations that send data to or fetch data from the backend
    (trace ingest, baseline sync, CI report push, fetch-from-backend).

    Returns True if allowed to proceed, False if blocked.
    """
    import os

    api_key = os.getenv("SPOOLED_API_KEY", "").strip()

    # No API key at all: block immediately
    if not api_key:
        console.print(
            f"\n[yellow]⚠[/yellow]  `{command_name}` uses backend features (Pro, $99/mo).\n"
        )
        console.print(
            "[dim]Free tier (no API key needed):[/dim]\n"
            "  • All local CLI commands (compare, batch-compare, ci run, baseline, diff, verify, policy)\n"
            "  • Run agents locally, generate baselines, gate PRs in CI\n"
            "  • Hash chain integrity verification\n"
        )
        console.print(
            "[dim]Pro adds (requires SPOOLED_API_KEY):[/dim]\n"
            "  • [cyan]Pattern 4[/cyan] — fetch production traces from backend instead of running agents in CI\n"
            "  • Backend trace ingest from staging/production\n"
            "  • Hosted dashboard at app.spooled.ai\n"
            "  • Slack/webhook drift alerts\n"
            "  • 90-day history retention\n"
        )
        console.print(
            "[bold]→ Get a key at https://spooled.ai/#pricing[/bold]\n"
            "[dim]Then: export SPOOLED_API_KEY=sk-...[/dim]\n"
        )
        return False

    # API key present: validate it's on a paid plan
    try:
        result = check_license_for_ci()
        plan = result.get("plan", "free")

        if plan != "free":
            return True

        # Valid key but free tier
        console.print(
            f"\n[yellow]⚠[/yellow]  `{command_name}` requires a Pro plan ($99/mo).\n"
            f"[dim]Current plan: free[/dim]\n"
        )
        console.print(
            "[dim]Pro adds:[/dim]\n"
            "  • [cyan]Pattern 4[/cyan] — fetch production traces from backend instead of running agents in CI\n"
            "  • Backend trace ingest from staging/production\n"
            "  • Hosted dashboard at app.spooled.ai\n"
            "  • Slack/webhook drift alerts\n"
        )
        console.print("[bold]→ Upgrade at https://spooled.ai/#pricing[/bold]\n")
        return False

    except Exception:
        # License validation failed (network error, backend down).
        # Allow execution — never break a CI pipeline over a license check.
        # The backend will enforce its own gates if the user pushes results.
        logger.debug("License check failed, allowing operation (fail open)")
        return True


def find_latest_trace(trace_dir: Path | None = None, agent_id: str | None = None) -> Path | None:
    """Find the latest trace file in the traces directory.

    Args:
        trace_dir: Optional trace directory (defaults to .spooled/traces)
        agent_id: Optional agent_id filter — only return traces for this agent

    Returns:
        Path to latest trace file, or None if not found
    """
    if trace_dir is None:
        trace_dir = get_trace_directory()

    if not trace_dir.exists():
        return None

    trace_files = list(trace_dir.glob("*.jsonl"))
    if not trace_files:
        return None

    # Filter by agent_id if provided
    if agent_id:
        filtered = []
        for tf in trace_files:
            try:
                with open(tf) as f:
                    first_line = json.loads(f.readline())
                    if first_line.get("agent_id") == agent_id:
                        filtered.append(tf)
            except Exception as _exc:
                logger.debug("Suppressed exception", error=str(_exc))

                continue
        trace_files = filtered
        if not trace_files:
            return None

    # Sort by modification time, newest first
    trace_files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return trace_files[0]


def _find_all_traces(trace_dir: Path) -> list[Path]:
    """Find all trace files in a directory.

    Args:
        trace_dir: Directory to search

    Returns:
        List of trace file paths sorted by modification time
    """
    if not trace_dir.exists():
        return []
    trace_files = list(trace_dir.glob("*.jsonl"))
    trace_files.sort(key=lambda p: p.stat().st_mtime)
    return trace_files


def _emit_github_annotations(report_data: dict) -> None:
    signals = report_data.get("signals", {})
    for name, signal in signals.items():
        if not isinstance(signal, dict) or not signal.get("detected"):
            continue
        severity = signal.get("severity", "medium")
        level = {
            "high": "error",
            "medium": "warning",
            "low": "notice",
            "info": "notice",
        }.get(severity, "notice")
        message = signal.get("message") or f"{name} detected"
        message = str(message).replace("\n", " ").strip()
        title = name.replace("_", " ").title()
        print(f"::{level} title=Spooled {title}::{message}")


def _write_summary_json(report_data: dict, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "agent_id": report_data.get("agent_id"),
        "run_id": report_data.get("run_id"),
        "trace_file": report_data.get("trace_file"),
        "summary": report_data.get("summary", {}),
        "policy": report_data.get("policy", {}),
    }
    output_path.write_text(json.dumps(payload, indent=2))


def _write_gitlab_codequality(report_data: dict, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    trace_path = report_data.get("trace_file") or "ai-behavior-report"
    signals = report_data.get("signals", {})
    findings = []

    severity_map = {
        "high": "critical",
        "medium": "major",
        "low": "minor",
        "info": "info",
    }

    for name, signal in signals.items():
        if not isinstance(signal, dict) or not signal.get("detected"):
            continue
        message = signal.get("message") or f"{name} detected"
        fingerprint = hashlib.sha256(f"{name}:{message}".encode()).hexdigest()
        severity = severity_map.get(signal.get("severity", "minor"), "minor")

        findings.append(
            {
                "description": str(message),
                "fingerprint": fingerprint,
                "severity": severity,
                "location": {
                    "path": trace_path,
                    "lines": {"begin": 1, "end": 1},
                },
            }
        )

    output_path.write_text(json.dumps(findings, indent=2))


def _load_trace(trace_file: Path) -> dict[str, Any]:
    """Load trace from file (JSONL or JSON).

    Args:
        trace_file: Path to trace file

    Returns:
        Trace data dictionary
    """
    if trace_file.suffix == ".jsonl":
        return load_trace_from_jsonl(trace_file)
    else:
        with open(trace_file) as f:
            return json.load(f)


def _compute_comparison(
    current_trace: dict[str, Any],
    baseline_data: Any,
    agent_id: str,
    policy_engine: PolicyEngine | None = None,
    policy_only: bool = False,
) -> dict[str, Any]:
    """Core comparison logic used by both `compare` and `run`.

    Args:
        current_trace: Current trace data
        baseline_data: AgentBaseline or None
        agent_id: Agent identifier
        policy_engine: Optional policy engine
        policy_only: If True, skip fingerprint comparison; only run signal detection + policy

    Returns:
        Comparison result dictionary
    """

    # Generate current fingerprint
    current_fp = BehavioralFingerprint(current_trace)
    current_fp_data = current_fp.generate()
    current_fp_hash = hash_fingerprint(current_fp_data)

    # Build a baseline manager from the baseline data
    baseline_manager = BaselineManager(agent_id)
    if baseline_data is not None:
        baseline_manager._baseline = baseline_data

    # Detect signals
    signal_detector = SignalDetector(current_trace, None, baseline_manager=baseline_manager)
    signals = signal_detector.detect_signals()

    # Check fingerprint against baseline
    fingerprint_status = "unknown"
    fingerprint_match = False
    baseline_fp_hash = None

    if policy_only:
        # Skip fingerprint comparison entirely; treat as "not compared"
        fingerprint_status = "not_compared"
        fingerprint_match = True  # don't block on fingerprint in policy_only mode
        baseline_fp_hash = (
            next(iter(baseline_data.intents), None)
            if baseline_data and baseline_data.intents
            else None
        )
    elif baseline_data and baseline_data.intents:
        # Check direct match
        if current_fp_hash in baseline_data.intents:
            fingerprint_status = "match"
            fingerprint_match = True
            baseline_fp_hash = current_fp_hash
        else:
            # Check accepted variants (prefix-aware: accept-variant may
            # store truncated hashes while current_fp_hash is full 64-char)
            for intent_id, intent_stat in baseline_data.intents.items():
                if any(
                    current_fp_hash == afp
                    or current_fp_hash.startswith(afp)
                    or afp.startswith(current_fp_hash)
                    for afp in (intent_stat.accepted_fingerprints or [])
                ):
                    fingerprint_status = "accepted_variant"
                    fingerprint_match = True
                    baseline_fp_hash = intent_id
                    break
            else:
                # Standard mode: order-tolerant matching via tool-set Jaccard.
                # If tool sets are >=85% similar, treat as MATCH. Absorbs natural
                # non-determinism without hiding real regressions.
                # Standard mode: order-tolerant, addition-tolerant, but
                # removal-sensitive. Reordering and optional extra tools = MATCH.
                # Missing a baseline tool = VARIANT (real regression).
                # Compute cross-intent tool presence: how often each tool appears
                # across ALL baseline intents. A tool in 7/10 intents is conditional
                # (70% rate). A tool in 10/10 is mandatory. This works even when
                # each intent has only 1 run (common with non-deterministic agents).
                n_intents = len(baseline_data.intents)
                cross_intent_presence: dict[str, float] = {}
                if n_intents > 0:
                    tool_intent_count: dict[str, int] = {}
                    for intent_stat in baseline_data.intents.values():
                        b_fp = (
                            intent_stat.fingerprint if hasattr(intent_stat, "fingerprint") else None
                        )
                        if b_fp:
                            for t in b_fp.get("tool_graph", {}).get("unique_tools", []):
                                tool_intent_count[t] = tool_intent_count.get(t, 0) + 1
                    cross_intent_presence = {
                        t: count / n_intents for t, count in tool_intent_count.items()
                    }

                best_jaccard = 0.0
                best_jaccard_intent = None
                best_mandatory_removed = set()
                for intent_id, intent_stat in baseline_data.intents.items():
                    b_fp = intent_stat.fingerprint if hasattr(intent_stat, "fingerprint") else None
                    if b_fp:
                        current_tools = set(
                            current_fp_data.get("tool_graph", {}).get("unique_tools", [])
                        )
                        baseline_tools = set(b_fp.get("tool_graph", {}).get("unique_tools", []))
                        union = len(current_tools | baseline_tools)
                        jaccard = len(current_tools & baseline_tools) / union if union > 0 else 1.0
                        removed = baseline_tools - current_tools

                        # A removed tool is mandatory only if it appears in ALL
                        # baseline intents (cross-intent presence == 1.0). Tools
                        # that appear in <100% of intents are conditional.
                        mandatory_removed = {
                            t for t in removed if cross_intent_presence.get(t, 1.0) >= 1.0
                        }

                        if jaccard > best_jaccard:
                            best_jaccard = jaccard
                            best_jaccard_intent = intent_id
                            best_mandatory_removed = mandatory_removed

                # MATCH if no MANDATORY tools were removed.
                if best_jaccard_intent and not best_mandatory_removed:
                    fingerprint_status = "match"
                    fingerprint_match = True
                    baseline_fp_hash = best_jaccard_intent
                else:
                    # Check structural (IO-schema) hash match — catches tool renames
                    current_structural_hash = hash_fingerprint(current_fp_data, mode="structural")
                    for intent_id, intent_stat in baseline_data.intents.items():
                        baseline_structural = getattr(
                            intent_stat, "structural_fingerprint_hash", None
                        )
                        if baseline_structural and baseline_structural == current_structural_hash:
                            fingerprint_status = "structural_match"
                            fingerprint_match = True
                            baseline_fp_hash = intent_id
                            break
                    else:
                        fingerprint_status = "new"
                        # Find closest intent for comparison (first one if exists)
                        baseline_fp_hash = next(iter(baseline_data.intents), None)
    else:
        fingerprint_status = "no_baseline"

    # Compute metric deltas if we have a matching baseline intent
    metric_deltas = {}
    if baseline_fp_hash and baseline_fp_hash in (baseline_data.intents if baseline_data else {}):
        baseline_stat = baseline_data.intents[baseline_fp_hash]
        # Token delta
        interactions = current_trace.get("interactions", [])
        current_tokens = 0
        for interaction in interactions:
            if interaction.get("interaction_type") == "LLM_CALL":
                usage = interaction.get("output", {}).get("usage") or interaction.get(
                    "metadata", {}
                ).get("usage")
                if usage and isinstance(usage, dict):
                    t = usage.get("total_tokens")
                    if t and isinstance(t, (int, float)):
                        current_tokens += t

        if baseline_stat.avg_tokens > 0:
            token_delta = current_tokens - baseline_stat.avg_tokens
            token_delta_pct = (token_delta / baseline_stat.avg_tokens) * 100
            metric_deltas["tokens"] = {
                "current": current_tokens,
                "baseline_avg": baseline_stat.avg_tokens,
                "delta": token_delta,
                "delta_pct": round(token_delta_pct, 1),
            }

        # Step count delta
        current_step_count = len(interactions)
        if baseline_stat.step_count > 0:
            step_delta = current_step_count - baseline_stat.step_count
            metric_deltas["step_count"] = {
                "current": current_step_count,
                "baseline": baseline_stat.step_count,
                "delta": step_delta,
            }

    # Similarity-aware VARIANT classification for "new" fingerprints
    similarity_score = None
    similarity_dimensions: dict[str, Any] | None = None
    reason_code: str | None = None
    reason_label: str | None = None
    tool_diff: dict[str, Any] | None = None
    if fingerprint_status == "new" and baseline_data and baseline_data.intents:
        best_detail = None
        best_intent = None
        for b_intent in baseline_data.intents.values():
            b_fp = b_intent.fingerprint if hasattr(b_intent, "fingerprint") else None
            if b_fp:
                detail = fingerprint_similarity_detailed(current_fp_data, b_fp)
                if best_detail is None or detail["overall"] > best_detail["overall"]:
                    best_detail = detail
                    best_intent = b_intent
        if best_detail and best_detail["overall"] >= 0.75:
            fingerprint_status = "variant"
            similarity_score = round(best_detail["overall"], 2)
            similarity_dimensions = {
                "tool_jaccard": best_detail["tool_jaccard"],
                "sequence_lcs": best_detail["sequence_lcs"],
                "error_jaccard": best_detail["error_jaccard"],
            }
            reason_code = best_detail["dominant_reason"]
            reason_label = best_detail["reason_label"]
        if fingerprint_status in ("variant", "new") and best_intent is not None:
            current_tools = set(current_fp_data.get("tool_graph", {}).get("unique_tools", []))
            baseline_tools = set(
                best_intent.fingerprint.get("tool_graph", {}).get("unique_tools", [])
                if hasattr(best_intent, "fingerprint") and best_intent.fingerprint
                else []
            )
            tool_diff = {
                "added": sorted(current_tools - baseline_tools),
                "removed": sorted(baseline_tools - current_tools),
                "baseline_sequence": (
                    best_intent.fingerprint.get("tool_graph", {}).get("sequence", [])
                    if hasattr(best_intent, "fingerprint") and best_intent.fingerprint
                    else []
                ),
                "current_sequence": current_fp_data.get("tool_graph", {}).get("sequence", []),
            }

    # Also compute latency delta when we have a baseline match/variant
    if baseline_fp_hash and baseline_fp_hash in (baseline_data.intents if baseline_data else {}):
        baseline_stat = baseline_data.intents[baseline_fp_hash]
        current_latency_ms = current_trace.get("trace", {}).get("total_latency_ms", 0)
        if not current_latency_ms:
            # Try to sum from interactions
            interactions = current_trace.get("interactions", [])
            current_latency_ms = sum(float(i.get("latency_ms", 0) or 0) for i in interactions)
        if baseline_stat.avg_latency > 0 and current_latency_ms > 0:
            lat_delta = current_latency_ms - baseline_stat.avg_latency
            lat_delta_pct = (lat_delta / baseline_stat.avg_latency) * 100
            metric_deltas["latency"] = {
                "current_ms": current_latency_ms,
                "baseline_avg_ms": baseline_stat.avg_latency,
                "delta_ms": lat_delta,
                "delta_pct": round(lat_delta_pct, 1),
            }

    # Evaluate policy
    policy_result = {}
    if policy_engine:
        policy_result = policy_engine.evaluate(
            signals,
            None,
            context={
                "fingerprint_status": fingerprint_status,
                "similarity_score": similarity_score,
            },
            agent_id=agent_id,
        )

    # Gather baseline stats for downstream consumers
    baseline_stats: dict[str, Any] = {}
    intent_trend: list[Any] = []
    intent_distribution: list[dict[str, Any]] = []
    if baseline_data and baseline_data.intents:
        # Compute intent frequency distribution across the whole agent
        total_runs = sum(
            getattr(ist, "sample_count", 0) or len(getattr(ist, "runs", []))
            for ist in baseline_data.intents.values()
        )
        if total_runs > 0:
            for iid, ist in baseline_data.intents.items():
                rc = getattr(ist, "sample_count", 0) or len(getattr(ist, "runs", []))
                tool_seq = (
                    ist.fingerprint.get("tool_graph", {}).get("sequence", [])
                    if hasattr(ist, "fingerprint") and ist.fingerprint
                    else []
                )
                intent_distribution.append(
                    {
                        "intent_id": iid,
                        "run_count": rc,
                        "frequency_pct": round((rc / total_runs) * 100, 1),
                        "tool_sequence": tool_seq,
                        "is_current": iid == current_fp_hash,
                    }
                )
            intent_distribution.sort(key=lambda x: x["frequency_pct"], reverse=True)

    if baseline_fp_hash and baseline_data and baseline_fp_hash in baseline_data.intents:
        bstat = baseline_data.intents[baseline_fp_hash]
        baseline_stats = {
            "sample_count": getattr(bstat, "sample_count", 0),
            "error_rate": getattr(bstat, "error_rate", 0.0),
            "avg_latency": getattr(bstat, "avg_latency", 0.0),
            "avg_tokens": getattr(bstat, "avg_tokens", 0.0),
            "latency_bounds": getattr(bstat, "latency_bounds", None),
        }
        intent_trend = getattr(bstat, "similarity_trend", [])

    # Compute Spooled Score — cap to D when policy blocks, penalize tool removals
    from spooled.scoring import compute_spooled_score

    policy_failed = bool(policy_result.get("should_block")) if policy_result else False
    tools_removed_count = len(tool_diff.get("removed", [])) if tool_diff else 0

    spooled_score = compute_spooled_score(
        fingerprint_status=fingerprint_status,
        similarity_score=similarity_score,
        signals=signals,
        metric_deltas=metric_deltas,
        similarity_trend=intent_trend,
        policy_failed=policy_failed,
        tools_removed=tools_removed_count,
    )

    result = {
        "agent_id": agent_id,
        "run_id": current_trace.get("trace", {}).get("run_id"),
        "timestamp": current_trace.get("trace", {}).get("timestamp"),
        "status": current_trace.get("trace", {}).get("status"),
        "fingerprint": current_fp_data,
        "fingerprint_hash": current_fp_hash,
        "fingerprint_status": fingerprint_status,
        "fingerprint_match": fingerprint_match,
        "baseline_fingerprint_hash": baseline_fp_hash,
        "signals": signals,
        "metric_deltas": metric_deltas,
        "baseline_stats": baseline_stats,
        "intent_distribution": intent_distribution,
        "similarity_score": similarity_score,
        "similarity_dimensions": similarity_dimensions,
        "reason_code": reason_code,
        "reason_label": reason_label,
        "tool_diff": tool_diff,
        "policy": policy_result,
        "spooled_score": spooled_score,
        "summary": {
            "has_warnings": signals.get("has_warnings", False),
            "severity": signals.get("severity", "none"),
            "signal_count": sum(
                1 for s in signals.values() if isinstance(s, dict) and s.get("detected")
            ),
            "fingerprint_match": fingerprint_match,
            "fingerprint_status": fingerprint_status,
            "policy_enabled": policy_result.get("enabled", False),
            "policy_passed": policy_result.get("passed", True),
            "should_block": policy_result.get("should_block", False),
            "policy_violations": len(policy_result.get("violations", [])),
            "spooled_score": spooled_score.get("score"),
            "spooled_grade": spooled_score.get("grade"),
        },
    }

    return result


def _determine_exit_code(result: dict[str, Any], enable_blocking: bool = True) -> int:
    """Determine exit code from comparison result.

    Returns 0 for pass, 1 for failure/block.
    New behavior (fingerprint_status == "new") blocks by default when
    enable_blocking is True, regardless of whether a policy file is loaded.
    """
    summary = result.get("summary", {})

    # Policy-based blocking
    if enable_blocking and summary.get("should_block"):
        return 1

    # New behavior always blocks when blocking is enabled
    if enable_blocking and summary.get("fingerprint_status") == "new":
        return 1

    return 0


# ─── ci-history helpers ──────────────────────────────────────────────────────


def _append_ci_history(result: dict[str, Any], cwd: Path) -> None:
    """Append one comparison result to the per-agent CI history JSONL file.

    Only records statuses that carry a similarity signal (match, variant,
    accepted_variant). 'new', 'no_baseline', etc. are ignored since they
    don't contribute to a meaningful trend series.
    """
    status = result.get("fingerprint_status", "")
    if status not in ("match", "variant", "accepted_variant"):
        return
    intent_id = result.get("baseline_fingerprint_hash") or ""
    if not intent_id:
        return
    agent_id = result.get("agent_id", "unknown")
    score = result.get("similarity_score")
    if score is None:
        score = 1.0 if status == "match" else 0.0
    entry = {
        "timestamp": result.get("timestamp") or datetime.now(timezone.utc).isoformat(),
        "intent_id": intent_id,
        "similarity_score": score,
        "fingerprint_status": status,
        "dominant_reason": result.get("reason_code"),
        "spooled_score": result.get("spooled_score", {}).get("score"),
    }
    history_dir = cwd / ".spooled" / "ci-history"
    history_dir.mkdir(parents=True, exist_ok=True)
    with open(history_dir / f"{agent_id}.jsonl", "a") as f:
        f.write(json.dumps(entry) + "\n")


# ─── history ─────────────────────────────────────────────────────────────────


@app.command()
def history(
    agent_id: str | None = typer.Option(
        None, "--agent-id", "-a", help="Filter by agent ID (default: show all agents)"
    ),
    limit: int = typer.Option(20, "--limit", "-n", help="Max entries to show (newest first)"),
    push: bool = typer.Option(
        False, "--push", help="Push local history to the backend before displaying"
    ),
    pull: bool = typer.Option(
        False, "--pull", help="Pull remote history from backend and merge locally before displaying"
    ),
) -> None:
    """Show recent CI comparison history from .spooled/ci-history/.

    Reads per-agent JSONL history files and renders a table of recent
    comparison results with timestamps, similarity scores, and status.

    Use --push to upload local history to the backend, or --pull to
    download and merge remote history before displaying.

    Example:
       spooled ci history
       spooled ci history --agent-id my_agent
       spooled ci history --agent-id my_agent --limit 50
       spooled ci history --agent-id my_agent --push
       spooled ci history --agent-id my_agent --pull
    """
    from rich.table import Table as _Table

    history_dir = get_trace_directory().parent / "ci-history"

    # ── sync with backend ─────────────────────────────────────────────────────
    if push or pull:
        from spooled.ci_history_sync import pull_ci_history, push_ci_history

        agents_to_sync: list[str] = []
        if agent_id:
            agents_to_sync = [agent_id]
        elif history_dir.exists():
            agents_to_sync = [f.stem for f in sorted(history_dir.glob("*.jsonl"))]

        for sync_agent in agents_to_sync:
            if push:
                ok, msg = push_ci_history(sync_agent, history_dir)
                icon = "[green]✓[/green]" if ok else "[red]✗[/red]"
                console.print(f"{icon} push {sync_agent}: {msg}")
            if pull:
                ok, msg = pull_ci_history(sync_agent, history_dir)
                icon = "[green]✓[/green]" if ok else "[red]✗[/red]"
                console.print(f"{icon} pull {sync_agent}: {msg}")

    entries: list[dict[str, Any]] = []

    if agent_id:
        history_file = history_dir / f"{agent_id}.jsonl"
        if not history_file.exists():
            console.print(f"No history for {agent_id}")
            raise typer.Exit(code=0)
        for line in history_file.read_text().splitlines():
            line = line.strip()
            if line:
                try:
                    e = json.loads(line)
                    e["_agent"] = agent_id
                    entries.append(e)
                except Exception as _exc:
                    logger.debug("Suppressed exception", error=str(_exc))

                    pass
    else:
        if not history_dir.exists():
            console.print("No history found.")
            raise typer.Exit(code=0)
        for history_file in sorted(history_dir.glob("*.jsonl")):
            agent_stem = history_file.stem
            for line in history_file.read_text().splitlines():
                line = line.strip()
                if line:
                    try:
                        e = json.loads(line)
                        e["_agent"] = agent_stem
                        entries.append(e)
                    except Exception as _exc:
                        logger.debug("Suppressed exception", error=str(_exc))

                        pass

    if not entries:
        console.print("No history found.")
        raise typer.Exit(code=0)

    # Sort newest first, then apply limit
    entries.sort(key=lambda e: e.get("timestamp", ""), reverse=True)
    entries = entries[:limit]

    table = _Table(show_header=True, header_style="bold dim")
    table.add_column("Timestamp", style="dim")
    if not agent_id:
        table.add_column("Agent")
    table.add_column("Intent", style="dim")
    table.add_column("Score", justify="right")
    table.add_column("Status")
    table.add_column("Reason")

    for e in entries:
        ts_raw = e.get("timestamp", "")
        try:
            ts = datetime.fromisoformat(ts_raw.replace("Z", "+00:00")).strftime("%m-%d %H:%M")
        except Exception:
            ts = ts_raw[:16]

        intent_id = (e.get("intent_id") or "")[:16]
        score = float(e.get("similarity_score") or 0.0)
        score_str = f"{score:.2f}"
        if score >= 1.0:
            score_disp = f"[green]{score_str}[/green]"
        elif score > 0.8:
            score_disp = f"[yellow]{score_str}[/yellow]"
        else:
            score_disp = f"[red]{score_str}[/red]"

        status = e.get("fingerprint_status", "")
        if status == "match":
            status_disp = "[green]MATCH[/green]"
        elif status == "variant":
            status_disp = "[yellow]VARIANT[/yellow]"
        elif status == "accepted_variant":
            status_disp = "[dim]accepted_variant[/dim]"
        else:
            status_disp = status

        reason = e.get("dominant_reason") or "—"

        if agent_id:
            table.add_row(ts, intent_id, score_disp, status_disp, reason)
        else:
            table.add_row(ts, e.get("_agent", ""), intent_id, score_disp, status_disp, reason)

    console.print(table)
    console.print(f"\n[dim]{len(entries)} entries[/dim]")


# ─── compare ────────────────────────────────────────────────────────────────


@app.command()
def compare(
    current: list[Path] = typer.Argument(
        ...,
        help="Path(s) to current trace (.jsonl) or summary JSON. Accepts multiple files (shell glob).",
    ),
    baseline: Path = typer.Option(
        ...,
        "--baseline",
        "-b",
        help="Path to baseline (summary JSON, full baseline, or trace file)",
    ),
    agent_id: str = typer.Option("unknown", "--agent-id", "-a", help="Agent identifier"),
    policy_file: Path | None = typer.Option(
        None, "--policy", "-p", help="Path to policy YAML file"
    ),
    out: Path | None = typer.Option(None, "--out", "-o", help="Write JSON result to file"),
    enable_blocking: bool = typer.Option(
        True, "--enable-blocking/--no-blocking", help="Exit with code 1 on policy violations"
    ),
    attest: bool = typer.Option(
        False,
        "--attest",
        help="Submit attestation after comparison (requires SPOOLED_BACKEND_URL + SPOOLED_API_KEY)",
    ),
) -> None:
    """Compare trace(s) against a baseline and evaluate policy.

    Takes one or more captured traces (or summary JSON) and a baseline file.
    Computes fingerprint diff, metric drift, and evaluates policy.
    Outputs report and sets exit code for CI gating.

    When multiple traces are provided, each is compared independently and
    the worst exit code is used.

    Example:
       spooled ci compare .spooled/traces/run-123.jsonl --baseline baselines/my_agent.json
       spooled ci compare trace.jsonl -b baselines/ -a my_agent --out result.json
       spooled ci compare .spooled/traces/*.jsonl -b baselines/
    """
    within_limits = _check_paywall()

    worst_exit = 0
    results = []

    try:
        if len(current) > 1:
            console.print(f"[dim]Comparing {len(current)} traces against baseline...[/dim]\n")

        for trace_path in current:
            try:
                if not trace_path.exists():
                    console.print(f"[red]✗[/red] Current trace not found: {trace_path}")
                    worst_exit = max(worst_exit, 1)
                    continue

                # Load current trace
                current_trace = _load_trace(trace_path)

                # Auto-detect agent_id from trace if not specified
                effective_agent_id = agent_id
                if effective_agent_id == "unknown":
                    effective_agent_id = current_trace.get("trace", {}).get("agent_id", "unknown")

                # Load baseline
                baseline_path = baseline
                if baseline.is_dir():
                    # Look for agent-specific baseline in directory
                    candidate = baseline / f"{effective_agent_id}.json"
                    if candidate.exists():
                        baseline_path = candidate
                    else:
                        # No baseline for this agent — run comparison with no baseline
                        # (do NOT fall back to another agent's baseline file)
                        console.print(
                            f"[dim]  NO_BASELINE: no baseline for {effective_agent_id} in {baseline}[/dim]"
                        )
                        baseline_data = None
                        policy_engine = PolicyEngine(policy_file)
                        result = _compute_comparison(
                            current_trace, baseline_data, effective_agent_id, policy_engine
                        )
                        results.append(result)
                        try:
                            from spooled.usage import UsageTracker

                            UsageTracker().record_comparison()
                        except Exception as _exc:
                            logger.debug("Suppressed exception", error=str(_exc))

                            pass
                        _append_ci_history(result, cwd=Path.cwd())
                        result["baseline_path"] = str(baseline_path)
                        _display_compare_results(result)
                        if attest:
                            _submit_ci_attestation(result, current_trace)
                        exit_code = _determine_exit_code(result, enable_blocking)
                        worst_exit = max(worst_exit, exit_code)
                        continue

                if not baseline_path.exists():
                    console.print(f"[red]✗[/red] Baseline not found: {baseline_path}")
                    worst_exit = max(worst_exit, 1)
                    continue

                baseline_data = load_baseline_from_path(baseline_path, effective_agent_id)

                # Load policy
                policy_engine = PolicyEngine(policy_file)

                # Run comparison
                result = _compute_comparison(
                    current_trace, baseline_data, effective_agent_id, policy_engine
                )
                results.append(result)

                # Record usage for free tier enforcement
                try:
                    from spooled.usage import UsageTracker

                    UsageTracker().record_comparison()
                except Exception as _exc:
                    logger.debug("Suppressed exception", error=str(_exc))

                    pass

                # Persist to per-agent CI history for similarity trend tracking
                _append_ci_history(result, cwd=Path.cwd())

                # Display results
                result["baseline_path"] = str(baseline_path)
                _display_compare_results(result)

                # Submit attestation if --attest flag is set
                if attest:
                    _submit_ci_attestation(result, current_trace)

                # Track worst exit code
                exit_code = _determine_exit_code(result, enable_blocking)
                worst_exit = max(worst_exit, exit_code)

            except typer.Exit:
                raise
            except Exception as e:
                logger.debug("Compare failed for trace", trace=str(trace_path), error=str(e))
                console.print(f"[red]✗[/red] Compare failed for {trace_path.name}: {e}")
                worst_exit = max(worst_exit, 1)

        # Write combined output
        if out and results:
            out.parent.mkdir(parents=True, exist_ok=True)
            output_data = results[0] if len(results) == 1 else results
            with open(out, "w") as f:
                json.dump(output_data, f, indent=2, default=str)
            console.print(f"\n[dim]Result written to: {out}[/dim]")

        # Free-tier upsell: show what Pro adds (only when not already on a paid plan)
        if not within_limits or not os.getenv("SPOOLED_API_KEY"):
            console.print(
                "\n[dim]─── Automate this in CI? ──────────────────────────────[/dim]\n"
                "[dim]Pro adds: [cyan]ci run[/cyan] (batch + exit codes) · "
                "GitHub Action (PR comments + merge blocking) · "
                "content-blind quality signals · hosted dashboard[/dim]\n"
                "[dim]→ https://spooled.ai/#pricing[/dim]"
            )

        raise typer.Exit(code=worst_exit)

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Compare failed", error=str(e))
        console.print(f"[red]✗[/red] Compare failed: {e}")
        raise typer.Exit(code=1)


def _submit_ci_attestation(result: dict[str, Any], trace_data: dict[str, Any]) -> None:
    """Submit attestation after CI comparison if backend is configured."""
    backend_url = os.getenv("SPOOLED_BACKEND_URL", "")
    api_key = os.getenv("SPOOLED_API_KEY", "")
    if not backend_url or not api_key:
        console.print(
            "[dim]  Attestation skipped: SPOOLED_BACKEND_URL or SPOOLED_API_KEY not set[/dim]"
        )
        return

    try:
        from spooled.attest import save_receipt, submit_attestation

        agent_id = result.get("agent_id", "unknown")
        fp_hash = result.get("fingerprint_hash", "")
        chain_hash = trace_data.get("trace", {}).get("chain_hash")
        run_id = trace_data.get("trace", {}).get("run_id")

        # Extract scores from result
        spooled = result.get("spooled_score", {})
        spooled_score_val = spooled.get("score") if isinstance(spooled, dict) else None
        spooled_grade_val = spooled.get("grade") if isinstance(spooled, dict) else None

        drift_score = None
        similarity = result.get("similarity_score")
        if similarity is not None:
            drift_score = float(similarity)

        # Extract metrics
        deltas = result.get("metric_deltas", {})
        metrics: dict[str, Any] = {}
        if "tokens" in deltas:
            metrics["total_tokens"] = deltas["tokens"].get("current", 0)
        if "step_count" in deltas:
            metrics["step_count"] = deltas["step_count"].get("current", 0)

        att_result = submit_attestation(
            agent_id=agent_id,
            fingerprint_hash=fp_hash,
            chain_hash=chain_hash,
            drift_score=drift_score,
            spooled_score=spooled_score_val,
            spooled_grade=spooled_grade_val,
            metrics=metrics,
            run_id=run_id,
            backend_url=backend_url,
            api_key=api_key,
        )

        att_id = att_result.get("attestation_id", "unknown")
        receipt = att_result.get("receipt", {})
        save_receipt(receipt)
        console.print(f"  [green]Attestation submitted: {att_id}[/green]")

    except Exception as e:
        console.print(f"  [yellow]Attestation failed (non-blocking): {e}[/yellow]")


def _display_compare_results(result: dict[str, Any]) -> None:
    """Display comparison results to console in a Rich Panel."""
    from rich.panel import Panel

    summary = result["summary"]
    fp_status = result["fingerprint_status"]
    fp_hash = result.get("fingerprint_hash", "")[:16]
    agent_id = result.get("agent_id", "unknown")

    # Fingerprint status
    status_icon = {
        "match": "[green]MATCH[/green]",
        "accepted_variant": "[green]ACCEPTED VARIANT[/green]",
        "variant": "[yellow]VARIANT[/yellow]",
        "new": "[yellow]NEW[/yellow]",
        "no_baseline": "[dim]NO BASELINE[/dim]",
    }.get(fp_status, fp_status)

    baseline_fp_hash = result.get("baseline_fingerprint_hash", "")
    baseline_path = result.get("baseline_path", "")

    panel_lines = []
    panel_lines.append(f"Fingerprint: {fp_hash}...  {status_icon}")

    # Show baseline intent ID and accept command for variants/new behaviors
    if fp_status in ("variant", "new") and baseline_fp_hash:
        baseline_intent_short = baseline_fp_hash[:16]
        panel_lines.append(f"Baseline intent: {baseline_intent_short}...")
        bp_flag = f" -b {baseline_path}" if baseline_path else ""
        panel_lines.append(
            f"[dim]Accept with:[/dim] spooled ci accept-variant "
            f"--intent {baseline_intent_short} --fingerprint {fp_hash}{bp_flag}"
        )

    # Spooled Score
    spooled = result.get("spooled_score", {})
    if spooled and spooled.get("score") is not None:
        sc = spooled["score"]
        grade = spooled.get("grade", "-")
        confidence = spooled.get("confidence", "low")
        color = {"A": "green", "B": "green", "C": "yellow", "D": "red", "F": "red"}.get(
            grade, "white"
        )
        panel_lines.append(
            f"Spooled Score: [{color}]{sc}/100 ({grade})[/{color}]  [dim]confidence: {confidence}[/dim]"
        )

    panel_lines.append("")

    # Metric deltas
    deltas = result.get("metric_deltas", {})
    if "tokens" in deltas:
        t = deltas["tokens"]
        sign = "+" if t["delta"] >= 0 else ""
        color = (
            "red" if abs(t["delta_pct"]) > 20 else "yellow" if abs(t["delta_pct"]) > 10 else "green"
        )
        panel_lines.append(
            f"Tokens:  {t['current']:,.0f} ({sign}{t['delta']:.0f}, [{color}]{sign}{t['delta_pct']}%[/{color}])"
        )
    if "step_count" in deltas:
        s = deltas["step_count"]
        sign = "+" if s["delta"] >= 0 else ""
        panel_lines.append(f"Steps:   {s['current']} ({sign}{s['delta']})")

    # Tool diff
    td = result.get("tool_diff")
    if td and (td.get("added") or td.get("removed")):
        panel_lines.append("")
        panel_lines.append("Tool Changes:")
        if td.get("removed"):
            panel_lines.append(f"  [red]Removed:[/red] {', '.join(td['removed'])}")
        if td.get("added"):
            panel_lines.append(f"  [green]Added:[/green]   {', '.join(td['added'])}")
        if td.get("baseline_sequence") and td.get("current_sequence"):
            panel_lines.append(f"  Baseline seq: {td['baseline_sequence']}")
            panel_lines.append(f"  Current  seq: {td['current_sequence']}")
    elif td and td.get("current_sequence") != td.get("baseline_sequence"):
        panel_lines.append("")
        panel_lines.append("Tool Changes: [yellow]Sequence reordered[/yellow]")

    panel_lines.append("")

    # Signals
    signal_count = summary["signal_count"]
    if signal_count > 0:
        severity = summary["severity"]
        color = {"high": "red", "medium": "yellow", "low": "green"}.get(severity, "white")
        panel_lines.append(
            f"Signals: [{color}]{signal_count} detected (severity: {severity})[/{color}]"
        )
    else:
        panel_lines.append("Signals: [green]none[/green]")

    # Policy
    if summary.get("policy_enabled"):
        if summary["policy_passed"]:
            panel_lines.append("Policy:  [green]PASSED[/green]")
        else:
            violations = summary.get("policy_violations", 0)
            panel_lines.append(f"Policy:  [red]FAILED ({violations} violations)[/red]")
            if summary.get("should_block"):
                panel_lines.append("[red]BLOCKED - merge will be prevented[/red]")

    # Overall result for subtitle
    if summary.get("should_block"):
        result_str = "[red]FAIL[/red]"
        border_style = "red"
    elif fp_status == "new":
        result_str = "[yellow]NEW BEHAVIOR[/yellow]"
        border_style = "yellow"
    else:
        result_str = "[green]PASS[/green]"
        border_style = "green"

    content = "\n".join(panel_lines)
    panel = Panel(
        content,
        title=f"[bold]{agent_id}[/bold]",
        subtitle=result_str,
        border_style=border_style,
        padding=(0, 2),
    )
    console.print(panel)


def _display_ci_summary(
    results: list[dict[str, Any]],
    ci_summary: dict[str, Any],
    out: Path,
) -> None:
    """Display CI summary table — shared by `run` and `batch_compare`."""
    from rich.table import Table

    table = Table(show_header=True, header_style="bold")
    table.add_column("Agent")
    table.add_column("Status")
    table.add_column("Score", justify="right")
    table.add_column("Signals", justify="right")
    table.add_column("Tokens")

    for r in results:
        agent = r.get("agent_id", "unknown")
        fp_status = r.get("fingerprint_status", "unknown")

        status_map = {
            "match": "[green]MATCH[/green]",
            "accepted_variant": "[green]ACCEPTED[/green]",
            "variant": "[yellow]VARIANT[/yellow]",
            "new": "[yellow]NEW[/yellow]",
            "no_baseline": "[dim]NO BASELINE[/dim]",
            "not_compared": "[dim]POLICY-ONLY[/dim]",
        }
        status_str = status_map.get(fp_status, fp_status)

        # Score
        trace_score = (
            r.get("spooled_score", {}).get("score")
            if isinstance(r.get("spooled_score"), dict)
            else r.get("summary", {}).get("spooled_score")
        )
        grade = (
            r.get("spooled_score", {}).get("grade", "")
            if isinstance(r.get("spooled_score"), dict)
            else ""
        )
        if trace_score is not None:
            color = {"A": "green", "B": "green", "C": "yellow", "D": "red", "F": "red"}.get(
                grade, "white"
            )
            score_str = f"[{color}]{trace_score} ({grade})[/{color}]"
        else:
            score_str = "-"

        # Signals
        signal_count = r.get("summary", {}).get("signal_count", 0)
        signal_str = str(signal_count) if signal_count > 0 else "[green]0[/green]"

        # Token delta
        token_str = "-"
        deltas = r.get("metric_deltas", {})
        if "tokens" in deltas:
            t = deltas["tokens"]
            sign = "+" if t.get("delta", 0) >= 0 else ""
            pct = t.get("delta_pct", 0)
            color = "red" if abs(pct) > 20 else "yellow" if abs(pct) > 10 else "green"
            token_str = f"[{color}]{sign}{pct}%[/{color}]"

        table.add_row(agent, status_str, score_str, signal_str, token_str)

    console.print(table)

    # Agent-level Spooled Score
    _agent_score = ci_summary.get("spooled_score", {})
    if _agent_score and _agent_score.get("score") is not None:
        _sc = _agent_score["score"]
        _gr = _agent_score["grade"]
        _color = {"A": "green", "B": "green", "C": "yellow", "D": "red", "F": "red"}.get(
            _gr, "white"
        )
        console.print(f"  [{_color}]Spooled Score: {_sc}/100 ({_gr})[/{_color}]")

    console.print(f"  Reports written to: {out}/")


def _display_ci_result(overall_exit: int) -> None:
    """Display final CI PASS/FAIL banner in a Rich Panel."""
    from rich.panel import Panel

    if overall_exit == 0:
        panel = Panel(
            "[bold green]CI RESULT: PASS[/bold green]",
            border_style="green",
            padding=(0, 4),
        )
    else:
        panel = Panel(
            "[bold red]CI RESULT: FAIL[/bold red]",
            border_style="red",
            padding=(0, 4),
        )
    console.print(panel)


# ─── update-baseline ────────────────────────────────────────────────────────


@app.command("update-baseline")
def update_baseline(
    trace_dir: Path | None = typer.Option(
        None, "--from", help="Directory containing traces (default: .spooled/traces/)"
    ),
    out: Path = typer.Option(
        Path("baselines"), "--out", "-o", help="Output directory for baseline summaries"
    ),
    agent_id: str | None = typer.Option(
        None, "--agent-id", "-a", help="Filter to specific agent (default: all agents)"
    ),
    min_runs: int = typer.Option(0, "--min-runs", help="Minimum runs per intent (0 = no gate)"),
    max_error_rate: float = typer.Option(
        1.0, "--max-error-rate", help="Max error rate 0-1 (1.0 = no gate)"
    ),
    max_cv: float = typer.Option(
        float("inf"), "--max-cv", help="Max latency coefficient of variation (inf = no gate)"
    ),
) -> None:
    """Generate compact baseline summaries from traces.

    Reads traces from .spooled/traces/ (or specified dir), groups by agent,
    computes fingerprints and metrics, and writes git-committable baseline
    summary JSON files to the output directory.

    Optional quality gates (--min-runs, --max-error-rate, --max-cv) filter out
    intents that don't yet have enough consistent observations.

    Example:
       spooled ci update-baseline
       spooled ci update-baseline --from .spooled/traces/ --out .github/baselines/
       spooled ci update-baseline --min-runs 5 --max-error-rate 0.2 --max-cv 0.5
    """
    import json as _json

    from rich.panel import Panel as _Panel

    from spooled.models import BaselineSummary as _BaselineSummary

    try:
        source_dir = trace_dir or get_trace_directory()
        if not source_dir.exists():
            console.print(f"[red]✗[/red] Trace directory not found: {source_dir}")
            raise typer.Exit(code=1)

        trace_files = _find_all_traces(source_dir)
        if not trace_files:
            console.print(f"[red]✗[/red] No trace files found in: {source_dir}")
            raise typer.Exit(code=1)

        console.print(f"[dim]Found {len(trace_files)} trace files in {source_dir}[/dim]")

        # Auto-clean persistent baseline cache to prevent double-counting.
        # The recorder writes to .spooled/traces/baselines/ during execution;
        # update-baseline rebuilds from raw traces so stale cache must be cleared.
        cache_dir = source_dir / "baselines"
        if cache_dir.exists():
            import shutil

            shutil.rmtree(cache_dir)
            cache_dir.mkdir(parents=True, exist_ok=True)
            logger.debug("Cleared baseline cache", path=str(cache_dir))

        gates_active = min_runs > 0 or max_error_rate < 1.0 or max_cv < float("inf")

        # Group traces by agent_id and build baselines
        agents: dict[str, BaselineManager] = {}
        processed = 0
        skipped = 0

        for tf in trace_files:
            try:
                trace_data = _load_trace(tf)
                trace_agent_id = trace_data.get("trace", {}).get("agent_id", "unknown")

                # Filter by agent_id if specified
                if agent_id and trace_agent_id != agent_id:
                    continue

                if trace_agent_id not in agents:
                    mgr = BaselineManager(trace_agent_id)
                    # Start with a fresh baseline to avoid double-counting runs
                    # already accumulated by the recorder's persistent cache.
                    mgr._baseline = AgentBaseline(
                        agent_id=trace_agent_id,
                        updated_at=datetime.now(timezone.utc),
                        intents={},
                    )
                    agents[trace_agent_id] = mgr

                # Collect tags from traces (union of all tags seen for this agent)
                trace_tags = trace_data.get("trace", {}).get("tags", [])
                if trace_tags:
                    existing = set(agents[trace_agent_id].tags)
                    for t in trace_tags:
                        if t not in existing:
                            agents[trace_agent_id].tags.append(t)
                            existing.add(t)

                status = trace_data.get("trace", {}).get("status", "UNKNOWN")
                agents[trace_agent_id].add_to_baseline(trace_data, status)

                # Enrich with step count and tool call counts
                _enrich_baseline_stats(agents[trace_agent_id], trace_data)

                processed += 1
            except Exception as e:
                logger.debug("Skipping trace file", path=str(tf), error=str(e))
                skipped += 1

        if not agents:
            console.print("[red]✗[/red] No traces matched the filter criteria")
            raise typer.Exit(code=1)

        # Snapshot existing summaries before overwriting (for diff narrative + first-time detection)
        old_summaries: dict[str, Any] = {}
        out.mkdir(parents=True, exist_ok=True)
        for aid in agents:
            old_path = out / f"{aid}.json"
            if old_path.exists():
                try:
                    with open(old_path) as _f:
                        old_summaries[aid] = _BaselineSummary(**_json.load(_f))
                except Exception as _exc:
                    logger.debug("Suppressed exception", error=str(_exc))

                    pass

        is_first_time = len(old_summaries) == 0

        # Inject similarity_trend from ci-history into RunStatistics before writing
        from collections import defaultdict as _dd

        from spooled.models import SimilarityTrendPoint as _STP

        _ci_history_dir = (source_dir).parent / "ci-history"
        for _aid, _mgr in agents.items():
            _hf = _ci_history_dir / f"{_aid}.jsonl"
            if not _hf.exists():
                continue
            try:
                _entries = [
                    json.loads(line) for line in _hf.read_text().splitlines() if line.strip()
                ]
            except Exception as _exc:
                logger.debug("Suppressed exception", error=str(_exc))

                continue
            _by_intent: dict = _dd(list)
            for _e in _entries:
                _by_intent[_e.get("intent_id", "")].append(_e)
            _baseline = _mgr.load_baseline()
            for _iid, _stat in _baseline.intents.items():
                _recent = _by_intent.get(_iid, [])[-30:]
                _stat.similarity_trend = [_STP(**_e) for _e in _recent]
            _mgr._baseline = _baseline

        # Write baseline summaries (with optional quality gates)
        written = []
        held_back_total = 0

        for aid, manager in agents.items():
            if gates_active:
                full_baseline = manager.load_baseline()

                # Auto-merge similar intents before applying quality gates.
                # This collapses structurally similar fingerprints (e.g. same tools,
                # different order) into a single intent, making min-runs achievable
                # for non-deterministic LLM agents.
                from spooled.baseline import auto_merge_intents as _auto_merge

                merged = _auto_merge(full_baseline, similarity_threshold=0.8)
                if merged:
                    console.print(f"\n  [dim]{aid}: merged {merged} similar intent(s)[/dim]")
                    manager._baseline = full_baseline

                promoted_ids = []
                held_back = []

                for intent_id, stat in full_baseline.intents.items():
                    reasons = []
                    if stat.sample_count < min_runs:
                        reasons.append(f"only {stat.sample_count}/{min_runs} runs")
                    if stat.error_rate > max_error_rate:
                        reasons.append(f"error_rate {stat.error_rate:.0%} > {max_error_rate:.0%}")
                    if stat.avg_latency > 0 and stat.std_dev_latency > 0:
                        cv = stat.std_dev_latency / stat.avg_latency
                        if cv > max_cv:
                            reasons.append(f"latency CV={cv:.2f} > {max_cv}")
                    if reasons:
                        held_back.append((intent_id, reasons))
                    else:
                        promoted_ids.append(intent_id)

                held_back_total += len(held_back)

                if not promoted_ids:
                    console.print(f"\n[yellow]{aid}[/yellow]: no intents meet quality gates")
                    for intent_id, reasons in held_back:
                        console.print(f"  [dim]held[/dim] {intent_id[:16]}: {'; '.join(reasons)}")
                    continue

                from datetime import datetime as _dt
                from datetime import timezone as _tz

                from spooled.models import AgentBaseline as _AgentBaseline

                pruned = _AgentBaseline(
                    agent_id=full_baseline.agent_id,
                    updated_at=_dt.now(_tz.utc),
                    intents={iid: full_baseline.intents[iid] for iid in promoted_ids},
                )
                # Carry similarity_trend from full_baseline into pruned intents
                for _iid, _stat in pruned.intents.items():
                    if not _stat.similarity_trend:
                        _stat.similarity_trend = full_baseline.intents[_iid].similarity_trend
                # Carry over accepted_fingerprints and accepted_variants from
                # the existing baseline so that `accept-variant` provenance is
                # not lost when update-baseline is re-run for sparkline updates
                # or other reasons.
                if aid in old_summaries:
                    old = old_summaries[aid]
                    for iid, stat in pruned.intents.items():
                        old_intent = old.intents.get(iid)
                        if old_intent:
                            existing_fps = set(stat.accepted_fingerprints or [])
                            for fp in old_intent.accepted_fingerprints or []:
                                existing_fps.add(fp)
                            stat.accepted_fingerprints = sorted(existing_fps)
                            existing_av_hashes = {
                                av.fingerprint_hash for av in (stat.accepted_variants or [])
                            }
                            for av in old_intent.accepted_variants or []:
                                if av.fingerprint_hash not in existing_av_hashes:
                                    stat.accepted_variants.append(av)

                pruned_manager = BaselineManager(aid)
                pruned_manager._baseline = pruned
                # Merge tags from traces + old summary
                pruned_manager.tags = list(manager.tags)
                if aid in old_summaries and old_summaries[aid].tags:
                    existing = set(pruned_manager.tags)
                    for t in old_summaries[aid].tags:
                        if t not in existing:
                            pruned_manager.tags.append(t)
                            existing.add(t)
                output_path = out / f"{aid}.json"
                summary = pruned_manager.save_summary(output_path)
                written.append((aid, output_path, len(summary.intents), summary))

                if held_back:
                    console.print(f"  [dim]held back {len(held_back)} intent(s):[/dim]")
                    for intent_id, reasons in held_back:
                        console.print(f"    [dim]{intent_id[:16]}[/dim]: {'; '.join(reasons)}")
            else:
                # Carry over accepted_fingerprints and accepted_variants from
                # the existing baseline (same reason as the gates_active path).
                if aid in old_summaries:
                    old = old_summaries[aid]
                    mgr_baseline = manager.load_baseline()
                    for iid, stat in mgr_baseline.intents.items():
                        old_intent = old.intents.get(iid)
                        if old_intent:
                            existing_fps = set(stat.accepted_fingerprints or [])
                            for fp in old_intent.accepted_fingerprints or []:
                                existing_fps.add(fp)
                            stat.accepted_fingerprints = sorted(existing_fps)
                            existing_av_hashes = {
                                av.fingerprint_hash for av in (stat.accepted_variants or [])
                            }
                            for av in old_intent.accepted_variants or []:
                                if av.fingerprint_hash not in existing_av_hashes:
                                    stat.accepted_variants.append(av)
                    manager._baseline = mgr_baseline

                # Merge tags from old summary
                if aid in old_summaries and old_summaries[aid].tags:
                    existing = set(manager.tags)
                    for t in old_summaries[aid].tags:
                        if t not in existing:
                            manager.tags.append(t)
                            existing.add(t)

                output_path = out / f"{aid}.json"
                summary = manager.save_summary(output_path)
                written.append((aid, output_path, len(summary.intents), summary))

        console.print(
            f"\n[green]Baselines updated[/green] ({processed} traces processed, {skipped} skipped)"
        )
        for aid, path, intent_count, new_summary in written:
            console.print(f"  {aid}: {path} ({intent_count} intents)")

            # Diff narrative
            if aid in old_summaries:
                diff = baseline_diff(old_summaries[aid], new_summary)
                if diff["added"]:
                    console.print(f"    [green]+[/green] {len(diff['added'])} new intent(s)")
                    for entry in diff["added"]:
                        console.print(
                            f"      [dim]{entry['intent_id'][:16]}[/dim] (new behavior pattern)"
                        )
                if diff["removed"]:
                    console.print(f"    [red]-[/red] {len(diff['removed'])} removed intent(s)")
                    for entry in diff["removed"]:
                        console.print(
                            f"      [dim]{entry['intent_id'][:16]}[/dim] (no longer observed)"
                        )
                if diff["changed"]:
                    console.print(
                        f"    [yellow]~[/yellow] {len(diff['changed'])} changed intent(s)"
                    )
                    for entry in diff["changed"]:
                        iid = entry["intent_id"][:16]
                        parts = []
                        for metric, vals in entry["deltas"].items():
                            if metric == "run_count":
                                parts.append(f"runs {vals['old']}→{vals['new']}")
                            elif "delta_pct" in vals:
                                sign = "+" if vals["delta_pct"] > 0 else ""
                                parts.append(f"{metric} {sign}{vals['delta_pct']}%")
                            elif "delta" in vals:
                                sign = "+" if vals["delta"] > 0 else ""
                                parts.append(f"{metric} {sign}{vals['delta']:.3f}")
                        console.print(f"      [dim]{iid}[/dim]: {', '.join(parts)}")
                if not any([diff["added"], diff["removed"], diff["changed"]]):
                    console.print("    [dim](no significant changes)[/dim]")

        # Clustering suggestions: flag intents that could share an intent bucket
        for aid, manager in agents.items():
            baseline = manager.load_baseline()
            if len(baseline.intents) < 2:
                continue
            clusters = cluster_intents(baseline, similarity_threshold=0.8)
            mergeable = [c for c in clusters if len(c) > 1]
            if mergeable:
                console.print(f"\n[yellow]Intent clustering suggestions for {aid}:[/yellow]")
                for cluster in mergeable:
                    short_ids = [cid[:16] for cid in cluster]
                    console.print(
                        f"  [dim]Similar intents (consider accept-variant):[/dim] {', '.join(short_ids)}"
                    )

        # Next-steps panel
        n_agents = len(written)
        out_str = str(out)
        if is_first_time and n_agents > 0:
            console.print()
            console.print(
                _Panel(
                    f"[bold green]✓ Created baselines for {n_agents} agent(s)[/bold green]\n\n"
                    f"[bold]Next:[/bold]\n"
                    f"  git add {out_str}/ && git commit -m 'Add AI baselines'\n\n"
                    "Push your branch — CI will now track behavior.\n"
                    "Run [cyan]spooled doctor[/cyan] to verify setup at any time.",
                    title="First-time setup complete",
                    border_style="green",
                )
            )
        elif not is_first_time and n_agents > 0:
            console.print()
            console.print(
                _Panel(
                    f"[bold green]✓ Updated baselines for {n_agents} agent(s)[/bold green]\n\n"
                    "Review the diff above, then:\n"
                    f"  git add {out_str}/ && git commit -m 'Update AI baselines'",
                    title="Baselines refreshed",
                    border_style="green",
                )
            )

        raise typer.Exit(code=0)

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Update baseline failed", error=str(e))
        console.print(f"[red]✗[/red] Failed: {e}")
        raise typer.Exit(code=1)


# ─── promote ─────────────────────────────────────────────────────────────────


@app.command("promote")
def promote_baseline(
    trace_dir: Path | None = typer.Option(
        None, "--from", help="Directory containing traces (default: .spooled/traces/)"
    ),
    out: Path = typer.Option(
        Path("baselines"), "--out", "-o", help="Output directory for promoted baseline summaries"
    ),
    agent_id: str | None = typer.Option(
        None, "--agent-id", "-a", help="Filter to specific agent (default: all agents)"
    ),
    min_runs: int = typer.Option(
        5,
        "--min-runs",
        "-n",
        help="Minimum number of consistent runs required to promote an intent",
    ),
    max_error_rate: float = typer.Option(
        0.2, "--max-error-rate", help="Maximum error rate allowed for promotion (0.0-1.0)"
    ),
    max_cv: float = typer.Option(
        0.5,
        "--max-cv",
        help="Maximum coefficient of variation (std_dev/avg) for latency consistency check",
    ),
) -> None:
    """[Deprecated] Promote intents to baseline with quality gates.

    .. deprecated::
        Use ``spooled ci update-baseline`` with gate flags instead::

            spooled ci update-baseline --min-runs 5 --max-error-rate 0.2 --max-cv 0.5
    """
    import warnings

    warnings.warn(
        "spooled ci promote is deprecated — use spooled ci update-baseline instead",
        DeprecationWarning,
        stacklevel=2,
    )
    console.print(
        "[yellow]⚠[/yellow]  `promote` is deprecated. Use: "
        "update-baseline --min-runs 5 --max-error-rate 0.2 --max-cv 0.5"
    )
    ctx = typer.get_current_context()
    ctx.invoke(
        update_baseline,
        trace_dir=trace_dir,
        out=out,
        agent_id=agent_id,
        min_runs=min_runs,
        max_error_rate=max_error_rate,
        max_cv=max_cv,
    )


def _enrich_baseline_stats(manager: BaselineManager, trace_data: dict[str, Any]) -> None:
    """Enrich baseline stats with step_count, tool_call_counts, etc.

    Called after add_to_baseline to fill in the new fields.
    """
    baseline = manager.load_baseline()
    interactions = trace_data.get("interactions", [])
    fp = BehavioralFingerprint(trace_data)
    fp_data = fp.generate()
    intent_id = hash_fingerprint(fp_data)

    if intent_id not in baseline.intents:
        return

    stat = baseline.intents[intent_id]

    # Step count (use latest)
    stat.step_count = len(interactions)

    # Fingerprint hash
    if not stat.fingerprint_hash:
        stat.fingerprint_hash = intent_id

    # Accepted fingerprints (initialize if empty)
    if not stat.accepted_fingerprints:
        stat.accepted_fingerprints = [intent_id]

    # Tool call counts
    tool_counts: dict[str, int] = {}
    total_prompt = 0
    total_completion = 0
    total_tokens = 0
    for interaction in interactions:
        if interaction.get("interaction_type") == "TOOL_CALL":
            tool_name = interaction.get("input", {}).get("function", "unknown")
            tool_counts[tool_name] = tool_counts.get(tool_name, 0) + 1
        if interaction.get("interaction_type") == "LLM_CALL":
            usage = interaction.get("output", {}).get("usage") or interaction.get(
                "metadata", {}
            ).get("usage")
            if usage and isinstance(usage, dict):
                total_prompt += usage.get("prompt_tokens", 0)
                total_completion += usage.get("completion_tokens", 0)
                total_tokens += usage.get("total_tokens", 0)

    stat.tool_call_counts = tool_counts
    stat.token_totals = {
        "prompt_tokens": total_prompt,
        "completion_tokens": total_completion,
        "total_tokens": total_tokens,
    }

    # Latency bounds from runs
    if stat.runs:
        latencies = [
            float(r.get("total_latency_ms", 0))
            for r in stat.runs
            if r.get("total_latency_ms") is not None
        ]
        if latencies:
            sorted_lats = sorted(latencies)
            p95_idx = max(0, int(len(sorted_lats) * 0.95) - 1)
            stat.latency_bounds = {
                "min_ms": sorted_lats[0],
                "max_ms": sorted_lats[-1],
                "avg_ms": stat.avg_latency,
                "p95_ms": sorted_lats[p95_idx],
            }

    manager.save_baseline(baseline)


# ─── run ─────────────────────────────────────────────────────────────────────


@app.command()
def run(
    suite: Path = typer.Option(
        ..., "--suite", "-s", help="Path to test suite (Python module or directory of test scripts)"
    ),
    baseline: Path | None = typer.Option(
        None, "--baseline", "-b", help="Path to baseline (summary JSON or directory)"
    ),
    policy_file: Path | None = typer.Option(
        None, "--policy", "-p", help="Path to policy YAML file"
    ),
    out: Path = typer.Option(Path("ci-report"), "--out", "-o", help="Output directory for reports"),
    agent_id: str | None = typer.Option(
        None, "--agent-id", "-a", help="Agent identifier (auto-detected from traces if not set)"
    ),
    enable_blocking: bool = typer.Option(
        True, "--enable-blocking/--no-blocking", help="Exit with code 1 on policy violations"
    ),
    retries: int = typer.Option(
        1, "--retries", "-r", help="Rerun count for flaky metric signals (2 = 2-pass verification)"
    ),
    push: bool = typer.Option(False, "--push", help="Upload CI report to backend after generation"),
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend API URL (overrides SPOOLED_BACKEND_URL env var)"
    ),
) -> None:
    """Run a test suite and compare against baseline.

    This is the single command teams put in their CI YAML. It:
    1. Executes the test suite (Python module or directory)
    2. Captures traces for each test
    3. Computes fingerprints and metrics
    4. Compares against baseline
    5. Evaluates policy
    6. Outputs: exit code + markdown report + JSON summary

    Example:
       spooled ci run --suite tests/ai/ --baseline baselines/ --policy .spooled/policy.yml
       spooled ci run -s tests/ai/test_agent.py -b baselines/my_agent.json -o ci-report/
    """
    # ci run is a free local operation; --push (backend report sync) is the only
    # part that requires Pro, and it's enforced when called.
    try:
        if not suite.exists():
            console.print(f"[red]✗[/red] Test suite not found: {suite}")
            raise typer.Exit(code=1)

        # Step 1: Run test suite
        console.print(f"[bold]Step 1/4:[/bold] Running test suite: {suite}")
        exit_code = _run_test_suite(suite)
        if exit_code != 0:
            console.print(f"[red]✗[/red] Test suite failed with exit code {exit_code}")
            # Continue to analyze whatever traces were produced
            console.print("[dim]Analyzing traces from partial run...[/dim]")

        # Step 2: Find captured traces
        console.print("[bold]Step 2/4:[/bold] Collecting traces...")
        trace_dir = get_trace_directory()
        trace_files = _find_all_traces(trace_dir)

        if not trace_files:
            console.print("[red]✗[/red] No traces captured. Is the SDK initialized in your tests?")
            raise typer.Exit(code=1)

        console.print(f"  Found {len(trace_files)} trace(s)")

        # Step 3: Compare each trace against baseline
        console.print("[bold]Step 3/4:[/bold] Comparing against baseline...")
        policy_engine = PolicyEngine(policy_file)
        results: list[dict[str, Any]] = []
        overall_exit = 0

        for tf in trace_files:
            try:
                trace_data = _load_trace(tf)
                trace_agent = trace_data.get("trace", {}).get("agent_id", agent_id or "unknown")

                # Load baseline for this agent
                baseline_data = None
                if baseline:
                    baseline_path = baseline
                    if baseline.is_dir():
                        candidate = baseline / f"{trace_agent}.json"
                        if candidate.exists():
                            baseline_path = candidate
                        else:
                            continue
                    if baseline_path.exists():
                        baseline_data = load_baseline_from_path(baseline_path, trace_agent)

                result = _compute_comparison(trace_data, baseline_data, trace_agent, policy_engine)
                result["trace_file"] = str(tf)
                results.append(result)

                # Record usage for free tier enforcement
                try:
                    from spooled.usage import UsageTracker

                    UsageTracker().record_comparison()
                except Exception as _exc:
                    logger.debug("Suppressed exception", error=str(_exc))

                    pass

                ec = _determine_exit_code(result, enable_blocking)
                if ec != 0:
                    overall_exit = 1

            except Exception as e:
                logger.debug("Skipping trace", path=str(tf), error=str(e))

        if not results:
            console.print("[red]✗[/red] No traces could be analyzed")
            raise typer.Exit(code=1)

        # 2-pass verification: rerun if failures are metric-only and retries > 1
        if retries > 1 and overall_exit != 0 and _are_failures_metric_only(results):
            console.print(
                f"\n[yellow]Metric-only failures detected — rerunning for 2-pass verification ({retries - 1} retry)...[/yellow]"
            )
            _clear_traces(trace_dir)

            # Rerun suite
            exit_code = _run_test_suite(suite)

            # Recollect and recompare
            trace_files = _find_all_traces(trace_dir)
            if trace_files:
                results = []
                overall_exit = 0
                for tf in trace_files:
                    try:
                        trace_data = _load_trace(tf)
                        trace_agent = trace_data.get("trace", {}).get(
                            "agent_id", agent_id or "unknown"
                        )

                        baseline_data = None
                        if baseline:
                            baseline_path = baseline
                            if baseline.is_dir():
                                candidate = baseline / f"{trace_agent}.json"
                                if candidate.exists():
                                    baseline_path = candidate
                                else:
                                    continue
                            if baseline_path.exists():
                                baseline_data = load_baseline_from_path(baseline_path, trace_agent)

                        result = _compute_comparison(
                            trace_data, baseline_data, trace_agent, policy_engine
                        )
                        result["trace_file"] = str(tf)
                        results.append(result)

                        ec = _determine_exit_code(result, enable_blocking)
                        if ec != 0:
                            overall_exit = 1
                    except Exception as e:
                        logger.debug("Skipping trace on retry", path=str(tf), error=str(e))

                if _are_failures_metric_only(results) and overall_exit != 0:
                    console.print(
                        "[yellow]Metric signals reproduced on retry — confirming failure[/yellow]"
                    )
                elif overall_exit == 0:
                    console.print(
                        "[green]Metric signals did not reproduce on retry — passing[/green]"
                    )

        # Step 4: Generate reports
        console.print("[bold]Step 4/4:[/bold] Generating reports...")
        out.mkdir(parents=True, exist_ok=True)

        # Generate a report ID upfront so it can be included in markdown
        import uuid

        ci_report_id = str(uuid.uuid4()) if push else None

        # JSON summary
        summary_path = out / "summary.json"
        ci_summary = _build_ci_summary(results)
        if ci_report_id:
            ci_summary["ci_report_id"] = ci_report_id
        with open(summary_path, "w") as f:
            json.dump(ci_summary, f, indent=2, default=str)

        # Markdown report
        md_path = out / "report.md"
        baseline_dir_str = (
            str(baseline)
            if baseline and baseline.is_dir()
            else str(baseline.parent) if baseline else "baselines"
        )
        md_content = _build_ci_markdown(ci_summary, results, baseline_dir=baseline_dir_str)
        with open(md_path, "w") as f:
            f.write(md_content)

        # Per-trace results (sanitize before writing to disk)
        for i, result in enumerate(results):
            sanitized = _sanitize_artifact_result(result)
            result_path = out / f"trace-{i}.json"
            with open(result_path, "w") as f:
                json.dump(sanitized, f, indent=2, default=str)

        # Push to backend if requested
        if push:
            _push_ci_report(ci_summary, results, backend_url, ci_report_id)

        # Display summary
        _display_ci_summary(results, ci_summary, out)
        _display_ci_result(overall_exit)

        raise typer.Exit(code=overall_exit)

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("CI run failed", error=str(e))
        console.print(f"[red]✗[/red] CI run failed: {e}")
        raise typer.Exit(code=1)


# ─── fetch-traces (Pattern 4) ──────────────────────────────────────────────


def _parse_since(since: str) -> str:
    """Parse a --since value into an ISO 8601 timestamp.

    Accepts duration strings ("24h", "7d", "30d") or ISO timestamps.
    """
    import re
    from datetime import timedelta

    match = re.match(r"^(\d+)(h|d|m)$", since.strip())
    if match:
        value, unit = int(match.group(1)), match.group(2)
        delta = {
            "h": timedelta(hours=value),
            "d": timedelta(days=value),
            "m": timedelta(minutes=value),
        }[unit]
        return (datetime.now(timezone.utc) - delta).isoformat()
    return since


@app.command("fetch-traces")
def fetch_traces(
    agent_id: str = typer.Option(
        ..., "--agent-id", "-a", help="Agent identifier to fetch traces for"
    ),
    since: str = typer.Option(
        "24h",
        "--since",
        "-s",
        help="Time window: duration ('24h', '7d') or ISO timestamp",
    ),
    commit_sha: str | None = typer.Option(
        None, "--commit-sha", "-c", help="Filter by git commit SHA prefix"
    ),
    out_dir: Path = typer.Option(
        Path(".spooled/fetched"),
        "--out-dir",
        "-o",
        help="Directory to write fetched trace JSONL files",
    ),
    limit: int = typer.Option(
        20, "--limit", "-n", help="Maximum number of traces to fetch (max 50)"
    ),
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend API URL (overrides env var)"
    ),
) -> None:
    """Fetch recent traces from the Spooled backend (Pro).

    Downloads traces matching the given agent-id and time window,
    materializes them as local JSONL files for use with batch-compare.

    This is Pattern 4: compare production/staging traces in CI
    without running LLM agents.

    Examples:
       spooled ci fetch-traces --agent-id deal_agent --since 24h
       spooled ci fetch-traces -a rag_agent -s 7d --commit-sha abc123
       spooled ci fetch-traces -a my_agent -o .spooled/fetched --limit 10
    """
    if not _require_pro("ci fetch-traces"):
        raise typer.Exit(code=1)

    import os

    try:
        import httpx
    except ImportError:
        console.print("[red]✗[/red] httpx is required: pip install httpx")
        raise typer.Exit(code=1)

    url = backend_url or os.getenv("SPOOLED_BACKEND_URL", "").strip()
    if not url:
        from spooled.licensing import _get_backend_url

        url = _get_backend_url()

    if not url:
        console.print(
            "[red]✗[/red] No backend URL configured. Set SPOOLED_BACKEND_URL or pass --backend-url."
        )
        raise typer.Exit(code=1)

    url = url.rstrip("/")
    api_key = os.getenv("SPOOLED_API_KEY", "").strip()
    headers = {"x-api-key": api_key} if api_key else {}

    since_ts = _parse_since(since)

    # Build query params
    params: dict[str, str] = {
        "agent_id": agent_id,
        "since": since_ts,
        "limit": str(min(max(1, limit), 50)),
        "include_interactions": "true",
    }
    if commit_sha:
        params["commit_sha"] = commit_sha

    console.print(f"  Fetching traces for [bold]{agent_id}[/bold] since {since}...")

    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.get(
                f"{url}/api/traces/search",
                params=params,
                headers=headers,
            )
            response.raise_for_status()
            data = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 403:
            body = (
                e.response.json()
                if e.response.headers.get("content-type", "").startswith("application/json")
                else {}
            )
            console.print(
                f"[red]✗[/red] {body.get('error', 'Forbidden — check your SPOOLED_API_KEY')}"
            )
        else:
            console.print(f"[red]✗[/red] Backend error: {e.response.status_code}")
        raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]✗[/red] Failed to fetch traces: {e}")
        raise typer.Exit(code=1)

    traces = data.get("traces", [])
    if not traces:
        console.print(f"[yellow]⚠[/yellow]  No traces found for agent '{agent_id}' since {since}")
        raise typer.Exit(code=0)

    # Write each trace as a JSONL file
    out_dir.mkdir(parents=True, exist_ok=True)
    written = 0

    for trace in traces:
        run_id = trace.get("run_id", "unknown")
        interactions = trace.pop("interactions", [])

        trace_path = out_dir / f"{run_id}.jsonl"
        with open(trace_path, "w") as f:
            # First line: trace metadata (must have "type": "trace" for load_trace_from_jsonl)
            trace_meta = {
                "type": "trace",
                **{
                    k: v
                    for k, v in trace.items()
                    if k
                    in (
                        "run_id",
                        "agent_id",
                        "timestamp",
                        "status",
                        "chain_hash",
                        "fingerprint_hash",
                        "environment",
                        "tags",
                    )
                },
            }
            f.write(json.dumps(trace_meta, default=str) + "\n")
            # Subsequent lines: interactions (must have "type": "interaction")
            for interaction in interactions:
                if "type" not in interaction:
                    interaction["type"] = "interaction"
                f.write(json.dumps(interaction, default=str) + "\n")

        written += 1

    console.print(f"[green]✓[/green] Fetched {written} trace(s) for '{agent_id}' → {out_dir}")


# ─── batch-compare ────────────────────────────────────────────────────────


@app.command("batch-compare")
def batch_compare(
    trace_dir: Path = typer.Option(
        Path(".spooled/traces"), "--trace-dir", "-t", help="Directory containing trace files"
    ),
    baseline: Path = typer.Option(
        ..., "--baseline", "-b", help="Path to baseline (summary JSON or directory)"
    ),
    policy_file: Path | None = typer.Option(
        None, "--policy", "-p", help="Path to policy YAML file"
    ),
    out: Path = typer.Option(Path("ci-report"), "--out", "-o", help="Output directory for reports"),
    enable_blocking: bool = typer.Option(
        True, "--enable-blocking/--no-blocking", help="Exit with code 1 on policy violations"
    ),
    github_annotations: bool = typer.Option(
        False, "--github-annotations", help="Emit GitHub Actions annotations for detected signals"
    ),
    push: bool = typer.Option(False, "--push", help="Upload CI report to backend after generation"),
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend API URL (overrides SPOOLED_BACKEND_URL env var)"
    ),
    group_by_session: bool = typer.Option(
        False, "--group-by-session", help="Group results by multi-agent session in the report"
    ),
    policy_only: bool = typer.Option(
        False,
        "--policy-only",
        help="Skip fingerprint comparison; only run signal detection + policy evaluation",
    ),
) -> None:
    """Compare all traces in a directory against baselines.

    Like `ci run` but skips test execution — use when traces already exist.
    Compares each trace against the appropriate baseline, evaluates policy,
    and generates summary + markdown report.

    Use --policy-only to skip fingerprint gating and only evaluate metrics/signals.
    This is useful when adopting Spooled incrementally — get signal alerting first,
    enable fingerprint gating later.

    Example:
       spooled ci batch-compare --trace-dir .spooled/traces --baseline .github/baselines/
       spooled ci batch-compare -t .spooled/traces -b baselines/ --github-annotations --no-blocking
       spooled ci batch-compare -t .spooled/traces -b baselines/ --policy-only
    """
    # batch-compare is a free local operation. The only Pro gate is --push,
    # which sends the CI report to the backend.
    if push and not _require_pro("ci batch-compare --push"):
        push = False
        console.print(
            "[dim]--push disabled (requires Pro). Continuing with local comparison.[/dim]\n"
        )

    try:
        # Step 1: Find traces
        trace_files = _find_all_traces(trace_dir)
        if not trace_files:
            console.print(f"[red]✗[/red] No trace files found in: {trace_dir}")
            raise typer.Exit(code=1)

        console.print(f"  Found {len(trace_files)} trace(s) in {trace_dir}")

        # Step 2: Compare each trace against baseline
        policy_engine = PolicyEngine(policy_file)
        results: list[dict[str, Any]] = []
        overall_exit = 0

        for tf in trace_files:
            try:
                trace_data = _load_trace(tf)
                trace_agent = trace_data.get("trace", {}).get("agent_id", "unknown")

                # Load baseline for this agent
                baseline_data = None
                baseline_path = baseline
                if baseline.is_dir():
                    candidate = baseline / f"{trace_agent}.json"
                    if candidate.exists():
                        baseline_path = candidate
                    else:
                        # Skip traces with no matching baseline file
                        continue
                if baseline_path.exists():
                    baseline_data = load_baseline_from_path(baseline_path, trace_agent)

                result = _compute_comparison(
                    trace_data, baseline_data, trace_agent, policy_engine, policy_only=policy_only
                )
                result["trace_file"] = str(tf)

                # Record usage for free tier enforcement
                try:
                    from spooled.usage import UsageTracker

                    UsageTracker().record_comparison()
                except Exception as _exc:
                    logger.debug("Suppressed exception", error=str(_exc))

                    pass

                # Inject session_id from trace metadata for session grouping
                trace_session_id = trace_data.get("trace", {}).get("session_id")
                if trace_session_id:
                    result["session_id"] = trace_session_id

                results.append(result)

                # Emit GitHub annotations per-trace
                if github_annotations:
                    _emit_github_annotations(result)

                ec = _determine_exit_code(result, enable_blocking)
                if ec != 0:
                    overall_exit = 1

            except Exception as e:
                logger.debug("Skipping trace", path=str(tf), error=str(e))

        if not results:
            console.print("[red]✗[/red] No traces could be analyzed")
            raise typer.Exit(code=1)

        # Step 3: Generate reports
        out.mkdir(parents=True, exist_ok=True)

        import uuid

        ci_report_id = str(uuid.uuid4()) if push else None

        # JSON summary
        summary_path = out / "summary.json"
        ci_summary = _build_ci_summary(results)
        if ci_report_id:
            ci_summary["ci_report_id"] = ci_report_id

        # Add session grouping if requested
        if group_by_session:
            ci_summary["sessions"] = _build_session_groups(results)

        with open(summary_path, "w") as f:
            json.dump(ci_summary, f, indent=2, default=str)

        # Markdown report
        md_path = out / "report.md"
        baseline_dir_str = str(baseline) if baseline.is_dir() else str(baseline.parent)
        md_content = _build_ci_markdown(ci_summary, results, baseline_dir=baseline_dir_str)
        with open(md_path, "w") as f:
            f.write(md_content)

        # Per-trace results (sanitize before writing to disk)
        for i, result in enumerate(results):
            sanitized = _sanitize_artifact_result(result)
            result_path = out / f"trace-{i}.json"
            with open(result_path, "w") as f:
                json.dump(sanitized, f, indent=2, default=str)

        # Push to backend if requested
        if push:
            _push_ci_report(ci_summary, results, backend_url, ci_report_id)

        # Display summary
        _display_ci_summary(results, ci_summary, out)
        _display_ci_result(overall_exit)

        raise typer.Exit(code=overall_exit)

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Batch compare failed", error=str(e))
        console.print(f"[red]✗[/red] Batch compare failed: {e}")
        raise typer.Exit(code=1)


def _run_test_suite(suite: Path) -> int:
    """Execute a test suite.

    Args:
        suite: Path to test module or directory

    Returns:
        Exit code from test execution
    """
    if suite.is_dir():
        cmd = [sys.executable, "-m", "pytest", str(suite), "-v", "--tb=short"]
    elif suite.suffix == ".py":
        cmd = [sys.executable, str(suite)]
    else:
        cmd = [sys.executable, "-m", "pytest", str(suite), "-v", "--tb=short"]

    try:
        result = subprocess.run(
            cmd,
            capture_output=False,
            timeout=300,
        )
        return result.returncode
    except subprocess.TimeoutExpired:
        console.print("[red]✗[/red] Test suite timed out (300s)")
        return 124
    except Exception as e:
        console.print(f"[red]✗[/red] Failed to run test suite: {e}")
        return 1


def _are_failures_metric_only(results: list[dict[str, Any]]) -> bool:
    """Check whether all policy violations are from metric-sensitive signals.

    Returns True only when every violation type is in METRIC_SENSITIVE_SIGNALS.
    Structural changes (new fingerprint, new side effects) always return False.
    """
    for result in results:
        # Structural change is never metric-only
        if result.get("fingerprint_status") == "new":
            return False

        policy = result.get("policy", {})
        for violation in policy.get("violations", []):
            vtype = violation.get("type", "")
            if vtype not in METRIC_SENSITIVE_SIGNALS:
                return False

    return True


def _clear_traces(trace_dir: Path) -> None:
    """Remove all .jsonl trace files from a directory for rerun."""
    if not trace_dir.exists():
        return
    for f in trace_dir.glob("*.jsonl"):
        f.unlink()


def _build_session_groups(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Group results by session_id for multi-agent session reporting.

    Args:
        results: Per-trace comparison results

    Returns:
        List of session group dicts with session_id, agents, status, and trace refs
    """
    from collections import defaultdict

    sessions: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for r in results:
        session_id = r.get("session_id")
        if session_id:
            sessions[session_id].append(r)

    groups = []
    for session_id, session_results in sessions.items():
        agents = sorted({r["agent_id"] for r in session_results})
        all_pass = all(r["fingerprint_match"] for r in session_results)
        any_block = any(r["summary"].get("should_block") for r in session_results)
        status = "FAIL" if any_block else ("PASS" if all_pass else "WARN")
        groups.append(
            {
                "session_id": session_id,
                "agents": agents,
                "trace_count": len(session_results),
                "status": status,
                "traces": [
                    {
                        "agent_id": r["agent_id"],
                        "fingerprint_status": r["fingerprint_status"],
                        "should_block": r["summary"].get("should_block", False),
                    }
                    for r in session_results
                ],
            }
        )

    return groups


def _sanitize_artifact_result(result: dict[str, Any]) -> dict[str, Any]:
    """Sanitize a per-trace CI result before writing to disk.

    Strips error strings from fingerprint data that could leak
    sensitive information (stack traces, file paths, internal state).
    Preserves structural fields (sequence, type, recovery_type).

    Args:
        result: Per-trace comparison result dict

    Returns:
        Sanitized copy of the result
    """
    import copy

    sanitized = copy.deepcopy(result)

    fp = sanitized.get("fingerprint", {})
    if not isinstance(fp, dict):
        return sanitized

    # Redact error strings in error_patterns
    error_patterns = fp.get("error_patterns", {})
    if isinstance(error_patterns, dict):
        errors = error_patterns.get("errors", [])
        if isinstance(errors, list):
            for entry in errors:
                if isinstance(entry, dict) and "error" in entry:
                    entry["error"] = "[REDACTED]"

    # Redact error strings in branch_paths
    branch_paths = fp.get("branch_paths", [])
    if isinstance(branch_paths, list):
        for path_entry in branch_paths:
            if isinstance(path_entry, dict) and "error" in path_entry:
                path_entry["error"] = "[REDACTED]"

    return sanitized


def _build_ci_summary(results: list[dict[str, Any]]) -> dict[str, Any]:
    """Build aggregate CI summary from per-trace results."""
    from spooled.scoring import compute_agent_spooled_score

    total = len(results)
    passed = sum(1 for r in results if r["fingerprint_match"])
    new_behavior = sum(1 for r in results if r["fingerprint_status"] in ("new", "variant"))
    no_baseline = sum(1 for r in results if r["fingerprint_status"] == "no_baseline")
    policy_failures = sum(1 for r in results if r["summary"].get("should_block"))
    has_warnings = any(r["summary"]["has_warnings"] for r in results)

    max_severity = "none"
    for r in results:
        s = r["summary"]["severity"]
        if s == "high":
            max_severity = "high"
            break
        elif s == "medium" and max_severity != "high":
            max_severity = "medium"
        elif s == "low" and max_severity == "none":
            max_severity = "low"

    # Compute agent-level Spooled Score
    intent_scores = []
    for r in results:
        ss = r.get("spooled_score")
        if ss:
            intent_scores.append(
                {
                    "score": ss.get("score"),
                    "confidence": ss.get("confidence", "low"),
                    "run_count": r.get("baseline_stats", {}).get("sample_count", 1),
                }
            )
    agent_score = compute_agent_spooled_score(intent_scores)

    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "total_traces": total,
        "passed": passed,
        "new_behavior": new_behavior,
        "no_baseline": no_baseline,
        "policy_failures": policy_failures,
        "has_warnings": has_warnings,
        "max_severity": max_severity,
        "overall_result": "FAIL" if policy_failures > 0 else "PASS",
        "spooled_score": agent_score,
        "traces": [
            {
                "trace_file": (
                    os.path.basename(r.get("trace_file", "")) if r.get("trace_file") else None
                ),
                "agent_id": r["agent_id"],
                "fingerprint_hash": r.get("fingerprint_hash", "")[:16],
                "fingerprint_status": r["fingerprint_status"],
                "severity": r["summary"]["severity"],
                "should_block": r["summary"].get("should_block", False),
                "token_delta_pct": r.get("metric_deltas", {})
                .get("tokens", {})
                .get("delta_pct", 0.0),
                "latency_delta_pct": r.get("metric_deltas", {})
                .get("latency", {})
                .get("delta_pct", 0.0),
                "baseline_run_count": r.get("baseline_stats", {}).get("sample_count", 0),
                "similarity_score": r.get("similarity_score"),
                "reason_code": r.get("reason_code"),
                "reason_label": r.get("reason_label"),
                "similarity_dimensions": r.get("similarity_dimensions"),
                "tool_diff": r.get("tool_diff"),
                "spooled_score": r.get("spooled_score", {}).get("score"),
                "spooled_grade": r.get("spooled_score", {}).get("grade"),
            }
            for r in results
        ],
    }


def _build_ci_markdown(
    ci_summary: dict[str, Any],
    results: list[dict[str, Any]],
    baseline_dir: str = "baselines",
) -> str:
    """Build CI markdown report for PR comments."""
    from cli.report_pr import build_pr_markdown

    return build_pr_markdown(ci_summary, results, baseline_dir=baseline_dir)


def _push_ci_report(
    ci_summary: dict[str, Any],
    results: list[dict[str, Any]],
    backend_url: str | None = None,
    run_id: str | None = None,
) -> None:
    """Push CI report to the backend."""
    import uuid

    try:
        import httpx
    except ImportError:
        console.print("[yellow]![/yellow] httpx not installed — skipping push (pip install httpx)")
        return

    from spooled.utils import get_auth_headers

    url = backend_url or os.getenv("SPOOLED_BACKEND_URL")
    if not url:
        console.print("[yellow]![/yellow] No backend URL configured — skipping push")
        console.print("  Set SPOOLED_BACKEND_URL or use --backend-url")
        return

    run_id = run_id or str(uuid.uuid4())
    agent_ids = list({r["agent_id"] for r in results})
    agent_id = agent_ids[0] if len(agent_ids) == 1 else "multi-agent"

    # Build signals list from results
    signals = []
    for r in results:
        raw_signals = r.get("signals", {})
        if isinstance(raw_signals, dict):
            for name, sig_data in raw_signals.items():
                if isinstance(sig_data, dict) and sig_data.get("detected"):
                    signals.append({"name": name, **sig_data})
        elif isinstance(raw_signals, list):
            signals.extend(raw_signals)

    # Build policy result
    policy_result = {
        "passed": ci_summary.get("policy_failures", 0) == 0,
        "violations": [],
    }
    for r in results:
        policy_data = r.get("policy", {})
        for v in policy_data.get("violations", []):
            policy_result["violations"].append(v)

    # Payload is the BatchCIRun shape directly (so GET /api/ci-reports/{id}
    # returns something isBatchReport() recognises without unwrapping).
    payload = {
        # BatchCIRun fields at top level
        "timestamp": ci_summary["timestamp"],
        "total_traces": ci_summary.get("total_traces", len(results)),
        "passed": ci_summary.get("passed", 0),
        "new_behavior": ci_summary.get("new_behavior", 0),
        "no_baseline": ci_summary.get("no_baseline", 0),
        "policy_failures": ci_summary.get("policy_failures", 0),
        "has_warnings": ci_summary.get("has_warnings", False),
        "max_severity": ci_summary.get("max_severity", "none"),
        "overall_result": ci_summary.get("overall_result", "PASS"),
        "traces": ci_summary.get("traces", []),
        # Extra backend fields (not part of BatchCIRun but useful for queries)
        "run_id": run_id,
        "agent_id": agent_id,
        "signals": signals,
        "policy_result": policy_result,
    }

    api_url = f"{url.rstrip('/')}/api/ci-reports"
    try:
        with httpx.Client(timeout=30) as client:
            response = client.post(
                api_url,
                json=payload,
                headers={"Content-Type": "application/json", **get_auth_headers()},
            )
            response.raise_for_status()
            console.print(f"  [green]Pushed CI report:[/green] {run_id}")
    except httpx.HTTPStatusError as e:
        console.print(f"[yellow]![/yellow] Failed to push CI report: {e.response.status_code}")
        logger.debug("Push failed", status=e.response.status_code, body=e.response.text)
    except Exception as e:
        console.print(f"[yellow]![/yellow] Failed to push CI report: {e}")
        logger.debug("Push failed", error=str(e))


# ─── accept-variant ──────────────────────────────────────────────────────────


@app.command("accept-variant")
def accept_variant(
    intent: str = typer.Option(
        ..., "--intent", "-i", help="Intent ID (fingerprint hash) to update"
    ),
    fingerprint: str = typer.Option(
        ..., "--fingerprint", "-f", help="Fingerprint hash to accept as a variant"
    ),
    baseline_path: Path = typer.Option(
        ..., "--baseline", "-b", help="Path to baseline summary JSON file"
    ),
    reason: str | None = typer.Option(
        None, "--reason", "-r", help="Human-readable reason (e.g. 'prompt update', 'model upgrade')"
    ),
    accepted_by: str | None = typer.Option(
        None, "--by", help="Who is accepting (git user, team, or tool name)"
    ),
) -> None:
    """Add a fingerprint variant to an intent's accepted set.

    Handles legitimate branching where an agent sometimes takes path A,
    sometimes path B. Both fingerprints should be accepted as known behavior.

    Optionally record provenance with --reason and --by for audit trail.

    Example:
       spooled ci accept-variant --intent abc123 --fingerprint def456 --baseline baselines/my_agent.json
       spooled ci accept-variant --intent abc123 --fingerprint def456 -b baselines/my_agent.json --reason "prompt update" --by "alice"
    """
    try:
        if not baseline_path.exists():
            console.print(f"[red]✗[/red] Baseline not found: {baseline_path}")
            raise typer.Exit(code=1)

        with open(baseline_path) as f:
            data = json.load(f)

        # Support both summary and full baseline formats
        intents = data.get("intents", {})

        # Find the intent (support prefix matching)
        matched_intent = None
        for intent_id in intents:
            if intent_id == intent or intent_id.startswith(intent):
                matched_intent = intent_id
                break

        if matched_intent is None:
            console.print(f"[red]✗[/red] Intent not found: {intent}")
            console.print(
                f"  Available intents: {', '.join(k[:16] + '...' for k in intents.keys())}"
            )
            raise typer.Exit(code=1)

        intent_data = intents[matched_intent]

        # Add to accepted_fingerprints (backward-compat flat list)
        accepted = intent_data.get("accepted_fingerprints", [])
        if fingerprint in accepted:
            console.print(
                f"[yellow]Fingerprint already accepted for intent {matched_intent[:16]}...[/yellow]"
            )
            raise typer.Exit(code=0)

        accepted.append(fingerprint)
        intent_data["accepted_fingerprints"] = accepted

        # Also write provenance record to accepted_variants
        accepted_variants = intent_data.get("accepted_variants", [])
        # Auto-detect accepted_by from git if not provided
        resolved_by = accepted_by
        if not resolved_by:
            try:
                git_user = subprocess.check_output(
                    ["git", "config", "user.name"], text=True, timeout=5
                ).strip()
                if git_user:
                    resolved_by = git_user
            except Exception:
                resolved_by = "cli"

        variant_record = {
            "fingerprint_hash": fingerprint,
            "accepted_at": datetime.now(timezone.utc).isoformat(),
            "reason": reason,
            "accepted_by": resolved_by,
        }
        accepted_variants.append(variant_record)
        intent_data["accepted_variants"] = accepted_variants

        # Write back
        with open(baseline_path, "w") as f:
            json.dump(data, f, indent=2)

        console.print(
            f"[green]Accepted fingerprint {fingerprint[:16]}... for intent {matched_intent[:16]}...[/green]"
        )
        if reason:
            console.print(f"  Reason: {reason}")
        if resolved_by:
            console.print(f"  Accepted by: {resolved_by}")
        console.print(f"  Total accepted variants: {len(accepted)}")
        raise typer.Exit(code=0)

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Accept variant failed", error=str(e))
        console.print(f"[red]✗[/red] Failed: {e}")
        raise typer.Exit(code=1)


# ─── report (existing, unchanged) ───────────────────────────────────────────


@app.command()
def report(
    trace_file: Path | None = typer.Argument(
        None, help="Path to trace file (optional, will use latest if not provided)"
    ),
    agent_id: str = typer.Option(..., "--agent-id", "-a", help="Agent identifier"),
    baseline_file: Path | None = typer.Option(
        None, "--baseline", "-b", help="Path to baseline trace file (optional)"
    ),
    policy_file: Path | None = typer.Option(
        None,
        "--policy",
        "-p",
        help="Path to policy YAML file (optional, auto-detects if not provided)",
    ),
    output: Path = typer.Option(
        Path("ai-behavior-report.md"), "--output", "-o", help="Output file path"
    ),
    format: str = typer.Option("markdown", "--format", "-f", help="Output format: markdown, json"),
    trace_dir: Path | None = typer.Option(
        None, "--trace-dir", "-d", help="Trace directory (defaults to .spooled/traces)"
    ),
    enable_blocking: bool = typer.Option(
        False, "--enable-blocking", help="Enable policy-based merge blocking (requires policy file)"
    ),
    github_annotations: bool = typer.Option(
        False, "--github-annotations", help="Emit GitHub Actions annotations for detected signals"
    ),
    gitlab_codequality: Path | None = typer.Option(
        None,
        "--gitlab-codequality",
        help="Write GitLab Code Quality report JSON to path",
    ),
    summary_json: Path | None = typer.Option(
        None,
        "--summary-json",
        help="Write report summary JSON to path",
    ),
) -> None:
    """Generate AI Behavior Diff Report for CI/CD.

    This command generates a comprehensive report comparing the current trace
    against a baseline, detecting signals, and providing actionable insights.

    If trace_file is not provided, the latest trace in the traces directory will be used.

    Example:
       spooled ci report --agent-id my_agent  # Uses latest trace
       spooled ci report .spooled/traces/run-123.jsonl --agent-id my_agent
       spooled ci report trace.jsonl --agent-id my_agent --output report.json --format json
    """
    try:
        # Auto-detect latest trace if not provided
        if trace_file is None:
            latest_trace = find_latest_trace(trace_dir, agent_id=agent_id)
            if latest_trace is None:
                console.print(
                    "[red]✗[/red] No trace file provided and no traces found in .spooled/traces/"
                )
                console.print("\n[yellow]Tips:[/yellow]")
                console.print("   1. Run your agent tests with tracing enabled")
                console.print(
                    "   2. Specify a trace file: [cyan]spooled ci report <trace_file> --agent-id <id>[/cyan]"
                )
                raise typer.Exit(code=1)
            trace_file = latest_trace
            console.print(f"[dim]Using latest trace: {trace_file}[/dim]")

        if not trace_file.exists():
            console.print(f"[red]✗[/red] Trace file not found: {trace_file}")
            raise typer.Exit(code=1)

        # Generate report with policy evaluation
        report_gen = AIBehaviorReport(trace_file, agent_id, baseline_file, policy_file)
        report_gen.save(output, format=format)

        # Display summary
        report_data = report_gen.generate()
        summary = report_data["summary"]
        policy_result = report_data.get("policy", {})

        console.print(f"[green]OK[/green] AI Behavior Report generated: {output}")

        # Display signal warnings
        if summary["has_warnings"]:
            severity = summary["severity"]
            severity_color = {
                "high": "red",
                "medium": "yellow",
                "low": "green",
            }.get(severity, "white")

            console.print(
                f"\n[{severity_color}]Warnings detected (Severity: {severity.upper()})[/{severity_color}]"
            )
            console.print(f"  Signal count: {summary['signal_count']}")
        else:
            console.print("\n[green]No warnings detected[/green]")

        # Display policy evaluation
        if policy_result.get("enabled"):
            if policy_result.get("passed"):
                console.print("\n[green]Policy: PASSED[/green]")
            else:
                violation_count = len(policy_result.get("violations", []))
                console.print(f"\n[red]Policy: FAILED ({violation_count} violations)[/red]")

                if policy_result.get("should_block"):
                    console.print("[red]Merge blocking is ENABLED - this PR will be blocked[/red]")
                else:
                    console.print("[yellow]Merge blocking is DISABLED - warnings only[/yellow]")

        if github_annotations:
            _emit_github_annotations(report_data)

        if summary_json is not None:
            _write_summary_json(report_data, summary_json)

        if gitlab_codequality is not None:
            _write_gitlab_codequality(report_data, gitlab_codequality)

        # Exit with appropriate code for CI
        should_block = (
            enable_blocking
            and policy_result.get("enabled")
            and policy_result.get("block_merges")
            and policy_result.get("should_block")
        )

        if should_block:
            console.print(
                "\n[red]Policy violations detected. Exiting with code 1 to block merge.[/red]"
            )
            raise typer.Exit(code=1)
        elif summary["has_warnings"] and summary["severity"] == "high":
            console.print(
                "\n[yellow]Note: High severity warnings detected (non-blocking mode).[/yellow]"
            )
            raise typer.Exit(code=0)
        else:
            raise typer.Exit(code=0)

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Failed to generate CI report", error=str(e))
        console.print(f"[red]✗[/red] Failed to generate report: {str(e)}")
        raise typer.Exit(code=1)


@app.command()
def badge(
    baseline: Path = typer.Option(
        ..., "--baseline", "-b", help="Path to baseline summary JSON file or directory"
    ),
    agent_id: str | None = typer.Option(
        None,
        "--agent-id",
        "-a",
        help="Agent ID (auto-detected from file, required when --baseline is a directory)",
    ),
    format: str = typer.Option(
        "markdown", "--format", "-f", help="Output format: markdown, url, json"
    ),
) -> None:
    """Generate a Spooled Score badge for README or CI.

    Reads the latest Spooled Score from a baseline summary file and
    outputs a shields.io badge URL or markdown snippet.

    Example:
       spooled ci badge --baseline baselines/my_agent.json
       spooled ci badge -b baselines/ -a my_agent --format url
    """
    from spooled.models import BaselineSummary as _BS
    from spooled.scoring import compute_agent_spooled_score, format_badge_markdown, format_badge_url

    try:
        # Resolve baseline file
        if baseline.is_dir():
            if not agent_id:
                console.print("[red]✗[/red] --agent-id required when --baseline is a directory")
                raise typer.Exit(code=1)
            baseline = baseline / f"{agent_id}.json"

        if not baseline.exists():
            console.print(f"[red]✗[/red] Baseline file not found: {baseline}")
            raise typer.Exit(code=1)

        with open(baseline) as f:
            data = json.load(f)

        # Fix null fingerprint_hash values from older baselines
        for intent_id, intent_data in data.get("intents", {}).items():
            if isinstance(intent_data, dict) and intent_data.get("fingerprint_hash") is None:
                intent_data["fingerprint_hash"] = intent_id

        summary = _BS.model_validate(data)
        detected_agent_id = agent_id or summary.agent_id

        # Collect per-intent scores from stored spooled_score
        intent_scores = []
        for _intent_id, intent in summary.intents.items():
            if intent.spooled_score:
                intent_scores.append(
                    {
                        "score": intent.spooled_score.score,
                        "confidence": intent.spooled_score.confidence,
                        "run_count": intent.run_count,
                    }
                )
            else:
                # Compute from trend data if no stored score
                from spooled.scoring import compute_spooled_score as _cs

                _raw = _cs(
                    fingerprint_status="match",
                    similarity_score=None,
                    signals={},
                    metric_deltas={},
                    similarity_trend=[p.model_dump() for p in intent.similarity_trend],
                )
                intent_scores.append(
                    {
                        "score": _raw["score"],
                        "confidence": _raw["confidence"],
                        "run_count": intent.run_count,
                    }
                )

        agent_score = compute_agent_spooled_score(intent_scores)

        if agent_score.get("score") is None:
            console.print(f"[yellow]![/yellow] No score data available for {detected_agent_id}")
            raise typer.Exit(code=0)

        sc = agent_score["score"]
        gr = agent_score["grade"]

        if format == "json":
            import json as _json

            output = _json.dumps(
                {
                    "agent_id": detected_agent_id,
                    "score": sc,
                    "grade": gr,
                    "confidence": agent_score["confidence"],
                    "intent_count": agent_score["intent_count"],
                    "badge_url": format_badge_url(sc, gr),
                },
                indent=2,
            )
            console.print(output)
        elif format == "url":
            console.print(format_badge_url(sc, gr))
        else:
            console.print(format_badge_markdown(sc, gr))

    except typer.Exit:
        raise
    except Exception as e:
        console.print(f"[red]✗[/red] Failed to generate badge: {e}")
        raise typer.Exit(code=1)


# ─── approve ─────────────────────────────────────────────────────────────────


@app.command("approve")
def approve(
    agent: str = typer.Option(
        ..., "--agent", "-a", help="Agent ID whose latest variant(s) to accept"
    ),
    baseline_dir: Path = typer.Option(
        Path("baselines"),
        "--baseline",
        "-b",
        help="Directory containing baseline summary JSON files",
    ),
    trace_dir: Path | None = typer.Option(
        None, "--from", help="Directory containing traces (default: .spooled/traces/)"
    ),
    reason: str | None = typer.Option(
        None, "--reason", "-r", help="Human-readable reason for accepting variants"
    ),
    accepted_by: str | None = typer.Option(
        None, "--by", help="Who is accepting (git user, team, or tool name)"
    ),
    commit: bool = typer.Option(False, "--commit", help="Auto-commit baseline changes with git"),
    message: str | None = typer.Option(
        None, "--message", "-m", help="Custom commit message (implies --commit)"
    ),
) -> None:
    """Accept latest variant fingerprints and regenerate the baseline in one step.

    Combines the accept-variant and update-baseline workflows: scans recent
    traces for the given agent, accepts any new fingerprint variants into
    the baseline, regenerates the baseline summary with updated metrics,
    and optionally commits the result.

    Example:
       spooled ci approve --agent my_agent
       spooled ci approve --agent my_agent --baseline baselines/ --commit
       spooled ci approve --agent my_agent -b baselines/ --message "chore: approve prompt-v2 variants"
    """
    import json as _json

    from spooled.models import BaselineSummary as _BaselineSummary

    # --message implies --commit
    if message:
        commit = True

    try:
        # ── 1. Locate baseline file for this agent ──────────────────────
        baseline_path = baseline_dir / f"{agent}.json"
        if not baseline_path.exists():
            console.print(f"[red]✗[/red] Baseline not found: {baseline_path}")
            console.print(
                f"  Expected a file at [cyan]{baseline_path}[/cyan] for agent [bold]{agent}[/bold]."
            )
            raise typer.Exit(code=1)

        with open(baseline_path) as f:
            baseline_data = _json.load(f)

        intents = baseline_data.get("intents", {})
        if not intents:
            console.print(f"[red]✗[/red] Baseline has no intents: {baseline_path}")
            raise typer.Exit(code=1)

        # ── 2. Scan traces to find new fingerprints ─────────────────────
        source_dir = trace_dir or get_trace_directory()
        if not source_dir.exists():
            console.print(f"[red]✗[/red] Trace directory not found: {source_dir}")
            raise typer.Exit(code=1)

        trace_files = _find_all_traces(source_dir)
        if not trace_files:
            console.print(f"[red]✗[/red] No trace files found in: {source_dir}")
            raise typer.Exit(code=1)

        # Collect current fingerprint hashes from traces belonging to this agent
        new_fps: dict[str, str] = {}  # fingerprint_hash -> closest intent_id
        for tf in trace_files:
            try:
                trace_data = _load_trace(tf)
                trace_agent_id = trace_data.get("trace", {}).get("agent_id", "unknown")
                if trace_agent_id != agent:
                    continue

                fp = BehavioralFingerprint(trace_data)
                fp_data = fp.generate()
                fp_hash = hash_fingerprint(fp_data)

                # Check if this fingerprint is already known
                if fp_hash in intents:
                    continue  # exact match — already a primary intent

                already_accepted = False
                closest_intent = None
                for intent_id, intent_data in intents.items():
                    accepted = intent_data.get("accepted_fingerprints", [])
                    if fp_hash in accepted:
                        already_accepted = True
                        break
                    # Track closest intent (first one as fallback)
                    if closest_intent is None:
                        closest_intent = intent_id

                if already_accepted:
                    continue

                # Map this new fingerprint to its closest intent
                if closest_intent:
                    new_fps[fp_hash] = closest_intent
            except Exception as _exc:
                logger.debug("Suppressed exception", error=str(_exc))

                continue

        if not new_fps:
            console.print(
                f"[yellow]No new variant fingerprints found for agent [bold]{agent}[/bold].[/yellow]"
            )
            console.print("  All observed fingerprints are already in the baseline.")
        else:
            # ── 3. Accept each new fingerprint (accept-variant logic) ───
            resolved_by = accepted_by
            if not resolved_by:
                try:
                    git_user = subprocess.check_output(
                        ["git", "config", "user.name"], text=True, timeout=5
                    ).strip()
                    if git_user:
                        resolved_by = git_user
                except Exception:
                    resolved_by = "cli"

            for fp_hash, intent_id in new_fps.items():
                intent_data = intents[intent_id]

                # Add to accepted_fingerprints
                accepted = intent_data.get("accepted_fingerprints", [])
                accepted.append(fp_hash)
                intent_data["accepted_fingerprints"] = accepted

                # Write provenance record to accepted_variants
                accepted_variants = intent_data.get("accepted_variants", [])
                variant_record = {
                    "fingerprint_hash": fp_hash,
                    "accepted_at": datetime.now(timezone.utc).isoformat(),
                    "reason": reason or "approved via spooled ci approve",
                    "accepted_by": resolved_by,
                }
                accepted_variants.append(variant_record)
                intent_data["accepted_variants"] = accepted_variants

                console.print(
                    f"[green]Accepted[/green] fingerprint {fp_hash[:16]}... "
                    f"for intent {intent_id[:16]}..."
                )

            # Write updated baseline with accepted variants
            with open(baseline_path, "w") as f:
                _json.dump(baseline_data, f, indent=2)

            console.print(
                f"\n[green]Accepted {len(new_fps)} new variant(s)[/green] "
                f"for agent [bold]{agent}[/bold]."
            )

        # ── 4. Regenerate baseline (update-baseline logic) ──────────────
        console.print("\n[dim]Regenerating baseline from traces...[/dim]")

        agents: dict[str, BaselineManager] = {}
        processed = 0

        for tf in trace_files:
            try:
                trace_data = _load_trace(tf)
                trace_agent_id = trace_data.get("trace", {}).get("agent_id", "unknown")
                if trace_agent_id != agent:
                    continue

                if trace_agent_id not in agents:
                    mgr = BaselineManager(trace_agent_id)
                    mgr._baseline = AgentBaseline(
                        agent_id=trace_agent_id,
                        updated_at=datetime.now(timezone.utc),
                        intents={},
                    )
                    agents[trace_agent_id] = mgr

                status = trace_data.get("trace", {}).get("status", "UNKNOWN")
                agents[trace_agent_id].add_to_baseline(trace_data, status)
                _enrich_baseline_stats(agents[trace_agent_id], trace_data)
                processed += 1
            except Exception as _exc:
                logger.debug("Suppressed exception", error=str(_exc))

                continue

        if agents:
            # Load existing summary to preserve accepted_fingerprints/variants
            old_summary = None
            if baseline_path.exists():
                try:
                    with open(baseline_path) as _f:
                        old_summary = _BaselineSummary(**_json.load(_f))
                except Exception as _exc:
                    logger.debug("Suppressed exception", error=str(_exc))

                    pass

            mgr = agents[agent]
            mgr_baseline = mgr.load_baseline()

            # Carry over accepted_fingerprints and accepted_variants from
            # the updated baseline file (which now includes newly accepted variants)
            if old_summary:
                for iid, stat in mgr_baseline.intents.items():
                    old_intent = old_summary.intents.get(iid)
                    if old_intent:
                        existing_fps = set(stat.accepted_fingerprints or [])
                        for fp in old_intent.accepted_fingerprints or []:
                            existing_fps.add(fp)
                        stat.accepted_fingerprints = sorted(existing_fps)
                        existing_av_hashes = {
                            av.fingerprint_hash for av in (stat.accepted_variants or [])
                        }
                        for av in old_intent.accepted_variants or []:
                            if av.fingerprint_hash not in existing_av_hashes:
                                stat.accepted_variants.append(av)

            mgr._baseline = mgr_baseline
            baseline_dir.mkdir(parents=True, exist_ok=True)
            summary = mgr.save_summary(baseline_path)

            console.print(
                f"[green]Baseline regenerated[/green]: {baseline_path} "
                f"({len(summary.intents)} intents, {processed} traces)"
            )
        else:
            console.print(
                f"[yellow]No traces found for agent {agent} — baseline not regenerated.[/yellow]"
            )

        # ── 5. Optional git commit ──────────────────────────────────────
        if commit:
            commit_msg = message or f"chore(baselines): approve variants for {agent}"
            try:
                subprocess.run(
                    ["git", "add", str(baseline_path)],
                    check=True,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                subprocess.run(
                    ["git", "commit", "-m", commit_msg],
                    check=True,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                console.print(f"\n[green]Committed:[/green] {commit_msg}")
            except subprocess.CalledProcessError as e:
                stderr = e.stderr.strip() if e.stderr else str(e)
                console.print(f"[yellow]Git commit skipped:[/yellow] {stderr}")

        raise typer.Exit(code=0)

    except typer.Exit:
        raise
    except Exception as e:
        logger.debug("Approve failed", error=str(e))
        console.print(f"[red]✗[/red] Failed: {e}")
        raise typer.Exit(code=1)
