"""Command to replay traces locally using pytest."""

from __future__ import annotations

from pathlib import Path

import structlog
import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from cli.utils import extract_run_id, resolve_trace_path

logger = structlog.get_logger(__name__)
console = Console()

app = typer.Typer(name="replay", help="Replay a trace locally")


@app.command()
def trace(
    run_id: str = typer.Argument(..., help="The trace run_id or path to trace file"),
    trace_file: Path | None = typer.Option(
        None, "--file", "-f", help="Path to trace JSON file (if not in default location)"
    ),
    output_dir: Path = typer.Option(
        Path("tests"), "--output-dir", "-o", help="Directory to generate pytest file"
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed output"),
) -> None:
    """Generate a pytest file from a trace for deterministic replay.

    This command reads a trace file and generates a pytest test that replays
    the exact execution using mocked I/O operations.

    Example:
       spooled replay abc-123-def
       spooled replay .spooled/traces/abc-123-def.jsonl
       spooled replay abc-123-def --file ./traces/abc-123-def.json
    """
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task(f"Generating replay test for {run_id}...", total=None)

        try:
            # Resolve trace file path (accepts both run IDs and file paths)
            trace_file = resolve_trace_path(run_id, trace_file)

            if trace_file is None or not trace_file.exists():
                console.print(f"[red]✗[/red] Trace file not found: {run_id}")
                console.print("\n[yellow]💡 Tips:[/yellow]")
                console.print("   1. List available traces: [cyan]spooled list traces[/cyan]")
                console.print(f"   2. Pull from backend: [cyan]spooled pull trace {run_id}[/cyan]")
                console.print("   3. Specify custom path: [cyan]--file /path/to/trace.jsonl[/cyan]")
                raise typer.Exit(code=1)

            # Generate pytest file
            clean_run_id = extract_run_id(run_id)
            test_file = generate_replay_test(clean_run_id, trace_file, output_dir)

            progress.update(task, completed=True)
            console.print(f"[green]✓[/green] Replay test generated: {test_file}")
            console.print(f"\nRun with: [cyan]pytest {test_file}[/cyan]")

        except FileNotFoundError as e:
            console.print(f"[red]✗[/red] File not found: {str(e)}")
            console.print("\n[yellow]💡 Tip:[/yellow] Ensure the trace file exists and is readable")
            raise typer.Exit(code=1)
        except typer.Exit:
            raise
        except Exception as e:
            logger.debug("Failed to generate replay test", run_id=run_id, error=str(e))
            console.print(f"[red]✗[/red] Failed to generate replay test: {str(e)}")
            if verbose:
                import traceback

                console.print("\n[dim]Full traceback:[/dim]")
                console.print(traceback.format_exc())
            else:
                console.print(
                    "\n[yellow]💡 Tip:[/yellow] Use [cyan]--verbose[/cyan] for detailed error information"
                )
            raise typer.Exit(code=1)


def generate_replay_test(run_id: str, trace_file: Path, output_dir: Path) -> Path:
    """Generate a pytest file from a trace.

    Args:
        run_id: The trace run_id
        trace_file: Path to the trace JSONL or JSON file
        output_dir: Directory to write the test file

    Returns:
        Path to the generated test file
    """
    from cli.replay_generator import ReplayGenerator
    from spooled.storage import load_trace_from_jsonl

    # Load trace data (try JSONL first, fallback to JSON)
    if trace_file.suffix == ".jsonl":
        trace_data = load_trace_from_jsonl(trace_file)
    else:
        import json

        with open(trace_file) as f:
            trace_data = json.load(f)

    # Generate test code
    generator = ReplayGenerator(run_id, trace_data)
    test_code = generator.generate()

    # Write test file
    output_dir.mkdir(parents=True, exist_ok=True)
    test_file = output_dir / f"replay_{run_id}.py"

    with open(test_file, "w") as f:
        f.write(test_code)

    return test_file
