"""spooled doctor — setup health check command."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import typer
from rich.console import Console

app = typer.Typer(name="doctor", help="Check Spooled setup health")
console = Console()


# Check result: (ok, warn_only, label, detail)
Check = tuple[bool, bool, str, str | None]

# Sections: ordered list of (section_name, checks)
Sections = list[tuple[str, list[Check]]]


def _check(ok: bool, label: str, fix: str | None = None, warn: bool = False) -> Check:
    return (ok, warn, label, fix)


def _print_check(result: Check) -> None:
    ok, warn_only, label, fix = result
    if ok:
        console.print(f"  [green]✓[/green]  {label}")
    elif warn_only:
        console.print(f"  [yellow]![/yellow]  {label}")
        if fix:
            console.print(f"       [dim]{fix}[/dim]")
    else:
        console.print(f"  [red]✗[/red]  {label}")
        if fix:
            console.print(f"       [dim]{fix}[/dim]")


def _http_get(url: str, headers: dict[str, str] | None = None, timeout: int = 5) -> tuple[int, str]:
    """Minimal HTTP GET — uses httpx if available, else urllib."""
    try:
        import httpx as _httpx

        with _httpx.Client(timeout=float(timeout)) as client:
            resp = client.get(url, headers=headers or {})
        return resp.status_code, resp.text
    except ImportError:
        pass
    import urllib.request

    req = urllib.request.Request(url, headers=headers or {})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, r.read().decode("utf-8", errors="replace")


def _env_checks(cwd: Path) -> list[Check]:
    checks: list[Check] = []

    major, minor = sys.version_info.major, sys.version_info.minor
    py_label = f"Python {major}.{minor}.{sys.version_info.micro}"
    if (major, minor) >= (3, 10):
        checks.append(_check(True, py_label))
    else:
        checks.append(
            _check(
                False,
                f"{py_label} (3.10+ required)",
                "Upgrade Python: https://python.org/downloads",
            )
        )

    try:
        import spooled as _sdk  # type: ignore

        version = getattr(_sdk, "__version__", "unknown")
        checks.append(_check(True, f"spooled SDK {version} installed"))
    except ImportError:
        checks.append(_check(False, "spooled SDK not installed", "pip install spooled"))

    try:
        branch = subprocess.check_output(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=cwd,
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=5,
        ).strip()
        checks.append(_check(True, f"Git repository (branch: {branch})"))
    except Exception:
        checks.append(
            _check(
                False,
                "Not inside a git repository",
                "git init  (Spooled baselines are committed alongside code)",
                warn=True,
            )
        )

    return checks


def _local_checks(cwd: Path) -> list[Check]:
    checks: list[Check] = []

    traces_dir = cwd / ".spooled" / "traces"
    if traces_dir.exists():
        count = len(list(traces_dir.glob("*.jsonl")))
        label = f"Traces directory found ({count} trace{'s' if count != 1 else ''})"
        if count == 0:
            checks.append(
                _check(
                    False,
                    label,
                    "Add spooled.init() to your agent and run it once to capture a trace",
                    warn=True,
                )
            )
        else:
            checks.append(_check(True, label))
    else:
        checks.append(
            _check(
                False,
                "Traces directory not found (.spooled/traces/)",
                "spooled init project  —  or add spooled.init() to your agent",
            )
        )

    baseline_locations = [
        cwd / ".github" / "baselines",
        cwd / "baselines",
        cwd / ".spooled" / "baselines",
    ]
    found_baselines: Path | None = None
    baseline_count = 0
    for loc in baseline_locations:
        files = list(loc.glob("*.json")) if loc.exists() else []
        if files:
            found_baselines = loc
            baseline_count = len(files)
            break

    if found_baselines:
        agents = ", ".join(f.stem for f in sorted(found_baselines.glob("*.json")))
        rel = found_baselines.relative_to(cwd)
        checks.append(
            _check(
                True,
                f"Baselines: {rel}/ ({baseline_count} agent{'s' if baseline_count != 1 else ''}: {agents})",
            )
        )
    else:
        checks.append(
            _check(
                False,
                "No baselines found",
                "spooled ci update-baseline --out .github/baselines/\n"
                "       git add .github/baselines/ && git commit -m 'Add AI baselines'",
            )
        )

    try:
        from spooled.policy import PolicyEngine

        engine = PolicyEngine()
        if engine.policy_file and engine.policy_file.exists():
            rel = (
                engine.policy_file.relative_to(cwd)
                if engine.policy_file.is_relative_to(cwd)
                else engine.policy_file
            )
            if engine.policy:
                checks.append(
                    _check(
                        True,
                        f"Policy: {rel} (name: {engine.policy.name}, "
                        f"block_merges: {engine.policy.block_merges})",
                    )
                )
            else:
                checks.append(
                    _check(
                        False,
                        f"Policy file found but failed to parse: {rel}",
                        "Check YAML syntax — run:`spooled policy validate",
                    )
                )
        else:
            # Check for per-agent policy files before reporting "not found"
            agent_policies = []
            for pattern in [
                "agents/*_policy.yml",
                "agents/*_policy.yaml",
                "policies/*.yml",
                "policies/*.yaml",
            ]:
                agent_policies.extend(cwd.glob(pattern))
            if agent_policies:
                names = ", ".join(p.stem for p in sorted(agent_policies)[:5])
                suffix = f" +{len(agent_policies) - 5} more" if len(agent_policies) > 5 else ""
                checks.append(
                    _check(
                        True,
                        f"Per-agent policies: {len(agent_policies)} found ({names}{suffix})",
                    )
                )
            else:
                checks.append(
                    _check(
                        False,
                        "No policy file found",
                        "spooled policy init --template moderate  —  creates spooled-policy.yml",
                        warn=True,
                    )
                )
    except Exception as e:
        checks.append(_check(False, f"Policy check failed: {e}", warn=True))

    workflows_dir = cwd / ".github" / "workflows"
    ci_workflow_found = False
    ci_workflow_name = None
    if workflows_dir.exists():
        for yml_file in sorted(workflows_dir.glob("*.yml")):
            try:
                content = yml_file.read_text(errors="replace")
                if (
                    "batch-compare" in content
                    or "ai-baseline" in content
                    or "spooled" in content.lower()
                ):
                    ci_workflow_found = True
                    ci_workflow_name = yml_file.name
                    break
            except Exception:
                pass

    if ci_workflow_found:
        checks.append(_check(True, f"CI workflow: .github/workflows/{ci_workflow_name}"))
    else:
        checks.append(
            _check(
                False,
                "No CI workflow referencing Spooled found",
                "spooled init project --with-demo  —  scaffolds .github/workflows/ai-baseline.yml",
                warn=True,
            )
        )

    return checks


def _remote_checks(backend_url: str | None) -> list[Check]:
    checks: list[Check] = []

    url = (backend_url or os.getenv("SPOOLED_BACKEND_URL", "")).strip().rstrip("/")
    api_key = os.getenv("SPOOLED_API_KEY", "").strip()

    # ── Backend URL ───────────────────────────────────────────────────────────
    if url:
        checks.append(_check(True, f"SPOOLED_BACKEND_URL: {url}"))
    else:
        checks.append(_check(True, "SPOOLED_BACKEND_URL not set — local-only mode (no sync)"))

    # ── API key ───────────────────────────────────────────────────────────────
    if api_key:
        masked = api_key[:8] + "…"
        checks.append(_check(True, f"SPOOLED_API_KEY: {masked}"))
    elif url:
        checks.append(
            _check(
                False,
                "SPOOLED_API_KEY not set (required for backend sync)",
                "export SPOOLED_API_KEY=<your-key>",
                warn=True,
            )
        )
    else:
        checks.append(_check(True, "SPOOLED_API_KEY not set (not required for local-only mode)"))

    # ── Backend health (only if URL configured) ───────────────────────────────
    if url:
        try:
            status, _ = _http_get(f"{url}/api/health")
            if status == 200:
                checks.append(_check(True, f"Backend reachable: {url}/api/health"))
            else:
                checks.append(
                    _check(
                        False,
                        f"Backend returned HTTP {status}: {url}/api/health",
                        "Check SPOOLED_BACKEND_URL or backend logs",
                    )
                )
        except Exception as e:
            checks.append(
                _check(
                    False,
                    f"Backend unreachable: {url}  ({type(e).__name__})",
                    "Check SPOOLED_BACKEND_URL and network connectivity",
                )
            )

        # ── API key validity via /api/whoami (only if key is also set) ────────
        if api_key:
            try:
                status, body = _http_get(
                    f"{url}/api/whoami",
                    headers={"x-api-key": api_key},
                )
                if status == 200:
                    import json as _json

                    try:
                        org_id = _json.loads(body).get("org_id", "?")
                    except Exception:
                        org_id = "?"
                    checks.append(_check(True, f"API key valid (org_id: {org_id})"))
                elif status == 401:
                    checks.append(
                        _check(
                            False,
                            "API key rejected by backend (HTTP 401)",
                            "Check SPOOLED_API_KEY — obtain a valid key from your Spooled admin",
                        )
                    )
                else:
                    checks.append(
                        _check(
                            False,
                            f"API key validation returned HTTP {status}",
                            "Check backend logs",
                            warn=True,
                        )
                    )
            except Exception as e:
                checks.append(
                    _check(False, f"Could not validate API key: {type(e).__name__}", warn=True)
                )

    return checks


def _run_sections(cwd: Path, backend_url: str | None) -> Sections:
    return [
        ("Environment", _env_checks(cwd)),
        ("Local setup", _local_checks(cwd)),
        ("Remote", _remote_checks(backend_url)),
    ]


@app.callback(invoke_without_command=True)
def doctor(
    ctx: typer.Context,
    backend_url: str | None = typer.Option(
        None, "--backend-url", "-u", help="Backend URL to test (overrides SPOOLED_BACKEND_URL)"
    ),
) -> None:
    """Check that Spooled is set up correctly.

    Runs a series of health checks across environment, local setup, and remote
    connectivity, then prints actionable fix hints for anything wrong.

    Example:
       spooled doctor
       spooled doctor --backend-url https://api.spooled.ai
    """
    if ctx.invoked_subcommand is not None:
        return

    cwd = Path.cwd()

    console.print()
    console.print("[bold]Spooled Doctor[/bold]")
    console.print("[dim]" + "─" * 40 + "[/dim]")

    sections = _run_sections(cwd, backend_url)

    all_checks: list[Check] = []
    for section_name, section_checks in sections:
        console.print(f"\n  [dim]{section_name}[/dim]")
        for result in section_checks:
            _print_check(result)
        all_checks.extend(section_checks)

    failures = [c for c in all_checks if not c[0] and not c[1]]
    warnings = [c for c in all_checks if not c[0] and c[1]]
    console.print()
    console.print("[dim]" + "─" * 40 + "[/dim]")

    if not failures and not warnings:
        console.print("[bold green]All checks passed — Spooled is ready![/bold green]")
    elif not failures:
        console.print(
            f"[bold yellow]{len(warnings)} warning{'s' if len(warnings) != 1 else ''} "
            f"(no blockers)[/bold yellow]"
        )
    else:
        console.print(
            f"[bold red]{len(failures)} check{'s' if len(failures) != 1 else ''} failed[/bold red]"
            + (f", {len(warnings)} warning{'s' if len(warnings) != 1 else ''}" if warnings else "")
        )

    console.print()
    sys.exit(0 if not failures else 1)
