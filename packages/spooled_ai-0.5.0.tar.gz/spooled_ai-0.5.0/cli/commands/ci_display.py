"""CI display — Rich console output formatting for CI commands.

Extracted from ci.py. Contains comparison result display, CI summary,
GitHub annotations, and GitLab code quality output.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import structlog

logger = structlog.get_logger(__name__)

try:
    from rich.console import Console

    console = Console(stderr=True)
except ImportError:
    console = None  # type: ignore


def _display_compare_results(result: dict[str, Any]) -> None:
    """Display comparison results to console in a Rich Panel."""
    from rich.panel import Panel

    summary = result["summary"]
    fp_status = result["fingerprint_status"]
    fp_hash = result.get("fingerprint_hash", "")[:16]
    agent_id = result.get("agent_id", "unknown")

    # Fingerprint status
    status_icon = {
        "match": "[green]MATCH[/green]",
        "accepted_variant": "[green]ACCEPTED VARIANT[/green]",
        "structural_match": "[green]MATCH[/green] [dim](structural)[/dim]",
        "variant": "[yellow]VARIANT[/yellow]",
        "new": "[yellow]NEW[/yellow]",
        "no_baseline": "[cyan]LEARNING[/cyan]",
        "learning": "[cyan]LEARNING[/cyan]",
    }.get(fp_status, fp_status)

    baseline_fp_hash = result.get("baseline_fingerprint_hash", "")
    baseline_path = result.get("baseline_path", "")

    panel_lines = []
    panel_lines.append(f"Fingerprint: {fp_hash}...  {status_icon}")

    # Show baseline intent ID and accept command for variants/new behaviors
    if fp_status in ("variant", "new") and baseline_fp_hash:
        baseline_intent_short = baseline_fp_hash[:16]
        panel_lines.append(f"Baseline intent: {baseline_intent_short}...")
        bp_flag = f" -b {baseline_path}" if baseline_path else ""
        panel_lines.append(
            f"[dim]Accept with:[/dim] spooled ci accept-variant "
            f"--intent {baseline_intent_short} --fingerprint {fp_hash}{bp_flag}"
        )

    # Spooled Score
    spooled = result.get("spooled_score", {})
    if spooled and spooled.get("score") is not None:
        sc = spooled["score"]
        grade = spooled.get("grade", "-")
        confidence = spooled.get("confidence", "low")
        color = {"A": "green", "B": "green", "C": "yellow", "D": "red", "F": "red"}.get(
            grade, "white"
        )
        panel_lines.append(
            f"Spooled Score: [{color}]{sc}/100 ({grade})[/{color}]  [dim]confidence: {confidence}[/dim]"
        )

    panel_lines.append("")

    # Metric deltas
    deltas = result.get("metric_deltas", {})
    if "tokens" in deltas:
        t = deltas["tokens"]
        sign = "+" if t["delta"] >= 0 else ""
        color = (
            "red" if abs(t["delta_pct"]) > 20 else "yellow" if abs(t["delta_pct"]) > 10 else "green"
        )
        panel_lines.append(
            f"Tokens:  {t['current']:,.0f} ({sign}{t['delta']:.0f}, [{color}]{sign}{t['delta_pct']}%[/{color}])"
        )
    if "step_count" in deltas:
        s = deltas["step_count"]
        sign = "+" if s["delta"] >= 0 else ""
        panel_lines.append(f"Steps:   {s['current']} ({sign}{s['delta']})")

    # Tool diff
    td = result.get("tool_diff")
    if td and (td.get("added") or td.get("removed")):
        panel_lines.append("")
        panel_lines.append("Tool Changes:")
        if td.get("removed"):
            panel_lines.append(f"  [red]Removed:[/red] {', '.join(td['removed'])}")
        if td.get("added"):
            panel_lines.append(f"  [green]Added:[/green]   {', '.join(td['added'])}")
        if td.get("baseline_sequence") and td.get("current_sequence"):
            panel_lines.append(f"  Baseline seq: {td['baseline_sequence']}")
            panel_lines.append(f"  Current  seq: {td['current_sequence']}")
    elif td and td.get("current_sequence") != td.get("baseline_sequence"):
        panel_lines.append("")
        if fp_status == "structural_match":
            panel_lines.append(
                "[dim]Tool ordering differs from baseline (expected variance for LLM agents)[/dim]"
            )
        else:
            panel_lines.append("Tool Changes: [yellow]Sequence reordered[/yellow]")

    panel_lines.append("")

    # Signals
    signal_count = summary["signal_count"]
    if signal_count > 0:
        severity = summary["severity"]
        color = {"high": "red", "medium": "yellow", "low": "green"}.get(severity, "white")
        panel_lines.append(
            f"Signals: [{color}]{signal_count} detected (severity: {severity})[/{color}]"
        )
    else:
        panel_lines.append("Signals: [green]none[/green]")

    # Policy
    if summary.get("policy_enabled"):
        if summary["policy_passed"]:
            panel_lines.append("Policy:  [green]PASSED[/green]")
        else:
            violations = summary.get("policy_violations", 0)
            panel_lines.append(f"Policy:  [red]FAILED ({violations} violations)[/red]")
            if summary.get("should_block"):
                panel_lines.append("[red]BLOCKED - merge will be prevented[/red]")

    # Overall result for subtitle
    if summary.get("should_block"):
        result_str = "[red]FAIL[/red]"
        border_style = "red"
    elif fp_status in ("no_baseline", "learning"):
        result_str = "[cyan]LEARNING[/cyan]"
        border_style = "cyan"
    elif fp_status == "new":
        result_str = "[yellow]NEW BEHAVIOR[/yellow]"
        border_style = "yellow"
    else:
        result_str = "[green]PASS[/green]"
        border_style = "green"

    # First-run guidance for new agents
    if fp_status in ("no_baseline", "learning"):
        panel_lines.append("")
        panel_lines.append(
            "[dim]First run detected. Spooled is learning behavioral patterns.[/dim]"
        )
        panel_lines.append("[dim]Run 3+ times, then build a baseline:[/dim]")
        panel_lines.append(
            "[dim]  spooled ci update-baseline --from .spooled/traces/ --out baselines/[/dim]"
        )

    content = "\n".join(panel_lines)
    panel = Panel(
        content,
        title=f"[bold]{agent_id}[/bold]",
        subtitle=result_str,
        border_style=border_style,
        padding=(0, 2),
    )
    console.print(panel)


def _display_ci_summary(
    results: list[dict[str, Any]],
    ci_summary: dict[str, Any],
    out: Path,
) -> None:
    """Display CI summary table — shared by `run` and `batch_compare`."""
    from rich.table import Table

    table = Table(show_header=True, header_style="bold")
    table.add_column("Agent")
    table.add_column("Status")
    table.add_column("Score", justify="right")
    table.add_column("Signals", justify="right")
    table.add_column("Tokens")

    for r in results:
        agent = r.get("agent_id", "unknown")
        fp_status = r.get("fingerprint_status", "unknown")

        status_map = {
            "match": "[green]MATCH[/green]",
            "accepted_variant": "[green]ACCEPTED[/green]",
            "structural_match": "[green]MATCH[/green]",
            "variant": "[yellow]VARIANT[/yellow]",
            "new": "[yellow]NEW[/yellow]",
            "no_baseline": "[cyan]LEARNING[/cyan]",
            "learning": "[cyan]LEARNING[/cyan]",
            "not_compared": "[dim]POLICY-ONLY[/dim]",
        }
        status_str = status_map.get(fp_status, fp_status)

        # Score
        trace_score = (
            r.get("spooled_score", {}).get("score")
            if isinstance(r.get("spooled_score"), dict)
            else r.get("summary", {}).get("spooled_score")
        )
        grade = (
            r.get("spooled_score", {}).get("grade", "")
            if isinstance(r.get("spooled_score"), dict)
            else ""
        )
        if trace_score is not None:
            color = {"A": "green", "B": "green", "C": "yellow", "D": "red", "F": "red"}.get(
                grade, "white"
            )
            score_str = f"[{color}]{trace_score} ({grade})[/{color}]"
        else:
            score_str = "-"

        # Signals
        signal_count = r.get("summary", {}).get("signal_count", 0)
        signal_str = str(signal_count) if signal_count > 0 else "[green]0[/green]"

        # Token delta
        token_str = "-"
        deltas = r.get("metric_deltas", {})
        if "tokens" in deltas:
            t = deltas["tokens"]
            sign = "+" if t.get("delta", 0) >= 0 else ""
            pct = t.get("delta_pct", 0)
            color = "red" if abs(pct) > 20 else "yellow" if abs(pct) > 10 else "green"
            token_str = f"[{color}]{sign}{pct}%[/{color}]"

        table.add_row(agent, status_str, score_str, signal_str, token_str)

    console.print(table)

    # Agent-level Spooled Score
    _agent_score = ci_summary.get("spooled_score", {})
    if _agent_score and _agent_score.get("score") is not None:
        _sc = _agent_score["score"]
        _gr = _agent_score["grade"]
        _color = {"A": "green", "B": "green", "C": "yellow", "D": "red", "F": "red"}.get(
            _gr, "white"
        )
        console.print(f"  [{_color}]Spooled Score: {_sc}/100 ({_gr})[/{_color}]")

    console.print(f"  Reports written to: {out}/")


def _display_ci_result(overall_exit: int) -> None:
    """Display final CI PASS/FAIL banner in a Rich Panel."""
    from rich.panel import Panel

    if overall_exit == 0:
        panel = Panel(
            "[bold green]CI RESULT: PASS[/bold green]",
            border_style="green",
            padding=(0, 4),
        )
    else:
        panel = Panel(
            "[bold red]CI RESULT: FAIL[/bold red]",
            border_style="red",
            padding=(0, 4),
        )
    console.print(panel)


# ─── update-baseline ────────────────────────────────────────────────────────


def _emit_github_annotations(report_data: dict) -> None:
    signals = report_data.get("signals", {})
    for name, signal in signals.items():
        if not isinstance(signal, dict) or not signal.get("detected"):
            continue
        severity = signal.get("severity", "medium")
        level = {
            "high": "error",
            "medium": "warning",
            "low": "notice",
            "info": "notice",
        }.get(severity, "notice")
        message = signal.get("message") or f"{name} detected"
        message = str(message).replace("\n", " ").strip()
        title = name.replace("_", " ").title()
        print(f"::{level} title=Spooled {title}::{message}")


def _write_summary_json(report_data: dict, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "agent_id": report_data.get("agent_id"),
        "run_id": report_data.get("run_id"),
        "trace_file": report_data.get("trace_file"),
        "summary": report_data.get("summary", {}),
        "policy": report_data.get("policy", {}),
    }
    output_path.write_text(json.dumps(payload, indent=2))


def _write_gitlab_codequality(report_data: dict, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    trace_path = report_data.get("trace_file") or "ai-behavior-report"
    signals = report_data.get("signals", {})
    findings = []

    severity_map = {
        "high": "critical",
        "medium": "major",
        "low": "minor",
        "info": "info",
    }

    for name, signal in signals.items():
        if not isinstance(signal, dict) or not signal.get("detected"):
            continue
        message = signal.get("message") or f"{name} detected"
        fingerprint = hashlib.sha256(f"{name}:{message}".encode()).hexdigest()
        severity = severity_map.get(signal.get("severity", "minor"), "minor")

        findings.append(
            {
                "description": str(message),
                "fingerprint": fingerprint,
                "severity": severity,
                "location": {
                    "path": trace_path,
                    "lines": {"begin": 1, "end": 1},
                },
            }
        )

    output_path.write_text(json.dumps(findings, indent=2))
