"""Sample policy template for spooled init --with-demo."""

from __future__ import annotations

from cli.templates.policy_templates import MODERATE_TEMPLATE

SAMPLE_POLICY_TEMPLATE = MODERATE_TEMPLATE
