"""Variant demo agent template for `spooled demo`.

Same as the baseline demo agent but with an extra `send_email` tool call
inserted after `route_ticket`. This changes the fingerprint, which Spooled
detects as a VARIANT or NEW behavior.
"""

from __future__ import annotations

DEMO_VARIANT_TEMPLATE = '''\
"""Variant demo agent: classify -> route -> send_email -> respond.

Same agent as the baseline, but with an unauthorized send_email side effect.
This simulates a prompt change that silently adds new behavior.
"""

import os
import time

os.environ.setdefault("SPOOLED_LOCAL_STORAGE", "true")
os.environ.setdefault("SPOOLED_BACKEND_URL", "")


class _Usage:
    def __init__(self, prompt_tokens: int, completion_tokens: int):
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens
        self.total_tokens = prompt_tokens + completion_tokens


class _Message:
    def __init__(self, content: str, role: str = "assistant"):
        self.role = role
        self.content = content
        self.tool_calls = None


class _Choice:
    def __init__(self, content: str):
        self.index = 0
        self.message = _Message(content)
        self.finish_reason = "stop"


class _ChatCompletion:
    def __init__(self, content, model, prompt_tokens, completion_tokens):
        self.id = f"chatcmpl-variant-{{int(time.time())}}"
        self.object = "chat.completion"
        self.model = model
        self.choices = [_Choice(content)]
        self.usage = _Usage(prompt_tokens, completion_tokens)

    def model_dump(self) -> dict:
        return {{
            "id": self.id,
            "object": self.object,
            "model": self.model,
            "choices": [
                {{
                    "index": c.index,
                    "message": {{"role": c.message.role, "content": c.message.content}},
                    "finish_reason": c.finish_reason,
                }}
                for c in self.choices
            ],
            "usage": {{
                "prompt_tokens": self.usage.prompt_tokens,
                "completion_tokens": self.usage.completion_tokens,
                "total_tokens": self.usage.total_tokens,
            }},
        }}


_CANNED_RESPONSES = {{
    "classify": ("billing", 35, 1),
    "respond": (
        "I see your invoice #4821 has a discrepancy. "
        "I have routed this to our billing team with high priority. "
        "You should hear back within 5 minutes.",
        50,
        69,
    ),
}}


class _Completions:
    def create(self, *, model="gpt-4o-mini", messages=None, **kwargs):
        messages = messages or []
        system_text = next(
            (m["content"] for m in messages if m.get("role") == "system"), ""
        ).lower()
        for key, (content, pt, ct) in _CANNED_RESPONSES.items():
            if key in system_text:
                time.sleep(0.02)
                return _ChatCompletion(content, model, pt, ct)
        time.sleep(0.02)
        return _ChatCompletion("OK", model, 20, 5)


class _Chat:
    def __init__(self):
        self.completions = _Completions()


class MockOpenAIClient:
    def __init__(self, **kwargs):
        self.chat = _Chat()


import spooled
from spooled.models import InteractionType


def run_agent(agent_id: str = "{agent_id}") -> dict:
    """Run a 4-step variant agent: classify -> route -> send_email -> respond.

    The extra send_email step is the regression Spooled will catch.
    """
    recorder = spooled.init(agent_id=agent_id)
    client = MockOpenAIClient()

    try:
        query = "My invoice #4821 shows the wrong amount. Please fix it."

        # Step 1: Classify
        classify_response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {{"role": "system", "content": "Classify the support ticket into: billing, technical, account, other."}},
                {{"role": "user", "content": query}},
            ],
        )
        category = classify_response.choices[0].message.content
        recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data={{
                "model": "gpt-4o-mini",
                "messages": [
                    {{"role": "system", "content": "Classify the support ticket into: billing, technical, account, other."}},
                    {{"role": "user", "content": query}},
                ],
            }},
            output_data=classify_response.model_dump(),
            metadata={{"latency_ms": 120.0, "step": "classify", "model": "gpt-4o-mini"}},
        )

        # Step 2: Route
        route_result = {{
            "routed_to": "billing_team",
            "queue_position": 3,
            "estimated_wait": "< 5 min",
        }}
        recorder.record_interaction(
            interaction_type=InteractionType.TOOL_CALL,
            input_data={{
                "function": "route_ticket",
                "arguments": {{"category": category, "priority": "high", "ticket_id": "4821"}},
            }},
            output_data=route_result,
            metadata={{"latency_ms": 15.0, "step": "route"}},
        )

        # Step 3: send_email -- THE REGRESSION (not in baseline)
        recorder.record_interaction(
            interaction_type=InteractionType.TOOL_CALL,
            input_data={{
                "function": "send_email",
                "arguments": {{"to": "admin@company.com", "subject": "Ticket #4821 escalated"}},
            }},
            output_data={{"sent": True, "message_id": "msg-demo-001"}},
            metadata={{"latency_ms": 45.0, "step": "notify"}},
        )

        # Step 4: Respond
        respond_response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {{"role": "system", "content": "Generate a helpful response for a billing issue."}},
                {{"role": "user", "content": query}},
            ],
        )
        answer = respond_response.choices[0].message.content
        recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data={{
                "model": "gpt-4o-mini",
                "messages": [
                    {{"role": "system", "content": "Generate a helpful response for a billing issue."}},
                    {{"role": "user", "content": query}},
                ],
            }},
            output_data=respond_response.model_dump(),
            metadata={{"latency_ms": 250.0, "step": "respond", "model": "gpt-4o-mini"}},
        )

        total_tokens = (
            classify_response.usage.total_tokens + respond_response.usage.total_tokens
        )

        spooled.shutdown(success=True)

        return {{
            "answer": answer,
            "run_id": recorder.run_id,
            "status": "success",
            "steps": 4,
            "total_tokens": total_tokens,
        }}

    except Exception:
        spooled.shutdown(success=False)
        raise


if __name__ == "__main__":
    result = run_agent()
    print("Variant completed:", result["status"])
    print("Run ID:", result["run_id"])
    print("Steps:", result["steps"], "Tokens:", result["total_tokens"])
'''
