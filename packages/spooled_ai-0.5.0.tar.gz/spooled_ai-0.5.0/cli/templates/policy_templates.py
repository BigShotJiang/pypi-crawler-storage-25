"""Policy templates for spooled policy init --template."""

from __future__ import annotations

STRICT_TEMPLATE = """\
# Spooled Policy: STRICT
# All 12 signals as fail_if with tight thresholds.
# Designed for production-critical agents where any behavioral drift blocks merges.

name: "strict_policy"
enabled: true
block_merges: true

rules:
  - name: "strict_gating"
    description: "Block on any behavioral change"
    severity: "high"
    fail_if:
      new_side_effects: true
      new_tools: true
      latency_spike:
        threshold_percent: 30.0
      retry_explosion:
        threshold: 3
      error_increase:
        threshold: 1
      tool_usage_change:
        threshold_percent: 30.0
      token_usage_spike:
        threshold_percent: 30.0
      component_latency_drift:
        threshold_percent: 50.0
      content_filter_rate_change:
        threshold: 0.05
      tool_overuse:
        threshold_percent: 30.0
      retrieval_regression:
        threshold: 0.1
      on_variant: true
"""

MODERATE_TEMPLATE = """\
# Spooled Policy: MODERATE (recommended)
# Critical signals block merges, others warn.
# Good balance of safety and velocity for most teams.

name: "moderate_policy"
enabled: true
block_merges: true

rules:
  - name: "critical_blockers"
    description: "Block on structural changes and safety signals"
    severity: "high"
    fail_if:
      new_side_effects: true
      new_tools: true
      on_variant: true
      retry_explosion:
        threshold: 5
      content_filter_rate_change:
        threshold: 0.1

  - name: "metric_warnings"
    description: "Warn on metric drift and quality regressions"
    severity: "medium"
    warn_if:
      latency_spike:
        threshold_percent: 50.0
      error_increase:
        threshold: 2
      tool_usage_change:
        threshold_percent: 50.0
      token_usage_spike:
        threshold_percent: 50.0
      component_latency_drift:
        threshold_percent: 100.0
      tool_overuse:
        threshold_percent: 50.0
      retrieval_regression:
        threshold: 0.2
      on_variant:
        min_similarity: 0.85
"""

PERMISSIVE_TEMPLATE = """\
# Spooled Policy: PERMISSIVE
# All signals as warnings with relaxed thresholds.
# Useful for early adoption or experimentation — nothing blocks.

name: "permissive_policy"
enabled: true
block_merges: false

rules:
  - name: "observe_all"
    description: "Warn on all signals with relaxed thresholds"
    severity: "low"
    warn_if:
      new_side_effects: true
      new_tools: true
      latency_spike:
        threshold_percent: 100.0
      retry_explosion:
        threshold: 10
      error_increase:
        threshold: 5
      tool_usage_change:
        threshold_percent: 100.0
      token_usage_spike:
        threshold_percent: 100.0
      component_latency_drift:
        threshold_percent: 200.0
      content_filter_rate_change:
        threshold: 0.2
      tool_overuse:
        threshold_percent: 100.0
      retrieval_regression:
        threshold: 0.3
"""

POLICY_TEMPLATES: dict[str, str] = {
    "strict": STRICT_TEMPLATE,
    "moderate": MODERATE_TEMPLATE,
    "permissive": PERMISSIVE_TEMPLATE,
}


def get_template(name: str) -> str:
    """Get a policy template by name.

    Args:
        name: Template name (strict, moderate, permissive)

    Returns:
        YAML template string

    Raises:
        ValueError: If template name is not recognized
    """
    if name not in POLICY_TEMPLATES:
        valid = ", ".join(POLICY_TEMPLATES.keys())
        raise ValueError(f"Unknown template '{name}'. Valid templates: {valid}")
    return POLICY_TEMPLATES[name]
