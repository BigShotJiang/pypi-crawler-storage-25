"""Templates for scaffolding Spooled projects."""

from __future__ import annotations
