"""Demo agent template for spooled init --with-demo."""

from __future__ import annotations

DEMO_AGENT_TEMPLATE = '''\
"""Demo agent: classify -> route -> respond.

A self-contained agent that demonstrates Spooled auto-instrumentation.
No API keys required -- uses a mock OpenAI client with canned responses.

Spooled captures every LLM call automatically. In production you just swap
MockOpenAIClient for the real ``openai.OpenAI()`` and everything still records.

Run:
    python {agent_id}.py

What production code looks like (two lines of Spooled, everything else is normal):

    import spooled
    spooled.init(agent_id="my_agent")          # <-- line 1

    from openai import OpenAI
    client = OpenAI()
    response = client.chat.completions.create(  # captured automatically
        model="gpt-4o-mini",
        messages=[...],
    )

    spooled.shutdown()                          # <-- line 2
"""

import os
import time

os.environ.setdefault("SPOOLED_LOCAL_STORAGE", "true")
os.environ.setdefault("SPOOLED_BACKEND_URL", "")


# ---------------------------------------------------------------------------
# Mock OpenAI client -- stands in for the real SDK so the demo runs without
# an API key.  Spooled\'s auto-instrumentation hooks patch the real
# openai.resources.chat.completions.Completions class at import time, so
# this mock records interactions via the recorder directly while keeping the
# main code identical to what a real agent looks like.
# ---------------------------------------------------------------------------

class _Usage:
    def __init__(self, prompt_tokens: int, completion_tokens: int):
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens
        self.total_tokens = prompt_tokens + completion_tokens


class _Message:
    def __init__(self, content: str, role: str = "assistant"):
        self.role = role
        self.content = content
        self.tool_calls = None


class _Choice:
    def __init__(self, content: str):
        self.index = 0
        self.message = _Message(content)
        self.finish_reason = "stop"


class _ChatCompletion:
    """Minimal replica of openai.types.chat.ChatCompletion."""

    def __init__(self, content: str, model: str, prompt_tokens: int, completion_tokens: int):
        self.id = f"chatcmpl-demo-{{int(time.time())}}"
        self.object = "chat.completion"
        self.model = model
        self.choices = [_Choice(content)]
        self.usage = _Usage(prompt_tokens, completion_tokens)

    def model_dump(self) -> dict:
        return {{
            "id": self.id,
            "object": self.object,
            "model": self.model,
            "choices": [
                {{
                    "index": c.index,
                    "message": {{"role": c.message.role, "content": c.message.content}},
                    "finish_reason": c.finish_reason,
                }}
                for c in self.choices
            ],
            "usage": {{
                "prompt_tokens": self.usage.prompt_tokens,
                "completion_tokens": self.usage.completion_tokens,
                "total_tokens": self.usage.total_tokens,
            }},
        }}


# Canned responses keyed by system-prompt keyword
_CANNED_RESPONSES = {{
    "classify": ("billing", 35, 1),
    "respond": (
        "I see your invoice #4821 has a discrepancy. "
        "I have routed this to our billing team with high priority. "
        "You should hear back within 5 minutes.",
        50,
        69,
    ),
}}


class _Completions:
    def create(self, *, model: str = "gpt-4o-mini", messages=None, **kwargs) -> _ChatCompletion:
        """Return a canned ChatCompletion, simulating latency."""
        messages = messages or []
        system_text = next(
            (m["content"] for m in messages if m.get("role") == "system"), ""
        ).lower()

        for key, (content, pt, ct) in _CANNED_RESPONSES.items():
            if key in system_text:
                time.sleep(0.05)  # simulate network latency
                return _ChatCompletion(content, model, pt, ct)

        time.sleep(0.05)
        return _ChatCompletion("OK", model, 20, 5)


class _Chat:
    def __init__(self):
        self.completions = _Completions()


class MockOpenAIClient:
    """Drop-in mock for ``openai.OpenAI()`` -- no API key needed."""

    def __init__(self, **kwargs):
        self.chat = _Chat()


# ---------------------------------------------------------------------------
# Agent code -- looks exactly like production code with a real OpenAI client.
# ---------------------------------------------------------------------------

import spooled
from spooled.models import InteractionType


def run_agent(agent_id: str = "{agent_id}") -> dict:
    """Run a 3-step support agent: classify -> route -> respond."""

    # -- Spooled line 1: initialise (installs auto-instrumentation hooks) --
    recorder = spooled.init(agent_id=agent_id)

    # In production: client = openai.OpenAI()
    client = MockOpenAIClient()

    try:
        query = "My invoice #4821 shows the wrong amount. Please fix it."

        # Step 1: Classify the ticket
        classify_response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {{"role": "system", "content": "Classify the support ticket into: billing, technical, account, other."}},
                {{"role": "user", "content": query}},
            ],
        )
        category = classify_response.choices[0].message.content

        # Since MockOpenAIClient isn\'t the real openai SDK, the auto-hook
        # won\'t intercept it.  Record manually so the demo trace is complete.
        # With the real openai library this block is unnecessary -- Spooled
        # captures it automatically.
        recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data={{
                "model": "gpt-4o-mini",
                "messages": [
                    {{"role": "system", "content": "Classify the support ticket into: billing, technical, account, other."}},
                    {{"role": "user", "content": query}},
                ],
            }},
            output_data=classify_response.model_dump(),
            metadata={{"latency_ms": 120.0, "step": "classify", "model": "gpt-4o-mini"}},
        )

        # Step 2: Route to the right handler (tool call -- always manual)
        route_result = {{
            "routed_to": "billing_team",
            "queue_position": 3,
            "estimated_wait": "< 5 min",
        }}
        recorder.record_interaction(
            interaction_type=InteractionType.TOOL_CALL,
            input_data={{
                "function": "route_ticket",
                "arguments": {{"category": category, "priority": "high", "ticket_id": "4821"}},
            }},
            output_data=route_result,
            metadata={{"latency_ms": 15.0, "step": "route"}},
        )

        # Step 3: Generate a response
        respond_response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {{"role": "system", "content": "Generate a helpful response for a billing issue."}},
                {{"role": "user", "content": query}},
            ],
        )
        answer = respond_response.choices[0].message.content

        recorder.record_interaction(
            interaction_type=InteractionType.LLM_CALL,
            input_data={{
                "model": "gpt-4o-mini",
                "messages": [
                    {{"role": "system", "content": "Generate a helpful response for a billing issue."}},
                    {{"role": "user", "content": query}},
                ],
            }},
            output_data=respond_response.model_dump(),
            metadata={{"latency_ms": 250.0, "step": "respond", "model": "gpt-4o-mini"}},
        )

        total_tokens = (
            classify_response.usage.total_tokens + respond_response.usage.total_tokens
        )

        # -- Spooled line 2: shut down --
        spooled.shutdown(success=True)

        return {{
            "answer": answer,
            "run_id": recorder.run_id,
            "status": "success",
            "steps": 3,
            "total_tokens": total_tokens,
        }}

    except Exception as e:
        spooled.shutdown(success=False)
        raise


if __name__ == "__main__":
    result = run_agent()
    print("Agent completed:", result["status"])
    print("Run ID:", result["run_id"])
    print("Steps:", result["steps"], "Tokens:", result["total_tokens"])
'''
