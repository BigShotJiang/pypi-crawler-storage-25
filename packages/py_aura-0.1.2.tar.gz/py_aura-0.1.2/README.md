# brainrot 🧠

Wassup, gooners. So today I got -300 aura so I decided to make this and gain my sigma status and +1000 aura.

**brainrot** is a Python keyword transpiler that replaces boring standard keywords with certified brainrot meme slang. Write unhinged code. Run it anyway.

---

## Installation

```bash
pip install py-aura
```

Requires Python 3.10+. Requires having any rizz at all.

---

## Usage

### As a CLI

```bash
brainrot run  myfile.brainrot   # execute your brainrot file
brainrot show myfile.brainrot   # translate it to boring Python
brainrot keys                   # print the full keyword map
```

### As a module

```python
import brainrot

brainrot.run("myfile.brainrot")           # execute directly
brainrot.translate("myfile.brainrot")     # get the Python source back
brainrot.show_keywords()                  # print the keyword table
brainrot.to_python(source_str)            # translate a string
brainrot.to_brainrot(source_str)          # corrupt normal Python
```

---

## The Keyword Map

| brainrot | Python |
|---|---|
| `npc_check` | `if` |
| `plot_twist` | `elif` |
| `sybau` | `else` |
| `grind` | `for` |
| `no_cap_loop` | `while` |
| `yeet` | `break` |
| `skibidi_skip` | `continue` |
| `vibe` | `pass` |
| `sigma_move` | `def` |
| `its_giving` | `return` |
| `ohio_school` | `class` |
| `lowkey_func` | `lambda` |
| `rizz_and` | `and` |
| `bussin_or` | `or` |
| `no_rizz` | `not` |
| `ate` | `in` |
| `hits_different` | `is` |
| `W` | `True` |
| `L` | `False` |
| `ghosted` | `None` |
| `summon` | `import` |
| `straight_from` | `from` |
| `aka` | `as` |
| `bet` | `try` |
| `mid_detected` | `except` |
| `no_matter_what` | `finally` |
| `ratio` | `raise` |
| `linked_up` | `with` |
| `slay_output` | `yield` |
| `main_character` | `global` |
| `side_character` | `nonlocal` |
| `ghosted_var` | `del` |
| `trust_me_bro` | `assert` |
| `lowkey_async` | `async` |
| `hold_on_bestie` | `await` |

---

## Example

```python
# hello.brainrot

straight_from math summon sqrt aka square_root

ohio_school Animal:
    sigma_move __init__(self, name, vibe_score):
        self.name = name
        self.vibe_score = vibe_score

    sigma_move is_sigma(self):
        its_giving self.vibe_score > 8

sigma_move classify(animals):
    sigmas, npcs = [], []
    grind a ate animals:
        npc_check a.is_sigma():
            sigmas.append(a)
        sybau:
            npcs.append(a)
    its_giving sigmas, npcs

trust_me_bro W, "W must be truthy no cap"
```

Run it:

```bash
brainrot run hello.brainrot
```

---

## aura status

| action | aura |
|---|---|
| Writing normal Python | -300 |
| Installing brainrot | +500 |
| Actually shipping something with it | +1000 |
| Getting a PR merged | sigma |

---

## Contributing

PRs welcome. If you have a better meme keyword for something, open an issue. The bar is: would a chronically online 14 year old understand it. If yes, ship it.

---

## License

Not open source but I'm too sigma to care so do whatever you want with it.
