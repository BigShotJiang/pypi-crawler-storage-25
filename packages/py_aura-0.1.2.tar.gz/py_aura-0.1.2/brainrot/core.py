"""
py-aura / brainrot — A Python keyword transpiler that replaces boring standard
keywords with certified brainrot meme slang. Write unhinged code. Run it anyway.

Usage:
    import brainrot
    brainrot.run("myfile.brainrot")       # run a .brainrot file
    brainrot.translate("myfile.brainrot") # translate to normal Python
    brainrot.show_keywords()              # print the full keyword map

CLI:
    python -m brainrot run  myfile.brainrot
    python -m brainrot show myfile.brainrot
    python -m brainrot keys
"""

import re
import sys

# ── The sacred mapping ────────────────────────────────────────────────────────

BRAINROT_MAP: dict[str, str] = {

    # ── control flow ──────────────────────────────────────────────────────────
    "if":                   "npc_check",
    "elif":                 "plot_twist",
    "else":                 "sybau",
    "for":                  "grind",
    "while":                "no_cap_loop",
    "break":                "yeet",
    "continue":             "skibidi_skip",
    "pass":                 "vibe",
    "match":                "vibe_check",
    "case":                 "its_giving_vibes",

    # ── functions & classes ───────────────────────────────────────────────────
    "def":                  "sigma_move",
    "return":               "its_giving",
    "class":                "ohio_school",
    "lambda":               "lowkey_func",

    # ── decorators ────────────────────────────────────────────────────────────
    "@property":            "@main_character_trait",
    "@staticmethod":        "@npc_behavior",
    "@classmethod":         "@ohio_tradition",
    "@abstractmethod":      "@delulu",

    # ── dunder methods ────────────────────────────────────────────────────────
    "__init__":             "__spawn__",
    "__str__":              "__yap__",
    "__repr__":             "__mirror__",
    "__len__":              "__body_count__",
    "__del__":              "__ghosted__",
    "__call__":             "__rizz__",
    "__iter__":             "__grindset__",
    "__next__":             "__keep_pushing__",
    "__enter__":            "__linked_up__",
    "__exit__":             "__peace_out__",
    "__getitem__":          "__yoink__",
    "__setitem__":          "__slay__",
    "__delitem__":          "__ratio__",
    "__contains__":         "__ate__",
    "__add__":              "__rizz_up__",
    "__sub__":              "__ratio_down__",
    "__mul__":              "__grind_by__",
    "__truediv__":          "__split_the_tab__",
    "__floordiv__":         "__lowkey_divide__",
    "__mod__":              "__left_on_read__",
    "__pow__":              "__glow_up__",
    "__eq__":               "__same_energy__",
    "__ne__":               "__different_energy__",
    "__lt__":               "__lower__",
    "__gt__":               "__higher__",
    "__le__":               "__lowkey__",
    "__ge__":               "__highkey__",
    "__bool__":             "__W_or_L__",
    "__hash__":             "__aura_score__",
    "__getattr__":          "__stalk__",
    "__setattr__":          "__impose__",
    "__delattr__":          "__cancel__",
    "__new__":              "__manifest__",
    "__class__":            "__ohio_school__",
    "__slots__":            "__loadout__",
    "__all__":              "__main_characters__",
    "__doc__":              "__lore__",
    "__name__":             "__username__",
    "__file__":             "__origin__",
    "__module__":           "__arc__",
    "__debug__":            "__trust_me_bro_mode__",

    # ── logic ─────────────────────────────────────────────────────────────────
    "and":                  "rizz_and",
    "or":                   "bussin_or",
    "not":                  "no_rizz",
    "in":                   "ate",
    "is":                   "hits_different",
    "True":                 "W",
    "False":                "L",
    "None":                 "ghosted",
    "NotImplemented":       "too_lazy",

    # ── imports ───────────────────────────────────────────────────────────────
    "import":               "summon",
    "from":                 "straight_from",
    "as":                   "aka",

    # ── exceptions ────────────────────────────────────────────────────────────
    "try":                  "bet",
    "except":               "mid_detected",
    "finally":              "no_matter_what",
    "raise":                "ratio",
    "Exception":            "Ratio",
    "ValueError":           "MidValue",
    "TypeError":            "WrongVibes",
    "KeyError":             "GhostedKey",
    "IndexError":           "OutOfGrind",
    "AttributeError":       "NoRizzAttribute",
    "ImportError":          "FailedSummon",
    "RuntimeError":         "MidRuntime",
    "StopIteration":        "GrindsetOver",
    "NotImplementedError":  "TooLazyError",
    "PermissionError":      "RatioedByOS",
    "FileNotFoundError":    "GhostedFile",
    "OverflowError":        "TooMuchRizz",
    "ZeroDivisionError":    "DivideByL",
    "RecursionError":       "InfiniteGrind",
    "OSError":              "SkibidiOS",
    "IOError":              "SkibidiIO",
    "MemoryError":          "BrokeAhhError",
    "AssertionError":       "NahtTrustingBro",
    "NameError":            "WhoError",
    "SyntaxError":          "BrainrotError",
    "IndentationError":     "TabVsSpacesRatio",
    "StopAsyncIteration":   "AsyncGrindsetOver",
    "ArithmeticError":      "MathIsHard",
    "BaseException":        "BaseRatio",

    # ── context managers & generators ─────────────────────────────────────────
    "with":                 "linked_up",
    "yield":                "slay_output",
    "yield from":           "slay_from",

    # ── scope ─────────────────────────────────────────────────────────────────
    "global":               "main_character",
    "nonlocal":             "side_character",
    "del":                  "ghosted_var",

    # ── type / misc keywords ──────────────────────────────────────────────────
    "assert":               "trust_me_bro",
    "async":                "lowkey_async",
    "await":                "hold_on_bestie",
    "type":                 "lowkey_type",

    # ── builtin functions ─────────────────────────────────────────────────────
    "print":                "yap",
    "len":                  "body_count",
    "range":                "grind_range",
    "enumerate":            "ranked_grind",
    "zip":                  "link_up",
    "map":                  "glow_up",
    "filter":               "npc_filter",
    "sorted":               "sigma_sort",
    "reversed":             "plot_twist_list",
    "sum":                  "total_aura",
    "min":                  "most_L",
    "max":                  "most_W",
    "abs":                  "no_cap_value",
    "round":                "lowkey_round",
    "isinstance":           "hits_different_check",
    "hasattr":              "has_rizz",
    "getattr":              "get_rizz",
    "setattr":              "set_rizz",
    "delattr":              "cancel_rizz",
    "input":                "ask_the_chat",
    "open":                 "unlock",
    "super":                "elder_sigma",
    "vars":                 "character_sheet",
    "dir":                  "full_lore",
    "id":                   "aura_id",
    "repr":                 "mirror",
    "callable":             "has_rizz_move",
    "iter":                 "start_grind",
    "next":                 "next_grind",
    "any":                  "anyone_bussin",
    "all":                  "everyone_bussin",
    "hex":                  "sigma_hex",
    "bin":                  "binary_grind",
    "oct":                  "octal_arc",
    "ord":                  "aura_number",
    "chr":                  "aura_char",
    "pow":                  "glow_up_by",
    "divmod":               "split_and_leftover",
    "hash":                 "get_aura_score",
    "format":               "rizz_format",
    "eval":                 "trust_me_bro_exec",
    "exec":                 "yolo_exec",
    "compile":              "forge_sigma",
    "globals":              "main_characters_dict",
    "locals":               "side_characters_dict",
    "breakpoint":           "pause_the_grind",
    "exit":                 "log_off",
    "quit":                 "ragequit",

    # ── builtin types ─────────────────────────────────────────────────────────
    "str":                  "yap_type",
    "int":                  "sigma_int",
    "float":                "mid_float",
    "bool":                 "W_or_L",
    "list":                 "grind_list",
    "dict":                 "lore_book",
    "set":                  "no_duplicates",
    "tuple":                "locked_in",
    "bytes":                "raw_sigma",
    "bytearray":            "mutable_sigma",
    "complex":              "imaginary_rizz",
    "frozenset":            "perma_locked",
    "memoryview":           "sigma_vision",
    "object":               "base_ohio",

}

# Reverse map for translating brainrot → Python
PYTHON_MAP: dict[str, str] = {v: k for k, v in BRAINROT_MAP.items()}

# Build patterns — longest tokens first, decorators & dunders handled literally
def _make_pattern(keys: list[str]) -> re.Pattern:
    parts = []
    for k in sorted(keys, key=len, reverse=True):
        if k.startswith("@") or k.startswith("__"):
            parts.append(re.escape(k))
        else:
            parts.append(r'\b' + re.escape(k) + r'\b')
    return re.compile('(' + '|'.join(parts) + ')')

_BRAINROT_PATTERN = _make_pattern(list(BRAINROT_MAP.keys()))
_PYTHON_PATTERN   = _make_pattern(list(PYTHON_MAP.keys()))


# ── Core translation ──────────────────────────────────────────────────────────

def _translate(source: str, pattern: re.Pattern, mapping: dict) -> str:
    """Translate source skipping string literals and comments."""
    result = []
    i = 0
    while i < len(source):
        # triple-quoted strings
        if source[i:i+3] in ('"""', "'''"):
            quote = source[i:i+3]
            end = i + 3
            while end < len(source):
                if source[end] == '\\':
                    end += 2
                    continue
                if source[end:end+3] == quote:
                    end += 3
                    break
                end += 1
            result.append(source[i:end])
            i = end
            continue
        # single-quoted strings
        if source[i] in ('"', "'"):
            quote = source[i]
            end = i + 1
            while end < len(source):
                if source[end] == '\\':
                    end += 2
                    continue
                if source[end] == quote:
                    end += 1
                    break
                end += 1
            result.append(source[i:end])
            i = end
            continue
        # comments
        if source[i] == '#':
            end = source.find('\n', i)
            end = end if end != -1 else len(source)
            result.append(source[i:end])
            i = end
            continue
        # keyword match
        m = pattern.match(source, i)
        if m:
            result.append(mapping[m.group()])
            i = m.end()
        else:
            result.append(source[i])
            i += 1
    return ''.join(result)


def to_brainrot(source: str) -> str:
    """Translate normal Python source → brainrot syntax."""
    return _translate(source, _BRAINROT_PATTERN, BRAINROT_MAP)


def to_python(source: str) -> str:
    """Translate brainrot syntax → normal Python source."""
    return _translate(source, _PYTHON_PATTERN, PYTHON_MAP)


# ── File helpers ──────────────────────────────────────────────────────────────

def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def run(path: str) -> None:
    """Execute a .brainrot file."""
    source = _read(path)
    python_source = to_python(source)
    code = compile(python_source, path, "exec")
    ns = _brainrot_builtins()
    ns.update({"__name__": "__main__", "__file__": path})
    exec(code, ns)  # noqa: S102


def translate(path: str, output_path: str | None = None) -> str:
    """Translate a .brainrot file to Python."""
    source = _read(path)
    result = to_python(source)
    if output_path:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(result)
    return result


def show_keywords() -> None:
    """Print the full brainrot ↔ Python keyword mapping by category."""
    categories = {
        "control flow":          ["if","elif","else","for","while","break","continue","pass","match","case"],
        "functions & classes":   ["def","return","class","lambda"],
        "decorators":            ["@property","@staticmethod","@classmethod","@abstractmethod"],
        "dunder methods":        ["__init__","__str__","__repr__","__len__","__del__","__call__",
                                  "__iter__","__next__","__enter__","__exit__","__getitem__",
                                  "__setitem__","__delitem__","__contains__","__add__","__sub__",
                                  "__mul__","__truediv__","__floordiv__","__mod__","__pow__",
                                  "__eq__","__ne__","__lt__","__gt__","__le__","__ge__",
                                  "__bool__","__hash__","__getattr__","__setattr__","__delattr__",
                                  "__new__","__class__","__slots__","__all__","__doc__",
                                  "__name__","__file__","__module__","__debug__"],
        "logic":                 ["and","or","not","in","is","True","False","None","NotImplemented"],
        "imports":               ["import","from","as"],
        "exceptions (keywords)": ["try","except","finally","raise"],
        "exceptions (builtins)": ["Exception","ValueError","TypeError","KeyError","IndexError",
                                  "AttributeError","ImportError","RuntimeError","StopIteration",
                                  "NotImplementedError","PermissionError","FileNotFoundError",
                                  "OverflowError","ZeroDivisionError","RecursionError","OSError",
                                  "IOError","MemoryError","AssertionError","NameError","SyntaxError",
                                  "IndentationError","StopAsyncIteration","ArithmeticError","BaseException"],
        "context / generators":  ["with","yield","yield from"],
        "scope":                 ["global","nonlocal","del"],
        "type / misc keywords":  ["assert","async","await","type"],
        "builtin functions":     ["print","len","range","enumerate","zip","map","filter","sorted",
                                  "reversed","sum","min","max","abs","round","isinstance","hasattr",
                                  "getattr","setattr","delattr","input","open","super","vars","dir",
                                  "id","repr","callable","iter","next","any","all","hex","bin","oct",
                                  "ord","chr","pow","divmod","hash","format","eval","exec","compile",
                                  "globals","locals","breakpoint","exit","quit"],
        "builtin types":         ["str","int","float","bool","list","dict","set","tuple","bytes",
                                  "bytearray","complex","frozenset","memoryview","object"],
    }
    col = max(len(v) for v in BRAINROT_MAP.values())
    total = 0
    for cat, keys in categories.items():
        print(f"\n  {cat.upper()}")
        print("  " + "─" * (col + 14))
        for k in keys:
            if k in BRAINROT_MAP:
                print(f"  {BRAINROT_MAP[k]:<{col+2}}  →  {k}")
                total += 1
    print(f"\n  total: {total} keywords mapped\n")


# ── CLI ───────────────────────────────────────────────────────────────────────

def _cli() -> None:
    if len(sys.argv) < 2:
        print("Usage: python -m brainrot [run|show|keys] [file]")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "keys":
        show_keywords()
    elif cmd == "run":
        if len(sys.argv) < 3:
            print("Usage: python -m brainrot run <file.brainrot>")
            sys.exit(1)
        run(sys.argv[2])
    elif cmd == "show":
        if len(sys.argv) < 3:
            print("Usage: python -m brainrot show <file.brainrot>")
            sys.exit(1)
        print(translate(sys.argv[2]))
    else:
        print(f"Unknown command: {cmd}")
        sys.exit(1)


if __name__ == "__main__":
    _cli()


# ── Brainrot builtins namespace ───────────────────────────────────────────────
# Maps every brainrot builtin alias → the real Python builtin.
# Injected automatically when running .brainrot files via run().

def _brainrot_builtins() -> dict:
    import builtins
    mapping = {
        # functions
        "yap":                  print,
        "body_count":           len,
        "grind_range":          range,
        "ranked_grind":         enumerate,
        "link_up":              zip,
        "glow_up":              map,
        "npc_filter":           filter,
        "sigma_sort":           sorted,
        "plot_twist_list":      reversed,
        "total_aura":           sum,
        "most_L":               min,
        "most_W":               max,
        "no_cap_value":         abs,
        "lowkey_round":         round,
        "hits_different_check": isinstance,
        "has_rizz":             hasattr,
        "get_rizz":             getattr,
        "set_rizz":             setattr,
        "cancel_rizz":          delattr,
        "ask_the_chat":         input,
        "unlock":               open,
        "elder_sigma":          super,
        "character_sheet":      vars,
        "full_lore":            dir,
        "aura_id":              id,
        "mirror":               repr,
        "has_rizz_move":        callable,
        "start_grind":          iter,
        "next_grind":           next,
        "anyone_bussin":        any,
        "everyone_bussin":      all,
        "sigma_hex":            hex,
        "binary_grind":         bin,
        "octal_arc":            oct,
        "aura_number":          ord,
        "aura_char":            chr,
        "glow_up_by":           pow,
        "split_and_leftover":   divmod,
        "get_aura_score":       hash,
        "rizz_format":          format,
        "trust_me_bro_exec":    eval,
        "yolo_exec":            exec,
        "forge_sigma":          compile,
        "main_characters_dict": globals,
        "side_characters_dict": locals,
        "pause_the_grind":      breakpoint,
        "log_off":              exit,
        "ragequit":             quit,
        # types
        "yap_type":             str,
        "sigma_int":            int,
        "mid_float":            float,
        "W_or_L":               bool,
        "grind_list":           list,
        "lore_book":            dict,
        "no_duplicates":        set,
        "locked_in":            tuple,
        "raw_sigma":            bytes,
        "mutable_sigma":        bytearray,
        "imaginary_rizz":       complex,
        "perma_locked":         frozenset,
        "sigma_vision":         memoryview,
        "base_ohio":            object,
        # exceptions
        "Ratio":                Exception,
        "MidValue":             ValueError,
        "WrongVibes":           TypeError,
        "GhostedKey":           KeyError,
        "OutOfGrind":           IndexError,
        "NoRizzAttribute":      AttributeError,
        "FailedSummon":         ImportError,
        "MidRuntime":           RuntimeError,
        "GrindsetOver":         StopIteration,
        "TooLazyError":         NotImplementedError,
        "RatioedByOS":          PermissionError,
        "GhostedFile":          FileNotFoundError,
        "TooMuchRizz":          OverflowError,
        "DivideByL":            ZeroDivisionError,
        "InfiniteGrind":        RecursionError,
        "SkibidiOS":            OSError,
        "SkibidiIO":            IOError,
        "BrokeAhhError":        MemoryError,
        "NahtTrustingBro":      AssertionError,
        "WhoError":             NameError,
        "BrainrotError":        SyntaxError,
        "TabVsSpacesRatio":     IndentationError,
        "AsyncGrindsetOver":    StopAsyncIteration,
        "MathIsHard":           ArithmeticError,
        "BaseRatio":            BaseException,
        # constants
        "too_lazy":             NotImplemented,
    }
    # also include all real builtins so standard names still work
    ns = vars(builtins).copy()
    ns.update(mapping)
    return ns
