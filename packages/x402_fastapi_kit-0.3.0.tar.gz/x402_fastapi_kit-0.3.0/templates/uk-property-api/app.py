"""
UK Property Data API — powered by x402-fastapi-kit.

8 endpoints serving Land Registry, VOA, EPC, crime, flood risk,
planning, and council tax data. Paid via x402 on Base network.

Deploy:
    export X402_PAY_TO=0xYourMetaMaskAddress
    export REDIS_URL=redis://localhost:6379
    uvicorn app:app --reload
"""

from __future__ import annotations

import logging

from x402_fastapi_kit import (
    APIKeyManager,
    EventBus,
    EventType,
    PaymentApp,
    PaymentEvent,
    RateLimiter,
    ServiceManifest,
    require_payment,
)
from x402_fastapi_kit.cache import RedisCache
from x402_fastapi_kit.mcp import MCPWrapper

from routes.sold_prices import router as sold_prices_router
from routes.rental_yields import router as rental_yields_router
from routes.stamp_duty import router as stamp_duty_router
from routes.epc_ratings import router as epc_ratings_router
from routes.crime_stats import router as crime_stats_router
from routes.flood_risk import router as flood_risk_router
from routes.planning import router as planning_router
from routes.council_tax import router as council_tax_router

logging.basicConfig(level=logging.INFO)

# ── Shared services ───────────────────────────────────────────────

bus = EventBus()
cache = RedisCache()

api_keys = APIKeyManager()
# Add partner keys from environment or config
# api_keys.add_key("partner-name", "sk_live_xxx")

rate_limiter = RateLimiter(
    requests_per_minute=30,
    route_limits={
        "/api/v1/sold-prices": 20,
        "/api/v1/flood-risk": 10,
    },
)

manifest = ServiceManifest(
    name="UK Property Data API",
    description="Land Registry sold prices, rental yields, stamp duty "
    "calculator, EPC ratings, crime statistics, flood risk, "
    "planning applications, and council tax — all via x402",
    version="1.0.0",
    tags=[
        "property", "uk", "land-registry", "epc",
        "crime", "flood", "planning", "council-tax",
    ],
)


@bus.on(EventType.PAYMENT_VERIFIED)
async def log_payment(event: PaymentEvent):
    logging.info(
        "Payment: %s on %s (tx: %s)",
        event.price, event.route, event.tx_hash,
    )


# ── App ───────────────────────────────────────────────────────────

app = PaymentApp(
    title="UK Property Data API",
    description="8 property data endpoints paid via x402",
    version="1.0.0",
    event_bus=bus,
    api_key_manager=api_keys,
    rate_limiter=rate_limiter,
    manifest=manifest,
    analytics=True,
)

# Mount route modules
app.include_router(sold_prices_router, prefix="/api/v1")
app.include_router(rental_yields_router, prefix="/api/v1")
app.include_router(stamp_duty_router, prefix="/api/v1")
app.include_router(epc_ratings_router, prefix="/api/v1")
app.include_router(crime_stats_router, prefix="/api/v1")
app.include_router(flood_risk_router, prefix="/api/v1")
app.include_router(planning_router, prefix="/api/v1")
app.include_router(council_tax_router, prefix="/api/v1")

# Enrich OpenAPI + mount MCP
app.enrich_openapi_schema()
mcp = MCPWrapper(app, app.x402_settings, base_url="https://your-api.up.railway.app")
mcp.mount()


@app.get("/")
async def root():
    return {
        "service": "UK Property Data API",
        "version": "1.0.0",
        "endpoints": 8,
        "docs": "/docs",
        "health": "/x402/health",
        "dashboard": "/x402/dashboard",
        "manifest": "/.well-known/x402",
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
