"""epc ratings endpoint."""

from fastapi import APIRouter, Query
from x402_fastapi_kit import require_payment

router = APIRouter(tags=["property"])


@router.get("/epc-ratings")
@require_payment(price="$0.05", description="epc ratings data")
async def get_epc_ratings(
    postcode: str = Query(..., description="UK postcode (e.g. SW1A 1AA)"),
):
    """
    Returns epc ratings data for a UK postcode.

    TODO: Connect to your actual data source in services/.
    """
    return {
        "postcode": postcode.upper(),
        "data": "Replace with real epc ratings data",
        "source": "TODO",
    }
