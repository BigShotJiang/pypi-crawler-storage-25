"""council tax endpoint."""

from fastapi import APIRouter, Query
from x402_fastapi_kit import require_payment

router = APIRouter(tags=["property"])


@router.get("/council-tax")
@require_payment(price="$0.05", description="council tax data")
async def get_council_tax(
    postcode: str = Query(..., description="UK postcode (e.g. SW1A 1AA)"),
):
    """
    Returns council tax data for a UK postcode.

    TODO: Connect to your actual data source in services/.
    """
    return {
        "postcode": postcode.upper(),
        "data": "Replace with real council tax data",
        "source": "TODO",
    }
