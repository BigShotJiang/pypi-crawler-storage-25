"""Sold prices endpoint — Land Registry data."""

from fastapi import APIRouter, Query

from x402_fastapi_kit import require_payment

router = APIRouter(tags=["property"])


@router.get("/sold-prices")
@require_payment(price="$0.05", description="Land Registry sold price data")
async def get_sold_prices(
    postcode: str = Query(..., description="UK postcode (e.g. SW1A 1AA)"),
    limit: int = Query(10, ge=1, le=50, description="Max results"),
):
    """
    Returns sold property prices from HM Land Registry.

    Data includes: address, price paid, date, property type, tenure.
    Updated monthly from Land Registry Price Paid Data.
    """
    # TODO: Replace with your actual data source
    # e.g. await services.land_registry.get_sold_prices(postcode, limit)
    return {
        "postcode": postcode.upper(),
        "results": [
            {
                "address": "10 Downing Street, London",
                "price": 1_500_000,
                "date": "2024-03-15",
                "property_type": "terraced",
                "tenure": "freehold",
            }
        ],
        "count": 1,
        "source": "HM Land Registry",
    }
