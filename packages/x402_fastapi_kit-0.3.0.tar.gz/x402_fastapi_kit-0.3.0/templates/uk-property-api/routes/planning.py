"""planning endpoint."""

from fastapi import APIRouter, Query
from x402_fastapi_kit import require_payment

router = APIRouter(tags=["property"])


@router.get("/planning")
@require_payment(price="$0.05", description="planning data")
async def get_planning(
    postcode: str = Query(..., description="UK postcode (e.g. SW1A 1AA)"),
):
    """
    Returns planning data for a UK postcode.

    TODO: Connect to your actual data source in services/.
    """
    return {
        "postcode": postcode.upper(),
        "data": "Replace with real planning data",
        "source": "TODO",
    }
