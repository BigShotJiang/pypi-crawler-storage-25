"""flood risk endpoint."""

from fastapi import APIRouter, Query
from x402_fastapi_kit import require_payment

router = APIRouter(tags=["property"])


@router.get("/flood-risk")
@require_payment(price="$0.05", description="flood risk data")
async def get_flood_risk(
    postcode: str = Query(..., description="UK postcode (e.g. SW1A 1AA)"),
):
    """
    Returns flood risk data for a UK postcode.

    TODO: Connect to your actual data source in services/.
    """
    return {
        "postcode": postcode.upper(),
        "data": "Replace with real flood risk data",
        "source": "TODO",
    }
