"""stamp duty endpoint."""

from fastapi import APIRouter, Query
from x402_fastapi_kit import require_payment

router = APIRouter(tags=["property"])


@router.get("/stamp-duty")
@require_payment(price="$0.05", description="stamp duty data")
async def get_stamp_duty(
    postcode: str = Query(..., description="UK postcode (e.g. SW1A 1AA)"),
):
    """
    Returns stamp duty data for a UK postcode.

    TODO: Connect to your actual data source in services/.
    """
    return {
        "postcode": postcode.upper(),
        "data": "Replace with real stamp duty data",
        "source": "TODO",
    }
