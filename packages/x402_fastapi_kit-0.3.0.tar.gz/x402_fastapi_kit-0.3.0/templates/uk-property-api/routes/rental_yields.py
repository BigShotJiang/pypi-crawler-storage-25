"""rental yields endpoint."""

from fastapi import APIRouter, Query
from x402_fastapi_kit import require_payment

router = APIRouter(tags=["property"])


@router.get("/rental-yields")
@require_payment(price="$0.05", description="rental yields data")
async def get_rental_yields(
    postcode: str = Query(..., description="UK postcode (e.g. SW1A 1AA)"),
):
    """
    Returns rental yields data for a UK postcode.

    TODO: Connect to your actual data source in services/.
    """
    return {
        "postcode": postcode.upper(),
        "data": "Replace with real rental yields data",
        "source": "TODO",
    }
