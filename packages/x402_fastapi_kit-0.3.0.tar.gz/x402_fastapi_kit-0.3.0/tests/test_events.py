"""Tests for x402_fastapi_kit.events."""

import pytest

from x402_fastapi_kit.events import EventBus, EventType, PaymentEvent


class TestPaymentEvent:
    def test_defaults(self):
        e = PaymentEvent(
            event_type=EventType.PAYMENT_VERIFIED,
            route="/data",
            method="GET",
        )
        assert e.event_type == EventType.PAYMENT_VERIFIED
        assert e.timestamp > 0
        assert e.extra == {}

    def test_full_event(self):
        e = PaymentEvent(
            event_type=EventType.PAYMENT_VERIFIED,
            route="/data",
            method="GET",
            client_id="0xABC",
            price="$0.05",
            tx_hash="0x123",
            verification={"valid": True},
        )
        assert e.tx_hash == "0x123"
        assert e.price == "$0.05"


class TestEventBus:
    @pytest.mark.anyio
    async def test_subscribe_and_emit(self):
        bus = EventBus()
        received = []

        @bus.on("payment.verified")
        async def handler(event: PaymentEvent):
            received.append(event)

        event = PaymentEvent(
            event_type=EventType.PAYMENT_VERIFIED,
            route="/test",
            method="GET",
        )
        await bus.emit(event)
        assert len(received) == 1
        assert received[0].route == "/test"

    @pytest.mark.anyio
    async def test_sync_handler(self):
        bus = EventBus()
        received = []

        @bus.on("request.gated")
        def sync_handler(event: PaymentEvent):
            received.append(event.route)

        await bus.emit(PaymentEvent(
            event_type=EventType.REQUEST_GATED,
            route="/sync",
            method="GET",
        ))
        assert received == ["/sync"]

    @pytest.mark.anyio
    async def test_wildcard_handler(self):
        bus = EventBus()
        received = []

        bus.on_all(lambda e: received.append(e.event_type))

        await bus.emit(PaymentEvent(
            event_type=EventType.PAYMENT_VERIFIED,
            route="/a", method="GET",
        ))
        await bus.emit(PaymentEvent(
            event_type=EventType.REQUEST_GATED,
            route="/b", method="GET",
        ))
        assert len(received) == 2

    @pytest.mark.anyio
    async def test_handler_error_doesnt_propagate(self):
        bus = EventBus()

        @bus.on("payment.verified")
        async def bad_handler(event: PaymentEvent):
            raise RuntimeError("boom")

        # Should not raise
        await bus.emit(PaymentEvent(
            event_type=EventType.PAYMENT_VERIFIED,
            route="/test", method="GET",
        ))

    @pytest.mark.anyio
    async def test_unsubscribe(self):
        bus = EventBus()
        received = []

        async def handler(event: PaymentEvent):
            received.append(1)

        bus.subscribe("payment.verified", handler)
        assert bus.unsubscribe("payment.verified", handler)

        await bus.emit(PaymentEvent(
            event_type=EventType.PAYMENT_VERIFIED,
            route="/test", method="GET",
        ))
        assert len(received) == 0

    @pytest.mark.anyio
    async def test_no_handlers_is_fine(self):
        bus = EventBus()
        # Should not raise even with no handlers
        await bus.emit(PaymentEvent(
            event_type=EventType.RATE_LIMITED,
            route="/test", method="GET",
        ))

    def test_handler_count(self):
        bus = EventBus()
        bus.subscribe("a", lambda e: None)
        bus.subscribe("a", lambda e: None)
        bus.subscribe("b", lambda e: None)
        bus.on_all(lambda e: None)
        assert bus.handler_count == 4

    def test_clear(self):
        bus = EventBus()
        bus.subscribe("a", lambda e: None)
        bus.on_all(lambda e: None)
        bus.clear()
        assert bus.handler_count == 0

    @pytest.mark.anyio
    async def test_multiple_handlers_same_event(self):
        bus = EventBus()
        results = []

        @bus.on("payment.verified")
        async def h1(e: PaymentEvent):
            results.append("h1")

        @bus.on("payment.verified")
        async def h2(e: PaymentEvent):
            results.append("h2")

        await bus.emit(PaymentEvent(
            event_type=EventType.PAYMENT_VERIFIED,
            route="/test", method="GET",
        ))
        assert set(results) == {"h1", "h2"}
