"""Integration tests for the full Phase 2 middleware pipeline."""

from unittest.mock import AsyncMock, patch

import pytest
from httpx import ASGITransport, AsyncClient

from x402_fastapi_kit import (
    APIKeyManager,
    EventBus,
    EventType,
    PaymentApp,
    PaymentEvent,
    RateLimiter,
    WalletAllowlist,
    require_payment,
)
from x402_fastapi_kit.config import X402Settings
from x402_fastapi_kit.middleware.payment import _registry

# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def settings(monkeypatch):
    monkeypatch.setenv("X402_PAY_TO", "0x1234567890abcdef1234567890abcdef12345678")
    monkeypatch.setenv("X402_NETWORK", "eip155:84532")
    monkeypatch.setenv("X402_RATE_LIMIT_ENABLED", "false")  # disable by default for tests
    return X402Settings()


@pytest.fixture
def event_bus():
    return EventBus()


@pytest.fixture
def api_keys():
    mgr = APIKeyManager()
    mgr.add_key("test-partner", "sk_test_secret123")
    mgr.add_key("internal-agent", "sk_agent_xyz")
    return mgr


@pytest.fixture
def allowlist():
    al = WalletAllowlist()
    al.add("0xAAAABBBBCCCCDDDDEEEEFFFF00001111AAAA2222", label="free-partner")
    return al


@pytest.fixture
def app(settings, event_bus, api_keys, allowlist):
    _registry._routes.clear()

    payment_app = PaymentApp(
        settings=settings,
        event_bus=event_bus,
        api_key_manager=api_keys,
        wallet_allowlist=allowlist,
        title="Phase 2 Test API",
    )

    @payment_app.get("/free")
    async def free_endpoint():
        return {"free": True}

    @payment_app.get("/paid")
    @require_payment(price="$0.05", description="Test paid endpoint")
    async def paid_endpoint():
        return {"data": "premium"}

    return payment_app


@pytest.fixture
async def client(app):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ── API Key Bypass ────────────────────────────────────────────────────────────

class TestAPIKeyBypass:
    @pytest.mark.anyio
    async def test_valid_api_key_bypasses_payment(self, client):
        resp = await client.get(
            "/paid",
            headers={"X-API-Key": "sk_test_secret123"},
        )
        assert resp.status_code == 200
        assert resp.json()["data"] == "premium"

    @pytest.mark.anyio
    async def test_invalid_api_key_falls_through_to_402(self, client):
        resp = await client.get(
            "/paid",
            headers={"X-API-Key": "sk_INVALID"},
        )
        assert resp.status_code == 402

    @pytest.mark.anyio
    async def test_api_key_emits_event(self, client, event_bus):
        received = []

        @event_bus.on(EventType.AUTH_API_KEY)
        async def handler(event: PaymentEvent):
            received.append(event)

        await client.get("/paid", headers={"X-API-Key": "sk_test_secret123"})
        assert len(received) == 1
        assert received[0].client_id == "test-partner"
        assert received[0].route == "/paid"

    @pytest.mark.anyio
    async def test_free_routes_unaffected_by_api_key(self, client):
        resp = await client.get("/free", headers={"X-API-Key": "sk_test_secret123"})
        assert resp.status_code == 200  # free route, no middleware interference


# ── Wallet Allowlist Bypass ───────────────────────────────────────────────────

class TestWalletAllowlistBypass:
    @pytest.mark.anyio
    async def test_allowlisted_wallet_bypasses_payment(self, client):
        resp = await client.get(
            "/paid",
            headers={"X-WALLET": "0xAAAABBBBCCCCDDDDEEEEFFFF00001111AAAA2222"},
        )
        assert resp.status_code == 200
        assert resp.json()["data"] == "premium"

    @pytest.mark.anyio
    async def test_non_allowlisted_wallet_falls_through(self, client):
        resp = await client.get(
            "/paid",
            headers={"X-WALLET": "0xNOTINLIST0000000000000000000000000000000"},
        )
        assert resp.status_code == 402

    @pytest.mark.anyio
    async def test_allowlist_emits_event(self, client, event_bus):
        received = []

        @event_bus.on(EventType.AUTH_ALLOWLIST)
        async def handler(event: PaymentEvent):
            received.append(event)

        await client.get(
            "/paid",
            headers={"X-WALLET": "0xAAAABBBBCCCCDDDDEEEEFFFF00001111AAAA2222"},
        )
        assert len(received) == 1
        assert received[0].client_id == "free-partner"

    @pytest.mark.anyio
    async def test_evm_case_insensitive(self, client):
        # Lowercase version of the allowlisted address
        resp = await client.get(
            "/paid",
            headers={"X-WALLET": "0xaaaabbbbccccddddeeeeffff00001111aaaa2222"},
        )
        assert resp.status_code == 200


# ── Rate Limiting ─────────────────────────────────────────────────────────────

class TestRateLimiting:
    @pytest.fixture
    def rate_limited_app(self, settings, event_bus, api_keys, allowlist):
        _registry._routes.clear()

        limiter = RateLimiter(requests_per_minute=3)

        payment_app = PaymentApp(
            settings=settings,
            event_bus=event_bus,
            api_key_manager=api_keys,
            wallet_allowlist=allowlist,
            rate_limiter=limiter,
            title="Rate Limited API",
        )

        @payment_app.get("/paid")
        @require_payment(price="$0.01")
        async def paid():
            return {"ok": True}

        return payment_app

    @pytest.fixture
    async def rl_client(self, rate_limited_app):
        transport = ASGITransport(app=rate_limited_app)
        async with AsyncClient(transport=transport, base_url="http://test") as c:
            yield c

    @pytest.mark.anyio
    async def test_rate_limit_returns_429(self, rl_client):
        # First 3 requests get 402 (no payment, but counted)
        for _ in range(3):
            resp = await rl_client.get("/paid")
            assert resp.status_code == 402

        # 4th request should be rate limited
        resp = await rl_client.get("/paid")
        assert resp.status_code == 429
        assert "Retry-After" in resp.headers

    @pytest.mark.anyio
    async def test_rate_limit_headers(self, rl_client):
        resp = await rl_client.get("/paid")
        assert "X-RateLimit-Limit" not in resp.headers  # 402 doesn't add RL headers

    @pytest.mark.anyio
    async def test_rate_limit_emits_event(self, rl_client, event_bus):
        received = []

        @event_bus.on(EventType.RATE_LIMITED)
        async def handler(event: PaymentEvent):
            received.append(event)

        for _ in range(4):
            await rl_client.get("/paid")

        assert len(received) == 1  # only the 4th request was rate limited

    @pytest.mark.anyio
    async def test_api_key_bypasses_rate_limit(self, rl_client):
        """API key auth happens BEFORE rate limit check."""
        # Exhaust rate limit
        for _ in range(4):
            await rl_client.get("/paid")

        # API key should still work (step 2 runs before step 3)
        resp = await rl_client.get(
            "/paid",
            headers={"X-API-Key": "sk_test_secret123"},
        )
        assert resp.status_code == 200


# ── Event Hooks in Payment Flow ───────────────────────────────────────────────

class TestPaymentEvents:
    @pytest.mark.anyio
    async def test_gated_event_on_402(self, client, event_bus):
        received = []

        @event_bus.on(EventType.REQUEST_GATED)
        async def handler(event: PaymentEvent):
            received.append(event)

        await client.get("/paid")
        assert len(received) == 1
        assert received[0].price == "$0.05"

    @pytest.mark.anyio
    async def test_verified_event_on_payment(self, client, event_bus):
        received = []

        @event_bus.on(EventType.PAYMENT_VERIFIED)
        async def handler(event: PaymentEvent):
            received.append(event)

        mock_verification = {"valid": True, "transaction": "0xabc123"}

        with patch(
            "x402_fastapi_kit.middleware.payment._verify_payment",
            new_callable=AsyncMock,
            return_value=mock_verification,
        ):
            await client.get("/paid", headers={"X-PAYMENT": "signed-payload"})

        assert len(received) == 1
        assert received[0].tx_hash == "0xabc123"

    @pytest.mark.anyio
    async def test_rejected_event_on_invalid_payment(self, client, event_bus):
        received = []

        @event_bus.on(EventType.PAYMENT_REJECTED)
        async def handler(event: PaymentEvent):
            received.append(event)

        with patch(
            "x402_fastapi_kit.middleware.payment._verify_payment",
            new_callable=AsyncMock,
            return_value={"valid": False, "reason": "expired"},
        ):
            await client.get("/paid", headers={"X-PAYMENT": "bad-payload"})

        assert len(received) == 1
        assert received[0].reason == "Invalid payment"

    @pytest.mark.anyio
    async def test_facilitator_error_event(self, client, event_bus):
        received = []

        @event_bus.on(EventType.FACILITATOR_ERROR)
        async def handler(event: PaymentEvent):
            received.append(event)

        with patch(
            "x402_fastapi_kit.middleware.payment._verify_payment",
            new_callable=AsyncMock,
            side_effect=ConnectionError("down"),
        ):
            await client.get("/paid", headers={"X-PAYMENT": "payload"})

        assert len(received) == 1
        assert "down" in received[0].reason

    @pytest.mark.anyio
    async def test_wildcard_handler_sees_all(self, client, event_bus):
        all_events = []
        event_bus.on_all(lambda e: all_events.append(e.event_type))

        # 402 → request.gated
        await client.get("/paid")
        # API key → auth.api_key
        await client.get("/paid", headers={"X-API-Key": "sk_test_secret123"})

        assert EventType.REQUEST_GATED in all_events
        assert EventType.AUTH_API_KEY in all_events


# ── Health Endpoint Phase 2 Fields ────────────────────────────────────────────

class TestHealthPhase2:
    @pytest.mark.anyio
    async def test_health_includes_phase2_fields(self, client):
        resp = await client.get("/x402/health")
        body = resp.json()
        assert "rate_limit_enabled" in body
        assert "api_keys_enabled" in body
        assert "allowlist_enabled" in body
