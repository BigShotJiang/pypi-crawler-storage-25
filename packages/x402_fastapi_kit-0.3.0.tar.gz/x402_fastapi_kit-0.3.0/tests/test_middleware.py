"""Tests for the payment middleware and decorator."""

import base64
import json
from unittest.mock import AsyncMock, patch

import pytest
from httpx import ASGITransport, AsyncClient

from x402_fastapi_kit import PaymentApp, require_payment
from x402_fastapi_kit.config import X402Settings
from x402_fastapi_kit.middleware.types import RoutePrice, RouteRegistry

# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def settings(monkeypatch):
    monkeypatch.setenv("X402_PAY_TO", "0x1234567890abcdef1234567890abcdef12345678")
    monkeypatch.setenv("X402_NETWORK", "eip155:84532")
    monkeypatch.setenv("X402_DEBUG", "true")
    return X402Settings()


@pytest.fixture
def app(settings):
    """Create a test PaymentApp with sample routes."""
    from x402_fastapi_kit.middleware.payment import _registry
    _registry._routes.clear()  # reset between tests

    payment_app = PaymentApp(settings=settings, title="Test API")

    @payment_app.get("/free")
    async def free_endpoint():
        return {"free": True}

    @payment_app.get("/paid")
    @require_payment(price="$0.05", description="Test paid endpoint")
    async def paid_endpoint():
        return {"data": "premium"}

    @payment_app.get("/cheap")
    @require_payment(price="$0.001")
    async def cheap_endpoint():
        return {"data": "micro"}

    @payment_app.post("/submit")
    @require_payment(price="$0.10", description="Submit data")
    async def submit_endpoint():
        return {"submitted": True}

    return payment_app


@pytest.fixture
async def client(app):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ── Route Registration ────────────────────────────────────────────────────────

class TestRouteRegistry:
    def test_register_and_get(self):
        reg = RouteRegistry()
        rp = RoutePrice(price="$0.01")
        reg.register("GET", "/data", rp)
        assert reg.get("GET", "/data") is rp
        assert reg.get("POST", "/data") is None
        assert len(reg) == 1

    def test_all_routes(self):
        reg = RouteRegistry()
        reg.register("GET", "/a", RoutePrice(price="$0.01"))
        reg.register("POST", "/b", RoutePrice(price="$0.02"))
        assert len(reg.all()) == 2


class TestRoutePrice:
    def test_to_accepts_defaults(self):
        rp = RoutePrice(price="$0.05")
        accepts = rp.to_accepts(
            default_network="eip155:84532",
            default_scheme="exact",
            default_pay_to="0xABC",
            default_timeout=300,
            default_description="Default desc",
        )
        assert accepts["price"] == "$0.05"
        assert accepts["network"] == "eip155:84532"
        assert accepts["scheme"] == "exact"
        assert accepts["pay_to"] == "0xABC"

    def test_to_accepts_overrides(self):
        rp = RoutePrice(
            price="$1.00",
            network="eip155:8453",
            scheme="upto",
            pay_to="0xCustom",
            description="My endpoint",
        )
        accepts = rp.to_accepts(
            default_network="eip155:84532",
            default_scheme="exact",
            default_pay_to="0xDefault",
            default_timeout=300,
            default_description="Default",
        )
        assert accepts["network"] == "eip155:8453"
        assert accepts["scheme"] == "upto"
        assert accepts["pay_to"] == "0xCustom"
        assert accepts["description"] == "My endpoint"


# ── 402 Responses ─────────────────────────────────────────────────────────────

class TestPaymentGate402:
    """Requests without payment headers should return 402."""

    @pytest.mark.anyio
    async def test_free_endpoint_passes(self, client):
        resp = await client.get("/free")
        assert resp.status_code == 200
        assert resp.json() == {"free": True}

    @pytest.mark.anyio
    async def test_paid_endpoint_returns_402(self, client):
        resp = await client.get("/paid")
        assert resp.status_code == 402

        body = resp.json()
        assert body["x402Version"] == 2
        assert body["error"] == "Payment required"
        assert len(body["accepts"]) >= 1
        assert body["accepts"][0]["price"] == "$0.05"
        assert body["accepts"][0]["scheme"] == "exact"

    @pytest.mark.anyio
    async def test_402_includes_payment_required_header(self, client):
        resp = await client.get("/paid")
        assert resp.status_code == 402

        header = resp.headers.get("payment-required")
        assert header is not None

        decoded = json.loads(base64.b64decode(header))
        assert decoded["x402Version"] == 2

    @pytest.mark.anyio
    async def test_post_route_returns_402(self, client):
        resp = await client.post("/submit")
        assert resp.status_code == 402
        assert resp.json()["accepts"][0]["price"] == "$0.10"

    @pytest.mark.anyio
    async def test_cheap_endpoint_402(self, client):
        resp = await client.get("/cheap")
        assert resp.status_code == 402
        assert resp.json()["accepts"][0]["price"] == "$0.001"


# ── Payment Verification ─────────────────────────────────────────────────────

class TestPaymentVerification:
    """Requests with valid payment headers should pass through."""

    @pytest.mark.anyio
    async def test_valid_payment_passes(self, client):
        mock_verification = {
            "valid": True,
            "transaction": "0xabc123",
        }

        with patch(
            "x402_fastapi_kit.middleware.payment._verify_payment",
            new_callable=AsyncMock,
            return_value=mock_verification,
        ):
            resp = await client.get(
                "/paid",
                headers={"X-PAYMENT": "signed-payment-payload-here"},
            )
            assert resp.status_code == 200
            assert resp.json()["data"] == "premium"

    @pytest.mark.anyio
    async def test_invalid_payment_returns_402(self, client):
        mock_verification = {"valid": False, "reason": "expired"}

        with patch(
            "x402_fastapi_kit.middleware.payment._verify_payment",
            new_callable=AsyncMock,
            return_value=mock_verification,
        ):
            resp = await client.get(
                "/paid",
                headers={"X-PAYMENT": "bad-payload"},
            )
            assert resp.status_code == 402
            assert "Invalid payment" in resp.json()["error"]

    @pytest.mark.anyio
    async def test_facilitator_error_returns_502(self, client):
        with patch(
            "x402_fastapi_kit.middleware.payment._verify_payment",
            new_callable=AsyncMock,
            side_effect=ConnectionError("facilitator down"),
        ):
            resp = await client.get(
                "/paid",
                headers={"X-PAYMENT": "some-payload"},
            )
            assert resp.status_code == 502


# ── Introspection Endpoints ───────────────────────────────────────────────────

class TestIntrospection:
    @pytest.mark.anyio
    async def test_health_endpoint(self, client):
        resp = await client.get("/x402/health")
        assert resp.status_code == 200
        body = resp.json()
        assert body["status"] == "ok"
        assert body["network"] == "eip155:84532"
        assert body["is_testnet"] is True
        assert body["gated_routes"] >= 3

    @pytest.mark.anyio
    async def test_routes_endpoint(self, client):
        resp = await client.get("/x402/routes")
        assert resp.status_code == 200
        routes = resp.json()["routes"]
        assert "GET /paid" in routes
        assert routes["GET /paid"]["price"] == "$0.05"
