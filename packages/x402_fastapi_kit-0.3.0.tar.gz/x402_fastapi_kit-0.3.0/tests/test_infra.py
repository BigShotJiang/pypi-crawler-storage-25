"""Tests for Phase 3 additions: cache, MCP wrapper, Redis backend."""

import json
from unittest.mock import AsyncMock, MagicMock

import pytest
from httpx import ASGITransport, AsyncClient

from x402_fastapi_kit import (
    EventBus,
    MCPWrapper,
    PaymentApp,
    ServiceManifest,
    require_payment,
)
from x402_fastapi_kit.cache import CacheStats, RedisCache
from x402_fastapi_kit.config import X402Settings
from x402_fastapi_kit.middleware.payment import _registry
from x402_fastapi_kit.middleware.redis_backend import RedisBackend

# ── Fixtures ──────────────────────────────────────────────────────

@pytest.fixture
def settings(monkeypatch):
    monkeypatch.setenv("X402_PAY_TO", "0x1234567890abcdef1234567890abcdef12345678")
    monkeypatch.setenv("X402_NETWORK", "eip155:84532")
    monkeypatch.setenv("X402_RATE_LIMIT_ENABLED", "false")
    return X402Settings()


@pytest.fixture
def app_with_routes(settings):
    _registry._routes.clear()
    bus = EventBus()
    manifest = ServiceManifest(name="Test API", tags=["test"])

    test_app = PaymentApp(
        settings=settings,
        event_bus=bus,
        manifest=manifest,
        analytics=True,
        title="MCP Test",
    )

    @test_app.get("/free-data")
    async def free_data():
        return {"free": True}

    @test_app.get("/paid-data")
    @require_payment(price="$0.05", description="Premium data")
    async def paid_data():
        return {"data": "premium"}

    @test_app.post("/submit")
    @require_payment(price="$0.10", description="Submit something")
    async def submit():
        return {"ok": True}

    return test_app


@pytest.fixture
async def client(app_with_routes):
    transport = ASGITransport(app=app_with_routes)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ══════════════════════════════════════════════════════════════════
# CACHE TESTS
# ══════════════════════════════════════════════════════════════════

class TestCacheStats:
    def test_hit_rate_zero(self):
        stats = CacheStats()
        assert stats.hit_rate == 0.0

    def test_hit_rate_calculated(self):
        stats = CacheStats(hits=3, misses=7)
        assert stats.hit_rate == 0.3

    def test_to_dict(self):
        stats = CacheStats(hits=10, misses=5, errors=1, sets=8)
        d = stats.to_dict()
        assert d["hits"] == 10
        assert d["hit_rate"] == 0.667


class TestRedisCacheWithoutRedis:
    """Test cache behavior when Redis is unavailable."""

    @pytest.mark.anyio
    async def test_get_returns_none_without_redis(self):
        cache = RedisCache(url="redis://nonexistent:6379")
        result = await cache.get("test_key")
        assert result is None
        assert cache.stats.misses == 1

    @pytest.mark.anyio
    async def test_set_returns_false_without_redis(self):
        cache = RedisCache(url="redis://nonexistent:6379")
        result = await cache.set("key", {"data": 1})
        assert result is False

    @pytest.mark.anyio
    async def test_delete_returns_false_without_redis(self):
        cache = RedisCache(url="redis://nonexistent:6379")
        result = await cache.delete("key")
        assert result is False

    @pytest.mark.anyio
    async def test_clear_prefix_returns_zero_without_redis(self):
        cache = RedisCache(url="redis://nonexistent:6379")
        result = await cache.clear_prefix("test:")
        assert result == 0

    def test_is_available_initially_true(self):
        cache = RedisCache()
        assert cache._available is True

    def test_make_key(self):
        cache = RedisCache(key_prefix="myapp:")
        assert cache._make_key("users:1") == "myapp:users:1"

    def test_default_ttl(self):
        cache = RedisCache(default_ttl=7200)
        assert cache.default_ttl == 7200


class TestRedisCacheWithMockedRedis:
    """Test cache behavior with a mocked Redis connection."""

    @pytest.mark.anyio
    async def test_get_hit(self):
        cache = RedisCache()
        mock_redis = AsyncMock()
        mock_redis.get = AsyncMock(
            return_value=json.dumps({"result": 42})
        )
        cache._redis = mock_redis
        cache._available = True

        result = await cache.get("test_key")
        assert result == {"result": 42}
        assert cache.stats.hits == 1

    @pytest.mark.anyio
    async def test_get_miss(self):
        cache = RedisCache()
        mock_redis = AsyncMock()
        mock_redis.get = AsyncMock(return_value=None)
        cache._redis = mock_redis
        cache._available = True

        result = await cache.get("test_key")
        assert result is None
        assert cache.stats.misses == 1

    @pytest.mark.anyio
    async def test_set_success(self):
        cache = RedisCache()
        mock_redis = AsyncMock()
        mock_redis.setex = AsyncMock()
        cache._redis = mock_redis
        cache._available = True

        result = await cache.set("key", {"data": "value"}, ttl=60)
        assert result is True
        assert cache.stats.sets == 1
        mock_redis.setex.assert_called_once()

    @pytest.mark.anyio
    async def test_get_error_returns_none(self):
        cache = RedisCache()
        mock_redis = AsyncMock()
        mock_redis.get = AsyncMock(side_effect=Exception("redis error"))
        cache._redis = mock_redis
        cache._available = True

        result = await cache.get("key")
        assert result is None
        assert cache.stats.errors == 1

    @pytest.mark.anyio
    async def test_cached_decorator(self):
        cache = RedisCache()
        mock_redis = AsyncMock()
        mock_redis.get = AsyncMock(return_value=None)
        mock_redis.setex = AsyncMock()
        cache._redis = mock_redis
        cache._available = True

        call_count = 0

        @cache.cached(prefix="test", ttl=60)
        async def my_func(x: int):
            nonlocal call_count
            call_count += 1
            return {"x": x}

        result = await my_func(42)
        assert result == {"x": 42}
        assert call_count == 1
        assert cache.stats.sets == 1

    @pytest.mark.anyio
    async def test_cached_decorator_returns_cached(self):
        cache = RedisCache()
        mock_redis = AsyncMock()
        mock_redis.get = AsyncMock(
            return_value=json.dumps({"cached": True})
        )
        cache._redis = mock_redis
        cache._available = True

        call_count = 0

        @cache.cached(prefix="test")
        async def my_func():
            nonlocal call_count
            call_count += 1
            return {"cached": False}

        result = await my_func()
        assert result == {"cached": True}
        assert call_count == 0  # function never called
        assert cache.stats.hits == 1

    @pytest.mark.anyio
    async def test_close(self):
        cache = RedisCache()
        mock_redis = AsyncMock()
        cache._redis = mock_redis
        await cache.close()
        mock_redis.close.assert_called_once()
        assert cache._redis is None


# ══════════════════════════════════════════════════════════════════
# REDIS RATE LIMIT BACKEND TESTS
# ══════════════════════════════════════════════════════════════════

class TestRedisBackendWithoutRedis:
    @pytest.mark.anyio
    async def test_record_returns_zero_without_redis(self):
        backend = RedisBackend(url="redis://nonexistent:6379")
        count = await backend.record_and_count("key", 60.0, 100.0)
        assert count == 0  # fail open

    @pytest.mark.anyio
    async def test_get_count_returns_zero_without_redis(self):
        backend = RedisBackend(url="redis://nonexistent:6379")
        count = await backend.get_count("key", 60.0, 100.0)
        assert count == 0

    def test_make_key(self):
        backend = RedisBackend(key_prefix="rl:")
        assert backend._make_key("client:1") == "rl:client:1"


class TestRedisBackendWithMock:
    @pytest.mark.anyio
    async def test_record_and_count(self):
        backend = RedisBackend()
        mock_redis = AsyncMock()
        mock_pipe = AsyncMock()
        mock_pipe.execute = AsyncMock(return_value=[0, True, 5, True])
        mock_redis.pipeline = MagicMock(return_value=mock_pipe)
        backend._redis = mock_redis

        count = await backend.record_and_count("key", 60.0, 100.0)
        assert count == 5

    @pytest.mark.anyio
    async def test_get_count(self):
        backend = RedisBackend()
        mock_redis = AsyncMock()
        mock_pipe = AsyncMock()
        mock_pipe.execute = AsyncMock(return_value=[0, 3])
        mock_redis.pipeline = MagicMock(return_value=mock_pipe)
        backend._redis = mock_redis

        count = await backend.get_count("key", 60.0, 100.0)
        assert count == 3

    @pytest.mark.anyio
    async def test_close(self):
        backend = RedisBackend()
        mock_redis = AsyncMock()
        backend._redis = mock_redis
        await backend.close()
        mock_redis.close.assert_called_once()


# ══════════════════════════════════════════════════════════════════
# MCP WRAPPER TESTS
# ══════════════════════════════════════════════════════════════════

class TestMCPWrapper:
    @pytest.mark.anyio
    async def test_mcp_config_endpoint(self, client):
        # Trigger route discovery first
        await client.get("/paid-data")

        # Mount MCP
        wrapper = MCPWrapper(
            client._transport.app,  # type: ignore
            X402Settings(pay_to="0x1234567890abcdef1234567890abcdef12345678"),
            base_url="http://test",
        )
        wrapper.mount()

        resp = await client.get("/mcp/config")
        assert resp.status_code == 200
        config = resp.json()
        assert config["mcpVersion"] == "1.0"
        assert "tools" in config
        assert config["x-x402"]["protocol"] == "x402"

    @pytest.mark.anyio
    async def test_mcp_tools_endpoint(self, client):
        wrapper = MCPWrapper(
            client._transport.app,  # type: ignore
            X402Settings(pay_to="0x1234567890abcdef1234567890abcdef12345678"),
        )
        wrapper.mount()

        resp = await client.get("/mcp/tools")
        assert resp.status_code == 200
        body = resp.json()
        assert "tools" in body
        assert "count" in body

    def test_generate_config_structure(self, app_with_routes, settings):
        wrapper = MCPWrapper(app_with_routes, settings)
        config = wrapper.generate_config()

        assert config["mcpVersion"] == "1.0"
        assert config["server"]["name"] == "MCP Test"
        assert config["capabilities"]["tools"] is True
        assert isinstance(config["tools"], list)
        assert config["x-x402"]["payTo"] == settings.pay_to

    def test_tools_include_paid_endpoints(self, app_with_routes, settings):
        # Trigger route discovery
        _registry._routes.clear()
        from x402_fastapi_kit.middleware.payment import _discover_payment_routes
        _discover_payment_routes(app_with_routes, settings)

        wrapper = MCPWrapper(app_with_routes, settings)
        config = wrapper.generate_config()
        tools = config["tools"]

        # Find paid tools
        paid_tools = [t for t in tools if t.get("x-x402", {}).get("paid")]
        assert len(paid_tools) >= 2  # /paid-data and /submit

        # Check pricing is in description
        for tool in paid_tools:
            assert "x402:" in tool["description"]

    def test_write_config(self, app_with_routes, settings, tmp_path):
        wrapper = MCPWrapper(app_with_routes, settings)
        path = tmp_path / "mcp.json"
        wrapper.write_config(str(path))

        assert path.exists()
        with open(path) as f:
            config = json.load(f)
        assert config["mcpVersion"] == "1.0"

    def test_custom_server_name(self, app_with_routes, settings):
        wrapper = MCPWrapper(
            app_with_routes,
            settings,
            server_name="My Custom API",
            server_version="2.0.0",
            base_url="https://api.example.com",
        )
        config = wrapper.generate_config()
        assert config["server"]["name"] == "My Custom API"
        assert config["server"]["version"] == "2.0.0"
        assert config["x-x402"]["wellKnown"] == (
            "https://api.example.com/.well-known/x402"
        )
