"""x402-fastapi-kit test suite."""
