"""Tests for x402_fastapi_kit.config."""

import pytest
from pydantic import ValidationError

from x402_fastapi_kit.config import FACILITATORS, Network, X402Settings


class TestX402Settings:
    """Configuration loading and validation."""

    def test_minimal_config(self, monkeypatch):
        monkeypatch.setenv("X402_PAY_TO", "0x1234567890abcdef1234567890abcdef12345678")
        settings = X402Settings()
        assert settings.pay_to == "0x1234567890abcdef1234567890abcdef12345678"
        assert settings.network == Network.BASE_SEPOLIA.value
        assert settings.scheme == "exact"
        assert settings.default_price == "$0.01"

    def test_invalid_evm_address(self, monkeypatch):
        monkeypatch.setenv("X402_PAY_TO", "0xTOOSHORT")
        with pytest.raises(ValidationError):
            X402Settings()

    def test_is_testnet_base_sepolia(self, monkeypatch):
        monkeypatch.setenv("X402_PAY_TO", "0x1234567890abcdef1234567890abcdef12345678")
        monkeypatch.setenv("X402_NETWORK", "eip155:84532")
        settings = X402Settings()
        assert settings.is_testnet is True
        assert settings.is_evm is True
        assert settings.is_svm is False

    def test_is_mainnet_base(self, monkeypatch):
        monkeypatch.setenv("X402_PAY_TO", "0x1234567890abcdef1234567890abcdef12345678")
        monkeypatch.setenv("X402_NETWORK", "eip155:8453")
        settings = X402Settings()
        assert settings.is_testnet is False

    def test_solana_network(self, monkeypatch):
        monkeypatch.setenv("X402_PAY_TO", "7EcDhSYGxXyscszYEp35KHN8vvw3svAuLKTzXwCFLtV")
        monkeypatch.setenv("X402_NETWORK", "solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1")
        settings = X402Settings()
        assert settings.is_svm is True
        assert settings.is_testnet is True

    def test_custom_facilitator(self, monkeypatch):
        monkeypatch.setenv("X402_PAY_TO", "0x1234567890abcdef1234567890abcdef12345678")
        monkeypatch.setenv("X402_FACILITATOR_URL", "https://custom.facilitator.example/v1")
        settings = X402Settings()
        assert settings.facilitator_url == "https://custom.facilitator.example/v1"

    def test_all_overrides(self, monkeypatch):
        monkeypatch.setenv("X402_PAY_TO", "0x1234567890abcdef1234567890abcdef12345678")
        monkeypatch.setenv("X402_NETWORK", "eip155:137")
        monkeypatch.setenv("X402_DEFAULT_PRICE", "$0.50")
        monkeypatch.setenv("X402_MAX_TIMEOUT_SECONDS", "600")
        monkeypatch.setenv("X402_PORT", "9000")
        settings = X402Settings()
        assert settings.network == "eip155:137"
        assert settings.default_price == "$0.50"
        assert settings.max_timeout_seconds == 600
        assert settings.port == 9000


class TestNetwork:
    """Network enum values."""

    def test_known_networks(self):
        assert Network.BASE_SEPOLIA.value == "eip155:84532"
        assert Network.BASE_MAINNET.value == "eip155:8453"
        assert Network.SOLANA_DEVNET.value == "solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1"

    def test_facilitator_urls(self):
        assert "x402.org" in FACILITATORS["testnet"]
