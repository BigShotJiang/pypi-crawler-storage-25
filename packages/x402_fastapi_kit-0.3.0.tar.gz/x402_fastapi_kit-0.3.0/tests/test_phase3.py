"""Tests for Phase 3: discovery, client SDK, analytics."""

from decimal import Decimal
from unittest.mock import AsyncMock, patch

import pytest
from httpx import ASGITransport, AsyncClient

from x402_fastapi_kit import (
    AnalyticsCollector,
    DryRunSigner,
    EventBus,
    EventType,
    PaymentApp,
    PaymentEvent,
    PaymentPolicy,
    ServiceManifest,
    X402Client,
    require_payment,
)
from x402_fastapi_kit.config import X402Settings
from x402_fastapi_kit.middleware.payment import _registry

# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def settings(monkeypatch):
    monkeypatch.setenv("X402_PAY_TO", "0x1234567890abcdef1234567890abcdef12345678")
    monkeypatch.setenv("X402_NETWORK", "eip155:84532")
    monkeypatch.setenv("X402_RATE_LIMIT_ENABLED", "false")
    return X402Settings()


@pytest.fixture
def bus():
    return EventBus()


@pytest.fixture
def manifest():
    return ServiceManifest(
        name="Test Weather API",
        description="Weather data for agents",
        tags=["weather", "data"],
        homepage="https://example.com",
    )


@pytest.fixture
def app(settings, bus, manifest):
    _registry._routes.clear()

    payment_app = PaymentApp(
        settings=settings,
        event_bus=bus,
        manifest=manifest,
        analytics=True,
        title="Phase 3 Test",
    )

    @payment_app.get("/free")
    async def free():
        return {"free": True}

    @payment_app.get("/data")
    @require_payment(price="$0.05", description="Premium data")
    async def data():
        return {"data": "premium"}

    return payment_app


@pytest.fixture
async def client(app):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


# ══════════════════════════════════════════════════════════════════════════════
# DISCOVERY TESTS
# ══════════════════════════════════════════════════════════════════════════════

class TestWellKnownManifest:
    @pytest.mark.anyio
    async def test_well_known_exists(self, client):
        resp = await client.get("/.well-known/x402")
        assert resp.status_code == 200

    @pytest.mark.anyio
    async def test_manifest_structure(self, client):
        resp = await client.get("/.well-known/x402")
        body = resp.json()
        assert body["x402Version"] == 2
        assert body["service"]["name"] == "Test Weather API"
        assert body["service"]["tags"] == ["weather", "data"]
        assert body["payment"]["payTo"].startswith("0x")
        assert body["payment"]["network"] == "eip155:84532"

    @pytest.mark.anyio
    async def test_manifest_includes_endpoints(self, client):
        # Trigger route discovery first
        await client.get("/data")
        resp = await client.get("/.well-known/x402")
        endpoints = resp.json()["endpoints"]
        paths = [e["path"] for e in endpoints]
        assert "/data" in paths

    @pytest.mark.anyio
    async def test_manifest_without_manifest_arg(self, settings, bus):
        """App without manifest should not have .well-known."""
        _registry._routes.clear()
        app = PaymentApp(settings=settings, event_bus=bus, manifest=None)
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://t") as c:
            resp = await c.get("/.well-known/x402")
            assert resp.status_code == 404


class TestServiceManifest:
    def test_build(self, settings):
        m = ServiceManifest(name="Test", contact="hello@example.com")
        result = m.build(settings)
        assert result["service"]["name"] == "Test"
        assert result["service"]["contact"] == "hello@example.com"
        assert result["payment"]["scheme"] == "exact"


# ══════════════════════════════════════════════════════════════════════════════
# CLIENT SDK TESTS
# ══════════════════════════════════════════════════════════════════════════════

class TestDryRunSigner:
    @pytest.mark.anyio
    async def test_sign_returns_string(self):
        signer = DryRunSigner()
        payload = await signer.sign({"price": "$0.01", "network": "eip155:84532"})
        assert isinstance(payload, str)
        assert len(payload) > 10

    def test_address(self):
        signer = DryRunSigner()
        assert signer.address.startswith("0x")


class TestPaymentPolicy:
    def test_allows_under_limit(self):
        policy = PaymentPolicy(max_per_request=Decimal("1.00"))
        assert policy.check("$0.50")

    def test_rejects_over_request_limit(self):
        policy = PaymentPolicy(max_per_request=Decimal("0.10"))
        assert not policy.check("$0.50")

    def test_rejects_over_session_limit(self):
        policy = PaymentPolicy(
            max_per_request=Decimal("5.00"),
            max_per_session=Decimal("2.00"),
        )
        policy.record_spend("$1.50")
        assert not policy.check("$1.00")  # 1.50 + 1.00 > 2.00

    def test_select_requirement_cheapest(self):
        policy = PaymentPolicy()
        accepts = [
            {"price": "$0.10", "network": "eip155:84532", "scheme": "exact"},
            {"price": "$0.01", "network": "eip155:8453", "scheme": "exact"},
        ]
        selected = policy.select_requirement(accepts)
        assert selected is not None
        assert selected["price"] == "$0.01"

    def test_select_prefers_network(self):
        policy = PaymentPolicy(preferred_network="eip155:84532")
        accepts = [
            {"price": "$0.05", "network": "eip155:84532", "scheme": "exact"},
            {"price": "$0.01", "network": "eip155:8453", "scheme": "exact"},
        ]
        selected = policy.select_requirement(accepts)
        # Prefers network even if more expensive
        assert selected["network"] == "eip155:84532"

    def test_session_tracking(self):
        policy = PaymentPolicy()
        policy.record_spend("$0.50")
        policy.record_spend("$0.25")
        assert policy.session_spent == Decimal("0.75")


class TestX402Client:
    @pytest.mark.anyio
    async def test_free_endpoint_no_payment(self, app):
        """Non-gated route should pass through without payment."""
        X402Client(signer=DryRunSigner())
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as hc:
            # Use raw httpx for free endpoints
            resp = await hc.get("/free")
            assert resp.status_code == 200

    @pytest.mark.anyio
    async def test_handles_402_and_retries(self, app):
        """Client should parse 402 and retry with payment header."""
        x402_client = X402Client(signer=DryRunSigner())

        # Mock the full flow through our app
        mock_verify = {"valid": True, "transaction": "0xtx123"}

        with patch(
            "x402_fastapi_kit.middleware.payment._verify_payment",
            new_callable=AsyncMock,
            return_value=mock_verify,
        ):
            transport = ASGITransport(app=app)
            async with AsyncClient(
                transport=transport, base_url="http://test"
            ) as hc:
                # Manually do the X402Client flow against our test app
                resp = await hc.get("/data")
                assert resp.status_code == 402

                body = resp.json()
                accepts = body["accepts"]
                requirement = x402_client.policy.select_requirement(accepts)
                assert requirement is not None

                payload = await x402_client.signer.sign(requirement)
                resp2 = await hc.get(
                    "/data", headers={"X-PAYMENT": payload}
                )
                assert resp2.status_code == 200

    @pytest.mark.anyio
    async def test_discover_well_known(self, app):
        """Client discover() should fetch .well-known/x402."""
        X402Client()
        transport = ASGITransport(app=app)
        async with AsyncClient(
            transport=transport, base_url="http://test"
        ) as hc:
            resp = await hc.get("/.well-known/x402")
            if resp.status_code == 200:
                manifest = resp.json()
                assert manifest["x402Version"] == 2

    def test_receipts_empty_initially(self):
        c = X402Client()
        assert c.receipts == []
        assert c.total_spent == Decimal("0")


# ══════════════════════════════════════════════════════════════════════════════
# ANALYTICS TESTS
# ══════════════════════════════════════════════════════════════════════════════

class TestAnalyticsCollector:
    @pytest.mark.anyio
    async def test_stats_endpoint_exists(self, client):
        resp = await client.get("/x402/stats")
        assert resp.status_code == 200
        body = resp.json()
        assert "totals" in body
        assert "routes" in body
        assert "auth_breakdown" in body

    @pytest.mark.anyio
    async def test_dashboard_endpoint_exists(self, client):
        resp = await client.get("/x402/dashboard")
        assert resp.status_code == 200
        assert "x402" in resp.text.lower()

    @pytest.mark.anyio
    async def test_stats_count_gated_requests(self, client):
        # Make some requests to trigger events
        await client.get("/data")  # 402
        await client.get("/data")  # 402

        resp = await client.get("/x402/stats")
        stats = resp.json()
        assert stats["totals"]["requests"] >= 2

    @pytest.mark.anyio
    async def test_stats_count_payments(self, client):
        mock_verify = {"valid": True, "transaction": "0xpay1"}

        with patch(
            "x402_fastapi_kit.middleware.payment._verify_payment",
            new_callable=AsyncMock,
            return_value=mock_verify,
        ):
            await client.get("/data", headers={"X-PAYMENT": "payload"})

        resp = await client.get("/x402/stats")
        stats = resp.json()
        assert stats["totals"]["payments"] >= 1
        # Revenue should be $0.05
        assert "$0.05" in stats["totals"]["revenue"]

    @pytest.mark.anyio
    async def test_stats_route_breakdown(self, client):
        await client.get("/data")  # 402

        resp = await client.get("/x402/stats")
        routes = resp.json()["routes"]
        assert "/data" in routes

    def test_collector_snapshot_structure(self, bus):
        collector = AnalyticsCollector(bus)
        snap = collector.snapshot()
        assert "uptime_seconds" in snap
        assert "totals" in snap
        assert "hourly_revenue" in snap
        assert "recent_events" in snap

    @pytest.mark.anyio
    async def test_collector_tracks_events(self, bus):
        collector = AnalyticsCollector(bus)

        await bus.emit(PaymentEvent(
            event_type=EventType.PAYMENT_VERIFIED,
            route="/test",
            method="GET",
            price="$1.00",
            tx_hash="0xabc",
        ))

        snap = collector.snapshot()
        assert snap["totals"]["payments"] == 1
        assert snap["totals"]["revenue"] == "$1.00"
        assert snap["routes"]["/test"]["payments"] == 1

    @pytest.mark.anyio
    async def test_collector_tracks_rate_limits(self, bus):
        collector = AnalyticsCollector(bus)

        await bus.emit(PaymentEvent(
            event_type=EventType.RATE_LIMITED,
            route="/data",
            method="GET",
            client_id="1.2.3.4",
        ))

        snap = collector.snapshot()
        assert snap["totals"]["rate_limited"] == 1

    @pytest.mark.anyio
    async def test_recent_events_capped(self, bus):
        collector = AnalyticsCollector(bus)
        collector._max_recent = 5

        for i in range(10):
            await bus.emit(PaymentEvent(
                event_type=EventType.REQUEST_GATED,
                route=f"/r{i}",
                method="GET",
            ))

        collector.snapshot()
        assert len(collector._recent) == 5


# ══════════════════════════════════════════════════════════════════════════════
# HEALTH ENDPOINT PHASE 3
# ══════════════════════════════════════════════════════════════════════════════

class TestHealthPhase3:
    @pytest.mark.anyio
    async def test_health_includes_phase3_fields(self, client):
        resp = await client.get("/x402/health")
        body = resp.json()
        assert body["version"] == "0.3.0"
        assert "analytics_enabled" in body
        assert "manifest_enabled" in body
        assert body["analytics_enabled"] is True
        assert body["manifest_enabled"] is True
