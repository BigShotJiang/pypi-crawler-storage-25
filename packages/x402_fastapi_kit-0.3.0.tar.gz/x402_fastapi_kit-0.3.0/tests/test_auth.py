"""Tests for x402_fastapi_kit.auth."""

from x402_fastapi_kit.auth import APIKeyManager, AuthMethod, WalletAllowlist


class TestAPIKeyManager:
    def test_add_and_verify(self):
        mgr = APIKeyManager()
        mgr.add_key("partner", "sk_test_abc123")
        result = mgr.verify("sk_test_abc123")
        assert result.authenticated
        assert result.method == AuthMethod.API_KEY
        assert result.identity == "partner"

    def test_verify_invalid_key(self):
        mgr = APIKeyManager()
        mgr.add_key("partner", "sk_test_abc123")
        result = mgr.verify("sk_test_WRONG")
        assert not result.authenticated
        assert result.method == AuthMethod.NONE

    def test_add_keys_bulk(self):
        mgr = APIKeyManager()
        mgr.add_keys({"a": "key_a", "b": "key_b"})
        assert len(mgr) == 2
        assert mgr.verify("key_a").authenticated
        assert mgr.verify("key_b").authenticated

    def test_revoke_key(self):
        mgr = APIKeyManager()
        mgr.add_key("temp", "sk_temp")
        assert mgr.verify("sk_temp").authenticated
        assert mgr.revoke_key("temp")
        assert not mgr.verify("sk_temp").authenticated

    def test_revoke_nonexistent(self):
        mgr = APIKeyManager()
        assert not mgr.revoke_key("nope")

    def test_generate_key_format(self):
        key = APIKeyManager.generate_key()
        assert key.startswith("sk_x402_")
        assert len(key) > 20

    def test_list_names(self):
        mgr = APIKeyManager()
        mgr.add_keys({"alpha": "k1", "beta": "k2"})
        names = mgr.list_names()
        assert "alpha" in names
        assert "beta" in names


class TestWalletAllowlist:
    def test_add_and_check(self):
        al = WalletAllowlist()
        al.add("0xAbCdEf1234567890AbCdEf1234567890AbCdEf12", label="partner")
        result = al.check("0xabcdef1234567890abcdef1234567890abcdef12")  # lowercase
        assert result.authenticated
        assert result.method == AuthMethod.WALLET_ALLOWLIST
        assert result.identity == "partner"

    def test_check_not_listed(self):
        al = WalletAllowlist()
        result = al.check("0xNOTLISTED")
        assert not result.authenticated

    def test_evm_case_insensitive(self):
        al = WalletAllowlist()
        al.add("0xAAAABBBBCCCCDDDDEEEEFFFF0000111122223333")
        addr = "0xaaaabbbbccccddddeeee ffff0000111122223333".replace(" ", "")
        assert al.check(addr).authenticated

    def test_solana_case_sensitive(self):
        al = WalletAllowlist()
        al.add("7EcDhSYGxXyscszYEp35KHN8vvw3svAuLKTzXwCFLtV")
        assert al.check("7EcDhSYGxXyscszYEp35KHN8vvw3svAuLKTzXwCFLtV").authenticated
        # Solana is case-sensitive
        assert not al.check("7ecdhsygxxyscszYEp35KHN8vvw3svAuLKTzXwCFLtV").authenticated

    def test_add_many_list(self):
        al = WalletAllowlist()
        al.add_many(["0xAA" + "00" * 19, "0xBB" + "00" * 19])
        assert len(al) == 2

    def test_add_many_dict(self):
        al = WalletAllowlist()
        al.add_many({"0xAA" + "00" * 19: "Alice", "0xBB" + "00" * 19: "Bob"})
        assert len(al) == 2

    def test_remove(self):
        al = WalletAllowlist()
        al.add("0xAA" + "00" * 19)
        assert al.remove("0xAA" + "00" * 19)
        assert not al.check("0xAA" + "00" * 19).authenticated

    def test_contains(self):
        al = WalletAllowlist()
        al.add("0xAA" + "00" * 19)
        assert ("0xAA" + "00" * 19) in al

    def test_list_addresses(self):
        al = WalletAllowlist()
        al.add("0xAA" + "00" * 19, label="test")
        entries = al.list_addresses()
        assert len(entries) == 1
        assert entries[0]["label"] == "test"
