"""Tests for x402_fastapi_kit.middleware.rate_limit."""

import pytest

from x402_fastapi_kit.middleware.rate_limit import (
    InMemoryBackend,
    RateLimiter,
    RateLimitResult,
)


class TestRateLimitResult:
    def test_allowed_result_headers(self):
        r = RateLimitResult(allowed=True, limit=60, remaining=59, reset_at=1000.0)
        h = r.headers()
        assert h["X-RateLimit-Limit"] == "60"
        assert h["X-RateLimit-Remaining"] == "59"
        assert "Retry-After" not in h

    def test_denied_result_headers(self):
        r = RateLimitResult(
            allowed=False, limit=60, remaining=0, reset_at=1000.0, retry_after=30.0
        )
        h = r.headers()
        assert h["X-RateLimit-Remaining"] == "0"
        assert "Retry-After" in h


class TestInMemoryBackend:
    @pytest.mark.anyio
    async def test_record_and_count(self):
        backend = InMemoryBackend()
        count = await backend.record_and_count("k1", 60.0, 100.0)
        assert count == 1
        count = await backend.record_and_count("k1", 60.0, 101.0)
        assert count == 2

    @pytest.mark.anyio
    async def test_pruning(self):
        backend = InMemoryBackend()
        # Record at t=10
        await backend.record_and_count("k1", 60.0, 10.0)
        # At t=100, the t=10 entry is expired (100 - 60 = 40 cutoff)
        count = await backend.record_and_count("k1", 60.0, 100.0)
        assert count == 1  # old one pruned, new one added

    @pytest.mark.anyio
    async def test_get_count_without_recording(self):
        backend = InMemoryBackend()
        await backend.record_and_count("k1", 60.0, 100.0)
        count = await backend.get_count("k1", 60.0, 101.0)
        assert count == 1  # didn't increment

    def test_clear(self):
        backend = InMemoryBackend()
        backend._store["k1"] = [1.0, 2.0]
        backend.clear()
        assert len(backend._store) == 0


class TestRateLimiter:
    @pytest.mark.anyio
    async def test_allows_within_limit(self):
        limiter = RateLimiter(requests_per_minute=5)
        for _ in range(5):
            r = await limiter.check("client1")
            assert r.allowed

    @pytest.mark.anyio
    async def test_blocks_over_limit(self):
        limiter = RateLimiter(requests_per_minute=3)
        for _ in range(3):
            await limiter.check("client1")
        r = await limiter.check("client1")
        assert not r.allowed
        assert r.retry_after is not None

    @pytest.mark.anyio
    async def test_per_route_limits(self):
        limiter = RateLimiter(
            requests_per_minute=100,
            route_limits={"/expensive": 2},
        )
        await limiter.check("c1", route="/expensive")
        await limiter.check("c1", route="/expensive")
        r = await limiter.check("c1", route="/expensive")
        assert not r.allowed

        # Global limit for other routes still high
        r = await limiter.check("c1", route="/cheap")
        assert r.allowed

    @pytest.mark.anyio
    async def test_separate_clients(self):
        limiter = RateLimiter(requests_per_minute=2)
        await limiter.check("client1")
        await limiter.check("client1")
        r = await limiter.check("client1")
        assert not r.allowed

        # Different client should still be allowed
        r = await limiter.check("client2")
        assert r.allowed

    @pytest.mark.anyio
    async def test_peek_without_recording(self):
        limiter = RateLimiter(requests_per_minute=2)
        r = await limiter.check("c1", record=False)
        assert r.allowed
        assert r.remaining == 2  # nothing recorded
