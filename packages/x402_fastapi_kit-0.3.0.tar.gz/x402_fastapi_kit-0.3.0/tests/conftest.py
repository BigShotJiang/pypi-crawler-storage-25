"""Shared fixtures for the test suite."""

import os

import pytest


@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    """Ensure no stale X402_ env vars leak between tests."""
    for key in list(os.environ):
        if key.startswith("X402_"):
            monkeypatch.delenv(key, raising=False)
