"""Tests for x402_fastapi_kit.utils."""

from x402_fastapi_kit.utils import (
    format_price,
    is_evm_address,
    is_solana_address,
    mask_address,
    parse_price,
)


class TestParsePrice:
    def test_one_cent(self):
        assert parse_price("$0.01") == 10_000

    def test_one_dollar(self):
        assert parse_price("$1.00") == 1_000_000

    def test_no_dollar_sign(self):
        assert parse_price("0.001") == 1_000

    def test_sub_cent(self):
        assert parse_price("$0.0001") == 100

    def test_large(self):
        assert parse_price("$100") == 100_000_000


class TestFormatPrice:
    def test_one_cent(self):
        assert format_price(10_000) == "$0.01"

    def test_one_dollar(self):
        assert format_price(1_000_000) == "$1.00"


class TestAddressValidation:
    def test_valid_evm(self):
        assert is_evm_address("0x1234567890abcdef1234567890abcdef12345678") is True

    def test_invalid_evm_short(self):
        assert is_evm_address("0x1234") is False

    def test_valid_solana(self):
        assert is_solana_address("7EcDhSYGxXyscszYEp35KHN8vvw3svAuLKTzXwCFLtV") is True

    def test_invalid_solana(self):
        assert is_solana_address("0xNotSolana") is False


class TestMaskAddress:
    def test_evm(self):
        masked = mask_address("0x1234567890abcdef1234567890abcdef12345678")
        assert masked.startswith("0x1234")
        assert masked.endswith("5678")
        assert "…" in masked

    def test_short(self):
        assert mask_address("0x1234") == "0x1234"
