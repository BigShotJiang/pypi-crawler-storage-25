"""
Example x402-fastapi-kit service (v0.3.0 — all phases).

Demonstrates: payment gating, API key bypass, wallet allowlist,
rate limiting, event hooks, service discovery, and analytics.

Run::

    export X402_PAY_TO=0xYourWalletAddress
    export X402_DEBUG=true
    uvicorn examples.app:app --reload

Then visit:
    http://localhost:8000/           — landing page
    http://localhost:8000/docs       — OpenAPI docs (with x402 metadata)
    http://localhost:8000/x402/dashboard — live analytics
    http://localhost:8000/.well-known/x402 — service manifest
"""

from __future__ import annotations

import logging
import random
from datetime import datetime, timezone

from fastapi import Request
from fastapi.responses import HTMLResponse

from x402_fastapi_kit import (
    APIKeyManager,
    EventBus,
    EventType,
    PaymentApp,
    PaymentEvent,
    RateLimiter,
    ServiceManifest,
    WalletAllowlist,
    require_payment,
)

logging.basicConfig(level=logging.INFO)

# ── Event hooks ───────────────────────────────────────────────────────────────

bus = EventBus()


@bus.on(EventType.PAYMENT_VERIFIED)
async def on_payment(event: PaymentEvent):
    logging.info("Payment received: %s on %s", event.tx_hash, event.route)


@bus.on(EventType.RATE_LIMITED)
async def on_rate_limited(event: PaymentEvent):
    logging.warning("Rate limited: %s on %s", event.client_id, event.route)


# ── Access control ────────────────────────────────────────────────────────────

api_keys = APIKeyManager()
api_keys.add_key("demo-partner", "sk_demo_abc123")
api_keys.add_key("internal-agent", "sk_agent_xyz789")

allowlist = WalletAllowlist()
allowlist.add(
    "0x0000000000000000000000000000000000000001",
    label="test-agent",
)

rate_limiter = RateLimiter(
    requests_per_minute=30,
    route_limits={"/forecast": 10, "/alerts": 5},
)

# ── Service manifest ──────────────────────────────────────────────────────────

manifest = ServiceManifest(
    name="x402 Weather API",
    description="Pay-per-request weather data for humans and AI agents",
    version="0.3.0",
    tags=["weather", "data", "climate", "forecast"],
    homepage="https://github.com/your-org/x402-fastapi-kit",
)

# ── App (all features enabled) ────────────────────────────────────────────────

app = PaymentApp(
    title="x402 Weather API",
    description="Full-featured example: payments, auth, rate limits, "
    "discovery, analytics",
    version="0.3.0",
    event_bus=bus,
    api_key_manager=api_keys,
    wallet_allowlist=allowlist,
    rate_limiter=rate_limiter,
    manifest=manifest,
    analytics=True,
)

# Enrich OpenAPI with x402 payment metadata
app.enrich_openapi_schema()


# ── Free endpoints ────────────────────────────────────────────────────────────


@app.get("/", response_class=HTMLResponse, tags=["public"])
async def landing():
    return """
    <!DOCTYPE html>
    <html>
    <head><title>x402 Weather API</title></head>
    <body style="font-family:system-ui;max-width:700px;margin:4rem auto;
                 padding:0 1rem;color:#333;">
    <h1>x402 Weather API <small style="color:#888">v0.3</small></h1>
    <p>Pay-per-request weather data powered by
       <strong>x402-fastapi-kit</strong>.</p>

    <h3>Try it</h3>
    <pre style="background:#f5f5f5;padding:1rem;border-radius:6px;
                font-size:13px;overflow-x:auto;">
# 402 — no payment
curl localhost:8000/weather

# 200 — API key bypass
curl -H "X-API-Key: sk_demo_abc123" localhost:8000/weather

# 200 — wallet allowlist
curl -H "X-WALLET: 0x000...001" localhost:8000/weather</pre>

    <h3>Endpoints</h3>
    <table style="border-collapse:collapse;width:100%;font-size:14px;">
      <tr style="border-bottom:1px solid #ddd">
        <td><code>GET /weather</code></td>
        <td>Current weather — $0.01</td></tr>
      <tr style="border-bottom:1px solid #ddd">
        <td><code>GET /forecast</code></td>
        <td>5-day forecast — $0.05</td></tr>
      <tr style="border-bottom:1px solid #ddd">
        <td><code>POST /alerts</code></td>
        <td>Custom alerts — $0.10</td></tr>
    </table>

    <h3>Introspection</h3>
    <p>
      <a href="/docs">OpenAPI docs</a> ·
      <a href="/x402/health">Health</a> ·
      <a href="/x402/routes">Routes</a> ·
      <a href="/x402/stats">Stats (JSON)</a> ·
      <a href="/x402/dashboard">Dashboard</a> ·
      <a href="/.well-known/x402">Manifest</a>
    </p>
    </body></html>
    """


@app.get("/ping", tags=["public"])
async def ping():
    return {
        "pong": True,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# ── Paid endpoints ────────────────────────────────────────────────────────────


@app.get("/weather", tags=["weather"])
@require_payment(price="$0.01", description="Current weather conditions")
async def get_weather(request: Request):
    payment = getattr(request.state, "x402_payment", None)
    auth = getattr(request.state, "x402_auth", None)
    return {
        "report": {
            "weather": random.choice(
                ["sunny", "cloudy", "rainy", "windy"]
            ),
            "temperature_f": random.randint(20, 100),
            "humidity_pct": random.randint(10, 95),
        },
        "auth_method": auth.method.value if auth else "x402",
        "payment_tx": (
            payment.get("transaction") if payment else None
        ),
    }


@app.get("/forecast", tags=["weather"])
@require_payment(price="$0.05", description="5-day weather forecast")
async def get_forecast():
    conditions = ["sunny", "cloudy", "rainy", "windy", "snowy"]
    return {
        "forecast": [
            {
                "day": i + 1,
                "condition": random.choice(conditions),
                "high_f": random.randint(50, 95),
                "low_f": random.randint(20, 55),
            }
            for i in range(5)
        ],
    }


@app.post("/alerts", tags=["weather"])
@require_payment(price="$0.10", description="Create weather alert")
async def create_alert():
    return {
        "alert_id": f"alert_{random.randint(1000, 9999)}",
        "status": "registered",
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "examples.app:app", host="0.0.0.0", port=8000, reload=True
    )
