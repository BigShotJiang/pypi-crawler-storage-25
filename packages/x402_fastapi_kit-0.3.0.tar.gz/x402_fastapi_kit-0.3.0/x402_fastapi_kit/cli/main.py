"""
x402kit CLI — scaffold new x402-fastapi-kit projects.

Usage::

    x402kit init my-paid-api
    x402kit info
"""

from __future__ import annotations

import argparse
import os
import sys
import textwrap

APP_TEMPLATE = textwrap.dedent('''\
    """
    {name} — powered by x402-fastapi-kit
    """

    from x402_fastapi_kit import PaymentApp, require_payment

    app = PaymentApp(title="{name}")


    @app.get("/")
    async def root():
        """Free public endpoint."""
        return {{"service": "{name}", "docs": "/docs"}}


    @app.get("/data")
    @require_payment(price="$0.01", description="Premium data endpoint")
    async def paid_data():
        """Payment-gated endpoint — $0.01 per request."""
        return {{"data": "This is premium content!", "paid": True}}


    if __name__ == "__main__":
        import uvicorn
        uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
''')

ENV_TEMPLATE = textwrap.dedent('''\
    # x402-fastapi-kit configuration
    # See: https://github.com/your-org/x402-fastapi-kit#configuration

    # REQUIRED: Your wallet address (EVM hex or Solana base58)
    X402_PAY_TO=0xYOUR_WALLET_ADDRESS_HERE

    # Network (default: Base Sepolia testnet)
    X402_NETWORK=eip155:84532

    # Facilitator URL (default: testnet facilitator)
    X402_FACILITATOR_URL=https://x402.org/facilitator

    # Default price for gated routes
    X402_DEFAULT_PRICE=$0.01

    # Server
    X402_HOST=0.0.0.0
    X402_PORT=8000
    X402_DEBUG=true

    # Optional: Solana address (for dual-chain support)
    # X402_SVM_PAY_TO=YourSolanaAddress

    # Optional: CDP credentials (for mainnet facilitator)
    # X402_CDP_API_KEY_ID=
    # X402_CDP_API_KEY_SECRET=
''')

DOCKERFILE_TEMPLATE = textwrap.dedent('''\
    FROM python:3.12-slim
    WORKDIR /app
    COPY requirements.txt .
    RUN pip install --no-cache-dir -r requirements.txt
    COPY . .
    EXPOSE 8000
    CMD ["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"]
''')

REQUIREMENTS_TEMPLATE = textwrap.dedent('''\
    x402-fastapi-kit>=0.1.0
    uvicorn>=0.23.0
''')

GITIGNORE_TEMPLATE = textwrap.dedent('''\
    __pycache__/
    *.pyc
    .env
    .venv/
    dist/
    *.egg-info/
''')


def cmd_init(args: argparse.Namespace) -> None:
    """Scaffold a new x402-fastapi-kit project."""
    name = args.name
    target = os.path.join(os.getcwd(), name)

    if os.path.exists(target):
        print(f"Error: directory '{name}' already exists.", file=sys.stderr)
        sys.exit(1)

    os.makedirs(target)

    files = {
        "app.py": APP_TEMPLATE.format(name=name),
        ".env": ENV_TEMPLATE,
        "Dockerfile": DOCKERFILE_TEMPLATE,
        "requirements.txt": REQUIREMENTS_TEMPLATE,
        ".gitignore": GITIGNORE_TEMPLATE,
    }

    for filename, content in files.items():
        path = os.path.join(target, filename)
        with open(path, "w") as f:
            f.write(content)

    print(f"✓ Created project '{name}' at ./{name}/")
    print()
    print("  Next steps:")
    print(f"    cd {name}")
    print("    pip install x402-fastapi-kit")
    print("    # Edit .env with your wallet address")
    print("    python app.py")
    print()
    print("  Then visit http://localhost:8000/docs")


def cmd_info(args: argparse.Namespace) -> None:
    """Print current kit info."""
    from x402_fastapi_kit import __version__

    print(f"x402-fastapi-kit v{__version__}")
    print()
    print("Supported networks:")
    from x402_fastapi_kit.config import Network
    for n in Network:
        print(f"  {n.value:50s}  ({n.name})")


def cli() -> None:
    parser = argparse.ArgumentParser(
        prog="x402kit",
        description="x402-fastapi-kit CLI — scaffold and manage x402 payment-gated APIs",
    )
    sub = parser.add_subparsers(dest="command")

    init_p = sub.add_parser("init", help="Create a new x402-fastapi-kit project")
    init_p.add_argument("name", help="Project directory name")

    sub.add_parser("info", help="Show version and supported networks")

    args = parser.parse_args()

    if args.command == "init":
        cmd_init(args)
    elif args.command == "info":
        cmd_info(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    cli()
