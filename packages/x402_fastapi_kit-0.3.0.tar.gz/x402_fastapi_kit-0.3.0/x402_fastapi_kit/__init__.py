"""
x402-fastapi-kit — Production-ready starter kit for x402 payment-gated FastAPI services.

Deploy an x402-paid API in 10 minutes.
Bring your data source, set your price per request,
we handle payments, caching, rate limiting, and agent discovery.
"""

# Phase 1 — Core
# Phase 3 — Discovery, Client, Analytics
from x402_fastapi_kit.analytics import AnalyticsCollector
from x402_fastapi_kit.app import PaymentApp

# Phase 2 — Access Control & Events
from x402_fastapi_kit.auth import APIKeyManager, AuthMethod, AuthResult, WalletAllowlist
from x402_fastapi_kit.cache import RedisCache
from x402_fastapi_kit.client import DryRunSigner, PaymentPolicy, PaymentSigner, X402Client
from x402_fastapi_kit.config import X402Settings
from x402_fastapi_kit.discovery import ServiceManifest, enrich_openapi, register_with_bazaar
from x402_fastapi_kit.events import EventBus, EventType, PaymentEvent
from x402_fastapi_kit.mcp import MCPWrapper
from x402_fastapi_kit.middleware.payment import PaymentGate, require_payment
from x402_fastapi_kit.middleware.rate_limit import RateLimiter
from x402_fastapi_kit.middleware.types import RoutePrice

__all__ = [
    # Core
    "PaymentApp",
    "PaymentGate",
    "X402Settings",
    "require_payment",
    "RoutePrice",
    "RateLimiter",
    # Auth & Events
    "APIKeyManager",
    "AuthMethod",
    "AuthResult",
    "WalletAllowlist",
    "EventBus",
    "EventType",
    "PaymentEvent",
    # Discovery & MCP
    "ServiceManifest",
    "enrich_openapi",
    "register_with_bazaar",
    "MCPWrapper",
    # Client
    "X402Client",
    "PaymentSigner",
    "DryRunSigner",
    "PaymentPolicy",
    # Infrastructure
    "AnalyticsCollector",
    "RedisCache",
]

__version__ = "0.3.0"
