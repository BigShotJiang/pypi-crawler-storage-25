"""
x402 Client SDK — the buyer side of the protocol.

Handles the full payment flow: request → 402 → parse requirements →
sign payment → retry with X-PAYMENT header → get response.

Usage::

    from x402_fastapi_kit.client import X402Client

    client = X402Client(
        signer=my_wallet_signer,
        max_payment="$1.00",
    )

    # Automatic: handles 402 → pay → retry transparently
    resp = await client.get("https://api.example.com/weather")
    print(resp.json())

    # Or step-by-step
    resp = await client.request("GET", "https://api.example.com/weather")

For use without a real signer (testing/dry-run), pass ``signer=None``
and the client will report payment requirements without paying.
"""

from __future__ import annotations

import base64
import contextlib
import json
import logging
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any

import httpx

logger = logging.getLogger("x402_fastapi_kit.client")


# ── Signer interface ──────────────────────────────────────────────────────────

class PaymentSigner:
    """
    Abstract signer interface.

    Implement ``sign()`` to produce a signed payment payload from
    the server's payment requirements. The returned string is sent
    as the ``X-PAYMENT`` header value.
    """

    async def sign(self, payment_requirements: dict[str, Any]) -> str:
        """
        Sign a payment for the given requirements.

        Args:
            payment_requirements: One entry from the 402 response's ``accepts`` array.

        Returns:
            Signed payment payload string for the X-PAYMENT header.
        """
        raise NotImplementedError("Subclass and implement sign()")

    @property
    def address(self) -> str:
        """Return the signer's wallet address."""
        raise NotImplementedError


class DryRunSigner(PaymentSigner):
    """
    A no-op signer for testing/dry-run mode.

    Returns a placeholder payload that will fail verification but lets
    you exercise the full flow without a real wallet.
    """

    async def sign(self, payment_requirements: dict[str, Any]) -> str:
        return base64.b64encode(json.dumps({
            "dry_run": True,
            "requirements": payment_requirements,
            "timestamp": time.time(),
        }).encode()).decode()

    @property
    def address(self) -> str:
        return "0x0000000000000000000000000000000000000000"


# ── Payment policies ──────────────────────────────────────────────────────────

@dataclass
class PaymentPolicy:
    """
    Spending controls for the client.

    Prevents accidental overspending by rejecting payment requirements
    that exceed configured limits.
    """

    max_per_request: Decimal = Decimal("1.00")
    max_per_session: Decimal = Decimal("10.00")
    preferred_network: str | None = None
    preferred_scheme: str | None = None
    _session_spent: Decimal = field(default=Decimal("0"), init=False)

    def check(self, price_str: str) -> bool:
        """Return True if the price is within policy limits."""
        price = Decimal(price_str.lstrip("$"))
        if price > self.max_per_request:
            logger.warning(
                "Policy reject: $%s > max_per_request $%s",
                price, self.max_per_request,
            )
            return False
        if self._session_spent + price > self.max_per_session:
            logger.warning(
                "Policy reject: session total $%s + $%s > max_per_session $%s",
                self._session_spent, price, self.max_per_session,
            )
            return False
        return True

    def record_spend(self, price_str: str) -> None:
        """Record a successful payment."""
        self._session_spent += Decimal(price_str.lstrip("$"))

    @property
    def session_spent(self) -> Decimal:
        return self._session_spent

    def select_requirement(
        self, accepts: list[dict[str, Any]]
    ) -> dict[str, Any] | None:
        """
        Select the best payment option from the 402 ``accepts`` array.

        Applies network/scheme preferences, then picks the cheapest
        option that passes policy checks.
        """
        candidates = []
        for req in accepts:
            price_str = req.get("price", "$0")
            if not self.check(price_str):
                continue

            score = 0
            if self.preferred_network and req.get("network") == self.preferred_network:
                score += 10
            if self.preferred_scheme and req.get("scheme") == self.preferred_scheme:
                score += 5

            candidates.append((score, Decimal(price_str.lstrip("$")), req))

        if not candidates:
            return None

        # Sort by score (desc), then price (asc)
        candidates.sort(key=lambda x: (-x[0], x[1]))
        return candidates[0][2]


# ── Payment receipt ───────────────────────────────────────────────────────────

@dataclass
class PaymentReceipt:
    """Record of a completed payment."""

    url: str
    method: str
    price: str
    network: str
    tx_hash: str | None
    timestamp: float = field(default_factory=time.time)


# ── X402 Client ───────────────────────────────────────────────────────────────

class X402Client:
    """
    HTTP client that transparently handles x402 payment flows.

    Wraps ``httpx.AsyncClient`` and intercepts 402 responses:
    parse payment requirements → select best option → sign → retry.

    Args:
        signer: Wallet signer (or ``DryRunSigner()`` for testing).
        policy: Spending policy/limits.
        max_retries: Max payment attempts per request.
        headers: Extra headers to include on all requests.

    Example::

        client = X402Client(signer=my_signer)

        # These all handle 402 transparently:
        resp = await client.get("https://api.example.com/data")
        resp = await client.post("https://api.example.com/submit", json={...})
    """

    def __init__(
        self,
        signer: PaymentSigner | None = None,
        policy: PaymentPolicy | None = None,
        max_retries: int = 1,
        headers: dict[str, str] | None = None,
        timeout: float = 30.0,
    ) -> None:
        self.signer = signer or DryRunSigner()
        self.policy = policy or PaymentPolicy()
        self.max_retries = max_retries
        self._extra_headers = headers or {}
        self._timeout = timeout
        self._receipts: list[PaymentReceipt] = []

    @property
    def receipts(self) -> list[PaymentReceipt]:
        """All payment receipts from this session."""
        return list(self._receipts)

    @property
    def total_spent(self) -> Decimal:
        """Total spent this session."""
        return self.policy.session_spent

    async def request(
        self,
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """
        Make an HTTP request, handling x402 payment if needed.

        If the server returns 402, the client will:
        1. Parse the payment requirements
        2. Select the best option per policy
        3. Sign the payment
        4. Retry with the X-PAYMENT header

        Returns the final response (200 after payment, or the 402 if
        payment wasn't possible).
        """
        headers = {**self._extra_headers, **kwargs.pop("headers", {})}

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            # Initial request
            resp = await client.request(
                method, url, headers=headers, **kwargs
            )

            if resp.status_code != 402:
                return resp

            # Parse 402 response
            try:
                body = resp.json()
            except Exception:
                logger.warning("Could not parse 402 body from %s", url)
                return resp

            accepts = body.get("accepts", [])
            if not accepts:
                logger.warning("402 with no accepts from %s", url)
                return resp

            # Select best payment option
            requirement = self.policy.select_requirement(accepts)
            if requirement is None:
                logger.warning(
                    "No acceptable payment option for %s (policy rejected all)",
                    url,
                )
                return resp

            # Sign and retry
            for _attempt in range(self.max_retries):
                try:
                    payment_payload = await self.signer.sign(requirement)
                except Exception as exc:
                    logger.error("Signer error: %s", exc)
                    return resp

                retry_headers = {
                    **headers,
                    "X-PAYMENT": payment_payload,
                }

                resp = await client.request(
                    method, url, headers=retry_headers, **kwargs
                )

                if resp.status_code != 402:
                    # Payment accepted (or other status)
                    price = requirement.get("price", "$0")
                    self.policy.record_spend(price)

                    # Extract tx hash from response header
                    tx_hash = None
                    payment_resp = resp.headers.get("X-PAYMENT-RESPONSE")
                    if payment_resp:
                        with contextlib.suppress(Exception):
                            tx_hash = json.loads(payment_resp).get("transaction")

                    self._receipts.append(PaymentReceipt(
                        url=url,
                        method=method,
                        price=price,
                        network=requirement.get("network", "unknown"),
                        tx_hash=tx_hash,
                    ))

                    logger.info(
                        "✓ Paid %s for %s %s (tx: %s)",
                        price, method, url, tx_hash or "?",
                    )
                    return resp

            return resp

    # ── Convenience methods ───────────────────────────────────────────

    async def get(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("GET", url, **kwargs)

    async def post(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("POST", url, **kwargs)

    async def put(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("PUT", url, **kwargs)

    async def delete(self, url: str, **kwargs: Any) -> httpx.Response:
        return await self.request("DELETE", url, **kwargs)

    # ── Discovery helper ──────────────────────────────────────────────

    async def discover(self, base_url: str) -> dict[str, Any] | None:
        """
        Fetch the ``.well-known/x402`` manifest from a service.

        Returns the manifest dict, or None if not found.
        """
        url = f"{base_url.rstrip('/')}/.well-known/x402"
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            try:
                resp = await client.get(url)
                if resp.status_code == 200:
                    return resp.json()
            except Exception as exc:
                logger.debug("Discovery failed for %s: %s", base_url, exc)
        return None
