"""Utility functions for x402-fastapi-kit."""

from __future__ import annotations

import re
from decimal import Decimal


def parse_price(price_str: str) -> int:
    """
    Parse a human-friendly price string into the smallest unit (6 decimals for USDC).

    Examples::

        parse_price("$0.01")   → 10000
        parse_price("$1.00")   → 1000000
        parse_price("0.001")   → 1000
        parse_price("$0.0001") → 100
    """
    cleaned = price_str.strip().lstrip("$")
    amount = Decimal(cleaned)
    return int(amount * Decimal("1_000_000"))


def format_price(amount_smallest: int) -> str:
    """
    Format a smallest-unit amount back to a human-friendly string.

    Examples::

        format_price(10000)   → "$0.01"
        format_price(1000000) → "$1.00"
    """
    usd = Decimal(amount_smallest) / Decimal("1_000_000")
    return f"${usd:.2f}"


def is_evm_address(address: str) -> bool:
    """Check if a string looks like a valid EVM address."""
    return bool(re.match(r"^0x[0-9a-fA-F]{40}$", address))


def is_solana_address(address: str) -> bool:
    """Check if a string looks like a valid Solana address (base58, 32-44 chars)."""
    return bool(re.match(r"^[1-9A-HJ-NP-Za-km-z]{32,44}$", address))


def mask_address(address: str, show: int = 6) -> str:
    """Mask a wallet address for safe logging."""
    if len(address) <= show * 2:
        return address
    return f"{address[:show]}…{address[-4:]}"
