"""
Authentication and access control for x402-fastapi-kit.

Provides two bypass mechanisms that skip x402 payment verification:

1. **API Key Auth** — Traditional ``X-API-Key`` header authentication for clients
   that haven't adopted x402 yet. Keys are loaded from config.

2. **Wallet Allowlist** — Pre-approved wallet addresses that get free access
   (partners, your own AI agents, test wallets). Extracted from the payment
   header's signer address or a dedicated ``X-WALLET`` header.

Both mechanisms short-circuit the payment middleware: if a request is
authenticated via API key or allowlisted wallet, it passes through without
hitting the facilitator.
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import secrets
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger("x402_fastapi_kit")


class AuthMethod(str, Enum):
    """How a request was authenticated."""

    X402_PAYMENT = "x402"
    API_KEY = "api_key"
    WALLET_ALLOWLIST = "wallet_allowlist"
    NONE = "none"


@dataclass(frozen=True)
class AuthResult:
    """Result of an authentication check."""

    authenticated: bool
    method: AuthMethod
    identity: str | None = None  # API key name or wallet address
    reason: str | None = None  # Why it failed (if applicable)


# ── API Key Manager ───────────────────────────────────────────────────────────

class APIKeyManager:
    """
    Manages API key authentication.

    Keys are stored as ``name → hashed_secret`` pairs. The ``X-API-Key`` header
    value is compared in constant time against all registered keys.

    Usage::

        mgr = APIKeyManager()
        mgr.add_key("my-partner", "sk_live_abc123")

        result = mgr.verify("sk_live_abc123")
        assert result.authenticated
        assert result.identity == "my-partner"
    """

    def __init__(self) -> None:
        self._keys: dict[str, str] = {}  # name → sha256(secret)
        self._lookup: dict[str, str] = {}  # sha256(secret) → name

    @staticmethod
    def _hash(secret: str) -> str:
        return hashlib.sha256(secret.encode()).hexdigest()

    def add_key(self, name: str, secret: str) -> None:
        """Register an API key."""
        h = self._hash(secret)
        self._keys[name] = h
        self._lookup[h] = name
        logger.debug("Registered API key: %s", name)

    def add_keys(self, keys: dict[str, str]) -> None:
        """Register multiple API keys (name → secret)."""
        for name, secret in keys.items():
            self.add_key(name, secret)

    def revoke_key(self, name: str) -> bool:
        """Revoke an API key by name. Returns True if found."""
        h = self._keys.pop(name, None)
        if h:
            self._lookup.pop(h, None)
            logger.info("Revoked API key: %s", name)
            return True
        return False

    def verify(self, secret: str) -> AuthResult:
        """
        Verify an API key secret.

        Uses constant-time comparison to prevent timing attacks.
        """
        candidate_hash = self._hash(secret)

        for stored_hash, name in self._lookup.items():
            if hmac.compare_digest(candidate_hash, stored_hash):
                return AuthResult(
                    authenticated=True,
                    method=AuthMethod.API_KEY,
                    identity=name,
                )

        return AuthResult(
            authenticated=False,
            method=AuthMethod.NONE,
            reason="Invalid API key",
        )

    @staticmethod
    def generate_key(prefix: str = "sk_x402") -> str:
        """Generate a cryptographically secure API key."""
        return f"{prefix}_{secrets.token_urlsafe(32)}"

    def __len__(self) -> int:
        return len(self._keys)

    def list_names(self) -> list[str]:
        """Return registered key names (not secrets)."""
        return list(self._keys.keys())


# ── Wallet Allowlist ──────────────────────────────────────────────────────────

class WalletAllowlist:
    """
    Manages a set of pre-approved wallet addresses.

    Allowlisted wallets bypass x402 payment verification entirely.
    Addresses are stored normalised (lowercase for EVM, as-is for Solana).

    Usage::

        allowlist = WalletAllowlist()
        allowlist.add("0xMyPartnerWallet")
        allowlist.add("SolanaPartnerAddress")

        result = allowlist.check("0xmypartnerwallet")  # case-insensitive for EVM
        assert result.authenticated
    """

    def __init__(self) -> None:
        self._addresses: set[str] = set()
        self._labels: dict[str, str] = {}  # normalised address → label

    @staticmethod
    def _normalise(address: str) -> str:
        """Normalise an address for comparison."""
        addr = address.strip()
        if addr.startswith("0x"):
            return addr.lower()
        return addr

    def add(self, address: str, label: str | None = None) -> None:
        """Add an address to the allowlist."""
        norm = self._normalise(address)
        self._addresses.add(norm)
        if label:
            self._labels[norm] = label
        logger.debug("Allowlisted wallet: %s (%s)", norm[:10] + "…", label or "unlabelled")

    def add_many(self, addresses: list[str] | dict[str, str]) -> None:
        """
        Add multiple addresses.

        Accepts a list of addresses or a dict of {address: label}.
        """
        if isinstance(addresses, dict):
            for addr, label in addresses.items():
                self.add(addr, label)
        else:
            for addr in addresses:
                self.add(addr)

    def remove(self, address: str) -> bool:
        """Remove an address. Returns True if found."""
        norm = self._normalise(address)
        if norm in self._addresses:
            self._addresses.discard(norm)
            self._labels.pop(norm, None)
            return True
        return False

    def check(self, address: str) -> AuthResult:
        """Check if a wallet address is allowlisted."""
        norm = self._normalise(address)
        if norm in self._addresses:
            label = self._labels.get(norm)
            identity = label or norm
            return AuthResult(
                authenticated=True,
                method=AuthMethod.WALLET_ALLOWLIST,
                identity=identity,
            )
        return AuthResult(
            authenticated=False,
            method=AuthMethod.NONE,
            reason="Wallet not allowlisted",
        )

    def __len__(self) -> int:
        return len(self._addresses)

    def __contains__(self, address: str) -> bool:
        return self._normalise(address) in self._addresses

    def list_addresses(self) -> list[dict[str, str]]:
        """Return allowlisted addresses with labels."""
        return [
            {"address": addr, "label": self._labels.get(addr, "")}
            for addr in sorted(self._addresses)
        ]
