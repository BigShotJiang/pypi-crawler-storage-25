"""
Redis caching layer for x402-fastapi-kit.

Provides a cache-aside pattern with TTL-based expiry and graceful
fallback when Redis is unavailable. If Redis goes down, the API
keeps serving — it just skips the cache.

Usage::

    from x402_fastapi_kit.cache import RedisCache

    cache = RedisCache(url="redis://localhost:6379")

    # Cache a response
    await cache.set("sold_prices:SW1A_1AA", data, ttl=3600)

    # Retrieve (returns None on miss or Redis failure)
    data = await cache.get("sold_prices:SW1A_1AA")

    # Use as a decorator on your service functions
    @cache.cached(prefix="sold_prices", ttl=3600)
    async def get_sold_prices(postcode: str):
        return await fetch_from_land_registry(postcode)
"""

from __future__ import annotations

import hashlib
import json
import logging
from collections.abc import Callable
from dataclasses import dataclass
from functools import wraps
from typing import Any

logger = logging.getLogger("x402_fastapi_kit")


@dataclass
class CacheStats:
    """Cache performance counters."""

    hits: int = 0
    misses: int = 0
    errors: int = 0
    sets: int = 0

    @property
    def hit_rate(self) -> float:
        total = self.hits + self.misses
        return self.hits / total if total > 0 else 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "hits": self.hits,
            "misses": self.misses,
            "errors": self.errors,
            "sets": self.sets,
            "hit_rate": round(self.hit_rate, 3),
        }


class RedisCache:
    """
    Redis cache with graceful fallback.

    If Redis is unavailable (connection error, timeout), all operations
    return None / succeed silently — the API never fails because of cache.

    Args:
        url: Redis connection URL (e.g. ``redis://localhost:6379``).
        default_ttl: Default TTL in seconds for cached values.
        key_prefix: Global prefix for all cache keys.
    """

    def __init__(
        self,
        url: str = "redis://localhost:6379",
        default_ttl: int = 3600,
        key_prefix: str = "x402:",
    ) -> None:
        self.url = url
        self.default_ttl = default_ttl
        self.key_prefix = key_prefix
        self.stats = CacheStats()
        self._redis: Any = None
        self._available = True

    async def _get_redis(self) -> Any:
        """Lazy-connect to Redis."""
        if self._redis is not None:
            return self._redis
        try:
            import redis.asyncio as aioredis

            self._redis = aioredis.from_url(
                self.url,
                decode_responses=True,
                socket_connect_timeout=2,
                socket_timeout=2,
            )
            # Test connection
            await self._redis.ping()
            self._available = True
            logger.info("Redis connected: %s", self.url)
            return self._redis
        except Exception as exc:
            logger.warning("Redis unavailable, caching disabled: %s", exc)
            self._available = False
            self._redis = None
            return None

    def _make_key(self, key: str) -> str:
        """Build a namespaced cache key."""
        return f"{self.key_prefix}{key}"

    async def get(self, key: str) -> Any | None:
        """
        Retrieve a cached value.

        Returns None on cache miss or Redis failure.
        """
        r = await self._get_redis()
        if r is None:
            self.stats.misses += 1
            return None

        try:
            raw = await r.get(self._make_key(key))
            if raw is None:
                self.stats.misses += 1
                return None
            self.stats.hits += 1
            return json.loads(raw)
        except Exception as exc:
            logger.debug("Cache get error for %s: %s", key, exc)
            self.stats.errors += 1
            return None

    async def set(
        self, key: str, value: Any, ttl: int | None = None
    ) -> bool:
        """
        Store a value in cache.

        Returns True on success, False on failure (silent).
        """
        r = await self._get_redis()
        if r is None:
            return False

        try:
            raw = json.dumps(value, default=str)
            await r.setex(
                self._make_key(key),
                ttl or self.default_ttl,
                raw,
            )
            self.stats.sets += 1
            return True
        except Exception as exc:
            logger.debug("Cache set error for %s: %s", key, exc)
            self.stats.errors += 1
            return False

    async def delete(self, key: str) -> bool:
        """Delete a cached value."""
        r = await self._get_redis()
        if r is None:
            return False
        try:
            await r.delete(self._make_key(key))
            return True
        except Exception:
            return False

    async def clear_prefix(self, prefix: str) -> int:
        """Delete all keys matching a prefix. Returns count deleted."""
        r = await self._get_redis()
        if r is None:
            return 0
        try:
            pattern = self._make_key(f"{prefix}*")
            keys = []
            async for key in r.scan_iter(match=pattern, count=100):
                keys.append(key)
            if keys:
                return await r.delete(*keys)
            return 0
        except Exception:
            return 0

    @property
    def is_available(self) -> bool:
        return self._available

    def cached(
        self,
        prefix: str,
        ttl: int | None = None,
    ) -> Callable:
        """
        Decorator that caches function results in Redis.

        Cache key is built from the prefix + function arguments.

        Example::

            @cache.cached(prefix="sold_prices", ttl=3600)
            async def get_sold_prices(postcode: str):
                return await fetch_from_land_registry(postcode)
        """
        cache_ref = self

        def decorator(func: Callable) -> Callable:
            @wraps(func)
            async def wrapper(*args: Any, **kwargs: Any) -> Any:
                # Build cache key from args
                key_data = f"{prefix}:{args}:{kwargs}"
                cache_key = hashlib.md5(
                    key_data.encode()
                ).hexdigest()
                full_key = f"{prefix}:{cache_key}"

                # Try cache first
                cached_value = await cache_ref.get(full_key)
                if cached_value is not None:
                    return cached_value

                # Cache miss — call the function
                result = await func(*args, **kwargs)

                # Store in cache (fire-and-forget)
                await cache_ref.set(full_key, result, ttl=ttl)

                return result

            wrapper._cache_prefix = prefix  # type: ignore[attr-defined]
            return wrapper

        return decorator

    async def close(self) -> None:
        """Close the Redis connection."""
        if self._redis is not None:
            await self._redis.close()
            self._redis = None
