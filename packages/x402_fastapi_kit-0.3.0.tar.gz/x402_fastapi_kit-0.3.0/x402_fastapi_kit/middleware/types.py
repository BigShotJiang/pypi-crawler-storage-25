"""Shared types for the payment middleware layer."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class RoutePrice:
    """
    Pricing configuration for a single route.

    Examples::

        RoutePrice(price="$0.01")
        RoutePrice(price="$0.10", description="Premium weather data")
        RoutePrice(price="$1.00", network="eip155:8453")  # override global network
    """

    price: str
    description: str | None = None
    network: str | None = None
    scheme: str | None = None
    pay_to: str | None = None
    max_timeout_seconds: int | None = None

    def to_accepts(
        self,
        *,
        default_network: str,
        default_scheme: str,
        default_pay_to: str,
        default_timeout: int,
        default_description: str,
    ) -> dict:
        """Convert to the x402 PaymentOption-compatible dict."""
        return {
            "scheme": self.scheme or default_scheme,
            "network": self.network or default_network,
            "price": self.price,
            "pay_to": self.pay_to or default_pay_to,
            "description": self.description or default_description,
            "max_timeout_seconds": self.max_timeout_seconds or default_timeout,
        }


@dataclass
class RouteRegistry:
    """Thread-safe registry of payment-gated routes."""

    _routes: dict[str, RoutePrice] = field(default_factory=dict)

    def register(self, method: str, path: str, config: RoutePrice) -> None:
        key = f"{method.upper()} {path}"
        self._routes[key] = config

    def get(self, method: str, path: str) -> RoutePrice | None:
        key = f"{method.upper()} {path}"
        return self._routes.get(key)

    def all(self) -> dict[str, RoutePrice]:
        return dict(self._routes)

    def __len__(self) -> int:
        return len(self._routes)
