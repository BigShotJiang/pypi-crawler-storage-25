"""
Payment middleware and route decorator for x402-fastapi-kit.

This module provides the core payment enforcement layer:

1. **PaymentGate** — ASGI middleware with the full Phase 2 dispatch pipeline:
   - Wallet allowlist check (bypass)
   - API key auth check (bypass)
   - Rate limit check (429)
   - x402 payment verification (402 / pass-through)
   - Event hook emission at every decision point

2. **@require_payment** — Decorator that marks routes for gating.
"""

from __future__ import annotations

import base64
import json
import logging
from collections.abc import Callable
from functools import wraps
from typing import Any

import httpx
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import JSONResponse

from x402_fastapi_kit.auth import (
    APIKeyManager,
    WalletAllowlist,
)
from x402_fastapi_kit.config import X402Settings
from x402_fastapi_kit.events import EventBus, EventType, PaymentEvent
from x402_fastapi_kit.middleware.rate_limit import RateLimiter
from x402_fastapi_kit.middleware.types import RoutePrice, RouteRegistry

logger = logging.getLogger("x402_fastapi_kit")

# ── Module-level registry (populated by @require_payment) ────────────────────
_registry = RouteRegistry()


def get_registry() -> RouteRegistry:
    """Return the global route registry."""
    return _registry


# ── x402 response builder ────────────────────────────────────────────────────

def _build_402_response(
    request: Request,
    route_price: RoutePrice,
    settings: X402Settings,
) -> JSONResponse:
    """Build a spec-compliant x402 v2 402 response."""
    accepts = [
        route_price.to_accepts(
            default_network=settings.network,
            default_scheme=settings.scheme,
            default_pay_to=settings.pay_to,
            default_timeout=settings.max_timeout_seconds,
            default_description=settings.default_description,
        )
    ]

    if settings.svm_pay_to and not route_price.network:
        svm_network = "solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1"
        if not settings.is_testnet:
            svm_network = "solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp"
        accepts.append(
            {
                "scheme": route_price.scheme or settings.scheme,
                "network": svm_network,
                "price": route_price.price,
                "pay_to": settings.svm_pay_to,
                "description": route_price.description or settings.default_description,
                "max_timeout_seconds": (
                    route_price.max_timeout_seconds or settings.max_timeout_seconds
                ),
            }
        )

    body = {
        "x402Version": 2,
        "error": "Payment required",
        "resource": {"url": str(request.url)},
        "accepts": accepts,
    }

    encoded = base64.b64encode(json.dumps(body).encode()).decode()

    return JSONResponse(
        status_code=402,
        content=body,
        headers={"PAYMENT-REQUIRED": encoded},
    )


# ── Facilitator verification ─────────────────────────────────────────────────

async def _verify_payment(
    payment_header: str,
    route_price: RoutePrice,
    settings: X402Settings,
) -> dict[str, Any]:
    """Verify a payment payload with the facilitator."""
    accepts = route_price.to_accepts(
        default_network=settings.network,
        default_scheme=settings.scheme,
        default_pay_to=settings.pay_to,
        default_timeout=settings.max_timeout_seconds,
        default_description=settings.default_description,
    )

    verify_url = f"{settings.facilitator_url.rstrip('/')}/verify"

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            verify_url,
            json={
                "paymentPayload": payment_header,
                "paymentRequirements": accepts,
            },
        )
        resp.raise_for_status()
        return resp.json()


# ── Client ID extraction ─────────────────────────────────────────────────────

def _get_client_id(request: Request) -> str:
    """Extract a client identifier for rate limiting."""
    # Prefer forwarded IP, then direct IP, then fallback
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    if request.client:
        return request.client.host
    return "unknown"


# ── Route discovery helper ────────────────────────────────────────────────────

def _discover_payment_routes(app: Any, settings: X402Settings) -> None:
    """Walk registered FastAPI routes and pick up @require_payment metadata."""
    for route in app.routes:
        endpoint = getattr(route, "endpoint", None)
        if endpoint is None:
            continue

        price_config = getattr(endpoint, "_x402_price", None)
        if price_config is None:
            continue

        if price_config.price is None:
            price_config.price = settings.default_price

        methods = getattr(route, "methods", {"GET"})
        path = getattr(route, "path", None)
        if path:
            for method in methods:
                _registry.register(method, path, price_config)
                logger.debug(
                    "Registered gated route: %s %s → %s",
                    method, path, price_config.price,
                )


# ── ASGI Middleware ───────────────────────────────────────────────────────────

class PaymentGate(BaseHTTPMiddleware):
    """
    ASGI middleware with the full x402-fastapi-kit dispatch pipeline.

    On each request to a gated route, the pipeline runs in order:

    1. **Wallet allowlist** — if the wallet is pre-approved, pass through
    2. **API key auth** — if a valid ``X-API-Key`` is present, pass through
    3. **Rate limiter** — if the client has exceeded their limit, return 429
    4. **x402 payment** — verify with facilitator or return 402

    Event hooks fire at every decision point for observability.
    """

    def __init__(
        self,
        app: Any,
        settings: X402Settings | None = None,
        owner_app: Any | None = None,
        event_bus: EventBus | None = None,
        api_key_manager: APIKeyManager | None = None,
        wallet_allowlist: WalletAllowlist | None = None,
        rate_limiter: RateLimiter | None = None,
    ) -> None:
        super().__init__(app)
        self.settings = settings or X402Settings()
        self._owner_app = owner_app
        self._discovered = False

        # Phase 2 components
        self.event_bus = event_bus or EventBus()
        self.api_keys = api_key_manager or APIKeyManager()
        self.allowlist = wallet_allowlist or WalletAllowlist()
        self.rate_limiter = rate_limiter

        # Auto-configure from settings
        self._configure_from_settings()

    def _configure_from_settings(self) -> None:
        """Wire up Phase 2 components from X402Settings."""
        s = self.settings

        # Rate limiter
        if s.rate_limit_enabled and self.rate_limiter is None:
            self.rate_limiter = RateLimiter(
                requests_per_minute=s.rate_limit_rpm,
                route_limits=s.parse_rate_limit_routes(),
            )

        # API keys
        if s.api_keys_enabled:
            parsed = s.parse_api_keys()
            if parsed:
                self.api_keys.add_keys(parsed)

        # Wallet allowlist
        if s.allowlist_enabled:
            parsed = s.parse_allowlist()
            if parsed:
                self.allowlist.add_many(parsed)

    def _ensure_discovered(self) -> None:
        """Lazily discover decorated routes on first request."""
        if self._discovered:
            return
        self._discovered = True

        if self._owner_app is not None:
            _discover_payment_routes(self._owner_app, self.settings)
            env_label = "TESTNET" if self.settings.is_testnet else "MAINNET"
            chain = "EVM" if self.settings.is_evm else "SVM" if self.settings.is_svm else "?"
            logger.info(
                "x402-fastapi-kit ready · %s · %s · %s · %d route(s) · "
                "%d API key(s) · %d allowlisted",
                env_label, chain, self.settings.network, len(_registry),
                len(self.api_keys), len(self.allowlist),
            )

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        self._ensure_discovered()

        route_price = _registry.get(request.method, request.url.path)

        if route_price is None:
            return await call_next(request)

        client_id = _get_client_id(request)
        path = request.url.path
        method = request.method

        # ── Step 1: Wallet allowlist check ────────────────────────────
        wallet_header = request.headers.get("X-WALLET", "").strip()
        if wallet_header and len(self.allowlist) > 0:
            allow_result = self.allowlist.check(wallet_header)
            if allow_result.authenticated:
                request.state.x402_auth = allow_result
                logger.info(
                    "✓ allowlisted → %s %s (%s)",
                    method, path, allow_result.identity,
                )
                await self.event_bus.emit(PaymentEvent(
                    event_type=EventType.AUTH_ALLOWLIST,
                    route=path, method=method,
                    client_id=allow_result.identity,
                    price=route_price.price,
                ))
                return await call_next(request)

        # ── Step 2: API key auth check ────────────────────────────────
        api_key_header = request.headers.get("X-API-Key", "").strip()
        if api_key_header and len(self.api_keys) > 0:
            key_result = self.api_keys.verify(api_key_header)
            if key_result.authenticated:
                request.state.x402_auth = key_result
                logger.info(
                    "✓ API key → %s %s (%s)",
                    method, path, key_result.identity,
                )
                await self.event_bus.emit(PaymentEvent(
                    event_type=EventType.AUTH_API_KEY,
                    route=path, method=method,
                    client_id=key_result.identity,
                    price=route_price.price,
                ))
                return await call_next(request)

        # ── Step 3: Rate limit check ──────────────────────────────────
        if self.rate_limiter is not None:
            rl_result = await self.rate_limiter.check(client_id, route=path)
            if not rl_result.allowed:
                logger.info(
                    "429 → %s %s (rate limited: %s)",
                    method, path, client_id,
                )
                await self.event_bus.emit(PaymentEvent(
                    event_type=EventType.RATE_LIMITED,
                    route=path, method=method,
                    client_id=client_id,
                    price=route_price.price,
                ))
                return JSONResponse(
                    status_code=429,
                    content={
                        "error": "Rate limit exceeded",
                        "retry_after": rl_result.retry_after,
                    },
                    headers=rl_result.headers(),
                )

        # ── Step 4: x402 payment check ────────────────────────────────
        payment_header = (
            request.headers.get("X-PAYMENT")
            or request.headers.get("PAYMENT-SIGNATURE")
            or request.headers.get("x-payment")
        )

        if not payment_header:
            logger.info("402 → %s %s (no payment)", method, path)
            await self.event_bus.emit(PaymentEvent(
                event_type=EventType.REQUEST_GATED,
                route=path, method=method,
                client_id=client_id,
                price=route_price.price,
            ))
            return _build_402_response(request, route_price, self.settings)

        # Verify with facilitator
        try:
            verification = await _verify_payment(
                payment_header, route_price, self.settings
            )
        except httpx.HTTPStatusError as exc:
            logger.warning("Facilitator rejected payment: %s", exc)
            await self.event_bus.emit(PaymentEvent(
                event_type=EventType.PAYMENT_REJECTED,
                route=path, method=method,
                client_id=client_id,
                reason=str(exc),
            ))
            return JSONResponse(
                status_code=402,
                content={
                    "error": "Payment verification failed",
                    "detail": str(exc),
                },
            )
        except Exception as exc:
            logger.error("Facilitator error: %s", exc)
            await self.event_bus.emit(PaymentEvent(
                event_type=EventType.FACILITATOR_ERROR,
                route=path, method=method,
                client_id=client_id,
                reason=str(exc),
            ))
            return JSONResponse(
                status_code=502,
                content={"error": "Payment facilitator unavailable"},
            )

        is_valid = verification.get("valid", False) or verification.get("isValid", False)
        if not is_valid:
            logger.info("402 → %s %s (invalid payment)", method, path)
            await self.event_bus.emit(PaymentEvent(
                event_type=EventType.PAYMENT_REJECTED,
                route=path, method=method,
                client_id=client_id,
                verification=verification,
                reason="Invalid payment",
            ))
            return JSONResponse(
                status_code=402,
                content={"error": "Invalid payment", "detail": verification},
            )

        # Payment verified!
        tx_hash = verification.get("transaction", verification.get("txHash"))
        request.state.x402_payment = verification
        logger.info("✓ paid → %s %s (tx: %s)", method, path, tx_hash or "?")

        await self.event_bus.emit(PaymentEvent(
            event_type=EventType.PAYMENT_VERIFIED,
            route=path, method=method,
            client_id=client_id,
            price=route_price.price,
            tx_hash=tx_hash,
            verification=verification,
        ))

        response = await call_next(request)

        if tx_hash:
            response.headers["X-PAYMENT-RESPONSE"] = json.dumps(
                {"transaction": tx_hash}
            )

        return response


# ── @require_payment decorator ────────────────────────────────────────────────

def require_payment(
    price: str | None = None,
    *,
    description: str | None = None,
    network: str | None = None,
    scheme: str | None = None,
    pay_to: str | None = None,
    max_timeout_seconds: int | None = None,
) -> Callable:
    """
    Decorator that registers a FastAPI route for x402 payment gating.

    Must be applied **after** the route decorator::

        @app.get("/data")
        @require_payment(price="$0.05", description="Premium data")
        async def get_data():
            return {"data": "valuable"}
    """

    route_config = RoutePrice(
        price=price,  # type: ignore[arg-type]
        description=description,
        network=network,
        scheme=scheme,
        pay_to=pay_to,
        max_timeout_seconds=max_timeout_seconds,
    )

    def decorator(func: Callable) -> Callable:
        func._x402_price = route_config  # type: ignore[attr-defined]

        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            return await func(*args, **kwargs)

        wrapper._x402_price = route_config  # type: ignore[attr-defined]
        return wrapper

    return decorator
