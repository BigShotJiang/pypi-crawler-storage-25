"""
Redis backend for the rate limiter.

Uses Redis sorted sets for a true sliding window — works across
multiple processes / containers, unlike the in-memory backend.

Usage::

    from x402_fastapi_kit.middleware.rate_limit import RateLimiter
    from x402_fastapi_kit.middleware.redis_backend import RedisBackend

    backend = RedisBackend(url="redis://localhost:6379")
    limiter = RateLimiter(requests_per_minute=60, backend=backend)
"""

from __future__ import annotations

import logging
from typing import Any

from x402_fastapi_kit.middleware.rate_limit import RateLimitBackend

logger = logging.getLogger("x402_fastapi_kit")


class RedisBackend(RateLimitBackend):
    """
    Redis-backed sliding window rate limit backend.

    Uses sorted sets with timestamps as scores. On each request:
    1. Remove entries older than the window
    2. Add the current timestamp
    3. Count remaining entries

    This is atomic via a Redis pipeline, so it's safe across
    multiple processes.

    Args:
        url: Redis connection URL.
        key_prefix: Prefix for rate limit keys in Redis.
    """

    def __init__(
        self,
        url: str = "redis://localhost:6379",
        key_prefix: str = "x402:rl:",
    ) -> None:
        self.url = url
        self.key_prefix = key_prefix
        self._redis: Any = None

    async def _get_redis(self) -> Any:
        if self._redis is not None:
            return self._redis
        try:
            import redis.asyncio as aioredis

            self._redis = aioredis.from_url(
                self.url,
                decode_responses=True,
                socket_connect_timeout=2,
                socket_timeout=2,
            )
            await self._redis.ping()
            logger.info("Redis rate limiter connected: %s", self.url)
            return self._redis
        except Exception as exc:
            logger.warning(
                "Redis rate limiter unavailable: %s", exc
            )
            return None

    def _make_key(self, key: str) -> str:
        return f"{self.key_prefix}{key}"

    async def record_and_count(
        self, key: str, window_seconds: float, now: float
    ) -> int:
        """
        Record a request and return the count in the current window.

        Uses a Redis pipeline for atomicity:
        1. ZREMRANGEBYSCORE to prune old entries
        2. ZADD to add the current timestamp
        3. ZCARD to count
        4. EXPIRE to auto-cleanup the key
        """
        r = await self._get_redis()
        if r is None:
            return 0  # fail open — allow if Redis is down

        rkey = self._make_key(key)
        cutoff = now - window_seconds
        member = f"{now}:{id(key)}"

        try:
            pipe = r.pipeline()
            pipe.zremrangebyscore(rkey, "-inf", cutoff)
            pipe.zadd(rkey, {member: now})
            pipe.zcard(rkey)
            pipe.expire(rkey, int(window_seconds) + 10)
            results = await pipe.execute()
            return results[2]  # ZCARD result
        except Exception as exc:
            logger.debug("Redis rate limit error: %s", exc)
            return 0  # fail open

    async def get_count(
        self, key: str, window_seconds: float, now: float
    ) -> int:
        """Return the current request count without recording."""
        r = await self._get_redis()
        if r is None:
            return 0

        rkey = self._make_key(key)
        cutoff = now - window_seconds

        try:
            pipe = r.pipeline()
            pipe.zremrangebyscore(rkey, "-inf", cutoff)
            pipe.zcard(rkey)
            results = await pipe.execute()
            return results[1]
        except Exception as exc:
            logger.debug("Redis rate limit count error: %s", exc)
            return 0

    async def close(self) -> None:
        """Close the Redis connection."""
        if self._redis is not None:
            await self._redis.close()
            self._redis = None
