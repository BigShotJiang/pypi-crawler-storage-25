"""
Sliding-window rate limiter for x402-fastapi-kit.

Limits requests per client identifier (IP, wallet address, or API key) using
a sliding window algorithm. Ships with an in-memory backend; swap in Redis
or any async store by implementing ``RateLimitBackend``.

Usage::

    limiter = RateLimiter(requests_per_minute=60)

    result = await limiter.check("client-id", route="/weather")
    if not result.allowed:
        return 429  # Too Many Requests
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from collections import defaultdict
from dataclasses import dataclass
from threading import Lock


@dataclass(frozen=True)
class RateLimitResult:
    """Result of a rate limit check."""

    allowed: bool
    limit: int
    remaining: int
    reset_at: float  # Unix timestamp when the window resets
    retry_after: float | None = None  # Seconds until next allowed request

    def headers(self) -> dict[str, str]:
        """Standard rate-limit response headers."""
        h = {
            "X-RateLimit-Limit": str(self.limit),
            "X-RateLimit-Remaining": str(max(0, self.remaining)),
            "X-RateLimit-Reset": str(int(self.reset_at)),
        }
        if self.retry_after is not None:
            h["Retry-After"] = str(int(self.retry_after) + 1)
        return h


# ── Backend interface ─────────────────────────────────────────────────────────

class RateLimitBackend(ABC):
    """Abstract backend for rate limit state storage."""

    @abstractmethod
    async def record_and_count(
        self, key: str, window_seconds: float, now: float
    ) -> int:
        """
        Record a new request and return the count of requests in the
        current sliding window.
        """
        ...

    @abstractmethod
    async def get_count(self, key: str, window_seconds: float, now: float) -> int:
        """Return the current request count without recording."""
        ...


# ── In-memory backend ─────────────────────────────────────────────────────────

class InMemoryBackend(RateLimitBackend):
    """
    Thread-safe in-memory sliding window backend.

    Stores request timestamps per key, pruning expired entries on access.
    Suitable for single-process deployments; use Redis for multi-process.
    """

    def __init__(self) -> None:
        self._store: dict[str, list[float]] = defaultdict(list)
        self._lock = Lock()

    def _prune(self, key: str, cutoff: float) -> list[float]:
        """Remove timestamps older than cutoff and return remaining."""
        entries = self._store[key]
        pruned = [t for t in entries if t > cutoff]
        self._store[key] = pruned
        return pruned

    async def record_and_count(
        self, key: str, window_seconds: float, now: float
    ) -> int:
        with self._lock:
            cutoff = now - window_seconds
            current = self._prune(key, cutoff)
            current.append(now)
            return len(current)

    async def get_count(self, key: str, window_seconds: float, now: float) -> int:
        with self._lock:
            cutoff = now - window_seconds
            return len(self._prune(key, cutoff))

    def clear(self) -> None:
        """Reset all stored state (useful for testing)."""
        with self._lock:
            self._store.clear()


# ── Rate limiter ──────────────────────────────────────────────────────────────

@dataclass
class RateLimitRule:
    """A rate limit rule that can be global or per-route."""

    requests_per_minute: int
    route_pattern: str | None = None  # None = global, or "/path" for per-route

    @property
    def window_seconds(self) -> float:
        return 60.0


class RateLimiter:
    """
    Sliding-window rate limiter.

    Args:
        requests_per_minute: Global default limit.
        route_limits: Optional dict mapping route paths to per-route limits.
        backend: Storage backend (defaults to in-memory).

    Example::

        limiter = RateLimiter(
            requests_per_minute=60,
            route_limits={"/expensive": 10},
        )
    """

    def __init__(
        self,
        requests_per_minute: int = 60,
        route_limits: dict[str, int] | None = None,
        backend: RateLimitBackend | None = None,
    ) -> None:
        self.default_rpm = requests_per_minute
        self.route_limits = route_limits or {}
        self.backend = backend or InMemoryBackend()

    def _get_limit(self, route: str | None) -> int:
        """Resolve the effective limit for a route."""
        if route and route in self.route_limits:
            return self.route_limits[route]
        return self.default_rpm

    def _make_key(self, client_id: str, route: str | None) -> str:
        """Build the storage key."""
        if route:
            return f"rl:{client_id}:{route}"
        return f"rl:{client_id}:*"

    async def check(
        self,
        client_id: str,
        route: str | None = None,
        *,
        record: bool = True,
    ) -> RateLimitResult:
        """
        Check (and optionally record) a request against the rate limit.

        Args:
            client_id: Identifier for the client (IP, wallet, API key).
            route: Optional route path for per-route limits.
            record: If True, record this request in the window.

        Returns:
            RateLimitResult with allowed/remaining/headers.
        """
        now = time.time()
        limit = self._get_limit(route)
        window = 60.0
        key = self._make_key(client_id, route)

        if record:
            count = await self.backend.record_and_count(key, window, now)
        else:
            count = await self.backend.get_count(key, window, now)

        allowed = count <= limit
        remaining = max(0, limit - count)
        reset_at = now + window

        retry_after = None
        if not allowed:
            retry_after = window  # worst case; could be smarter with oldest timestamp

        return RateLimitResult(
            allowed=allowed,
            limit=limit,
            remaining=remaining,
            reset_at=reset_at,
            retry_after=retry_after,
        )
