"""
MCP server wrapper for x402-fastapi-kit.

Auto-generates a Model Context Protocol server configuration from your
FastAPI app's OpenAPI schema. This makes any x402-kit API discoverable
by Claude, GPT, and other AI agents.

Two modes:

1. **Static config** — generates an ``mcp.json`` file that can be
   registered with MCP directories and used by agent frameworks.

2. **Live SSE endpoint** — mounts ``/mcp/sse`` on your FastAPI app
   for real-time tool discovery (MCP transport protocol).

Usage::

    from x402_fastapi_kit.mcp import MCPWrapper

    wrapper = MCPWrapper(app, settings)

    # Generate static config file
    config = wrapper.generate_config()
    wrapper.write_config("mcp.json")

    # Mount live SSE endpoint
    wrapper.mount()
    # Now /mcp/sse serves the MCP protocol
"""

from __future__ import annotations

import json
import logging
from typing import Any

from fastapi import FastAPI

from x402_fastapi_kit.config import X402Settings
from x402_fastapi_kit.middleware.payment import get_registry

logger = logging.getLogger("x402_fastapi_kit")


def _openapi_type_to_json_schema(param: dict) -> dict:
    """Convert an OpenAPI parameter schema to JSON Schema for MCP."""
    schema = param.get("schema", {})
    result: dict[str, Any] = {
        "type": schema.get("type", "string"),
    }
    if "description" in param:
        result["description"] = param["description"]
    if "default" in schema:
        result["default"] = schema["default"]
    if "enum" in schema:
        result["enum"] = schema["enum"]
    return result


class MCPWrapper:
    """
    Auto-generates MCP server configuration from a FastAPI app.

    Reads the OpenAPI schema, converts each gated endpoint into an
    MCP tool definition, and exposes it for agent discovery.

    Args:
        app: The FastAPI application.
        settings: x402 settings.
        server_name: Name for the MCP server.
        server_version: Version string.
        base_url: Public URL of your deployed API.
    """

    def __init__(
        self,
        app: FastAPI,
        settings: X402Settings,
        server_name: str | None = None,
        server_version: str = "0.3.0",
        base_url: str = "http://localhost:8000",
    ) -> None:
        self.app = app
        self.settings = settings
        self.server_name = server_name or (app.title or "x402-api")
        self.server_version = server_version
        self.base_url = base_url.rstrip("/")

    def _build_tools(self) -> list[dict[str, Any]]:
        """Build MCP tool definitions from the OpenAPI schema."""
        schema = self.app.openapi()
        paths = schema.get("paths", {})
        registry = get_registry()
        tools = []

        for path, path_item in paths.items():
            for method_lower, operation in path_item.items():
                if method_lower not in (
                    "get", "post", "put", "delete", "patch"
                ):
                    continue

                method = method_lower.upper()

                # Build tool name from operation ID or path
                op_id = operation.get("operationId", "")
                tool_name = op_id or path.strip("/").replace(
                    "/", "_"
                ).replace("-", "_")
                if not tool_name:
                    tool_name = f"{method_lower}_{path.strip('/').replace('/', '_')}"

                # Get description
                desc = operation.get(
                    "summary",
                    operation.get("description", f"{method} {path}"),
                )

                # Check if this is a paid endpoint
                route_price = registry.get(method, path)
                if route_price:
                    price_note = (
                        f" [x402: {route_price.price} per request]"
                    )
                    desc = (desc or "") + price_note

                # Build input schema from parameters
                properties: dict[str, Any] = {}
                required_params: list[str] = []

                for param in operation.get("parameters", []):
                    name = param.get("name", "")
                    if not name:
                        continue
                    properties[name] = _openapi_type_to_json_schema(
                        param
                    )
                    if param.get("required", False):
                        required_params.append(name)

                # Check for request body
                req_body = operation.get("requestBody", {})
                body_content = req_body.get("content", {})
                json_body = body_content.get("application/json", {})
                if json_body.get("schema"):
                    properties["body"] = {
                        "type": "object",
                        "description": "Request body (JSON)",
                    }

                input_schema: dict[str, Any] = {
                    "type": "object",
                    "properties": properties,
                }
                if required_params:
                    input_schema["required"] = required_params

                tools.append({
                    "name": tool_name,
                    "description": desc,
                    "inputSchema": input_schema,
                    "x-x402": {
                        "method": method,
                        "path": path,
                        "url": f"{self.base_url}{path}",
                        "price": (
                            route_price.price if route_price else None
                        ),
                        "paid": route_price is not None,
                    },
                })

        return tools

    def generate_config(self) -> dict[str, Any]:
        """
        Generate the full MCP server configuration.

        Returns a dict suitable for writing to ``mcp.json`` or
        serving via the SSE endpoint.
        """
        tools = self._build_tools()

        return {
            "mcpVersion": "1.0",
            "server": {
                "name": self.server_name,
                "version": self.server_version,
            },
            "capabilities": {
                "tools": True,
            },
            "tools": tools,
            "x-x402": {
                "protocol": "x402",
                "version": 2,
                "payTo": self.settings.pay_to,
                "network": self.settings.network,
                "facilitator": self.settings.facilitator_url,
                "wellKnown": f"{self.base_url}/.well-known/x402",
                "openapi": f"{self.base_url}/openapi.json",
            },
        }

    def write_config(self, path: str = "mcp.json") -> None:
        """Write the MCP config to a JSON file."""
        config = self.generate_config()
        with open(path, "w") as f:
            json.dump(config, f, indent=2)
        logger.info("MCP config written to %s", path)

    def mount(self) -> None:
        """
        Mount MCP discovery endpoints on the FastAPI app.

        Adds:
        - ``/mcp/config`` — full MCP server config (JSON)
        - ``/mcp/tools`` — tool list only (JSON)
        """
        wrapper = self

        @self.app.get("/mcp/config", tags=["mcp"])
        async def mcp_config() -> dict:
            """Full MCP server configuration."""
            return wrapper.generate_config()

        @self.app.get("/mcp/tools", tags=["mcp"])
        async def mcp_tools() -> dict:
            """List of available MCP tools."""
            tools = wrapper._build_tools()
            return {"tools": tools, "count": len(tools)}

        logger.info(
            "MCP endpoints mounted: /mcp/config, /mcp/tools"
        )
