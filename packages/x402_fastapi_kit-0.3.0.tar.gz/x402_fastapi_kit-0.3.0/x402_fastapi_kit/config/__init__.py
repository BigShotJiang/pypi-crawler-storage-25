"""
Centralised configuration for x402-fastapi-kit.

All values can be set via environment variables (prefixed X402_) or a .env file.
"""

from __future__ import annotations

from enum import Enum

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Network(str, Enum):
    """Supported blockchain networks."""

    BASE_SEPOLIA = "eip155:84532"
    BASE_MAINNET = "eip155:8453"
    ETHEREUM_MAINNET = "eip155:1"
    POLYGON_MAINNET = "eip155:137"
    SOLANA_DEVNET = "solana:EtWTRABZaYq6iMfeYKouRu166VU2xqa1"
    SOLANA_MAINNET = "solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp"


# Well-known facilitator URLs
FACILITATORS = {
    "testnet": "https://x402.org/facilitator",
    "coinbase": "https://x402.org/facilitator",
    "cdp": "https://api.developer.coinbase.com/x402/facilitator",
}


class X402Settings(BaseSettings):
    """
    Core x402 configuration.

    Set these via environment variables (prefix ``X402_``) or a ``.env`` file::

        X402_PAY_TO=0xYourAddress
        X402_NETWORK=eip155:84532
        X402_FACILITATOR_URL=https://x402.org/facilitator
        X402_DEFAULT_PRICE=$0.01
    """

    model_config = SettingsConfigDict(
        env_prefix="X402_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ── Wallet & Network ──────────────────────────────────────────────
    pay_to: str = Field(
        ...,
        description="Wallet address that receives payments (EVM hex or Solana base58).",
    )
    network: str = Field(
        default=Network.BASE_SEPOLIA.value,
        description="CAIP-2 network identifier.",
    )
    scheme: str = Field(
        default="exact",
        description="Payment scheme (exact, upto, …).",
    )

    # ── Facilitator ───────────────────────────────────────────────────
    facilitator_url: str = Field(
        default=FACILITATORS["testnet"],
        description="URL of the x402 facilitator service.",
    )

    # ── Defaults ──────────────────────────────────────────────────────
    default_price: str = Field(
        default="$0.01",
        description="Default price for gated routes (e.g. '$0.01', '$1.00').",
    )
    default_description: str = Field(
        default="Paid API endpoint",
        description="Default description surfaced in 402 responses.",
    )
    max_timeout_seconds: int = Field(
        default=300,
        description="Maximum payment timeout in seconds.",
    )

    # ── Server ────────────────────────────────────────────────────────
    host: str = Field(default="0.0.0.0", description="Uvicorn bind host.")
    port: int = Field(default=8000, description="Uvicorn bind port.")
    debug: bool = Field(default=False, description="Enable debug mode.")

    # ── Rate Limiting (Phase 2) ────────────────────────────────────────
    rate_limit_enabled: bool = Field(
        default=True,
        description="Enable request rate limiting.",
    )
    rate_limit_rpm: int = Field(
        default=60,
        description="Default requests per minute per client.",
    )
    rate_limit_routes: str = Field(
        default="",
        description="Per-route limits as 'path=rpm,path=rpm' (e.g. '/weather=30,/forecast=10').",
    )

    # ── API Key Auth (Phase 2) ─────────────────────────────────────────
    api_keys_enabled: bool = Field(
        default=False,
        description="Enable API key fallback authentication.",
    )
    api_keys: str = Field(
        default="",
        description=(
            "API keys as 'name=secret,name=secret'"
            " (e.g. 'partner1=sk_abc,internal=sk_xyz')."
        ),
    )

    # ── Wallet Allowlist (Phase 2) ─────────────────────────────────────
    allowlist_enabled: bool = Field(
        default=False,
        description="Enable wallet allowlist bypass.",
    )
    allowlist_addresses: str = Field(
        default="",
        description="Comma-separated wallet addresses to allowlist.",
    )

    # ── Optional CDP credentials (mainnet) ────────────────────────────
    cdp_api_key_id: str | None = Field(default=None)
    cdp_api_key_secret: str | None = Field(default=None)

    # ── Solana pay_to (optional second address) ───────────────────────
    svm_pay_to: str | None = Field(
        default=None,
        description="Solana wallet address (if accepting SVM payments alongside EVM).",
    )

    @field_validator("pay_to")
    @classmethod
    def validate_pay_to(cls, v: str) -> str:
        v = v.strip()
        if v.startswith("0x"):
            if len(v) != 42:
                raise ValueError(f"EVM address must be 42 chars (got {len(v)}): {v}")
        elif len(v) < 32 or len(v) > 44:
            raise ValueError(f"Solana address must be 32-44 chars (got {len(v)}): {v}")
        return v

    @property
    def is_testnet(self) -> bool:
        testnet_ids = {"84532", "EtWTRABZaYq6iMfeYKouRu166VU2xqa1"}
        return any(tid in self.network for tid in testnet_ids)

    @property
    def is_evm(self) -> bool:
        return self.network.startswith("eip155:")

    @property
    def is_svm(self) -> bool:
        return self.network.startswith("solana:")

    def parse_rate_limit_routes(self) -> dict[str, int]:
        """Parse 'rate_limit_routes' into {path: rpm} dict."""
        if not self.rate_limit_routes.strip():
            return {}
        result = {}
        for pair in self.rate_limit_routes.split(","):
            pair = pair.strip()
            if "=" in pair:
                path, rpm = pair.rsplit("=", 1)
                result[path.strip()] = int(rpm.strip())
        return result

    def parse_api_keys(self) -> dict[str, str]:
        """Parse 'api_keys' into {name: secret} dict."""
        if not self.api_keys.strip():
            return {}
        result = {}
        for pair in self.api_keys.split(","):
            pair = pair.strip()
            if "=" in pair:
                name, secret = pair.split("=", 1)
                result[name.strip()] = secret.strip()
        return result

    def parse_allowlist(self) -> list[str]:
        """Parse 'allowlist_addresses' into a list of addresses."""
        if not self.allowlist_addresses.strip():
            return []
        return [a.strip() for a in self.allowlist_addresses.split(",") if a.strip()]
