"""Re-export for convenience."""
from x402_fastapi_kit.config import X402Settings

__all__ = ["X402Settings"]
