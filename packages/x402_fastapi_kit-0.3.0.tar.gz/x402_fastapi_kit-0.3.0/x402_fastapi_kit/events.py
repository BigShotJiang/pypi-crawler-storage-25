"""
Event hooks for x402-fastapi-kit.

Provides an observable callback system for payment lifecycle events.
Register handlers to get notified when payments are verified, rejected,
or when routes are gated. Useful for logging, analytics, alerting, and
custom business logic.

Usage::

    from x402_fastapi_kit.events import EventBus, PaymentEvent

    bus = EventBus()

    @bus.on("payment.verified")
    async def log_payment(event: PaymentEvent):
        print(f"Paid! {event.route} by {event.client_id} — tx: {event.tx_hash}")

    @bus.on("payment.rejected")
    async def alert_rejected(event: PaymentEvent):
        send_alert(f"Rejected payment on {event.route}: {event.reason}")

    @bus.on("request.gated")
    async def count_gates(event: PaymentEvent):
        metrics.incr(f"402_responses.{event.route}")

    @bus.on("auth.api_key")
    async def log_api_key_access(event: PaymentEvent):
        print(f"API key access: {event.client_id} → {event.route}")
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger("x402_fastapi_kit")


class EventType(str, Enum):
    """Payment lifecycle event types."""

    PAYMENT_VERIFIED = "payment.verified"
    PAYMENT_REJECTED = "payment.rejected"
    REQUEST_GATED = "request.gated"       # 402 returned (no payment header)
    AUTH_API_KEY = "auth.api_key"          # Bypassed via API key
    AUTH_ALLOWLIST = "auth.allowlist"      # Bypassed via wallet allowlist
    RATE_LIMITED = "rate.limited"          # 429 returned
    FACILITATOR_ERROR = "facilitator.error"


@dataclass
class PaymentEvent:
    """Payload for a payment lifecycle event."""

    event_type: EventType
    route: str
    method: str
    client_id: str | None = None      # IP, wallet, or API key name
    price: str | None = None
    tx_hash: str | None = None
    reason: str | None = None         # Rejection/error reason
    verification: dict | None = None  # Full facilitator response
    timestamp: float = field(default_factory=time.time)
    extra: dict[str, Any] = field(default_factory=dict)


# Type alias for event handlers
EventHandler = Callable[[PaymentEvent], Any]


class EventBus:
    """
    Pub/sub event bus for payment lifecycle events.

    Handlers can be sync or async. Errors in handlers are logged but never
    propagate to the request — the payment flow is never disrupted by
    observer failures.

    Usage::

        bus = EventBus()

        # Decorator style
        @bus.on("payment.verified")
        async def handler(event):
            ...

        # Imperative style
        bus.subscribe("payment.rejected", my_handler)

        # Emit (called internally by the middleware)
        await bus.emit(PaymentEvent(...))
    """

    def __init__(self) -> None:
        self._handlers: dict[str, list[EventHandler]] = defaultdict(list)
        self._wildcard_handlers: list[EventHandler] = []

    def subscribe(self, event_type: str | EventType, handler: EventHandler) -> None:
        """Register a handler for a specific event type."""
        key = event_type.value if isinstance(event_type, EventType) else event_type
        self._handlers[key].append(handler)

    def on(self, event_type: str | EventType) -> Callable:
        """
        Decorator to register an event handler.

        Example::

            @bus.on("payment.verified")
            async def handle(event: PaymentEvent):
                ...
        """
        def decorator(func: EventHandler) -> EventHandler:
            self.subscribe(event_type, func)
            return func
        return decorator

    def on_all(self, handler: EventHandler) -> None:
        """Register a handler that receives ALL events (wildcard)."""
        self._wildcard_handlers.append(handler)

    def unsubscribe(self, event_type: str | EventType, handler: EventHandler) -> bool:
        """Remove a handler. Returns True if found."""
        key = event_type.value if isinstance(event_type, EventType) else event_type
        handlers = self._handlers.get(key, [])
        if handler in handlers:
            handlers.remove(handler)
            return True
        return False

    async def emit(self, event: PaymentEvent) -> None:
        """
        Emit an event to all registered handlers.

        Handlers run concurrently. Errors are caught and logged — they never
        disrupt the payment flow.
        """
        key = (
            event.event_type.value
            if isinstance(event.event_type, EventType)
            else event.event_type
        )
        handlers = list(self._handlers.get(key, [])) + list(self._wildcard_handlers)

        if not handlers:
            return

        tasks = []
        for handler in handlers:
            try:
                result = handler(event)
                if asyncio.iscoroutine(result):
                    tasks.append(result)
            except Exception:
                logger.exception("Sync event handler error for %s", key)

        if tasks:
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for r in results:
                if isinstance(r, Exception):
                    logger.exception("Async event handler error for %s: %s", key, r)

    @property
    def handler_count(self) -> int:
        """Total number of registered handlers."""
        total = sum(len(h) for h in self._handlers.values())
        return total + len(self._wildcard_handlers)

    def clear(self) -> None:
        """Remove all handlers."""
        self._handlers.clear()
        self._wildcard_handlers.clear()
