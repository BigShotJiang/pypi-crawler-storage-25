"""
Service discovery for x402-fastapi-kit.

Three mechanisms for making your service findable:

1. **`/.well-known/x402`** — Static JSON manifest describing your service,
   payment options, and available endpoints. AI agents and crawlers use this
   to discover what you offer and how to pay.

2. **Bazaar registration** — Registers your service with the x402 Bazaar
   discovery layer so it appears in the global service directory.

3. **OpenAPI enrichment** — Injects x402 payment metadata into your
   FastAPI OpenAPI schema so tools can read pricing from ``/openapi.json``.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

import httpx
from fastapi import FastAPI

from x402_fastapi_kit.config import X402Settings
from x402_fastapi_kit.middleware.payment import get_registry

logger = logging.getLogger("x402_fastapi_kit")


# ── .well-known/x402 manifest ────────────────────────────────────────────────

@dataclass
class ServiceManifest:
    """
    Describes your x402 service for agent/crawler discovery.

    Served at ``/.well-known/x402`` by default.
    """

    name: str = "x402-fastapi-kit Service"
    description: str = "A payment-gated API"
    version: str = "0.3.0"
    homepage: str | None = None
    contact: str | None = None
    tags: list[str] = field(default_factory=list)

    def build(self, settings: X402Settings) -> dict[str, Any]:
        """Build the manifest JSON from settings + route registry."""
        registry = get_registry()

        endpoints = []
        for key, rp in registry.all().items():
            method, path = key.split(" ", 1)
            endpoints.append({
                "method": method,
                "path": path,
                "price": rp.price,
                "description": rp.description or settings.default_description,
                "scheme": rp.scheme or settings.scheme,
                "network": rp.network or settings.network,
            })

        manifest: dict[str, Any] = {
            "x402Version": 2,
            "service": {
                "name": self.name,
                "description": self.description,
                "version": self.version,
            },
            "payment": {
                "payTo": settings.pay_to,
                "network": settings.network,
                "scheme": settings.scheme,
                "facilitator": settings.facilitator_url,
            },
            "endpoints": endpoints,
        }

        if self.homepage:
            manifest["service"]["homepage"] = self.homepage
        if self.contact:
            manifest["service"]["contact"] = self.contact
        if self.tags:
            manifest["service"]["tags"] = self.tags

        if settings.svm_pay_to:
            manifest["payment"]["svmPayTo"] = settings.svm_pay_to

        return manifest


def register_well_known(
    app: FastAPI,
    settings: X402Settings,
    manifest: ServiceManifest | None = None,
) -> None:
    """
    Add ``/.well-known/x402`` endpoint to a FastAPI app.

    Called automatically by ``PaymentApp`` when a manifest is provided.
    """
    _manifest = manifest or ServiceManifest()

    @app.get("/.well-known/x402", tags=["x402"], include_in_schema=True)
    async def well_known_x402() -> dict:
        return _manifest.build(settings)


# ── Bazaar registration ──────────────────────────────────────────────────────

BAZAAR_URL = "https://x402.org/bazaar"


async def register_with_bazaar(
    service_url: str,
    settings: X402Settings,
    manifest: ServiceManifest | None = None,
    bazaar_url: str = BAZAAR_URL,
) -> dict[str, Any]:
    """
    Register your service with the x402 Bazaar discovery layer.

    Args:
        service_url: The public URL of your service (e.g. "https://api.example.com").
        settings: Your x402 settings.
        manifest: Optional service manifest (builds one from settings if omitted).
        bazaar_url: Bazaar API endpoint.

    Returns:
        Registration response from Bazaar.

    Example::

        result = await register_with_bazaar(
            "https://weather.example.com",
            settings,
            ServiceManifest(name="Weather API", tags=["weather", "data"]),
        )
    """
    m = manifest or ServiceManifest()
    payload = m.build(settings)
    payload["service"]["url"] = service_url

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            f"{bazaar_url.rstrip('/')}/register",
            json=payload,
        )
        resp.raise_for_status()
        result = resp.json()

    logger.info("Registered with Bazaar: %s → %s", service_url, result)
    return result


# ── OpenAPI enrichment ────────────────────────────────────────────────────────

def enrich_openapi(app: FastAPI, settings: X402Settings) -> None:
    """
    Inject x402 payment metadata into the OpenAPI schema.

    After calling this, each gated endpoint in ``/openapi.json`` will include
    an ``x-x402`` extension with pricing and payment details. This allows
    agent frameworks and API tools to read payment info programmatically.
    """
    registry = get_registry()
    original_schema = app.openapi

    def custom_openapi() -> dict:
        schema = original_schema()

        for key, rp in registry.all().items():
            method, path = key.split(" ", 1)
            method_lower = method.lower()

            path_item = schema.get("paths", {}).get(path, {})
            operation = path_item.get(method_lower, {})

            if operation:
                operation["x-x402"] = {
                    "price": rp.price,
                    "scheme": rp.scheme or settings.scheme,
                    "network": rp.network or settings.network,
                    "payTo": rp.pay_to or settings.pay_to,
                    "description": rp.description or settings.default_description,
                }

                # Add 402 response to the operation
                if "responses" not in operation:
                    operation["responses"] = {}
                operation["responses"]["402"] = {
                    "description": "Payment Required — "
                    "submit X-PAYMENT header with signed payment payload",
                }

        # Add x402 info to the top-level schema
        schema["info"]["x-x402"] = {
            "version": 2,
            "payTo": settings.pay_to,
            "network": settings.network,
            "facilitator": settings.facilitator_url,
        }

        return schema

    app.openapi = custom_openapi  # type: ignore[assignment]
