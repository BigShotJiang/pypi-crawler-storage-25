"""
PaymentApp — batteries-included FastAPI subclass for x402 services.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import FastAPI

from x402_fastapi_kit.analytics import AnalyticsCollector
from x402_fastapi_kit.auth import APIKeyManager, WalletAllowlist
from x402_fastapi_kit.config import X402Settings
from x402_fastapi_kit.discovery import (
    ServiceManifest,
    enrich_openapi,
    register_well_known,
)
from x402_fastapi_kit.events import EventBus
from x402_fastapi_kit.middleware.payment import PaymentGate, get_registry
from x402_fastapi_kit.middleware.rate_limit import RateLimiter

logger = logging.getLogger("x402_fastapi_kit")


class PaymentApp(FastAPI):
    """
    FastAPI application pre-configured with the full x402-fastapi-kit stack.

    Phases 1–3:
    - Payment middleware with 4-step pipeline
    - API key auth, wallet allowlist, rate limiting, event hooks
    - Service discovery (.well-known/x402), OpenAPI enrichment, analytics
    """

    def __init__(
        self,
        settings: X402Settings | None = None,
        *,
        event_bus: EventBus | None = None,
        api_key_manager: APIKeyManager | None = None,
        wallet_allowlist: WalletAllowlist | None = None,
        rate_limiter: RateLimiter | None = None,
        manifest: ServiceManifest | None = None,
        analytics: bool = True,
        **kwargs: Any,
    ) -> None:
        self._x402_settings = settings
        self._event_bus = event_bus or EventBus()
        self._api_key_manager = api_key_manager
        self._wallet_allowlist = wallet_allowlist
        self._rate_limiter = rate_limiter
        self._manifest = manifest
        self._analytics_enabled = analytics
        self._analytics_collector: AnalyticsCollector | None = None

        kwargs.setdefault("title", "x402-fastapi-kit Service")
        super().__init__(**kwargs)

        # Introspection endpoints (Phase 1)
        self._register_introspection()

        # Discovery (Phase 3)
        if self._manifest is not None:
            register_well_known(self, self.x402_settings, self._manifest)

        # Analytics (Phase 3)
        if self._analytics_enabled:
            self._analytics_collector = AnalyticsCollector(self._event_bus)
            self._analytics_collector.mount(self, self.x402_settings)

        # Payment middleware (must be added last — Starlette wraps in reverse)
        self.add_middleware(
            PaymentGate,
            settings=self.x402_settings,
            owner_app=self,
            event_bus=self._event_bus,
            api_key_manager=self._api_key_manager,
            wallet_allowlist=self._wallet_allowlist,
            rate_limiter=self._rate_limiter,
        )

    @property
    def x402_settings(self) -> X402Settings:
        if self._x402_settings is None:
            self._x402_settings = X402Settings()
        return self._x402_settings

    @property
    def event_bus(self) -> EventBus:
        return self._event_bus

    @property
    def analytics(self) -> AnalyticsCollector | None:
        return self._analytics_collector

    def enrich_openapi_schema(self) -> None:
        """Inject x402 metadata into the OpenAPI schema."""
        enrich_openapi(self, self.x402_settings)

    def _register_introspection(self) -> None:
        settings_ref = self

        @self.get("/x402/health", tags=["x402"], include_in_schema=True)
        async def x402_health() -> dict:
            s = settings_ref.x402_settings
            registry = get_registry()
            return {
                "status": "ok",
                "version": "0.3.0",
                "network": s.network,
                "is_testnet": s.is_testnet,
                "facilitator": s.facilitator_url,
                "gated_routes": len(registry),
                "rate_limit_enabled": s.rate_limit_enabled,
                "api_keys_enabled": s.api_keys_enabled,
                "allowlist_enabled": s.allowlist_enabled,
                "analytics_enabled": settings_ref._analytics_enabled,
                "manifest_enabled": settings_ref._manifest is not None,
            }

        @self.get("/x402/routes", tags=["x402"], include_in_schema=True)
        async def x402_routes() -> dict:
            s = settings_ref.x402_settings
            registry = get_registry()
            routes = {}
            for key, rp in registry.all().items():
                routes[key] = {
                    "price": rp.price,
                    "description": rp.description or s.default_description,
                    "network": rp.network or s.network,
                    "scheme": rp.scheme or s.scheme,
                }
            return {"routes": routes}
