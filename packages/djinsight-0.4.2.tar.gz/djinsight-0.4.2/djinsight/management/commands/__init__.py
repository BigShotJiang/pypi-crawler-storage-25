# djinsight management commands
