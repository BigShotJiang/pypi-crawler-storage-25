# License

```{include} ../LICENSE
```
