"""A client to the LimeSurvey Remote Control API 2, written in modern Python."""

from __future__ import annotations

from importlib import metadata

from citric import objects
from citric.client import Client
from citric.rest import RESTClient

__version__: str = metadata.version("citric")
"""Package version"""

del annotations, metadata  # noqa: RUF067

__all__ = ["Client", "RESTClient", "objects"]
