"""
Entry point for: python3 -m supero.cli
"""

if __name__ == "__main__":
    from supero.cli.run import main
    main()
