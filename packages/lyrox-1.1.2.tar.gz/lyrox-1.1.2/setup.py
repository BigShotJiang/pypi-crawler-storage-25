from setuptools import setup

setup(
    name="Lyrox",
    version="1.1.2",
    py_modules=["Lyrox"],
    install_requires=["base91"],
    author="Lyrox",
    description="Telegram; @LyroxPy",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)