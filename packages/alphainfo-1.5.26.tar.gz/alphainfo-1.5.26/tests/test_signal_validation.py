"""
Tests for `_validate_signal_quality` — the client-side signal validator
that catches common pitfalls before the round-trip and points the user
at the right recipe.

These tests exercise the validator directly (not behind the HTTP shim)
because we want to assert on the error / warning messages exactly.
"""

from __future__ import annotations

import pytest

from alphainfo.client import _validate_signal_quality
from alphainfo.exceptions import ValidationError

# ---------------------------------------------------------------------------
# Hard errors
# ---------------------------------------------------------------------------


class TestHardErrors:
    def test_none_is_rejected(self):
        with pytest.raises(ValidationError, match="None"):
            _validate_signal_quality(None)

    def test_non_iterable_is_rejected(self):
        with pytest.raises(ValidationError, match="sequence"):
            _validate_signal_quality(42)

    def test_bytes_is_rejected_with_recipe_pointer(self):
        with pytest.raises(ValidationError, match="bytes|encoding_guide"):
            _validate_signal_quality(b"\x01\x02\x03\x04")

    def test_bytearray_is_rejected(self):
        with pytest.raises(ValidationError, match="bytearray"):
            _validate_signal_quality(bytearray([1, 2, 3, 4]))

    def test_empty_signal_is_rejected(self):
        with pytest.raises(ValidationError, match="empty"):
            _validate_signal_quality([])

    def test_non_numeric_is_rejected(self):
        with pytest.raises(ValidationError, match="non-numeric"):
            _validate_signal_quality([1.0, 2.0, "three", 4.0])

    def test_all_nan_is_rejected(self):
        bad = [float("nan")] * 100
        with pytest.raises(ValidationError, match="all NaN"):
            _validate_signal_quality(bad)

    def test_all_inf_is_rejected(self):
        bad = [float("inf")] * 100
        with pytest.raises(ValidationError, match="all NaN"):  # Inf rolls into NaN bucket
            _validate_signal_quality(bad)


# ---------------------------------------------------------------------------
# Soft warnings (don't raise, but point at a recipe)
# ---------------------------------------------------------------------------


class TestSoftWarnings:
    def test_constant_signal_warns_not_errors(self):
        with pytest.warns(UserWarning, match="constant"):
            _validate_signal_quality([1.0] * 100)

    def test_very_short_signal_warns(self):
        with pytest.warns(UserWarning, match="32 samples"):
            _validate_signal_quality([0.1, 0.2, 0.3, 0.4, 0.5,
                                       0.6, 0.7, 0.8, 0.9, 1.0,
                                       1.1, 1.2])

    def test_some_nan_is_hard_error_now(self):
        # Partial NaN used to be a UserWarning, but JSON can't serialise
        # NaN/Inf so the call would fail downstream with a cryptic
        # ValueError. Now it's a hard ValidationError with a recipe
        # pointer + a one-line fix in the message.
        signal = [float("nan")] * 5 + [0.1 * i for i in range(50)]
        with pytest.raises(ValidationError, match="NaN/Inf"):
            _validate_signal_quality(signal)

    def test_some_inf_is_hard_error(self):
        signal = [float("inf"), -1.0, -0.5, 0.0, 0.5, 1.0] + [0.1] * 50
        with pytest.raises(ValidationError, match="NaN/Inf"):
            _validate_signal_quality(signal)

    def test_categorical_like_warns(self):
        # 100 samples, only 3 unique values — looks like an event sequence
        signal = [0.0] * 40 + [1.0] * 30 + [2.0] * 30
        with pytest.warns(UserWarning, match="categorical"):
            _validate_signal_quality(signal)


# ---------------------------------------------------------------------------
# Healthy signals — no warnings, no errors
# ---------------------------------------------------------------------------


class TestHealthySignals:
    def test_realistic_returns_silent(self):
        """A realistic 500-sample Gaussian-returns signal should pass
        validation with no warnings or errors."""
        import random
        import warnings as warnings_mod
        rng = random.Random(42)
        signal = [rng.gauss(0, 0.01) for _ in range(500)]
        with warnings_mod.catch_warnings(record=True) as record:
            warnings_mod.simplefilter("always")
            _validate_signal_quality(signal)
        # Filter for the validator's own warnings — anything mentioning
        # one of our recipe pointers is suspicious here.
        suspect = [w for w in record
                   if "samples" in str(w.message).lower()
                   or "categorical" in str(w.message).lower()
                   or "constant" in str(w.message).lower()
                   or "NaN/Inf" in str(w.message)]
        assert suspect == [], (
            f"Healthy signal triggered validator warnings: "
            f"{[str(w.message) for w in suspect]}"
        )

    def test_skip_warnings_arg_silences_warnings(self):
        """When skip_warnings=True, even short / categorical signals pass
        without UserWarnings (used for baselines, where the signal-side
        warnings are louder anyway)."""
        import warnings as warnings_mod
        short_categorical = [0.0, 1.0, 0.0, 1.0, 0.0,
                              1.0, 0.0, 1.0, 0.0, 1.0,
                              0.0, 1.0]
        with warnings_mod.catch_warnings(record=True) as record:
            warnings_mod.simplefilter("always")
            _validate_signal_quality(short_categorical, skip_warnings=True)
        msgs = [str(w.message) for w in record]
        assert not any("samples" in m for m in msgs)
        assert not any("categorical" in m for m in msgs)


# ---------------------------------------------------------------------------
# Recipe pointers — check error / warning messages name the right recipe
# ---------------------------------------------------------------------------


class TestRecipePointers:
    def test_empty_message_points_to_event_grammar_or_encoding_guide(self):
        try:
            _validate_signal_quality([])
        except ValidationError as e:
            msg = str(e)
            # At least one recipe must be named in the error
            assert ("event_grammar" in msg
                    or "encoding_guide" in msg)

    def test_categorical_warning_points_to_event_grammar(self):
        signal = [0.0] * 40 + [1.0] * 30 + [2.0] * 30
        with pytest.warns(UserWarning) as record:
            _validate_signal_quality(signal)
        msgs = [str(w.message) for w in record]
        assert any("event_grammar" in m for m in msgs), (
            "categorical-like warning should point to recipes.event_grammar"
        )

    def test_constant_warning_points_to_recipe(self):
        with pytest.warns(UserWarning) as record:
            _validate_signal_quality([1.0] * 100)
        msgs = [str(w.message) for w in record]
        # Should mention either a recipe or a concrete fix
        assert any("event_grammar" in m or "varying baseline" in m
                   for m in msgs)


# ---------------------------------------------------------------------------
# Batch / matrix / vector payload-builder coverage — list[bytes] etc.
# ---------------------------------------------------------------------------


class TestPayloadBuilderValidation:
    """The fixes in 1.5.24 wire `_validate_signal_quality` into
    _build_batch_payload, _build_matrix_payload, _build_vector_payload —
    so the same hard-error contract applies to analyze_batch /
    analyze_matrix / analyze_vector, not just analyze."""

    def test_batch_rejects_list_of_bytes(self):
        from alphainfo.client import _build_batch_payload
        with pytest.raises(ValidationError, match="bytes|non-numeric"):
            _build_batch_payload(
                signals=[[b"\x01", b"\x02", b"\x03"] + [b"\xff"] * 50],
                sampling_rate=1.0, domain="generic",
                baselines=None, include_semantic=False, use_multiscale=True,
            )

    def test_batch_rejects_partial_nan(self):
        from alphainfo.client import _build_batch_payload
        good = [0.1 * i for i in range(50)]
        bad = [float("nan")] + [0.1 * i for i in range(49)]
        with pytest.raises(ValidationError, match="NaN/Inf"):
            _build_batch_payload(
                signals=[good, bad], sampling_rate=1.0, domain="generic",
                baselines=None, include_semantic=False, use_multiscale=True,
            )

    def test_matrix_rejects_partial_inf(self):
        from alphainfo.client import _build_matrix_payload
        good = [0.1 * i for i in range(50)]
        bad = [float("inf")] + [0.1 * i for i in range(49)]
        with pytest.raises(ValidationError, match="NaN/Inf"):
            _build_matrix_payload(
                signals=[good, bad], sampling_rate=1.0, domain="generic",
                use_multiscale=True,
            )

    def test_vector_rejects_dict_value(self):
        from alphainfo.client import _build_vector_payload
        with pytest.raises(ValidationError, match="non-numeric|sequence"):
            _build_vector_payload(
                channels={"ch1": [{"foo": 1}] + [0.5] * 50},
                sampling_rate=1.0, domain="generic",
                baselines=None, include_semantic=False, use_multiscale=True,
            )

    def test_vector_rejects_bytes_in_channel(self):
        from alphainfo.client import _build_vector_payload
        with pytest.raises(ValidationError, match="bytes|encoding_guide"):
            _build_vector_payload(
                channels={"ch1": b"\x01" * 50},
                sampling_rate=1.0, domain="generic",
                baselines=None, include_semantic=False, use_multiscale=True,
            )
