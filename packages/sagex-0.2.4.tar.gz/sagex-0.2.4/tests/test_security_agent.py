"""Phase 7 acceptance criteria: security agent pattern classifier and audit."""

from __future__ import annotations

from pathlib import Path

import pytest
from conftest import StubAnthropicClient

from sagex.agents.security_agent import (
    SECURITY_AGENT_SYSTEM,
    SecurityAgent,
    SecurityRisk,
    classify_security_risk,
)
from sagex.config import AgentConfig, BudgetConfig, SecurityAgentConfig
from sagex.event_bus import AgentEvent, EventType
from sagex.knowledge.rules_db import RulesDB
from sagex.llm.budget import BudgetManager
from sagex.llm.cache import ContentCache
from sagex.llm.token_tracker import TokenTracker

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def db(tmp_path: Path) -> RulesDB:
    return RulesDB(str(tmp_path / "rules.db"))


def _make_budget(
    db: RulesDB, responses: list[str] | None = None
) -> BudgetManager:
    default = (
        '{"severity":"critical","description":"AWS key",'
        '"file_path":"app.py","remediation":null}'
    )
    stub = StubAnthropicClient(responses=responses or [default])
    tracker = TokenTracker(db)
    cache = ContentCache(db, ttl_minutes=60)
    return BudgetManager(BudgetConfig(), tracker, cache, client=stub)


def _event(file_paths: list[str] | None = None) -> AgentEvent:
    return AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="test-proj",
        repo_root="/repo",
        file_paths=file_paths or ["app.py"],
    )


# ---------------------------------------------------------------------------
# classify_security_risk — pattern tests
# ---------------------------------------------------------------------------


def test_aws_secret_key_is_critical() -> None:
    """Diff with AWS_SECRET_ACCESS_KEY value → severity='critical'."""
    diff = '+AWS_SECRET_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE/wJalrXUtnFEMI"\n'
    risk = classify_security_risk(diff, "config.py")
    assert risk is not None
    assert risk.severity == "critical"
    assert risk.file_path == "config.py"


def test_hardcoded_password_is_critical() -> None:
    """password='...' literal → severity='critical'."""
    diff = "+password = 'supersecretpassword123'\n"
    risk = classify_security_risk(diff, "settings.py")
    assert risk is not None
    assert risk.severity == "critical"


def test_private_key_header_is_critical() -> None:
    """RSA private key header → severity='critical'."""
    diff = "+-----BEGIN RSA PRIVATE KEY-----\n"
    risk = classify_security_risk(diff, "key.pem")
    assert risk is not None
    assert risk.severity == "critical"


def test_debug_true_is_high() -> None:
    """debug=true → severity='high'."""
    diff = "+DEBUG = True\n"
    risk = classify_security_risk(diff, "settings.py")
    assert risk is not None
    assert risk.severity == "high"
    assert "Debug mode" in risk.description


def test_verify_false_is_high() -> None:
    """verify=false → severity='high'."""
    diff = "+verify = false\n"
    risk = classify_security_risk(diff, "client.py")
    assert risk is not None
    assert risk.severity == "high"


def test_http_non_local_is_medium() -> None:
    """Non-localhost http:// URL → severity='medium'."""
    diff = '+url = "http://example.com/api"\n'
    risk = classify_security_risk(diff, "api.py")
    assert risk is not None
    assert risk.severity == "medium"


def test_http_localhost_is_ignored() -> None:
    """http://localhost URL does not trigger the medium pattern."""
    diff = '+url = "http://localhost:8080/api"\n'
    risk = classify_security_risk(diff, "api.py")
    # could be None or lower severity — must NOT be flagged as medium http risk
    # (might still be None — that's the assertion)
    if risk is not None:
        # If matched something, it shouldn't be the http pattern for localhost
        assert "Non-HTTPS" not in risk.description


def test_clean_diff_returns_none() -> None:
    """A diff with no security issues → None."""
    diff = "+x = 1\n+def foo():\n+    return x\n"
    risk = classify_security_risk(diff, "main.py")
    assert risk is None


def test_removed_lines_are_not_flagged() -> None:
    """Removed lines (starting with '-') are not scanned."""
    diff = '-password = "old_secret_value_here"\n'
    risk = classify_security_risk(diff, "config.py")
    assert risk is None


def test_worst_severity_wins() -> None:
    """When multiple patterns match, the highest severity is returned."""
    diff = (
        '+DEBUG = True\n'
        '+AWS_SECRET_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE/wJalrXUtnFEMI"\n'
    )
    risk = classify_security_risk(diff, "config.py")
    assert risk is not None
    assert risk.severity == "critical"


def test_line_number_is_recorded() -> None:
    """The line number of the matched line is recorded in the result."""
    diff = "context line\n+AWS_SECRET_ACCESS_KEY = AKIAIOSFODNN7EXAMPLEKEY1\n"
    risk = classify_security_risk(diff, "cfg.py")
    assert risk is not None
    assert 2 in risk.line_numbers


# ---------------------------------------------------------------------------
# SecurityAgent.audit — LLM call tests
# ---------------------------------------------------------------------------


async def test_security_agent_calls_budget_not_anthropic(db: RulesDB) -> None:
    """SecurityAgent must use BudgetManager, not anthropic.Anthropic()."""
    budget = _make_budget(db)
    agent = SecurityAgent(AgentConfig(), budget)
    risk = SecurityRisk(
        severity="critical",
        pattern_matched="aws",
        description="AWS key",
        line_numbers=[1],
        file_path="app.py",
    )

    result = await agent.audit(_event(), "+AWS_KEY=...\n", risk)

    assert isinstance(result, dict)
    stub = budget._client  # type: ignore[attr-defined]
    assert stub.call_count == 1


async def test_security_agent_uses_security_system_prompt(db: RulesDB) -> None:
    """The audit call uses SECURITY_AGENT_SYSTEM as the system prompt."""
    budget = _make_budget(db)
    agent = SecurityAgent(AgentConfig(), budget)
    risk = SecurityRisk(
        severity="high",
        pattern_matched="debug",
        description="Debug mode",
        line_numbers=[5],
        file_path="settings.py",
    )

    await agent.audit(_event(["settings.py"]), "+debug = true\n", risk)

    stub = budget._client  # type: ignore[attr-defined]
    last_kwargs = stub.messages.last_kwargs
    assert last_kwargs.get("system") == SECURITY_AGENT_SYSTEM


async def test_security_agent_passes_security_max_tokens_to_api(db: RulesDB) -> None:
    """The security_max_tokens config field reaches messages.create as max_tokens."""
    budget = _make_budget(db)
    agent_cfg = AgentConfig(security_max_tokens=333)
    agent = SecurityAgent(agent_cfg, budget)
    risk = SecurityRisk(
        severity="high",
        pattern_matched="debug",
        description="Debug mode",
        line_numbers=[5],
        file_path="settings.py",
    )

    await agent.audit(_event(["settings.py"]), "+debug = true\n", risk)

    stub = budget._client  # type: ignore[attr-defined]
    assert stub.messages.last_kwargs.get("max_tokens") == 333


async def test_security_agent_prompt_includes_risk_details(db: RulesDB) -> None:
    """The user prompt includes risk severity, description, and file path."""
    budget = _make_budget(db)
    agent = SecurityAgent(AgentConfig(), budget)
    risk = SecurityRisk(
        severity="critical",
        pattern_matched="aws",
        description="AWS credential exposed",
        line_numbers=[3],
        file_path="deploy.env",
    )

    await agent.audit(_event(["deploy.env"]), "+AWS_SECRET_ACCESS_KEY=XYZ\n", risk)

    stub = budget._client  # type: ignore[attr-defined]
    user_content = stub.messages.last_kwargs.get("messages", [{}])[0].get("content", "")
    assert "critical" in user_content
    assert "AWS credential exposed" in user_content
    assert "deploy.env" in user_content


async def test_security_agent_auto_remediate_flag_in_prompt(db: RulesDB) -> None:
    """auto_remediate=True appears in the user prompt."""
    budget = _make_budget(db)
    sec_cfg = SecurityAgentConfig(auto_remediate=True)
    agent = SecurityAgent(AgentConfig(), budget, security_config=sec_cfg)
    risk = SecurityRisk(
        severity="high",
        pattern_matched="debug",
        description="Debug mode",
        line_numbers=[1],
        file_path="app.py",
    )

    await agent.audit(_event(), "+debug=true\n", risk)

    stub = budget._client  # type: ignore[attr-defined]
    user_content = stub.messages.last_kwargs.get("messages", [{}])[0].get("content", "")
    assert "True" in user_content


# ---------------------------------------------------------------------------
# Integration: auto_remediate=False vs True behaviour
# ---------------------------------------------------------------------------


def test_security_agent_config_auto_remediate_default_false() -> None:
    """SecurityAgentConfig defaults to auto_remediate=False."""
    cfg = SecurityAgentConfig()
    assert cfg.auto_remediate is False


def test_security_agent_config_watch_extra_default_includes_env() -> None:
    """Default watch_extra includes .env* pattern."""
    cfg = SecurityAgentConfig()
    assert any(".env" in p for p in cfg.watch_extra)
