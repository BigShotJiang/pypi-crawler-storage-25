"""Unit tests for make_provider() and the SAGEX_PROVIDER env-var override."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import httpx
import pytest

from sagex.config import AgentConfig
from sagex.llm.providers import make_provider
from sagex.llm.providers.anthropic_api import AnthropicAPIProvider
from sagex.llm.providers.claude_code import ClaudeCodePassthroughProvider
from sagex.llm.providers.ollama import OllamaProvider
from sagex.llm.providers.openai_api import OpenAIProvider

# ---------------------------------------------------------------------------
# Default & per-provider resolution
# ---------------------------------------------------------------------------


def test_default_config_returns_anthropic_api(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("SAGEX_PROVIDER", raising=False)
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-stub")
    p = make_provider(AgentConfig())
    assert isinstance(p, AnthropicAPIProvider)
    assert p.name == "anthropic_api"


def test_claude_code_provider_selected_by_config(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("SAGEX_PROVIDER", raising=False)
    fake_version = MagicMock(returncode=0, stdout="claude 1.0\n", stderr="")
    with patch(
        "sagex.llm.providers.claude_code.shutil.which",
        return_value="/fake/claude",
    ):
        with patch(
            "sagex.llm.providers.claude_code.subprocess.run",
            return_value=fake_version,
        ):
            p = make_provider(AgentConfig(provider="claude_code"))
    assert isinstance(p, ClaudeCodePassthroughProvider)


def test_openai_provider_selected_by_config(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("SAGEX_PROVIDER", raising=False)
    monkeypatch.setenv("OPENAI_API_KEY", "sk-proj-stub")
    p = make_provider(AgentConfig(provider="openai_api"))
    assert isinstance(p, OpenAIProvider)


def test_ollama_provider_selected_by_config(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("SAGEX_PROVIDER", raising=False)

    # Pre-flight HTTP call is made via a sync httpx.Client; patch that out.
    mock_client = MagicMock()
    mock_client.__enter__ = MagicMock(return_value=mock_client)
    mock_client.__exit__ = MagicMock(return_value=False)
    mock_client.get = MagicMock(
        return_value=MagicMock(raise_for_status=MagicMock())
    )
    with patch("sagex.llm.providers.ollama.httpx.Client", return_value=mock_client):
        p = make_provider(
            AgentConfig(provider="ollama", ollama_base_url="http://127.0.0.1:11434")
        )
    assert isinstance(p, OllamaProvider)


# ---------------------------------------------------------------------------
# SAGEX_PROVIDER env-var override (option C)
# ---------------------------------------------------------------------------


def test_env_var_overrides_config(monkeypatch: pytest.MonkeyPatch) -> None:
    """SAGEX_PROVIDER wins over agent.provider in the config."""
    monkeypatch.setenv("SAGEX_PROVIDER", "ollama")

    mock_client = MagicMock()
    mock_client.__enter__ = MagicMock(return_value=mock_client)
    mock_client.__exit__ = MagicMock(return_value=False)
    mock_client.get = MagicMock(
        return_value=MagicMock(raise_for_status=MagicMock())
    )
    with patch("sagex.llm.providers.ollama.httpx.Client", return_value=mock_client):
        # Config says anthropic_api, env says ollama — env wins.
        p = make_provider(AgentConfig(provider="anthropic_api"))
    assert isinstance(p, OllamaProvider)


def test_env_var_empty_string_falls_back_to_config(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Empty SAGEX_PROVIDER is treated as unset."""
    monkeypatch.setenv("SAGEX_PROVIDER", "")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-stub")
    p = make_provider(AgentConfig())  # config default = anthropic_api
    assert isinstance(p, AnthropicAPIProvider)


def test_env_var_invalid_value_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("SAGEX_PROVIDER", "deepseek")
    with pytest.raises(ValueError, match="not a valid provider"):
        make_provider(AgentConfig())


# ---------------------------------------------------------------------------
# Ollama base URL forwarding
# ---------------------------------------------------------------------------


def test_ollama_base_url_is_forwarded(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("SAGEX_PROVIDER", raising=False)

    def noop_transport(_r: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={})

    # Cover pre-flight — mock out the sync Client used inside the provider.
    mock_client = MagicMock()
    mock_client.__enter__ = MagicMock(return_value=mock_client)
    mock_client.__exit__ = MagicMock(return_value=False)
    mock_client.get = MagicMock(
        return_value=MagicMock(raise_for_status=MagicMock())
    )
    with patch("sagex.llm.providers.ollama.httpx.Client", return_value=mock_client):
        p = make_provider(
            AgentConfig(
                provider="ollama",
                ollama_base_url="http://remote-ollama:9000",
            )
        )
    assert isinstance(p, OllamaProvider)
    assert p._base_url == "http://remote-ollama:9000"
