"""Phase 2 acceptance criteria: knowledge store, SQLite migrations, Bayesian confidence."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest
from conftest import MockEmbedder

from sagex.config import KnowledgeConfig
from sagex.knowledge.rules_db import Episode, PendingApproval, Rule, RulesDB
from sagex.knowledge.store import KnowledgeStore

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def db(tmp_path: Path) -> RulesDB:
    return RulesDB(str(tmp_path / "rules.db"))


@pytest.fixture
def store(tmp_path: Path) -> KnowledgeStore:
    cfg = KnowledgeConfig(
        db_path=str(tmp_path / "rules.db"),
        vector_path=str(tmp_path / "vectors"),
    )
    return KnowledgeStore(cfg, project_name="test-proj", embedder=MockEmbedder())  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Migration tests
# ---------------------------------------------------------------------------

def test_migrations_create_all_tables(tmp_path: Path) -> None:
    """All 7 migrations run on a fresh DB; all 7 tables exist."""
    db = RulesDB(str(tmp_path / "rules.db"))
    conn = db._conn
    tables = {
        row[0]
        for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    expected = {
        "rules", "episodes", "token_usage", "content_cache",
        "pending_approvals", "event_queue", "schema_version",
    }
    assert expected.issubset(tables), f"Missing tables: {expected - tables}"


def test_schema_version_is_7(db: RulesDB) -> None:
    """After fresh init, schema_version reaches 7."""
    assert db._get_schema_version() == 7


def test_migrations_idempotent(tmp_path: Path) -> None:
    """Running RulesDB.__init__ twice does not error or duplicate rows."""
    path = str(tmp_path / "rules.db")
    db1 = RulesDB(path)
    assert db1._get_schema_version() == 7
    db2 = RulesDB(path)  # re-open same file
    assert db2._get_schema_version() == 7


def test_hot_path_indexes_exist(db: RulesDB) -> None:
    """Migrations 006/007 create indexes on the project/confidence/ts hot paths.

    The episodes composite index is the *corrected* shape from migration
    007 — (project_name, status, created_at) — so range-on-created_at
    can actually benefit after equality-on-status narrows the b-tree.
    The old misordered index idx_episodes_project_created_status must
    not exist after migration 007 drops it.
    """
    rows = db._conn.execute(
        "SELECT name FROM sqlite_master WHERE type='index'"
    ).fetchall()
    names = {row[0] for row in rows}
    expected = {
        "idx_rules_project_confidence",
        "idx_episodes_project_created",
        "idx_episodes_project_status_created",
        "idx_token_usage_project_ts",
        "idx_pending_approvals_project_status",
        "idx_event_queue_status_created",
    }
    assert expected.issubset(names), f"Missing indexes: {expected - names}"
    # The pre-fix index name from migration 006 must have been dropped.
    assert "idx_episodes_project_created_status" not in names


def test_episode_stats_query_plan_uses_index(db: RulesDB) -> None:
    """get_episode_stats's status-filtered query must actually use the
    idx_episodes_project_status_created index.

    Index-name existence (test_hot_path_indexes_exist) doesn't prove the
    planner chose it — the column order could still be wrong and SQLite
    would silently fall back to a scan.  EXPLAIN QUERY PLAN surfaces the
    planner's decision so a regression would fail loudly instead of
    shipping as a quiet performance cliff.
    """
    plan_rows = db._conn.execute(
        """EXPLAIN QUERY PLAN
           SELECT COUNT(*) FROM episodes
           WHERE project_name=? AND created_at>=? AND status='skipped'""",
        ("p", "2026-01-01T00:00:00+00:00"),
    ).fetchall()
    plan_text = " ".join(str(row) for row in plan_rows)
    assert "idx_episodes_project_status_created" in plan_text, (
        f"planner did not pick the status-leading index; plan was: {plan_text}"
    )


def test_v5_database_upgrades_to_v7_on_reopen(tmp_path: Path) -> None:
    """A DB frozen at schema_version=5 must cleanly upgrade to v7 on reopen.

    Fresh-init tests don't exercise the upgrade path — the migration
    runner's 'apply anything past current_version' loop is only tickled
    when current_version < latest.  This simulates a user who applied
    migrations 001-005 on an older sagex build and now picks up a newer
    release with migrations 006 and 007.
    """
    db_path = str(tmp_path / "rules.db")

    # Start with a fully-migrated DB (v7), then roll it back to v5 by
    # deleting the v6/v7 schema_version rows and dropping their indexes.
    # Reopening via RulesDB() then triggers the upgrade path.
    db = RulesDB(db_path)
    assert db._get_schema_version() == 7

    db._conn.execute("DELETE FROM schema_version WHERE version IN (6, 7)")
    for idx in (
        "idx_rules_project_confidence",
        "idx_episodes_project_created",
        "idx_episodes_project_created_status",
        "idx_episodes_project_status_created",
        "idx_token_usage_project_ts",
        "idx_pending_approvals_project_status",
        "idx_event_queue_status_created",
    ):
        db._conn.execute(f"DROP INDEX IF EXISTS {idx}")
    db._conn.commit()
    assert db._get_schema_version() == 5

    # Reopen — migration runner applies 006 then 007.
    db2 = RulesDB(db_path)
    assert db2._get_schema_version() == 7

    rows = db2._conn.execute(
        "SELECT name FROM sqlite_master WHERE type='index'"
    ).fetchall()
    names = {row[0] for row in rows}
    assert "idx_episodes_project_status_created" in names
    assert "idx_episodes_project_created_status" not in names


def test_wal_mode(db: RulesDB) -> None:
    """SQLite connection uses WAL journal mode as required."""
    row = db._conn.execute("PRAGMA journal_mode").fetchone()
    assert row[0] == "wal"


# ---------------------------------------------------------------------------
# Rule CRUD + confidence
# ---------------------------------------------------------------------------

async def test_write_and_read_rule(db: RulesDB) -> None:
    """Write a rule; read it back; verify defaults."""
    rule = Rule(trigger_pattern="auth modified", lesson="check middleware", project_name="p")
    rule_id = await db.write_rule(rule)
    fetched = db.get_rule(rule_id)
    assert fetched is not None
    assert fetched.confidence == pytest.approx(0.3)
    assert fetched.status == "unvalidated"
    assert fetched.times_applied == 0
    assert fetched.times_correct == 0
    assert fetched.trigger_pattern == "auth modified"
    assert fetched.lesson == "check middleware"


async def test_confidence_increases_correctly_applied_twice(db: RulesDB) -> None:
    """Applying a rule correctly twice → Bayesian confidence rises; status → active."""
    rule = Rule(trigger_pattern="t", lesson="l", project_name="p")
    rule_id = await db.write_rule(rule)

    # First correct application: alpha=2, beta=1 → 2/3 ≈ 0.667
    await db.update_confidence(rule_id, correct=True)
    r1 = db.get_rule(rule_id)
    assert r1 is not None
    assert r1.confidence == pytest.approx(2 / 3)
    assert r1.status == "unvalidated"  # only 1 correct so far

    # Second correct application: alpha=3, beta=1 → 3/4 = 0.75; now active
    await db.update_confidence(rule_id, correct=True)
    r2 = db.get_rule(rule_id)
    assert r2 is not None
    assert r2.confidence == pytest.approx(3 / 4)
    assert r2.status == "active"


async def test_confidence_decreases_after_incorrect(db: RulesDB) -> None:
    """Confidence decreases when an incorrect application follows a correct one."""
    rule = Rule(trigger_pattern="t", lesson="l", project_name="p")
    rule_id = await db.write_rule(rule)

    # First correct: confidence → 2/3 ≈ 0.667
    await db.update_confidence(rule_id, correct=True)
    r1 = db.get_rule(rule_id)
    assert r1 is not None
    after_correct = r1.confidence

    # Incorrect: applied=2, correct=1 → alpha=2, beta=2 → 2/4 = 0.5
    await db.update_confidence(rule_id, correct=False)
    r2 = db.get_rule(rule_id)
    assert r2 is not None
    assert r2.confidence < after_correct
    assert r2.confidence == pytest.approx(2 / 4)


async def test_archive_low_confidence_rules(db: RulesDB) -> None:
    """Rules with confidence < threshold are archived; count returned."""
    low = Rule(trigger_pattern="t", lesson="l", project_name="p", confidence=0.1)
    high = Rule(trigger_pattern="t2", lesson="l2", project_name="p", confidence=0.9)
    await db.write_rule(low)
    await db.write_rule(high)

    archived = await db.archive_low_confidence_rules("p", threshold=0.2)
    assert archived == 1

    fetched_low = db.get_rule(low.id)
    assert fetched_low is not None
    assert fetched_low.status == "archived"

    fetched_high = db.get_rule(high.id)
    assert fetched_high is not None
    assert fetched_high.status != "archived"


async def test_archive_low_confidence_rules_returns_actual_rowcount(
    db: RulesDB,
) -> None:
    """Returned count must equal rows the UPDATE actually flipped (issue #26).

    Before the fix, count came from a standalone SELECT outside the write
    lock — a concurrent insert could widen the set between the SELECT and
    the UPDATE, making the returned value stale.  Now the archive
    operation runs the UPDATE under the write lock and returns that
    statement's ``cursor.rowcount``, so the reported value matches the
    rows actually transitioned to ``status='archived'``.
    """
    for i in range(5):
        await db.write_rule(
            Rule(trigger_pattern=f"t{i}", lesson="l", project_name="p", confidence=0.1)
        )
    # Pre-archive two of them directly so they're already status='archived'.
    # The UPDATE must skip these — returned count should be 3, not 5.
    async with db._write_lock:
        db._conn.execute(
            "UPDATE rules SET status='archived' WHERE project_name='p' "
            "AND trigger_pattern IN ('t0','t1')"
        )
        db._conn.commit()

    archived = await db.archive_low_confidence_rules("p", threshold=0.2)
    assert archived == 3, (
        f"Expected 3 newly-archived rows, got {archived}. "
        f"Stale count would have reported 5."
    )
    # Second call is idempotent — nothing left below threshold.
    assert await db.archive_low_confidence_rules("p", threshold=0.2) == 0


async def test_get_rules_for_project_excludes_archived(db: RulesDB) -> None:
    """get_rules_for_project never returns archived rules."""
    active = Rule(trigger_pattern="t", lesson="l", project_name="p", confidence=0.8)
    archived = Rule(trigger_pattern="t2", lesson="l2", project_name="p",
                    confidence=0.9, status="archived")
    await db.write_rule(active)
    await db.write_rule(archived)

    results = db.get_rules_for_project("p", min_confidence=0.0)
    ids = [r.id for r in results]
    assert active.id in ids
    assert archived.id not in ids


# ---------------------------------------------------------------------------
# Episode CRUD
# ---------------------------------------------------------------------------

async def test_write_and_read_episode(db: RulesDB) -> None:
    ep = Episode(
        project_name="p",
        trigger_event='{"type": "file_modified"}',
        status="completed",
    )
    ep_id = await db.write_episode(ep)
    fetched = db.get_episode(ep_id)
    assert fetched is not None
    assert fetched.project_name == "p"
    assert fetched.status == "completed"
    assert fetched.regression_detected == 0


async def test_get_recent_episodes_order(db: RulesDB) -> None:
    """get_recent_episodes returns episodes in descending created_at order."""
    for i in range(3):
        ep = Episode(project_name="p", trigger_event=f'{{"i":{i}}}')
        await db.write_episode(ep)
    episodes = db.get_recent_episodes("p", limit=3)
    assert len(episodes) == 3
    # Most recent first
    assert episodes[0].created_at >= episodes[1].created_at


# ---------------------------------------------------------------------------
# Pending approvals
# ---------------------------------------------------------------------------

async def test_write_and_resolve_approval(db: RulesDB) -> None:
    ep = Episode(project_name="p", trigger_event="{}")
    ep_id = await db.write_episode(ep)

    approval = PendingApproval(project_name="p", episode_id=ep_id, plan_json="{}")
    appr_id = await db.write_pending_approval(approval)

    pending = db.get_pending_approvals("p")
    assert any(a.id == appr_id for a in pending)

    await db.resolve_approval(appr_id, "approved")
    after = db.get_pending_approvals("p")
    assert not any(a.id == appr_id for a in after)


# ---------------------------------------------------------------------------
# KnowledgeStore — conflict detection
# ---------------------------------------------------------------------------

async def test_detect_conflicts_same_trigger_different_lesson(store: KnowledgeStore) -> None:
    """Rules with the same trigger_pattern but different lessons are flagged."""
    rule1 = Rule(
        trigger_pattern="auth module modified",
        lesson="update session middleware",
        project_name="test-proj",
        confidence=0.6,
    )
    rule2 = Rule(
        trigger_pattern="auth module modified",   # identical trigger
        lesson="check token expiry",              # different lesson
        project_name="test-proj",
        confidence=0.6,
    )
    await store._db.write_rule(rule1)
    await store._db.write_rule(rule2)

    rules = store._db.get_rules_for_project("test-proj", min_confidence=0.0)
    has_conflicts, note = await store.detect_conflicts(rules)
    assert has_conflicts, f"Expected conflict, got: {note}"
    assert "vs" in note


async def test_detect_no_conflicts_same_lesson(store: KnowledgeStore) -> None:
    """Rules with same trigger AND same lesson are not flagged as conflicting."""
    rule1 = Rule(
        trigger_pattern="auth modified",
        lesson="check middleware",
        project_name="test-proj",
    )
    rule2 = Rule(
        trigger_pattern="auth modified",
        lesson="check middleware",  # same lesson — no conflict
        project_name="test-proj",
    )
    await store._db.write_rule(rule1)
    await store._db.write_rule(rule2)

    rules = store._db.get_rules_for_project("test-proj", 0.0)
    has_conflicts, _ = await store.detect_conflicts(rules)
    assert not has_conflicts


# ---------------------------------------------------------------------------
# KnowledgeStore — episode embedding + semantic search
# ---------------------------------------------------------------------------

async def test_record_episode_and_query(store: KnowledgeStore) -> None:
    """Write + embed an episode; querying with the same text returns it."""
    situation = "auth module changed"
    ep = Episode(
        project_name="test-proj",
        trigger_event=f'{{"situation": "{situation}"}}',
        actions_taken='["updated session.py"]',
    )
    ep_id = await store.record_episode(ep)

    ctx = await store.get_relevant_context(situation)
    ids = [item["id"] for item in ctx.similar_episodes]
    assert ep_id in ids, f"Episode {ep_id} not in query results: {ids}"


def test_embedder_load_is_thread_safe() -> None:
    """Concurrent ``Embedder._load`` calls must construct the model exactly once.

    Issue context: ``aembed`` / ``aembed_batch`` offload to worker threads
    via ``asyncio.to_thread``.  Without the ``threading.Lock`` guard
    introduced in PR #38, two first-callers landing on different worker
    threads can both observe ``self._model is None`` and both run the
    ~90 MB ``SentenceTransformer`` construction; the later assignment
    can also overwrite an instance another thread is mid-``encode``
    against.  The double-checked-with-lock pattern makes this safe.

    Spawn 8 concurrent threads all calling ``_load`` on the same Embedder
    and patch ``SentenceTransformer`` to count constructions; assert
    exactly one was built.
    """
    import sys
    import threading
    import time
    import types

    from sagex.knowledge.embedder import Embedder

    counter_lock = threading.Lock()
    construction_count = 0

    class _FakeSentenceTransformer:
        def __init__(self, name: str) -> None:
            nonlocal construction_count
            with counter_lock:
                construction_count += 1
            # Slow construction so concurrent threads have time to race.
            time.sleep(0.05)

    # Inject a fake ``sentence_transformers`` module so the lazy
    # ``from sentence_transformers import SentenceTransformer`` inside
    # ``_load`` resolves to our fake without touching the real package.
    fake_module = types.ModuleType("sentence_transformers")
    fake_module.SentenceTransformer = _FakeSentenceTransformer  # type: ignore[attr-defined]
    saved = sys.modules.get("sentence_transformers")
    sys.modules["sentence_transformers"] = fake_module
    try:
        embedder = Embedder()
        threads = [threading.Thread(target=embedder._load) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
    finally:
        if saved is not None:
            sys.modules["sentence_transformers"] = saved
        else:
            sys.modules.pop("sentence_transformers", None)

    assert construction_count == 1, (
        f"Expected exactly one SentenceTransformer construction across 8 "
        f"concurrent _load calls, got {construction_count} — the threading."
        f"Lock guard in Embedder._load is not effective."
    )


# ---------------------------------------------------------------------------
# Export / import
# ---------------------------------------------------------------------------

async def test_export_rules_filters_by_confidence_and_count(
    store: KnowledgeStore,
) -> None:
    """export_rules returns only rules above confidence and min_applied thresholds."""
    good = Rule(
        trigger_pattern="when tests fail",
        lesson="run pytest -x",
        project_name="test-proj",
        confidence=0.9,
        times_applied=15,
        times_correct=14,
    )
    low_conf = Rule(
        trigger_pattern="when config changes",
        lesson="restart server",
        project_name="test-proj",
        confidence=0.5,   # below 0.85
        times_applied=20,
    )
    low_applied = Rule(
        trigger_pattern="when deps updated",
        lesson="rebuild venv",
        project_name="test-proj",
        confidence=0.9,
        times_applied=3,  # below min_applied=10
    )
    for r in (good, low_conf, low_applied):
        await store._db.write_rule(r)

    exported = store.export_rules(min_confidence=0.85, min_applied=10)
    patterns = [e["trigger_pattern"] for e in exported]
    assert "when tests fail" in patterns
    assert "when config changes" not in patterns
    assert "when deps updated" not in patterns


async def test_import_rules_into_second_store(
    tmp_path: Path, store: KnowledgeStore
) -> None:
    """Rules exported from one store can be imported into another."""
    rule = Rule(
        trigger_pattern="auth change",
        lesson="update middleware",
        project_name="test-proj",
        confidence=0.9,
        times_applied=12,
        times_correct=11,
    )
    await store._db.write_rule(rule)

    exported = store.export_rules(min_confidence=0.85, min_applied=10)
    assert len(exported) == 1

    cfg2 = KnowledgeConfig(
        db_path=str(tmp_path / "rules2.db"),
        vector_path=str(tmp_path / "vectors2"),
    )
    store2 = KnowledgeStore(cfg2, project_name="test-proj", embedder=MockEmbedder())  # type: ignore[arg-type]
    imported = await store2.import_rules(exported)
    assert imported == 1

    rules = store2._db.get_rules_for_project("test-proj", 0.0)
    assert any(r.trigger_pattern == "auth change" for r in rules)


# ---------------------------------------------------------------------------
# Concurrency
# ---------------------------------------------------------------------------

async def test_concurrent_write_rule_no_locking_errors(tmp_path: Path) -> None:
    """Concurrent writers on the same DB file must not hit 'database is locked'.

    Issue #28: the original version of this test passed a single ``RulesDB``
    instance to all three writers.  Because ``RulesDB`` owns one
    ``asyncio.Lock`` that serialises every write through ``_write()``, the
    three ``write_rule`` calls never reached SQLite concurrently — the
    test name said "WAL concurrency" but the implementation only exercised
    the Python lock.

    Even using three separate ``RulesDB`` instances on a single event-loop
    thread isn't enough: each ``_write`` ultimately calls *synchronous*
    ``sqlite3.execute`` + ``commit`` with no ``await`` point, so
    ``asyncio.gather`` interleaves them sequentially and SQLite never sees
    overlapping writers.  Push each writer onto its own OS thread via
    ``asyncio.to_thread`` so the writes really do overlap in wall time.
    That makes SQLite lock contention possible and increases the chance
    of surfacing WAL/synchronous regressions, including
    ``database is locked`` errors — though note that ``RulesDB`` opens
    its connections without an explicit ``timeout=0`` or
    ``PRAGMA busy_timeout=0``, so the SQLite default busy handling may
    block instead of failing fast in some configurations.  The test
    catches and re-raises that exception with a WAL-pointing assertion
    when it does fire.
    """
    import json
    import sqlite3

    db_path = str(tmp_path / "rules.db")

    # Each thread gets its own RulesDB → its own sqlite3.Connection.
    # ``check_same_thread=False`` is set inside ``RulesDB.__init__``, so
    # using these from worker threads is safe.
    dbs = [RulesDB(db_path) for _ in range(3)]
    # One rule with a non-trivial tag list so we exercise json-serialised
    # tag storage (the same shape ``RulesDB.write_rule`` writes); other two
    # use defaults.
    rules = [
        Rule(
            trigger_pattern="trigger 0",
            lesson="lesson 0",
            project_name="p",
            tags=["concurrency", "wal"],
        ),
        Rule(trigger_pattern="trigger 1", lesson="lesson 1", project_name="p"),
        Rule(trigger_pattern="trigger 2", lesson="lesson 2", project_name="p"),
    ]

    def _direct_insert(db: RulesDB, rule: Rule) -> None:
        # Bypass the asyncio-lock-protected ``_write`` so the work happens
        # on the worker thread (without re-entering the event loop).  Use
        # the *same* SQL and the *same* parameter serialisation as
        # ``RulesDB.write_rule`` — including ``json.dumps(rule.tags)`` —
        # so this test would catch a regression in tag serialisation
        # alongside any WAL regression.
        db._conn.execute(
            """INSERT OR REPLACE INTO rules
               (id, trigger_pattern, lesson, confidence, times_applied,
                times_correct, status, tags, source_episode_id, project_name,
                created_at, last_used_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                rule.id, rule.trigger_pattern, rule.lesson, rule.confidence,
                rule.times_applied, rule.times_correct, rule.status,
                json.dumps(rule.tags), rule.source_episode_id, rule.project_name,
                rule.created_at, rule.last_used_at,
            ),
        )
        db._conn.commit()

    try:
        await asyncio.gather(
            *[
                asyncio.to_thread(_direct_insert, db, r)
                for db, r in zip(dbs, rules, strict=True)
            ]
        )
    except sqlite3.OperationalError as exc:
        if "database is locked" in str(exc):
            raise AssertionError(
                "Concurrent SQLite writers hit 'database is locked' — "
                "WAL mode regression?"
            ) from exc
        raise

    # Any of the three instances can read back — WAL allows concurrent readers.
    stored = dbs[0].get_rules_for_project("p", min_confidence=0.0)
    assert len(stored) == 3
    # Specifically verify the tag-serialisation path landed correctly so
    # a future change to write_rule's tag encoding can't silently diverge
    # from this test's direct-insert path.
    by_trigger = {r.trigger_pattern: r for r in stored}
    assert by_trigger["trigger 0"].tags == ["concurrency", "wal"]


# ---------------------------------------------------------------------------
# Regression: import_rules must go through KnowledgeStore.write_rule so that
# imported rules are indexed in ChromaDB. Previously it wrote directly to
# RulesDB, leaving the vector store blind to imported rules (issue #11).
# ---------------------------------------------------------------------------

async def test_import_rules_indexes_into_vector_store(
    tmp_path: Path, store: KnowledgeStore
) -> None:
    """Imported rules are retrievable via vector query."""
    rule = Rule(
        trigger_pattern="auth change",
        lesson="update middleware",
        project_name="test-proj",
        confidence=0.9,
        times_applied=12,
        times_correct=11,
    )
    await store._db.write_rule(rule)
    exported = store.export_rules(min_confidence=0.85, min_applied=10)

    cfg2 = KnowledgeConfig(
        db_path=str(tmp_path / "rules2.db"),
        vector_path=str(tmp_path / "vectors2"),
    )
    store2 = KnowledgeStore(cfg2, project_name="test-proj", embedder=MockEmbedder())  # type: ignore[arg-type]
    imported = await store2.import_rules(exported)
    assert imported == 1

    # The crux: semantic search for the imported rule's trigger must find it.
    results = store2._vector_db.query(
        "auth change", "test-proj", n_results=5
    )
    ids = [item["id"] for item in results]
    assert ids, "imported rule was not indexed into ChromaDB"


# ---------------------------------------------------------------------------
# Regression: detect_conflicts must operate on the active rule set up to the
# configured conflict-check cap, not just the top-N slice used for context.
# Otherwise a contradiction between a top-N rule and a rule outside top-N
# (but inside the cap) is invisible (issue #22).
# ---------------------------------------------------------------------------

async def test_detect_conflicts_sees_rules_outside_top_n(tmp_path: Path) -> None:
    """Conflict between a top-N rule and a rule outside top-N is still flagged."""
    cfg = KnowledgeConfig(
        db_path=str(tmp_path / "rules.db"),
        vector_path=str(tmp_path / "vectors"),
        max_rules_in_context=1,  # only 1 rule in context; rest must still be scanned
        min_confidence_threshold=0.0,
    )
    store = KnowledgeStore(cfg, project_name="p", embedder=MockEmbedder())  # type: ignore[arg-type]

    high = Rule(
        trigger_pattern="auth module modified",
        lesson="update session middleware",
        project_name="p",
        confidence=0.95,
    )
    low = Rule(
        trigger_pattern="auth module modified",  # identical trigger
        lesson="check token expiry",              # different lesson
        project_name="p",
        confidence=0.2,                           # below the top-N slice
    )
    await store._db.write_rule(high)
    await store._db.write_rule(low)

    ctx = await store.get_relevant_context("any situation")
    assert len(ctx.rules) == 1  # top-N slice was applied
    assert ctx.has_conflicts, (
        f"Expected conflict between top-N rule and low-confidence rule, "
        f"note={ctx.conflict_note!r}"
    )


# ---------------------------------------------------------------------------
# Regression: max_rules_in_conflict_check actually bounds the scan. A rule
# beyond the cap must NOT be compared, so a future regression that drops
# the cap (or computes the slice wrong) fails loudly.
# ---------------------------------------------------------------------------

async def test_max_rules_in_conflict_check_bounds_the_scan(tmp_path: Path) -> None:
    """Setting cap=1 means only the highest-confidence rule is scanned, so a
    conflicting rule that lands at index >=1 must NOT be flagged."""
    cfg = KnowledgeConfig(
        db_path=str(tmp_path / "rules.db"),
        vector_path=str(tmp_path / "vectors"),
        max_rules_in_context=1,
        min_confidence_threshold=0.0,
        max_rules_in_conflict_check=1,
    )
    store = KnowledgeStore(cfg, project_name="p", embedder=MockEmbedder())  # type: ignore[arg-type]

    # Identical triggers + different lessons → would conflict under an
    # unbounded scan.  Two-rule corpus, cap=1 → only rule 0 is scanned,
    # so detect_conflicts has nothing to compare against and returns False.
    await store._db.write_rule(
        Rule(
            trigger_pattern="auth module modified",
            lesson="A",
            project_name="p",
            confidence=0.95,
        )
    )
    await store._db.write_rule(
        Rule(
            trigger_pattern="auth module modified",
            lesson="B",
            project_name="p",
            confidence=0.2,
        )
    )

    ctx = await store.get_relevant_context("any situation")
    assert ctx.has_conflicts is False, (
        f"Expected cap=1 to suppress detection of the rule outside the cap; "
        f"note={ctx.conflict_note!r}"
    )
