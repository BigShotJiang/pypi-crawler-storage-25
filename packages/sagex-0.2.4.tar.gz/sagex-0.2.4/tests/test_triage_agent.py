"""Phase 5 acceptance criteria: triage agent rule-based and LLM classification."""

from __future__ import annotations

from pathlib import Path

import pytest
from conftest import StubAnthropicClient

from sagex.agents.triage_agent import (
    TriageAgent,
    TriageResult,
    rule_based_triage,
)
from sagex.config import AgentConfig, BudgetConfig
from sagex.event_bus import AgentEvent, EventType
from sagex.knowledge.rules_db import RulesDB
from sagex.llm.budget import BudgetManager
from sagex.llm.cache import ContentCache
from sagex.llm.token_tracker import TokenTracker

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def db(tmp_path: Path) -> RulesDB:
    return RulesDB(str(tmp_path / "rules.db"))


def _make_budget(db: RulesDB, responses: list[str] | None = None) -> BudgetManager:
    stub = StubAnthropicClient(responses=responses or ['{"severity": "low", "reason": "ok"}'])
    tracker = TokenTracker(db)
    cache = ContentCache(db, ttl_minutes=60)
    return BudgetManager(BudgetConfig(), tracker, cache, client=stub)


def _event(
    file_paths: list[str],
    diff: str = "",
    project: str = "proj",
) -> AgentEvent:
    return AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name=project,
        repo_root="/repo",
        file_paths=file_paths,
        diff=diff,
    )


# ---------------------------------------------------------------------------
# Rule-based: skip cases
# ---------------------------------------------------------------------------

def test_log_file_returns_skip_no_llm() -> None:
    """.log file extension → skip, no LLM needed."""
    event = _event(["logs/output.log"])
    result = rule_based_triage(event)
    assert result == "skip"


def test_lock_file_returns_skip() -> None:
    """poetry.lock → skip."""
    result = rule_based_triage(_event(["poetry.lock"]))
    assert result == "skip"


def test_pyc_file_returns_skip() -> None:
    """Compiled .pyc → skip."""
    result = rule_based_triage(_event(["src/__pycache__/foo.pyc"]))
    assert result == "skip"


def test_markdown_file_returns_skip() -> None:
    """Documentation files → skip (no LLM needed)."""
    assert rule_based_triage(_event(["README.md"])) == "skip"
    assert rule_based_triage(_event(["docs/guide.rst"])) == "skip"


def test_requirements_txt_is_not_skipped() -> None:
    """requirements.txt and similar dependency .txt files must NOT skip — they
    need full LLM analysis (potential CVE / supply-chain risk)."""
    for path in ("requirements.txt", "constraints.txt", "deps/runtime.txt"):
        assert rule_based_triage(_event([path])) != "skip", path


def test_trailing_whitespace_only_change_returns_skip() -> None:
    """Pure trailing-whitespace cleanup → skip (stripped content matches)."""
    diff = (
        "--- a/foo.py\n+++ b/foo.py\n@@ -1,2 +1,2 @@\n"
        "-    return value\n"
        "+    return value   \n"
    )
    assert rule_based_triage(_event(["foo.py"], diff=diff)) == "skip"


def test_tab_to_space_indent_change_returns_skip() -> None:
    """Tab → space indent conversion → skip (stripped content matches)."""
    diff = (
        "--- a/foo.py\n+++ b/foo.py\n@@ -1,2 +1,2 @@\n"
        "-\tx = 1\n"
        "+    x = 1\n"
        "-\treturn x\n"
        "+    return x\n"
    )
    assert rule_based_triage(_event(["foo.py"], diff=diff)) == "skip"


def test_min_js_skips_via_multipart_extension() -> None:
    """foo.min.js must skip — extension match now uses endswith, not last suffix."""
    assert rule_based_triage(_event(["public/app.min.js"])) == "skip"
    # Plain .js must NOT skip (real source code)
    diff = "--- a/app.js\n+++ b/app.js\n@@ -1 +1 @@\n-x = 1\n+x = 2\n"
    assert rule_based_triage(_event(["src/app.js"], diff=diff)) != "skip"


def test_root_relative_build_dir_skips() -> None:
    """SKIP_PATTERNS must match root-relative paths like 'dist/app.js' (no leading slash)."""
    for path in (
        "dist/app.js",
        "build/index.html",
        "out/static/main.css",
        "node_modules/react/index.js",
        "coverage/lcov.info",
    ):
        assert rule_based_triage(_event([path])) == "skip", path


def test_real_change_with_formatting_does_not_skip() -> None:
    """If any added line differs in stripped content, must NOT skip."""
    diff = (
        "--- a/foo.py\n+++ b/foo.py\n@@ -1,3 +1,3 @@\n"
        "-x = 1\n"
        "+x = 2\n"           # real change
        "-    y = 1   \n"
        "+    y = 1\n"       # whitespace cleanup
    )
    assert rule_based_triage(_event(["foo.py"], diff=diff)) != "skip"


def test_build_artifact_dirs_return_skip() -> None:
    """Files under dist/, build/, coverage/ → skip."""
    for path in (
        "dist/bundle.js.map",
        "build/lib/main.js.map",
        "out/index.js.map",
        "coverage/lcov.info.lock",
        "htmlcov/status.lock",
        "my_pkg.egg-info/PKG-INFO.lock",
    ):
        assert rule_based_triage(_event([path])) == "skip", path


def test_whitespace_only_diff_returns_skip() -> None:
    """A diff containing only whitespace changes → skip."""
    diff = (
        "--- a/foo.py\n"
        "+++ b/foo.py\n"
        "@@ -1,2 +1,2 @@\n"
        "-   \n"   # removed blank/whitespace line
        "+    \n"  # added blank/whitespace line
    )
    result = rule_based_triage(_event(["foo.py"], diff=diff))
    assert result == "skip"


# ---------------------------------------------------------------------------
# Rule-based: security / test signals
# ---------------------------------------------------------------------------

def test_env_path_returns_high_minimum() -> None:
    """.env file modification → at least 'high'."""
    result = rule_based_triage(_event(["/project/.env"]))
    assert result in ("high", "critical")


def test_secret_in_path_returns_high() -> None:
    """'secret' in filename → at least 'high'."""
    result = rule_based_triage(_event(["config/secret_keys.py"]))
    assert result in ("high", "critical")


def test_test_file_returns_medium_minimum() -> None:
    """test_ prefix → at least 'medium'."""
    result = rule_based_triage(_event(["tests/test_auth.py"]))
    assert result in ("medium", "high", "critical")


def test_test_suffix_returns_medium_minimum() -> None:
    """_test.py suffix → at least 'medium'."""
    result = rule_based_triage(_event(["auth_test.py"]))
    assert result in ("medium", "high", "critical")


# ---------------------------------------------------------------------------
# Rule-based: inconclusive
# ---------------------------------------------------------------------------

def test_large_diff_unknown_file_is_inconclusive() -> None:
    """A large diff to an unknown file type returns None (inconclusive)."""
    big_diff = "\n".join([f"+line{i}" for i in range(20)])
    result = rule_based_triage(_event(["main.py"], diff=big_diff))
    assert result is None


def test_small_diff_returns_low() -> None:
    """A diff with < 5 changed lines and no special signals → 'low'."""
    diff = "--- a/main.py\n+++ b/main.py\n@@ -1 +1 @@\n-x = 1\n+x = 2\n"
    result = rule_based_triage(_event(["main.py"], diff=diff))
    assert result == "low"


# ---------------------------------------------------------------------------
# TriageAgent — rule-based path (no LLM call)
# ---------------------------------------------------------------------------

async def test_triage_agent_skip_no_llm_call(db: RulesDB) -> None:
    """.log file → skip severity, used_llm=False."""
    budget = _make_budget(db)
    agent = TriageAgent(AgentConfig(), budget)
    event = _event(["app.log"])

    result = await agent.classify(event)

    assert isinstance(result, TriageResult)
    assert result.severity == "skip"
    assert result.used_llm is False
    # Stub was never called (rule-based path)
    stub = budget._client  # type: ignore[attr-defined]
    assert stub.call_count == 0


async def test_triage_agent_env_returns_high_no_llm(db: RulesDB) -> None:
    """.env path → high, no LLM call."""
    budget = _make_budget(db)
    agent = TriageAgent(AgentConfig(), budget)
    event = _event([".env"])

    result = await agent.classify(event)

    assert result.severity in ("high", "critical")
    assert result.used_llm is False


async def test_triage_agent_whitespace_diff_skip_no_llm(db: RulesDB) -> None:
    """Whitespace-only diff → skip, no LLM call."""
    diff = "--- a/a.py\n+++ b/a.py\n@@ -1 +1 @@\n-  \n+   \n"
    budget = _make_budget(db)
    agent = TriageAgent(AgentConfig(), budget)

    result = await agent.classify(_event(["a.py"], diff=diff))

    assert result.severity == "skip"
    assert result.used_llm is False


# ---------------------------------------------------------------------------
# TriageAgent — LLM path
# ---------------------------------------------------------------------------

async def test_triage_agent_inconclusive_triggers_haiku_call(db: RulesDB) -> None:
    """An inconclusive event triggers exactly one Haiku LLM call."""
    haiku_response = '{"severity": "medium", "reason": "logic change"}'
    budget = _make_budget(db, responses=[haiku_response])
    agent = TriageAgent(AgentConfig(), budget)

    # Large diff to unknown file → inconclusive → LLM call
    big_diff = "\n".join([f"+line{i}" for i in range(20)])
    event = _event(["main.py"], diff=big_diff)

    result = await agent.classify(event)

    assert result.used_llm is True
    stub = budget._client  # type: ignore[attr-defined]
    assert stub.call_count == 1


async def test_triage_agent_passes_triage_max_tokens_to_api(db: RulesDB) -> None:
    """The triage_max_tokens config field reaches messages.create as max_tokens."""
    haiku_response = '{"severity": "medium", "reason": "ok"}'
    budget = _make_budget(db, responses=[haiku_response])
    agent_cfg = AgentConfig(triage_max_tokens=128)
    agent = TriageAgent(agent_cfg, budget)

    big_diff = "\n".join([f"+line{i}" for i in range(20)])
    await agent.classify(_event(["main.py"], diff=big_diff))

    stub = budget._client  # type: ignore[attr-defined]
    assert stub.messages.last_kwargs.get("max_tokens") == 128


async def test_triage_agent_llm_critical_classified_correctly(db: RulesDB) -> None:
    """When Haiku returns 'critical', TriageAgent surfaces it as 'critical'."""
    critical_response = '{"severity": "critical", "reason": "secret exposed"}'
    budget = _make_budget(db, responses=[critical_response])
    agent = TriageAgent(AgentConfig(), budget)

    big_diff = "\n".join([f"+line{i}" for i in range(20)])
    event = _event(["config.py"], diff=big_diff)

    result = await agent.classify(event)

    assert result.severity == "critical"
    assert result.used_llm is True
    assert "secret" in result.reason.lower()


async def test_triage_agent_test_file_medium_no_llm(db: RulesDB) -> None:
    """test_ file → at least medium from rule, no LLM call."""
    budget = _make_budget(db)
    agent = TriageAgent(AgentConfig(), budget)

    result = await agent.classify(_event(["tests/test_auth.py"]))

    assert result.severity in ("medium", "high", "critical")
    assert result.used_llm is False
    stub = budget._client  # type: ignore[attr-defined]
    assert stub.call_count == 0
