"""Phase 6 acceptance criteria: task agent, action executor."""

from __future__ import annotations

from pathlib import Path

import pytest
from conftest import StubAnthropicClient

from sagex.agents.task_agent import (
    ActionExecutor,
    TaskAgent,
    _format_episodes,
    _format_rules,
    _preprocess_diff,
)
from sagex.agents.triage_agent import TriageResult
from sagex.config import (
    AgentConfig,
    BudgetConfig,
    KnowledgeConfig,
    ProjectConfig,
    RunnerConfig,
    TestConfig,
    WatchConfig,
)
from sagex.event_bus import AgentEvent, EventType
from sagex.knowledge.rules_db import Rule, RulesDB
from sagex.knowledge.store import KnowledgeContext
from sagex.llm.budget import BudgetManager
from sagex.llm.cache import ContentCache
from sagex.llm.token_tracker import TokenTracker

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def db(tmp_path: Path) -> RulesDB:
    return RulesDB(str(tmp_path / "rules.db"))


def _make_budget(db: RulesDB, responses: list[str] | None = None) -> BudgetManager:
    stub = StubAnthropicClient(
        responses=responses
        or [
            '{"summary":"ok","severity":"low","actions":[],'
            '"checks_required":[],"rules_applied":[],'
            '"confidence":0.8,"skip_reason":null}'
        ]
    )
    tracker = TokenTracker(db)
    cache = ContentCache(db, ttl_minutes=60)
    return BudgetManager(BudgetConfig(), tracker, cache, client=stub)


def _make_config(repo_root: str, test_command: str = "echo pass") -> ProjectConfig:
    return ProjectConfig(
        name="test-proj",
        repo_root=repo_root,
        watch=WatchConfig(paths=[repo_root]),
        test=TestConfig(command=test_command),
        agent=AgentConfig(),
        runner=RunnerConfig(),
    )


def _event(diff_context: str | None = None, diff: str | None = None) -> AgentEvent:
    return AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="test-proj",
        repo_root="/repo",
        file_paths=["main.py"],
        diff=diff,
        diff_context=diff_context,
    )


def _triage() -> TriageResult:
    return TriageResult(severity="medium", reason="logic change", used_llm=False)


def _context(rules: list[Rule] | None = None) -> KnowledgeContext:
    return KnowledgeContext(
        rules=rules or [],
        similar_episodes=[],
        has_conflicts=False,
    )


# ---------------------------------------------------------------------------
# _preprocess_diff
# ---------------------------------------------------------------------------

async def test_preprocess_diff_returns_original_when_short(db: RulesDB) -> None:
    """Short diff is returned unchanged — no Haiku call."""
    budget = _make_budget(db)
    event = _event()
    result = await _preprocess_diff("short diff", event, budget)
    assert result == "short diff"
    stub = budget._client  # type: ignore[attr-defined]
    assert stub.call_count == 0


async def test_preprocess_diff_summarises_large_diff(db: RulesDB) -> None:
    """Diff exceeding threshold triggers a Haiku summarisation call."""
    budget = _make_budget(db, responses=["[DIFF SUMMARISED] small summary"])
    event = _event()
    large_diff = "X" * 7000
    result = await _preprocess_diff(large_diff, event, budget)
    assert "SUMMARISED" in result
    stub = budget._client  # type: ignore[attr-defined]
    assert stub.call_count == 1


# ---------------------------------------------------------------------------
# TaskAgent.plan
# ---------------------------------------------------------------------------

async def test_task_agent_calls_budget_not_anthropic_directly(db: RulesDB) -> None:
    """TaskAgent must use BudgetManager, not instantiate anthropic.Anthropic()."""
    budget = _make_budget(db)
    agent = TaskAgent(AgentConfig(), budget)
    event = _event(diff_context="some diff")

    plan = await agent.plan(event, _triage(), _context())

    assert isinstance(plan, dict)
    stub = budget._client  # type: ignore[attr-defined]
    assert stub.call_count >= 1


async def test_task_agent_prompt_includes_rules(db: RulesDB) -> None:
    """The user prompt sent to the LLM contains rule text."""
    budget = _make_budget(db)
    agent = TaskAgent(AgentConfig(), budget)
    rule = Rule(
        trigger_pattern="auth modified",
        lesson="check middleware",
        project_name="test-proj",
        confidence=0.8,
    )
    ctx = _context(rules=[rule])
    event = _event(diff_context="auth.py diff")

    await agent.plan(event, _triage(), ctx)

    stub = budget._client  # type: ignore[attr-defined]
    last_user = stub.messages.last_kwargs.get("messages", [{}])[0].get("content", "")
    assert "auth modified" in last_user or "check middleware" in last_user


async def test_task_agent_prompt_includes_conflict_note(db: RulesDB) -> None:
    """Conflict note appears in the prompt when context.has_conflicts is True."""
    budget = _make_budget(db)
    agent = TaskAgent(AgentConfig(), budget)
    ctx = KnowledgeContext(
        rules=[],
        similar_episodes=[],
        has_conflicts=True,
        conflict_note="Rule A vs Rule B",
    )
    event = _event(diff_context="diff")

    await agent.plan(event, _triage(), ctx)

    stub = budget._client  # type: ignore[attr-defined]
    last_user = stub.messages.last_kwargs.get("messages", [{}])[0].get("content", "")
    assert "Rule A vs Rule B" in last_user


async def test_task_agent_skipped_plan_returned_as_is(db: RulesDB) -> None:
    """When plan has skip_reason, it is returned directly without modification."""
    skip_plan = (
        '{"summary":"no action needed","severity":"low","actions":[],'
        '"checks_required":[],"rules_applied":[],'
        '"confidence":0.9,"skip_reason":"whitespace only"}'
    )
    budget = _make_budget(db, responses=[skip_plan])
    agent = TaskAgent(AgentConfig(), budget)

    plan = await agent.plan(_event(diff_context="diff"), _triage(), _context())
    assert plan["skip_reason"] == "whitespace only"


# ---------------------------------------------------------------------------
# ActionExecutor
# ---------------------------------------------------------------------------

async def test_action_executor_skipped_when_skip_reason_set(tmp_path: Path) -> None:
    """ActionExecutor returns skipped=True immediately when skip_reason is set."""
    config = _make_config(str(tmp_path))
    executor = ActionExecutor()
    plan = {"skip_reason": "nothing to do", "actions": []}

    result = await executor.execute(plan, config)

    assert result.skipped is True
    assert result.skip_reason == "nothing to do"
    assert result.actions_taken == []


async def test_action_executor_creates_file(tmp_path: Path) -> None:
    """create_file action writes the file to disk."""
    config = _make_config(str(tmp_path))
    executor = ActionExecutor()
    plan = {
        "skip_reason": None,
        "actions": [
            {
                "type": "create_file",
                "target": "new_module.py",
                "description": "create module",
                "content": "# new\nx = 1\n",
            }
        ],
    }

    result = await executor.execute(plan, config)

    assert (tmp_path / "new_module.py").exists()
    assert (tmp_path / "new_module.py").read_text() == "# new\nx = 1\n"
    assert "new_module.py" in result.actions_taken[0]
    assert result.errors == []


async def test_action_executor_edits_file(tmp_path: Path) -> None:
    """edit_file action overwrites an existing file."""
    target = tmp_path / "foo.py"
    target.write_text("old content\n")
    config = _make_config(str(tmp_path))
    executor = ActionExecutor()
    plan = {
        "skip_reason": None,
        "actions": [
            {
                "type": "edit_file",
                "target": "foo.py",
                "description": "update foo",
                "content": "new content\n",
            }
        ],
    }

    await executor.execute(plan, config)

    assert target.read_text() == "new content\n"


async def test_action_executor_deletes_file(tmp_path: Path) -> None:
    """delete_file action removes an existing file."""
    target = tmp_path / "obsolete.py"
    target.write_text("old\n")
    config = _make_config(str(tmp_path))
    executor = ActionExecutor()
    plan = {
        "skip_reason": None,
        "actions": [
            {
                "type": "delete_file",
                "target": "obsolete.py",
                "description": "remove dead code",
            }
        ],
    }

    await executor.execute(plan, config)

    assert not target.exists()


async def test_action_executor_runs_command(tmp_path: Path) -> None:
    """run_command action executes a shell command when require_approval=True."""
    config = _make_config(str(tmp_path))
    config = config.model_copy(update={"runner": RunnerConfig(require_approval=True)})
    executor = ActionExecutor()
    sentinel = tmp_path / "sentinel.txt"
    plan = {
        "skip_reason": None,
        "actions": [
            {
                "type": "run_command",
                "target": f"touch {sentinel}",
                "description": "create sentinel",
            }
        ],
    }

    result = await executor.execute(plan, config)

    assert sentinel.exists()
    assert result.errors == []


async def test_action_executor_run_command_blocked_without_approval(tmp_path: Path) -> None:
    """run_command is blocked and produces an error when require_approval=False."""
    config = _make_config(str(tmp_path))  # require_approval defaults to False
    executor = ActionExecutor()
    sentinel = tmp_path / "sentinel.txt"
    plan = {
        "skip_reason": None,
        "actions": [
            {
                "type": "run_command",
                "target": f"touch {sentinel}",
                "description": "should be blocked",
            }
        ],
    }

    result = await executor.execute(plan, config)

    assert not sentinel.exists()
    assert len(result.errors) == 1
    assert "require_approval" in result.errors[0]


async def test_action_executor_blocks_path_traversal(tmp_path: Path) -> None:
    """edit_file and delete_file must reject paths that escape repo_root."""
    config = _make_config(str(tmp_path))
    executor = ActionExecutor()

    outside = tmp_path.parent / "outside.txt"
    traversal_target = "../outside.txt"

    for action_type in ("edit_file", "create_file"):
        plan = {
            "skip_reason": None,
            "actions": [
                {
                    "type": action_type,
                    "target": traversal_target,
                    "content": "pwned",
                    "description": "escape attempt",
                }
            ],
        }
        result = await executor.execute(plan, config)
        assert not outside.exists(), f"{action_type} must not write outside repo_root"
        assert any("traversal" in e for e in result.errors), (
            f"{action_type} must add a traversal error"
        )

    # delete_file traversal
    outside.write_text("safe")
    plan = {
        "skip_reason": None,
        "actions": [{"type": "delete_file", "target": traversal_target, "description": "delete"}],
    }
    result = await executor.execute(plan, config)
    assert outside.exists(), "delete_file must not remove files outside repo_root"
    assert any("traversal" in e for e in result.errors)


async def test_action_executor_captures_test_result(tmp_path: Path) -> None:
    """After executing actions, the test command result is captured."""
    config = _make_config(str(tmp_path), test_command="echo 'all tests pass'")
    executor = ActionExecutor()
    plan = {"skip_reason": None, "actions": []}

    result = await executor.execute(plan, config)

    assert result.test_result == "pass"
    assert "all tests pass" in (result.test_output or "")


async def test_action_executor_detects_failing_test(tmp_path: Path) -> None:
    """test_result is 'fail' when the test command exits non-zero."""
    config = _make_config(str(tmp_path), test_command="exit 1")
    executor = ActionExecutor()
    plan = {"skip_reason": None, "actions": []}

    result = await executor.execute(plan, config)

    assert result.test_result == "fail"


# ---------------------------------------------------------------------------
# Context truncation (token-saving optimisations)
# ---------------------------------------------------------------------------

def test_format_rules_truncates_long_text() -> None:
    """Per-rule trigger and lesson are truncated past max_chars_per_rule."""
    long_text = "x" * 500
    rule = Rule(
        trigger_pattern=long_text,
        lesson=long_text,
        project_name="p",
        confidence=0.9,
    )
    out = _format_rules([rule], max_chars_per_rule=100)
    # Truncated portions appear with the ellipsis marker
    assert "…" in out
    # Full 500-char text must NOT appear in either field
    assert long_text not in out


def test_format_episodes_respects_limit_and_truncation() -> None:
    """Episodes beyond limit are dropped; remaining are truncated."""
    episodes = [{"text": "y" * 500} for _ in range(5)]
    out = _format_episodes(episodes, limit=2, max_chars_per_episode=80)
    # Only 2 entries
    assert out.count("\n- ") + (1 if out.startswith("- ") else 0) == 2
    # No raw 500-char string survives
    assert "y" * 500 not in out
    assert "…" in out


async def test_task_agent_truncates_long_test_output(db: RulesDB) -> None:
    """Long test_output_before is truncated to the tail (failure summary lives there)."""
    budget = _make_budget(db)
    agent = TaskAgent(AgentConfig(), budget)
    # Simulate verbose pytest output: 5KB of collection noise + a final failure line
    noise = "collected 200 items\n" + ("." * 100 + "\n") * 50
    failure = "FAILED tests/test_x.py::test_thing - AssertionError: expected 1 got 2"
    long_output = noise + failure
    assert len(long_output) > 1500

    await agent.plan(
        _event(diff_context="diff"),
        _triage(),
        _context(),
        test_output_before=long_output,
    )

    stub = budget._client  # type: ignore[attr-defined]
    last_user = stub.messages.last_kwargs.get("messages", [{}])[0].get("content", "")
    # Truncation marker present
    assert "[truncated" in last_user
    # Failure summary preserved
    assert "AssertionError: expected 1 got 2" in last_user
    # Early collection noise dropped
    assert "collected 200 items" not in last_user


async def test_task_agent_truncates_rules_in_prompt(db: RulesDB) -> None:
    """Long rule lessons are truncated in the prompt sent to the LLM."""
    budget = _make_budget(db)
    knowledge_config = KnowledgeConfig(max_rule_chars=50, max_episodes_in_context=2)
    agent = TaskAgent(AgentConfig(), budget, knowledge_config)
    long_lesson = "z" * 300
    rule = Rule(
        trigger_pattern="auth modified",
        lesson=long_lesson,
        project_name="test-proj",
        confidence=0.8,
    )
    await agent.plan(_event(diff_context="diff"), _triage(), _context(rules=[rule]))

    stub = budget._client  # type: ignore[attr-defined]
    last_user = stub.messages.last_kwargs.get("messages", [{}])[0].get("content", "")
    assert long_lesson not in last_user
    assert "…" in last_user
