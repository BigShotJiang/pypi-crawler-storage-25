"""Guard against version drift between __init__.py and installed metadata."""

from __future__ import annotations

from importlib.metadata import version

from click.testing import CliRunner

import sagex
from sagex.cli import main


def test_dunder_version_matches_installed_metadata() -> None:
    """``sagex.__version__`` must match the wheel's recorded version.

    Historically the two drifted (pyproject.toml moved 0.1.0 → 0.2.2 across
    multiple releases while ``src/sagex/__init__.py::__version__`` stayed
    pinned to "0.1.0"). ``scripts/bump-version.sh`` now rewrites both on
    every bump; this test is the CI-enforceable backstop.
    """
    assert sagex.__version__ == version("sagex")


def test_cli_version_flag_prints_current_version() -> None:
    """``sagex --version`` must print the current version, not error.

    The READMEs document ``sagex --version`` as the install-verification
    command; without this test, the flag can silently disappear again.
    """
    result = CliRunner().invoke(main, ["--version"])
    assert result.exit_code == 0
    assert sagex.__version__ in result.output
