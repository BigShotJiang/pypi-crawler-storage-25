"""Tests for CLI-level guards that complement the transport-layer register tests.

tests/test_api.py already covers the /projects/register HTTP handler.  This
file covers the user-facing CLI: its guards, prompts, and error messages.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from click.testing import CliRunner
from conftest import write_minimal_config

from sagex.cli import main


def test_register_refuses_template_default_name(tmp_path: Path) -> None:
    """``sagex register`` must refuse to register ``name: my-project``.

    Before this guard, users who ran ``sagex init`` then ``sagex register``
    without editing the generated ``config.yaml`` would silently register
    the runtime under the placeholder name ``my-project``.  They would
    then edit the config to a real name, but the runtime kept pointing at
    the placeholder — producing ghost projects and confusing 404s on
    ``/projects/<real-name>/...`` endpoints.

    Patches ``httpx.post`` so we can assert positively that **no network
    call was attempted**, not just that a specific error string failed to
    appear.  Message-absence is weak evidence; call-count is strong.
    """
    config_path = tmp_path / "config.yaml"
    write_minimal_config(config_path, project_name="my-project")

    with patch("httpx.post") as mock_post:
        result = CliRunner().invoke(main, ["register", str(config_path)])

    # ClickException → non-zero exit with a message on stderr.
    assert result.exit_code != 0
    assert "my-project" in result.output
    assert "template default" in result.output
    # Must surface the config path so the user knows where to edit.
    assert str(config_path) in result.output
    # Positive proof that the guard fired before any network activity.
    mock_post.assert_not_called()


def test_register_force_flag_bypasses_template_guard(tmp_path: Path) -> None:
    """``sagex register --force`` must skip the template-name check and
    actually attempt the HTTP POST with force=True propagated through.

    Escape hatch for tests, CI, and the rare user who legitimately wants
    a project literally named ``my-project``.  We mock httpx.post so the
    test doesn't depend on a running runtime — the positive assertions
    then prove three things:

      1. The guard is silent (no ClickException raised before the POST).
      2. The POST is actually attempted (mock was invoked exactly once).
      3. force=True reaches the API layer so its matching guard also
         gets the signal (would otherwise reject with the same message).
    """
    config_path = tmp_path / "config.yaml"
    write_minimal_config(config_path, project_name="my-project")

    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock(return_value=None)
    with patch("httpx.post", return_value=mock_response) as mock_post:
        result = CliRunner().invoke(
            main, ["register", str(config_path), "--force"]
        )

    # Guard silent.
    assert "template default" not in result.output
    # Clean exit — mocked httpx returned 2xx-equivalent.
    assert result.exit_code == 0
    # Exactly one POST.
    mock_post.assert_called_once()
    # Payload carries force=True and the resolved config path.
    payload = mock_post.call_args.kwargs["json"]
    assert payload["force"] is True
    assert payload["config_path"].endswith("config.yaml")


def test_init_template_uses_shared_placeholder_constant() -> None:
    """`sagex init`'s scaffolded config.yaml must write the same placeholder
    name that the register-time guards check for.

    If ``_CONFIG_TEMPLATE`` and ``TEMPLATE_PLACEHOLDER_NAME`` drift, `init`
    could write a placeholder the guards don't recognise (register goes
    through silently) or the guards could block a placeholder the
    template doesn't actually write (legitimate re-inits rejected).

    We assert the scaffold contains the exact line the guard reads — a
    direct contract between the init path and the register path.
    """
    from sagex.cli import _CONFIG_TEMPLATE
    from sagex.constants import TEMPLATE_PLACEHOLDER_NAME

    assert f"name: {TEMPLATE_PLACEHOLDER_NAME}\n" in _CONFIG_TEMPLATE


def test_hook_template_does_not_suppress_stderr() -> None:
    """The generated hook template must NOT redirect stderr to /dev/null.

    Issue #19's notify-warning fix only works if stderr from ``sagex
    notify`` actually reaches the user's terminal.  An accidental
    re-introduction of ``2>/dev/null`` in ``_HOOK_TEMPLATE`` would
    silently swallow the new warning and reopen the footgun.  This
    asserts the contract between (CLI warning emission) and
    (hook script visibility) at the template level.
    """
    from sagex.cli import _HOOK_TEMPLATE

    assert "2>/dev/null" not in _HOOK_TEMPLATE, (
        "The hook template must not redirect stderr away — config-parse "
        "warnings need to reach the user's terminal."
    )
    # ``|| true`` must remain so a notify failure doesn't break the git hook.
    assert "|| true" in _HOOK_TEMPLATE


def test_configure_logging_honours_env_level() -> None:
    """``configure_logging()`` (no arg) picks up ``AGENTIS_LOG_LEVEL``.

    README documents this env var; the test exists so documentation and
    implementation can't drift again — previously the README listed
    AGENTIS_LOG_LEVEL as a supported override while the code ignored it.
    """
    import logging as stdlogging
    import os

    from sagex.logging import configure_logging

    saved_level = stdlogging.getLogger().level
    saved_env = os.environ.get("AGENTIS_LOG_LEVEL")
    try:
        os.environ["AGENTIS_LOG_LEVEL"] = "DEBUG"
        configure_logging()
        assert stdlogging.getLogger().level == stdlogging.DEBUG

        os.environ["AGENTIS_LOG_LEVEL"] = "WARNING"
        configure_logging()
        assert stdlogging.getLogger().level == stdlogging.WARNING

        # Explicit arg always wins over the env var.
        configure_logging(level=stdlogging.ERROR)
        assert stdlogging.getLogger().level == stdlogging.ERROR

        # Invalid env value falls back to INFO (not a crash).
        os.environ["AGENTIS_LOG_LEVEL"] = "NOT_A_LEVEL"
        configure_logging()
        assert stdlogging.getLogger().level == stdlogging.INFO
    finally:
        if saved_env is None:
            os.environ.pop("AGENTIS_LOG_LEVEL", None)
        else:
            os.environ["AGENTIS_LOG_LEVEL"] = saved_env
        stdlogging.getLogger().setLevel(saved_level)


# ---------------------------------------------------------------------------
# Issue #18: `sagex status <unknown>` must not silently report zeros.
# ---------------------------------------------------------------------------

def test_status_404_surfaces_actionable_error() -> None:
    """A 404 from /projects/<name>/... must produce a clear error, not zeros.

    Old behaviour: ``.json().get("episodes", [])`` on a 404 response
    returned [] because the error body is ``{"detail": "Project not found"}``.
    The CLI then printed "0 rules, 0 tokens, no episodes" — indistinguishable
    from a legitimately quiet project.
    """
    import httpx

    def _fake_get(url: str, **kwargs: object) -> MagicMock:
        resp = MagicMock(spec=httpx.Response)
        if url.endswith("/projects"):
            resp.status_code = 200
            resp.json = MagicMock(return_value={"projects": ["real-proj"]})
            resp.raise_for_status = MagicMock(return_value=None)
        else:
            resp.status_code = 404
            resp.json = MagicMock(return_value={"detail": "Project 'bogus' not found"})
            resp.raise_for_status = MagicMock(
                side_effect=httpx.HTTPStatusError(
                    "404", request=MagicMock(), response=resp,
                )
            )
        return resp

    with patch("httpx.get", side_effect=_fake_get):
        result = CliRunner().invoke(main, ["status", "bogus"])

    assert result.exit_code != 0
    # Surface the typo-hint so the user doesn't have to read the server log.
    assert "bogus" in result.output
    assert "not found" in result.output.lower()
    assert "real-proj" in result.output  # suggestion from /projects list


# ---------------------------------------------------------------------------
# Issue #19: `sagex notify` must warn on malformed config instead of silently
# falling back to the repo directory name.
# ---------------------------------------------------------------------------

def test_notify_warns_on_malformed_config(tmp_path: Path) -> None:
    """A broken .agents/config.yaml triggers a visible stderr warning."""
    agents = tmp_path / ".agents"
    agents.mkdir()
    # Write syntactically valid YAML but missing required pydantic fields.
    (agents / "config.yaml").write_text("name: broken-proj\n")  # no repo_root etc.

    mock_response = MagicMock()
    mock_response.raise_for_status = MagicMock(return_value=None)
    with patch("httpx.post", return_value=mock_response):
        result = CliRunner().invoke(
            main, ["notify", "--event", "commit", "--repo", str(tmp_path)]
        )

    # Click ≥ 8.x exposes ``result.stderr`` separately regardless of
    # whether the runner also mixed it into ``result.output``.  Asserting
    # against ``result.stderr`` directly proves the warning landed on the
    # correct stream — which matters because the hook template relies on
    # stderr being visible (issue #19) — without coupling to
    # ``result.output``'s mixing default that varied across Click
    # versions (and was removed entirely in 8.3+).
    assert "warning:" in result.stderr.lower()
    assert "failed to load" in result.stderr.lower()
    assert tmp_path.name in result.stderr


def test_notify_attaches_git_context_to_post_body(tmp_path: Path) -> None:
    """``sagex notify`` must compute git context locally and attach it to the
    POST body — that's the architectural fix for the bug where every
    hook event arrived at the runtime with file_paths=[] and diff=None.

    We patch ``sagex.watcher.git_context_for_event`` to return a known
    triple, then invoke the CLI and inspect the JSON body that landed on
    ``httpx.post``.  This proves the wire format carries the diff
    end-to-end without depending on a real git repo or a live runtime.
    """
    captured: dict[str, object] = {}

    def _capture_post(url: str, json: dict[str, object], timeout: float):  # type: ignore[no-untyped-def]
        captured["url"] = url
        captured["json"] = json
        resp = MagicMock()
        resp.raise_for_status = MagicMock(return_value=None)
        return resp

    fake_files = ["src/foo.py", "src/bar.py"]
    fake_diff = "diff --git a/src/foo.py b/src/foo.py\n+x = 1\n"
    fake_ctx = "@@ ctx @@\n+x = 1\n"

    with patch("httpx.post", side_effect=_capture_post), patch(
        "sagex.watcher.git_context_for_event",
        return_value=(fake_files, fake_diff, fake_ctx),
    ):
        result = CliRunner().invoke(
            main, ["notify", "--event", "commit", "--repo", str(tmp_path)]
        )

    assert result.exit_code == 0, result.output
    body = captured["json"]
    assert isinstance(body, dict)
    assert body["event_type"] == "commit"
    assert body["file_paths"] == fake_files
    assert body["diff"] == fake_diff
    assert body["diff_context"] == fake_ctx
