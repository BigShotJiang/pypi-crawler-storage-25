"""Unit tests for ClaudeCodePassthroughProvider.

Mocks out ``shutil.which``, ``subprocess.run`` (for the version pre-flight),
and ``asyncio.create_subprocess_exec`` so no real ``claude`` binary is
touched.  The real binary is exercised only by the nightly E2E smoke test
(gated behind ``@pytest.mark.llm``).
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from sagex.llm.providers.base import (
    ProviderAuthError,
    ProviderCallError,
    ProviderUnavailableError,
)
from sagex.llm.providers.claude_code import ClaudeCodePassthroughProvider

# ---------------------------------------------------------------------------
# Pre-flight construction tests
# ---------------------------------------------------------------------------

def test_raises_unavailable_when_binary_missing() -> None:
    """shutil.which returning None -> ProviderUnavailableError with install hint."""
    with patch("sagex.llm.providers.claude_code.shutil.which", return_value=None):
        with pytest.raises(ProviderUnavailableError, match="not found on PATH"):
            ClaudeCodePassthroughProvider()


def test_raises_unavailable_when_version_fails() -> None:
    """claude --version exiting nonzero -> ProviderUnavailableError."""
    fake_result = MagicMock(returncode=1, stdout="", stderr="oh no")
    with patch("sagex.llm.providers.claude_code.shutil.which", return_value="/fake/claude"):
        with patch("sagex.llm.providers.claude_code.subprocess.run", return_value=fake_result):
            with pytest.raises(ProviderUnavailableError, match="exited 1"):
                ClaudeCodePassthroughProvider()


def test_construction_succeeds_when_version_ok() -> None:
    """Binary present + --version succeeds -> provider constructs cleanly."""
    fake_result = MagicMock(returncode=0, stdout="claude 1.2.3\n", stderr="")
    with patch("sagex.llm.providers.claude_code.shutil.which", return_value="/fake/claude"):
        with patch("sagex.llm.providers.claude_code.subprocess.run", return_value=fake_result):
            p = ClaudeCodePassthroughProvider()
    assert p.name == "claude_code"
    assert p._version == "claude 1.2.3"


def test_supports_known_models_only() -> None:
    fake_result = MagicMock(returncode=0, stdout="claude 1.0\n", stderr="")
    with patch("sagex.llm.providers.claude_code.shutil.which", return_value="/fake/claude"):
        with patch("sagex.llm.providers.claude_code.subprocess.run", return_value=fake_result):
            p = ClaudeCodePassthroughProvider()
    assert p.supports_model("claude-sonnet-4-6") is True
    assert p.supports_model("gpt-5") is False


# ---------------------------------------------------------------------------
# call() — subprocess interaction
# ---------------------------------------------------------------------------

def _provider() -> ClaudeCodePassthroughProvider:
    fake_result = MagicMock(returncode=0, stdout="claude 1.0\n", stderr="")
    with patch("sagex.llm.providers.claude_code.shutil.which", return_value="/fake/claude"):
        with patch("sagex.llm.providers.claude_code.subprocess.run", return_value=fake_result):
            return ClaudeCodePassthroughProvider()


def _make_proc(returncode: int, stdout: bytes, stderr: bytes = b"") -> MagicMock:
    proc = MagicMock()
    proc.returncode = returncode
    proc.communicate = AsyncMock(return_value=(stdout, stderr))
    return proc


async def test_call_parses_json_and_returns_call_result() -> None:
    provider = _provider()
    payload = {
        "content": "hello from claude",
        "model": "claude-sonnet-4-6",
        "usage": {
            "input_tokens": 42,
            "output_tokens": 17,
            "cache_read_input_tokens": 10,
            "cache_creation_input_tokens": 5,
        },
    }
    proc = _make_proc(0, json.dumps(payload).encode())
    with patch(
        "sagex.llm.providers.claude_code.asyncio.create_subprocess_exec",
        return_value=proc,
    ):
        result = await provider.call(
            system="be helpful",
            user="hi",
            model="claude-sonnet-4-6",
            max_tokens=2048,
            temperature=0.2,
        )
    assert result.text == "hello from claude"
    assert result.input_tokens == 42
    assert result.output_tokens == 17
    assert result.cache_read_tokens == 10
    assert result.cache_write_tokens == 5
    assert result.model == "claude-sonnet-4-6"
    # stdin receives the user prompt (NOT argv — per locked decision #10)
    proc.communicate.assert_awaited_once_with(input=b"hi")


async def test_call_raises_auth_error_on_login_failure() -> None:
    provider = _provider()
    proc = _make_proc(1, b"", b"Please run `claude login` to authenticate.")
    with patch(
        "sagex.llm.providers.claude_code.asyncio.create_subprocess_exec",
        return_value=proc,
    ):
        with pytest.raises(ProviderAuthError, match="claude login"):
            await provider.call(
                system="s", user="u", model="claude-sonnet-4-6",
                max_tokens=1, temperature=0.2,
            )


async def test_call_raises_call_error_on_nonzero_exit() -> None:
    provider = _provider()
    proc = _make_proc(2, b"", b"boom")
    with patch(
        "sagex.llm.providers.claude_code.asyncio.create_subprocess_exec",
        return_value=proc,
    ):
        with pytest.raises(ProviderCallError, match="exited 2"):
            await provider.call(
                system="s", user="u", model="claude-sonnet-4-6",
                max_tokens=1, temperature=0.2,
            )


async def test_call_raises_call_error_on_malformed_json() -> None:
    provider = _provider()
    proc = _make_proc(0, b"<!DOCTYPE html>not json")
    with patch(
        "sagex.llm.providers.claude_code.asyncio.create_subprocess_exec",
        return_value=proc,
    ):
        with pytest.raises(ProviderCallError, match="non-JSON"):
            await provider.call(
                system="s", user="u", model="claude-sonnet-4-6",
                max_tokens=1, temperature=0.2,
            )


# ---------------------------------------------------------------------------
# One-time WARNING when ignored fields are set
# ---------------------------------------------------------------------------

async def test_max_tokens_warning_logged_once(caplog: pytest.LogCaptureFixture) -> None:
    """Setting max_tokens logs a one-time WARNING; subsequent calls are silent."""
    import logging
    provider = _provider()
    proc = _make_proc(0, json.dumps({"content": "ok", "usage": {}}).encode())
    with patch(
        "sagex.llm.providers.claude_code.asyncio.create_subprocess_exec",
        return_value=proc,
    ):
        with caplog.at_level(logging.WARNING, logger="sagex.llm.providers.claude_code"):
            await provider.call(
                system="s", user="u", model="claude-sonnet-4-6",
                max_tokens=2048, temperature=0.2,
            )
            await provider.call(
                system="s", user="u", model="claude-sonnet-4-6",
                max_tokens=2048, temperature=0.2,
            )

    warnings = [r for r in caplog.records if "ignores max_tokens" in r.getMessage()]
    assert len(warnings) == 1, f"expected one warning, got {len(warnings)}"


# ---------------------------------------------------------------------------
# SECURITY: user prompt must NOT appear in argv
# ---------------------------------------------------------------------------

async def test_user_prompt_passed_via_stdin_not_argv() -> None:
    """Regression guard for locked decision #10: /proc/<pid>/cmdline leak.

    The user prompt must be written to stdin and `-` (not the prompt) must
    appear as the argv slot after `-p`.
    """
    provider = _provider()
    proc = _make_proc(0, json.dumps({"content": "ok", "usage": {}}).encode())
    secret_prompt = "my-sensitive-diff-contents-abc123"
    with patch(
        "sagex.llm.providers.claude_code.asyncio.create_subprocess_exec",
        return_value=proc,
    ) as m:
        await provider.call(
            system="s", user=secret_prompt,
            model="claude-sonnet-4-6", max_tokens=1, temperature=0.2,
        )
    call_args, _call_kwargs = m.call_args
    argv = list(call_args)
    assert secret_prompt not in argv, (
        "user prompt must not appear in argv — "
        "that leaks to /proc/<pid>/cmdline on multi-user systems"
    )
    # Confirm `-` is the placeholder after `-p`
    p_index = argv.index("-p")
    assert argv[p_index + 1] == "-", "`-p -` signals 'read prompt from stdin'"


async def test_temperature_warning_logged_once(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Non-default temperature triggers one WARNING; subsequent calls silent."""
    import logging

    provider = _provider()
    proc = _make_proc(0, json.dumps({"content": "ok", "usage": {}}).encode())
    with patch(
        "sagex.llm.providers.claude_code.asyncio.create_subprocess_exec",
        return_value=proc,
    ):
        with caplog.at_level(
            logging.WARNING, logger="sagex.llm.providers.claude_code"
        ):
            await provider.call(
                system="s", user="u", model="claude-sonnet-4-6",
                max_tokens=0, temperature=0.9,   # non-default temp
            )
            await provider.call(
                system="s", user="u", model="claude-sonnet-4-6",
                max_tokens=0, temperature=0.9,
            )

    warnings = [r for r in caplog.records if "ignores temperature" in r.getMessage()]
    assert len(warnings) == 1


async def test_call_handles_non_string_content_field() -> None:
    """Some claude versions nest content blocks; provider falls back to JSON."""
    provider = _provider()
    nested_content = [{"type": "text", "text": "hi"}]
    payload = {"content": nested_content, "usage": {}}
    proc = _make_proc(0, json.dumps(payload).encode())
    with patch(
        "sagex.llm.providers.claude_code.asyncio.create_subprocess_exec",
        return_value=proc,
    ):
        result = await provider.call(
            system="s", user="u", model="claude-sonnet-4-6",
            max_tokens=0, temperature=0.2,
        )
    # Fallback stringifies the list, so the text is a valid JSON serialization.
    assert json.loads(result.text) == nested_content


# ---------------------------------------------------------------------------
# is_retryable_error classification (review fix #5)
# ---------------------------------------------------------------------------


def test_is_retryable_error_classification() -> None:
    """Auth = terminal; ProviderCallError = retryable; other = no-retry."""
    provider = _provider()
    from sagex.llm.providers.base import ProviderAuthError

    assert provider.is_retryable_error(ProviderAuthError("no")) is False
    assert provider.is_retryable_error(ProviderCallError("transient")) is True
    assert provider.is_retryable_error(ValueError("unrelated")) is False


# ---------------------------------------------------------------------------
# Timeout path — hung subprocess is killed + ProviderCallError surfaces
# ---------------------------------------------------------------------------


async def test_call_times_out_and_kills_subprocess() -> None:
    """When claude hangs, asyncio.wait_for fires, we kill the subprocess,
    and surface ProviderCallError — never block the event loop forever.
    """
    provider = _provider()

    # A subprocess that never returns from communicate.
    proc = MagicMock()
    proc.returncode = None
    proc.kill = MagicMock()
    proc.wait = AsyncMock(return_value=0)

    async def _hang(**_kwargs: object) -> tuple[bytes, bytes]:
        import asyncio as _asyncio
        await _asyncio.sleep(3600)
        return (b"", b"")  # pragma: no cover

    proc.communicate = AsyncMock(side_effect=_hang)

    with patch(
        "sagex.llm.providers.claude_code.asyncio.create_subprocess_exec",
        return_value=proc,
    ):
        # Patch the timeout constant down so the test doesn't actually wait 120s.
        with patch("sagex.llm.providers.claude_code._CALL_TIMEOUT_SECONDS", 0.05):
            with pytest.raises(ProviderCallError, match="did not return within"):
                await provider.call(
                    system="s", user="u", model="claude-sonnet-4-6",
                    max_tokens=1, temperature=0.2,
                )

    proc.kill.assert_called_once()
    proc.wait.assert_awaited_once()
