"""Unit tests specific to AnthropicAPIProvider (refactor + is_retryable_error).

The main end-to-end coverage for the Anthropic path lives in
``test_budget.py`` (the pre-existing budget/cache/retry suite).  This file
exercises the provider's own branches that aren't hit there.
"""

from __future__ import annotations

import anthropic
from conftest import make_http_response

from sagex.llm.providers.anthropic_api import AnthropicAPIProvider
from sagex.llm.providers.base import ProviderCallError


def _provider() -> AnthropicAPIProvider:
    return AnthropicAPIProvider(api_key="stub-key-for-tests")


# ---------------------------------------------------------------------------
# is_retryable_error — per-provider retry classification (review fix #5)
# ---------------------------------------------------------------------------


def test_rate_limit_is_retryable() -> None:
    p = _provider()
    exc = anthropic.RateLimitError(
        message="slow down", response=make_http_response(429), body=None,
    )
    assert p.is_retryable_error(exc) is True


def test_server_error_is_retryable() -> None:
    p = _provider()
    exc = anthropic.APIStatusError(
        message="server down", response=make_http_response(503), body=None,
    )
    assert p.is_retryable_error(exc) is True


def test_client_error_is_not_retryable() -> None:
    p = _provider()
    exc = anthropic.APIStatusError(
        message="bad request", response=make_http_response(400), body=None,
    )
    assert p.is_retryable_error(exc) is False


def test_provider_call_error_is_retryable() -> None:
    p = _provider()
    assert p.is_retryable_error(ProviderCallError("x")) is True


def test_unrelated_exception_is_not_retryable() -> None:
    p = _provider()
    assert p.is_retryable_error(ValueError("nope")) is False


def test_supports_known_models_only() -> None:
    p = _provider()
    assert p.supports_model("claude-sonnet-4-6") is True
    assert p.supports_model("claude-haiku-4-5") is True
    assert p.supports_model("gpt-5") is False
