"""Phase 12 acceptance criteria: NPM wrapper package structure and validity."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

REPO_ROOT = Path(__file__).parent.parent
NPM_DIR = REPO_ROOT / "agent-runtime-npm"


# ---------------------------------------------------------------------------
# File structure
# ---------------------------------------------------------------------------


def test_package_json_exists() -> None:
    assert (NPM_DIR / "package.json").exists()


def test_bin_script_exists() -> None:
    assert (NPM_DIR / "bin" / "agent-runtime.js").exists()


def test_postinstall_script_exists() -> None:
    assert (NPM_DIR / "scripts" / "postinstall.js").exists()


# ---------------------------------------------------------------------------
# package.json content
# ---------------------------------------------------------------------------


def test_package_json_is_valid_json() -> None:
    text = (NPM_DIR / "package.json").read_text()
    data = json.loads(text)
    assert isinstance(data, dict)


def test_package_json_has_required_fields() -> None:
    data = json.loads((NPM_DIR / "package.json").read_text())
    assert "name" in data
    assert "version" in data
    assert "bin" in data
    assert "scripts" in data
    assert "postinstall" in data["scripts"]
    assert "engines" in data
    assert "node" in data["engines"]


def test_package_json_bin_points_to_existing_file() -> None:
    data = json.loads((NPM_DIR / "package.json").read_text())
    for _cmd, rel_path in data["bin"].items():
        assert (NPM_DIR / rel_path).exists(), f"bin target not found: {rel_path}"


# ---------------------------------------------------------------------------
# bin/agent-runtime.js content
# ---------------------------------------------------------------------------


def test_bin_script_is_executable_node() -> None:
    text = (NPM_DIR / "bin" / "agent-runtime.js").read_text()
    assert "#!/usr/bin/env node" in text


def test_bin_script_forwards_argv() -> None:
    text = (NPM_DIR / "bin" / "agent-runtime.js").read_text()
    assert "process.argv" in text
    assert "spawn" in text or "spawnSync" in text or "exec" in text


# ---------------------------------------------------------------------------
# scripts/postinstall.js content
# ---------------------------------------------------------------------------


def test_postinstall_creates_venv() -> None:
    text = (NPM_DIR / "scripts" / "postinstall.js").read_text()
    assert "venv" in text
    assert "findPython" in text or "python" in text.lower()


def test_postinstall_calls_pip_install() -> None:
    text = (NPM_DIR / "scripts" / "postinstall.js").read_text()
    assert "pip" in text
    assert "sagex" in text


# ---------------------------------------------------------------------------
# npm pack (only run if npm is available)
# ---------------------------------------------------------------------------


def test_npm_pack_dry_run() -> None:
    """npm pack --dry-run validates the package without creating a tarball."""
    npm = shutil.which("npm")
    if npm is None:
        import pytest
        pytest.skip("npm not available in this environment")

    result = subprocess.run(
        [npm, "pack", "--dry-run"],
        cwd=str(NPM_DIR),
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, (
        f"npm pack --dry-run failed:\n{result.stdout}\n{result.stderr}"
    )


# ---------------------------------------------------------------------------
# Supporting scripts
# ---------------------------------------------------------------------------


def test_bump_version_script_exists() -> None:
    assert (REPO_ROOT / "scripts" / "bump-version.sh").exists()


def test_publish_workflow_exists() -> None:
    assert (REPO_ROOT / ".github" / "workflows" / "publish.yml").exists()
