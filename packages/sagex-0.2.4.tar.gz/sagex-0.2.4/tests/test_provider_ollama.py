"""Unit tests for OllamaProvider.

Uses ``httpx.MockTransport`` so no real server is needed.  The E2E smoke
test against a live ``ollama serve`` is opt-in via ``@pytest.mark.llm``.
"""

from __future__ import annotations

import json

import httpx
import pytest

from sagex.llm.providers.base import (
    ProviderCallError,
    ProviderUnavailableError,
)
from sagex.llm.providers.ollama import OllamaProvider

# ---------------------------------------------------------------------------
# Pre-flight
# ---------------------------------------------------------------------------


def test_raises_unavailable_when_server_unreachable() -> None:
    """No server on localhost -> ProviderUnavailableError with install hint."""
    with pytest.raises(ProviderUnavailableError, match="not reachable"):
        # 1 = port unlikely to be listening
        OllamaProvider(base_url="http://localhost:1")


# ---------------------------------------------------------------------------
# call() via MockTransport
# ---------------------------------------------------------------------------


def _make_provider(handler: httpx.MockTransport) -> OllamaProvider:
    return OllamaProvider(client=httpx.AsyncClient(transport=handler))


async def test_call_parses_ollama_chat_response() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/chat"
        body = json.loads(request.content)
        assert body["model"] == "llama3.1:8b"
        assert body["messages"] == [
            {"role": "system", "content": "be helpful"},
            {"role": "user", "content": "hi"},
        ]
        assert body["stream"] is False
        assert body["options"]["num_predict"] == 512
        return httpx.Response(200, json={
            "model": "llama3.1:8b",
            "message": {"role": "assistant", "content": "hello from llama"},
            "prompt_eval_count": 42,
            "eval_count": 17,
        })

    p = _make_provider(httpx.MockTransport(handler))
    result = await p.call(
        system="be helpful",
        user="hi",
        model="llama3.1:8b",
        max_tokens=512,
        temperature=0.2,
    )
    assert result.text == "hello from llama"
    assert result.input_tokens == 42
    assert result.output_tokens == 17
    assert result.cache_read_tokens == 0
    assert result.cache_write_tokens == 0
    assert result.model == "llama3.1:8b"


async def test_call_raises_on_http_error() -> None:
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(500, text="server exploded")

    p = _make_provider(httpx.MockTransport(handler))
    with pytest.raises(ProviderCallError, match="HTTP 500"):
        await p.call(
            system="s", user="u", model="llama3.1:8b",
            max_tokens=1, temperature=0.2,
        )


async def test_call_raises_on_connection_error() -> None:
    def handler(_request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("boom")

    p = _make_provider(httpx.MockTransport(handler))
    with pytest.raises(ProviderCallError, match="request failed"):
        await p.call(
            system="s", user="u", model="llama3.1:8b",
            max_tokens=1, temperature=0.2,
        )


def test_supports_any_model_name() -> None:
    """Ollama has no allowlist — user-managed model registry."""
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={})
    p = _make_provider(httpx.MockTransport(handler))
    assert p.supports_model("custom-finetuned:latest") is True
    assert p.supports_model("llama3.1:8b") is True
    # Even a totally made-up name returns True; Ollama will error cleanly
    # at call time if the model isn't pulled.
    assert p.supports_model("no-such-model") is True


def test_name() -> None:
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={})
    p = _make_provider(httpx.MockTransport(handler))
    assert p.name == "ollama"


# ---------------------------------------------------------------------------
# aclose() — resource cleanup (review fix #3)
# ---------------------------------------------------------------------------


async def test_aclose_releases_async_client() -> None:
    """After aclose(), the underlying httpx.AsyncClient is closed."""
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={})
    p = _make_provider(httpx.MockTransport(handler))
    assert p._client.is_closed is False
    await p.aclose()
    assert p._client.is_closed is True
