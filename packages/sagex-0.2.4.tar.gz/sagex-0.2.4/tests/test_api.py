"""Phase 8 acceptance criteria: Registration API."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from pathlib import Path

import pytest
import yaml
from httpx import ASGITransport, AsyncClient

from sagex.api.server import ProjectRegistry, create_app
from sagex.config import (
    AgentConfig,
    BudgetConfig,
    KnowledgeConfig,
    ProjectConfig,
    RunnerConfig,
    TestConfig,
    WatchConfig,
)
from sagex.event_bus import EventBus
from sagex.knowledge.rules_db import PendingApproval, RulesDB
from sagex.watcher import WatcherManager

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_project_config(name: str, tmp_path: Path) -> ProjectConfig:
    return ProjectConfig(
        name=name,
        repo_root=str(tmp_path),
        watch=WatchConfig(paths=[str(tmp_path)]),
        test=TestConfig(command="echo pass"),
        agent=AgentConfig(),
        runner=RunnerConfig(),
        knowledge=KnowledgeConfig(
            db_path=str(tmp_path / f"{name}_rules.db"),
            vector_path=str(tmp_path / "vectors"),
        ),
        budget=BudgetConfig(),
    )


@pytest.fixture
async def client(tmp_path: Path) -> AsyncIterator[AsyncClient]:
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        yield ac


@pytest.fixture
async def client_with_project(
    tmp_path: Path,
) -> AsyncIterator[tuple[AsyncClient, ProjectConfig]]:
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    config = _make_project_config("test-proj", tmp_path)
    registry.register(config)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        yield ac, config


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


async def test_health_returns_200(client: AsyncClient) -> None:
    resp = await client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "ok"
    assert "version" in data


# ---------------------------------------------------------------------------
# Project registration
# ---------------------------------------------------------------------------


async def test_register_project_appears_in_list(tmp_path: Path) -> None:
    """Register a project → it appears in GET /projects."""
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    # config_path must be .agents/config.yaml (security requirement)
    agents_dir = tmp_path / ".agents"
    agents_dir.mkdir()
    config_path = agents_dir / "config.yaml"
    config_path.write_text(
        yaml.dump(
            {
                "name": "my-proj",
                "repo_root": str(tmp_path),
                "watch": {"paths": [str(tmp_path)]},
                "test": {"command": "echo pass"},
            }
        )
    )

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post("/projects/register", json={"config_path": str(config_path)})
        assert resp.status_code == 201
        assert resp.json()["name"] == "my-proj"

        resp = await ac.get("/projects")
        assert "my-proj" in resp.json()["projects"]


async def test_register_refuses_template_placeholder_name(tmp_path: Path) -> None:
    """The API route mirrors the CLI guard: `name: my-project` is refused.

    Non-CLI clients (CI scripts, custom SDKs, direct curl) must get the
    same protection against the template-placeholder footgun as the CLI's
    `sagex register` provides.  Bypasses with force=true.
    """
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    app = create_app(bus, WatcherManager(bus), ProjectRegistry())

    agents_dir = tmp_path / ".agents"
    agents_dir.mkdir()
    config_path = agents_dir / "config.yaml"
    config_path.write_text(
        yaml.dump(
            {
                "name": "my-project",  # the template default
                "repo_root": str(tmp_path),
                "watch": {"paths": [str(tmp_path)]},
                "test": {"command": "echo pass"},
            }
        )
    )

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        # Default path → rejected with 400 and an actionable message.
        resp = await ac.post(
            "/projects/register", json={"config_path": str(config_path)}
        )
        assert resp.status_code == 400
        detail = resp.json()["detail"].lower()
        # Message must name the offending placeholder so the user knows
        # what to change, and must mention the ``force`` escape hatch so
        # scripted callers discover it.  We match on the semantic tokens
        # rather than exact wording so cosmetic message edits don't break
        # this test.
        assert "my-project" in detail
        assert "force" in detail

        # force=true → accepted.
        resp = await ac.post(
            "/projects/register",
            json={"config_path": str(config_path), "force": True},
        )
        assert resp.status_code == 201
        assert resp.json()["name"] == "my-project"


async def test_register_rejects_arbitrary_config_path(tmp_path: Path) -> None:
    """register endpoint must reject config paths outside .agents/config.yaml."""
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    app = create_app(bus, WatcherManager(bus), ProjectRegistry())

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        # Attempt to read an arbitrary file (simulates path-traversal attack)
        resp = await ac.post("/projects/register", json={"config_path": "/etc/passwd"})
        assert resp.status_code == 400

        # Also reject a valid-looking path that lacks .agents directory
        bad_path = tmp_path / "config.yaml"
        bad_path.write_text("name: evil\n")
        resp = await ac.post("/projects/register", json={"config_path": str(bad_path)})
        assert resp.status_code == 400


# ---------------------------------------------------------------------------
# Issue #13: config.yaml cannot direct filesystem writes outside repo_root
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "field,bad_path",
    [
        ("db_path", "/etc/malicious.db"),                  # absolute
        ("db_path", "../../outside.db"),                   # traversal
        ("db_path", "subdir/../../escape.db"),             # mid-path traversal
        ("vector_path", "/var/malicious/vectors"),         # absolute
        ("vector_path", "../../outside-vectors"),          # traversal
        ("vector_path", "subdir/../../escape-vectors"),    # mid-path traversal
    ],
)
async def test_register_rejects_unsafe_knowledge_paths(
    tmp_path: Path, field: str, bad_path: str
) -> None:
    """knowledge.{db_path,vector_path} pointing outside repo_root must be rejected at register."""
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    app = create_app(bus, WatcherManager(bus), ProjectRegistry())

    agents_dir = tmp_path / ".agents"
    agents_dir.mkdir()
    config_path = agents_dir / "config.yaml"
    knowledge: dict[str, str] = {
        "db_path": ".agents/knowledge/rules.db",
        "vector_path": ".agents/knowledge/vectors",
    }
    knowledge[field] = bad_path
    config_path.write_text(
        yaml.dump(
            {
                "name": "evil-proj",
                "repo_root": str(tmp_path),
                "watch": {"paths": [str(tmp_path)]},
                "test": {"command": "echo pass"},
                "knowledge": knowledge,
            }
        )
    )

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/projects/register", json={"config_path": str(config_path)}
        )
        assert resp.status_code == 400
        assert field in resp.json()["detail"]


async def test_register_rejects_mismatched_repo_root(tmp_path: Path) -> None:
    """A hostile config that sets ``repo_root: /`` to launder relative knowledge
    paths into arbitrary filesystem writes must be rejected at register time.
    The trust anchor is the directory containing ``.agents/config.yaml``, not
    the user-controlled ``repo_root`` field.
    """
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    app = create_app(bus, WatcherManager(bus), ProjectRegistry())

    agents_dir = tmp_path / ".agents"
    agents_dir.mkdir()
    config_path = agents_dir / "config.yaml"
    config_path.write_text(
        yaml.dump(
            {
                "name": "evil-proj",
                # Deliberately point repo_root somewhere other than tmp_path
                # so that relative knowledge paths would resolve outside the
                # config's owning directory.
                "repo_root": "/",
                "watch": {"paths": [str(tmp_path)]},
                "test": {"command": "echo pass"},
                "knowledge": {
                    "db_path": "etc/rules.db",
                    "vector_path": "etc/vectors",
                },
            }
        )
    )

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/projects/register", json={"config_path": str(config_path)}
        )
        assert resp.status_code == 400
        assert "repo_root" in resp.json()["detail"]


async def test_register_persists_resolved_absolute_paths(tmp_path: Path) -> None:
    """After successful registration the registry holds *absolute* knowledge
    paths, not the relative form the config originally specified.

    The validator resolves ``db_path`` / ``vector_path`` against the
    derived repo root and writes the resolved absolute string back into
    ``config.knowledge``.  Without that, downstream openers
    (``RulesDB(...)``, ``VectorDB(...)``) would re-interpret the
    relative form against the server's current working directory and
    could write outside the validated containment tree.
    """
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    app = create_app(bus, WatcherManager(bus), registry)

    agents_dir = tmp_path / ".agents"
    agents_dir.mkdir()
    config_path = agents_dir / "config.yaml"
    config_path.write_text(
        yaml.dump(
            {
                "name": "abs-paths-proj",
                "repo_root": str(tmp_path),
                "watch": {"paths": [str(tmp_path)]},
                "test": {"command": "echo pass"},
                "knowledge": {
                    "db_path": ".agents/knowledge/rules.db",
                    "vector_path": ".agents/knowledge/vectors",
                },
            }
        )
    )

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/projects/register", json={"config_path": str(config_path)}
        )
        assert resp.status_code == 201

    cfg = registry.get("abs-paths-proj")
    assert cfg is not None
    db_path = Path(cfg.knowledge.db_path)
    vec_path = Path(cfg.knowledge.vector_path)
    # Both fields must have been replaced with absolute paths anchored
    # at the validated repo root.
    assert db_path.is_absolute(), f"db_path stayed relative: {db_path}"
    assert vec_path.is_absolute(), f"vector_path stayed relative: {vec_path}"
    derived_root = config_path.parent.parent.resolve()
    assert db_path == derived_root / ".agents/knowledge/rules.db"
    assert vec_path == derived_root / ".agents/knowledge/vectors"


# ---------------------------------------------------------------------------
# Issue #16: malformed config surfaces the underlying parse/validation error
# ---------------------------------------------------------------------------

async def test_register_malformed_config_surfaces_error(tmp_path: Path) -> None:
    """Invalid *config* (missing required field) → 400 with the underlying
    pydantic ValidationError detail in the response body. The YAML itself
    parses cleanly here; what fails is schema validation."""
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    app = create_app(bus, WatcherManager(bus), ProjectRegistry())

    agents_dir = tmp_path / ".agents"
    agents_dir.mkdir()
    config_path = agents_dir / "config.yaml"
    # Missing required ``repo_root`` field — pydantic raises a ValidationError
    # naming the field.  The API must include that detail so the user knows
    # what's wrong without having to read the server log.
    config_path.write_text(
        yaml.dump(
            {
                "name": "broken-proj",
                "watch": {"paths": [str(tmp_path)]},
                "test": {"command": "echo pass"},
            }
        )
    )

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/projects/register", json={"config_path": str(config_path)}
        )
        assert resp.status_code == 400
        detail = resp.json()["detail"]
        # The surfaced message must mention the missing field so the user
        # can fix the config without grepping the server log.
        assert "repo_root" in detail, (
            f"Expected detail to name the missing field; got: {detail!r}"
        )


async def test_deregister_project_removes_it(client: AsyncClient) -> None:
    """Register then deregister → project is gone."""
    # inject directly via registry
    registry = client._transport.app.state.registry  # type: ignore[attr-defined]
    config = ProjectConfig(
        name="gone-proj",
        repo_root="/tmp",
        watch=WatchConfig(paths=["/tmp"]),
        test=TestConfig(command="echo pass"),
    )
    registry.register(config)

    resp = await client.get("/projects")
    assert "gone-proj" in resp.json()["projects"]

    resp = await client.delete("/projects/gone-proj")
    assert resp.status_code == 200

    resp = await client.get("/projects")
    assert "gone-proj" not in resp.json()["projects"]


async def test_deregister_unknown_project_returns_404(client: AsyncClient) -> None:
    resp = await client.delete("/projects/does-not-exist")
    assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Notify → event on bus
# ---------------------------------------------------------------------------


async def test_notify_queues_event(tmp_path: Path) -> None:
    """POST /notify → event on the event bus."""
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/notify",
            json={
                "project_name": "my-proj",
                "event_type": "file_modified",
                "repo_root": "/repo",
                "file_paths": ["main.py"],
            },
        )
        assert resp.status_code == 202
        data = resp.json()
        assert data["status"] == "queued"
        assert "event_id" in data

    # Event should be on the bus
    assert bus._queue.qsize() == 1


async def test_notify_maps_hook_event_names_to_git_commit_type(
    tmp_path: Path,
) -> None:
    """``commit`` and ``push`` from the hook script must land as
    ``EventType.GIT_COMMIT``, not silently fall back to FILE_MODIFIED.

    Regression guard for the bug that put 69 mistyped events in the
    sagex repo's own rules.db: ``EventType("commit")`` raises ValueError
    because the wire-format value is ``"git_commit"``, and the route
    used to swallow that into a FILE_MODIFIED fallback — leaving every
    git-hook event mislabelled in the audit trail.
    """
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        for hook_name in ("commit", "push"):
            resp = await ac.post(
                "/notify",
                json={
                    "project_name": "my-proj",
                    "event_type": hook_name,
                    "repo_root": "/repo",
                },
            )
            assert resp.status_code == 202

    # Drain both events and assert their type — the bus is FIFO.
    evt1 = await asyncio.wait_for(bus.subscribe(), timeout=1.0)
    evt2 = await asyncio.wait_for(bus.subscribe(), timeout=1.0)
    assert evt1.type.value == "git_commit"
    assert evt2.type.value == "git_commit"


async def test_notify_accepts_wire_format_event_types(
    tmp_path: Path,
) -> None:
    """Callers that pass the enum's wire format directly (``git_commit``,
    ``manual``, ``file_modified``) must continue to work unchanged.

    The new ``_HOOK_EVENT_TO_TYPE`` map is checked first; this test
    proves the ``EventType()`` fallback still handles every existing
    contract.  Without it, lifting hook-name handling could silently
    have broken every non-hook caller (the watcher, the trigger CLI,
    anything POSTing directly to /notify).
    """
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        for wire_name in ("git_commit", "manual", "file_modified"):
            resp = await ac.post(
                "/notify",
                json={
                    "project_name": "my-proj",
                    "event_type": wire_name,
                    "repo_root": "/repo",
                },
            )
            assert resp.status_code == 202

    for expected in ("git_commit", "manual", "file_modified"):
        evt = await asyncio.wait_for(bus.subscribe(), timeout=1.0)
        assert evt.type.value == expected


async def test_notify_forwards_diff_and_diff_context_to_event(
    tmp_path: Path,
) -> None:
    """``diff`` and ``diff_context`` from the request body must land on
    the AgentEvent — otherwise the runtime can't ever see the changes
    the hook captured at commit time, which is the whole point of the
    hook computing them locally.
    """
    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.post(
            "/notify",
            json={
                "project_name": "my-proj",
                "event_type": "commit",
                "repo_root": "/repo",
                "file_paths": ["src/foo.py"],
                "diff": "diff --git a/src/foo.py b/src/foo.py\n+x = 1\n",
                "diff_context": "@@ context @@\n+x = 1\n",
            },
        )
        assert resp.status_code == 202

    evt = await asyncio.wait_for(bus.subscribe(), timeout=1.0)
    assert evt.file_paths == ["src/foo.py"]
    assert evt.diff is not None and "x = 1" in evt.diff
    assert evt.diff_context is not None and "context" in evt.diff_context


# ---------------------------------------------------------------------------
# Queue status
# ---------------------------------------------------------------------------


async def test_queue_status_returns_depth(client: AsyncClient) -> None:
    resp = await client.get("/queue/status")
    assert resp.status_code == 200
    assert resp.json()["depth"] == 0


# ---------------------------------------------------------------------------
# Rules
# ---------------------------------------------------------------------------


async def test_list_rules_empty(
    client_with_project: tuple[AsyncClient, ProjectConfig],
) -> None:
    ac, config = client_with_project
    resp = await ac.get(f"/projects/{config.name}/rules")
    assert resp.status_code == 200
    assert resp.json()["rules"] == []


async def test_list_rules_unknown_project_returns_404(client: AsyncClient) -> None:
    resp = await client.get("/projects/no-such-project/rules")
    assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Usage
# ---------------------------------------------------------------------------


async def test_usage_summary(
    client_with_project: tuple[AsyncClient, ProjectConfig],
) -> None:
    ac, config = client_with_project
    resp = await ac.get(f"/projects/{config.name}/usage?period=24h")
    assert resp.status_code == 200
    data = resp.json()
    assert "total_input_tokens" in data
    assert "total_output_tokens" in data
    assert "total_cost_usd" in data
    assert data["period"] == "24h"


async def test_usage_history(
    client_with_project: tuple[AsyncClient, ProjectConfig],
) -> None:
    ac, config = client_with_project
    resp = await ac.get(f"/projects/{config.name}/usage/history?period=24h")
    assert resp.status_code == 200
    data = resp.json()
    assert "history" in data
    assert isinstance(data["history"], list)


# ---------------------------------------------------------------------------
# Approvals
# ---------------------------------------------------------------------------


async def test_list_approvals_empty(
    client_with_project: tuple[AsyncClient, ProjectConfig],
) -> None:
    ac, config = client_with_project
    resp = await ac.get(f"/projects/{config.name}/approvals")
    assert resp.status_code == 200
    assert resp.json()["approvals"] == []


async def test_approve_resolves_approval(
    tmp_path: Path,
) -> None:
    """POST /approvals/{id}/approve → approval is resolved."""
    db = RulesDB(str(tmp_path / "rules.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    config = _make_project_config("proj", tmp_path)
    registry.register(config)

    # Write an approval directly into the project DB
    proj_db = RulesDB(config.knowledge.db_path)
    proj_db.run_migrations(
        Path(__file__).parent.parent / "src" / "sagex" / "knowledge" / "migrations"
    )
    approval = PendingApproval(
        project_name="proj",
        episode_id="ep_001",
        plan_json='{"actions":[]}',
    )
    await proj_db.write_pending_approval(approval)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        # Should appear in list
        resp = await ac.get("/projects/proj/approvals")
        assert resp.status_code == 200
        approvals = resp.json()["approvals"]
        assert len(approvals) == 1
        appr_id = approvals[0]["id"]

        # Approve it
        resp = await ac.post(f"/projects/proj/approvals/{appr_id}/approve")
        assert resp.status_code == 200
        assert resp.json()["status"] == "approved"

        # Should no longer be pending
        resp = await ac.get("/projects/proj/approvals")
        assert resp.json()["approvals"] == []


async def test_reject_resolves_approval(
    tmp_path: Path,
) -> None:
    """POST /approvals/{id}/reject → approval is resolved as rejected."""
    db = RulesDB(str(tmp_path / "rules.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    config = _make_project_config("proj2", tmp_path)
    registry.register(config)

    proj_db = RulesDB(config.knowledge.db_path)
    proj_db.run_migrations(
        Path(__file__).parent.parent / "src" / "sagex" / "knowledge" / "migrations"
    )
    approval = PendingApproval(
        project_name="proj2",
        episode_id="ep_002",
        plan_json='{"actions":[]}',
    )
    await proj_db.write_pending_approval(approval)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        resp = await ac.get("/projects/proj2/approvals")
        appr_id = resp.json()["approvals"][0]["id"]

        resp = await ac.post(f"/projects/proj2/approvals/{appr_id}/reject")
        assert resp.status_code == 200
        assert resp.json()["status"] == "rejected"


# ---------------------------------------------------------------------------
# Issue #25: resolve_approval must not overwrite an already-resolved row.
# ---------------------------------------------------------------------------

async def test_double_resolve_returns_409_conflict(tmp_path: Path) -> None:
    """Approving an already-approved approval must 409, not silently overwrite.

    Silent overwrite corrupts the audit trail: user A approves, user B
    rejects, row reads "rejected" even though the runner already acted
    on the approval.
    """
    db = RulesDB(str(tmp_path / "rules.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    app = create_app(bus, WatcherManager(bus), registry)
    config = _make_project_config("dup-proj", tmp_path)
    registry.register(config)

    proj_db = RulesDB(config.knowledge.db_path)
    proj_db.run_migrations(
        Path(__file__).parent.parent / "src" / "sagex" / "knowledge" / "migrations"
    )
    await proj_db.write_pending_approval(
        PendingApproval(
            project_name="dup-proj",
            episode_id="ep_x",
            plan_json='{"actions":[]}',
        )
    )

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        appr_id = (await ac.get("/projects/dup-proj/approvals")).json()["approvals"][0]["id"]

        first = await ac.post(f"/projects/dup-proj/approvals/{appr_id}/approve")
        assert first.status_code == 200

        # Second attempt — approve again, then reject after approve — both
        # must fail with 409 Conflict, and the original "approved" status
        # must remain.
        second = await ac.post(f"/projects/dup-proj/approvals/{appr_id}/approve")
        assert second.status_code == 409

        third = await ac.post(f"/projects/dup-proj/approvals/{appr_id}/reject")
        assert third.status_code == 409

    row = proj_db.get_approval(appr_id)
    assert row is not None
    assert row.status == "approved"


# ---------------------------------------------------------------------------
# Issue #15: approve/reject must refuse approval IDs from another project.
# ---------------------------------------------------------------------------

async def test_cross_project_approval_returns_404(tmp_path: Path) -> None:
    """A project A endpoint must not resolve project B's approval."""
    db = RulesDB(str(tmp_path / "rules.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    app = create_app(bus, WatcherManager(bus), registry)

    config_a = _make_project_config("proj-a", tmp_path)
    config_b = _make_project_config("proj-b", tmp_path)
    registry.register(config_a)
    registry.register(config_b)

    # Both configs point at different DB paths, but we simulate the worst
    # case where they share a DB file by writing B's approval into A's DB.
    # This mimics a shared-DB deployment (or a future refactor) where only
    # the UPDATE's project_name clause defends against cross-project resolve.
    db_a = RulesDB(config_a.knowledge.db_path)
    db_a.run_migrations(
        Path(__file__).parent.parent / "src" / "sagex" / "knowledge" / "migrations"
    )
    appr_b = PendingApproval(
        project_name="proj-b",
        episode_id="ep_b",
        plan_json='{"actions":[]}',
    )
    await db_a.write_pending_approval(appr_b)

    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as ac:
        # Attempt to approve project B's approval via project A's endpoint.
        resp = await ac.post(
            f"/projects/proj-a/approvals/{appr_b.id}/approve"
        )
        assert resp.status_code == 404

    row = db_a.get_approval(appr_b.id)
    assert row is not None
    assert row.status == "pending"  # unchanged


def test_approval_waiters_orphan_notify_is_bounded(monkeypatch: pytest.MonkeyPatch) -> None:
    """``ApprovalWaiters._events`` must not grow without bound when ``notify``
    pre-creates events that no waiter ever consumes (the runner-less case).

    Lower the cap, push more orphan notifies than the cap allows, and
    assert the dict stays at the cap with LRU eviction (oldest gone,
    newest retained).
    """
    from sagex.api import server as srv

    monkeypatch.setattr(srv, "_MAX_APPROVAL_EVENTS", 3)
    waiters = srv.ApprovalWaiters()
    for i in range(5):
        waiters.notify(f"orphan-{i}")

    pending = waiters.pending_ids()
    assert len(pending) == 3, f"expected cap=3, got {len(pending)}: {pending}"
    # LRU order: 0 and 1 evicted, 2/3/4 retained.
    assert "orphan-0" not in pending
    assert "orphan-1" not in pending
    assert "orphan-2" in pending
    assert "orphan-3" in pending
    assert "orphan-4" in pending


# ---------------------------------------------------------------------------
# Gap #7: RulesDB cached per db_path (migrations only run once)
# ---------------------------------------------------------------------------


async def test_get_db_returns_same_instance_for_same_project(tmp_path: Path) -> None:
    """Multiple calls to _get_db for the same project return the cached instance."""
    from fastapi import Request

    from sagex.api.routes import _get_db

    db = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    config = _make_project_config("cache-proj", tmp_path)
    registry.register(config)

    # Fake a minimal Request object pointing at our app
    scope = {"type": "http", "method": "GET", "path": "/", "headers": []}
    scope["app"] = app  # type: ignore[assignment]
    request = Request(scope)  # type: ignore[arg-type]

    db1 = await _get_db(request, "cache-proj")
    db2 = await _get_db(request, "cache-proj")
    assert db1 is db2, "Expected the same RulesDB instance (cached)"


async def test_get_db_concurrent_first_requests_dedupe(tmp_path: Path) -> None:
    """Concurrent first-requests must not construct duplicate RulesDB instances.

    Regression test for issue #17 — the TOCTOU between the `if not in cache`
    check and the subsequent assignment was previously unlocked, so two
    concurrent coroutines could both enter the construction branch and
    install rival RulesDB objects.  With the async lock, only one wins.
    """
    from fastapi import Request

    from sagex.api.routes import _get_db

    db_global = RulesDB(str(tmp_path / "global.db"))
    bus = EventBus(db_global)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    app = create_app(bus, watcher_manager, registry)

    config = _make_project_config("race-proj", tmp_path)
    registry.register(config)

    scope = {"type": "http", "method": "GET", "path": "/", "headers": []}
    scope["app"] = app  # type: ignore[assignment]
    request = Request(scope)  # type: ignore[arg-type]

    results = await asyncio.gather(*[_get_db(request, "race-proj") for _ in range(10)])
    assert all(r is results[0] for r in results), (
        "Concurrent first-requests produced duplicate RulesDB instances"
    )
