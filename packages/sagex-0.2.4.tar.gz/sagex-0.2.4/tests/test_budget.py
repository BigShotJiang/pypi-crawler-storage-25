"""Phase 3 acceptance criteria: LLM budget, prompt cache, and token tracker."""

from __future__ import annotations

import asyncio
import inspect
from datetime import UTC
from pathlib import Path

import pytest
from conftest import StubAnthropicClient

from sagex.config import BudgetConfig
from sagex.knowledge.rules_db import RulesDB
from sagex.llm.budget import AgentOutputError, BudgetExceededError, BudgetManager
from sagex.llm.cache import ContentCache, build_cached_request
from sagex.llm.token_tracker import MODEL_PRICING, TokenTracker

# ---------------------------------------------------------------------------
# Helpers / fixtures
# ---------------------------------------------------------------------------

class _FakeUsage:
    """Fake Anthropic Usage object for tests that want specific token counts."""

    def __init__(
        self,
        input_tokens: int = 10,
        output_tokens: int = 20,
        cache_read: int = 0,
        cache_write: int = 0,
    ) -> None:
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.cache_read_input_tokens = cache_read
        self.cache_creation_input_tokens = cache_write


@pytest.fixture
def db(tmp_path: Path) -> RulesDB:
    return RulesDB(str(tmp_path / "rules.db"))


@pytest.fixture
def tracker(db: RulesDB) -> TokenTracker:
    return TokenTracker(db)


@pytest.fixture
def cache(db: RulesDB) -> ContentCache:
    return ContentCache(db, ttl_minutes=60)


@pytest.fixture
def config() -> BudgetConfig:
    return BudgetConfig(
        hourly_token_limit=50_000,
        daily_token_limit=500_000,
        enable_prompt_caching=True,
    )


@pytest.fixture
def manager(
    config: BudgetConfig,
    tracker: TokenTracker,
    cache: ContentCache,
) -> BudgetManager:
    stub = StubAnthropicClient(responses=['{"status": "ok"}'])
    return BudgetManager(config, tracker, cache, client=stub)


# ---------------------------------------------------------------------------
# Async type checks
# ---------------------------------------------------------------------------

def test_budget_manager_call_is_async() -> None:
    """BudgetManager.call() must be declared async def."""
    assert asyncio.iscoroutinefunction(BudgetManager.call)


def test_token_tracker_record_is_async() -> None:
    """TokenTracker.record() must be declared async def."""
    assert asyncio.iscoroutinefunction(TokenTracker.record)


# ---------------------------------------------------------------------------
# Basic call
# ---------------------------------------------------------------------------

async def test_call_returns_stub_text(manager: BudgetManager) -> None:
    """call() returns the text emitted by the stub client."""
    text = await manager.call(
        project="proj",
        agent_type="task",
        system="You are helpful.",
        user="Hello",
        model="claude-sonnet-4-6",
        max_tokens=100,
    )
    assert text == '{"status": "ok"}'


# ---------------------------------------------------------------------------
# Content-hash cache
# ---------------------------------------------------------------------------

async def test_call_returns_cached_on_second_call(
    config: BudgetConfig,
    tracker: TokenTracker,
    cache: ContentCache,
) -> None:
    """Second identical call returns cached result without hitting the API."""
    stub = StubAnthropicClient(responses=["first response", "second response"])
    mgr = BudgetManager(config, tracker, cache, client=stub)

    r1 = await mgr.call(
        project="proj",
        agent_type="task",
        system="sys",
        user="user",
        model="claude-sonnet-4-6",
        max_tokens=100,
    )
    r2 = await mgr.call(
        project="proj",
        agent_type="task",
        system="sys",
        user="user",
        model="claude-sonnet-4-6",
        max_tokens=100,
    )

    assert r1 == "first response"
    assert r2 == "first response"   # cached — not "second response"
    assert stub.call_count == 1     # API called only once


async def test_cache_isolates_across_models(
    config: BudgetConfig,
    tracker: TokenTracker,
    cache: ContentCache,
) -> None:
    """Identical (system, user) but different model must NOT cross-hit.

    Before adding ``model`` to the cache key, a Haiku response could be
    served for a Sonnet call with the same prompts, producing semantic
    drift. Each model now gets its own cache slot.
    """
    stub = StubAnthropicClient(responses=["sonnet response", "haiku response"])
    mgr = BudgetManager(config, tracker, cache, client=stub)

    r_sonnet = await mgr.call(
        project="proj",
        agent_type="task",
        system="sys",
        user="user",
        model="claude-sonnet-4-6",
        max_tokens=100,
    )
    r_haiku = await mgr.call(
        project="proj",
        agent_type="triage",
        system="sys",
        user="user",
        model="claude-haiku-4-5",
        max_tokens=100,
    )

    assert r_sonnet == "sonnet response"
    assert r_haiku == "haiku response"   # not cross-served from Sonnet
    assert stub.call_count == 2          # both models hit API


async def test_cache_respects_ttl(
    config: BudgetConfig,
    tracker: TokenTracker,
    db: RulesDB,
) -> None:
    """Expired cache entries (ttl_minutes=0) are not returned."""
    expired_cache = ContentCache(db, ttl_minutes=0)
    stub = StubAnthropicClient(responses=["response A", "response B"])
    mgr = BudgetManager(config, tracker, expired_cache, client=stub)

    await mgr.call(
        project="proj",
        agent_type="task",
        system="sys",
        user="hello",
        model="claude-sonnet-4-6",
        max_tokens=100,
    )
    # With ttl=0, entry is immediately expired — second call must hit API again
    r2 = await mgr.call(
        project="proj",
        agent_type="task",
        system="sys",
        user="hello",
        model="claude-sonnet-4-6",
        max_tokens=100,
    )
    assert stub.call_count == 2
    assert r2 == "response B"


# ---------------------------------------------------------------------------
# Budget enforcement
# ---------------------------------------------------------------------------

async def test_budget_exceeded_hourly(
    config: BudgetConfig,
    tracker: TokenTracker,
    cache: ContentCache,
) -> None:
    """BudgetExceededError is raised when the hourly token limit is breached."""
    # Fill hourly bucket past the 50 000 limit
    big_usage = _FakeUsage(input_tokens=40_000, output_tokens=15_000)
    await tracker.record("proj", "task", "claude-sonnet-4-6", big_usage)

    stub = StubAnthropicClient()
    mgr = BudgetManager(config, tracker, cache, client=stub)

    with pytest.raises(BudgetExceededError, match="Hourly"):
        await mgr.call(
            project="proj",
            agent_type="task",
            system="sys",
            user="user",
            model="claude-sonnet-4-6",
            max_tokens=100,
        )


async def test_token_cap_fires_for_subscription_provider_with_rate_limit_framing(
    config: BudgetConfig,
    tracker: TokenTracker,
    cache: ContentCache,
) -> None:
    """Locked decision #6: the token-count cap must fire for claude_code /
    ollama too (blast-radius guard).  Error framing uses 'rate-limit' rather
    than 'cost' since those providers don't produce a dollar bill.
    """
    # Pre-load token_usage past the hourly limit
    big_usage = _FakeUsage(input_tokens=40_000, output_tokens=15_000)
    await tracker.record("proj", "task", "claude-sonnet-4-6", big_usage)

    # Stand-in provider with name="claude_code" to trigger subscription framing
    class _StubSubscriptionProvider:
        name = "claude_code"

        def supports_model(self, model: str) -> bool:
            return True

        async def call(self, **_kwargs: object) -> None:  # pragma: no cover
            raise AssertionError("must not be reached — cap should fire first")

    mgr = BudgetManager(config, tracker, cache, provider=_StubSubscriptionProvider())
    with pytest.raises(BudgetExceededError, match="rate-limit"):
        await mgr.call(
            project="proj",
            agent_type="task",
            system="sys",
            user="user",
            model="claude-sonnet-4-6",
            max_tokens=100,
        )


async def test_token_cap_uses_cost_framing_for_api_provider(
    config: BudgetConfig,
    tracker: TokenTracker,
    cache: ContentCache,
) -> None:
    """API providers see 'cost cap' framing (the legacy wording)."""
    big_usage = _FakeUsage(input_tokens=40_000, output_tokens=15_000)
    await tracker.record("proj", "task", "claude-sonnet-4-6", big_usage)

    class _StubApiProvider:
        name = "openai_api"

        def supports_model(self, model: str) -> bool:
            return True

        async def call(self, **_kwargs: object) -> None:  # pragma: no cover
            raise AssertionError("cap should fire first")

    mgr = BudgetManager(config, tracker, cache, provider=_StubApiProvider())
    with pytest.raises(BudgetExceededError, match="cost cap"):
        await mgr.call(
            project="proj",
            agent_type="task",
            system="sys",
            user="user",
            model="gpt-5",
            max_tokens=100,
        )


# ---------------------------------------------------------------------------
# Token cost computation
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "model,input_t,output_t,expected_usd",
    [
        (
            "claude-haiku-4-5",
            1_000_000,
            0,
            MODEL_PRICING["claude-haiku-4-5"]["input"] * 1_000_000,
        ),
        (
            "claude-sonnet-4-6",
            0,
            1_000_000,
            MODEL_PRICING["claude-sonnet-4-6"]["output"] * 1_000_000,
        ),
        (
            "claude-opus-4-7",
            500_000,
            500_000,
            (
                MODEL_PRICING["claude-opus-4-7"]["input"] * 500_000
                + MODEL_PRICING["claude-opus-4-7"]["output"] * 500_000
            ),
        ),
    ],
)
def test_token_cost_computed_correctly(
    model: str,
    input_t: int,
    output_t: int,
    expected_usd: float,
) -> None:
    """compute_cost is correct for all three models."""
    actual = TokenTracker.compute_cost(model, input_t, output_t)
    assert actual == pytest.approx(expected_usd, rel=1e-6)


async def test_tracker_zeros_cost_for_subscription_and_local_providers(
    db: RulesDB, tracker: TokenTracker
) -> None:
    """Locked decision: claude_code / ollama always report $0 in sagex usage,
    even for models not in MODEL_PRICING (like ollama's llama3.1:8b).
    Regression guard against the Sonnet-pricing fallback that was silently
    assigning non-zero USD to Ollama calls.
    """
    usage = _FakeUsage(input_tokens=1000, output_tokens=500)

    # Ollama with an arbitrary user-managed model name — previously fell
    # through to Sonnet pricing; now forced to $0.
    rec_ollama = await tracker.record(
        "proj", "task", "llama3.1:8b", usage, provider_name="ollama"
    )
    assert rec_ollama.cost_usd == 0.0

    # Claude Code subscription — known Anthropic model, but subscription
    # absorbs the spend so $0 in sagex usage.
    rec_claude_code = await tracker.record(
        "proj", "meta", "claude-sonnet-4-6", usage, provider_name="claude_code"
    )
    assert rec_claude_code.cost_usd == 0.0

    # Paid API path still produces a non-zero cost for the same usage.
    rec_api = await tracker.record(
        "proj", "task", "claude-sonnet-4-6", usage, provider_name="anthropic_api"
    )
    assert rec_api.cost_usd > 0.0

    # Legacy call sites that don't pass provider_name still work
    # (falls through to the per-model pricing table).
    rec_legacy = await tracker.record("proj", "task", "claude-sonnet-4-6", usage)
    assert rec_legacy.cost_usd > 0.0


def test_pricing_age_is_non_negative_and_stale_flag_works() -> None:
    """Review fix #6: MODEL_PRICING carries a refresh date and a staleness helper."""
    from sagex.llm.token_tracker import (
        MODEL_PRICING_LAST_UPDATED,
        get_pricing_age_days,
        pricing_is_stale,
    )

    age = get_pricing_age_days()
    assert age >= 0
    # The constant itself is YYYY-MM parseable.
    assert len(MODEL_PRICING_LAST_UPDATED) == 7 and MODEL_PRICING_LAST_UPDATED[4] == "-"
    # pricing_is_stale is a boolean derived from the age.
    assert isinstance(pricing_is_stale(), bool)


def test_cost_includes_cache_tokens() -> None:
    """Cache read/write tokens are factored into the cost."""
    cost_plain = TokenTracker.compute_cost("claude-sonnet-4-6", 1000, 0)
    cost_with_cache = TokenTracker.compute_cost(
        "claude-sonnet-4-6", 1000, 0, cache_read_tokens=1000
    )
    # Cache read is cheaper than input; cost_with_cache > cost_plain
    assert cost_with_cache > cost_plain


def test_compute_cost_unknown_model_returns_zero_and_warns(
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Issue #14: unknown models must not silently bill at Sonnet rates.

    The old ``MODEL_PRICING.get(model, MODEL_PRICING["claude-sonnet-4-6"])``
    fallback produced misleading dollar figures — e.g. a user running
    ``gpt-4-turbo`` saw Sonnet-rate USD in ``sagex usage``.  The fix
    returns 0.0 with a one-time WARN identifying the model.  Zero is
    the honest value when we can't compute the real cost; the log entry
    tells the user exactly what to add to MODEL_PRICING.
    """
    from sagex.llm.token_tracker import _WARNED_UNKNOWN_MODELS

    # Reset per-process warning cache so this test doesn't depend on
    # whether earlier tests already warned about this model.
    _WARNED_UNKNOWN_MODELS.clear()

    # Keep both compute_cost calls inside the same caplog level override.
    # If the second call escaped the context, the suite's default log
    # config could filter WARNINGs out and the "no re-warn" assertion
    # would pass even if the implementation regressed and re-warned.
    with caplog.at_level("WARNING", logger="sagex.llm.token_tracker"):
        cost = TokenTracker.compute_cost("gpt-4-turbo-does-not-exist", 1_000, 500)

        assert cost == 0.0
        assert any(
            "pricing_unknown_model" in rec.message
            or "pricing_unknown_model" == rec.msg
            for rec in caplog.records
        ), f"Expected pricing_unknown_model warning, got: {[r.message for r in caplog.records]}"

        # Second call for the same model must NOT re-warn (log flooding guard).
        pre = len(caplog.records)
        _ = TokenTracker.compute_cost("gpt-4-turbo-does-not-exist", 1_000, 500)
        post = len(caplog.records)
        assert post == pre, "Warning was logged twice for the same unknown model"


def test_compute_cost_unknown_model_dedupe_set_is_bounded(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """The dedupe set must not grow unboundedly under churn (issue from PR #35 review).

    Lower the cap to a small value, exceed it, and assert:
    1. The set never exceeds the cap.
    2. Re-warning the LRU-evicted model emits a fresh warning (so the
       fix is actually a cap, not silent suppression).
    """
    from sagex.llm import token_tracker as tt

    monkeypatch.setattr(tt, "_WARNED_UNKNOWN_MODELS_CAP", 3)
    tt._WARNED_UNKNOWN_MODELS.clear()

    with caplog.at_level("WARNING", logger="sagex.llm.token_tracker"):
        # Push 5 distinct unknown models through compute_cost.  Cap=3
        # means models[0] and models[1] should be evicted in LRU order.
        for i in range(5):
            TokenTracker.compute_cost(f"unknown-model-churn-{i}", 1, 1)

        assert len(tt._WARNED_UNKNOWN_MODELS) == 3, (
            f"Expected dedupe set bounded to 3, got {len(tt._WARNED_UNKNOWN_MODELS)}"
        )
        # Re-warning the *evicted* first model fires a fresh warning;
        # re-warning a still-tracked model does not.
        pre = len(caplog.records)
        TokenTracker.compute_cost("unknown-model-churn-0", 1, 1)
        assert len(caplog.records) == pre + 1, (
            "Re-warning an evicted model must produce a new log record"
        )
        pre2 = len(caplog.records)
        TokenTracker.compute_cost("unknown-model-churn-4", 1, 1)
        assert len(caplog.records) == pre2, (
            "Re-warning a still-tracked model must NOT produce a new log record"
        )


# ---------------------------------------------------------------------------
# call_json and AgentOutputError
# ---------------------------------------------------------------------------

async def test_call_json_parses_valid_json(manager: BudgetManager) -> None:
    """call_json() returns a dict on valid JSON response."""
    result = await manager.call_json(
        project="proj",
        agent_type="task",
        system="sys",
        user="user",
        model="claude-sonnet-4-6",
        max_tokens=100,
    )
    assert isinstance(result, dict)
    assert result["status"] == "ok"


async def test_call_json_raises_agent_output_error_on_double_malformed(
    config: BudgetConfig,
    tracker: TokenTracker,
    cache: ContentCache,
) -> None:
    """call_json() raises AgentOutputError when both attempts return bad JSON."""
    stub = StubAnthropicClient(responses=["not json at all", "still not json"])
    mgr = BudgetManager(config, tracker, cache, client=stub)

    with pytest.raises(AgentOutputError):
        await mgr.call_json(
            project="proj",
            agent_type="task",
            system="sys",
            user="give me json",
            model="claude-sonnet-4-6",
            max_tokens=100,
        )
    # Both calls reached the API
    assert stub.call_count == 2


# ---------------------------------------------------------------------------
# _call_with_retry: asyncio.sleep only
# ---------------------------------------------------------------------------

def test_call_with_retry_uses_asyncio_sleep_not_time_sleep() -> None:
    """_call_with_retry must use asyncio.sleep; time module must not be imported."""

    # asyncio.sleep must be present in the retry method itself
    retry_source = inspect.getsource(BudgetManager._call_with_retry)
    assert "asyncio.sleep" in retry_source

    # The module must not import the time module (which would enable time.sleep)
    import ast
    import importlib.util

    spec = importlib.util.find_spec("sagex.llm.budget")
    assert spec is not None and spec.origin is not None
    tree = ast.parse(open(spec.origin).read())
    imported_names = [
        node.names[0].name
        for node in ast.walk(tree)
        if isinstance(node, ast.Import)
    ]
    assert "time" not in imported_names


def test_call_with_retry_applies_jitter() -> None:
    """_call_with_retry must use random.uniform to spread retries.

    Plain ``asyncio.sleep(2**attempt)`` causes a thundering herd when
    many concurrent calls hit the same transient error at the same
    instant — they all wake up simultaneously and re-hit the provider.

    The current implementation uses *equal-jitter* backoff
    (``base/2 + U(0, base/2)`` with ``base = 2**attempt``) — AWS's
    canonical middle ground between fixed backoff (no spread) and
    full-jitter (halves mean wait).  This test asserts only that
    ``random.uniform`` is present in the retry path so either jitter
    strategy passes; it guards the thundering-herd fix, not the exact
    distribution.
    """
    retry_source = inspect.getsource(BudgetManager._call_with_retry)
    assert "random.uniform" in retry_source


# ---------------------------------------------------------------------------
# build_cached_request — cache_control threshold guard
# ---------------------------------------------------------------------------

def test_build_cached_request_no_cache_control_for_short_prompt() -> None:
    """Short system prompt (< 1024 estimated tokens) must NOT get cache_control."""
    short_system = "You are a helpful assistant."  # well under 1024 tokens
    result = build_cached_request(
        system_prompt=short_system,
        user_prompt="hello",
        model="claude-sonnet-4-6",
        max_tokens=100,
        enable_prompt_caching=True,
    )
    system = result["system"]
    # When short, system is returned as a plain string — no cache_control key
    assert isinstance(system, str) or (
        isinstance(system, list)
        and all("cache_control" not in block for block in system)
    )


def test_build_cached_request_has_cache_control_for_long_prompt() -> None:
    """Long system prompt (>= 1024 estimated tokens) must include cache_control."""
    # 1024 tokens ≈ 4096 characters
    long_system = "X" * 4096
    result = build_cached_request(
        system_prompt=long_system,
        user_prompt="hello",
        model="claude-sonnet-4-6",
        max_tokens=100,
        enable_prompt_caching=True,
    )
    system = result["system"]
    assert isinstance(system, list)
    assert any("cache_control" in block for block in system)


def test_build_cached_request_no_cache_control_when_disabled() -> None:
    """cache_control is never applied when enable_prompt_caching=False."""
    long_system = "X" * 4096
    result = build_cached_request(
        system_prompt=long_system,
        user_prompt="hello",
        model="claude-sonnet-4-6",
        max_tokens=100,
        enable_prompt_caching=False,
    )
    system = result["system"]
    # With caching disabled, system is a plain string even for long prompts
    assert isinstance(system, str) or (
        isinstance(system, list)
        and all("cache_control" not in block for block in system)
    )


def test_build_cached_request_haiku_threshold_is_2048_tokens() -> None:
    """Haiku requires 2048 tokens (8192 chars); just below threshold → no cache_control."""
    # 2047 tokens ≈ 8188 chars — just below Haiku's 2048-token threshold
    just_under = "Y" * 8188
    result = build_cached_request(
        system_prompt=just_under,
        user_prompt="hello",
        model="claude-haiku-4-5",
        max_tokens=100,
        enable_prompt_caching=True,
    )
    system = result["system"]
    assert isinstance(system, str) or (
        isinstance(system, list)
        and all("cache_control" not in block for block in system)
    )

    # 2048 tokens ≈ 8192 chars — at the threshold → cache_control applied
    at_threshold = "Y" * 8192
    result2 = build_cached_request(
        system_prompt=at_threshold,
        user_prompt="hello",
        model="claude-haiku-4-5",
        max_tokens=100,
        enable_prompt_caching=True,
    )
    system2 = result2["system"]
    assert isinstance(system2, list)
    assert any("cache_control" in block for block in system2)


# ---------------------------------------------------------------------------
# TokenTracker.record round-trip
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Gap #4: budget alert fires at threshold
# ---------------------------------------------------------------------------


async def test_budget_alert_logged_when_approaching_daily_limit(
    db: RulesDB,
) -> None:
    """A warning is logged when daily usage reaches alert_threshold (80%)."""
    import logging

    tight_config = BudgetConfig(
        hourly_token_limit=1_000_000,
        daily_token_limit=10_000,
        alert_threshold=0.8,
    )
    tracker = TokenTracker(db)
    cache = ContentCache(db, ttl_minutes=60)

    # Record 8 100 tokens — 81 % of the 10 000 daily limit
    class _BigUsage:
        input_tokens = 8_100
        output_tokens = 0
        cache_read_input_tokens = 0
        cache_creation_input_tokens = 0

    await tracker.record("proj", "task", "claude-sonnet-4-6", _BigUsage())

    stub = StubAnthropicClient(responses=['{"ok":1}'])
    mgr = BudgetManager(tight_config, tracker, cache, client=stub)

    log_records: list[logging.LogRecord] = []

    class _Cap(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            log_records.append(record)

    import sagex.llm.budget as budget_mod

    logger = logging.getLogger(budget_mod.__name__)
    old_level = logger.level
    logger.setLevel(logging.DEBUG)
    cap = _Cap()
    logger.addHandler(cap)
    try:
        # check_budget reads usage; should emit budget_alert warning
        mgr.check_budget("proj")
    finally:
        logger.removeHandler(cap)
        logger.setLevel(old_level)

    msgs = [r.getMessage() for r in log_records]
    assert any("budget_alert" in m for m in msgs), f"expected budget_alert, got: {msgs}"


async def test_anthropic_provider_preserves_cache_control_behaviour(
    config: BudgetConfig,
    tracker: TokenTracker,
    cache: ContentCache,
) -> None:
    """Refactor-equivalence gate: AnthropicAPIProvider must apply
    ``cache_control`` identically to the pre-v0.2.0 code path.
    Short prompts → no ``cache_control``; long prompts → ``cache_control``.
    """
    from sagex.llm.providers.anthropic_api import AnthropicAPIProvider

    # Short system prompt → no cache_control expected
    short_stub = StubAnthropicClient(responses=['{"status": "ok"}'])
    provider_short = AnthropicAPIProvider(
        client=short_stub, enable_prompt_caching=True
    )
    mgr_short = BudgetManager(config, tracker, cache, provider=provider_short)
    await mgr_short.call(
        project="proj",
        agent_type="task",
        system="You are helpful.",  # ~4 tokens, well below 1024 threshold
        user="hi",
        model="claude-sonnet-4-6",
        max_tokens=100,
    )
    sent_system = short_stub.messages.last_kwargs.get("system")
    # When short, system is sent as a plain string — no cache_control
    assert isinstance(sent_system, str) or (
        isinstance(sent_system, list)
        and all("cache_control" not in block for block in sent_system)
    )

    # Long system prompt → cache_control expected
    long_stub = StubAnthropicClient(responses=['{"status": "ok"}'])
    provider_long = AnthropicAPIProvider(
        client=long_stub, enable_prompt_caching=True
    )
    mgr_long = BudgetManager(config, tracker, cache, provider=provider_long)
    await mgr_long.call(
        project="proj",
        agent_type="task",
        system="X" * 4096,  # ~1024 tokens — at Sonnet's threshold
        user="hi",
        model="claude-sonnet-4-6",
        max_tokens=100,
    )
    sent_system = long_stub.messages.last_kwargs.get("system")
    assert isinstance(sent_system, list)
    assert any("cache_control" in block for block in sent_system)


async def test_tracker_record_persists_to_db(db: RulesDB, tracker: TokenTracker) -> None:
    """record() stores the usage record; get_summary reflects it."""
    from datetime import datetime, timedelta

    usage = _FakeUsage(input_tokens=100, output_tokens=50)
    rec = await tracker.record("proj", "task", "claude-sonnet-4-6", usage)

    assert rec.input_tokens == 100
    assert rec.output_tokens == 50
    assert rec.cost_usd == pytest.approx(
        TokenTracker.compute_cost("claude-sonnet-4-6", 100, 50)
    )

    since = (datetime.now(UTC) - timedelta(minutes=5)).isoformat()
    summary = tracker.get_summary("proj", since)
    assert summary["total_calls"] == 1
    assert summary["input_tokens"] == 100
    assert summary["output_tokens"] == 50
