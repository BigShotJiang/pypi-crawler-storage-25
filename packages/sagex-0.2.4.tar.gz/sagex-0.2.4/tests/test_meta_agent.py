"""Phase 6 acceptance criteria: meta agent reflection and rule extraction."""

from __future__ import annotations

from pathlib import Path

import pytest
from conftest import StubAnthropicClient

from sagex.agents.meta_agent import MetaAgent, detect_regression
from sagex.agents.task_agent import ExecutionResult
from sagex.agents.triage_agent import TriageResult
from sagex.config import AgentConfig, BudgetConfig
from sagex.event_bus import AgentEvent, EventType
from sagex.knowledge.rules_db import Episode, RulesDB
from sagex.llm.budget import BudgetManager
from sagex.llm.cache import ContentCache
from sagex.llm.token_tracker import TokenTracker

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def db(tmp_path: Path) -> RulesDB:
    return RulesDB(str(tmp_path / "rules.db"))


def _make_budget(db: RulesDB, meta_response: str | None = None) -> BudgetManager:
    default = (
        '{"outcome":"good","outcome_reason":"all tests pass",'
        '"lesson":null,"rule":null,"rule_updates":[]}'
    )
    stub = StubAnthropicClient(responses=[meta_response or default])
    tracker = TokenTracker(db)
    cache = ContentCache(db, ttl_minutes=60)
    return BudgetManager(BudgetConfig(), tracker, cache, client=stub)


def _make_episode(
    test_before: str | None = "pass",
    test_after: str | None = "pass",
    regression: int = 0,
) -> Episode:
    return Episode(
        project_name="test-proj",
        trigger_event="{}",
        test_result_before=test_before,
        test_result_after=test_after,
        regression_detected=regression,
    )


def _event() -> AgentEvent:
    return AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="test-proj",
        repo_root="/repo",
        file_paths=["auth.py"],
    )


def _triage(severity: str = "medium") -> TriageResult:
    return TriageResult(severity=severity, reason="logic change", used_llm=False)


def _result(errors: list[str] | None = None) -> ExecutionResult:
    return ExecutionResult(
        actions_taken=["edit_file: auth.py"],
        files_modified=["auth.py"],
        errors=errors or [],
        test_result="pass",
    )


# ---------------------------------------------------------------------------
# detect_regression
# ---------------------------------------------------------------------------

@pytest.mark.parametrize(
    "before,after,expected",
    [
        ("pass", "fail", True),
        ("pass", "pass", False),
        ("fail", "fail", False),
        (None, "fail", False),
        ("pass", None, False),
    ],
)
def test_detect_regression(
    before: str | None, after: str | None, expected: bool
) -> None:
    assert detect_regression(before, after) is expected


# ---------------------------------------------------------------------------
# MetaAgent.reflect
# ---------------------------------------------------------------------------

async def test_meta_agent_calls_budget_not_anthropic(db: RulesDB) -> None:
    """MetaAgent uses BudgetManager, not anthropic.Anthropic()."""
    budget = _make_budget(db)
    agent = MetaAgent(AgentConfig(), budget)

    reflection = await agent.reflect(
        _event(), _triage(), {}, _result(), _make_episode()
    )

    assert isinstance(reflection, dict)
    stub = budget._client  # type: ignore[attr-defined]
    assert stub.call_count == 1


async def test_meta_agent_passes_meta_max_tokens_to_api(db: RulesDB) -> None:
    """The meta_max_tokens config field reaches messages.create as max_tokens."""
    budget = _make_budget(db)
    agent_cfg = AgentConfig(meta_max_tokens=777)
    agent = MetaAgent(agent_cfg, budget)

    await agent.reflect(_event(), _triage(), {}, _result(), _make_episode())

    stub = budget._client  # type: ignore[attr-defined]
    assert stub.messages.last_kwargs.get("max_tokens") == 777


async def test_meta_agent_identifies_regression(db: RulesDB) -> None:
    """When tests went from pass→fail, the reflection should indicate bad outcome."""
    response = (
        '{"outcome":"bad","outcome_reason":"regression detected",'
        '"lesson":"always run tests before committing",'
        '"rule":null,"rule_updates":[]}'
    )
    budget = _make_budget(db, response)
    agent = MetaAgent(AgentConfig(), budget)
    episode = _make_episode(test_before="pass", test_after="fail", regression=1)

    reflection = await agent.reflect(_event(), _triage(), {}, _result(), episode)

    assert reflection["outcome"] == "bad"


async def test_meta_agent_parses_rule_with_correct_confidence(db: RulesDB) -> None:
    """parse_rule() builds a Rule with the confidence from meta agent JSON."""
    response = (
        '{"outcome":"partial","outcome_reason":"no tests added",'
        '"lesson":"always add tests for new auth logic",'
        '"rule":{'
        '"trigger_pattern":"auth module modified",'
        '"lesson":"add tests for every auth code path",'
        '"tags":["auth","testing"],'
        '"initial_confidence":0.3'
        '},"rule_updates":[]}'
    )
    budget = _make_budget(db, response)
    agent = MetaAgent(AgentConfig(), budget)

    reflection = await agent.reflect(_event(), _triage(), {}, _result(), _make_episode())
    rule = agent.parse_rule(reflection, "test-proj")

    assert rule is not None
    assert rule.trigger_pattern == "auth module modified"
    assert rule.confidence == pytest.approx(0.3)
    assert "auth" in rule.tags
    assert rule.project_name == "test-proj"


async def test_meta_agent_parse_rule_returns_none_when_absent(db: RulesDB) -> None:
    """parse_rule() returns None when the reflection has no rule."""
    budget = _make_budget(db)
    agent = MetaAgent(AgentConfig(), budget)

    reflection = await agent.reflect(_event(), _triage(), {}, _result(), _make_episode())
    rule = agent.parse_rule(reflection, "test-proj")

    assert rule is None


async def test_meta_agent_prompt_includes_test_results(db: RulesDB) -> None:
    """The LLM prompt includes before/after test results."""
    budget = _make_budget(db)
    agent = MetaAgent(AgentConfig(), budget)
    episode = _make_episode(test_before="pass", test_after="fail", regression=1)

    await agent.reflect(_event(), _triage(), {}, _result(), episode)

    stub = budget._client  # type: ignore[attr-defined]
    last_user = stub.messages.last_kwargs.get("messages", [{}])[0].get("content", "")
    assert "pass" in last_user
    assert "fail" in last_user
    assert "regression_detected: 1" in last_user


async def test_meta_agent_outcome_good_on_success(db: RulesDB) -> None:
    """Good execution with passing tests leads to good outcome."""
    response = (
        '{"outcome":"good","outcome_reason":"tests pass",'
        '"lesson":null,"rule":null,"rule_updates":[]}'
    )
    budget = _make_budget(db, response)
    agent = MetaAgent(AgentConfig(), budget)

    reflection = await agent.reflect(
        _event(), _triage(), {}, _result(), _make_episode()
    )
    assert reflection["outcome"] == "good"


# ---------------------------------------------------------------------------
# Gap #9: MetaAgent.reflect() accepts optional budget parameter
# ---------------------------------------------------------------------------


async def test_meta_agent_reflect_accepts_optional_budget_param(db: RulesDB) -> None:
    """reflect() accepts an optional budget keyword arg (design doc spec)."""
    response = (
        '{"outcome":"good","outcome_reason":"ok",'
        '"lesson":null,"rule":null,"rule_updates":[]}'
    )
    budget = _make_budget(db, response)
    agent = MetaAgent(AgentConfig(), budget)

    # Passing budget=None must not raise
    reflection = await agent.reflect(
        _event(), _triage(), {}, _result(), _make_episode(), budget=None
    )
    assert "outcome" in reflection

    # Passing budget=<real budget> must also not raise
    response2 = (
        '{"outcome":"partial","outcome_reason":"ok",'
        '"lesson":null,"rule":null,"rule_updates":[]}'
    )
    budget2 = _make_budget(db, response2)
    agent2 = MetaAgent(AgentConfig(), budget2)
    reflection2 = await agent2.reflect(
        _event(), _triage(), {}, _result(), _make_episode(), budget=budget2
    )
    assert "outcome" in reflection2
