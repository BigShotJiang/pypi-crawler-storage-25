"""Phase 9 acceptance criteria: main runner and orchestration loop."""

from __future__ import annotations

import asyncio
import logging
from collections import OrderedDict
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, patch

import pytest
from conftest import MockEmbedder, StubAnthropicClient

from sagex.agents.task_agent import ExecutionResult
from sagex.api.server import ProjectRegistry
from sagex.config import (
    AgentConfig,
    AgentsConfig,
    BudgetConfig,
    KnowledgeConfig,
    ProjectConfig,
    RunnerConfig,
    SecurityAgentConfig,
    TestConfig,
    WatchConfig,
)
from sagex.event_bus import AgentEvent, EventBus, EventType
from sagex.knowledge.rules_db import Episode, RulesDB
from sagex.knowledge.store import KnowledgeStore
from sagex.llm.budget import BudgetExceededError, BudgetManager
from sagex.llm.cache import ContentCache
from sagex.llm.token_tracker import TokenTracker
from sagex.runner import Runner, _execute_with_retry
from sagex.watcher import WatcherManager

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_db(tmp_path: Path) -> RulesDB:
    db = RulesDB(str(tmp_path / "rules.db"))
    db.run_migrations(
        Path(__file__).parent.parent / "src" / "sagex" / "knowledge" / "migrations"
    )
    return db


def _make_budget(db: RulesDB, responses: list[str] | None = None) -> BudgetManager:
    # NOTE: _event() uses auth.py with a 1-line diff — rule-based triage returns
    # "low" without an LLM call.  Default responses start with the task-agent plan.
    stub = StubAnthropicClient(
        responses=responses
        or [
            '{"summary":"ok","severity":"low","actions":[],'
            '"checks_required":[],"rules_applied":[],"confidence":0.8,"skip_reason":null}',
            '{"outcome":"good","outcome_reason":"pass","lesson":null,"rule":null,"rule_updates":[]}',
        ]
    )
    tracker = TokenTracker(db)
    cache = ContentCache(db, ttl_minutes=60)
    return BudgetManager(BudgetConfig(), tracker, cache, client=stub)


def _make_config(
    tmp_path: Path,
    *,
    require_approval: bool = False,
    security_enabled: bool = False,
    auto_remediate: bool = False,
    approval_timeout: int = 300,
) -> ProjectConfig:
    return ProjectConfig(
        name="test-proj",
        repo_root=str(tmp_path),
        watch=WatchConfig(paths=[str(tmp_path)]),
        test=TestConfig(command="echo pass"),
        agent=AgentConfig(),
        runner=RunnerConfig(
            require_approval=require_approval,
            approval_timeout_seconds=approval_timeout,
        ),
        knowledge=KnowledgeConfig(
            db_path=str(tmp_path / "rules.db"),
            vector_path=str(tmp_path / "vectors"),
        ),
        budget=BudgetConfig(),
        agents=AgentsConfig(
            security=SecurityAgentConfig(
                enabled=security_enabled,
                auto_remediate=auto_remediate,
            )
        ),
    )


def _event() -> AgentEvent:
    return AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="test-proj",
        repo_root="/repo",
        file_paths=["auth.py"],
        diff="+x = 1\n",
    )


def _make_runner(
    tmp_path: Path, config: ProjectConfig
) -> tuple[Runner, ProjectRegistry, RulesDB]:
    db = _make_db(tmp_path)
    bus = EventBus(db)
    registry = ProjectRegistry()
    registry.register(config)
    watcher_manager = WatcherManager(bus)
    runner = Runner(bus, registry, watcher_manager)
    return runner, registry, db


# ---------------------------------------------------------------------------
# Helper: patch runner internals to avoid real LLM/disk/subprocess
# ---------------------------------------------------------------------------


@contextmanager
def _patch_runner(
    db: RulesDB, responses: list[str] | None = None
) -> Iterator[None]:
    """Patch _make_budget_manager + _run_tests + Embedder for a runner test.

    Also stubs ``sagex.knowledge.store.Embedder`` to ``MockEmbedder`` so the
    ~14s cold-process SentenceTransformer load (offloaded to a thread by
    PR #38) doesn't fire inside ``KnowledgeStore.detect_conflicts``.  Every
    runner test that drives ``_handle_event`` reaches that code path, so
    the stub belongs in the shared helper rather than each call site —
    keeps the suite fast and the approval-poll budgets realistic.
    """
    budget = _make_budget(db, responses)

    async def _fake_make_budget(_config: Any) -> BudgetManager:
        return budget

    with patch.multiple(
        "sagex.runner",
        _make_budget_manager=_fake_make_budget,
        _run_tests=AsyncMock(return_value="pass"),
    ), patch("sagex.knowledge.store.Embedder", new=MockEmbedder):
        yield


# ---------------------------------------------------------------------------
# store.record_episode / write_rule / update_rule_outcome are coroutines
# ---------------------------------------------------------------------------


def _make_store(tmp_path: Path) -> KnowledgeStore:
    _make_db(tmp_path)  # run migrations first
    return KnowledgeStore(
        KnowledgeConfig(
            db_path=str(tmp_path / "rules.db"),
            vector_path=str(tmp_path / "vectors"),
        ),
        "test-proj",
    )


def test_store_record_episode_is_coroutine(tmp_path: Path) -> None:
    assert asyncio.iscoroutinefunction(_make_store(tmp_path).record_episode)


def test_store_write_rule_is_coroutine(tmp_path: Path) -> None:
    assert asyncio.iscoroutinefunction(_make_store(tmp_path).write_rule)


def test_store_update_rule_outcome_is_coroutine(tmp_path: Path) -> None:
    assert asyncio.iscoroutinefunction(_make_store(tmp_path).update_rule_outcome)


# ---------------------------------------------------------------------------
# Full cycle
# ---------------------------------------------------------------------------


async def test_full_cycle_episode_written_completed(tmp_path: Path) -> None:
    """Full cycle: event → triage → task → execute → meta → episode completed."""
    config = _make_config(tmp_path)
    runner, registry, db = _make_runner(tmp_path, config)

    with _patch_runner(db):
        await runner._handle_event(_event())

    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert len(episodes) >= 1
    assert episodes[0].status == "completed"


async def test_event_handler_does_not_call_archive(tmp_path: Path) -> None:
    """_handle_event must not fire archive_low_confidence_rules per-event (issue #21).

    The archival call used to run inside the hot path — a COUNT + UPDATE
    scan of the whole rules table on every single successful execution.
    It now lives in a separate background loop.  This test asserts the
    per-event path no longer touches archival at all.
    """
    config = _make_config(tmp_path)
    runner, registry, db = _make_runner(tmp_path, config)

    with _patch_runner(db), patch.object(
        RulesDB, "archive_low_confidence_rules", new=AsyncMock(return_value=0)
    ) as mock_archive:
        await runner._handle_event(_event())

    assert mock_archive.await_count == 0, (
        f"archive_low_confidence_rules was called {mock_archive.await_count} "
        f"time(s) from the event hot path"
    )


async def test_archival_loop_starts_and_aclose_cancels(tmp_path: Path) -> None:
    """The background loop must start when the runner runs, and ``aclose``
    must cancel it cleanly + be idempotent on repeat invocations.

    ``test_event_handler_does_not_call_archive`` only proves the
    *per-event* path is clean.  This one asserts the lifecycle of the
    *loop* path — start, alive, cancel, idempotent.

    We don't try to wait for ``archive_low_confidence_rules`` to be
    invoked here: the loop's interval gate uses ``loop.time()``
    (monotonic) and the new "first-tick anchor" semantic means the
    second-or-later tick is the one that fires archive.  Driving that
    deterministically would require synthetic-clock injection that
    fights the asyncio scheduler — out of scope for a lifecycle test.
    What we *do* verify is that the loop is registered, alive, and
    responds to cancellation — the regression we're guarding against
    is "the loop isn't started" or "aclose doesn't cancel cleanly".
    """
    from sagex import runner as runner_module

    config = _make_config(tmp_path)
    runner, _, _ = _make_runner(tmp_path, config)

    # Capture the *real* asyncio.sleep before patching so our fake doesn't
    # call its own patched version recursively.
    real_sleep = asyncio.sleep

    async def _instant_sleep(_seconds: float) -> None:
        # Yield once so the loop body advances and the task is cancellable.
        await real_sleep(0)

    # ``aclose`` flips the module-level ``_PROVIDER_CACHE_CLOSED`` flag
    # to True.  Without restoring it, every subsequent test in the suite
    # whose code path hits ``_make_budget_manager`` raises
    # ``ProviderCacheClosedError`` — a cross-test contamination first
    # observed in ``test_make_provider_blocking_does_not_block_other_keys``.
    saved_closed = runner_module._PROVIDER_CACHE_CLOSED
    try:
        with patch("sagex.runner.asyncio.sleep", new=_instant_sleep):
            # Start the loop directly (avoid running the full runner.run()
            # event-consumption loop which would hang waiting on the bus).
            runner._archival_task = asyncio.create_task(runner._archival_loop())
            # Yield enough times for the first tick body to execute (it
            # records the project's anchor and `continue`s).
            for _ in range(5):
                await real_sleep(0)
            assert runner._archival_task is not None
            assert not runner._archival_task.done(), "archival loop ended unexpectedly"

            # aclose must cancel the loop task cleanly.
            await runner.aclose()
            assert runner._archival_task is None
            # Re-running aclose must be a no-op (idempotent shutdown).
            await runner.aclose()
    finally:
        runner_module._PROVIDER_CACHE_CLOSED = saved_closed


async def test_full_cycle_rule_written_when_meta_returns_rule(
    tmp_path: Path,
) -> None:
    """When meta agent returns a rule, it is persisted to the DB."""
    config = _make_config(tmp_path)
    runner, registry, db = _make_runner(tmp_path, config)

    # triage is rule-based for auth.py + 1-line diff → no LLM call for triage
    plan_resp = (
        '{"summary":"ok","severity":"low","actions":[],'
        '"checks_required":[],"rules_applied":[],"confidence":0.8,"skip_reason":null}'
    )
    meta_response = (
        '{"outcome":"partial","outcome_reason":"ok",'
        '"lesson":"add tests","rule":{'
        '"trigger_pattern":"auth modified",'
        '"lesson":"always add tests",'
        '"tags":["auth","testing"],'
        '"initial_confidence":0.4},'
        '"rule_updates":[]}'
    )
    responses = [plan_resp, meta_response]

    with _patch_runner(db, responses):
        await runner._handle_event(_event())

    rules = db.get_rules_for_project("test-proj", min_confidence=0.0)
    assert any(r.trigger_pattern == "auth modified" for r in rules)


# ---------------------------------------------------------------------------
# Skip triage
# ---------------------------------------------------------------------------


async def test_skip_triage_llm_skip_episode_written(tmp_path: Path) -> None:
    """LLM triage returning 'skip' → no task agent call, episode written as skipped."""
    config = _make_config(tmp_path)
    runner, registry, db = _make_runner(tmp_path, config)

    # Use a large diff with an unknown file to force LLM triage (inconclusive rule-based)
    large_diff = "+x = 1\n" * 20  # 20 changed lines → inconclusive → LLM called
    llm_skip_event = AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="test-proj",
        repo_root="/repo",
        file_paths=["some_module.py"],
        diff=large_diff,
    )

    # The LLM returns 'skip'
    skip_response = '{"severity":"skip","reason":"auto-generated code"}'
    budget = _make_budget(db, [skip_response])

    async def _fake_make_budget(_config: Any) -> BudgetManager:
        return budget

    with patch.multiple(
        "sagex.runner",
        _make_budget_manager=_fake_make_budget,
        _run_tests=AsyncMock(return_value="pass"),
    ):
        await runner._handle_event(llm_skip_event)

    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert len(episodes) >= 1
    assert episodes[0].status == "skipped"


async def test_skip_via_rule_based_triage(tmp_path: Path) -> None:
    """Log file → rule-based skip (no LLM call), episode written as skipped."""
    config = _make_config(tmp_path)
    runner, registry, db = _make_runner(tmp_path, config)

    skip_event = AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="test-proj",
        repo_root="/repo",
        file_paths=["app.log"],
    )

    with _patch_runner(db):
        await runner._handle_event(skip_event)

    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert len(episodes) >= 1
    assert episodes[0].status == "skipped"


# ---------------------------------------------------------------------------
# BudgetExceededError
# ---------------------------------------------------------------------------


async def test_budget_exceeded_episode_written_runner_continues(
    tmp_path: Path,
) -> None:
    """BudgetExceededError in plan phase → episode written, runner not crashed."""
    config = _make_config(tmp_path)
    runner, registry, db = _make_runner(tmp_path, config)

    async def _exploding_budget(_config: Any) -> BudgetManager:
        raise BudgetExceededError("hourly limit reached")

    with patch("sagex.runner._make_budget_manager", _exploding_budget):
        # Should not raise — exception is caught in _plan_phase
        await runner._handle_event(_event())

    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert len(episodes) >= 1
    ep = episodes[0]
    assert ep.error_message is not None
    assert "hourly limit" in ep.error_message


# ---------------------------------------------------------------------------
# Deregistered project
# ---------------------------------------------------------------------------


async def test_deregistered_project_no_exception(tmp_path: Path) -> None:
    """Deregistered project mid-cycle → _handle_event exits cleanly."""
    config = _make_config(tmp_path)
    runner, registry, db = _make_runner(tmp_path, config)
    registry.deregister("test-proj")

    # Should return immediately without touching DB or raising
    with _patch_runner(db):
        await runner._handle_event(_event())

    # No episodes written
    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert len(episodes) == 0


# ---------------------------------------------------------------------------
# Approval flow
# ---------------------------------------------------------------------------


async def test_approval_approved_episode_completed(tmp_path: Path) -> None:
    """Approval resolves (approved) → episode status='completed'."""
    config = _make_config(tmp_path, require_approval=True, approval_timeout=60)
    runner, registry, db = _make_runner(tmp_path, config)

    # Capture the real asyncio.sleep before patching so the mock can use it
    _real_sleep = asyncio.sleep

    async def _auto_approve() -> None:
        # Poll until the runner actually writes the approval, then resolve.
        # A fixed sleep(0.05) used to be enough when plan_phase was entirely
        # synchronous; after PR-7 it yields at async boundaries (chromadb,
        # embedder) so the approval write may happen *after* a 50ms tick.
        for _ in range(200):
            approvals = db.get_pending_approvals("test-proj")
            if approvals:
                for a in approvals:
                    await db.resolve_approval(a.id, "approved")
                return
            await _real_sleep(0.05)
        # ~10s elapsed with no approval written.  Without this raise the
        # outer ``await runner._handle_event(...)`` would just stall against
        # ``approval_timeout`` (60s) and the eventual failure would point
        # at "test took too long" rather than at the real bug ("approval
        # row was never written").
        raise AssertionError(
            "_auto_approve timed out: no pending approval written for "
            "'test-proj' within 200 × 50ms.  Check that _handle_event is "
            "actually persisting an approval before the gate."
        )

    # Patch runner's sleep to yield without waiting; use real sleep to avoid recursion
    async def _yielding_sleep(n: float) -> None:
        await _real_sleep(0)

    with patch("sagex.runner.asyncio.sleep", new=_yielding_sleep):
        with _patch_runner(db):
            approve_task = asyncio.create_task(_auto_approve())
            await runner._handle_event(_event())
            await approve_task

    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert any(ep.status == "completed" for ep in episodes)


async def test_approval_rejected_episode_skipped(tmp_path: Path) -> None:
    """Approval rejected → episode status='skipped', no ActionExecutor."""
    config = _make_config(tmp_path, require_approval=True, approval_timeout=60)
    runner, registry, db = _make_runner(tmp_path, config)

    _real_sleep = asyncio.sleep

    async def _auto_reject() -> None:
        for _ in range(200):
            approvals = db.get_pending_approvals("test-proj")
            if approvals:
                for a in approvals:
                    await db.resolve_approval(a.id, "rejected")
                return
            await _real_sleep(0.05)
        # ~10s elapsed with no approval written — fail fast with an
        # actionable message instead of letting the outer handler stall
        # against the 60s ``approval_timeout``.
        raise AssertionError(
            "_auto_reject timed out: no pending approval written for "
            "'test-proj' within 200 × 50ms.  Check that _handle_event is "
            "actually persisting an approval before the gate."
        )

    async def _yielding_sleep(n: float) -> None:
        await _real_sleep(0)

    with patch("sagex.runner.asyncio.sleep", new=_yielding_sleep):
        with _patch_runner(db):
            reject_task = asyncio.create_task(_auto_reject())
            await runner._handle_event(_event())
            await reject_task

    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert any(ep.status == "skipped" for ep in episodes)


async def test_approval_timeout_resolve_called(tmp_path: Path) -> None:
    """Approval timeout → resolve_approval('timeout') is called."""
    # Use approval_timeout=0 so the while loop exits on the first check.
    # The sleep mock yields to the event loop without waiting.
    config = _make_config(tmp_path, require_approval=True, approval_timeout=0)
    runner, registry, db = _make_runner(tmp_path, config)

    async def _yielding_sleep(n: float) -> None:
        await asyncio.sleep(0)

    with patch("sagex.runner.asyncio.sleep", new=_yielding_sleep):
        with _patch_runner(db):
            await runner._handle_event(_event())

    # Approval should be resolved as "timeout"
    approval = db._conn.execute(
        "SELECT status FROM pending_approvals WHERE project_name='test-proj'"
    ).fetchone()
    if approval:
        assert approval[0] == "timeout"


# ---------------------------------------------------------------------------
# Issue #10: ApprovalWaiters wakes the runner immediately on resolve, without
# relying on the DB-poll fallback.
# ---------------------------------------------------------------------------

async def test_approval_event_resumes_without_polling(tmp_path: Path) -> None:
    """A resolved approval event wakes the runner in <500ms, not 5s.

    The runner registers an ``asyncio.Event`` with ``ApprovalWaiters``; the
    approve call sets it; ``_wait_for_approval`` returns without waiting
    for the 30s fallback DB poll.  ``approval_timeout`` here is 60s and
    the resolver's "wait until the row is written" loop polls every 10ms,
    so the realistic budget for the whole resolve-then-wake round trip is
    well under 500ms — anything close to seconds means the event-signal
    path regressed to falling back on the DB poll.  The threshold leaves
    headroom for scheduler jitter under CI load.
    """
    from sagex.api.server import ApprovalWaiters
    from sagex.runner import _wait_for_approval

    waiters = ApprovalWaiters()
    config = _make_config(tmp_path, require_approval=True, approval_timeout=60)
    db = _make_db(tmp_path)
    store = KnowledgeStore(
        config.knowledge, project_name="test-proj", embedder=MockEmbedder(),  # type: ignore[arg-type]
    )
    store._db = db
    episode = Episode(project_name="test-proj", trigger_event="{}")

    async def _resolve_soon() -> None:
        # Wait until the runner has actually persisted its pending approval
        # before resolving — otherwise we resolve nothing and the test hangs
        # against the 60s timeout.  Bounded retry loop avoids an unbounded
        # spin if the runner never writes the row.
        for _ in range(200):
            approvals = db.get_pending_approvals("test-proj")
            if len(approvals) == 1:
                a = approvals[0]
                await db.resolve_approval(a.id, "approved", project_name="test-proj")
                waiters.notify(a.id)
                return
            await asyncio.sleep(0.01)
        raise AssertionError("Timed out waiting for the runner to write a pending approval")

    resolver = asyncio.create_task(_resolve_soon())
    loop = asyncio.get_running_loop()
    start = loop.time()
    approved = await _wait_for_approval(
        {"actions": []}, episode, store, config, waiters=waiters,
    )
    elapsed = loop.time() - start
    await resolver

    assert approved is True
    assert elapsed < 0.5, f"Event-based resumption took {elapsed:.3f}s (>0.5s)"
    # Waiter must be cleaned up after resolution so the registry doesn't leak.
    assert waiters.is_empty()


# ---------------------------------------------------------------------------
# Semaphore: 4th event can reach approval wait while 3 others execute
# ---------------------------------------------------------------------------


async def test_semaphore_limit_respected(tmp_path: Path) -> None:
    """The runner semaphore starts at 3; concurrent events can proceed."""
    config = _make_config(tmp_path)
    runner, registry, db = _make_runner(tmp_path, config)

    # Verify semaphore initial value
    assert runner._semaphore._value == 3


# ---------------------------------------------------------------------------
# _execute_with_retry
# ---------------------------------------------------------------------------


async def test_execute_with_retry_succeeds_first_attempt(tmp_path: Path) -> None:
    """_execute_with_retry returns on first success."""
    config = _make_config(tmp_path)
    plan: dict[str, Any] = {"skip_reason": None, "actions": []}

    with patch("sagex.runner._run_tests", return_value="pass"):
        result = await _execute_with_retry(plan, config, None, config.runner)

    assert isinstance(result, ExecutionResult)


async def test_plan_phase_returns_plan_result_dataclass(tmp_path: Path) -> None:
    """Issue #27: happy path returns a typed ``PlanResult``, not a 10-tuple.

    Skip path returns ``None``.  Every field on a returned ``PlanResult``
    is guaranteed non-None so callers don't need ``# type: ignore`` to
    touch ``result.budget.name`` etc.
    """
    from sagex.runner import PlanResult

    config = _make_config(tmp_path)
    runner, _, db = _make_runner(tmp_path, config)

    with _patch_runner(db):
        result = await runner._plan_phase(_event(), config)

    assert isinstance(result, PlanResult), f"expected PlanResult, got {type(result)}"
    # Every slot that used to silently receive None on the error tuple is
    # now guaranteed non-None on the success path.
    assert result.plan is not None
    assert result.budget is not None
    assert result.task_agent is not None
    assert result.meta_agent is not None
    assert result.store is not None


async def test_plan_phase_returns_none_on_triage_skip(tmp_path: Path) -> None:
    """Skip-path contract: triage 'skip' must produce ``None``, not a tuple.

    The PlanResult refactor (issue #27) collapsed every skip branch onto
    a single ``return None`` sentinel.  Without a direct assertion of
    that contract, a future regression that returned a half-populated
    PlanResult (or even an empty tuple) on the skip path would still
    pass the happy-path test and the integration test (which only
    observes the *episode*, not the return value).

    We use ``docs/README.md`` to exercise the *rule-based* triage skip
    path: ``.md`` is in ``SKIP_EXTENSIONS``, so ``rule_based_triage``
    returns "skip" before any LLM is consulted.  That's the cheapest
    skip route through ``_plan_phase`` — ideal for a sentinel test.
    No LLM responses are queued because none should be consumed.
    """
    config = _make_config(tmp_path)
    runner, _, db = _make_runner(tmp_path, config)

    event = AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="test-proj",
        repo_root="/repo",
        file_paths=["docs/README.md"],
        diff="+x\n",
    )

    with _patch_runner(db):
        result = await runner._plan_phase(event, config)

    assert result is None, (
        f"Expected None on triage-skip path, got {type(result).__name__}"
    )
    # The episode must have been recorded as skipped before returning.
    eps = db.get_recent_episodes("test-proj", limit=5)
    assert any(ep.status == "skipped" for ep in eps)


# ---------------------------------------------------------------------------
# Gap #3: max_concurrent_tasks taken from constructor param
# ---------------------------------------------------------------------------


def test_runner_semaphore_uses_max_concurrent_tasks_param(tmp_path: Path) -> None:
    """Runner honours the max_concurrent_tasks constructor parameter."""
    db = _make_db(tmp_path)
    bus = EventBus(db)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    runner = Runner(bus, registry, watcher_manager, max_concurrent_tasks=5)
    assert runner._semaphore._value == 5


# ---------------------------------------------------------------------------
# Gap #6: _maybe_notify is async def
# ---------------------------------------------------------------------------


def test_maybe_notify_is_async() -> None:
    """_maybe_notify must be declared async def so it runs in the event loop."""
    from sagex.runner import _maybe_notify

    assert asyncio.iscoroutinefunction(_maybe_notify)


# ---------------------------------------------------------------------------
# Gap #8: security_risk log emitted when security enabled and risk found
# ---------------------------------------------------------------------------


async def test_security_risk_log_emitted_when_risk_found(tmp_path: Path) -> None:
    """security_risk is logged when the pattern scan detects a risk."""
    config = _make_config(tmp_path, security_enabled=True, auto_remediate=False)
    runner, registry, db = _make_runner(tmp_path, config)

    log_records: list[logging.LogRecord] = []

    class _CapHandler(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            log_records.append(record)

    import sagex.runner as runner_mod

    logger = logging.getLogger(runner_mod.__name__)
    old_level = logger.level
    logger.setLevel(logging.DEBUG)
    handler = _CapHandler()
    logger.addHandler(handler)

    # diff with a hardcoded credential triggers "critical" security risk
    risky_event = AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="test-proj",
        repo_root="/repo",
        file_paths=["config.py"],
        diff='+API_KEY = "sk-abcdefghijklmnopqrstuvwx"\n',
    )

    try:
        with _patch_runner(db):
            await runner._handle_event(risky_event)
    finally:
        logger.removeHandler(handler)
        logger.setLevel(old_level)

    msgs = [r.getMessage() for r in log_records]
    assert "security_risk" in msgs


# ---------------------------------------------------------------------------
# Gap #2: auto_remediate=True calls SecurityAgent.audit() and continues
# ---------------------------------------------------------------------------


async def test_auto_remediate_calls_security_audit_and_continues(
    tmp_path: Path,
) -> None:
    """When auto_remediate=True and a risk is found, SecurityAgent.audit is called
    and the event continues to the task agent (episode is NOT skipped)."""
    config = _make_config(tmp_path, security_enabled=True, auto_remediate=True)
    runner, registry, db = _make_runner(tmp_path, config)

    # audit() returns a minimal security report; task + meta follow
    audit_response = (
        '{"severity":"critical","description":"hardcoded key",'
        '"file_path":"config.py","remediation":null}'
    )
    plan_response = (
        '{"summary":"remove key","severity":"critical","actions":[],'
        '"checks_required":[],"rules_applied":[],"confidence":0.9,"skip_reason":null}'
    )
    meta_response = (
        '{"outcome":"good","outcome_reason":"key removed",'
        '"lesson":null,"rule":null,"rule_updates":[]}'
    )

    stub = StubAnthropicClient(
        responses=[audit_response, plan_response, meta_response]
    )
    budget = BudgetManager(
        BudgetConfig(),
        TokenTracker(db),
        ContentCache(db, ttl_minutes=60),
        client=stub,
    )

    async def _fake_budget(_config: Any) -> BudgetManager:
        return budget

    risky_event = AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="test-proj",
        repo_root="/repo",
        file_paths=["config.py"],
        diff='+API_KEY = "sk-abcdefghijklmnopqrstuvwx"\n',
    )

    with patch.multiple(
        "sagex.runner",
        _make_budget_manager=_fake_budget,
        _run_tests=AsyncMock(return_value="pass"),
    ):
        await runner._handle_event(risky_event)

    episodes = db.get_recent_episodes("test-proj", limit=10)
    assert len(episodes) >= 1
    # episode must NOT be skipped — it continued past security check
    assert episodes[0].status == "completed"


async def test_execute_with_retry_retries_on_failure(tmp_path: Path) -> None:
    """_execute_with_retry retries up to retry_max_attempts."""
    config = _make_config(tmp_path)
    plan: dict[str, Any] = {"skip_reason": None, "actions": []}

    call_count = 0

    async def _failing_execute(
        self: Any, plan: Any, config: Any, test_output_before: Any = None
    ) -> ExecutionResult:
        nonlocal call_count
        call_count += 1
        if call_count < 3:
            raise RuntimeError("transient error")
        return ExecutionResult(test_result="pass")

    with patch("sagex.runner.ActionExecutor.execute", _failing_execute):
        with patch("sagex.runner.asyncio.sleep", new=AsyncMock(return_value=None)):
            result = await _execute_with_retry(plan, config, None, config.runner)

    assert call_count == 3
    assert result.test_result == "pass"


# ---------------------------------------------------------------------------
# Provider-cache LRU eviction (prevents unbounded growth across projects)
# ---------------------------------------------------------------------------


async def test_provider_cache_evicts_oldest_when_capacity_reached() -> None:
    """_evict_lru_if_full pops the least-recently-used provider and closes it.

    Without this, a server registering many distinct provider configs (or
    re-registering with flipping settings) would grow _PROVIDER_CACHE
    without bound, leaking httpx pools per entry.

    Holds ``_PROVIDER_CACHE_LOCK`` around the call because
    ``_evict_lru_if_full`` asserts the lock is held — if that runtime
    assertion is ever removed and this test stops exercising the lock,
    the test still passes while production loses an ordering guarantee.
    """
    from sagex import runner as runner_module

    class _FakeProvider:
        def __init__(self, name: str) -> None:
            self.name = name
            self.closed = False

        async def aclose(self) -> None:
            self.closed = True

    saved = runner_module._PROVIDER_CACHE
    saved_cap = runner_module._MAX_PROVIDER_CACHE
    try:
        runner_module._PROVIDER_CACHE = OrderedDict()
        runner_module._MAX_PROVIDER_CACHE = 3

        a, b, c, d = (_FakeProvider(n) for n in ("a", "b", "c", "d"))
        runner_module._PROVIDER_CACHE[("k1",)] = a
        runner_module._PROVIDER_CACHE[("k2",)] = b
        runner_module._PROVIDER_CACHE[("k3",)] = c

        # The runtime assertion inside _evict_lru_if_full requires the
        # lock to be held — mirror the production invariant here so any
        # future "oh I don't need the lock in this one case" refactor is
        # caught by the guard.
        async with runner_module._PROVIDER_CACHE_LOCK:
            # Cap reached; evicting before an insert removes the oldest (a).
            await runner_module._evict_lru_if_full()
            runner_module._PROVIDER_CACHE[("k4",)] = d

        assert a.closed is True
        assert b.closed is False and c.closed is False and d.closed is False
        assert list(runner_module._PROVIDER_CACHE.keys()) == [
            ("k2",), ("k3",), ("k4",),
        ]
    finally:
        runner_module._PROVIDER_CACHE = saved
        runner_module._MAX_PROVIDER_CACHE = saved_cap


async def test_evict_lru_if_full_requires_lock() -> None:
    """_evict_lru_if_full must refuse to run without _PROVIDER_CACHE_LOCK held.

    The lock-held assertion is there so future refactors that drop the
    ``async with`` around provider construction can't silently regress
    the check-then-evict-then-insert ordering — concurrent misses would
    otherwise both evict, both construct, both insert, and one provider
    would orphan (pool never closed, slot overwritten).
    """
    from sagex import runner as runner_module

    saved = runner_module._PROVIDER_CACHE
    saved_cap = runner_module._MAX_PROVIDER_CACHE
    try:
        runner_module._PROVIDER_CACHE = OrderedDict()
        runner_module._MAX_PROVIDER_CACHE = 3
        # Lock NOT held → the assertion should fail.
        import pytest

        with pytest.raises(AssertionError, match="_PROVIDER_CACHE_LOCK"):
            await runner_module._evict_lru_if_full()
    finally:
        runner_module._PROVIDER_CACHE = saved
        runner_module._MAX_PROVIDER_CACHE = saved_cap


async def test_aclose_is_atomic_against_concurrent_make(tmp_path: Path) -> None:
    """Runner.aclose must drain the cache atomically under _PROVIDER_CACHE_LOCK.

    Regression test for issue #23: without the lock, a concurrent
    ``_make_budget_manager`` insert could race the ``clear()`` — the
    insert would land after clear(), leaking an un-closed provider past
    shutdown.  We simulate by holding the lock from outside so
    ``aclose`` has to wait, proving it takes the lock.
    """
    from sagex import runner as runner_module

    config = _make_config(tmp_path)
    runner, _, _ = _make_runner(tmp_path, config)

    saved = runner_module._PROVIDER_CACHE
    saved_closed = runner_module._PROVIDER_CACHE_CLOSED
    try:
        runner_module._PROVIDER_CACHE = OrderedDict()
        runner_module._PROVIDER_CACHE_CLOSED = False

        class _P:
            def __init__(self) -> None:
                self.closed = False

            async def aclose(self) -> None:
                self.closed = True

        provider = _P()
        runner_module._PROVIDER_CACHE[("k",)] = provider

        # Hold the lock from "another task" — aclose should block on it.
        async with runner_module._PROVIDER_CACHE_LOCK:
            aclose_task = asyncio.create_task(runner.aclose())
            # Give the task a chance to try to enter the lock.
            await asyncio.sleep(0.05)
            # It must NOT have cleared the cache yet — blocked on the lock.
            assert list(runner_module._PROVIDER_CACHE.keys()) == [("k",)]
            assert provider.closed is False
        # Lock released — aclose proceeds.
        await aclose_task
        assert provider.closed is True
        assert len(runner_module._PROVIDER_CACHE) == 0
        # The closed flag must be set so any in-flight constructor
        # observes it and doesn't re-populate the cache.
        assert runner_module._PROVIDER_CACHE_CLOSED is True
    finally:
        runner_module._PROVIDER_CACHE = saved
        # Reset the module-level closed flag — it would otherwise leak
        # across tests and make subsequent _make_budget_manager calls
        # raise ProviderCacheClosedError.
        runner_module._PROVIDER_CACHE_CLOSED = saved_closed


async def test_make_provider_blocking_does_not_block_other_keys(tmp_path: Path) -> None:
    """Construction for one key must not block construction for another (issue #20).

    Simulates a ``make_provider`` that takes 0.3s via ``time.sleep``; two
    concurrent calls for *different* cache keys must finish in wall time
    close to the single-call duration, not 2x it.  Before the fix, both
    were serialised by _PROVIDER_CACHE_LOCK held during construction.
    """
    import time

    from sagex import runner as runner_module

    class _P:
        def __init__(self, name: str) -> None:
            self.name = name

    # make_provider stand-in: synchronous, blocks 0.3s.
    def _slow_make_provider(agent: Any, enable_prompt_caching: bool = True) -> _P:
        time.sleep(0.3)
        return _P("slow")

    # Minimal config stub — _make_budget_manager touches only a few fields.
    cfg_a = _make_config(tmp_path)
    cfg_a.name = "proj-a"  # type: ignore[misc]
    cfg_b = _make_config(tmp_path)
    cfg_b.name = "proj-b"  # type: ignore[misc]
    cfg_b.knowledge.db_path = str(tmp_path / "proj-b.db")

    saved = runner_module._PROVIDER_CACHE
    saved_pending = runner_module._PROVIDER_CACHE_PENDING
    try:
        runner_module._PROVIDER_CACHE = OrderedDict()
        runner_module._PROVIDER_CACHE_PENDING = {}

        with patch(
            "sagex.llm.providers.make_provider", side_effect=_slow_make_provider
        ):
            loop = asyncio.get_running_loop()
            start = loop.time()
            await asyncio.gather(
                runner_module._make_budget_manager(cfg_a),
                runner_module._make_budget_manager(cfg_b),
            )
            elapsed = loop.time() - start

        # Sequentialised = ~0.6s.  Parallel (via asyncio.to_thread) = ~0.35s.
        # Allow generous headroom for CI jitter but catch the 2x regression.
        assert elapsed < 0.55, (
            f"Two concurrent distinct-key constructions took {elapsed:.3f}s — "
            f"they appear to be serialised by _PROVIDER_CACHE_LOCK (issue #20)."
        )
    finally:
        runner_module._PROVIDER_CACHE = saved
        runner_module._PROVIDER_CACHE_PENDING = saved_pending


async def test_evict_lru_if_full_no_op_when_cap_non_positive() -> None:
    """Misconfigured ``_MAX_PROVIDER_CACHE <= 0`` must not hang.

    Without the guard, the ``while len >= 0`` loop would popitem on an
    empty dict forever (raising KeyError on the second iteration, but
    not before the first call does something surprising).
    """
    from sagex import runner as runner_module

    saved = runner_module._PROVIDER_CACHE
    saved_cap = runner_module._MAX_PROVIDER_CACHE
    try:
        runner_module._PROVIDER_CACHE = OrderedDict()
        runner_module._MAX_PROVIDER_CACHE = 0
        async with runner_module._PROVIDER_CACHE_LOCK:
            # Must return without raising and without mutating the cache.
            await runner_module._evict_lru_if_full()
        assert len(runner_module._PROVIDER_CACHE) == 0
    finally:
        runner_module._PROVIDER_CACHE = saved
        runner_module._MAX_PROVIDER_CACHE = saved_cap


async def test_make_budget_manager_after_aclose_raises(tmp_path: Path) -> None:
    """Once ``Runner.aclose`` has set the closed flag, new
    ``_make_budget_manager`` calls must refuse rather than re-populate
    the cache (which would leak past shutdown — the new entry would be
    closed by no one).
    """
    from sagex import runner as runner_module

    saved_cache = runner_module._PROVIDER_CACHE
    saved_pending = runner_module._PROVIDER_CACHE_PENDING
    saved_closed = runner_module._PROVIDER_CACHE_CLOSED
    try:
        runner_module._PROVIDER_CACHE = OrderedDict()
        runner_module._PROVIDER_CACHE_PENDING = {}
        runner_module._PROVIDER_CACHE_CLOSED = True

        cfg = _make_config(tmp_path)
        with pytest.raises(runner_module.ProviderCacheClosedError):
            await runner_module._make_budget_manager(cfg)
    finally:
        runner_module._PROVIDER_CACHE = saved_cache
        runner_module._PROVIDER_CACHE_PENDING = saved_pending
        runner_module._PROVIDER_CACHE_CLOSED = saved_closed
