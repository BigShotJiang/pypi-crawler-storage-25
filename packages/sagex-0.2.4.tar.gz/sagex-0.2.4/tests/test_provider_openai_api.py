"""Unit tests for OpenAIProvider.

Uses a minimal stub that mimics ``openai.AsyncOpenAI.chat.completions.create``.
The real API is only touched by the opt-in E2E suite.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock

import openai
import pytest
from conftest import make_http_response

from sagex.llm.providers.base import ProviderAuthError, ProviderCallError
from sagex.llm.providers.openai_api import OpenAIProvider

# ---------------------------------------------------------------------------
# Stub
# ---------------------------------------------------------------------------


class _StubUsage:
    def __init__(self, prompt: int, completion: int, cached: int = 0) -> None:
        self.prompt_tokens = prompt
        self.completion_tokens = completion
        self.prompt_tokens_details = type(
            "_D", (), {"cached_tokens": cached}
        )()


class _StubMessage:
    def __init__(self, content: str) -> None:
        self.content = content


class _StubChoice:
    def __init__(self, content: str) -> None:
        self.message = _StubMessage(content)


class _StubResponse:
    def __init__(self, content: str, model: str = "gpt-5", usage: _StubUsage | None = None) -> None:
        self.choices = [_StubChoice(content)]
        self.model = model
        self.usage = usage or _StubUsage(prompt=10, completion=20)


class _StubCompletions:
    def __init__(self, response: _StubResponse) -> None:
        self._response = response
        self.last_kwargs: dict[str, Any] = {}
        self.create = AsyncMock(side_effect=self._create)

    async def _create(self, **kwargs: Any) -> _StubResponse:
        self.last_kwargs = kwargs
        return self._response


class _StubChat:
    def __init__(self, response: _StubResponse) -> None:
        self.completions = _StubCompletions(response)


class StubOpenAIClient:
    """Mimics the subset of ``openai.AsyncOpenAI`` the provider uses."""

    def __init__(self, content: str = "hello", model: str = "gpt-5") -> None:
        self.chat = _StubChat(_StubResponse(content, model=model))


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------


def test_raises_auth_error_when_no_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    with pytest.raises(ProviderAuthError, match="OPENAI_API_KEY"):
        OpenAIProvider()


def test_constructs_with_client_override() -> None:
    stub = StubOpenAIClient()
    p = OpenAIProvider(client=stub)
    assert p.name == "openai_api"


def test_supports_known_models_only() -> None:
    p = OpenAIProvider(client=StubOpenAIClient())
    assert p.supports_model("gpt-5") is True
    assert p.supports_model("gpt-4o-mini") is True
    assert p.supports_model("claude-sonnet-4-6") is False


# ---------------------------------------------------------------------------
# call() happy path
# ---------------------------------------------------------------------------


async def test_call_returns_call_result_from_stub() -> None:
    stub = StubOpenAIClient(content="hello from gpt", model="gpt-5")
    stub.chat.completions._response.usage = _StubUsage(
        prompt=42, completion=17, cached=10
    )
    p = OpenAIProvider(client=stub)
    result = await p.call(
        system="be helpful",
        user="hi",
        model="gpt-5",
        max_tokens=100,
        temperature=0.2,
    )
    assert result.text == "hello from gpt"
    assert result.input_tokens == 42
    assert result.output_tokens == 17
    assert result.cache_read_tokens == 10
    assert result.cache_write_tokens == 0
    assert result.model == "gpt-5"
    # Verify the SDK got the right args
    sent = stub.chat.completions.last_kwargs
    assert sent["model"] == "gpt-5"
    assert sent["messages"][0] == {"role": "system", "content": "be helpful"}
    assert sent["messages"][1] == {"role": "user", "content": "hi"}
    assert sent["max_tokens"] == 100
    assert sent["temperature"] == 0.2


# ---------------------------------------------------------------------------
# call() error paths
# ---------------------------------------------------------------------------


async def test_unsupported_model_raises_at_call_time() -> None:
    p = OpenAIProvider(client=StubOpenAIClient())
    with pytest.raises(ProviderCallError, match="not in the OpenAI provider"):
        await p.call(
            system="s", user="u", model="claude-sonnet-4-6",
            max_tokens=1, temperature=0.2,
        )


async def test_call_raises_provider_auth_error_on_authentication_failure() -> None:
    """openai.AuthenticationError -> ProviderAuthError (terminal, no retry)."""
    stub = StubOpenAIClient()
    stub.chat.completions.create = AsyncMock(
        side_effect=openai.AuthenticationError(
            message="bad key",
            response=make_http_response(401),
            body=None,
        )
    )
    p = OpenAIProvider(client=stub)
    with pytest.raises(ProviderAuthError, match="OpenAI auth failed"):
        await p.call(
            system="s", user="u", model="gpt-5",
            max_tokens=1, temperature=0.2,
        )


# ---------------------------------------------------------------------------
# is_retryable_error — per-provider retry classification (review fix #5)
# ---------------------------------------------------------------------------


def test_is_retryable_error_classification() -> None:
    """OpenAIProvider.is_retryable_error covers each branch."""
    p = OpenAIProvider(client=StubOpenAIClient())

    rate_limit = openai.RateLimitError(
        message="slow down", response=make_http_response(429), body=None,
    )
    assert p.is_retryable_error(rate_limit) is True

    five_hundred = openai.APIStatusError(
        message="server down", response=make_http_response(503), body=None,
    )
    assert p.is_retryable_error(five_hundred) is True

    four_hundred = openai.APIStatusError(
        message="bad request", response=make_http_response(400), body=None,
    )
    assert p.is_retryable_error(four_hundred) is False

    # ProviderCallError -> retry (local wrap for unknown model etc.)
    assert p.is_retryable_error(ProviderCallError("x")) is True

    # Unrelated errors -> no retry
    assert p.is_retryable_error(ValueError("nope")) is False


# ---------------------------------------------------------------------------
# Retry — BudgetManager must retry on openai.RateLimitError (review fix #2)
# ---------------------------------------------------------------------------


async def test_budget_manager_retries_openai_rate_limit_error(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Regression for review finding #2: OpenAI RateLimitError must hit the
    BudgetManager retry loop and succeed on the second attempt."""
    from sagex.config import BudgetConfig
    from sagex.knowledge.rules_db import RulesDB
    from sagex.llm.budget import BudgetManager
    from sagex.llm.cache import ContentCache
    from sagex.llm.providers.base import CallResult
    from sagex.llm.token_tracker import TokenTracker

    # Provider that raises RateLimitError on first call, succeeds on second.
    class _FlakyOpenAIProvider:
        name = "openai_api"
        calls = 0

        def supports_model(self, _m: str) -> bool:
            return True

        def is_retryable_error(self, exc: BaseException) -> bool:
            return isinstance(exc, openai.RateLimitError)

        async def call(self, **_kwargs: Any) -> CallResult:
            _FlakyOpenAIProvider.calls += 1
            if _FlakyOpenAIProvider.calls == 1:
                raise openai.RateLimitError(
                    message="slow down",
                    response=make_http_response(429),
                    body=None,
                )
            return CallResult(
                text="ok",
                input_tokens=1,
                output_tokens=1,
                model="gpt-5",
            )

    db = RulesDB(str(tmp_path / "r.db"))
    tracker = TokenTracker(db)
    cache = ContentCache(db, ttl_minutes=60)
    mgr = BudgetManager(
        BudgetConfig(hourly_token_limit=1_000_000, daily_token_limit=10_000_000),
        tracker,
        cache,
        provider=_FlakyOpenAIProvider(),  # type: ignore[arg-type]
    )

    # Skip backoff via monkeypatch (auto-cleans up even on crash, unlike
    # manual try/finally which could leak the stub into other tests).
    import asyncio
    monkeypatch.setattr(asyncio, "sleep", AsyncMock(return_value=None))

    text = await mgr.call(
        project="proj", agent_type="task",
        system="s", user="u", model="gpt-5",
        max_tokens=10, temperature=0.2,
    )

    assert text == "ok"
    assert _FlakyOpenAIProvider.calls == 2  # retried once, succeeded
