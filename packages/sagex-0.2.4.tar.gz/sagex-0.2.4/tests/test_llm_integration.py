"""Real LLM integration tests — require ANTHROPIC_API_KEY.

Run with:  pytest tests/test_llm_integration.py -v -m llm
Excluded from CI: pytest -m "not llm"

Each test makes one or more real API calls and asserts on the structure of
the response, not on specific wording (which can vary across model versions).
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from sagex.agents.meta_agent import MetaAgent
from sagex.agents.security_agent import SecurityAgent, SecurityRisk
from sagex.agents.task_agent import TaskAgent
from sagex.agents.triage_agent import TriageAgent
from sagex.config import (
    AgentConfig,
    BudgetConfig,
    KnowledgeConfig,
    SecurityAgentConfig,
)
from sagex.event_bus import AgentEvent, EventType
from sagex.knowledge.rules_db import Episode, RulesDB
from sagex.knowledge.store import KnowledgeStore
from sagex.llm.budget import BudgetManager
from sagex.llm.cache import ContentCache
from sagex.llm.token_tracker import TokenTracker

pytestmark = pytest.mark.llm


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _require_api_key() -> str:
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not key or key.startswith("sk-ant-..."):
        pytest.skip("ANTHROPIC_API_KEY not set")
    return key


def _make_budget(db: RulesDB, api_key: str) -> BudgetManager:
    tracker = TokenTracker(db)
    cache = ContentCache(db, ttl_minutes=60)
    config = BudgetConfig(hourly_token_limit=50_000, daily_token_limit=500_000)
    return BudgetManager(config, tracker, cache, api_key=api_key)


def _make_db(tmp_path: Path) -> RulesDB:
    db = RulesDB(str(tmp_path / "rules.db"))
    db.run_migrations(
        Path(__file__).parent.parent / "src" / "sagex" / "knowledge" / "migrations"
    )
    return db


def _event(diff: str = "+x = 1\n", file_paths: list[str] | None = None) -> AgentEvent:
    return AgentEvent(
        type=EventType.FILE_MODIFIED,
        project_name="llm-test",
        repo_root="/repo",
        file_paths=file_paths or ["auth.py"],
        diff=diff,
    )


def _agent_config() -> AgentConfig:
    return AgentConfig(
        model="claude-haiku-4-5",       # use cheapest model for LLM tests
        triage_model="claude-haiku-4-5",
        max_tokens=1024,
    )


# ---------------------------------------------------------------------------
# Triage agent
# ---------------------------------------------------------------------------


async def test_llm_triage_classifies_severity(tmp_path: Path) -> None:
    """Real Haiku call: TriageAgent returns a valid severity for a code change."""
    api_key = _require_api_key()
    db = _make_db(tmp_path)
    budget = _make_budget(db, api_key)
    agent = TriageAgent(_agent_config(), budget)

    # A large diff on an unknown file forces LLM triage
    large_diff = "+def risky_function():\n" + "+    pass\n" * 20
    result = await agent.classify(_event(diff=large_diff, file_paths=["service.py"]))

    assert result.severity in ("skip", "low", "medium", "high", "critical")
    assert result.used_llm is True
    assert isinstance(result.reason, str) and len(result.reason) > 0


async def test_llm_triage_skips_log_file_without_llm(tmp_path: Path) -> None:
    """Rule-based skip still works end-to-end (no API call)."""
    api_key = _require_api_key()
    db = _make_db(tmp_path)
    budget = _make_budget(db, api_key)
    agent = TriageAgent(_agent_config(), budget)

    result = await agent.classify(_event(file_paths=["app.log"]))

    assert result.severity == "skip"
    assert result.used_llm is False


# ---------------------------------------------------------------------------
# Task agent
# ---------------------------------------------------------------------------


async def test_llm_task_agent_returns_valid_plan(tmp_path: Path) -> None:
    """Real Haiku call: TaskAgent.plan() returns a structurally valid JSON plan."""
    api_key = _require_api_key()
    db = _make_db(tmp_path)
    budget = _make_budget(db, api_key)
    agent = TaskAgent(_agent_config(), budget)

    store = KnowledgeStore(
        KnowledgeConfig(
            db_path=str(tmp_path / "rules.db"),
            vector_path=str(tmp_path / "vectors"),
        ),
        "llm-test",
    )
    context = await store.get_relevant_context("FILE_MODIFIED: auth.py")

    from sagex.agents.triage_agent import TriageResult

    triage = TriageResult(severity="medium", reason="auth change", used_llm=False)
    plan = await agent.plan(_event(), triage, context, "pass")

    assert isinstance(plan, dict)
    assert "summary" in plan
    assert "severity" in plan
    assert plan["severity"] in ("low", "medium", "high", "critical")
    assert "actions" in plan
    assert isinstance(plan["actions"], list)
    assert "confidence" in plan
    assert 0.0 <= float(plan["confidence"]) <= 1.0


# ---------------------------------------------------------------------------
# Meta agent
# ---------------------------------------------------------------------------


async def test_llm_meta_agent_reflects_on_good_outcome(tmp_path: Path) -> None:
    """Real Haiku call: MetaAgent.reflect() returns valid outcome JSON."""
    api_key = _require_api_key()
    db = _make_db(tmp_path)
    budget = _make_budget(db, api_key)
    agent = MetaAgent(_agent_config(), budget)

    from sagex.agents.task_agent import ExecutionResult
    from sagex.agents.triage_agent import TriageResult

    triage = TriageResult(severity="low", reason="minor change", used_llm=False)
    result = ExecutionResult(
        test_result="pass",
        actions_taken=["edit auth.py"],
        files_modified=["auth.py"],
    )
    episode = Episode(
        project_name="llm-test",
        trigger_event="{}",
        context_snapshot="{}",
        status="completed",
        test_result_before="pass",
        test_result_after="pass",
        regression_detected=0,
    )

    reflection = await agent.reflect(_event(), triage, {}, result, episode)

    assert isinstance(reflection, dict)
    assert reflection.get("outcome") in ("good", "partial", "bad")
    assert "outcome_reason" in reflection
    assert "rule_updates" in reflection
    assert isinstance(reflection["rule_updates"], list)


async def test_llm_meta_agent_detects_regression(tmp_path: Path) -> None:
    """Real Haiku call: MetaAgent includes regression signal when tests go from pass→fail."""
    api_key = _require_api_key()
    db = _make_db(tmp_path)
    budget = _make_budget(db, api_key)
    agent = MetaAgent(_agent_config(), budget)

    from sagex.agents.task_agent import ExecutionResult
    from sagex.agents.triage_agent import TriageResult

    triage = TriageResult(severity="medium", reason="auth change", used_llm=False)
    result = ExecutionResult(
        test_result="fail",
        actions_taken=["edit auth.py"],
        files_modified=["auth.py"],
        errors=["AssertionError in test_login"],
    )
    episode = Episode(
        project_name="llm-test",
        trigger_event="{}",
        context_snapshot="{}",
        status="completed",
        test_result_before="pass",
        test_result_after="fail",
        regression_detected=1,
    )

    reflection = await agent.reflect(_event(), triage, {}, result, episode)

    # Regression → outcome should not be "good"
    assert reflection.get("outcome") in ("partial", "bad")


# ---------------------------------------------------------------------------
# Security agent
# ---------------------------------------------------------------------------


async def test_llm_security_agent_audits_credential_leak(tmp_path: Path) -> None:
    """Real Haiku call: SecurityAgent.audit() returns a structured report."""
    api_key = _require_api_key()
    db = _make_db(tmp_path)
    budget = _make_budget(db, api_key)
    agent = SecurityAgent(
        _agent_config(),
        budget,
        SecurityAgentConfig(enabled=True, auto_remediate=False),
    )

    diff = '+API_KEY = "sk-abcdefghijklmnopqrstuvwxyz"\n'
    risk = SecurityRisk(
        severity="critical",
        pattern_matched=r"(api_key)\s*=\s*['\"][^'\"]{8,}['\"]",
        description="Hardcoded credential detected",
        line_numbers=[1],
        file_path="config.py",
    )

    report = await agent.audit(_event(diff=diff, file_paths=["config.py"]), diff, risk)

    assert isinstance(report, dict)
    assert "severity" in report
    assert report["severity"] in ("critical", "high", "medium")
    assert "description" in report


# ---------------------------------------------------------------------------
# Budget layer: token tracking round-trip
# ---------------------------------------------------------------------------


async def test_llm_token_usage_recorded_after_real_call(tmp_path: Path) -> None:
    """After a real API call, token_usage row is persisted to SQLite."""
    from datetime import UTC, datetime, timedelta

    api_key = _require_api_key()
    db = _make_db(tmp_path)
    budget = _make_budget(db, api_key)

    await budget.call(
        project="llm-test",
        agent_type="triage",
        system="You are a helpful assistant. Reply with one word.",
        user="Say 'hello'.",
        model="claude-haiku-4-5",
        max_tokens=10,
    )

    since = (datetime.now(UTC) - timedelta(minutes=5)).isoformat()
    rows = db.get_token_usage("llm-test", since_iso=since)
    assert len(rows) == 1
    assert rows[0].input_tokens > 0
    assert rows[0].output_tokens > 0
    assert rows[0].agent_type == "triage"
