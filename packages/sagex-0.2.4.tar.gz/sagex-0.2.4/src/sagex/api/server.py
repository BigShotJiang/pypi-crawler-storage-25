"""FastAPI application factory and project registry.

The app is wired up here; all routes live in ``routes.py``.
"""

from __future__ import annotations

import asyncio
from collections import OrderedDict
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any

from fastapi import FastAPI

from sagex.config import ProjectConfig

if TYPE_CHECKING:
    from sagex.event_bus import EventBus
    from sagex.watcher import WatcherManager


# ---------------------------------------------------------------------------
# Project registry
# ---------------------------------------------------------------------------


class ProjectRegistry:
    """In-memory registry of active ``ProjectConfig`` objects."""

    def __init__(self) -> None:
        self._projects: dict[str, ProjectConfig] = {}

    def register(self, config: ProjectConfig) -> None:
        """Add or replace a project configuration."""
        self._projects[config.name] = config

    def deregister(self, name: str) -> None:
        """Remove a project by name.  No-op if not found."""
        self._projects.pop(name, None)

    def get(self, name: str) -> ProjectConfig | None:
        """Return the ``ProjectConfig`` for *name*, or ``None``."""
        return self._projects.get(name)

    def list_all(self) -> list[ProjectConfig]:
        """Return all registered project configs."""
        return list(self._projects.values())


# Cap on the in-memory pre-set/orphan event registry.  Without a cap, an
# API instance running without (or out of sync with) a registered runner
# would accumulate one entry per approve/reject call forever — every
# notify() pre-creates an event whose corresponding register() never
# arrives.  1024 is far above any realistic in-flight approval depth.
_MAX_APPROVAL_EVENTS: int = 1024


class ApprovalWaiters:
    """Shared registry of ``asyncio.Event`` per pending approval id.

    Used by the runner to block on an approval and by the API routes to
    signal resolution without waiting for the next poll tick.  The DB row
    is still the source of truth — the event is only a wake-up signal.
    This keeps the runner restart-safe: if the process died and lost the
    event, the fallback poll (~30s) will still see the resolution in the
    pending_approvals table.

    ``asyncio.Event`` is not thread-safe; only touch these from the event
    loop thread.

    Bounded growth: ``_events`` is an ``OrderedDict`` capped at
    ``_MAX_APPROVAL_EVENTS``.  The cap matters for the orphan-notify
    case — if no runner is wired to this registry, every approve/reject
    pre-creates an event that no one ever consumes.  Insertions evict
    the LRU entry on overflow (FIFO of last-touched).
    """

    def __init__(self) -> None:
        self._events: OrderedDict[str, asyncio.Event] = OrderedDict()

    def _insert(self, approval_id: str, event: asyncio.Event) -> None:
        """Install *event* under *approval_id*, evicting LRU on overflow."""
        self._events[approval_id] = event
        self._events.move_to_end(approval_id)
        while len(self._events) > _MAX_APPROVAL_EVENTS:
            self._events.popitem(last=False)

    def register(self, approval_id: str) -> asyncio.Event:
        event = self._events.get(approval_id)
        if event is None:
            event = asyncio.Event()
            self._insert(approval_id, event)
        else:
            # Bump freshness so a later overflow eviction targets cold
            # entries first.
            self._events.move_to_end(approval_id)
        return event

    def notify(self, approval_id: str) -> None:
        """Signal any waiter on *approval_id* that its row has been resolved.

        If resolution wins the race against ``register()`` (the API route
        finishes resolving before the runner has called ``register``), create
        and pre-set the event now.  A later ``register()`` then returns an
        already-set event and the waiter wakes immediately instead of
        sleeping until the next ~30s fallback poll.

        The orphan-notify case (no waiter ever registers) is bounded by
        ``_MAX_APPROVAL_EVENTS`` via LRU eviction in ``_insert`` — without
        it, every approve/reject in a runner-less deployment would leak
        an Event forever.
        """
        event = self._events.get(approval_id)
        if event is None:
            event = asyncio.Event()
            self._insert(approval_id, event)
        else:
            self._events.move_to_end(approval_id)
        event.set()

    def discard(self, approval_id: str) -> None:
        """Drop the event for *approval_id* once the waiter has observed it."""
        self._events.pop(approval_id, None)

    def is_empty(self) -> bool:
        """Return True if no approval is currently being tracked.

        Public inspection helper for tests/diagnostics — avoids reaching
        into ``self._events`` from outside.
        """
        return not self._events

    def pending_ids(self) -> list[str]:
        """Return a snapshot of the currently tracked approval ids."""
        return list(self._events)


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------


def create_app(
    bus: EventBus,
    watcher_manager: WatcherManager,
    registry: ProjectRegistry,
    runner: Any | None = None,
    approval_waiters: ApprovalWaiters | None = None,
) -> FastAPI:
    """Create and return the FastAPI application.

    Parameters
    ----------
    bus:
        The shared ``EventBus`` instance.
    watcher_manager:
        The ``WatcherManager`` that controls filesystem watchers.
    registry:
        The ``ProjectRegistry`` holding all registered projects.
    runner:
        Optional runner task (may be ``None`` in tests).
    approval_waiters:
        Optional ``ApprovalWaiters`` registry shared with the runner so
        resolved approvals wake waiters instantly (issue #10).  A fresh
        registry is created when not provided.
    """

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        # Startup: reload any persisted unprocessed events
        bus.reload_persisted_events()
        yield
        # Shutdown: stop watchers, then release cached provider resources
        # (httpx pools, etc.) so sockets drain cleanly instead of surfacing
        # "unclosed client" warnings at interpreter exit.
        watcher_manager.stop_all()
        if runner is not None:
            try:
                await runner.aclose()
            except Exception:  # noqa: BLE001 — best-effort at shutdown
                pass

    app = FastAPI(
        title="Agent Runtime",
        version="0.1.0",
        lifespan=lifespan,
    )
    app.state.bus = bus
    app.state.registry = registry
    app.state.watcher_manager = watcher_manager
    app.state.runner = runner
    app.state.approval_waiters = approval_waiters or ApprovalWaiters()

    # Register routes
    from sagex.api.routes import router  # noqa: PLC0415

    app.include_router(router)

    return app
