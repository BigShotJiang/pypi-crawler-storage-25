"""All API route handlers for the Agent Runtime server."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from sagex.config import load_config
from sagex.constants import TEMPLATE_PLACEHOLDER_NAME
from sagex.event_bus import AgentEvent, EventType
from sagex.knowledge.rules_db import RulesDB
from sagex.knowledge.store import KnowledgeStore

router = APIRouter()
_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class RegisterRequest(BaseModel):
    config_path: str
    force: bool = False


class NotifyRequest(BaseModel):
    project_name: str
    event_type: str
    repo_root: str
    file_paths: list[str] = []
    diff: str | None = None
    diff_context: str | None = None
    extra: dict[str, Any] = {}


# Hook scripts use short verbs ("commit", "push") that don't match the
# wire-format EventType enum values ("git_commit", ...).  Without this
# map, ``EventType("commit")`` raises and the route silently falls back to
# FILE_MODIFIED — which is what put 69 mistyped events in this repo's
# rules.db.  Any new hook event names go here, not in EventType.
_HOOK_EVENT_TO_TYPE: dict[str, EventType] = {
    "commit": EventType.GIT_COMMIT,
    "push": EventType.GIT_COMMIT,
}


class RuleFeedbackRequest(BaseModel):
    was_correct: bool


class UsageQueryRequest(BaseModel):
    period: str = "24h"


class RulesExportRequest(BaseModel):
    min_confidence: float = 0.85
    min_applied: int = 10


class RulesImportRequest(BaseModel):
    rules: list[dict[str, Any]]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _get_db(request: Request, project_name: str) -> RulesDB:
    """Return the RulesDB for *project_name*, or raise 404.

    Caches one RulesDB instance per db_path in ``app.state._db_cache`` so
    each project's SQLite connection + migrations check is paid once per
    process.  ``RulesDB.__init__`` already runs migrations from its own
    package-relative ``migrations`` dir, so we don't re-invoke them here.

    Concurrency: cache population is guarded by ``_db_cache_lock``.  The
    blocking work (``sqlite3.connect`` + migrations) runs via
    ``asyncio.to_thread`` so the event loop isn't pinned for unrelated
    requests during the first-touch initialisation; only the
    cache-bookkeeping bracket is on the loop thread.
    """
    registry = request.app.state.registry
    config = registry.get(project_name)
    if config is None:
        raise HTTPException(status_code=404, detail=f"Project '{project_name}' not found")

    state = request.app.state
    if not hasattr(state, "_db_cache"):
        state._db_cache = {}
    if not hasattr(state, "_db_cache_lock"):
        state._db_cache_lock = asyncio.Lock()

    db_cache: dict[str, RulesDB] = state._db_cache
    db_path = config.knowledge.db_path
    if db_path in db_cache:
        return db_cache[db_path]

    async with state._db_cache_lock:
        # Re-check under the lock: another request may have constructed
        # this DB between our first `in` check and acquiring the lock.
        if db_path in db_cache:
            return db_cache[db_path]
        # ``RulesDB(...)`` does sqlite3.connect + run_migrations — both
        # blocking I/O.  Offload to a worker thread so concurrent
        # requests for *other* projects aren't stalled waiting on this
        # one's first-touch initialisation.
        db = await asyncio.to_thread(RulesDB, db_path)
        db_cache[db_path] = db
        return db


def _validate_knowledge_paths(config: Any, config_path: Path) -> None:
    """Reject knowledge paths that escape the project's repo_root.

    The runtime opens ``knowledge.db_path`` as SQLite and ``knowledge.vector_path``
    as ChromaDB, both of which create files on write.  Without this check a
    config.yaml attacker (or any CI job that drops its own ``.agents/`` dir)
    could direct writes to arbitrary filesystem locations under the server
    process's identity — see issue #13.

    Rules enforced:

    * The trust anchor is the *derived* repo root: ``config_path.parent.parent``
      (since the register handler requires ``<dir>/.agents/config.yaml``).
      ``config.repo_root`` is *untrusted* — a hostile config can set it to
      ``/`` and turn any relative ``db_path`` into an arbitrary write — so
      the declared ``repo_root`` must equal the derived one (after resolve).
    * ``db_path`` and ``vector_path`` must not be absolute paths.
    * They must not contain ``..`` segments.
    * After joining with the derived repo root, the resolved location must
      stay inside it (catches symlink escapes).

    Side effect: on success, mutates ``config.knowledge.db_path`` and
    ``config.knowledge.vector_path`` to the *resolved absolute* paths so
    downstream openers (``RulesDB(...)``, ``VectorDB(...)``) don't
    re-interpret the relative form against the server's current working
    directory — that would reintroduce the very write-outside-tree bug
    this validator exists to prevent.

    Raises ``HTTPException(400)`` on any violation.
    """
    derived_root = config_path.parent.parent.resolve()
    declared_root = Path(config.repo_root).resolve()
    if declared_root != derived_root:
        raise HTTPException(
            status_code=400,
            detail=(
                f"repo_root {config.repo_root!r} does not match the "
                f"directory containing .agents/config.yaml ({derived_root}). "
                "repo_root must point at that directory."
            ),
        )
    repo_root = derived_root
    for field in ("db_path", "vector_path"):
        raw = getattr(config.knowledge, field)
        if not raw:
            raise HTTPException(status_code=400, detail=f"knowledge.{field} must not be empty")
        p = Path(raw)
        if p.is_absolute():
            raise HTTPException(
                status_code=400,
                detail=f"knowledge.{field} must be a relative path; got {raw!r}",
            )
        if any(part == ".." for part in p.parts):
            raise HTTPException(
                status_code=400,
                detail=f"knowledge.{field} must not contain '..' segments; got {raw!r}",
            )
        resolved = (repo_root / p).resolve()
        try:
            resolved.relative_to(repo_root)
        except ValueError as exc:
            # Symlink escape or other form of path that resolves outside
            # the repo tree after normalisation.
            raise HTTPException(
                status_code=400,
                detail=(
                    f"knowledge.{field} resolves outside repo_root: "
                    f"{resolved} is not under {repo_root}"
                ),
            ) from exc
        # Pin the validated absolute path into the config so downstream
        # callers (RulesDB / VectorDB) don't re-evaluate the original
        # relative value against the server's cwd.
        setattr(config.knowledge, field, str(resolved))


def _period_to_iso(period: str) -> str:
    """Convert a period string like '24h' or '7d' to an ISO timestamp string."""
    import datetime

    if len(period) < 2 or period[-1] not in {"h", "d"} or not period[:-1].isdigit():
        raise HTTPException(
            status_code=422,
            detail="Invalid period. Supported formats: '<N>h' or '<N>d' (e.g. '24h', '7d').",
        )
    value = int(period[:-1])
    now = datetime.datetime.now(datetime.UTC)
    if period.endswith("h"):
        delta = datetime.timedelta(hours=value)
    else:
        delta = datetime.timedelta(days=value)
    return (now - delta).isoformat()


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


@router.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "version": "0.1.0"}


# ---------------------------------------------------------------------------
# Project management
# ---------------------------------------------------------------------------


@router.post("/projects/register", status_code=201)
async def register_project(
    body: RegisterRequest, request: Request
) -> dict[str, str]:
    config_path = Path(body.config_path).resolve()
    # Require the config file to be named config.yaml inside a directory
    # whose immediate parent is ``.agents``.  Tightening "any ancestor named
    # .agents" → "immediate parent must be .agents" is what makes the
    # ``config_path.parent.parent`` derivation in _validate_knowledge_paths
    # actually correspond to the project root.  Without this, a path like
    # ``/foo/.agents/sub/config.yaml`` would pass the original
    # ``".agents" in parts`` check but its derived root would be
    # ``/foo/.agents`` rather than ``/foo``.
    if config_path.name != "config.yaml" or config_path.parent.name != ".agents":
        raise HTTPException(
            status_code=400,
            detail="config_path must point to a .agents/config.yaml file",
        )
    try:
        config = load_config(config_path)
    except Exception as exc:
        _log.warning(
            "register_config_load_failed",
            extra={"path": str(config_path), "error": str(exc)},
        )
        raise HTTPException(
            status_code=400,
            detail=f"Failed to load project config: {exc}",
        ) from exc

    # Reject configs whose knowledge paths escape repo_root (issue #13).
    # The trust anchor is the derived repo root — config_path.parent.parent —
    # not the untrusted ``config.repo_root`` field.
    _validate_knowledge_paths(config, config_path)

    # Guard non-CLI clients (CI scripts, custom SDKs, direct curl) from the
    # same template-placeholder footgun the CLI's `sagex register` guards
    # against: registering under the literal `name: my-project` from the
    # scaffolded config produces a ghost project disconnected from the
    # user's real repo identifier.  `force=true` in the body opts out.
    if config.name == TEMPLATE_PLACEHOLDER_NAME and not body.force:
        raise HTTPException(
            status_code=400,
            detail=(
                "Project name is still the template default "
                f"('{TEMPLATE_PLACEHOLDER_NAME}'). Edit the 'name:' field "
                "in .agents/config.yaml to a real project name before "
                "registering, or pass force=true in the request body."
            ),
        )

    request.app.state.registry.register(config)
    return {"name": config.name, "status": "registered"}


@router.delete("/projects/{name}", status_code=200)
async def deregister_project(name: str, request: Request) -> dict[str, str]:
    registry = request.app.state.registry
    if registry.get(name) is None:
        raise HTTPException(status_code=404, detail=f"Project '{name}' not found")
    registry.deregister(name)
    return {"name": name, "status": "deregistered"}


@router.get("/projects")
async def list_projects(request: Request) -> dict[str, list[str]]:
    projects = request.app.state.registry.list_all()
    return {"projects": [p.name for p in projects]}


# ---------------------------------------------------------------------------
# Event notification
# ---------------------------------------------------------------------------


@router.post("/notify", status_code=202)
async def notify(body: NotifyRequest, request: Request) -> dict[str, str]:
    bus = request.app.state.bus
    # Hook-name → enum first; fall back to the enum's own constructor for
    # callers that already speak the wire format; final fallback to
    # FILE_MODIFIED so a never-seen event_type doesn't 4xx the hook.
    event_type = _HOOK_EVENT_TO_TYPE.get(body.event_type)
    if event_type is None:
        try:
            event_type = EventType(body.event_type)
        except ValueError:
            event_type = EventType.FILE_MODIFIED

    event = AgentEvent(
        type=event_type,
        project_name=body.project_name,
        repo_root=body.repo_root,
        file_paths=body.file_paths,
        diff=body.diff,
        diff_context=body.diff_context,
        extra=body.extra,
    )
    await bus.publish(event)
    return {"status": "queued", "event_id": event.id}


# ---------------------------------------------------------------------------
# Queue status
# ---------------------------------------------------------------------------


@router.get("/queue/status")
async def queue_status(request: Request) -> dict[str, int]:
    bus = request.app.state.bus
    return {"depth": bus._queue.qsize()}


# ---------------------------------------------------------------------------
# Rules
# ---------------------------------------------------------------------------


@router.get("/projects/{name}/rules")
async def list_rules(
    name: str,
    request: Request,
    tag: str | None = None,
    status: str | None = None,
) -> dict[str, Any]:
    db = await _get_db(request, name)
    rules = db.get_rules_for_project(name, min_confidence=0.0)
    if status is not None:
        rules = [r for r in rules if r.status == status]
    if tag is not None:
        rules = [r for r in rules if tag in r.tags]
    return {
        "rules": [
            {
                "id": r.id,
                "trigger_pattern": r.trigger_pattern,
                "lesson": r.lesson,
                "confidence": r.confidence,
                "status": r.status,
                "tags": r.tags,
            }
            for r in rules
        ]
    }


@router.post("/projects/{name}/rules/{rule_id}/feedback")
async def rule_feedback(
    name: str, rule_id: str, body: RuleFeedbackRequest, request: Request
) -> dict[str, str]:
    db = await _get_db(request, name)
    await db.update_confidence(rule_id, body.was_correct)
    return {"rule_id": rule_id, "status": "updated"}


@router.post("/projects/{name}/rules/export")
async def export_rules(
    name: str, body: RulesExportRequest, request: Request
) -> dict[str, Any]:
    registry = request.app.state.registry
    config = registry.get(name)
    if config is None:
        raise HTTPException(status_code=404, detail=f"Project '{name}' not found")
    store = KnowledgeStore(config.knowledge, name)
    exported = store.export_rules(
        min_confidence=body.min_confidence,
        min_applied=body.min_applied,
    )
    return {"rules": exported, "count": len(exported)}


@router.post("/projects/{name}/rules/import")
async def import_rules(
    name: str, body: RulesImportRequest, request: Request
) -> dict[str, Any]:
    registry = request.app.state.registry
    config = registry.get(name)
    if config is None:
        raise HTTPException(status_code=404, detail=f"Project '{name}' not found")
    store = KnowledgeStore(config.knowledge, name)
    count = await store.import_rules(body.rules)
    return {"imported": count}


# ---------------------------------------------------------------------------
# Episodes
# ---------------------------------------------------------------------------


@router.get("/projects/{name}/episodes")
async def list_episodes(
    name: str, request: Request, limit: int = 20
) -> dict[str, Any]:
    db = await _get_db(request, name)
    episodes = db.get_recent_episodes(name, limit=limit)
    return {
        "episodes": [
            {
                "id": e.id,
                "status": e.status,
                "severity": e.severity,
                "test_result_before": e.test_result_before,
                "test_result_after": e.test_result_after,
                "regression_detected": e.regression_detected,
                "lesson_extracted": e.lesson_extracted,
                "created_at": e.created_at,
            }
            for e in episodes
        ]
    }


# ---------------------------------------------------------------------------
# Token usage
# ---------------------------------------------------------------------------


@router.get("/projects/{name}/usage")
async def usage_summary(
    name: str,
    request: Request,
    period: str = "24h",
) -> dict[str, Any]:
    db = await _get_db(request, name)
    since = _period_to_iso(period)
    rows = db.get_token_usage(name, since_iso=since)
    ep_stats = db.get_episode_stats(name, since_iso=since)

    total_input = sum(r.input_tokens for r in rows)
    total_output = sum(r.output_tokens for r in rows)
    total_cost = sum(r.cost_usd for r in rows)
    cache_read = sum(r.cache_read_tokens for r in rows)
    cache_hits = sum(1 for r in rows if r.was_cached)
    input_fresh = sum(r.input_tokens for r in rows if not r.was_cached)
    input_cached = cache_read

    total_events = ep_stats["total"]
    skipped = ep_stats["skipped"]
    skip_pct = round(skipped / total_events * 100, 1) if total_events else 0.0

    # Estimate savings: cache_read tokens cost ~10% of normal input price
    # Rough saving = cache_read_tokens * 0.9 * avg_input_price_per_token
    # Use a conservative $3/1M tokens (sonnet rate) as baseline
    avg_input_rate = 3.0 / 1_000_000
    cache_savings = round(cache_read * avg_input_rate * 0.9, 6)

    by_agent: dict[str, dict[str, int]] = {}
    for r in rows:
        agent = r.agent_type or "unknown"
        if agent not in by_agent:
            by_agent[agent] = {"calls": 0, "tokens": 0}
        by_agent[agent]["calls"] += 1
        by_agent[agent]["tokens"] += r.input_tokens + r.output_tokens

    return {
        "period": period,
        "total_events": total_events,
        "skipped_by_triage": skipped,
        "skip_pct": skip_pct,
        "cache_hits": cache_hits,
        "api_calls": sum(1 for r in rows if not r.was_cached),
        "input_tokens_fresh": input_fresh,
        "input_tokens_cached": input_cached,
        "output_tokens": total_output,
        "cache_savings_usd": cache_savings,
        "estimated_cost_usd": round(total_cost, 6),
        # legacy aliases kept for existing test_api.py assertions
        "total_input_tokens": total_input,
        "total_output_tokens": total_output,
        "total_cost_usd": round(total_cost, 6),
        "call_count": len(rows),
        "by_agent": by_agent,
    }


@router.get("/projects/{name}/usage/history")
async def usage_history(
    name: str,
    request: Request,
    period: str = "24h",
) -> dict[str, Any]:
    db = await _get_db(request, name)
    since = _period_to_iso(period)
    rows = db.get_token_usage(name, since_iso=since)
    history = [
        {
            "id": r.id,
            "agent_type": r.agent_type,
            "input_tokens": r.input_tokens,
            "output_tokens": r.output_tokens,
            "model": r.model,
            "cost_usd": r.cost_usd,
            "timestamp": r.ts,
        }
        for r in rows
    ]
    return {"period": period, "history": history}


# ---------------------------------------------------------------------------
# Approvals
# ---------------------------------------------------------------------------


@router.get("/projects/{name}/approvals")
async def list_approvals(name: str, request: Request) -> dict[str, Any]:
    db = await _get_db(request, name)
    approvals = db.get_pending_approvals(name)
    return {
        "approvals": [
            {
                "id": a.id,
                "episode_id": a.episode_id,
                "plan_json": a.plan_json,
                "status": a.status,
                "created_at": a.created_at,
            }
            for a in approvals
        ]
    }


async def _resolve_or_http(
    db: RulesDB, approval_id: str, status: str, project_name: str
) -> None:
    """Call ``db.resolve_approval`` and translate errors to HTTP responses.

    * ``KeyError`` (not found *or* wrong project) → 404 with a fixed
      ``\"approval not found\"`` body.  Returning the raw ``str(exc)``
      would (a) include the surrounding quotes ``str(KeyError(\"x\"))``
      adds and (b) leak which case fired — exists-but-other-project
      vs truly missing — which is a side channel a caller can probe.
    * ``ValueError`` (already resolved) → 409 Conflict.  Safe to surface
      the message verbatim because the row's existence is implicit in
      the 200 the caller would have gotten on first resolve.
    """
    try:
        await db.resolve_approval(approval_id, status, project_name=project_name)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="approval not found") from exc
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post("/projects/{name}/approvals/{approval_id}/approve")
async def approve(
    name: str, approval_id: str, request: Request
) -> dict[str, str]:
    db = await _get_db(request, name)
    await _resolve_or_http(db, approval_id, "approved", name)
    # Wake any runner task waiting on this approval (issue #10).
    waiters = getattr(request.app.state, "approval_waiters", None)
    if waiters is not None:
        waiters.notify(approval_id)
    return {"approval_id": approval_id, "status": "approved"}


@router.post("/projects/{name}/approvals/{approval_id}/reject")
async def reject(
    name: str, approval_id: str, request: Request
) -> dict[str, str]:
    db = await _get_db(request, name)
    await _resolve_or_http(db, approval_id, "rejected", name)
    waiters = getattr(request.app.state, "approval_waiters", None)
    if waiters is not None:
        waiters.notify(approval_id)
    return {"approval_id": approval_id, "status": "rejected"}
