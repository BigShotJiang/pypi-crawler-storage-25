"""Project-wide constants shared across the CLI and API layers.

Kept deliberately tiny — one well-named module is less footgun-prone than
duplicating a string literal in both ``cli.py`` and ``api/routes.py`` and
relying on code review to keep them in sync.
"""

from __future__ import annotations

# Literal value that ``sagex init`` writes into the scaffolded
# ``.agents/config.yaml``.  ``sagex register`` (CLI) and ``POST
# /projects/register`` (API) both refuse to register a config whose
# ``name:`` field is still this placeholder, unless ``--force`` /
# ``force=true`` is supplied.  See the matching guards in
# ``sagex/cli.py::register`` and ``sagex/api/routes.py::register_project``.
TEMPLATE_PLACEHOLDER_NAME = "my-project"
