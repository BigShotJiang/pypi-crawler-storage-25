"""BudgetManager — the single entry point for every LLM call in sagex.

Every LLM call in sagex flows through this module.  The wire-level request
is delegated to a ``Provider`` (see ``sagex.llm.providers``).  Budget
enforcement, content-hash deduplication, retry, and token tracking are
provider-agnostic and live here.

Call pipeline
-------------
call(project, agent_type, system, user, model, max_tokens)
  ├─ check_budget()              ← sync read; raises BudgetExceededError
  ├─ ContentCache.get()          ← sync read; instant cache hit
  ├─ _call_with_retry()          ← Provider.call() with backoff
  ├─ TokenTracker.record()       ← async write to token_usage table
  └─ ContentCache.set()          ← async write to content_cache table
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
import re
from datetime import UTC, datetime, timedelta
from typing import Any

from sagex.config import BudgetConfig
from sagex.llm.cache import ContentCache
from sagex.llm.providers.base import CallResult, Provider
from sagex.llm.token_tracker import TokenTracker

_log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class BudgetExceededError(Exception):
    """Raised when the token budget for the current period is exhausted."""


class AgentOutputError(Exception):
    """Raised when an agent returns malformed JSON after one retry."""


# ---------------------------------------------------------------------------
# Zero-usage sentinel (used when returning a cached response)
# ---------------------------------------------------------------------------

class _ZeroUsage:
    """Fake anthropic Usage object for cache-hit records (no tokens consumed)."""

    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_input_tokens: int = 0
    cache_creation_input_tokens: int = 0


# ---------------------------------------------------------------------------
# BudgetManager
# ---------------------------------------------------------------------------

class BudgetManager:
    """Budget + cache + tracking facade over any ``Provider``.

    The provider handles the wire-level call (HTTPS to Anthropic, subprocess
    to ``claude``, HTTP to Ollama, etc.).  This class is provider-agnostic.

    Parameters
    ----------
    config:
        Budget limits and caching knobs.
    tracker:
        Pre-constructed ``TokenTracker`` instance.
    content_cache:
        Pre-constructed ``ContentCache`` instance.
    provider:
        The LLM provider to delegate calls to.  See ``sagex.llm.providers``.
    client:
        Legacy kwarg — back-compat shim for tests that previously injected
        a ``StubAnthropicClient`` directly.  When provided *and* no
        ``provider`` is given, a stub ``AnthropicAPIProvider`` is built
        wrapping it.  New code should pass ``provider=`` instead.
    api_key:
        Legacy kwarg — if ``provider`` and ``client`` are both ``None``,
        a default ``AnthropicAPIProvider`` is constructed with this key.
    """

    def __init__(
        self,
        config: BudgetConfig,
        tracker: TokenTracker,
        content_cache: ContentCache,
        provider: Provider | None = None,
        client: Any = None,
        api_key: str | None = None,
    ) -> None:
        self._config = config
        self._tracker = tracker
        self._cache = content_cache
        if provider is not None:
            self._provider: Provider = provider
        else:
            # Back-compat construction path
            from sagex.llm.providers.anthropic_api import AnthropicAPIProvider
            self._provider = AnthropicAPIProvider(
                api_key=api_key,
                enable_prompt_caching=config.enable_prompt_caching,
                client=client,
            )

    @property
    def _client(self) -> Any:
        """Back-compat accessor for tests that inspect the underlying stub.

        Returns the ``_client`` of the provider when the provider exposes it
        (``AnthropicAPIProvider`` does); otherwise returns ``None``.
        """
        return getattr(self._provider, "_client", None)

    async def aclose(self) -> None:
        """Release provider-held resources (httpx pools, subprocess handles).

        Safe to call on any provider — if the provider doesn't implement
        ``aclose``, this is a no-op.  ``runner._handle_event`` calls this
        in ``finally`` to avoid per-event resource leaks on long-running
        ``sagex serve`` processes.
        """
        close_fn = getattr(self._provider, "aclose", None)
        if close_fn is None:
            return
        try:
            await close_fn()
        except Exception as exc:  # noqa: BLE001
            # Shutdown best-effort — never let a close failure crash the event.
            _log.warning("provider_aclose_failed", extra={
                "extra": {"provider": self._provider.name, "error": str(exc)}
            })

    # ------------------------------------------------------------------ Budget

    @staticmethod
    def _since_hours(hours: int) -> str:
        return (datetime.now(UTC) - timedelta(hours=hours)).isoformat()

    def _cap_framing(self) -> str:
        """Return human-readable framing for the cap based on provider.

        Subscription / free providers don't generate a dollar bill, so the
        cap is framed as a rate-limit / volume guard (the cap's real purpose
        for those users).  API providers see the standard cost framing.
        (Locked spec decision #6.)
        """
        subscription_providers = {"claude_code", "ollama"}
        if self._provider.name in subscription_providers:
            return "rate-limit / volume cap"
        return "cost cap"

    def check_budget(self, project: str) -> None:
        """Raise ``BudgetExceededError`` when hourly or daily token limits are breached.

        The limit is always enforced regardless of provider (locked decision #6)
        as a blast-radius guard against runaway loops.  Only the error framing
        differs for subscription / free providers.

        Sync — reads token_usage via WAL reader; no write lock needed.
        """
        framing = self._cap_framing()
        hourly = self._tracker.get_summary(project, self._since_hours(1))
        hourly_total = hourly["input_tokens"] + hourly["output_tokens"]
        if hourly_total >= self._config.hourly_token_limit:
            raise BudgetExceededError(
                f"Hourly token {framing} hit: {hourly_total} >= "
                f"{self._config.hourly_token_limit}"
            )

        daily = self._tracker.get_summary(project, self._since_hours(24))
        daily_total = daily["input_tokens"] + daily["output_tokens"]
        if daily_total >= self._config.daily_token_limit:
            raise BudgetExceededError(
                f"Daily token {framing} hit: {daily_total} >= "
                f"{self._config.daily_token_limit}"
            )

        # Alert when approaching the daily limit
        daily_pct = daily_total / self._config.daily_token_limit
        if daily_pct >= self._config.alert_threshold:
            _log.warning(
                "budget_alert",
                extra={
                    "extra": {
                        "project": project,
                        "daily_pct": round(daily_pct * 100),
                        "daily_total": daily_total,
                        "daily_limit": self._config.daily_token_limit,
                    }
                },
            )

    # ------------------------------------------------------------------ Retry

    async def _call_with_retry(
        self,
        system: str,
        user: str,
        model: str,
        max_tokens: int,
        temperature: float,
        max_attempts: int = 3,
    ) -> CallResult:
        """Provider call with exponential-backoff retry on transient errors.

        Uses ``asyncio.sleep`` — never ``time.sleep``.  The provider decides
        which exceptions are retryable via ``provider.is_retryable_error``;
        this keeps BudgetManager SDK-agnostic so new providers can plug in
        without edits here.
        """
        for attempt in range(max_attempts):
            try:
                return await self._provider.call(
                    system=system,
                    user=user,
                    model=model,
                    max_tokens=max_tokens,
                    temperature=temperature,
                )
            except Exception as exc:
                if attempt == max_attempts - 1:
                    raise
                if not self._provider.is_retryable_error(exc):
                    raise
                # Equal-jitter exponential backoff:
                #   sleep = base/2 + U(0, base/2)
                # with base = 2**attempt.  Mean delay is 3*base/4 — about
                # 25% lower than the pre-jitter fixed `base`, which is an
                # acceptable trade for spreading the wake-up distribution
                # across a window so N concurrent retries don't re-hit
                # the provider in lockstep (thundering herd).  Full-jitter
                # (U(0, base)) would halve the mean, which can retry too
                # aggressively on slow transients; equal-jitter is the
                # AWS-recommended middle.
                base = 2.0**attempt
                await asyncio.sleep(base / 2 + random.uniform(0.0, base / 2))
        raise RuntimeError("unreachable")  # pragma: no cover

    # ------------------------------------------------------------------ Public API

    async def call(
        self,
        project: str,
        agent_type: str,
        system: str,
        user: str,
        model: str,
        max_tokens: int,
        temperature: float = 0.2,
    ) -> str:
        """Make one LLM call, enforcing budget, caching, and token tracking.

        Returns the raw text of the model's response.
        """
        self.check_budget(project)

        # Content-hash deduplication — instant cache hit
        cached = self._cache.get(system, user, model)
        if cached is not None:
            await self._tracker.record(
                project,
                agent_type,
                model,
                _ZeroUsage(),
                call_hash=self._cache._hash(system, user, model),
                was_cached=True,
                provider_name=self._provider.name,
            )
            return cached

        result = await self._call_with_retry(
            system=system,
            user=user,
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
        )

        await self._tracker.record(
            project,
            agent_type,
            model,
            result,
            call_hash=self._cache._hash(system, user, model),
            was_cached=False,
            provider_name=self._provider.name,
        )
        await self._cache.set(system, user, result.text, model)
        return result.text

    @staticmethod
    def _strip_fences(text: str) -> str:
        """Strip markdown code fences that models sometimes wrap JSON in.

        Handles: ```json\\n{...}\\n``` and ``` ... ```
        """
        stripped = text.strip()
        stripped = re.sub(r"^```(?:json)?\s*\n?", "", stripped)
        stripped = re.sub(r"\n?```\s*$", "", stripped)
        return stripped.strip()

    async def call_json(
        self,
        project: str,
        agent_type: str,
        system: str,
        user: str,
        model: str,
        max_tokens: int,
        temperature: float = 0.2,
    ) -> dict[str, object]:
        """Like ``call()``, but parse the response as JSON.

        Strips markdown code fences before parsing (models occasionally wrap
        JSON in ```json ... ``` despite being told not to).
        On malformed JSON: retry once with a correction prompt.
        If still invalid: raise ``AgentOutputError``.
        """
        text = self._strip_fences(await self.call(
            project=project,
            agent_type=agent_type,
            system=system,
            user=user,
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
        ))
        try:
            result: dict[str, object] = json.loads(text)
            return result
        except json.JSONDecodeError:
            correction = (
                user
                + "\n\nYour previous response was not valid JSON. "
                "Return ONLY the JSON object, no prose, no markdown fences."
            )
            text2 = self._strip_fences(await self.call(
                project=project,
                agent_type=agent_type,
                system=system,
                user=correction,
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
            ))
            try:
                result2: dict[str, object] = json.loads(text2)
                return result2
            except json.JSONDecodeError as exc:
                raise AgentOutputError(
                    f"Agent returned malformed JSON after retry: {text2[:200]}"
                ) from exc
