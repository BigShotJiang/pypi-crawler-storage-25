"""Token usage tracking: records LLM call costs to the SQLite store.

TokenUsageRecord is the concrete type that RulesDB.write_token_usage and
get_token_usage operate on.  It is intentionally kept dependency-free so
that rules_db.py can lazy-import it without a circular-import risk.
"""

from __future__ import annotations

import logging
import uuid
from collections import OrderedDict
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

_log = logging.getLogger(__name__)

# Models we've already warned about under this process — prevents the
# pricing-unknown warning from flooding logs when a mis-configured model
# logs thousands of calls per session.
#
# Bounded growth: backed by an ``OrderedDict`` (used as an ordered-set —
# values are ignored) capped at ``_WARNED_UNKNOWN_MODELS_CAP`` so an
# upstream caller passing dynamic/unique model IDs (or a typo storm)
# can't turn the dedupe guard into an unbounded memory leak.  When
# capacity is hit, the least-recently-warned model is evicted; if it
# reappears later we'll re-warn — that's a small repetition cost in
# exchange for a hard memory bound.
_WARNED_UNKNOWN_MODELS_CAP: int = 256
_WARNED_UNKNOWN_MODELS: OrderedDict[str, None] = OrderedDict()


def _record_unknown_model_warned(model: str) -> bool:
    """Mark *model* as warned and return True if it was a *new* warning.

    Returns False when *model* was already warned under this process
    (so the caller suppresses re-logging).  Maintains LRU order under
    the per-process cap.
    """
    if model in _WARNED_UNKNOWN_MODELS:
        # Touch freshness so a stable misconfigured model doesn't get
        # evicted by a burst of one-off unknown names.
        _WARNED_UNKNOWN_MODELS.move_to_end(model)
        return False
    _WARNED_UNKNOWN_MODELS[model] = None
    while len(_WARNED_UNKNOWN_MODELS) > _WARNED_UNKNOWN_MODELS_CAP:
        _WARNED_UNKNOWN_MODELS.popitem(last=False)
    return True

# ---------------------------------------------------------------------------
# Pricing table (per-token costs in USD)
# ---------------------------------------------------------------------------
# MODEL_PRICING_LAST_UPDATED is consumed by ``get_pricing_age_days()``;
# callers (e.g. ``sagex usage``) should warn when the age exceeds the
# staleness threshold.  Refresh both this constant and the rates below in
# lockstep whenever Anthropic or OpenAI changes prices (typically 12-18
# month cycles).

MODEL_PRICING_LAST_UPDATED = "2026-04"  # YYYY-MM
MODEL_PRICING_STALE_AFTER_DAYS = 180

# Providers where tokens don't translate to out-of-pocket spend.  Calls
# routed through these never get a dollar amount in sagex usage regardless
# of model name (Ollama runs arbitrary user-managed models like llama3.1:8b
# which are NOT in MODEL_PRICING; previously we fell back to Sonnet rates,
# producing misleading non-zero USD).
_FREE_PROVIDERS: frozenset[str] = frozenset({"claude_code", "ollama"})

# Fail fast at import time if the constant above is typo'd; silent parse
# failure inside ``pricing_is_stale()`` would be worse.  Use explicit
# raise rather than ``assert`` so the guard survives ``python -O``.
try:
    datetime.strptime(MODEL_PRICING_LAST_UPDATED, "%Y-%m")
except ValueError as _exc:
    raise ValueError(
        f"MODEL_PRICING_LAST_UPDATED={MODEL_PRICING_LAST_UPDATED!r} "
        f"is not YYYY-MM: {_exc}"
    ) from _exc

MODEL_PRICING: dict[str, dict[str, float]] = {
    "claude-opus-4-7": {
        "input": 15.0 / 1_000_000,
        "output": 75.0 / 1_000_000,
        "cache_write": 18.75 / 1_000_000,
        "cache_read": 1.5 / 1_000_000,
    },
    "claude-sonnet-4-6": {
        "input": 3.0 / 1_000_000,
        "output": 15.0 / 1_000_000,
        "cache_write": 3.75 / 1_000_000,
        "cache_read": 0.30 / 1_000_000,
    },
    "claude-haiku-4-5": {
        "input": 0.80 / 1_000_000,
        "output": 4.0 / 1_000_000,
        "cache_write": 1.0 / 1_000_000,
        "cache_read": 0.08 / 1_000_000,
    },
    # OpenAI rates (verified 2026-04; see docs/PROVIDERS.md for refresh cadence)
    "gpt-5": {
        "input": 5.0 / 1_000_000,
        "output": 15.0 / 1_000_000,
        "cache_write": 0.0,   # OpenAI caches automatically; no separate write rate
        "cache_read": 0.5 / 1_000_000,
    },
    "gpt-4o": {
        "input": 2.5 / 1_000_000,
        "output": 10.0 / 1_000_000,
        "cache_write": 0.0,
        "cache_read": 1.25 / 1_000_000,
    },
    "gpt-4o-mini": {
        "input": 0.15 / 1_000_000,
        "output": 0.60 / 1_000_000,
        "cache_write": 0.0,
        "cache_read": 0.075 / 1_000_000,
    },
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def get_pricing_age_days() -> int:
    """Days since ``MODEL_PRICING`` was last refreshed.

    Callers (``sagex usage``) should warn users when this exceeds
    ``MODEL_PRICING_STALE_AFTER_DAYS`` — cost figures may be wrong.
    """
    last_refresh = datetime.strptime(MODEL_PRICING_LAST_UPDATED, "%Y-%m").replace(
        tzinfo=UTC
    )
    return (datetime.now(UTC) - last_refresh).days


def pricing_is_stale() -> bool:
    return get_pricing_age_days() > MODEL_PRICING_STALE_AFTER_DAYS


def _short_uuid() -> str:
    return uuid.uuid4().hex[:8]


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class TokenUsageRecord:
    id: str
    ts: str
    project: str
    agent_type: str
    model: str
    input_tokens: int
    output_tokens: int
    cache_read_tokens: int
    cache_write_tokens: int
    cost_usd: float
    call_hash: str | None
    was_cached: bool


# ---------------------------------------------------------------------------
# Tracker
# ---------------------------------------------------------------------------

class TokenTracker:
    """Async recorder + sync summary reader for token usage."""

    def __init__(self, db: Any) -> None:  # db: RulesDB — Any avoids circular import
        self._db = db

    async def record(
        self,
        project: str,
        agent_type: str,
        model: str,
        usage: Any,                  # anthropic Usage object or zero-usage sentinel
        call_hash: str | None = None,
        was_cached: bool = False,
        provider_name: str | None = None,
    ) -> TokenUsageRecord:
        """Build a TokenUsageRecord from an Anthropic usage object and persist it.

        Async — calls ``self._db.write_token_usage()`` which acquires the
        ``RulesDB`` write lock. Always ``await`` this method.

        ``provider_name`` is used to zero out ``cost_usd`` for subscription /
        free-local providers (``claude_code``, ``ollama``) per spec decision
        #1.  When omitted, the legacy per-model pricing table is applied.
        """
        input_tokens: int = getattr(usage, "input_tokens", 0) or 0
        output_tokens: int = getattr(usage, "output_tokens", 0) or 0
        # Accept both the Anthropic SDK names (cache_{read,creation}_input_tokens)
        # and the sagex CallResult names (cache_{read,write}_tokens) so this
        # layer stays provider-agnostic.
        cache_read: int = (
            getattr(usage, "cache_read_input_tokens", 0)
            or getattr(usage, "cache_read_tokens", 0)
            or 0
        )
        cache_write: int = (
            getattr(usage, "cache_creation_input_tokens", 0)
            or getattr(usage, "cache_write_tokens", 0)
            or 0
        )
        if provider_name in _FREE_PROVIDERS:
            # Subscription or local — tokens counted for observability, cost $0.
            cost = 0.0
        else:
            cost = self.compute_cost(
                model, input_tokens, output_tokens, cache_read, cache_write
            )

        rec = TokenUsageRecord(
            id=f"tok_{_short_uuid()}",
            ts=_now_iso(),
            project=project,
            agent_type=agent_type,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_tokens=cache_read,
            cache_write_tokens=cache_write,
            cost_usd=cost,
            call_hash=call_hash,
            was_cached=was_cached,
        )
        await self._db.write_token_usage(rec)
        return rec

    def get_summary(self, project: str, since_iso: str) -> dict[str, int | float]:
        """Return aggregated statistics for *project* since *since_iso* (sync read).

        Pushes SUM/COUNT into SQLite via ``RulesDB.get_token_usage_summary``
        so memory stays O(1) and latency stays O(rows in range) instead of
        O(rows in range) * Python allocation per row.
        """
        summary: dict[str, int | float] = self._db.get_token_usage_summary(
            project, since_iso
        )
        return summary

    @staticmethod
    def compute_cost(
        model: str,
        input_tokens: int,
        output_tokens: int,
        cache_read_tokens: int = 0,
        cache_write_tokens: int = 0,
    ) -> float:
        """Compute USD cost from token counts using the MODEL_PRICING table.

        Returns 0.0 and logs a one-time WARN for any model not in
        ``MODEL_PRICING``.  The old behaviour (silently falling back to
        Sonnet pricing) produced misleading dollar figures for users
        running unknown OpenAI / Anthropic models — e.g. ``gpt-4-turbo``
        would be billed at the real GPT-4-turbo rate but shown in
        ``sagex usage`` at Sonnet rates (issue #14).  Zero is the
        honest value when we can't compute the real one; the WARN tells
        the user exactly which model to add to the table.
        """
        pricing = MODEL_PRICING.get(model)
        if pricing is None:
            if _record_unknown_model_warned(model):
                _log.warning(
                    "pricing_unknown_model",
                    extra={
                        "extra": {
                            "model": model,
                            "action": (
                                "cost reported as $0.00 — add this model to "
                                "MODEL_PRICING in token_tracker.py or pin your "
                                "config to a known model to get real costs"
                            ),
                        }
                    },
                )
            return 0.0
        return (
            input_tokens * pricing["input"]
            + output_tokens * pricing["output"]
            + cache_read_tokens * pricing["cache_read"]
            + cache_write_tokens * pricing["cache_write"]
        )
