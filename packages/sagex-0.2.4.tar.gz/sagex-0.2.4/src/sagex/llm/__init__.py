"""LLM budget, caching, and token-tracking layer."""
