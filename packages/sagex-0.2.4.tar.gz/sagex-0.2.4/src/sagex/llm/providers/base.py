"""Provider Protocol and shared types.

Every provider implementation must satisfy the ``Provider`` Protocol below
and return a ``CallResult`` from ``call()``.  ``BudgetManager`` treats the
provider as a black box: it handles budget enforcement, content-hash
deduplication, retry, and token tracking around every provider call.

Exceptions
----------
``ProviderUnavailableError``
    Raised at construction when the provider's upstream is not reachable
    (e.g. ``claude`` binary not on PATH, Ollama server not running).  The
    user is expected to fix this before retrying.

``ProviderAuthError``
    Raised at construction or first call when authentication is missing or
    invalid (e.g. ``claude login`` expired, ``OPENAI_API_KEY`` unset).

``ProviderCallError``
    Raised during a single call when the upstream returned an error that
    isn't authentication-related and isn't a budget/rate-limit case.  The
    ``BudgetManager`` retry loop catches this once before re-raising.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable


@dataclass
class CallResult:
    """Return value of ``Provider.call``.

    Providers MUST populate ``text``, ``input_tokens``, ``output_tokens``,
    and ``model``.  ``cache_read_tokens`` / ``cache_write_tokens`` stay at
    their defaults for providers that don't support prompt caching.
    """

    text: str
    input_tokens: int
    output_tokens: int
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    model: str = ""


@runtime_checkable
class Provider(Protocol):
    """One LLM-call implementation.  All providers are fully async."""

    @property
    def name(self) -> str:
        """Short stable identifier for logs and config lookups.

        Must be one of: ``"anthropic_api"``, ``"claude_code"``,
        ``"openai_api"``, ``"ollama"``.
        """
        ...

    def supports_model(self, model: str) -> bool:
        """Return True when *model* is known to work with this provider.

        Used by the factory for config-load-time validation.  Providers
        that can't enumerate supported models (Ollama) return True always.
        """
        ...

    def is_retryable_error(self, exc: BaseException) -> bool:
        """Return True when ``exc`` from ``call()`` should trigger a retry.

        Canonical retryable cases: rate-limiting, 5xx server errors,
        transient network failures.  Auth errors and 4xx (except 429) are
        NOT retryable.  Each provider knows its own SDK's exception
        hierarchy; the ``BudgetManager`` retry loop trusts this verdict.
        """
        ...

    async def call(
        self,
        system: str,
        user: str,
        model: str,
        max_tokens: int,
        temperature: float,
    ) -> CallResult:
        """Make one LLM call.

        Parameters
        ----------
        system, user:
            The prompts.
        model:
            Provider-specific model identifier (e.g. ``"claude-sonnet-4-6"``,
            ``"gpt-5"``, ``"llama3.1:8b"``).
        max_tokens:
            Maximum output tokens.  Some providers may ignore this (the
            Claude Code CLI, for example, enforces its own ceiling);
            such providers MUST log a one-time WARNING and honour their
            own default.
        temperature:
            Sampling temperature in ``[0.0, 1.0]``.  Providers that can't
            honour this follow the same one-time-WARNING rule.
        """
        ...


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class ProviderUnavailableError(Exception):
    """The provider's upstream is not reachable (binary/server/API).

    Raised at construction so the user sees a clear error before any call
    is attempted.  The message should include the fix (e.g. "Install
    Claude Code and run `claude login`").
    """


class ProviderAuthError(Exception):
    """Authentication is missing or invalid.

    Raised at construction (for API-key providers that can eager-check) or
    on the first call (for providers where auth is verified lazily by the
    upstream).
    """


class ProviderCallError(Exception):
    """Non-auth, non-budget upstream error during one call.

    ``BudgetManager._call_with_retry`` catches this once before surfacing
    to the agent layer.
    """
