"""AnthropicAPIProvider — HTTPS calls to api.anthropic.com via the official SDK.

Behaviorally identical to the pre-v0.2.0 code path in ``BudgetManager``.
Prompt caching via ``cache_control`` is preserved through ``build_cached_request``.
"""

from __future__ import annotations

import os
from typing import Any

import anthropic

from sagex.llm.cache import build_cached_request
from sagex.llm.providers.base import (
    CallResult,
    Provider,
    ProviderCallError,  # used by is_retryable_error
)

_KNOWN_MODELS: frozenset[str] = frozenset({
    "claude-haiku-4-5",
    "claude-sonnet-4-6",
    "claude-opus-4-7",
})


class AnthropicAPIProvider(Provider):
    """Thin wrapper around ``anthropic.AsyncAnthropic``.

    Parameters
    ----------
    api_key:
        Anthropic API key.  Falls back to ``ANTHROPIC_API_KEY`` env var when
        not supplied.
    enable_prompt_caching:
        Threshold-guarded ``cache_control`` application (matches the
        pre-v0.2.0 behaviour).  Off only to opt out for diagnostics.
    client:
        Optional override — inject a ``StubAnthropicClient`` in tests so the
        real API is never called.
    """

    def __init__(
        self,
        api_key: str | None = None,
        enable_prompt_caching: bool = True,
        client: Any = None,
    ) -> None:
        if client is not None:
            self._client: Any = client
        else:
            self._client = anthropic.AsyncAnthropic(
                api_key=api_key or os.environ.get("ANTHROPIC_API_KEY", "")
            )
        self._enable_prompt_caching = enable_prompt_caching

    @property
    def name(self) -> str:
        return "anthropic_api"

    def supports_model(self, model: str) -> bool:
        return model in _KNOWN_MODELS

    async def aclose(self) -> None:
        """Release the underlying ``httpx.AsyncClient`` owned by the SDK.

        Providers are cached across events (see ``runner._PROVIDER_CACHE``)
        so this is NOT called per-event; ``Runner.aclose()`` iterates the
        cache at server shutdown and awaits each provider's aclose()
        directly (it doesn't go through ``BudgetManager``).
        """
        close_fn = getattr(self._client, "close", None) or getattr(
            self._client, "aclose", None
        )
        if close_fn is None:
            return
        result = close_fn()
        if hasattr(result, "__await__"):
            await result

    def is_retryable_error(self, exc: BaseException) -> bool:
        if isinstance(exc, anthropic.RateLimitError):
            return True
        if isinstance(exc, anthropic.APIStatusError):
            return exc.status_code >= 500
        if isinstance(exc, ProviderCallError):
            return True
        return False

    async def call(
        self,
        system: str,
        user: str,
        model: str,
        max_tokens: int,
        temperature: float,
    ) -> CallResult:
        request = build_cached_request(
            system,
            user,
            model,
            max_tokens,
            enable_prompt_caching=self._enable_prompt_caching,
        )
        request["temperature"] = temperature

        # Let SDK exceptions propagate unchanged; the retry loop consults
        # ``is_retryable_error`` which knows 429 / 5xx are retryable and
        # other 4xx (auth, bad request) are not.
        response = await self._client.messages.create(**request)

        usage = response.usage
        return CallResult(
            text=response.content[0].text,
            input_tokens=usage.input_tokens,
            output_tokens=usage.output_tokens,
            cache_read_tokens=getattr(usage, "cache_read_input_tokens", 0) or 0,
            cache_write_tokens=getattr(usage, "cache_creation_input_tokens", 0) or 0,
            model=getattr(response, "model", model),
        )
