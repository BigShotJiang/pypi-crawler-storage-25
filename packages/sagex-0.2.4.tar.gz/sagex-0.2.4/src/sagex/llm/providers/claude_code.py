"""ClaudeCodePassthroughProvider — spawns the user's local ``claude`` CLI.

Consumes the user's Claude Pro/Max subscription quota via Claude Code
(Anthropic's own CLI) instead of billing an API key.  The user prompt is
passed via stdin — never argv — so multi-user hosts don't leak prompt
contents through ``/proc/<pid>/cmdline`` (locked spec decision #10).
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
import subprocess
from typing import Any

from sagex.llm.providers.base import (
    CallResult,
    Provider,
    ProviderAuthError,
    ProviderCallError,
    ProviderUnavailableError,
)

_log = logging.getLogger(__name__)

_KNOWN_MODELS: frozenset[str] = frozenset({
    "claude-haiku-4-5",
    "claude-sonnet-4-6",
    "claude-opus-4-7",
})

# Subprocess safety: cap each `claude -p` call to 120 seconds. A hung CLI
# would otherwise block the event loop forever.  Claude Code typically
# returns in 5-30s; 120s is a generous ceiling for slow networks.
_CALL_TIMEOUT_SECONDS = 120.0

# Pre-flight version check: short ceiling because the binary responds
# instantly or it's broken.
_VERSION_CHECK_TIMEOUT_SECONDS = 3.0


class ClaudeCodePassthroughProvider(Provider):
    """Delegates each LLM call to a subprocess of the local ``claude`` CLI.

    Pre-flight checks run once at construction:
    1. ``claude`` binary on PATH (``shutil.which``)
    2. ``claude --version`` returns 0

    Each call spawns ``claude -p - --append-system-prompt <system>
    --output-format json --model <model>`` and pipes the user prompt to
    stdin.  Output is parsed as JSON to extract ``content`` and ``usage``.

    ``max_tokens`` and ``temperature`` are not exposed by the CLI.  The
    provider logs a one-time WARNING per session when they're set, so
    users aren't surprised that the knobs have no visible effect.
    """

    def __init__(self, binary: str = "claude") -> None:
        path = shutil.which(binary)
        if path is None:
            raise ProviderUnavailableError(
                f"{binary!r} binary not found on PATH. "
                "Install Claude Code from https://claude.com/code and run "
                "`claude login`, then retry."
            )
        self._binary = path

        try:
            res = subprocess.run(
                [self._binary, "--version"],
                capture_output=True,
                text=True,
                timeout=_VERSION_CHECK_TIMEOUT_SECONDS,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise ProviderUnavailableError(
                f"`{self._binary} --version` failed: {exc}"
            ) from exc
        if res.returncode != 0:
            raise ProviderUnavailableError(
                f"`{self._binary} --version` exited {res.returncode}: "
                f"{res.stderr[:500]}"
            )
        self._version = (res.stdout or res.stderr).strip().splitlines()[0]
        self._warned_max_tokens = False
        self._warned_temperature = False

    @property
    def name(self) -> str:
        return "claude_code"

    def supports_model(self, model: str) -> bool:
        return model in _KNOWN_MODELS

    def is_retryable_error(self, exc: BaseException) -> bool:
        # Auth errors are terminal — re-running won't fix ``claude login``.
        # ProviderCallError (subprocess exit nonzero, timeout, non-JSON) is
        # retried once to cover transient hiccups.
        if isinstance(exc, ProviderAuthError):
            return False
        if isinstance(exc, ProviderCallError):
            return True
        return False

    async def call(
        self,
        system: str,
        user: str,
        model: str,
        max_tokens: int,
        temperature: float,
    ) -> CallResult:
        if max_tokens and not self._warned_max_tokens:
            _log.warning(
                "claude_code_provider ignores max_tokens=%s — the claude CLI "
                "uses its own default output ceiling; this warning is logged "
                "once per session.",
                max_tokens,
            )
            self._warned_max_tokens = True
        if temperature != 0.2 and not self._warned_temperature:
            _log.warning(
                "claude_code_provider ignores temperature=%s — the claude CLI "
                "uses its own default; logged once per session.",
                temperature,
            )
            self._warned_temperature = True

        proc = await asyncio.create_subprocess_exec(
            self._binary,
            "-p", "-",  # "-" = read user prompt from stdin
            # system prompt via flag (smaller + lower sensitivity than the diff)
            "--append-system-prompt", system,
            "--output-format", "json",
            "--model", model,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout_b, stderr_b = await asyncio.wait_for(
                proc.communicate(input=user.encode("utf-8")),
                timeout=_CALL_TIMEOUT_SECONDS,
            )
        except TimeoutError as exc:
            # Kill the hung subprocess so we don't leak it; then surface.
            proc.kill()
            try:
                await proc.wait()
            except Exception:  # noqa: BLE001
                pass
            raise ProviderCallError(
                f"`claude -p` did not return within "
                f"{_CALL_TIMEOUT_SECONDS}s; subprocess killed."
            ) from exc

        if proc.returncode != 0:
            err = stderr_b.decode("utf-8", errors="replace")
            # Map common failure modes
            if "login" in err.lower() or "not authenticated" in err.lower():
                raise ProviderAuthError(
                    f"claude CLI not authenticated: {err[:500]}. Run `claude login`."
                )
            raise ProviderCallError(
                f"`claude -p` exited {proc.returncode}: {err[:500]}"
            )

        try:
            payload: dict[str, Any] = json.loads(stdout_b.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ProviderCallError(
                f"claude CLI returned non-JSON output: "
                f"{stdout_b[:500].decode('utf-8', errors='replace')}"
            ) from exc

        usage = payload.get("usage") or {}
        text = payload.get("content") or payload.get("result") or ""
        if not isinstance(text, str):
            # Some versions nest content blocks; fall back to JSON stringify
            text = json.dumps(text)

        return CallResult(
            text=text,
            input_tokens=int(usage.get("input_tokens", 0) or 0),
            output_tokens=int(usage.get("output_tokens", 0) or 0),
            cache_read_tokens=int(usage.get("cache_read_input_tokens", 0) or 0),
            cache_write_tokens=int(usage.get("cache_creation_input_tokens", 0) or 0),
            model=str(payload.get("model", model)),
        )
