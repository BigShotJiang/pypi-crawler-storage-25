"""OpenAIProvider — Chat Completions via the official openai SDK.

Requires ``OPENAI_API_KEY`` in the environment.  Billed pay-per-token at
OpenAI's platform rates.  Does NOT tap a ChatGPT subscription — only
Codex CLI has that privilege.  See docs/PROVIDERS.md.
"""

from __future__ import annotations

import os
from typing import Any

import openai

from sagex.llm.providers.base import (
    CallResult,
    Provider,
    ProviderAuthError,
    ProviderCallError,
)

# Kept narrow to the current mainline models; pricing entries in
# ``token_tracker.MODEL_PRICING`` must stay in sync.
_KNOWN_MODELS: frozenset[str] = frozenset({
    "gpt-5",
    "gpt-4o",
    "gpt-4o-mini",
})


class OpenAIProvider(Provider):
    """Thin wrapper around ``openai.AsyncOpenAI``.

    Parameters
    ----------
    api_key:
        OpenAI API key.  Falls back to ``OPENAI_API_KEY`` env var.  Raises
        ``ProviderAuthError`` at construction when neither is available
        (cheap eager check; the SDK would also surface this at first call).
    client:
        Optional stub for tests.  When provided, ``api_key`` is ignored.
    """

    def __init__(self, api_key: str | None = None, client: Any = None) -> None:
        if client is not None:
            self._client: Any = client
        else:
            key = api_key or os.environ.get("OPENAI_API_KEY", "")
            if not key:
                raise ProviderAuthError(
                    "OPENAI_API_KEY is not set. Get a key at "
                    "https://platform.openai.com/api-keys, then set the env var."
                )
            self._client = openai.AsyncOpenAI(api_key=key)

    @property
    def name(self) -> str:
        return "openai_api"

    def supports_model(self, model: str) -> bool:
        return model in _KNOWN_MODELS

    async def aclose(self) -> None:
        """Release the underlying ``httpx.AsyncClient`` owned by the SDK.

        Providers are cached across events (see ``runner._PROVIDER_CACHE``)
        so this is NOT called per-event; ``Runner.aclose()`` iterates the
        cache at server shutdown and awaits each provider's aclose()
        directly (it doesn't go through ``BudgetManager``).
        """
        close_fn = getattr(self._client, "close", None) or getattr(
            self._client, "aclose", None
        )
        if close_fn is None:
            return
        result = close_fn()
        if hasattr(result, "__await__"):
            await result

    def is_retryable_error(self, exc: BaseException) -> bool:
        if isinstance(exc, openai.RateLimitError):
            return True
        if isinstance(exc, openai.APIStatusError):
            return exc.status_code >= 500
        if isinstance(exc, ProviderCallError):
            return True
        return False

    async def call(
        self,
        system: str,
        user: str,
        model: str,
        max_tokens: int,
        temperature: float,
    ) -> CallResult:
        if not self.supports_model(model):
            raise ProviderCallError(
                f"model {model!r} is not in the OpenAI provider's known list; "
                f"valid options: {sorted(_KNOWN_MODELS)}"
            )

        try:
            response = await self._client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                max_tokens=max_tokens,
                temperature=temperature,
            )
        except openai.AuthenticationError as exc:
            # Terminal: no retry will fix a bad key.
            raise ProviderAuthError(f"OpenAI auth failed: {exc}") from exc
        # All other SDK exceptions propagate unchanged; the retry loop
        # consults ``is_retryable_error`` which knows 429 / 5xx are
        # retryable and other 4xx (bad request, etc.) are not.

        usage = response.usage
        # OpenAI exposes cache stats under usage.prompt_tokens_details.cached_tokens
        cache_read = 0
        if usage is not None:
            details = getattr(usage, "prompt_tokens_details", None)
            if details is not None:
                cache_read = getattr(details, "cached_tokens", 0) or 0

        text = response.choices[0].message.content or ""
        return CallResult(
            text=text,
            input_tokens=getattr(usage, "prompt_tokens", 0) or 0,
            output_tokens=getattr(usage, "completion_tokens", 0) or 0,
            cache_read_tokens=cache_read,
            cache_write_tokens=0,  # OpenAI doesn't report a write-side bill
            model=response.model or model,
        )
