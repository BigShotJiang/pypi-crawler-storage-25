"""OllamaProvider — local LLM via the Ollama HTTP server.

Runs entirely on the user's hardware; no external network traffic.  Cost
is hardcoded to ``$0`` (locked spec decision #1).  Pre-flight verifies the
server is reachable at construction time.

Install: https://ollama.com  → ``ollama serve`` → ``ollama pull llama3.1:8b``.
"""

from __future__ import annotations

from typing import Any

import httpx

from sagex.llm.providers.base import (
    CallResult,
    Provider,
    ProviderCallError,
    ProviderUnavailableError,
)

_DEFAULT_BASE_URL = "http://localhost:11434"
_CALL_TIMEOUT_SECONDS = 300.0


class OllamaProvider(Provider):
    """Calls a local Ollama server via ``POST /api/chat``.

    Parameters
    ----------
    base_url:
        Server URL.  Defaults to ``http://localhost:11434``.
    client:
        Optional ``httpx.AsyncClient`` override for tests.  When provided,
        the pre-flight ``/api/tags`` check is skipped — the stub will serve
        whatever responses it was configured with.
    """

    def __init__(
        self,
        base_url: str = _DEFAULT_BASE_URL,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")

        if client is not None:
            self._client = client
            return

        # Pre-flight: GET /api/tags synchronously so we fail loudly if the
        # server isn't running.  Uses a sync httpx.Client (single quick call).
        try:
            with httpx.Client(timeout=5.0) as sync_client:
                resp = sync_client.get(f"{self._base_url}/api/tags")
            resp.raise_for_status()
        except (httpx.RequestError, httpx.HTTPStatusError) as exc:
            raise ProviderUnavailableError(
                f"Ollama server not reachable at {self._base_url}. "
                f"Install from https://ollama.com and run `ollama serve`, "
                f"then retry.  Underlying error: {exc}"
            ) from exc

        self._client = httpx.AsyncClient(timeout=_CALL_TIMEOUT_SECONDS)

    @property
    def name(self) -> str:
        return "ollama"

    def supports_model(self, model: str) -> bool:
        # Ollama has a user-managed model registry — we don't enumerate.
        # ``ollama pull foo:bar`` after the fact makes any string valid.
        return True

    def is_retryable_error(self, exc: BaseException) -> bool:
        # All call-level failures from OllamaProvider are ProviderCallError
        # (HTTP 4xx/5xx, RequestError).  Retry once to cover transient
        # localhost hiccups (server reload, model swap, etc.).
        return isinstance(exc, ProviderCallError)

    async def aclose(self) -> None:
        """Release the underlying httpx connection pool.

        Long-running daemons (``sagex serve``) should call this at shutdown
        to avoid leaking sockets over multi-day runs.
        """
        await self._client.aclose()

    async def call(
        self,
        system: str,
        user: str,
        model: str,
        max_tokens: int,
        temperature: float,
    ) -> CallResult:
        payload: dict[str, Any] = {
            "model": model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "stream": False,
            "options": {
                "num_predict": max_tokens,
                "temperature": temperature,
            },
        }
        try:
            response = await self._client.post(
                f"{self._base_url}/api/chat",
                json=payload,
            )
        except httpx.RequestError as exc:
            raise ProviderCallError(
                f"Ollama request failed: {exc}"
            ) from exc

        if response.status_code >= 400:
            raise ProviderCallError(
                f"Ollama returned HTTP {response.status_code}: "
                f"{response.text[:500]}"
            )

        data = response.json()
        # Ollama returns ``{"message": {"role": "assistant", "content": "..."},
        # "prompt_eval_count": N, "eval_count": M, ...}``
        message = data.get("message") or {}
        text = message.get("content", "")
        return CallResult(
            text=text,
            input_tokens=int(data.get("prompt_eval_count", 0) or 0),
            output_tokens=int(data.get("eval_count", 0) or 0),
            cache_read_tokens=0,
            cache_write_tokens=0,
            model=str(data.get("model", model)),
        )
