"""LLM provider abstraction.

Every LLM call in sagex flows through ``BudgetManager``, which delegates the
actual wire-level request to a ``Provider``.  Swapping providers lets sagex
target Anthropic API, a locally-installed ``claude`` CLI, the OpenAI API, or
a local Ollama server, all behind the same budget / cache / token-tracker
machinery.
"""

from sagex.llm.providers.base import (
    CallResult,
    Provider,
    ProviderAuthError,
    ProviderCallError,
    ProviderUnavailableError,
)
from sagex.llm.providers.factory import make_provider

__all__ = [
    "CallResult",
    "Provider",
    "ProviderAuthError",
    "ProviderCallError",
    "ProviderUnavailableError",
    "make_provider",
]
