"""Factory that builds a ``Provider`` from ``AgentConfig`` + env vars.

Resolution order for the active provider name:

1. ``SAGEX_PROVIDER`` environment variable (override for one-off runs)
2. ``agent.provider`` from the project config file
3. Default: ``"anthropic_api"``

The sentinel model resolution is done inside ``AgentConfig`` itself (see
``_resolve_model_sentinels``), so the factory only needs to instantiate the
right class with the right kwargs.
"""

from __future__ import annotations

import logging
import os
from typing import cast

from sagex.config import PROVIDER_MODEL_DEFAULTS, AgentConfig, ProviderName
from sagex.llm.providers.anthropic_api import AnthropicAPIProvider
from sagex.llm.providers.base import Provider
from sagex.llm.providers.claude_code import ClaudeCodePassthroughProvider
from sagex.llm.providers.ollama import OllamaProvider
from sagex.llm.providers.openai_api import OpenAIProvider

_log = logging.getLogger(__name__)

_ENV_OVERRIDE = "SAGEX_PROVIDER"


def _resolve_provider_name(agent_config: AgentConfig) -> ProviderName:
    """Apply the env-var override if set, falling back to config."""
    env_val = os.environ.get(_ENV_OVERRIDE, "").strip()
    if env_val:
        if env_val not in PROVIDER_MODEL_DEFAULTS:
            raise ValueError(
                f"{_ENV_OVERRIDE}={env_val!r} is not a valid provider; "
                f"valid: {sorted(PROVIDER_MODEL_DEFAULTS)}"
            )
        _log.info(
            "provider_env_override",
            extra={"extra": {"env": env_val, "config": agent_config.provider}},
        )
        return cast(ProviderName, env_val)
    return agent_config.provider


def make_provider(
    agent_config: AgentConfig,
    enable_prompt_caching: bool = True,
) -> Provider:
    """Construct the Provider selected by ``agent_config`` (or env override).

    Parameters
    ----------
    agent_config:
        Project's ``AgentConfig`` with model sentinels already resolved.
    enable_prompt_caching:
        Forwarded to ``AnthropicAPIProvider``.  Ignored by other providers.
    """
    name = _resolve_provider_name(agent_config)

    if name == "anthropic_api":
        return AnthropicAPIProvider(enable_prompt_caching=enable_prompt_caching)
    if name == "claude_code":
        return ClaudeCodePassthroughProvider()
    if name == "openai_api":
        return OpenAIProvider()
    if name == "ollama":
        return OllamaProvider(base_url=agent_config.ollama_base_url)

    # Should be unreachable thanks to the Literal type and the env-var check
    # above, but keep an explicit branch for safety.
    raise ValueError(f"Unknown provider: {name!r}")  # pragma: no cover
