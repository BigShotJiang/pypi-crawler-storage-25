"""Pydantic config models for Agentis projects."""

from __future__ import annotations

from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, Field, model_validator

# ---------------------------------------------------------------------------
# Provider model defaults
# ---------------------------------------------------------------------------
# When ``AgentConfig.model`` or ``.triage_model`` is ``None``, the factory
# resolves the sentinel against this table at startup based on the selected
# provider.  Explicit (non-None) values are validated against the per-provider
# known-model list and passed through unchanged.

ProviderName = Literal["anthropic_api", "claude_code", "openai_api", "ollama"]

PROVIDER_MODEL_DEFAULTS: dict[str, dict[str, str]] = {
    "anthropic_api": {
        "model": "claude-sonnet-4-6",
        "triage_model": "claude-haiku-4-5",
    },
    "claude_code": {
        "model": "claude-sonnet-4-6",
        "triage_model": "claude-haiku-4-5",
    },
    "openai_api": {
        "model": "gpt-5",
        "triage_model": "gpt-4o-mini",
    },
    "ollama": {
        "model": "llama3.1:8b",
        "triage_model": "llama3.2:1b",
    },
}

# Per-provider known-model allowlist used for explicit-value validation.
# Ollama returns an empty list meaning "don't validate" (user-managed registry).
PROVIDER_KNOWN_MODELS: dict[str, frozenset[str]] = {
    "anthropic_api": frozenset({
        "claude-haiku-4-5", "claude-sonnet-4-6", "claude-opus-4-7",
    }),
    "claude_code": frozenset({
        "claude-haiku-4-5", "claude-sonnet-4-6", "claude-opus-4-7",
    }),
    "openai_api": frozenset({
        "gpt-5", "gpt-4o", "gpt-4o-mini",
    }),
    "ollama": frozenset(),  # validation skipped
}


class WatchConfig(BaseModel):
    paths: list[str]
    ignore: list[str] = [
        "**/__pycache__/**",
        "**/.git/**",
        "**/node_modules/**",
        "**/*.log",
        "**/*.lock",
        # NOTE: .env* is intentionally NOT in the default ignore list.
        # Security-sensitive files must always be watchable so the security
        # agent can detect credential leaks. If you want to suppress .env
        # watch events, add "**/.env*" to this list explicitly in config.yaml.
    ]
    debounce_seconds: float = 2.0


class TestConfig(BaseModel):
    command: str
    timeout_seconds: int = 120
    working_dir: str | None = None


class AgentConfig(BaseModel):
    provider: ProviderName = "anthropic_api"
    # Sentinel defaults: empty string means "use the per-provider default
    # from PROVIDER_MODEL_DEFAULTS".  Any non-empty user value is validated
    # against PROVIDER_KNOWN_MODELS.  The ``_resolve_model_sentinels``
    # validator guarantees these are concrete strings after construction.
    model: str = ""
    triage_model: str = ""
    max_tokens: int = 2048
    triage_max_tokens: int = 512
    meta_max_tokens: int = 1024
    security_max_tokens: int = 1024
    summariser_max_tokens: int = 512
    temperature: float = 0.2
    triage_temperature: float = 0.0
    # Ollama-specific (ignored for other providers)
    ollama_base_url: str = "http://localhost:11434"

    @model_validator(mode="after")
    def _resolve_model_sentinels(self) -> AgentConfig:
        """Resolve provider override + empty-string sentinels.

        Order of operations (important — validates downstream fields against
        the *final* provider, not the config-file one):

        1. Apply ``SAGEX_PROVIDER`` env-var override to ``self.provider`` if
           the env var names a valid provider.  This avoids config/env
           inconsistency where config says ``anthropic_api`` (resolving
           model→``claude-sonnet-4-6``) but env says ``openai_api``.
        2. Resolve empty-string ``model`` / ``triage_model`` sentinels
           against the per-provider default table.
        3. Validate explicit user values against the per-provider known-model
           list (Ollama skips — user-managed registry).
        """
        import os

        env_override = os.environ.get("SAGEX_PROVIDER", "").strip()
        if env_override and env_override in PROVIDER_MODEL_DEFAULTS:
            # Only override if env names a *valid* provider.  Invalid values
            # are rejected by the factory with a clearer message.
            self.provider = env_override  # type: ignore[assignment]

        defaults = PROVIDER_MODEL_DEFAULTS[self.provider]
        known = PROVIDER_KNOWN_MODELS[self.provider]

        if not self.model:
            self.model = defaults["model"]
        elif known and self.model not in known:
            raise ValueError(
                f"model {self.model!r} is not supported by provider "
                f"{self.provider!r}; valid options: {sorted(known)}"
            )

        if not self.triage_model:
            self.triage_model = defaults["triage_model"]
        elif known and self.triage_model not in known:
            raise ValueError(
                f"triage_model {self.triage_model!r} is not supported by "
                f"provider {self.provider!r}; valid options: {sorted(known)}"
            )
        return self


class KnowledgeConfig(BaseModel):
    db_path: str = ".agents/knowledge/rules.db"
    vector_path: str = ".agents/knowledge/vectors"
    min_confidence_threshold: float = 0.4
    max_rules_in_context: int = 5
    max_episodes_in_context: int = 3
    max_rule_chars: int = 200
    max_episode_chars: int = 200
    max_context_chars: int = 4000
    context_window_lines: int = 30
    # Cap the rule set scanned by per-call O(n²) conflict detection so a
    # large rule corpus doesn't make every agent run pay the full pairwise
    # cost. Rules come from get_rules_for_project() already ordered by
    # confidence DESC, so the cap keeps the most authoritative rules.
    max_rules_in_conflict_check: int = 50
    # How often the runner's background task archives rules whose confidence
    # has fallen below ``archive_confidence_threshold``.  Default 24h keeps
    # archival off the per-event hot path (old behaviour did a COUNT+UPDATE
    # scan of the rules table for every single event) while still bounding
    # rule-store size.  Set to 0 to disable periodic archival entirely.
    archive_interval_hours: int = 24
    archive_confidence_threshold: float = 0.2


class BudgetConfig(BaseModel):
    hourly_token_limit: int = 50_000
    daily_token_limit: int = 500_000
    alert_threshold: float = 0.8
    content_cache_ttl_minutes: int = 60
    enable_prompt_caching: bool = True


class RunnerConfig(BaseModel):
    max_concurrent_tasks: int = 3
    queue_max_size: int = 100
    require_approval: bool = False
    approval_timeout_seconds: int = 300
    # Minimum 1 attempt — 0 would leave ``_execute_with_retry`` raising
    # ``TypeError: exceptions must derive from BaseException`` because the
    # loop body never ran and ``last_error`` stayed ``None`` (issue #12).
    # The config boundary is the right place to reject the invalid state.
    retry_max_attempts: int = Field(default=3, ge=1)
    retry_backoff_seconds: float = 2.0


class SecurityAgentConfig(BaseModel):
    enabled: bool = False
    watch_extra: list[str] = [
        ".env*",
        "**/*secret*",
        "**/*credential*",
        "**/requirements*.txt",
        "**/package.json",
        "**/Dockerfile*",
    ]
    auto_remediate: bool = False


class AgentsConfig(BaseModel):
    security: SecurityAgentConfig = Field(default_factory=SecurityAgentConfig)


class NotificationsConfig(BaseModel):
    webhook_url: str | None = None
    on: list[str] = ["critical", "regression_detected"]


class ProjectConfig(BaseModel):
    name: str
    repo_root: str
    watch: WatchConfig
    test: TestConfig
    agent: AgentConfig = Field(default_factory=AgentConfig)
    knowledge: KnowledgeConfig = Field(default_factory=KnowledgeConfig)
    budget: BudgetConfig = Field(default_factory=BudgetConfig)
    runner: RunnerConfig = Field(default_factory=RunnerConfig)
    agents: AgentsConfig = Field(default_factory=AgentsConfig)
    notifications: NotificationsConfig = Field(default_factory=NotificationsConfig)
    runtime_url: str = "http://localhost:8765"


def load_config(config_path: Path) -> ProjectConfig:
    """Load and validate a .agents/config.yaml file.

    PyYAML (YAML 1.1) parses the bare key ``on`` as the boolean ``True``.
    This is a known gotcha for the ``notifications.on`` field — we normalise
    it back to the string key ``"on"`` before handing the dict to Pydantic.

    Relative ``repo_root`` values are resolved against the config file's
    parent directory so ``repo_root: .`` always means "this config's
    folder", regardless of the server's working directory.  Previously
    the server would ``cd`` to its own cwd and run tests in the wrong
    tree.  Absolute paths pass through unchanged.
    """
    config_path = config_path.resolve()
    raw: dict[str, object] = yaml.safe_load(config_path.read_text())
    if isinstance(raw.get("notifications"), dict):
        notifs: dict[object, object] = raw["notifications"]  # type: ignore[assignment]
        if True in notifs:
            notifs["on"] = notifs.pop(True)
    # Resolve relative repo_root against the config file's directory.
    rr = raw.get("repo_root")
    if isinstance(rr, str):
        rr_path = Path(rr)
        if not rr_path.is_absolute():
            # config lives at /proj/.agents/config.yaml  →  anchor = /proj
            anchor = config_path.parent
            if anchor.name == ".agents":
                anchor = anchor.parent
            raw["repo_root"] = str((anchor / rr_path).resolve())
    return ProjectConfig.model_validate(raw)
