"""sentence-transformers wrapper with lazy model loading.

The model (~90 MB) is downloaded once and cached at
~/.cache/sentence_transformers/. Subsequent loads are instant.
"""

from __future__ import annotations

import asyncio
import threading
from typing import Any


class Embedder:
    MODEL_NAME = "all-MiniLM-L6-v2"

    def __init__(self) -> None:
        self._model: Any = None  # SentenceTransformer, lazy-loaded on first use
        # Guards the lazy-init in ``_load``.  Without this, two concurrent
        # ``aembed*`` calls running on different worker threads (via
        # ``asyncio.to_thread``) can both observe ``self._model is None``,
        # both build a SentenceTransformer (the second wasting the ~90 MB
        # download cost / memory), and the later assignment can overwrite
        # an instance another thread is mid-``encode`` against.  Cheap on
        # the hot path: the lock is held only for the cache-check after
        # the first successful load.
        self._load_lock = threading.Lock()

    def _load(self) -> None:
        # Double-checked: the fast path is the read of ``_model`` outside
        # the lock so steady-state callers don't pay a lock acquisition.
        # The lock-protected re-check is the slow-path that prevents two
        # concurrent first-callers from racing the import + construction.
        if self._model is not None:
            return
        with self._load_lock:
            if self._model is None:
                from sentence_transformers import (
                    SentenceTransformer,  # type: ignore[import-untyped,unused-ignore]
                )

                self._model = SentenceTransformer(self.MODEL_NAME)

    def embed(self, text: str) -> list[float]:
        self._load()
        result: list[float] = self._model.encode(text).tolist()
        return result

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        self._load()
        result: list[list[float]] = self._model.encode(texts).tolist()
        return result

    # ------------------------------------------------------------------
    # Async wrappers (issue #9) — see VectorDB for rationale.  A
    # sentence-transformers forward pass is 50–200ms CPU on the loop
    # thread; offload via asyncio.to_thread so concurrent events can
    # embed in parallel.
    # ------------------------------------------------------------------

    async def aembed(self, text: str) -> list[float]:
        return await asyncio.to_thread(self.embed, text)

    async def aembed_batch(self, texts: list[str]) -> list[list[float]]:
        return await asyncio.to_thread(self.embed_batch, texts)
