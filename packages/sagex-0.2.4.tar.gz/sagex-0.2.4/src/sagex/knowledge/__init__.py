"""Knowledge store: SQLite rules DB, ChromaDB vector store, unified interface."""
