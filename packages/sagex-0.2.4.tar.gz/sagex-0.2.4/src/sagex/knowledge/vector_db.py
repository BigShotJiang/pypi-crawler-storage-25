"""ChromaDB vector store wrapper.

All documents from every project share one collection (``agent_knowledge``),
filtered by the ``project_name`` metadata field at query time.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

from sagex.knowledge.embedder import Embedder


class VectorDB:
    def __init__(self, persist_path: str, embedder: Embedder) -> None:
        import chromadb  # lazy — chromadb+onnx can be slow to import

        Path(persist_path).mkdir(parents=True, exist_ok=True)
        self._client: Any = chromadb.PersistentClient(path=persist_path)
        self._collection: Any = self._client.get_or_create_collection(
            "agent_knowledge"
        )
        self._embedder = embedder

    def upsert(self, id: str, text: str, metadata: dict[str, str]) -> None:
        embedding = self._embedder.embed(text)
        self._collection.upsert(
            ids=[id],
            embeddings=[embedding],
            documents=[text],
            metadatas=[metadata],
        )

    def query(
        self,
        query_text: str,
        project_name: str,
        n_results: int = 5,
    ) -> list[dict[str, Any]]:
        embedding = self._embedder.embed(query_text)
        # Guard: ChromaDB raises if n_results > collection size
        total: int = self._collection.count()
        actual_n = min(n_results, total)
        if actual_n == 0:
            return []
        try:
            results: dict[str, Any] = self._collection.query(
                query_embeddings=[embedding],
                n_results=actual_n,
                where={"project_name": project_name},
            )
        except Exception:
            return []

        items: list[dict[str, Any]] = []
        ids = results.get("ids", [[]])[0]
        docs = results.get("documents", [[]])[0]
        metas = results.get("metadatas", [[]])[0]
        dists = results.get("distances", [[]])[0]
        for i, item_id in enumerate(ids):
            items.append(
                {
                    "id": item_id,
                    "text": docs[i] if i < len(docs) else "",
                    "metadata": metas[i] if i < len(metas) else {},
                    "distance": dists[i] if i < len(dists) else 0.0,
                }
            )
        return items

    def delete(self, id: str) -> None:
        try:
            self._collection.delete(ids=[id])
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Async wrappers (issue #9)
    #
    # ChromaDB's DuckDB-backed ``query`` and ``upsert`` + the underlying
    # sentence-transformers forward pass are synchronous and CPU-bound —
    # ~100–500ms on warm calls.  Running them on the event loop thread
    # stalls every other event, approval poller, and HTTP handler for
    # the duration (defeats the point of asyncio.Semaphore(3)).  These
    # ``a*`` wrappers offload to the default thread pool so three
    # concurrent events can actually do their embedding work in
    # parallel on separate threads.
    # ------------------------------------------------------------------

    async def aupsert(self, id: str, text: str, metadata: dict[str, str]) -> None:
        await asyncio.to_thread(self.upsert, id, text, metadata)

    async def aquery(
        self,
        query_text: str,
        project_name: str,
        n_results: int = 5,
    ) -> list[dict[str, Any]]:
        return await asyncio.to_thread(
            self.query, query_text, project_name, n_results,
        )
