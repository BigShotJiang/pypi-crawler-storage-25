"""Main orchestration loop: observe-act-reflect cycle.

The ``Runner`` listens on the ``EventBus`` and processes each event through:
  1. Security check (optional, zero-token pattern scan)
  2. Triage (rule-based → Haiku if inconclusive)
  3. Test run before acting
  4. Knowledge context load
  5. Task agent plan
  6. (Optional) approval gate — runs OUTSIDE the semaphore
  7. Action execution + test run after
  8. Meta agent reflection
  9. Knowledge update

The semaphore (default 3) limits concurrent *active computation* only.
Approval waits run outside the semaphore so they don't block other events.
"""

from __future__ import annotations

import asyncio
import dataclasses
import json
import logging
import time
from collections import OrderedDict
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

import httpx

from sagex.agents.meta_agent import MetaAgent, detect_regression
from sagex.agents.security_agent import SecurityAgent, SecurityRisk, classify_security_risk
from sagex.agents.task_agent import ActionExecutor, ExecutionResult, TaskAgent
from sagex.agents.triage_agent import TriageAgent, TriageResult
from sagex.api.server import ApprovalWaiters, ProjectRegistry
from sagex.config import ProjectConfig
from sagex.event_bus import AgentEvent, EventBus
from sagex.knowledge.rules_db import Episode, PendingApproval, Rule, RulesDB
from sagex.knowledge.store import KnowledgeContext, KnowledgeStore
from sagex.llm.budget import BudgetExceededError, BudgetManager
from sagex.llm.cache import ContentCache
from sagex.llm.providers.base import Provider
from sagex.llm.token_tracker import TokenTracker
from sagex.watcher import WatcherManager

_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Plan phase result type
# ---------------------------------------------------------------------------

@dataclass
class PlanResult:
    """Typed bundle produced by ``Runner._plan_phase`` on the happy path.

    Replaces a 10-tuple whose ``BudgetManager``/``TaskAgent``/``MetaAgent``
    slots received ``None`` on error branches — that shape violated its
    annotations and required a ``# type: ignore[return-value]`` to
    appease mypy (issue #27).  With ``_plan_phase`` returning
    ``PlanResult | None`` the skip signal is syntactic: ``None`` means
    "do not execute", and every field on a returned ``PlanResult`` is
    guaranteed non-None.
    """

    plan: dict[str, Any]
    episode: Episode
    triage: TriageResult
    context: KnowledgeContext
    test_before: str | None
    store: KnowledgeStore
    budget: BudgetManager
    task_agent: TaskAgent
    meta_agent: MetaAgent


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _serialise(event: AgentEvent) -> str:
    return json.dumps(dataclasses.asdict(event), default=str)


# Per-project provider cache.  Provider construction does blocking I/O
# for claude_code (subprocess.run --version) and ollama (httpx GET
# /api/tags); re-running those on every event would stall the event loop.
# Caching makes pre-flight a one-time cost per sagex serve process.
#
# Cache key includes every provider-construction input so a project
# re-register with modified settings (different ollama_base_url,
# enable_prompt_caching flip, etc.) builds a fresh provider instead of
# silently reusing a stale one.
_PROVIDER_CACHE: OrderedDict[tuple[str, ...], Provider] = OrderedDict()
# Hard cap so a server handling many distinct project configs (or many
# re-registrations with changing provider settings) can't grow the cache
# without bound.  Each provider owns an httpx pool / subprocess handle, so
# leaking them is real memory + file-descriptor pressure.  64 is well above
# realistic concurrent-project counts for a single sagex serve process.
_MAX_PROVIDER_CACHE = 64
# Guards the check-then-create pattern below.  Without this, two concurrent
# _handle_event tasks could both see a cache miss for the same key, both
# construct providers, and the second insert would orphan the first (its
# httpx pool neither cached nor closed).
_PROVIDER_CACHE_LOCK = asyncio.Lock()
# In-flight provider constructions keyed by cache_key.  Concurrent callers
# that miss the cache find an event here and wait on it, instead of each
# launching their own blocking pre-flight.  Populated and cleared under
# _PROVIDER_CACHE_LOCK; the event itself is signalled by the constructor
# after it installs the provider in _PROVIDER_CACHE.  See _make_budget_manager.
_PROVIDER_CACHE_PENDING: dict[tuple[str, ...], asyncio.Event] = {}
# Set by Runner.aclose() to coordinate shutdown with in-flight
# _make_budget_manager calls: a constructor that finishes after aclose()
# has snapshotted-and-cleared the cache must close the just-built provider
# itself instead of installing it into a closed cache (where it would
# leak past shutdown).  Reads/writes guarded by _PROVIDER_CACHE_LOCK.
_PROVIDER_CACHE_CLOSED: bool = False


class ProviderCacheClosedError(RuntimeError):
    """Raised when ``_make_budget_manager`` cannot serve a request because the
    process is shutting down (``Runner.aclose`` has run).  Callers should
    treat this as a transient shutdown signal, not a configuration error."""


async def _aclose_provider(
    provider: Provider,
    cache_key: tuple[str, ...] | None = None,
) -> None:
    """Best-effort aclose() on an evicted provider.

    Providers without an aclose() (e.g. test fakes) are skipped silently;
    failures from live aclose() are logged and swallowed so eviction never
    propagates back up to the caller.

    ``cache_key`` is optional identifying context included in the failure
    log — without it, a production httpx-pool / file-descriptor leak shows
    up in logs as an anonymous warning that can't be attributed to a
    specific project or provider config.  Callers that have the cache key
    handy should pass it; those that don't (e.g. ``Runner.aclose`` closing
    everything at shutdown) can omit it and the log still includes
    ``provider.name`` as a partial fingerprint.
    """
    close_fn = getattr(provider, "aclose", None)
    if close_fn is None:
        return
    try:
        await close_fn()
    except Exception as exc:  # noqa: BLE001
        _log.warning(
            "evicted_provider_aclose_failed",
            extra={
                "extra": {
                    "error": str(exc),
                    "provider": getattr(provider, "name", "unknown"),
                    "cache_key": list(cache_key) if cache_key else None,
                }
            },
        )


async def _evict_lru_if_full() -> None:
    """Make room in the provider cache before an imminent insert.

    **Call contract:** this is a *pre-insert* helper.  The caller is about
    to add one new entry, so we evict while ``len >= cap`` (not ``>``) so
    that after this returns, ``len < cap`` and the caller's subsequent
    ``_PROVIDER_CACHE[cache_key] = provider`` lands at exactly ``cap`` —
    never over.  If this were called without a pending insert, the cache
    would stabilise at ``cap - 1`` (one slot permanently empty).

    Caller must hold ``_PROVIDER_CACHE_LOCK`` — enforced at runtime via an
    assertion so a future refactor that drops the lock wrap doesn't also
    silently break the check-then-evict ordering.

    Uses OrderedDict.popitem (last=False) so the least-recently-inserted /
    least-recently-touched entry goes first — callers bump freshness by
    move_to_end on every hit.

    No-op when ``_MAX_PROVIDER_CACHE`` is non-positive — otherwise the loop
    would try to popitem on an empty dict forever.  ``<= 0`` can only
    happen via a misconfiguration (the constant is not user-facing today),
    but the guard is cheap and prevents an unbounded hang.
    """
    assert _PROVIDER_CACHE_LOCK.locked(), (
        "_evict_lru_if_full must be called while holding _PROVIDER_CACHE_LOCK"
    )
    if _MAX_PROVIDER_CACHE <= 0:
        return
    while len(_PROVIDER_CACHE) >= _MAX_PROVIDER_CACHE:
        victim_key, victim = _PROVIDER_CACHE.popitem(last=False)
        await _aclose_provider(victim, cache_key=victim_key)


def _provider_cache_key(config: ProjectConfig) -> tuple[str, ...]:
    """Build a cache key that invalidates when provider-relevant config changes."""
    return (
        config.name,
        config.agent.provider,
        config.agent.ollama_base_url,
        str(config.budget.enable_prompt_caching),
    )


async def _evict_stale_providers_for_project(project_name: str, keep_key: tuple[str, ...]) -> None:
    """Close + remove any cached providers for *project_name* that aren't *keep_key*.

    A project re-registered with different provider settings (new ollama URL,
    prompt-caching flipped, etc.) lands a new cache key.  Without eviction,
    the old provider instance stays in the cache forever, leaking its
    httpx pool and occupying memory until process exit.
    """
    # Cache keys are always non-empty 4-tuples from _provider_cache_key,
    # so no truthiness check on k is needed.
    stale_keys = [
        k for k in _PROVIDER_CACHE
        if k[0] == project_name and k != keep_key
    ]
    for k in stale_keys:
        old = _PROVIDER_CACHE.pop(k, None)
        if old is not None:
            await _aclose_provider(old, cache_key=k)


async def _make_budget_manager(config: ProjectConfig) -> BudgetManager:
    from sagex.llm.providers import make_provider

    db = RulesDB(config.knowledge.db_path)
    tracker = TokenTracker(db)
    cache = ContentCache(db, ttl_minutes=config.budget.content_cache_ttl_minutes)

    cache_key = _provider_cache_key(config)

    # ``make_provider`` performs blocking pre-flight I/O (subprocess.run for
    # claude_code, httpx.get for ollama) that can take 100ms–2s on a cold
    # start.  Running it inside ``_PROVIDER_CACHE_LOCK`` would stall every
    # other project's event handler for the duration (issue #20).  Instead:
    #
    #   1. Hold the lock only long enough to decide: hit, install a pending
    #      slot, or wait for someone else's pending slot.
    #   2. Release the lock before constructing.
    #   3. Reacquire briefly to finalise the cache slot.
    #
    # The ``_PROVIDER_CACHE_PENDING`` map stores ``asyncio.Event`` per
    # in-flight construction so concurrent callers for the same key block
    # on the first constructor instead of launching rival constructions.
    while True:
        async with _PROVIDER_CACHE_LOCK:
            if _PROVIDER_CACHE_CLOSED:
                raise ProviderCacheClosedError(
                    "Provider cache is shut down (Runner.aclose has run)."
                )
            provider = _PROVIDER_CACHE.get(cache_key)
            if provider is not None:
                # Cache hit — bump freshness so LRU eviction targets truly
                # cold entries.
                _PROVIDER_CACHE.move_to_end(cache_key)
                return BudgetManager(config.budget, tracker, cache, provider=provider)

            pending = _PROVIDER_CACHE_PENDING.get(cache_key)
            if pending is None:
                # We're the first: stake a pending-slot and construct outside the lock.
                event = asyncio.Event()
                _PROVIDER_CACHE_PENDING[cache_key] = event
                must_construct = True
            else:
                # Someone else is already constructing this exact key — wait.
                event = pending
                must_construct = False

            if must_construct:
                # Evict while still under the lock so the cache doesn't overshoot
                # _MAX_PROVIDER_CACHE between our pending-reservation and the
                # finalise step below.  We re-check the cap at install time
                # too, because pending reservations for *different* keys can
                # accumulate while their constructions run in parallel and
                # collectively overshoot the eviction budget computed here.
                #
                # Both calls await on _aclose_provider for any victim.  If
                # we're cancelled (or eviction raises) between staking the
                # pending slot and reaching the construction try/except
                # below, the slot would leak forever and any subsequent
                # caller for this key would deadlock on ``event.wait()``.
                # Catch *any* exception, drop the slot, signal the event,
                # then re-raise so the caller still sees the error.
                try:
                    await _evict_stale_providers_for_project(config.name, cache_key)
                    await _evict_lru_if_full()
                except BaseException:
                    if _PROVIDER_CACHE_PENDING.get(cache_key) is event:
                        _PROVIDER_CACHE_PENDING.pop(cache_key, None)
                    event.set()
                    raise

        if must_construct:
            # Blocking pre-flight runs WITHOUT the lock.  Offload to a thread
            # so even a synchronous implementation doesn't block the event
            # loop itself — keeps HTTP handlers and other tasks responsive.
            #
            # Cancellation handling: ``asyncio.to_thread`` is cancellation-
            # sensitive — if our task is cancelled mid-await, the worker
            # thread keeps running and can still produce a provider whose
            # resources would be silently dropped.  Wrap the work in a
            # shielded task so cancellation flips us into a cleanup branch
            # that closes whatever the thread eventually returns.
            construct_task = asyncio.ensure_future(
                asyncio.to_thread(
                    make_provider,
                    config.agent,
                    enable_prompt_caching=config.budget.enable_prompt_caching,
                )
            )
            try:
                new_provider = await asyncio.shield(construct_task)
            except asyncio.CancelledError:
                # Our awaiter was cancelled.  The thread is still running;
                # spawn a detached cleanup that closes the orphaned provider
                # once it materialises and frees the pending slot for any
                # waiters.
                async def _cleanup_orphan() -> None:
                    try:
                        prov = await construct_task
                    except BaseException:
                        prov = None
                    async with _PROVIDER_CACHE_LOCK:
                        _PROVIDER_CACHE_PENDING.pop(cache_key, None)
                    event.set()
                    if prov is not None:
                        await _aclose_provider(prov, cache_key=cache_key)

                asyncio.ensure_future(_cleanup_orphan())
                raise
            except BaseException:
                # Construction failed (e.g. ollama unreachable).  Free the
                # pending slot so waiters don't deadlock, then propagate.
                async with _PROVIDER_CACHE_LOCK:
                    _PROVIDER_CACHE_PENDING.pop(cache_key, None)
                event.set()
                raise

            # ``provider_to_close`` is the just-built provider only when
            # we lose the shutdown race.  We hold the cache lock just
            # long enough to mutate state, then release it before
            # awaiting the slow provider teardown — keeping aclose()
            # off the lock prevents long httpx-pool drains from
            # blocking other tasks (notably another Runner.aclose()
            # observer) from making progress during shutdown.
            provider_to_close: Provider | None = None
            async with _PROVIDER_CACHE_LOCK:
                if _PROVIDER_CACHE_CLOSED:
                    # Lost the race against Runner.aclose() — install would
                    # leak the just-constructed provider into a cache no
                    # one will close.  Drop the pending slot and signal
                    # waiters under the lock, then close the provider
                    # ourselves outside the critical section.
                    _PROVIDER_CACHE_PENDING.pop(cache_key, None)
                    event.set()
                    provider_to_close = new_provider
                else:
                    # Re-check cap here (not just before construction):
                    # pending reservations for other keys may have
                    # completed and pushed the cache to capacity while
                    # our to_thread was running.
                    await _evict_lru_if_full()
                    _PROVIDER_CACHE[cache_key] = new_provider
                    _PROVIDER_CACHE_PENDING.pop(cache_key, None)
                    event.set()
            if provider_to_close is not None:
                await _aclose_provider(provider_to_close, cache_key=cache_key)
                raise ProviderCacheClosedError(
                    "Provider cache shut down during construction."
                )
            return BudgetManager(config.budget, tracker, cache, provider=new_provider)

        # Wait for whoever staked the pending-slot to finish, then loop and
        # re-read the cache — most often a hit this time.
        await event.wait()


async def _run_tests(config: ProjectConfig) -> str:
    """Run the project test suite and return 'pass' or 'fail'.

    Async: uses ``asyncio.create_subprocess_shell`` so the event loop
    keeps serving other events while the test command runs.  The previous
    ``subprocess.run`` blocked the whole loop for up to
    ``test.timeout_seconds`` (default 120s), starving HTTP handlers.
    """
    try:
        proc = await asyncio.create_subprocess_shell(
            config.test.command,
            cwd=config.test.working_dir or config.repo_root,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        try:
            await asyncio.wait_for(proc.wait(), timeout=config.test.timeout_seconds)
        except TimeoutError:
            proc.kill()
            try:
                await proc.wait()
            except Exception:  # noqa: BLE001
                pass
            return "fail"
        return "pass" if proc.returncode == 0 else "fail"
    except Exception:
        return "fail"


def _run_security_check(
    event: AgentEvent,
    config: ProjectConfig,
) -> SecurityRisk | None:
    """Run the zero-token security pattern scan on the event diff."""
    diff = event.diff or event.diff_context or ""
    if not diff:
        return None
    worst: SecurityRisk | None = None
    for file_path in event.file_paths:
        risk = classify_security_risk(diff, file_path)
        if risk and (
            worst is None
            or {"critical": 3, "high": 2, "medium": 1}.get(risk.severity, 0)
            > {"critical": 3, "high": 2, "medium": 1}.get(worst.severity, 0)
        ):
            worst = risk
    return worst


async def _maybe_notify(config: ProjectConfig, episode: Episode) -> None:
    """Fire webhook notification if configured and conditions match."""
    webhook_url = config.notifications.webhook_url
    if not webhook_url:
        return
    on_conditions = config.notifications.on
    should_notify = (
        episode.severity in on_conditions
        or (episode.regression_detected and "regression_detected" in on_conditions)
    )
    if not should_notify:
        return
    try:
        async with httpx.AsyncClient() as client:
            await client.post(
                webhook_url,
                json={
                    "project": episode.project_name,
                    "episode_id": episode.id,
                    "severity": episode.severity,
                    "regression": bool(episode.regression_detected),
                    "status": episode.status,
                },
                timeout=5.0,
            )
    except Exception as exc:
        _log.warning("webhook_failed", extra={"url": webhook_url, "error": str(exc)})


# ---------------------------------------------------------------------------
# Retry wrapper
# ---------------------------------------------------------------------------


async def _execute_with_retry(
    plan: dict[str, Any],
    config: ProjectConfig,
    test_before: str | None,
    runner_config: Any,
) -> ExecutionResult:
    executor = ActionExecutor()
    last_error: Exception | None = None
    for attempt in range(runner_config.retry_max_attempts):
        try:
            return await executor.execute(plan, config, test_before)
        except Exception as exc:
            last_error = exc
            await asyncio.sleep(runner_config.retry_backoff_seconds**attempt)
    raise last_error  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Approval wait
# ---------------------------------------------------------------------------


async def _wait_for_approval(
    plan: dict[str, Any],
    episode: Episode,
    store: KnowledgeStore,
    config: ProjectConfig,
    waiters: ApprovalWaiters | None = None,
) -> bool:
    """Write a PendingApproval and wait until resolved or timed out.

    Uses an ``asyncio.Event`` registered with *waiters* to resume within
    milliseconds of the API route flipping the row — no 5-second polling
    lag (issue #10).  A ~30s fallback ``asyncio.wait_for`` still reads
    the DB so we remain restart-safe: if the process died and lost the
    in-memory event, the next tick still sees the resolution written to
    ``pending_approvals`` by the API route.

    Must be called WITHOUT holding the runner semaphore.
    """
    approval = PendingApproval(
        project_name=episode.project_name,
        episode_id=episode.id,
        plan_json=json.dumps(plan),
        status="pending",
        created_at=_now(),
    )
    approval_id = await store._db.write_pending_approval(approval)
    event = waiters.register(approval_id) if waiters is not None else None

    loop = asyncio.get_running_loop()
    deadline = loop.time() + config.runner.approval_timeout_seconds
    fallback_poll_seconds = 30.0

    try:
        while loop.time() < deadline:
            remaining = deadline - loop.time()
            tick = min(fallback_poll_seconds, remaining)
            if event is not None:
                try:
                    await asyncio.wait_for(event.wait(), timeout=tick)
                except TimeoutError:
                    # asyncio.wait_for() raises ``asyncio.TimeoutError``,
                    # which is an alias of the builtin ``TimeoutError`` since
                    # Python 3.11 — ruff UP041 enforces the builtin name.
                    # Fall through to DB poll so a missed signal (process
                    # restart, stale registry) doesn't strand the waiter.
                    pass
            else:
                await asyncio.sleep(tick)

            resolved = store._db.get_approval(approval_id)
            if resolved is None:
                continue
            if resolved.status == "approved":
                return True
            if resolved.status == "rejected":
                return False

        # Timeout: mark it resolved so subsequent observers don't see it as
        # pending forever.  project_name=None takes the timeout-path branch
        # in resolve_approval (the auto-resolver, not a cross-project caller).
        try:
            await store._db.resolve_approval(approval_id, "timeout")
        except ValueError:
            # Race: user approved/rejected between our last poll and now.
            # Re-read and honour the resolved status instead of falling
            # through as a timeout.
            resolved = store._db.get_approval(approval_id)
            if resolved is not None and resolved.status == "approved":
                return True
        return False
    finally:
        if waiters is not None:
            waiters.discard(approval_id)


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------


class Runner:
    """Orchestrates the observe-act-reflect loop for all registered projects."""

    def __init__(
        self,
        event_bus: EventBus,
        registry: ProjectRegistry,
        watcher_manager: WatcherManager,
        max_concurrent_tasks: int = 3,
        approval_waiters: ApprovalWaiters | None = None,
    ) -> None:
        self._bus = event_bus
        self._registry = registry
        self._watcher_manager = watcher_manager
        self._semaphore = asyncio.Semaphore(max_concurrent_tasks)
        self._archival_task: asyncio.Task[None] | None = None
        self._approval_waiters = approval_waiters

    async def run(self) -> None:
        """Consume events from the bus forever."""
        # Launch the rule-archival background task once, at first run.
        # Firing archival inline on every event (old behaviour) scaled as
        # O(events) instead of O(time) — issue #21.  Guard re-creation so
        # callers (or tests) that invoke run() twice don't end up with two
        # archival loops, where the first becomes uncancellable from
        # aclose().
        if self._archival_task is None or self._archival_task.done():
            self._archival_task = asyncio.create_task(self._archival_loop())
        while True:
            event = await self._bus.subscribe()
            asyncio.create_task(self._handle_event(event))

    async def _archival_loop(self) -> None:
        """Periodically archive low-confidence rules for every project.

        Sleep granularity is one hour; each tick we inspect each project's
        ``archive_interval_hours`` setting and run archival only if the
        per-project interval has elapsed.  Archival is idempotent — a tick
        that finds no eligible rows simply returns 0.

        The task is started once at ``run()`` time and runs until cancelled
        by ``aclose``.  Errors during archival are logged and swallowed so
        one misbehaving project can't kill the whole loop.

        ``RulesDB`` instances are cached per ``db_path``: the constructor
        opens a SQLite connection and runs migrations, so re-creating one
        per archival tick (every interval, every project) leaks file
        descriptors and re-runs the migrations check.
        """
        last_archived_at: dict[str, float] = {}
        db_cache: dict[str, RulesDB] = {}
        loop = asyncio.get_running_loop()
        # Granularity = 1h; finer ticking would wake the loop for no reason
        # since config intervals are measured in hours.
        tick_seconds = 3600.0
        try:
            while True:
                try:
                    await asyncio.sleep(tick_seconds)
                except asyncio.CancelledError:
                    return
                now = loop.time()
                for project in self._registry.list_all():
                    interval_h = project.knowledge.archive_interval_hours
                    if interval_h <= 0:
                        continue
                    # Treat the first tick after a project becomes visible
                    # as the project's "last archive" anchor.  ``loop.time()``
                    # is monotonic and starts near 0, so the previous
                    # ``get(..., 0.0)`` default made every newly-registered
                    # project's first archival fire on the next 1-hour tick
                    # regardless of ``archive_interval_hours``.  With this
                    # anchor, the first real archival fires after the
                    # configured interval.
                    last = last_archived_at.get(project.name)
                    if last is None:
                        last_archived_at[project.name] = now
                        continue
                    if now - last < interval_h * 3600.0:
                        continue
                    try:
                        db_path = project.knowledge.db_path
                        db = db_cache.get(db_path)
                        if db is None:
                            db = RulesDB(db_path)
                            db_cache[db_path] = db
                        archived = await db.archive_low_confidence_rules(
                            project.name,
                            threshold=project.knowledge.archive_confidence_threshold,
                        )
                        last_archived_at[project.name] = now
                        _log.info(
                            "archival_tick",
                            extra={"extra": {"project": project.name, "archived": archived}},
                        )
                    except Exception as exc:  # noqa: BLE001
                        _log.warning(
                            "archival_failed",
                            extra={"extra": {"project": project.name, "error": str(exc)}},
                        )
        finally:
            # Best-effort close of any RulesDB connections we opened — older
            # RulesDB versions may not have close(); rely on getattr so we
            # don't fail shutdown if the API isn't there yet.
            for db in db_cache.values():
                close = getattr(db, "close", None)
                if callable(close):
                    try:
                        result = close()
                        if asyncio.iscoroutine(result):
                            await result
                    except Exception:  # noqa: BLE001
                        pass

    async def aclose(self) -> None:
        """Release every cached provider's HTTP/subprocess resources.

        Call this at server shutdown (e.g., from the FastAPI lifespan
        teardown) to avoid ``httpx.AsyncClient`` "unclosed client" warnings
        and flush any in-flight connections cleanly.  Each provider's
        close is best-effort — an error from one provider does not block
        closing the others.

        The snapshot + clear + closed-flag happen atomically under
        ``_PROVIDER_CACHE_LOCK``.  Concurrent ``_make_budget_manager``
        calls that are mid-construction observe the flag at install time
        and close their just-built provider themselves rather than leak
        it into a cleared cache (issue #23).  Pending-slot waiters are
        signalled here so they don't deadlock against a constructor
        whose own task may have raised ``ProviderCacheClosedError``.
        Provider aclose() runs outside the lock so a slow teardown
        doesn't block other shutdown tasks.
        """
        # Cancel the archival background task first so it stops opening new
        # RulesDB connections while we tear the provider cache down.
        if self._archival_task is not None:
            self._archival_task.cancel()
            try:
                await self._archival_task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass
            self._archival_task = None

        global _PROVIDER_CACHE_CLOSED
        async with _PROVIDER_CACHE_LOCK:
            _PROVIDER_CACHE_CLOSED = True
            entries = list(_PROVIDER_CACHE.items())
            _PROVIDER_CACHE.clear()
            # Wake every pending-slot waiter so any caller blocked in the
            # ``await event.wait()`` loop unblocks, re-takes the lock,
            # observes _PROVIDER_CACHE_CLOSED, and raises rather than
            # spinning forever waiting for a constructor that may have
            # been cancelled by shutdown.
            pending_events = list(_PROVIDER_CACHE_PENDING.values())
        for ev in pending_events:
            ev.set()
        for key, provider in entries:
            close_fn = getattr(provider, "aclose", None)
            if close_fn is None:
                continue
            try:
                await close_fn()
            except Exception as exc:  # noqa: BLE001
                _log.warning(
                    "provider_aclose_failed",
                    extra={"extra": {"cache_key": key, "error": str(exc)}},
                )

    async def _handle_event(self, event: AgentEvent) -> None:
        config = self._registry.get(event.project_name)
        if config is None:
            return

        _log.info(
            "event_received",
            extra={
                "extra": {
                    "event_id": event.id,
                    "event_type": str(event.type),
                    "project": event.project_name,
                    "file_count": len(event.file_paths),
                }
            },
        )

        try:
            # Phase 1: triage + plan — held under semaphore
            result = await self._plan_phase(event, config)
            if result is None:
                return

            # Phase 2: approval gate — runs WITHOUT semaphore
            if config.runner.require_approval:
                approved = await _wait_for_approval(
                    result.plan,
                    result.episode,
                    result.store,
                    config,
                    waiters=self._approval_waiters,
                )
                if not approved:
                    result.episode.status = "skipped"
                    await result.store.record_episode(result.episode)
                    return

            # Phase 3: execution + reflection — back under semaphore
            async with self._semaphore:
                await self._execute_phase(
                    event,
                    result.plan,
                    result.episode,
                    result.triage,
                    result.context,
                    result.test_before,
                    result.store,
                    result.budget,
                    result.meta_agent,
                    config,
                )
        finally:
            # Note: we intentionally do NOT call budget.aclose() here.
            # Providers are cached per (project, provider) across events to
            # amortise their pre-flight I/O; closing the httpx pool on each
            # event would defeat the cache.  Pool cleanup happens at
            # process exit (one pool per process is fine).
            await self._bus.mark_event_done(event.id)

    async def _plan_phase(
        self, event: AgentEvent, config: ProjectConfig
    ) -> PlanResult | None:
        """Triage + plan, held under semaphore.

        Returns ``None`` when the caller should skip execution — budget
        setup failed, triage returned ``skip``, security halted the
        event, or any branch that already recorded a terminal episode.
        Otherwise returns a fully-populated ``PlanResult``.
        """
        async with self._semaphore:
            store = KnowledgeStore(config.knowledge, event.project_name)
            episode = Episode(
                project_name=event.project_name,
                status="failed",
                trigger_event=_serialise(event),
                context_snapshot="{}",
                created_at=_now(),
            )

            try:
                budget = await _make_budget_manager(config)
                triage_agent = TriageAgent(config.agent, budget)
                task_agent = TaskAgent(config.agent, budget, config.knowledge)
                meta_agent = MetaAgent(config.agent, budget)
            except Exception as exc:
                # Budget setup failed (e.g. BudgetExceededError)
                _log.warning("plan_phase_setup_error", extra={
                    "project": event.project_name, "error": str(exc)
                })
                episode.error_message = str(exc)
                await store.record_episode(episode)
                return None

            try:
                # 1. Security check
                if config.agents.security.enabled:
                    risk = _run_security_check(event, config)
                    if risk:
                        _log.info(
                            "security_risk",
                            extra={
                                "extra": {
                                    "project": event.project_name,
                                    "severity": risk.severity,
                                    "description": risk.description,
                                    "auto_remediate": config.agents.security.auto_remediate,
                                }
                            },
                        )
                        if config.agents.security.auto_remediate:
                            # LLM-backed deep audit; result informs task agent context
                            security_agent = SecurityAgent(
                                config.agent, budget, config.agents.security
                            )
                            diff = event.diff or event.diff_context or ""
                            audit = await security_agent.audit(event, diff, risk)
                            episode.severity = str(audit.get("severity", risk.severity))
                            _log.info(
                                "security_audit",
                                extra={
                                    "extra": {
                                        "project": event.project_name,
                                        "severity": episode.severity,
                                        "description": audit.get("description"),
                                    }
                                },
                            )
                        else:
                            episode.severity = risk.severity
                            episode.status = "skipped"
                            await store.record_episode(episode)
                            await _maybe_notify(config, episode)
                            return None

                # 2. Triage
                triage = await triage_agent.classify(event)
                _log.info(
                    "triage_result",
                    extra={
                        "extra": {
                            "project": event.project_name,
                            "severity": triage.severity,
                            "used_llm": triage.used_llm,
                            "tokens_used": triage.tokens_used,
                        }
                    },
                )
                if triage.severity == "skip":
                    episode.status = "skipped"
                    episode.severity = "skip"
                    await store.record_episode(episode)
                    return None

                # 3. Run tests before acting
                test_before = await _run_tests(config)
                episode.test_result_before = test_before

                # 4. Load knowledge context
                situation = f"{event.type}: {', '.join(event.file_paths)}"
                context = await store.get_relevant_context(situation)
                _log.info(
                    "knowledge_loaded",
                    extra={
                        "extra": {
                            "project": event.project_name,
                            "rule_count": len(context.rules),
                            "episode_count": len(context.similar_episodes),
                            "has_conflicts": context.has_conflicts,
                        }
                    },
                )

                # 5. Task agent plans
                plan = await task_agent.plan(event, triage, context, test_before)
                _log.info(
                    "plan_produced",
                    extra={
                        "extra": {
                            "project": event.project_name,
                            "action_count": len(plan.get("actions", [])),
                            "severity": plan.get("severity"),
                            "confidence": plan.get("confidence"),
                        }
                    },
                )

                return PlanResult(
                    plan=plan,
                    episode=episode,
                    triage=triage,
                    context=context,
                    test_before=test_before,
                    store=store,
                    budget=budget,
                    task_agent=task_agent,
                    meta_agent=meta_agent,
                )

            except BudgetExceededError as exc:
                _log.warning("budget_exceeded", extra={
                    "project": event.project_name, "error": str(exc)
                })
                episode.error_message = str(exc)
                await store.record_episode(episode)
                return None

            except Exception as exc:
                _log.error("plan_phase_error", extra={
                    "project": event.project_name, "error": str(exc)
                })
                episode.error_message = str(exc)
                await store.record_episode(episode)
                return None

    async def _execute_phase(
        self,
        event: AgentEvent,
        plan: dict[str, Any],
        episode: Episode,
        triage: TriageResult,
        context: KnowledgeContext,
        test_before: str | None,
        store: KnowledgeStore,
        budget: BudgetManager,
        meta_agent: MetaAgent,
        config: ProjectConfig,
    ) -> None:
        """Execute plan, reflect, and update knowledge. Held under semaphore."""
        # Dry-run: log plan and skip execution
        if event.extra.get("dry_run"):
            _log.info(
                "dry_run_plan",
                extra={
                    "extra": {
                        "project": event.project_name,
                        "plan": plan,
                    }
                },
            )
            episode.status = "skipped"
            episode.error_message = "dry_run"
            await store.record_episode(episode)
            return

        try:
            # 6. Execute plan with retry
            _t0 = time.monotonic()
            result = await _execute_with_retry(plan, config, test_before, config.runner)
            duration_ms = int((time.monotonic() - _t0) * 1000)

            # 7. Build episode
            episode.rules_applied = json.dumps(plan.get("rules_applied", []))
            episode.actions_taken = json.dumps(result.actions_taken)
            episode.files_modified = json.dumps(result.files_modified)
            episode.test_result_after = result.test_result
            episode.regression_detected = int(
                detect_regression(test_before, result.test_result)
            )
            episode.severity = triage.severity
            episode.status = "completed"

            _log.info(
                "execution_complete",
                extra={
                    "extra": {
                        "project": event.project_name,
                        "files_modified": result.files_modified,
                        "test_result": result.test_result,
                        "duration_ms": duration_ms,
                    }
                },
            )

            # 8. Meta agent reflects
            reflection = await meta_agent.reflect(event, triage, plan, result, episode)

            # 9. Update knowledge
            episode.lesson_extracted = reflection.get("lesson")
            await store.record_episode(episode)

            rule_id: str | None = None
            if reflection.get("rule"):
                r = reflection["rule"]
                raw_tags = r.get("tags")
                tags: list[str] = (
                    [str(t) for t in raw_tags] if isinstance(raw_tags, list) else []
                )
                rule = Rule(
                    trigger_pattern=str(r.get("trigger_pattern", "")),
                    lesson=str(r.get("lesson", "")),
                    confidence=float(r.get("initial_confidence", 0.3)),
                    status="unvalidated",
                    tags=tags,
                    source_episode_id=episode.id,
                    project_name=event.project_name,
                )
                rule_id = await store.write_rule(rule)
                episode.rule_generated_id = rule_id
                await store.record_episode(episode)

            _log.info(
                "meta_outcome",
                extra={
                    "extra": {
                        "project": event.project_name,
                        "outcome": reflection.get("outcome"),
                        "rule_written": rule_id,
                    }
                },
            )

            for upd in reflection.get("rule_updates", []):
                await store.update_rule_outcome(
                    str(upd.get("rule_id", "")), bool(upd.get("was_correct", False))
                )

            # 10. Webhook
            await _maybe_notify(config, episode)

        except BudgetExceededError as exc:
            _log.warning("budget_exceeded", extra={
                "project": event.project_name, "error": str(exc)
            })
            episode.error_message = str(exc)
            await store.record_episode(episode)

        except Exception as exc:
            _log.error("execute_phase_error", extra={
                "project": event.project_name, "error": str(exc)
            })
            episode.error_message = str(exc)
            await store.record_episode(episode)
