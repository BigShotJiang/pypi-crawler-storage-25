"""Sagex — self-hosted, self-learning local code agent."""

__version__ = "0.2.4"
