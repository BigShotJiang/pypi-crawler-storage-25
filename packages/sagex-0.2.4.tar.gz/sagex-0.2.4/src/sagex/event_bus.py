"""Event bus: typed agent events + persistent async queue.

Events are published onto an in-memory asyncio.Queue and immediately
persisted to the SQLite ``event_queue`` table (migration 005).  On server
restart, ``reload_persisted_events`` replays any unprocessed rows so no
event is lost.
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _short_uuid() -> str:
    return uuid.uuid4().hex[:8]


# ---------------------------------------------------------------------------
# Event schema
# ---------------------------------------------------------------------------

class EventType(StrEnum):
    FILE_MODIFIED = "file_modified"
    FILE_DELETED = "file_deleted"
    FILE_CREATED = "file_created"
    GIT_COMMIT = "git_commit"
    TEST_FAILURE = "test_failure"
    CI_LOG = "ci_log"
    MANUAL = "manual"


@dataclass
class AgentEvent:
    type: EventType
    project_name: str
    repo_root: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))
    file_paths: list[str] = field(default_factory=list)
    diff: str | None = None
    diff_context: str | None = None
    test_output: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: f"evt_{_short_uuid()}")

    def __post_init__(self) -> None:
        """Coerce string fields back to their proper types after JSON round-trip."""
        if isinstance(self.type, str):
            self.type = EventType(self.type)
        if isinstance(self.timestamp, str):
            self.timestamp = datetime.fromisoformat(self.timestamp)


# ---------------------------------------------------------------------------
# EventBus
# ---------------------------------------------------------------------------

class EventBus:
    """Persistent async queue for ``AgentEvent`` objects.

    Parameters
    ----------
    db:
        Live ``RulesDB`` instance — used to persist and reload events.
    max_size:
        Maximum in-memory queue depth.  Publish calls that exceed this limit
        log a warning and drop the event rather than blocking or raising.
    """

    def __init__(self, db: Any, max_size: int = 100) -> None:
        self._queue: asyncio.Queue[AgentEvent] = asyncio.Queue(maxsize=max_size)
        self._db = db
        # Loop is attached explicitly via attach_loop() once asyncio.run() starts.
        # publish_sync (called from watchdog threads) uses this loop.
        self._loop: asyncio.AbstractEventLoop | None = None

    def attach_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        """Attach the running event loop so publish_sync can schedule from threads.

        Call this inside the async main coroutine (after asyncio.run() starts)
        so that get_running_loop() is guaranteed to succeed.
        """
        self._loop = loop

    async def publish(self, event: AgentEvent) -> bool:
        """Enqueue *event* and persist it to SQLite.

        Returns ``False`` (and logs a warning) when the queue is full so the
        caller can handle back-pressure without an exception.
        """
        try:
            self._queue.put_nowait(event)
        except asyncio.QueueFull:
            _log.warning(
                "event_dropped",
                extra={"event_id": event.id, "project": event.project_name},
            )
            return False
        await self._db.persist_event(event)
        return True

    async def subscribe(self) -> AgentEvent:
        """Block until an event is available; mark it as processing in SQLite."""
        event = await self._queue.get()
        await self._db.mark_event_processing(event.id)
        return event

    async def mark_event_done(self, event_id: str) -> None:
        """Mark an event as done in SQLite so it is not replayed on restart."""
        await self._db.mark_event_done(event_id)

    def publish_sync(self, event: AgentEvent) -> None:
        """Thread-safe publish for use from watchdog callbacks (non-async threads).

        Schedules ``publish`` on the loop captured at construction time.
        If no loop was captured (EventBus built outside any async context),
        the event is dropped with a warning rather than raising.
        """
        loop = self._loop
        if loop is None or not loop.is_running():
            _log.warning(
                "publish_sync called with no running event loop",
                extra={"event_id": event.id},
            )
            return
        asyncio.run_coroutine_threadsafe(self.publish(event), loop)

    def reload_persisted_events(self) -> int:
        """On startup, reload events that were in-flight when the server last stopped.

        Returns the number of events reloaded.
        """
        events: list[Any] = self._db.get_unprocessed_events()
        count = 0
        for event in events:
            try:
                self._queue.put_nowait(event)
                count += 1
            except asyncio.QueueFull:
                _log.warning("queue_full_on_reload", extra={"event_id": event.id})
                break
        return count
