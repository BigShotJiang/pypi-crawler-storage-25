"""BaseAgent — shared scaffolding for all Sagex agents.

Every agent subclasses BaseAgent and calls ``await self.budget_call(...)`` or
``await self.budget_call_json(...)`` rather than touching ``BudgetManager``
directly.  This indirection keeps the system prompt and model selection in the
agent while routing all API calls through the budget/cache/tracker pipeline.
"""

from __future__ import annotations

from sagex.config import AgentConfig
from sagex.llm.budget import BudgetManager


class BaseAgent:
    """Mixin providing budget-aware LLM calls for all agent subclasses.

    Parameters
    ----------
    config:
        Agent-level configuration (model name, max_tokens, temperature…).
    budget:
        Shared ``BudgetManager`` instance — the single entry point for all
        Anthropic API calls.
    """

    def __init__(self, config: AgentConfig, budget: BudgetManager) -> None:
        self._config = config
        self._budget = budget

    async def budget_call(
        self,
        project: str,
        agent_type: str,
        system: str,
        user: str,
        model: str | None = None,
        max_tokens: int | None = None,
    ) -> str:
        """Delegate to ``BudgetManager.call`` using this agent's defaults."""
        return await self._budget.call(
            project=project,
            agent_type=agent_type,
            system=system,
            user=user,
            model=model or self._config.model,
            max_tokens=max_tokens if max_tokens is not None else self._config.max_tokens,
            temperature=self._config.temperature,
        )

    async def budget_call_json(
        self,
        project: str,
        agent_type: str,
        system: str,
        user: str,
        model: str | None = None,
        max_tokens: int | None = None,
    ) -> dict[str, object]:
        """Delegate to ``BudgetManager.call_json`` using this agent's defaults."""
        return await self._budget.call_json(
            project=project,
            agent_type=agent_type,
            system=system,
            user=user,
            model=model or self._config.model,
            max_tokens=max_tokens if max_tokens is not None else self._config.max_tokens,
            temperature=self._config.temperature,
        )
