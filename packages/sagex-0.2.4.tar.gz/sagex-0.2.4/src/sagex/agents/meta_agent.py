"""Meta agent: reflects on task agent outcomes and extracts rules.

The meta agent is the reflector half of the observe-act-reflect loop.
It receives the full episode context (event, triage, plan, execution result)
and returns a structured JSON with:
- An outcome assessment (good / partial / bad)
- An optional lesson
- An optional new Rule to persist
- Rule correctness updates for rules that were applied
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from sagex.agents.base import BaseAgent
from sagex.config import AgentConfig
from sagex.event_bus import AgentEvent
from sagex.knowledge.rules_db import Episode, Rule
from sagex.llm.budget import BudgetManager

if TYPE_CHECKING:
    from sagex.agents.task_agent import ExecutionResult
    from sagex.agents.triage_agent import TriageResult


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

META_AGENT_SYSTEM = """\
You are a meta agent. You reflect on what a task agent just did and extract lessons.

You receive:
- The original event
- The triage classification
- The task agent's action plan
- The execution result (what actually happened, errors)
- Test results before and after
- Whether a regression was detected

Your job:
1. Determine if the outcome was good, partial, or bad.
2. Extract one specific, actionable lesson if something went wrong or could improve.
3. If a lesson is valuable, produce a rule. Good rules are:
   - Specific: name file patterns or module types
   - Actionable: say what TO DO, not just what to avoid
   - Concise: under 100 words
   - Tagged: choose 1-3 tags from: security, auth, testing, dead-code,
     config, dependency, compliance, refactor, performance
4. If existing rules were used, mark each as correct or incorrect.

Return ONLY valid JSON. No prose outside the JSON. Schema:
{
  "outcome": "good|partial|bad",
  "outcome_reason": "one sentence",
  "lesson": "specific lesson or null",
  "rule": {
    "trigger_pattern": "when to apply",
    "lesson": "what to do",
    "tags": ["tag1"],
    "initial_confidence": 0.3
  },
  "rule_updates": [
    {"rule_id": "...", "was_correct": true}
  ]
}\
"""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def detect_regression(before: str | None, after: str | None) -> bool:
    """Return True when tests passed before and fail after (regression)."""
    return before == "pass" and after == "fail"


def _build_user_prompt(
    event: AgentEvent,
    triage: TriageResult,
    plan: dict[str, Any],
    result: ExecutionResult,
    episode: Episode,
) -> str:
    return (
        f"<event>\n"
        f"type: {event.type}, severity: {triage.severity}\n"
        f"files: {event.file_paths}\n"
        f"</event>\n\n"
        f"<action_plan>\n{json.dumps(plan, indent=2)}\n</action_plan>\n\n"
        f"<execution_result>\n"
        f"actions_taken: {result.actions_taken}\n"
        f"files_modified: {result.files_modified}\n"
        f"errors: {result.errors}\n"
        f"skipped: {result.skipped} ({result.skip_reason})\n"
        f"</execution_result>\n\n"
        f"<test_results>\n"
        f"before: {episode.test_result_before}\n"
        f"after: {episode.test_result_after}\n"
        f"regression_detected: {episode.regression_detected}\n"
        f"</test_results>"
    )


def _parse_rule(raw: dict[str, Any] | None, project_name: str) -> Rule | None:
    """Convert a raw rule dict from meta agent JSON into a ``Rule`` dataclass."""
    if not raw:
        return None
    trigger = str(raw.get("trigger_pattern", ""))
    lesson = str(raw.get("lesson", ""))
    if not trigger or not lesson:
        return None
    raw_tags = raw.get("tags")
    tags: list[str] = [str(t) for t in raw_tags] if isinstance(raw_tags, list) else []
    confidence = float(raw.get("initial_confidence", 0.3))
    return Rule(
        trigger_pattern=trigger,
        lesson=lesson,
        project_name=project_name,
        confidence=confidence,
        tags=tags,
    )


# ---------------------------------------------------------------------------
# MetaAgent
# ---------------------------------------------------------------------------

class MetaAgent(BaseAgent):
    """Reflector: analyses episode outcomes and writes new knowledge rules."""

    def __init__(self, config: AgentConfig, budget: BudgetManager) -> None:
        super().__init__(config, budget)

    async def reflect(
        self,
        event: AgentEvent,
        triage: TriageResult,
        plan: dict[str, Any],
        result: ExecutionResult,
        episode: Episode,
        budget: BudgetManager | None = None,
    ) -> dict[str, Any]:
        """Return a structured reflection JSON for the completed episode."""
        user_prompt = _build_user_prompt(event, triage, plan, result, episode)
        return await self.budget_call_json(
            project=event.project_name,
            agent_type="meta",
            system=META_AGENT_SYSTEM,
            user=user_prompt,
            model=self._config.model,
            max_tokens=self._config.meta_max_tokens,
        )

    def parse_rule(
        self, reflection: dict[str, Any], project_name: str
    ) -> Rule | None:
        """Extract a ``Rule`` from a reflection dict, or ``None`` if absent."""
        return _parse_rule(reflection.get("rule"), project_name)
