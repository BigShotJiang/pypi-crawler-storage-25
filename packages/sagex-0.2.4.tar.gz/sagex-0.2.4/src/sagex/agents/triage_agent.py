"""Triage agent: fast pre-filter before expensive task agent calls.

Architecture
------------
Event received
      │
      ▼
rule_based_triage()    ← 0 tokens, instant
      │
      ├── skip / low      → TriageResult(used_llm=False)
      ├── high / critical → TriageResult(used_llm=False)
      │
      └── None (inconclusive)
              │
              ▼
        Haiku LLM call (~150 tokens)
              │
              ├── skip / low      → TriageResult(used_llm=True)
              ├── medium          → task agent with Haiku
              └── high / critical → task agent with Sonnet
"""

from __future__ import annotations

import fnmatch
from dataclasses import dataclass

from sagex.agents.base import BaseAgent
from sagex.config import AgentConfig
from sagex.event_bus import AgentEvent
from sagex.llm.budget import BudgetManager

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SKIP_EXTENSIONS: frozenset[str] = frozenset(
    # NOTE: .txt is intentionally NOT included — it would skip requirements.txt,
    # constraints.txt, and other dependency / security-sensitive files.
    {".log", ".lock", ".pyc", ".map", ".min.js", ".md", ".rst"}
)
SKIP_PATTERNS: list[str] = [
    "**/__pycache__/**",
    "**/node_modules/**",
    "**/.git/**",
    "**/dist/**",
    "**/build/**",
    "**/out/**",
    "**/.next/**",
    "**/.cache/**",
    "**/coverage/**",
    "**/htmlcov/**",
    "**/*.egg-info/**",
]
SECURITY_PATHS: list[str] = [
    ".env",
    "secret",
    "credential",
    "private_key",
    "Dockerfile",
]
TEST_INDICATORS: list[str] = [
    "test_",
    "_test.py",
    "spec.",
    ".test.ts",
]

TRIAGE_SYSTEM = """You are a code change classifier. Given a list of changed \
files and a short diff summary, return a single JSON object:
{"severity": "skip|low|medium|high|critical", "reason": "one sentence"}

Severity guide:
- skip: whitespace, comments, lock files, auto-generated files
- low: minor changes unlikely to affect behaviour
- medium: logic changes, config edits
- high: auth, security, API contracts, breaking changes
- critical: secrets exposed, security vulnerabilities, data loss risk
Return ONLY the JSON. No prose."""


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class TriageResult:
    severity: str    # skip | low | medium | high | critical
    reason: str
    used_llm: bool
    tokens_used: int = 0


# ---------------------------------------------------------------------------
# Rule-based classifier helpers
# ---------------------------------------------------------------------------

def _matches_skip_extension(path: str) -> bool:
    """True when *path* ends with any extension in ``SKIP_EXTENSIONS``.

    Uses ``endswith`` (not "last `.` suffix") so multi-part extensions like
    ``.min.js`` and ``.bundle.js.map`` match correctly.
    """
    lowered = path.lower()
    return any(lowered.endswith(ext) for ext in SKIP_EXTENSIONS)


def _matches_skip_pattern(path: str) -> bool:
    """True when *path* matches any glob in ``SKIP_PATTERNS``.

    Normalises the path with a leading ``/`` before matching so root-relative
    inputs like ``"dist/app.js"`` correctly match patterns like ``"**/dist/**"``
    (which fnmatch expands to a regex requiring at least one preceding char).
    """
    normalised = path if path.startswith("/") else "/" + path
    return any(fnmatch.fnmatch(normalised, pat) for pat in SKIP_PATTERNS)


def _is_whitespace_only_diff(diff: str) -> bool:
    """Return True for diffs that change only whitespace.

    Two cases qualify:
    1. Every added/removed line is blank after stripping (pure blank-line edits).
    2. The stripped sequence of removed lines equals the stripped sequence of
       added lines — catches trailing-whitespace cleanup, tab→space conversion,
       indent normalization, and similar formatter-only changes.
    """
    removed: list[str] = []
    added: list[str] = []
    has_change = False
    all_blank = True
    for line in diff.splitlines():
        if line.startswith("---") or line.startswith("+++"):
            continue  # file headers
        if line.startswith("-"):
            has_change = True
            stripped = line[1:].strip()
            if stripped:
                all_blank = False
            removed.append(stripped)
        elif line.startswith("+"):
            has_change = True
            stripped = line[1:].strip()
            if stripped:
                all_blank = False
            added.append(stripped)
    if not has_change:
        return False
    if all_blank:
        return True
    return removed == added


def rule_based_triage(event: AgentEvent) -> str | None:
    """Classify the event using only heuristics — no LLM call.

    Returns a severity string (``"skip"``, ``"low"``, ``"medium"``,
    ``"high"``, or ``"critical"``) or ``None`` when the result is
    inconclusive and a Haiku call is needed.
    """
    paths = event.file_paths
    diff = event.diff or ""

    # All paths match skip patterns → skip
    if paths and all(_matches_skip_pattern(p) for p in paths):
        return "skip"

    # All paths have skip extensions → skip
    if paths and all(_matches_skip_extension(p) for p in paths):
        return "skip"

    # Whitespace-only diff → skip
    if diff and _is_whitespace_only_diff(diff):
        return "skip"

    # Security-sensitive path touched → high minimum
    if any(
        any(sec in p for sec in SECURITY_PATHS)
        for p in paths
    ):
        return "high"

    # Test file touched → medium minimum
    if any(
        any(ind in p for ind in TEST_INDICATORS)
        for p in paths
    ):
        return "medium"

    # Tiny diff with no other signals → low
    changed_lines = [
        line for line in diff.splitlines()
        if line.startswith(("+", "-")) and not line.startswith(("+++", "---"))
    ]
    if len(changed_lines) < 5:
        return "low"

    # Inconclusive — let Haiku decide
    return None


# ---------------------------------------------------------------------------
# TriageAgent
# ---------------------------------------------------------------------------

class TriageAgent(BaseAgent):
    """Classifies an AgentEvent as skip / low / medium / high / critical.

    Tries the rule-based classifier first (0 tokens).  Falls back to a
    fast Haiku LLM call only when the result is inconclusive.
    """

    def __init__(self, config: AgentConfig, budget: BudgetManager) -> None:
        super().__init__(config, budget)

    async def classify(self, event: AgentEvent) -> TriageResult:
        """Return a ``TriageResult`` for *event*."""
        severity = rule_based_triage(event)
        if severity is not None:
            return TriageResult(
                severity=severity,
                reason="rule-based classification",
                used_llm=False,
                tokens_used=0,
            )

        # Inconclusive → Haiku LLM call
        diff_summary = (event.diff or "")[:1000]
        user_prompt = (
            f"Changed files: {event.file_paths}\n\n"
            f"Diff (truncated to 1000 chars):\n{diff_summary}"
        )
        result = await self.budget_call_json(
            project=event.project_name,
            agent_type="triage",
            system=TRIAGE_SYSTEM,
            user=user_prompt,
            model=self._config.triage_model,
            max_tokens=self._config.triage_max_tokens,
        )
        return TriageResult(
            severity=str(result.get("severity", "low")),
            reason=str(result.get("reason", "")),
            used_llm=True,
            tokens_used=0,  # approximate — tracked in token_usage table
        )
