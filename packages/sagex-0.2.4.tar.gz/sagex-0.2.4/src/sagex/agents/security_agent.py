"""Security agent: pattern-based pre-check + LLM-backed remediation.

Runs as a pre-check on security-sensitive paths before the task agent.

Pipeline
--------
1. ``classify_security_risk(diff, file_path)`` — zero-token regex scan.
2. ``SecurityAgent.audit(event, diff, config)`` — LLM-backed deep audit
   (only called when auto_remediate=True or caller wants a full report).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from sagex.agents.base import BaseAgent
from sagex.config import AgentConfig, SecurityAgentConfig
from sagex.llm.budget import BudgetManager

if TYPE_CHECKING:
    from sagex.event_bus import AgentEvent


# ---------------------------------------------------------------------------
# Pattern classifier
# ---------------------------------------------------------------------------

SECURITY_PATTERNS: list[tuple[str, str, str]] = [
    # (regex, severity, description)
    (
        r"(?i)(password|secret|api_key|token)\s*=\s*['\"][^'\"]{8,}['\"]",
        "critical",
        "Hardcoded credential detected",
    ),
    (
        r"(?i)-----BEGIN (RSA |EC |DSA )?PRIVATE KEY-----",
        "critical",
        "Private key in source",
    ),
    (
        r"(?i)(AWS_ACCESS_KEY_ID|AWS_SECRET_ACCESS_KEY)\s*=\s*['\"]?[A-Za-z0-9/+]{16,}['\"]?",
        "critical",
        "AWS credential exposed",
    ),
    (
        r"(?i)debug\s*=\s*true",
        "high",
        "Debug mode enabled in config",
    ),
    (
        r"(?i)verify\s*=\s*false",
        "high",
        "TLS verification disabled",
    ),
    (
        r"(?i)http://(?!localhost|127\.0\.0\.1)",
        "medium",
        "Non-HTTPS URL in non-local code",
    ),
]

_SEVERITY_RANK: dict[str, int] = {
    "medium": 1,
    "high": 2,
    "critical": 3,
}


@dataclass
class SecurityRisk:
    severity: str
    pattern_matched: str
    description: str
    line_numbers: list[int] = field(default_factory=list)
    file_path: str = ""


def classify_security_risk(diff: str, file_path: str) -> SecurityRisk | None:
    """Scan diff lines for known risk patterns.

    Only examines added lines (those starting with ``+`` but not ``+++``).
    Returns the highest-severity risk found, or ``None`` when the diff is clean.
    """
    worst: SecurityRisk | None = None

    for lineno, line in enumerate(diff.splitlines(), start=1):
        if not line.startswith("+") or line.startswith("+++"):
            continue
        content = line[1:]  # strip the leading '+'
        for pattern, severity, description in SECURITY_PATTERNS:
            if re.search(pattern, content):
                candidate = SecurityRisk(
                    severity=severity,
                    pattern_matched=pattern,
                    description=description,
                    line_numbers=[lineno],
                    file_path=file_path,
                )
                if worst is None or (
                    _SEVERITY_RANK.get(severity, 0) > _SEVERITY_RANK.get(worst.severity, 0)
                ):
                    worst = candidate
                    break  # use first match per line, then move on

    return worst


# ---------------------------------------------------------------------------
# Security agent system prompt
# ---------------------------------------------------------------------------

SECURITY_AGENT_SYSTEM = """\
You are a security and compliance agent. Your job:
1. Detect secrets, credentials, or sensitive data in the codebase.
2. Detect dependency vulnerabilities (outdated packages with known CVEs).
3. Detect configuration regressions (debug on, TLS off, insecure URLs).
4. Never remove or modify files without explicit confirmation unless
   auto_remediate is enabled.

When you find a risk, produce a structured JSON report.
When auto_remediate is true, also include an action plan to remediate.
Return ONLY valid JSON.\
"""


# ---------------------------------------------------------------------------
# SecurityAgent
# ---------------------------------------------------------------------------

class SecurityAgent(BaseAgent):
    """Security and compliance specialist."""

    def __init__(
        self,
        config: AgentConfig,
        budget: BudgetManager,
        security_config: SecurityAgentConfig | None = None,
    ) -> None:
        super().__init__(config, budget)
        self._security_config = security_config or SecurityAgentConfig()

    async def audit(
        self,
        event: AgentEvent,
        diff: str,
        risk: SecurityRisk,
    ) -> dict[str, Any]:
        """Return a structured JSON audit report for *risk*.

        When ``auto_remediate=True``, the JSON will include a ``remediation``
        action plan.  When ``False``, it contains only a report.
        """
        auto_remediate = self._security_config.auto_remediate
        user_prompt = (
            f"<event>\n"
            f"files: {event.file_paths}\n"
            f"project: {event.project_name}\n"
            f"</event>\n\n"
            f"<security_risk>\n"
            f"severity: {risk.severity}\n"
            f"description: {risk.description}\n"
            f"file: {risk.file_path}\n"
            f"lines: {risk.line_numbers}\n"
            f"</security_risk>\n\n"
            f"<diff>\n{diff[:4000]}\n</diff>\n\n"
            f"auto_remediate: {auto_remediate}\n\n"
            "Return JSON:\n"
            "{\n"
            '  "severity": "critical|high|medium",\n'
            '  "description": "one sentence",\n'
            '  "file_path": "path",\n'
            '  "remediation": null\n'
            "}"
        )
        return await self.budget_call_json(
            project=event.project_name,
            agent_type="security",
            system=SECURITY_AGENT_SYSTEM,
            user=user_prompt,
            model=self._config.model,
            max_tokens=self._config.security_max_tokens,
        )
