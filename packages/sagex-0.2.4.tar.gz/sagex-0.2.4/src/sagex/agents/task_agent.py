"""Task agent: plans actions based on change context and knowledge store.

Responsibilities
----------------
1. Pre-process the diff (summarise via Haiku if too large).
2. Build a rich user prompt from event, triage result, and knowledge context.
3. Call Sonnet via the budget layer to get a structured JSON action plan.
4. Provide ActionExecutor to carry out the plan and capture results.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from sagex.agents.base import BaseAgent
from sagex.config import AgentConfig, KnowledgeConfig, ProjectConfig
from sagex.event_bus import AgentEvent
from sagex.knowledge.rules_db import Rule
from sagex.llm.budget import BudgetManager

if TYPE_CHECKING:
    from sagex.agents.triage_agent import TriageResult
    from sagex.knowledge.store import KnowledgeContext


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_SUMMARISE_THRESHOLD_CHARS = 6000
_TEST_OUTPUT_TAIL_CHARS = 1500

TASK_AGENT_SYSTEM = """\
You are a task agent responsible for making targeted, safe improvements to a codebase.

You receive:
- An event describing what changed (type, affected files)
- The git diff with ±30 lines of surrounding context per hunk
- Test output before the change (if available; may be truncated to the last 1500 chars)
- Rules from past experience (learn from these; unvalidated rules are suggestions only)
- Semantically similar past episodes (use as additional context)
- A conflict note if any rules contradict each other

Your job is to analyse the situation and produce a structured action plan.
You do NOT execute changes directly. You return a JSON plan only.

Before producing the plan, always verify:
1. Will any of my actions introduce a regression?
2. Is there dead code left behind after this change?
3. Do tests need to be added or updated to cover the change?
4. Do any security or compliance files also need updating?
5. Are there conflicting rules? If so, use your judgment for this specific situation.

Return ONLY valid JSON. No prose outside the JSON. Schema:
{
  "summary": "one sentence",
  "severity": "low|medium|high|critical",
  "actions": [
    {
      "type": "edit_file|delete_file|run_command|create_file",
      "target": "path/to/file or shell command",
      "description": "what and why",
      "content": "full file content for edit_file/create_file"
    }
  ],
  "checks_required": ["verification steps"],
  "rules_applied": ["rule_id_1"],
  "confidence": 0.0,
  "skip_reason": null
}\
"""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def _preprocess_diff(
    diff_context: str | None,
    event: AgentEvent,
    budget: BudgetManager,
    summariser_max_tokens: int = 512,
) -> str:
    """Summarise the diff with Haiku when it exceeds the context threshold.

    Returns the original *diff_context* when under the threshold, or a
    Haiku-generated summary when it is too large for the task agent prompt.
    """
    if not diff_context or len(diff_context) <= _SUMMARISE_THRESHOLD_CHARS:
        return diff_context or "no diff available"

    summary = await budget.call(
        project=event.project_name,
        agent_type="diff_summariser",
        system=(
            "Summarise this code diff in under 400 words. "
            "Preserve all file names, function names, class names, and line numbers. "
            "Focus on what changed semantically, not line-by-line."
        ),
        user=diff_context,
        model="claude-haiku-4-5",
        max_tokens=summariser_max_tokens,
    )
    return f"[DIFF SUMMARISED — original was {len(diff_context)} chars]\n\n{summary}"


def _truncate(text: str, max_chars: int) -> str:
    if max_chars <= 0 or len(text) <= max_chars:
        return text
    return text[: max_chars - 1].rstrip() + "…"


def _truncate_test_output(text: str | None, tail_chars: int = _TEST_OUTPUT_TAIL_CHARS) -> str:
    """Keep the last *tail_chars* of test output; the failure summary lives at the end.

    Pytest emits collection lines, deprecation warnings, and dot-progress at the
    top — only the tail (failure traceback / summary line) is useful to the agent.
    """
    if not text:
        return "not available"
    if len(text) <= tail_chars:
        return text
    return f"[truncated — showing last {tail_chars} chars]\n…\n{text[-tail_chars:]}"


def _format_rules(rules: list[Rule], max_chars_per_rule: int) -> str:
    if not rules:
        return "No rules available."
    parts: list[str] = []
    for r in rules:
        trigger = _truncate(r.trigger_pattern, max_chars_per_rule)
        lesson = _truncate(r.lesson, max_chars_per_rule)
        parts.append(
            f"Rule {r.id} (confidence={r.confidence:.2f}, status={r.status}):\n"
            f"  Trigger: {trigger}\n"
            f"  Lesson: {lesson}"
        )
    return "\n\n".join(parts)


def _format_episodes(
    episodes: list[dict[str, Any]],
    limit: int,
    max_chars_per_episode: int,
) -> str:
    if not episodes:
        return "No similar episodes."
    parts: list[str] = []
    for ep in episodes[:limit]:
        doc = _truncate(
            str(ep.get("text") or ep.get("document", "")),
            max_chars_per_episode,
        )
        parts.append(f"- {doc}")
    return "\n".join(parts)


def _build_user_prompt(
    event: AgentEvent,
    triage_result: TriageResult,
    context: KnowledgeContext,
    diff_text: str,
    test_output_before: str | None,
    knowledge_config: KnowledgeConfig,
) -> str:
    conflict_section = (
        f"<conflict_note>{context.conflict_note}</conflict_note>\n\n"
        if context.has_conflicts
        else ""
    )
    rules_block = _format_rules(context.rules, knowledge_config.max_rule_chars)
    episodes_block = _format_episodes(
        context.similar_episodes,
        knowledge_config.max_episodes_in_context,
        knowledge_config.max_episode_chars,
    )
    return (
        f"<event>\n"
        f"type: {event.type}\n"
        f"files: {event.file_paths}\n"
        f"triage_severity: {triage_result.severity}\n"
        f"triage_reason: {triage_result.reason}\n"
        f"</event>\n\n"
        f"<diff_with_context>\n{diff_text}\n</diff_with_context>\n\n"
        f"<test_output_before>\n{_truncate_test_output(test_output_before)}\n</test_output_before>\n\n"
        f"<rules>\n{rules_block}\n</rules>\n\n"
        f"{conflict_section}"
        f"<similar_episodes>\n{episodes_block}\n</similar_episodes>"
    )


# ---------------------------------------------------------------------------
# TaskAgent
# ---------------------------------------------------------------------------

class TaskAgent(BaseAgent):
    """Actor: turns a triage result + knowledge context into an action plan."""

    def __init__(
        self,
        config: AgentConfig,
        budget: BudgetManager,
        knowledge_config: KnowledgeConfig | None = None,
    ) -> None:
        super().__init__(config, budget)
        self._knowledge_config = knowledge_config or KnowledgeConfig()

    async def plan(
        self,
        event: AgentEvent,
        triage_result: TriageResult,
        context: KnowledgeContext,
        test_output_before: str | None = None,
    ) -> dict[str, Any]:
        """Return a structured JSON action plan for *event*."""
        diff_text = await _preprocess_diff(
            event.diff_context,
            event,
            self._budget,
            summariser_max_tokens=self._config.summariser_max_tokens,
        )
        user_prompt = _build_user_prompt(
            event,
            triage_result,
            context,
            diff_text,
            test_output_before,
            self._knowledge_config,
        )
        return await self.budget_call_json(
            project=event.project_name,
            agent_type="task",
            system=TASK_AGENT_SYSTEM,
            user=user_prompt,
            model=self._config.model,
        )


# ---------------------------------------------------------------------------
# ExecutionResult
# ---------------------------------------------------------------------------

@dataclass
class ExecutionResult:
    actions_taken: list[str] = field(default_factory=list)
    files_modified: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    test_result: str | None = None   # "pass" | "fail" | None
    test_output: str | None = None
    skipped: bool = False
    skip_reason: str | None = None


# ---------------------------------------------------------------------------
# ActionExecutor
# ---------------------------------------------------------------------------

class ActionExecutor:
    """Executes the action plan produced by TaskAgent.plan()."""

    async def execute(
        self,
        plan: dict[str, Any],
        config: ProjectConfig,
        test_output_before: str | None = None,
    ) -> ExecutionResult:
        """Carry out all actions in *plan* and return the execution result.

        Async: subprocess calls go through ``asyncio.create_subprocess_exec``
        so a 60-second command doesn't block the entire event loop.  The
        runner's ``Semaphore(3)`` caps active computation but only works
        if the compute doesn't monopolise the single event-loop thread —
        before this change a long-running test run stalled the approval
        poller and every HTTP handler on the process (issue #8).

        If ``plan["skip_reason"]`` is set, returns immediately with
        ``skipped=True`` without touching the filesystem.
        """
        result = ExecutionResult()

        # Short-circuit if the task agent decided to skip
        skip_reason = plan.get("skip_reason")
        if skip_reason:
            result.skipped = True
            result.skip_reason = str(skip_reason)
            return result

        actions: list[dict[str, Any]] = plan.get("actions", [])
        for action in actions:
            action_type = str(action.get("type", ""))
            target = str(action.get("target", ""))
            description = str(action.get("description", ""))

            try:
                if action_type in ("edit_file", "create_file"):
                    content = str(action.get("content", ""))
                    file_path = Path(target)
                    if not file_path.is_absolute():
                        file_path = Path(config.repo_root) / file_path
                    try:
                        file_path.resolve().relative_to(Path(config.repo_root).resolve())
                    except ValueError:
                        result.errors.append(
                            f"Path traversal blocked: {target!r} escapes repo_root"
                        )
                        continue
                    file_path.parent.mkdir(parents=True, exist_ok=True)
                    file_path.write_text(content)
                    result.actions_taken.append(f"{action_type}: {target} — {description}")
                    result.files_modified.append(str(file_path))

                elif action_type == "delete_file":
                    file_path = Path(target)
                    if not file_path.is_absolute():
                        file_path = Path(config.repo_root) / file_path
                    try:
                        file_path.resolve().relative_to(Path(config.repo_root).resolve())
                    except ValueError:
                        result.errors.append(
                            f"Path traversal blocked: {target!r} escapes repo_root"
                        )
                        continue
                    if file_path.exists():
                        file_path.unlink()
                    result.actions_taken.append(f"delete_file: {target} — {description}")
                    result.files_modified.append(str(file_path))

                elif action_type == "run_command":
                    if not config.runner.require_approval:
                        result.errors.append(
                            f"run_command skipped: require_approval must be enabled "
                            f"before the agent may execute shell commands (target={target!r})"
                        )
                    else:
                        import shlex

                        proc = await asyncio.create_subprocess_exec(
                            *shlex.split(target),
                            cwd=config.repo_root,
                            stdout=asyncio.subprocess.PIPE,
                            stderr=asyncio.subprocess.PIPE,
                        )
                        try:
                            _stdout_b, stderr_b = await asyncio.wait_for(
                                proc.communicate(), timeout=60
                            )
                        except TimeoutError:
                            proc.kill()
                            try:
                                await proc.wait()
                            except Exception:  # noqa: BLE001
                                pass
                            result.errors.append(
                                f"Command timed out after 60s: {target!r}"
                            )
                            continue
                        result.actions_taken.append(
                            f"run_command: {target} (exit={proc.returncode})"
                        )
                        if proc.returncode != 0:
                            stderr_txt = stderr_b.decode(errors="replace")
                            result.errors.append(
                                f"Command failed (exit {proc.returncode}): {stderr_txt[:500]}"
                            )
                else:
                    result.errors.append(f"Unknown action type: {action_type}")

            except Exception as exc:
                result.errors.append(f"Error executing {action_type} on {target}: {exc}")

        # Run the project test suite — async subprocess so a long test run
        # doesn't stall the whole event loop.
        try:
            test_proc = await asyncio.create_subprocess_shell(
                config.test.command,
                cwd=config.test.working_dir or config.repo_root,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            try:
                stdout_b, stderr_b = await asyncio.wait_for(
                    test_proc.communicate(),
                    timeout=config.test.timeout_seconds,
                )
            except TimeoutError:
                test_proc.kill()
                try:
                    await test_proc.wait()
                except Exception:  # noqa: BLE001
                    pass
                result.test_result = "fail"
                result.test_output = "Test command timed out"
            else:
                result.test_output = (
                    stdout_b.decode(errors="replace") + stderr_b.decode(errors="replace")
                )[:4000]
                result.test_result = "pass" if test_proc.returncode == 0 else "fail"
        except Exception as exc:
            result.test_result = "fail"
            result.test_output = f"Test runner error: {exc}"

        return result
