"""Filesystem watcher: detects changes and publishes typed AgentEvents.

Uses watchdog for cross-platform filesystem events.  Changed paths are
debounced (collected for ``debounce_seconds`` then fired as one event) to
avoid flooding the bus on rapid saves.

Public surface
--------------
- ``get_git_diff``           — raw ``git diff HEAD`` output
- ``get_diff_with_context``  — diff with ±N surrounding lines, truncated to max_chars
- ``ProjectWatcher``         — single-project watcher
- ``WatcherManager``         — multi-project watcher registry
"""

from __future__ import annotations

import fnmatch
import logging
import subprocess
import threading
from time import monotonic
from typing import TYPE_CHECKING, Any

from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

from sagex.event_bus import AgentEvent, EventBus, EventType

if TYPE_CHECKING:
    from sagex.config import ProjectConfig

_log = logging.getLogger(__name__)

_TRUNCATION_MARKER = "... [truncated — {remaining} chars omitted] ..."


# ---------------------------------------------------------------------------
# Git helpers
# ---------------------------------------------------------------------------

def get_git_diff(repo_root: str, file_paths: list[str]) -> str | None:
    """Run ``git diff HEAD -- <files>`` and return stdout.

    Returns ``None`` on subprocess error or empty output.
    """
    try:
        result = subprocess.run(
            ["git", "diff", "HEAD", "--"] + file_paths,
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.stdout or None
    except Exception as exc:
        _log.debug("get_git_diff error: %s", exc)
        return None


def get_diff_with_context(
    repo_root: str,
    file_paths: list[str],
    context_lines: int = 30,
    max_chars: int = 8000,
) -> str | None:
    """Return ``git diff`` with ±``context_lines`` of surrounding code.

    If the output exceeds ``max_chars``, it is truncated with a clear marker.
    No LLM call is made here — this is raw content delivery only.
    """
    try:
        result = subprocess.run(
            ["git", "diff", f"-U{context_lines}", "HEAD", "--"] + file_paths,
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=10,
        )
        output = result.stdout
        if not output:
            return None
        if len(output) <= max_chars:
            return output
        remaining = len(output) - max_chars
        marker = _TRUNCATION_MARKER.format(remaining=remaining)
        return output[:max_chars] + "\n" + marker
    except Exception as exc:
        _log.debug("get_diff_with_context error: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Git context for hook-fired events (post-commit / pre-push)
#
# The watcher above captures *uncommitted* edits — ``git diff HEAD``.  Hook
# events have different semantics: a post-commit fires after HEAD just moved,
# so ``git diff HEAD`` is empty by definition; the right diff is what was
# *just committed* (``HEAD~1..HEAD``).  Pre-push wants every commit about to
# leave the local branch (``@{u}..HEAD``).  Without this distinction the
# notify endpoint receives ``file_paths=[]`` + ``diff=null`` and the task
# agent correctly refuses to act — which is what was happening on this repo
# (75 episodes, 0 files modified).
# ---------------------------------------------------------------------------


def _run_git(
    repo_root: str, args: list[str], timeout: int = 10
) -> str | None:
    """Run a git subcommand and return stdout, or ``None`` on any failure.

    ``check=False`` so a non-zero exit (e.g. ``HEAD~1`` doesn't exist on
    the very first commit, or ``@{u}`` has no upstream) returns gracefully
    instead of raising.  Callers branch on ``None`` to pick a fallback ref.
    """
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except Exception as exc:
        _log.debug("_run_git error: %s", exc)
        return None
    if result.returncode != 0:
        return None
    return result.stdout


def _resolve_event_range(repo_root: str, event_name: str) -> str | None:
    """Return the git ref-range that captures what happened for *event_name*.

    Examples
    --------
    ``post-commit`` → ``"HEAD~1..HEAD"`` (the commit that just landed).
        Falls back to ``None`` on the very first commit (no parent), where
        every existing-file diff would be the whole file — too noisy to be
        useful as an event payload.
    ``pre-push`` → ``"<upstream>..HEAD"`` (every commit about to be pushed).
        Falls back to ``"HEAD~1..HEAD"`` when no upstream is configured —
        e.g. first push of a new branch — so the agent still sees the
        latest commit instead of nothing.

    Returns ``None`` when no meaningful range exists (initial commit,
    detached HEAD with no parent, repo without commits, etc.).  Callers
    treat ``None`` as "skip diff computation, just publish the bare event".
    """
    if event_name == "commit":
        # Verify HEAD~1 exists; rev-parse returns non-zero on the initial commit.
        if _run_git(repo_root, ["rev-parse", "--verify", "HEAD~1"]) is None:
            return None
        return "HEAD~1..HEAD"

    if event_name == "push":
        upstream = _run_git(
            repo_root, ["rev-parse", "--abbrev-ref", "@{u}"]
        )
        if upstream is None:
            # No upstream — fall back to the latest commit so the push
            # event isn't context-free.  Still ``None`` for an initial-
            # commit branch with no upstream, handled below.
            if _run_git(repo_root, ["rev-parse", "--verify", "HEAD~1"]) is None:
                return None
            return "HEAD~1..HEAD"
        return f"{upstream.strip()}..HEAD"

    return None


def _git_files_in_range(repo_root: str, ref_range: str) -> list[str]:
    """Return the files changed in *ref_range*, one per element."""
    out = _run_git(
        repo_root, ["diff", "--name-only", ref_range]
    )
    if out is None:
        return []
    return [line for line in out.splitlines() if line]


def _git_diff_in_range(
    repo_root: str,
    ref_range: str,
    context_lines: int | None = None,
    max_chars: int | None = None,
) -> str | None:
    """Return the diff for *ref_range*, optionally with extra context + truncation.

    Mirrors the truncation behaviour of ``get_diff_with_context`` so the
    hook payload size is bounded the same way the watcher payload is —
    keeps prompt-token cost predictable on a giant ``pre-push``.
    """
    args = ["diff"]
    if context_lines is not None:
        args.append(f"-U{context_lines}")
    args.append(ref_range)
    out = _run_git(repo_root, args)
    if not out:
        return None
    if max_chars is None or len(out) <= max_chars:
        return out
    remaining = len(out) - max_chars
    marker = _TRUNCATION_MARKER.format(remaining=remaining)
    return out[:max_chars] + "\n" + marker


# Default cap on the raw ``diff`` returned by git_context_for_event.
# 200 KB is wide enough that the security agent's pattern scan still has a
# realistic chance of catching credentials in a large push, but narrow
# enough to bound the notify POST body and the SQLite event_queue row that
# stores the persisted event.  ``diff_context`` keeps its tighter
# ``max_chars`` cap because it feeds the LLM prompt directly and the token
# budget is the binding constraint there, not the storage size.  Bounding
# both also closes the regression Copilot flagged on PR #40: the runner
# uses ``event.diff or event.diff_context`` for security checks, so an
# unbounded ``diff`` defeats the existing prompt-side cap.
_DEFAULT_DIFF_MAX_CHARS = 200_000


def git_context_for_event(
    event_name: str,
    repo_root: str,
    context_lines: int = 30,
    max_chars: int = 8000,
    diff_max_chars: int = _DEFAULT_DIFF_MAX_CHARS,
) -> tuple[list[str], str | None, str | None]:
    """Compute ``(file_paths, diff, diff_context)`` for a hook event.

    *event_name* must be one of ``"commit"`` (post-commit hook) or
    ``"push"`` (pre-push hook).  Any other value returns the empty tuple
    ``([], None, None)`` so unknown events fall through harmlessly to the
    pre-bugfix behaviour rather than guessing.

    On any git failure (not a repo, no parent commit, no upstream and no
    HEAD~1, ``git`` not on PATH) returns ``([], None, None)`` so the
    notify call still succeeds — sagex would rather record a context-free
    event than break the user's git operation.

    Both ``diff`` and ``diff_context`` are size-bounded:

    * ``diff_context`` → ``max_chars`` (LLM prompt budget; default 8 KB).
    * ``diff``         → ``diff_max_chars`` (security-scan + persistence
      budget; default 200 KB).  A ``pre-push`` against a long-running
      branch can produce a multi-MB raw diff; without this cap the POST
      body, the SQLite event row, and the security pattern scan all pay
      the cost — see Copilot review on PR #40.
    """
    ref_range = _resolve_event_range(repo_root, event_name)
    if ref_range is None:
        return [], None, None
    files = _git_files_in_range(repo_root, ref_range)
    diff = _git_diff_in_range(repo_root, ref_range, max_chars=diff_max_chars)
    diff_context = _git_diff_in_range(
        repo_root, ref_range, context_lines=context_lines, max_chars=max_chars
    )
    return files, diff, diff_context


# ---------------------------------------------------------------------------
# Ignore-list check
# ---------------------------------------------------------------------------

def _should_ignore(path: str, ignore_patterns: list[str]) -> bool:
    """Return ``True`` if *path* matches any of the ignore glob patterns."""
    import os

    # Normalize to forward slashes for cross-platform consistency
    normalized = path.replace("\\", "/")
    basename = os.path.basename(path)
    for pattern in ignore_patterns:
        if fnmatch.fnmatch(normalized, pattern):
            return True
        # Also match against the basename only (for patterns like "*.log")
        if fnmatch.fnmatch(basename, pattern):
            return True
    return False


# ---------------------------------------------------------------------------
# Watchdog handler with debounce
# ---------------------------------------------------------------------------

class _DebounceHandler(FileSystemEventHandler):
    """Collects filesystem events and fires one consolidated AgentEvent after debounce."""

    def __init__(self, config: ProjectConfig, bus: EventBus) -> None:
        super().__init__()
        self._config = config
        self._bus = bus
        self._pending: dict[str, float] = {}  # path → last-seen monotonic time
        self._lock = threading.Lock()
        self._timer: threading.Timer | None = None

    def on_any_event(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        path = str(event.src_path)
        if _should_ignore(path, self._config.watch.ignore):
            return
        with self._lock:
            self._pending[path] = monotonic()
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(
                self._config.watch.debounce_seconds,
                self._fire,
            )
            self._timer.daemon = True
            self._timer.start()

    def _fire(self) -> None:
        with self._lock:
            paths = list(self._pending.keys())
            self._pending.clear()
            self._timer = None
        if not paths:
            return

        diff = get_git_diff(self._config.repo_root, paths)
        context = get_diff_with_context(
            self._config.repo_root,
            paths,
            context_lines=self._config.knowledge.context_window_lines,
            max_chars=self._config.knowledge.max_context_chars,
        )
        agent_event = AgentEvent(
            type=EventType.FILE_MODIFIED,
            project_name=self._config.name,
            repo_root=self._config.repo_root,
            file_paths=paths,
            diff=diff,
            diff_context=context,
        )
        self._bus.publish_sync(agent_event)


# ---------------------------------------------------------------------------
# ProjectWatcher
# ---------------------------------------------------------------------------

class ProjectWatcher:
    """Watches a single project's paths and publishes events to the bus."""

    def __init__(self, config: ProjectConfig, bus: EventBus) -> None:
        self._config = config
        self._bus = bus
        self._observer: Any = Observer()
        self._handler = _DebounceHandler(config, bus)

    def start(self) -> None:
        for watch_path in self._config.watch.paths:
            self._observer.schedule(self._handler, watch_path, recursive=True)
        self._observer.start()
        _log.info("watcher started", extra={"project": self._config.name})

    def stop(self) -> None:
        self._observer.stop()
        self._observer.join()
        _log.info("watcher stopped", extra={"project": self._config.name})


# ---------------------------------------------------------------------------
# WatcherManager
# ---------------------------------------------------------------------------

class WatcherManager:
    """Registry of ProjectWatchers for multiple projects."""

    def __init__(self, bus: EventBus) -> None:
        self._bus = bus
        self._watchers: dict[str, ProjectWatcher] = {}

    def add_project(self, config: ProjectConfig) -> None:
        if config.name in self._watchers:
            return
        watcher = ProjectWatcher(config, self._bus)
        self._watchers[config.name] = watcher

    def remove_project(self, project_name: str) -> None:
        watcher = self._watchers.pop(project_name, None)
        if watcher is not None:
            watcher.stop()

    def start_all(self) -> None:
        for watcher in self._watchers.values():
            watcher.start()

    def stop_all(self) -> None:
        for watcher in self._watchers.values():
            watcher.stop()
        self._watchers.clear()
