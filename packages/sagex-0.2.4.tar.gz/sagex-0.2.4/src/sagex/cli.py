"""Click CLI entrypoint for Agentis."""

from __future__ import annotations

import stat
from pathlib import Path
from typing import Any

import click

from sagex import __version__ as _sagex_version
from sagex.constants import TEMPLATE_PLACEHOLDER_NAME

_CONFIG_TEMPLATE = f"""\
name: {TEMPLATE_PLACEHOLDER_NAME}

repo_root: .

watch:
  paths:
    - "src/**/*.py"
    - "tests/**/*.py"
    - "*.yaml"
    - "*.toml"
  ignore:
    - "**/__pycache__/**"
    - "**/.git/**"
    - "**/*.log"
  debounce_seconds: 2.0

test:
  command: "pytest tests/ -x --tb=short"
  timeout_seconds: 120

agent:
  # Provider — one of: anthropic_api (default, pay-per-token Anthropic API),
  # claude_code (local `claude` CLI, consumes Claude Pro/Max subscription),
  # openai_api (pay-per-token OpenAI), ollama (local, free).
  # Override per-run with SAGEX_PROVIDER=<name>.
  provider: "anthropic_api"
  # Leave model / triage_model empty to auto-resolve to the provider's
  # default (e.g., openai_api → gpt-5 / gpt-4o-mini).  Set explicitly to
  # override; invalid model-for-provider combinations fail at startup.
  model: ""
  triage_model: ""
  max_tokens: 2048             # task agent output ceiling
  triage_max_tokens: 512       # haiku triage classification
  meta_max_tokens: 1024        # reflection JSON
  security_max_tokens: 1024    # security audit JSON
  summariser_max_tokens: 512   # diff pre-summariser (haiku)
  temperature: 0.2
  # Ollama-only — ignored by other providers
  ollama_base_url: "http://localhost:11434"

knowledge:
  min_confidence_threshold: 0.4
  max_rules_in_context: 5
  max_episodes_in_context: 3
  max_rule_chars: 200          # per-rule truncation in task prompt
  max_episode_chars: 200       # per-episode truncation in task prompt
  max_context_chars: 4000
  context_window_lines: 30

budget:
  hourly_token_limit: 50000
  daily_token_limit: 500000
  alert_threshold: 0.8
  content_cache_ttl_minutes: 60
  enable_prompt_caching: true

runner:
  max_concurrent_tasks: 3
  queue_max_size: 100
  require_approval: false
  approval_timeout_seconds: 300
  retry_max_attempts: 3

agents:
  security:
    enabled: false
    watch_extra:
      - ".env*"
      - "**/*secret*"
      - "**/requirements*.txt"
      - "**/Dockerfile*"
    auto_remediate: false

notifications:
  webhook_url: null
  on:
    - "critical"
    - "regression_detected"

runtime_url: "http://localhost:8765"
"""

_GITIGNORE_CONTENT = """\
# SQLite WAL/SHM temp files — never commit these
knowledge/*.db-wal
knowledge/*.db-shm

# ChromaDB vector index — large binary, regenerates from episodes
knowledge/vectors/

# Uncomment the next line to keep knowledge LOCAL (not shared with team).
# Leave commented to COMMIT rules.db so the team shares learned rules.
# knowledge/rules.db
"""

_HOOK_TEMPLATE = """\
#!/bin/sh
# `sagex notify` writes config-load warnings to stderr (e.g. broken
# .agents/config.yaml).  Do not redirect stderr — letting it fall through
# to the user's terminal is what surfaces the footgun in issue #19
# (silently dropped events from a misnamed project).  Failures still
# don't block the git hook (`|| true`).
sagex notify --event={event} --repo="$(pwd)" || true
"""


@click.group()
@click.version_option(_sagex_version, prog_name="sagex")
def main() -> None:
    """Agentis — self-learning code agent."""


@main.command()
@click.option("--host", default="0.0.0.0", show_default=True)
@click.option("--port", default=8765, show_default=True)
@click.option("--max-concurrent", default=3, show_default=True, help="Max concurrent agent tasks.")
def serve(host: str, port: int, max_concurrent: int) -> None:
    """Start the agent runtime server."""
    import asyncio

    # AGENTIS_DB_PATH lets operators relocate the global event/usage DB
    # without editing code — useful when /home is read-only (containers,
    # CI) or when the ops team wants the DB under /var or a project-
    # specific data dir.  The name keeps the AGENTIS_ prefix for
    # continuity with the original project name; sagex-specific env vars
    # use SAGEX_*.  Documented in README under "Environment variables".
    import os

    import uvicorn

    from sagex.api.server import ApprovalWaiters, ProjectRegistry, create_app
    from sagex.event_bus import EventBus
    from sagex.knowledge.rules_db import RulesDB
    from sagex.runner import Runner
    from sagex.watcher import WatcherManager

    db_path_override = os.environ.get("AGENTIS_DB_PATH")
    db_path = Path(db_path_override).expanduser() if db_path_override else (
        Path.home() / ".sagex" / "global.db"
    )
    db_path.parent.mkdir(parents=True, exist_ok=True)
    db = RulesDB(str(db_path))

    bus = EventBus(db, max_size=100)
    registry = ProjectRegistry()
    watcher_manager = WatcherManager(bus)
    # Shared approval waiters so approve/reject routes wake runner waiters
    # instantly (issue #10) instead of waiting for the next DB poll tick.
    approval_waiters = ApprovalWaiters()
    runner = Runner(
        bus, registry, watcher_manager,
        max_concurrent_tasks=max_concurrent,
        approval_waiters=approval_waiters,
    )
    app = create_app(
        bus, watcher_manager, registry, runner, approval_waiters=approval_waiters,
    )

    from sagex.logging import configure_logging

    configure_logging()

    async def _main() -> None:
        bus.attach_loop(asyncio.get_running_loop())
        bus.reload_persisted_events()
        asyncio.create_task(runner.run())
        cfg = uvicorn.Config(app, host=host, port=port, log_level="info")
        await uvicorn.Server(cfg).serve()

    asyncio.run(_main())


@main.command()
@click.argument("config_path")
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help="Allow registering even if the project name is still the template default.",
)
def register(config_path: str, force: bool) -> None:
    """Register .agents/config.yaml with the running runtime."""
    import httpx

    from sagex.config import load_config

    config = load_config(Path(config_path))

    # Guard against silently registering the `name: my-project` template
    # default.  Running `sagex init` then `sagex register` without editing
    # the config in between used to register under the placeholder name —
    # the user then thought they were pointing at the right project while
    # the runtime held a ghost `my-project` with no real config attached.
    if config.name == TEMPLATE_PLACEHOLDER_NAME and not force:
        raise click.ClickException(
            "Project name is still the template default "
            f"('{TEMPLATE_PLACEHOLDER_NAME}'). Edit the `name:` field in "
            f"{config_path} to a real project name before registering, "
            "or pass --force to override."
        )

    r = httpx.post(
        f"{config.runtime_url}/projects/register",
        json={
            "config_path": str(Path(config_path).absolute()),
            # Surface the CLI's --force flag to the API's matching guard so
            # legitimate force-registrations bypass both checks consistently.
            "force": force,
        },
    )
    r.raise_for_status()
    click.echo(f"Registered: {config.name}")


@main.command()
@click.argument("repo_path")
def init(repo_path: str) -> None:
    """Scaffold .agents/ directory in a project repo."""
    root = Path(repo_path).resolve()
    agents_dir = root / ".agents"
    knowledge_dir = agents_dir / "knowledge"
    migrations_dir = knowledge_dir / "migrations"
    hooks_dir = agents_dir / "hooks"

    for directory in (agents_dir, knowledge_dir, migrations_dir, hooks_dir):
        directory.mkdir(parents=True, exist_ok=True)

    # config.yaml — skip if already present so re-runs don't overwrite edits
    config_file = agents_dir / "config.yaml"
    if not config_file.exists():
        config_file.write_text(_CONFIG_TEMPLATE)
        click.echo(f"Created  {config_file}")
    else:
        click.echo(f"Skipped  {config_file} (already exists)")

    # .gitignore — always (re)write so it stays canonical
    gitignore_file = agents_dir / ".gitignore"
    gitignore_file.write_text(_GITIGNORE_CONTENT)
    click.echo(f"Created  {gitignore_file}")

    # Git hooks
    for event, script_name in [("commit", "post-commit"), ("push", "pre-push")]:
        hook_file = hooks_dir / script_name
        hook_file.write_text(_HOOK_TEMPLATE.format(event=event))
        current_mode = hook_file.stat().st_mode
        hook_file.chmod(current_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        click.echo(f"Created  {hook_file}")

    click.echo(
        f"\nNext steps:\n"
        f"  1. Edit {config_file}\n"
        f"     Set name, watch paths, and test command for your project.\n"
        f"\n"
        f"  2. Install git hooks:\n"
        f"       ln -sf {hooks_dir}/post-commit {root}/.git/hooks/post-commit\n"
        f"       ln -sf {hooks_dir}/pre-push    {root}/.git/hooks/pre-push\n"
        f"\n"
        f"  3. Start the runtime and register:\n"
        f"       sagex serve --port 8765\n"
        f"       sagex register {config_file}\n"
        f"\n"
        f"  Knowledge sharing:\n"
        f"    rules.db is committed by default so the whole team shares learned rules.\n"
        f"    To keep knowledge local, uncomment '# knowledge/rules.db' in\n"
        f"    {agents_dir / '.gitignore'}."
    )


@main.command()
@click.argument("project_name")
@click.option("--runtime-url", default="http://localhost:8765", show_default=True)
def status(project_name: str, runtime_url: str) -> None:
    """Print recent activity and token usage for a project."""
    import httpx

    def _fetch(path: str) -> dict[str, Any]:
        """GET *path* and raise a helpful ClickException on 404.

        A silent fallback to ``.json().get("episodes", [])`` on 404 would
        show "0 episodes, 0 rules, $0.0000" — indistinguishable from a
        legitimately quiet project and the exact footgun tracked in
        issue #18: a user could register under a wrong name, then
        ``sagex status <other-name>``, see zeros, and conclude everything
        is fine while nothing is wired up.
        """
        resp = httpx.get(f"{runtime_url}{path}")
        if resp.status_code == 404:
            # Best-effort suggestion: list registered projects so the user
            # can spot a typo without reading the server log.  Distinguish
            # a successful 200-with-empty-list (genuinely no projects) from
            # a non-200 response or network failure (lookup itself failed):
            # we must not print "No projects registered" when the lookup
            # never succeeded, or the user gets a confidently wrong hint.
            registered: list[str] = []
            listed_projects = False
            try:
                projects_resp = httpx.get(f"{runtime_url}/projects")
                projects_resp.raise_for_status()
                proj_body = projects_resp.json()
                if isinstance(proj_body, dict):
                    raw_projects = proj_body.get("projects", [])
                    if isinstance(raw_projects, list):
                        registered = [str(p) for p in raw_projects]
                        listed_projects = True
            except Exception:
                pass
            if registered:
                hint = f"\n  Registered projects: {', '.join(registered)}"
            elif listed_projects:
                hint = "\n  No projects registered."
            else:
                hint = "\n  Could not list registered projects."
            raise click.ClickException(
                f"Project {project_name!r} not found on {runtime_url}."
                f"{hint}\n  Did you run `sagex register` against the right config?"
            )
        resp.raise_for_status()
        # Validate at the boundary so ``status``'s downstream ``.get(...)``
        # calls don't fall over on a non-dict body (e.g., a server returning
        # a list, a string, or null).  Without this, the type annotation
        # was relying on a ``# type: ignore`` and any unexpected response
        # would produce an ``AttributeError`` deep in the formatting code.
        body = resp.json()
        if not isinstance(body, dict):
            raise click.ClickException(
                f"Unexpected JSON shape from {runtime_url}{path}: "
                f"expected an object, got {type(body).__name__}"
            )
        return body

    episodes = _fetch(
        f"/projects/{project_name}/episodes?limit=10"
    ).get("episodes", [])
    rules_data = _fetch(f"/projects/{project_name}/rules").get("rules", [])
    usage_data = _fetch(f"/projects/{project_name}/usage?period=24h")

    click.echo(f"\n{'=' * 50}")
    click.echo(f"  {project_name}")
    click.echo(f"{'=' * 50}")
    active = sum(1 for r in rules_data if r.get("status") == "active")
    unvalidated = sum(1 for r in rules_data if r.get("status") == "unvalidated")
    click.echo(
        f"  Rules: {len(rules_data)} total  "
        f"({active} active, {unvalidated} unvalidated)"
    )
    click.echo(
        f"  Tokens today: {usage_data.get('input_tokens_fresh', 0):,} input  "
        f"{usage_data.get('output_tokens', 0):,} output  "
        f"${usage_data.get('estimated_cost_usd', 0):.4f}"
    )
    click.echo("\n  Recent episodes:")
    for ep in episodes:
        if ep.get("test_result_after") == "pass":
            icon = "\u2713"
        elif ep.get("regression_detected"):
            icon = "\u2717"
        else:
            icon = "\u2022"
        click.echo(
            f"    {icon} {ep['created_at'][:19]}  "
            f"[{ep.get('severity', '?'):8s}]  {ep['status']:12s}"
        )


@main.command()
@click.argument("project_name")
@click.option("--last", default="24h", show_default=True, help="Time window: 1h, 24h, 7d")
@click.option("--runtime-url", default="http://localhost:8765", show_default=True)
def usage(project_name: str, last: str, runtime_url: str) -> None:
    """Show token usage and cost history for a project."""
    import httpx

    from sagex.llm.token_tracker import (
        MODEL_PRICING_LAST_UPDATED,
        get_pricing_age_days,
        pricing_is_stale,
    )

    data = httpx.get(
        f"{runtime_url}/projects/{project_name}/usage?period={last}"
    ).json()

    click.echo(f"\n{project_name} \u2014 last {last}")
    click.echo("\u2500" * 55)

    # Warn when the pricing table is old — dollar figures below may be wrong.
    if pricing_is_stale():
        click.echo(
            click.style(
                f"\u26a0  Pricing table last updated {MODEL_PRICING_LAST_UPDATED} "
                f"({get_pricing_age_days()} days ago) — cost figures may be "
                f"stale.  See docs/PROVIDERS.md for refresh procedure.",
                fg="yellow",
            )
        )
    click.echo(f"Total events:          {data.get('total_events', 0):>8,}")
    click.echo(
        f"Skipped by triage:     {data.get('skipped_by_triage', 0):>8,}  "
        f"({data.get('skip_pct', 0):.0f}%)"
    )
    click.echo(f"Cache hits:            {data.get('cache_hits', 0):>8,}")
    click.echo(f"Actual API calls:      {data.get('api_calls', 0):>8,}")
    click.echo()
    click.echo(f"Input tokens (fresh):  {data.get('input_tokens_fresh', 0):>8,}")
    click.echo(
        f"Input tokens (cached): {data.get('input_tokens_cached', 0):>8,}  "
        f"(saved ${data.get('cache_savings_usd', 0):.4f})"
    )
    click.echo(f"Output tokens:         {data.get('output_tokens', 0):>8,}")
    click.echo(f"Estimated cost:        ${data.get('estimated_cost_usd', 0):>8.4f}")
    click.echo()
    click.echo("By agent type:")
    for agent, stats in data.get("by_agent", {}).items():
        click.echo(
            f"  {agent:<12} {stats['calls']:>4} calls  "
            f"{stats['tokens']:>8,} tokens"
        )


@main.command()
@click.option("--event", "event_name", required=True, help="Event type: commit or push.")
@click.option("--repo", required=True, help="Absolute path to the project repo root.")
@click.option("--runtime-url", default="http://localhost:8765", show_default=True)
def notify(event_name: str, repo: str, runtime_url: str) -> None:
    """Notify the runtime of a git hook event (called by installed hooks)."""
    import httpx

    from sagex.config import load_config

    repo_path = Path(repo)
    config_path = repo_path / ".agents" / "config.yaml"
    project_name = repo_path.name  # fallback if config not readable
    if config_path.exists():
        try:
            cfg = load_config(config_path)
            project_name = cfg.name
        except Exception as exc:
            # Visible warning — silent-swallow fallback to repo_path.name is the
            # footgun in issue #19: malformed config yields a name that doesn't
            # match any registered project, runtime returns 202 from /notify,
            # event is dropped silently, and the hook reports "success" forever.
            #
            # Pydantic ``ValidationError`` renders ``str(exc)`` as a multi-
            # line block that scrolls a git-hook terminal off-screen.
            # Surface the exception type explicitly and reduce the body to
            # its first line so the warning stays scannable; the user can
            # re-run ``sagex notify`` standalone for the full trace.
            exc_summary = str(exc).strip().splitlines() or [""]
            # Wording: "failed to load" not "failed to parse" — load_config
            # can fail at *either* the YAML parse step or at Pydantic
            # schema validation (e.g., missing required fields), and the
            # latter is what users hit most often.
            click.echo(
                f"warning: {config_path} failed to load "
                f"({type(exc).__name__}: {exc_summary[0]}); "
                f"falling back to repo directory name {project_name!r}. "
                f"The event will be dropped if no project is registered under "
                f"that name — fix .agents/config.yaml and retry.",
                err=True,
            )

    # Compute the git context for the event AT THE HOOK SITE — this is
    # the only moment when the working tree is at the exact state the
    # event captures.  If we deferred to the API server, race windows
    # (another commit lands, working tree changes) and trust-boundary
    # issues (the runtime daemon would need read access to arbitrary
    # repo_root paths) would creep in.  See the architecture note on PR
    # #40 for the full reasoning.
    from sagex.watcher import git_context_for_event

    file_paths, diff, diff_context = git_context_for_event(
        event_name, repo
    )

    r = httpx.post(
        f"{runtime_url}/notify",
        json={
            "project_name": project_name,
            "event_type": event_name,
            "repo_root": repo,
            "file_paths": file_paths,
            "diff": diff,
            "diff_context": diff_context,
        },
        timeout=5.0,
    )
    r.raise_for_status()
    click.echo(f"Notified runtime: {event_name} for {project_name}")


@main.command()
@click.argument("project_name")
@click.option("--dry-run", is_flag=True, help="Show plan without executing.")
@click.option("--runtime-url", default="http://localhost:8765", show_default=True)
def trigger(project_name: str, dry_run: bool, runtime_url: str) -> None:
    """Manually trigger an agent cycle. --dry-run shows the plan without executing."""
    import httpx

    r = httpx.post(
        f"{runtime_url}/notify",
        json={
            "project_name": project_name,
            "event_type": "manual",
            "repo_root": ".",
            "extra": {"dry_run": dry_run},
        },
    )
    r.raise_for_status()
    if dry_run:
        click.echo("Dry run triggered \u2014 check logs for plan output.")
    else:
        click.echo("Agent cycle triggered.")
