# Contributing to AI-Augmented Developer

Thanks for taking the time to contribute. This document explains how to propose changes to the framework.

## Ground rules

1. **Open an issue first** for anything larger than a typo or a one-line fix. Describe the problem and the intended outcome before writing code or new skills.
2. **One concern per PR.** A PR that fixes a bug and refactors unrelated skills is harder to review and more likely to regress things.
3. **Follow the constitution.** Every PR that affects skills, templates, or the CLI must either pass the constitution check in its plan, or document the waiver in `Complexity Tracking`. Read [`constitution.md`](./constitution.md) before proposing architectural changes.
4. **Cite prior art.** If you adapt a skill or template from another project, update `CREDITS.md`.

## Types of contributions

### Bug reports

File an issue with:

- the platform (Claude Code / Cursor / Codex / OpenCode / Gemini CLI) and version,
- the skill, command, or template involved,
- the exact invocation and the observed vs expected behavior,
- if applicable, the minimum reproducer (a short `spec.md` or `plan.md` that triggers the bug).

### New or modified skills

Each skill lives under `skills/<name>/SKILL.md` with frontmatter that conforms to `schemas/skill-frontmatter.schema.json` (available from v0.2 onward).

Checklist for a skill PR:

- [ ] Frontmatter has `name`, `description`, `version`. From v0.2: `inputs`, `outputs`, `requires` as applicable.
- [ ] Body is under 100 lines unless there is a documented reason.
- [ ] If the skill prescribes a workflow, it is invokable from a fresh context without the agent needing to read any other file first.
- [ ] No contradictions with existing skills. In particular, `skills/using-ai-augmented-developer/SKILL.md` governs the meta-rules.
- [ ] At least one concrete example of usage.

### The `[NEEDS CLARIFICATION]` marker

When writing a spec or plan, any ambiguity you cannot resolve on your own
is marked inline:

```markdown
The import job should retry [NEEDS CLARIFICATION: how many times? the
original PRD doesn't say, and we saw two different values in Slack].
```

Rules:

- Every marker must include a precise question after the colon. A bare
  `[NEEDS CLARIFICATION]` is not useful.
- The `clarify` skill surfaces these markers to the user and edits them
  out once answered.
- A spec or plan that still contains a marker is **not approved** and
  must not be handed off to `implement`. CI enforces this from phase 6a.

### New templates or presets

Templates (`templates/*.md`) and presets (`presets/<name>/`) need:

- a rationale in the PR description (what gap does it fill?),
- for presets, a `preset.yaml` listing the variables to substitute during install,
- test coverage once the CLI ships: a round-trip that runs `aiadev install --preset <name>` in a throwaway directory and asserts the resulting structure.

### Bundled agents

The `agents/` catalog is imported from upstream projects (see `CREDITS.md`). **Do not** hand-edit files there; open an issue so we can track drift with the source.

## Local workflow

Until the CLI ships (see `CHANGELOG.md [Unreleased]`), validation is manual:

```bash
# List skills and their frontmatter (for smoke checking)
find skills -name "SKILL.md" -exec head -n 10 {} \;

# From v0.2: the CLI handles this
aiadev validate
aiadev doctor
```

CI runs the same checks automatically via `.github/workflows/validate.yml`.

### Testing the install command locally

The install engine (v0.3) is exercised by unit, CLI, and end-to-end
tests. To try the command by hand without mutating your own checkout:

```bash
# Create a disposable project directory.
mkdir -p /tmp/install-demo && cd /tmp/install-demo

# Point the CLI at this framework checkout.
AIADEV_ROOT=/path/to/ai-augmented-developer \
  python -m aiadev install \
    --preset lean \
    --non-interactive \
    --vars PROJECT_NAME=Demo

ls /tmp/install-demo          # CLAUDE.md + .aiadev/installed.yaml
cat /tmp/install-demo/.aiadev/installed.yaml

# Undo.
AIADEV_ROOT=/path/to/ai-augmented-developer \
  python -m aiadev install --preset lean --uninstall
```

The test suite covers every behaviour of that flow. For coverage reports:

```bash
pytest --cov=src/aiadev --cov-report=term-missing
```

## Commit messages

Follow [Conventional Commits](https://www.conventionalcommits.org/):

- `feat:` new skill, command, template, preset, or CLI feature.
- `fix:` bug fix.
- `docs:` README, CONTRIBUTING, CHANGELOG changes.
- `refactor:` renames, moves, or structural changes with no behavior change.
- `chore:` tooling, dependencies, CI config.

Breaking changes go in the footer: `BREAKING CHANGE: <description>`.

## Release process

The full release runbook lives at [`docs/RELEASING.md`](./docs/RELEASING.md). It covers the one-time PyPI trusted-publisher setup, the routine release flow (bump `VERSION`, promote `CHANGELOG`, tag, publish a GitHub release that triggers the workflow), the failure modes, and the post-publish smoke test.

Short version of the routine flow once `main` is green:

```bash
echo "X.Y.Z" > VERSION                # bump
$EDITOR CHANGELOG.md                  # move [Unreleased] to [X.Y.Z]
git commit -am "chore(release): X.Y.Z"
git tag -a vX.Y.Z -m "Release X.Y.Z — <one line>"
git push origin main && git push origin vX.Y.Z
gh release create vX.Y.Z --title "vX.Y.Z — <one line>" --notes-file <(awk ...)
```

The publish workflow runs on the release event and uploads the wheel + sdist to <https://pypi.org/project/aiadev/>.

## Code of conduct

Be respectful. Assume good faith. If someone asks for context, give it. If something in a review feels unfair, say so and we will work through it.
