"""Typed exceptions for Devantis SDK.

Every API error maps to a specific exception. Consumers catch what they care about.
"""


class DevantisError(Exception):
    """Base exception for all SDK errors."""

    def __init__(self, message: str, service: str = "", status_code: int = 0):
        self.service = service
        self.status_code = status_code
        super().__init__(message)


class AuthError(DevantisError):
    """Authentication failed — token expired, invalid, or missing."""
    pass


class Forbidden(DevantisError):
    """Permission denied — user doesn't have the required role."""

    def __init__(self, message: str = "Permission denied", service: str = "", required_role: str = ""):
        self.required_role = required_role
        super().__init__(message, service, 403)


class NotFound(DevantisError):
    """Resource not found."""

    def __init__(self, entity_type: str = "", entity_id: str = "", service: str = ""):
        self.entity_type = entity_type
        self.entity_id = entity_id
        msg = f"{entity_type} not found: {entity_id}" if entity_type else "Not found"
        super().__init__(msg, service, 404)


class ValidationError(DevantisError):
    """Invalid input — request body didn't pass validation."""

    def __init__(self, detail: str | dict = "", service: str = ""):
        self.detail = detail
        msg = str(detail) if isinstance(detail, str) else f"Validation error: {detail}"
        super().__init__(msg, service, 422)


class Conflict(DevantisError):
    """Conflict — resource already exists or concurrent modification."""

    def __init__(self, message: str = "Conflict", service: str = ""):
        super().__init__(message, service, 409)


class ServiceUnavailable(DevantisError):
    """Backend service is down or unreachable."""

    def __init__(self, service: str = "", message: str = ""):
        msg = message or f"{service} is unavailable. The service may be starting up."
        super().__init__(msg, service, 503)


class RateLimited(DevantisError):
    """Too many requests — retry after delay."""

    def __init__(self, retry_after: int = 5, service: str = ""):
        self.retry_after = retry_after
        super().__init__(f"Rate limited. Retry after {retry_after}s.", service, 429)


class WriteLockTimeout(DevantisError):
    """Another session holds the write lock."""

    def __init__(self, message: str = "Write lock held by another session"):
        super().__init__(message, status_code=423)
