"""Devantis SDK — Python interface to the Devantis development platform.

Usage:
    from devantis import DevantisClient

    client = await DevantisClient.connect(org="my-org", project="my-proj", app="my-app")

    # Read source code
    content = await client.source.read("src/main.py")

    # Search everything
    results = await client.search("authentication")

    # Create a ticket
    ticket = await client.tickets.create(title="...", description="...", feature="auth")
"""

from devantis.main import DevantisClient

__all__ = ["DevantisClient"]

try:
    from importlib.metadata import version as _get_version
    __version__ = _get_version("devantis-sdk")
except Exception:
    __version__ = "0.0.0"
