"""Pydantic models for Devantis SDK request/response types.

Models will be added as services are implemented.
For Phase 1, services return raw dicts from the API.
Phase 2 will add typed models for IDE autocomplete and validation.
"""
