"""Tenant context — org/project/app resolution and header injection.

Resolves slugs to UUIDs on first use, caches the result.
Injects X-Organization-ID, X-Project-ID, X-Application-ID headers.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class TenantContext:
    """Resolved tenant context with UUIDs."""

    org_id: str
    org_slug: str
    org_name: str
    project_id: str
    project_slug: str
    project_name: str
    app_id: str
    app_slug: str
    app_name: str
    app_type: str = ""
    user_role: str = ""

    def context_headers(self) -> dict[str, str]:
        """Return tenant context headers for API requests."""
        return {
            "X-Organization-ID": self.org_id,
            "X-Project-ID": self.project_id,
            "X-Application-ID": self.app_id,
        }


class TenantResolver:
    """Resolves org/project/app slugs or IDs to a full TenantContext."""

    def __init__(self, http_client, auth, project_service_url: str):
        self._http = http_client
        self._auth = auth
        self._base = project_service_url

    async def resolve(self, org: str, project: str, app: str) -> TenantContext:
        """Resolve slugs or UUIDs to a full TenantContext.

        Accepts either slugs (my-org) or UUIDs (70d031b7-...).
        """
        headers = await self._auth.get_headers()

        # Resolve org
        if self._is_uuid(org):
            org_data = await self._get(f"/api/v1/organisations/{org}", headers)
        else:
            org_data = await self._get(f"/api/v1/organisations/by-slug/{org}", headers)

        org_id = str(org_data["id"])
        org_slug = org_data.get("slug", org)
        org_name = org_data.get("name", org_slug)

        # Resolve project
        if self._is_uuid(project):
            proj_data = await self._get(
                f"/api/v1/organisations/{org_id}/projects/{project}", headers
            )
        else:
            proj_data = await self._get(
                f"/api/v1/organisations/{org_id}/projects/by-slug/{project}", headers
            )

        project_id = str(proj_data["id"])
        project_slug = proj_data.get("slug", project)
        project_name = proj_data.get("name", project_slug)

        # Resolve app
        if self._is_uuid(app):
            app_data = await self._get(
                f"/api/v1/organisations/{org_id}/projects/{project_id}/apps/{app}",
                headers,
            )
        else:
            app_data = await self._get(
                f"/api/v1/organisations/{org_id}/projects/{project_id}/apps/by-slug/{app}",
                headers,
            )

        app_id = str(app_data["id"])
        app_slug = app_data.get("slug", app)
        app_name = app_data.get("name", app_slug)
        app_type = app_data.get("app_type", "")

        logger.info(f"Resolved tenant: {org_name}/{project_name}/{app_name}")

        return TenantContext(
            org_id=org_id, org_slug=org_slug, org_name=org_name,
            project_id=project_id, project_slug=project_slug, project_name=project_name,
            app_id=app_id, app_slug=app_slug, app_name=app_name,
            app_type=app_type,
        )

    async def _get(self, path: str, headers: dict) -> dict:
        response = await self._http.get(f"{self._base}{path}", headers=headers)
        if response.status_code == 404:
            from devantis.errors import NotFound
            raise NotFound(entity_type="resource", entity_id=path, service="project-service")
        response.raise_for_status()
        return response.json()

    @staticmethod
    def _is_uuid(value: str) -> bool:
        """Check if a string looks like a UUID."""
        return len(value) == 36 and value.count("-") == 4


def resolve_from_env() -> tuple[str, str, str]:
    """Read org/project/app from environment variables or config."""
    org = os.environ.get("DEVANTIS_ORG", "")
    project = os.environ.get("DEVANTIS_PROJECT", "")
    app = os.environ.get("DEVANTIS_APP", "")

    if not all([org, project, app]):
        # Try loading from CLI config (~/.devantis.yaml)
        # CLI saves as default_org/default_project/default_app
        config_path = os.path.expanduser("~/.devantis.yaml")
        if os.path.exists(config_path):
            import yaml
            with open(config_path) as f:
                config = yaml.safe_load(f) or {}
            org = org or config.get("default_org",
                        config.get("organisation", config.get("org", "")))
            project = project or config.get("default_project",
                                 config.get("project", ""))
            app = app or config.get("default_app",
                        config.get("app", config.get("application", "")))

    if not all([org, project, app]):
        from devantis.errors import DevantisError
        raise DevantisError(
            "Missing tenant context. Set DEVANTIS_ORG, DEVANTIS_PROJECT, DEVANTIS_APP "
            "environment variables, or run 'devantis config'."
        )

    return org, project, app
