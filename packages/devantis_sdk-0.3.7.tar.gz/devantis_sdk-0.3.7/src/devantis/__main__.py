"""Run the MCP server: python -m devantis"""
from devantis.mcp_server import main

main()
