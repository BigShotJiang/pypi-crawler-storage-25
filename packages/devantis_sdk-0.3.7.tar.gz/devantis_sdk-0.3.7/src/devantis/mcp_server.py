"""Devantis MCP Server — wraps the Devantis SDK for Claude Desktop / Claude Code.

Run with:
    python -m devantis
    python -m devantis.mcp_server

Provides ~100 tools covering the full Devantis platform:
- Source code: read, write, edit, delete, move, list, glob, grep
- Tickets: full CRUD + labels, subtasks, links, watchers, comments, boards, charts
- Requirements: CRUD + search
- Sprints & Epics: CRUD + ticket assignment
- Architecture & Designs: CRUD + search
- Chat: send messages, answer questions, confirm, sessions, history
- Knowledge Graph (Brain): entities, observations, relations, search, reasoning
- Executors: shell, K8s deploy, MCP tools
- Analytics: token usage, cost forecast, alerts
- Users & Members: search, manage team
- Config & Notifications: app config, notification channels
- Search: cross-entity parallel search
- Memory: persistent project decisions
- Bulk: batch ticket operations
"""

from __future__ import annotations

import asyncio
import json
import logging

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Resource,
    TextContent,
    Tool,
)

from devantis.errors import (
    AuthError,
    Conflict,
    DevantisError,
    Forbidden,
    NotFound,
    RateLimited,
    ServiceUnavailable,
    ValidationError,
    WriteLockTimeout,
)
from devantis.main import DevantisClient

logger = logging.getLogger(__name__)

# ── Global state (initialised on first connection) ─────────────────
_client: DevantisClient | None = None
_briefing: str = ""
_active_chat_session: str | None = None  # Persisted across tool calls

server = Server("devantis-platform", version="0.2.0")


# ── Helpers ────────────────────────────────────────────────────────

def _text(content: str, is_error: bool = False) -> list[TextContent]:
    return [TextContent(type="text", text=content, isError=is_error)]


def _json_text(data, is_error: bool = False) -> list[TextContent]:
    text = json.dumps(data, indent=2, default=str) if not isinstance(data, str) else data
    return _text(text, is_error=is_error)


def _j(data) -> str:
    """Compact JSON serialization."""
    return json.dumps(data, default=str)


async def _ensure_client() -> DevantisClient:
    global _client, _briefing
    if _client is None:
        _client = await DevantisClient.connect()
        try:
            _briefing = await _client.build_briefing()
        except Exception as exc:
            logger.warning("Failed to build briefing: %s", exc)
            _briefing = "Connected to Devantis platform. Briefing unavailable — use tools to explore."
    return _client


# ── Server Instructions (dynamic briefing) ─────────────────────────

@server.list_resources()
async def list_resources() -> list[Resource]:
    return [
        Resource(
            uri="devantis://context",
            name="Current Context",
            description="Current organisation, project, and application context.",
            mimeType="text/plain",
        ),
        Resource(
            uri="devantis://project/overview",
            name="Project Overview",
            description="Live summary — requirement counts, ticket counts, file stats, sprint status.",
            mimeType="application/json",
        ),
        Resource(
            uri="devantis://source/tree",
            name="Source File Tree",
            description="Complete source code file listing.",
            mimeType="text/plain",
        ),
        Resource(
            uri="devantis://project/memory",
            name="Project Memory",
            description="Persistent project decisions and preferences.",
            mimeType="application/json",
        ),
        Resource(
            uri="devantis://docs/navigation",
            name="Documentation Navigation",
            description="Full documentation navigation tree — categories and pages.",
            mimeType="application/json",
        ),
    ]


@server.read_resource()
async def read_resource(uri: str) -> str:
    client = await _ensure_client()

    if uri == "devantis://context":
        ctx = client.context
        return (
            f"Organisation: {ctx.org_name} ({ctx.org_slug})\n"
            f"Project: {ctx.project_name} ({ctx.project_slug})\n"
            f"Application: {ctx.app_name} ({ctx.app_slug})\n"
            f"App Type: {ctx.app_type or 'unknown'}\n"
            f"Role: {ctx.user_role or 'unknown'}"
        )

    if uri == "devantis://project/overview":
        overview = await client.get_project_overview()
        return json.dumps(overview, indent=2, default=str)

    if uri == "devantis://source/tree":
        try:
            files = await client.source.list()
            paths = sorted(f.get("path", "") for f in files if isinstance(f, dict))
            return "\n".join(paths) if paths else "(no files)"
        except Exception:
            return "(could not load file tree)"

    if uri == "devantis://project/memory":
        try:
            mem = await client.memory.list()
            return json.dumps(mem, indent=2, default=str)
        except Exception:
            return "{}"

    if uri == "devantis://docs/navigation":
        try:
            nav = await client.docs.navigation()
            return json.dumps(nav, indent=2, default=str)
        except Exception:
            return '{"categories": []}'

    return f"Unknown resource: {uri}"


# ── Tool Definitions ───────────────────────────────────────────────
# Organized by domain. Each Tool has name, description, inputSchema.

def _tool(name: str, desc: str, props: dict, required: list[str] | None = None) -> Tool:
    """Shorthand for creating a Tool."""
    schema: dict = {"type": "object", "properties": props}
    if required:
        schema["required"] = required
    return Tool(name=name, description=desc, inputSchema=schema)


def _str(desc: str) -> dict:
    return {"type": "string", "description": desc}


def _int(desc: str) -> dict:
    return {"type": "integer", "description": desc}


def _bool(desc: str) -> dict:
    return {"type": "boolean", "description": desc}


def _arr(desc: str, items: dict | None = None) -> dict:
    d: dict = {"type": "array", "description": desc}
    if items:
        d["items"] = items
    return d


def _obj(desc: str) -> dict:
    return {"type": "object", "description": desc}


TOOLS: list[Tool] = [
    # ══════════════════════════════════════════════════════════
    # SOURCE CODE
    # ══════════════════════════════════════════════════════════
    _tool("devantis_read_file",
          "Read the full contents of a source code file from the project repository. Use this to inspect "
          "existing code before making changes, understand how a module works, or verify a file exists. "
          "Always read a file before using devantis_edit_file so you know the exact content to match.",
          {"path": _str("File path relative to project root. Example: `src/main.py`, `backend/routers/health.py`, `package.json`")},
          ["path"]),

    _tool("devantis_list_files",
          "List all files in the project repository, optionally filtered to a specific folder. Use this "
          "to browse the project structure, discover what files exist, or understand the overall layout "
          "before diving into specific files. Returns file metadata including paths and sizes.",
          {"folder": _str("Folder path to list contents of. Omit or leave empty to list ALL files in the project. "
                          "Example: `src/components`, `backend/api`, `tests`")}),

    _tool("devantis_glob_files",
          "Find files matching a glob pattern across the entire project. Faster and more precise than "
          "listing everything and filtering manually. Use this when searching for files by naming convention "
          "-- all Python files, all test files, all configs in a subfolder, or files with a specific extension.",
          {"pattern": _str("Glob pattern to match file paths against. Supports `*` (any characters in one segment), "
                           "`**` (any nested directories), and `?` (single character). "
                           "Examples: `*.py`, `src/**/*.ts`, `**/test_*.py`, `**/*.config.js`, `docs/**/*.md`")},
          ["pattern"]),

    _tool("devantis_grep",
          "Search inside source code files using regex patterns. This is the ONLY way to find functions, "
          "classes, imports, variable usages, or any text pattern inside file contents. File listing and "
          "glob tools only match file names, not content. Use this when you need to find WHERE something "
          "is defined, imported, called, or referenced across the codebase.",
          {
              "pattern": _str("Regex pattern to search for inside file contents. Supports full regex syntax. "
                              "Examples: `def authenticate`, `class UserService`, `import.*redis`, `TODO:.*fix`"),
              "patterns": _arr("Multiple regex patterns to search in a single pass. More efficient than calling "
                               "grep multiple times. Each pattern is searched independently and results are grouped. "
                               "Example: [`def create_user`, `def delete_user`, `def update_user`]", {"type": "string"}),
              "glob": _str("Only search inside files matching this glob pattern, ignoring all other files. "
                           "Use this to narrow searches to specific file types or directories. "
                           "Examples: `*.py`, `src/**/*.ts`, `**/*.yaml`"),
              "context_lines": _int("Number of lines to include before and after each match for surrounding context. "
                                    "Default: 2. Set higher (e.g., 5-10) when you need to understand the function or "
                                    "block a match appears in."),
              "max_results": _int("Maximum number of matches to return per pattern. Default: 10. Increase if you "
                                  "need a comprehensive list of all occurrences (e.g., 50 or 100)."),
          }),

    _tool("devantis_write_file",
          "Create a brand new file or completely overwrite an existing file with new content. Use this "
          "when creating NEW files that don't exist yet, or when changes are so extensive that a full "
          "replacement is simpler than editing. For small, targeted changes to existing files, prefer "
          "devantis_edit_file instead -- it is safer, sends less data, and avoids accidentally losing content.",
          {
              "path": _str("File path relative to project root. Parent directories are created automatically "
                           "if they don't exist. Example: `src/utils/helpers.py`, `config/settings.yaml`"),
              "content": _str("The complete file content to write. This REPLACES the entire file contents -- "
                              "anything not included will be lost. For new files, provide the full initial content."),
          },
          ["path", "content"]),

    _tool("devantis_edit_file",
          "Make a targeted, surgical change to an existing file by finding a block of old content and "
          "replacing it with new content. Uses fuzzy matching that tolerates minor whitespace differences. "
          "Use this for focused edits: changing a function body, fixing a bug, updating an import, adding "
          "a method. Always read the file first with devantis_read_file so you know the exact content to match.",
          {
              "file_path": _str("Path of the file to edit, relative to project root. The file must already exist. "
                                "Example: `src/main.py`, `backend/models/user.py`"),
              "old_content": _str("The existing code block to find and replace. Copy this EXACTLY from the file "
                                  "(use devantis_read_file first). Include enough surrounding context to make the "
                                  "match unique -- at least 2-3 lines above and below the change point."),
              "new_content": _str("The replacement code that will take the place of old_content. Must be a complete "
                                  "replacement -- include unchanged surrounding lines if they were part of old_content."),
          },
          ["file_path", "old_content", "new_content"]),

    _tool("devantis_delete_file",
          "Permanently delete a source code file from the project repository. Use this to remove files "
          "that are no longer needed -- old configs, deprecated modules, temporary files, or files replaced "
          "during refactoring. This action cannot be undone (though git history preserves the file).",
          {"path": _str("File path relative to project root to delete. Example: `src/old_module.py`, "
                        "`config/deprecated.yaml`, `tests/test_removed_feature.py`")},
          ["path"]),

    _tool("devantis_move_file",
          "Move or rename a file within the project repository. Use this when refactoring -- renaming a "
          "module, reorganizing files into a new folder structure, or changing file extensions. The "
          "destination directory is created automatically if it doesn't exist.",
          {
              "source_path": _str("Current file path relative to project root. Example: `src/utils.py`"),
              "destination_path": _str("New file path relative to project root. Example: `src/helpers/utils.py`, "
                                       "`src/utils_v2.py`"),
          },
          ["source_path", "destination_path"]),

    # ── Source Code — Batch ─────────────────────────────────
    _tool("devantis_batch_files",
          "Perform batch file operations — write, delete, or edit multiple files in a single call (max 20). "
          "Much more efficient than calling single-file tools repeatedly. Use this when creating scaffolding, "
          "refactoring across files, or cleaning up multiple files at once.",
          {
              "action": _str("`write` (create/overwrite multiple files), `delete` (remove multiple files), "
                             "`edit` (find-and-replace across multiple files)"),
              "files": _arr("For `write`: list of {path, content} objects. Example: "
                            '[{"path": "src/main.py", "content": "..."}, {"path": "src/utils.py", "content": "..."}]',
                            {"type": "object"}),
              "paths": _arr("For `delete`: list of file paths to remove. Example: "
                            '["src/old.py", "src/deprecated.py"]',
                            {"type": "string"}),
              "edits": _arr("For `edit`: list of {path, old_content, new_content} objects. "
                            'Example: [{"path": "src/main.py", "old_content": "old code", "new_content": "new code"}]',
                            {"type": "object"}),
          },
          ["action"]),

    # ══════════════════════════════════════════════════════════
    # SEARCH
    # ══════════════════════════════════════════════════════════
    _tool("devantis_search",
          "Search across ALL project entities in one call -- tickets, requirements, architecture docs, "
          "design files, and source code. Use this as the first step when you need to find something "
          "but don't know which entity type it belongs to, or when you want a broad cross-cutting view. "
          "For targeted searches within a single entity type, use the specific search tool instead.",
          {
              "query": _str("Search text to find across all entity types. Can be a keyword, phrase, or concept. "
                            "Examples: `authentication`, `payment processing`, `database migration`"),
              "entity_types": _arr("Narrow the search to specific entity types instead of searching everything. "
                                   "Valid values: `requirements`, `tickets`, `architecture`, `designs`, `code`. "
                                   "Example: [`tickets`, `requirements`] to search only those two.",
                                   {"type": "string"}),
          },
          ["query"]),

    _tool("devantis_search_tickets",
          "Full-text search across ticket titles and descriptions. More targeted than devantis_search "
          "when you specifically need to find tickets. Use this when looking for tickets about a particular "
          "topic, feature, or bug. Supports filtering by feature group for narrower results.",
          {
              "query": _str("Search text to match against ticket titles and descriptions. "
                            "Examples: `login bug`, `API rate limiting`, `user onboarding flow`"),
              "feature": _str("Filter results to only tickets belonging to this feature group. "
                              "Example: `authentication`, `billing`, `dashboard`"),
              "max_results": _int("Maximum number of tickets to return. Default: 50. Lower values (10-20) "
                                  "for quick lookups, higher (100+) for comprehensive audits."),
          },
          ["query"]),

    # ══════════════════════════════════════════════════════════
    # TICKETS -- Core CRUD
    # ══════════════════════════════════════════════════════════
    _tool("devantis_list_tickets",
          "List tickets from the project backlog with optional filters for status, priority, feature, "
          "assignee, sprint, or epic. Use this to get an overview of work items, check what's in progress, "
          "find tickets in a specific state, or browse the backlog. Returns paginated results.",
          {
              "status": _str("Filter by ticket workflow status. Valid values: `backlog` (not started), "
                             "`open` (ready to work), `in_progress` (actively being worked), `blocked` (waiting "
                             "on something), `review` (code review), `testing` (QA), `done` (completed). "
                             "Omit to return all statuses."),
              "feature": _str("Filter by feature group name. Returns only tickets belonging to this feature. "
                              "Example: `authentication`, `billing`, `user-management`"),
              "priority": _str("Filter by priority level. Valid values: `critical`, `high`, `medium`, `low`. "
                               "Omit to return all priorities."),
              "assignee": _str("Filter by assigned team member's username. Returns only tickets assigned to "
                               "this person. Example: `john.doe`"),
              "sprint_id": _str("Filter by sprint UUID. Returns only tickets that belong to this sprint. "
                                "Use devantis_manage_sprints with action=`list` to find sprint IDs."),
              "epic_id": _str("Filter by epic UUID or key. Returns only tickets that belong to this epic. "
                              "Use devantis_manage_epics with action=`list` to find epic IDs."),
              "page": _int("Page number for pagination, starting at 1. Default: 1."),
              "page_size": _int("Number of tickets per page. Default: 30. Max recommended: 100."),
          }),

    _tool("devantis_get_ticket",
          "Get the full details of a single ticket including its title, description, status, priority, "
          "assignee, labels, acceptance criteria, implementation notes, comments, subtasks, and links. "
          "Use this when you need complete information about a specific ticket before working on it.",
          {"ticket_id": _str("The ticket's unique identifier. This is a UUID string. "
                             "Example: `a1b2c3d4-e5f6-7890-abcd-ef1234567890`")},
          ["ticket_id"]),

    _tool("devantis_create_ticket",
          "Create a new ticket in the project backlog. Use this to track new work items -- features to "
          "build, bugs to fix, tasks to complete, or technical chores. Provide a clear title, detailed "
          "description, and feature group at minimum. Add acceptance criteria for clarity on what 'done' means.",
          {
              "title": _str("Short, action-oriented title summarizing the work. Should be clear enough to "
                            "understand at a glance. Examples: `Add OAuth2 login flow`, `Fix 500 error on /api/users`, "
                            "`Migrate DB to PostgreSQL 16`"),
              "description": _str("Detailed description of what needs to be built or fixed. Include context, "
                                  "scope boundaries, expected behavior, and any technical constraints. "
                                  "Supports markdown formatting."),
              "feature": _str("Feature group this ticket belongs to. Used for organizing and filtering. "
                              "Example: `authentication`, `billing`, `dashboard`, `infrastructure`"),
              "type": _str("Ticket type classification. Valid values: `feature` (new functionality), "
                           "`bug` (defect to fix), `task` (general work item), `enhancement` (improvement "
                           "to existing feature), `chore` (maintenance/tech debt). Default: `task`."),
              "priority": _str("Priority level. Valid values: `critical` (blocking, fix immediately), "
                               "`high` (important, fix this sprint), `medium` (normal priority), "
                               "`low` (nice to have, do when free). Default: `medium`."),
              "acceptance_criteria": _arr("List of specific, testable conditions that must be true for the "
                                          "ticket to be considered done. Example: [`User can log in with Google OAuth`, "
                                          "`Session persists across page refreshes`, `Logout clears all tokens`]",
                                          {"type": "string"}),
              "labels": _arr("Categorization labels for cross-cutting concerns. Example: [`security`, `frontend`, "
                             "`breaking-change`]", {"type": "string"}),
              "assignee": _str("Username of the team member to assign this ticket to. "
                               "Use devantis_users_search to find usernames."),
              "implementation_notes": _str("Technical guidance for whoever implements this ticket. Include "
                                           "architecture decisions, relevant file paths, API contracts, or "
                                           "gotchas to watch out for."),
              "epic_id": _str("UUID of the epic to attach this ticket to. Use devantis_manage_epics "
                              "with action=`list` to find epic IDs."),
              "sprint_id": _str("UUID of the sprint to add this ticket to. Use devantis_manage_sprints "
                                "with action=`list` to find sprint IDs."),
          },
          ["title", "description", "feature"]),

    _tool("devantis_update_ticket",
          "Update one or more fields on an existing ticket. Only the fields you provide will be changed; "
          "omitted fields remain untouched. Use this to refine ticket details, change priority, reassign "
          "work, or update acceptance criteria. For status changes, use devantis_transition_ticket instead.",
          {
              "ticket_id": _str("UUID of the ticket to update. Example: `a1b2c3d4-e5f6-7890-abcd-ef1234567890`"),
              "title": _str("New title to replace the current one."),
              "description": _str("New description to replace the current one. Supports markdown."),
              "priority": _str("New priority level. Valid values: `critical`, `high`, `medium`, `low`."),
              "labels": _arr("New label set. WARNING: This REPLACES all existing labels -- include any you "
                             "want to keep. Example: [`security`, `backend`, `urgent`]", {"type": "string"}),
              "assignee": _str("Username of the new assignee. Use devantis_users_search to find usernames."),
              "acceptance_criteria": _arr("New acceptance criteria. WARNING: This REPLACES all existing criteria -- "
                                          "include any you want to keep.", {"type": "string"}),
              "implementation_notes": _str("New implementation notes to replace the current ones."),
          },
          ["ticket_id"]),

    _tool("devantis_delete_ticket",
          "Permanently delete a ticket from the project. This removes the ticket and all its associated "
          "data (comments, subtasks, links, time logs). This action cannot be undone. Use with caution -- "
          "consider moving to `done` or `backlog` status instead if you might need the ticket later.",
          {"ticket_id": _str("UUID of the ticket to permanently delete. "
                             "Example: `a1b2c3d4-e5f6-7890-abcd-ef1234567890`")},
          ["ticket_id"]),

    _tool("devantis_transition_ticket",
          "Move a ticket through its workflow by applying a status transition action. Use this instead "
          "of devantis_update_ticket when changing ticket status, because transitions enforce workflow "
          "rules and record state change history. Each action moves the ticket to a specific target status.",
          {
              "ticket_id": _str("UUID of the ticket to transition. "
                                "Example: `a1b2c3d4-e5f6-7890-abcd-ef1234567890`"),
              "action": _str("Workflow transition to apply. Valid values: `start` (move to in_progress), "
                             "`submit_review` (move to review), `move_testing` (move to testing), "
                             "`done` (mark completed), `block` (mark as blocked -- provide reason), "
                             "`unblock` (remove blocked status), `backlog` (move back to backlog), "
                             "`reopen` (reopen a closed ticket)."),
              "reason": _str("Explanation for the transition. Required for `block` (what's blocking it?) "
                             "and recommended for `unblock` (what changed?). Helpful for audit trail on any transition. "
                             "Example: `Waiting on API key from third-party vendor`"),
          },
          ["ticket_id", "action"]),

    # ── Tickets -- Comments ───────────────────────────────────
    _tool("devantis_add_ticket_comment",
          "Add a comment to a ticket's discussion thread. Comments support full markdown formatting "
          "including code blocks, links, and lists. Use this to leave notes, ask questions, document "
          "decisions, or provide status updates on a ticket.",
          {
              "ticket_id": _str("UUID of the ticket to comment on. "
                                "Example: `a1b2c3d4-e5f6-7890-abcd-ef1234567890`"),
              "content": _str("Comment text in markdown format. Supports headings, code blocks, lists, "
                              "bold/italic, and links. Example: `Investigated the issue -- root cause is "
                              "a race condition in the session handler. See \\`src/session.py:142\\`.`"),
          },
          ["ticket_id", "content"]),

    _tool("devantis_list_ticket_comments",
          "Retrieve all comments on a ticket in chronological order. Use this to read the discussion "
          "history, understand context from previous conversations, or check if a question was already "
          "answered before adding a new comment.",
          {"ticket_id": _str("UUID of the ticket whose comments to retrieve. "
                             "Example: `a1b2c3d4-e5f6-7890-abcd-ef1234567890`")},
          ["ticket_id"]),

    # ── Tickets -- Labels ─────────────────────────────────────
    _tool("devantis_manage_labels",
          "Manage the project's label system for categorizing tickets. Labels are shared across all "
          "tickets and can be used for filtering, reporting, and organization. Use this to create "
          "new labels, see available labels, or attach/detach labels from specific tickets.",
          {
              "action": _str("Operation to perform. Valid values: `list` (get all available labels), "
                             "`create` (create a new label -- requires name), `delete` (remove a label -- requires label_id), "
                             "`add_to_ticket` (attach label to ticket -- requires label_id + ticket_id), "
                             "`remove_from_ticket` (detach label from ticket -- requires label_id + ticket_id), "
                             "`get_ticket_labels` (list labels on a specific ticket -- requires ticket_id)."),
              "name": _str("Display name for the new label. Required for `create` action. "
                           "Example: `security`, `breaking-change`, `needs-design`"),
              "color": _str("Hex color code for the label badge. Used for `create` action. "
                            "Example: `#ff4444` (red), `#44bb44` (green), `#4488ff` (blue)"),
              "label_id": _str("UUID of the label. Required for `delete`, `add_to_ticket`, and `remove_from_ticket`. "
                               "Use action=`list` to discover label IDs."),
              "ticket_id": _str("UUID of the ticket. Required for `add_to_ticket`, `remove_from_ticket`, "
                                "and `get_ticket_labels`."),
          },
          ["action"]),

    # ── Tickets -- Subtasks ───────────────────────────────────
    _tool("devantis_manage_subtasks",
          "Manage subtasks (checklist items) on a ticket. Subtasks break a ticket into smaller, "
          "trackable units of work that can be individually completed. Use this to create implementation "
          "checklists, track progress on multi-step tasks, or decompose complex tickets.",
          {
              "action": _str("Operation to perform. Valid values: `list` (get all subtasks on the ticket), "
                             "`create` (add a new subtask -- requires title), `update` (modify a subtask -- "
                             "requires subtask_id), `delete` (remove a subtask -- requires subtask_id)."),
              "ticket_id": _str("UUID of the parent ticket that owns the subtasks. Required for all actions."),
              "subtask_id": _str("UUID of the specific subtask. Required for `update` and `delete` actions. "
                                 "Use action=`list` to discover subtask IDs."),
              "title": _str("Subtask title. Required for `create`, optional for `update`. "
                            "Example: `Write unit tests for auth middleware`"),
              "description": _str("Optional detailed description of the subtask. "
                                  "Example: `Cover both valid and expired token scenarios`"),
              "is_completed": _bool("Set to true to mark the subtask as done, false to mark as incomplete. "
                                    "Used with `update` action to track progress."),
          },
          ["action", "ticket_id"]),

    # ── Tickets -- Links ──────────────────────────────────────
    _tool("devantis_manage_links",
          "Create, list, or delete typed relationships between tickets. Links capture dependencies, "
          "duplicates, and parent-child hierarchies. Use this to document that one ticket blocks another, "
          "mark duplicates, or organize tickets into parent-child structures.",
          {
              "action": _str("Operation to perform. Valid values: `list` (show all links on a ticket), "
                             "`create` (create a new link -- requires target_ticket_id + link_type), "
                             "`delete` (remove a link -- requires link_id)."),
              "ticket_id": _str("UUID of the source ticket (the 'from' side of the relationship). "
                                "Required for all actions."),
              "target_ticket_id": _str("UUID of the target ticket (the 'to' side of the relationship). "
                                       "Required for `create` action."),
              "link_type": _str("Type of relationship between the two tickets. Required for `create`. "
                                "Valid values: `BLOCKS` (source blocks target), `BLOCKED_BY` (source is blocked by target), "
                                "`DUPLICATES` (source duplicates target), `DUPLICATED_BY` (source is duplicated by target), "
                                "`RELATES_TO` (general relation), `PARENT_OF` (source is parent of target), "
                                "`CHILD_OF` (source is child of target)."),
              "link_id": _str("UUID of the link to remove. Required for `delete` action. "
                              "Use action=`list` to discover link IDs."),
          },
          ["action", "ticket_id"]),

    # ── Tickets -- Watchers & Voting ──────────────────────────
    _tool("devantis_ticket_watch",
          "Manage watchers on a ticket. Watchers receive notifications when the ticket is updated. "
          "Use this to subscribe to ticket updates, see who is following a ticket, or unsubscribe "
          "from notifications you no longer need.",
          {
              "action": _str("Operation to perform. Valid values: `list` (show all watchers on the ticket), "
                             "`watch` (subscribe the current user to ticket notifications), "
                             "`unwatch` (unsubscribe the current user from ticket notifications)."),
              "ticket_id": _str("UUID of the ticket to watch/unwatch or list watchers for."),
          },
          ["action", "ticket_id"]),

    _tool("devantis_ticket_vote",
          "Manage votes on a ticket. Votes signal interest or priority from team members -- higher "
          "vote counts indicate tickets the team wants addressed. Use this to upvote important tickets, "
          "remove your vote, or check how many votes a ticket has.",
          {
              "action": _str("Operation to perform. Valid values: `get` (get current vote count and voters), "
                             "`vote` (add the current user's vote to the ticket), "
                             "`unvote` (remove the current user's vote from the ticket)."),
              "ticket_id": _str("UUID of the ticket to vote on or check votes for."),
          },
          ["action", "ticket_id"]),

    # ── Tickets -- Time Logs ──────────────────────────────────
    _tool("devantis_ticket_timelog",
          "Track time spent working on a ticket. Time logs record hours worked, what was done, and "
          "when. Use this to log your work hours, review time spent by the team, or remove incorrect "
          "time entries for accurate project tracking and reporting.",
          {
              "action": _str("Operation to perform. Valid values: `list` (show all time entries on the ticket), "
                             "`log` (record time spent -- requires hours_spent), "
                             "`delete` (remove a time entry -- requires log_id)."),
              "ticket_id": _str("UUID of the ticket to log time against or list time entries for."),
              "hours_spent": {"type": "number", "description": "Number of hours spent working. Supports decimals "
                              "for partial hours. Required for `log` action. Examples: 0.5 (30 min), 1.5 (1h 30m), 8 (full day)."},
              "description": _str("Brief description of work performed. Used with `log` action. "
                                  "Example: `Debugged authentication timeout issue`, `Code review and testing`"),
              "work_date": _str("Date when the work was performed, in ISO 8601 format. Used with `log` action. "
                                "Example: `2025-03-15`. Defaults to today if omitted."),
              "log_id": _str("UUID of the time log entry to remove. Required for `delete` action. "
                             "Use action=`list` to discover log IDs."),
          },
          ["action", "ticket_id"]),

    # ── Tickets -- Milestones ─────────────────────────────────
    _tool("devantis_manage_milestones",
          "Manage project milestones -- named checkpoints with due dates that group related tickets. "
          "Milestones represent release targets, project phases, or delivery deadlines. Use this to "
          "create milestones, track progress toward them, and assign/unassign tickets to milestones.",
          {
              "action": _str("Operation to perform. Valid values: `list` (show all milestones, optionally filtered "
                             "by status), `create` (create a new milestone -- requires name), `update` (modify a "
                             "milestone -- requires milestone_id), `delete` (remove a milestone -- requires milestone_id), "
                             "`add_ticket` (assign a ticket to a milestone -- requires milestone_id + ticket_id), "
                             "`remove_ticket` (unassign a ticket from a milestone -- requires milestone_id + ticket_id)."),
              "milestone_id": _str("UUID of the milestone. Required for `update`, `delete`, `add_ticket`, `remove_ticket`. "
                                   "Use action=`list` to discover milestone IDs."),
              "ticket_id": _str("UUID of the ticket to assign or unassign. Required for `add_ticket` and `remove_ticket`."),
              "name": _str("Milestone display name. Required for `create`, optional for `update`. "
                           "Example: `v1.0 Release`, `Q2 Security Hardening`, `Beta Launch`"),
              "description": _str("Description of what this milestone represents and its goals. "
                                  "Example: `All authentication features complete and tested`"),
              "due_date": _str("Target completion date in ISO 8601 format. Example: `2025-06-30`"),
              "status": _str("Filter milestones by status when using `list` action. "
                             "Valid values: `open`, `closed`. Omit to list all."),
          },
          ["action"]),

    # ── Tickets -- Components ─────────────────────────────────
    _tool("devantis_manage_components",
          "Manage project components -- named subsystems or modules that tickets can be categorized under. "
          "Components represent distinct areas of the codebase (e.g., 'API Layer', 'Auth Module', 'Database'). "
          "Use this to organize tickets by technical area and track which subsystems have the most work.",
          {
              "action": _str("Operation to perform. Valid values: `list` (show all components), "
                             "`create` (create a new component -- requires name), "
                             "`delete` (remove a component -- requires component_id), "
                             "`add_ticket` (assign a ticket to a component -- requires component_id + ticket_id)."),
              "component_id": _str("UUID of the component. Required for `delete` and `add_ticket`. "
                                   "Use action=`list` to discover component IDs."),
              "ticket_id": _str("UUID of the ticket to assign to the component. Required for `add_ticket`."),
              "name": _str("Component display name. Required for `create`. "
                           "Example: `API Gateway`, `Auth Module`, `Payment Processing`, `CI/CD Pipeline`"),
              "description": _str("Description of what this component covers. Used with `create`. "
                                  "Example: `All REST API endpoints and middleware`"),
          },
          ["action"]),

    # ── Tickets -- Filters ────────────────────────────────────
    _tool("devantis_manage_filters",
          "Manage saved ticket filters -- reusable query presets that can be shared with the team. "
          "Use this to create commonly-used filter combinations (e.g., 'My Critical Bugs', 'Sprint "
          "Blockers'), execute saved filters to get matching tickets, or manage existing filters.",
          {
              "action": _str("Operation to perform. Valid values: `list` (show all saved filters), "
                             "`create` (save a new filter -- requires name + filter_query), "
                             "`execute` (run a saved filter and return matching tickets -- requires filter_id), "
                             "`delete` (remove a saved filter -- requires filter_id)."),
              "filter_id": _str("UUID of the saved filter. Required for `execute` and `delete`. "
                                "Use action=`list` to discover filter IDs."),
              "name": _str("Display name for the saved filter. Required for `create`. "
                           "Example: `My Open Bugs`, `Sprint 5 High Priority`, `Unassigned Backend Tasks`"),
              "filter_query": _obj("Filter criteria object for `create`. Supported keys: "
                                   "`status` (ticket status), `priority` (ticket priority), `assignee` (username), "
                                   "`epic_id` (epic UUID), `sprint_id` (sprint UUID), `search_text` (full-text search). "
                                   "Example: {\"status\": \"in_progress\", \"priority\": \"critical\"}"),
              "is_public": _bool("Whether the filter should be visible to all team members. Default: false (private). "
                                 "Set to true to share useful filters with the team."),
          },
          ["action"]),

    # ── Tickets -- Boards ─────────────────────────────────────
    _tool("devantis_get_board",
          "Get a visual board view of tickets organized into columns by a grouping criterion. "
          "Returns tickets grouped into lanes for Kanban-style visualization. Use this to see project "
          "status at a glance, identify bottlenecks, or review work distribution across the team.",
          {
              "board_type": _str("How to group tickets into columns. Valid values: `kanban` (group by workflow "
                                 "status: backlog/open/in_progress/review/testing/done), `by-assignee` (group by "
                                 "who's assigned), `by-feature` (group by feature area), `by-priority` (group by "
                                 "priority level). Default: `kanban`."),
              "feature": _str("Filter board to only show tickets from a specific feature group. "
                              "Example: `authentication`, `billing`"),
              "sprint_id": _str("Filter board to only show tickets in a specific sprint. "
                                "Use devantis_manage_sprints with action=`list` to find sprint IDs."),
              "epic_id": _str("Filter board to only show tickets in a specific epic. "
                              "Use devantis_manage_epics with action=`list` to find epic IDs."),
          }),

    # ── Tickets -- Charts ─────────────────────────────────────
    _tool("devantis_get_chart",
          "Get chart data for sprint and project analytics. Returns data points for rendering burndown, "
          "burnup, cumulative flow, or velocity charts. Use this when the user asks about sprint progress, "
          "team velocity trends, or work-in-progress over time.",
          {
              "chart_type": _str("Type of chart data to generate. Valid values: `burndown` (remaining work in a "
                                 "sprint over time -- requires sprint_id), `burnup` (completed work in a sprint over "
                                 "time -- requires sprint_id), `cumulative_flow` (ticket count by status over a "
                                 "time window -- uses days param), `velocity` (tickets completed per sprint over "
                                 "recent sprints -- uses sprints param)."),
              "sprint_id": _str("UUID of the sprint. Required for `burndown` and `burnup` chart types. "
                                "Use devantis_manage_sprints with action=`list` to find sprint IDs."),
              "days": _int("Number of days to look back for `cumulative_flow` chart. Default: 30. "
                           "Example: 7 (one week), 30 (one month), 90 (one quarter)."),
              "sprints": _int("Number of recent sprints to include in `velocity` chart. Default: 6. "
                              "Example: 3 (last 3 sprints), 10 (last 10 sprints)."),
          },
          ["chart_type"]),

    # ── Tickets -- Stats ──────────────────────────────────────
    _tool("devantis_ticket_stats",
          "Get aggregate ticket statistics for the current project -- counts broken down by status, "
          "ticket type, and priority level. Use this for quick project health checks, dashboards, or "
          "when the user asks 'how many tickets' questions. Much faster than listing all tickets and counting.",
          {}),

    # ══════════════════════════════════════════════════════════
    # SPRINTS
    # ══════════════════════════════════════════════════════════
    _tool("devantis_manage_sprints",
          "Manage sprints -- time-boxed iterations for organizing and delivering work. Sprints have a "
          "name, goal, start/end dates, and contain tickets. Use this to plan sprints, start/complete them, "
          "and add or remove tickets. Also use to list sprints when you need sprint IDs for other tools.",
          {
              "action": _str("Operation to perform. Valid values: `list` (show sprints, optionally filtered by "
                             "status), `get` (get sprint details -- requires sprint_id), `create` (create a new "
                             "sprint -- requires name + start_date + end_date), `update` (modify sprint -- requires "
                             "sprint_id), `delete` (remove sprint -- requires sprint_id), `start` (activate a "
                             "planning sprint -- requires sprint_id), `complete` (close an active sprint -- "
                             "requires sprint_id), `get_tickets` (list tickets in sprint -- requires sprint_id), "
                             "`add_ticket` (add ticket to sprint -- requires sprint_id + ticket_id), "
                             "`remove_ticket` (remove ticket from sprint -- requires sprint_id + ticket_id)."),
              "sprint_id": _str("UUID of the sprint. Required for `get`, `update`, `delete`, `start`, `complete`, "
                                "`get_tickets`, `add_ticket`, `remove_ticket`."),
              "ticket_id": _str("UUID of the ticket to add or remove. Required for `add_ticket` and `remove_ticket`."),
              "name": _str("Sprint name. Required for `create`, optional for `update`. "
                           "Example: `Sprint 12`, `Sprint 2025-W15`, `March Iteration`"),
              "goal": _str("Sprint goal describing what the team aims to deliver. "
                           "Example: `Complete user authentication and session management`"),
              "start_date": _str("Sprint start date in ISO 8601 format. Required for `create`. Example: `2025-04-01`"),
              "end_date": _str("Sprint end date in ISO 8601 format. Required for `create`. Example: `2025-04-14`"),
              "status": _str("Filter sprints by status when using `list` action. Valid values: `planning` (not yet "
                             "started), `active` (currently in progress), `completed` (finished). Omit to list all."),
          },
          ["action"]),

    # ══════════════════════════════════════════════════════════
    # EPICS
    # ══════════════════════════════════════════════════════════
    _tool("devantis_manage_epics",
          "Manage epics -- large bodies of work that span multiple tickets and potentially multiple sprints. "
          "Epics group related tickets under a common theme or initiative. Use this to create high-level "
          "work packages, track their progress, and organize tickets into meaningful groups.",
          {
              "action": _str("Operation to perform. Valid values: `list` (show epics, optionally filtered by "
                             "status), `get` (get epic details -- requires epic_id), `create` (create a new "
                             "epic -- requires name), `update` (modify epic -- requires epic_id), `delete` "
                             "(remove epic -- requires epic_id), `get_tickets` (list tickets in epic -- requires "
                             "epic_id), `add_ticket` (add ticket to epic -- requires epic_id + ticket_id), "
                             "`remove_ticket` (remove ticket from epic -- requires epic_id + ticket_id)."),
              "epic_id": _str("UUID or key of the epic. Required for `get`, `update`, `delete`, `get_tickets`, "
                              "`add_ticket`, `remove_ticket`. Key format example: `EPIC-001`."),
              "ticket_id": _str("UUID of the ticket to add or remove. Required for `add_ticket` and `remove_ticket`."),
              "name": _str("Epic name. Required for `create`, optional for `update`. "
                           "Example: `User Authentication System`, `Payment Gateway Integration`"),
              "summary": _str("Short one-line summary of the epic's purpose. "
                              "Example: `Implement OAuth2 + MFA for all user-facing endpoints`"),
              "description": _str("Full description of the epic including goals, scope, and success criteria. "
                                  "Supports markdown."),
              "color": _str("Hex color code for visual identification on boards and charts. "
                            "Example: `#7c3aed` (purple), `#059669` (green), `#dc2626` (red)"),
              "status": _str("Filter epics by status when using `list` action. Valid values: `to_do` (not started), "
                             "`in_progress` (actively being worked), `done` (completed). Omit to list all."),
          },
          ["action"]),

    # ══════════════════════════════════════════════════════════
    # REQUIREMENTS
    # ══════════════════════════════════════════════════════════
    _tool("devantis_list_requirements",
          "List project requirements with optional filters for status, feature, and priority. Requirements "
          "are formal specifications of what the system should do. Use this to browse existing requirements, "
          "check what has been approved, or find requirements for a specific feature area.",
          {
              "status": _str("Filter by requirement lifecycle status. Valid values: `draft` (initial write-up), "
                             "`pending_review` (submitted for approval), `approved` (accepted for implementation), "
                             "`rejected` (not accepted), `in_progress` (actively being implemented), "
                             "`implemented` (code complete), `deprecated` (no longer relevant). Omit for all."),
              "feature": _str("Filter by feature group. Example: `authentication`, `billing`, `reporting`"),
              "priority": _str("Filter by priority level. Valid values: `critical`, `high`, `medium`, `low`."),
              "page": _int("Page number for pagination, starting at 1. Default: 1."),
              "page_size": _int("Number of requirements per page. Default: 30. Max recommended: 100."),
          }),

    _tool("devantis_get_requirement",
          "Get the full details of a single requirement including its title, description, status, priority, "
          "acceptance criteria, tags, and notes. Use this when you need to understand the complete specification "
          "for a feature before implementing it or creating tickets from it.",
          {"requirement_id": _str("UUID of the requirement to retrieve. "
                                  "Example: `a1b2c3d4-e5f6-7890-abcd-ef1234567890`")},
          ["requirement_id"]),

    _tool("devantis_create_requirement",
          "Create a new formal requirement specification. Requirements should be thorough and detailed -- "
          "write descriptions of 200+ words covering purpose, scope, constraints, and technical considerations. "
          "Include 10-15 testable acceptance criteria. Use this to document what the system should do before "
          "creating implementation tickets.",
          {
              "title": _str("Clear, specific title that summarizes the requirement. Should be unique and descriptive. "
                            "Example: `OAuth2 Authorization Code Flow for External Identity Providers`"),
              "description": _str("Thorough description (200+ words) covering: purpose and business value, scope "
                                  "and boundaries, technical constraints, dependencies on other features, and edge cases. "
                                  "Supports markdown formatting."),
              "feature": _str("Feature category this requirement belongs to. Used for organization and filtering. "
                              "Example: `authentication`, `billing`, `user-management`, `reporting`"),
              "type": _str("Requirement classification. Valid values: `functional` (what the system does), "
                           "`non_functional` (performance, scalability, reliability constraints), `security` "
                           "(authentication, authorization, data protection), `performance` (speed, throughput, "
                           "resource usage). Default: `functional`."),
              "priority": _str("Priority level. Valid values: `critical` (must have for launch), `high` "
                               "(important, schedule soon), `medium` (normal priority), `low` (nice to have)."),
              "acceptance_criteria": _arr("List of 10-15 specific, testable conditions that define when this "
                                          "requirement is fully satisfied. Each criterion should be independently "
                                          "verifiable. Example: [`User can initiate OAuth2 flow with Google`, "
                                          "`Tokens are refreshed automatically before expiry`, "
                                          "`Failed auth attempts are rate-limited to 5/minute`]",
                                          {"type": "string"}),
              "tags": _arr("Categorization tags for cross-referencing. Example: [`security`, `mvp`, `external-api`]",
                           {"type": "string"}),
              "notes": _str("Additional implementation guidance, risk assessments, or technical notes for the "
                            "development team. Example: `Consider using PKCE for public clients. "
                            "Token storage must use httpOnly cookies, not localStorage.`"),
          },
          ["title", "description", "feature"]),

    _tool("devantis_update_requirement",
          "Update one or more fields on an existing requirement. Only fields you provide will be changed; "
          "omitted fields remain untouched. Use this to refine specifications, change status through "
          "the review lifecycle, or update acceptance criteria based on feedback.",
          {
              "requirement_id": _str("UUID of the requirement to update."),
              "title": _str("New title to replace the current one."),
              "description": _str("New description to replace the current one."),
              "status": _str("New lifecycle status. Valid values: `draft`, `pending_review`, `approved`, "
                             "`rejected`, `in_progress`, `implemented`, `deprecated`."),
              "priority": _str("New priority level. Valid values: `critical`, `high`, `medium`, `low`."),
              "acceptance_criteria": _arr("New acceptance criteria. WARNING: This REPLACES all existing criteria -- "
                                          "include any you want to keep.", {"type": "string"}),
              "tags": _arr("New tag set. WARNING: This REPLACES all existing tags -- include any you want to keep.",
                           {"type": "string"}),
              "notes": _str("New implementation notes to replace the current ones."),
          },
          ["requirement_id"]),

    _tool("devantis_delete_requirement",
          "Permanently delete a requirement from the project. This removes the requirement and all "
          "associated data. This action cannot be undone. Consider changing status to `deprecated` "
          "instead if you want to preserve the history.",
          {"requirement_id": _str("UUID of the requirement to permanently delete.")},
          ["requirement_id"]),

    # ══════════════════════════════════════════════════════════
    # ARCHITECTURE
    # ══════════════════════════════════════════════════════════
    _tool("devantis_list_architecture",
          "List all architecture documents in the project -- both text documents (markdown specs, ADRs) "
          "and diagrams (DrawIO files). Use this to discover what architecture documentation exists, "
          "browse by folder, or find a specific document before reading it.",
          {"folder": _str("Filter to documents within a specific folder. Omit to list all architecture "
                          "documents. Example: `decisions`, `diagrams`, `api-specs`")}),

    _tool("devantis_read_architecture",
          "Read the full content of an architecture document. Markdown documents are returned as-is. "
          "DrawIO XML diagrams are automatically converted to a human-readable text representation. "
          "Use this to understand system design, review architecture decisions, or check existing specs "
          "before proposing changes.",
          {"architecture_id": _str("Document identifier (typically the filename without extension). "
                                   "Use devantis_list_architecture to discover available document IDs. "
                                   "Example: `system-overview`, `auth-flow-diagram`, `adr-001-database-choice`")},
          ["architecture_id"]),

    _tool("devantis_create_architecture",
          "Create a new architecture document in the project. Use this to add design specs, architecture "
          "decision records (ADRs), system diagrams, or technical documentation. Markdown documents "
          "support full formatting; diagrams should be in DrawIO XML format.",
          {
              "id": _str("Document identifier that becomes the filename. Use kebab-case without extension. "
                         "Example: `system-overview`, `auth-flow`, `adr-003-caching-strategy`"),
              "content": _str("Document content. For `document` type: markdown text. For `diagram` type: "
                              "DrawIO XML content. Supports full markdown formatting for documents."),
              "file_type": _str("Type of architecture document. Valid values: `document` (markdown text "
                                "-- specs, ADRs, guides) or `diagram` (DrawIO XML visual diagram). Default: `document`."),
              "folder": _str("Folder to create the document in. Will be created if it doesn't exist. "
                             "Example: `decisions`, `diagrams`, `api-specs`"),
          },
          ["id", "content"]),

    _tool("devantis_update_architecture",
          "Update the content of an existing architecture document. Completely replaces the document "
          "content. Use devantis_read_architecture first to get the current content, then modify and "
          "write back. Use this for maintaining living documentation as the system evolves.",
          {
              "architecture_id": _str("Document identifier to update. "
                                      "Example: `system-overview`, `auth-flow-diagram`"),
              "content": _str("New content to completely replace the existing document. "
                              "For markdown documents: full markdown text. For diagrams: complete DrawIO XML."),
          },
          ["architecture_id", "content"]),

    _tool("devantis_delete_architecture",
          "Permanently delete an architecture document. This action cannot be undone. Use this to remove "
          "outdated or superseded architecture documentation.",
          {"architecture_id": _str("Document identifier to delete. "
                                   "Example: `old-system-overview`, `deprecated-auth-flow`")},
          ["architecture_id"]),

    _tool("devantis_search_architecture",
          "Search architecture documents by name or content keywords. Use this when you need to find "
          "architecture docs related to a specific topic but don't know the exact document name.",
          {"query": _str("Search text to match against document names and content. "
                         "Example: `authentication`, `database schema`, `microservice boundary`")},
          ["query"]),

    # ══════════════════════════════════════════════════════════
    # DESIGNS
    # ══════════════════════════════════════════════════════════
    _tool("devantis_list_designs",
          "List all design files in the project -- HTML mockups, CSS stylesheets, design tokens, "
          "documentation, and diagrams. Use this to discover what design assets exist, browse by "
          "folder or file type, or find a specific design file before reading it.",
          {
              "folder": _str("Filter to files within a specific folder. Omit to list all design files. "
                             "Example: `components`, `pages`, `tokens`"),
              "file_type": _str("Filter by design file type. Valid values: `html` (HTML mockups/prototypes), "
                                "`css` (stylesheets), `tokens` (design tokens -- colors, spacing, typography), "
                                "`document` (markdown design docs), `diagram` (DrawIO design diagrams). "
                                "Omit to list all types."),
          }),

    _tool("devantis_read_design",
          "Read the full content of a design file. Use this to inspect HTML mockups, CSS styles, "
          "design token definitions, or design documentation before making changes.",
          {"design_id": _str("Design file identifier. Use devantis_list_designs to discover available IDs. "
                             "Example: `button-component`, `color-tokens`, `landing-page-mockup`")},
          ["design_id"]),

    _tool("devantis_create_design",
          "Create a new design file in the project. Use this to add HTML prototypes, CSS stylesheets, "
          "design token definitions, design documentation, or visual diagrams.",
          {
              "id": _str("File identifier that becomes the filename. Use kebab-case without extension. "
                         "Example: `button-component`, `color-tokens`, `dashboard-layout`"),
              "content": _str("Complete file content. Format depends on file_type: HTML markup for `html`, "
                              "CSS rules for `css`, JSON for `tokens`, markdown for `document`, "
                              "DrawIO XML for `diagram`."),
              "file_type": _str("Type of design file to create. Valid values: `html` (HTML mockups/prototypes), "
                                "`css` (stylesheets), `tokens` (design tokens JSON -- colors, spacing, typography), "
                                "`document` (markdown design documentation), `diagram` (DrawIO XML visual diagram)."),
              "folder": _str("Folder to create the file in. Will be created if it doesn't exist. "
                             "Example: `components`, `pages`, `tokens`"),
          },
          ["id", "content", "file_type"]),

    _tool("devantis_update_design",
          "Update the content of an existing design file. Completely replaces the file content. "
          "Read the file first with devantis_read_design to see current content before overwriting.",
          {
              "design_id": _str("File identifier to update. Example: `button-component`, `color-tokens`"),
              "content": _str("New content to completely replace the existing file."),
          },
          ["design_id", "content"]),

    _tool("devantis_delete_design",
          "Permanently delete a design file. This action cannot be undone. Use this to remove "
          "outdated mockups, deprecated stylesheets, or superseded design documents.",
          {"design_id": _str("File identifier to delete. Example: `old-button-component`, `legacy-tokens`")},
          ["design_id"]),

    _tool("devantis_search_designs",
          "Search design files by name or content keywords, optionally filtered by file type. Use this "
          "when looking for design assets related to a specific component, page, or concept.",
          {
              "query": _str("Search text to match against file names and content. "
                            "Example: `button`, `navigation`, `color palette`"),
              "file_type": _str("Narrow search to a specific file type. Valid values: `html`, `css`, "
                                "`tokens`, `document`, `diagram`. Omit to search all types."),
          }),

    # ══════════════════════════════════════════════════════════
    # CHAT -- Full Interactive Support
    # ══════════════════════════════════════════════════════════
    _tool("devantis_chat_session",
          "Manage the active chat session. By default, each devantis_chat_send creates a new session. "
          "Use this tool to SET a persistent session (all subsequent sends reuse it), START a fresh one, "
          "or CLEAR it (back to creating new sessions each time). This is how you have multi-turn "
          "conversations with the AI assistant.",
          {
              "action": _str("`set` (reuse an existing session ID for all future sends), "
                             "`start` (create a new session and make it the active one), "
                             "`clear` (stop reusing — each send creates a new session), "
                             "`get` (show the current active session ID, if any)"),
              "session_id": _str("Session UUID to set as active. Required for `set`. "
                                 "Use devantis_chat_sessions to find existing session IDs."),
          },
          ["action"]),

    _tool("devantis_chat_send",
          "Send a message to the platform's built-in AI assistant and wait for a response. The assistant "
          "can execute workflows, write code, create tickets, analyze the codebase, and more. "
          "If the workflow pauses for approval, it returns status='waiting_for_input' with the question -- "
          "use devantis_chat_answer to respond and resume the workflow. "
          "If an active session is set (via devantis_chat_session), messages are sent to that session "
          "automatically, maintaining conversation context across calls.",
          {
              "message": _str("Message to send to the AI assistant. Can be a question, instruction, or request. "
                              "Examples: `Implement the login page`, `How does the auth system work?`, "
                              "`Create tickets for the billing feature`"),
              "session_id": _str("UUID of an existing chat session to continue the conversation. "
                                 "Omit to use the active session (if set via devantis_chat_session) or start a new one."),
              "timeout": _int("Maximum seconds to wait for the AI assistant's response before timing out. "
                              "Default: 300 (5 minutes). Set higher for complex tasks (e.g., 600 for implementation)."),
          },
          ["message"]),

    _tool("devantis_chat_answer",
          "Answer a question from a paused AI workflow. Use this ONLY after devantis_chat_send returns "
          "status='waiting_for_input' -- it means the AI assistant paused to ask for clarification or "
          "approval. Your answer resumes the workflow from where it left off. "
          "If an active session is set, session_id is optional.",
          {
              "session_id": _str("UUID of the chat session that is waiting for input. "
                                 "Optional if an active session is set via devantis_chat_session."),
              "answer": _str("Your answer to the AI assistant's question. This could be approval ('Yes, proceed'), "
                             "a choice ('Option B'), clarification, or any free-text response."),
              "timeout": _int("Maximum seconds to wait for the resumed workflow's response. Default: 300 (5 minutes). "
                              "Set higher for complex tasks that may take longer after resuming."),
          },
          ["answer"]),

    _tool("devantis_chat_confirm",
          "Confirm or reject a proposal from a paused AI workflow that requires explicit approval. "
          "This is different from devantis_chat_answer -- use this when the workflow presents a structured "
          "proposal (e.g., a CRUD operation or deployment plan) that needs a boolean approve/reject decision. "
          "If an active session is set, session_id is optional.",
          {
              "session_id": _str("UUID of the chat session with the pending proposal. "
                                 "Optional if an active session is set via devantis_chat_session."),
              "job_id": _str("Job identifier from the waiting_for_input response data. This identifies the specific "
                             "workflow job that is waiting for confirmation."),
              "approved": _bool("Set to true to approve and execute the proposal, or false to reject it and "
                                "cancel the proposed action."),
              "timeout": _int("Maximum seconds to wait for the workflow's response after confirmation. "
                              "Default: 300 (5 minutes)."),
          },
          ["job_id", "approved"]),

    _tool("devantis_chat_history",
          "Retrieve the complete raw conversation history of a chat session. Returns all messages (user "
          "and assistant) with role, content, timestamps, and image references. Also includes any "
          "in-progress streaming content and pending waiting_for_input prompts. Use this to review what "
          "the AI assistant did, analyse its decisions, or resume context from a previous conversation. "
          "If an active session is set, session_id is optional.",
          {"session_id": _str("UUID of the chat session to retrieve history for. "
                              "Optional if an active session is set via devantis_chat_session. "
                              "Use devantis_chat_sessions to find session IDs.")}),

    _tool("devantis_chat_sessions",
          "List recent chat sessions for the current user, ordered by most recent first. Returns session "
          "IDs, creation dates, and preview information. Use this to find a session to continue or to "
          "review past conversations.",
          {"page_size": _int("Number of sessions to return. Default: 20. Set lower for a quick glance, "
                             "higher to browse further back in history.")}),

    _tool("devantis_chat_stop",
          "Cancel a currently running AI workflow in a chat session. Use this to abort a long-running "
          "operation that is taking too long or going in the wrong direction. The session remains "
          "available for new messages after cancellation. "
          "If an active session is set, session_id is optional.",
          {"session_id": _str("UUID of the chat session to cancel. "
                              "Optional if an active session is set via devantis_chat_session.")}),

    _tool("devantis_chat_delete",
          "Permanently delete a chat session and all its conversation history. This action cannot be "
          "undone. Use this to clean up old or irrelevant sessions. "
          "If an active session is set, session_id is optional.",
          {"session_id": _str("UUID of the chat session to delete. "
                              "Optional if an active session is set via devantis_chat_session.")}),

    # ══════════════════════════════════════════════════════════
    # KNOWLEDGE GRAPH (Brain)
    # ══════════════════════════════════════════════════════════
    _tool("devantis_kg_search",
          "Search the project's knowledge graph (AI brain) for entities and their observations. The brain "
          "stores structured knowledge about the codebase -- services, patterns, decisions, error solutions, "
          "and architectural concepts. Use this BEFORE making changes to check if the brain has relevant "
          "context, patterns, or gotchas about the area you're working in.",
          {
              "query": _str("Search text to find relevant knowledge. Can be a keyword, concept, or question. "
                            "Examples: `authentication`, `database connection pooling`, `rate limiting pattern`"),
              "entity_type": _str("Narrow search to a specific entity type. Common values: `service` (microservices), "
                                  "`pattern` (design patterns), `decision` (architecture decisions), `error` (known "
                                  "error patterns and solutions), `component` (system components), `concept` "
                                  "(technical concepts). Omit to search all types."),
          },
          ["query"]),

    _tool("devantis_kg_get_entity",
          "Get a specific knowledge graph entity with all its observations (facts, corrections, gotchas). "
          "Use this when you know the exact entity name and want its complete knowledge record. Observations "
          "include facts, corrections to previous facts, gotchas to watch out for, and cached data.",
          {"name": _str("Exact name of the knowledge graph entity. Entity names are typically kebab-case or "
                        "descriptive phrases. Examples: `user-service`, `jwt-auth-pattern`, `postgres-connection-pool`")},
          ["name"]),

    _tool("devantis_kg_add",
          "Add structured knowledge to the project's brain. Creates a new entity with observations, or "
          "adds observations to an existing entity. Use this to record high-level insights, architectural "
          "decisions, discovered patterns, or important gotchas that should persist across sessions. "
          "Only record significant, reusable knowledge -- not transient implementation details.",
          {
              "name": _str("Entity name. Use descriptive, kebab-case names. Examples: `user-auth-service`, "
                           "`rate-limiting-pattern`, `adr-redis-caching`"),
              "entity_type": _str("Classification of the entity. Valid values: `service` (a microservice or API), "
                                  "`pattern` (a design/code pattern), `decision` (an architecture decision record), "
                                  "`error` (a known error pattern and its solution), `component` (a system component), "
                                  "`concept` (a technical concept or domain term)."),
              "observations": _arr("List of observation objects to attach to the entity. Each observation should "
                                   "have `content` (text) and optionally `kind` (fact/correction/gotcha/cached). "
                                   "Example: [{\"content\": \"Uses JWT with 15-minute expiry\", \"kind\": \"fact\"}]",
                                   {"type": "object"}),
          },
          ["name", "entity_type"]),

    _tool("devantis_kg_add_observation",
          "Add a single observation to an existing knowledge graph entity. Observations are discrete facts, "
          "corrections, or gotchas attached to an entity. Use this to incrementally build knowledge -- add "
          "a new fact you discovered, correct a previous observation, or note a gotcha for future reference.",
          {
              "entity_name": _str("Name of the existing entity to add the observation to. "
                                  "Example: `user-service`, `postgres-connection-pool`"),
              "content": _str("The observation text. Should be a clear, self-contained statement. "
                              "Examples: `Requires Redis 7+ for stream support`, "
                              "`Connection timeout is 30s, not 10s as documented`, "
                              "`Must call close() explicitly or connections leak`"),
              "kind": _str("Type of observation. Valid values: `fact` (a verified truth about the entity), "
                           "`correction` (supersedes a previous incorrect fact), `gotcha` (a surprising behavior "
                           "or common mistake to watch out for), `cached` (temporary data with TTL, auto-expires). "
                           "Default: `fact`."),
          },
          ["entity_name", "content"]),

    _tool("devantis_kg_remove",
          "Remove outdated or incorrect knowledge from the brain. Use this to delete entire entities that "
          "are no longer relevant, remove specific observations that have been superseded, or delete "
          "relations that no longer hold true. Keeping the brain clean improves its usefulness.",
          {
              "action": _str("What to remove. Valid values: `delete_entity` (remove an entire entity and all its "
                             "observations -- requires entity_name), `delete_observation` (remove a single observation -- "
                             "requires entity_name + observation_id), `delete_relation` (remove a relation between "
                             "entities -- requires relation_id)."),
              "entity_name": _str("Name of the entity. Required for `delete_entity` and `delete_observation`. "
                                  "Example: `deprecated-auth-service`"),
              "observation_id": _str("UUID of the observation to remove. Required for `delete_observation`. "
                                     "Use devantis_kg_get_entity to find observation IDs."),
              "relation_id": _str("UUID of the relation to remove. Required for `delete_relation`. "
                                  "Use devantis_kg_relations with action=`list` to find relation IDs."),
          },
          ["action"]),

    _tool("devantis_kg_relations",
          "Manage typed relationships between knowledge graph entities. Relations capture how entities "
          "connect -- which services depend on others, which patterns are used where, which decisions "
          "affect which components. Use this to build a connected knowledge map.",
          {
              "action": _str("Operation to perform. Valid values: `list` (show relations, optionally filtered "
                             "by from_entity, to_entity, or relation_type), `create` (create a new relation -- "
                             "requires from_entity + to_entity + relation_type), `delete` (remove a relation -- "
                             "requires relation_id)."),
              "from_entity": _str("Source entity name (the 'from' side). Required for `create`, optional filter for `list`. "
                                  "Example: `user-service`"),
              "to_entity": _str("Target entity name (the 'to' side). Required for `create`, optional filter for `list`. "
                                "Example: `postgres-database`"),
              "relation_type": _str("Type of relationship. Required for `create`, optional filter for `list`. "
                                    "Common values: `depends_on`, `uses`, `implements`, `part_of`, `supersedes`, "
                                    "`related_to`, `blocked_by`. Example: `depends_on`"),
              "relation_id": _str("UUID of the relation to remove. Required for `delete`. "
                                  "Use action=`list` to discover relation IDs."),
          },
          ["action"]),

    _tool("devantis_kg_reason",
          "Ask the brain a question and get an LLM-powered reasoning response based on all stored "
          "knowledge. The brain searches its entities, observations, and relations to construct a "
          "context-aware answer. Use this for complex questions that require connecting multiple pieces "
          "of knowledge -- architecture questions, impact analysis, or decision guidance.",
          {"question": _str("Question to reason about using stored knowledge. "
                            "Examples: `What would break if we change the auth token format?`, "
                            "`How does data flow from the API to the database?`, "
                            "`What patterns does this project use for error handling?`")},
          ["question"]),

    _tool("devantis_kg_stats",
          "Get aggregate statistics about the knowledge graph -- total entity count, distribution by "
          "entity type, observation counts, relation counts, and quality metrics. Use this for a quick "
          "health check on how much knowledge the brain has accumulated.",
          {}),

    _tool("devantis_kg_vitals",
          "Get brain vital signs including an intelligence score, growth trends over time, and utilization "
          "metrics. This is a higher-level health view than devantis_kg_stats -- it shows whether the "
          "brain is growing, stagnating, or has quality issues that need attention.",
          {}),

    _tool("devantis_kg_impact",
          "Analyze the impact of changing a knowledge graph entity. Returns all entities that directly "
          "or transitively depend on the given entity. Use before refactoring to understand blast radius.",
          {"entity_name": _str("Entity name to analyze impact for. Example: `auth-service`, `db-schema`")},
          ["entity_name"]),

    _tool("devantis_kg_confirm_observation",
          "Mark an observation as still valid (bumps its confirmed_at timestamp). Use this to prevent "
          "the brain from flagging an observation as stale. Important for keeping knowledge fresh.",
          {
              "entity_name": _str("Entity that owns the observation"),
              "observation_id": _str("UUID of the observation to confirm"),
          },
          ["entity_name", "observation_id"]),

    _tool("devantis_kg_dependencies",
          "Trace dependency chains from a knowledge graph entity using recursive graph traversal. "
          "Follow outgoing dependencies to see what an entity depends on (and what those depend on), "
          "or follow incoming dependencies to see what depends on it (impact analysis).",
          {
              "entity_name": _str("Name of the entity to start tracing from. "
                                  "Example: `user-service`, `auth-middleware`"),
              "direction": _str("Direction to traverse. Valid values: `outgoing` (what does this entity depend "
                                "on? -- follows depends_on/uses relations forward), `incoming` (what depends on "
                                "this entity? -- reverse traversal for impact analysis). Default: `outgoing`."),
          },
          ["entity_name"]),

    # ══════════════════════════════════════════════════════════
    # EXECUTORS
    # ══════════════════════════════════════════════════════════
    _tool("devantis_executor_shell",
          "Run a shell command on a remote executor agent connected to the project's infrastructure. "
          "Use this for operations that require a running environment -- checking service health, "
          "running database queries, executing scripts, or inspecting logs on remote systems. "
          "Commands are logged for audit purposes.",
          {
              "command": _str("Shell command to execute on the remote executor. "
                              "Examples: `curl -s http://localhost:8080/health`, `psql -c 'SELECT count(*) FROM users'`, "
                              "`docker ps`, `npm test`"),
              "purpose": _str("Human-readable explanation of why this command is being run. Recorded in the "
                              "audit log. Example: `Checking API health after deployment`, "
                              "`Verifying database migration applied correctly`"),
              "tail_lines": _int("Only return the last N lines of output. Useful for commands that produce "
                                 "verbose output where only the end matters (e.g., build logs, test results). "
                                 "Example: 50 to get just the summary of a test run."),
          },
          ["command"]),

    _tool("devantis_deploy_k8s",
          "Execute a Kubernetes deployment operation via the MCP server running on the project's executor. "
          "This is the gateway to all Kubernetes operations -- deploying apps, building images, pushing to "
          "registries, scaling deployments, checking status, viewing logs, and rolling back releases. "
          "Each operation maps to a specific K8s MCP tool.",
          {
              "tool_name": _str("Name of the Kubernetes MCP tool to invoke. Valid values: `deploy_app` (deploy using "
                                "built-in Helm chart), `deploy_helm` (deploy from a Helm chart), `deploy_manifests` "
                                "(apply raw K8s YAML), `build_image` (build container image from Dockerfile), "
                                "`push_image` (push image to registry), `list_deployments` (list all deployments), "
                                "`get_deploy_status` (get deployment health + pod status), `get_deploy_logs` (get pod logs), "
                                "`scale` (scale deployment replicas), `rollback` (rollback Helm release), "
                                "`delete_deployment` (delete a deployment), `manage_namespace` (create/list/delete namespaces), "
                                "`manage_secrets` (create/list/delete K8s secrets), `configure_ingress` (set up ingress + TLS)."),
              "arguments": _obj("Arguments object for the specific K8s tool being invoked. Structure varies by tool. "
                                "Example for deploy_app: {\"name\": \"my-api\", \"image\": \"my-api:latest\", \"port\": 8080}. "
                                "Example for scale: {\"name\": \"my-api\", \"replicas\": 3}."),
              "timeout_seconds": _int("Maximum seconds to wait for the K8s operation to complete. Default: 300 (5 minutes). "
                                      "Increase for slow operations like image builds (e.g., 600)."),
          },
          ["tool_name"]),

    _tool("devantis_list_executors",
          "List all available executor agents and their current status. Executors are remote agents that "
          "can run shell commands and Kubernetes operations. Use this to check which executors are online "
          "and available before running commands or deployments.",
          {"status": _str("Filter executors by status. Valid values: `online` (healthy and accepting commands), "
                          "`offline` (not responding), `error` (connected but in error state). "
                          "Omit to list all executors regardless of status.")}),

    # ══════════════════════════════════════════════════════════
    # ANALYTICS
    # ══════════════════════════════════════════════════════════
    _tool("devantis_token_usage",
          "Get AI token usage and cost analytics for the project. Shows how many tokens have been consumed, "
          "by which models and workflows, and the associated costs. Use this when the user asks about AI "
          "spending, wants to optimize costs, or needs usage reports.",
          {
              "view": _str("Analytics view to display. Valid values: `summary` (total tokens and cost overview), "
                           "`history` (usage over time -- combine with period param), `by_model` (breakdown by "
                           "AI model), `by_workflow` (breakdown by workflow type), `by_session` (breakdown by "
                           "individual chat sessions)."),
              "period": _str("Time granularity for the `history` view. Valid values: `day` (daily breakdown), "
                             "`week` (weekly breakdown), `month` (monthly breakdown). Only used with view=`history`."),
          },
          ["view"]),

    _tool("devantis_cost_forecast",
          "Get AI cost predictions or spending alerts for the project. Forecasts extrapolate current "
          "usage trends; alerts show configured spending limits and whether they're being approached. "
          "Use this for budget planning or to check if spending is on track.",
          {"action": _str("Operation to perform. Valid values: `forecast` (projected costs based on current "
                          "usage trends -- shows estimated spend for upcoming periods), `alerts` (list configured "
                          "spending alerts and their current status -- triggered, approaching, or healthy).")},
          ["action"]),

    # ══════════════════════════════════════════════════════════
    # USERS
    # ══════════════════════════════════════════════════════════
    _tool("devantis_users_search",
          "Search for platform users by name or email address. Use this to find usernames for assigning "
          "tickets, adding team members, or looking up who someone is. Returns matching user profiles "
          "with their IDs, names, and emails.",
          {"query": _str("Search text to match against user names and email addresses. "
                         "Examples: `john`, `jane.doe@company.com`, `smith`")},
          ["query"]),

    _tool("devantis_users_me",
          "Get the profile of the currently authenticated user, including their name, email, user ID, "
          "and roles. Use this to check your own identity, find your user ID for assignments, or "
          "verify your role and permissions.",
          {}),

    # ══════════════════════════════════════════════════════════
    # TEAM MANAGEMENT
    # ══════════════════════════════════════════════════════════
    _tool("devantis_list_members",
          "List all team members at a specific organizational level -- the whole organisation, a specific "
          "project, or a specific application. Returns member names, roles, and email addresses. "
          "Use this to see who has access, check team composition, or find someone's role.",
          {"level": _str("Organizational level to list members for. Valid values: `organisation` (all org "
                         "members across all projects), `project` (members of the current project), "
                         "`app` (members of the current application).")},
          ["level"]),

    _tool("devantis_manage_members",
          "Add, update roles for, or remove team members at a specific organizational level. Use this "
          "to grant access to new team members, change someone's role (e.g., promote reader to writer), "
          "or revoke access by removing a member.",
          {
              "level": _str("Organizational level to manage members at. Valid values: `organisation` (org-wide "
                            "membership), `project` (project-level access), `app` (application-level access)."),
              "action": _str("Operation to perform. Valid values: `add` (invite a user as a member -- requires "
                             "username + role), `update` (change a member's role -- requires username + role), "
                             "`remove` (revoke membership -- requires username)."),
              "username": _str("Username of the person to manage. Use devantis_users_search to find usernames."),
              "role": _str("Role to assign. Required for `add` and `update`. Valid values: `admin` (full control "
                           "including member management), `writer` (can create and edit content), `reader` "
                           "(view-only access)."),
          },
          ["level", "action", "username"]),

    # ══════════════════════════════════════════════════════════
    # CONFIGURATION
    # ══════════════════════════════════════════════════════════
    _tool("devantis_get_config",
          "Get the current application configuration including LLM settings, feature flags, and cost "
          "limits. Use this to check what AI models are configured, which features are enabled, or "
          "what spending limits are in place before making changes.",
          {"section": _str("Configuration section to retrieve. Valid values: `llm` (AI model settings -- "
                           "model names, temperature, max tokens), `flags` (feature flags -- which features "
                           "are enabled/disabled), `cost_limits` (spending limits and alert thresholds), "
                           "`all` (everything at once).")},
          ["section"]),

    _tool("devantis_update_config",
          "Update a single application configuration value. Use this to change AI model settings, toggle "
          "feature flags, or adjust cost limits. Changes take effect immediately for new operations.",
          {
              "key": _str("Configuration key to update. The key format is `section.setting`. "
                          "Examples: `llm.model`, `llm.temperature`, `flags.enable_auto_commit`, "
                          "`cost_limits.monthly_max`"),
              "value": _str("New value for the configuration key. Type depends on the setting -- strings "
                            "for model names, numbers for limits and temperatures, true/false for flags. "
                            "Examples: `claude-sonnet-4-6-20250627`, `0.7`, `true`, `50.00`"),
          },
          ["key", "value"]),

    # ══════════════════════════════════════════════════════════
    # NOTIFICATIONS
    # ══════════════════════════════════════════════════════════
    _tool("devantis_manage_notifications",
          "Manage notification channels (email, webhook, Slack, Teams) and event subscriptions. Channels "
          "define WHERE notifications go; subscriptions define WHICH events trigger notifications. Use "
          "this to set up alerting, review notification logs, or test that channels are working.",
          {
              "action": _str("Operation to perform. Valid values: `list_channels` (show all notification channels), "
                             "`create_channel` (create a new channel -- requires name + channel_type + config), "
                             "`delete_channel` (remove a channel -- requires channel_id), `test_channel` (send a test "
                             "notification -- requires channel_id), `list_subscriptions` (show all event subscriptions), "
                             "`create_subscription` (subscribe a channel to an event -- requires channel_id + event_type), "
                             "`delete_subscription` (remove a subscription -- requires subscription_id), "
                             "`list_event_types` (show all available event types you can subscribe to), "
                             "`list_logs` (show recent notification delivery logs), `retry_log` (retry a failed "
                             "notification delivery -- requires log_id)."),
              "channel_id": _str("UUID of the notification channel. Required for `delete_channel`, `test_channel`, "
                                 "and `create_subscription`. Use action=`list_channels` to discover IDs."),
              "name": _str("Display name for the notification channel. Required for `create_channel`. "
                           "Example: `Engineering Slack`, `PagerDuty Webhook`, `Team Email`"),
              "channel_type": _str("Type of notification channel. Required for `create_channel`. Valid values: "
                                   "`email` (send to email addresses), `webhook` (HTTP POST to a URL), "
                                   "`slack` (post to a Slack channel via webhook), `teams` (post to Microsoft "
                                   "Teams via webhook)."),
              "config": _obj("Channel-specific configuration. Required for `create_channel`. Structure depends on "
                             "channel_type. For `email`: {\"recipients\": [\"team@company.com\"]}. For `webhook`: "
                             "{\"url\": \"https://hooks.example.com/notify\"}. For `slack`: {\"webhook_url\": "
                             "\"https://hooks.slack.com/services/...\"}. For `teams`: {\"webhook_url\": \"https://...\"}"),
              "event_type": _str("Event type to subscribe to. Required for `create_subscription`. "
                                 "Use action=`list_event_types` to see all available events. "
                                 "Examples: `ticket.created`, `deployment.failed`, `cost_limit.exceeded`"),
              "min_severity": _str("Minimum severity level for the subscription to trigger. Used with "
                                   "`create_subscription`. Valid values: `info` (all events), `warning` "
                                   "(warning and above), `critical` (only critical events). Default: `info`."),
              "subscription_id": _str("UUID of the subscription to remove. Required for `delete_subscription`. "
                                      "Use action=`list_subscriptions` to discover IDs."),
              "log_id": _str("UUID of the notification log entry to retry. Required for `retry_log`. "
                             "Use action=`list_logs` to find failed delivery log IDs."),
          },
          ["action"]),

    # ══════════════════════════════════════════════════════════
    # PROJECTS & ORGANISATIONS
    # ══════════════════════════════════════════════════════════
    _tool("devantis_list_projects",
          "List organisations, projects, or applications that the current user has access to. Use this "
          "to discover available workspaces, find project slugs for context switching, or see what "
          "applications exist within the current project.",
          {"level": _str("What to list. Valid values: `organisations` (all orgs the user belongs to), "
                         "`projects` (all projects in the current organisation), `apps` (all applications "
                         "in the current project).")},
          ["level"]),

    # ══════════════════════════════════════════════════════════
    # MEMORY
    # ══════════════════════════════════════════════════════════
    _tool("devantis_memory",
          "Read or write persistent project memory -- key-value pairs that survive across sessions. "
          "Use this to store project conventions, user preferences, recurring decisions, or any "
          "information that should be remembered permanently. Different from the knowledge graph: "
          "memory is for simple key-value notes, the brain is for structured entity relationships.",
          {
              "action": _str("Operation to perform. Valid values: `list` (show all memory entries), "
                             "`set` (create or update a memory entry -- requires key + content), "
                             "`delete` (remove a memory entry -- requires key)."),
              "key": _str("Memory key identifier. Required for `set` and `delete`. Use descriptive, "
                          "namespaced keys. Examples: `code-style`, `preferred-test-framework`, "
                          "`deploy-checklist`, `team-conventions`"),
              "content": _str("Memory content to store. Required for `set`. Can be any text -- notes, "
                              "lists, instructions, or structured data. "
                              "Example: `Always use pytest with fixtures. Prefer factory_boy over raw object creation.`"),
          },
          ["action"]),

    # ══════════════════════════════════════════════════════════
    # CONTEXT
    # ══════════════════════════════════════════════════════════
    _tool("devantis_switch_context",
          "Switch the active organisation, project, and/or application context. All subsequent tool calls "
          "will operate against the new context. Use this when the user wants to work on a different "
          "project or application. Provide only the fields you want to change -- omitted fields stay the same.",
          {
              "organisation": _str("Organisation slug to switch to. Use devantis_list_projects with "
                                   "level=`organisations` to discover available org slugs. "
                                   "Example: `my-company`, `acme-corp`"),
              "project": _str("Project slug to switch to. Use devantis_list_projects with level=`projects` "
                              "to discover available project slugs. Example: `backend-api`, `mobile-app`"),
              "app": _str("Application slug to switch to. Use devantis_list_projects with level=`apps` "
                          "to discover available app slugs. Example: `web-frontend`, `api-server`"),
          }),

    # ══════════════════════════════════════════════════════════
    # DOCUMENTATION
    # ══════════════════════════════════════════════════════════
    _tool("devantis_list_docs",
          "List platform documentation pages. Returns page metadata (title, description, tags, "
          "category) without full content. Use this to discover what documentation is available, "
          "browse by category, or find pages by tag. The documentation covers SDK reference, "
          "API guides, tutorials, Kubernetes deployment, and more.",
          {
              "category": _str("Filter by category slug. Available categories: 'getting-started', "
                               "'sdk', 'api-reference', 'guides', 'advanced', 'tutorials'. "
                               "Omit to list all pages across all categories."),
              "tag": _str("Filter by tag. Examples: 'authentication', 'kubernetes', 'installation'. "
                          "Omit for no tag filter."),
          }),

    _tool("devantis_read_doc",
          "Read a specific documentation page by its slug. Returns the full markdown content, "
          "metadata (title, author, tags, read time), category info, and previous/next navigation "
          "links. Use this to reference official documentation when answering user questions about "
          "the platform, SDK, API, or deployment. Always prefer this over guessing.",
          {"slug": _str("Fully-qualified page slug: '{category}/{page}'. "
                        "Examples: 'sdk/getting-started', 'guides/kubernetes-deployment', "
                        "'api-reference/authentication', 'tutorials/build-first-ai-app', "
                        "'advanced/executor-setup'. Use devantis_list_docs to discover slugs.")},
          ["slug"]),

    _tool("devantis_search_docs",
          "Search across all platform documentation using full-text search. Searches page titles, "
          "descriptions, tags, and content body. Returns matching pages with a relevance-ranked "
          "snippet showing where the match was found. Use this when you need to find documentation "
          "about a specific topic but don't know which page covers it.",
          {
              "query": _str("Search text (case-insensitive). Examples: 'authentication', "
                            "'kubernetes quotas', 'ticket API', 'MCP server setup'"),
              "max_results": _int("Maximum results to return. Default: 10. Increase for broad queries."),
          },
          ["query"]),

    # ══════════════════════════════════════════════════════════
    # BULK OPERATIONS
    # ══════════════════════════════════════════════════════════
    _tool("devantis_bulk_tickets",
          "Perform batch operations on multiple tickets at once. Much more efficient than calling "
          "individual ticket tools in a loop. Use this for creating multiple tickets from a plan, "
          "fetching several tickets by ID, bulk-updating fields, mass-deleting, or moving a batch "
          "of tickets to a sprint.",
          {
              "action": _str("Batch operation to perform. Valid values: `create` (create multiple tickets at once "
                             "-- requires tickets array), `get` (fetch multiple tickets by ID -- requires ticket_ids), "
                             "`update` (apply the same field changes to multiple tickets -- requires ticket_ids + update), "
                             "`delete` (delete multiple tickets -- requires ticket_ids), `move_to_sprint` (assign "
                             "multiple tickets to a sprint -- requires ticket_ids + sprint_id)."),
              "tickets": _arr("Array of ticket objects for `create` action. Each object should have at minimum "
                              "`title`, `description`, and `feature`. "
                              "Example: [{\"title\": \"Add login page\", \"description\": \"...\", \"feature\": \"auth\"}]",
                              {"type": "object"}),
              "ticket_ids": _arr("Array of ticket UUIDs for `get`, `update`, `delete`, and `move_to_sprint` actions. "
                                 "Example: [\"uuid-1\", \"uuid-2\", \"uuid-3\"]", {"type": "string"}),
              "update": _obj("Fields to apply to all specified tickets for `update` action. Same fields as "
                             "devantis_update_ticket (except ticket_id). "
                             "Example: {\"priority\": \"high\", \"assignee\": \"john.doe\"}"),
              "sprint_id": _str("UUID of the sprint to move tickets into for `move_to_sprint` action. "
                                "Use devantis_manage_sprints with action=`list` to find sprint IDs."),
          },
          ["action"]),

    # ══════════════════════════════════════════════════════════
    # BILLING & LICENSING (admin-only)
    # ══════════════════════════════════════════════════════════
    _tool("devantis_billing",
          "Billing and subscription management. View invoices, credit balance, current plan, quotas, "
          "cost breakdowns, tax, and manage subscriptions. Most actions require org admin or superadmin role.",
          {
              "action": _str("Operation to perform. Valid values: "
                             "**Plan & Quotas:** "
                             "`get_plan` (current subscription details), "
                             "`list_plans` (all available plans with pricing), "
                             "`get_entitlements` (plan + all quotas + features + suspension status), "
                             "`get_usage` (usage summary -- all quotas with current/limit values), "
                             "`get_overage_rates` (overage pricing for a plan -- requires plan_name), "
                             "**Invoices:** "
                             "`list_invoices` (billing invoices and receipts), "
                             "`get_invoice` (single invoice with line items -- requires invoice_id), "
                             "`upcoming_invoice` (preview next invoice), "
                             "`retry_invoice` (retry a failed payment -- requires invoice_id), "
                             "**Credits:** "
                             "`get_credits` (credit balance -- remaining, allocated, consumed), "
                             "`list_transactions` (credit transaction history), "
                             "`list_credit_packs` (available credit packs with prices), "
                             "`purchase_credits` (create checkout for credit purchase -- requires pack), "
                             "`allocate_credits` (manually add credits -- admin only, requires amount_usd), "
                             "**Subscription:** "
                             "`cancel_subscription` (cancel plan at period end), "
                             "`reactivate_subscription` (undo cancellation before period ends), "
                             "**Payment Methods:** "
                             "`list_payment_methods` (saved payment cards), "
                             "`remove_payment_method` (remove a card -- requires pm_id), "
                             "`set_default_payment_method` (set default card -- requires pm_id), "
                             "**Tax:** "
                             "`get_tax_summary` (current tax configuration), "
                             "`list_tax_ids` (tax IDs on billing customer), "
                             "`add_tax_id` (add a tax ID -- requires tax_type + tax_value), "
                             "`remove_tax_id` (remove a tax ID -- requires tax_id), "
                             "`get_tax_types` (supported tax ID types by country), "
                             "**Cost Breakdown:** "
                             "`get_seat_cost` (seat billing summary), "
                             "`get_executor_cost` (executor usage cost), "
                             "`get_k8s_cost` (Kubernetes resource cost), "
                             "`get_registry_cost` (container registry storage cost)."),
              "invoice_id": _str("UUID of the invoice. Required for `get_invoice` and `retry_invoice`."),
              "pack": _str("Credit pack to purchase. Required for `purchase_credits`. "
                           "Valid values: `small` ($10), `medium` ($25), `large` ($50), "
                           "or `custom_<amount>` (e.g. `custom_100`)."),
              "amount_usd": _str("Dollar amount for `allocate_credits`. Example: `50.00`."),
              "description": _str("Description for `allocate_credits`. Example: `Bonus credits for Q2`."),
              "plan_name": _str("Plan name for `get_overage_rates`. Example: `pro`, `team`."),
              "pm_id": _str("Payment method UUID. Required for `remove_payment_method` and `set_default_payment_method`."),
              "tax_type": _str("Tax ID type for `add_tax_id`. Examples: `eu_vat`, `gb_vat`, `us_ein`."),
              "tax_value": _str("Tax ID value for `add_tax_id`. Example: `RO12345678`."),
              "tax_id": _str("Tax ID to remove for `remove_tax_id`."),
              "project_id": _str("Optional project UUID. Used with `get_entitlements`, `get_usage`, "
                                 "`get_credits` for project-level billing."),
              "month": _str("Optional YYYY-MM filter for `list_invoices`. Example: `2026-04`."),
              "limit": _int("Max items to return for list actions. Default: 20 for invoices, 50 for transactions."),
              "page": _int("Page number for `list_transactions`. Default: 1."),
          },
          ["action"]),
]


@server.list_tools()
async def list_tools() -> list[Tool]:
    return TOOLS


# ── Tool Dispatch ──────────────────────────────────────────────────

async def _handle_tool(name: str, args: dict) -> str:
    """Route a tool call to the appropriate SDK method. Returns JSON string."""
    global _active_chat_session
    client = await _ensure_client()

    # ── Source Code ───────────────────────────────────────────
    if name == "devantis_read_file":
        return await client.source.read(args["path"])

    if name == "devantis_list_files":
        return _j(await client.source.list(folder=args.get("folder", "")))

    if name == "devantis_glob_files":
        return _j(await client.source.glob(args["pattern"]))

    if name == "devantis_grep":
        return _j(await client.source.grep(
            pattern=args.get("pattern"),
            patterns=args.get("patterns"),
            glob=args.get("glob"),
            context_lines=args.get("context_lines", 2),
            max_results=args.get("max_results", 10),
        ))

    if name == "devantis_write_file":
        return _j(await client.source.write(args["path"], args["content"]))

    if name == "devantis_edit_file":
        return _j(await client.source.edit(args["file_path"], args["old_content"], args["new_content"]))

    if name == "devantis_delete_file":
        return _j(await client.source.delete(args["path"]))

    if name == "devantis_move_file":
        return _j(await client.source.move(args["source_path"], args["destination_path"]))

    # ── Source Code — Batch ──────────────────────────────────
    if name == "devantis_batch_files":
        action = args["action"]
        if action == "write":
            return _j(await client.source.batch_write(args.get("files", [])))
        if action == "delete":
            return _j(await client.source.batch_delete(args.get("paths", [])))
        if action == "edit":
            return _j(await client.source.batch_edit(args.get("edits", [])))
        return _j({"error": f"Unknown batch action: {action}"})

    # ── Search ───────────────────────────────────────────────
    if name == "devantis_search":
        return _j(await client.search(args["query"], entity_types=args.get("entity_types")))

    if name == "devantis_search_tickets":
        return _j(await client.tickets.search(
            args["query"], feature=args.get("feature", ""), max_results=args.get("max_results", 50)
        ))

    # ── Tickets — Core CRUD ──────────────────────────────────
    if name == "devantis_list_tickets":
        return _j(await client.tickets.list(
            status=args.get("status", ""), feature=args.get("feature", ""),
            priority=args.get("priority", ""), assignee=args.get("assignee", ""),
            sprint_id=args.get("sprint_id", ""), epic_id=args.get("epic_id", ""),
            page=args.get("page", 1), page_size=args.get("page_size", 30),
        ))

    if name == "devantis_get_ticket":
        return _j(await client.tickets.get(args["ticket_id"]))

    if name == "devantis_create_ticket":
        return _j(await client.tickets.create(**args))

    if name == "devantis_update_ticket":
        tid = args.pop("ticket_id")
        return _j(await client.tickets.update(tid, **args))

    if name == "devantis_delete_ticket":
        await client.tickets.delete(args["ticket_id"])
        return _j({"status": "deleted", "ticket_id": args["ticket_id"]})

    if name == "devantis_transition_ticket":
        return _j(await client.tickets.transition(
            args["ticket_id"], args["action"], reason=args.get("reason", "")
        ))

    # ── Tickets — Comments ───────────────────────────────────
    if name == "devantis_add_ticket_comment":
        return _j(await client.tickets.add_comment(args["ticket_id"], args["content"]))

    if name == "devantis_list_ticket_comments":
        return _j(await client.tickets.list_comments(args["ticket_id"]))

    # ── Tickets — Labels ─────────────────────────────────────
    if name == "devantis_manage_labels":
        action = args["action"]
        if action == "list":
            return _j(await client.tickets.list_labels())
        if action == "create":
            return _j(await client.tickets.create_label(args["name"], args.get("color", ""), args.get("description", "")))
        if action == "delete":
            await client.tickets.delete_label(args["label_id"])
            return _j({"status": "deleted"})
        if action == "add_to_ticket":
            return _j(await client.tickets.add_label_to_ticket(args["ticket_id"], args["label_id"]))
        if action == "remove_from_ticket":
            await client.tickets.remove_label_from_ticket(args["ticket_id"], args["label_id"])
            return _j({"status": "removed"})
        if action == "get_ticket_labels":
            return _j(await client.tickets.get_ticket_labels(args["ticket_id"]))
        return _j({"error": f"Unknown label action: {action}"})

    # ── Tickets — Subtasks ───────────────────────────────────
    if name == "devantis_manage_subtasks":
        action = args["action"]
        tid = args["ticket_id"]
        if action == "list":
            return _j(await client.tickets.list_subtasks(tid))
        if action == "create":
            return _j(await client.tickets.create_subtask(tid, args["title"], args.get("description", "")))
        if action == "update":
            update_args = {k: v for k, v in args.items() if k not in ("action", "ticket_id", "subtask_id")}
            return _j(await client.tickets.update_subtask(tid, args["subtask_id"], **update_args))
        if action == "delete":
            await client.tickets.delete_subtask(tid, args["subtask_id"])
            return _j({"status": "deleted"})
        return _j({"error": f"Unknown subtask action: {action}"})

    # ── Tickets — Links ──────────────────────────────────────
    if name == "devantis_manage_links":
        action = args["action"]
        tid = args["ticket_id"]
        if action == "list":
            return _j(await client.tickets.list_links(tid))
        if action == "create":
            return _j(await client.tickets.create_link(tid, args["target_ticket_id"], args["link_type"]))
        if action == "delete":
            await client.tickets.delete_link(tid, args["link_id"])
            return _j({"status": "deleted"})
        return _j({"error": f"Unknown link action: {action}"})

    # ── Tickets — Watchers ───────────────────────────────────
    if name == "devantis_ticket_watch":
        action = args["action"]
        tid = args["ticket_id"]
        if action == "list":
            return _j(await client.tickets.list_watchers(tid))
        if action == "watch":
            return _j(await client.tickets.watch_ticket(tid))
        if action == "unwatch":
            await client.tickets.unwatch_ticket(tid)
            return _j({"status": "unwatched"})
        return _j({"error": f"Unknown watch action: {action}"})

    # ── Tickets — Voting ─────────────────────────────────────
    if name == "devantis_ticket_vote":
        action = args["action"]
        tid = args["ticket_id"]
        if action == "get":
            return _j(await client.tickets.get_votes(tid))
        if action == "vote":
            return _j(await client.tickets.vote(tid))
        if action == "unvote":
            await client.tickets.unvote(tid)
            return _j({"status": "unvoted"})
        return _j({"error": f"Unknown vote action: {action}"})

    # ── Tickets — Time Logs ──────────────────────────────────
    if name == "devantis_ticket_timelog":
        action = args["action"]
        tid = args["ticket_id"]
        if action == "list":
            return _j(await client.tickets.list_timelogs(tid))
        if action == "log":
            return _j(await client.tickets.log_time(
                tid, args["hours_spent"], args.get("description", ""), args.get("work_date", "")
            ))
        if action == "delete":
            await client.tickets.delete_timelog(tid, args["log_id"])
            return _j({"status": "deleted"})
        return _j({"error": f"Unknown timelog action: {action}"})

    # ── Tickets — Milestones ─────────────────────────────────
    if name == "devantis_manage_milestones":
        action = args["action"]
        if action == "list":
            return _j(await client.tickets.list_milestones(status=args.get("status", "")))
        if action == "create":
            return _j(await client.tickets.create_milestone(
                args["name"], args.get("description", ""), args.get("due_date", "")
            ))
        if action == "update":
            upd = {k: v for k, v in args.items() if k not in ("action", "milestone_id")}
            return _j(await client.tickets.update_milestone(args["milestone_id"], **upd))
        if action == "delete":
            await client.tickets.delete_milestone(args["milestone_id"])
            return _j({"status": "deleted"})
        if action == "add_ticket":
            return _j(await client.tickets.add_ticket_to_milestone(args["milestone_id"], args["ticket_id"]))
        if action == "remove_ticket":
            await client.tickets.remove_ticket_from_milestone(args["milestone_id"], args["ticket_id"])
            return _j({"status": "removed"})
        return _j({"error": f"Unknown milestone action: {action}"})

    # ── Tickets — Components ─────────────────────────────────
    if name == "devantis_manage_components":
        action = args["action"]
        if action == "list":
            return _j(await client.tickets.list_components())
        if action == "create":
            return _j(await client.tickets.create_component(args["name"], args.get("description", "")))
        if action == "delete":
            await client.tickets.delete_component(args["component_id"])
            return _j({"status": "deleted"})
        if action == "add_ticket":
            return _j(await client.tickets.add_ticket_to_component(args["component_id"], args["ticket_id"]))
        return _j({"error": f"Unknown component action: {action}"})

    # ── Tickets — Filters ────────────────────────────────────
    if name == "devantis_manage_filters":
        action = args["action"]
        if action == "list":
            return _j(await client.tickets.list_filters())
        if action == "create":
            return _j(await client.tickets.create_filter(
                args["name"], args.get("filter_query", {}), args.get("is_public", False)
            ))
        if action == "execute":
            return _j(await client.tickets.execute_filter(args["filter_id"]))
        if action == "delete":
            await client.tickets.delete_filter(args["filter_id"])
            return _j({"status": "deleted"})
        return _j({"error": f"Unknown filter action: {action}"})

    # ── Tickets — Boards ─────────────────────────────────────
    if name == "devantis_get_board":
        return _j(await client.tickets.get_board(
            board_type=args.get("board_type", "kanban"),
            feature=args.get("feature", ""),
            sprint_id=args.get("sprint_id", ""),
            epic_id=args.get("epic_id", ""),
        ))

    # ── Tickets — Charts ─────────────────────────────────────
    if name == "devantis_get_chart":
        chart_type = args["chart_type"]
        if chart_type == "burndown":
            return _j(await client.tickets.get_burndown(args["sprint_id"]))
        if chart_type == "burnup":
            return _j(await client.tickets.get_burnup(args["sprint_id"]))
        if chart_type == "cumulative_flow":
            return _j(await client.tickets.get_cumulative_flow(days=args.get("days", 30)))
        if chart_type == "velocity":
            return _j(await client.tickets.get_velocity(sprints=args.get("sprints", 6)))
        return _j({"error": f"Unknown chart type: {chart_type}"})

    # ── Tickets — Stats ──────────────────────────────────────
    if name == "devantis_ticket_stats":
        return _j(await client.tickets.get_stats())

    # ── Sprints ──────────────────────────────────────────────
    if name == "devantis_manage_sprints":
        action = args["action"]
        if action == "list":
            return _j(await client.tickets.list_sprints(status=args.get("status", "")))
        if action == "get":
            return _j(await client.tickets.get_sprint(args["sprint_id"]))
        if action == "create":
            return _j(await client.tickets.create_sprint(
                args["name"], args.get("goal", ""), args.get("start_date", ""), args.get("end_date", "")
            ))
        if action == "update":
            upd = {k: v for k, v in args.items() if k not in ("action", "sprint_id")}
            return _j(await client.tickets.update_sprint(args["sprint_id"], **upd))
        if action == "delete":
            await client.tickets.delete_sprint(args["sprint_id"])
            return _j({"status": "deleted"})
        if action == "start":
            return _j(await client.tickets.start_sprint(args["sprint_id"]))
        if action == "complete":
            return _j(await client.tickets.complete_sprint(args["sprint_id"]))
        if action == "get_tickets":
            return _j(await client.tickets.get_sprint_tickets(args["sprint_id"]))
        if action == "add_ticket":
            return _j(await client.tickets.add_ticket_to_sprint(args["sprint_id"], args["ticket_id"]))
        if action == "remove_ticket":
            await client.tickets.remove_ticket_from_sprint(args["sprint_id"], args["ticket_id"])
            return _j({"status": "removed"})
        return _j({"error": f"Unknown sprint action: {action}"})

    # ── Epics ────────────────────────────────────────────────
    if name == "devantis_manage_epics":
        action = args["action"]
        if action == "list":
            return _j(await client.tickets.list_epics(status=args.get("status", "")))
        if action == "get":
            return _j(await client.tickets.get_epic(args["epic_id"]))
        if action == "create":
            return _j(await client.tickets.create_epic(
                args["name"], args.get("summary", ""), args.get("description", ""), args.get("color", "")
            ))
        if action == "update":
            upd = {k: v for k, v in args.items() if k not in ("action", "epic_id")}
            return _j(await client.tickets.update_epic(args["epic_id"], **upd))
        if action == "delete":
            await client.tickets.delete_epic(args["epic_id"])
            return _j({"status": "deleted"})
        if action == "get_tickets":
            return _j(await client.tickets.get_epic_tickets(args["epic_id"]))
        if action == "add_ticket":
            return _j(await client.tickets.add_ticket_to_epic(args["epic_id"], args["ticket_id"]))
        if action == "remove_ticket":
            await client.tickets.remove_ticket_from_epic(args["epic_id"], args["ticket_id"])
            return _j({"status": "removed"})
        return _j({"error": f"Unknown epic action: {action}"})

    # ── Requirements ─────────────────────────────────────────
    if name == "devantis_list_requirements":
        return _j(await client.requirements.list(
            status=args.get("status", ""), feature=args.get("feature", ""),
            priority=args.get("priority", ""),
            page=args.get("page", 1), page_size=args.get("page_size", 30),
        ))

    if name == "devantis_get_requirement":
        return _j(await client.requirements.get(args["requirement_id"]))

    if name == "devantis_create_requirement":
        return _j(await client.requirements.create(**args))

    if name == "devantis_update_requirement":
        rid = args.pop("requirement_id")
        return _j(await client.requirements.update(rid, **args))

    if name == "devantis_delete_requirement":
        await client.requirements.delete(args["requirement_id"])
        return _j({"status": "deleted", "requirement_id": args["requirement_id"]})

    # ── Architecture ─────────────────────────────────────────
    if name == "devantis_list_architecture":
        return _j(await client.architecture.list(folder=args.get("folder", "")))

    if name == "devantis_read_architecture":
        result = await client.architecture.get(args["architecture_id"])
        return _j(result)

    if name == "devantis_create_architecture":
        return _j(await client.architecture.create(
            id=args["id"], content=args["content"],
            file_type=args.get("file_type", "document"), folder=args.get("folder", ""),
        ))

    if name == "devantis_update_architecture":
        return _j(await client.architecture.update(args["architecture_id"], args["content"]))

    if name == "devantis_delete_architecture":
        await client.architecture.delete(args["architecture_id"])
        return _j({"status": "deleted"})

    if name == "devantis_search_architecture":
        return _j(await client.architecture.search(args["query"]))

    # ── Designs ──────────────────────────────────────────────
    if name == "devantis_list_designs":
        return _j(await client.designs.list(
            folder=args.get("folder", ""), file_type=args.get("file_type", ""),
        ))

    if name == "devantis_read_design":
        return _j(await client.designs.get(args["design_id"]))

    if name == "devantis_create_design":
        return _j(await client.designs.create(
            id=args["id"], content=args["content"],
            file_type=args.get("file_type", "html"), folder=args.get("folder", ""),
        ))

    if name == "devantis_update_design":
        return _j(await client.designs.update(args["design_id"], args["content"]))

    if name == "devantis_delete_design":
        await client.designs.delete(args["design_id"])
        return _j({"status": "deleted"})

    if name == "devantis_search_designs":
        return _j(await client.designs.search(args.get("query", ""), file_type=args.get("file_type", "")))

    # ── Chat — Session Management ───────────────────────────
    if name == "devantis_chat_session":
        action = args["action"]
        if action == "get":
            return _j({"active_session": _active_chat_session})
        if action == "set":
            _active_chat_session = args["session_id"]
            return _j({"active_session": _active_chat_session, "status": "set"})
        if action == "start":
            import uuid
            _active_chat_session = str(uuid.uuid4())
            return _j({"active_session": _active_chat_session, "status": "started"})
        if action == "clear":
            _active_chat_session = None
            return _j({"active_session": None, "status": "cleared"})
        return _j({"error": f"Unknown session action: {action}"})

    # ── Chat — Send / Answer / Confirm ───────────────────────
    if name == "devantis_chat_send":
        session_id = args.get("session_id") or _active_chat_session
        result = await client.chat.send(
            args["message"], session_id=session_id, timeout=args.get("timeout", 300),
        )
        # Auto-persist the session from the response
        if result.get("session_id") and not _active_chat_session:
            _active_chat_session = result["session_id"]
        return _j(result)

    if name == "devantis_chat_answer":
        session_id = args.get("session_id") or _active_chat_session
        if not session_id:
            return _j({"error": "No session_id provided and no active session. Use devantis_chat_session to set one."})
        return _j(await client.chat.answer(
            session_id, args["answer"], timeout=args.get("timeout", 300),
        ))

    if name == "devantis_chat_confirm":
        session_id = args.get("session_id") or _active_chat_session
        if not session_id:
            return _j({"error": "No session_id provided and no active session."})
        return _j(await client.chat.confirm(
            session_id, args["job_id"], args["approved"], timeout=args.get("timeout", 300),
        ))

    if name == "devantis_chat_history":
        session_id = args.get("session_id") or _active_chat_session
        if not session_id:
            return _j({"error": "No session_id provided and no active session. Use devantis_chat_session to set one."})
        return _j(await client.chat.history(session_id))

    if name == "devantis_chat_sessions":
        return _j(await client.chat.sessions(page_size=args.get("page_size", 20)))

    if name == "devantis_chat_stop":
        session_id = args.get("session_id") or _active_chat_session
        if not session_id:
            return _j({"error": "No session_id provided and no active session."})
        return _j(await client.chat.stop(session_id))

    if name == "devantis_chat_delete":
        session_id = args.get("session_id") or _active_chat_session
        if not session_id:
            return _j({"error": "No session_id provided and no active session."})
        await client.chat.delete(session_id)
        return _j({"status": "deleted"})

    # ── Knowledge Graph ──────────────────────────────────────
    if name == "devantis_kg_search":
        return _j(await client.knowledge_graph.search(args["query"], entity_type=args.get("entity_type", "")))

    if name == "devantis_kg_get_entity":
        return _j(await client.knowledge_graph.get_entity(args["name"]))

    if name == "devantis_kg_add":
        return _j(await client.knowledge_graph.create_entity(
            args["name"], args["entity_type"], observations=args.get("observations"),
        ))

    if name == "devantis_kg_add_observation":
        return _j(await client.knowledge_graph.add_observation(
            args["entity_name"], args["content"], kind=args.get("kind", "fact"),
        ))

    if name == "devantis_kg_remove":
        action = args["action"]
        if action == "delete_entity":
            await client.knowledge_graph.delete_entity(args["entity_name"])
            return _j({"status": "deleted"})
        if action == "delete_observation":
            await client.knowledge_graph.delete_observation(args["entity_name"], args["observation_id"])
            return _j({"status": "deleted"})
        if action == "delete_relation":
            await client.knowledge_graph.delete_relation(args["relation_id"])
            return _j({"status": "deleted"})
        return _j({"error": f"Unknown kg remove action: {action}"})

    if name == "devantis_kg_relations":
        action = args["action"]
        if action == "list":
            return _j(await client.knowledge_graph.list_relations(
                from_entity=args.get("from_entity", ""),
                to_entity=args.get("to_entity", ""),
                relation_type=args.get("relation_type", ""),
            ))
        if action == "create":
            return _j(await client.knowledge_graph.create_relation(
                args["from_entity"], args["to_entity"], args["relation_type"],
            ))
        if action == "delete":
            await client.knowledge_graph.delete_relation(args["relation_id"])
            return _j({"status": "deleted"})
        return _j({"error": f"Unknown kg relation action: {action}"})

    if name == "devantis_kg_reason":
        return _j(await client.knowledge_graph.reason(args["question"]))

    if name == "devantis_kg_stats":
        return _j(await client.knowledge_graph.stats())

    if name == "devantis_kg_vitals":
        return _j(await client.knowledge_graph.vitals())

    if name == "devantis_kg_impact":
        return _j(await client.knowledge_graph.impact(args["entity_name"]))

    if name == "devantis_kg_confirm_observation":
        return _j(await client.knowledge_graph.confirm_observation(
            args["entity_name"], args["observation_id"],
        ))

    if name == "devantis_kg_dependencies":
        return _j(await client.knowledge_graph.dependencies(
            args["entity_name"], direction=args.get("direction", "outgoing"),
        ))

    # ── Executors ────────────────────────────────────────────
    if name == "devantis_executor_shell":
        return _j(await client.executors.shell(
            args["command"], purpose=args.get("purpose", ""), tail_lines=args.get("tail_lines", 0),
        ))

    if name == "devantis_deploy_k8s":
        return _j(await client.executors.deploy_k8s(
            args["tool_name"], arguments=args.get("arguments"),
            timeout_seconds=args.get("timeout_seconds", 300),
        ))

    if name == "devantis_list_executors":
        return _j(await client.executors.list(status=args.get("status", "")))

    # ── Analytics ────────────────────────────────────────────
    if name == "devantis_token_usage":
        return _j(await client.analytics.token_usage(
            view=args["view"], period=args.get("period"),
        ))

    if name == "devantis_cost_forecast":
        action = args["action"]
        if action == "forecast":
            return _j(await client.analytics.cost_forecast())
        if action == "alerts":
            return _j(await client.analytics.alerts())
        return _j({"error": f"Unknown cost action: {action}"})

    # ── Users ────────────────────────────────────────────────
    if name == "devantis_users_search":
        return _j(await client.users.search(args.get("query", "")))

    if name == "devantis_users_me":
        return _j(await client.users.me())

    # ── Members ──────────────────────────────────────────────
    if name == "devantis_list_members":
        return _j(await client.projects.list_members(level=args["level"]))

    if name == "devantis_manage_members":
        action = args["action"]
        level = args["level"]
        username = args["username"]
        if action == "add":
            return _j(await client.projects.add_member(level, username, args.get("role", "reader")))
        if action == "update":
            return _j(await client.projects.update_member(level, username, args["role"]))
        if action == "remove":
            await client.projects.remove_member(level, username)
            return _j({"status": "removed"})
        return _j({"error": f"Unknown member action: {action}"})

    # ── Config ───────────────────────────────────────────────
    if name == "devantis_get_config":
        return _j(await client.projects.get_config(section=args["section"]))

    if name == "devantis_update_config":
        return _j(await client.projects.update_config(args["key"], args["value"]))

    # ── Notifications ────────────────────────────────────────
    if name == "devantis_manage_notifications":
        action = args["action"]
        if action == "list_channels":
            return _j(await client.notifications.list_channels(channel_type=args.get("channel_type", "")))
        if action == "create_channel":
            return _j(await client.notifications.create_channel(
                args["name"], args["channel_type"], args.get("config", {}),
            ))
        if action == "delete_channel":
            await client.notifications.delete_channel(args["channel_id"])
            return _j({"status": "deleted"})
        if action == "test_channel":
            return _j(await client.notifications.test_channel(args["channel_id"]))
        if action == "list_subscriptions":
            return _j(await client.notifications.list_subscriptions(event_type=args.get("event_type", "")))
        if action == "create_subscription":
            return _j(await client.notifications.create_subscription(
                args["event_type"], args["channel_id"],
                min_severity=args.get("min_severity", "info"),
            ))
        if action == "delete_subscription":
            await client.notifications.delete_subscription(args["subscription_id"])
            return _j({"status": "deleted"})
        if action == "list_event_types":
            return _j(await client.notifications.list_event_types())
        if action == "list_logs":
            return _j(await client.notifications.list_logs(channel_id=args.get("channel_id", "")))
        if action == "retry_log":
            return _j(await client.notifications.retry_log(args["log_id"]))
        return _j({"error": f"Unknown notification action: {action}"})

    # ── Projects ─────────────────────────────────────────────
    if name == "devantis_list_projects":
        level = args["level"]
        if level == "organisations":
            return _j(await client.projects.list_organisations())
        if level == "projects":
            return _j(await client.projects.list_projects())
        if level == "apps":
            return _j(await client.projects.list_apps())
        return _j({"error": f"Unknown level: {level}"})

    # ── Memory ───────────────────────────────────────────────
    if name == "devantis_memory":
        action = args["action"]
        if action == "list":
            return _j(await client.memory.list())
        if action == "set":
            return _j(await client.memory.set(args["key"], args["content"]))
        if action == "delete":
            return _j(await client.memory.delete(args["key"]))
        return _j({"error": f"Unknown memory action: {action}"})

    # ── Context ──────────────────────────────────────────────
    if name == "devantis_switch_context":
        global _briefing
        new_ctx = await client.switch_context(
            org=args.get("organisation", ""),
            project=args.get("project", ""),
            app=args.get("app", ""),
        )
        # Wipe chat session — old session belongs to the old app
        _active_chat_session = None
        try:
            _briefing = await client.build_briefing()
        except Exception:
            pass
        return _j({
            "organisation": new_ctx.org_name,
            "org_slug": new_ctx.org_slug,
            "project": new_ctx.project_name,
            "project_slug": new_ctx.project_slug,
            "application": new_ctx.app_name,
            "app_slug": new_ctx.app_slug,
            "app_type": new_ctx.app_type,
            "role": new_ctx.user_role,
        })

    # ── Bulk Tickets ─────────────────────────────────────────
    if name == "devantis_bulk_tickets":
        action = args["action"]
        if action == "create":
            return _j(await client.tickets.bulk_create(args.get("tickets", [])))
        if action == "get":
            return _j(await client.tickets.bulk_get(args.get("ticket_ids", [])))
        if action == "update":
            return _j(await client.tickets.bulk_update(
                args.get("ticket_ids", []), **(args.get("update", {}))
            ))
        if action == "delete":
            return _j(await client.tickets.bulk_delete(args.get("ticket_ids", [])))
        if action == "move_to_sprint":
            return _j(await client.tickets.bulk_move_to_sprint(
                args["sprint_id"], args.get("ticket_ids", [])
            ))
        return _j({"error": f"Unknown bulk action: {action}"})

    # ── Documentation ────────────────────────────────────────
    if name == "devantis_list_docs":
        return _j(await client.docs.list(
            category=args.get("category", ""),
            tag=args.get("tag", ""),
        ))

    if name == "devantis_read_doc":
        return _j(await client.docs.get(args["slug"]))

    if name == "devantis_search_docs":
        return _j(await client.docs.search(
            args["query"],
            max_results=args.get("max_results", 10),
        ))

    # ── Billing & Licensing ────────────────────────────────────
    if name == "devantis_billing":
        action = args["action"]
        # Plan & Quotas
        if action == "get_plan":
            return _j(await client.billing.get_plan())
        if action == "list_plans":
            return _j(await client.billing.list_plans())
        if action == "get_entitlements":
            return _j(await client.billing.get_entitlements(project_id=args.get("project_id")))
        if action == "get_usage":
            return _j(await client.billing.get_usage(project_id=args.get("project_id")))
        if action == "get_overage_rates":
            return _j(await client.billing.get_overage_rates(args["plan_name"]))
        # Invoices
        if action == "list_invoices":
            return _j(await client.billing.list_invoices(
                limit=args.get("limit", 20), month=args.get("month"),
            ))
        if action == "get_invoice":
            return _j(await client.billing.get_invoice(args["invoice_id"]))
        if action == "upcoming_invoice":
            return _j(await client.billing.get_upcoming_invoice())
        if action == "retry_invoice":
            return _j(await client.billing.retry_invoice(args["invoice_id"]))
        # Credits
        if action == "get_credits":
            return _j(await client.billing.get_credits(project_id=args.get("project_id")))
        if action == "list_transactions":
            return _j(await client.billing.list_transactions(
                limit=args.get("limit", 50), page=args.get("page", 1),
            ))
        if action == "list_credit_packs":
            return _j(await client.billing.list_credit_packs())
        if action == "purchase_credits":
            return _j(await client.billing.purchase_credits(args["pack"]))
        if action == "allocate_credits":
            return _j(await client.billing.allocate_credits(
                float(args["amount_usd"]), args.get("description", ""),
            ))
        # Subscription
        if action == "cancel_subscription":
            return _j(await client.billing.cancel_subscription())
        if action == "reactivate_subscription":
            return _j(await client.billing.reactivate_subscription())
        # Payment Methods
        if action == "list_payment_methods":
            return _j(await client.billing.list_payment_methods())
        if action == "remove_payment_method":
            return _j(await client.billing.remove_payment_method(args["pm_id"]))
        if action == "set_default_payment_method":
            return _j(await client.billing.set_default_payment_method(args["pm_id"]))
        # Tax
        if action == "get_tax_summary":
            return _j(await client.billing.get_tax_summary())
        if action == "list_tax_ids":
            return _j(await client.billing.list_tax_ids())
        if action == "add_tax_id":
            return _j(await client.billing.add_tax_id(args["tax_type"], args["tax_value"]))
        if action == "remove_tax_id":
            return _j(await client.billing.remove_tax_id(args["tax_id"]))
        if action == "get_tax_types":
            return _j(await client.billing.get_tax_types())
        # Cost Breakdown
        if action == "get_seat_cost":
            return _j(await client.billing.get_seat_cost())
        if action == "get_executor_cost":
            return _j(await client.billing.get_executor_cost())
        if action == "get_k8s_cost":
            return _j(await client.billing.get_k8s_cost())
        if action == "get_registry_cost":
            return _j(await client.billing.get_registry_cost())
        return _j({"error": f"Unknown billing action: {action}"})

    return _j({"error": f"Unknown tool: {name}"})


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Dispatch a tool call — routes to SDK, catches errors, returns MCP-formatted results."""
    try:
        result = await _handle_tool(name, arguments or {})
        return _text(result)
    except NotFound as exc:
        return _text(
            _j({"error": "not_found", "message": str(exc), "entity_type": exc.entity_type, "entity_id": exc.entity_id}),
            is_error=True,
        )
    except Forbidden as exc:
        return _text(
            _j({"error": "forbidden", "message": str(exc), "required_role": exc.required_role}),
            is_error=True,
        )
    except AuthError as exc:
        return _text(
            _j({"error": "auth_error", "message": str(exc)}),
            is_error=True,
        )
    except ValidationError as exc:
        return _text(
            _j({"error": "validation_error", "message": str(exc), "detail": str(exc.detail)}),
            is_error=True,
        )
    except Conflict as exc:
        return _text(
            _j({"error": "conflict", "message": str(exc)}),
            is_error=True,
        )
    except RateLimited as exc:
        return _text(
            _j({"error": "rate_limited", "message": str(exc), "retry_after": exc.retry_after}),
            is_error=True,
        )
    except ServiceUnavailable as exc:
        return _text(
            _j({"error": "service_unavailable", "message": str(exc), "service": exc.service}),
            is_error=True,
        )
    except WriteLockTimeout as exc:
        return _text(
            _j({"error": "write_lock", "message": str(exc)}),
            is_error=True,
        )
    except DevantisError as exc:
        return _text(
            _j({"error": "devantis_error", "message": str(exc), "status_code": exc.status_code}),
            is_error=True,
        )
    except Exception as exc:
        logger.exception("Unexpected error in tool %s", name)
        return _text(
            _j({"error": "internal_error", "message": str(exc)}),
            is_error=True,
        )


# ── Server Startup ─────────────────────────────────────────────────

def main():
    """Run the Devantis MCP server over stdio."""

    async def _run():
        # Don't eagerly connect — let _ensure_client() run on first tool call.
        # This way the MCP server starts even if Docker services aren't up yet.
        logger.info("Devantis MCP server starting (lazy connection mode)")

        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )

    asyncio.run(_run())


if __name__ == "__main__":
    main()
