"""Authentication providers for the Devantis SDK.

Three auth modes:
- UserTokenAuth: reads ~/.devantis_token.json (shared with CLI)
- InternalAuth: uses INTERNAL_SERVICE_KEY (for executor inside Docker)
- ServiceAccountAuth: Keycloak client_credentials grant
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from pathlib import Path

import httpx

from devantis.errors import AuthError

logger = logging.getLogger(__name__)


class BaseAuth:
    """Abstract auth provider."""

    async def get_headers(self) -> dict[str, str]:
        """Return auth headers for an API request."""
        raise NotImplementedError

    async def refresh(self) -> None:
        """Refresh the auth token if applicable."""
        pass


class UserTokenAuth(BaseAuth):
    """Auth using the CLI's saved Keycloak token.

    Reads from ~/.devantis_token.json which is written by `devantis login`.
    Auto-refreshes when the token expires.
    """

    def __init__(
        self,
        token_file: str | Path = "~/.devantis_token.json",
        keycloak_url: str = "https://auth.platform.encodeit.ro/auth",
        realm: str = "platform-dev",
        client_id: str = "platform-cli",
    ):
        self._token_file = Path(token_file).expanduser()
        self._keycloak_url = keycloak_url
        self._realm = realm
        self._client_id = client_id
        self._access_token: str | None = None
        self._refresh_token: str | None = None
        self._expires_at: float = 0
        self._http = httpx.AsyncClient(timeout=15.0)
        self._lock = asyncio.Lock()
        self._load_token_file()

    @classmethod
    def from_file(cls, path: str | Path = "~/.devantis_token.json") -> UserTokenAuth:
        return cls(token_file=path)

    def _load_token_file(self) -> None:
        """Load token from the CLI's saved file."""
        if not self._token_file.exists():
            raise AuthError(
                f"Token file not found: {self._token_file}. Run 'devantis login' first."
            )
        try:
            data = json.loads(self._token_file.read_text())
            self._access_token = data.get("access_token")
            self._refresh_token = data.get("refresh_token")
            saved_at = data.get("_saved_at", 0)
            expires_in = data.get("expires_in", 300)
            self._expires_at = saved_at + expires_in - 30
        except (json.JSONDecodeError, KeyError) as e:
            raise AuthError(f"Invalid token file: {e}") from e

    def _is_expired(self) -> bool:
        return time.time() >= self._expires_at

    async def get_headers(self) -> dict[str, str]:
        if self._is_expired():
            await self.refresh()
        return {"Authorization": f"Bearer {self._access_token}"}

    async def refresh(self) -> None:
        async with self._lock:
            # Double-check after acquiring lock (another coroutine may have refreshed)
            if not self._is_expired():
                return

            if not self._refresh_token:
                raise AuthError("No refresh token. Run 'devantis login'.")

            token_url = (
                f"{self._keycloak_url}/realms/{self._realm}"
                f"/protocol/openid-connect/token"
            )
            try:
                response = await self._http.post(
                    token_url,
                    data={
                        "grant_type": "refresh_token",
                        "refresh_token": self._refresh_token,
                        "client_id": self._client_id,
                    },
                )
                if response.status_code != 200:
                    raise AuthError(
                        f"Token refresh failed ({response.status_code}). Run 'devantis login'."
                    )
                data = response.json()
                self._access_token = data["access_token"]
                self._refresh_token = data.get("refresh_token", self._refresh_token)
                self._expires_at = time.time() + data.get("expires_in", 300) - 30

                # Persist refreshed token for CLI compatibility
                self._save_token_file(data)
                logger.debug("Token refreshed successfully")

            except httpx.HTTPError as e:
                raise AuthError(f"Token refresh failed: {e}") from e

    def _save_token_file(self, data: dict) -> None:
        """Save refreshed token back to file (CLI can reuse it)."""
        try:
            save_data = {
                "access_token": data["access_token"],
                "refresh_token": data.get("refresh_token", self._refresh_token),
                "expires_in": data.get("expires_in", 300),
                "token_type": data.get("token_type", "Bearer"),
                "_saved_at": time.time(),
            }
            self._token_file.write_text(json.dumps(save_data))
        except OSError:
            pass  # Non-critical — token works in memory even if file write fails


class InternalAuth(BaseAuth):
    """Auth using internal service key (for agentic executor inside Docker).

    No token refresh needed — the key doesn't expire.
    """

    def __init__(self, service_key: str):
        if not service_key:
            raise AuthError("INTERNAL_SERVICE_KEY is empty")
        self._key = service_key

    @classmethod
    def from_env(cls) -> InternalAuth:
        import os
        key = os.environ.get("INTERNAL_SERVICE_KEY", "")
        if not key:
            raise AuthError("INTERNAL_SERVICE_KEY not set in environment")
        return cls(service_key=key)

    async def get_headers(self) -> dict[str, str]:
        return {"X-Internal-Service-Key": self._key}


class ServiceAccountAuth(BaseAuth):
    """Auth using Keycloak client_credentials grant (for server-side deployments)."""

    def __init__(
        self,
        keycloak_url: str,
        realm: str,
        client_id: str,
        client_secret: str,
    ):
        self._keycloak_url = keycloak_url
        self._realm = realm
        self._client_id = client_id
        self._client_secret = client_secret
        self._access_token: str | None = None
        self._expires_at: float = 0
        self._http = httpx.AsyncClient(timeout=15.0)
        self._lock = asyncio.Lock()

    async def get_headers(self) -> dict[str, str]:
        if self._access_token is None or time.time() >= self._expires_at:
            await self.refresh()
        return {"Authorization": f"Bearer {self._access_token}"}

    async def refresh(self) -> None:
        async with self._lock:
            if self._access_token and time.time() < self._expires_at:
                return

            token_url = (
                f"{self._keycloak_url}/realms/{self._realm}"
                f"/protocol/openid-connect/token"
            )
            response = await self._http.post(
                token_url,
                data={
                    "grant_type": "client_credentials",
                    "client_id": self._client_id,
                    "client_secret": self._client_secret,
                },
            )
            if response.status_code != 200:
                raise AuthError(f"Service account auth failed: {response.status_code}")
            data = response.json()
            self._access_token = data["access_token"]
            self._expires_at = time.time() + data.get("expires_in", 300) - 30


def auto_detect_auth() -> BaseAuth:
    """Auto-detect the best auth mode based on environment.

    Priority:
    1. INTERNAL_SERVICE_KEY env var → InternalAuth (Docker/executor)
    2. ~/.devantis_token.json exists → UserTokenAuth (local dev/CLI)
    3. Error with clear message
    """
    import os

    key = os.environ.get("INTERNAL_SERVICE_KEY")
    if key:
        return InternalAuth(service_key=key)

    token_file = Path("~/.devantis_token.json").expanduser()
    if token_file.exists():
        return UserTokenAuth(token_file=token_file)

    raise AuthError(
        "No authentication configured.\n"
        "  - For local development: run 'devantis login'\n"
        "  - For Docker/executor: set INTERNAL_SERVICE_KEY environment variable"
    )
