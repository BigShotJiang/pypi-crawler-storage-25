"""Base HTTP client with auth, tenant, retries, and error mapping.

Supports two modes:
- **Gateway mode** (default): all services behind a single URL with path-based routing
  (development: https://devantis.dev.encodeit.ro/api/{service}/...)
- **Local mode**: each service has its own URL (localhost:807x) — for local development

The default is production gateway. Override with:
- DEVANTIS_API_URL env var (set to empty string "" for local mode)
- ~/.devantis-mcp.yaml config file
- INTERNAL_SERVICE_KEY env var (auto-switches to Docker service URLs)
"""

from __future__ import annotations

import asyncio
import logging
import os

import httpx

from devantis.auth import BaseAuth
from devantis.errors import (
    AuthError, Conflict, DevantisError, Forbidden, NotFound,
    RateLimited, ServiceUnavailable, ValidationError,
)
from devantis.tenant import TenantContext

logger = logging.getLogger(__name__)

# Default service URLs — host-mapped ports from docker-compose.
# These are the ports exposed to localhost when running `make up` from infrastructure/.
# NOTE: host ports differ from container-internal ports for several services.
DEFAULT_SERVICES = {
    "ticket-service": "http://localhost:8076",           # container 8076 → host 8076
    "requirement-service": "http://localhost:8075",      # container 8075 → host 8075
    "sourcecode-service": "http://localhost:8079",       # container 8079 → host 8079
    "architecture-service": "http://localhost:8077",     # container 8077 → host 8077
    "designs-service": "http://localhost:8078",          # container 8078 → host 8078
    "chat-service": "http://localhost:8090",             # container 8090 → host 8090 (via chat-lb)
    "executor-service": "http://localhost:8094",         # container 8090 → host 8094
    "project-service": "http://localhost:8081",          # container 8081 → host 8081
    "organisation-service": "http://localhost:8083",     # container 8083 → host 8083
    "user-service": "http://localhost:8086",             # container 8082 → host 8086
    "storage-service": "http://localhost:8082",          # container 8080 → host 8082
    "notification-service": "http://localhost:8096",     # container 8095 → host 8096
    "knowledge-graph-service": "http://localhost:8097",  # container 8097 → host 8097
    "documentation-service": "http://localhost:8098",    # container 8098 → host 8098
    "licensing-service": "http://localhost:8099",        # container 8099 → host 8099
}

# Docker-internal service URLs — container names and internal ports.
# Used when the SDK itself runs inside the Docker network (e.g., as a container).
DOCKER_SERVICES = {
    "ticket-service": "http://ticket-service:8076",
    "requirement-service": "http://requirement-service:8075",
    "sourcecode-service": "http://sourcecode-service:8079",
    "architecture-service": "http://architecture-service:8077",
    "designs-service": "http://designs-service:8078",
    "chat-service": "http://chat-service:8090",
    "executor-service": "http://executor-service:8090",
    "project-service": "http://project-service:8081",
    "organisation-service": "http://organisation-service:8083",
    "user-service": "http://user-service:8082",
    "storage-service": "http://storage-service:8080",
    "notification-service": "http://notification-service:8095",
    "knowledge-graph-service": "http://knowledge-graph-service:8097",
    "documentation-service": "http://documentation-service:8098",
    "licensing-service": "http://licensing-service:8099",
}

# Gateway path prefixes — used when all services are behind a single domain
# The nginx ingress strips this prefix before forwarding to the service.
# e.g., https://devantis.dev.encodeit.ro/api/tickets/api/v1/... → /api/v1/...
GATEWAY_PREFIXES = {
    "ticket-service": "/api/tickets",
    "requirement-service": "/api/requirements",
    "sourcecode-service": "/api/sourcecode",
    "architecture-service": "/api/architecture",
    "designs-service": "/api/designs",
    "chat-service": "/api/chat",
    "executor-service": "/api/executor",
    "project-service": "/api/projects",
    "organisation-service": "/api/organisations",
    "user-service": "/api/users",
    "storage-service": "/api/storage",
    "notification-service": "/api/notifications",
    "knowledge-graph-service": "/api/knowledge-graph",
    "documentation-service": "/api/documentation",
    "licensing-service": "/api/licensing",
}


class BaseClient:
    """HTTP client shared by all services. Handles auth, tenant, retries, errors.

    Supports gateway mode for production (single URL, path-based routing).
    """

    def __init__(
        self,
        auth: BaseAuth,
        tenant: TenantContext,
        services: dict[str, str] | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        gateway_url: str = "",
    ):
        self.auth = auth
        self.tenant = tenant
        self.services = services or DEFAULT_SERVICES
        self._http = httpx.AsyncClient(timeout=timeout)
        self._max_retries = max_retries

        # Gateway mode: all services behind a single URL
        # Default to production. Set DEVANTIS_API_URL="" for local mode.
        self._gateway_url = (
            gateway_url
            or os.environ.get("DEVANTIS_API_URL", "https://devantis.dev.encodeit.ro")
        ).rstrip("/")

    @property
    def gateway_mode(self) -> bool:
        return bool(self._gateway_url)

    def service_url(self, service: str) -> str:
        """Get base URL for a service.

        In gateway mode, returns the gateway URL (caller must use _build_url for full path).
        In local/docker mode, returns the direct service URL.
        """
        if self._gateway_url:
            return self._gateway_url
        url = self.services.get(service)
        if not url:
            raise DevantisError(f"Unknown service: {service}")
        return url

    def _build_url(self, service: str, path: str) -> str:
        """Build the full URL for a request.

        In gateway mode: {gateway_url}{gateway_prefix}{path}
        In local mode: {service_url}{path}
        """
        if self._gateway_url:
            prefix = GATEWAY_PREFIXES.get(service, "")
            return f"{self._gateway_url}{prefix}{path}"
        return self.service_url(service) + path

    async def get(self, service: str, path: str, **kwargs) -> httpx.Response:
        return await self._request("GET", service, path, **kwargs)

    async def post(self, service: str, path: str, **kwargs) -> httpx.Response:
        return await self._request("POST", service, path, **kwargs)

    async def put(self, service: str, path: str, **kwargs) -> httpx.Response:
        return await self._request("PUT", service, path, **kwargs)

    async def patch(self, service: str, path: str, **kwargs) -> httpx.Response:
        return await self._request("PATCH", service, path, **kwargs)

    async def delete(self, service: str, path: str, **kwargs) -> httpx.Response:
        return await self._request("DELETE", service, path, **kwargs)

    async def _request(
        self,
        method: str,
        service: str,
        path: str,
        **kwargs,
    ) -> httpx.Response:
        """Make an authenticated request with retries and error mapping."""
        url = self._build_url(service, path)
        headers = {**(await self.auth.get_headers()), **self.tenant.context_headers()}

        # Merge any extra headers from caller
        if "headers" in kwargs:
            headers.update(kwargs.pop("headers"))

        last_error: Exception | None = None

        for attempt in range(self._max_retries):
            try:
                response = await self._http.request(
                    method, url, headers=headers, **kwargs
                )
            except httpx.ConnectError as e:
                last_error = ServiceUnavailable(service=service, message=str(e))
                if attempt < self._max_retries - 1:
                    await asyncio.sleep(1 * (attempt + 1))
                    continue
                raise last_error from e
            except httpx.TimeoutException as e:
                last_error = ServiceUnavailable(
                    service=service, message=f"Request timed out: {e}"
                )
                if attempt < self._max_retries - 1:
                    await asyncio.sleep(1 * (attempt + 1))
                    continue
                raise last_error from e

            # 401 — try refreshing token once
            if response.status_code == 401 and attempt == 0:
                try:
                    await self.auth.refresh()
                    headers.update(await self.auth.get_headers())
                    continue
                except AuthError:
                    self._raise_for_status(response, service)

            # 429 — respect Retry-After
            if response.status_code == 429:
                retry_after = int(response.headers.get("Retry-After", 5))
                if attempt < self._max_retries - 1:
                    await asyncio.sleep(retry_after)
                    continue
                raise RateLimited(retry_after=retry_after, service=service)

            # 5xx — retry with backoff
            if response.status_code >= 500 and attempt < self._max_retries - 1:
                await asyncio.sleep(1 * (attempt + 1))
                continue

            # Success or client error — stop retrying
            break

        self._raise_for_status(response, service)
        return response

    def _raise_for_status(self, response: httpx.Response, service: str) -> None:
        """Map HTTP status codes to typed exceptions."""
        status = response.status_code
        if status < 400:
            return

        body = ""
        try:
            body = response.text[:500]
        except Exception:
            pass

        if status == 401:
            raise AuthError(f"Authentication failed. Run 'devantis login'. ({body})")
        if status == 403:
            raise Forbidden(message=f"Permission denied: {body}", service=service)
        if status == 404:
            raise NotFound(service=service)
        if status == 409:
            raise Conflict(message=f"Conflict: {body}", service=service)
        if status == 422:
            try:
                detail = response.json().get("detail", body)
            except Exception:
                detail = body
            raise ValidationError(detail=detail, service=service)
        if status == 429:
            retry_after = int(response.headers.get("Retry-After", 5))
            raise RateLimited(retry_after=retry_after, service=service)
        if status >= 500:
            raise ServiceUnavailable(service=service, message=body)

        raise DevantisError(f"HTTP {status}: {body}", service=service, status_code=status)

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._http.aclose()
