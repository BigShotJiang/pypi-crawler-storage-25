"""Cross-entity search — search across all platform entities in parallel."""

from __future__ import annotations

import asyncio
import logging

from devantis.client import BaseClient

logger = logging.getLogger(__name__)

ENTITY_SERVICES = {
    "requirements": ("requirement-service", "/requirements/search"),
    "tickets": ("ticket-service", "/tickets/search"),
    "architecture": ("architecture-service", "/search"),
    "designs": ("designs-service", "/search"),
    "code": ("sourcecode-service", "/search"),
}


class SearchService:
    """Cross-entity search — one call to search everything."""

    def __init__(self, http: BaseClient):
        self._http = http
        self._bases = {
            "requirements": f"/api/v1/organisations/{http.tenant.org_id}/projects/{http.tenant.project_id}/apps/{http.tenant.app_id}",
            "tickets": f"/api/v1/org/{http.tenant.org_id}/project/{http.tenant.project_id}/app/{http.tenant.app_id}",
            "architecture": f"/api/v1/org/{http.tenant.org_id}/project/{http.tenant.project_id}/app/{http.tenant.app_id}/architectures",
            "designs": f"/api/v1/org/{http.tenant.org_id}/project/{http.tenant.project_id}/app/{http.tenant.app_id}/designs",
            "code": f"/api/v1/org/{http.tenant.org_id}/project/{http.tenant.project_id}/app/{http.tenant.app_id}/sourcecode",
        }

    async def search(
        self,
        query: str,
        entity_types: list[str] | None = None,
        max_results_per_type: int = 5,
    ) -> dict:
        """Search across all entity types in parallel.

        Returns results grouped by entity type.
        """
        types = entity_types or list(ENTITY_SERVICES.keys())

        async def search_one(entity_type: str) -> tuple[str, list[dict]]:
            service, path_suffix = ENTITY_SERVICES[entity_type]
            base = self._bases.get(entity_type, "")
            full_path = f"{base}{path_suffix}"
            try:
                response = await self._http.get(
                    service, full_path,
                    params={"q": query, "max_results": max_results_per_type},
                )
                data = response.json()
                # Different services return results in different formats
                if isinstance(data, list):
                    return entity_type, data[:max_results_per_type]
                if isinstance(data, dict):
                    items = data.get("results", data.get("items", []))
                    return entity_type, items[:max_results_per_type]
                return entity_type, []
            except Exception as e:
                logger.debug(f"Search failed for {entity_type}: {e}")
                return entity_type, []

        tasks = [search_one(t) for t in types if t in ENTITY_SERVICES]
        results_list = await asyncio.gather(*tasks)

        return {entity_type: items for entity_type, items in results_list}
