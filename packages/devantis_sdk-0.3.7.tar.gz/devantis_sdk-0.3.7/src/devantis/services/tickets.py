"""Ticket service — full ticket lifecycle, sub-resources, sprints, epics, boards, charts."""

from __future__ import annotations

from devantis.client import BaseClient

SERVICE = "ticket-service"


class TicketService:
    """Ticket operations including sub-resources, sprints, epics, boards, and charts."""

    def __init__(self, http: BaseClient):
        self._http = http
        self._base = f"/api/v1/org/{http.tenant.org_id}/project/{http.tenant.project_id}/app/{http.tenant.app_id}"

    # ── Core CRUD ─────────────────────────────────────────────

    async def list(
        self,
        status: str = "",
        feature: str = "",
        priority: str = "",
        assignee: str = "",
        sprint_id: str = "",
        epic_id: str = "",
        page: int = 1,
        page_size: int = 30,
    ) -> dict:
        """List tickets with optional filters."""
        params: dict = {"page": page, "page_size": page_size}
        if status: params["status"] = status
        if feature: params["feature"] = feature
        if priority: params["priority"] = priority
        if assignee: params["assignee"] = assignee
        if sprint_id: params["sprint_id"] = sprint_id
        if epic_id: params["epic_id"] = epic_id
        response = await self._http.get(SERVICE, f"{self._base}/tickets", params=params)
        return response.json()

    async def get(self, ticket_id: str) -> dict:
        """Get full ticket details."""
        response = await self._http.get(SERVICE, f"{self._base}/tickets/{ticket_id}")
        return response.json()

    async def create(self, **kwargs) -> dict:
        """Create a ticket. Required: title, description, feature."""
        response = await self._http.post(SERVICE, f"{self._base}/tickets", json=kwargs)
        return response.json()

    async def update(self, ticket_id: str, **kwargs) -> dict:
        """Update a ticket."""
        response = await self._http.patch(SERVICE, f"{self._base}/tickets/{ticket_id}", json=kwargs)
        return response.json()

    async def delete(self, ticket_id: str) -> None:
        """Delete a ticket."""
        await self._http.delete(SERVICE, f"{self._base}/tickets/{ticket_id}")

    async def search(self, query: str, feature: str = "", max_results: int = 50) -> list[dict]:
        """Full-text search across tickets."""
        params: dict = {"q": query, "max_results": max_results}
        if feature: params["feature"] = feature
        response = await self._http.get(SERVICE, f"{self._base}/tickets/search", params=params)
        return response.json()

    async def list_features(self) -> list[str]:
        """List all feature categories."""
        response = await self._http.get(SERVICE, f"{self._base}/tickets/features")
        return response.json()

    # ── Status Workflow ───────────────────────────────────────

    async def transition(self, ticket_id: str, action: str, reason: str = "") -> dict:
        """Change ticket status."""
        action_map = {
            "start": "start-progress",
            "submit_review": "submit-for-review",
            "move_testing": "move-to-testing",
            "done": "mark-done",
            "block": "block",
            "unblock": "unblock",
            "backlog": "move-to-backlog",
            "reopen": "reopen",
        }
        endpoint = action_map.get(action, action)
        body = {"reason": reason} if reason else {}
        response = await self._http.post(
            SERVICE, f"{self._base}/tickets/{ticket_id}/{endpoint}", json=body
        )
        return response.json()

    # ── Comments ──────────────────────────────────────────────

    async def add_comment(self, ticket_id: str, content: str) -> dict:
        """Add a comment to a ticket."""
        response = await self._http.post(
            SERVICE, f"{self._base}/tickets/{ticket_id}/comments",
            json={"content": content},
        )
        return response.json()

    async def list_comments(self, ticket_id: str) -> list[dict]:
        """List comments on a ticket."""
        response = await self._http.get(SERVICE, f"{self._base}/tickets/{ticket_id}/comments")
        return response.json()

    # ── Labels ────────────────────────────────────────────────

    async def list_labels(self) -> list[dict]:
        """List all labels for the app."""
        response = await self._http.get(SERVICE, f"{self._base}/labels")
        return response.json()

    async def create_label(self, name: str, color: str = "", description: str = "") -> dict:
        """Create a label."""
        body: dict = {"name": name}
        if color: body["color"] = color
        if description: body["description"] = description
        response = await self._http.post(SERVICE, f"{self._base}/labels", json=body)
        return response.json()

    async def delete_label(self, label_id: str) -> None:
        """Delete a label."""
        await self._http.delete(SERVICE, f"{self._base}/labels/{label_id}")

    async def add_label_to_ticket(self, ticket_id: str, label_id: str) -> dict:
        """Add a label to a ticket."""
        response = await self._http.post(
            SERVICE, f"{self._base}/tickets/{ticket_id}/labels/{label_id}"
        )
        return response.json()

    async def remove_label_from_ticket(self, ticket_id: str, label_id: str) -> None:
        """Remove a label from a ticket."""
        await self._http.delete(
            SERVICE, f"{self._base}/tickets/{ticket_id}/labels/{label_id}"
        )

    async def get_ticket_labels(self, ticket_id: str) -> list[dict]:
        """Get labels on a ticket."""
        response = await self._http.get(
            SERVICE, f"{self._base}/tickets/{ticket_id}/labels"
        )
        return response.json()

    # ── Subtasks ──────────────────────────────────────────────

    async def list_subtasks(self, ticket_id: str) -> list[dict]:
        """List subtasks on a ticket."""
        response = await self._http.get(
            SERVICE, f"{self._base}/tickets/{ticket_id}/subtasks"
        )
        return response.json()

    async def create_subtask(self, ticket_id: str, title: str, description: str = "") -> dict:
        """Create a subtask on a ticket."""
        body: dict = {"title": title}
        if description: body["description"] = description
        response = await self._http.post(
            SERVICE, f"{self._base}/tickets/{ticket_id}/subtasks", json=body
        )
        return response.json()

    async def update_subtask(
        self, ticket_id: str, subtask_id: str, **kwargs
    ) -> dict:
        """Update a subtask (title, description, is_completed, position)."""
        response = await self._http.patch(
            SERVICE, f"{self._base}/tickets/{ticket_id}/subtasks/{subtask_id}",
            json=kwargs,
        )
        return response.json()

    async def delete_subtask(self, ticket_id: str, subtask_id: str) -> None:
        """Delete a subtask."""
        await self._http.delete(
            SERVICE, f"{self._base}/tickets/{ticket_id}/subtasks/{subtask_id}"
        )

    # ── Links ─────────────────────────────────────────────────

    async def list_links(self, ticket_id: str) -> list[dict]:
        """List ticket links (blocks, duplicates, relates_to, parent/child)."""
        response = await self._http.get(
            SERVICE, f"{self._base}/tickets/{ticket_id}/links"
        )
        return response.json()

    async def create_link(
        self, ticket_id: str, target_ticket_id: str, link_type: str
    ) -> dict:
        """Create a link. Types: BLOCKS, BLOCKED_BY, DUPLICATES, DUPLICATED_BY, RELATES_TO, PARENT_OF, CHILD_OF."""
        response = await self._http.post(
            SERVICE, f"{self._base}/tickets/{ticket_id}/links",
            json={"target_ticket_id": target_ticket_id, "link_type": link_type},
        )
        return response.json()

    async def delete_link(self, ticket_id: str, link_id: str) -> None:
        """Delete a ticket link."""
        await self._http.delete(
            SERVICE, f"{self._base}/tickets/{ticket_id}/links/{link_id}"
        )

    # ── Watchers ──────────────────────────────────────────────

    async def list_watchers(self, ticket_id: str) -> list[dict]:
        """List watchers on a ticket."""
        response = await self._http.get(
            SERVICE, f"{self._base}/tickets/{ticket_id}/watchers"
        )
        return response.json()

    async def watch_ticket(self, ticket_id: str) -> dict:
        """Add current user as watcher."""
        response = await self._http.post(
            SERVICE, f"{self._base}/tickets/{ticket_id}/watchers"
        )
        return response.json()

    async def unwatch_ticket(self, ticket_id: str) -> None:
        """Remove current user from watchers."""
        await self._http.delete(
            SERVICE, f"{self._base}/tickets/{ticket_id}/watchers"
        )

    # ── Voting ────────────────────────────────────────────────

    async def get_votes(self, ticket_id: str) -> dict:
        """Get vote count and whether current user voted."""
        response = await self._http.get(
            SERVICE, f"{self._base}/tickets/{ticket_id}/votes"
        )
        return response.json()

    async def vote(self, ticket_id: str) -> dict:
        """Vote for a ticket."""
        response = await self._http.post(
            SERVICE, f"{self._base}/tickets/{ticket_id}/votes"
        )
        return response.json()

    async def unvote(self, ticket_id: str) -> None:
        """Remove vote from a ticket."""
        await self._http.delete(
            SERVICE, f"{self._base}/tickets/{ticket_id}/votes"
        )

    # ── Time Logs ─────────────────────────────────────────────

    async def list_timelogs(self, ticket_id: str) -> list[dict]:
        """List time logs on a ticket."""
        response = await self._http.get(
            SERVICE, f"{self._base}/tickets/{ticket_id}/timelogs"
        )
        return response.json()

    async def log_time(
        self, ticket_id: str, hours_spent: float, description: str = "", work_date: str = ""
    ) -> dict:
        """Log time on a ticket."""
        body: dict = {"hours_spent": hours_spent}
        if description: body["description"] = description
        if work_date: body["work_date"] = work_date
        response = await self._http.post(
            SERVICE, f"{self._base}/tickets/{ticket_id}/timelogs", json=body
        )
        return response.json()

    async def delete_timelog(self, ticket_id: str, log_id: str) -> None:
        """Delete a time log."""
        await self._http.delete(
            SERVICE, f"{self._base}/tickets/{ticket_id}/timelogs/{log_id}"
        )

    # ── Milestones ────────────────────────────────────────────

    async def list_milestones(self, status: str = "") -> list[dict]:
        """List milestones."""
        params: dict = {}
        if status: params["status"] = status
        response = await self._http.get(
            SERVICE, f"{self._base}/milestones", params=params
        )
        return response.json()

    async def create_milestone(
        self, name: str, description: str = "", due_date: str = ""
    ) -> dict:
        """Create a milestone."""
        body: dict = {"name": name}
        if description: body["description"] = description
        if due_date: body["due_date"] = due_date
        response = await self._http.post(
            SERVICE, f"{self._base}/milestones", json=body
        )
        return response.json()

    async def update_milestone(self, milestone_id: str, **kwargs) -> dict:
        """Update a milestone."""
        response = await self._http.patch(
            SERVICE, f"{self._base}/milestones/{milestone_id}", json=kwargs
        )
        return response.json()

    async def delete_milestone(self, milestone_id: str) -> None:
        """Delete a milestone."""
        await self._http.delete(SERVICE, f"{self._base}/milestones/{milestone_id}")

    async def add_ticket_to_milestone(self, milestone_id: str, ticket_id: str) -> dict:
        """Add a ticket to a milestone."""
        response = await self._http.post(
            SERVICE, f"{self._base}/milestones/{milestone_id}/tickets/{ticket_id}"
        )
        return response.json()

    async def remove_ticket_from_milestone(self, milestone_id: str, ticket_id: str) -> None:
        """Remove a ticket from a milestone."""
        await self._http.delete(
            SERVICE, f"{self._base}/milestones/{milestone_id}/tickets/{ticket_id}"
        )

    # ── Components ────────────────────────────────────────────

    async def list_components(self) -> list[dict]:
        """List components."""
        response = await self._http.get(SERVICE, f"{self._base}/components")
        return response.json()

    async def create_component(self, name: str, description: str = "") -> dict:
        """Create a component."""
        body: dict = {"name": name}
        if description: body["description"] = description
        response = await self._http.post(
            SERVICE, f"{self._base}/components", json=body
        )
        return response.json()

    async def delete_component(self, component_id: str) -> None:
        """Delete a component."""
        await self._http.delete(SERVICE, f"{self._base}/components/{component_id}")

    async def add_ticket_to_component(self, component_id: str, ticket_id: str) -> dict:
        """Add a ticket to a component."""
        response = await self._http.post(
            SERVICE, f"{self._base}/components/{component_id}/tickets/{ticket_id}"
        )
        return response.json()

    # ── Filters ───────────────────────────────────────────────

    async def list_filters(self, include_public: bool = True) -> list[dict]:
        """List saved filters."""
        params: dict = {}
        if include_public: params["include_public"] = "true"
        response = await self._http.get(
            SERVICE, f"{self._base}/filters", params=params
        )
        return response.json()

    async def create_filter(self, name: str, filter_query: dict, is_public: bool = False) -> dict:
        """Create a saved filter."""
        response = await self._http.post(
            SERVICE, f"{self._base}/filters",
            json={"name": name, "filter_query": filter_query, "is_public": is_public},
        )
        return response.json()

    async def execute_filter(self, filter_id: str, page: int = 1, page_size: int = 30) -> dict:
        """Execute a saved filter and get matching tickets."""
        response = await self._http.post(
            SERVICE, f"{self._base}/filters/{filter_id}/execute",
            params={"page": page, "page_size": page_size},
        )
        return response.json()

    async def delete_filter(self, filter_id: str) -> None:
        """Delete a saved filter."""
        await self._http.delete(SERVICE, f"{self._base}/filters/{filter_id}")

    # ── Sprints ───────────────────────────────────────────────

    async def list_sprints(self, status: str = "") -> list[dict]:
        """List sprints."""
        params: dict = {}
        if status: params["status"] = status
        response = await self._http.get(
            SERVICE, f"{self._base}/sprints", params=params
        )
        return response.json()

    async def get_sprint(self, sprint_id: str) -> dict:
        """Get sprint details."""
        response = await self._http.get(
            SERVICE, f"{self._base}/sprints/{sprint_id}"
        )
        return response.json()

    async def create_sprint(self, name: str, goal: str = "", start_date: str = "", end_date: str = "") -> dict:
        """Create a sprint."""
        body: dict = {"name": name}
        if goal: body["goal"] = goal
        if start_date: body["start_date"] = start_date
        if end_date: body["end_date"] = end_date
        response = await self._http.post(
            SERVICE, f"{self._base}/sprints", json=body
        )
        return response.json()

    async def update_sprint(self, sprint_id: str, **kwargs) -> dict:
        """Update a sprint."""
        response = await self._http.patch(
            SERVICE, f"{self._base}/sprints/{sprint_id}", json=kwargs
        )
        return response.json()

    async def delete_sprint(self, sprint_id: str) -> None:
        """Delete a sprint."""
        await self._http.delete(SERVICE, f"{self._base}/sprints/{sprint_id}")

    async def start_sprint(self, sprint_id: str) -> dict:
        """Start a sprint (planning -> active)."""
        response = await self._http.post(
            SERVICE, f"{self._base}/sprints/{sprint_id}/start"
        )
        return response.json()

    async def complete_sprint(self, sprint_id: str) -> dict:
        """Complete a sprint (active -> completed)."""
        response = await self._http.post(
            SERVICE, f"{self._base}/sprints/{sprint_id}/complete"
        )
        return response.json()

    async def get_sprint_tickets(self, sprint_id: str) -> list[dict]:
        """List tickets in a sprint."""
        response = await self._http.get(
            SERVICE, f"{self._base}/sprints/{sprint_id}/tickets"
        )
        return response.json()

    async def add_ticket_to_sprint(self, sprint_id: str, ticket_id: str) -> dict:
        """Add a ticket to a sprint."""
        response = await self._http.post(
            SERVICE, f"{self._base}/sprints/{sprint_id}/tickets/{ticket_id}"
        )
        return response.json()

    async def remove_ticket_from_sprint(self, sprint_id: str, ticket_id: str) -> None:
        """Remove a ticket from a sprint."""
        await self._http.delete(
            SERVICE, f"{self._base}/sprints/{sprint_id}/tickets/{ticket_id}"
        )

    # ── Epics ─────────────────────────────────────────────────

    async def list_epics(self, status: str = "") -> list[dict]:
        """List epics."""
        params: dict = {}
        if status: params["status"] = status
        response = await self._http.get(
            SERVICE, f"{self._base}/epics", params=params
        )
        return response.json()

    async def get_epic(self, epic_id: str) -> dict:
        """Get epic details."""
        response = await self._http.get(
            SERVICE, f"{self._base}/epics/{epic_id}"
        )
        return response.json()

    async def create_epic(self, name: str, summary: str = "", description: str = "", color: str = "") -> dict:
        """Create an epic."""
        body: dict = {"name": name}
        if summary: body["summary"] = summary
        if description: body["description"] = description
        if color: body["color"] = color
        response = await self._http.post(
            SERVICE, f"{self._base}/epics", json=body
        )
        return response.json()

    async def update_epic(self, epic_id: str, **kwargs) -> dict:
        """Update an epic."""
        response = await self._http.patch(
            SERVICE, f"{self._base}/epics/{epic_id}", json=kwargs
        )
        return response.json()

    async def delete_epic(self, epic_id: str) -> None:
        """Delete an epic."""
        await self._http.delete(SERVICE, f"{self._base}/epics/{epic_id}")

    async def get_epic_tickets(self, epic_id: str) -> list[dict]:
        """List tickets in an epic."""
        response = await self._http.get(
            SERVICE, f"{self._base}/epics/{epic_id}/tickets"
        )
        return response.json()

    async def add_ticket_to_epic(self, epic_id: str, ticket_id: str) -> dict:
        """Add a ticket to an epic."""
        response = await self._http.post(
            SERVICE, f"{self._base}/epics/{epic_id}/tickets/{ticket_id}"
        )
        return response.json()

    async def remove_ticket_from_epic(self, epic_id: str, ticket_id: str) -> None:
        """Remove a ticket from an epic."""
        await self._http.delete(
            SERVICE, f"{self._base}/epics/{epic_id}/tickets/{ticket_id}"
        )

    # ── Boards ────────────────────────────────────────────────

    async def get_board(
        self,
        board_type: str = "kanban",
        feature: str = "",
        sprint_id: str = "",
        epic_id: str = "",
    ) -> dict:
        """Get a board view. Types: kanban, by-assignee, by-feature, by-priority."""
        params: dict = {}
        if feature: params["feature"] = feature
        if sprint_id: params["sprint_id"] = sprint_id
        if epic_id: params["epic_id"] = epic_id
        response = await self._http.get(
            SERVICE, f"{self._base}/boards/{board_type}", params=params
        )
        return response.json()

    # ── Charts ────────────────────────────────────────────────

    async def get_burndown(self, sprint_id: str) -> dict:
        """Get burndown chart data for a sprint."""
        response = await self._http.get(
            SERVICE, f"{self._base}/charts/burndown/{sprint_id}"
        )
        return response.json()

    async def get_burnup(self, sprint_id: str) -> dict:
        """Get burnup chart data for a sprint."""
        response = await self._http.get(
            SERVICE, f"{self._base}/charts/burnup/{sprint_id}"
        )
        return response.json()

    async def get_cumulative_flow(self, days: int = 30) -> dict:
        """Get cumulative flow diagram data."""
        response = await self._http.get(
            SERVICE, f"{self._base}/charts/cumulative-flow", params={"days": days}
        )
        return response.json()

    async def get_velocity(self, sprints: int = 6) -> dict:
        """Get velocity chart data for recent sprints."""
        response = await self._http.get(
            SERVICE, f"{self._base}/charts/velocity", params={"sprints": sprints}
        )
        return response.json()

    # ── Stats ─────────────────────────────────────────────────

    async def get_stats(self) -> dict:
        """Get ticket statistics summary."""
        response = await self._http.get(SERVICE, f"{self._base}/stats/summary")
        return response.json()

    # ── Bulk Operations ───────────────────────────────────────

    async def bulk_create(self, tickets: list[dict]) -> dict:
        """Create multiple tickets at once."""
        response = await self._http.post(
            SERVICE, f"{self._base}/bulk/create", json={"tickets": tickets}
        )
        return response.json()

    async def bulk_get(self, ticket_ids: list[str]) -> dict:
        """Fetch multiple tickets by ID."""
        response = await self._http.post(
            SERVICE, f"{self._base}/bulk/get", json={"ticket_ids": ticket_ids}
        )
        return response.json()

    async def bulk_update(self, ticket_ids: list[str], **kwargs) -> dict:
        """Bulk update tickets."""
        body = {"ticket_ids": ticket_ids, **kwargs}
        response = await self._http.post(SERVICE, f"{self._base}/bulk/update", json=body)
        return response.json()

    async def bulk_delete(self, ticket_ids: list[str]) -> dict:
        """Bulk delete tickets."""
        response = await self._http.post(
            SERVICE, f"{self._base}/bulk/delete", json={"ticket_ids": ticket_ids}
        )
        return response.json()

    async def bulk_move_to_sprint(self, sprint_id: str, ticket_ids: list[str]) -> dict:
        """Bulk move tickets to a sprint."""
        response = await self._http.post(
            SERVICE, f"{self._base}/bulk/move-to-sprint/{sprint_id}",
            json={"ticket_ids": ticket_ids},
        )
        return response.json()
