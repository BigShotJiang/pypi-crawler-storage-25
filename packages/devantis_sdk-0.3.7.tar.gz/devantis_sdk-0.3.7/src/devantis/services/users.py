"""User service — search, lookup, and current user profile."""

from __future__ import annotations

from devantis.client import BaseClient

SERVICE = "user-service"


class UserService:
    """User lookup and profile operations."""

    def __init__(self, http: BaseClient):
        self._http = http
        self._base = "/api/v1/users"

    async def search(self, query: str = "") -> list[dict]:
        """Search users by name or email.

        Args:
            query: Search string. Empty string returns all visible users.
        """
        params = {}
        if query:
            params["search"] = query
        response = await self._http.get(SERVICE, self._base, params=params)
        return response.json()

    async def get(self, user_id: str) -> dict:
        """Get a user by ID."""
        response = await self._http.get(SERVICE, f"{self._base}/{user_id}")
        return response.json()

    async def me(self) -> dict:
        """Get the current user's profile."""
        response = await self._http.get(SERVICE, f"{self._base}/me")
        return response.json()
