"""Executor service — agents, jobs, shell execution, MCP tool calls, K8s deployments."""

from __future__ import annotations

import asyncio
import json
import logging

from devantis.client import BaseClient
from devantis.errors import DevantisError, NotFound

logger = logging.getLogger(__name__)

SERVICE = "executor-service"

# Terminal job statuses — no further state changes expected.
_TERMINAL_STATUSES = frozenset({"completed", "failed", "cancelled", "timeout"})

# Default poll interval / timeout for job completion.
_POLL_INTERVAL = 2.0  # seconds
_DEFAULT_TIMEOUT = 120  # seconds


class ExecutorService:
    """Executor operations — agents, jobs, shell, MCP, K8s deployments."""

    def __init__(self, http: BaseClient):
        self._http = http
        self._base = "/api/v1"

    # ── Agents ────────────────────────────────────────────────────

    async def list(self, status: str = "") -> list[dict]:
        """List agents visible to the current tenant.

        Args:
            status: Optional filter — 'online', 'offline', 'busy', 'error'.
        """
        params = {}
        if status:
            params["status"] = status
        response = await self._http.get(SERVICE, f"{self._base}/agents", params=params)
        data = response.json()
        return data.get("agents", data) if isinstance(data, dict) else data

    async def get(self, agent_id: str) -> dict:
        """Get full agent details."""
        response = await self._http.get(SERVICE, f"{self._base}/agents/{agent_id}")
        return response.json()

    async def discover_capabilities(
        self,
        agent_id: str,
        filter_tool: str = "",
        filter_mcp_server: str = "",
    ) -> dict:
        """Discover an agent's capabilities, MCP servers, and tools.

        Args:
            agent_id: Agent UUID.
            filter_tool: Optional — return only tools whose name contains this substring.
            filter_mcp_server: Optional — return only the named MCP server's tools.

        Returns:
            Dict with ``capabilities``, ``mcp_servers``, and ``tools`` lists.
        """
        response = await self._http.get(
            SERVICE, f"{self._base}/agents/{agent_id}/capabilities"
        )
        data = response.json()

        # Client-side filtering for convenience
        if filter_mcp_server and isinstance(data, dict):
            servers = data.get("mcp_servers", [])
            data["mcp_servers"] = [
                s for s in servers
                if isinstance(s, dict) and filter_mcp_server.lower() in s.get("name", "").lower()
            ]
        if filter_tool and isinstance(data, dict):
            tools = data.get("tools", [])
            data["tools"] = [
                t for t in tools
                if isinstance(t, dict) and filter_tool.lower() in t.get("name", "").lower()
            ]

        return data

    # ── Jobs ──────────────────────────────────────────────────────

    async def list_jobs(self, status: str = "", page: int = 1, page_size: int = 20) -> dict:
        """List jobs for the current tenant.

        Args:
            status: Optional status filter — 'pending', 'running', 'completed', 'failed', etc.
            page: Page number (default 1).
            page_size: Items per page (default 20, max 100).
        """
        t = self._http.tenant
        params: dict = {
            "organisation_id": t.org_id,
            "project_id": t.project_id,
            "app_id": t.app_id,
            "page": page,
            "page_size": page_size,
        }
        if status:
            params["status"] = status
        response = await self._http.get(SERVICE, f"{self._base}/jobs", params=params)
        return response.json()

    async def get_job(self, job_id: str) -> dict:
        """Get a specific job by ID."""
        response = await self._http.get(SERVICE, f"{self._base}/jobs/{job_id}")
        return response.json()

    async def approve_job(self, job_id: str) -> dict:
        """Approve a job that is pending approval."""
        response = await self._http.post(SERVICE, f"{self._base}/jobs/{job_id}/approve")
        return response.json()

    async def cancel_job(self, job_id: str) -> dict:
        """Cancel a pending or queued job."""
        response = await self._http.post(SERVICE, f"{self._base}/jobs/{job_id}/cancel")
        return response.json()

    # ── Shell Execution ───────────────────────────────────────────

    async def shell(
        self,
        command: str,
        agent_id: str = "",
        purpose: str = "",
        tail_lines: int = 0,
        timeout_seconds: int = _DEFAULT_TIMEOUT,
    ) -> dict:
        """Execute a shell command on an agent via the job system.

        Creates an ``execute`` job targeting ``shell``, polls until completion,
        and returns the result.

        Args:
            command: Shell command to run.
            agent_id: Agent UUID. If empty, auto-discovers the first online agent.
            purpose: Human-readable description of what the command does.
            tail_lines: If > 0, only return the last N lines of output.
            timeout_seconds: Max seconds to wait for completion (default 120).

        Returns:
            Dict with ``output``, ``exit_code``, ``status``, and ``job_id``.
        """
        resolved_agent = agent_id or await self._resolve_agent()

        params: dict = {"command": command}
        if purpose:
            params["purpose"] = purpose
        if tail_lines > 0:
            params["tail_lines"] = tail_lines

        job = await self._create_job(
            operation_type="execute",
            target="shell",
            params=params,
            agent_id=resolved_agent,
            timeout_seconds=timeout_seconds,
        )

        return await self._poll_job(job["id"], timeout_seconds)

    # ── Kubernetes / MCP Deployment ───────────────────────────────

    async def deploy_k8s(
        self,
        tool_name: str,
        arguments: dict | None = None,
        timeout_seconds: int = _DEFAULT_TIMEOUT,
    ) -> dict:
        """Execute a Kubernetes deployment tool via the MCP job system.

        Creates an ``mcp_call`` job targeting ``kubernetes``, waits for completion.

        Args:
            tool_name: MCP tool name (e.g., 'deploy_app', 'build_image', 'scale').
            arguments: Tool-specific arguments dict.
            timeout_seconds: Max seconds to wait for completion (default 120).

        Returns:
            Dict with ``output``, ``status``, and ``job_id``.
        """
        # Resolve an agent that has kubernetes capability
        agents = await self.list(status="online")
        k8s_agent = None
        for agent in agents:
            targets = agent.get("supported_targets", [])
            if "kubernetes" in targets or "mcp" in targets:
                k8s_agent = agent["id"]
                break

        if not k8s_agent:
            raise DevantisError(
                "No online agent with kubernetes/mcp capability found.",
                service=SERVICE,
            )

        params: dict = {
            "mcp_server": "mcp-kubernetes",
            "tool_name": tool_name,
        }
        if arguments:
            params["arguments"] = arguments

        job = await self._create_job(
            operation_type="mcp_call",
            target="mcp",
            params=params,
            agent_id=k8s_agent,
            timeout_seconds=timeout_seconds,
        )

        return await self._poll_job(job["id"], timeout_seconds)

    async def call_mcp_tool(
        self,
        agent_id: str,
        mcp_server: str,
        tool_name: str,
        arguments: dict | None = None,
        timeout_seconds: int = _DEFAULT_TIMEOUT,
    ) -> dict:
        """Call an arbitrary MCP tool on a specific agent.

        Args:
            agent_id: Agent UUID that hosts the MCP server.
            mcp_server: Name of the MCP server (e.g., 'mcp-kubernetes').
            tool_name: Tool name exposed by the MCP server.
            arguments: Tool-specific arguments dict.
            timeout_seconds: Max seconds to wait for completion (default 120).

        Returns:
            Dict with ``output``, ``status``, and ``job_id``.
        """
        params: dict = {
            "mcp_server": mcp_server,
            "tool_name": tool_name,
        }
        if arguments:
            params["arguments"] = arguments

        job = await self._create_job(
            operation_type="mcp_call",
            target="mcp",
            params=params,
            agent_id=agent_id,
            timeout_seconds=timeout_seconds,
        )

        return await self._poll_job(job["id"], timeout_seconds)

    # ── Internal Helpers ──────────────────────────────────────────

    async def _resolve_agent(self) -> str:
        """Find the first online agent for the current tenant."""
        agents = await self.list(status="online")
        if not agents:
            raise DevantisError(
                "No online agents found. Register and start an executor-runner first.",
                service=SERVICE,
            )
        return str(agents[0]["id"])

    async def _create_job(
        self,
        operation_type: str,
        target: str,
        params: dict,
        agent_id: str,
        timeout_seconds: int = _DEFAULT_TIMEOUT,
    ) -> dict:
        """Create a job via the executor service API."""
        t = self._http.tenant
        body: dict = {
            "organisation_id": t.org_id,
            "project_id": t.project_id,
            "app_id": t.app_id,
            "operation_type": operation_type,
            "target": target,
            "params": params,
            "triggered_by": "user",
            "timeout_seconds": timeout_seconds,
            "requires_approval": False,
            "agent_id": agent_id,
        }
        response = await self._http.post(SERVICE, f"{self._base}/jobs", json=body)
        return response.json()

    async def _poll_job(self, job_id: str, timeout_seconds: int) -> dict:
        """Poll a job until it reaches a terminal status or times out.

        Returns a simplified result dict.
        """
        elapsed = 0.0
        while elapsed < timeout_seconds:
            job = await self.get_job(job_id)
            status = job.get("status", "")

            if status in _TERMINAL_STATUSES:
                return {
                    "job_id": job_id,
                    "status": status,
                    "output": job.get("output", ""),
                    "error": job.get("error", ""),
                    "exit_code": job.get("exit_code"),
                    "duration_ms": job.get("duration_ms"),
                }

            await asyncio.sleep(_POLL_INTERVAL)
            elapsed += _POLL_INTERVAL

        # Timed out waiting — return last known state
        return {
            "job_id": job_id,
            "status": "timeout",
            "error": f"Job did not complete within {timeout_seconds}s. Check with get_job('{job_id}').",
            "output": "",
            "exit_code": None,
            "duration_ms": None,
        }
