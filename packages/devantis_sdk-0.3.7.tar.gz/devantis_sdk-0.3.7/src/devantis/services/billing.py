"""Billing service — invoices, credits, plans, quotas, subscriptions, tax, costs."""

from __future__ import annotations

from devantis.client import BaseClient

SERVICE = "licensing-service"


class BillingService:
    """Billing, licensing, and subscription management."""

    def __init__(self, http: BaseClient):
        self._http = http
        self._org_id = http.tenant.org_id
        self._project_id = http.tenant.project_id
        self._billing = f"/api/v1/billing/orgs/{self._org_id}"
        self._credits = f"/api/v1/orgs/{self._org_id}/credits"
        self._entitlements = f"/api/v1/orgs/{self._org_id}"
        self._plans = "/api/v1/plans"

    # ── Plan & Entitlements ──────────────────────────────────────

    async def get_plan(self) -> dict:
        """Get the current subscription plan."""
        r = await self._http.get(SERVICE, f"{self._billing}/subscription")
        return r.json()

    async def list_plans(self) -> dict:
        """List all available plans with pricing, quotas, and features."""
        r = await self._http.get(SERVICE, self._plans)
        return r.json()

    async def get_plan_details(self, plan_name: str) -> dict:
        """Get full details for a specific plan."""
        r = await self._http.get(SERVICE, f"{self._plans}/{plan_name}")
        return r.json()

    async def get_overage_rates(self, plan_name: str) -> dict:
        """Get overage and executor pricing for a plan."""
        r = await self._http.get(SERVICE, f"{self._plans}/{plan_name}/overage")
        return r.json()

    async def get_entitlements(self, project_id: str | None = None) -> dict:
        """Get full entitlement status — plan, quotas, features, dunning."""
        params = {}
        if project_id:
            params["project_id"] = project_id
        r = await self._http.get(SERVICE, f"{self._entitlements}/entitlements", params=params)
        return r.json()

    async def get_usage(self, project_id: str | None = None) -> dict:
        """Get usage summary — all quotas with current/limit values."""
        params = {}
        if project_id:
            params["project_id"] = project_id
        r = await self._http.get(SERVICE, f"{self._entitlements}/usage", params=params)
        return r.json()

    # ── Invoices ─────────────────────────────────────────────────

    async def list_invoices(
        self, limit: int = 20, month: str | None = None,
    ) -> dict:
        """List invoices. Optional month filter (YYYY-MM)."""
        params: dict = {"limit": limit}
        if month:
            params["month"] = month
        r = await self._http.get(SERVICE, f"{self._billing}/invoices", params=params)
        return r.json()

    async def get_invoice(self, invoice_id: str) -> dict:
        """Get invoice detail with line items."""
        r = await self._http.get(SERVICE, f"{self._billing}/invoices/{invoice_id}")
        return r.json()

    async def get_upcoming_invoice(self) -> dict:
        """Preview the next upcoming invoice."""
        r = await self._http.get(SERVICE, f"{self._billing}/invoices/upcoming")
        return r.json()

    async def retry_invoice(self, invoice_id: str) -> dict:
        """Retry a failed invoice payment."""
        r = await self._http.post(SERVICE, f"{self._billing}/invoices/{invoice_id}/retry")
        return r.json()

    # ── Credits ──────────────────────────────────────────────────

    async def get_credits(self, project_id: str | None = None) -> dict:
        """Get credit balance."""
        params = {}
        if project_id:
            params["project_id"] = project_id
        r = await self._http.get(SERVICE, self._credits, params=params)
        return r.json()

    async def allocate_credits(self, amount_usd: float, description: str = "") -> dict:
        """Allocate credits manually (admin only)."""
        r = await self._http.post(
            SERVICE, f"{self._credits}/allocate",
            json={"amount_usd": amount_usd, "description": description},
        )
        return r.json()

    async def list_transactions(
        self, limit: int = 50, page: int = 1,
    ) -> dict:
        """List credit transactions."""
        params: dict = {"limit": limit, "page": page}
        r = await self._http.get(SERVICE, f"{self._credits}/transactions", params=params)
        return r.json()

    async def purchase_credits(
        self, pack: str, success_url: str = "", cancel_url: str = "",
    ) -> dict:
        """Create a Stripe checkout session for credit purchase.

        Args:
            pack: Pack name — small ($10), medium ($25), large ($50),
                  or custom_<amount> (e.g. custom_100).
            success_url: Redirect URL after payment.
            cancel_url: Redirect URL on cancel.

        Returns:
            {checkout_url, session_id}
        """
        body: dict = {"pack_name": pack}
        if success_url:
            body["success_url"] = success_url
        if cancel_url:
            body["cancel_url"] = cancel_url
        r = await self._http.post(SERVICE, f"{self._billing}/credits/purchase", json=body)
        return r.json()

    async def confirm_credit_purchase(self, session_id: str) -> dict:
        """Confirm a credit purchase (fallback for webhook)."""
        r = await self._http.post(
            SERVICE, f"{self._billing}/credits/purchase/confirm",
            json={"session_id": session_id},
        )
        return r.json()

    async def list_credit_packs(self) -> dict:
        """List available credit packs with prices."""
        r = await self._http.get(SERVICE, f"{self._billing}/credits/packs")
        return r.json()

    # ── Subscription Management ──────────────────────────────────

    async def create_subscription(
        self, plan_name: str, billing_cycle: str = "monthly",
        success_url: str = "", cancel_url: str = "",
    ) -> dict:
        """Create a new subscription via Stripe Checkout.

        Returns:
            {checkout_url, session_id}
        """
        body: dict = {"plan_name": plan_name, "billing_cycle": billing_cycle}
        if success_url:
            body["success_url"] = success_url
        if cancel_url:
            body["cancel_url"] = cancel_url
        r = await self._http.post(SERVICE, f"{self._billing}/subscription", json=body)
        return r.json()

    async def change_plan(self, new_price_id: str, is_upgrade: bool = True) -> dict:
        """Upgrade or downgrade to a different plan."""
        r = await self._http.patch(
            SERVICE, f"{self._billing}/subscription",
            json={"new_price_id": new_price_id, "is_upgrade": is_upgrade},
        )
        return r.json()

    async def cancel_subscription(self, at_period_end: bool = True) -> dict:
        """Cancel the subscription."""
        r = await self._http.delete(
            SERVICE, f"{self._billing}/subscription",
            params={"at_period_end": str(at_period_end).lower()},
        )
        return r.json()

    async def reactivate_subscription(self) -> dict:
        """Reactivate a subscription that was cancelled but hasn't expired."""
        r = await self._http.post(SERVICE, f"{self._billing}/subscription/reactivate")
        return r.json()

    # ── Payment Methods ──────────────────────────────────────────

    async def list_payment_methods(self) -> list:
        """List saved payment methods."""
        r = await self._http.get(SERVICE, f"{self._billing}/payment-methods")
        return r.json()

    async def remove_payment_method(self, pm_id: str) -> dict:
        """Remove a payment method."""
        r = await self._http.delete(SERVICE, f"{self._billing}/payment-methods/{pm_id}")
        return r.json()

    async def set_default_payment_method(self, pm_id: str) -> dict:
        """Set a payment method as default."""
        r = await self._http.put(SERVICE, f"{self._billing}/payment-methods/{pm_id}/default")
        return r.json()

    # ── Tax & Billing Details ────────────────────────────────────

    async def get_tax_summary(self) -> dict:
        """Get tax configuration summary."""
        r = await self._http.get(SERVICE, f"{self._billing}/tax/summary")
        return r.json()

    async def list_tax_ids(self) -> list:
        """List tax IDs on the billing customer."""
        r = await self._http.get(SERVICE, f"{self._billing}/tax/ids")
        return r.json()

    async def add_tax_id(self, tax_type: str, value: str) -> dict:
        """Add a tax ID (e.g. eu_vat, gb_vat, us_ein)."""
        r = await self._http.post(
            SERVICE, f"{self._billing}/tax/ids",
            json={"tax_type": tax_type, "value": value},
        )
        return r.json()

    async def remove_tax_id(self, tax_id: str) -> dict:
        """Remove a tax ID."""
        r = await self._http.delete(SERVICE, f"{self._billing}/tax/ids/{tax_id}")
        return r.json()

    async def get_tax_types(self) -> dict:
        """List supported tax ID types by country."""
        r = await self._http.get(SERVICE, f"{self._billing}/tax/tax-types")
        return r.json()

    async def update_billing_details(self, **kwargs) -> dict:
        """Update billing address and tax settings."""
        r = await self._http.put(SERVICE, f"{self._billing}/tax/billing", json=kwargs)
        return r.json()

    # ── Cost Breakdown ───────────────────────────────────────────

    async def get_seat_cost(self) -> dict:
        """Get seat billing summary."""
        r = await self._http.get(SERVICE, f"{self._entitlements}/seats/cost")
        return r.json()

    async def get_executor_cost(self) -> dict:
        """Get executor usage cost summary."""
        r = await self._http.get(SERVICE, f"{self._entitlements}/executor/cost")
        return r.json()

    async def get_k8s_cost(self) -> dict:
        """Get Kubernetes resource cost summary."""
        r = await self._http.get(SERVICE, f"{self._entitlements}/k8s/cost")
        return r.json()

    async def get_registry_cost(self) -> dict:
        """Get container registry storage cost."""
        r = await self._http.get(SERVICE, f"{self._entitlements}/registry/cost")
        return r.json()

    # ── Receipts ─────────────────────────────────────────────────

    async def get_receipt_url(self, session_id: str) -> str:
        """Get the URL for downloading a receipt PDF."""
        base = self._http.service_url(SERVICE)
        return f"{base}{self._billing}/receipts/{session_id}/pdf"
