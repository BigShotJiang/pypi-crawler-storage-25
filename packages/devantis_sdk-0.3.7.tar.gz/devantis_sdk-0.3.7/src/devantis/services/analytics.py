"""Analytics service — token usage, cost forecasting, and alerts."""

from __future__ import annotations

from devantis.client import BaseClient

SERVICE = "chat-service"


class AnalyticsService:
    """Token usage analytics, cost forecasts, and alerts."""

    def __init__(self, http: BaseClient):
        self._http = http
        t = http.tenant
        self._org_id = t.org_id
        self._project_id = t.project_id
        self._app_id = t.app_id
        self._base = "/api/v1/token-usage"

    def _query_params(self) -> dict:
        """Common tenant query params for token-usage endpoints."""
        return {
            "org_id": self._org_id,
            "project_id": self._project_id,
            "app_id": self._app_id,
        }

    async def token_usage(
        self,
        view: str = "summary",
        period: str | None = None,
        session_id: str | None = None,
    ) -> dict:
        """Query token usage data.

        Args:
            view: One of "summary", "history", "by_model", "by_workflow",
                  "by_session", "session_detail".
            period: Optional time period filter (e.g. "7d", "30d").
            session_id: Required when view is "session_detail".
        """
        view_map = {
            "summary": "/summary",
            "history": "/history",
            "by_model": "/by-model",
            "by_workflow": "/by-workflow",
            "by_session": "/by-session",
            "session_detail": f"/session/{session_id}" if session_id else "/summary",
        }
        endpoint = view_map.get(view, "/summary")
        params = self._query_params()
        if period:
            params["period"] = period
        response = await self._http.get(SERVICE, f"{self._base}{endpoint}", params=params)
        return response.json()

    async def cost_forecast(self) -> dict:
        """Get cost forecast for the current app."""
        params = self._query_params()
        response = await self._http.get(
            SERVICE, f"{self._base}/forecast", params=params
        )
        return response.json()

    async def alerts(self) -> dict:
        """List cost alerts for the current app."""
        params = self._query_params()
        response = await self._http.get(
            SERVICE, f"{self._base}/alerts", params=params
        )
        return response.json()

    async def acknowledge_alert(self, alert_id: str) -> dict:
        """Acknowledge a cost alert."""
        params = self._query_params()
        response = await self._http.post(
            SERVICE, f"{self._base}/alerts/{alert_id}/acknowledge", params=params
        )
        return response.json()
