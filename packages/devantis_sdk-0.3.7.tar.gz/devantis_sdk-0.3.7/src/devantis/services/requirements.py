"""Requirement service — list, get, create, update, delete, search."""

from __future__ import annotations

from devantis.client import BaseClient

SERVICE = "requirement-service"


class RequirementService:
    """Requirement operations."""

    def __init__(self, http: BaseClient):
        self._http = http
        t = http.tenant
        self._base = f"/api/v1/organisations/{t.org_id}/projects/{t.project_id}/apps/{t.app_id}"

    async def list(
        self,
        status: str = "",
        feature: str = "",
        priority: str = "",
        page: int = 1,
        page_size: int = 30,
    ) -> dict:
        """List requirements with optional filters."""
        params = {"page": page, "page_size": page_size}
        if status: params["status"] = status
        if feature: params["feature"] = feature
        if priority: params["priority"] = priority
        response = await self._http.get(SERVICE, f"{self._base}/requirements", params=params)
        return response.json()

    async def get(self, requirement_id: str) -> dict:
        """Get full requirement details."""
        response = await self._http.get(SERVICE, f"{self._base}/requirements/{requirement_id}")
        return response.json()

    async def create(self, **kwargs) -> dict:
        """Create a requirement. Required: title, description, feature."""
        response = await self._http.post(SERVICE, f"{self._base}/requirements", json=kwargs)
        return response.json()

    async def update(self, requirement_id: str, **kwargs) -> dict:
        """Update a requirement."""
        response = await self._http.patch(
            SERVICE, f"{self._base}/requirements/{requirement_id}", json=kwargs
        )
        return response.json()

    async def delete(self, requirement_id: str) -> None:
        """Delete a requirement."""
        await self._http.delete(SERVICE, f"{self._base}/requirements/{requirement_id}")

    async def search(self, query: str, feature: str = "", max_results: int = 50) -> list[dict]:
        """Full-text search across requirements."""
        params = {"q": query, "max_results": max_results}
        if feature: params["feature"] = feature
        response = await self._http.get(SERVICE, f"{self._base}/requirements/search", params=params)
        return response.json()

    async def list_features(self) -> list[str]:
        """List all feature categories."""
        response = await self._http.get(SERVICE, f"{self._base}/requirements/features")
        return response.json()

    async def get_stats(self) -> dict:
        """Get requirement statistics."""
        response = await self._http.get(SERVICE, f"{self._base}/requirements/stats")
        return response.json()
