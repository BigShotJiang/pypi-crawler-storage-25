"""Project service — organisations, projects, apps, members, config, feature flags, cost limits."""

from __future__ import annotations

from devantis.client import BaseClient

PROJECT_SERVICE = "project-service"
ORG_SERVICE = "organisation-service"


class ProjectService:
    """Organisation, project, and app management."""

    def __init__(self, http: BaseClient):
        self._http = http
        t = http.tenant
        self._org_id = t.org_id
        self._project_id = t.project_id
        self._app_id = t.app_id

    # ── Organisations ────────────────────────────────────────────────────

    async def list_organisations(self) -> list[dict]:
        """List all organisations the current user belongs to."""
        response = await self._http.get(PROJECT_SERVICE, "/api/v1/organisations")
        return response.json()

    # ── Projects ─────────────────────────────────────────────────────────

    async def list_projects(self, org_id: str | None = None) -> list[dict]:
        """List projects in an organisation."""
        oid = org_id or self._org_id
        response = await self._http.get(
            PROJECT_SERVICE, f"/api/v1/organisations/{oid}/projects"
        )
        return response.json()

    # ── Apps ─────────────────────────────────────────────────────────────

    async def list_apps(
        self, org_id: str | None = None, project_id: str | None = None
    ) -> list[dict]:
        """List apps in a project."""
        oid = org_id or self._org_id
        pid = project_id or self._project_id
        response = await self._http.get(
            PROJECT_SERVICE,
            f"/api/v1/organisations/{oid}/projects/{pid}/apps",
        )
        return response.json()

    # ── Members ──────────────────────────────────────────────────────────

    def _members_path(self, level: str) -> tuple[str, str]:
        """Return (service, path) for member endpoints at the given level."""
        if level == "organisation":
            return (
                ORG_SERVICE,
                f"/api/v1/organisations/{self._org_id}/members",
            )
        if level == "project":
            return (
                PROJECT_SERVICE,
                f"/api/v1/organisations/{self._org_id}/projects/{self._project_id}/members",
            )
        # Default: app level
        return (
            PROJECT_SERVICE,
            f"/api/v1/organisations/{self._org_id}/projects/{self._project_id}"
            f"/apps/{self._app_id}/members",
        )

    async def list_members(self, level: str = "app") -> dict:
        """List members at the given level (organisation, project, or app)."""
        service, path = self._members_path(level)
        response = await self._http.get(service, path)
        return response.json()

    async def add_member(self, level: str, username: str, role: str) -> dict:
        """Add a member at the given level."""
        service, path = self._members_path(level)
        response = await self._http.post(
            service, path, json={"username": username, "role": role}
        )
        return response.json()

    async def update_member(self, level: str, username: str, role: str) -> dict:
        """Update a member's role at the given level."""
        service, path = self._members_path(level)
        response = await self._http.patch(
            service, f"{path}/{username}", json={"role": role}
        )
        return response.json()

    async def remove_member(self, level: str, username: str) -> None:
        """Remove a member at the given level."""
        service, path = self._members_path(level)
        await self._http.delete(service, f"{path}/{username}")

    # ── Configurations ───────────────────────────────────────────────────

    async def get_config(self, section: str = "all") -> dict:
        """Get app-level configurations.

        Args:
            section: "llm", "flags", "cost_limits", or "all" (default).
                     "all" fetches configurations + feature flags + cost limits.
        """
        base = (
            f"/api/v1/organisations/{self._org_id}/projects/{self._project_id}"
            f"/apps/{self._app_id}"
        )
        if section == "flags":
            response = await self._http.get(
                PROJECT_SERVICE, f"{base}/feature-flags"
            )
            return response.json()
        if section == "cost_limits":
            response = await self._http.get(
                PROJECT_SERVICE, f"{base}/cost-limit"
            )
            return response.json()
        if section == "llm":
            response = await self._http.get(
                PROJECT_SERVICE, f"{base}/configurations"
            )
            return response.json()
        # "all" — fetch configs, flags, and cost limits in parallel
        # (sequential here for simplicity; callers can parallelise externally)
        configs = await self.get_config("llm")
        flags = await self.get_config("flags")
        cost = await self.get_config("cost_limits")
        return {"configurations": configs, "feature_flags": flags, "cost_limits": cost}

    async def update_config(self, key: str, value: str) -> dict:
        """Update an app-level configuration value."""
        base = (
            f"/api/v1/organisations/{self._org_id}/projects/{self._project_id}"
            f"/apps/{self._app_id}/configurations"
        )
        response = await self._http.put(
            PROJECT_SERVICE, base, json={"key": key, "value": value}
        )
        return response.json()

    # ── Feature Flags ────────────────────────────────────────────────────

    async def list_feature_flags(self) -> list[dict]:
        """List app-level feature flags."""
        base = (
            f"/api/v1/organisations/{self._org_id}/projects/{self._project_id}"
            f"/apps/{self._app_id}/feature-flags"
        )
        response = await self._http.get(PROJECT_SERVICE, base)
        return response.json()

    async def set_feature_flag(self, flag_id_or_name: str, enabled: bool) -> dict:
        """Enable or disable a feature flag."""
        base = (
            f"/api/v1/organisations/{self._org_id}/projects/{self._project_id}"
            f"/apps/{self._app_id}/feature-flags/{flag_id_or_name}"
        )
        response = await self._http.patch(
            PROJECT_SERVICE, base, json={"enabled": enabled}
        )
        return response.json()

    # ── Cost Limits ──────────────────────────────────────────────────────

    async def get_cost_limits(self) -> dict:
        """Get app-level cost limits."""
        base = (
            f"/api/v1/organisations/{self._org_id}/projects/{self._project_id}"
            f"/apps/{self._app_id}/cost-limit"
        )
        response = await self._http.get(PROJECT_SERVICE, base)
        return response.json()

    async def set_cost_limits(
        self,
        monthly_limit: float,
        alert_threshold: int,
        enabled: bool = True,
    ) -> dict:
        """Set app-level cost limits."""
        base = (
            f"/api/v1/organisations/{self._org_id}/projects/{self._project_id}"
            f"/apps/{self._app_id}/cost-limit"
        )
        response = await self._http.put(
            PROJECT_SERVICE,
            base,
            json={
                "enabled": enabled,
                "monthly_limit": monthly_limit,
                "alert_threshold": alert_threshold,
            },
        )
        return response.json()
