"""Designs service — list, get, create, update, delete, search, folders, move, copy, rename, replace, styles."""

from __future__ import annotations

from devantis.client import BaseClient

SERVICE = "designs-service"


class DesignService:
    """Design document operations (HTML mockups, tokens, CSS, etc.)."""

    def __init__(self, http: BaseClient):
        self._http = http
        t = http.tenant
        self._base = f"/api/v1/org/{t.org_id}/project/{t.project_id}/app/{t.app_id}/designs"

    # -- Read Operations -------------------------------------------------------

    async def list(self, folder: str = "", file_type: str = "") -> list[dict]:
        """List design files, optionally filtered by folder and/or file type.

        Args:
            folder: Optional folder path to filter by.
            file_type: Optional file type filter — 'html', 'tokens', 'document',
                       'diagram', 'css', 'javascript', 'json', 'yaml', 'text'.
        """
        params = {}
        if folder:
            params["folder"] = folder
        if file_type:
            params["file_type"] = file_type
        response = await self._http.get(SERVICE, self._base, params=params)
        data = response.json()
        return data.get("items", data) if isinstance(data, dict) else data

    async def get(self, design_id: str) -> dict:
        """Get full design document content."""
        response = await self._http.get(SERVICE, f"{self._base}/{design_id}")
        return response.json()

    async def search(self, query: str, file_type: str = "") -> list[dict]:
        """Search design documents by name or content.

        Args:
            query: Search query string.
            file_type: Optional file type filter.
        """
        params: dict = {"q": query}
        if file_type:
            params["file_type"] = file_type
        response = await self._http.get(
            SERVICE, f"{self._base}/search", params=params
        )
        data = response.json()
        return data.get("results", data) if isinstance(data, dict) else data

    async def list_folders(self) -> list[dict]:
        """List all folders containing design documents."""
        response = await self._http.get(SERVICE, f"{self._base}/folders")
        data = response.json()
        return data.get("folders", data) if isinstance(data, dict) else data

    async def get_styles(self, design_id: str) -> dict:
        """Get a summary of Tailwind CSS classes used in a design.

        Returns categorized lists of colors, spacing, typography, borders, and effects.
        More efficient than reading full content for style analysis.
        """
        response = await self._http.get(
            SERVICE, f"{self._base}/{design_id}/styles"
        )
        return response.json()

    # -- Write Operations ------------------------------------------------------

    async def create(
        self,
        id: str,
        content: str,
        file_type: str = "html",
        folder: str = "",
    ) -> dict:
        """Create a new design document.

        Args:
            id: Document identifier (filename without extension).
            content: Document content (HTML, CSS, JSON, etc.).
            file_type: Type — 'html', 'tokens', 'document', 'diagram', 'css',
                       'javascript', 'json', 'yaml', 'text'.
            folder: Optional folder path.
        """
        body: dict = {"id": id, "content": content, "file_type": file_type}
        if folder:
            body["folder"] = folder
        response = await self._http.post(SERVICE, self._base, json=body)
        return response.json()

    async def update(self, design_id: str, content: str) -> dict:
        """Update an existing design document's content."""
        response = await self._http.put(
            SERVICE, f"{self._base}/{design_id}",
            json={"content": content},
        )
        return response.json()

    async def delete(self, design_id: str) -> None:
        """Delete a design document."""
        await self._http.delete(SERVICE, f"{self._base}/{design_id}")

    async def replace(
        self, design_id: str, replacements: list[dict[str, str]]
    ) -> dict:
        """Replace text in a design file. Efficient for bulk style changes.

        Args:
            design_id: Document identifier (with or without extension).
            replacements: List of ``{"find": "old text", "replace": "new text"}`` pairs.

        Returns:
            Dict with ``id``, ``path``, ``replacements_made``, and ``details``.
        """
        response = await self._http.patch(
            SERVICE, f"{self._base}/{design_id}/replace",
            json={"replacements": replacements},
        )
        return response.json()

    # -- Organise Operations ---------------------------------------------------

    async def move(self, design_id: str, folder: str) -> dict:
        """Move a design document to a different folder."""
        response = await self._http.post(
            SERVICE, f"{self._base}/{design_id}/move",
            json={"folder": folder},
        )
        return response.json()

    async def copy(self, design_id: str, new_id: str, folder: str = "") -> dict:
        """Copy a design document, optionally into a different folder.

        Args:
            design_id: Source document ID.
            new_id: ID for the new copy.
            folder: Target folder (defaults to same folder as source).
        """
        body: dict = {"new_id": new_id}
        if folder:
            body["folder"] = folder
        response = await self._http.post(
            SERVICE, f"{self._base}/{design_id}/copy",
            json=body,
        )
        return response.json()

    async def rename(self, design_id: str, new_id: str) -> dict:
        """Rename a design document.

        Args:
            design_id: Current document ID.
            new_id: New document ID.
        """
        response = await self._http.post(
            SERVICE, f"{self._base}/{design_id}/rename",
            json={"new_id": new_id},
        )
        return response.json()
