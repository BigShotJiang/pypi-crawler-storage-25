"""Knowledge Graph service — entities, observations, relations, search, brain operations."""

from __future__ import annotations

from devantis.client import BaseClient

SERVICE = "knowledge-graph-service"


class KnowledgeGraphService:
    """Knowledge graph (AI Brain) operations."""

    def __init__(self, http: BaseClient):
        self._http = http
        t = http.tenant
        self._base = (
            f"/api/v1/org/{t.org_id}/project/{t.project_id}"
            f"/app/{t.app_id}/knowledge"
        )
        self._graph = (
            f"/api/v1/org/{t.org_id}/project/{t.project_id}"
            f"/app/{t.app_id}/knowledge/graph"
        )

    # ── Entities ──────────────────────────────────────────────

    async def list_entities(
        self,
        entity_type: str = "",
        page: int = 1,
        page_size: int = 50,
    ) -> list[dict]:
        """List knowledge graph entities."""
        params: dict = {"page": page, "page_size": page_size}
        if entity_type:
            params["entity_type"] = entity_type
        resp = await self._http.get(SERVICE, f"{self._base}/entities", params=params)
        return resp.json()

    async def get_entity(self, name: str) -> dict:
        """Get entity with its observations."""
        resp = await self._http.get(SERVICE, f"{self._base}/entities/{name}")
        return resp.json()

    async def create_entity(
        self,
        name: str,
        entity_type: str,
        observations: list[dict] | None = None,
    ) -> dict:
        """Create or upsert an entity."""
        body: dict = {"name": name, "entity_type": entity_type}
        if observations:
            body["observations"] = observations
        resp = await self._http.post(SERVICE, f"{self._base}/entities", json=body)
        return resp.json()

    async def delete_entity(self, name: str) -> None:
        """Delete an entity (cascades observations and relations)."""
        await self._http.delete(SERVICE, f"{self._base}/entities/{name}")

    # ── Observations ──────────────────────────────────────────

    async def add_observation(
        self,
        entity_name: str,
        content: str,
        kind: str = "fact",
    ) -> dict:
        """Add an observation to an entity. kind: fact, correction, gotcha, cached, media."""
        resp = await self._http.post(
            SERVICE,
            f"{self._base}/entities/{entity_name}/observations",
            json={"content": content, "kind": kind},
        )
        return resp.json()

    async def delete_observation(self, entity_name: str, observation_id: str) -> None:
        """Remove an observation."""
        await self._http.delete(
            SERVICE,
            f"{self._base}/entities/{entity_name}/observations/{observation_id}",
        )

    async def confirm_observation(self, entity_name: str, observation_id: str) -> dict:
        """Bump confirmed_at on an observation (mark as still valid)."""
        resp = await self._http.post(
            SERVICE,
            f"{self._base}/entities/{entity_name}/observations/{observation_id}/confirm",
        )
        return resp.json()

    # ── Relations ─────────────────────────────────────────────

    async def list_relations(
        self,
        from_entity: str = "",
        to_entity: str = "",
        relation_type: str = "",
    ) -> list[dict]:
        """List relations, optionally filtered."""
        params: dict = {}
        if from_entity:
            params["from_entity"] = from_entity
        if to_entity:
            params["to_entity"] = to_entity
        if relation_type:
            params["relation_type"] = relation_type
        resp = await self._http.get(SERVICE, f"{self._base}/relations", params=params)
        return resp.json()

    async def create_relation(
        self,
        from_entity: str,
        to_entity: str,
        relation_type: str,
    ) -> dict:
        """Create a typed relation between entities."""
        resp = await self._http.post(
            SERVICE,
            f"{self._base}/relations",
            json={
                "from_entity": from_entity,
                "to_entity": to_entity,
                "relation_type": relation_type,
            },
        )
        return resp.json()

    async def delete_relation(self, relation_id: str) -> None:
        """Delete a relation."""
        await self._http.delete(SERVICE, f"{self._base}/relations/{relation_id}")

    # ── Search & Traversal ────────────────────────────────────

    async def search(
        self,
        query: str,
        entity_type: str = "",
    ) -> list[dict]:
        """Full-text search across entities and observations."""
        params: dict = {"q": query}
        if entity_type:
            params["entity_type"] = entity_type
        resp = await self._http.get(SERVICE, f"{self._base}/search", params=params)
        return resp.json()

    async def dependencies(
        self,
        entity_name: str,
        direction: str = "outgoing",
    ) -> list[dict]:
        """Recursive dependency traversal."""
        params = {"direction": direction}
        resp = await self._http.get(
            SERVICE,
            f"{self._base}/dependencies/{entity_name}",
            params=params,
        )
        return resp.json()

    async def impact(self, entity_name: str) -> list[dict]:
        """Reverse dependency (impact) analysis."""
        resp = await self._http.get(
            SERVICE, f"{self._base}/impact/{entity_name}"
        )
        return resp.json()

    # ── Graph Operations ──────────────────────────────────────

    async def stats(self) -> dict:
        """Graph statistics: counts, type distribution."""
        resp = await self._http.get(SERVICE, f"{self._graph}/stats")
        return resp.json()

    async def export_graph(self) -> dict:
        """Full graph export."""
        resp = await self._http.get(SERVICE, self._graph)
        return resp.json()

    async def import_graph(self, data: dict) -> dict:
        """Import (upsert) a graph."""
        resp = await self._http.post(SERVICE, f"{self._graph}/import", json=data)
        return resp.json()

    async def bulk_add(self, entities: list[dict], relations: list[dict] | None = None) -> dict:
        """Bulk add entities + relations."""
        body: dict = {"entities": entities}
        if relations:
            body["relations"] = relations
        resp = await self._http.post(SERVICE, f"{self._graph}/bulk", json=body)
        return resp.json()

    # ── Brain Intelligence ────────────────────────────────────

    async def vitals(self) -> dict:
        """Brain vital signs: intelligence score, quality, growth."""
        resp = await self._http.get(SERVICE, f"{self._graph}/vitals")
        return resp.json()

    async def reason(self, question: str, max_tokens: int = 4096) -> dict:
        """LLM reasoning over brain knowledge."""
        params = {"question": question, "max_tokens": max_tokens}
        resp = await self._http.post(SERVICE, f"{self._graph}/reason", params=params)
        return resp.json()

    async def consolidate(self, dry_run: bool = True) -> dict:
        """Run 3-phase brain consolidation: cleanup, organize, enrich."""
        resp = await self._http.post(
            SERVICE, f"{self._graph}/consolidate", json={"dry_run": dry_run}
        )
        return resp.json()

    async def cleanup(self, dry_run: bool = True) -> dict:
        """Run brain cleanup (remove stale/duplicate entities)."""
        resp = await self._http.post(
            SERVICE, f"{self._graph}/cleanup", json={"dry_run": dry_run}
        )
        return resp.json()

    async def stale_entities(self, days: int = 30) -> list[dict]:
        """Find entities not confirmed in N days."""
        resp = await self._http.get(
            SERVICE, f"{self._graph}/stale", params={"days": days}
        )
        return resp.json()

    async def history(self, period: str = "day") -> dict:
        """Time-series of entity/observation/relation growth."""
        resp = await self._http.get(
            SERVICE, f"{self._graph}/history", params={"period": period}
        )
        return resp.json()

    # ── Media ─────────────────────────────────────────────────

    async def list_media(self) -> list[dict]:
        """List stored media files."""
        resp = await self._http.get(SERVICE, f"{self._base}/media")
        return resp.json()

    async def get_media(self, filename: str, as_base64: bool = False) -> dict:
        """Get a media file."""
        suffix = "/base64" if as_base64 else ""
        resp = await self._http.get(SERVICE, f"{self._base}/media/{filename}{suffix}")
        return resp.json()

    async def delete_media(self, filename: str) -> None:
        """Delete a media file."""
        await self._http.delete(SERVICE, f"{self._base}/media/{filename}")
