"""Memory service — persistent project memory (key-value preferences)."""

from __future__ import annotations

from devantis.client import BaseClient

SERVICE = "chat-service"


class MemoryService:
    """Project memory — persistent preferences and decisions."""

    def __init__(self, http: BaseClient):
        self._http = http
        t = http.tenant
        self._base = f"/api/v1/org/{t.org_id}/project/{t.project_id}/app/{t.app_id}/memory"

    async def list(self) -> dict[str, str]:
        """Get all memory entries as key-value pairs."""
        response = await self._http.get(SERVICE, self._base)
        data = response.json()
        memories = data.get("memories", [])
        return {m["key"]: m["content"] for m in memories if "key" in m}

    async def set(self, key: str, content: str) -> dict:
        """Set a memory entry (upsert)."""
        response = await self._http.post(
            SERVICE, self._base,
            json={"key": key, "content": content, "source": "sdk"},
        )
        return response.json()

    async def delete(self, key: str) -> dict:
        """Delete a memory entry."""
        response = await self._http.delete(SERVICE, f"{self._base}/{key}")
        return response.json()
