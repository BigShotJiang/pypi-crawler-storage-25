"""Chat service — send messages, answer questions, manage sessions, view history.

Full interactive support: send messages, handle waiting_for_input prompts,
answer questions from paused workflows, confirm/reject proposals.
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid

from devantis.client import BaseClient

SERVICE = "chat-service"

logger = logging.getLogger(__name__)


class ChatService:
    """Chat operations — WebSocket messaging and REST session management.

    Supports full interactive flows:
    - send(): Send a message, collect response (handles streaming + pauses)
    - answer(): Respond to a paused workflow's question
    - confirm(): Confirm or reject a proposal
    - sessions/history/stop/delete: Session management
    """

    def __init__(self, http: BaseClient):
        self._http = http
        t = http.tenant
        self._org_id = t.org_id
        self._project_id = t.project_id
        self._app_id = t.app_id

    async def send(
        self,
        message: str,
        session_id: str | None = None,
        timeout: float = 300,
    ) -> dict:
        """Send a chat message via WebSocket and collect the full response.

        If the workflow pauses (waiting_for_input), returns with status='waiting_for_input'
        and includes the question/options so the caller can respond with answer().

        Returns:
            dict with keys:
            - session_id: str
            - content: str (accumulated response text)
            - status: 'complete' | 'waiting_for_input' | 'error' | 'timeout'
            - artifacts: list[dict]
            - waiting_for_input: dict | None (question data if paused)
            - job_id: str | None (needed for answer/confirm)
            - token_usage: dict | None
            - raw_messages: list[dict]
        """
        ws = await self._connect_ws(session_id, timeout)
        return await ws.send_and_collect(message, timeout)

    async def answer(
        self,
        session_id: str,
        answer_text: str,
        timeout: float = 300,
    ) -> dict:
        """Answer a paused workflow's question.

        The gateway treats new messages on a paused session as answers
        to the pending waiting_for_input prompt.

        Returns same format as send().
        """
        ws = await self._connect_ws(session_id, timeout)
        return await ws.send_and_collect(answer_text, timeout, is_answer=True)

    async def confirm(
        self,
        session_id: str,
        job_id: str,
        approved: bool,
        data: dict | None = None,
        timeout: float = 300,
    ) -> dict:
        """Confirm or reject a proposal from a paused workflow.

        Returns same format as send().
        """
        ws = await self._connect_ws(session_id, timeout)
        return await ws.confirm_and_collect(job_id, approved, data, timeout)

    async def sessions(self, page_size: int = 20) -> dict:
        """List chat sessions for the current app."""
        params = {
            "org_id": self._org_id,
            "project_id": self._project_id,
            "app_id": self._app_id,
        }
        if page_size:
            params["page_size"] = page_size
        response = await self._http.get(SERVICE, "/sessions", params=params)
        return response.json()

    async def history(self, session_id: str, raw: bool = False) -> dict:
        """Get session history."""
        response = await self._http.get(SERVICE, f"/sessions/{session_id}/history")
        return response.json()

    async def stop(self, session_id: str) -> dict:
        """Cancel a running workflow for a session."""
        response = await self._http.post(SERVICE, f"/sessions/{session_id}/cancel")
        return response.json()

    async def delete(self, session_id: str) -> None:
        """Delete a chat session."""
        await self._http.delete(SERVICE, f"/sessions/{session_id}")

    # ── WebSocket connection factory ──────────────────────────

    async def _connect_ws(self, session_id: str | None, timeout: float) -> _ChatWebSocket:
        """Create and connect a WebSocket wrapper."""
        try:
            import websockets
        except ImportError:
            raise ImportError(
                "The 'websockets' package is required for ChatService. "
                "Install it with: pip install websockets"
            )

        if session_id is None:
            session_id = str(uuid.uuid4())

        # Build WebSocket URL
        if self._http.gateway_mode:
            # Gateway mode: wss://devantis.dev.encodeit.ro/ws/chat
            base_url = self._http._gateway_url
            ws_url = base_url.replace("http://", "ws://").replace("https://", "wss://")
            ws_path = "/ws/chat"
        else:
            # Local/Docker mode: ws://chat-service:8090/ws/chat
            base_url = self._http.service_url(SERVICE)
            ws_url = base_url.replace("http://", "ws://").replace("https://", "wss://")
            ws_path = "/ws/chat"

        # Get auth token
        headers = await self._http.auth.get_headers()
        token = ""
        auth_header = headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
        else:
            token = headers.get("X-Internal-Service-Key", "")

        params = (
            f"?session_id={session_id}"
            f"&org_id={self._org_id}"
            f"&project_id={self._project_id}"
            f"&app_id={self._app_id}"
            f"&token={token}"
        )
        uri = f"{ws_url}{ws_path}{params}"

        return _ChatWebSocket(uri, session_id, websockets)


class _ChatWebSocket:
    """Internal WebSocket wrapper for chat interactions."""

    def __init__(self, uri: str, session_id: str, websockets_mod):
        self._uri = uri
        self._session_id = session_id
        self._ws_mod = websockets_mod

    async def send_and_collect(
        self, message: str, timeout: float, is_answer: bool = False,
    ) -> dict:
        """Connect, send message, collect response until complete or paused."""
        content_chunks: list[str] = []
        artifacts: list[dict] = []
        raw_messages: list[dict] = []
        waiting_for_input = None
        job_id = None
        token_usage = None
        status = "complete"
        skip_first_waiting = False

        async with self._ws_mod.connect(self._uri, max_size=10_000_000) as ws:
            # Wait for connected
            connected_raw = await asyncio.wait_for(ws.recv(), timeout=10)
            connected = json.loads(connected_raw)
            raw_messages.append(connected)

            if "session_id" in connected:
                self._session_id = connected["session_id"]

            # If reconnecting to a paused session, skip the stale waiting_for_input
            has_running = connected.get("data", {}).get("has_running_job", False)
            if has_running and is_answer:
                skip_first_waiting = True

            # Send chat message — gateway unpacks flat into ClientMessage
            await ws.send(json.dumps({
                "type": "chat_message",
                "content": message,
            }))

            # Collect responses
            deadline = asyncio.get_event_loop().time() + timeout
            while True:
                remaining = deadline - asyncio.get_event_loop().time()
                if remaining <= 0:
                    status = "timeout"
                    break

                try:
                    raw = await asyncio.wait_for(ws.recv(), timeout=remaining)
                except asyncio.TimeoutError:
                    status = "timeout"
                    break

                msg = json.loads(raw)
                raw_messages.append(msg)
                msg_type = msg.get("type", "")
                msg_data = msg.get("data", {})

                if msg_type == "stream_chunk":
                    chunk = msg_data.get("content", "")
                    if chunk:
                        content_chunks.append(chunk)

                elif msg_type == "message_start":
                    job_id = msg_data.get("job_id", job_id)

                elif msg_type == "artifact":
                    artifacts.append(msg_data)

                elif msg_type == "token_usage":
                    token_usage = msg_data

                elif msg_type == "waiting_for_input":
                    if skip_first_waiting:
                        skip_first_waiting = False
                        continue
                    waiting_for_input = msg_data
                    job_id = msg_data.get("job_id", job_id)
                    status = "waiting_for_input"
                    break

                elif msg_type == "confirm_request":
                    waiting_for_input = msg_data
                    job_id = msg_data.get("job_id", job_id)
                    status = "waiting_for_input"
                    break

                elif msg_type == "tool_approval_request":
                    waiting_for_input = msg_data
                    job_id = msg_data.get("job_id", job_id)
                    status = "waiting_for_input"
                    break

                elif msg_type == "message_complete":
                    status = "complete"
                    break

                elif msg_type == "error":
                    error_msg = msg_data.get("message", "Unknown error")
                    status = "error"
                    content_chunks.append(f"\n[Error: {error_msg}]")
                    break

        return {
            "session_id": self._session_id,
            "content": "".join(content_chunks),
            "status": status,
            "artifacts": artifacts,
            "waiting_for_input": waiting_for_input,
            "job_id": job_id,
            "token_usage": token_usage,
            "raw_messages": raw_messages,
        }

    async def confirm_and_collect(
        self, job_id: str, approved: bool, data: dict | None, timeout: float,
    ) -> dict:
        """Connect, send confirmation, collect response."""
        content_chunks: list[str] = []
        raw_messages: list[dict] = []
        token_usage = None
        status = "complete"

        async with self._ws_mod.connect(self._uri, max_size=10_000_000) as ws:
            connected_raw = await asyncio.wait_for(ws.recv(), timeout=10)
            connected = json.loads(connected_raw)
            raw_messages.append(connected)

            if "session_id" in connected:
                self._session_id = connected["session_id"]

            # Send confirmation — gateway unpacks flat into ClientMessage
            confirm_msg: dict = {
                "type": "confirm",
                "job_id": job_id,
                "approved": approved,
            }
            if data:
                confirm_msg["data"] = data
            await ws.send(json.dumps(confirm_msg))

            # Collect responses
            deadline = asyncio.get_event_loop().time() + timeout
            while True:
                remaining = deadline - asyncio.get_event_loop().time()
                if remaining <= 0:
                    status = "timeout"
                    break

                try:
                    raw = await asyncio.wait_for(ws.recv(), timeout=remaining)
                except asyncio.TimeoutError:
                    status = "timeout"
                    break

                msg = json.loads(raw)
                raw_messages.append(msg)
                msg_type = msg.get("type", "")
                msg_data = msg.get("data", {})

                if msg_type == "stream_chunk":
                    chunk = msg_data.get("content", "")
                    if chunk:
                        content_chunks.append(chunk)
                elif msg_type == "token_usage":
                    token_usage = msg_data
                elif msg_type == "message_complete":
                    break
                elif msg_type == "error":
                    status = "error"
                    content_chunks.append(f"\n[Error: {msg_data.get('message', '')}]")
                    break

        return {
            "session_id": self._session_id,
            "content": "".join(content_chunks),
            "status": status,
            "artifacts": [],
            "waiting_for_input": None,
            "job_id": job_id,
            "token_usage": token_usage,
            "raw_messages": raw_messages,
        }
