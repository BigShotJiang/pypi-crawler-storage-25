"""Source code service — file read/write/edit/delete, search, grep, glob."""

from __future__ import annotations

import fnmatch
import logging
import re

from devantis.client import BaseClient
from devantis.errors import NotFound

logger = logging.getLogger(__name__)

SERVICE = "sourcecode-service"

# Extensions to skip during grep (binary/non-searchable)
_BINARY_EXTENSIONS = frozenset({
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".svg", ".webp",
    ".mp3", ".mp4", ".avi", ".mov", ".wav", ".flac",
    ".zip", ".tar", ".gz", ".bz2", ".rar", ".7z",
    ".pdf", ".doc", ".docx", ".xls", ".xlsx",
    ".woff", ".woff2", ".ttf", ".eot", ".otf",
    ".pyc", ".pyo", ".class", ".o", ".so", ".dll",
    ".lock", ".min.js", ".min.css",
})


class SourceService:
    """Source code operations — files, grep, glob."""

    def __init__(self, http: BaseClient):
        self._http = http
        self._base = f"/api/v1/org/{http.tenant.org_id}/project/{http.tenant.project_id}/app/{http.tenant.app_id}/sourcecode"

    # ── File Operations ────────────────────────────────────────

    async def read(self, path: str) -> str:
        """Read a file's content. Raises NotFound if file doesn't exist."""
        response = await self._http.get(
            SERVICE, f"{self._base}/file", params={"path": path}
        )
        data = response.json()
        return data.get("content", "") if isinstance(data, dict) else str(data)

    async def write(self, path: str, content: str) -> dict:
        """Create or overwrite a file. Auto-stages for git commit."""
        # Try update first (PUT)
        try:
            response = await self._http.put(
                SERVICE, f"{self._base}/file",
                params={"path": path},
                json={"content": content},
            )
            return {"path": path, "status": "updated"}
        except NotFound:
            pass

        # File doesn't exist — create (POST)
        folder, filename = self._split_path(path)
        file_id, ext = self._split_filename(filename)
        response = await self._http.post(
            SERVICE, self._base,
            json={"id": file_id, "content": content, "folder": folder, "extension": ext},
        )
        return {"path": path, "status": "created"}

    async def edit(self, path: str, old_content: str, new_content: str) -> dict:
        """Edit a file by finding old_content and replacing with new_content.

        Uses fuzzy matching — tolerates whitespace differences.
        Returns the updated section with line numbers on success.
        Returns helpful error context on failure.
        """
        try:
            content = await self.read(path)
        except NotFound:
            return {"success": False, "error": f"File not found: {path}"}

        # Try exact match first
        match_content = self._fuzzy_find(content, old_content)
        if match_content is None:
            # Build helpful error
            preview = self._build_preview(content, old_content)
            return {
                "success": False,
                "error": "old_content not found in file",
                "file_preview": preview,
                "total_lines": content.count("\n") + 1,
                "hint": "The content you're looking for doesn't match. Use read_file to see the exact content.",
            }

        # Replace first occurrence
        new_file_content = content.replace(match_content, new_content, 1)
        await self.write(path, new_file_content)

        # Find the updated section for confirmation
        start_line = new_file_content[:new_file_content.find(new_content)].count("\n")
        updated_lines = new_content.split("\n")
        numbered = "\n".join(
            f"  {start_line + i + 1} | {line}"
            for i, line in enumerate(updated_lines[:10])
        )

        return {
            "success": True,
            "path": path,
            "updated_lines": len(new_file_content.split("\n")),
            "updated_section": numbered,
        }

    async def delete(self, path: str) -> dict:
        """Delete a file."""
        await self._http.delete(
            SERVICE, f"{self._base}/file", params={"path": path}
        )
        return {"path": path, "status": "deleted"}

    async def move(self, source_path: str, destination_path: str) -> dict:
        """Move or rename a file."""
        # Read source
        content = await self.read(source_path)
        # Write to destination
        await self.write(destination_path, content)
        # Delete source
        await self.delete(source_path)
        return {"source": source_path, "destination": destination_path, "status": "moved"}

    # ── List & Search ──────────────────────────────────────────

    async def list(self, folder: str = "") -> list[dict]:
        """List files, optionally filtered by folder."""
        params = {}
        if folder:
            params["folder"] = folder
        response = await self._http.get(SERVICE, self._base, params=params)
        data = response.json()
        items = data.get("items", data) if isinstance(data, dict) else data
        return items if isinstance(items, list) else []

    async def search(self, query: str) -> list[dict]:
        """Search files by name."""
        response = await self._http.get(
            SERVICE, f"{self._base}/search", params={"q": query}
        )
        data = response.json()
        return data.get("results", []) if isinstance(data, dict) else []

    async def glob(self, pattern: str, folder: str = "") -> list[str]:
        """Find files matching a glob pattern (e.g., '*.py', 'src/**/*.ts')."""
        files = await self.list(folder=folder)
        paths = [f.get("path", "") for f in files if isinstance(f, dict)]

        matches = []
        for path in paths:
            if self._glob_match(pattern, path):
                matches.append(path)
        return matches

    async def grep(
        self,
        pattern: str | None = None,
        patterns: list[str] | None = None,
        glob: str | None = None,
        context_lines: int = 2,
        max_results: int = 10,
    ) -> dict:
        """Search inside file contents using regex.

        This is the ONLY way to search code content (not just filenames).
        Reads files and applies regex line-by-line.
        """
        search_patterns = patterns or ([pattern] if pattern else [])
        if not search_patterns:
            return {"error": "pattern or patterns is required"}

        # Get file list
        files = await self.list()
        paths = [f.get("path", "") for f in files if isinstance(f, dict)]

        # Filter by glob
        if glob:
            paths = [p for p in paths if self._glob_match(glob, p)]

        # Filter out binary files
        paths = [p for p in paths if not any(p.endswith(ext) for ext in _BINARY_EXTENSIONS)]

        # Compile regexes
        compiled = {}
        for p in search_patterns:
            try:
                compiled[p] = re.compile(p, re.IGNORECASE)
            except re.error as e:
                return {"error": f"Invalid regex '{p}': {e}"}

        # Search files
        results = {p: {"matches": [], "count": 0} for p in search_patterns}
        files_scanned = 0

        for file_path in paths:
            # Check if all patterns have enough results
            if all(results[p]["count"] >= max_results for p in search_patterns):
                break

            try:
                content = await self.read(file_path)
            except (NotFound, Exception):
                continue

            files_scanned += 1
            lines = content.split("\n")

            for pat_str, regex in compiled.items():
                if results[pat_str]["count"] >= max_results:
                    continue

                for line_num, line in enumerate(lines):
                    if regex.search(line):
                        # Build snippet with context
                        start = max(0, line_num - context_lines)
                        end = min(len(lines), line_num + context_lines + 1)
                        snippet = "\n".join(
                            f"{start + i + 1}: {lines[start + i]}"
                            for i in range(end - start)
                        )
                        results[pat_str]["matches"].append({
                            "file": file_path,
                            "line": line_num + 1,
                            "snippet": snippet,
                        })
                        results[pat_str]["count"] += 1
                        if results[pat_str]["count"] >= max_results:
                            break

        # Format response
        if len(search_patterns) == 1:
            pat = search_patterns[0]
            return {
                "pattern": pat,
                "matches": results[pat]["matches"],
                "count": results[pat]["count"],
                "files_scanned": files_scanned,
            }

        total = sum(r["count"] for r in results.values())
        return {
            "patterns": results,
            "total_matches": total,
            "files_scanned": files_scanned,
        }

    # ── Fuzzy Matching (for edit) ──────────────────────────────

    def _fuzzy_find(self, file_content: str, old_content: str) -> str | None:
        """Find content with fuzzy whitespace matching."""
        old_clean = self._strip_line_numbers(old_content)

        # Level 1: normalized (tabs→spaces, trailing whitespace)
        norm_file = self._normalize(file_content)
        norm_old = self._normalize(old_clean)
        if norm_old in norm_file:
            return self._extract_match(file_content, norm_file, norm_old)

        # Level 2: aggressive leading whitespace
        agg_file = self._normalize_aggressive(file_content)
        agg_old = self._normalize_aggressive(old_clean)
        if agg_old in agg_file:
            return self._extract_match(file_content, agg_file, agg_old)

        return None

    @staticmethod
    def _strip_line_numbers(text: str) -> str:
        lines = text.split("\n")
        result = []
        for line in lines:
            m = re.match(r"^\s*\d+\s*\|\s?(.*)$", line)
            result.append(m.group(1) if m else line)
        return "\n".join(result)

    @staticmethod
    def _normalize(text: str) -> str:
        text = text.replace("\r\n", "\n").replace("\t", "    ")
        return "\n".join(line.rstrip() for line in text.split("\n"))

    @staticmethod
    def _normalize_aggressive(text: str) -> str:
        lines = text.split("\n")
        result = []
        for line in lines:
            stripped = line.lstrip()
            if stripped:
                leading = line[: len(line) - len(stripped)].replace("\t", "    ")
                result.append(leading + stripped.rstrip())
            else:
                result.append("")
        return "\n".join(result)

    @staticmethod
    def _extract_match(original: str, normalized: str, needle: str) -> str:
        idx = normalized.find(needle)
        start_line = normalized[:idx].count("\n")
        end_line = start_line + needle.count("\n")
        lines = original.split("\n")
        return "\n".join(lines[start_line : end_line + 1])

    @staticmethod
    def _build_preview(content: str, search: str, context: int = 5) -> str:
        """Build a preview of the file around the best approximate match."""
        lines = content.split("\n")
        search_first_line = search.strip().split("\n")[0].strip()
        best_line = 0
        best_score = 0
        for i, line in enumerate(lines):
            # Simple similarity: count matching words
            words_file = set(line.lower().split())
            words_search = set(search_first_line.lower().split())
            score = len(words_file & words_search)
            if score > best_score:
                best_score = score
                best_line = i

        start = max(0, best_line - context)
        end = min(len(lines), best_line + context + 1)
        return "\n".join(f"  {start + i + 1} | {lines[start + i]}" for i in range(end - start))

    # ── Path Utilities ─────────────────────────────────────────

    @staticmethod
    def _split_path(path: str) -> tuple[str, str]:
        """Split 'folder/sub/file.py' into ('folder/sub', 'file.py')."""
        if "/" in path:
            last_slash = path.rfind("/")
            return path[:last_slash], path[last_slash + 1 :]
        return "", path

    @staticmethod
    def _split_filename(filename: str) -> tuple[str, str]:
        """Split 'file.py' into ('file', 'py')."""
        if "." in filename:
            last_dot = filename.rfind(".")
            return filename[:last_dot], filename[last_dot + 1 :]
        return filename, ""

    # ── Batch Operations ─────────────────────────────────────

    async def batch_write(self, files: list[dict]) -> dict:
        """Write multiple files at once (max 20). Each item: {path, content}."""
        response = await self._http.post(
            SERVICE, f"{self._base}/files/batch", json={"files": files}
        )
        return response.json()

    async def batch_delete(self, paths: list[str]) -> dict:
        """Delete multiple files at once (max 20)."""
        response = await self._http.delete(
            SERVICE, f"{self._base}/files/batch", json={"paths": paths}
        )
        return response.json()

    async def batch_edit(self, edits: list[dict]) -> dict:
        """Edit multiple files at once (max 20). Each item: {path, old_content, new_content}."""
        response = await self._http.patch(
            SERVICE, f"{self._base}/files/batch", json={"edits": edits}
        )
        return response.json()

    @staticmethod
    def _glob_match(pattern: str, path: str) -> bool:
        """Match a path against a glob pattern supporting **."""
        if "**" not in pattern:
            return fnmatch.fnmatch(path, pattern)
        parts = pattern.split("**")
        regex_parts = []
        for i, part in enumerate(parts):
            if i > 0:
                regex_parts.append(".*")
            escaped = re.escape(part).replace(r"\*", "[^/]*").replace(r"\?", "[^/]")
            regex_parts.append(escaped)
        regex = "^" + "".join(regex_parts) + "$"
        return bool(re.match(regex, path))

