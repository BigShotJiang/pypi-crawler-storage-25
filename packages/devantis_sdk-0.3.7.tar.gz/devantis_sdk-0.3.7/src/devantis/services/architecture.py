"""Architecture service — list, get, create, update, delete, search, folders, move, copy, rename."""

from __future__ import annotations

from devantis.client import BaseClient

SERVICE = "architecture-service"


class ArchitectureService:
    """Architecture document operations."""

    def __init__(self, http: BaseClient):
        self._http = http
        t = http.tenant
        self._base = f"/api/v1/org/{t.org_id}/project/{t.project_id}/app/{t.app_id}/architectures"

    # -- Read Operations -------------------------------------------------------

    async def list(self, folder: str = "") -> list[dict]:
        """List architecture documents, optionally filtered by folder."""
        params = {}
        if folder:
            params["folder"] = folder
        response = await self._http.get(SERVICE, self._base, params=params)
        data = response.json()
        return data.get("items", data) if isinstance(data, dict) else data

    async def get(self, architecture_id: str) -> dict:
        """Get full architecture document content."""
        response = await self._http.get(SERVICE, f"{self._base}/{architecture_id}")
        return response.json()

    async def search(self, query: str) -> list[dict]:
        """Search architecture documents by name or content."""
        response = await self._http.get(
            SERVICE, f"{self._base}/search", params={"q": query}
        )
        data = response.json()
        return data.get("results", data) if isinstance(data, dict) else data

    async def list_folders(self) -> list[dict]:
        """List all folders containing architecture documents."""
        response = await self._http.get(SERVICE, f"{self._base}/folders")
        data = response.json()
        return data.get("folders", data) if isinstance(data, dict) else data

    # -- Write Operations ------------------------------------------------------

    async def create(
        self,
        id: str,
        content: str,
        file_type: str = "diagram",
        folder: str = "",
    ) -> dict:
        """Create a new architecture document.

        Args:
            id: Document identifier (filename without extension).
            content: Document content (markdown, mermaid, etc.).
            file_type: Type of document — 'diagram' or 'document'.
            folder: Optional folder path.
        """
        body: dict = {"id": id, "content": content, "file_type": file_type}
        if folder:
            body["folder"] = folder
        response = await self._http.post(SERVICE, self._base, json=body)
        return response.json()

    async def update(self, architecture_id: str, content: str) -> dict:
        """Update an existing architecture document's content."""
        response = await self._http.put(
            SERVICE, f"{self._base}/{architecture_id}",
            json={"content": content},
        )
        return response.json()

    async def delete(self, architecture_id: str) -> None:
        """Delete an architecture document."""
        await self._http.delete(SERVICE, f"{self._base}/{architecture_id}")

    # -- Organise Operations ---------------------------------------------------

    async def move(self, architecture_id: str, folder: str) -> dict:
        """Move an architecture document to a different folder."""
        response = await self._http.post(
            SERVICE, f"{self._base}/{architecture_id}/move",
            json={"folder": folder},
        )
        return response.json()

    async def copy(
        self, architecture_id: str, new_id: str, folder: str = ""
    ) -> dict:
        """Copy an architecture document, optionally into a different folder.

        Args:
            architecture_id: Source document ID.
            new_id: ID for the new copy.
            folder: Target folder (defaults to same folder as source).
        """
        body: dict = {"new_id": new_id}
        if folder:
            body["folder"] = folder
        response = await self._http.post(
            SERVICE, f"{self._base}/{architecture_id}/copy",
            json=body,
        )
        return response.json()

    async def rename(self, architecture_id: str, new_id: str) -> dict:
        """Rename an architecture document.

        Args:
            architecture_id: Current document ID.
            new_id: New document ID.
        """
        response = await self._http.post(
            SERVICE, f"{self._base}/{architecture_id}/rename",
            json={"new_id": new_id},
        )
        return response.json()
