"""Documentation service — browse, read, and search platform documentation.

Documentation is served by the documentation-service (port 8098). The API returns
clean JSON; no YAML or frontmatter parsing is performed by the SDK.

The documentation API is public — no authentication is required.
"""

from __future__ import annotations

from devantis.client import BaseClient

SERVICE = "documentation-service"


class DocumentationService:
    """Platform documentation — browse, read, and search user docs."""

    def __init__(self, http: BaseClient):
        self._http = http
        self._base = "/api/v1/docs"

    async def list(
        self,
        category: str = "",
        tag: str = "",
    ) -> dict:
        """List documentation pages with optional filtering.

        Args:
            category: Filter by category slug (e.g., 'sdk', 'guides').
            tag: Filter by tag (e.g., 'authentication').

        Returns:
            Dict with 'pages' list and 'total' count.
        """
        params: dict = {}
        if category:
            params["category"] = category
        if tag:
            params["tag"] = tag
        response = await self._http.get(SERVICE, self._base, params=params)
        return response.json()

    async def get(self, slug: str) -> dict:
        """Read a documentation page by slug.

        Args:
            slug: Fully-qualified slug like 'sdk/getting-started'.

        Returns:
            Dict with title, description, author, tags, content, prev/next links.
        """
        response = await self._http.get(SERVICE, f"{self._base}/pages/{slug}")
        return response.json()

    async def search(self, query: str, max_results: int = 10) -> dict:
        """Full-text search across documentation.

        Args:
            query: Search text.
            max_results: Maximum results to return. Default: 10.

        Returns:
            Dict with 'query', 'results' list, and 'total' count.
        """
        params: dict = {"q": query, "max_results": max_results}
        response = await self._http.get(SERVICE, f"{self._base}/search", params=params)
        return response.json()

    async def navigation(self) -> dict:
        """Get the full navigation tree (categories + pages with titles)."""
        response = await self._http.get(SERVICE, f"{self._base}/navigation")
        return response.json()

    async def categories(self) -> list[dict]:
        """List categories with page counts."""
        response = await self._http.get(SERVICE, f"{self._base}/categories")
        return response.json()
