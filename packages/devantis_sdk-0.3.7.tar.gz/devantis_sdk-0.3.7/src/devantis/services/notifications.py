"""Notification service — channels, subscriptions, logs."""

from __future__ import annotations

from devantis.client import BaseClient

SERVICE = "notification-service"


class NotificationService:
    """Notification channel and subscription management."""

    def __init__(self, http: BaseClient):
        self._http = http
        self._org_id = http.tenant.org_id

    # ── Channels ──────────────────────────────────────────────

    async def list_channels(self, channel_type: str = "") -> list[dict]:
        """List notification channels."""
        params: dict = {"org_id": self._org_id}
        if channel_type:
            params["channel_type"] = channel_type
        resp = await self._http.get(
            SERVICE, "/api/v1/notifications/channels", params=params
        )
        return resp.json()

    async def get_channel(self, channel_id: str) -> dict:
        """Get channel details."""
        resp = await self._http.get(
            SERVICE,
            f"/api/v1/notifications/channels/{channel_id}",
            params={"org_id": self._org_id},
        )
        return resp.json()

    async def create_channel(
        self,
        name: str,
        channel_type: str,
        config: dict,
        enabled: bool = True,
    ) -> dict:
        """Create a notification channel (email, webhook, slack, teams)."""
        resp = await self._http.post(
            SERVICE,
            "/api/v1/notifications/channels",
            params={"org_id": self._org_id},
            json={
                "name": name,
                "channel_type": channel_type,
                "config": config,
                "enabled": enabled,
            },
        )
        return resp.json()

    async def update_channel(self, channel_id: str, **kwargs) -> dict:
        """Update a notification channel."""
        resp = await self._http.put(
            SERVICE,
            f"/api/v1/notifications/channels/{channel_id}",
            params={"org_id": self._org_id},
            json=kwargs,
        )
        return resp.json()

    async def delete_channel(self, channel_id: str) -> None:
        """Delete a notification channel."""
        await self._http.delete(
            SERVICE,
            f"/api/v1/notifications/channels/{channel_id}",
            params={"org_id": self._org_id},
        )

    async def test_channel(self, channel_id: str) -> dict:
        """Test a notification channel."""
        resp = await self._http.post(
            SERVICE,
            f"/api/v1/notifications/channels/{channel_id}/test",
            params={"org_id": self._org_id},
        )
        return resp.json()

    # ── Subscriptions ─────────────────────────────────────────

    async def list_subscriptions(self, event_type: str = "") -> list[dict]:
        """List notification subscriptions."""
        params: dict = {"org_id": self._org_id}
        if event_type:
            params["event_type"] = event_type
        resp = await self._http.get(
            SERVICE, "/api/v1/notifications/subscriptions", params=params
        )
        return resp.json()

    async def create_subscription(
        self,
        event_type: str,
        channel_id: str,
        min_severity: str = "info",
        enabled: bool = True,
    ) -> dict:
        """Create a notification subscription."""
        resp = await self._http.post(
            SERVICE,
            "/api/v1/notifications/subscriptions",
            params={"org_id": self._org_id},
            json={
                "event_type": event_type,
                "channel_id": channel_id,
                "min_severity": min_severity,
                "enabled": enabled,
            },
        )
        return resp.json()

    async def delete_subscription(self, subscription_id: str) -> None:
        """Delete a notification subscription."""
        await self._http.delete(
            SERVICE,
            f"/api/v1/notifications/subscriptions/{subscription_id}",
            params={"org_id": self._org_id},
        )

    async def list_event_types(self) -> dict:
        """List available event types and severity levels."""
        resp = await self._http.get(
            SERVICE, "/api/v1/notifications/subscriptions/event-types"
        )
        return resp.json()

    # ── Logs ──────────────────────────────────────────────────

    async def list_logs(
        self,
        channel_id: str = "",
        status: str = "",
        page: int = 1,
        page_size: int = 50,
    ) -> dict:
        """List notification logs."""
        params: dict = {"org_id": self._org_id, "page": page, "page_size": page_size}
        if channel_id:
            params["channel_id"] = channel_id
        if status:
            params["status"] = status
        resp = await self._http.get(
            SERVICE, "/api/v1/notifications/logs", params=params
        )
        return resp.json()

    async def retry_log(self, log_id: str) -> dict:
        """Retry a failed notification."""
        resp = await self._http.post(
            SERVICE,
            f"/api/v1/notifications/logs/{log_id}/retry",
            params={"org_id": self._org_id},
        )
        return resp.json()
