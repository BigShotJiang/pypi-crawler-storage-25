"""DevantisClient — main entry point for the SDK.

Connects to the Devantis platform and exposes all services.
"""

from __future__ import annotations

import logging
import os

from devantis.auth import BaseAuth, auto_detect_auth
from devantis.client import BaseClient, DEFAULT_SERVICES, DOCKER_SERVICES
from devantis.tenant import TenantContext, TenantResolver, resolve_from_env
from devantis.services.source import SourceService
from devantis.services.tickets import TicketService
from devantis.services.requirements import RequirementService
from devantis.services.search import SearchService
from devantis.services.memory import MemoryService
from devantis.services.architecture import ArchitectureService
from devantis.services.designs import DesignService
from devantis.services.executors import ExecutorService
from devantis.services.chat import ChatService
from devantis.services.projects import ProjectService
from devantis.services.analytics import AnalyticsService
from devantis.services.users import UserService
from devantis.services.knowledge_graph import KnowledgeGraphService
from devantis.services.notifications import NotificationService
from devantis.services.docs import DocumentationService
from devantis.services.billing import BillingService

logger = logging.getLogger(__name__)


class DevantisClient:
    """Main client for the Devantis platform.

    Usage:
        # Auto-detect auth and tenant from environment/config
        client = await DevantisClient.connect()

        # Or specify explicitly
        client = await DevantisClient.connect(
            org="my-org", project="my-proj", app="my-app"
        )

        # Use services
        files = await client.source.list()
        tickets = await client.tickets.list(status="open")
        results = await client.search("authentication")
        matches = await client.source.grep("def login", glob="*.py")
        await client.executors.shell("cd backend && python -m pytest")
    """

    def __init__(self, http: BaseClient):
        """Initialize with a configured BaseClient. Use connect() instead."""
        self._http = http

        # Core services
        self.source = SourceService(http)
        self.tickets = TicketService(http)
        self.requirements = RequirementService(http)
        self.memory = MemoryService(http)

        # Content services
        self.architecture = ArchitectureService(http)
        self.designs = DesignService(http)

        # Operations
        self.executors = ExecutorService(http)
        self.chat = ChatService(http)
        self.projects = ProjectService(http)
        self.analytics = AnalyticsService(http)
        self.users = UserService(http)

        # Knowledge & Automation
        self.knowledge_graph = KnowledgeGraphService(http)
        self.notifications = NotificationService(http)
        self.docs = DocumentationService(http)
        self.billing = BillingService(http)
        # Internal
        self._search_service = SearchService(http)

    @classmethod
    async def connect(
        cls,
        org: str = "",
        project: str = "",
        app: str = "",
        auth: BaseAuth | None = None,
        services: dict[str, str] | None = None,
    ) -> DevantisClient:
        """Connect to the Devantis platform.

        Auto-detects auth mode and tenant context if not provided.

        Args:
            org: Organisation slug or UUID. Auto-detected from env/config if omitted.
            project: Project slug or UUID. Auto-detected if omitted.
            app: Application slug or UUID. Auto-detected if omitted.
            auth: Auth provider. Auto-detected if omitted (InternalAuth or UserTokenAuth).
            services: Service URL overrides. Auto-detected (Docker or localhost).
        """
        # Auto-detect auth
        if auth is None:
            auth = auto_detect_auth()

        # Auto-detect service URLs
        # Priority: explicit param > INTERNAL_SERVICE_KEY (Docker) > config file > defaults
        # Docker mode: use internal service URLs, disable gateway
        # Otherwise: gateway mode (default: development URL)
        _force_local = False
        _config_api_url = None
        if services is None:
            if os.environ.get("INTERNAL_SERVICE_KEY"):
                services = DOCKER_SERVICES
                _force_local = True
            else:
                config = _load_config()
                services = config.get("services") or DEFAULT_SERVICES
                _config_api_url = config.get("api_url")  # e.g., https://devantis.dev.encodeit.ro

        # Auto-detect tenant
        if not all([org, project, app]):
            org, project, app = resolve_from_env()

        # Resolve tenant (slug → UUID)
        import httpx
        async_http = httpx.AsyncClient(timeout=15.0)
        resolver = TenantResolver(async_http, auth, services.get("project-service", ""))
        tenant = await resolver.resolve(org, project, app)
        await async_http.aclose()

        # Build client
        # Docker mode: disable gateway (direct service URLs)
        # Config file: use api_url from config if set
        # Default: production gateway URL (set in BaseClient)
        kwargs: dict = {"auth": auth, "tenant": tenant, "services": services}
        if _force_local:
            kwargs["gateway_url"] = ""
        elif _config_api_url:
            kwargs["gateway_url"] = _config_api_url
        http = BaseClient(**kwargs)
        client = cls(http)

        logger.info(
            f"Connected to Devantis: {tenant.org_name}/{tenant.project_name}/{tenant.app_name} "
            f"(role: {tenant.user_role or 'unknown'})"
        )

        return client

    # ── Convenience Methods ────────────────────────────────────

    async def search(
        self,
        query: str,
        entity_types: list[str] | None = None,
    ) -> dict:
        """Search across all entity types in parallel.

        Args:
            query: Search text
            entity_types: Optional filter: requirements, tickets, architecture, designs, code

        Returns:
            Results grouped by entity type.
        """
        return await self._search_service.search(query, entity_types)

    @property
    def context(self) -> TenantContext:
        """Current tenant context (org, project, app)."""
        return self._http.tenant

    async def switch_context(
        self,
        org: str = "",
        project: str = "",
        app: str = "",
    ) -> TenantContext:
        """Switch to a different org/project/app.

        Omitted parameters retain their current value.
        """
        current = self._http.tenant
        org = org or current.org_slug
        project = project or current.project_slug
        app = app or current.app_slug

        import httpx
        async_http = httpx.AsyncClient(timeout=15.0)
        resolver = TenantResolver(
            async_http, self._http.auth,
            self._http.service_url("project-service"),
        )
        new_tenant = await resolver.resolve(org, project, app)
        await async_http.aclose()

        self._http.tenant = new_tenant

        # Reinitialize all services with new tenant
        self.__init__(self._http)

        logger.info(f"Switched to: {new_tenant.org_name}/{new_tenant.project_name}/{new_tenant.app_name}")
        return new_tenant

    async def get_project_overview(self) -> dict:
        """Get a summary of the current project state.

        Used by the MCP server for the dynamic briefing
        and by the agentic executor for system prompt enrichment.
        """
        import asyncio

        async def safe(coro, default=None):
            try:
                return await coro
            except Exception:
                return default

        reqs, tickets, files, mem, features = await asyncio.gather(
            safe(self.requirements.list(page_size=1), {}),
            safe(self.tickets.list(page_size=1), {}),
            safe(self.source.list(), []),
            safe(self.memory.list(), {}),
            safe(self.requirements.list_features(), []),
        )

        # Count files by extension
        extensions: dict[str, int] = {}
        folders: set[str] = set()
        for f in (files if isinstance(files, list) else []):
            ext = f.get("extension", "")
            if ext:
                extensions[ext] = extensions.get(ext, 0) + 1
            folder = f.get("folder", "")
            if folder:
                folders.add(folder)

        return {
            "requirements": {
                "total": reqs.get("total", 0) if isinstance(reqs, dict) else 0,
                "features": features if isinstance(features, list) else [],
            },
            "tickets": {
                "total": tickets.get("total", 0) if isinstance(tickets, dict) else 0,
            },
            "source_code": {
                "total_files": len(files) if isinstance(files, list) else 0,
                "languages": extensions,
                "top_folders": sorted(folders)[:10],
            },
            "memory": mem if isinstance(mem, dict) else {},
        }

    async def build_briefing(self) -> str:
        """Build a complete project briefing from live data.

        Used by:
        - MCP server: as dynamic server instructions
        - Agentic executor: appended to system prompt

        Returns a text string with everything Claude needs to know.
        """
        ctx = self.context
        overview = await self.get_project_overview()

        # Build file tree
        try:
            files = await self.source.list()
            tree_lines = []
            for f in (files if isinstance(files, list) else []):
                tree_lines.append(f.get("path", ""))
            tree = "\n".join(sorted(tree_lines)[:100])  # Cap at 100 files
        except Exception:
            tree = "(could not load file tree)"

        # Format memory
        mem = overview.get("memory", {})
        mem_lines = "\n".join(f"- **{k}**: {v}" for k, v in mem.items()) if mem else "(no project memory saved)"

        # Format languages
        langs = overview.get("source_code", {}).get("languages", {})
        lang_str = ", ".join(f"{ext}: {count}" for ext, count in sorted(langs.items(), key=lambda x: -x[1])[:8])

        return f"""You are connected to the Devantis development platform with full access.

# Your Context

| Field | Value |
|---|---|
| Organisation | {ctx.org_name} (`{ctx.org_slug}`) |
| Project | {ctx.project_name} (`{ctx.project_slug}`) |
| Application | {ctx.app_name} (`{ctx.app_slug}`) |
| App Type | {ctx.app_type or 'unknown'} |

# Project State

- **Requirements**: {overview['requirements']['total']} total, features: {', '.join(overview['requirements']['features']) or 'none'}
- **Tickets**: {overview['tickets']['total']} total
- **Source Code**: {overview['source_code']['total_files']} files ({lang_str or 'no files'})
- **Folders**: {', '.join(overview['source_code']['top_folders'][:5]) or 'none'}

# Project Memory

{mem_lines}

# File Tree

```
{tree}
```

# How to Work

## Implementing features:
1. `devantis_search(query)` — find related requirements, tickets, code
2. `devantis_get_requirement(id)` — read the full spec
3. `devantis_grep(pattern, glob="*.py")` — find related code patterns
4. `devantis_read_file(path)` — understand existing code
5. `devantis_edit_file(path, old, new)` — make targeted changes
6. `devantis_write_file(path, content)` — only for NEW files
7. `devantis_transition_ticket(id, "done")` — update status

## Key rules:
- **Search before creating** — avoid duplicates
- **Read before editing** — understand the code first
- **Edit, don't rewrite** — use edit_file for changes, write_file only for new files
- **grep for code search** — file search only matches names, grep searches content
- **Artifact content in English** — regardless of chat language
- **Update ticket status** — when starting or completing work
"""

    async def close(self) -> None:
        """Close the client and release resources."""
        await self._http.close()


def _load_config() -> dict:
    """Load SDK config from ~/.devantis-mcp.yaml."""
    import yaml
    from pathlib import Path

    config_path = Path("~/.devantis-mcp.yaml").expanduser()
    if not config_path.exists():
        return {}

    try:
        with open(config_path) as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}


def _load_service_urls() -> dict[str, str] | None:
    """Try to load service URLs from config file."""
    return _load_config().get("services", None)
