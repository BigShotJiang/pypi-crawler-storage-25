from .config import configure_logging

__version__ = "2.21.0"  # x-release-please-version
__library_name__ = "Secret Safe Library"

configure_logging()
