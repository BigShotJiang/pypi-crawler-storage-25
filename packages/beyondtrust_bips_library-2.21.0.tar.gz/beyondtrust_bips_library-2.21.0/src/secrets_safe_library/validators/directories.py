from secrets_safe_library.validators.base import BaseValidator

_CHANGE_FREQUENCY_FIELDS = {
    "change_frequency_type": {
        "type": "string",
        "allowed": ["first", "last", "xdays"],
        "nullable": True,
    },
    "change_frequency_days": {
        "type": "integer",
        "min": 1,
        "max": 999,
        "nullable": True,
        "default": None,
        "is_required_if": {"field": "change_frequency_type", "value": "xdays"},
    },
}


_DIRECTORY_BODY_FIELDS = {
    "domain_name": {"type": "string", "maxlength": 255, "nullable": True},
    "forest_name": {"type": "string", "maxlength": 64, "nullable": True},
    "net_bios_name": {"type": "string", "maxlength": 15, "nullable": True},
    "use_ssl": {"type": "boolean", "nullable": True},
    "platform_id": {"type": "integer", "min": 1, "nullable": True},
    "port": {"type": "integer", "min": 1, "max": 65535, "nullable": True},
    "timeout": {"type": "integer", "min": 1, "max": 3600, "nullable": True},
    "description": {"type": "string", "maxlength": 255, "nullable": True},
    "contact_email": {"type": "string", "maxlength": 1000, "nullable": True},
    "password_rule_id": {"type": "integer", "min": 0, "nullable": True},
    "release_duration": {
        "type": "integer",
        "min": 1,
        "max": 525600,
        "nullable": True,
    },
    "max_release_duration": {
        "type": "integer",
        "min": 1,
        "max": 525600,
        "nullable": True,
    },
    "isa_release_duration": {
        "type": "integer",
        "min": 1,
        "max": 525600,
        "nullable": True,
    },
    "auto_management_flag": {"type": "boolean", "nullable": True},
    "functional_account_id": {"type": "integer", "nullable": True},
    "account_name_format": {"type": "integer", "nullable": True},
    "check_password_flag": {"type": "boolean", "nullable": True},
    "change_password_after_any_release_flag": {"type": "boolean", "nullable": True},
    "reset_password_on_mismatch_flag": {"type": "boolean", "nullable": True},
}


class _DirectorySchemaValidator:
    def get_create_schema(self) -> dict:
        return {
            **_CHANGE_FREQUENCY_FIELDS,
            **_DIRECTORY_BODY_FIELDS,
            "workgroup_id": {"type": "integer", "min": 1, "nullable": False},
            "change_time": {
                "type": "string",
                "regex": r"^([01]\d|2[0-3]):[0-5]\d$",
                "nullable": True,
            },
        }

    def get_update_schema(self) -> dict:
        return {
            **_CHANGE_FREQUENCY_FIELDS,
            **_DIRECTORY_BODY_FIELDS,
            "directory_id": {"type": "integer", "min": 1, "nullable": False},
            "workgroup_id": {"type": "integer", "min": 1, "nullable": True},
            "change_time": {
                "type": "string",
                "regex": r"^([01]\d|2[0-3]):[0-5]\d$",
                "nullable": True,
            },
        }


class DirectoryValidator(BaseValidator):
    """Validator for Directory create/update operations."""

    def __init__(self):
        self.schema_validator = _DirectorySchemaValidator()

    def get_schema(self, operation: str) -> dict:
        if operation == "create":
            return self.schema_validator.get_create_schema()
        if operation == "update":
            return self.schema_validator.get_update_schema()
        raise ValueError(f"Unsupported operation: {operation}")

    def validate(
        self,
        data: dict,
        operation: str,
        allow_unknown: bool = True,
        update: bool = False,
    ) -> dict:
        schema = self.get_schema(operation)
        data = super().validate(data, schema, allow_unknown, update)
        return data
