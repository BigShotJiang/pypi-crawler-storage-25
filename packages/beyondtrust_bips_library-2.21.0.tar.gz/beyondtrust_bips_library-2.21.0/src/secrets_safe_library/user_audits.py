"""User Audits module, all the logic to manage User Audits from BeyondInsight API"""

import logging

from secrets_safe_library import utils
from secrets_safe_library.authentication import Authentication
from secrets_safe_library.core import APIObject


class UserAudit(APIObject):
    """Class to interact with User Audits in BeyondInsight API."""

    def __init__(self, authentication: Authentication, logger: logging.Logger = None):
        super().__init__(authentication, logger, endpoint="/useraudits")

    def list_user_audits(
        self,
        username: str = None,
        action_type: str = None,
        section: str = None,
        start_date: str = None,
        end_date: str = None,
        limit: int = None,
        offset: int = None,
    ) -> dict:
        """
        Returns a list of user audit records.

        API: GET /useraudits

        Args:
            username (str, optional): Filter by username.
            action_type (str, optional): Filter by action type.
            section (str, optional): Filter by section.
            start_date (str, optional): Filter by start date (ISO 8601).
            end_date (str, optional): Filter by end date (ISO 8601).
            limit (int, optional): Maximum number of records to return.
            offset (int, optional): Number of records to skip.

        Returns:
            dict: Paginated response with TotalCount and Data fields.
        """
        if limit is not None or offset is not None:
            self.validate_pagination(limit, offset)

        params = {
            "username": username,
            "actionType": action_type,
            "section": section,
            "startDate": start_date,
            "endDate": end_date,
            "limit": limit,
            "offset": offset,
        }
        query_string = self.make_query_string(params)
        endpoint = f"{self.endpoint}?{query_string}" if query_string else self.endpoint

        utils.print_log(
            self._logger,
            "Calling list_user_audits endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)
        return response.json()

    def get_user_audit_details(
        self,
        audit_id: int,
        limit: int = None,
        offset: int = None,
    ) -> dict:
        """
        Returns details for a specific user audit record.

        API: GET /useraudits/{auditId}/userauditdetails

        Args:
            audit_id (int): The user audit record ID.
            limit (int, optional): Maximum number of records to return.
            offset (int, optional): Number of records to skip.

        Returns:
            dict: Paginated response with TotalCount and Data fields.
        """
        if limit is not None or offset is not None:
            self.validate_pagination(limit, offset)

        params = {
            "limit": limit,
            "offset": offset,
        }
        query_string = self.make_query_string(params)
        endpoint = f"{self.endpoint}/{audit_id}/userauditdetails"
        if query_string:
            endpoint = f"{endpoint}?{query_string}"

        utils.print_log(
            self._logger,
            f"Calling get_user_audit_details endpoint for audit {audit_id}",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)
        return response.json()
