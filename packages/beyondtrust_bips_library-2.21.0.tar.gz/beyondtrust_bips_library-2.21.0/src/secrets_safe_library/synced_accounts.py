"""Synced Accounts module, managing synced accounts from BeyondInsight API"""

import logging

from cerberus import Validator

from secrets_safe_library import exceptions, utils
from secrets_safe_library.authentication import Authentication
from secrets_safe_library.core import APIObject


class SyncedAccount(APIObject):
    """
    Class to manage synced accounts for managed accounts in BeyondInsight API.
    """

    def __init__(self, authentication: Authentication, logger: logging.Logger = None):
        super().__init__(authentication, logger, endpoint="/syncedaccounts")
        self._schema = {
            "managed_account_id": {"type": "integer", "nullable": False, "min": 1},
            "synced_account_id": {"type": "integer", "nullable": False, "min": 1},
        }
        self._validator = Validator(self._schema)

    def list_by_managed_account(self, managed_account_id: int) -> list:
        """
        Returns all synced accounts for a managed account.

        API: GET ManagedAccounts/{managedAccountID}/SyncedAccounts

        Args:
            managed_account_id (int): The ID of the managed account.

        Returns:
            list: List of synced accounts.
        """
        if not self._validator.validate({"managed_account_id": managed_account_id}):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        endpoint = f"/managedaccounts/{managed_account_id}{self.endpoint}"

        utils.print_log(
            self._logger,
            "Calling list synced accounts by managed account ID endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)

        return response.json()

    def create(self, managed_account_id: int, synced_account_id: int) -> dict:
        """
        Syncs a managed account with another managed account.

        API: POST ManagedAccounts/{managedAccountID}/SyncedAccounts/{syncedAccountID}

        Args:
            managed_account_id (int): The ID of the managed account to sync to.
            synced_account_id (int): The ID of the managed account to sync.

        Returns:
            dict: The created synced account.
        """
        if not self._validator.validate(
            {
                "managed_account_id": managed_account_id,
                "synced_account_id": synced_account_id,
            }
        ):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        endpoint = (
            f"/managedaccounts/{managed_account_id}"
            f"{self.endpoint}/{synced_account_id}"
        )

        utils.print_log(
            self._logger,
            "Calling create synced account endpoint",
            logging.DEBUG,
        )
        response = self._run_post_request(
            endpoint,
            payload={},
            include_api_version=False,
            expected_status_code=[200, 201],
        )

        return response.json()

    def delete_all(self, managed_account_id: int) -> None:
        """
        Deletes all synced accounts for a managed account.

        API: DELETE ManagedAccounts/{managedAccountID}/SyncedAccounts

        Args:
            managed_account_id (int): The ID of the managed account.
        """
        if not self._validator.validate({"managed_account_id": managed_account_id}):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        endpoint = f"/managedaccounts/{managed_account_id}{self.endpoint}"

        utils.print_log(
            self._logger,
            "Calling delete all synced accounts endpoint",
            logging.DEBUG,
        )
        self._run_delete_request(endpoint)

    def delete(self, managed_account_id: int, synced_account_id: int) -> None:
        """
        Deletes a single synced account from a managed account.

        API: DELETE ManagedAccounts/{managedAccountID}/SyncedAccounts/{syncedAccountID}

        Args:
            managed_account_id (int): The ID of the managed account.
            synced_account_id (int): The ID of the synced account to unsync.
        """
        if not self._validator.validate(
            {
                "managed_account_id": managed_account_id,
                "synced_account_id": synced_account_id,
            }
        ):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        endpoint = (
            f"/managedaccounts/{managed_account_id}"
            f"{self.endpoint}/{synced_account_id}"
        )

        utils.print_log(
            self._logger,
            "Calling delete synced account endpoint",
            logging.DEBUG,
        )
        self._run_delete_request(endpoint)
