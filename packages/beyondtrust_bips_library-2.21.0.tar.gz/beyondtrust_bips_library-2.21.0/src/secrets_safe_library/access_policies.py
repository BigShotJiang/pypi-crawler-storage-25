"""Access Policies module, all the logic to read and test access policies from PS API"""

import logging
from typing import Tuple

from cerberus import Validator

from secrets_safe_library import exceptions, utils
from secrets_safe_library.authentication import Authentication
from secrets_safe_library.core import APIObject
from secrets_safe_library.mixins import ListMixin
from secrets_safe_library.validators.base import CustomValidator


class AccessPolicy(APIObject, ListMixin):

    def __init__(self, authentication: Authentication, logger: logging.Logger = None):
        super().__init__(authentication, logger, endpoint="/accesspolicies")

        # Schema rules used for validations
        self._schema = {
            "system_id": {"type": "integer", "min": 1, "required": True},
            "account_id": {"type": "integer", "min": 1, "required": True},
            "duration_minutes": {"type": "integer", "min": 1, "default": 60},
        }
        self._validator = Validator(self._schema)

        self._policy_id_validator = CustomValidator(
            {"policy_id": {"type": "integer", "min": 1}}
        )

    def test_access_policy(
        self,
        system_id: int,
        account_id: int,
        duration_minutes: int = 60,
    ) -> Tuple[dict, int]:
        """
        Tests access to a managed account and returns a list of Password Safe access
        policies that are available in the request window.

        API: POST AccessPolicies/Test

        Args:
            system_id (int): The ID of the system.
            account_id (int): The ID of the account.
            duration_minutes (int, optional): The duration in minutes for which the
                access is requested. Defaults to 60.

        Returns:
            Tuple[dict, int]: Tuple containing the JSON response and the HTTP status
                code.
        """
        attributes = {
            "system_id": system_id,
            "account_id": account_id,
            "duration_minutes": duration_minutes,
        }

        if not self._validator.validate(attributes, update=True):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        payload = {
            "SystemId": system_id,
            "AccountId": account_id,
            "DurationMinutes": duration_minutes,
        }
        endpoint = f"{self.endpoint}/test"

        utils.print_log(
            self._logger,
            "Calling test access policy endpoint",
            logging.DEBUG,
        )
        response = self._run_post_request(
            endpoint, payload, include_api_version=False, expected_status_code=200
        )

        return response.json(), response.status_code

    def list_assignees(
        self,
        policy_id: int,
        limit: int = None,
        offset: int = None,
    ) -> dict:
        """
        Returns a paginated response of access policy assignees for a given access
        policy.

        API: GET AccessPolicies/{id}/Assignees

        Args:
            policy_id (int): The ID of the access policy.
            limit (int, optional): Maximum number of records to return.
            offset (int, optional): Number of records to skip.

        Returns:
            dict: Paginated response with ``TotalCount`` and ``Data`` keys.
        """
        if not self._policy_id_validator.validate(
            {"policy_id": policy_id}, update=True
        ):
            raise exceptions.OptionsError(
                f"Please check: {self._policy_id_validator.errors}"
            )

        if limit is not None or offset is not None:
            self.validate_pagination(limit, offset)

        params = {"limit": limit, "offset": offset}
        query_string = self.make_query_string(params)
        endpoint = f"{self.endpoint}/{policy_id}/assignees"
        if query_string:
            endpoint = f"{endpoint}?{query_string}"

        utils.print_log(
            self._logger,
            "Calling list_assignees endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)
        return response.json()
