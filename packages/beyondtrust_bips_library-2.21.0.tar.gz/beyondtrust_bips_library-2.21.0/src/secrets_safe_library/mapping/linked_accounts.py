"""
This file contains the fields mapping for each endpoint and version related to
Linked Accounts.

More info for the fields included in each endpoint and version:
- https://docs.beyondtrust.com/bips/docs/beyondinsight-apis
- https://docs.beyondtrust.com/bips/docs/password-safe-apis
"""

from secrets_safe_library.constants.endpoints import (
    GET_LINKED_ACCOUNTS_MANAGED_SYSTEM_ID,
    POST_LINKED_ACCOUNT_MANAGED_SYSTEM_ID,
)
from secrets_safe_library.constants.versions import Version

fields = {
    GET_LINKED_ACCOUNTS_MANAGED_SYSTEM_ID: {
        Version.DEFAULT.value: [
            "ManagedAccountID",
            "ManagedSystemID",
            "DomainName",
            "AccountName",
            "DistinguishedName",
            "UserPrincipalName",
            "SAMAccountName",
        ],
    },
    POST_LINKED_ACCOUNT_MANAGED_SYSTEM_ID: {
        Version.DEFAULT.value: {
            "ManagedAccountID": int,
            "ManagedSystemID": int,
            "DomainName": str,
            "AccountName": str,
            "DistinguishedName": str,
            "UserPrincipalName": str,
            "SAMAccountName": str,
            "PasswordFallbackFlag": bool,
            "LoginAccountFlag": bool,
            "Description": str,
            "ApiEnabled": bool,
            "PasswordRuleID": int,
            "ReleaseNotificationEmail": str,
            "ChangeServicesFlag": bool,
            "ChangeTasksFlag": bool,
            "RestartServicesFlag": bool,
            "AutoManagementFlag": bool,
            "DSSAutoManagementFlag": bool,
            "CheckPasswordFlag": bool,
            "ChangePasswordAfterAnyReleaseFlag": bool,
            "ResetPasswordOnMismatchFlag": bool,
            "ReleaseDuration": int,
            "MaxReleaseDuration": int,
            "ISAReleaseDuration": int,
            "ChangeFrequencyType": str,
            "ChangeFrequencyDays": int,
            "ChangeTime": str,
            "IsSubscribedAccount": bool,
            "ParentAccountID": int,
            "MaxConcurrentRequests": int,
            "LastChangeDate": str,
            "NextChangeDate": str,
            "ChangeState": int,
            "IsChanging": bool,
            "UseOwnCredentials": bool,
            "ChangeIISAppPoolFlag": bool,
            "RestartIISAppPoolFlag": bool,
            "WorkgroupID": int,
            "ChangeWindowsAutoLogonFlag": bool,
            "ChangeComPlusFlag": bool,
            "ChangeDComFlag": bool,
            "ChangeSComFlag": bool,
            "ObjectID": str,
        },
    },
}
