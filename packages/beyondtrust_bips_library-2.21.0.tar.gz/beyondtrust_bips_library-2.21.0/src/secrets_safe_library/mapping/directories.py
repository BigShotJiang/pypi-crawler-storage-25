"""
This file contains the fields mapping for each endpoint and version related to
DIRECTORIES.

More info for the fields included in each endpoint and version:
- https://docs.beyondtrust.com/bips/docs/beyondinsight-api
"""

from secrets_safe_library.constants.endpoints import (
    GET_DIRECTORIES,
    GET_DIRECTORIES_ID,
    GET_DIRECTORIES_ID_MANAGED_SYSTEMS,
    POST_WORKGROUPS_WORKGROUPID_DIRECTORIES,
    PUT_DIRECTORIES_ID,
)
from secrets_safe_library.constants.versions import Version

_CREATE_DIRECTORY_BODY_FIELDS = {
    "DomainName": str,
    "ForestName": str,
    "NetBiosName": str,
    "UseSSL": bool,
    "PlatformID": int,
    "Port": int,
    "Timeout": int,
    "Description": str,
    "ContactEmail": str,
    "PasswordRuleID": int,
    "ReleaseDuration": int,
    "MaxReleaseDuration": int,
    "ISAReleaseDuration": int,
    "AutoManagementFlag": bool,
    "FunctionalAccountID": int,
    "AccountNameFormat": int,
    "CheckPasswordFlag": bool,
    "ChangePasswordAfterAnyReleaseFlag": bool,
    "ResetPasswordOnMismatchFlag": bool,
    "ChangeFrequencyType": str,
    "ChangeFrequencyDays": int,
    "ChangeTime": str,
}

_UPDATE_DIRECTORY_BODY_FIELDS = {
    **_CREATE_DIRECTORY_BODY_FIELDS,
    "WorkgroupID": int,
}

_DIRECTORY_FIELDS = ["DirectoryID", *_UPDATE_DIRECTORY_BODY_FIELDS.keys()]

fields = {
    GET_DIRECTORIES: {
        Version.DEFAULT.value: _DIRECTORY_FIELDS,
    },
    GET_DIRECTORIES_ID: {
        Version.DEFAULT.value: _DIRECTORY_FIELDS,
    },
    POST_WORKGROUPS_WORKGROUPID_DIRECTORIES: {
        Version.DEFAULT.value: _CREATE_DIRECTORY_BODY_FIELDS,
    },
    PUT_DIRECTORIES_ID: {
        Version.DEFAULT.value: _UPDATE_DIRECTORY_BODY_FIELDS,
    },
    GET_DIRECTORIES_ID_MANAGED_SYSTEMS: {
        Version.DEFAULT.value: [
            "ManagedSystemID",
            "EntityTypeID",
            "AssetID",
            "DatabaseID",
            "DirectoryID",
            "WorkgroupID",
            "HostName",
            "IPAddress",
            "PlatformID",
            "NetBiosName",
            "Port",
            "Timeout",
            "Description",
            "ContactEmail",
            "PasswordRuleID",
            "ReleaseDuration",
            "MaxReleaseDuration",
            "ISAReleaseDuration",
            "AutoManagementFlag",
            "FunctionalAccountID",
            "CheckPasswordFlag",
            "ChangePasswordAfterAnyReleaseFlag",
            "ResetPasswordOnMismatchFlag",
            "ChangeFrequencyType",
            "ChangeFrequencyDays",
            "ChangeTime",
            "AccountNameFormat",
        ],
    },
}
