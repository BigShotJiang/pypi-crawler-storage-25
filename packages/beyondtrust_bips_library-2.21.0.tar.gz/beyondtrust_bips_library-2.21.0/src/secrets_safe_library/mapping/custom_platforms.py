"""
This file contains the fields mapping for each endpoint and version related to
Custom Platforms.

More info for the fields included in each endpoint and version:
- https://docs.beyondtrust.com/bips/reference/introduction
"""

from secrets_safe_library.constants.endpoints import (
    GET_CUSTOM_PLATFORMS,
    GET_CUSTOM_PLATFORMS_ID,
    GET_CUSTOM_PLATFORMS_ID_EXPORT,
    POST_CUSTOM_PLATFORMS_IMPORT,
)
from secrets_safe_library.constants.versions import Version

fields = {
    GET_CUSTOM_PLATFORMS: {
        Version.DEFAULT.value: [
            "id",
            "name",
        ],
    },
    GET_CUSTOM_PLATFORMS_ID: {
        Version.DEFAULT.value: [
            "id",
            "name",
        ],
    },
    GET_CUSTOM_PLATFORMS_ID_EXPORT: {
        Version.DEFAULT.value: [],
    },
    POST_CUSTOM_PLATFORMS_IMPORT: {
        Version.DEFAULT.value: ["CustomPlatform"],
    },
}
