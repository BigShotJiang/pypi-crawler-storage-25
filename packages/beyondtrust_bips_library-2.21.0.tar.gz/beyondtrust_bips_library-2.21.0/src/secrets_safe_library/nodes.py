"""Nodes module, all the logic to manage nodes from PS API"""

import logging

from secrets_safe_library.authentication import Authentication
from secrets_safe_library.core import APIObject
from secrets_safe_library.mixins import ListMixin


class Nodes(APIObject, ListMixin):
    """
    Nodes class for managing nodes via the PS API.

    This class provides functionality to list nodes.
    Inherits from APIObject and ListMixin to provide basic API functionality
    and list operations.
    """

    def __init__(self, authentication: Authentication, logger: logging.Logger = None):
        super().__init__(authentication, logger, endpoint="/nodes")
