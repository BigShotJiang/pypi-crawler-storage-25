"""Directories module, all the logic to manage directories from BeyondInsight API"""

import logging

from secrets_safe_library import utils
from secrets_safe_library.authentication import Authentication
from secrets_safe_library.constants.endpoints import (
    POST_WORKGROUPS_WORKGROUPID_DIRECTORIES,
    PUT_DIRECTORIES_ID,
)
from secrets_safe_library.core import APIObject
from secrets_safe_library.mapping import directories as dir_mapping
from secrets_safe_library.mixins import DeleteByIdMixin, GetByIdMixin, ListMixin
from secrets_safe_library.validators.directories import DirectoryValidator


class Directory(
    APIObject, ListMixin, GetByIdMixin, DeleteByIdMixin, DirectoryValidator
):
    """
    Class to interact with directories in BeyondInsight API.
    """

    def __init__(self, authentication: Authentication, logger: logging.Logger = None):
        APIObject.__init__(self, authentication, logger, endpoint="/directories")
        DirectoryValidator.__init__(self)

    def list_directories(self) -> list:
        """
        Returns all directories.

        API: GET Directories

        Returns:
            list: List of directories.
        """
        utils.print_log(
            self._logger,
            "Calling list_directories endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(self.endpoint, include_api_version=False)
        return response.json()

    def get_directory_by_id(self, directory_id: int) -> dict:
        """
        Returns a directory by ID.

        API: GET Directories/{id}

        Args:
            directory_id (int): The unique identifier of the directory.

        Returns:
            dict: Directory data.
        """
        endpoint = f"{self.endpoint}/{directory_id}"
        utils.print_log(
            self._logger,
            "Calling get_directory_by_id endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)
        return response.json()

    def delete_directory_by_id(self, directory_id: int) -> None:
        """
        Deletes a directory by ID.

        API: DELETE Directories/{id}

        Args:
            directory_id (int): The unique identifier of the directory.

        Returns:
            None
        """
        endpoint = f"{self.endpoint}/{directory_id}"
        utils.print_log(
            self._logger,
            "Calling delete_directory_by_id endpoint",
            logging.DEBUG,
        )
        self._run_delete_request(endpoint, expected_status_code=200)

    def create_directory(self, workgroup_id: int, **kwargs) -> dict:
        """
        Creates a directory under the specified workgroup.

        API: POST Workgroups/{workgroupID}/Directories

        Args:
            workgroup_id (int): The ID of the workgroup to create the directory under.
            **kwargs: Optional body fields. Accepted keys:
                domain_name (str): The domain name of the directory.
                forest_name (str): The forest name.
                net_bios_name (str): The NetBIOS name.
                use_ssl (bool): Whether to use SSL.
                platform_id (int): The platform ID.
                port (int): The port number.
                timeout (int): The connection timeout in seconds.
                description (str): A description for the directory.
                contact_email (str): The contact email address.
                password_rule_id (int): The ID of the password rule.
                release_duration (int): The default release duration in minutes.
                max_release_duration (int): The max release duration in minutes.
                isa_release_duration (int): The ISA release duration in minutes.
                auto_management_flag (bool): Whether auto management is enabled.
                functional_account_id (int): The ID of the functional account.
                account_name_format (int): The account name format.
                check_password_flag (bool): Whether to enable password testing.
                change_password_after_any_release_flag (bool): Whether to change
                    password after any release.
                reset_password_on_mismatch_flag (bool): Whether to reset password
                    on mismatch.
                change_frequency_type (str): The change frequency type
                    (first, last, xdays).
                change_frequency_days (int): The number of days between password
                    changes. Required when change_frequency_type is 'xdays'.
                change_time (str): The time of day for password changes (HH:MM).

        Returns:
            dict: The created directory data.

        Raises:
            OptionsError: If workgroup_id < 1, change_frequency_type is invalid, or
                change_frequency_days is missing when change_frequency_type is 'xdays'.
            CreationError: If the API returns an error response.
        """
        validated_data = self.validate(
            {"workgroup_id": workgroup_id, **kwargs},
            "create",
            allow_unknown=False,
        )

        req_structure = self.get_request_body_version(
            dir_mapping.fields,
            POST_WORKGROUPS_WORKGROUPID_DIRECTORIES,
        )
        payload = self.generate_request_body(
            req_structure,
            **{k: v for k, v in validated_data.items() if k != "workgroup_id"},
        )

        utils.print_log(
            self._logger,
            "Calling create_directory endpoint",
            logging.DEBUG,
        )

        response = self._run_post_request(
            f"/workgroups/{workgroup_id}/directories",
            payload=payload,
            include_api_version=False,
            expected_status_code=200,
        )
        return response.json()

    def update_directory(self, directory_id: int, **kwargs) -> dict:
        """
        Updates an existing directory by ID.

        API: PUT Directories/{id}

        Args:
            directory_id (int): The unique identifier of the directory to update.
            **kwargs: Optional body fields. Accepted keys:
                domain_name (str): The domain name of the directory.
                forest_name (str): The forest name.
                net_bios_name (str): The NetBIOS name.
                use_ssl (bool): Whether to use SSL.
                platform_id (int): The platform ID.
                workgroup_id (int): The ID of the workgroup.
                port (int): The port number.
                timeout (int): The connection timeout in seconds.
                description (str): A description for the directory.
                contact_email (str): The contact email address.
                password_rule_id (int): The ID of the password rule.
                release_duration (int): The default release duration in minutes.
                max_release_duration (int): The max release duration in minutes.
                isa_release_duration (int): The ISA release duration in minutes.
                auto_management_flag (bool): Whether auto management is enabled.
                functional_account_id (int): The ID of the functional account.
                account_name_format (int): The account name format.
                check_password_flag (bool): Whether to enable password testing.
                change_password_after_any_release_flag (bool): Whether to change
                    password after any release.
                reset_password_on_mismatch_flag (bool): Whether to reset password
                    on mismatch.
                change_frequency_type (str): The change frequency type
                    (first, last, xdays).
                change_frequency_days (int): The number of days between password
                    changes. Required when change_frequency_type is 'xdays'.
                change_time (str): The time of day for password changes (HH:MM).

        Returns:
            dict: The updated directory data.

        Raises:
            OptionsError: If directory_id < 1, change_frequency_type is invalid, or
                change_frequency_days is missing when change_frequency_type is 'xdays'.
            UpdateError: If the API returns an error response.
        """
        validated_data = self.validate(
            {"directory_id": directory_id, **kwargs},
            "update",
            allow_unknown=False,
        )

        req_structure = self.get_request_body_version(
            dir_mapping.fields,
            PUT_DIRECTORIES_ID,
        )
        payload = self.generate_request_body(
            req_structure,
            **{k: v for k, v in validated_data.items() if k != "directory_id"},
        )

        utils.print_log(
            self._logger,
            "Calling update_directory endpoint",
            logging.DEBUG,
        )

        response = self._run_put_request(
            f"/directories/{directory_id}",
            payload=payload,
            include_api_version=False,
        )
        return response.json()

    def get_managed_systems_by_directory_id(self, directory_id: int) -> list:
        """
        Returns all managed systems associated with a directory.

        API: GET Directories/{id}/ManagedSystems

        Args:
            directory_id (int): The unique identifier of the directory.

        Returns:
            list: List of managed systems linked to the directory.
        """
        endpoint = f"{self.endpoint}/{directory_id}/managedsystems"
        utils.print_log(
            self._logger,
            "Calling get_managed_systems_by_directory_id endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)
        return response.json()
