"""Linked Accounts module, managing linked accounts from BeyondInsight API"""

import logging

from cerberus import Validator

from secrets_safe_library import exceptions, utils
from secrets_safe_library.authentication import Authentication
from secrets_safe_library.core import APIObject


class LinkedAccount(APIObject):
    """
    Class to manage linked accounts for managed systems in BeyondInsight API.
    """

    def __init__(self, authentication: Authentication, logger: logging.Logger = None):
        super().__init__(authentication, logger, endpoint="/linkedaccounts")
        self._schema = {
            "managed_system_id": {"type": "integer", "nullable": False, "min": 1},
            "directory_account_id": {"type": "integer", "nullable": False, "min": 1},
        }
        self._validator = Validator(self._schema)

    def list_by_managed_system(self, managed_system_id: int) -> list:
        """
        Returns all linked accounts for a managed system.

        API: GET ManagedSystems/{managedSystemID}/LinkedAccounts

        Args:
            managed_system_id (int): The ID of the managed system.

        Returns:
            list: List of linked accounts.
        """
        if not self._validator.validate({"managed_system_id": managed_system_id}):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        endpoint = f"/managedsystems/{managed_system_id}{self.endpoint}"

        utils.print_log(
            self._logger,
            "Calling list linked accounts by managed system ID endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)

        return response.json()

    def create(self, managed_system_id: int, directory_account_id: int) -> dict:
        """
        Links a directory account to a managed system.

        API: POST ManagedSystems/{managedSystemID}/LinkedAccounts/{directoryAccountID}

        Args:
            managed_system_id (int): The ID of the managed system.
            directory_account_id (int): The ID of the directory account to link.

        Returns:
            dict: The created linked account.
        """
        if not self._validator.validate(
            {
                "managed_system_id": managed_system_id,
                "directory_account_id": directory_account_id,
            }
        ):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        endpoint = (
            f"/managedsystems/{managed_system_id}"
            f"{self.endpoint}/{directory_account_id}"
        )

        utils.print_log(
            self._logger,
            "Calling create linked account endpoint",
            logging.DEBUG,
        )
        response = self._run_post_request(
            endpoint, payload={}, include_api_version=False
        )

        return response.json()

    def delete_all(self, managed_system_id: int) -> None:
        """
        Deletes all linked accounts for a managed system.

        API: DELETE ManagedSystems/{managedSystemID}/LinkedAccounts

        Args:
            managed_system_id (int): The ID of the managed system.
        """
        if not self._validator.validate({"managed_system_id": managed_system_id}):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        endpoint = f"/managedsystems/{managed_system_id}{self.endpoint}"

        utils.print_log(
            self._logger,
            "Calling delete all linked accounts endpoint",
            logging.DEBUG,
        )
        self._run_delete_request(endpoint)

    def delete_single(self, managed_system_id: int, directory_account_id: int) -> None:
        """
        Deletes a single linked account from a managed system.

        API: DELETE ManagedSystems/{managedSystemID}/LinkedAccounts/{directoryAccountID}

        Args:
            managed_system_id (int): The ID of the managed system.
            directory_account_id (int): The ID of the directory account to unlink.
        """
        if not self._validator.validate(
            {
                "managed_system_id": managed_system_id,
                "directory_account_id": directory_account_id,
            }
        ):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        endpoint = (
            f"/managedsystems/{managed_system_id}"
            f"{self.endpoint}/{directory_account_id}"
        )

        utils.print_log(
            self._logger,
            "Calling delete linked account endpoint",
            logging.DEBUG,
        )
        self._run_delete_request(endpoint)
