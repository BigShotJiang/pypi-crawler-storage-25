"""Custom Platforms module, all the logic to manage custom platforms from PS API"""

import logging

from secrets_safe_library import exceptions, utils
from secrets_safe_library.authentication import Authentication
from secrets_safe_library.core import APIObject
from secrets_safe_library.mixins import GetByIdMixin, ListMixin
from secrets_safe_library.validators.base import CustomValidator


class CustomPlatform(APIObject, ListMixin, GetByIdMixin):

    def __init__(self, authentication: Authentication, logger: logging.Logger = None):
        super().__init__(authentication, logger, endpoint="/customplatforms")

        self._platform_id_validator = CustomValidator(
            {"platform_id": {"type": "integer", "min": 1}}
        )

    def export(self, platform_id: int) -> str:
        """
        Exports a custom platform by ID.

        API: GET CustomPlatforms/{id}/Export

        Args:
            platform_id (int): The ID of the custom platform to export.

        Returns:
            str: The raw XML content of the exported custom platform.
        """
        if not self._platform_id_validator.validate(
            {"platform_id": platform_id}, update=True
        ):
            raise exceptions.OptionsError(
                f"Please check: {self._platform_id_validator.errors}"
            )

        endpoint = f"{self.endpoint}/{platform_id}/export"

        utils.print_log(
            self._logger,
            "Calling export endpoint",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)
        return response.text

    def import_platform(self, file_path: str) -> dict:
        """
        Imports a custom platform configuration from an XML file.

        API: POST CustomPlatforms/Import

        Args:
            file_path (str): The path to the XML file to import.

        Returns:
            dict: The API response as a dictionary.

        Raises:
            FileNotFoundError: If the file at file_path does not exist.
            CreationError: If the API returns an error response.
        """
        with open(file_path, "r", encoding="utf-8") as f:
            xml_content = f.read()

        xml_content = (
            xml_content.replace("\r\n", "").replace("\n", "").replace("\r", "")
        )
        payload = {"CustomPlatform": xml_content}
        utils.print_log(
            self._logger,
            "Calling import_platform endpoint",
            logging.DEBUG,
        )
        response = self._run_post_request(
            f"{self.endpoint}/import",
            payload=payload,
            include_api_version=False,
            expected_status_code=200,
        )
        return response.json()
