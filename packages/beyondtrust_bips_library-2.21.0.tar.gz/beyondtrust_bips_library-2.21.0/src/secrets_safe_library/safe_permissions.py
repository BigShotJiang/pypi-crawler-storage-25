"""Safe permissions module, all the logic to manage safe permissions from PS API"""

import logging
from typing import Optional, Tuple

from cerberus import Validator

from secrets_safe_library import exceptions, utils
from secrets_safe_library.authentication import Authentication
from secrets_safe_library.constants.endpoints import (
    DELETE_SECRETS_SAFE_SAFES_ID_SAFE_PERMISSIONS,
    GET_SECRETS_SAFE_SAFES_ID_SAFE_PERMISSIONS,
    GET_SECRETS_SAFE_SAFES_SAFE_PERMISSIONS,
    PUT_SECRETS_SAFE_SAFES_ID_SAFE_PERMISSIONS,
)
from secrets_safe_library.core import APIObject


class SafePermission(APIObject):

    def __init__(self, authentication: Authentication, logger: logging.Logger = None):
        super().__init__(authentication, logger, endpoint="/secrets-safe/safes")

        self._schema = {
            "principal_type": {"type": "integer", "min": 0, "max": 1},
            "principal_id": {"type": "integer", "min": 1},
        }
        self._validator = Validator(self._schema)

    def _build_endpoint(self, endpoint_constant: str, **kwargs) -> str:
        """Build an endpoint path from a constant, replacing placeholders."""
        _, path = endpoint_constant.split(":", 1)
        for key, value in kwargs.items():
            path = path.replace(f"{{{key}}}", str(value))
        return f"/{path}"

    def list_safe_permissions(self) -> list:
        """
        Returns all available safe permission types.

        API: GET secrets-safe/safes/safe-permissions

        Returns:
            list: List of available safe permission types.
        """
        endpoint = self._build_endpoint(GET_SECRETS_SAFE_SAFES_SAFE_PERMISSIONS)
        utils.print_log(
            self._logger, "Calling list_safe_permissions endpoint", logging.DEBUG
        )
        response = self._run_get_request(endpoint, include_api_version=False)
        return response.json()

    def get_safe_permissions(self, safe_id: str) -> list:
        """
        Returns permissions assigned to a specific safe.

        API: GET secrets-safe/safes/{id}/safe-permissions

        Args:
            safe_id (str): The safe ID (GUID).

        Returns:
            list: List of permissions for the safe.
        """
        endpoint = self._build_endpoint(
            GET_SECRETS_SAFE_SAFES_ID_SAFE_PERMISSIONS, ID=safe_id
        )
        utils.print_log(
            self._logger,
            f"Calling get_safe_permissions endpoint for safe {safe_id}",
            logging.DEBUG,
        )
        response = self._run_get_request(endpoint, include_api_version=False)
        return response.json()

    def update_safe_permissions(
        self,
        safe_id: str,
        principal_type: int,
        principal_id: int,
        permission_flags: Optional[list] = None,
        expires_on: Optional[str] = None,
    ) -> Tuple[str, int]:
        """
        Assigns or updates permissions for a principal on a safe.

        API: PUT secrets-safe/safes/{id}/safe-permissions

        Args:
            safe_id (str): The safe ID (GUID).
            principal_type (int): 0 for user, 1 for group.
            principal_id (int): ID of the user or group.
            permission_flags (list, optional): Permissions to assign.
            expires_on (str, optional): Expiry datetime for the permissions (ISO 8601).

        Returns:
            Tuple[str, int]: Tuple containing raw response text and status code.
        """
        attributes = {
            "principal_type": principal_type,
            "principal_id": principal_id,
        }

        if not self._validator.validate(attributes):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        payload = {
            "PrincipalType": principal_type,
            "PrincipalID": principal_id,
        }
        if permission_flags is not None:
            payload["PermissionFlags"] = permission_flags
        if expires_on is not None:
            payload["ExpiresOn"] = expires_on

        endpoint = self._build_endpoint(
            PUT_SECRETS_SAFE_SAFES_ID_SAFE_PERMISSIONS, ID=safe_id
        )
        utils.print_log(
            self._logger, "Calling update_safe_permissions endpoint", logging.DEBUG
        )
        response = self._run_put_request(
            endpoint,
            payload,
            include_api_version=False,
            expected_status_code=[204],
        )
        return response.text, response.status_code

    def delete_safe_permissions(
        self,
        safe_id: str,
        principal_type: int,
        principal_id: int,
    ) -> Tuple[str, int]:
        """
        Revokes permissions for a principal on a safe.

        API: DELETE secrets-safe/safes/{id}/safe-permissions

        Args:
            safe_id (str): The safe ID (GUID).
            principal_type (int): 0 for user, 1 for group.
            principal_id (int): ID of the user or group.

        Returns:
            Tuple[str, int]: Tuple containing raw response text and status code.
        """
        attributes = {
            "principal_type": principal_type,
            "principal_id": principal_id,
        }

        if not self._validator.validate(attributes):
            raise exceptions.OptionsError(f"Please check: {self._validator.errors}")

        payload = {
            "PrincipalType": principal_type,
            "PrincipalID": principal_id,
        }
        endpoint = self._build_endpoint(
            DELETE_SECRETS_SAFE_SAFES_ID_SAFE_PERMISSIONS, ID=safe_id
        )

        utils.print_log(
            self._logger, "Calling delete_safe_permissions endpoint", logging.DEBUG
        )
        response = self._run_delete_request(
            endpoint, expected_status_code=204, payload=payload
        )
        return response.text, response.status_code
