"""nogit snapshot — crée un ZIP du dossier courant."""

import json
import sys
import zipfile
import os
from datetime import datetime
from pathlib import Path

from nogit.utils import MAX_FILE_SIZE, is_binary, md5_file, register_project, update_registry_snapshots, get_project_mode, copy_to_external
from nogit.ignore import ensure_nogitignore, load_patterns, is_ignored

NOGIT_META = "nogit.meta.json"


def _write_zip_meta(zf: zipfile.ZipFile, type_: str):
    zf.writestr(NOGIT_META, json.dumps({"type": type_}, indent=2))


def _scan_files(project_root: Path, dir_patterns, file_patterns) -> tuple[list[Path], bool]:
    """Scanne les fichiers à inclure. Retourne (fichiers, depth_exceeded).

    - Dossier dangereux (racine/niv1/niv2) : scan limité à 1 niveau de profondeur.
    - Dossier normal : scan jusqu'à 3 niveaux pour l'aperçu de confirmation.
    """
    collected = []
    depth_exceeded = False
    is_dangerous_path = len(project_root.parts) <= 3
    max_depth = 1 if is_dangerous_path else 3

    for root, dirs, files in os.walk(project_root):
        root_path = Path(root)
        depth = len(root_path.relative_to(project_root).parts)
        if depth > max_depth:
            depth_exceeded = True
            dirs[:] = []
            continue

        dirs[:] = [
            d for d in dirs
            if not is_ignored(root_path / d, project_root, dir_patterns, file_patterns)
        ]
        for filename in files:
            file_path = root_path / filename
            if is_ignored(file_path, project_root, dir_patterns, file_patterns):
                continue
            try:
                file_path.stat()
                collected.append(file_path)
            except OSError:
                continue

    return collected, depth_exceeded


_FORBIDDEN_PATHS = {
    # Linux
    "/tmp", "/var/tmp", "/root", "/home", "/etc", "/usr", "/bin", "/sbin",
    # macOS
    "/private/tmp", "/private/var", "/Library", "/System", "/Applications", "/Users",
    # Windows
    "C:\\Windows", "C:\\Program Files", "C:\\Program Files (x86)", "C:\\Users",
}

_FORBIDDEN_ENV_VARS = ("USERPROFILE", "APPDATA", "LOCALAPPDATA", "TEMP", "TMP", "PROGRAMDATA")


def _is_forbidden_path(project_root: Path) -> bool:
    p = str(project_root).rstrip("/\\")
    if p in _FORBIDDEN_PATHS:
        return True
    for var in _FORBIDDEN_ENV_VARS:
        val = os.environ.get(var)
        if val and Path(p) == Path(val):
            return True
    return False


def _confirm_snapshot(project_root: Path, files: list[Path], depth_exceeded: bool, force: bool = False) -> bool:
    """Affiche un résumé et demande confirmation si le projet semble dangereux."""
    n = len(files)
    parts = project_root.parts
    forbidden = _is_forbidden_path(project_root)

    if forbidden:
        print(f"[nogit] ERREUR : '{project_root}' est un dossier système — nogit ne peut pas être utilisé ici.")
        return False

    is_dangerous = (
        n > 500
        or len(parts) <= 3
        or depth_exceeded
    )

    if not is_dangerous:
        return True

    print(f"[nogit] Dossier : {project_root}")
    print(f"[nogit] {n} fichiers détectés à inclure dans le snapshot.")
    if len(parts) <= 3:
        print("[nogit] ATTENTION : vous êtes dans un dossier système ou très haut dans l'arborescence.")
    if depth_exceeded:
        print("[nogit] ATTENTION : arborescence tronquée — scan limité par sécurité.")

    preview = files[:20]
    for f in preview:
        try:
            rel = f.relative_to(project_root)
        except ValueError:
            rel = f
        print(f"  {rel}")
    if n > 20:
        print(f"  ... et {n - 20} autres fichiers.")

    if force:
        return True

    if not sys.stdin.isatty():
        print("[nogit] Entrée non interactive — relancez avec 'nogit snapshot --yes' pour confirmer.")
        return False

    answer = input("\nContinuer ? [o/N] ").strip().lower()
    return answer in ("o", "oui", "y", "yes")


def run_full(project_root: Path):
    """Full snapshot sans vérification du mode — utilisé par le watcher au démarrage."""
    nogit_dir = project_root / ".nogit" / "snapshots"
    nogit_dir.mkdir(parents=True, exist_ok=True)

    ensure_nogitignore(project_root)
    dir_patterns, file_patterns = load_patterns(project_root)

    timestamp = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
    zip_path = nogit_dir / f"{timestamp}.zip"

    register_project(project_root)

    stats = {"included": 0, "meta": 0, "skipped": 0}

    print(f"[nogit] Snapshot initial → {zip_path.name}")

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        _write_zip_meta(zf, "full")
        for root, dirs, files in os.walk(project_root):
            root_path = Path(root)
            dirs[:] = [
                d for d in dirs
                if not is_ignored(root_path / d, project_root, dir_patterns, file_patterns)
            ]
            for filename in files:
                file_path = root_path / filename
                if is_ignored(file_path, project_root, dir_patterns, file_patterns):
                    stats["skipped"] += 1
                    continue
                relative = file_path.relative_to(project_root)
                try:
                    size = file_path.stat().st_size
                except OSError:
                    stats["skipped"] += 1
                    continue
                if size > MAX_FILE_SIZE or is_binary(file_path):
                    try:
                        mtime = file_path.stat().st_mtime
                    except OSError:
                        stats["skipped"] += 1
                        continue
                    meta = {
                        "path": str(relative).replace("\\", "/"),
                        "size_bytes": size,
                        "modified_at": datetime.fromtimestamp(mtime).isoformat(timespec="seconds"),
                        "md5": md5_file(file_path),
                    }
                    zf.writestr(str(relative).replace("\\", "/") + ".meta.json", json.dumps(meta, indent=2))
                    stats["meta"] += 1
                else:
                    zf.write(file_path, relative)
                    stats["included"] += 1

    update_registry_snapshots(project_root)
    copy_to_external(project_root, zip_path)

    total = stats["included"] + stats["meta"] + stats["skipped"]
    size_mb = zip_path.stat().st_size / (1024 * 1024)
    print(f"[nogit] ✓ {zip_path.name}")
    print(f"        {stats['included']} fichiers inclus, {stats['meta']} méta, {stats['skipped']} ignorés ({total} total)")
    print(f"        Taille ZIP : {size_mb:.2f} MB")


def run(force: bool = False):
    project_root = Path.cwd()

    mode, _ = get_project_mode(project_root)
    if mode == "auto":
        print("[nogit] Ce projet est en mode automatique — utilisez le watcher pour les snapshots.")
        print("        Faites 'nogit manual' pour repasser en mode manuel.")
        return

    ensure_nogitignore(project_root)
    dir_patterns, file_patterns = load_patterns(project_root)

    files, depth_exceeded = _scan_files(project_root, dir_patterns, file_patterns)
    if not _confirm_snapshot(project_root, files, depth_exceeded, force=force):
        print("[nogit] Snapshot annulé.")
        return

    nogit_dir = project_root / ".nogit" / "snapshots"
    nogit_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
    zip_path = nogit_dir / f"{timestamp}.zip"

    register_project(project_root)

    stats = {"included": 0, "meta": 0, "skipped": 0}

    print(f"[nogit] Snapshot en cours → {zip_path.name}")

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        _write_zip_meta(zf, "full")
        for root, dirs, files_in_dir in os.walk(project_root):
            root_path = Path(root)
            dirs[:] = [
                d for d in dirs
                if not is_ignored(root_path / d, project_root, dir_patterns, file_patterns)
            ]
            for filename in files_in_dir:
                file_path = root_path / filename
                if is_ignored(file_path, project_root, dir_patterns, file_patterns):
                    stats["skipped"] += 1
                    continue
                relative = file_path.relative_to(project_root)
                try:
                    size = file_path.stat().st_size
                except OSError:
                    stats["skipped"] += 1
                    continue
                if size > MAX_FILE_SIZE or is_binary(file_path):
                    try:
                        mtime = file_path.stat().st_mtime
                    except OSError:
                        stats["skipped"] += 1
                        continue
                    meta = {
                        "path": str(relative).replace("\\", "/"),
                        "size_bytes": size,
                        "modified_at": datetime.fromtimestamp(mtime).isoformat(timespec="seconds"),
                        "md5": md5_file(file_path),
                    }
                    zf.writestr(str(relative).replace("\\", "/") + ".meta.json", json.dumps(meta, indent=2))
                    stats["meta"] += 1
                else:
                    zf.write(file_path, relative)
                    stats["included"] += 1

    update_registry_snapshots(project_root)
    copy_to_external(project_root, zip_path)

    total = stats["included"] + stats["meta"] + stats["skipped"]
    size_mb = zip_path.stat().st_size / (1024 * 1024)
    print(f"[nogit] ✓ {zip_path.name}")
    print(f"        {stats['included']} fichiers inclus, {stats['meta']} méta, {stats['skipped']} ignorés ({total} total)")
    print(f"        Taille ZIP : {size_mb:.2f} MB")


def run_incremental(project_root: Path, changed_paths: set[str]):
    """Snapshot incrémental — seuls les fichiers modifiés sont inclus."""
    nogit_dir = project_root / ".nogit" / "snapshots"
    nogit_dir.mkdir(parents=True, exist_ok=True)

    ensure_nogitignore(project_root)
    dir_patterns, file_patterns = load_patterns(project_root)

    timestamp = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
    zip_path = nogit_dir / f"{timestamp}.zip"

    register_project(project_root)

    stats = {"included": 0, "meta": 0, "skipped": 0}

    print(f"[nogit] Snapshot incrémental → {zip_path.name}")

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        _write_zip_meta(zf, "incremental")
        for file_path_str in changed_paths:
            file_path = Path(file_path_str)

            if not file_path.exists():
                continue

            if is_ignored(file_path, project_root, dir_patterns, file_patterns):
                stats["skipped"] += 1
                continue

            relative = file_path.relative_to(project_root)
            rel_str = str(relative).replace("\\", "/")

            try:
                size = file_path.stat().st_size
            except OSError:
                stats["skipped"] += 1
                continue

            if size > MAX_FILE_SIZE or is_binary(file_path):
                meta = {
                    "path": rel_str,
                    "size_bytes": size,
                    "modified_at": datetime.fromtimestamp(
                        file_path.stat().st_mtime
                    ).isoformat(timespec="seconds"),
                    "md5": md5_file(file_path),
                }
                zf.writestr(rel_str + ".meta.json", json.dumps(meta, indent=2))
                stats["meta"] += 1
            else:
                zf.write(file_path, relative)
                stats["included"] += 1

    update_registry_snapshots(project_root)
    copy_to_external(project_root, zip_path)

    total = stats["included"] + stats["meta"] + stats["skipped"]
    size_mb = zip_path.stat().st_size / (1024 * 1024)
    print(f"[nogit] ✓ {zip_path.name}")
    print(f"        {stats['included']} modifié(s), {stats['meta']} méta, {stats['skipped']} ignorés ({total} total)")
    print(f"        Taille ZIP : {size_mb:.2f} MB")
