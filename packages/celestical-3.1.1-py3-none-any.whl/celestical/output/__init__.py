"""Output module for CLI display."""
from celestical.output.types import Result, Theme, OutputProtocol
from celestical.output.console import ConsoleOutput, get_output, set_output

__all__ = [
    "Result",
    "Theme", 
    "OutputProtocol",
    "ConsoleOutput",
    "get_output",
    "set_output",
]
