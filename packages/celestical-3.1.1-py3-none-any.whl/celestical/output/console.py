"""Rich-based console output implementation."""
import sys
from contextlib import contextmanager
from typing import Generator, Optional

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.prompt import Confirm, Prompt
from rich.table import Table

from celestical.output.types import Theme


class ConsoleOutput:
    """Rich-based console output implementation.
    
    Provides a unified interface for all CLI output operations with support
    for quiet mode, verbose mode, progress indicators, and styled output.
    """

    def __init__(self, quiet: bool = False, verbose: bool = False):
        """Initialize the ConsoleOutput instance.
        
        Args:
            quiet: If True, suppress non-essential output
            verbose: If True, enable debug/verbose output
        """
        self._quiet = quiet
        self._verbose = verbose
        self._console = Console()

    @property
    def quiet(self) -> bool:
        """Whether the output is in quiet mode."""
        return self._quiet

    @property
    def verbose(self) -> bool:
        """Whether the output is in verbose mode."""
        return self._verbose

    def _should_print(self, level: str = "info") -> bool:
        """Determine if output should be printed based on mode.
        
        Args:
            level: The log level ("info", "debug", "error", etc.)
        
        Returns:
            True if the output should be printed, False otherwise
        """
        if self._quiet:
            return level in ("error",)
        if level == "debug":
            return self._verbose
        return True

    def success(self, msg: str) -> None:
        """Print a success message with a checkmark prefix.
        
        Args:
            msg: The message to display
        """
        if not self._should_print():
            return
        self._console.print(f"[{Theme.SUCCESS}]✓[/{Theme.SUCCESS}] {msg}")

    def error(self, msg: str, exit_code: int = 1) -> None:
        """Print an error message and optionally exit.
        
        Args:
            msg: The error message to display
            exit_code: If > 0, exit the program with this code (default: 1)
        """
        self._console.print(f"[{Theme.ERROR}]✗[/{Theme.ERROR}] {msg}")
        if exit_code > 0:
            sys.exit(exit_code)

    def info(self, msg: str) -> None:
        """Print an informational message with an info prefix.
        
        Args:
            msg: The message to display
        """
        if not self._should_print():
            return
        self._console.print(f"[{Theme.INFO}]ℹ[/{Theme.INFO}] {msg}")

    def warning(self, msg: str) -> None:
        """Print a warning message with an exclamation prefix.
        
        Args:
            msg: The warning message to display
        """
        if not self._should_print():
            return
        self._console.print(f"[{Theme.WARNING}]![/{Theme.WARNING}] {msg}")

    def debug(self, msg: str) -> None:
        """Print a debug message (only visible in verbose mode).
        
        Args:
            msg: The debug message to display
        """
        if not self._should_print("debug"):
            return
        self._console.print(f"[{Theme.DIM}]⚙ {msg}[/{Theme.DIM}]")

    def table(self, data: list[dict], columns: Optional[list[str]] = None,
              title: Optional[str] = None) -> None:
        """Display data in a formatted table.
        
        Args:
            data: List of dictionaries, each representing a row
            columns: Optional list of column names to display (default: all keys)
            title: Optional table title
        """
        if not self._should_print():
            return
        if not data:
            self.info("No data to display")
            return

        table = Table(title=title, show_header=True, header_style=Theme.TABLE_HEADER)
        
        cols = columns or list(data[0].keys())
        for col in cols:
            table.add_column(col)

        for row in data:
            table.add_row(*[str(row.get(col, "")) for col in cols])

        self._console.print(table)

    def panel(self, msg: str, title: str = "Celestical",
              kind: str = "info") -> None:
        """Display a message in a bordered panel.
        
        Args:
            msg: The message to display in the panel
            title: The panel title (default: "Celestical")
            kind: Panel style - "info", "error", or "success"
        """
        if not self._should_print():
            return
        
        style = Theme.PANEL_INFO
        if kind == "error":
            style = Theme.PANEL_ERROR
        elif kind == "success":
            style = Theme.PANEL_SUCCESS

        panel = Panel(
            msg,
            title=f"[bold]{title}[/bold]",
            border_style=style,
            expand=True,
            title_align="left"
        )
        self._console.print(panel)

    @contextmanager
    def progress(self, description: str = "Processing") -> Generator[None, None, None]:
        """Display a progress spinner while an operation runs.
        
        Args:
            description: The description text to show next to the spinner
        
        Yields:
            None - use as a context manager
        
        Example:
            with output.progress("Uploading..."):
                upload_files()
        """
        if self._quiet:
            yield
            return

        progress_bar = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            transient=True,
            console=self._console
        )
        
        with progress_bar:
            task = progress_bar.add_task(description, total=None)
            try:
                yield
            finally:
                progress_bar.update(task, completed=True)

    def confirm(self, prompt: str, default: bool = False) -> bool:
        """Ask for user confirmation with a yes/no prompt.
        
        Args:
            prompt: The question to ask the user
            default: The default value if user just presses Enter
        
        Returns:
            True if user confirms, False otherwise
        """
        if self._quiet:
            return default
        return Confirm.ask(prompt, default=default)

    def prompt(self, prompt: str, default: Optional[str] = None,
               helptxt: str = "") -> str:
        """Prompt the user for text input.
        
        Args:
            prompt: The prompt message to display
            default: Optional default value
            helptxt: Optional help text (shown in parentheses, or type ? for full help)
        
        Returns:
            The user's input as a string
        """
        if self._quiet:
            return default or ""
        
        more_help = ""
        if helptxt:
            if len(helptxt) <= 30:
                more_help = f" [{Theme.MUTED}]({helptxt})[/{Theme.MUTED}]"
            else:
                more_help = f" [{Theme.MUTED}](type ? for help)[/{Theme.MUTED}]"

        result = Prompt.ask(
            f"[{Theme.HIGHLIGHT}]>>>[/{Theme.HIGHLIGHT}] {prompt}{more_help}",
            default=default
        )

        if result == "?" and helptxt:
            self.info(helptxt)
            return self.prompt(prompt, default, helptxt)

        return result or ""

    def print(self, msg: str) -> None:
        """Print a raw message without any formatting or prefix.
        
        Args:
            msg: The message to print
        """
        if not self._should_print():
            return
        self._console.print(msg)

    def space(self, rows: int = 1) -> None:
        """Print blank lines for visual spacing.
        
        Args:
            rows: Number of blank lines to print (default: 1)
        """
        if not self._should_print():
            return
        if rows > 0:
            self._console.print("\n" * (rows - 1))


_global_output: Optional[ConsoleOutput] = None


def get_output(quiet: bool = False, verbose: bool = False) -> ConsoleOutput:
    """Get the global output instance, creating it if necessary.
    
    Args:
        quiet: Whether to suppress non-essential output
        verbose: Whether to enable verbose/debug output
    
    Returns:
        The global ConsoleOutput instance
    """
    global _global_output
    if _global_output is None:
        _global_output = ConsoleOutput(quiet=quiet, verbose=verbose)
    return _global_output


def set_output(output: ConsoleOutput) -> None:
    """Set the global output instance.
    
    Args:
        output: The ConsoleOutput instance to use globally
    """
    global _global_output
    _global_output = output
