"""Output types and protocols for the CLI."""
from contextlib import AbstractContextManager
from dataclasses import dataclass
from typing import Any, Generic, Optional, Protocol, TypeVar

T = TypeVar('T')


@dataclass
class Result(Generic[T]):
    """A result object for operations that can succeed or fail.
    
    Attributes:
        success: Whether the operation succeeded
        data: The data returned by the operation (if successful)
        message: A human-readable message
        error_code: An optional error code for programmatic handling
    """
    success: bool
    data: Optional[T] = None
    message: str = ""
    error_code: Optional[str] = None

    @classmethod
    def ok(cls, data: Optional[T] = None, message: str = "") -> "Result[T]":
        """Create a successful result.
        
        Parameters:
            data: The data to include in the result
            message: A human-readable success message
        
        Returns:
            A Result instance with success=True
        """
        return cls(success=True, data=data, message=message)

    @classmethod
    def fail(cls, message: str, error_code: Optional[str] = None, 
             data: Optional[T] = None) -> "Result[T]":
        """ Create a failed result.
        
        Parameters:
            message: A human-readable error message
            error_code: An optional error code for programmatic handling
            data: Optional data to include despite the failure
        
        Returns:
            A Result instance with success=False
        """
        return cls(success=False, message=message, error_code=error_code, data=data)

    def __bool__(self) -> bool:
        """ Allow using Result in boolean context (True if successful).
        """
        return self.success


class Theme:
    """Centralized theme constants for consistent styling."""
    
    SUCCESS = "green"
    ERROR = "red"
    WARNING = "orange"
    INFO = "blue"
    HIGHLIGHT = "yellow"
    DIM = "dim"
    MUTED = "grey50"
    
    PANEL_INFO = "purple"
    PANEL_ERROR = "red"
    PANEL_SUCCESS = "green"
    
    TABLE_HEADER = "bold blue"
    TABLE_ROW_ALT = "dim"
    
    PROGRESS_SPINNER = "dots"
    PROGRESS_BAR = "bar.back"
    
    @classmethod
    def style(cls, text: str, style: str) -> str:
        """Apply a style to text for Rich rendering.
        
        Parameters:
            text: The text to style
            style: The Rich style to apply (e.g., "bold red")
        
        Returns:
            The styled text string
        """
        return f"[{style}]{text}[/{style}]"


class OutputProtocol(Protocol):
    """ Protocol defining the output interface for CLI commands.
    
    This allows different output implementations (console, JSON, quiet, etc.)
    to be used interchangeably.
    """

    @property
    def quiet(self) -> bool:
        """Whether the output is in quiet mode."""
        ...

    @property
    def verbose(self) -> bool:
        """Whether the output is in verbose mode."""
        ...

    def success(self, msg: str) -> None:
        """Print a success message."""
        ...

    def error(self, msg: str, exit_code: int = 1) -> None:
        """Print an error message and optionally exit."""
        ...

    def info(self, msg: str) -> None:
        """Print an informational message."""
        ...

    def warning(self, msg: str) -> None:
        """Print a warning message."""
        ...

    def debug(self, msg: str) -> None:
        """Print a debug message (only in verbose mode)."""
        ...

    def table(self, data: list[dict], columns: Optional[list[str]] = None, 
              title: Optional[str] = None) -> None:
        """Display data in a table format."""
        ...

    def panel(self, msg: str, title: str = "Celestical", 
              kind: str = "info") -> None:
        """Display a message in a panel."""
        ...

    def progress(self, description: str = "Processing") -> AbstractContextManager:
        """Display a progress indicator."""
        ...

    def confirm(self, prompt: str, default: bool = False) -> bool:
        """Ask for user confirmation."""
        ...

    def prompt(self, prompt: str, default: Optional[str] = None, 
               helptxt: str = "") -> str:
        """Prompt the user for input."""
        ...

    def print(self, msg: str) -> None:
        """Print a raw message without formatting."""
        ...

    def space(self, rows: int = 1) -> None:
        """Print blank lines."""
        ...
