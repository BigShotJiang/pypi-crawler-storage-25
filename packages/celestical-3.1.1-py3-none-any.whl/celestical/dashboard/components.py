"""UI components for the dashboard layout."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from textual.message import Message
from textual.reactive import reactive
from textual.widgets import DataTable, Input, Static
from rich.text import Text
from rich.table import Table

from celestical.dashboard.data_service import AppSummary


class LeftPanel0(Static):
    """The larger (3/4) left column displaying Celestical apps."""

    class AppSelected(Message):
        """Message emitted when a row is highlighted."""

        def __init__(self, sender: "LeftPanel0", summary: AppSummary) -> None:
            super().__init__()
            self.sender = sender
            self.summary = summary

    summaries: List[AppSummary] = reactive([])
    status_message: str = reactive("Loading Celestical apps...")

    def compose(self):
        yield Static("Celestical Apps", classes="panel-title")
        yield Static("", classes="spacer")
        yield DataTable(id="apps-table", zebra_stripes=True)

    def on_mount(self) -> None:
        try:
            self.table = self.query_one(DataTable)
            self.table.cursor_type = "row"
            self.table.add_column("#", width=3)
            self.table.add_column("Name", width=20)
            self.table.add_column("UUID", width=36)  # Full UUID width
            self.table.add_column("Domain", width=20)
            self.table.add_column("Status", width=10)
            self._summary_by_key: Dict[str, AppSummary] = {}
            self._render_apps()
            self.table.refresh()
            self.refresh()
            try:
                self.table.focus()
            except:
                try:
                    self.focus()
                except:
                    pass
        except Exception as e:
            try:
                error_widget = self.query_one("#apps-table", DataTable)
                error_widget.add_row("ERROR", f"Failed to initialize: {e}", "", "", "")
                error_widget.refresh()
            except:
                pass
            self.refresh()

    def update_apps(self, summaries: List[AppSummary], status: str) -> None:
        self.summaries = summaries
        if summaries:
            self.status_message = status or f"Found {len(summaries)} app(s)."
        else:
            self.status_message = status or "No apps available."
        self._render_apps()

    def _render_apps(self) -> None:
        self.table.clear()
        self._summary_by_key = {}
        if not self.summaries:
            self.table.add_row("–", self.status_message, "", "", "", key="empty")
            self.table.cursor_type = "none"
            return

        self.table.cursor_type = "row"
        for summary in self.summaries:
            self._summary_by_key[summary.index_label] = summary
            self.table.add_row(
                summary.index_label,
                summary.name,
                summary.uuid_display,
                summary.domain,
                summary.status_markup,
                key=summary.index_label,
            )

    def move_cursor(self, delta: int) -> None:
        if not self.summaries:
            return
        row, column = self.table.cursor_coordinate
        new_row = min(max(row + delta, 0), len(self.summaries) - 1)
        self.table.cursor_coordinate = (new_row, column)
        # Manually trigger selection update
        self._trigger_selection(new_row)

    def select_row(self, index: int) -> None:
        if not self.summaries:
            return
        index = min(max(index, 0), len(self.summaries) - 1)
        self.table.cursor_coordinate = (index, 0)
        # Manually trigger selection update
        self._trigger_selection(index)

    def _trigger_selection(self, row_index: int) -> None:
        """Manually trigger AppSelected message for a given row index."""
        if 0 <= row_index < len(self.summaries):
            summary = self.summaries[row_index]
            self.post_message(self.AppSelected(self, summary))

    def on_data_table_row_highlighted(
        self, event: DataTable.RowHighlighted
    ) -> None:
        # Try to get summary by row key first
        summary = self._summary_by_key.get(event.row_key)
        # If not found, try to get by current cursor position
        if not summary:
            row, _ = self.table.cursor_coordinate
            if 0 <= row < len(self.summaries):
                summary = self.summaries[row]
        if summary:
            self.post_message(self.AppSelected(self, summary))


class DynamicStatic(Static):
    """A Static widget that properly updates when content changes."""

    content_text = reactive("")

    def watch_content_text(self, text: str) -> None:
        """Update content when reactive variable changes."""
        self.update(text)
        self.refresh()


class RightPanel(Static):
    """The smaller (1/4) right column."""

    detail_content = reactive("")
    usage_content = reactive("")

    def compose(self):
        yield DynamicStatic("", id="selected-info")
        yield DynamicStatic("", id="usage-info")
        yield Static("", id="help-info")

    def on_mount(self) -> None:
        self.selected_info = self.query_one("#selected-info", DynamicStatic)
        self.usage_info = self.query_one("#usage-info", DynamicStatic)
        self.help_info = self.query_one("#help-info", Static)
        self.update_help_text()
        self.update_details(None, None)
        self.refresh()
        self.help_info.refresh()

    def watch_detail_content(self, content: str) -> None:
        """Watch for changes to detail content."""
        if hasattr(self, 'selected_info') and self.selected_info:
            self.selected_info.content_text = content

    def watch_usage_content(self, content: str) -> None:
        """Watch for changes to usage content."""
        if hasattr(self, 'usage_info') and self.usage_info:
            self.usage_info.content_text = content

    def update_details(
        self, summary: Optional[AppSummary], usage_data: Optional[Dict[str, int]], app_id: Optional[str] = None
    ) -> None:
        if not summary:
            detail_text = "[red]No app selected[/red]"
            usage_text = "[dim]Usage data unavailable[/dim]"
        else:
            # Extract data from raw_app - handle both dict and object
            raw = summary.raw_app

            # Use provided app_id if available, otherwise extract from raw_app
            if app_id and app_id != "unknown":
                uuid_full = str(app_id)
            elif isinstance(raw, dict):
                uuid_full = str(raw.get("id", "—") or "—")
            else:
                uuid_full = str(getattr(raw, "id", "—") or "—")

            # If still no UUID, try fallbacks
            if uuid_full == "—" or not uuid_full or uuid_full == "unknown":
                # Try to get from summary's uuid_display (first 12 chars + ...)
                uuid_display = summary.uuid_display
                if uuid_display and uuid_display != "—":
                    # Try to extract full UUID from raw_app
                    from celestical.dashboard.data_service import _app_value
                    uuid_full = _app_value(raw, "id", uuid_display)
                    if uuid_full:
                        uuid_full = str(uuid_full)
                    else:
                        uuid_full = uuid_display

            domain = summary.domain or summary.name or "N/A"

            detail_lines = [
                "[bold white]App Details[/bold white]",
                "─" * 25,
                f"UUID: {uuid_full}",
                f"Domain: {domain}",
                f"Status: {summary.status_markup}",
            ]
            detail_text = "\n".join(detail_lines)
            detail_text += f"\n[dim]{uuid_full}[/dim]"

            usage = usage_data or {}
            usage_lines = [
                "[bold white]Resource Usage[/bold white]",
                "─" * 25,
                f"CPU: {usage.get('cpu', 0)} vCPU",
                f"Memory: {usage.get('memory', 0)} GB",
                f"Storage: {usage.get('storage', 0)} GB",
                f"In Network: {usage.get('in_network', 0)} MB",
                f"Out Network: {usage.get('out_network', 0)} MB",
                f"Energy: {usage.get('energy', 0)} units",
            ]
            usage_text = "\n".join(usage_lines)

        self._force_update_widgets(detail_text, usage_text)

    def _force_update_widgets(self, detail_text: str, usage_text: str) -> None:
        """Force update widgets with new content."""
        # Directly update the DynamicStatic widgets - this is the most reliable way
        if hasattr(self, 'selected_info') and self.selected_info:
            # Set the reactive content_text which will trigger watch_content_text
            self.selected_info.content_text = detail_text
            # Also call update directly as fallback
            self.selected_info.update(detail_text)
            self.selected_info.refresh()

        if hasattr(self, 'usage_info') and self.usage_info:
            # Set the reactive content_text which will trigger watch_content_text
            self.usage_info.content_text = usage_text
            # Also call update directly as fallback
            self.usage_info.update(usage_text)
            self.usage_info.refresh()

        # Update reactive variables on RightPanel (triggers watch methods as backup)
        self.detail_content = detail_text
        self.usage_content = usage_text

    def update_help_text(self) -> None:
        help_text = "\n".join(
            [
                "[bold white]Controls[/bold white]",
                "─" * 25,
                "↑/↓ or j/k : Navigate apps",
                "r          : Refresh data",
                "s          : Stop selected app",
                "e          : Enter app index",
                "h          : Help",
                "q          : Quit",
            ]
        )
        self.help_info.update(help_text)


class CustomHeader(Static):
    """Custom header showing title, version, and user info."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__("Celestical Dashboard", *args, **kwargs)
        self.version_info = "Version: loading..."
        self.user_info = "Loading..."

    def update_header_info(self, version: str, user_email: str) -> None:
        """Update header with version and user information."""
        self.version_info = f"Version: {version}"
        self.user_info = f"Logged in as: {user_email}"
        self._render_header()

    def on_mount(self) -> None:
        """Render header when mounted."""
        self._render_header()
    
    def _render_header(self) -> None:
        """Render header with proper spacing like the old dashboard."""
        try:
            # Create a table with two columns for proper alignment
            table = Table.grid(expand=True)
            table.add_column(justify="left")
            table.add_column(justify="right")

            # First row: Title and Version
            title_text = Text("Celestical Dashboard", style="bold white")
            version_text = Text(self.version_info, style="green")
            table.add_row(title_text, version_text)

            # Second row: Empty left, User info right
            empty_text = Text("")
            user_text = Text(self.user_info, style="blue")
            table.add_row(empty_text, user_text)

            self.update(table)
            self.refresh()
        except Exception as e:
            # Fallback to simple text if table rendering fails
            self.update(f"Celestical Dashboard | {self.version_info} | {self.user_info}")
            self.refresh()


class QuitAwareInput(Input):
    """Input widget that allows quit keys to work even when focused."""
    
    def on_key(self, event) -> None:
        """Handle key events to allow quit even when input is focused."""
        if event.key == "q" or event.key == "Q" or event.key == "escape":
            event.prevent_default()
            event.stop()
            self.app.action_quit()
            return
        # For other keys, let Input handle them normally
        # Don't call super().on_key() as Input doesn't have that method


class AppIndexInput(Static):
    """Input widget for entering app index numbers."""

    def compose(self):
        yield Static("Enter app index (press 'e' to focus): ", id="input-label")
        yield QuitAwareInput(placeholder="Press 'e' then type app number and press Enter", id="app-index-input")

    def on_mount(self) -> None:
        self.input_widget = self.query_one("#app-index-input", QuitAwareInput)


class CustomFooter(Static):
    """Custom footer showing controls and current status."""

    controls_text = "↑/↓ navigate · r refresh · s stop · h help · e enter index · q quit"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self.status_message = "Ready."
        initial_content = f"{self.controls_text} | {self.status_message}"
        super().__init__(initial_content, *args, **kwargs)

    def set_status(self, message: str) -> None:
        self.status_message = message
        content = f"{self.controls_text} | {self.status_message}"
        self.update(content)
