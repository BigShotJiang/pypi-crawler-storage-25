"""Dashboard layout and main application."""

from typing import Optional

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container
from textual.widgets import Input

from celestical.utils.version_check import get_version
from celestical.dashboard.data_service import DashboardDataService, _app_value
from celestical.dashboard.handlers import DashboardEventHandler
from celestical.dashboard.components import (
    LeftPanel0, RightPanel, CustomHeader, AppIndexInput, CustomFooter
)


class Dashboard(App):
    """A simple Textual dashboard layout."""

    # Textual App defined member
    CSS = """
    Screen { layout: vertical; }
    CustomHeader { dock: top; height: 3; }
    AppIndexInput { dock: bottom; height: 3; }
    CustomFooter { dock: bottom; height: 1; }

    .body { layout: horizontal; height: 100%; }

    LeftPanel0 {
        background: rgb(90,190,150);
        width: 3fr;           /* 3 parts of total */
        height: 100%;
        padding: 1;
    }

    RightPanel {
        background: rgb(150,100,50);
        width: 1fr;           /* 1 part of total */
        height: 100%;
        padding: 1;
    }

    .panel-title {
        content-align: center middle;
        color: yellow;
    }

    AppIndexInput {
        background: rgb(50,50,50);
        padding: 1;
    }

    #input-label {
        color: white;
        text-style: bold;
    }

    #app-index-input {
        margin-top: 1;
    }

    .spacer {
        height: 1;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("Q", "quit", "Quit", show=False),  # Capital Q also quits
        Binding("ctrl+c", "quit", "Quit", show=False),  # Also allow Ctrl+C
        Binding("escape", "quit", "Quit", show=False),  # Escape also quits
        Binding("r", "refresh_data", "Refresh"),
        Binding("s", "stop_selected_app", "Stop App"),
        Binding("h", "show_help", "Help"),
        Binding("e", "focus_input", "Enter Index"),
        Binding("up", "move_up", "Up"),
        Binding("down", "move_down", "Down"),
        Binding("j", "move_down", show=False),
        Binding("k", "move_up", show=False),
    ]

    def __init__(self) -> None:
        super().__init__()
        self.data_service: Optional[DashboardDataService] = None
        self.event_handler: Optional[DashboardEventHandler] = None
        self.footer_status = "Press h for help."
        self.header_widget = None
        self.left_panel = None
        self.right_panel = None
        self.input_widget = None
        self.footer_widget = None

    def compose(self) -> ComposeResult:
        """Compose the dashboard widgets."""
        yield CustomHeader()
        with Container(classes="body"):
            yield LeftPanel0()
            yield RightPanel()
        yield AppIndexInput()
        yield CustomFooter()

    def on_mount(self) -> None:
        """ Initialization/mounting of the dashboard """
        try:
            self.header_widget = self.query_one(CustomHeader)
            self.left_panel = self.query_one(LeftPanel0)
            self.right_panel = self.query_one(RightPanel)
            self.input_widget = self.query_one(AppIndexInput)
            self.footer_widget = self.query_one(CustomFooter)

            self.header_widget.refresh()
            self.left_panel.refresh()
            self.right_panel.refresh()
            self.footer_widget.refresh()

            # Set initial status
            self.footer_status = "Initializing dashboard..."
            self._update_footer()

            # Update header with version immediately (before services)
            try:
                version = get_version()
                self.header_widget.update_header_info(version, "Initializing...")
            except:
                pass
            
            self.refresh()
            self.screen.refresh()
            
            try:
                self.screen.focus()
            except:
                pass
            
            self.set_timer(0.1, self._delayed_initialize)
        except Exception as exc:
            # Fallback if everything fails
            error_msg = f"Dashboard initialization failed: {exc}"
            self.footer_status = f"[red]{error_msg}[/red]"
            try:
                if hasattr(self, 'footer_widget') and self.footer_widget:
                    self._update_footer()
                    self.refresh()
                    self.screen.refresh()
            except:
                # If footer update fails, at least try to show something
                pass
            # Log the error
            if hasattr(self, 'data_service') and self.data_service:
                self.data_service.config.logger.error(f"Dashboard mount error: {exc}", exc_info=True)
            else:
                import logging
                logging.error(f"Dashboard mount error: {exc}", exc_info=True)

    def _delayed_initialize(self) -> None:
        """Initialize services after screen is shown."""
        try:
            self.footer_status = "Initializing services..."
            self._update_footer()
            self.refresh()
            self.screen.refresh()
            
            self._initialize_services()
            
            if self.data_service:
                self._update_header()
                user_email = self.data_service.get_user_email()
                if user_email != "Not logged in":
                    self.footer_status = "Ready. Press 'r' to refresh apps."
                else:
                    self.footer_status = "Not logged in. Press 'r' to refresh or login first."
            else:
                self.footer_status = "Services unavailable. Press 'r' to retry."
                try:
                    version = get_version()
                    if hasattr(self, 'header_widget') and self.header_widget:
                        self.header_widget.update_header_info(version, "Not logged in")
                except:
                    pass
            
            self._update_footer()
            self.refresh()
            self.screen.refresh()
            
            self.set_timer(0.2, self._delayed_refresh)
        except Exception as e:
            self.footer_status = f"Warning: {str(e)[:50]}"
            self._update_footer()
            self.refresh()
            self.screen.refresh()
    
    def _delayed_refresh(self) -> None:
        """Refresh data after services are initialized."""
        try:
            self.footer_status = "Loading apps..."
            self._update_footer()
            self.refresh()
            
            self.refresh_data()
        except Exception as e:
            self.footer_status = f"Data error: {str(e)[:50]}"
            self._update_footer()
            self.refresh()
    
    def _initialize_services(self) -> None:
        """Initialize data service and event handler."""
        if self.data_service:
            return
        try:
            self.data_service = DashboardDataService()
            self.event_handler = DashboardEventHandler(self.data_service)
            self.footer_status = "Services initialized"
        except Exception as exc:
            self.footer_status = f"[red]Failed to initialize services: {exc}[/red]"
            self.data_service = None
            self.event_handler = None
        finally:
            # Always update footer even if there's an error
            self._update_footer()
            self.refresh()

    def refresh_data(self) -> None:
        """Refresh dashboard data."""
        try:
            if not self.event_handler:
                if hasattr(self, 'left_panel') and self.left_panel:
                    self.left_panel.update_apps([], "Services unavailable.")
                self.footer_status = "No event handler available"
                self._update_footer()
                self.refresh()
                return

            summaries, status = self.event_handler.handle_refresh_data()
            if not summaries:
                if hasattr(self, 'left_panel') and self.left_panel:
                    self.left_panel.update_apps([], status or "No apps available")
                if hasattr(self, 'right_panel') and self.right_panel:
                    self.right_panel.update_details(None, None)
                self.footer_status = status or "No apps found"
                self._update_footer()
                self.refresh()
                return

            if hasattr(self, 'left_panel') and self.left_panel:
                self.left_panel.update_apps(summaries, f"Found {len(summaries)} app(s).")
            self._update_header()

            # Select first app if available
            if summaries:
                self.event_handler.handle_app_selection(summaries[0])
                self._update_selection_display()
                if hasattr(self, 'left_panel') and self.left_panel:
                    self.left_panel.select_row(0)

            self.footer_status = "Apps loaded successfully."
            self._update_footer()
            self.refresh()
        except Exception as exc:
            self.footer_status = f"[red]Error loading data: {exc}[/red]"
            if hasattr(self, 'left_panel') and self.left_panel:
                self.left_panel.update_apps([], "Error loading apps")
            self._update_footer()
            self.refresh()
            if hasattr(self, 'data_service') and self.data_service:
                self.data_service.config.logger.error(f"Refresh data error: {exc}", exc_info=True)

    def _update_selection_display(self) -> None:
        """Update the right panel with current selection."""
        if not self.event_handler:
            return

        summary = self.event_handler.get_current_selection()
        usage_data = self.event_handler.get_usage_data()

        if summary:
            app_id = _app_value(summary.raw_app, "id", "unknown")
            self.right_panel.update_details(summary, usage_data, app_id)

    def on_left_panel0_appselected(self, message: LeftPanel0.AppSelected) -> None:
        """Handle app selection message from left panel."""
        if not self.event_handler:
            return

        self.event_handler.handle_app_selection(message.summary)
        self._update_selection_display()
        self.footer_status = f"Selected app {message.summary.name}"
        self._update_footer()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission for app index selection."""
        if not self.event_handler:
            self.footer_status = "No event handler available."
            self._update_footer()
            return

        success, message, summary = self.event_handler.handle_index_input(event.value)
        self.footer_status = message
        self._update_footer()

        if success and summary:
            self._update_selection_display()
            # Move cursor to selected row
            self.left_panel.select_row(self.event_handler.selected_index)

            # Clear the input
            event.input.value = ""

    def action_refresh_data(self) -> None:
        self.refresh_data()

    def action_move_up(self) -> None:
        if not self.event_handler:
            return
        summary = self.event_handler.handle_move_selection(-1)
        if summary:
            self._update_selection_display()
            self.left_panel.select_row(self.event_handler.selected_index)

    def action_move_down(self) -> None:
        if not self.event_handler:
            return
        summary = self.event_handler.handle_move_selection(1)
        if summary:
            self._update_selection_display()
            self.left_panel.select_row(self.event_handler.selected_index)

    def action_stop_selected_app(self) -> None:
        if not self.event_handler:
            self.footer_status = "No event handler available."
        else:
            success, message = self.event_handler.handle_stop_app()
            self.footer_status = message
        self._update_footer()

    def action_show_help(self) -> None:
        self.right_panel.update_help_text()
        self.footer_status = "Help updated."
        self._update_footer()

    def action_quit(self) -> None:
        """Quit the dashboard application."""
        self.exit()

    def action_focus_input(self) -> None:
        """Focus the app index input field."""
        try:
            input_field = self.input_widget.query_one("#app-index-input", Input)
            input_field.focus()
            self.footer_status = "Enter app index number and press Enter..."
            self._update_footer()
        except Exception as e:
            self.footer_status = f"Could not focus input: {str(e)}"
            self._update_footer()

    def _update_header(self) -> None:
        """Update header with version and user info."""
        if not self.data_service:
            if hasattr(self, 'header_widget') and self.header_widget:
                try:
                    version = get_version()
                    self.header_widget.update_header_info(version, "Not logged in")
                except:
                    pass
            return
        if not hasattr(self, 'header_widget') or not self.header_widget:
            return

        try:
            # Get the installed Celestical package version
            version = get_version()
            user_email = self.data_service.get_user_email()
            self.header_widget.update_header_info(version, user_email)
            self.header_widget.refresh()
        except Exception as e:
            if self.data_service:
                self.data_service.config.logger.debug(f"Header update error: {e}")

    def _update_footer(self) -> None:
        """Update footer with current status message."""
        if hasattr(self, 'footer_widget') and self.footer_widget:
            try:
                self.footer_widget.set_status(self.footer_status)
            except Exception as e:
                # Silently fail if footer update fails to avoid breaking the app
                pass
