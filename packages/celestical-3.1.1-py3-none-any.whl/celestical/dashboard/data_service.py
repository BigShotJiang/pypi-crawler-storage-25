"""Dashboard data service for managing data flow and business logic."""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Dict, List, Tuple

from celestical.config import Config
from celestical.services import SessionService
from celestical.user import User


@dataclass
class AppSummary:
    """Lightweight representation of an app row for the table."""

    index_label: str
    name: str
    uuid_display: str
    domain: str
    status_markup: str
    raw_app: object


def _app_value(app: object, field: str, default: object = None) -> object:
    """Safely get a field from either a dict or object."""

    if isinstance(app, dict):
        return app.get(field, default)

    return getattr(app, field, default)


def _summarize_app(index: int, app: object) -> AppSummary:
    """Convert raw app objects into `AppSummary` entries."""

    url = _app_value(app, "url", "") or ""
    name = url or _app_value(app, "name", "Unnamed app")

    app_id = _app_value(app, "id", "") or ""
    uuid_display = app_id or "—"

    domain = url or "N/A"

    is_running = bool(_app_value(app, "is_running", False))
    is_stopped = bool(_app_value(app, "is_stopped", False))
    if is_stopped:
        status_markup = "[red]stopped[/red]"
    elif is_running:
        status_markup = "[bright_green]running[/bright_green]"
    else:
        status_markup = "[bright_red]paused[/bright_red]"

    return AppSummary(
        index_label=str(index),
        name=str(name),
        uuid_display=uuid_display,
        domain=str(domain),
        status_markup=status_markup,
        raw_app=app,
    )


class DashboardDataService:
    """Bridges existing session logic with the Textual dashboard."""

    def __init__(self) -> None:
        self.config = Config()
        try:
            # Check if user is already logged in without prompting
            user = User(config=self.config)
            if user.is_logged_in():
                # User is logged in, create session with login
                try:
                    self.session = SessionService(
                        needs_login=True,
                        config=self.config)
                except Exception as oops:
                    # If login session fails, try without login
                    msg = f"Login session failed: {oops}"
                    msg += ", trying without login..."
                    self.config.logger.warning(msg)
                    self.session = SessionService(
                        needs_login=False,
                        config=self.config)
            else:
                # User not logged in, create session without login requirement
                self.session = SessionService(
                    needs_login=False,
                    config=self.config)
        except Exception as oops:
            # Fallback to no login if anything fails
            msg = f"Session creation failed: {oops}"
            msg += ", continuing without login..."
            self.config.logger.warning(msg)
            try:
                self.session = SessionService(
                    needs_login=False,
                    config=self.config)
            except Exception as eoops2:
                msg = f"Session creation failed: {eoops2}"
                self.config.logger.error(msg)
                self.session = None

    def fetch_app_summaries(self) -> Tuple[List[AppSummary], str]:
        """Fetch app summaries from the session.

        Returns:
            Tuple of (app_summaries, status_message)
        """
        if not self.session:
            return [], "No session available"

        try:
            apps_dict, status = self.session.get_apps()
        except Exception as exc:
            return [], f"Failed to load apps: {exc}"

        if status != "ok":
            return [], f"API returned status: {status}"

        if not apps_dict:
            return [], "No apps found"

        summaries: List[AppSummary] = []
        for idx, app in enumerate(apps_dict.values(), start=1):
            summaries.append(_summarize_app(idx, app))

        return summaries, ""

    def get_user_email(self) -> str:
        """Get the current user's email/username.

        Returns:
            User email or "Not logged in"
        """
        user = getattr(self.session, "user", None)
        if user:
            # Check if user is actually logged in
            if hasattr(user, 'is_logged_in') and callable(user.is_logged_in):
                if user.is_logged_in():
                    username = getattr(user, "username", None)
                    if username:
                        return username
            else:
                # Fallback: check if username exists
                username = getattr(user, "username", None)
                if username and username.strip():
                    return username
        return "Not logged in"

    def build_usage_data(self) -> Dict[str, int]:
        """Build usage metrics for the selected app.

        Note: Currently returns simulated data for demonstration purposes.
        TODO: Replace with real metrics from the API.

        Returns:
            Dictionary with usage metrics
        """
        # TODO: Replace with real API calls to get actual usage metrics
        return {
            "cpu": random.randint(20, 80),
            "memory": random.randint(30, 90),
            "storage": random.randint(10, 50),
            "in_network": random.randint(5, 40),
            "out_network": random.randint(5, 40),
            "energy": random.randint(20, 70),
            "services": random.randint(1, 5),
        }

    def stop_app(self, app_summary: AppSummary) -> Tuple[bool, str]:
        """Stop the specified app.

        Args:
            app_summary: The app to stop

        Returns:
            Tuple of (success, message)
        """
        # TODO: Implement actual app stopping logic via API calls
        app_name = app_summary.name
        return True, f"Stop requested for {app_name} (not implemented)"

    def refresh_apps(self) -> Tuple[List[AppSummary], str]:
        """Refresh and return updated app summaries.

        Returns:
            Tuple of (app_summaries, status_message)
        """
        return self.fetch_app_summaries()
