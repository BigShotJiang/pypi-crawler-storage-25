"""Event handlers for dashboard interactions."""

from __future__ import annotations

from typing import Optional

from celestical.dashboard.data_service import AppSummary, DashboardDataService


class DashboardEventHandler:
    """Handles dashboard events and user interactions."""

    def __init__(self, data_service: Optional["DashboardDataService"] = None):
        self.data_service = data_service
        self.selected_summary: Optional["AppSummary"] = None
        self.selected_index = 0
        self.apps = []
        self.usage_data = {}

    def handle_app_selection(self, summary: "AppSummary") -> None:
        """Handle when an app is selected.

        Args:
            summary: The selected app summary
        """
        self.selected_summary = summary
        try:
            self.selected_index = max(int(summary.index_label) - 1, 0)
        except ValueError:
            self.selected_index = 0

        # Update usage data
        if self.data_service:
            self.usage_data = self.data_service.build_usage_data()

    def handle_refresh_data(self) -> tuple[list["AppSummary"], str]:
        """Handle data refresh request.

        Returns:
            Tuple of (app_summaries, status_message)
        """
        if not self.data_service:
            return [], "No data service available"

        summaries, status = self.data_service.refresh_apps()
        self.apps = summaries

        # Reset selection if no apps
        if not summaries:
            self.selected_summary = None
            self.selected_index = 0
        else:
            # Maintain selection if possible
            if self.selected_index >= len(summaries):
                self.selected_index = len(summaries) - 1
            if self.selected_index >= 0:
                self.selected_summary = summaries[self.selected_index]

        return summaries, status

    def handle_move_selection(self, delta: int) -> Optional["AppSummary"]:
        """Handle moving selection up or down.

        Args:
            delta: Direction to move (-1 for up, +1 for down)

        Returns:
            New selected app summary or None
        """
        if not self.apps:
            return None

        new_index = min(max(self.selected_index + delta, 0), len(self.apps) - 1)
        self.selected_index = new_index
        self.selected_summary = self.apps[new_index]

        # Update usage data
        if self.data_service:
            self.usage_data = self.data_service.build_usage_data()

        return self.selected_summary

    def handle_index_input(self, input_value: str) -> tuple[bool, str, Optional["AppSummary"]]:
        """Handle user input for app index selection.

        Args:
            input_value: The input string from user

        Returns:
            Tuple of (success, message, selected_app_summary)
        """
        try:
            index_str = input_value.strip()
            if not index_str:
                return False, "Please enter a valid app index number.", None

            # Convert to 0-based index (user enters 1-based)
            user_index = int(index_str)
            if user_index < 1:
                return False, "App index must be 1 or greater.", None

            zero_based_index = user_index - 1

            # Check if index is valid
            if not self.apps or zero_based_index >= len(self.apps):
                return False, f"Invalid app index. Available apps: 1-{len(self.apps)}", None

            # Select the app
            self.selected_index = zero_based_index
            self.selected_summary = self.apps[zero_based_index]

            # Update usage data
            if self.data_service:
                self.usage_data = self.data_service.build_usage_data()

            return True, f"Selected app #{user_index}: {self.apps[zero_based_index].name}", self.selected_summary

        except ValueError:
            return False, "Please enter a valid number.", None

    def handle_stop_app(self) -> tuple[bool, str]:
        """Handle stopping the selected app.

        Returns:
            Tuple of (success, message)
        """
        if not self.selected_summary:
            return False, "No app selected."

        if not self.data_service:
            return False, "No data service available."

        success, message = self.data_service.stop_app(self.selected_summary)
        return success, message

    def get_current_selection(self) -> Optional["AppSummary"]:
        """Get the currently selected app summary.

        Returns:
            Current app summary or None
        """
        return self.selected_summary

    def get_usage_data(self) -> dict:
        """Get the current usage data.

        Returns:
            Usage data dictionary
        """
        return self.usage_data
