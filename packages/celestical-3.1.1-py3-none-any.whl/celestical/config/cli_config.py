import click 
import typer
from typer.core import TyperGroup
from celestical.app.commands import app_flexible_handler


class FallbackGroup(TyperGroup):
    """ Configuring the one FallbackGroup of the Typer app.
    This will be called when an unrecognized command is given
        
        It should dispatch action to a handler or several.
        In our case this is the app handler. 

    """

    def get_command(self, ctx: typer.Context, cmd_name: str):
        """Try normal command resolution, everything non Null goes through here.

        If nothing is found then fallback_command is used
        """
        rv = super().get_command(ctx, cmd_name)
        if rv is not None:
            # in case the command exists
            return rv

        # If command doesn't exist, run fallback
        @click.command(name=cmd_name, context_settings=dict(ignore_unknown_options=True))
        @click.argument("args", nargs=-1, type=click.UNPROCESSED)
        def fallback_command(*args, **kwargs):
            """ Fallback dispatcher when command is not defined.
                We want to see if that is a app name or "dashboard"

            Parameters:
                - args: is empty
                - kwargs is a dictionary with one key called 'args' which value
                  is a tuple of arguments after the command name such as ('-a',
                  'stop')
            """
            # Do your custom logic here
            # Example: call a function with cmd_name
            if cmd_name is not None:
                if cmd_name == "help":
                    ctx.get_help()
                elif cmd_name != "":
                    app_flexible_handler(ctx, cmd_name, args, kwargs)

        return fallback_command


