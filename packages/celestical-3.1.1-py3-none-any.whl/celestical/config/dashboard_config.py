"""Dashboard configuration settings."""

from typing import Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum


class DashboardTheme(Enum):
    """Available dashboard themes."""
    DEFAULT = "default"
    DARK = "dark"
    LIGHT = "light"
    MONOCHROME = "monochrome"


@dataclass
class DashboardConfig:
    """Configuration class for dashboard settings."""
    
    # Display settings
    theme: DashboardTheme = DashboardTheme.DEFAULT
    refresh_interval: int = 5
    show_timestamps: bool = True
    show_debug_info: bool = False
    
    # Layout settings
    max_apps_per_page: int = 10
    compact_mode: bool = False
    
    # Data settings
    cache_duration: int = 300  # 5 minutes
    auto_refresh: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary.
        
        Returns:
            Dictionary representation of the configuration
        """
        return {
            "theme": self.theme.value,
            "refresh_interval": self.refresh_interval,
            "show_timestamps": self.show_timestamps,
            "show_debug_info": self.show_debug_info,
            "max_apps_per_page": self.max_apps_per_page,
            "compact_mode": self.compact_mode,
            "cache_duration": self.cache_duration,
            "auto_refresh": self.auto_refresh
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DashboardConfig":
        """Create configuration from dictionary.
        
        Args:
            data: Dictionary containing configuration data
            
        Returns:
            DashboardConfig instance
        """
        return cls(
            theme=DashboardTheme(data.get("theme", "default")),
            refresh_interval=data.get("refresh_interval", 5),
            show_timestamps=data.get("show_timestamps", True),
            show_debug_info=data.get("show_debug_info", False),
            max_apps_per_page=data.get("max_apps_per_page", 10),
            compact_mode=data.get("compact_mode", False),
            cache_duration=data.get("cache_duration", 300),
            auto_refresh=data.get("auto_refresh", True)
        )
    
    def update(self, **kwargs) -> None:
        """Update configuration with new values.
        
        Args:
            **kwargs: Configuration values to update
        """
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
