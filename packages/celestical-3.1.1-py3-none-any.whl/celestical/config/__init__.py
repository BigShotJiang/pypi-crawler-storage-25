"""
Configuration management for the Celestical application.
"""
from .config import Config
from .dashboard_config import DashboardConfig
