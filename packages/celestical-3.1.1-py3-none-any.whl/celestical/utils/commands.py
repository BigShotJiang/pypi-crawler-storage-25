import typer
from celestical.utils.display import cli_panel, print_console, print_text

def add_utils_commands(app: typer.Typer) -> bool:
    if app is None:
        return False 

    @app.command("help")
    def default_help(ctx: typer.Context,
                     cmd: Optional[str] =
                        typer.Argument(
                            default="",
                            help="Command name to get help from")
                    ):
        """
         Display this help message similarly to -h or --help
         or about a command if specified
        """
        if ctx is None:
            typer.echo(ctx.get_help())
            return

        if ctx.parent is None:
            typer.echo(ctx.get_help())
            return

        if cmd == "":
            # Show general help
            typer.echo(ctx.parent.get_help())
            return

        # Show help for specific command
        try:
            # Get the command from the parent app
            command = ctx.parent.command.commands.get(cmd)
            if command:
                # Simple approach: show command info
                print(f"\nHelp for command: {cmd}")
                print("=" * 50)
                if hasattr(command, 'help') and command.help:
                    print(command.help)
                    # print(help(command))
                    command_context = command.context_class(command)
                    print("\nUsage:")
                    print(f"  celestical {cmd}")
                    print(command_context.get_help())
                    # print(CCC.command.get_help(CCC))
                else:
                    print(f"No detailed help available for '{cmd}'")
            else:
                print_text(f"Command '{cmd}' not found. Available commands:",
                          worry_level="oops")
                typer.echo(ctx.parent.get_help())
        except (ValueError, AttributeError, KeyError) as e:
            print_text(f"Error getting help for command '{cmd}': {e}",
                      worry_level="oops")
            typer.echo(ctx.parent.get_help())

