"""Helper display functions for the celestical app.

DEPRECATED: Use celestical.output.ConsoleOutput instead.
These functions are kept for backward compatibility.
"""
import os
import time
import warnings

from prettytable import PrettyTable
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from celestical.output import ConsoleOutput, Theme


console = Console()
_output = ConsoleOutput()

MIN_WIDTH = 80
MIN_HEIGHT = 20
READ_DELAY = 0.8


def clear_screen():
    """Tries to clear the screen."""
    try:
        os.system('clear' if os.name == 'posix' else 'cls')
    except Exception:
        pass


def is_console_big(
    this_console: Console = None,
    verbose: bool = True) -> bool:
    """Return size and if it is large enough (True)."""
    if this_console is None:
        this_console = console
    terminal_width = this_console.size.width
    terminal_height = this_console.size.height

    if terminal_width < MIN_WIDTH or terminal_height < MIN_HEIGHT:
        if verbose:
            msg = "[red]Terminal too small[/red]"
            msg += f"\nCurrent size: {terminal_width}x{terminal_height}"
            msg += f"\nResize to at least [red]{MIN_WIDTH}x{MIN_HEIGHT}[/red]"
            print_console(msg)
        return False

    return True


def read_wait():
    """Cognitively we might have to wait for the readers."""
    time.sleep(READ_DELAY)


def create_empty_table(columns_labels):
    """Create an empty table with specified columns."""
    pt = PrettyTable()
    pt.field_names = columns_labels
    return pt


def add_row_to_table(table: PrettyTable, row_dict):
    """Add a row to the table based on a dictionary."""
    if set(row_dict.keys()) != set(table.field_names):
        raise ValueError("Row dictionary keys do not match table columns.")
    table.add_row([row_dict[col] for col in table.field_names])


def cli_create_table(data: dict) -> Table:
    """Create a table from a dictionary."""
    table = Table(show_header=True, header_style=Theme.TABLE_HEADER)
    table.add_column("Key", style=Theme.DIM)
    table.add_column("Value")

    for key, value in data.items():
        table.add_row(str(key), str(value))

    return table


def write_app_row(
        app: dict,
        key: int = 0,
        active_app_id: str = "",
        indent_space: str = "") -> str:
    """Common representation of an app in a list."""
    app_id = app.get("id", "-")
    active = "[r]ON[/r]" if active_app_id == app_id else "  "
    acolor = Theme.HIGHLIGHT if active_app_id == app_id else Theme.MUTED
    app_id_str = f"[{Theme.MUTED}]{app_id}[/{Theme.MUTED}]"

    app_url = app.get("url", "")
    if app_url == "":
        app_url = "[ no domain ]"

    cdate = app.get('created_date', "no-date")
    cdate_s = cdate.split("T")
    if len(cdate_s) > 1:
        cdate = f"[{Theme.MUTED}]{cdate_s[0]}[/{Theme.MUTED}]"
        cdate += f" [grey54]{cdate_s[1]}[/grey54]"

    one_app_row = f"\n{indent_space} {active} "
    one_app_row += f"> {key}/ [{acolor}]{app_url}[/{acolor}]"
    one_app_row += f"\n{indent_space}      ({cdate}) {app_id_str}"

    return one_app_row


def cli_panel(
        message: str,
        title: str = "Celestical - Information",
        kind: str = "info",
        batch: bool = False) -> None:
    """Display a message in a panel.
    
    DEPRECATED: Use ConsoleOutput.panel() instead.
    """
    if batch:
        return
    _output.panel(message, title=title, kind=kind)


def print_nested_dict(dictionary: dict, batch: bool = False):
    """Print a nested dictionary in a readable format."""
    if batch:
        return
    for key, value in dictionary.items():
        if isinstance(value, dict):
            print_nested_dict(value)
        else:
            print(f"{key}: {value}")


def print_feedback(used_input: str, batch: bool = False):
    """Show users what they have input."""
    if batch:
        return
    _output.success(used_input)


def print_help(help_text: str, batch: bool = False):
    """Show users a help text."""
    if batch:
        return
    _output.info(help_text)


def print_space(rows: int = 1):
    """Simply jump lines by number of requested rows."""
    _output.space(rows)


def print_text(text: str, worry_level: str = "chill"):
    """Print text to the CLI.
    
    DEPRECATED: Use ConsoleOutput.info(), warning(), or error() instead.
    """
    if worry_level == "oops":
        _output.warning(text)
    elif worry_level == "ohno":
        _output.error(text, exit_code=0)
    else:
        _output.info(text)


def print_console(msg: str):
    """Simple console print."""
    _output.info(msg)
    read_wait()


def print_warning(msg: str):
    """Console print a warning."""
    _output.warning(msg)


def print_error(msg: str):
    """Console print an error."""
    _output.error(msg, exit_code=0)


def guess_service_type_by_name(service_name: str, img_name: str = ""):
    """Quick guess of service type based on service name and image name."""
    service_types = {
        "FRONTEND": ["web", "www", "frontend", "traefik", "haproxy",
                     "apache", "nginx"],
        "API": ["api", "backend", "service", "node"],
        "DB": ["database", "redis", "mongo", "mariadb", "postgre"],
        "BATCH": ["process", "hidden", "compute"],
        "OTHER": []
    }

    if len(service_name) == 0:
        return ""

    service_name = service_name.lower()

    for stype, guessers in service_types.items():
        for guesser in guessers:
            if guesser in service_name:
                return stype

    if img_name:
        img_name = img_name.lower()
        for stype, guessers in service_types.items():
            for guesser in guessers:
                if guesser in img_name:
                    return stype

    return "OTHER"


def dict_to_list_env(d_in: dict) -> list:
    """Convert a dictionary to a list of environment variable strings."""
    env_list = []
    for key, value in d_in.items():
        env_list.append(key + "=" + str(value))
    return env_list


def set_login_prompt(prefix: str) -> bool:
    """Sets a custom shell prompt showing login status for Celestical."""
    prompt_var = "PS1"

    if "ZSH_VERSION" in os.environ:
        if os.environ["ZSH_VERSION"] != "":
            if "PROMPT" in os.environ and os.environ["PROMPT"] != "":
                prompt_var = "PROMPT"

    if prompt_var not in os.environ:
        return False

    original_prompt = os.environ[prompt_var]
    os.environ[prompt_var] = prefix + original_prompt
    return True
