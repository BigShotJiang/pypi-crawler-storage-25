"""Session service layer - business logic separated from UI.

This module provides a clean interface for session management with:
 - Result types for clear success/failure states
 - ConsoleOutput for consistent display
 - Full backward compatibility with legacy Session functionality
"""
from typing import Optional, Tuple, Dict, Any, List

from celestical.output import Result, ConsoleOutput
from celestical.config import Config
from celestical.user import User
from celestical.app import App
from celestical.app.functions import get_apps_list
from celestical.docker import DockerMachine
from celestical.utils.display import write_app_row


class SessionService:
    """Business logic for session management.
    
    This class handles the core functionality for:
    - User authentication (login/logout)
    - App selection and management
    - Docker service checking
    - Deployments
    
    All methods return Result objects for clear success/failure states
    and use ConsoleOutput for consistent display.
    """

    def __init__(
        self,
        needs_login: bool = False,
        force_login: bool = False,
        config: Optional[Config] = None,
        batch_mode: bool = False,
        select_app: bool = False,
        output: Optional[ConsoleOutput] = None
    ) -> None:
        """Initialize the SessionService instance.

        Parameters:
            needs_login: If True, login will be prompted if not already logged in
            force_login: If True, forces re-login even if already authenticated
            config: Optional configuration instance (default: new Config)
            batch_mode: If True, suppresses interactive prompts
            select_app: If True, triggers app selection on init
            output: Optional ConsoleOutput instance (default: new ConsoleOutput)
        """
        self._config = config or Config()
        self._output = output or ConsoleOutput(quiet=batch_mode)
        self._batch_mode = batch_mode
        self._user: User = User(config=self._config)
        self._app: Optional[App] = None

        # Handle login requirements
        if force_login:
            self._user.user_login(force_relog=True)
        elif needs_login:
            logged_in_user = self._get_logged_in_user()
            if logged_in_user is None:
                raise SystemExit(2)
            self._user = logged_in_user

        # Optional app selection on init
        if select_app:
            self.select_app()

    @property
    def config(self) -> Config:
        """Get the configuration instance."""
        return self._config

    @property
    def user(self) -> User:
        """Get the user instance."""
        return self._user

    @property
    def app(self) -> Optional[App]:
        """Get the currently selected app, if any."""
        return self._app

    @property
    def output(self) -> ConsoleOutput:
        """Get the output instance."""
        return self._output

    def _get_logged_in_user(self) -> Optional[User]:
        """Get a logged in user, prompting for login if necessary.

        Returns:
            User instance if logged in, None otherwise
        """
        user = User(config=self._config)
        if not user.is_logged_in():
            if user.user_login():
                return user
            return None
        return user

    def logout(self) -> Result[bool]:
        """Logout the current user by resetting local credentials.

        Returns:
            Result indicating logout success
        """
        self._config.reset_config()
        self._output.success("Logged out.")
        return Result.ok(True, message="Logged out successfully")

    def check_docker_service(self) -> bool:
        """Check if Docker is running on the local machine.

        Returns:
            True if Docker is running, False otherwise
        """
        docker_m = DockerMachine()
        docker_client = docker_m.get_docker_client()
        return docker_client is not None

    def get_apps(self) -> Tuple[Dict[str, Any], str]:
        """Fetch all apps for the current user from the API.
        
        Returns:
            Tuple of (apps dictionary, status string)
        """
        return get_apps_list(self._user, self._config)

    def get_apps_table(self, start_index: int = 1) -> Tuple[str, Dict[str, Any]]:
        """Create a table string with all apps from API.
        
        Marks the active app for user selection.
        
        Parameters:
            start_index: Starting index for app numbering (default: 1)
        
        Returns:
            Tuple of (formatted table string, apps dictionary)
        """
        apps, api_status = get_apps_list(
            user=self._user,
            config=self._config,
            start_index=start_index)

        if apps is None or api_status != "ok":
            return "", {}

        active_app_id = self._config.get_active_app()

        # Build table string
        cli_table = "\n>>>> Your Celestical Apps"
        if len(apps) == 0:
            cli_table = "\n>>>> You have no Celestical Apps, yet! :-) "
            cli_table += "\n     use:  [b]celestical deploy[/b] [i]my-docker-compose.yml[/i]"

        for key, app in apps.items():
            one_app_row = write_app_row(app, key, active_app_id)
            cli_table += one_app_row

        # Check for local apps not pushed yet
        local_apps = self._get_local_apps_list(
            rapps=apps,
            start_index=len(apps) + start_index + 1
        )
        if len(local_apps) > 0:
            self._config.logger.warning(" --- Local apps have been detected")

        return cli_table, apps

    def _get_local_apps_list(
        self,
        rapps: Dict[str, Any],
        start_index: int = 1
    ) -> Dict[str, Any]:
        """Get local apps in folder that are not part of remote listing.
        
        Parameters:
            rapps: Dictionary of remote apps
            start_index: Starting index for local app numbering
        
        Returns:
            Dictionary mapping index to app info
        """
        app_dir = self._config.get_app_config_dir()
        app_listing = {}

        key = start_index
        for app in app_dir.iterdir():
            if app.is_dir():
                app_id = str(app.name)
                if app_id not in [rapps[p].get("id", ":") for p in rapps]:
                    app_listing[key] = {"id": app_id}
                    key += 1
        return app_listing

    def _retrieve_app_index_from_id(self, apps: Dict[str, Any], app_id: str) -> List[str]:
        """Find apps matching a partial ID.
        
        Parameters:
            apps: Dictionary of apps
            app_id: Partial or full app ID to match
        
        Returns:
            List of matching app keys
        """
        return [
            index for index, app in apps.items()
            if app.get("id", "_").startswith(app_id) or
               app.get("id", "_").endswith(app_id)
        ]

    def _retrieve_app_index_from_index(self, apps: Dict[str, Any], user_index: str) -> List[str]:
        """Find apps matching an index number.
        
        Parameters:
            apps: Dictionary of apps
            user_index: Index string to match
        
        Returns:
            List of matching app keys
        """
        return [key for key in apps if user_index == key]

    def _retrieve_app_index_from_url(self, apps: Dict[str, Any], url: str) -> List[str]:
        """Find apps matching a URL pattern.
        
        Parameters:
            apps: Dictionary of apps
            url: URL substring to match
        
        Returns:
            List of matching app keys
        """
        return [index for index, app in apps.items() if url in app.get("url", "")]

    def _select_apps_from_app_choice(
        self,
        app_list: Dict[str, Any],
        app_choice: str
    ) -> List[str]:
        """Select apps by various criteria (index, ID, URL).
        
        Parameters:
            app_list: Dictionary of apps
            app_choice: User's choice (can be index, ID, or URL)
        
        Returns:
            List of matching app keys
        """
        selected_apps_keys = []

        # Match by index
        selected_apps_keys.extend(
            self._retrieve_app_index_from_index(app_list, app_choice)
        )

        # Match by ID or URL (requires at least 3 chars)
        if len(app_choice) >= 3:
            selected_apps_keys.extend(
                self._retrieve_app_index_from_id(app_list, app_choice)
            )
            selected_apps_keys.extend(
                self._retrieve_app_index_from_url(app_list, app_choice)
            )

        return sorted(list(set(selected_apps_keys)))

    def select_app(self, app_id: str = "") -> bool:
        """Select an app to work with.
        
        If no app_id provided, shows a list for user selection.
        If apps list is empty, creates a new app.
        
        Parameters:
            app_id: Optional app ID to select directly
        
        Returns:
            True if app was selected/created, False otherwise
        """
        cli_table, apps = self.get_apps_table()
        msg = ""

        # Direct selection by app_id
        if len(app_id) >= 3:
            selected_app_ids = self._retrieve_app_index_from_id(apps, app_id)

            if len(selected_app_ids) == 1:
                self._app = App(
                    app_id=apps[selected_app_ids[0]]["id"],
                    user=self._user,
                    config=self._config
                )
                self._app.set_as_active_app()
                return True

            msg = "[bold]The App ID provided does not exist[/bold]\n"

        # No apps available - create new
        if len(apps) == 0:
            self._app = None
            msg += ">>> Creating a new app for you."
            self._output.info(msg)

            self._app = App(user=self._user, config=self._config)
            self._app.set_as_active_app()

            if self._app.has_access_issue():
                return False

            self._output.panel(
                f"Setting your new app as the active App.\n{self._app}",
                title="New App Created"
            )
            return True

        # Show apps and prompt for selection
        self._output.panel(cli_table, title="Select one of your Apps")

        # Get user selection
        app_id = self._select_from_list(apps)

        # Create App instance
        url_list = [apps[app_a].get("url", "_") for app_a in apps]
        self._app = App(
            app_id=app_id,
            user=self._user,
            domain_list=url_list,
            config=self._config
        )
        self._app.set_as_active_app()
        return True

    def _select_from_list(self, apps: Dict[str, Any]) -> str:
        """Prompt user to select an app from the list.
        
        Parameters:
            apps: Dictionary of apps to choose from
        
        Returns:
            Selected app ID, or empty string for new app
        """
        active_app = self._config.get_active_app()
        if active_app is None:
            active_app = ""

        # Find the key for the active app
        active_app_key = ""
        for app_d in apps:
            if apps[app_d].get("id", "") == active_app:
                active_app_key = app_d

        # Prompt for selection
        msg = "Select the App number to work on, or [bold]N[/bold] for a new one"
        app_num_str = self._output.prompt(
            prompt=msg,
            default=active_app_key,
            helptxt="Choose an App number from the list or 'N' to create a new one"
        )

        # Parse selection
        app_num = 0
        if app_num_str == "":
            if active_app != "":
                return active_app
            app_num = len(apps) + 1

        if app_num == 0:
            try:
                app_num = int(app_num_str)
            except ValueError:
                app_num = len(apps) + 1

        if (app_num_str not in apps) or (app_num >= len(apps) + 1):
            msg = ""
            if app_num_str.lower() not in ["n", "new", "neu"]:
                msg = f"\nI know [b]{app_num_str}[/b] does not look "
                msg += "like a 'N' or 'new', I'll create a new one anyway.\n"
            msg += "Few questions and deployment will be done."
            msg += "\n\nSo let's create your new App!"
            self._output.panel(msg, title="Creating a new app")
            return ""

        # Return selected app ID
        return apps.get(app_num_str, {}).get("id", "")

    def delete_app(self, app_list: Optional[Dict[str, Any]] = None) -> bool:
        """Delete an app after user confirmation.
        
        Parameters:
            app_list: Optional pre-fetched app list
        
        Returns:
            True if app was deleted, False otherwise
        """
        if app_list is None:
            _, app_list = self.get_apps_table()

        if not app_list:
            self._output.info("No apps to delete.")
            return False

        prompt_delete_app = "Which app do you want to [red]delete[/red]?"
        app_choice = self._output.prompt(prompt=prompt_delete_app)

        if len(app_choice) == 0:
            self._output.info("Nothing selected.")
            return False

        # Get app ID
        chosen_apps_keys = self._select_apps_from_app_choice(app_list, app_choice)

        app_id = ""
        if len(chosen_apps_keys) == 1:
            app_id = app_list[chosen_apps_keys[0]]["id"]
        elif len(chosen_apps_keys) > 1:
            msg = "Several choices are possible, please be more specific."
            self._output.warning(msg)
            return False
        else:
            self._output.warning("No app found for your choice.")
            return False

        # Delete the app
        self._config.delete_active_file()

        if self._app is not None and self._app.app_id == app_id:
            self._app.delete_app()
            return True

        app = App(app_id=app_id, config=self._config, user=self._user)
        app.delete_app()
        return True

    def app_actions(self) -> bool:
        """Show app actions menu and handle user selection.
        
        Returns:
            True if action was performed, False otherwise
        """
        apps_table, app_list = self.get_apps_table()

        if not app_list:
            return False

        msg = "Actions:\n"
        msg += "    1/ Activate an app (a)\n"
        msg += "    2/ [red]Delete[/red] an app (d)"

        self._output.panel(apps_table, title="Apps")
        self._output.info(msg)

        user_action_choice = self._output.prompt("Select an action",
            default="")
        user_action_choice = user_action_choice.lower()

        if user_action_choice in ["d", "del", "delete", "2"]:
            return self.delete_app(app_list)

        self._output.info("Nothing done")
        return False


def create_session(
    needs_login: bool = False,
    force_login: bool = False,
    config: Optional[Config] = None,
    output: Optional[ConsoleOutput] = None
) -> Result[SessionService]:
    """ Factory function to create a session with proper authentication state.
    
    Parameters:
        needs_login: If True, login will be prompted if not already logged in
        force_login: If True, forces re-login even if already authenticated
        config: Optional configuration instance to use
        output: Optional ConsoleOutput instance to use
    
    Returns:
        Result containing the SessionService on success, or error on failure
    """
    try:
        service = SessionService(
            needs_login=needs_login,
            force_login=force_login,
            config=config,
            output=output
        )
        return Result.ok(service, message="Session created")
    except SystemExit:
        return Result.fail("Login required", error_code="LOGIN_REQUIRED")
    except Exception as oops:
        return Result.fail(str(oops), error_code="SESSION_ERROR")
