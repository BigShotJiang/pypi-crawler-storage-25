"""
This module contains class which does local and remote app management
"""
from pathlib import Path
import shutil
import base64

from celestical.user import User
from celestical.compose import Compose, Enricher
from celestical.config.config import Config
from celestical.output import get_output
from celestical.utils.display import (
    cli_panel,
    print_text,
    print_space,
    write_app_row,
    print_console,
    print_feedback)
from celestical.utils.prompts import confirm_user
from celestical.utils.files import save_yaml
from celestical.utils.waiters import Spinner, ProgressBar
from celestical.utils.crypt import Cryptic
from celestical.api.exceptions import (
    ForbiddenException,
    UnauthorizedException,
    NotFoundException,
    BadRequestException)
from celestical.api import ApiException
from celestical import api
from celestical.docker import Image


_console = get_output()

class App:
    """ This class consist of attributes and methods to manage local files of a
    specific app.

    By default this object would create a new App.
    Unless given a valid app ID.
    """

    def __init__(
            self,
            app_id: str = "",
            config: Config = None,
            force_sync: bool = True,
            domain_list: list | None = None,
            compose: Compose = None,
            user: User = None):
        """ An App contains a ecompose dictionary/file

        Parameters:
            - app_id: an App ID to set and load if given
            - force_sync: True to force synching with the web or False to work
              offline.
            - domain_list: list of strings of domains already locally synched
            - compose: Compose object to work with if empty, it will create a
              new one.
            - user: User object to make requests with. if empty it will load
              the current config.
        """
        # Config related topics
        self.config = config
        if self.config is None:
            self.config = Config()
        self.logger = self.config.logger

        self.access_issue = 0
        self.domain_list = [] if domain_list is None else domain_list

        # User setups
        self.user = User() if user is None else user

        # App ID is saved here to link it to the API
        self.app_id = app_id

        # all information should be in the compose metadata
        # including the app id and url.
        self.compose = compose
        if compose is None:
            self.compose = Compose()

        if len(app_id) >= 32 or force_sync is True:
            if not self.sync():
                self.logger.warning("App could not be synced.")

    def __str__(self) -> str:
        info = f"App ID: {self.app_id}\n"
        if len(self.compose.services) > 0:
            info += f"  - {len(self.compose.services)} services:\n"
            for serv in self.compose.services:
                info += f"      - {serv}"
        return info

    def _get_app_dir(self) -> Path:
        """ This function returns the path to enriched docker compose file
        given the app ID

        Return:
            - Path to the directory containing this app ecompose file
        """
        path = self.config.get_app_config_dir() / self.app_id
        path.mkdir(parents=True, exist_ok=True)
        return path

    def _get_ecompose_path(self) -> Path:
        """One place to define the ecompose path

            Content of that file is managed by the Compose object
        """
        return self._get_app_dir() / "ecompose.yml"

    def has_access_issue(self) -> bool:
        """ Manage status about issues creating an app

        Checking values of self.access_issue
         0: no issues
         1: ForbiddenException issue
        """
        if self.access_issue > 0:
            return True
        return False

    def set_as_active_app(self) -> None:
        """ This function sets the active app the one which user is currently
            working on.

        Parameters:
          - active_app_id:str: ID of the active app in string format.
        """
        path = self.config.get_active_app_id_path()
        path.write_text(data=self.app_id)

    def enrich(self, in_compose_path:Path) -> bool:
        """ This function commands and check enrichment process

            1. it checks which file is most recent from the app or the given
            user input (docker compose file)
            2. if the command line input file is older than the app ecompose
            then we continue to 4.
            3. Enrich the ecompose file
            4. Upload compose to get information about what to upload
            5. Upload images and anciliary information (confs)
        """
        # Get this app ecompose path even if not exist
        current_ecompose_path = self._get_ecompose_path()

        # Get None if the user input does not exist
        # or the detected most probable compose file if a folder is given
        user_compose_path = self.compose.define_compose_path(in_compose_path)

        if user_compose_path is None and not current_ecompose_path.is_file():
            print_text("We could not find a path to a compose file.",
                       worry_level="oops")
            return False

        # Setup which file has been selected
        selected_path = user_compose_path

        # --- Enricher
        enricher = Enricher(self.compose)
        self.compose = enricher.prepare(
            ecompose_path=current_ecompose_path,
            selected_path=selected_path)

        self.save_app()
        return True

    def read_app_ecompose(self) -> dict:
        """
        This function read the apps enriched ecompose file and returns it.

        Return:
            - ecompose content in dict format

        """
        ecompose_path = self._get_ecompose_path()
        ecompose_dict = self.compose.read_docker_compose(ecompose_path)
        return ecompose_dict

    def save_app(self) -> Path|None:
        """ This function saves the ecompose file when given ecompose dict with
        app id.

        Returns:
            - Path to enriched docker compose file
        """
        self.compose.ecompose["celestical"]["app_id"] = self.app_id
        ecomp_save = self.compose.ecompose.copy()

        if ecomp_save.get("celestical_secrets", None) is not None:
            del ecomp_save["celestical_secrets"]

        ecompose_path = self._get_ecompose_path()
        self.logger.info(f"Saving app: {self.app_id}")

        return save_yaml(data=ecomp_save,
                         yml_file=ecompose_path,
                         cli_logger=self.config.logger)

    def check_app_status(self):
        """ Check with celestical cloud the status of the app.
        """
        # if user is logged in
        apiconf = self.user.get_api_with_auth()
        with api.ApiClient(apiconf) as api_client:
            app_api = api.AppApi(api_client)
            #api_response = app_api.get_user_apps_app_status_get()
            app_api.get_app_app_app_uuid_get_with_http_info(
                app_uuid=self.app_id)

    def sync(self) -> bool:
        """ Makes initial setup and Sync local and celestical cloud apps state.

        This function does:
             - creating folder structure
             - syncing with remote corresponding app if exists
        """
        # Make sure the base apps folder exist or make it.
        # already done:  apps_dir.mkdir(parents=True, exist_ok=True)

        if self.app_id == "":
            self.logger.debug("Trying creating app")
            # To create a new app we need a base domain
            if len(self.compose.get("base_domain")) == 0:
                self.compose.init_ecompose()

            # no id no sync
            create_res = self.create()
            if create_res is None:
                return False
        else:  # we retrieve app info
            self.logger.debug(f"Trying syncing app {self.app_id}")
            saved_app = self._get_app_from_api()
            if saved_app is None:
                self.logger.debug("No app found from the API")
                return False
            self.compose.init_ecompose(
                base_domain=saved_app.url,
                app_id=self.app_id)

        return True
        # Create dedicated app folder or make sure it is created
        #self.sync_apps()

    def _make_encrypted_compose_pack(self, deploy: bool = True) -> dict:
        """ Make a compose pack with encrypted ecompose

            app_id can be empty in the pack
            app_url must be fed with the right info
        """
        compose_pack = {}

        # Default values
        compose_pack["enriched_compose"] = None
        compose_pack["deploy"] = deploy
        compose_pack["app_id"] = self.app_id
        compose_pack["app_url"] = self.compose.get("base_domain")

        # --- DEBUG encryption is disabled
        import yaml
        data = yaml.safe_dump(
                self.compose.ecompose,
                default_flow_style=False
            )
        compose_pack["enriched_compose"] = data
        return compose_pack

        # cryptic = Cryptic(config=self.config)

        # # No need to Convert string to bytes for base64 encoder
        # # enc_compose_data is already bytes with self.config.encoding
        # enc_compose_data = cryptic.encryption(self.compose.ecompose)

        # if enc_compose_data is None or len(enc_compose_data) == 0:
        #     print_text(worry_level="ohno",
        #                text="Encryption Failed: "+self.app_id)
        #     return compose_pack

        # # Generate base64 bytes stream from encrypted bytes
        # encrypted_data = base64.b64encode(enc_compose_data)

        # # Convert back to string for JSON Serialization
        # encrypted_data = encrypted_data.decode(self.config.encoding)

        # compose_pack["enriched_compose"] = encrypted_data

        # return compose_pack

    def create(self, deployment_type: str = "staging") -> Path|None:
        """
        This function makes a record in celestical cloud and gets the app ID.
        Creates folder structure and creates a basic enriched compose if none
        given.

        Args:
            deployment_type: Either "staging" or "production". 
                           If staging, a random domain is generated.
                           If production, uses user-provided base_domain.

        Returns:
            - Path to the enriched docker compose file
        """
        apiconf = self.user.get_api_with_auth()
        if apiconf is None:
            return None

        base_domain = self.compose.get("base_domain") or ""

        if deployment_type != "production" and not base_domain:
            with api.ApiClient(apiconf) as api_client:
                app_api = api.AppApi(api_client)
                try:
                    random_domain_response = app_api.get_random_domain_app_domain_get()
                    base_domain = random_domain_response.base_domain
                    self.compose.set("base_domain", base_domain)
                    self.logger.info(f"Generated random domain: {base_domain}")
                except Exception as eoops:
                    self.logger.error(f"Could not get random domain: {eoops}")
                    return None

        with api.ApiClient(apiconf) as api_client:
            app_api = api.AppApi(api_client)
            try:
                app_create = api.AppCreate(
                    url=base_domain,
                    deployment_type=deployment_type
                )
                api_response = app_api.create_app_only_app_post(app_create)
            except Exception as e:
                self.logger.error(f"Failed to create app: {e}")
                print_text(f"Failed to create app: {e}", worry_level="ohno")
                return None

        if not api_response or len(str(api_response.id)) == 0:
            self.logger.warning("App not created: no app id found from API.")
            print_text(
                "App could not be created, could not get API response",
                worry_level="ohno",
            )
            return None

        self.app_id = str(api_response.id)
        self.compose.set("status", "just-created")

        path = self.save_app()

        self.logger.info("Initiated App with ID: "+self.app_id)

        return path

    def push(self) -> bool:
        """ Manages push of an app for deployment
           - compose update
           - image updates
        """
        # self.save_app()
        compose_pack = self._make_encrypted_compose_pack(deploy=True)

        api_response = self.upload_compose(compose_pack)

        if api_response is None:
            return False

        if self.app_id != str(api_response.id):
            print_text("Enriched compose could not be pushed correctly",
                worry_level="ohno")

        return self.upload_images()

    def _get_app_from_api(self) -> api.App | None:
        """ This function gets app info from the API

        Return:
            - dict of app info or None if failed
        """
        apiconf = self.user.get_api_with_auth()
        with api.ApiClient(apiconf) as api_client:
            app_api = api.AppApi(api_client)
            try:
                return app_api.get_app_app_app_uuid_get(self.app_id)
            except ForbiddenException:
                self.logger.warning("Not allowed to get app by uuid.")
                return None
            except UnauthorizedException:
                self.logger.warning("Not authorized to get app by uuid.")
                return None
            except NotFoundException:
                self.logger.warning("App not found.")
                return None
            except Exception as oops:
                self.logger.warning("gettting App from API did not work.")
                self.logger.warning(oops)
                return None

    def upload_compose(self, compose_pack: dict):
        """ Update or create a composed application

        Parameters
          - compose_pack
        Returns:
          - api response
        """
        apiconf = self.user.get_api_with_auth()
        if apiconf is None:
            return None

        if not self.app_id:
            self.logger.error("No app_id set. Cannot upload compose.")
            return None

        api_response = None
        with api.ApiClient(apiconf) as api_client:
            app_api = api.AppApi(api_client)

            try:
                self.logger.debug("Preparing compose info to post")
                compose_to_post = api.Compose.from_dict(compose_pack)
            except (TypeError, ValueError, AttributeError) as oops:
                print_text(">>> [red]Compose data is not serializable[/red]")
                self.logger.error(oops)
                return None

            try:
                self.logger.debug("Making compose info push request")
                api_response = app_api.update_compose_app_app_uuid_compose_post(
                    app_uuid=self.app_id,
                    compose=compose_to_post
                )

            except ForbiddenException as oops:
                self.access_issue = 1
                print_space()
                print_text(">>> [red]You don't have access to this service yet.[/red]")
                print_text("  - Make sure your email is verified")
                print_text("  - Select a payment method via our app")
                print_text("  - You can also apply for free credits")
                print_text("     visit: https://celestical.eu/app ")
                self.logger.error(oops)
                print_space()
                return None

            except UnauthorizedException as oops:
                self.access_issue = 2
                print_space()
                print_text(">>> [red]Access not authorized for now[/red]")
                print_text(f"  - Check your account is verified: {self.user.username}")
                print_text("  - Make sure you have activated the service you want to use")
                print_text("  - Else it is us not you.")
                self.logger.error("ERROR in App.upload_compose() (create): "+ \
                        "unauthorized posting of enriched compose file " + \
                        "(potential API issue")
                self.logger.error(oops)
                print_space()
                return None

            except BadRequestException as oops:
                self.access_issue = 3
                print_space()
                print_text(">>> [red]Bad request[/red] to upload your compose file.")
                if len(compose_pack.get("app_url", "")) == 0:
                    print_text("  - Your app does not have a base domain.",
                               worry_level="oops")
                print_space()
                return None

            except ApiException as oops:
                self.access_issue = 4
                print_space()
                print_text(">>> [red]Wrong API communication[/red] no actions on your app.")
                print_text("  - Update celestical command line; pip install -U celestical")
                self.logger.error("ERROR in App.upload_compose(): "+ \
                        "ApiException posting the enriched compose file")
                self.logger.error(oops)
                print_space()
                return None

            except Exception as oops:
                self.access_issue = 5
                print_space()
                print_text(">>> [red]Undefined error during API communication[/red].")
                # TODO move to another Exception
                print_text("  - Check your Internet connection")
                self.logger.error(oops)
                print_space()
                return None

        if not isinstance(api_response, api.App):
            self.logger.error("API response is not an App.")
            msg = "Try to login again, your token might have expired.\n"
            msg += "--> [underline]celestical login[/underline]"
            cli_panel(msg)
            return None

        return api_response

    def upload_images(self) -> bool:
        """Upload the enriched compose file to the Celestical Cloud."""

        cli_panel("Now uploading your App's images to Celestical")

        e_compose = self.compose.ecompose
        if e_compose is None:
            return False

        # Build the compressed tar file for services images
        image_names = [
            e_compose["services"][service_name]["image"]
            for service_name in e_compose["services"]
        ]

        image_d = Image(config=self.config)

        # if "name" not in e_compose["celestical"]:
        #    self.logger.warning("Upload needs an APP name or domain")
        #    raise typer.Abort()

        image_paths, failed_images = image_d.compress_images(
            images=image_names,
            project_name=e_compose["celestical"].get("name", "_no-name_"))

        if len(failed_images) > 0:
            msg = ""
            for img in failed_images:
                msg += " - " + str(img) + "\n"
            if len(image_paths) > 0:
                _console.warning("Some images could not be found:")
            else:
                _console.warning("No image could be found:")
            _console.error(msg=msg, exit_code=0)
            return False

        # Upload images
        apiconf = self.user.get_api_with_auth()
        if apiconf is None:
            return False

        success_up = True
        with api.ApiClient(apiconf) as api_client:
            app_api = api.AppApi(api_client)
            for ipath in image_paths:
                this_success = self._upload_one_image(app_api, ipath)
                success_up = success_up and this_success

        return success_up

    def write_row(self, app_information: api.App):
        """ Print the basic app information """
        app_min_dict = {
            "url": app_information.url,
            "created_date": app_information.created_date,
            "id": app_information.id
            }

        print_console(write_app_row(app_min_dict,
                                    key=1))

    def delete_app(self):
        """ Delete the app which has the app_id"""
        # --- Retrieve app and delete
        app_information = self._get_app_from_api()

        if app_information is None:
            # Inform No app found
            print_text("No app found")
            self.logger.warning("No app found while delete app")
            return None

        # --- Acknowledgement on the selected app
        self.write_row(app_information)
        confirm_delete_app = confirm_user(
            "Do you want to [red]delete that app[/red]?",
            default=False)

        if confirm_delete_app is False:
            print_text("App not deleted")
            return None

        # --- Delete the ecompose folder
        msg = f"Deleting app {self.app_id}"
        self.logger.info(msg)

        app_path = self._get_app_dir()
        if app_path.is_dir():
            try:
                shutil.rmtree(app_path)
            except OSError as oops:
                msg = f"Issue: during app_dir  deletion {app_path}"
                self.logger.warning(msg)
                self.logger.warning(oops)

        # --- Delete the Database record
        delete_app_status = None

        apiconf = self.user.get_api_with_auth()
        if apiconf is None:
            self.logger.warning("App configuration not found")
            return delete_app_status

        try:
            with api.ApiClient(apiconf) as api_client:
                app_api = api.AppApi(api_client)
                # This endpoint returns nothing meaningful on success; avoid assignment
                app_api.delete_app_app_app_uuid_delete(self.app_id)
                delete_app_status = True
        except ApiException as oops:
            msg = f"Could not delete the app from api: {self.app_id}"
            self.logger.error(msg)
            self.logger.error(oops)

        print_feedback(f"App successfully deleted: {self.app_id}")
        return delete_app_status

    def _upload_one_image(self, app_api: api.AppApi, ipath: Path) -> bool:
        """Read a compressed image file and upload it, showing progress."""
        spinner = Spinner()
        try:
            file_size = ipath.stat().st_size
            file_bytes = bytearray()
            with ProgressBar(total_bytes=file_size,
                             description=f"Reading {ipath.name}") as progress_bar:
                with ipath.open(mode="rb") as fdesc:
                    while True:
                        chunk = fdesc.read(1024 * 1024)
                        if not chunk:
                            break
                        file_bytes.extend(chunk)
                        progress_bar.advance(len(chunk))
                progress_bar.complete()

            upfile = (ipath.name, bytes(file_bytes))
            self.logger.debug("Making image upload request")

            loading_msg = f"your image {ipath.name} is uploading"
            spinner.start(loading_msg)

            upload_method = (
                app_api
                .upload_image_compressed_file_app_app_uuid_image_post_with_http_info
            )
            api_ires = upload_method(
                app_uuid=self.app_id,
                image_file=upfile
            )

            spinner.stop()

            if api_ires is not None:
                status_text = " uploaded" if (api_ires.status_code == 200) else " not uploaded"
                print_feedback(f"{ipath.name}{status_text}")

        except (OSError, ApiException) as oops:
            if spinner.is_stopped is False:
                spinner.stop()
            self.logger.debug("Exception in uploading image %s", ipath)
            self.logger.debug(type(oops))
            print_text(f"Could not upload file {ipath.name}")
            return False

        return True
