import typer
from celestical.utils.display import cli_panel, print_text

def app_flexible_handler(ctx: typer.Context,
                         cmd_name: str,
                         args, kwargs) -> bool:
    """ Handling calls to client when no command name is registered Typically
    the app name with a subcommand like systemctl for linux services.

    Parameters:
        - ctx: typer context in which the handler is called
        - cmd_name: should be recognized as string with uuid characters and
          format.
        - args: usually empty
        - kwargs: all arguments after the app. the first one should be a verb
          like; start, stop, pause, delete
    """
    if len(cmd_name) < 3:
        print_text("Please give at least 3 characters of your app ID")
        return False

    # cmd_name is checked to be a app ID.
    print_text(f"APP Command: looking for app uuid containing {cmd_name}")
