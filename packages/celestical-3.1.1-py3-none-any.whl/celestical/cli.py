"""The CLI to interface with the Celestical European Serverless Cloud."""
import time
from typing import Optional
from pathlib import Path
import typer

from celestical.output import ConsoleOutput, get_output, set_output
from celestical.config import Config
from celestical.config.cli_config import FallbackGroup
from celestical.user import User
from celestical.services import SessionService
from celestical.utils.version_check import get_version, check_cli_version
import celestical.dashboard.layout as dashistical


user = User()
tui_version = get_version()
msg = f" ======= Starting Celestical TUI {tui_version}"
user.config.logger.info(msg)

openssl_version = "unknown"
try:
    import ssl
    openssl_version = ssl.OPENSSL_VERSION
    user.config.logger.info(f"  - OpenSSL version: {ssl.OPENSSL_VERSION}")
except Exception as e:
    user.config.logger.warning(e)


app = typer.Typer(
    pretty_exceptions_short=False,
    no_args_is_help=False,
    context_settings={"help_option_names": ["-h", "--help"]},
    help=user.welcome(),
    rich_markup_mode="rich",
    cls=FallbackGroup
)


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    quiet: bool = typer.Option(
        False,
        "--quiet", "-q",
        help="Suppress non-essential output"
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose", "-v",
        help="Enable verbose/debug output"
    )
) -> bool:
    """Celestical CLI - Deploy to the European Serverless Cloud."""
    ctx.obj = {"quiet": quiet, "verbose": verbose}
    set_output(ConsoleOutput(quiet=quiet, verbose=verbose))

    if ctx.invoked_subcommand is not None:
        return False

    output = get_output(quiet=quiet, verbose=verbose)
    output.info("Launching your Celestical Cloud dashboard...")
    dashboard = dashistical.Dashboard()
    dashboard.run()
    return True


@app.command()
def version(
    ctx: typer.Context,
    short: bool = typer.Option(
        False,
        "--short", "-s",
        help="Show only version number"
    )
) -> None:
    """Print version information."""
    output = ConsoleOutput(
        quiet=ctx.obj.get("quiet", False) if ctx.obj else False,
        verbose=ctx.obj.get("verbose", False) if ctx.obj else False
    )

    version_str = user.current_celestical_version

    if short:
        output.print(version_str)
    else:
        oneliner = f"celestical {version_str}"
        oneliner += f" (deps: {openssl_version})"
        output.print(oneliner)


@app.command()
def deploy(
    ctx: typer.Context,
    compose_path: Optional[str] = typer.Argument(
        default="./",
        help="Path to compose file or directory. Default: current directory"
    ),
    api_host: Optional[str] = typer.Option(
        default="",
        help="Custom API host (including port). For testing."
    ),
    api_scheme: Optional[str] = typer.Option(
        default="",
        help="Custom connection scheme (http/https). For testing."
    ),
    yes: bool = typer.Option(
        False,
        "--yes", "-y",
        help="Skip confirmation prompts"
    )
) -> None:
    """Deploy your docker-compose application to Celestical Cloud.
    
    Select or create an app, prepare it, and push images.
    """
    output = ConsoleOutput(
        quiet=ctx.obj.get("quiet", False) if ctx.obj else False,
        verbose=ctx.obj.get("verbose", False) if ctx.obj else False
    )

    if not check_cli_version():
        output.error("CLI version incompatible. Please update.")
        raise typer.Exit(1)

    compose_file = Path(compose_path) if compose_path else Path("./")

    if not compose_file.is_dir():
        if not compose_file.is_file():
            output.error(f"{compose_path} not found")
            raise typer.Exit(1)

    config = None
    if api_host and len(api_host) > 3:
        config = Config(host=api_host, scheme=api_scheme or "https")
    elif api_scheme and len(api_scheme) > 3:
        config = Config(scheme=api_scheme)

    # Don't wrap session init in progress - it may trigger login prompts
    session = SessionService(needs_login=True, config=config, output=output)

    # Don't wrap select_app in progress - it has interactive prompts
    selected = session.select_app()

    if not selected:
        output.error("Failed to select app")
        raise typer.Exit(1)

    if not session.check_docker_service():
        msg = "Docker is not running. Please start your docker service."
        output.warning(msg)
        if not yes:
            if not output.confirm(
                    "Continue when Docker is ready?",
                    default=False):
                raise typer.Exit(0)

    # auto-enriching
    with output.progress("Enriching your compose file..."):
        # TODO scan images hashes and use smart endpoint
        time.sleep(1.5)

    # double check auto-enrichment
    if session.app:
        enriched = session.app.enrich(Path(compose_path or "./"))
    else:
        enriched = False

    if not enriched:
        output.error("Failed to enrich compose file")
        raise typer.Exit(1)

    with output.progress("Pushing images to Celestical Cloud..."):
        if session.app:
            is_deployed = session.app.push()
        else:
            is_deployed = False

    app_domain = "unknown"
    if session.app and session.app.compose:
        app_domain = session.app.compose.get("base_domain") or "unknown"

    if is_deployed:
        output.success(f"All images uploaded for: {app_domain}")
        output.info("Check the dashboard: celestical")
    else:
        output.warning("Deployment incomplete. Follow the instructions above.")


@app.command("list")
def list_apps(
    ctx: typer.Context,
    format: str = typer.Option(
        "table",
        "--format", "-f",
        help="Output format: table, json, simple"
    )
) -> None:
    """List all your Celestical apps."""
    output = ConsoleOutput(
        quiet=ctx.obj.get("quiet", False) if ctx.obj else False,
        verbose=ctx.obj.get("verbose", False) if ctx.obj else False
    )

    if not check_cli_version():
        output.error("CLI version incompatible. Please update.")
        raise typer.Exit(1)

    session = SessionService(needs_login=True, output=output)

    with output.progress("Fetching apps..."):
        apps, status = session.get_apps()

    if not apps:
        output.info("No apps found. Deploy one with: celestical deploy")
        return

    if format == "json":
        import json
        output.print(json.dumps(apps, indent=2))
        return

    if format == "simple":
        for key, app in apps.items():
            url = app.get("url", "no-domain")
            app_id = app.get("id", "?")
            output.print(f"{key}: {url} ({app_id[:8]}...)")
        return

    app_list = []
    for key, app in apps.items():
        app_list.append({
            "#": key,
            "Domain": app.get("url", "-"),
            "ID": app.get("id", "-")[:12] + "...",
            "Created": app.get("created_date", "-")[:10] if app.get("created_date") else "-"
        })

    output.table(app_list, title="Your Celestical Apps")


@app.command()
def stop(
    ctx: typer.Context,
    app_id: str = typer.Argument(..., help="App ID or index to stop"),
    yes: bool = typer.Option(
        False,
        "--yes", "-y",
        help="Skip confirmation prompt"
    )
) -> None:
    """Stop a running Celestical app."""
    output = ConsoleOutput(
        quiet=ctx.obj.get("quiet", False) if ctx.obj else False,
        verbose=ctx.obj.get("verbose", False) if ctx.obj else False
    )

    if not check_cli_version():
        output.error("CLI version incompatible. Please update.")
        raise typer.Exit(1)

    if not yes:
        if not output.confirm(f"Stop app {app_id}?", default=False):
            output.info("Cancelled.")
            raise typer.Exit(0)

    session = SessionService(needs_login=True, output=output)

    with output.progress(f"Stopping app {app_id}..."):
        apps, _ = session.get_apps()

        selected_keys = session._select_apps_from_app_choice(apps, app_id)

        if not selected_keys:
            output.error(f"App '{app_id}' not found")
            raise typer.Exit(1)

        if len(selected_keys) > 1:
            output.warning("Multiple apps match. Please be more specific:")
            for key in selected_keys:
                app = apps[key]
                output.print(f"  {key}: {app.get('url', '?')} ({app.get('id', '?')[:8]}...)")
            raise typer.Exit(1)

        from celestical.app import App
        app_obj = App(
            app_id=apps[selected_keys[0]]["id"],
            user=session.user,
            config=session.config
        )
        result = app_obj.delete_app()

    if result:
        output.success(f"App {app_id} stopped")
    else:
        output.error(f"Failed to stop app {app_id}")


@app.command()
def login(ctx: typer.Context) -> None:
    """Login to Celestical Cloud Services."""
    output = ConsoleOutput(
        quiet=ctx.obj.get("quiet", False) if ctx.obj else False,
        verbose=ctx.obj.get("verbose", False) if ctx.obj else False
    )

    if not check_cli_version():
        output.error("CLI version incompatible. Please update.")
        raise typer.Exit(1)

    # Don't wrap login in progress - it has interactive prompts
    session = SessionService(needs_login=True, force_login=True, output=output)

    # there should always be a user object but logged in or out.
    if session.user is not None:
        output.print(session.user.to_rich())


@app.command()
def logout(ctx: typer.Context) -> None:
    """Logout from Celestical Cloud Services."""
    output = ConsoleOutput(
        quiet=ctx.obj.get("quiet", False) if ctx.obj else False,
        verbose=ctx.obj.get("verbose", False) if ctx.obj else False
    )

    if not check_cli_version():
        output.error("CLI version incompatible. Please update.")
        raise typer.Exit(1)

    session = SessionService(needs_login=False, force_login=False, output=output)
    session.logout()


@app.command()
def register(ctx: typer.Context) -> None:
    """Register a new user for Celestical Cloud Services."""
    output = ConsoleOutput(
        quiet=ctx.obj.get("quiet", False) if ctx.obj else False,
        verbose=ctx.obj.get("verbose", False) if ctx.obj else False
    )

    session = SessionService(
        needs_login=False,
        force_login=False,
        output=output)

    # Don't wrap register in progress - it has interactive prompts
    flag, username = session.user.user_register()

    config = session.user.config.load_config()

    if flag == 0:
        output.error("User could not be created.")
        raise typer.Exit(1)

    if flag in (1, 3):
        msg = ""
        if config.get('username') != username:
            msg = "You can now switch user to "
        else:
            msg = "You can now login with user "
        output.success(msg + username)
        output.info("Run: celestical login")
