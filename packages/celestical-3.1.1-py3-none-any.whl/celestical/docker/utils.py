"""Utilities for working with Docker images and their layers."""

from __future__ import annotations
import json
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Iterable, List, Optional

import docker
from docker.errors import DockerException, ImageNotFound


def _get_docker_client(timeout: int = 30) -> docker.DockerClient:
    """Get a Docker client instance."""
    try:
        client = docker.from_env(timeout=timeout)
        # Test connection
        client.ping()
        return client
    except DockerException as exc:
        raise RuntimeError(
            "Failed to connect to Docker daemon. Ensure Docker is running and accessible."
        ) from exc


def _run_docker_history(image: str, timeout: int = 30) -> Iterable[dict]:
    """Get Docker image history and yield entries as dictionaries."""

    if not image:
        raise ValueError("Image name must be provided.")

    client = _get_docker_client(timeout=timeout)
    
    try:
        # Get the image object
        img = client.images.get(image)
        
        # Get image history
        history = img.history()
        
        for entry in history:
            # Convert the history entry to match the format expected by existing code
            yield {
                "ID": entry.get("Id", ""),
                "CreatedBy": entry.get("CreatedBy", ""),
                "Created": entry.get("Created", ""),
                "Size": entry.get("Size", 0),
                "Comment": entry.get("Comment", "")
            }
            
    except ImageNotFound as exc:
        raise RuntimeError(
            f"Image {image!r} not found. Make sure the image exists locally or pull it first."
        ) from exc
    except DockerException as exc:
        raise RuntimeError(
            f"Failed to get history for image {image!r}: {exc}"
        ) from exc
    finally:
        client.close()


def get_image_layers(image: str, timeout: int = 30) -> List[str]:
    """Return the ordered list of layer IDs for the provided image name."""

    layers: List[str] = []
    for entry in _run_docker_history(image=image, timeout=timeout):
        layers.append(entry.get("ID", "").strip())
    return layers


