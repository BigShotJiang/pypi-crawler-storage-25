import socket
import random
import json
import threading
import platform
import subprocess
import os
import time
from concurrent.futures import ThreadPoolExecutor

CYAN = '\033[96m'
YELLOW = '\033[93m'
GREEN = '\033[92m'
RED = '\033[91m'
BOLD = '\033[1m'
RESET = '\033[0m'

class PairingSystem:
    def __init__(self, sec_mgr):
        self.sec_mgr = sec_mgr
        self.tcp_port = 55555
        self.active_pin = None
        self.hosting = False
        
        # Approval System
        self.pending_request_ip = None
        self.approval_event = threading.Event()
        self.is_approved = False

    def get_real_ip(self):
        """Forces the OS to reveal the true Wi-Fi IP, ignoring localhost."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80)) # Doesn't actually send data
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def check_and_start_ssh(self, port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        if s.connect_ex(('127.0.0.1', port)) == 0:
            s.close()
            return True, "SSH Server is already running."
        s.close()

        print(f"{YELLOW}SSH server not detected on port {port}. Attempting to start it...{RESET}")
        
        system = platform.system().lower()
        is_termux = "termux" in os.environ.get("PREFIX", "").lower()

        try:
            if is_termux:
                subprocess.run(["sshd"], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            elif system == "linux":
                subprocess.run(["sudo", "systemctl", "start", "ssh"], check=True)
            elif system == "windows":
                subprocess.run(["net", "start", "sshd"], check=True, capture_output=True)
            elif system == "darwin":
                subprocess.run(["sudo", "systemsetup", "-setremotelogin", "on"], check=True)
            else:
                return False, f"Unsupported OS for auto-start: {system}. Please start manually."
        except Exception:
            return False, "Failed to execute start command. Is OpenSSH installed?"

        time.sleep(2)
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        if s.connect_ex(('127.0.0.1', port)) == 0:
            s.close()
            return True, "SSH Server successfully started!"
        s.close()
        
        return False, f"Attempted to start SSH, but port {port} is still closed."

    def start_host(self, ssh_port, ssh_user, ssh_pass):
        self.ssh_port = ssh_port
        self.ssh_user = ssh_user
        self.ssh_pass = ssh_pass
        
        self.active_pin = str(random.randint(100000, 999999))
        self.hosting = True
        self.pending_request_ip = None
        
        real_ip = self.get_real_ip()
        
        print(f"\n{BOLD}{CYAN}Auto-Discovery Hosting Active!{RESET}")
        print(f"Your device IP is: {BOLD}{YELLOW}{real_ip}{RESET}")
        print(f"Tell the other device to enter Pairing Code: {BOLD}{YELLOW}{self.active_pin}{RESET}")

        threading.Thread(target=self._listen_for_pairing, daemon=True).start()

    def resolve_approval(self, approved):
        self.is_approved = approved
        self.approval_event.set()

    def stop_host(self):
        self.hosting = False
        self.active_pin = None
        self.pending_request_ip = None

    def _listen_for_pairing(self):
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        try:
            server.bind(("0.0.0.0", self.tcp_port))
            server.listen(1)
            server.settimeout(1)
        except Exception as e:
            print(f"\n{BOLD}{RED}[Error] Failed to bind hosting port: {str(e)}{RESET}")
            self.hosting = False
            return
        
        while self.hosting:
            try:
                client, addr = server.accept()
                data = client.recv(1024).decode()
                
                if data == self.active_pin:
                    self.pending_request_ip = addr[0]
                    self.approval_event.clear()
                    
                    client.send(b"WAITING_APPROVAL")
                    self.approval_event.wait(timeout=60)
                    
                    if self.is_approved:
                        try:
                            hostname = socket.gethostname()
                        except Exception:
                            hostname = "Unknown_Host"

                        creds = {
                            "hostname": hostname,
                            "port": self.ssh_port,
                            "user": self.ssh_user,
                            "password": self.ssh_pass
                        }
                        client.send(self.sec_mgr.encrypt(json.dumps(creds)).encode())
                        self.stop_host()
                    else:
                        client.send(b"REJECTED")
                        self.pending_request_ip = None
                else:
                    client.send(b"DENIED")
                
                client.close()
            except socket.timeout:
                continue
            except Exception:
                break
                
        server.close()

    def connect_with_pin(self, pin):
        local_ip = self.get_real_ip()
        if local_ip == "127.0.0.1":
            return False, "Not connected to a Wi-Fi network."
            
        base_ip = ".".join(local_ip.split(".")[:-1]) + "."
        target_ips = [f"{base_ip}{i}" for i in range(1, 255)]
        
        result_data = None
        
        def sweep_ip(ip):
            nonlocal result_data
            if result_data is not None: return
            
            try:
                client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                client.settimeout(0.3) # Very fast sweep
                
                if client.connect_ex((ip, self.tcp_port)) == 0:
                    client.settimeout(65.0) # Wait for human approval
                    client.send(pin.encode())
                    
                    response = client.recv(1024).decode()
                    if response == "WAITING_APPROVAL":
                        print(f"\n{BOLD}{GREEN}[!] Host found at {ip}!{RESET}")
                        print(f"{YELLOW}Waiting for the host device to accept your request...{RESET}")
                        
                        final_response = client.recv(2048).decode()
                        if final_response == "REJECTED":
                            result_data = (False, f"Connection rejected by the host at {ip}.")
                        elif final_response == "DENIED":
                            result_data = (False, "Incorrect PIN.")
                        elif final_response:
                            creds = json.loads(self.sec_mgr.decrypt(final_response))
                            creds['ip'] = ip
                            result_data = (True, creds)
                        else:
                            result_data = (False, "Host disconnected.")
                    elif response == "DENIED":
                        pass
                client.close()
            except Exception:
                pass

        with ThreadPoolExecutor(max_workers=75) as executor:
            executor.map(sweep_ip, target_ips)
            
        if result_data:
            return result_data
        return False, "No device found hosting with that PIN."
