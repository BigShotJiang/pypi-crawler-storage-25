import sys
import os
import time

# To use the notifier, we must ensure the path is correct
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tower.notifier import Notifier

AUTH_FILE = os.path.expanduser("~/.ssh_tower/pending_auth.token")

def verify():
    provided_token = os.environ.get("TOWER_TOKEN")
    remote_ip = os.environ.get("SSH_CONNECTION", "Unknown_IP").split()[0]

    # 1. No token = Immediate Block
    if not provided_token:
        Notifier.send("🚫 Unauthorized Access", f"Blocked standard SSH attempt from {remote_ip}")
        print("\n\033[91m[!] ACCESS DENIED: This device is locked by SSH Tower.")
        print("[!] Connect via the Tower Dashboard to gain access.\033[0m")
        sys.exit(1)

    # 2. Verify Token
    if os.path.exists(AUTH_FILE):
        with open(AUTH_FILE, "r") as f:
            data = f.read().strip().split("|")
            if len(data) == 2:
                valid_token, expiry = data
                
                # Check match and expiry (60 secs)
                if provided_token == valid_token and time.time() < float(expiry):
                    os.remove(AUTH_FILE) # Consume token
                    
                    Notifier.send("✅ Tower Access", f"Authorized connection from {remote_ip}")
                    
                    # 3. Launch Shell or Command
                    # If paramiko sent a specific command, run it. Otherwise, open a shell.
                    original_cmd = os.environ.get("SSH_ORIGINAL_COMMAND")
                    shell = os.environ.get("SHELL", "/data/data/com.termux/files/usr/bin/bash")
                    
                    if not os.path.exists(shell): shell = "/bin/sh" # Fallback for non-termux
                    
                    if original_cmd:
                        os.system(f"{shell} -c '{original_cmd}'")
                    else:
                        os.system(shell)
                    return

    Notifier.send("🚫 Unauthorized Access", f"Expired or invalid token from {remote_ip}")
    print("\n\033[91m[!] INVALID OR EXPIRED TOKEN.\033[0m")
    sys.exit(1)

if __name__ == "__main__":
    verify()
