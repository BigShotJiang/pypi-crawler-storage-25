import sys, os
import getpass
import time, subprocess, signal
from tower.security import SecurityManager
from tower.scanner import NetworkScanner
from tower.ssh_manager import SSHSession
from tower.pairing import PairingSystem
from tower.daemon import TowerDaemon, run_daemon_debug

# ANSI Colors
CYAN = '\033[96m'
MAGENTA = '\033[95m'
YELLOW = '\033[93m'
GREEN = '\033[92m'
RED = '\033[91m'
BLUE = '\033[94m'
BOLD = '\033[1m'
RESET = '\033[0m'

sec_mgr = SecurityManager()
session = SSHSession(sec_mgr)
pairing = PairingSystem(sec_mgr)

def print_banner():
    print(f"\n{CYAN}{'='*50}{RESET}")
    print(f"{BOLD}{CYAN}   SSH tower{RESET} - Advanced Remote Management Tool")
    print(f"{CYAN}{'='*50}{RESET}\n")

def is_daemon_running():
    """Checks if the background daemon is alive and valid."""
    pid_file = os.path.expanduser("~/.ssh_tower/daemon.pid")
    if not os.path.exists(pid_file):
        return False, None
        
    try:
        with open(pid_file, "r") as f:
            pid = int(f.read().strip())
        
        # Signal 0 checks if the process is alive without killing it
        os.kill(pid, 0)
        return True, pid
    except (ProcessLookupError, ValueError, OSError, OverflowError):
        # File exists but process is dead, clean up the stale file
        if os.path.exists(pid_file):
            try:
                os.remove(pid_file)
            except:
                pass
        return False, None

def toggle_daemon():
    """Starts or Stops the background daemon with Termux-specific path fixes."""
    running, pid = is_daemon_running()
    
    if running:
        print(f"{YELLOW}Stopping background service (PID: {pid})...{RESET}")
        try:
            os.kill(pid, 15) # SIGTERM
            time.sleep(0.5)
            print(f"{GREEN}Service stopped.{RESET}")
        except Exception as e:
            print(f"{RED}Error: {e}{RESET}")
    else:
        print(f"{YELLOW}Launching Background Alert Service...{RESET}")
        
        # 1. Get the absolute path to the directory CONTAINING the 'tower' folder
        # This is crucial for Python to find your module.
        current_dir = os.path.dirname(os.path.abspath(__file__))
        parent_dir = os.path.dirname(current_dir)
        
        # 2. Setup environment variables to include this path
        env = os.environ.copy()
        env["PYTHONPATH"] = parent_dir + os.pathsep + env.get("PYTHONPATH", "")

        # 3. Setup a debug log to catch early crashes (ImportErrors, etc.)
        # 3. Setup a debug log
        debug_log_path = os.path.expanduser("~/.ssh_tower/daemon_debug.log")
        os.makedirs(os.path.dirname(debug_log_path), exist_ok=True)
        
        try:
            # DO NOT use 'with open' here. Let the subprocess own the file!
            f_err = open(debug_log_path, "a")
            
            subprocess.Popen(
                [sys.executable, "-m", "tower.daemon_launcher"], 
                stdout=f_err, 
                stderr=f_err, 
                env=env,      
                start_new_session=True, 
                cwd=parent_dir 
            )
            
            # 4. Verification loop
            print(f"{CYAN}Verifying startup...{RESET}", end="", flush=True)
            for _ in range(6):
                time.sleep(0.5)
                print(".", end="", flush=True)
                running, _ = is_daemon_running()
                if running: break
            
            if running:
                print(f"\n{BOLD}{GREEN}Service is now ACTIVE!{RESET}")
            else:
                print(f"\n{RED}Service failed to start.{RESET}")
                
        except Exception as e:
            print(f"\n{RED}Launcher error: {e}{RESET}")

def file_manager_menu():
    print(f"\n{BOLD}{MAGENTA}--- File Manager ---{RESET}")
    print("1. List Files (Remote)")
    print("2. Download File")
    print("3. Upload File")
    print("4. Back")
    
    choice = input("\nSelect: ").strip()
    sftp = session.get_sftp()
    
    if choice == "1":
        path = input("Remote Path (Default '.'): ") or "."
        try:
            files = sftp.listdir(path)
            print(f"\n{CYAN}Files in {path}:{RESET}")
            for f in files: print(f" - {f}")
        except Exception as e: print(f"{RED}Error: {e}{RESET}")
        
    elif choice == "2":
        rem = input("Remote filename: ")
        loc = input("Save as (Local): ")
        success, msg = session.download_file(rem, loc)
        print(GREEN if success else RED, msg, RESET)

    elif choice == "3":
        loc = input("Local filename: ")
        rem = input("Save as (Remote): ")
        success, msg = session.upload_file(loc, rem)
        print(GREEN if success else RED, msg, RESET)

def broadcast_tools_menu():
    # Detect OS to pick right commands
    os_info = session.execute("uname -a").lower()
    from tower.remote_ops import RemoteOps
    
    print(f"\n{BOLD}{CYAN}--- Broadcast & Hardware Tools ---{RESET}")
    print("1. Capture Remote Photo")
    print("2. Get Remote GPS Location")
    print("3. System Information Broadcast")
    print("4. Back")

    choice = input("\nSelect: ").strip()
    
    if choice == "1":
        print(f"{YELLOW}Capturing photo...{RESET}")
        session.execute(RemoteOps.get_camera_cmd(os_info))
        # Now download the photo automatically
        session.download_file("output.jpg", "remote_capture.jpg")
        print(f"{GREEN}Photo saved locally as 'remote_capture.jpg'{RESET}")
        
    elif choice == "2":
        print(f"{YELLOW}Requesting GPS...{RESET}")
        out = session.execute(RemoteOps.get_gps_cmd(os_info))
        print(f"{CYAN}Location Data:{RESET}\n{out}")

    elif choice == "3":
        out = session.execute(RemoteOps.get_info_cmd())
        print(f"{CYAN}Broadcast Info:{RESET}\n{out}")

def toggle_lockdown():
    # Dynamically find Termux or Linux sshd config
    prefix = os.environ.get("PREFIX", "/data/data/com.termux/files/usr")
    sshd_config = f"{prefix}/etc/ssh/sshd_config"
    
    import tower.gatekeeper
    gatekeeper_module_path = os.path.abspath(tower.gatekeeper.__file__)
    
    if not os.path.exists(sshd_config):
        print(f"{RED}Cannot find sshd_config at {sshd_config}. Is OpenSSH installed?{RESET}")
        return

    try:
        with open(sshd_config, "r") as f:
            config = f.read()
            
        if "gatekeeper.py" in config:
            # UNLOCK THE DEVICE
            print(f"{YELLOW}Deactivating Lockdown...{RESET}")
            new_config = "\n".join([line for line in config.splitlines() if "gatekeeper.py" not in line and "AcceptEnv TOWER_TOKEN" not in line])
            with open(sshd_config, "w") as f:
                f.write(new_config)
            print(f"{BOLD}{GREEN}Device is now UNLOCKED. Standard SSH is allowed.{RESET}")
        else:
            # LOCK THE DEVICE
            print(f"{YELLOW}Activating Tower Lockdown...{RESET}")
            with open(sshd_config, "a") as f:
                # Add Python path explicitly
                f.write(f"\nAcceptEnv TOWER_TOKEN\nForceCommand {sys.executable} {gatekeeper_module_path}\n")
            print(f"{BOLD}{RED}LOCKDOWN ACTIVE.{RESET}")
            print(f"{CYAN}Standard SSH connections will now be blocked!{RESET}")
            
        # Restart SSHD to apply changes
        subprocess.run(["pkill", "sshd"], check=False)
        subprocess.run(["sshd"], check=False)
    except Exception as e:
        print(f"{RED}Error modifying sshd_config: {e}{RESET}")

def start_daemon_mode():
    print(f"{GREEN}Starting Tower Daemon in background...{RESET}")
    print(f"{CYAN}Alerts are now ACTIVE. You can close this terminal.{RESET}")
    
    # Use 'nohup' logic to keep it running even if terminal closes
    daemon = TowerDaemon()
    daemon.start()

def scan_network_menu():
    print(f"{YELLOW}Initiating network discovery (Checking devices & SSH ports)...{RESET}")
    print(f"{MAGENTA}Please wait roughly 5-10 seconds...{RESET}")
    
    hosts = NetworkScanner.scan_network()
    
    if not hosts:
        print(f"{RED}No online devices found on the local network.{RESET}\n")
        return

    print(f"\n{BOLD}{CYAN}{'IP Address'.ljust(16)} {GREEN}{'SSH Status'.ljust(15)} {MAGENTA}Hostname{RESET}")
    print("-" * 55)
    
    for h in hosts:
        if h['ports']:
            # Device is online and SSH is OPEN
            ports_str = f"OPEN ({','.join(map(str, h['ports']))})"
            status_color = GREEN
        else:
            # Device is online but SSH is CLOSED
            ports_str = "Closed/Filtered"
            status_color = RED
            
        print(f"{CYAN}{h['ip'].ljust(16)}{RESET} {status_color}{ports_str.ljust(15)}{RESET} {MAGENTA}{h['hostname']}{RESET}")
    print(f"\n{YELLOW}Note: To connect to a device, you must start an SSH server on it first (e.g., 'sshd' in Termux or 'sudo systemctl start ssh' on Linux).{RESET}\n")

def connect_ssh_menu():
    profiles = list(sec_mgr.db["profiles"].keys())
    if not profiles:
        print(f"{RED}No profiles found. Add one first.{RESET}\n")
        return
    
    for idx, p in enumerate(profiles):
        print(f"[{idx}] {p} ({sec_mgr.db['profiles'][p]['ip']})")
    
    try:
        choice = int(input(f"\nSelect profile index: "))
        if 0 <= choice < len(profiles):
            name = profiles[choice]
            prof = sec_mgr.db["profiles"][name]
            print(f"{YELLOW}Connecting to {name}...{RESET}")
            success, msg = session.connect(name, prof)
            
            if success:
                print(f"{BOLD}{GREEN}Connection Established!{RESET}\n")
                session_menu()
            else:
                print(f"{BOLD}{RED}Failed: {msg}{RESET}\n")
        else:
            print(f"{RED}Invalid index.{RESET}\n")
    except ValueError:
        print(f"{RED}Please enter a valid number.{RESET}\n")

def session_menu():
    while session.connected:
        # Calculate how long the connection has been active
        duration_seconds = int(time.time() - session.start_time)
        mins, secs = divmod(duration_seconds, 60)
        time_str = f"{mins}m {secs}s"
        
        print(f"\n{BOLD}{BLUE}--- Active Session Menu ---{RESET}")
        print(f"{BOLD}{GREEN}► Connected with {session.current_user} at {session.current_ip} (Time: {time_str}){RESET}\n")
        
        print("1. Open Live SSH Terminal")
        print("2. File Manager (SFTP)")      
        print("3. Broadcast Tools (Camera/GPS)") 
        print("4. Execute Single Command")
        print("5. Freeze Device")
        print("6. Disconnect")
        
        choice = input(f"\nSelect action (1/2/3/4): ").strip()
        
        if choice == "1":
            # Opens a real, interactive terminal where nano/top/sudo work perfectly
            session.interactive_shell()
        elif choice == "2": file_manager_menu()
        elif choice == "3": broadcast_tools_menu()
        elif choice == "4":
            cmd = input("Enter command: ")
            out = session.execute(cmd)
            print(f"\n{GREEN}--- Output ---{RESET}\n{out}\n{GREEN}--------------{RESET}")
            
        elif choice == "5":
            session.freeze_device()
            print(f"{BOLD}{RED}Device Frozen (CPU spiked via dummy process).{RESET}")
            
        elif choice == "6":
            session.disconnect()
            print(f"{YELLOW}Disconnected.{RESET}\n")
        else:
            print(f"{RED}Invalid option.{RESET}")

def add_profile_menu():
    print(f"{BOLD}--- Add New SSH Profile ---{RESET}")
    name = input("Profile Name: ")
    ip = input("IP Address: ")
    port = input("Port (Default 22, Termux 8022): ").strip()
    port = int(port) if port.isdigit() else 22
    user = input("Username: ")
    
    auth_type = ""
    while auth_type not in ["1", "2"]:
        auth_type = input("Auth Type [1=Password, 2=Key]: ").strip()
    
    if auth_type == "1":
        pwd = getpass.getpass("Password (hidden): ")
        sec_mgr.add_profile(name, ip, port, user, password=pwd)
    else:
        k_path = input("Private Key Path: ")
        sec_mgr.add_profile(name, ip, port, user, key_path=k_path)
    
    print(f"{BOLD}{GREEN}Profile Saved!{RESET}\n")

def pairing_menu():
    print(f"\n{BOLD}--- Auto-Discovery Pairing System ---{RESET}")
    print("1. Host a Pairing Session (Share your SSH access)")
    print("2. Connect using a Pairing Code")
    choice = input("\nSelect (1/2): ").strip()
    
    if choice == "1":
        print(f"\n{YELLOW}To allow a device to connect, provide your current SSH details:{RESET}")
        
        port_input = input("Your SSH Port (Default 22, Termux 8022): ").strip()
        port = int(port_input) if port_input.isdigit() else 22
        user = input("Your SSH Username: ").strip()
        pwd = getpass.getpass("Your SSH Password (hidden): ")
        
        print(f"\n{YELLOW}Verifying SSH Server status on port {port}...{RESET}")
        ssh_running, ssh_msg = pairing.check_and_start_ssh(port)
        
        if not ssh_running:
            print(f"{BOLD}{RED}[Error] {ssh_msg}{RESET}")
            print(f"{RED}Aborting. Please ensure OpenSSH is installed and running.{RESET}\n")
            return
            
        print(f"{BOLD}{GREEN}[Success] {ssh_msg}{RESET}")

        try:
            pairing.start_host(port, user, pwd)
            print(f"\n{MAGENTA}Waiting for incoming connections... (Press CTRL+C to stop hosting){RESET}\n")
            
            # Non-blocking loop waiting for connections or Ctrl+C
            while pairing.hosting:
                if pairing.pending_request_ip:
                    print(f"\n{BOLD}{GREEN}[!] INCOMING CONNECTION REQUEST{RESET}")
                    ans = input(f"{YELLOW}A device at {pairing.pending_request_ip} wants to connect. Accept? (y/n): {RESET}").strip().lower()
                    
                    if ans == 'y':
                        pairing.resolve_approval(True)
                        print(f"{GREEN}Access Granted. Credentials sent safely.{RESET}\n")
                    else:
                        pairing.resolve_approval(False)
                        print(f"{RED}Request Rejected.{RESET}\n")
                        
                time.sleep(0.5)
                
        except KeyboardInterrupt:
            # THIS safely catches Ctrl+C without crashing the app!
            pass
        except Exception as e:
            print(f"{BOLD}{RED}Failed to start hosting: {e}{RESET}\n")
        finally:
            pairing.stop_host()
            print(f"\n{YELLOW}Hosting stopped. Returning to menu...{RESET}\n")
        
    elif choice == "2":
        pin = input("\nEnter the 6-digit Pairing Code: ").strip()
        if not pin:
            print(f"{RED}PIN cannot be empty.{RESET}\n")
            return
            
        print(f"{YELLOW}Scanning local network for the Host... (This takes 1-3 seconds){RESET}")
        
        success, data = pairing.connect_with_pin(pin)
        
        if success:
            hostname = data.get("hostname", "Unknown")
            port = data.get("port", 22)
            user = data.get("user")
            pwd = data.get("password")
            target_ip = data.get("ip")
            
            print(f"{BOLD}{GREEN}Paired Successfully! Received access for {hostname} ({target_ip}) on port {port}.{RESET}")
            
            profile_name = f"{hostname}_{target_ip}"
            sec_mgr.add_profile(profile_name, target_ip, port, user, password=pwd)
            
            connect_now = input(f"\nDo you want to connect to {hostname} right now? (y/n): ").strip().lower()
            if connect_now == 'y':
                print(f"{YELLOW}Establishing SSH connection to {target_ip}:{port}...{RESET}")
                c_success, msg = session.connect(profile_name, sec_mgr.db["profiles"][profile_name])
                
                if c_success:
                    print(f"{BOLD}{GREEN}SSH Connection Established!{RESET}\n")
                    session_menu()
                else:
                    print(f"{BOLD}{RED}SSH Connection Failed: {msg}{RESET}\n")
        else:
            print(f"{BOLD}{RED}Pairing Error: {data}{RESET}\n")

def main():
    while True:
        print_banner()
        daemon_active, _ = is_daemon_running()
        daemon_status = f"{GREEN}[ACTIVE]{RESET}" if daemon_active else f"{RED}[OFF]{RESET}"

        prefix = os.environ.get("PREFIX", "/data/data/com.termux/files/usr")
        try:
            with open(f"{prefix}/etc/ssh/sshd_config", "r") as f:
                is_locked = "gatekeeper.py" in f.read()
        except: is_locked = False
        lock_status = f"{RED}[LOCKED]{RESET}" if is_locked else f"{GREEN}[UNLOCKED]{RESET}"

        print("1. Connect to Profile")
        print("2. Add Profile")
        print(f"3. Scan Network {GREEN}(High-Speed){RESET}")
        print(f"4. AirDrop Pairing {MAGENTA}(Auto-Discovery){RESET}")
        print(f"5. Background Alert Service {daemon_status}")
        print("6. Test Notification System")
        print("7. Recent Connections History")
        print("8. Exit")
        print(f"{YELLOW}9. Run Daemon in Debug Mode (Foreground){RESET}")
        print(f"{MAGENTA}10. Toggle Device Lockdown Security {lock_status}{RESET}") # NEW OPTION

        choice = input(f"\n{BOLD}Choose an option:{RESET} ").strip()
        print()
        
        if choice == "1": connect_ssh_menu()
        elif choice == "2": add_profile_menu()
        elif choice == "3": scan_network_menu()
        elif choice == "4": pairing_menu()
        elif choice == "5": toggle_daemon(); input("\nPress Enter to return to menu...")
        elif choice == "6":
            print(f"{YELLOW}Sending test notification...{RESET}")
            from tower.notifier import Notifier
            Notifier.send("Tower Test", "If you see this, notifications are working!")
            print(f"{GREEN}Done. If you didn't see a popup, check Termux:API permissions.{RESET}")
        elif choice == "7":
            print(f"{BOLD}--- Recent Connections ---{RESET}")
            print(f"{CYAN}{'Name'.ljust(15)} {MAGENTA}{'IP'.ljust(15)} {GREEN}Duration{RESET}")
            print("-" * 45)
            for h in sec_mgr.db["history"]:
                print(f"{CYAN}{h['name'].ljust(15)}{RESET} {MAGENTA}{h['ip'].ljust(15)}{RESET} {GREEN}{h['duration']}{RESET}")
            print()
        elif choice == "8":
            print(f"{YELLOW}Exiting SSH tower...{RESET}")
            sys.exit(0)
        elif choice == "9": # NEW BLOCK
            # This will block the menu and print EVERYTHING the daemon is doing
            run_daemon_debug()
            input(f"\n{MAGENTA}Debug ended. Press Enter to return to menu...{RESET}")
        elif choice == "10":
            toggle_lockdown()
            input("\nPress Enter to return to menu...")
        else:
            print(f"{RED}Invalid option. Try again.{RESET}")

if __name__ == "__main__":
    main()
