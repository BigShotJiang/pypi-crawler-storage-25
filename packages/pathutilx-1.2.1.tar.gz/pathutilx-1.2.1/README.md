# pathutilx

![PyPI](https://img.shields.io/pypi/v/pathutilx.svg)
![Python Versions](https://img.shields.io/pypi/pyversions/pathutilx.svg)
![Status](https://img.shields.io/badge/status-production%20stable-brightgreen.svg)
![OS](https://img.shields.io/badge/os-windows-blue.svg)

`pathutilx` is a lightweight Python package for readable Windows path shortcuts and helpers. It makes it easy to build paths, resolve common Windows folder locations, and perform directory listing and search operations consistently.

## Install

```bash
pip install pathutilx
```

## Quick Start

```python
from pathutilx import desktop, join

notes = join("notes.txt", base=desktop)
print(notes)
```

```python
import pathutilx as p

print(p.downloads)
print(p.appdata.local)
print(p.cwd)
```

```python
from pathutilx import listdir, search, documents

items = listdir(documents)
print(items)

matches = search("*.docx", documents)
print(matches)
```

## Features

- `build(*parts, base=None)` — build a normalized path from parts
- `join(*parts, base=None)` — alias for `build`
- `listdir(*parts, base=None)` — list files and folders in a directory
- `search(pattern, *parts, base=None, recursive=True)` — search names using glob patterns
- `win_root()` — access common Windows system folders
- `windows_root()` — backward-compatible alias for `win_root()`
- Direct access to common Windows locations such as `desktop`, `downloads`, `documents`, `appdata`, `temp`, and more
- `cwd` — current working directory path node

## Usage

Use `win_root()` to access common Windows folders from the package root object:

```python
import pathutilx as p

print(p.win_root().desktop)
print(p.win_root().appdata.local)
```

Use `listdir()` and `search()` to explore filesystem contents:

```python
from pathutilx import listdir, search, desktop

for item in listdir(desktop):
    print(item)

for item in search("*.txt", desktop, recursive=False):
    print(item)
```

## Changelog

### 1.2.1:
- Better README

## Roadmap

### 1.3.0:
- Linux and macOS support
- More Windows folders support

### 1.3.1:
- Bugfixes and optimizations