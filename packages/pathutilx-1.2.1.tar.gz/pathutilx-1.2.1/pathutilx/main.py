from .finder.windows import (
    PathNode,
    build_path,
    listdir as _listdir,
    search as _search,
    win_root,
    windows_root as _windows_root,
)


_windows = win_root()

appdata = _windows.appdata
cwd = _windows.cwd
contacts = _windows.contacts
desktop = _windows.desktop
documents = _windows.documents
downloads = _windows.downloads
favorites = _windows.favorites
home = _windows.home
links = _windows.links
music = _windows.music
pictures = _windows.pictures
program_files = _windows.program_files
program_files_x86 = _windows.program_files_x86
program_data = _windows.program_data
public = _windows.public
saved_games = _windows.saved_games
system32 = _windows.system32
system_drive = _windows.system_drive
temp = _windows.temp
tmp = _windows.tmp
user_profile = _windows.user_profile
videos = _windows.videos
windows_dir = _windows.windows_dir


def build(*parts, base=None):
    return build_path(*parts, base=base)


def join(*parts, base=None):
    return build(*parts, base=base)


def listdir(*parts, base=None):
    return _listdir(*parts, base=base)


def search(pattern, *parts, base=None, recursive=True):
    return _search(pattern, *parts, base=base, recursive=recursive)


def windows_root():
    return _windows_root()


__all__ = [
    "PathNode",
    "appdata",
    "build",
    "cwd",
    "contacts",
    "desktop",
    "documents",
    "downloads",
    "favorites",
    "home",
    "join",
    "links",
    "music",
    "pictures",
    "program_data",
    "program_files",
    "program_files_x86",
    "public",
    "saved_games",
    "system32",
    "system_drive",
    "temp",
    "tmp",
    "user_profile",
    "videos",
    "windows_dir",
    "win_root",
    "windows_root",
    "listdir",
    "search",
]
