import os
import tempfile
import unittest
from pathlib import Path

import pathutilx as p


class TestPathUtilX(unittest.TestCase):
    def test_build_and_join(self):
        self.assertEqual(p.build("foo", "bar"), Path("foo") / "bar")
        self.assertEqual(p.join("foo", "bar"), Path("foo") / "bar")

    def test_build_with_base_paths(self):
        root = Path("/tmp")
        self.assertEqual(p.build("hello.txt", base=root), root / "hello.txt")
        self.assertEqual(p.build("foo", "bar", base=p.win_root().cwd), Path.cwd() / "foo" / "bar")

    def test_build_raises_without_parts_or_base(self):
        with self.assertRaises(ValueError):
            p.build()

    def test_pathnode_file_and_directory_metadata(self):
        with tempfile.TemporaryDirectory() as tempdir:
            temp_path = Path(tempdir)
            file_path = temp_path / "file.txt"
            dir_path = temp_path / "subdir"
            dir_path.mkdir()
            file_path.write_text("x")

            file_node = p.PathNode(file_path)
            dir_node = p.PathNode(dir_path)

            self.assertTrue(file_node.exists())
            self.assertTrue(file_node.is_file())
            self.assertFalse(file_node.is_dir())
            self.assertEqual(file_node.name, "file.txt")
            self.assertEqual(file_node.parent, file_path.parent)

            self.assertTrue(dir_node.exists())
            self.assertTrue(dir_node.is_dir())
            self.assertFalse(dir_node.is_file())
            self.assertEqual(dir_node.name, "subdir")
            self.assertEqual(dir_node.parent, dir_path.parent)

    def test_pathnode_operations(self):
        with tempfile.TemporaryDirectory() as tempdir:
            temp_path = Path(tempdir)
            node = p.PathNode(temp_path, child=p.PathNode(temp_path / "child"))

            self.assertEqual(node.build("subdir"), temp_path / "subdir")
            self.assertEqual(node.joinpath("subdir"), temp_path / "subdir")
            self.assertEqual(node("subdir", "file.txt"), temp_path / "subdir" / "file.txt")
            self.assertEqual(node / "subdir", temp_path / "subdir")
            self.assertEqual(os.fspath(node), str(temp_path))
            self.assertEqual(str(node), str(temp_path))
            self.assertEqual(repr(node), f"PathNode({temp_path})")
            self.assertTrue(hasattr(node, "child"))
            self.assertEqual(node.child.path, temp_path / "child")

    def test_win_root_aliases(self):
        self.assertTrue(callable(p.win_root))
        self.assertTrue(callable(p.windows_root))
        self.assertEqual(p.windows_root().home.path, p.win_root().home.path)

    def test_listdir_returns_paths(self):
        with tempfile.TemporaryDirectory() as tempdir:
            temp_path = Path(tempdir)
            (temp_path / "file1.txt").write_text("x")
            (temp_path / "subdir").mkdir()

            entries = p.listdir(temp_path)
            self.assertIsInstance(entries, list)
            self.assertEqual({entry.name for entry in entries}, {"file1.txt", "subdir"})
            self.assertTrue(all(isinstance(item, Path) for item in entries))

    def test_listdir_with_pathnode_base(self):
        with tempfile.TemporaryDirectory() as tempdir:
            temp_path = Path(tempdir)
            node = p.PathNode(temp_path)
            (temp_path / "file2.txt").write_text("x")

            entries = p.listdir(base=node)
            self.assertEqual(len(entries), 1)
            self.assertEqual(entries[0].name, "file2.txt")

    def test_search_with_pathnode_base(self):
        with tempfile.TemporaryDirectory() as tempdir:
            temp_path = Path(tempdir)
            node = p.PathNode(temp_path)
            (temp_path / "x.log").write_text("x")
            (temp_path / "y.txt").write_text("y")

            results = p.search("*.txt", base=node)
            self.assertEqual([item.name for item in results], ["y.txt"])

    def test_listdir_errors(self):
        with self.assertRaises(FileNotFoundError):
            p.listdir("nonexistent-directory")

        with tempfile.TemporaryDirectory() as tempdir:
            temp_path = Path(tempdir)
            file_path = temp_path / "file.txt"
            file_path.write_text("x")
            with self.assertRaises(NotADirectoryError):
                p.listdir(file_path)

    def test_search_multiple_patterns(self):
        with tempfile.TemporaryDirectory() as tempdir:
            temp_path = Path(tempdir)
            (temp_path / "a.txt").write_text("a")
            (temp_path / "b.py").write_text("b")
            (temp_path / "c.md").write_text("c")
            results = p.search(["*.txt", "*.py"], temp_path, recursive=False)
            self.assertEqual({item.name for item in results}, {"a.txt", "b.py"})

    def test_search_recursive_behavior(self):
        with tempfile.TemporaryDirectory() as tempdir:
            temp_path = Path(tempdir)
            nested = temp_path / "nested"
            nested.mkdir()
            (nested / "nested.txt").write_text("x")
            (temp_path / "root.txt").write_text("x")

            non_recursive = p.search("*.txt", temp_path, recursive=False)
            self.assertEqual({item.name for item in non_recursive}, {"root.txt"})

            recursive = p.search("*.txt", temp_path, recursive=True)
            self.assertEqual({item.name for item in recursive}, {"root.txt", "nested.txt"})

    def test_search_errors(self):
        with self.assertRaises(FileNotFoundError):
            p.search("*.txt", "does-not-exist")

        with tempfile.TemporaryDirectory() as tempdir:
            temp_path = Path(tempdir)
            file_path = temp_path / "file.txt"
            file_path.write_text("x")
            with self.assertRaises(NotADirectoryError):
                p.search("*.txt", file_path)

    def test_cwd_is_current_working_directory(self):
        self.assertEqual(Path.cwd(), Path(p.cwd.path))


if __name__ == "__main__":
    unittest.main()
