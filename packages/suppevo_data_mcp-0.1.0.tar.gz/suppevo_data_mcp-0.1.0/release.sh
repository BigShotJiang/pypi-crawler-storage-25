#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# Interactive Release Script for suppevo-mcp
# =============================================================================

PYPROJECT="pyproject.toml"
CHANGELOG="CHANGELOG.md"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

info()  { echo -e "${BLUE}ℹ${NC}  $*"; }
ok()    { echo -e "${GREEN}✓${NC}  $*"; }
warn()  { echo -e "${YELLOW}⚠${NC}  $*"; }
error() { echo -e "${RED}✗${NC}  $*"; exit 1; }

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

get_current_version() {
    grep -m1 '^version' "$PYPROJECT" | sed 's/version = "//;s/"//'
}

set_version() {
    local new_version="$1"
    sed -i '' "s/^version = \".*\"/version = \"${new_version}\"/" "$PYPROJECT"
}

bump_version() {
    local current="$1" part="$2"
    IFS='.' read -r major minor patch <<< "$current"
    case "$part" in
        major) echo "$((major + 1)).0.0" ;;
        minor) echo "${major}.$((minor + 1)).0" ;;
        patch) echo "${major}.${minor}.$((patch + 1))" ;;
        *) echo "$current" ;;
    esac
}

generate_changelog() {
    local version="$1"
    local date
    date=$(date +%Y-%m-%d)

    # Get commits since last tag (or all commits if no tags)
    local last_tag
    last_tag=$(git describe --tags --abbrev=0 2>/dev/null || echo "")

    local commits
    if [[ -n "$last_tag" ]]; then
        commits=$(git log "${last_tag}..HEAD" --pretty=format:"%s" 2>/dev/null || echo "")
    else
        commits=$(git log --pretty=format:"%s" 2>/dev/null || echo "")
    fi

    if [[ -z "$commits" ]]; then
        warn "No commits found for changelog generation."
        echo "## [${version}] - ${date}"
        echo ""
        echo "### Changed"
        echo "- Release ${version}"
        return
    fi

    local added="" fixed="" changed=""

    while IFS= read -r msg; do
        [[ -z "$msg" ]] && continue
        if [[ "$msg" =~ ^feat ]]; then
            msg="${msg#feat:}"
            msg="${msg#feat(*)}"
            msg="${msg#: }"
            added="${added}\n- ${msg}"
        elif [[ "$msg" =~ ^fix ]]; then
            msg="${msg#fix:}"
            msg="${msg#fix(*)}"
            msg="${msg#: }"
            fixed="${fixed}\n- ${msg}"
        else
            # Strip conventional commit prefix if present
            msg=$(echo "$msg" | sed 's/^[a-z]*\([^)]*\): //' | sed 's/^[a-z]*: //')
            changed="${changed}\n- ${msg}"
        fi
    done <<< "$commits"

    echo "## [${version}] - ${date}"
    echo ""
    if [[ -n "$added" ]]; then
        echo "### Added"
        echo -e "$added"
        echo ""
    fi
    if [[ -n "$fixed" ]]; then
        echo "### Fixed"
        echo -e "$fixed"
        echo ""
    fi
    if [[ -n "$changed" ]]; then
        echo "### Changed"
        echo -e "$changed"
        echo ""
    fi
}

# ---------------------------------------------------------------------------
# Pre-flight checks
# ---------------------------------------------------------------------------

info "Checking prerequisites..."

command -v python3 >/dev/null 2>&1 || error "python3 not found"
command -v git >/dev/null 2>&1 || error "git not found"
[[ -f "$PYPROJECT" ]] || error "$PYPROJECT not found. Run from project root."

# Check git status
if [[ -n "$(git status --porcelain 2>/dev/null)" ]]; then
    warn "Working directory has uncommitted changes."
    read -rp "Continue anyway? [y/N] " confirm
    [[ "$confirm" =~ ^[Yy]$ ]] || exit 0
fi

CURRENT_VERSION=$(get_current_version)
ok "Current version: ${CURRENT_VERSION}"

# ---------------------------------------------------------------------------
# Version selection
# ---------------------------------------------------------------------------

echo ""
info "Select version bump:"
echo "  1) patch  → $(bump_version "$CURRENT_VERSION" patch)"
echo "  2) minor  → $(bump_version "$CURRENT_VERSION" minor)"
echo "  3) major  → $(bump_version "$CURRENT_VERSION" major)"
echo "  4) custom"
echo ""
read -rp "Choice [1-4]: " choice

case "$choice" in
    1) NEW_VERSION=$(bump_version "$CURRENT_VERSION" patch) ;;
    2) NEW_VERSION=$(bump_version "$CURRENT_VERSION" minor) ;;
    3) NEW_VERSION=$(bump_version "$CURRENT_VERSION" major) ;;
    4)
        read -rp "Enter version (e.g. 1.2.3): " NEW_VERSION
        [[ "$NEW_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || error "Invalid version format"
        ;;
    *) error "Invalid choice" ;;
esac

ok "New version: ${NEW_VERSION}"

# ---------------------------------------------------------------------------
# Update version
# ---------------------------------------------------------------------------

set_version "$NEW_VERSION"
ok "Updated $PYPROJECT to version ${NEW_VERSION}"

# ---------------------------------------------------------------------------
# Generate changelog
# ---------------------------------------------------------------------------

info "Generating changelog entry..."
CHANGELOG_ENTRY=$(generate_changelog "$NEW_VERSION")

echo ""
echo "--- Changelog Preview ---"
echo "$CHANGELOG_ENTRY"
echo "--- End Preview ---"
echo ""

read -rp "Open in editor for adjustments? [y/N] " edit_choice
if [[ "$edit_choice" =~ ^[Yy]$ ]]; then
    TMPFILE=$(mktemp /tmp/changelog_entry.XXXXXX.md)
    echo "$CHANGELOG_ENTRY" > "$TMPFILE"
    ${EDITOR:-vim} "$TMPFILE"
    CHANGELOG_ENTRY=$(cat "$TMPFILE")
    rm -f "$TMPFILE"
fi

# Prepend to CHANGELOG.md
if [[ -f "$CHANGELOG" ]]; then
    # Insert after the header lines
    TMPFILE=$(mktemp /tmp/changelog.XXXXXX.md)
    head -n 5 "$CHANGELOG" > "$TMPFILE"
    echo "" >> "$TMPFILE"
    echo "$CHANGELOG_ENTRY" >> "$TMPFILE"
    tail -n +6 "$CHANGELOG" >> "$TMPFILE"
    mv "$TMPFILE" "$CHANGELOG"
else
    echo "# Changelog" > "$CHANGELOG"
    echo "" >> "$CHANGELOG"
    echo "$CHANGELOG_ENTRY" >> "$CHANGELOG"
fi
ok "Updated $CHANGELOG"

# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------

info "Building package..."
rm -rf dist/ build/ *.egg-info
python3 -m build
ok "Package built successfully"

# ---------------------------------------------------------------------------
# Check
# ---------------------------------------------------------------------------

info "Checking package..."
python3 -m twine check dist/*
ok "Package checks passed"

# ---------------------------------------------------------------------------
# Commit and tag
# ---------------------------------------------------------------------------

echo ""
read -rp "Commit changes and create tag v${NEW_VERSION}? [Y/n] " commit_choice
if [[ ! "$commit_choice" =~ ^[Nn]$ ]]; then
    git add "$PYPROJECT" "$CHANGELOG"
    git commit -m "chore: release version ${NEW_VERSION}"
    git tag -a "v${NEW_VERSION}" -m "Release version ${NEW_VERSION}"
    ok "Created commit and tag v${NEW_VERSION}"
fi

# ---------------------------------------------------------------------------
# Upload
# ---------------------------------------------------------------------------

echo ""
info "Upload options:"
echo "  1) TestPyPI (recommended for first time)"
echo "  2) PyPI (production)"
echo "  3) Skip upload"
echo ""
read -rp "Choice [1-3]: " upload_choice

case "$upload_choice" in
    1)
        python3 -m twine upload --repository testpypi dist/*
        ok "Uploaded to TestPyPI"
        echo ""
        info "Test with: pip install --index-url https://test.pypi.org/simple/ suppevo-mcp==${NEW_VERSION}"
        ;;
    2)
        python3 -m twine upload dist/*
        ok "Uploaded to PyPI"
        ;;
    3) info "Skipping upload." ;;
    *) warn "Invalid choice, skipping upload." ;;
esac

# ---------------------------------------------------------------------------
# Push
# ---------------------------------------------------------------------------

echo ""
read -rp "Push commits and tags to remote? [Y/n] " push_choice
if [[ ! "$push_choice" =~ ^[Nn]$ ]]; then
    git push && git push --tags
    ok "Pushed to remote"
fi

echo ""
ok "Release ${NEW_VERSION} complete! 🎉"
