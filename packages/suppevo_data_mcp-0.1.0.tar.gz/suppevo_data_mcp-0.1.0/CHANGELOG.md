# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.1.0] - 2025-05-24

### Added
- Initial release of the Suppevo MCP server
- Profile management tools
- Product CRUD and bulk operations (admin)
- Supplement tracking tools
- Dose logging and summaries
- Schedule management with reminders
- Review creation and moderation
- Rewards, badges, streaks, and challenges
- Brand management (admin)
- Public discovery endpoints (no auth)
- Ingredient intelligence (alternatives, interactions, dosing guides)
- News endpoints
- Token auto-refresh via AWS Cognito
- Retry logic for transient errors
