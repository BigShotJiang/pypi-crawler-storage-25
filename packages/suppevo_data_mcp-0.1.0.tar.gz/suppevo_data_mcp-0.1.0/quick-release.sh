#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# Quick Patch Release Script for suppevo-mcp
# Usage: ./quick-release.sh [optional description]
# =============================================================================

PYPROJECT="pyproject.toml"
CHANGELOG="CHANGELOG.md"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

info()  { echo -e "${BLUE}ℹ${NC}  $*"; }
ok()    { echo -e "${GREEN}✓${NC}  $*"; }
error() { echo -e "${RED}✗${NC}  $*"; exit 1; }

# ---------------------------------------------------------------------------
# Pre-flight
# ---------------------------------------------------------------------------

command -v python3 >/dev/null 2>&1 || error "python3 not found"
command -v git >/dev/null 2>&1 || error "git not found"
[[ -f "$PYPROJECT" ]] || error "$PYPROJECT not found. Run from project root."

# ---------------------------------------------------------------------------
# Version bump (patch)
# ---------------------------------------------------------------------------

CURRENT_VERSION=$(grep -m1 '^version' "$PYPROJECT" | sed 's/version = "//;s/"//')
IFS='.' read -r major minor patch <<< "$CURRENT_VERSION"
NEW_VERSION="${major}.${minor}.$((patch + 1))"

info "Bumping version: ${CURRENT_VERSION} → ${NEW_VERSION}"
sed -i '' "s/^version = \".*\"/version = \"${NEW_VERSION}\"/" "$PYPROJECT"
ok "Updated $PYPROJECT"

# ---------------------------------------------------------------------------
# Changelog
# ---------------------------------------------------------------------------

DATE=$(date +%Y-%m-%d)
DESCRIPTION="${1:-}"

if [[ -z "$DESCRIPTION" ]]; then
    # Auto-generate from commits since last tag
    LAST_TAG=$(git describe --tags --abbrev=0 2>/dev/null || echo "")
    if [[ -n "$LAST_TAG" ]]; then
        COMMITS=$(git log "${LAST_TAG}..HEAD" --pretty=format:"- %s" 2>/dev/null || echo "- Patch release")
    else
        COMMITS=$(git log --pretty=format:"- %s" 2>/dev/null || echo "- Initial release")
    fi

    ENTRY="## [${NEW_VERSION}] - ${DATE}

### Changed
${COMMITS}
"
else
    ENTRY="## [${NEW_VERSION}] - ${DATE}

### Fixed
- ${DESCRIPTION}
"
fi

# Prepend to CHANGELOG.md
if [[ -f "$CHANGELOG" ]]; then
    TMPFILE=$(mktemp /tmp/changelog.XXXXXX.md)
    head -n 5 "$CHANGELOG" > "$TMPFILE"
    echo "" >> "$TMPFILE"
    echo "$ENTRY" >> "$TMPFILE"
    tail -n +6 "$CHANGELOG" >> "$TMPFILE"
    mv "$TMPFILE" "$CHANGELOG"
else
    {
        echo "# Changelog"
        echo ""
        echo "$ENTRY"
    } > "$CHANGELOG"
fi
ok "Updated $CHANGELOG"

# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------

info "Building package..."
rm -rf dist/ build/ *.egg-info
python3 -m build
ok "Package built"

# ---------------------------------------------------------------------------
# Check
# ---------------------------------------------------------------------------

info "Checking package..."
python3 -m twine check dist/*
ok "Package checks passed"

# ---------------------------------------------------------------------------
# Commit and tag
# ---------------------------------------------------------------------------

git add "$PYPROJECT" "$CHANGELOG"
git commit -m "chore: release version ${NEW_VERSION}"
git tag -a "v${NEW_VERSION}" -m "Release version ${NEW_VERSION}"
ok "Created commit and tag v${NEW_VERSION}"

echo ""
ok "Quick release ${NEW_VERSION} ready! 🚀"
echo ""
info "Next steps:"
echo "  Upload:  python3 -m twine upload dist/*"
echo "  Push:    git push && git push --tags"
