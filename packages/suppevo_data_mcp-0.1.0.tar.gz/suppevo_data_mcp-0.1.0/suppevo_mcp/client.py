"""HTTP client for the Suppevo REST API."""

from __future__ import annotations

import asyncio
import logging

import httpx

DEFAULT_BASE_URL = "https://api.dev.suppevo.com/"
DEFAULT_CDN_BASE_URL = "https://cdn-dev.suppevo.com"
DEFAULT_COGNITO_REGION = "us-east-1"
TIMEOUT = 30.0
MAX_RETRIES = 2
RETRY_BACKOFF = 1.0  # seconds

log = logging.getLogger(__name__)


class SuppevoClient:
    """Thin async wrapper around the Suppevo REST API."""

    def __init__(
        self,
        base_url: str = DEFAULT_BASE_URL,
        cdn_base_url: str = DEFAULT_CDN_BASE_URL,
        token: str | None = None,
        refresh_token: str | None = None,
        client_id: str | None = None,
        cognito_region: str = DEFAULT_COGNITO_REGION,
    ):
        self.base_url = base_url.rstrip("/")
        self.cdn_base_url = cdn_base_url.rstrip("/")
        self.token = token
        self.refresh_token = refresh_token
        self.client_id = client_id
        self.cognito_region = cognito_region
        self._http: httpx.AsyncClient | None = None
        self._refreshing = False

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_http(self) -> httpx.AsyncClient:
        """Return a persistent AsyncClient, creating one if needed."""
        if self._http is None or self._http.is_closed:
            self._http = httpx.AsyncClient(timeout=TIMEOUT)
        return self._http

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._http is not None and not self._http.is_closed:
            await self._http.aclose()
            self._http = None

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Accept": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    async def _refresh_access_token(self) -> bool:
        """Use the Cognito refresh token to obtain a new access token.

        Returns True if the token was successfully refreshed.
        """
        if not self.refresh_token or not self.client_id:
            return False

        if self._refreshing:
            # Avoid recursive refresh attempts
            return False

        self._refreshing = True
        try:
            cognito_url = (
                f"https://cognito-idp.{self.cognito_region}.amazonaws.com/"
            )
            http = self._get_http()
            resp = await http.post(
                cognito_url,
                json={
                    "AuthFlow": "REFRESH_TOKEN_AUTH",
                    "ClientId": self.client_id,
                    "AuthParameters": {
                        "REFRESH_TOKEN": self.refresh_token,
                    },
                },
                headers={
                    "Content-Type": "application/x-amz-json-1.1",
                    "X-Amz-Target": "AWSCognitoIdentityProviderService.InitiateAuth",
                },
            )
            if resp.status_code == 200:
                data = resp.json()
                auth_result = data.get("AuthenticationResult", {})
                new_token = auth_result.get("IdToken") or auth_result.get("AccessToken")
                if new_token:
                    self.token = new_token
                    log.info("Successfully refreshed access token via Cognito.")
                    return True
            log.warning(
                "Token refresh failed with status %s: %s",
                resp.status_code,
                resp.text[:200],
            )
            return False
        except Exception as exc:
            log.warning("Token refresh error: %s", exc)
            return False
        finally:
            self._refreshing = False

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict | None = None,
        json_body: dict | None = None,
        auth_required: bool = True,
    ) -> dict | str | None:
        """Send an HTTP request and return parsed JSON (or raw text for non-JSON).

        Retries up to MAX_RETRIES times for transient errors (5xx, connect
        errors, timeouts). Returns a clear message for 401 expired tokens.
        """
        headers = self._headers()
        if not auth_required:
            headers.pop("Authorization", None)
        url = f"{self.base_url}{path}" if not path.startswith("http") else path

        last_error: Exception | None = None
        for attempt in range(1 + MAX_RETRIES):
            try:
                http = self._get_http()
                resp = await http.request(
                    method,
                    url,
                    headers=headers,
                    params=_clean_params(params),
                    json=json_body,
                )

                # 401 — try refresh token, then fail if that doesn't work
                if resp.status_code == 401:
                    if auth_required and not self._refreshing and await self._refresh_access_token():
                        # Token refreshed — retry this request with new token
                        headers = self._headers()
                        continue
                    return {
                        "error": "authentication_failed",
                        "status_code": 401,
                        "message": (
                            "Authentication failed (401). Your SUPPEVO_API_TOKEN "
                            "may have expired. Please refresh it in "
                            ".kiro/settings/mcp.json and restart the MCP server."
                        ),
                    }

                # 5xx — retry
                if resp.status_code >= 500:
                    if attempt < MAX_RETRIES:
                        log.warning("Server error %s on %s %s (attempt %d), retrying...", resp.status_code, method, path, attempt + 1)
                        await asyncio.sleep(RETRY_BACKOFF * (attempt + 1))
                        continue
                    # Final attempt — fall through to normal response handling

                if resp.status_code == 204:
                    return {"status": "success", "status_code": 204}
                content_type = resp.headers.get("content-type", "")
                if "application/json" in content_type:
                    data = resp.json()
                    if resp.is_error:
                        return {"error": data, "status_code": resp.status_code}
                    return data
                # Non-JSON (e.g. text/calendar for iCal)
                return resp.text

            except (httpx.ConnectError, httpx.TimeoutException) as exc:
                last_error = exc
                if attempt < MAX_RETRIES:
                    log.warning("%s on %s %s (attempt %d), retrying...", type(exc).__name__, method, path, attempt + 1)
                    await asyncio.sleep(RETRY_BACKOFF * (attempt + 1))
                    continue
                return {
                    "error": "connection_failed",
                    "message": f"{type(exc).__name__}: {exc}. Retried {MAX_RETRIES} times.",
                }

        # Should not reach here, but just in case
        return {"error": "unknown", "message": str(last_error) if last_error else "Request failed"}

    # ------------------------------------------------------------------
    # Profile
    # ------------------------------------------------------------------

    async def get_profile(self) -> dict | str | None:
        return await self._request("GET", "/profile")

    async def create_profile(self, body: dict) -> dict | str | None:
        return await self._request("POST", "/profile", json_body=body)

    async def update_profile(self, body: dict) -> dict | str | None:
        return await self._request("PUT", "/profile", json_body=body)

    # ------------------------------------------------------------------
    # Products
    # ------------------------------------------------------------------

    async def list_products(self, *, cursor: str | None = None, limit: int | None = None, category: str | None = None) -> dict | str | None:
        return await self._request("GET", "/products/search", params={"cursor": cursor, "limit": limit, "category": category})

    async def create_product(self, body: dict) -> dict | str | None:
        return await self._request("POST", "/products", json_body=body)

    async def search_products(self, *, q: str | None = None, category: str | None = None, brand: str | None = None, brand_id: str | None = None, upc: str | None = None, ingredient: str | None = None, ingredient_q: str | None = None, sort: str | None = None, order: str | None = None, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/products/search", params={"q": q, "category": category, "brand": brand, "brand_id": brand_id, "upc": upc, "ingredient": ingredient, "ingredient_q": ingredient_q, "sort": sort, "order": order, "cursor": cursor, "limit": limit})

    async def bulk_create_products(self, products: list[dict]) -> dict | str | None:
        return await self._request("POST", "/products/bulk", json_body={"products": products})

    async def bulk_update_products(self, products: list[dict]) -> dict | str | None:
        return await self._request("PATCH", "/products/bulk", json_body={"products": products})

    async def bulk_delete_products(self, product_ids: list[str]) -> dict | str | None:
        return await self._request("DELETE", "/products/bulk", json_body={"product_ids": product_ids})

    async def get_product(self, product_id: str) -> dict | str | None:
        return await self._request("GET", f"/products/{product_id}")

    async def update_product(self, product_id: str, body: dict) -> dict | str | None:
        return await self._request("PATCH", f"/products/{product_id}", json_body=body)

    async def delete_product(self, product_id: str) -> dict | str | None:
        return await self._request("DELETE", f"/products/{product_id}")

    async def list_product_reviews(self, product_id: str, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", f"/products/{product_id}/reviews", params={"cursor": cursor, "limit": limit})

    async def create_product_review(self, product_id: str, body: dict) -> dict | str | None:
        return await self._request("POST", f"/products/{product_id}/reviews", json_body=body)

    # ------------------------------------------------------------------
    # Supplements
    # ------------------------------------------------------------------

    async def list_supplements(self, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/supplements", params={"cursor": cursor, "limit": limit})

    async def create_supplement(self, body: dict) -> dict | str | None:
        return await self._request("POST", "/supplements", json_body=body)

    async def get_supplement(self, supplement_id: str) -> dict | str | None:
        return await self._request("GET", f"/supplements/{supplement_id}")

    async def update_supplement(self, supplement_id: str, body: dict) -> dict | str | None:
        return await self._request("PATCH", f"/supplements/{supplement_id}", json_body=body)

    async def delete_supplement(self, supplement_id: str) -> dict | str | None:
        return await self._request("DELETE", f"/supplements/{supplement_id}")

    async def get_supplement_ical(self, supplement_id: str) -> dict | str | None:
        return await self._request("GET", f"/supplements/{supplement_id}/ical")

    # Schedules
    async def list_schedules(self, supplement_id: str, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", f"/supplements/{supplement_id}/schedules", params={"cursor": cursor, "limit": limit})

    async def create_schedule(self, supplement_id: str, body: dict) -> dict | str | None:
        return await self._request("POST", f"/supplements/{supplement_id}/schedules", json_body=body)

    async def update_schedule(self, schedule_id: str, body: dict) -> dict | str | None:
        return await self._request("PATCH", f"/schedules/{schedule_id}", json_body=body)

    async def delete_schedule(self, schedule_id: str) -> dict | str | None:
        return await self._request("DELETE", f"/schedules/{schedule_id}")

    # ------------------------------------------------------------------
    # Doses
    # ------------------------------------------------------------------

    async def list_doses(self, *, supplement_id: str | None = None, start_date: str | None = None, end_date: str | None = None, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/doses", params={"supplement_id": supplement_id, "start_date": start_date, "end_date": end_date, "cursor": cursor, "limit": limit})

    async def create_dose(self, body: dict) -> dict | str | None:
        return await self._request("POST", "/doses", json_body=body)

    async def get_dose_summary(self, *, supplement_id: str, start_date: str, end_date: str) -> dict | str | None:
        return await self._request("GET", "/doses/summary", params={"supplement_id": supplement_id, "start_date": start_date, "end_date": end_date})

    async def update_dose(self, dose_id: str, body: dict) -> dict | str | None:
        return await self._request("PATCH", f"/doses/{dose_id}", json_body=body)

    async def delete_dose(self, dose_id: str) -> dict | str | None:
        return await self._request("DELETE", f"/doses/{dose_id}")

    # ------------------------------------------------------------------
    # Reviews
    # ------------------------------------------------------------------

    async def list_review_prompts(self, *, product_id: str) -> dict | str | None:
        return await self._request("GET", "/reviews/prompts", params={"product_id": product_id})

    async def list_recent_reviews(self, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/reviews/recent", params={"cursor": cursor, "limit": limit})

    async def list_moderation_queue(self, *, status: str | None = None, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/reviews/moderation", params={"status": status, "cursor": cursor, "limit": limit})

    async def get_review(self, review_id: str) -> dict | str | None:
        return await self._request("GET", f"/reviews/{review_id}")

    async def moderate_review(self, review_id: str, body: dict) -> dict | str | None:
        return await self._request("PATCH", f"/reviews/{review_id}", json_body=body)

    async def delete_review(self, review_id: str) -> dict | str | None:
        return await self._request("DELETE", f"/reviews/{review_id}")

    # ------------------------------------------------------------------
    # Rewards
    # ------------------------------------------------------------------

    async def list_points(self, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/rewards/points", params={"cursor": cursor, "limit": limit})

    async def get_points_balance(self) -> dict | str | None:
        return await self._request("GET", "/rewards/points/balance")

    async def list_badges(self) -> dict | str | None:
        return await self._request("GET", "/rewards/badges")

    async def get_streak(self) -> dict | str | None:
        return await self._request("GET", "/rewards/streak")

    async def list_challenges(self) -> dict | str | None:
        return await self._request("GET", "/rewards/challenges")

    async def get_challenge(self, challenge_id: str) -> dict | str | None:
        return await self._request("GET", f"/rewards/challenges/{challenge_id}")

    # ------------------------------------------------------------------
    # Brands
    # ------------------------------------------------------------------

    async def list_brands(self, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/brands", params={"cursor": cursor, "limit": limit})

    async def create_brand(self, body: dict) -> dict | str | None:
        return await self._request("POST", "/brands", json_body=body)

    async def get_brand(self, brand_id: str) -> dict | str | None:
        return await self._request("GET", f"/brands/{brand_id}")

    async def update_brand(self, brand_id: str, body: dict) -> dict | str | None:
        return await self._request("PATCH", f"/brands/{brand_id}", json_body=body)

    async def delete_brand(self, brand_id: str) -> dict | str | None:
        return await self._request("DELETE", f"/brands/{brand_id}")

    async def search_brands(self, *, q: str | None = None, name: str | None = None, city: str | None = None, state: str | None = None, country: str | None = None, sort: str | None = None, order: str | None = None, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/brands", params={"q": q, "name": name, "city": city, "state": state, "country": country, "sort": sort, "order": order, "cursor": cursor, "limit": limit})

    async def list_brand_products(self, brand_id: str, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", f"/brands/{brand_id}/products", params={"cursor": cursor, "limit": limit})

    async def list_brand_reviews(self, brand_id: str, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", f"/brands/{brand_id}/reviews", params={"cursor": cursor, "limit": limit})

    async def create_brand_review(self, brand_id: str, body: dict) -> dict | str | None:
        return await self._request("POST", f"/brands/{brand_id}/reviews", json_body=body)

    # ------------------------------------------------------------------
    # Public endpoints (no auth)
    # ------------------------------------------------------------------

    async def public_get_product_search_index(self) -> dict | str | None:
        return await self._request("GET", f"{self.cdn_base_url}/search-products.json", auth_required=False)

    async def public_get_brand_search_index(self) -> dict | str | None:
        return await self._request("GET", f"{self.cdn_base_url}/search-brands.json", auth_required=False)

    async def public_get_ingredient_search_index(self) -> dict | str | None:
        return await self._request("GET", f"{self.cdn_base_url}/search-ingredients.json", auth_required=False)

    async def public_search_products(self, *, q: str | None = None, category: str | None = None, ingredient: str | None = None, ingredient_q: str | None = None, brand: str | None = None, brand_id: str | None = None, upc: str | None = None, tag: str | None = None, sort: str | None = None, order: str | None = None, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/public/products/search", params={"q": q, "category": category, "ingredient": ingredient, "ingredient_q": ingredient_q, "brand": brand, "brand_id": brand_id, "upc": upc, "tag": tag, "sort": sort, "order": order, "cursor": cursor, "limit": limit}, auth_required=False)

    async def public_get_product_facets(self) -> dict | str | None:
        return await self._request("GET", f"{self.cdn_base_url}/facets-products.json", auth_required=False)

    async def public_get_product(self, product_id: str) -> dict | str | None:
        return await self._request("GET", f"/public/products/{product_id}", auth_required=False)

    async def public_list_product_reviews(self, product_id: str, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", f"/public/products/{product_id}/reviews", params={"cursor": cursor, "limit": limit}, auth_required=False)

    async def public_record_affiliate_click(self, product_id: str) -> dict | str | None:
        return await self._request("POST", f"/public/products/{product_id}/affiliate-click", auth_required=False)

    async def public_get_product_completeness(self, product_id: str) -> dict | str | None:
        return await self._request("GET", f"/public/products/{product_id}/completeness", auth_required=False)

    # ------------------------------------------------------------------
    # Upload endpoints (admin)
    # ------------------------------------------------------------------

    async def upload_product_image(self, product_id: str, filename: str = "main.png") -> dict | str | None:
        return await self._request("POST", f"/uploads/products/{product_id}/image", json_body={"filename": filename})

    async def upload_brand_logo(self, brand_id: str, filename: str = "logo.png") -> dict | str | None:
        return await self._request("POST", f"/uploads/brands/{brand_id}/logo", json_body={"filename": filename})

    async def public_list_brands(self, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/public/brands", params={"cursor": cursor, "limit": limit}, auth_required=False)

    async def public_search_brands(self, *, q: str | None = None, name: str | None = None, city: str | None = None, state: str | None = None, country: str | None = None, sort: str | None = None, order: str | None = None, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/public/brands", params={"q": q, "name": name, "city": city, "state": state, "country": country, "sort": sort, "order": order, "cursor": cursor, "limit": limit}, auth_required=False)

    async def public_get_brand_facets(self) -> dict | str | None:
        return await self._request("GET", f"{self.cdn_base_url}/facets-brands.json", auth_required=False)

    async def public_get_brand(self, brand_id: str) -> dict | str | None:
        return await self._request("GET", f"/public/brands/{brand_id}", auth_required=False)

    async def public_list_brand_products(self, brand_id: str, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", f"/public/brands/{brand_id}/products", params={"cursor": cursor, "limit": limit}, auth_required=False)

    async def public_list_brand_reviews(self, brand_id: str, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", f"/public/brands/{brand_id}/reviews", params={"cursor": cursor, "limit": limit}, auth_required=False)

    # News
    async def public_list_news(self, *, sponsored: bool | None = None, from_date: str | None = None, to_date: str | None = None, q: str | None = None, tag: str | None = None, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/public/news", params={"sponsored": sponsored, "from": from_date, "to": to_date, "q": q, "tag": tag, "cursor": cursor, "limit": limit}, auth_required=False)

    async def public_get_news(self, news_id: str) -> dict | str | None:
        return await self._request("GET", f"/public/news/{news_id}", auth_required=False)

    # ------------------------------------------------------------------
    # Ingredients (authenticated)
    # ------------------------------------------------------------------

    async def list_ingredients(self, *, cursor: str | None = None, limit: int | None = None, type: str | None = None) -> dict | str | None:
        return await self._request("GET", "/ingredients", params={"cursor": cursor, "limit": limit, "type": type})

    async def create_ingredient(self, body: dict) -> dict | str | None:
        return await self._request("POST", "/ingredients", json_body=body)

    async def search_ingredients(self, *, q: str | None = None, name: str | None = None, type: str | None = None, sort: str | None = None, order: str | None = None, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/ingredients/search", params={"q": q, "name": name, "type": type, "sort": sort, "order": order, "cursor": cursor, "limit": limit})

    async def get_ingredient_facets(self) -> dict | str | None:
        return await self._request("GET", f"{self.cdn_base_url}/facets-ingredients.json", auth_required=False)

    async def get_ingredient(self, ingredient_id: str) -> dict | str | None:
        return await self._request("GET", f"/ingredients/{ingredient_id}")

    async def update_ingredient(self, ingredient_id: str, body: dict) -> dict | str | None:
        return await self._request("PATCH", f"/ingredients/{ingredient_id}", json_body=body)

    async def delete_ingredient(self, ingredient_id: str) -> dict | str | None:
        return await self._request("DELETE", f"/ingredients/{ingredient_id}")

    async def list_ingredient_products(self, ingredient_id: str, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", f"/ingredients/{ingredient_id}/products", params={"cursor": cursor, "limit": limit})

    async def bulk_create_ingredients(self, ingredients: list[dict]) -> dict | str | None:
        return await self._request("POST", "/ingredients/bulk", json_body={"items": ingredients})

    async def bulk_update_ingredients(self, ingredients: list[dict]) -> dict | str | None:
        return await self._request("PATCH", "/ingredients/bulk", json_body={"items": ingredients})

    async def list_unlinked_ingredients(self, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/admin/ingredients/unlinked", params={"cursor": cursor, "limit": limit})

    async def auto_link_ingredients(self, body: dict | None = None) -> dict | str | None:
        return await self._request("POST", "/admin/ingredients/auto-link", json_body=body or {})

    async def get_ingredient_analytics(self) -> dict | str | None:
        return await self._request("GET", "/admin/ingredients/analytics")

    async def merge_ingredient(self, ingredient_id: str, body: dict) -> dict | str | None:
        return await self._request("POST", f"/ingredients/{ingredient_id}/merge", json_body=body)

    # ------------------------------------------------------------------
    # Public Ingredients (no auth)
    # ------------------------------------------------------------------

    async def public_list_ingredients(self, *, cursor: str | None = None, limit: int | None = None, type: str | None = None) -> dict | str | None:
        return await self._request("GET", "/public/ingredients", params={"cursor": cursor, "limit": limit, "type": type}, auth_required=False)

    async def public_search_ingredients(self, *, q: str | None = None, name: str | None = None, type: str | None = None, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/public/ingredients/search", params={"q": q, "name": name, "type": type, "cursor": cursor, "limit": limit}, auth_required=False)

    async def public_get_ingredient_facets(self) -> dict | str | None:
        return await self._request("GET", f"{self.cdn_base_url}/facets-ingredients.json", auth_required=False)

    async def public_get_ingredient(self, ingredient_id: str) -> dict | str | None:
        return await self._request("GET", f"/public/ingredients/{ingredient_id}", auth_required=False)

    async def public_list_ingredient_products(self, ingredient_id: str, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", f"/public/ingredients/{ingredient_id}/products", params={"cursor": cursor, "limit": limit}, auth_required=False)

    # ------------------------------------------------------------------
    # Ingredient Intelligence (public, no auth)
    # ------------------------------------------------------------------

    async def get_ingredient_alternatives(self, ingredient_id: str) -> dict | str | None:
        return await self._request("GET", f"/public/ingredients/{ingredient_id}/alternatives", auth_required=False)

    async def get_ingredient_interactions(self, ingredient_id: str, *, severity: str | None = None, type: str | None = None) -> dict | str | None:
        return await self._request("GET", f"/public/ingredients/{ingredient_id}/interactions", params={"severity": severity, "type": type}, auth_required=False)

    async def get_ingredient_dosing_guide(self, ingredient_id: str) -> dict | str | None:
        return await self._request("GET", f"/public/ingredients/{ingredient_id}/dosing-guide", auth_required=False)

    async def get_ingredient_effectiveness(self, ingredient_id: str) -> dict | str | None:
        return await self._request("GET", f"/public/ingredients/{ingredient_id}/effectiveness", auth_required=False)

    async def get_trending_ingredients(self, *, limit: int | None = None, period: str | None = None) -> dict | str | None:
        return await self._request("GET", "/public/ingredients/trending", params={"limit": limit, "period": period}, auth_required=False)

    async def get_ingredients_by_benefit(self, benefit_slug: str, *, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", f"/public/ingredients/by-benefit/{benefit_slug}", params={"limit": limit}, auth_required=False)

    async def compare_ingredients(self, slug: str) -> dict | str | None:
        return await self._request("GET", f"/public/ingredients/compare/{slug}", auth_required=False)

    # ------------------------------------------------------------------
    # Scoring (public, no auth)
    # ------------------------------------------------------------------

    async def get_product_ingredient_score(self, product_id: str) -> dict | str | None:
        return await self._request("GET", f"/public/products/{product_id}/ingredient-score", auth_required=False)

    async def compare_products(self, ids: str) -> dict | str | None:
        return await self._request("GET", "/public/products/compare", params={"ids": ids}, auth_required=False)

    # ------------------------------------------------------------------
    # Stack analysis (authenticated)
    # ------------------------------------------------------------------

    async def stack_analysis(self) -> dict | str | None:
        return await self._request("GET", "/stack/analysis")

    async def stack_daily_totals(self) -> dict | str | None:
        return await self._request("GET", "/stack/daily-totals")

    async def stack_gaps(self) -> dict | str | None:
        return await self._request("GET", "/stack/gaps")

    async def stack_overlaps(self) -> dict | str | None:
        return await self._request("GET", "/stack/overlaps")

    async def stack_recommendations(self) -> dict | str | None:
        return await self._request("GET", "/stack/recommendations")

    async def stack_warnings(self) -> dict | str | None:
        return await self._request("GET", "/stack/warnings")

    # ------------------------------------------------------------------
    # CDN Discovery Indexes (public, no auth)
    # ------------------------------------------------------------------

    async def public_get_product_discovery_index(self) -> dict | str | None:
        return await self._request("GET", f"{self.cdn_base_url}/discover-products.json", auth_required=False)

    async def public_get_brand_discovery_index(self) -> dict | str | None:
        return await self._request("GET", f"{self.cdn_base_url}/discover-brands.json", auth_required=False)

    async def public_get_ingredient_discovery_index(self) -> dict | str | None:
        return await self._request("GET", f"{self.cdn_base_url}/discover-ingredients.json", auth_required=False)

    # Admin news
    async def admin_create_news(self, body: dict) -> dict | str | None:
        return await self._request("POST", "/admin/news", json_body=body)

    async def admin_update_news(self, news_id: str, body: dict) -> dict | str | None:
        return await self._request("PATCH", f"/admin/news/{news_id}", json_body=body)

    async def admin_delete_news(self, news_id: str) -> dict | str | None:
        return await self._request("DELETE", f"/admin/news/{news_id}")

    # ------------------------------------------------------------------
    # Admin Users
    # ------------------------------------------------------------------

    async def admin_list_users(self, *, cursor: str | None = None, limit: int | None = None, sort: str | None = None, order: str | None = None, q: str | None = None, status: str | None = None) -> dict | str | None:
        return await self._request("GET", "/admin/users", params={"cursor": cursor, "limit": limit, "sort": sort, "order": order, "q": q, "status": status})

    async def admin_get_user(self, user_id: str) -> dict | str | None:
        return await self._request("GET", f"/admin/users/{user_id}")

    async def admin_get_user_profile(self, user_id: str) -> dict | str | None:
        return await self._request("GET", f"/admin/users/{user_id}/profile")

    async def admin_update_user_profile(self, user_id: str, body: dict) -> dict | str | None:
        return await self._request("PATCH", f"/admin/users/{user_id}/profile", json_body=body)

    # ------------------------------------------------------------------
    # Suggestions (user)
    # ------------------------------------------------------------------

    async def list_my_suggestions(self, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/suggestions", params={"cursor": cursor, "limit": limit})

    async def create_suggestion(self, body: dict) -> dict | str | None:
        return await self._request("POST", "/suggestions", json_body=body)

    async def get_suggestion(self, suggestion_id: str) -> dict | str | None:
        return await self._request("GET", f"/suggestions/{suggestion_id}")

    async def upload_suggestion_image(self, suggestion_id: str, body: dict | None = None) -> dict | str | None:
        return await self._request("POST", f"/suggestions/{suggestion_id}/upload", json_body=body or {})

    # ------------------------------------------------------------------
    # Suggestions (admin)
    # ------------------------------------------------------------------

    async def admin_list_suggestions(self, *, status: str | None = None, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/admin/suggestions", params={"status": status, "cursor": cursor, "limit": limit})

    async def admin_get_suggestion(self, suggestion_id: str) -> dict | str | None:
        return await self._request("GET", f"/admin/suggestions/{suggestion_id}")

    async def admin_review_suggestion(self, suggestion_id: str, body: dict) -> dict | str | None:
        return await self._request("PATCH", f"/admin/suggestions/{suggestion_id}", json_body=body)

    async def admin_edit_suggestion(self, suggestion_id: str, body: dict) -> dict | str | None:
        return await self._request("PUT", f"/admin/suggestions/{suggestion_id}", json_body=body)

    async def admin_get_suggestion_image_url(self, suggestion_id: str, filename: str) -> dict | str | None:
        return await self._request("GET", f"/admin/suggestions/{suggestion_id}/images/{filename}")

    # ------------------------------------------------------------------
    # Profile brands
    # ------------------------------------------------------------------

    async def get_my_brands(self) -> dict | str | None:
        return await self._request("GET", "/profile/brands")

    # ------------------------------------------------------------------
    # Brand owners
    # ------------------------------------------------------------------

    async def list_brand_owners(self, brand_id: str) -> dict | str | None:
        return await self._request("GET", f"/brands/{brand_id}/owners")

    async def add_brand_owner(self, brand_id: str, body: dict) -> dict | str | None:
        return await self._request("POST", f"/brands/{brand_id}/owners", json_body=body)

    async def remove_brand_owner(self, brand_id: str, user_id: str) -> dict | str | None:
        return await self._request("DELETE", f"/brands/{brand_id}/owners/{user_id}")

    # ------------------------------------------------------------------
    # Admin user groups
    # ------------------------------------------------------------------

    async def admin_list_user_groups(self, user_id: str) -> dict | str | None:
        return await self._request("GET", f"/admin/users/{user_id}/groups")

    async def admin_add_user_to_group(self, user_id: str, body: dict) -> dict | str | None:
        return await self._request("POST", f"/admin/users/{user_id}/groups", json_body=body)

    async def admin_remove_user_from_group(self, user_id: str, group_name: str) -> dict | str | None:
        return await self._request("DELETE", f"/admin/users/{user_id}/groups/{group_name}")

    # ------------------------------------------------------------------
    # Admin user brands
    # ------------------------------------------------------------------

    async def admin_list_user_brands(self, user_id: str) -> dict | str | None:
        return await self._request("GET", f"/admin/users/{user_id}/brands")

    # ------------------------------------------------------------------
    # Benefits (admin write)
    # ------------------------------------------------------------------

    async def create_benefit(self, body: dict) -> dict | str | None:
        return await self._request("POST", "/benefits", json_body=body)

    async def update_benefit(self, benefit_id: str, body: dict) -> dict | str | None:
        return await self._request("PATCH", f"/benefits/{benefit_id}", json_body=body)

    async def delete_benefit(self, benefit_id: str) -> dict | str | None:
        return await self._request("DELETE", f"/benefits/{benefit_id}")

    async def rebuild_benefit_rankings(self) -> dict | str | None:
        return await self._request("POST", "/admin/benefits/rebuild-rankings")

    async def get_benefit_ranking_rebuild_status(self) -> dict | str | None:
        return await self._request("GET", "/admin/benefits/rebuild-rankings")

    # ------------------------------------------------------------------
    # Benefits (public read)
    # ------------------------------------------------------------------

    async def public_list_benefits(self, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/public/benefits", params={"cursor": cursor, "limit": limit})

    async def public_get_benefit(self, slug: str) -> dict | str | None:
        return await self._request("GET", f"/public/benefits/{slug}")

    async def public_list_benefit_ingredients(self, slug: str, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", f"/public/benefits/{slug}/ingredients", params={"cursor": cursor, "limit": limit})

    async def public_list_benefit_products(self, slug: str, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", f"/public/benefits/{slug}/products", params={"cursor": cursor, "limit": limit})

    # ------------------------------------------------------------------
    # Brand search index (CDN)
    # ------------------------------------------------------------------

    async def get_brand_search_index(self) -> dict | str | None:
        return await self._request("GET", f"{self.cdn_base_url}/search-brands.json", auth_required=False)

    # ------------------------------------------------------------------
    # Exports
    # ------------------------------------------------------------------

    async def create_export(self, body: dict) -> dict | str | None:
        return await self._request("POST", "/exports", json_body=body)

    # ------------------------------------------------------------------
    # CDN Benefits Index
    # ------------------------------------------------------------------

    async def public_get_benefits_search_index(self) -> dict | str | None:
        return await self._request("GET", f"{self.cdn_base_url}/search-benefits.json", auth_required=False)

    # ------------------------------------------------------------------
    # Biomarkers (Admin)
    # ------------------------------------------------------------------

    async def create_biomarker(self, body: dict) -> dict | str | None:
        return await self._request("POST", "/biomarkers", json_body=body)

    async def update_biomarker(self, biomarker_id: str, body: dict) -> dict | str | None:
        return await self._request("PATCH", f"/biomarkers/{biomarker_id}", json_body=body)

    async def delete_biomarker(self, biomarker_id: str) -> dict | str | None:
        return await self._request("DELETE", f"/biomarkers/{biomarker_id}")

    async def bulk_create_biomarkers(self, items: list[dict]) -> dict | str | None:
        return await self._request("POST", "/biomarkers/bulk", json_body={"items": items})

    # ------------------------------------------------------------------
    # Biomarkers (Public)
    # ------------------------------------------------------------------

    async def public_list_biomarkers(self, *, cursor: str | None = None, limit: int | None = None, category: str | None = None) -> dict | str | None:
        return await self._request("GET", "/public/biomarkers", params={"cursor": cursor, "limit": limit, "category": category}, auth_required=False)

    async def public_get_biomarker(self, biomarker_id: str) -> dict | str | None:
        return await self._request("GET", f"/public/biomarkers/{biomarker_id}", auth_required=False)

    async def public_list_biomarkers_by_category(self, category: str, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", "/public/biomarkers", params={"category": category, "cursor": cursor, "limit": limit}, auth_required=False)

    async def public_list_biomarker_ingredients(self, slug: str, *, cursor: str | None = None, limit: int | None = None) -> dict | str | None:
        return await self._request("GET", f"/public/biomarkers/{slug}/ingredients", params={"cursor": cursor, "limit": limit}, auth_required=False)

    # ------------------------------------------------------------------
    # Biomarkers (Stack / Premium)
    # ------------------------------------------------------------------

    async def stack_biomarkers_testing_plan(self) -> dict | str | None:
        return await self._request("GET", "/stack/biomarkers/testing-plan")

    async def stack_biomarkers_report(self) -> dict | str | None:
        return await self._request("GET", "/stack/biomarkers/report")

    # ------------------------------------------------------------------
    # Evidence Links (Admin)
    # ------------------------------------------------------------------

    async def create_evidence_link(self, ingredient_id: str, body: dict) -> dict | str | None:
        return await self._request("POST", f"/ingredients/{ingredient_id}/evidence", json_body=body)

    async def update_evidence_link(self, evidence_id: str, ingredient_id: str, body: dict) -> dict | str | None:
        return await self._request("PATCH", f"/evidence/{evidence_id}", params={"ingredient_id": ingredient_id}, json_body=body)

    async def delete_evidence_link(self, evidence_id: str, ingredient_id: str) -> dict | str | None:
        return await self._request("DELETE", f"/evidence/{evidence_id}", params={"ingredient_id": ingredient_id})

    async def bulk_create_evidence_links(self, items: list[dict]) -> dict | str | None:
        return await self._request("POST", "/evidence/bulk", json_body={"items": items})

    # ------------------------------------------------------------------
    # Evidence Links (Public)
    # ------------------------------------------------------------------

    async def public_list_ingredient_evidence(self, ingredient_id: str) -> dict | str | None:
        return await self._request("GET", f"/public/ingredients/{ingredient_id}/evidence", auth_required=False)

    async def public_list_ingredient_biomarkers(self, ingredient_id: str) -> dict | str | None:
        return await self._request("GET", f"/public/ingredients/{ingredient_id}/biomarkers", auth_required=False)


def _clean_params(params: dict | None) -> dict | None:
    """Remove None values from query params."""
    if params is None:
        return None
    return {k: v for k, v in params.items() if v is not None}
