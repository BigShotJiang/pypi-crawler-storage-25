"""Allow running as `python -m suppevo_mcp`."""

from suppevo_mcp.server import main

main()
