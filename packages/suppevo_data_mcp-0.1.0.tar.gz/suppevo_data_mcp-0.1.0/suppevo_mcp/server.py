"""Suppevo MCP Server — exposes the Suppevo REST API as MCP tools."""

from __future__ import annotations

import json
import os
from pathlib import Path

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP

from suppevo_mcp.client import SuppevoClient

# ---------------------------------------------------------------------------
# Load environment variables from ~/.env (user home directory)
# ---------------------------------------------------------------------------

_user_env = Path.home() / ".env"
if _user_env.exists():
    load_dotenv(_user_env)


# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------

mcp = FastMCP(
    "suppevo",
    instructions=(
        "MCP server for the Suppevo supplement-tracking platform API (v0.28.1). "
        "Provides tools for managing user profiles, products, supplements, "
        "doses, reviews, rewards, brands, brand owners, benefits, public discovery, "
        "news, admin user groups, suggestions, ingredient intelligence, "
        "stack analysis, and scoring. "
        "Set SUPPEVO_API_TOKEN for authenticated endpoints and optionally "
        "SUPPEVO_API_BASE_URL to override the default https://api.dev.suppevo.com/."
    ),
)


def _client() -> SuppevoClient:
    global _cached_client
    if _cached_client is None:
        _cached_client = SuppevoClient(
            base_url=os.environ.get("SUPPEVO_API_BASE_URL", "https://api.dev.suppevo.com/"),
            token=os.environ.get("SUPPEVO_API_TOKEN"),
            refresh_token=os.environ.get("SUPPEVO_REFRESH_TOKEN"),
            client_id=os.environ.get("SUPPEVO_CLIENT_ID"),
            cognito_region=os.environ.get("SUPPEVO_COGNITO_REGION", "us-east-1"),
        )
    return _cached_client


_cached_client: SuppevoClient | None = None


def _json_result(data) -> str:
    if isinstance(data, str):
        return data
    return json.dumps(data, indent=2, default=str)


def _sanitize_floats(obj):
    """Recursively convert Python floats to Decimal-safe representations.

    DynamoDB rejects native floats. This converts them to int when lossless,
    otherwise to a string representation that the backend can parse as Decimal.
    """
    from decimal import Decimal

    if isinstance(obj, float):
        d = Decimal(str(obj))
        if d == d.to_integral_value():
            return int(d)
        return float(d)
    elif isinstance(obj, dict):
        return {k: _sanitize_floats(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_sanitize_floats(item) for item in obj]
    return obj


# ===================================================================
# Profile tools
# ===================================================================


@mcp.tool()
async def get_profile() -> str:
    """Retrieve the authenticated user's Suppevo profile."""
    return _json_result(await _client().get_profile())


@mcp.tool()
async def create_profile(display_name: str, interest_categories: list[str] | None = None, avatar_url: str | None = None) -> str:
    """Create a new user profile.

    Args:
        display_name: User display name (required).
        interest_categories: List of supplement categories the user is interested in.
            Valid values: sleep, digestion, stress, energy, joints, immunity, heart,
            brain, beauty, weight, prenatal, kids, sports, general.
        avatar_url: URL of the user's avatar image.
    """
    body: dict = {"displayName": display_name}
    if interest_categories is not None:
        body["interestCategories"] = interest_categories
    if avatar_url is not None:
        body["avatarUrl"] = avatar_url
    return _json_result(await _client().create_profile(body))


@mcp.tool()
async def update_profile(display_name: str | None = None, interest_categories: list[str] | None = None, avatar_url: str | None = None, preferences: dict | None = None) -> str:
    """Update the authenticated user's profile. Only provided fields are changed.

    Args:
        display_name: New display name.
        interest_categories: Updated supplement interest categories.
        avatar_url: New avatar URL.
        preferences: Key-value preferences object.
    """
    body: dict = {}
    if display_name is not None:
        body["displayName"] = display_name
    if interest_categories is not None:
        body["interestCategories"] = interest_categories
    if avatar_url is not None:
        body["avatarUrl"] = avatar_url
    if preferences is not None:
        body["preferences"] = preferences
    return _json_result(await _client().update_profile(body))


# ===================================================================
# Product tools (admin-only; read operations use public_* tools)
# ===================================================================


@mcp.tool()
async def create_product(name: str, category: str, brand: str | None = None, brand_id: str | None = None, form: str | None = None, default_dose_amount: float | None = None, default_dose_unit: str | None = None, manufacturer: str | None = None, country_of_origin: str | None = None, website: str | None = None, upc: str | None = None, serving_size: str | None = None, servings_per_container: int | None = None, ingredients: list[dict] | None = None, image_url: str | None = None, dosage: str | None = None, asin: str | None = None, description: str | None = None) -> str:
    """Create a new product (admin only).

    Args:
        name: Product name (required).
        category: Supplement category (required).
        brand: Brand name.
        brand_id: UUID of the brand.
        form: Physical form (capsule, tablet, powder, etc.).
        default_dose_amount: Default dose amount per serving.
        default_dose_unit: Unit for the default dose.
        manufacturer: Manufacturer name.
        country_of_origin: Country of manufacture.
        website: Official product website URL.
        upc: Universal Product Code.
        serving_size: Serving size description.
        servings_per_container: Number of servings per container.
        ingredients: List of ingredient objects with name, amount, unit, and optional daily_value_percent.
        image_url: Product image URL.
        dosage: Recommended dosage information.
        asin: Amazon Standard Identification Number (10 alphanumeric characters).
        description: General product description or details.
    """
    body: dict = {"name": name, "category": category}
    for key, val in [("brand", brand), ("brand_id", brand_id), ("form", form), ("default_dose_amount", default_dose_amount), ("default_dose_unit", default_dose_unit), ("manufacturer", manufacturer), ("country_of_origin", country_of_origin), ("website", website), ("upc", upc), ("serving_size", serving_size), ("servings_per_container", servings_per_container), ("ingredients", ingredients), ("imageUrl", image_url), ("dosage", dosage), ("asin", asin), ("description", description)]:
        if val is not None:
            body[key] = val
    body = _sanitize_floats(body)
    return _json_result(await _client().create_product(body))


@mcp.tool()
async def update_product(product_id: str, name: str | None = None, category: str | None = None, brand: str | None = None, brand_id: str | None = None, form: str | None = None, default_dose_amount: float | None = None, default_dose_unit: str | None = None, manufacturer: str | None = None, country_of_origin: str | None = None, website: str | None = None, upc: str | None = None, serving_size: str | None = None, servings_per_container: int | None = None, ingredients: list[dict] | None = None, image_url: str | None = None, dosage: str | None = None, asin: str | None = None, description: str | None = None) -> str:
    """Update a product by ID (admin only). Only provided fields are changed.

    Args:
        product_id: UUID of the product.
        name: Product name.
        category: Supplement category.
        brand: Brand name.
        brand_id: UUID of the brand.
        form: Physical form.
        default_dose_amount: Default dose amount per serving.
        default_dose_unit: Unit for the default dose.
        manufacturer: Manufacturer name.
        country_of_origin: Country of manufacture.
        website: Official product website URL.
        upc: Universal Product Code.
        serving_size: Serving size description.
        servings_per_container: Number of servings per container.
        ingredients: Updated ingredient list.
        image_url: Product image URL.
        dosage: Recommended dosage information.
        asin: Amazon Standard Identification Number (10 alphanumeric characters).
        description: General product description or details.
    """
    body: dict = {}
    for key, val in [("name", name), ("category", category), ("brand", brand), ("brand_id", brand_id), ("form", form), ("default_dose_amount", default_dose_amount), ("default_dose_unit", default_dose_unit), ("manufacturer", manufacturer), ("country_of_origin", country_of_origin), ("website", website), ("upc", upc), ("serving_size", serving_size), ("servings_per_container", servings_per_container), ("ingredients", ingredients), ("imageUrl", image_url), ("dosage", dosage), ("asin", asin), ("description", description)]:
        if val is not None:
            body[key] = val
    body = _sanitize_floats(body)
    return _json_result(await _client().update_product(product_id, body))


@mcp.tool()
async def delete_product(product_id: str) -> str:
    """Delete a product by ID (admin only).

    Args:
        product_id: UUID of the product.
    """
    return _json_result(await _client().delete_product(product_id))


@mcp.tool()
async def bulk_create_products(products: list[dict]) -> str:
    """Bulk create up to 25 products in a single request (admin only).

    Each product is validated and persisted independently — failures for one
    item do not block others. Returns created products and per-item errors.

    Args:
        products: List of product objects (max 25). Each requires at minimum
            'name' and 'category'. Optional fields: brand, brand_id, form,
            default_dose_amount, default_dose_unit, manufacturer,
            country_of_origin, website, upc, serving_size,
            servings_per_container, ingredients, imageUrl, dosage, asin.
    """
    products = _sanitize_floats(products)
    return _json_result(await _client().bulk_create_products(products))


@mcp.tool()
async def bulk_update_products(products: list[dict]) -> str:
    """Bulk update up to 25 products in a single request (admin only).

    Each product update is applied independently. Each item in the list must
    include an 'id' field plus any fields to update.

    Args:
        products: List of product update objects (max 25). Each requires 'id'
            (UUID). Optional fields to update: name, category, brand, brand_id,
            form, default_dose_amount, default_dose_unit, manufacturer,
            country_of_origin, website, upc, serving_size,
            servings_per_container, ingredients, imageUrl, dosage, asin.
    """
    products = _sanitize_floats(products)
    return _json_result(await _client().bulk_update_products(products))


@mcp.tool()
async def bulk_delete_products(product_ids: list[str]) -> str:
    """Bulk delete up to 25 products in a single request (admin only).

    Each deletion is processed independently — products in active supplement
    routines are skipped with an error. Returns deleted IDs and per-item errors.

    Args:
        product_ids: List of product UUIDs to delete (max 25).
    """
    return _json_result(await _client().bulk_delete_products(product_ids))


@mcp.tool()
async def create_review(product_id: str, rating: int, title: str, body: str) -> str:
    """Create a review for a product.

    Args:
        product_id: UUID of the product.
        rating: Rating from 1 to 5.
        title: Review title.
        body: Review body text.
    """
    return _json_result(await _client().create_product_review(product_id, {"product_id": product_id, "rating": rating, "title": title, "body": body}))


# ===================================================================
# Supplement tools
# ===================================================================


@mcp.tool()
async def list_supplements(cursor: str | None = None, limit: int | None = None) -> str:
    """List the authenticated user's supplement tracking entries.

    Args:
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().list_supplements(cursor=cursor, limit=limit))


@mcp.tool()
async def create_supplement(product_id: str | None = None, name: str | None = None, brand: str | None = None, dosage: str | None = None, category: str | None = None, notes: str | None = None, started_at: str | None = None) -> str:
    """Add a product to the user's supplement tracking list.

    Args:
        product_id: UUID of the product (optional if manual entry).
        name: Supplement name for manual entry (required if product_id absent).
        brand: Brand name for manual entry.
        dosage: Dosage information for manual entry.
        category: Supplement category for manual entry.
        notes: Optional notes.
        started_at: Date when user started taking this supplement (YYYY-MM-DD).
    """
    body: dict = {}
    for key, val in [("product_id", product_id), ("name", name), ("brand", brand), ("dosage", dosage), ("category", category), ("notes", notes), ("started_at", started_at)]:
        if val is not None:
            body[key] = val
    return _json_result(await _client().create_supplement(body))


@mcp.tool()
async def get_supplement(supplement_id: str) -> str:
    """Get a user supplement tracking entry by ID.

    Args:
        supplement_id: UUID of the supplement entry.
    """
    return _json_result(await _client().get_supplement(supplement_id))


@mcp.tool()
async def update_supplement(supplement_id: str, notes: str | None = None, started_at: str | None = None) -> str:
    """Update a user supplement entry.

    Args:
        supplement_id: UUID of the supplement entry.
        notes: Updated notes.
        started_at: Updated start date (YYYY-MM-DD).
    """
    body: dict = {}
    if notes is not None:
        body["notes"] = notes
    if started_at is not None:
        body["started_at"] = started_at
    return _json_result(await _client().update_supplement(supplement_id, body))


@mcp.tool()
async def delete_supplement(supplement_id: str) -> str:
    """Remove a supplement from the user's tracking list.

    Args:
        supplement_id: UUID of the supplement entry.
    """
    return _json_result(await _client().delete_supplement(supplement_id))


@mcp.tool()
async def get_supplement_ical(supplement_id: str) -> str:
    """Export a supplement schedule as an iCal (.ics) file.

    Args:
        supplement_id: UUID of the supplement entry.
    """
    return _json_result(await _client().get_supplement_ical(supplement_id))


# ===================================================================
# Schedule tools
# ===================================================================


@mcp.tool()
async def list_schedules(supplement_id: str, cursor: str | None = None, limit: int | None = None) -> str:
    """List schedules for a supplement.

    Args:
        supplement_id: UUID of the supplement.
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().list_schedules(supplement_id, cursor=cursor, limit=limit))


@mcp.tool()
async def create_schedule(supplement_id: str, dose_amount: float, dose_unit: str, frequency: str, time_of_day: list[str], start_date: str, end_date: str | None = None, is_active: bool = True, reminder_enabled: bool = False, reminder_time: str | None = None) -> str:
    """Create a dosing schedule for a supplement.

    Args:
        supplement_id: UUID of the supplement.
        dose_amount: Amount per dose.
        dose_unit: Unit of measurement.
        frequency: How often (e.g. daily, twice_daily).
        time_of_day: Times of day (e.g. ["morning", "evening"]).
        start_date: Schedule start date (YYYY-MM-DD).
        end_date: Schedule end date (YYYY-MM-DD), null if ongoing.
        is_active: Whether the schedule is active (default true).
        reminder_enabled: Enable reminders (default false).
        reminder_time: Preferred reminder time (e.g. "08:00").
    """
    body: dict = {
        "supplement_id": supplement_id,
        "dose_amount": dose_amount,
        "dose_unit": dose_unit,
        "frequency": frequency,
        "time_of_day": time_of_day,
        "start_date": start_date,
        "is_active": is_active,
        "reminderEnabled": reminder_enabled,
    }
    if end_date is not None:
        body["end_date"] = end_date
    if reminder_time is not None:
        body["reminderTime"] = reminder_time
    return _json_result(await _client().create_schedule(supplement_id, body))


@mcp.tool()
async def update_schedule(schedule_id: str, dose_amount: float | None = None, dose_unit: str | None = None, frequency: str | None = None, time_of_day: list[str] | None = None, start_date: str | None = None, end_date: str | None = None, is_active: bool | None = None, reminder_enabled: bool | None = None, reminder_time: str | None = None) -> str:
    """Update a schedule. Only provided fields are changed.

    Args:
        schedule_id: UUID of the schedule.
        dose_amount: Amount per dose.
        dose_unit: Unit of measurement.
        frequency: How often.
        time_of_day: Times of day.
        start_date: Schedule start date.
        end_date: Schedule end date.
        is_active: Whether the schedule is active.
        reminder_enabled: Enable reminders.
        reminder_time: Preferred reminder time.
    """
    body: dict = {}
    for key, val in [("dose_amount", dose_amount), ("dose_unit", dose_unit), ("frequency", frequency), ("time_of_day", time_of_day), ("start_date", start_date), ("end_date", end_date), ("is_active", is_active), ("reminderEnabled", reminder_enabled), ("reminderTime", reminder_time)]:
        if val is not None:
            body[key] = val
    return _json_result(await _client().update_schedule(schedule_id, body))


@mcp.tool()
async def delete_schedule(schedule_id: str) -> str:
    """Delete a schedule by ID.

    Args:
        schedule_id: UUID of the schedule.
    """
    return _json_result(await _client().delete_schedule(schedule_id))


# ===================================================================
# Dose tools
# ===================================================================


@mcp.tool()
async def list_doses(supplement_id: str | None = None, start_date: str | None = None, end_date: str | None = None, cursor: str | None = None, limit: int | None = None) -> str:
    """List dose logs with optional filters.

    Args:
        supplement_id: Filter by supplement UUID.
        start_date: Filter from this date inclusive (YYYY-MM-DD).
        end_date: Filter until this date inclusive (YYYY-MM-DD).
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().list_doses(supplement_id=supplement_id, start_date=start_date, end_date=end_date, cursor=cursor, limit=limit))


@mcp.tool()
async def create_dose(supplement_id: str, dose_amount: float, dose_unit: str, taken_at: str, schedule_id: str | None = None, notes: str | None = None) -> str:
    """Log a new dose.

    Args:
        supplement_id: UUID of the supplement taken.
        dose_amount: Amount taken.
        dose_unit: Unit of measurement.
        taken_at: ISO 8601 timestamp when the dose was taken.
        schedule_id: UUID of the schedule this dose is logged against.
        notes: Optional notes.
    """
    body: dict = {
        "supplement_id": supplement_id,
        "dose_amount": dose_amount,
        "dose_unit": dose_unit,
        "taken_at": taken_at,
    }
    if schedule_id is not None:
        body["schedule_id"] = schedule_id
    if notes is not None:
        body["notes"] = notes
    return _json_result(await _client().create_dose(body))


@mcp.tool()
async def get_dose_summary(supplement_id: str, start_date: str, end_date: str) -> str:
    """Get aggregated dose summary for a supplement over a date range.

    Args:
        supplement_id: UUID of the supplement.
        start_date: Start date inclusive (YYYY-MM-DD).
        end_date: End date inclusive (YYYY-MM-DD).
    """
    return _json_result(await _client().get_dose_summary(supplement_id=supplement_id, start_date=start_date, end_date=end_date))


@mcp.tool()
async def update_dose(dose_id: str, dose_amount: float | None = None, dose_unit: str | None = None, taken_at: str | None = None, notes: str | None = None) -> str:
    """Update a dose log. Only provided fields are changed.

    Args:
        dose_id: UUID of the dose log.
        dose_amount: Updated amount.
        dose_unit: Updated unit.
        taken_at: Updated timestamp.
        notes: Updated notes.
    """
    body: dict = {}
    for key, val in [("dose_amount", dose_amount), ("dose_unit", dose_unit), ("taken_at", taken_at), ("notes", notes)]:
        if val is not None:
            body[key] = val
    return _json_result(await _client().update_dose(dose_id, body))


@mcp.tool()
async def delete_dose(dose_id: str) -> str:
    """Delete a dose log by ID.

    Args:
        dose_id: UUID of the dose log.
    """
    return _json_result(await _client().delete_dose(dose_id))


# ===================================================================
# Review tools
# ===================================================================


@mcp.tool()
async def list_review_prompts(product_id: str) -> str:
    """List review prompts for a product.

    Args:
        product_id: UUID of the product.
    """
    return _json_result(await _client().list_review_prompts(product_id=product_id))


@mcp.tool()
async def list_recent_reviews(cursor: str | None = None, limit: int | None = None) -> str:
    """List most recent approved reviews across all products.

    Args:
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().list_recent_reviews(cursor=cursor, limit=limit))


@mcp.tool()
async def list_moderation_queue(status: str | None = None, cursor: str | None = None, limit: int | None = None) -> str:
    """List reviews in the admin moderation queue. Defaults to pending and flagged.

    Args:
        status: Filter by moderation status (pending, approved, rejected, flagged).
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().list_moderation_queue(status=status, cursor=cursor, limit=limit))


@mcp.tool()
async def get_review(review_id: str) -> str:
    """Get a review by ID.

    Args:
        review_id: UUID of the review.
    """
    return _json_result(await _client().get_review(review_id))


@mcp.tool()
async def moderate_review(review_id: str, moderation_status: str) -> str:
    """Update review moderation status (admin only).

    Args:
        review_id: UUID of the review.
        moderation_status: New status (pending, approved, rejected, flagged).
    """
    return _json_result(await _client().moderate_review(review_id, {"moderation_status": moderation_status}))


@mcp.tool()
async def delete_review(review_id: str) -> str:
    """Delete a review by ID.

    Args:
        review_id: UUID of the review.
    """
    return _json_result(await _client().delete_review(review_id))


# ===================================================================
# Rewards tools
# ===================================================================


@mcp.tool()
async def list_points(cursor: str | None = None, limit: int | None = None) -> str:
    """List points ledger entries for the authenticated user.

    Args:
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().list_points(cursor=cursor, limit=limit))


@mcp.tool()
async def get_points_balance() -> str:
    """Get the current total points balance for the authenticated user."""
    return _json_result(await _client().get_points_balance())


@mcp.tool()
async def list_badges() -> str:
    """List all badges for the authenticated user, including earned status."""
    return _json_result(await _client().list_badges())


@mcp.tool()
async def get_streak() -> str:
    """Get the current dose logging streak for the authenticated user."""
    return _json_result(await _client().get_streak())


@mcp.tool()
async def list_challenges() -> str:
    """List active challenges for the authenticated user."""
    return _json_result(await _client().list_challenges())


@mcp.tool()
async def get_challenge(challenge_id: str) -> str:
    """Get a challenge by ID with current progress.

    Args:
        challenge_id: UUID of the challenge.
    """
    return _json_result(await _client().get_challenge(challenge_id))


# ===================================================================
# Brand tools (admin-only; read operations use public_* tools)
# ===================================================================


@mcp.tool()
async def create_brand(name: str, website: str | None = None, history: str | None = None, current_news: list[str] | None = None, logo_url: str | None = None, founded_year: int | None = None, headquarters: str | None = None, city: str | None = None, state: str | None = None, country: str | None = None) -> str:
    """Create a new brand (admin only).

    Args:
        name: Brand display name (required).
        website: Brand website URL.
        history: Short history or background.
        current_news: List of current news headlines.
        logo_url: URL of the brand logo.
        founded_year: Year the brand was founded.
        headquarters: Full headquarters address.
        city: Headquarters city.
        state: Headquarters state or province.
        country: Headquarters country.
    """
    body: dict = {"name": name}
    for key, val in [("website", website), ("history", history), ("current_news", current_news), ("logo_url", logo_url), ("founded_year", founded_year), ("headquarters", headquarters), ("city", city), ("state", state), ("country", country)]:
        if val is not None:
            body[key] = val
    return _json_result(await _client().create_brand(body))


@mcp.tool()
async def update_brand(brand_id: str, name: str | None = None, website: str | None = None, history: str | None = None, current_news: list[str] | None = None, logo_url: str | None = None, founded_year: int | None = None, headquarters: str | None = None, city: str | None = None, state: str | None = None, country: str | None = None, parent_company: str | None = None, brand_type: str | None = None, known_for: list[str] | None = None, badges: list[str] | None = None, website_platform: str | None = None, contact_email: str | None = None) -> str:
    """Update a brand (admin only). Only provided fields are changed.

    Args:
        brand_id: UUID of the brand.
        name: Brand display name.
        website: Brand website URL.
        history: Short history or background.
        current_news: List of current news headlines.
        logo_url: URL of the brand logo.
        founded_year: Year the brand was founded.
        headquarters: Full headquarters address.
        city: Headquarters city.
        state: Headquarters state or province.
        country: Headquarters country.
        parent_company: Parent company name (e.g. "Crush It Holdings").
        brand_type: Brand classification (independent, subsidiary, house_brand, white_label).
        known_for: Key product categories or claims the brand is known for.
        badges: Quality and certification badges (e.g. GMP Tested, Non-GMO, Made in USA).
        website_platform: E-commerce platform (e.g. Shopify, Amazon, WooCommerce).
        contact_email: Brand contact email address.
    """
    body: dict = {}
    for key, val in [("name", name), ("website", website), ("history", history), ("current_news", current_news), ("logo_url", logo_url), ("founded_year", founded_year), ("headquarters", headquarters), ("city", city), ("state", state), ("country", country), ("parent_company", parent_company), ("brand_type", brand_type), ("known_for", known_for), ("badges", badges), ("website_platform", website_platform), ("contact_email", contact_email)]:
        if val is not None:
            body[key] = val
    return _json_result(await _client().update_brand(brand_id, body))


@mcp.tool()
async def delete_brand(brand_id: str) -> str:
    """Delete a brand (admin only).

    Args:
        brand_id: UUID of the brand.
    """
    return _json_result(await _client().delete_brand(brand_id))


@mcp.tool()
async def create_brand_review(brand_id: str, rating: int, title: str, body: str) -> str:
    """Create a review for a brand. Body is scanned for DSHEA claim words.

    Args:
        brand_id: UUID of the brand.
        rating: Rating from 1 to 5.
        title: Review title.
        body: Review body text.
    """
    return _json_result(await _client().create_brand_review(brand_id, {"rating": rating, "title": title, "body": body}))


# ===================================================================
# Public discovery tools (no auth required)
# ===================================================================


@mcp.tool()
async def public_search_products(q: str | None = None, category: str | None = None, ingredient: str | None = None, ingredient_q: str | None = None, brand: str | None = None, brand_id: str | None = None, upc: str | None = None, tag: str | None = None, sort: str | None = None, order: str | None = None, cursor: str | None = None, limit: int | None = None) -> str:
    """Search products publicly (no auth). Supports text, category, ingredient, brand, and tag filters with sorting.

    Args:
        q: Text search on product name, brand, or ingredients (case-insensitive substring).
        category: Comma-separated category exact match (OR logic).
        ingredient: Comma-separated ingredient name exact match (OR logic, case-insensitive).
        ingredient_q: Ingredient name substring match (case-insensitive).
        brand: Comma-separated brand name exact match (OR logic, case-insensitive).
        brand_id: Brand UUID exact match.
        upc: UPC barcode exact match.
        tag: Comma-separated use-case tag filter.
        sort: Sort field (name, averageRating, reviewCount, created_at).
        order: Sort direction (asc or desc, default asc).
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().public_search_products(q=q, category=category, ingredient=ingredient, ingredient_q=ingredient_q, brand=brand, brand_id=brand_id, upc=upc, tag=tag, sort=sort, order=order, cursor=cursor, limit=limit))


@mcp.tool()
async def public_get_product_facets() -> str:
    """Get pre-computed product facet counts (category, brand, ingredient). No auth."""
    return _json_result(await _client().public_get_product_facets())


@mcp.tool()
async def public_get_product_search_index() -> str:
    """Get product search index stats (total count, etc.). No auth."""
    return _json_result(await _client().public_get_product_search_index())


@mcp.tool()
async def public_get_brand_search_index() -> str:
    """Get brand search index stats (total count, etc.). No auth."""
    return _json_result(await _client().public_get_brand_search_index())


@mcp.tool()
async def public_get_ingredient_search_index() -> str:
    """Get ingredient search index stats (total count, etc.). No auth."""
    return _json_result(await _client().public_get_ingredient_search_index())


@mcp.tool()
async def public_get_product_discovery_index() -> str:
    """Get product discovery index with rank_score for browse/discovery pages (CDN, no auth)."""
    return _json_result(await _client().public_get_product_discovery_index())


@mcp.tool()
async def public_get_brand_discovery_index() -> str:
    """Get brand discovery index with rank_score for browse/discovery pages (CDN, no auth)."""
    return _json_result(await _client().public_get_brand_discovery_index())


@mcp.tool()
async def public_get_ingredient_discovery_index() -> str:
    """Get ingredient discovery index with rank_score for browse/discovery pages (CDN, no auth)."""
    return _json_result(await _client().public_get_ingredient_discovery_index())


@mcp.tool()
async def public_get_product(product_id: str) -> str:
    """Get public product detail with rating distribution. No auth.

    Args:
        product_id: UUID of the product.
    """
    return _json_result(await _client().public_get_product(product_id))


@mcp.tool()
async def public_list_product_reviews(product_id: str, cursor: str | None = None, limit: int | None = None) -> str:
    """List approved reviews for a product publicly. No auth.

    Args:
        product_id: UUID of the product.
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().public_list_product_reviews(product_id, cursor=cursor, limit=limit))


@mcp.tool()
async def public_record_affiliate_click(product_id: str) -> str:
    """Record an affiliate click event (fire-and-forget). No auth.

    Args:
        product_id: UUID of the product.
    """
    return _json_result(await _client().public_record_affiliate_click(product_id))


@mcp.tool()
async def public_get_product_completeness(product_id: str) -> str:
    """Get completeness score for a product (public, no auth).

    Args:
        product_id: UUID of the product.
    """
    return _json_result(await _client().public_get_product_completeness(product_id))


@mcp.tool()
async def upload_product_image(product_id: str, filename: str = "main.png") -> str:
    """Get a presigned S3 PUT URL for uploading a product image (admin only).

    After uploading the file to the returned URL, the product's imageUrl
    is automatically updated to the CDN URL.

    Args:
        product_id: UUID of the product.
        filename: Image filename with extension (e.g. main.png, main.webp, main.jpg).
    """
    return _json_result(await _client().upload_product_image(product_id, filename))


@mcp.tool()
async def upload_brand_logo(brand_id: str, filename: str = "logo.png") -> str:
    """Get a presigned S3 PUT URL for uploading a brand logo (admin only).

    After uploading the file to the returned URL, the brand's logo_url
    is automatically updated to the CDN URL.

    Args:
        brand_id: UUID of the brand.
        filename: Logo filename with extension (e.g. logo.png, logo.webp, logo.jpg).
    """
    return _json_result(await _client().upload_brand_logo(brand_id, filename))


@mcp.tool()
async def public_list_brands(cursor: str | None = None, limit: int | None = None) -> str:
    """List all brands publicly. No auth.

    Args:
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().public_list_brands(cursor=cursor, limit=limit))


@mcp.tool()
async def public_search_brands(q: str | None = None, name: str | None = None, city: str | None = None, state: str | None = None, country: str | None = None, sort: str | None = None, order: str | None = None, cursor: str | None = None, limit: int | None = None) -> str:
    """Search brands publicly with text, name, location filters, and sorting. No auth.

    Args:
        q: Text search on brand name and headquarters (case-insensitive substring match).
        name: Exact match on brand name (case-insensitive).
        city: Exact match on city (case-insensitive).
        state: Exact match on state or province (case-insensitive).
        country: Exact match on country (case-insensitive).
        sort: Sort field (name, founded_year, averageRating, reviewCount).
        order: Sort direction (asc or desc, default asc).
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().public_search_brands(q=q, name=name, city=city, state=state, country=country, sort=sort, order=order, cursor=cursor, limit=limit))


@mcp.tool()
async def public_get_brand_facets() -> str:
    """Get pre-computed brand facet counts by location (city, state, country). No auth."""
    return _json_result(await _client().public_get_brand_facets())


@mcp.tool()
async def public_get_brand(brand_id: str) -> str:
    """Get brand detail publicly. No auth.

    Args:
        brand_id: UUID of the brand.
    """
    return _json_result(await _client().public_get_brand(brand_id))


@mcp.tool()
async def public_list_brand_products(brand_id: str, cursor: str | None = None, limit: int | None = None) -> str:
    """List products for a brand publicly. No auth.

    Args:
        brand_id: UUID of the brand.
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().public_list_brand_products(brand_id, cursor=cursor, limit=limit))


@mcp.tool()
async def public_list_brand_reviews(brand_id: str, cursor: str | None = None, limit: int | None = None) -> str:
    """List approved reviews for a brand publicly. No auth.

    Args:
        brand_id: UUID of the brand.
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().public_list_brand_reviews(brand_id, cursor=cursor, limit=limit))


# ===================================================================
# News tools
# ===================================================================


@mcp.tool()
async def public_list_news(sponsored: bool | None = None, from_date: str | None = None, to_date: str | None = None, q: str | None = None, tag: str | None = None, cursor: str | None = None, limit: int | None = None) -> str:
    """List curated news feed in reverse chronological order. No auth.

    Args:
        sponsored: Filter by sponsored flag.
        from_date: Inclusive start date (YYYY-MM-DD).
        to_date: Inclusive end date (YYYY-MM-DD).
        q: Text search on title and summary.
        tag: Exact match on tags.
        cursor: Opaque pagination cursor.
        limit: Items per page (5-20, default 10).
    """
    return _json_result(await _client().public_list_news(sponsored=sponsored, from_date=from_date, to_date=to_date, q=q, tag=tag, cursor=cursor, limit=limit))


@mcp.tool()
async def public_get_news(news_id: str) -> str:
    """Get a single news item with full content. No auth.

    Args:
        news_id: UUID of the news item.
    """
    return _json_result(await _client().public_get_news(news_id))


@mcp.tool()
async def admin_create_news(title: str, summary: str, content: str, publication_date: str, source_attribution: str, sponsored: bool = False, tags: list[str] | None = None) -> str:
    """Create a news item (admin only).

    Args:
        title: Headline of the news entry.
        summary: Short summary.
        content: Full article body.
        publication_date: Publication date (YYYY-MM-DD).
        source_attribution: Origin or credit for the content.
        sponsored: Whether the item is sponsored (default false).
        tags: Topic tags (e.g. ["ingredients", "industry"]).
    """
    body: dict = {
        "title": title,
        "summary": summary,
        "content": content,
        "publication_date": publication_date,
        "source_attribution": source_attribution,
        "sponsored": sponsored,
    }
    if tags is not None:
        body["tags"] = tags
    return _json_result(await _client().admin_create_news(body))


@mcp.tool()
async def admin_update_news(news_id: str, title: str | None = None, summary: str | None = None, content: str | None = None, publication_date: str | None = None, source_attribution: str | None = None, sponsored: bool | None = None, tags: list[str] | None = None) -> str:
    """Update a news item (admin only). Only provided fields are changed.

    Args:
        news_id: UUID of the news item.
        title: Headline.
        summary: Short summary.
        content: Full article body.
        publication_date: Publication date (YYYY-MM-DD).
        source_attribution: Origin or credit.
        sponsored: Whether sponsored.
        tags: Topic tags.
    """
    body: dict = {}
    for key, val in [("title", title), ("summary", summary), ("content", content), ("publication_date", publication_date), ("source_attribution", source_attribution), ("sponsored", sponsored), ("tags", tags)]:
        if val is not None:
            body[key] = val
    return _json_result(await _client().admin_update_news(news_id, body))


@mcp.tool()
async def admin_delete_news(news_id: str) -> str:
    """Delete a news item (admin only).

    Args:
        news_id: UUID of the news item.
    """
    return _json_result(await _client().admin_delete_news(news_id))


# ===================================================================
# Ingredient tools (authenticated, admin for write operations)
# ===================================================================


@mcp.tool()
async def list_ingredients(cursor: str | None = None, limit: int | None = None, type: str | None = None) -> str:
    """List ingredients (paginated). Optionally filter by type.

    Args:
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
        type: Filter by ingredient type (vitamin, mineral, amino_acid, fatty_acid, probiotic, herbal, botanical, enzyme, fiber, protein, antioxidant, other).
    """
    return _json_result(await _client().list_ingredients(cursor=cursor, limit=limit, type=type))


@mcp.tool()
async def create_ingredient(name: str, type: str, description: str, health_effects: list[dict] | None = None, natural_sources: list[str] | None = None, safety_notes: str | None = None, daily_value: float | None = None, daily_value_unit: str | None = None, upper_limit: float | None = None, upper_limit_unit: str | None = None, common_forms: list[str] | None = None) -> str:
    """Create an ingredient (admin only).

    Args:
        name: Ingredient name (required).
        type: Ingredient type (required). Valid values: vitamin, mineral, amino_acid, fatty_acid, probiotic, herbal, botanical, enzyme, fiber, protein, antioxidant, other.
        description: Description of the ingredient (required).
        health_effects: List of health effect objects with 'effect' (str) and 'evidence_level' (strong|moderate|preliminary|traditional).
        natural_sources: List of natural sources.
        safety_notes: Safety notes or warnings.
        daily_value: Recommended daily value amount.
        daily_value_unit: Unit for the daily value (e.g. "mcg", "mg", "IU").
        upper_limit: Tolerable upper intake level per day.
        upper_limit_unit: Unit for the upper limit (e.g. "mcg", "mg").
        common_forms: Common supplement forms (e.g. ["Cholecalciferol", "Citrate"]).
    """
    body: dict = {"name": name, "type": type, "description": description}
    for key, val in [("health_effects", health_effects), ("natural_sources", natural_sources), ("safety_notes", safety_notes), ("daily_value", daily_value), ("daily_value_unit", daily_value_unit), ("upper_limit", upper_limit), ("upper_limit_unit", upper_limit_unit), ("common_forms", common_forms)]:
        if val is not None:
            body[key] = val
    return _json_result(await _client().create_ingredient(body))


@mcp.tool()
async def search_ingredients(q: str | None = None, name: str | None = None, type: str | None = None, sort: str | None = None, order: str | None = None, cursor: str | None = None, limit: int | None = None) -> str:
    """Search ingredients by text query, exact name, or type. Supports sorting.

    Args:
        q: Text search on ingredient name (case-insensitive substring).
        name: Exact ingredient name match (via normalized name GSI).
        type: Filter by ingredient type.
        sort: Sort field (name or product_count).
        order: Sort direction (asc or desc, default asc).
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().search_ingredients(q=q, name=name, type=type, sort=sort, order=order, cursor=cursor, limit=limit))


@mcp.tool()
async def get_ingredient_facets() -> str:
    """Get ingredient facet counts by type."""
    return _json_result(await _client().get_ingredient_facets())


@mcp.tool()
async def get_ingredient(ingredient_id: str) -> str:
    """Get full ingredient details by ID.

    Args:
        ingredient_id: UUID of the ingredient.
    """
    return _json_result(await _client().get_ingredient(ingredient_id))


@mcp.tool()
async def update_ingredient(ingredient_id: str, name: str | None = None, type: str | None = None, description: str | None = None, health_effects: list[dict] | None = None, natural_sources: list[str] | None = None, safety_notes: str | None = None, daily_value: float | None = None, daily_value_unit: str | None = None, upper_limit: float | None = None, upper_limit_unit: str | None = None, common_forms: list[str] | None = None, interactions: list[dict] | None = None, contraindications: list[str] | None = None, benefit_categories: list[str] | None = None, pregnancy_safety: str | None = None) -> str:
    """Update an ingredient (admin only). Only provided fields are changed.

    Args:
        ingredient_id: UUID of the ingredient.
        name: Ingredient name.
        type: Ingredient type.
        description: Description of the ingredient.
        health_effects: List of health effect objects with 'effect' (str) and 'evidence_level' (strong|moderate|preliminary|traditional).
        natural_sources: List of natural sources.
        safety_notes: Safety notes or warnings.
        daily_value: Recommended daily value amount.
        daily_value_unit: Unit for the daily value (e.g. "mcg", "mg", "IU").
        upper_limit: Tolerable upper intake level per day.
        upper_limit_unit: Unit for the upper limit (e.g. "mcg", "mg").
        common_forms: Common supplement forms.
        interactions: List of interaction objects with interacts_with, interaction_type, severity, description, recommendation.
        contraindications: List of conditions where this ingredient should be avoided.
        benefit_categories: List of benefit category slugs.
        pregnancy_safety: Pregnancy safety classification (safe, caution, avoid, insufficient_data).
    """
    body: dict = {}
    for key, val in [("name", name), ("type", type), ("description", description), ("health_effects", health_effects), ("natural_sources", natural_sources), ("safety_notes", safety_notes), ("daily_value", daily_value), ("daily_value_unit", daily_value_unit), ("upper_limit", upper_limit), ("upper_limit_unit", upper_limit_unit), ("common_forms", common_forms), ("interactions", interactions), ("contraindications", contraindications), ("benefit_categories", benefit_categories), ("pregnancy_safety", pregnancy_safety)]:
        if val is not None:
            body[key] = val
    return _json_result(await _client().update_ingredient(ingredient_id, body))


@mcp.tool()
async def delete_ingredient(ingredient_id: str) -> str:
    """Delete an ingredient by ID (admin only).

    Args:
        ingredient_id: UUID of the ingredient.
    """
    return _json_result(await _client().delete_ingredient(ingredient_id))


@mcp.tool()
async def list_ingredient_products(ingredient_id: str, cursor: str | None = None, limit: int | None = None) -> str:
    """List products containing a specific ingredient.

    Args:
        ingredient_id: UUID of the ingredient.
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().list_ingredient_products(ingredient_id, cursor=cursor, limit=limit))


@mcp.tool()
async def bulk_create_ingredients(ingredients: list[dict]) -> str:
    """Bulk create up to 25 ingredients in a single request (admin only).

    Each ingredient is validated and persisted independently — failures for one
    item do not block others. Returns created ingredients and per-item errors.

    Args:
        ingredients: List of ingredient objects (max 25). Each requires at minimum
            'name', 'type', and 'description'. Optional fields: health_effects,
            natural_sources, safety_notes, daily_value, daily_value_unit,
            upper_limit, upper_limit_unit, common_forms.
    """
    return _json_result(await _client().bulk_create_ingredients(ingredients))


@mcp.tool()
async def bulk_update_ingredients(ingredients: list[dict]) -> str:
    """Bulk update up to 25 ingredients in a single request (admin only).

    Each ingredient update is applied independently. Each item in the list must
    include an 'id' field plus any fields to update.

    Args:
        ingredients: List of ingredient update objects (max 25). Each requires 'id'
            (UUID). Optional fields to update: name, type, description, health_effects,
            natural_sources, safety_notes, daily_value, daily_value_unit,
            upper_limit, upper_limit_unit, common_forms.
    """
    return _json_result(await _client().bulk_update_ingredients(ingredients))


@mcp.tool()
async def list_unlinked_ingredients(cursor: str | None = None, limit: int | None = None) -> str:
    """List product ingredient names that are not linked to an ingredient entity (admin only).

    Args:
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().list_unlinked_ingredients(cursor=cursor, limit=limit))


@mcp.tool()
async def auto_link_ingredients() -> str:
    """Auto-link product ingredients to ingredient entities by name match (admin only).

    Scans unlinked product ingredient names and attempts to match them to existing
    ingredient entities. Returns counts of linked and unlinked items.
    """
    return _json_result(await _client().auto_link_ingredients())


@mcp.tool()
async def get_ingredient_analytics() -> str:
    """Get ingredient coverage and linking statistics (admin only).

    Returns analytics data including total ingredients, linked vs unlinked counts,
    and coverage percentages.
    """
    return _json_result(await _client().get_ingredient_analytics())


@mcp.tool()
async def merge_ingredient(ingredient_id: str, target_id: str) -> str:
    """Merge a duplicate ingredient into a target ingredient (admin only).

    The source ingredient is deleted and all product references are updated
    to point to the target ingredient.

    Args:
        ingredient_id: UUID of the source ingredient to merge from (will be deleted).
        target_id: UUID of the target ingredient to merge into (will be kept).
    """
    return _json_result(await _client().merge_ingredient(ingredient_id, {"target_id": target_id}))


# ===================================================================
# Public Ingredient tools (no auth required)
# ===================================================================


@mcp.tool()
async def public_list_ingredients(cursor: str | None = None, limit: int | None = None, type: str | None = None) -> str:
    """List ingredients publicly (no auth). Optionally filter by type.

    Args:
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
        type: Filter by ingredient type.
    """
    return _json_result(await _client().public_list_ingredients(cursor=cursor, limit=limit, type=type))


@mcp.tool()
async def public_search_ingredients(q: str | None = None, name: str | None = None, type: str | None = None, cursor: str | None = None, limit: int | None = None) -> str:
    """Search ingredients publicly (no auth). Supports text query, exact name, and type filter.

    Args:
        q: Text search on ingredient name (case-insensitive substring).
        name: Exact ingredient name match.
        type: Filter by ingredient type.
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().public_search_ingredients(q=q, name=name, type=type, cursor=cursor, limit=limit))


@mcp.tool()
async def public_get_ingredient_facets() -> str:
    """Get ingredient facet counts by type (no auth)."""
    return _json_result(await _client().public_get_ingredient_facets())


@mcp.tool()
async def public_get_ingredient(ingredient_id: str) -> str:
    """Get full ingredient details publicly (no auth).

    Args:
        ingredient_id: UUID of the ingredient.
    """
    return _json_result(await _client().public_get_ingredient(ingredient_id))


@mcp.tool()
async def public_list_ingredient_products(ingredient_id: str, cursor: str | None = None, limit: int | None = None) -> str:
    """List products containing a specific ingredient publicly (no auth).

    Args:
        ingredient_id: UUID of the ingredient.
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().public_list_ingredient_products(ingredient_id, cursor=cursor, limit=limit))


# ===================================================================
# Ingredient Intelligence tools (public, no auth)
# ===================================================================


@mcp.tool()
async def get_ingredient_alternatives(ingredient_id: str) -> str:
    """List alternative forms and related ingredients (public, no auth).

    Returns alternative forms of the same parent ingredient (e.g., Magnesium
    Glycinate vs Magnesium Citrate). Sorted by product count descending.

    Args:
        ingredient_id: UUID of the ingredient.
    """
    return _json_result(await _client().get_ingredient_alternatives(ingredient_id))


@mcp.tool()
async def get_ingredient_interactions(ingredient_id: str, severity: str | None = None, type: str | None = None) -> str:
    """Get drug, ingredient, and condition interaction warnings (public, no auth).

    Returns known interactions for an ingredient. Optionally filter by
    severity or type.

    Args:
        ingredient_id: UUID of the ingredient.
        severity: Filter by severity (mild, moderate, severe).
        type: Filter by interaction type (drug, ingredient, condition).
    """
    return _json_result(await _client().get_ingredient_interactions(ingredient_id, severity=severity, type=type))


@mcp.tool()
async def get_ingredient_dosing_guide(ingredient_id: str) -> str:
    """Get effective dose range, form recommendations, and bioavailability (public, no auth).

    Args:
        ingredient_id: UUID of the ingredient.
    """
    return _json_result(await _client().get_ingredient_dosing_guide(ingredient_id))


@mcp.tool()
async def get_ingredient_effectiveness(ingredient_id: str) -> str:
    """Get popularity vs user satisfaction quadrant data for an ingredient (public, no auth).

    Args:
        ingredient_id: UUID of the ingredient.
    """
    return _json_result(await _client().get_ingredient_effectiveness(ingredient_id))


@mcp.tool()
async def get_trending_ingredients(limit: int | None = None, period: str | None = None) -> str:
    """Get top trending ingredients by popularity (public, no auth).

    Args:
        limit: Maximum number of results to return.
        period: Time period for trending calculation.
    """
    return _json_result(await _client().get_trending_ingredients(limit=limit, period=period))


@mcp.tool()
async def get_ingredients_by_benefit(benefit_slug: str, limit: int | None = None) -> str:
    """Get ingredients ranked for a specific benefit category (public, no auth).

    Args:
        benefit_slug: URL-friendly benefit category slug (e.g., "sleep", "energy").
        limit: Maximum number of results to return.
    """
    return _json_result(await _client().get_ingredients_by_benefit(benefit_slug, limit=limit))


@mcp.tool()
async def compare_ingredients(slug: str) -> str:
    """Compare two ingredients side-by-side (public, no auth).

    Args:
        slug: Comparison slug in format 'ingredient-a-vs-ingredient-b'
            (e.g., magnesium-glycinate-vs-magnesium-citrate).
    """
    return _json_result(await _client().compare_ingredients(slug))


# ===================================================================
# Scoring tools (public, no auth)
# ===================================================================


@mcp.tool()
async def get_product_ingredient_score(product_id: str) -> str:
    """Get dosage adequacy and transparency score for a product (public, no auth).

    Args:
        product_id: UUID of the product.
    """
    return _json_result(await _client().get_product_ingredient_score(product_id))


@mcp.tool()
async def compare_products(ids: str) -> str:
    """Compare 2-4 products by ingredient scores (public, no auth).

    Args:
        ids: Comma-separated product IDs (2-4 UUIDs).
    """
    return _json_result(await _client().compare_products(ids))


# ===================================================================
# Stack Analysis tools (authenticated)
# ===================================================================


@mcp.tool()
async def stack_analysis() -> str:
    """Full analysis of user's supplement stack.

    Returns combined daily totals, overlaps, and warnings for all
    supplements in the authenticated user's stack.
    """
    return _json_result(await _client().stack_analysis())


@mcp.tool()
async def stack_daily_totals() -> str:
    """Sum daily intake per ingredient vs daily value and upper limit.

    Returns the total daily intake for each ingredient across all supplements
    in the user's stack, compared against recommended daily values.
    """
    return _json_result(await _client().stack_daily_totals())


@mcp.tool()
async def stack_gaps() -> str:
    """Identify missing ingredients per health goal.

    Returns ingredients that the user's health goals suggest they should be
    taking but are not currently in their supplement stack.
    """
    return _json_result(await _client().stack_gaps())


@mcp.tool()
async def stack_overlaps() -> str:
    """Detect ingredient overlaps across products in the user's stack.

    Returns ingredients that appear in multiple products, with total amounts
    and potential over-supplementation warnings.
    """
    return _json_result(await _client().stack_overlaps())


@mcp.tool()
async def stack_recommendations() -> str:
    """Get personalized ingredient recommendations based on health goals.

    Returns recommended ingredients excluding those already in the user's stack,
    based on their configured health goals.
    """
    return _json_result(await _client().stack_recommendations())


@mcp.tool()
async def stack_warnings() -> str:
    """Get interaction and overdose warnings for the user's supplement stack.

    Returns warnings sorted by severity, including ingredient interactions
    and ingredients exceeding tolerable upper limits.
    """
    return _json_result(await _client().stack_warnings())


# ===================================================================
# Authenticated product read tools
# ===================================================================


@mcp.tool()
async def list_products(cursor: str | None = None, limit: int | None = None, category: str | None = None) -> str:
    """List products with optional category filter (authenticated).

    Args:
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
        category: Filter by supplement category.
    """
    return _json_result(await _client().list_products(cursor=cursor, limit=limit, category=category))


@mcp.tool()
async def search_products(q: str | None = None, category: str | None = None, brand: str | None = None, brand_id: str | None = None, upc: str | None = None, ingredient: str | None = None, ingredient_q: str | None = None, sort: str | None = None, order: str | None = None, cursor: str | None = None, limit: int | None = None) -> str:
    """Search products with text query, filters, and sorting (authenticated).

    Args:
        q: Text search on product name, brand, or ingredients (case-insensitive substring).
        category: Comma-separated category exact match (OR logic).
        brand: Comma-separated brand name exact match (OR logic, case-insensitive).
        brand_id: Brand UUID exact match.
        upc: UPC barcode exact match.
        ingredient: Comma-separated ingredient name exact match (OR logic, case-insensitive).
        ingredient_q: Ingredient name substring match (case-insensitive).
        sort: Sort field (name, averageRating, reviewCount, created_at).
        order: Sort direction (asc or desc, default asc).
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().search_products(q=q, category=category, brand=brand, brand_id=brand_id, upc=upc, ingredient=ingredient, ingredient_q=ingredient_q, sort=sort, order=order, cursor=cursor, limit=limit))


@mcp.tool()
async def get_product(product_id: str) -> str:
    """Get a product by ID (authenticated).

    Args:
        product_id: UUID of the product.
    """
    return _json_result(await _client().get_product(product_id))


@mcp.tool()
async def list_product_reviews(product_id: str, cursor: str | None = None, limit: int | None = None) -> str:
    """List reviews for a product (authenticated).

    Args:
        product_id: UUID of the product.
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().list_product_reviews(product_id, cursor=cursor, limit=limit))


# ===================================================================
# Authenticated brand read tools
# ===================================================================


@mcp.tool()
async def list_brands(q: str | None = None, name: str | None = None, city: str | None = None, state: str | None = None, country: str | None = None, sort: str | None = None, order: str | None = None, cursor: str | None = None, limit: int | None = None) -> str:
    """List and search brands (authenticated, with optional filters and sorting).

    Args:
        q: Text search on brand name and headquarters (case-insensitive substring match).
        name: Exact match on brand name (case-insensitive).
        city: Exact match on city (case-insensitive).
        state: Exact match on state or province (case-insensitive).
        country: Exact match on country (case-insensitive).
        sort: Sort field (name, founded_year, averageRating, reviewCount).
        order: Sort direction (asc or desc, default asc).
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().search_brands(q=q, name=name, city=city, state=state, country=country, sort=sort, order=order, cursor=cursor, limit=limit))


@mcp.tool()
async def get_brand(brand_id: str) -> str:
    """Get full brand details (authenticated).

    Args:
        brand_id: UUID of the brand.
    """
    return _json_result(await _client().get_brand(brand_id))


@mcp.tool()
async def list_brand_products(brand_id: str, cursor: str | None = None, limit: int | None = None) -> str:
    """List products belonging to a brand (authenticated).

    Args:
        brand_id: UUID of the brand.
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().list_brand_products(brand_id, cursor=cursor, limit=limit))


@mcp.tool()
async def list_brand_reviews(brand_id: str, cursor: str | None = None, limit: int | None = None) -> str:
    """List reviews for a brand (authenticated).

    Args:
        brand_id: UUID of the brand.
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().list_brand_reviews(brand_id, cursor=cursor, limit=limit))


# ===================================================================
# Suggestion tools (user)
# ===================================================================


@mcp.tool()
async def admin_list_users(cursor: str | None = None, limit: int | None = None, sort: str | None = None, order: str | None = None, q: str | None = None, status: str | None = None) -> str:
    """List all user profiles (admin only).

    Args:
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
        sort: Sort field (displayName, email, createdAt, lastActiveAt).
        order: Sort direction (asc or desc, default desc).
        q: Text search on displayName and email (case-insensitive).
        status: Filter by account status (active, suspended).
    """
    return _json_result(await _client().admin_list_users(cursor=cursor, limit=limit, sort=sort, order=order, q=q, status=status))


@mcp.tool()
async def admin_get_user(user_id: str) -> str:
    """Get Cognito account details for a user (admin only).

    Returns account-level information including email, status, enabled flag,
    and auth method.

    Args:
        user_id: Cognito user sub (UUID).
    """
    return _json_result(await _client().admin_get_user(user_id))


@mcp.tool()
async def admin_get_user_profile(user_id: str) -> str:
    """Get the full app-level profile for a user (admin only).

    Returns the complete profile document including interest categories,
    dietary restrictions, health goals, allergies, bio, and preferences.

    Args:
        user_id: Cognito user sub (UUID).
    """
    return _json_result(await _client().admin_get_user_profile(user_id))


@mcp.tool()
async def admin_update_user_profile(user_id: str, display_name: str | None = None, interest_categories: list[str] | None = None, avatar_url: str | None = None, preferences: dict | None = None, enabled: bool | None = None) -> str:
    """Update a user's profile (admin only). Only provided fields are changed.

    Args:
        user_id: Cognito user sub (UUID).
        display_name: New display name.
        interest_categories: Updated supplement interest categories.
        avatar_url: New avatar URL.
        preferences: Key-value preferences object.
        enabled: Enable or disable the user's Cognito account.
    """
    body: dict = {}
    if display_name is not None:
        body["displayName"] = display_name
    if interest_categories is not None:
        body["interestCategories"] = interest_categories
    if avatar_url is not None:
        body["avatarUrl"] = avatar_url
    if preferences is not None:
        body["preferences"] = preferences
    if enabled is not None:
        body["enabled"] = enabled
    return _json_result(await _client().admin_update_user_profile(user_id, body))


@mcp.tool()
async def list_my_suggestions(cursor: str | None = None, limit: int | None = None) -> str:
    """List the authenticated user's suggestions.

    Args:
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().list_my_suggestions(cursor=cursor, limit=limit))


@mcp.tool()
async def create_suggestion(suggestion_type: str, entity_type: str | None = None, target_id: str | None = None, payload: dict | None = None, message: str | None = None, notes: str | None = None) -> str:
    """Submit a new suggestion (structured or general).

    Args:
        suggestion_type: Type of suggestion. Valid values: product_image, product_name, product_upc, product_category, product_ingredients, product_dosage, brand_name, brand_website, brand_logo, brand_location, ingredient_name, ingredient_category, general.
        entity_type: Entity type (product, brand, ingredient). Required for structured suggestions.
        target_id: UUID of the entity being suggested for change. Required for structured suggestions.
        payload: Field-specific data per suggestion_type. Required for structured suggestions.
        message: Free-text user feedback. Required for general suggestions.
        notes: Optional user explanation of why this change is needed.
    """
    body: dict = {"suggestion_type": suggestion_type}
    for key, val in [("entity_type", entity_type), ("target_id", target_id), ("payload", payload), ("message", message), ("notes", notes)]:
        if val is not None:
            body[key] = val
    return _json_result(await _client().create_suggestion(body))


@mcp.tool()
async def get_suggestion(suggestion_id: str) -> str:
    """Get a specific suggestion by ID.

    Args:
        suggestion_id: UUID of the suggestion.
    """
    return _json_result(await _client().get_suggestion(suggestion_id))


@mcp.tool()
async def upload_suggestion_image(suggestion_id: str, filename: str = "image.png") -> str:
    """Get a presigned URL for uploading an image to a suggestion. Only for product_image and brand_logo types.

    Args:
        suggestion_id: UUID of the suggestion.
        filename: Filename for the uploaded image (default: image.png).
    """
    return _json_result(await _client().upload_suggestion_image(suggestion_id, {"filename": filename}))


# ===================================================================
# Suggestion tools (admin)
# ===================================================================


@mcp.tool()
async def admin_list_suggestions(status: str | None = None, cursor: str | None = None, limit: int | None = None) -> str:
    """List suggestions by status for admin moderation queue. Defaults to pending.

    Args:
        status: Filter by suggestion status (pending, approved, rejected).
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().admin_list_suggestions(status=status, cursor=cursor, limit=limit))


@mcp.tool()
async def admin_get_suggestion(suggestion_id: str) -> str:
    """Get full suggestion details (admin).

    Args:
        suggestion_id: UUID of the suggestion.
    """
    return _json_result(await _client().admin_get_suggestion(suggestion_id))


@mcp.tool()
async def admin_review_suggestion(suggestion_id: str, status: str, admin_notes: str | None = None, admin_payload: dict | None = None) -> str:
    """Approve or reject a suggestion (admin only). On approve, the suggestion is auto-applied.

    Args:
        suggestion_id: UUID of the suggestion.
        status: Terminal status (approved or rejected).
        admin_notes: Optional notes from the reviewer.
        admin_payload: Required when approving a general suggestion. Object with entity_type, target_id, and fields.
    """
    body: dict = {"status": status}
    if admin_notes is not None:
        body["admin_notes"] = admin_notes
    if admin_payload is not None:
        body["admin_payload"] = admin_payload
    return _json_result(await _client().admin_review_suggestion(suggestion_id, body))


@mcp.tool()
async def admin_edit_suggestion(suggestion_id: str, suggestion_type: str | None = None, entity_type: str | None = None, target_id: str | None = None, payload: dict | None = None, message: str | None = None, notes: str | None = None) -> str:
    """Edit a suggestion's content before review (admin only). Only provided fields are changed.

    Args:
        suggestion_id: UUID of the suggestion.
        suggestion_type: Updated suggestion type.
        entity_type: Updated entity type (product, brand, ingredient).
        target_id: Updated target entity UUID.
        payload: Updated field-specific data.
        message: Updated free-text feedback.
        notes: Updated notes.
    """
    body: dict = {}
    for key, val in [("suggestion_type", suggestion_type), ("entity_type", entity_type), ("target_id", target_id), ("payload", payload), ("message", message), ("notes", notes)]:
        if val is not None:
            body[key] = val
    return _json_result(await _client().admin_edit_suggestion(suggestion_id, body))


@mcp.tool()
async def admin_get_suggestion_image_url(suggestion_id: str, filename: str) -> str:
    """Get presigned GET URL for a suggestion image (admin). For viewing uploaded images in moderation UI.

    Args:
        suggestion_id: UUID of the suggestion.
        filename: Image filename (e.g. "photo.png").
    """
    return _json_result(await _client().admin_get_suggestion_image_url(suggestion_id, filename))


# ===================================================================
# Profile brand tools
# ===================================================================


@mcp.tool()
async def get_my_brands() -> str:
    """List brands owned by the authenticated user."""
    return _json_result(await _client().get_my_brands())


# ===================================================================
# Brand owner tools
# ===================================================================


@mcp.tool()
async def list_brand_owners(brand_id: str) -> str:
    """List owners of a brand. Accessible by admins and brand owners.

    Args:
        brand_id: UUID of the brand.
    """
    return _json_result(await _client().list_brand_owners(brand_id))


@mcp.tool()
async def add_brand_owner(brand_id: str, user_id: str) -> str:
    """Add a user as brand owner (admin only). Idempotent.

    Args:
        brand_id: UUID of the brand.
        user_id: Cognito sub (UUID) of the user to add as owner.
    """
    return _json_result(await _client().add_brand_owner(brand_id, {"user_id": user_id}))


@mcp.tool()
async def remove_brand_owner(brand_id: str, user_id: str) -> str:
    """Remove a user's ownership of a brand (admin only). Idempotent.

    Args:
        brand_id: UUID of the brand.
        user_id: Cognito sub (UUID) of the user to remove.
    """
    return _json_result(await _client().remove_brand_owner(brand_id, user_id))


# ===================================================================
# Admin user group tools
# ===================================================================


@mcp.tool()
async def admin_list_user_groups(user_id: str) -> str:
    """List Cognito groups for a user (admin only).

    Args:
        user_id: Cognito user sub (UUID).
    """
    return _json_result(await _client().admin_list_user_groups(user_id))


@mcp.tool()
async def admin_add_user_to_group(user_id: str, group: str) -> str:
    """Add a user to a Cognito group (admin only). Idempotent.

    Args:
        user_id: Cognito user sub (UUID).
        group: Group name to add the user to. Valid values: brand_owner.
    """
    return _json_result(await _client().admin_add_user_to_group(user_id, {"group": group}))


@mcp.tool()
async def admin_remove_user_from_group(user_id: str, group_name: str) -> str:
    """Remove a user from a Cognito group (admin only). Idempotent.

    Args:
        user_id: Cognito user sub (UUID).
        group_name: Group name to remove the user from. Valid values: brand_owner.
    """
    return _json_result(await _client().admin_remove_user_from_group(user_id, group_name))


# ===================================================================
# Admin user brand tools
# ===================================================================


@mcp.tool()
async def admin_list_user_brands(user_id: str) -> str:
    """List brands owned by a user (admin only).

    Args:
        user_id: Cognito user sub (UUID).
    """
    return _json_result(await _client().admin_list_user_brands(user_id))


# ===================================================================
# Benefit tools (admin write)
# ===================================================================


@mcp.tool()
async def create_benefit(name: str, description: str, icon_url: str | None = None, top_ingredients: list[str] | None = None, related_categories: list[str] | None = None, seo_title: str | None = None, seo_description: str | None = None, content: str | None = None) -> str:
    """Create a benefit category (admin only).

    Args:
        name: Benefit category name (required).
        description: Description of the benefit (required).
        icon_url: URL of the benefit icon.
        top_ingredients: Ordered list of ingredient IDs.
        related_categories: Related benefit slugs.
        seo_title: SEO title override.
        seo_description: SEO description override.
        content: Markdown body content.
    """
    body: dict = {"name": name, "description": description}
    for key, val in [("icon_url", icon_url), ("top_ingredients", top_ingredients), ("related_categories", related_categories), ("seo_title", seo_title), ("seo_description", seo_description), ("content", content)]:
        if val is not None:
            body[key] = val
    return _json_result(await _client().create_benefit(body))


@mcp.tool()
async def update_benefit(benefit_id: str, name: str | None = None, description: str | None = None, icon_url: str | None = None, top_ingredients: list[str] | None = None, related_categories: list[str] | None = None, seo_title: str | None = None, seo_description: str | None = None, content: str | None = None) -> str:
    """Update a benefit category (admin only). Only provided fields are changed.

    Args:
        benefit_id: UUID of the benefit category.
        name: Benefit category name.
        description: Description of the benefit.
        icon_url: URL of the benefit icon.
        top_ingredients: Ordered list of ingredient IDs.
        related_categories: Related benefit slugs.
        seo_title: SEO title override.
        seo_description: SEO description override.
        content: Markdown body content.
    """
    body: dict = {}
    for key, val in [("name", name), ("description", description), ("icon_url", icon_url), ("top_ingredients", top_ingredients), ("related_categories", related_categories), ("seo_title", seo_title), ("seo_description", seo_description), ("content", content)]:
        if val is not None:
            body[key] = val
    return _json_result(await _client().update_benefit(benefit_id, body))


@mcp.tool()
async def delete_benefit(benefit_id: str) -> str:
    """Delete a benefit category (admin only).

    Args:
        benefit_id: UUID of the benefit category.
    """
    return _json_result(await _client().delete_benefit(benefit_id))


@mcp.tool()
async def rebuild_benefit_rankings() -> str:
    """Trigger immediate benefit ranking rebuild (admin only).

    Recomputes algorithmic ingredient rankings for all benefit categories.
    Rankings are based on a weighted composite of product count, evidence level,
    popularity, trend direction, and average product rating.
    Also triggered automatically daily at 03:00 UTC via CloudWatch Events.
    """
    return _json_result(await _client().rebuild_benefit_rankings())


@mcp.tool()
async def get_benefit_ranking_rebuild_status() -> str:
    """Get the status of the benefit ranking rebuild job (admin only).

    Returns the current status (running, completed, failed) and metadata
    about the last rebuild.
    """
    return _json_result(await _client().get_benefit_ranking_rebuild_status())


# ===================================================================
# Benefit tools (public read)
# ===================================================================


@mcp.tool()
async def public_list_benefits(cursor: str | None = None, limit: int | None = None) -> str:
    """List all benefit categories (public, no auth).

    Args:
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().public_list_benefits(cursor=cursor, limit=limit))


@mcp.tool()
async def public_get_benefit(slug: str) -> str:
    """Get benefit category detail by slug (public, no auth).

    Args:
        slug: Benefit category URL slug.
    """
    return _json_result(await _client().public_get_benefit(slug))


@mcp.tool()
async def public_list_benefit_ingredients(slug: str, cursor: str | None = None, limit: int | None = None) -> str:
    """List ranked ingredients for a benefit category (public, no auth).

    Args:
        slug: Benefit category URL slug.
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().public_list_benefit_ingredients(slug, cursor=cursor, limit=limit))


@mcp.tool()
async def public_list_benefit_products(slug: str, cursor: str | None = None, limit: int | None = None) -> str:
    """List top products for a benefit category (public, no auth).

    Args:
        slug: Benefit category URL slug.
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    return _json_result(await _client().public_list_benefit_products(slug, cursor=cursor, limit=limit))


# ===================================================================
# Helper tools (auto-paginating lookups)
# ===================================================================


@mcp.tool()
async def find_brand_by_name(name: str) -> str:
    """Find a brand by exact name match. Uses GSI7 for O(1) lookup when available, with auto-pagination fallback.

    Args:
        name: Exact brand name to find (case-insensitive).
    """
    client = _client()
    cursor = None
    max_pages = 50
    for page in range(max_pages):
        result = await client.public_search_brands(name=name, cursor=cursor, limit=100)
        if isinstance(result, dict) and "error" in result:
            return _json_result(result)
        items = result.get("items", [])
        for item in items:
            if item.get("name", "").lower() == name.lower():
                return _json_result(item)
        if not result.get("has_more"):
            break
        cursor = result.get("next_cursor")
    return _json_result({"error": "not_found", "message": f"Brand '{name}' not found after scanning {page + 1} pages."})


@mcp.tool()
async def find_product_by_upc(upc: str) -> str:
    """Find a product by exact UPC barcode match with auto-pagination.

    Args:
        upc: UPC barcode to search for.
    """
    client = _client()
    cursor = None
    max_pages = 50
    for page in range(max_pages):
        result = await client.public_search_products(upc=upc, cursor=cursor, limit=100)
        if isinstance(result, dict) and "error" in result:
            return _json_result(result)
        items = result.get("items", [])
        if items:
            return _json_result(items[0])
        if not result.get("has_more"):
            break
        cursor = result.get("next_cursor")
    return _json_result({"error": "not_found", "message": f"Product with UPC '{upc}' not found after scanning {page + 1} pages."})


# ===================================================================
# Exports
# ===================================================================


@mcp.tool()
async def create_export(export_type: str, filters: dict | None = None) -> str:
    """Create a data export.

    Args:
        export_type: Type of export to create.
        filters: Optional filters to apply to the export.
    """
    body: dict = {"type": export_type}
    if filters:
        body["filters"] = filters
    result = await _client().create_export(body)
    return _json_result(result)


# ===================================================================
# CDN Benefits Search Index
# ===================================================================


@mcp.tool()
async def public_get_benefits_search_index() -> str:
    """Get benefits search index from CDN (public, no auth)."""
    result = await _client().public_get_benefits_search_index()
    return _json_result(result)


# ===================================================================
# Biomarkers (Admin)
# ===================================================================


@mcp.tool()
async def create_biomarker(
    name: str,
    common_name: str,
    category: str,
    unit: str,
    optimal_range_min: float,
    optimal_range_max: float,
    deficiency_threshold: float,
    description: str,
    why_it_matters: str,
    range_source: str,
    testing_method: str,
    sample_type: str,
    insufficiency_threshold: float | None = None,
    excess_threshold: float | None = None,
    range_notes: str | None = None,
    testing_frequency: str | None = None,
    fasting_required: bool = False,
    factors_that_influence: list[str] | None = None,
    related_benefit_categories: list[str] | None = None,
    seo_title: str | None = None,
    seo_description: str | None = None,
) -> str:
    """Create a new biomarker (admin only).

    Args:
        name: Scientific biomarker name (e.g. "25-Hydroxyvitamin D").
        common_name: Common name (e.g. "Vitamin D").
        category: Category (blood_chemistry, hormonal, inflammatory, metabolic, cardiovascular, cognitive, bone, immune, gut, oxidative_stress).
        unit: Measurement unit (e.g. "ng/mL", "pg/mL").
        optimal_range_min: Lower bound of optimal range.
        optimal_range_max: Upper bound of optimal range.
        deficiency_threshold: Value below which is considered deficient.
        description: Description of the biomarker.
        why_it_matters: Explanation of health relevance.
        range_source: Source/citation for the reference ranges.
        testing_method: How this biomarker is tested (e.g. "Blood draw").
        sample_type: Sample type (e.g. "blood", "serum", "urine").
        insufficiency_threshold: Value below which is insufficient (optional).
        excess_threshold: Value above which is excessive (optional).
        range_notes: Additional notes about ranges.
        testing_frequency: Recommended testing frequency.
        fasting_required: Whether fasting is required for testing.
        factors_that_influence: Factors that can influence levels.
        related_benefit_categories: Related benefit category slugs.
        seo_title: SEO title override.
        seo_description: SEO description override.
    """
    body: dict = {
        "name": name,
        "common_name": common_name,
        "category": category,
        "unit": unit,
        "optimal_range_min": optimal_range_min,
        "optimal_range_max": optimal_range_max,
        "deficiency_threshold": deficiency_threshold,
        "description": description,
        "why_it_matters": why_it_matters,
        "range_source": range_source,
        "testing_method": testing_method,
        "sample_type": sample_type,
        "fasting_required": fasting_required,
    }
    if insufficiency_threshold is not None:
        body["insufficiency_threshold"] = insufficiency_threshold
    if excess_threshold is not None:
        body["excess_threshold"] = excess_threshold
    if range_notes is not None:
        body["range_notes"] = range_notes
    if testing_frequency is not None:
        body["testing_frequency"] = testing_frequency
    if factors_that_influence is not None:
        body["factors_that_influence"] = factors_that_influence
    if related_benefit_categories is not None:
        body["related_benefit_categories"] = related_benefit_categories
    if seo_title is not None:
        body["seo_title"] = seo_title
    if seo_description is not None:
        body["seo_description"] = seo_description
    result = await _client().create_biomarker(body)
    return _json_result(result)


@mcp.tool()
async def update_biomarker(
    biomarker_id: str,
    name: str | None = None,
    common_name: str | None = None,
    category: str | None = None,
    unit: str | None = None,
    optimal_range_min: float | None = None,
    optimal_range_max: float | None = None,
    deficiency_threshold: float | None = None,
    insufficiency_threshold: float | None = None,
    excess_threshold: float | None = None,
    range_source: str | None = None,
    range_notes: str | None = None,
    testing_method: str | None = None,
    testing_frequency: str | None = None,
    fasting_required: bool | None = None,
    sample_type: str | None = None,
    description: str | None = None,
    why_it_matters: str | None = None,
    factors_that_influence: list[str] | None = None,
    related_benefit_categories: list[str] | None = None,
    seo_title: str | None = None,
    seo_description: str | None = None,
) -> str:
    """Update a biomarker (admin only). Only provided fields are changed.

    Args:
        biomarker_id: UUID of the biomarker.
        name: Scientific biomarker name.
        common_name: Common name.
        category: Category (blood_chemistry, hormonal, inflammatory, metabolic, cardiovascular, cognitive, bone, immune, gut, oxidative_stress).
        unit: Measurement unit.
        optimal_range_min: Lower bound of optimal range.
        optimal_range_max: Upper bound of optimal range.
        deficiency_threshold: Deficiency threshold value.
        insufficiency_threshold: Insufficiency threshold value.
        excess_threshold: Excess threshold value.
        range_source: Source/citation for reference ranges.
        range_notes: Additional notes about ranges.
        testing_method: How this biomarker is tested.
        testing_frequency: Recommended testing frequency.
        fasting_required: Whether fasting is required.
        sample_type: Sample type.
        description: Description of the biomarker.
        why_it_matters: Explanation of health relevance.
        factors_that_influence: Factors that can influence levels.
        related_benefit_categories: Related benefit category slugs.
        seo_title: SEO title override.
        seo_description: SEO description override.
    """
    body: dict = {}
    if name is not None:
        body["name"] = name
    if common_name is not None:
        body["common_name"] = common_name
    if category is not None:
        body["category"] = category
    if unit is not None:
        body["unit"] = unit
    if optimal_range_min is not None:
        body["optimal_range_min"] = optimal_range_min
    if optimal_range_max is not None:
        body["optimal_range_max"] = optimal_range_max
    if deficiency_threshold is not None:
        body["deficiency_threshold"] = deficiency_threshold
    if insufficiency_threshold is not None:
        body["insufficiency_threshold"] = insufficiency_threshold
    if excess_threshold is not None:
        body["excess_threshold"] = excess_threshold
    if range_source is not None:
        body["range_source"] = range_source
    if range_notes is not None:
        body["range_notes"] = range_notes
    if testing_method is not None:
        body["testing_method"] = testing_method
    if testing_frequency is not None:
        body["testing_frequency"] = testing_frequency
    if fasting_required is not None:
        body["fasting_required"] = fasting_required
    if sample_type is not None:
        body["sample_type"] = sample_type
    if description is not None:
        body["description"] = description
    if why_it_matters is not None:
        body["why_it_matters"] = why_it_matters
    if factors_that_influence is not None:
        body["factors_that_influence"] = factors_that_influence
    if related_benefit_categories is not None:
        body["related_benefit_categories"] = related_benefit_categories
    if seo_title is not None:
        body["seo_title"] = seo_title
    if seo_description is not None:
        body["seo_description"] = seo_description
    result = await _client().update_biomarker(biomarker_id, body)
    return _json_result(result)


@mcp.tool()
async def delete_biomarker(biomarker_id: str) -> str:
    """Delete a biomarker (admin only). Blocked if evidence links reference it.

    Args:
        biomarker_id: UUID of the biomarker.
    """
    result = await _client().delete_biomarker(biomarker_id)
    return _json_result(result)


@mcp.tool()
async def bulk_create_biomarkers(items: list[dict]) -> str:
    """Bulk create up to 25 biomarkers (admin only).

    Each item requires: name, common_name, category, unit, optimal_range_min,
    optimal_range_max, deficiency_threshold, range_source, testing_method,
    sample_type, description, why_it_matters.

    Args:
        items: List of biomarker objects (max 25).
    """
    result = await _client().bulk_create_biomarkers(items)
    return _json_result(result)


# ===================================================================
# Biomarkers (Public)
# ===================================================================


@mcp.tool()
async def public_list_biomarkers(
    cursor: str | None = None,
    limit: int | None = None,
    category: str | None = None,
) -> str:
    """List biomarkers publicly (no auth). Optionally filter by category.

    Args:
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
        category: Filter by category (blood_chemistry, hormonal, inflammatory, metabolic, cardiovascular, cognitive, bone, immune, gut, oxidative_stress).
    """
    result = await _client().public_list_biomarkers(cursor=cursor, limit=limit, category=category)
    return _json_result(result)


@mcp.tool()
async def public_get_biomarker(biomarker_id: str) -> str:
    """Get biomarker detail publicly (no auth).

    Args:
        biomarker_id: UUID or slug of the biomarker.
    """
    result = await _client().public_get_biomarker(biomarker_id)
    return _json_result(result)


@mcp.tool()
async def public_list_biomarkers_by_category(
    category: str,
    cursor: str | None = None,
    limit: int | None = None,
) -> str:
    """List biomarkers by category publicly (no auth).

    Args:
        category: Biomarker category (blood_chemistry, hormonal, inflammatory, metabolic, cardiovascular, cognitive, bone, immune, gut, oxidative_stress).
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    result = await _client().public_list_biomarkers_by_category(category, cursor=cursor, limit=limit)
    return _json_result(result)


@mcp.tool()
async def public_list_biomarker_ingredients(
    slug: str,
    cursor: str | None = None,
    limit: int | None = None,
) -> str:
    """List ingredients that support a biomarker, ranked by evidence quality (public, no auth).

    Args:
        slug: Biomarker slug (e.g. "zinc-level", "vitamin-d-blood-level").
        cursor: Opaque pagination cursor.
        limit: Items per page (1-100, default 20).
    """
    result = await _client().public_list_biomarker_ingredients(slug, cursor=cursor, limit=limit)
    return _json_result(result)


# ===================================================================
# Biomarkers (Stack / Premium)
# ===================================================================


@mcp.tool()
async def stack_biomarkers_testing_plan() -> str:
    """Get recommended biomarker testing schedule based on user's supplement stack (premium)."""
    result = await _client().stack_biomarkers_testing_plan()
    return _json_result(result)


@mcp.tool()
async def stack_biomarkers_report() -> str:
    """Get full biomarker coverage report for user's supplement stack (premium)."""
    result = await _client().stack_biomarkers_report()
    return _json_result(result)


# ===================================================================
# Evidence Links (Admin)
# ===================================================================


@mcp.tool()
async def create_evidence_link(
    ingredient_id: str,
    biomarker_id: str,
    effect_direction: str,
    effect_summary: str,
    studied_dose: str,
    studied_duration: str,
    study_type: str,
    evidence_quality: str,
    population_studied: str,
    citation: dict,
    observed_change: str | None = None,
    sample_size: int | None = None,
    limitations: str | None = None,
    additional_references: list[dict] | None = None,
) -> str:
    """Create an evidence link for an ingredient (admin only).

    Args:
        ingredient_id: UUID of the ingredient.
        biomarker_id: UUID of the biomarker this evidence links to.
        effect_direction: Direction of effect (supports_increase, supports_decrease, supports_maintenance, modulates).
        effect_summary: Summary of the observed effect (DSHEA claim-word filtered).
        studied_dose: Dose used in the study (e.g. "2000 IU/day").
        studied_duration: Duration of the study (e.g. "12 weeks").
        study_type: Type of study (meta_analysis, systematic_review, rct, cohort, case_control, cross_sectional, in_vitro).
        evidence_quality: Quality rating (high, moderate, low, very_low).
        population_studied: Description of the study population.
        citation: Primary citation object with title, authors, journal, year, and optional doi/pubmed_id/url.
        observed_change: Quantified change observed (optional).
        sample_size: Number of participants (optional).
        limitations: Study limitations (optional).
        additional_references: Additional citation objects (optional).
    """
    body: dict = {
        "biomarker_id": biomarker_id,
        "effect_direction": effect_direction,
        "effect_summary": effect_summary,
        "studied_dose": studied_dose,
        "studied_duration": studied_duration,
        "study_type": study_type,
        "evidence_quality": evidence_quality,
        "population_studied": population_studied,
        "citation": citation,
    }
    if observed_change is not None:
        body["observed_change"] = observed_change
    if sample_size is not None:
        body["sample_size"] = sample_size
    if limitations is not None:
        body["limitations"] = limitations
    if additional_references is not None:
        body["additional_references"] = additional_references
    result = await _client().create_evidence_link(ingredient_id, body)
    return _json_result(result)


@mcp.tool()
async def update_evidence_link(
    evidence_id: str,
    ingredient_id: str,
    effect_direction: str | None = None,
    effect_summary: str | None = None,
    studied_dose: str | None = None,
    studied_duration: str | None = None,
    observed_change: str | None = None,
    study_type: str | None = None,
    evidence_quality: str | None = None,
    sample_size: int | None = None,
    population_studied: str | None = None,
    limitations: str | None = None,
    citation: dict | None = None,
    additional_references: list[dict] | None = None,
    dshea_reviewed: bool | None = None,
    reviewed_by: str | None = None,
) -> str:
    """Update an evidence link (admin only). Only provided fields are changed.

    Args:
        evidence_id: UUID of the evidence link.
        ingredient_id: UUID of the ingredient this evidence belongs to.
        effect_direction: Direction of effect (supports_increase, supports_decrease, supports_maintenance, modulates).
        effect_summary: Summary of the observed effect.
        studied_dose: Dose used in the study.
        studied_duration: Duration of the study.
        observed_change: Quantified change observed.
        study_type: Type of study.
        evidence_quality: Quality rating (high, moderate, low, very_low).
        sample_size: Number of participants.
        population_studied: Description of the study population.
        limitations: Study limitations.
        citation: Primary citation object.
        additional_references: Additional citation objects.
        dshea_reviewed: Whether the evidence link has been DSHEA reviewed.
        reviewed_by: Admin user who reviewed.
    """
    body: dict = {}
    if effect_direction is not None:
        body["effect_direction"] = effect_direction
    if effect_summary is not None:
        body["effect_summary"] = effect_summary
    if studied_dose is not None:
        body["studied_dose"] = studied_dose
    if studied_duration is not None:
        body["studied_duration"] = studied_duration
    if observed_change is not None:
        body["observed_change"] = observed_change
    if study_type is not None:
        body["study_type"] = study_type
    if evidence_quality is not None:
        body["evidence_quality"] = evidence_quality
    if sample_size is not None:
        body["sample_size"] = sample_size
    if population_studied is not None:
        body["population_studied"] = population_studied
    if limitations is not None:
        body["limitations"] = limitations
    if citation is not None:
        body["citation"] = citation
    if additional_references is not None:
        body["additional_references"] = additional_references
    if dshea_reviewed is not None:
        body["dshea_reviewed"] = dshea_reviewed
    if reviewed_by is not None:
        body["reviewed_by"] = reviewed_by
    result = await _client().update_evidence_link(evidence_id, ingredient_id, body)
    return _json_result(result)


@mcp.tool()
async def delete_evidence_link(evidence_id: str, ingredient_id: str) -> str:
    """Delete an evidence link (admin only).

    Args:
        evidence_id: UUID of the evidence link.
        ingredient_id: UUID of the ingredient this evidence belongs to.
    """
    result = await _client().delete_evidence_link(evidence_id, ingredient_id)
    return _json_result(result)


@mcp.tool()
async def bulk_create_evidence_links(items: list[dict]) -> str:
    """Bulk create up to 25 evidence links (admin only).

    Each item requires: ingredient_id, biomarker_id, effect_direction,
    effect_summary, studied_dose, studied_duration, study_type,
    evidence_quality, population_studied, citation.

    Args:
        items: List of evidence link objects (max 25). Each must include ingredient_id.
    """
    result = await _client().bulk_create_evidence_links(items)
    return _json_result(result)


# ===================================================================
# Evidence Links (Public)
# ===================================================================


@mcp.tool()
async def public_list_ingredient_evidence(ingredient_id: str) -> str:
    """List evidence links for an ingredient grouped by biomarker (public, reviewed only, no auth).

    Args:
        ingredient_id: UUID of the ingredient.
    """
    result = await _client().public_list_ingredient_evidence(ingredient_id)
    return _json_result(result)


@mcp.tool()
async def public_list_ingredient_biomarkers(ingredient_id: str) -> str:
    """List biomarkers affected by an ingredient (public summary, no auth).

    Args:
        ingredient_id: UUID of the ingredient.
    """
    result = await _client().public_list_ingredient_biomarkers(ingredient_id)
    return _json_result(result)


# ===================================================================
# Entry point
# ===================================================================


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
