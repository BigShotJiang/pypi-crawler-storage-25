"""Shared output helpers for CLI commands."""

import json
import sys
from typing import Any

from tabulate import tabulate


def table(rows: list[dict], headers: list[str], fmt: str = "simple") -> None:
    if not rows:
        print("(no results)")
        return
    data = [[r.get(h, "") or "" for h in headers] for r in rows]
    print(tabulate(data, headers=headers, tablefmt=fmt))


def kv(data: dict, title: str = "") -> None:
    if title:
        print(f"\n{title}")
        print("-" * len(title))
    width = max((len(k) for k in data), default=0) + 2
    for k, v in data.items():
        print(f"  {k:<{width}} {v}")


def success(msg: str) -> None:
    print(f"OK  {msg}")


def error(msg: str) -> None:
    print(f"ERR {msg}", file=sys.stderr)


def as_json(data: Any) -> None:
    print(json.dumps(data, indent=2, default=str))
