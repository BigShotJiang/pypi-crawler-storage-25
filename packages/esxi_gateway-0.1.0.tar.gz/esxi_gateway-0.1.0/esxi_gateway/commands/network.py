"""Network commands — list portgroups and virtual switches."""

import sys

import click

from esxi_gateway import session
from esxi_gateway.commands.connect import client_from_session
from esxi_gateway.output import table, as_json, error
from esxi_gateway.soap_client import ESXiClient, SoapFault

_NET_PROPS = [
    "name",
    "summary.accessible",
    "summary.ipPoolName",
]


@click.group("network")
def network_group() -> None:
    """Inspect virtual networks and portgroups."""


@network_group.command("list")
@click.option("--json", "as_json_flag", is_flag=True)
def network_list(as_json_flag: bool) -> None:
    """List all networks / portgroups."""
    client = _get_client()
    try:
        nets = client.retrieve_properties("Network", _NET_PROPS)
    except SoapFault as exc:
        error(str(exc)); sys.exit(1)

    if as_json_flag:
        as_json(nets); return

    rows = [
        {
            "Name":       n.get("name", ""),
            "Type":       n.get("_moref_type", ""),
            "Accessible": n.get("summary.accessible", ""),
            "IP Pool":    n.get("summary.ipPoolName", "") or "",
        }
        for n in nets
    ]
    table(rows, ["Name", "Type", "Accessible", "IP Pool"])


# ------------------------------------------------------------------

def _get_client() -> ESXiClient:
    try:
        data = session.require()
    except RuntimeError as exc:
        error(str(exc)); sys.exit(1)
    return client_from_session(data)
