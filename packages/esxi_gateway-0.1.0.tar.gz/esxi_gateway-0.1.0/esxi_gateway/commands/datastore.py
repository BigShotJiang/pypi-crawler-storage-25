"""Datastore commands."""

import sys

import click

from esxi_gateway import session
from esxi_gateway.commands.connect import client_from_session
from esxi_gateway.output import table, kv, as_json, error
from esxi_gateway.soap_client import ESXiClient, SoapFault

_DS_PROPS = [
    "name",
    "summary.type",
    "summary.capacity",
    "summary.freeSpace",
    "summary.accessible",
    "summary.url",
]


@click.group("datastore")
def datastore_group() -> None:
    """Manage and inspect datastores."""


@datastore_group.command("list")
@click.option("--json", "as_json_flag", is_flag=True)
def datastore_list(as_json_flag: bool) -> None:
    """List all datastores."""
    client = _get_client()
    try:
        dss = client.retrieve_properties("Datastore", _DS_PROPS)
    except SoapFault as exc:
        error(str(exc)); sys.exit(1)

    if as_json_flag:
        as_json(dss); return

    rows = [
        {
            "Name":        ds.get("name", ""),
            "Type":        ds.get("summary.type", ""),
            "Capacity GB": _gb(ds.get("summary.capacity", "0")),
            "Free GB":     _gb(ds.get("summary.freeSpace", "0")),
            "Used %":      _pct(ds.get("summary.capacity"), ds.get("summary.freeSpace")),
            "Accessible":  ds.get("summary.accessible", ""),
        }
        for ds in dss
    ]
    table(rows, ["Name", "Type", "Capacity GB", "Free GB", "Used %", "Accessible"])


@datastore_group.command("info")
@click.argument("name")
@click.option("--json", "as_json_flag", is_flag=True)
def datastore_info(name: str, as_json_flag: bool) -> None:
    """Show details for a specific datastore."""
    client = _get_client()
    try:
        dss = client.retrieve_properties("Datastore", _DS_PROPS)
    except SoapFault as exc:
        error(str(exc)); sys.exit(1)

    matched = [d for d in dss if d.get("name", "").lower() == name.lower()]
    if not matched:
        error(f"Datastore not found: '{name}'"); sys.exit(1)
    ds = matched[0]

    if as_json_flag:
        as_json(ds); return

    cap  = int(ds.get("summary.capacity",  "0") or 0)
    free = int(ds.get("summary.freeSpace", "0") or 0)
    used = cap - free

    kv(
        {
            "Name":        ds.get("name", ""),
            "MoRef":       ds.get("_moref", ""),
            "Type":        ds.get("summary.type", ""),
            "URL":         ds.get("summary.url", ""),
            "Accessible":  ds.get("summary.accessible", ""),
            "Capacity":    f"{cap / 1_073_741_824:.2f} GB",
            "Used":        f"{used / 1_073_741_824:.2f} GB",
            "Free":        f"{free / 1_073_741_824:.2f} GB",
        },
        title=f"Datastore: {name}",
    )


# ------------------------------------------------------------------

def _get_client() -> ESXiClient:
    try:
        data = session.require()
    except RuntimeError as exc:
        error(str(exc)); sys.exit(1)
    return client_from_session(data)


def _gb(val) -> str:
    try:
        return f"{int(val) / 1_073_741_824:.2f}"
    except (ValueError, TypeError):
        return ""


def _pct(cap, free) -> str:
    try:
        c, f = int(cap), int(free)
        return f"{(c - f) / c * 100:.1f}%" if c else "0%"
    except (ValueError, TypeError):
        return ""
