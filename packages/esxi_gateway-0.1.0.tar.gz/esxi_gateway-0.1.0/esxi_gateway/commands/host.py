"""Host-level information commands."""

import sys

import click

from esxi_gateway import session
from esxi_gateway.commands.connect import client_from_session
from esxi_gateway.output import kv, table, as_json, error
from esxi_gateway.soap_client import ESXiClient, SoapFault

_HOST_PROPS = [
    "name",
    "runtime.powerState",
    "runtime.connectionState",
    "runtime.inMaintenanceMode",
    "summary.hardware.cpuMhz",
    "summary.hardware.numCpuCores",
    "summary.hardware.numCpuPkgs",
    "summary.hardware.memorySize",
    "summary.hardware.model",
    "summary.hardware.vendor",
    "summary.config.name",
    "summary.config.product.version",
    "summary.config.product.build",
    "summary.quickStats.overallCpuUsage",
    "summary.quickStats.overallMemoryUsage",
]


@click.group("host")
def host_group() -> None:
    """Show host information and status."""


@host_group.command("list")
@click.option("--json", "as_json_flag", is_flag=True)
def host_list(as_json_flag: bool) -> None:
    """List all hosts."""
    client = _get_client()
    try:
        hosts = client.retrieve_properties("HostSystem", _HOST_PROPS)
    except SoapFault as exc:
        error(str(exc)); sys.exit(1)

    if as_json_flag:
        as_json(hosts); return

    rows = [
        {
            "Name":       h.get("name", ""),
            "State":      h.get("runtime.connectionState", ""),
            "Power":      h.get("runtime.powerState", ""),
            "Maint.":     "yes" if h.get("runtime.inMaintenanceMode") == "true" else "no",
            "CPU cores":  h.get("summary.hardware.numCpuCores", ""),
            "Memory GB":  _mem_gb(h.get("summary.hardware.memorySize", "0")),
            "Model":      h.get("summary.hardware.model", ""),
        }
        for h in hosts
    ]
    table(rows, ["Name", "State", "Power", "Maint.", "CPU cores", "Memory GB", "Model"])


@host_group.command("info")
@click.argument("name", required=False)
@click.option("--json", "as_json_flag", is_flag=True)
def host_info(name: str, as_json_flag: bool) -> None:
    """Show detailed information for a host (first host if name omitted)."""
    client = _get_client()
    try:
        hosts = client.retrieve_properties("HostSystem", _HOST_PROPS)
    except SoapFault as exc:
        error(str(exc)); sys.exit(1)

    if not hosts:
        error("No hosts found."); sys.exit(1)

    if name:
        matched = [h for h in hosts if h.get("name", "").lower() == name.lower()]
        if not matched:
            error(f"Host not found: '{name}'"); sys.exit(1)
        host = matched[0]
    else:
        host = hosts[0]

    if as_json_flag:
        as_json(host); return

    mem_bytes = int(host.get("summary.hardware.memorySize", 0) or 0)
    mem_used  = int(host.get("summary.quickStats.overallMemoryUsage", 0) or 0)
    cpu_mhz   = int(host.get("summary.hardware.cpuMhz", 0) or 0)
    cpu_used  = int(host.get("summary.quickStats.overallCpuUsage", 0) or 0)
    cores     = int(host.get("summary.hardware.numCpuCores", 1) or 1)
    total_mhz = cpu_mhz * cores

    kv(
        {
            "Name":            host.get("name", ""),
            "MoRef":           host.get("_moref", ""),
            "Vendor":          host.get("summary.hardware.vendor", ""),
            "Model":           host.get("summary.hardware.model", ""),
            "ESXi version":    host.get("summary.config.product.version", ""),
            "Build":           host.get("summary.config.product.build", ""),
            "Connection":      host.get("runtime.connectionState", ""),
            "Power":           host.get("runtime.powerState", ""),
            "Maintenance":     host.get("runtime.inMaintenanceMode", ""),
            "CPU sockets":     host.get("summary.hardware.numCpuPkgs", ""),
            "CPU cores":       str(cores),
            "CPU MHz (each)":  str(cpu_mhz),
            "CPU usage":       f"{cpu_used} MHz / {total_mhz} MHz",
            "Memory total":    f"{mem_bytes / 1_073_741_824:.1f} GB",
            "Memory usage":    f"{mem_used} MB",
        },
        title=f"Host: {host.get('name', '')}",
    )


# ------------------------------------------------------------------

def _get_client() -> ESXiClient:
    try:
        data = session.require()
    except RuntimeError as exc:
        error(str(exc)); sys.exit(1)
    return client_from_session(data)


def _mem_gb(val: str) -> str:
    try:
        return f"{int(val) / 1_073_741_824:.1f}"
    except (ValueError, TypeError):
        return ""
