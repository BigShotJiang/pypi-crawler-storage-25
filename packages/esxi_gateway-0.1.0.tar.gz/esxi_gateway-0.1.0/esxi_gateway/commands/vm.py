"""Virtual machine commands: list, info, power, snapshot."""

import sys
from typing import Optional

import click

from esxi_gateway import session
from esxi_gateway.commands.connect import client_from_session
from esxi_gateway.output import table, kv, success, error, as_json
from esxi_gateway.soap_client import ESXiClient, SoapFault

# Properties fetched for every VM in list/lookup operations
_VM_PROPS = [
    "name",
    "runtime.powerState",
    "config.guestFullName",
    "config.numCpu",
    "config.memorySizeMB",
    "summary.storage.committed",
    "guest.ipAddress",
    "snapshot",
]


@click.group("vm")
def vm_group() -> None:
    """Manage virtual machines."""


# ------------------------------------------------------------------
# vm list
# ------------------------------------------------------------------

@vm_group.command("list")
@click.option("--json", "as_json_flag", is_flag=True, help="Output as JSON")
def vm_list(as_json_flag: bool) -> None:
    """List all virtual machines."""
    client, _ = _get_client()
    try:
        vms = client.retrieve_properties("VirtualMachine", _VM_PROPS)
    except SoapFault as exc:
        error(str(exc)); sys.exit(1)

    if as_json_flag:
        as_json(vms); return

    rows = [
        {
            "Name":       v.get("name", ""),
            "Power":      _short_power(v.get("runtime.powerState", "")),
            "Guest OS":   _truncate(v.get("config.guestFullName", ""), 28),
            "CPUs":       v.get("config.numCpu", ""),
            "Memory MB":  v.get("config.memorySizeMB", ""),
            "IP":         v.get("guest.ipAddress", ""),
        }
        for v in vms
    ]
    table(rows, ["Name", "Power", "Guest OS", "CPUs", "Memory MB", "IP"])


# ------------------------------------------------------------------
# vm info
# ------------------------------------------------------------------

@vm_group.command("info")
@click.argument("name")
@click.option("--json", "as_json_flag", is_flag=True, help="Output as JSON")
def vm_info(name: str, as_json_flag: bool) -> None:
    """Show detailed information about a VM."""
    client, _ = _get_client()
    vm = _find_vm(client, name)

    if as_json_flag:
        as_json(vm); return

    storage_bytes = vm.get("summary.storage.committed") or "0"
    try:
        storage_gb = f"{int(storage_bytes) / 1_073_741_824:.1f} GB"
    except ValueError:
        storage_gb = storage_bytes

    kv(
        {
            "Name":       vm.get("name", ""),
            "MoRef":      vm.get("_moref", ""),
            "Power":      vm.get("runtime.powerState", ""),
            "Guest OS":   vm.get("config.guestFullName", ""),
            "CPUs":       vm.get("config.numCpu", ""),
            "Memory MB":  vm.get("config.memorySizeMB", ""),
            "Storage":    storage_gb,
            "IP":         vm.get("guest.ipAddress", "") or "(not available)",
            "Snapshots":  "(use: esxi vm snapshot list <name>)",
        },
        title=f"VM: {name}",
    )


# ------------------------------------------------------------------
# vm power commands
# ------------------------------------------------------------------

@vm_group.command("start")
@click.argument("name")
@click.option("--wait/--no-wait", default=True, show_default=True, help="Wait for task to complete")
def vm_start(name: str, wait: bool) -> None:
    """Power on a VM."""
    _power_action("start", name, wait)


@vm_group.command("stop")
@click.argument("name")
@click.option("--force", is_flag=True, help="Hard power-off (skip guest shutdown)")
@click.option("--wait/--no-wait", default=True, show_default=True)
def vm_stop(name: str, force: bool, wait: bool) -> None:
    """Power off a VM (graceful guest shutdown by default)."""
    client, _ = _get_client()
    vm = _find_vm(client, name)
    moref = vm["_moref"]

    try:
        if force:
            task = client.power_off_vm(moref)
            if wait:
                _wait(client, task, f"Powering off {name}")
            else:
                success(f"Task submitted: {task}")
        else:
            client.shutdown_guest(moref)
            success(f"Sent shutdown signal to guest '{name}'")
    except SoapFault as exc:
        error(str(exc)); sys.exit(1)


@vm_group.command("suspend")
@click.argument("name")
@click.option("--wait/--no-wait", default=True, show_default=True)
def vm_suspend(name: str, wait: bool) -> None:
    """Suspend a VM."""
    _power_action("suspend", name, wait)


@vm_group.command("reset")
@click.argument("name")
@click.option("--wait/--no-wait", default=True, show_default=True)
def vm_reset(name: str, wait: bool) -> None:
    """Reset (hard reboot) a VM."""
    _power_action("reset", name, wait)


@vm_group.command("reboot")
@click.argument("name")
def vm_reboot(name: str) -> None:
    """Send a graceful reboot signal to the guest OS."""
    client, _ = _get_client()
    vm = _find_vm(client, name)
    try:
        client.reboot_guest(vm["_moref"])
        success(f"Sent reboot signal to guest '{name}'")
    except SoapFault as exc:
        error(str(exc)); sys.exit(1)


# ------------------------------------------------------------------
# vm snapshot subgroup
# ------------------------------------------------------------------

@vm_group.group("snapshot")
def snapshot_group() -> None:
    """Manage VM snapshots."""


@snapshot_group.command("list")
@click.argument("name")
@click.option("--json", "as_json_flag", is_flag=True)
def snapshot_list(name: str, as_json_flag: bool) -> None:
    """List snapshots for a VM."""
    client, _ = _get_client()
    vm = _find_vm(client, name, props=["name", "snapshot"])

    snap_el = vm.get("snapshot")
    if not snap_el:
        click.echo(f"No snapshots for VM '{name}'.")
        return

    # snapshot property returns nested XML — re-query with full prop path
    from esxi_gateway.soap_client import _child_text
    import xml.etree.ElementTree as ET

    rows = _parse_snapshot_tree(vm)
    if as_json_flag:
        as_json(rows); return

    table(rows, ["Name", "Description", "MoRef"])


@snapshot_group.command("create")
@click.argument("name")
@click.argument("snapshot_name")
@click.option("--description", "-d", default="", help="Snapshot description")
@click.option("--memory",  is_flag=True, help="Include memory state")
@click.option("--quiesce", is_flag=True, help="Quiesce guest filesystem (requires VMware Tools)")
@click.option("--wait/--no-wait", default=True, show_default=True)
def snapshot_create(
    name: str, snapshot_name: str, description: str, memory: bool, quiesce: bool, wait: bool
) -> None:
    """Create a snapshot of a VM."""
    client, _ = _get_client()
    vm = _find_vm(client, name)
    try:
        task = client.create_snapshot(vm["_moref"], snapshot_name, description, memory, quiesce)
        if wait:
            _wait(client, task, f"Creating snapshot '{snapshot_name}' on '{name}'")
        else:
            success(f"Task submitted: {task}")
    except SoapFault as exc:
        error(str(exc)); sys.exit(1)


@snapshot_group.command("revert")
@click.argument("snapshot_moref", metavar="SNAPSHOT_MOREF")
@click.option("--wait/--no-wait", default=True, show_default=True)
def snapshot_revert(snapshot_moref: str, wait: bool) -> None:
    """Revert to a snapshot by its MoRef (use 'vm snapshot list' to get it)."""
    client, _ = _get_client()
    try:
        task = client.revert_to_snapshot(snapshot_moref)
        if wait:
            _wait(client, task, f"Reverting to snapshot {snapshot_moref}")
        else:
            success(f"Task submitted: {task}")
    except SoapFault as exc:
        error(str(exc)); sys.exit(1)


@snapshot_group.command("remove")
@click.argument("snapshot_moref", metavar="SNAPSHOT_MOREF")
@click.option("--children", is_flag=True, help="Also remove child snapshots")
@click.option("--wait/--no-wait", default=True, show_default=True)
def snapshot_remove(snapshot_moref: str, children: bool, wait: bool) -> None:
    """Remove a snapshot by its MoRef."""
    client, _ = _get_client()
    try:
        task = client.remove_snapshot(snapshot_moref, remove_children=children)
        if wait:
            _wait(client, task, f"Removing snapshot {snapshot_moref}")
        else:
            success(f"Task submitted: {task}")
    except SoapFault as exc:
        error(str(exc)); sys.exit(1)


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _get_client() -> tuple[ESXiClient, dict]:
    try:
        data = session.require()
    except RuntimeError as exc:
        error(str(exc)); sys.exit(1)
    return client_from_session(data), data


def _find_vm(
    client: ESXiClient, name: str, props: Optional[list] = None
) -> dict:
    props = props or _VM_PROPS
    vms = client.retrieve_properties("VirtualMachine", props)
    for vm in vms:
        if vm.get("name", "").lower() == name.lower():
            return vm
    error(f"VM not found: '{name}'")
    sys.exit(1)


def _power_action(action: str, name: str, wait: bool) -> None:
    client, _ = _get_client()
    vm = _find_vm(client, name)
    moref = vm["_moref"]

    ops = {
        "start":   (client.power_on_vm,  f"Powering on {name}"),
        "suspend": (client.suspend_vm,   f"Suspending {name}"),
        "reset":   (client.reset_vm,     f"Resetting {name}"),
    }
    fn, label = ops[action]
    try:
        task = fn(moref)
        if wait:
            _wait(client, task, label)
        else:
            success(f"Task submitted: {task}")
    except SoapFault as exc:
        error(str(exc)); sys.exit(1)


def _wait(client: ESXiClient, task_moref: str, label: str) -> None:
    click.echo(f"{label} ...", nl=False)
    result = client.wait_for_task(task_moref)
    if result["state"] == "success":
        click.echo(" done.")
    else:
        click.echo(" FAILED.")
        error(f"Task {task_moref} ended with state: {result['state']}")
        sys.exit(1)


def _short_power(state: str) -> str:
    return {"poweredOn": "ON", "poweredOff": "OFF", "suspended": "SUSP"}.get(state, state)


def _truncate(text: str, n: int) -> str:
    return text if len(text) <= n else text[: n - 1] + "…"


def _parse_snapshot_tree(vm: dict) -> list[dict]:
    # snapshot value from retrieve_properties is a text blob; we display
    # what we can — a proper tree requires a dedicated propSet path
    return [
        {"Name": "(use MoRef from ESXi UI or API)", "Description": "", "MoRef": ""}
    ]
