"""connect / disconnect / status commands."""

import getpass
import sys

import click

from esxi_gateway import session
from esxi_gateway.output import kv, success, error
from esxi_gateway.soap_client import ESXiClient, SoapFault


@click.command("connect")
@click.option("--host",       required=True,  help="ESXi / vCenter hostname or IP")
@click.option("--user",       required=True,  help="Username (e.g. root)")
@click.option("--password",   default=None,   help="Password (prompted if omitted)")
@click.option("--no-verify",  is_flag=True,   help="Disable SSL certificate verification")
@click.option("--timeout",    default=30,     show_default=True, help="Request timeout in seconds")
def connect(host: str, user: str, password: str, no_verify: bool, timeout: int) -> None:
    """Authenticate to an ESXi host or vCenter and save the session."""
    if password is None:
        password = getpass.getpass(f"Password for {user}@{host}: ")

    verify_ssl = not no_verify
    client = ESXiClient(host, verify_ssl=verify_ssl, timeout=timeout)

    try:
        about = client.get_service_content()["about"]
        client.login(user, password)
    except SoapFault as exc:
        error(str(exc))
        sys.exit(1)
    except Exception as exc:
        error(f"Connection failed: {exc}")
        sys.exit(1)

    session.save(
        host=host,
        username=user,
        password=password,
        session_cookie=client._session_cookie,
        verify_ssl=verify_ssl,
        about=about,
    )

    success(f"Connected to {host}")
    kv(
        {
            "Product":     about.get("name", ""),
            "Version":     about.get("version", ""),
            "Build":       about.get("build", ""),
            "API version": about.get("apiVersion", ""),
        },
        title="Server info",
    )


@click.command("disconnect")
def disconnect() -> None:
    """Log out from the current ESXi session."""
    data = session.load()
    if data is None:
        click.echo("No active session.")
        return

    client = _client_from_session(data)
    try:
        client.logout()
    except Exception:
        pass  # logout best-effort

    session.clear()
    success(f"Disconnected from {data['host']}")


@click.command("status")
def status() -> None:
    """Show the current connection status."""
    data = session.load()
    if data is None:
        click.echo("Not connected.")
        return

    kv(
        {
            "Host":    data["host"],
            "User":    data["username"],
            "Product": data.get("about", {}).get("name", ""),
            "Version": data.get("about", {}).get("version", ""),
        },
        title="Session",
    )


# ------------------------------------------------------------------
# Shared factory used by command modules
# ------------------------------------------------------------------

def _client_from_session(data: dict) -> ESXiClient:
    client = ESXiClient(data["host"], verify_ssl=data.get("verify_ssl", False))
    client._session_cookie = data.get("session_cookie")
    return client


def client_from_session(data: dict) -> ESXiClient:
    return _client_from_session(data)
