"""
Persistent session store — saves host, credentials, and session cookie
to ~/.esxi-gateway/session.json so the CLI is stateless between invocations.
"""

import json
import os
import stat
from pathlib import Path
from typing import Optional

_CONFIG_DIR  = Path.home() / ".esxi-gateway"
_SESSION_FILE = _CONFIG_DIR / "session.json"


def _ensure_dir() -> None:
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    # Restrict to owner only (contains credentials)
    _CONFIG_DIR.chmod(stat.S_IRWXU)


def save(
    host: str,
    username: str,
    password: str,
    session_cookie: Optional[str],
    verify_ssl: bool,
    about: dict,
) -> None:
    _ensure_dir()
    data = {
        "host":           host,
        "username":       username,
        "password":       password,
        "session_cookie": session_cookie,
        "verify_ssl":     verify_ssl,
        "about":          about,
    }
    _SESSION_FILE.write_text(json.dumps(data, indent=2))
    _SESSION_FILE.chmod(stat.S_IRUSR | stat.S_IWUSR)


def load() -> Optional[dict]:
    if not _SESSION_FILE.exists():
        return None
    try:
        return json.loads(_SESSION_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def clear() -> None:
    if _SESSION_FILE.exists():
        _SESSION_FILE.unlink()


def require() -> dict:
    """Load session or raise a friendly error."""
    data = load()
    if data is None:
        raise RuntimeError(
            "Not connected. Run:  esxi connect --host <host> --user <user>"
        )
    return data
