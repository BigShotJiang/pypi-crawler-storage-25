"""
esxi — CLI gateway to the VMware ESXi / vSphere SOAP API.

Usage:
  esxi connect --host <host> --user <user>
  esxi vm list
  esxi vm info <name>
  esxi vm start|stop|suspend|reset|reboot <name>
  esxi vm snapshot list|create|revert|remove ...
  esxi host list
  esxi host info [<name>]
  esxi datastore list
  esxi datastore info <name>
  esxi network list
  esxi status
  esxi disconnect
"""

import click

from esxi_gateway.commands.connect import connect, disconnect, status
from esxi_gateway.commands.vm import vm_group
from esxi_gateway.commands.host import host_group
from esxi_gateway.commands.datastore import datastore_group
from esxi_gateway.commands.network import network_group


@click.group()
@click.version_option(package_name="esxi-gateway")
def cli() -> None:
    """ESXi SOAP-to-CLI gateway — manage VMware ESXi from the command line."""


cli.add_command(connect)
cli.add_command(disconnect)
cli.add_command(status)
cli.add_command(vm_group)
cli.add_command(host_group)
cli.add_command(datastore_group)
cli.add_command(network_group)
