"""
Low-level SOAP client for the VMware vSphere / ESXi SDK endpoint.

All communication uses the vSphere SOAP API (https://<host>/sdk).
We build raw XML rather than relying on a WSDL parser so the tool
has zero heavy dependencies beyond `requests`.
"""

import re
import xml.etree.ElementTree as ET
from typing import Any, Optional
from urllib.parse import urljoin

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# XML namespaces used by vSphere SOAP
NS = {
    "soapenv": "http://schemas.xmlsoap.org/soap/envelope/",
    "vim25":   "urn:vim25",
    "xsi":     "http://www.w3.org/2001/XMLSchema-instance",
}

_SOAP_ENVELOPE = """\
<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:vim25="urn:vim25"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <soapenv:Body>
{body}
  </soapenv:Body>
</soapenv:Envelope>"""


class SoapFault(Exception):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(f"[{code}] {message}")


class ESXiClient:
    """Thin SOAP client for a single ESXi host or vCenter."""

    def __init__(self, host: str, verify_ssl: bool = False, timeout: int = 30):
        self.host = host.rstrip("/")
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.session = requests.Session()
        self.session.verify = verify_ssl
        self.sdk_url = f"https://{self.host}/sdk"
        self._session_cookie: Optional[str] = None
        self._service_content: Optional[dict] = None

    # ------------------------------------------------------------------
    # Low-level SOAP plumbing
    # ------------------------------------------------------------------

    def _build_envelope(self, body_xml: str) -> str:
        return _SOAP_ENVELOPE.format(body=body_xml)

    def _post(self, body_xml: str) -> ET.Element:
        envelope = self._build_envelope(body_xml)
        headers = {
            "Content-Type": "text/xml; charset=utf-8",
            "SOAPAction": '""',
        }
        if self._session_cookie:
            headers["Cookie"] = self._session_cookie

        resp = self.session.post(
            self.sdk_url,
            data=envelope.encode("utf-8"),
            headers=headers,
            timeout=self.timeout,
        )

        # Persist session cookie returned by ESXi (vmware_soap_session)
        if "Set-Cookie" in resp.headers:
            self._session_cookie = resp.headers["Set-Cookie"].split(";")[0]

        root = ET.fromstring(resp.text)
        self._raise_if_fault(root)
        return root

    def _raise_if_fault(self, root: ET.Element) -> None:
        fault = root.find(".//{http://schemas.xmlsoap.org/soap/envelope/}Fault")
        if fault is None:
            return
        code_el = fault.find("faultcode")
        msg_el  = fault.find("faultstring")
        code    = code_el.text if code_el is not None else "Unknown"
        message = msg_el.text  if msg_el  is not None else "Unknown error"
        raise SoapFault(code, message)

    # ------------------------------------------------------------------
    # Service content (root reference object)
    # ------------------------------------------------------------------

    def get_service_content(self) -> dict:
        if self._service_content:
            return self._service_content

        body = """\
    <vim25:RetrieveServiceContent>
      <vim25:_this type="ServiceInstance">ServiceInstance</vim25:_this>
    </vim25:RetrieveServiceContent>"""

        root = self._post(body)
        sc = root.find(".//{urn:vim25}returnval")
        if sc is None:
            raise SoapFault("ParseError", "Could not find returnval in RetrieveServiceContent")

        def _text(tag: str) -> Optional[str]:
            el = sc.find(f"{{urn:vim25}}{tag}")
            return el.text if el is not None else None

        self._service_content = {
            "rootFolder":        _mo(sc, "rootFolder"),
            "propertyCollector": _mo(sc, "propertyCollector"),
            "viewManager":       _mo(sc, "viewManager"),
            "sessionManager":    _mo(sc, "sessionManager"),
            "about":             _parse_about(sc),
        }
        return self._service_content

    # ------------------------------------------------------------------
    # Authentication
    # ------------------------------------------------------------------

    def login(self, username: str, password: str) -> dict:
        sc = self.get_service_content()
        sm_val, sm_type = sc["sessionManager"]

        body = f"""\
    <vim25:Login>
      <vim25:_this type="{sm_type}">{sm_val}</vim25:_this>
      <vim25:userName>{_xml_escape(username)}</vim25:userName>
      <vim25:password>{_xml_escape(password)}</vim25:password>
    </vim25:Login>"""

        root = self._post(body)
        rv = root.find(".//{urn:vim25}returnval")
        session_info = {
            "key":      _child_text(rv, "key"),
            "userName": _child_text(rv, "userName"),
            "fullName": _child_text(rv, "fullName"),
        }
        return session_info

    def logout(self) -> None:
        sc = self.get_service_content()
        sm_val, sm_type = sc["sessionManager"]

        body = f"""\
    <vim25:Logout>
      <vim25:_this type="{sm_type}">{sm_val}</vim25:_this>
    </vim25:Logout>"""

        self._post(body)
        self._session_cookie = None

    # ------------------------------------------------------------------
    # Property collector — the universal vSphere query mechanism
    # ------------------------------------------------------------------

    def retrieve_properties(
        self,
        obj_type: str,
        properties: list[str],
        container_val: Optional[str] = None,
        container_type: str = "Folder",
    ) -> list[dict]:
        """
        Retrieve `properties` for all objects of `obj_type` reachable
        from `container_val` (defaults to the root folder).
        Returns a list of dicts keyed by property name plus '_moref'.
        """
        sc = self.get_service_content()
        pc_val, pc_type = sc["propertyCollector"]
        if container_val is None:
            container_val, container_type = sc["rootFolder"]

        prop_specs = "\n".join(
            f"          <vim25:pathSet>{p}</vim25:pathSet>" for p in properties
        )

        body = f"""\
    <vim25:RetrieveProperties>
      <vim25:_this type="{pc_type}">{pc_val}</vim25:_this>
      <vim25:specSet>
        <vim25:propSet>
          <vim25:type>{obj_type}</vim25:type>
{prop_specs}
        </vim25:propSet>
        <vim25:objectSet>
          <vim25:obj type="{container_type}">{container_val}</vim25:obj>
          <vim25:skip>false</vim25:skip>
          <vim25:selectSet xsi:type="vim25:TraversalSpec">
            <vim25:name>traverseAll</vim25:name>
            <vim25:type>{container_type}</vim25:type>
            <vim25:path>childEntity</vim25:path>
            <vim25:skip>false</vim25:skip>
            <vim25:selectSet>
              <vim25:name>traverseAll</vim25:name>
            </vim25:selectSet>
          </vim25:selectSet>
        </vim25:objectSet>
      </vim25:specSet>
    </vim25:RetrieveProperties>"""

        root = self._post(body)
        results = []
        for obj_content in root.findall(".//{urn:vim25}returnval"):
            obj_el = obj_content.find("{urn:vim25}obj")
            moref = obj_el.text if obj_el is not None else None
            moref_type = obj_el.get("type") if obj_el is not None else None

            record: dict[str, Any] = {"_moref": moref, "_moref_type": moref_type}
            for prop_el in obj_content.findall("{urn:vim25}propSet"):
                name  = _child_text(prop_el, "name")
                val   = _child_text(prop_el, "val")
                if val is None:
                    # Complex value — grab first text leaf
                    val_el = prop_el.find("{urn:vim25}val")
                    val = _deep_text(val_el) if val_el is not None else None
                record[name] = val
            results.append(record)
        return results

    # ------------------------------------------------------------------
    # Power operations
    # ------------------------------------------------------------------

    def power_on_vm(self, vm_moref: str) -> str:
        return self._invoke_task("PowerOnVM_Task", vm_moref, "VirtualMachine")

    def power_off_vm(self, vm_moref: str) -> str:
        return self._invoke_task("PowerOffVM_Task", vm_moref, "VirtualMachine")

    def suspend_vm(self, vm_moref: str) -> str:
        return self._invoke_task("SuspendVM_Task", vm_moref, "VirtualMachine")

    def reset_vm(self, vm_moref: str) -> str:
        return self._invoke_task("ResetVM_Task", vm_moref, "VirtualMachine")

    def shutdown_guest(self, vm_moref: str) -> None:
        body = f"""\
    <vim25:ShutdownGuest>
      <vim25:_this type="VirtualMachine">{vm_moref}</vim25:_this>
    </vim25:ShutdownGuest>"""
        self._post(body)

    def reboot_guest(self, vm_moref: str) -> None:
        body = f"""\
    <vim25:RebootGuest>
      <vim25:_this type="VirtualMachine">{vm_moref}</vim25:_this>
    </vim25:RebootGuest>"""
        self._post(body)

    # ------------------------------------------------------------------
    # Snapshots
    # ------------------------------------------------------------------

    def create_snapshot(
        self,
        vm_moref: str,
        name: str,
        description: str = "",
        memory: bool = False,
        quiesce: bool = False,
    ) -> str:
        body = f"""\
    <vim25:CreateSnapshot_Task>
      <vim25:_this type="VirtualMachine">{vm_moref}</vim25:_this>
      <vim25:name>{_xml_escape(name)}</vim25:name>
      <vim25:description>{_xml_escape(description)}</vim25:description>
      <vim25:memory>{"true" if memory else "false"}</vim25:memory>
      <vim25:quiesce>{"true" if quiesce else "false"}</vim25:quiesce>
    </vim25:CreateSnapshot_Task>"""

        root = self._post(body)
        rv = root.find(".//{urn:vim25}returnval")
        return rv.text if rv is not None else ""

    def revert_to_snapshot(self, snapshot_moref: str) -> str:
        return self._invoke_task("RevertToSnapshot_Task", snapshot_moref, "VirtualMachineSnapshot")

    def remove_snapshot(self, snapshot_moref: str, remove_children: bool = False) -> str:
        body = f"""\
    <vim25:RemoveSnapshot_Task>
      <vim25:_this type="VirtualMachineSnapshot">{snapshot_moref}</vim25:_this>
      <vim25:removeChildren>{"true" if remove_children else "false"}</vim25:removeChildren>
    </vim25:RemoveSnapshot_Task>"""

        root = self._post(body)
        rv = root.find(".//{urn:vim25}returnval")
        return rv.text if rv is not None else ""

    # ------------------------------------------------------------------
    # Task polling
    # ------------------------------------------------------------------

    def wait_for_task(self, task_moref: str, poll_interval: float = 2.0) -> dict:
        import time
        while True:
            results = self.retrieve_properties(
                "Task",
                ["info.state", "info.progress", "info.error", "info.result"],
                container_val=task_moref,
                container_type="Task",
            )
            # Fallback: direct property retrieve for Task object
            state = self._get_task_state(task_moref)
            if state in ("success", "error"):
                return {"state": state, "moref": task_moref}
            time.sleep(poll_interval)

    def _get_task_state(self, task_moref: str) -> str:
        sc = self.get_service_content()
        pc_val, pc_type = sc["propertyCollector"]

        body = f"""\
    <vim25:RetrieveProperties>
      <vim25:_this type="{pc_type}">{pc_val}</vim25:_this>
      <vim25:specSet>
        <vim25:propSet>
          <vim25:type>Task</vim25:type>
          <vim25:pathSet>info.state</vim25:pathSet>
        </vim25:propSet>
        <vim25:objectSet>
          <vim25:obj type="Task">{task_moref}</vim25:obj>
          <vim25:skip>false</vim25:skip>
        </vim25:objectSet>
      </vim25:specSet>
    </vim25:RetrieveProperties>"""

        root = self._post(body)
        for prop_el in root.findall(".//{urn:vim25}propSet"):
            name = _child_text(prop_el, "name")
            if name == "info.state":
                return _child_text(prop_el, "val") or "queued"
        return "queued"

    # ------------------------------------------------------------------
    # Host-level helpers
    # ------------------------------------------------------------------

    def retrieve_host_config(self, host_moref: str, path: str) -> Optional[str]:
        sc = self.get_service_content()
        pc_val, pc_type = sc["propertyCollector"]

        body = f"""\
    <vim25:RetrieveProperties>
      <vim25:_this type="{pc_type}">{pc_val}</vim25:_this>
      <vim25:specSet>
        <vim25:propSet>
          <vim25:type>HostSystem</vim25:type>
          <vim25:pathSet>{path}</vim25:pathSet>
        </vim25:propSet>
        <vim25:objectSet>
          <vim25:obj type="HostSystem">{host_moref}</vim25:obj>
          <vim25:skip>false</vim25:skip>
        </vim25:objectSet>
      </vim25:specSet>
    </vim25:RetrieveProperties>"""

        root = self._post(body)
        for prop_el in root.findall(".//{urn:vim25}propSet"):
            name = _child_text(prop_el, "name")
            if name == path:
                return _child_text(prop_el, "val")
        return None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _invoke_task(self, method: str, moref_val: str, moref_type: str) -> str:
        body = f"""\
    <vim25:{method}>
      <vim25:_this type="{moref_type}">{moref_val}</vim25:_this>
    </vim25:{method}>"""

        root = self._post(body)
        rv = root.find(".//{urn:vim25}returnval")
        return rv.text if rv is not None else ""


# ------------------------------------------------------------------
# XML helpers
# ------------------------------------------------------------------

def _mo(parent: ET.Element, tag: str) -> tuple[str, str]:
    """Return (value, type) for a ManagedObjectReference child element."""
    el = parent.find(f"{{urn:vim25}}{tag}")
    if el is None:
        return ("", "")
    return (el.text or "", el.get("type", ""))


def _child_text(parent: Optional[ET.Element], tag: str) -> Optional[str]:
    if parent is None:
        return None
    el = parent.find(f"{{urn:vim25}}{tag}")
    if el is None:
        el = parent.find(tag)
    return el.text if el is not None else None


def _deep_text(el: Optional[ET.Element]) -> Optional[str]:
    """Return concatenated text from all descendant text nodes."""
    if el is None:
        return None
    parts = [t for t in el.itertext() if t and t.strip()]
    return " ".join(parts) if parts else el.text


def _parse_about(sc: ET.Element) -> dict:
    about = sc.find("{urn:vim25}about")
    if about is None:
        return {}
    return {
        "name":        _child_text(about, "name"),
        "version":     _child_text(about, "version"),
        "build":       _child_text(about, "build"),
        "apiVersion":  _child_text(about, "apiVersion"),
        "productLine": _child_text(about, "productLine"),
    }


def _xml_escape(text: str) -> str:
    return (
        text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("'", "&apos;")
    )
