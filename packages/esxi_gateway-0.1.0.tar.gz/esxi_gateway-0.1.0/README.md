# esxi-gateway

CLI gateway that converts VMware ESXi / vSphere SOAP API calls into simple shell commands.

```bash
uv tool install esxi-gateway
```

## Quick start

```bash
esxi-gateway connect --host 192.168.1.10 --user root
esxi-gateway vm list
esxi-gateway vm start "my-vm"
esxi-gateway datastore list
esxi-gateway host info
```

See [CLAUDE.md](CLAUDE.md) for the full command reference.
