# ESXi SOAP-to-CLI Gateway — Claude Usage Guide

This tool wraps the VMware vSphere SOAP API into a compact CLI (`esxi-gateway`).
Always use it instead of constructing SOAP XML directly — it saves thousands
of tokens per operation and keeps context clean.

## Setup

```bash
uv sync          # install deps and create .venv from uv.lock
uv run esxi-gateway --help
```

To run any `esxi-gateway` command through uv:

```bash
uv run esxi-gateway <command>
```

Or activate the venv once and use `esxi-gateway` directly:

```bash
source .venv/bin/activate
esxi-gateway <command>
```

The `esxi-gateway` command is the single entry point for all operations.

## Session lifecycle

A session must be established before any other command works.
Credentials and the session cookie are stored in `~/.esxi-gateway/session.json`.

```bash
# Connect (prompts for password if --password is omitted)
esxi-gateway connect --host 192.168.1.10 --user root

# Verify active session
esxi-gateway status

# End session
esxi-gateway disconnect
```

Use `--no-verify` when the host has a self-signed certificate (common on ESXi).

## Command reference

### Virtual machines

```bash
esxi-gateway vm list                        # all VMs: name, power, OS, CPUs, RAM, IP
esxi-gateway vm info <name>                 # detailed view of one VM
esxi-gateway vm start   <name>              # power on
esxi-gateway vm stop    <name>              # graceful guest shutdown
esxi-gateway vm stop    <name> --force      # hard power-off
esxi-gateway vm suspend <name>              # suspend to memory
esxi-gateway vm reset   <name>              # hard reset
esxi-gateway vm reboot  <name>              # graceful guest reboot (requires VMware Tools)
```

### Snapshots

```bash
esxi-gateway vm snapshot list   <name>
esxi-gateway vm snapshot create <name> <snapshot-name> [-d "description"] [--memory] [--quiesce]
esxi-gateway vm snapshot revert <snapshot-moref>
esxi-gateway vm snapshot remove <snapshot-moref> [--children]
```

Get the snapshot MoRef from `vm snapshot list` output.

### Host

```bash
esxi-gateway host list              # all hosts: state, power, CPUs, RAM, model
esxi-gateway host info              # first host (typical for standalone ESXi)
esxi-gateway host info <name>       # specific host by name
```

### Datastores

```bash
esxi-gateway datastore list             # all datastores: type, capacity, free, usage %
esxi-gateway datastore info <name>      # detailed view
```

### Networks

```bash
esxi-gateway network list           # all portgroups / distributed portgroups
```

## Output modes

Every command accepts `--json` for structured output when you need to extract
a specific field or pass data to another operation:

```bash
esxi-gateway vm list --json
esxi-gateway datastore info datastore1 --json
```

Default output is a human-readable table or key-value block — prefer this for
display; prefer `--json` when parsing.

## Task wait behaviour

Power and snapshot operations submit async vSphere tasks.
By default they block until the task completes (`--wait`).
Pass `--no-wait` to get the task MoRef back immediately for long operations.

```bash
esxi-gateway vm start myvm --no-wait      # returns task moref, does not block
esxi-gateway vm start myvm                # blocks until powered on
```

## Common workflows

### Find a VM and check its state
```bash
esxi-gateway vm list
esxi-gateway vm info "my-vm-name"
```

### Power cycle a VM
```bash
esxi-gateway vm stop  "web-server"          # graceful
esxi-gateway vm start "web-server"
```

### Take a pre-maintenance snapshot then put host in maintenance
```bash
esxi-gateway vm snapshot create "db-server" "pre-maint-$(date +%Y%m%d)"
esxi-gateway vm stop "db-server"
```

### Audit storage across all datastores
```bash
esxi-gateway datastore list
```

### Get all VM IPs for inventory
```bash
esxi-gateway vm list --json | python3 -c "
import json,sys
vms = json.load(sys.stdin)
for v in vms: print(v.get('name'), v.get('guest.ipAddress'))
"
```

## Error handling

- `ERR Not connected` — run `esxi-gateway connect` first.
- `ERR [InvalidLogin]` — wrong credentials; reconnect.
- `ERR [NoPermission]` — the user lacks privileges for that operation.
- `ERR Connection failed` — host unreachable or wrong hostname/IP.
- A task ends with `FAILED` — check vSphere events/logs on the host.

## What this tool does NOT cover

- Cloning / deploying VMs from templates
- Network adapter / disk reconfiguration
- User and permission management
- vCenter-specific features (DRS, vMotion, HA)
- ESXi host configuration changes (networking, storage adapters)

For these, use the vSphere Web Client or `govc` (VMware's official Go CLI).

## Token efficiency reminder

Never construct SOAP XML manually. One `RetrieveProperties` round-trip in raw
XML costs 3,000–6,000 tokens; the equivalent `esxi-gateway` command costs ~200.
Always exhaust the commands above before considering any other approach.
