from contextlib import asynccontextmanager, contextmanager
from typing import AsyncIterator, Iterator

from sqlalchemy.ext.asyncio import AsyncSession as SA_AsyncSession
from sqlalchemy.orm import Session as SA_Session

from ..exceptions import RestlyConfigurationError
from ._globals import _fr_globals


@asynccontextmanager
async def open_async_session() -> AsyncIterator[SA_AsyncSession]:
    """Open an async database session for use outside of request context.

    Example::

        async with fr.open_async_session() as session:
            result = await session.execute(select(User))
    """
    if _fr_globals.async_make_session is None:
        raise RestlyConfigurationError(
            "Call fr.configure() before using open_async_session()."
        )
    async with _fr_globals.async_make_session() as sess:
        yield sess


@contextmanager
def open_session() -> Iterator[SA_Session]:
    """Open a sync database session for use outside of request context.

    Example::

        with fr.open_session() as session:
            result = session.execute(select(User))
    """
    if _fr_globals.make_session is None:
        raise RestlyConfigurationError(
            "Call fr.configure() before using open_session()."
        )
    with _fr_globals.make_session() as sess:
        yield sess
