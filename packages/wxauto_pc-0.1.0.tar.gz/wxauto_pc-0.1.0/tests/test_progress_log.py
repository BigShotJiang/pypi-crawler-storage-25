from wxauto_pc.storage.progress_log import ProgressLog


def test_progress_log_record(tmp_path):
    log = ProgressLog(tmp_path / "progress.json")
    row = log.record(tool_name="send_message", category="message", status="done", notes="已完成", test_status="通过")
    rows = log.list_all()
    assert row["tool_name"] == "send_message"
    assert rows[0]["status"] == "done"
