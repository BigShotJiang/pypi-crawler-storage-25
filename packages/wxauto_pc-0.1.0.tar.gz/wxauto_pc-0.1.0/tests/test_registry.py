from wxauto_pc.tools import message_tools, system_tools, ui_tools
from wxauto_pc.tools.registry import list_tools


def test_list_tools_contains_message_session_entries():
    tools = list_tools()
    names = {item["name"] for item in tools}
    assert "wechat_initialize" in names
    assert "send_message" in names
    assert "get_sessions" in names
    assert "switch_to_contact" in names
