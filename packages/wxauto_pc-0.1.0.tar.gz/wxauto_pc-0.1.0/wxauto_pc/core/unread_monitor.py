"""未读消息监听器。"""

from __future__ import annotations

import hashlib
import logging
import time
from collections import Counter
from typing import Callable, Dict, Iterator, List, Optional

from ..storage.paths import get_monitor_log_path
from .client import WeChatClient
from .message_reader import MessageReader


class UnreadMessageMonitor:
    """监听指定会话的新未读消息。"""

    def __init__(
        self,
        client: Optional[WeChatClient] = None,
        reader: Optional[MessageReader] = None,
        log_file: str | None = None,
        enable_log: bool = True,
    ):
        self.client = client or WeChatClient()
        self.reader = reader or MessageReader(self.client)
        self._seen_counts: Counter = Counter()
        self.log_file = log_file or str(get_monitor_log_path())
        self.enable_log = enable_log
        self.logger = self._create_logger()

    def _create_logger(self) -> logging.Logger:
        logger = logging.getLogger(f"wxauto_pc.unread_monitor.{id(self)}")
        logger.setLevel(logging.DEBUG)
        logger.propagate = False
        if not self.enable_log or not self.log_file:
            logger.addHandler(logging.NullHandler())
            return logger
        handler = logging.FileHandler(self.log_file, encoding="utf-8")
        handler.setLevel(logging.DEBUG)
        handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        logger.handlers.clear()
        logger.addHandler(handler)
        return logger

    def _log(self, message: str, level: int = logging.DEBUG):
        if self.enable_log:
            self.logger.log(level, message)

    def _make_fingerprint(self, message: Dict[str, object]) -> str:
        raw = message.get("raw_content", "") or message.get("content", "")
        return hashlib.sha1(str(raw).encode("utf-8", errors="ignore")).hexdigest()

    def _seed_seen(self, messages: List[Dict[str, object]]):
        for message in messages:
            fp = self._make_fingerprint(message)
            self._seen_counts[fp] += 1

    def _filter_new_messages(self, messages: List[Dict[str, object]]) -> List[Dict[str, object]]:
        new_messages = []
        seen_in_batch: Counter = Counter()
        for message in messages:
            fp = self._make_fingerprint(message)
            seen_in_batch[fp] += 1
            if seen_in_batch[fp] > self._seen_counts.get(fp, 0):
                self._seen_counts[fp] = seen_in_batch[fp]
                new_messages.append(message)
        return new_messages

    def monitor_chat(
        self,
        chat_name: str,
        *,
        poll_interval: float = 1.0,
        read_count: int = 20,
        format_private: bool = True,
        watch_when_active: bool = True,
        stop_event=None,
        on_messages: Optional[Callable[[List[Dict[str, object]]], Optional[bool]]] = None,
        timeout_s: Optional[float] = None,
        stop_on_first_batch: bool = False,
        should_stop: Optional[Callable[[], bool]] = None,
        on_tick: Optional[Callable[[int], None]] = None,
    ) -> Iterator[List[Dict[str, object]]]:
        baseline = self.reader.read_latest_from_chat(chat_name, count=read_count, format_private=format_private)
        self._seed_seen(baseline)
        start_time = time.time()
        tick = 0
        while True:
            tick += 1
            if stop_event is not None and stop_event.is_set():
                return
            if should_stop is not None and should_stop():
                return
            if timeout_s is not None and time.time() - start_time >= timeout_s:
                return
            current_chat = self.client.get_chat_name()
            unread_count = self.client.get_unread_count(chat_name)
            should_read = (watch_when_active and current_chat == chat_name) or unread_count > 0
            if should_read:
                messages = self.reader.read_latest_from_chat(chat_name, count=read_count, format_private=format_private)
                new_messages = self._filter_new_messages(messages)
                if new_messages:
                    if on_messages:
                        callback_result = on_messages(new_messages)
                        if callback_result:
                            yield new_messages
                            return
                    yield new_messages
                    if stop_on_first_batch:
                        return
            if on_tick is not None:
                on_tick(tick)
            time.sleep(poll_interval)
