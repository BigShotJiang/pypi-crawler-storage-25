"""微信客户端核心类。"""

from __future__ import annotations

import ctypes
import os
import re
import time
from typing import Dict, List, Optional, Tuple

from ..storage.message_cache import MessageCache

try:
    import uiautomation as auto
except ImportError:  # pragma: no cover - 允许未安装时导入包本身
    auto = None


class WeChatClient:
    """微信桌面客户端操作类。"""

    PROFILE_CLASS_NAME = "mmui::ContactProfileView"
    TABBAR_AUTOMATION_ID = "MainView.main_tabbar"
    PROFILE_NICKNAME_AUTOMATION_ID = "right_v_view.nickname_button_view.display_name_text"
    PROFILE_KEY_AUTOMATION_ID = "right_v_view.user_info_center_view.basic_line_view.basic_line.key_text"
    PROFILE_VALUE_AUTOMATION_ID = "right_v_view.user_info_center_view.basic_line_view.ContactProfileTextView"

    def __init__(self, process_id: Optional[int] = None, auto_fetch_profile: bool = False):
        self._ensure_auto_available()
        self.process_id = process_id
        self.main_window = None
        self.profile_cache: Dict[str, str] = {}
        self.message_cache = MessageCache()
        self._connect()
        if auto_fetch_profile:
            self._init_profile()

    @staticmethod
    def _ensure_auto_available():
        if auto is None:
            raise ImportError("未安装 uiautomation，请先安装依赖后再使用微信自动化功能")

    def _walk_controls(self, control, *, max_depth: int = 6, _depth: int = 0):
        if _depth > max_depth:
            return
        yield control
        try:
            children = control.GetChildren()
        except Exception:
            children = []
        for child in children:
            yield from self._walk_controls(child, max_depth=max_depth, _depth=_depth + 1)

    def _find_contact_profile_view_once(self, *, max_depth_main: int = 8, max_depth_root: int = 4, max_nodes: int = 1200):
        scanned = 0
        roots = []
        if self.main_window is not None:
            roots.append((self.main_window, max_depth_main))
        roots.append((auto.GetRootControl(), max_depth_root))
        for root, depth in roots:
            for ctrl in self._walk_controls(root, max_depth=depth):
                scanned += 1
                if getattr(ctrl, "ClassName", "") == self.PROFILE_CLASS_NAME:
                    return ctrl
                if scanned >= max_nodes:
                    return None
        return None

    def _wait_contact_profile_view(self, *, timeout: float = 1.5, interval: float = 0.05, max_depth: int = 10):
        deadline = time.time() + timeout
        while time.time() < deadline:
            ctrl = self._find_contact_profile_view_once(
                max_depth_main=min(max_depth + 2, 12),
                max_depth_root=min(max_depth, 6),
            )
            if ctrl is not None:
                return ctrl
            time.sleep(interval)
        return None

    def _close_contact_profile_view(self, max_attempts: int = 2) -> bool:
        closed = False
        for _ in range(max_attempts):
            profile_view = self._find_contact_profile_view_once(max_depth_main=10, max_depth_root=3, max_nodes=700)
            if profile_view is None:
                return closed
            try:
                profile_view.SetFocus()
            except Exception:
                pass
            try:
                profile_view.SendKeys("{Esc}")
                closed = True
            except Exception:
                break
            time.sleep(0.06)
        return closed

    def _close_contact_profile_view_safely(self, delay: float = 0.3):
        try:
            time.sleep(delay)
            self._close_contact_profile_view()
        except Exception:
            pass

    @staticmethod
    def _control_center(rect) -> Tuple[int, int]:
        center_x = rect.left + max(1, (rect.right - rect.left) // 2)
        center_y = rect.top + max(1, (rect.bottom - rect.top) // 2)
        return center_x, center_y

    def _find_contacts_control(self, tabbar):
        tabbar_rect = tabbar.BoundingRectangle
        target_y = tabbar_rect.top + 105
        keywords = ("通讯录", "联系人", "contact", "contacts", "addressbook")
        preferred_types = {"ButtonControl", "ListItemControl", "TabItemControl"}
        candidates = []
        for ctrl in self._walk_controls(tabbar, max_depth=6):
            aid = getattr(ctrl, "AutomationId", "") or ""
            name = (getattr(ctrl, "Name", "") or "").strip()
            class_name = getattr(ctrl, "ClassName", "") or ""
            control_type = getattr(ctrl, "ControlTypeName", "") or ""
            if not aid and not name and control_type not in preferred_types:
                continue
            probe = f"{aid} {name} {class_name}".lower()
            score = 0
            if any(k in probe for k in keywords):
                score += 10
            if control_type in preferred_types:
                score += 2
            try:
                rect = ctrl.BoundingRectangle
                center_x, center_y = self._control_center(rect)
            except Exception:
                continue
            if rect.right - rect.left <= 120:
                score += 1
            distance = abs(center_y - target_y)
            candidates.append((score, distance, ctrl, {"name": name, "aid": aid, "center_x": center_x, "center_y": center_y}))
        if not candidates:
            return None
        candidates.sort(key=lambda item: (-item[0], item[1]))
        best = candidates[0]
        return {"control": best[2], "meta": best[3], "score": best[0]}

    def click_contacts_tab(self, y_offset: int = 106) -> Tuple[bool, str]:
        try:
            tabbar = self.main_window.Control(AutomationId=self.TABBAR_AUTOMATION_ID)
            if not tabbar.Exists(2, 0.5):
                return False, f"未找到 AutomationId={self.TABBAR_AUTOMATION_ID} 的控件"
            found = self._find_contacts_control(tabbar)
            if found is not None:
                ctrl = found["control"]
                meta = found["meta"]
                try:
                    ctrl.Click()
                    time.sleep(0.25)
                    return True, f"已打开联系人页面：{meta['name'] or '通讯录'}"
                except Exception:
                    auto.Click(meta["center_x"], meta["center_y"])
                    time.sleep(0.25)
                    return True, f"已通过坐标回退打开联系人页面：{meta['name'] or '通讯录'}"
            rect = tabbar.BoundingRectangle
            click_x = rect.left + max(1, (rect.right - rect.left) // 2)
            click_y = max(rect.top + 5, min(rect.bottom - 5, rect.top + int(y_offset)))
            auto.Click(click_x, click_y)
            time.sleep(0.25)
            return True, "已通过坐标点击联系人入口"
        except Exception as exc:
            return False, f"点击联系人失败: {exc}"

    def click_top_avatar(self, y_offset: int = 50) -> Tuple[bool, str]:
        try:
            tabbar = self.main_window.Control(AutomationId=self.TABBAR_AUTOMATION_ID)
            if not tabbar.Exists(2, 0.5):
                return False, f"未找到 AutomationId={self.TABBAR_AUTOMATION_ID} 的控件"
            rect = tabbar.BoundingRectangle
            click_x = rect.left + max(1, (rect.right - rect.left) // 2)
            click_y = max(rect.top + 5, min(rect.bottom - 5, rect.top + int(y_offset)))
            auto.Click(click_x, click_y)
            time.sleep(0.25)
            return True, "已点击顶部头像区域"
        except Exception as exc:
            return False, f"点击顶部头像失败: {exc}"

    @staticmethod
    def _normalize_wechat_id(value: str) -> str:
        text = (value or "").strip()
        if not text:
            return ""
        labeled = re.search(r"(?:微信号|微信ID|WeChat ID)\s*[:：]?\s*([a-zA-Z][-_a-zA-Z0-9]{5,31})", text, flags=re.IGNORECASE)
        if labeled:
            return labeled.group(1)
        if re.fullmatch(r"[a-zA-Z][-_a-zA-Z0-9]{5,31}", text):
            return text
        return ""

    def _extract_profile_from_contact_profile_view(self, profile_view) -> Tuple[str, str]:
        nickname = ""
        for ctrl in self._walk_controls(profile_view, max_depth=14):
            if getattr(ctrl, "AutomationId", "") == self.PROFILE_NICKNAME_AUTOMATION_ID:
                nickname = (getattr(ctrl, "Name", "") or "").strip()
                break
        wechat_id = ""
        expecting_value = False
        for ctrl in self._walk_controls(profile_view, max_depth=14):
            aid = getattr(ctrl, "AutomationId", "")
            name = (getattr(ctrl, "Name", "") or "").strip()
            if aid == self.PROFILE_KEY_AUTOMATION_ID and name.startswith("微信号"):
                expecting_value = True
                continue
            if expecting_value and aid == self.PROFILE_VALUE_AUTOMATION_ID:
                wechat_id = self._normalize_wechat_id(name)
                if wechat_id:
                    break
        if not wechat_id:
            for ctrl in self._walk_controls(profile_view, max_depth=14):
                candidate = self._normalize_wechat_id((getattr(ctrl, "Name", "") or "").strip())
                if candidate:
                    wechat_id = candidate
                    break
        return nickname, wechat_id

    def _init_profile(self):
        tabbar = self.main_window.Control(AutomationId=self.TABBAR_AUTOMATION_ID)
        if not tabbar.Exists(2, 0.5):
            raise RuntimeError(f"未找到 AutomationId={self.TABBAR_AUTOMATION_ID} 的控件")
        for _ in range(3):
            ok, _ = self.click_top_avatar(y_offset=50)
            if not ok:
                time.sleep(0.18)
                continue
            profile_view = self._wait_contact_profile_view(timeout=1.8, interval=0.05, max_depth=12)
            if profile_view is None:
                time.sleep(0.18)
                continue
            extract_deadline = time.time() + 2.5
            while time.time() < extract_deadline:
                nickname, wechat_id = self._extract_profile_from_contact_profile_view(profile_view)
                if nickname and wechat_id:
                    self.profile_cache = {"nickname": nickname, "wechat_id": wechat_id}
                    self._close_contact_profile_view_safely(delay=0.5)
                    return
                time.sleep(0.08)
            # 识别失败时先不主动关闭弹窗，避免刚显示就被收起
            raise RuntimeError("个人信息弹窗已打开，但在等待时间内未完成识别")
        raise RuntimeError("点击顶部头像后未能提取完整个人资料")

    def get_profile(self) -> Dict[str, str]:
        return self.profile_cache

    def verify_profile(self) -> bool:
        try:
            self._init_profile()
            return bool(self.profile_cache.get("nickname") and self.profile_cache.get("wechat_id"))
        except Exception:
            return False

    def _get_window_handle(self) -> int:
        try:
            return int(getattr(self.main_window, "NativeWindowHandle", 0) or 0)
        except Exception:
            return 0

    def _show_and_focus_main_window(self) -> Tuple[bool, str]:
        hwnd = self._get_window_handle()
        last_error = ""

        if hwnd:
            try:
                user32 = ctypes.windll.user32
                user32.ShowWindow(hwnd, 9)   # SW_RESTORE
                user32.ShowWindow(hwnd, 5)   # SW_SHOW
                user32.ShowWindow(hwnd, 1)   # SW_SHOWNORMAL
                time.sleep(0.2)
                user32.SetForegroundWindow(hwnd)
                user32.BringWindowToTop(hwnd)
                user32.SetActiveWindow(hwnd)
                user32.SetFocus(hwnd)
                time.sleep(0.2)
            except Exception as exc:
                last_error = str(exc)

        try:
            self.main_window.ShowWindow(9)
            self.main_window.ShowWindow(5)
            self.main_window.ShowWindow(1)
            time.sleep(0.2)
        except Exception as exc:
            last_error = str(exc)

        try:
            self.main_window.SetFocus()
            time.sleep(0.2)
            if self.get_chat_name() or self.is_active():
                return True, "已恢复并激活微信窗口"
        except Exception as exc:
            last_error = str(exc)

        if hwnd:
            return False, f"已尝试恢复微信窗口，但激活失败: {last_error}"
        return False, "未获取到微信窗口句柄，可能已隐藏到托盘或未正确创建主窗口"

    def _reconnect_main_window(self) -> bool:
        try:
            if self.process_id:
                self.main_window = auto.WindowControl(searchDepth=1, ProcessId=self.process_id)
            else:
                self.main_window = auto.WindowControl(searchDepth=1, ClassName="mmui::MainWindow")
            return bool(self.main_window and self.main_window.Exists(0, 0))
        except Exception:
            return False

    def _connect(self):
        if self.process_id:
            self.main_window = auto.WindowControl(searchDepth=1, ProcessId=self.process_id)
            if not self.main_window.Exists(0, 0):
                raise ConnectionError(f"未找到进程ID为 {self.process_id} 的微信窗口")
        else:
            self.main_window = auto.WindowControl(searchDepth=1, ClassName="mmui::MainWindow")
            if not self.main_window.Exists(0, 0):
                raise ConnectionError("未找到微信窗口，请确保微信已启动")
        self._show_and_focus_main_window()

    def activate(self) -> Tuple[bool, str]:
        success, message = self._show_and_focus_main_window()
        if success:
            return success, message

        self._reconnect_main_window()
        success, message = self._show_and_focus_main_window()
        if success:
            return success, "已重新连接并激活微信窗口"

        return False, message

    def is_active(self) -> bool:
        try:
            return bool(self.main_window.HasKeyboardFocus or self.main_window.IsTopLevel())
        except Exception:
            return False

    def get_status(self) -> Dict[str, object]:
        exists = False
        try:
            exists = bool(self.main_window and self.main_window.Exists(0, 0))
        except Exception:
            exists = False
        return {
            "connected": exists,
            "active": self.is_active() if exists else False,
            "visible": bool(self._get_window_handle()) if exists else False,
            "chat_name": self.get_chat_name() if exists else "",
            "profile_loaded": bool(self.profile_cache),
        }

    def get_chat_list(self):
        chat_list = self.main_window.ListControl(AutomationId="chat_message_list")
        if not chat_list.Exists(0, 0):
            raise ValueError("未找到聊天消息列表")
        return chat_list

    def get_session_list_control(self):
        session_list = self.main_window.ListControl(Name="会话")
        if not session_list.Exists(1, 0.5):
            return None
        return session_list

    def _parse_unread_from_session_item_name(self, name: str) -> Optional[Tuple[str, int]]:
        text = (name or "").strip()
        if not text:
            return None
        chat_name = text.split("\n")[0].strip()
        if not chat_name:
            return None
        matched = re.search(r"\[(\d+)\s*条\]", text)
        if not matched:
            return None
        try:
            unread = int(matched.group(1))
        except ValueError:
            return None
        return chat_name, unread

    def get_unread_chats(self, ignore_list: Optional[List[str]] = None) -> List[Dict[str, int]]:
        ignore_set = set(ignore_list or [])
        session_list = self.get_session_list_control()
        if not session_list:
            return []
        unread_items: List[Dict[str, int]] = []
        for item in session_list.GetChildren():
            parsed = self._parse_unread_from_session_item_name(getattr(item, "Name", ""))
            if not parsed:
                continue
            chat_name, unread = parsed
            if chat_name in ignore_set:
                continue
            unread_items.append({"chat_name": chat_name, "unread": unread})
        return unread_items

    def get_sessions(self) -> List[Dict[str, object]]:
        session_list = self.get_session_list_control()
        if not session_list:
            return []
        rows: List[Dict[str, object]] = []
        for item in session_list.GetChildren():
            name = (getattr(item, "Name", "") or "").strip()
            if not name:
                continue
            parsed = self._parse_unread_from_session_item_name(name)
            chat_name = parsed[0] if parsed else name.split("\n")[0].strip()
            unread = parsed[1] if parsed else 0
            rows.append({"chat_name": chat_name, "unread": unread, "raw_name": name})
        return rows

    def get_recent_groups(self) -> List[Dict[str, object]]:
        return [item for item in self.get_sessions() if item.get("chat_name", "").endswith(")") and "(" in item.get("chat_name", "")]

    def get_unread_count(self, chat_name: str) -> int:
        for item in self.get_unread_chats():
            if item["chat_name"] == chat_name:
                return item["unread"]
        return 0

    def switch_to_chat(self, chat_name: str, timeout: int = 5) -> bool:
        try:
            title_text = self.main_window.TextControl(Name=chat_name)
            if title_text.Exists(0.3, 0.3):
                return True
            session_list = self.main_window.ListControl(Name="会话")
            if session_list.Exists(1, 0.5):
                automation_id = f"session_item_{chat_name}"
                chat_item = session_list.ListItemControl(AutomationId=automation_id)
                if chat_item.Exists(0.5, 0.5):
                    chat_item.Click()
                    time.sleep(0.3)
                    return True
            search_box = self.main_window.EditControl(Name="搜索")
            if not search_box.Exists(2, 0.5):
                return False
            search_box.Click()
            time.sleep(0.3)
            search_box.SendKeys(chat_name)
            time.sleep(min(timeout, 1))
            search_result_list = self.main_window.ListControl(AutomationId="search_list")
            if not search_result_list.Exists(0.5, 0.5):
                search_box.SendKeys("{Esc}")
                return False
            items = search_result_list.GetChildren()
            if not items:
                search_box.SendKeys("{Esc}")
                return False
            section_name = None
            frequent_item = None
            contact_item = None
            group_item = None
            for item in items:
                item_name = item.Name.strip()
                if item.ControlTypeName != "ListItemControl":
                    continue
                if item_name in {"最常使用", "联系人", "群聊", "聊天记录", "收藏", "搜索网络结果"}:
                    section_name = item_name
                    continue
                if item.AutomationId == f"search_item_{chat_name}" or item_name == chat_name:
                    if section_name == "最常使用" and frequent_item is None:
                        frequent_item = item
                    elif section_name == "联系人" and contact_item is None:
                        contact_item = item
                    elif section_name == "群聊" and group_item is None:
                        group_item = item
            target_item = frequent_item or contact_item or group_item
            if not target_item:
                search_box.SendKeys("{Esc}")
                return False
            target_item.Click()
            time.sleep(0.5)
            return True
        except Exception:
            return False

    def get_latest_messages(self, count: int | None = None) -> List[Dict[str, object]]:
        chat_list = self.get_chat_list()
        messages = []
        all_items = chat_list.GetChildren()
        items_to_parse = all_items[-count:] if count else all_items
        for item in items_to_parse:
            msg_data = self._parse_message_item(item)
            if msg_data:
                messages.append(msg_data)
        return messages

    def _parse_message_item(self, item) -> Optional[Dict[str, object]]:
        try:
            text = item.Name.strip()
            if not text:
                return None
            is_time = self._is_time_marker(item)
            is_mine = False
            color_ambiguous = not is_time
            if not is_time:
                try:
                    from PIL import ImageGrab

                    def _is_green(px):
                        r, g, b = px[0], px[1], px[2]
                        return g > 150 and g > r * 1.3 and g > b * 1.1

                    def _sample_green(img):
                        w, h = img.size
                        if w <= 0 or h <= 0:
                            return 0, 0
                        sample_rows = [int(h * ratio) for ratio in (0.25, 0.5, 0.75) if 0 < int(h * ratio) < h]
                        rg = sum(1 for sy in sample_rows for x in range(60, 95, 5) if _is_green(img.getpixel((int(w * x / 100), sy))))
                        lg = sum(1 for sy in sample_rows for x in range(5, 40, 5) if _is_green(img.getpixel((int(w * x / 100), sy))))
                        return rg, lg

                    rect = item.BoundingRectangle
                    img = ImageGrab.grab(bbox=(rect.left, rect.top, rect.right, rect.bottom))
                    right_green, left_green = _sample_green(img)
                    if right_green == 0 and left_green == 0:
                        time.sleep(0.2)
                        img2 = ImageGrab.grab(bbox=(rect.left, rect.top, rect.right, rect.bottom))
                        right_green, left_green = _sample_green(img2)
                    if right_green > 0 or left_green > 0:
                        is_mine = right_green > left_green
                        color_ambiguous = False
                except Exception:
                    pass
            return {
                "sender": "",
                "content": text,
                "time": "",
                "is_time": is_time,
                "is_mine": is_mine,
                "color_ambiguous": color_ambiguous if not is_time else False,
                "raw_content": text,
            }
        except Exception:
            return None

    def _is_time_marker(self, item) -> bool:
        if getattr(item, "AutomationId", None):
            return False
        text = (getattr(item, "Name", "") or "").strip()
        if not text or ":" not in text or len(text) > 20:
            return False
        time_patterns = [
            r"^\d{1,2}:\d{2}$",
            r"^昨天",
            r"^星期[一二三四五六日]",
            r"^\d{1,2}月\d{1,2}日",
            r"^\d{4}年\d{1,2}月\d{1,2}日",
        ]
        return any(re.match(pattern, text) for pattern in time_patterns)

    def get_chat_name(self) -> str:
        try:
            chat_name_label = self.main_window.TextControl(
                AutomationId="content_view.top_content_view.title_h_view.left_v_view.left_content_v_view.left_ui_.big_title_line_h_view.current_chat_name_label"
            )
            if chat_name_label.Exists(1, 0.5):
                return chat_name_label.Name
            return ""
        except Exception:
            return ""

    def get_cached_wechat_id(self) -> Optional[str]:
        wechat_id = (self.profile_cache or {}).get("wechat_id")
        if not wechat_id or wechat_id == "未知":
            return None
        return wechat_id

    def _detect_chat_type(self, chat_name: str) -> str:
        try:
            title = self.get_chat_name() or chat_name
            if title and title.endswith(")") and "(" in title:
                return "group"
        except Exception:
            pass
        return "private"

    def _guess_content_type_from_path(self, file_path: str) -> str:
        ext = os.path.splitext(file_path)[1].lower()
        if ext in {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"}:
            return "image"
        return "file"

    def send_message(self, chat_name: str, message: str) -> Tuple[bool, str]:
        try:
            if not self.switch_to_chat(chat_name):
                return False, f"未找到联系人或群聊: {chat_name}"
            input_box = self.main_window.EditControl(AutomationId="chat_input_field")
            if not input_box.Exists(2, 0.5):
                return False, "未找到输入框"
            input_box.Click()
            time.sleep(0.2)
            input_box.SendKeys(message)
            time.sleep(0.3)
            input_box.SendKeys("{Enter}")
            time.sleep(0.3)
            chat_type = self._detect_chat_type(chat_name)
            self.message_cache.add_message(
                chat_name,
                message,
                chat_type=chat_type,
                content_type="text",
                chat_id=self.get_cached_wechat_id(),
                to_chat_name=chat_name,
                to_chat_id=None,
                from_chat_name=(self.profile_cache or {}).get("nickname") or "我",
                group_name=chat_name if chat_type == "group" else None,
            )
            return True, "发送成功"
        except Exception as exc:
            return False, f"发送失败: {exc}"

    def send_message_with_mention(self, chat_name: str, mention_names: List[str], message: str) -> Tuple[bool, str]:
        try:
            if not self.switch_to_chat(chat_name):
                return False, f"未找到群聊: {chat_name}"

            input_box = self.main_window.EditControl(AutomationId="chat_input_field")
            if not input_box.Exists(2, 0.5):
                return False, "未找到输入框"

            input_box.Click()
            time.sleep(0.2)

            for mention_name in mention_names:
                input_box.SendKeys("@")
                time.sleep(0.5)
                input_box.SendKeys(mention_name)
                time.sleep(0.8)

                if mention_name == "所有人":
                    input_box.SendKeys("{Enter}")
                    time.sleep(0.3)
                    continue

                mention_list = self.main_window.ListControl(AutomationId="chat_mention_list")
                if not mention_list.Exists(0.5, 0.5):
                    try:
                        input_box.GetValuePattern().SetValue("")
                    except Exception:
                        pass
                    return False, f"好友 '{mention_name}' 不在群 '{chat_name}' 中，已取消发送"

                items = mention_list.GetChildren()
                if len(items) == 0:
                    try:
                        input_box.GetValuePattern().SetValue("")
                    except Exception:
                        pass
                    return False, f"好友 '{mention_name}' 不在群 '{chat_name}' 中，已取消发送"

                input_box.SendKeys("{Enter}")
                time.sleep(0.3)

            input_box.SendKeys(" " + message)
            time.sleep(0.3)
            input_box.SendKeys("{Enter}")
            time.sleep(0.3)

            mention_text = " ".join(f"@{name}" for name in mention_names)
            self.message_cache.add_message(
                chat_name,
                f"{mention_text} {message}".strip(),
                chat_type="group",
                content_type="text",
                chat_id=self.get_cached_wechat_id(),
                to_chat_name=chat_name,
                to_chat_id=None,
                from_chat_name=(self.profile_cache or {}).get("nickname") or "我",
                group_name=chat_name,
            )
            return True, "发送成功"
        except Exception as exc:
            return False, f"发送失败: {exc}"

    @staticmethod
    def _normalize_input_path(file_path: str) -> str:
        text = (file_path or "").strip()
        if not text:
            return ""
        invisible_chars = {
            "\u200e",  # LRM
            "\u200f",  # RLM
            "\u202a",  # LRE
            "\u202b",  # RLE
            "\u202c",  # PDF
            "\u202d",  # LRO
            "\u202e",  # RLO
            "\ufeff",  # BOM
        }
        return "".join(ch for ch in text if ch not in invisible_chars)

    def send_file(self, chat_name: str, file_path: str) -> Tuple[bool, str]:
        try:
            normalized_path = self._normalize_input_path(file_path)
            if not normalized_path:
                return False, "文件路径不能为空"
            if not os.path.exists(normalized_path):
                return False, f"文件不存在: {normalized_path}"
            if not self.switch_to_chat(chat_name):
                return False, f"未找到联系人或群聊: {chat_name}"
            input_box = self.main_window.EditControl(AutomationId="chat_input_field")
            if not input_box.Exists(2, 0.5):
                return False, "未找到输入框"
            input_box.Click()
            time.sleep(0.3)
            import subprocess

            ps_script = f'Set-Clipboard -Path "{normalized_path}"'
            subprocess.run(["powershell", "-Command", ps_script], check=True)
            time.sleep(0.3)
            input_box.SendKeys("{Ctrl}v")
            time.sleep(0.8)
            input_box.SendKeys("{Enter}")
            time.sleep(0.3)
            chat_type = self._detect_chat_type(chat_name)
            self.message_cache.add_message(
                chat_name,
                os.path.basename(normalized_path),
                chat_type=chat_type,
                content_type=self._guess_content_type_from_path(normalized_path),
                chat_id=self.get_cached_wechat_id(),
                to_chat_name=chat_name,
                to_chat_id=None,
                from_chat_name=(self.profile_cache or {}).get("nickname") or "我",
                group_name=chat_name if chat_type == "group" else None,
            )
            return True, "发送成功"
        except Exception as exc:
            return False, f"发送失败: {exc}"

    def clear_message_cache(self):
        self.message_cache.clear_all()

    def clear_old_cache(self, days: int = 7):
        self.message_cache.clear_old_messages(days)
