"""消息读取器。"""

from __future__ import annotations

from typing import Dict, List, Optional

from .client import WeChatClient


class MessageReader:
    """微信消息读取器。"""

    def __init__(self, client: Optional[WeChatClient] = None):
        self.client = client or WeChatClient()

    def read_latest_from_chat(self, chat_name: str, count: int | None = None, format_private: bool = True) -> List[Dict[str, object]]:
        if not self.client.switch_to_chat(chat_name):
            raise ValueError(f"未找到聊天: {chat_name}")
        messages = self.client.get_latest_messages(None)
        if format_private:
            current_chat = self.client.get_chat_name()
            messages = self._format_private_messages(messages, current_chat)
        else:
            messages = self._mark_my_messages(messages, chat_name)
        return messages[-count:] if count else messages

    def _mark_my_messages(self, messages: List[Dict[str, object]], chat_name: str) -> List[Dict[str, object]]:
        formatted = []
        current_time = ""
        for msg in messages:
            if msg.get("is_time", False):
                current_time = msg["content"]
                continue
            content = msg["content"]
            sender = "我" if self.client.message_cache.is_sent_by_me(content, chat_name) else "群成员"
            formatted.append(
                {
                    "sender": sender,
                    "content": content,
                    "time": current_time,
                    "formatted_content": f"[{current_time}][{sender}] {content}",
                    "raw_content": content,
                }
            )
        return formatted

    def _format_private_messages(self, messages: List[Dict[str, object]], chat_name: str) -> List[Dict[str, object]]:
        formatted = []
        current_time = ""
        for msg in messages:
            if msg.get("is_time", False):
                current_time = msg["content"]
                continue
            content = msg["content"]
            is_mine = msg.get("is_mine", False)
            if msg.get("color_ambiguous", True):
                is_mine = self.client.message_cache.is_sent_by_me(content, chat_name)
            if is_mine:
                sender = "我"
                formatted_content = f"[{current_time}][我] {content}"
            else:
                sender = chat_name
                formatted_content = f"[{current_time}][{chat_name}] {content}"
            formatted.append(
                {
                    "sender": sender,
                    "content": formatted_content,
                    "time": current_time,
                    "is_mine": is_mine,
                    "raw_content": content,
                }
            )
        return formatted
