"""CLI for op3."""
