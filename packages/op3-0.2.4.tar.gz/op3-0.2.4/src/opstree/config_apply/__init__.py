"""Shared configuration application logic."""
