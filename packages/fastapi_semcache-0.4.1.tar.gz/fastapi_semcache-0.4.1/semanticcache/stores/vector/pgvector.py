"""Async PostgreSQL + pgvector storage for cache embeddings and payloads."""

# pyright: reportUnknownArgumentType=false

from __future__ import annotations

import asyncio
import re
import math
from datetime import datetime, timedelta, timezone
from typing import LiteralString, Self, cast

from psycopg import sql
from psycopg.types.json import Json
from psycopg_pool import AsyncConnectionPool

from ...types import CacheEntry
from ...exceptions import NonFiniteEmbeddingValueException

_IDENTIFIER_SAFE = re.compile(r"^[a-z][a-z0-9_]{0,62}$")


def _vector_literal(embedding: list[float]) -> str:
    """Format a Python embedding list for PostgreSQL ``vector`` casts.

    Args:
        embedding: Dense embedding matching ``VECTOR(d)`` column dimension.

    Returns:
        Bracketed comma-separated floats accepted by ``::vector``.

    Raises:
        NonFiniteEmbeddingValueException: If any value is non-finite (nan or inf).
    """
    parts: list[str] = []
    for x in embedding:
        f = float(x)
        if not math.isfinite(f):
            raise NonFiniteEmbeddingValueException(
                index=embedding.index(x),
                value=f,
            )
        parts.append(str(f))
    return "[" + ",".join(parts) + "]"


def _validate_table_name(name: str) -> str:
    """Ensure ``name`` is a safe unqualified SQL identifier.

    Args:
        name: Proposed table name (only lower-case ``sc_`` + hex is expected).

    Returns:
        The same string when valid.

    Raises:
        ValueError: If ``name`` is not a safe identifier.
    """
    if not _IDENTIFIER_SAFE.match(name) or ".." in name:
        msg = f"invalid vector table name: {name!r}"
        raise ValueError(msg)
    return name


class AsyncPgVectorStore:
    """Insert and ANN-search rows in a pgvector table using cosine distance."""

    _embedding_dim: int
    _table_name: str
    _pool: AsyncConnectionPool
    _schema_lock: asyncio.Lock
    _schema_ready: bool
    _ttl_days: float | None

    def __init__(
        self,
        pg_uri: str,
        *,
        table_name: str,
        embedding_dim: int,
        min_pool_size: int = 1,
        max_pool_size: int = 10,
        ttl_days: float | None = None,
    ) -> None:
        """Configure an async connection pool for a ``VECTOR(dim)`` cache table.

        Args:
            pg_uri: PostgreSQL connection URI (pgvector extension required).
            table_name: Target table; created by ``ensure_schema`` if missing.
            embedding_dim: Expected embedding length; must match ``VECTOR(d)``.
            min_pool_size: Minimum connections kept in the pool.
            max_pool_size: Maximum concurrent connections.
            ttl_days: Optional TTL in days (fractional allowed). When set, each
                upserted row receives ``expires_at = NOW() + interval``. When
                ``None``, ``expires_at`` is left NULL.
        """
        self._embedding_dim = embedding_dim
        self._table_name = _validate_table_name(table_name)
        self._schema_lock = asyncio.Lock()
        self._schema_ready = False
        self._ttl_days = ttl_days
        self._pool = AsyncConnectionPool(
            conninfo=pg_uri,
            min_size=min_pool_size,
            max_size=max_pool_size,
            open=False,
        )

    async def open(self) -> None:
        """Open the async pool (required before queries)."""
        await self._pool.open()

    async def close(self) -> None:
        """Close all pooled connections."""
        await self._pool.close()

    async def __aenter__(self) -> Self:
        """Open the pool for use as an async context manager."""
        await self.open()
        return self

    async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
        """Close the pool when leaving the context."""
        await self.close()

    async def ensure_schema(self) -> None:
        """Create the cache table, indexes, and unique constraint when they do not exist."""
        if self._schema_ready:
            return
        async with self._schema_lock:
            if self._schema_ready:
                return
            if self._embedding_dim < 1 or self._embedding_dim > 16000:
                msg = "embedding_dim out of supported range for VECTOR()"
                raise ValueError(msg)
            dim_lit = sql.SQL(cast(LiteralString, str(self._embedding_dim)))
            tbl = sql.Identifier(self._table_name)
            create_table = sql.SQL(
                """
                CREATE TABLE IF NOT EXISTS {tbl} (
                  id SERIAL PRIMARY KEY,
                  query_text TEXT NOT NULL,
                  query_embedding VECTOR({dim}),
                  response JSONB NOT NULL,
                  model_key TEXT NOT NULL DEFAULT '',
                  scope_key TEXT NOT NULL DEFAULT '',
                  created_at TIMESTAMPTZ DEFAULT NOW(),
                  expires_at TIMESTAMPTZ DEFAULT NULL
                )
                """
            ).format(tbl=tbl, dim=dim_lit)
            idx_name = sql.Identifier(f"{self._table_name}_hnsw")
            create_idx = sql.SQL(
                """
                CREATE INDEX IF NOT EXISTS {idx}
                ON {tbl}
                USING hnsw (query_embedding vector_cosine_ops)
                WITH (m = 16, ef_construction = 64)
                """
            ).format(idx=idx_name, tbl=tbl)
            scope_idx_name = sql.Identifier(f"{self._table_name}_scope_model")
            create_scope_idx = sql.SQL(
                """
                CREATE INDEX IF NOT EXISTS {idx}
                ON {tbl} (scope_key, model_key)
                """
            ).format(idx=scope_idx_name, tbl=tbl)
            uniq_name = sql.Identifier(f"{self._table_name}_uniq_query")
            create_uniq = sql.SQL(
                """
                CREATE UNIQUE INDEX IF NOT EXISTS {idx}
                ON {tbl} (query_text, model_key, scope_key)
                """
            ).format(idx=uniq_name, tbl=tbl)
            migrate_model_key = sql.SQL(
                """
                ALTER TABLE {tbl}
                ADD COLUMN IF NOT EXISTS model_key TEXT NOT NULL DEFAULT ''
                """
            ).format(tbl=tbl)
            migrate_scope_key = sql.SQL(
                """
                ALTER TABLE {tbl}
                ADD COLUMN IF NOT EXISTS scope_key TEXT NOT NULL DEFAULT ''
                """
            ).format(tbl=tbl)
            migrate_expires_at = sql.SQL(
                """
                ALTER TABLE {tbl}
                ADD COLUMN IF NOT EXISTS expires_at TIMESTAMPTZ DEFAULT NULL
                """
            ).format(tbl=tbl)
            async with self._pool.connection() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(create_table)
                    await cur.execute(create_idx)
                    await cur.execute(create_scope_idx)
                    await cur.execute(create_uniq)
                    await cur.execute(migrate_model_key)
                    await cur.execute(migrate_scope_key)
                    await cur.execute(migrate_expires_at)
            self._schema_ready = True

    def _ensure_dim(self, embedding: list[float]) -> None:
        if len(embedding) != self._embedding_dim:
            msg = (
                f"embedding length {len(embedding)} does not match "
                f"VECTOR({self._embedding_dim})"
            )
            raise ValueError(msg)

    async def upsert(
        self,
        query_text: str,
        embedding: list[float],
        response: dict[str, object],
        *,
        model_key: str = "",
        scope_key: str = "",
    ) -> int:
        """Insert or update a cache row, preventing duplicates on conflict.

        Uses ``ON CONFLICT (query_text, model_key, scope_key) DO UPDATE`` so
        concurrent cache misses for the same query overwrite the stored response
        rather than inserting duplicate rows. Requires the unique index created
        by ``ensure_schema``.

        Args:
            query_text: Original query string stored for debugging or display.
            embedding: Vector matching the table ``VECTOR(d)`` dimension.
            response: JSON-serializable payload stored in ``response`` JSONB.
            model_key: Logical model id for scoped similarity search and Redis keys;
                empty string denotes the default bucket.
            scope_key: Tenant or namespace bucket; empty string denotes the legacy
                global bucket when scope requirement is disabled.

        Returns:
            Primary key ``id`` of the inserted or updated row.

        Raises:
            ValueError: If ``embedding`` length does not match ``embedding_dim``.
        """
        self._ensure_dim(embedding)
        vec = _vector_literal(embedding)
        expires_at: datetime | None = (
            datetime.now(tz=timezone.utc) + timedelta(days=self._ttl_days)
            if self._ttl_days is not None
            else None
        )
        tbl = sql.Identifier(self._table_name)
        insert = sql.SQL(
            """
            INSERT INTO {tbl} (query_text, query_embedding, response, model_key, scope_key, expires_at)
            VALUES (%s, %s::vector, %s::jsonb, %s, %s, %s)
            ON CONFLICT (query_text, model_key, scope_key)
            DO UPDATE SET
                query_embedding = EXCLUDED.query_embedding,
                response        = EXCLUDED.response,
                created_at      = NOW(),
                expires_at      = EXCLUDED.expires_at
            RETURNING id
            """
        ).format(tbl=tbl)
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                _ = await cur.execute(
                    insert,
                    (query_text, vec, Json(response), model_key, scope_key, expires_at),
                )
                row = await cur.fetchone()
                if row is None:
                    msg = "cache insert failed"
                    raise RuntimeError(msg)
                return int(row[0])

    async def delete_by_id(
        self,
        entry_id: int,
        *,
        model_key: str = "",
        scope_key: str = "",
    ) -> int:
        """Delete a single row when its id matches the model and scope buckets.

        Args:
            entry_id: Primary key of the row to remove.
            model_key: Row filter; must match the row's ``model_key`` column.
            scope_key: Row filter; must match the row's ``scope_key`` column.

        Returns:
            Number of rows deleted (0 or 1).
        """
        tbl = sql.Identifier(self._table_name)
        stmt = sql.SQL(
            "DELETE FROM {tbl} WHERE id = %s AND model_key = %s AND scope_key = %s"
        ).format(tbl=tbl)
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                await cur.execute(stmt, (entry_id, model_key, scope_key))
                return int(cur.rowcount or 0)

    async def similarity_search_top_k(
        self,
        query_embedding: list[float],
        threshold: float,
        limit: int,
        *,
        model_key: str = "",
        scope_key: str = "",
    ) -> list[CacheEntry]:
        """Return up to ``limit`` rows at or above ``threshold`` by cosine similarity.

        The query vector is bound once via a CTE and reused for both the similarity
        filter and ORDER BY, avoiding triple serialization of large embedding payloads
        (e.g. 3072-dim OpenAI models send ~25 KB per query; the CTE reduces this to ~8 KB).

        Uses ``<=>`` (cosine distance); similarity is ``1 - distance``, comparable to
        cosine similarity for normalized vectors.

        Args:
            query_embedding: Query vector of length ``embedding_dim``.
            threshold: Minimum similarity in ``[0.0, 1.0]`` for a hit.
            limit: Maximum number of rows to return among those at or above
                ``threshold``.
            model_key: Only consider rows with this ``model_key`` (empty string is
                the default bucket).
            scope_key: Only consider rows with this ``scope_key`` (empty string is
                the legacy global bucket).

        Returns:
            List of ``CacheEntry`` objects ordered from highest to lowest similarity.
            Rows whose ``expires_at`` is in the past are excluded; rows with a
            ``NULL`` ``expires_at`` are treated as non-expiring.
            The list is empty on miss.

        Raises:
            ValueError: If ``query_embedding`` length does not match ``embedding_dim``.
        """
        if limit <= 0:
            return []
        self._ensure_dim(query_embedding)
        vec = _vector_literal(query_embedding)
        tbl = sql.Identifier(self._table_name)
        stmt = sql.SQL(
            """
            WITH q AS (SELECT %s::vector AS v)
            SELECT t.id, t.query_text, t.response,
                   (1 - (t.query_embedding <=> q.v)) AS similarity
            FROM {tbl} t, q
            WHERE t.query_embedding IS NOT NULL
              AND t.model_key = %s
              AND t.scope_key = %s
              AND (1 - (t.query_embedding <=> q.v)) >= %s
              AND (t.expires_at IS NULL OR t.expires_at > NOW())
            ORDER BY t.query_embedding <=> q.v
            LIMIT %s
            """
        ).format(tbl=tbl)
        async with self._pool.connection() as conn:
            async with conn.cursor() as cur:
                _ = await cur.execute(
                    stmt,
                    (
                        vec,
                        model_key,
                        scope_key,
                        threshold,
                        limit,
                    ),
                )
                rows = await cur.fetchall()
                entries: list[CacheEntry] = []
                for row in rows:
                    rid, qtext, resp, similarity = row
                    sim = float(similarity)
                    if not isinstance(resp, dict):
                        msg = "cache response column must deserialize to a JSON object"
                        raise TypeError(msg)
                    entries.append(
                        CacheEntry(
                            id=int(rid),
                            query_text=str(qtext),
                            response=resp,
                            similarity=sim,
                        )
                    )
                return entries

    async def similarity_search(
        self,
        query_embedding: list[float],
        threshold: float,
        *,
        model_key: str = "",
        scope_key: str = "",
    ) -> CacheEntry | None:
        """Find the nearest row among those meeting the similarity threshold.

        This compatibility wrapper delegates to ``similarity_search_top_k`` with
        ``limit=1``.

        Args:
            query_embedding: Query vector of length ``embedding_dim``.
            threshold: Minimum similarity in ``[0.0, 1.0]`` for a hit.
            model_key: Only consider rows with this ``model_key``.
            scope_key: Only consider rows with this ``scope_key``.

        Returns:
            ``CacheEntry`` for the nearest qualifying neighbor by cosine distance;
            ``None`` when no row meets ``threshold``.

        Raises:
            ValueError: If ``query_embedding`` length does not match ``embedding_dim``.
        """
        entries = await self.similarity_search_top_k(
            query_embedding=query_embedding,
            threshold=threshold,
            limit=1,
            model_key=model_key,
            scope_key=scope_key,
        )
        if not entries:
            return None
        return entries[0]
