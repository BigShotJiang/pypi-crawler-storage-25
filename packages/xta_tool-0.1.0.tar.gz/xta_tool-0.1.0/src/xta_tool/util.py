# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import io
from typing import Any, Callable, Iterator, TypeAlias

Chunks: TypeAlias = Callable[[], Iterator[bytes]]


def merge_dict_to_snake_case(
    dictionary: dict[str, Any], override_dictionary: dict[str, Any]
):
    return merge_dict(
        translate_dict_to_snake_case(dictionary),
        translate_dict_to_snake_case(override_dictionary),
    )


def merge_dict(
    dictionary: dict[str, Any], override_dictionary: dict[str, Any]
) -> dict[str, Any]:
    merged_dict = dict()
    for key, value in dictionary.items():
        if key in override_dictionary:
            merged_dict[key] = _merge_value(value, override_dictionary[key])
        else:
            merged_dict[key] = value
    for key, value in override_dictionary.items():
        if key not in dictionary:
            merged_dict[key] = value
    return merged_dict


def _merge_value(value: Any, override_value: Any) -> Any:
    return (
        merge_dict(value, override_value)
        if isinstance(value, dict) and isinstance(override_value, dict)
        else override_value
    )


def translate_dict_to_snake_case(data) -> Any:
    if isinstance(data, dict):
        translated_dict = dict()
        for key, value in data.items():
            translated_key = _translate_key_to_snake_case(key)
            translated_value = translate_dict_to_snake_case(value)
            translated_dict[translated_key] = translated_value
        return translated_dict
    elif isinstance(data, list):
        return [translate_dict_to_snake_case(item) for item in data]
    return data


def _translate_key_to_snake_case(key: str) -> str:
    with io.StringIO() as output:
        for c in key:
            if not c.isalnum():
                output.write("_")
            elif c.isupper():
                output.write("_" + c.lower())
            else:
                output.write(c)
        return output.getvalue()
