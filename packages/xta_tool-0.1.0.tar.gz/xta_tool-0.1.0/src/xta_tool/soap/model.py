# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later


from click import ClickException
from pydantic import BaseModel, Field

from ..util import Chunks


class AttachmentResource(BaseModel):
    content_id: str
    content: Chunks = Field(exclude=True)


class BadResponseError(ClickException):
    def format_message(self) -> str:
        return "[Bad Response] " + self.message


class SoapFault(BaseModel):
    reason: str
    tag: str
    code: str
    name: str


class SoapError(ClickException):
    def __init__(self, fault: SoapFault) -> None:
        super().__init__(fault.model_dump_json())

    def format_message(self) -> str:
        return "[Soap Fault] " + self.message
