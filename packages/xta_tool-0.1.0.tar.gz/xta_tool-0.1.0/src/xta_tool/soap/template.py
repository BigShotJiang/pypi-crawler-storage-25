# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import xml.etree.ElementTree as ET

import jinja2

from ..util import Chunks

JINJA_ENV = jinja2.Environment(
    loader=jinja2.PackageLoader("xta_tool.soap", "templates"),
    autoescape=jinja2.select_autoescape(),
)


def render_envelope(context: dict) -> Chunks:
    def chunks():
        envelope = ET.canonicalize(
            JINJA_ENV.get_template("envelope.xml").render(context), strip_text=True
        )
        yield envelope.encode()

    return chunks
