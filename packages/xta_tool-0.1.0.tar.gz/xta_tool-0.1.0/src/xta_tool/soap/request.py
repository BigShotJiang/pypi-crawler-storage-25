# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import uuid

import httpx
from pydantic import BaseModel, Field

from . import mtom, template
from .model import AttachmentResource


class XtaSoapRequest(BaseModel):
    url: str
    action: str
    header_template: str = ""
    body_template: str = ""
    message_id: str = Field(default_factory=lambda: f"urn:uuid:{str(uuid.uuid4())}")
    attachments: list[AttachmentResource] = Field(default=[], exclude=True)
    context: dict = Field(default=dict(), exclude=True)

    def prepare(self) -> httpx.Request:
        context = {
            **self.context,
            "soap": self.model_dump(),
        }
        mtom_request = mtom.OutgoingSoapMtomXopMessage(
            action=self.action,
            envelope=template.render_envelope(context),
            attachments=self.attachments,
        )
        return httpx.Request(
            "POST",
            self.url,
            content=mtom.generate_chunks(mtom_request.body),
            headers={
                "SOAPAction": self.action,
                "Accept": "*/*",
                "Content-Type": mtom_request.content_type,
            },
        )
