# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import io
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from functools import cached_property
from typing import Iterator

from . import mtom
from .model import BadResponseError, SoapFault


@dataclass
class IncomingSoapMessage:
    envelope_xml: str
    attachments: Iterator[mtom.ReadablePart]

    @cached_property
    def envelope(self):
        try:
            return ET.fromstring(self.envelope_xml)
        except ET.ParseError as e:
            raise BadResponseError(f"Failed to parse xml! {e}")

    @property
    def action(self):
        return self.text("{*}Header/{*}Action")

    def text(self, xml_path: str) -> str:
        result = self.envelope.findtext(xml_path)
        if not result:
            raise BadResponseError("'{xml_path}' not found in SOAP envelope!")
        return result

    def select(self, xml_path: str) -> ET.Element:
        result = self.envelope.find(xml_path)
        if result is None:
            raise BadResponseError("'{xml_path}' not found in SOAP envelope!")
        return result

    @property
    def fault(self):
        fault = self.envelope.find(".//{http://www.w3.org/2003/05/soap-envelope}Fault")
        if fault is not None:
            detail = fault.find("{*}Detail/*")

            def find_detail_text(xpath: str) -> str:
                return detail.findtext(xpath, default="") if detail is not None else ""

            reason = fault.findtext("{*}Reason/{*}Text", default="")
            return SoapFault(
                reason=reason,
                tag=detail.tag if detail is not None else "",
                name=find_detail_text(".//{}name"),
                code=find_detail_text(".//{}code"),
            )


def receive(
    content_type: str, chunks: Iterator[bytes], max_envelope_size: int
) -> IncomingSoapMessage:
    if content_type.startswith("multipart/related"):
        # Handle SOAP-Message with MTOM-XOP
        attributes = mtom.parse_content_type_attributes(content_type)
        boundary = attributes.boundary
        # Verify boundary
        if not boundary:
            raise BadResponseError("MTOM-XOP content_type must declare a boundary!")
        # Split mtom content into parts
        parts_iter = mtom.receive_parts(chunks, attributes.boundary)
        # Get envelope from first mtom part
        try:
            start_part = next(parts_iter)
        except StopIteration:
            raise BadResponseError(
                "SOAP-Message with MTOM-XOP must contain at least one part!"
            )
        # Verify content ID of start part
        start_content_id = attributes.start_content_id
        if not start_content_id:
            raise BadResponseError(
                'MTOM-XOP content_type must declare a "start" content ID!'
            )
        if start_part.content_id != start_content_id:
            raise BadResponseError(
                "SOAP-Message with MTOM-XOP must start with envelope part!"
            )
        # Read envelope xml
        envelope_xml = _read_envelope_xml(start_part.chunks, max_envelope_size)
    else:
        # Handle SOAP-Message
        envelope_xml = _read_envelope_xml(chunks, max_envelope_size)
        parts_iter = iter([])
    return IncomingSoapMessage(envelope_xml, parts_iter)


def _read_envelope_xml(chunks: Iterator[bytes], max_size: int) -> str:
    with io.BytesIO() as buffer:
        size = 0
        for chunk in chunks:
            size += len(chunk)
            if size > max_size:
                raise BadResponseError(
                    f"Envelope too large! response_envelope_size_limit={max_size}"
                )
            buffer.write(chunk)
        envelope_xml = buffer.getvalue().decode(errors="ignore")
    return envelope_xml
