# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from .model import AttachmentResource, SoapError
from .mtom import ReadablePart, generate_chunks
from .request import XtaSoapRequest
from .response import IncomingSoapMessage, receive

_ = (
    generate_chunks,
    ReadablePart,
    AttachmentResource,
    SoapError,
    XtaSoapRequest,
    IncomingSoapMessage,
    receive,
)
