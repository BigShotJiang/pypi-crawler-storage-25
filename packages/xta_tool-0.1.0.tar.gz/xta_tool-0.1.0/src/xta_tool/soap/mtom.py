# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import io
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Iterable, Iterator

from .model import AttachmentResource, Chunks

CHUNK_SIZE = 256 * 1024
START_PART_CONTENT_ID = "root.message@cxf.apache.org"
START_PART_CONTENT_TYPE = "application/soap+xml"


@dataclass
class BinaryMtomXopPart:
    content_id: str
    content: Chunks
    content_type: str = "application/octet-stream"

    @property
    def header(self):
        yield from (
            line.encode() + b"\r\n"
            for line in [
                f"Content-Type: {self.content_type}",
                "Content-Transfer-Encoding: binary",
                f"Content-ID: <{self.content_id}>",
            ]
        )

    @property
    def body(self):
        yield from self.header
        yield b"\r\n"
        yield from self.content()


@dataclass
class OutgoingSoapMtomXopMessage:
    """
    SOAP envelope with attachments using MTOM-XOP

    See: https://www.w3.org/TR/SOAP-attachments/ and https://www.w3.org/TR/soap12-mtom/

    """

    action: str
    envelope: Chunks
    attachments: list[AttachmentResource] = field(default_factory=lambda: [])
    boundary: str = field(default_factory=lambda: f"uuid:{str(uuid.uuid4())}")

    @property
    def content_type(self) -> str:
        return "; ".join(
            [
                "multipart/related",
                'type="application/xop+xml"',
                f'boundary="{self.boundary}"',
                f'start="<{START_PART_CONTENT_ID}>"',
                f'start-info="{START_PART_CONTENT_TYPE}; action=\\"{self.action}\\""',
            ]
        )

    @property
    def _envelope_content_type(self) -> str:
        return "; ".join(
            [
                "application/xop+xml",
                "charset=UTF-8",
                f'type="{START_PART_CONTENT_TYPE}; action=\\"{self.action}\\""',
            ]
        )

    @property
    def body(self):
        boundary_bytes = self.boundary.encode()
        for part in self.parts:
            yield b"--" + boundary_bytes + b"\r\n"
            yield from part.body
            yield b"\r\n"
        yield b"--" + boundary_bytes + b"--\r\n"

    @property
    def parts(self) -> list[BinaryMtomXopPart]:
        return [
            BinaryMtomXopPart(
                content_id=START_PART_CONTENT_ID,
                content=self.envelope,
                content_type=self._envelope_content_type,
            ),
            *(
                BinaryMtomXopPart(
                    content_id=attachment.content_id, content=attachment.content
                )
                for attachment in self.attachments
            ),
        ]


def generate_chunks(lines: Iterable[bytes], chunk_size=CHUNK_SIZE) -> Iterable[bytes]:
    """Yields equally sized chunks from source lines"""
    buffer = bytearray(b"\x00" * chunk_size)
    buffer_pos = 0
    for line in lines:
        line_pos = 0
        while len(line) != line_pos:
            target_read_size = chunk_size - buffer_pos

            # yield buffer data if full
            if target_read_size == 0:
                yield bytes(buffer)
                buffer_pos = 0
                target_read_size = chunk_size

            # advance line
            line_slice = line[line_pos : line_pos + target_read_size]
            actual_read_size = len(line_slice)
            line_pos += actual_read_size

            # advance buffer
            buffer[buffer_pos : buffer_pos + actual_read_size] = line_slice
            buffer_pos += actual_read_size
    # yield residual data
    if buffer_pos > 0:
        yield bytes(buffer[:buffer_pos])


def _split_parts_at_boundary(
    chunks: Iterable[bytes], boundary: str
) -> Iterator[Iterator[bytes]]:
    start_boundary = b"--" + boundary.encode() + b"\r\n"
    mid_or_end_boundary_prefix = b"\r\n--" + boundary.encode()
    min_segment_size = len(mid_or_end_boundary_prefix) + 2
    chunks_iter = iter(chunks)

    segment = b""

    def fill_segment():
        nonlocal segment
        while len(segment) < min_segment_size:
            segment += next(chunks_iter)

    def next_boundary():
        nonlocal segment
        fill_segment()
        index = segment.find(start_boundary)
        if index != -1:
            segment = segment[index + len(start_boundary) :]
            return True
        return False

    def chunks_of_part():
        nonlocal segment
        fill_segment()
        while len(segment) >= min_segment_size:
            result = segment.find(mid_or_end_boundary_prefix)
            if result == -1:
                # no boundary in segment
                yield segment[: -len(mid_or_end_boundary_prefix)]
                segment = segment[-len(mid_or_end_boundary_prefix) :]
            else:
                # boundary in segment
                yield segment[:result]
                segment = segment[result:]
                return
            fill_segment()
        # unexpected end of stream
        yield segment

    while next_boundary():
        yield chunks_of_part()


@dataclass
class ReadablePart:
    headers: dict[str, str]
    chunks: Iterator[bytes]

    @property
    def content_id(self) -> str:
        return self.headers.get("content-id", "")[1:-1]

    @property
    def content_type(self) -> str:
        return self.headers.get("content-type", "")


def receive_parts(chunks: Iterable[bytes], boundary: str) -> Iterator[ReadablePart]:
    """Yields readable parts separated by a boundary

    Note that advancing to the next part stops the chunk iterator of the previous part.
    """
    for part_chunks in _split_parts_at_boundary(chunks, boundary):
        with _receive_part(part_chunks) as part:
            yield part


@contextmanager
def _receive_part(part_chunks: Iterable[bytes]) -> Iterator[ReadablePart]:
    segment = b""
    part_chunks_iter = iter(part_chunks)

    def next_line_break_in_segment():
        nonlocal segment
        start = 0
        while True:
            result = segment.find(b"\r\n", start)
            start = max(0, len(segment) - 1)
            if result != -1:
                # next new line
                return result
            segment += next(part_chunks_iter)

    def header_lines() -> Iterator[bytes]:
        nonlocal segment
        while index := next_line_break_in_segment():
            # next header line
            yield segment[:index]
            segment = segment[index + 2 :]
        # end of header
        segment = segment[2:]

    headers = dict()
    for line in header_lines():
        header_key, header_value = _parse_header_line(line)
        headers[header_key] = header_value

    def data_chunks() -> Iterator[bytes]:
        nonlocal segment
        if segment:
            yield segment
        segment = b""
        yield from part_chunks_iter

    data_chunks_iter = data_chunks()
    yield ReadablePart(headers=headers, chunks=data_chunks_iter)
    # Finish iteration of part_chunks
    for _ in data_chunks_iter:
        pass


def _parse_header_line(header_line: bytes) -> tuple[str, str]:
    header_keyvalue = header_line.split(b": ", 1)
    if len(header_keyvalue) == 2:
        key, value = header_keyvalue
    else:
        (key,) = header_keyvalue
        value = b""
    return key.decode(errors="ignore").lower(), value.decode(errors="ignore")


@dataclass
class ContentTypeAttributes:
    attributes: dict[str, str]

    @property
    def boundary(self):
        return self.attributes.get("boundary", "")

    @property
    def start_content_id(self):
        return self.attributes.get("start", "<>")[1:-1]


def parse_content_type_attributes(content_type) -> ContentTypeAttributes:
    return ContentTypeAttributes(attributes=_parse_attributes(content_type))


def _parse_attributes(content_type: str) -> dict[str, str]:
    return {key: value for key, value in _iter_attributes(iter(content_type))}


def _iter_attributes(chars: Iterator[str]) -> Iterator[tuple[str, str]]:
    has_next = True
    while has_next:
        key_value, has_next = _parse_attribute(chars)
        yield key_value


def _parse_attribute(chars: Iterator[str]) -> tuple[tuple[str, str], bool]:
    def parse_literal_string():
        literal_string = io.StringIO()
        escaped = False
        for c in chars:
            if escaped:
                escaped = False
                literal_string.write(c)
            elif c == "\\":
                escaped = True
            elif c == '"':
                break
            else:
                literal_string.write(c)
        return literal_string.getvalue()

    def parse_literal():
        literal = io.StringIO()
        stop_char = ""
        for c in chars:
            if c == '"':
                literal.write(parse_literal_string())
            elif c in ";=":
                stop_char = c
                break
            elif not c.isspace():
                literal.write(c)
        return literal.getvalue(), stop_char

    key, stop_char = parse_literal()
    value = ""
    if stop_char == "=":
        value, stop_char = parse_literal()
    return (key.lower(), value), stop_char == ";"
