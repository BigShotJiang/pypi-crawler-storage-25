# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import uuid
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, Field

BASE64_PREFIX = "base64:"


def _generate_content_id():
    return f"{str(uuid.uuid4())}@xoev.de"


def _find(element: Optional[ET.Element], xpath: str) -> Optional[ET.Element]:
    return None if element is None else element.find(xpath)


def _findtext(element: Optional[ET.Element], xpath: str) -> str:
    return "" if element is None else element.findtext(xpath, default="").strip()


def _get_attribute(element: Optional[ET.Element], attribute_name: str) -> str:
    return "" if element is None else element.attrib.get(attribute_name, "").strip()


class XtaFile(BaseModel):
    file_name: str
    content: str
    content_id: str = Field(default_factory=_generate_content_id)
    content_type: str = "application/octet-stream"

    @property
    def safe_file_name(self):
        return (self.file_name.strip() or self.content_id.strip()).replace("/", "_")

    @staticmethod
    def from_xml(file_element: Optional[ET.Element]):
        def attrib(name):
            return _get_attribute(file_element, name)

        return XtaFile(
            content_type=attrib("contentType"),
            file_name=attrib("filename"),
            content_id=_get_attribute(_find(file_element, "{*}Include"), "href")[
                len("cid:") :
            ],
            content=BASE64_PREFIX + _findtext(file_element, "."),
        )


class XtaCode(BaseModel):
    code: str
    list_uri: str = "urn:de:payloadSchema:elementName"
    list_version_id: str = "1.0"

    @staticmethod
    def from_xml(code_element: Optional[ET.Element]):
        def attrib(name):
            return _get_attribute(code_element, name)

        return XtaCode(
            code=_findtext(code_element, "code"),
            list_uri=attrib("listURI"),
            list_version_id=attrib("listVersionID"),
        )


class XtaIdentifier(BaseModel):
    value: str
    category: str = ""
    name: str = ""
    typ: str = "xoev"

    @staticmethod
    def from_xml(identifer_element: Optional[ET.Element]):
        def attrib(name):
            return _get_attribute(identifer_element, name)

        return XtaIdentifier(
            typ=attrib("type"),
            name=attrib("name"),
            category=attrib("category"),
            value=_findtext(identifer_element, "."),
        )


class XtaMetadata(BaseModel):
    author: XtaIdentifier
    reader: XtaIdentifier
    message_id: str
    service: str
    business_scenario: XtaCode
    message_type: XtaCode
    message_type_payload_schema: str
    origin_time: str = ""
    initial_send_time: str = ""
    delivery_time: str = ""
    initial_fetch_time: str = ""

    @staticmethod
    def from_xml(metadata_element: Optional[ET.Element]):
        def find(path):
            return _find(metadata_element, path)

        def findtext(path):
            return _findtext(metadata_element, path)

        return XtaMetadata(
            author=XtaIdentifier.from_xml(
                find("{*}Originators/{*}Author/{*}Identifier")
            ),
            reader=XtaIdentifier.from_xml(
                find("{*}Destinations/{*}Reader/{*}Identifier")
            ),
            message_id=findtext("{*}MsgIdentification/{*}MessageID"),
            service=findtext("{*}Qualifier/{*}Service"),
            business_scenario=XtaCode.from_xml(
                find("{*}Qualifier/{*}BusinessScenario/{*}Defined")
            ),
            message_type=XtaCode.from_xml(find("{*}Qualifier/{*}MessageType")),
            message_type_payload_schema=_get_attribute(
                find("{*}Qualifier/{*}MessageType"), "payloadSchema"
            ),
            origin_time=findtext("{*}DeliveryAttributes/{*}Origin"),
            initial_send_time=findtext("{*}DeliveryAttributes/{*}InitialSend"),
            delivery_time=findtext("{*}DeliveryAttributes/{*}Delivery"),
            initial_fetch_time=findtext("{*}DeliveryAttributes/{*}InitialFetch"),
        )


class XtaMessage(BaseModel):
    metadata: XtaMetadata
    message: XtaFile
    attachments: list[XtaFile] = []
    source_path: Optional[Path] = Field(default=None, exclude=True)

    @property
    def source_directory(self) -> Optional[Path]:
        return self.source_path.parent if self.source_path is not None else None

    @staticmethod
    def from_xml(
        metadata_element: Optional[ET.Element],
        container_element: Optional[ET.Element],
        source_path: Optional[Path] = None,
    ):
        def find_in_container(path):
            return _find(container_element, path)

        def find_all_in_container(path):
            return [] if container_element is None else container_element.findall(path)

        return XtaMessage(
            metadata=XtaMetadata.from_xml(metadata_element),
            message=XtaFile.from_xml(
                find_in_container("{*}ContentContainer/{*}Message")
            ),
            attachments=[
                XtaFile.from_xml(element)
                for element in find_all_in_container(
                    "{*}ContentContainer/{*}Attachment"
                )
            ],
            source_path=source_path,
        )


class XtaTransportReport(BaseModel):
    metadata: XtaMetadata
    server_identity: str = ""
    report_time: str
    status: str

    @staticmethod
    def from_xml(transport_report_element: Optional[ET.Element]):
        def findtext(path: str):
            return _findtext(transport_report_element, path)

        return XtaTransportReport(
            metadata=XtaMetadata.from_xml(
                _find(transport_report_element, "{*}MessageMetaData")
            ),
            report_time=findtext("{*}ReportTime"),
            server_identity=findtext("{*}XTAServerIdentity"),
            status=findtext("{*}MessageStatus/{*}Status"),
        )
