# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import ssl
import tomllib
from contextlib import contextmanager
from pathlib import Path

import httpx
from click import ClickException
from pydantic import BaseModel

from . import util
from .model import XtaIdentifier

DEFAULT_CONFIG_PATH = Path.home() / ".xta" / "config.toml"


class Config(BaseModel):
    base_url: str = "https://localhost:8443"
    management_port_path: str = "/services/XTAService/ManagementPort"
    msg_box_port_path: str = "/services/XTAService/MsgBoxPort"
    send_port_path: str = "/services/XTAService/SendXtaPort"
    verify: bool = True
    cafile: str = "~/.xta/ca.crt"
    certfile: str = "~/.xta/tls.crt"
    keyfile: str = "~/.xta/tls.key"
    self_identifier: XtaIdentifier = XtaIdentifier(value="*")
    user_agent: str = "Apache-CXF/4.0.7"
    verbose: bool = False
    max_save_base64_size: int = 1 << 20  # 1 MiB
    max_response_envelope_size: int = 10 << 20  # 10 MiB
    max_list_items: int = 100

    @property
    def management_port_url(self):
        return self.base_url + self.management_port_path

    @property
    def msg_box_port_url(self):
        return self.base_url + self.msg_box_port_path

    @property
    def send_port_url(self):
        return self.base_url + self.send_port_path


CONFIG: Config | None = None

LOADED_CONFIG_FILES = []


def get_config() -> Config:
    if CONFIG is None:
        raise RuntimeError("init_global_config not called?")
    return CONFIG


def init_global_config(config_path: Path, profiles: str):
    global CONFIG
    LOADED_CONFIG_FILES.clear()
    config_dict = _load_default_toml_config(config_path)
    for profile_str in profiles.split(","):
        profile = profile_str.strip()
        if profile:
            config_dict = util.merge_dict(
                config_dict,
                _load_profile_toml_config(config_path, profile),
            )
    CONFIG = Config(**config_dict)


def _load_default_toml_config(config_path: Path):
    if config_path.is_file():
        return _load_toml_config(config_path)
    elif config_path.absolute() != DEFAULT_CONFIG_PATH.absolute():
        raise ClickException("Config file '{config_path}' does not exist!")
    return dict()


def _load_profile_toml_config(config_path: Path, profile: str):
    profile_config_path = _to_profile_path(config_path, profile)
    if profile_config_path.is_file():
        return _load_toml_config(profile_config_path)
    else:
        raise ClickException(
            f"Profile config file '{profile_config_path}' does not exist!"
        )


def _load_toml_config(config_path: Path):
    LOADED_CONFIG_FILES.append(config_path)
    with open(config_path, "rb") as file:
        return util.translate_dict_to_snake_case(tomllib.load(file))


def _to_profile_path(config_path: Path, profile: str) -> Path:
    name = config_path.name
    suffix = ""
    parts = name.rsplit(".", 1)
    if len(parts) == 2:
        name, extension = parts
        suffix = f".{extension}"
    return config_path.parent / f"{name}-{profile}{suffix}"


@contextmanager
def create_http_client():
    cfg = get_config()
    ctx = ssl.create_default_context(
        cafile=Path(cfg.cafile).expanduser() if cfg.cafile else None
    )
    ctx.verify_mode = (
        ssl.VerifyMode.CERT_REQUIRED if cfg.verify else ssl.VerifyMode.CERT_NONE
    )
    if cfg.certfile:
        ctx.load_cert_chain(
            certfile=Path(cfg.certfile).expanduser(),
            keyfile=Path(cfg.keyfile).expanduser() if cfg.keyfile else None,
        )
    with httpx.Client(verify=ctx) as client:
        yield client
