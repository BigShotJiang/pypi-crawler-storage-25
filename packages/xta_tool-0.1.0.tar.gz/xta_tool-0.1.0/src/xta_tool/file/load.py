# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import base64
from pathlib import Path
from typing import Optional

import yaml
from click import ClickException
from pydantic import ValidationError

from ..model import BASE64_PREFIX, XtaMessage
from ..util import (
    Chunks,
    merge_dict,
    translate_dict_to_snake_case,
)
from . import template
from .zip import create_zip_content


def load_xta_file_content(
    file_content: str, source_directory: Optional[Path], context: dict
) -> Chunks:
    if file_content.startswith(BASE64_PREFIX):
        return lambda: iter([base64.b64decode(file_content[len(BASE64_PREFIX) :])])
    else:
        if source_directory is None or not source_directory.is_dir():
            raise ClickException(
                f"Source directory '{source_directory}' of '{file_content}' does not exist!"
            )
        content_path = source_directory / file_content
        if content_path.is_dir():
            return lambda: create_zip_content(content_path, context)
        if not content_path.is_file():
            raise ClickException(f"Content file '{content_path}' does not exist!")

        return lambda: template.load_file_content(content_path, context)


def load_xta_message(message_id: str, message_path: Path) -> XtaMessage:
    message_file_path = _get_yaml_message_file_path(message_path)
    message_dict = _load_yaml_message_file(message_file_path)
    try:
        return XtaMessage(
            **merge_dict(
                message_dict,
                dict(
                    metadata=dict(message_id=message_id), source_path=message_file_path
                ),
            ),
        )
    except ValidationError as e:
        raise ClickException(f"{message_path} invalid!\n{e}")


def _get_yaml_message_file_path(path: Path) -> Path:
    return path / "xta-message.yaml" if path.is_dir() else path


def _load_yaml_message_file(file_path: Path) -> dict:
    with file_path.open() as file:
        try:
            message = yaml.safe_load(file)
        except yaml.YAMLError as e:
            raise ClickException(f"yaml message '{file_path}' invalid! {e}")
        if not isinstance(message, dict):
            raise ClickException(
                f"yaml message '{file_path}' must contain key-value pairs!"
            )
        return translate_dict_to_snake_case(message)
