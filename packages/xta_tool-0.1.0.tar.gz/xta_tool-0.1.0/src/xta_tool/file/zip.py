# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import atexit
import io
import zipfile
from pathlib import Path
from tempfile import SpooledTemporaryFile
from typing import Iterator

from . import template

ZIP_BUFFER_SIZE = 1 << 20  # 1 MiB


def create_zip_content(source_directory: Path, context: dict) -> Iterator[bytes]:
    with SpooledTemporaryFile(max_size=ZIP_BUFFER_SIZE) as file:
        with zipfile.ZipFile(file, "w") as archive:
            _write_zip_content(archive, source_directory, context)
        file.seek(0)

        def close():
            file.close()

        atexit.register(close)
        while chunk := file.read(io.DEFAULT_BUFFER_SIZE):
            yield chunk
        atexit.unregister(close)


def _write_zip_content(archive: zipfile.ZipFile, source_directory: Path, context: dict):
    for entry_path in source_directory.glob("**/*"):
        if entry_path.is_file():
            _write_zip_entry(archive, entry_path, source_directory, context)


def _write_zip_entry(
    archive: zipfile.ZipFile, entry_path: Path, source_directory: Path, context: dict
):
    entry_name = str(
        template.remove_jinja_extension(entry_path).relative_to(source_directory)
    )
    with archive.open(entry_name, "w") as entry:
        for chunk in template.load_file_content(entry_path, context):
            entry.write(chunk)
