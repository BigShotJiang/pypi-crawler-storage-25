# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import base64
import io
from pathlib import Path
from typing import Callable, Iterator

from click import ClickException

from ..model import BASE64_PREFIX, XtaFile, XtaMessage
from ..soap import mtom


def save_xta_message(
    xta_message: XtaMessage,
    soap_attachments: Iterator[mtom.ReadablePart],
    max_base64_size: int,
) -> XtaMessage:
    output_directory = (
        xta_message.source_path.parent if xta_message.source_path else None
    )

    def download_content(xta_file: XtaFile, chunks: Iterator[bytes]) -> str:
        return (
            _download_to_output_directory(xta_file, chunks, output_directory)
            if output_directory is not None
            else _download_to_base64_string(xta_file, chunks, max_base64_size)
        )

    return _with_downloaded_file_content(
        xta_message, soap_attachments, download_content
    )


def _with_downloaded_file_content(
    xta_message: XtaMessage,
    soap_attachments: Iterator[mtom.ReadablePart],
    download_content: Callable[[XtaFile, Iterator[bytes]], str],
) -> XtaMessage:
    xta_files = {
        file.content_id: file
        for file in [xta_message.message] + xta_message.attachments
    }
    for soap_attachment in soap_attachments:
        xta_file = xta_files.get(soap_attachment.content_id)
        if xta_file:
            xta_files[soap_attachment.content_id] = xta_file.model_copy(
                update=(
                    dict(content=download_content(xta_file, soap_attachment.chunks))
                )
            )
    return xta_message.model_copy(
        update=dict(
            message=xta_files[xta_message.message.content_id],
            attachments=[
                xta_files[xta_file.content_id] for xta_file in xta_message.attachments
            ],
        )
    )


def _download_to_output_directory(
    xta_file: XtaFile, chunks: Iterator[bytes], output_directory: Path
) -> str:
    output_path = output_directory / xta_file.safe_file_name
    with open(output_path, "wb") as file:
        for chunk in chunks:
            file.write(chunk)
    return str(output_path.relative_to(output_directory))


def _download_to_base64_string(
    xta_file: XtaFile, chunks: Iterator[bytes], max_size: int
) -> str:
    base64_str = io.StringIO()

    def write_as_base64(chunk):
        base64_str.write(base64.b64encode(chunk).decode())

    size = 0
    chunk_residual = b""
    for new_chunk in chunks:
        size += len(new_chunk)
        if size > max_size:
            raise ClickException(
                f"Received file '{xta_file.file_name}' is too large! download_base64_size_limit={max_size}"
            )
        chunk = chunk_residual + new_chunk
        base64_encodable_size = 3 * (len(chunk) // 3)
        chunk_residual = chunk[base64_encodable_size:]
        write_as_base64(chunk[:base64_encodable_size])
    write_as_base64(chunk_residual)
    return BASE64_PREFIX + base64_str.getvalue()
