# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import io
from pathlib import Path
from typing import Iterator

import jinja2
from click import ClickException

ENV = jinja2.Environment(loader=jinja2.FileSystemLoader("/"))

JINJA_FILE_NAME_EXTENSION = ".jinja"


def remove_jinja_extension(content_path: Path) -> Path:
    return content_path.with_name(
        content_path.name.removesuffix(JINJA_FILE_NAME_EXTENSION)
    )


def load_file_content(content_path: Path, context: dict) -> Iterator[bytes]:
    if content_path.name.endswith(JINJA_FILE_NAME_EXTENSION):
        return _render_template_content(content_path, context)
    return _load_direct_file_contents(content_path)


def _render_template_content(template_path: Path, context: dict) -> Iterator[bytes]:
    try:
        for part in ENV.get_template(str(template_path.absolute())).stream(**context):
            yield part.encode()
    except jinja2.TemplateError as e:
        raise ClickException(f"[Template {template_path}] {e}")


def _load_direct_file_contents(path: Path) -> Iterator[bytes]:
    with open(path, "rb") as file:
        while chunk := file.read(io.DEFAULT_BUFFER_SIZE):
            yield chunk
