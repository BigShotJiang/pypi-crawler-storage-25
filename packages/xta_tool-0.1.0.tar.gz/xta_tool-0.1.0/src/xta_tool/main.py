# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

import sys
from pathlib import Path

import click
import yaml

from . import client as xta
from . import config as cfg
from . import file


@click.group()
@click.option(
    "-c",
    "--config",
    envvar="XTA_TOOL_CONFIG",
    default=cfg.DEFAULT_CONFIG_PATH,
    type=click.Path(exists=False, file_okay=True, dir_okay=False),
    help="xta-tool configuration file.",
)
@click.option(
    "-p",
    "--profile",
    envvar="XTA_TOOL_PROFILE",
    default="",
    help="Profile to override base configuration.",
)
def main(config, profile):
    """Send and receive xta messages."""
    config = Path(config)
    cfg.init_global_config(config, profile)


@main.command()
def new():
    """Get a new message id from the server."""
    with xta.create_xta_client() as client:
        click.echo(client.new())


@main.command()
@click.argument("message_id", metavar="ID")
@click.argument("path", type=click.Path(exists=True, file_okay=True, dir_okay=True))
def send(message_id, path):
    """Send a message with ID from PATH.

    ID is the identifier of the message, or ID is 'new' to use a new message id
    PATH of a source yaml file describing the message, or PATH is a directory containing such a file named 'xta-message.yaml'
    """
    path = Path(path).expanduser()
    with xta.create_xta_client() as client:
        if message_id == "new":
            message_id = client.new()
        client.send(file.load_xta_message(message_id, path))
    click.echo(message_id)


@main.command()
@click.argument("message_id", metavar="ID")
@click.argument("path", type=click.Path(exists=False, file_okay=True, dir_okay=True))
def get(message_id, path):
    """Get a message by ID and save it to PATH.

    ID is the identifier of the message
    PATH of the target yaml file to save the received message to, or the directory to save `xta-message.yaml` and extra files to
    """
    path = Path(path).expanduser()
    with xta.create_xta_client(
        output_directory=path if path.is_dir() else None
    ) as client:
        message = client.get(message_id)
        with open(message.source_path or path, "w") as file:
            yaml.safe_dump(message.model_dump(exclude_defaults=True), file)
    click.echo(message_id)


@main.command()
def ls():
    """List open messages by id."""
    with xta.create_xta_client() as client:
        for metadata in client.ls():
            click.echo(metadata.message_id)


@main.command()
@click.argument("message_id", metavar="ID")
def inspect(message_id):
    """Inspect a message by ID, showing its transport report.

    ID is the identifier of the message.
    """
    with xta.create_xta_client() as client:
        report = client.inspect(message_id)
    yaml.dump(report.model_dump(), sys.stdout)


@main.command()
@click.argument("message_id", metavar="ID")
def close(message_id):
    """Close a message by its ID to acknowledge that it has been read.

    ID is the identifier of the message.
    """
    with xta.create_xta_client() as client:
        client.close(message_id)
    click.echo(message_id)


@main.command()
def config():
    """Show active configuration values"""
    for config_path in cfg.LOADED_CONFIG_FILES:
        click.echo(f"# {config_path}")
    yaml.dump(cfg.get_config().model_dump(), sys.stdout)
