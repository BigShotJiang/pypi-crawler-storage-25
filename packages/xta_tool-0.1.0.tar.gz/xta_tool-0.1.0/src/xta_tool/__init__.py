# SPDX-FileCopyrightText: 2026 Jan Zickermann <janz@noreply.codeberg.org>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

from .client import XtaClient
from .config import Config, get_config, init_global_config
from .main import main as cli
from .model import (
    BASE64_PREFIX,
    XtaCode,
    XtaFile,
    XtaIdentifier,
    XtaMessage,
    XtaMetadata,
    XtaTransportReport,
)

_ = (
    get_config,
    Config,
    init_global_config,
    XtaClient,
    XtaFile,
    XtaCode,
    XtaIdentifier,
    XtaMetadata,
    XtaMessage,
    XtaTransportReport,
    BASE64_PREFIX,
    cli,
)
