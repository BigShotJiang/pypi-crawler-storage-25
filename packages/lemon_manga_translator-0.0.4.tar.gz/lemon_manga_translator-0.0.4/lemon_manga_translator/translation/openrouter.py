from __future__ import annotations

import base64
import io
import json
import logging
import re
import time
from dataclasses import dataclass
from typing import Sequence

import httpx
from PIL import Image, ImageDraw, ImageFont

from lemon_manga_translator.types import TextBlock

DEFAULT_VISION_MAX_LONG_EDGE = 1024

logger = logging.getLogger(__name__)


class OpenRouterError(RuntimeError):
    pass


@dataclass
class VisionBlockResult:
    block_index: int
    is_sfx: bool
    ko_translation: str | None


SYSTEM_PROMPT = """\
You process numbered text regions on a manga page in a single pass:
classify as SFX/dialogue and translate dialogue into Korean.

The image has numbered rectangles drawn on it. Each rectangle encloses
some Japanese text. For EACH number, output two things:

1. is_sfx (bool)
   - true  = sound effect / onomatopoeia / 의성어 / 의태어
             (stylized art-like text that should stay in the original,
              e.g. ガタガタ, ドキドキ, バン, ドーン).
             Translator should NOT touch it.
   - false = dialogue / narration / sign text a translator would handle.

2. ko_translation (string | null)
   - If is_sfx=false: a natural Korean translation matching the tone of
     the panel (존댓말/반말 preserved, 만화 말풍선 특유의 줄임/감탄은
     자연스럽게). Read the Japanese text from the image directly.
   - If is_sfx=true: null (do not translate SFX).

Output: pure JSON array, no markdown, no explanation. One element per
numbered rectangle, in numeric order:

[
  {"id": <int>, "is_sfx": <bool>, "ko_translation": <string|null>}
]
"""


_LABEL_PAD = 4
_BBOX_COLOR = (255, 0, 0)
_LABEL_BG = (255, 255, 0)
_LABEL_FG = (0, 0, 0)
_LABEL_BORDER = (0, 0, 0)
class PageAnnotator:
    def __init__(
        self,
        max_long_edge: int = DEFAULT_VISION_MAX_LONG_EDGE,
    ):
        self.max_long_edge = max_long_edge

    def annotate(
        self, page_image: Image.Image, blocks: Sequence[TextBlock]
    ) -> Image.Image:
        resized, scaled_bboxes = self._resize_with_blocks(
            page_image.convert("RGB"), blocks
        )
        long_edge = max(resized.size)
        font_size = max(12, int(round(long_edge * 0.018)))
        line_width = max(1, int(round(long_edge / 500)))
        return self._draw_numbered_overlay(
            resized, scaled_bboxes, font_size=font_size, line_width=line_width
        )

    def _resize_with_blocks(
        self, image: Image.Image, blocks: Sequence[TextBlock]
    ) -> tuple[Image.Image, list[tuple[int, int, int, int]]]:
        W, H = image.size
        bboxes = [
            (int(b.bbox.x), int(b.bbox.y), int(b.bbox.x1), int(b.bbox.y1))
            for b in blocks
        ]
        long_edge = max(W, H)
        if long_edge <= self.max_long_edge:
            return image, bboxes
        scale = self.max_long_edge / long_edge
        new_w = max(1, int(round(W * scale)))
        new_h = max(1, int(round(H * scale)))
        resized = image.resize((new_w, new_h), Image.LANCZOS)
        scaled = [
            (
                int(round(x0 * scale)),
                int(round(y0 * scale)),
                int(round(x1 * scale)),
                int(round(y1 * scale)),
            )
            for (x0, y0, x1, y1) in bboxes
        ]
        return resized, scaled

    def _load_font(self, font_size: int) -> ImageFont.ImageFont:
        return ImageFont.load_default(font_size)

    def _draw_numbered_overlay(
        self,
        image: Image.Image,
        bboxes: Sequence[tuple[int, int, int, int]],
        font_size: int,
        line_width: int,
    ) -> Image.Image:
        out = image.convert("RGB").copy()
        draw = ImageDraw.Draw(out)
        font = self._load_font(font_size)
        W, H = out.size
        for idx, (x0, y0, x1, y1) in enumerate(bboxes):
            draw.rectangle([x0, y0, x1, y1], outline=_BBOX_COLOR, width=line_width)
            self._draw_label(draw, str(idx), x0, y0, x1, y1, W, H, font)
        return out

    @staticmethod
    def _draw_label(
        draw: ImageDraw.ImageDraw,
        label: str,
        x0: int,
        y0: int,
        x1: int,
        y1: int,
        W: int,
        H: int,
        font: ImageFont.ImageFont,
    ) -> None:
        text_bbox = draw.textbbox((0, 0), label, font=font)
        tw = text_bbox[2] - text_bbox[0]
        th = text_bbox[3] - text_bbox[1]
        label_w = tw + 2 * _LABEL_PAD
        label_h = th + 2 * _LABEL_PAD
        lx0 = max(0, x0 - 2)
        ly0 = y0 - label_h - 2
        if ly0 < 0:
            ly0 = y1 + 2
            if ly0 + label_h > H:
                ly0 = y0 + 2
        lx1 = min(W, lx0 + label_w)
        ly1 = ly0 + label_h
        draw.rectangle(
            [lx0, ly0, lx1, ly1], fill=_LABEL_BG, outline=_LABEL_BORDER, width=1
        )
        draw.text((lx0 + _LABEL_PAD, ly0 + _LABEL_PAD), label, fill=_LABEL_FG, font=font)


def _encode_png_b64(image: Image.Image) -> str:
    buf = io.BytesIO()
    image.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _parse_json_array(content: str) -> list[dict]:
    s = (content or "").strip()
    if not s:
        raise OpenRouterError("LLM returned empty content")
    fence = re.match(r"^```(?:json)?\s*(.*?)\s*```$", s, re.DOTALL)
    if fence:
        s = fence.group(1).strip()
    try:
        parsed = json.loads(s)
    except json.JSONDecodeError:
        match = re.search(r"\[[\s\S]*\]", s)
        if not match:
            raise OpenRouterError(f"LLM did not return a JSON array: {content[:300]}")
        parsed = json.loads(match.group(0))
    if not isinstance(parsed, list):
        raise OpenRouterError(f"Expected JSON array, got {type(parsed).__name__}")
    return parsed


class VisionLlmClient:
    def __init__(
        self,
        api_key: str,
        model: str,
        base_url: str = "https://openrouter.ai/api/v1",
        max_long_edge: int = DEFAULT_VISION_MAX_LONG_EDGE,
        max_attempts: int = 5,
        timeout: float = 180.0,
        annotator: PageAnnotator | None = None,
    ):
        if not api_key:
            raise OpenRouterError("OPENROUTER_API_KEY is empty")
        if not model:
            raise OpenRouterError("OPENROUTER_MODEL is empty")
        self.api_key = api_key
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.max_attempts = max_attempts
        self.timeout = timeout
        self.annotator = annotator or PageAnnotator(max_long_edge=max_long_edge)
        self.last_usage: dict = {}
        self.last_attempts: int = 0
        self.last_annotated: Image.Image | None = None

    def run_page(
        self, page_image: Image.Image, blocks: Sequence[TextBlock]
    ) -> list[VisionBlockResult]:
        # invariant: blocks[i]는 LLM 페이로드에서 id=i로 참조되고, 결과도 같은 순서로 반환
        self.last_usage = {}
        self.last_attempts = 0
        self.last_annotated = None
        if not blocks:
            return []

        annotated = self.annotator.annotate(page_image, blocks)
        self.last_annotated = annotated
        b64 = _encode_png_b64(annotated)
        block_ids = list(range(len(blocks)))
        id_list = ", ".join(str(i) for i in block_ids)
        user_text = (
            f"The image has {len(block_ids)} numbered rectangles. The IDs are: "
            f"{id_list}. For each id, output is_sfx and ko_translation. "
            f"Return exactly {len(block_ids)} elements in the JSON array, one "
            f"per id."
        )

        parsed = self._call_with_retry(b64, user_text, len(block_ids))
        return self._build_results(parsed, block_ids)

    def _call_with_retry(
        self, b64: str, user_text: str, expected: int
    ) -> list[dict]:
        last_err: Exception | None = None
        for attempt in range(1, self.max_attempts + 1):
            self.last_attempts = attempt
            try:
                return self._call_once(b64, user_text, expected)
            except Exception as e:
                last_err = e
                if attempt < self.max_attempts:
                    time.sleep(2 ** (attempt - 1))
        raise OpenRouterError(
            f"vision call failed after {self.max_attempts} attempts: {last_err}"
        ) from last_err

    @staticmethod
    def _build_results(
        parsed: list[dict], block_ids: list[int]
    ) -> list[VisionBlockResult]:
        by_id = {int(item.get("id", -1)): item for item in parsed}
        results: list[VisionBlockResult] = []
        for i in block_ids:
            item = by_id.get(i, {})
            is_sfx = bool(item.get("is_sfx", False))
            ko_raw = item.get("ko_translation")
            ko = ko_raw.strip() if isinstance(ko_raw, str) else None
            results.append(
                VisionBlockResult(
                    block_index=i,
                    is_sfx=is_sfx,
                    ko_translation=(ko or None),
                )
            )
        return results

    def _call_once(self, b64: str, user_text: str, expected: int) -> list[dict]:
        response = httpx.post(
            f"{self.base_url}/chat/completions",
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": self.model,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": user_text},
                            {
                                "type": "image_url",
                                "image_url": {"url": f"data:image/png;base64,{b64}"},
                            },
                        ],
                    },
                ],
                "temperature": 0,
            },
            timeout=self.timeout,
        )
        if response.status_code != 200:
            raise OpenRouterError(
                f"OpenRouter returned {response.status_code}: {response.text[:500]}"
            )
        body = response.json()
        if "error" in body:
            raise OpenRouterError(f"OpenRouter error: {body['error']}")
        try:
            content = body["choices"][0]["message"]["content"]
        except (KeyError, IndexError) as e:
            raise OpenRouterError(f"Unexpected response shape: {body}") from e
        self.last_usage = body.get("usage") or {}
        parsed = _parse_json_array(content)
        if len(parsed) != expected:
            raise OpenRouterError(
                f"block count mismatch: expected {expected}, got {len(parsed)}"
            )
        return parsed
