from pydantic import BaseModel, Field
from typing import List


    
class SummaryEvaluationResult(BaseModel):
    true_positives: int = Field(
        description=(
            "summary contains key information. Number of key topics included"
        )
    )
    false_positives: int = Field(
        description=(
            "summary contains irrelevant additional information. Number of irrelevant information"
        )
    )
    true_negatives: int = Field(
        description=(
            "summary skips trivial information correctly skipped: number of trivial information correctly skipped"
        )
    )
    false_negatives: int = Field(
        description=(
            "summary skips key information: number of concorrectly skipped content"
        )
    )
    reasoning: str = Field(
        description="reasoning for each number")


class SummaryResult(BaseModel):
    """Represents a summarization response from an LLM."""
    summary: str = Field(
        description="Generated summary for the provided text"
    )


class EmbeddingResult(BaseModel):
    embedding: List[float] = Field(
        description=(
            "Encoded embedding of text"
        )
    )