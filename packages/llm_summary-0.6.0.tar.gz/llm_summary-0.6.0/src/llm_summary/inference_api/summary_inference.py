from llm_summary.core.dto import SummaryResult
from llm_summary.inference_api.mlflow_config import MlFlowConfig
from llm_summary.inference_api.prompts import (
    default_summarization_system_prompt,
    default_summarization_user_prompt,
)
from llm_summary.inference_api.llm_config import LlmConfig
from llm_summary.inference_api.strategies.strategy_factory import create_inference_strategy_local
import logging
import mlflow
from mlflow import genai
import time



class SummaryInferenceProvider:
    """Wrapper around a local inference strategy to generate text summaries."""

    model: str
    mlflow_config: MlFlowConfig

    def __init__(self, **kwargs):
        self.model = kwargs.get('model', "llama3.2")
        
        self.llm_config =LlmConfig(
            temperature=0.1,        # lower randomness → more factual summaries
            top_p=0.95,              # allow reasonable token pool
            typical_p=1.0,          # disable typical sampling (not needed)
            top_k=20,               # moderate constraint
            max_tokens=256,         # depends on summary length you want
            repeat_penalty=1.1,     # avoid loops without harming fluency
            frequency_penalty=0.0,  # repetition control usually unnecessary
            presence_penalty=0.0,   # do not force new topics in summaries
            num_thread=16,          # hardware dependent (fine if CPU supports it)
)

        self.mlflow_config = kwargs.get('mlflow_config', MlFlowConfig())
        mlflow.set_tracking_uri(self.mlflow_config.tracking_host)

        self.inference_strategy = create_inference_strategy_local(
            name=kwargs.get('strategy', "ollama"),
            llm_config=self.llm_config,
        )

    def inference(self, prompt: str, system: str) -> SummaryResult:
        return self.inference_strategy.inference(
            prompt=prompt,
            system=system,
            model=self.model,
            json_response_type=SummaryResult,
        )

    def generate_prompt(self, text) -> str:
        if self.mlflow_config.mlflow_user_prompt_id is None:
            return default_summarization_user_prompt(text=text)
        return str(
            genai.load_prompt(f"prompts:/{self.mlflow_config.mlflow_user_prompt_id}").format(text=text)
        )

    def generate_system_prompt(self) -> str:
        if self.mlflow_config.mlflow_system_prompt_id is None:
            # call function to build default system prompt
            return default_summarization_system_prompt
        return str(genai.load_prompt(f"prompts:/{self.mlflow_config.mlflow_system_prompt_id}").format())

    def summarize(self, text: str) -> SummaryResult:
        cleaned = text
        start_time = time.time()
        
        prompt = self.generate_prompt(cleaned)
        system_prompt = self.generate_system_prompt()
        result = self.inference(prompt=prompt, system=system_prompt)
        
        duration = time.time() - start_time
        logging.info("Summary inference completed in %.2f seconds", duration)
        return result
        

    

    
