from llm_summary.core.dto import SummaryEvaluationResult
from llm_summary.inference_api.mlflow_config import MlFlowConfig
from llm_summary.inference_api.llm_config import LlmConfig
from llm_summary.inference_api.strategies.strategy_factory import create_inference_strategy_local
import logging
import mlflow
from mlflow import genai
import time



class LlmAsJudgeProvider:
    """Wrapper around a local inference strategy to evaluate summaries using LLM-as-judge."""

    model: str
    mlflow_config: MlFlowConfig

    def __init__(self, **kwargs):
        self.model = kwargs.get('model', "llama3.2")
        
        self.llm_config = LlmConfig(
            temperature=0.0,        # deterministic outputs → consistent evaluations
            top_p=1.0,              # disable nucleus filtering when temperature=0
            typical_p=1.0,          # disable typical sampling
            top_k=0,                # disable top-k restriction
            max_tokens=512,         # enough for reasoning + scoring
            repeat_penalty=1.05,    # slight guard against loops
            frequency_penalty=0.0,  # repetition control unnecessary for judging
            presence_penalty=0.0,   # do not bias toward new topics
            num_thread=16,          # hardware dependent
        )

        self.mlflow_config = kwargs.get('mlflow_config', MlFlowConfig())
        mlflow.set_tracking_uri(self.mlflow_config.tracking_host)

        self.inference_strategy = create_inference_strategy_local(
            name=kwargs.get('strategy', "ollama"),
            llm_config=self.llm_config,
        )

    def inference(self, prompt: str, system: str) -> SummaryEvaluationResult:
        return self.inference_strategy.inference(
            prompt=prompt,
            system=system,
            model=self.model,
            json_response_type=SummaryEvaluationResult,
        )

    def generate_judge_prompt(self, originaltext: str, summary: str) -> str:
        """Generate a prompt for LLM-as-judge evaluation."""
        if self.mlflow_config.mlflow_user_prompt_id is None:
            return (
                f"Original Text:\n{originaltext}\n\n"
                f"Generated Summary:\n{summary}\n\n"
                f"Evaluate the summary based on true positives (key information included), "
                f"false positives (irrelevant information), true negatives (trivial information correctly skipped), "
                f"and false negatives (key information incorrectly skipped). Provide your evaluation."
            )
        return str(
            genai.load_prompt(f"prompts:/{self.mlflow_config.mlflow_user_prompt_id}").format(
                originaltext=originaltext, summary=summary
            )
        )

    def generate_system_prompt(self) -> str:
        """Generate system prompt for evaluation."""
        if self.mlflow_config.mlflow_system_prompt_id is None:
            return (
                "You are an expert evaluator of text summaries. "
                "Evaluate the provided summary against the original text and determine: "
                "1. True positives: key information included in the summary "
                "2. False positives: irrelevant or incorrect information in the summary "
                "3. True negatives: trivial information correctly omitted "
                "4. False negatives: important information missing from the summary "
                "Provide your evaluation in a structured format with reasoning."
            )
        return str(genai.load_prompt(f"prompts:/{self.mlflow_config.mlflow_system_prompt_id}").format())

    def judge(self, originaltext: str, summary: str) -> SummaryEvaluationResult:
        """Evaluate a summary against the original text using LLM-as-judge."""
        start_time = time.time()
        
        prompt = self.generate_judge_prompt(originaltext, summary)
        system_prompt = self.generate_system_prompt()
        result = self.inference(prompt=prompt, system=system_prompt)
        
        duration = time.time() - start_time
        logging.info("LLM-as-judge evaluation completed in %.2f seconds", duration)
        return result
        

    

    
