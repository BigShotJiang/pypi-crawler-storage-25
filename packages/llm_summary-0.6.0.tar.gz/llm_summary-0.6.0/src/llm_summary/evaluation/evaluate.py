"""
Evaluate summarization models against a reference dataset.

CSV format (no header assumed by default):
- column 0: original text
- column 1: reference summary

This script will:
- call the summarization API for each text
- compute simple overlap precision/recall/F1 between predicted and reference summaries
- log metrics, params and a predictions CSV artifact to MLflow
"""

from typing import Iterable, List, Set, Dict, Any, Optional

import os
import logging
import time

import pandas as pd
from llm_summary.inference_api.mlflow_config import MlFlowConfig
import mlflow
from llm_summary.inference_api.summary_inference import SummaryInferenceProvider
from llm_summary.core.dto import SummaryResult
from llm_summary.inference_api.llm_as_judge_inference import LlmAsJudgeProvider

from llm_summary.evaluation.metrics import compute_precision_recall_f1


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


def evaluate_dataset(
    csv_path: str,
    model_name: str,
    strategy: str,
    system_prompt_id: str,
    user_prompt_id: str,
    llm_judge: LlmAsJudgeProvider,
    mlflow_experiment: Optional[str] = None,
) -> Dict[str, Any]:
    # MLflow logging
    mlflow.set_tracking_uri("http://localhost:5050")
    mlflow_exp = mlflow_experiment or model_name
    mlflow.set_experiment(mlflow_exp)
    with mlflow.start_run(run_name=f"{model_name}-cpu-default-prompt"):
        summarizer = SummaryInferenceProvider(
            model=model_name,
            strategy=strategy,
            mlflow_config=MlFlowConfig(
                mlflow_system_prompt_id=system_prompt_id,
                mlflow_user_prompt_id=user_prompt_id,
            ),
            ollama_host="http://localhost:11434",
        )
        text_col = 0
        summary_col = 1
        
        df = pd.read_csv(csv_path, dtype=str).fillna("")
       

        texts = df.iloc[:, text_col].astype(str).tolist()
        references = df.iloc[:, summary_col].astype(str).tolist()

        total_tp = total_fp = total_fn = 0
        rows = []

        for idx, (text, ref) in enumerate(zip(texts, references)):
            start_time = time.time()
            try:
                result: SummaryResult = summarizer.summarize(text=text)
                pred_summary = result.summary
                evaluation_summary = llm_judge.judge(text, pred_summary)
                
            except Exception as e:
                logger.exception("Predictor failed on text index %s: %s", idx, e)
                pred_summary = ""
                
                continue
            latency_ms = (time.time() - start_time) * 1000
            mlflow.log_metric("latency_ms", latency_ms, step=idx)
            
            total_tp += (evaluation_summary.true_positives + evaluation_summary.true_negatives)
            total_fp += evaluation_summary.false_positives
            total_fn += evaluation_summary.false_negatives

            size_ratio = len(pred_summary.split()) / len(text.split()) if text.strip() else 0.0
            rows.append({
                "index": idx,
                "text": text,
                "reference": ref,
                "predicted": pred_summary,
                "tp": evaluation_summary.true_positives,
                "fp": evaluation_summary.false_positives,
                "fn": evaluation_summary.false_negatives,
                "tn": evaluation_summary.true_negatives,
                "size_ratio": size_ratio,
            })

        precision, recall, f1 = compute_precision_recall_f1(total_tp, total_fp, total_fn)

        metrics = {
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "tp": total_tp,
            "fp": total_fp,
            "fn": total_fn,
            "n_samples": len(rows),
        }

        preds_df = pd.DataFrame(rows)

        # log params
        mlflow.log_param("dataset", csv_path)
        mlflow.log_param("model_name", f"{model_name}_cpu")
        mlflow.log_param("n_samples", len(rows))
        # log metrics
        mlflow.log_metric("precision", precision)
        mlflow.log_metric("recall", recall)
        mlflow.log_metric("f1", f1)
        mlflow.log_metric("tp", total_tp)
        mlflow.log_metric("fp", total_fp)
        mlflow.log_metric("fn", total_fn)
        

        filename = f"predictions_{int(time.time())}.csv"
        preds_df.to_csv(filename, index=False)
        mlflow.log_artifact(os.path.abspath(filename), artifact_path="artifacts")

        logger.info("Evaluation complete. precision=%.4f recall=%.4f f1=%.4f", precision, recall, f1)
        logger.info("Predictions CSV written to %s and logged to MLflow experiment '%s'", filename, mlflow_exp)

        return {"metrics": metrics, "predictions_csv": filename}
