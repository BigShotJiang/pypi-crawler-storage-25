"""
Usage (example):
python main_judge.py --csv example_data.csv --model-name llama3.2 --mlflow-experiment summary_judge --mlflow-system-prompt-id SUMMARY_JUDGE_System/1 --mlflow-user-prompt-id SUMMARY_JUDGE_User/1
"""
import argparse
import sys
import logging

from llm_summary.evaluation.evaluate_judge import evaluate_dataset


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

def _parse_args():
    p = argparse.ArgumentParser(description="Evaluate text summarization models")
    p.add_argument("--csv", required=True, help="Path to CSV file (text, reference summary). No header expected by default.")
    p.add_argument("--model-name", required=True, help="Model name (also used as MLflow run name / experiment)")
    p.add_argument("--strategy", default="ollama", help="inference strategy: ollama|ollama-slim|openai|gpt-oss|google")
    p.add_argument("--mlflow-experiment", default="summary", help="MLflow experiment name (defaults to model-name)")
    p.add_argument("--mlflow-system-prompt-id", default=None, help="MLflow System prompt id")
    p.add_argument("--mlflow-user-prompt-id", default=None, help="MLflow User prompt id")
    return p.parse_args()

if __name__ == "__main__":
    args = _parse_args()
    try:
        logger.info("Starting LLM judge evaluation with model: %s", args.model_name)
        evaluate_dataset(
            csv_path=args.csv,
            model_name=args.model_name,
            strategy=args.strategy,
            system_prompt_id=args.mlflow_system_prompt_id,
            user_prompt_id=args.mlflow_user_prompt_id,
            mlflow_experiment=args.mlflow_experiment
        )
    except Exception as exc:
        logger.exception("Evaluation failed: %s", exc)
        sys.exit(2)
        
        