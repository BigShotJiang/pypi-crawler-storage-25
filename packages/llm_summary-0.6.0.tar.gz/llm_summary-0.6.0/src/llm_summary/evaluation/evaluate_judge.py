"""
Evaluate an LLM Judge against a reference dataset.

CSV format (no header assumed by default):
- column 0: original text
- column 1: reference summary
- column 2: true positives
- column 3: false positives
- column 4: true negatives
- column 5: false negatives

This script will:
- call the judge API for each text
- compute simple overlap precision/recall/F1 between predicted and reference summaries
- log metrics, params and a predictions CSV artifact to MLflow
"""

from typing import Iterable, List, Set, Dict, Any, Optional

import os
import logging
import time

import pandas as pd
from llm_summary.inference_api.mlflow_config import MlFlowConfig
import mlflow
from llm_summary.inference_api.summary_inference import SummaryInferenceProvider
from llm_summary.core.dto import SummaryResult
from llm_summary.inference_api.llm_as_judge_inference import LlmAsJudgeProvider

from llm_summary.evaluation.metrics import compute_precision_recall_f1


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


def evaluate_dataset(
    csv_path: str,
    model_name: str,
    strategy: str,
    system_prompt_id: str,
    user_prompt_id: str,
    mlflow_experiment: Optional[str] = None,
) -> Dict[str, Any]:
    # MLflow logging
    mlflow.set_tracking_uri("http://localhost:5050")
    mlflow_exp = mlflow_experiment or model_name
    mlflow.set_experiment(mlflow_exp)
    with mlflow.start_run(run_name=f"{model_name}-{strategy}-cpu-default-prompt"):
        llm_judge = LlmAsJudgeProvider(
            model=model_name,
            strategy=strategy,
            mlflow_config=MlFlowConfig(
                mlflow_system_prompt_id=system_prompt_id,
                mlflow_user_prompt_id=user_prompt_id,
            ),
            ollama_host="http://localhost:11434"
        )
        
        text_col: int = 0
        summary_col: int = 1
        tp_col: int = 2
        fp_col: int = 3
        tn_col: int = 4
        fn_col: int = 5

        df = pd.read_csv(csv_path, dtype=str).fillna("")
        if df.shape[1] <= max(text_col, summary_col):
            raise ValueError("CSV does not contain enough columns for text/summary based on provided indices")

        texts = df.iloc[:, text_col].astype(str).tolist()
        summaries = df.iloc[:, summary_col].astype(str).tolist()
        tps = df.iloc[:, tp_col].astype(int).tolist()
        fps = df.iloc[:, fp_col].astype(int).tolist()
        tns = df.iloc[:, tn_col].astype(int).tolist()
        fns = df.iloc[:, fn_col].astype(int).tolist()

        total_tp = total_fp = total_fn = 0
        rows = []

        for idx, (text, summary, expected_tp, expected_fp, expected_tn, expected_fn) in enumerate(
                        zip(texts, summaries, tps, fps, tns, fns)):
            
            start_time = time.time()
            try:
                evaluation_summary = llm_judge.judge(text, summary)
            except Exception as e:
                logger.exception("Predictor judge failed on text index %s: %s", idx, e)
                continue
            latency_ms = (time.time() - start_time) * 1000
            mlflow.log_metric("latency_ms", latency_ms, step=idx)
            
            tp =  1 if evaluation_summary.true_positives == expected_tp else abs(evaluation_summary.true_positives - expected_tp)
            fp =  0 if evaluation_summary.false_positives == expected_fp else abs(evaluation_summary.false_positives - expected_fp)
            fn =  0 if evaluation_summary.false_negatives == expected_fn else abs (evaluation_summary.false_negatives - expected_fn)
            tn =  1 if evaluation_summary.true_negatives == expected_tn else abs(evaluation_summary.true_negatives - expected_tn)
            
            total_tp += (tp+tn)
            total_fp += fp
            total_fn += fn

            size_ratio = len(summary.split()) / len(text.split()) if text.strip() else 0.0
            rows.append({
                "index": idx,
                "text": text,
                "predicted": summary,
                "tp": evaluation_summary.true_positives,
                "fp": evaluation_summary.false_positives,
                "fn": evaluation_summary.false_negatives,
                "tn": evaluation_summary.true_negatives,
                "size_ratio": size_ratio,
            })

        precision, recall, f1 = compute_precision_recall_f1(total_tp, total_fp, total_fn)

        metrics = {
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "tp": total_tp,
            "fp": total_fp,
            "fn": total_fn,
            "n_samples": len(rows),
        }

        preds_df = pd.DataFrame(rows)

        # log params
        mlflow.log_param("dataset", csv_path)
        mlflow.log_param("model_name", f"{model_name}_cpu")
        mlflow.log_param("n_samples", len(rows))
        # log metrics
        mlflow.log_metric("precision", precision)
        mlflow.log_metric("recall", recall)
        mlflow.log_metric("f1", f1)
        mlflow.log_metric("tp", total_tp)
        mlflow.log_metric("fp", total_fp)
        mlflow.log_metric("fn", total_fn)
    

        filename = f"predictions_{int(time.time())}.csv"
        preds_df.to_csv(filename, index=False)
        mlflow.log_artifact(os.path.abspath(filename), artifact_path="artifacts")

        logger.info("Evaluation complete. precision=%.4f recall=%.4f f1=%.4f", precision, recall, f1)
        logger.info("Predictions CSV written to %s and logged to MLflow experiment '%s'", filename, mlflow_exp)

        return {"metrics": metrics, "predictions_csv": filename}
