"""Utility helpers for evaluation metrics.

This module provides functions to calculate standard classification metrics used
throughout the project such as precision, recall and the F1 score.  It keeps the
logic in one place so callers don't need to duplicate the normalisation
checks (denominator zero-handling, etc.).
"""

from typing import Tuple


def compute_precision_recall_f1(tp: int, fp: int, fn: int) -> Tuple[float, float, float]:
    """Return precision, recall and f1 score for the provided counts.

    Args:
        tp: number of true positives
        fp: number of false positives
        fn: number of false negatives

    The implementation mirrors the logic used previously in
    :func:`llm_summary.evaluation.evaluate.evaluate_dataset` but is factored out
    into a single helper for reuse and easier unit testing.  If the denominator
    for any ratio would be zero we return ``0.0`` for that value.

    Returns:
        ``(precision, recall, f1)`` where each element is a float in ``[0.0, 1.0]``.
    """
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    if precision + recall > 0:
        f1 = 2 * precision * recall / (precision + recall)
    else:
        f1 = 0.0
    return precision, recall, f1
