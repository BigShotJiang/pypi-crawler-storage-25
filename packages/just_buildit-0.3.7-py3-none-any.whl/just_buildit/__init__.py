"""
just-buildit — minimum viable PEP 517 build backend for C extensions.

Public surface (PEP 517):
  get_requires_for_build_wheel()
  prepare_metadata_for_build_wheel()
  build_wheel()
  build_editable()
  get_requires_for_build_sdist()
  build_sdist()
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("just-buildit")
except PackageNotFoundError:
    __version__ = "unknown"

import tempfile
from pathlib import Path

from . import _build, _meta, _sdist, _wheel
from ._wheel import _normalize_name


def get_requires_for_build_wheel(config_settings=None) -> list[str]:
    return []


def prepare_metadata_for_build_wheel(
    metadata_directory: str,
    config_settings=None,
) -> str:
    config = _meta.load(Path.cwd())
    from . import _wheel as w
    dist_info = w._write_dist_info(
        name=config.name,
        version=config.version,
        metadata_dir=Path(metadata_directory),
        summary=config.summary,
        readme_text=config.readme_text,
        readme_content_type=config.readme_content_type,
        requires_python=config.requires_python,
        classifiers=config.classifiers or None,
        keywords=config.keywords or None,
        urls=config.urls or None,
        dependencies=config.dependencies or None,
        scripts=config.scripts or None,
    )
    return dist_info.name


def build_editable(
    wheel_directory: str,
    config_settings=None,
    metadata_directory: str | None = None,
) -> str:
    project_root = Path.cwd()
    wheel_dir = Path(wheel_directory)
    config = _meta.load(project_root)

    # Resolve the editable source root: explicit config wins; src/ is the default
    # for the conventional src-layout; anything else falls back to a full wheel build.
    if config.editable_path is not None:
        editable_path = config.editable_path
    elif (project_root / "src").is_dir():
        editable_path = "src"
    else:
        raise RuntimeError(
            "build_editable requires an editable source root but none was found.\n\n"
            "Either put your sources in a src/ directory (auto-detected), or set:\n\n"
            "  [tool.just-buildit]\n"
            '  editable_path = "src"\n'
        )

    # Write a .pth file pointing at the source tree.
    # No build command is run — the C extension must already be compiled in place.
    with tempfile.TemporaryDirectory(prefix="just-buildit-") as tmp:
        output_dir = Path(tmp) / "output"
        output_dir.mkdir()

        pth_target = (project_root / editable_path).resolve()
        pth_name = _normalize_name(config.name) + ".pth"
        (output_dir / pth_name).write_text(str(pth_target) + "\n", encoding="utf-8")

        wheel_path = _wheel.build_wheel(
            name=config.name,
            version=config.version,
            output_dir=output_dir,
            wheel_dir=wheel_dir,
            exclude=[],
            summary=config.summary,
            readme_text=config.readme_text,
            readme_content_type=config.readme_content_type,
            requires_python=config.requires_python,
            classifiers=config.classifiers or None,
            keywords=config.keywords or None,
            urls=config.urls or None,
            dependencies=config.dependencies or None,
            scripts=config.scripts or None,
        )

    return wheel_path.name


def build_wheel(
    wheel_directory: str,
    config_settings=None,
    metadata_directory: str | None = None,
) -> str:
    project_root = Path.cwd()
    wheel_dir = Path(wheel_directory)

    config = _meta.load(project_root)

    with tempfile.TemporaryDirectory(prefix="just-buildit-") as tmp:
        output_dir = Path(tmp) / "output"

        # Step 1: build -> output_dir (the wheel content root)
        package = config.package or _normalize_name(config.name)
        output_dir = _build.run_build(
            name=config.name,
            package=package,
            command=config.command,
            output_dir=output_dir,
            project_root=project_root,
            pure=config.pure,
        )

        # Step 2: assemble wheel from everything in output_dir
        raw_wheel = _wheel.build_wheel(
            name=config.name,
            version=config.version,
            output_dir=output_dir,
            wheel_dir=wheel_dir,
            exclude=config.exclude,
            summary=config.summary,
            readme_text=config.readme_text,
            readme_content_type=config.readme_content_type,
            requires_python=config.requires_python,
            classifiers=config.classifiers or None,
            keywords=config.keywords or None,
            urls=config.urls or None,
            dependencies=config.dependencies or None,
            scripts=config.scripts or None,
        )

        # Step 3: repair (auditwheel / delocate / delvewheel).
        # A pure-Python wheel is py3-none-any — there is no native binary to
        # repair, so the repair step is skipped unconditionally.
        final_wheel = _build.run_repair(
            wheel_path=raw_wheel,
            wheel_dir=wheel_dir,
            repair_command=False if config.pure else config.repair,
            repair_args=config.repair_args or None,
        )

    return final_wheel.name


def get_requires_for_build_sdist(config_settings=None) -> list[str]:
    return []


def build_sdist(
    sdist_directory: str,
    config_settings=None,
) -> str:
    project_root = Path.cwd()
    sdist_dir = Path(sdist_directory)
    sdist_dir.mkdir(parents=True, exist_ok=True)

    config = _meta.load(project_root)
    sdist_path = _sdist.build_sdist(
        project_root=project_root,
        sdist_dir=sdist_dir,
        config=config,
    )
    return sdist_path.name
