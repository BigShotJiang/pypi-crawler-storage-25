from __future__ import annotations

import argparse
import contextlib
import difflib
import importlib
import json
import os
import re
import select
import shlex
import shutil
import signal
import socket
import struct
import subprocess
import sys
import threading
import time
import webbrowser
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urljoin, urlparse

from websockets.exceptions import ConnectionClosed, InvalidHandshake
from websockets.sync.client import connect as websocket_connect

from runtime_sdk import __version__
from runtime_sdk.client import DEFAULT_WARMUP_TIMEOUT, RuntimeAPIError, RuntimeClient
from runtime_sdk.config import (
    DEFAULT_BASE_URL,
    PendingSignup,
    RuntimeConfig,
    RuntimeConfigError,
    load_config,
    save_config,
)


# --------------------------------------------------------------------------- #
# TTY detection + lazy rich/questionary imports                               #
# --------------------------------------------------------------------------- #


def _interactive() -> bool:
    """True when we have a real terminal on both ends — enables fancy UI."""
    if os.environ.get("RUNTIME_NO_TTY"):
        return False
    try:
        return sys.stdin.isatty() and sys.stdout.isatty()
    except (AttributeError, ValueError):
        return False


SPINNER = "aesthetic"  # unicode ▰▱ progress-bar style; single place to tweak.


def _with_spinner(label: str, fn: Callable[[], Any]) -> Any:
    """Run fn(), wrapped in a rich spinner when interactive."""
    if not _interactive():
        return fn()
    with _UI.console().status(f"[cyan]{label}[/cyan]", spinner=SPINNER):
        return fn()


class _UI:
    """Lazy holder for rich + questionary so non-TTY paths stay import-cheap."""

    _console: Any = None
    _err_console: Any = None
    _questionary: Any = None
    _questionary_style: Any = None
    _rich_mods: dict[str, Any] | None = None

    @classmethod
    def console(cls) -> Any:
        if cls._console is None:
            from rich.console import Console

            cls._console = Console()
        return cls._console

    @classmethod
    def err(cls) -> Any:
        if cls._err_console is None:
            from rich.console import Console

            cls._err_console = Console(stderr=True)
        return cls._err_console

    @classmethod
    def q(cls) -> Any:
        if cls._questionary is None:
            import questionary

            cls._questionary = questionary
        return cls._questionary

    @classmethod
    def style(cls) -> Any:
        if cls._questionary_style is None:
            cls._questionary_style = cls.q().Style(
                [
                    ("qmark", "fg:#22c55e bold"),
                    ("question", "bold fg:#e5e7eb"),
                    ("answer", "fg:#22c55e bold"),
                    ("pointer", "fg:#60a5fa bold"),
                    ("highlighted", "fg:#ffffff bg:#1f2937 bold"),
                    ("selected", "fg:#22c55e bold"),
                    ("separator", "fg:#4b5563"),
                    ("instruction", "fg:#94a3b8 italic"),
                    ("text", "fg:#d1d5db"),
                    ("disabled", "fg:#6b7280 italic"),
                ]
            )
        return cls._questionary_style

    @classmethod
    def rich(cls) -> dict[str, Any]:
        if cls._rich_mods is None:
            from rich import box
            from rich.panel import Panel
            from rich.table import Table
            from rich.text import Text

            cls._rich_mods = {"Panel": Panel, "Text": Text, "Table": Table, "box": box}
        return cls._rich_mods


# --------------------------------------------------------------------------- #
# argparse                                                                    #
# --------------------------------------------------------------------------- #


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="runtime",
        description="Manage RuntimeVM computers — run code, publish apps, share URLs.",
    )
    parser.add_argument("--base-url", help="Override the Runtime API base URL")
    parser.add_argument("--version", action="version", version=f"runtime-sdk {__version__}")

    # Subcommand is optional: bare `runtime` defaults to `create`.
    subparsers = parser.add_subparsers(dest="command", required=False)

    signup = subparsers.add_parser("signup", help="Send an email verification code")
    signup.add_argument("email", nargs="?", default=None)
    signup.add_argument("--name", default=None)

    verify = subparsers.add_parser("verify", help="Verify an emailed code and save a fresh API key")
    verify.add_argument("code", nargs="?", default=None)
    verify.add_argument("--flow-id", type=int)

    login = subparsers.add_parser("login", help="Start email login or import an API key")
    login.add_argument(
        "identifier",
        nargs="?",
        default=None,
        help="Email address to send a code to, or an API key for backwards compatibility",
    )
    login.add_argument("--name", default=None, help="Optional display name for first-time email signup")
    login.add_argument(
        "--api-key",
        nargs="?",
        const="",
        default=None,
        help="Import an API key explicitly (prompts if omitted in interactive mode)",
    )

    subparsers.add_parser("whoami")
    subparsers.add_parser("logout")

    api_keys_cmd = subparsers.add_parser("api-keys", help="Manage Runtime API keys")
    api_keys_subparsers = api_keys_cmd.add_subparsers(dest="api_keys_action", required=True)
    api_keys_subparsers.add_parser("list", aliases=["ls"], help="List API keys")
    api_keys_create = api_keys_subparsers.add_parser("create", help="Create a new API key")
    api_keys_create.add_argument("label", nargs="?", default=None, help="Human-friendly label for the new API key")
    api_keys_revoke = api_keys_subparsers.add_parser("revoke", help="Revoke an API key")
    api_keys_revoke.add_argument("id", nargs="?", default=None, help="API key id")

    secrets_cmd = subparsers.add_parser("secrets", help="Manage account-level secret sets")
    secrets_subparsers = secrets_cmd.add_subparsers(dest="secrets_action", required=True)
    secrets_subparsers.add_parser("list", aliases=["ls"], help="List secret sets")
    secrets_show = secrets_subparsers.add_parser("show", help="Show one secret set")
    secrets_show.add_argument("slug", nargs="?", default=None, help="Secret set slug")
    secrets_set = secrets_subparsers.add_parser("set", help="Create or replace a secret set from KEY=VALUE pairs")
    secrets_set.add_argument("slug", nargs="?", default=None, help="Secret set slug")
    secrets_set.add_argument("pairs", nargs="*", help="KEY=VALUE pairs")
    secrets_import = secrets_subparsers.add_parser("import", help="Create or replace a secret set from a .env file")
    secrets_import.add_argument("slug", nargs="?", default=None, help="Secret set slug")
    secrets_import.add_argument("--env-file", required=True, help="Path to .env file")
    secrets_delete = secrets_subparsers.add_parser("delete", aliases=["rm"], help="Delete a secret set")
    secrets_delete.add_argument("slug", nargs="?", default=None, help="Secret set slug")

    github_cmd = subparsers.add_parser("github", help="Manage connected GitHub App installations")
    github_subparsers = github_cmd.add_subparsers(dest="github_action", required=True)
    github_subparsers.add_parser("list", aliases=["ls"], help="List connected GitHub installations")
    github_disconnect = github_subparsers.add_parser("disconnect", aliases=["rm"], help="Disconnect a GitHub installation from Runtime")
    github_disconnect.add_argument("ref", nargs="?", default=None, help="GitHub owner or installation id")

    integrate_cmd = subparsers.add_parser("integrate", help="Connect the RuntimeVM GitHub App")
    integrate_cmd.add_argument("provider", choices=["github"])
    integrate_cmd.add_argument("--no-open", action="store_true", help="Print the install URL instead of opening a browser")
    integrate_cmd.add_argument("--timeout", type=int, default=180, help="Seconds to wait for the browser install to finish (default: 180)")

    switch_cmd = subparsers.add_parser(
        "switch",
        aliases=["checkout"],
        help="Open a GitHub branch workspace in its own computer",
    )
    switch_cmd.add_argument("branch", nargs="?", default=None, help="Git branch to open")
    switch_cmd.add_argument("--repo", default=None, help="GitHub repository in owner/name format")
    switch_cmd.add_argument("-c", "--create", action="store_true", help="Create a new branch before opening it")
    switch_cmd.add_argument("--from", dest="base_branch", default=None, help="Base branch for -c (defaults to the repo default branch)")

    create_cmd = subparsers.add_parser("create", help="Create a new computer with the starter app published by default")
    create_cmd.add_argument(
        "name",
        nargs="?",
        default=None,
        help="Subdomain name (e.g. redsox → redsox.runruntime.dev). Random if skipped.",
    )
    create_cmd.add_argument("--command", dest="startup_command", help="Initial service command to save on create")
    create_cmd.add_argument("--cwd", help="Working directory for the initial service command")
    create_cmd.add_argument("--port", type=int, help="App port to publish for the initial service")
    list_cmd = subparsers.add_parser("list", aliases=["ls"], help="List computers")
    list_cmd.add_argument(
        "-w",
        "--watch",
        nargs="?",
        const=2,
        type=int,
        default=None,
        metavar="SECONDS",
        help="Re-render the table every N seconds (default 2)",
    )

    enter_cmd = subparsers.add_parser("enter", help="Enter a computer's console")
    enter_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    info_cmd = subparsers.add_parser("info", help="Get computer details")
    info_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    url_cmd = subparsers.add_parser("url", help="Show a computer's public URL and live published port")
    url_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    share_cmd = subparsers.add_parser("share", help="Set whether a computer is public or private")
    share_subparsers = share_cmd.add_subparsers(dest="share_action", required=True)
    share_public = share_subparsers.add_parser("public", help="Make a computer publicly accessible")
    share_public.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    share_private = share_subparsers.add_parser("private", help="Require owner auth before browser access")
    share_private.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    start_cmd = subparsers.add_parser("start", help="Wake a cold computer")
    start_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    delete_cmd = subparsers.add_parser("delete", aliases=["rm"], help="Delete a computer")
    delete_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    delete_cmd.add_argument(
        "--force",
        "-y",
        action="store_true",
        help="Skip the typed-name confirmation prompt",
    )

    run_cmd = subparsers.add_parser("run", help="Run a one-shot command in a computer")
    run_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    run_cmd.add_argument(
        "run_command",
        metavar="command",
        nargs="?",
        default=None,
        help="Command to run",
    )
    run_cmd.add_argument("--uid", type=int, help="User ID")
    run_cmd.add_argument("--gid", type=int, help="Group ID")
    run_cmd.add_argument("--cwd", help="Working directory")
    run_cmd.add_argument("--shell", help="Shell to use")

    publish_cmd = subparsers.add_parser(
        "publish", help="Promote the running app on a local port into the durable public app"
    )
    publish_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    publish_cmd.add_argument("port", nargs="?", type=int, default=None, help="Local app port")
    publish_cmd.add_argument("publish_command", nargs="*", help="Command after --")

    startup_cmd = subparsers.add_parser("startup", help=argparse.SUPPRESS)
    startup_subparsers = startup_cmd.add_subparsers(dest="startup_action", required=True)
    startup_show = startup_subparsers.add_parser("show", help="Show durable startup config")
    startup_show.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    startup_set = startup_subparsers.add_parser("set", help="Set durable startup config")
    startup_set.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    startup_set.add_argument("--command", dest="startup_value_command", required=True, help="Durable startup command")
    startup_set.add_argument("--cwd", help="Working directory for the durable startup command")
    startup_set.add_argument("--port", required=True, type=int, help="App port to publish for durable startup")
    startup_clear = startup_subparsers.add_parser("clear", help="Clear durable startup config")
    startup_clear.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    service_cmd = subparsers.add_parser("service", help="Manage the durable published app service")
    service_subparsers = service_cmd.add_subparsers(dest="service_action", required=True)
    service_run = service_subparsers.add_parser("run", help="Start and publish a durable service command")
    service_run.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    service_run.add_argument("--port", required=True, type=int, help="Service port")
    service_run.add_argument("--cwd", help="Working directory for the service command")
    service_run.add_argument("service_command", nargs="*", help="Command after --")
    service_show = service_subparsers.add_parser("show", help="Show the durable published app service")
    service_show.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    service_status = service_subparsers.add_parser("status", help="Show durable service status")
    service_status.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    service_logs = service_subparsers.add_parser("logs", help="Stream durable service logs")
    service_logs.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    service_logs.add_argument("--follow", action="store_true", help="Follow live logs")
    service_restart = service_subparsers.add_parser("restart", help="Restart the durable service")
    service_restart.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    service_stop = service_subparsers.add_parser("stop", help="Stop the durable service but keep its config")
    service_stop.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    service_clear = service_subparsers.add_parser("clear", help="Clear the durable published app service")
    service_clear.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    proxy_cmd = subparsers.add_parser("proxy", help="Manage background local port proxies")
    proxy_subparsers = proxy_cmd.add_subparsers(dest="proxy_command", required=True)
    proxy_start = proxy_subparsers.add_parser("start", help="Start one or more background local port proxies")
    proxy_start.add_argument("id", help="Computer ID (hostname)")
    proxy_start.add_argument("ports", nargs="+", help="Port mappings like 5432 or 15432:5432")
    proxy_subparsers.add_parser("ls", help="List background local port proxies")
    proxy_stop = proxy_subparsers.add_parser("stop", help="Stop one or more background local port proxies")
    proxy_stop.add_argument("local_ports", nargs="*", type=int, help="Local ports to stop")
    proxy_stop.add_argument("--all", action="store_true", help="Stop all running proxies")

    proxy_agent = subparsers.add_parser("_proxy_agent", help=argparse.SUPPRESS)
    proxy_agent.add_argument("--base-url", required=True)
    proxy_agent.add_argument("--computer-id", required=True)
    proxy_agent.add_argument("--display-name", required=True)
    proxy_agent.add_argument("--local-port", type=int, required=True)
    proxy_agent.add_argument("--remote-port", type=int, required=True)

    help_cmd = subparsers.add_parser("help", help="Show extended help for a topic")
    help_cmd.add_argument("topic", nargs="?", default=None, help="Topic to show (computer, share, account, all)")

    completion_cmd = subparsers.add_parser(
        "completion", help="Print shell completion script (bash, zsh, fish)"
    )
    completion_cmd.add_argument("shell", choices=["bash", "zsh", "fish"], help="Target shell")

    # Hidden helper used by shell completion to list slugs, one per line.
    subparsers.add_parser("_slugs", help=argparse.SUPPRESS)

    parser.format_help = lambda: _format_top_help()  # type: ignore[assignment]
    return parser


_HELP_SECTIONS: tuple[tuple[str, tuple[tuple[str, str], ...]], ...] = (
    (
        "Computers",
        (
            ("create [name]", "Create a new computer (starter app published by default)"),
            ("list, ls", "List computers (-w watches, refreshes every 2s)"),
            ("info [id]", "Show computer details"),
            ("url [id]", "Show a computer's public URL and live published port"),
            ("start [id]", "Wake a cold computer"),
            ("enter [id]", "Enter a computer's console (TTY)"),
            ("run [id] <cmd>", "Run a one-shot command"),
            ("publish [id] <port> -- <cmd>", "Run and publish a durable service command"),
            ("delete, rm [id]", "Delete a computer (typed-name confirm; --force / -y to skip)"),
        ),
    ),
    (
        "Sharing",
        (
            ("share public [id]", "Make a computer publicly accessible"),
            ("share private [id]", "Require owner auth before browser access"),
        ),
    ),
    (
        "Startup & service",
        (
            ("service run [id] --port N -- <cmd>", "Run and publish a durable service command"),
            ("service status [id]", "Show durable service status"),
            ("service logs [id] --follow", "Stream service logs"),
            ("service restart [id]", "Restart the durable service"),
            ("service stop [id]", "Stop service but keep config"),
            ("service clear [id]", "Clear the durable published app service"),
        ),
    ),
    (
        "Proxy",
        (
            ("proxy start <id> <ports…>", "Forward local → remote ports (e.g. 5432 or 15432:5432)"),
            ("proxy ls", "List running proxies"),
            ("proxy stop [ports…] [--all]", "Stop proxies (by local port or all)"),
        ),
    ),
    (
        "GitHub",
        (
            ("switch, checkout [branch]", "Open a GitHub branch workspace in its own computer"),
            ("integrate github", "Install the RuntimeVM GitHub App and wait for completion"),
            ("github list", "List connected GitHub installations"),
            ("github disconnect, rm [owner|id]", "Disconnect one GitHub installation"),
        ),
    ),
    (
        "Account",
        (
            ("signup [email]", "Send an email verification code"),
            ("verify [code]", "Verify an emailed code and save a fresh API key"),
            ("login [email|api-key]", "Email login or import an API key"),
            ("whoami", "Show current account"),
            ("logout", "Revoke API key and remove local config"),
            ("api-keys list/create/revoke", "Manage Runtime API keys"),
            ("secrets list/show/set/import/rm", "Manage account-level secret sets"),
        ),
    ),
    (
        "Shell",
        (
            ("help [topic]", "Show extended help — topics: computer, share, account, all"),
            ("completion <bash|zsh|fish>", "Print shell completion script"),
        ),
    ),
)


_HELP_EXAMPLES: tuple[str, ...] = (
    "runtime                         # interactive menu (create if piped)",
    "runtime ls -w                   # live-updating list",
    "runtime create mybox --command 'npm start' --cwd /app --port 3000",
    "runtime share private mybox     # require owner auth",
    "runtime integrate github         # open GitHub and wait for the install to finish",
    "runtime github list              # show connected GitHub orgs/accounts",
    "runtime proxy start mybox 5432  # forward localhost:5432 → mybox:5432",
    "runtime completion zsh > ~/.zsh/completions/_runtime",
)


def _format_top_help() -> str:
    lines: list[str] = []
    lines.append("runtime — manage RuntimeVM computers")
    lines.append("")
    lines.append("usage: runtime [--base-url URL] [--version] [-h] <command> [args…]")
    lines.append("")
    lines.append("Global options:")
    lines.append("  --base-url URL       Override the Runtime API base URL")
    lines.append("  --version            Show the CLI version")
    lines.append("  -h, --help           Show this help")
    lines.append("")
    left_width = 0
    for _, rows in _HELP_SECTIONS:
        for name, _ in rows:
            left_width = max(left_width, len(name))
    left_width = min(left_width, 38)
    for title, rows in _HELP_SECTIONS:
        lines.append(f"{title}:")
        for name, desc in rows:
            padded = name if len(name) >= left_width else name + " " * (left_width - len(name))
            lines.append(f"  {padded}  {desc}")
        lines.append("")
    lines.append("Examples:")
    for example in _HELP_EXAMPLES:
        lines.append(f"  {example}")
    lines.append("")
    lines.append("Run `runtime <command> --help` for flags and examples on one command.")
    lines.append("Run `runtime help <topic>` for long-form docs.")
    return "\n".join(lines) + "\n"


def _windows_unsupported() -> bool:
    return sys.platform == "win32"



def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if _windows_unsupported():
        return report_error("runtime-sdk supports macOS and Linux only; Windows is not supported")

    try:
        config = load_config()
        if args.base_url:
            config.base_url = args.base_url
        elif os.environ.get("RUNTIME_BASE_URL"):
            config.base_url = str(os.environ.get("RUNTIME_BASE_URL"))
        else:
            config.base_url = config.configured_base_url or DEFAULT_BASE_URL

        # Bare `runtime` →
        #   TTY + no api key      → onboarding
        #   TTY + api key         → interactive menu (list + actions)
        #   non-TTY               → create (preserves script-friendly default)
        if args.command is None:
            if _interactive():
                if not config.api_key:
                    return handle_onboarding(config)
                return handle_list(config)
            args.command = "create"
            args.name = None

        if args.command == "signup":
            return handle_signup(config, args.email, args.name)
        if args.command == "verify":
            return handle_verify(config, args.code, args.flow_id)
        if args.command == "login":
            return handle_login(config, args.identifier, args.name, args.api_key)
        if args.command == "whoami":
            return handle_whoami(config)
        if args.command == "logout":
            return handle_logout(config)
        if args.command == "api-keys":
            if args.api_keys_action in ("list", "ls"):
                return handle_api_keys_list(config)
            if args.api_keys_action == "create":
                return handle_api_keys_create(config, args.label)
            if args.api_keys_action == "revoke":
                return handle_api_keys_revoke(config, args.id)
            return report_error("unknown api-keys command")
        if args.command == "secrets":
            if args.secrets_action in ("list", "ls"):
                return handle_secrets_list(config)
            if args.secrets_action == "show":
                return handle_secrets_show(config, args.slug)
            if args.secrets_action == "set":
                return handle_secrets_set(config, args.slug, args.pairs)
            if args.secrets_action == "import":
                return handle_secrets_import(config, args.slug, args.env_file)
            if args.secrets_action in ("delete", "rm"):
                return handle_secrets_delete(config, args.slug)
            return report_error("unknown secrets command")
        if args.command == "github":
            if args.github_action in ("list", "ls"):
                return handle_github_list(config)
            if args.github_action in ("disconnect", "rm"):
                return handle_github_disconnect(config, args.ref)
            return report_error("unknown github command")
        if args.command == "integrate":
            return handle_integrate_github(config, args.provider, no_open=args.no_open, timeout_seconds=args.timeout)
        if args.command in ("switch", "checkout"):
            return handle_switch(
                config,
                getattr(args, "repo", None),
                getattr(args, "branch", None),
                create_branch=getattr(args, "create", False),
                base_branch=getattr(args, "base_branch", None),
            )
        if args.command == "create":
            return handle_create(
                config,
                args.name,
                getattr(args, "startup_command", None),
                getattr(args, "cwd", None),
                getattr(args, "port", None),
            )
        if args.command in ("list", "ls"):
            return handle_list(config, watch=getattr(args, "watch", None))
        if args.command == "info":
            return handle_info(config, args.id)
        if args.command == "url":
            return handle_url(config, args.id)
        if args.command == "share":
            return handle_share(config, args.share_action, args.id)
        if args.command == "start":
            return handle_start(config, args.id)
        if args.command == "enter":
            return handle_enter(config, args.id)
        if args.command in ("delete", "rm"):
            return handle_delete(config, args.id, force=getattr(args, "force", False))
        if args.command == "run":
            return handle_run(
                config, args.id, args.run_command, args.uid, args.gid, args.cwd, args.shell
            )
        if args.command == "publish":
            return handle_publish(config, args.id, args.port, args.publish_command)
        if args.command == "startup":
            if args.startup_action == "show":
                return handle_startup_show(config, args.id)
            if args.startup_action == "set":
                return handle_startup_set(config, args.id, args.startup_value_command, args.cwd, args.port)
            if args.startup_action == "clear":
                return handle_startup_clear(config, args.id)
            return report_error("unknown startup command")
        if args.command == "service":
            if args.service_action == "run":
                return handle_service_run(config, args.id, args.port, args.cwd, args.service_command)
            if args.service_action in ("show", "status"):
                return handle_service_show(config, args.id)
            if args.service_action == "logs":
                return handle_service_logs(config, args.id, args.follow)
            if args.service_action == "restart":
                return handle_service_restart(config, args.id)
            if args.service_action == "stop":
                return handle_service_stop(config, args.id)
            if args.service_action == "clear":
                return handle_service_clear(config, args.id)
            return report_error("unknown service command")
        if args.command == "proxy":
            if args.proxy_command == "start":
                return handle_proxy_start(config, args.id, args.ports)
            if args.proxy_command == "ls":
                return handle_proxy_ls(config)
            if args.proxy_command == "stop":
                return handle_proxy_stop(config, args.local_ports, stop_all=args.all)
            return report_error("unknown proxy command")
        if args.command == "help":
            return handle_help(args.topic)
        if args.command == "completion":
            return handle_completion(args.shell)
        if args.command == "_slugs":
            return handle_slugs(config)
        if args.command == "_proxy_agent":
            return run_proxy_agent(
                args.base_url,
                os.environ.get("RUNTIME_PROXY_API_KEY", ""),
                args.computer_id,
                args.display_name,
                args.local_port,
                args.remote_port,
            )
    except RuntimeAPIError as exc:
        return report_error(str(exc), status_code=exc.status_code)
    except RuntimeConfigError as exc:
        return report_error(str(exc))
    except KeyboardInterrupt:
        if _interactive():
            UI = _UI.err()
            UI.print("\n[dim]cancelled[/dim]")
            return 130
        return report_error("cancelled")

    return report_error("unknown command")


# --------------------------------------------------------------------------- #
# Shared helpers                                                              #
# --------------------------------------------------------------------------- #


def write_json(payload: dict[str, Any], *, error: bool = False) -> int:
    stream = sys.stderr if error else sys.stdout
    stream.write(json.dumps(payload) + "\n")
    return 1 if error else 0


def report_error(message: str, *, status_code: int | None = None) -> int:
    """Error output — JSON in non-TTY mode, rich in TTY mode."""
    if _interactive():
        err = _UI.err()
        suffix = f" [dim](http {status_code})[/dim]" if status_code is not None else ""
        err.print(f"[bold red]✗[/bold red] {message}{suffix}")
        return 1
    payload: dict[str, Any] = {"success": False, "error": message}
    if status_code is not None:
        payload["status_code"] = status_code
    return write_json(payload, error=True)


def report_success(payload: dict[str, Any], renderer: Callable[[dict[str, Any]], None] | None = None) -> int:
    """Success output — rich renderer in TTY, JSON otherwise."""
    if _interactive() and renderer is not None:
        renderer(payload)
        return 0
    return write_json({"success": True, **payload})


def _require_api_key(config: RuntimeConfig) -> int | None:
    if config.api_key:
        return None
    return report_error("missing api key; run login or verify first")


def _runtime_state_dir() -> Path:
    root = os.environ.get("XDG_STATE_HOME")
    if root:
        return Path(root) / "runtime"
    return Path.home() / ".local" / "state" / "runtime"


def _proxy_dir() -> Path:
    return _runtime_state_dir() / "proxies"


def _proxy_state_path(local_port: int) -> Path:
    return _proxy_dir() / f"proxy-{local_port}.json"


def _proxy_log_path(local_port: int) -> Path:
    return _proxy_dir() / f"proxy-{local_port}.log"


def _pid_running(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _pid_command(pid: int) -> str:
    if pid <= 0:
        return ""
    try:
        return subprocess.check_output(
            ["ps", "-o", "command=", "-p", str(pid)],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except (OSError, subprocess.SubprocessError):
        return ""


def _proxy_pid_matches(pid: int, local_port: int) -> bool:
    if not _pid_running(pid):
        return False
    command = _pid_command(pid)
    if not command:
        return False
    with contextlib.suppress(ValueError):
        argv = shlex.split(command)
        if "_proxy_agent" not in argv:
            return False
        if "--local-port" not in argv:
            return False
        index = argv.index("--local-port")
        if index + 1 >= len(argv) or argv[index + 1] != str(local_port):
            return False
        return "runtime_sdk.cli" in argv or any(part.endswith("runtime_sdk.cli") for part in argv)
    return False


def _load_proxy_records(*, clean_stale: bool = False) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    directory = _proxy_dir()
    if not directory.exists():
        return records
    for path in sorted(directory.glob("proxy-*.json")):
        try:
            record = json.loads(path.read_text())
        except (OSError, ValueError):
            continue
        if not isinstance(record, dict):
            continue
        record["state_path"] = str(path)
        pid = int(record.get("pid") or 0)
        local_port = int(record.get("local_port") or 0)
        record["status"] = "running" if _proxy_pid_matches(pid, local_port) else "stopped"
        if clean_stale and record["status"] != "running":
            with contextlib.suppress(OSError):
                path.unlink()
            continue
        records.append(record)
    return records


def _parse_proxy_port_spec(spec: str) -> tuple[int, int]:
    text = str(spec or "").strip()
    if not text:
        raise RuntimeAPIError("port mapping is required")
    if ":" in text:
        local_text, remote_text = text.split(":", 1)
    else:
        local_text, remote_text = text, text
    try:
        local_port = int(local_text)
        remote_port = int(remote_text)
    except ValueError as exc:
        raise RuntimeAPIError(f"invalid port mapping: {text}") from exc
    for port in (local_port, remote_port):
        if port <= 0 or port > 65535:
            raise RuntimeAPIError("port must be between 1 and 65535")
    return local_port, remote_port


def _resolve_ws_url(base_url: str, ws_url: Any) -> str:
    text = str(ws_url or "").strip()
    if not text:
        return ""
    if text.startswith("ws://") or text.startswith("wss://"):
        return text

    parsed = urlparse(base_url)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    root = f"{scheme}://{parsed.netloc}"
    if text.startswith("/"):
        return root + text
    return urljoin(root + "/", text)


def _spawn_proxy_agent(base_url: str, api_key: str, computer_id: str, display_name: str, local_port: int, remote_port: int) -> int:
    proxy_dir = _proxy_dir()
    proxy_dir.mkdir(parents=True, exist_ok=True)
    log_path = _proxy_log_path(local_port)
    log_file = log_path.open("a", encoding="utf-8")
    child_env = os.environ.copy()
    child_env["RUNTIME_PROXY_API_KEY"] = api_key
    try:
        proc = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "runtime_sdk.cli",
                "_proxy_agent",
                "--base-url",
                base_url,
                "--computer-id",
                computer_id,
                "--display-name",
                display_name,
                "--local-port",
                str(local_port),
                "--remote-port",
                str(remote_port),
            ],
            stdin=subprocess.DEVNULL,
            stdout=log_file,
            stderr=log_file,
            start_new_session=True,
            close_fds=True,
            env=child_env,
        )
    finally:
        log_file.close()

    deadline = time.time() + max(4.0, DEFAULT_WARMUP_TIMEOUT + 2.0)
    state_path = _proxy_state_path(local_port)
    while time.time() < deadline:
        if state_path.exists():
            return proc.pid
        code = proc.poll()
        if code is not None:
            break
        time.sleep(0.1)

    message = f"proxy failed to start on localhost:{local_port}"
    with contextlib.suppress(OSError):
        tail = log_path.read_text(encoding="utf-8").strip()
        if tail:
            message = tail.splitlines()[-1]
    raise RuntimeAPIError(message)


def _remove_proxy_state(local_port: int) -> None:
    with contextlib.suppress(OSError):
        _proxy_state_path(local_port).unlink()


def _stop_proxy_ports(local_ports: list[int], *, stop_all: bool = False) -> list[dict[str, Any]]:
    records = _load_proxy_records(clean_stale=False)
    stopped: list[dict[str, Any]] = []
    wanted = set(local_ports)
    for record in records:
        port = int(record.get("local_port") or 0)
        if not stop_all and port not in wanted:
            continue
        pid = int(record.get("pid") or 0)
        if _proxy_pid_matches(pid, port):
            with contextlib.suppress(OSError):
                os.kill(pid, signal.SIGTERM)
        _remove_proxy_state(port)
        record["status"] = "stopped"
        stopped.append(record)
    return stopped


def _prompt_text(message: str, *, default: str | None = None) -> str | None:
    """Ask for a line of text. Returns None if the user left it blank.

    Ctrl-C propagates as KeyboardInterrupt, handled centrally by main().
    """
    answer = _UI.q().text(message, default=default or "").unsafe_ask()
    return answer.strip() or None


def _prompt_password(message: str) -> str | None:
    answer = _UI.q().password(message).unsafe_ask()
    return answer.strip() or None


def _prompt_confirm(message: str, *, default: bool = False) -> bool:
    return bool(_UI.q().confirm(message, default=default).unsafe_ask())


def _copy_to_clipboard(text: str) -> bool:
    """Copy text to the OS clipboard. Returns True on success."""
    text = str(text or "")
    if not text:
        return False
    candidates = [
        ["pbcopy"],
        ["wl-copy"],
        ["xclip", "-selection", "clipboard"],
        ["xsel", "--clipboard", "--input"],
    ]
    if sys.platform == "win32":
        candidates.insert(0, ["clip"])
    for cmd in candidates:
        if not shutil.which(cmd[0]):
            continue
        try:
            subprocess.run(cmd, input=text.encode(), check=True)
            return True
        except (OSError, subprocess.SubprocessError):
            continue
    return False


def _close_matches(ref: str, candidates: list[str], limit: int = 3) -> list[str]:
    """Return up to `limit` candidates that look similar to ref."""
    ref = (ref or "").strip()
    if not ref:
        return []
    pool = [c for c in candidates if c]
    return difflib.get_close_matches(ref, pool, n=limit, cutoff=0.4)


def _prompt_typed_confirm(message: str, expected: str) -> bool:
    """Ask the user to retype the expected token (case-insensitive). Empty = cancel."""
    typed = _prompt_text(f"{message} (type {expected!r} to confirm)") or ""
    return typed.strip().lower() == expected.strip().lower()


def _computer_power_state(c: dict[str, Any]) -> str:
    power = c.get("power_state")
    if power is not None:
        return str(power or "?")
    status = str(c.get("status") or "?")
    if status in ("warm", "cold"):
        return status
    if status == "deleted":
        return "cold"
    return "warm"



def _computer_internal_status(c: dict[str, Any]) -> str:
    internal = c.get("internal_status")
    if internal is not None:
        return str(internal or "?")
    return str(c.get("status") or "?")



def _computer_status_label(c: dict[str, Any]) -> str:
    power = _computer_power_state(c)
    internal = _computer_internal_status(c)
    if power == internal:
        return power
    if power == "warm" and internal == "running":
        return power
    if internal in {"creating", "archiving", "restoring", "orphaned"}:
        return internal
    return power



def _computer_matches_ref(c: dict[str, Any], ref: str) -> bool:
    ref = ref.strip()
    if not ref:
        return False

    candidates = {
        str(c.get("id") or "").strip(),
        str(c.get("slug") or "").strip(),
        str(c.get("hostname") or "").strip(),
        str(c.get("public_url") or "").strip(),
    }

    public_url = str(c.get("public_url") or "").strip()
    if public_url:
        parsed = urlparse(public_url)
        if parsed.netloc:
            candidates.add(parsed.netloc)
            first_label = parsed.netloc.split(".", 1)[0].strip()
            if first_label:
                candidates.add(first_label)

    return ref in {value for value in candidates if value}



def _resolve_computer_ref(client: RuntimeClient, ref: str) -> str:
    ref = ref.strip()
    if not ref:
        raise RuntimeAPIError("computer id is required")
    if ref.startswith("cmp_"):
        return ref

    try:
        payload = client.list_computers()
    except RuntimeAPIError:
        return ref

    computers = payload.get("computers") or []
    if not isinstance(computers, list):
        computers = []

    matches = [c for c in computers if isinstance(c, dict) and _computer_matches_ref(c, ref)]
    if len(matches) == 1:
        resolved = str(matches[0].get("id") or "").strip()
        return resolved or ref
    if len(matches) > 1:
        raise RuntimeAPIError(f"multiple computers matched {ref!r}; use the exact computer id")

    slugs = [str(c.get("slug") or "").strip() for c in computers if isinstance(c, dict)]
    suggestions = _close_matches(ref, [s for s in slugs if s])
    if suggestions:
        hint = ", ".join(repr(s) for s in suggestions)
        raise RuntimeAPIError(f"computer {ref!r} not found. Did you mean {hint}?")
    raise RuntimeAPIError(f"computer {ref!r} not found")



def _coerce_github_repo(repo: str | None) -> str | None:
    text = str(repo or "").strip()
    if not text:
        return None
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", text):
        raise RuntimeAPIError("repo must be in owner/name format")
    owner, name = text.split("/", 1)
    return f"{owner}/{name}"



def _coerce_git_branch(branch: str | None) -> str | None:
    text = str(branch or "").strip()
    if not text:
        return None
    if text == "@":
        raise RuntimeAPIError("branch name is invalid")
    if text.startswith("-") or text.endswith("/") or text.endswith(".") or text.endswith(".lock"):
        raise RuntimeAPIError("branch name is invalid")
    if ".." in text or "//" in text or "@{" in text:
        raise RuntimeAPIError("branch name is invalid")
    if any(ch in text for ch in (" ", "~", "^", ":", "?", "*", "[", "\\")):
        raise RuntimeAPIError("branch name is invalid")
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in text):
        raise RuntimeAPIError("branch name is invalid")
    return text



def _render_branch_workspace(payload: dict[str, Any]) -> None:
    computer = payload.get("computer") or {}
    repo = str(payload.get("repo") or "")
    branch = str(payload.get("branch") or "")
    action = "created branch" if payload.get("create_branch") else "opened branch"
    _render_computer_panel(computer, title="workspace")
    _UI.console().print(f"[green]✓[/green] {action} [bold]{repo}#{branch}[/bold]")
    url = computer.get("public_url")
    if url:
        _UI.console().print(f"[bold green]→[/bold green] [cyan]{url}[/cyan]")



def _computer_name(c: dict[str, Any]) -> str:
    return str(c.get("slug") or c.get("id") or "?")



def _computer_url_label(c: dict[str, Any]) -> str:
    public_url = str(c.get("public_url") or "").strip()
    if not public_url:
        return ""
    parsed = urlparse(public_url)
    return parsed.netloc or public_url



def _relative_time_label(value: Any) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    try:
        created = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return raw
    delta = datetime.now(timezone.utc) - created.astimezone(timezone.utc)
    seconds = max(0, int(delta.total_seconds()))
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    if hours < 24:
        return f"{hours}h"
    days = hours // 24
    return f"{days}d"



def _computer_created_label(c: dict[str, Any]) -> str:
    return _relative_time_label(c.get("created_at"))



def _computer_status_style(status: str) -> str:
    if "cold" in status:
        return "bold cyan"
    if "warm" in status or "running" in status:
        return "bold green"
    if "archiving" in status or "restoring" in status:
        return "bold yellow"
    if "creating" in status:
        return "bold magenta"
    if "orphaned" in status:
        return "bold red"
    return "white"



def _computer_status_dot(status: str) -> str:
    if "cold" in status:
        return "◌"
    if "warm" in status or "running" in status:
        return "●"
    if "archiving" in status or "restoring" in status:
        return "◐"
    if "creating" in status:
        return "◔"
    if "orphaned" in status:
        return "✕"
    return "•"



def _computer_sort_key(c: dict[str, Any]) -> tuple[int, str, str]:
    status = _computer_status_label(c)
    priority = 1
    if "warm" in status or "running" in status:
        priority = 0
    elif "cold" in status:
        priority = 1
    elif "restoring" in status or "creating" in status:
        priority = 2
    else:
        priority = 3
    return (priority, _computer_name(c).lower(), str(c.get("id") or ""))



def _picker_status_color(status: str) -> str:
    if "cold" in status:
        return "fg:#60a5fa"  # cyan-blue
    if "warm" in status or "running" in status:
        return "fg:#22c55e"  # green
    if "archiving" in status or "restoring" in status:
        return "fg:#eab308"  # yellow
    if "creating" in status:
        return "fg:#a855f7"  # magenta
    if "orphaned" in status:
        return "fg:#ef4444"  # red
    return "fg:#e5e7eb"


def _picker_widths(computers: list[dict[str, Any]]) -> dict[str, int]:
    """Compute aligned column widths for the interactive picker rows.

    We budget total width to leave room for questionary's pointer + indicator.
    """
    term_width = shutil.get_terminal_size((100, 20)).columns
    name_w = max(len("name"), max((len(_computer_name(c)) for c in computers), default=0))
    name_w = min(name_w, 24)
    status_w = max(len("state"), max((len(_computer_status_label(c)) for c in computers), default=0))
    status_w = min(status_w, 14)
    age_w = max(len("age"), max((len(_computer_created_label(c)) for c in computers), default=0))
    age_w = min(age_w, 6)
    # pointer + indicator + 2 gaps * 3 + status dot (2 chars) + padding
    reserved = 6 + name_w + status_w + age_w + 2 * 3 + 2
    url_w = max(len("url"), min(max((len(_computer_url_label(c)) for c in computers), default=16), term_width - reserved))
    url_w = max(10, url_w)
    return {"name": name_w, "status": status_w, "url": url_w, "age": age_w}


def _computer_choice_title(c: dict[str, Any], widths: dict[str, int]) -> list[tuple[str, str]]:
    """Return a styled list-of-tuples title so the picker rows look tabular.

    Columns: name · state (colored dot + label) · url · age.
    """
    name = _computer_name(c)
    status = _computer_status_label(c)
    url = _computer_url_label(c) or "—"
    age = _computer_created_label(c) or ""
    color = _picker_status_color(status)
    dot = _computer_status_dot(status)
    # Keep each column within its budget; truncate with ellipsis on overflow.
    def fit(text: str, width: int, align: str = "<") -> str:
        text = str(text or "")
        if len(text) > width:
            return text[: max(1, width - 1)] + "…"
        return format(text, f"{align}{width}")
    return [
        ("", fit(name, widths["name"]) + "  "),
        (color, f"{dot} "),
        (color, fit(status, widths["status"])),
        ("", "  "),
        ("fg:#cbd5e1", fit(url, widths["url"])),
        ("", "  "),
        ("fg:#6b7280", fit(age, widths["age"], ">")),
    ]





def _select_prompt(message: str, choices: list[Any], *, instruction: str | None = None) -> Any:
    # questionary rejects use_jk_keys together with use_search_filter because
    # j/k would be swallowed by the search prefix. We pick search over vim keys.
    question = _UI.q().select(
        message,
        choices=choices,
        qmark="●",
        pointer="❯",
        instruction=instruction or "↑↓ · type to search · enter select · esc back",
        use_indicator=True,
        use_jk_keys=False,
        use_search_filter=True,
        style=_UI.style(),
    )
    # Bind ESC explicitly — questionary's select prompt does not bind it by
    # default. With eager=True the binding fires before prompt_toolkit's
    # meta-key timeout. .unsafe_ask() returns the `result` we pass to exit().
    with contextlib.suppress(Exception):
        from prompt_toolkit.keys import Keys

        bindings = question.application.key_bindings

        @bindings.add(Keys.Escape, eager=True)
        def _escape(event: Any) -> None:
            event.app.exit(result=None)

    return question


def _pick_computer(
    config: RuntimeConfig,
    prompt: str,
    predicate: Callable[[dict[str, Any]], bool] | None = None,
) -> dict[str, Any] | None:
    """Fetch computers and let the user arrow-key through them.

    Returns the picked computer dict, or None on ESC / "← cancel".
    Ctrl-C propagates as KeyboardInterrupt.
    """
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    payload = client.list_computers()
    computers = payload.get("computers") or []
    if not isinstance(computers, list):
        computers = []
    if predicate is not None:
        computers = [c for c in computers if isinstance(c, dict) and predicate(c)]
    computers = sorted(computers, key=_computer_sort_key)
    if not computers:
        _UI.err().print("[yellow]no matching computers found[/yellow]")
        return None

    questionary = _UI.q()
    widths = _picker_widths(computers)
    choices = [
        questionary.Choice(title=_computer_choice_title(c, widths), value=c) for c in computers
    ]
    choices.append(questionary.Choice(title="← cancel", value=None))
    picked = _select_prompt(prompt, choices).unsafe_ask()
    return picked if isinstance(picked, dict) else None


# --------------------------------------------------------------------------- #
# Rich renderers                                                              #
# --------------------------------------------------------------------------- #


def _render_computer_panel(c: dict[str, Any], *, title: str = "computer") -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    body = Text()
    status = _computer_status_label(c)
    status_style = _computer_status_style(status)
    rows: list[tuple[str, str, str | None]] = [
        ("name", _computer_name(c), "bold white"),
        ("state", f"{_computer_status_dot(status)} {status}", status_style),
        ("share", str(c.get("visibility") or "public"), "bold white"),
        ("url", _computer_url_label(c) or "—", "white"),
        ("age", _computer_created_label(c) or "—", "dim"),
        ("id", str(c.get("id") or "—"), "dim"),
    ]
    for label, value, style in rows:
        body.append(f"{label:<8}", style="dim")
        body.append(value, style=style or "white")
        body.append("\n")
    _UI.console().print(Panel(body, title=title, border_style="cyan", expand=False, padding=(0, 1)))


def _render_run_result(result: dict[str, Any]) -> None:
    mods = _UI.rich()
    Panel = mods["Panel"]
    console = _UI.console()
    stdout = result.get("stdout") or ""
    stderr = result.get("stderr") or ""
    exit_code = result.get("exit_code")
    if stdout:
        console.print(Panel(stdout.rstrip(), title="stdout", border_style="green", expand=False))
    if stderr:
        console.print(Panel(stderr.rstrip(), title="stderr", border_style="red", expand=False))
    color = "green" if exit_code == 0 else "red"
    console.print(f"[{color}]exit {exit_code}[/{color}]")


def _render_network_panel(payload: dict[str, Any], *, title: str = "url") -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    body = Text()
    status = str(payload.get("status") or "unknown")
    published_port = payload.get("published_port")
    startup_port = payload.get("startup_port")
    rows: list[tuple[str, str, str | None]] = [
        ("url", str(payload.get("public_url") or "—"), "cyan"),
        ("state", f"{_computer_status_dot(status)} {status}", _computer_status_style(status)),
        ("share", str(payload.get("visibility") or "public"), "bold white"),
    ]
    if published_port:
        rows.append(("port", str(published_port), "bold white"))
    elif startup_port:
        rows.append(("port", str(startup_port), "bold white"))
        rows.append(("source", "durable startup", "dim"))
    else:
        rows.append(("port", "—", "dim"))
    if published_port and startup_port and startup_port != published_port:
        rows.append(("startup", str(startup_port), "dim"))
    for label, value, style in rows:
        body.append(f"{label:<8}", style="dim")
        body.append(value, style=style or "white")
        body.append("\n")
    _UI.console().print(Panel(body, title=title, border_style="cyan", expand=False, padding=(0, 1)))


def _render_startup_panel(payload: dict[str, Any], *, title: str = "startup") -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    body = Text()
    configured = bool(payload.get("configured"))
    rows: list[tuple[str, str, str | None]] = [("configured", "yes" if configured else "no", "bold white" if configured else "dim")]
    if payload.get("status"):
        rows.append(("status", str(payload.get("status")), "bold white"))
    if payload.get("public_url"):
        rows.append(("url", str(payload.get("public_url")), "cyan"))
    if configured:
        rows.extend(
            [
                ("command", str(payload.get("command") or "—"), "white"),
                ("cwd", str(payload.get("cwd") or "/home/ubuntu"), "dim"),
                ("port", str(payload.get("port") or "—"), "bold white"),
            ]
        )
        if payload.get("exec_id"):
            rows.append(("exec", str(payload.get("exec_id")), "dim"))
        if payload.get("started_at"):
            rows.append(("started", str(payload.get("started_at")), "dim"))
        if payload.get("exit_code") is not None:
            rows.append(("exit", str(payload.get("exit_code")), "red"))
    for label, value, style in rows:
        body.append(f"{label:<10}", style="dim")
        body.append(value, style=style or "white")
        body.append("\n")
    _UI.console().print(Panel(body, title=title, border_style="cyan", expand=False, padding=(0, 1)))


def _render_whoami_panel(payload: dict[str, Any]) -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    owner = payload.get("owner") or {}
    rows: list[tuple[str, Any]] = [
        ("email", owner.get("email")),
        ("name", owner.get("name")),
        ("account id", payload.get("account_id")),
        ("trust tier", payload.get("trust_tier")),
    ]
    body = Text()
    for label, value in rows:
        if value is None:
            continue
        body.append(f"{label:<12}", style="dim")
        body.append(f"{value}\n")
    _UI.console().print(Panel(body, title="whoami", border_style="cyan", expand=False))



def _api_key_status_label(key: dict[str, Any]) -> str:
    if key.get("revoked_at"):
        return "revoked"
    if key.get("last_used_at"):
        return "used"
    return "unused"



def _api_key_status_style(status: str) -> str:
    if status == "revoked":
        return "bold red"
    if status == "used":
        return "bold green"
    return "yellow"



def _render_api_keys_table(payload: dict[str, Any]) -> None:
    mods = _UI.rich()
    Table = mods["Table"]
    api_keys = payload.get("api_keys") or []
    if not isinstance(api_keys, list) or not api_keys:
        _UI.console().print("[yellow]no api keys found[/yellow]")
        return

    table = Table(title="API keys", expand=True, box=mods["box"].SIMPLE_HEAVY)
    table.add_column("ID", style="dim", no_wrap=True)
    table.add_column("Label", style="bold white")
    table.add_column("Prefix", style="white", no_wrap=True)
    table.add_column("Created", style="dim", no_wrap=True, justify="right")
    table.add_column("Last used", style="dim", no_wrap=True, justify="right")
    table.add_column("Status", no_wrap=True)

    for entry in api_keys:
        if not isinstance(entry, dict):
            continue
        status = _api_key_status_label(entry)
        style = _api_key_status_style(status)
        table.add_row(
            str(entry.get("id") or "—"),
            str(entry.get("label") or "—"),
            str(entry.get("key_prefix") or "—"),
            _relative_time_label(entry.get("created_at")) or "—",
            _relative_time_label(entry.get("last_used_at")) or "—",
            f"[{style}]{status}[/{style}]",
        )

    _UI.console().print(table)



def _render_api_key_created(payload: dict[str, Any]) -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    key = payload.get("key") or {}
    secret = str(payload.get("api_key") or "")
    body = Text()
    rows = [
        ("id", key.get("id")),
        ("label", key.get("label")),
        ("prefix", key.get("key_prefix")),
    ]
    for label, value in rows:
        if value is None:
            continue
        body.append(f"{label:<12}", style="dim")
        body.append(f"{value}\n")
    if secret:
        body.append("save now     ", style="bold yellow")
        body.append("this secret is only shown once\n", style="yellow")
        body.append("api key      ", style="dim")
        body.append(secret, style="bold white")
        body.append("\n")
    _UI.console().print(Panel(body, title="api key created", border_style="cyan", expand=False))



def _render_secret_sets_table(payload: dict[str, Any]) -> None:
    mods = _UI.rich()
    Table = mods["Table"]
    secret_sets = payload.get("secret_sets") or []
    if not isinstance(secret_sets, list) or not secret_sets:
        _UI.console().print("[yellow]no secret sets found[/yellow]")
        return

    table = Table(title="Secret sets", expand=True, box=mods["box"].SIMPLE_HEAVY)
    table.add_column("Slug", style="bold white")
    table.add_column("Keys", style="white")
    table.add_column("Updated", style="dim", no_wrap=True, justify="right")

    for entry in secret_sets:
        if not isinstance(entry, dict):
            continue
        keys = entry.get("keys") or []
        table.add_row(
            str(entry.get("slug") or "—"),
            ", ".join(str(key) for key in keys) or "—",
            _relative_time_label(entry.get("updated_at")) or "—",
        )

    _UI.console().print(table)



def _render_secret_set_panel(payload: dict[str, Any]) -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    body = Text()
    body.append(f"{'slug':<12}", style="dim")
    body.append(f"{payload.get('slug') or '—'}\n")
    body.append(f"{'keys':<12}", style="dim")
    body.append(", ".join(str(key) for key in (payload.get("keys") or [])) or "—")
    _UI.console().print(Panel(body, title="secret set", border_style="cyan", expand=False))


# --------------------------------------------------------------------------- #
# Command handlers                                                            #
# --------------------------------------------------------------------------- #


def _looks_like_api_key(value: str | None) -> bool:
    candidate = (value or "").strip()
    return candidate.startswith("rt_live_")


def _begin_verification_flow(config: RuntimeConfig, email: str, name: str | None) -> dict[str, Any]:
    client = RuntimeClient(base_url=config.base_url)
    result = client.start_verification(email, name)
    config.pending_signup = PendingSignup(
        flow_id=int(result["flow_id"]),
        email=email,
        expires_at=result.get("expires_at"),
    )
    save_config(config)
    return result



def _start_verification_flow(config: RuntimeConfig, email: str | None, name: str | None) -> int:
    if email is None:
        if not _interactive():
            return report_error("email is required")
        email = _prompt_text("Email")
        if not email:
            return report_error("email is required")

    result = _begin_verification_flow(config, email, name)

    def render(payload: dict[str, Any]) -> None:
        _UI.console().print(
            f"[green]✓[/green] verification code sent to [bold]{email}[/bold]"
        )
        _UI.console().print(
            f"[dim]then run:[/dim] runtime verify <code>"
        )

    return report_success(result, render)



def _interactive_email_auth_flow(config: RuntimeConfig, email: str | None, name: str | None) -> int:
    pending = config.pending_signup
    if email is None and pending is not None and pending.email:
        _UI.console().print(
            f"[green]✓[/green] verification code already sent to [bold]{pending.email}[/bold]"
        )
        code = _prompt_text("Verification code")
        if not code:
            return report_error("verification code is required")
        return handle_verify(config, code, pending.flow_id)

    if email is None:
        email = _prompt_text("Email")
        if not email:
            return report_error("email is required")

    _begin_verification_flow(config, email, name)
    _UI.console().print(
        f"[green]✓[/green] verification code sent to [bold]{email}[/bold]"
    )
    code = _prompt_text("Verification code")
    if not code:
        return report_error("verification code is required")
    return handle_verify(config, code, None)


def _login_with_api_key(config: RuntimeConfig, api_key: str | None) -> int:
    if api_key is None or api_key == "":
        if not _interactive():
            return report_error("api key is required")
        api_key = _prompt_password("API key")
        if not api_key:
            return report_error("api key is required")

    client = RuntimeClient(base_url=config.base_url, api_key=api_key)
    whoami = client.whoami()
    config.api_key = api_key
    config.pending_signup = None
    save_config(config)

    def render(_: dict[str, Any]) -> None:
        owner = whoami.get("owner") or {}
        email = owner.get("email")
        if email:
            _UI.console().print(f"[green]✓[/green] logged in as [bold]{email}[/bold]")
            return
        _UI.console().print("[green]✓[/green] api key saved")

    return report_success({"message": "logged in", **whoami}, render)


def handle_signup(config: RuntimeConfig, email: str | None, name: str | None) -> int:
    if _interactive():
        return _interactive_email_auth_flow(config, email, name)
    return _start_verification_flow(config, email, name)


def handle_verify(config: RuntimeConfig, code: str | None, flow_id: int | None) -> int:
    pending = config.pending_signup
    resolved_flow_id = flow_id or (pending.flow_id if pending else None)
    if not resolved_flow_id:
        return report_error("missing flow id; run login first or pass --flow-id")

    if code is None:
        if not _interactive():
            return report_error("verification code is required")
        code = _prompt_text("Verification code")
        if not code:
            return report_error("verification code is required")

    client = RuntimeClient(base_url=config.base_url)
    result = client.verify(resolved_flow_id, code)
    api_key = result.get("api_key")
    if api_key:
        config.api_key = api_key
    config.pending_signup = None
    save_config(config)

    def render(payload: dict[str, Any]) -> None:
        owner = payload.get("owner") or {}
        email = owner.get("email")
        if email:
            _UI.console().print(f"[green]✓[/green] verified, logged in as [bold]{email}[/bold]")
            return
        _UI.console().print("[green]✓[/green] verified, api key saved")

    return report_success(result, render)


def handle_login(
    config: RuntimeConfig,
    identifier: str | None,
    name: str | None,
    api_key: str | None,
) -> int:
    if api_key is not None:
        if identifier is not None:
            return report_error("pass either an email/api key argument or --api-key, not both")
        return _login_with_api_key(config, api_key)

    if _looks_like_api_key(identifier):
        return _login_with_api_key(config, identifier)

    if _interactive():
        return _interactive_email_auth_flow(config, identifier, name)
    return _start_verification_flow(config, identifier, name)


def handle_whoami(config: RuntimeConfig) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    result = client.whoami()
    return report_success(result, _render_whoami_panel)


def handle_logout(config: RuntimeConfig) -> int:
    had_api_key = config.api_key is not None
    revoked = False
    if config.api_key:
        try:
            RuntimeClient(base_url=config.base_url, api_key=config.api_key).logout()
            revoked = True
        except RuntimeAPIError:
            revoked = False

    config.api_key = None
    config.pending_signup = None
    save_config(config)

    message = "logged out"
    if had_api_key and not revoked:
        message = "logged out locally"

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(f"[green]✓[/green] {message}")

    return report_success({"message": message}, render)



def handle_api_keys_list(config: RuntimeConfig) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    return report_success(client.list_api_keys(), _render_api_keys_table)



def handle_api_keys_create(config: RuntimeConfig, label: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if label is None:
        if not _interactive():
            return report_error("label is required")
        label = _prompt_text("API key label")
        if not label:
            return report_error("label is required")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    result = client.create_api_key(label)
    return report_success(result, _render_api_key_created)



def handle_api_keys_revoke(config: RuntimeConfig, key_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if key_id is None:
        if not _interactive():
            return report_error("api key id is required")
        key_id = _prompt_text("API key id")
        if not key_id:
            return report_error("api key id is required")

    try:
        resolved_key_id = int(str(key_id).strip())
    except ValueError:
        return report_error("api key id must be a number")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    client.revoke_api_key(resolved_key_id)

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(f"[green]✓[/green] api key {resolved_key_id} revoked")

    return report_success({"id": resolved_key_id, "message": f"api key {resolved_key_id} revoked"}, render)



def _render_github_installations_table(payload: dict[str, Any]) -> None:
    mods = _UI.rich()
    Table = mods["Table"]
    installations = payload.get("installations") or []
    if not isinstance(installations, list) or not installations:
        _UI.console().print("[yellow]no GitHub installations found[/yellow]")
        return

    table = Table(title="GitHub", expand=True, box=mods["box"].SIMPLE_HEAVY)
    table.add_column("ID", style="bold white")
    table.add_column("Owner", style="white")
    table.add_column("Type", style="white")
    table.add_column("Repos", style="white")
    table.add_column("Status", style="white")

    for entry in installations:
        if not isinstance(entry, dict):
            continue
        status = "suspended" if entry.get("suspended") else "connected"
        table.add_row(
            str(entry.get("id") or "—"),
            str(entry.get("github_account_login") or "—"),
            str(entry.get("github_account_type") or "—"),
            str(entry.get("repository_selection") or "—"),
            status,
        )
    _UI.console().print(table)



def _coerce_secret_set_slug(slug: str | None) -> str | None:
    value = str(slug or "").strip()
    return value or None



def _parse_secret_pairs(pairs: list[str] | None) -> dict[str, str]:
    values: dict[str, str] = {}
    for pair in pairs or []:
        if "=" not in pair:
            raise RuntimeConfigError(f"invalid secret pair: {pair}")
        key, value = pair.split("=", 1)
        key = key.strip()
        if not key:
            raise RuntimeConfigError(f"invalid secret pair: {pair}")
        values[key] = value
    return values



def _parse_env_file(path: str) -> dict[str, str]:
    try:
        lines = Path(path).read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise RuntimeConfigError(f"failed to read env file: {exc}") from exc
    values: dict[str, str] = {}
    for raw_line in lines:
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export "):].strip()
        if "=" not in line:
            raise RuntimeConfigError(f"invalid env line: {raw_line}")
        key, value = line.split("=", 1)
        key = key.strip()
        if not key:
            raise RuntimeConfigError(f"invalid env line: {raw_line}")
        value = value.strip()
        if value and value[0] == value[-1] and value[0] in {'\"', "'"}:
            value = value[1:-1]
        values[key] = value
    return values



def handle_secrets_list(config: RuntimeConfig) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    return report_success(client.list_secret_sets(), _render_secret_sets_table)



def handle_secrets_show(config: RuntimeConfig, slug: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    resolved_slug = _coerce_secret_set_slug(slug)
    if resolved_slug is None:
        if not _interactive():
            return report_error("secret set slug is required")
        resolved_slug = _prompt_text("Secret set slug")
        if not resolved_slug:
            return report_error("secret set slug is required")
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    return report_success(client.get_secret_set(resolved_slug), _render_secret_set_panel)



def handle_secrets_set(config: RuntimeConfig, slug: str | None, pairs: list[str] | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    resolved_slug = _coerce_secret_set_slug(slug)
    if resolved_slug is None:
        if not _interactive():
            return report_error("secret set slug is required")
        resolved_slug = _prompt_text("Secret set slug")
        if not resolved_slug:
            return report_error("secret set slug is required")
    values = _parse_secret_pairs(pairs)
    if not values:
        return report_error("at least one KEY=VALUE pair is required")
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    secret_set = client.put_secret_set(resolved_slug, values)
    return report_success(
        {"secret_set": secret_set},
        lambda payload: _UI.console().print(f"[green]✓[/green] saved [bold]{payload['secret_set'].get('slug', resolved_slug)}[/bold]"),
    )



def handle_secrets_import(config: RuntimeConfig, slug: str | None, env_file: str) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    resolved_slug = _coerce_secret_set_slug(slug)
    if resolved_slug is None:
        if not _interactive():
            return report_error("secret set slug is required")
        resolved_slug = _prompt_text("Secret set slug")
        if not resolved_slug:
            return report_error("secret set slug is required")
    values = _parse_env_file(env_file)
    if not values:
        return report_error("env file did not contain any secrets")
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    secret_set = client.put_secret_set(resolved_slug, values)
    return report_success(
        {"secret_set": secret_set},
        lambda payload: _UI.console().print(f"[green]✓[/green] saved [bold]{payload['secret_set'].get('slug', resolved_slug)}[/bold] from [bold]{env_file}[/bold]"),
    )



def handle_secrets_delete(config: RuntimeConfig, slug: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    resolved_slug = _coerce_secret_set_slug(slug)
    if resolved_slug is None:
        if not _interactive():
            return report_error("secret set slug is required")
        resolved_slug = _prompt_text("Secret set slug")
        if not resolved_slug:
            return report_error("secret set slug is required")
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    client.delete_secret_set(resolved_slug)
    return report_success(
        {"slug": resolved_slug, "deleted": True},
        lambda payload: _UI.console().print(f"[green]✓[/green] deleted [bold]{payload['slug']}[/bold]"),
    )



def handle_github_list(config: RuntimeConfig) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    return report_success(client.list_github_installations(), _render_github_installations_table)



def handle_github_disconnect(config: RuntimeConfig, ref: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    resolved_ref = str(ref or "").strip()
    if not resolved_ref:
        if not _interactive():
            return report_error("github owner or installation id is required")
        resolved_ref = _prompt_text("GitHub owner or installation id")
        if not resolved_ref:
            return report_error("github owner or installation id is required")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    installation_id: int | None = None
    owner = resolved_ref

    try:
        installation_id = int(resolved_ref)
    except ValueError:
        payload = client.list_github_installations()
        installations = payload.get("installations") or []
        target_owner = resolved_ref.casefold()
        match = next(
            (
                entry
                for entry in installations
                if isinstance(entry, dict) and str(entry.get("github_account_login") or "").strip().casefold() == target_owner
            ),
            None,
        )
        if match is None:
            return report_error(f"github installation not found: {resolved_ref}")
        try:
            installation_id = int(match.get("id"))
        except (TypeError, ValueError):
            return report_error(f"github installation is missing an id: {resolved_ref}")
        owner = str(match.get("github_account_login") or resolved_ref)

    if installation_id is None or installation_id <= 0:
        return report_error("installation id must be a positive number")

    client.disconnect_github_installation(installation_id)
    return report_success(
        {"id": installation_id, "owner": owner, "deleted": True},
        lambda payload: _UI.console().print(f"[green]✓[/green] disconnected [bold]{payload['owner']}[/bold]"),
    )



def handle_integrate_github(
    config: RuntimeConfig,
    provider: str,
    *,
    no_open: bool = False,
    timeout_seconds: int = 180,
) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if provider != "github":
        return report_error(f"unsupported integration provider: {provider}")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    payload = _with_spinner("getting GitHub install link…", client.start_github_connect)
    install_url = str(payload.get("install_url") or "").strip()
    session_id = int(payload.get("session_id") or 0)
    if not install_url or session_id <= 0:
        return report_error("server did not return a GitHub install session")

    opened = False
    if not no_open:
        with contextlib.suppress(Exception):
            opened = bool(webbrowser.open(install_url))

    if _interactive():
        action = "opened in your browser" if opened else "copy this URL into your browser"
        _UI.console().print(f"[cyan]→[/cyan] {action}: [link={install_url}]{install_url}[/link]")
        _UI.console().print("[dim]Choose the GitHub account/org and repo access in GitHub. Waiting for completion…[/dim]")

    deadline = time.time() + max(1, int(timeout_seconds))
    last_status = "pending"
    while time.time() < deadline:
        session = client.get_github_connect_session(session_id)
        status = str(session.get("status") or "pending")
        last_status = status
        if status == "completed":
            installation = session.get("installation") or {}
            owner = str(installation.get("github_account_login") or "github")
            return report_success(
                {"installation": installation, "install_url": install_url, "session_id": session_id},
                lambda result: _UI.console().print(f"[green]✓[/green] connected [bold]{(result.get('installation') or {}).get('github_account_login', owner)}[/bold]"),
            )
        if status in {"failed", "expired"}:
            return report_error(str(session.get("error") or f"github connect {status}"))
        time.sleep(2)

    return report_error(f"timed out waiting for GitHub install to finish (last status: {last_status})")



def handle_switch(
    config: RuntimeConfig,
    repo: str | None,
    branch: str | None,
    *,
    create_branch: bool = False,
    base_branch: str | None = None,
) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if base_branch is not None and not create_branch:
        return report_error("--from can only be used together with -c")

    try:
        resolved_repo = _coerce_github_repo(repo)
        resolved_branch = _coerce_git_branch(branch)
    except RuntimeAPIError as exc:
        return report_error(str(exc), status_code=exc.status_code)

    if resolved_repo is None:
        if not _interactive():
            return report_error("--repo is required")
        resolved_repo = _prompt_text("GitHub repo (owner/name)")
        try:
            resolved_repo = _coerce_github_repo(resolved_repo)
        except RuntimeAPIError as exc:
            return report_error(str(exc), status_code=exc.status_code)
        if resolved_repo is None:
            return report_error("repo is required")

    if resolved_branch is None:
        if not _interactive():
            return report_error("branch is required")
        prompt = "New branch name" if create_branch else "Branch name"
        resolved_branch = _prompt_text(prompt)
        try:
            resolved_branch = _coerce_git_branch(resolved_branch)
        except RuntimeAPIError as exc:
            return report_error(str(exc), status_code=exc.status_code)
        if resolved_branch is None:
            return report_error("branch is required")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    try:
        payload = _with_spinner(
            "opening branch workspace…",
            lambda: client.switch_workspace(
                repo=resolved_repo,
                branch=resolved_branch,
                create=create_branch,
                base_branch=base_branch,
            ),
        )
    except RuntimeAPIError as exc:
        return report_error(str(exc), status_code=exc.status_code)

    computer = payload.get("computer") or {}
    computer_id = str(computer.get("id") or "").strip()
    if not computer_id:
        return report_error("server did not return a computer id")

    code = report_success(payload, _render_branch_workspace)
    if code != 0 or not _interactive():
        return code
    return _enter_computer(config, computer_id)



def handle_onboarding(config: RuntimeConfig) -> int:
    code = handle_login(config, None, None, None)
    if code != 0:
        return code
    return handle_create(config, None, None, None, None)



def handle_create(
    config: RuntimeConfig,
    name: str | None,
    startup_command: str | None,
    cwd: str | None,
    port: int | None,
) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if name is None and _interactive():
        name = _prompt_text("Name your computer")

    if startup_command is None and port is not None:
        return report_error("startup command is required when port is provided")
    if startup_command is not None and port is None:
        return report_error("port is required when startup command is provided")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    label = "creating computer…"
    if startup_command is not None:
        label = f"creating computer and starting app on port {port}…"
    try:
        result = _with_spinner(
            label,
            lambda: client.create_computer(slug=name, command=startup_command, cwd=cwd, port=port),
        )
    except RuntimeAPIError as exc:
        if exc.status_code == 409 and "slug already in use" in str(exc) and name:
            return report_error(
                f"computer name {name!r} is already in use. Names become public URL slugs and must be globally unique across active and cold computers. If it is yours, pick it from `runtime list` or delete it; otherwise choose a different name.",
                status_code=exc.status_code,
            )
        raise

    def render(payload: dict[str, Any]) -> None:
        _render_computer_panel(payload, title="created")
        url = payload.get("public_url")
        if url:
            _UI.console().print(f"[bold green]→[/bold green] [cyan]{url}[/cyan]")

    code = report_success(result, render)
    if code != 0 or not _interactive():
        return code

    computer_id = result.get("id") or result.get("slug")
    if not computer_id:
        return code
    return _enter_computer(config, str(computer_id))


def handle_list(config: RuntimeConfig, *, watch: int | None = None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if watch is not None:
        if not _interactive():
            return report_error("--watch requires an interactive terminal")
        interval = max(1, int(watch))
        return _watch_list(config, interval)

    if _interactive():
        return _interactive_list(config)

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    return report_success(client.list_computers())


def _watch_list(config: RuntimeConfig, interval: int) -> int:
    from rich.live import Live

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    console = _UI.console()
    console.print(f"[dim]watching every {interval}s · press Ctrl+C to exit[/dim]")

    def render_table() -> Any:
        mods = _UI.rich()
        Table, box = mods["Table"], mods["box"]
        table = Table(
            title=f"computers · refresh {interval}s · {datetime.now().strftime('%H:%M:%S')}",
            box=box.MINIMAL_DOUBLE_HEAD,
            expand=True,
            header_style="bold #7dd3fc",
            title_style="bold white",
            row_styles=["", "dim"],
        )
        table.add_column("Name", style="bold white", no_wrap=True, ratio=2)
        table.add_column("State", no_wrap=True, ratio=2)
        table.add_column("URL", overflow="fold", ratio=4)
        table.add_column("Age", style="dim", justify="right", ratio=1)
        try:
            payload = client.list_computers()
        except RuntimeAPIError as exc:
            table.add_row(f"[red]error: {exc}[/red]", "", "", "")
            return table
        computers = payload.get("computers") or []
        if not isinstance(computers, list):
            computers = []
        for computer in sorted(computers, key=_computer_sort_key):
            status = _computer_status_label(computer)
            style = _computer_status_style(status)
            table.add_row(
                _computer_name(computer),
                f"[{style}]{_computer_status_dot(status)} {status}[/{style}]",
                _computer_url_label(computer),
                _computer_created_label(computer),
            )
        if not computers:
            table.add_row("[dim]no computers yet[/dim]", "", "", "")
        return table

    try:
        with Live(render_table(), console=console, refresh_per_second=4, screen=False) as live:
            while True:
                time.sleep(interval)
                live.update(render_table())
    except KeyboardInterrupt:
        console.print("[dim]watch stopped[/dim]")
        return 0


def handle_info(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = client.get_computer(computer_id)
    return report_success(result, lambda p: _render_computer_panel(p, title="computer"))


def handle_url(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = client.get_computer_network(computer_id)
    return report_success(result, lambda p: _render_network_panel(p, title="url"))


def handle_share(config: RuntimeConfig, visibility: str | None, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if visibility not in ("public", "private"):
        return report_error("share target must be public or private")

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(
        f"setting {computer_id} to {visibility}…",
        lambda: client.set_visibility(computer_id, visibility),
    )

    def render(payload: dict[str, Any]) -> None:
        _render_computer_panel(payload, title="share")
        _UI.console().print(f"[green]✓[/green] [bold]{computer_id}[/bold] is now [bold]{visibility}[/bold]")

    return report_success(result, render)


def handle_startup_show(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = client.get_startup_config(computer_id)
    return report_success(result, lambda p: _render_startup_panel(p, title="startup"))


def handle_startup_set(
    config: RuntimeConfig,
    computer_id: str | None,
    command: str | None,
    cwd: str | None,
    port: int | None,
) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if not computer_id:
        return report_error("computer id is required")
    if not command:
        return report_error("startup command is required")
    if port is None:
        return report_error("port is required")
    if port <= 0 or port > 65535:
        return report_error("port must be between 1 and 65535")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(
        f"saving startup config for {computer_id}…",
        lambda: client.set_startup_config(computer_id, command=command, cwd=cwd, port=port),
    )
    return report_success(result, lambda p: _render_startup_panel(p, title="startup saved"))


def handle_startup_clear(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if not computer_id:
        return report_error("computer id is required")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(
        f"clearing startup config for {computer_id}…",
        lambda: client.clear_startup_config(computer_id),
    )

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(f"[green]✓[/green] cleared durable startup config for [bold]{computer_id}[/bold]")

    return report_success(result or {"configured": False}, render)


def _command_from_remainder(parts: list[str] | None) -> str | None:
    if not parts:
        return None
    if parts and parts[0] == "--":
        parts = parts[1:]
    if not parts:
        return None
    return shlex.join(parts)


def handle_service_run(config: RuntimeConfig, computer_id: str | None, port: int | None, cwd: str | None, command_parts: list[str] | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if not computer_id:
        return report_error("computer id is required")
    if port is None or port <= 0 or port > 65535:
        return report_error("port must be between 1 and 65535")
    command = _command_from_remainder(command_parts)
    if not command:
        return report_error("service run requires -- <command...>")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(
        f"starting service on {computer_id}…",
        lambda: client.run_service(computer_id, command=command, cwd=cwd, port=port),
    )
    return report_success(result, lambda p: _render_startup_panel(p, title="service"))


def handle_service_show(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = client.get_service_config(computer_id)
    return report_success(result, lambda p: _render_startup_panel(p, title="service"))


def handle_service_logs(config: RuntimeConfig, computer_id: str | None, follow: bool) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if not computer_id:
        return report_error("computer id is required")
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    for line in client.stream_service_logs(computer_id, follow=follow):
        try:
            frame = json.loads(line)
        except ValueError:
            print(line)
            continue
        stdout = frame.get("stdout") or ""
        stderr = frame.get("stderr") or ""
        data = frame.get("data") or ""
        error = frame.get("error") or ""
        if stdout:
            print(stdout, end="")
        if stderr:
            print(stderr, end="", file=sys.stderr)
        if data:
            print(data, end="")
        if error:
            print(error, file=sys.stderr)
    return 0


def handle_service_restart(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if not computer_id:
        return report_error("computer id is required")
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(f"restarting service for {computer_id}…", lambda: client.restart_service(computer_id))
    return report_success(result, lambda p: _render_startup_panel(p, title="service restarted"))


def handle_service_stop(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if not computer_id:
        return report_error("computer id is required")
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(f"stopping service for {computer_id}…", lambda: client.stop_service(computer_id))
    return report_success(result, lambda p: _render_startup_panel(p, title="service stopped"))


def handle_service_clear(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if not computer_id:
        return report_error("computer id is required")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(
        f"clearing service for {computer_id}…",
        lambda: client.clear_service_config(computer_id),
    )

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(f"[green]✓[/green] cleared durable service for [bold]{computer_id}[/bold]")

    return report_success(result or {"configured": False}, render)


def handle_start(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(
            config,
            "Pick a cold computer to wake",
            lambda c: _computer_power_state(c) == "cold",
        )
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(f"warming {computer_id}…", lambda: client.start_computer(computer_id))

    def render(payload: dict[str, Any]) -> None:
        _render_computer_panel(payload, title="warmed")
        url = payload.get("public_url")
        if url:
            _UI.console().print(f"[bold green]→[/bold green] [cyan]{url}[/cyan]")

    return report_success(result, render)


def handle_enter(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if not _interactive():
        return report_error("enter requires an interactive terminal")

    if computer_id is None:
        picked = _pick_computer(
            config,
            "Pick a computer to enter",
            lambda c: _computer_internal_status(c) in ("running", "cold"),
        )
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, str(computer_id))
    return _enter_computer(config, str(computer_id))


def handle_delete(config: RuntimeConfig, computer_id: str | None, *, force: bool = False) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer to delete")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    # In TTY mode, require the user to retype the slug as confirmation
    # unless --force was passed. Non-TTY callers stay script-friendly.
    if _interactive() and not force:
        if not _prompt_typed_confirm(
            f"Delete {computer_id}? This permanently destroys filesystem, service, and public URL.",
            str(computer_id),
        ):
            _UI.console().print("[dim]cancelled[/dim]")
            return 0

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    display_ref = computer_id
    computer_id = _resolve_computer_ref(client, computer_id)
    client.delete_computer(computer_id)

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(f"[green]✓[/green] deleted [bold]{display_ref}[/bold]")

    return report_success({"message": f"computer {display_ref} deleted"}, render)


def handle_run(
    config: RuntimeConfig,
    computer_id: str | None,
    command: str | None,
    uid: int | None,
    gid: int | None,
    cwd: str | None,
    shell: str | None,
) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(
            config,
            "Pick a computer",
            lambda c: _computer_internal_status(c) == "running",
        )
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    if command is None:
        if not _interactive():
            return report_error("command is required")
        command = _prompt_text("Command to run")
        if not command:
            return report_error("command is required")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(
        f"running on {computer_id}…",
        lambda: client.run_command(
            computer_id, command, uid=uid, gid=gid, cwd=cwd, shell=shell
        ),
    )
    return report_success(result, _render_run_result)


def handle_publish(config: RuntimeConfig, computer_id: str | None, port: int | None, command_parts: list[str] | None = None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(
            config,
            "Pick a computer",
            lambda c: _computer_internal_status(c) == "running",
        )
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    if port is None:
        if not _interactive():
            return report_error("port is required")
        port_text = _prompt_text("Port to publish", default="3000")
        if not port_text:
            return report_error("port is required")
        try:
            port = int(port_text)
        except ValueError:
            return report_error("port must be a number")

    if port <= 0 or port > 65535:
        return report_error("port must be between 1 and 65535")

    command = _command_from_remainder(command_parts)
    if not command:
        return report_error(f"publish requires -- <command...>, for example: runtime publish {computer_id} {port} -- npm run dev -- --host 0.0.0.0")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(
        f"publishing service on {computer_id}…",
        lambda: client.publish_port(computer_id, port, command=command),
    )
    return report_success(result, lambda p: _render_startup_panel(p, title="service"))


def handle_proxy_start(config: RuntimeConfig, computer_id: str | None, specs: list[str] | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if not computer_id:
        return report_error("computer id is required")
    if not specs:
        return report_error("at least one port mapping is required")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    resolved_id = _resolve_computer_ref(client, computer_id)
    existing_records = _load_proxy_records(clean_stale=True)
    existing_ports = {int(r.get("local_port") or 0) for r in existing_records}
    mappings: list[tuple[int, int]] = []
    seen_ports: set[int] = set()
    for spec in specs:
        local_port, remote_port = _parse_proxy_port_spec(spec)
        if local_port in existing_ports:
            return report_error(f"local port {local_port} is already in use by a runtime proxy")
        if local_port in seen_ports:
            return report_error(f"local port {local_port} was specified more than once")
        seen_ports.add(local_port)
        mappings.append((local_port, remote_port))

    started: list[dict[str, Any]] = []
    started_ports: list[int] = []
    for local_port, remote_port in mappings:
        try:
            _spawn_proxy_agent(config.base_url, str(config.api_key or ""), resolved_id, computer_id, local_port, remote_port)
        except RuntimeAPIError as exc:
            if started_ports:
                _stop_proxy_ports(started_ports, stop_all=False)
            return report_error(str(exc), status_code=exc.status_code)
        except Exception as exc:
            if started_ports:
                _stop_proxy_ports(started_ports, stop_all=False)
            return report_error(str(exc))
        started_ports.append(local_port)
        started.append({"computer_id": resolved_id, "computer": computer_id, "local_port": local_port, "remote_port": remote_port})

    def render(payload: dict[str, Any]) -> None:
        _UI.console().print("[green]✓[/green] proxy started")
        for proxy in payload.get("proxies", []):
            _UI.console().print(
                f"  [bold]localhost:{proxy['local_port']}[/bold] -> [cyan]{proxy['computer']}[/cyan]:{proxy['remote_port']}"
            )

    return report_success({"proxies": started}, render)


def handle_proxy_ls(config: RuntimeConfig) -> int:
    proxies = _load_proxy_records(clean_stale=True)

    def render(payload: dict[str, Any]) -> None:
        mods = _UI.rich()
        Table = mods["Table"]
        table = Table(title="proxies")
        table.add_column("VM", style="white")
        table.add_column("Local", style="cyan")
        table.add_column("Remote", style="white")
        table.add_column("Status", style="green")
        for proxy in payload.get("proxies", []):
            table.add_row(
                str(proxy.get("display_name") or proxy.get("computer_id") or "—"),
                str(proxy.get("local_port") or "—"),
                str(proxy.get("remote_port") or "—"),
                str(proxy.get("status") or "unknown"),
            )
        _UI.console().print(table)

    return report_success({"proxies": proxies}, render if _interactive() else None)


def handle_proxy_stop(config: RuntimeConfig, local_ports: list[int] | None, *, stop_all: bool = False) -> int:
    if not stop_all and not local_ports:
        return report_error("pass one or more local ports, or use --all")

    stopped = _stop_proxy_ports(local_ports or [], stop_all=stop_all)

    def render(payload: dict[str, Any]) -> None:
        _UI.console().print("[green]✓[/green] proxy stopped")
        for proxy in payload.get("proxies", []):
            _UI.console().print(
                f"  [bold]localhost:{proxy.get('local_port')}[/bold] -> [cyan]{proxy.get('display_name') or proxy.get('computer_id')}[/cyan]:{proxy.get('remote_port')}"
            )

    return report_success({"proxies": stopped}, render if _interactive() else None)


def _proxy_preflight(base_url: str, api_key: str, computer_id: str, remote_port: int) -> None:
    client = RuntimeClient(base_url=base_url, api_key=api_key)
    ticket_payload = client.create_proxy_ticket(computer_id, remote_port)
    ws_url = _resolve_ws_url(base_url, ticket_payload.get("ws_url"))
    if not ws_url:
        raise RuntimeAPIError("proxy endpoint did not return a websocket url")
    with websocket_connect(ws_url, open_timeout=DEFAULT_WARMUP_TIMEOUT, close_timeout=1, max_size=None):
        return



def run_proxy_agent(base_url: str, api_key: str, computer_id: str, display_name: str, local_port: int, remote_port: int) -> int:
    if not api_key:
        print("proxy agent missing api key", file=sys.stderr)
        return 1

    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        listener.bind(("127.0.0.1", local_port))
        listener.listen()
        listener.settimeout(1.0)
    except OSError as exc:
        print(f"proxy listen failed on localhost:{local_port}: {exc}", file=sys.stderr)
        return 1

    try:
        _proxy_preflight(base_url, api_key, computer_id, remote_port)
    except Exception as exc:
        with contextlib.suppress(OSError):
            listener.close()
        print(f"proxy preflight failed for localhost:{local_port} -> {computer_id}:{remote_port}: {exc}", file=sys.stderr)
        return 1

    proxy_dir = _proxy_dir()
    proxy_dir.mkdir(parents=True, exist_ok=True)
    state = {
        "pid": os.getpid(),
        "computer_id": computer_id,
        "display_name": display_name,
        "local_port": local_port,
        "remote_port": remote_port,
        "started_at": datetime.now(timezone.utc).isoformat(),
    }
    _proxy_state_path(local_port).write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")

    stop_event = threading.Event()

    def handle_signal(_signum: int, _frame: Any) -> None:
        stop_event.set()
        with contextlib.suppress(OSError):
            listener.close()

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    try:
        while not stop_event.is_set():
            try:
                conn, _ = listener.accept()
            except socket.timeout:
                continue
            except OSError:
                if stop_event.is_set():
                    break
                continue
            thread = threading.Thread(
                target=_handle_proxy_client,
                args=(base_url, api_key, computer_id, remote_port, conn),
                daemon=True,
            )
            thread.start()
    finally:
        with contextlib.suppress(OSError):
            listener.close()
        _remove_proxy_state(local_port)
    return 0


def _handle_proxy_client(base_url: str, api_key: str, computer_id: str, remote_port: int, conn: socket.socket) -> None:
    client = RuntimeClient(base_url=base_url, api_key=api_key)
    try:
        ticket_payload = client.create_proxy_ticket(computer_id, remote_port)
        ws_url = _resolve_ws_url(base_url, ticket_payload.get("ws_url"))
        if not ws_url:
            raise RuntimeAPIError("proxy endpoint did not return a websocket url")
        with websocket_connect(ws_url, open_timeout=DEFAULT_WARMUP_TIMEOUT, close_timeout=1, max_size=None) as ws:
            stop = threading.Event()

            def local_to_ws() -> None:
                try:
                    while not stop.is_set():
                        data = conn.recv(65536)
                        if not data:
                            break
                        ws.send(data)
                except Exception:
                    pass
                finally:
                    stop.set()
                    with contextlib.suppress(Exception):
                        ws.close()

            def ws_to_local() -> None:
                try:
                    while not stop.is_set():
                        data = ws.recv()
                        if data is None:
                            break
                        if isinstance(data, str):
                            chunk = data.encode()
                        else:
                            chunk = data
                        if chunk:
                            conn.sendall(chunk)
                except Exception:
                    pass
                finally:
                    stop.set()
                    with contextlib.suppress(OSError):
                        conn.shutdown(socket.SHUT_RDWR)

            t1 = threading.Thread(target=local_to_ws, daemon=True)
            t2 = threading.Thread(target=ws_to_local, daemon=True)
            t1.start()
            t2.start()
            t1.join()
            t2.join()
    except Exception as exc:
        print(f"proxy connection failed for localhost:{conn.getsockname()[1]} -> {computer_id}:{remote_port}: {exc}", file=sys.stderr)
    finally:
        with contextlib.suppress(OSError):
            conn.close()


def _enter_computer(config: RuntimeConfig, computer_id: str) -> int:
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    ticket_payload = _with_spinner(
        f"preparing console for {computer_id}…",
        lambda: client.create_terminal_ticket(computer_id),
    )
    ws_url = _resolve_ws_url(config.base_url, ticket_payload.get("ws_url"))
    if not ws_url:
        return report_error("terminal endpoint did not return a websocket url")

    _UI.console().print("[cyan]●[/cyan] Connecting to console...")

    try:
        return _run_terminal_session(ws_url)
    except RuntimeAPIError as exc:
        return report_error(str(exc), status_code=exc.status_code)
    except (InvalidHandshake, TimeoutError, OSError) as exc:
        return report_error(f"terminal failed: {exc}")


def _load_posix_tty_modules() -> tuple[Any, Any]:
    try:
        termios_mod = importlib.import_module("termios")
        tty_mod = importlib.import_module("tty")
    except ModuleNotFoundError as exc:
        raise RuntimeAPIError(
            "interactive console is not supported on this platform yet; use `runtime run` for one-shot commands"
        ) from exc
    return termios_mod, tty_mod


TERMINAL_FRAME_DATA = 0x01
TERMINAL_FRAME_WINDOW_SIZE = 0x02
TERMINAL_FRAME_SHUTDOWN = 0x03
TERMINAL_FRAME_HEARTBEAT = 0x04
TERMINAL_FRAME_SESSION_CLOSE = 0x05
TERMINAL_FRAME_HEADER_SIZE = 5


def _encode_terminal_frame(frame_type: int, payload: bytes = b"") -> bytes:
    return bytes([frame_type]) + struct.pack(">I", len(payload)) + payload


def _parse_terminal_frame(raw: bytes) -> tuple[int, bytes]:
    if len(raw) < TERMINAL_FRAME_HEADER_SIZE:
        raise RuntimeAPIError("terminal received a truncated frame")
    payload_len = struct.unpack(">I", raw[1:TERMINAL_FRAME_HEADER_SIZE])[0]
    if len(raw) != TERMINAL_FRAME_HEADER_SIZE + payload_len:
        raise RuntimeAPIError("terminal received a malformed frame")
    return raw[0], raw[TERMINAL_FRAME_HEADER_SIZE:]


def _run_terminal_session(ws_url: str) -> int:
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return report_error("enter requires an interactive terminal")

    termios_mod, tty_mod = _load_posix_tty_modules()
    fd = sys.stdin.fileno()
    old_settings = termios_mod.tcgetattr(fd)
    stop = threading.Event()
    result: dict[str, Any] = {"code": 0, "error": None}
    output_state: dict[str, Any] = {"buffer": "", "suppressing_preamble": True}

    with websocket_connect(ws_url, open_timeout=DEFAULT_WARMUP_TIMEOUT, close_timeout=1) as ws:
        _send_terminal_resize(ws)

        def recv_loop() -> None:
            try:
                while not stop.is_set():
                    raw = ws.recv()
                    if raw is None:
                        result["code"] = 0
                        stop.set()
                        return
                    if not isinstance(raw, bytes):
                        raise RuntimeAPIError("terminal received a non-binary frame")
                    frame_type, payload = _parse_terminal_frame(raw)
                    if frame_type == TERMINAL_FRAME_HEARTBEAT:
                        continue
                    if frame_type == TERMINAL_FRAME_DATA:
                        data = _filter_terminal_output(payload.decode("utf-8", errors="ignore"), output_state)
                        if data:
                            sys.stdout.write(data)
                            sys.stdout.flush()
                        continue
                    if frame_type in (TERMINAL_FRAME_SHUTDOWN, TERMINAL_FRAME_SESSION_CLOSE):
                        stop.set()
                        return
            except ConnectionClosed:
                if not stop.is_set() and not result.get("error") and int(result.get("code") or 0) == 0:
                    result["code"] = 1
                    result["error"] = "terminal connection closed unexpectedly"
                stop.set()
            except Exception as exc:  # pragma: no cover - defensive for real TTY sessions
                result["code"] = 1
                result["error"] = str(exc)
                stop.set()

        recv_thread = threading.Thread(target=recv_loop, daemon=True)
        recv_thread.start()

        last_size = shutil.get_terminal_size((100, 24))
        try:
            tty_mod.setraw(fd)
            while not stop.is_set():
                current_size = shutil.get_terminal_size((100, 24))
                if current_size != last_size:
                    _send_terminal_resize(ws)
                    last_size = current_size

                readable, _, _ = select.select([fd], [], [], 0.1)
                if fd not in readable:
                    continue
                data = os.read(fd, 1024)
                if not data:
                    stop.set()
                    break
                ws.send(_encode_terminal_frame(TERMINAL_FRAME_DATA, data))
        finally:
            stop.set()
            with contextlib.suppress(Exception):
                ws.send(_encode_terminal_frame(TERMINAL_FRAME_SHUTDOWN))
            with contextlib.suppress(Exception):
                ws.close()
            termios_mod.tcsetattr(fd, termios_mod.TCSADRAIN, old_settings)
            recv_thread.join(timeout=1)

    sys.stdout.write("\n")
    sys.stdout.flush()
    tail = _flush_terminal_output(output_state)
    if tail:
        sys.stdout.write(tail)
        sys.stdout.flush()
    if result.get("error"):
        _UI.err().print(f"[bold red]✗[/bold red] {result['error']}")
    return int(result.get("code") or 0)


def _filter_terminal_output(chunk: str, state: dict[str, Any]) -> str:
    if not chunk:
        return ""
    if not state.get("suppressing_preamble", False):
        return _strip_terminal_noise(chunk)

    buffer = str(state.get("buffer") or "") + chunk
    marker = "\x1b[1;34mruntime@"
    idx = buffer.find(marker)
    if idx != -1:
        state["suppressing_preamble"] = False
        state["buffer"] = ""
        return _strip_terminal_noise(buffer[idx:])

    cleaned = _strip_terminal_noise(buffer)
    if cleaned and _should_release_terminal_output(cleaned):
        state["suppressing_preamble"] = False
        state["buffer"] = ""
        return cleaned

    if len(buffer) > 8192:
        state["suppressing_preamble"] = False
        state["buffer"] = ""
        return _strip_terminal_noise(buffer)

    state["buffer"] = buffer
    return ""



def _should_release_terminal_output(text: str) -> bool:
    if not text:
        return False
    if "\n" in text or "\r" in text:
        return True
    if len(text) >= 256:
        return True

    stripped = text.rstrip()
    return text.endswith(("$ ", "# ", "% ", "> ")) or stripped.endswith(("$", "#", "%", ">"))



def _flush_terminal_output(state: dict[str, Any]) -> str:
    buffer = str(state.get("buffer") or "")
    state["buffer"] = ""
    return _strip_terminal_noise(buffer)


def _strip_terminal_noise(text: str) -> str:
    if not text:
        return ""

    lines = text.splitlines(keepends=True)
    filtered: list[str] = []
    for line in lines:
        stripped = line.rstrip("\r\n")
        if stripped.startswith("Running bootstrap command: export PS1='\\[\\033[1;34m\\]runtime@"):
            continue
        if stripped == "Connected! Press Ctrl+] to exit.":
            continue
        if stripped == "* Image built by SlicerVM (2026)":
            continue
        if stripped == "* Website: https://slicervm.com":
            continue
        if stripped == "* Docs: https://docs.slicervm.com":
            continue
        filtered.append(line)
    return "".join(filtered)


def _send_terminal_resize(ws: Any) -> None:
    size = shutil.get_terminal_size((100, 24))
    ws.send(_encode_terminal_frame(TERMINAL_FRAME_WINDOW_SIZE, struct.pack(">II", size.columns, size.lines)))


# --------------------------------------------------------------------------- #
# Interactive list → detail → action loop                                    #
# --------------------------------------------------------------------------- #


def _interactive_list(config: RuntimeConfig) -> int:
    """Interactive top-level menu: picker is the display, no separate table.

    ESC / Ctrl+C / "✕ quit" exit. "+ new computer" creates one. "↻ refresh"
    re-fetches. Picking a VM drops into its action submenu.
    """
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    questionary = _UI.q()

    while True:
        payload = _with_spinner("fetching computers…", client.list_computers)
        computers = payload.get("computers") or []
        if not isinstance(computers, list):
            computers = []

        if not computers:
            _UI.console().print("[dim]no computers yet. creating your first one…[/dim]")
            return handle_create(config, None, None, None, None)

        computers = sorted(computers, key=_computer_sort_key)
        widths = _picker_widths(computers)

        # Title summarises counts so the picker alone carries enough context.
        total = len(computers)
        warm = sum(1 for c in computers if "warm" in _computer_status_label(c) or "running" in _computer_status_label(c))
        cold = sum(1 for c in computers if "cold" in _computer_status_label(c))
        bits = [f"{total} total"]
        if warm:
            bits.append(f"{warm} warm")
        if cold:
            bits.append(f"{cold} cold")
        summary = " · ".join(bits)

        choices: list[Any] = [
            questionary.Choice(title=_computer_choice_title(c, widths), value=c)
            for c in computers
        ]
        choices.append(questionary.Separator())
        choices.append(questionary.Choice(title="+ new computer", value="__new__"))
        choices.append(questionary.Choice(title="↻ refresh", value="__refresh__"))
        choices.append(questionary.Choice(title="✕ quit", value="__quit__"))

        picked = _select_prompt(f"Pick a computer ({summary})", choices).unsafe_ask()

        if picked is None or picked == "__quit__":
            return 0
        if picked == "__refresh__":
            continue
        if picked == "__new__":
            handle_create(config, None, None, None, None)
            continue
        if not isinstance(picked, dict):
            continue

        action = _vm_detail_menu(client, picked)
        if action == "__quit__":
            return 0
        # otherwise: loop and refresh the list


def _vm_detail_menu(client: RuntimeClient, vm: dict[str, Any]) -> str:
    """Action menu for a single VM. Returns '__back__' or '__quit__'."""
    questionary = _UI.q()
    vm_id = vm.get("id") or vm.get("slug") or "?"
    slug = vm.get("slug") or vm_id

    while True:
        _render_computer_panel(vm, title=f"computer: {slug}")

        power_state = _computer_power_state(vm)
        internal_status = _computer_internal_status(vm)
        visibility = str(vm.get("visibility") or "public")
        flip_visibility = "private" if visibility == "public" else "public"

        choices: list[Any] = []
        if internal_status in ("running", "cold"):
            choices.append(questionary.Choice(title="⌨ enter console", value="enter"))
        if internal_status == "running":
            choices.append(questionary.Choice(title="▶ run a command", value="run"))
            choices.append(questionary.Choice(title="⤴ publish service", value="publish"))
        if power_state == "cold":
            choices.append(questionary.Choice(title="☀ start / wake", value="start"))
        choices.extend(
            [
                questionary.Choice(title="⧉ copy public url", value="copy-url"),
                questionary.Choice(title="↗ open in browser", value="open-url"),
                questionary.Choice(title=f"⚑ make {flip_visibility}", value=f"share:{flip_visibility}"),
                questionary.Choice(title="⚙ service…", value="startup"),
                questionary.Choice(title="ℹ refresh info", value="info"),
                questionary.Separator(),
                questionary.Choice(title="✕ delete", value="delete"),
                questionary.Choice(title="← back", value="__back__"),
                questionary.Choice(title="✕ quit", value="__quit__"),
            ]
        )

        action = _select_prompt(
            f"What would you like to do with {slug}?",
            choices,
        ).unsafe_ask()

        if action is None or action == "__back__":
            return "__back__"
        if action == "__quit__":
            return "__quit__"

        if action == "enter":
            _enter_computer(RuntimeConfig(base_url=client.base_url, api_key=client.api_key), str(vm_id))
            vm = _with_spinner("fetching…", lambda: client.get_computer(vm_id))
            continue

        if action == "run":
            command = _prompt_text("Command to run")
            if not command:
                continue
            result = _with_spinner(
                f"running on {slug}…", lambda: client.run_command(vm_id, command)
            )
            _render_run_result(result)
            continue

        if action == "start":
            vm = _with_spinner(f"warming {slug}…", lambda: client.start_computer(vm_id))
            continue

        if action == "publish":
            port_text = _prompt_text("Port to publish", default="3000")
            if not port_text:
                continue
            try:
                port = int(port_text)
            except ValueError:
                _UI.err().print("[red]port must be a number[/red]")
                continue
            if port <= 0 or port > 65535:
                _UI.err().print("[red]port must be between 1 and 65535[/red]")
                continue
            command = _prompt_text("Command to run as the service")
            if not command:
                continue
            result = _with_spinner(
                f"publishing service on {slug}…",
                lambda: client.publish_port(vm_id, port, command=command),
            )
            _render_startup_panel(result, title=f"service: {slug}")
            continue

        if action == "info":
            vm = _with_spinner("fetching…", lambda: client.get_computer(vm_id))
            continue

        if action == "copy-url":
            url = str(vm.get("public_url") or "").strip()
            if not url:
                _UI.console().print("[yellow]no public url on this computer[/yellow]")
                continue
            if _copy_to_clipboard(url):
                _UI.console().print(f"[green]✓[/green] copied [cyan]{url}[/cyan]")
            else:
                _UI.console().print(f"[yellow]no clipboard tool found[/yellow] [cyan]{url}[/cyan]")
            continue

        if action == "open-url":
            url = str(vm.get("public_url") or "").strip()
            if not url:
                _UI.console().print("[yellow]no public url on this computer[/yellow]")
                continue
            with contextlib.suppress(Exception):
                webbrowser.open(url)
            _UI.console().print(f"[green]→[/green] opened [cyan]{url}[/cyan]")
            continue

        if action.startswith("share:"):
            target = action.split(":", 1)[1]
            vm = _with_spinner(
                f"setting {slug} to {target}…",
                lambda: client.set_visibility(str(vm_id), target),
            )
            _UI.console().print(
                f"[green]✓[/green] [bold]{slug}[/bold] is now [bold]{target}[/bold]"
            )
            continue

        if action == "startup":
            _vm_startup_submenu(client, vm_id, slug)
            vm = _with_spinner("fetching…", lambda: client.get_computer(vm_id))
            continue

        if action == "delete":
            if not _prompt_typed_confirm(
                f"Delete {slug}? This permanently destroys filesystem, service, and public URL.",
                str(slug),
            ):
                _UI.console().print("[dim]cancelled[/dim]")
                continue
            _with_spinner(f"deleting {slug}…", lambda: client.delete_computer(vm_id))
            _UI.console().print(f"[green]✓[/green] deleted [bold]{slug}[/bold]")
            return "__back__"


def _vm_startup_submenu(client: RuntimeClient, vm_id: str, slug: str) -> None:
    """Inner submenu for the durable service."""
    questionary = _UI.q()
    while True:
        current = _with_spinner("fetching service…", lambda: client.get_service(vm_id))
        _render_startup_panel(current, title=f"service: {slug}")
        configured = bool(current.get("configured"))
        choices: list[Any] = [
            questionary.Choice(title="✎ set / replace", value="set"),
        ]
        if configured:
            choices.append(questionary.Choice(title="✕ clear", value="clear"))
        choices.extend(
            [
                questionary.Separator(),
                questionary.Choice(title="← back", value="__back__"),
            ]
        )
        action = _select_prompt("service", choices).unsafe_ask()
        if action in (None, "__back__"):
            return
        if action == "set":
            command = _prompt_text("Service command", default=str(current.get("command") or ""))
            if not command:
                _UI.console().print("[dim]cancelled[/dim]")
                continue
            port_text = _prompt_text("App port", default=str(current.get("port") or "3000"))
            if not port_text:
                _UI.console().print("[dim]cancelled[/dim]")
                continue
            try:
                port = int(port_text)
            except ValueError:
                _UI.err().print("[red]port must be a number[/red]")
                continue
            if port <= 0 or port > 65535:
                _UI.err().print("[red]port must be between 1 and 65535[/red]")
                continue
            cwd = _prompt_text("Working directory (optional)", default=str(current.get("cwd") or ""))
            _with_spinner(
                "starting service…",
                lambda: client.run_service(vm_id, command=command, cwd=cwd or None, port=port),
            )
            _UI.console().print(f"[green]✓[/green] service started for [bold]{slug}[/bold]")
            continue
        if action == "clear":
            if not _prompt_confirm(f"Clear service for {slug}?", default=False):
                _UI.console().print("[dim]cancelled[/dim]")
                continue
            _with_spinner(
                "clearing service…",
                lambda: client.clear_service(vm_id),
            )
            _UI.console().print(f"[green]✓[/green] cleared service for [bold]{slug}[/bold]")
            continue


# --------------------------------------------------------------------------- #
# Help browser + shell completion                                              #
# --------------------------------------------------------------------------- #


_HELP_TOPICS: dict[str, tuple[str, ...]] = {
    "computer": ("Computers",),
    "computers": ("Computers",),
    "share": ("Sharing",),
    "sharing": ("Sharing",),
    "service": ("Startup & service",),
    "proxy": ("Proxy",),
    "github": ("GitHub",),
    "account": ("Account",),
    "shell": ("Shell",),
    "all": tuple(title for title, _ in _HELP_SECTIONS),
}


def handle_help(topic: str | None) -> int:
    if topic is None:
        sys.stdout.write(_format_top_help())
        return 0
    key = topic.strip().lower()
    if key not in _HELP_TOPICS:
        matches = _close_matches(key, list(_HELP_TOPICS))
        if matches:
            return report_error(f"unknown help topic {topic!r}. Did you mean {', '.join(repr(m) for m in matches)}?")
        return report_error(f"unknown help topic {topic!r}. Try: {', '.join(sorted(_HELP_TOPICS))}")

    wanted = set(_HELP_TOPICS[key])
    lines: list[str] = []
    for title, rows in _HELP_SECTIONS:
        if title not in wanted:
            continue
        lines.append(f"{title}:")
        left = max((len(name) for name, _ in rows), default=0)
        for name, desc in rows:
            padded = name + " " * max(0, left - len(name))
            lines.append(f"  {padded}  {desc}")
        lines.append("")
    sys.stdout.write("\n".join(lines) + "\n")
    return 0


_COMPLETION_BASH = r"""# bash completion for runtime
_runtime_complete() {
  local cur sub
  COMPREPLY=()
  cur="${COMP_WORDS[COMP_CWORD]}"
  if [[ ${COMP_CWORD} -eq 1 ]]; then
    COMPREPLY=( $(compgen -W "create list ls info url start enter run publish delete rm share service proxy switch checkout github integrate secrets api-keys signup verify login whoami logout completion help" -- "$cur") )
    return
  fi
  sub="${COMP_WORDS[1]}"
  case "$sub" in
    info|url|start|enter|run|publish|delete|rm|startup|service)
      local ids
      ids=$(runtime _slugs 2>/dev/null)
      COMPREPLY=( $(compgen -W "$ids" -- "$cur") )
      ;;
    completion)
      COMPREPLY=( $(compgen -W "bash zsh fish" -- "$cur") )
      ;;
    share)
      if [[ ${COMP_CWORD} -eq 2 ]]; then
        COMPREPLY=( $(compgen -W "public private" -- "$cur") )
      else
        local ids
        ids=$(runtime _slugs 2>/dev/null)
        COMPREPLY=( $(compgen -W "$ids" -- "$cur") )
      fi
      ;;
  esac
}
complete -F _runtime_complete runtime
"""


_COMPLETION_ZSH = r"""#compdef runtime
_runtime() {
  local -a _runtime_commands
  _runtime_commands=(
    'create:Create a new computer'
    'list:List computers'
    'ls:List computers'
    'info:Show details'
    'url:Show public URL'
    'start:Wake a cold computer'
    'enter:Enter console'
    'run:Run a command'
    'publish:Publish a port'
    'delete:Delete a computer'
    'rm:Delete a computer'
    'share:Set visibility'
    'service:Service config'
    'proxy:Port proxies'
    'switch:Open a GitHub branch workspace'
    'checkout:Open a GitHub branch workspace'
    'github:GitHub connections'
    'integrate:Connect GitHub'
    'secrets:Secret sets'
    'api-keys:API keys'
    'signup:Send verification code'
    'verify:Verify code'
    'login:Login'
    'whoami:Show account'
    'logout:Log out'
    'completion:Shell completion'
    'help:Extended help'
  )
  local state
  _arguments -C '1: :->cmd' '*:: :->args'
  case $state in
    cmd)
      _describe -t commands 'runtime command' _runtime_commands
      ;;
    args)
      case ${words[1]} in
        info|url|start|enter|run|publish|delete|rm|startup|service)
          local -a ids
          ids=(${(f)"$(runtime _slugs 2>/dev/null)"})
          _describe -t slugs 'computer' ids
          ;;
        share)
          if (( CURRENT == 2 )); then
            _values 'visibility' public private
          else
            local -a ids
            ids=(${(f)"$(runtime _slugs 2>/dev/null)"})
            _describe -t slugs 'computer' ids
          fi
          ;;
        completion)
          _values 'shell' bash zsh fish
          ;;
      esac
      ;;
  esac
}
_runtime "$@"
"""


_COMPLETION_FISH = r"""# fish completion for runtime
function __runtime_slugs
  runtime _slugs 2>/dev/null
end

complete -c runtime -f
complete -c runtime -n '__fish_use_subcommand' -a create -d 'Create'
complete -c runtime -n '__fish_use_subcommand' -a list -d 'List'
complete -c runtime -n '__fish_use_subcommand' -a ls -d 'List'
complete -c runtime -n '__fish_use_subcommand' -a info -d 'Show details'
complete -c runtime -n '__fish_use_subcommand' -a url -d 'Show URL'
complete -c runtime -n '__fish_use_subcommand' -a start -d 'Wake'
complete -c runtime -n '__fish_use_subcommand' -a enter -d 'Console'
complete -c runtime -n '__fish_use_subcommand' -a run -d 'Run command'
complete -c runtime -n '__fish_use_subcommand' -a publish -d 'Publish port'
complete -c runtime -n '__fish_use_subcommand' -a delete -d 'Delete'
complete -c runtime -n '__fish_use_subcommand' -a rm -d 'Delete'
complete -c runtime -n '__fish_use_subcommand' -a share -d 'Set visibility'
complete -c runtime -n '__fish_use_subcommand' -a service -d 'Service config'
complete -c runtime -n '__fish_use_subcommand' -a proxy -d 'Port proxies'
complete -c runtime -n '__fish_use_subcommand' -a github -d 'GitHub connections'
complete -c runtime -n '__fish_use_subcommand' -a integrate -d 'Connect GitHub'
complete -c runtime -n '__fish_use_subcommand' -a help -d 'Extended help'
complete -c runtime -n '__fish_use_subcommand' -a completion -d 'Completion'

complete -c runtime -n '__fish_seen_subcommand_from info url start enter run publish delete rm service' -a '(__runtime_slugs)'
complete -c runtime -n '__fish_seen_subcommand_from completion' -a 'bash zsh fish'
complete -c runtime -n '__fish_seen_subcommand_from share' -a 'public private'
"""


def handle_completion(shell: str) -> int:
    scripts = {"bash": _COMPLETION_BASH, "zsh": _COMPLETION_ZSH, "fish": _COMPLETION_FISH}
    script = scripts.get(shell)
    if script is None:
        return report_error(f"unsupported shell: {shell}")
    sys.stdout.write(script)
    return 0


def handle_slugs(config: RuntimeConfig) -> int:
    """Print one slug per line. Used by shell completion scripts. Silent on errors."""
    if not config.api_key:
        return 0
    try:
        client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
        payload = client.list_computers()
    except Exception:
        return 0
    computers = payload.get("computers") or []
    if not isinstance(computers, list):
        return 0
    for c in computers:
        if isinstance(c, dict):
            slug = str(c.get("slug") or "").strip()
            if slug:
                sys.stdout.write(slug + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
