from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx


class RuntimeAPIError(RuntimeError):
    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


DEFAULT_WARMUP_TIMEOUT = 180.0


@dataclass(slots=True)
class RuntimeClient:
    base_url: str
    api_key: str | None = None
    timeout: float = 10.0
    transport: httpx.BaseTransport | None = None

    def __post_init__(self) -> None:
        self.base_url = self.base_url.rstrip("/")

    def start_verification(self, email: str, name: str | None = None) -> dict[str, Any]:
        body: dict[str, Any] = {"email": email}
        if name is not None:
            body["name"] = name
        return self._request("POST", "/api/auth/start", json=body)

    def signup(self, email: str, name: str | None = None) -> dict[str, Any]:
        return self.start_verification(email, name)

    def verify(self, flow_id: int, code: str) -> dict[str, Any]:
        return self._request("POST", "/api/auth/verify", json={"flow_id": flow_id, "code": code})

    def whoami(self) -> dict[str, Any]:
        return self._request("GET", "/api/auth/whoami", auth_required=True)

    def logout(self) -> dict[str, Any]:
        return self._request("POST", "/api/auth/logout", auth_required=True)

    def list_api_keys(self) -> dict[str, Any]:
        return self._request("GET", "/api/api-keys", auth_required=True)

    def create_api_key(self, label: str) -> dict[str, Any]:
        return self._request("POST", "/api/api-keys", json={"label": label}, auth_required=True)

    def revoke_api_key(self, key_id: int) -> dict[str, Any]:
        return self._request("POST", f"/api/api-keys/{key_id}/revoke", auth_required=True)

    # --- GitHub App ---

    def start_github_connect(self) -> dict[str, Any]:
        return self._request("POST", "/api/github/connect", auth_required=True)

    def get_github_connect_session(self, session_id: int) -> dict[str, Any]:
        return self._request("GET", f"/api/github/connect/{session_id}", auth_required=True)

    def list_github_installations(self) -> dict[str, Any]:
        return self._request("GET", "/api/github/installations", auth_required=True)

    def disconnect_github_installation(self, installation_id: int) -> dict[str, Any]:
        return self._request("DELETE", f"/api/github/installations/{installation_id}", auth_required=True)

    def list_secret_sets(self) -> dict[str, Any]:
        return self._request("GET", "/api/secrets", auth_required=True)

    def get_secret_set(self, slug: str) -> dict[str, Any]:
        return self._request("GET", f"/api/secrets/{slug}", auth_required=True)

    def put_secret_set(self, slug: str, values: dict[str, str]) -> dict[str, Any]:
        return self._request("PUT", f"/api/secrets/{slug}", json={"values": values}, auth_required=True)

    def delete_secret_set(self, slug: str) -> dict[str, Any]:
        return self._request("DELETE", f"/api/secrets/{slug}", auth_required=True)

    # --- Computers ---

    def switch_workspace(
        self,
        *,
        repo: str,
        branch: str,
        create: bool = False,
        base_branch: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"repo": repo, "branch": branch, "create": create}
        if base_branch is not None:
            body["from"] = base_branch
        return self._request(
            "POST",
            "/api/workspaces/switch",
            json=body,
            auth_required=True,
            timeout=max(self.timeout, DEFAULT_WARMUP_TIMEOUT),
        )

    def create_computer(
        self,
        *,
        slug: str | None = None,
        command: str | None = None,
        cwd: str | None = None,
        port: int | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if slug:
            body["slug"] = slug
        if command is not None or cwd is not None or port is not None:
            start: dict[str, Any] = {}
            if command is not None:
                start["command"] = command
            if cwd is not None:
                start["cwd"] = cwd
            if port is not None:
                start["port"] = port
            body["start"] = start
        return self._request(
            "POST",
            "/api/computers",
            json=body or None,
            auth_required=True,
            timeout=max(self.timeout, DEFAULT_WARMUP_TIMEOUT),
        )

    def list_computers(self) -> dict[str, Any]:
        return self._request("GET", "/api/computers", auth_required=True)

    def get_computer(self, computer_id: str) -> dict[str, Any]:
        return self._request("GET", f"/api/computers/{computer_id}", auth_required=True)

    def get_computer_network(self, computer_id: str) -> dict[str, Any]:
        return self._request("GET", f"/api/computers/{computer_id}/network", auth_required=True)

    def set_visibility(self, computer_id: str, visibility: str) -> dict[str, Any]:
        return self._request(
            "PUT",
            f"/api/computers/{computer_id}/visibility",
            json={"visibility": visibility},
            auth_required=True,
        )

    def get_startup_config(self, computer_id: str) -> dict[str, Any]:
        return self._request("GET", f"/api/computers/{computer_id}/startup", auth_required=True)

    def get_service_config(self, computer_id: str) -> dict[str, Any]:
        return self.get_service(computer_id)

    def get_service(self, computer_id: str) -> dict[str, Any]:
        return self._request("GET", f"/api/computers/{computer_id}/service", auth_required=True)

    def run_service(
        self,
        computer_id: str,
        *,
        command: str,
        cwd: str | None = None,
        port: int,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"command": command, "port": port}
        if cwd is not None:
            body["cwd"] = cwd
        return self._request(
            "POST",
            f"/api/computers/{computer_id}/service/run",
            json=body,
            auth_required=True,
            timeout=max(self.timeout, DEFAULT_WARMUP_TIMEOUT),
        )

    def restart_service(self, computer_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/computers/{computer_id}/service/restart",
            auth_required=True,
            timeout=max(self.timeout, DEFAULT_WARMUP_TIMEOUT),
        )

    def stop_service(self, computer_id: str) -> dict[str, Any]:
        return self._request("POST", f"/api/computers/{computer_id}/service/stop", auth_required=True)

    def clear_service(self, computer_id: str) -> dict[str, Any]:
        return self._request("DELETE", f"/api/computers/{computer_id}/service", auth_required=True)

    def stream_service_logs(self, computer_id: str, *, follow: bool = False):
        if not self.api_key:
            raise RuntimeAPIError("missing api key")
        path = f"/api/computers/{computer_id}/service/logs"
        if follow:
            path += "?follow=true"
        client = httpx.Client(base_url=self.base_url, timeout=None, transport=self.transport)
        try:
            with client.stream("GET", path, headers={"Authorization": f"Bearer {self.api_key}"}) as response:
                if not response.is_success:
                    body = response.read()
                    payload: dict[str, Any] = {}
                    if body:
                        try:
                            decoded = response.json()
                            if isinstance(decoded, dict):
                                payload = decoded
                        except ValueError:
                            pass
                    message = payload.get("error") or payload.get("message") or f"http {response.status_code}"
                    raise RuntimeAPIError(str(message), status_code=response.status_code)
                for line in response.iter_lines():
                    if not line:
                        continue
                    yield line
        finally:
            client.close()

    def set_startup_config(
        self,
        computer_id: str,
        *,
        command: str,
        cwd: str | None = None,
        port: int,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"command": command, "port": port}
        if cwd is not None:
            body["cwd"] = cwd
        return self._request("PUT", f"/api/computers/{computer_id}/startup", json=body, auth_required=True)

    def clear_startup_config(self, computer_id: str) -> dict[str, Any]:
        return self._request("DELETE", f"/api/computers/{computer_id}/startup", auth_required=True)

    def clear_service_config(self, computer_id: str) -> dict[str, Any]:
        return self.clear_service(computer_id)

    def start_computer(self, computer_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/computers/{computer_id}/start",
            auth_required=True,
            timeout=max(self.timeout, DEFAULT_WARMUP_TIMEOUT),
        )

    def delete_computer(self, computer_id: str) -> dict[str, Any]:
        return self._request("DELETE", f"/api/computers/{computer_id}", auth_required=True)

    def create_terminal_ticket(self, computer_id: str) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/computers/{computer_id}/terminal-ticket",
            auth_required=True,
            timeout=max(self.timeout, DEFAULT_WARMUP_TIMEOUT),
        )

    def create_proxy_ticket(self, computer_id: str, port: int) -> dict[str, Any]:
        if port <= 0 or port > 65535:
            raise RuntimeAPIError("port must be between 1 and 65535")
        return self._request(
            "POST",
            f"/api/computers/{computer_id}/proxy-ticket",
            json={"port": port},
            auth_required=True,
            timeout=max(self.timeout, DEFAULT_WARMUP_TIMEOUT),
        )

    def run_command(
        self,
        computer_id: str,
        command: str,
        *,
        uid: int | None = None,
        gid: int | None = None,
        cwd: str | None = None,
        shell: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"command": command}
        if uid is not None:
            body["uid"] = uid
        if gid is not None:
            body["gid"] = gid
        if cwd is not None:
            body["cwd"] = cwd
        if shell is not None:
            body["shell"] = shell
        return self._request("POST", f"/api/computers/{computer_id}/exec", json=body, auth_required=True)

    def publish_port(self, computer_id: str, port: int, *, command: str | None = None, cwd: str | None = None) -> dict[str, Any]:
        if port <= 0 or port > 65535:
            raise RuntimeAPIError("port must be between 1 and 65535")
        if not command:
            raise RuntimeAPIError("publish requires -- <command...>")
        return self.run_service(computer_id, command=command, cwd=cwd, port=port)

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        auth_required: bool = False,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        headers: dict[str, str] = {}
        if auth_required:
            if not self.api_key:
                raise RuntimeAPIError("missing api key")
            headers["Authorization"] = f"Bearer {self.api_key}"

        try:
            with httpx.Client(
                base_url=self.base_url,
                timeout=self.timeout if timeout is None else timeout,
                transport=self.transport,
            ) as client:
                response = client.request(method, path, json=json, headers=headers)
        except httpx.HTTPError as exc:
            raise RuntimeAPIError(f"request failed: {exc}") from exc

        payload = self._decode_response(response)
        if response.is_success:
            return payload

        message = payload.get("error") or payload.get("message") or f"http {response.status_code}"
        raise RuntimeAPIError(str(message), status_code=response.status_code)

    @staticmethod
    def _decode_response(response: httpx.Response) -> dict[str, Any]:
        if not response.content:
            return {}
        try:
            decoded = response.json()
        except ValueError as exc:
            raise RuntimeAPIError("server returned invalid JSON", status_code=response.status_code) from exc

        if not isinstance(decoded, dict):
            raise RuntimeAPIError("server returned non-object JSON", status_code=response.status_code)
        return decoded
