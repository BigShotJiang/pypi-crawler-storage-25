class TelegramOIDCException(Exception):
    """Базовое исключение для библиотеки Telegram OIDC."""
    pass

class ConfigurationError(TelegramOIDCException):
    """Ошибка конфигурации клиента."""
    pass

class TokenExchangeError(TelegramOIDCException):
    """Ошибка при обмене кода на токен."""
    pass

class TokenValidationError(TelegramOIDCException):
    """Ошибка валидации ID Token (неверная подпись, истек срок и т.д.)."""
    pass