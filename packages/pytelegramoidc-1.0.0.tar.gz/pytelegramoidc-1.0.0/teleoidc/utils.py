import base64
import hashlib
import os
import secrets

def generate_pkce_pair() -> tuple[str, str]:
    """
    Генерирует пару code_verifier и code_challenge для PKCE (метод S256).
    
    :return: Кортеж (code_verifier, code_challenge)
    """
    # Генерируем случайную строку (от 43 до 128 символов)
    verifier_bytes = os.urandom(32)
    code_verifier = base64.urlsafe_b64encode(verifier_bytes).decode('utf-8').rstrip('=')
    
    # Хешируем SHA256 и кодируем в Base64URL
    challenge_bytes = hashlib.sha256(code_verifier.encode('utf-8')).digest()
    code_challenge = base64.urlsafe_b64encode(challenge_bytes).decode('utf-8').rstrip('=')
    
    return code_verifier, code_challenge

def generate_state() -> str:
    """Генерирует случайную строку для параметра state (защита от CSRF)."""
    return secrets.token_urlsafe(32)