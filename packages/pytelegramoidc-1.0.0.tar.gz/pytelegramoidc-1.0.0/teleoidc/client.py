import urllib.parse
from typing import List, Optional

import httpx
import jwt
from jwt import PyJWKClient
from jwt.exceptions import PyJWTError

from .exceptions import TokenExchangeError, TokenValidationError
from .models import TelegramUser, TokenResponse, AuthRequestParams
from .utils import generate_pkce_pair, generate_state


class TelegramAsyncOIDCClient:
    AUTH_URL = "https://oauth.telegram.org/auth"
    TOKEN_URL = "https://oauth.telegram.org/token"
    JWKS_URL = "https://oauth.telegram.org/.well-known/jwks.json"
    ISSUER = "https://oauth.telegram.org"

    def __init__(self, client_id: str, client_secret: str, redirect_uri: str):
        self.client_id = str(client_id)
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri
        
        # PyJWKClient автоматически кэширует ключи, чтобы не делать запрос при каждой проверке токена
        self.jwks_client = PyJWKClient(self.JWKS_URL)

    def get_auth_request(
        self, 
        scopes: Optional[List[str]] = None, 
        state: Optional[str] = None
    ) -> AuthRequestParams:
        """
        Генерирует URL для редиректа пользователя в Telegram, а также verifier для PKCE.
        
        ВАЖНО: Вы должны сохранить `state` и `code_verifier` (например, в сессии пользователя),
        чтобы использовать их после того, как пользователь вернется на `redirect_uri`.
        """
        if scopes is None:
            scopes = ["openid", "profile"]
        if "openid" not in scopes:
            scopes.insert(0, "openid")

        state = state or generate_state()
        code_verifier, code_challenge = generate_pkce_pair()

        params = {
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "response_type": "code",
            "scope": " ".join(scopes),
            "state": state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256"
        }

        url = f"{self.AUTH_URL}?{urllib.parse.urlencode(params)}"
        return AuthRequestParams(auth_url=url, state=state, code_verifier=code_verifier)

    async def exchange_code_for_token(self, code: str, code_verifier: str) -> TokenResponse:
        """
        Обменивает authorization code на access_token и id_token.
        """
        data = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": self.redirect_uri,
            "client_id": self.client_id,
            "code_verifier": code_verifier
        }

        async with httpx.AsyncClient() as client:
            response = await client.post(
                self.TOKEN_URL,
                data=data,
                auth=(self.client_id, self.client_secret)  # httpx автоматически сделает Basic Auth
            )

        if response.status_code != 200:
            raise TokenExchangeError(f"Ошибка обмена токена: {response.text}")

        return TokenResponse(**response.json())

    def validate_id_token(self, id_token: str) -> TelegramUser:
        """
        Проверяет подпись JWT и валидирует claims (iss, aud, exp).
        Возвращает объект пользователя.
        """
        try:
            # Получаем публичный ключ из кэша JWKS
            signing_key = self.jwks_client.get_signing_key_from_jwt(id_token)

            # Декодируем и валидируем
            payload = jwt.decode(
                id_token,
                signing_key.key,
                algorithms=["RS256"],
                audience=self.client_id,
                issuer=self.ISSUER
            )
            
            return TelegramUser(**payload)
        except PyJWTError as e:
            raise TokenValidationError(f"ID Token недействителен: {str(e)}")