from typing import Optional, List
from pydantic import BaseModel, Field

class TelegramUser(BaseModel):
    """Модель данных пользователя, извлеченная из ID Token."""
    iss: str
    aud: str
    sub: str
    iat: int
    exp: int
    
    # Telegram-specific поля
    id: int
    name: str
    preferred_username: Optional[str] = None
    picture: Optional[str] = None
    phone_number: Optional[str] = None


class TokenResponse(BaseModel):
    """Ответ от сервера Telegram при успешном получении токенов."""
    access_token: str
    token_type: str = "Bearer"
    expires_in: int
    id_token: str


class AuthRequestParams(BaseModel):
    """Параметры, генерируемые для редиректа пользователя."""
    auth_url: str
    state: str
    code_verifier: str