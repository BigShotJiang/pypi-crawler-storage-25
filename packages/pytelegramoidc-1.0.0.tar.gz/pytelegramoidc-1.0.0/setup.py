from setuptools import setup, find_packages
import os

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="pyTelegramOIDC",
    version="1.0.0",
    author="S1qwy",
    author_email="s1qwy@internet.ru",
    description="Async Python library for Telegram OpenID Connect (OIDC) login",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/S1qwy/pyTelegramOIDC",
    packages=find_packages(),
    install_requires=[
        "httpx>=0.24.0",
        "PyJWT[crypto]>=2.8.0",
        "pydantic>=2.0.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Security",
        "Topic :: Internet :: WWW/HTTP :: Session",
    ],
    python_requires=">=3.8",
)