# pylint: disable=missing-docstring, protected-access, redefined-outer-name
import os
import sys
import unittest
from unittest.mock import patch
import tkinter as tk
from PIL import Image
from guardian_ltsm.one_bit_convert import OneBitConverter, _SaveConfig

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC_DIR = os.path.join(ROOT_DIR, "src")
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)


class TestOneBitConverter(unittest.TestCase):

    def setUp(self):
        self.root = tk.Tk()
        self.root.withdraw()

    def tearDown(self):
        self.root.destroy()

    def test_parse_hex_string(self):
        with patch.object(OneBitConverter, "open_image_dialog", lambda self: None):
            converter = OneBitConverter(parent=self.root, controller=None, data_mode=False)

        hex_string = "0x01, 0xFF, bad, 0xA0"
        result = converter.parse_hex_string(hex_string)
        self.assertEqual(result, [1, 255, 160])

    def test_format_byte_array(self):
        with patch.object(OneBitConverter, "open_image_dialog", lambda self: None):
            converter = OneBitConverter(parent=self.root, controller=None, data_mode=False)

        formatted = converter._format_byte_array(["0x01", "0x02", "0x03", "0x04"], bytes_per_row=2)
        self.assertEqual(formatted, "    0x01, 0x02,\n    0x03, 0x04")

    def test_build_header_content(self):
        with patch.object(OneBitConverter, "open_image_dialog", lambda self: None):
            converter = OneBitConverter(parent=self.root, controller=None, data_mode=False)

        converter.core.width = 2
        converter.core.height = 1
        config = _SaveConfig(ext=".h", vertical=False, swap=False,
                            image_name="foo", file_name="bar")
        raw_data = [0x11, 0x22, 0x33]
        header = converter._build_header_content(config, raw_data)

        self.assertIn("#ifndef BAR_H", header)
        self.assertIn("// Image Name  : foo", header)
        self.assertIn("// Dimensions  : 2 x 1 px", header)
        self.assertIn("const uint8_t foo[] = {", header)

    def test_refresh_applies_image_to_data(self):
        with patch.object(OneBitConverter, "open_image_dialog", lambda self: None):
            converter = OneBitConverter(parent=self.root, controller=None, data_mode=False)

        converter._update_preview = lambda: None
        converter.output_button = type("Btn", (),
        {"state": "disabled", "config": lambda self, **kw: setattr(self, "state", kw["state"])})()
        converter.original_image = Image.new("L", (2, 1), 255)
        converter.threshold_var.set(128)
        converter.invert_var.set(False)

        converter.refresh()
        self.assertEqual(converter.output_button.state, "normal")
        self.assertEqual(converter.core.bitmap_2d, [[1, 1]])

    def test_refresh_applies_data_to_image(self):
        with patch.object(OneBitConverter, "open_image_dialog", lambda self: None):
            converter = OneBitConverter(parent=self.root, controller=None, data_mode=False)

        converter._update_preview = lambda: None
        converter.output_button = type("Btn", (),
        {"state": "disabled", "config": lambda self, **kw: setattr(self, "state", kw["state"])})()
        converter.core.width = 2
        converter.core.height = 1
        converter.core.bitmap_2d = [[0, 0]]
        converter.raw_bytes = [0xFF]

        converter.refresh()
        self.assertEqual(converter.output_button.state, "normal")


if __name__ == "__main__":
    unittest.main()
