# pylint: disable=missing-docstring, protected-access, redefined-outer-name
import os
import sys
import unittest
from PIL import Image
from guardian_ltsm.colour_bit_convert import (
    ColourBitCore,
    ConvertOptions,
    FormatOptions,
)

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC_DIR = os.path.join(ROOT_DIR, "src")
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)



class TestColourBitCore(unittest.TestCase):

    def test_rgb_to_rbgg_nibble_and_back(self):
        red_nibble = ColourBitCore._rgb_to_rbgg_nibble(255, 0, 0)
        self.assertEqual(red_nibble, 0x8)
        blue_green_nibble = ColourBitCore._rgb_to_rbgg_nibble(0, 255, 255)
        self.assertEqual(blue_green_nibble, 0x7)

        self.assertEqual(
            ColourBitCore._rbgg_nibble_to_rgb(red_nibble),
            (255, 0, 0),
        )
        self.assertEqual(
            ColourBitCore._rbgg_nibble_to_rgb(blue_green_nibble),
            (0, 255, 255),
        )

    def test_pack_pixel_formats(self):
        core = ColourBitCore()

        self.assertEqual(core._pack_pixel(128, "L", "little"), [128])
        self.assertEqual(core._pack_pixel((128, 64, 32), "RGB332", "little"), [0x88])

        self.assertEqual(
            core._pack_pixel((255, 128, 64), "RGB565", "little"),
            core._pack_pixel((255, 128, 64), "RGB565", "little"),
        )
        self.assertEqual(
            core._pack_pixel((255, 128, 64), "RGB565", "little"),
            [8, 252],
        )
        self.assertEqual(
            core._pack_pixel((255, 128, 64), "RGB565", "big"),
            [252, 8],
        )

        self.assertEqual(
            core._pack_pixel((255, 128, 64), "BGR565", "little"),
            [31, 68],
        )
        self.assertEqual(
            core._pack_pixel((255, 128, 64), "BGR565", "big"),
            [68, 31],
        )

        self.assertEqual(core._pack_pixel((10, 20, 30), "RGB", "little"), [10, 20, 30])
        self.assertEqual(core._pack_pixel((10, 20, 30, 40), "RGBA", "little"), [10, 20, 30, 40])

    def test_apply_resize_aspect_ratio(self):
        image = Image.new("RGB", (4, 2), "red")
        core = ColourBitCore()

        resized_width = core._apply_resize(image, "2", "")
        self.assertEqual(resized_width.size, (2, 1))

        resized_height = core._apply_resize(image, "", "4")
        self.assertEqual(resized_height.size, (8, 4))

    def test_convert_and_format_bytes(self):
        image = Image.new("RGB", (2, 1))
        image.putpixel((0, 0), (255, 0, 0))
        image.putpixel((1, 0), (0, 255, 0))

        core = ColourBitCore()
        opts = ConvertOptions(
            palette_mode="RGB565",
            endian="little",
            resize_w="",
            resize_h="",
        )
        raw_bytes = core.convert(image, opts)

        self.assertEqual(len(raw_bytes), 4)
        self.assertEqual(core.converted_image.size, (2, 1))

        format_opts = FormatOptions(
            output_format="hex",
            datatype="uint16_t",
            image_name="test_image",
            multiline=True,
            separate_bytes=False,
            palette_mode="RGB565",
        )
        formatted = core.format_bytes(raw_bytes, format_opts)
        self.assertIn("#define TEST_IMAGE_WIDTH   2", formatted)
        self.assertIn("#define TEST_IMAGE_HEIGHT  1", formatted)
        self.assertIn("const uint16_t test_image[] = {", formatted)
        self.assertIn("0x", formatted)

        format_opts.output_format = "decimal"
        formatted_decimal = core.format_bytes(raw_bytes, format_opts)
        self.assertIn("const uint16_t test_image[] = {", formatted_decimal)
        self.assertNotIn("0x", formatted_decimal)

        format_opts.output_format = "binary"
        formatted_binary = core.format_bytes(raw_bytes, format_opts)
        self.assertIn("0b", formatted_binary)

    def test_format_bytes_separate_bytes(self):
        raw_bytes = [0x12, 0x34, 0x56]
        core = ColourBitCore()
        core.width = 3

        opts = FormatOptions(
            output_format="hex",
            datatype="uint8_t",
            image_name="data",
            multiline=True,
            separate_bytes=True,
            palette_mode="RGB",
        )

        formatted = core.format_bytes(raw_bytes, opts)
        self.assertIn("0x12", formatted)
        self.assertIn("0x34", formatted)
        self.assertIn("0x56", formatted)
        self.assertIn("const uint8_t data[] = {", formatted)

    def test_make_preview_image_rgba(self):
        core = ColourBitCore()
        core.width = 2
        core.height = 1
        raw_bytes = [10, 20, 30, 40, 50, 60, 70, 80]

        preview = core._make_preview_image(raw_bytes, "RGBA")
        self.assertEqual(preview.size, (2, 1))
        self.assertEqual(preview.getpixel((0, 0)), (10, 20, 30))
        self.assertEqual(preview.getpixel((1, 0)), (50, 60, 70))

    def test_make_preview_image_rbgg4(self):
        core = ColourBitCore()
        core.width = 2
        core.height = 1

        preview = core._make_preview_image([0x80], "RBGG4")
        self.assertEqual(preview.size, (2, 1))
        self.assertEqual(preview.getpixel((0, 0)), (255, 0, 0))
        self.assertEqual(preview.getpixel((1, 0)), (0, 0, 0))


if __name__ == "__main__":
    unittest.main()
