# pylint: disable=missing-docstring, protected-access, redefined-outer-name
import os
import sys
import tempfile
import unittest
from pathlib import Path
import guardian_ltsm.settings as settings_mod

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC_DIR = os.path.join(ROOT_DIR, "src")
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)


class TestSettings(unittest.TestCase):

    def test_load_creates_defaults_and_persists(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            cfg_path = Path(temp_dir) / "guardian_ltsm.cfg"
            original_path = settings_mod.CL_CONFIG_PATH
            settings_mod.CL_CONFIG_PATH = cfg_path
            try:
                config = settings_mod.Settings()
                self.assertTrue(cfg_path.exists())
                self.assertEqual(config.getint("Display", "preview_width", fallback=0), 160)
                self.assertEqual(config.getstr("Paths", "input_dir", fallback=""), str(Path.home()))

                config.set("Paths", "output_dir", "/tmp")
                self.assertEqual(config.getstr("Paths", "output_dir", fallback=""), "/tmp")

                loaded = settings_mod.Settings()
                self.assertEqual(loaded.getstr("Paths", "output_dir", fallback=""), "/tmp")
            finally:
                settings_mod.CL_CONFIG_PATH = original_path


if __name__ == "__main__":
    unittest.main()
