# pylint: disable=missing-docstring, protected-access, redefined-outer-name
import os
import sys
import unittest
from PIL import Image
from guardian_ltsm.one_bit_convert import OneBitCore

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC_DIR = os.path.join(ROOT_DIR, "src")
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)


class TestOneBitCore(unittest.TestCase):

    def test_image_to_bitmap_threshold_and_invert(self):
        image = Image.new("L", (2, 2))
        image.putpixel((0, 0), 0)
        image.putpixel((1, 0), 255)
        image.putpixel((0, 1), 128)
        image.putpixel((1, 1), 200)

        core = OneBitCore()
        core.threshold = 128
        core.invert = False
        core.image_to_bitmap(image)
        self.assertEqual(core.bitmap_2d, [[0, 1], [0, 1]])

        core.invert = True
        core.image_to_bitmap(image)
        self.assertEqual(core.bitmap_2d, [[1, 0], [1, 0]])

    def test_pack_bits_horizontal_and_vertical(self):
        core = OneBitCore()
        core.width = 3
        core.height = 2
        core.bitmap_2d = [[1, 0, 1], [0, 1, 0]]

        expected_horizontal = [0xA0, 0x40]
        self.assertEqual(core.pack_bits(vertical=False), expected_horizontal)

        expected_vertical = [0x01, 0x02, 0x01]
        self.assertEqual(core.pack_bits(vertical=True), expected_vertical)

        expected_swap = [0x05, 0x02]
        self.assertEqual(core.pack_bits(vertical=False, swap_bits=True), expected_swap)

    def test_unpack_bits_horizontal_and_vertical(self):
        core = OneBitCore()
        core.width = 3
        core.height = 2
        core.bitmap_2d = [[0] * 3 for _ in range(2)]

        horizontal_data = [0xA0, 0x40]
        core.unpack_bits(horizontal_data)
        self.assertEqual(core.bitmap_2d, [[1, 0, 1], [0, 1, 0]])

        core.vertical_addressing = True
        core.bitmap_2d = [[0] * 3 for _ in range(2)]
        vertical_data = [0x01, 0x02, 0x01]
        core.unpack_bits(vertical_data)
        self.assertEqual(core.bitmap_2d, [[1, 0, 1], [0, 1, 0]])

    def test_calc_data_size(self):
        core = OneBitCore()
        core.width = 10
        core.height = 3
        core.vertical_addressing = False
        self.assertEqual(core.calc_data_size(), 6)

        core.vertical_addressing = True
        self.assertEqual(core.calc_data_size(), 10)

    def test_bitmap_to_image(self):
        core = OneBitCore()
        core.width = 2
        core.height = 2
        core.bitmap_2d = [[0, 1], [1, 0]]

        image = core.bitmap_to_image()
        self.assertEqual(image.mode, "1")
        self.assertEqual(image.getpixel((0, 0)), 0)
        self.assertEqual(image.getpixel((1, 0)), 255)
        self.assertEqual(image.getpixel((0, 1)), 255)
        self.assertEqual(image.getpixel((1, 1)), 0)


if __name__ == "__main__":
    unittest.main()
