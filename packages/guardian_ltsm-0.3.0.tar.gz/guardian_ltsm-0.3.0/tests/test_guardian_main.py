# pylint: disable=missing-docstring, protected-access, redefined-outer-name
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch
import tkinter as tk
from guardian_ltsm.guardian_main import (
    GuardianApp,
    install_desktop_entry,
    desktop_entry_installed,
    MainMenu,
)


ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC_DIR = os.path.join(ROOT_DIR, "src")
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)



class TestGuardianMainHelpers(unittest.TestCase):

    def test_desktop_entry_installed_false_when_missing(self):
        with tempfile.TemporaryDirectory() as temp_home:
            with patch("guardian_ltsm.guardian_main.Path.home", return_value=Path(temp_home)):
                self.assertFalse(desktop_entry_installed())

    def test_desktop_entry_installed_true_when_files_exist(self):
        with tempfile.TemporaryDirectory() as temp_home:
            path = Path(temp_home)
            icons = path / ".local/share/icons"
            apps = path / ".local/share/applications"
            icons.mkdir(parents=True, exist_ok=True)
            apps.mkdir(parents=True, exist_ok=True)
            (icons / "guardian.png").write_text("x")
            (apps / "guardian.desktop").write_text("x")

            with patch("guardian_ltsm.guardian_main.Path.home", return_value=path):
                self.assertTrue(desktop_entry_installed())

    def test_install_desktop_entry_success_calls_curl_and_returns_true(self):
        with tempfile.TemporaryDirectory() as temp_home:
            path = Path(temp_home)
            with patch("guardian_ltsm.guardian_main.sys.platform", "linux"), \
                 patch("guardian_ltsm.guardian_main.Path.home", return_value=path), \
                 patch("guardian_ltsm.guardian_main.subprocess.run") as run_mock, \
                 patch("guardian_ltsm.guardian_main.messagebox.showinfo") as showinfo_mock, \
                 patch("guardian_ltsm.guardian_main.messagebox.showerror") as showerror_mock:
                run_mock.return_value = Mock(returncode=0)
                result = install_desktop_entry()

            self.assertTrue(result)
            self.assertEqual(run_mock.call_count, 2)
            showinfo_mock.assert_called_once()
            showerror_mock.assert_not_called()


class TestGuardianAppFrameManagement(unittest.TestCase):

    def setUp(self):
        self.root = tk.Tk()
        self.root.withdraw()

    def tearDown(self):
        self.root.destroy()

    def test_show_frame_raises_correct_frame(self):
        app = GuardianApp()

        target_frame = app.frames[MainMenu]
        target_frame.tkraise = Mock()

        app.show_frame(MainMenu)

        target_frame.tkraise.assert_called_once()


if __name__ == "__main__":
    unittest.main()
