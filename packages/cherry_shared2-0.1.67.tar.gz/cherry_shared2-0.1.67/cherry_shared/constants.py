class Constants:
    """Internal Constants class for Bot, only edit this if you know what you're doing."""

    bot_username = "cherrys"
    bot_firstname = "Cherry Bot"

    trending_channel_id = -1001929856388
    test_trending_channel = -1002187493063
    trending_channel_link = "https://t.me/cherrytrending"
    trending_evm_channel_link = "https://t.me/cherrytrendingevm"
    luxury_trending_link = "https://t.me/cherrytrend"
    bot_link = "https://t.me/cherrys"
    website_link = "https://cherrybot.net/"
    twitter_link = "https://x.com/cherrytgbot"
    announcements_channel = "https://t.me/Cherrybotannouncements"
    raid_channel_link = "https://t.me/cherryraid"
    cherry_channels_folder = "https://t.me/addlist/rmaImOUui5U2OTdk"
    raid_leaderboard = "https://t.me/cherryraid/6"
    support_group_link = "https://t.me/CherryAdmin"
    cherry_docs = "https://docs.cherrybot.co"
    cherry_ads = "https://t.me/CherryBotads"
    raid_channel_id = -1002205397643
    raid_debug_channel_id = -1002242607566
    ongoing_raids_channel = -1002210794648
    boosted_raids_channel = -1002205397643
    cherry_group_id = -1002013828335
    luxury_group_id = -1003425821137
    luxury_leaderboard_msg_id = 20872
    luxury_raid_channel_thread_id = 14
    timeout = 120  # in seconds (for pyromod listener)
    data_dir = r"data/"
    MAX_RETRIES = 20

    # Media URLs
    image_trending = "https://storage.cherrybot.ai/trending.png"
    image_start_dm = "https://storage.cherrybot.ai/start_dm.png"
    image_start_group = "https://storage.cherrybot.ai/startgroup.png"
    image_ads = "https://storage.cherrybot.ai/Ads.png"
    image_raid_boost = "https://storage.cherrybot.ai/Raid_boost.png"
    image_promo = "https://pub-3cc89f6e3f43453594fe8f9510588dac.r2.dev/promo.png"
    image_dex_paid = "https://storage.cherrybot.ai/Dex_paid.png"
    image_project_links = "https://storage.cherrybot.ai/PrLinks.png"
    image_raid_update = "https://storage.cherrybot.ai/Raid_Update.png"
    image_add_links = "https://storage.cherrybot.ai/Tg_group.png"
    image_confirm = "https://storage.cherrybot.ai/confirm.png"
    image_launchpad = "https://storage.cherrybot.ai/launchpad.png"
    image_package = "https://storage.cherrybot.ai/package.png"
    image_settings = "https://storage.cherrybot.ai/settings.png"
    image_token_ca = "https://storage.cherrybot.ai/token_ca.png"
    image_your_dex = "https://storage.cherrybot.ai/your_dex.png"
    image_your_group = "https://storage.cherrybot.ai/your_group.png"

    trend_points_expiry = 12  # Hours
    service_message_delete_delay = 10
    greeting_message_delete_delay = 90

