# MTK Logger

Logging utilities for MarkTrack applications.

## Installation

To install from GitHub Packages:

```bash
# Configure pip to use GitHub Packages
pip config set global.extra-index-url https://YOUR_GITHUB_TOKEN@github.com/pprasquier/mtk_logger/raw/main/dist/

# Install the package
pip install mtk_logger
```

Or with Poetry:

```bash
# Add GitHub Packages as a source
poetry source add --priority=supplemental github https://github.com/pprasquier/mtk_logger/raw/main/dist/

# Install the package
poetry add mtk_logger
```

## Usage

Default import (optional `settings_dir`; defaults to `"settings_files"` for backwards compatibility):

```python
from mtk_logger import get_logger

logger = get_logger(__name__)
logger.info("This is a log message")
```

Custom Prefy settings directory (same pattern as `Preferences(settings_dir)` elsewhere):

```python
from mtk_logger import get_logger

logger = get_logger(__name__, settings_dir="backend/settings/app")
```

Structured JSON logs (`log_format` = `json` in Prefy) include any keys you set on `CorrelationContext`, plus fields passed via stdlib `extra=` (0.7.0+):

```python
from mtk_logger import CorrelationContext, get_logger

logger = get_logger(__name__, settings_dir="path/to/settings")
CorrelationContext.set("cycle_id", "cyc-abc")
CorrelationContext.set("job_id", "job-123")  # vendor-neutral: any string keys
logger.info(
    "doing work",
    extra={"event": "pipeline.cycle.created", "latency_ms": 42},
)
```

The JSON `event` field uses `extra["event"]` when provided; otherwise it falls back to the logger name (0.6.x behaviour). `CorrelationContext` values override the same key on `extra=`.

Exports: `MTKLogger`, `get_logger`, `CorrelationContext`, `JSONFormatter`.

## FastAPI middleware

```python
from mtk_logger.fastapi_middleware import RequestLoggingMiddleware

app.add_middleware(RequestLoggingMiddleware)
```

With a custom settings directory (matches `get_logger(..., settings_dir=...)`):

```python
from mtk_logger.fastapi_middleware import RequestLoggingMiddleware

app.add_middleware(RequestLoggingMiddleware, settings_dir="backend/settings/app")
```

`RequestLoggingMiddleware` sets `request_id` on `CorrelationContext` for the request lifetime (restored afterward) and emits `latency_ms` on the completion log via `extra=`. Legacy message text is unchanged.

### 0.9.0 migration note

The public constructor signature and log events are unchanged. Only the implementation moved from Starlette `BaseHTTPMiddleware` to pure ASGI (`async def __call__(self, scope, receive, send)`), which avoids deadlocks when stacked with other pure-ASGI middleware under `httpx.ASGITransport` / `TestClient`. No application code changes are required beyond bumping the dependency.

See `settings_example.json` for Prefy keys: `log_dir`, `log_format`, `process_name`, etc.
