import os
import sys
import logging
from logging.handlers import TimedRotatingFileHandler
from prefy import Preferences

### BE SURE TO ADD log_file_name and app_name settings. Cf. settings_example.json


def _resolve_log_dir(log_dir: str, settings_dir: str, base_dir: str | None = None) -> str:
    """Resolve a relative ``log_dir`` to an absolute path.

    Resolution order for a *relative* ``log_dir``:

    1. ``base_dir`` given  -> anchor to it. This is the explicit, preferred form:
       the caller states the anchor (e.g. its project/service root) and no
       directory-layout is inferred.
    2. ``base_dir`` is None -> anchor to ``settings_dir``; if that bundle sits
       directly under a directory named ``settings`` (``<root>/settings/<tier>``)
       fall back to the service root ``<root>``. Retained for backwards
       compatibility with callers that do not pass ``base_dir``.

    Absolute ``log_dir`` values are returned unchanged in all cases.
    """
    if os.path.isabs(log_dir):
        return log_dir
    if base_dir is not None:
        return os.path.normpath(os.path.join(os.path.abspath(base_dir), log_dir))
    base = os.path.abspath(settings_dir)
    if os.path.basename(os.path.dirname(base)) == "settings":
        base = os.path.dirname(os.path.dirname(base))
    return os.path.normpath(os.path.join(base, log_dir))


class _ScriptIdFilter(logging.Filter):
    """Injects script_id on each LogRecord for text-mode Formatter."""

    def __init__(self, script_id: str):
        super().__init__()
        self.script_id = script_id

    def filter(self, record: logging.LogRecord) -> bool:
        record.script_id = self.script_id
        return True


class MTKLogger(logging.Logger):
    def __init__(self, script_name=None, backup_count=7, settings_dir="settings_files", base_dir=None):
        settings = Preferences(settings_dir)

        log_file_name = settings.log_file_name
        app_name = settings.app_name

        super().__init__(app_name)
        preferences_level = settings.log_level
        level = getattr(logging, preferences_level, logging.DEBUG)
        self.setLevel(level)

        log_dir = _resolve_log_dir(settings.log_dir, settings_dir, base_dir)
        os.makedirs(log_dir, exist_ok=True)
        log_filename = os.path.join(log_dir, f"{log_file_name}.log")

        script_id = script_name or os.path.basename(sys.argv[0])

        file_handler = TimedRotatingFileHandler(
            filename=log_filename,
            when="midnight",
            interval=1,
            backupCount=backup_count,
            encoding="utf-8",
            utc=False,
        )
        file_handler.setLevel(logging.DEBUG)
        self.addHandler(file_handler)

        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.DEBUG)
        self.addHandler(console_handler)

        log_format = getattr(settings, "log_format", "text")

        if log_format == "json":
            from mtk_logger.formatters import JSONFormatter

            process_name = getattr(settings, "process_name", "api")
            formatter = JSONFormatter(process_name=process_name)
        else:
            self.addFilter(_ScriptIdFilter(script_id))
            formatter = logging.Formatter(
                "%(asctime)s - %(name)s - %(levelname)s - %(script_id)s - "
                "[Line %(lineno)d] - %(message)s"
            )

        for handler in self.handlers:
            handler.setFormatter(formatter)

        self.json_mode = log_format == "json"

        self.debug(
            "Logging initialized for script: %s, daily rotation enabled, logs in: %s",
            script_id,
            log_filename,
        )


def get_logger(script_name=None, backup_count=7, settings_dir="settings_files", base_dir=None):
    return MTKLogger(script_name, backup_count, settings_dir, base_dir)
