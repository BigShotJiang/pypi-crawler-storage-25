"""
Generic contextvars-backed key-value storage for correlation IDs.

Provides vendor-neutral thread-safe and async-task-safe storage for arbitrary correlation IDs.
These IDs are automatically picked up by JSONFormatter without needing to thread them
through every log call.

Vendor-neutral design: OOT uses cycle_id/trace_id/participant_id; mtk_craft_be may use
job_id/worker_id; any caller can set/get arbitrary string keys.
"""

from contextvars import ContextVar
from typing import Optional


class CorrelationContext:
    """
    Generic contextvars-backed key-value store for correlation IDs.

    Uses contextvars so that each async task has its own context, inherited from
    the parent task on creation. Modifications in a child task do not affect siblings
    or the parent.

    Vendor-neutral: store any string keys; JSONFormatter automatically includes all
    set values in JSON output.

    Usage (OOT):
        >>> from mtk_logger.correlation import CorrelationContext
        >>> CorrelationContext.set("cycle_id", "cyc-abc123")
        >>> CorrelationContext.set("trace_id", "tr-xyz789")
        >>> CorrelationContext.get("cycle_id")
        'cyc-abc123'

    Usage (mtk_craft_be):
        >>> CorrelationContext.set("job_id", "job-123")
        >>> CorrelationContext.set("worker_id", "w-001")
    """

    _vars: dict[str, ContextVar[Optional[str]]] = {}

    @classmethod
    def set(cls, key: str, value: Optional[str]) -> None:
        """
        Set a correlation ID by key.

        Args:
            key: Arbitrary string key (e.g., "cycle_id", "job_id", "request_id")
            value: String value, or None to clear the key
        """
        if key not in cls._vars:
            cls._vars[key] = ContextVar(f"mtk_{key}", default=None)
        cls._vars[key].set(value)

    @classmethod
    def get(cls, key: str) -> Optional[str]:
        """
        Get a correlation ID by key.

        Args:
            key: The key to retrieve

        Returns:
            The value, or None if not set or never registered
        """
        if key not in cls._vars:
            return None
        return cls._vars[key].get()

    @classmethod
    def as_dict(cls) -> dict[str, str]:
        """
        Return a dict of all currently-set correlation IDs.

        Returns:
            Dictionary with all set keys (only present if non-None)

        Example (OOT):
            >>> CorrelationContext.set("cycle_id", "cyc-123")
            >>> CorrelationContext.set("trace_id", "tr-456")
            >>> CorrelationContext.as_dict()
            {'cycle_id': 'cyc-123', 'trace_id': 'tr-456'}

        Example (mtk_craft_be):
            >>> CorrelationContext.set("job_id", "job-789")
            >>> CorrelationContext.as_dict()
            {'job_id': 'job-789'}
        """
        return {
            key: value.get()
            for key, value in cls._vars.items()
            if value.get() is not None
        }

    @classmethod
    def clear(cls) -> None:
        """Clear all correlation IDs (useful for test isolation)."""
        for var in cls._vars.values():
            var.set(None)
