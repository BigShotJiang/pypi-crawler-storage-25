import json
import os
import time
import uuid
from collections.abc import MutableMapping
from typing import Any

from starlette.datastructures import QueryParams

from mtk_logger.correlation import CorrelationContext
from mtk_logger.logger import get_logger


class RequestLoggingMiddleware:
    def __init__(self, app, settings_dir="settings_files"):
        self.app = app
        self._settings_dir = settings_dir

    async def __call__(self, scope, receive, send):
        if scope.get("type") != "http":
            await self.app(scope, receive, send)
            return

        request_id = str(uuid.uuid4())
        start_time = time.time()
        prior_correlation = CorrelationContext.as_dict()
        CorrelationContext.set("request_id", request_id)

        try:
            logger = get_logger(
                os.path.basename(__file__), settings_dir=self._settings_dir
            )

            path = scope.get("path", "")
            method = scope.get("method", "")
            logger.debug(f'("Request: {request_id} - {method} {path}")')

            query_params: dict[str, Any] = {}
            query_params_obj = QueryParams(scope.get("query_string", b""))
            for key, value in query_params_obj.multi_items():
                if key in query_params:
                    logger.debug(f"Duplicate key '{key}' found in query parameters")
                    if not isinstance(query_params[key], list):
                        query_params[key] = [query_params[key]]
                    query_params[key].append(value)
                else:
                    query_params[key] = value
                    logger.debug(f"Added key '{key}' to query parameters")

            body = None
            receive_for_app = receive

            if method in ("POST", "PUT", "PATCH"):
                body_bytes = b""
                while True:
                    message = await receive()
                    if message["type"] != "http.request":
                        continue
                    body_bytes += message.get("body", b"")
                    if not message.get("more_body", False):
                        break

                async def replay_receive():
                    return {
                        "type": "http.request",
                        "body": body_bytes,
                        "more_body": False,
                    }

                receive_for_app = replay_receive

                try:
                    body = json.loads(body_bytes.decode())
                    if isinstance(body, dict):
                        for key, value in body.items():
                            if isinstance(value, list) and len(value) > 5:
                                sample = value[:3]
                                body[key] = {
                                    "count": len(value),
                                    "sample": sample,
                                }
                except Exception:
                    body = {"raw_size": len(body_bytes), "note": "Non-JSON body"}

            log_data = {
                "request_id": request_id,
                "method": method,
                "path": path,
                "query_params": query_params,
                "body": body,
            }

            logger.info(
                f"API Request: {json.dumps(log_data)}",
                extra={"event": "api.request.received"},
            )

            messages: list[MutableMapping[str, Any]] = []

            async def send_wrapper(message):
                messages.append(message)

            await self.app(scope, receive_for_app, send_wrapper)

            response_start = next(
                (m for m in messages if m["type"] == "http.response.start"),
                None,
            )
            response_body = b"".join(
                m.get("body", b"")
                for m in messages
                if m["type"] == "http.response.body"
            )

            status_code = response_start["status"] if response_start else 0

            try:
                response_data = json.loads(response_body.decode())
                if isinstance(response_data, list):
                    record_count = len(response_data)
                else:
                    record_count = 1
            except json.JSONDecodeError:
                record_count = 0

            process_time = time.time() - start_time
            latency_ms = round(process_time * 1000)

            logger.info(
                f"Request {request_id} completed in {process_time:.4f}s with status "
                f"{status_code} and {record_count} records",
                extra={
                    "event": "api.request.completed",
                    "latency_ms": latency_ms,
                },
            )
            logger.debug(f"Request {request_id} response= {response_body.decode()}")

            for message in messages:
                await send(message)
        finally:
            CorrelationContext.clear()
            for key, value in prior_correlation.items():
                CorrelationContext.set(key, value)
