"""
JSON formatter for structured logging with correlation IDs.

JSONFormatter reads correlation IDs from CorrelationContext (contextvars) and emits
single-line JSON with mandatory and optional fields.
"""

import json
import logging
import re
import sys
import traceback
from datetime import datetime, timezone

from mtk_logger.correlation import CorrelationContext

# Stdlib LogRecord keys — never emit as passthrough fields.
_BUILTIN_RECORD_KEYS = frozenset(
    logging.LogRecord(
        name="",
        level=logging.INFO,
        pathname="",
        lineno=0,
        msg="",
        args=(),
        exc_info=None,
    ).__dict__.keys()
)

# Formatter-owned output keys — passthrough must not override these.
_OUTPUT_KEYS = frozenset({"timestamp", "process", "level", "event", "message"})

# Emitted from exc_info handling, not arbitrary extra=.
_EXC_OUTPUT_KEYS = frozenset({"error_class", "stack_trace"})


def _resolve_event(record: logging.LogRecord) -> str:
    """TF-15 event from extra=; fall back to logger name for 0.6.x compatibility."""
    event = getattr(record, "event", None)
    if event is not None:
        return str(event)
    return record.name


def _extra_fields(record: logging.LogRecord) -> dict[str, object]:
    """Non-reserved LogRecord attributes from logging extra= (and similar)."""
    skip = _BUILTIN_RECORD_KEYS | _OUTPUT_KEYS | _EXC_OUTPUT_KEYS
    out: dict[str, object] = {}
    for key, value in record.__dict__.items():
        if key in skip or key.startswith("_"):
            continue
        if key in out:
            continue
        try:
            json.dumps(value)
        except (TypeError, ValueError):
            continue
        out[key] = value
    return out


class JSONFormatter(logging.Formatter):
    """
    Emit structured JSON logs with correlation IDs and optional fields.

    Vendor-neutral: automatically includes any keys from CorrelationContext.

    Mandatory fields per log line:
    - timestamp: ISO 8601 UTC
    - process: one of "api", "worker", "scheduler"
    - level: DEBUG, INFO, WARNING, ERROR, CRITICAL
    - event: from logging extra= when provided (e.g. "pipeline.cycle.created");
      otherwise the logger name (0.6.x compatibility)
    - message: formatted log message

    Optional fields (included when present):
    - CorrelationContext keys: any keys set via CorrelationContext.set(key, value)
    - Arbitrary extra= keys merged into the JSON object (0.7.0+), except reserved keys
    - latency_ms, payload_size: via extra= or attributes on the LogRecord
    - error_class, stack_trace: from exc_info (not taken from extra=)
    """

    _REDACT_PATTERNS = [
        (r'user_message\s*=\s*["\']([^"\']*)["\']', 'user_message="<redacted>"'),
        (r'content\s*=\s*["\']([^"\']*)["\']', 'content="<redacted>"'),
        (r'body\s*=\s*["\']([^"\']*)["\']', 'body="<redacted>"'),
        (r"'content'\s*:\s*'[^']*'", "'content': '<redacted>'"),
        (r'"content"\s*:\s*"[^"]*"', '"content": "<redacted>"'),
        (r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b", "<email>"),
        (r"api_key\s*=\s*[\w-]+", "api_key=<redacted>"),
        (r"token\s*=\s*[\w-]+", "token=<redacted>"),
        (r"password\s*=\s*[\w-]+", "password=<redacted>"),
    ]

    def __init__(self, process_name: str = "api"):
        """
        Initialize JSONFormatter.

        Args:
            process_name: One of "api", "worker", "scheduler".
                         Embedded in every log line's "process" field.
        """
        super().__init__()
        if process_name not in ("api", "worker", "scheduler"):
            raise ValueError(
                f"process_name must be 'api', 'worker', or 'scheduler', got '{process_name}'"
            )
        self.process_name = process_name

    def format(self, record: logging.LogRecord) -> str:
        output: dict[str, object] = {
            "timestamp": self._format_timestamp(record),
            "process": self.process_name,
            "level": record.levelname,
            "event": _resolve_event(record),
            "message": record.getMessage(),
        }

        output.update(_extra_fields(record))
        output.update(CorrelationContext.as_dict())

        if hasattr(record, "latency_ms"):
            output["latency_ms"] = record.latency_ms
        if hasattr(record, "payload_size"):
            output["payload_size"] = record.payload_size

        if record.exc_info:
            exc_info = record.exc_info
            if exc_info is True:
                exc_info = sys.exc_info()
            if not exc_info or exc_info[0] is None:
                pass
            else:
                exc_type, exc_value, exc_traceback = exc_info
                if exc_type:
                    output["error_class"] = exc_type.__name__
                if exc_traceback:
                    stack_trace = self._format_exception_from_tuple(exc_info)
                    output["stack_trace"] = self._scrub_pii(stack_trace)

        return json.dumps(output, ensure_ascii=False)

    def _format_timestamp(self, record: logging.LogRecord) -> str:
        dt = datetime.fromtimestamp(record.created, tz=timezone.utc)
        return dt.isoformat(timespec="milliseconds").replace("+00:00", "Z")

    def _format_exception_from_tuple(self, exc_info) -> str:
        exc_type, exc_value, exc_tb = exc_info
        return "".join(traceback.format_exception(exc_type, exc_value, exc_tb))

    def _scrub_pii(self, text: str) -> str:
        result = text
        for pattern, replacement in self._REDACT_PATTERNS:
            result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)
        return result
