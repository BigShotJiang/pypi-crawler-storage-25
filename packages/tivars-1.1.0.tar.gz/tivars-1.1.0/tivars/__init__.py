"""
A library for interacting with TI-(e)z80 (82/83/84 series) calculator files

Docs and API reference for specific functionalities are in the modules listed below.
Example scripts can be found `in the repository <https://github.com/TI-Toolkit/tivars_lib_py/tree/main/examples>`_.
"""


from .bundle import *
from .file import *
from .flash import *
from .models import *
from .tokenizer import *
from .types import *
from .var import *


__version__ = "1.1.0"
__all__ = list({*bundle.__all__, *file.__all__, *flash.__all__, *models.__all__, *tokenizer.__all__, *types.__all__, *var.__all__, "__version__"})
