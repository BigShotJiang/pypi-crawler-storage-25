"""Cross-platform hardware ID generation."""

import hashlib
import os
import platform
import re
import socket
import subprocess
from typing import List


# Salt for hardware ID generation (matches .NET client)
_HARDWARE_SALT = "ExisOneHardwareSalt_v1"

# Lines in /proc/cpuinfo that fluctuate between reads (cpufreq scaling,
# turbo boost, bogomips drift). Including them in the fingerprint produces
# a different hash on every call, which we definitely do not want.
_CPUINFO_VOLATILE_PREFIXES = (
    "cpu mhz",
    "bogomips",
    "cache size",
    "core id",
    "apicid",
    "initial apicid",
    "cpu cores",
    "siblings",
    "processor",
)

# Network interface name prefixes that belong to virtual / transient
# adapters (Docker, VPN tunnels, VMs, WSL, etc.). Their MAC addresses come
# and go with the lifecycle of the underlying software, so they make
# unreliable fingerprint inputs.
_VIRTUAL_NIC_PREFIXES = (
    "docker", "br-", "veth", "virbr", "vmnet", "vboxnet",
    "tun", "tap", "wg", "tailscale", "zt", "utun",
)


def generate_hardware_id() -> str:
    """
    Generate a cross-platform hardware fingerprint.

    Collects various hardware identifiers (CPU, disk, MAC addresses, etc.)
    and produces a stable SHA-256 hash. This matches the algorithm used
    by the .NET ExisOne client for compatibility.

    Returns:
        64-character uppercase hex string (SHA-256 hash)
    """
    components: List[str] = []

    system = platform.system()

    # Platform-specific hardware identifiers
    if system == "Windows":
        components.extend(_get_windows_identifiers())
    else:
        components.extend(_get_unix_identifiers())

    # MAC addresses (all platforms)
    components.extend(_get_mac_addresses())

    # Generic system info (all platforms)
    components.append("x64" if platform.machine().endswith("64") else "x86")
    components.append(str(os.cpu_count() or 1))
    components.append(socket.gethostname())
    components.append(platform.platform())

    # Combine and hash
    combined = "".join(components)
    salted = _HARDWARE_SALT + combined

    hash_bytes = hashlib.sha256(salted.encode("utf-8")).digest()
    return hash_bytes.hex().upper()


def _get_windows_identifiers() -> List[str]:
    """Get Windows-specific hardware identifiers via WMI."""
    identifiers: List[str] = []

    wmi_queries = [
        ("Win32_Processor", "ProcessorId"),
        ("Win32_BaseBoard", "SerialNumber"),
        ("Win32_BIOS", "SerialNumber"),
        ("Win32_DiskDrive", "SerialNumber"),
    ]

    for class_name, prop_name in wmi_queries:
        try:
            result = subprocess.run(
                ["wmic", class_name, "get", prop_name],
                capture_output=True,
                text=True,
                timeout=5,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0
            )
            if result.returncode == 0:
                lines = result.stdout.strip().split("\n")
                if len(lines) > 1:
                    value = lines[1].strip()
                    if value and value.lower() not in ("none", "to be filled by o.e.m."):
                        identifiers.append(value)
        except Exception:
            pass

    return identifiers


def _get_unix_identifiers() -> List[str]:
    """Get Linux/macOS hardware identifiers."""
    identifiers: List[str] = []

    # Machine ID files (Linux)
    machine_id_paths = [
        "/etc/machine-id",
        "/var/lib/dbus/machine-id",
        "/sys/class/dmi/id/product_uuid",
    ]

    for path in machine_id_paths:
        try:
            if os.path.exists(path):
                with open(path, "r") as f:
                    content = f.read().strip()
                    if content:
                        identifiers.append(content)
        except Exception:
            pass

    # CPU info (Linux) — strip out volatile lines (cpu MHz, bogomips, etc.)
    # so the same machine produces the same fingerprint across reads.
    try:
        if os.path.exists("/proc/cpuinfo"):
            with open("/proc/cpuinfo", "r") as f:
                stable_lines = []
                for line in f:
                    key = line.split(":", 1)[0].strip().lower()
                    if not key:
                        continue
                    if any(key.startswith(p) for p in _CPUINFO_VOLATILE_PREFIXES):
                        continue
                    stable_lines.append(line.rstrip())
                if stable_lines:
                    identifiers.append("\n".join(stable_lines))
        elif platform.system() == "Darwin":
            # macOS: get hardware UUID
            result = subprocess.run(
                ["system_profiler", "SPHardwareDataType"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                for line in result.stdout.split("\n"):
                    if "Hardware UUID" in line:
                        uuid_val = line.split(":")[-1].strip()
                        if uuid_val:
                            identifiers.append(uuid_val)
                        break
    except Exception:
        pass

    return identifiers


def _is_virtual_nic_name(name: str) -> bool:
    """Return True if the interface name looks like a virtual / transient adapter."""
    if not name:
        return False
    n = name.lower()
    return any(n.startswith(p) for p in _VIRTUAL_NIC_PREFIXES)


def _get_mac_addresses() -> List[str]:
    """
    Get MAC addresses from network interfaces.

    Deliberately does NOT use ``uuid.getnode()``: when the OS cannot read a
    real hardware MAC, ``getnode()`` returns a *random* 48-bit value, which
    would make the entire fingerprint random and break license matching.

    Virtual / transient adapters (Docker, VPN tunnels, VMs, WSL, etc.) are
    excluded by name so the result stays stable across container / VM
    lifecycle events.
    """
    macs: List[str] = []
    system = platform.system()

    try:
        if system == "Windows":
            # `getmac /v /fo csv /nh` outputs: "Connection","Adapter","MAC","Transport"
            result = subprocess.run(
                ["getmac", "/v", "/fo", "csv", "/nh"],
                capture_output=True,
                text=True,
                timeout=5,
                creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0,
            )
            if result.returncode == 0:
                for line in result.stdout.strip().split("\n"):
                    parts = [p.strip('"') for p in line.split(",")]
                    if len(parts) < 3:
                        continue
                    conn_name, _adapter, raw_mac = parts[0], parts[1], parts[2]
                    if _is_virtual_nic_name(conn_name):
                        continue
                    mac = raw_mac.replace("-", "").replace(":", "").upper()
                    if mac and len(mac) == 12 and mac != "000000000000" and mac not in macs:
                        macs.append(mac)
        elif system == "Linux":
            # `ip -o link show` produces one line per interface:
            #   2: eth0: <BROADCAST,MULTICAST,UP> mtu 1500 ... link/ether aa:bb:cc:dd:ee:ff ...
            result = subprocess.run(
                ["ip", "-o", "link", "show"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                for line in result.stdout.split("\n"):
                    m = re.match(r"^\d+:\s+([^:@\s]+)[@:]", line)
                    if not m:
                        continue
                    iface_name = m.group(1)
                    if _is_virtual_nic_name(iface_name) or iface_name == "lo":
                        continue
                    if "link/ether" not in line:
                        continue
                    parts = line.split()
                    idx = parts.index("link/ether") + 1
                    if idx < len(parts):
                        mac = parts[idx].replace(":", "").upper()
                        if mac and len(mac) == 12 and mac != "000000000000" and mac not in macs:
                            macs.append(mac)
        elif system == "Darwin":
            # `ifconfig -a` lists each interface and any associated MAC.
            result = subprocess.run(
                ["ifconfig", "-a"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                current_iface = None
                for line in result.stdout.split("\n"):
                    if line and not line.startswith((" ", "\t")):
                        # New interface block: "en0: flags=..."
                        current_iface = line.split(":", 1)[0].strip()
                        continue
                    if current_iface and not _is_virtual_nic_name(current_iface) \
                            and current_iface != "lo0" and "ether " in line:
                        parts = line.split()
                        idx = parts.index("ether") + 1
                        if idx < len(parts):
                            mac = parts[idx].replace(":", "").upper()
                            if mac and len(mac) == 12 and mac != "000000000000" and mac not in macs:
                                macs.append(mac)
    except Exception:
        pass

    # Sort for consistency across runs.
    macs.sort()
    return macs
