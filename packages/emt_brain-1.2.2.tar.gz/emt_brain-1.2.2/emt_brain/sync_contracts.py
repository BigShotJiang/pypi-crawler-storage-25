"""sync_contracts.py — Populate global contracts into per-workflow contracts/ folders.

Per ADR-001 D9: each v2 workflow has a local copy of universal contracts (e.g.,
`envelope-v1.json`) in its `contracts/` folder. This module copies the source
from `flezi-emt/global-contracts/` into each v2 workflow's local `contracts/`.

- Source: `<repo>/flezi-emt/global-contracts/<universal-contract>.json`
- Target: `<repo>/flezi-emt/workflows/<wf>/contracts/<universal-contract>.json`
- Detection: workflows with `blueprint_version: "2.0"` or `contracts_index` in SKILL.md frontmatter
- Version tracking: sidecar file `<wf>/contracts/.sync-manifest.json` records
  source_sha256 per universal contract — enables drift detection on re-sync

Only universal contracts (those declared in the global-contracts/ folder) get
populated. Per-workflow contracts authored in `contracts/index.yaml` are left
untouched.
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None  # type: ignore[assignment]


MANIFEST_FILENAME = ".sync-manifest.json"

# Universal contracts to propagate into each v2 workflow.
# Extend this set if more universal contracts are added to global-contracts/.
UNIVERSAL_CONTRACTS = {"envelope-v1.json"}


@dataclass
class SyncResult:
    workflow_id: str
    action: str  # "copied" | "refreshed" | "skipped-v1" | "up-to-date" | "error"
    contract_name: str
    detail: str = ""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _sha256(data: bytes) -> str:
    h = hashlib.sha256()
    h.update(data)
    return h.hexdigest()


def _parse_frontmatter(skill_md: Path) -> dict:
    if not skill_md.exists():
        return {}
    content = skill_md.read_text(encoding="utf-8")
    match = re.match(r"^---\n(.*?)\n---", content, re.DOTALL)
    if not match:
        return {}
    if yaml is None:
        return {}
    try:
        fm = yaml.safe_load(match.group(1))
        return fm if isinstance(fm, dict) else {}
    except Exception:
        return {}


def _is_v2_workflow(fm: dict) -> bool:
    if fm.get("blueprint_version") == "2.0":
        return True
    if fm.get("contracts_index"):
        return True
    return False


def _discover_workflows(repo_root: Path) -> list[Path]:
    """Return list of workflow directories (folders with SKILL.md) under workflows/."""
    workflows_root = repo_root / "flezi-emt" / "workflows"
    if not workflows_root.exists():
        return []
    return sorted([
        p for p in workflows_root.iterdir()
        if p.is_dir() and (p / "SKILL.md").exists()
    ])


def _load_manifest(contracts_dir: Path) -> dict:
    mf = contracts_dir / MANIFEST_FILENAME
    if not mf.exists():
        return {}
    try:
        return json.loads(mf.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def _write_manifest(contracts_dir: Path, manifest: dict, dry_run: bool) -> None:
    if dry_run:
        return
    mf = contracts_dir / MANIFEST_FILENAME
    mf.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------
# Per-workflow sync
# ---------------------------------------------------------------------------


def _sync_one_workflow(
    workflow_dir: Path,
    global_contracts_dir: Path,
    dry_run: bool = False,
) -> list[SyncResult]:
    """Sync universal contracts into a single workflow's contracts/ folder.

    Returns one SyncResult per universal contract processed.
    """
    wf_id = workflow_dir.name
    results: list[SyncResult] = []

    fm = _parse_frontmatter(workflow_dir / "SKILL.md")
    if not _is_v2_workflow(fm):
        results.append(SyncResult(wf_id, "skipped-v1", "<all>", "workflow has no v2 markers"))
        return results

    contracts_dir = workflow_dir / "contracts"
    if not contracts_dir.exists() and not dry_run:
        contracts_dir.mkdir(parents=True, exist_ok=True)

    manifest = _load_manifest(contracts_dir)

    for contract_name in sorted(UNIVERSAL_CONTRACTS):
        src = global_contracts_dir / contract_name
        if not src.exists():
            results.append(SyncResult(wf_id, "error", contract_name, f"source missing: {src}"))
            continue

        src_bytes = src.read_bytes()
        src_sha = _sha256(src_bytes)
        target = contracts_dir / contract_name

        recorded = manifest.get(contract_name, {}).get("source_sha256")
        target_exists = target.exists()

        if target_exists and recorded == src_sha:
            results.append(SyncResult(wf_id, "up-to-date", contract_name))
            continue

        action = "refreshed" if target_exists else "copied"
        if not dry_run:
            target.write_bytes(src_bytes)
            manifest[contract_name] = {
                "source_path": str(src.relative_to(global_contracts_dir.parent.parent)),
                "source_sha256": src_sha,
            }
        results.append(SyncResult(wf_id, action, contract_name,
                                   f"sha={src_sha[:8]} -> {target.name}"))

    _write_manifest(contracts_dir, manifest, dry_run)
    return results


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------


def populate_envelope_to_workflows(
    repo_root: Path,
    dry_run: bool = False,
) -> list[SyncResult]:
    """Main entry: iterate all v2 workflows, copy universal contracts.

    Returns aggregated SyncResult list across all workflows.
    """
    global_dir = repo_root / "flezi-emt" / "global-contracts"
    if not global_dir.exists():
        return [SyncResult("<repo>", "error", "<all>",
                            f"global-contracts folder not found at {global_dir}")]

    workflows = _discover_workflows(repo_root)
    if not workflows:
        return [SyncResult("<repo>", "error", "<all>",
                            f"no workflows found under {repo_root / 'flezi-emt' / 'workflows'}")]

    all_results: list[SyncResult] = []
    for wf in workflows:
        all_results.extend(_sync_one_workflow(wf, global_dir, dry_run=dry_run))
    return all_results


def check_envelope_version_drift(repo_root: Path) -> list[SyncResult]:
    """Report contracts whose local copy sha doesn't match source.

    Non-destructive — suggests re-sync but does not perform it.
    """
    global_dir = repo_root / "flezi-emt" / "global-contracts"
    if not global_dir.exists():
        return []

    drift: list[SyncResult] = []
    for wf in _discover_workflows(repo_root):
        fm = _parse_frontmatter(wf / "SKILL.md")
        if not _is_v2_workflow(fm):
            continue
        contracts_dir = wf / "contracts"
        manifest = _load_manifest(contracts_dir)
        for contract_name in sorted(UNIVERSAL_CONTRACTS):
            src = global_dir / contract_name
            if not src.exists():
                continue
            src_sha = _sha256(src.read_bytes())
            recorded = manifest.get(contract_name, {}).get("source_sha256")
            target = contracts_dir / contract_name
            if not target.exists():
                drift.append(SyncResult(wf.name, "error", contract_name,
                                         "local copy missing"))
            elif recorded != src_sha:
                drift.append(SyncResult(wf.name, "drift", contract_name,
                                         f"recorded={recorded[:8] if recorded else 'none'}, source={src_sha[:8]}"))
    return drift


def format_results(results: list[SyncResult]) -> str:
    """Render results as human-readable summary."""
    if not results:
        return "(no contracts processed)"

    by_action: dict[str, list[SyncResult]] = {}
    for r in results:
        by_action.setdefault(r.action, []).append(r)

    lines = []
    for action in sorted(by_action.keys()):
        entries = by_action[action]
        lines.append(f"\n[{action}] {len(entries)} contract(s):")
        for e in entries:
            detail = f" — {e.detail}" if e.detail else ""
            lines.append(f"  - {e.workflow_id}/{e.contract_name}{detail}")
    return "\n".join(lines).lstrip()
