"""mcp_setup.py — install and activate MCP servers for Claude Code.

Three modes:
  npx        — npm-packaged servers, run via `npx -y <package>`
  npm-global  — npm-packaged servers installed globally, run via
                `node <npm-root-g>/<package>/<entrypoint>`
  local      — GitHub-sourced servers cloned locally, npm-installed,
                run via `node <entry>` (legacy; prefer npm-global for
                published packages)

Installation strategy (in priority order):
  1. `claude` CLI available → `claude mcp add -s user <name> -- <cmd> <args>`
     Writes to ~/.claude.json; shows as "User config" in `claude mcp get`.
  2. Fallback → write mcpServers entry directly to ~/.claude/settings.json
     (also user-scope, but managed manually).

Scope is ALWAYS user — never project/local.
"""
from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import NamedTuple

# ---------------------------------------------------------------------------
# Server registry
# ---------------------------------------------------------------------------

MCP_SERVERS: dict[str, dict] = {
    "memory": {
        "mode": "npx",
        "display_name": "Memory",
        "package": "@modelcontextprotocol/server-memory",
    },
    "context-mode": {
        "mode": "npm-global",
        "display_name": "Context Mode",
        "package": "context-mode",
        # server.bundle.mjs is the MCP server — NOT cli.bundle.mjs (CLI tool)
        "entrypoint": "server.bundle.mjs",
        "description": "Context window management (sandbox execution + session continuity)",
    },
}

# Backwards-compatible alias used by older callers
STANDARD_MCP_SERVERS = {
    k: (
        {"command": "npx", "args": ["-y", v["package"]]}
        if v["mode"] == "npx"
        else {}
    )
    for k, v in MCP_SERVERS.items()
}


class McpServerStatus(NamedTuple):
    name: str
    display_name: str
    package: str
    already_configured: bool
    added: bool
    mode: str = "npx"
    install_path: Path | None = None
    error: str | None = None
    updated: bool = False  # npm package updated in place (npm-global mode only)


# ---------------------------------------------------------------------------
# Capability checks
# ---------------------------------------------------------------------------

def check_npx_available() -> bool:
    return shutil.which("npx") is not None


def check_npm_available() -> bool:
    return shutil.which("npm") is not None


def check_node_available() -> bool:
    return shutil.which("node") is not None


def check_claude_cli_available() -> bool:
    return shutil.which("claude") is not None


# ---------------------------------------------------------------------------
# claude mcp CLI helpers (primary installation path — guarantees user scope)
# ---------------------------------------------------------------------------

def _claude_mcp_exists_as_user(name: str) -> bool:
    """Return True if server is registered at user scope via claude mcp."""
    if not check_claude_cli_available():
        return False
    result = subprocess.run(
        ["claude", "mcp", "get", name],
        capture_output=True,
        text=True,
    )
    return result.returncode == 0 and "User config" in result.stdout


def _claude_mcp_add_user(name: str, command: str, args: list[str]) -> str | None:
    """Register server at user scope via `claude mcp add -s user`.

    Returns error string on failure, None on success.
    """
    result = subprocess.run(
        ["claude", "mcp", "add", "-s", "user", name, "--", command] + args,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return (result.stderr or result.stdout).strip()[:300] or "claude mcp add failed"
    return None


# ---------------------------------------------------------------------------
# Fallback: direct settings.json write (when claude CLI not available)
# ---------------------------------------------------------------------------

def _user_settings_path() -> Path:
    """~/.claude/settings.json — user-level settings (fallback scope)."""
    return Path.home() / ".claude" / "settings.json"


def _load_settings(path: Path) -> dict:
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return {}
    return {}


def _save_settings(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def _settings_has_server(name: str) -> bool:
    data = _load_settings(_user_settings_path())
    return name in data.get("mcpServers", {})


def _settings_add_server(name: str, command: str, args: list[str]) -> None:
    path = _user_settings_path()
    data = _load_settings(path)
    data.setdefault("mcpServers", {})[name] = {"command": command, "args": args}
    _save_settings(path, data)


# ---------------------------------------------------------------------------
# npm-global helpers
# ---------------------------------------------------------------------------

def _npm_global_root() -> Path | None:
    result = subprocess.run(
        ["npm", "root", "-g"],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return None
    raw = result.stdout.strip()
    return Path(raw) if raw else None


def _npm_global_install(package: str) -> str | None:
    """Run `npm install -g <package>`. Returns error string or None."""
    result = subprocess.run(
        ["npm", "install", "-g", package],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return f"npm install -g failed: {result.stderr.strip()[:300]}"
    return None


# ---------------------------------------------------------------------------
# Local (git clone) helpers — kept for legacy local-mode entries
# ---------------------------------------------------------------------------

def _local_servers_dir() -> Path:
    from platformdirs import user_data_dir
    return Path(user_data_dir("emt-brain")) / "mcp-servers"


def _resolve_entrypoint_local(install_path: Path, hint: str | None) -> Path:
    if hint:
        return install_path / hint
    pkg_path = install_path / "package.json"
    if pkg_path.exists():
        try:
            pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
            bin_field = pkg.get("bin")
            if isinstance(bin_field, str):
                return install_path / bin_field
            if isinstance(bin_field, dict) and bin_field:
                return install_path / next(iter(bin_field.values()))
            main_field = pkg.get("main")
            if main_field:
                return install_path / main_field
        except Exception:
            pass
    return install_path / "index.js"


def _clone_and_build(source: str, install_path: Path) -> str | None:
    if install_path.exists():
        shutil.rmtree(install_path)
    result = subprocess.run(
        ["git", "clone", "--depth=1", source, str(install_path)],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return f"git clone failed: {result.stderr.strip()}"
    npm_result = subprocess.run(
        ["npm", "install", "--prefer-offline"],
        cwd=install_path,
        capture_output=True,
        text=True,
    )
    if npm_result.returncode != 0:
        return f"npm install failed: {npm_result.stderr.strip()[:300]}"
    pkg_path = install_path / "package.json"
    if pkg_path.exists():
        try:
            pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
            if "build" in (pkg.get("scripts") or {}):
                build_result = subprocess.run(
                    ["npm", "run", "build"],
                    cwd=install_path,
                    capture_output=True,
                    text=True,
                )
                if build_result.returncode != 0:
                    return f"npm run build failed: {build_result.stderr.strip()[:300]}"
        except Exception:
            pass
    return None


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def setup_mcp_servers(
    scope: str = "user",          # kept for backwards compat; always treated as user
    project_path: Path | None = None,  # unused; kept for backwards compat
    dry_run: bool = False,
    force: bool = False,
    server_names: list[str] | None = None,
) -> tuple[Path, list[McpServerStatus]]:
    """Ensure registered MCP servers are configured at USER scope.

    Installation priority:
      1. `claude mcp add -s user` (when claude CLI available) → ~/.claude.json
      2. Fallback: write to ~/.claude/settings.json directly

    scope/project_path parameters are ignored — always installs at user scope.
    """
    use_cli = check_claude_cli_available() and not dry_run
    settings_path = _user_settings_path()

    targets = server_names or list(MCP_SERVERS.keys())
    statuses: list[McpServerStatus] = []

    for name in targets:
        if name not in MCP_SERVERS:
            continue
        info = MCP_SERVERS[name]
        mode = info["mode"]

        # ── already configured? ──────────────────────────────────────────────
        already_configured = (
            _claude_mcp_exists_as_user(name)
            if use_cli
            else _settings_has_server(name)
        )

        if already_configured and not force and mode != "npm-global":
            statuses.append(McpServerStatus(
                name=name,
                display_name=info["display_name"],
                package=info.get("package", ""),
                already_configured=True,
                added=False,
                mode=mode,
            ))
            continue

        if dry_run:
            statuses.append(McpServerStatus(
                name=name,
                display_name=info["display_name"],
                package=info.get("package", ""),
                already_configured=already_configured,
                added=False,
                mode=mode,
            ))
            continue

        # ── npx mode ─────────────────────────────────────────────────────────
        if mode == "npx":
            pkg = info["package"]
            command, args = "npx", ["-y", pkg]

            if use_cli:
                err = _claude_mcp_add_user(name, command, args)
            else:
                try:
                    _settings_add_server(name, command, args)
                    err = None
                except Exception as exc:
                    err = str(exc)

            statuses.append(McpServerStatus(
                name=name,
                display_name=info["display_name"],
                package=pkg,
                already_configured=already_configured,
                added=err is None,
                mode=mode,
                error=err,
            ))

        # ── npm-global mode ───────────────────────────────────────────────────
        elif mode == "npm-global":
            pkg = info["package"]
            entrypoint_name = info.get("entrypoint", "index.js")

            if not shutil.which("npm"):
                statuses.append(McpServerStatus(
                    name=name,
                    display_name=info["display_name"],
                    package=pkg,
                    already_configured=already_configured,
                    added=False,
                    mode=mode,
                    error="npm not found on PATH — install Node.js",
                ))
                continue

            err = _npm_global_install(pkg)
            if err:
                statuses.append(McpServerStatus(
                    name=name,
                    display_name=info["display_name"],
                    package=pkg,
                    already_configured=already_configured,
                    added=False,
                    mode=mode,
                    error=err,
                ))
                continue

            global_root = _npm_global_root()
            if not global_root:
                statuses.append(McpServerStatus(
                    name=name,
                    display_name=info["display_name"],
                    package=pkg,
                    already_configured=already_configured,
                    added=False,
                    mode=mode,
                    error="npm root -g failed",
                ))
                continue

            entrypoint = global_root / pkg / entrypoint_name
            if not entrypoint.exists():
                statuses.append(McpServerStatus(
                    name=name,
                    display_name=info["display_name"],
                    package=pkg,
                    already_configured=already_configured,
                    added=False,
                    mode=mode,
                    error=f"entrypoint not found: {entrypoint}",
                ))
                continue

            if already_configured and not force:
                # MCP config already registered; npm install -g above updated the package.
                statuses.append(McpServerStatus(
                    name=name,
                    display_name=info["display_name"],
                    package=pkg,
                    already_configured=True,
                    added=False,
                    updated=True,
                    mode=mode,
                    install_path=global_root / pkg,
                ))
                continue

            command, args = "node", [str(entrypoint)]

            if use_cli:
                err = _claude_mcp_add_user(name, command, args)
            else:
                try:
                    _settings_add_server(name, command, args)
                    err = None
                except Exception as exc:
                    err = str(exc)

            statuses.append(McpServerStatus(
                name=name,
                display_name=info["display_name"],
                package=pkg,
                already_configured=already_configured,
                added=err is None,
                mode=mode,
                install_path=global_root / pkg,
                error=err,
            ))

        # ── local mode (git clone) ────────────────────────────────────────────
        elif mode == "local":
            source = info["source"]
            install_path = _local_servers_dir() / name
            already_cloned = (install_path / "package.json").exists()

            if already_configured and already_cloned and not force:
                statuses.append(McpServerStatus(
                    name=name,
                    display_name=info["display_name"],
                    package=source,
                    already_configured=True,
                    added=False,
                    mode=mode,
                    install_path=install_path,
                ))
                continue

            if not shutil.which("git"):
                statuses.append(McpServerStatus(
                    name=name,
                    display_name=info["display_name"],
                    package=source,
                    already_configured=already_configured,
                    added=False,
                    mode=mode,
                    install_path=install_path,
                    error="git not found on PATH",
                ))
                continue
            if not shutil.which("npm"):
                statuses.append(McpServerStatus(
                    name=name,
                    display_name=info["display_name"],
                    package=source,
                    already_configured=already_configured,
                    added=False,
                    mode=mode,
                    install_path=install_path,
                    error="npm not found on PATH — install Node.js",
                ))
                continue

            err = _clone_and_build(source, install_path)
            if err:
                statuses.append(McpServerStatus(
                    name=name,
                    display_name=info["display_name"],
                    package=source,
                    already_configured=already_configured,
                    added=False,
                    mode=mode,
                    install_path=install_path,
                    error=err,
                ))
                continue

            entrypoint = _resolve_entrypoint_local(install_path, info.get("entrypoint"))
            command, args = "node", [str(entrypoint)]

            if use_cli:
                err = _claude_mcp_add_user(name, command, args)
            else:
                try:
                    _settings_add_server(name, command, args)
                    err = None
                except Exception as exc:
                    err = str(exc)

            statuses.append(McpServerStatus(
                name=name,
                display_name=info["display_name"],
                package=source,
                already_configured=already_configured,
                added=err is None,
                mode=mode,
                install_path=install_path,
                error=err,
            ))

    return settings_path, statuses


# kept for backwards compat
def resolve_settings_path(scope: str, project_path: Path | None = None) -> Path:
    return _user_settings_path()
