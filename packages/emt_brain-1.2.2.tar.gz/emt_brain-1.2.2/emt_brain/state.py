from __future__ import annotations
import json
from pathlib import Path
from platformdirs import user_config_dir, user_data_dir, user_cache_dir

APP_NAME = "emt-brain"


def _config_path() -> Path:
    return Path(user_config_dir(APP_NAME)) / "config.json"


def _state_path() -> Path:
    return Path(user_data_dir(APP_NAME)) / "state.json"


def cache_dir() -> Path:
    return Path(user_cache_dir(APP_NAME)) / "repo-cache"


def _read(path: Path) -> dict:
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {}


def _write(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")


# --- Config ---

def load_config() -> dict:
    return _read(_config_path())


def save_config(data: dict) -> None:
    _write(_config_path(), data)


def config_path() -> Path:
    return _config_path()


# --- State ---

def load_state() -> dict:
    return _read(_state_path())


def save_state(data: dict) -> None:
    _write(_state_path(), data)


def state_path() -> Path:
    return _state_path()
