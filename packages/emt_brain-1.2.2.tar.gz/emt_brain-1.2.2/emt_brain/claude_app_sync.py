"""claude_app_sync.py — Install EMT co-work skills into the Claude desktop app plugin directory."""
from __future__ import annotations

import json
import shutil
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

CLAUDE_APP_DATA = Path.home() / "Library" / "Application Support" / "Claude"
SKILLS_PLUGIN_DIR = CLAUDE_APP_DATA / "local-agent-mode-sessions" / "skills-plugin"
COWORK_CLI_OPS_FILE = CLAUDE_APP_DATA / "cowork-enabled-cli-ops.json"

# Skill IDs that belong to the co-work bundle
COWORK_SKILL_IDS: list[str] = [
    "emt-sk-brand-guide",
    "emt-sk-docx",
    "emt-sk-jp-trans",
    "emt-sk-pdf",
    "emt-sk-pptx",
    "doc-coauthoring",
    "docx",
    "pdf",
    "pptx",
    "xlsx",
]


@dataclass
class SkillSyncResult:
    skill_id: str
    action: str  # "add", "update", "skip", "missing"
    dest: Path | None = None
    error: str | None = None


def is_available() -> bool:
    """Return True if Claude desktop app data directory exists."""
    return CLAUDE_APP_DATA.exists()


def get_account_id() -> str | None:
    """Read the owner account ID from cowork-enabled-cli-ops.json."""
    if not COWORK_CLI_OPS_FILE.exists():
        return None
    try:
        data = json.loads(COWORK_CLI_OPS_FILE.read_text(encoding="utf-8"))
        return data.get("ownerAccountId")
    except Exception:
        return None


def find_plugin_dir(account_id: str) -> Path | None:
    """Find the first plugin directory that contains the account's manifest.json."""
    if not SKILLS_PLUGIN_DIR.exists():
        return None
    for plugin_uuid_dir in SKILLS_PLUGIN_DIR.iterdir():
        if not plugin_uuid_dir.is_dir():
            continue
        account_dir = plugin_uuid_dir / account_id
        if (account_dir / "manifest.json").exists():
            return account_dir
    return None


def load_manifest(plugin_dir: Path) -> dict:
    manifest_path = plugin_dir / "manifest.json"
    if manifest_path.exists():
        try:
            return json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"lastUpdated": 0, "skills": []}


def save_manifest(plugin_dir: Path, manifest: dict, dry_run: bool = False) -> None:
    if dry_run:
        return
    manifest["lastUpdated"] = int(time.time() * 1000)
    (plugin_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )


def _upsert_manifest_entry(manifest: dict, skill_id: str, description: str) -> str:
    """Add or update a skill entry in the manifest. Returns 'add' or 'update'."""
    now = datetime.now(timezone.utc).isoformat()
    existing = next((s for s in manifest["skills"] if s["name"] == skill_id), None)
    if existing:
        existing["description"] = description
        existing["updatedAt"] = now
        return "update"
    manifest["skills"].append({
        "skillId": skill_id,
        "name": skill_id,
        "description": description,
        "creatorType": "user",
        "updatedAt": now,
        "enabled": True,
    })
    return "add"


def _read_description(skill_md: Path) -> str:
    """Extract description from SKILL.md frontmatter."""
    try:
        text = skill_md.read_text(encoding="utf-8")
        in_front = False
        for line in text.splitlines():
            if line.strip() == "---":
                in_front = not in_front
                continue
            if in_front and line.startswith("description:"):
                val = line.split(":", 1)[1].strip().strip('"').strip("'")
                return val
    except Exception:
        pass
    return ""


def install_skills(
    source_skills_root: Path,
    plugin_dir: Path,
    skill_ids: list[str] | None = None,
    dry_run: bool = False,
) -> list[SkillSyncResult]:
    """
    Copy SKILL.md files from source_skills_root into the plugin's skills/ directory
    and update manifest.json.

    Args:
        source_skills_root: directory containing <skill-id>/SKILL.md (e.g. ~/.claude/skills/)
        plugin_dir:         the account-level plugin dir (contains manifest.json + skills/)
        skill_ids:          which skills to sync; defaults to COWORK_SKILL_IDS
        dry_run:            preview without writing
    """
    if skill_ids is None:
        skill_ids = COWORK_SKILL_IDS

    manifest = load_manifest(plugin_dir)
    results: list[SkillSyncResult] = []

    for sid in skill_ids:
        src_dir = source_skills_root / sid
        src_md = src_dir / "SKILL.md"

        if not src_md.exists():
            results.append(SkillSyncResult(skill_id=sid, action="missing", error="not in source root"))
            continue

        dest_dir = plugin_dir / "skills" / sid
        dest_md = dest_dir / "SKILL.md"
        action = "update" if dest_md.exists() else "add"

        description = _read_description(src_md)
        manifest_action = _upsert_manifest_entry(manifest, sid, description)
        # Prefer filesystem state for display
        action = manifest_action

        if not dry_run:
            dest_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_md, dest_md)
            # Copy any extra files (LICENSE, REFERENCE.md, etc.)
            for extra in src_dir.iterdir():
                if extra.is_file() and extra.name != "SKILL.md":
                    shutil.copy2(extra, dest_dir / extra.name)

        results.append(SkillSyncResult(skill_id=sid, action=action, dest=dest_md))

    save_manifest(plugin_dir, manifest, dry_run=dry_run)
    return results
