#!/usr/bin/env node
/**
 * precompact-instruction.mjs — PreCompact hook (HARNESS Layer C — Quality assurance)
 *
 * Injects structured summarization schema into every /compact run.
 * Covers: A1 (structured output), A3 (observation aging), B5 (under-pressure), B6 (early turns).
 *
 * Output: hookSpecificOutput.additionalContext → Claude Code injects into /compact prompt.
 */

import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

try {
  const raw = await new Promise((resolve) => {
    let data = "";
    process.stdin.on("data", (c) => (data += c));
    process.stdin.on("end", () => resolve(data));
    process.stdin.on("error", () => resolve(""));
  });

  const input = raw.trim() ? JSON.parse(raw) : {};
  const cwd = input.cwd || process.cwd();

  // Write post-compact sentinel — consumed by context-pct.mjs on next UserPromptSubmit
  // to grant a grace turn (off-by-1: compact's own API call inflates reported usage)
  try { writeFileSync(join(cwd, ".flezi-emt", ".post-compact"), new Date().toISOString(), "utf8"); } catch {}

  // Try to read session intent for context
  let intentHint = "";
  const intentPath = join(cwd, ".flezi-emt", ".session-intent");
  if (existsSync(intentPath)) {
    try {
      const intent = readFileSync(intentPath, "utf-8").trim().slice(0, 150);
      if (intent) intentHint = `\nSession intent: ${intent}`;
    } catch {}
  }

  const instruction = `[HARNESS/precompact] Structured compaction required.${intentHint}

STRUCTURED SECTIONS (compress all older turns into these):
1. Session Intent (1 line)
2. Files Modified — for each file: full path | change type (created/modified/deleted) | function/method names changed | what specifically changed (no paraphrase, no "updated config")
3. Decisions — reasoning + outcome; ALWAYS include decisions from first 2-3 turns (early constraints are irreplaceable)
4. Open Questions — unresolved blockers with "open: " prefix
5. Resolved Conflicts — any contradictions encountered (version conflicts, perspective clashes) + chosen resolution + rationale; if none, omit section
6. Current State — what is in progress + immediate next step

CATEGORY-AWARE COMPRESSION (apply per content type):
- Tool outputs: extract key metrics/errors (regex: numbers, "error|warn|fail|success|found|total"). Max 200 chars. Format: [Tool: <name> → key result]
- Conversations: preserve decisions and questions verbatim, drop filler/acknowledgments
- Documents/file reads: lead paragraph only + any lines containing identifiers (function names, paths, error codes)
- If budget is tight: drop document/file reads before cutting decisions or file modifications

NEVER compress: tool definitions, function signatures, file paths, error codes, error messages.
Replace tool outputs older than 3 turns: [Obs:N elided. Key: <1-line summary>]
Target: 50-70% token reduction. If >70% → preserve more — do not lose critical state.

SLIDING WINDOW (place this LAST — it is the bottom anchor of the summary):
Summarize the last 1 complete exchange (last user message + last assistant response) in 2-4 sentences.
Preserve verbatim: file paths, function names, error codes, line numbers, decision outcomes.`;

  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: "PreCompact",
      additionalContext: instruction
    }
  }) + "\n");
} catch {
  // Never block compaction — silent exit
  process.exit(0);
}
