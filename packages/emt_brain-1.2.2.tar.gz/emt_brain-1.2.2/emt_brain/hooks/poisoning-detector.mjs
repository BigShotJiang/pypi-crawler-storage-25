/**
 * poisoning-detector.mjs — PostToolUse
 * Detects error-compounding loops: same error fingerprint repeated ≥3×.
 * State: .flezi-emt/.error-log.json (cleared by session-cleanup.mjs on SessionStart)
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";

const POISON_LOG = ".flezi-emt/.error-log.json";
const REPEAT_THRESHOLD = 3;

try {
  const raw = await new Promise((resolve) => {
    let data = "";
    process.stdin.on("data", (c) => (data += c));
    process.stdin.on("end", () => resolve(data));
    process.stdin.on("error", () => resolve(""));
  });
  if (!raw.trim()) process.exit(0);

  const input = JSON.parse(raw);
  const output = input.tool_response?.output ?? "";
  if (!output) process.exit(0);

  let log = {};
  if (existsSync(POISON_LOG)) {
    try { log = JSON.parse(readFileSync(POISON_LOG, "utf-8")); } catch {}
  }

  const errorLines = output
    .split("\n")
    .filter((l) => /error|exception|failed|cannot|undefined is not/i.test(l))
    .map((l) => l.trim().slice(0, 80));

  for (const err of errorLines) {
    if (err.startsWith("__")) continue; // skip system keys (e.g. __refetch_count)
    log[err] = (log[err] ?? 0) + 1;

    if (log[err] === REPEAT_THRESHOLD) {
      mkdirSync(".flezi-emt", { recursive: true });
  writeFileSync(POISON_LOG, JSON.stringify(log));
      process.stdout.write(JSON.stringify({
        type: "inject_context",
        context: [
          `⚠ [poisoning-detector] Error repeated ${REPEAT_THRESHOLD}×: "${err}"`,
          `Stop referencing previous attempts. Reset: ignore prior error context, solve from first principles.`,
        ].join("\n")
      }) + "\n");
      process.exit(0);
    }
  }

  mkdirSync(".flezi-emt", { recursive: true });
  writeFileSync(POISON_LOG, JSON.stringify(log));
} catch {
  // Never block — silent exit
}
process.exit(0);
