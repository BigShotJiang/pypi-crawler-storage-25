/**
 * observation-masking.mjs — PostToolUse
 * Replaces tool outputs >2KB with a compact summary + ctx_search pointer.
 */

const THRESHOLD = 2048; // ~500 tokens

try {
  const raw = await new Promise((resolve) => {
    let data = "";
    process.stdin.on("data", (c) => (data += c));
    process.stdin.on("end", () => resolve(data));
    process.stdin.on("error", () => resolve(""));
  });
  if (!raw.trim()) process.exit(0);

  const input = JSON.parse(raw);
  const output = input.tool_response?.output ?? "";
  if (!output || output.length <= THRESHOLD) process.exit(0);

  const lines = output.split("\n");
  const signals = lines
    .filter((l) =>
      /error|warn|fail|success|done|result|total|found|✓|✗|→/i.test(l) ||
      l.includes("://") ||
      /^\s*[\d,]+/.test(l)
    )
    .slice(0, 15);

  const summary =
    signals.length > 0
      ? signals.join("\n")
      : lines.slice(0, 5).join("\n") + "\n...[truncated]";

  process.stdout.write(JSON.stringify({
    type: "replace_output",
    output: `[MASKED ${output.length} chars → ~${Math.ceil(output.length / 4)} tokens]\n${summary}\n[Use ctx_search to query full output if needed]`
  }) + "\n");
} catch {
  // Never block — silent exit
}
process.exit(0);
