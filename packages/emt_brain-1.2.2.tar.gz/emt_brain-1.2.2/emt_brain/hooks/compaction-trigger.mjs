/**
 * compaction-trigger.mjs — PostToolUse
 * Fires at ≥75% (optimal trigger per context-compression skill) with a mandatory
 * imperative instruction so Claude runs /compact before the next action.
 * The 65/70% advisory thresholds are owned by context-pct.mjs (UserPromptSubmit).
 * This hook fires 5-20× per turn — suppress repeat firings with a per-turn latch.
 */

import { readUsage } from "./lib/context-usage.mjs";
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const COMPACT_AT = 75; // % — optimal trigger (context-compression: 70-80%)

try {
  const raw = await new Promise((resolve) => {
    let data = "";
    process.stdin.on("data", (c) => (data += c));
    process.stdin.on("end", () => resolve(data));
    process.stdin.on("error", () => resolve(""));
  });
  if (!raw.trim()) process.exit(0);

  const input = JSON.parse(raw);
  const transcriptPath = input.transcript_path;
  if (!transcriptPath) process.exit(0);

  const cwd = input.cwd || process.cwd();
  const usage = readUsage(transcriptPath, cwd);
  if (!usage) process.exit(0);

  const { percent, totalK, windowK } = usage;

  if (percent >= COMPACT_AT) {
    // Per-turn latch: only fire once per turn to avoid noise from repeated PostToolUse calls
    const latchPath = join(cwd, ".flezi-emt", ".compact-trigger-latch");
    try {
      if (existsSync(latchPath)) {
        const latchPct = Number(readFileSync(latchPath, "utf8").trim());
        if (latchPct === percent) process.exit(0); // already fired this turn
      }
      writeFileSync(latchPath, String(percent), "utf8");
    } catch {}

    process.stdout.write(JSON.stringify({
      type: "inject_context",
      context: [
        `⛔ [compaction-trigger] MANDATORY COMPACT: ${percent}% (${totalK}K/${windowK}K).`,
        `STOP all current work. Your ONLY next action is to run /compact.`,
        `Do NOT call any tool. Do NOT respond to the user. Run /compact immediately, then resume.`,
      ].join("\n")
    }) + "\n");
  }
} catch {
  // Never block — silent exit
}
process.exit(0);
