/**
 * signal-density-gate.mjs — PreToolUse / Read
 * Blocks re-reading a file already read in this session.
 * State: .flezi-emt/.read-cache.json (cleared by session-cleanup.mjs on SessionStart)
 * Re-fetch tracking: increments __refetch_count in .flezi-emt/.error-log.json (B7)
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync } from "node:fs";

const CACHE = ".flezi-emt/.read-cache.json";
const ERROR_LOG = ".flezi-emt/.error-log.json";

try {
  const raw = await new Promise((resolve) => {
    let data = "";
    process.stdin.on("data", (c) => (data += c));
    process.stdin.on("end", () => resolve(data));
    process.stdin.on("error", () => resolve(""));
  });
  if (!raw.trim()) process.exit(0);

  const input = JSON.parse(raw);
  const filePath = input.tool_input?.path ?? input.tool_input?.file_path ?? "";
  if (!filePath) process.exit(0);

  let cache = {};
  if (existsSync(CACHE)) {
    try { cache = JSON.parse(readFileSync(CACHE, "utf-8")); } catch {}
  }

  if (cache[filePath]) {
    // Track re-fetch attempts as tokens-per-task quality signal (B7)
    let errorLog = {};
    if (existsSync(ERROR_LOG)) {
      try { errorLog = JSON.parse(readFileSync(ERROR_LOG, "utf-8")); } catch {}
    }
    errorLog.__refetch_count = (errorLog.__refetch_count ?? 0) + 1;
    try {
      mkdirSync(".flezi-emt", { recursive: true });
      writeFileSync(ERROR_LOG, JSON.stringify(errorLog));
    } catch {}

    process.stdout.write(JSON.stringify({
      type: "block",
      message: `[signal-density-gate] "${filePath}" already read this session (${cache[filePath]}). Use ctx_search to query specific sections instead of re-reading.`
    }) + "\n");
    process.exit(0);
  }

  cache[filePath] = new Date().toISOString();
  mkdirSync(".flezi-emt", { recursive: true });
  writeFileSync(CACHE, JSON.stringify(cache, null, 2));
} catch {
  // Never block — silent exit
}
process.exit(0);
