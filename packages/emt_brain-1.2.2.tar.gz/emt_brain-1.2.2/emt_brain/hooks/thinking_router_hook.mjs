#!/usr/bin/env node
/**
 * thinking_router_hook.mjs — HARNESS Thinking Pillar router (UserPromptSubmit)
 *
 * Scores the incoming prompt and injects thinking mode guidance as
 * additionalContext before Claude processes it.
 *
 * Scoring: Haiku API (primary) → heuristic fallback.
 * Silent for score 0–2 — no noise on trivial prompts.
 *
 * Source: flezi-emt/hooks/ (deployed to ~/.claude/hooks/ via emt-brain hook-setup)
 */

import { readFileSync } from "fs";

// ── Scoring config ────────────────────────────────────────────────────────────

const DIMENSIONS = {
  reversibility: {
    high:   ["schema", "migrate", "contract", "api design", "architecture", "redesign"],
    medium: ["refactor", "restructure", "rename module", "extract"],
    low:    ["fix", "typo", "rename variable", "format", "comment"],
  },
  scope: {
    high:   ["system", "entire", "all services", "cross", "pipeline", "platform"],
    medium: ["module", "component", "multiple files", "service"],
    low:    ["function", "method", "line", "variable", "single file"],
  },
  conflicts: {
    high:   ["balance", "trade-off", "vs", "versus", "constraint", "optimize both"],
    medium: ["consider", "weigh", "priority"],
    low:    [],
  },
  novelty: {
    high:   ["never done", "first time", "new domain", "unfamiliar", "from scratch"],
    medium: ["new feature", "unknown", "explore"],
    low:    ["again", "same as", "like before", "standard"],
  },
  cascade: {
    high:   ["breaking change", "migration", "deprecat", "rollout", "production"],
    medium: ["downstream", "depend", "affect other", "shared"],
    low:    ["isolated", "standalone", "no dependencies"],
  },
};

const STRONG_SIGNALS = [
  "design the", "architect", "plan the migration", "design schema",
  "how should we", "what's the best approach", "compare options",
  "evaluate", "recommend approach",
];

/** @type {Array<[number, number, string, string, number, string]>} */
const ROUTING_TABLE = [
  [0,  2,  "none",           "",           0,     "No thinking needed — simple/fast"],
  [3,  4,  "think",          "think",      2000,  "Moderate complexity"],
  [5,  6,  "think_hard",     "think hard", 8000,  "Multiple factors to consider"],
  [7,  8,  "ultrathink",     "ultrathink", 16000, "Architectural / high-stakes"],
  [9,  10, "ultrathink_max", "ultrathink", 31999, "System-wide / irreversible"],
];

const ICONS = {
  none:           "⚡",
  think:          "💭",
  think_hard:     "🧠",
  ultrathink:     "🔥",
  ultrathink_max: "🚀",
};

// ── Scoring logic ─────────────────────────────────────────────────────────────

function scoreDimension(text, rules) {
  if (rules.high.some((w) => text.includes(w)))   return 2;
  if (rules.medium.some((w) => text.includes(w))) return 1;
  return 0;
}

function computeScore(prompt) {
  const text = prompt.toLowerCase();

  const scores = Object.fromEntries(
    Object.entries(DIMENSIONS).map(([dim, rules]) => [dim, scoreDimension(text, rules)])
  );

  let total = Object.values(scores).reduce((a, b) => a + b, 0);

  if (STRONG_SIGNALS.some((s) => text.includes(s))) {
    total = Math.min(total + 2, 10);
  }

  const wordCount = prompt.split(/\s+/).length;
  if (wordCount > 200) {
    total = Math.min(total + 1, 10);
  }

  return { scores, total, via: "heuristic" };
}

function getRouting(total) {
  for (const [lo, hi, mode, keyword, thinkingTokens, rationale] of ROUTING_TABLE) {
    if (total >= lo && total <= hi) {
      return { mode, keyword, thinkingTokens, rationale };
    }
  }
  return { mode: "ultrathink_max", keyword: "ultrathink", thinkingTokens: 31999, rationale: "Max complexity" };
}

// ── Haiku classifier ──────────────────────────────────────────────────────────

async function classifyWithHaiku(prompt) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return null;

  const body = {
    model: "claude-haiku-4-5-20251001",
    max_tokens: 200,
    messages: [{
      role: "user",
      content: `Score this query 0-2 on each dimension. JSON only, no other text.

reversibility: how hard to undo (0=trivial, 2=breaking/schema)
scope: files/systems affected (0=single fn, 2=cross-system)
conflicts: competing constraints (0=none, 2=multiple)
novelty: familiarity (0=known pattern, 2=new domain)
cascade: downstream risk (0=isolated, 2=breaking change)

Query: ${prompt.slice(0, 500)}

{"reversibility":N,"scope":N,"conflicts":N,"novelty":N,"cascade":N}`,
    }],
  };

  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) return null;

    const data = await res.json();
    const raw = data.content?.[0]?.text?.trim() ?? "";
    const scores = JSON.parse(raw);

    const keys = ["reversibility", "scope", "conflicts", "novelty", "cascade"];
    const total = Math.min(keys.reduce((sum, k) => sum + (scores[k] ?? 0), 0), 10);

    return { scores, total, via: "haiku" };
  } catch {
    return null;
  }
}

// ── Build additionalContext ────────────────────────────────────────────────────

function buildContext(scoreData, routing) {
  const { total, scores } = scoreData;
  const { mode, keyword, thinkingTokens, rationale } = routing;
  const icon = ICONS[mode] ?? "🧠";

  const dimLine = ["reversibility", "scope", "conflicts", "novelty", "cascade"]
    .map((k) => `${k}=${scores[k] ?? 0}`)
    .join(" ");

  const actionLine = keyword
    ? `  → Recommended: use '${keyword}' mode for this response (budget ~${thinkingTokens.toLocaleString()} tokens)`
    : "  → No extended thinking needed. Respond directly.";

  const lines = [
    `[ThinkingRouter] Complexity: ${total}/10 — ${icon} ${rationale} (via ${scoreData.via})`,
    `  ${dimLine}`,
    actionLine,
  ];

  if (total >= 6) {
    lines.push("  → PLAN REQUIRED: score ≥ 6 — after thinking, enter EnterPlanMode before writing code or taking action.");
  }

  return lines.join("\n");
}

// ── Read stdin ────────────────────────────────────────────────────────────────

function readStdin() {
  try {
    return readFileSync("/dev/stdin", "utf8");
  } catch {
    return "";
  }
}

// ── Main ──────────────────────────────────────────────────────────────────────

async function main() {
  let event;
  try {
    const raw = readStdin();
    event = JSON.parse(raw);
  } catch {
    process.exit(0);
  }

  let prompt = "";
  const content = event?.message?.content ?? "";
  if (typeof content === "string") {
    prompt = content;
  } else if (Array.isArray(content)) {
    prompt = content
      .filter((b) => b?.type === "text")
      .map((b) => b.text ?? "")
      .join("");
  }

  if (!prompt.trim()) process.exit(0);

  // Haiku primary, heuristic fallback
  let scoreData = await classifyWithHaiku(prompt);
  if (!scoreData) {
    scoreData = computeScore(prompt);
  }

  const routing = getRouting(scoreData.total);

  // Silent for none mode — no noise on trivial prompts
  if (routing.mode === "none") {
    process.exit(0);
  }

  const additionalContext = buildContext(scoreData, routing);

  process.stdout.write(JSON.stringify({ additionalContext, continue: true }) + "\n");
  process.exit(0);
}

// ESM entry-point guard: only execute when invoked directly, not when imported
if (process.argv[1]?.endsWith("thinking_router_hook.mjs")) {
  main().catch(() => process.exit(0));
}

// ── Exports for unit testing ──────────────────────────────────────────────────
export { scoreDimension, computeScore, getRouting, buildContext, DIMENSIONS, ROUTING_TABLE, ICONS };
