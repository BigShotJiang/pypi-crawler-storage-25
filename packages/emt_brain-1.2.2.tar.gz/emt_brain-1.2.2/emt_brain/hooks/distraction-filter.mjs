/**
 * distraction-filter.mjs — PreToolUse / Read + WebFetch
 * Blocks low-signal noise files (node_modules, dist, lock files, etc.)
 */

const NOISE_PATTERNS = [
  /node_modules\//,
  /\.git\//,
  /\/dist\//,
  /\/build\//,
  /\/coverage\//,
  /\.next\//,
  /package-lock\.json$/,
  /yarn\.lock$/,
  /bun\.lock$/,
  /\.map$/,
  /\.min\.js$/,
];

try {
  const raw = await new Promise((resolve) => {
    let data = "";
    process.stdin.on("data", (c) => (data += c));
    process.stdin.on("end", () => resolve(data));
    process.stdin.on("error", () => resolve(""));
  });
  if (!raw.trim()) process.exit(0);

  const input = JSON.parse(raw);
  const target =
    input.tool_input?.path ??
    input.tool_input?.file_path ??
    input.tool_input?.url ??
    "";
  if (!target) process.exit(0);

  if (NOISE_PATTERNS.some((p) => p.test(target))) {
    process.stdout.write(JSON.stringify({
      type: "block",
      message: `[distraction-filter] "${target}" is low-signal noise. Use ctx_execute to extract specific sections if genuinely needed.`
    }) + "\n");
  }
} catch {
  // Never block — silent exit
}
process.exit(0);
