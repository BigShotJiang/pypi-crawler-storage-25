/**
 * session-cleanup.mjs — SessionStart
 * Clears per-session state files so each session starts fresh.
 * Prevents .read-cache.json and .error-log.json from accumulating stale state.
 */

import { writeFileSync, rmSync, mkdirSync } from "node:fs";

try {
  mkdirSync(".flezi-emt", { recursive: true });
  writeFileSync(".flezi-emt/.read-cache.json", "{}");
  writeFileSync(".flezi-emt/.error-log.json", "{}");
  try { rmSync(".flezi-emt/.session-intent"); } catch {}
} catch {
  // Never block — silent exit
}
process.exit(0);
