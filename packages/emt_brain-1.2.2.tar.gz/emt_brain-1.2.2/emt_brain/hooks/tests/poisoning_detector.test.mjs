/**
 * poisoning_detector.test.mjs
 * Integration tests for poisoning-detector.mjs hook (PostToolUse).
 *
 * Strategy: spawn as subprocess with mock PostToolUse JSON on stdin;
 * verify inject_context output after threshold is reached.
 *
 * Run: node --test flezi-emt/hooks/tests/poisoning_detector.test.mjs
 */

import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdtempSync, writeFileSync, rmSync, mkdirSync } from "node:fs";
import { join, resolve } from "node:path";
import { tmpdir } from "node:os";

const HOOK_PATH = resolve(import.meta.dirname, "../poisoning-detector.mjs");
const REPEAT_THRESHOLD = 3;

/** Run poisoning-detector.mjs with a given tool output string from a temp cwd. */
function runHook(toolOutput, cwd) {
  const stdinPayload = JSON.stringify({
    tool_response: { output: toolOutput },
  });

  return spawnSync("node", [HOOK_PATH], {
    input: stdinPayload,
    encoding: "utf8",
    timeout: 5000,
    cwd,
  });
}

describe("poisoning-detector error loop detection", () => {
  test("single error occurrence: no inject_context output", () => {
    const tmpDir = mkdtempSync(join(tmpdir(), "poison-test-"));
    try {
      mkdirSync(join(tmpDir, ".flezi-emt"), { recursive: true });
      const result = runHook("Error: cannot read property of undefined", tmpDir);
      assert.equal(result.status, 0);
      const out = result.stdout ?? "";
      assert.ok(!out.includes("inject_context"), "single error should not trigger inject_context");
    } finally {
      rmSync(tmpDir, { recursive: true, force: true });
    }
  });

  test("error repeated exactly 3 times: triggers inject_context warning", () => {
    const tmpDir = mkdtempSync(join(tmpdir(), "poison-test-"));
    try {
      mkdirSync(join(tmpDir, ".flezi-emt"), { recursive: true });
      const errorMsg = "Error: cannot find module 'missing-dep'";

      // First 2 calls — no trigger yet
      for (let i = 0; i < REPEAT_THRESHOLD - 1; i++) {
        const r = runHook(errorMsg, tmpDir);
        assert.equal(r.status, 0);
        assert.ok(!(r.stdout ?? "").includes("inject_context"), `call ${i + 1} should not trigger`);
      }

      // Third call — should trigger
      const result = runHook(errorMsg, tmpDir);
      assert.equal(result.status, 0);
      const out = result.stdout ?? "";
      assert.ok(out.includes("inject_context"), "3rd repeated error should trigger inject_context");
      assert.ok(out.includes("poisoning-detector"), "output should mention poisoning-detector");
      assert.ok(out.includes("3×"), "should report 3 repetitions");
    } finally {
      rmSync(tmpDir, { recursive: true, force: true });
    }
  });

  test("different error messages: no false positive trigger", () => {
    const tmpDir = mkdtempSync(join(tmpdir(), "poison-test-"));
    try {
      mkdirSync(join(tmpDir, ".flezi-emt"), { recursive: true });
      // Each call has a different error — none should repeat 3 times
      const errors = [
        "Error: cannot connect to database",
        "Error: file not found",
        "Error: permission denied",
        "Error: timeout exceeded",
      ];
      for (const err of errors) {
        const r = runHook(err, tmpDir);
        assert.equal(r.status, 0);
        assert.ok(!(r.stdout ?? "").includes("inject_context"), `unique error '${err}' should not trigger`);
      }
    } finally {
      rmSync(tmpDir, { recursive: true, force: true });
    }
  });

  test("system keys (__ prefix) are ignored", () => {
    const tmpDir = mkdtempSync(join(tmpdir(), "poison-test-"));
    try {
      mkdirSync(join(tmpDir, ".flezi-emt"), { recursive: true });
      // Seed log with a __ key at high count
      const logPath = join(tmpDir, ".flezi-emt", ".error-log.json");
      writeFileSync(logPath, JSON.stringify({ "__refetch_count": 10 }));

      // Tool output containing __refetch_count-like lines should not trigger
      const result = runHook("__refetch_count exceeded limit", tmpDir);
      assert.equal(result.status, 0);
      assert.ok(!(result.stdout ?? "").includes("inject_context"), "__ keys should be skipped");
    } finally {
      rmSync(tmpDir, { recursive: true, force: true });
    }
  });

  test("empty tool output: exits silently", () => {
    const result = spawnSync("node", [HOOK_PATH], {
      input: JSON.stringify({ tool_response: { output: "" } }),
      encoding: "utf8",
      timeout: 5000,
    });
    assert.equal(result.status, 0);
    assert.equal((result.stdout ?? "").trim(), "");
  });

  test("malformed stdin: exits silently (exit 0, no crash)", () => {
    const result = spawnSync("node", [HOOK_PATH], {
      input: "not json at all",
      encoding: "utf8",
      timeout: 5000,
    });
    assert.equal(result.status, 0);
  });
});
