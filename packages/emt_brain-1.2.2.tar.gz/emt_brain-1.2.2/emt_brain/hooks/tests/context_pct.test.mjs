/**
 * context_pct.test.mjs
 * Integration tests for context-pct.mjs hook (UserPromptSubmit).
 *
 * Strategy: spawn the hook as a subprocess with a mock JSONL transcript and
 * verify stdout advisory messages for each threshold tier.
 *
 * Run: node --test flezi-emt/hooks/tests/context_pct.test.mjs
 */

import { test, describe, before, after } from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdirSync, mkdtempSync, writeFileSync, rmSync } from "node:fs";
import { join, resolve } from "node:path";
import { tmpdir } from "node:os";

const HOOK_PATH = resolve(import.meta.dirname, "../context-pct.mjs");
// readUsage reads from obj.message.usage and uses window = floor(200_000 * 0.95) = 190_000
const EFFECTIVE_WINDOW = Math.floor(200_000 * 0.95); // 190_000

/** Build a minimal JSONL transcript entry that readUsage will parse.
 * Format: { message: { usage: { input_tokens } } } — matches Claude Code transcript schema. */
function makeTranscript(inputTokens) {
  return JSON.stringify({ message: { usage: { input_tokens: inputTokens, output_tokens: 0 } } }) + "\n";
}

/** Calculate inputTokens to land at ~targetPct after readUsage math. */
function tokensForPct(targetPct) {
  return Math.floor((targetPct / 100) * EFFECTIVE_WINDOW);
}

/** Run context-pct.mjs with a synthetic transcript and return {stdout, stderr, status}. */
function runHook(inputTokens, extraInput = {}) {
  let tmpDir;
  try {
    tmpDir = mkdtempSync(join(tmpdir(), "harness-test-"));
    const transcriptFile = join(tmpDir, "transcript.jsonl");
    writeFileSync(transcriptFile, makeTranscript(inputTokens));

    const stdinPayload = JSON.stringify({
      transcript_path: transcriptFile,
      cwd: tmpDir,
      ...extraInput,
    });

    const result = spawnSync("node", [HOOK_PATH], {
      input: stdinPayload,
      encoding: "utf8",
      timeout: 5000,
      // Override HOME so detectWindowSize can't see ~/.claude/settings.json —
      // keeps the 200K baseline deterministic regardless of machine config.
      env: { ...process.env, HOME: tmpDir },
    });

    return {
      stdout: result.stdout ?? "",
      stderr: result.stderr ?? "",
      status: result.status ?? 0,
    };
  } finally {
    try { rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

// ── Advisory message thresholds ───────────────────────────────────────────────

describe("context-pct advisory messages", () => {
  test("< 65%: outputs ✓ (all clear)", () => {
    const { stdout } = runHook(tokensForPct(55));
    assert.ok(stdout.includes("✓"), `expected ✓ but got: ${stdout.trim()}`);
    assert.ok(!stdout.includes("⚠"), "should not warn at 55%");
    assert.ok(!stdout.includes("⛔"), "should not block at 55%");
  });

  test("65–69%: outputs ⚡ context filling", () => {
    const { stdout } = runHook(tokensForPct(66));
    assert.ok(stdout.includes("⚡"), `expected ⚡ at 66% but got: ${stdout.trim()}`);
    assert.ok(stdout.includes("context filling"), "should say context filling");
  });

  test("70–79%: outputs ⚠ run /compact before next turn", () => {
    const { stdout } = runHook(tokensForPct(72));
    assert.ok(stdout.includes("⚠"), `expected ⚠ at 72% but got: ${stdout.trim()}`);
    assert.ok(stdout.toLowerCase().includes("compact"), "should mention compact");
  });

  test("≥ 80% with /compact prompt: outputs running /compact (not blocked)", () => {
    const { stdout } = runHook(tokensForPct(82), { prompt: "/compact" });
    // Should NOT be a block decision JSON; should be advisory
    assert.ok(!stdout.includes('"decision":"block"'), "should not block /compact command");
    assert.ok(stdout.includes("⛔"), "should show ⛔ status");
  });

  test("≥ 80% with non-compact prompt: outputs block JSON", () => {
    const { stdout } = runHook(tokensForPct(82), { prompt: "continue with the task" });
    // Should output block JSON
    assert.ok(stdout.includes('"decision"'), `expected block JSON but got: ${stdout.trim()}`);
    assert.ok(stdout.includes("block"), "decision should be 'block'");
    assert.ok(stdout.includes("COMPACT REQUIRED"), "should say COMPACT REQUIRED");
  });

  test("exit code is 0 (never crashes)", () => {
    const { status } = runHook(tokensForPct(50));
    assert.equal(status, 0, "hook should always exit 0");
  });

  test("empty stdin: exits silently (code 0, no output)", () => {
    const result = spawnSync("node", [HOOK_PATH], {
      input: "",
      encoding: "utf8",
      timeout: 5000,
    });
    assert.equal(result.status, 0);
    assert.equal((result.stdout ?? "").trim(), "");
  });
});
