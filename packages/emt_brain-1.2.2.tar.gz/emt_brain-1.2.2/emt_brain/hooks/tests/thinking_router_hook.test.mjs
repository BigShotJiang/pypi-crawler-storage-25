/**
 * thinking_router_hook.test.mjs
 * Unit tests for thinking_router_hook.mjs pure functions.
 *
 * Run: node --test flezi-emt/hooks/tests/thinking_router_hook.test.mjs
 */

import { test, describe } from "node:test";
import assert from "node:assert/strict";
import {
  scoreDimension,
  computeScore,
  getRouting,
  buildContext,
  DIMENSIONS,
  ROUTING_TABLE,
} from "../thinking_router_hook.mjs";

// ── scoreDimension ────────────────────────────────────────────────────────────

describe("scoreDimension", () => {
  test("returns 2 for high-tier keyword match", () => {
    assert.equal(scoreDimension("migrate the schema", DIMENSIONS.reversibility), 2);
  });

  test("returns 1 for medium-tier keyword match", () => {
    assert.equal(scoreDimension("let's refactor this module", DIMENSIONS.reversibility), 1);
  });

  test("returns 0 for low-tier keyword match (low overrides nothing)", () => {
    // 'fix' is in low — returns 0 because low is not scored up
    assert.equal(scoreDimension("fix the typo", DIMENSIONS.reversibility), 0);
  });

  test("returns 0 when no keyword matches", () => {
    assert.equal(scoreDimension("hello world", DIMENSIONS.scope), 0);
  });

  test("high takes priority over medium", () => {
    // 'system' (high) and 'module' (medium) both present
    assert.equal(scoreDimension("system-wide module refactor", DIMENSIONS.scope), 2);
  });

  test("conflicts dimension: no-match returns 0", () => {
    assert.equal(scoreDimension("just add a button", DIMENSIONS.conflicts), 0);
  });

  test("conflicts dimension: medium match", () => {
    assert.equal(scoreDimension("we need to consider the options", DIMENSIONS.conflicts), 1);
  });

  test("conflicts dimension: high match", () => {
    assert.equal(scoreDimension("balance performance vs readability", DIMENSIONS.conflicts), 2);
  });

  test("cascade: production = high", () => {
    assert.equal(scoreDimension("deploy to production", DIMENSIONS.cascade), 2);
  });

  test("novelty: 'from scratch' = high", () => {
    assert.equal(scoreDimension("build this from scratch", DIMENSIONS.novelty), 2);
  });
});

// ── computeScore ─────────────────────────────────────────────────────────────

describe("computeScore", () => {
  test("trivial prompt scores 0", () => {
    const { total } = computeScore("fix typo");
    assert.equal(total, 0);
  });

  test("strong signal boosts score by 2", () => {
    // "how should we" is a strong signal; with 0 base = 2
    const { total } = computeScore("how should we handle this?");
    assert.ok(total >= 2, `expected ≥ 2, got ${total}`);
  });

  test("architectural prompt scores high", () => {
    const { total } = computeScore("design the architecture for a cross-system migration");
    // "design the" strong signal (+2) + architecture(reversibility:high +2) + migrate(cascade:high? +2) + cross(scope:high +2)
    assert.ok(total >= 7, `expected ≥ 7, got ${total}`);
  });

  test("long prompt (>200 words) gets +1 length bonus", () => {
    const longPrompt = "word ".repeat(210);
    const short = computeScore("word");
    const long = computeScore(longPrompt);
    assert.ok(long.total >= short.total + 1, "long prompt should score at least 1 more");
  });

  test("score is capped at 10", () => {
    // Pile on every possible keyword
    const overloaded = "design the architecture for a cross-system breaking change migration " +
      "to balance trade-offs from scratch in production with never done before cascade effects";
    const { total } = computeScore(overloaded);
    assert.ok(total <= 10, `score should not exceed 10, got ${total}`);
  });

  test("via field is 'heuristic'", () => {
    const { via } = computeScore("anything");
    assert.equal(via, "heuristic");
  });

  test("returns scores object with all 5 dimensions", () => {
    const { scores } = computeScore("some prompt");
    const dims = ["reversibility", "scope", "conflicts", "novelty", "cascade"];
    for (const d of dims) {
      assert.ok(d in scores, `missing dimension: ${d}`);
    }
  });
});

// ── getRouting ────────────────────────────────────────────────────────────────

describe("getRouting", () => {
  const cases = [
    [0,  "none",           ""],
    [1,  "none",           ""],
    [2,  "none",           ""],
    [3,  "think",          "think"],
    [4,  "think",          "think"],
    [5,  "think_hard",     "think hard"],
    [6,  "think_hard",     "think hard"],
    [7,  "ultrathink",     "ultrathink"],
    [8,  "ultrathink",     "ultrathink"],
    [9,  "ultrathink_max", "ultrathink"],
    [10, "ultrathink_max", "ultrathink"],
  ];

  for (const [score, expectedMode, expectedKeyword] of cases) {
    test(`score ${score} → mode '${expectedMode}'`, () => {
      const routing = getRouting(score);
      assert.equal(routing.mode, expectedMode);
      assert.equal(routing.keyword, expectedKeyword);
    });
  }

  test("thinkingTokens increases with score tier", () => {
    const t3 = getRouting(3).thinkingTokens;
    const t5 = getRouting(5).thinkingTokens;
    const t7 = getRouting(7).thinkingTokens;
    const t9 = getRouting(9).thinkingTokens;
    assert.ok(t3 < t5 && t5 < t7 && t7 < t9, "tokens should increase with score tier");
  });
});

// ── buildContext ──────────────────────────────────────────────────────────────

describe("buildContext", () => {
  const mockScore = {
    total: 7,
    scores: { reversibility: 2, scope: 2, conflicts: 1, novelty: 1, cascade: 1 },
    via: "haiku",
  };
  const routing = getRouting(7);

  test("contains ThinkingRouter prefix", () => {
    const ctx = buildContext(mockScore, routing);
    assert.ok(ctx.includes("[ThinkingRouter]"), "should include [ThinkingRouter] prefix");
  });

  test("contains all 5 dimension scores", () => {
    const ctx = buildContext(mockScore, routing);
    assert.ok(ctx.includes("reversibility=2"), "should include reversibility score");
    assert.ok(ctx.includes("scope=2"), "should include scope score");
    assert.ok(ctx.includes("conflicts=1"), "should include conflicts score");
    assert.ok(ctx.includes("novelty=1"), "should include novelty score");
    assert.ok(ctx.includes("cascade=1"), "should include cascade score");
  });

  test("contains action line with keyword", () => {
    const ctx = buildContext(mockScore, routing);
    assert.ok(ctx.includes("ultrathink"), "should recommend ultrathink for score 7");
    assert.ok(ctx.includes("→ Recommended:"), "should include recommendation arrow");
  });

  test("via field appears in output", () => {
    const ctx = buildContext(mockScore, routing);
    assert.ok(ctx.includes("via haiku"), "should show scoring via");
  });

  test("none mode: empty keyword produces 'Respond directly' message", () => {
    const noneScore = { total: 1, scores: { reversibility: 0, scope: 0, conflicts: 0, novelty: 0, cascade: 1 }, via: "heuristic" };
    const noneRouting = getRouting(1);
    // none mode has empty keyword — but buildContext is only called for score >= 3 in main()
    // Still test the branch: empty keyword → respond directly
    const ctx = buildContext(noneScore, noneRouting);
    assert.ok(ctx.includes("Respond directly"), "no-keyword mode should say respond directly");
  });

  test("score ≥ 6: output is 4 lines (includes PLAN REQUIRED)", () => {
    const ctx = buildContext(mockScore, routing);
    const lines = ctx.split("\n");
    assert.equal(lines.length, 4, "score ≥ 6 output should have 4 lines");
    assert.ok(ctx.includes("PLAN REQUIRED"), "should include PLAN REQUIRED directive");
    assert.ok(ctx.includes("EnterPlanMode"), "should mention EnterPlanMode");
  });

  test("score < 6: output is 3 lines (no PLAN REQUIRED)", () => {
    const lowScore = { total: 5, scores: { reversibility: 1, scope: 2, conflicts: 0, novelty: 1, cascade: 1 }, via: "heuristic" };
    const ctx = buildContext(lowScore, getRouting(5));
    const lines = ctx.split("\n");
    assert.equal(lines.length, 3, "score < 6 output should have exactly 3 lines");
    assert.ok(!ctx.includes("PLAN REQUIRED"), "score < 6 should not include PLAN REQUIRED");
  });
});

// ── Integration: silent mode for score 0-2 ───────────────────────────────────

describe("integration: silent for trivial prompts", () => {
  test("computeScore('fix typo') → getRouting → mode is 'none'", () => {
    const { total } = computeScore("fix typo");
    const { mode } = getRouting(total);
    assert.equal(mode, "none", "trivial prompt should route to 'none' (silent)");
  });

  test("computeScore('hello') → total 0 → none mode", () => {
    const { total } = computeScore("hello");
    assert.equal(total, 0);
    assert.equal(getRouting(total).mode, "none");
  });
});
