"""plugins_setup.py — install 3rd-party skill/agent plugins from public GitHub repos.

MCP servers (e.g. context-mode) are managed by mcp_setup.py, not here.
"""
from __future__ import annotations

import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import NamedTuple

# ---------------------------------------------------------------------------
# Plugin registry
#
# Fields:
#   display_name   Human-friendly name
#   description    One-line purpose
#   source         Public git URL (no auth required)
#   type           "skill" | "agent"
#   install_subdir Path relative to .claude/ root where the plugin lands
#   marker_file    File whose presence confirms the plugin is installed
#   source_subdir  Subdir inside the cloned repo to copy (None = repo root)
# ---------------------------------------------------------------------------

PLUGINS: dict[str, dict] = {
    "graphify": {
        "display_name": "Graphify",
        "description": "Convert any input to a knowledge graph",
        "source": "https://github.com/safishamsi/graphify",
        "type": "skill",
        "install_subdir": "skills/graphify",
        "marker_file": "skill.md",
        "source_subdir": "graphify",
        "pip_package": "graphifyy",
    },
    # Add more skill/agent plugins here.
    # For MCP servers, add them to mcp_setup.MCP_SERVERS instead.
}


class PluginStatus(NamedTuple):
    name: str
    display_name: str
    description: str
    plugin_type: str
    source: str
    install_path: Path
    already_installed: bool
    installed: bool
    error: str | None = None
    pip_installed: bool = False


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def resolve_claude_root(scope: str, project_path: Path | None = None) -> Path:
    """Return the .claude/ directory for the given scope."""
    if scope == "project":
        return (project_path or Path.cwd()) / ".claude"
    return Path.home() / ".claude"


def is_installed(name: str, scope: str = "global", project_path: Path | None = None) -> bool:
    if name not in PLUGINS:
        return False
    info = PLUGINS[name]
    root = resolve_claude_root(scope, project_path)
    return (root / info["install_subdir"] / info["marker_file"]).exists()


def list_plugins(scope: str = "global", project_path: Path | None = None) -> list[dict]:
    """Return all registered plugins with their installed status."""
    claude_root = resolve_claude_root(scope, project_path)
    return [
        {
            "name": name,
            "display_name": info["display_name"],
            "description": info["description"],
            "type": info["type"],
            "source": info["source"],
            "installed": is_installed(name, scope, project_path),
            "install_path": claude_root / info["install_subdir"],
        }
        for name, info in PLUGINS.items()
    ]


# ---------------------------------------------------------------------------
# Install
# ---------------------------------------------------------------------------

def install_plugin(
    name: str,
    scope: str = "global",
    project_path: Path | None = None,
    dry_run: bool = False,
    force: bool = False,
) -> PluginStatus:
    """Clone and copy a registered skill/agent plugin into .claude/.

    Uses `git clone --depth=1` (requires git on PATH, no auth needed for public repos).
    Removes the cloned .git directory after copy to keep the install lean.
    """
    if name not in PLUGINS:
        raise ValueError(f"Unknown plugin '{name}'. Available: {list(PLUGINS)}")

    info = PLUGINS[name]
    claude_root = resolve_claude_root(scope, project_path)
    install_path = claude_root / info["install_subdir"]
    already_installed = (install_path / info["marker_file"]).exists()

    _base = dict(
        name=name,
        display_name=info["display_name"],
        description=info["description"],
        plugin_type=info["type"],
        source=info["source"],
        install_path=install_path,
        already_installed=already_installed,
    )

    if already_installed and not force:
        return PluginStatus(**_base, installed=False)

    if dry_run:
        return PluginStatus(**_base, installed=False)

    try:
        with tempfile.TemporaryDirectory() as tmp:
            clone_dest = Path(tmp) / "repo"
            result = subprocess.run(
                ["git", "clone", "--depth=1", info["source"], str(clone_dest)],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                return PluginStatus(
                    **_base,
                    installed=False,
                    error=f"git clone failed: {result.stderr.strip()}",
                )

            src = clone_dest / info["source_subdir"] if info.get("source_subdir") else clone_dest

            if install_path.exists():
                shutil.rmtree(install_path)
            shutil.copytree(src, install_path, ignore=shutil.ignore_patterns(".git"))

        pip_installed = False
        if info.get("pip_package"):
            pip_result = subprocess.run(
                [sys.executable, "-m", "pip", "install", info["pip_package"]],
                capture_output=True,
                text=True,
            )
            pip_installed = pip_result.returncode == 0
            if not pip_installed:
                return PluginStatus(
                    **_base,
                    installed=True,
                    pip_installed=False,
                    error=f"pip install {info['pip_package']} failed: {pip_result.stderr.strip()}",
                )

        return PluginStatus(**_base, installed=True, pip_installed=pip_installed)

    except Exception as exc:
        return PluginStatus(**_base, installed=False, error=str(exc))
