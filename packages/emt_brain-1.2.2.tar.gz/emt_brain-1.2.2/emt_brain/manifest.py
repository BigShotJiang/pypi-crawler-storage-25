from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SkillEntry:
    id: str
    source: str
    license: str = ""
    owner: str = ""
    tags: list[str] = field(default_factory=list)
    phase: str = ""
    category: str = ""


@dataclass
class BundleEntry:
    id: str
    source: str
    phase: str = ""
    skills: list[str] = field(default_factory=list)
    agents: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)


@dataclass
class WorkflowEntry:
    id: str
    source: str
    entry_agent: str
    agents: list[dict]  # raw agent slot dicts from index.json
    consumes_workflow_handoff: str  # upstream workflow ID or ""
    produces_workflow_handoff: str  # contract name or ""
    tags: list[str] = field(default_factory=list)
    is_v2: bool = False

    def as_skill_entry(self) -> SkillEntry:
        """Represent this workflow as a SkillEntry for use by the sync engine."""
        return SkillEntry(
            id=self.id,
            source=self.source,
            license="FPT-Proprietary",
            owner="EMT",
            tags=self.tags,
            category="workflow",
        )


@dataclass
class AgentEntry:
    id: str
    source: str
    skills: list[str] = field(default_factory=list)


@dataclass
class Manifest:
    skills: list[SkillEntry]
    bundles: list[BundleEntry]
    workflows: list[WorkflowEntry] = field(default_factory=list)
    agents: list[AgentEntry] = field(default_factory=list)


def load_manifest(repo_root: Path) -> Manifest:
    """Read index.json from repo root and return a Manifest with skills, bundles, workflows, agents."""
    manifest_file = repo_root / "index.json"
    if not manifest_file.exists():
        raise FileNotFoundError(f"Manifest not found: {manifest_file}")

    data = json.loads(manifest_file.read_text(encoding="utf-8"))
    version = data.get("version", 1)
    if version not in (1, 2, 3, 4):
        raise ValueError(f"Unsupported manifest version: {version}")

    skills: list[SkillEntry] = []
    for item in data.get("skills", []):
        if "id" not in item or "source" not in item:
            raise ValueError(f"Manifest entry missing 'id' or 'source': {item}")
        skills.append(SkillEntry(
            id=item["id"],
            source=item["source"],
            license=item.get("license", ""),
            owner=item.get("owner", ""),
            tags=item.get("tags") or [],
            phase=item.get("phase", ""),
            category=item.get("category", ""),
        ))

    bundles: list[BundleEntry] = []
    for item in data.get("bundles", []):
        if "id" not in item:
            continue
        bundles.append(BundleEntry(
            id=item["id"],
            source=item.get("source", ""),
            phase=item.get("phase", ""),
            skills=item.get("skills") or [],
            agents=item.get("agents") or [],
            tags=item.get("tags") or [],
        ))

    workflows: list[WorkflowEntry] = []
    for item in data.get("workflows", []):
        if "id" not in item:
            continue
        consumes = ""
        cwh = item.get("consumes_workflow_handoff")
        if isinstance(cwh, dict):
            consumes = cwh.get("workflow", "")
        produces = ""
        pwh = item.get("produces_workflow_handoff")
        if isinstance(pwh, dict):
            produces = pwh.get("contract", "")
        workflows.append(WorkflowEntry(
            id=item["id"],
            source=item.get("source", f"flezi-emt/workflows/{item['id']}"),
            entry_agent=item.get("entry_agent", ""),
            agents=item.get("agents") or [],
            consumes_workflow_handoff=consumes,
            produces_workflow_handoff=produces,
            tags=item.get("tags") or [],
            is_v2=bool(item.get("is_v2")),
        ))

    agents: list[AgentEntry] = []
    for item in data.get("agents", []):
        if "id" not in item:
            continue
        agents.append(AgentEntry(
            id=item["id"],
            source=item.get("source", ""),
            skills=item.get("skills") or [],
        ))

    return Manifest(skills=skills, bundles=bundles, workflows=workflows, agents=agents)
