"""workflow_resolver.py — Resolve transitive dependency closure for a workflow.

Given a workflow ID, returns:
  - All related workflow IDs (via consumes_workflow_handoff chain)
  - All agent IDs referenced by those workflows
  - All skill IDs used by those agents

Intended use: framework-sync --workflow <id> scopes the sync to this closure
plus the default bundle.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

from .manifest import Manifest


@dataclass
class ResolvedDeps:
    workflows: list[str] = field(default_factory=list)
    agents: list[str] = field(default_factory=list)
    skills: list[str] = field(default_factory=list)


def resolve_workflow_deps(workflow_id: str, manifest: Manifest) -> ResolvedDeps:
    """Return the transitive dep closure for *workflow_id*.

    Traverses consumes_workflow_handoff links (BFS). Collects agents from all
    resolved workflows, then skills from those agents.

    Raises ValueError if *workflow_id* is not in the manifest.
    """
    wf_by_id = {wf.id: wf for wf in manifest.workflows}
    agent_by_id = {a.id: a for a in manifest.agents}

    if workflow_id not in wf_by_id:
        available = sorted(wf_by_id.keys())
        raise ValueError(
            f"Workflow '{workflow_id}' not found in manifest.\n"
            f"Available: {', '.join(available) or '(none)'}"
        )

    # BFS over the workflow graph via consumes_workflow_handoff
    resolved_wf: set[str] = set()
    queue: deque[str] = deque([workflow_id])
    while queue:
        wid = queue.popleft()
        if wid in resolved_wf or wid not in wf_by_id:
            continue
        resolved_wf.add(wid)
        upstream = wf_by_id[wid].consumes_workflow_handoff
        if upstream and upstream not in resolved_wf:
            queue.append(upstream)

    # Collect agents from all resolved workflows
    resolved_agents: set[str] = set()
    for wid in resolved_wf:
        for slot in wf_by_id[wid].agents:
            ref = slot.get("agent_ref") or slot.get("id", "")
            if ref:
                resolved_agents.add(ref)

    # Collect skills from resolved agents
    resolved_skills: set[str] = set()
    for aid in resolved_agents:
        if aid in agent_by_id:
            resolved_skills.update(agent_by_id[aid].skills)

    return ResolvedDeps(
        workflows=sorted(resolved_wf),
        agents=sorted(resolved_agents),
        skills=sorted(resolved_skills),
    )
