"""Tests for emt_brain.project_config — find_project_config, load_project_config, merge_configs."""
import pytest
from pathlib import Path

from emt_brain.project_config import find_project_config, load_project_config, merge_configs


# ---------------------------------------------------------------------------
# find_project_config
# ---------------------------------------------------------------------------

def test_find_config_in_current_dir(tmp_path):
    config = tmp_path / ".flezi-emt" / "config.yaml"
    config.parent.mkdir()
    config.write_text("profile: emt-stage-assessment\n")
    assert find_project_config(tmp_path) == config


def test_find_config_in_parent(tmp_path):
    subdir = tmp_path / "src" / "module"
    subdir.mkdir(parents=True)
    config = tmp_path / ".flezi-emt" / "config.yaml"
    config.parent.mkdir()
    config.write_text("profile: emt-stage-planning\n")
    assert find_project_config(subdir) == config


def test_find_config_stops_at_git_boundary(tmp_path):
    (tmp_path / ".git").mkdir()
    nested = tmp_path / "deep" / "nested"
    nested.mkdir(parents=True)
    # .flezi-emt/config.yaml is ABOVE the .git boundary — should not be found
    parent = tmp_path.parent
    config_above = parent / ".flezi-emt" / "config.yaml"
    if config_above.exists():
        config_above.unlink()
    assert find_project_config(nested) is None


def test_find_config_no_config_no_git_returns_none(tmp_path):
    subdir = tmp_path / "a" / "b" / "c"
    subdir.mkdir(parents=True)
    # No .flezi-emt/config.yaml anywhere up to tmp_path root
    result = find_project_config(subdir)
    # May return None or find something from real filesystem above tmp_path.
    # We only assert it doesn't raise and returns Path or None.
    assert result is None or isinstance(result, Path)


def test_find_config_cwd_outside_git_repo(tmp_path):
    # Simulate a dir with no .git and no .flezi anywhere in walk up to tmp_path
    isolated = tmp_path / "isolated"
    isolated.mkdir()
    result = find_project_config(isolated)
    assert result is None or isinstance(result, Path)


def test_find_config_prefers_nearest(tmp_path):
    # Config in both root and subdir — should return nearest (subdir's)
    deep = tmp_path / "project" / "src"
    deep.mkdir(parents=True)

    root_config = tmp_path / ".flezi-emt" / "config.yaml"
    root_config.parent.mkdir()
    root_config.write_text("profile: emt-stage-planning\n")

    near_config = tmp_path / "project" / ".flezi-emt" / "config.yaml"
    near_config.parent.mkdir()
    near_config.write_text("profile: emt-stage-assessment\n")

    assert find_project_config(deep) == near_config


# ---------------------------------------------------------------------------
# load_project_config
# ---------------------------------------------------------------------------

def test_load_minimal_profile(tmp_path):
    f = tmp_path / "config.yaml"
    f.write_text("profile: emt-stage-assessment\n")
    cfg = load_project_config(f)
    assert cfg == {"profile": "emt-stage-assessment"}


def test_load_filter_tags_as_list(tmp_path):
    f = tmp_path / "config.yaml"
    f.write_text("filter_tags:\n  - baseline\n  - xray\n")
    cfg = load_project_config(f)
    assert cfg["filter_tags"] == "baseline,xray"


def test_load_filter_tags_as_string(tmp_path):
    f = tmp_path / "config.yaml"
    f.write_text("filter_tags: baseline,xray\n")
    cfg = load_project_config(f)
    assert cfg["filter_tags"] == "baseline,xray"


def test_load_all_known_keys(tmp_path):
    f = tmp_path / "config.yaml"
    f.write_text("profile: emt-stage-assessment\nfilter_tags: [xray]\nprovider: claude\nscope: project\n")
    cfg = load_project_config(f)
    assert cfg["profile"] == "emt-stage-assessment"
    assert cfg["filter_tags"] == "xray"
    assert cfg["provider"] == "claude"
    assert cfg["scope"] == "project"


def test_load_empty_file_returns_empty_dict(tmp_path):
    f = tmp_path / "config.yaml"
    f.write_text("")
    cfg = load_project_config(f)
    assert cfg == {}


def test_load_unknown_keys_warns_does_not_raise(tmp_path):
    f = tmp_path / "config.yaml"
    f.write_text("profiel: typo\nprofile: emt-stage-assessment\n")  # "profiel" is unknown
    cfg = load_project_config(f)
    # Should not raise; unknown key "profiel" warned and ignored
    assert cfg == {"profile": "emt-stage-assessment"}


def test_load_invalid_yaml_raises(tmp_path):
    f = tmp_path / "config.yaml"
    f.write_text("key: [unclosed\n")
    with pytest.raises(ValueError, match="not valid YAML"):
        load_project_config(f)


def test_load_non_mapping_raises(tmp_path):
    f = tmp_path / "config.yaml"
    f.write_text("- item1\n- item2\n")
    with pytest.raises(ValueError, match="must be a YAML mapping"):
        load_project_config(f)


# ---------------------------------------------------------------------------
# merge_configs
# ---------------------------------------------------------------------------

def test_merge_cli_overrides_all(tmp_path):
    global_cfg = {"provider": "copilot", "scope": "global"}
    project_cfg = {"provider": "claude", "profile": "emt-stage-planning"}
    cli = {"provider": "copilot", "profile": "emt-stage-assessment"}
    result = merge_configs(global_cfg, project_cfg, cli)
    assert result["provider"] == "copilot"       # CLI wins
    assert result["profile"] == "emt-stage-assessment"  # CLI wins over project


def test_merge_project_overrides_global():
    global_cfg = {"provider": "copilot", "scope": "global"}
    project_cfg = {"scope": "project"}
    result = merge_configs(global_cfg, project_cfg, {})
    assert result["scope"] == "project"
    assert result["provider"] == "copilot"       # global preserved


def test_merge_cli_filter_tags_replaces_project_filter_tags():
    # Shallow merge: CLI filter_tags fully replaces project filter_tags
    project_cfg = {"filter_tags": "baseline,xray"}
    cli = {"filter_tags": "planning"}
    result = merge_configs({}, project_cfg, cli)
    assert result["filter_tags"] == "planning"


def test_merge_empty_overrides_preserve_global():
    global_cfg = {"provider": "claude", "scope": "global", "repo_url": "https://example.com"}
    result = merge_configs(global_cfg, {}, {})
    assert result == global_cfg
