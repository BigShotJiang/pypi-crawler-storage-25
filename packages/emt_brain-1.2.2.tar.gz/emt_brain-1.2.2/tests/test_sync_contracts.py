"""Tests for emt_brain.sync_contracts — universal contract propagation."""
import json
from pathlib import Path

import pytest

from emt_brain.sync_contracts import (
    MANIFEST_FILENAME,
    UNIVERSAL_CONTRACTS,
    SyncResult,
    check_envelope_version_drift,
    populate_envelope_to_workflows,
)


# ---------------------------------------------------------------------------
# Test fixtures
# ---------------------------------------------------------------------------


def _make_repo(tmp_path: Path, workflows: list[tuple[str, bool]]) -> Path:
    """Create a fake repo skeleton under tmp_path.

    Args:
        tmp_path: pytest tmp fixture path
        workflows: list of (workflow_id, is_v2) tuples to create

    Returns the repo_root path.
    """
    repo = tmp_path / "repo"
    global_dir = repo / "flezi-emt" / "global-contracts"
    global_dir.mkdir(parents=True)
    (global_dir / "envelope-v1.json").write_text(
        '{"$id": "envelope-v1", "type": "object"}'
    )

    for wf_id, is_v2 in workflows:
        wf_dir = repo / "flezi-emt" / "workflows" / wf_id
        wf_dir.mkdir(parents=True)
        if is_v2:
            fm = (
                "---\n"
                f"name: {wf_id}\n"
                'pattern: workflow\n'
                'license: FPT-Proprietary\n'
                'owner: EMT\n'
                'blueprint_version: "2.0"\n'
                'contracts_index: contracts/index.yaml\n'
                'entry_agent: a\n'
                'agents:\n'
                '  - id: a\n'
                '    agent_ref: emt-ag-x\n'
                '---\n'
                '## v2 wf\n'
            )
        else:
            fm = (
                "---\n"
                f"name: {wf_id}\n"
                'pattern: workflow\n'
                'license: FPT-Proprietary\n'
                'owner: EMT\n'
                'entry_agent: a\n'
                'agents:\n'
                '  - id: a\n'
                '    agent_ref: emt-ag-x\n'
                '---\n'
                '## v1 wf\n'
            )
        (wf_dir / "SKILL.md").write_text(fm)
    return repo


# ---------------------------------------------------------------------------
# populate_envelope_to_workflows
# ---------------------------------------------------------------------------


def test_populate_copies_envelope_into_v2_workflow(tmp_path):
    repo = _make_repo(tmp_path, [("emt-wf-test", True)])
    results = populate_envelope_to_workflows(repo)
    assert any(r.action == "copied" and r.contract_name == "envelope-v1.json" for r in results)
    target = repo / "flezi-emt" / "workflows" / "emt-wf-test" / "contracts" / "envelope-v1.json"
    assert target.exists()
    # Content matches source
    src = repo / "flezi-emt" / "global-contracts" / "envelope-v1.json"
    assert target.read_text() == src.read_text()


def test_populate_skips_v1_workflow(tmp_path):
    repo = _make_repo(tmp_path, [("emt-wf-v1", False)])
    results = populate_envelope_to_workflows(repo)
    # v1 workflow should get skipped-v1 result
    assert any(r.action == "skipped-v1" for r in results)
    # No contracts/ folder should be created
    contracts_dir = repo / "flezi-emt" / "workflows" / "emt-wf-v1" / "contracts"
    assert not contracts_dir.exists()


def test_populate_writes_manifest_sidecar(tmp_path):
    repo = _make_repo(tmp_path, [("emt-wf-test", True)])
    populate_envelope_to_workflows(repo)
    manifest_path = (
        repo / "flezi-emt" / "workflows" / "emt-wf-test" / "contracts" / MANIFEST_FILENAME
    )
    assert manifest_path.exists()
    data = json.loads(manifest_path.read_text())
    assert "envelope-v1.json" in data
    assert "source_sha256" in data["envelope-v1.json"]


def test_populate_is_idempotent_up_to_date(tmp_path):
    repo = _make_repo(tmp_path, [("emt-wf-test", True)])
    # First sync
    populate_envelope_to_workflows(repo)
    # Second sync should detect up-to-date
    results = populate_envelope_to_workflows(repo)
    up_to_date = [r for r in results if r.action == "up-to-date"]
    assert len(up_to_date) >= 1


def test_populate_refreshes_when_source_changes(tmp_path):
    repo = _make_repo(tmp_path, [("emt-wf-test", True)])
    populate_envelope_to_workflows(repo)

    # Modify source
    source = repo / "flezi-emt" / "global-contracts" / "envelope-v1.json"
    source.write_text('{"$id": "envelope-v1", "type": "object", "modified": true}')

    # Re-sync → should refresh
    results = populate_envelope_to_workflows(repo)
    refreshed = [r for r in results if r.action == "refreshed"]
    assert len(refreshed) >= 1

    target = repo / "flezi-emt" / "workflows" / "emt-wf-test" / "contracts" / "envelope-v1.json"
    assert '"modified": true' in target.read_text()


def test_populate_handles_multiple_workflows(tmp_path):
    repo = _make_repo(tmp_path, [
        ("emt-wf-v2-a", True),
        ("emt-wf-v2-b", True),
        ("emt-wf-v1-c", False),
    ])
    results = populate_envelope_to_workflows(repo)
    copied = [r for r in results if r.action == "copied"]
    skipped = [r for r in results if r.action == "skipped-v1"]
    assert len(copied) == 2  # two v2 workflows
    assert len(skipped) == 1  # one v1 workflow


def test_populate_returns_error_when_global_contracts_missing(tmp_path):
    repo = tmp_path / "bad-repo"
    (repo / "flezi-emt" / "workflows").mkdir(parents=True)
    results = populate_envelope_to_workflows(repo)
    assert all(r.action == "error" for r in results)


def test_populate_dry_run_does_not_write(tmp_path):
    repo = _make_repo(tmp_path, [("emt-wf-test", True)])
    results = populate_envelope_to_workflows(repo, dry_run=True)
    # Result reports action
    assert any(r.action == "copied" for r in results)
    # But no files written (since contracts dir existed only because dry_run=True early-returned)
    # For this specific fixture, contracts/ does NOT exist yet, so dry_run returns error
    # Let's just check manifest doesn't exist:
    manifest = (
        repo / "flezi-emt" / "workflows" / "emt-wf-test" / "contracts" / MANIFEST_FILENAME
    )
    assert not manifest.exists()


# ---------------------------------------------------------------------------
# check_envelope_version_drift
# ---------------------------------------------------------------------------


def test_drift_detects_modified_local_copy(tmp_path):
    repo = _make_repo(tmp_path, [("emt-wf-test", True)])
    populate_envelope_to_workflows(repo)

    # Tamper with local copy (simulating user editing it)
    local = repo / "flezi-emt" / "workflows" / "emt-wf-test" / "contracts" / "envelope-v1.json"
    local.write_text('{"tampered": true}')
    # But source has changed too — so drift reports
    source = repo / "flezi-emt" / "global-contracts" / "envelope-v1.json"
    source.write_text('{"$id": "envelope-v1", "updated": true}')

    drift = check_envelope_version_drift(repo)
    assert len(drift) >= 1
    assert drift[0].action == "drift"


def test_drift_empty_when_in_sync(tmp_path):
    repo = _make_repo(tmp_path, [("emt-wf-test", True)])
    populate_envelope_to_workflows(repo)
    drift = check_envelope_version_drift(repo)
    assert len(drift) == 0


def test_drift_reports_missing_local_copy(tmp_path):
    repo = _make_repo(tmp_path, [("emt-wf-test", True)])
    populate_envelope_to_workflows(repo)

    # Delete local copy
    local = repo / "flezi-emt" / "workflows" / "emt-wf-test" / "contracts" / "envelope-v1.json"
    local.unlink()

    drift = check_envelope_version_drift(repo)
    errors = [d for d in drift if d.action == "error"]
    assert len(errors) >= 1
    assert "missing" in errors[0].detail.lower()


# ---------------------------------------------------------------------------
# SyncResult dataclass smoke
# ---------------------------------------------------------------------------


def test_sync_result_default_detail():
    r = SyncResult("wf-x", "copied", "envelope-v1.json")
    assert r.detail == ""


def test_universal_contracts_set():
    assert "envelope-v1.json" in UNIVERSAL_CONTRACTS
