"""test_sync_agents.py — Unit tests for sync_agents module."""
from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest

from emt_brain.sync_agents import (
    MARKER,
    AgentSyncAction,
    _build_output,
    _has_marker,
    _hash_content,
    _parse_frontmatter,
    apply_sync,
    plan_prune,
    plan_sync,
    run_sync_agents,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

MINIMAL_AGENT_MD = textwrap.dedent("""\
    ---
    name: emt-ag-test
    description: "A test agent"
    pattern: agent
    license: FPT-Proprietary
    owner: EMT
    category: planning
    version: "0.1.0"
    skills: [emt-sk-read-planning-context]
    claude_code:
      tools: []
      model: inherit
    ---

    # Test Agent

    You are a test agent.

    ## Responsibilities

    1. Do test things.
    """)

MULTI_MODE_AGENT_MD = textwrap.dedent("""\
    ---
    name: emt-ag-ip-spec
    description: "Spec agent with multiple modes"
    pattern: agent
    license: FPT-Proprietary
    owner: EMT
    category: planning
    version: "0.1.0"
    skills: [emt-sk-create-artifact]
    claude_code:
      tools: [read, write]
      model: sonnet
    ---

    # Spec Agent

    You are a spec agent.

    ## Responsibilities

    1. Create specs.
    """)

INDEX_JSON_CONTENT = {
    "$schema": "emt-index-v3",
    "version": 3,
    "updated": "2026-04-21",
    "skills": [],
    "bundles": [],
    "workflows": [],
    "agents": [
        {"id": "emt-ag-test", "source": "flezi-emt/agents/shared/emt-ag-test",
         "pattern": "agent", "name": "emt-ag-test", "description": "A test agent",
         "claude_code": {"tools": [], "model": "inherit"}},
        {"id": "emt-ag-ip-spec", "source": "flezi-emt/agents/internal-planning/emt-ag-ip-spec",
         "pattern": "agent", "name": "emt-ag-ip-spec", "description": "Spec agent with multiple modes",
         "claude_code": {"tools": ["read", "write"], "model": "sonnet"}},
    ],
}


@pytest.fixture
def tmp_repo(tmp_path: Path) -> Path:
    """Create a minimal repo with index.json and two agent source folders (each containing AGENT.md)."""
    # index.json
    (tmp_path / "index.json").write_text(
        json.dumps(INDEX_JSON_CONTENT, indent=2), encoding="utf-8"
    )

    # Agent source folders (each contains AGENT.md)
    shared_dir = tmp_path / "flezi-emt" / "agents" / "shared" / "emt-ag-test"
    shared_dir.mkdir(parents=True)
    (shared_dir / "AGENT.md").write_text(MINIMAL_AGENT_MD, encoding="utf-8")

    ip_dir = tmp_path / "flezi-emt" / "agents" / "internal-planning" / "emt-ag-ip-spec"
    ip_dir.mkdir(parents=True)
    (ip_dir / "AGENT.md").write_text(MULTI_MODE_AGENT_MD, encoding="utf-8")

    return tmp_path


@pytest.fixture
def agents_dest(tmp_path: Path) -> Path:
    d = tmp_path / ".claude" / "agents"
    d.mkdir(parents=True)
    return d


# ---------------------------------------------------------------------------
# _parse_frontmatter
# ---------------------------------------------------------------------------

class TestParseFrontmatter:
    def test_parses_valid_frontmatter(self):
        fm, body = _parse_frontmatter(MINIMAL_AGENT_MD)
        assert fm["name"] == "emt-ag-test"
        assert fm["pattern"] == "agent"
        assert "# Test Agent" in body

    def test_returns_empty_dict_on_no_frontmatter(self):
        fm, body = _parse_frontmatter("# No frontmatter here\n\nJust body.")
        assert fm == {}
        assert "No frontmatter" in body

    def test_body_after_closing_separator(self):
        _, body = _parse_frontmatter(MINIMAL_AGENT_MD)
        assert "# Test Agent" in body


# ---------------------------------------------------------------------------
# _build_output
# ---------------------------------------------------------------------------

class TestBuildOutput:
    def test_contains_marker(self):
        fm, body = _parse_frontmatter(MINIMAL_AGENT_MD)
        output = _build_output(fm, body)
        assert MARKER in output

    def test_contains_name_and_description(self):
        fm, body = _parse_frontmatter(MINIMAL_AGENT_MD)
        output = _build_output(fm, body)
        assert "name: emt-ag-test" in output
        assert "description:" in output

    def test_strips_emt_only_fields(self):
        fm, body = _parse_frontmatter(MINIMAL_AGENT_MD)
        output = _build_output(fm, body)
        assert "pattern:" not in output
        assert "license:" not in output
        assert "owner:" not in output
        assert "skills:" not in output

    def test_inherits_tools_when_present(self):
        fm, body = _parse_frontmatter(MULTI_MODE_AGENT_MD)
        output = _build_output(fm, body)
        assert '"read"' in output
        assert '"write"' in output

    def test_inherits_model_when_not_inherit(self):
        fm, body = _parse_frontmatter(MULTI_MODE_AGENT_MD)
        output = _build_output(fm, body)
        assert "model: sonnet" in output

    def test_omits_model_when_inherit(self):
        fm, body = _parse_frontmatter(MINIMAL_AGENT_MD)
        output = _build_output(fm, body)
        assert "model:" not in output

    def test_omits_tools_when_empty(self):
        fm, body = _parse_frontmatter(MINIMAL_AGENT_MD)
        output = _build_output(fm, body)
        assert "tools:" not in output

    def test_body_preserved(self):
        fm, body = _parse_frontmatter(MINIMAL_AGENT_MD)
        output = _build_output(fm, body)
        assert "# Test Agent" in output
        assert "## Responsibilities" in output


# ---------------------------------------------------------------------------
# _has_marker
# ---------------------------------------------------------------------------

class TestHasMarker:
    def test_detects_marker(self, tmp_path: Path):
        p = tmp_path / "agent.md"
        p.write_text(f"---\n{MARKER}\nname: x\n---\nbody\n", encoding="utf-8")
        assert _has_marker(p) is True

    def test_no_marker(self, tmp_path: Path):
        p = tmp_path / "agent.md"
        p.write_text("---\nname: x\n---\nbody\n", encoding="utf-8")
        assert _has_marker(p) is False

    def test_missing_file_returns_false(self, tmp_path: Path):
        assert _has_marker(tmp_path / "nonexistent.md") is False


# ---------------------------------------------------------------------------
# plan_sync
# ---------------------------------------------------------------------------

class TestPlanSync:
    def test_add_when_dest_absent(self, tmp_repo: Path, agents_dest: Path):
        agents = INDEX_JSON_CONTENT["agents"]
        plan = plan_sync(agents, tmp_repo, agents_dest)
        actions = {a.name: a for a in plan}
        assert actions["emt-ag-test"].action == "add"
        assert actions["emt-ag-ip-spec"].action == "add"

    def test_skip_when_content_unchanged(self, tmp_repo: Path, agents_dest: Path):
        agents = INDEX_JSON_CONTENT["agents"]
        # First: apply to create files
        plan = plan_sync(agents, tmp_repo, agents_dest)
        apply_sync(plan)
        # Second: plan again — should be skip
        plan2 = plan_sync(agents, tmp_repo, agents_dest)
        for action in plan2:
            assert action.action == "skip", f"{action.name} should be skip"

    def test_update_when_content_changed(self, tmp_repo: Path, agents_dest: Path):
        agents = INDEX_JSON_CONTENT["agents"]
        plan = plan_sync(agents, tmp_repo, agents_dest)
        apply_sync(plan)

        # Modify source file
        src = tmp_repo / "flezi-emt" / "agents" / "shared" / "emt-ag-test" / "AGENT.md"
        src.write_text(MINIMAL_AGENT_MD + "\nExtra line.\n", encoding="utf-8")

        plan2 = plan_sync(agents, tmp_repo, agents_dest)
        actions = {a.name: a for a in plan2}
        assert actions["emt-ag-test"].action == "update"

    def test_blocked_when_no_marker_on_existing_file(self, tmp_repo: Path, agents_dest: Path):
        # Pre-create a user-written file without marker
        user_file = agents_dest / "emt-ag-test.md"
        user_file.write_text("---\nname: emt-ag-test\n---\nmy own content\n", encoding="utf-8")

        agents = INDEX_JSON_CONTENT["agents"]
        plan = plan_sync(agents, tmp_repo, agents_dest)
        actions = {a.name: a for a in plan}
        assert actions["emt-ag-test"].action == "blocked"

    def test_blocked_when_source_missing(self, tmp_repo: Path, agents_dest: Path):
        agents = [{"id": "emt-ag-ghost", "source": "flezi-emt/agents/ghost"}]
        plan = plan_sync(agents, tmp_repo, agents_dest)
        assert plan[0].action == "blocked"


# ---------------------------------------------------------------------------
# plan_prune
# ---------------------------------------------------------------------------

class TestPlanPrune:
    def test_prune_orphan_files(self, agents_dest: Path):
        # Create a generated file that is NOT in the index
        orphan = agents_dest / "emt-ag-orphan.md"
        orphan.write_text(f"---\n{MARKER}\nname: emt-ag-orphan\n---\nbody\n", encoding="utf-8")

        pruned = plan_prune({"emt-ag-test", "emt-ag-ip-spec"}, agents_dest)
        assert len(pruned) == 1
        assert pruned[0].name == "emt-ag-orphan"
        assert pruned[0].action == "prune"

    def test_no_prune_for_indexed_agents(self, agents_dest: Path):
        # Create a generated file that IS in the index
        indexed = agents_dest / "emt-ag-test.md"
        indexed.write_text(f"---\n{MARKER}\nname: emt-ag-test\n---\nbody\n", encoding="utf-8")

        pruned = plan_prune({"emt-ag-test"}, agents_dest)
        assert len(pruned) == 0

    def test_no_prune_user_files_without_marker(self, agents_dest: Path):
        user_file = agents_dest / "emt-ag-user.md"
        user_file.write_text("---\nname: emt-ag-user\n---\nbody\n", encoding="utf-8")

        pruned = plan_prune(set(), agents_dest)
        assert len(pruned) == 0

    def test_empty_dest_returns_empty(self, tmp_path: Path):
        pruned = plan_prune(set(), tmp_path / "nonexistent")
        assert pruned == []


# ---------------------------------------------------------------------------
# apply_sync
# ---------------------------------------------------------------------------

class TestApplySync:
    def test_dry_run_does_not_write(self, tmp_repo: Path, agents_dest: Path):
        agents = INDEX_JSON_CONTENT["agents"]
        plan = plan_sync(agents, tmp_repo, agents_dest)
        stats = apply_sync(plan, dry_run=True)
        assert stats["added"] == 2
        assert not (agents_dest / "emt-ag-test.md").exists()

    def test_apply_writes_files(self, tmp_repo: Path, agents_dest: Path):
        agents = INDEX_JSON_CONTENT["agents"]
        plan = plan_sync(agents, tmp_repo, agents_dest)
        stats = apply_sync(plan, dry_run=False)
        assert stats["added"] == 2
        assert (agents_dest / "emt-ag-test.md").exists()
        assert (agents_dest / "emt-ag-ip-spec.md").exists()

    def test_prune_deletes_file(self, agents_dest: Path):
        orphan = agents_dest / "emt-ag-orphan.md"
        orphan.write_text(f"---\n{MARKER}\nname: emt-ag-orphan\n---\nbody\n", encoding="utf-8")
        prune_actions = [AgentSyncAction(
            name="emt-ag-orphan",
            source=orphan,
            dest=orphan,
            action="prune",
            reason="test",
        )]
        apply_sync(prune_actions, dry_run=False)
        assert not orphan.exists()

    def test_prune_dry_run_keeps_file(self, agents_dest: Path):
        orphan = agents_dest / "emt-ag-orphan.md"
        orphan.write_text(f"---\n{MARKER}\nname: emt-ag-orphan\n---\nbody\n", encoding="utf-8")
        prune_actions = [AgentSyncAction(
            name="emt-ag-orphan",
            source=orphan,
            dest=orphan,
            action="prune",
            reason="test",
        )]
        apply_sync(prune_actions, dry_run=True)
        assert orphan.exists()

    def test_blocked_counted_but_not_written(self, agents_dest: Path, tmp_path: Path):
        blocked_action = AgentSyncAction(
            name="emt-ag-ghost",
            source=tmp_path / "ghost.md",
            dest=agents_dest / "emt-ag-ghost.md",
            action="blocked",
            reason="source missing",
        )
        stats = apply_sync([blocked_action])
        assert stats["blocked"] == 1
        assert not (agents_dest / "emt-ag-ghost.md").exists()


# ---------------------------------------------------------------------------
# run_sync_agents (integration)
# ---------------------------------------------------------------------------

class TestRunSyncAgents:
    def test_full_sync_creates_files(self, tmp_repo: Path, agents_dest: Path):
        actions, stats = run_sync_agents(tmp_repo, agents_dest)
        assert stats["added"] == 2
        assert (agents_dest / "emt-ag-test.md").exists()

    def test_idempotent_second_run(self, tmp_repo: Path, agents_dest: Path):
        run_sync_agents(tmp_repo, agents_dest)
        _, stats2 = run_sync_agents(tmp_repo, agents_dest)
        assert stats2["added"] == 0
        assert stats2["updated"] == 0
        assert stats2["skipped"] == 2

    def test_dry_run_no_files_written(self, tmp_repo: Path, agents_dest: Path):
        _, stats = run_sync_agents(tmp_repo, agents_dest, dry_run=True)
        assert stats["added"] == 2
        assert not (agents_dest / "emt-ag-test.md").exists()

    def test_prune_removes_orphan(self, tmp_repo: Path, agents_dest: Path):
        # Create an orphan
        orphan = agents_dest / "emt-ag-gone.md"
        orphan.write_text(f"---\n{MARKER}\nname: emt-ag-gone\n---\nbody\n", encoding="utf-8")
        _, stats = run_sync_agents(tmp_repo, agents_dest, prune=True)
        assert stats["pruned"] == 1
        assert not orphan.exists()

    def test_missing_index_returns_empty(self, tmp_path: Path, agents_dest: Path):
        actions, stats = run_sync_agents(tmp_path, agents_dest)
        assert actions == []
        assert stats == {}

    def test_generated_file_has_marker(self, tmp_repo: Path, agents_dest: Path):
        run_sync_agents(tmp_repo, agents_dest)
        content = (agents_dest / "emt-ag-test.md").read_text(encoding="utf-8")
        assert MARKER in content

    def test_generated_file_strips_emt_fields(self, tmp_repo: Path, agents_dest: Path):
        run_sync_agents(tmp_repo, agents_dest)
        content = (agents_dest / "emt-ag-test.md").read_text(encoding="utf-8")
        assert "pattern:" not in content
        assert "license:" not in content
        assert "skills:" not in content

    def test_model_sonnet_included(self, tmp_repo: Path, agents_dest: Path):
        run_sync_agents(tmp_repo, agents_dest)
        content = (agents_dest / "emt-ag-ip-spec.md").read_text(encoding="utf-8")
        assert "model: sonnet" in content

    def test_tools_included_for_multi_mode(self, tmp_repo: Path, agents_dest: Path):
        run_sync_agents(tmp_repo, agents_dest)
        content = (agents_dest / "emt-ag-ip-spec.md").read_text(encoding="utf-8")
        assert "read" in content
        assert "write" in content
