"""
hatch_build.py — Pre-build hook: sync .claude/settings.json → emt_brain/settings-template.json

Runs automatically before every `python -m build` so the bundled template
always mirrors the project's canonical settings file. The _load_template()
function in hook_setup.py then applies path rewrites and strips project-specific
hooks at install time.
"""

import shutil
from pathlib import Path

from hatchling.builders.hooks.plugin.interface import BuildHookInterface


class CustomBuildHook(BuildHookInterface):
    def initialize(self, version: str, build_data: dict) -> None:
        repo_root = Path(__file__).parent.parent.parent
        src = repo_root / ".claude" / "settings.json"
        dst = Path(__file__).parent / "emt_brain" / "settings-template.json"
        if src.exists():
            shutil.copy2(src, dst)
            self.app.display_info(f"[hook] Synced {src.relative_to(repo_root)} → emt_brain/settings-template.json")
        else:
            self.app.display_warning("[hook] .claude/settings.json not found — using existing settings-template.json")
