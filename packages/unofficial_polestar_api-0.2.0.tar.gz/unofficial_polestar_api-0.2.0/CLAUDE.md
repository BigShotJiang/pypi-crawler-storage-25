# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
pytest tests/                              # run all tests
pytest tests/test_models.py::test_name     # run single test
python -m build                            # build sdist + wheel
mkdocs serve                               # local docs preview
```

No formal linter configured.

## Architecture

Two packages in one repo:

- **`src/polestar_api/`** — Async Python client for Polestar's gRPC APIs. Published to PyPI as `unofficial-polestar-api`.
- **`custom_components/polestar/`** — Home Assistant integration that depends on the above package. Distributed via HACS.

### Protobuf without protoc

The project uses **no `.proto` files or code generation**. Instead:

- **`codec.py`** — Raw protobuf wire format encoder/decoder. Handles varint, fixed64, fixed32, length-delimited, and deprecated groups (wire type 3/4).
- **`wire.py`** — `ProtoMessage` mixin for frozen dataclasses. Add `schema={field_num: "attr_name"}` to a dataclass and it gets `to_bytes()` / `from_bytes()`. Wire types are inferred from Python type hints (float→double, int→int64, str→string, IntEnum→enum, nested ProtoMessage→message). Use `Annotated[float, Float32]` for 32-bit floats.

### Service layer

Each gRPC service gets a client class in `services/`. Pattern:
- Constructor takes `GrpcConnection` + VIN
- Service path comes from `BackendProfile` (abstracts C3 vs PCCS backend paths)
- Uses `grpc.unary_unary()` or `grpc.unary_stream()` from `grpc.py` (auto-retry with exponential backoff, user agent spoofed as Java/OkHttp)

### Chronos envelope

Services under `chronos.services.v1.*` (amp limit, target SoC, charge timer, charge locations, etc.) wrap requests in a `ChronosRequest` envelope (UUID, VIN, source="RCS", timezone). Use `wrap_chronos(vin, payload)` from `services/chronos.py`. Responses also come wrapped — services have `_parse()` methods that unwrap field 3 of the envelope before parsing the inner payload.

Chronos endpoints are subscriptions (unary_stream) — take the first message, then the stream stays open for live updates.

### Auth flow

OIDC/PKCE via Polestar's PingFederate. `TokenStore` is a Protocol with file, memory, and HA config entry implementations. Tokens auto-refresh 60s before expiry; full re-auth if refresh fails.

### Vehicle facade

`vehicle.py` composes all ~18 service clients into a single `Vehicle` class that the HA integration and end users interact with.

### HA integration

`PolestarCoordinator` (extends `DataUpdateCoordinator`) handles both polling (default 10 min, configurable) and long-lived gRPC streams for real-time data. Entity classes pull data from `coordinator.data` (a `PolestarVehicleData` snapshot).

## Reverse engineering context

Proto schemas are reverse-engineered from the decompiled Polestar APK (JADX output in the parent repo's `artifacts/decompiled/`). Field numbers and types come from the `dynamicMethod` / `newMessageInfo` strings in the decompiled Java. The parent repo at `../` has `FINDINGS.md` with discovered endpoints and `protos/` with partial reconstructed `.proto` files.