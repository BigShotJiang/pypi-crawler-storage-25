import unittest
from llm_redacted import sanitize_output, restore_output

class TestSanitizer(unittest.TestCase):
    def test_basic_sanitize(self):
        text = "My email is test@gmail.com and key is sk-12345678901234567890"
        clean = sanitize_output(text)
        self.assertIn("[EMAIL]", clean)
        self.assertIn("[OPENAI_KEY]", clean)

    def test_detailed_sanitize(self):
        text = "Contact a@b.com or c@d.com"
        result = sanitize_output(text, detailed=True)
        self.assertIn("[EMAIL_1]", result.cleaned)
        self.assertIn("[EMAIL_2]", result.cleaned)
        
        restored = restore_output(result.cleaned, result.mapping)
        self.assertEqual(restored, text)

if __name__ == '__main__':
    unittest.main()
