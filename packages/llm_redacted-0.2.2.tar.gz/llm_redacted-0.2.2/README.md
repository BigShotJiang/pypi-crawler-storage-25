# llm-redacted

Stop leaking secrets. One function call.

A lightweight, zero-dependency Python library that sanitizes secrets, API keys, PII, and sensitive data from text. Designed for LLM output pipelines.

## Installation

```bash
pip install llm-redacted
```

## Quick Start

```python
from llm_redacted import sanitize_output

text = "My API key is sk-12345678901234567890"
clean = sanitize_output(text)
print(clean)
# Output: My API key is [OPENAI_KEY]
```

## Features

- **20 Built-in Detectors**: OpenAI, AWS, GitHub, Stripe, JWT, GCP, Slack, Twilio, Azure, Discord, PEM, Email, Phone, IPv4, SSN, Credit Cards, Env Vars, Local Paths, Connection Strings, Bearer Tokens.
- **Zero Dependencies**: Pure Python stdlib.
- **Reversible Redaction**: Keep a mapping of original secrets to restore them later.
- **Streaming Support**: Sanitize LLM streams token-by-token.
- **Extensible**: Add custom regex detectors easily.

## Advanced Usage

### Reversible Redaction
```python
from llm_redacted import sanitize_output, restore_output

result = sanitize_output("Email admin@test.com", detailed=True)
print(result.cleaned) # Email [EMAIL_1]

restored = restore_output(result.cleaned, result.mapping)
print(restored) # Email admin@test.com
```

### Streaming
```python
from llm_redacted import StreamingSanitizer

sanitizer = StreamingSanitizer()
# feed tokens one by one
safe_token = sanitizer.feed("sk-")
```
