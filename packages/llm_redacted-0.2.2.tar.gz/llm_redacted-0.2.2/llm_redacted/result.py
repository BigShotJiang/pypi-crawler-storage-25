"""Result types for the redacted sanitizer."""
from dataclasses import dataclass, field


@dataclass
class Finding:
    """A single detected sensitive item."""
    detector_type: str
    original: str
    placeholder: str
    start: int
    end: int


@dataclass
class SanitizeResult:
    """Result of a detailed sanitization operation."""
    cleaned: str
    findings: list = field(default_factory=list)
    mapping: dict = field(default_factory=dict)

    def __str__(self):
        return self.cleaned

    def __repr__(self):
        return f"SanitizeResult(findings={len(self.findings)}, mapping_size={len(self.mapping)})"
