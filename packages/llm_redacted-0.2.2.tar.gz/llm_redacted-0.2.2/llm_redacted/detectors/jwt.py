# Matches JWT tokens: must start with eyJ (base64 for '{"')
# Three base64url sections separated by dots
TYPE = "JWT_TOKEN"
PATTERN = r"\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b"
PLACEHOLDER = "[JWT_TOKEN]"