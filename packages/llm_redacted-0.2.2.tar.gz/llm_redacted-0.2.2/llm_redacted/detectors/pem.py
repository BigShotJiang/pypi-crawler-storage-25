# Matches PEM-encoded private keys: RSA, DSA, EC, OPENSSH, ENCRYPTED
TYPE = "PEM_KEY"
PATTERN = r"-----BEGIN[\w ]*PRIVATE KEY-----[\s\S]+?-----END[\w ]*PRIVATE KEY-----"
PLACEHOLDER = "[PEM_KEY]"
