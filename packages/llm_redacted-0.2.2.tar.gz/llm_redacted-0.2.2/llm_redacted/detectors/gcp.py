# Matches Google Cloud API keys (AIzaSy prefix, 39 chars total)
# and Google OAuth client IDs
TYPE = "GCP_API_KEY"
PATTERN = r"\bAIzaSy[A-Za-z0-9_-]{33}\b"
PLACEHOLDER = "[GCP_KEY]"
