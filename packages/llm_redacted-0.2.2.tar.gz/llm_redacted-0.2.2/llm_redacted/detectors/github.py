# Matches GitHub tokens: ghp_, gho_, ghu_, ghs_, ghr_ followed by 36+ alphanumeric chars
TYPE = "GITHUB_TOKEN"
PATTERN = r"\bgh[pousr]_[A-Za-z0-9_]{36,}\b"
PLACEHOLDER = "[GITHUB_TOKEN]"
