# Matches Azure storage account keys (base64, 88 chars)
# and Azure SAS tokens
TYPE = "AZURE_KEY"
PATTERN = r"(?:AccountKey=)[A-Za-z0-9+/=]{80,}|(?:sig=)[A-Za-z0-9%+/=]{40,}"
PLACEHOLDER = "[AZURE_KEY]"
