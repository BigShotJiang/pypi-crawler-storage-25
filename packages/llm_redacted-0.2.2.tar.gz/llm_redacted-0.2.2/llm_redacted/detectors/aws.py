# Matches AWS Access Key IDs: AKIA, ASIA (temp creds), AGPA, ANPA, A3T prefixes
TYPE = "AWS_ACCESS_KEY"
PATTERN = r"\b(?:AKIA|ASIA|AGPA|ANPA|A3T)[0-9A-Z]{16}\b"
PLACEHOLDER = "[AWS_KEY]"
