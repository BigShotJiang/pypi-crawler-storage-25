# Matches email addresses
TYPE = "EMAIL"
PATTERN = r"\b[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z]{2,}\b"
PLACEHOLDER = "[EMAIL]"
