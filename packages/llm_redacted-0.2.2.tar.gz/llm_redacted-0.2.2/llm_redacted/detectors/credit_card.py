# Matches major credit card number formats (with optional separators)
# Visa (4xxx), Mastercard (5xxx/2xxx), Amex (34xx/37xx), Discover (6xxx)
TYPE = "CREDIT_CARD"
PATTERN = r"\b(?:4[0-9]{3}|5[1-5][0-9]{2}|3[47][0-9]{2}|6(?:011|5[0-9]{2}))[- ]?[0-9]{4}[- ]?[0-9]{4}[- ]?[0-9]{3,4}\b"
PLACEHOLDER = "[CREDIT_CARD]"
