# Matches local file paths (Unix and Windows)
# Covers /home, /Users, /root, /etc, /var, /tmp, /opt, /srv and Windows drive paths
TYPE = "LOCAL_PATH"
PATTERN = r"(?:[A-Z]:\\(?:[^\\\s]+\\)*[^\\\s]+|/(?:home|Users|root|etc|var|tmp|opt|srv)/[\w./-]+)"
PLACEHOLDER = "[LOCAL_PATH]"
