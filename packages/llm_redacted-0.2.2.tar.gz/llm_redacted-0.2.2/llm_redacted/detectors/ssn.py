# Matches US Social Security Numbers: XXX-XX-XXXX format
# Excludes known invalid ranges (000, 666, 900-999 in area)
TYPE = "SSN"
PATTERN = r"\b(?!000|666|9\d{2})\d{3}-(?!00)\d{2}-(?!0000)\d{4}\b"
PLACEHOLDER = "[SSN]"
