# Matches Stripe API keys: sk_live_ or sk_test_ followed by 24+ alphanumeric chars
TYPE = "STRIPE_KEY"
PATTERN = r"\bsk_(?:live|test)_[A-Za-z0-9]{24,}\b"
PLACEHOLDER = "[STRIPE_KEY]"
