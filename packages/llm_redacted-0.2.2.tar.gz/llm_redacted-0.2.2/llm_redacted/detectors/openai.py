# Matches OpenAI API keys: sk-<20+ alphanumeric chars>
# Supports sk-proj- and sk-org- prefixes
TYPE = "OPENAI_API_KEY"
PATTERN = r"\bsk-(?:proj-|org-)?[A-Za-z0-9_-]{20,}\b"
PLACEHOLDER = "[OPENAI_KEY]"