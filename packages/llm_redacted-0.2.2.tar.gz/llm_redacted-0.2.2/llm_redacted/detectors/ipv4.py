# Matches valid IPv4 addresses: each octet 0-255
TYPE = "IPV4_ADDRESS"
PATTERN = r"\b(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)\b"
PLACEHOLDER = "[IP_ADDRESS]"
