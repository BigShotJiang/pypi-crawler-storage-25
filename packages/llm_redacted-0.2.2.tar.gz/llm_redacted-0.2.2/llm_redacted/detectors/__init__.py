"""Auto-discovery of all detector modules in this package."""
import importlib
import pkgutil
import os


def _discover_detectors():
    """Discover all detector modules and return them as a list."""
    detectors = []
    package_dir = os.path.dirname(__file__)
    for importer, modname, ispkg in pkgutil.iter_modules([package_dir]):
        if modname.startswith('_'):
            continue
        module = importlib.import_module(f'.{modname}', package=__package__)
        if hasattr(module, 'TYPE') and hasattr(module, 'PATTERN') and hasattr(module, 'PLACEHOLDER'):
            detectors.append(module)
    return detectors


ALL_DETECTORS = _discover_detectors()
