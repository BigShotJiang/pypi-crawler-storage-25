# Matches Discord bot tokens and webhook URLs
TYPE = "DISCORD_TOKEN"
PATTERN = r"(?:discord(?:app)?\.com/api/webhooks/\d+/[\w-]+|[MN][A-Za-z\d]{23,}\.[\w-]{6}\.[\w-]{27,})"
PLACEHOLDER = "[DISCORD_TOKEN]"
