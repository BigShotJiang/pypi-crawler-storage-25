# Matches international phone numbers - requires + country code to reduce false positives
# Or matches common formats like (XXX) XXX-XXXX
TYPE = "PHONE"
PATTERN = r"(?:\+\d{1,3}[\s.-]?\(?\d{1,4}\)?[\s.-]?\d{2,5}[\s.-]?\d{2,5})|(?:\(\d{3}\)[\s.-]?\d{3}[\s.-]?\d{4})"
PLACEHOLDER = "[PHONE]"
