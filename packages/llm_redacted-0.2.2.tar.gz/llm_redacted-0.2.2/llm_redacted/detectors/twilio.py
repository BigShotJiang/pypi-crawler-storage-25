# Matches Twilio Account SIDs (AC + 32 hex) and Auth Tokens (32 hex)
TYPE = "TWILIO_KEY"
PATTERN = r"\bAC[a-f0-9]{32}\b"
PLACEHOLDER = "[TWILIO_SID]"
