# Matches Bearer tokens in HTTP authorization headers
TYPE = "BEARER_TOKEN"
PATTERN = r"(?:Bearer|Authorization:\s*Bearer)\s+[A-Za-z0-9_\-.~+/]+="
PLACEHOLDER = "[BEARER_TOKEN]"
