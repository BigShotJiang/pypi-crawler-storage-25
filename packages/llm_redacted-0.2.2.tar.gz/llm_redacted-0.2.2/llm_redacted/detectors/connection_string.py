# Matches database connection strings with embedded credentials
# postgres://, mysql://, mongodb://, redis://, etc.
TYPE = "CONNECTION_STRING"
PATTERN = r"(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis|amqp|mssql)://[^\s'\"<>]+:[^\s'\"<>]+@[^\s'\"<>]+"
PLACEHOLDER = "[CONNECTION_STRING]"
