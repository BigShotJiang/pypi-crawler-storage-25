# Matches env var assignments with sensitive-looking keys
# Requires key to contain SECRET, PASSWORD, TOKEN, API_KEY, etc.
# Value must be at least 6 chars to avoid matching docs
TYPE = "ENV_VAR"
PATTERN = r"(?:^|\b)(?:export\s+)?[A-Z_]*(?:SECRET|PASSWORD|PASSWD|TOKEN|API_?KEY|AUTH|CREDENTIAL)[A-Z_]*\s*=\s*[\"']?[^\s\"'>]{6,}[\"']?"
PLACEHOLDER = "[ENV_VAR_REDACTED]"
