# Matches Slack tokens: bot (xoxb-), user (xoxp-), app (xapp-), workspace (xoxa-)
TYPE = "SLACK_TOKEN"
PATTERN = r"\bxox[bpas]-[A-Za-z0-9-]{10,}\b"
PLACEHOLDER = "[SLACK_TOKEN]"
