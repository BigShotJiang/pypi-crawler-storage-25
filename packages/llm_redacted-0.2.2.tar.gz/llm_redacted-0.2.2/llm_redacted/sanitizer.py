"""Core sanitization engine for the redacted library."""
import re
from llm_redacted.detectors import ALL_DETECTORS
from llm_redacted.result import SanitizeResult, Finding


# Precompile regexes for built-in detectors
_COMPILED_DETECTORS = [
    (re.compile(det.PATTERN, re.MULTILINE), det.TYPE, det.PLACEHOLDER)
    for det in ALL_DETECTORS
]


def sanitize_output(text, custom_detectors=None, detailed=False):
    """Sanitize sensitive data from text.

    Args:
        text: Input text to sanitize.
        custom_detectors: Optional list of custom detector dicts with
            'TYPE', 'PATTERN', and 'PLACEHOLDER' keys.
        detailed: If True, returns a SanitizeResult with findings and
            a reversible mapping. If False, returns a plain string.

    Returns:
        str if detailed=False, SanitizeResult if detailed=True.
    """
    compiled = list(_COMPILED_DETECTORS)

    if custom_detectors:
        for det in custom_detectors:
            compiled.append((
                re.compile(det["PATTERN"], re.MULTILINE),
                det["TYPE"],
                det["PLACEHOLDER"]
            ))

    if not detailed:
        # Simple mode: just replace with static placeholders (backward compatible)
        cleaned = text
        for pattern, dtype, placeholder in compiled:
            cleaned = pattern.sub(placeholder, cleaned)
        return cleaned

    # Detailed mode: collect findings, build mapping with indexed placeholders
    # First, find all matches across all detectors
    all_matches = []
    for pattern, dtype, placeholder in compiled:
        for match in pattern.finditer(text):
            all_matches.append({
                'start': match.start(),
                'end': match.end(),
                'original': match.group(),
                'type': dtype,
                'placeholder_base': placeholder,
            })

    # Sort by start position (earliest first), then by length (longest first)
    all_matches.sort(key=lambda m: (m['start'], -(m['end'] - m['start'])))

    # Remove overlapping matches (keep the first/longest one)
    filtered = []
    last_end = 0
    for m in all_matches:
        if m['start'] >= last_end:
            filtered.append(m)
            last_end = m['end']

    # Build indexed placeholders and mapping
    type_counters = {}
    findings = []
    mapping = {}

    for m in filtered:
        base = m['placeholder_base']
        # Strip brackets, add index, re-bracket
        inner = base.strip('[]')
        count = type_counters.get(inner, 0) + 1
        type_counters[inner] = count
        indexed = f"[{inner}_{count}]"

        findings.append(Finding(
            detector_type=m['type'],
            original=m['original'],
            placeholder=indexed,
            start=m['start'],
            end=m['end'],
        ))
        mapping[indexed] = m['original']

    # Build cleaned text by replacing from end to start to preserve positions
    cleaned = text
    for finding in reversed(findings):
        cleaned = cleaned[:finding.start] + finding.placeholder + cleaned[finding.end:]

    return SanitizeResult(
        cleaned=cleaned,
        findings=findings,
        mapping=mapping,
    )


def restore_output(cleaned_text, mapping):
    """Restore original values from a sanitized text using a mapping.

    Args:
        cleaned_text: Text with indexed placeholders (e.g., [EMAIL_1]).
        mapping: Dict mapping placeholders to original values,
            as returned by SanitizeResult.mapping.

    Returns:
        str with placeholders replaced by original values.
    """
    result = cleaned_text
    # Sort by placeholder length descending to avoid partial replacements
    for placeholder, original in sorted(mapping.items(), key=lambda x: -len(x[0])):
        result = result.replace(placeholder, original)
    return result