"""Streaming sanitizer for real-time LLM output processing."""
import re
from llm_redacted.detectors import ALL_DETECTORS


class StreamingSanitizer:
    """Sanitizes text token-by-token for streaming LLM output.

    Maintains an internal buffer to handle patterns that may span
    multiple tokens. Emits sanitized text as soon as it's safe to
    do so.

    Usage:
        sanitizer = StreamingSanitizer()
        for token in llm_stream:
            safe_text = sanitizer.feed(token)
            print(safe_text, end='', flush=True)
        # Don't forget to flush at the end
        print(sanitizer.flush(), end='', flush=True)
    """

    # Maximum pattern length we might need to buffer for
    # This is a conservative estimate based on the longest patterns
    _MAX_PATTERN_LEN = 512

    def __init__(self, custom_detectors=None):
        """Initialize the streaming sanitizer.

        Args:
            custom_detectors: Optional list of custom detector dicts
                with 'TYPE', 'PATTERN', and 'PLACEHOLDER' keys.
        """
        self._buffer = ""
        self._detectors = [
            (re.compile(det.PATTERN, re.MULTILINE), det.PLACEHOLDER)
            for det in ALL_DETECTORS
        ]
        if custom_detectors:
            for det in custom_detectors:
                self._detectors.append((
                    re.compile(det["PATTERN"], re.MULTILINE),
                    det["PLACEHOLDER"]
                ))

    def feed(self, token):
        """Feed a token into the sanitizer.

        Args:
            token: A string token from the LLM stream.

        Returns:
            A string of sanitized text that is safe to emit.
            May be empty if the sanitizer is buffering.
        """
        self._buffer += token

        # If buffer is small, keep accumulating — we might be mid-pattern
        if len(self._buffer) < self._MAX_PATTERN_LEN:
            # Check if any pattern could still be growing
            if self._has_partial_match():
                return ""

        # Apply all detectors to the buffer
        sanitized = self._buffer
        for pattern, placeholder in self._detectors:
            sanitized = pattern.sub(placeholder, sanitized)

        # Keep a tail portion in the buffer in case a pattern spans
        # the boundary. The safe portion is everything before the tail.
        tail_size = min(self._MAX_PATTERN_LEN, len(sanitized))

        if len(sanitized) <= tail_size:
            # Buffer is still small enough to hold entirely
            self._buffer = self._buffer  # keep original buffer for partial matching
            # But if no partial matches, we can emit some
            if not self._has_partial_match():
                self._buffer = ""
                return sanitized
            return ""

        safe = sanitized[:-tail_size]
        # We need to figure out how much of the original buffer corresponds
        # to the safe portion. Apply detectors to progressively larger
        # prefixes... Actually, simpler approach:
        # After sanitization, keep the tail of the SANITIZED output
        # in the buffer and emit the safe prefix.
        self._buffer = sanitized[-tail_size:]
        return safe

    def _has_partial_match(self):
        """Check if any detector pattern could partially match at the end of the buffer."""
        buf = self._buffer
        # Check if the buffer ends with something that looks like
        # the start of a sensitive pattern
        partial_starters = [
            r'sk-',           # OpenAI, Stripe
            r'eyJ',           # JWT
            r'AKIA', r'ASIA', # AWS
            r'gh',            # GitHub
            r'xox',           # Slack
            r'AC',            # Twilio
            r'AIza',          # GCP
            r'Bearer',        # Bearer tokens
            r'-----BEGIN',    # PEM
            r'AccountKey=',   # Azure
        ]
        for starter in partial_starters:
            # Check if the buffer ends with a prefix of this starter
            for i in range(1, len(starter) + 1):
                if buf.endswith(starter[:i]):
                    return True
        return False

    def flush(self):
        """Flush remaining buffer content.

        Call this when the stream ends to get any remaining text.

        Returns:
            Sanitized remaining buffer content.
        """
        if not self._buffer:
            return ""
        sanitized = self._buffer
        for pattern, placeholder in self._detectors:
            sanitized = pattern.sub(placeholder, sanitized)
        self._buffer = ""
        return sanitized

    def reset(self):
        """Reset the sanitizer state, clearing the buffer."""
        self._buffer = ""
