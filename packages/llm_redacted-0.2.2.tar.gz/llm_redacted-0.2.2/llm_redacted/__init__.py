"""redacted — A lightweight, zero-dependency output sanitizer.

Sanitizes secrets, API keys, PII, and sensitive data from text.
Designed for LLM output pipelines, logging, and data sharing.
"""
from llm_redacted.sanitizer import sanitize_output, restore_output
from llm_redacted.result import SanitizeResult, Finding
from llm_redacted.streaming import StreamingSanitizer

__version__ = "0.2.1"
__all__ = [
    "sanitize_output",
    "restore_output",
    "SanitizeResult",
    "Finding",
    "StreamingSanitizer",
]
