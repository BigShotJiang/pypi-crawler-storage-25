"""find_customer -- Search for a customer in the License Portal.

Uses SOQL LIKE as primary search, falling back to SOSL (fuzzy/phonetic)
when SOQL returns no results. Returns matches for the AI to present.
On confirmation, returns account_id and account_name for the AI to
pass explicitly to downstream tools.
"""

import logging
import re
from typing import Any

from ..utils import sf_cli, state

logger = logging.getLogger(__name__)

TOOL_DEFINITION = {
    "name": "find_customer",
    "description": (
        "Search for a customer by name in the CloudSense License Management "
        "Portal. Uses SOQL LIKE search with SOSL fuzzy fallback. Returns "
        "matching accounts for the AI to present to the user. "
        "Once the user confirms a customer, call this tool again with "
        "confirm_account_id and confirm_account_name — the tool returns "
        "account_id and account_name for you to pass to downstream tools. "
        "Requires connect_lma first."
    ),
    "inputSchema": {
        "type": "object",
        "properties": {
            "customer_name": {
                "type": "string",
                "description": (
                    "Customer name to search for. Handles partial matches "
                    "and misspellings. Examples: 'nbnco', 'NBN Co', 'starhub'"
                ),
            },
            "confirm_account_id": {
                "type": "string",
                "description": (
                    "Account ID to confirm. Pass this after the user has "
                    "confirmed the correct account from search results."
                ),
            },
            "confirm_account_name": {
                "type": "string",
                "description": (
                    "Account name corresponding to confirm_account_id."
                ),
            },
            "working_directory": {
                "type": "string",
                "description": "Workspace directory. The AI passes this automatically.",
            },
        },
        "required": [],
    },
}


def _get_lma_alias() -> str:
    """Read the LMA org alias from state, or return default."""
    existing = state.load()
    return existing.get("lma_org_alias") or "cs-lma"


ACCOUNT_FIELDS = (
    "Id, Name, Type, Description, Country__c, Industry, "
    "Industry_Type__c, Industry_Class__c, Industry_Group__c, "
    "LinkedIn_Company_Profile_URL__c, Ownership_status__c, "
    "ParentId, Parent.Name, Region__c, Website"
)


def _sosl_search(name: str, lma_alias: str) -> list[dict[str, Any]]:
    """SOSL fuzzy search against Account, excluding Prospects."""
    try:
        return sf_cli.sosl_search(
            search_term=name,
            returning=f"Account({ACCOUNT_FIELDS} WHERE Type != 'Prospect')",
            target_org=lma_alias,
        )
    except sf_cli.SfCliError as e:
        logger.warning("SOSL search failed: %s", e)
        return []


def _soql_search(name: str, lma_alias: str) -> list[dict[str, Any]]:
    """SOQL LIKE search against Account, excluding Prospects."""
    safe_name = name.replace("'", "''")
    query = (
        f"SELECT {ACCOUNT_FIELDS} FROM Account "
        f"WHERE Name LIKE '%{safe_name}%' "
        f"AND (Type != 'Prospect' OR Type = null) "
        f"ORDER BY Name LIMIT 25"
    )
    return sf_cli.lma_query(query, lma_alias)


def _fetch_account_detail(account_id: str, lma_alias: str) -> dict[str, Any]:
    """Fetch full account profile by ID for the confirmation step."""
    safe_id = account_id.replace("'", "''")
    query = f"SELECT {ACCOUNT_FIELDS} FROM Account WHERE Id = '{safe_id}' LIMIT 1"
    try:
        results = sf_cli.lma_query(query, lma_alias)
        return results[0] if results else {}
    except sf_cli.SfCliError:
        return {}


def _format_account_profile(
    acct: dict[str, Any], fallback_name: str, fallback_id: str,
) -> str:
    """Format account detail into a readable profile block."""
    name = acct.get("Name") or fallback_name
    aid = acct.get("Id") or fallback_id
    region = acct.get("Region__c") or "—"
    country = acct.get("Country__c") or "—"
    industry = acct.get("Industry") or "—"

    industry_parts = [
        p for p in [
            acct.get("Industry_Type__c"),
            acct.get("Industry_Class__c"),
            acct.get("Industry_Group__c"),
        ] if p
    ]
    industry_detail = " > ".join(industry_parts) if industry_parts else ""
    industry_str = f"{industry} ({industry_detail})" if industry_detail else industry

    parent_ref = acct.get("Parent")
    parent_name = parent_ref.get("Name") if isinstance(parent_ref, dict) else None
    parent_str = parent_name or "—"
    ownership = acct.get("Ownership_status__c") or "—"

    desc = acct.get("Description") or ""
    if len(desc) > 200:
        desc = desc[:197] + "..."

    website = acct.get("Website") or "—"
    linkedin = acct.get("LinkedIn_Company_Profile_URL__c") or ""

    lines = [
        f"- **Name:** {name}",
        f"- **Account ID:** {aid}",
        f"- **Region:** {region} | **Country:** {country}",
        f"- **Industry:** {industry_str}",
        f"- **Ownership:** {ownership} | **Parent:** {parent_str}",
    ]
    if desc:
        lines.append(f"- **Description:** {desc}")
    lines.append(f"- **Website:** {website}")
    if linkedin:
        lines.append(f"- **LinkedIn:** {linkedin}")

    return "\n".join(lines)


async def run(arguments: dict[str, Any]) -> str:
    """Execute the find_customer tool."""
    state.set_working_dir(arguments.get("working_directory"))

    lma_alias = _get_lma_alias()
    confirm_id = arguments.get("confirm_account_id")
    confirm_name = arguments.get("confirm_account_name")

    if confirm_id and confirm_name:
        slug = re.sub(r"[^a-z0-9]+", "-", confirm_name.lower().strip()).strip("-") or "unknown"
        acct_detail = _fetch_account_detail(confirm_id, lma_alias)
        profile = _format_account_profile(acct_detail, confirm_name, confirm_id)
        return (
            f"STATUS: CONFIRMED\n\n"
            f"## Customer Confirmed\n\n"
            f"{profile}\n"
            f"- **Folder:** customers/{slug}/\n\n"
            f"Pass account_id='{confirm_id}' and "
            f"account_name='{confirm_name}' to subsequent tools. "
            f"Carry the profile context above for downstream analysis."
        )

    customer_name = arguments.get("customer_name")
    if not customer_name:
        return (
            "STATUS: MISSING_INPUT\n\n"
            "Provide either `customer_name` to search, or "
            "`confirm_account_id` + `confirm_account_name` to confirm."
        )

    results = _soql_search(customer_name, lma_alias)
    method = "SOQL LIKE"

    if not results:
        results = _sosl_search(customer_name, lma_alias)
        method = "SOSL (fallback)"

    if not results:
        return (
            "STATUS: NO_RESULTS\n\n"
            f"- **Search term:** {customer_name}\n"
            f"- **Method:** {method}\n"
            f"- **Matches:** 0\n\n"
            "No accounts found. Try a shorter or different search term."
        )

    lines = [
        "STATUS: READY\n",
        f"- **Search term:** {customer_name}",
        f"- **Method:** {method}",
        f"- **Matches:** {len(results)}\n",
    ]

    lines.append("| # | Account Name | Type | Region | Industry | Account ID |")
    lines.append("|---|-------------|------|--------|----------|------------|")
    for i, acct in enumerate(results, 1):
        aid = acct.get("Id", "")
        name = acct.get("Name", "")
        atype = acct.get("Type") or "—"
        region = acct.get("Region__c") or "—"
        industry = acct.get("Industry") or "—"
        lines.append(f"| {i} | {name} | {atype} | {region} | {industry} | {aid} |")

    if len(results) >= 25:
        lines.append(
            "\n*Results capped at 25. Try a more specific search term "
            "to narrow down.*"
        )

    return "\n".join(lines)
