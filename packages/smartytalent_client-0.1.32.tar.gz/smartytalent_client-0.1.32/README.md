# smartytalent-client

[![PyPI version](https://img.shields.io/pypi/v/smartytalent-client.svg)](https://pypi.org/project/smartytalent-client/)
[![Python versions](https://img.shields.io/pypi/pyversions/smartytalent-client.svg)](https://pypi.org/project/smartytalent-client/)
[![Downloads](https://img.shields.io/pypi/dm/smartytalent-client.svg)](https://pypi.org/project/smartytalent-client/)

Python client for the **SmartyTalent** recruitment API, auto-generated from the OpenAPI spec using [`openapi-generator-cli`](https://openapi-generator.tech/) with the `python` template.

Fully typed with [Pydantic v2](https://docs.pydantic.dev/) models. Requires Python 3.9+.

## Install

```bash
pip install smartytalent-client
```

## Quick start

```python
from smartytalent_client import ApiClient, Configuration
from smartytalent_client.api import TenantsApi

config = Configuration(
    host="https://api.smartytalent.example.com",
    access_token="<your-access-token>",
)

with ApiClient(config) as client:
    tenants_api = TenantsApi(client)
    tenants = tenants_api.list_tenants(filter_status="active")
    for t in tenants:
        print(t.id, t.name)
```

## Authentication

The API uses **Bearer token** auth. Pass the raw token (no `Bearer ` prefix) as `access_token`:

```python
config = Configuration(
    host="https://api.smartytalent.example.com",
    access_token=access_token,
)
```

## Async usage

Each API method has an `_async` variant built on `asyncio`:

```python
import asyncio
from smartytalent_client import ApiClient, Configuration
from smartytalent_client.api import TenantsApi

async def main():
    config = Configuration(host="...", access_token="...")
    async with ApiClient(config) as client:
        api = TenantsApi(client)
        tenants = await api.list_tenants_async(filter_status="active")
        print(tenants)

asyncio.run(main())
```

## API surface

The client exposes one class per API tag, importable from `smartytalent_client.api`:

`ActionsApi`, `AdsApi`, `ApikeysApi`, `AssessmentsApi`, `BrowsersApi`, `CallsApi`, `CandidatesApi`, `ChatsApi`, `ConversationsApi`, `EmailsApi`, `FilesApi`, `FindersApi`, `FormsApi`, `JobsApi`, `LinksApi`, `MeetingsApi`, `NotesApi`, `NotificationsApi`, `OperationsApi`, `PersonasApi`, `ReportsApi`, `RolesApi`, `RunsApi`, `TalentsApi`, `TenantsApi`, `TranslationsApi`, `TriggersApi`, `UsersApi`, `WebhooksApi`, `WorkflowsApi`.

All request/response DTOs are Pydantic models in `smartytalent_client.models`.

## Configuration options

`Configuration` accepts:

| Option             | Type                          | Description                                   |
| ------------------ | ----------------------------- | --------------------------------------------- |
| `host`             | `str`                         | API base URL                                  |
| `access_token`     | `str`                         | OAuth2 bearer token                           |
| `api_key`          | `dict[str, str]`              | Header-based API keys (by security scheme)    |
| `username` / `password` | `str`                    | HTTP basic auth                               |
| `verify_ssl`       | `bool`                        | Toggle TLS verification (default `True`)      |
| `ssl_ca_cert`      | `str`                         | Path to a custom CA bundle                    |
| `proxy`            | `str`                         | HTTP/HTTPS proxy URL                          |
| `retries`          | `int`                         | Retry count for transient failures            |
| `connection_pool_maxsize` | `int`                  | urllib3 pool size                             |

## Error handling

Non-2xx responses raise subclasses of `smartytalent_client.ApiException`:

```python
from smartytalent_client import ApiException
from smartytalent_client.exceptions import NotFoundException, UnauthorizedException

try:
    tenants_api.get_tenant(id="missing-id")
except NotFoundException:
    ...
except UnauthorizedException:
    ...
except ApiException as e:
    print(e.status, e.reason, e.body)
```

## Type safety

Every API method returns a Pydantic model — use `.model_dump()` to serialize, `.model_validate()` to parse. IDEs with type support (VS Code / PyCharm) provide full autocompletion on request parameters and response fields.

## Versioning

This package is auto-published on every update to the OpenAPI spec. Version numbers are synchronized with the `@smartytalent/*` npm packages.

## License

Licensed under the [Apache License, Version 2.0](./LICENSE).

Copyright © 2026 SmartyTalent (SmartyMeet sp. z o.o.)
