"""Enforcement abstractions: EnforcementResult, EnforcementRule, AsyncEnforcementRule.

Only ABCs and the result dataclass. No concrete implementations.
Extracted from bpsai-framework engine.enforcement.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class EnforcementResult:
    """Result of an enforcement check."""

    passed: bool
    rule_name: str
    details: str | None = None
    severity: str = "error"  # "error", "warning", "info"


class EnforcementRule(ABC):
    """Abstract base class for enforcement rules.

    Each rule checks a specific constraint and returns a pass/fail result.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Rule identifier."""

    @abstractmethod
    def check(
        self, content: str, context: dict[str, Any] | None = None
    ) -> EnforcementResult:
        """Run the enforcement check. Returns result with pass/fail."""


class AsyncEnforcementRule(ABC):
    """Abstract base class for async enforcement rules.

    Async rules call external models for scoring.
    Same interface as EnforcementRule but with async check method.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Rule identifier."""

    @abstractmethod
    async def check(
        self, content: str, context: dict[str, Any] | None = None
    ) -> EnforcementResult:
        """Run the async enforcement check. Returns result with pass/fail."""
