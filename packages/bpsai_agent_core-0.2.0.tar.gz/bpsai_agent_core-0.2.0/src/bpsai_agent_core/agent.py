"""BaseAgent ABC -- cognitive loop for sense-plan-execute-learn agents."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from bpsai_agent_core.llm import LLMCall
from bpsai_agent_core.observation import Observation
from bpsai_agent_core.tick import Phase, PhaseResult, TickContext, TickResult
from bpsai_agent_core.transport import AsyncTransport, Transport


@dataclass
class AgentConfig:
    """Configuration for an agent instance."""

    agent_id: str
    name: str
    version: str = "0.1.0"
    skills: list[str] = field(default_factory=list)
    llm_call: LLMCall | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class BaseAgent(ABC):
    """Abstract base for cognitive-loop agents.

    Subclasses must implement sense, plan, execute, and learn.
    The default tick() method runs them in order, stopping on
    the first failed phase.
    """

    def __init__(self, config: AgentConfig) -> None:
        self._config = config
        self._transport: Transport | AsyncTransport | None = None

    @property
    def config(self) -> AgentConfig:
        return self._config

    def set_transport(self, transport: Transport | AsyncTransport) -> None:
        """Attach a transport for publishing observations."""
        self._transport = transport

    def emit(
        self, obs_type: str, payload: dict[str, Any], *, severity: str = "info",
    ) -> None:
        """Publish an observation via the transport. No-op if no transport set."""
        if self._transport is None:
            return
        obs = Observation(
            agent_name=self._config.name,
            type=obs_type,
            payload=payload,
            severity=severity,
        )
        if isinstance(self._transport, Transport):
            self._transport.publish(obs)

    async def aemit(
        self, obs_type: str, payload: dict[str, Any], *, severity: str = "info",
    ) -> None:
        """Async variant of emit. Uses apublish() if available, else sync publish()."""
        if self._transport is None:
            return
        obs = Observation(
            agent_name=self._config.name,
            type=obs_type,
            payload=payload,
            severity=severity,
        )
        if isinstance(self._transport, AsyncTransport):
            await self._transport.apublish(obs)
        elif isinstance(self._transport, Transport):
            self._transport.publish(obs)

    @abstractmethod
    async def sense(self, context: TickContext) -> PhaseResult:
        """Observe the environment."""

    @abstractmethod
    async def plan(self, context: TickContext) -> PhaseResult:
        """Decide what to do next."""

    @abstractmethod
    async def execute(self, context: TickContext) -> PhaseResult:
        """Take action."""

    @abstractmethod
    async def learn(self, context: TickContext) -> PhaseResult:
        """Update internal state from execution results."""

    async def tick(self, context: TickContext) -> TickResult:
        """Run one complete cognitive cycle. Override for custom flow."""
        results: dict[str, PhaseResult] = {}
        total_ms = 0.0

        for phase, method in [
            (Phase.SENSE, self.sense),
            (Phase.PLAN, self.plan),
            (Phase.EXECUTE, self.execute),
            (Phase.LEARN, self.learn),
        ]:
            result = await method(context)
            results[phase.value] = result
            total_ms += result.duration_ms
            if not result.passed:
                break

        return TickResult(
            tick_number=context.tick_number,
            phase_results=results,
            duration_ms=total_ms,
            events_processed=len(context.event_queue_snapshot),
        )

    def card(self) -> "AgentCard":
        """Return an AgentCard descriptor for this agent."""
        from bpsai_agent_core.card import AgentCard, AgentSkill

        skills = [
            AgentSkill(id=s, name=s, description=s)
            for s in self._config.skills
        ]
        return AgentCard(
            name=self._config.agent_id,
            description=f"{self._config.name} agent",
            version=self._config.version,
            skills=skills,
        )
