"""LLM call protocol for agent-core.

Defines the minimal interface that any LLM integration must satisfy.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class LLMCall(Protocol):
    """Protocol for LLM call implementations.

    Any callable that accepts system and user prompts and returns
    a string response satisfies this protocol.
    """

    async def __call__(self, system: str, user: str) -> str: ...
