"""Core loop runner for the agent orchestration loop.

Executes ticks through registered phase hooks. Dependencies
(cadence, event queue) are protocol-based for flexibility.
"""

from __future__ import annotations

import asyncio
import threading
import time
from datetime import datetime, timezone

from bpsai_agent_core.hooks import PhaseRegistry
from bpsai_agent_core.tick import Phase, PhaseResult, TickContext, TickResult


class LoopRunner:
    """Executes orchestration ticks through all phases in order.

    Each tick builds a TickContext and runs registered hooks
    for each Phase in enum order.
    """

    def __init__(
        self,
        registry: PhaseRegistry,
        tick_timeout_seconds: float = 300.0,
    ) -> None:
        self._registry = registry
        self._tick_timeout = tick_timeout_seconds
        self._tick_count = 0
        self._previous_result: TickResult | None = None
        self._shutdown_event = threading.Event()

    @property
    def tick_count(self) -> int:
        return self._tick_count

    def shutdown(self) -> None:
        """Signal the runner to stop after the current tick completes."""
        self._shutdown_event.set()

    async def run_tick(self) -> TickResult:
        """Execute one complete tick through all phases."""
        context = self._build_context()
        phase_results: dict[str, PhaseResult] = {}
        tick_start = time.monotonic()

        for phase in Phase:
            if self._shutdown_event.is_set():
                break
            result = await self._execute_phase(phase, context)
            phase_results[phase.value] = result

        duration_ms = (time.monotonic() - tick_start) * 1000
        tick_result = TickResult(
            tick_number=self._tick_count,
            phase_results=phase_results,
            duration_ms=round(duration_ms, 1),
            events_processed=0,
        )
        self._tick_count += 1
        self._previous_result = tick_result
        return tick_result

    async def run(self, max_ticks: int | None = None) -> None:
        """Run the loop until shutdown or max_ticks is reached."""
        while not self._shutdown_event.is_set():
            if max_ticks is not None and self._tick_count >= max_ticks:
                break
            await self.run_tick()

    def _build_context(self) -> TickContext:
        """Build a TickContext for the current tick."""
        return TickContext(
            tick_number=self._tick_count,
            timestamp=datetime.now(timezone.utc).isoformat(),
            event_queue_snapshot=[],
            state_snapshot={},
            previous_result=self._previous_result,
        )

    async def _execute_phase(
        self, phase: Phase, context: TickContext,
    ) -> PhaseResult:
        """Run all hooks for a single phase and aggregate results."""
        hooks = self._registry.get_hooks(phase)
        if not hooks:
            return PhaseResult(
                phase=phase, passed=True, findings=[], duration_ms=0.0,
            )

        all_findings: list[str] = []
        all_passed = True
        phase_start = time.monotonic()

        for hook in hooks:
            try:
                result = await asyncio.wait_for(
                    hook.execute(context),
                    timeout=self._tick_timeout,
                )
                for f in result.findings:
                    all_findings.append(f.replace("\n", " ").replace("\r", ""))
                if not result.passed:
                    all_passed = False
            except asyncio.TimeoutError:
                all_findings.append(
                    f"Hook timed out after {self._tick_timeout}s",
                )
                all_passed = False
            except Exception as exc:
                all_findings.append(
                    f"Hook raised {type(exc).__name__}: {exc}",
                )
                all_passed = False

        duration_ms = (time.monotonic() - phase_start) * 1000
        return PhaseResult(
            phase=phase,
            passed=all_passed,
            findings=all_findings,
            duration_ms=round(duration_ms, 1),
        )
