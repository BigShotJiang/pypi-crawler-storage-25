"""AgentCard dataclasses for A2A agent card structure.

Provides typed Python representations of the A2A protocol agent card
schema used for registry discovery (/.well-known/agent-card.json).

Extracted from bpsai-a2a agent_cards schema.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class AgentSkill:
    """A single skill advertised by an agent."""

    id: str
    name: str
    description: str
    tags: list[str] = field(default_factory=list)
    examples: list[str] = field(default_factory=list)


@dataclass
class AgentCapabilities:
    """Capability flags for an agent card."""

    streaming: bool = False
    pushNotifications: bool = False
    stateTransitionHistory: bool = False


@dataclass
class AgentProvider:
    """Organization that provides the agent."""

    organization: str
    url: str = ""


@dataclass
class AgentCard:
    """A2A-compatible agent card.

    Serializes to the JSON structure expected by A2A registries
    and can be restored via :meth:`from_dict`.
    """

    name: str
    description: str
    version: str
    skills: list[AgentSkill] = field(default_factory=list)
    capabilities: AgentCapabilities = field(default_factory=AgentCapabilities)
    provider: AgentProvider = field(
        default_factory=lambda: AgentProvider(organization="BPS AI"),
    )
    url: str = ""
    defaultInputModes: list[str] = field(
        default_factory=lambda: ["text/plain"],
    )
    defaultOutputModes: list[str] = field(
        default_factory=lambda: ["text/plain"],
    )

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable dict matching the A2A schema."""
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "url": self.url,
            "skills": [
                {
                    "id": s.id,
                    "name": s.name,
                    "description": s.description,
                    "tags": list(s.tags),
                    "examples": list(s.examples),
                }
                for s in self.skills
            ],
            "capabilities": {
                "streaming": self.capabilities.streaming,
                "pushNotifications": self.capabilities.pushNotifications,
                "stateTransitionHistory": self.capabilities.stateTransitionHistory,
            },
            "provider": {
                "organization": self.provider.organization,
                "url": self.provider.url,
            },
            "defaultInputModes": list(self.defaultInputModes),
            "defaultOutputModes": list(self.defaultOutputModes),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AgentCard:
        """Construct an AgentCard from a dict (e.g. parsed JSON)."""
        skills_data = data.get("skills", [])
        skills = [
            AgentSkill(
                id=s["id"],
                name=s["name"],
                description=s["description"],
                tags=s.get("tags", []),
                examples=s.get("examples", []),
            )
            for s in skills_data
        ]

        caps_data = data.get("capabilities", {})
        capabilities = AgentCapabilities(
            streaming=caps_data.get("streaming", False),
            pushNotifications=caps_data.get("pushNotifications", False),
            stateTransitionHistory=caps_data.get("stateTransitionHistory", False),
        )

        prov_data = data.get("provider", {})
        provider = AgentProvider(
            organization=prov_data.get("organization", "BPS AI"),
            url=prov_data.get("url", ""),
        )

        return cls(
            name=data["name"],
            description=data["description"],
            version=data["version"],
            url=data.get("url", ""),
            skills=skills,
            capabilities=capabilities,
            provider=provider,
            defaultInputModes=data.get("defaultInputModes", ["text/plain"]),
            defaultOutputModes=data.get("defaultOutputModes", ["text/plain"]),
        )
