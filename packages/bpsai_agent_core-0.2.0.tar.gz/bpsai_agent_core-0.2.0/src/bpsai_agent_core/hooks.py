"""PhaseHook protocol and PhaseRegistry for orchestration loop phases.

PhaseHook defines the structural contract for hook instances that execute
within a specific orchestration Phase.  PhaseRegistry organizes hooks by
phase and returns them sorted by priority (ascending) on retrieval.

Extracted from bpsai-framework engine.orchestration.phase_registry.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from bpsai_agent_core.tick import Phase, PhaseResult, TickContext


@runtime_checkable
class PhaseHook(Protocol):
    """Structural protocol for orchestration phase hooks.

    Implementors must expose ``phase``, ``priority``, and an async
    ``execute`` method that receives a :class:`TickContext` and returns
    a :class:`PhaseResult`.
    """

    @property
    def phase(self) -> Phase: ...

    @property
    def priority(self) -> int: ...

    async def execute(self, context: TickContext) -> PhaseResult: ...


class PhaseRegistry:
    """Registry of :class:`PhaseHook` instances keyed by :class:`Phase`.

    Stores *instances* keyed by the ``Phase`` enum.  Hooks are returned
    sorted by priority ascending (lower number = higher priority).
    """

    def __init__(self) -> None:
        self._hooks: dict[Phase, list[PhaseHook]] = {}

    def register(self, hook: PhaseHook) -> None:
        """Register a hook after validating PhaseHook protocol conformance.

        Raises:
            TypeError: If *hook* does not satisfy the PhaseHook protocol.
        """
        if not isinstance(hook, PhaseHook):
            raise TypeError(
                f"Expected PhaseHook, got {type(hook).__name__}"
            )
        phase = hook.phase
        if phase not in self._hooks:
            self._hooks[phase] = []
        self._hooks[phase].append(hook)

    def get_hooks(self, phase: Phase) -> list[PhaseHook]:
        """Return hooks for *phase* sorted by priority ascending.

        Returns an empty list when no hooks are registered for the phase.
        """
        hooks = self._hooks.get(phase, [])
        return sorted(hooks, key=lambda h: h.priority)

    def clear(self) -> None:
        """Remove all registered hooks."""
        self._hooks.clear()

    def count(self) -> int:
        """Return total number of registered hooks across all phases."""
        return sum(len(hooks) for hooks in self._hooks.values())
