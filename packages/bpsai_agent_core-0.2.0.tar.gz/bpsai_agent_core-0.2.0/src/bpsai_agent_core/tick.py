"""Tick lifecycle types: Phase, PhaseResult, TickContext, TickResult.

These dataclasses flow through the agent orchestration loop.
Extracted from bpsai-framework engine.orchestration.models with
DISPATCH renamed to EXECUTE.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Phase(Enum):
    """Orchestration loop phases.

    Member ORDER is load-bearing -- the loop iterates ``list(Phase)``.
    """

    SENSE = "sense"
    PLAN = "plan"
    EXECUTE = "execute"
    ENFORCE = "enforce"
    LEARN = "learn"


@dataclass
class PhaseResult:
    """Outcome of a single phase execution within one tick."""

    phase: Phase
    passed: bool
    findings: list[str]
    duration_ms: float

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable dict."""
        return {
            "phase": self.phase.value,
            "passed": self.passed,
            "findings": list(self.findings),
            "duration_ms": self.duration_ms,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PhaseResult:
        """Construct from a dict (e.g. parsed JSON)."""
        return cls(
            phase=Phase(data["phase"]),
            passed=bool(data["passed"]),
            findings=[str(f) for f in data["findings"]],
            duration_ms=max(0.0, float(data["duration_ms"])),
        )


@dataclass
class TickResult:
    """Aggregate result of one complete tick through all phases."""

    tick_number: int
    phase_results: dict[str, PhaseResult]
    duration_ms: float
    events_processed: int

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable dict."""
        return {
            "tick_number": self.tick_number,
            "phase_results": {
                key: pr.to_dict() for key, pr in self.phase_results.items()
            },
            "duration_ms": self.duration_ms,
            "events_processed": self.events_processed,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TickResult:
        """Construct from a dict (e.g. parsed JSON)."""
        return cls(
            tick_number=int(data["tick_number"]),
            phase_results={
                str(key): PhaseResult.from_dict(pr_data)
                for key, pr_data in data["phase_results"].items()
            },
            duration_ms=max(0.0, float(data["duration_ms"])),
            events_processed=int(data["events_processed"]),
        )


@dataclass
class TickContext:
    """Input context supplied to the orchestration loop for one tick."""

    tick_number: int
    timestamp: str
    event_queue_snapshot: list[dict[str, Any]]
    state_snapshot: dict[str, Any]
    previous_result: TickResult | None = None

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable dict."""
        return {
            "tick_number": self.tick_number,
            "timestamp": self.timestamp,
            "event_queue_snapshot": list(self.event_queue_snapshot),
            "state_snapshot": dict(self.state_snapshot),
            "previous_result": (
                self.previous_result.to_dict()
                if self.previous_result is not None
                else None
            ),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TickContext:
        """Construct from a dict (e.g. parsed JSON)."""
        prev_data = data.get("previous_result")
        return cls(
            tick_number=int(data["tick_number"]),
            timestamp=str(data["timestamp"]),
            event_queue_snapshot=list(data["event_queue_snapshot"]),
            state_snapshot=dict(data["state_snapshot"]),
            previous_result=(
                TickResult.from_dict(prev_data)
                if prev_data is not None
                else None
            ),
        )
