"""Transport protocols for publishing observations.

Transport (sync) and AsyncTransport (async) are runtime-checkable protocols.
Any class with a matching publish/apublish method satisfies the protocol
without explicit inheritance.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from bpsai_agent_core.observation import Observation


@runtime_checkable
class Transport(Protocol):
    """Sync transport: publishes observations."""

    def publish(self, observation: Observation) -> None: ...


@runtime_checkable
class AsyncTransport(Protocol):
    """Async transport: publishes observations asynchronously."""

    async def apublish(self, observation: Observation) -> None: ...
