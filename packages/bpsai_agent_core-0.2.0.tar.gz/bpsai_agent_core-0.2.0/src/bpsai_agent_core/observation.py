"""Observation -- typed data emitted by agents for cross-cutting concerns.

An Observation carries an agent name, observation type, arbitrary payload,
auto-generated UTC timestamp, and severity level.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class Observation:
    """A single observation emitted by an agent."""

    agent_name: str
    type: str
    payload: dict[str, Any]
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    severity: str = "info"
