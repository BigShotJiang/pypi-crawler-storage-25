"""FileTransport — appends observations as JSONL to a local file.

Satisfies both Transport (sync) and AsyncTransport (async) protocols.
Always opens in append mode; never overwrites existing data.
Creates parent directories automatically on first write.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from datetime import datetime
from pathlib import Path

from bpsai_agent_core.observation import Observation


class FileTransport:
    """Append-only JSONL file transport for observations."""

    def __init__(self, path: Path) -> None:
        self._path = path

    def publish(self, observation: Observation) -> None:
        """Write one JSON line for the observation (sync)."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(_serialize(observation))
        with self._path.open("a") as f:
            f.write(line + "\n")

    async def apublish(self, observation: Observation) -> None:
        """Write one JSON line for the observation (async, delegates to sync)."""
        self.publish(observation)


def _serialize(obs: Observation) -> dict:
    """Convert an Observation to a JSON-safe dict."""
    data = asdict(obs)
    if isinstance(data.get("timestamp"), datetime):
        data["timestamp"] = data["timestamp"].isoformat()
    return data
