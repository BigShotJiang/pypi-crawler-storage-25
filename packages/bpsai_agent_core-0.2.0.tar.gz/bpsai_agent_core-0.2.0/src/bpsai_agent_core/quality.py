"""QualityProfile -- SQLite-backed quality observation store.

Generalized from the BeliefEngine pattern: stores quality observations
with confidence scores, reinforcement, decay, and pruning. No LLM
reflection -- that belongs in the Lounge layer.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from pathlib import Path


@dataclass
class QualityObservation:
    """A single quality observation with confidence tracking."""

    id: int
    observation: str
    confidence: float
    reinforcement_count: int
    created_at: str
    updated_at: str


class QualityProfile:
    """SQLite-backed quality profile with confidence decay."""

    def __init__(self, db_path: Path | str = ":memory:") -> None:
        self._conn = sqlite3.connect(str(db_path))
        self._conn.row_factory = sqlite3.Row
        self._create_table()

    def _create_table(self) -> None:
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS quality_observations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                observation TEXT NOT NULL,
                confidence REAL NOT NULL DEFAULT 1.0,
                reinforcement_count INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT (datetime('now')),
                updated_at TEXT NOT NULL DEFAULT (datetime('now'))
            )
        """)
        self._conn.commit()

    def record(self, observation: str, confidence: float = 1.0) -> int:
        """Record a new quality observation. Returns the observation ID."""
        clamped = min(max(confidence, 0.0), 1.0)
        cursor = self._conn.execute(
            "INSERT INTO quality_observations (observation, confidence) VALUES (?, ?)",
            (observation, clamped),
        )
        self._conn.commit()
        return cursor.lastrowid  # type: ignore[return-value]

    def get_active(
        self, limit: int = 5, min_confidence: float = 0.1
    ) -> list[QualityObservation]:
        """Get active observations above minimum confidence, ordered by confidence desc."""
        rows = self._conn.execute(
            "SELECT * FROM quality_observations "
            "WHERE confidence >= ? ORDER BY confidence DESC LIMIT ?",
            (min_confidence, limit),
        ).fetchall()
        return [QualityObservation(**dict(r)) for r in rows]

    def reinforce(self, observation_id: int) -> None:
        """Reinforce an observation -- boost confidence with diminishing returns."""
        row = self._conn.execute(
            "SELECT confidence, reinforcement_count "
            "FROM quality_observations WHERE id = ?",
            (observation_id,),
        ).fetchone()
        if not row:
            return
        boost = 0.1 / (1 + row["reinforcement_count"])
        new_confidence = min(row["confidence"] + boost, 1.0)
        self._conn.execute(
            "UPDATE quality_observations "
            "SET confidence = ?, reinforcement_count = reinforcement_count + 1, "
            "updated_at = datetime('now') WHERE id = ?",
            (new_confidence, observation_id),
        )
        self._conn.commit()

    def decay_stale(self, days: int = 7) -> int:
        """Apply 10% decay to observations not updated in `days` days.

        Returns count of observations decayed.
        """
        cursor = self._conn.execute(
            "UPDATE quality_observations "
            "SET confidence = confidence * 0.9, updated_at = datetime('now') "
            "WHERE julianday('now') - julianday(updated_at) > ?",
            (days,),
        )
        self._conn.commit()
        return cursor.rowcount

    def prune(self, threshold: float = 0.1) -> int:
        """Remove observations below confidence threshold. Returns count pruned."""
        cursor = self._conn.execute(
            "DELETE FROM quality_observations WHERE confidence < ?",
            (threshold,),
        )
        self._conn.commit()
        return cursor.rowcount

    def as_prompt_context(self) -> str:
        """Format active observations for inclusion in system prompts."""
        active = self.get_active(limit=10)
        if not active:
            return "No quality observations recorded."
        lines = [
            f"- {obs.observation} (confidence: {obs.confidence:.2f})"
            for obs in active
        ]
        return "Quality observations:\n" + "\n".join(lines)

    def close(self) -> None:
        """Close the database connection."""
        self._conn.close()
