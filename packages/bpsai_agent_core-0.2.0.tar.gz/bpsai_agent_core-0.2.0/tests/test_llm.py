"""Tests for LLMCall protocol."""

from __future__ import annotations

import pytest


class TestLLMCallProtocol:
    """LLMCall protocol tests."""

    def test_protocol_is_runtime_checkable(self) -> None:
        from bpsai_agent_core.llm import LLMCall

        assert hasattr(LLMCall, "__protocol_attrs__") or hasattr(
            LLMCall, "__callable__"
        )
        # runtime_checkable protocols support isinstance checks
        assert isinstance(LLMCall, type)

    def test_conforming_class_is_instance(self) -> None:
        from bpsai_agent_core.llm import LLMCall

        class MyLLM:
            async def __call__(self, system: str, user: str) -> str:
                return "response"

        assert isinstance(MyLLM(), LLMCall)

    def test_non_conforming_class_is_not_instance(self) -> None:
        from bpsai_agent_core.llm import LLMCall

        class NotAnLLM:
            def hello(self) -> str:
                return "hi"

        assert not isinstance(NotAnLLM(), LLMCall)

    @pytest.mark.asyncio
    async def test_conforming_callable_works(self) -> None:
        from bpsai_agent_core.llm import LLMCall

        class EchoLLM:
            async def __call__(self, system: str, user: str) -> str:
                return f"{system}: {user}"

        llm: LLMCall = EchoLLM()
        result = await llm("sys", "usr")
        assert result == "sys: usr"
