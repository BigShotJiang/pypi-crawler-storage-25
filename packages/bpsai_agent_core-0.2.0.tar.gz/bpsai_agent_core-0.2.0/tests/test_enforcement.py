"""Tests for enforcement abstractions: EnforcementResult, EnforcementRule, AsyncEnforcementRule."""

from __future__ import annotations

import pytest


class TestEnforcementResult:
    """EnforcementResult dataclass tests."""

    def test_construction_minimal(self) -> None:
        from bpsai_agent_core.enforcement import EnforcementResult

        er = EnforcementResult(passed=True, rule_name="test_rule")
        assert er.passed is True
        assert er.rule_name == "test_rule"
        assert er.details is None
        assert er.severity == "error"

    def test_construction_full(self) -> None:
        from bpsai_agent_core.enforcement import EnforcementResult

        er = EnforcementResult(
            passed=False,
            rule_name="brand_check",
            details="Brand name mismatch",
            severity="warning",
        )
        assert er.passed is False
        assert er.details == "Brand name mismatch"
        assert er.severity == "warning"


class TestEnforcementRule:
    """EnforcementRule ABC tests."""

    def test_cannot_instantiate_directly(self) -> None:
        from bpsai_agent_core.enforcement import EnforcementRule

        with pytest.raises(TypeError):
            EnforcementRule()  # type: ignore[abstract]

    def test_concrete_subclass_works(self) -> None:
        from bpsai_agent_core.enforcement import EnforcementResult, EnforcementRule

        class AlwaysPass(EnforcementRule):
            @property
            def name(self) -> str:
                return "always_pass"

            def check(self, content: str, context: dict | None = None) -> EnforcementResult:
                return EnforcementResult(passed=True, rule_name=self.name)

        rule = AlwaysPass()
        assert rule.name == "always_pass"
        result = rule.check("hello")
        assert result.passed is True

    def test_subclass_must_implement_name_and_check(self) -> None:
        from bpsai_agent_core.enforcement import EnforcementRule

        class Incomplete(EnforcementRule):
            pass

        with pytest.raises(TypeError):
            Incomplete()  # type: ignore[abstract]


class TestAsyncEnforcementRule:
    """AsyncEnforcementRule ABC tests."""

    def test_cannot_instantiate_directly(self) -> None:
        from bpsai_agent_core.enforcement import AsyncEnforcementRule

        with pytest.raises(TypeError):
            AsyncEnforcementRule()  # type: ignore[abstract]

    @pytest.mark.asyncio
    async def test_concrete_async_subclass_works(self) -> None:
        from bpsai_agent_core.enforcement import AsyncEnforcementRule, EnforcementResult

        class AsyncAlwaysPass(AsyncEnforcementRule):
            @property
            def name(self) -> str:
                return "async_pass"

            async def check(
                self, content: str, context: dict | None = None
            ) -> EnforcementResult:
                return EnforcementResult(passed=True, rule_name=self.name)

        rule = AsyncAlwaysPass()
        result = await rule.check("test content")
        assert result.passed is True
        assert result.rule_name == "async_pass"
