"""Integration test — full agent lifecycle from package public API."""

import pytest

from bpsai_agent_core import (
    AgentCard,
    AgentConfig,
    BaseAgent,
    LoopRunner,
    Phase,
    PhaseHook,
    PhaseRegistry,
    PhaseResult,
    QualityProfile,
    TickContext,
    TickResult,
)


class EchoAgent(BaseAgent):
    """Minimal concrete agent for integration testing."""

    async def sense(self, context: TickContext) -> PhaseResult:
        return PhaseResult(phase=Phase.SENSE, passed=True, findings=["sensed"], duration_ms=1.0)

    async def plan(self, context: TickContext) -> PhaseResult:
        return PhaseResult(phase=Phase.PLAN, passed=True, findings=["planned"], duration_ms=1.0)

    async def execute(self, context: TickContext) -> PhaseResult:
        return PhaseResult(phase=Phase.EXECUTE, passed=True, findings=["executed"], duration_ms=1.0)

    async def learn(self, context: TickContext) -> PhaseResult:
        return PhaseResult(phase=Phase.LEARN, passed=True, findings=["learned"], duration_ms=1.0)


class TestFullLifecycle:
    """End-to-end: create agent → run tick → check results → generate card."""

    @pytest.mark.asyncio
    async def test_agent_tick_lifecycle(self):
        config = AgentConfig(agent_id="bpsai-echo", name="Echo", version="0.1.0")
        agent = EchoAgent(config)

        context = TickContext(
            tick_number=0,
            timestamp="2026-03-30T00:00:00Z",
            event_queue_snapshot=[],
            state_snapshot={},
        )
        result = await agent.tick(context)

        assert isinstance(result, TickResult)
        assert all(pr.passed for pr in result.phase_results.values())
        assert len(result.phase_results) == 4

    @pytest.mark.asyncio
    async def test_agent_card_from_config(self):
        config = AgentConfig(
            agent_id="bpsai-echo",
            name="Echo",
            version="1.0.0",
            skills=["testing", "echoing"],
        )
        agent = EchoAgent(config)
        card = agent.card()

        assert isinstance(card, AgentCard)
        assert card.name == "bpsai-echo"
        assert card.version == "1.0.0"

    @pytest.mark.asyncio
    async def test_agent_card_serializes(self):
        config = AgentConfig(agent_id="bpsai-echo", name="Echo")
        agent = EchoAgent(config)
        card = agent.card()
        data = card.to_dict()

        assert isinstance(data, dict)
        assert data["name"] == "bpsai-echo"
        round_tripped = AgentCard.from_dict(data)
        assert round_tripped.name == card.name


class TestQualityProfileLifecycle:
    """Record → reinforce → decay → prune → prompt context."""

    def test_full_quality_lifecycle(self):
        qp = QualityProfile()
        try:
            obs_id = qp.record("Agent produces accurate reviews", confidence=0.8)
            assert obs_id == 1

            qp.reinforce(obs_id)
            active = qp.get_active(limit=1)
            assert active[0].confidence > 0.8

            context = qp.as_prompt_context()
            assert "accurate reviews" in context

            qp.record("Noisy finding", confidence=0.05)
            pruned = qp.prune(threshold=0.1)
            assert pruned == 1
        finally:
            qp.close()


class TestLoopRunnerWithHooks:
    """LoopRunner + PhaseRegistry + hooks end-to-end."""

    @pytest.mark.asyncio
    async def test_loop_with_registered_hooks(self):
        registry = PhaseRegistry()
        execution_log = []

        class LoggingHook:
            def __init__(self, phase: Phase):
                self._phase = phase

            @property
            def phase(self) -> Phase:
                return self._phase

            @property
            def priority(self) -> int:
                return 10

            async def execute(self, context: TickContext) -> PhaseResult:
                execution_log.append(self._phase.value)
                return PhaseResult(phase=self._phase, passed=True, findings=[], duration_ms=0.0)

        for phase in [Phase.SENSE, Phase.PLAN, Phase.EXECUTE, Phase.LEARN]:
            registry.register(LoggingHook(phase))

        runner = LoopRunner(registry=registry)
        await runner.run(max_ticks=2)

        assert runner.tick_count == 2
        assert execution_log == [
            "sense", "plan", "execute", "learn",
            "sense", "plan", "execute", "learn",
        ]


class TestPublicAPIImports:
    """Verify all public types are importable from the top-level package."""

    def test_all_exports_importable(self):
        import bpsai_agent_core

        expected = [
            "AgentConfig", "BaseAgent",
            "AgentCard", "AgentSkill", "AgentCapabilities", "AgentProvider",
            "EnforcementRule", "AsyncEnforcementRule", "EnforcementResult",
            "LLMCall",
            "LoopRunner",
            "Phase", "PhaseResult", "TickContext", "TickResult",
            "PhaseHook", "PhaseRegistry",
            "QualityProfile", "QualityObservation",
        ]
        for name in expected:
            assert hasattr(bpsai_agent_core, name), f"Missing export: {name}"
