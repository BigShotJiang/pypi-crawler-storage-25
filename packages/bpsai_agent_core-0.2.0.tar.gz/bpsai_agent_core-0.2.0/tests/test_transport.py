"""Tests for Transport and AsyncTransport protocols."""

from __future__ import annotations

from typing import runtime_checkable

import pytest


class TestTransportProtocol:
    """Transport sync protocol tests."""

    def test_is_runtime_checkable(self) -> None:
        from bpsai_agent_core.transport import Transport

        assert getattr(Transport, "__protocol_attrs__", None) is not None or hasattr(
            Transport, "__callable_proto_members_only__"
        )
        # runtime_checkable protocols support isinstance checks
        assert isinstance(Transport, type)

    def test_conforming_class_is_instance(self) -> None:
        from bpsai_agent_core.observation import Observation
        from bpsai_agent_core.transport import Transport

        class MyTransport:
            def publish(self, observation: Observation) -> None:
                pass

        assert isinstance(MyTransport(), Transport)

    def test_non_conforming_class_is_not_instance(self) -> None:
        from bpsai_agent_core.transport import Transport

        class NotATransport:
            def send(self, data: str) -> None:
                pass

        assert not isinstance(NotATransport(), Transport)

    def test_publish_can_be_called(self) -> None:
        from bpsai_agent_core.observation import Observation
        from bpsai_agent_core.transport import Transport

        published: list[Observation] = []

        class Collector:
            def publish(self, observation: Observation) -> None:
                published.append(observation)

        t: Transport = Collector()  # type: ignore[assignment]
        obs = Observation(agent_name="a", type="t", payload={})
        t.publish(obs)
        assert len(published) == 1
        assert published[0] is obs


class TestAsyncTransportProtocol:
    """AsyncTransport async protocol tests."""

    def test_is_runtime_checkable(self) -> None:
        from bpsai_agent_core.transport import AsyncTransport

        assert isinstance(AsyncTransport, type)

    def test_conforming_class_is_instance(self) -> None:
        from bpsai_agent_core.observation import Observation
        from bpsai_agent_core.transport import AsyncTransport

        class MyAsyncTransport:
            async def apublish(self, observation: Observation) -> None:
                pass

        assert isinstance(MyAsyncTransport(), AsyncTransport)

    def test_non_conforming_class_is_not_instance(self) -> None:
        from bpsai_agent_core.transport import AsyncTransport

        class NotAsync:
            def publish(self, data: str) -> None:
                pass

        assert not isinstance(NotAsync(), AsyncTransport)

    @pytest.mark.asyncio
    async def test_apublish_can_be_called(self) -> None:
        from bpsai_agent_core.observation import Observation
        from bpsai_agent_core.transport import AsyncTransport

        published: list[Observation] = []

        class AsyncCollector:
            async def apublish(self, observation: Observation) -> None:
                published.append(observation)

        t: AsyncTransport = AsyncCollector()  # type: ignore[assignment]
        obs = Observation(agent_name="a", type="t", payload={})
        await t.apublish(obs)
        assert len(published) == 1
        assert published[0] is obs
