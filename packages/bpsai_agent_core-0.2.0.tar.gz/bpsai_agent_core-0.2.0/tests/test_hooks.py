"""Tests for PhaseHook protocol and PhaseRegistry."""

from __future__ import annotations

import pytest

from bpsai_agent_core.hooks import PhaseHook, PhaseRegistry
from bpsai_agent_core.tick import Phase, PhaseResult, TickContext


# ---------------------------------------------------------------------------
# Concrete hook for testing
# ---------------------------------------------------------------------------

class _SampleHook:
    """Minimal concrete hook satisfying PhaseHook protocol."""

    def __init__(self, phase: Phase, priority: int = 0) -> None:
        self._phase = phase
        self._priority = priority

    @property
    def phase(self) -> Phase:
        return self._phase

    @property
    def priority(self) -> int:
        return self._priority

    async def execute(self, context: TickContext) -> PhaseResult:
        return PhaseResult(
            phase=self._phase,
            passed=True,
            findings=[],
            duration_ms=0.0,
        )


class _NotAHook:
    """Object that does NOT satisfy PhaseHook protocol."""

    pass


# ---------------------------------------------------------------------------
# PhaseHook protocol conformance
# ---------------------------------------------------------------------------

class TestPhaseHookProtocol:
    """PhaseHook is a runtime-checkable Protocol."""

    def test_concrete_hook_satisfies_protocol(self) -> None:
        hook = _SampleHook(Phase.SENSE)
        assert isinstance(hook, PhaseHook)

    def test_non_conforming_object_rejected(self) -> None:
        obj = _NotAHook()
        assert not isinstance(obj, PhaseHook)


# ---------------------------------------------------------------------------
# PhaseRegistry
# ---------------------------------------------------------------------------

class TestPhaseRegistry:
    """PhaseRegistry stores hooks by phase with priority ordering."""

    def test_register_and_retrieve_single_hook(self) -> None:
        reg = PhaseRegistry()
        hook = _SampleHook(Phase.SENSE)
        reg.register(hook)
        assert reg.get_hooks(Phase.SENSE) == [hook]

    def test_empty_phase_returns_empty_list(self) -> None:
        reg = PhaseRegistry()
        assert reg.get_hooks(Phase.PLAN) == []

    def test_priority_ordering_lower_number_first(self) -> None:
        reg = PhaseRegistry()
        high = _SampleHook(Phase.EXECUTE, priority=10)
        low = _SampleHook(Phase.EXECUTE, priority=1)
        mid = _SampleHook(Phase.EXECUTE, priority=5)
        reg.register(high)
        reg.register(low)
        reg.register(mid)
        result = reg.get_hooks(Phase.EXECUTE)
        assert result == [low, mid, high]

    def test_multiple_hooks_per_phase(self) -> None:
        reg = PhaseRegistry()
        h1 = _SampleHook(Phase.LEARN, priority=0)
        h2 = _SampleHook(Phase.LEARN, priority=0)
        reg.register(h1)
        reg.register(h2)
        assert len(reg.get_hooks(Phase.LEARN)) == 2

    def test_register_rejects_non_hook(self) -> None:
        reg = PhaseRegistry()
        with pytest.raises(TypeError, match="Expected PhaseHook"):
            reg.register(_NotAHook())  # type: ignore[arg-type]

    def test_hooks_isolated_by_phase(self) -> None:
        reg = PhaseRegistry()
        sense_hook = _SampleHook(Phase.SENSE)
        plan_hook = _SampleHook(Phase.PLAN)
        reg.register(sense_hook)
        reg.register(plan_hook)
        assert reg.get_hooks(Phase.SENSE) == [sense_hook]
        assert reg.get_hooks(Phase.PLAN) == [plan_hook]

    def test_clear_removes_all_hooks(self) -> None:
        reg = PhaseRegistry()
        reg.register(_SampleHook(Phase.SENSE))
        reg.register(_SampleHook(Phase.PLAN))
        reg.clear()
        assert reg.get_hooks(Phase.SENSE) == []
        assert reg.count() == 0

    def test_count_returns_total(self) -> None:
        reg = PhaseRegistry()
        reg.register(_SampleHook(Phase.SENSE))
        reg.register(_SampleHook(Phase.PLAN))
        reg.register(_SampleHook(Phase.PLAN))
        assert reg.count() == 3
