"""Tests for Observation dataclass."""

from __future__ import annotations

from datetime import datetime, timezone


class TestObservation:
    """Observation dataclass tests."""

    def test_construction_minimal(self) -> None:
        from bpsai_agent_core.observation import Observation

        obs = Observation(agent_name="scout", type="metric", payload={"cpu": 0.8})
        assert obs.agent_name == "scout"
        assert obs.type == "metric"
        assert obs.payload == {"cpu": 0.8}
        assert obs.severity == "info"
        assert obs.timestamp is not None

    def test_auto_timestamp(self) -> None:
        from bpsai_agent_core.observation import Observation

        before = datetime.now(timezone.utc)
        obs = Observation(agent_name="a", type="event", payload={})
        after = datetime.now(timezone.utc)
        assert before <= obs.timestamp <= after

    def test_custom_severity(self) -> None:
        from bpsai_agent_core.observation import Observation

        obs = Observation(
            agent_name="guard",
            type="alert",
            payload={"msg": "breach"},
            severity="critical",
        )
        assert obs.severity == "critical"

    def test_custom_timestamp(self) -> None:
        from bpsai_agent_core.observation import Observation

        ts = datetime(2026, 1, 1, tzinfo=timezone.utc)
        obs = Observation(
            agent_name="a", type="event", payload={}, timestamp=ts
        )
        assert obs.timestamp == ts

    def test_payload_is_dict(self) -> None:
        from bpsai_agent_core.observation import Observation

        obs = Observation(agent_name="a", type="t", payload={"k": [1, 2, 3]})
        assert isinstance(obs.payload, dict)

    def test_is_dataclass(self) -> None:
        from dataclasses import fields

        from bpsai_agent_core.observation import Observation

        field_names = {f.name for f in fields(Observation)}
        assert field_names == {"agent_name", "type", "payload", "timestamp", "severity"}
