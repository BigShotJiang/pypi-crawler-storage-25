"""Tests for FileTransport — JSONL file-based observation transport."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest

from bpsai_agent_core.observation import Observation


class TestFileTransportProtocolConformance:
    """FileTransport satisfies both Transport and AsyncTransport protocols."""

    def test_satisfies_transport_protocol(self) -> None:
        from bpsai_agent_core.file_transport import FileTransport
        from bpsai_agent_core.transport import Transport

        ft = FileTransport(path=Path("/tmp/test.jsonl"))
        assert isinstance(ft, Transport)

    def test_satisfies_async_transport_protocol(self) -> None:
        from bpsai_agent_core.file_transport import FileTransport
        from bpsai_agent_core.transport import AsyncTransport

        ft = FileTransport(path=Path("/tmp/test.jsonl"))
        assert isinstance(ft, AsyncTransport)


class TestFileTransportPublish:
    """Sync publish writes one JSON line per observation."""

    def test_writes_one_json_line(self, tmp_path: Path) -> None:
        from bpsai_agent_core.file_transport import FileTransport

        fp = tmp_path / "obs.jsonl"
        ft = FileTransport(path=fp)
        obs = Observation(agent_name="a1", type="metric", payload={"val": 42})
        ft.publish(obs)

        lines = fp.read_text().strip().splitlines()
        assert len(lines) == 1
        data = json.loads(lines[0])
        assert data["agent_name"] == "a1"
        assert data["type"] == "metric"
        assert data["payload"] == {"val": 42}
        assert data["severity"] == "info"
        assert "timestamp" in data

    def test_appends_multiple_observations(self, tmp_path: Path) -> None:
        from bpsai_agent_core.file_transport import FileTransport

        fp = tmp_path / "obs.jsonl"
        ft = FileTransport(path=fp)
        for i in range(3):
            ft.publish(Observation(agent_name="a", type="t", payload={"i": i}))

        lines = fp.read_text().strip().splitlines()
        assert len(lines) == 3
        for i, line in enumerate(lines):
            assert json.loads(line)["payload"]["i"] == i

    def test_append_mode_never_overwrites(self, tmp_path: Path) -> None:
        from bpsai_agent_core.file_transport import FileTransport

        fp = tmp_path / "obs.jsonl"
        fp.write_text('{"existing": true}\n')

        ft = FileTransport(path=fp)
        ft.publish(Observation(agent_name="a", type="t", payload={}))

        lines = fp.read_text().strip().splitlines()
        assert len(lines) == 2
        assert json.loads(lines[0]) == {"existing": True}

    def test_creates_parent_directories(self, tmp_path: Path) -> None:
        from bpsai_agent_core.file_transport import FileTransport

        fp = tmp_path / "deep" / "nested" / "dir" / "obs.jsonl"
        ft = FileTransport(path=fp)
        ft.publish(Observation(agent_name="a", type="t", payload={}))

        assert fp.exists()
        lines = fp.read_text().strip().splitlines()
        assert len(lines) == 1


class TestFileTransportApublish:
    """Async apublish writes one JSON line per observation."""

    @pytest.mark.asyncio
    async def test_async_writes_one_json_line(self, tmp_path: Path) -> None:
        from bpsai_agent_core.file_transport import FileTransport

        fp = tmp_path / "obs.jsonl"
        ft = FileTransport(path=fp)
        obs = Observation(agent_name="a1", type="metric", payload={"val": 1})
        await ft.apublish(obs)

        lines = fp.read_text().strip().splitlines()
        assert len(lines) == 1
        data = json.loads(lines[0])
        assert data["agent_name"] == "a1"

    @pytest.mark.asyncio
    async def test_async_appends(self, tmp_path: Path) -> None:
        from bpsai_agent_core.file_transport import FileTransport

        fp = tmp_path / "obs.jsonl"
        ft = FileTransport(path=fp)
        for i in range(3):
            await ft.apublish(Observation(agent_name="a", type="t", payload={"i": i}))

        lines = fp.read_text().strip().splitlines()
        assert len(lines) == 3

    @pytest.mark.asyncio
    async def test_async_creates_parent_directories(self, tmp_path: Path) -> None:
        from bpsai_agent_core.file_transport import FileTransport

        fp = tmp_path / "sub" / "obs.jsonl"
        ft = FileTransport(path=fp)
        await ft.apublish(Observation(agent_name="a", type="t", payload={}))

        assert fp.exists()
