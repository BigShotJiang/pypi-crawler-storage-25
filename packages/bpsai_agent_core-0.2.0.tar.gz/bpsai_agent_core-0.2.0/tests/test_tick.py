"""Tests for tick lifecycle types: Phase, PhaseResult, TickContext, TickResult."""

from __future__ import annotations

import pytest


class TestPhase:
    """Phase enum tests."""

    def test_phase_members_exist(self) -> None:
        from bpsai_agent_core.tick import Phase

        assert Phase.SENSE.value == "sense"
        assert Phase.PLAN.value == "plan"
        assert Phase.EXECUTE.value == "execute"
        assert Phase.ENFORCE.value == "enforce"
        assert Phase.LEARN.value == "learn"

    def test_phase_member_order_is_load_bearing(self) -> None:
        """Phase member order must be SENSE, PLAN, EXECUTE, ENFORCE, LEARN."""
        from bpsai_agent_core.tick import Phase

        expected = ["sense", "plan", "execute", "enforce", "learn"]
        actual = [p.value for p in Phase]
        assert actual == expected

    def test_phase_has_no_dispatch(self) -> None:
        """DISPATCH was renamed to EXECUTE in agent-core."""
        from bpsai_agent_core.tick import Phase

        assert not hasattr(Phase, "DISPATCH")

    def test_phase_count(self) -> None:
        from bpsai_agent_core.tick import Phase

        assert len(Phase) == 5


class TestPhaseResult:
    """PhaseResult dataclass tests."""

    def test_construction(self) -> None:
        from bpsai_agent_core.tick import Phase, PhaseResult

        pr = PhaseResult(
            phase=Phase.SENSE, passed=True, findings=["ok"], duration_ms=1.5
        )
        assert pr.phase == Phase.SENSE
        assert pr.passed is True
        assert pr.findings == ["ok"]
        assert pr.duration_ms == 1.5

    def test_to_dict(self) -> None:
        from bpsai_agent_core.tick import Phase, PhaseResult

        pr = PhaseResult(
            phase=Phase.EXECUTE, passed=False, findings=["fail"], duration_ms=2.0
        )
        d = pr.to_dict()
        assert d == {
            "phase": "execute",
            "passed": False,
            "findings": ["fail"],
            "duration_ms": 2.0,
        }

    def test_from_dict_roundtrip(self) -> None:
        from bpsai_agent_core.tick import Phase, PhaseResult

        original = PhaseResult(
            phase=Phase.LEARN, passed=True, findings=["a", "b"], duration_ms=3.0
        )
        restored = PhaseResult.from_dict(original.to_dict())
        assert restored.phase == original.phase
        assert restored.passed == original.passed
        assert restored.findings == original.findings
        assert restored.duration_ms == original.duration_ms

    def test_from_dict_clamps_negative_duration(self) -> None:
        from bpsai_agent_core.tick import PhaseResult

        pr = PhaseResult.from_dict(
            {"phase": "sense", "passed": True, "findings": [], "duration_ms": -5.0}
        )
        assert pr.duration_ms == 0.0


class TestTickResult:
    """TickResult dataclass tests."""

    def test_construction(self) -> None:
        from bpsai_agent_core.tick import TickResult

        tr = TickResult(
            tick_number=1,
            phase_results={},
            duration_ms=10.0,
            events_processed=3,
        )
        assert tr.tick_number == 1
        assert tr.events_processed == 3

    def test_to_dict_from_dict_roundtrip(self) -> None:
        from bpsai_agent_core.tick import Phase, PhaseResult, TickResult

        pr = PhaseResult(
            phase=Phase.SENSE, passed=True, findings=[], duration_ms=1.0
        )
        original = TickResult(
            tick_number=2,
            phase_results={"sense": pr},
            duration_ms=5.0,
            events_processed=1,
        )
        restored = TickResult.from_dict(original.to_dict())
        assert restored.tick_number == 2
        assert restored.duration_ms == 5.0
        assert restored.events_processed == 1
        assert "sense" in restored.phase_results
        assert restored.phase_results["sense"].passed is True


class TestTickContext:
    """TickContext dataclass tests."""

    def test_construction_without_previous(self) -> None:
        from bpsai_agent_core.tick import TickContext

        ctx = TickContext(
            tick_number=1,
            timestamp="2026-01-01T00:00:00Z",
            event_queue_snapshot=[],
            state_snapshot={"key": "val"},
        )
        assert ctx.previous_result is None
        assert ctx.tick_number == 1

    def test_to_dict_from_dict_roundtrip_with_previous(self) -> None:
        from bpsai_agent_core.tick import Phase, PhaseResult, TickContext, TickResult

        pr = PhaseResult(
            phase=Phase.EXECUTE, passed=True, findings=[], duration_ms=1.0
        )
        prev = TickResult(
            tick_number=0,
            phase_results={"execute": pr},
            duration_ms=2.0,
            events_processed=0,
        )
        original = TickContext(
            tick_number=1,
            timestamp="2026-01-01T00:00:00Z",
            event_queue_snapshot=[{"type": "test"}],
            state_snapshot={"s": 1},
            previous_result=prev,
        )
        restored = TickContext.from_dict(original.to_dict())
        assert restored.tick_number == 1
        assert restored.timestamp == "2026-01-01T00:00:00Z"
        assert restored.previous_result is not None
        assert restored.previous_result.tick_number == 0

    def test_to_dict_without_previous_result(self) -> None:
        from bpsai_agent_core.tick import TickContext

        ctx = TickContext(
            tick_number=0,
            timestamp="t",
            event_queue_snapshot=[],
            state_snapshot={},
        )
        d = ctx.to_dict()
        assert d["previous_result"] is None
