"""Tests for AgentCard dataclasses and serialization."""

from __future__ import annotations

from bpsai_agent_core.card import (
    AgentCapabilities,
    AgentCard,
    AgentProvider,
    AgentSkill,
)


# ---------------------------------------------------------------------------
# AgentSkill
# ---------------------------------------------------------------------------

class TestAgentSkill:
    """AgentSkill construction and defaults."""

    def test_construction_required_fields(self) -> None:
        skill = AgentSkill(id="test", name="Test", description="A test skill")
        assert skill.id == "test"
        assert skill.name == "Test"
        assert skill.description == "A test skill"

    def test_default_lists_empty(self) -> None:
        skill = AgentSkill(id="s", name="S", description="d")
        assert skill.tags == []
        assert skill.examples == []

    def test_tags_and_examples(self) -> None:
        skill = AgentSkill(
            id="s", name="S", description="d",
            tags=["a", "b"], examples=["do x"],
        )
        assert skill.tags == ["a", "b"]
        assert skill.examples == ["do x"]


# ---------------------------------------------------------------------------
# AgentCard defaults
# ---------------------------------------------------------------------------

class TestAgentCardDefaults:
    """AgentCard construction with default values."""

    def test_minimal_construction(self) -> None:
        card = AgentCard(name="test", description="d", version="1.0.0")
        assert card.name == "test"
        assert card.description == "d"
        assert card.version == "1.0.0"

    def test_default_capabilities(self) -> None:
        card = AgentCard(name="t", description="d", version="1")
        assert card.capabilities.streaming is False
        assert card.capabilities.pushNotifications is False
        assert card.capabilities.stateTransitionHistory is False

    def test_default_provider(self) -> None:
        card = AgentCard(name="t", description="d", version="1")
        assert card.provider.organization == "BPS AI"

    def test_default_modes(self) -> None:
        card = AgentCard(name="t", description="d", version="1")
        assert card.defaultInputModes == ["text/plain"]
        assert card.defaultOutputModes == ["text/plain"]

    def test_default_skills_empty(self) -> None:
        card = AgentCard(name="t", description="d", version="1")
        assert card.skills == []

    def test_default_url_empty(self) -> None:
        card = AgentCard(name="t", description="d", version="1")
        assert card.url == ""


# ---------------------------------------------------------------------------
# AgentCard with all fields
# ---------------------------------------------------------------------------

class TestAgentCardFull:
    """AgentCard construction with all fields specified."""

    def test_all_fields(self) -> None:
        card = AgentCard(
            name="bpsai-metis",
            description="Reasoning agent",
            version="2.0.0",
            url="https://example.com",
            skills=[AgentSkill(id="observe", name="observe", description="d")],
            capabilities=AgentCapabilities(streaming=True, pushNotifications=True),
            provider=AgentProvider(organization="Acme", url="https://acme.com"),
            defaultInputModes=["application/json"],
            defaultOutputModes=["application/json"],
        )
        assert card.name == "bpsai-metis"
        assert card.capabilities.streaming is True
        assert card.provider.organization == "Acme"
        assert len(card.skills) == 1


# ---------------------------------------------------------------------------
# Serialization round-trip
# ---------------------------------------------------------------------------

class TestAgentCardSerialization:
    """to_dict / from_dict produce correct A2A-compatible structures."""

    def _make_card(self) -> AgentCard:
        return AgentCard(
            name="test-agent",
            description="Test",
            version="1.0.0",
            url="https://test.ai",
            skills=[
                AgentSkill(
                    id="plan", name="plan", description="Planning",
                    tags=["core"], examples=["plan sprint"],
                ),
            ],
            capabilities=AgentCapabilities(streaming=True),
            provider=AgentProvider(organization="Test Co", url="https://test.co"),
            defaultInputModes=["application/json"],
            defaultOutputModes=["application/json"],
        )

    def test_to_dict_top_level_keys(self) -> None:
        d = self._make_card().to_dict()
        expected_keys = {
            "name", "description", "version", "url",
            "skills", "capabilities", "provider",
            "defaultInputModes", "defaultOutputModes",
        }
        assert set(d.keys()) == expected_keys

    def test_to_dict_skills_structure(self) -> None:
        d = self._make_card().to_dict()
        skill = d["skills"][0]
        assert skill["id"] == "plan"
        assert skill["tags"] == ["core"]

    def test_to_dict_capabilities_structure(self) -> None:
        d = self._make_card().to_dict()
        assert d["capabilities"]["streaming"] is True
        assert d["capabilities"]["pushNotifications"] is False

    def test_to_dict_provider_structure(self) -> None:
        d = self._make_card().to_dict()
        assert d["provider"]["organization"] == "Test Co"
        assert d["provider"]["url"] == "https://test.co"

    def test_from_dict_round_trip(self) -> None:
        original = self._make_card()
        d = original.to_dict()
        restored = AgentCard.from_dict(d)
        assert restored.name == original.name
        assert restored.version == original.version
        assert restored.capabilities.streaming is True
        assert restored.provider.organization == "Test Co"
        assert len(restored.skills) == 1
        assert restored.skills[0].id == "plan"
        assert restored.skills[0].tags == ["core"]

    def test_from_dict_minimal(self) -> None:
        d = {"name": "x", "description": "y", "version": "0.1"}
        card = AgentCard.from_dict(d)
        assert card.name == "x"
        assert card.skills == []
        assert card.capabilities.streaming is False
