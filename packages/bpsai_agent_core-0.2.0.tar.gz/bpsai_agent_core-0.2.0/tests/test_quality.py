"""Tests for QualityProfile -- SQLite-backed quality observation store."""

from __future__ import annotations

from bpsai_agent_core.quality import QualityObservation, QualityProfile


class TestQualityRecord:
    def test_record_returns_id(self):
        qp = QualityProfile()
        obs_id = qp.record("test observation")
        assert isinstance(obs_id, int)
        assert obs_id >= 1
        qp.close()

    def test_record_multiple_returns_incrementing_ids(self):
        qp = QualityProfile()
        id1 = qp.record("obs 1")
        id2 = qp.record("obs 2")
        assert id2 > id1
        qp.close()

    def test_confidence_clamped_high(self):
        qp = QualityProfile()
        qp.record("over", confidence=5.0)
        obs = qp.get_active()
        assert obs[0].confidence <= 1.0
        qp.close()

    def test_confidence_clamped_low(self):
        qp = QualityProfile()
        qp.record("under", confidence=-1.0)
        obs = qp.get_active(min_confidence=0.0)
        assert obs[0].confidence >= 0.0
        qp.close()


class TestQualityGetActive:
    def test_returns_ordered_by_confidence_desc(self):
        qp = QualityProfile()
        qp.record("low", confidence=0.3)
        qp.record("high", confidence=0.9)
        qp.record("mid", confidence=0.6)

        active = qp.get_active()
        confidences = [o.confidence for o in active]
        assert confidences == sorted(confidences, reverse=True)
        qp.close()

    def test_filters_by_min_confidence(self):
        qp = QualityProfile()
        qp.record("keep", confidence=0.5)
        qp.record("drop", confidence=0.05)

        active = qp.get_active(min_confidence=0.1)
        assert len(active) == 1
        assert active[0].observation == "keep"
        qp.close()

    def test_respects_limit(self):
        qp = QualityProfile()
        for i in range(10):
            qp.record(f"obs {i}", confidence=0.5)

        active = qp.get_active(limit=3)
        assert len(active) == 3
        qp.close()


class TestQualityReinforce:
    def test_reinforce_boosts_confidence(self):
        qp = QualityProfile()
        obs_id = qp.record("boost me", confidence=0.5)
        qp.reinforce(obs_id)
        obs = qp.get_active()
        target = [o for o in obs if o.id == obs_id][0]
        assert target.confidence > 0.5
        qp.close()

    def test_reinforce_diminishing_returns(self):
        qp = QualityProfile()
        obs_id = qp.record("boost me", confidence=0.5)

        qp.reinforce(obs_id)
        obs1 = qp.get_active()
        boost1 = [o for o in obs1 if o.id == obs_id][0].confidence - 0.5

        qp.reinforce(obs_id)
        obs2 = qp.get_active()
        boost2 = [o for o in obs2 if o.id == obs_id][0].confidence - (0.5 + boost1)

        assert boost2 < boost1
        qp.close()

    def test_reinforce_nonexistent_is_noop(self):
        qp = QualityProfile()
        qp.reinforce(9999)  # should not raise
        qp.close()


class TestQualityPrune:
    def test_prune_removes_low_confidence(self):
        qp = QualityProfile()
        qp.record("keep", confidence=0.5)
        qp.record("remove", confidence=0.05)

        removed = qp.prune(threshold=0.1)
        assert removed == 1
        active = qp.get_active(min_confidence=0.0)
        assert len(active) == 1
        assert active[0].observation == "keep"
        qp.close()

    def test_prune_returns_zero_when_nothing_pruned(self):
        qp = QualityProfile()
        qp.record("keep", confidence=0.5)
        removed = qp.prune(threshold=0.1)
        assert removed == 0
        qp.close()


class TestQualityPromptContext:
    def test_as_prompt_context_formats_active(self):
        qp = QualityProfile()
        qp.record("use type hints", confidence=0.8)
        result = qp.as_prompt_context()
        assert "Quality observations:" in result
        assert "use type hints" in result
        assert "0.80" in result
        qp.close()

    def test_as_prompt_context_empty_returns_default(self):
        qp = QualityProfile()
        result = qp.as_prompt_context()
        assert result == "No quality observations recorded."
        qp.close()


class TestQualityClose:
    def test_close_works_without_error(self):
        qp = QualityProfile()
        qp.close()  # should not raise
