"""Tests for LoopRunner — orchestration tick executor."""

import asyncio

import pytest

from bpsai_agent_core.hooks import PhaseRegistry
from bpsai_agent_core.loop import LoopRunner
from bpsai_agent_core.tick import Phase, PhaseResult, TickContext


class CountingHook:
    """Test hook that counts executions."""

    def __init__(self, phase: Phase, passed: bool = True):
        self._phase = phase
        self._passed = passed
        self.call_count = 0

    @property
    def phase(self) -> Phase:
        return self._phase

    @property
    def priority(self) -> int:
        return 10

    async def execute(self, context: TickContext) -> PhaseResult:
        self.call_count += 1
        return PhaseResult(
            phase=self._phase, passed=self._passed, findings=[], duration_ms=0.0,
        )


class TestRunTick:
    """Tests for run_tick()."""

    @pytest.mark.asyncio
    async def test_run_tick_increments_count(self):
        registry = PhaseRegistry()
        runner = LoopRunner(registry=registry)
        assert runner.tick_count == 0
        await runner.run_tick()
        assert runner.tick_count == 1

    @pytest.mark.asyncio
    async def test_run_tick_returns_tick_result(self):
        registry = PhaseRegistry()
        runner = LoopRunner(registry=registry)
        result = await runner.run_tick()
        assert result.tick_number == 0
        assert isinstance(result.phase_results, dict)

    @pytest.mark.asyncio
    async def test_run_tick_executes_hooks(self):
        registry = PhaseRegistry()
        hook = CountingHook(Phase.SENSE)
        registry.register(hook)
        runner = LoopRunner(registry=registry)
        await runner.run_tick()
        assert hook.call_count == 1

    @pytest.mark.asyncio
    async def test_run_tick_executes_all_phases(self):
        registry = PhaseRegistry()
        hooks = [CountingHook(phase) for phase in Phase]
        for h in hooks:
            registry.register(h)
        runner = LoopRunner(registry=registry)
        await runner.run_tick()
        for h in hooks:
            assert h.call_count == 1

    @pytest.mark.asyncio
    async def test_run_tick_empty_phase_passes(self):
        registry = PhaseRegistry()
        runner = LoopRunner(registry=registry)
        result = await runner.run_tick()
        for phase_key, pr in result.phase_results.items():
            assert pr.passed is True

    @pytest.mark.asyncio
    async def test_run_tick_timeout_reports_failure(self):
        """Hook that exceeds timeout is reported as failure."""

        class SlowHook:
            @property
            def phase(self) -> Phase:
                return Phase.SENSE

            @property
            def priority(self) -> int:
                return 10

            async def execute(self, context: TickContext) -> PhaseResult:
                await asyncio.sleep(10)
                return PhaseResult(phase=Phase.SENSE, passed=True, findings=[], duration_ms=0.0)

        registry = PhaseRegistry()
        registry.register(SlowHook())
        runner = LoopRunner(registry=registry, tick_timeout_seconds=0.1)
        result = await runner.run_tick()
        sense_result = result.phase_results[Phase.SENSE.value]
        assert sense_result.passed is False
        assert any("timed out" in f.lower() for f in sense_result.findings)

    @pytest.mark.asyncio
    async def test_run_tick_exception_reports_failure(self):
        """Hook that raises is reported as failure."""

        class FailingHook:
            @property
            def phase(self) -> Phase:
                return Phase.PLAN

            @property
            def priority(self) -> int:
                return 10

            async def execute(self, context: TickContext) -> PhaseResult:
                raise RuntimeError("boom")

        registry = PhaseRegistry()
        registry.register(FailingHook())
        runner = LoopRunner(registry=registry)
        result = await runner.run_tick()
        plan_result = result.phase_results[Phase.PLAN.value]
        assert plan_result.passed is False
        assert any("RuntimeError" in f for f in plan_result.findings)


class TestRun:
    """Tests for run() with max_ticks."""

    @pytest.mark.asyncio
    async def test_run_with_max_ticks(self):
        registry = PhaseRegistry()
        runner = LoopRunner(registry=registry)
        await runner.run(max_ticks=3)
        assert runner.tick_count == 3

    @pytest.mark.asyncio
    async def test_shutdown_stops_loop(self):
        """Shutdown mid-loop stops before max_ticks."""
        registry = PhaseRegistry()
        runner = LoopRunner(registry=registry)

        class ShutdownAfterThree:
            @property
            def phase(self) -> Phase:
                return Phase.SENSE

            @property
            def priority(self) -> int:
                return 10

            async def execute(self, context: TickContext) -> PhaseResult:
                if context.tick_number >= 3:
                    runner.shutdown()
                return PhaseResult(phase=Phase.SENSE, passed=True, findings=[], duration_ms=0.0)

        registry.register(ShutdownAfterThree())
        await runner.run(max_ticks=100)
        assert runner.tick_count <= 4  # may complete the tick that triggered shutdown

    @pytest.mark.asyncio
    async def test_previous_result_available_in_context(self):
        """Second tick's context includes previous tick's result."""
        contexts_seen = []

        class ContextCapture:
            @property
            def phase(self) -> Phase:
                return Phase.SENSE

            @property
            def priority(self) -> int:
                return 10

            async def execute(self, context: TickContext) -> PhaseResult:
                contexts_seen.append(context)
                return PhaseResult(phase=Phase.SENSE, passed=True, findings=[], duration_ms=0.0)

        registry = PhaseRegistry()
        registry.register(ContextCapture())
        runner = LoopRunner(registry=registry)
        await runner.run(max_ticks=2)
        assert contexts_seen[0].previous_result is None
        assert contexts_seen[1].previous_result is not None
