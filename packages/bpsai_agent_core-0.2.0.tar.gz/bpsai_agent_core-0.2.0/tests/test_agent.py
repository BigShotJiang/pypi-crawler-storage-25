"""Tests for BaseAgent ABC and AgentConfig."""

from __future__ import annotations

import pytest

from bpsai_agent_core.agent import AgentConfig, BaseAgent
from bpsai_agent_core.observation import Observation
from bpsai_agent_core.tick import Phase, PhaseResult, TickContext, TickResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_context(tick_number: int = 1) -> TickContext:
    return TickContext(
        tick_number=tick_number,
        timestamp="2026-01-01T00:00:00Z",
        event_queue_snapshot=[],
        state_snapshot={},
    )


def _ok_result(phase: Phase) -> PhaseResult:
    return PhaseResult(phase=phase, passed=True, findings=[], duration_ms=0.0)


def _fail_result(phase: Phase) -> PhaseResult:
    return PhaseResult(phase=phase, passed=False, findings=["error"], duration_ms=0.0)


class StubAgent(BaseAgent):
    """Concrete agent for testing -- records call order."""

    def __init__(self, config: AgentConfig, fail_phase: Phase | None = None):
        super().__init__(config)
        self.call_order: list[Phase] = []
        self._fail_phase = fail_phase

    async def sense(self, context: TickContext) -> PhaseResult:
        self.call_order.append(Phase.SENSE)
        if self._fail_phase == Phase.SENSE:
            return _fail_result(Phase.SENSE)
        return _ok_result(Phase.SENSE)

    async def plan(self, context: TickContext) -> PhaseResult:
        self.call_order.append(Phase.PLAN)
        if self._fail_phase == Phase.PLAN:
            return _fail_result(Phase.PLAN)
        return _ok_result(Phase.PLAN)

    async def execute(self, context: TickContext) -> PhaseResult:
        self.call_order.append(Phase.EXECUTE)
        if self._fail_phase == Phase.EXECUTE:
            return _fail_result(Phase.EXECUTE)
        return _ok_result(Phase.EXECUTE)

    async def learn(self, context: TickContext) -> PhaseResult:
        self.call_order.append(Phase.LEARN)
        if self._fail_phase == Phase.LEARN:
            return _fail_result(Phase.LEARN)
        return _ok_result(Phase.LEARN)


# ---------------------------------------------------------------------------
# AgentConfig tests
# ---------------------------------------------------------------------------

class TestAgentConfig:
    def test_defaults(self):
        cfg = AgentConfig(agent_id="a1", name="Test Agent")
        assert cfg.agent_id == "a1"
        assert cfg.name == "Test Agent"
        assert cfg.version == "0.1.0"
        assert cfg.skills == []
        assert cfg.llm_call is None
        assert cfg.metadata == {}

    def test_with_llm_call(self):
        async def fake_llm(system: str, user: str) -> str:
            return "response"

        cfg = AgentConfig(agent_id="a2", name="LLM Agent", llm_call=fake_llm)
        assert cfg.llm_call is not None


# ---------------------------------------------------------------------------
# BaseAgent tests
# ---------------------------------------------------------------------------

class TestBaseAgent:
    def test_cannot_instantiate_directly(self):
        cfg = AgentConfig(agent_id="a1", name="Test")
        with pytest.raises(TypeError):
            BaseAgent(cfg)  # type: ignore[abstract]

    def test_concrete_subclass_works(self):
        cfg = AgentConfig(agent_id="a1", name="Stub")
        agent = StubAgent(cfg)
        assert agent.config is cfg

    @pytest.mark.asyncio
    async def test_tick_calls_phases_in_order(self):
        cfg = AgentConfig(agent_id="a1", name="Stub")
        agent = StubAgent(cfg)
        ctx = _make_context()

        result = await agent.tick(ctx)

        assert agent.call_order == [Phase.SENSE, Phase.PLAN, Phase.EXECUTE, Phase.LEARN]
        assert result.tick_number == 1

    @pytest.mark.asyncio
    async def test_tick_all_pass_returns_success(self):
        cfg = AgentConfig(agent_id="a1", name="Stub")
        agent = StubAgent(cfg)
        ctx = _make_context()

        result = await agent.tick(ctx)

        # All phases passed
        for pr in result.phase_results.values():
            assert pr.passed is True

    @pytest.mark.asyncio
    async def test_tick_stops_on_first_failed_phase(self):
        cfg = AgentConfig(agent_id="a1", name="Stub")
        agent = StubAgent(cfg, fail_phase=Phase.PLAN)
        ctx = _make_context()

        result = await agent.tick(ctx)

        assert agent.call_order == [Phase.SENSE, Phase.PLAN]
        assert Phase.EXECUTE.value not in result.phase_results
        assert Phase.LEARN.value not in result.phase_results

    @pytest.mark.asyncio
    async def test_tick_returns_tick_result_with_phase_results(self):
        cfg = AgentConfig(agent_id="a1", name="Stub")
        agent = StubAgent(cfg)
        ctx = _make_context(tick_number=5)

        result = await agent.tick(ctx)

        assert isinstance(result, TickResult)
        assert result.tick_number == 5
        assert len(result.phase_results) == 4


class TestBaseAgentCard:
    def test_card_returns_agent_card(self):
        from bpsai_agent_core.card import AgentCard

        cfg = AgentConfig(agent_id="bot-1", name="My Bot", version="1.2.0")
        agent = StubAgent(cfg)
        card = agent.card()

        assert isinstance(card, AgentCard)
        assert card.name == "bot-1"
        assert card.version == "1.2.0"


# ---------------------------------------------------------------------------
# Transport helpers for emit/aemit tests
# ---------------------------------------------------------------------------

class FakeSyncTransport:
    """Sync-only transport that records published observations."""

    def __init__(self):
        self.published: list[Observation] = []

    def publish(self, observation: Observation) -> None:
        self.published.append(observation)


class FakeAsyncTransport:
    """Async transport that records published observations."""

    def __init__(self):
        self.published: list[Observation] = []

    def publish(self, observation: Observation) -> None:
        self.published.append(observation)

    async def apublish(self, observation: Observation) -> None:
        self.published.append(observation)


# ---------------------------------------------------------------------------
# set_transport / emit / aemit tests
# ---------------------------------------------------------------------------

class TestSetTransport:
    def test_set_transport_stores_transport(self):
        cfg = AgentConfig(agent_id="a1", name="Test")
        agent = StubAgent(cfg)
        transport = FakeSyncTransport()
        agent.set_transport(transport)
        assert agent._transport is transport

    def test_no_transport_by_default(self):
        cfg = AgentConfig(agent_id="a1", name="Test")
        agent = StubAgent(cfg)
        assert agent._transport is None


class TestEmit:
    def test_emit_noop_without_transport(self):
        cfg = AgentConfig(agent_id="a1", name="Test")
        agent = StubAgent(cfg)
        # Should not raise
        agent.emit("test.event", {"key": "value"})

    def test_emit_publishes_via_transport(self):
        cfg = AgentConfig(agent_id="a1", name="Test")
        agent = StubAgent(cfg)
        transport = FakeSyncTransport()
        agent.set_transport(transport)

        agent.emit("test.event", {"key": "value"})

        assert len(transport.published) == 1
        obs = transport.published[0]
        assert obs.agent_name == "Test"
        assert obs.type == "test.event"
        assert obs.payload == {"key": "value"}
        assert obs.severity == "info"

    def test_emit_custom_severity(self):
        cfg = AgentConfig(agent_id="a1", name="Test")
        agent = StubAgent(cfg)
        transport = FakeSyncTransport()
        agent.set_transport(transport)

        agent.emit("error.event", {"err": "boom"}, severity="error")

        obs = transport.published[0]
        assert obs.severity == "error"

    def test_emit_auto_populates_agent_name_from_config(self):
        cfg = AgentConfig(agent_id="a1", name="My Custom Agent")
        agent = StubAgent(cfg)
        transport = FakeSyncTransport()
        agent.set_transport(transport)

        agent.emit("ping", {})

        assert transport.published[0].agent_name == "My Custom Agent"


class TestAemit:
    @pytest.mark.asyncio
    async def test_aemit_noop_without_transport(self):
        cfg = AgentConfig(agent_id="a1", name="Test")
        agent = StubAgent(cfg)
        # Should not raise
        await agent.aemit("test.event", {"key": "value"})

    @pytest.mark.asyncio
    async def test_aemit_uses_apublish_when_available(self):
        cfg = AgentConfig(agent_id="a1", name="Test")
        agent = StubAgent(cfg)
        transport = FakeAsyncTransport()
        agent.set_transport(transport)

        await agent.aemit("test.event", {"key": "value"})

        assert len(transport.published) == 1
        obs = transport.published[0]
        assert obs.agent_name == "Test"
        assert obs.type == "test.event"

    @pytest.mark.asyncio
    async def test_aemit_falls_back_to_sync_publish(self):
        cfg = AgentConfig(agent_id="a1", name="Test")
        agent = StubAgent(cfg)
        transport = FakeSyncTransport()  # No apublish
        agent.set_transport(transport)

        await agent.aemit("test.event", {"data": 1})

        assert len(transport.published) == 1
        assert transport.published[0].type == "test.event"

    @pytest.mark.asyncio
    async def test_aemit_auto_populates_agent_name(self):
        cfg = AgentConfig(agent_id="a1", name="Async Agent")
        agent = StubAgent(cfg)
        transport = FakeAsyncTransport()
        agent.set_transport(transport)

        await agent.aemit("ping", {})

        assert transport.published[0].agent_name == "Async Agent"
