# mypy: disable-error-code="misc"
"""Tests the basic compiler traits."""

from dataclasses import FrozenInstanceError, dataclass

import pytest
from frozendict import frozendict

from fhy_core.identifier import Identifier
from fhy_core.provenance import Provenance
from fhy_core.trait import (
    Equal,
    EqualMixin,
    Frozen,
    FrozenMixin,
    FrozenMutationError,
    FrozenValidationError,
    HasIdentifier,
    HasIdentifierMixin,
    HasProvenance,
    HasProvenanceMixin,
    Interned,
    InternedMixin,
    Orderable,
    OrderableMixin,
    PartialEqual,
    PartialEqualMixin,
    PartialOrderable,
    PartialOrderableMixin,
    VerifiableMixin,
    VerificationError,
)

from .conftest import mock_identifier


@dataclass
class _IdentifierCarrier(HasIdentifierMixin):
    _identifier: Identifier

    def get_identifier(self) -> Identifier:
        return self._identifier


@dataclass
class _ProvenanceCarrier(HasProvenanceMixin):
    _provenance: Provenance

    def get_provenance(self) -> Provenance:
        return self._provenance


@dataclass
class _FrozenNode(FrozenMixin):
    value: int
    items: list[int]

    def __post_init__(self) -> None:
        self.freeze(deep=True)


class _MutablePayload:
    def __init__(self) -> None:
        self.values = [1, 2, 3]


@dataclass(frozen=True)
class _PartialOrderableValue(PartialOrderableMixin):
    value: int

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, _PartialOrderableValue):
            return NotImplemented
        return self.value < other.value


@dataclass(eq=True)
class _AutoPartialEqualValue(PartialEqualMixin):
    value: int


@dataclass(eq=False)
class _NoPartialEqualValue(PartialEqualMixin):
    value: int


@dataclass(eq=True, frozen=True)
class _AutoEqualValue(EqualMixin):
    value: int


class _NoHashEqualValue(EqualMixin):  # noqa: PLW1641
    pass


@dataclass(order=True)
class _AutoPartialOrderableValue(PartialOrderableMixin):  # type: ignore[override]
    value: int


@dataclass(order=True)
class _AutoOrderableValue(OrderableMixin):  # type: ignore[override]
    value: int


@dataclass
class _FrozenWrapper(FrozenMixin):
    payload: object


@dataclass
class _FrozenMapNode(FrozenMixin):
    payload: dict[str, int]

    def __post_init__(self) -> None:
        self.freeze(deep=True)


@dataclass
class _CyclicFrozenNode(FrozenMixin):
    peer: object | None = None


@dataclass(frozen=True)
class _AutoFrozenPoint(FrozenMixin):
    x: int
    y: int


@dataclass(frozen=True)
class _AutoFrozenPayload(FrozenMixin):
    payload: object


class _InternedValue(InternedMixin[str]):
    def __init__(self, key: str, value: int) -> None:
        self.key = key
        self.value = value

    def get_intern_key(self) -> str:
        return self.key


class _BaseInternedValue(InternedMixin[str]):
    def __init__(self, key: str) -> None:
        self.key = key

    def get_intern_key(self) -> str:
        return self.key


class _DerivedInternedValue(_BaseInternedValue):
    def __init__(self, key: str, payload: int) -> None:
        super().__init__(key)
        self.payload = payload


class _VerifiedFrozenInternedValue(InternedMixin[str], FrozenMixin, VerifiableMixin):
    verify_calls = 0

    def __init__(self, key: str, payload: list[int]) -> None:
        self.key = key
        self.payload = payload

    def get_intern_key(self) -> str:
        return self.key

    def verify(self) -> None:
        type(self).verify_calls += 1
        if not self.key:
            raise VerificationError("missing intern key")


class _RaisingInternedValue(InternedMixin[str]):
    def __init__(self, key: str) -> None:
        self.key = key
        raise RuntimeError("init failed")

    def get_intern_key(self) -> str:
        return self.key


@dataclass
class _DataclassInternedValue(InternedMixin[str]):
    key: str
    value: int

    def __post_init__(self) -> None:
        self.register_interned_instance()

    def get_intern_key(self) -> str:
        return self.key


def test_has_identifier_runtime_protocol() -> None:
    """Test `HasIdentifier` runtime protocol."""
    carrier = _IdentifierCarrier(mock_identifier("x", 1))
    assert isinstance(carrier, HasIdentifier)


def test_has_provenance_runtime_protocol() -> None:
    """Test `HasProvenance` runtime protocol."""
    carrier = _ProvenanceCarrier(Provenance.unknown())
    assert isinstance(carrier, HasProvenance)


def test_partial_orderable_runtime_protocol() -> None:
    """Test `PartialOrderable` runtime protocol."""
    value = _PartialOrderableValue(3)
    assert isinstance(value, PartialOrderable)


def test_partial_orderable_supports_sorting() -> None:
    """Test `PartialOrderableMixin` implementations can be sorted."""
    values = [
        _PartialOrderableValue(3),
        _PartialOrderableValue(1),
        _PartialOrderableValue(2),
    ]
    sorted_values = sorted(values)
    assert [value.value for value in sorted_values] == [1, 2, 3]


def test_partial_equal_runtime_protocol() -> None:
    """Test `PartialEqual` runtime protocol."""
    value = _AutoPartialEqualValue(3)
    assert isinstance(value, PartialEqual)
    assert value.supports_partial_equality is True


def test_partial_equal_detects_eq_false_dataclass() -> None:
    """Test `PartialEqualMixin` detects `dataclass(eq=False)` as unsupported."""
    value = _NoPartialEqualValue(3)
    assert value.supports_partial_equality is False
    assert value.__eq__(_NoPartialEqualValue(3)) is NotImplemented


def test_equal_runtime_protocol() -> None:
    """Test `Equal` runtime protocol."""
    value = _AutoEqualValue(3)
    assert isinstance(value, Equal)
    assert value.supports_equality is True
    assert value.supports_partial_equality is True
    assert value == _AutoEqualValue(3)


def test_equal_mixin_requires_hash_implementation() -> None:
    """Test `EqualMixin` prompts subclasses to implement hash."""
    with pytest.raises(NotImplementedError):
        hash(_NoHashEqualValue())


def test_partial_orderable_detects_ordered_dataclass() -> None:
    """Test `PartialOrderableMixin` detects `dataclass(order=True)` support."""
    left = _AutoPartialOrderableValue(1)
    right = _AutoPartialOrderableValue(2)
    assert left.supports_partial_ordering is True
    assert left < right


def test_orderable_runtime_protocol() -> None:
    """Test `Orderable` runtime protocol."""
    value = _AutoOrderableValue(3)
    assert isinstance(value, Orderable)
    assert value.supports_ordering is True
    assert value.supports_partial_ordering is True


def test_orderable_mixin_defaults_to_total_order() -> None:
    """Test `OrderableMixin` defaults to total-order support."""
    value = _AutoOrderableValue(3)
    assert value.supports_partial_ordering is True
    assert value.supports_ordering is True


def test_identifier_mixin_contract() -> None:
    """Test `HasIdentifierMixin` contract."""
    carrier = _IdentifierCarrier(mock_identifier("field", 2))
    assert carrier.get_identifier().name_hint == "field"
    assert carrier.get_identifier().id == 2


def test_provenance_mixin_contract() -> None:
    """Test `HasProvenanceMixin` contract."""
    carrier = _ProvenanceCarrier(Provenance.unknown())
    assert carrier.get_provenance() == Provenance.unknown()


def test_frozen_runtime_protocol() -> None:
    """Test `Frozen` runtime protocol."""
    node = _FrozenNode(1, [2, 3])
    assert isinstance(node, Frozen)


def test_frozen_blocks_attribute_updates_after_freeze() -> None:
    """Test `FrozenMixin` blocks direct attribute mutation after freezing."""
    node = _FrozenNode(1, [2, 3])
    with pytest.raises(FrozenMutationError):
        node.value = 42


def test_frozen_blocks_attribute_deletion_after_freeze() -> None:
    """Test `FrozenMixin` blocks attribute deletion after freezing."""
    node = _FrozenNode(1, [2, 3])
    with pytest.raises(FrozenMutationError):
        del node.value


def test_frozen_deep_freeze_converts_mutable_builtins() -> None:
    """Test `FrozenMixin.freeze(deep=True)` converts mutable containers."""
    node = _FrozenNode(1, [2, 3])
    assert isinstance(node.items, tuple)


def test_frozen_deep_freeze_converts_dict_to_frozendict() -> None:
    """Test `FrozenMixin.freeze(deep=True)` converts dict to frozendict."""
    node = _FrozenMapNode({"x": 1})
    assert isinstance(node.payload, frozendict)


def test_frozen_assert_frozen_passes_for_write_protected_instance() -> None:
    """Test `FrozenMixin.assert_frozen` passes for valid frozen instances."""
    node = _FrozenNode(1, [2, 3])
    node.assert_frozen(deep=True)


def test_frozen_assert_frozen_fails_when_not_frozen() -> None:
    """Test `FrozenMixin.assert_frozen` fails if instance was not frozen."""
    wrapper = _FrozenWrapper(_MutablePayload())
    with pytest.raises(FrozenValidationError):
        wrapper.assert_frozen()


def test_frozen_strict_check_detects_unknown_mutable_payload() -> None:
    """Test strict deep frozen checks reject unknown mutable nested objects."""
    wrapper = _FrozenWrapper(_MutablePayload())
    wrapper.freeze(deep=False)
    with pytest.raises(FrozenValidationError):
        wrapper.assert_frozen(deep=True, strict=True)


def test_frozen_deep_freeze_handles_self_reference() -> None:
    """Test `FrozenMixin.freeze(deep=True)` handles direct self-references."""
    node = _CyclicFrozenNode()
    node.peer = node
    node.freeze(deep=True)
    assert node.is_frozen
    assert node.peer is node


def test_frozen_deep_freeze_handles_mutually_recursive_nodes() -> None:
    """Test `FrozenMixin.freeze(deep=True)` handles mutual object cycles."""
    left = _CyclicFrozenNode()
    right = _CyclicFrozenNode()
    left.peer = right
    right.peer = left
    left.freeze(deep=True)
    assert left.is_frozen
    assert right.is_frozen
    assert left.peer is right
    assert right.peer is left


def test_native_frozen_dataclass_runtime_protocol() -> None:
    """Test native frozen dataclass instances satisfy the `Frozen` protocol."""
    point = _AutoFrozenPoint(1, 2)
    assert isinstance(point, Frozen)
    assert point.is_frozen is True


def test_native_frozen_dataclass_blocks_mutation() -> None:
    """Test native frozen dataclass blocks direct attribute mutation."""
    point = _AutoFrozenPoint(1, 2)
    with pytest.raises(FrozenInstanceError):
        point.x = 4


def test_native_frozen_dataclass_assert_frozen_detects_deep_mutability() -> None:
    """Test native frozen dataclass deep checks reject mutable nested payloads."""
    payload = _AutoFrozenPayload(payload=[1, 2, 3])
    with pytest.raises(FrozenValidationError):
        payload.assert_frozen(deep=True)


def test_native_frozen_dataclass_with_frozen_mixin() -> None:
    """Test native `dataclass(frozen=True)` integrates with `FrozenMixin`."""

    @dataclass(frozen=True)
    class _NativeFrozenPoint(FrozenMixin):
        x: int
        y: int

    point = _NativeFrozenPoint(1, 2)

    assert isinstance(point, Frozen)
    assert point.is_frozen is True
    point.assert_frozen()
    with pytest.raises(FrozenInstanceError):
        setattr(point, "x", 4)


def test_interned_runtime_protocol() -> None:
    """Test `Interned` runtime protocol."""
    _InternedValue.clear_interned_registry()
    value = _InternedValue("x", 1)
    assert isinstance(value, Interned)


def test_interned_returns_first_registered_instance_for_key() -> None:
    """Test duplicate intern keys preserve the first registered instance."""
    _InternedValue.clear_interned_registry()
    first = _InternedValue("x", 1)
    second = _InternedValue("x", 2)

    assert _InternedValue.get_interned("x") is first
    assert _InternedValue.require_interned("x") is first
    assert second is not first


def test_interned_subclasses_share_family_registry() -> None:
    """Test descendants register into the same family registry as their base."""
    _BaseInternedValue.clear_interned_registry()
    value = _DerivedInternedValue("child", 7)

    assert _BaseInternedValue.get_interned("child") is value
    assert _DerivedInternedValue.get_interned("child") is value


def test_interned_supports_manual_registration_from_dataclass_post_init() -> None:
    """Test dataclass users can register canonical instances from `__post_init__`."""
    _DataclassInternedValue.clear_interned_registry()
    value = _DataclassInternedValue("dc", 9)

    assert _DataclassInternedValue.get_interned("dc") is value


def test_interned_finalize_verifies_and_freezes_once() -> None:
    """Test `InternedMixin` verifies/freezes exactly once per full init chain."""
    _VerifiedFrozenInternedValue.clear_interned_registry()
    _VerifiedFrozenInternedValue.verify_calls = 0
    value = _VerifiedFrozenInternedValue("frozen", [1, 2, 3])

    assert _VerifiedFrozenInternedValue.verify_calls == 1
    assert value.is_frozen is True
    assert value.payload == (1, 2, 3)  # type: ignore[comparison-overlap]


def test_interned_finalize_propagates_verification_errors() -> None:
    """Test failed verification prevents invalid interned registration."""
    _VerifiedFrozenInternedValue.clear_interned_registry()
    _VerifiedFrozenInternedValue.verify_calls = 0

    with pytest.raises(VerificationError):
        _VerifiedFrozenInternedValue("", [1])

    assert _VerifiedFrozenInternedValue.get_interned("") is None


def test_interned_does_not_register_when_init_raises() -> None:
    """Test failed initialization prevents partial interned registration."""
    _RaisingInternedValue.clear_interned_registry()

    with pytest.raises(RuntimeError, match="init failed"):
        _RaisingInternedValue("boom")

    assert _RaisingInternedValue.get_interned("boom") is None
