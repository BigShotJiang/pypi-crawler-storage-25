# © 2025 SolarWinds Worldwide, LLC. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at:http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.

"""SolarWinds TracerProvider with custom shutdown behavior."""

from opentelemetry.sdk.trace import TracerProvider
from typing_extensions import override

from solarwinds_apm.oboe.http_sampler import HttpSampler


class SolarwindsTracerProvider(TracerProvider):
    """Provide custom TracerProvider with HttpSampler shutdown support.

    Extends OpenTelemetry TracerProvider to properly shutdown HttpSampler.
    """

    @override
    def shutdown(self) -> None:
        """
        Shutdown the tracer provider and its sampler.

        Ensures HttpSampler daemon thread is properly terminated before parent shutdown.
        """
        if isinstance(self.sampler, HttpSampler):
            self.sampler.shutdown()
        super().shutdown()
