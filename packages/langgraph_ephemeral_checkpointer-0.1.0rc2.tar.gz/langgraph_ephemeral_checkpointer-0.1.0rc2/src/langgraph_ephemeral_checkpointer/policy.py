from dataclasses import dataclass

@dataclass(frozen=True)
class TTLPolicy:
    idle_ttl_seconds: int | None = None
    hard_age_ttl_seconds: int | None = None
    max_checkpoints_per_thread: int | None = None

    def __post_init__(self) -> None:
        has_ttl = (
            self.idle_ttl_seconds is not None
            or self.hard_age_ttl_seconds is not None
        )
        has_count = self.max_checkpoints_per_thread is not None
        if not has_ttl and not has_count:
            raise ValueError("At least one retention rule must be set")
        if self.idle_ttl_seconds is not None and self.idle_ttl_seconds <= 0:
            raise ValueError("idle_ttl_seconds must be positive")
        if self.hard_age_ttl_seconds is not None and self.hard_age_ttl_seconds <= 0:
            raise ValueError("hard_age_ttl_seconds must be positive")
        if self.max_checkpoints_per_thread is not None and self.max_checkpoints_per_thread < 1:
            raise ValueError("max_checkpoints_per_thread must be >= 1")
