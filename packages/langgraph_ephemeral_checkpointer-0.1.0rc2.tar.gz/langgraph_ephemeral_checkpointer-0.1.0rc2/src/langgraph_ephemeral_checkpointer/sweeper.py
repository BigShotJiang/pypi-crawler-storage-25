from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime

from langgraph.checkpoint.base import BaseCheckpointSaver

from . import _strategies
from ._coordination import AdvisoryLock, get_advisory_lock
from ._strategies._base import Strategy, ThreadTimestamps
from .policy import TTLPolicy
from .result import SweepResult
from .types import OnBeforeDelete, OnSweepComplete, PolicyOverride, PolicyResolver

logger = logging.getLogger(__name__)

_REASON_IDLE = "idle_ttl"
_REASON_AGE = "hard_age_ttl"

# (thread_id, timestamps, human_description) — threads that passed all pre-checks
_DeleteItem = tuple[str, ThreadTimestamps, str]
# (thread_id, keep_count)
_PruneItem = tuple[str, int]

class TTLSweeper:
    """Periodically deletes expired LangGraph threads from any BaseCheckpointSaver.

    The sweeper is a sidecar — it never sits in the hot path.  The graph
    talks directly to the checkpointer; the sweeper independently cleans
    expired threads on its own schedule.
    """

    def __init__(
            self,
            checkpointer: BaseCheckpointSaver,
            policy: TTLPolicy,
            *,
            policy_resolver: PolicyResolver | None = None,
            enable_coordination: bool = False,
            safe_delete: bool = True,
            on_before_delete: OnBeforeDelete | None = None,
            on_sweep_complete: OnSweepComplete | None = None,
    ) -> None:
        self._checkpointer = checkpointer
        self._policy = policy
        self._policy_resolver = policy_resolver
        self._safe_delete = safe_delete
        self._on_before_delete = on_before_delete
        self._on_sweep_complete = on_sweep_complete

        self._strategy: Strategy = _strategies.detect(checkpointer)
        self._advisory_lock: AdvisoryLock | None = get_advisory_lock(
            checkpointer, enable_coordination
        )

        self._task: asyncio.Task | None = None
        self._stop_event: asyncio.Event | None = None
        self._interval_seconds: int = 300

        if (
                policy.max_checkpoints_per_thread is not None
                and not self._strategy.supports_pruning
        ):
            logger.warning(
                "max_checkpoints_per_thread is set but %s does not support count-based "
                "pruning; count limits will not be enforced.  Use InMemorySaver, "
                "SqliteSaver, AsyncSqliteSaver, PostgresSaver, or AsyncPostgresSaver.",
                type(self._strategy).__name__,
            )

    def sweep(self, *, dry_run: bool = False) -> SweepResult:
        """Run a single sweep synchronously and return results."""
        start = time.monotonic()

        lock_acquired = False
        if self._advisory_lock is not None:
            lock_acquired = self._advisory_lock.try_acquire()
            if not lock_acquired:
                logger.info(
                    "Advisory lock held by another sweeper instance; skipping this cycle"
                )
                return SweepResult(
                    deleted_thread_ids=[],
                    pruned_checkpoint_count=0,
                    active_thread_count=0,
                    sweep_duration_seconds=time.monotonic() - start,
                )

        try:
            return self._run_sweep(dry_run=dry_run)
        finally:
            if lock_acquired and self._advisory_lock is not None:
                self._advisory_lock.release()

    async def asweep(self, *, dry_run: bool = False) -> SweepResult:
        """Run a single sweep asynchronously and return results."""
        start = time.monotonic()

        lock_acquired = False
        if self._advisory_lock is not None:
            lock_acquired = await self._advisory_lock.atry_acquire()
            if not lock_acquired:
                logger.info(
                    "Advisory lock held by another sweeper instance; skipping this cycle"
                )
                return SweepResult(
                    deleted_thread_ids=[],
                    pruned_checkpoint_count=0,
                    active_thread_count=0,
                    sweep_duration_seconds=time.monotonic() - start,
                )

        try:
            return await self._arun_sweep(dry_run=dry_run)
        finally:
            if lock_acquired and self._advisory_lock is not None:
                await self._advisory_lock.arelease()

    async def start(self, interval_seconds: int = 300) -> None:
        """Start the background sweep loop."""
        if self._task is not None and not self._task.done():
            raise RuntimeError("Sweeper already running; call stop() first")
        self._interval_seconds = interval_seconds
        self._stop_event = asyncio.Event()
        self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        """Stop the background sweep loop and wait for it to finish."""
        if self._stop_event is not None:
            self._stop_event.set()
        if self._task is not None and not self._task.done():
            await self._task
        self._task = None
        self._stop_event = None

    async def _loop(self) -> None:
        assert self._stop_event is not None
        while True:
            try:
                await self.asweep()
            except Exception:
                logger.exception("Sweep cycle failed, will retry next interval")
            try:
                await asyncio.wait_for(
                    self._stop_event.wait(),
                    timeout=self._interval_seconds,
                )
                break
            except asyncio.TimeoutError:
                pass

    def _run_sweep(self, *, dry_run: bool) -> SweepResult:
        start = time.monotonic()
        timestamps = self._strategy.collect()
        now = time.time()
        dry_ids, to_delete, to_prune = self._plan(timestamps, now, dry_run)

        deleted_ids = list(dry_ids)
        pruned_count = 0
        for tid, ts, human in to_delete:
            if self._safe_delete and not self._safe_check_sync(tid, ts):
                logger.debug("Skipping thread_id=%s: timestamp changed since sweep start", tid)
                continue
            logger.debug("Deleting thread_id=%s (%s)", tid, human)
            self._checkpointer.delete_thread(tid)
            deleted_ids.append(tid)
        for tid, keep_count in to_prune:
            pruned_count += self._strategy.prune(tid, keep_count)

        return self._build_result(timestamps, deleted_ids, pruned_count, start, dry_run)

    async def _arun_sweep(self, *, dry_run: bool) -> SweepResult:
        start = time.monotonic()
        timestamps = await self._strategy.acollect()
        now = time.time()
        dry_ids, to_delete, to_prune = self._plan(timestamps, now, dry_run)

        deleted_ids = list(dry_ids)
        pruned_count = 0
        for tid, ts, human in to_delete:
            if self._safe_delete and not await self._safe_check_async(tid, ts):
                logger.debug("Skipping thread_id=%s: timestamp changed since sweep start", tid)
                continue
            logger.debug("Deleting thread_id=%s (%s)", tid, human)
            await self._checkpointer.adelete_thread(tid)
            deleted_ids.append(tid)
        for tid, keep_count in to_prune:
            pruned_count += await self._strategy.aprune(tid, keep_count)

        return self._build_result(timestamps, deleted_ids, pruned_count, start, dry_run)

    def _plan(
            self,
            timestamps: dict[str, ThreadTimestamps],
            now: float,
            dry_run: bool,
    ) -> tuple[list[str], list[_DeleteItem], list[_PruneItem]]:
        """Pure decision pass — no I/O.

        Returns:
            dry_ids   — thread IDs that would be deleted (dry_run=True only)
            to_delete — (thread_id, ts, human_desc) for threads needing deletion
            to_prune  — (thread_id, keep_count) for threads needing pruning
        """
        dry_ids: list[str] = []
        to_delete: list[_DeleteItem] = []
        to_prune: list[_PruneItem] = []

        for tid, ts in timestamps.items():
            policy = self._resolve_policy(tid)
            if policy is None:
                continue  # EXEMPT

            reason_code = self._expiry_reason_code(ts, now, policy)
            if reason_code:
                human = self._expiry_human(ts, now, policy)
                if dry_run:
                    logger.debug("[DRY RUN] Would delete thread_id=%s (%s)", tid, human)
                    dry_ids.append(tid)
                    continue
                if not self._fire_on_before_delete(tid, policy, reason_code):
                    continue
                to_delete.append((tid, ts, human))

            elif not dry_run and policy.max_checkpoints_per_thread is not None:
                to_prune.append((tid, policy.max_checkpoints_per_thread))

        return dry_ids, to_delete, to_prune

    def _build_result(
            self,
            timestamps: dict[str, ThreadTimestamps],
            deleted_ids: list[str],
            pruned_count: int,
            start: float,
            dry_run: bool,
    ) -> SweepResult:
        result = SweepResult(
            deleted_thread_ids=deleted_ids,
            pruned_checkpoint_count=pruned_count,
            active_thread_count=len(timestamps) - len(deleted_ids),
            sweep_duration_seconds=time.monotonic() - start,
        )
        self._log_result(result, dry_run)
        self._fire_on_sweep_complete(result)
        return result

    def _resolve_policy(self, thread_id: str) -> TTLPolicy | None:
        """Return the effective TTLPolicy for thread_id, or None if exempt."""
        if self._policy_resolver is None:
            return self._policy

        try:
            override = self._policy_resolver(thread_id)
        except Exception:
            logger.exception(
                "policy_resolver raised for thread_id=%s; falling back to global policy",
                thread_id,
            )
            return self._policy

        if isinstance(override, TTLPolicy):
            return override
        if override is PolicyOverride.EXEMPT:
            return None
        return self._policy  # PolicyOverride.USE_DEFAULT

    def _expiry_reason_code(
            self, ts: ThreadTimestamps, now: float, policy: TTLPolicy
    ) -> str | None:
        if policy.idle_ttl_seconds is not None:
            if now - ts.latest_ts > policy.idle_ttl_seconds:
                return _REASON_IDLE
        if policy.hard_age_ttl_seconds is not None:
            if now - ts.earliest_ts > policy.hard_age_ttl_seconds:
                return _REASON_AGE
        return None

    def _expiry_human(
            self, ts: ThreadTimestamps, now: float, policy: TTLPolicy
    ) -> str:
        if policy.idle_ttl_seconds is not None:
            idle = now - ts.latest_ts
            if idle > policy.idle_ttl_seconds:
                return f"idle {idle:.0f}s > {policy.idle_ttl_seconds}s limit"
        if policy.hard_age_ttl_seconds is not None:
            age = now - ts.earliest_ts
            if age > policy.hard_age_ttl_seconds:
                return f"age {age:.0f}s > {policy.hard_age_ttl_seconds}s limit"
        return "expired"

    def _safe_check_sync(self, thread_id: str, original: ThreadTimestamps) -> bool:
        config = {"configurable": {"thread_id": thread_id}}
        current = self._checkpointer.get_tuple(config)
        if current is None:
            return False
        current_ts = datetime.fromisoformat(current.checkpoint["ts"]).timestamp()
        return current_ts <= original.latest_ts + 0.001

    async def _safe_check_async(self, thread_id: str, original: ThreadTimestamps) -> bool:
        config = {"configurable": {"thread_id": thread_id}}
        current = await self._checkpointer.aget_tuple(config)
        if current is None:
            return False
        current_ts = datetime.fromisoformat(current.checkpoint["ts"]).timestamp()
        return current_ts <= original.latest_ts + 0.001

    def _fire_on_before_delete(self, thread_id: str, policy: TTLPolicy, reason: str) -> bool:
        if self._on_before_delete is None:
            return True
        try:
            return bool(self._on_before_delete(thread_id, policy, reason))
        except Exception:
            logger.exception(
                "on_before_delete raised for thread_id=%s; skipping deletion", thread_id
            )
            return False

    def _fire_on_sweep_complete(self, result: SweepResult) -> None:
        if self._on_sweep_complete is None:
            return
        try:
            self._on_sweep_complete(result)
        except Exception:
            logger.exception("on_sweep_complete raised; ignoring")

    def _log_result(self, result: SweepResult, dry_run: bool) -> None:
        if dry_run:
            logger.info(
                "[DRY RUN] Would expire %d threads, %d active (%.2fs)",
                len(result.deleted_thread_ids),
                result.active_thread_count,
                result.sweep_duration_seconds,
            )
        else:
            logger.info(
                "Sweep complete: %d expired, %d pruned, %d active (%.2fs)",
                len(result.deleted_thread_ids),
                result.pruned_checkpoint_count,
                result.active_thread_count,
                result.sweep_duration_seconds,
            )
