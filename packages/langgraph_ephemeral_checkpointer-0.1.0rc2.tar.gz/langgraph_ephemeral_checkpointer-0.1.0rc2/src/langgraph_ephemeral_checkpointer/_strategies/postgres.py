import logging

from ._base import Strategy, ThreadTimestamps, uuid6_to_unix

logger = logging.getLogger(__name__)

_COLLECT_QUERY = """
    SELECT thread_id, MIN(checkpoint_id) AS earliest_id, MAX(checkpoint_id) AS latest_id
    FROM checkpoints
    GROUP BY thread_id
"""

_NS_QUERY = "SELECT DISTINCT checkpoint_ns FROM checkpoints WHERE thread_id = %s"
_COUNT_QUERY = (
    "SELECT COUNT(*) AS cnt FROM checkpoints"
    " WHERE thread_id = %s AND checkpoint_ns = %s"
)
_OLDEST_IDS_QUERY = """
    SELECT checkpoint_id FROM checkpoints
    WHERE thread_id = %s AND checkpoint_ns = %s
    ORDER BY checkpoint_id ASC LIMIT %s
"""
_DELETE_WRITES = (
    "DELETE FROM writes"
    " WHERE thread_id = %s AND checkpoint_ns = %s AND checkpoint_id = ANY(%s)"
)
_DELETE_CHECKPOINTS = (
    "DELETE FROM checkpoints"
    " WHERE thread_id = %s AND checkpoint_ns = %s AND checkpoint_id = ANY(%s)"
)

class PostgresStrategy(Strategy):
    """Optimised strategy for PostgresSaver."""

    def __init__(self, checkpointer) -> None:
        self._checkpointer = checkpointer

    def collect(self) -> dict[str, ThreadTimestamps]:
        try:
            with self._checkpointer._cursor() as cur:
                cur.execute(_COLLECT_QUERY)
                rows = cur.fetchall()
            return {
                row["thread_id"]: ThreadTimestamps(
                    latest_ts=uuid6_to_unix(row["latest_id"]),
                    earliest_ts=uuid6_to_unix(row["earliest_id"]),
                )
                for row in rows
            }
        except Exception:
            logger.debug("Postgres optimised sweep failed, falling back to generic", exc_info=True)
            from .generic import GenericStrategy
            return GenericStrategy(self._checkpointer).collect()

    async def acollect(self) -> dict[str, ThreadTimestamps]:
        from .generic import GenericStrategy
        return await GenericStrategy(self._checkpointer).acollect()

    @property
    def supports_pruning(self) -> bool:
        return True

    def prune(self, thread_id: str, keep_count: int) -> int:
        pruned = 0
        try:
            with self._checkpointer._cursor() as cur:
                cur.execute(_NS_QUERY, (thread_id,))
                namespaces = [row["checkpoint_ns"] for row in cur.fetchall()]

                for ns in namespaces:
                    cur.execute(_COUNT_QUERY, (thread_id, ns))
                    total = cur.fetchone()["cnt"]
                    excess = total - keep_count
                    if excess <= 0:
                        continue

                    cur.execute(_OLDEST_IDS_QUERY, (thread_id, ns, excess))
                    cp_ids = [row["checkpoint_id"] for row in cur.fetchall()]
                    if not cp_ids:
                        continue

                    cur.execute(_DELETE_WRITES, (thread_id, ns, cp_ids))
                    cur.execute(_DELETE_CHECKPOINTS, (thread_id, ns, cp_ids))
                    pruned += len(cp_ids)
        except Exception:
            logger.debug("Postgres pruning failed for thread_id=%s", thread_id, exc_info=True)

        return pruned

    async def aprune(self, thread_id: str, keep_count: int) -> int:
        from .generic import GenericStrategy
        # Sync-only saver; delegate upward if somehow called async
        return self.prune(thread_id, keep_count)

class AsyncPostgresStrategy(Strategy):
    """Optimised strategy for AsyncPostgresSaver."""

    def __init__(self, checkpointer) -> None:
        self._checkpointer = checkpointer

    def collect(self) -> dict[str, ThreadTimestamps]:
        from .generic import GenericStrategy
        return GenericStrategy(self._checkpointer).collect()

    async def acollect(self) -> dict[str, ThreadTimestamps]:
        try:
            async with self._checkpointer._cursor() as cur:
                await cur.execute(_COLLECT_QUERY)
                rows = await cur.fetchall()
            return {
                row["thread_id"]: ThreadTimestamps(
                    latest_ts=uuid6_to_unix(row["latest_id"]),
                    earliest_ts=uuid6_to_unix(row["earliest_id"]),
                )
                for row in rows
            }
        except Exception:
            logger.debug("AsyncPostgres optimised sweep failed, falling back to generic", exc_info=True)
            from .generic import GenericStrategy
            return await GenericStrategy(self._checkpointer).acollect()

    @property
    def supports_pruning(self) -> bool:
        return True

    async def aprune(self, thread_id: str, keep_count: int) -> int:
        pruned = 0
        try:
            async with self._checkpointer._cursor() as cur:
                await cur.execute(_NS_QUERY, (thread_id,))
                namespaces = [row["checkpoint_ns"] for row in await cur.fetchall()]

                for ns in namespaces:
                    await cur.execute(_COUNT_QUERY, (thread_id, ns))
                    total = (await cur.fetchone())["cnt"]
                    excess = total - keep_count
                    if excess <= 0:
                        continue

                    await cur.execute(_OLDEST_IDS_QUERY, (thread_id, ns, excess))
                    cp_ids = [row["checkpoint_id"] for row in await cur.fetchall()]
                    if not cp_ids:
                        continue

                    await cur.execute(_DELETE_WRITES, (thread_id, ns, cp_ids))
                    await cur.execute(_DELETE_CHECKPOINTS, (thread_id, ns, cp_ids))
                    pruned += len(cp_ids)
        except Exception:
            logger.debug("AsyncPostgres pruning failed for thread_id=%s", thread_id, exc_info=True)

        return pruned
