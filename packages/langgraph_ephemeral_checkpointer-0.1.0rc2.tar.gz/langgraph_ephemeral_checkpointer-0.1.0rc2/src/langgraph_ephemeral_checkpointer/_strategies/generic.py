from datetime import datetime

from langgraph.checkpoint.base import BaseCheckpointSaver

from ._base import Strategy, ThreadTimestamps

class GenericStrategy(Strategy):
    def __init__(self, checkpointer: BaseCheckpointSaver) -> None:
        self._checkpointer = checkpointer

    def collect(self) -> dict[str, ThreadTimestamps]:
        threads: dict[str, ThreadTimestamps] = {}
        for tup in self._checkpointer.list(None):
            tid = tup.config["configurable"]["thread_id"]
            ts = datetime.fromisoformat(tup.checkpoint["ts"]).timestamp()
            if tid not in threads:
                threads[tid] = ThreadTimestamps(latest_ts=ts, earliest_ts=ts)
            else:
                entry = threads[tid]
                if ts > entry.latest_ts:
                    entry.latest_ts = ts
                if ts < entry.earliest_ts:
                    entry.earliest_ts = ts
        return threads

    async def acollect(self) -> dict[str, ThreadTimestamps]:
        threads: dict[str, ThreadTimestamps] = {}
        async for tup in self._checkpointer.alist(None):
            tid = tup.config["configurable"]["thread_id"]
            ts = datetime.fromisoformat(tup.checkpoint["ts"]).timestamp()
            if tid not in threads:
                threads[tid] = ThreadTimestamps(latest_ts=ts, earliest_ts=ts)
            else:
                entry = threads[tid]
                if ts > entry.latest_ts:
                    entry.latest_ts = ts
                if ts < entry.earliest_ts:
                    entry.earliest_ts = ts
        return threads
