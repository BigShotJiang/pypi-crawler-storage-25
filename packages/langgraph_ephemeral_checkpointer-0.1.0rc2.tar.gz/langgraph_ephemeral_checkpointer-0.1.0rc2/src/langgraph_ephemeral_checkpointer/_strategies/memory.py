from langgraph.checkpoint.memory import InMemorySaver

from ._base import Strategy, ThreadTimestamps, uuid6_to_unix

class MemoryStrategy(Strategy):
    """Optimised strategy for InMemorySaver — reads storage dict directly,
    extracting timestamps from UUIDv6 checkpoint IDs without deserialising blobs."""

    def __init__(self, checkpointer: InMemorySaver) -> None:
        self._checkpointer = checkpointer

    def _do_collect(self) -> dict[str, ThreadTimestamps]:
        threads: dict[str, ThreadTimestamps] = {}
        for thread_id, ns_dict in self._checkpointer.storage.items():
            all_cp_ids = [
                cp_id
                for cp_dict in ns_dict.values()
                for cp_id in cp_dict
            ]
            if not all_cp_ids:
                continue
            threads[thread_id] = ThreadTimestamps(
                latest_ts=uuid6_to_unix(max(all_cp_ids)),
                earliest_ts=uuid6_to_unix(min(all_cp_ids)),
            )
        return threads

    def collect(self) -> dict[str, ThreadTimestamps]:
        return self._do_collect()

    async def acollect(self) -> dict[str, ThreadTimestamps]:
        return self._do_collect()

    @property
    def supports_pruning(self) -> bool:
        return True

    def _do_prune(self, thread_id: str, keep_count: int) -> int:
        if thread_id not in self._checkpointer.storage:
            return 0
        pruned = 0
        for ns, cp_dict in self._checkpointer.storage[thread_id].items():
            excess = len(cp_dict) - keep_count
            if excess <= 0:
                continue
            # Smallest UUIDv6 = oldest checkpoint
            oldest_ids = sorted(cp_dict.keys())[:excess]
            for cp_id in oldest_ids:
                del cp_dict[cp_id]
                key = (thread_id, ns, cp_id)
                self._checkpointer.writes.pop(key, None)
                # Remove associated blobs
                for bk in list(self._checkpointer.blobs.keys()):
                    if bk[0] == thread_id:
                        # Blobs are keyed by (thread_id, checkpoint_ns, channel, version)
                        # We can't easily correlate to a specific checkpoint_id without
                        # deserialising; leave orphaned blobs — they are evicted on
                        # delete_thread() or when storage is cleared.
                        pass
                pruned += 1
        return pruned

    def prune(self, thread_id: str, keep_count: int) -> int:
        return self._do_prune(thread_id, keep_count)

    async def aprune(self, thread_id: str, keep_count: int) -> int:
        return self._do_prune(thread_id, keep_count)
