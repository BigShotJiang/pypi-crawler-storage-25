import logging

from ._base import Strategy, ThreadTimestamps, uuid6_to_unix

logger = logging.getLogger(__name__)

_COLLECT_QUERY = """
    SELECT thread_id, MIN(checkpoint_id) AS earliest_id, MAX(checkpoint_id) AS latest_id
    FROM checkpoints
    GROUP BY thread_id
"""

_NS_QUERY = "SELECT DISTINCT checkpoint_ns FROM checkpoints WHERE thread_id = ?"
_COUNT_QUERY = "SELECT COUNT(*) FROM checkpoints WHERE thread_id = ? AND checkpoint_ns = ?"
_OLDEST_IDS_QUERY = """
    SELECT checkpoint_id FROM checkpoints
    WHERE thread_id = ? AND checkpoint_ns = ?
    ORDER BY checkpoint_id ASC LIMIT ?
"""

class SqliteStrategy(Strategy):
    """Optimised strategy for SqliteSaver — single GROUP BY query instead of
    iterating all checkpoints through Python."""

    def __init__(self, checkpointer) -> None:
        self._checkpointer = checkpointer

    def collect(self) -> dict[str, ThreadTimestamps]:
        try:
            with self._checkpointer.cursor(transaction=False) as cur:
                cur.execute(_COLLECT_QUERY)
                rows = cur.fetchall()
            return {
                thread_id: ThreadTimestamps(
                    latest_ts=uuid6_to_unix(latest_id),
                    earliest_ts=uuid6_to_unix(earliest_id),
                )
                for thread_id, earliest_id, latest_id in rows
            }
        except Exception:
            logger.debug("SQLite optimised sweep failed, falling back to generic", exc_info=True)
            from .generic import GenericStrategy
            return GenericStrategy(self._checkpointer).collect()

    async def acollect(self) -> dict[str, ThreadTimestamps]:
        from .generic import GenericStrategy
        return await GenericStrategy(self._checkpointer).acollect()

    @property
    def supports_pruning(self) -> bool:
        return True

    def _do_prune(self, thread_id: str, keep_count: int) -> int:
        pruned = 0
        try:
            with self._checkpointer.cursor(transaction=False) as cur:
                cur.execute(_NS_QUERY, (thread_id,))
                namespaces = [r[0] for r in cur.fetchall()]

            for ns in namespaces:
                with self._checkpointer.cursor(transaction=False) as cur:
                    cur.execute(_COUNT_QUERY, (thread_id, ns))
                    total = cur.fetchone()[0]

                excess = total - keep_count
                if excess <= 0:
                    continue

                with self._checkpointer.cursor(transaction=False) as cur:
                    cur.execute(_OLDEST_IDS_QUERY, (thread_id, ns, excess))
                    cp_ids = [r[0] for r in cur.fetchall()]

                if not cp_ids:
                    continue

                placeholders = ",".join("?" * len(cp_ids))
                with self._checkpointer.cursor(transaction=True) as cur:
                    cur.execute(
                        f"DELETE FROM writes WHERE thread_id = ? AND checkpoint_ns = ?"
                        f" AND checkpoint_id IN ({placeholders})",
                        (thread_id, ns, *cp_ids),
                    )
                    cur.execute(
                        f"DELETE FROM checkpoints WHERE thread_id = ? AND checkpoint_ns = ?"
                        f" AND checkpoint_id IN ({placeholders})",
                        (thread_id, ns, *cp_ids),
                    )
                    pruned += len(cp_ids)
        except Exception:
            logger.debug("SQLite pruning failed for thread_id=%s", thread_id, exc_info=True)

        return pruned

    def prune(self, thread_id: str, keep_count: int) -> int:
        return self._do_prune(thread_id, keep_count)

    async def aprune(self, thread_id: str, keep_count: int) -> int:
        # SqliteSaver is sync-only under the hood
        return self._do_prune(thread_id, keep_count)

class AsyncSqliteStrategy(Strategy):
    """Optimised strategy for AsyncSqliteSaver."""

    def __init__(self, checkpointer) -> None:
        self._checkpointer = checkpointer

    def collect(self) -> dict[str, ThreadTimestamps]:
        from .generic import GenericStrategy
        return GenericStrategy(self._checkpointer).collect()

    async def acollect(self) -> dict[str, ThreadTimestamps]:
        try:
            await self._checkpointer.setup()
            async with (
                self._checkpointer.lock,
                self._checkpointer.conn.execute(_COLLECT_QUERY) as cur,
            ):
                rows = await cur.fetchall()
            return {
                thread_id: ThreadTimestamps(
                    latest_ts=uuid6_to_unix(latest_id),
                    earliest_ts=uuid6_to_unix(earliest_id),
                )
                for thread_id, earliest_id, latest_id in rows
            }
        except Exception:
            logger.debug("AsyncSQLite optimised sweep failed, falling back to generic", exc_info=True)
            from .generic import GenericStrategy
            return await GenericStrategy(self._checkpointer).acollect()

    @property
    def supports_pruning(self) -> bool:
        return True

    async def aprune(self, thread_id: str, keep_count: int) -> int:
        pruned = 0
        try:
            await self._checkpointer.setup()
            async with self._checkpointer.lock:
                async with self._checkpointer.conn.execute(
                    _NS_QUERY, (thread_id,)
                ) as cur:
                    ns_rows = await cur.fetchall()
                namespaces = [r[0] for r in ns_rows]

                for ns in namespaces:
                    async with self._checkpointer.conn.execute(
                        _COUNT_QUERY, (thread_id, ns)
                    ) as cur:
                        total = (await cur.fetchone())[0]

                    excess = total - keep_count
                    if excess <= 0:
                        continue

                    async with self._checkpointer.conn.execute(
                        _OLDEST_IDS_QUERY, (thread_id, ns, excess)
                    ) as cur:
                        cp_ids = [r[0] for r in await cur.fetchall()]

                    if not cp_ids:
                        continue

                    placeholders = ",".join("?" * len(cp_ids))
                    await self._checkpointer.conn.execute(
                        f"DELETE FROM writes WHERE thread_id = ? AND checkpoint_ns = ?"
                        f" AND checkpoint_id IN ({placeholders})",
                        (thread_id, ns, *cp_ids),
                    )
                    await self._checkpointer.conn.execute(
                        f"DELETE FROM checkpoints WHERE thread_id = ? AND checkpoint_ns = ?"
                        f" AND checkpoint_id IN ({placeholders})",
                        (thread_id, ns, *cp_ids),
                    )
                    await self._checkpointer.conn.commit()
                    pruned += len(cp_ids)
        except Exception:
            logger.debug("AsyncSQLite pruning failed for thread_id=%s", thread_id, exc_info=True)

        return pruned
