from abc import ABC, abstractmethod
from dataclasses import dataclass
import uuid as _uuid_mod

# Offset between UUID epoch (1582-10-15) and Unix epoch (1970-01-01) in 100-ns intervals
_UUID_EPOCH_OFFSET = 0x01B21DD213814000

@dataclass
class ThreadTimestamps:
    latest_ts: float    # unix timestamp seconds
    earliest_ts: float  # unix timestamp seconds

class Strategy(ABC):
    @abstractmethod
    def collect(self) -> dict[str, ThreadTimestamps]: ...

    @abstractmethod
    async def acollect(self) -> dict[str, ThreadTimestamps]: ...

    def prune(self, thread_id: str, keep_count: int) -> int:
        """Delete oldest checkpoints so at most keep_count remain.

        Returns the number of checkpoints deleted.  The default returns 0
        (pruning not supported by this strategy).
        """
        return 0

    async def aprune(self, thread_id: str, keep_count: int) -> int:
        """Async variant of prune().  Default returns 0."""
        return 0

    @property
    def supports_pruning(self) -> bool:
        """True if this strategy can enforce max_checkpoints_per_thread."""
        return False

def uuid6_to_unix(uuid_str: str | object) -> float:
    """Extract unix timestamp from a UUIDv6 checkpoint ID."""
    u = _uuid_mod.UUID(str(uuid_str))
    i = u.int
    time_high_and_mid = (i >> 80) & 0xFFFFFFFFFFFF
    time_low = (i >> 64) & 0x0FFF
    timestamp = (time_high_and_mid << 12) | time_low
    return (timestamp - _UUID_EPOCH_OFFSET) * 100 / 1e9
