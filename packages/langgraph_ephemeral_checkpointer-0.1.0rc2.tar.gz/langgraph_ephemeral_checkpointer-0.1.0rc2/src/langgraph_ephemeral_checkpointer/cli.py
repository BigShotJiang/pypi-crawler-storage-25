"""Command-line interface for langgraph-ephemeral-checkpointer.

Usage:
    python -m langgraph_ephemeral_checkpointer status --backend sqlite --dsn db.sqlite --idle-ttl 3600
    python -m langgraph_ephemeral_checkpointer sweep  --backend sqlite --dsn db.sqlite --idle-ttl 3600
    python -m langgraph_ephemeral_checkpointer sweep  --backend sqlite --dsn db.sqlite --idle-ttl 3600 --dry-run
"""

import sys
import time
from contextlib import contextmanager
from typing import Literal

from clypi import Command, arg

from .policy import TTLPolicy
from .result import SweepResult
from .sweeper import TTLSweeper

@contextmanager
def _open_checkpointer(backend: str, dsn: str | None):
    if backend == "memory":
        from langgraph.checkpoint.memory import InMemorySaver
        yield InMemorySaver()

    elif backend == "sqlite":
        if not dsn:
            print("error: --dsn is required for the sqlite backend", file=sys.stderr)
            sys.exit(1)
        try:
            from langgraph.checkpoint.sqlite import SqliteSaver
        except ImportError:
            print("error: langgraph-checkpoint-sqlite is not installed", file=sys.stderr)
            sys.exit(1)
        with SqliteSaver.from_conn_string(dsn) as saver:
            saver.setup()
            yield saver

    elif backend == "postgres":
        if not dsn:
            print("error: --dsn is required for the postgres backend", file=sys.stderr)
            sys.exit(1)
        try:
            from langgraph.checkpoint.postgres import PostgresSaver
        except ImportError:
            print("error: langgraph-checkpoint-postgres is not installed", file=sys.stderr)
            sys.exit(1)
        with PostgresSaver.from_conn_string(dsn) as saver:
            saver.setup()
            yield saver

    else:
        print(f"error: Unknown backend '{backend}'. Choose from: memory, sqlite, postgres", file=sys.stderr)
        sys.exit(1)

def _count_checkpoints(checkpointer) -> dict[str, int]:
    counts: dict[str, int] = {}
    for tup in checkpointer.list(None):
        tid = tup.config["configurable"]["thread_id"]
        counts[tid] = counts.get(tid, 0) + 1
    return counts

def _fmt_seconds(s: float) -> str:
    s = int(s)
    if s < 60:
        return f"{s}s"
    m, sec = divmod(s, 60)
    if m < 60:
        return f"{m}m {sec}s"
    h, min_ = divmod(m, 60)
    return f"{h}h {min_}m"

def _policy_desc(policy: TTLPolicy) -> str:
    parts = []
    if policy.idle_ttl_seconds is not None:
        parts.append(f"idle={policy.idle_ttl_seconds}s")
    if policy.hard_age_ttl_seconds is not None:
        parts.append(f"hard_age={policy.hard_age_ttl_seconds}s")
    if policy.max_checkpoints_per_thread is not None:
        parts.append(f"max_checkpoints={policy.max_checkpoints_per_thread}")
    return ", ".join(parts)

def _build_policy(
    idle_ttl: int | None,
    hard_age_ttl: int | None,
    max_checkpoints: int | None,
) -> TTLPolicy:
    if not any([idle_ttl, hard_age_ttl, max_checkpoints]):
        print(
            "error: At least one of --idle-ttl, --hard-age-ttl, or --max-checkpoints is required.",
            file=sys.stderr,
        )
        sys.exit(1)
    return TTLPolicy(
        idle_ttl_seconds=idle_ttl,
        hard_age_ttl_seconds=hard_age_ttl,
        max_checkpoints_per_thread=max_checkpoints,
    )

class Status(Command):
    """Show all threads with their ages, idle time, and TTL status."""

    backend: Literal["memory", "sqlite", "postgres"] = arg(help="Checkpointer backend.")
    dsn: str | None = arg(None, help="Connection string or file path.")
    idle_ttl: int | None = arg(None, help="Idle TTL in seconds.")
    hard_age_ttl: int | None = arg(None, help="Hard age TTL in seconds.")
    max_checkpoints: int | None = arg(None, help="Max checkpoints per thread.")

    async def run(self) -> None:
        policy = _build_policy(self.idle_ttl, self.hard_age_ttl, self.max_checkpoints)

        with _open_checkpointer(self.backend, self.dsn) as checkpointer:
            from ._strategies import detect
            strategy = detect(checkpointer)
            timestamps = strategy.collect()
            counts = _count_checkpoints(checkpointer)
            now = time.time()

            if not timestamps:
                print("No threads found.")
                return

            sweeper = TTLSweeper(checkpointer, policy)
            rows = []
            for tid, ts in sorted(timestamps.items()):
                age_s = now - ts.earliest_ts
                idle_s = now - ts.latest_ts
                cp_count = counts.get(tid, 0)
                reason = sweeper._expiry_reason_code(ts, now, policy)
                if reason is None:
                    status = "active"
                elif reason == "idle_ttl":
                    status = "EXPIRED (idle)"
                elif reason == "hard_age_ttl":
                    status = "EXPIRED (hard_age)"
                else:
                    status = f"EXPIRED ({reason})"
                rows.append((tid, age_s, idle_s, cp_count, status))

            expired_count = sum(1 for _, _, _, _, s in rows if s.startswith("EXPIRED"))

            hdr = f"{'thread_id':<32}  {'age':>9}  {'idle':>9}  {'checkpoints':>11}  status"
            sep = "-" * len(hdr)
            print(f"\nThread Status (policy: {_policy_desc(policy)})")
            print(sep)
            print(hdr)
            print(sep)
            for tid, age_s, idle_s, cp_count, status in rows:
                print(
                    f"{tid:<32}  {_fmt_seconds(age_s):>9}  {_fmt_seconds(idle_s):>9}"
                    f"  {cp_count:>11}  {status}"
                )
            print(sep)
            print(f"Total: {len(rows)} threads ({expired_count} would be expired)")
            print()

class Sweep(Command):
    """Delete expired threads based on TTL policy."""

    backend: Literal["memory", "sqlite", "postgres"] = arg(help="Checkpointer backend.")
    dsn: str | None = arg(None, help="Connection string or file path.")
    idle_ttl: int | None = arg(None, help="Idle TTL in seconds.")
    hard_age_ttl: int | None = arg(None, help="Hard age TTL in seconds.")
    max_checkpoints: int | None = arg(None, help="Max checkpoints per thread.")
    dry_run: bool = arg(False, help="Preview deletions without actually deleting.")

    async def run(self) -> None:
        policy = _build_policy(self.idle_ttl, self.hard_age_ttl, self.max_checkpoints)

        with _open_checkpointer(self.backend, self.dsn) as checkpointer:
            sweeper = TTLSweeper(checkpointer, policy)
            result: SweepResult = sweeper.sweep(dry_run=self.dry_run)

        prefix = "[DRY RUN] " if self.dry_run else ""
        verb = "Would delete" if self.dry_run else "Deleted"
        print(
            f"{prefix}{verb} {len(result.deleted_thread_ids)} thread(s), "
            f"{result.active_thread_count} active "
            f"({result.sweep_duration_seconds:.2f}s)"
        )
        if result.pruned_checkpoint_count:
            print(f"{prefix}Pruned {result.pruned_checkpoint_count} checkpoint(s)")
        if result.deleted_thread_ids:
            print(f"{verb}: {', '.join(result.deleted_thread_ids)}")

class Cli(Command):
    """Inspect and sweep expired LangGraph threads."""

    subcommand: Status | Sweep

def main() -> None:
    Cli.parse().start()
