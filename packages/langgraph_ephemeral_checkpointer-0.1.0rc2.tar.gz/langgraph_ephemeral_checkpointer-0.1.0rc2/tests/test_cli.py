"""Tests for the CLI (status and sweep subcommands, §14.7)."""
import sys
from collections.abc import AsyncIterator, Iterator
from contextlib import contextmanager
from unittest.mock import patch

import pytest
from langgraph.checkpoint.base import BaseCheckpointSaver, CheckpointTuple

from langgraph_ephemeral_checkpointer.cli import (
    Cli,
    Status,
    Sweep,
    _build_policy,
    _fmt_seconds,
    _policy_desc,
)
from langgraph_ephemeral_checkpointer.policy import TTLPolicy

from .conftest import iso_ts, make_checkpoint_tuple

FAKE_CP_ID = "1f1411e3-4e80-62b6-8001-eb2883608248"

def test_fmt_seconds_sub_minute():
    assert _fmt_seconds(45) == "45s"

def test_fmt_seconds_minutes():
    assert _fmt_seconds(125) == "2m 5s"

def test_fmt_seconds_hours():
    assert _fmt_seconds(3661) == "1h 1m"

def test_policy_desc_idle_only():
    p = TTLPolicy(idle_ttl_seconds=3600)
    assert _policy_desc(p) == "idle=3600s"

def test_policy_desc_all_fields():
    p = TTLPolicy(idle_ttl_seconds=60, hard_age_ttl_seconds=120, max_checkpoints_per_thread=5)
    desc = _policy_desc(p)
    assert "idle=60s" in desc
    assert "hard_age=120s" in desc
    assert "max_checkpoints=5" in desc

def test_build_policy_idle_ttl():
    p = _build_policy(idle_ttl=3600, hard_age_ttl=None, max_checkpoints=None)
    assert p.idle_ttl_seconds == 3600
    assert p.hard_age_ttl_seconds is None

def test_build_policy_all_fields():
    p = _build_policy(idle_ttl=60, hard_age_ttl=120, max_checkpoints=5)
    assert p.idle_ttl_seconds == 60
    assert p.hard_age_ttl_seconds == 120
    assert p.max_checkpoints_per_thread == 5

def test_build_policy_no_ttl_exits():
    with pytest.raises(SystemExit):
        _build_policy(idle_ttl=None, hard_age_ttl=None, max_checkpoints=None)

def test_sweep_parses_dry_run_flag():
    cmd = Sweep.parse(["--backend", "memory", "--idle-ttl", "3600", "--dry-run"])
    assert cmd.dry_run is True
    assert cmd.idle_ttl == 3600
    assert cmd.backend == "memory"

def test_status_parses_idle_ttl():
    cmd = Status.parse(["--backend", "memory", "--idle-ttl", "60"])
    assert cmd.idle_ttl == 60
    assert cmd.backend == "memory"

def test_cli_requires_subcommand():
    with pytest.raises(SystemExit):
        Cli.parse([])

class MockCP(BaseCheckpointSaver):
    def __init__(self, tuples):
        super().__init__()
        self._tuples = tuples
        self.deleted: list[str] = []

    def list(self, config, **kwargs) -> Iterator[CheckpointTuple]:
        return iter(self._tuples)

    async def alist(self, config, **kwargs) -> AsyncIterator[CheckpointTuple]:
        for t in self._tuples:
            yield t

    def get_tuple(self, config):
        tid = config["configurable"].get("thread_id")
        for t in reversed(self._tuples):
            if t.config["configurable"]["thread_id"] == tid:
                return t
        return None

    async def aget_tuple(self, config):
        return self.get_tuple(config)

    def put(self, config, checkpoint, metadata, new_versions):
        return config

    def put_writes(self, config, writes, task_id, task_path=()):
        pass

    def delete_thread(self, thread_id):
        self.deleted.append(thread_id)

    async def adelete_thread(self, thread_id):
        self.deleted.append(thread_id)

@contextmanager
def _mock_open(cp):
    yield cp

@pytest.mark.asyncio
async def test_sweep_empty_store(capsys):
    cmd = Sweep(backend="memory", dsn=None, idle_ttl=3600)
    await cmd.run()
    out = capsys.readouterr().out
    assert "Deleted 0 thread(s)" in out

@pytest.mark.asyncio
async def test_sweep_dry_run_prefix(capsys):
    cmd = Sweep(backend="memory", dsn=None, idle_ttl=3600, dry_run=True)
    await cmd.run()
    out = capsys.readouterr().out
    assert "[DRY RUN]" in out
    assert "Would delete" in out

@pytest.mark.asyncio
async def test_sweep_reports_deleted(capsys):
    tuples = [make_checkpoint_tuple("t1", FAKE_CP_ID, iso_ts(-7200))]
    cp = MockCP(tuples)

    with patch("langgraph_ephemeral_checkpointer.cli._open_checkpointer", return_value=_mock_open(cp)):
        cmd = Sweep(backend="memory", dsn=None, idle_ttl=60)
        await cmd.run()

    out = capsys.readouterr().out
    assert "Deleted 1 thread(s)" in out
    assert "t1" in out

@pytest.mark.asyncio
async def test_sweep_dry_run_does_not_delete(capsys):
    tuples = [make_checkpoint_tuple("t1", FAKE_CP_ID, iso_ts(-7200))]
    cp = MockCP(tuples)

    with patch("langgraph_ephemeral_checkpointer.cli._open_checkpointer", return_value=_mock_open(cp)):
        cmd = Sweep(backend="memory", dsn=None, idle_ttl=60, dry_run=True)
        await cmd.run()

    out = capsys.readouterr().out
    assert "[DRY RUN]" in out
    assert "Would delete 1 thread(s)" in out
    assert cp.deleted == []

@pytest.mark.asyncio
async def test_status_empty_store(capsys):
    cp = MockCP([])

    with patch("langgraph_ephemeral_checkpointer.cli._open_checkpointer", return_value=_mock_open(cp)):
        cmd = Status(backend="memory", dsn=None, idle_ttl=3600)
        await cmd.run()

    out = capsys.readouterr().out
    assert "No threads found" in out

@pytest.mark.asyncio
async def test_status_shows_expired_thread(capsys):
    tuples = [make_checkpoint_tuple("mythread", FAKE_CP_ID, iso_ts(-7200))]
    cp = MockCP(tuples)

    with patch("langgraph_ephemeral_checkpointer.cli._open_checkpointer", return_value=_mock_open(cp)):
        cmd = Status(backend="memory", dsn=None, idle_ttl=3600)
        await cmd.run()

    out = capsys.readouterr().out
    assert "mythread" in out
    assert "EXPIRED" in out

@pytest.mark.asyncio
async def test_status_shows_active_thread(capsys):
    tuples = [make_checkpoint_tuple("fresh", FAKE_CP_ID, iso_ts(-10))]
    cp = MockCP(tuples)

    with patch("langgraph_ephemeral_checkpointer.cli._open_checkpointer", return_value=_mock_open(cp)):
        cmd = Status(backend="memory", dsn=None, idle_ttl=3600)
        await cmd.run()

    out = capsys.readouterr().out
    assert "fresh" in out
    assert "active" in out

@pytest.mark.asyncio
async def test_sqlite_without_dsn_exits():
    cmd = Sweep(backend="sqlite", dsn=None, idle_ttl=60)
    with pytest.raises(SystemExit):
        await cmd.run()

@pytest.mark.asyncio
async def test_sweep_no_ttl_exits():
    cmd = Sweep(backend="memory", dsn=None)
    with pytest.raises(SystemExit):
        await cmd.run()
