import asyncio
from collections.abc import AsyncIterator, Iterator
from unittest.mock import patch

import pytest
from langgraph.checkpoint.base import BaseCheckpointSaver, CheckpointTuple

from langgraph_ephemeral_checkpointer import TTLPolicy, TTLSweeper
from langgraph_ephemeral_checkpointer.result import SweepResult

from .conftest import iso_ts, make_checkpoint_tuple

class MockCheckpointer(BaseCheckpointSaver):
    def __init__(self, tuples: list[CheckpointTuple]) -> None:
        super().__init__()
        self._tuples = tuples
        self.deleted: list[str] = []

    def list(self, config, **kwargs) -> Iterator[CheckpointTuple]:
        return iter(self._tuples)

    async def alist(self, config, **kwargs) -> AsyncIterator[CheckpointTuple]:
        for t in self._tuples:
            yield t

    def get_tuple(self, config) -> CheckpointTuple | None:
        tid = config["configurable"].get("thread_id")
        for t in reversed(self._tuples):
            if t.config["configurable"]["thread_id"] == tid:
                return t
        return None

    async def aget_tuple(self, config) -> CheckpointTuple | None:
        return self.get_tuple(config)

    def put(self, config, checkpoint, metadata, new_versions):
        return config

    def put_writes(self, config, writes, task_id, task_path=()):
        pass

    def delete_thread(self, thread_id: str) -> None:
        self.deleted.append(thread_id)

    async def adelete_thread(self, thread_id: str) -> None:
        self.deleted.append(thread_id)

FAKE_CP_ID = "1f1411e3-4e80-62b6-8001-eb2883608248"

def _make_sweeper(tuples, **policy_kwargs):
    cp = MockCheckpointer(tuples)
    policy = TTLPolicy(**policy_kwargs)
    return TTLSweeper(cp, policy), cp

def test_sweep_deletes_idle_expired():
    tuples = [
        make_checkpoint_tuple("expired", FAKE_CP_ID, iso_ts(-3700)),
        make_checkpoint_tuple("active", FAKE_CP_ID, iso_ts(-10)),
    ]
    sweeper, cp = _make_sweeper(tuples, idle_ttl_seconds=3600)
    result = sweeper.sweep()

    assert result.deleted_thread_ids == ["expired"]
    assert result.active_thread_count == 1
    assert result.pruned_checkpoint_count == 0
    assert "expired" in cp.deleted
    assert "active" not in cp.deleted

def test_sweep_keeps_active():
    tuples = [make_checkpoint_tuple("alive", FAKE_CP_ID, iso_ts(-10))]
    sweeper, cp = _make_sweeper(tuples, idle_ttl_seconds=3600)
    result = sweeper.sweep()

    assert result.deleted_thread_ids == []
    assert result.active_thread_count == 1
    assert cp.deleted == []

def test_sweep_hard_age_expired():
    tuples = [
        make_checkpoint_tuple("old", FAKE_CP_ID, iso_ts(-90000)),
        make_checkpoint_tuple("young", FAKE_CP_ID, iso_ts(-100)),
    ]
    sweeper, cp = _make_sweeper(tuples, hard_age_ttl_seconds=86400)
    result = sweeper.sweep()

    assert "old" in result.deleted_thread_ids
    assert "young" not in result.deleted_thread_ids

def test_sweep_or_logic_idle_triggers():
    tuples = [make_checkpoint_tuple("t", FAKE_CP_ID, iso_ts(-100))]
    sweeper, _ = _make_sweeper(tuples, idle_ttl_seconds=60, hard_age_ttl_seconds=86400)
    result = sweeper.sweep()
    assert "t" in result.deleted_thread_ids

def test_sweep_or_logic_hard_age_triggers():
    old_id = "1e0000e3-4e80-62b6-8001-000000000000"
    tuples = [
        make_checkpoint_tuple("t", old_id, iso_ts(-100000)),
        make_checkpoint_tuple("t", FAKE_CP_ID, iso_ts(-10)),
    ]
    sweeper, _ = _make_sweeper(tuples, idle_ttl_seconds=3600, hard_age_ttl_seconds=86400)
    result = sweeper.sweep()
    assert "t" in result.deleted_thread_ids

def test_sweep_result_fields():
    tuples = [
        make_checkpoint_tuple("e", FAKE_CP_ID, iso_ts(-3700)),
        make_checkpoint_tuple("a1", FAKE_CP_ID, iso_ts(-10)),
        make_checkpoint_tuple("a2", FAKE_CP_ID, iso_ts(-20)),
    ]
    sweeper, _ = _make_sweeper(tuples, idle_ttl_seconds=3600)
    result = sweeper.sweep()

    assert isinstance(result, SweepResult)
    assert result.active_thread_count == 2
    assert result.pruned_checkpoint_count == 0
    assert result.sweep_duration_seconds >= 0

def test_sweep_empty_checkpointer():
    sweeper, cp = _make_sweeper([], idle_ttl_seconds=60)
    result = sweeper.sweep()
    assert result.deleted_thread_ids == []
    assert result.active_thread_count == 0
    assert result.pruned_checkpoint_count == 0

@pytest.mark.asyncio
async def test_asweep_same_as_sweep():
    tuples = [
        make_checkpoint_tuple("expired", FAKE_CP_ID, iso_ts(-3700)),
        make_checkpoint_tuple("active", FAKE_CP_ID, iso_ts(-10)),
    ]
    cp = MockCheckpointer(tuples)
    sweeper = TTLSweeper(cp, TTLPolicy(idle_ttl_seconds=3600))

    result = await sweeper.asweep()
    assert result.deleted_thread_ids == ["expired"]
    assert result.active_thread_count == 1
    assert "expired" in cp.deleted

@pytest.mark.asyncio
async def test_start_stop_lifecycle():
    tuples = [make_checkpoint_tuple("t", FAKE_CP_ID, iso_ts(-10))]
    cp = MockCheckpointer(tuples)
    sweeper = TTLSweeper(cp, TTLPolicy(idle_ttl_seconds=3600))

    await sweeper.start(interval_seconds=600)
    assert sweeper._task is not None
    assert not sweeper._task.done()

    await asyncio.sleep(0.05)

    await sweeper.stop()
    assert sweeper._task is None

@pytest.mark.asyncio
async def test_start_twice_raises():
    cp = MockCheckpointer([])
    sweeper = TTLSweeper(cp, TTLPolicy(idle_ttl_seconds=60))
    await sweeper.start(interval_seconds=600)
    try:
        with pytest.raises(RuntimeError, match="already running"):
            await sweeper.start(interval_seconds=600)
    finally:
        await sweeper.stop()

@pytest.mark.asyncio
async def test_loop_survives_exception():
    """A transient exception in asweep() should not crash the background loop."""
    call_count = 0
    original_asweep = TTLSweeper.asweep

    async def flaky_asweep(self, *, dry_run=False):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            raise RuntimeError("transient error")
        return await original_asweep(self, dry_run=dry_run)

    cp = MockCheckpointer([])
    sweeper = TTLSweeper(cp, TTLPolicy(idle_ttl_seconds=60))

    with patch.object(TTLSweeper, "asweep", flaky_asweep):
        await sweeper.start(interval_seconds=1)
        await asyncio.sleep(1.5)
        await sweeper.stop()

    assert call_count >= 2

@pytest.mark.asyncio
async def test_stop_before_start_is_noop():
    cp = MockCheckpointer([])
    sweeper = TTLSweeper(cp, TTLPolicy(idle_ttl_seconds=60))
    await sweeper.stop()  # should not raise
