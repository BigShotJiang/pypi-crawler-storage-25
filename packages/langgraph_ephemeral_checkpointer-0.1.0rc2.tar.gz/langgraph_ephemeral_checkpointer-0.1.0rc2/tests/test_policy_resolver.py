"""Tests for per-thread policy overrides (§14.1)."""
from collections.abc import AsyncIterator, Iterator

import pytest
from langgraph.checkpoint.base import BaseCheckpointSaver, CheckpointTuple

from langgraph_ephemeral_checkpointer import TTLPolicy, TTLSweeper
from langgraph_ephemeral_checkpointer.types import PolicyOverride

from .conftest import iso_ts, make_checkpoint_tuple

FAKE_CP_ID = "1f1411e3-4e80-62b6-8001-eb2883608248"

class MockCP(BaseCheckpointSaver):
    def __init__(self, tuples):
        super().__init__()
        self._tuples = tuples
        self.deleted: list[str] = []

    def list(self, config, **kwargs) -> Iterator[CheckpointTuple]:
        return iter(self._tuples)

    async def alist(self, config, **kwargs) -> AsyncIterator[CheckpointTuple]:
        for t in self._tuples:
            yield t

    def get_tuple(self, config):
        tid = config["configurable"].get("thread_id")
        for t in reversed(self._tuples):
            if t.config["configurable"]["thread_id"] == tid:
                return t
        return None

    async def aget_tuple(self, config):
        return self.get_tuple(config)

    def put(self, config, checkpoint, metadata, new_versions):
        return config

    def put_writes(self, config, writes, task_id, task_path=()):
        pass

    def delete_thread(self, thread_id):
        self.deleted.append(thread_id)

    async def adelete_thread(self, thread_id):
        self.deleted.append(thread_id)

def _tuples(*thread_ids, offset=-3700):
    return [make_checkpoint_tuple(tid, FAKE_CP_ID, iso_ts(offset)) for tid in thread_ids]

def test_exempt_thread_never_deleted():
    cp = MockCP(_tuples("vip", "regular"))
    policy = TTLPolicy(idle_ttl_seconds=60)

    def resolver(tid):
        return PolicyOverride.EXEMPT if tid == "vip" else PolicyOverride.USE_DEFAULT

    sweeper = TTLSweeper(cp, policy, policy_resolver=resolver)
    result = sweeper.sweep()

    assert "vip" not in result.deleted_thread_ids
    assert "regular" in result.deleted_thread_ids
    assert "vip" not in cp.deleted

def test_custom_policy_override_used():
    """Thread 'long' gets a 7-day TTL, thread 'short' gets the 60s default."""
    cp = MockCP(_tuples("long", "short", offset=-3700))
    default_policy = TTLPolicy(idle_ttl_seconds=60)
    long_policy = TTLPolicy(idle_ttl_seconds=604800)  # 7 days

    def resolver(tid):
        return long_policy if tid == "long" else PolicyOverride.USE_DEFAULT

    sweeper = TTLSweeper(cp, default_policy, policy_resolver=resolver)
    result = sweeper.sweep()

    assert "short" in result.deleted_thread_ids
    assert "long" not in result.deleted_thread_ids

def test_use_default_falls_back_to_global():
    cp = MockCP(_tuples("t"))
    policy = TTLPolicy(idle_ttl_seconds=60)

    def resolver(tid):
        return PolicyOverride.USE_DEFAULT

    sweeper = TTLSweeper(cp, policy, policy_resolver=resolver)
    result = sweeper.sweep()
    assert "t" in result.deleted_thread_ids

def test_resolver_exception_falls_back_to_global(caplog):
    cp = MockCP(_tuples("t"))
    policy = TTLPolicy(idle_ttl_seconds=60)

    def bad_resolver(tid):
        raise ValueError("resolver exploded")

    sweeper = TTLSweeper(cp, policy, policy_resolver=bad_resolver)
    result = sweeper.sweep()

    # Thread should still be deleted using the global policy
    assert "t" in result.deleted_thread_ids

def test_resolver_called_once_per_thread():
    call_counts: dict[str, int] = {}
    cp = MockCP(_tuples("a", "b", "c"))
    policy = TTLPolicy(idle_ttl_seconds=3600)

    def counting_resolver(tid):
        call_counts[tid] = call_counts.get(tid, 0) + 1
        return PolicyOverride.USE_DEFAULT

    sweeper = TTLSweeper(cp, policy, policy_resolver=counting_resolver)
    sweeper.sweep()

    assert call_counts == {"a": 1, "b": 1, "c": 1}

@pytest.mark.asyncio
async def test_async_sweep_respects_resolver():
    cp = MockCP(_tuples("exempt", "expired"))
    policy = TTLPolicy(idle_ttl_seconds=60)

    def resolver(tid):
        return PolicyOverride.EXEMPT if tid == "exempt" else PolicyOverride.USE_DEFAULT

    sweeper = TTLSweeper(cp, policy, policy_resolver=resolver)
    result = await sweeper.asweep()

    assert "exempt" not in result.deleted_thread_ids
    assert "expired" in result.deleted_thread_ids
