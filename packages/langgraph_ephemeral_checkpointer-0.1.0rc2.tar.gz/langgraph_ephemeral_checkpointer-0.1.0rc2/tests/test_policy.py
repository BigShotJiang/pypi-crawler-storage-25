import pytest
from langgraph_ephemeral_checkpointer import TTLPolicy

def test_no_rules_raises():
    with pytest.raises(ValueError, match="At least one retention rule"):
        TTLPolicy()

def test_negative_idle_raises():
    with pytest.raises(ValueError, match="idle_ttl_seconds must be positive"):
        TTLPolicy(idle_ttl_seconds=-1)

def test_zero_idle_raises():
    with pytest.raises(ValueError, match="idle_ttl_seconds must be positive"):
        TTLPolicy(idle_ttl_seconds=0)

def test_negative_hard_age_raises():
    with pytest.raises(ValueError, match="hard_age_ttl_seconds must be positive"):
        TTLPolicy(hard_age_ttl_seconds=-1)

def test_zero_hard_age_raises():
    with pytest.raises(ValueError, match="hard_age_ttl_seconds must be positive"):
        TTLPolicy(hard_age_ttl_seconds=0)

def test_idle_only():
    p = TTLPolicy(idle_ttl_seconds=60)
    assert p.idle_ttl_seconds == 60
    assert p.hard_age_ttl_seconds is None
    assert p.max_checkpoints_per_thread is None

def test_hard_age_only():
    p = TTLPolicy(hard_age_ttl_seconds=3600)
    assert p.hard_age_ttl_seconds == 3600
    assert p.idle_ttl_seconds is None

def test_both_ttls():
    p = TTLPolicy(idle_ttl_seconds=60, hard_age_ttl_seconds=3600)
    assert p.idle_ttl_seconds == 60
    assert p.hard_age_ttl_seconds == 3600

def test_frozen():
    p = TTLPolicy(idle_ttl_seconds=60)
    with pytest.raises((AttributeError, TypeError)):
        p.idle_ttl_seconds = 999  # type: ignore[misc]

def test_max_checkpoints_only():
    p = TTLPolicy(max_checkpoints_per_thread=10)
    assert p.max_checkpoints_per_thread == 10
    assert p.idle_ttl_seconds is None
    assert p.hard_age_ttl_seconds is None

def test_max_checkpoints_zero_raises():
    with pytest.raises(ValueError, match="max_checkpoints_per_thread must be >= 1"):
        TTLPolicy(max_checkpoints_per_thread=0)

def test_max_checkpoints_negative_raises():
    with pytest.raises(ValueError, match="max_checkpoints_per_thread must be >= 1"):
        TTLPolicy(max_checkpoints_per_thread=-5)

def test_max_checkpoints_one_is_valid():
    p = TTLPolicy(max_checkpoints_per_thread=1)
    assert p.max_checkpoints_per_thread == 1

def test_all_three_rules():
    p = TTLPolicy(
        idle_ttl_seconds=3600,
        hard_age_ttl_seconds=86400,
        max_checkpoints_per_thread=50,
    )
    assert p.idle_ttl_seconds == 3600
    assert p.hard_age_ttl_seconds == 86400
    assert p.max_checkpoints_per_thread == 50
