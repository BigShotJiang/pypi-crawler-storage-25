"""Tests for the generic strategy against a mock checkpointer."""
from collections.abc import AsyncIterator, Iterator

import pytest
from langgraph.checkpoint.base import BaseCheckpointSaver, CheckpointTuple

from langgraph_ephemeral_checkpointer._strategies.generic import GenericStrategy

from .conftest import iso_ts, make_checkpoint_tuple

FAKE_CP_ID = "1f1411e3-4e80-62b6-8001-eb2883608248"

class StubCheckpointer(BaseCheckpointSaver):
    def __init__(self, tuples: list[CheckpointTuple]) -> None:
        super().__init__()
        self._tuples = tuples

    def list(self, config, **kwargs) -> Iterator[CheckpointTuple]:
        return iter(self._tuples)

    async def alist(self, config, **kwargs) -> AsyncIterator[CheckpointTuple]:
        for t in self._tuples:
            yield t

    def get_tuple(self, config):
        return None

    def put(self, config, checkpoint, metadata, new_versions):
        return config

    def put_writes(self, config, writes, task_id, task_path=()):
        pass

def test_collect_empty():
    strategy = GenericStrategy(StubCheckpointer([]))
    assert strategy.collect() == {}

def test_collect_single_thread():
    tuples = [make_checkpoint_tuple("t1", FAKE_CP_ID, iso_ts(-100))]
    strategy = GenericStrategy(StubCheckpointer(tuples))
    result = strategy.collect()

    assert "t1" in result
    ts = result["t1"]
    assert ts.latest_ts == ts.earliest_ts

def test_collect_multiple_threads():
    tuples = [
        make_checkpoint_tuple("t1", FAKE_CP_ID, iso_ts(-50)),
        make_checkpoint_tuple("t2", FAKE_CP_ID, iso_ts(-200)),
    ]
    strategy = GenericStrategy(StubCheckpointer(tuples))
    result = strategy.collect()

    assert set(result.keys()) == {"t1", "t2"}
    assert result["t1"].latest_ts > result["t2"].latest_ts

def test_collect_multiple_checkpoints_per_thread():
    # Two checkpoints for the same thread: old and recent
    old_id = "1e0000e3-4e80-62b6-8001-000000000000"
    tuples = [
        make_checkpoint_tuple("t1", FAKE_CP_ID, iso_ts(-10)),   # latest
        make_checkpoint_tuple("t1", old_id, iso_ts(-1000)),     # earliest
    ]
    strategy = GenericStrategy(StubCheckpointer(tuples))
    result = strategy.collect()

    assert len(result) == 1
    ts = result["t1"]
    assert ts.latest_ts > ts.earliest_ts
    # latest should be close to now-10s, earliest close to now-1000s
    import time
    now = time.time()
    assert abs(ts.latest_ts - (now - 10)) < 2
    assert abs(ts.earliest_ts - (now - 1000)) < 2

@pytest.mark.asyncio
async def test_acollect_matches_collect():
    tuples = [
        make_checkpoint_tuple("t1", FAKE_CP_ID, iso_ts(-100)),
        make_checkpoint_tuple("t2", FAKE_CP_ID, iso_ts(-200)),
    ]
    cp = StubCheckpointer(tuples)
    strategy = GenericStrategy(cp)

    sync_result = strategy.collect()
    async_result = await strategy.acollect()

    assert set(sync_result.keys()) == set(async_result.keys())
    for tid in sync_result:
        assert abs(sync_result[tid].latest_ts - async_result[tid].latest_ts) < 0.01
