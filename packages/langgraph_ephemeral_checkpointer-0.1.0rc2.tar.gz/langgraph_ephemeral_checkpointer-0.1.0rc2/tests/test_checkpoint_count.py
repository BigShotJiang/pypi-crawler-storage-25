"""Tests for max_checkpoints_per_thread pruning (§14.2)."""
import time

import pytest
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph
from typing import TypedDict

from langgraph_ephemeral_checkpointer import TTLPolicy, TTLSweeper
from langgraph_ephemeral_checkpointer._strategies.memory import MemoryStrategy
from langgraph_ephemeral_checkpointer._strategies.sqlite import SqliteStrategy

class _State(TypedDict):
    x: int

def _build_graph(saver):
    b = StateGraph(_State)
    b.add_node("inc", lambda s: {"x": s["x"] + 1})
    b.add_edge(START, "inc")
    b.add_edge("inc", END)
    return b.compile(checkpointer=saver)

def _cp_count(saver, thread_id: str) -> int:
    return sum(
        1 for t in saver.list(None)
        if t.config["configurable"]["thread_id"] == thread_id
    )

def test_memory_prune_removes_oldest():
    saver = InMemorySaver()
    graph = _build_graph(saver)
    for _ in range(5):
        graph.invoke({"x": 0}, {"configurable": {"thread_id": "t1"}})

    before = _cp_count(saver, "t1")
    assert before > 2  # sanity: at least 3 checkpoints from 5 invocations

    strategy = MemoryStrategy(saver)
    pruned = strategy.prune("t1", keep_count=2)

    assert pruned == before - 2
    assert _cp_count(saver, "t1") == 2

def test_memory_prune_below_limit_is_noop():
    saver = InMemorySaver()
    graph = _build_graph(saver)
    graph.invoke({"x": 0}, {"configurable": {"thread_id": "t1"}})

    strategy = MemoryStrategy(saver)
    pruned = strategy.prune("t1", keep_count=10)

    assert pruned == 0

def test_memory_prune_keeps_newest():
    """After pruning, the remaining checkpoint should be the latest."""
    saver = InMemorySaver()
    graph = _build_graph(saver)
    for i in range(4):
        graph.invoke({"x": i}, {"configurable": {"thread_id": "t1"}})

    strategy = MemoryStrategy(saver)
    strategy.prune("t1", keep_count=1)

    remaining = list(saver.list({"configurable": {"thread_id": "t1"}}))
    assert len(remaining) == 1
    # The kept checkpoint should have the highest state value
    assert remaining[0].checkpoint["channel_values"]["x"] == 4

def test_sweep_prunes_over_limit():
    saver = InMemorySaver()
    graph = _build_graph(saver)
    for _ in range(6):
        graph.invoke({"x": 0}, {"configurable": {"thread_id": "t1"}})

    total_before = _cp_count(saver, "t1")

    policy = TTLPolicy(max_checkpoints_per_thread=3)
    sweeper = TTLSweeper(saver, policy)

    result = sweeper.sweep()

    assert result.pruned_checkpoint_count == total_before - 3
    assert result.deleted_thread_ids == []
    assert _cp_count(saver, "t1") == 3

def test_sweep_does_not_prune_ttl_expired_thread():
    """A thread that would be deleted entirely should not also be pruned."""
    saver = InMemorySaver()
    graph = _build_graph(saver)
    for _ in range(6):
        graph.invoke({"x": 0}, {"configurable": {"thread_id": "t1"}})

    policy = TTLPolicy(idle_ttl_seconds=1, max_checkpoints_per_thread=3)
    sweeper = TTLSweeper(saver, policy)

    total_before = _cp_count(saver, "t1")

    # Still fresh — should prune, not delete
    result = sweeper.sweep()
    assert result.deleted_thread_ids == []
    assert result.pruned_checkpoint_count == total_before - 3

    time.sleep(1.1)

    # Now stale — should delete, not prune
    result2 = sweeper.sweep()
    assert "t1" in result2.deleted_thread_ids
    assert result2.pruned_checkpoint_count == 0
    assert "t1" not in saver.storage

def test_sqlite_prune_removes_oldest():
    with SqliteSaver.from_conn_string(":memory:") as saver:
        graph = _build_graph(saver)
        for _ in range(5):
            graph.invoke({"x": 0}, {"configurable": {"thread_id": "t1"}})

        before = _cp_count(saver, "t1")
        assert before > 2

        strategy = SqliteStrategy(saver)
        pruned = strategy.prune("t1", keep_count=2)

        assert pruned == before - 2
        assert _cp_count(saver, "t1") == 2

def test_sqlite_sweep_prunes():
    with SqliteSaver.from_conn_string(":memory:") as saver:
        graph = _build_graph(saver)
        for _ in range(6):
            graph.invoke({"x": 0}, {"configurable": {"thread_id": "t1"}})

        total_before = _cp_count(saver, "t1")
        policy = TTLPolicy(max_checkpoints_per_thread=2)
        sweeper = TTLSweeper(saver, policy)
        result = sweeper.sweep()

        assert result.pruned_checkpoint_count == total_before - 2
        assert _cp_count(saver, "t1") == 2

@pytest.mark.asyncio
async def test_async_sqlite_prune():
    pytest.importorskip("aiosqlite")
    from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

    async def _acp_count(saver, thread_id: str) -> int:
        count = 0
        async for t in saver.alist(None):
            if t.config["configurable"]["thread_id"] == thread_id:
                count += 1
        return count

    async with AsyncSqliteSaver.from_conn_string(":memory:") as saver:
        graph = _build_graph(saver)
        for _ in range(5):
            await graph.ainvoke({"x": 0}, {"configurable": {"thread_id": "t1"}})

        policy = TTLPolicy(max_checkpoints_per_thread=2)
        sweeper = TTLSweeper(saver, policy)
        result = await sweeper.asweep()

        assert result.pruned_checkpoint_count > 0
        assert await _acp_count(saver, "t1") == 2

def test_unsupported_backend_warns(caplog):
    from collections.abc import Iterator
    from langgraph.checkpoint.base import BaseCheckpointSaver, CheckpointTuple

    class StubSaver(BaseCheckpointSaver):
        def list(self, config, **kwargs) -> Iterator[CheckpointTuple]:
            return iter([])

        async def alist(self, config, **kwargs):
            return
            yield  # make it an async generator

        def get_tuple(self, config):
            return None

        async def aget_tuple(self, config):
            return None

        def put(self, config, checkpoint, metadata, new_versions):
            return config

        def put_writes(self, config, writes, task_id, task_path=()):
            pass

    import logging
    with caplog.at_level(logging.WARNING, logger="langgraph_ephemeral_checkpointer.sweeper"):
        TTLSweeper(StubSaver(), TTLPolicy(max_checkpoints_per_thread=5))

    assert any("does not support count-based pruning" in r.message for r in caplog.records)
