from datetime import datetime, timezone, timedelta

from langgraph.checkpoint.base import CheckpointTuple

def iso_ts(offset_seconds: float = 0.0) -> str:
    """Return an ISO 8601 timestamp offset_seconds from now."""
    dt = datetime.now(timezone.utc) + timedelta(seconds=offset_seconds)
    return dt.isoformat()

def make_checkpoint_tuple(
    thread_id: str,
    checkpoint_id: str,
    ts: str,
    checkpoint_ns: str = "",
) -> CheckpointTuple:
    return CheckpointTuple(
        config={
            "configurable": {
                "thread_id": thread_id,
                "checkpoint_ns": checkpoint_ns,
                "checkpoint_id": checkpoint_id,
            }
        },
        checkpoint={
            "v": 1,
            "id": checkpoint_id,
            "ts": ts,
            "channel_values": {},
            "channel_versions": {},
            "versions_seen": {},
            "updated_channels": None,
        },
        metadata={},
        parent_config=None,
        pending_writes=None,
    )
