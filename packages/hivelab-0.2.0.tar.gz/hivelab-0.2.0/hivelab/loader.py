"""Resolve a push source (file or directory) into a markdown body + side files
+ attachments.

Rules for directories:
  - Primary markdown body: first of
        summary.md, notes.md, report.md, analysis.md, README.md,
        then the first *.md found at the top level (alphabetic order).
  - Side files (small config / metrics): contents appended to the markdown
    body as fenced code blocks so the LLM can extract structured fields.
        config.json, config.yaml, config.yml,
        params.json, params.yaml, params.yml,
        hparams.json, hparams.yaml, hparams.yml,
        args.json, args.yaml,
        train.yaml, run.yaml, run.json,
        metrics.json, result.json, results.json
  - Attachments (logs / other text artifacts): uploaded as separate files
    via /api/uploads and linked from the bottom of the markdown body.
        *.log, *.txt, train.log, output.log, stderr.txt, stdout.txt,
        plus any extra .md files beyond the primary one
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

PREFERRED_PRIMARY = ["summary.md", "notes.md", "report.md", "analysis.md", "README.md"]

SIDE_CONFIG_NAMES = [
    "config.json",
    "config.yaml",
    "config.yml",
    "params.json",
    "params.yaml",
    "params.yml",
    "hparams.json",
    "hparams.yaml",
    "hparams.yml",
    "args.json",
    "args.yaml",
    "train.yaml",
    "train.json",
    "run.yaml",
    "run.json",
    "metrics.json",
    "result.json",
    "results.json",
]

# Suffixes treated as "uploadable text artifact": shown as download link in
# the markdown body, NOT embedded inline.
ATTACHMENT_SUFFIXES = {".log", ".txt"}


@dataclass
class LoadedSource:
    primary_path: Path
    markdown: str
    side_files: List[Path] = field(default_factory=list)
    attachments: List[Path] = field(default_factory=list)


def load_source(path_str: str) -> LoadedSource:
    path = Path(path_str).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"path does not exist: {path}")

    if path.is_file():
        if path.suffix.lower() != ".md":
            raise ValueError(f"only .md files are supported, got: {path.name}")
        md = path.read_text(encoding="utf-8")
        side = _collect_side_files(path.parent)
        attachments = _collect_attachments(path.parent, exclude={path})
        if side:
            md = _append_side_files(md, side)
        return LoadedSource(
            primary_path=path, markdown=md, side_files=side, attachments=attachments
        )

    # directory
    primary = _pick_primary_md(path)
    if primary is None:
        raise FileNotFoundError(f"no .md file found in {path}")
    md = primary.read_text(encoding="utf-8")
    side = _collect_side_files(path)
    attachments = _collect_attachments(path, exclude={primary})
    if side:
        md = _append_side_files(md, side)
    return LoadedSource(
        primary_path=primary, markdown=md, side_files=side, attachments=attachments
    )


def _pick_primary_md(directory: Path) -> Optional[Path]:
    for name in PREFERRED_PRIMARY:
        candidate = directory / name
        if candidate.exists() and candidate.is_file():
            return candidate
    mds = sorted([p for p in directory.glob("*.md") if p.is_file()])
    return mds[0] if mds else None


def _collect_side_files(directory: Path) -> List[Path]:
    out: List[Path] = []
    for name in SIDE_CONFIG_NAMES:
        p = directory / name
        if p.exists() and p.is_file():
            out.append(p)
    return out


def _collect_attachments(directory: Path, exclude: set) -> List[Path]:
    """Pick .log / .txt files + any extra .md files (besides primary) in the
    top level. Files larger than 50MB are skipped (server limit)."""
    out: List[Path] = []
    side_names = set(SIDE_CONFIG_NAMES)
    for p in sorted(directory.iterdir()):
        if not p.is_file() or p in exclude:
            continue
        if p.name in side_names:  # already embedded
            continue
        suf = p.suffix.lower()
        if suf in ATTACHMENT_SUFFIXES or suf == ".md":
            try:
                if p.stat().st_size <= 50 * 1024 * 1024:
                    out.append(p)
            except OSError:
                pass
    return out


def _append_side_files(md: str, side: List[Path]) -> str:
    blocks: List[str] = [md.rstrip()]
    blocks.append("")
    blocks.append("---")
    blocks.append("")
    blocks.append("> 以下内容由 hivelab 从同目录的配置/结果文件附加，方便 LLM 抽取字段：")
    blocks.append("")
    for p in side:
        lang = _lang_for_suffix(p.suffix)
        try:
            text = p.read_text(encoding="utf-8").strip()
        except OSError as e:
            text = f"(read failed: {e})"
        if p.suffix.lower() == ".json":
            try:
                text = json.dumps(json.loads(text), indent=2, ensure_ascii=False)
            except json.JSONDecodeError:
                pass
        blocks.append(f"### `{p.name}`")
        blocks.append(f"```{lang}")
        blocks.append(text)
        blocks.append("```")
        blocks.append("")
    return "\n".join(blocks)


def append_attachment_section(md: str, uploaded: List[Tuple[str, str]]) -> str:
    """Append a bullet list of attached files (as markdown links) to the body.

    `uploaded` is a list of (filename, markdown_snippet) — typically the
    markdown_snippet is what the server returned (already a link). We just
    join them under a section header.
    """
    if not uploaded:
        return md
    blocks: List[str] = [md.rstrip()]
    blocks.append("")
    blocks.append("---")
    blocks.append("")
    blocks.append("### 附件（日志 / 其他文本文件）")
    blocks.append("")
    for fname, snippet in uploaded:
        blocks.append(f"- {snippet}")
    blocks.append("")
    return "\n".join(blocks)


def _lang_for_suffix(suf: str) -> str:
    s = suf.lower().lstrip(".")
    if s in ("yaml", "yml"):
        return "yaml"
    if s == "json":
        return "json"
    return ""


def parse_field_overrides(values: Tuple[str, ...]) -> dict:
    """Convert click's multi-value --field name=value into structuredFields dict.

    Field values are auto-coerced:
      - "true"/"false" → bool
      - numeric strings → number
      - everything else → string
    All overrides are flagged edited=True with confidence=1 so the backend
    treats them as authoritative.
    """
    out: dict = {}
    for raw in values:
        if "=" not in raw:
            raise ValueError(f"--field expects name=value, got: {raw}")
        name, val = raw.split("=", 1)
        name = name.strip()
        val = val.strip()
        coerced: object
        low = val.lower()
        if low in ("true", "false"):
            coerced = low == "true"
        else:
            try:
                if "." in val or "e" in low:
                    coerced = float(val)
                else:
                    coerced = int(val)
            except ValueError:
                coerced = val
        out[name] = {"value": coerced, "confidence": 1, "edited": True}
    return out
