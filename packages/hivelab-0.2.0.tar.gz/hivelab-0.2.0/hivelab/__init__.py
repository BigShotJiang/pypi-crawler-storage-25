"""hivelab — push structured Markdown research notes to any hivelab-compatible backend."""

__version__ = "0.1.0"
