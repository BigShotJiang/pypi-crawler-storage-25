"""Thin HTTP client around the hivelab `/api/v1/*` protocol."""

from __future__ import annotations

import json as _json
import os
from typing import Any, Dict, Optional

import requests

from .config import Profile


class HivelabError(Exception):
    def __init__(self, status: int, payload: Any, message: str = ""):
        self.status = status
        self.payload = payload
        super().__init__(message or f"HTTP {status}: {payload}")


class Client:
    def __init__(self, profile: Profile, timeout: int = 60):
        self.profile = profile
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Authorization": f"Bearer {profile.token}",
                "Accept": "application/json",
                "User-Agent": "hivelab-cli/0.1",
            }
        )
        # By default we bypass any system-wide HTTP/HTTPS proxy. Reason:
        # users often run hivelab from environments with a global proxy
        # configured for browsing (clash / corp proxy / VPN), and that proxy
        # either can't reach the hive backend or rate-limits/blocks it. The
        # hive backend is typically on a server you own anyway. To explicitly
        # honor system proxy settings, set HIVELAB_USE_PROXY=1.
        if os.environ.get("HIVELAB_USE_PROXY") != "1":
            self.session.trust_env = False

    # ------------------------------------------------------------------ core

    def _request(self, method: str, path: str, body: Optional[Dict] = None) -> Any:
        url = self.profile.url + path
        try:
            r = self.session.request(
                method,
                url,
                json=body,
                timeout=self.timeout,
            )
        except requests.RequestException as e:
            raise HivelabError(0, None, f"connection error: {e}") from e

        try:
            data = r.json()
        except ValueError:
            data = r.text

        if not r.ok:
            msg = ""
            if isinstance(data, dict):
                msg = data.get("message") or data.get("error") or ""
            raise HivelabError(r.status_code, data, msg)
        return data

    # ------------------------------------------------------------- endpoints

    def whoami(self) -> Dict:
        return self._request("GET", "/api/v1/whoami")

    def list_projects(self) -> Dict:
        return self._request("GET", "/api/v1/projects")

    def get_project(self, slug: str) -> Dict:
        return self._request("GET", f"/api/v1/projects/{slug}")

    def get_template(self, template_id: str) -> Dict:
        return self._request("GET", f"/api/v1/templates/{template_id}")

    def push_experiment(self, payload: Dict) -> Dict:
        return self._request("POST", "/api/v1/experiments", payload)

    def push_note(self, payload: Dict) -> Dict:
        return self._request("POST", "/api/v1/notes", payload)

    def get_digest(self, week: str = "current") -> Dict:
        return self._request("GET", f"/api/v1/digest?week={week}")

    # ---- the routes below use the web /api/* surface, not /api/v1.
    # The token middleware on the server accepts the same Bearer token there,
    # so this works without any backend change.

    def list_my_todos(self, status: str = "open") -> Dict:
        return self._request("GET", f"/api/my/todos?status={status}")

    def list_project_todos(self, slug: str, status: str | None = None) -> Dict:
        qs = f"?status={status}" if status else ""
        return self._request("GET", f"/api/projects/{slug}/todos{qs}")

    def create_todo(self, slug: str, payload: Dict) -> Dict:
        return self._request("POST", f"/api/projects/{slug}/todos", payload)

    def update_todo(self, todo_id: str, payload: Dict) -> Dict:
        return self._request("PATCH", f"/api/todos/{todo_id}", payload)

    def delete_todo(self, todo_id: str) -> Dict:
        return self._request("DELETE", f"/api/todos/{todo_id}")

    def search(self, q: str) -> Dict:
        from urllib.parse import quote
        return self._request("GET", f"/api/search?q={quote(q)}")

    def list_notifications(self, status: str = "unread", limit: int = 30) -> Dict:
        return self._request(
            "GET", f"/api/me/notifications?status={status}&limit={limit}"
        )

    def unread_count(self) -> Dict:
        return self._request("GET", "/api/me/notifications/unread-count")

    def mark_notifications_read(self, ids: list[str] | None = None) -> Dict:
        return self._request(
            "POST", "/api/me/notifications/read", {"ids": ids if ids is not None else None}
        )

    def list_users(self) -> Dict:
        return self._request("GET", "/api/users")

    def suggest_template(self, project_slug: str, markdown: str, hint: str | None = None) -> Dict:
        body: Dict = {"project": project_slug, "markdown": markdown}
        if hint:
            body["hint"] = hint
        return self._request("POST", "/api/templates/suggest", body)

    def create_template(self, project_slug: str, name: str, fields_schema: list) -> Dict:
        return self._request(
            "POST",
            f"/api/projects/{project_slug}/templates",
            {"name": name, "fieldsSchema": fields_schema},
        )

    def upload_file(self, project_slug: str, file_path: str) -> Dict:
        """Upload a file to /api/uploads scoped to a project. Returns the
        attachment record including a ready-to-use markdown snippet."""
        url = self.profile.url + "/api/uploads"
        with open(file_path, "rb") as f:
            files = {"file": (file_path.split("/")[-1], f)}
            data = {"project": project_slug}
            # don't use self.session.post directly because we need to drop
            # Content-Type so requests sets multipart/form-data with boundary
            try:
                r = self.session.post(
                    url,
                    files=files,
                    data=data,
                    timeout=120,
                )
            except requests.RequestException as e:
                raise HivelabError(0, None, f"upload error: {e}") from e
        try:
            payload = r.json()
        except ValueError:
            payload = r.text
        if not r.ok:
            msg = ""
            if isinstance(payload, dict):
                msg = payload.get("message") or payload.get("error") or ""
            raise HivelabError(r.status_code, payload, msg)
        return payload["attachment"]
