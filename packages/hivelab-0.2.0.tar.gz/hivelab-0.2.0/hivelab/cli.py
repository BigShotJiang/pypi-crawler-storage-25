"""hivelab CLI entry point.

Commands:
  hivelab login                          # interactive setup or use --url/--token
  hivelab logout
  hivelab whoami
  hivelab profiles
  hivelab projects
  hivelab templates <project>
  hivelab push <path> --project X [--template Y] [--thread Z] [...]
  hivelab note "text" --project X [--title T]
  hivelab digest [--week current|previous|YYYY-MM-DD]
"""

from __future__ import annotations

import json
import sys
from typing import Optional

import click
from rich.console import Console
from rich.table import Table

from . import __version__
from .client import Client, HivelabError
from .config import (
    delete_profile,
    list_profiles,
    load_profile,
    save_profile,
)
from .loader import (
    append_attachment_section,
    load_source,
    parse_field_overrides,
)

console = Console()
err_console = Console(stderr=True, style="red")


# ---------------------------------------------------------- shared helpers ---


def get_client(profile_name: Optional[str]) -> Client:
    p = load_profile(profile_name)
    if not p:
        err_console.print(
            "未登录。运行 `hivelab login` 配置 URL + token，或设置环境变量 "
            "HIVELAB_URL + HIVELAB_TOKEN。"
        )
        sys.exit(2)
    return Client(p)


def run(func):
    """Decorator: catch HivelabError and pretty-print to stderr."""
    def wrapped(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except HivelabError as e:
            err_console.print(f"[bold]请求失败 ({e.status}):[/bold] {e}")
            if isinstance(e.payload, dict) and e.payload.get("message"):
                pass  # already in the message
            sys.exit(1)
        except FileNotFoundError as e:
            err_console.print(str(e))
            sys.exit(1)
        except ValueError as e:
            err_console.print(str(e))
            sys.exit(2)
    wrapped.__name__ = func.__name__
    wrapped.__doc__ = func.__doc__
    return wrapped


# --------------------------------------------------------- top-level group ---


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(__version__, prog_name="hivelab")
@click.option(
    "--profile",
    "-p",
    "profile",
    default=None,
    help="Use a named profile from ~/.config/hivelab/config.json.",
)
@click.pass_context
def main(ctx: click.Context, profile: Optional[str]) -> None:
    """Push structured Markdown research notes to a hivelab backend."""
    ctx.ensure_object(dict)
    ctx.obj["profile"] = profile


# ------------------------------------------------------------------ login ---


@main.command()
@click.option("--url", default=None, help="Backend URL, e.g. http://localhost:3000")
@click.option("--token", default=None, help="API token (lab_xxx...)")
@click.option(
    "--name",
    "profile_name",
    default="default",
    help="Profile name to store under (default: default)",
)
@click.option(
    "--set-default", is_flag=True, help="Also mark this profile as the default."
)
def login(url, token, profile_name, set_default):
    """Save backend URL + API token to ~/.config/hivelab/config.json."""
    if not url:
        url = click.prompt("Backend URL", default="http://localhost:3000")
    if not token:
        token = click.prompt("API token (lab_…)", hide_input=True)
    url = url.rstrip("/")

    # validate immediately by calling whoami
    from .client import Client as _C
    from .config import Profile as _P
    try:
        me = _C(_P(url=url, token=token)).whoami()
    except HivelabError as e:
        err_console.print(f"[bold]token 验证失败 ({e.status}):[/bold] {e}")
        sys.exit(1)

    save_profile(profile_name, url=url, token=token, set_default=set_default)
    console.print(
        f":white_check_mark: 已保存 profile [bold]{profile_name}[/bold]，"
        f"登录身份：[bold]{me['name']}[/bold] ({me['username']}) @ {url}"
    )


@main.command()
@click.option(
    "--name",
    "profile_name",
    default="default",
    help="Profile name to remove (default: default)",
)
def logout(profile_name):
    """Remove a saved profile from local config."""
    ok = delete_profile(profile_name)
    if ok:
        console.print(f":white_check_mark: 已删除 profile [bold]{profile_name}[/bold]。")
    else:
        err_console.print(f"profile {profile_name} 不存在。")
        sys.exit(1)


@main.command()
def profiles():
    """List all configured profiles."""
    info = list_profiles()
    profiles = info.get("profiles") or {}
    if not profiles:
        console.print("尚未配置任何 profile。运行 `hivelab login`。")
        return
    table = Table(show_header=True, header_style="bold")
    table.add_column("name")
    table.add_column("url")
    table.add_column("token")
    table.add_column("default")
    for name, p in profiles.items():
        table.add_row(
            name,
            p["url"],
            p["token_preview"],
            "✓" if info.get("default") == name else "",
        )
    console.print(table)


# -------------------------------------------------------------- inspection ---


@main.command()
@click.pass_context
@run
def whoami(ctx):
    """Show who you're logged in as on the current backend."""
    c = get_client(ctx.obj["profile"])
    me = c.whoami()
    console.print(
        f"[bold]{me['name']}[/bold] ({me['username']}) — role: {me['role']}"
    )
    console.print(f"  endpoint: {c.profile.url}")


@main.command()
@click.pass_context
@run
def projects(ctx):
    """List projects you're a member of."""
    c = get_client(ctx.obj["profile"])
    data = c.list_projects()
    items = data.get("projects", [])
    if not items:
        console.print("没有可访问的项目。")
        return
    table = Table(show_header=True, header_style="bold")
    table.add_column("slug")
    table.add_column("name")
    table.add_column("description")
    for p in items:
        table.add_row(p["slug"], p["name"], p.get("description") or "")
    console.print(table)


@main.command()
@click.argument("project")
@click.pass_context
@run
def templates(ctx, project):
    """Show templates and active threads for a project."""
    c = get_client(ctx.obj["profile"])
    data = c.get_project(project)["project"]

    if data.get("threads"):
        console.print(f"[bold]Threads in {data['name']}:[/bold]")
        tt = Table(show_header=True, header_style="dim")
        tt.add_column("id")
        tt.add_column("name")
        tt.add_column("status")
        for t in data["threads"]:
            tt.add_row(t["id"], t["name"], t["status"])
        console.print(tt)
        console.print()

    if not data.get("templates"):
        console.print("[dim]（该项目没有模板）[/dim]")
        return

    console.print(f"[bold]Templates in {data['name']}:[/bold]")
    for tpl in data["templates"]:
        console.print(f"\n[bold]{tpl['name']}[/bold]  v{tpl['version']}  (id: {tpl['id']})")
        ft = Table(show_header=True, header_style="dim", padding=(0, 1))
        ft.add_column("name")
        ft.add_column("type")
        ft.add_column("unit")
        ft.add_column("required")
        ft.add_column("description")
        for f in tpl["fieldsSchema"]:
            ft.add_row(
                f["name"],
                f["type"],
                f.get("unit") or "",
                "✓" if f.get("required") else "",
                f.get("description") or "",
            )
        console.print(ft)


# -------------------------------------------------------------- push / note --


@main.command()
@click.argument("path", type=click.Path(exists=True, dir_okay=True, file_okay=True))
@click.option("--project", "-P", required=True, help="Project slug.")
@click.option("--template", "-T", default=None, help="Template id or name.")
@click.option("--thread", default=None, help="Thread id or name.")
@click.option("--title", default=None, help="Override title (default: extracted by LLM).")
@click.option(
    "--field",
    "fields",
    multiple=True,
    metavar="NAME=VALUE",
    help="Override a structured field (skips LLM for that field). Repeatable.",
)
@click.option(
    "--publish",
    is_flag=True,
    help="Mark as published immediately (default: draft, requires web review).",
)
@click.option(
    "--draft",
    is_flag=True,
    help="Force draft status (default behavior when --template given).",
)
@click.option(
    "--no-llm",
    is_flag=True,
    help="Skip LLM extraction; all structured fields must come from --field overrides.",
)
@click.option(
    "--attach",
    "attach_extra",
    multiple=True,
    metavar="FILE",
    type=click.Path(exists=True, dir_okay=False),
    help="Extra file to upload as an attachment (outside the source dir). Repeatable.",
)
@click.option(
    "--no-attach",
    is_flag=True,
    help="Skip uploading any attachments (logs / extra .md), even if found in the directory.",
)
@click.option("--dry-run", is_flag=True, help="Print the payload, do not send.")
@click.pass_context
@run
def push(ctx, path, project, template, thread, title, fields, publish, draft, no_llm, attach_extra, no_attach, dry_run):
    """Push a Markdown note as an experiment.

    PATH can be:
      - a .md file
      - a directory. The CLI picks summary.md / notes.md / report.md /
        analysis.md / README.md / first .md as the body. It then:
        * embeds sibling config.json / hparams.yaml / metrics.json / etc.
          into the markdown for the LLM to extract fields from;
        * uploads sibling *.log / *.txt / extra .md as attachments and
          links them at the bottom of the body.

    Use --attach to add files from outside the source dir. Use --no-attach
    to skip all attachments.
    """
    src = load_source(path)
    overrides = parse_field_overrides(fields)

    # Collect everything to attach (sibling logs + explicit --attach).
    attach_paths: list = [] if no_attach else list(src.attachments)
    for extra in attach_extra:
        from pathlib import Path as _P
        attach_paths.append(_P(extra).expanduser().resolve())

    body = src.markdown

    if dry_run:
        if attach_paths:
            body = append_attachment_section(
                body, [(p.name, f"[{p.name}](<would upload>)") for p in attach_paths]
            )
        payload_preview: dict = {"project": project, "markdown": body}
        if template: payload_preview["template"] = template
        if thread: payload_preview["thread"] = thread
        if title: payload_preview["title"] = title
        if overrides: payload_preview["structuredFields"] = overrides
        console.print("[dim]--dry-run, will not send:[/dim]")
        console.print_json(data=payload_preview)
        return

    c = get_client(ctx.obj["profile"])

    # Upload attachments BEFORE creating the experiment so the markdown body
    # can include real links. Each upload failure is non-fatal: we keep going
    # and tell the user at the end.
    uploaded: list = []
    failed: list = []
    for p in attach_paths:
        try:
            console.print(f"  [dim]上传 {p.name}（{_human_size(p.stat().st_size)}）…[/dim]")
            att = c.upload_file(project, str(p))
            uploaded.append((p.name, att["markdown"]))
        except Exception as e:
            failed.append((p.name, str(e)))

    if uploaded:
        body = append_attachment_section(body, uploaded)

    payload: dict = {"project": project, "markdown": body}
    if template: payload["template"] = template
    if thread: payload["thread"] = thread
    if title: payload["title"] = title
    if overrides: payload["structuredFields"] = overrides
    if no_llm and "structuredFields" not in payload:
        payload["structuredFields"] = {}
    if publish: payload["status"] = "published"
    elif draft: payload["status"] = "draft"

    r = c.push_experiment(payload)["experiment"]
    badge = "[yellow]draft[/yellow]" if r["status"] == "draft" else "[green]published[/green]"
    console.print(
        f":rocket: {badge}  [bold]{r['title']}[/bold]  ({src.primary_path.name})"
    )
    console.print(f"  → {c.profile.url}{r['reviewUrl']}")
    if src.side_files:
        names = ", ".join(p.name for p in src.side_files)
        console.print(f"  [dim]内嵌配置 → {names}[/dim]")
    if uploaded:
        names = ", ".join(n for n, _ in uploaded)
        console.print(f"  [dim]附件已上传 → {names}[/dim]")
    if failed:
        for n, msg in failed:
            err_console.print(f"  附件上传失败 {n}: {msg}")
    if r["status"] == "draft":
        console.print(
            "  [dim]上 web 确认 LLM 抽出的字段后点「发布」。[/dim]"
        )


def _human_size(n: int) -> str:
    for unit in ("B", "KB", "MB"):
        if n < 1024:
            return f"{n:.1f}{unit}" if unit != "B" else f"{n}{unit}"
        n = n / 1024
    return f"{n:.1f}GB"


@main.command()
@click.argument("text", nargs=-1, required=True)
@click.option("--project", "-P", required=True, help="Project slug.")
@click.option("--title", default=None, help="Note title (default: first line).")
@click.option("--dry-run", is_flag=True)
@click.pass_context
@run
def note(ctx, text, project, title, dry_run):
    """Push a quick freeform Markdown note (no template, no LLM extraction)."""
    body = " ".join(text).strip()
    if not body:
        err_console.print("note body 不能为空。")
        sys.exit(2)
    payload: dict = {"project": project, "markdown": body}
    if title:
        payload["title"] = title
    if dry_run:
        console.print_json(data=payload)
        return
    c = get_client(ctx.obj["profile"])
    r = c.push_note(payload)["note"]
    console.print(f":memo: [bold]{r['title']}[/bold]  → {c.profile.url}{r['reviewUrl']}")


# ----------------------------------------------------------------- digest ---


@main.command()
@click.option(
    "--week",
    default="current",
    help="current | previous | YYYY-MM-DD (Monday of the target week).",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output raw JSON instead of formatted text.",
)
@click.pass_context
@run
def digest(ctx, week, as_json):
    """Print the weekly digest for projects you're a member of."""
    c = get_client(ctx.obj["profile"])
    data = c.get_digest(week)
    if as_json:
        click.echo(json.dumps(data, indent=2, ensure_ascii=False))
        return
    digests = data.get("digests", [])
    console.print(f"[dim]week starting {data['weekStart']}[/dim]")
    if not digests:
        console.print("（这周还没有周报。在 web 上点「立刻生成」可以现在跑一轮。）")
        return
    for d in digests:
        thread_str = f" › {d['thread']['name']}" if d.get("thread") else ""
        console.print(
            f"\n[bold]{d['project']['name']}{thread_str}[/bold]  "
            f"[dim]{d['generatedAt'][:16].replace('T', ' ')}[/dim]"
        )
        console.print(d["contentMarkdown"])


# --------------------------------------------------------------- search ---


@main.command()
@click.argument("query", nargs=-1, required=True)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output raw JSON instead of formatted text.",
)
@click.pass_context
@run
def search(ctx, query, as_json):
    """Search experiments / notes / todos / threads. Scoped to your projects."""
    q = " ".join(query).strip()
    if not q:
        return
    c = get_client(ctx.obj["profile"])
    r = c.search(q)
    if as_json:
        click.echo(json.dumps(r, indent=2, ensure_ascii=False))
        return
    total = sum(len(r[k]) for k in ("experiments", "notes", "todos", "threads"))
    if total == 0:
        console.print(f"[dim]没匹配到「{q}」的任何东西。[/dim]")
        return

    if r["experiments"]:
        console.print(f"\n[bold]实验 ({len(r['experiments'])})[/bold]")
        for e in r["experiments"]:
            meta = " · ".join(
                x for x in [
                    (e.get("project") or {}).get("name"),
                    (e.get("thread") or {}).get("name"),
                ] if x
            )
            console.print(f"  • [cyan]{e['title']}[/cyan]  [dim]{meta}[/dim]")
            if e.get("excerpt"):
                console.print(f"    [dim]{e['excerpt']}[/dim]")
    if r["notes"]:
        console.print(f"\n[bold]笔记 ({len(r['notes'])})[/bold]")
        for n in r["notes"]:
            project_name = (n.get("project") or {}).get("name", "")
            console.print(f"  • [cyan]{n['title']}[/cyan]  [dim]{n['author']['name']} · {project_name}[/dim]")
            if n.get("excerpt"):
                console.print(f"    [dim]{n['excerpt']}[/dim]")
    if r["todos"]:
        console.print(f"\n[bold]待办 ({len(r['todos'])})[/bold]")
        for t in r["todos"]:
            assignee = (t.get("assignee") or {}).get("name", "未分配")
            due = f" · 截止 {t['dueDate'][:10]}" if t.get("dueDate") else ""
            console.print(f"  • [{t['status']:11}] {t['title']}  [dim]{assignee} · {t['project']['name']}{due}[/dim]")
    if r["threads"]:
        console.print(f"\n[bold]研究分支 ({len(r['threads'])})[/bold]")
        for th in r["threads"]:
            console.print(f"  • [cyan]{th['name']}[/cyan]  [dim]{th['status']} · {th['project']['name']}[/dim]")


# --------------------------------------------------------------- todos ---


@main.group()
def todo():
    """Manage todos (list / add / done / drop)."""


@todo.command("list")
@click.option(
    "--scope",
    type=click.Choice(["me", "project"]),
    default="me",
    help="me = todos assigned to you across all projects; project = a project's todos.",
)
@click.option(
    "--project",
    "-P",
    default=None,
    help="Required when --scope=project.",
)
@click.option(
    "--status",
    type=click.Choice(["open", "done", "all"]),
    default="open",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Output raw JSON.",
)
@click.pass_context
@run
def todo_list(ctx, scope, project, status, as_json):
    """List todos."""
    c = get_client(ctx.obj["profile"])
    if scope == "me":
        r = c.list_my_todos(status=status)
    else:
        if not project:
            err_console.print("--scope=project 时需要提供 --project SLUG。")
            sys.exit(2)
        api_status = None if status == "all" else status
        r = c.list_project_todos(project, status=api_status)
    todos = r.get("todos", [])
    if as_json:
        click.echo(json.dumps(todos, indent=2, ensure_ascii=False))
        return
    if not todos:
        console.print("[dim]没有待办。[/dim]")
        return
    table = Table(show_header=True, header_style="bold")
    table.add_column("id", style="dim", no_wrap=True)
    table.add_column("状态")
    table.add_column("标题")
    table.add_column("负责人")
    table.add_column("截止")
    if scope == "me":
        table.add_column("项目")
    for t in todos:
        assignee = (t.get("assignee") or {}).get("name", "—")
        due = t["dueDate"][:10] if t.get("dueDate") else "—"
        status_icon = {
            "open": "⬜ 待办",
            "in_progress": "🟡 进行中",
            "done": "✅ 已完成",
            "cancelled": "⊘ 取消",
        }.get(t["status"], t["status"])
        row = [
            t["id"][:8],
            status_icon,
            t["title"],
            assignee,
            due,
        ]
        if scope == "me":
            row.append(t.get("project", {}).get("name", ""))
        table.add_row(*row)
    console.print(table)


@todo.command("add")
@click.argument("title")
@click.option("--project", "-P", required=True, help="Project slug.")
@click.option("--assign", default=None, help="Username to assign to (default: yourself).")
@click.option("--due", default=None, help="Due date (YYYY-MM-DD).")
@click.option("--thread", default=None, help="Thread id to attach to.")
@click.option("--desc", default=None, help="Description (markdown ok).")
@click.pass_context
@run
def todo_add(ctx, title, project, assign, due, thread, desc):
    """Add a new todo to a project."""
    c = get_client(ctx.obj["profile"])
    assignee_id = None
    if assign is None:
        # default to self
        assignee_id = c.whoami()["id"]
    elif assign == "":
        assignee_id = None  # explicit unassigned
    else:
        # resolve username → id (must be a project member)
        users = c.list_users().get("users", [])
        match = [u for u in users if u["username"] == assign.lower()]
        if not match:
            err_console.print(f"找不到用户 {assign}。")
            sys.exit(1)
        assignee_id = match[0]["id"]

    payload = {"title": title}
    if assignee_id:
        payload["assigneeId"] = assignee_id
    if due:
        # accept YYYY-MM-DD
        try:
            payload["dueDate"] = due + "T00:00:00.000Z" if "T" not in due else due
        except Exception:
            err_console.print("日期格式应为 YYYY-MM-DD。")
            sys.exit(2)
    if thread:
        payload["threadId"] = thread
    if desc:
        payload["description"] = desc

    r = c.create_todo(project, payload)["todo"]
    console.print(f":memo: 已创建 [bold]{r['title']}[/bold]")
    console.print(f"  id: {r['id']}")
    if r.get("assignee"):
        console.print(f"  负责人: {r['assignee']['name']}")
    if r.get("dueDate"):
        console.print(f"  截止: {r['dueDate'][:10]}")


@todo.command("done")
@click.argument("todo_id")
@click.pass_context
@run
def todo_done(ctx, todo_id):
    """Mark a todo as done."""
    c = get_client(ctx.obj["profile"])
    full_id = _resolve_todo_id(c, todo_id)
    r = c.update_todo(full_id, {"status": "done"})["todo"]
    console.print(f":white_check_mark: 已完成 [bold]{r['title']}[/bold]")


@todo.command("reopen")
@click.argument("todo_id")
@click.pass_context
@run
def todo_reopen(ctx, todo_id):
    """Reopen a completed todo."""
    c = get_client(ctx.obj["profile"])
    full_id = _resolve_todo_id(c, todo_id)
    r = c.update_todo(full_id, {"status": "open"})["todo"]
    console.print(f":arrows_counterclockwise: 已重新打开 [bold]{r['title']}[/bold]")


@todo.command("drop")
@click.argument("todo_id")
@click.confirmation_option(prompt="确定要删除这个待办？")
@click.pass_context
@run
def todo_drop(ctx, todo_id):
    """Delete a todo."""
    c = get_client(ctx.obj["profile"])
    full_id = _resolve_todo_id(c, todo_id)
    c.delete_todo(full_id)
    console.print(":wastebasket: 已删除")


def _resolve_todo_id(c: Client, partial: str) -> str:
    """Accept either a full id or a short prefix from `todo list` output."""
    if len(partial) >= 24:
        return partial
    # search my todos for prefix
    for status in ("open", "done", "all"):
        todos = c.list_my_todos(status=status).get("todos", [])
        for t in todos:
            if t["id"].startswith(partial):
                return t["id"]
    err_console.print(f"找不到 id 前缀 {partial}。把 `hivelab todo list` 里的完整 id 贴进来再试。")
    sys.exit(1)


# ----------------------------------------------------------- notifications ---


@main.command()
@click.option(
    "--all",
    "show_all",
    is_flag=True,
    help="Show all (including read). Default: unread only.",
)
@click.option(
    "--read",
    "mark_read",
    is_flag=True,
    help="Mark all unread as read after listing.",
)
@click.pass_context
@run
def notif(ctx, show_all, mark_read):
    """Show notifications."""
    c = get_client(ctx.obj["profile"])
    status = "all" if show_all else "unread"
    rows = c.list_notifications(status=status, limit=30).get("notifications", [])
    if not rows:
        console.print("[dim]没有通知。[/dim]")
    else:
        for n in rows:
            unread = n.get("readAt") is None
            dot = "[red]●[/red]" if unread else "[dim]·[/dim]"
            title = n["title"]
            body = n.get("body") or ""
            project = (n.get("project") or {}).get("name", "")
            console.print(f"{dot} {title}  [dim]{project}[/dim]")
            if body:
                console.print(f"   [dim]{body}[/dim]")
    if mark_read:
        r = c.mark_notifications_read()
        if r.get("updated", 0) > 0:
            console.print(f"\n[dim]标记 {r['updated']} 条为已读。[/dim]")


# ---------------------------------------------------------------- templates ---


@main.group()
def template():
    """Design and create experiment templates (suggest / create)."""


@template.command("suggest")
@click.argument("path", type=click.Path(exists=True, dir_okay=True, file_okay=True))
@click.option("--project", "-P", required=True, help="Project slug.")
@click.option(
    "--hint",
    default=None,
    help="Optional one-liner hint to the LLM, e.g. \"ML training run\".",
)
@click.option(
    "--save",
    is_flag=True,
    help="After showing the suggestion, prompt for a template name and create it.",
)
@click.option(
    "--output",
    "-o",
    default=None,
    type=click.Path(dir_okay=False),
    help="Write the suggested schema to a yaml file (for hand-editing).",
)
@click.pass_context
@run
def template_suggest(ctx, path, project, hint, save, output):
    """Suggest a template schema from a sample experiment.

    Reads a sample run (file or directory) the same way `push` does, sends
    the markdown body + embedded configs/metrics to the LLM, and shows you
    a proposed field schema. Use --save to immediately create the template;
    use -o to dump as yaml for hand-editing then `template create -f`.
    """
    src = load_source(path)
    c = get_client(ctx.obj["profile"])

    console.print(f"[dim]让大模型分析 {src.primary_path.name} 推荐模板字段…[/dim]")
    r = c.suggest_template(project, src.markdown, hint=hint)
    fields = r.get("fields", [])

    if not fields:
        err_console.print("LLM 没返回任何字段。看看样本笔记是不是太短，或者 backend LLM 配置有问题。")
        sys.exit(1)

    _print_schema(fields)

    if output:
        import yaml as _yaml
        with open(output, "w", encoding="utf-8") as f:
            _yaml.safe_dump({"fields": fields}, f, allow_unicode=True, sort_keys=False)
        console.print(f"\n[dim]已写入 {output}。可以手动编辑后再 `hivelab template create -P {project} -f {output}` 创建。[/dim]")
        return

    if save:
        name = click.prompt("模板名称（中文或英文都行）")
        out = c.create_template(project, name.strip(), fields)
        tpl = out["template"]
        console.print(
            f"\n:white_check_mark: 已创建模板 [bold]{tpl['name']}[/bold] v{tpl['version']}（{len(tpl['fieldsSchema'])} 字段）。"
        )
    else:
        console.print(
            "\n[dim]加 --save 直接保存为模板，或加 -o tpl.yaml 导出后手动编辑。[/dim]"
        )


@template.command("create")
@click.option("--project", "-P", required=True, help="Project slug.")
@click.option(
    "--name",
    "-n",
    default=None,
    help="Template name. Required unless reading from a file that contains it.",
)
@click.option(
    "--from-file",
    "-f",
    "from_file",
    default=None,
    type=click.Path(exists=True, dir_okay=False),
    help="Read schema from a yaml or json file. Top-level key `fields` (or `fieldsSchema`).",
)
@click.option(
    "--interactive",
    "-i",
    is_flag=True,
    help="Walk through field-by-field prompt to build a schema.",
)
@click.pass_context
@run
def template_create(ctx, project, name, from_file, interactive):
    """Create a new template via yaml file or interactive prompt."""
    if not from_file and not interactive:
        err_console.print("需要 -f tpl.yaml 或 --interactive。")
        sys.exit(2)

    if from_file:
        import yaml as _yaml
        with open(from_file, encoding="utf-8") as f:
            data = _yaml.safe_load(f)
        if not isinstance(data, dict):
            err_console.print(f"{from_file} 顶层应该是 dict。")
            sys.exit(2)
        fields = data.get("fields") or data.get("fieldsSchema") or []
        if not name:
            name = data.get("name") or click.prompt("模板名称")
    else:
        fields = _interactive_build_fields()
        if not name:
            name = click.prompt("模板名称")

    if not fields:
        err_console.print("字段列表为空。")
        sys.exit(2)

    _print_schema(fields)
    if not click.confirm("\n确认创建这个模板？", default=True):
        return

    c = get_client(ctx.obj["profile"])
    out = c.create_template(project, name.strip(), fields)
    tpl = out["template"]
    console.print(
        f":white_check_mark: 已创建模板 [bold]{tpl['name']}[/bold] v{tpl['version']}（{len(tpl['fieldsSchema'])} 字段）。"
    )


def _interactive_build_fields() -> list:
    console.print("[dim]进入交互模式。每个字段填完按回车；字段名留空回车结束。[/dim]\n")
    out: list = []
    while True:
        n = click.prompt(f"字段名 #{len(out) + 1}（空回车结束）", default="", show_default=False)
        n = n.strip()
        if not n:
            break
        t = click.prompt(
            "  类型 (string/number/boolean/enum/text)",
            default="string",
            type=click.Choice(["string", "number", "boolean", "enum", "text"]),
        )
        field: dict = {"name": n, "type": t}
        unit = click.prompt("  单位（如 % / s，无则留空）", default="", show_default=False).strip()
        if unit:
            field["unit"] = unit
        if t == "number":
            direction = click.prompt(
                "  指标方向 (higher_better/lower_better/none)",
                default="none",
                type=click.Choice(["higher_better", "lower_better", "none"]),
            )
            if direction != "none":
                field["direction"] = direction
        if t == "enum":
            opts = click.prompt("  选项（逗号分隔）").strip()
            field["options"] = [s.strip() for s in opts.split(",") if s.strip()]
        required = click.prompt("  必填？(y/N)", default="n").strip().lower()
        if required == "y":
            field["required"] = True
        desc = click.prompt("  说明（喂给大模型抽取时会用，可选）", default="", show_default=False).strip()
        if desc:
            field["description"] = desc
        out.append(field)
        console.print()
    return out


@template.command("list")
@click.argument("project")
@click.pass_context
@run
def template_list(ctx, project):
    """List templates of a project (alias for `templates <project>`)."""
    c = get_client(ctx.obj["profile"])
    data = c.get_project(project)["project"]
    if not data.get("templates"):
        console.print("[dim]（该项目没有模板）[/dim]")
        return
    for tpl in data["templates"]:
        console.print(f"\n[bold]{tpl['name']}[/bold]  v{tpl['version']}  (id: {tpl['id']})")
        _print_schema(tpl["fieldsSchema"])


def _print_schema(fields: list) -> None:
    """Pretty-print a fields schema as a table."""
    t = Table(show_header=True, header_style="bold", padding=(0, 1))
    t.add_column("name", style="cyan")
    t.add_column("type")
    t.add_column("unit")
    t.add_column("方向")
    t.add_column("必填")
    t.add_column("说明")
    for f in fields:
        direction = f.get("direction") or ""
        if direction == "higher_better":
            direction = "↑ 越高越好"
        elif direction == "lower_better":
            direction = "↓ 越低越好"
        t.add_row(
            f["name"],
            f["type"],
            f.get("unit") or "",
            direction,
            "✓" if f.get("required") else "",
            f.get("description") or "",
        )
    console.print(t)


if __name__ == "__main__":
    main()
