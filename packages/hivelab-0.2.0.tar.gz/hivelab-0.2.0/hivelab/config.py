"""Config file management for hivelab.

The config lives at ~/.config/hivelab/config.json and stores one or more
profiles. Most users only need the default profile; --profile flag selects
others.

    {
      "default_profile": "default",
      "profiles": {
        "default": {"url": "http://localhost:3000", "token": "lab_xxx"},
        "prod":    {"url": "https://research.example.com", "token": "lab_yyy"}
      }
    }
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


def config_dir() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
    return Path(base) / "hivelab"


def config_path() -> Path:
    return config_dir() / "config.json"


@dataclass
class Profile:
    url: str
    token: str


def _load_raw() -> dict:
    path = config_path()
    if not path.exists():
        return {"default_profile": "default", "profiles": {}}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise RuntimeError(f"config file {path} is malformed: {e}") from e


def _save_raw(data: dict) -> None:
    config_dir().mkdir(parents=True, exist_ok=True)
    path = config_path()
    # write atomically + secure perms (token is sensitive)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def load_profile(profile_name: Optional[str] = None) -> Optional[Profile]:
    """Load a profile by name. Env vars HIVELAB_URL + HIVELAB_TOKEN override
    the config file entirely when both are set."""
    env_url = os.environ.get("HIVELAB_URL")
    env_token = os.environ.get("HIVELAB_TOKEN")
    if env_url and env_token:
        return Profile(url=env_url.rstrip("/"), token=env_token)

    raw = _load_raw()
    name = profile_name or raw.get("default_profile", "default")
    p = raw.get("profiles", {}).get(name)
    if not p:
        return None
    return Profile(url=p["url"].rstrip("/"), token=p["token"])


def save_profile(name: str, url: str, token: str, set_default: bool = False) -> None:
    raw = _load_raw()
    raw.setdefault("profiles", {})[name] = {"url": url.rstrip("/"), "token": token}
    if set_default or not raw.get("default_profile"):
        raw["default_profile"] = name
    _save_raw(raw)


def delete_profile(name: str) -> bool:
    raw = _load_raw()
    profiles = raw.get("profiles", {})
    if name not in profiles:
        return False
    del profiles[name]
    if raw.get("default_profile") == name:
        # promote any remaining profile to default
        remaining = next(iter(profiles), None)
        if remaining:
            raw["default_profile"] = remaining
        else:
            raw.pop("default_profile", None)
    _save_raw(raw)
    return True


def list_profiles() -> dict:
    raw = _load_raw()
    return {
        "default": raw.get("default_profile"),
        "profiles": {
            name: {"url": p["url"], "token_preview": p["token"][:8] + "…"}
            for name, p in raw.get("profiles", {}).items()
        },
    }
