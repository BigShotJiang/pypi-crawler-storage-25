#!/usr/bin/env bash
# Usage: scripts/release.sh 0.2.0
# Bumps pyproject.toml version, builds, uploads to PyPI.
#
# Expects a project-scoped token in env var HIVELAB_PYPI_TOKEN, or in
# ~/.pypirc under [pypi] / password = pypi-XXXX.
set -euo pipefail

VERSION="${1:-}"
if [ -z "$VERSION" ]; then
  echo "usage: $0 <new-version>   e.g. $0 0.2.0" >&2
  exit 2
fi

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

# 1. bump version in pyproject.toml
sed -i.bak "s/^version = \".*\"/version = \"$VERSION\"/" pyproject.toml
rm -f pyproject.toml.bak
grep '^version = ' pyproject.toml

# 2. clean + build
rm -rf dist build *.egg-info
python -m build

# 3. sanity check
python -m twine check dist/*

# 4. upload
if [ -n "${HIVELAB_PYPI_TOKEN:-}" ]; then
  TWINE_USERNAME=__token__ TWINE_PASSWORD="$HIVELAB_PYPI_TOKEN" python -m twine upload dist/*
else
  python -m twine upload dist/*
fi

echo
echo "✅ hivelab v$VERSION released"
echo "   https://pypi.org/project/hivelab/$VERSION/"
echo
echo "Don't forget to: git commit -am 'release v$VERSION' && git tag v$VERSION"
