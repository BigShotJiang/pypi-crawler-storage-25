import os
import tree_sitter_python as tspy
from tree_sitter import Language, Parser

PY_LANGUAGE = Language(tspy.language())
parser = Parser(PY_LANGUAGE)


def parse_repo_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    tree = parser.parse(bytes(content, "utf8"))
    nodes = []

    # -----------------------------
    # CONTEXT STATE (THE KEY FIX)
    # -----------------------------
    module_name = os.path.splitext(os.path.basename(file_path))[0]

    class_stack = []

    def get_class_path():
        return ".".join(class_stack) if class_stack else None

    def build_qualified_name(name):
        parts = [module_name]

        class_path = get_class_path()
        if class_path:
            parts.append(class_path)

        parts.append(name)

        return ".".join(parts)

    # -----------------------------
    # AST WALK
    # -----------------------------
    def walk(node):
        nonlocal class_stack

        # CLASS DEFINITION
        if node.type == "class_definition":
            name_node = node.child_by_field_name("name")
            if name_node:
                class_name = content[name_node.start_byte:name_node.end_byte]

                class_stack.append(class_name)

                nodes.append({
                    "name": class_name,
                    "qualified_name": build_qualified_name(class_name),
                    "kind": "cls",
                    "code": content[node.start_byte:node.end_byte],
                    "start": node.start_point[0],
                    "end": node.end_point[0],
                    "parent": ".".join(class_stack[:-1]) if len(class_stack) > 1 else None
                })

                for child in node.children:
                    walk(child)

                class_stack.pop()
                return

        # FUNCTION DEFINITION
        if node.type == "function_definition":
            name_node = node.child_by_field_name("name")
            if name_node:
                func_name = content[name_node.start_byte:name_node.end_byte]

                nodes.append({
                    "name": func_name,
                    "qualified_name": build_qualified_name(func_name),
                    "kind": "fn",
                    "code": content[node.start_byte:node.end_byte],
                    "start": node.start_point[0],
                    "end": node.end_point[0],
                    "parent": class_stack[-1] if class_stack else None
                })

                return

        # CONTINUE TRAVERSAL
        for child in node.children:
            walk(child)

    walk(tree.root_node)
    return nodes