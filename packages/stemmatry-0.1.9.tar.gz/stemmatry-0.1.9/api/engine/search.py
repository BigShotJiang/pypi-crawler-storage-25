from django.db.models import Q

from stemmatry.api.models import StemmaNode


# -----------------------------------
# BASIC CONTEXT API (unchanged)
# -----------------------------------
def get_node_context(name, path_hint=None):
    try:
        try:
            node = StemmaNode.objects.get(qualified_name=name)
        except:
            node = StemmaNode.objects.get(name=name)

        context_blocks = []

        context_blocks.append(f"--- CODE BLOCK: {node.name} ({node.kind}) ---")
        context_blocks.append(node.content)

        if node.parent:
            parent = node.parent
            context_blocks.append(
                f"\n--- PARENT CONTEXT: Defined inside {parent.kind} '{parent.name}' ---"
            )
            context_blocks.append(parent.content)

        return "\n".join(context_blocks)

    except StemmaNode.DoesNotExist:
        return f"Error: Node '{name}' not found in Stemmatry index."
    except StemmaNode.MultipleObjectsReturned:
        nodes = StemmaNode.objects.filter(name=name)
        if nodes.count() > 1 and path_hint:
            # Try to narrow it down by the hint (e.g., "TradeTrace")
            refined_nodes = nodes.filter(path__icontains=path_hint)
            if refined_nodes.exists():
                nodes = refined_nodes
                
        paths = [n.path for n in nodes]
        return f"Error: Multiple matches for '{name}'. Paths: {paths}"


# -----------------------------------
# RANKING
# -----------------------------------
def _score_node(node: StemmaNode, query: str) -> int:
    score = 0
    q = query.lower()

    if node.qualified_name == query:
        score += 100

    if node.name == query:
        score += 50

    if node.name.lower() == q:
        score += 25

    if q in node.name.lower():
        score += 10

    if node.path:
        score += 5

    return score

def _get_best_node(query: str) -> StemmaNode | None:
    """
    MVP symbol resolver:
    returns the best matching node for a query.
    """

    # 1. COLLECT CANDIDATES
    candidates = list(
        StemmaNode.objects.filter(
            Q(name__icontains=query) |
            Q(qualified_name__icontains=query)
        )
    )

    # strong seeds
    direct = list(
        StemmaNode.objects.filter(qualified_name=query)
        | StemmaNode.objects.filter(name=query)
    )

    candidates = direct + candidates

    if not candidates:
        return None

    # 2. DEDUPE
    seen = set()
    unique = []

    for c in candidates:
        if c.id not in seen:
            seen.add(c.id)
            unique.append(c)

    # 3. RANK
    ranked = sorted(
        unique,
        key=lambda n: _score_node(n, query),
        reverse=True
    )

    return ranked[0] if ranked else None

# -----------------------------------
# CLEAN PARENT (REMOVE CHILD METHOD)
# -----------------------------------
def strip_self_from_parent(parent_content: str, child_name: str) -> str:
    lines = parent_content.split("\n")
    cleaned = []

    skipping = False

    for line in lines:
        if line.strip().startswith(f"def {child_name}"):
            skipping = True
            continue

        if skipping and (line.startswith("def ") or line.startswith("class ")):
            skipping = False

        if not skipping:
            cleaned.append(line)

    return "\n".join(cleaned)



# -----------------------------------
# TRUNCATION
# -----------------------------------
def truncate(text: str, limit: int = 2000) -> str:
    return text[:limit] if text else ""


def build_context(node, intent: str) -> str:
    """
    Smart context shaping based on intent.
    """

    MAX_CODE = 1500
    MAX_PARENT = 1000
    MAX_SIBLINGS = 5

    output = []

    # ----------------------------
    # PRIMARY (always highest priority)
    # ----------------------------
    output.append("[PRIMARY_SYMBOL]")
    output.append(node.name)
    output.append(truncate(node.content, MAX_CODE))

    # ----------------------------
    # INTENT-AWARE CONTEXT
    # ----------------------------

    if intent in ["explain", "architecture"]:
        if node.parent:
            output.append("\n[PARENT_CONTEXT]")
            output.append(
                truncate(
                    strip_self_from_parent(node.parent.content, node.name),
                    MAX_PARENT
                )
            )

    if intent == "debug":
        # debugging benefits from siblings (alternative flows)
        siblings = node.parent.children.exclude(id=node.id) if node.parent else []

        output.append("\n[SIBLINGS]")
        for sib in siblings[:MAX_SIBLINGS]:
            output.append(f"{sib.name} | {sib.kind}")

    return "\n".join(output)