def classify_intent(query: str) -> str:
    q = query.lower().strip()

    explain_keywords = [
        "how", "explain", "what does", "walkthrough", "step by step"
    ]

    debug_keywords = [
        "bug", "error", "issue", "why", "fails", "not working", "trace"
    ]

    architecture_keywords = [
        "architecture", "design", "system", "flow", "structure"
    ]

    if any(k in q for k in explain_keywords):
        return "explain"

    if any(k in q for k in debug_keywords):
        return "debug"

    if any(k in q for k in architecture_keywords):
        return "architecture"

    return "lookup"