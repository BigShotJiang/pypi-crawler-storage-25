import os

from django.core.management.base import BaseCommand

from stemmatry.api.models import StemmaNode

from stemmatry.api.engine.parser import parse_repo_file


class Command(BaseCommand):
    help = 'Ingest a Python repository into the Stemmatry database'

    def add_arguments(self, parser):
        # The path to the folder you want to index
        parser.add_argument('path', type=str)
    
    def handle(self, *args, **options):
        repo_path = options['path']

        if not os.path.exists(repo_path):
            self.stderr.write(self.style.ERROR(f"Path does not exist: {repo_path}"))
            return
        
        for root, dirs, files in os.walk(repo_path):

            dirs[:] = [d for d in dirs if d not in ['venv', '.venv', 'env', '__pycache__', 'virtualenv', 'ENV', 'env.bak', 'venv.bak', 'node_modules'] and not d.startswith('.')]

            for file in files:
                if file.endswith('.py'):
                    full_path = os.path.join(root, file)
                    self.stdout.write(f"Parsing: {full_path}")

                    try:
                        nodes_data = parse_repo_file(full_path)

                        # We use this to link children to parents within the same file
                        file_nodes = {}

                        for data in nodes_data:
                            # Create or update the node
                            node, created = StemmaNode.objects.update_or_create(
                                name=data['name'],
                                path=full_path,
                                qualified_name=data['qualified_name'],
                                line_start=data['start'],
                                defaults={
                                    'kind': data['kind'],
                                    'content': data['code'],
                                    'line_end': data['end'],
                                    'qualified_name': data['qualified_name'],
                                }
                            )
                            file_nodes[data['name']] = node
                            
                            # If the parser identified a parent, link it now
                            if data['parent'] and data['parent'] in file_nodes:
                                node.parent = file_nodes[data['parent']]
                                node.save()

                    except Exception as e:
                        self.stderr.write(self.style.ERROR(f"Failed to parse {file}: {str(e)}"))

        self.stdout.write(self.style.SUCCESS('Stemmatry Ingestion Complete!'))