import webbrowser
import time
import httpx
import os
import json
from pathlib import Path

# Local Config
# BRAIN_URL = "http://localhost:8000/api"
# WEB_URL = "http://localhost:3000"

BRAIN_URL = "https://stemmatry-infra-production.up.railway.app/api"
WEB_URL = "https://stemmatry-web.vercel.app"


def get_claude_config_path():
    """Finds the Claude config, checking both standard and Store/Package paths."""
    # 1. The Standard Path
    standard_path = Path.home() / "AppData/Roaming/Claude/claude_desktop_config.json"
    
    # 2. The Microsoft Store / AppX Path (The one you found)
    # We search for the 'Claude_...' directory because the suffix might change
    package_root = Path.home() / "AppData/Local/Packages"
    store_path = None
    
    if package_root.exists():
        # Look for a folder starting with 'Claude_'
        claude_packages = list(package_root.glob("Claude_*"))
        if claude_packages:
            # Construct the path within the sandbox
            potential_store_path = claude_packages[0] / "LocalCache/Roaming/Claude/claude_desktop_config.json"
            if potential_store_path.exists():
                store_path = potential_store_path

    # Return Store path if it exists, otherwise default to Standard
    selected_path = store_path if store_path else standard_path
    print(f"📍 Target Config: {selected_path}")
    return selected_path

def setup():
    print("🚀 Stemmatry Local Setup Wizard")
    
    with httpx.Client() as client:
        # 1. Start Handshake
        print("Initiating handshake with local Brain...")
        res = client.post(f"{BRAIN_URL}/cli/auth/start/")
        session_id = res.json()["session_id"]
        
        # 2. Open Local Frontend
        auth_url = f"{WEB_URL}/cli-login/{session_id}"
        print(f"🔗 Opening browser: {auth_url}")
        webbrowser.open(auth_url)
        
        # 3. Polling the Brain
        print("Waiting for browser authorization...", end="", flush=True)
        api_key = None
        while not api_key:
            try:
                poll_res = client.get(f"{BRAIN_URL}/cli/auth/poll/{session_id}/")
                if poll_res.status_code == 200:
                    api_key = poll_res.json().get("api_key")
                    print("\n✅ Authorization received!")
                else:
                    print(".", end="", flush=True)
                    time.sleep(2)
            except Exception:
                time.sleep(2)
        
        # 4. Inject into Claude
        update_claude_config(api_key)

import sys
import shutil

def update_claude_config(api_key):
    config_path = get_claude_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Load existing or create new
    if config_path.exists():
        with open(config_path, 'r') as f:
            try:
                config = json.load(f)
            except json.JSONDecodeError:
                config = {"mcpServers": {}}
    else:
        config = {"mcpServers": {}}

    # UNIVERSAL LOGIC: 
    # 1. Look for the 'stemmatry' command in the system PATH
    # 2. Fallback to the 'bin' or 'Scripts' folder of the current Python environment
    executable_name = "stemmatry.exe" if os.name == "nt" else "stemmatry"
    executable_path = shutil.which("stemmatry")
    
    if not executable_path:
        # If shutil can't find it (not in PATH yet), check the current Python's script directory
        executable_path = os.path.join(os.path.dirname(sys.executable), executable_name)

    # If both fail, we fallback to a generic command (less ideal but works as last resort)
    command = executable_path if os.path.exists(executable_path) else "stemmatry"

    config["mcpServers"]["stemmatry"] = {
        "command": command, 
        "args": [], # No args needed! The entry point knows to run mcp_server.py
        "env": {
            "STEMMATRY_API_KEY": api_key,
            "DJANGO_SETTINGS_MODULE": "stemmatry.core.settings",
            # We don't send PYTHONPATH because the package handles its own imports
        }
    }

    with open(config_path, 'w') as f:
        json.dump(config, f, indent=4)
    
    print(f"✨ Universal configuration written to: {config_path}")

if __name__ == "__main__":
    setup()