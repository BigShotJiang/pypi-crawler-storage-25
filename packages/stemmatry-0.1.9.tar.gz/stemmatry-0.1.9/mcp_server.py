import os
import django
import httpx
import hashlib

from mcp.server.fastmcp import FastMCP

from asgiref.sync import sync_to_async # <--- Add this import




# 1. Initialize Django so we can use the models
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'stemmatry.core.settings')
django.setup()

from stemmatry.api.models import StemmaNode
from stemmatry.api.engine.search import get_node_context, build_context, _get_best_node
from stemmatry.api.engine.intent import classify_intent
from stemmatry.api.management.commands.ingest import Command as IngestCommand

# 2. Create the MCP Server
mcp = FastMCP("Stemmatry")

BRAIN_VERIFY_URL = "https://stemmatry-infra-production.up.railway.app/api/auth/user/engine/verify/"


def generate_project_signature(path: str):
    """
    Hashes the actual content of every code file.
    Deterministic and collision-proof.
    """
    hasher = hashlib.sha256()
    # Align this with your Django Command ignore list
    ignored_dirs = {'venv', '.venv', 'env', '__pycache__', 'virtualenv', '.git', 'node_modules'}

    for root, dirs, files in os.walk(path):
        dirs[:] = [d for d in dirs if d not in ignored_dirs and not d.startswith('.')]
        
        for f in sorted(files):
            if f.endswith('.py'):
                file_path = os.path.join(root, f)
                try:
                    with open(file_path, 'rb') as f_obj:
                        while chunk := f_obj.read(8192):
                            hasher.update(chunk)
                except (OSError, FileNotFoundError):
                    continue
                
    return hasher.hexdigest()


def get_repo_stats(path: str):
    import ast, os
    total_lines = 0
    total_nodes = 0

    # Strict list matching your IngestCommand
    ignored_dirs = {'venv', '.venv', 'env', '__pycache__', 'virtualenv', 'ENV', 'env.bak', 'venv.bak', '.git', '.idea', '.vscode', 'node_modules'}

    for root, dirs, files in os.walk(path):
        # Filter directories: remove ignored ones and any hidden ones starting with '.'
        dirs[:] = [d for d in dirs if d not in ignored_dirs and not d.startswith('.')]
        
        for file in files:
            if file.endswith(".py"):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        content = f.read()
                        total_lines += len(content.splitlines())
                        
                        tree = ast.parse(content)
                        for node in ast.walk(tree):
                            if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef)):
                                total_nodes += 1
                except Exception:
                    continue 
                    
    return total_nodes, total_lines


async def verify_engine_access(action: str = "query", metadata: dict = None):
    """
    Step 2: The Engine sends the passport to the Brain.
    """
    # 1. Grab the key the user set in their environment
    api_key = os.getenv("STEMMATRY_API_KEY")
    
    if not api_key:
        raise PermissionError("STEMMATRY_API_KEY not found. Please set it in your environment or in config file environment.")

    # --- NEW: Construct the payload ---
    payload = {"action": action}
    if metadata:
        payload.update(metadata)

    # 2. Ping the Brain
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                BRAIN_VERIFY_URL,
                headers={"Authorization": f"Bearer {api_key}"},
                json=payload
            )
            
            if response.status_code == 200:
                data = response.json()
                print(f"Verified user: {data.get('user')}")
                # return True
                return response.json()
            # Handle specific error codes from the Brain
            elif response.status_code == 402:
                # raise PermissionError(f"Insufficient Credits: {response.json().get('detail')}")
                return {
                    "valid": False, 
                    "detail": "Invalid API Key. Please check your STEMMATRY_API_KEY in your config file."
                }
            elif response.status_code == 403:
                return {
                    "valid": False, 
                    "detail": f"Slot Limit Reached: {response.json().get('detail')}"
                }

            else:
                return {
                    "valid": False,
                    "detail": f"Access Denied: {response.text}"
                }

        except httpx.RequestError as e:
            return {"valid": False, "detail": "Brain is offline. Check your internet or Stemmatry server status."}


@mcp.tool()
async def ingest_codebase(path: str) -> str:
    """
    Ingests a Python codebase to provide structural lineage.
    
    IMPORTANT: The path MUST be an absolute path (e.g., 'C:/Users/Dev/Project').
    If the user says '.' or gives a relative path, ask them for the 
    full absolute path to their project root before running this tool.

    """
    try:
        # --- NEW: VALIDATION GUARD ---
        if not path or not os.path.exists(path):
            return f"Ingestion failed: The path '{path}' does not exist. Please provide a valid absolute path."
        
        if not os.path.isdir(path):
            return f"Ingestion failed: '{path}' is a file, not a directory. Please provide the project root directory."
        
        # 0. PRE-FLIGHT SCAN
        nodes, lines = await sync_to_async(get_repo_stats)(path)
        
        # --- THE GATEKEEPER ---
        if nodes == 0:
            return (
                f"Ingestion aborted: No indexable Python symbols found in '{path}'. "
                "Stemmatry currently only supports Python lineage. No credits were used."
            )

        # 1. GENERATE IDENTITY (The DNA)
        # We do this first so the Brain knows EXACTLY what codebase this is.
        signature = await sync_to_async(generate_project_signature)(path)


        # 2. THE GUARD: This pings the Brain before doing anything else
        access_data = await verify_engine_access(
            action='ingest',
            metadata={
                'node_count': nodes, 
                'line_count': lines,
                'identifier': signature,
                'path': path,
            }
        )

        # Now check the 'valid' key in the returned dict
        if not access_data.get('valid'):
            return f"Access Denied: {access_data.get('detail', 'Unknown error')}"

        # We define a small wrapper to pass the path correctly
        def run_ingest():
            
            # Clean up any existing nodes for this exact path
            StemmaNode.objects.filter(path__icontains=path).delete()

            ingester = IngestCommand()
            # We pass path as a kwarg because handle() expects options dict
            ingester.handle(path=path)
            
        # Run the blocking Django command in a separate thread
        await sync_to_async(run_ingest, thread_sensitive=False)()
        
        return f"Successfully mapped the 'Tree' for {path}. I now have deterministic lineage of the code."
    except Exception as e:
        return f"Ingestion failed: {str(e)}"


@mcp.tool()
async def deindex_codebase(path: str) -> str:
    """
    Removes/De-indexes a codebase from the index and frees up an indexing slot.
    
    CRITICAL SAFETY RULES:
    1. NEVER call this tool automatically or autonomously.
    2. If a 'Slot Limit Reached' error occurs, you MUST list the current 
       codebases to the user and ask them explicitly which one to remove.
    3. You are FORBIDDEN from choosing a codebase to delete on behalf of the user.
    4. Only execute this tool AFTER the user provides the specific path or codebase to remove.
    """
    try:
        # 1. Normalize the path (Fixes slashes and casing)
        # This converts "/startup/wooobet" to "D:\\MyWork\\Projects\\Startup\\WoooBet"
        clean_path = os.path.normpath(path)

        # 2. Notify Brain
        await verify_engine_access(action="deindex", metadata={"path": clean_path, "identifier": "manual_purge"})

        # 3. Local Purge with Case-Insensitive Matching
        def purge_data():
            # Use __istartswith to handle Windows drive letter casing issues
            deleted, _ = StemmaNode.objects.filter(path__istartswith=clean_path).delete()
            return deleted

        count = await sync_to_async(purge_data)()
        
        if count == 0:
            # Helpful debugging for you and Claude
            return f"De-index attempted for {clean_path}, but 0 nodes were found. Check if the path is absolute."
            
        return f"Successfully de-indexed {clean_path}. {count} nodes removed."
    except Exception as e:
        return f"Error during de-indexing: {str(e)}"


@mcp.tool()
async def list_codebases() -> str:
    """
    Lists all indexed codebase roots. Use these paths for de-indexing.
    """
    try:
        # Action 'list' costs 0 credits in your Brain logic
        data = await verify_engine_access(action="list")

        # --- THE FIX: Stop the silent failure ---
        if not data.get("valid"):
            return f"Authentication Error: {data.get('detail')}"

        repos = data.get("codebases", [])

        if not repos:
            return "The index is currently empty."

        output = ["=== ACTIVE CODEBASE SLOTS ==="]
        output.extend([f"- {repo}" for repo in sorted(repos)])
            
        return "\n".join(output)
    except Exception as e:
        return f"Failed to list codebases: {str(e)}"



@mcp.tool()
async def get_code_lineage(name: str, path_hint=None) -> str:
    """
    Retrieves the code for a function or class, plus its parent context 
    (the 'Tree-Guided' lineage) from the Stemmatry index.

    If multiple matches exist, provide a 'path_hint' (any part of the absolute path) 
    to disambiguate.
    """

    # 1. THE GUARD: This pings the Brain before doing anything else
    await verify_engine_access(action="get_code_lineage")
    
    return await sync_to_async(get_node_context)(name, path_hint=path_hint)


@mcp.tool()
async def resolve_symbol(query: str) -> str:

    """
    High-level tool to resolve, explain, or debug code symbols based on a natural language query.
    
    Use this tool when you need to:
    - Locate a specific class, function, or method by name or description.
    - Understand the logic of a specific code block (Explain mode).
    - Identify potential bugs or failure points in a symbol (Debug mode).
    - Understand how a symbol fits into the broader system (Architecture mode).
    
    Args:
        query: A natural language description or the exact name of the code symbol 
               (e.g., 'the user registration logic' or 'create_superuser').
    """

    # 1. THE GUARD: This pings the Brain before doing anything else
    await verify_engine_access(action="query")

    intent = classify_intent(query)

    # 🔥 Get best node directly from full query
    node = await sync_to_async(_get_best_node)(query)

    if not node:
        return f"Symbol not found for query: {query}"

    # 🔥 Build structured context
    context = build_context(node, intent)

    # ----------------------------
    # LOOKUP
    # ----------------------------
    if intent == "lookup":
        return f"""
[MODE: LOOKUP]

Return the symbol information exactly as provided.
Do NOT explain unless explicitly asked.

{context}
"""

    # ----------------------------
    # EXPLAIN
    # ----------------------------
    if intent == "explain":
        return f"""
[INSTRUCTION]
Explain the following code step by step.

Use ONLY the provided context.

{context}
"""

    # ----------------------------
    # DEBUG
    # ----------------------------
    if intent == "debug":
        return f"""
[MODE: DEBUG]

Analyze the code strictly for:
- possible bugs
- failure points
- edge cases

If information is missing, ASK for it instead of guessing.

{context}
"""

    # ----------------------------
    # ARCHITECTURE
    # ----------------------------
    if intent == "architecture":
        return f"""
[INSTRUCTION]
Explain system design and relationships.

{context}
"""

    return context



@mcp.tool()
async def debug_index(query: str) -> str:
    """
    Searches the internal Stemma index for raw symbol matches. 
    
    Use this tool as a fallback if 'resolve_symbol' fails to find a specific name, 
    or if you want to see all occurrences of a string across the codebase paths 
    to verify what has been indexed.
    
    Args:
        query: The string or partial name to search for in the symbol index.
    """

    # 1. THE GUARD: This pings the Brain before doing anything else
    await verify_engine_access(action="debug_index")

    results = await sync_to_async(lambda: list(
        StemmaNode.objects.filter(name__icontains=query).values(
            "name", "qualified_name", "path"
        )
    ))()

    if not results:
        return f"No results for: {query}"

    output = []
    output.append(f"=== DEBUG INDEX: {query} ===")

    for r in results:
        output.append(
            f"- {r['name']} | {r['qualified_name']} | {r['path']}"
        )

    return "\n".join(output)


if __name__ == '__main__':
    mcp.run()