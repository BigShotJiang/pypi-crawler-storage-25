[![License: MIT](https://img.shields.io/github/license/seixasgroup/plusu?color=green&style=for-the-badge)](LICENSE)    [![PyPI](https://img.shields.io/pypi/v/plusu?color=red&style=for-the-badge)](https://pypi.org/project/plusu/)

# PLUSU

PLUSU is a Python toolkit for the first-principles determination of Hubbard $U$ parameters. It automates linear response calculations based on the density functional theory (DFT) approach pioneered by Cococcioni and de Gironcoli.

## Installation

## Usage

## Getting started

