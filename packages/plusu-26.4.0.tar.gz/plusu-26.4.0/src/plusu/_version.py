# -*- coding: utf-8 -*-
# file: _version.py

__version__ ="26.4.0"  # YY.MM.incremental
