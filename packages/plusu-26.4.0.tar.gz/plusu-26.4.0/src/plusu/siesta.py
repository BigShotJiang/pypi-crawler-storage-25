# -*- coding: utf-8 -*-
# file: siesta.py

class SIESTAPU:
    def __init__(self, calc):
        self.calc = calc
