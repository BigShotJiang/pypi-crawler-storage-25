# -*- coding: utf-8 -*-
# file: gpaw.py

class GPAWPU:
    def __init__(self, calc):
        self.calc = calc

