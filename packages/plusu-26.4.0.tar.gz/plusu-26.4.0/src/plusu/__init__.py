# -*- coding: utf-8 -*-
# file: __init__.py

import warnings
warnings.filterwarnings("ignore")

from ase.parallel import parprint as print

from ._version import __version__
