# -*- coding: utf-8 -*-
# file: vasp.py

class VASPPU:
    def __init__(self, calc):
        self.calc = calc