---
title: Import and Export Datasets
description: Move datasets in and out of Staso as CSVs, or synthesize new entries from existing ones with st.dataset.generate.
---

# Import and Export Datasets

Move datasets in and out of Staso as CSVs, or synthesize new entries from existing ones.

```python
import staso as st

st.init(api_key="...", workspace_slug="...")

count = st.dataset.upload_csv(ds.id, "./entries.csv", split="train")
path  = st.dataset.download_csv(ds.id, "./out.csv")

new_entries = st.dataset.generate(
    ds.id,
    count=50,
    prompt="Generate refund scenarios with amount > $500",
)
```

## Upload CSV

```python
count = st.dataset.upload_csv(
    dataset_id,
    "./entries.csv",
    split="train",
)
```

Column names in the CSV header must match existing dataset columns (create them first with `st.dataset.create(..., columns=[...])` — see [/docs/datasets/manage](/docs/datasets/manage)). Returns the number of entries inserted.

## Download CSV

```python
path = st.dataset.download_csv(
    dataset_id,
    "./out.csv",
    split=None,
)
```

Writes every entry to `file_path` and returns the resolved `Path`. Pass `split="test"` to export only one split.

## Synthetic generation

`generate` asks Staso to synthesize new entries that match the dataset's schema and style.

```python
entries = st.dataset.generate(
    dataset_id,
    count=50,
    prompt="Generate refund scenarios where the customer is upset and the amount is over $500",
    seed_entry_ids=["ent_abc", "ent_def"],
)
```

- `count` — how many new entries to generate. Default `10`.
- `prompt` — natural-language instructions to steer the generator.
- `seed_entry_ids` — optional list of existing entries to ground the generator on. Use this to keep the synthetic batch on-distribution with your real data.

Generated rows are appended to the dataset and returned as a list of `DatasetEntry`.

## Next

- [Create and manage datasets](/docs/datasets/manage)
- [Evaluate a dataset](/docs/datasets/evaluate)
