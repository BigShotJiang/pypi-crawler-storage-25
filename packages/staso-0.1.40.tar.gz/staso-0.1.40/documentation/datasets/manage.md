---
title: Create and Manage Datasets
description: Full CRUD for Staso datasets, entries, and folders using the st.dataset Python SDK.
---

# Create and Manage Datasets

Every dataset operation is a top-level function on `staso.dataset`. No classes to instantiate.

```python
import staso as st

st.init(api_key="...", workspace_slug="...")

ds = st.dataset.create(
    name="eval-refunds",
    description="Refund-flow regressions",
    columns=[
        {"name": "input", "column_type": "input"},
        {"name": "expected", "column_type": "expected_output"},
    ],
)
st.dataset.add_entry(ds.id, {"input": "...", "expected": "refund_issued"}, split="test")
```

## Dataset CRUD

```python
ds = st.dataset.create(
    name="eval-refunds",
    description="Refund-flow regressions",
    columns=[{"name": "input", "column_type": "input"}],
    folder_id=None,
)

ds = st.dataset.get(dataset_id)

datasets = st.dataset.list(folder_id=None, limit=100, offset=0)

ds = st.dataset.update(dataset_id, name="eval-refunds-v2", description="New description")

st.dataset.delete(dataset_id)
```

`create` returns a `Dataset` with `id`, `name`, `description`, `folder_id`, `columns`, `entry_count`, `created_at`, `updated_at`.

## Entries

```python
entry = st.dataset.add_entry(
    ds.id,
    {"input": "I want a refund", "expected": "refund_issued"},
    split="train",
)

entries = st.dataset.add_entries(
    ds.id,
    [
        {"input": "case a"},
        {"input": "case b"},
    ],
    split="test",
)

rows = st.dataset.list_entries(ds.id, split=None, limit=100, offset=0)

st.dataset.update_entry(ds.id, entry.id, data={"input": "updated text"})

st.dataset.delete_entry(ds.id, entry.id)
```

Each `DatasetEntry` has `id`, `dataset_id`, `data`, `split`, `source_type`, `created_at`. `source_type` is set automatically when the entry came from a trace — see [/docs/datasets/curate-from-traces](/docs/datasets/curate-from-traces).

## Folders

Group datasets by workstream, team, or feature.

```python
folder = st.dataset.create_folder("evals/refunds")

folders = st.dataset.list_folders(parent_id=None)

st.dataset.delete_folder(folder.id)
```

## ColumnType

Column types drive how the dashboard and evaluator interpret each field.

| Value | Purpose |
|---|---|
| `variable` | Free-form variable, default |
| `input` | Agent input |
| `output` | Agent output |
| `expected_output` | Ground truth for scoring |
| `expected_tool_calls` | Ground-truth tool trajectory |
| `scenario` | Scenario description |
| `expected_steps` | Ground-truth step list |
| `conversation_history` | Prior turns |
| `files` | Attached files |
| `custom` | Escape hatch |

```python
from staso.dataset import ColumnType

ColumnType.INPUT           # "input"
ColumnType.EXPECTED_OUTPUT # "expected_output"
```

## SplitType

| Value | Use |
|---|---|
| `train` | Training split |
| `test` | Held-out eval split |
| `validation` | Tuning split |

```python
from staso.dataset import SplitType

st.dataset.add_entry(ds.id, {"input": "x"}, split=SplitType.TEST)
```

Strings (`"train"`, `"test"`, `"validation"`) are accepted anywhere `SplitType` is.

## Next

- [Curate datasets from traces](/docs/datasets/curate-from-traces)
- [Evaluate a dataset](/docs/datasets/evaluate)
