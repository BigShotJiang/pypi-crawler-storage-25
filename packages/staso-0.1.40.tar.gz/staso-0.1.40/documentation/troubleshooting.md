---
title: Staso SDK troubleshooting
description: Fix 403 plan errors, 429 rate limits, silent traces, guard fail-open, and Claude Code or Codex hooks that are not firing.
---

# Staso SDK troubleshooting

Symptom → cause → fix for the most common issues when running the Staso Python SDK in production.

```bash
export STASO_DEBUG=1   # turn on SDK debug logs before reproducing any issue
```

## 403 — "Organization has no active plan"

**Symptom:** Ingest responses return `403` with `Organization has no active plan`. The dashboard shows no new spans.

**Cause:** Your organization is on the free tier (`no_plan`), which is blocked by default.

**Fix:** Subscribe to a paid plan at [staso.ai/pricing](https://staso.ai/pricing). Tracing resumes on the next request. See [pricing](/docs/pricing) for plan quotas.

## 429 — rate limited

**Symptom:** Ingest returns `429` with a `Retry-After` header. Debug logs show `ingest rate limited`.

**Cause:** You exceeded the per-minute, per-hour, or monthly ingestion cap for your plan.

**Fix:** The SDK honors `Retry-After` automatically. For sustained overages, upgrade the plan or lower trace volume. See [plan limits](/docs/pricing).

## SDK silently not sending data

**Symptom:** No errors, no traces on the dashboard.

**Cause:** Most commonly: missing API key, missing agent name, `enabled=False`, or a network block on `base_url`.

**Fix:**

1. Confirm `STASO_API_KEY` and `STASO_AGENT_NAME` are set (or passed to `st.init`).
2. Check for `enabled=False` overrides on `st.init` — the default is `True`.
3. Set `STASO_DEBUG=1` and re-run. Look for `ingest returned` lines.
4. Verify outbound HTTPS to `https://api.staso.ai` (or your custom `base_url`).

## Guard returning `allow` unexpectedly

**Symptom:** Guard lets through calls you expected it to block. No errors raised.

**Cause:** Guard defaults to **fail-open** on transport errors (network, timeout, backend down) so the SDK never crashes your agent.

**Fix:** To fail closed instead, set it per call or globally:

```python
result = st.guard(tool_name="shell", tool_input={"cmd": "rm -rf /"}, fail_closed=True)
# or process-wide:
# export STASO_GUARD_FAIL_CLOSED=true
```

See [manual guard checks](/docs/guard/manual-checks).

## Claude Code or Codex hooks not firing

**Symptom:** `staso setup` ran successfully, but no traces appear when you use the CLI agent.

**Cause:** The settings file drifted after an SDK upgrade, or the wrong scope was used.

**Fix:**

```bash
staso status            # verify which files contain Staso hooks
staso sync              # re-apply hooks for the current SDK version
```

If `status` shows `not configured`, re-run `staso setup --target <agent>` with `--scope global`. See the [CLI reference](/docs/cli).

## `ImportError` on `staso.integrations.patch_anthropic`

**Symptom:** `ImportError` or `ModuleNotFoundError` when calling `patch_anthropic` or `patch_openai`.

**Cause:** The vendor SDK is not installed — Staso declares it as an optional extra.

**Fix:**

```bash
pip install "staso[anthropic]"   # or "staso[openai]", or "staso[all]"
```

## Stale hook config after SDK upgrade

**Symptom:** After `pip install --upgrade staso`, CLI agents trace inconsistently or miss events.

**Cause:** The settings file still references the old Python path or lacks newly-added hook events.

**Fix:**

```bash
staso sync
```

`staso update` does `pip install --upgrade staso` followed by `staso sync` in one step.

## See also

- [CLI reference](/docs/cli)
- [SDK configuration](/docs/sdk/configuration)
- [Pricing and plan limits](/docs/pricing)
- [Manual guard checks](/docs/guard/manual-checks)
