---
title: Connect GitHub
description: Connect GitHub for source-aware diagnosis and Fix PRs.
---

# Connect GitHub

Connect GitHub so Staso can read your source code during diagnosis and open fix pull requests.

| | Without GitHub | With GitHub |
|---|---|---|
| **Diagnosis input** | Trace data only | Trace data + source code at the exact failing version |
| **Fix PRs** | Disabled | Enabled — requires [Deep runs](/docs/heal/deep-runs) |

## Setup

1. Go to **Settings -> Integrations** in your dashboard
2. Click **Connect** on the GitHub card
3. Install the Staso GitHub App on your org or personal account
4. Choose **All repositories** or select specific repos

Once connected, Staso matches repos to traces automatically using [version tracking](/docs/guides/vcs-tracking) metadata. Multi-repo setups work out of the box.

## Permissions

Staso requests two permission scopes on connected repositories:

- **Read**: source code — used to read files at the exact version your agent ran on
- **Write**: contents and pull requests — used to push fix branches and open PRs when you trigger a fix

No force pushes. No merges. No access outside the repos you select.

## Private repos

Private repos are supported. The GitHub App grants access only to the repos you select, following the standard GitHub App permission model.

## Disconnect

Go to **Settings -> Integrations** and click **Disconnect**. You can also uninstall the app from GitHub under **Settings -> Applications**.

## Troubleshooting

| Symptom | Fix |
|---|---|
| Callback fails after install | Click **Connect** again — the install URL refreshes each time |
| Wrong repos listed | Update selection in GitHub under **Settings -> Applications -> Staso -> Configure** |
| Diagnosis says "no source" | Verify the trace has [version tracking](/docs/guides/vcs-tracking) metadata and the repo is connected |
| Diagnosis used wrong version | Staso falls back to the latest pushed commit when local changes are uncommitted |
