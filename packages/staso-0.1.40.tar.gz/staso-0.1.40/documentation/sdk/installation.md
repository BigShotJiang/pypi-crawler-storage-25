---
title: Installation
description: Install the Staso Python SDK for AI agent tracing and LLM observability. Core install, optional Anthropic and OpenAI extras.
---

# Installation

Install the Staso Python SDK and pick the extras that match the LLM providers you use.

```bash
pip install staso
```

## Requirements

- Python **3.11** or newer.
- A Staso API key. See [Create an API key](/docs/getting-started/create-api-key).

## Install options

| Install | Use case |
|---|---|
| `pip install staso` | Core SDK only. Decorators, spans, conversations, annotations. |
| `pip install "staso[anthropic]"` | Auto-instrument the Anthropic SDK. |
| `pip install "staso[openai]"` | Auto-instrument the OpenAI SDK. |
| `pip install "staso[all]"` | Both Anthropic and OpenAI auto-instrumentation. |

The extras pull in the matching provider SDK and wire up agent instrumentation automatically at import time. No extra calls required.

## Verify

```bash
python -c "import staso; print(staso.__version__)"
```

## Next

- [Initialize the SDK](/docs/sdk/initialization)
- [Anthropic integration](/docs/integrations/anthropic)
- [OpenAI integration](/docs/integrations/openai)
