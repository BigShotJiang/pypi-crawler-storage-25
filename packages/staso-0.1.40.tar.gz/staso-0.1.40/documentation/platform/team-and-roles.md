---
title: Team and Roles
description: Invite teammates, assign default or custom roles, and control who can manage keys, workspaces, guards, and datasets.
---

Invite teammates to your org, assign roles, and customize permissions.

## Inviting users

1. Dashboard → Settings → Members → **Invite**.
2. Enter the email and pick a role.
3. The invitee gets an email with a signup link. They join the org on accept.

Invites are idempotent — sending twice to the same email just refreshes the link.

## Default roles

| Role | What they can do |
|---|---|
| `owner` | Every permission, including `delete_org` and `create_custom_role`. |
| `admin` | Every permission except `create_custom_role`. Manage members, workspaces, API keys, guards, and datasets. |
| `member` | `view_guard` only. Add more by assigning a custom role. |

## Custom roles

A custom role is a named bundle of permissions. Use them when the three defaults don't map to your team — for example, a "security" role that can manage guards but not members.

| Plan | Custom roles per org |
|---|---|
| `no_plan` | 0 |
| `personal` | 2 |
| `team` | 10 |
| `enterprise` | unlimited |

## Permission list

Every permission the backend ships. A custom role is any subset.

| Permission | Lets the user |
|---|---|
| `edit_org_settings` | Change org name, branding, and integration settings. |
| `create_api_keys` | Create, rotate, and deactivate API keys. |
| `invite_users` | Send and revoke invites. |
| `change_user_role` | Promote, demote, or reassign members. |
| `create_workspace` | Create new workspaces in the org. |
| `delete_workspace` | Delete a workspace and its data. |
| `remove_user` | Remove a member from the org entirely. |
| `remove_workspace_member` | Remove a member from a single workspace. |
| `create_custom_role` | Define a new role with a custom permission set. |
| `add_workspace_member` | Add an org member to a workspace. |
| `delete_org` | Delete the organization. Owner-level. |
| `manage_guard_rules` | Create and edit Guard rules. |
| `manage_guard_policies` | Create and edit Guard policies. |
| `view_guard` | Read Guard dashboards and results. |
| `manage_datasets` | Create, edit, and delete datasets. |
| `view_datasets` | Read datasets and their entries. |

## Workspace membership vs org membership

You can be in an org without being attached to any particular workspace. Admins add you to workspaces explicitly via `add_workspace_member`. This keeps blast radius small — a contractor can be in the org for billing or audit purposes without seeing every customer's traces.

## Next

- [Organizations & Workspaces](/docs/platform/organizations-and-workspaces)
- [Guard rules and policies](/docs/guard/rules-and-policies)
- [Datasets overview](/docs/datasets/overview)
