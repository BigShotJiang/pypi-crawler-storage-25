---
title: Organizations & Workspaces
description: The two-level tenant model — an organization owns billing, RBAC, and API keys; workspaces own the data.
---

Your data lives in a workspace. Your billing, team, and RBAC live in the organization that owns that workspace.

```
Organization  (billing, RBAC, plan)
└─ Workspace  (isolated data scope)
   └─ Traces + Spans
```

## Organizations

The top-level container. An organization holds the subscription plan, members, roles, API keys, and integrations.

One is created automatically on signup. You can create more from the dashboard under Settings → Organizations.

New organizations start on `no_plan`, which blocks ingest until you upgrade. Pricing is on the [pricing page](/docs/pricing).

## Workspaces

Workspaces are isolated data scopes inside an org. Use them to separate:

- Environments — `prod` vs `staging` vs `dev`.
- Teams — `web`, `backend`, `mobile`.
- Customers — one workspace per tenant in a multi-tenant SaaS.

Each workspace has a `slug`. The SDK targets it two equivalent ways:

```python
import staso as st

st.init(api_key="ak_...", workspace_slug="prod")
```

```bash
export STASO_WORKSPACE_SLUG=prod
```

If you don't specify one, the SDK uses the workspace named `default`.

## Plan limits

| Plan | Members | Workspaces | API keys | Custom roles |
|---|---|---|---|---|
| `no_plan` | 1 | 1 | 0 | 0 |
| `personal` | 3 | 3 | 6 | 2 |
| `team` | 10 | 20 | 30 | 10 |
| `enterprise` | unlimited | unlimited | unlimited | unlimited |

Plans also cap monthly ingestion, retention, and guard/AI runs. See the [pricing page](/docs/pricing) for the full matrix.

## When to add a new workspace

- You want to keep staging traffic out of prod dashboards.
- Two teams should not see each other's traces.
- You run a multi-tenant product and want per-customer scoping.

Workspaces are free to create (up to the plan cap). Err on the side of more.

## Next

- [API Keys](/docs/platform/api-keys)
- [Team and Roles](/docs/platform/team-and-roles)
- [Pricing](/docs/pricing)
