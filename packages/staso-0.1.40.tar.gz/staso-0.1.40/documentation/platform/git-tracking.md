---
title: Git Tracking
description: Tie every trace to the commit that produced it so you can compare behavior across versions and diagnose regressions.
---

Every trace carries its git commit, branch, and dirty state so you can compare behavior across versions.

## How it works

`st.init(capture_git=True)` is the default. The SDK detects the commit context once at init and tags every trace.

Detection order:

1. `STASO_VCS_*` environment variables (explicit override).
2. CI/CD provider env vars (GitHub Actions, Vercel, Railway, etc.).
3. Local `.git/` directory via `git` CLI.
4. `.staso-build-info` JSON file next to your app.

Each trace gets these metadata fields:

| Field | Example |
|---|---|
| `vcs.commit.sha` | `3f2a1b9...` (40-char SHA) |
| `vcs.branch` | `main` |
| `vcs.repo_url` | `https://github.com/acme/agent` |
| `vcs.is_dirty` | `true` when uncommitted changes exist locally |

The dashboard filters, groups, and diffs by any of these.

## CI/CD auto-detection

Supported out of the box:

- GitHub Actions
- Vercel
- Railway
- Heroku
- GitLab CI
- CircleCI
- Bitbucket Pipelines
- AWS CodeBuild
- Netlify
- Azure DevOps

If your platform ships standard commit env vars under a different name, use the manual override below.

## Manual override

For containers that don't ship `.git/` but know their commit — the cleanest path in Docker, Kubernetes, and serverless:

```bash
export STASO_VCS_COMMIT_SHA=$GIT_COMMIT
export STASO_VCS_BRANCH=$GIT_BRANCH
export STASO_VCS_REPO_URL=https://github.com/acme/agent
```

These take precedence over everything else.

## Disable

Pass `capture_git=False` if you don't want git metadata on traces:

```python
st.init(api_key="ak_...", capture_git=False)
```

## Why it matters

- **Regression detection** — latency or error rate spikes pinned to a commit.
- **Rollback decisions** — see what the previous green commit actually did.
- **Fix verification** — confirm the bad behavior is gone on the new SHA.
- **Heal diagnosis context** — the auto-diagnoser uses commit and diff to reason about what changed.

## Next

- [SDK configuration](/docs/sdk/configuration)
- [SDK initialization](/docs/sdk/initialization)
- [Heal overview](/docs/heal/overview)
- [Environment variables reference](/docs/reference/environment-variables)
