---
title: API Keys
description: Create, scope, and rotate the keys the SDK uses to authenticate with the Staso ingest API.
---

API keys authenticate the SDK to the Staso ingest API. Keys are either org-wide or scoped to specific workspaces.

## Creating a key

1. Dashboard → Settings → API Keys → **New Key**.
2. Give it a name. Optionally set an expiry.
3. Pick a scope (see below).
4. Copy the raw key immediately — it is shown once and stored as a hash on the backend.

The dashboard keeps a `key_prefix` (the first 12 characters) so you can identify a key later without revealing the secret.

## Scopes

| Scope | What it can do | When to use |
|---|---|---|
| `full_org` | Ingest into any workspace in the org | Default — single-team orgs |
| `workspace_scoped` | Ingest only into the workspaces you list | Multi-tenant, per-env, or per-team keys |

Pick `workspace_scoped` whenever a key ships to an environment that should not be able to write to other workspaces — for example, a prod deploy key that must never touch staging.

## Using the key

Two equivalent options:

```python
import staso as st

st.init(api_key="ak_live_...", workspace_slug="prod")
```

```bash
export STASO_API_KEY=ak_live_...
export STASO_WORKSPACE_SLUG=prod
```

If `workspace_slug` is not set on `init()` and not in the trace payload, the backend falls back to the key's default workspace.

## Rotation

1. Create a new key with the same scope.
2. Deploy it alongside the old one (env var swap).
3. Watch the dashboard — new ingests should show up under the new `key_prefix`.
4. Deactivate the old key.

This avoids downtime and gives you a clean cutover point to verify in the UI.

## Plan limits

| Plan | API keys per org |
|---|---|
| `no_plan` | 0 |
| `personal` | 6 |
| `team` | 30 |
| `enterprise` | unlimited |

`no_plan` blocks key creation entirely — upgrade before integrating.

## Next

- [SDK initialization](/docs/sdk/initialization)
- [Organizations & Workspaces](/docs/platform/organizations-and-workspaces)
