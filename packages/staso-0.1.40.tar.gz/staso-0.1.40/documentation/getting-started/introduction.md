---
title: What is Staso?
description: Staso is an AI agent observability, guardrails, and self-healing platform for Python teams shipping LLM agents to production.
---

# What is Staso?

Staso is a Python SDK and platform for AI agent observability, guardrails, and automated failure diagnosis — built for teams running Anthropic, OpenAI, Claude Code, or Codex agents in production.

## What it does

**Observe.** Staso traces every agent run end-to-end: LLM calls, tool invocations, token usage, latency, errors, and intermediate state. One `patch_anthropic()` or `patch_openai()` call captures model requests, responses, and streaming output. Decorators like `@st.agent` and `@st.tool` add structured spans to your own code. See [LLM tracing](/docs/sdk/initialization) and [integrations](/docs/integrations/overview).

**Guard.** Staso Guard evaluates tool calls before they execute. Block destructive operations, modify unsafe arguments, or escalate to a human — enforced from a single rules surface. See [Guard overview](/docs/guard/overview).

**Heal.** Point Heal at any trace — a failure, a regression, a slow run, a bad eval result — and it diagnoses the root cause from the span tree and suggests a fix. For CLI agents (Claude Code, Codex) the fix can land as a PR. See [Heal overview](/docs/heal/overview).

## Who it's for

Python teams shipping AI agents to production. Staso plugs in without rewrites. The SDK is Python 3.11+ and supports sync, async, and streaming responses.

## How it fits together

1. Your agent runs — a Python process or CLI invocation.
2. The SDK traces it — spans flow to Staso in the background.
3. Guard checks tool calls in-flight — blocks, modifies, or allows.
4. When something looks off — a failure, a regression, a latency spike, a bad eval — Heal diagnoses the trace and proposes a fix.
5. You review and merge — or let the agent apply it for CLI targets.

Each piece is independent. Start with tracing, add guards when you need enforcement, turn on Heal when you want diagnosis automated.

## Next

Read the [Quickstart](/docs/getting-started/quickstart) to get a trace on your dashboard in under five minutes, then learn the [core concepts](/docs/getting-started/core-concepts).
