---
title: Quickstart
description: Install Staso, trace your first AI agent, and see it on the dashboard in under 5 minutes.
---

# Quickstart

Install the SDK, initialize it, auto-instrument your LLM client, and run your agent — you'll see the trace on the Staso dashboard.

```python
import staso as st
from staso.integrations import patch_anthropic
import anthropic

st.init(api_key="ak_...", agent_name="support-agent")
patch_anthropic()

client = anthropic.Anthropic()
resp = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=256,
    messages=[{"role": "user", "content": "Ping"}],
)
print(resp.content[0].text)

st.shutdown()
```

Python 3.11+ required.

## 1. Install

Pick the extra that matches your LLM provider:

```bash
pip install "staso[anthropic]"   # Anthropic auto-instrumentation
pip install "staso[openai]"      # OpenAI auto-instrumentation
pip install "staso[all]"         # both
```

## 2. Get an API key

You need a Staso API key before `init()` will work. If you don't have one yet, follow [Create an API key](/docs/getting-started/create-api-key). Set it as an environment variable:

```bash
export STASO_API_KEY=ak_...
```

## 3. Initialize

Call `st.init()` once at process start. `api_key` and `agent_name` are required — pass them directly or rely on `STASO_API_KEY` and `STASO_AGENT_NAME` environment variables.

```python
import staso as st

st.init(
    api_key="ak_...",            # or STASO_API_KEY
    agent_name="support-agent",  # or STASO_AGENT_NAME
    environment="prod",          # optional, default "default"
)
```

Common keyword arguments (see [initialization reference](/docs/sdk/initialization)):

| Argument         | Default                          | Purpose                             |
| ---------------- | -------------------------------- | ----------------------------------- |
| `api_key`        | `STASO_API_KEY`                  | Auth token, required.               |
| `agent_name`     | `STASO_AGENT_NAME`               | Logical agent identifier, required. |
| `environment`    | `STASO_ENVIRONMENT` / `default`  | Logical partition (prod, staging).  |
| `workspace_slug` | `STASO_WORKSPACE_SLUG` / `default` | Target workspace.                 |
| `base_url`       | `https://api.staso.ai`           | Override for self-hosted.           |
| `debug`          | `STASO_DEBUG`                    | Verbose SDK logs.                   |

## 4. Auto-instrument your LLM

Call the patch once at startup — the SDK patches the provider class itself, so existing and future clients are all instrumented. Every LLM call becomes an `LLM` span with model, messages, tokens, and latency. Sync, async, and streaming are all captured. Patches are idempotent.

```python
from staso.integrations import patch_anthropic, patch_openai

patch_anthropic()  # if you use Anthropic
patch_openai()     # if you use OpenAI
```

See [integrations overview](/docs/integrations/overview) for the full list.

## 5. Run your agent

Drop this into a file, set `STASO_API_KEY` and `ANTHROPIC_API_KEY`, and run it.

```python
import staso as st
from staso.integrations import patch_anthropic
import anthropic

st.init(api_key="ak_...", agent_name="support-agent")
patch_anthropic()

client = anthropic.Anthropic()

resp = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=256,
    messages=[{"role": "user", "content": "Hello, Staso."}],
)
print(resp.content[0].text)

st.shutdown()
```

Open the Staso dashboard — you'll see a trace named `support-agent` with an `LLM` child span containing the model, token usage, and latency.

## 6. Add a tool span

Wrap any helper function with `@st.tool` to capture it as a `TOOL` span inside the trace. Inputs and return values are recorded automatically.

```python
@st.tool
def search_faq(query: str) -> str:
    return db.search(query)
```

`@st.agent` and `@st.trace` work the same way for agent entry points and generic spans. See the [decorators reference](/docs/sdk/decorators).

## Next

- [Decorators reference](/docs/sdk/decorators) — `@agent`, `@tool`, `@trace`.
- [Integrations](/docs/integrations/overview) — Anthropic, OpenAI, Claude Code, Codex.
- [Guard overview](/docs/guard/overview) — block or modify tool calls before they run.
