---
title: Create an API Key
description: Sign up, create your first Staso API key, and store it as STASO_API_KEY for the Python SDK.
---

# Create an API Key

Create a Staso API key from the dashboard and export it as `STASO_API_KEY` so the Python SDK can authenticate.

```bash
export STASO_API_KEY=ak_...
```

## Steps

1. **Sign up.** Go to [staso.ai](https://staso.ai) and sign in with Google or GitHub OAuth.
2. **Your first organization is created automatically.** A default workspace is created inside it — you can rename both later.
3. **Open Settings → API Keys** in the dashboard.
4. **Create a key.** Give it a name (e.g. `prod-backend`) and choose a scope (see below). Only workspace members with the `create_api_keys` permission can issue keys.
5. **Copy the raw key.** The raw value is shown exactly once. Store it as `STASO_API_KEY` in your environment, secret manager, or `.env` file. After that the dashboard only shows the key prefix.

## Scope choices

API keys are scoped at creation time and the scope cannot be changed later. Pick based on what the key needs to write to.

| Scope              | What it can do                                              | Use when                                              |
| ------------------ | ----------------------------------------------------------- | ----------------------------------------------------- |
| `full_org`         | Writes to any workspace in the organization.                | One key per service that spans multiple workspaces.   |
| `workspace_scoped` | Writes only to the workspaces you select at creation time.  | Isolating environments, teams, or customers.          |

Default to `workspace_scoped` unless you have a concrete reason to span the org. See [organizations and workspaces](/docs/platform/organizations-and-workspaces) for the data model.

## Rotating keys

You can deactivate a key at any time from Settings → API Keys. Deactivated keys stop accepting ingest immediately. Create a new key, roll it out, then deactivate the old one — there's no rotation downtime.

## Plan note

A new organization starts on `no_plan`. Ingest is blocked until you upgrade. Upgrade from the billing page before running a production agent — see [pricing](/docs/pricing) and the [API keys platform guide](/docs/platform/api-keys) for details.

## Next

Head to the [Quickstart](/docs/getting-started/quickstart) to initialize the SDK with your new key.
