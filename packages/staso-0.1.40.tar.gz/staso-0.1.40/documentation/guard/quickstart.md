---
title: Guard Quickstart
description: Turn Guard on by patching your LLM SDK — tool calls are evaluated automatically, blocked calls raise GuardBlocked, modified calls are rewritten in place.
---

# Guard Quickstart

Turn on Guard by patching your LLM SDK — tool calls are evaluated automatically.

```python
import staso as st
from staso.integrations import patch_anthropic

st.init(api_key="...", agent_name="refunds-agent")
patch_anthropic()  # Guard evaluates tool_use blocks automatically
```

That's it. Every `tool_use` block from the Anthropic response is evaluated against your rules and policies before your tool-dispatch loop runs.

For OpenAI, swap in `patch_openai()`.

## Environment

Guard is on by default inside the integrations. Disable it per-process with:

```bash
export STASO_GUARD_ENABLED=false
```

Only the literal string `false` (case-insensitive) disables Guard — any other value, including `0`, leaves it on.

## What happens

1. The integration intercepts the model response and extracts each tool call.
2. Guard evaluates each call against your rules.
3. The chosen action is applied:
   - `allow` — tool call proceeds.
   - `modify` — the tool-call arguments are rewritten in place.
   - `block` / `escalate` — `staso.GuardBlocked` is raised.
4. A child `guard:*` span is added to the active trace so decisions are visible on the dashboard.

## Handling blocked tools

```python
import staso as st
from staso.integrations import patch_anthropic
import anthropic

st.init(api_key="...", agent_name="refunds-agent")
patch_anthropic()

client = anthropic.Anthropic()

try:
    resp = client.messages.create(
        model="claude-sonnet-4-5",
        max_tokens=1024,
        tools=[...],
        messages=[...],
    )
except st.GuardBlocked as e:
    print(f"blocked: {e.reason}")
    # fall back, re-prompt, or surface to the user
```

See [Error Handling](/docs/guard/error-handling) for the full exception shape.

## Opting out per call

There is no per-call opt-out — Guard runs on every tool call inside a patched client. To skip it, set `STASO_GUARD_ENABLED=false` before `patch_*` runs, or simply don't call the patcher.

## Next

- [Anthropic integration](/docs/integrations/anthropic)
- [OpenAI integration](/docs/integrations/openai)
- [Manual Guard Checks](/docs/guard/manual-checks) — for non-patched code paths.
- [Error Handling](/docs/guard/error-handling)
