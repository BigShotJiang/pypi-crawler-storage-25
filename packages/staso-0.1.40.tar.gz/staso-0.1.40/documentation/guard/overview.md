---
title: Guard Overview
description: Evaluate every tool call your AI agent is about to make — block dangerous actions, rewrite bad inputs, or escalate to a human before code runs.
---

# Guard Overview

Guard evaluates every tool call your agent is about to make — block dangerous actions, modify bad inputs, or escalate to a human.

```python
import staso as st
from staso.integrations import patch_anthropic

st.init(api_key="...", agent_name="refunds-agent")
patch_anthropic()  # Guard evaluates every tool_use block automatically
```

## Why Guard

One wrong tool call from an LLM is enough to refund the wrong customer, delete a production table, or email a million users. Prompt-level safety isn't enough — the damage happens at the tool boundary. Guard sits there.

## How it works

Guard intercepts each tool call and returns one of four actions:

- **allow** — the call proceeds unchanged.
- **block** — the call is denied; integrations raise `staso.GuardBlocked`.
- **modify** — Guard rewrites `tool_input` with safer arguments; use `result.modified_input`.
- **escalate** — a human must approve before the call runs.

Decisions are attached to the trace as child spans, so every guarded call is visible in the dashboard.

## What you get

- **Static rules** — proprietary deterministic checks (dangerous shell, destructive SQL, PII patterns). Fast and free of LLM calls.
- **LLM-judge rules** — model-based checks for intent, prompt injection, jailbreaks, hallucinated facts.
- **Custom rules** — your own rules defined in the dashboard.
- **Policies** — bundle rules together and attach them to specific agents or environments.

Quotas vary per plan — see [Rules and Policies](/docs/guard/rules-and-policies).

## Plan gating

Guard is not available on the `no_plan` tier. API requests from a `no_plan` org return **HTTP 403**. Upgrade to Personal or higher to enable Guard. See [pricing](/docs/pricing).

## Next

- [Guard Quickstart](/docs/guard/quickstart) — turn Guard on in under five minutes.
- [Manual Guard Checks](/docs/guard/manual-checks) — call `st.guard(...)` from non-patched code.
- [Rules and Policies](/docs/guard/rules-and-policies) — what ships in the box and what you can customise.
