---
title: Staso pricing and plan limits
description: Plan quotas for ingestion, retention, Guard evaluations, datasets, and Heal runs. Enforcement and billing rules.
---

# Staso pricing and plan limits

Staso has three paid tiers (Personal, Team, Enterprise) plus a blocked free tier. See [staso.ai/pricing](https://staso.ai/pricing) for current prices. The quotas below are enforced by the backend at runtime.

## Core quotas

| Limit | Free (no plan) | Personal | Team | Enterprise |
|---|---|---|---|---|
| Monthly trace ingestion | 0 | 10,000 | 100,000 | Unlimited |
| Data retention | 0 days | 7 days | 30 days | Unlimited |
| Members per org | 1 | 3 | 10 | Unlimited |
| Workspaces per org | 1 | 3 | 20 | Unlimited |
| API keys per org | 0 | 6 | 30 | Unlimited |
| Ingest rate (per minute) | 0 | 200 | 1,000 | Unlimited |
| Ingest rate (per hour) | 0 | 5,000 | 50,000 | Unlimited |

Free tier cannot send traces — every ingest returns `403`. Subscribe to unblock.

## Guard quotas

| Limit | Free | Personal | Team | Enterprise |
|---|---|---|---|---|
| Static rule evaluations / month | 0 | 10,000 | Unlimited | Unlimited |
| LLM judge evaluations / month | 0 | 300 | 5,000 | Unlimited |
| Custom rules per org | 0 | 5 | 30 | Unlimited |
| Policies per org | 0 | 5 | 30 | Unlimited |

Static rule evaluations run filesystem-backed checks. LLM judge evaluations call a model and count separately. See [Guard overview](/docs/guard/overview).

## Datasets and Heal quotas

| Limit | Free | Personal | Team | Enterprise |
|---|---|---|---|---|
| Datasets per org | 0 | 3 | 30 | Unlimited |
| Entries per dataset | 0 | 500 | 10,000 | Unlimited |
| Columns per dataset | 0 | 20 | 50 | Unlimited |
| Manual Heal runs / day | 0 | 15 | 50 | Unlimited |
| Manual Heal runs / month | 0 | 100 | 500 | Unlimited |
| Auto Heal runs / day | 0 | 50 | 200 | Unlimited |
| Auto Heal runs / month | 0 | 500 | 5,000 | Unlimited |
| Concurrent Heal runs | 0 | 2 | 5 | 20 |

A Heal run is one LLM-powered stage — diagnosis and fix count as separate runs. Auto runs are triggered by guard violations or the regression detector.

## Enforcement

- **No plan → 403.** Every ingest request from an org with `no_plan` is rejected with `403 Organization has no active plan`. Upgrade to resume tracing.
- **Rate limits → 429.** Exceeding the per-minute or per-hour ingest budget returns `429` with a `Retry-After` header. The SDK respects it automatically.
- **Monthly cap → 429.** Hitting the monthly trace limit also returns `429` with `Retry-After: 86400` until the new cycle begins.
- **Feature gates.** Guard, Heal, and dataset features return a `403` with a descriptive error when a call exceeds the plan's allotment.

## Billing

Billing cycles run on the calendar month in UTC. Quotas reset at the start of each month; overages are blocked, not billed. Upgrades take effect immediately; downgrades apply at the next cycle.

Dollar amounts, promotional pricing, and enterprise terms live at [staso.ai/pricing](https://staso.ai/pricing).

## See also

- [Organizations and workspaces](/docs/platform/organizations-and-workspaces)
- [Troubleshooting: rate limits and 403 errors](/docs/troubleshooting)
