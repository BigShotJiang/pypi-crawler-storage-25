---
title: Claude Code Integration
description: Capture every Claude Code session, tool use, and failure with one setup command.
---

# Claude Code Integration

Hooks into Claude Code's event system to capture every session, every tool use, every stop event — without modifying your Claude Code configuration by hand.

## Install

```bash
pip install staso
```

## Setup (interactive)

```bash
staso setup --target claude-code
```

The wizard prompts for API key, workspace, environment, agent name, scope, and Guard preference, then writes the hook configuration for you.

## Setup (scripted)

```bash
staso setup --target claude-code \
  --api-key $STASO_API_KEY \
  --agent-name my-claude-code \
  --scope global
```

## What it does

Writes hook configuration to one of:

- **Global scope:** `~/.claude/settings.json`
- **Project scope:** `./.claude/settings.local.json`

Each hook event runs a Python subprocess — `python -m staso.claude_code` — that ships the event to Staso.

## Hook events captured

`SessionStart`, `UserPromptSubmit`, `PreToolUse`, `PostToolUse`, `PostToolUseFailure`, `Stop`, `StopFailure`, `SubagentStart`, `SubagentStop`, `SessionEnd`.

## Flags

| Flag | Purpose |
|---|---|
| `--target` | Agent to configure — `claude-code` here. |
| `--api-key` | Staso API key (`ak_...`). Falls back to `STASO_API_KEY`. |
| `--base-url` | Override the Staso backend URL. |
| `--workspace` | Workspace slug (default: `default`). |
| `--environment` | Environment name (default: `default`). |
| `--agent-name` | Display name shown on the Staso dashboard. |
| `--scope` | `global` or `project`. |
| `--guard` / `--no-guard` | Toggle Guard evaluation. Enabled by default. |
| `--auto-sync` | Re-sync hook config on each session start. |

## Guard integration

Guard is enabled by default. On `PreToolUse`, Staso evaluates the tool call against your rules and can block or modify it before Claude Code executes. Disable with `--no-guard`. See [Guard Overview](/docs/guard/overview).

## Keep hooks in sync

After upgrading the SDK, refresh the hook wiring:

```bash
staso sync --target claude-code
```

Or pass `--auto-sync` during setup to do it on every session start.

## Uninstall

```bash
staso uninstall --target claude-code
```

Removes Staso hook entries, removes Staso env vars, and cleans up state files under `~/.staso/claude-code/`.

## Next

- [CLI Reference](/docs/cli)
- [Codex Integration](/docs/integrations/codex)
- [Guard Overview](/docs/guard/overview)
