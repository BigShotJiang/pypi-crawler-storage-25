---
title: Anthropic Integration
description: Auto-trace every Anthropic Python SDK call — tokens, tool use, cache, extended thinking, errors.
---

# Anthropic Integration

Auto-traces every call made through the Anthropic Python SDK — token counts, tool use, cache, extended thinking, errors.

## Install

```bash
pip install "staso[anthropic]"
```

## Enable

```python
import staso as st
from staso.integrations import patch_anthropic
from anthropic import Anthropic

st.init(api_key="...", agent_name="my-agent")
patch_anthropic()

client = Anthropic()
msg = client.messages.create(
    model="claude-sonnet-4",
    max_tokens=1024,
    messages=[{"role": "user", "content": "hi"}],
)
```

Call `patch_anthropic()` once, after `st.init()`. It is idempotent — calling it again is a no-op — and patches both the sync `Messages.create` and async `AsyncMessages.create` code paths.

## What it captures

Each `messages.create` call produces a single LLM span with:

- **Input:** model, system prompt, tool definitions, messages (when `capture_messages=True`).
- **Output:** full content blocks — `text`, `tool_use`, `thinking`.
- **Tokens:** input, output, cache read, cache creation.
- **Request params:** `temperature`, `max_tokens`, `top_p`, `top_k`, `stop_sequences`, `tool_choice`, `thinking`.
- **Response metadata:** `stop_reason`, `response_id`, `has_thinking` flag.

## Streaming

`messages.create(stream=True)` and `messages.stream(...)` are both wrapped. The span stays open until the stream finishes, then captures the aggregated content, token counts, and any tool use blocks.

## Guard pass-through

Every `tool_use` block in the response is handed to [Guard](/docs/guard/overview) for evaluation. If an enforce-mode rule blocks a tool, the patched `create()` raises `staso.GuardBlocked` before returning — your agent loop never dispatches a blocked tool. Modify-mode rules rewrite `ToolUseBlock.input` in place. See [error handling](/docs/guard/error-handling) for the full flow.

## Next

- [OpenAI Integration](/docs/integrations/openai)
- [Guard Overview](/docs/guard/overview)
- [SDK Initialization](/docs/sdk/initialization)
