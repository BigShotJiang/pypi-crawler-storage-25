---
title: OpenAI Integration
description: Auto-trace every OpenAI Python SDK call — tokens, tool calls, reasoning, response metadata.
---

# OpenAI Integration

Auto-traces every call made through the OpenAI Python SDK — tokens, tool calls, reasoning, response metadata.

## Install

```bash
pip install "staso[openai]"
```

## Enable

```python
import staso as st
from staso.integrations import patch_openai
from openai import OpenAI

st.init(api_key="...", agent_name="my-agent")
patch_openai()

client = OpenAI()
resp = client.chat.completions.create(
    model="gpt-5.4",
    messages=[{"role": "user", "content": "hi"}],
)
```

Call `patch_openai()` once, after `st.init()`. It is idempotent and patches both the sync `Completions.create` and async `AsyncCompletions.create` code paths.

## What it captures

Each `chat.completions.create` call produces a single LLM span with:

- **Input:** model, tool definitions, messages (when `capture_messages=True`).
- **Output:** assistant `content`, `role`, `tool_calls`.
- **Tokens:** prompt, completion, total, reasoning (for o-series models).
- **Request params:** `temperature`, `max_tokens` / `max_completion_tokens`, `top_p`, `frequency_penalty`, `presence_penalty`, `seed`, `stop`, `tool_choice`, `response_format`, `service_tier`.
- **Response metadata:** `finish_reason`, `response_id`.

## Streaming

`chat.completions.create(stream=True)` is wrapped. The span stays open across the stream and finalizes with aggregated content, tool calls, and token usage.

## Guard pass-through

Every `tool_call` in the response is handed to [Guard](/docs/guard/overview) for evaluation. If an enforce-mode rule blocks a tool, the patched `create()` raises `staso.GuardBlocked` before returning — your agent loop never dispatches a blocked tool. Modify-mode rules rewrite the tool call's `function.arguments` in place.

## Next

- [Anthropic Integration](/docs/integrations/anthropic)
- [Guard Overview](/docs/guard/overview)
- [SDK Initialization](/docs/sdk/initialization)
