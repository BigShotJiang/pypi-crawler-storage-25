---
title: Integrations
description: Auto-instrument Anthropic, OpenAI, Claude Code, and Codex with one function call or one CLI command.
---

# Integrations

Staso ships four first-party integrations. Each one captures traces without touching your application code.

| Integration | Install | Enable | What it captures |
|---|---|---|---|
| [Anthropic](/docs/integrations/anthropic) | `pip install "staso[anthropic]"` | `patch_anthropic()` | every call through the Anthropic SDK |
| [OpenAI](/docs/integrations/openai) | `pip install "staso[openai]"` | `patch_openai()` | every call through the OpenAI SDK |
| [Claude Code](/docs/integrations/claude-code) | `pip install staso` | `staso setup --target claude-code` | every session + tool use + stop event |
| [Codex](/docs/integrations/codex) | `pip install staso` | `staso setup --target codex` | every session + tool use + stop event |

Auto-instrumentation means you never decorate call sites, never forward spans, never rebuild traces after a refactor. The integration owns capture end-to-end so every request — sync, async, streaming — ends up on the same timeline.

## Next

- [Anthropic](/docs/integrations/anthropic) — patch the Anthropic Python SDK.
- [OpenAI](/docs/integrations/openai) — patch the OpenAI Python SDK.
- [Claude Code](/docs/integrations/claude-code) — hook every Claude Code session.
- [Codex](/docs/integrations/codex) — hook every Codex session.
