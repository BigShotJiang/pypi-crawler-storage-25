---
title: Codex Integration
description: Capture every Codex session, tool use, and stop event with one setup command.
---

# Codex Integration

Hooks into Codex's event system to capture every session, every tool use, every stop — and enables Codex's `codex_hooks` feature flag for you.

## Install

```bash
pip install staso
```

## Setup (interactive)

```bash
staso setup --target codex
```

The wizard prompts for API key, workspace, environment, agent name, scope, and Guard preference, then writes the hook configuration.

## Setup (scripted)

```bash
staso setup --target codex \
  --api-key $STASO_API_KEY \
  --agent-name my-codex \
  --scope global
```

## What it does

Writes hook configuration to one of:

- **Global scope:** `~/.codex/hooks.json`
- **Project scope:** `./.codex/hooks.json`

And sets `features.codex_hooks = true` in `~/.codex/config.toml` (or `./.codex/config.toml` for project scope) so Codex actually runs the hooks. Each event runs `python -m staso.codex` with the Staso env vars embedded in the command string.

## Hook events captured

`SessionStart`, `UserPromptSubmit`, `PreToolUse`, `PostToolUse`, `Stop`.

## Flags

| Flag | Purpose |
|---|---|
| `--target` | Agent to configure — `codex` here. |
| `--api-key` | Staso API key (`ak_...`). Falls back to `STASO_API_KEY`. |
| `--base-url` | Override the Staso backend URL. |
| `--workspace` | Workspace slug (default: `default`). |
| `--environment` | Environment name (default: `default`). |
| `--agent-name` | Display name shown on the Staso dashboard. |
| `--scope` | `global` or `project`. |
| `--guard` / `--no-guard` | Toggle Guard evaluation. Enabled by default. |
| `--auto-sync` | Re-sync hook config on each session start. |

## Guard integration

Guard is enabled by default. On `PreToolUse`, Staso evaluates the tool call against your rules and can block or modify it before Codex executes. Disable with `--no-guard`. See [Guard Overview](/docs/guard/overview).

## Keep hooks in sync

After upgrading the SDK:

```bash
staso sync --target codex
```

Or pass `--auto-sync` during setup to do it on every session start.

## Uninstall

```bash
staso uninstall --target codex
```

Removes Staso hook entries, clears the `codex_hooks` feature flag, and cleans up state files under `~/.staso/codex/`.

## Next

- [CLI Reference](/docs/cli)
- [Claude Code Integration](/docs/integrations/claude-code)
- [Guard Overview](/docs/guard/overview)
