"""Interactive CLI setup wizard using questionary.

When the user runs ``staso setup`` without flags, this module presents
a beautiful arrow-key-driven experience for selecting the target agent
and entering configuration values.
"""
from __future__ import annotations

import os
import sys
from typing import Any

import questionary
from questionary import Style

# -- theme ---------------------------------------------------------------------

STASO_STYLE = Style([
    ("qmark", "fg:ansicyan bold"),
    ("question", "bold"),
    ("answer", "fg:ansicyan bold"),
    ("pointer", "fg:ansicyan bold"),
    ("highlighted", "fg:ansicyan bold"),
    ("selected", "fg:ansicyan"),
    ("separator", "fg:ansibrightblack"),
    ("instruction", "fg:ansibrightblack"),
    ("text", ""),
    ("disabled", "fg:ansibrightblack italic"),
])


# -- agent registry for interactive display ------------------------------------

# Each entry: (display_name, cli_name, description, available)
# This is the single place to add new integrations — the wizard auto-discovers.
AGENT_CHOICES: list[dict[str, Any]] = [
    {
        "name": "Claude Code  —  Anthropic's CLI coding agent",
        "value": "claude-code",
    },
    {
        "name": "Codex        —  OpenAI's CLI coding agent",
        "value": "codex",
    },
]


# -- validators ----------------------------------------------------------------


def _validate_api_key(text: str) -> bool | str:
    text = text.strip()
    if not text:
        return "API key is required. Get yours at https://staso.ai"
    if not text.startswith("ak_"):
        return "API key must start with 'ak_'"
    if len(text) < 10:
        return "API key is too short"
    return True


def _validate_optional(_text: str) -> bool:
    return True


# -- wizard --------------------------------------------------------------------


def interactive_setup() -> dict[str, str] | None:
    """Run the interactive setup wizard.

    Returns a dict with keys: target, api_key, workspace, environment,
    agent_name, scope, auto_sync.  Returns None if the user cancels (Ctrl-C).
    """
    print()
    print("  \033[1m\033[96mStaso\033[0m — setup wizard")
    print("  \033[90mConfigure tracing for your CLI AI agent.\033[0m")
    print("  \033[90mPress Enter at any prompt to accept the default shown in [brackets].\033[0m")
    print()

    # 1. Select agent
    target = questionary.select(
        "Which agent do you want to trace?",
        choices=AGENT_CHOICES,
        style=STASO_STYLE,
        qmark="→",
        instruction="(↑/↓ to move, Enter to select — default: Claude Code)",
    ).ask()

    if target is None:
        return None

    # 2. API key (required)
    env_key = os.environ.get("STASO_API_KEY", "")
    print()
    print("  \033[90mCreate an API key in the Staso dashboard:\033[0m")
    print("  \033[90mSettings → API Keys (https://staso.ai/settings/api-keys)\033[0m")
    print("  \033[90mThe raw key is shown only once on creation — copy it before closing.\033[0m")
    api_key_instruction = (
        "(Enter to use STASO_API_KEY from env)"
        if env_key
        else "(required — paste your ak_... key, then Enter)"
    )
    api_key = questionary.text(
        "Staso API key",
        default=env_key,
        validate=_validate_api_key,
        style=STASO_STYLE,
        qmark="→",
        instruction=api_key_instruction,
    ).ask()

    if api_key is None:
        return None

    # 3. Workspace
    print()
    print("  \033[90mFind your workspace slug in the Staso dashboard:\033[0m")
    print("  \033[90mSettings → Workspace Info (https://staso.ai/settings/workspace-info)\033[0m")
    print("  \033[90mLeave as 'default' if you haven't created a workspace yet.\033[0m")
    workspace = questionary.text(
        "Workspace slug",
        default="default",
        validate=_validate_optional,
        style=STASO_STYLE,
        qmark="→",
        instruction="(Enter to keep [default])",
    ).ask()

    if workspace is None:
        return None

    # 4. Environment
    print()
    print("  \033[90mEnvironment is a free-form label for splitting traces (e.g. prod, staging, dev).\033[0m")
    print("  \033[90mIt does not need to pre-exist — traces are grouped by this value in the dashboard.\033[0m")
    environment = questionary.text(
        "Environment",
        default="default",
        validate=_validate_optional,
        style=STASO_STYLE,
        qmark="→",
        instruction="(Enter to keep [default], or type prod / staging / dev)",
    ).ask()

    if environment is None:
        return None

    # 5. Agent Name (optional)
    default_agent_name = target  # use agent name as default
    agent_name = questionary.text(
        "Agent Name",
        default=default_agent_name,
        validate=_validate_optional,
        style=STASO_STYLE,
        qmark="→",
        instruction=f"(Enter to keep [{default_agent_name}] — shown on dashboard)",
    ).ask()

    if agent_name is None:
        return None

    # 6. Scope
    scope = questionary.select(
        "Scope",
        choices=[
            {"name": "Global   —  trace all sessions on this machine", "value": "global"},
            {"name": "Project  —  trace only in the current directory", "value": "project"},
        ],
        style=STASO_STYLE,
        qmark="→",
        instruction="(↑/↓ to move, Enter to select — default: Global)",
    ).ask()

    if scope is None:
        return None

    # 7. Guard
    guard_enabled = questionary.confirm(
        "Enable Guard?",
        default=True,
        style=STASO_STYLE,
        qmark="→",
        instruction="[Y/n] evaluate tool calls against safety rules (Enter = Yes)",
    ).ask()

    if guard_enabled is None:
        return None

    # 8. Auto-sync
    auto_sync = questionary.confirm(
        "Enable auto-sync?",
        default=True,
        style=STASO_STYLE,
        qmark="→",
        instruction="[Y/n] auto-update hooks on each session start (Enter = Yes)",
    ).ask()

    if auto_sync is None:
        return None

    return {
        "target": target,
        "api_key": api_key.strip(),
        "workspace": workspace.strip(),
        "environment": environment.strip(),
        "agent_name": agent_name.strip(),
        "scope": scope,
        "guard_enabled": guard_enabled,
        "auto_sync": auto_sync,
    }
