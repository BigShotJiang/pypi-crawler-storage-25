from staso._version import __version__

SDK_NAME = "staso-python"
SDK_NAME_DATASETS = "staso-python-sdk"
USER_AGENT = f"{SDK_NAME}/{__version__}"
USER_AGENT_DATASETS = f"{SDK_NAME_DATASETS}/{__version__}"
