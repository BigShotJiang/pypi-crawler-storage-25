"""Git context detection for version-aware tracing."""
from __future__ import annotations

import json
import os
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class GitContext:
    commit_sha: str
    branch: str
    repo_url: str
    is_dirty: bool


# (sha_var, branch_var, repo_var, guard_var)
_PLATFORMS: list[tuple[str, str | None, str | None, str]] = [
    ("GITHUB_SHA", "GITHUB_REF_NAME", "GITHUB_REPOSITORY", "GITHUB_ACTIONS"),
    ("VERCEL_GIT_COMMIT_SHA", "VERCEL_GIT_COMMIT_REF", "VERCEL_GIT_REPO_SLUG", "VERCEL"),
    ("RAILWAY_GIT_COMMIT_SHA", "RAILWAY_GIT_BRANCH", None, "RAILWAY_ENVIRONMENT"),
    ("HEROKU_SLUG_COMMIT", None, None, "HEROKU_SLUG_COMMIT"),
    ("CI_COMMIT_SHA", "CI_COMMIT_BRANCH", "CI_PROJECT_URL", "GITLAB_CI"),
    ("CIRCLE_SHA1", "CIRCLE_BRANCH", "CIRCLE_REPOSITORY_URL", "CIRCLECI"),
    ("BITBUCKET_COMMIT", "BITBUCKET_BRANCH", "BITBUCKET_GIT_HTTP_ORIGIN", "BITBUCKET_COMMIT"),
    ("CODEBUILD_RESOLVED_SOURCE_VERSION", None, "CODEBUILD_SOURCE_REPO_URL", "CODEBUILD_BUILD_ID"),
    ("COMMIT_REF", "BRANCH", "REPOSITORY_URL", "NETLIFY"),
    ("BUILD_SOURCEVERSION", "BUILD_SOURCEBRANCH", "BUILD_REPOSITORY_URI", "TF_BUILD"),
]


def _strip_credentials(url: str) -> str:
    return re.sub(r"(https?://)[^/@]+@", r"\1", url)


def _from_staso_env_vars() -> GitContext | None:
    sha = os.environ.get("STASO_VCS_COMMIT_SHA", "")
    if not sha:
        return None
    return GitContext(
        commit_sha=sha,
        branch=os.environ.get("STASO_VCS_BRANCH", ""),
        repo_url=os.environ.get("STASO_VCS_REPO_URL", ""),
        is_dirty=False,
    )


def _from_platform_env_vars() -> GitContext | None:
    for sha_var, branch_var, repo_var, guard_var in _PLATFORMS:
        if not os.environ.get(guard_var):
            continue
        sha = os.environ.get(sha_var, "")
        if not sha:
            continue
        branch = os.environ.get(branch_var, "") if branch_var else ""
        raw_repo = os.environ.get(repo_var, "") if repo_var else ""
        repo_url = _strip_credentials(raw_repo) if raw_repo else ""
        return GitContext(
            commit_sha=sha,
            branch=branch,
            repo_url=repo_url,
            is_dirty=False,
        )
    return None


def _run(cmd: list[str], cwd: str | None) -> str | None:
    try:
        result = subprocess.run(
            cmd,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
        return None
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None


def _from_git_cli(cwd: str | None) -> GitContext | None:
    sha = _run(["git", "rev-parse", "HEAD"], cwd)
    if not sha or len(sha) != 40:
        return None
    branch = _run(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd) or ""
    if branch == "HEAD":
        branch = ""
    raw_url = _run(["git", "config", "--get", "remote.origin.url"], cwd) or ""
    repo_url = _strip_credentials(raw_url) if raw_url else ""
    status = _run(["git", "status", "--porcelain"], cwd)
    is_dirty = bool(status)
    return GitContext(
        commit_sha=sha,
        branch=branch,
        repo_url=repo_url,
        is_dirty=is_dirty,
    )


def _from_build_info_file(cwd: str | None) -> GitContext | None:
    base = Path(cwd) if cwd else Path.cwd()
    info_path = base / ".staso-build-info"
    if not info_path.is_file():
        return None
    try:
        data = json.loads(info_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    sha = data.get("commit_sha", "")
    if not sha:
        return None
    return GitContext(
        commit_sha=sha,
        branch=data.get("branch", ""),
        repo_url=data.get("repo_url", ""),
        is_dirty=False,
    )


def detect_git(cwd: str | None = None) -> GitContext | None:
    return (
        _from_staso_env_vars()
        or _from_platform_env_vars()
        or _from_git_cli(cwd)
        or _from_build_info_file(cwd)
    )
