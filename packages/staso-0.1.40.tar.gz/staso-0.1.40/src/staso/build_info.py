"""Write git build info for Docker images.

Usage in Dockerfile:
    RUN python -m staso.build_info
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from .git import detect_git


def main() -> None:
    ctx = detect_git()
    if ctx is None:
        print("staso: no git context detected, skipping .staso-build-info", file=sys.stderr)
        return
    info = {
        "commit_sha": ctx.commit_sha,
        "branch": ctx.branch,
        "repo_url": ctx.repo_url,
    }
    Path(".staso-build-info").write_text(json.dumps(info), encoding="utf-8")
    print(f"staso: wrote .staso-build-info (commit={ctx.commit_sha[:7]})", file=sys.stderr)


if __name__ == "__main__":
    main()
