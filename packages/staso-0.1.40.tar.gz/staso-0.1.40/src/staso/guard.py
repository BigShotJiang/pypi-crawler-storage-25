"""Guard API — check agent actions before they execute.

HTTP transport: urllib, NOT httpx
---------------------------------
This module deliberately uses :mod:`urllib.request` instead of ``httpx``
so it stays importable inside dependency-light subprocesses — the Claude
Code and Codex hook binaries boot in milliseconds and cannot afford an
httpx transitive dep. Every guard call from those hooks (see
``staso/claude_code/hook.py::handle_pre_tool_use``) re-uses this same
function. If you're tempted to "unify" the transport with
``staso.dataset._client`` (which uses httpx), don't — or move guard
evaluation out of the hook subprocess first.

Fail-open vs fail-closed
------------------------
The default behaviour on any guard transport failure (network down,
timeout, unreachable backend) is **fail-open** — the tool call is allowed
to proceed. This is the right default for observability customers who
want a degraded guard service to never block legitimate agent work.

Security-conscious customers can opt into **fail-closed** behaviour, in
which transport failures return ``action="block"`` instead:

1. Per-call: ``guard(..., fail_closed=True)``.
2. Process-wide: set ``STASO_GUARD_FAIL_CLOSED=true`` before ``st.init``.

Fail-closed is NOT the default because a mis-configured Staso endpoint
or flaky network would then silently brick every agent in production.
Ops teams should make this decision deliberately.
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass
from typing import Any
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

from staso._common.helpers import generate_agent_id
from staso._common.version import USER_AGENT
from staso.client import get_client
from staso.guard_types import GuardResult, GuardRuleResult

logger = logging.getLogger(__name__)


class GuardBlocked(Exception):
    """Raised by drop-in LLM integrations when an enforce-mode guard rule blocks one or more tool calls.

    The drop-in integrations (``patch_openai`` / ``patch_anthropic``) evaluate
    guard rules *after* the LLM response arrives but *before* control returns
    to the caller's tool-dispatch loop. When an enforce-mode rule fires, the
    integration evaluates **every** tool call in the batch, emits a child
    ``guard:blocked:*`` span per blocked tool, then raises this exception —
    so the entire batch is prevented from running instead of silently
    executing alongside misleading spans.

    Attributes:
        tool_name: The FIRST tool call that was blocked (for backwards
            compat + one-line error messages).
        result: The ``GuardResult`` for that first tool.
        reason: Short human-readable reason from ``result.reason`` falling
            back to a generic message. When multiple tools are blocked,
            this summarises all of them.
        rules_triggered: Names of every rule that contributed to the block
            across ALL blocked tools (deduplicated, preserving order).
        blocked_tools: Full ordered list of every blocked tool in this
            batch, each entry a ``BlockedTool(tool_name, result)`` record.
            Use this when you need per-tool detail — e.g. to surface all
            failures to the user instead of just the first.

    Typical customer handling::

        try:
            response = client.chat.completions.create(...)
        except staso.GuardBlocked as e:
            for blocked in e.blocked_tools:
                logger.warning(
                    "guard blocked %s: %s (rules: %s)",
                    blocked.tool_name,
                    blocked.result.reason,
                    blocked.result.rules_triggered,
                )
            # fall back to a safer tool, ask the user, etc.
    """

    def __init__(
        self,
        tool_name: str,
        result: GuardResult,
        *,
        blocked_tools: "list[BlockedTool] | None" = None,
    ) -> None:
        self.tool_name = tool_name
        self.result = result

        # Default: a single-entry list so callers can always iterate
        # ``blocked_tools`` without branching on len.
        if blocked_tools is None:
            blocked_tools = [BlockedTool(tool_name=tool_name, result=result)]
        self.blocked_tools: list[BlockedTool] = list(blocked_tools)

        # Deduplicated union of rules across every blocked tool.
        seen: set[str] = set()
        aggregated_rules: list[str] = []
        for bt in self.blocked_tools:
            for rule in bt.result.rules_triggered or []:
                if rule not in seen:
                    seen.add(rule)
                    aggregated_rules.append(rule)
        self.rules_triggered: list[str] = aggregated_rules

        if len(self.blocked_tools) > 1:
            parts = [
                f"{bt.tool_name}: {bt.result.reason}" if bt.result.reason
                else bt.tool_name
                for bt in self.blocked_tools
            ]
            self.reason = "; ".join(parts)
            msg = (
                f"Guard blocked {len(self.blocked_tools)} tools "
                f"({', '.join(bt.tool_name for bt in self.blocked_tools)}): "
                f"{self.reason}"
            )
        else:
            self.reason = result.reason or "Guard policy blocked this tool call"
            msg = f"Guard blocked tool {tool_name!r}: {self.reason}"
        super().__init__(msg)


@dataclass(frozen=True)
class BlockedTool:
    """One blocked tool in a :class:`GuardBlocked` exception."""

    tool_name: str
    result: GuardResult

def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ[name])
    except (KeyError, ValueError):
        return default


# Read at import time so one STASO_GUARD_TIMEOUT export covers every caller:
# explicit guard() users, the observational passes in patch_openai /
# patch_anthropic, and the Claude Code / Codex hook PreToolUse handlers.
_DEFAULT_TIMEOUT = _env_float("STASO_GUARD_TIMEOUT", 10.0)
_DEFAULT_ESCALATION_POLL_INTERVAL = 3.0  # seconds
_DEFAULT_ESCALATION_TIMEOUT = 300.0  # seconds


def _env_bool(name: str, default: bool) -> bool:
    val = os.environ.get(name)
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "on")


def guard(
    tool_name: str,
    tool_input: dict[str, Any],
    *,
    context: dict[str, Any] | None = None,
    wait_for_escalation: bool = False,
    escalation_poll_interval: float = _DEFAULT_ESCALATION_POLL_INTERVAL,
    escalation_timeout: float = _DEFAULT_ESCALATION_TIMEOUT,
    timeout: float = _DEFAULT_TIMEOUT,
    fail_closed: bool | None = None,
) -> GuardResult:
    """Check an agent action before executing it.

    Call this before executing a tool. Returns a GuardResult with the decision.

    If action == "modify": use result.modified_input instead of original.
    If action == "escalate" and wait_for_escalation=True:
        Polls until a human resolves the escalation.
        Returns final action (allow/block) after resolution.
    If action == "escalate" and wait_for_escalation=False:
        Returns immediately. Treat as block.

    Args:
        tool_name: Name of the tool being called
        tool_input: The tool's input parameters
        context: Optional context (session_id, agent_name, trace_id, environment, workspace_id)
        wait_for_escalation: If True, poll until escalation is resolved
        escalation_poll_interval: Seconds between polls (default 3)
        escalation_timeout: Max seconds to wait for escalation (default 300)
        timeout: HTTP request timeout in seconds
        fail_closed: When ``True``, transport failures (network, timeout,
            unreachable backend) return ``action="block"`` instead of
            ``"allow"``. Defaults to the ``STASO_GUARD_FAIL_CLOSED`` env var
            (``false`` by default) so a flaky backend doesn't silently
            brick every agent in production. Security-conscious customers
            should set it explicitly: ``guard(..., fail_closed=True)``.

    Returns:
        GuardResult with the decision
    """
    if fail_closed is None:
        fail_closed = _env_bool("STASO_GUARD_FAIL_CLOSED", False)
    client = get_client()

    # Resolve config from client or fall back to env vars (for hook subprocesses)
    if client is not None and client.config.enabled:
        config = client.config
        api_key = config.api_key
        base_url = config.base_url.rstrip("/")
        default_context = {
            "agent_id": config.agent_id,
            "agent_name": config.agent_name,
            "environment": config.environment,
            "workspace_id": config.workspace_slug,
        }
    else:
        api_key = os.environ.get("STASO_API_KEY", "")
        if not api_key:
            return GuardResult(action="allow", reason="Guard not initialized")
        base_url = os.environ.get("STASO_BASE_URL", "https://api.staso.ai").rstrip("/")
        env_agent_name = os.environ.get("STASO_AGENT_NAME", "")
        # Deterministic UUID5 derived from agent_name, matching the shape
        # written to spans.agent_id by the ingestion service. Without this,
        # subprocess/hook guard calls ended up storing an empty agent_id in
        # guard_violations while the matching span row stored the UUID —
        # the two tables couldn't be joined without a runtime coercion.
        default_context = {
            "agent_id": generate_agent_id(env_agent_name) if env_agent_name else "",
            "agent_name": env_agent_name,
            "environment": os.environ.get("STASO_ENVIRONMENT", "default"),
            "workspace_id": os.environ.get("STASO_WORKSPACE_SLUG", "default"),
        }

    # Build request payload
    payload = {
        "tool_name": tool_name,
        "tool_input": tool_input,
        "context": {
            **default_context,
            **(context or {}),
        },
    }

    start = time.monotonic()

    try:
        response = _post(
            url=f"{base_url}/v1/guard/evaluate",
            api_key=api_key,
            payload=payload,
            timeout=timeout,
        )
    except Exception as e:
        # Transport failure. Default behaviour is fail-open (allow) so a
        # flaky network doesn't brick production agents. Security-sensitive
        # customers opt into fail-closed via kwarg or env var.
        logger.warning("Guard check failed: %s", e)
        if fail_closed:
            return GuardResult(
                action="block",
                reason=f"Guard unavailable (fail-closed): {e}",
                severity="high",
            )
        return GuardResult(action="allow", reason=f"Guard check failed: {e}")

    latency_ms = (time.monotonic() - start) * 1000

    # Parse response
    result = _parse_response(response, latency_ms)

    # Handle escalation polling. Use the local `api_key` — `config` is only
    # defined in the client-enabled branch above, so referencing it here
    # would crash any caller using the env-var fallback path.
    if result.action == "escalate" and wait_for_escalation and result.escalation_id:
        result = _poll_escalation(
            base_url=base_url,
            api_key=api_key,
            escalation_id=result.escalation_id,
            poll_interval=escalation_poll_interval,
            timeout=escalation_timeout,
            original_result=result,
        )

    return result


def _post(url: str, api_key: str, payload: dict, timeout: float) -> dict:
    """Make a POST request to the guard API."""
    data = json.dumps(payload, default=str).encode("utf-8")
    req = Request(
        url,
        data=data,
        headers={
            "Content-Type": "application/json",
            "X-API-Key": api_key,
            "User-Agent": USER_AGENT,
        },
        method="POST",
    )

    with urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _get(url: str, api_key: str, timeout: float) -> dict:
    """Make a GET request."""
    req = Request(
        url,
        headers={
            "X-API-Key": api_key,
            "User-Agent": USER_AGENT,
        },
        method="GET",
    )
    with urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _parse_response(data: dict, latency_ms: float) -> GuardResult:
    """Parse API response into GuardResult."""
    results = []
    for r in data.get("results", []):
        rule_action = r.get("action", "allow")
        results.append(GuardRuleResult(
            rule_id=r.get("rule_id", ""),
            rule_name=r.get("rule_name", ""),
            passed=rule_action == "allow",
            score=r.get("score"),
            action=rule_action,
            reason=r.get("reason", ""),
            severity=r.get("severity", "medium"),
            latency_ms=r.get("latency_ms", 0.0),
            violations=r.get("violations", []),
        ))

    # Derive rules_triggered from individual results (backend doesn't send this separately)
    triggered = data.get("rules_triggered", [])
    if not triggered:
        triggered = [r.rule_name for r in results if not r.passed]

    return GuardResult(
        action=data.get("action", "allow"),
        reason=data.get("reason", ""),
        rule_name=triggered[0] if triggered else None,
        severity=data.get("severity", "low"),
        results=results,
        modified_input=data.get("modified_input"),
        modifications=data.get("modifications", []),
        escalation_id=data.get("escalation_id"),
        latency_ms=latency_ms,
        rules_triggered=triggered,
    )


def _poll_escalation(
    base_url: str,
    api_key: str,
    escalation_id: str,
    poll_interval: float,
    timeout: float,
    original_result: GuardResult,
) -> GuardResult:
    """Poll escalation status until resolved or timeout."""
    start = time.monotonic()
    url = f"{base_url}/v1/guard/escalations/{escalation_id}/status"

    while (time.monotonic() - start) < timeout:
        try:
            status_data = _get(url, api_key, timeout=10.0)
            status = status_data.get("status", "pending")

            if status == "approved":
                return GuardResult(
                    action="allow",
                    reason="Escalation approved",
                    escalation_id=escalation_id,
                    latency_ms=(time.monotonic() - start) * 1000,
                    rules_triggered=original_result.rules_triggered,
                    severity=original_result.severity,
                )
            elif status in ("denied", "timeout"):
                return GuardResult(
                    action="block",
                    reason=f"Escalation {status}",
                    escalation_id=escalation_id,
                    latency_ms=(time.monotonic() - start) * 1000,
                    rules_triggered=original_result.rules_triggered,
                    severity=original_result.severity,
                )

            time.sleep(poll_interval)

        except Exception as e:
            logger.warning("Escalation poll failed: %s", e)
            time.sleep(poll_interval)

    return GuardResult(
        action="block",
        reason="Escalation poll timeout",
        escalation_id=escalation_id,
        latency_ms=(time.monotonic() - start) * 1000,
        rules_triggered=original_result.rules_triggered,
        severity=original_result.severity,
    )
