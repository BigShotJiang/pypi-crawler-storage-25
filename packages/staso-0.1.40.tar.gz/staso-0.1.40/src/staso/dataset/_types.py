"""Dataset data types — frozen dataclasses for SDK responses."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class ColumnType(StrEnum):
    VARIABLE = "variable"
    INPUT = "input"
    OUTPUT = "output"
    EXPECTED_OUTPUT = "expected_output"
    EXPECTED_TOOL_CALLS = "expected_tool_calls"
    SCENARIO = "scenario"
    EXPECTED_STEPS = "expected_steps"
    CONVERSATION_HISTORY = "conversation_history"
    FILES = "files"
    CUSTOM = "custom"


class SplitType(StrEnum):
    TRAIN = "train"
    TEST = "test"
    VALIDATION = "validation"


class StasoDatasetError(Exception):
    def __init__(self, message: str, status_code: int | None = None, response_body: str = ""):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


@dataclass(frozen=True)
class DatasetColumn:
    name: str
    column_type: str = "variable"
    description: str = ""
    required: bool = False


@dataclass(frozen=True)
class Dataset:
    id: str
    name: str
    description: str = ""
    folder_id: str | None = None
    template: str = "custom"
    columns: tuple[DatasetColumn, ...] = ()
    entry_count: int = 0
    created_at: str = ""
    updated_at: str = ""


@dataclass(frozen=True)
class DatasetEntry:
    id: str
    dataset_id: str
    data: dict[str, Any] = field(default_factory=dict)
    split: str | None = None
    source_type: str | None = None
    created_at: str = ""


@dataclass(frozen=True)
class DatasetFolder:
    id: str
    name: str
    parent_id: str | None = None


@dataclass(frozen=True)
class EvalResult:
    entry_id: str
    input_data: dict[str, Any] = field(default_factory=dict)
    expected: dict[str, Any] = field(default_factory=dict)
    actual: Any = None
    scores: dict[str, float] = field(default_factory=dict)
    passed: bool = True
    error: str | None = None
    trace_id: str | None = None
    duration_ms: float = 0.0


@dataclass(frozen=True)
class EvalSummary:
    dataset_id: str
    dataset_name: str
    total: int
    passed: int
    failed: int
    error_count: int
    avg_duration_ms: float
    scores: dict[str, float] = field(default_factory=dict)
    results: tuple[EvalResult, ...] = ()
