"""Evaluation runner — execute agent function against dataset entries."""

from __future__ import annotations

import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import TYPE_CHECKING, Any, Callable

from staso.dataset._types import DatasetEntry, EvalResult, EvalSummary

if TYPE_CHECKING:
    from staso.dataset._client import DatasetHTTPClient

logger = logging.getLogger(__name__)


class EvaluationRunner:
    def __init__(
        self,
        dataset_id: str,
        fn: Callable[[dict[str, Any]], Any],
        scorers: list[Callable[[dict, Any], float]],
        split: str | None,
        max_concurrency: int,
        trace: bool,
        http_client: DatasetHTTPClient,
    ) -> None:
        self._dataset_id = dataset_id
        self._fn = fn
        self._scorers = scorers
        self._split = split
        self._max_concurrency = max_concurrency
        self._trace = trace
        self._http = http_client

    def run(self) -> EvalSummary:
        dataset = self._http.get_dataset(self._dataset_id)

        entries: list[DatasetEntry] = []
        offset = 0
        while True:
            batch = self._http.list_entries(self._dataset_id, self._split, limit=100, offset=offset)
            if not batch:
                break
            entries.extend(batch)
            offset += len(batch)
            if len(batch) < 100:
                break

        results: list[EvalResult] = []
        if self._max_concurrency <= 1:
            for entry in entries:
                results.append(self._run_single(entry))
        else:
            with ThreadPoolExecutor(max_workers=self._max_concurrency) as pool:
                futures = {pool.submit(self._run_single, e): e for e in entries}
                for future in as_completed(futures):
                    results.append(future.result())

        passed = sum(1 for r in results if r.passed)
        failed = sum(1 for r in results if not r.passed and r.error is None)
        error_count = sum(1 for r in results if r.error is not None)
        durations = [r.duration_ms for r in results if r.duration_ms > 0]
        avg_duration = sum(durations) / len(durations) if durations else 0.0

        avg_scores: dict[str, float] = {}
        if self._scorers:
            for i, scorer in enumerate(self._scorers):
                key = getattr(scorer, "__name__", f"scorer_{i}")
                vals = [r.scores.get(key, 0.0) for r in results if key in r.scores]
                if vals:
                    avg_scores[key] = sum(vals) / len(vals)

        return EvalSummary(
            dataset_id=self._dataset_id,
            dataset_name=dataset.name,
            total=len(results),
            passed=passed,
            failed=failed,
            error_count=error_count,
            avg_duration_ms=avg_duration,
            scores=avg_scores,
            results=tuple(results),
        )

    def _run_single(self, entry: DatasetEntry) -> EvalResult:
        import contextlib

        start = time.monotonic()
        actual: Any = None
        error: str | None = None
        trace_id: str | None = None

        # Resolve the span context BEFORE executing the user function. The
        # old implementation wrapped both the span setup *and* the user call
        # in one try/except that retried on any exception — meaning a broken
        # user function ran twice (once inside a span, once outside), which
        # doubled side effects and cost. Split them: tracing setup failures
        # fall back to a null context; user-function exceptions are recorded
        # via the outer try/except exactly once.
        span_cm: Any = contextlib.nullcontext()
        if self._trace:
            try:
                import staso as st

                span_cm = st.span(f"eval:{self._dataset_id}", kind="chain")
            except Exception:
                logger.debug(
                    "eval: tracing unavailable, continuing without span",
                    exc_info=True,
                )

        try:
            with span_cm as s:
                actual = self._fn(entry.data)
                if s is not None:
                    trace_id = getattr(s, "trace_id", None)
        except Exception as e:
            error = str(e)

        duration_ms = (time.monotonic() - start) * 1000

        scores: dict[str, float] = {}
        passed = error is None
        if error is None and self._scorers:
            for scorer in self._scorers:
                key = getattr(scorer, "__name__", "scorer")
                try:
                    score = scorer(entry.data, actual)
                    scores[key] = float(score)
                    if score < 0.5:
                        passed = False
                except Exception as e:
                    logger.warning("Scorer %s failed: %s", key, e)
                    scores[key] = 0.0
                    passed = False

        return EvalResult(
            entry_id=entry.id,
            input_data=entry.data,
            expected={},
            actual=actual,
            scores=scores,
            passed=passed,
            error=error,
            trace_id=trace_id,
            duration_ms=duration_ms,
        )
