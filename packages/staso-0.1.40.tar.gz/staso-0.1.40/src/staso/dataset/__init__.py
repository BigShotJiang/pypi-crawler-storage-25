"""Dataset management — create, curate, evaluate datasets for AI agent testing.

Public API
----------
Every operation is exposed as a **top-level function on this module**::

    import staso as st
    st.init(...)
    ds = st.dataset.create("my-ds")
    st.dataset.add_entry(ds.id, {"input": "hello"})
    summary = st.dataset.evaluate(ds.id, my_agent_fn)

Historical note: earlier versions exposed a ``DatasetNamespace`` instance
bound to ``staso.dataset``. That rebound the package attribute to an
instance, so ``import staso.dataset as mod`` silently returned the
namespace instance instead of the module — a footgun for anyone
introspecting SDK internals. We now use module-level functions, which
keeps ``st.dataset.create(...)`` working while ``import staso.dataset``
returns the actual module.

HTTP transport
--------------
Dataset calls use ``httpx`` because the dataset client only runs inside
the user's own process (never inside a hook subprocess where adding a
heavy dep is painful). The guard API in ``staso.guard`` uses ``urllib``
instead precisely so hook subprocesses (Claude Code, Codex) stay
dependency-light. Do not "unify" them without also handling that.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from staso.dataset._types import (
    ColumnType,
    Dataset,
    DatasetColumn,
    DatasetEntry,
    DatasetFolder,
    EvalResult,
    EvalSummary,
    SplitType,
    StasoDatasetError,
)

if TYPE_CHECKING:
    from staso.dataset._client import DatasetHTTPClient

# Deliberately does NOT collide with the sibling submodule name `_client`.
_http_client: "DatasetHTTPClient | None" = None
_lock = threading.Lock()


# ── Typed trace mapping (Fix 4) ───────────────────────────────────────────


@dataclass(frozen=True)
class TraceColumnMapping:
    """Maps a field from a trace row to a dataset column.

    Replaces the previous ``dict[str, str]`` parameter on ``from_traces``,
    whose direction was ambiguous (was it ``{source: target}`` or
    ``{target: source}``?). This dataclass is explicit::

        st.dataset.from_traces(
            "prod-failures",
            trace_ids=[...],
            mapping=[
                TraceColumnMapping(source="request.body", target="input"),
                TraceColumnMapping(source="response.body", target="output"),
            ],
        )
    """

    source: str
    target: str


def _get_client() -> "DatasetHTTPClient":
    global _http_client
    if _http_client is not None:
        return _http_client

    from staso.client import get_client

    client = get_client()
    if client is None:
        raise RuntimeError("st.init() must be called before using st.dataset")

    with _lock:
        if _http_client is None:
            from staso.dataset._client import DatasetHTTPClient as Cls

            cfg = client.config
            _http_client = Cls(
                base_url=cfg.base_url,
                api_key=cfg.api_key,
                workspace_slug=cfg.workspace_slug,
            )
    return _http_client


def shutdown_dataset_client() -> None:
    global _http_client
    if _http_client is not None:
        _http_client.shutdown()
        _http_client = None


# ── Dataset CRUD ──────────────────────────────────────────────────────────


def create(
    name: str,
    *,
    description: str = "",
    columns: list[dict[str, str]] | None = None,
    folder_id: str | None = None,
) -> Dataset:
    return _get_client().create_dataset(name, description, columns or [], folder_id)


def get(dataset_id: str) -> Dataset:
    return _get_client().get_dataset(dataset_id)


def list(  # noqa: A001 — public API name locked for backwards compat
    *,
    folder_id: str | None = None,
    limit: int = 100,
    offset: int = 0,
) -> "list[Dataset]":
    return _get_client().list_datasets(folder_id, limit, offset)


def update(
    dataset_id: str,
    *,
    name: str | None = None,
    description: str | None = None,
) -> Dataset:
    return _get_client().update_dataset(dataset_id, name, description)


def delete(dataset_id: str) -> None:
    _get_client().delete_dataset(dataset_id)


# ── Entries ───────────────────────────────────────────────────────────────


def add_entry(
    dataset_id: str,
    data: dict[str, Any],
    *,
    split: str | SplitType | None = None,
    source_trace_id: str | None = None,
    source_span_id: str | None = None,
) -> DatasetEntry:
    return _get_client().add_entry(
        dataset_id,
        data,
        str(split) if split else None,
        source_trace_id,
        source_span_id,
    )


def add_entries(
    dataset_id: str,
    entries: "list[dict[str, Any]]",
    *,
    split: str | SplitType | None = None,
) -> "list[DatasetEntry]":
    return _get_client().add_entries(
        dataset_id, entries, str(split) if split else None
    )


def list_entries(
    dataset_id: str,
    *,
    split: str | SplitType | None = None,
    limit: int = 100,
    offset: int = 0,
) -> "list[DatasetEntry]":
    return _get_client().list_entries(
        dataset_id, str(split) if split else None, limit, offset
    )


def update_entry(
    dataset_id: str,
    entry_id: str,
    *,
    data: dict[str, Any] | None = None,
) -> DatasetEntry:
    return _get_client().update_entry(dataset_id, entry_id, data)


def delete_entry(dataset_id: str, entry_id: str) -> None:
    _get_client().delete_entry(dataset_id, entry_id)


# ── CSV ───────────────────────────────────────────────────────────────────


def upload_csv(
    dataset_id: str,
    file_path: str | Path,
    *,
    split: str | SplitType | None = None,
) -> int:
    return _get_client().upload_csv(
        dataset_id, str(file_path), str(split) if split else None
    )


def download_csv(
    dataset_id: str,
    file_path: str | Path,
    *,
    split: str | SplitType | None = None,
) -> Path:
    return Path(
        _get_client().download_csv(
            dataset_id, str(file_path), str(split) if split else None
        )
    )


# ── Trace Curation ────────────────────────────────────────────────────────


def from_traces(
    name: str,
    trace_ids: "list[str]",
    *,
    mapping: "list[TraceColumnMapping] | dict[str, str] | None" = None,
    description: str = "",
) -> Dataset:
    """Build a dataset from existing traces.

    ``mapping`` should be a list of :class:`TraceColumnMapping`
    (``source`` → ``target``). A bare ``dict[str, str]`` is still accepted
    for backwards compatibility: its keys are treated as ``target_column``
    names and values as ``source_field`` paths (the legacy direction). Prefer
    the typed form to avoid ambiguity.
    """
    normalised: "list[TraceColumnMapping] | None" = None
    if mapping is not None:
        if isinstance(mapping, dict):
            import warnings

            warnings.warn(
                "Passing a dict to from_traces(mapping=...) is ambiguous. "
                "Use a list of TraceColumnMapping(source=..., target=...) "
                "instead; the legacy direction {target: source} will be "
                "removed in a future release.",
                DeprecationWarning,
                stacklevel=2,
            )
            normalised = [
                TraceColumnMapping(source=src, target=tgt)
                for tgt, src in mapping.items()
            ]
        else:
            normalised = [
                m if isinstance(m, TraceColumnMapping)
                else TraceColumnMapping(source=m["source"], target=m["target"])
                for m in mapping
            ]
    return _get_client().create_from_traces(name, trace_ids, normalised, description)


# ── Folders ───────────────────────────────────────────────────────────────


def create_folder(name: str, *, parent_id: str | None = None) -> DatasetFolder:
    return _get_client().create_folder(name, parent_id)


def list_folders(*, parent_id: str | None = None) -> "list[DatasetFolder]":
    return _get_client().list_folders(parent_id)


def delete_folder(folder_id: str) -> None:
    _get_client().delete_folder(folder_id)


# ── Evaluation ────────────────────────────────────────────────────────────


def evaluate(
    dataset_id: str,
    fn: Callable[[dict[str, Any]], Any],
    *,
    scorers: "list[Callable[[dict, Any], float]] | None" = None,
    split: str | SplitType | None = None,
    max_concurrency: int = 1,
    trace: bool = True,
) -> EvalSummary:
    from staso.dataset._eval import EvaluationRunner

    return EvaluationRunner(
        dataset_id=dataset_id,
        fn=fn,
        scorers=scorers or [],
        split=str(split) if split else None,
        max_concurrency=max_concurrency,
        trace=trace,
        http_client=_get_client(),
    ).run()


# ── Synthetic ─────────────────────────────────────────────────────────────


def generate(
    dataset_id: str,
    *,
    count: int = 10,
    prompt: str | None = None,
    seed_entry_ids: "list[str] | None" = None,
) -> "list[DatasetEntry]":
    return _get_client().generate_synthetic(dataset_id, count, prompt, seed_entry_ids)


__all__ = [
    # Types
    "ColumnType",
    "Dataset",
    "DatasetColumn",
    "DatasetEntry",
    "DatasetFolder",
    "EvalResult",
    "EvalSummary",
    "SplitType",
    "StasoDatasetError",
    "TraceColumnMapping",
    # Lifecycle
    "shutdown_dataset_client",
    # CRUD
    "create",
    "get",
    "list",
    "update",
    "delete",
    # Entries
    "add_entry",
    "add_entries",
    "list_entries",
    "update_entry",
    "delete_entry",
    # CSV
    "upload_csv",
    "download_csv",
    # Curation
    "from_traces",
    # Folders
    "create_folder",
    "list_folders",
    "delete_folder",
    # Eval
    "evaluate",
    # Synthetic
    "generate",
]
