"""Zero-code-change instrumentation for the OpenAI Python SDK."""
from __future__ import annotations

import functools
import json
import logging
import time
from typing import Any

from ..client import get_client, get_tracer
from ..context import reset_current_span, set_current_span
from ..guard import GuardBlocked
from ..types import (
    META_FREQUENCY_PENALTY,
    META_MAX_TOKENS,
    META_PRESENCE_PENALTY,
    META_PROVIDER,
    META_REASONING_TOKENS,
    META_RESPONSE_FORMAT,
    META_RESPONSE_ID,
    META_SEED,
    META_SERVICE_TIER,
    META_STOP_REASON,
    META_STOP_SEQUENCES,
    META_TEMPERATURE,
    META_TOOL_CHOICE,
    META_TOP_P,
    OPENAI_KEY_CONTENT,
    OPENAI_KEY_MESSAGES,
    OPENAI_KEY_MODEL,
    OPENAI_KEY_ROLE,
    OPENAI_KEY_TOOL_CALLS,
    OPENAI_KEY_TOOLS,
    SpanKind,
    SpanStatus,
)
from ._guard_common import evaluate_and_enforce
from ._openai_streaming import AsyncOpenAIStreamProxy, OpenAIStreamProxy
from ._tool_loop_state import (
    after_llm_call as _tool_loop_after,
    before_llm_call as _tool_loop_before,
    close_agent_run as _tool_loop_close_run,
    ensure_agent_run as _tool_loop_open_run,
    record_tool_uses as _tool_loop_record,
)

logger = logging.getLogger("staso")

# Marker we stamp on the wrapped create() so _wrap_sync / _wrap_async can
# recognise an already-wrapped function and refuse to double-wrap. The
# module-level `_patched` flag below is kept for back-compat callers that
# still flip it, but the per-function marker is the authoritative signal.
_STASO_PATCH_MARKER = "_staso_patched"
_patched = False


def _parse_tool_args(args_raw: Any) -> dict[str, Any]:
    if isinstance(args_raw, str):
        try:
            parsed = json.loads(args_raw)
        except (json.JSONDecodeError, TypeError):
            return {"raw_arguments": args_raw}
        return parsed if isinstance(parsed, dict) else {"value": parsed}
    if isinstance(args_raw, dict):
        return args_raw
    return {}


def _build_tool_call_refs(
    response_tool_calls: Any,
    dumped_tool_calls: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Zip the live OpenAI tool_call objects with their dumped dict copies so
    the shared guard helper can both read names/inputs (from the dicts) and
    mutate the live objects for ``modify`` actions (via the refs)."""
    refs: list[dict[str, Any]] = []
    live = list(response_tool_calls) if response_tool_calls else []
    for idx, tc_dict in enumerate(dumped_tool_calls):
        if not isinstance(tc_dict, dict):
            continue
        func = tc_dict.get("function") or {}
        name = func.get("name", "unknown")
        inp = _parse_tool_args(func.get("arguments", "{}"))
        ref = live[idx] if idx < len(live) else None
        refs.append({"name": name, "input": inp, "ref": ref})
    return refs


def _apply_openai_modify(ref: Any, modified_input: dict[str, Any]) -> None:
    """Rewrite the live OpenAI ``ChatCompletionMessageToolCall`` in place so
    the caller's agent loop dispatches the modified arguments."""
    if ref is None:
        return
    try:
        ref.function.arguments = json.dumps(modified_input)
    except Exception:
        logger.debug("staso: openai tool_call mutation failed", exc_info=True)


def patch_openai() -> None:
    """Monkey-patch ``openai.resources.chat.Completions.create`` and ``.parse``
    (sync and async) to automatically emit LLM spans with comprehensive data
    capture.

    ``parse()`` is the structured-output helper (Pydantic ``response_format``);
    it bypasses ``create()`` internally and calls ``self._post`` directly, so
    it needs its own wrapper -- wrapping only ``create`` misses every
    ``client.chat.completions.parse(...)`` call.

    Safe to call multiple times -- only patches once.
    """
    global _patched
    if _patched:
        return

    try:
        from openai.resources.chat import AsyncCompletions, Completions
    except ImportError:
        raise ImportError(
            "openai package is required for this integration. "
            "Install it with: pip install 'staso[openai]'"
        )

    _wrap_sync(Completions)
    _wrap_async(AsyncCompletions)
    _wrap_sync_parse(Completions)
    _wrap_async_parse(AsyncCompletions)
    _patched = True
    logger.debug("staso: openai SDK patched")


def _extract_model(args: tuple, kwargs: dict) -> str:
    return str(kwargs.get("model", args[0] if args else ""))


_ROOT_LABEL_MAX = 60
_TOOL_LIST_MAX = 3

# finish_reasons that mark a single call "terminal" (model has stopped
# asking for tools). The state machine's stack-frame anchor decides
# whether a terminal response actually closes the synthetic agent-run:
# while the user's entry frame is still on the stack (e.g. a ``for``
# loop over prompts, an orchestrator between tool dispatches, a
# long-running ``_loop`` awaiting the next sweep) the close is a
# no-op and further LLM calls land in the same trace. When the anchor
# returns or no anchor could be captured (REPL / notebook top-level),
# a terminal call closes as a clean fallback.
_TERMINAL_FINISH_REASONS = frozenset(
    {"stop", "length", "content_filter", "function_call"}
)


def _first_user_text(messages: Any) -> str:
    """Return the first user message's text content. Handles plain
    string + the multimodal list-of-parts form (``{"type":"text",
    "text":"..."}``)."""
    if not isinstance(messages, list):
        return ""
    for m in messages:
        if not isinstance(m, dict) or m.get("role") != "user":
            continue
        content = m.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    t = part.get("text")
                    if isinstance(t, str) and t.strip():
                        return t
        return ""
    return ""


def _derive_root_label(messages: Any, model: str) -> str:
    """First markdown heading in the user's prompt, else first non-
    empty line, capped at ``_ROOT_LABEL_MAX``. Falls back to ``chat:
    <model>`` if the message carries no usable text."""
    text = _first_user_text(messages).strip()
    if not text:
        return f"chat: {model}" if model else "openai.chat.completions.create"

    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("#"):
            label = stripped.lstrip("#").strip()
            if label:
                return label[:_ROOT_LABEL_MAX]
        return stripped[:_ROOT_LABEL_MAX]

    return f"chat: {model}" if model else "openai.chat.completions.create"


def _derive_child_label(response: Any) -> str:
    """Label for a continuation LLM call: ``chat:tool_calls(foo, bar)``
    when the model requests more tools, ``chat:reply`` on a terminal
    finish, or ``chat:<finish_reason>`` otherwise."""
    choices = getattr(response, "choices", None) or []
    finish_reason = ""
    tool_names: list[str] = []
    if choices:
        finish_reason = getattr(choices[0], "finish_reason", "") or ""
        msg = getattr(choices[0], "message", None)
        if msg is not None:
            for tc in getattr(msg, "tool_calls", None) or []:
                fn = getattr(tc, "function", None)
                name = getattr(fn, "name", None) if fn is not None else None
                tool_names.append(str(name) if name else "?")

    if finish_reason == "tool_calls" and tool_names:
        shown = tool_names[:_TOOL_LIST_MAX]
        extra = len(tool_names) - len(shown)
        suffix = f", …+{extra}" if extra > 0 else ""
        return f"chat:tool_calls({', '.join(shown)}{suffix})"
    if finish_reason in _TERMINAL_FINISH_REASONS:
        return "chat:reply"
    if finish_reason:
        return f"chat:{finish_reason}"
    return "chat"


def _extract_openai_tool_calls(response: Any) -> list[dict]:
    """Normalise this response's ``tool_calls`` into the state machine's
    ``{"id","name","input"}`` format. ``arguments`` is a JSON string on
    the wire; we parse it here so downstream sees a real dict."""
    out: list[dict] = []
    choices = getattr(response, "choices", None) or []
    if not choices:
        return out
    msg = getattr(choices[0], "message", None)
    if msg is None:
        return out
    for tc in getattr(msg, "tool_calls", None) or []:
        tc_id = getattr(tc, "id", None)
        fn = getattr(tc, "function", None)
        name = getattr(fn, "name", None) if fn is not None else None
        raw_args = getattr(fn, "arguments", None) if fn is not None else None
        if not tc_id or not name:
            continue
        out.append(
            {
                "id": tc_id,
                "name": name,
                "input": _parse_tool_args(raw_args),
            }
        )
    return out


def _extract_openai_tool_results(messages: Any) -> list[tuple[str, Any]]:
    """OpenAI signals a tool-loop continuation with one or more messages
    of ``role: "tool"`` immediately after the assistant's
    ``tool_calls``. Each carries ``tool_call_id`` and the result in
    ``content``. We scan from the end backwards, collecting the
    contiguous tool-role tail."""
    if not isinstance(messages, list) or not messages:
        return []
    out: list[tuple[str, Any]] = []
    for m in reversed(messages):
        if not isinstance(m, dict):
            break
        if m.get("role") != "tool":
            break
        tcid = m.get("tool_call_id")
        if tcid:
            out.append((tcid, m.get("content")))
    # We walked backwards; restore chronological order.
    out.reverse()
    return out


def _capture_input(model: str, kwargs: dict) -> dict:
    """Build the span input dict from request kwargs."""
    inp: dict[str, Any] = {
        OPENAI_KEY_MODEL: model,
    }

    tools = kwargs.get("tools")
    if tools:
        inp[OPENAI_KEY_TOOLS] = tools

    client = get_client()
    if client and client.config.capture_messages:
        messages = kwargs.get("messages")
        if messages:
            inp[OPENAI_KEY_MESSAGES] = messages

    return inp


def _capture_metadata(kwargs: dict) -> dict[str, Any]:
    """Extract request parameters into metadata dict."""
    meta: dict[str, Any] = {META_PROVIDER: "openai"}

    _optional_keys = [
        ("temperature", META_TEMPERATURE),
        ("max_tokens", META_MAX_TOKENS),
        ("max_completion_tokens", META_MAX_TOKENS),
        ("top_p", META_TOP_P),
        ("frequency_penalty", META_FREQUENCY_PENALTY),
        ("presence_penalty", META_PRESENCE_PENALTY),
        ("seed", META_SEED),
        ("stop", META_STOP_SEQUENCES),
        ("tool_choice", META_TOOL_CHOICE),
        ("response_format", META_RESPONSE_FORMAT),
        ("service_tier", META_SERVICE_TIER),
    ]
    for kwarg_key, meta_key in _optional_keys:
        val = kwargs.get(kwarg_key)
        if val is not None:
            meta[meta_key] = val

    return meta


_RAW_RESPONSE_TYPES: tuple[type, ...] | None = None


def _raw_response_types() -> tuple[type, ...]:
    """Resolve and cache the openai raw-response wrapper classes.

    Two families today:
    * ``LegacyAPIResponse`` (``openai._legacy_response``) — what litellm's
      ``with_raw_response.create`` returns on openai 1.x/2.x. Upstream has
      flagged this class for deletion in the next major release, to be
      replaced by ``APIResponse`` / ``AsyncAPIResponse``.
    * ``BaseAPIResponse`` (``openai._response``) — shared parent of the
      modern ``APIResponse`` / ``AsyncAPIResponse``. Using the base class
      means a future openai release that adds new async/sync raw-response
      subclasses is still caught without a code change.

    Matches the OpenTelemetry OpenAI instrumentor pattern: lazy-import once,
    cache for process lifetime. Each class is imported independently so the
    removal of ``LegacyAPIResponse`` in openai 3.x doesn't cascade — we
    continue working via ``BaseAPIResponse``. If *both* imports fail (openai
    not installed, or its private module tree was reshuffled) we return an
    empty tuple and ``_unwrap_raw_response`` no-ops via ``isinstance(x, ())``.
    Raising here would turn every wrapped call into a hard crash for tests
    that don't depend on the openai package at all (e.g. fake-client tests).
    """
    global _RAW_RESPONSE_TYPES
    if _RAW_RESPONSE_TYPES is not None:
        return _RAW_RESPONSE_TYPES
    found: list[type] = []
    try:
        from openai._legacy_response import LegacyAPIResponse
        found.append(LegacyAPIResponse)
    except ImportError:
        pass
    try:
        from openai._response import BaseAPIResponse
        found.append(BaseAPIResponse)
    except ImportError:
        pass
    _RAW_RESPONSE_TYPES = tuple(found)
    return _RAW_RESPONSE_TYPES


def _unwrap_raw_response(response: Any) -> Any:
    """Unwrap a raw-response wrapper (openai ``LegacyAPIResponse`` /
    ``APIResponse``) into the parsed ``ChatCompletion``.

    litellm calls ``openai.chat.completions.with_raw_response.create`` so it
    can read provider-specific headers (cost, model-overrides). The object
    returned is a raw-response wrapper with no ``.choices`` / ``.usage``
    attributes — calling ``.parse()`` yields the underlying ``ChatCompletion``.
    ``.parse()`` is idempotent (result is cached), so this is safe even when
    litellm parses the response itself downstream.
    """
    if response is None:
        return response
    if isinstance(response, _raw_response_types()):
        return response.parse()
    return response


def _capture_response(span: Any, response: Any) -> None:
    """Extract response data onto span fields, then evaluate guard rules.

    Tool name extraction: tool names come from tool_call.function.name
    within response.choices[0].message.tool_calls. They are serialized
    via model_dump() into the span output dict under OPENAI_KEY_TOOL_CALLS.

    Guard evaluation happens AFTER the span data is captured but BEFORE
    returning control to the caller. If an enforce-mode rule blocks a tool
    call, ``evaluate_and_enforce`` raises ``GuardBlocked`` which propagates
    out of this function — the patched ``create()`` never returns a
    blocked response to the caller's agent loop.
    """
    response = _unwrap_raw_response(response)
    tc_list: list[dict[str, Any]] = []
    live_tool_calls: Any = None
    choices = getattr(response, "choices", None)
    if choices and len(choices) > 0:
        message = getattr(choices[0], "message", None)
        if message:
            content = getattr(message, "content", None) or ""
            role = getattr(message, "role", "assistant")
            live_tool_calls = getattr(message, "tool_calls", None)

            output: dict[str, Any] = {
                OPENAI_KEY_CONTENT: content,
                OPENAI_KEY_ROLE: role,
            }
            if live_tool_calls:
                for tc in live_tool_calls:
                    if hasattr(tc, "model_dump"):
                        tc_list.append(tc.model_dump())
                    elif isinstance(tc, dict):
                        tc_list.append(tc)
                    else:
                        tc_list.append(str(tc))
                output[OPENAI_KEY_TOOL_CALLS] = tc_list
            span.output = output

        finish_reason = getattr(choices[0], "finish_reason", None)
        if finish_reason:
            span.metadata[META_STOP_REASON] = finish_reason

    response_id = getattr(response, "id", None)
    if response_id:
        span.metadata[META_RESPONSE_ID] = response_id

    usage = getattr(response, "usage", None)
    if usage:
        span.input_tokens = getattr(usage, "prompt_tokens", 0) or 0
        span.output_tokens = getattr(usage, "completion_tokens", 0) or 0
        span.total_tokens = getattr(usage, "total_tokens", 0) or 0

        details = getattr(usage, "completion_tokens_details", None)
        if details:
            reasoning = getattr(details, "reasoning_tokens", None)
            if reasoning:
                span.metadata[META_REASONING_TOKENS] = reasoning

    # Tool-loop state machine: record every tool_call so the next
    # chat.completions.create with matching role:tool messages can
    # retro-emit tool:<name> spans + stitch under this span's trace.
    _tool_loop_record(span, _extract_openai_tool_calls(response))

    # Guard enforcement — raises GuardBlocked on enforce-mode blocks. Must
    # propagate so the caller's tool dispatch loop never sees a blocked
    # response.
    if tc_list:
        refs = _build_tool_call_refs(live_tool_calls, tc_list)
        evaluate_and_enforce(refs, span, apply_modify=_apply_openai_modify)


def _wrap_sync(cls: type) -> None:
    original = cls.create
    # Idempotent: refuse to wrap an already-wrapped function. Without this
    # guard, tests that flip the module-level `_patched` flag and call
    # _wrap_sync again double-wrap the class — the outer wrapper then
    # emits a span around the inner wrapper's span, producing ghost traces.
    if getattr(original, _STASO_PATCH_MARKER, False):
        return

    @functools.wraps(original)
    def _traced(self: Any, *args: Any, **kwargs: Any) -> Any:
        tracer = get_tracer()
        model = _extract_model(args, kwargs)

        if kwargs.get("stream"):
            span = tracer.start_span(
                "openai.chat.completions.create", kind=SpanKind.LLM
            )
            span.model = model
            span.input = _capture_input(model, kwargs)
            span.metadata.update(_capture_metadata(kwargs))
            token = set_current_span(span)
            start_time = time.time()
            try:
                stream = original(self, *args, **kwargs)
                return OpenAIStreamProxy(stream, span, start_time, token)
            except Exception as exc:
                span.record_exception(exc)
                span.end()
                reset_current_span(token)
                raise
        else:
            messages = kwargs.get("messages")
            tool_results = _extract_openai_tool_results(messages)
            ghost_token = _tool_loop_before(tool_results)
            if ghost_token is None:
                _tool_loop_open_run(_derive_root_label(messages, model))
            terminal = False
            errored: BaseException | None = None
            try:
                with tracer.start_as_current_span(
                    "chat", kind=SpanKind.LLM
                ) as span:
                    span.model = model
                    span.input = _capture_input(model, kwargs)
                    span.metadata.update(_capture_metadata(kwargs))
                    try:
                        response = original(self, *args, **kwargs)
                        _parsed = _unwrap_raw_response(response)
                        _capture_response(span, _parsed)
                        span.name = _derive_child_label(_parsed)
                        choices = getattr(_parsed, "choices", None) or []
                        finish_reason = (
                            getattr(choices[0], "finish_reason", "") or ""
                            if choices
                            else ""
                        )
                        terminal = finish_reason in _TERMINAL_FINISH_REASONS
                        span.status = SpanStatus.OK
                        return response
                    except BaseException as exc:
                        errored = exc
                        span.record_exception(exc)
                        raise
            finally:
                _tool_loop_after(ghost_token)
                # Pass the true terminal flag; the state machine's
                # stack-frame anchor decides whether to actually close
                # (caller still running → no-op; caller returned or
                # no anchor → close). Symmetric with Anthropic.
                _tool_loop_close_run(terminal=terminal, error=errored)

    # Stamp the wrapper + stash the original so tests can unwrap and so
    # re-patching after a reset is safe.
    setattr(_traced, _STASO_PATCH_MARKER, True)
    _traced._staso_original = original  # type: ignore[attr-defined]
    cls.create = _traced  # type: ignore[assignment]


def _sanitize_parse_kwargs(kwargs: dict) -> dict:
    """``parse()`` takes ``response_format`` as a Pydantic ``BaseModel``
    subclass. A class object can't round-trip through ``json.dumps`` cleanly
    (``default=str`` yields ``<class '...'>``), so dump the schema for span
    capture. The real class is still passed to the underlying API call
    unchanged -- only the copy used for metadata is rewritten."""
    rf = kwargs.get("response_format")
    if rf is None or not isinstance(rf, type):
        return kwargs
    dumped: Any
    try:
        dumped = {
            "type": "json_schema",
            "class": rf.__name__,
            "schema": rf.model_json_schema(),
        }
    except Exception:
        dumped = rf.__name__
    sanitized = dict(kwargs)
    sanitized["response_format"] = dumped
    return sanitized


def _wrap_async(cls: type) -> None:
    original = cls.create
    if getattr(original, _STASO_PATCH_MARKER, False):
        return

    @functools.wraps(original)
    async def _traced(self: Any, *args: Any, **kwargs: Any) -> Any:
        tracer = get_tracer()
        model = _extract_model(args, kwargs)

        if kwargs.get("stream"):
            span = tracer.start_span(
                "openai.chat.completions.create", kind=SpanKind.LLM
            )
            span.model = model
            span.input = _capture_input(model, kwargs)
            span.metadata.update(_capture_metadata(kwargs))
            token = set_current_span(span)
            start_time = time.time()
            try:
                stream = await original(self, *args, **kwargs)
                return AsyncOpenAIStreamProxy(stream, span, start_time, token)
            except Exception as exc:
                span.record_exception(exc)
                span.end()
                reset_current_span(token)
                raise
        else:
            messages = kwargs.get("messages")
            tool_results = _extract_openai_tool_results(messages)
            ghost_token = _tool_loop_before(tool_results)
            if ghost_token is None:
                _tool_loop_open_run(_derive_root_label(messages, model))
            terminal = False
            errored: BaseException | None = None
            try:
                with tracer.start_as_current_span(
                    "chat", kind=SpanKind.LLM
                ) as span:
                    span.model = model
                    span.input = _capture_input(model, kwargs)
                    span.metadata.update(_capture_metadata(kwargs))
                    try:
                        response = await original(self, *args, **kwargs)
                        _parsed = _unwrap_raw_response(response)
                        _capture_response(span, _parsed)
                        span.name = _derive_child_label(_parsed)
                        choices = getattr(_parsed, "choices", None) or []
                        finish_reason = (
                            getattr(choices[0], "finish_reason", "") or ""
                            if choices
                            else ""
                        )
                        terminal = finish_reason in _TERMINAL_FINISH_REASONS
                        span.status = SpanStatus.OK
                        return response
                    except BaseException as exc:
                        errored = exc
                        span.record_exception(exc)
                        raise
            finally:
                _tool_loop_after(ghost_token)
                # Pass the true terminal flag; the state machine's
                # stack-frame anchor decides whether to actually close
                # (caller still running → no-op; caller returned or
                # no anchor → close). Symmetric with Anthropic.
                _tool_loop_close_run(terminal=terminal, error=errored)

    setattr(_traced, _STASO_PATCH_MARKER, True)
    _traced._staso_original = original  # type: ignore[attr-defined]
    cls.create = _traced  # type: ignore[assignment]


def _wrap_sync_parse(cls: type) -> None:
    """Patch ``Completions.parse`` -- the Pydantic structured-output helper.

    Mirrors ``_wrap_sync`` but for the non-streaming ``parse()`` path.
    ``parse()`` never streams, so there's no ``stream=True`` branch. The
    response is a ``ParsedChatCompletion`` -- a subclass of
    ``ChatCompletion`` -- so the existing ``_capture_response`` helpers work
    unchanged."""
    if not hasattr(cls, "parse"):
        return
    original = cls.parse
    if getattr(original, _STASO_PATCH_MARKER, False):
        return

    @functools.wraps(original)
    def _traced(self: Any, *args: Any, **kwargs: Any) -> Any:
        tracer = get_tracer()
        model = _extract_model(args, kwargs)

        messages = kwargs.get("messages")
        tool_results = _extract_openai_tool_results(messages)
        ghost_token = _tool_loop_before(tool_results)
        if ghost_token is None:
            _tool_loop_open_run(_derive_root_label(messages, model))
        terminal = False
        errored: BaseException | None = None
        try:
            with tracer.start_as_current_span("chat", kind=SpanKind.LLM) as span:
                span.model = model
                span.input = _capture_input(model, kwargs)
                span.metadata.update(_capture_metadata(_sanitize_parse_kwargs(kwargs)))
                try:
                    response = original(self, *args, **kwargs)
                    _capture_response(span, response)
                    span.name = _derive_child_label(response)
                    choices = getattr(response, "choices", None) or []
                    finish_reason = (
                        getattr(choices[0], "finish_reason", "") or ""
                        if choices
                        else ""
                    )
                    terminal = finish_reason in _TERMINAL_FINISH_REASONS
                    span.status = SpanStatus.OK
                    return response
                except BaseException as exc:
                    errored = exc
                    span.record_exception(exc)
                    raise
        finally:
            _tool_loop_after(ghost_token)
            # Pass the true terminal flag; the state machine's
            # stack-frame anchor decides whether to actually close.
            _tool_loop_close_run(terminal=terminal, error=errored)

    setattr(_traced, _STASO_PATCH_MARKER, True)
    _traced._staso_original = original  # type: ignore[attr-defined]
    cls.parse = _traced  # type: ignore[assignment]


def _wrap_async_parse(cls: type) -> None:
    """Async counterpart of ``_wrap_sync_parse``."""
    if not hasattr(cls, "parse"):
        return
    original = cls.parse
    if getattr(original, _STASO_PATCH_MARKER, False):
        return

    @functools.wraps(original)
    async def _traced(self: Any, *args: Any, **kwargs: Any) -> Any:
        tracer = get_tracer()
        model = _extract_model(args, kwargs)

        messages = kwargs.get("messages")
        tool_results = _extract_openai_tool_results(messages)
        ghost_token = _tool_loop_before(tool_results)
        if ghost_token is None:
            _tool_loop_open_run(_derive_root_label(messages, model))
        terminal = False
        errored: BaseException | None = None
        try:
            with tracer.start_as_current_span("chat", kind=SpanKind.LLM) as span:
                span.model = model
                span.input = _capture_input(model, kwargs)
                span.metadata.update(_capture_metadata(_sanitize_parse_kwargs(kwargs)))
                try:
                    response = await original(self, *args, **kwargs)
                    _capture_response(span, response)
                    span.name = _derive_child_label(response)
                    choices = getattr(response, "choices", None) or []
                    finish_reason = (
                        getattr(choices[0], "finish_reason", "") or ""
                        if choices
                        else ""
                    )
                    terminal = finish_reason in _TERMINAL_FINISH_REASONS
                    span.status = SpanStatus.OK
                    return response
                except BaseException as exc:
                    errored = exc
                    span.record_exception(exc)
                    raise
        finally:
            _tool_loop_after(ghost_token)
            # Pass the true terminal flag; the state machine's
            # stack-frame anchor decides whether to actually close.
            _tool_loop_close_run(terminal=terminal, error=errored)

    setattr(_traced, _STASO_PATCH_MARKER, True)
    _traced._staso_original = original  # type: ignore[attr-defined]
    cls.parse = _traced  # type: ignore[assignment]
