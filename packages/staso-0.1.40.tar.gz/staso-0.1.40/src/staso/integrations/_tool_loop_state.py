"""Tool-loop state machine shared by Anthropic + OpenAI integrations.

Why this module exists
----------------------
A drop-in integration (``patch_anthropic`` / ``patch_openai``) only sees
the HTTP boundary — one span per ``messages.create`` /
``chat.completions.create`` call. On its own that gives N sibling root
traces per tool loop, no tool spans, and the live dashboard gives up
(because each trace immediately reports ``has_root_span=TRUE`` so the
backend flips ``is_live=false``).

This state machine stitches those calls into one trace that streams
live:

1. **Synthetic agent-run root.** On the first call we open an
   ``AGENT``-kind root span and keep it open. Every LLM span becomes
   its child. The root is only emitted *after* the agent run ends
   (anchor frame returns OR a terminal response fires with no anchor),
   so the backend's ``has_root_span=FALSE`` window stretches across the
   whole run and ``is_live=true`` stays on.
2. **Tool-result stitching.** When a new call carries ``tool_result``
   blocks for a ``tool_use_id`` we recorded last turn, we emit a
   retroactive ``tool:<name>`` child span with the real duration
   (response-of-previous-turn → start-of-this-turn), and we push the
   prior LLM span into context so the new call lands under the same
   ``trace_id``.
3. **Stack-frame anchoring.** On the first LLM call the state machine
   walks the Python call stack and captures the outermost non-SDK
   frame as the "anchor" — that frame IS the agent run. As long as the
   anchor is still on the stack, further LLM calls (sibling calls in a
   ``for`` loop, nested LLM calls inside tool handlers, continuation
   calls across tool-use turns) all reuse the same root and land in
   one trace. When the anchor returns, the next LLM call detects it's
   gone, closes the stale root, and opens a fresh one anchored to the
   new caller. This lets ``run_sweep()`` produce one trace per
   invocation without any decorator — matching the user's mental model
   of "one function call = one agent run".
4. **Process-exit safety.** An ``atexit`` hook closes any lingering
   agent-run so broken/abandoned loops still produce a complete trace.
   ``client.shutdown()`` reaches the same path through
   ``force_close_agent_run``, so explicit shutdowns emit the root
   before draining the transport.

Provider close policy
---------------------
``close_agent_run(terminal, error)`` is the shared per-call close
hook. Both providers pass ``terminal`` reflecting their native stop
semantics (Anthropic: ``stop_reason ∈ {end_turn, stop_sequence,
max_tokens}``; OpenAI: ``finish_reason ∈ {stop, length,
content_filter, function_call}``). The close decision then depends on
the anchor state:

* **Anchor still on stack** — terminal is a no-op. The caller is still
  running and may fire more LLM calls that should land in the same
  trace. Root stays open.
* **Anchor gone (or never captured)** — terminal closes the root.
  Matches legacy behaviour for REPL / notebook top-level calls where
  no user function wraps the call.
* **Error** — always closes. The anchor doesn't protect a crashing
  run from emitting its trace.

``force_close_agent_run`` closes unconditionally. Use it between
explicit workflow phases that should appear as separate traces, or
rely on atexit for process shutdown.

Provider-neutral contract
-------------------------
The state machine consumes **normalised** tool-use records:

    ToolUse = {"id": str, "name": str, "input": dict}

The Anthropic/OpenAI wrappers parse their native response shapes into
this form and back.
"""
from __future__ import annotations

import atexit
import logging
import random
import sys
import threading
import time
from collections import OrderedDict
from contextvars import ContextVar
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from ..client import get_client, get_tracer
from ..context import (
    agent_name_var,
    get_current_span,
    reset_current_span,
    set_current_span,
)
from ..provider import Span, _hex_to_uuid, _safe_json
from ..types import SpanKind, SpanStatus

logger = logging.getLogger("staso")

# Cap pending-tool registry to avoid unbounded growth in long-lived
# processes. Normal tool loops pop entries as they consume them.
_MAX_ENTRIES = 2000


@dataclass
class _PendingTool:
    name: str
    tool_input: dict[str, Any]
    start_time: float
    parent_trace_id: str
    parent_span_id: str
    agent_name: str
    agent_id: str
    session_id: str
    user_id: str


_LOCK = threading.Lock()
_PENDING_TOOLS: "OrderedDict[str, _PendingTool]" = OrderedDict()

# One synthetic agent-run root per ContextVar context. Sync code in a
# single thread shares one context, so a typical agent gets exactly one.
_AGENT_RUN_SPAN: ContextVar[Span | None] = ContextVar(
    "_staso_agent_run_span", default=None
)
# Token for the matching ``set_current_span(agent_run)`` so we can
# cleanly restore the caller's prior parent when the run closes. Without
# this the ended (non-recording) agent_run would linger in context and
# force subsequent spans into the NOOP path.
_AGENT_RUN_TOKEN: ContextVar[Any] = ContextVar(
    "_staso_agent_run_token", default=None
)
# Stack-frame anchor path for the active agent run. Stored as a tuple
# of ``_FrameAnchor`` in INNERMOST-FIRST order: ``(immediate_caller,
# parent, grandparent, …, outermost_user_frame)``. Only the ancestors
# (path[1:]) are used to decide "same run or not":
#
#   * Same run iff every stored ancestor is still on the current stack.
#     Sibling calls from the same or from different immediate callers
#     land in the same trace as long as the common ancestors are
#     intact. This covers lead_hunter (score and draft share the
#     ``run_sweep`` ancestor), target_companies_enrichment (repeated
#     ``_chat()`` calls share the ``enrich`` ancestor), and
#     competitor_watch (tool-loop turns share the ``_tool_loop``
#     ancestor).
#   * New run whenever any stored ancestor has returned. Iterating a
#     loop that calls ``run_sweep()`` N times produces N traces
#     because each invocation gets a fresh ``run_sweep`` frame.
#
# Empty tuple means no user frames could be identified (REPL / pure
# framework stack); in that mode we fall back to the legacy
# close-on-terminal behaviour.
_ANCHOR_PATH: ContextVar["tuple[_FrameAnchor, ...]"] = ContextVar(
    "_staso_anchor_path", default=()
)


# ── Stack-frame anchor ──────────────────────────────────────────────


@dataclass
class _FrameAnchor:
    """Pinned reference to a Python stack frame.

    Holds the frame object itself so identity comparisons (``is``) can
    distinguish between a frame that is still on the stack and a new
    invocation of the same function that happened to reuse CPython's
    recycled frame memory. While we hold the reference the frame can't
    be deallocated, so a later ``is`` check against the current stack
    is authoritative: match → same invocation still running; no match
    → frame has returned.

    ``qualname`` / ``filename`` / ``firstlineno`` are captured alongside
    for display and debugging only — they play no role in identity.
    """

    frame: Any
    qualname: str
    filename: str
    firstlineno: int


# Filename substrings that mark frames we skip when walking the stack
# to find a user anchor. Three buckets: the Staso SDK itself, the
# provider SDKs we wrap, and "infrastructure" frames (Python stdlib,
# installed third-party packages, the pytest / asyncio / runpy
# runners). What's left after filtering is the user's own code.
_FRAMEWORK_FRAME_MARKERS = (
    # Staso SDK
    "/staso/",
    "\\staso\\",
    # Provider SDKs we wrap — their internal frames are not user code
    # even when the direct caller of ``messages.create`` is user-side
    "/anthropic/",
    "\\anthropic\\",
    "/openai/",
    "\\openai\\",
    # Installed third-party packages (pytest, FastAPI, Celery, etc.)
    "/site-packages/",
    "\\site-packages\\",
    # CPython stdlib (runpy, asyncio, threading, typing, functools, …)
    "/lib/python",
    "\\lib\\python",
    # Frozen importlib / bootstrap modules surface as ``<frozen …>``
    "<frozen ",
)

_ROOT_LABEL_MAX_ANCHOR = 60


def _frame_qualname(frame: Any) -> str:
    """``co_qualname`` when available (Python 3.11+), else ``co_name``."""
    code = getattr(frame, "f_code", None)
    if code is None:
        return ""
    return getattr(code, "co_qualname", None) or getattr(code, "co_name", "") or ""


def _is_framework_frame(frame: Any) -> bool:
    """True if the frame's source file is in Staso, a wrapped provider
    SDK, the Python stdlib, or an installed third-party package —
    anything that is NOT the user's own code."""
    code = getattr(frame, "f_code", None)
    if code is None:
        return True
    filename = getattr(code, "co_filename", "") or ""
    return any(marker in filename for marker in _FRAMEWORK_FRAME_MARKERS)


def _walk_non_framework_frames(start_frame: Any) -> list[_FrameAnchor]:
    """Walk from ``start_frame`` upward, returning all non-framework
    frames as ``_FrameAnchor`` entries, ordered innermost-first.

    Each anchor pins a reference to its frame object so later identity
    (``is``) comparisons against the current stack stay correct even
    when CPython recycles the frame memory after a function returns."""
    path: list[_FrameAnchor] = []
    frame = start_frame
    while frame is not None:
        if not _is_framework_frame(frame):
            code = frame.f_code
            path.append(
                _FrameAnchor(
                    frame=frame,
                    qualname=_frame_qualname(frame),
                    filename=getattr(code, "co_filename", "") or "",
                    firstlineno=getattr(code, "co_firstlineno", 0) or 0,
                )
            )
        frame = frame.f_back
    return path


def _find_anchor_path() -> tuple[_FrameAnchor, ...]:
    """Return the non-framework call-stack path, innermost-first.

    Caller's caller (``sys._getframe(1)``) is the outermost Staso
    frame; we walk up from there. Framework frames (Staso, Anthropic,
    OpenAI, stdlib, site-packages) are filtered out; what remains is
    the user's own code.

    Returns an empty tuple if no user frame can be identified (REPL,
    pure-framework stack). In that mode callers fall back to the
    legacy close-on-terminal behaviour.
    """
    try:
        start = sys._getframe(1)
    except ValueError:
        return ()
    return tuple(_walk_non_framework_frames(start))


def _ancestors_still_on_stack(
    stored_path: tuple[_FrameAnchor, ...],
) -> bool:
    """True iff every ancestor in ``stored_path[1:]`` is still present
    on the current non-framework stack.

    The immediate caller (``stored_path[0]``) is intentionally
    excluded from the check — it's expected to differ between sibling
    calls (e.g. first from ``score_candidates``, then from
    ``draft_batch``). What defines "same agent run" is that the
    ancestors (``run_sweep``, its parent, and so on up) are intact.

    An empty or single-element stored path (no ancestors) is treated
    as "intact" — this matches the REPL / top-level-script case where
    there is nothing above the immediate caller worth tracking.
    """
    if len(stored_path) <= 1:
        return True
    try:
        start = sys._getframe(1)
    except ValueError:
        return False
    # Compare by frame-object identity (``is``). A new invocation of
    # the same function — even one that reuses the stored frame's
    # recycled memory address — is a distinct Python object, so the
    # check correctly reports the original frame as gone.
    current_frames = []
    frame = start
    while frame is not None:
        if not _is_framework_frame(frame):
            current_frames.append(frame)
        frame = frame.f_back
    for ancestor in stored_path[1:]:
        if not any(f is ancestor.frame for f in current_frames):
            return False
    return True


def _label_from_anchor_path(
    path: tuple[_FrameAnchor, ...],
) -> str | None:
    """Display name for the synthetic root, derived from the closest
    ancestor of the immediate caller.

    For ``enrich → _chat → messages.create`` the path is
    ``(_chat, enrich, main)``; the closest ancestor is ``enrich``, so
    the trace reads as an enrich run. For
    ``run_sweep → score → messages.create`` it's ``run_sweep``.
    Falls back to ``None`` when there's no ancestor (single-frame
    user code, like a top-level script call); callers then use the
    provider's message-text-based label.
    """
    if len(path) < 2:
        return None
    name = path[1].qualname.strip()
    if not name:
        return None
    return name[:_ROOT_LABEL_MAX_ANCHOR]


# ── Ghost parent (used by tool-result stitching) ────────────────────


class _GhostParent:
    """Span-like stub — only carries ``trace_id`` / ``span_id`` so
    ``Tracer.start_span`` can attach a child. The real prior span has
    already ended and been GC'd by the time we need it."""

    __slots__ = ("trace_id", "span_id", "_recording")

    def __init__(self, trace_id: str, span_id: str) -> None:
        self.trace_id = trace_id
        self.span_id = span_id
        self._recording = True


# ── Synthetic agent-run root ────────────────────────────────────────


def ensure_agent_run(label: str) -> Span | None:
    """Open the synthetic agent-run root if one isn't active, or
    replace a stale one whose anchor frame has returned.

    Called at the start of the FIRST LLM call in a loop (i.e. when
    ``before_llm_call`` didn't find a continuation). Subsequent calls
    see the existing root and reuse it — as long as the anchor frame
    from the original opening is still on the Python stack. If the
    anchor has returned (previous agent run is over) we close the
    stale root before opening a new one for the new caller.

    If the user has already wrapped their entry point with
    ``@st.agent`` or an equivalent AGENT-kind span, that span is
    reused as the root directly — no redundant synthetic AGENT gets
    created underneath it.

    Returns the active root span, or ``None`` when tracing is disabled
    (so the caller can short-circuit).
    """
    existing = _AGENT_RUN_SPAN.get(None)
    if existing is not None and getattr(existing, "_recording", False):
        stored_path = _ANCHOR_PATH.get(())
        if not stored_path or _ancestors_still_on_stack(stored_path):
            # Same agent run — reuse. Empty path means the root was
            # opened from a REPL / notebook where no user frame could
            # be identified; rely on terminal stop / atexit to close.
            return existing
        # Some ancestor of the previous immediate caller has returned
        # — the previous agent run is over. Close the stale root
        # before opening a fresh one for the new caller.
        _end_and_reset(error=None)

    # If the user has wrapped their code with ``@st.agent`` the
    # decorator sets ``agent_name_var`` for the duration of the
    # wrapped function. Respect it — the decorator's AGENT span is
    # already the trace root, any LLM span will naturally parent to
    # whatever the current span is (decorator AGENT, or a nested
    # ``@st.tool``'s TOOL span sitting under it). Don't stack a
    # synthetic AGENT on top.
    if agent_name_var.get(""):
        return None

    # Ditto for callers who opened an AGENT or CHAIN span manually:
    # the current span is already the workflow root. Don't stack a
    # synthetic AGENT on top — it creates an orphaned intermediate node
    # (especially under parallel asyncio tasks where close_agent_run's
    # anchor-frame check no-ops and the task-local ContextVar copy is
    # discarded before the synthetic root can be closed).
    current = get_current_span()
    if (
        current is not None
        and getattr(current, "_recording", False)
        and getattr(current, "kind", None) in (SpanKind.AGENT, SpanKind.CHAIN)
    ):
        return current

    anchor_path = _find_anchor_path()
    root_name = _label_from_anchor_path(anchor_path) or label

    tracer = get_tracer()
    span = tracer.start_span(root_name, kind=SpanKind.AGENT)
    if not getattr(span, "_recording", True):
        return None

    _AGENT_RUN_SPAN.set(span)
    if anchor_path:
        _ANCHOR_PATH.set(anchor_path)
    # Push into the span context so the imminent LLM span becomes a
    # child (inherits trace_id + sets parent_span_id). Keep the token
    # so close_agent_run() can cleanly restore the caller's prior
    # parent instead of leaving our ended root lingering.
    token = set_current_span(span)
    _AGENT_RUN_TOKEN.set(token)
    return span


def close_agent_run(*, terminal: bool, error: BaseException | None = None) -> None:
    """Close the synthetic agent-run root if one is active.

    Called after every LLM call. The decision tree:

    * **Error**: always close. A crashing run should emit its trace.
    * **terminal=False, no error**: no-op. The run isn't over.
    * **terminal=True, anchor frame still on stack**: no-op. The model
      reached a terminal stop but the user's entry-point function is
      still running and may fire more LLM calls that belong in this
      trace (think: for-loop scoring candidates, orchestrator
      dispatching the next tool). Root stays open.
    * **terminal=True, anchor gone (or never captured)**: close. The
      run is over — either because the user's entry frame has
      returned, or because we never found a user frame to anchor to
      (REPL / notebook top-level) and fall back to per-terminal-call
      boundaries.
    """
    if error is not None:
        _end_and_reset(error=error)
        return
    if not terminal:
        return
    stored_path = _ANCHOR_PATH.get(())
    if stored_path and _ancestors_still_on_stack(stored_path):
        # User's entry chain is still running — keep root alive so the
        # next LLM call (sibling in a loop, nested in a tool handler,
        # next turn of the orchestrator) joins the same trace.
        return
    _end_and_reset(error=None)


def force_close_agent_run() -> None:
    """Close any lingering agent-run unconditionally.

    Call from ``client.shutdown()`` (before transport drain) or user
    code that wants to explicitly end the current trace — e.g. between
    discrete workflow phases that should appear as separate traces.
    After this returns the next LLM call opens a fresh agent-run.
    Idempotent: second call is a no-op when there's no active run.
    """
    _end_and_reset(error=None)


def _end_and_reset(*, error: BaseException | None) -> None:
    span = _AGENT_RUN_SPAN.get(None)
    if span is None:
        # No active run; still clear any stale anchor defensively so
        # the next opening starts clean.
        _ANCHOR_PATH.set(())
        return
    try:
        if error is not None:
            span.record_exception(error)
        span.end()
    finally:
        token = _AGENT_RUN_TOKEN.get(None)
        if token is not None:
            try:
                reset_current_span(token)
            except Exception:
                logger.debug(
                    "staso: agent-run context reset failed", exc_info=True
                )
            _AGENT_RUN_TOKEN.set(None)
        _AGENT_RUN_SPAN.set(None)
        _ANCHOR_PATH.set(())


def _force_close_on_exit() -> None:
    """atexit hook — close any lingering agent-run so trace liveness
    doesn't hang indefinitely on unclean shutdowns."""
    try:
        force_close_agent_run()
    except Exception:
        logger.debug("staso: atexit agent-run close failed", exc_info=True)


atexit.register(_force_close_on_exit)


# ── Retroactive tool-span emission ──────────────────────────────────


def _emit_retroactive_tool_span(
    pending: _PendingTool,
    tool_use_id: str,
    end_time: float,
    output_content: Any,
) -> None:
    """Enqueue a completed ``tool:<name>`` span directly onto the
    transport. Start time is in the past (the prior response
    timestamp), so we build the dict by hand rather than going through
    the normal Span lifecycle."""
    client = get_client()
    if not client or not getattr(client, "_transport", None):
        return

    span_id = _hex_to_uuid(format(random.getrandbits(64), "016x"))
    duration_ms = max(0.0, (end_time - pending.start_time) * 1000)
    ts = datetime.fromtimestamp(pending.start_time, tz=timezone.utc).isoformat()

    input_payload = {
        "tool_name": pending.name,
        "tool_input": pending.tool_input,
        "tool_use_id": tool_use_id,
    }
    output_payload: dict[str, Any] = {}
    if output_content is not None:
        output_payload["content"] = output_content

    span_dict: dict[str, Any] = {
        "trace_id": pending.parent_trace_id,
        "span_id": span_id,
        "parent_span_id": pending.parent_span_id,
        "name": f"tool:{pending.name}",
        "kind": SpanKind.TOOL.value,
        "timestamp": ts,
        "duration_ms": round(duration_ms, 2),
        "status": SpanStatus.OK.value,
        "model": "",
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "input": _safe_json(input_payload),
        "output": _safe_json(output_payload) if output_payload else "",
        "attributes": _safe_json({"tool_name": pending.name, "auto_captured": True}),
        "error_message": None,
        "session_id": pending.session_id,
        "agent_name": pending.agent_name,
        "agent_id": pending.agent_id,
        "user_id": pending.user_id,
    }
    client._transport.enqueue(span_dict)


# ── Public state machine API ────────────────────────────────────────


def before_llm_call(tool_results: list[tuple[str, Any]] | None) -> Any:
    """Run before the outbound LLM HTTP request.

    ``tool_results`` is a normalised list of ``(tool_use_id, content)``
    pairs extracted from the call's ``messages[-1]`` by the provider
    wrapper (empty/None if this isn't a continuation).

    For each id we recognise:
      * emit a retroactive ``tool:<name>`` span (real duration)
      * remember the first matching parent ``(trace_id, span_id)`` so
        the imminent LLM span can be stitched under it

    Returns a context token (pass to ``after_llm_call``) when we pushed
    a ghost parent; ``None`` otherwise.
    """
    if not tool_results:
        return None

    now = time.time()
    parent_trace_id: str | None = None
    parent_span_id: str | None = None

    with _LOCK:
        for tool_use_id, result_content in tool_results:
            pending = _PENDING_TOOLS.pop(tool_use_id, None)
            if pending is None:
                continue
            if parent_trace_id is None:
                parent_trace_id = pending.parent_trace_id
                parent_span_id = pending.parent_span_id
            try:
                _emit_retroactive_tool_span(
                    pending, tool_use_id, now, result_content
                )
            except Exception:
                logger.debug(
                    "staso: retroactive tool-span emission failed", exc_info=True
                )

    if parent_trace_id is None or parent_span_id is None:
        return None

    # If there's already an active agent_run, we don't need the ghost —
    # the LLM span will naturally parent under it (same trace_id). But
    # we DO want the LLM span to parent specifically under the prior
    # LLM (so the tree reads: agent_run → LLM1 → tools+LLM2 → …), not
    # directly under agent_run. So we push the ghost regardless.
    ghost = _GhostParent(parent_trace_id, parent_span_id)
    return set_current_span(ghost)


def after_llm_call(ghost_token: Any) -> None:
    """Reset the ghost-parent context pushed by ``before_llm_call``."""
    if ghost_token is None:
        return
    try:
        reset_current_span(ghost_token)
    except Exception:
        logger.debug("staso: ghost-parent reset failed", exc_info=True)


def record_tool_uses(span: Any, tool_uses: list[dict[str, Any]]) -> None:
    """Register every tool invocation from a response so the next call
    can stitch under this span + retro-emit ``tool:<name>`` children.

    ``tool_uses`` is a list of ``{"id", "name", "input"}`` dicts,
    parsed out of the provider's response shape by the caller.
    """
    if not tool_uses:
        return

    trace_id = getattr(span, "trace_id", "") or ""
    parent_span_id = getattr(span, "span_id", "") or ""
    if not trace_id or not parent_span_id:
        return

    agent_name = getattr(span, "agent_name", "") or ""
    agent_id = getattr(span, "agent_id", "") or ""
    session_id = getattr(span, "session_id", "") or ""
    user_id = getattr(span, "user_id", "") or ""

    now = time.time()
    to_register: list[tuple[str, _PendingTool]] = []
    for tu in tool_uses:
        if not isinstance(tu, dict):
            continue
        tool_use_id = tu.get("id")
        if not tool_use_id:
            continue
        name = tu.get("name") or "unknown"
        raw_input = tu.get("input")
        if isinstance(raw_input, dict):
            tool_input: dict[str, Any] = dict(raw_input)
        elif raw_input is None:
            tool_input = {}
        else:
            tool_input = {"value": raw_input}
        to_register.append(
            (
                tool_use_id,
                _PendingTool(
                    name=name,
                    tool_input=tool_input,
                    start_time=now,
                    parent_trace_id=trace_id,
                    parent_span_id=parent_span_id,
                    agent_name=agent_name,
                    agent_id=agent_id,
                    session_id=session_id,
                    user_id=user_id,
                ),
            )
        )

    if not to_register:
        return

    with _LOCK:
        for tool_use_id, pending in to_register:
            _PENDING_TOOLS[tool_use_id] = pending
            _PENDING_TOOLS.move_to_end(tool_use_id)
        while len(_PENDING_TOOLS) > _MAX_ENTRIES:
            _PENDING_TOOLS.popitem(last=False)


def _reset_for_tests() -> None:
    """Wipe state between test cases. Not part of the public API."""
    with _LOCK:
        _PENDING_TOOLS.clear()
    _AGENT_RUN_SPAN.set(None)
    _AGENT_RUN_TOKEN.set(None)
    _ANCHOR_PATH.set(())
