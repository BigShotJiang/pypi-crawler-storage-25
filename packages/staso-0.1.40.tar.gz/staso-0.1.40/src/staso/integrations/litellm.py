"""Zero-code-change instrumentation for the LiteLLM SDK.

Monkey-patches ``litellm.completion`` and ``litellm.acompletion`` — the same
technique used for the OpenAI and Anthropic integrations — so every LLM call
runs inside a Staso span in the *same* coroutine / thread context as the
caller.  This keeps the tool-loop state machine (synthetic agent-run root,
retroactive tool spans, stack-frame anchoring) and guard enforcement fully
intact across multi-turn loops.

Usage::

    import staso as st
    st.init(api_key="...")
    st.integrations.patch_litellm()   # once at startup
"""
from __future__ import annotations

import functools
import json
import logging
from typing import Any

from ..client import get_client, get_tracer
from ..context import reset_current_span, set_current_span
from ..types import (
    META_API_BASE,
    META_EXTRA_BODY,
    META_FREQUENCY_PENALTY,
    META_MAX_TOKENS,
    META_PRESENCE_PENALTY,
    META_PROVIDER,
    META_REASONING_TOKENS,
    META_RESPONSE_FORMAT,
    META_RESPONSE_ID,
    META_SEED,
    META_SERVICE_TIER,
    META_STOP_REASON,
    META_STOP_SEQUENCES,
    META_TEMPERATURE,
    META_TOOL_CHOICE,
    META_TOP_P,
    OPENAI_KEY_CONTENT,
    OPENAI_KEY_MESSAGES,
    OPENAI_KEY_MODEL,
    OPENAI_KEY_ROLE,
    OPENAI_KEY_TOOL_CALLS,
    OPENAI_KEY_TOOLS,
    SpanKind,
    SpanStatus,
)
from ._guard_common import evaluate_and_enforce
from ._tool_loop_state import (
    after_llm_call as _tool_loop_after,
    before_llm_call as _tool_loop_before,
    close_agent_run as _tool_loop_close_run,
    ensure_agent_run as _tool_loop_open_run,
    record_tool_uses as _tool_loop_record,
)

logger = logging.getLogger("staso")

_STASO_PATCH_MARKER = "_staso_patched"
_patched = False

_TERMINAL_FINISH_REASONS = frozenset({"stop", "length", "content_filter", "function_call"})
_TOOL_LIST_MAX = 3
_ROOT_LABEL_MAX = 60


# ── Helpers ───────────────────────────────────────────────────────────────────


def _infer_provider(model: str) -> str:
    """Extract provider from a litellm model string (e.g. 'anthropic/claude-3' → 'anthropic').
    Falls back to keyword heuristics for bare model names."""
    if "/" in model:
        return model.split("/")[0]
    m = model.lower()
    if "claude" in m:
        return "anthropic"
    if any(k in m for k in ("gpt", "o1", "o3", "o4")):
        return "openai"
    if "gemini" in m:
        return "google"
    return "litellm"


def _parse_tool_args(args_raw: Any) -> dict[str, Any]:
    if isinstance(args_raw, str):
        try:
            parsed = json.loads(args_raw)
        except (json.JSONDecodeError, TypeError):
            return {"raw_arguments": args_raw}
        return parsed if isinstance(parsed, dict) else {"value": parsed}
    if isinstance(args_raw, dict):
        return args_raw
    return {}


def _extract_tool_results(messages: Any) -> list[tuple[str, Any]]:
    """Scan from the end of messages for a contiguous tail of role=tool messages
    (OpenAI-format tool-loop continuation signal)."""
    if not isinstance(messages, list) or not messages:
        return []
    out: list[tuple[str, Any]] = []
    for m in reversed(messages):
        if not isinstance(m, dict):
            break
        if m.get("role") != "tool":
            break
        tcid = m.get("tool_call_id")
        if tcid:
            out.append((tcid, m.get("content")))
    out.reverse()
    return out


def _first_user_text(messages: Any) -> str:
    if not isinstance(messages, list):
        return ""
    for m in messages:
        if not isinstance(m, dict) or m.get("role") != "user":
            continue
        content = m.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    t = part.get("text")
                    if isinstance(t, str) and t.strip():
                        return t
        return ""
    return ""


def _derive_root_label(messages: Any, model: str) -> str:
    text = _first_user_text(messages).strip()
    if not text:
        return f"chat: {model}" if model else "litellm.completion"
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("#"):
            label = stripped.lstrip("#").strip()
            if label:
                return label[:_ROOT_LABEL_MAX]
        return stripped[:_ROOT_LABEL_MAX]
    return f"chat: {model}" if model else "litellm.completion"


def _derive_child_label(response: Any) -> str:
    choices = getattr(response, "choices", None) or []
    finish_reason = ""
    tool_names: list[str] = []
    if choices:
        finish_reason = getattr(choices[0], "finish_reason", "") or ""
        msg = getattr(choices[0], "message", None)
        if msg is not None:
            for tc in getattr(msg, "tool_calls", None) or []:
                fn = getattr(tc, "function", None)
                name = getattr(fn, "name", None) if fn is not None else None
                tool_names.append(str(name) if name else "?")

    if finish_reason == "tool_calls" and tool_names:
        shown = tool_names[:_TOOL_LIST_MAX]
        extra = len(tool_names) - len(shown)
        suffix = f", …+{extra}" if extra > 0 else ""
        return f"chat:tool_calls({', '.join(shown)}{suffix})"
    if finish_reason in _TERMINAL_FINISH_REASONS:
        return "chat:reply"
    if finish_reason:
        return f"chat:{finish_reason}"
    return "chat"


def _capture_input(model: str, kwargs: dict) -> dict[str, Any]:
    inp: dict[str, Any] = {OPENAI_KEY_MODEL: model}
    tools = kwargs.get("tools")
    if tools:
        inp[OPENAI_KEY_TOOLS] = tools
    client = get_client()
    if client and client.config.capture_messages:
        messages = kwargs.get("messages")
        if messages:
            inp[OPENAI_KEY_MESSAGES] = messages
    return inp


def _capture_metadata(model: str, kwargs: dict) -> dict[str, Any]:
    provider = _infer_provider(model)
    meta: dict[str, Any] = {META_PROVIDER: provider}
    # ``extra_headers`` is deliberately excluded — Authorization / x-api-key /
    # anthropic-api-key / api-key (Azure) routinely flow through there, and
    # the backend redaction pass keys on payload shape (messages / attributes),
    # not arbitrary header maps. Safe capture needs a header-name allowlist;
    # until then we don't touch it.
    _optional_keys = [
        ("temperature", META_TEMPERATURE),
        ("max_tokens", META_MAX_TOKENS),
        ("max_completion_tokens", META_MAX_TOKENS),
        ("top_p", META_TOP_P),
        ("frequency_penalty", META_FREQUENCY_PENALTY),
        ("presence_penalty", META_PRESENCE_PENALTY),
        ("seed", META_SEED),
        ("stop", META_STOP_SEQUENCES),
        ("tool_choice", META_TOOL_CHOICE),
        ("response_format", META_RESPONSE_FORMAT),
        ("service_tier", META_SERVICE_TIER),
        ("extra_body", META_EXTRA_BODY),
        ("api_base", META_API_BASE),
    ]
    for kwarg_key, meta_key in _optional_keys:
        val = kwargs.get(kwarg_key)
        if val is not None:
            meta[meta_key] = val
    return meta


def _build_tool_call_refs(
    response: Any,
    tc_list: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Zip serialised tool-call dicts with their live objects so the guard
    helper can both read names/inputs and mutate args in-place on modify.

    Tool calls missing ``id`` or ``function.name`` are dropped here for the
    same reason ``_extract_response_tool_calls`` drops them: without an id
    the tool-loop state machine can't register the call (see
    ``record_tool_uses``'s ``if not tool_use_id: continue`` guard), and
    without a name the guard evaluation is meaningless. Keeping the two
    paths aligned prevents the subtle drift where the guard fires on a
    call that stitching later can't account for.
    """
    live: list[Any] = []
    choices = getattr(response, "choices", None) or []
    if choices:
        msg = getattr(choices[0], "message", None)
        if msg is not None:
            live = list(getattr(msg, "tool_calls", None) or [])
    refs: list[dict[str, Any]] = []
    for idx, tc_dict in enumerate(tc_list):
        if not isinstance(tc_dict, dict):
            continue
        tc_id = tc_dict.get("id")
        func = tc_dict.get("function") or {}
        name = func.get("name")
        if not tc_id or not name:
            continue
        inp = _parse_tool_args(func.get("arguments", "{}"))
        ref = live[idx] if idx < len(live) else None
        refs.append({"name": name, "input": inp, "ref": ref})
    return refs


def _apply_litellm_modify(ref: Any, modified_input: dict[str, Any]) -> None:
    """Rewrite the live LiteLLM tool_call arguments in-place so the caller's
    agent loop dispatches the modified arguments."""
    if ref is None:
        return
    try:
        ref.function.arguments = json.dumps(modified_input)
    except Exception:
        logger.debug("staso: litellm tool_call mutation failed", exc_info=True)


def _extract_response_tool_calls(response: Any) -> list[dict[str, Any]]:
    """Normalise response.choices[0].message.tool_calls → {"id","name","input"} list."""
    out: list[dict[str, Any]] = []
    choices = getattr(response, "choices", None) or []
    if not choices:
        return out
    msg = getattr(choices[0], "message", None)
    if msg is None:
        return out
    for tc in getattr(msg, "tool_calls", None) or []:
        tc_id = getattr(tc, "id", None)
        fn = getattr(tc, "function", None)
        name = getattr(fn, "name", None) if fn is not None else None
        raw_args = getattr(fn, "arguments", None) if fn is not None else None
        if not tc_id or not name:
            continue
        out.append({"id": tc_id, "name": name, "input": _parse_tool_args(raw_args)})
    return out


def _capture_response(span: Any, response: Any) -> None:
    """Write response content, tokens, and tool calls onto the span."""
    tc_list: list[Any] = []
    choices = getattr(response, "choices", None)
    if choices and len(choices) > 0:
        message = getattr(choices[0], "message", None)
        if message:
            content = getattr(message, "content", None) or ""
            role = getattr(message, "role", "assistant")
            live_tool_calls = getattr(message, "tool_calls", None)

            output: dict[str, Any] = {OPENAI_KEY_CONTENT: content, OPENAI_KEY_ROLE: role}
            if live_tool_calls:
                for tc in live_tool_calls:
                    if hasattr(tc, "model_dump"):
                        tc_list.append(tc.model_dump())
                    elif isinstance(tc, dict):
                        tc_list.append(tc)
                    else:
                        tc_list.append(str(tc))
                output[OPENAI_KEY_TOOL_CALLS] = tc_list
            span.output = output

        finish_reason = getattr(choices[0], "finish_reason", None)
        if finish_reason:
            span.metadata[META_STOP_REASON] = finish_reason

    response_id = getattr(response, "id", None)
    if response_id:
        span.metadata[META_RESPONSE_ID] = response_id

    usage = getattr(response, "usage", None)
    if usage:
        span.input_tokens = getattr(usage, "prompt_tokens", 0) or 0
        span.output_tokens = getattr(usage, "completion_tokens", 0) or 0
        span.total_tokens = getattr(usage, "total_tokens", 0) or 0
        details = getattr(usage, "completion_tokens_details", None)
        if details:
            reasoning = getattr(details, "reasoning_tokens", None)
            if reasoning:
                span.metadata[META_REASONING_TOKENS] = reasoning

    # Guard enforcement first — raises GuardBlocked on enforce-mode blocks before
    # tool calls are registered, so blocked calls never become orphaned pending spans.
    if tc_list:
        refs = _build_tool_call_refs(response, tc_list)
        evaluate_and_enforce(refs, span, apply_modify=_apply_litellm_modify)

    # Register tool calls so the next continuation can emit retroactive tool spans.
    # Called after guard enforcement: if GuardBlocked was raised above, registration
    # is skipped and no orphaned <1ms ghost spans appear at the trace root.
    _tool_loop_record(span, _extract_response_tool_calls(response))


# ── Wrappers ──────────────────────────────────────────────────────────────────


def _wrap_sync(original: Any) -> Any:
    if getattr(original, _STASO_PATCH_MARKER, False):
        return original

    @functools.wraps(original)
    def _traced(*args: Any, **kwargs: Any) -> Any:
        if kwargs.get("stream"):
            return original(*args, **kwargs)

        tracer = get_tracer()
        model = str(kwargs.get("model", args[0] if args else ""))
        messages = kwargs.get("messages")

        tool_results = _extract_tool_results(messages)
        ghost_token = _tool_loop_before(tool_results)
        if ghost_token is None:
            _tool_loop_open_run(_derive_root_label(messages, model))

        terminal = False
        errored: BaseException | None = None
        try:
            with tracer.start_as_current_span("chat", kind=SpanKind.LLM) as span:
                span.model = model
                span.input = _capture_input(model, kwargs)
                span.metadata.update(_capture_metadata(model, kwargs))
                try:
                    response = original(*args, **kwargs)
                    _capture_response(span, response)
                    span.name = _derive_child_label(response)
                    choices = getattr(response, "choices", None) or []
                    finish_reason = (
                        getattr(choices[0], "finish_reason", "") or "" if choices else ""
                    )
                    terminal = finish_reason in _TERMINAL_FINISH_REASONS
                    span.status = SpanStatus.OK
                    return response
                except BaseException as exc:
                    errored = exc
                    span.record_exception(exc)
                    raise
        finally:
            _tool_loop_after(ghost_token)
            _tool_loop_close_run(terminal=terminal, error=errored)

    setattr(_traced, _STASO_PATCH_MARKER, True)
    _traced._staso_original = original  # type: ignore[attr-defined]
    return _traced


def _wrap_async(original: Any) -> Any:
    if getattr(original, _STASO_PATCH_MARKER, False):
        return original

    @functools.wraps(original)
    async def _traced(*args: Any, **kwargs: Any) -> Any:
        if kwargs.get("stream"):
            return await original(*args, **kwargs)

        tracer = get_tracer()
        model = str(kwargs.get("model", args[0] if args else ""))
        messages = kwargs.get("messages")

        tool_results = _extract_tool_results(messages)
        ghost_token = _tool_loop_before(tool_results)
        if ghost_token is None:
            _tool_loop_open_run(_derive_root_label(messages, model))

        terminal = False
        errored: BaseException | None = None
        try:
            with tracer.start_as_current_span("chat", kind=SpanKind.LLM) as span:
                span.model = model
                span.input = _capture_input(model, kwargs)
                span.metadata.update(_capture_metadata(model, kwargs))
                try:
                    response = await original(*args, **kwargs)
                    _capture_response(span, response)
                    span.name = _derive_child_label(response)
                    choices = getattr(response, "choices", None) or []
                    finish_reason = (
                        getattr(choices[0], "finish_reason", "") or "" if choices else ""
                    )
                    terminal = finish_reason in _TERMINAL_FINISH_REASONS
                    span.status = SpanStatus.OK
                    return response
                except BaseException as exc:
                    errored = exc
                    span.record_exception(exc)
                    raise
        finally:
            _tool_loop_after(ghost_token)
            _tool_loop_close_run(terminal=terminal, error=errored)

    setattr(_traced, _STASO_PATCH_MARKER, True)
    _traced._staso_original = original  # type: ignore[attr-defined]
    return _traced


# ── Public API ────────────────────────────────────────────────────────────────


def patch_litellm() -> None:
    """Monkey-patch ``litellm.completion`` and ``litellm.acompletion`` to
    automatically emit Staso LLM spans with full tool-loop stitching.

    Follows the same wrapping pattern as ``patch_openai`` / ``patch_anthropic``:
    the span context manager runs in the caller's thread / asyncio Task, so the
    synthetic agent-run root and retroactive tool spans work identically to the
    first-party SDK integrations.

    Safe to call multiple times — patches only once.
    """
    global _patched
    if _patched:
        return

    try:
        import litellm
    except ImportError:
        raise ImportError(
            "litellm package is required for this integration. "
            "Install it with: pip install 'staso[litellm]'"
        )

    litellm.completion = _wrap_sync(litellm.completion)
    litellm.acompletion = _wrap_async(litellm.acompletion)

    _patched = True
    logger.debug("staso: litellm SDK patched")
