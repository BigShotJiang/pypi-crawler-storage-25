"""Root conftest – exclude integration tests from default collection.

Integration tests live under tests/integration-tests/ and require live API
keys + a running Staso backend.  Run them explicitly:

    pytest tests/integration-tests/ -m integration
"""
import os

collect_ignore_glob = [os.path.join("tests", "integration-tests", "*")]
