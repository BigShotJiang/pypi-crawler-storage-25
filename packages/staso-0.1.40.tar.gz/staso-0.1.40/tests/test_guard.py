"""Unit tests for staso.guard — the public guard() call + helpers.

All HTTP is mocked — we never talk to api.staso.ai.
"""
from __future__ import annotations

from unittest.mock import patch

import pytest

from staso.client import Client, _set_client
from staso.config import Config
from staso.guard import (
    GuardBlocked,
    _parse_response,
    _poll_escalation,
    guard,
)
from staso.guard_types import GuardResult, GuardRuleResult


def _mk_client(*, enabled: bool = True, api_key: str = "test-key") -> Client:
    cfg = Config(
        api_key=api_key,
        agent_name="test-agent",
        enabled=enabled,
        base_url="https://api.test.staso.ai/",
    )
    client = Client.__new__(Client)
    client._config = cfg
    client._transport = None
    client._provider = None
    return client


@pytest.fixture
def guard_client():
    client = _mk_client(enabled=True)
    _set_client(client)
    yield client
    _set_client(None)  # type: ignore[arg-type]


class TestGuardTypes:
    def test_guard_result_defaults(self):
        r = GuardResult(action="allow")
        assert r.action == "allow"
        assert r.reason == ""
        assert r.severity == "low"
        assert r.results == []
        assert r.modified_input is None
        assert r.rules_triggered == []

    def test_guard_rule_result_defaults(self):
        rr = GuardRuleResult()
        assert rr.passed is True
        assert rr.action == "audit"
        assert rr.violations == []

    def test_guard_result_is_frozen(self):
        r = GuardResult(action="allow")
        with pytest.raises((AttributeError, Exception)):
            r.action = "block"  # type: ignore[misc]


class TestGuardBlockedException:
    def test_attributes_populated_from_result(self):
        result = GuardResult(
            action="block",
            reason="unsafe command",
            rules_triggered=["dangerous_bash"],
        )
        err = GuardBlocked(tool_name="Bash", result=result)
        assert err.tool_name == "Bash"
        assert err.reason == "unsafe command"
        assert err.rules_triggered == ["dangerous_bash"]
        assert "Bash" in str(err)
        assert "unsafe command" in str(err)

    def test_default_reason_when_result_reason_empty(self):
        result = GuardResult(action="block")
        err = GuardBlocked(tool_name="Delete", result=result)
        assert "Guard policy blocked" in err.reason

    def test_is_exception_subclass(self):
        err = GuardBlocked("X", GuardResult(action="block"))
        assert isinstance(err, Exception)


class TestParseResponse:
    def test_parses_allow_response(self):
        data = {"action": "allow", "reason": "", "results": []}
        result = _parse_response(data, latency_ms=12.0)
        assert result.action == "allow"
        assert result.latency_ms == 12.0
        assert result.rules_triggered == []

    def test_parses_block_with_rule_results(self):
        data = {
            "action": "block",
            "reason": "unsafe",
            "severity": "high",
            "results": [
                {
                    "rule_id": "r1",
                    "rule_name": "no_rm_rf",
                    "action": "block",
                    "reason": "destructive",
                    "score": 0.9,
                    "latency_ms": 5.0,
                }
            ],
        }
        result = _parse_response(data, latency_ms=50.0)
        assert result.action == "block"
        assert result.severity == "high"
        assert len(result.results) == 1
        assert result.results[0].rule_name == "no_rm_rf"
        assert result.results[0].passed is False
        assert result.rule_name == "no_rm_rf"
        assert result.rules_triggered == ["no_rm_rf"]

    def test_derives_rules_triggered_from_failed_results(self):
        data = {
            "action": "block",
            "results": [
                {"rule_name": "r1", "action": "block"},
                {"rule_name": "r2", "action": "allow"},
            ],
        }
        result = _parse_response(data, latency_ms=1.0)
        assert result.rules_triggered == ["r1"]

    def test_uses_explicit_rules_triggered_when_given(self):
        data = {
            "action": "block",
            "rules_triggered": ["explicit"],
            "results": [],
        }
        result = _parse_response(data, latency_ms=1.0)
        assert result.rules_triggered == ["explicit"]

    def test_modify_response_carries_modified_input(self):
        data = {
            "action": "modify",
            "modified_input": {"safe": True},
            "modifications": [{"path": "x", "action": "set"}],
        }
        result = _parse_response(data, latency_ms=1.0)
        assert result.action == "modify"
        assert result.modified_input == {"safe": True}
        assert len(result.modifications) == 1

    def test_escalate_response_carries_escalation_id(self):
        data = {"action": "escalate", "escalation_id": "esc-42"}
        result = _parse_response(data, latency_ms=1.0)
        assert result.escalation_id == "esc-42"

    def test_per_rule_severity_is_preserved(self):
        """Regression: GuardRuleResult dropped the per-rule severity field,
        so audit-mode spans always reported severity='medium'."""
        data = {
            "action": "allow",
            "results": [
                {
                    "rule_id": "r1",
                    "rule_name": "pii_scan",
                    "action": "audit",
                    "severity": "critical",
                    "reason": "SSN leaked",
                }
            ],
        }
        result = _parse_response(data, latency_ms=1.0)
        assert result.results[0].severity == "critical"


class TestGuardCall:
    def test_allow_returns_guard_result(self, guard_client):
        fake = {"action": "allow", "reason": "all good"}
        with patch("staso.guard._post", return_value=fake):
            r = guard("Read", {"file_path": "/tmp/x"})
        assert r.action == "allow"
        assert r.reason == "all good"

    def test_payload_includes_tool_name_and_input(self, guard_client):
        captured: dict = {}

        def fake_post(url, api_key, payload, timeout):
            captured.update(url=url, api_key=api_key, payload=payload, timeout=timeout)
            return {"action": "allow"}

        with patch("staso.guard._post", side_effect=fake_post):
            guard("Bash", {"command": "ls"})

        assert captured["payload"]["tool_name"] == "Bash"
        assert captured["payload"]["tool_input"] == {"command": "ls"}
        assert captured["url"].endswith("/v1/guard/evaluate")
        assert captured["api_key"] == "test-key"

    def test_context_merges_with_defaults(self, guard_client):
        captured: dict = {}

        def fake_post(url, api_key, payload, timeout):
            captured.update(payload=payload)
            return {"action": "allow"}

        with patch("staso.guard._post", side_effect=fake_post):
            guard("Bash", {"cmd": "x"}, context={"trace_id": "trace-9"})

        ctx = captured["payload"]["context"]
        assert ctx["trace_id"] == "trace-9"
        assert ctx["agent_name"] == "test-agent"
        assert ctx["environment"] == "default"

    def test_user_context_overrides_default_fields(self, guard_client):
        captured: dict = {}

        def fake_post(url, api_key, payload, timeout):
            captured.update(payload=payload)
            return {"action": "allow"}

        with patch("staso.guard._post", side_effect=fake_post):
            guard("X", {}, context={"agent_name": "override"})

        assert captured["payload"]["context"]["agent_name"] == "override"

    def test_network_failure_is_failopen(self, guard_client):
        with patch("staso.guard._post", side_effect=RuntimeError("boom")):
            r = guard("Read", {})
        assert r.action == "allow"
        assert "failed" in r.reason.lower()

    def test_network_failure_fail_closed_per_call(self, guard_client):
        with patch("staso.guard._post", side_effect=RuntimeError("boom")):
            r = guard("Read", {}, fail_closed=True)
        assert r.action == "block"
        assert "unavailable" in r.reason.lower()
        assert r.severity == "high"

    def test_network_failure_fail_closed_via_env(self, guard_client, monkeypatch):
        monkeypatch.setenv("STASO_GUARD_FAIL_CLOSED", "true")
        with patch("staso.guard._post", side_effect=RuntimeError("boom")):
            r = guard("Read", {})
        assert r.action == "block"

    def test_fail_closed_default_is_false(self, guard_client, monkeypatch):
        monkeypatch.delenv("STASO_GUARD_FAIL_CLOSED", raising=False)
        with patch("staso.guard._post", side_effect=RuntimeError("boom")):
            r = guard("Read", {})
        assert r.action == "allow"

    def test_env_fallback_no_client(self, monkeypatch):
        _set_client(None)  # type: ignore[arg-type]
        monkeypatch.setenv("STASO_API_KEY", "env-key")
        monkeypatch.setenv("STASO_BASE_URL", "https://api.staging.staso.ai/")
        monkeypatch.setenv("STASO_AGENT_NAME", "env-agent")
        monkeypatch.setenv("STASO_ENVIRONMENT", "staging")

        captured: dict = {}

        def fake_post(url, api_key, payload, timeout):
            captured.update(url=url, api_key=api_key, payload=payload)
            return {"action": "allow"}

        with patch("staso.guard._post", side_effect=fake_post):
            guard("Bash", {"cmd": "ls"})

        assert captured["api_key"] == "env-key"
        assert captured["url"].startswith("https://api.staging.staso.ai")
        assert captured["payload"]["context"]["environment"] == "staging"
        assert captured["payload"]["context"]["agent_name"] == "env-agent"
        # env fallback derives agent_id from agent_name
        assert captured["payload"]["context"]["agent_id"]

    def test_env_fallback_missing_api_key_returns_allow(self, monkeypatch):
        _set_client(None)  # type: ignore[arg-type]
        monkeypatch.delenv("STASO_API_KEY", raising=False)
        r = guard("X", {})
        assert r.action == "allow"
        assert "not initialized" in r.reason.lower()

    def test_disabled_client_falls_back_to_env(self, monkeypatch):
        client = _mk_client(enabled=False)
        _set_client(client)
        monkeypatch.setenv("STASO_API_KEY", "env-key-2")

        captured: dict = {}

        def fake_post(url, api_key, payload, timeout):
            captured.update(api_key=api_key)
            return {"action": "allow"}

        with patch("staso.guard._post", side_effect=fake_post):
            guard("X", {})

        assert captured["api_key"] == "env-key-2"
        _set_client(None)  # type: ignore[arg-type]

    def test_block_response_returns_block_action(self, guard_client):
        fake = {"action": "block", "reason": "blocked"}
        with patch("staso.guard._post", return_value=fake):
            r = guard("Bash", {})
        assert r.action == "block"

    def test_modify_response_returns_modified_input(self, guard_client):
        fake = {
            "action": "modify",
            "modified_input": {"cmd": "ls"},
            "modifications": [{"path": "cmd", "value": "ls"}],
        }
        with patch("staso.guard._post", return_value=fake):
            r = guard("Bash", {"cmd": "rm -rf /"})
        assert r.action == "modify"
        assert r.modified_input == {"cmd": "ls"}

    def test_escalate_without_wait_returns_immediately(self, guard_client):
        fake = {"action": "escalate", "escalation_id": "esc-1"}
        with patch("staso.guard._post", return_value=fake):
            r = guard("Transfer", {"amount": 10000})
        assert r.action == "escalate"
        assert r.escalation_id == "esc-1"

    def test_escalate_with_wait_polls_until_approved(self, guard_client):
        eval_resp = {"action": "escalate", "escalation_id": "esc-9"}
        with patch("staso.guard._post", return_value=eval_resp), \
             patch("staso.guard._get", return_value={"status": "approved"}):
            r = guard("Transfer", {}, wait_for_escalation=True)
        assert r.action == "allow"
        assert "approved" in r.reason.lower()
        assert r.escalation_id == "esc-9"

    def test_escalate_with_wait_polls_until_denied(self, guard_client):
        eval_resp = {"action": "escalate", "escalation_id": "esc-10"}
        with patch("staso.guard._post", return_value=eval_resp), \
             patch("staso.guard._get", return_value={"status": "denied"}):
            r = guard("Transfer", {}, wait_for_escalation=True)
        assert r.action == "block"
        assert "denied" in r.reason.lower()

    def test_escalate_with_wait_works_via_env_var_fallback(self, monkeypatch):
        """Regression: `config.api_key` was referenced in the env-var fallback
        path, where `config` is unbound — calling with wait_for_escalation=True
        via env-var fallback used to crash with UnboundLocalError."""
        _set_client(None)  # type: ignore[arg-type]
        monkeypatch.setenv("STASO_API_KEY", "env-fallback-key")
        captured_get_api_key: list[str] = []

        def fake_get(url, api_key, timeout):
            captured_get_api_key.append(api_key)
            return {"status": "approved"}

        with patch(
            "staso.guard._post",
            return_value={"action": "escalate", "escalation_id": "esc-fb"},
        ), patch("staso.guard._get", side_effect=fake_get):
            r = guard("Transfer", {}, wait_for_escalation=True)

        assert r.action == "allow"
        assert captured_get_api_key == ["env-fallback-key"]


class TestPollEscalation:
    def test_returns_approved(self):
        with patch("staso.guard._get", return_value={"status": "approved"}):
            r = _poll_escalation(
                base_url="https://api.test",
                api_key="k",
                escalation_id="e",
                poll_interval=0.01,
                timeout=1.0,
                original_result=GuardResult(action="escalate"),
            )
        assert r.action == "allow"

    def test_returns_denied(self):
        with patch("staso.guard._get", return_value={"status": "denied"}):
            r = _poll_escalation(
                base_url="https://api.test",
                api_key="k",
                escalation_id="e",
                poll_interval=0.01,
                timeout=1.0,
                original_result=GuardResult(action="escalate"),
            )
        assert r.action == "block"

    def test_returns_timeout_status_as_block(self):
        with patch("staso.guard._get", return_value={"status": "timeout"}):
            r = _poll_escalation(
                base_url="https://api.test",
                api_key="k",
                escalation_id="e",
                poll_interval=0.01,
                timeout=1.0,
                original_result=GuardResult(action="escalate"),
            )
        assert r.action == "block"

    def test_timeout_after_polling_returns_block(self):
        with patch("staso.guard._get", return_value={"status": "pending"}):
            r = _poll_escalation(
                base_url="https://api.test",
                api_key="k",
                escalation_id="e",
                poll_interval=0.005,
                timeout=0.02,
                original_result=GuardResult(action="escalate"),
            )
        assert r.action == "block"
        assert "timeout" in r.reason.lower()

    def test_poll_http_error_falls_through_to_timeout(self):
        with patch("staso.guard._get", side_effect=RuntimeError("boom")):
            r = _poll_escalation(
                base_url="https://api.test",
                api_key="k",
                escalation_id="e",
                poll_interval=0.005,
                timeout=0.02,
                original_result=GuardResult(action="escalate"),
            )
        assert r.action == "block"
