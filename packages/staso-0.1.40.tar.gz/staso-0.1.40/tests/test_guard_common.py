"""Unit tests for staso.integrations._guard_common — evaluate_and_enforce + try_guard."""
from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import patch

import pytest

from staso.guard import BlockedTool, GuardBlocked
from staso.guard_types import GuardResult, GuardRuleResult
from staso.integrations._guard_common import (
    evaluate_and_enforce,
    guard_enabled,
    try_guard,
)


class TestGuardEnabled:
    def test_default_is_enabled(self, monkeypatch):
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        assert guard_enabled() is True

    def test_false_string_disables(self, monkeypatch):
        monkeypatch.setenv("STASO_GUARD_ENABLED", "false")
        assert guard_enabled() is False

    def test_capitalized_false_also_disables(self, monkeypatch):
        monkeypatch.setenv("STASO_GUARD_ENABLED", "FALSE")
        assert guard_enabled() is False

    def test_any_other_value_enables(self, monkeypatch):
        monkeypatch.setenv("STASO_GUARD_ENABLED", "true")
        assert guard_enabled() is True


class TestTryGuard:
    def test_returns_result_on_success(self, capturing):
        fake = GuardResult(action="allow", reason="ok")
        with patch("staso.guard.guard", return_value=fake):
            result = try_guard("Bash", {"cmd": "ls"})
        assert result is not None
        assert result.action == "allow"

    def test_returns_none_on_exception(self, capturing):
        with patch("staso.guard.guard", side_effect=RuntimeError("network")):
            result = try_guard("Bash", {})
        assert result is None

    def test_passes_context_from_span(self, capturing):
        fake = GuardResult(action="allow")
        captured: dict = {}

        def fake_guard(**kwargs):
            captured.update(kwargs)
            return fake

        # Seed session_id context
        from staso.context import session_id_var
        session_id_var.set("sess-42")

        try:
            with patch("staso.guard.guard", side_effect=fake_guard):
                try_guard("Read", {"file": "/tmp/x"})
        finally:
            session_id_var.set("")

        assert captured["tool_name"] == "Read"
        assert captured["tool_input"] == {"file": "/tmp/x"}
        assert captured["context"]["session_id"] == "sess-42"


def _mk_span():
    """Minimal span stub with the attributes evaluate_and_enforce touches."""
    span = SimpleNamespace()
    span.metadata = {}
    span.status = None
    span.error_message = None
    return span


class TestEvaluateAndEnforceDisabled:
    def test_early_return_when_disabled(self, monkeypatch):
        monkeypatch.setenv("STASO_GUARD_ENABLED", "false")
        span = _mk_span()
        # Must not raise, not touch anything
        evaluate_and_enforce(
            [{"name": "Bash", "input": {"cmd": "x"}, "ref": None}],
            span,
        )
        assert "guard_evaluations" not in span.metadata

    def test_early_return_on_empty_tool_calls(self):
        span = _mk_span()
        evaluate_and_enforce([], span)
        assert "guard_evaluations" not in span.metadata


class TestEvaluateAndEnforceAllow:
    def test_allow_does_not_raise(self, monkeypatch):
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        span = _mk_span()
        fake = GuardResult(action="allow", reason="ok")
        with patch(
            "staso.integrations._guard_common.try_guard", return_value=fake
        ):
            evaluate_and_enforce(
                [{"name": "Read", "input": {"file": "/tmp/a"}, "ref": None}],
                span,
            )
        assert span.metadata["guard_evaluations"][0]["action"] == "allow"
        assert span.status is None

    def test_allow_with_audit_fires_would_block_span(self, monkeypatch):
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        span = _mk_span()
        audit = GuardRuleResult(
            rule_name="pii_audit", passed=False, action="audit", reason="PII leak"
        )
        fake = GuardResult(action="allow", results=[audit])
        tracer = SimpleNamespace()
        child = _mk_span()
        child.metadata = {}
        child.end = lambda: None
        tracer.start_span = lambda name, kind=None: child

        with patch(
            "staso.integrations._guard_common.try_guard", return_value=fake
        ), patch(
            "staso.integrations._guard_common.get_tracer", return_value=tracer
        ):
            evaluate_and_enforce(
                [{"name": "Read", "input": {"file": "/x"}, "ref": None}],
                span,
            )

        assert child.metadata["guard_action"] == "would_block"


class TestEvaluateAndEnforceBlock:
    def test_block_raises_guard_blocked(self, monkeypatch):
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        span = _mk_span()
        fake = GuardResult(
            action="block",
            reason="too dangerous",
            rules_triggered=["dangerous_bash"],
        )
        with patch(
            "staso.integrations._guard_common.try_guard", return_value=fake
        ):
            with pytest.raises(GuardBlocked) as exc_info:
                evaluate_and_enforce(
                    [{"name": "Bash", "input": {"cmd": "rm -rf /"}, "ref": None}],
                    span,
                )

        assert exc_info.value.tool_name == "Bash"
        assert "too dangerous" in exc_info.value.reason

    def test_block_sets_parent_span_error(self, monkeypatch):
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        span = _mk_span()
        fake = GuardResult(action="block", reason="nope")
        with patch(
            "staso.integrations._guard_common.try_guard", return_value=fake
        ), pytest.raises(GuardBlocked):
            evaluate_and_enforce(
                [{"name": "X", "input": {}, "ref": None}], span
            )

        from staso.types import SpanStatus
        assert span.status == SpanStatus.ERROR
        assert span.error_message and "nope" in span.error_message

    def test_escalate_also_raises(self, monkeypatch):
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        span = _mk_span()
        fake = GuardResult(action="escalate", reason="human review")
        with patch(
            "staso.integrations._guard_common.try_guard", return_value=fake
        ):
            with pytest.raises(GuardBlocked):
                evaluate_and_enforce(
                    [{"name": "Transfer", "input": {}, "ref": None}],
                    span,
                )


class TestEvaluateAndEnforceModify:
    def test_modify_applies_callback(self, monkeypatch):
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        span = _mk_span()
        ref = {"args": "original"}
        modified = {"cmd": "ls -la"}
        fake = GuardResult(action="modify", modified_input=modified)

        applied: list = []

        def callback(r, mi):
            applied.append((r, mi))

        with patch(
            "staso.integrations._guard_common.try_guard", return_value=fake
        ):
            evaluate_and_enforce(
                [{"name": "Bash", "input": {"cmd": "rm -rf /"}, "ref": ref}],
                span,
                apply_modify=callback,
            )

        assert len(applied) == 1
        assert applied[0][0] is ref
        assert applied[0][1] == modified

    def test_modify_skipped_when_no_ref(self, monkeypatch):
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        span = _mk_span()
        fake = GuardResult(action="modify", modified_input={"safe": True})

        called = []

        def callback(r, mi):
            called.append(True)

        with patch(
            "staso.integrations._guard_common.try_guard", return_value=fake
        ):
            evaluate_and_enforce(
                [{"name": "Bash", "input": {}, "ref": None}],
                span,
                apply_modify=callback,
            )
        assert called == []

    def test_modify_callback_exception_is_swallowed(self, monkeypatch):
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        span = _mk_span()
        fake = GuardResult(action="modify", modified_input={"x": 1})

        def bad(ref, mi):
            raise RuntimeError("oops")

        with patch(
            "staso.integrations._guard_common.try_guard", return_value=fake
        ):
            # Must not propagate
            evaluate_and_enforce(
                [{"name": "Bash", "input": {}, "ref": object()}],
                span,
                apply_modify=bad,
            )


class TestGuardBlockedAggregation:
    """Fix 2: GuardBlocked now carries every blocked tool in the batch."""

    def test_single_block_has_one_entry_in_blocked_tools(self, monkeypatch):
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        span = _mk_span()
        with patch(
            "staso.integrations._guard_common.try_guard",
            return_value=GuardResult(
                action="block",
                reason="nope",
                rules_triggered=["r1"],
            ),
        ):
            with pytest.raises(GuardBlocked) as exc_info:
                evaluate_and_enforce(
                    [{"name": "Bash", "input": {}, "ref": None}], span
                )

        err = exc_info.value
        assert len(err.blocked_tools) == 1
        assert err.blocked_tools[0].tool_name == "Bash"
        assert err.blocked_tools[0].result.reason == "nope"
        assert err.rules_triggered == ["r1"]

    def test_multi_block_captures_every_tool(self, monkeypatch):
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        span = _mk_span()

        results_iter = iter(
            [
                GuardResult(
                    action="block",
                    reason="dangerous A",
                    rules_triggered=["rule_a"],
                ),
                GuardResult(action="allow"),
                GuardResult(
                    action="block",
                    reason="dangerous B",
                    rules_triggered=["rule_b"],
                ),
            ]
        )

        def fake_try(name, inp):
            return next(results_iter)

        with patch(
            "staso.integrations._guard_common.try_guard", side_effect=fake_try
        ):
            with pytest.raises(GuardBlocked) as exc_info:
                evaluate_and_enforce(
                    [
                        {"name": "delete_all", "input": {}, "ref": None},
                        {"name": "safe_read", "input": {}, "ref": None},
                        {"name": "wire_funds", "input": {}, "ref": None},
                    ],
                    span,
                )

        err = exc_info.value
        assert len(err.blocked_tools) == 2
        assert [bt.tool_name for bt in err.blocked_tools] == [
            "delete_all",
            "wire_funds",
        ]
        assert err.rules_triggered == ["rule_a", "rule_b"]
        # Aggregated exception message mentions count + tool names + reasons
        msg = str(err)
        assert "2 tools" in msg
        assert "delete_all" in msg
        assert "wire_funds" in msg
        assert "dangerous A" in msg
        assert "dangerous B" in msg
        # Backwards-compatible `tool_name` / `result` still point at first
        assert err.tool_name == "delete_all"
        assert err.result.reason == "dangerous A"

    def test_parent_span_metadata_carries_blocked_list(self, monkeypatch):
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        span = _mk_span()

        with patch(
            "staso.integrations._guard_common.try_guard",
            side_effect=[
                GuardResult(
                    action="block",
                    reason="A",
                    rules_triggered=["ra"],
                    severity="high",
                ),
                GuardResult(
                    action="block",
                    reason="B",
                    rules_triggered=["rb"],
                    severity="critical",
                ),
            ],
        ):
            with pytest.raises(GuardBlocked):
                evaluate_and_enforce(
                    [
                        {"name": "tool_a", "input": {}, "ref": None},
                        {"name": "tool_b", "input": {}, "ref": None},
                    ],
                    span,
                )

        blocked_meta = span.metadata["guard_blocked_tools"]
        assert span.metadata["guard_blocked_count"] == 2
        assert len(blocked_meta) == 2
        assert blocked_meta[0]["tool_name"] == "tool_a"
        assert blocked_meta[0]["severity"] == "high"
        assert blocked_meta[1]["tool_name"] == "tool_b"
        assert blocked_meta[1]["severity"] == "critical"
        assert blocked_meta[0]["rules_triggered"] == ["ra"]


class TestEvaluateAndEnforceBatch:
    def test_first_block_wins_after_processing_all(self, monkeypatch):
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        span = _mk_span()

        results_iter = iter(
            [
                GuardResult(action="allow"),
                GuardResult(action="block", reason="nope"),
                GuardResult(action="modify", modified_input={"safe": True}),
            ]
        )

        def fake_try(name, inp):
            return next(results_iter)

        applied: list = []

        with patch(
            "staso.integrations._guard_common.try_guard", side_effect=fake_try
        ):
            with pytest.raises(GuardBlocked):
                evaluate_and_enforce(
                    [
                        {"name": "A", "input": {}, "ref": None},
                        {"name": "B", "input": {}, "ref": None},
                        {"name": "C", "input": {}, "ref": object()},
                    ],
                    span,
                    apply_modify=lambda r, m: applied.append(m),
                )

        # All three evaluated — batch continues before raising
        assert len(span.metadata["guard_evaluations"]) == 3
        # Modify callback still invoked for C
        assert applied == [{"safe": True}]

    def test_try_guard_none_entries_are_skipped(self, monkeypatch):
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        span = _mk_span()
        with patch(
            "staso.integrations._guard_common.try_guard", return_value=None
        ):
            evaluate_and_enforce(
                [{"name": "X", "input": {}, "ref": None}], span
            )
        assert "guard_evaluations" not in span.metadata
