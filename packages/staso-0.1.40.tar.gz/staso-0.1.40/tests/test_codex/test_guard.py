"""Guard enforcement tests for the Codex PreToolUse hook."""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from staso.codex.hook import _infer_codex_tool_name, handle_pre_tool_use
from staso.codex.state import HookState, save_state
from staso.guard_types import GuardResult, GuardRuleResult


def _make_sender() -> MagicMock:
    sender = MagicMock()
    sender.send = MagicMock()
    return sender


def _seed_state(session_id: str = "s1") -> None:
    state = HookState(session_id=session_id, cwd="/proj")
    state.current_trace_id = "trace-1"
    state.current_turn_span_id = "turn-span-1"
    save_state(state)


def _payload(
    tool_name: str = "Bash",
    tool_input: dict | None = None,
) -> dict:
    return {
        "hook_event_name": "PreToolUse",
        "session_id": "s1",
        "tool_name": tool_name,
        "tool_input": tool_input or {"command": "ls"},
        "tool_use_id": "tu-1",
    }


class TestCodexPreToolUseGuard:
    def test_guard_disabled(self, tmp_path, monkeypatch):
        monkeypatch.setattr("staso.codex.state._state_dir", lambda: tmp_path)
        monkeypatch.setenv("STASO_GUARD_ENABLED", "false")
        _seed_state()

        with patch("staso.guard.guard") as mock_guard:
            result = handle_pre_tool_use(_payload(), _make_sender())

        assert result is None
        mock_guard.assert_not_called()

    def test_block_returns_decision_and_emits_span(
        self, tmp_path, monkeypatch
    ):
        monkeypatch.setattr("staso.codex.state._state_dir", lambda: tmp_path)
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        _seed_state()

        block = GuardResult(
            action="block",
            reason="prod delete",
            rules_triggered=["prod_safety"],
        )
        sender = _make_sender()
        with patch("staso.guard.guard", return_value=block):
            result = handle_pre_tool_use(_payload(), sender)

        assert result == {"decision": "block", "reason": "prod delete"}
        spans = sender.send.call_args[0][0]
        assert any(s["name"] == "guard:blocked:exec_command" for s in spans)

    def test_escalate_treated_as_block(self, tmp_path, monkeypatch):
        monkeypatch.setattr("staso.codex.state._state_dir", lambda: tmp_path)
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        _seed_state()

        with patch(
            "staso.guard.guard",
            return_value=GuardResult(action="escalate", reason="human needed"),
        ):
            result = handle_pre_tool_use(_payload(), _make_sender())

        assert result is not None
        assert result["decision"] == "block"

    def test_modify_returns_modified_input(self, tmp_path, monkeypatch):
        monkeypatch.setattr("staso.codex.state._state_dir", lambda: tmp_path)
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        _seed_state()

        modified = GuardResult(
            action="modify",
            modified_input={"command": "echo safe"},
        )
        sender = _make_sender()
        with patch("staso.guard.guard", return_value=modified):
            result = handle_pre_tool_use(
                _payload(tool_input={"command": "rm -rf /"}), sender
            )

        assert result == {
            "decision": "modify",
            "tool_input": {"command": "echo safe"},
        }
        spans = sender.send.call_args[0][0]
        assert any(s["name"] == "guard:modified:exec_command" for s in spans)

    def test_allow_with_audit_emits_would_block(
        self, tmp_path, monkeypatch
    ):
        monkeypatch.setattr("staso.codex.state._state_dir", lambda: tmp_path)
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        _seed_state()

        audit = GuardRuleResult(
            rule_name="ls_on_root",
            passed=False,
            action="audit",
            reason="root path scan",
        )
        sender = _make_sender()
        with patch(
            "staso.guard.guard",
            return_value=GuardResult(action="allow", results=[audit]),
        ):
            result = handle_pre_tool_use(_payload(), sender)

        assert result is None
        spans = sender.send.call_args[0][0]
        assert any(s["name"] == "guard:would-block:exec_command" for s in spans)

    def test_empty_trace_id_skips_guard(self, tmp_path, monkeypatch):
        monkeypatch.setattr("staso.codex.state._state_dir", lambda: tmp_path)
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)

        state = HookState(session_id="s1", cwd="/proj")
        state.current_trace_id = ""
        state.current_turn_span_id = "turn-span-1"
        save_state(state)

        with patch("staso.guard.guard") as mock_guard:
            result = handle_pre_tool_use(_payload(), _make_sender())

        assert result is None
        mock_guard.assert_not_called()

    def test_guard_exception_defaults_to_allow(
        self, tmp_path, monkeypatch
    ):
        monkeypatch.setattr("staso.codex.state._state_dir", lambda: tmp_path)
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        _seed_state()

        with patch("staso.guard.guard", side_effect=RuntimeError("boom")):
            result = handle_pre_tool_use(_payload(), _make_sender())

        assert result is None

    def test_guard_receives_context(self, tmp_path, monkeypatch):
        monkeypatch.setattr("staso.codex.state._state_dir", lambda: tmp_path)
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        _seed_state()

        captured: dict = {}

        def fake_guard(**kwargs):
            captured.update(kwargs)
            return GuardResult(action="allow")

        with patch("staso.guard.guard", side_effect=fake_guard):
            handle_pre_tool_use(_payload(), _make_sender())

        ctx = captured["context"]
        assert ctx["trace_id"] == "trace-1"
        assert ctx["session_id"] == "s1"


class TestCodexToolNameInference:
    """Fix 3 regression: `_infer_codex_tool_name` should return the real
    Codex tool name at PreToolUse time so guard rules can scope on
    apply_patch / update_plan / exec_command instead of a lie-name "Bash"."""

    def test_bash_with_command_becomes_exec_command(self):
        assert (
            _infer_codex_tool_name("Bash", {"command": "ls -la"})
            == "exec_command"
        )

    def test_bash_with_patch_body_becomes_apply_patch(self):
        command = (
            "apply_patch <<'PATCH'\n"
            "*** Begin Patch\n"
            "*** Update File: src/a.py\n"
            "@@\n"
            "-x\n"
            "+y\n"
            "*** End Patch\n"
            "PATCH"
        )
        assert (
            _infer_codex_tool_name("Bash", {"command": command})
            == "apply_patch"
        )

    def test_bash_with_structured_patch_key_becomes_apply_patch(self):
        assert (
            _infer_codex_tool_name("Bash", {"patch": "*** Begin Patch\n..."})
            == "apply_patch"
        )

    def test_bash_with_plan_key_becomes_update_plan(self):
        assert (
            _infer_codex_tool_name("Bash", {"plan": ["step 1", "step 2"]})
            == "update_plan"
        )

    def test_bash_with_apply_patch_first_token(self):
        assert (
            _infer_codex_tool_name("Bash", {"command": "apply_patch some-arg"})
            == "apply_patch"
        )

    def test_bash_with_absolute_path_to_apply_patch(self):
        assert (
            _infer_codex_tool_name(
                "Bash", {"command": "/usr/local/bin/apply_patch"}
            )
            == "apply_patch"
        )

    def test_command_as_list_supported(self):
        assert (
            _infer_codex_tool_name("Bash", {"command": ["ls", "-la"]})
            == "exec_command"
        )

    def test_non_bash_payload_passed_through(self):
        # When Codex already sends a real name, trust it.
        assert (
            _infer_codex_tool_name("update_plan", {"plan": []})
            == "update_plan"
        )

    def test_empty_tool_input_leaves_payload_name(self):
        assert _infer_codex_tool_name("Bash", {}) == "Bash"

    def test_non_dict_tool_input_safe(self):
        assert _infer_codex_tool_name("Bash", "not-a-dict") == "Bash"  # type: ignore[arg-type]

    def test_inferred_name_is_passed_to_guard_call(
        self, tmp_path, monkeypatch
    ):
        monkeypatch.setattr("staso.codex.state._state_dir", lambda: tmp_path)
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        _seed_state()

        captured: dict = {}

        def fake_guard(**kwargs):
            captured.update(kwargs)
            return GuardResult(action="allow")

        payload = _payload(
            tool_name="Bash",
            tool_input={"command": "apply_patch <<'PATCH'\n*** Begin Patch\n..."},
        )
        with patch("staso.guard.guard", side_effect=fake_guard):
            handle_pre_tool_use(payload, _make_sender())

        assert captured["tool_name"] == "apply_patch"
