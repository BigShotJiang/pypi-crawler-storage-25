"""Auto-discover personas and scenarios from `personas/<persona>/harness.py`.

No hardcoded list — we glob the `personas/` directory, import each harness
module, and read its `_SCENARIO_MAP` dict. Adding a new persona or scenario
requires zero changes to the demo seeders.
"""
from __future__ import annotations

import importlib
import importlib.util
import os
from types import ModuleType
from typing import Callable

_INTEGRATION_TESTS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_PERSONAS_DIR = os.path.join(_INTEGRATION_TESTS_ROOT, "personas")

# Personas whose harnesses are not part of the persona/scenario matrix
# (common/ is shared utilities; sales_agent is listed under self_heal only if you want it).
_SKIP_DIRS = {"common", "__pycache__"}


def _import_harness(persona_slug: str) -> ModuleType:
    module_name = f"personas.{persona_slug}.harness"
    try:
        return importlib.import_module(module_name)
    except ModuleNotFoundError:
        path = os.path.join(_PERSONAS_DIR, persona_slug, "harness.py")
        spec = importlib.util.spec_from_file_location(module_name, path)
        if spec is None or spec.loader is None:
            raise
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod


def discover() -> dict[str, list[str]]:
    """Return {persona_slug: [scenario_name, ...]} for every persona with a harness."""
    result: dict[str, list[str]] = {}
    if not os.path.isdir(_PERSONAS_DIR):
        return result

    for entry in sorted(os.listdir(_PERSONAS_DIR)):
        if entry in _SKIP_DIRS:
            continue
        persona_dir = os.path.join(_PERSONAS_DIR, entry)
        if not os.path.isdir(persona_dir):
            continue
        if not os.path.exists(os.path.join(persona_dir, "harness.py")):
            continue

        harness = _import_harness(entry)
        scenario_map = getattr(harness, "_SCENARIO_MAP", None)
        if not isinstance(scenario_map, dict):
            continue
        result[entry] = sorted(scenario_map.keys())
    return result


def get_runner(persona_slug: str) -> Callable[..., dict]:
    """Return the `run_scenario(scenario, provider, env)` callable for a persona."""
    harness = _import_harness(persona_slug)
    fn = getattr(harness, "run_scenario", None)
    if fn is None:
        raise AttributeError(f"{persona_slug}/harness.py does not expose run_scenario()")
    return fn
