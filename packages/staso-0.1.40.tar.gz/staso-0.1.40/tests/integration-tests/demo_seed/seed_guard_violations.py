"""Seed guard violations across every integration.

Guard seeding is just trace seeding filtered to the ``guard_*`` personas.
Each guard persona runs a real LLM loop where the agent is nudged into a
risky tool call; ``st.guard()`` intercepts the call and blocks or modifies
it, and the resulting trace lands on the dashboard with full LLM input,
tool arguments, and the guard decision propagated back through the agent
history.

For CLI-agent integrations (claude_code / codex), the persona's
``_TOOL_REPLAY`` canonical sequence is dispatched through the hook. The
hook's internal ``st.guard()`` call on PreToolUse handles the block
exactly like it would in a real Claude Code / Codex session.

Usage:
    python demo_seed/seed_guard_violations.py --env local --integration all
    python demo_seed/seed_guard_violations.py --env staging --integration openai
    python demo_seed/seed_guard_violations.py --env local --integration claude_code \\
        --persona guard_db_admin --scenario dangerous_drop_table
"""
from __future__ import annotations

import argparse
import os
import sys
import traceback

_TESTS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _TESTS_ROOT not in sys.path:
    sys.path.insert(0, _TESTS_ROOT)

from demo_seed import discovery, seed_traces  # noqa: E402

_GUARD_PERSONA_PREFIX = "guard_"


def _discover_guard_personas() -> list[str]:
    return sorted(p for p in discovery.discover() if p.startswith(_GUARD_PERSONA_PREFIX))


def _parse_multi(value: str, universe: list[str]) -> list[str]:
    if value == "all":
        return list(universe)
    requested = [v.strip() for v in value.split(",") if v.strip()]
    unknown = [v for v in requested if v not in universe]
    if unknown:
        sys.exit(f"Unknown value(s): {unknown}. Valid: {universe}")
    return requested


def main() -> None:
    guard_personas = _discover_guard_personas()
    if not guard_personas:
        sys.exit(
            "No guard_* personas discovered. Add one under "
            "tests/integration-tests/personas/guard_<slug>/."
        )

    parser = argparse.ArgumentParser(
        description="Seed Staso guard violations across every integration.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "\nDiscovered guard personas:\n"
            + "\n".join(f"  {p}: {', '.join(discovery.discover()[p])}" for p in guard_personas)
        ),
    )
    parser.add_argument("--env", required=True, choices=["local", "production"])
    parser.add_argument(
        "--integration",
        default="all",
        help="openai | anthropic | claude_code | codex | all | comma list",
    )
    parser.add_argument(
        "--persona",
        default="all",
        help=f"'all' or comma list. Known guard personas: {', '.join(guard_personas)}",
    )
    parser.add_argument("--scenario", default="all", help="'all' or comma list of scenario names")
    parser.add_argument("--repeat", type=int, default=1)
    parser.add_argument("--agent-name", default=None)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument(
        "--results",
        default=None,
        help="Path to write JSON report (default: results/seed_guard_<env>.json)",
    )
    args = parser.parse_args()

    personas = _parse_multi(args.persona, guard_personas)
    integrations = _parse_multi(args.integration, list(seed_traces._ALL_INTEGRATIONS))

    scenario_arg: list[str] | None
    if args.scenario == "all":
        scenario_arg = None
    else:
        scenario_arg = [s.strip() for s in args.scenario.split(",") if s.strip()]

    results_path = args.results or os.path.join(
        _TESTS_ROOT, "results", f"seed_guard_{args.env}.json"
    )

    try:
        seed_traces.seed(
            env=args.env,
            integrations=integrations,
            personas=personas,
            scenarios=scenario_arg,
            repeat=args.repeat,
            agent_name=args.agent_name,
            dry_run=args.dry_run,
            results_path=None if args.dry_run else results_path,
        )
    except SystemExit:
        raise
    except Exception:
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
