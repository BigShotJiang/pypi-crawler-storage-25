# demo_seed

Populate a Staso workspace with traces and guard violations across every integration.

Four integrations, one command each:

| Category | Integration |
|---|---|
| SDK | `openai`, `anthropic` |
| CLI tool | `claude_code`, `codex` |

Personas live in `tests/integration-tests/personas/` and are integration-agnostic — the same persona runs across all four.

## Setup

One-time bootstrap from the SDK repo root:

```bash
uv sync --project tests/integration-tests/demo_seed
```

This creates a venv at `tests/integration-tests/demo_seed/.venv` with the SDK installed editable-mode plus `openai`, `anthropic`, and `httpx`.

Then export credentials before running:

```bash
export STASO_API_KEY=ak_...
export STASO_WORKSPACE_SLUG=claude-code
export STASO_ENVIRONMENT=mayank
export STASO_AGENT_NAME=claude-code-global
export STASO_BASE_URL=http://localhost:6999   # or https://api.staso.ai
export OPENAI_API_KEY=sk-...                  # only for --integration openai
export ANTHROPIC_API_KEY=sk-ant-...            # only for --integration anthropic
```

For `--env local` the seeder pings `/health` and fails fast if the backend isn't running.

## Seed traces

Run from the SDK repo root:

```bash
# Every persona × every integration
uv run --project tests/integration-tests/demo_seed \
    tests/integration-tests/demo_seed/seed_traces.py --env local --integration all

# One integration across every persona
uv run --project tests/integration-tests/demo_seed \
    tests/integration-tests/demo_seed/seed_traces.py --env production --integration claude_code

# One persona across every integration
uv run --project tests/integration-tests/demo_seed \
    tests/integration-tests/demo_seed/seed_traces.py --env production --integration all --persona customer_support

# Single scenario, single integration (smoke test)
uv run --project tests/integration-tests/demo_seed \
    tests/integration-tests/demo_seed/seed_traces.py --env local --integration openai \
    --persona finance_ops --scenario payment_under_limit
uv run --project tests/integration-tests/demo_seed \
    tests/integration-tests/demo_seed/seed_traces.py --env local --integration claude_code \
    --persona finance_ops --scenario payment_under_limit
uv run --project tests/integration-tests/demo_seed \
    tests/integration-tests/demo_seed/seed_traces.py --env local --integration codex \
    --persona finance_ops --scenario payment_under_limit
uv run --project tests/integration-tests/demo_seed \
    tests/integration-tests/demo_seed/seed_traces.py --env local --integration anthropic \
    --persona finance_ops --scenario payment_under_limit
```

OpenAI and Anthropic hit the real LLM. Claude Code and Codex replay each persona's `_TOOL_REPLAY` sequence through the hook dispatcher — no LLM, same tools on the dashboard.

## Seed guard violations

Guard seeding is just trace seeding filtered to the `guard_*` personas. Each one runs a real LLM agent loop where the model is nudged into a risky tool call, `st.guard()` intercepts the call, and the blocked decision flows back through the trace. No synthetic payloads — real LLM input, real tool arguments, real block reason on the dashboard.

```bash
# Every guard persona × every integration
uv run --project tests/integration-tests/demo_seed \
    tests/integration-tests/demo_seed/seed_guard_violations.py --env local --integration all

# One integration, every guard persona
uv run --project tests/integration-tests/demo_seed \
    tests/integration-tests/demo_seed/seed_guard_violations.py --env local --integration openai
    
uv run --project tests/integration-tests/demo_seed \
    tests/integration-tests/demo_seed/seed_guard_violations.py --env local --integration anthropic
    
uv run --project tests/integration-tests/demo_seed \
    tests/integration-tests/demo_seed/seed_guard_violations.py --env local --integration claude_code
    
uv run --project tests/integration-tests/demo_seed \
    tests/integration-tests/demo_seed/seed_guard_violations.py --env local --integration codex

# One scenario, one integration (debug)
uv run --project tests/integration-tests/demo_seed \
    tests/integration-tests/demo_seed/seed_guard_violations.py --env local --integration claude_code \
    --persona guard_db_admin --scenario dangerous_drop_table
```

### Guard personas

| Persona | Scenario | Rule category |
|---|---|---|
| `guard_db_admin` | `dangerous_drop_table` | `dangerous` |
| `guard_db_admin` | `sql_injection_query` | `injection` |
| `guard_devops_deploy` | `secrets_leak_to_slack` | `secrets` |
| `guard_support_agent` | `pii_in_confirmation_email` | `pii` |
| `guard_research_analyst` | `indirect_injection_from_fetch` | `indirect_injection` (LLM judge) |
| `guard_ops_dashboard` | `data_exfiltration_webhook` | `data_exfiltration` (LLM judge) |

LLM-judge rules default to `mode=disabled`. Enable them in the dashboard for the target workspace if you want those scenarios to actually block.

## Add a new persona

Drop `personas/<slug>/harness.py` with a `_SCENARIO_MAP` (LLM runner) and a `_TOOL_REPLAY` (canonical tool sequence for CLI integrations). Auto-discovered on the next run.

## Add a new guard persona

Same as a regular persona, but name the folder `guard_<slug>` and build the agent loop with `personas.common.guarded_loop.run_guarded_agent` so every tool call passes through `st.guard()`. The `seed_guard_violations.py` filter picks it up automatically.

## Add a new integration

Implement the dispatcher in `seed_traces.py:_run_one`. SDK integrations use `patch_<provider>()` + the persona runner. CLI integrations replay `_TOOL_REPLAY` through the agent's hook module.
