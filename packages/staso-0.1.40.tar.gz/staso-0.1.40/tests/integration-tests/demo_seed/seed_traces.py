"""Seed traces across every Staso integration — OpenAI, Anthropic, Claude Code, Codex.

Usage:
    python demo_seed/seed_traces.py --env local --integration all
    python demo_seed/seed_traces.py --env staging --integration openai --persona customer_support
    python demo_seed/seed_traces.py --env local --integration claude_code --persona all

Personas and scenarios live under ``tests/integration-tests/personas/`` and
are auto-discovered — the seeder never cares which integration you're
targeting. For OpenAI/Anthropic it runs the persona through the real LLM
client. For Claude Code/Codex it replays the persona's canonical
``_TOOL_REPLAY`` sequence through the hook dispatcher.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import traceback
import uuid
from dataclasses import dataclass, field
from typing import Any

# Ensure tests/integration-tests/ is importable as a package root so we can
# load personas.<slug>.harness modules the same way conftest.py does.
_TESTS_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _TESTS_ROOT not in sys.path:
    sys.path.insert(0, _TESTS_ROOT)

from demo_seed import discovery, env_presets  # noqa: E402

_LLM_INTEGRATIONS = ("openai", "anthropic")
_CLI_AGENT_INTEGRATIONS = ("claude_code", "codex")
_ALL_INTEGRATIONS = _LLM_INTEGRATIONS + _CLI_AGENT_INTEGRATIONS

_HOOK_CWD = "/Users/demo/repo"

# Claude Code and Codex hooks read STASO_GUARD_TIMEOUT from os.environ when
# deciding how long to wait on ``st.guard()``. Default in the SDK is 10s,
# which is too tight for local backends that evaluate LLM-judge rules. Set
# a generous default here; users can still override by exporting a different
# value in their shell before running the seeder.
os.environ.setdefault("STASO_GUARD_TIMEOUT", "60")


@dataclass
class RunSummary:
    persona: str
    scenario: str
    integration: str
    iteration: int
    ok: bool
    session_id: str = ""
    error: str = ""
    elapsed_ms: int = 0


@dataclass
class SeedReport:
    env: str
    base_url: str
    started_at: float
    total: int = 0
    ok: int = 0
    failed: int = 0
    runs: list[RunSummary] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "env": self.env,
            "base_url": self.base_url,
            "started_at": self.started_at,
            "elapsed_s": round(time.time() - self.started_at, 1),
            "total": self.total,
            "ok": self.ok,
            "failed": self.failed,
            "runs": [r.__dict__ for r in self.runs],
        }


def _parse_multi(value: str | None, universe: list[str]) -> list[str]:
    """Parse 'all' / 'a,b' into a concrete list against universe."""
    if value is None or value == "all":
        return list(universe)
    requested = [v.strip() for v in value.split(",") if v.strip()]
    unknown = [v for v in requested if v not in universe]
    if unknown:
        sys.exit(f"Unknown value(s): {unknown}. Valid: {universe}")
    return requested


def _run_llm(
    persona: str,
    scenario: str,
    provider: str,
    env_label: str,
    iteration: int,
) -> RunSummary:
    """Dispatch via the persona's LLM-driven run_scenario()."""
    runner = discovery.get_runner(persona)
    start = time.monotonic()
    try:
        result = runner(scenario=scenario, provider=provider, env=env_label)
        elapsed_ms = int((time.monotonic() - start) * 1000)
        session_id = result.get("session_id", "") if isinstance(result, dict) else ""
        return RunSummary(
            persona=persona,
            scenario=scenario,
            integration=provider,
            iteration=iteration,
            ok=True,
            session_id=session_id,
            elapsed_ms=elapsed_ms,
        )
    except Exception as exc:
        return RunSummary(
            persona=persona,
            scenario=scenario,
            integration=provider,
            iteration=iteration,
            ok=False,
            error=f"{type(exc).__name__}: {exc}",
            elapsed_ms=int((time.monotonic() - start) * 1000),
        )


def _load_tool_replay(persona: str) -> list[tuple[str, dict, dict]]:
    """Read the persona's _TOOL_REPLAY constant from its harness module."""
    harness = discovery._import_harness(persona)  # type: ignore[attr-defined]
    replay = getattr(harness, "_TOOL_REPLAY", None)
    if not isinstance(replay, list) or not replay:
        raise RuntimeError(
            f"Persona {persona!r} has no _TOOL_REPLAY sequence defined in harness.py. "
            f"Add one to enable CLI-agent (claude_code / codex) seeding."
        )
    return replay


def _dispatch_cli_agent(
    persona: str,
    scenario: str,
    integration: str,
    env_label: str,
    iteration: int,
) -> RunSummary:
    """Replay a persona's canonical tool sequence through a CLI-agent hook.

    Loads ``_TOOL_REPLAY`` from the persona and dispatches SessionStart →
    UserPromptSubmit → PreToolUse/PostToolUse pairs → Stop through either
    ``staso.claude_code.hook`` or ``staso.codex.hook``. The integration
    receives the same tool calls the persona would normally issue via
    the LLM, so the dashboard shows the persona's real tools under the
    correct integration.
    """
    session_id = f"{persona}-{scenario}-{integration}-{uuid.uuid4().hex[:8]}"
    start = time.monotonic()
    try:
        replay = _load_tool_replay(persona)

        if integration == "claude_code":
            from staso.claude_code import hook as ck_hook
            dispatch = ck_hook.run
            transcript_dir = ".claude"
        elif integration == "codex":
            from staso.codex import hook as cx_hook
            dispatch = cx_hook.run
            transcript_dir = ".codex"
        else:
            raise ValueError(f"Unknown CLI-agent integration: {integration}")

        transcript_path = os.path.join(_HOOK_CWD, transcript_dir, "nonexistent.jsonl")

        dispatch({
            "hook_event_name": "SessionStart",
            "session_id": session_id,
            "cwd": _HOOK_CWD,
            "source": "startup",
        })
        dispatch({
            "hook_event_name": "UserPromptSubmit",
            "session_id": session_id,
            "cwd": _HOOK_CWD,
            "prompt": f"{persona}/{scenario}",
            "transcript_path": transcript_path,
        })

        for tool_name, tool_input, tool_response in replay:
            # Codex reports tool_name="Bash" at the hook layer; the real
            # tool lives inside tool_input where pattern-based rules can
            # still see it.
            hook_tool_name = "Bash" if integration == "codex" else tool_name
            tool_use_id = f"tu_{uuid.uuid4().hex[:8]}"

            pre_payload = {
                "hook_event_name": "PreToolUse",
                "session_id": session_id,
                "cwd": _HOOK_CWD,
                "tool_name": hook_tool_name,
                "tool_use_id": tool_use_id,
                "tool_input": (
                    {"tool": tool_name, **tool_input}
                    if integration == "codex"
                    else tool_input
                ),
            }
            decision = dispatch(pre_payload)

            # Honour the hook's PreToolUse decision the same way the real
            # Claude Code / Codex CLI hosts do. Without this check the
            # seeder unconditionally dispatches PostToolUse, which emits a
            # ``tool:<name>`` span even when the hook said block — a
            # faithful replay has to respect the decision so the DB
            # reflects what users will actually see in production.
            if isinstance(decision, dict):
                verdict = decision.get("decision")
                if verdict == "block":
                    # Real CLI hosts abort the tool before PostToolUse
                    # fires, so skip it entirely.
                    time.sleep(0.02)
                    continue
                if verdict == "modify" and "tool_input" in decision:
                    # Real CLI hosts run the tool with the modified input
                    # and PostToolUse observes the modified form.
                    pre_payload["tool_input"] = decision["tool_input"]

            dispatch({
                "hook_event_name": "PostToolUse",
                "session_id": session_id,
                "cwd": _HOOK_CWD,
                "tool_name": hook_tool_name,
                "tool_use_id": tool_use_id,
                "tool_input": pre_payload["tool_input"],
                "tool_response": tool_response,
            })
            time.sleep(0.02)

        dispatch({
            "hook_event_name": "Stop",
            "session_id": session_id,
            "cwd": _HOOK_CWD,
            "transcript_path": transcript_path,
        })

        return RunSummary(
            persona=persona,
            scenario=scenario,
            integration=integration,
            iteration=iteration,
            ok=True,
            session_id=session_id,
            elapsed_ms=int((time.monotonic() - start) * 1000),
        )
    except Exception as exc:
        return RunSummary(
            persona=persona,
            scenario=scenario,
            integration=integration,
            iteration=iteration,
            ok=False,
            error=f"{type(exc).__name__}: {exc}",
            elapsed_ms=int((time.monotonic() - start) * 1000),
        )


def _run_one(
    persona: str,
    scenario: str,
    integration: str,
    env_label: str,
    iteration: int,
) -> RunSummary:
    if integration in _LLM_INTEGRATIONS:
        return _run_llm(persona, scenario, integration, env_label, iteration)
    if integration in _CLI_AGENT_INTEGRATIONS:
        return _dispatch_cli_agent(persona, scenario, integration, env_label, iteration)
    raise ValueError(f"Unknown integration: {integration}")


def seed(
    *,
    env: str,
    integrations: list[str] | None = None,
    personas: list[str] | None = None,
    scenarios: list[str] | None = None,
    repeat: int = 1,
    agent_name: str | None = None,
    dry_run: bool = False,
    results_path: str | None = None,
) -> SeedReport:
    preset = env_presets.resolve(env)
    env_presets.assert_reachable(preset)

    available = discovery.discover()
    if not available:
        sys.exit("No personas discovered — is the tests/integration-tests/ tree intact?")

    all_personas = sorted(available.keys())
    selected_personas = personas or all_personas
    selected_personas = [p for p in selected_personas if p in available]
    if not selected_personas:
        sys.exit(f"No matching personas. Known: {all_personas}")

    if scenarios is None:
        plan = {p: list(available[p]) for p in selected_personas}
    else:
        requested = set(scenarios)
        plan = {}
        for p in selected_personas:
            matches = [s for s in available[p] if s in requested]
            if matches:
                plan[p] = matches
        if not plan:
            sys.exit(f"No scenarios {sorted(requested)} match personas {selected_personas}")

    selected_integrations = integrations or ["openai"]
    for ig in selected_integrations:
        if ig not in _ALL_INTEGRATIONS:
            sys.exit(f"Unknown integration {ig!r}. Valid: {list(_ALL_INTEGRATIONS)}")

    report = SeedReport(env=env, base_url=preset.base_url, started_at=time.time())

    scenario_count = sum(len(v) for v in plan.values())
    total_runs = scenario_count * len(selected_integrations) * repeat

    print("=" * 72)
    print("demo_seed: traces")
    print(f"  env          : {env}  ({preset.base_url})")
    print(f"  workspace    : {preset.workspace_slug}")
    print(f"  integrations : {', '.join(selected_integrations)}")
    print(f"  personas     : {', '.join(selected_personas)}")
    print(f"  scenarios    : {scenario_count}")
    print(f"  repeat       : {repeat}")
    print(f"  total runs   : {total_runs}")
    print("=" * 72)

    if dry_run:
        for p, scens in plan.items():
            for s in scens:
                for ig in selected_integrations:
                    for i in range(repeat):
                        print(f"[dry-run] {p}/{s} integration={ig} iter={i + 1}")
        return report

    # Only validate LLM provider keys if we'll actually run an LLM integration.
    llm_selected = [ig for ig in selected_integrations if ig in _LLM_INTEGRATIONS]
    if llm_selected:
        env_presets.export_provider_keys(preset, llm_selected)

    # If only CLI-agent integrations are selected we don't strictly need
    # st.init() (the hook dispatcher builds its sender from env vars). But
    # initialising st is harmless and lets LLM integrations share the same
    # client, so we always do it.
    import staso as st
    st.init(
        api_key=preset.api_key,
        agent_name=agent_name or preset.agent_name,
        base_url=preset.base_url,
        environment=preset.environment_label,
        workspace_slug=preset.workspace_slug,
        debug=False,
    )

    try:
        for p in selected_personas:
            if p not in plan:
                continue
            for s in plan[p]:
                for ig in selected_integrations:
                    for i in range(repeat):
                        print(f"-> {p}/{s} [{ig}] ({i + 1}/{repeat})", flush=True)
                        result = _run_one(p, s, ig, preset.environment_label, i + 1)
                        report.runs.append(result)
                        report.total += 1
                        if result.ok:
                            report.ok += 1
                            print(
                                f"   ok  session={result.session_id or '-'} "
                                f"({result.elapsed_ms}ms)",
                                flush=True,
                            )
                        else:
                            report.failed += 1
                            print(f"   FAIL {result.error}", flush=True)
    finally:
        st.shutdown()

    print("=" * 72)
    print(f"Done: {report.ok} ok, {report.failed} failed, total={report.total}")
    print(f"Elapsed: {round(time.time() - report.started_at, 1)}s")

    if results_path:
        os.makedirs(os.path.dirname(os.path.abspath(results_path)) or ".", exist_ok=True)
        with open(results_path, "w") as f:
            json.dump(report.to_dict(), f, indent=2, default=str)
        print(f"Report written: {results_path}")

    return report


def main() -> None:
    available = discovery.discover()
    persona_list = sorted(available.keys()) or ["<none discovered>"]

    parser = argparse.ArgumentParser(
        description="Seed Staso dashboards with traces across all 4 integrations.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "\nDiscovered personas/scenarios:\n"
            + "\n".join(f"  {p}: {', '.join(available[p])}" for p in persona_list if p in available)
        ),
    )
    parser.add_argument("--env", required=True, choices=["local", "production"])
    parser.add_argument(
        "--integration",
        default="openai",
        help=(
            "openai | anthropic | claude_code | codex | all | comma list. "
            "openai and anthropic run the persona through real LLM calls; "
            "claude_code and codex replay the persona's _TOOL_REPLAY sequence "
            "through the hook dispatcher."
        ),
    )
    parser.add_argument(
        "--persona",
        default="all",
        help=f"'all' or comma list. Known: {', '.join(persona_list)}",
    )
    parser.add_argument("--scenario", default="all", help="'all' or comma list of scenario names")
    parser.add_argument("--repeat", type=int, default=1, help="Runs per (persona, scenario, integration)")
    parser.add_argument(
        "--agent-name",
        default=None,
        help="agent_name passed to st.init. Defaults to $STASO_AGENT_NAME, then 'demo-seed-agent'.",
    )
    parser.add_argument("--dry-run", action="store_true", help="Print plan and exit")
    parser.add_argument(
        "--results",
        default=None,
        help="Path to write JSON report (default: results/seed_traces_<env>.json)",
    )
    args = parser.parse_args()

    personas = _parse_multi(args.persona, persona_list)
    integrations = _parse_multi(args.integration, list(_ALL_INTEGRATIONS))

    scenario_arg: list[str] | None
    if args.scenario == "all":
        scenario_arg = None
    else:
        scenario_arg = [s.strip() for s in args.scenario.split(",") if s.strip()]

    results_path = args.results or os.path.join(
        _TESTS_ROOT, "results", f"seed_traces_{args.env}.json"
    )

    try:
        seed(
            env=args.env,
            integrations=integrations,
            personas=personas,
            scenarios=scenario_arg,
            repeat=args.repeat,
            agent_name=args.agent_name,
            dry_run=args.dry_run,
            results_path=None if args.dry_run else results_path,
        )
    except SystemExit:
        raise
    except Exception:
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
