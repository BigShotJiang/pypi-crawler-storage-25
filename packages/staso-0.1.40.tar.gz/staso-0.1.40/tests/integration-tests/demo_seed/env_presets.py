"""Environment presets for demo seeders.

All credentials and workspace config come from ``os.environ`` — nothing is
hardcoded here so the file is safe to commit. Set these before running the
seeders (in your shell, ``.envrc``, CI secrets, etc.):

    STASO_API_KEY         -- Staso API key (required)
    STASO_BASE_URL        -- e.g. http://localhost:6999 or https://api.staso.ai
                             (optional — defaults per --env below)
    STASO_ENVIRONMENT     -- environment label stamped on every trace
                             (optional — defaults to the --env name)
    STASO_WORKSPACE_SLUG  -- target workspace slug (required)
    STASO_AGENT_NAME      -- dashboard grouping label (optional)
    OPENAI_API_KEY        -- required for --provider openai
    ANTHROPIC_API_KEY     -- required for --provider anthropic

Switch between local / production by exporting a different set of
``STASO_*`` vars — the seeder reads them at resolve time.

For --env local we ping {base_url}/health before seeding so you don't
fire traces at a dead backend.
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass


@dataclass(frozen=True)
class EnvPreset:
    name: str
    base_url: str
    environment_label: str
    api_key: str
    workspace_slug: str
    agent_name: str
    openai_api_key: str = ""
    anthropic_api_key: str = ""


# Per-env base_url defaults used when STASO_BASE_URL is not set.
_BASE_URL_DEFAULTS: dict[str, str] = {
    "local": "http://localhost:6999",
    "production": "https://api.staso.ai",
}


def resolve(name: str) -> EnvPreset:
    """Build an EnvPreset for ``name`` and sync it back into ``os.environ``.

    Reads STASO_* vars from the current environment, fills in per-env
    defaults (base_url), then writes the resolved values back into
    ``os.environ``. The write-back is load-bearing: CLI-agent hooks
    (``staso.claude_code.hook``, ``staso.codex.hook``) build their own
    ``SpanSender`` from ``os.environ`` at call time. If we don't sync
    the preset back, the hook falls through to the hardcoded
    ``https://api.staso.ai`` default and the seeder ships traces to
    prod even when you passed ``--env local``.
    """
    if name not in _BASE_URL_DEFAULTS:
        raise ValueError(
            f"Unknown env {name!r}. Supported: {', '.join(sorted(_BASE_URL_DEFAULTS))}"
        )

    # --env selects the base_url unconditionally — don't let a stale
    # STASO_BASE_URL in the shell silently redirect a --env local run to
    # production (that mismatch is what causes the 401 "invalid api key"
    # error when a local-workspace key is posted to prod).
    base_url = _BASE_URL_DEFAULTS[name]

    preset = EnvPreset(
        name=name,
        base_url=base_url,
        environment_label=os.environ.get("STASO_ENVIRONMENT", name),
        api_key=os.environ.get("STASO_API_KEY", ""),
        workspace_slug=os.environ.get("STASO_WORKSPACE_SLUG", ""),
        agent_name=os.environ.get("STASO_AGENT_NAME", "demo-seed-agent"),
        openai_api_key=os.environ.get("OPENAI_API_KEY", ""),
        anthropic_api_key=os.environ.get("ANTHROPIC_API_KEY", ""),
    )

    if not preset.api_key:
        raise SystemExit(
            "\n[demo_seed] FAIL: STASO_API_KEY is not set.\n"
            "  Export it in your shell before running the seeder."
        )
    if not preset.workspace_slug:
        raise SystemExit(
            "\n[demo_seed] FAIL: STASO_WORKSPACE_SLUG is not set.\n"
            "  Export it in your shell before running the seeder."
        )

    # Propagate the resolved values back into os.environ so anything that
    # reads them later (hook senders, subprocesses) sees the same config.
    os.environ["STASO_API_KEY"] = preset.api_key
    os.environ["STASO_BASE_URL"] = preset.base_url
    os.environ["STASO_ENVIRONMENT"] = preset.environment_label
    os.environ["STASO_WORKSPACE_SLUG"] = preset.workspace_slug
    os.environ["STASO_AGENT_NAME"] = preset.agent_name

    return preset


def export_provider_keys(preset: EnvPreset, providers: list[str]) -> None:
    """Validate that the provider LLM keys needed by the run are set.

    The persona harnesses' provider.py already reads OPENAI_API_KEY /
    ANTHROPIC_API_KEY from os.environ, so we just fail fast here if the
    required key is missing.
    """
    for provider in providers:
        if provider == "openai":
            if not preset.openai_api_key:
                sys.exit(
                    "[demo_seed] FAIL: OPENAI_API_KEY is not set but "
                    "--provider openai was requested."
                )
        elif provider == "anthropic":
            if not preset.anthropic_api_key:
                sys.exit(
                    "[demo_seed] FAIL: ANTHROPIC_API_KEY is not set but "
                    "--provider anthropic was requested."
                )
        else:
            sys.exit(f"Unknown provider {provider!r}")


def assert_reachable(preset: EnvPreset) -> None:
    """Ping {base_url}/health before we seed. Only enforced for `local`."""
    if preset.name != "local":
        return

    try:
        import httpx
    except ImportError:
        sys.exit("httpx is required for the local reachability check")

    try:
        resp = httpx.get(f"{preset.base_url}/health", timeout=2.0)
    except Exception as exc:
        sys.exit(
            f"\n[demo_seed] FAIL: local backend not reachable at {preset.base_url}\n"
            f"  reason: {exc}\n"
            f"  Start the backend (`uv run uvicorn src.app:app --port 6999` from the "
            f"agentic_leash_backend repo) and retry."
        )

    if resp.status_code != 200:
        sys.exit(
            f"\n[demo_seed] FAIL: local backend at {preset.base_url}/health returned "
            f"HTTP {resp.status_code}. Backend is up but unhealthy — check its logs."
        )
