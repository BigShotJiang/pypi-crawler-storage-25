"""Demo data seeders for Staso dashboards.

Two CLIs live here:
    seed_traces.py            -- populate traces across any persona/provider/env
    seed_guard_violations.py  -- populate guard violations across zero-config policies

Both read from .env (same file the pytest suite uses) and target local, staging,
or production workspaces via --env.
"""
