"""Cache for self-heal trace ingestion metadata.

Stores good/bad commit SHAs after first ingestion so subsequent runs
reuse existing ClickHouse data instead of re-ingesting.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import TypedDict

_CACHE_FILE = os.path.join(os.path.dirname(__file__), ".traces_cache.json")


class TraceCache(TypedDict):
    good_sha: str
    bad_sha: str
    agent_name: str
    n_traces: int
    good_error_rate: float
    bad_error_rate: float
    ingested_at: str


def load() -> TraceCache | None:
    """Load cached trace metadata. Returns None if cache doesn't exist."""
    if not os.path.exists(_CACHE_FILE):
        return None
    try:
        with open(_CACHE_FILE) as f:
            return json.load(f)
    except (json.JSONDecodeError, KeyError):
        return None


def save(meta: TraceCache) -> None:
    """Persist trace metadata to cache file."""
    meta["ingested_at"] = datetime.now(timezone.utc).isoformat()
    with open(_CACHE_FILE, "w") as f:
        json.dump(meta, f, indent=2)
    print(f"[cache] Saved to {_CACHE_FILE}")


def clear() -> None:
    """Delete the cache file to force re-ingestion."""
    if os.path.exists(_CACHE_FILE):
        os.remove(_CACHE_FILE)
        print(f"[cache] Cleared {_CACHE_FILE}")
