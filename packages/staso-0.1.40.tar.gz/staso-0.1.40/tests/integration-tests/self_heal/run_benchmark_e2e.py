#!/usr/bin/env python3
"""Multi-commit benchmark regression curve e2e test.

Runs the same BFCL benchmark tasks across N commit phases, each with
progressively worse FaultConfig. The regression detector sees a curve
across multiple degradation dimensions:

  v1_baseline  -> clean: no faults
  v2_slight    -> tool_fail_rate=10%, 500ms tool latency
  v3_moderate  -> tool_fail_rate=25%, 20% prompt corruption, 1K token inflation
  v4_bad       -> tool_fail_rate=50%, 40% prompt corruption, 3K inflation,
                  30% response truncation

This exercises all five fault types:
  - tool_fail_rate:          tool calls raise RuntimeError
  - tool_latency_ms:         artificial delay on tool calls (latency regression)
  - token_inflation_chars:   padding in system prompt (cost/token regression)
  - prompt_corruption_rate:  sentences randomly dropped (prompt regression)
  - response_truncation_rate: tool responses truncated (quality regression)

Usage:
    python run_benchmark_e2e.py
    python run_benchmark_e2e.py --provider anthropic --flush-wait 20
    python run_benchmark_e2e.py --phases v1_baseline,v4_bad   # subset

Unlike run_e2e.py (which uses hand-crafted personas), this script uses fixed
benchmark tasks so the regression signal comes purely from agent degradation,
not from switching to different scenarios.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import uuid

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

_ENV_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env")
if os.path.exists(_ENV_FILE):
    with open(_ENV_FILE) as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                _k, _, _v = _line.partition("=")
                os.environ.setdefault(_k.strip(), _v.strip())

import staso as st

from self_heal.workloads import FaultConfig
from self_heal.trace_generator import generate_workload_traces


# ── Commit curve definition ─────────────────────────────────────────────────
# Each entry: (phase_name, branch, FaultConfig)
# Phases are run in order; the regression detector compares adjacent commits.

_DEFAULT_CURVE: list[tuple[str, str, FaultConfig]] = [
    ("v1_baseline", "main", FaultConfig()),
    ("v2_slight", "feature-x", FaultConfig(
        tool_fail_rate=0.10,
        tool_latency_ms=500,
    )),
    ("v3_moderate", "feature-x", FaultConfig(
        tool_fail_rate=0.25,
        tool_latency_ms=1000,
        token_inflation_chars=1000,
        prompt_corruption_rate=0.20,
    )),
    ("v4_bad", "feature-x", FaultConfig(
        tool_fail_rate=0.50,
        tool_latency_ms=2000,
        token_inflation_chars=3000,
        prompt_corruption_rate=0.40,
        response_truncation_rate=0.30,
    )),
]

_PHASE_MAP = {name: (name, branch, fc) for name, branch, fc in _DEFAULT_CURVE}


def _run_phase(
    phase_name: str,
    branch: str,
    fault: FaultConfig,
    commit_sha: str,
    api_key: str,
    base_url: str,
    agent_name: str,
    environment: str,
    provider: str,
    workload: str = "bfcl",
) -> list[dict]:
    print(f"\n[{phase_name}] Generating traces (commit={commit_sha[:12]}, "
          f"tool_fail_rate={fault.tool_fail_rate:.0%})")
    os.environ["STASO_VCS_COMMIT_SHA"] = commit_sha
    os.environ["STASO_VCS_BRANCH"] = branch
    st.init(
        api_key=api_key,
        agent_name=agent_name,
        base_url=base_url,
        environment=environment,
        capture_git=True,
        debug=False,
    )
    try:
        results = generate_workload_traces(
            fault=fault,
            provider=provider,
            env=environment,
            workload=workload,
        )
        success_count = sum(1 for r in results if r.get("success", False))
        print(f"[{phase_name}] {len(results)} tasks, {success_count} correct "
              f"({success_count / max(len(results), 1):.0%} success rate). Flushing...")
        return results
    finally:
        st.shutdown()
        os.environ.pop("STASO_VCS_COMMIT_SHA", None)
        os.environ.pop("STASO_VCS_BRANCH", None)


def _wait_for_flush(seconds: int) -> None:
    print(f"\nWaiting {seconds}s for ClickHouse flush...")
    for i in range(seconds, 0, -5):
        print(f"  {i}s remaining...")
        time.sleep(min(5, i))


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Multi-commit benchmark regression curve e2e test"
    )
    parser.add_argument("--agent-name", default="benchmark-regression-agent")
    parser.add_argument(
        "--backend-url",
        default=os.environ.get("STASO_BASE_URL", "http://localhost:8000"),
    )
    parser.add_argument(
        "--environment",
        default=os.environ.get("STASO_ENVIRONMENT", "staging"),
    )
    parser.add_argument("--provider", default="openai", choices=["openai", "anthropic"])
    parser.add_argument(
        "--workload",
        default="bfcl",
        choices=["bfcl", "taubench"],
        help="Workload type: bfcl (single-turn) or taubench (multi-turn)",
    )
    parser.add_argument(
        "--phases",
        default=",".join(name for name, _, _ in _DEFAULT_CURVE),
        help="Comma-separated phase names to run (default: all 4)",
    )
    parser.add_argument(
        "--flush-wait",
        type=int,
        default=15,
        help="Seconds to wait for ClickHouse flush between phases",
    )
    parser.add_argument(
        "--out",
        default=None,
        help="Write per-phase summary JSON to this file",
    )
    args = parser.parse_args()

    api_key = os.environ.get("STASO_API_KEY", "")
    if not api_key:
        print("ERROR: STASO_API_KEY not set")
        sys.exit(1)

    selected_phases = [p.strip() for p in args.phases.split(",") if p.strip()]
    unknown = [p for p in selected_phases if p not in _PHASE_MAP]
    if unknown:
        print(f"ERROR: unknown phases: {unknown}. Available: {list(_PHASE_MAP)}")
        sys.exit(1)

    run_id = uuid.uuid4().hex[:6]
    summary: list[dict] = []

    print("=" * 60)
    print("Benchmark regression curve e2e")
    print(f"  agent:    {args.agent_name}")
    print(f"  provider: {args.provider}")
    print(f"  phases:   {selected_phases}")
    print(f"  run_id:   {run_id}")
    print("=" * 60)

    phase_shas: dict[str, str] = {}
    for phase_name in selected_phases:
        _, branch, fault = _PHASE_MAP[phase_name]
        commit_sha = f"benchmark_{phase_name}_{run_id}"
        phase_shas[phase_name] = commit_sha

        results = _run_phase(
            phase_name=phase_name,
            branch=branch,
            fault=fault,
            commit_sha=commit_sha,
            api_key=api_key,
            base_url=args.backend_url,
            agent_name=args.agent_name,
            environment=args.environment,
            provider=args.provider,
            workload=args.workload,
        )

        success_count = sum(1 for r in results if r.get("success", False))
        summary.append({
            "phase": phase_name,
            "commit_sha": commit_sha,
            "fault_config": {
                "tool_fail_rate": fault.tool_fail_rate,
                "tool_latency_ms": fault.tool_latency_ms,
                "token_inflation_chars": fault.token_inflation_chars,
                "prompt_corruption_rate": fault.prompt_corruption_rate,
                "response_truncation_rate": fault.response_truncation_rate,
                "model": fault.model,
            },
            "total_tasks": len(results),
            "success_count": success_count,
            "success_rate": success_count / max(len(results), 1),
        })

        if phase_name != selected_phases[-1]:
            _wait_for_flush(args.flush_wait)

    print("\n" + "=" * 80)
    print("Regression curve summary:")
    print(f"  {'Phase':<14} {'ToolFail':>8} {'Latency':>8} {'Inflate':>8} "
          f"{'Corrupt':>8} {'Trunc':>8} {'Success':>8}")
    print(f"  {'-'*14} {'-'*8} {'-'*8} {'-'*8} {'-'*8} {'-'*8} {'-'*8}")
    for s in summary:
        fc = s["fault_config"]
        print(f"  {s['phase']:<14} {fc['tool_fail_rate']:>7.0%} "
              f"{fc['tool_latency_ms']:>7.0f} {fc['token_inflation_chars']:>8} "
              f"{fc['prompt_corruption_rate']:>7.0%} "
              f"{fc['response_truncation_rate']:>7.0%} "
              f"{s['success_rate']:>7.0%}")
    print("=" * 80)
    print("\nCommit SHAs for regression detector:")
    for s in summary:
        print(f"  {s['phase']}: {s['commit_sha']}")

    if args.out:
        with open(args.out, "w") as f:
            json.dump({"run_id": run_id, "phases": summary}, f, indent=2)
        print(f"\nSummary written to {args.out}")


if __name__ == "__main__":
    main()
