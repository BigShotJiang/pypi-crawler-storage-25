"""Generates realistic LLM-backed traces for self-heal regression testing.

Runs persona scenarios tagged with two different VCS commit SHAs to produce
a detectable regression signal across three metrics:

  Good commit  -- happy-path scenarios from 3 personas
    customer_support / billing_inquiry      single-turn support, ~800 tokens, 0% errors
    finance_ops / payment_under_limit       single-payment pipeline, ~1200 tokens, 0% errors
    sales_agent / clean_sequence            7-tool SDR sequence, ~1000 tokens, 0% errors

  Bad commit   -- failure / regression scenarios from the same 3 personas
    customer_support / amnesia              8-turn context loss, ~10K tokens
    finance_ops / cumulative_evasion        8 payments, cumulative evasion, ~12K tokens
    sales_agent / enrichment_blackout       enrichment API down, ~60% session errors,
                                            ~60% tool_error_rate, high retry token spend

Good/bad delta drives all three regression detector thresholds:
  error_rate:        ~0% good vs ~55% bad   (2x threshold: 2.0)
  avg_total_tokens:  ~1K good vs ~11K bad   (1.5x threshold: already 11x)
  tool_error_rate:   ~0% good vs ~60% bad   (2x threshold: 2.0)

Designed to be run ONCE and cached. Subsequent self-heal test runs reuse
the commit SHAs from cache without re-ingesting.
"""
from __future__ import annotations

from personas.customer_support.harness import run_scenario as cs_scenario
from personas.finance_ops.harness import run_scenario as fo_scenario
from personas.sales_agent.harness import run_scenario as sa_scenario

# Each entry: (run_fn, scenario_name)
_GOOD_SCENARIOS = [
    (cs_scenario, "billing_inquiry"),
    (fo_scenario, "payment_under_limit"),
    (sa_scenario, "clean_sequence"),
]

_BAD_SCENARIOS = [
    (cs_scenario, "amnesia"),
    (fo_scenario, "cumulative_evasion"),
    (sa_scenario, "enrichment_blackout"),
]


def _run_scenarios(
    label: str,
    scenarios: list[tuple],
    provider: str,
    env: str,
    repeat: int,
) -> list[dict]:
    total = repeat * len(scenarios)
    done = 0
    results = []
    for i in range(repeat):
        round_ok = 0
        round_fail = 0
        for run_fn, scenario in scenarios:
            print(f"[{label}]   {scenario}...", end=" ", flush=True)
            try:
                result = run_fn(scenario, provider=provider, env=env)
                results.append(result)
                round_ok += 1
                print("ok", flush=True)
            except Exception as exc:
                round_fail += 1
                print(f"FAIL: {exc}", flush=True)
            done += 1
        status = f"ok={round_ok}"
        if round_fail:
            status += f" fail={round_fail}"
        print(f"[{label}] round {i + 1}/{repeat} complete ({status}) | {done}/{total} total", flush=True)
    return results


def generate_good_traces(provider: str, env: str, repeat: int = 15) -> list[dict]:
    """Run all good-commit scenarios `repeat` times each.

    Returns list of scenario result dicts. Failed runs are skipped with a log.
    Total traces target = repeat * 3 scenarios.
    """
    return _run_scenarios("good", _GOOD_SCENARIOS, provider, env, repeat)


def generate_bad_traces(provider: str, env: str, repeat: int = 15) -> list[dict]:
    """Run all bad-commit scenarios `repeat` times each.

    Returns list of scenario result dicts. The enrichment_blackout scenario
    catches session-level exceptions internally so they appear in results even
    when the session was marked as error in ClickHouse.

    Total traces target = repeat * 3 scenarios.
    """
    return _run_scenarios("bad", _BAD_SCENARIOS, provider, env, repeat)


def trace_count(results: list[dict]) -> int:
    return len(results)


# ─── Workload-driven multi-commit regression curve ───────────────────────


def generate_workload_traces(
    fault: "FaultConfig",
    provider: str,
    env: str,
    task_path: str | None = None,
    workload: str = "bfcl",
) -> list[dict]:
    """Run workload tasks once with the given fault config.

    workload: "bfcl" (single-turn) or "taubench" (multi-turn).

    Each task produces one scenario_result dict. The same task set is run
    across multiple commit phases (each with a different FaultConfig) to
    produce a measurable regression curve.

    task_path: override the default bundled data file.
    """
    if workload == "taubench":
        from self_heal.workloads import load_taubench_tasks, run_multi_turn_task
        tasks = load_taubench_tasks(task_path)
        run_fn = run_multi_turn_task
    else:
        from self_heal.workloads import load_bfcl_tasks, run_single_turn_task
        tasks = load_bfcl_tasks(task_path)
        run_fn = run_single_turn_task

    label = workload
    results = []
    total = len(tasks)
    for i, task in enumerate(tasks, start=1):
        print(f"[{label}]   {task.task_id}...", end=" ", flush=True)
        try:
            result = run_fn(task, fault, provider, env)
            results.append(result)
            ok = result.get("success", False)
            print("ok" if ok else "wrong", flush=True)
        except Exception as exc:
            print(f"FAIL: {exc}", flush=True)
        if i % 5 == 0 or i == total:
            done_ok = sum(1 for r in results if r.get("success", False))
            print(f"[{label}] {i}/{total} tasks ({done_ok} correct)", flush=True)
    return results


# Back-compat alias
generate_benchmark_traces = generate_workload_traces
