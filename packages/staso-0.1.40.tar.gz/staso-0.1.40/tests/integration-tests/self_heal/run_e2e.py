#!/usr/bin/env python3
"""Self-heal e2e test: ingest LLM-backed traces on two VCS commits, trigger regression detection.

Usage:
    python run_e2e.py --help

    # Minimal (uses .env defaults)
    python run_e2e.py

    # Custom
    python run_e2e.py \
        --agent-name my-agent \
        --backend-url http://localhost:8000 \
        --repeat 15 \
        --provider openai

This script re-initialises the SDK twice (good commit, bad commit) so each
batch of traces carries a distinct VCS commit SHA. Each phase runs real LLM
persona scenarios:

  Good commit: billing_inquiry + payment_under_limit + baseline_workflow
  Bad commit:  amnesia + cumulative_evasion + tool_regression

It then waits for ClickHouse flush and triggers self-heal detection via the
internal backend API (/internal/self-heal/detect or /internal/self-heal/inject).
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import uuid

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

# Load .env from integration-tests/ if present
_ENV_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".env")
if os.path.exists(_ENV_FILE):
    with open(_ENV_FILE) as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                _k, _, _v = _line.partition("=")
                os.environ.setdefault(_k.strip(), _v.strip())

import httpx
import staso as st

from self_heal.pipeline_client import SelfHealPipelineClient
from self_heal.trace_generator import generate_bad_traces, generate_good_traces, trace_count


def _phase(
    label: str,
    api_key: str,
    base_url: str,
    agent_name: str,
    environment: str,
    commit_sha: str,
    branch: str,
    provider: str,
    repeat: int,
) -> list[dict]:
    print(f"\n[{label}] commit={commit_sha[:12]} repeat={repeat} provider={provider}")
    os.environ["STASO_VCS_COMMIT_SHA"] = commit_sha
    os.environ["STASO_VCS_BRANCH"] = branch
    st.init(
        api_key=api_key,
        agent_name=agent_name,
        base_url=base_url,
        environment=environment,
        capture_git=True,
        debug=False,
    )
    try:
        generator = generate_good_traces if label == "good" else generate_bad_traces
        results = generator(provider=provider, env=environment, repeat=repeat)
        print(f"[{label}] Generated {trace_count(results)} traces. Flushing...")
        return results
    finally:
        st.shutdown()
        os.environ.pop("STASO_VCS_COMMIT_SHA", None)
        os.environ.pop("STASO_VCS_BRANCH", None)


def _wait_for_flush(seconds: int) -> None:
    print(f"\nWaiting {seconds}s for ClickHouse flush...")
    for i in range(seconds, 0, -5):
        print(f"  {i}s remaining...")
        time.sleep(min(5, i))



def _trigger_detection(backend_url: str, org_id: str | None) -> dict:
    url = f"{backend_url}/internal/self-heal/detect"
    payload = {}
    if org_id:
        payload["org_id"] = org_id
    print(f"\nTriggering detection: POST {url}")
    resp = httpx.post(url, json=payload or None, timeout=60)
    resp.raise_for_status()
    return resp.json()


def main() -> None:
    parser = argparse.ArgumentParser(description="Self-heal e2e test (real LLM traces)")
    parser.add_argument("--agent-name", default="selfheal-e2e-agent")
    parser.add_argument(
        "--backend-url",
        default=os.environ.get("STASO_BASE_URL", "http://localhost:8000"),
    )
    parser.add_argument(
        "--environment",
        default=os.environ.get("STASO_ENVIRONMENT", "staging"),
    )
    parser.add_argument("--provider", default="openai", choices=["openai", "anthropic"])
    parser.add_argument("--org-id", default=None, help="Org UUID")
    parser.add_argument("--workspace-id", default=None, help="Workspace UUID for inject mode")
    parser.add_argument(
        "--repeat",
        type=int,
        default=15,
        help="Times to run each scenario per commit (total = repeat * 3 scenarios)",
    )
    parser.add_argument(
        "--flush-wait",
        type=int,
        default=15,
        help="Seconds to wait for ClickHouse flush after ingestion",
    )
    parser.add_argument(
        "--mode",
        choices=["detect", "inject"],
        default="inject",
        help="detect=run full cron scan, inject=push event directly to pipeline",
    )
    parser.add_argument(
        "--pipeline-timeout",
        type=int,
        default=180,
        help="Seconds to wait for the worker to produce a diagnosis after inject",
    )
    args = parser.parse_args()

    api_key = os.environ.get("STASO_API_KEY", "")
    if not api_key:
        print("ERROR: STASO_API_KEY not set")
        sys.exit(1)

    run_id = uuid.uuid4().hex[:6]
    good_sha = f"selfheal_good_{run_id}"
    bad_sha = f"selfheal_bad_{run_id}"

    print("=" * 60)
    print("Self-heal e2e test (real LLM traces)")
    print(f"  agent:      {args.agent_name}")
    print(f"  provider:   {args.provider}")
    print(f"  good_sha:   {good_sha}")
    print(f"  bad_sha:    {bad_sha}")
    print(f"  backend:    {args.backend_url}")
    print(f"  mode:       {args.mode}")
    print(f"  repeat:     {args.repeat} runs x 3 scenarios = {args.repeat * 3} traces/commit")
    print("=" * 60)

    good_results = _phase(
        label="good",
        api_key=api_key,
        base_url=args.backend_url,
        agent_name=args.agent_name,
        environment=args.environment,
        commit_sha=good_sha,
        branch="main",
        provider=args.provider,
        repeat=args.repeat,
    )

    bad_results = _phase(
        label="bad",
        api_key=api_key,
        base_url=args.backend_url,
        agent_name=args.agent_name,
        environment=args.environment,
        commit_sha=bad_sha,
        branch="main",
        provider=args.provider,
        repeat=args.repeat,
    )

    print(f"\nIngestion complete: {trace_count(good_results)} good + {trace_count(bad_results)} bad traces")

    _wait_for_flush(args.flush_wait)

    if args.mode == "inject":
        org_id = args.org_id or os.environ.get("STASO_ORG_ID", "")
        workspace_id = args.workspace_id or os.environ.get("STASO_WORKSPACE_ID", "")
        environment = args.environment
        if not org_id:
            print("\nERROR: --org-id required for inject mode (or set STASO_ORG_ID)")
            sys.exit(1)
        if not workspace_id:
            print("\nERROR: --workspace-id required for inject mode (or set STASO_WORKSPACE_ID)")
            sys.exit(1)

        client = SelfHealPipelineClient(
            base_url=args.backend_url,
            org_id=org_id,
            workspace_id=workspace_id,
            environment=environment,
            agent_name=args.agent_name,
        )

        inject_result = client.inject(good_sha=good_sha, bad_sha=bad_sha)
        print(f"Injected: {json.dumps(inject_result, indent=2, default=str)}")
        print(f"\nPolling for diagnosis (timeout={args.pipeline_timeout}s)...")

        diagnosis = client.poll_result(
            bad_sha=bad_sha,
            timeout=args.pipeline_timeout,
            interval=10,
        )

        if diagnosis is None:
            print("\nTIMEOUT: No diagnosis produced within timeout.")
            print("Check backend logs for: evidence collection -> diagnosis -> dispatch")
            sys.exit(1)

        print(f"\nDiagnosis result:")
        print(json.dumps(diagnosis, indent=2, default=str))
        root_cause = diagnosis.get("root_cause", "unknown")
        confidence = diagnosis.get("confidence", 0.0)
        passed = root_cause != "unknown" and confidence >= 0.5
        print(f"\n{'PASS' if passed else 'WARN'}: root_cause={root_cause} confidence={confidence:.0%}")
    else:
        result = _trigger_detection(args.backend_url, args.org_id)
        print(f"\nDetection result:\n{json.dumps(result, indent=2, default=str)}")
        regressions = result.get("regressions_detected", 0)
        print(f"\n{'PASS' if regressions > 0 else 'MISS'}: {regressions} regression(s) detected")


if __name__ == "__main__":
    main()
