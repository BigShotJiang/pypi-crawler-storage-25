#!/usr/bin/env python3
"""Generate a single fault-injected trace and print its trace_id for diagnosis testing.

Usage:
    cd tests/integration-tests
    python self_heal/gen_fault_trace.py

    # Custom fault
    python self_heal/gen_fault_trace.py --fail-rate 1.0 --task-index 0 --provider openai

Output:
    trace_id=<uuid>   (ready to pass to the diagnosis API)

Then diagnose:
    curl -X POST http://localhost:8000/v1/traces/<trace_id>/diagnose \\
      -H "Authorization: Bearer <jwt>" \\
      -H "X-Org-Id: <org_id>" \\
      -H "Content-Type: application/json" \\
      -d '{"user_hint": "why did the tool fail?"}'
"""
from __future__ import annotations

import argparse
import os
import sys
import time

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

_ENV_FILE = os.path.join(_ROOT, ".env")
if os.path.exists(_ENV_FILE):
    with open(_ENV_FILE) as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                _k, _, _v = _line.partition("=")
                os.environ.setdefault(_k.strip(), _v.strip())

import httpx
import staso as st

from self_heal.workloads.bfcl import load_tasks, run_benchmark_task
from self_heal.workloads.fault import FaultConfig


def _get_trace_id(backend_url: str, session_id: str, jwt: str, org_id: str, retries: int = 6) -> str | None:
    """Query traces list by session_id to get the trace_id after flush."""
    headers = {"Authorization": f"Bearer {jwt}", "X-Org-Id": org_id}
    for attempt in range(retries):
        try:
            resp = httpx.get(
                f"{backend_url}/v1/traces",
                params={"session_id": session_id, "limit": 5},
                headers=headers,
                timeout=10,
            )
            resp.raise_for_status()
            traces = resp.json().get("traces", [])
            if traces:
                return traces[0]["trace_id"]
        except Exception as e:
            print(f"  poll attempt {attempt + 1}/{retries}: {e}")
        time.sleep(3)
    return None


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a fault-injected trace for diagnosis testing")
    parser.add_argument("--fail-rate", type=float, default=0.8, help="Tool failure rate (0.0-1.0)")
    parser.add_argument("--latency-ms", type=float, default=0.0, help="Tool latency injection (ms)")
    parser.add_argument("--task-index", type=int, default=0, help="Which BFCL task to run")
    parser.add_argument("--provider", default="openai", choices=["openai", "anthropic"])
    parser.add_argument(
        "--backend-url",
        default=os.environ.get("STASO_BASE_URL", "http://localhost:8000"),
    )
    parser.add_argument("--environment", default=os.environ.get("STASO_ENVIRONMENT", "staging"))
    parser.add_argument("--flush-wait", type=int, default=10, help="Seconds to wait for ClickHouse flush")
    args = parser.parse_args()

    api_key = os.environ.get("STASO_API_KEY", "")
    jwt = os.environ.get("STASO_JWT", "") or api_key
    org_id = os.environ.get("STASO_ORG_ID", "")

    if not api_key:
        print("ERROR: STASO_API_KEY not set")
        sys.exit(1)

    st.init(
        api_key=api_key,
        base_url=args.backend_url,
        environment=args.environment,
        agent_name="fault-trace-gen",
        debug=False,
    )

    tasks = load_tasks()
    task = tasks[args.task_index]
    fault = FaultConfig(
        tool_fail_rate=args.fail_rate,
        tool_latency_ms=args.latency_ms,
        seed=42,
    )

    print(f"Running task: {task.task_id}")
    print(f"Fault config: fail_rate={fault.tool_fail_rate} latency_ms={fault.tool_latency_ms}")

    result = run_benchmark_task(task, fault, provider=args.provider, env=args.environment)
    session_id = result["session_id"]

    print(f"Task done. session_id={session_id} success={result.get('success')} errors={result.get('tool_error_count')}")
    print(f"Flushing traces (waiting {args.flush_wait}s)...")

    st.shutdown()
    time.sleep(args.flush_wait)

    print("Querying backend for trace_id...")
    trace_id = _get_trace_id(args.backend_url, session_id, jwt, org_id)

    if trace_id:
        print(f"\ntrace_id={trace_id}")
        print(f"\nDiagnose with:")
        print(f'  curl -X POST {args.backend_url}/v1/traces/{trace_id}/diagnose \\')
        print(f'    -H "Authorization: Bearer $STASO_JWT" \\')
        print(f'    -H "X-Org-Id: {org_id}" \\')
        print(f'    -H "Content-Type: application/json" \\')
        print(f"    -d '{{\"user_hint\": \"tool failures during function calling\"}}'")
    else:
        print(f"\nCould not find trace_id. Check dashboard for session_id={session_id}")
        print("Traces may still be flushing — try again or increase --flush-wait")


if __name__ == "__main__":
    main()
