"""Fault injection primitives for workload-driven regression testing.

FaultConfig describes how to degrade agent behavior to simulate a commit regression.
Running the same tasks with progressively worse FaultConfigs produces a multi-commit
regression curve: good -> slight -> moderate -> bad.

Supported fault types:
  tool_fail_rate        -- tool calls raise RuntimeError at this probability
  tool_latency_ms       -- artificial delay injected before each tool call
  token_inflation_chars -- padding text prepended to system prompt (inflates token usage)
  prompt_corruption_rate-- probability of dropping a sentence from system prompt
  response_truncation_rate -- probability of truncating a tool response to max_chars
  response_max_chars    -- max chars when truncation fires
  model                 -- override the LLM model (simulates model drift / downgrade)
"""
from __future__ import annotations

import random
import re
import time
from dataclasses import dataclass
from typing import Callable

# Filler text used for token inflation -- realistic-looking but semantically empty
_PADDING_BLOCK = (
    "The following context is provided for reference. "
    "Please review all available information carefully before proceeding. "
    "Consider edge cases and potential failure modes in your analysis. "
    "Ensure consistency with prior instructions and maintain accuracy. "
)  # ~50 tokens / ~200 chars per block


@dataclass
class FaultConfig:
    """Controls how agent behavior is degraded for a given commit phase.

    tool_fail_rate:          fraction of tool calls that raise RuntimeError (0.0-1.0)
    tool_latency_ms:         artificial delay (ms) injected before each tool call
    token_inflation_chars:   chars of padding prepended to system prompt (0 = none)
    prompt_corruption_rate:  fraction of system prompt sentences randomly dropped (0.0-1.0)
    response_truncation_rate: fraction of tool responses truncated (0.0-1.0)
    response_max_chars:      max chars when truncation fires (default 50)
    model:                   override the provider's default model (None = keep default)
    seed:                    random seed for reproducible fault injection
    """
    tool_fail_rate: float = 0.0
    tool_latency_ms: float = 0.0
    token_inflation_chars: int = 0
    prompt_corruption_rate: float = 0.0
    response_truncation_rate: float = 0.0
    response_max_chars: int = 50
    model: str | None = None
    seed: int | None = None

    def should_fail(self, rng: random.Random) -> bool:
        return rng.random() < self.tool_fail_rate

    def should_truncate(self, rng: random.Random) -> bool:
        return rng.random() < self.response_truncation_rate


def corrupt_prompt(prompt: str, fault: FaultConfig, rng: random.Random) -> str:
    """Drop sentences from prompt at fault.prompt_corruption_rate probability.

    Splits on sentence boundaries (period/exclamation/question + space/end).
    Each sentence is independently dropped. At least one sentence always survives.
    """
    if fault.prompt_corruption_rate <= 0:
        return prompt
    sentences = re.split(r'(?<=[.!?])\s+', prompt)
    if len(sentences) <= 1:
        return prompt
    kept = [s for s in sentences if rng.random() >= fault.prompt_corruption_rate]
    if not kept:
        kept = [rng.choice(sentences)]
    return " ".join(kept)


def inflate_prompt(prompt: str, fault: FaultConfig) -> str:
    """Prepend padding text to inflate token usage.

    Repeats _PADDING_BLOCK until token_inflation_chars target is reached.
    """
    if fault.token_inflation_chars <= 0:
        return prompt
    repeats = (fault.token_inflation_chars // len(_PADDING_BLOCK)) + 1
    padding = (_PADDING_BLOCK * repeats)[:fault.token_inflation_chars]
    return padding + "\n\n" + prompt


def make_faulty_tool_map(
    tool_map: dict[str, Callable],
    fault: FaultConfig,
) -> dict[str, Callable]:
    """Wrap each tool in tool_map to inject faults.

    Supports: tool_fail_rate, tool_latency_ms, response_truncation_rate.
    Returns a new dict -- does not mutate the original.
    """
    rng = random.Random(fault.seed)

    def _wrap(fn: Callable) -> Callable:
        def wrapper(**kwargs):  # type: ignore[no-untyped-def]
            # Latency injection
            if fault.tool_latency_ms > 0:
                time.sleep(fault.tool_latency_ms / 1000.0)

            # Failure injection
            if fault.should_fail(rng):
                raise RuntimeError("Tool execution failed (injected fault)")

            result = fn(**kwargs)

            # Response truncation
            if fault.should_truncate(rng):
                if isinstance(result, dict):
                    truncated = str(result)[:fault.response_max_chars]
                    return {"truncated": truncated, "_fault": "response_truncation"}
                elif isinstance(result, str):
                    return result[:fault.response_max_chars]

            return result
        wrapper.__name__ = fn.__name__
        return wrapper

    return {name: _wrap(fn) for name, fn in tool_map.items()}
