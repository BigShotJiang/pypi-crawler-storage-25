"""Task definitions for workload-driven regression testing.

Two task types:

  SingleTurnTask -- one user message, one expected tool call (BFCL-style).
  MultiTurnTask  -- multi-turn conversation with user simulation, stateful
                    tools, and state-based evaluation (tau-bench-style).

Both work with FaultConfig for fault injection and produce scenario_result()
dicts for the trace pipeline.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# Single-turn (BFCL-style)
# ---------------------------------------------------------------------------

@dataclass
class SingleTurnTask:
    """A single-turn function-calling task.

    tools uses the canonical format:
        {"name": str, "description": str, "parameters": {json schema}}
    expected_function is the function the agent MUST call to succeed.
    expected_args_subset is a dict of key->value pairs that must appear
    in the agent's tool call arguments (partial match, string comparison).
    """
    task_id: str
    user_message: str
    tools: list[dict]
    expected_function: str
    expected_args_subset: dict = field(default_factory=dict)
    category: str = "simple"
    source: str = "bfcl"


# ---------------------------------------------------------------------------
# Multi-turn (tau-bench-style)
# ---------------------------------------------------------------------------

@dataclass
class ExpectedAction:
    """A single expected tool call in a multi-turn task.

    Matches tau-bench's Action(name, kwargs) format.
    """
    name: str
    kwargs: dict[str, Any] = field(default_factory=dict)


@dataclass
class MultiTurnTask:
    """A multi-turn conversation task with stateful tool evaluation.

    Designed to adapt tau-bench retail/airline tasks and persona-derived
    multi-turn scenarios into a common format.

    Fields:
      task_id:           unique identifier
      instruction:       user's goal description (fed to user simulator)
      tools:             canonical tool definitions (same format as SingleTurnTask)
      initial_state:     snapshot of database/state before the task runs
      expected_actions:  ordered list of tool calls the agent should make
      expected_outputs:  strings that must appear in agent's final responses
      domain:            source domain (retail, airline, persona, etc.)
      max_turns:         safety limit on conversation turns
      user_id:           reference user in the initial_state database (tau-bench)
      wiki:              domain knowledge / policy text the agent's system prompt
                         should reference (tau-bench's wiki.md equivalent)
      source:            which benchmark/framework this task came from
    """
    task_id: str
    instruction: str
    tools: list[dict]
    initial_state: dict[str, Any] = field(default_factory=dict)
    expected_actions: list[ExpectedAction] = field(default_factory=list)
    expected_outputs: list[str] = field(default_factory=list)
    domain: str = "general"
    max_turns: int = 20
    user_id: str = ""
    wiki: str = ""
    source: str = "taubench"
