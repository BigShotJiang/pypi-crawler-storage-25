"""Tau-bench adapter for multi-turn workload tasks.

Converts tau-bench retail/airline tasks into MultiTurnTask format and runs
them through the LLM loop with user simulation, stateful tools, and
state-based evaluation.

Tau-bench task anatomy:
  - instruction: natural language user goal (fed to user simulator LLM)
  - actions: ground truth tool calls the agent should make
  - outputs: strings that must appear in agent responses
  - tools: stateful tools that read/write an in-memory database
  - evaluation: database hash comparison (did agent reach correct final state?)

Our adapter:
  - Converts tau-bench Task -> MultiTurnTask
  - Implements a lightweight LLM user simulator (generates user turns)
  - Runs stateful tools against an in-memory state dict
  - Evaluates via expected_actions matching (ordered) + output string matching
  - Applies FaultConfig at tool + prompt level
"""
from __future__ import annotations

import copy
import json
import os
import random as _random
from typing import Any

import staso as st

from personas.common import TokenUsage, make_session_id, scenario_result
from personas.common.provider import (
    LLMResponse,
    ToolCall,
    append_to_history,
    execute_tools,
    get_llm_client,
    llm_chat,
    tools_for_provider,
)

from .fault import FaultConfig, corrupt_prompt, inflate_prompt, make_faulty_tool_map
from .task import ExpectedAction, MultiTurnTask

_DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

_USER_SIM_SYSTEM = """You are simulating a customer in a conversation with a support agent.
Your goal is described below. Generate realistic, natural messages one at a time.
Do not reveal all details upfront -- share information as the agent asks for it.
Do not fabricate information not in your instructions.
When your goal is fully achieved, respond with exactly: ###STOP###

Your goal:
{instruction}"""

_AGENT_SYSTEM = """You are a helpful customer service agent. Follow the company policy below.
Use the available tools to help the customer. Be concise and professional.

{wiki}"""


def _load_from_taubench(
    domain: str = "retail",
    split: str = "dev",
    limit: int | None = None,
) -> list[MultiTurnTask]:
    """Auto-import tasks directly from the tau-bench package.

    Requires: pip install tau-bench
    Reads task definitions, tool schemas, database state, and wiki/policy
    from tau-bench's Python modules and converts to MultiTurnTask on the fly.
    """
    # Import tau-bench environment
    if domain == "retail":
        from tau_bench.envs.retail.tasks_dev import TASKS as dev_tasks
        from tau_bench.envs.retail.tasks_test import TASKS as test_tasks
        from tau_bench.envs.retail.tasks import TASKS as all_tasks
        from tau_bench.envs.retail import tools as retail_tools_mod
        from tau_bench.envs.retail.wiki import WIKI
        from tau_bench.envs.retail.data import load_data
    elif domain == "airline":
        from tau_bench.envs.airline.tasks_dev import TASKS as dev_tasks
        from tau_bench.envs.airline.tasks_test import TASKS as test_tasks
        from tau_bench.envs.airline.tasks import TASKS as all_tasks
        from tau_bench.envs.airline import tools as retail_tools_mod
        from tau_bench.envs.airline.wiki import WIKI
        from tau_bench.envs.airline.data import load_data
    else:
        raise ValueError(f"Unknown tau-bench domain: {domain}")

    # Pick split
    task_list = {"dev": dev_tasks, "test": test_tasks, "all": all_tasks}[split]
    if limit:
        task_list = task_list[:limit]

    # Extract tool schemas via get_info()
    tool_classes = [
        getattr(retail_tools_mod, name)
        for name in dir(retail_tools_mod)
        if hasattr(getattr(retail_tools_mod, name), "get_info")
    ]
    tool_schemas = [cls.get_info() for cls in tool_classes]
    # Normalize to canonical format (strip OpenAI wrapper if present)
    canonical_tools = []
    for schema in tool_schemas:
        if "function" in schema:
            fn = schema["function"]
            canonical_tools.append({
                "name": fn["name"],
                "description": fn.get("description", ""),
                "parameters": fn.get("parameters", {}),
            })
        else:
            canonical_tools.append(schema)

    # Load database state
    db_state = load_data()

    # Convert each tau-bench Task to MultiTurnTask
    tasks = []
    for i, task in enumerate(task_list):
        actions = []
        for action in task.actions:
            # tau-bench uses either .arguments (dict) or .kwargs (Pydantic)
            kwargs = {}
            if hasattr(action, "kwargs") and action.kwargs:
                kwargs = dict(action.kwargs) if hasattr(action.kwargs, "__dict__") else action.kwargs
            elif hasattr(action, "arguments") and action.arguments:
                kwargs = action.arguments
            actions.append(ExpectedAction(name=action.name, kwargs=kwargs))

        tasks.append(MultiTurnTask(
            task_id=f"{domain}_{split}_{i:03d}",
            instruction=task.instruction,
            tools=canonical_tools,
            initial_state=copy.deepcopy(db_state),
            expected_actions=actions,
            expected_outputs=getattr(task, "outputs", []) or [],
            domain=domain,
            max_turns=20,
            user_id=getattr(task, "user_id", ""),
            wiki=WIKI if isinstance(WIKI, str) else "",
            source="taubench",
        ))
    return tasks


def _load_from_json(path: str) -> list[MultiTurnTask]:
    """Load tasks from a pre-curated JSON file (fallback)."""
    with open(path) as f:
        raw = json.load(f)
    return [
        MultiTurnTask(
            task_id=t["task_id"],
            instruction=t["instruction"],
            tools=t["tools"],
            initial_state=t.get("initial_state", {}),
            expected_actions=[
                ExpectedAction(name=a["name"], kwargs=a.get("kwargs", {}))
                for a in t.get("expected_actions", [])
            ],
            expected_outputs=t.get("expected_outputs", []),
            domain=t.get("domain", "retail"),
            max_turns=t.get("max_turns", 20),
            user_id=t.get("user_id", ""),
            wiki=t.get("wiki", ""),
            source="taubench",
        )
        for t in raw
    ]


def load_tasks(
    path: str | None = None,
    domain: str = "retail",
    split: str = "dev",
    limit: int | None = None,
) -> list[MultiTurnTask]:
    """Load tau-bench tasks. Auto-imports from the package if installed,
    falls back to a pre-curated JSON file.

    Args:
        path:   explicit JSON file path (skips auto-import)
        domain: tau-bench domain ("retail" or "airline")
        split:  task split ("dev", "test", "all")
        limit:  max number of tasks to load (None = all)
    """
    # Explicit JSON path
    if path:
        return _load_from_json(path)

    # Try auto-import from tau-bench package
    try:
        return _load_from_taubench(domain=domain, split=split, limit=limit)
    except ImportError:
        pass

    # Fallback to bundled JSON (if it exists)
    fallback = os.path.join(_DATA_DIR, f"taubench_{domain}.json")
    if os.path.exists(fallback):
        return _load_from_json(fallback)

    raise RuntimeError(
        f"tau-bench not installed and no fallback JSON found at {fallback}. "
        f"Install with: pip install tau-bench"
    )


def _user_sim_turn(
    client: Any,
    provider: str,
    user_messages: list[dict],
    instruction: str,
    model: str | None = None,
) -> tuple[str, TokenUsage]:
    """Generate one user simulator turn via LLM."""
    system = _USER_SIM_SYSTEM.format(instruction=instruction)
    resp: LLMResponse = llm_chat(
        client=client,
        provider=provider,
        messages=user_messages,
        system=system,
        tools=[],
        model=model,
        max_tokens=256,
        temperature=0.7,
    )
    content = resp.content or ""
    return content, resp.usage


def _load_native_tool_map(
    domain: str,
    state: dict[str, Any],
) -> dict[str, Any] | None:
    """Try to load tau-bench's native tool implementations.

    Native tools mutate state in-place (matching tau-bench's evaluation model).
    Returns None if tau-bench is not installed.
    """
    try:
        if domain == "retail":
            from tau_bench.envs.retail import tools as tools_mod
        elif domain == "airline":
            from tau_bench.envs.airline import tools as tools_mod
        else:
            return None
    except ImportError:
        return None

    tool_classes = [
        getattr(tools_mod, name)
        for name in dir(tools_mod)
        if hasattr(getattr(tools_mod, name), "invoke")
        and hasattr(getattr(tools_mod, name), "get_info")
    ]

    tool_map = {}
    for cls in tool_classes:
        info = cls.get_info()
        name = info.get("function", info).get("name", "") if "function" in info else info.get("name", "")
        if not name:
            continue

        def _make_native(tool_cls=cls):
            def wrapper(**kwargs):
                state.setdefault("_actions_taken", []).append(
                    {"name": name, "kwargs": kwargs}
                )
                return tool_cls.invoke(state, **kwargs)
            wrapper.__name__ = name
            return wrapper

        tool_map[name] = _make_native()
    return tool_map


def _build_stub_tool_map(
    tools: list[dict],
    state: dict[str, Any],
) -> dict[str, Any]:
    """Build stub tool map (fallback when tau-bench is not installed).

    Stubs record actions in state and return success responses.
    Less accurate than native tools but sufficient for fault injection testing.
    """
    def _make_stub(name: str):
        def stub(**kwargs):
            state.setdefault("_actions_taken", []).append(
                {"name": name, "kwargs": kwargs}
            )
            return {
                "status": "success",
                "tool": name,
                "args": kwargs,
                "message": f"Action '{name}' completed successfully.",
            }
        stub.__name__ = name
        return stub

    return {t["name"]: _make_stub(t["name"]) for t in tools}


def _build_stateful_tool_map(
    tools: list[dict],
    state: dict[str, Any],
    domain: str = "retail",
) -> dict[str, Any]:
    """Build tool map -- uses tau-bench native tools if available, stubs otherwise."""
    native = _load_native_tool_map(domain, state)
    if native:
        return native
    return _build_stub_tool_map(tools, state)


def evaluate(
    state: dict[str, Any],
    task: MultiTurnTask,
    agent_responses: list[str],
) -> tuple[bool, dict]:
    """Evaluate a multi-turn task result.

    Checks:
    1. Action matching: did the agent call the right tools with right args?
    2. Output matching: do expected strings appear in agent responses?

    Returns (success, details_dict).
    """
    actions_taken = state.get("_actions_taken", [])
    details: dict[str, Any] = {
        "actions_taken": actions_taken,
        "actions_expected": [
            {"name": a.name, "kwargs": a.kwargs}
            for a in task.expected_actions
        ],
    }

    # Action matching: check expected actions appear in order
    action_match = True
    if task.expected_actions:
        taken_idx = 0
        for expected in task.expected_actions:
            found = False
            while taken_idx < len(actions_taken):
                taken = actions_taken[taken_idx]
                taken_idx += 1
                if taken["name"] == expected.name:
                    # Check kwargs subset match
                    kwargs_match = all(
                        str(v).lower() in str(taken["kwargs"].get(k, "")).lower()
                        for k, v in expected.kwargs.items()
                    )
                    if kwargs_match:
                        found = True
                        break
            if not found:
                action_match = False
                break
    details["action_match"] = action_match

    # Output matching: check expected strings in agent responses
    combined_responses = " ".join(agent_responses).lower()
    output_match = all(
        exp.lower() in combined_responses
        for exp in task.expected_outputs
    ) if task.expected_outputs else True
    details["output_match"] = output_match

    success = action_match and output_match
    return success, details


def run_multi_turn_task(
    task: MultiTurnTask,
    fault: FaultConfig,
    provider: str,
    env: str,
) -> dict:
    """Run a multi-turn task with user simulation and fault injection.

    Flow per turn:
      1. User simulator generates a user message (LLM-based)
      2. Agent processes message, may call tools (with fault injection)
      3. Tool results feed back into agent
      4. Agent responds to user
      5. Repeat until user says ###STOP### or max_turns reached

    Returns scenario_result()-compatible dict.
    """
    rng = _random.Random(fault.seed)

    session_id = make_session_id("taubench", task.task_id)
    client = get_llm_client(provider)
    provider_tools = tools_for_provider(task.tools, provider)

    # Stateful tools + fault injection
    state = copy.deepcopy(task.initial_state)
    base_tool_map = _build_stateful_tool_map(task.tools, state, domain=task.domain)
    faulty_tool_map = make_faulty_tool_map(base_tool_map, fault)

    # Prompt-level faults
    agent_system = _AGENT_SYSTEM.format(wiki=task.wiki)
    agent_system = corrupt_prompt(agent_system, fault, rng)
    agent_system = inflate_prompt(agent_system, fault)

    # Conversation state
    agent_messages: list[dict] = []
    user_sim_messages: list[dict] = []
    usage = TokenUsage()
    all_tool_calls: list[ToolCall] = []
    tool_error_count = 0
    agent_responses: list[str] = []
    turn_count = 0

    with st.conversation(session_id):
        # Initial user message from simulator
        first_msg, sim_usage = _user_sim_turn(
            client, provider, [], task.instruction, fault.model,
        )
        usage += sim_usage

        if "###STOP###" in first_msg:
            first_msg = task.instruction  # fallback: use raw instruction

        agent_messages.append({"role": "user", "content": first_msg})
        user_sim_messages.append({"role": "assistant", "content": first_msg})

        for turn in range(task.max_turns):
            turn_count += 1

            # Agent turn: may involve multiple tool calls
            for _ in range(5):  # max 5 tool-call rounds per turn
                resp: LLMResponse = llm_chat(
                    client=client,
                    provider=provider,
                    messages=agent_messages,
                    system=agent_system,
                    tools=provider_tools,
                    model=fault.model,
                    max_tokens=512,
                    temperature=0.0,
                )
                usage += resp.usage

                if not resp.tool_calls:
                    # Agent is responding to user
                    agent_text = resp.content or ""
                    agent_responses.append(agent_text)
                    agent_messages.append({"role": "assistant", "content": agent_text})
                    break

                # Process tool calls
                all_tool_calls.extend(resp.tool_calls)
                results = execute_tools(resp.tool_calls, faulty_tool_map)
                tool_error_count += sum(1 for r in results if r.get("is_error"))
                append_to_history(agent_messages, provider, resp, results)

            # User simulator turn
            user_sim_messages.append(
                {"role": "user", "content": agent_responses[-1] if agent_responses else ""}
            )
            user_msg, sim_usage = _user_sim_turn(
                client, provider, user_sim_messages, task.instruction, fault.model,
            )
            usage += sim_usage

            if "###STOP###" in user_msg:
                break

            user_sim_messages.append({"role": "assistant", "content": user_msg})
            agent_messages.append({"role": "user", "content": user_msg})

    success, eval_details = evaluate(state, task, agent_responses)

    return scenario_result(
        scenario=task.task_id,
        session_id=session_id,
        expected_detections=[] if success else ["task_incomplete"],
        actual_outcome=(
            f"Turns: {turn_count}. "
            f"Actions: {len(state.get('_actions_taken', []))} / "
            f"{len(task.expected_actions)} expected. "
            f"Success: {success}."
        ),
        extra={
            "task_id": task.task_id,
            "domain": task.domain,
            "source": task.source,
            "success": success,
            "turn_count": turn_count,
            "tool_calls_made": [tc.name for tc in all_tool_calls],
            "tool_error_count": tool_error_count,
            "token_usage": usage.to_dict(),
            "eval_details": eval_details,
            "fault_config": {
                "tool_fail_rate": fault.tool_fail_rate,
                "tool_latency_ms": fault.tool_latency_ms,
                "token_inflation_chars": fault.token_inflation_chars,
                "prompt_corruption_rate": fault.prompt_corruption_rate,
                "response_truncation_rate": fault.response_truncation_rate,
                "model": fault.model,
            },
        },
    )
