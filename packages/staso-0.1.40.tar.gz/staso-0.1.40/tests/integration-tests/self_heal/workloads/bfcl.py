"""BFCL (Berkeley Function-Calling Leaderboard) adapter.

Loads curated tasks from data/bfcl_simple.json and runs them through the
standard persona LLM loop, returning scenario_result()-compatible dicts.

The fault config controls tool failure injection so the same tasks can be run
across multiple commit phases to produce a regression curve.
"""
from __future__ import annotations

import json
import os
from typing import Any

import staso as st

from personas.common import TokenUsage, make_session_id, scenario_result
from personas.common.provider import (
    LLMResponse,
    ToolCall,
    append_to_history,
    execute_tools,
    get_llm_client,
    llm_chat,
    tools_for_provider,
)

import random as _random

from .fault import FaultConfig, corrupt_prompt, inflate_prompt
from .task import SingleTurnTask

_DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "bfcl_simple.json")

_SYSTEM_PROMPT = """You are a helpful assistant with access to tools.
Use the available tools to answer the user's request accurately.
Call exactly the tool that best fulfills the request with correct arguments.
Do not make up information."""


def load_tasks(path: str | None = None) -> list[SingleTurnTask]:
    """Load benchmark tasks from JSON. path defaults to bundled bfcl_simple.json."""
    with open(path or _DATA_PATH) as f:
        raw = json.load(f)
    return [
        SingleTurnTask(
            task_id=t["task_id"],
            user_message=t["user_message"],
            tools=t["tools"],
            expected_function=t["expected_function"],
            expected_args_subset=t.get("expected_args_subset", {}),
            category=t.get("category", "simple"),
        )
        for t in raw
    ]


def evaluate(tool_calls: list[ToolCall], task: SingleTurnTask) -> bool:
    """Return True if the agent called the right function with the right key args."""
    matching = [tc for tc in tool_calls if tc.name == task.expected_function]
    if not matching:
        return False
    tc = matching[0]
    for key, expected_val in task.expected_args_subset.items():
        actual_val = tc.arguments.get(key)
        if actual_val is None:
            return False
        # Case-insensitive string containment check
        if str(expected_val).lower() not in str(actual_val).lower():
            return False
    return True


def _build_tool_map(tools: list[dict], fault: FaultConfig | None = None) -> dict[str, Any]:
    """Build stub tool map with @st.tool spans.

    Fault injection (failure + latency) happens inside each span so that
    RuntimeError errors are captured as error spans in the trace.
    """
    rng = _random.Random(fault.seed if fault else None)

    def _make_stub(name: str):
        @st.tool(name=name)
        def stub(**kwargs):
            if fault and fault.tool_latency_ms > 0:
                import time
                time.sleep(fault.tool_latency_ms / 1000.0)
            if fault and rng.random() < fault.tool_fail_rate:
                raise RuntimeError(f"Tool '{name}' execution failed (injected fault)")
            result: dict = {"tool": name, "result": "ok", "args": kwargs}
            if fault and fault.should_truncate(rng):
                return {"truncated": str(result)[:fault.response_max_chars], "_fault": "response_truncation"}
            return result
        return stub

    return {t["name"]: _make_stub(t["name"]) for t in tools}


def run_benchmark_task(
    task: SingleTurnTask,
    fault: FaultConfig,
    provider: str,
    env: str,
) -> dict:
    """Run a single benchmark task and return a scenario_result()-compatible dict.

    The tool map uses stub implementations (echo args) so no real API calls are made.
    Fault injection applies at multiple layers:
      - Tool level: fail_rate, latency, response_truncation (via make_faulty_tool_map)
      - Prompt level: corruption (drop sentences), inflation (pad tokens)
      - Model level: model override (via fault.model)
    """
    import random as _random

    rng = _random.Random(fault.seed)

    session_id = make_session_id("bfcl", task.task_id)
    client = get_llm_client(provider)
    provider_tools = tools_for_provider(task.tools, provider)
    faulty_tool_map = _build_tool_map(task.tools, fault=fault)

    # Apply prompt-level faults
    system_prompt = _SYSTEM_PROMPT
    system_prompt = corrupt_prompt(system_prompt, fault, rng)
    system_prompt = inflate_prompt(system_prompt, fault)

    messages: list[dict] = [{"role": "user", "content": task.user_message}]
    usage = TokenUsage()
    all_tool_calls: list[ToolCall] = []
    tool_error_count = 0

    with st.conversation(session_id):
        with st.span(task.task_id, kind="agent") as root:
            for _ in range(3):  # max 3 turns (single-turn tasks rarely need more)
                resp: LLMResponse = llm_chat(
                    client=client,
                    provider=provider,
                    messages=messages,
                    system=system_prompt,
                    tools=provider_tools,
                    model=fault.model,
                    max_tokens=512,
                    temperature=0.0,
                )
                usage += resp.usage
                if not resp.tool_calls:
                    break
                all_tool_calls.extend(resp.tool_calls)
                results = execute_tools(resp.tool_calls, faulty_tool_map)
                tool_error_count += sum(1 for r in results if r.get("is_error"))
                append_to_history(messages, provider, resp, results)
            if tool_error_count > 0:
                root.set_status("error", f"{tool_error_count} tool error(s)")

    success = evaluate(all_tool_calls, task)
    return scenario_result(
        scenario=task.task_id,
        session_id=session_id,
        expected_detections=[] if success else ["wrong_tool_call"],
        actual_outcome=(
            f"Called {all_tool_calls[0].name if all_tool_calls else 'no tool'}"
            f" (expected {task.expected_function}). Success: {success}."
        ),
        extra={
            "task_id": task.task_id,
            "category": task.category,
            "success": success,
            "tool_calls_made": [tc.name for tc in all_tool_calls],
            "tool_error_count": tool_error_count,
            "token_usage": usage.to_dict(),
            "fault_config": {
                "tool_fail_rate": fault.tool_fail_rate,
                "tool_latency_ms": fault.tool_latency_ms,
                "token_inflation_chars": fault.token_inflation_chars,
                "prompt_corruption_rate": fault.prompt_corruption_rate,
                "response_truncation_rate": fault.response_truncation_rate,
                "model": fault.model,
            },
        },
    )
