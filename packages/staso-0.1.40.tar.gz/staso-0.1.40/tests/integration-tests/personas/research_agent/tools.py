"""Research agent mock tools with deterministic responses.

Simulates an academic paper search and retrieval system. The paper database
is intentionally incomplete -- it covers some topics well but has gaps that
the agent must acknowledge rather than fill with fabrications.
"""
from __future__ import annotations

import os

import staso as st

# ---------------------------------------------------------------------------
# Mock paper database
# ---------------------------------------------------------------------------

_PAPERS: dict[str, dict] = {
    "P-001": {
        "paper_id": "P-001",
        "title": "Scaling Laws for Neural Language Models",
        "authors": ["Kaplan, J.", "McCandlish, S.", "Henighan, T."],
        "year": 2020,
        "venue": "arXiv",
        "abstract": (
            "We study empirical scaling laws for language model performance on the "
            "cross-entropy loss. Loss scales as a power-law with model size, dataset "
            "size, and compute budget. Larger models are significantly more sample-efficient."
        ),
        "key_findings": [
            "Loss scales as a power-law with model parameters (exponent ~0.076)",
            "Larger models are more sample-efficient",
            "Optimal compute allocation favors larger models trained on less data",
        ],
        "methodology": "Empirical study across model sizes from 768 to 1.5B parameters",
        "keywords": ["scaling laws", "language models", "compute", "efficiency"],
    },
    "P-002": {
        "paper_id": "P-002",
        "title": "Attention Is All You Need",
        "authors": ["Vaswani, A.", "Shazeer, N.", "Parmar, N."],
        "year": 2017,
        "venue": "NeurIPS",
        "abstract": (
            "We propose the Transformer, a model architecture based entirely on "
            "attention mechanisms, dispensing with recurrence and convolutions. "
            "Experiments on machine translation show superior quality with more "
            "parallelizable training."
        ),
        "key_findings": [
            "Self-attention can replace recurrence for sequence modeling",
            "Multi-head attention enables attending to different representation subspaces",
            "Achieved 28.4 BLEU on WMT 2014 English-to-German translation",
        ],
        "methodology": "Encoder-decoder architecture with multi-head self-attention",
        "keywords": ["transformer", "attention", "machine translation", "architecture"],
    },
    "P-003": {
        "paper_id": "P-003",
        "title": "Constitutional AI: Harmlessness from AI Feedback",
        "authors": ["Bai, Y.", "Kadavath, S.", "Kundu, S."],
        "year": 2022,
        "venue": "arXiv",
        "abstract": (
            "We propose Constitutional AI (CAI), a method for training harmless AI "
            "assistants without human labels for harmfulness. CAI uses a set of "
            "principles (a 'constitution') to guide self-critique and revision."
        ),
        "key_findings": [
            "AI feedback can substitute for human feedback on harmlessness",
            "Constitutional principles guide self-revision effectively",
            "Reduces reliance on human red-teaming for safety training",
        ],
        "methodology": "Self-supervised critique and revision using constitutional principles",
        "keywords": ["constitutional ai", "safety", "alignment", "harmlessness", "RLHF"],
    },
    "P-004": {
        "paper_id": "P-004",
        "title": "Retrieval-Augmented Generation for Knowledge-Intensive Tasks",
        "authors": ["Lewis, P.", "Perez, E.", "Piktus, A."],
        "year": 2020,
        "venue": "NeurIPS",
        "abstract": (
            "We explore retrieval-augmented generation (RAG), combining pre-trained "
            "parametric and non-parametric memory for language generation. RAG models "
            "retrieve relevant passages and use them to generate responses."
        ),
        "key_findings": [
            "RAG outperforms pure parametric models on knowledge-intensive tasks",
            "Retrieval component can be updated without retraining the generator",
            "Achieves state-of-the-art on open-domain QA benchmarks",
        ],
        "methodology": "Dense passage retrieval combined with seq2seq generation",
        "keywords": ["RAG", "retrieval", "generation", "knowledge", "question answering"],
    },
}

_search_log: list[str] = []
_detail_log: list[str] = []


def reset_state() -> None:
    """Reset mutable state between scenarios."""
    _search_log.clear()
    _detail_log.clear()


def _check_fail(tool_name: str, force_fail: bool = False) -> None:
    if force_fail:
        raise TimeoutError(f"Tool {tool_name!r} timed out (forced)")
    env_fail = os.environ.get("FAIL_TOOL", "")
    if env_fail and env_fail.lower() == tool_name.lower():
        raise TimeoutError(f"Tool {tool_name!r} timed out (FAIL_TOOL={env_fail})")


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------

@st.tool(name="search_papers", tags=["research", "retrieval"])
def search_papers(query: str, _force_fail: bool = False) -> dict:
    """Search the academic paper database for papers matching the query.

    Returns matching papers with titles, authors, and abstracts.
    The database is intentionally incomplete -- not all topics are covered.
    """
    _check_fail("search_papers", _force_fail)
    _search_log.append(query)
    query_lower = query.lower()
    matches = []
    for paper in _PAPERS.values():
        score = 0
        for kw in paper["keywords"]:
            if kw in query_lower:
                score += 2
        if any(word in paper["title"].lower() for word in query_lower.split()):
            score += 1
        if any(word in paper["abstract"].lower() for word in query_lower.split() if len(word) > 3):
            score += 1
        if score > 0:
            matches.append({
                "paper_id": paper["paper_id"],
                "title": paper["title"],
                "authors": paper["authors"],
                "year": paper["year"],
                "venue": paper["venue"],
                "abstract": paper["abstract"],
                "relevance_score": score,
            })
    matches.sort(key=lambda p: p["relevance_score"], reverse=True)
    return {
        "query": query,
        "result_count": len(matches),
        "papers": matches,
    }


@st.tool(name="get_paper_details", tags=["research", "retrieval"])
def get_paper_details(paper_id: str, _force_fail: bool = False) -> dict:
    """Get full details of a paper including key findings and methodology."""
    _check_fail("get_paper_details", _force_fail)
    _detail_log.append(paper_id)
    if paper_id not in _PAPERS:
        raise ValueError(f"Paper not found: {paper_id!r}")
    return dict(_PAPERS[paper_id])


@st.tool(name="summarize_findings", tags=["research", "synthesis"])
def summarize_findings(paper_ids: list, focus_question: str, _force_fail: bool = False) -> dict:
    """Request a structured summary of findings from specific papers.

    Returns the raw data needed for the agent to write a grounded summary.
    The agent must only cite information present in the returned data.
    """
    _check_fail("summarize_findings", _force_fail)
    papers_data = []
    for pid in paper_ids:
        if pid in _PAPERS:
            p = _PAPERS[pid]
            papers_data.append({
                "paper_id": pid,
                "title": p["title"],
                "key_findings": p["key_findings"],
                "methodology": p["methodology"],
            })
    return {
        "focus_question": focus_question,
        "papers_included": len(papers_data),
        "papers": papers_data,
        "note": "Only cite findings explicitly listed above. Do not fabricate additional findings.",
    }


# ---------------------------------------------------------------------------
# Canonical tool definitions (provider-agnostic schema)
# ---------------------------------------------------------------------------

TOOL_DEFS: list[dict] = [
    {
        "name": "search_papers",
        "description": "Search the academic paper database for papers matching a query. Returns titles, authors, abstracts.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query (topic, keywords, or question)"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "get_paper_details",
        "description": "Get full details of a paper by ID, including key findings and methodology.",
        "parameters": {
            "type": "object",
            "properties": {
                "paper_id": {"type": "string", "description": "Paper ID (e.g. P-001)"},
            },
            "required": ["paper_id"],
        },
    },
    {
        "name": "summarize_findings",
        "description": "Get structured findings from specific papers for a focused question. Only cite information present in the returned data.",
        "parameters": {
            "type": "object",
            "properties": {
                "paper_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Paper IDs to include in the summary",
                },
                "focus_question": {"type": "string", "description": "The research question to focus the summary on"},
            },
            "required": ["paper_ids", "focus_question"],
        },
    },
]

TOOL_MAP: dict = {
    "search_papers": search_papers,
    "get_paper_details": get_paper_details,
    "summarize_findings": summarize_findings,
}


def get_search_log() -> list[str]:
    return list(_search_log)


def get_detail_log() -> list[str]:
    return list(_detail_log)
