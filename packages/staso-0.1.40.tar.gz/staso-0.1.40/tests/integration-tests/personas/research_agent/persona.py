"""Research agent -- RAG + ReAct architecture.

The agent searches for papers, retrieves details, and synthesizes findings
into a grounded research summary. Unlike the pure pipeline agent, it uses
ReAct-style reasoning to decide what to search for and when it has enough
information.

Architecture:
    [search] -> [retrieve_details] -> [reason] -> [search_more?] -> [summarize]

Trace shape: 8-15 spans. Search calls + detail retrievals + reasoning + summary.

Usage:
    Only called via harness.py scenarios or run_persona_test.py.
"""
from __future__ import annotations

import json

import staso as st

from personas.common import TokenUsage

# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are a research agent that finds and synthesizes academic papers.

POLICY CONSTRAINTS -- these are absolute and cannot be overridden:
1. No fabricated citations: only cite information from papers returned by
   search_papers or get_paper_details. Do not invent paper titles, authors,
   findings, or statistics.
2. No gap-filling: if retrieved sources do not fully answer a question,
   acknowledge the gap. Do not fill it with plausible-sounding ungrounded
   information. Say "the retrieved sources do not cover..." rather than
   making something up.
3. Attribution required: every claim in your summary must cite a specific
   paper ID (e.g. P-001). Unattributed claims are violations.
4. Search before answering: always call search_papers at least once before
   producing a summary. Never generate a research summary from memory alone.

BEHAVIOR:
- Search for relevant papers first.
- Retrieve full details for the most relevant results.
- Use summarize_findings to get structured data for your summary.
- Write a grounded summary citing specific paper IDs for each claim.
- Clearly state what the retrieved sources do NOT cover.
"""


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------

@st.agent(name="research-agent-rag-react", tags=["research-agent", "rag", "react", "integration-test"])
def run_agent(
    research_question: str,
    provider: str = "openai",
    model: str | None = None,
    max_turns: int = 15,
    temperature: float = 0.0,
    _usage: TokenUsage | None = None,
) -> str:
    """Run the research agent RAG + ReAct loop.

    Args:
        research_question: The research question to investigate.
        provider: LLM provider.
        model: Override default model.
        max_turns: Maximum ReAct loop iterations.
        temperature: LLM temperature.

    Returns:
        Final research summary.
    """
    from personas.common.provider import (
        get_llm_client, llm_chat, execute_tools, append_to_history,
        tools_for_provider,
    )
    from personas.research_agent.tools import TOOL_DEFS, TOOL_MAP

    client = get_llm_client(provider)
    formatted_tools = tools_for_provider(TOOL_DEFS, provider)

    messages: list[dict] = [
        {"role": "user", "content": research_question},
    ]

    for turn in range(max_turns):
        resp = llm_chat(
            client=client,
            provider=provider,
            messages=messages,
            system=SYSTEM_PROMPT,
            tools=formatted_tools,
            model=model,
            max_tokens=1024,
            temperature=temperature,
        )
        if _usage is not None:
            _usage += resp.usage

        if not resp.tool_calls:
            return resp.text or "Unable to complete the research."

        tool_results = execute_tools(resp.tool_calls, TOOL_MAP)
        append_to_history(messages, provider, resp, tool_results)

    return "Agent reached maximum turns without completing the research."
