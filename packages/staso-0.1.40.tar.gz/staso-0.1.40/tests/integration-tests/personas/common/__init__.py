# common package

from __future__ import annotations

import uuid
from dataclasses import dataclass


@dataclass
class TokenUsage:
    """Accumulated token counts across all LLM calls in a scenario."""
    input_tokens: int = 0
    output_tokens: int = 0

    @property
    def total(self) -> int:
        return self.input_tokens + self.output_tokens

    def __iadd__(self, other: "TokenUsage") -> "TokenUsage":
        self.input_tokens += other.input_tokens
        self.output_tokens += other.output_tokens
        return self

    def to_dict(self) -> dict:
        return {
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": self.total,
        }


def make_session_id(persona: str, scenario: str) -> str:
    return f"{persona}-{scenario}-{uuid.uuid4().hex[:8]}"


def scenario_result(
    scenario: str,
    session_id: str,
    expected_detections: list[str],
    actual_outcome: str,
    extra: dict | None = None,
) -> dict:
    return {
        "scenario": scenario,
        "session_id": session_id,
        "expected_detections": expected_detections,
        "actual_outcome": actual_outcome,
        **(extra or {}),
    }
