"""Thin wrapper around demo_seed/seed_traces.py for single-scenario runs.

This is the historical CLI entry point for running one persona + one
scenario against Staso. It now delegates to the demo_seed trace seeder
so there is exactly one code path for persona orchestration.

Usage (from repo root):
    uv run python tests/integration-tests/personas/common/run_persona_test.py \\
        --persona customer-support --scenario billing_inquiry \\
        --provider openai --env staging

To seed multiple scenarios at once, bulk-fill a demo workspace, or exercise
guard policies, use the seeders directly:
    uv run python tests/integration-tests/demo_seed/seed_traces.py --env staging --persona all
    uv run python tests/integration-tests/demo_seed/seed_guard_violations.py --env staging
"""
from __future__ import annotations

import argparse
import os
import sys

_INTEGRATION_TESTS_ROOT = os.path.dirname(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
)
if _INTEGRATION_TESTS_ROOT not in sys.path:
    sys.path.insert(0, _INTEGRATION_TESTS_ROOT)

from demo_seed import seed_traces  # noqa: E402


# CLI flag used "customer-support" with a hyphen; filesystem uses "customer_support".
_HYPHEN_TO_SLUG = {
    "customer-support": "customer_support",
    "finance-ops": "finance_ops",
    "code-agent": "code_agent",
    "research-agent": "research_agent",
    "orchestrator": "orchestrator",
    "sales-agent": "sales_agent",
}


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run a single persona/scenario against Staso (thin wrapper around demo_seed)."
    )
    parser.add_argument("--persona", required=True, choices=sorted(_HYPHEN_TO_SLUG))
    parser.add_argument("--scenario", required=True, help="Scenario name (see personas/INDEX.md)")
    parser.add_argument("--provider", default="openai", choices=["openai", "anthropic"])
    parser.add_argument(
        "--env",
        default="staging",
        choices=["local", "staging", "production"],
        help="Environment preset (default: staging)",
    )
    args = parser.parse_args()

    persona_slug = _HYPHEN_TO_SLUG[args.persona]

    report = seed_traces.seed(
        env=args.env,
        personas=[persona_slug],
        scenarios=[args.scenario],
        integrations=[args.provider],
        repeat=1,
        agent_name=f"{persona_slug}-e2e-agent",
        results_path=None,
    )

    if report.failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
