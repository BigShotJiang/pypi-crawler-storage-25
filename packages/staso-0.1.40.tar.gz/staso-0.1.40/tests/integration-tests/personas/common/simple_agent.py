"""Plain drop-in agent loop used by every guard demo persona.

This is the exact pattern a real Staso customer writes after reading
``documentation/integrations/openai.md`` or ``anthropic.md``:

    import staso as st
    st.init(api_key=...)
    st.integrations.patch_openai()

    @st.agent(name="...")
    def run_agent(user_request):
        client = OpenAI()
        try:
            # normal agent loop — call model, execute tools, loop
        except st.GuardBlocked as exc:
            # enforce-mode rule fired; handle accordingly

No explicit ``st.guard()`` calls. No ``STASO_GUARD_ENABLED`` toggling. No
custom wrappers. The integration's drop-in pass evaluates every tool call
against the workspace's guard rules and — for enforce-mode rules —
raises ``GuardBlocked`` before the tool runs. Audit-mode rules emit a
``guard:would-block:*`` span but let the call proceed.
"""
from __future__ import annotations

from typing import Any, Callable

import staso as st

from personas.common import TokenUsage
from personas.common.provider import (
    append_to_history,
    execute_tools,
    get_llm_client,
    llm_chat,
    tools_for_provider,
)


def run_drop_in_agent(
    *,
    user_request: str,
    system_prompt: str,
    tool_defs: list[dict],
    tool_map: dict[str, Callable[..., Any]],
    provider: str,
    model: str | None = None,
    max_turns: int = 6,
    max_tokens: int = 1024,
    temperature: float = 0.0,
    usage: TokenUsage | None = None,
) -> str:
    """Drive a standard LLM → tool loop.

    The patched integration (``patch_openai`` / ``patch_anthropic``)
    auto-evaluates each tool call against the workspace's guard rules.
    Enforce-mode blocks raise :class:`staso.GuardBlocked` from inside
    ``client.chat.completions.create`` / ``client.messages.create``; we
    catch it here and return a short human message so the demo seeder
    records the block as a *successful* demo run (a block is the
    intended outcome of a guard demo — not a test failure).
    """
    client = get_llm_client(provider)
    formatted_tools = tools_for_provider(tool_defs, provider)
    messages: list[dict] = [{"role": "user", "content": user_request}]

    for _ in range(max_turns):
        try:
            resp = llm_chat(
                client=client,
                provider=provider,
                messages=messages,
                system=system_prompt,
                tools=formatted_tools,
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
            )
        except st.GuardBlocked as exc:
            return (
                f"[guard blocked tool {exc.tool_name!r}: {exc.reason}]"
            )

        if usage is not None:
            usage += resp.usage

        if not resp.tool_calls:
            return resp.text or ""

        tool_results = execute_tools(resp.tool_calls, tool_map)
        append_to_history(messages, provider, resp, tool_results)

    return "Agent reached max turns."
