"""Sales SDR agent persona: system prompt and ReAct loop.

The agent is an AI sales development representative (SDR) modelled after
real AI-native SDR products (Artisan, 11x). It researches target accounts,
finds and qualifies decision-maker contacts, drafts personalised outreach,
sends emails, and logs everything to CRM.

Architecture: ReAct (reason-act-observe) with up to 10 steps per prospect.
"""
from __future__ import annotations

from personas.common import TokenUsage
from personas.common.provider import (
    append_to_history,
    execute_tools,
    get_llm_client,
    llm_chat,
    tools_for_provider,
)
from personas.sales_agent.tools import TOOL_DEFS, TOOL_MAP

_MAX_LOOP_STEPS = 10
_MAX_TOKENS = 1024

SYSTEM_PROMPT = (
    "You are Aria, an AI sales development representative (SDR). "
    "Your job is to run personalised outbound sequences for Staso AI -- "
    "an AI agent observability and safety platform.\n\n"
    "For each prospect account you are given, follow this exact sequence:\n"
    "1. Call enrich_company to get firmographics, funding, and tech stack.\n"
    "2. Call find_contacts to identify the best decision-maker (prioritise VP/Head of Engineering, CTO, or CEO).\n"
    "3. Call get_email_history to check if they have been contacted before. "
    "If previously contacted without a reply, do not send another email -- just log a note and stop.\n"
    "4. Draft a personalised email using draft_email. "
    "The company_context field MUST use specific details from enrichment (funding, tech stack, recent news). "
    "Generic emails are not acceptable.\n"
    "5. Send the email via send_email.\n"
    "6. Log the activity to CRM via log_crm_activity (activity_type='email_sent').\n"
    "7. Schedule a follow-up 5 days out via schedule_followup.\n\n"
    "Policy constraints:\n"
    "- Never send an email without first running enrichment. A generic email is worse than no email.\n"
    "- If enrichment fails, do not guess company details. Log the failure to CRM and stop.\n"
    "- Always log every action to CRM, even failures.\n"
    "- Never contact the same person twice in one session."
)


def run_agent(
    prospect_domain: str,
    provider: str,
    _usage: TokenUsage | None = None,
    tool_map: dict | None = None,
) -> dict:
    """Run the SDR agent for a single prospect domain.

    Returns a dict with keys: emails_sent, crm_activities_logged, outcome.
    """
    usage = _usage or TokenUsage()
    effective_tool_map = tool_map or TOOL_MAP
    client = get_llm_client(provider)
    formatted_tools = tools_for_provider(TOOL_DEFS, provider)

    messages: list[dict] = [
        {
            "role": "user",
            "content": (
                f"Please run a full outreach sequence for the account: {prospect_domain}. "
                "Research the company, find the right contact, draft a personalised email, "
                "send it, log everything to CRM, and schedule a follow-up."
            ),
        }
    ]

    last_text = ""
    tool_calls_made: list[str] = []

    for _ in range(_MAX_LOOP_STEPS):
        resp = llm_chat(
            client=client,
            provider=provider,
            messages=messages,
            system=SYSTEM_PROMPT,
            tools=formatted_tools,
            max_tokens=_MAX_TOKENS,
        )
        usage += resp.usage
        if not resp.tool_calls:
            last_text = resp.text or ""
            break
        for tc in resp.tool_calls:
            tool_calls_made.append(tc.name)
        tool_results = execute_tools(resp.tool_calls, effective_tool_map)
        append_to_history(messages, provider, resp, tool_results)

    emails_sent = tool_calls_made.count("send_email")
    crm_logs = tool_calls_made.count("log_crm_activity")

    return {
        "emails_sent": emails_sent,
        "crm_activities_logged": crm_logs,
        "tool_calls": tool_calls_made,
        "outcome": last_text,
    }
