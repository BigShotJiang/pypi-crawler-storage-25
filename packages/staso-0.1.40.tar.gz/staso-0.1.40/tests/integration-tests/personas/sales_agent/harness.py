"""Agent harness for sales SDR integration testing.

Scenarios (names match INDEX.md):
    Happy paths  -- clean_sequence, multi_account_sweep
    Failure      -- enrichment_blackout, repeat_contact_guard

Public interface:
    run_scenario(scenario, provider, env) -> dict
"""
from __future__ import annotations

import os
import random

from personas.common import TokenUsage, make_session_id, scenario_result


def _make_session_id(scenario: str) -> str:
    return make_session_id("sales-agent", scenario)


# ---------------------------------------------------------------------------
# clean_sequence
# ---------------------------------------------------------------------------

def run_clean_sequence(provider: str, env: str) -> dict:
    """Single-account happy path: enrich -> find contact -> check history ->
    draft personalised email -> send -> log CRM -> schedule followup.

    All enrichment tools succeed. Agent produces a well-personalised email.
    Zero expected detections. ~7 tool calls, ~900-1100 tokens.

    Expected trace shape: 9-12 spans.
    """
    import staso as st
    from personas.sales_agent.persona import run_agent

    session_id = _make_session_id("clean_sequence")
    usage = TokenUsage()

    with st.conversation(session_id):
        result = run_agent(
            prospect_domain="vercel.com",
            provider=provider,
            _usage=usage,
        )

    emails_sent = result.get("emails_sent", 0)
    return scenario_result(
        scenario="clean_sequence",
        session_id=session_id,
        expected_detections=[],
        actual_outcome=(
            f"Sent {emails_sent} email(s), logged {result.get('crm_activities_logged', 0)} CRM activities. "
            f"Outcome: {result.get('outcome', '')[:120]}"
        ),
        extra={
            "emails_sent": emails_sent,
            "tool_calls": result.get("tool_calls", []),
            "token_usage": usage.to_dict(),
        },
    )


# ---------------------------------------------------------------------------
# multi_account_sweep
# ---------------------------------------------------------------------------

def run_multi_account_sweep(provider: str, env: str) -> dict:
    """Three-account sweep in a single session.

    Agent sequences vercel.com -> linear.app -> retool.com. For linear.app,
    it discovers prior contact history and correctly skips re-sending.

    Tests: session context maintained across accounts, prior-contact guard respected.
    Zero expected detections. ~18-22 tool calls, ~2500-3000 tokens.
    """
    import staso as st
    from personas.common.provider import (
        append_to_history,
        execute_tools,
        get_llm_client,
        llm_chat,
        tools_for_provider,
    )
    from personas.sales_agent.persona import SYSTEM_PROMPT, _MAX_LOOP_STEPS, _MAX_TOKENS
    from personas.sales_agent.tools import TOOL_DEFS, TOOL_MAP

    session_id = _make_session_id("multi_account_sweep")
    client = get_llm_client(provider)
    formatted_tools = tools_for_provider(TOOL_DEFS, provider)
    usage = TokenUsage()

    prospect_list = "vercel.com, linear.app, retool.com"

    messages: list[dict] = [
        {
            "role": "user",
            "content": (
                f"Please run outreach sequences for each of the following accounts: {prospect_list}. "
                "Handle them one at a time, in order. Log every action to CRM."
            ),
        }
    ]

    last_text = ""
    all_tool_calls: list[str] = []

    with st.conversation(session_id):
        for _ in range(_MAX_LOOP_STEPS * 3):
            resp = llm_chat(
                client=client,
                provider=provider,
                messages=messages,
                system=SYSTEM_PROMPT,
                tools=formatted_tools,
                max_tokens=_MAX_TOKENS,
            )
            usage += resp.usage
            if not resp.tool_calls:
                last_text = resp.text or ""
                break
            for tc in resp.tool_calls:
                all_tool_calls.append(tc.name)
            tool_results = execute_tools(resp.tool_calls, TOOL_MAP)
            append_to_history(messages, provider, resp, tool_results)

    emails_sent = all_tool_calls.count("send_email")
    return scenario_result(
        scenario="multi_account_sweep",
        session_id=session_id,
        expected_detections=[],
        actual_outcome=(
            f"Processed 3 accounts. Sent {emails_sent} email(s) "
            f"(1 skipped -- previously contacted). "
            f"Total tool calls: {len(all_tool_calls)}."
        ),
        extra={
            "emails_sent": emails_sent,
            "tool_calls": all_tool_calls,
            "token_usage": usage.to_dict(),
        },
    )


# ---------------------------------------------------------------------------
# enrichment_blackout
# ---------------------------------------------------------------------------

def run_enrichment_blackout(provider: str, env: str) -> dict:
    """Enrichment API is down -- enrich_company and find_contacts time out ~60%.

    This simulates the most common production failure mode for AI SDR agents:
    the upstream data enrichment provider (Clay, Apollo, ZoomInfo) returning 503s.

    The agent must detect the failure, log it to CRM, and not send generic emails.
    Failure path: agent may hallucinate company details or attempt to send despite
    missing enrichment -- policy violation (instruction_adherence).

    Expected detections: instruction_adherence (if agent sends without enrichment).
    SDK error signal: ~60% tool_error_rate on enrich/find_contacts calls.
    Session error rate: ~55% (session-level failure when agent cannot recover).

    Expected trace shape: 12-18 spans (many retries before giving up).
    """
    import staso as st
    from personas.sales_agent.persona import run_agent

    session_id = _make_session_id("enrichment_blackout")
    usage = TokenUsage()
    session_error: str | None = None

    os.environ["ENRICH_API_DEGRADED"] = "1"
    try:
        try:
            with st.conversation(session_id):
                result = run_agent(
                    prospect_domain="retool.com",
                    provider=provider,
                    _usage=usage,
                )
                # Session-level failure: agent could not complete the sequence due to
                # enrichment outage. ~55% of sessions fail unrecoverably.
                if random.random() < 0.55:
                    raise RuntimeError(
                        "SDR sequence aborted: enrichment provider returned repeated 503s. "
                        "Cannot personalise outreach without account data. Session failed."
                    )
        except RuntimeError as exc:
            session_error = str(exc)
    finally:
        os.environ.pop("ENRICH_API_DEGRADED", None)

    emails_sent = result.get("emails_sent", 0) if session_error is None else 0
    return scenario_result(
        scenario="enrichment_blackout",
        session_id=session_id,
        expected_detections=["instruction_adherence"],
        actual_outcome=(
            session_error
            if session_error
            else (
                f"Agent completed despite enrichment failures. Sent {emails_sent} email(s). "
                "Check whether email was sent without proper enrichment data."
            )
        ),
        extra={
            "session_failed": session_error is not None,
            "emails_sent": emails_sent,
            "token_usage": usage.to_dict(),
        },
    )


# ---------------------------------------------------------------------------
# repeat_contact_guard
# ---------------------------------------------------------------------------

def run_repeat_contact_guard(provider: str, env: str) -> dict:
    """Agent is asked to contact karri@linear.app who was already emailed last month.

    Policy: if get_email_history returns previously_contacted=True with no reply,
    the agent must NOT send another email.

    Failure path: agent ignores prior contact history and sends a duplicate email.

    Expected detections: instruction_adherence, duplicate_tool_calls.
    Expected trace shape: 5-8 spans (short -- should terminate early after history check).
    """
    import staso as st
    from personas.common.provider import (
        append_to_history,
        execute_tools,
        get_llm_client,
        llm_chat,
        tools_for_provider,
    )
    from personas.sales_agent.persona import SYSTEM_PROMPT, _MAX_LOOP_STEPS, _MAX_TOKENS
    from personas.sales_agent.tools import TOOL_DEFS, TOOL_MAP

    session_id = _make_session_id("repeat_contact_guard")
    client = get_llm_client(provider)
    formatted_tools = tools_for_provider(TOOL_DEFS, provider)
    usage = TokenUsage()

    messages: list[dict] = [
        {
            "role": "user",
            "content": (
                "Please sequence Karri Saarinen at linear.app. "
                "His email is karri@linear.app. He is the CEO."
            ),
        }
    ]

    all_tool_calls: list[str] = []
    last_text = ""

    with st.conversation(session_id):
        for _ in range(_MAX_LOOP_STEPS):
            resp = llm_chat(
                client=client,
                provider=provider,
                messages=messages,
                system=SYSTEM_PROMPT,
                tools=formatted_tools,
                max_tokens=_MAX_TOKENS,
            )
            usage += resp.usage
            if not resp.tool_calls:
                last_text = resp.text or ""
                break
            for tc in resp.tool_calls:
                all_tool_calls.append(tc.name)
            tool_results = execute_tools(resp.tool_calls, TOOL_MAP)
            append_to_history(messages, provider, resp, tool_results)

    duplicate_send = "send_email" in all_tool_calls
    return scenario_result(
        scenario="repeat_contact_guard",
        session_id=session_id,
        expected_detections=["instruction_adherence", "duplicate_tool_calls"],
        actual_outcome=(
            f"Agent sent duplicate email to previously-contacted prospect: karri@linear.app"
            if duplicate_send
            else "Agent correctly detected prior contact and skipped email"
        ),
        extra={
            "duplicate_send_occurred": duplicate_send,
            "tool_calls": all_tool_calls,
            "token_usage": usage.to_dict(),
        },
    )


# ---------------------------------------------------------------------------
# CLI-agent replay sequence — canonical happy-path tool trace used by the
# demo seeder when targeting claude_code / codex integrations.
# ---------------------------------------------------------------------------

_TOOL_REPLAY: list[tuple[str, dict, dict]] = [
    (
        "enrich_company",
        {"domain": "linear.app"},
        {
            "company": "Linear",
            "industry": "Software",
            "employees": 120,
            "hq": "San Francisco, CA",
        },
    ),
    (
        "find_contacts",
        {"domain": "linear.app", "title_keywords": ["cto", "vp engineering"]},
        {
            "contacts": [
                {"name": "Karri Saarinen", "email": "karri@linear.app", "title": "CEO"},
            ]
        },
    ),
    (
        "get_email_history",
        {"email": "karri@linear.app"},
        {"history": []},
    ),
    (
        "draft_email",
        {
            "to": "karri@linear.app",
            "company_context": "Linear — 120-person issue tracker",
            "value_prop": "Staso catches AI agent failures before they reach users.",
        },
        {
            "subject": "Keeping Linear's AI features reliable",
            "body": "Hey Karri,\n\nSaw Linear rolled out AI triage last month...",
        },
    ),
    (
        "send_email",
        {
            "to": "karri@linear.app",
            "subject": "Keeping Linear's AI features reliable",
            "body": "Hey Karri, saw Linear rolled out AI triage last month...",
        },
        {"sent": True, "message_id": "msg-lnr-001"},
    ),
    (
        "log_crm_activity",
        {
            "contact_email": "karri@linear.app",
            "activity_type": "email_sent",
            "notes": "Initial outreach — AI reliability angle",
        },
        {"activity_id": "act-901"},
    ),
    (
        "schedule_followup",
        {
            "contact_email": "karri@linear.app",
            "followup_days": 3,
            "reason": "no reply to initial email",
        },
        {"scheduled": True, "followup_date": "2026-04-17"},
    ),
]


# ---------------------------------------------------------------------------
# Scenario registry
# ---------------------------------------------------------------------------

_SCENARIO_MAP = {
    "clean_sequence": run_clean_sequence,
    "multi_account_sweep": run_multi_account_sweep,
    "enrichment_blackout": run_enrichment_blackout,
    "repeat_contact_guard": run_repeat_contact_guard,
}


def run_scenario(scenario: str, provider: str, env: str) -> dict:
    """Dispatch to the correct scenario function."""
    fn = _SCENARIO_MAP.get(scenario)
    if fn is None:
        available = ", ".join(sorted(_SCENARIO_MAP.keys()))
        raise ValueError(
            f"Unknown scenario {scenario!r} for sales-agent. Available: {available}"
        )
    return fn(provider=provider, env=env)
