"""Sales SDR agent mock tools with deterministic responses.

Models the outbound sales workflow of an AI SDR agent (modelled after real
AI-native SDR companies: Artisan, 11x, Clay). The agent researches accounts,
finds contacts, personalises email copy, and logs activity to CRM.

All tools use static in-memory data -- no external APIs. Responses are
deterministic so scenarios produce consistent traces.

Injectable failure mode: set ENRICH_API_DEGRADED=1 in the environment to
make enrichment and contact-search tools time out at a 60% rate. This
simulates the enrichment data provider going down -- the most common failure
mode for SDR agents in production.

Usage:
    import os
    os.environ["ENRICH_API_DEGRADED"] = "1"
    # enrich_company / find_contacts will now fail ~60% of calls
"""
from __future__ import annotations

import os

import staso as st

# ---------------------------------------------------------------------------
# Mock data store
# ---------------------------------------------------------------------------

_COMPANIES: dict[str, dict] = {
    "vercel.com": {
        "domain": "vercel.com",
        "name": "Vercel",
        "industry": "Developer Tools",
        "headcount": 450,
        "funding_stage": "Series C",
        "funding_total_usd": 313_000_000,
        "tech_stack": ["Next.js", "AWS", "Datadog", "PagerDuty"],
        "hq": "San Francisco, CA",
        "description": "Frontend cloud platform for deploying web applications.",
        "recent_news": "Raised $150M Series C in Jan 2026 to expand AI features.",
    },
    "linear.app": {
        "domain": "linear.app",
        "name": "Linear",
        "industry": "Project Management SaaS",
        "headcount": 90,
        "funding_stage": "Series B",
        "funding_total_usd": 52_000_000,
        "tech_stack": ["TypeScript", "GraphQL", "Postgres", "Sentry"],
        "hq": "San Francisco, CA",
        "description": "Issue tracking and project management for software teams.",
        "recent_news": "Launched AI-powered sprint planning in Q1 2026.",
    },
    "retool.com": {
        "domain": "retool.com",
        "name": "Retool",
        "industry": "Low-Code / Internal Tools",
        "headcount": 300,
        "funding_stage": "Series C",
        "funding_total_usd": 145_000_000,
        "tech_stack": ["React", "Node.js", "PostgreSQL", "AWS"],
        "hq": "San Francisco, CA",
        "description": "Low-code platform for building internal business tools.",
        "recent_news": "Expanding agent builder for agentic workflow automation.",
    },
}

_CONTACTS: dict[str, list[dict]] = {
    "vercel.com": [
        {
            "email": "gn@vercel.com",
            "first_name": "Guillermo",
            "last_name": "Rauch",
            "title": "CEO",
            "linkedin": "linkedin.com/in/guillermo-rauch",
            "decision_maker": True,
        },
        {
            "email": "eng.platform@vercel.com",
            "first_name": "Maya",
            "last_name": "Singh",
            "title": "Head of Platform Engineering",
            "linkedin": "linkedin.com/in/maya-singh-vercel",
            "decision_maker": True,
        },
    ],
    "linear.app": [
        {
            "email": "karri@linear.app",
            "first_name": "Karri",
            "last_name": "Saarinen",
            "title": "CEO",
            "linkedin": "linkedin.com/in/karrisa",
            "decision_maker": True,
        },
    ],
    "retool.com": [
        {
            "email": "david@retool.com",
            "first_name": "David",
            "last_name": "Hsu",
            "title": "CEO",
            "linkedin": "linkedin.com/in/david-hsu-retool",
            "decision_maker": True,
        },
        {
            "email": "ops@retool.com",
            "first_name": "Priya",
            "last_name": "Nair",
            "title": "VP Operations",
            "linkedin": "linkedin.com/in/priya-nair-retool",
            "decision_maker": True,
        },
    ],
}

_EMAIL_HISTORY: dict[str, list[dict]] = {
    "gn@vercel.com": [],
    "karri@linear.app": [
        {
            "sent_at": "2026-02-10",
            "subject": "Staso for Linear agents",
            "replied": False,
        }
    ],
    "david@retool.com": [],
    "ops@retool.com": [],
    "maya.singh@vercel.com": [],
}

_CRM_LOG: list[dict] = []

# Incrementing counter for generated activity IDs
_activity_counter = 1000

# Counter used by degraded tools for deterministic failure rate
_enrich_call_counter = 0


def _is_degraded() -> bool:
    return os.environ.get("ENRICH_API_DEGRADED", "0") == "1"


def _check_degraded(tool_name: str) -> None:
    """Raise TimeoutError ~60% of calls when ENRICH_API_DEGRADED=1."""
    global _enrich_call_counter
    _enrich_call_counter += 1
    if _is_degraded() and _enrich_call_counter % 5 < 3:
        raise TimeoutError(
            f"Enrichment API timeout on {tool_name}: upstream provider Clay returned 503. "
            "Retry after backoff or switch to fallback enrichment source."
        )


def _next_activity_id() -> str:
    global _activity_counter
    act_id = f"ACT-{_activity_counter}"
    _activity_counter += 1
    return act_id


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------

@st.tool(name="enrich_company", tags=["research", "enrichment"])
def enrich_company(domain: str) -> dict:
    """Enrich a company profile by domain. Returns firmographics, funding, tech stack."""
    _check_degraded("enrich_company")
    company = _COMPANIES.get(domain.lower())
    if not company:
        return {
            "domain": domain,
            "found": False,
            "message": f"No enrichment data found for domain {domain!r}",
        }
    return {"found": True, **company}


@st.tool(name="find_contacts", tags=["research", "contacts"])
def find_contacts(domain: str, title_keywords: list | None = None) -> dict:
    """Find decision-maker contacts at a company. Filters by title keywords if provided."""
    _check_degraded("find_contacts")
    contacts = _CONTACTS.get(domain.lower(), [])
    if title_keywords:
        kws = [k.lower() for k in title_keywords]
        contacts = [
            c for c in contacts
            if any(k in c["title"].lower() for k in kws)
        ]
    return {
        "domain": domain,
        "contacts_found": len(contacts),
        "contacts": contacts,
    }


@st.tool(name="get_email_history", tags=["crm", "history"])
def get_email_history(email: str) -> dict:
    """Check prior email history for a contact."""
    history = _EMAIL_HISTORY.get(email, [])
    return {
        "email": email,
        "prior_contact_count": len(history),
        "emails": history,
        "previously_contacted": len(history) > 0,
    }


@st.tool(name="draft_email", tags=["outreach", "copywriting"])
def draft_email(
    contact_first_name: str,
    contact_title: str,
    company_name: str,
    company_context: str,
    value_prop: str,
) -> dict:
    """Draft a personalised cold outreach email for a prospect."""
    subject = f"AI agent observability for {company_name}"
    body = (
        f"Hi {contact_first_name},\n\n"
        f"I noticed {company_context} -- "
        f"given your role as {contact_title}, I thought you'd find this relevant.\n\n"
        f"{value_prop}\n\n"
        "Happy to show you a 15-minute demo if this resonates.\n\n"
        "Best,\nAlex\nStaso AI"
    )
    return {
        "subject": subject,
        "body": body,
        "word_count": len(body.split()),
        "personalisation_score": 0.85,
    }


@st.tool(name="send_email", tags=["outreach", "delivery"])
def send_email(to: str, subject: str, body: str) -> dict:
    """Send the drafted email to the prospect."""
    return {
        "sent": True,
        "to": to,
        "subject": subject,
        "message_id": f"MSG-{_next_activity_id()}",
        "sent_at": "2026-04-06T09:00:00Z",
    }


@st.tool(name="log_crm_activity", tags=["crm", "logging"])
def log_crm_activity(
    contact_email: str,
    activity_type: str,
    notes: str,
    sequence_step: int = 1,
) -> dict:
    """Log an outreach activity to CRM."""
    activity_id = _next_activity_id()
    entry = {
        "activity_id": activity_id,
        "contact_email": contact_email,
        "activity_type": activity_type,
        "notes": notes,
        "sequence_step": sequence_step,
        "logged_at": "2026-04-06T09:00:00Z",
    }
    _CRM_LOG.append(entry)
    return {"logged": True, "activity_id": activity_id}


@st.tool(name="schedule_followup", tags=["crm", "sequencing"])
def schedule_followup(contact_email: str, followup_days: int, reason: str) -> dict:
    """Schedule a follow-up touchpoint for a contact."""
    return {
        "scheduled": True,
        "contact_email": contact_email,
        "followup_date": "2026-04-13",
        "followup_days": followup_days,
        "reason": reason,
        "task_id": f"TASK-{_next_activity_id()}",
    }


# ---------------------------------------------------------------------------
# Canonical tool definitions (provider-agnostic JSON schema)
# ---------------------------------------------------------------------------

TOOL_DEFS: list[dict] = [
    {
        "name": "enrich_company",
        "description": (
            "Enrich a company profile by domain name. Returns firmographics, "
            "funding stage, headcount, tech stack, and recent news."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "domain": {
                    "type": "string",
                    "description": "Company domain (e.g. 'vercel.com')",
                },
            },
            "required": ["domain"],
        },
    },
    {
        "name": "find_contacts",
        "description": (
            "Find decision-maker contacts at a company. "
            "Optionally filter by title keywords (e.g. ['VP', 'Head of Engineering'])."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "domain": {
                    "type": "string",
                    "description": "Company domain",
                },
                "title_keywords": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter contacts whose title contains any of these keywords",
                },
            },
            "required": ["domain"],
        },
    },
    {
        "name": "get_email_history",
        "description": "Check whether a contact has been emailed before and retrieve prior email threads.",
        "parameters": {
            "type": "object",
            "properties": {
                "email": {
                    "type": "string",
                    "description": "Contact email address",
                },
            },
            "required": ["email"],
        },
    },
    {
        "name": "draft_email",
        "description": (
            "Draft a personalised cold outreach email. Requires contact details and "
            "company context from enrichment to produce a high-quality, personalised message."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "contact_first_name": {"type": "string"},
                "contact_title": {"type": "string"},
                "company_name": {"type": "string"},
                "company_context": {
                    "type": "string",
                    "description": "1-2 sentences of specific company context (from enrichment) to personalise the email",
                },
                "value_prop": {
                    "type": "string",
                    "description": "Tailored value proposition for this specific prospect",
                },
            },
            "required": ["contact_first_name", "contact_title", "company_name", "company_context", "value_prop"],
        },
    },
    {
        "name": "send_email",
        "description": "Send the drafted outreach email to the prospect.",
        "parameters": {
            "type": "object",
            "properties": {
                "to": {"type": "string", "description": "Recipient email address"},
                "subject": {"type": "string"},
                "body": {"type": "string"},
            },
            "required": ["to", "subject", "body"],
        },
    },
    {
        "name": "log_crm_activity",
        "description": "Log an outreach activity (email sent, call, note) to the CRM.",
        "parameters": {
            "type": "object",
            "properties": {
                "contact_email": {"type": "string"},
                "activity_type": {
                    "type": "string",
                    "enum": ["email_sent", "call", "linkedin_message", "note"],
                },
                "notes": {"type": "string", "description": "Activity notes or summary"},
                "sequence_step": {
                    "type": "integer",
                    "description": "Step number in the outreach sequence (default 1)",
                },
            },
            "required": ["contact_email", "activity_type", "notes"],
        },
    },
    {
        "name": "schedule_followup",
        "description": "Schedule a follow-up touchpoint for a contact.",
        "parameters": {
            "type": "object",
            "properties": {
                "contact_email": {"type": "string"},
                "followup_days": {
                    "type": "integer",
                    "description": "Days from now to schedule the follow-up",
                },
                "reason": {"type": "string", "description": "Why this follow-up is being scheduled"},
            },
            "required": ["contact_email", "followup_days", "reason"],
        },
    },
]

TOOL_MAP: dict = {
    "enrich_company": enrich_company,
    "find_contacts": find_contacts,
    "get_email_history": get_email_history,
    "draft_email": draft_email,
    "send_email": send_email,
    "log_crm_activity": log_crm_activity,
    "schedule_followup": schedule_followup,
}
