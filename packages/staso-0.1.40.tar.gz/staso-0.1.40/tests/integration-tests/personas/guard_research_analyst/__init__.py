"""Guard demo: research analyst that ingests an indirect prompt injection."""
