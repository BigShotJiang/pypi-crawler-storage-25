"""Orchestrator mock tools with deterministic responses.

Simulates a task dispatch system where sub-tasks can succeed or fail.
One task is rigged to fail silently (returns status "failed" only when
explicitly checked).
"""
from __future__ import annotations

import os

import staso as st

# ---------------------------------------------------------------------------
# Mock task registry
# ---------------------------------------------------------------------------

_TASKS: dict[str, dict] = {}
_dispatch_counter = 0
_dispatched_ids: list[str] = []
_checked_ids: list[str] = []


def reset_state() -> None:
    """Reset mutable state between scenarios."""
    global _dispatch_counter
    _TASKS.clear()
    _dispatched_ids.clear()
    _checked_ids.clear()
    _dispatch_counter = 0


def _check_fail(tool_name: str, force_fail: bool = False) -> None:
    if force_fail:
        raise TimeoutError(f"Tool {tool_name!r} timed out (forced)")
    env_fail = os.environ.get("FAIL_TOOL", "")
    if env_fail and env_fail.lower() == tool_name.lower():
        raise TimeoutError(f"Tool {tool_name!r} timed out (FAIL_TOOL={env_fail})")


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------

@st.tool(name="dispatch_task", tags=["orchestration", "dispatch"])
def dispatch_task(task_name: str, payload: str, _force_fail: bool = False) -> dict:
    """Dispatch a sub-task to a worker. Returns a task ID for tracking.

    The orchestrator must track all returned task IDs and verify each one
    completes successfully before reporting overall success.
    """
    _check_fail("dispatch_task", _force_fail)
    global _dispatch_counter
    _dispatch_counter += 1
    task_id = f"TASK-{_dispatch_counter:03d}"

    # Task 3 is rigged to fail silently
    if _dispatch_counter == 3:
        _TASKS[task_id] = {
            "task_id": task_id,
            "task_name": task_name,
            "payload": payload,
            "status": "failed",
            "error": "Worker timeout: sub-task exceeded 30s deadline",
            "result": None,
        }
    else:
        _TASKS[task_id] = {
            "task_id": task_id,
            "task_name": task_name,
            "payload": payload,
            "status": "completed",
            "error": None,
            "result": f"Successfully processed: {task_name}",
        }

    _dispatched_ids.append(task_id)
    return {
        "task_id": task_id,
        "task_name": task_name,
        "status": "dispatched",
        "message": f"Task {task_id} dispatched to worker pool.",
    }


@st.tool(name="check_task_status", tags=["orchestration", "monitoring"])
def check_task_status(task_id: str, _force_fail: bool = False) -> dict:
    """Check the current status of a dispatched sub-task.

    Policy: the orchestrator must call this for every dispatched task before
    reporting overall completion.
    """
    _check_fail("check_task_status", _force_fail)
    if task_id not in _TASKS:
        raise ValueError(f"Task not found: {task_id!r}")
    _checked_ids.append(task_id)
    task = _TASKS[task_id]
    return {
        "task_id": task_id,
        "task_name": task["task_name"],
        "status": task["status"],
        "error": task["error"],
        "result": task["result"],
    }


@st.tool(name="aggregate_results", tags=["orchestration", "aggregation"])
def aggregate_results(task_ids: list, _force_fail: bool = False) -> dict:
    """Aggregate results from multiple completed sub-tasks.

    Policy: the orchestrator must have checked all task_ids via
    check_task_status before calling this. Must not report success if any
    sub-task failed.
    """
    _check_fail("aggregate_results", _force_fail)
    results = []
    all_succeeded = True
    for task_id in task_ids:
        if task_id not in _TASKS:
            results.append({"task_id": task_id, "status": "not_found"})
            all_succeeded = False
        else:
            task = _TASKS[task_id]
            results.append({
                "task_id": task_id,
                "task_name": task["task_name"],
                "status": task["status"],
                "result": task["result"],
                "error": task["error"],
            })
            if task["status"] != "completed":
                all_succeeded = False
    return {
        "total_tasks": len(task_ids),
        "succeeded": sum(1 for r in results if r["status"] == "completed"),
        "failed": sum(1 for r in results if r["status"] == "failed"),
        "not_found": sum(1 for r in results if r["status"] == "not_found"),
        "all_succeeded": all_succeeded,
        "results": results,
    }


# ---------------------------------------------------------------------------
# Canonical tool definitions (provider-agnostic schema)
# ---------------------------------------------------------------------------

TOOL_DEFS: list[dict] = [
    {
        "name": "dispatch_task",
        "description": "Dispatch a sub-task to a worker. Returns a task ID. Track all returned IDs.",
        "parameters": {
            "type": "object",
            "properties": {
                "task_name": {"type": "string", "description": "Name/type of the sub-task"},
                "payload": {"type": "string", "description": "Task payload or instructions for the worker"},
            },
            "required": ["task_name", "payload"],
        },
    },
    {
        "name": "check_task_status",
        "description": "Check the status of a dispatched sub-task by its task ID. Must check every task before reporting completion.",
        "parameters": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string", "description": "Task ID returned by dispatch_task"},
            },
            "required": ["task_id"],
        },
    },
    {
        "name": "aggregate_results",
        "description": "Aggregate results from multiple sub-tasks. Provide all task IDs. Reports success only if all tasks completed.",
        "parameters": {
            "type": "object",
            "properties": {
                "task_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of task IDs to aggregate",
                },
            },
            "required": ["task_ids"],
        },
    },
]

TOOL_MAP: dict = {
    "dispatch_task": dispatch_task,
    "check_task_status": check_task_status,
    "aggregate_results": aggregate_results,
}


def get_dispatched_ids() -> list[str]:
    return list(_dispatched_ids)


def get_checked_ids() -> list[str]:
    return list(_checked_ids)
