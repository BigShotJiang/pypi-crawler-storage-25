"""guard_analytics_export — pure audit-mode demo persona.

Exists to exercise the ``guard:would-block:*`` emission path. Every other
guard persona trips at least one enforce-mode rule, so audit-mode rules
(e.g. ``data_exfiltration`` after the global override) always co-fire with
an enforce rule on the same trace and the would-block branch never runs
in isolation. This persona issues a benign-looking POST to an unknown
third-party URL with no PII, no SQL, no injection strings — the only
rule that fires is the audit-mode ``data_exfiltration`` one.
"""
