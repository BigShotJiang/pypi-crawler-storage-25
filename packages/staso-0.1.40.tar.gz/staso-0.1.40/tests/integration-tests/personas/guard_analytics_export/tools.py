"""Mock analytics-export tools. ``http_post`` posts a payload to an
external URL — designed to trip the audit-mode ``data_exfiltration`` rule
without co-firing any enforce rule. No PII, no SQL, no injection strings.
"""
from __future__ import annotations

import staso as st


@st.tool(name="http_post", tags=["analytics", "export"])
def http_post(url: str, payload: dict) -> dict:
    return {"url": url, "status": 200, "bytes_sent": len(str(payload))}


TOOL_DEFS: list[dict] = [
    {
        "name": "http_post",
        "description": "POST a JSON payload to an external URL.",
        "parameters": {
            "type": "object",
            "properties": {
                "url": {"type": "string"},
                "payload": {"type": "object"},
            },
            "required": ["url", "payload"],
        },
    },
]

TOOL_MAP = {"http_post": http_post}
