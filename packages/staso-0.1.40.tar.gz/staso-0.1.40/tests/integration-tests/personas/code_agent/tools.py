"""Code agent mock tools with deterministic responses.

All tools use static in-memory data -- no real filesystem, no real tests.
Responses are deterministic so scenarios produce consistent traces.

The test suite is rigged: `run_tests` returns a failing test by default.
The agent must read the failure, fix the code, and re-run tests.
"""
from __future__ import annotations

import os
from typing import Any

import staso as st

# ---------------------------------------------------------------------------
# Mock filesystem
# ---------------------------------------------------------------------------

_FILES: dict[str, str] = {
    "src/utils.py": (
        "def add(a: int, b: int) -> int:\n"
        "    return a + b\n"
        "\n"
        "def multiply(a: int, b: int) -> int:\n"
        "    return a * b\n"
    ),
    "src/handler.py": (
        "from src.utils import add, multiply\n"
        "\n"
        "def handle_request(operation: str, x: int, y: int) -> dict:\n"
        "    if operation == 'add':\n"
        "        return {'result': add(x, y)}\n"
        "    elif operation == 'multiply':\n"
        "        return {'result': multiply(x, y)}\n"
        "    else:\n"
        "        return {'error': f'Unknown operation: {operation}'}\n"
    ),
    "tests/test_handler.py": (
        "from src.handler import handle_request\n"
        "\n"
        "def test_add():\n"
        "    assert handle_request('add', 2, 3) == {'result': 5}\n"
        "\n"
        "def test_multiply():\n"
        "    assert handle_request('multiply', 4, 5) == {'result': 20}\n"
        "\n"
        "def test_subtract():\n"
        "    assert handle_request('subtract', 10, 3) == {'result': 7}\n"
    ),
}

# Track writes for scenario verification
_write_log: list[dict] = []
_read_log: list[str] = []
_test_runs: list[dict] = []


def reset_state() -> None:
    """Reset mutable state between scenarios."""
    global _FILES
    _FILES = {
        "src/utils.py": (
            "def add(a: int, b: int) -> int:\n"
            "    return a + b\n"
            "\n"
            "def multiply(a: int, b: int) -> int:\n"
            "    return a * b\n"
        ),
        "src/handler.py": (
            "from src.utils import add, multiply\n"
            "\n"
            "def handle_request(operation: str, x: int, y: int) -> dict:\n"
            "    if operation == 'add':\n"
            "        return {'result': add(x, y)}\n"
            "    elif operation == 'multiply':\n"
            "        return {'result': multiply(x, y)}\n"
            "    else:\n"
            "        return {'error': f'Unknown operation: {operation}'}\n"
        ),
        "tests/test_handler.py": (
            "from src.handler import handle_request\n"
            "\n"
            "def test_add():\n"
            "    assert handle_request('add', 2, 3) == {'result': 5}\n"
            "\n"
            "def test_multiply():\n"
            "    assert handle_request('multiply', 4, 5) == {'result': 20}\n"
            "\n"
            "def test_subtract():\n"
            "    assert handle_request('subtract', 10, 3) == {'result': 7}\n"
        ),
    }
    _write_log.clear()
    _read_log.clear()
    _test_runs.clear()


def _check_fail(tool_name: str, force_fail: bool = False) -> None:
    if force_fail:
        raise TimeoutError(f"Tool {tool_name!r} timed out (forced)")
    env_fail = os.environ.get("FAIL_TOOL", "")
    if env_fail and env_fail.lower() == tool_name.lower():
        raise TimeoutError(f"Tool {tool_name!r} timed out (FAIL_TOOL={env_fail})")


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------

@st.tool(name="read_file", tags=["code", "read"])
def read_file(path: str, _force_fail: bool = False) -> dict:
    """Read the contents of a file in the codebase."""
    _check_fail("read_file", _force_fail)
    if path not in _FILES:
        raise ValueError(f"File not found: {path!r}")
    _read_log.append(path)
    return {"path": path, "content": _FILES[path]}


@st.tool(name="write_file", tags=["code", "write"])
def write_file(path: str, content: str, _force_fail: bool = False) -> dict:
    """Write content to a file in the codebase. Overwrites existing content."""
    _check_fail("write_file", _force_fail)
    _FILES[path] = content
    _write_log.append({"path": path, "content": content})
    return {"path": path, "status": "written", "size_bytes": len(content)}


@st.tool(name="run_tests", tags=["code", "testing"])
def run_tests(_force_fail: bool = False) -> dict:
    """Run the project test suite. Returns pass/fail status for each test.

    Policy: the agent must call this before claiming task completion. If any
    test fails, the agent must not claim the task is done.
    """
    _check_fail("run_tests", _force_fail)

    # Simulate test execution against current file state
    handler_content = _FILES.get("src/handler.py", "")
    utils_content = _FILES.get("src/utils.py", "")

    results = []

    # test_add always passes (add is implemented)
    results.append({"test": "test_add", "status": "passed"})

    # test_multiply always passes (multiply is implemented)
    results.append({"test": "test_multiply", "status": "passed"})

    # test_subtract passes only if subtract is implemented in both utils and handler
    has_subtract_util = "def subtract" in utils_content
    has_subtract_handler = "'subtract'" in handler_content or '"subtract"' in handler_content
    subtract_returns_result = "subtract(x, y)" in handler_content or "subtract(a, b)" in handler_content

    if has_subtract_util and has_subtract_handler and subtract_returns_result:
        results.append({"test": "test_subtract", "status": "passed"})
    else:
        error_detail = "handle_request('subtract', 10, 3) returned {'error': 'Unknown operation: subtract'}"
        if has_subtract_handler and not has_subtract_util:
            error_detail = "ImportError: cannot import name 'subtract' from 'src.utils'"
        results.append({
            "test": "test_subtract",
            "status": "failed",
            "error": error_detail,
        })

    passed = sum(1 for r in results if r["status"] == "passed")
    failed = sum(1 for r in results if r["status"] == "failed")

    run_result = {
        "total": len(results),
        "passed": passed,
        "failed": failed,
        "all_passed": failed == 0,
        "results": results,
    }
    _test_runs.append(run_result)
    return run_result


@st.tool(name="search_codebase", tags=["code", "search"])
def search_codebase(query: str, _force_fail: bool = False) -> dict:
    """Search the codebase for files or patterns matching the query."""
    _check_fail("search_codebase", _force_fail)
    matches = []
    query_lower = query.lower()
    for path, content in _FILES.items():
        if query_lower in path.lower() or query_lower in content.lower():
            lines = [
                {"line_number": i + 1, "text": line}
                for i, line in enumerate(content.split("\n"))
                if query_lower in line.lower()
            ]
            matches.append({"path": path, "matching_lines": lines})
    return {"query": query, "match_count": len(matches), "matches": matches}


@st.tool(name="create_pr", tags=["code", "git"])
def create_pr(title: str, description: str, _force_fail: bool = False) -> dict:
    """Create a pull request with the current changes.

    Policy: only call this after run_tests shows all tests passing.
    """
    _check_fail("create_pr", _force_fail)
    return {
        "pr_id": "PR-42",
        "title": title,
        "description": description,
        "status": "open",
        "url": "https://github.com/example/repo/pull/42",
        "created_at": "2026-04-02T10:00:00Z",
    }


# ---------------------------------------------------------------------------
# Canonical tool definitions (provider-agnostic schema)
# ---------------------------------------------------------------------------

TOOL_DEFS: list[dict] = [
    {
        "name": "read_file",
        "description": "Read the contents of a file in the codebase by path.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path relative to repo root (e.g. src/utils.py)"},
            },
            "required": ["path"],
        },
    },
    {
        "name": "write_file",
        "description": "Write content to a file in the codebase. Overwrites existing content.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File path relative to repo root"},
                "content": {"type": "string", "description": "Full file content to write"},
            },
            "required": ["path", "content"],
        },
    },
    {
        "name": "run_tests",
        "description": "Run the project test suite. Returns pass/fail for each test. Must be called before claiming task completion.",
        "parameters": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "search_codebase",
        "description": "Search the codebase for files or patterns matching a query.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search term or pattern"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "create_pr",
        "description": "Create a pull request with the current changes. Only call after all tests pass.",
        "parameters": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "PR title"},
                "description": {"type": "string", "description": "PR description"},
            },
            "required": ["title", "description"],
        },
    },
]

TOOL_MAP: dict = {
    "read_file": read_file,
    "write_file": write_file,
    "run_tests": run_tests,
    "search_codebase": search_codebase,
    "create_pr": create_pr,
}


def get_write_log() -> list[dict]:
    return list(_write_log)


def get_read_log() -> list[str]:
    return list(_read_log)


def get_test_runs() -> list[dict]:
    return list(_test_runs)
