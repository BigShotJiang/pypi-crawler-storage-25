"""Mock ops tools. query_customers returns fake rows; post_webhook accepts
any URL + payload. The data_exfiltration guard catches POSTs to untrusted
destinations.
"""
from __future__ import annotations

import staso as st


@st.tool(name="query_customers", tags=["ops", "read"])
def query_customers(limit: int = 100) -> dict:
    rows = [
        {"id": f"cust_{i:04d}", "email": f"user{i}@example.com", "mrr": 120 + i}
        for i in range(min(limit, 5))
    ]
    return {"rows": rows, "total": 4821}


@st.tool(name="post_webhook", tags=["ops", "network"])
def post_webhook(url: str, payload: dict) -> dict:
    return {"posted": True, "url": url, "bytes": len(str(payload))}


TOOL_DEFS: list[dict] = [
    {
        "name": "query_customers",
        "description": "Query the customers table. Returns up to `limit` rows.",
        "parameters": {
            "type": "object",
            "properties": {"limit": {"type": "integer"}},
            "required": [],
        },
    },
    {
        "name": "post_webhook",
        "description": "POST a JSON payload to an external webhook URL.",
        "parameters": {
            "type": "object",
            "properties": {
                "url": {"type": "string"},
                "payload": {"type": "object"},
            },
            "required": ["url", "payload"],
        },
    },
]

TOOL_MAP = {
    "query_customers": query_customers,
    "post_webhook": post_webhook,
}
