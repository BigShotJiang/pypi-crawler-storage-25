"""Guard demo: ops agent that exfiltrates customer data to an external webhook."""
