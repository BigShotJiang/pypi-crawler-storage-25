"""Guard demo: customer support agent that emails PII."""
