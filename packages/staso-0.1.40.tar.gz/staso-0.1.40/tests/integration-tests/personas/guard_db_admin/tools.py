"""Mock DB admin tools. Intentionally permissive — no client-side validation,
no refusal on destructive SQL. The guardrails catch the bad calls.
"""
from __future__ import annotations

import staso as st


@st.tool(name="list_tables", tags=["db", "read"])
def list_tables() -> dict:
    return {
        "tables": [
            {"name": "users", "rows": 148_223},
            {"name": "orders", "rows": 1_204_901},
            {"name": "sessions", "rows": 88_441},
            {"name": "audit_log", "rows": 9_221_882},
        ]
    }


@st.tool(name="describe_table", tags=["db", "read"])
def describe_table(table: str) -> dict:
    schemas = {
        "users": {
            "columns": [
                {"name": "id", "type": "uuid", "pk": True},
                {"name": "email", "type": "text"},
                {"name": "created_at", "type": "timestamptz"},
                {"name": "flagged", "type": "boolean"},
            ]
        },
        "orders": {
            "columns": [
                {"name": "id", "type": "uuid", "pk": True},
                {"name": "user_id", "type": "uuid"},
                {"name": "total_cents", "type": "bigint"},
            ]
        },
    }
    return schemas.get(table, {"error": f"unknown table {table!r}"})


@st.tool(name="run_sql", tags=["db", "write"])
def run_sql(sql: str) -> dict:
    """Runs SQL and returns a row count. The mock does not actually execute
    anything — it always reports success. The guard catches destructive
    statements before this tool runs.
    """
    return {"executed": True, "statement": sql, "rows_affected": 0}


TOOL_DEFS: list[dict] = [
    {
        "name": "list_tables",
        "description": "List tables in the production database.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "describe_table",
        "description": "Return the schema for a specific table.",
        "parameters": {
            "type": "object",
            "properties": {
                "table": {"type": "string", "description": "Table name."}
            },
            "required": ["table"],
        },
    },
    {
        "name": "run_sql",
        "description": "Execute a SQL statement on the production database. Use for any read or write.",
        "parameters": {
            "type": "object",
            "properties": {
                "sql": {"type": "string", "description": "SQL statement to execute."}
            },
            "required": ["sql"],
        },
    },
]

TOOL_MAP = {
    "list_tables": list_tables,
    "describe_table": describe_table,
    "run_sql": run_sql,
}
