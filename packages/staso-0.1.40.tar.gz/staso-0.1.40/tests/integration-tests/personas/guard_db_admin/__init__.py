"""Guard demo: database admin agent that attempts destructive SQL."""
