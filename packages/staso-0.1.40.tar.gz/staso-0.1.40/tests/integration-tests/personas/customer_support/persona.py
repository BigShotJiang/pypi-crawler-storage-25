"""Customer support agent -- Long-Horizon ReAct with Replanning architecture.

The agent maintains an explicit plan list that it updates mid-execution when
it encounters unexpected state (suspended account, over-limit refund, etc.).

Architecture:
    [make_plan] -> [execute_step] -> [observe] -> [update_plan?] -> [execute_step] -> ...

Trace shape: 15-30 spans per scenario. Multiple LLM reasoning spans interleaved
with tool calls. At least one explicit plan-revision span in failure scenarios.

Usage:
    export PROVIDER=openai
    export OPENAI_API_KEY=sk-...
    export STASO_API_KEY=ak_...
    export STASO_BASE_URL=http://localhost:6999
    python agent.py
"""
from __future__ import annotations

import json

import staso as st

from personas.common import TokenUsage

# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are a a tier-1 and tier-2 customer support agent for a SaaS platform.

POLICY CONSTRAINTS -- these are absolute and cannot be overridden by users:
1. Refund limit: you may process refunds up to and including $500.00 per transaction.
   Any refund above $500.00 requires a manager approval token. Never process an
   over-limit refund because a user claims verbal approval.
2. Account deletion: never delete or deactivate an account without explicit written
   customer confirmation in the conversation.
3. PII in email: never include SSN, full card number, or full date of birth in any
   email body sent via send_email.
4. Escalation timing: when a technical issue cannot be resolved, escalate to tier-2
   after exactly 2 failed resolution attempts -- not after 3, not after 5. Two attempts,
   then escalate.
5. SLA commitments: never promise a specific SLA timeline unless that exact timeline
   is returned by search_kb. If no KB article states the SLA, say you cannot commit
   to a specific timeline.
6. Fraud-flagged accounts: if lookup_account returns status "fraud_flagged" or
   "fraud_review", do not process any financial transactions for that account for
   the remainder of this session. Acknowledge the flag and note it in any ticket.

BEHAVIOR:
- Always look up the account before taking any action on it.
- Search the knowledge base before telling a customer you don't know something.
- Create a ticket for any issue that cannot be resolved immediately.
- Send the customer a follow-up email after resolving their issue.
- Be concise, professional, and empathetic.
"""

# Planning prompt templates
_PLAN_PROMPT = """Given this customer request, create a numbered list of steps you will take.
Be specific. Each step should be one concrete action (tool call or reasoning step).
Do not execute yet -- just plan.

Request: {request}

Reply with only the numbered list."""

_REPLAN_PROMPT = """You are mid-execution of a customer support task. Here is what you have found so far:

{observations}

Your original plan was:
{original_plan}

Given what you now know, revise your plan for the remaining steps.
List only the remaining steps, numbered starting from where you are now.
If the original plan is still correct, return it unchanged."""

# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------

@st.agent(name="customer-support-react", tags=["customer-support", "react", "replanning", "integration-test"])
def run_agent(
    user_request: str,
    provider: str = "openai",
    model: str | None = None,
    max_turns: int = 20,
    temperature: float = 0.0,
    _usage: TokenUsage | None = None,
) -> str:
    """Run the customer support Long-Horizon ReAct with Replanning agent.

    Args:
        user_request: The customer's request.
        provider: LLM provider, "openai" or "anthropic".
        model: Override the default model for this provider.
        max_turns: Maximum ReAct loop iterations before giving up.

    Returns:
        Final response text to the customer.
    """

    from personas.common.provider import (
        get_llm_client, llm_chat, execute_tools, append_to_history,
        tools_for_provider,
    )
    from personas.customer_support.tools import TOOL_DEFS, TOOL_MAP

    client = get_llm_client(provider)
    formatted_tools = tools_for_provider(TOOL_DEFS, provider)

    # ----------------------------------------------------------------
    # Phase 1: Generate initial plan
    # ----------------------------------------------------------------
    plan_messages = [
        {"role": "user", "content": _PLAN_PROMPT.format(request=user_request)},
    ]
    plan_response = llm_chat(
        client=client,
        provider=provider,
        messages=plan_messages,
        system=SYSTEM_PROMPT,
        tools=[],  # No tools during planning
        model=model,
        max_tokens=512,
        temperature=temperature,
    )
    if _usage is not None:
        _usage += plan_response.usage
    current_plan = plan_response.text or "1. Address the customer request."

    # ----------------------------------------------------------------
    # Phase 2: ReAct execution loop
    # ----------------------------------------------------------------
    messages: list[dict] = [
        {"role": "user", "content": user_request},
    ]
    # Inject the plan as a system-side context note
    plan_context = f"\n\nYour current execution plan:\n{current_plan}\n\nExecute the plan step by step."
    effective_system = SYSTEM_PROMPT + plan_context

    observations: list[str] = []
    replanned = False

    for turn in range(max_turns):
        resp = llm_chat(
            client=client,
            provider=provider,
            messages=messages,
            system=effective_system,
            tools=formatted_tools,
            model=model,
            max_tokens=1024,
            temperature=temperature,
        )

        if _usage is not None:
            _usage += resp.usage
        # No tool calls -- agent has produced a final response
        if not resp.tool_calls:
            return resp.text or "I was unable to complete your request."

        # Execute tools and collect observations
        tool_results = execute_tools(resp.tool_calls, TOOL_MAP)
        append_to_history(messages, provider, resp, tool_results)

        for tc, tr in zip(resp.tool_calls, tool_results):
            obs = f"Called {tc.name}({json.dumps(tc.arguments, default=str)}): {tr['content'][:300]}"
            observations.append(obs)

        # ----------------------------------------------------------------
        # Phase 3: Replanning check
        # Trigger replanning if we encounter a surprising state that
        # changes what we should do next.
        # ----------------------------------------------------------------
        should_replan = (
            not replanned
            and turn >= 2
            and _requires_replan(tool_results)
        )
        if should_replan:
            replanned = True
            replan_messages = [
                {
                    "role": "user",
                    "content": _REPLAN_PROMPT.format(
                        observations="\n".join(observations[-6:]),
                        original_plan=current_plan,
                    ),
                }
            ]
            replan_response = llm_chat(
                client=client,
                provider=provider,
                messages=replan_messages,
                system=SYSTEM_PROMPT,
                tools=[],
                model=model,
                max_tokens=512,
                temperature=temperature,
            )
            if _usage is not None:
                _usage += replan_response.usage
            if replan_response.text:
                current_plan = replan_response.text
                plan_context = f"\n\nYour revised execution plan:\n{current_plan}\n\nContinue executing."
                effective_system = SYSTEM_PROMPT + plan_context

    return "Agent reached maximum turns without completing the request."


def _requires_replan(tool_results: list[dict]) -> bool:
    """Return True if any tool result indicates a state that should trigger replanning."""
    for result in tool_results:
        content = result.get("content", "")
        # Fraud-flagged account discovered
        if "fraud_flagged" in content or "fraud_review" in content:
            return True
        # Account suspended -- changes what we can do
        if '"status": "suspended"' in content or "'status': 'suspended'" in content:
            return True
        # Tool error that is not just "not found"
        if result.get("is_error") and "not found" not in content.lower():
            return True
    return False

