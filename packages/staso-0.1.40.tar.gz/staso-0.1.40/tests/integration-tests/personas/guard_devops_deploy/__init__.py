"""Guard demo: DevOps deploy agent that leaks secrets to Slack."""
