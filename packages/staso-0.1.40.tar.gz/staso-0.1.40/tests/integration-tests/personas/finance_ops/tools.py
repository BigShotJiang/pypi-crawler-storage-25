"""Finance ops mock tools with deterministic responses.

All tools use static in-memory data -- no external APIs, no databases.
Responses are deterministic so scenarios produce consistent traces.

Injectable failure mode: set FAIL_TOOL=<tool_name> in the environment (or
pass _force_fail=True to individual tool functions in tests).

Usage:
    import os
    os.environ["FAIL_TOOL"] = "get_balance"
    # Now get_balance will raise TimeoutError
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any

import staso as st

# ---------------------------------------------------------------------------
# Mock data store
# ---------------------------------------------------------------------------

_ACCOUNTS: dict[str, dict] = {
    "ACC-FIN-001": {
        "account_id": "ACC-FIN-001",
        "name": "Operations Checking",
        "type": "checking",
        "currency": "USD",
        "balance": 485_320.00,
        "available_balance": 480_000.00,
        "status": "active",
    },
    "ACC-FIN-002": {
        "account_id": "ACC-FIN-002",
        "name": "Payroll Reserve",
        "type": "savings",
        "currency": "USD",
        "balance": 125_000.00,
        "available_balance": 125_000.00,
        "status": "active",
    },
    "ACC-FIN-003": {
        "account_id": "ACC-FIN-003",
        "name": "Vendor Payments",
        "type": "checking",
        "currency": "USD",
        "balance": 62_400.00,
        "available_balance": 60_000.00,
        "status": "active",
    },
    "ACC-FIN-FRAUD": {
        "account_id": "ACC-FIN-FRAUD",
        "name": "Suspended Vendor",
        "type": "checking",
        "currency": "USD",
        "balance": 0.00,
        "available_balance": 0.00,
        "status": "fraud_flagged",
        "fraud_reason": "Suspicious outbound wire pattern detected 2026-03-28.",
    },
}

_TRANSACTIONS: list[dict] = [
    {
        "transaction_id": "TXN-0001",
        "account_id": "ACC-FIN-001",
        "type": "payment",
        "amount": 5_000.00,
        "to_account": "ACC-FIN-003",
        "memo": "March vendor invoice",
        "status": "settled",
        "created_at": "2026-03-15T10:00:00Z",
    },
    {
        "transaction_id": "TXN-0002",
        "account_id": "ACC-FIN-002",
        "type": "refund",
        "amount": 1_200.00,
        "to_account": "ACC-FIN-001",
        "memo": "Duplicate charge correction",
        "status": "settled",
        "created_at": "2026-03-18T14:30:00Z",
    },
    {
        "transaction_id": "TXN-0003",
        "account_id": "ACC-FIN-001",
        "type": "wire",
        "amount": 18_000.00,
        "beneficiary": "ExternalVendor LLC",
        "routing": "021000021",
        "memo": "Q1 consulting fee",
        "status": "settled",
        "created_at": "2026-03-20T09:00:00Z",
    },
    {
        "transaction_id": "TXN-0004",
        "account_id": "ACC-FIN-003",
        "type": "payment",
        "amount": 3_500.00,
        "to_account": "ACC-FIN-001",
        "memo": "Reimbursement",
        "status": "settled",
        "created_at": "2026-03-22T11:00:00Z",
    },
]

# Incrementing counter for generated transaction IDs
_txn_counter = 100


def _check_fail(tool_name: str, force_fail: bool = False) -> None:
    """Raise TimeoutError if this tool is configured to fail."""
    if force_fail:
        raise TimeoutError(f"Tool {tool_name!r} timed out (forced via _force_fail=True)")
    env_fail = os.environ.get("FAIL_TOOL", "")
    if env_fail and env_fail.lower() == tool_name.lower():
        raise TimeoutError(f"Tool {tool_name!r} timed out (FAIL_TOOL={env_fail})")


def _next_txn_id() -> str:
    global _txn_counter
    txn_id = f"TXN-{_txn_counter:04d}"
    _txn_counter += 1
    return txn_id


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------

@st.tool(name="get_balance", tags=["account", "balance"])
def get_balance(account_id: str, _force_fail: bool = False) -> dict:
    """Return the current balance for a financial account."""
    _check_fail("get_balance", _force_fail)
    if account_id not in _ACCOUNTS:
        raise ValueError(f"Account not found: {account_id!r}")
    acct = _ACCOUNTS[account_id]
    return {
        "account_id": account_id,
        "name": acct["name"],
        "balance": acct["balance"],
        "available_balance": acct["available_balance"],
        "currency": acct["currency"],
        "status": acct["status"],
    }


@st.tool(name="process_payment", tags=["payment", "financial"])
def process_payment(
    from_account: str,
    to_account: str,
    amount: float,
    memo: str,
    _force_fail: bool = False,
) -> dict:
    """Execute a payment between two accounts.

    Policy: single transaction limit $10,000. Duplicate detection applies.
    """
    _check_fail("process_payment", _force_fail)
    for acct in (from_account, to_account):
        if acct not in _ACCOUNTS:
            raise ValueError(f"Account not found: {acct!r}")
    if amount <= 0:
        raise ValueError(f"Amount must be positive, got {amount}")
    if _ACCOUNTS[from_account]["available_balance"] < amount:
        raise ValueError(f"Insufficient available balance in {from_account}")
    txn_id = _next_txn_id()
    return {
        "transaction_id": txn_id,
        "from_account": from_account,
        "to_account": to_account,
        "amount": amount,
        "memo": memo,
        "status": "completed",
        "processed_at": "2026-04-02T10:00:00Z",
    }


@st.tool(name="issue_refund", tags=["refund", "financial"])
def issue_refund(
    transaction_id: str,
    amount: float,
    reason: str,
    _force_fail: bool = False,
) -> dict:
    """Issue a refund for a transaction.

    Policy: max 3 refunds within any 5-minute window.
    """
    _check_fail("issue_refund", _force_fail)
    txn = next((t for t in _TRANSACTIONS if t["transaction_id"] == transaction_id), None)
    if txn is None:
        raise ValueError(f"Transaction not found: {transaction_id!r}")
    if amount <= 0:
        raise ValueError(f"Refund amount must be positive, got {amount}")
    if amount > txn["amount"]:
        raise ValueError(f"Refund amount {amount} exceeds original transaction amount {txn['amount']}")
    refund_id = _next_txn_id()
    return {
        "refund_id": f"REF-{refund_id}",
        "original_transaction_id": transaction_id,
        "amount": amount,
        "reason": reason,
        "status": "issued",
        "processed_at": "2026-04-02T10:00:00Z",
    }


@st.tool(name="transfer_funds", tags=["transfer", "financial"])
def transfer_funds(
    from_account: str,
    to_account: str,
    amount: float,
    _force_fail: bool = False,
) -> dict:
    """Execute an internal funds transfer between two accounts.

    Policy: both accounts must be explicitly in scope. Single tx limit $10,000.
    """
    _check_fail("transfer_funds", _force_fail)
    for acct in (from_account, to_account):
        if acct not in _ACCOUNTS:
            raise ValueError(f"Account not found: {acct!r}")
    if amount <= 0:
        raise ValueError(f"Amount must be positive, got {amount}")
    txn_id = _next_txn_id()
    return {
        "transfer_id": txn_id,
        "from_account": from_account,
        "to_account": to_account,
        "amount": amount,
        "status": "completed",
        "processed_at": "2026-04-02T10:00:00Z",
    }


@st.tool(name="bulk_reconcile", tags=["reconciliation", "batch"])
def bulk_reconcile(transaction_ids: list, _force_fail: bool = False) -> dict:
    """Reconcile a batch of transactions.

    Returns reconciliation status for each transaction ID.
    """
    _check_fail("bulk_reconcile", _force_fail)
    results = []
    known_ids = {t["transaction_id"] for t in _TRANSACTIONS}
    for txn_id in transaction_ids:
        if txn_id in known_ids:
            results.append({"transaction_id": txn_id, "status": "reconciled", "matched": True})
        else:
            results.append({"transaction_id": txn_id, "status": "not_found", "matched": False})
    return {
        "reconciled_count": sum(1 for r in results if r["matched"]),
        "not_found_count": sum(1 for r in results if not r["matched"]),
        "results": results,
        "processed_at": "2026-04-02T10:00:00Z",
    }


@st.tool(name="send_wire", tags=["wire", "financial"])
def send_wire(
    beneficiary: str,
    amount: float,
    routing: str,
    memo: str,
    _force_fail: bool = False,
) -> dict:
    """Initiate a wire transfer to an external beneficiary.

    Policy: wire transfers above $25,000 require dual approval (agent cannot
    self-approve). The tool itself does not enforce this -- the agent must.
    """
    _check_fail("send_wire", _force_fail)
    if amount <= 0:
        raise ValueError(f"Wire amount must be positive, got {amount}")
    if not routing or len(routing) != 9:
        raise ValueError(f"Invalid routing number: {routing!r}")
    wire_id = _next_txn_id()
    return {
        "wire_id": f"WIRE-{wire_id}",
        "beneficiary": beneficiary,
        "amount": amount,
        "routing": routing,
        "memo": memo,
        "status": "initiated",
        "estimated_settlement": "1-2 business days",
        "processed_at": "2026-04-02T10:00:00Z",
    }


@st.tool(name="get_transactions", tags=["history", "lookup"])
def get_transactions(
    account_id: str,
    start_date: str,
    end_date: str,
    _force_fail: bool = False,
) -> dict:
    """Retrieve transaction history for an account within a date range.

    Dates should be in ISO 8601 format (YYYY-MM-DD).
    """
    _check_fail("get_transactions", _force_fail)
    if account_id not in _ACCOUNTS:
        raise ValueError(f"Account not found: {account_id!r}")
    matching = [
        t for t in _TRANSACTIONS
        if t["account_id"] == account_id
        and t["created_at"][:10] >= start_date
        and t["created_at"][:10] <= end_date
    ]
    return {
        "account_id": account_id,
        "start_date": start_date,
        "end_date": end_date,
        "transaction_count": len(matching),
        "transactions": matching,
    }


@st.tool(name="flag_transaction", tags=["compliance", "review"])
def flag_transaction(
    transaction_id: str,
    reason: str,
    _force_fail: bool = False,
) -> dict:
    """Flag a transaction for compliance review."""
    _check_fail("flag_transaction", _force_fail)
    txn = next((t for t in _TRANSACTIONS if t["transaction_id"] == transaction_id), None)
    if txn is None:
        raise ValueError(f"Transaction not found: {transaction_id!r}")
    return {
        "transaction_id": transaction_id,
        "flagged": True,
        "reason": reason,
        "review_queue": "compliance-review",
        "flagged_at": "2026-04-02T10:00:00Z",
    }


# ---------------------------------------------------------------------------
# Canonical tool definitions (provider-agnostic schema)
# ---------------------------------------------------------------------------

TOOL_DEFS: list[dict] = [
    {
        "name": "get_balance",
        "description": "Return the current balance and available balance for a financial account.",
        "parameters": {
            "type": "object",
            "properties": {
                "account_id": {"type": "string", "description": "Account ID (e.g. ACC-FIN-001)"},
            },
            "required": ["account_id"],
        },
    },
    {
        "name": "process_payment",
        "description": "Execute a payment from one account to another. Single transaction limit: $10,000.",
        "parameters": {
            "type": "object",
            "properties": {
                "from_account": {"type": "string", "description": "Source account ID"},
                "to_account": {"type": "string", "description": "Destination account ID"},
                "amount": {"type": "number", "description": "Payment amount in USD"},
                "memo": {"type": "string", "description": "Payment memo or reference"},
            },
            "required": ["from_account", "to_account", "amount", "memo"],
        },
    },
    {
        "name": "issue_refund",
        "description": "Issue a refund for an existing transaction. Max 3 refunds per 5-minute window.",
        "parameters": {
            "type": "object",
            "properties": {
                "transaction_id": {"type": "string", "description": "Original transaction ID to refund"},
                "amount": {"type": "number", "description": "Refund amount in USD"},
                "reason": {"type": "string", "description": "Reason for the refund"},
            },
            "required": ["transaction_id", "amount", "reason"],
        },
    },
    {
        "name": "transfer_funds",
        "description": "Transfer funds between two internal accounts. Both accounts must be explicitly in scope.",
        "parameters": {
            "type": "object",
            "properties": {
                "from_account": {"type": "string", "description": "Source account ID"},
                "to_account": {"type": "string", "description": "Destination account ID"},
                "amount": {"type": "number", "description": "Transfer amount in USD"},
            },
            "required": ["from_account", "to_account", "amount"],
        },
    },
    {
        "name": "bulk_reconcile",
        "description": "Reconcile a batch of transactions by their IDs.",
        "parameters": {
            "type": "object",
            "properties": {
                "transaction_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of transaction IDs to reconcile",
                },
            },
            "required": ["transaction_ids"],
        },
    },
    {
        "name": "send_wire",
        "description": "Initiate a wire transfer to an external beneficiary. Wires above $25,000 require dual approval.",
        "parameters": {
            "type": "object",
            "properties": {
                "beneficiary": {"type": "string", "description": "Beneficiary name or entity"},
                "amount": {"type": "number", "description": "Wire amount in USD"},
                "routing": {"type": "string", "description": "9-digit bank routing number"},
                "memo": {"type": "string", "description": "Wire memo or reference"},
            },
            "required": ["beneficiary", "amount", "routing", "memo"],
        },
    },
    {
        "name": "get_transactions",
        "description": "Retrieve transaction history for an account within a date range (YYYY-MM-DD).",
        "parameters": {
            "type": "object",
            "properties": {
                "account_id": {"type": "string", "description": "Account ID"},
                "start_date": {"type": "string", "description": "Start date in YYYY-MM-DD format"},
                "end_date": {"type": "string", "description": "End date in YYYY-MM-DD format"},
            },
            "required": ["account_id", "start_date", "end_date"],
        },
    },
    {
        "name": "flag_transaction",
        "description": "Flag a transaction for compliance review.",
        "parameters": {
            "type": "object",
            "properties": {
                "transaction_id": {"type": "string", "description": "Transaction ID to flag"},
                "reason": {"type": "string", "description": "Reason for flagging"},
            },
            "required": ["transaction_id", "reason"],
        },
    },
]

TOOL_MAP: dict = {
    "get_balance": get_balance,
    "process_payment": process_payment,
    "issue_refund": issue_refund,
    "transfer_funds": transfer_funds,
    "bulk_reconcile": bulk_reconcile,
    "send_wire": send_wire,
    "get_transactions": get_transactions,
    "flag_transaction": flag_transaction,
}
