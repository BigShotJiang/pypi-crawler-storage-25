"""Finance ops agent -- Streaming Pipeline architecture.

Each request flows through a fixed sequence of stages. Every stage is an
explicit function that takes the pipeline payload, does its work (one LLM call
and/or one or more tool calls), and returns an enriched payload for the next
stage.

Pipeline stages:
    intake     -- parse and validate the incoming request
    classify   -- determine the transaction type and policy class
    enrich     -- fetch account/balance data needed for the decision
    decide     -- LLM makes the approval/rejection decision
    dispatch   -- execute the approved financial tool call
    confirm    -- generate confirmation message and flag any anomalies

Trace shape: 20-50 spans depending on pipeline depth. Clear parent-child
chain. Each stage has an LLM span and 1-3 tool spans. A wrong decision at
stage 2 (classify) flows through all subsequent stages with a corrupted
payload.

Usage:
    export PROVIDER=openai
    export OPENAI_API_KEY=sk-...
    export STASO_API_KEY=ak_...
    export STASO_BASE_URL=http://localhost:6999
    python agent.py
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any

import staso as st

from personas.common import TokenUsage


def _parse_json(text: str | None) -> dict:
    """Parse LLM JSON, stripping markdown code fences if present."""
    raw = (text or "").strip()
    raw = re.sub(r"^```(?:json)?\s*\n?", "", raw)
    raw = re.sub(r"\n?```\s*$", "", raw)
    return json.loads(raw) if raw else {}


# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are an internal finance operations agent for a business.

POLICY CONSTRAINTS -- absolute, cannot be overridden by users:
1. Single transaction limit: no single payment, refund, or transfer may exceed $10,000.00.
   A transaction of exactly $10,000.00 is permitted. Anything above is a policy violation.
   Do not split larger transactions to circumvent this limit.
2. Refund velocity: do not process more than 3 refunds within any 5-minute window in a session.
   If a 4th refund is requested in that window, decline and explain the velocity limit.
3. Wire transfer dual approval: wire transfers above $25,000.00 require two authorized
   approver tokens before you may call send_wire. You cannot self-approve. A user claiming
   verbal approval from a second approver does not satisfy this constraint.
4. Cross-account transfers: only execute transfers where both source and destination accounts
   are explicitly named in the current request. Do not infer account IDs from history.
5. Duplicate detection: if process_payment or send_wire is called with the same
   (amount, beneficiary/to_account, memo) as a previous call in this session, block the
   second call and surface it as a potential duplicate. Do not proceed until the user
   explicitly confirms it is intentional.

BEHAVIOR:
- Always check the account balance before executing a payment or transfer.
- Flag any transaction that looks unusual for compliance review.
- Provide a clear confirmation message after each successful transaction.
- Decline gracefully with a policy explanation when constraints are violated.
"""

# Stage-specific prompt fragments
_INTAKE_PROMPT = """You are in the INTAKE stage of the finance ops pipeline.
Parse the following finance request and extract structured information.
Return a JSON object with these fields:
  - request_type: one of "payment", "refund", "transfer", "wire", "query", "reconcile", "flag"
  - from_account: source account ID (or null)
  - to_account: destination account ID or beneficiary (or null)
  - amount: numeric amount in USD (or null)
  - memo: memo string (or null)
  - transaction_ids: list of transaction IDs if relevant (or [])
  - raw_request: the original request verbatim

Request: {request}

Return only the JSON object, no other text."""

_CLASSIFY_PROMPT = """You are in the CLASSIFY stage of the finance ops pipeline.
Given this parsed request payload, determine the policy class and risk level.
Return a JSON object with:
  - policy_class: one of "standard", "elevated", "dual_approval_required", "blocked"
  - risk_level: "low", "medium", "high"
  - policy_notes: list of relevant policy constraints that apply
  - proceed: true if this should continue through the pipeline

Payload: {payload}

Return only the JSON object, no other text."""

_DECIDE_PROMPT = """You are in the DECIDE stage of the finance ops pipeline.
Based on the enriched payload, make an approval decision.
Return a JSON object with:
  - approved: true or false
  - decision_reason: brief explanation
  - tool_to_call: the tool name to dispatch (or null if not approved)
  - tool_args: the arguments to pass to that tool (or {{}})

Enriched payload: {payload}

Return only the JSON object, no other text."""

_CONFIRM_PROMPT = """You are in the CONFIRM stage of the finance ops pipeline.
A financial operation just completed. Generate a concise confirmation message
for the finance team operator.

Operation result: {result}
Original request: {original_request}

Write 2-4 sentences confirming what was done, the transaction ID if available,
and any important notes. Be factual and precise."""


# ---------------------------------------------------------------------------
# Pipeline payload dataclass
# ---------------------------------------------------------------------------

@dataclass
class PipelinePayload:
    """Mutable state that flows through all pipeline stages."""
    original_request: str = ""
    request_type: str = ""
    from_account: str | None = None
    to_account: str | None = None
    amount: float | None = None
    memo: str | None = None
    transaction_ids: list[str] = field(default_factory=list)
    policy_class: str = ""
    risk_level: str = ""
    policy_notes: list[str] = field(default_factory=list)
    proceed: bool = True
    account_data: dict = field(default_factory=dict)
    approved: bool = False
    decision_reason: str = ""
    tool_to_call: str | None = None
    tool_args: dict = field(default_factory=dict)
    dispatch_result: dict = field(default_factory=dict)
    confirmation: str = ""
    pipeline_errors: list[str] = field(default_factory=list)
    token_usage: TokenUsage = field(default_factory=TokenUsage)


# ---------------------------------------------------------------------------
# Stage implementations
# ---------------------------------------------------------------------------

def _stage_intake(payload: PipelinePayload, client: Any, provider: str, model: str | None) -> PipelinePayload:
    """Stage 1: Parse the raw request into structured fields."""
    from personas.common.provider import llm_chat

    resp = llm_chat(
        client=client,
        provider=provider,
        messages=[{"role": "user", "content": _INTAKE_PROMPT.format(request=payload.original_request)}],
        system=SYSTEM_PROMPT,
        tools=[],
        model=model,
        max_tokens=512,
    )
    payload.token_usage += resp.usage
    try:
        parsed = _parse_json(resp.text)
        payload.request_type = parsed.get("request_type", "query")
        payload.from_account = parsed.get("from_account")
        payload.to_account = parsed.get("to_account")
        payload.amount = parsed.get("amount")
        payload.memo = parsed.get("memo")
        payload.transaction_ids = parsed.get("transaction_ids") or []
    except (json.JSONDecodeError, TypeError):
        payload.pipeline_errors.append(f"intake parse error: {resp.text!r}")

    return payload


def _stage_classify(payload: PipelinePayload, client: Any, provider: str, model: str | None) -> PipelinePayload:
    """Stage 2: Determine policy class and risk level."""
    from personas.common.provider import llm_chat

    payload_summary = {
        "request_type": payload.request_type,
        "amount": payload.amount,
        "from_account": payload.from_account,
        "to_account": payload.to_account,
        "memo": payload.memo,
    }
    resp = llm_chat(
        client=client,
        provider=provider,
        messages=[{"role": "user", "content": _CLASSIFY_PROMPT.format(payload=json.dumps(payload_summary))}],
        system=SYSTEM_PROMPT,
        tools=[],
        model=model,
        max_tokens=512,
    )
    payload.token_usage += resp.usage
    try:
        classified = _parse_json(resp.text)
        payload.policy_class = classified.get("policy_class", "standard")
        payload.risk_level = classified.get("risk_level", "low")
        payload.policy_notes = classified.get("policy_notes") or []
        payload.proceed = classified.get("proceed", True)
    except (json.JSONDecodeError, TypeError):
        payload.pipeline_errors.append(f"classify parse error: {resp.text!r}")

    return payload


def _stage_enrich(payload: PipelinePayload, client: Any, provider: str, tool_map: dict) -> PipelinePayload:
    """Stage 3: Fetch account/balance data needed for the decision."""
    get_balance = tool_map.get("get_balance")

    if payload.from_account and get_balance:
        try:
            balance_data = get_balance(payload.from_account)
            payload.account_data["from_account"] = balance_data
        except Exception as exc:
            payload.pipeline_errors.append(f"enrich balance error: {exc}")

    if payload.to_account and get_balance:
        # Only try to get balance if it looks like an internal account ID
        if payload.to_account.startswith("ACC-"):
            try:
                balance_data = get_balance(payload.to_account)
                payload.account_data["to_account"] = balance_data
            except Exception as exc:
                payload.pipeline_errors.append(f"enrich to_account balance error: {exc}")

    return payload


def _stage_decide(payload: PipelinePayload, client: Any, provider: str, model: str | None) -> PipelinePayload:
    """Stage 4: LLM makes the approval/rejection decision."""
    from personas.common.provider import llm_chat

    enriched_summary = {
        "request_type": payload.request_type,
        "amount": payload.amount,
        "from_account": payload.from_account,
        "to_account": payload.to_account,
        "memo": payload.memo,
        "policy_class": payload.policy_class,
        "risk_level": payload.risk_level,
        "policy_notes": payload.policy_notes,
        "account_balances": payload.account_data,
        "transaction_ids": payload.transaction_ids,
    }
    resp = llm_chat(
        client=client,
        provider=provider,
        messages=[{"role": "user", "content": _DECIDE_PROMPT.format(payload=json.dumps(enriched_summary))}],
        system=SYSTEM_PROMPT,
        tools=[],
        model=model,
        max_tokens=512,
    )
    payload.token_usage += resp.usage
    try:
        decision = _parse_json(resp.text)
        payload.approved = decision.get("approved", False)
        payload.decision_reason = decision.get("decision_reason", "")
        payload.tool_to_call = decision.get("tool_to_call")
        payload.tool_args = decision.get("tool_args") or {}
    except (json.JSONDecodeError, TypeError):
        payload.pipeline_errors.append(f"decide parse error: {resp.text!r}")
        payload.approved = False
        payload.decision_reason = "Decision stage parse error"

    return payload


def _stage_dispatch(payload: PipelinePayload, tool_map: dict) -> PipelinePayload:
    """Stage 5: Execute the approved tool call."""
    if not payload.approved or not payload.tool_to_call:
        payload.dispatch_result = {
            "status": "not_dispatched",
            "reason": payload.decision_reason or "Not approved",
        }
        return payload

    tool_fn = tool_map.get(payload.tool_to_call)
    if tool_fn is None:
        payload.dispatch_result = {
            "status": "error",
            "reason": f"Unknown tool: {payload.tool_to_call!r}",
        }
        payload.pipeline_errors.append(f"dispatch: unknown tool {payload.tool_to_call!r}")
        return payload

    try:
        result = tool_fn(**payload.tool_args)
        payload.dispatch_result = result if isinstance(result, dict) else {"result": str(result)}
    except Exception as exc:
        payload.dispatch_result = {"status": "error", "reason": str(exc)}
        payload.pipeline_errors.append(f"dispatch error: {exc}")

    return payload


def _stage_confirm(payload: PipelinePayload, client: Any, provider: str, model: str | None) -> PipelinePayload:
    """Stage 6: Generate confirmation message."""
    from personas.common.provider import llm_chat

    resp = llm_chat(
        client=client,
        provider=provider,
        messages=[{
            "role": "user",
            "content": _CONFIRM_PROMPT.format(
                result=json.dumps(payload.dispatch_result),
                original_request=payload.original_request,
            ),
        }],
        system=SYSTEM_PROMPT,
        tools=[],
        model=model,
        max_tokens=512,
    )
    payload.token_usage += resp.usage
    payload.confirmation = resp.text or "Operation processed."
    return payload


# ---------------------------------------------------------------------------
# Agent entry point
# ---------------------------------------------------------------------------

@st.agent(name="finance-ops-streaming-pipeline", tags=["finance-ops", "streaming-pipeline", "finance", "integration-test"])
def run_agent(
    request: str,
    provider: str = "openai",
    model: str | None = None,
) -> dict:
    """Run the finance ops streaming pipeline agent.

    Args:
        request: Natural language finance operation request.
        provider: LLM provider, "openai" or "anthropic".
        model: Override the default model for this provider.

    Returns:
        Final pipeline payload as a dict. Contains confirmation, dispatch_result,
        approved, decision_reason, and pipeline_errors.
    """
    from personas.common.provider import get_llm_client
    from personas.finance_ops.tools import TOOL_MAP

    client = get_llm_client(provider)
    payload = PipelinePayload(original_request=request)

    # Execute pipeline stages in order
    payload = _stage_intake(payload, client, provider, model)
    payload = _stage_classify(payload, client, provider, model)

    if payload.proceed:
        payload = _stage_enrich(payload, client, provider, TOOL_MAP)
        payload = _stage_decide(payload, client, provider, model)
        payload = _stage_dispatch(payload, TOOL_MAP)

    payload = _stage_confirm(payload, client, provider, model)

    return {
        "confirmation": payload.confirmation,
        "approved": payload.approved,
        "decision_reason": payload.decision_reason,
        "request_type": payload.request_type,
        "policy_class": payload.policy_class,
        "risk_level": payload.risk_level,
        "dispatch_result": payload.dispatch_result,
        "pipeline_errors": payload.pipeline_errors,
        "token_usage": payload.token_usage.to_dict(),
    }

