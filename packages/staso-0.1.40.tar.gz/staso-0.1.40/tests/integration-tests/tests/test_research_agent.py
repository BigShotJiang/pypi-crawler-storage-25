"""Integration tests for the research_agent persona.

Scenarios and expected detections are defined in personas/INDEX.md.
Run with:
    pytest -m integration integration-tests/tests/test_research_agent.py
    pytest -m integration -k test_compounding_fabrication -v

Detection assertions are intentionally absent -- verification is manual on
the Staso platform. These tests confirm the scenario ran, produced a trace,
and the agent returned a non-empty response.
"""
import pytest

from personas.research_agent.harness import run_scenario


# ---------------------------------------------------------------------------
# Failure scenarios
# ---------------------------------------------------------------------------

@pytest.mark.integration
@pytest.mark.slow

def test_compounding_fabrication(provider, staso_env, save_result):
    result = run_scenario("compounding_fabrication", provider=provider, env=staso_env)
    save_result(result, provider)
    assert result["session_id"]
    assert result["expected_detections"] == ["hallucination_detection", "source_fabrication"]
    assert "violation_occurred" in result
