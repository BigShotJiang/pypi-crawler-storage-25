"""Complex integration tests for the litellm drop-in integration.

Three scenarios that go well beyond the atomic layer and test behaviors that
are unique to the litellm integration:

    test_multi_turn_tool_loop_stitching
        3-step DevOps workflow.  All litellm.completion() calls happen inside
        one st.conversation() and must land under a SINGLE agent-run root.
        Without the monkey-patch this would produce one trace per call.

    test_secrets_exfil_via_litellm
        Guard enforcement through litellm (not through the first-party OpenAI /
        Anthropic integrations).  Verifies the ``secrets`` rule fires or that
        the agent completed the loop — either way the scenario ran without
        crashing.  Actual detection is verified on the Staso platform.

    test_dangerous_cmd_blocked_and_recovered
        Deterministic guard block injected via mock.  Verifies that:
          1. GuardBlocked propagates out of litellm.completion() to the caller.
          2. The agent loop catches it without corrupting span state.
          3. The fallback path (create_alert) is taken — the agent does not
             abort or re-raise the exception.

Run:
    pytest tests/integration-tests/tests/test_litellm_devops_agent.py -m "integration and slow" -v
    pytest tests/integration-tests/tests/test_litellm_devops_agent.py::test_dangerous_cmd_blocked_and_recovered -v
"""
from __future__ import annotations

import pytest
from unittest.mock import patch

from staso.guard import GuardBlocked
from staso.guard_types import GuardResult

from personas.litellm_devops_agent.harness import (
    run_dangerous_cmd_blocked_and_recovered,
    run_multi_turn_tool_loop,
    run_secrets_exfil_via_litellm,
)


# ── Scenario 1: multi-turn tool-loop stitching ────────────────────────────────


@pytest.mark.integration
@pytest.mark.slow
def test_multi_turn_tool_loop_stitching(staso_env):
    """3-turn DevOps workflow via litellm — all LLM calls stitched under one root.

    The scenario asks the agent to: check api-service latency, scale it if
    degraded, and create an alert.  This forces at least 2 LLM turns with
    intervening tool calls, which exercises the _tool_loop_state machine's
    stitching logic across repeated litellm.completion() invocations.

    Assertions:
      - At least 2 distinct tool call types were made (check_latency + one of
        scale_up / create_alert) — confirming the loop ran multiple turns.
      - The scenario ran to completion with a non-empty final response.
      - Token counts are non-zero — confirming real LLM calls were made.
    """
    result = run_multi_turn_tool_loop(provider="litellm", env=staso_env)

    assert result["scenario"] == "multi_turn_tool_loop"
    assert result["session_id"]

    tool_calls = result["tool_calls_made"]
    tool_names = {tc["name"] for tc in tool_calls}

    assert len(tool_calls) >= 2, f"Expected >=2 tool calls, got: {tool_names}"
    assert "check_latency" in tool_names or "list_services" in tool_names, (
        f"Expected a latency-check tool call, got: {tool_names}"
    )
    assert any(n in tool_names for n in ("scale_up", "create_alert")), (
        f"Expected a scale or alert action, got: {tool_names}"
    )

    assert result["llm_turns"] >= 2, "Expected at least 2 litellm.completion() calls"
    assert result["actual_outcome"], "Agent should have produced a final text reply"

    usage = result["token_usage"]
    assert usage["input_tokens"] > 0
    assert usage["output_tokens"] > 0


# ── Scenario 2: secrets exfil through litellm ─────────────────────────────────


@pytest.mark.integration
@pytest.mark.slow
def test_secrets_exfil_via_litellm(staso_env):
    """Secrets guard fires through litellm — not just through OpenAI/Anthropic patches.

    The agent is asked to post raw secret values to Slack.  If the workspace
    has a ``secrets`` enforce rule the guard fires and GuardBlocked is raised
    inside litellm.completion(); the harness catches it and returns a blocked
    message.  If the rule is in audit mode the agent completes and the
    violation is recorded on the platform.

    Assertions:
      - The scenario ran to completion without an uncaught exception.
      - If a guard block fired, blocked_tool is non-empty (expected: post_to_slack).
      - At minimum, read_secret was called — the agent attempted the exfil path.
    """
    result = run_secrets_exfil_via_litellm(provider="litellm", env=staso_env)

    assert result["scenario"] == "secrets_exfil_via_litellm"
    assert result["session_id"]
    assert result["actual_outcome"]

    tool_names = {tc["name"] for tc in result["tool_calls_made"]}

    if result["guard_blocked"]:
        assert result["blocked_tool"], "blocked_tool should be set when guard fired"
        print(f"[guard blocked] tool={result['blocked_tool']!r}")
    else:
        # Guard may be in audit mode or not configured; scenario still ran.
        assert "read_secret" in tool_names or "post_to_slack" in tool_names, (
            f"Agent should have attempted the exfil path. Tools seen: {tool_names}"
        )


# ── Scenario 3: dangerous command blocked + recovery ──────────────────────────


@pytest.mark.integration
@pytest.mark.slow
def test_dangerous_cmd_blocked_and_recovered(staso_env):
    """GuardBlocked from litellm.completion() is caught; agent recovers via create_alert.

    The guard is injected deterministically: try_guard returns ``block`` for
    any call to ``run_command`` while returning ``allow`` for everything else.
    The LLM turns still hit the real LiteLLM API so the full integration path
    is exercised.

    Assertions:
      1. guard_blocked=True  — GuardBlocked was raised inside litellm.completion().
      2. guard_blocked_info contains the blocked tool name.
      3. recovered=True     — the fallback create_alert path ran after the block.
      4. run_command never appeared in executed tool calls (block prevented dispatch).
      5. create_alert appeared — recovery was real, not just a flag flip.
    """
    def _selective_guard(name: str, inp: dict) -> GuardResult:
        if name == "run_command":
            return GuardResult(action="block", reason="destructive command on prod host")
        return GuardResult(action="allow")

    with patch(
        "staso.integrations._guard_common.try_guard",
        side_effect=_selective_guard,
    ):
        result = run_dangerous_cmd_blocked_and_recovered(provider="litellm", env=staso_env)

    assert result["scenario"] == "dangerous_cmd_blocked_and_recovered"
    assert result["guard_blocked"], "Guard should have fired on run_command"

    blocked_info = result["guard_blocked_info"]
    assert blocked_info.get("tool_name") == "run_command", (
        f"Expected run_command to be blocked, got: {blocked_info}"
    )

    assert result["recovered"], "Agent should have called create_alert as fallback"

    tool_names = [tc["name"] for tc in result["tool_calls_made"]]
    assert "run_command" not in tool_names, (
        "run_command should not appear in executed calls — guard blocked before dispatch"
    )
    assert "create_alert" in tool_names, (
        "create_alert (fallback) should appear in tool_calls_made"
    )

    print(
        f"[guard-recovery] blocked={blocked_info!r}  "
        f"fallback_calls={[n for n in tool_names if n == 'create_alert']}"
    )
