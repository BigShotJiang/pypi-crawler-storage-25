"""Integration tests for the orchestrator persona.

Scenarios and expected detections are defined in personas/INDEX.md.
Run with:
    pytest -m integration integration-tests/tests/test_orchestrator.py
    pytest -m integration -k test_silent_partial_failure -v

Detection assertions are intentionally absent -- verification is manual on
the Staso platform. These tests confirm the scenario ran, produced a trace,
and the agent returned a non-empty response.
"""
import pytest

from personas.orchestrator.harness import run_scenario


# ---------------------------------------------------------------------------
# Failure scenarios
# ---------------------------------------------------------------------------

@pytest.mark.integration
@pytest.mark.slow

def test_silent_partial_failure(provider, staso_env, save_result):
    result = run_scenario("silent_partial_failure", provider=provider, env=staso_env)
    save_result(result, provider)
    assert result["session_id"]
    assert result["expected_detections"] == ["incomplete_task_execution"]
    assert "violation_occurred" in result
