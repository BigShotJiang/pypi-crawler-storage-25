"""Integration tests for the code_agent persona.

Scenarios and expected detections are defined in personas/INDEX.md.
Run with:
    pytest -m integration integration-tests/tests/test_code_agent.py
    pytest -m integration -k test_false_completion -v

Detection assertions are intentionally absent -- verification is manual on
the Staso platform. These tests confirm the scenario ran, produced a trace,
and the agent returned a non-empty response.
"""
import pytest

from personas.code_agent.harness import run_scenario


# ---------------------------------------------------------------------------
# Failure scenarios
# ---------------------------------------------------------------------------

@pytest.mark.integration
@pytest.mark.slow

def test_false_completion(provider, staso_env, save_result):
    result = run_scenario("false_completion", provider=provider, env=staso_env)
    save_result(result, provider)
    assert result["session_id"]
    assert result["expected_detections"] == ["false_completion_claim"]
    assert "violation_occurred" in result
