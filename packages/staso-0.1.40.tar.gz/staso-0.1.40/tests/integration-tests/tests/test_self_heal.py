"""Integration tests for the self-heal feature.

Two test functions at different depths:

  test_self_heal_regression (self_heal, integration)
    Verifies that good and bad commit traces were ingested into the platform
    with the correct VCS tags. This is a pre-condition check -- it does NOT
    assert that regression detection fired.

  test_self_heal_full_pipeline (self_heal, integration, slow)
    End-to-end: injects a RegressionEvent via the backend API using the SHAs
    from the ingested traces, waits for the worker to run evidence collection
    + diagnosis + dispatch, and asserts on the diagnosis quality.
    Requires: STASO_ORG_ID env var and a reachable STASO_BASE_URL.

Run:
    pytest -m self_heal tests/integration-tests/
    pytest -m "self_heal and not slow" tests/integration-tests/   # ingestion only
    pytest -m "self_heal and slow" tests/integration-tests/       # full pipeline only
"""
from __future__ import annotations

import json
import os

import pytest


# ---------------------------------------------------------------------------
# test_self_heal_regression
# ---------------------------------------------------------------------------

@pytest.mark.integration
@pytest.mark.self_heal
def test_self_heal_regression(self_heal_run, save_result):
    """Assert that good and bad commit traces were successfully ingested.

    good_results / bad_results are lists of scenario result dicts from real LLM
    persona runs. Count = n_traces * 3 scenarios (minus any skipped failures).
    """
    good_results, bad_results, meta = self_heal_run

    # When the fixture uses cached SHAs, results lists are empty (traces already in CH).
    # Use the cached n_traces count as the fallback so assertions still hold.
    good_count = len(good_results) if good_results else meta.get("n_traces", 0)
    bad_count = len(bad_results) if bad_results else meta.get("n_traces", 0)

    assert good_count > 0, "No good commit traces were generated (and no cached count)"
    assert bad_count > 0, "No bad commit traces were generated (and no cached count)"
    assert meta["good_sha"] != meta["bad_sha"]

    result = {
        "scenario": "self_heal_regression",
        "good_commit_sha": meta["good_sha"],
        "bad_commit_sha": meta["bad_sha"],
        "agent_name": meta["agent_name"],
        "good_trace_count": good_count,
        "bad_trace_count": bad_count,
        "good_error_rate": meta["good_error_rate"],
        "bad_error_rate": meta["bad_error_rate"],
        "expected_detections": ["regression_detected"],
        "actual_outcome": (
            f"Ingested {len(good_results)} good + {len(bad_results)} bad traces. "
            f"Trigger detection via POST /internal/self-heal/inject with "
            f"org_id, agent_name={meta['agent_name']!r}, "
            f"good_commit_sha={meta['good_sha']!r}, bad_commit_sha={meta['bad_sha']!r}"
        ),
    }

    save_result(result, "self_heal")

    print(f"\n--- self-heal trace ingestion complete ---")
    print(f"  good_sha:  {meta['good_sha']}")
    print(f"  bad_sha:   {meta['bad_sha']}")
    print(f"  agent:     {meta['agent_name']}")
    print(f"  To trigger: POST /internal/self-heal/inject")
    print(json.dumps({
        "org_id": "<your-org-uuid>",
        "agent_name": meta["agent_name"],
        "good_commit_sha": meta["good_sha"],
        "bad_commit_sha": meta["bad_sha"],
    }, indent=4))


# ---------------------------------------------------------------------------
# test_self_heal_full_pipeline
# ---------------------------------------------------------------------------

@pytest.mark.integration
@pytest.mark.self_heal
@pytest.mark.slow
def test_self_heal_full_pipeline(self_heal_run, save_result, request):
    """End-to-end self-heal pipeline test.

    Flow:
      1. Use SHAs from self_heal_run (traces already in CH after flush wait).
      2. Inject RegressionEvent via /internal/self-heal/inject.
      3. Poll /internal/self-heal/results until the worker produces a diagnosis.
      4. Assert diagnosis quality: known root cause, confidence >= 0.5.

    Skips if STASO_ORG_ID is not set or backend is not reachable.
    """
    from self_heal.pipeline_client import SelfHealPipelineClient

    good_results, bad_results, meta = self_heal_run

    org_id = os.environ.get("STASO_ORG_ID", "")
    workspace_id = os.environ.get("STASO_WORKSPACE_ID", "")
    environment = os.environ.get("STASO_ENVIRONMENT", os.environ.get("STASO_ENV", "staging"))
    base_url = os.environ.get("STASO_BASE_URL", "https://api.staso.ai")
    pipeline_timeout = request.config.getoption("--self-heal-pipeline-timeout")

    if not org_id:
        pytest.skip("STASO_ORG_ID not set -- skipping full pipeline test")
    if not workspace_id:
        pytest.skip("STASO_WORKSPACE_ID not set -- skipping full pipeline test")

    client = SelfHealPipelineClient(
        base_url=base_url,
        org_id=org_id,
        workspace_id=workspace_id,
        environment=environment,
        agent_name=meta["agent_name"],
    )

    if not client.reachable():
        pytest.skip(f"Backend not reachable at {base_url} -- skipping full pipeline test")

    # Step 1: Inject the regression event with real SHAs from the fixture
    print(f"\n[e2e] Injecting regression event: good={meta['good_sha'][:12]} bad={meta['bad_sha'][:12]}")
    inject_resp = client.inject(
        good_sha=meta["good_sha"],
        bad_sha=meta["bad_sha"],
        bad_error_rate=meta["bad_error_rate"],
        good_error_rate=meta["good_error_rate"],
    )
    assert inject_resp.get("status") == "injected", f"Inject failed: {inject_resp}"
    print(f"[e2e] Event injected into stream: {inject_resp.get('stream')}")

    # Step 2: Poll for the worker to process and produce a diagnosis
    print(f"[e2e] Polling for diagnosis (timeout={pipeline_timeout}s)...")
    diagnosis = client.poll_result(
        bad_sha=meta["bad_sha"],
        timeout=pipeline_timeout,
        interval=10,
    )

    assert diagnosis is not None, (
        f"Self-heal pipeline did not produce a diagnosis within {pipeline_timeout}s. "
        f"Check backend logs for: evidence collection -> diagnosis -> dispatch. "
        f"bad_sha={meta['bad_sha']}"
    )

    # Step 3: Assert diagnosis quality
    root_cause = diagnosis.get("root_cause", "unknown")
    confidence = diagnosis.get("confidence", 0.0)
    explanation = diagnosis.get("explanation", "")

    assert root_cause != "unknown", (
        f"Expected a specific root cause classification, got 'unknown'. "
        f"Full diagnosis: {diagnosis}"
    )
    assert confidence >= 0.5, (
        f"Diagnosis confidence too low ({confidence:.2f}). "
        f"Root cause: {root_cause}. Explanation: {explanation[:200]}"
    )
    assert len(explanation) > 20, (
        f"Explanation too short ({len(explanation)} chars): {explanation!r}"
    )

    print(f"[e2e] Diagnosis: root_cause={root_cause} confidence={confidence:.0%}")
    print(f"[e2e] Explanation: {explanation[:300]}")

    result = {
        "scenario": "self_heal_full_pipeline",
        "good_commit_sha": meta["good_sha"],
        "bad_commit_sha": meta["bad_sha"],
        "agent_name": meta["agent_name"],
        "root_cause": root_cause,
        "confidence": confidence,
        "explanation": explanation,
        "suggested_fix": diagnosis.get("suggested_fix"),
        "thresholds_breached": diagnosis.get("thresholds_breached", []),
        "dispatched": diagnosis.get("dispatched"),
        "processed_at": diagnosis.get("processed_at"),
        "actual_outcome": f"Regression detected: {root_cause} ({confidence:.0%} confidence)",
        "expected_detections": ["regression_detected"],
    }

    save_result(result, "self_heal_pipeline")
    print(f"\n--- self-heal full pipeline PASSED ---")
    print(f"  root_cause: {root_cause}")
    print(f"  confidence: {confidence:.0%}")
    print(f"  processed:  {diagnosis.get('processed_at', 'unknown')}")
