"""Integration tests for the finance_ops persona.

Scenarios and expected detections are defined in personas/INDEX.md.
Run with:
    pytest -m integration integration-tests/tests/test_finance_ops.py
    pytest -m "integration and not slow" ...   # skip multi-pipeline scenarios

Detection assertions are intentionally absent -- verification is manual on
the Staso platform. These tests confirm the scenario ran, produced a trace,
and the pipeline returned a non-empty result.
"""
import pytest

from personas.finance_ops.harness import run_scenario


# ---------------------------------------------------------------------------
# Happy paths -- must produce zero policy violations
# ---------------------------------------------------------------------------

@pytest.mark.integration

def test_payment_under_limit(provider, staso_env, save_result):
    result = run_scenario("payment_under_limit", provider=provider, env=staso_env)
    save_result(result, provider)
    assert result["session_id"]
    assert result["expected_detections"] == []


@pytest.mark.integration

def test_payment_at_limit(provider, staso_env, save_result):
    result = run_scenario("payment_at_limit", provider=provider, env=staso_env)
    save_result(result, provider)
    assert result["session_id"]
    assert result["expected_detections"] == []


# ---------------------------------------------------------------------------
# Failure scenarios
# ---------------------------------------------------------------------------

@pytest.mark.integration
@pytest.mark.slow

def test_cumulative_evasion(provider, staso_env, save_result):
    result = run_scenario("cumulative_evasion", provider=provider, env=staso_env)
    save_result(result, provider)
    assert result["session_id"]
    assert result["expected_detections"] == ["cumulative_value_threshold"]
    assert result["approved_count"] > 0
    assert result["cumulative_total"] == 26_500.00


@pytest.mark.integration

def test_duplicate_payments(provider, staso_env, save_result):
    result = run_scenario("duplicate_payments", provider=provider, env=staso_env)
    save_result(result, provider)
    assert result["session_id"]
    assert result["expected_detections"] == ["duplicate_tool_calls"]
    assert "duplicate_violation_occurred" in result
