"""Integration tests for the customer_support persona.

Scenarios and expected detections are defined in personas/INDEX.md.
Run with:
    pytest -m integration integration-tests/tests/test_customer_support.py
    pytest -m "integration and not slow" ...   # skip multi-turn scenarios

Detection assertions are intentionally absent -- verification is manual on
the Staso platform. These tests confirm the scenario ran, produced a trace,
and the agent returned a non-empty response.
"""
import pytest

from personas.customer_support.harness import run_scenario


# ---------------------------------------------------------------------------
# Happy paths -- must produce zero policy violations
# ---------------------------------------------------------------------------

@pytest.mark.integration

def test_billing_inquiry(provider, staso_env, save_result):
    result = run_scenario("billing_inquiry", provider=provider, env=staso_env)
    save_result(result, provider)
    assert result["session_id"]
    assert result["actual_outcome"]
    assert result["expected_detections"] == []


@pytest.mark.integration
@pytest.mark.slow

def test_multi_turn_context(provider, staso_env, save_result):
    result = run_scenario("multi_turn_context", provider=provider, env=staso_env)
    save_result(result, provider)
    assert result["session_id"]
    assert result["turns_completed"] == 5
    assert result["expected_detections"] == []


@pytest.mark.integration

def test_refund_at_limit(provider, staso_env, save_result):
    result = run_scenario("refund_at_limit", provider=provider, env=staso_env)
    save_result(result, provider)
    assert result["session_id"]
    assert result["actual_outcome"]
    assert result["expected_detections"] == []


# ---------------------------------------------------------------------------
# Failure scenarios -- agent may or may not misbehave (LLM-dependent).
# Tests confirm the scenario ran and produced a trace. Violation detection
# is verified manually on the Staso platform.
# ---------------------------------------------------------------------------

@pytest.mark.integration
@pytest.mark.slow

def test_incremental_boundary_push(provider, staso_env, save_result):
    result = run_scenario("incremental_boundary_push", provider=provider, env=staso_env)
    save_result(result, provider)
    assert result["session_id"]
    assert result["expected_detections"] == ["instruction_adherence", "goal_deviation"]
    assert "violation_occurred" in result


@pytest.mark.integration
@pytest.mark.slow

def test_amnesia(provider, staso_env, save_result):
    result = run_scenario("amnesia", provider=provider, env=staso_env)
    save_result(result, provider)
    assert result["session_id"]
    assert result["expected_detections"] == ["context_loss", "instruction_adherence"]
    assert "violation_occurred" in result
