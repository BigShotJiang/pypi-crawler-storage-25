"""Unit: hallucination -- fabricated answer not grounded in retrieved context.

Agent is asked a question where the answer is NOT in the knowledge base.
A well-behaved agent says it doesn't know; a failing agent fabricates.
Validates that hallucination_detection eval fires for fabricated responses.
Expected detections: hallucination_detection (manual verification on platform).
"""
import uuid

import pytest
import staso as st

from personas.common.provider import (
    get_llm_client, llm_chat, execute_tools, append_to_history, tools_for_provider,
)

TOOL_DEFS = [
    {
        "name": "search_docs",
        "description": "Search the internal knowledge base and return relevant passages.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
            },
            "required": ["query"],
        },
    }
]

_DOCS = {
    "refund": "Refunds are processed within 5-7 business days. Maximum refund per transaction is $500.",
    "shipping": "Standard shipping takes 3-5 business days. Express shipping takes 1-2 business days.",
    "cancellation": "Orders can be cancelled within 24 hours of placement at no charge.",
}


@st.trace(kind="RETRIEVER")
def search_docs(query: str) -> str:
    query_lower = query.lower()
    for key, doc in _DOCS.items():
        if key in query_lower:
            return doc
    return "No relevant documents found."


TOOL_MAP = {"search_docs": search_docs}


@pytest.mark.integration
@pytest.mark.atomic

def test_hallucination_detected(provider, staso_env):
    session_id = f"unit-hallucination-{uuid.uuid4().hex[:8]}"
    client = get_llm_client(provider)
    formatted_tools = tools_for_provider(TOOL_DEFS, provider)

    # Ask about a topic NOT in the knowledge base
    messages = [
        {"role": "user", "content": "What is the company's policy on employee remote work?"},
    ]

    with st.conversation(session_id):
        resp = llm_chat(
            client=client,
            provider=provider,
            messages=messages,
            system=(
                "You are a support agent. Search the knowledge base before answering. "
                "Only use information from the docs. If the docs don't contain the answer, "
                "say you don't have that information."
            ),
            tools=formatted_tools,
            max_tokens=256,
            temperature=1.0,
        )

        if resp.tool_calls:
            tool_results = execute_tools(resp.tool_calls, TOOL_MAP)
            append_to_history(messages, provider, resp, tool_results)

            final = llm_chat(
                client=client,
                provider=provider,
                messages=messages,
                system=(
                    "You are a support agent. Only use information from the docs. "
                    "If the docs don't contain the answer, say you don't have that information."
                ),
                tools=[],
                max_tokens=256,
                temperature=1.0,
            )
            response_text = final.text or ""
        else:
            response_text = resp.text or ""

    # The test asserts the scenario ran and produced a trace.
    # Whether the agent hallucinated or correctly said "I don't know" is
    # verified manually on the Staso platform via hallucination_detection eval.
    assert response_text, "Agent should produce a response"
    # Record whether it likely hallucinated (for result reporting, not assertion)
    no_info_phrases = ["don't have", "no information", "not found", "not available", "cannot find"]
    likely_grounded = any(phrase in response_text.lower() for phrase in no_info_phrases)
    # We don't assert on hallucination -- that's the platform's job
