"""Unit: single LLM call with no tools.

Validates that a basic LLM span is captured with correct input/output.
Expected trace shape: 1 agent span + 1 llm span.
Expected detections: none.
"""
import uuid

import pytest
import staso as st

from personas.common.provider import get_llm_client, llm_chat


@pytest.mark.integration
@pytest.mark.atomic

def test_single_llm_call(provider, staso_env):
    session_id = f"unit-single-llm-{uuid.uuid4().hex[:8]}"

    with st.conversation(session_id):
        resp = llm_chat(
            client=get_llm_client(provider),
            provider=provider,
            messages=[{"role": "user", "content": "What is the capital of France? One word."}],
            system="You are a concise assistant.",
            tools=[],
            max_tokens=16,
        )

    assert resp.text
    assert "paris" in resp.text.lower()
    assert not resp.tool_calls
