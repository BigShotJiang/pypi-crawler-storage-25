"""Unit: tool error followed by successful retry.

Validates that an error span is emitted on the first call and the agent
retries successfully. Uses a stateful tool that fails once then succeeds.

Expected trace shape: 1 llm span + 1 error tool span + 1 llm span + 1 ok tool span.
Expected detections: none (error was handled correctly).
"""
import uuid

import pytest
import staso as st

from personas.common.provider import (
    get_llm_client, llm_chat, execute_tools, append_to_history, tools_for_provider,
)

TOOL_DEFS = [
    {
        "name": "fetch_order_status",
        "description": "Fetch the status of an order by order ID. May fail transiently -- retry on error.",
        "parameters": {
            "type": "object",
            "properties": {
                "order_id": {"type": "string"},
            },
            "required": ["order_id"],
        },
    }
]


def _make_flaky_tool():
    call_count = {"n": 0}

    def fetch_order_status(order_id: str) -> dict:
        call_count["n"] += 1
        if call_count["n"] == 1:
            raise RuntimeError("Upstream service unavailable. Please retry.")
        return {"order_id": order_id, "status": "shipped", "eta": "2 business days"}

    return fetch_order_status


@pytest.mark.integration
@pytest.mark.atomic

def test_error_then_retry_succeeds(provider, staso_env):
    session_id = f"unit-error-retry-{uuid.uuid4().hex[:8]}"
    client = get_llm_client(provider)
    formatted_tools = tools_for_provider(TOOL_DEFS, provider)
    tool_map = {"fetch_order_status": _make_flaky_tool()}
    messages = [{"role": "user", "content": "What is the status of order ORD-999?"}]

    tool_call_count = 0

    with st.conversation(session_id):
        for _ in range(6):  # enough iterations for error + retry
            resp = llm_chat(
                client=client,
                provider=provider,
                messages=messages,
                system="If a tool returns an error, retry the call once.",
                tools=formatted_tools,
                max_tokens=256,
            )
            if not resp.tool_calls:
                final_text = resp.text
                break
            tool_call_count += len(resp.tool_calls)
            tool_results = execute_tools(resp.tool_calls, tool_map)
            append_to_history(messages, provider, resp, tool_results)
            # Once at least one tool call succeeded, force a text summary
            if any(not tr["is_error"] for tr in tool_results):
                final_resp = llm_chat(
                    client=client,
                    provider=provider,
                    messages=messages,
                    system="If a tool returns an error, retry the call once.",
                    tools=[],
                    max_tokens=256,
                )
                final_text = final_resp.text
                break
        else:
            final_text = None

    assert final_text, "Agent should produce a final response after retry"
    assert tool_call_count >= 2, "Tool should have been called at least twice (error + retry)"
