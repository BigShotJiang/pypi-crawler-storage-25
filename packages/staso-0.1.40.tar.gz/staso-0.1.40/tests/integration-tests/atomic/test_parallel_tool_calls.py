"""Unit: parallel tool calls in a single LLM response.

Validates that concurrent tool spans are captured and rendered correctly.
The LLM is asked a question requiring two tool calls in a single response.
Expected trace shape: 1 llm span + 2 parallel tool spans + 1 llm span.
Expected detections: none.
"""
import uuid

import pytest
import staso as st

from personas.common.provider import (
    get_llm_client, llm_chat, execute_tools, append_to_history, tools_for_provider,
)

TOOL_DEFS = [
    {
        "name": "get_weather",
        "description": "Get the current weather for a city.",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name"},
            },
            "required": ["city"],
        },
    },
    {
        "name": "get_time",
        "description": "Get the current local time for a city.",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name"},
            },
            "required": ["city"],
        },
    },
]


@st.tool
def get_weather(city: str) -> dict:
    return {"city": city, "temperature_c": 22, "condition": "sunny"}


@st.tool
def get_time(city: str) -> dict:
    return {"city": city, "local_time": "14:30", "timezone": "CET"}


TOOL_MAP = {"get_weather": get_weather, "get_time": get_time}


@pytest.mark.integration
@pytest.mark.atomic

def test_parallel_tool_calls(provider, staso_env):
    session_id = f"unit-parallel-tools-{uuid.uuid4().hex[:8]}"
    client = get_llm_client(provider)
    formatted_tools = tools_for_provider(TOOL_DEFS, provider)
    messages = [
        {"role": "user", "content": "What is the weather AND the current time in Paris? Use both tools."},
    ]

    with st.conversation(session_id):
        resp = llm_chat(
            client=client,
            provider=provider,
            messages=messages,
            system="You have two tools available. When asked about weather AND time, call both tools in the same response.",
            tools=formatted_tools,
            max_tokens=256,
        )
        assert resp.tool_calls, "LLM should have made tool calls"
        # We expect 2 parallel tool calls but some providers may serialize them.
        # Assert at least 1 to be safe, but the typical case is 2.
        tool_names = {tc.name for tc in resp.tool_calls}
        assert len(resp.tool_calls) >= 1, "Expected at least 1 tool call"

        tool_results = execute_tools(resp.tool_calls, TOOL_MAP)
        append_to_history(messages, provider, resp, tool_results)

        final = llm_chat(
            client=client,
            provider=provider,
            messages=messages,
            system="Summarize the results.",
            tools=[],
            max_tokens=256,
        )

    assert final.text
    assert not final.tool_calls
