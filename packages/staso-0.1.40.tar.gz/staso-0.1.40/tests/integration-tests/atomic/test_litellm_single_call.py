"""Integration: LiteLLM drop-in single LLM call and tool-use loop.

Validates that patch_litellm() captures spans with correct input/output and
that a multi-turn tool loop is stitched under a single agent-run root rather
than emitting a separate trace per call.

Run with:
    pytest tests/integration-tests/atomic/test_litellm_single_call.py -m atomic
"""
from __future__ import annotations

import uuid

import pytest
import staso as st

from personas.common.provider import (
    append_to_history,
    execute_tools,
    get_llm_client,
    llm_chat,
    tools_for_provider,
)

PROVIDER = "litellm"


TOOL_DEFS = [
    {
        "name": "get_weather",
        "description": "Return the current weather for a city.",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name"},
            },
            "required": ["city"],
        },
    }
]


@st.tool
def get_weather(city: str) -> dict:
    return {"city": city, "temperature_c": 22, "condition": "sunny"}


TOOL_MAP = {"get_weather": get_weather}


@pytest.mark.integration
@pytest.mark.atomic
def test_litellm_single_call(staso_env):
    """Single LLM call through litellm produces a valid text response."""
    session_id = f"litellm-single-{uuid.uuid4().hex[:8]}"
    client = get_llm_client(PROVIDER)

    with st.conversation(session_id):
        resp = llm_chat(
            client=client,
            provider=PROVIDER,
            messages=[{"role": "user", "content": "What is the capital of Japan? One word."}],
            system="You are a concise assistant.",
            tools=[],
            max_tokens=16,
        )

    assert resp.text
    assert "tokyo" in resp.text.lower()
    assert not resp.tool_calls


@pytest.mark.integration
@pytest.mark.atomic
def test_litellm_tool_use(staso_env):
    """LiteLLM tool-use loop: LLM calls get_weather, receives result, produces reply."""
    session_id = f"litellm-tool-{uuid.uuid4().hex[:8]}"
    client = get_llm_client(PROVIDER)
    formatted_tools = tools_for_provider(TOOL_DEFS, PROVIDER)
    messages = [{"role": "user", "content": "What is the weather in London right now?"}]

    with st.conversation(session_id):
        resp = llm_chat(
            client=client,
            provider=PROVIDER,
            messages=messages,
            system="Use the available tools to answer.",
            tools=formatted_tools,
            max_tokens=256,
        )
        assert resp.tool_calls, "LLM should call get_weather"
        assert resp.tool_calls[0].name == "get_weather"
        assert resp.tool_calls[0].arguments.get("city")

        tool_results = execute_tools(resp.tool_calls, TOOL_MAP)
        append_to_history(messages, PROVIDER, resp, tool_results)

        final = llm_chat(
            client=client,
            provider=PROVIDER,
            messages=messages,
            system="Use the available tools to answer.",
            tools=[],
            max_tokens=256,
        )

    assert final.text
    assert not final.tool_calls


@pytest.mark.integration
@pytest.mark.atomic
def test_litellm_multi_turn_context_retained(staso_env):
    """Multi-turn litellm conversation retains context across turns."""
    session_id = f"litellm-multi-{uuid.uuid4().hex[:8]}"
    client = get_llm_client(PROVIDER)
    messages = []

    turns = [
        "My name is Alex.",
        "I work as a software engineer.",
        "What is my name and job?",
    ]

    responses = []
    with st.conversation(session_id):
        for turn in turns:
            messages.append({"role": "user", "content": turn})
            resp = llm_chat(
                client=client,
                provider=PROVIDER,
                messages=messages,
                system="You are a helpful assistant. Remember everything the user tells you.",
                tools=[],
                max_tokens=128,
            )
            messages.append({"role": "assistant", "content": resp.text or ""})
            responses.append(resp.text or "")

    final = responses[-1].lower()
    assert "alex" in final
    assert "engineer" in final
