"""Unit: RAG pipeline -- retrieval + grounded generation.

Validates that a retriever span is captured and the LLM grounds its answer
in the retrieved content rather than hallucinating.

Expected trace shape: 1 retriever span + 1 llm span.
Expected detections: none (happy path -- grounded answer).
"""
import uuid

import pytest
import staso as st

from personas.common.provider import (
    get_llm_client, llm_chat, execute_tools, append_to_history, tools_for_provider,
)

TOOL_DEFS = [
    {
        "name": "search_docs",
        "description": "Search the internal knowledge base and return relevant passages.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
            },
            "required": ["query"],
        },
    }
]

_DOCS = {
    "refund": "Refunds are processed within 5-7 business days. Maximum refund per transaction is $500.",
    "shipping": "Standard shipping takes 3-5 business days. Express shipping takes 1-2 business days.",
    "cancellation": "Orders can be cancelled within 24 hours of placement at no charge.",
}


@st.trace(kind="RETRIEVER")
def search_docs(query: str) -> str:
    query_lower = query.lower()
    for key, doc in _DOCS.items():
        if key in query_lower:
            return doc
    return "No relevant documents found."


TOOL_MAP = {"search_docs": search_docs}


@pytest.mark.integration
@pytest.mark.atomic

def test_rag_grounded_answer(provider, staso_env):
    session_id = f"unit-rag-{uuid.uuid4().hex[:8]}"
    client = get_llm_client(provider)
    formatted_tools = tools_for_provider(TOOL_DEFS, provider)
    messages = [{"role": "user", "content": "How long does a refund take?"}]

    with st.conversation(session_id):
        resp = llm_chat(
            client=client,
            provider=provider,
            messages=messages,
            system="Search the knowledge base before answering. Only use information from the docs.",
            tools=formatted_tools,
            max_tokens=256,
        )
        assert resp.tool_calls, "LLM should retrieve docs before answering"
        assert resp.tool_calls[0].name == "search_docs"

        tool_results = execute_tools(resp.tool_calls, TOOL_MAP)
        append_to_history(messages, provider, resp, tool_results)

        final = llm_chat(
            client=client,
            provider=provider,
            messages=messages,
            system="Search the knowledge base before answering. Only use information from the docs.",
            tools=formatted_tools,
            max_tokens=256,
        )

    assert final.text
    # Answer must reference the retrieved content, not hallucinate
    assert any(phrase in final.text.lower() for phrase in ["5", "7", "business day"])
