"""Unit: multi-agent delegation -- parent spawns a sub-agent.

Validates that nested agent spans are captured with correct parent-child
hierarchy. Parent agent delegates a sub-task to a specialised sub-agent
decorated with @st.agent.
Expected trace shape: parent agent span > sub-agent span > tool spans.
Expected detections: none.
"""
import uuid

import pytest
import staso as st

from personas.common.provider import (
    get_llm_client, llm_chat, execute_tools, append_to_history, tools_for_provider,
)

TOOL_DEFS = [
    {
        "name": "lookup_price",
        "description": "Look up the current price of a product by name.",
        "parameters": {
            "type": "object",
            "properties": {
                "product": {"type": "string", "description": "Product name"},
            },
            "required": ["product"],
        },
    },
]


@st.tool
def lookup_price(product: str) -> dict:
    prices = {"laptop": 999.99, "keyboard": 79.99, "monitor": 349.99}
    price = prices.get(product.lower(), 0.0)
    return {"product": product, "price_usd": price, "in_stock": price > 0}


TOOL_MAP = {"lookup_price": lookup_price}


@st.agent(name="pricing-sub-agent", tags=["sub-agent", "pricing"])
def pricing_sub_agent(product: str, provider: str, client, formatted_tools) -> str:
    """Sub-agent that looks up a product price and returns a summary."""
    messages = [{"role": "user", "content": f"What is the price of a {product}?"}]

    resp = llm_chat(
        client=client,
        provider=provider,
        messages=messages,
        system="Use the lookup_price tool to answer.",
        tools=formatted_tools,
        max_tokens=256,
    )
    if resp.tool_calls:
        tool_results = execute_tools(resp.tool_calls, TOOL_MAP)
        append_to_history(messages, provider, resp, tool_results)
        final = llm_chat(
            client=client,
            provider=provider,
            messages=messages,
            system="Summarize the price lookup result.",
            tools=[],
            max_tokens=256,
        )
        return final.text or "No price found."
    return resp.text or "No response."


@pytest.mark.integration
@pytest.mark.atomic

def test_multi_agent_delegation(provider, staso_env):
    session_id = f"unit-multi-agent-{uuid.uuid4().hex[:8]}"
    client = get_llm_client(provider)
    formatted_tools = tools_for_provider(TOOL_DEFS, provider)

    with st.conversation(session_id):
        # Parent agent delegates to pricing sub-agent
        result = pricing_sub_agent(
            product="laptop",
            provider=provider,
            client=client,
            formatted_tools=formatted_tools,
        )

    assert result
    assert isinstance(result, str)
