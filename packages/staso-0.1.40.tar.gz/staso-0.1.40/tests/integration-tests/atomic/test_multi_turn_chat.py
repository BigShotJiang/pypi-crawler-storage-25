"""Unit: multi-turn conversation session grouping.

3 turns in the same st.conversation(). The agent must carry context from
turn 1 into turn 3 (name introduced at turn 1 recalled at turn 3).
Validates session linking via session_id.

Expected trace shape: 3 llm spans linked under one session.
Expected detections: none.
"""
import uuid

import pytest
import staso as st

from personas.common.provider import get_llm_client, llm_chat

SYSTEM = "You are a helpful assistant. Remember everything the user tells you in this conversation."


@pytest.mark.integration
@pytest.mark.atomic

def test_multi_turn_context_retained(provider, staso_env):
    session_id = f"unit-multi-turn-{uuid.uuid4().hex[:8]}"
    client = get_llm_client(provider)
    messages = []

    turns = [
        "My name is Alex.",
        "I work as a software engineer.",
        "What is my name and job?",
    ]

    responses = []
    with st.conversation(session_id):
        for turn in turns:
            messages.append({"role": "user", "content": turn})
            resp = llm_chat(
                client=client,
                provider=provider,
                messages=messages,
                system=SYSTEM,
                tools=[],
                max_tokens=128,
            )
            messages.append({"role": "assistant", "content": resp.text or ""})
            responses.append(resp.text or "")

    assert len(responses) == 3
    final = responses[-1].lower()
    assert "alex" in final, "Agent should recall the name from turn 1"
    assert "engineer" in final, "Agent should recall the job from turn 2"
