"""Unit: cascading failure -- error propagates across a multi-step chain.

A 3-step pipeline where step 1 fails. Steps 2 and 3 receive the error
result and must handle or propagate it. Validates that error propagation
is captured in the trace tree and that the agent surfaces the root cause.
Expected trace shape: 3 tool spans (1 error + 2 downstream).
Expected detections: agent_behavior_monitoring (manual verification on platform).
"""
import uuid

import pytest
import staso as st

from personas.common.provider import (
    get_llm_client, llm_chat, execute_tools, append_to_history, tools_for_provider,
)

TOOL_DEFS = [
    {
        "name": "fetch_user_profile",
        "description": "Step 1: Fetch a user profile by user ID. May fail if the user service is down.",
        "parameters": {
            "type": "object",
            "properties": {
                "user_id": {"type": "string"},
            },
            "required": ["user_id"],
        },
    },
    {
        "name": "enrich_profile",
        "description": "Step 2: Enrich a user profile with additional data. Requires valid profile from step 1.",
        "parameters": {
            "type": "object",
            "properties": {
                "profile_data": {"type": "string", "description": "JSON profile data from fetch_user_profile"},
            },
            "required": ["profile_data"],
        },
    },
    {
        "name": "generate_report",
        "description": "Step 3: Generate a report from enriched profile. Requires valid enriched data from step 2.",
        "parameters": {
            "type": "object",
            "properties": {
                "enriched_data": {"type": "string", "description": "JSON enriched data from enrich_profile"},
            },
            "required": ["enriched_data"],
        },
    },
]


@st.tool
def fetch_user_profile(user_id: str) -> dict:
    # Step 1 always fails to trigger the cascade
    raise RuntimeError("User service unavailable: connection timeout after 5000ms")


@st.tool
def enrich_profile(profile_data: str) -> dict:
    if "error" in profile_data.lower() or "unavailable" in profile_data.lower():
        return {"status": "error", "reason": "Cannot enrich: upstream profile fetch failed"}
    return {"enriched": True, "profile": profile_data, "extra": {"loyalty_tier": "gold"}}


@st.tool
def generate_report(enriched_data: str) -> dict:
    if "error" in enriched_data.lower():
        return {"status": "error", "reason": "Cannot generate report: upstream enrichment failed"}
    return {"report": f"User report generated from: {enriched_data[:50]}"}


TOOL_MAP = {
    "fetch_user_profile": fetch_user_profile,
    "enrich_profile": enrich_profile,
    "generate_report": generate_report,
}


@pytest.mark.integration
@pytest.mark.atomic

def test_cascading_failure(provider, staso_env):
    session_id = f"unit-cascade-{uuid.uuid4().hex[:8]}"
    client = get_llm_client(provider)
    formatted_tools = tools_for_provider(TOOL_DEFS, provider)
    messages = [
        {
            "role": "user",
            "content": (
                "Generate a full user report for user ID 'USR-404'. "
                "You need to: 1) fetch the user profile, 2) enrich it, 3) generate the report. "
                "Execute all three steps in order."
            ),
        },
    ]

    tool_calls_made = []
    error_results = []

    with st.conversation(session_id):
        for _ in range(8):
            resp = llm_chat(
                client=client,
                provider=provider,
                messages=messages,
                system=(
                    "Execute the three pipeline steps in order. "
                    "If a step fails, you may still attempt subsequent steps but pass the error forward. "
                    "Report the final outcome including any errors."
                ),
                tools=formatted_tools,
                max_tokens=512,
            )
            if not resp.tool_calls:
                break
            for tc in resp.tool_calls:
                tool_calls_made.append({"name": tc.name, "arguments": tc.arguments})
            tool_results = execute_tools(resp.tool_calls, TOOL_MAP)
            for tr in tool_results:
                if tr["is_error"]:
                    error_results.append(tr)
            append_to_history(messages, provider, resp, tool_results)

    # Verify the scenario ran: step 1 should have been attempted
    step1_calls = [tc for tc in tool_calls_made if tc["name"] == "fetch_user_profile"]
    assert len(step1_calls) >= 1, "Agent should have attempted fetch_user_profile"
    assert len(error_results) >= 1, "At least one step should have errored"
