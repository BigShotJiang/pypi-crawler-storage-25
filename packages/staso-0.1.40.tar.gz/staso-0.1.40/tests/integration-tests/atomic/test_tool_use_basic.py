"""Unit: single tool call.

Validates that a tool span is captured with correct args and result.
Expected trace shape: 1 agent span + 1 llm span + 1 tool span.
Expected detections: none.
"""
import uuid

import pytest
import staso as st

from personas.common.provider import (
    get_llm_client, llm_chat, execute_tools, append_to_history, tools_for_provider,
)

TOOL_DEFS = [
    {
        "name": "get_weather",
        "description": "Get the current weather for a city.",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name"},
            },
            "required": ["city"],
        },
    }
]


@st.tool
def get_weather(city: str) -> dict:
    return {"city": city, "temperature_c": 18, "condition": "partly cloudy"}


TOOL_MAP = {"get_weather": get_weather}


@pytest.mark.integration
@pytest.mark.atomic

def test_tool_use_basic(provider, staso_env):
    session_id = f"unit-tool-basic-{uuid.uuid4().hex[:8]}"
    client = get_llm_client(provider)
    formatted_tools = tools_for_provider(TOOL_DEFS, provider)
    messages = [{"role": "user", "content": "What is the weather in London?"}]

    with st.conversation(session_id):
        resp = llm_chat(
            client=client,
            provider=provider,
            messages=messages,
            system="Use the available tools to answer.",
            tools=formatted_tools,
            max_tokens=256,
        )
        assert resp.tool_calls, "LLM should have called get_weather"
        assert resp.tool_calls[0].name == "get_weather"
        assert resp.tool_calls[0].arguments.get("city")

        tool_results = execute_tools(resp.tool_calls, TOOL_MAP)
        append_to_history(messages, provider, resp, tool_results)

        # Pass no tools so the LLM is forced to produce a text summary
        final = llm_chat(
            client=client,
            provider=provider,
            messages=messages,
            system="Use the available tools to answer.",
            tools=[],
            max_tokens=256,
        )

    assert final.text
    assert not final.tool_calls
