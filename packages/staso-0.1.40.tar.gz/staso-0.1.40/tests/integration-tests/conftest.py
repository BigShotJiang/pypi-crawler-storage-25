"""pytest configuration for integration tests.

Adds integration-tests/ to sys.path so all persona modules are importable
as `personas.*` without per-file path hacks.

Marks:
    integration  -- requires live LLM API keys and a running Staso backend
    atomic       -- single-capability, fast (<10s), no persona setup needed
    slow         -- multi-turn or multi-pipeline scenarios (>30s expected)

Run subsets:
    pytest -m atomic                          # atomic layer only
    pytest -m "integration and not slow"      # atomic + persona happy paths
    pytest -m integration                     # everything
"""
from __future__ import annotations

import json
import os
import sys

import pytest

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

# Load .env from integration-tests/ if present (no python-dotenv dependency needed)
_ENV_FILE = os.path.join(_ROOT, ".env")
if os.path.exists(_ENV_FILE):
    with open(_ENV_FILE) as _f:
        for _line in _f:
            _line = _line.strip()
            if _line and not _line.startswith("#") and "=" in _line:
                _k, _, _v = _line.partition("=")
                os.environ.setdefault(_k.strip(), _v.strip())


def _resolve_workspace_id() -> None:
    """If STASO_WORKSPACE_SLUG is set but STASO_WORKSPACE_ID is not, resolve slug to UUID.

    Calls GET /v1/workspaces?org_id=... and sets STASO_WORKSPACE_ID in os.environ.
    Raises ValueError if the slug is not found.
    """
    if os.environ.get("STASO_WORKSPACE_ID"):
        return  # UUID already provided

    slug = os.environ.get("STASO_WORKSPACE_SLUG", "").strip()
    if not slug:
        return  # neither provided — test will skip on its own

    base_url = os.environ.get("STASO_BASE_URL", "https://api.staso.ai").rstrip("/")
    api_key = os.environ.get("STASO_API_KEY", "")
    org_id = os.environ.get("STASO_ORG_ID", "")

    if not api_key or not org_id:
        return  # missing required context — let the test skip naturally

    try:
        import httpx
        resp = httpx.get(
            f"{base_url}/v1/workspaces",
            headers={"X-API-Key": api_key},
            params={"org_id": org_id},
            timeout=10,
        )
        resp.raise_for_status()
        for ws in resp.json():
            if ws.get("slug") == slug:
                os.environ["STASO_WORKSPACE_ID"] = ws["id"]
                print(f"[conftest] Resolved workspace slug {slug!r} -> {ws['id']}")
                return
        raise ValueError(f"Workspace slug {slug!r} not found in org {org_id}")
    except Exception as exc:
        print(f"[conftest] WARNING: could not resolve workspace slug {slug!r}: {exc}")


_resolve_workspace_id()

_ALL_PROVIDERS = ["openai", "anthropic"]


def pytest_addoption(parser):
    parser.addoption(
        "--persona",
        default=None,
        help="Run tests for a specific persona: customer_support | finance_ops | code_agent | orchestrator | research_agent",
    )
    parser.addoption(
        "--providers",
        default=None,
        help="Comma-separated providers to test: openai,anthropic (default: whatever each test specifies)",
    )
    parser.addoption(
        "--self-heal-traces",
        type=int,
        default=35,
        help="Number of traces per commit for self-heal tests (min 30 for detection threshold)",
    )
    parser.addoption(
        "--self-heal-agent",
        default="selfheal-integration-agent",
        help="Agent name to use for self-heal trace ingestion",
    )
    parser.addoption(
        "--self-heal-regenerate",
        action="store_true",
        default=False,
        help="Force re-ingestion even if cached commit SHAs exist in ClickHouse",
    )
    parser.addoption(
        "--self-heal-flush-wait",
        type=int,
        default=20,
        help="Seconds to wait after trace ingestion for ClickHouse flush before triggering detection",
    )
    parser.addoption(
        "--self-heal-pipeline-timeout",
        type=int,
        default=180,
        help="Seconds to wait for the self-heal worker to produce a diagnosis result",
    )


def pytest_configure(config):
    config.addinivalue_line("markers", "integration: requires live LLM + Staso backend")
    config.addinivalue_line("markers", "atomic: single-capability, fast, no persona setup")
    config.addinivalue_line("markers", "slow: multi-turn or multi-pipeline, expect >30s")
    config.addinivalue_line("markers", "self_heal: ingest multi-commit trace pairs for self-heal regression testing")


def pytest_generate_tests(metafunc):
    """Centralized provider parametrization for all integration tests.

    All tests that accept a 'provider' argument are parametrized here.
    No test file should use @pytest.mark.parametrize("provider", ...) directly.

    --providers openai,anthropic   -> run both providers for all tests
    --providers openai             -> run only openai
    (no flag)                      -> openai only (default)
    """
    if "provider" not in metafunc.fixturenames:
        return

    providers_opt = metafunc.config.getoption("--providers")
    if providers_opt:
        providers = [p.strip() for p in providers_opt.split(",")]
    else:
        providers = ["openai"]

    metafunc.parametrize("provider", providers)


def pytest_collection_modifyitems(config, items):
    persona = config.getoption("--persona")
    if not persona:
        return
    skip = pytest.mark.skip(reason=f"--persona={persona} filter")
    for item in items:
        if f"test_{persona}" not in item.fspath.basename:
            item.add_marker(skip)


_RESULTS_DIR = os.path.join(_ROOT, "results")


@pytest.fixture
def save_result():
    """Return a callable that saves a scenario result dict to results/<scenario>_<provider>.json."""
    def _save(result: dict, provider: str) -> None:
        os.makedirs(_RESULTS_DIR, exist_ok=True)
        scenario = result.get("scenario", "unknown")
        path = os.path.join(_RESULTS_DIR, f"{scenario}_{provider}.json")
        with open(path, "w") as f:
            json.dump(result, f, indent=2)
    return _save


@pytest.fixture(scope="session")
def staso_env() -> str:
    return os.environ.get("STASO_ENVIRONMENT", os.environ.get("STASO_ENV", "staging"))


@pytest.fixture(scope="session", autouse=True)
def staso_session(staso_env):
    """Initialise the Staso SDK once per test session and shut down after."""
    api_key = os.environ.get("STASO_API_KEY", "")
    if not api_key:
        pytest.skip("STASO_API_KEY not set -- skipping all integration tests")

    import staso as st
    st.init(
        api_key=api_key,
        agent_name="integration-test-session",
        base_url=os.environ.get("STASO_BASE_URL", "https://api.staso.ai"),
        environment=staso_env,
        debug=False,
    )
    yield
    st.shutdown()


@pytest.fixture(scope="module")
def self_heal_run(request, staso_env):
    """Ingest two batches of LLM-backed traces (good commit + bad commit) for self-heal testing.

    Re-initialises the SDK twice with different STASO_VCS_COMMIT_SHA values so
    each batch is tagged with a distinct commit SHA. Returns:
        (good_results, bad_results, meta_dict)

    good_results / bad_results are lists of scenario result dicts from real LLM
    persona runs. Total per phase = n_traces * 3 scenarios.

    The fixture is module-scoped so a single ingestion run is shared across all
    self-heal test functions in the module.
    """
    import uuid
    import staso as st
    from self_heal.cache import TraceCache, clear, load, save
    from self_heal.trace_generator import generate_bad_traces, generate_good_traces, trace_count

    api_key = os.environ.get("STASO_API_KEY", "")
    if not api_key:
        pytest.skip("STASO_API_KEY not set")

    base_url = os.environ.get("STASO_BASE_URL", "https://api.staso.ai")
    n_traces = request.config.getoption("--self-heal-traces")
    agent_name = request.config.getoption("--self-heal-agent")
    regenerate = request.config.getoption("--self-heal-regenerate")

    # Use cached commit SHAs if available and regeneration not forced
    if regenerate:
        clear()

    cached = load()
    if cached and cached.get("agent_name") == agent_name:
        print(f"\n[self_heal] Reusing cached commits from {cached['ingested_at']}")
        print(f"  good_sha: {cached['good_sha']}")
        print(f"  bad_sha:  {cached['bad_sha']}")
        meta: TraceCache = cached
        return [], [], meta

    # Pick provider for trace generation (first from --providers, default openai)
    providers_opt = request.config.getoption("--providers")
    provider = providers_opt.split(",")[0].strip() if providers_opt else "openai"

    # Fresh ingestion
    run_id = uuid.uuid4().hex[:6]
    good_sha = f"selfheal_good_{run_id}"
    bad_sha = f"selfheal_bad_{run_id}"

    def _phase(commit_sha: str, generator_fn, label: str) -> list[dict]:
        os.environ["STASO_VCS_COMMIT_SHA"] = commit_sha
        os.environ["STASO_VCS_BRANCH"] = "main"
        st.init(
            api_key=api_key,
            agent_name=agent_name,
            base_url=base_url,
            environment=staso_env,
            capture_git=True,
            debug=False,
        )
        try:
            print(f"\n[self_heal] Generating {label} traces (commit={commit_sha[:12]}, repeat={n_traces})")
            return generator_fn(provider=provider, env=staso_env, repeat=n_traces)
        finally:
            st.shutdown()
            os.environ.pop("STASO_VCS_COMMIT_SHA", None)
            os.environ.pop("STASO_VCS_BRANCH", None)

    good_results = _phase(good_sha, generate_good_traces, "good")
    bad_results = _phase(bad_sha, generate_bad_traces, "bad")

    print(f"[self_heal] Ingested {trace_count(good_results)} good traces, {trace_count(bad_results)} bad traces")

    flush_wait = request.config.getoption("--self-heal-flush-wait")
    print(f"[self_heal] Waiting {flush_wait}s for ClickHouse flush...")
    import time
    time.sleep(flush_wait)

    meta = TraceCache(
        good_sha=good_sha,
        bad_sha=bad_sha,
        agent_name=agent_name,
        n_traces=n_traces,
        good_error_rate=0.0,
        bad_error_rate=0.60,
        ingested_at="",
    )
    save(meta)

    # Restore session-level SDK state for other tests
    st.init(
        api_key=api_key,
        agent_name="integration-test-session",
        base_url=base_url,
        environment=staso_env,
        debug=False,
    )

    return good_results, bad_results, meta
