"""Estimate token costs for integration test scenarios without running them.

Usage (from repo root):
    python tests/integration-tests/estimate_costs.py
    python tests/integration-tests/estimate_costs.py --provider openai
    python tests/integration-tests/estimate_costs.py --persona customer_support
    python tests/integration-tests/estimate_costs.py --scenario billing_inquiry
    python tests/integration-tests/estimate_costs.py --compute          # recompute baselines from source chars
    python tests/integration-tests/estimate_costs.py --update result.json  # calibrate from actual run

Pricing source: kept in sync with backend/src/services/analytics.py MODEL_COSTS.
Model keys differ (backend uses short names like "gpt-4o-mini"; we prefix with provider).
When backend pricing changes, update _PRICING here too.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

_HERE = Path(__file__).parent
_BASELINES_PATH = _HERE / "token_baselines.json"

# ---------------------------------------------------------------------------
# Pricing -- mirrors backend/src/services/analytics.py MODEL_COSTS format.
# Keys are "provider/model-id" to avoid collision across providers.
# Per 1M tokens (USD).
# ---------------------------------------------------------------------------
_PRICING: dict[str, dict[str, float]] = {
    "openai/gpt-4o-mini":         {"input": 0.15,  "output": 0.60},
    "openai/gpt-4o":              {"input": 2.50,  "output": 10.00},
    "anthropic/claude-haiku-4-5": {"input": 0.80,  "output": 4.00},
    "anthropic/claude-sonnet-4-6":{"input": 3.00,  "output": 15.00},
}

# Chars-per-token approximation (OpenAI/Anthropic rule of thumb for English text).
_CHARS_PER_TOKEN = 4

# ---------------------------------------------------------------------------
# Known LLM call counts per scenario (from scenario design, not measured).
# intake/classify/decide/confirm = 4 calls per pipeline run for finance_ops.
# plan + N execution + optional replan = varies for customer_support.
# ---------------------------------------------------------------------------
_SCENARIO_LLM_CALLS: dict[str, dict[str, int]] = {
    "customer_support": {
        "billing_inquiry":           4,   # plan + ~3 execution
        "multi_turn_context":       15,   # 5 turns × ~3 calls each
        "refund_at_limit":           3,   # plan + ~2 execution
        "incremental_boundary_push":20,   # 5 turns × ~4 calls each
        "amnesia":                  24,   # 8 turns × ~3 calls each
    },
    "finance_ops": {
        "payment_under_limit":  4,   # 1 pipeline run × 4 LLM stages
        "payment_at_limit":     4,
        "cumulative_evasion":  32,   # 8 pipeline runs × 4 stages
        "duplicate_payments":   8,   # 2 pipeline runs × 4 stages
    },
    "code_agent": {
        "false_completion":    10,   # plan(1) + search/read/write/run_tests loop(~9)
    },
    "orchestrator": {
        "silent_partial_failure": 8, # dispatch(4) + check(4) + aggregate + report
    },
    "research_agent": {
        "compounding_fabrication": 6, # search + get_details(~2) + summarize + final
    },
}

# Output token ratio: estimated output as fraction of max_tokens.
# Most responses are well under the 512-1024 token budget.
_OUTPUT_RATIO = 0.4


# ---------------------------------------------------------------------------
# Char extraction helpers (no imports of persona code -- avoids staso dep)
# ---------------------------------------------------------------------------

def _extract_triple_quoted(src: str, var_name: str) -> str:
    """Extract the content of a triple-quoted string assigned to var_name."""
    pattern = rf'{var_name}\s*=\s*"""(.*?)"""'
    m = re.search(pattern, src, re.DOTALL)
    return m.group(1) if m else ""


def _extract_tool_defs(src: str) -> str:
    """Extract the TOOL_DEFS list body from a tools.py source string."""
    m = re.search(r"TOOL_DEFS: list\[dict\] = (\[.+?\])\s*\n\s*\n\s*TOOL_MAP", src, re.DOTALL)
    return m.group(1) if m else ""


def _persona_static_tokens(persona: str) -> dict[str, int]:
    """Return system_prompt and tool_defs token estimates for a persona."""
    agent_src = (_HERE / "personas" / persona / "persona.py").read_text()
    tools_src = (_HERE / "personas" / persona / "tools.py").read_text()

    system_prompt = _extract_triple_quoted(agent_src, "SYSTEM_PROMPT")
    tool_defs = _extract_tool_defs(tools_src)

    return {
        "system_prompt_tokens": len(system_prompt) // _CHARS_PER_TOKEN,
        "tool_defs_tokens":     len(tool_defs)     // _CHARS_PER_TOKEN,
    }


def _scenario_user_chars(persona: str, scenario: str) -> int:
    """Rough char count of user-visible text in a scenario (turns + request strings)."""
    src = (_HERE / "personas" / persona / "harness.py").read_text()

    # Find the scenario function body
    fn_name = f"run_{scenario}"
    fn_match = re.search(rf"def {fn_name}\(.+?\ndef (run_|\Z)", src, re.DOTALL)
    fn_body = fn_match.group(0) if fn_match else src

    # Sum all string literals in the function body as a proxy for user turn text
    strings = re.findall(r'"([^"]{20,})"', fn_body)
    strings += re.findall(r"'([^']{20,})'", fn_body)
    return sum(len(s) for s in strings)


# ---------------------------------------------------------------------------
# Compute baselines from source chars
# ---------------------------------------------------------------------------

def compute_baselines() -> dict:
    """Derive token estimates from actual source file character counts."""
    baselines: dict = {}

    for persona, scenarios in _SCENARIO_LLM_CALLS.items():
        static = _persona_static_tokens(persona)
        sys_tokens = static["system_prompt_tokens"]
        tool_tokens = static["tool_defs_tokens"]
        # Static context sent on every LLM call
        static_input_per_call = sys_tokens + tool_tokens

        baselines[persona] = {}
        for scenario, llm_calls in scenarios.items():
            user_chars = _scenario_user_chars(persona, scenario)
            user_tokens = user_chars // _CHARS_PER_TOKEN

            # Input: static context × calls + user/history tokens (grows with turns)
            # Use a 1.5× multiplier on user tokens to account for history accumulation
            input_tokens = static_input_per_call * llm_calls + int(user_tokens * 1.5)

            # Output: each call produces up to max_tokens × output_ratio
            max_tokens_per_call = 512 if persona == "finance_ops" else 1024
            output_tokens = int(max_tokens_per_call * _OUTPUT_RATIO * llm_calls)

            baselines[persona][scenario] = {
                model_key: {
                    "input_tokens":  input_tokens,
                    "output_tokens": output_tokens,
                    "llm_calls":     llm_calls,
                    "_method":       "char_count",
                }
                for model_key in _PRICING
            }

    return baselines


# ---------------------------------------------------------------------------
# Cost calculation
# ---------------------------------------------------------------------------

def _cost(model_key: str, input_tokens: int, output_tokens: int) -> float:
    pricing = _PRICING.get(model_key)
    if not pricing:
        return 0.0
    return (
        input_tokens  / 1_000_000 * pricing["input"] +
        output_tokens / 1_000_000 * pricing["output"]
    )


def _load_baselines() -> dict:
    with open(_BASELINES_PATH) as f:
        return json.load(f)


# ---------------------------------------------------------------------------
# Display
# ---------------------------------------------------------------------------

def estimate(
    baselines: dict,
    provider_filter: str | None = None,
    persona_filter: str | None = None,
    scenario_filter: str | None = None,
) -> None:
    total_input = total_output = 0
    total_cost = 0.0
    rows = []

    for persona, scenarios in baselines.items():
        if persona.startswith("_"):
            continue
        if persona_filter and persona != persona_filter:
            continue
        for scenario, providers in scenarios.items():
            if scenario_filter and scenario != scenario_filter:
                continue
            for model_key, est in providers.items():
                if model_key.startswith("_"):
                    continue
                prov = model_key.split("/")[0]
                if provider_filter and prov != provider_filter:
                    continue

                inp  = est["input_tokens"]
                out  = est["output_tokens"]
                calls = est["llm_calls"]
                method = est.get("_method", "manual")
                cost = _cost(model_key, inp, out)

                total_input  += inp
                total_output += out
                total_cost   += cost

                rows.append((persona, scenario, model_key, inp, out, inp + out, calls, cost, method))

    if not rows:
        print("No matching scenarios found.")
        return

    col_w = [18, 30, 30, 7, 7, 8, 6, 10, 12]
    hdrs  = ["persona", "scenario", "model", "input", "output", "total", "calls", "cost($)", "method"]
    fmt   = "  ".join(f"{{:<{w}}}" for w in col_w)
    sep   = "  ".join("-" * w for w in col_w)

    print()
    print(fmt.format(*hdrs))
    print(sep)
    for r in rows:
        persona, scenario, model, inp, out, tot, calls, cost, method = r
        print(fmt.format(persona, scenario, model, inp, out, tot, calls, f"{cost:.5f}", method))
    print(sep)
    print(fmt.format("TOTAL", "", "", total_input, total_output, total_input + total_output,
                     "", f"{total_cost:.5f}", ""))
    print()
    print(f"  Estimated total cost: ${total_cost:.4f} USD")
    print()


# ---------------------------------------------------------------------------
# Update baselines from an actual run result
# ---------------------------------------------------------------------------

def update_from_result(result_path: str) -> None:
    baselines = _load_baselines()

    with open(result_path) as f:
        result = json.load(f)

    scenario    = result.get("scenario")
    token_usage = result.get("token_usage")
    if not scenario or not token_usage:
        print("Result file missing 'scenario' or 'token_usage' keys.")
        return

    session_id = result.get("session_id", "")
    persona = next(
        (p for p in baselines if not p.startswith("_") and session_id.startswith(p.replace("_", "-"))),
        None,
    )
    if not persona or scenario not in baselines.get(persona, {}):
        print(f"Could not locate {persona}/{scenario} in baselines.")
        return

    for model_key in baselines[persona][scenario]:
        if model_key.startswith("_"):
            continue
        entry = baselines[persona][scenario][model_key]
        entry["input_tokens"]  = token_usage["input_tokens"]
        entry["output_tokens"] = token_usage["output_tokens"]
        entry["_method"]       = "actual"
        print(f"Updated {persona}/{scenario}/{model_key} -> actual.")

    with open(_BASELINES_PATH, "w") as f:
        json.dump(baselines, f, indent=2)
    print(f"Saved {_BASELINES_PATH}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Estimate integration test token costs without running tests.",
    )
    parser.add_argument("--provider", help="Filter: openai | anthropic")
    parser.add_argument("--persona",  help="Filter: customer_support | finance_ops")
    parser.add_argument("--scenario", help="Filter: billing_inquiry | amnesia | ...")
    parser.add_argument("--compute",  action="store_true",
                        help="Recompute baselines from source file char counts and save.")
    parser.add_argument("--update",   metavar="RESULT_JSON",
                        help="Calibrate baselines from an actual test run result JSON.")
    args = parser.parse_args()

    if args.update:
        update_from_result(args.update)
        return

    if args.compute:
        baselines = compute_baselines()
        with open(_BASELINES_PATH, "w") as f:
            json.dump(baselines, f, indent=2)
        print(f"Recomputed baselines saved to {_BASELINES_PATH}")
        estimate(baselines, args.provider, args.persona, args.scenario)
        return

    baselines = _load_baselines()
    estimate(baselines, args.provider, args.persona, args.scenario)


if __name__ == "__main__":
    main()
