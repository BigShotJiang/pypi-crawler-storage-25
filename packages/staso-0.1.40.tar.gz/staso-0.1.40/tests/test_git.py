"""Tests for staso.git -- git context detection."""
from __future__ import annotations

import json
from unittest.mock import patch

import pytest

from staso.git import (
    GitContext,
    _from_build_info_file,
    _from_git_cli,
    _from_platform_env_vars,
    _from_staso_env_vars,
    _strip_credentials,
    detect_git,
)


class TestStripCredentials:
    def test_strips_user_pass(self):
        assert _strip_credentials("https://user:pass@github.com/org/repo.git") == "https://github.com/org/repo.git"

    def test_strips_token(self):
        assert _strip_credentials("https://x-access-token:ghp_abc@github.com/org/repo") == "https://github.com/org/repo"

    def test_no_credentials_unchanged(self):
        assert _strip_credentials("https://github.com/org/repo") == "https://github.com/org/repo"

    def test_ssh_url_unchanged(self):
        url = "git@github.com:org/repo.git"
        assert _strip_credentials(url) == url

    def test_empty_string(self):
        assert _strip_credentials("") == ""


class TestFromStasoEnvVars:
    def test_returns_context_when_set(self, monkeypatch):
        monkeypatch.setenv("STASO_VCS_COMMIT_SHA", "abc123" * 6 + "abcd")
        monkeypatch.setenv("STASO_VCS_BRANCH", "main")
        monkeypatch.setenv("STASO_VCS_REPO_URL", "https://github.com/org/repo")

        ctx = _from_staso_env_vars()
        assert ctx is not None
        assert ctx.commit_sha == "abc123" * 6 + "abcd"
        assert ctx.branch == "main"
        assert ctx.repo_url == "https://github.com/org/repo"
        assert ctx.is_dirty is False

    def test_returns_none_when_empty(self, monkeypatch):
        monkeypatch.delenv("STASO_VCS_COMMIT_SHA", raising=False)
        assert _from_staso_env_vars() is None

    def test_returns_none_when_blank(self, monkeypatch):
        monkeypatch.setenv("STASO_VCS_COMMIT_SHA", "")
        assert _from_staso_env_vars() is None


class TestFromPlatformEnvVars:
    def test_github_actions(self, monkeypatch):
        monkeypatch.setenv("GITHUB_ACTIONS", "true")
        monkeypatch.setenv("GITHUB_SHA", "a" * 40)
        monkeypatch.setenv("GITHUB_REF_NAME", "feature-branch")
        monkeypatch.setenv("GITHUB_REPOSITORY", "org/repo")

        ctx = _from_platform_env_vars()
        assert ctx is not None
        assert ctx.commit_sha == "a" * 40
        assert ctx.branch == "feature-branch"
        assert ctx.repo_url == "org/repo"
        assert ctx.is_dirty is False

    def test_vercel(self, monkeypatch):
        monkeypatch.setenv("VERCEL", "1")
        monkeypatch.setenv("VERCEL_GIT_COMMIT_SHA", "b" * 40)
        monkeypatch.setenv("VERCEL_GIT_COMMIT_REF", "main")
        monkeypatch.setenv("VERCEL_GIT_REPO_SLUG", "my-app")

        ctx = _from_platform_env_vars()
        assert ctx is not None
        assert ctx.commit_sha == "b" * 40
        assert ctx.branch == "main"

    def test_gitlab_ci(self, monkeypatch):
        monkeypatch.setenv("GITLAB_CI", "true")
        monkeypatch.setenv("CI_COMMIT_SHA", "c" * 40)
        monkeypatch.setenv("CI_COMMIT_BRANCH", "develop")
        monkeypatch.setenv("CI_PROJECT_URL", "https://gitlab.com/org/repo")

        ctx = _from_platform_env_vars()
        assert ctx is not None
        assert ctx.commit_sha == "c" * 40
        assert ctx.branch == "develop"

    def test_strips_credentials_from_repo_url(self, monkeypatch):
        monkeypatch.setenv("CIRCLECI", "true")
        monkeypatch.setenv("CIRCLE_SHA1", "d" * 40)
        monkeypatch.setenv("CIRCLE_BRANCH", "main")
        monkeypatch.setenv("CIRCLE_REPOSITORY_URL", "https://token@github.com/org/repo.git")

        ctx = _from_platform_env_vars()
        assert ctx is not None
        assert ctx.repo_url == "https://github.com/org/repo.git"

    def test_returns_none_without_ci(self, monkeypatch):
        for var in ["GITHUB_ACTIONS", "VERCEL", "GITLAB_CI", "CIRCLECI",
                     "BITBUCKET_COMMIT", "CODEBUILD_BUILD_ID", "NETLIFY",
                     "TF_BUILD", "RAILWAY_ENVIRONMENT", "HEROKU_SLUG_COMMIT"]:
            monkeypatch.delenv(var, raising=False)
        assert _from_platform_env_vars() is None

    def test_platform_with_no_branch_var(self, monkeypatch):
        monkeypatch.setenv("HEROKU_SLUG_COMMIT", "e" * 40)

        ctx = _from_platform_env_vars()
        assert ctx is not None
        assert ctx.commit_sha == "e" * 40
        assert ctx.branch == ""


class TestFromGitCli:
    def test_returns_context_in_repo(self, monkeypatch):
        monkeypatch.setattr(
            "staso.git._run",
            lambda cmd, cwd: {
                ("git", "rev-parse", "HEAD"): "f" * 40,
                ("git", "rev-parse", "--abbrev-ref", "HEAD"): "main",
                ("git", "config", "--get", "remote.origin.url"): "https://github.com/org/repo.git",
                ("git", "status", "--porcelain"): "",
            }.get(tuple(cmd)),
        )

        ctx = _from_git_cli(None)
        assert ctx is not None
        assert ctx.commit_sha == "f" * 40
        assert ctx.branch == "main"
        assert ctx.repo_url == "https://github.com/org/repo.git"
        assert ctx.is_dirty is False

    def test_dirty_repo(self, monkeypatch):
        monkeypatch.setattr(
            "staso.git._run",
            lambda cmd, cwd: {
                ("git", "rev-parse", "HEAD"): "f" * 40,
                ("git", "rev-parse", "--abbrev-ref", "HEAD"): "main",
                ("git", "config", "--get", "remote.origin.url"): "",
                ("git", "status", "--porcelain"): " M src/main.py",
            }.get(tuple(cmd)),
        )

        ctx = _from_git_cli(None)
        assert ctx is not None
        assert ctx.is_dirty is True

    def test_returns_none_without_git(self, monkeypatch):
        monkeypatch.setattr("staso.git._run", lambda cmd, cwd: None)
        assert _from_git_cli(None) is None

    def test_returns_none_for_short_sha(self, monkeypatch):
        monkeypatch.setattr(
            "staso.git._run",
            lambda cmd, cwd: "abc123" if tuple(cmd) == ("git", "rev-parse", "HEAD") else None,
        )
        assert _from_git_cli(None) is None


class TestFromBuildInfoFile:
    def test_reads_valid_file(self, tmp_path):
        info = {"commit_sha": "a" * 40, "branch": "main", "repo_url": "https://github.com/org/repo"}
        (tmp_path / ".staso-build-info").write_text(json.dumps(info), encoding="utf-8")

        ctx = _from_build_info_file(str(tmp_path))
        assert ctx is not None
        assert ctx.commit_sha == "a" * 40
        assert ctx.branch == "main"
        assert ctx.repo_url == "https://github.com/org/repo"
        assert ctx.is_dirty is False

    def test_returns_none_without_file(self, tmp_path):
        assert _from_build_info_file(str(tmp_path)) is None

    def test_returns_none_for_invalid_json(self, tmp_path):
        (tmp_path / ".staso-build-info").write_text("not json", encoding="utf-8")
        assert _from_build_info_file(str(tmp_path)) is None

    def test_returns_none_for_missing_sha(self, tmp_path):
        (tmp_path / ".staso-build-info").write_text(json.dumps({"branch": "main"}), encoding="utf-8")
        assert _from_build_info_file(str(tmp_path)) is None


class TestDetectGit:
    def test_priority_staso_env_first(self, monkeypatch):
        monkeypatch.setenv("STASO_VCS_COMMIT_SHA", "1" * 40)
        monkeypatch.setenv("STASO_VCS_BRANCH", "staso-branch")
        monkeypatch.setenv("GITHUB_ACTIONS", "true")
        monkeypatch.setenv("GITHUB_SHA", "2" * 40)

        ctx = detect_git()
        assert ctx is not None
        assert ctx.commit_sha == "1" * 40
        assert ctx.branch == "staso-branch"

    def test_falls_through_to_platform(self, monkeypatch):
        monkeypatch.delenv("STASO_VCS_COMMIT_SHA", raising=False)
        monkeypatch.setenv("GITHUB_ACTIONS", "true")
        monkeypatch.setenv("GITHUB_SHA", "2" * 40)
        monkeypatch.setenv("GITHUB_REF_NAME", "gh-branch")

        monkeypatch.setattr("staso.git._from_git_cli", lambda cwd: None)

        ctx = detect_git()
        assert ctx is not None
        assert ctx.commit_sha == "2" * 40

    def test_returns_none_when_nothing_available(self, monkeypatch):
        monkeypatch.delenv("STASO_VCS_COMMIT_SHA", raising=False)
        for var in ["GITHUB_ACTIONS", "VERCEL", "GITLAB_CI", "CIRCLECI",
                     "BITBUCKET_COMMIT", "CODEBUILD_BUILD_ID", "NETLIFY",
                     "TF_BUILD", "RAILWAY_ENVIRONMENT", "HEROKU_SLUG_COMMIT"]:
            monkeypatch.delenv(var, raising=False)
        monkeypatch.setattr("staso.git._from_git_cli", lambda cwd: None)

        assert detect_git("/nonexistent") is None

    def test_git_context_is_frozen(self):
        ctx = GitContext(commit_sha="a" * 40, branch="main", repo_url="", is_dirty=False)
        with pytest.raises(AttributeError):
            ctx.commit_sha = "changed"  # type: ignore[misc]
