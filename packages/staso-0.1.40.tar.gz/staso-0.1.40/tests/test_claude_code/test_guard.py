"""Guard enforcement tests for the Claude Code PreToolUse hook."""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from staso.claude_code.hook import handle_pre_tool_use
from staso.claude_code.state import HookState, save_state
from staso.guard_types import GuardResult, GuardRuleResult


def _make_sender() -> MagicMock:
    sender = MagicMock()
    sender.send = MagicMock()
    return sender


def _seed_state(tmp_path, session_id: str = "s1") -> None:
    state = HookState(session_id=session_id, cwd="/proj")
    state.current_trace_id = "trace-1"
    state.current_turn_span_id = "turn-span-1"
    save_state(state)


def _payload(
    session_id: str = "s1",
    tool_name: str = "Bash",
    tool_input: dict | None = None,
) -> dict:
    return {
        "hook_event_name": "PreToolUse",
        "session_id": session_id,
        "tool_name": tool_name,
        "tool_input": tool_input or {"command": "ls"},
        "tool_use_id": "tu-1",
    }


class TestPreToolUseGuardDisabled:
    def test_guard_disabled_returns_none(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "staso.claude_code.state._state_dir", lambda: tmp_path
        )
        monkeypatch.setenv("STASO_GUARD_ENABLED", "false")
        _seed_state(tmp_path)

        with patch("staso.guard.guard") as mock_guard:
            result = handle_pre_tool_use(_payload(), _make_sender())

        assert result is None
        mock_guard.assert_not_called()


class TestPreToolUseGuardBlock:
    def test_block_returns_decision_block(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "staso.claude_code.state._state_dir", lambda: tmp_path
        )
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        _seed_state(tmp_path)

        block = GuardResult(
            action="block",
            reason="dangerous rm -rf",
            rules_triggered=["no_rm_rf"],
        )
        with patch("staso.guard.guard", return_value=block):
            sender = _make_sender()
            result = handle_pre_tool_use(
                _payload(tool_input={"command": "rm -rf /"}), sender
            )

        assert result == {"decision": "block", "reason": "dangerous rm -rf"}
        # A guard:blocked:Bash span was emitted
        sender.send.assert_called()
        spans = sender.send.call_args[0][0]
        assert any(s["name"] == "guard:blocked:Bash" for s in spans)
        assert spans[0]["status"] == "error"

    def test_escalate_also_returns_block_decision(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "staso.claude_code.state._state_dir", lambda: tmp_path
        )
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        _seed_state(tmp_path)

        escalate = GuardResult(action="escalate", reason="needs review")
        with patch("staso.guard.guard", return_value=escalate):
            result = handle_pre_tool_use(_payload(), _make_sender())

        assert result is not None
        assert result["decision"] == "block"


class TestPreToolUseGuardModify:
    def test_modify_returns_modified_input(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "staso.claude_code.state._state_dir", lambda: tmp_path
        )
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        _seed_state(tmp_path)

        modified = GuardResult(
            action="modify",
            modified_input={"command": "ls -la"},
            modifications=[{"path": "command", "value": "ls -la"}],
        )
        with patch("staso.guard.guard", return_value=modified):
            sender = _make_sender()
            result = handle_pre_tool_use(
                _payload(tool_input={"command": "rm -rf /"}), sender
            )

        assert result == {
            "decision": "modify",
            "tool_input": {"command": "ls -la"},
        }
        sender.send.assert_called()
        spans = sender.send.call_args[0][0]
        assert any(s["name"] == "guard:modified:Bash" for s in spans)

    def test_modify_without_modified_input_falls_through(
        self, tmp_path, monkeypatch
    ):
        monkeypatch.setattr(
            "staso.claude_code.state._state_dir", lambda: tmp_path
        )
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        _seed_state(tmp_path)

        empty_modify = GuardResult(action="modify", modified_input=None)
        with patch("staso.guard.guard", return_value=empty_modify):
            result = handle_pre_tool_use(_payload(), _make_sender())

        # No decision returned — defaults to allow
        assert result is None


class TestPreToolUseGuardAllow:
    def test_allow_no_audit_returns_none(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "staso.claude_code.state._state_dir", lambda: tmp_path
        )
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        _seed_state(tmp_path)

        with patch(
            "staso.guard.guard",
            return_value=GuardResult(action="allow"),
        ):
            sender = _make_sender()
            result = handle_pre_tool_use(_payload(), sender)

        assert result is None

    def test_allow_with_audit_rules_emits_would_block_span(
        self, tmp_path, monkeypatch
    ):
        monkeypatch.setattr(
            "staso.claude_code.state._state_dir", lambda: tmp_path
        )
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        _seed_state(tmp_path)

        audit = GuardRuleResult(
            rule_name="secret_path",
            passed=False,
            action="audit",
            reason="scanning sensitive paths",
        )
        with patch(
            "staso.guard.guard",
            return_value=GuardResult(action="allow", results=[audit]),
        ):
            sender = _make_sender()
            result = handle_pre_tool_use(_payload(), sender)

        assert result is None
        sender.send.assert_called()
        spans = sender.send.call_args[0][0]
        assert any(s["name"] == "guard:would-block:Bash" for s in spans)


class TestPreToolUseGuardEdgeCases:
    def test_empty_trace_id_skips_guard(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "staso.claude_code.state._state_dir", lambda: tmp_path
        )
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)

        state = HookState(session_id="s1", cwd="/proj")
        state.current_trace_id = ""  # defensive empty
        state.current_turn_span_id = "turn-span-1"
        save_state(state)

        with patch("staso.guard.guard") as mock_guard:
            result = handle_pre_tool_use(_payload(), _make_sender())

        assert result is None
        mock_guard.assert_not_called()

    def test_guard_exception_defaults_to_allow(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "staso.claude_code.state._state_dir", lambda: tmp_path
        )
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        _seed_state(tmp_path)

        with patch("staso.guard.guard", side_effect=RuntimeError("boom")):
            result = handle_pre_tool_use(_payload(), _make_sender())

        # Fail-open behavior
        assert result is None

    def test_guard_receives_context_with_trace_and_session(
        self, tmp_path, monkeypatch
    ):
        monkeypatch.setattr(
            "staso.claude_code.state._state_dir", lambda: tmp_path
        )
        monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
        _seed_state(tmp_path)

        captured: dict = {}

        def fake_guard(**kwargs):
            captured.update(kwargs)
            return GuardResult(action="allow")

        with patch("staso.guard.guard", side_effect=fake_guard):
            handle_pre_tool_use(_payload(), _make_sender())

        ctx = captured["context"]
        assert ctx["trace_id"] == "trace-1"
        assert ctx["session_id"] == "s1"
