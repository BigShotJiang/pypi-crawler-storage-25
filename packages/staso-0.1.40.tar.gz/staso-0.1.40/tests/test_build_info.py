"""Tests for staso.build_info -- Docker build-time git snapshot CLI."""
from __future__ import annotations

import json
from unittest.mock import patch

from staso.build_info import main
from staso.git import GitContext


class TestBuildInfoMain:
    def test_writes_file_when_git_detected(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        ctx = GitContext(commit_sha="a" * 40, branch="main", repo_url="https://github.com/org/repo", is_dirty=True)
        with patch("staso.build_info.detect_git", return_value=ctx):
            main()

        info_path = tmp_path / ".staso-build-info"
        assert info_path.exists()
        data = json.loads(info_path.read_text(encoding="utf-8"))
        assert data["commit_sha"] == "a" * 40
        assert data["branch"] == "main"
        assert data["repo_url"] == "https://github.com/org/repo"

    def test_skips_when_no_git(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        with patch("staso.build_info.detect_git", return_value=None):
            main()

        assert not (tmp_path / ".staso-build-info").exists()
        assert "skipping" in capsys.readouterr().err
