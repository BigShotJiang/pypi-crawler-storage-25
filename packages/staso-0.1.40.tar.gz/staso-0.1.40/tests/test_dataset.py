"""Unit tests for staso.dataset — CRUD, entries, CSV, folders, curation, eval.

All HTTP is mocked via an in-process fake httpx.Client. No real network calls.
"""
from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

import staso.dataset as dataset_api
from staso.client import Client, _set_client
from staso.config import Config
from staso.dataset import (
    TraceColumnMapping,
    shutdown_dataset_client,
)
from staso.dataset._client import DatasetHTTPClient
from staso.dataset._eval import EvaluationRunner
from staso.dataset._types import (
    ColumnType,
    Dataset,
    DatasetColumn,
    DatasetEntry,
    DatasetFolder,
    EvalResult,
    EvalSummary,
    SplitType,
    StasoDatasetError,
)


# ── Fake httpx Client ────────────────────────────────────────────────────


class FakeResponse:
    def __init__(self, status_code: int = 200, json_body=None, content: bytes | None = None, text: str = ""):
        self.status_code = status_code
        self._json = json_body
        self.content = content if content is not None else (
            json.dumps(json_body).encode() if json_body is not None else b""
        )
        self.text = text or (
            json.dumps(json_body) if json_body is not None else ""
        )

    def json(self):
        return self._json


class FakeHTTP:
    """In-process stand-in for httpx.Client."""

    def __init__(self):
        self.calls: list[tuple] = []
        # Map (method, path_suffix) -> list of responses
        self.responses: dict = {}
        self._default: FakeResponse | None = None

    def set_default(self, resp: FakeResponse) -> None:
        self._default = resp

    def queue(self, method: str, path_suffix: str, resp: FakeResponse) -> None:
        self.responses.setdefault((method.upper(), path_suffix), []).append(resp)

    def request(self, method: str, url: str, **kwargs):
        self.calls.append(("request", method.upper(), url, kwargs))
        key = (method.upper(), _match_suffix(url, self.responses))
        if key in self.responses and self.responses[key]:
            return self.responses[key].pop(0)
        if self._default is not None:
            return self._default
        return FakeResponse(200, {})

    def post(self, url: str, **kwargs):
        self.calls.append(("post", "POST", url, kwargs))
        key = ("POST", _match_suffix(url, self.responses))
        if key in self.responses and self.responses[key]:
            return self.responses[key].pop(0)
        if self._default is not None:
            return self._default
        return FakeResponse(200, {})

    def get(self, url: str, **kwargs):
        self.calls.append(("get", "GET", url, kwargs))
        key = ("GET", _match_suffix(url, self.responses))
        if key in self.responses and self.responses[key]:
            return self.responses[key].pop(0)
        if self._default is not None:
            return self._default
        return FakeResponse(200, {})

    def close(self):
        pass


def _match_suffix(url: str, responses: dict) -> str:
    """Find the longest registered suffix that matches this URL."""
    matching = [
        suffix
        for (_m, suffix) in responses.keys()
        if suffix and url.endswith(suffix) or suffix == ""
    ]
    # Prefer longest match
    matching.sort(key=len, reverse=True)
    return matching[0] if matching else ""


# ── Fixtures ────────────────────────────────────────────────────────────


@pytest.fixture
def fake_http():
    return FakeHTTP()


@pytest.fixture
def dataset_client(fake_http):
    """Real DatasetHTTPClient with fake httpx backing it."""
    client = DatasetHTTPClient(
        base_url="https://api.test.staso.ai",
        api_key="test-key",
        workspace_slug="default",
    )
    client._client = fake_http  # inject fake
    return client


@pytest.fixture
def staso_client_with_dataset(fake_http, monkeypatch):
    """Set up a staso Client so DatasetNamespace can resolve _get_client()."""
    cfg = Config(
        api_key="test-key",
        agent_name="test-agent",
        base_url="https://api.test.staso.ai",
        workspace_slug="default",
        enabled=False,
    )
    client = Client.__new__(Client)
    client._config = cfg
    client._transport = MagicMock()
    client._provider = None
    _set_client(client)

    # Force the dataset module to build a fresh client and inject our fake http
    shutdown_dataset_client()
    import staso.dataset as ds_mod

    original_cls = DatasetHTTPClient

    def _factory(**kwargs):
        c = original_cls(**kwargs)
        c._client = fake_http
        return c

    # Patch the lazy import so `_get_client()` returns a client with our fake
    with patch(
        "staso.dataset._client.DatasetHTTPClient",
        side_effect=_factory,
    ):
        yield cfg
    shutdown_dataset_client()
    _set_client(None)  # type: ignore[arg-type]


# ── Types ───────────────────────────────────────────────────────────────


class TestDatasetTypes:
    def test_column_type_enum_members(self):
        assert ColumnType.VARIABLE == "variable"
        assert ColumnType.INPUT == "input"
        assert ColumnType.OUTPUT == "output"
        assert ColumnType.EXPECTED_OUTPUT == "expected_output"
        assert ColumnType.EXPECTED_TOOL_CALLS == "expected_tool_calls"
        assert ColumnType.SCENARIO == "scenario"
        assert ColumnType.EXPECTED_STEPS == "expected_steps"
        assert ColumnType.CONVERSATION_HISTORY == "conversation_history"
        assert ColumnType.FILES == "files"
        assert ColumnType.CUSTOM == "custom"

    def test_split_type_enum_members(self):
        assert SplitType.TRAIN == "train"
        assert SplitType.TEST == "test"
        assert SplitType.VALIDATION == "validation"

    def test_dataset_frozen(self):
        d = Dataset(id="d1", name="x")
        with pytest.raises((AttributeError, Exception)):
            d.name = "new"  # type: ignore[misc]

    def test_dataset_entry_defaults(self):
        e = DatasetEntry(id="e1", dataset_id="d1")
        assert e.data == {}
        assert e.split is None
        assert e.source_type is None

    def test_dataset_folder_defaults(self):
        f = DatasetFolder(id="f1", name="root")
        assert f.parent_id is None

    def test_staso_dataset_error_has_status_code(self):
        err = StasoDatasetError("bad", status_code=500, response_body="server")
        assert err.status_code == 500
        assert err.response_body == "server"
        assert "bad" in str(err)

    def test_eval_summary_defaults(self):
        s = EvalSummary(
            dataset_id="d1",
            dataset_name="x",
            total=0,
            passed=0,
            failed=0,
            error_count=0,
            avg_duration_ms=0.0,
        )
        assert s.scores == {}
        assert s.results == ()


# ── HTTP Client: CRUD ───────────────────────────────────────────────────


class TestDatasetClientCRUD:
    def test_create_dataset_basic(self, dataset_client, fake_http):
        fake_http.set_default(
            FakeResponse(
                200,
                {
                    "id": "d1",
                    "name": "My DS",
                    "description": "desc",
                    "created_at": "2026-04-15T00:00:00Z",
                },
            )
        )
        ds = dataset_client.create_dataset("My DS", "desc", [], None)
        assert ds.id == "d1"
        assert ds.name == "My DS"
        # First call is a POST
        method_call = fake_http.calls[0]
        assert method_call[1] == "POST"
        body = method_call[3]["json"]
        assert body["name"] == "My DS"
        assert body["template"] == "custom"

    def test_create_dataset_with_folder(self, dataset_client, fake_http):
        fake_http.set_default(FakeResponse(200, {"id": "d1", "name": "N"}))
        dataset_client.create_dataset("N", "", [], "folder-7")
        body = fake_http.calls[0][3]["json"]
        assert body["folder_id"] == "folder-7"

    def test_create_dataset_with_columns_makes_extra_calls(
        self, dataset_client, fake_http
    ):
        fake_http.queue(
            "POST",
            "",
            FakeResponse(200, {"id": "d1", "name": "N"}),
        )
        # Column creation call
        fake_http.queue(
            "POST",
            "/d1/columns",
            FakeResponse(200, {"id": "c1", "name": "input_col"}),
        )
        # Re-fetch after columns
        fake_http.queue(
            "GET",
            "/d1",
            FakeResponse(
                200,
                {
                    "id": "d1",
                    "name": "N",
                    "columns": [
                        {
                            "name": "input_col",
                            "column_type": "input",
                            "description": "",
                            "is_required": True,
                        }
                    ],
                },
            ),
        )

        ds = dataset_client.create_dataset(
            "N",
            "",
            [{"name": "input_col", "column_type": "input", "description": ""}],
            None,
        )
        assert len(ds.columns) == 1
        assert ds.columns[0].name == "input_col"
        assert ds.columns[0].column_type == "input"
        assert ds.columns[0].required is True

    def test_get_dataset(self, dataset_client, fake_http):
        fake_http.set_default(
            FakeResponse(
                200,
                {
                    "id": "d9",
                    "name": "Fetched",
                    "entry_count": 42,
                },
            )
        )
        ds = dataset_client.get_dataset("d9")
        assert ds.id == "d9"
        assert ds.entry_count == 42

    def test_list_datasets_returns_list(self, dataset_client, fake_http):
        fake_http.set_default(
            FakeResponse(
                200,
                {
                    "datasets": [
                        {"id": "a", "name": "A"},
                        {"id": "b", "name": "B"},
                    ]
                },
            )
        )
        result = dataset_client.list_datasets(None, 50, 0)
        assert len(result) == 2
        assert result[0].id == "a"

    def test_list_datasets_passes_pagination(self, dataset_client, fake_http):
        fake_http.set_default(FakeResponse(200, {"datasets": []}))
        dataset_client.list_datasets("folder-1", 10, 20)
        call = fake_http.calls[0]
        assert call[3]["params"]["limit"] == 10
        assert call[3]["params"]["offset"] == 20
        assert call[3]["params"]["folder_id"] == "folder-1"

    def test_update_dataset_patches(self, dataset_client, fake_http):
        fake_http.set_default(
            FakeResponse(200, {"id": "d1", "name": "new"})
        )
        dataset_client.update_dataset("d1", "new", None)
        call = fake_http.calls[0]
        assert call[1] == "PATCH"
        body = call[3]["json"]
        assert body == {"name": "new"}

    def test_delete_dataset(self, dataset_client, fake_http):
        fake_http.set_default(FakeResponse(204, None))
        dataset_client.delete_dataset("d1")
        call = fake_http.calls[0]
        assert call[1] == "DELETE"
        assert "/d1" in call[2]


class TestDatasetClientErrors:
    def test_4xx_raises_immediately(self, dataset_client, fake_http):
        fake_http.set_default(
            FakeResponse(404, None, text="not found")
        )
        with pytest.raises(StasoDatasetError) as exc_info:
            dataset_client.get_dataset("nope")
        assert exc_info.value.status_code == 404

    def test_5xx_retries_and_eventually_raises(
        self, dataset_client, fake_http, monkeypatch
    ):
        monkeypatch.setattr("time.sleep", lambda s: None)
        # Queue 3 500s — retry limit is 3
        for _ in range(3):
            fake_http.queue(
                "GET",
                "/d1",
                FakeResponse(500, None, text="internal"),
            )
        fake_http.set_default(FakeResponse(500, None, text="internal"))
        with pytest.raises(StasoDatasetError) as exc_info:
            dataset_client.get_dataset("d1")
        assert exc_info.value.status_code == 500

    def test_5xx_then_200_succeeds(
        self, dataset_client, fake_http, monkeypatch
    ):
        monkeypatch.setattr("time.sleep", lambda s: None)
        # First 500, then 200
        fake_http.queue("GET", "/d1", FakeResponse(500, None, text="fail"))
        fake_http.queue(
            "GET",
            "/d1",
            FakeResponse(200, {"id": "d1", "name": "ok"}),
        )
        ds = dataset_client.get_dataset("d1")
        assert ds.id == "d1"

    def test_429_is_retried(self, dataset_client, fake_http, monkeypatch):
        """Regression: 429 (rate limit) is retriable, not a permanent error."""
        monkeypatch.setattr("time.sleep", lambda s: None)
        fake_http.queue("GET", "/d1", FakeResponse(429, None, text="rate limit"))
        fake_http.queue(
            "GET", "/d1", FakeResponse(200, {"id": "d1", "name": "ok"})
        )
        ds = dataset_client.get_dataset("d1")
        assert ds.id == "d1"

    def test_429_honours_retry_after_header(
        self, dataset_client, fake_http, monkeypatch
    ):
        slept_for: list[float] = []
        monkeypatch.setattr("time.sleep", lambda s: slept_for.append(s))

        rate_limited = FakeResponse(429, None, text="rate limit")
        rate_limited.headers = {"Retry-After": "7"}
        fake_http.queue("GET", "/d1", rate_limited)
        fake_http.queue(
            "GET", "/d1", FakeResponse(200, {"id": "d1", "name": "ok"})
        )
        dataset_client.get_dataset("d1")
        assert slept_for == [7.0]

    def test_204_returns_none(self, dataset_client, fake_http):
        fake_http.set_default(FakeResponse(204, None, content=b""))
        # Delete is a good 204 test
        result = dataset_client.delete_dataset("d1")
        assert result is None


# ── Entries ─────────────────────────────────────────────────────────────


class TestDatasetClientEntries:
    def test_add_entry_basic(self, dataset_client, fake_http):
        fake_http.set_default(
            FakeResponse(
                200,
                {
                    "id": "e1",
                    "dataset_id": "d1",
                    "data": {"x": 1},
                    "source_type": "manual",
                },
            )
        )
        entry = dataset_client.add_entry("d1", {"x": 1}, None, None, None)
        assert entry.id == "e1"
        assert entry.data == {"x": 1}
        assert entry.source_type == "manual"
        body = fake_http.calls[0][3]["json"]
        assert body == {"data": {"x": 1}}

    def test_add_entry_with_split(self, dataset_client, fake_http):
        fake_http.set_default(
            FakeResponse(200, {"id": "e1", "dataset_id": "d1"})
        )
        dataset_client.add_entry("d1", {"x": 1}, "train", None, None)
        assert fake_http.calls[0][3]["json"]["split_id"] == "train"

    def test_add_entries_bulk(self, dataset_client, fake_http):
        fake_http.set_default(
            FakeResponse(
                200,
                [
                    {"id": "e1", "dataset_id": "d1"},
                    {"id": "e2", "dataset_id": "d1"},
                ],
            )
        )
        entries = dataset_client.add_entries(
            "d1", [{"x": 1}, {"x": 2}], None
        )
        assert len(entries) == 2
        call = fake_http.calls[0]
        assert "bulk" in call[2]

    def test_list_entries_returns_list(self, dataset_client, fake_http):
        fake_http.set_default(
            FakeResponse(
                200,
                {
                    "entries": [
                        {"id": "e1", "dataset_id": "d1", "data": {}},
                        {"id": "e2", "dataset_id": "d1", "data": {}},
                    ]
                },
            )
        )
        entries = dataset_client.list_entries("d1", None, 50, 0)
        assert len(entries) == 2

    def test_list_entries_with_split_filter(self, dataset_client, fake_http):
        fake_http.set_default(FakeResponse(200, {"entries": []}))
        dataset_client.list_entries("d1", "test", 10, 5)
        params = fake_http.calls[0][3]["params"]
        assert params["split_id"] == "test"
        assert params["limit"] == 10
        assert params["offset"] == 5

    def test_update_entry(self, dataset_client, fake_http):
        fake_http.set_default(
            FakeResponse(
                200,
                {"id": "e1", "dataset_id": "d1", "data": {"x": 2}},
            )
        )
        entry = dataset_client.update_entry("d1", "e1", {"x": 2})
        assert entry.data == {"x": 2}
        assert fake_http.calls[0][1] == "PATCH"

    def test_delete_entry(self, dataset_client, fake_http):
        fake_http.set_default(FakeResponse(204, None))
        dataset_client.delete_entry("d1", "e1")
        call = fake_http.calls[0]
        assert call[1] == "DELETE"
        assert call[3]["json"] == {"entry_ids": ["e1"]}


# ── Folders ─────────────────────────────────────────────────────────────


class TestDatasetClientFolders:
    def test_create_folder(self, dataset_client, fake_http):
        fake_http.set_default(
            FakeResponse(200, {"id": "f1", "name": "root"})
        )
        folder = dataset_client.create_folder("root", None)
        assert folder.id == "f1"
        assert folder.name == "root"

    def test_create_folder_with_parent(self, dataset_client, fake_http):
        fake_http.set_default(
            FakeResponse(200, {"id": "f2", "name": "child", "parent_id": "f1"})
        )
        folder = dataset_client.create_folder("child", "f1")
        body = fake_http.calls[0][3]["json"]
        assert body["parent_id"] == "f1"
        assert folder.parent_id == "f1"

    def test_list_folders_handles_list_response(
        self, dataset_client, fake_http
    ):
        fake_http.set_default(
            FakeResponse(
                200,
                [{"id": "f1", "name": "a"}, {"id": "f2", "name": "b"}],
            )
        )
        folders = dataset_client.list_folders(None)
        assert len(folders) == 2

    def test_list_folders_handles_dict_response(
        self, dataset_client, fake_http
    ):
        fake_http.set_default(
            FakeResponse(
                200,
                {"folders": [{"id": "f1", "name": "a"}]},
            )
        )
        folders = dataset_client.list_folders(None)
        assert len(folders) == 1

    def test_delete_folder(self, dataset_client, fake_http):
        fake_http.set_default(FakeResponse(204, None))
        dataset_client.delete_folder("f1")
        assert fake_http.calls[0][1] == "DELETE"


# ── CSV ─────────────────────────────────────────────────────────────────


class TestDatasetClientCSV:
    def test_upload_csv(self, dataset_client, fake_http, tmp_path):
        csv_file = tmp_path / "data.csv"
        csv_file.write_text("col1,col2\nv1,v2\n")

        fake_http.set_default(FakeResponse(200, {"imported": 1}))
        count = dataset_client.upload_csv("d1", str(csv_file), None)
        assert count == 1

    def test_upload_csv_passes_split_as_query_param(
        self, dataset_client, fake_http, tmp_path
    ):
        """Regression: upload_csv used to accept `split` and silently drop
        it, so rows landed unassigned. It should now be sent as a query param."""
        csv_file = tmp_path / "data.csv"
        csv_file.write_text("a,b\n1,2\n")
        fake_http.set_default(FakeResponse(200, {"imported": 1}))

        dataset_client.upload_csv("d1", str(csv_file), "train")

        call = next(c for c in fake_http.calls if c[0] == "post")
        assert call[3]["params"]["split_id"] == "train"

    def test_upload_csv_error(self, dataset_client, fake_http, tmp_path):
        csv_file = tmp_path / "bad.csv"
        csv_file.write_text("x")
        fake_http.set_default(FakeResponse(400, None, text="invalid"))
        with pytest.raises(StasoDatasetError) as exc_info:
            dataset_client.upload_csv("d1", str(csv_file), None)
        assert exc_info.value.status_code == 400

    def test_download_csv(self, dataset_client, fake_http, tmp_path):
        out = tmp_path / "out.csv"
        fake_http.set_default(
            FakeResponse(200, None, content=b"col1,col2\nv1,v2\n")
        )
        result_path = dataset_client.download_csv("d1", str(out), None)
        assert result_path == str(out)
        assert out.read_bytes() == b"col1,col2\nv1,v2\n"

    def test_download_csv_with_split_param(
        self, dataset_client, fake_http, tmp_path
    ):
        out = tmp_path / "out.csv"
        fake_http.set_default(FakeResponse(200, None, content=b""))
        dataset_client.download_csv("d1", str(out), "validation")
        call = fake_http.calls[0]
        assert call[3]["params"]["split_id"] == "validation"

    def test_download_csv_error(self, dataset_client, fake_http, tmp_path):
        out = tmp_path / "out.csv"
        fake_http.set_default(FakeResponse(500, None, text="boom"))
        with pytest.raises(StasoDatasetError):
            dataset_client.download_csv("d1", str(out), None)


# ── Trace Curation ──────────────────────────────────────────────────────


class TestFromTraces:
    def test_from_traces_without_mapping(self, dataset_client, fake_http):
        fake_http.set_default(FakeResponse(200, {"id": "d1", "name": "From traces"}))
        ds = dataset_client.create_from_traces("From traces", [], None, "")
        assert ds.id == "d1"

    def test_from_traces_with_mapping_calls_curate(
        self, dataset_client, fake_http
    ):
        fake_http.queue(
            "POST",
            "",
            FakeResponse(200, {"id": "d1", "name": "From traces"}),
        )
        fake_http.queue(
            "POST",
            "/d1/curate",
            FakeResponse(200, {"curated": 3}),
        )
        fake_http.queue(
            "GET",
            "/d1",
            FakeResponse(200, {"id": "d1", "name": "From traces", "entry_count": 3}),
        )
        ds = dataset_client.create_from_traces(
            "From traces",
            ["t1", "t2", "t3"],
            [
                TraceColumnMapping(source="request.body", target="input_col"),
                TraceColumnMapping(source="response.body", target="output_col"),
            ],
            "desc",
        )
        assert ds.entry_count == 3
        curate_call = next(c for c in fake_http.calls if "/curate" in c[2])
        body = curate_call[3]["json"]
        assert body["trace_ids"] == ["t1", "t2", "t3"]
        assert {"source_field": "request.body", "target_column": "input_col"} in body["mappings"]


# ── Synthetic ───────────────────────────────────────────────────────────


class TestGenerateSynthetic:
    def test_generate_parses_entries(self, dataset_client, fake_http):
        fake_http.set_default(
            FakeResponse(
                200,
                {
                    "entries": [
                        {"id": "e1", "dataset_id": "d1", "data": {"q": "a"}},
                        {"id": "e2", "dataset_id": "d1", "data": {"q": "b"}},
                    ]
                },
            )
        )
        entries = dataset_client.generate_synthetic("d1", 2, None, None)
        assert len(entries) == 2

    def test_generate_with_prompt_and_seeds(self, dataset_client, fake_http):
        fake_http.set_default(FakeResponse(200, {"entries": []}))
        dataset_client.generate_synthetic(
            "d1", 5, "be specific", ["seed-1", "seed-2"]
        )
        body = fake_http.calls[0][3]["json"]
        assert body["count"] == 5
        assert body["instructions"] == "be specific"
        assert body["seed_entry_ids"] == ["seed-1", "seed-2"]


# ── Evaluation Runner ───────────────────────────────────────────────────


class TestEvaluationRunner:
    def test_basic_run_no_scorers(self):
        http = MagicMock()
        http.get_dataset.return_value = Dataset(id="d1", name="x")
        http.list_entries.side_effect = [
            [
                DatasetEntry(id="e1", dataset_id="d1", data={"q": "a"}),
                DatasetEntry(id="e2", dataset_id="d1", data={"q": "b"}),
            ],
            [],
        ]

        def my_fn(row):
            return f"ans:{row['q']}"

        runner = EvaluationRunner(
            dataset_id="d1",
            fn=my_fn,
            scorers=[],
            split=None,
            max_concurrency=1,
            trace=False,
            http_client=http,
        )
        summary = runner.run()
        assert summary.total == 2
        assert summary.passed == 2
        assert summary.error_count == 0

    def test_scorer_below_threshold_marks_failed(self):
        http = MagicMock()
        http.get_dataset.return_value = Dataset(id="d1", name="x")
        http.list_entries.side_effect = [
            [DatasetEntry(id="e1", dataset_id="d1", data={})],
            [],
        ]

        def low_scorer(row, actual):
            return 0.3

        runner = EvaluationRunner(
            dataset_id="d1",
            fn=lambda r: "out",
            scorers=[low_scorer],
            split=None,
            max_concurrency=1,
            trace=False,
            http_client=http,
        )
        summary = runner.run()
        assert summary.failed == 1
        assert summary.passed == 0

    def test_scorer_above_threshold_passes(self):
        http = MagicMock()
        http.get_dataset.return_value = Dataset(id="d1", name="x")
        http.list_entries.side_effect = [
            [DatasetEntry(id="e1", dataset_id="d1", data={})],
            [],
        ]

        def high_scorer(row, actual):
            return 0.9

        runner = EvaluationRunner(
            dataset_id="d1",
            fn=lambda r: "out",
            scorers=[high_scorer],
            split=None,
            max_concurrency=1,
            trace=False,
            http_client=http,
        )
        summary = runner.run()
        assert summary.passed == 1
        assert "high_scorer" in summary.scores
        assert summary.scores["high_scorer"] == 0.9

    def test_fn_exception_is_called_exactly_once(self):
        """Regression: the old tracing try/except retried the user function
        on exception — running side-effectful code twice per error."""
        http = MagicMock()
        http.get_dataset.return_value = Dataset(id="d1", name="x")
        http.list_entries.side_effect = [
            [DatasetEntry(id="e1", dataset_id="d1", data={})],
            [],
        ]

        call_count = {"n": 0}

        def broken(row):
            call_count["n"] += 1
            raise ValueError("bad input")

        runner = EvaluationRunner(
            dataset_id="d1",
            fn=broken,
            scorers=[],
            split=None,
            max_concurrency=1,
            trace=True,  # tracing enabled — this is the broken code path
            http_client=http,
        )
        runner.run()
        assert call_count["n"] == 1

    def test_fn_exception_captured_as_error(self):
        http = MagicMock()
        http.get_dataset.return_value = Dataset(id="d1", name="x")
        http.list_entries.side_effect = [
            [DatasetEntry(id="e1", dataset_id="d1", data={})],
            [],
        ]

        def broken(row):
            raise ValueError("bad input")

        runner = EvaluationRunner(
            dataset_id="d1",
            fn=broken,
            scorers=[],
            split=None,
            max_concurrency=1,
            trace=False,
            http_client=http,
        )
        summary = runner.run()
        assert summary.error_count == 1
        assert summary.results[0].error == "bad input"

    def test_scorer_exception_is_logged_and_marks_failed(self):
        http = MagicMock()
        http.get_dataset.return_value = Dataset(id="d1", name="x")
        http.list_entries.side_effect = [
            [DatasetEntry(id="e1", dataset_id="d1", data={})],
            [],
        ]

        def bad_scorer(row, actual):
            raise RuntimeError("scorer broken")

        runner = EvaluationRunner(
            dataset_id="d1",
            fn=lambda r: "out",
            scorers=[bad_scorer],
            split=None,
            max_concurrency=1,
            trace=False,
            http_client=http,
        )
        summary = runner.run()
        assert summary.failed == 1

    def test_concurrent_run(self):
        http = MagicMock()
        http.get_dataset.return_value = Dataset(id="d1", name="x")
        http.list_entries.side_effect = [
            [
                DatasetEntry(id=f"e{i}", dataset_id="d1", data={"i": i})
                for i in range(4)
            ],
            [],
        ]
        runner = EvaluationRunner(
            dataset_id="d1",
            fn=lambda r: r["i"] * 2,
            scorers=[],
            split=None,
            max_concurrency=4,
            trace=False,
            http_client=http,
        )
        summary = runner.run()
        assert summary.total == 4
        assert summary.passed == 4

    def test_split_passed_to_list_entries(self):
        http = MagicMock()
        http.get_dataset.return_value = Dataset(id="d1", name="x")
        http.list_entries.side_effect = [[], []]
        runner = EvaluationRunner(
            dataset_id="d1",
            fn=lambda r: None,
            scorers=[],
            split="test",
            max_concurrency=1,
            trace=False,
            http_client=http,
        )
        runner.run()
        # first list_entries call used split="test"
        call = http.list_entries.call_args_list[0]
        assert call.args[1] == "test"

    def test_pagination_stops_after_partial_batch(self):
        http = MagicMock()
        http.get_dataset.return_value = Dataset(id="d1", name="x")
        # 3 entries — less than 100, so loop exits
        http.list_entries.return_value = [
            DatasetEntry(id=f"e{i}", dataset_id="d1") for i in range(3)
        ]
        runner = EvaluationRunner(
            dataset_id="d1",
            fn=lambda r: None,
            scorers=[],
            split=None,
            max_concurrency=1,
            trace=False,
            http_client=http,
        )
        summary = runner.run()
        assert summary.total == 3
        # Called exactly once — partial batch short-circuits
        assert http.list_entries.call_count == 1


# ── Module-level public API (st.dataset.*) ─────────────────────────────


class TestDatasetModuleAPI:
    def test_module_requires_st_init(self):
        shutdown_dataset_client()
        _set_client(None)  # type: ignore[arg-type]
        with pytest.raises(RuntimeError, match="st.init"):
            dataset_api.create("x")

    def test_create_delegates_to_http(self, staso_client_with_dataset, fake_http):
        fake_http.set_default(FakeResponse(200, {"id": "d1", "name": "x"}))
        ds = dataset_api.create("x")
        assert ds.id == "d1"

    def test_list_delegates_to_http(self, staso_client_with_dataset, fake_http):
        fake_http.set_default(FakeResponse(200, {"datasets": []}))
        result = dataset_api.list()
        assert result == []

    def test_add_entry_converts_splittype_enum(
        self, staso_client_with_dataset, fake_http
    ):
        fake_http.set_default(FakeResponse(200, {"id": "e1", "dataset_id": "d1"}))
        dataset_api.add_entry("d1", {"x": 1}, split=SplitType.TRAIN)
        body = fake_http.calls[0][3]["json"]
        assert body["split_id"] == "train"

    def test_download_csv_returns_path_object(
        self, staso_client_with_dataset, fake_http, tmp_path
    ):
        out = tmp_path / "out.csv"
        fake_http.set_default(FakeResponse(200, None, content=b""))
        result = dataset_api.download_csv("d1", out)
        assert isinstance(result, Path)

    def test_shutdown_dataset_client_resets_global(
        self, staso_client_with_dataset, fake_http
    ):
        fake_http.set_default(FakeResponse(200, {"id": "d1", "name": "x"}))
        dataset_api.create("x")
        assert dataset_api._http_client is not None
        shutdown_dataset_client()
        assert dataset_api._http_client is None

    def test_import_staso_dataset_returns_module_not_instance(self):
        """Regression: Fix 7 — `import staso.dataset` used to return a
        DatasetNamespace instance, not the module."""
        import types

        import staso.dataset as ds_mod
        assert isinstance(ds_mod, types.ModuleType)
        # Top-level API functions are module attributes
        assert callable(ds_mod.create)
        assert callable(ds_mod.evaluate)


class TestFromTracesTypedMapping:
    def test_accepts_list_of_typed_mapping(
        self, staso_client_with_dataset, fake_http
    ):
        fake_http.queue(
            "POST",
            "",
            FakeResponse(200, {"id": "d1", "name": "From traces"}),
        )
        fake_http.queue(
            "POST",
            "/d1/curate",
            FakeResponse(200, {"curated": 2}),
        )
        fake_http.queue(
            "GET",
            "/d1",
            FakeResponse(
                200, {"id": "d1", "name": "From traces", "entry_count": 2}
            ),
        )
        ds = dataset_api.from_traces(
            "From traces",
            ["t1", "t2"],
            mapping=[
                TraceColumnMapping(source="request.body", target="input"),
                TraceColumnMapping(source="response.body", target="output"),
            ],
        )
        assert ds.id == "d1"
        curate_call = next(c for c in fake_http.calls if "/curate" in c[2])
        mappings = curate_call[3]["json"]["mappings"]
        assert {"source_field": "request.body", "target_column": "input"} in mappings
        assert {"source_field": "response.body", "target_column": "output"} in mappings

    def test_legacy_dict_emits_deprecation_warning(
        self, staso_client_with_dataset, fake_http
    ):
        fake_http.queue(
            "POST", "", FakeResponse(200, {"id": "d1", "name": "X"})
        )
        fake_http.queue(
            "POST", "/d1/curate", FakeResponse(200, {"curated": 1})
        )
        fake_http.queue(
            "GET", "/d1", FakeResponse(200, {"id": "d1", "name": "X"})
        )
        with pytest.warns(DeprecationWarning):
            dataset_api.from_traces(
                "X",
                ["t1"],
                mapping={"input": "request.body"},
            )


# ── E2E (skipped — too slow for CI) ────────────────────────────────────


@pytest.mark.skip(
    reason="End-to-end dataset flow hitting a real staso backend — comprehensive but not for CI"
)
class TestDatasetE2E:
    def test_full_lifecycle_create_add_eval_delete(self):  # pragma: no cover
        raise NotImplementedError
