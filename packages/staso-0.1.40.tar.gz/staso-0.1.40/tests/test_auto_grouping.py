"""Tests for stack-frame auto-grouping in the tool-loop state machine.

The state machine picks up the non-framework call stack when the
synthetic agent-run root is opened and uses the *ancestors* of the
immediate LLM caller to decide, on subsequent calls, whether they
belong to the same agent run. A new run starts when any stored
ancestor has returned.

Concretely:
  * Sibling calls from the same helper (``for c in cs: score(c)``) —
    one trace, every call shares the ancestor chain.
  * Different helpers under the same parent (``score() ; draft()``
    both inside ``run_sweep``) — one trace, common ancestor
    ``run_sweep`` is intact.
  * Separate invocations of the same agent entry (``for _ in range(3):
    run_sweep()``) — three traces, because each ``run_sweep`` gets a
    fresh frame that shows up as a changed ancestor.
  * Nested LLM call inside a tool handler — one trace, the
    orchestrator's ancestor chain survives through the dispatch.

The helper ``_flush`` is used to explicitly close any lingering root
so tests can assert on emitted spans without waiting for atexit.
"""
from __future__ import annotations

import asyncio
from types import SimpleNamespace

import pytest


def _flush() -> None:
    """Force-close any active agent-run so the test can assert on the
    emitted root span."""
    from staso.integrations._tool_loop_state import force_close_agent_run
    force_close_agent_run()


# ── Anthropic ─────────────────────────────────────────────────────


class _FakeAnthropicMessages:
    """Fake sync Anthropic Messages that returns a configurable sequence
    of stop_reasons so tests can simulate end_turn / tool_use / etc."""

    def __init__(self, stop_reasons: list[str] | None = None) -> None:
        self._stops = list(stop_reasons) if stop_reasons else []
        self._n = 0

    def create(self, *args, **kwargs):
        stop = self._stops[self._n] if self._n < len(self._stops) else "end_turn"
        self._n += 1
        return SimpleNamespace(
            content=[],
            id=f"msg_{self._n}",
            usage=SimpleNamespace(input_tokens=10, output_tokens=5),
            stop_reason=stop,
        )


class TestAnthropicAutoGrouping:
    """Anthropic-side coverage of the anchor-based grouping rules."""

    def test_for_loop_in_one_function_shares_trace(self, capturing):
        """Sibling calls from the same helper land in one trace."""
        from staso.integrations.anthropic import _wrap_sync

        _wrap_sync(_FakeAnthropicMessages)

        def lead_hunter_sweep():
            fake = _FakeAnthropicMessages(["end_turn", "end_turn", "end_turn"])
            for _ in range(3):
                fake.create(model="claude-test")

        lead_hunter_sweep()
        _flush()

        llm_spans = [s for s in capturing if s["kind"] == "llm"]
        agent_spans = [s for s in capturing if s["kind"] == "agent"]
        assert len(llm_spans) == 3
        assert len(agent_spans) == 1, "should be one root across the for-loop"

        root_trace = agent_spans[0]["trace_id"]
        for s in llm_spans:
            assert s["trace_id"] == root_trace

    def test_nested_helpers_share_one_trace(self, capturing):
        """``score_candidates`` and ``draft_batch`` both invoked from
        ``run_sweep`` should land in the same trace — the common
        ancestor ``run_sweep`` is intact across both helper calls."""
        from staso.integrations.anthropic import _wrap_sync

        _wrap_sync(_FakeAnthropicMessages)

        fake = _FakeAnthropicMessages(["end_turn"] * 4)

        def score_candidates():
            # two LLM calls in a scoring loop
            fake.create(model="claude-scorer")
            fake.create(model="claude-scorer")

        def draft_batch():
            # two LLM calls in a drafting loop
            fake.create(model="claude-drafter")
            fake.create(model="claude-drafter")

        def run_sweep():
            score_candidates()
            draft_batch()

        run_sweep()
        _flush()

        agent_spans = [s for s in capturing if s["kind"] == "agent"]
        llm_spans = [s for s in capturing if s["kind"] == "llm"]
        assert len(agent_spans) == 1, (
            "score and draft should share one root anchored at run_sweep"
        )
        assert len(llm_spans) == 4
        root_trace = agent_spans[0]["trace_id"]
        assert all(s["trace_id"] == root_trace for s in llm_spans)

    def test_loop_of_runs_gets_trace_per_iteration(self, capturing):
        """Outer ``for _ in range(N): run_sweep()`` produces N traces
        because each ``run_sweep`` invocation is a fresh frame."""
        from staso.integrations.anthropic import _wrap_sync

        _wrap_sync(_FakeAnthropicMessages)

        def _score():
            _FakeAnthropicMessages(["end_turn"]).create(model="claude-sweep")

        def run_sweep():
            _score()

        for _ in range(3):
            run_sweep()
        _flush()

        agent_spans = [s for s in capturing if s["kind"] == "agent"]
        llm_spans = [s for s in capturing if s["kind"] == "llm"]
        assert len(agent_spans) == 3, (
            "each run_sweep() invocation is an independent agent run"
        )
        assert len(llm_spans) == 3
        trace_ids = {s["trace_id"] for s in agent_spans}
        assert len(trace_ids) == 3, "each iteration gets a distinct trace_id"

    def test_nested_llm_in_tool_handler_shares_trace(self, capturing):
        """An orchestrator that dispatches a tool whose handler makes
        its own ``messages.create`` call must keep all the LLM spans
        in one trace — nested end_turn must NOT close the outer run."""
        from staso.integrations.anthropic import _wrap_sync

        fake = _FakeAnthropicMessages(["end_turn", "end_turn"])
        _wrap_sync(type(fake))

        def score_tool():
            # Tool handler makes its own LLM call (e.g. a scorer agent
            # invoked as a tool by the orchestrator).
            fake.create(model="claude-scorer")

        def orchestrator():
            fake.create(model="claude-orch")
            # Simulate dispatching a tool call whose handler fires an
            # internal messages.create.
            score_tool()

        orchestrator()
        _flush()

        llm_spans = [s for s in capturing if s["kind"] == "llm"]
        agent_spans = [s for s in capturing if s["kind"] == "agent"]
        assert len(llm_spans) == 2
        assert len(agent_spans) == 1, (
            "nested end_turn must not close the orchestrator's root "
            "while the orchestrator frame is still running"
        )
        root_trace = agent_spans[0]["trace_id"]
        assert all(s["trace_id"] == root_trace for s in llm_spans)

    def test_agent_decorator_prevents_redundant_synthetic_root(self, capturing):
        """When ``@st.agent`` wraps the entry, the state machine must
        NOT create a second AGENT-kind root beneath the decorator's
        span."""
        import staso as st
        from staso.integrations.anthropic import _wrap_sync

        _wrap_sync(_FakeAnthropicMessages)

        @st.agent(name="manual-agent")
        def run():
            _FakeAnthropicMessages(["end_turn"]).create(model="claude-mgr")
            _FakeAnthropicMessages(["end_turn"]).create(model="claude-mgr")

        run()
        _flush()

        agent_spans = [s for s in capturing if s["kind"] == "agent"]
        assert len(agent_spans) == 1, (
            "manual @st.agent should be the only AGENT span; no "
            "synthetic root should stack on top of it"
        )
        assert agent_spans[0]["name"] == "manual-agent"
        llm_spans = [s for s in capturing if s["kind"] == "llm"]
        assert len(llm_spans) == 2
        root_trace = agent_spans[0]["trace_id"]
        assert all(s["trace_id"] == root_trace for s in llm_spans)

    def test_error_in_call_emits_root_immediately(self, capturing):
        """Error path always closes the root regardless of anchor
        state, so a crashing run still emits its trace."""
        class _Boom:
            def create(self, *args, **kwargs):
                raise ConnectionError("api down")

        from staso.integrations.anthropic import _wrap_sync
        _wrap_sync(_Boom)

        def agent():
            try:
                _Boom().create(model="claude-err")
            except ConnectionError:
                pass

        agent()
        # No flush — error path should have closed the root already.

        agent_spans = [s for s in capturing if s["kind"] == "agent"]
        llm_spans = [s for s in capturing if s["kind"] == "llm"]
        assert len(agent_spans) == 1
        assert len(llm_spans) == 1
        assert llm_spans[0]["status"] == "error"


# ── OpenAI ────────────────────────────────────────────────────────


class _FakeOpenAIMessages:
    """Fake sync OpenAI Completions that returns configurable finishes."""

    def __init__(self, finishes: list[str] | None = None) -> None:
        self._finishes = list(finishes) if finishes else []
        self._n = 0

    def create(self, *args, **kwargs):
        finish = self._finishes[self._n] if self._n < len(self._finishes) else "stop"
        self._n += 1
        return SimpleNamespace(
            id=f"cmpl_{self._n}",
            choices=[
                SimpleNamespace(
                    finish_reason=finish,
                    message=SimpleNamespace(
                        content="hi", role="assistant", tool_calls=None
                    ),
                )
            ],
            usage=SimpleNamespace(
                prompt_tokens=10, completion_tokens=5, total_tokens=15
            ),
        )


class TestOpenAIAutoGrouping:
    """OpenAI-side coverage — the terminal-flag alignment means OpenAI
    now shares the same anchor-based grouping semantics as Anthropic."""

    def test_for_loop_in_one_function_shares_trace(self, capturing):
        from staso.integrations.openai import _wrap_sync

        _wrap_sync(_FakeOpenAIMessages)

        def inbox_triage_run():
            fake = _FakeOpenAIMessages(["stop", "stop", "stop"])
            for _ in range(3):
                fake.create(model="gpt-test")

        inbox_triage_run()
        _flush()

        llm_spans = [s for s in capturing if s["kind"] == "llm"]
        agent_spans = [s for s in capturing if s["kind"] == "agent"]
        assert len(llm_spans) == 3
        assert len(agent_spans) == 1
        root_trace = agent_spans[0]["trace_id"]
        assert all(s["trace_id"] == root_trace for s in llm_spans)

    def test_loop_of_runs_gets_trace_per_iteration(self, capturing):
        from staso.integrations.openai import _wrap_sync

        _wrap_sync(_FakeOpenAIMessages)

        def _helper():
            _FakeOpenAIMessages(["stop"]).create(model="gpt-sweep")

        def run_enrich():
            _helper()

        for _ in range(3):
            run_enrich()
        _flush()

        agent_spans = [s for s in capturing if s["kind"] == "agent"]
        assert len(agent_spans) == 3

    def test_nested_llm_in_tool_handler_shares_trace(self, capturing):
        """P3 for OpenAI: nested LLM call inside a tool handler must
        not fragment the outer orchestrator's trace."""
        from staso.integrations.openai import _wrap_sync

        fake = _FakeOpenAIMessages(["stop", "stop"])
        _wrap_sync(type(fake))

        def score_tool():
            fake.create(model="gpt-scorer")

        def orchestrator():
            fake.create(model="gpt-orch")
            score_tool()

        orchestrator()
        _flush()

        llm_spans = [s for s in capturing if s["kind"] == "llm"]
        agent_spans = [s for s in capturing if s["kind"] == "agent"]
        assert len(llm_spans) == 2
        assert len(agent_spans) == 1
        root_trace = agent_spans[0]["trace_id"]
        assert all(s["trace_id"] == root_trace for s in llm_spans)

    def test_parse_and_create_in_same_function_share_trace(self, capturing):
        """Mixed API usage (``.parse`` + ``.create``) inside one driver
        shares a trace — models lead_hunter scorer (parse) + drafter
        (create) under one run_sweep."""
        from staso.integrations.openai import _wrap_sync, _wrap_sync_parse

        class _FakeParse(_FakeOpenAIMessages):
            def parse(self, *args, **kwargs):
                # Return a response object directly — do NOT call
                # self.create (it's wrapped, would double-span).
                self._n += 1
                return SimpleNamespace(
                    id=f"parsed_{self._n}",
                    choices=[
                        SimpleNamespace(
                            finish_reason="stop",
                            message=SimpleNamespace(
                                content="hi", role="assistant", tool_calls=None
                            ),
                        )
                    ],
                    usage=SimpleNamespace(
                        prompt_tokens=10, completion_tokens=5, total_tokens=15
                    ),
                )

        _wrap_sync(_FakeParse)
        _wrap_sync_parse(_FakeParse)

        fake = _FakeParse(["stop", "stop"])

        def classify():
            fake.parse(model="gpt-classify")

        def draft():
            fake.create(model="gpt-draft")

        def email_pipeline():
            classify()
            draft()

        email_pipeline()
        _flush()

        llm_spans = [s for s in capturing if s["kind"] == "llm"]
        agent_spans = [s for s in capturing if s["kind"] == "agent"]
        assert len(llm_spans) == 2
        assert len(agent_spans) == 1
        root_trace = agent_spans[0]["trace_id"]
        assert all(s["trace_id"] == root_trace for s in llm_spans)


# ── Async / concurrency ──────────────────────────────────────────


class TestAnchorEdgeCases:
    def test_async_tasks_isolated_by_contextvar(self, capturing):
        """``asyncio.gather`` copies the ContextVar per task. Each task
        opens its own root and accumulates its own path — they do NOT
        collide on a shared ``_AGENT_RUN_SPAN``."""
        from staso.integrations.anthropic import _wrap_async

        class _FakeAsync:
            def __init__(self, finish="end_turn"):
                self._finish = finish

            async def create(self, *args, **kwargs):
                return SimpleNamespace(
                    content=[],
                    id="msg_async",
                    usage=SimpleNamespace(input_tokens=1, output_tokens=1),
                    stop_reason=self._finish,
                )

        _wrap_async(_FakeAsync)

        async def _helper_a():
            await _FakeAsync().create(model="claude-a")

        async def _helper_b():
            await _FakeAsync().create(model="claude-b")

        async def task_a():
            await _helper_a()

        async def task_b():
            await _helper_b()

        async def driver():
            await asyncio.gather(task_a(), task_b())
            # The driver's own context holds no agent run after gather
            # returns (each child had its own copy); both child
            # contexts closed when the gather awaited completion. The
            # explicit flush here is defensive.
            _flush()

        asyncio.run(driver())

        # At minimum every LLM call lands in the capture; the exact
        # number of traces depends on how asyncio dispatched the tasks
        # but each task should use its own trace_id.
        llm_spans = [s for s in capturing if s["kind"] == "llm"]
        assert len(llm_spans) >= 2
