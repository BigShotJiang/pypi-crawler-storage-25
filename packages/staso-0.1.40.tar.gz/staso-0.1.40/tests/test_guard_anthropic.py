"""Guard enforcement tests for the Anthropic drop-in integration.

All Anthropic clients are faked — we never hit the real API.
"""
from __future__ import annotations

import asyncio
from types import SimpleNamespace
from unittest.mock import patch

import pytest

from staso.guard import GuardBlocked
from staso.guard_types import GuardResult, GuardRuleResult
from staso.integrations.anthropic import (
    _apply_anthropic_modify,
    _build_tool_use_refs,
    _wrap_async,
    _wrap_sync,
)


@pytest.fixture(autouse=True)
def _reset_patch_flag():
    import staso.integrations.anthropic as mod

    original = mod._patched
    mod._patched = False
    yield
    mod._patched = original


@pytest.fixture(autouse=True)
def _guard_enabled(monkeypatch):
    monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
    yield


def _tool_use_block(
    name: str = "bash",
    input_: dict | None = None,
    block_id: str = "toolu_1",
) -> SimpleNamespace:
    b = SimpleNamespace(
        type="tool_use",
        id=block_id,
        name=name,
        input=input_ if input_ is not None else {"cmd": "ls"},
    )
    b.model_dump = lambda: {
        "type": "tool_use",
        "id": block_id,
        "name": b.name,
        "input": b.input,
    }
    return b


def _text_block(text: str = "hi") -> SimpleNamespace:
    b = SimpleNamespace(type="text", text=text)
    b.model_dump = lambda: {"type": "text", "text": text}
    return b


def _message(content: list, stop_reason: str = "tool_use"):
    return SimpleNamespace(
        id="msg_test",
        content=content,
        usage=SimpleNamespace(input_tokens=10, output_tokens=5),
        stop_reason=stop_reason,
    )


class TestBuildToolUseRefs:
    def test_extracts_tool_use_blocks_only(self):
        text = _text_block()
        tool = _tool_use_block(name="run", input_={"x": 1})
        refs = _build_tool_use_refs(
            [text, tool], [text.model_dump(), tool.model_dump()]
        )
        # Text blocks are skipped; only the tool_use at original index 1 is kept
        assert len(refs) == 1
        assert refs[0]["name"] == "run"
        assert refs[0]["input"] == {"x": 1}
        assert refs[0]["ref"] is tool

    def test_non_dict_input_wrapped(self):
        # Simulate the server returning a non-dict input (unusual but possible)
        tool = _tool_use_block(name="x", input_={"y": 1})
        dumped = tool.model_dump()
        dumped["input"] = "not-a-dict"
        refs = _build_tool_use_refs([tool], [dumped])
        assert refs[0]["input"] == {"value": "not-a-dict"}

    def test_ref_none_when_live_block_type_mismatch(self):
        wrong_live = SimpleNamespace(type="text", text="x")
        dumped = [{"type": "tool_use", "name": "r", "input": {}}]
        refs = _build_tool_use_refs([wrong_live], dumped)
        assert refs[0]["ref"] is None


class TestApplyAnthropicModify:
    def test_mutates_input_in_place(self):
        b = _tool_use_block(input_={"cmd": "rm -rf /"})
        _apply_anthropic_modify(b, {"cmd": "ls"})
        assert b.input == {"cmd": "ls"}

    def test_none_ref_is_noop(self):
        _apply_anthropic_modify(None, {"x": 1})


class TestSyncGuardEnforcement:
    def test_block_raises_guard_blocked(self, capturing):
        tool = _tool_use_block(name="delete", input_={"path": "/etc/passwd"})

        class FakeMessages:
            def create(self, *args, **kwargs):
                return _message([tool])

        _wrap_sync(FakeMessages)

        with patch(
            "staso.integrations._guard_common.try_guard",
            return_value=GuardResult(action="block", reason="too dangerous"),
        ):
            with pytest.raises(GuardBlocked) as exc_info:
                FakeMessages().create(model="claude-test")

        assert exc_info.value.tool_name == "delete"
        assert capturing[0]["status"] == "error"

    def test_modify_mutates_tool_use_input(self, capturing):
        tool = _tool_use_block(name="bash", input_={"cmd": "rm -rf /"})

        class FakeMessages:
            def create(self, *args, **kwargs):
                return _message([tool])

        _wrap_sync(FakeMessages)

        with patch(
            "staso.integrations._guard_common.try_guard",
            return_value=GuardResult(
                action="modify", modified_input={"cmd": "ls"}
            ),
        ):
            response = FakeMessages().create(model="claude-test")

        returned_tool = response.content[0]
        assert returned_tool.input == {"cmd": "ls"}

    def test_allow_is_transparent(self, capturing):
        tool = _tool_use_block()

        class FakeMessages:
            def create(self, *args, **kwargs):
                return _message([tool])

        _wrap_sync(FakeMessages)
        with patch(
            "staso.integrations._guard_common.try_guard",
            return_value=GuardResult(action="allow"),
        ):
            FakeMessages().create(model="claude-test")

        assert capturing[0]["status"] == "ok"

    def test_no_tool_use_skips_guard(self, capturing):
        class FakeMessages:
            def create(self, *args, **kwargs):
                return _message([_text_block("hello")], stop_reason="end_turn")

        _wrap_sync(FakeMessages)

        with patch(
            "staso.integrations._guard_common.try_guard"
        ) as mock_try:
            FakeMessages().create(model="claude-test")

        mock_try.assert_not_called()

    def test_env_disable_skips_guard(self, capturing, monkeypatch):
        monkeypatch.setenv("STASO_GUARD_ENABLED", "false")
        tool = _tool_use_block()

        class FakeMessages:
            def create(self, *args, **kwargs):
                return _message([tool])

        _wrap_sync(FakeMessages)

        with patch(
            "staso.integrations._guard_common.try_guard"
        ) as mock_try:
            FakeMessages().create(model="claude-test")

        mock_try.assert_not_called()

    def test_audit_mode_emits_would_block_span(self, capturing):
        tool = _tool_use_block(name="read_secret")

        class FakeMessages:
            def create(self, *args, **kwargs):
                return _message([tool])

        _wrap_sync(FakeMessages)

        audit = GuardRuleResult(
            rule_name="secret_scan",
            passed=False,
            action="audit",
            reason="sensitive path",
        )
        with patch(
            "staso.integrations._guard_common.try_guard",
            return_value=GuardResult(action="allow", results=[audit]),
        ):
            FakeMessages().create(model="claude-test")

        names = [s["name"] for s in capturing]
        assert any(n.startswith("guard:would-block:") for n in names)


class TestAsyncGuardEnforcement:
    def test_async_block_raises(self, capturing):
        tool = _tool_use_block(name="danger")

        class FakeAsyncMessages:
            async def create(self, *args, **kwargs):
                return _message([tool])

        _wrap_async(FakeAsyncMessages)

        async def run():
            with patch(
                "staso.integrations._guard_common.try_guard",
                return_value=GuardResult(action="block", reason="nope"),
            ):
                with pytest.raises(GuardBlocked):
                    await FakeAsyncMessages().create(model="claude-test")

        asyncio.run(run())
        assert capturing[0]["status"] == "error"

    def test_async_modify_rewrites_input(self, capturing):
        tool = _tool_use_block(name="bash", input_={"cmd": "curl evil"})

        class FakeAsyncMessages:
            async def create(self, *args, **kwargs):
                return _message([tool])

        _wrap_async(FakeAsyncMessages)

        async def run():
            with patch(
                "staso.integrations._guard_common.try_guard",
                return_value=GuardResult(
                    action="modify", modified_input={"cmd": "echo safe"}
                ),
            ):
                response = await FakeAsyncMessages().create(model="claude-test")
            return response

        response = asyncio.run(run())
        assert response.content[0].input == {"cmd": "echo safe"}


@pytest.mark.skip(
    reason="End-to-end guard enforcement against live Anthropic API — comprehensive but not for CI"
)
class TestLiveAnthropicGuardE2E:
    def test_live_anthropic_guard_block_end_to_end(self):  # pragma: no cover
        raise NotImplementedError
