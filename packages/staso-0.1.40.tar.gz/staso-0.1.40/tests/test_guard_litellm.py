"""Unit tests for the LiteLLM drop-in integration.

Covers helper functions, wrapper idempotency, patch_litellm idempotency,
span capture, and guard enforcement (block / modify / allow / audit).
All LiteLLM calls are faked — we never hit the real API.
"""
from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from staso.guard import GuardBlocked
from staso.guard_types import GuardResult, GuardRuleResult
from staso.integrations.litellm import (
    _apply_litellm_modify,
    _capture_metadata,
    _derive_child_label,
    _derive_root_label,
    _extract_tool_results,
    _infer_provider,
    _wrap_async,
    _wrap_sync,
)


# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture(autouse=True)
def _reset_patch_flag():
    import staso.integrations.litellm as mod

    original = mod._patched
    mod._patched = False
    yield
    mod._patched = original


@pytest.fixture(autouse=True)
def _guard_enabled(monkeypatch):
    monkeypatch.delenv("STASO_GUARD_ENABLED", raising=False)
    yield


# ── Response builders ──────────────────────────────────────────────────────────


def _tool_call(
    name: str = "get_weather",
    arguments: str = '{"city":"SF"}',
    call_id: str = "call_1",
) -> SimpleNamespace:
    tc = SimpleNamespace(
        id=call_id,
        type="function",
        function=SimpleNamespace(name=name, arguments=arguments),
    )
    tc.model_dump = lambda: {
        "id": call_id,
        "type": "function",
        "function": {"name": name, "arguments": arguments},
    }
    return tc


def _completion(
    tool_calls: list | None = None,
    content: str = "Hello",
    finish_reason: str | None = None,
) -> SimpleNamespace:
    if finish_reason is None:
        finish_reason = "tool_calls" if tool_calls else "stop"
    return SimpleNamespace(
        id="chatcmpl-test",
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(
                    content=content,
                    role="assistant",
                    tool_calls=tool_calls,
                ),
                finish_reason=finish_reason,
            )
        ],
        usage=SimpleNamespace(
            prompt_tokens=10,
            completion_tokens=5,
            total_tokens=15,
            completion_tokens_details=None,
        ),
        model="gpt-4",
    )


def _msgs(text: str = "go") -> list[dict]:
    return [{"role": "user", "content": text}]


# ── _infer_provider ────────────────────────────────────────────────────────────


class TestInferProvider:
    def test_slash_prefix_anthropic(self):
        assert _infer_provider("anthropic/claude-3-haiku") == "anthropic"

    def test_slash_prefix_openai(self):
        assert _infer_provider("openai/gpt-4o") == "openai"

    def test_slash_prefix_google(self):
        assert _infer_provider("google/gemini-pro") == "google"

    def test_bare_claude(self):
        assert _infer_provider("claude-3-haiku-20240307") == "anthropic"

    def test_bare_gpt(self):
        assert _infer_provider("gpt-4o-mini") == "openai"

    def test_bare_o_series(self):
        for m in ("o1-mini", "o3", "o4-mini"):
            assert _infer_provider(m) == "openai"

    def test_bare_gemini(self):
        assert _infer_provider("gemini-pro") == "google"

    def test_unknown_falls_back(self):
        assert _infer_provider("some-exotic-model-7b") == "litellm"


# ── _extract_tool_results ──────────────────────────────────────────────────────


class TestExtractToolResults:
    def test_empty_list(self):
        assert _extract_tool_results([]) == []

    def test_non_list(self):
        assert _extract_tool_results("not a list") == []  # type: ignore[arg-type]

    def test_no_tool_messages(self):
        msgs = [{"role": "user", "content": "hi"}, {"role": "assistant", "content": "hi"}]
        assert _extract_tool_results(msgs) == []

    def test_single_tail_tool_message(self):
        msgs = [
            {"role": "user", "content": "go"},
            {"role": "assistant", "content": None},
            {"role": "tool", "tool_call_id": "c1", "content": "done"},
        ]
        assert _extract_tool_results(msgs) == [("c1", "done")]

    def test_multiple_tail_tool_messages(self):
        msgs = [
            {"role": "tool", "tool_call_id": "c1", "content": "r1"},
            {"role": "tool", "tool_call_id": "c2", "content": "r2"},
        ]
        result = _extract_tool_results(msgs)
        assert result == [("c1", "r1"), ("c2", "r2")]

    def test_stops_before_non_tool_message(self):
        msgs = [
            {"role": "tool", "tool_call_id": "c1", "content": "r1"},
            {"role": "assistant", "content": "mid"},
            {"role": "tool", "tool_call_id": "c2", "content": "r2"},
        ]
        result = _extract_tool_results(msgs)
        assert result == [("c2", "r2")]


# ── _derive_root_label ────────────────────────────────────────────────────────


class TestDeriveRootLabel:
    def test_plain_text(self):
        msgs = [{"role": "user", "content": "What is the capital of France?"}]
        assert _derive_root_label(msgs, "gpt-4") == "What is the capital of France?"

    def test_truncated_at_60(self):
        msgs = [{"role": "user", "content": "x" * 80}]
        assert len(_derive_root_label(msgs, "gpt-4")) == 60

    def test_markdown_heading_stripped(self):
        msgs = [{"role": "user", "content": "# My Task\nDo something"}]
        assert _derive_root_label(msgs, "gpt-4") == "My Task"

    def test_no_user_message_uses_model(self):
        msgs = [{"role": "system", "content": "you are an assistant"}]
        assert _derive_root_label(msgs, "gpt-4") == "chat: gpt-4"

    def test_empty_messages_uses_model(self):
        assert _derive_root_label([], "gpt-4") == "chat: gpt-4"

    def test_multipart_content(self):
        msgs = [{"role": "user", "content": [{"type": "text", "text": "Hello world"}]}]
        assert _derive_root_label(msgs, "gpt-4") == "Hello world"


# ── _derive_child_label ───────────────────────────────────────────────────────


class TestDeriveChildLabel:
    def test_stop_gives_chat_reply(self):
        resp = _completion(content="Paris", finish_reason="stop")
        assert _derive_child_label(resp) == "chat:reply"

    def test_length_gives_chat_reply(self):
        resp = _completion(content="...", finish_reason="length")
        assert _derive_child_label(resp) == "chat:reply"

    def test_single_tool_call(self):
        tc = _tool_call("get_weather")
        resp = _completion(tool_calls=[tc], finish_reason="tool_calls")
        assert _derive_child_label(resp) == "chat:tool_calls(get_weather)"

    def test_multiple_tool_calls_ellipsis(self):
        tcs = [_tool_call(f"tool_{i}", call_id=f"c{i}") for i in range(4)]
        resp = _completion(tool_calls=tcs, finish_reason="tool_calls")
        label = _derive_child_label(resp)
        assert "…+1" in label

    def test_unknown_finish_reason(self):
        resp = _completion(finish_reason="custom_thing")
        assert _derive_child_label(resp) == "chat:custom_thing"


# ── _apply_litellm_modify ─────────────────────────────────────────────────────


class TestApplyLitellmModify:
    def test_mutates_function_arguments_in_place(self):
        tc = _tool_call(arguments='{"cmd":"rm -rf /"}')
        _apply_litellm_modify(tc, {"cmd": "ls"})
        assert json.loads(tc.function.arguments) == {"cmd": "ls"}

    def test_none_ref_is_noop(self):
        _apply_litellm_modify(None, {"cmd": "ls"})  # must not raise

    def test_bad_ref_without_function_is_silent(self):
        _apply_litellm_modify(SimpleNamespace(), {"cmd": "ls"})  # must not raise


# ── _capture_metadata: extra_body + api_base ──────────────────────────────────


class TestCaptureMetadata:
    def test_extra_body_captured_as_is(self):
        extra = {"reasoning": {"effort": "high"}, "safety": "strict"}
        meta = _capture_metadata("openai/gpt-4o", {"extra_body": extra})
        assert meta["extra_body"] == extra

    def test_api_base_captured(self):
        meta = _capture_metadata(
            "openai/gpt-4o",
            {"api_base": "https://proxy.example.com/v1"},
        )
        assert meta["api_base"] == "https://proxy.example.com/v1"

    def test_missing_kwargs_not_set(self):
        meta = _capture_metadata("openai/gpt-4o", {})
        assert "extra_body" not in meta
        assert "api_base" not in meta

    def test_extra_headers_not_captured(self):
        """Auth tokens routinely flow through extra_headers; capturing them
        verbatim would leak credentials into the trace. Until a header-
        allowlist pass is added, the integration must stay silent on them."""
        meta = _capture_metadata(
            "openai/gpt-4o",
            {
                "extra_headers": {
                    "Authorization": "Bearer sk-live-abc123",
                    "x-api-key": "super-secret",
                }
            },
        )
        assert "extra_headers" not in meta
        assert "Authorization" not in json.dumps(meta)
        assert "sk-live-abc123" not in json.dumps(meta)


# ── Wrapper idempotency ───────────────────────────────────────────────────────


class TestWrapIdempotency:
    def test_wrap_sync_does_not_double_wrap(self):
        def fake(*args, **kwargs):
            return _completion()

        once = _wrap_sync(fake)
        twice = _wrap_sync(once)
        assert once is twice

    def test_wrap_async_does_not_double_wrap(self):
        async def fake(*args, **kwargs):
            return _completion()

        once = _wrap_async(fake)
        twice = _wrap_async(once)
        assert once is twice


# ── patch_litellm idempotency ─────────────────────────────────────────────────


class TestPatchLitellmIdempotency:
    def test_patch_only_applies_once(self):
        import types

        fake_litellm = types.ModuleType("litellm")
        original_completion = MagicMock(return_value=_completion())
        original_acompletion = MagicMock()
        fake_litellm.completion = original_completion
        fake_litellm.acompletion = original_acompletion

        with patch.dict("sys.modules", {"litellm": fake_litellm}):
            from staso.integrations.litellm import patch_litellm

            patch_litellm()
            first_completion = fake_litellm.completion

            patch_litellm()
            assert fake_litellm.completion is first_completion


# ── Sync guard enforcement ────────────────────────────────────────────────────


class TestSyncGuardEnforcement:
    def test_block_raises_guard_blocked(self, capturing):
        tc = _tool_call(name="delete_file")

        def fake(*args, **kwargs):
            return _completion(tool_calls=[tc], finish_reason="tool_calls")

        wrapped = _wrap_sync(fake)

        with patch(
            "staso.integrations._guard_common.try_guard",
            return_value=GuardResult(action="block", reason="destructive"),
        ):
            with pytest.raises(GuardBlocked) as exc_info:
                wrapped(model="gpt-4", messages=_msgs("delete it"))

        assert exc_info.value.tool_name == "delete_file"
        assert capturing[0]["status"] == "error"

    def test_modify_rewrites_tool_arguments(self, capturing):
        tc = _tool_call(name="bash", arguments='{"cmd":"rm -rf /"}')

        def fake(*args, **kwargs):
            return _completion(tool_calls=[tc], finish_reason="tool_calls")

        wrapped = _wrap_sync(fake)

        with patch(
            "staso.integrations._guard_common.try_guard",
            return_value=GuardResult(action="modify", modified_input={"cmd": "ls"}),
        ):
            response = wrapped(model="gpt-4", messages=_msgs("run it"))

        returned_tc = response.choices[0].message.tool_calls[0]
        assert json.loads(returned_tc.function.arguments) == {"cmd": "ls"}

    def test_allow_is_transparent(self, capturing):
        tc = _tool_call(name="read_file")

        def fake(*args, **kwargs):
            return _completion(tool_calls=[tc], finish_reason="tool_calls")

        wrapped = _wrap_sync(fake)

        with patch(
            "staso.integrations._guard_common.try_guard",
            return_value=GuardResult(action="allow"),
        ):
            response = wrapped(model="gpt-4", messages=_msgs("read"))

        assert response is not None
        assert capturing[0]["status"] == "ok"

    def test_no_tool_calls_skips_guard(self, capturing):
        def fake(*args, **kwargs):
            return _completion(content="Paris", finish_reason="stop")

        wrapped = _wrap_sync(fake)

        with patch("staso.integrations._guard_common.try_guard") as mock_try:
            wrapped(model="gpt-4", messages=_msgs("capital?"))

        mock_try.assert_not_called()

    def test_malformed_tool_calls_skip_guard_and_registration(self, capturing):
        """A response whose tool_call lacks an ``id`` / ``name`` must be dropped
        by BOTH the guard-eval path and the tool-loop registration path. If one
        fires and the other doesn't, the next turn's stitching diverges."""
        good = _tool_call(name="search", call_id="good_1")
        missing_name = _tool_call(name="", call_id="bad_1")
        missing_id = _tool_call(name="drop", call_id="")

        def fake(*args, **kwargs):
            return _completion(
                tool_calls=[good, missing_name, missing_id],
                finish_reason="tool_calls",
            )

        wrapped = _wrap_sync(fake)

        with patch(
            "staso.integrations._guard_common.try_guard",
            return_value=GuardResult(action="allow"),
        ) as mock_try:
            wrapped(model="gpt-4", messages=_msgs("go"))

        invoked_names = [call.args[0] for call in mock_try.call_args_list]
        assert invoked_names == ["search"], (
            f"guard should only see well-formed tool calls, got: {invoked_names}"
        )

    def test_guard_env_disable_skips_evaluation(self, capturing, monkeypatch):
        monkeypatch.setenv("STASO_GUARD_ENABLED", "false")
        tc = _tool_call(name="x")

        def fake(*args, **kwargs):
            return _completion(tool_calls=[tc], finish_reason="tool_calls")

        wrapped = _wrap_sync(fake)

        with patch("staso.integrations._guard_common.try_guard") as mock_try:
            wrapped(model="gpt-4", messages=_msgs("go"))

        mock_try.assert_not_called()

    def test_audit_emits_would_block_child_span(self, capturing):
        tc = _tool_call(name="read_secret")

        def fake(*args, **kwargs):
            return _completion(tool_calls=[tc], finish_reason="tool_calls")

        wrapped = _wrap_sync(fake)

        audit = GuardRuleResult(
            rule_name="pii_audit",
            passed=False,
            action="audit",
            reason="PII access",
        )
        with patch(
            "staso.integrations._guard_common.try_guard",
            return_value=GuardResult(action="allow", results=[audit]),
        ):
            wrapped(model="gpt-4", messages=_msgs("read secret"))

        child_names = [s["name"] for s in capturing]
        assert any(n.startswith("guard:would-block:") for n in child_names)


# ── Async guard enforcement ───────────────────────────────────────────────────


class TestAsyncGuardEnforcement:
    def test_block_raises_guard_blocked_async(self, capturing):
        tc = _tool_call(name="drop_table")

        async def fake(*args, **kwargs):
            return _completion(tool_calls=[tc], finish_reason="tool_calls")

        wrapped = _wrap_async(fake)

        with patch(
            "staso.integrations._guard_common.try_guard",
            return_value=GuardResult(action="block", reason="data loss"),
        ):
            with pytest.raises(GuardBlocked) as exc_info:
                asyncio.run(wrapped(model="gpt-4", messages=_msgs("drop")))

        assert exc_info.value.tool_name == "drop_table"
        assert capturing[0]["status"] == "error"

    def test_modify_rewrites_arguments_async(self, capturing):
        tc = _tool_call(name="bash", arguments='{"cmd":"cat /etc/passwd"}')

        async def fake(*args, **kwargs):
            return _completion(tool_calls=[tc], finish_reason="tool_calls")

        wrapped = _wrap_async(fake)

        with patch(
            "staso.integrations._guard_common.try_guard",
            return_value=GuardResult(action="modify", modified_input={"cmd": "echo ok"}),
        ):
            response = asyncio.run(wrapped(model="gpt-4", messages=_msgs("cat")))

        returned_tc = response.choices[0].message.tool_calls[0]
        assert json.loads(returned_tc.function.arguments) == {"cmd": "echo ok"}

    def test_allow_is_transparent_async(self, capturing):
        async def fake(*args, **kwargs):
            return _completion(content="Paris", finish_reason="stop")

        wrapped = _wrap_async(fake)

        with patch(
            "staso.integrations._guard_common.try_guard",
            return_value=GuardResult(action="allow"),
        ):
            response = asyncio.run(wrapped(model="gpt-4", messages=_msgs("capital?")))

        assert response is not None

    def test_no_tool_calls_skips_guard_async(self, capturing):
        async def fake(*args, **kwargs):
            return _completion(content="42", finish_reason="stop")

        wrapped = _wrap_async(fake)

        with patch("staso.integrations._guard_common.try_guard") as mock_try:
            asyncio.run(wrapped(model="gpt-4", messages=_msgs("math")))

        mock_try.assert_not_called()


# ── Span capture ──────────────────────────────────────────────────────────────


class TestSpanCapture:
    def test_sync_stop_span_name_and_kind(self, capturing):
        def fake(*args, **kwargs):
            return _completion(content="Paris", finish_reason="stop")

        wrapped = _wrap_sync(fake)
        wrapped(model="gpt-4", messages=_msgs("capital?"))

        span = capturing[0]
        assert span["name"] == "chat:reply"
        assert span["kind"] == "llm"
        assert span["status"] == "ok"

    def test_sync_tool_calls_span_name(self, capturing):
        tc = _tool_call(name="search")

        def fake(*args, **kwargs):
            return _completion(tool_calls=[tc], finish_reason="tool_calls")

        wrapped = _wrap_sync(fake)

        with patch(
            "staso.integrations._guard_common.try_guard",
            return_value=GuardResult(action="allow"),
        ):
            wrapped(model="gpt-4", messages=_msgs("search it"))

        assert capturing[0]["name"] == "chat:tool_calls(search)"

    def test_async_span_kind_and_status(self, capturing):
        async def fake(*args, **kwargs):
            return _completion(content="hi", finish_reason="stop")

        wrapped = _wrap_async(fake)
        asyncio.run(wrapped(model="anthropic/claude-3-haiku", messages=_msgs("hi")))

        span = capturing[0]
        assert span["kind"] == "llm"
        assert span["status"] == "ok"

    def test_exception_marks_span_error(self, capturing):
        def fake(*args, **kwargs):
            raise RuntimeError("API down")

        wrapped = _wrap_sync(fake)

        with pytest.raises(RuntimeError, match="API down"):
            wrapped(model="gpt-4", messages=_msgs("hi"))

        span = capturing[0]
        assert span["status"] == "error"
        assert "API down" in span.get("error_message", "")

    def test_token_counts_captured(self, capturing):
        def fake(*args, **kwargs):
            return _completion(content="done", finish_reason="stop")

        wrapped = _wrap_sync(fake)
        wrapped(model="gpt-4", messages=_msgs("go"))

        span = capturing[0]
        assert span["input_tokens"] == 10
        assert span["output_tokens"] == 5
        assert span["total_tokens"] == 15

    def test_stream_true_bypasses_instrumentation(self, capturing):
        sentinel = object()

        def fake(*args, **kwargs):
            return sentinel

        wrapped = _wrap_sync(fake)

        with patch("staso.integrations._guard_common.try_guard") as mock_try:
            result = wrapped(model="gpt-4", messages=_msgs("stream"), stream=True)

        assert result is sentinel
        assert capturing == []
        mock_try.assert_not_called()

    def test_stream_true_async_bypasses_instrumentation(self, capturing):
        sentinel = object()

        async def fake(*args, **kwargs):
            return sentinel

        wrapped = _wrap_async(fake)

        with patch("staso.integrations._guard_common.try_guard") as mock_try:
            result = asyncio.run(wrapped(model="gpt-4", messages=_msgs("stream"), stream=True))

        assert result is sentinel
        assert capturing == []
        mock_try.assert_not_called()
