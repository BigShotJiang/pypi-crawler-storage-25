"""Tests for staso.integrations.openai."""
from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace
from unittest.mock import patch

import pytest


@pytest.fixture(autouse=True)
def _reset_patch_flag():
    """Reset the _patched flag between tests."""
    import staso.integrations.openai as mod

    original = mod._patched
    mod._patched = False
    yield
    mod._patched = original


def _fake_completion(
    content="Hello!",
    model="gpt-4",
    prompt_tokens=10,
    completion_tokens=20,
    finish_reason="stop",
    tool_calls=None,
):
    """Build a fake ChatCompletion response."""
    return SimpleNamespace(
        id="chatcmpl-test",
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(
                    content=content,
                    role="assistant",
                    tool_calls=tool_calls,
                ),
                finish_reason=finish_reason,
            )
        ],
        usage=SimpleNamespace(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=prompt_tokens + completion_tokens,
            completion_tokens_details=None,
        ),
        model=model,
    )


class TestPatchOpenAI:
    def test_raises_without_openai_installed(self):
        with patch.dict(
            "sys.modules",
            {
                "openai": None,
                "openai.resources": None,
                "openai.resources.chat": None,
            },
        ):
            import staso.integrations.openai as mod

            mod._patched = False
            with pytest.raises(ImportError, match="openai package is required"):
                mod.patch_openai()

    def test_idempotent(self):
        import staso.integrations.openai as mod

        mod._patched = True
        mod.patch_openai()  # Should be a no-op


class TestSyncWrapper:
    def test_emits_span(self, capturing):
        class FakeCompletions:
            def create(self, *args, **kwargs):
                return _fake_completion()

        from staso.integrations.openai import _wrap_sync

        _wrap_sync(FakeCompletions)
        result = FakeCompletions().create(model="gpt-4", max_tokens=1024)

        assert result.usage.prompt_tokens == 10
        # Agent-run stays open across calls — only the LLM span is in
        # ``capturing`` until we explicitly close the run.
        assert len(capturing) == 1
        assert capturing[0]["kind"] == "llm"
        from staso.integrations._tool_loop_state import force_close_agent_run

        force_close_agent_run()
        assert len(capturing) == 2
        llm_spans = [s for s in capturing if s["kind"] == "llm"]
        agent_spans = [s for s in capturing if s["kind"] == "agent"]
        assert len(llm_spans) == 1 and len(agent_spans) == 1

        span = llm_spans[0]
        # finish_reason="stop" -> "chat:reply" child label
        assert span["name"] == "chat:reply"
        assert span["model"] == "gpt-4"
        assert span["input_tokens"] == 10
        assert span["output_tokens"] == 20
        assert span["total_tokens"] == 30
        assert span["status"] == "ok"

    def test_captures_error(self, capturing):
        class FakeCompletions:
            def create(self, *args, **kwargs):
                raise ConnectionError("API down")

        from staso.integrations.openai import _wrap_sync

        _wrap_sync(FakeCompletions)

        with pytest.raises(ConnectionError, match="API down"):
            FakeCompletions().create(model="gpt-4")

        assert capturing[0]["status"] == "error"
        assert capturing[0]["error_message"] == "API down"

    def test_captures_input_and_metadata(self, capturing):
        class FakeCompletions:
            def create(self, *args, **kwargs):
                return _fake_completion()

        from staso.integrations.openai import _wrap_sync

        _wrap_sync(FakeCompletions)
        FakeCompletions().create(
            model="gpt-4",
            max_tokens=512,
            temperature=0.7,
        )

        input_val = json.loads(capturing[0]["input"])
        assert input_val["model"] == "gpt-4"

        attrs = json.loads(capturing[0]["attributes"])
        assert attrs["max_tokens"] == 512
        assert attrs["temperature"] == 0.7
        assert attrs["provider"] == "openai"

    def test_captures_tool_calls(self, capturing):
        tool_call = SimpleNamespace(
            id="call_123",
            type="function",
            function=SimpleNamespace(name="get_weather", arguments='{"city":"SF"}'),
        )
        tool_call.model_dump = lambda: {
            "id": "call_123",
            "type": "function",
            "function": {"name": "get_weather", "arguments": '{"city":"SF"}'},
        }

        class FakeCompletions:
            def create(self, *args, **kwargs):
                return _fake_completion(
                    content=None,
                    tool_calls=[tool_call],
                    finish_reason="tool_calls",
                )

        from staso.integrations.openai import _wrap_sync

        _wrap_sync(FakeCompletions)
        FakeCompletions().create(model="gpt-4")

        output = json.loads(capturing[0]["output"])
        assert "tool_calls" in output
        assert output["tool_calls"][0]["id"] == "call_123"

    def test_captures_output_content(self, capturing):
        class FakeCompletions:
            def create(self, *args, **kwargs):
                return _fake_completion(content="Hello world!")

        from staso.integrations.openai import _wrap_sync

        _wrap_sync(FakeCompletions)
        FakeCompletions().create(model="gpt-4")

        output = json.loads(capturing[0]["output"])
        assert output["content"] == "Hello world!"
        assert output["role"] == "assistant"

    def test_captures_stop_reason(self, capturing):
        class FakeCompletions:
            def create(self, *args, **kwargs):
                return _fake_completion(finish_reason="length")

        from staso.integrations.openai import _wrap_sync

        _wrap_sync(FakeCompletions)
        FakeCompletions().create(model="gpt-4")

        attrs = json.loads(capturing[0]["attributes"])
        assert attrs["stop_reason"] == "length"


class TestAsyncWrapper:
    def test_emits_span(self, capturing):
        class FakeAsyncCompletions:
            async def create(self, *args, **kwargs):
                return _fake_completion(
                    model="gpt-4-turbo", prompt_tokens=200, completion_tokens=75
                )

        from staso.integrations._tool_loop_state import force_close_agent_run
        from staso.integrations.openai import _wrap_async

        _wrap_async(FakeAsyncCompletions)

        # OpenAI keeps the agent-run open across calls, so close it
        # from inside the coroutine context — ContextVars set in a
        # coroutine are gone once ``asyncio.run`` returns, so a
        # ``force_close_agent_run()`` from the outer sync frame would
        # miss the active run.
        async def _run():
            result = await FakeAsyncCompletions().create(model="gpt-4-turbo")
            force_close_agent_run()
            return result

        result = asyncio.run(_run())

        assert result.usage.prompt_tokens == 200
        assert len(capturing) == 2  # LLM + synthetic agent-run root
        llm_spans = [s for s in capturing if s["kind"] == "llm"]
        assert len(llm_spans) == 1

        span = llm_spans[0]
        assert span["model"] == "gpt-4-turbo"
        assert span["input_tokens"] == 200
        assert span["output_tokens"] == 75
        assert span["total_tokens"] == 275

    def test_captures_error(self, capturing):
        class FakeAsyncCompletions:
            async def create(self, *args, **kwargs):
                raise ConnectionError("async fail")

        from staso.integrations.openai import _wrap_async

        _wrap_async(FakeAsyncCompletions)

        with pytest.raises(ConnectionError, match="async fail"):
            asyncio.run(FakeAsyncCompletions().create(model="gpt-4"))

        assert capturing[0]["status"] == "error"


class TestAgentRunTraceCohesion:
    """Regression guards for the inbox-triage bug: multiple sequential
    LLM calls in one process must land under ONE trace, and the
    synthetic agent-run root must stay open for the live-tracing
    window until shutdown."""

    def test_sequential_create_calls_share_trace(self, capturing):
        class FakeCompletions:
            def create(self, *args, **kwargs):
                return _fake_completion()

        from staso.integrations.openai import _wrap_sync

        _wrap_sync(FakeCompletions)
        FakeCompletions().create(
            model="gpt-4",
            messages=[{"role": "user", "content": "first"}],
        )
        FakeCompletions().create(
            model="gpt-4",
            messages=[{"role": "user", "content": "second"}],
        )
        FakeCompletions().create(
            model="gpt-4",
            messages=[{"role": "user", "content": "third"}],
        )

        # Three calls completed, three LLM spans captured, agent-run
        # still open (not yet captured).
        assert len(capturing) == 3
        assert all(s["kind"] == "llm" for s in capturing)
        # All three must share ONE trace_id — the agent-run's.
        trace_ids = {s["trace_id"] for s in capturing}
        assert len(trace_ids) == 1, f"expected 1 trace, got {trace_ids}"

        # Closing the agent-run emits the root; all four spans share
        # the same trace_id.
        from staso.integrations._tool_loop_state import force_close_agent_run

        force_close_agent_run()
        assert len(capturing) == 4
        assert {s["trace_id"] for s in capturing} == trace_ids
        agents = [s for s in capturing if s["kind"] == "agent"]
        assert len(agents) == 1
        # Every LLM span parents under the agent-run.
        agent_span_id = agents[0]["span_id"]
        llms = [s for s in capturing if s["kind"] == "llm"]
        assert all(s["parent_span_id"] == agent_span_id for s in llms)

    def test_sequential_parse_calls_share_trace(self, capturing):
        """Same guarantee as the create() case but for structured-output
        parse() calls — the inbox-triage bug was here."""
        class FakeCompletions:
            def parse(self, *args, **kwargs):
                return _fake_completion(content='{"label":"x"}')

        from staso.integrations.openai import _wrap_sync_parse

        _wrap_sync_parse(FakeCompletions)
        for i in range(3):
            FakeCompletions().parse(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": f"msg {i}"}],
                response_format=Classification,
            )

        assert len(capturing) == 3
        trace_ids = {s["trace_id"] for s in capturing}
        assert len(trace_ids) == 1

    def test_terminal_finish_reason_does_not_close_root(self, capturing):
        """The legacy behaviour closed the agent-run on every
        ``finish_reason=stop``; the new contract keeps it open."""
        class FakeCompletions:
            def create(self, *args, **kwargs):
                return _fake_completion(finish_reason="stop")

        from staso.integrations.openai import _wrap_sync

        _wrap_sync(FakeCompletions)
        FakeCompletions().create(
            model="gpt-4", messages=[{"role": "user", "content": "hi"}]
        )

        # A single call emits only the LLM span — the agent-run is still
        # open. Under the old behaviour we'd have 2 spans here.
        assert len(capturing) == 1
        assert capturing[0]["kind"] == "llm"

    def test_error_closes_root_and_next_call_starts_new_trace(self, capturing):
        """A hard error still closes the agent-run so a retry gets a
        fresh trace instead of getting stitched into the failed one."""
        call_count = {"n": 0}

        class FakeCompletions:
            def create(self, *args, **kwargs):
                call_count["n"] += 1
                if call_count["n"] == 1:
                    raise ConnectionError("boom")
                return _fake_completion()

        from staso.integrations.openai import _wrap_sync

        _wrap_sync(FakeCompletions)
        with pytest.raises(ConnectionError):
            FakeCompletions().create(
                model="gpt-4", messages=[{"role": "user", "content": "hi"}]
            )
        FakeCompletions().create(
            model="gpt-4", messages=[{"role": "user", "content": "retry"}]
        )

        llms = [s for s in capturing if s["kind"] == "llm"]
        agents = [s for s in capturing if s["kind"] == "agent"]
        # The error path closes the first agent-run (so it's already in
        # capturing); the retry opens a fresh one (still open).
        assert len(llms) == 2
        assert len(agents) == 1
        # Two traces: the errored first attempt, the in-flight retry.
        assert len({s["trace_id"] for s in capturing}) == 2

    def test_force_close_is_idempotent(self, capturing):
        """Calling force_close twice must not crash or emit a duplicate."""
        class FakeCompletions:
            def create(self, *args, **kwargs):
                return _fake_completion()

        from staso.integrations.openai import _wrap_sync
        from staso.integrations._tool_loop_state import force_close_agent_run

        _wrap_sync(FakeCompletions)
        FakeCompletions().create(
            model="gpt-4", messages=[{"role": "user", "content": "hi"}]
        )
        force_close_agent_run()
        force_close_agent_run()  # second call is a no-op

        assert len([s for s in capturing if s["kind"] == "agent"]) == 1

    def test_shutdown_closes_agent_run_before_transport_drain(self):
        """client.shutdown() must close the agent-run so the root span
        lands before the transport stops accepting enqueues."""
        captured: list[dict] = []

        from unittest.mock import MagicMock

        import staso as st
        from staso.client import Client, _set_client
        from staso.config import Config
        from staso.provider import TracerProvider

        transport = MagicMock()
        transport.enqueue.side_effect = lambda d: captured.append(d)

        cfg = Config(api_key="test-key", agent_name="test-agent", enabled=False)
        client = Client.__new__(Client)
        client._config = cfg
        client._transport = transport
        client._provider = TracerProvider(
            transport=transport, agent_name="test-agent", enabled=True
        )
        _set_client(client)

        class FakeCompletions:
            def create(self, *args, **kwargs):
                return _fake_completion()

        from staso.integrations.openai import _wrap_sync

        _wrap_sync(FakeCompletions)
        FakeCompletions().create(
            model="gpt-4", messages=[{"role": "user", "content": "hi"}]
        )

        assert len(captured) == 1  # LLM span, agent-run still open
        client.shutdown()
        # After shutdown, agent-run span should have been enqueued.
        assert len(captured) == 2
        agents = [s for s in captured if s["kind"] == "agent"]
        assert len(agents) == 1


class TestExtractModel:
    def test_from_kwargs(self):
        from staso.integrations.openai import _extract_model

        assert _extract_model((), {"model": "gpt-4"}) == "gpt-4"

    def test_from_args(self):
        from staso.integrations.openai import _extract_model

        assert _extract_model(("gpt-4",), {}) == "gpt-4"

    def test_empty(self):
        from staso.integrations.openai import _extract_model

        assert _extract_model((), {}) == ""


class Classification:
    """Pydantic-shaped stand-in. Duck-types for _sanitize_parse_kwargs.
    Class name matters: _sanitize_parse_kwargs reads ``cls.__name__``."""

    @staticmethod
    def model_json_schema():
        return {"type": "object", "properties": {"label": {"type": "string"}}}


class TestSanitizeParseKwargs:
    def test_rewrites_pydantic_class_to_schema(self):
        from staso.integrations.openai import _sanitize_parse_kwargs

        out = _sanitize_parse_kwargs({"response_format": Classification, "temperature": 0})
        rf = out["response_format"]
        assert isinstance(rf, dict)
        assert rf["type"] == "json_schema"
        assert rf["class"] == "Classification"
        assert rf["schema"]["type"] == "object"
        # untouched kwargs pass through
        assert out["temperature"] == 0

    def test_returns_kwargs_unchanged_if_response_format_is_dict(self):
        from staso.integrations.openai import _sanitize_parse_kwargs

        rf = {"type": "json_object"}
        out = _sanitize_parse_kwargs({"response_format": rf})
        assert out["response_format"] is rf

    def test_returns_kwargs_unchanged_if_response_format_missing(self):
        from staso.integrations.openai import _sanitize_parse_kwargs

        out = _sanitize_parse_kwargs({"temperature": 0.5})
        assert "response_format" not in out

    def test_falls_back_to_class_name_if_schema_raises(self):
        from staso.integrations.openai import _sanitize_parse_kwargs

        class Broken:
            __name__ = "Broken"

            @staticmethod
            def model_json_schema():
                raise RuntimeError("no schema")

        out = _sanitize_parse_kwargs({"response_format": Broken})
        assert out["response_format"] == "Broken"

    def test_does_not_mutate_original(self):
        from staso.integrations.openai import _sanitize_parse_kwargs

        original = {"response_format": Classification}
        _sanitize_parse_kwargs(original)
        assert original["response_format"] is Classification


class TestSyncParseWrapper:
    def test_emits_span(self, capturing):
        class FakeCompletions:
            def parse(self, *args, **kwargs):
                return _fake_completion(content='{"label":"x"}')

        from staso.integrations.openai import _wrap_sync_parse

        _wrap_sync_parse(FakeCompletions)
        result = FakeCompletions().parse(
            model="gpt-4o",
            messages=[{"role": "user", "content": "hello"}],
            response_format=Classification,
        )

        assert result.usage.prompt_tokens == 10
        from staso.integrations._tool_loop_state import force_close_agent_run

        force_close_agent_run()
        # LLM span + synthetic agent-run root.
        assert len(capturing) == 2
        llm_spans = [s for s in capturing if s["kind"] == "llm"]
        agent_spans = [s for s in capturing if s["kind"] == "agent"]
        assert len(llm_spans) == 1 and len(agent_spans) == 1

        span = llm_spans[0]
        assert span["name"] == "chat:reply"
        assert span["model"] == "gpt-4o"
        assert span["input_tokens"] == 10
        assert span["output_tokens"] == 20
        assert span["status"] == "ok"

    def test_response_format_captured_as_schema_not_class_repr(self, capturing):
        class FakeCompletions:
            def parse(self, *args, **kwargs):
                return _fake_completion()

        from staso.integrations.openai import _wrap_sync_parse

        _wrap_sync_parse(FakeCompletions)
        FakeCompletions().parse(
            model="gpt-4o",
            messages=[{"role": "user", "content": "hi"}],
            response_format=Classification,
        )

        llm_span = next(s for s in capturing if s["kind"] == "llm")
        attrs = json.loads(llm_span["attributes"])
        rf = attrs["response_format"]
        assert isinstance(rf, dict)
        assert rf["class"] == "Classification"
        assert "schema" in rf

    def test_class_passed_unchanged_to_underlying_parse(self, capturing):
        """Sanitising is for span capture only -- the real call must still
        receive the Pydantic class so OpenAI's helper can build the schema
        and coerce the response."""
        received = {}

        class FakeCompletions:
            def parse(self, *args, **kwargs):
                received.update(kwargs)
                return _fake_completion()

        from staso.integrations.openai import _wrap_sync_parse

        _wrap_sync_parse(FakeCompletions)
        FakeCompletions().parse(
            model="gpt-4o",
            messages=[{"role": "user", "content": "hi"}],
            response_format=Classification,
        )
        assert received["response_format"] is Classification

    def test_captures_error(self, capturing):
        class FakeCompletions:
            def parse(self, *args, **kwargs):
                raise ConnectionError("parse fail")

        from staso.integrations.openai import _wrap_sync_parse

        _wrap_sync_parse(FakeCompletions)
        with pytest.raises(ConnectionError, match="parse fail"):
            FakeCompletions().parse(
                model="gpt-4o",
                messages=[{"role": "user", "content": "hi"}],
                response_format=Classification,
            )
        assert capturing[0]["status"] == "error"
        assert capturing[0]["error_message"] == "parse fail"

    def test_idempotent_wrap(self):
        """Second _wrap_sync_parse on the same class must not double-wrap."""
        class FakeCompletions:
            def parse(self, *args, **kwargs):
                return _fake_completion()

        from staso.integrations.openai import _wrap_sync_parse

        _wrap_sync_parse(FakeCompletions)
        first = FakeCompletions.parse
        _wrap_sync_parse(FakeCompletions)
        assert FakeCompletions.parse is first

    def test_noop_if_parse_missing(self):
        """Some minimal stubs may not expose .parse -- the wrapper must
        silently skip them rather than crashing during patch."""
        class NoParse:
            pass

        from staso.integrations.openai import _wrap_sync_parse

        _wrap_sync_parse(NoParse)  # must not raise


class TestAsyncParseWrapper:
    def test_emits_span(self, capturing):
        class FakeAsyncCompletions:
            async def parse(self, *args, **kwargs):
                return _fake_completion(model="gpt-4o", prompt_tokens=50, completion_tokens=5)

        from staso.integrations.openai import _wrap_async_parse

        _wrap_async_parse(FakeAsyncCompletions)
        result = asyncio.run(
            FakeAsyncCompletions().parse(
                model="gpt-4o",
                messages=[{"role": "user", "content": "hi"}],
                response_format=Classification,
            )
        )

        assert result.usage.prompt_tokens == 50
        llm_spans = [s for s in capturing if s["kind"] == "llm"]
        assert len(llm_spans) == 1
        assert llm_spans[0]["model"] == "gpt-4o"
        assert llm_spans[0]["input_tokens"] == 50

    def test_captures_error(self, capturing):
        class FakeAsyncCompletions:
            async def parse(self, *args, **kwargs):
                raise ConnectionError("async parse fail")

        from staso.integrations.openai import _wrap_async_parse

        _wrap_async_parse(FakeAsyncCompletions)
        with pytest.raises(ConnectionError, match="async parse fail"):
            asyncio.run(
                FakeAsyncCompletions().parse(
                    model="gpt-4o",
                    messages=[{"role": "user", "content": "hi"}],
                    response_format=Classification,
                )
            )
        assert capturing[0]["status"] == "error"


