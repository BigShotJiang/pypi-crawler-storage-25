# Staso Python SDK

Observe, guard, and control your AI agents. Every tool call, LLM interaction, token count, latency, and error -- on your [Staso dashboard](https://staso.ai). Guard agent actions before they execute -- block dangerous operations, modify risky inputs, escalate to humans.

```bash
pip install staso
```

```python
import staso as st
from staso import guard

st.init(api_key="ak_...", agent_name="my-agent")

@st.agent(name="support-agent")
def handle_request(message: str) -> str:
    context = search_kb(message)
    return call_llm(context, message)

@st.tool(name="search_kb")
def search_kb(query: str) -> str:
    return db.search(query)

@st.tool(name="process_refund")
def process_refund(customer_id: str, amount: float) -> str:
    result = guard(tool_name="process_refund", tool_input={"amount": amount})
    if result.action == "block":
        return f"Blocked: {result.reason}"
    return do_refund(customer_id, amount)

with st.conversation("conversation-123"):
    handle_request("How do I reset my password?")

st.shutdown()
```

Open your dashboard. Full execution tree -- agents, tools, LLM calls, tokens, timing, errors. Guard evaluations on every tool call.

## Auto-Instrument LLM Calls

```bash
pip install "staso[anthropic]"  # or "staso[openai]" or "staso[all]"
```

```python
st.integrations.patch_anthropic()
# every Anthropic SDK call is now traced automatically -- tokens, model, latency, errors

st.integrations.patch_openai()
# every OpenAI SDK call is now traced automatically
```

Both sync and async clients. Streaming fully supported.

## Guard Agent Actions

Evaluate tool calls before they execute. Four actions: allow, block, modify, escalate.

```python
from staso import guard

result = guard(tool_name="delete_records", tool_input={"table": "users"})
if result.action == "block":
    raise PermissionError(result.reason)
```

Guards run automatically in Claude Code and Codex sessions -- blocking dangerous tools and modifying risky inputs in real-time. For LLM SDK integrations (Anthropic, OpenAI), guard evaluations are recorded on span metadata.

## CLI Agent Integrations

Trace Claude Code (39 tool types) and Codex (32 tool types) sessions automatically. Every tool call renders as a human-readable card on your dashboard -- diffs, terminal output, agent trees, plan steps. Not raw JSON. Guards evaluate each tool before execution.

Run the interactive wizard:

```bash
staso setup
```

Or pass flags directly:

```bash
staso setup --target claude-code --api-key ak_... --workspace my-workspace
staso setup --target codex --api-key ak_... --workspace my-workspace
```

## CLI Commands

```bash
staso setup                                              # interactive setup wizard
staso setup     --target claude-code --api-key ak_...    # scripted setup
staso status                                             # show what's configured
staso sync                                               # sync hooks after upgrade
staso update                                             # upgrade package + sync
staso uninstall --target codex                           # remove hooks, clean up
staso version                                            # show version info
```

## Docs

- [Quickstart](https://staso.ai/docs/getting-started/quickstart) -- 5 minutes to first trace
- [Guards](https://staso.ai/docs/guards/overview) -- evaluate, block, modify, and escalate tool calls
- [Tracing](https://staso.ai/docs/guides/tracing) -- `@agent`, `@tool`, `@trace`, `st.span()`
- [Conversations](https://staso.ai/docs/guides/conversations) -- group traces by conversation
- [Integrations](https://staso.ai/docs/integrations/overview) -- Anthropic, OpenAI, Claude Code, Codex
- [Configuration](https://staso.ai/docs/configuration/options) -- all options and env vars
- [Troubleshooting](https://staso.ai/docs/troubleshooting) -- common issues

Python 3.11+ &middot; [Apache 2.0](LICENSE)
