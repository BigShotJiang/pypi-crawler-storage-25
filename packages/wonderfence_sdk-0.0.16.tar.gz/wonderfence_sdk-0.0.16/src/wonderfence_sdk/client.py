import asyncio
import logging
import os
import uuid
import warnings
from typing import Any, Optional

import aiohttp
import requests

from .models import AnalysisContext, CustomField, EvaluateMessageResponse, ImageInput, MessageType
from .utils import (
    _get_version,
    async_retry_with_exponential_backoff,
    retry_with_exponential_backoff,
)

# HTTP status code threshold for error responses
HTTP_ERROR_THRESHOLD = 300

logger = logging.getLogger("wonderfence_sdk")

# SDK User-Agent with dynamic version
USER_AGENT = f"wonderfence-sdk/{_get_version()}"


class WonderFenceClient:
    """SDK Client for easier communication with WonderFence API

    .. deprecated::
        Use :class:`WonderFenceV2Client` instead.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        app_name: Optional[str] = None,
        base_url: Optional[str] = None,
        provider: Optional[str] = None,
        model_name: Optional[str] = None,
        model_version: Optional[str] = None,
        platform: Optional[str] = None,
        api_timeout: Optional[int] = None,
    ) -> None:
        """
        Initialize the WonderFenceClient with configuration values.
        :param api_key: The supplied Alice WonderFence API key - provide if you want to override the env var or not use it
        :param app_name: Name of the app that is calling the API - provide if you want to override the env var
        :param base_url: Base URL for the WonderFence API - provide if you want to override the env var
        :param provider: Default value for which LLM provider the client is analyzing (e.g. openai, anthropic, deepseek)
        :param model_name: Default value for name of the LLM model being used (e.g. gpt-3.5-turbo, claude-2)
        :param model_version: Default value for version of the LLM model being used (e.g. 2023-05-15)
        :param platform: Default value for cloud platform where the model is hosted (e.g. aws, azure, databricks)
        :param api_timeout: Timeout for API requests in seconds (default is 5 seconds)

        .. deprecated::
            Use :class:`WonderFenceV2Client` instead.
        """
        warnings.warn(
            "WonderFenceClient is deprecated, use WonderFenceV2Client instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        # Initialize with provided values or environment variables
        self.api_key = api_key or os.environ.get("ALICE_API_KEY")
        self.app_name = app_name or os.environ.get("ALICE_APP_NAME", "unknown")
        self.base_url = base_url or os.environ.get("ALICE_URL_OVERRIDE", "https://api.alice.io")
        self.provider = provider or os.environ.get("ALICE_MODEL_PROVIDER", "unknown")
        self.model_name = model_name or os.environ.get("ALICE_MODEL_NAME", "unknown")
        self.model_version = model_version or os.environ.get("ALICE_MODEL_VERSION", "unknown")
        self.platform = platform or os.environ.get("ALICE_PLATFORM", "unknown")
        self.api_timeout = api_timeout or int(os.environ.get("ALICE_API_TIMEOUT", "5"))

        self._setup_http("v1")
        self._validate_init_parameters()

        logger.debug(
            "WonderFenceClient initialized successfully with base_url: %s, app_name: %s", self.base_url, self.app_name
        )

    def _setup_http(self, api_version: str) -> None:
        """Initialize HTTP client, headers, and API URL. Shared between v1 and v2."""
        assert self.base_url is not None, "base_url should never be None"
        self.api_url = self.base_url + f"/{api_version}/evaluate/message"
        self.headers = {
            "Content-Type": "application/json",
            "User-Agent": USER_AGENT,
            "af-api-key": self.api_key,
        }

        self.http_client: Optional[aiohttp.ClientSession] = None
        self.timeout_seconds: Optional[aiohttp.ClientTimeout] = None

        try:
            if asyncio.get_event_loop().is_running():
                self.http_client = aiohttp.ClientSession(
                    headers={"User-Agent": USER_AGENT},
                    connector=aiohttp.TCPConnector(limit=5000, force_close=False),
                )
                self.timeout_seconds = aiohttp.ClientTimeout(total=self.api_timeout)
        except RuntimeError:
            pass

    async def close(self) -> None:
        """Explicitly close the HTTP client session."""
        if self.http_client and not self.http_client.closed:
            await self.http_client.close()

    def _validate_common_parameters(self) -> None:
        """Validate parameters shared between v1 and v2 clients."""
        if not self.api_key or self.api_key.strip() == "":
            raise ValueError("API key is required. Set ALICE_API_KEY environment variable or pass api_key parameter.")

        if not self.base_url or self.base_url.strip() == "":
            raise ValueError(
                "Base URL is required. Set ALICE_URL_OVERRIDE environment variable or pass base_url parameter."
            )

        if not self.base_url.startswith(("http://", "https://")):
            raise ValueError(f"Invalid base URL format: {self.base_url}. URL must start with http:// or https://")

        if self.api_timeout <= 0:
            raise ValueError(f"API timeout must be positive, got: {self.api_timeout}")

    def _validate_init_parameters(self) -> None:
        """Post-initialization validations for v1 client."""
        self._validate_common_parameters()

        if not self.app_name or self.app_name.strip() == "":
            raise ValueError(
                "App name cannot be empty. Set ALICE_APP_NAME environment variable or pass app_name parameter."
            )

    def _validate_custom_fields_set(self, custom_fields: Optional[set[CustomField]] = None) -> None:
        """
        Validate that custom_fields is either None or a set of CustomField objects.

        :param custom_fields: The custom fields to validate
        :raises ValueError: If custom_fields is not None and not a set of CustomField objects
        """
        if custom_fields is not None:
            if not isinstance(custom_fields, set):
                raise ValueError(f"custom_fields must be a set of CustomField objects, got {type(custom_fields)}")

            for field in custom_fields:
                if not isinstance(field, CustomField):
                    raise ValueError(f"All items in custom_fields must be CustomField instances, got {type(field)}")

    def _create_request_body(
        self,
        type: MessageType,
        text: Optional[str] = None,
        image: Optional[ImageInput] = None,
        model: Optional[str] = None,
        platform: Optional[str] = None,
        provider: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        version: Optional[str] = None,
        custom_fields: Optional[set[CustomField]] = None,
    ) -> dict:
        # Validate that exactly one of text or image is provided
        if text is None and image is None:
            raise ValueError("Either text or image must be provided")
        if text is not None and image is not None:
            raise ValueError("Cannot provide both text and image - they are mutually exclusive")

        # Validate custom_fields is a set
        self._validate_custom_fields_set(custom_fields)

        body: dict[str, Any] = {
            "message_type": type.value,
            "session_id": session_id or str(uuid.uuid4()),
            "user_id": user_id or str(uuid.uuid4()),
            "app_name": self.app_name,
            "model_context": {
                "provider": provider or self.provider,
                "name": model or self.model_name,
                "version": version or self.model_version,
                "cloud_platform": platform or self.platform,
            },
        }

        # Add either text or image data
        if text is not None:
            body["text"] = text
        elif image is not None:
            body.update(image.to_dict())

        if custom_fields is not None and len(custom_fields) > 0:
            body["custom_fields"] = [field.to_dict() for field in custom_fields]

        logger.debug("API request: %s", body)
        return body

    def _handle_api_response(self, detection: dict) -> EvaluateMessageResponse:
        logger.debug("API response: %s", detection)
        return EvaluateMessageResponse(**detection)

    @retry_with_exponential_backoff(
        max_retries=int(os.environ.get("ALICE_RETRY_MAX", "3")),
        base_delay=float(os.environ.get("ALICE_RETRY_BASE_DELAY", "1")),
    )
    def _sync_internal_call(
        self,
        type: MessageType,
        text: Optional[str] = None,
        image: Optional[ImageInput] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        version: Optional[str] = None,
        platform: Optional[str] = None,
        custom_fields: Optional[set[CustomField]] = None,
    ) -> EvaluateMessageResponse:
        body = self._create_request_body(
            type=type,
            text=text,
            image=image,
            model=model,
            platform=platform,
            provider=provider,
            session_id=session_id,
            user_id=user_id,
            version=version,
            custom_fields=custom_fields,
        )
        detection_response = requests.post(
            self.api_url,
            headers=self.headers,
            json=body,
            timeout=self.api_timeout,
        )
        if detection_response.status_code >= HTTP_ERROR_THRESHOLD:
            raise Exception(f"{detection_response.status_code}:{detection_response.text}")

        return self._handle_api_response(detection_response.json())

    @async_retry_with_exponential_backoff(
        max_retries=int(os.environ.get("ALICE_RETRY_MAX", "3")),
        base_delay=float(os.environ.get("ALICE_RETRY_BASE_DELAY", "1")),
    )
    async def _async_internal_call(
        self,
        type: MessageType,
        text: Optional[str] = None,
        image: Optional[ImageInput] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        version: Optional[str] = None,
        platform: Optional[str] = None,
        custom_fields: Optional[set[CustomField]] = None,
    ) -> EvaluateMessageResponse:
        if self.http_client is None:
            raise RuntimeError("Async client not initialized. Ensure you have a running event loop.")

        body = self._create_request_body(
            type=type,
            text=text,
            image=image,
            model=model,
            platform=platform,
            provider=provider,
            session_id=session_id,
            user_id=user_id,
            version=version,
            custom_fields=custom_fields,
        )

        async with self.http_client.post(
            self.api_url,
            headers=self.headers,
            json=body,
            timeout=self.timeout_seconds,
        ) as detection_response:
            if detection_response.status >= HTTP_ERROR_THRESHOLD:
                # Properly await the response text
                response_text = await detection_response.text()
                raise Exception(f"{detection_response.status}:{response_text}")
            return self._handle_api_response(await detection_response.json())

    def evaluate_prompt_sync(
        self,
        context: AnalysisContext,
        prompt: Optional[str] = None,
        image: Optional[ImageInput] = None,
        custom_fields: Optional[set[CustomField]] = None,
    ) -> EvaluateMessageResponse:
        """
        Evaluate a user prompt (text or image) that is sent to an LLM
        :param context: Metadata for evaluation, fields that are not supplied will be taken from env vars
            session_id and user_id are required to group texts in the Alice platform
        :param prompt: The text of the prompt to analyze (mutually exclusive with image)
        :param image: ImageInput object for image prompts (mutually exclusive with prompt)
        :param custom_fields: Optional set of predefined custom fields to include in the request
        :return: EvaluateMessageResponse object with analysis and detection results
        """
        if prompt is None and image is None:
            raise ValueError("Either prompt or image must be provided")
        if prompt is not None and image is not None:
            raise ValueError("Cannot provide both prompt and image - they are mutually exclusive")

        return self._sync_internal_call(
            type=MessageType.PROMPT,
            text=prompt,
            image=image,
            session_id=context.session_id,
            user_id=context.user_id,
            provider=context.provider,
            model=context.model_name,
            version=context.model_version,
            platform=context.platform,
            custom_fields=custom_fields,
        )

    def evaluate_response_sync(
        self,
        context: AnalysisContext,
        response: Optional[Any] = None,
        image: Optional[ImageInput] = None,
        custom_fields: Optional[set[CustomField]] = None,
    ) -> EvaluateMessageResponse:
        """
        Evaluate a return LLM response (text or image) to a prompt.
        :param context: Metadata for evaluation, fields that are not supplied will be taken from env vars
            session_id and user_id are required to group texts in the Alice platform
        :param response: The LLM text response to a given prompt (mutually exclusive with image)
        :param image: ImageInput object for image responses (mutually exclusive with response)
        :param custom_fields: Optional set of predefined custom fields to include in the request
        :return: EvaluateMessageResponse object with analysis and detection results
        """
        if response is None and image is None:
            raise ValueError("Either response or image must be provided")
        if response is not None and image is not None:
            raise ValueError("Cannot provide both response and image - they are mutually exclusive")

        return self._sync_internal_call(
            type=MessageType.RESPONSE,
            text=str(response) if response is not None else None,
            image=image,
            session_id=context.session_id,
            user_id=context.user_id,
            provider=context.provider,
            model=context.model_name,
            version=context.model_version,
            platform=context.platform,
            custom_fields=custom_fields,
        )

    async def evaluate_prompt(
        self,
        context: AnalysisContext,
        prompt: Optional[str] = None,
        image: Optional[ImageInput] = None,
        custom_fields: Optional[set[CustomField]] = None,
    ) -> EvaluateMessageResponse:
        """
        Evaluate a user prompt (text or image) that is sent to an LLM, using asyncio
        :param context: Metadata for evaluation, fields that are not supplied will be taken from env vars
            session_id and user_id are required to group texts in the Alice platform
        :param prompt: The text of the prompt to analyze (mutually exclusive with image)
        :param image: ImageInput object for image prompts (mutually exclusive with prompt)
        :param custom_fields: Optional set of predefined custom fields to include in the request
        :return: EvaluateMessageResponse object with analysis and detection results
        """
        if prompt is None and image is None:
            raise ValueError("Either prompt or image must be provided")
        if prompt is not None and image is not None:
            raise ValueError("Cannot provide both prompt and image - they are mutually exclusive")

        return await self._async_internal_call(
            type=MessageType.PROMPT,
            text=prompt,
            image=image,
            session_id=context.session_id,
            user_id=context.user_id,
            provider=context.provider,
            model=context.model_name,
            version=context.model_version,
            platform=context.platform,
            custom_fields=custom_fields,
        )

    async def evaluate_response(
        self,
        context: AnalysisContext,
        response: Optional[Any] = None,
        image: Optional[ImageInput] = None,
        custom_fields: Optional[set[CustomField]] = None,
    ) -> EvaluateMessageResponse:
        """
        Evaluate a return LLM response (text or image) to a prompt, using asyncio.
        :param context: Metadata for evaluation, fields that are not supplied will be taken from env vars
            session_id and user_id are required to group texts in the Alice platform
        :param response: The LLM text response to a given prompt (mutually exclusive with image)
        :param image: ImageInput object for image responses (mutually exclusive with response)
        :param custom_fields: Optional set of predefined custom fields to include in the request
        :return: EvaluateMessageResponse object with analysis and detection results
        """
        if response is None and image is None:
            raise ValueError("Either response or image must be provided")
        if response is not None and image is not None:
            raise ValueError("Cannot provide both response and image - they are mutually exclusive")

        return await self._async_internal_call(
            type=MessageType.RESPONSE,
            text=str(response) if response is not None else None,
            image=image,
            session_id=context.session_id,
            user_id=context.user_id,
            provider=context.provider,
            model=context.model_name,
            version=context.model_version,
            platform=context.platform,
            custom_fields=custom_fields,
        )


class WonderFenceV2Client(WonderFenceClient):
    """SDK Client for WonderFence API v2.

    V2 requires app_id (UUID) instead of app_name, and makes model_context optional.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        app_id: Optional[str] = None,
        base_url: Optional[str] = None,
        provider: Optional[str] = None,
        model_name: Optional[str] = None,
        model_version: Optional[str] = None,
        platform: Optional[str] = None,
        api_timeout: Optional[int] = None,
    ) -> None:
        """
        Initialize the WonderFenceV2Client with configuration values.
        :param api_key: The supplied Alice WonderFence API key - provide if you want to override the env var or not use it
        :param app_id: UUID of the application whose policies to apply - falls back to ALICE_APP_ID env var
        :param base_url: Base URL for the WonderFence API - provide if you want to override the env var
        :param provider: LLM provider (e.g. openai, anthropic) - optional, falls back to ALICE_MODEL_PROVIDER env var
        :param model_name: Name of the LLM model (e.g. gpt-3.5-turbo) - optional, falls back to ALICE_MODEL_NAME env var
        :param model_version: Version of the LLM model (e.g. 2023-05-15) - optional, falls back to ALICE_MODEL_VERSION env var
        :param platform: Cloud platform where the model is hosted (e.g. aws, azure) - optional, falls back to ALICE_PLATFORM env var
        :param api_timeout: Timeout for API requests in seconds (default is 5 seconds)
        """
        self.api_key = api_key or os.environ.get("ALICE_API_KEY")
        self.app_id = app_id or os.environ.get("ALICE_APP_ID")
        self.base_url = base_url or os.environ.get("ALICE_URL_OVERRIDE", "https://api.alice.io")
        self.provider: Optional[str] = provider or os.environ.get("ALICE_MODEL_PROVIDER")
        self.model_name: Optional[str] = model_name or os.environ.get("ALICE_MODEL_NAME")
        self.model_version: Optional[str] = model_version or os.environ.get("ALICE_MODEL_VERSION")
        self.platform: Optional[str] = platform or os.environ.get("ALICE_PLATFORM")
        self.api_timeout = api_timeout or int(os.environ.get("ALICE_API_TIMEOUT", "5"))

        self._setup_http("v2")
        self._validate_init_parameters()

        logger.debug(
            "WonderFenceV2Client initialized successfully with base_url: %s, app_id: %s", self.base_url, self.app_id
        )

    def _validate_init_parameters(self) -> None:
        """Post-initialization validations for v2 client."""
        self._validate_common_parameters()

        if not self.app_id or self.app_id.strip() == "":
            raise ValueError("App ID is required. Set ALICE_APP_ID environment variable or pass app_id parameter.")

        try:
            uuid.UUID(self.app_id)
        except ValueError as err:
            raise ValueError(f"Invalid app_id format: {self.app_id}. Must be a valid UUID.") from err

    def _create_request_body(
        self,
        type: MessageType,
        text: Optional[str] = None,
        image: Optional[ImageInput] = None,
        model: Optional[str] = None,
        platform: Optional[str] = None,
        provider: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        version: Optional[str] = None,
        custom_fields: Optional[set[CustomField]] = None,
    ) -> dict:
        if text is None and image is None:
            raise ValueError("Either text or image must be provided")
        if text is not None and image is not None:
            raise ValueError("Cannot provide both text and image - they are mutually exclusive")

        self._validate_custom_fields_set(custom_fields)

        body: dict[str, Any] = {
            "message_type": type.value,
            "session_id": session_id or str(uuid.uuid4()),
            "user_id": user_id or str(uuid.uuid4()),
            "app_id": self.app_id,
        }

        # model_context is optional in v2 — only include if any field is provided
        effective_provider = provider or self.provider
        effective_model = model or self.model_name
        effective_version = version or self.model_version
        effective_platform = platform or self.platform

        if any((effective_provider, effective_model, effective_version, effective_platform)):
            body["model_context"] = {
                "provider": effective_provider or "unknown",
                "name": effective_model or "unknown",
                "version": effective_version or "unknown",
                "cloud_platform": effective_platform or "unknown",
            }

        if text is not None:
            body["text"] = text
        elif image is not None:
            body.update(image.to_dict())

        if custom_fields is not None and len(custom_fields) > 0:
            body["custom_fields"] = [field.to_dict() for field in custom_fields]

        logger.debug("API request: %s", body)
        return body
