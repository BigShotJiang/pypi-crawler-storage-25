import os

os.environ["ALICE_RETRY_MAX"] = "2"
os.environ["ALICE_RETRY_BASE_DELAY"] = "0.1"
import pytest
from aiohttp import ClientConnectionError
from aioresponses import aioresponses
from wonderfence_sdk.client import USER_AGENT, WonderFenceV2Client
from wonderfence_sdk.models import AnalysisContext, CustomField, EvaluateMessageResponse

pytestmark = pytest.mark.citest

VALID_APP_ID = "550e8400-e29b-41d4-a716-446655440000"
V2_URL = "https://api.alice.io/v2/evaluate/message"


@pytest.mark.asyncio  # type: ignore[misc]
async def test_v2_evaluate_prompt_async() -> None:
    with aioresponses() as mocker:
        mocker.post(
            url=V2_URL,
            status=200,
            payload={
                "correlation_id": "test-correlation-id",
                "action": "",
                "detections": [],
                "errors": [],
            },
        )

        client = WonderFenceV2Client(api_key="test_api_key", app_id=VALID_APP_ID)
        context = AnalysisContext(session_id="test_session", user_id="test_user")
        result = await client.evaluate_prompt(prompt="test prompt", context=context)

        assert isinstance(result, EvaluateMessageResponse)
        assert result.action == ""
        assert result.action_text is None
        assert result.detections == []
        assert result.errors == []


@pytest.mark.asyncio  # type: ignore[misc]
async def test_v2_evaluate_response_async() -> None:
    with aioresponses() as mocker:
        mocker.post(
            url=V2_URL,
            status=200,
            payload={
                "correlation_id": "test-correlation-id",
                "action": "",
                "detections": [],
                "errors": [],
            },
        )

        client = WonderFenceV2Client(api_key="test_api_key", app_id=VALID_APP_ID)
        context = AnalysisContext(session_id="test_session", user_id="test_user")
        result = await client.evaluate_response(response="test response", context=context)

        assert isinstance(result, EvaluateMessageResponse)
        assert result.action == ""
        assert result.detections == []


@pytest.mark.asyncio  # type: ignore[misc]
async def test_v2_evaluate_response_timeout() -> None:
    with aioresponses() as mocker:
        mocker.post(url=V2_URL, timeout=True)

        client = WonderFenceV2Client(api_key="test_api_key", app_id=VALID_APP_ID)
        context = AnalysisContext(session_id="test_session", user_id="test_user")

        with pytest.raises(ClientConnectionError):
            await client.evaluate_response(response="test response", context=context)


@pytest.mark.asyncio  # type: ignore[misc]
async def test_v2_evaluate_prompt_async_custom_fields() -> None:
    with aioresponses() as mocker:
        mocker.post(
            url=V2_URL,
            status=200,
            payload={
                "correlation_id": "test-correlation-id",
                "action": "",
                "detections": [],
                "errors": [],
            },
        )

        client = WonderFenceV2Client(api_key="test_api_key", app_id=VALID_APP_ID)
        context = AnalysisContext(session_id="test_session", user_id="test_user")
        result = await client.evaluate_prompt(
            prompt="test prompt", context=context, custom_fields={CustomField(name="test_field", value=123)}
        )

        assert isinstance(result, EvaluateMessageResponse)
        assert result.action == ""
        mocker.assert_called_with(
            V2_URL,
            "POST",
            json={
                "text": "test prompt",
                "message_type": "prompt",
                "session_id": "test_session",
                "user_id": "test_user",
                "app_id": VALID_APP_ID,
                "custom_fields": [{"test_field": 123}],
            },
            headers={
                "User-Agent": USER_AGENT,
                "af-api-key": "test_api_key",
                "Content-Type": "application/json",
            },
            timeout=client.timeout_seconds,
        )


@pytest.mark.asyncio  # type: ignore[misc]
async def test_v2_evaluate_prompt_async_without_model_context() -> None:
    """Verify that model_context is omitted from the request when no fields are provided."""
    with aioresponses() as mocker:
        mocker.post(
            url=V2_URL,
            status=200,
            payload={
                "correlation_id": "test-correlation-id",
                "action": "",
                "detections": [],
                "errors": [],
            },
        )

        client = WonderFenceV2Client(api_key="test_api_key", app_id=VALID_APP_ID)
        context = AnalysisContext(session_id="test_session", user_id="test_user")
        await client.evaluate_prompt(prompt="test prompt", context=context)

        mocker.assert_called_with(
            V2_URL,
            "POST",
            json={
                "text": "test prompt",
                "message_type": "prompt",
                "session_id": "test_session",
                "user_id": "test_user",
                "app_id": VALID_APP_ID,
            },
            headers={
                "User-Agent": USER_AGENT,
                "af-api-key": "test_api_key",
                "Content-Type": "application/json",
            },
            timeout=client.timeout_seconds,
        )


@pytest.mark.asyncio  # type: ignore[misc]
async def test_v2_evaluate_prompt_async_with_model_context() -> None:
    """Verify that model_context is included when fields are provided via AnalysisContext."""
    with aioresponses() as mocker:
        mocker.post(
            url=V2_URL,
            status=200,
            payload={
                "correlation_id": "test-correlation-id",
                "action": "",
                "detections": [],
                "errors": [],
            },
        )

        client = WonderFenceV2Client(api_key="test_api_key", app_id=VALID_APP_ID)
        context = AnalysisContext(
            session_id="test_session",
            user_id="test_user",
            provider="openai",
            model_name="gpt-4",
            model_version="2023-05-15",
            platform="azure",
        )
        await client.evaluate_prompt(prompt="test prompt", context=context)

        mocker.assert_called_with(
            V2_URL,
            "POST",
            json={
                "text": "test prompt",
                "message_type": "prompt",
                "session_id": "test_session",
                "user_id": "test_user",
                "app_id": VALID_APP_ID,
                "model_context": {
                    "provider": "openai",
                    "name": "gpt-4",
                    "version": "2023-05-15",
                    "cloud_platform": "azure",
                },
            },
            headers={
                "User-Agent": USER_AGENT,
                "af-api-key": "test_api_key",
                "Content-Type": "application/json",
            },
            timeout=client.timeout_seconds,
        )
