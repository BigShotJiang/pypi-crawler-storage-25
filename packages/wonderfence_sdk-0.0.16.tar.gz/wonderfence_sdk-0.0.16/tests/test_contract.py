"""OpenAPI contract tests — validates SDK shapes against the live spec.

Run `./scripts/fetch-spec.sh` first to download the spec to tests/fixtures/openapi.json.
"""

import copy
import json
import os
from pathlib import Path

import jsonschema
import pytest

from wonderfence_sdk.client import WonderFenceClient
from wonderfence_sdk.models import (
    Actions,
    CustomField,
    EvaluateMessageResponse,
    ImageInput,
    MessageType,
)

# ─── Spec loader ──────────────────────────────────────────────────────────────

SPEC_PATH = os.environ.get(
    "OPENAPI_SPEC_PATH",
    str(Path(__file__).parent / "fixtures" / "openapi.json"),
)


def normalize_nullable(schema: object) -> object:
    """Convert OpenAPI 3.0 ``nullable: true`` to JSON Schema ``type: [original, "null"]``."""
    if schema is None or not isinstance(schema, dict):
        return schema
    if isinstance(schema, list):
        return [normalize_nullable(item) for item in schema]

    result: dict = {}
    for key, value in schema.items():
        if key == "nullable":
            continue
        result[key] = normalize_nullable(value) if isinstance(value, (dict, list)) else value

    if schema.get("nullable") is True:
        if "type" in result:
            orig = result["type"]
            result["type"] = [*orig, "null"] if isinstance(orig, list) else [orig, "null"]
        else:
            result["type"] = "null"

    return result


def get_schema(spec: dict, name: str) -> dict:
    """Extract and normalize a schema from ``components.schemas``."""
    schemas = spec.get("components", {}).get("schemas", {})
    if name not in schemas:
        pytest.fail(f'Schema "{name}" not found in OpenAPI spec')
    return normalize_nullable(copy.deepcopy(schemas[name]))


# ─── Fixtures ─────────────────────────────────────────────────────────────────


@pytest.fixture(scope="module")
def spec():
    if not Path(SPEC_PATH).exists():
        pytest.skip(f"OpenAPI spec not found at {SPEC_PATH}. Run ./scripts/fetch-spec.sh first.")
    with open(SPEC_PATH) as f:
        return json.load(f)


@pytest.fixture(scope="module")
def client():
    """Create a WonderFenceClient for building request bodies (no real API calls)."""
    saved = {k: os.environ.get(k) for k in ("ALICE_API_KEY", "ALICE_APP_NAME")}
    os.environ["ALICE_API_KEY"] = "test-key-for-contract-tests"
    os.environ.setdefault("ALICE_APP_NAME", "contract-test")
    try:
        return WonderFenceClient(
            api_key="test-key-for-contract-tests",
            app_name="contract-test",
            base_url="https://api.alice.io",
            provider="openai",
            model_name="gpt-4",
            model_version="0613",
            platform="aws",
        )
    finally:
        for k, v in saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


# ─── Helpers ──────────────────────────────────────────────────────────────────


def _resolve_refs(schema: dict, spec: dict) -> dict:
    """Inline top-level ``$ref`` so jsonschema can validate standalone."""
    if "$ref" in schema:
        ref_path = schema["$ref"]  # e.g. "#/components/schemas/Foo"
        parts = ref_path.lstrip("#/").split("/")
        resolved = spec
        for part in parts:
            resolved = resolved[part]
        return normalize_nullable(copy.deepcopy(resolved))
    return schema


def _validate(instance: dict, schema: dict, spec: dict) -> None:
    """Validate *instance* against *schema*, resolving ``$ref`` in properties."""
    # Build a self-contained schema with definitions for $ref resolution
    resolved = copy.deepcopy(schema)

    # Inline any top-level $ref in property schemas
    if "properties" in resolved:
        for prop_name, prop_schema in resolved["properties"].items():
            resolved["properties"][prop_name] = _resolve_refs(prop_schema, spec)
            # Handle array items with $ref
            if prop_schema.get("type") == "array" and "$ref" in prop_schema.get("items", {}):
                resolved["properties"][prop_name]["items"] = _resolve_refs(prop_schema["items"], spec)

    jsonschema.validate(instance=instance, schema=resolved)


# ─── Request body tests ──────────────────────────────────────────────────────


class TestRequestBody:
    def test_text_matches_text_message_schema(self, spec, client):
        body = client._create_request_body(
            type=MessageType.PROMPT,
            text="Hello, world!",
            session_id="sess-1",
            user_id="user-1",
        )

        schema = get_schema(spec, "TextMessage")
        _validate(body, schema, spec)

    def test_image_url_matches_schema(self, spec, client):
        body = client._create_request_body(
            type=MessageType.PROMPT,
            image=ImageInput(media_url="https://example.com/image.jpg"),
            session_id="sess-1",
            user_id="user-1",
        )

        schema = get_schema(spec, "ImageUrlMessage")
        _validate(body, schema, spec)

    def test_image_base64_matches_schema(self, spec, client):
        body = client._create_request_body(
            type=MessageType.PROMPT,
            image=ImageInput(raw_media="iVBORw0KGgoAAAANSUhEUg==", mime_type="image/png"),
            session_id="sess-1",
            user_id="user-1",
        )

        schema = get_schema(spec, "ImageBase64Message")
        _validate(body, schema, spec)

    def test_custom_fields_format(self, spec, client):
        body = client._create_request_body(
            type=MessageType.PROMPT,
            text="test text",
            session_id="sess-1",
            user_id="user-1",
            custom_fields={CustomField(name="department", value="sales")},
        )

        # custom_fields should be [{"department": "sales"}] — single key-value per object
        assert body["custom_fields"] == [{"department": "sales"}]

        # Validate the whole body still matches TextMessage
        schema = get_schema(spec, "TextMessage")
        _validate(body, schema, spec)


# ─── Response schema tests ───────────────────────────────────────────────────


class TestResponseSchema:
    def test_accepts_valid_response(self):
        valid_response = {
            "correlation_id": "resp-abc123",
            "action": "BLOCK",
            "action_text": "Content blocked",
            "detections": [
                {
                    "type": "hate_speech",
                    "score": 0.95,
                    "spans": [{"start": 0, "end": 10}],
                },
            ],
            "errors": [],
        }
        result = EvaluateMessageResponse(**valid_response)
        assert result.correlation_id == "resp-abc123"
        assert result.action == Actions.BLOCK

    def test_accepts_minimal_response(self):
        minimal_response = {
            "correlation_id": "resp-min",
            "action": "",
            "detections": [],
            "errors": [],
        }
        result = EvaluateMessageResponse(**minimal_response)
        assert result.correlation_id == "resp-min"
        assert result.action == Actions.NO_ACTION

    def test_covers_all_openapi_fields(self, spec):
        response_schema = get_schema(spec, "EvaluateMessageResponse")
        spec_fields = set(response_schema.get("properties", {}).keys())

        pydantic_fields = set(EvaluateMessageResponse.model_fields.keys())

        missing = spec_fields - pydantic_fields
        assert not missing, f"Pydantic model is missing OpenAPI fields: {missing}"


# ─── Enum tests ───────────────────────────────────────────────────────────────


class TestEnums:
    def test_actions_match_spec(self, spec):
        response_schema = get_schema(spec, "EvaluateMessageResponse")
        spec_actions = sorted(response_schema["properties"]["action"]["enum"])
        sdk_actions = sorted(a.value for a in Actions)

        assert sdk_actions == spec_actions

    def test_message_type_match_spec(self, spec):
        text_message_schema = get_schema(spec, "TextMessage")
        spec_message_types = sorted(text_message_schema["properties"]["message_type"]["enum"])
        sdk_message_types = sorted(m.value for m in MessageType)

        assert sdk_message_types == spec_message_types


# ─── Endpoint and config tests ───────────────────────────────────────────────


class TestEndpointAndConfig:
    def test_endpoint_exists(self, spec):
        paths = spec.get("paths", {})
        assert "/v1/evaluate/message" in paths, "Expected /v1/evaluate/message in OpenAPI paths"

    def test_config_defaults(self):
        """Verify SDK default configuration values."""
        saved_env: dict[str, str | None] = {}
        env_vars = [
            "ALICE_API_KEY",
            "ALICE_APP_NAME",
            "ALICE_URL_OVERRIDE",
            "ALICE_MODEL_PROVIDER",
            "ALICE_MODEL_NAME",
            "ALICE_MODEL_VERSION",
            "ALICE_PLATFORM",
            "ALICE_API_TIMEOUT",
            "ALICE_RETRY_MAX",
            "ALICE_RETRY_BASE_DELAY",
        ]
        for v in env_vars:
            saved_env[v] = os.environ.get(v)
            os.environ.pop(v, None)

        try:
            client = WonderFenceClient(api_key="test-key", app_name="test-app")
            assert client.base_url == "https://api.alice.io"
            expected_timeout = 5
            assert client.api_timeout == expected_timeout
        finally:
            for key, val in saved_env.items():
                if val is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = val
