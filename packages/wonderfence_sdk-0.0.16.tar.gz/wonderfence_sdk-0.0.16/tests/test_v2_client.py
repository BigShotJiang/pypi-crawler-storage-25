import os

os.environ["ALICE_RETRY_MAX"] = "2"
os.environ["ALICE_RETRY_BASE_DELAY"] = "0.1"
import unittest
from unittest.mock import MagicMock, patch

import pytest
import responses
from requests.exceptions import ConnectTimeout
from wonderfence_sdk.client import USER_AGENT, WonderFenceV2Client
from wonderfence_sdk.models import AnalysisContext, CustomField, EvaluateMessageResponse, ImageInput, MessageType

pytestmark = pytest.mark.citest

VALID_APP_ID = "550e8400-e29b-41d4-a716-446655440000"
V2_URL = "https://api.alice.io/v2/evaluate/message"


class TestWonderFenceV2Init(unittest.TestCase):
    def test_v2_client_init_with_valid_uuid(self) -> None:
        client = WonderFenceV2Client(api_key="test_api_key", app_id=VALID_APP_ID)
        self.assertEqual(client.app_id, VALID_APP_ID)
        self.assertEqual(client.api_url, V2_URL)

    def test_v2_client_init_with_invalid_uuid_raises(self) -> None:
        with self.assertRaises(ValueError) as context:
            WonderFenceV2Client(api_key="test_api_key", app_id="not-a-uuid")
        self.assertIn("Invalid app_id format", str(context.exception))

    def test_v2_client_init_without_app_id_raises(self) -> None:
        with self.assertRaises(ValueError) as context:
            WonderFenceV2Client(api_key="test_api_key")
        self.assertIn("App ID is required", str(context.exception))

    def test_v2_client_init_with_empty_app_id_raises(self) -> None:
        with self.assertRaises(ValueError) as context:
            WonderFenceV2Client(api_key="test_api_key", app_id="")
        self.assertIn("App ID is required", str(context.exception))

    @patch.dict(os.environ, {"ALICE_APP_ID": VALID_APP_ID})
    def test_v2_client_init_from_env_var(self) -> None:
        client = WonderFenceV2Client(api_key="test_api_key")
        self.assertEqual(client.app_id, VALID_APP_ID)

    def test_v2_client_model_context_defaults_to_none(self) -> None:
        client = WonderFenceV2Client(api_key="test_api_key", app_id=VALID_APP_ID)
        self.assertIsNone(client.provider)
        self.assertIsNone(client.model_name)
        self.assertIsNone(client.model_version)
        self.assertIsNone(client.platform)


class TestWonderFenceV2(unittest.TestCase):
    def setUp(self) -> None:
        self.api_key = "test_api_key"
        self.app_id = VALID_APP_ID
        self.client = WonderFenceV2Client(api_key=self.api_key, app_id=self.app_id)

    @patch("wonderfence_sdk.client.requests.post")
    def test_v2_sync_internal_call_success(self, mock_post: MagicMock) -> None:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "correlation_id": "test-correlation-id",
            "action": "",
            "detections": [],
            "errors": [],
        }
        mock_post.return_value = mock_response

        result = self.client._sync_internal_call(
            text="test text",
            type=MessageType.PROMPT,
            session_id="test_session",
            user_id="test_user",
        )

        self.assertIsInstance(result, EvaluateMessageResponse)
        self.assertEqual(result.action, "")
        self.assertEqual(result.detections, [])
        self.assertEqual(result.errors, [])

    @patch("wonderfence_sdk.client.requests.post")
    def test_v2_sync_internal_call_blocked(self, mock_post: MagicMock) -> None:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "correlation_id": "test-correlation-id",
            "action": "BLOCK",
            "detections": [{"type": "test_reason", "score": 0.95}],
            "errors": [],
        }
        mock_post.return_value = mock_response

        result = self.client._sync_internal_call(
            text="test text",
            type=MessageType.PROMPT,
            session_id="test_session",
            user_id="test_user",
        )

        self.assertIsInstance(result, EvaluateMessageResponse)
        self.assertEqual(result.action, "BLOCK")
        self.assertEqual(len(result.detections), 1)

    @patch("wonderfence_sdk.client.requests.post")
    def test_v2_sync_internal_call_mask(self, mock_post: MagicMock) -> None:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "correlation_id": "test-correlation-id",
            "action": "MASK",
            "action_text": "***** text",
            "detections": [{"type": "test_reason", "score": 0.85}],
            "errors": [],
        }
        mock_post.return_value = mock_response

        result = self.client._sync_internal_call(
            text="test text",
            type=MessageType.PROMPT,
            session_id="test_session",
            user_id="test_user",
        )

        self.assertIsInstance(result, EvaluateMessageResponse)
        self.assertEqual(result.action, "MASK")
        self.assertEqual(result.action_text, "***** text")

    @patch("wonderfence_sdk.client.requests.post")
    def test_v2_evaluate_prompt(self, mock_post: MagicMock) -> None:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "correlation_id": "test-correlation-id",
            "action": "",
            "detections": [],
            "errors": [],
        }
        mock_post.return_value = mock_response

        context = AnalysisContext(session_id="test_session", user_id="test_user")
        result = self.client.evaluate_prompt_sync(context=context, prompt="test prompt")

        self.assertIsInstance(result, EvaluateMessageResponse)
        self.assertEqual(result.action, "")

    @patch("wonderfence_sdk.client.requests.post")
    def test_v2_evaluate_response(self, mock_post: MagicMock) -> None:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "correlation_id": "test-correlation-id",
            "action": "",
            "detections": [],
            "errors": [],
        }
        mock_post.return_value = mock_response

        context = AnalysisContext(session_id="test_session", user_id="test_user")
        result = self.client.evaluate_response_sync(context=context, response="test response")

        self.assertIsInstance(result, EvaluateMessageResponse)
        self.assertEqual(result.action, "")

    @patch("wonderfence_sdk.client.requests.post")
    def test_v2_request_body_sends_app_id_not_app_name(self, mock_post: MagicMock) -> None:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "correlation_id": "test-correlation-id",
            "action": "",
            "detections": [],
            "errors": [],
        }
        mock_post.return_value = mock_response

        context = AnalysisContext(session_id="test_session", user_id="test_user")
        self.client.evaluate_prompt_sync(context=context, prompt="test prompt")

        call_kwargs = mock_post.call_args
        body = call_kwargs.kwargs["json"] if "json" in call_kwargs.kwargs else call_kwargs[1]["json"]
        self.assertEqual(body["app_id"], VALID_APP_ID)
        self.assertNotIn("app_name", body)

    @patch("wonderfence_sdk.client.requests.post")
    def test_v2_request_body_without_model_context(self, mock_post: MagicMock) -> None:
        """When no model_context fields are provided, model_context should be absent from the body."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "correlation_id": "test-correlation-id",
            "action": "",
            "detections": [],
            "errors": [],
        }
        mock_post.return_value = mock_response

        context = AnalysisContext(session_id="test_session", user_id="test_user")
        self.client.evaluate_prompt_sync(context=context, prompt="test prompt")

        call_kwargs = mock_post.call_args
        body = call_kwargs.kwargs["json"] if "json" in call_kwargs.kwargs else call_kwargs[1]["json"]
        self.assertNotIn("model_context", body)

    @patch("wonderfence_sdk.client.requests.post")
    def test_v2_request_body_with_model_context(self, mock_post: MagicMock) -> None:
        """When model_context fields are provided via AnalysisContext, they should appear in the body."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "correlation_id": "test-correlation-id",
            "action": "",
            "detections": [],
            "errors": [],
        }
        mock_post.return_value = mock_response

        context = AnalysisContext(
            session_id="test_session",
            user_id="test_user",
            provider="openai",
            model_name="gpt-4",
            model_version="2023-05-15",
            platform="azure",
        )
        self.client.evaluate_prompt_sync(context=context, prompt="test prompt")

        call_kwargs = mock_post.call_args
        body = call_kwargs.kwargs["json"] if "json" in call_kwargs.kwargs else call_kwargs[1]["json"]
        self.assertEqual(
            body["model_context"],
            {
                "provider": "openai",
                "name": "gpt-4",
                "version": "2023-05-15",
                "cloud_platform": "azure",
            },
        )

    @patch("wonderfence_sdk.client.requests.post")
    def test_v2_request_body_with_partial_model_context(self, mock_post: MagicMock) -> None:
        """When only some model_context fields are provided, missing ones default to 'unknown'."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "correlation_id": "test-correlation-id",
            "action": "",
            "detections": [],
            "errors": [],
        }
        mock_post.return_value = mock_response

        context = AnalysisContext(session_id="test_session", user_id="test_user", provider="openai")
        self.client.evaluate_prompt_sync(context=context, prompt="test prompt")

        call_kwargs = mock_post.call_args
        body = call_kwargs.kwargs["json"] if "json" in call_kwargs.kwargs else call_kwargs[1]["json"]
        self.assertEqual(
            body["model_context"],
            {
                "provider": "openai",
                "name": "unknown",
                "version": "unknown",
                "cloud_platform": "unknown",
            },
        )

    @patch("wonderfence_sdk.client.requests.post")
    def test_v2_evaluate_prompt_custom_fields(self, mock_post: MagicMock) -> None:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "correlation_id": "test-correlation-id",
            "action": "",
            "detections": [],
            "errors": [],
        }
        mock_post.return_value = mock_response

        context = AnalysisContext(session_id="test_session", user_id="test_user")
        self.client.evaluate_prompt_sync(
            context=context,
            prompt="test prompt",
            custom_fields={CustomField(name="test_field", value="test_value")},
        )

        mock_post.assert_called_with(
            V2_URL,
            json={
                "text": "test prompt",
                "message_type": "prompt",
                "session_id": "test_session",
                "user_id": "test_user",
                "app_id": VALID_APP_ID,
                "custom_fields": [{"test_field": "test_value"}],
            },
            headers={"af-api-key": self.api_key, "Content-Type": "application/json", "User-Agent": USER_AGENT},
            timeout=5,
        )

    @patch("wonderfence_sdk.client.requests.post")
    def test_v2_evaluate_prompt_with_image_url(self, mock_post: MagicMock) -> None:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "correlation_id": "test-correlation-id",
            "action": "",
            "detections": [],
            "errors": [],
        }
        mock_post.return_value = mock_response

        context = AnalysisContext(session_id="test_session", user_id="test_user")
        image = ImageInput(media_url="https://example.com/image.jpg")
        self.client.evaluate_prompt_sync(context=context, image=image)

        mock_post.assert_called_with(
            V2_URL,
            json={
                "media_url": "https://example.com/image.jpg",
                "message_type": "prompt",
                "session_id": "test_session",
                "user_id": "test_user",
                "app_id": VALID_APP_ID,
            },
            headers={"af-api-key": self.api_key, "Content-Type": "application/json", "User-Agent": USER_AGENT},
            timeout=5,
        )

    @responses.activate  # type: ignore[misc]
    def test_v2_sync_internal_call_timeout(self) -> None:
        responses.add(
            responses.POST,
            V2_URL,
            body=ConnectTimeout(),
        )

        with self.assertRaises(ConnectTimeout):
            self.client._sync_internal_call(
                text="test text",
                type=MessageType.PROMPT,
                session_id="test_session",
                user_id="test_user",
            )

    def test_v2_evaluate_prompt_both_text_and_image_raises(self) -> None:
        image = ImageInput(media_url="https://example.com/image.jpg")
        context = AnalysisContext(session_id="test_session", user_id="test_user")
        with self.assertRaises(ValueError) as ctx:
            self.client.evaluate_prompt_sync(context=context, prompt="text", image=image)
        self.assertIn("Cannot provide both prompt and image", str(ctx.exception))

    def test_v2_evaluate_prompt_neither_text_nor_image_raises(self) -> None:
        context = AnalysisContext(session_id="test_session", user_id="test_user")
        with self.assertRaises(ValueError) as ctx:
            self.client.evaluate_prompt_sync(context=context)
        self.assertIn("Either prompt or image must be provided", str(ctx.exception))

    @patch("wonderfence_sdk.client.requests.post")
    def test_v2_client_with_constructor_model_context(self, mock_post: MagicMock) -> None:
        """When model_context fields are set on the client constructor, they should be used as defaults."""
        client = WonderFenceV2Client(
            api_key="test_api_key",
            app_id=VALID_APP_ID,
            provider="anthropic",
            model_name="claude-3",
        )

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "correlation_id": "test-correlation-id",
            "action": "",
            "detections": [],
            "errors": [],
        }
        mock_post.return_value = mock_response

        context = AnalysisContext(session_id="test_session", user_id="test_user")
        client.evaluate_prompt_sync(context=context, prompt="test prompt")

        call_kwargs = mock_post.call_args
        body = call_kwargs.kwargs["json"] if "json" in call_kwargs.kwargs else call_kwargs[1]["json"]
        self.assertEqual(
            body["model_context"],
            {
                "provider": "anthropic",
                "name": "claude-3",
                "version": "unknown",
                "cloud_platform": "unknown",
            },
        )
