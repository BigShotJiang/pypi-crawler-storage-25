"""
Entry point for running pythinker as a module: python -m pythinker
"""

from pythinker.cli.commands import app

if __name__ == "__main__":
    app()
