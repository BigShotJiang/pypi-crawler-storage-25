"""Posthumous test suite."""
