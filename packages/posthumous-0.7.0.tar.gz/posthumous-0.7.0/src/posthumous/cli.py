"""Command-line interface for Posthumous."""

from __future__ import annotations

import asyncio
import logging
import os
import signal
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

import click

from posthumous import __version__

if TYPE_CHECKING:
    from posthumous.config import Config


def setup_logging(verbose: bool = False, log_file: Path | None = None) -> None:
    """Configure logging."""
    level = logging.DEBUG if verbose else logging.INFO
    format_str = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"

    handlers: list[logging.Handler] = [logging.StreamHandler()]

    if log_file:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(log_file))

    logging.basicConfig(
        level=level,
        format=format_str,
        handlers=handlers,
    )

    # Reduce noise from third-party libraries
    logging.getLogger("aiohttp").setLevel(logging.WARNING)
    logging.getLogger("apprise").setLevel(logging.WARNING)


@click.group()
@click.version_option(version=__version__)
@click.option('-v', '--verbose', is_flag=True, help='Enable verbose output')
@click.option(
    '-c', '--config',
    type=click.Path(exists=False, path_type=Path),
    help='Path to config file',
)
@click.pass_context
def main(ctx: click.Context, verbose: bool, config: Path | None) -> None:
    """Posthumous - A federated deadman switch."""
    ctx.ensure_object(dict)
    ctx.obj['verbose'] = verbose
    ctx.obj['config_path'] = config


def _resolve_config_path(ctx: click.Context) -> Path:
    """Resolve config path from context or default."""
    from posthumous.config import Config
    return ctx.obj.get('config_path') or Config.get_default_config_path()


def _load_config_or_exit(ctx: click.Context, hint_init: bool = False) -> tuple[Path, Config]:
    """Resolve the config path, exit 1 if missing, else return (path, Config).

    If ``hint_init`` is True, a follow-up "Run 'posthumous init' first."
    hint is printed before exiting.
    """
    from posthumous.config import Config

    config_path = _resolve_config_path(ctx)
    if not config_path.exists():
        click.echo(f"Config not found at {config_path}", err=True)
        if hint_init:
            click.echo("Run 'posthumous init' first.", err=True)
        sys.exit(1)
    return config_path, Config.from_yaml(config_path)


def _redact_secret(secret: str) -> str:
    """Redact a secret key, showing only the first 4 characters."""
    if len(secret) <= 4:
        return "****"
    return secret[:4] + "****"


@main.group()
@click.pass_context
def config(ctx: click.Context) -> None:
    """View, validate, and edit configuration."""
    pass


@config.command()
@click.pass_context
def path(ctx: click.Context) -> None:
    """Show file and directory locations."""
    config_path = _resolve_config_path(ctx)
    config_dir = config_path.parent

    paths = [
        ("Config file", config_path),
        ("State file", config_dir / "state.yaml"),
        ("Scripts dir", config_dir / "scripts"),
        ("Logs dir", config_dir / "logs"),
    ]

    for label, p in paths:
        marker = "exists" if p.exists() else "missing"
        click.echo(f"{label}: {p} [{marker}]")


@config.command()
@click.pass_context
def show(ctx: click.Context) -> None:
    """Print current config with secret_key redacted."""
    import yaml

    _, cfg = _load_config_or_exit(ctx)
    data = cfg.to_dict()
    data['secret_key'] = _redact_secret(data.get('secret_key', ''))

    click.echo(yaml.dump(data, default_flow_style=False, sort_keys=False), nl=False)


@config.command()
@click.pass_context
def validate(ctx: click.Context) -> None:
    """Validate configuration and report errors."""
    _, cfg = _load_config_or_exit(ctx)
    errors = cfg.validate()

    if errors:
        click.echo("Configuration errors:", err=True)
        for error in errors:
            click.echo(f"  - {error}", err=True)
        sys.exit(1)
    else:
        click.echo("Config OK")


@config.command()
@click.pass_context
def edit(ctx: click.Context) -> None:
    """Open config in $EDITOR, then validate on close."""
    from posthumous.config import Config

    config_path, _ = _load_config_or_exit(ctx, hint_init=True)

    editor = os.environ.get('VISUAL') or os.environ.get('EDITOR') or 'vi'
    subprocess.call([editor, str(config_path)])

    # Validate after editing
    try:
        cfg = Config.from_yaml(config_path)
        errors = cfg.validate()
        if errors:
            click.echo("Validation errors after edit:", err=True)
            for error in errors:
                click.echo(f"  - {error}", err=True)
        else:
            click.echo("Config OK")
    except Exception as e:
        click.echo(f"Failed to parse config: {e}", err=True)


@main.group()
def service():
    """Manage the systemd service."""
    pass


@service.command()
@click.pass_context
def install(ctx: click.Context) -> None:
    """Install and start the systemd user service."""
    from posthumous.systemd import generate_unit_file, get_unit_path

    config_path, config = _load_config_or_exit(ctx)
    unit_content = generate_unit_file(
        python_path=sys.executable,
        config_path=str(config_path.resolve()),
        node_name=config.node_name,
    )

    unit_path = get_unit_path()
    unit_path.parent.mkdir(parents=True, exist_ok=True)
    unit_path.write_text(unit_content)
    click.echo(f"Unit file written to {unit_path}")

    subprocess.run(["systemctl", "--user", "daemon-reload"], check=True)
    subprocess.run(["systemctl", "--user", "enable", "--now", "posthumous"], check=True)
    click.echo("Service installed, enabled, and started.")


@service.command()
def uninstall() -> None:
    """Stop, disable, and remove the systemd user service."""
    from posthumous.systemd import get_unit_path

    unit_path = get_unit_path()
    if not unit_path.exists():
        click.echo("Service is not installed.", err=True)
        sys.exit(1)

    subprocess.run(["systemctl", "--user", "stop", "posthumous"], check=False)
    subprocess.run(["systemctl", "--user", "disable", "posthumous"], check=False)
    unit_path.unlink()
    subprocess.run(["systemctl", "--user", "daemon-reload"], check=True)
    click.echo("Service stopped, disabled, and removed.")


@service.command('status')
def service_status() -> None:
    """Show systemd service status."""
    subprocess.run(["systemctl", "--user", "status", "posthumous"])


@service.command()
@click.option('--follow', '-f', is_flag=True, help='Follow log output')
def logs(follow: bool) -> None:
    """Show service journal logs."""
    cmd = ["journalctl", "--user", "-u", "posthumous", "--no-pager"]
    if follow:
        cmd.append("-f")
    subprocess.run(cmd)


@main.command()
@click.option('--node-name', prompt='Node name', help='Name for this node')
@click.option('--join', 'join_url', help='URL of existing node to join')
@click.pass_context
def init(ctx: click.Context, node_name: str, join_url: str | None) -> None:
    """Initialize a new Posthumous node."""
    from posthumous.auth import generate_secret, generate_qr_code_terminal, get_provisioning_uri
    from posthumous.config import Config, generate_default_config
    from posthumous.scripts import create_example_script

    config_path = ctx.obj.get('config_path') or Config.get_default_config_path()
    config_dir = config_path.parent

    if config_path.exists():
        click.echo(f"Config already exists at {config_path}", err=True)
        click.echo("Delete it first if you want to reinitialize.", err=True)
        sys.exit(1)

    # Generate or fetch secret
    if join_url:
        click.echo(f"Joining existing federation at {join_url}...")
        # In a real implementation, we'd fetch the secret securely
        # For now, prompt for it
        secret = click.prompt(
            "Enter the shared secret from an existing node",
            hide_input=True,
        )
    else:
        secret = generate_secret()
        click.echo("Generated new TOTP secret.")

    # Create config
    config = generate_default_config(node_name, secret)
    config.config_dir = config_dir

    # Create directories
    config_dir.mkdir(parents=True, exist_ok=True)
    (config_dir / "logs").mkdir(exist_ok=True)
    (config_dir / "scripts").mkdir(exist_ok=True)

    # Save config
    config.save(config_path)
    click.echo(f"Config created at {config_path}")

    # Create example script
    script_path = create_example_script(config_dir)
    click.echo(f"Example script created at {script_path}")

    # Show QR code for TOTP setup
    click.echo("\n" + "=" * 50)
    click.echo("TOTP Setup - Scan with your authenticator app:")
    click.echo("=" * 50 + "\n")

    try:
        qr = generate_qr_code_terminal(secret, node_name)
        click.echo(qr)
    except ImportError:
        click.echo("(QR code display requires 'qrcode' package)")

    click.echo(f"\nManual entry URI: {get_provisioning_uri(secret, node_name)}")
    click.echo(f"Secret: {secret}")
    click.echo("\n" + "=" * 50)
    click.echo("IMPORTANT: Save this secret securely!")
    click.echo("You'll need it to set up additional nodes.")
    click.echo("=" * 50)

    click.echo("\nNext steps:")
    click.echo("  1. Add the TOTP to your authenticator app")
    click.echo("  2. Edit ~/.posthumous/config.yaml to configure notifications")
    click.echo("  3. Run: posthumous run")


@main.command()
@click.option('--daemon', '-d', is_flag=True, help='Run in background')
@click.option('--stop', is_flag=True, help='Stop a running daemon')
@click.pass_context
def run(ctx: click.Context, daemon: bool, stop: bool) -> None:
    """Start the Posthumous daemon."""
    from posthumous.runner import DaemonRunner

    _, config = _load_config_or_exit(ctx, hint_init=True)

    # Handle --stop before validation (just need config_dir for PID file)
    if stop:
        import time
        pid_path = config.config_dir / "posthumous.pid"
        if not pid_path.exists():
            click.echo("No PID file found. Is the daemon running?", err=True)
            sys.exit(1)

        try:
            pid = int(pid_path.read_text().strip())
        except ValueError:
            click.echo(f"PID file at {pid_path} is corrupt, removing it.", err=True)
            pid_path.unlink(missing_ok=True)
            sys.exit(1)

        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            click.echo(f"No process with PID {pid}. Removing stale PID file.")
            pid_path.unlink(missing_ok=True)
            return

        click.echo(f"Sent SIGTERM to PID {pid}")
        for _ in range(20):
            try:
                os.kill(pid, 0)
                time.sleep(0.5)
            except ProcessLookupError:
                pid_path.unlink(missing_ok=True)
                click.echo("Daemon stopped.")
                return
        click.echo(f"Process {pid} still running. Try: kill -9 {pid}", err=True)
        sys.exit(1)

    errors = config.validate()
    if errors:
        click.echo("Configuration errors:", err=True)
        for error in errors:
            click.echo(f"  - {error}", err=True)
        sys.exit(1)

    # Setup logging
    log_file = config.config_dir / "logs" / "posthumous.log"
    setup_logging(ctx.obj.get('verbose', False), log_file)

    if daemon:
        from posthumous.systemd import is_service_installed
        if is_service_installed():
            click.echo("Systemd service is installed. Use 'systemctl --user start posthumous' instead.")
            sys.exit(0)

        # Double-fork daemonization
        pid = os.fork()
        if pid > 0:
            sys.exit(0)
        os.setsid()
        pid = os.fork()
        if pid > 0:
            sys.exit(0)

        # Detach from parent's cwd (so we don't pin an unmount) and set a
        # restrictive umask so daemon-created files aren't world-readable.
        os.chdir("/")
        os.umask(0o077)

        # Redirect stdio
        devnull = os.open(os.devnull, os.O_RDWR)
        os.dup2(devnull, 0)
        log_path = config.config_dir / "logs" / "daemon.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_fd = os.open(str(log_path), os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        os.dup2(log_fd, 1)
        os.dup2(log_fd, 2)
        os.close(devnull)
        os.close(log_fd)

        # Write PID file
        pid_path = config.config_dir / "posthumous.pid"
        pid_path.write_text(str(os.getpid()))

    click.echo(f"Starting Posthumous node '{config.node_name}'...")

    # Build the runner up front so state recovery (if needed) and the main
    # daemon lifecycle use the same instance. The recovery is run in its own
    # asyncio.run() call so that any aiohttp sessions it opened are fully
    # torn down before the daemon loop starts.
    runner = DaemonRunner(config)
    asyncio.run(runner.attempt_state_recovery())
    runner.build_components()

    try:
        asyncio.run(runner.run())
    except KeyboardInterrupt:
        pass


@main.command()
@click.option('--token', '-t', help='Use API token instead of TOTP')
@click.pass_context
def checkin(ctx: click.Context, token: str | None) -> None:
    """Check in to reset the timer."""
    from posthumous.state import StateManager, Status
    from posthumous.auth import Authenticator, LockedOutError, AuthError

    _, config = _load_config_or_exit(ctx)
    state_manager = StateManager(config.config_dir / "state.yaml", config.get_encryption_secret())

    if state_manager.state.status == Status.TRIGGERED:
        click.echo("Node is already TRIGGERED. Check-in not possible.", err=True)
        sys.exit(1)

    authenticator = Authenticator(
        secret=config.secret_key,
        api_token=config.api_token,
        max_attempts=config.max_failed_attempts,
        lockout_duration=config.lockout_duration,
    )

    # Get code
    code = None
    if not token:
        code = click.prompt("TOTP code", hide_input=False)

    try:
        success = authenticator.verify(
            code=code,
            token=token,
            state=state_manager.state,
            source="cli",
        )
    except LockedOutError as e:
        state_manager.save()
        click.echo(str(e), err=True)
        sys.exit(1)
    except AuthError as e:
        click.echo(str(e), err=True)
        sys.exit(1)

    if not success:
        state_manager.save()
        click.echo("Invalid code.", err=True)
        sys.exit(1)

    # Record check-in
    state_manager.checkin()

    # Calculate next deadline
    next_deadline = state_manager.state.last_checkin + config.trigger_at

    click.echo(f"✓ Check-in accepted")
    click.echo(f"  Status: {state_manager.state.status.value.upper()}")
    click.echo(f"  Next deadline: {next_deadline.strftime('%Y-%m-%d %H:%M UTC')}")


@main.command()
@click.pass_context
def status(ctx: click.Context) -> None:
    """Show current status."""
    from posthumous.state import StateManager
    from posthumous.watchdog import Watchdog, format_time_remaining

    _, config = _load_config_or_exit(ctx)
    state_manager = StateManager(config.config_dir / "state.yaml", config.get_encryption_secret())
    watchdog = Watchdog(config, state_manager)

    state = state_manager.state
    tr = watchdog.get_time_remaining()

    click.echo(f"Node: {config.node_name}")
    click.echo(f"Status: {state.status.value.upper()}")

    if state.last_checkin:
        click.echo(f"Last check-in: {state.last_checkin.strftime('%Y-%m-%d %H:%M UTC')}")

    if state.trigger_time:
        click.echo(f"Triggered at: {state.trigger_time.strftime('%Y-%m-%d %H:%M UTC')}")

    click.echo()
    click.echo(format_time_remaining(tr))

    # Show peer status if configured
    if config.peers:
        click.echo()
        click.echo("Peers:")
        for url in config.peers:
            peer_state = state.peer_states.get(url)
            if peer_state and peer_state.last_seen:
                age = datetime.now(timezone.utc) - peer_state.last_seen
                click.echo(f"  {url}: seen {int(age.total_seconds()) // 60}m ago")
            else:
                click.echo(f"  {url}: unknown")


@main.command()
@click.option('--force', is_flag=True, help='Skip confirmation prompt')
@click.pass_context
def reset(ctx: click.Context, force: bool) -> None:
    """Reset state to ARMED (administrative recovery)."""
    from posthumous.state import StateManager, Status

    _, config = _load_config_or_exit(ctx)
    state_manager = StateManager(config.config_dir / "state.yaml", config.get_encryption_secret())
    current = state_manager.state.status

    if current == Status.ARMED:
        click.echo("Already ARMED. Nothing to reset.")
        return

    if current == Status.TRIGGERED and not force:
        click.confirm(
            "Node is TRIGGERED. This is irreversible. Reset to ARMED?",
            abort=True,
        )
    elif not force:
        click.confirm(f"Reset from {current.value.upper()} to ARMED?", abort=True)

    state_manager.reset()
    click.echo("State reset to ARMED.")


@main.command()
@click.option('--force', is_flag=True, help='Skip confirmation prompt')
@click.pass_context
def recover(ctx: click.Context, force: bool) -> None:
    """Recover state from the healthiest peer."""
    from posthumous.state import StateManager
    from posthumous.peers import PeerManager, pick_best_peer

    _, config = _load_config_or_exit(ctx)
    state_manager = StateManager(config.config_dir / "state.yaml", config.get_encryption_secret())

    async def do_recover():
        peer_manager = PeerManager(config, state_manager)
        try:
            # Fetch peer statuses once; pass them through to sync_state_from_peers
            # below so we don't issue a second round of requests.
            statuses = await peer_manager.get_all_peer_status()

            if not force:
                # Show local state
                local = state_manager.state
                click.echo("Local state:")
                click.echo(f"  status:       {local.status.value}")
                click.echo(f"  last_checkin: {local.last_checkin or 'never'}")
                click.echo(f"  trigger_time: {local.trigger_time or 'none'}")
                click.echo(f"  schedule:     {len(local.schedule_state)} items")

                best = pick_best_peer(statuses)
                if best:
                    click.echo(f"\nPeer state ({best.url}):")
                    click.echo(f"  status:       {best.status or 'unknown'}")
                    click.echo(f"  last_checkin: {best.last_checkin or 'never'}")
                else:
                    click.echo("\nNo reachable peers with state to compare.")
                    return

                click.echo()
                if not click.confirm("Overwrite local state from peer?"):
                    click.echo("Aborted.")
                    return

            success = await peer_manager.sync_state_from_peers(statuses)
            if success:
                click.echo("State recovered from peer successfully.")
            else:
                click.echo("No peers available for recovery.", err=True)
                sys.exit(1)
        finally:
            await peer_manager.close()

    asyncio.run(do_recover())


@main.command()
@click.pass_context
def peers(ctx: click.Context) -> None:
    """Show peer status."""
    from posthumous.state import StateManager
    from posthumous.peers import PeerManager, format_peer_status

    _, config = _load_config_or_exit(ctx)

    if not config.peers:
        click.echo("No peers configured.")
        return

    state_manager = StateManager(config.config_dir / "state.yaml", config.get_encryption_secret())
    peer_manager = PeerManager(config, state_manager)

    async def check_peers():
        statuses = await peer_manager.get_all_peer_status()
        await peer_manager.close()

        click.echo("Peers:")
        for status in statuses:
            click.echo(f"  {format_peer_status(status)}")

    asyncio.run(check_peers())


@main.command('test-notify')
@click.option('--channel', '-c', help='Test specific channel (default: all)')
@click.pass_context
def test_notify(ctx: click.Context, channel: str | None) -> None:
    """Send test notifications."""
    from posthumous.notifications import NotificationManager

    _, config = _load_config_or_exit(ctx)
    manager = NotificationManager(config.notifications)

    async def test():
        if channel:
            if channel not in config.notifications:
                click.echo(f"Unknown channel: {channel}", err=True)
                return
            result = await manager.test_channel(channel)
            status = "✓" if result.success else "✗"
            click.echo(f"{status} {channel}: {result.error or 'OK'}")
        else:
            results = await manager.test_all_channels()
            for name, result in results.items():
                status = "✓" if result.success else "✗"
                click.echo(f"{status} {name}: {result.error or 'OK'}")

    asyncio.run(test())


@main.command('test-trigger')
@click.pass_context
def test_trigger(ctx: click.Context) -> None:
    """Show what would happen on trigger (always dry run)."""
    from posthumous.config import NotificationAction, ScriptAction

    _, config = _load_config_or_exit(ctx)

    click.echo("Trigger actions that would execute:")
    click.echo()

    for i, action in enumerate(config.on_trigger, 1):
        if isinstance(action, NotificationAction):
            click.echo(f"  {i}. Notify channel '{action.channel}':")
            click.echo(f"     Message: {action.message}")
        elif isinstance(action, ScriptAction):
            script_path = config.get_script_path(action.script)
            exists = "✓" if script_path.exists() else "✗ NOT FOUND"
            click.echo(f"  {i}. Run script: {action.script} ({exists})")

    click.echo()
    click.echo("Post-trigger scheduled items:")
    for item in config.post_trigger:
        click.echo(f"  - {item.name}: {item.when}")


@main.command()
@click.argument('output', type=click.Path(path_type=Path))
@click.option('--decrypt', is_flag=True, default=False,
              help='Export in plaintext (default; decrypts encrypted state files).')
@click.pass_context
def export(ctx: click.Context, output: Path, decrypt: bool) -> None:
    """Export state for backup.

    Always exports in plaintext YAML. If state is encrypted at rest,
    it is transparently decrypted for the export.
    """
    import yaml
    from posthumous.state import StateManager

    _, config = _load_config_or_exit(ctx)
    state_manager = StateManager(config.config_dir / "state.yaml", config.get_encryption_secret())

    data = {
        'config': config.to_dict(),
        'state': state_manager.state.to_dict(),
    }

    with open(output, 'w') as f:
        yaml.dump(data, f, default_flow_style=False)
    os.chmod(output, 0o600)

    if config.encrypt_at_rest:
        click.echo(f"Exported to {output} (decrypted)")
    else:
        click.echo(f"Exported to {output}")


@main.command('import')
@click.argument('input_file', type=click.Path(exists=True, path_type=Path))
@click.pass_context
def import_state(ctx: click.Context, input_file: Path) -> None:
    """Import state from backup."""
    import yaml
    from posthumous.config import Config
    from posthumous.state import State, StateManager

    config_path = ctx.obj.get('config_path') or Config.get_default_config_path()

    with open(input_file) as f:
        data = yaml.safe_load(f)

    if 'state' not in data:
        click.echo("No state found in backup file", err=True)
        sys.exit(1)

    # Load or create config
    if config_path.exists():
        config = Config.from_yaml(config_path)
    else:
        if 'config' not in data:
            click.echo("No config in backup and no existing config", err=True)
            sys.exit(1)
        config = Config.from_dict(data['config'])
        config.config_dir = config_path.parent
        config.save(config_path)
        click.echo(f"Config restored to {config_path}")

    # Restore state
    state = State.from_dict(data['state'])
    state_path = config.config_dir / "state.yaml"
    state.save(state_path, encryption_secret=config.get_encryption_secret())

    click.echo(f"State restored. Status: {state.status.value}")


if __name__ == "__main__":
    main()
