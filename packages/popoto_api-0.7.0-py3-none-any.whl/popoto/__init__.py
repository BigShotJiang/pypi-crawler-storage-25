"""Popoto package exports."""

import logging

from . import popoto as _popoto

# Re-export everything from the legacy module path so existing imports keep working.
logging.getLogger(__name__).addHandler(logging.NullHandler())

__all__ = getattr(_popoto, "__all__", [name for name in dir(_popoto) if not name.startswith("_")])

globals().update({name: getattr(_popoto, name) for name in __all__})

del _popoto
