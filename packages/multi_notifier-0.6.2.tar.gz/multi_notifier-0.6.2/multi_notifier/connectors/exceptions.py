"""All connector exceptions."""

import multi_notifier.exceptions


class ConnectorError(multi_notifier.exceptions.NotificationError):
    """Error which is raised by connectors."""


class ConnectorConfigurationError(ConnectorError):
    """Error which is raised if configuration is faulty."""


class ConnectorTimeoutError(ConnectorError):
    """Error which is raised if a timeout is raised."""
