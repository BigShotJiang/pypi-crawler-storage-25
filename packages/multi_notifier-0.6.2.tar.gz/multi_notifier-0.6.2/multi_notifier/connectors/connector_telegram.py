"""Module for communication with Telegram, Mail, ..."""

import asyncio
import logging
from pathlib import Path

import pydantic
from aiogram import Bot
from aiogram.types import InputMediaAudio, InputMediaDocument, InputMediaLivePhoto, InputMediaPhoto, InputMediaVideo, Message, MessageEntity
from aiogram.types.input_file import FSInputFile
from sulguk import transform_html

import multi_notifier.connectors.exceptions
import multi_notifier.connectors.interface

LOGGER = logging.getLogger(__name__)


async def _send_html_message_async(token: str, chat_id: int | str, text: str, images: dict[str, Path] | None = None) -> list[Message]:
    if images is None:
        images = {}

    # Transform HTML to get text and entities
    render_result = transform_html(text)

    # Convert sulguk entities to aiogram MessageEntity objects
    entities = None
    if render_result.entities:
        entities = [MessageEntity(type=entity["type"], offset=entity["offset"], length=entity["length"]) for entity in render_result.entities]

    if images:
        # Create media group with photos
        media: list[InputMediaAudio | InputMediaDocument | InputMediaLivePhoto | InputMediaPhoto | InputMediaVideo] = []
        for i, file_path in enumerate(images.values()):
            input_file = FSInputFile(file_path)
            if i == 0:
                media.append(InputMediaPhoto(media=input_file, caption=render_result.text, caption_entities=entities))
            else:
                media.append(InputMediaPhoto(media=input_file))

        async with Bot(token=token) as bot:
            return await bot.send_media_group(chat_id=chat_id, media=media)

    # Message without media
    async with Bot(token=token) as bot:
        response = await bot.send_message(chat_id=chat_id, text=render_result.text, entities=entities)
    return [response]


class TelegramConfig(pydantic.BaseModel):
    """Config for telegram connector."""

    bot_token: str


class Telegram(multi_notifier.connectors.interface.Interface):
    """Class to send Telegram messages."""

    def __init__(self, telegram_config: TelegramConfig) -> None:
        """Init Telegram class.

        Args:
            telegram_config: config for telegram connector

        Raises:
            multi_notifier.connectors.exceptions.ConnectorConfigurationError: if bot configuration is not correct
        """
        self._config = telegram_config
        asyncio.run(self._test_config())

    async def _test_config(self) -> None:
        """Test if bot token is correct.

        Raises:
            multi_notifier.connectors.exceptions.ConnectorConfigurationError: if bot token is not correct
        """
        try:
            async with Bot(token=self._config.bot_token) as bot:
                await bot.get_me()
        except Exception as exc:
            LOGGER.exception(msg := "Bot config not valid")
            raise multi_notifier.connectors.exceptions.ConnectorConfigurationError(msg) from exc

    def send_message(self, recipient: str | list[str], message: str, subject: str | None = None, images: dict[str, Path] | None = None) -> None:
        """Send a message to one or multiple recipients.

        Args:
            recipient: single recipient or list of recipients
            message: message which should be sent
            subject: subject will be added to the prefix
            images: images which should be sent

        Raises:
            multi_notifier.connectors.exceptions.ConnectorError: if telegram could not be sent
        """
        recipient = recipient if isinstance(recipient, list) else [recipient]
        msg_with_subject = f"{subject}: {message}" if subject else message

        for chat_id in recipient:
            LOGGER.debug(f"Send message to {recipient}")
            try:
                asyncio.run(_send_html_message_async(self._config.bot_token, chat_id, msg_with_subject, images))
            except Exception as exc:
                msg = f"Failed to send message to {chat_id}"
                raise multi_notifier.connectors.exceptions.ConnectorError(msg) from exc

    @staticmethod
    def is_valid_recipient(recipient: str) -> bool:
        """Check if the given recipient is valid.

        Args:
            recipient: Single recipient which should be checked

        Returns:
            True if recipient has a supported format, else False
        """
        if recipient.isdigit():
            return True
        LOGGER.warning(f"The recipient '{recipient}' is not valid !")
        return False
