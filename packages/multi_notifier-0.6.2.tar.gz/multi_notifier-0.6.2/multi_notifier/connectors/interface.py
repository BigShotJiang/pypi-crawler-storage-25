"""Interface for all connectors."""

import abc
from abc import ABC
from pathlib import Path


class Interface(ABC):
    """Interface for all connectors."""

    @abc.abstractmethod
    def send_message(self, recipient: str | list[str], message: str, subject: str | None = None, images: dict[str, Path] | None = None) -> None:
        """Send a message to one or multiple recipients.

        Args:
            recipient: recipient or recipients of the message which should be sent
            message: content of the message
            subject: subject of the message
            images: images which should be sent

        Raises:
            multi_notifier.connectors.exceptions.ConnectorError: if message could not be sent
        """

    @staticmethod
    @abc.abstractmethod
    def is_valid_recipient(recipient: str) -> bool:
        """Check if the given recipient is valid.

        Args:
            recipient: Single recipient which should be checked

        Returns:
            True if recipient has a supported format, else False
        """
