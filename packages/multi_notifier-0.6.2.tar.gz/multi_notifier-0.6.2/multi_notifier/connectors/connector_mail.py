"""Connector for mail."""

import html
import logging
import re
import smtplib
import ssl
from email.charset import QP, Charset
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formatdate, make_msgid
from pathlib import Path

import pydantic

import multi_notifier.connectors.exceptions
import multi_notifier.connectors.interface

LOGGER = logging.getLogger(__name__)


class MailConfig(pydantic.BaseModel):
    """Config for mail connector."""

    user: str
    password: str
    smtp_host: str
    smtp_port: int


class Mail(multi_notifier.connectors.interface.Interface):
    """Class to send e-mails."""

    __html_pattern = re.compile(r"<[^<]+?>")

    def __init__(self, mail_config: MailConfig) -> None:
        """Init Mail class.

        Args:
            mail_config: config for mail connector

        Raises:
            multi_notifier.connectors.exceptions.ConnectorConfigurationError: If mail configuration is faulty
        """
        self.config = mail_config
        self.smtp_host = mail_config.smtp_host
        self.smtp_port = mail_config.smtp_port
        self.user = mail_config.user
        self.password = mail_config.password

    def _create_msg(self, recipients: list[str], message: str, subject: str | None = None, images: dict[str, Path] | None = None) -> MIMEMultipart:  # noqa: C901, PLR0915
        """Create a MIME multipart message with optional images and HTML support.

        Args:
            recipients: list of recipients (email addresses).
            message: Message content (plain text or HTML).
            subject: Subject line of the email. Defaults to "No Subject" if not provided.
            images: Dictionary mapping Content-ID to image file paths for embedded images.

        Returns:
            MIMEMultipart: A MIME message object ready to be sent via SMTP.

        Raises:
            No direct exceptions, but logs warnings if image files are not found.
        """
        if images is None:
            images = {}

        # check if content of message is HTML and set text / HTML
        is_html = bool(self.__html_pattern.search(message))

        # Create MIME message structure
        # For emails with images and HTML:
        #   related - root
        #   └── alternative (text/html variants)
        #       ├── text/plain
        #       └── text/html
        #   └── image1, image2, ... (embedded images with Content-ID)
        #
        # For emails with images and plain text:
        #   mixed - root
        #   ├── alternative (text/plain)
        #   └── image1, image2, ... (regular attachments)
        #
        # For emails without images:
        #   alternative - root
        #   ├── text/plain
        #   └── text/html (if HTML)
        if images and not is_html:
            # Plain text with images: use multipart/mixed for regular attachments
            msg = MIMEMultipart("mixed")
            alternative = MIMEMultipart("alternative")
            msg.attach(alternative)
        elif images and is_html:
            # HTML with images: use multipart/related for embedded images
            msg = MIMEMultipart("related")
            alternative = MIMEMultipart("alternative")
            msg.attach(alternative)
        else:
            # No images: simple alternative structure
            msg = MIMEMultipart("alternative")
            # Smart alias: When no images exist, msg and alternative point to the same object.
            # This allows the code below to always use "alternative.attach()" regardless
            # of whether images are present or not.
            alternative = msg

        msg["Subject"] = subject or "No Subject"
        msg["From"] = self.user
        msg["MIME-Version"] = "1.0"
        msg["Message-ID"] = make_msgid(domain=self.smtp_host)
        msg["Date"] = formatdate(localtime=True)
        msg["To"] = ", ".join(recipients)

        # Add text and HTML parts with explicit UTF-8 charset
        # Charset encoding: Use quoted-printable to keep emails readable and smaller than base64
        charset = Charset("utf-8")
        charset.header_encoding = QP
        charset.body_encoding = QP
        if is_html:
            # Create plain text version from HTML
            # This provides a fallback for email clients that don't support HTML
            plain_text = self.__html_pattern.sub("", message)
            # Clean up extra whitespace and decode HTML entities
            plain_text = html.unescape(plain_text)
            plain_text = re.sub(r"\s+", " ", plain_text).strip()

            text_part = MIMEText(plain_text, "plain", _charset="utf-8")
            html_part = MIMEText(message, "html", _charset="utf-8")
            # Apply quoted-printable encoding for better email compatibility
            text_part.set_charset(charset)
            html_part.set_charset(charset)
            # Attach both alternatives: email client chooses the best one it can render
            alternative.attach(text_part)
            alternative.attach(html_part)
        else:
            text_part = MIMEText(message, "plain", _charset="utf-8")
            text_part.set_charset(charset)
            alternative.attach(text_part)

        # Add images
        if is_html:
            # For HTML messages: embed images with Content-ID for HTML reference
            # Images are attached to the 'msg' object (the root container), not to 'alternative'.
            # This ensures images are in the multipart/related structure, allowing them to be
            # referenced by their Content-ID in HTML img tags: <img src="cid:image_id">
            for cid, image_path in images.items():
                try:
                    img_data = image_path.read_bytes()
                    img = MIMEImage(img_data)
                    # Set Content-ID header: allows HTML to reference this image via src="cid:..."
                    img.add_header("Content-ID", f"<{cid}>")
                    msg.attach(img)
                except FileNotFoundError:
                    LOGGER.warning(f"Image file not found: {image_path}")
                    continue
        elif images:
            # For plain text messages: add images as regular attachments
            for image_path in images.values():
                try:
                    img_data = image_path.read_bytes()
                    img = MIMEImage(img_data)
                    # Add filename and disposition for regular attachment
                    filename = image_path.name
                    img.add_header("Content-Disposition", f'attachment; filename="{filename}"')
                    msg.attach(img)
                except FileNotFoundError:
                    LOGGER.warning(f"Image file not found: {image_path}")
                    continue

        return msg

    def send_message(self, recipient: str | list[str], message: str, subject: str | None = None, images: dict[str, Path] | None = None) -> None:
        """Send a message to one or multiple recipients.

        Args:
            recipient: one or multiple recipients. (Must be mail addresses!)
            message: Message which should be sent
            subject: Subject of the mail
            images: Images which will be added to the mail

        Raises:
            multi_notifier.connectors.exceptions.ConnectorError: if mail could not be sent
        """
        LOGGER.debug(f"Sending mail to {recipient} with subject '{subject}' and message '{message[:20]}'")
        recipient_list = recipient if isinstance(recipient, list) else [recipient]
        msg = self._create_msg(recipient_list, message, subject, images)

        try:
            # Create SMTP session
            context = ssl.create_default_context()
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                server.starttls(context=context)
                server.login(self.user, self.password)

                # Send email
                server.send_message(msg, to_addrs=recipient_list)

        except Exception as exc:
            error_msg = "Could not send mail"
            LOGGER.exception(error_msg)
            raise multi_notifier.connectors.exceptions.ConnectorError(error_msg) from exc

    @staticmethod
    def is_valid_recipient(recipient: str) -> bool:
        """Check if the given recipient is valid.

        Args:
            recipient: Single recipient which should be checked

        Returns:
            True if recipient has a supported format, else False.
        """
        if re.fullmatch(r"[^@]+@[^@]+\.[^@]+", recipient):
            return True
        LOGGER.warning(f"The recipient '{recipient}' is not valid !")
        return False
