"""Errors of notification SEND_HANDLER package."""


class NotificationError(Exception):
    """Error which is raised by this python package."""


class ConfigurationError(NotificationError):
    """Error which is raised if configuration is faulty."""
