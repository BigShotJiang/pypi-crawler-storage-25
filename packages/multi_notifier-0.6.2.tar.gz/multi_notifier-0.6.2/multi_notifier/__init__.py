"""Init file of send_handler."""

__version__ = "0.6.2"
