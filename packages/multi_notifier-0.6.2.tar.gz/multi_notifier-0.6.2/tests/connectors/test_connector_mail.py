import smtplib
import ssl
from email.mime.multipart import MIMEMultipart
from pathlib import Path

import pytest
from pytest import LogCaptureFixture
from pytest_mock import MockerFixture

from multi_notifier.connectors.connector_mail import Mail
from multi_notifier.connectors.exceptions import ConnectorError


@pytest.mark.parametrize(
    "message, images, expected_content_type, expected_structure",
    [
        # Plain text, no images
        ("Simple text message", None, "multipart/alternative", {"has_text": True, "has_html": False, "has_images": False}),
        # Plain text with images
        ("Text with images", {"img1": Path("test.png")}, "multipart/mixed", {"has_text": True, "has_html": False, "has_images": True}),
        # HTML, no images
        ("<p>HTML message</p>", None, "multipart/alternative", {"has_text": True, "has_html": True, "has_images": False}),
        # HTML with images
        (
            '<p>HTML with <img src="cid:img1">image</p>',
            {"img1": Path("test.png")},
            "multipart/related",
            {"has_text": True, "has_html": True, "has_images": True},
        ),
    ],
)
def test_create_msg_structure(
    mail_connector: Mail,
    sample_image_path: Path,
    message: str,
    images: dict[str, Path],
    expected_content_type: str,
    expected_structure: dict[str, bool],
) -> None:
    """Test _create_msg with different combinations of text/HTML and images."""
    recipients = ["test@test.com"]
    subject = "Test Subject"

    # Replace image paths with actual test image path
    if images:
        images = dict.fromkeys(images.keys(), sample_image_path)

    msg = mail_connector._create_msg(recipients, message, subject, images)

    # Test basic message structure
    assert isinstance(msg, MIMEMultipart)
    assert msg.get_content_type() == expected_content_type
    assert msg["Subject"] == subject
    assert msg["From"] == "test@test.com"
    assert msg["To"] == "test@test.com"
    assert msg["MIME-Version"] == "1.0"
    assert "Message-ID" in msg
    assert "Date" in msg

    # Test content parts
    parts = list(msg.walk())

    # Count different part types
    text_parts = [p for p in parts if p.get_content_type() == "text/plain"]
    html_parts = [p for p in parts if p.get_content_type() == "text/html"]
    image_parts = [p for p in parts if p.get_content_type().startswith("image/")]

    # Test expected structure
    assert len(text_parts) == (1 if expected_structure["has_text"] else 0)
    assert len(html_parts) == (1 if expected_structure["has_html"] else 0)
    assert len(image_parts) == (1 if expected_structure["has_images"] else 0)

    # Test text content
    if expected_structure["has_text"]:
        text_part = text_parts[0]
        assert text_part.get_content_type() == "text/plain"
        assert text_part.get_charset() == "utf-8"
        if expected_structure["has_html"]:
            # For HTML messages, text should be stripped of HTML tags
            text_content = text_part.get_payload(decode=True).decode("utf-8")
            assert "HTML with" in text_content or "HTML message" in text_content
        else:
            text_content = text_part.get_payload(decode=True).decode("utf-8")
            assert message in text_content

    # Test HTML content
    if expected_structure["has_html"]:
        html_part = html_parts[0]
        assert html_part.get_content_type() == "text/html"
        assert html_part.get_charset() == "utf-8"
        html_content = html_part.get_payload(decode=True).decode("utf-8")
        assert message in html_content

    # Test image content
    if expected_structure["has_images"]:
        image_part = image_parts[0]
        assert image_part.get_content_type().startswith("image/")

        if expected_structure["has_html"]:
            # HTML messages should have Content-ID for embedding
            assert "Content-ID" in image_part
            assert "<img1>" in image_part.get("Content-ID")
        else:
            # Plain text messages should have Content-Disposition for attachment
            assert "Content-Disposition" in image_part
            assert "attachment" in image_part.get("Content-Disposition")
            assert "filename=" in image_part.get("Content-Disposition")


def test_create_msg_multiple_recipients(mail_connector: Mail) -> None:
    """Test _create_msg with multiple recipients."""
    recipients = ["test1@test.com", "test2@test.com"]
    message = "Test message to multiple recipients"

    msg = mail_connector._create_msg(recipients, message)

    assert msg["To"] == "test1@test.com, test2@test.com"


def test_create_msg_html_to_text_conversion(mail_connector: Mail) -> None:
    """Test that HTML is properly converted to plain text."""
    html_message = """
    <html>
        <body>
            <h1>Header</h1>
            <p>Paragraph with <b>bold</b> text.</p>
            <ul>
                <li>Item 1</li>
                <li>Item 2</li>
            </ul>
        </body>
    </html>
    """

    msg = mail_connector._create_msg(["test@test.com"], html_message)

    parts = list(msg.walk())
    text_parts = [p for p in parts if p.get_content_type() == "text/plain"]
    html_parts = [p for p in parts if p.get_content_type() == "text/html"]

    assert len(text_parts) == 1
    assert len(html_parts) == 1

    # Check that plain text version contains content without HTML tags
    text_content = text_parts[0].get_payload(decode=True).decode("utf-8")
    assert "Header" in text_content
    assert "bold" in text_content
    assert "Item 1" in text_content
    assert "Item 2" in text_content
    assert "<h1>" not in text_content
    assert "<b>" not in text_content

    # Check that HTML version is preserved
    html_content = html_parts[0].get_payload(decode=True).decode("utf-8")
    assert "<h1>Header</h1>" in html_content
    assert "<b>bold</b>" in html_content


def test_create_msg_missing_image_file_plain(
    mail_connector: Mail,
    caplog: LogCaptureFixture,
) -> None:
    """Test handling of missing image file for plain msg."""
    missing_image = {"img1": Path("nonexistent.png")}

    msg = mail_connector._create_msg(["test@test.com"], "Text with missing image", images=missing_image)

    # Should still create message, but log warning
    assert msg is not None
    assert "Image file not found" in caplog.text


def test_create_msg_missing_image_file_html(
    mail_connector: Mail,
    caplog: LogCaptureFixture,
) -> None:
    """Test handling of missing image file for HTML msg."""
    missing_image = {"img1": Path("nonexistent.png")}

    msg = mail_connector._create_msg(["test@test.com"], "<p>Text with missing image</p>", images=missing_image)

    # Should still create message, but log warning
    assert msg is not None
    assert "Image file not found" in caplog.text


@pytest.mark.parametrize(
    "recipient, is_valid",
    [
        ("mail", False),
        ("mail@domain", False),
        ("mail@domain.", False),
        ("@domain.de", False),
        ("domain.de", False),
        (".de", False),
        ("mail@domain.de", True),
    ],
)
def test_is_valid_recipient(recipient: str, is_valid: bool) -> None:
    """Test is_valid_recipient."""
    assert Mail.is_valid_recipient(recipient) == is_valid


def test_send_message_success_plain_text(mail_connector: Mail, mocker: MockerFixture) -> None:
    """Test successful sending of plain text message."""
    # Setup mocks
    mock_server = mocker.MagicMock()
    mock_smtp = mocker.patch("smtplib.SMTP")
    mock_smtp.return_value.__enter__.return_value = mock_server
    mock_ssl_context = mocker.patch("ssl.create_default_context")

    # Test data
    recipient = "test@test.com"
    message = "Test plain text message"
    subject = "Test Subject"

    # Execute
    mail_connector.send_message(recipient, message, subject)

    # Verify SMTP calls
    mock_smtp.assert_called_once_with("smtp.test.com", 587)
    mock_server.starttls.assert_called_once_with(context=mock_ssl_context.return_value)
    mock_server.login.assert_called_once_with("test@test.com", "testpass")
    mock_server.send_message.assert_called_once()

    # Check the message that was sent
    sent_msg = mock_server.send_message.call_args[0][0]
    assert isinstance(sent_msg, MIMEMultipart)
    assert sent_msg["To"] == recipient
    assert sent_msg["Subject"] == subject
    assert sent_msg["From"] == "test@test.com"


def test_send_message_success_html_with_images(mail_connector: Mail, mocker: MockerFixture, sample_image_path: Path) -> None:
    """Test successful sending of HTML message with images."""
    # Setup mocks
    mock_server = mocker.MagicMock()
    mock_smtp = mocker.patch("smtplib.SMTP")
    mock_smtp.return_value.__enter__.return_value = mock_server
    mock_ssl_context = mocker.patch("ssl.create_default_context")

    # Test data
    recipient = "test@test.com"
    message = '<p>HTML message with <img src="cid:img1">image</p>'
    subject = "HTML Test"
    images = {"img1": sample_image_path}

    # Execute
    mail_connector.send_message(recipient, message, subject, images)

    # Verify SMTP calls
    mock_smtp.assert_called_once_with("smtp.test.com", 587)
    mock_server.starttls.assert_called_once_with(context=mock_ssl_context.return_value)
    mock_server.login.assert_called_once_with("test@test.com", "testpass")
    mock_server.send_message.assert_called_once()

    # Check the message that was sent
    sent_msg = mock_server.send_message.call_args[0][0]
    assert isinstance(sent_msg, MIMEMultipart)
    assert sent_msg.get_content_type() == "multipart/related"
    assert sent_msg["To"] == recipient
    assert sent_msg["Subject"] == subject


def test_send_message_success_multiple_recipients(mail_connector: Mail, mocker: MockerFixture) -> None:
    """Test successful sending to multiple recipients."""
    # Setup mocks
    mock_server = mocker.MagicMock()
    mock_smtp = mocker.patch("smtplib.SMTP")
    mock_smtp.return_value.__enter__.return_value = mock_server
    mocker.patch("ssl.create_default_context")

    # Test data
    recipients = ["test1@test.com", "test2@test.com"]
    message = "Message to multiple recipients"

    # Execute
    mail_connector.send_message(recipients, message)

    # Verify the message was sent to all recipients
    sent_msg = mock_server.send_message.call_args[0][0]
    assert sent_msg["To"] == "test1@test.com, test2@test.com"

    # Verify send_message was called with correct recipients
    call_args = mock_server.send_message.call_args
    assert call_args[1]["to_addrs"] == recipients


@pytest.mark.parametrize(
    "error_scenario",
    [
        # SMTP error during send_message
        {"mock_target": "send_message", "exception": smtplib.SMTPException("SMTP connection failed")},
        # Authentication error during login
        {"mock_target": "login", "exception": smtplib.SMTPAuthenticationError(535, "Authentication failed")},
        # Connection error during SMTP connection
        {"mock_target": "smtp_connect", "exception": ConnectionError("Could not connect to SMTP server")},
        # SSL context creation error
        {"mock_target": "ssl_context", "exception": ssl.SSLError("SSL context creation failed")},
    ],
)
def test_send_message_errors(mail_connector: Mail, mocker: MockerFixture, error_scenario: dict) -> None:
    """Test handling of various errors during sending."""
    # Setup mocks
    mock_server = mocker.MagicMock()
    mock_smtp = mocker.patch("smtplib.SMTP")
    mock_smtp.return_value.__enter__.return_value = mock_server
    mock_ssl_context = mocker.patch("ssl.create_default_context")

    # Apply the specific error scenario
    mock_target = error_scenario["mock_target"]
    exception = error_scenario["exception"]

    if mock_target == "send_message":
        mock_server.send_message.side_effect = exception
    elif mock_target == "login":
        mock_server.login.side_effect = exception
    elif mock_target == "smtp_connect":
        mock_smtp.side_effect = exception
    elif mock_target == "ssl_context":
        mock_ssl_context.side_effect = exception

    # Test data
    recipient = "test@test.com"
    message = "Test message"

    # Execute and verify exception
    with pytest.raises(ConnectorError, match="Could not send mail"):
        mail_connector.send_message(recipient, message)


def test_send_message_with_default_subject(mail_connector: Mail, mocker: MockerFixture) -> None:
    """Test sending message without subject (should use default)."""
    # Setup mocks
    mock_server = mocker.MagicMock()
    mock_smtp = mocker.patch("smtplib.SMTP")
    mock_smtp.return_value.__enter__.return_value = mock_server
    mocker.patch("ssl.create_default_context")

    # Test data
    recipient = "test@test.com"
    message = "Test message without subject"

    # Execute
    mail_connector.send_message(recipient, message)  # No subject provided

    # Check the message that was sent
    sent_msg = mock_server.send_message.call_args[0][0]
    assert sent_msg["Subject"] == "No Subject"


def test_send_message_empty_images_dict(mail_connector: Mail, mocker: MockerFixture) -> None:
    """Test sending message with empty images dictionary."""
    # Setup mocks
    mock_server = mocker.MagicMock()
    mock_smtp = mocker.patch("smtplib.SMTP")
    mock_smtp.return_value.__enter__.return_value = mock_server
    mocker.patch("ssl.create_default_context")

    # Test data
    recipient = "test@test.com"
    message = "Test message"
    images = {}  # Empty dict

    # Execute
    mail_connector.send_message(recipient, message, images=images)

    # Verify message was sent successfully
    mock_server.send_message.assert_called_once()

    # Check the message structure (should be multipart/alternative, not mixed)
    sent_msg = mock_server.send_message.call_args[0][0]
    assert sent_msg.get_content_type() == "multipart/alternative"
