from pathlib import Path
from unittest.mock import AsyncMock, Mock

import pytest
from aiogram.types import Message, MessageEntity
from pytest_mock import MockerFixture

from multi_notifier.connectors.connector_telegram import Telegram, TelegramConfig, _send_html_message_async
from multi_notifier.connectors.exceptions import ConnectorConfigurationError

# =================================== _send_html_message_async Tests ===================================


async def test_send_html_message_async_plain_text_success(mocker: MockerFixture) -> None:
    """Test successful sending of plain text message without images."""
    # Setup mocks
    mock_render_result = Mock(text="Plain text message", entities=None)
    mock_transform_html = mocker.patch("multi_notifier.connectors.connector_telegram.transform_html", return_value=mock_render_result)

    mock_message = Mock(spec=Message)
    mock_bot = mocker.patch("multi_notifier.connectors.connector_telegram.Bot")
    mock_bot.return_value.__aenter__.return_value.send_message = AsyncMock(return_value=mock_message)

    # Test data
    token = "test_token"  # noqa: S105
    chat_id = "123456"
    text = "Plain text message"

    # Execute
    result = await _send_html_message_async(token, chat_id, text)

    # Verify calls
    mock_transform_html.assert_called_once_with(text)
    mock_bot.assert_called_once_with(token=token)
    mock_bot.return_value.__aenter__.return_value.send_message.assert_called_once_with(chat_id=chat_id, text="Plain text message", entities=None)

    # Verify result
    assert result == [mock_message]


async def test_send_html_message_async_html_with_entities_success(mocker: MockerFixture) -> None:
    """Test successful sending of HTML message with entities."""
    # Setup mocks
    mock_render_result = Mock(text="HTML message", entities=[{"type": "bold", "offset": 0, "length": 4}])
    mock_transform_html = mocker.patch("multi_notifier.connectors.connector_telegram.transform_html", return_value=mock_render_result)

    mock_message = Mock(spec=Message)
    mock_bot = mocker.patch("multi_notifier.connectors.connector_telegram.Bot")
    mock_bot.return_value.__aenter__.return_value.send_message = AsyncMock(return_value=mock_message)

    # Test data
    token = "test_token"  # noqa: S105
    chat_id = "123456"
    text = "<b>HTML</b> message"

    # Execute
    result = await _send_html_message_async(token, chat_id, text)

    # Verify calls
    mock_transform_html.assert_called_once_with(text)
    mock_bot.assert_called_once_with(token=token)

    # Check entity conversion
    expected_entities = [MessageEntity(type="bold", offset=0, length=4)]
    mock_bot.return_value.__aenter__.return_value.send_message.assert_called_once_with(
        chat_id=chat_id, text="HTML message", entities=expected_entities
    )

    # Verify result
    assert result == [mock_message]


async def test_send_html_message_async_with_images_success(mocker: MockerFixture, sample_image_path: Path) -> None:
    """Test successful sending of message with images."""
    # Setup mocks
    mock_render_result = Mock(text="Message with images", entities=[{"type": "italic", "offset": 0, "length": 7}])
    mock_transform_html = mocker.patch("multi_notifier.connectors.connector_telegram.transform_html", return_value=mock_render_result)

    mock_input_file = Mock()
    mock_fs_input_file = mocker.patch("multi_notifier.connectors.connector_telegram.FSInputFile", return_value=mock_input_file)

    mock_media_photo = Mock()
    mock_input_media_photo = mocker.patch("multi_notifier.connectors.connector_telegram.InputMediaPhoto", return_value=mock_media_photo)

    mock_message = Mock(spec=Message)
    mock_bot = mocker.patch("multi_notifier.connectors.connector_telegram.Bot")
    mock_bot.return_value.__aenter__.return_value.send_media_group = AsyncMock(return_value=[mock_message])

    # Test data
    token = "test_token"  # noqa: S105
    chat_id = "123456"
    text = "Message with images"
    images = {"img1": sample_image_path, "img2": sample_image_path}

    # Execute
    result = await _send_html_message_async(token, chat_id, text, images)

    # Verify calls
    mock_transform_html.assert_called_once_with(text)
    mock_bot.assert_called_once_with(token=token)

    # Verify FSInputFile creation for each image
    assert mock_fs_input_file.call_count == 2
    mock_fs_input_file.assert_any_call(sample_image_path)

    # Verify InputMediaPhoto creation
    assert mock_input_media_photo.call_count == 2
    # First image should have caption and entities
    first_call = mock_input_media_photo.call_args_list[0]
    assert first_call.kwargs["media"] == mock_input_file
    assert first_call.kwargs["caption"] == "Message with images"
    assert len(first_call.kwargs["caption_entities"]) == 1
    assert first_call.kwargs["caption_entities"][0].type == "italic"

    # Second image should only have media
    second_call = mock_input_media_photo.call_args_list[1]
    assert second_call.kwargs["media"] == mock_input_file
    assert "caption" not in second_call.kwargs

    # Verify send_media_group call
    mock_bot.return_value.__aenter__.return_value.send_media_group.assert_called_once_with(
        chat_id=chat_id, media=[mock_media_photo, mock_media_photo]
    )

    # Verify result
    assert result == [mock_message]


async def test_send_html_message_async_empty_images_dict(mocker: MockerFixture) -> None:
    """Test sending message with empty images dictionary (should send as text)."""
    # Setup mocks
    mock_render_result = Mock(text="Message with empty images", entities=None)
    mocker.patch("multi_notifier.connectors.connector_telegram.transform_html", return_value=mock_render_result)

    mock_message = Mock(spec=Message)
    mock_bot = mocker.patch("multi_notifier.connectors.connector_telegram.Bot")
    mock_bot.return_value.__aenter__.return_value.send_message = AsyncMock(return_value=mock_message)

    # Test data
    token = "test_token"  # noqa: S105
    chat_id = "123456"
    text = "Message with empty images"
    images = {}

    # Execute
    result = await _send_html_message_async(token, chat_id, text, images)

    # Verify text message was sent (not media group)
    mock_bot.return_value.__aenter__.return_value.send_message.assert_called_once_with(
        chat_id=chat_id, text="Message with empty images", entities=None
    )
    mock_bot.return_value.__aenter__.return_value.send_media_group.assert_not_called()

    # Verify result
    assert result == [mock_message]


async def test_send_html_message_async_bot_error(mocker: MockerFixture) -> None:
    """Test handling of bot errors during sending."""
    # Setup mocks
    mock_render_result = Mock(text="Test message", entities=None)
    mocker.patch("multi_notifier.connectors.connector_telegram.transform_html", return_value=mock_render_result)

    mock_bot = mocker.patch("multi_notifier.connectors.connector_telegram.Bot")
    mock_bot.return_value.__aenter__.return_value.send_message = AsyncMock(side_effect=Exception("Bot error"))

    # Test data
    token = "test_token"  # noqa: S105
    chat_id = "123456"
    text = "Test message"

    # Execute and verify exception
    with pytest.raises(Exception, match="Bot error"):
        await _send_html_message_async(token, chat_id, text)


async def test_send_html_message_async_media_group_error(mocker: MockerFixture, sample_image_path: Path) -> None:
    """Test handling of media group errors."""
    # Setup mocks
    mock_render_result = Mock(text="Message with images", entities=None)
    mocker.patch("multi_notifier.connectors.connector_telegram.transform_html", return_value=mock_render_result)

    mock_bot = mocker.patch("multi_notifier.connectors.connector_telegram.Bot")
    mock_bot.return_value.__aenter__.return_value.send_media_group = AsyncMock(side_effect=Exception("Media group error"))

    # Test data
    token = "test_token"  # noqa: S105
    chat_id = "123456"
    text = "Message with images"
    images = {"img1": sample_image_path}

    # Execute and verify exception
    with pytest.raises(Exception, match="Media group error"):
        await _send_html_message_async(token, chat_id, text, images)


def test_telegram_init(telegram_config: TelegramConfig, mocker: MockerFixture) -> None:
    """Test __init__ of Telegram."""
    # Mock the async test method directly
    mock_test_config = mocker.AsyncMock()
    mocker.patch.object(Telegram, "_test_config", mock_test_config)
    asyncio_run_mock = mocker.patch("asyncio.run")

    # Execute
    Telegram(telegram_config)

    # Verify both calls
    mock_test_config.assert_called_once()
    asyncio_run_mock.assert_called_once()


async def test_test_config(telegram_config: TelegramConfig, mocker: MockerFixture) -> None:
    """Test _test_config of Telegram."""
    # Mock Bot and get_me
    mock_bot = mocker.patch("multi_notifier.connectors.connector_telegram.Bot")
    mock_bot.return_value.__aenter__.return_value.get_me = AsyncMock(return_value=Mock(id=123, is_bot=False))

    # Create a Telegram instance without mocking _test_config for this test
    telegram = Telegram.__new__(Telegram)
    telegram._config = telegram_config

    # Execute
    await telegram._test_config()

    # Verify
    mock_bot.assert_called_once_with(token=telegram._config.bot_token)
    mock_bot.return_value.__aenter__.return_value.get_me.assert_called_once()


async def test_test_config_exceptions(telegram_config: TelegramConfig, mocker: MockerFixture) -> None:
    """Test exceptions of _test_config of Telegram."""
    # Mock Bot and get_me
    mock_bot = mocker.patch("multi_notifier.connectors.connector_telegram.Bot")
    mock_bot.return_value.__aenter__.return_value.get_me = AsyncMock(side_effect=Exception("Some error"))

    # Create a Telegram instance without mocking _test_config for this test
    telegram = Telegram.__new__(Telegram)
    telegram._config = telegram_config

    # Execute
    with pytest.raises(ConnectorConfigurationError):
        await telegram._test_config()

    # Verify
    mock_bot.assert_called_once_with(token=telegram._config.bot_token)


@pytest.mark.parametrize(
    "recipient, msg, subject, images, msg_expect",
    [
        ("123", "test", None, None, "test"),
        ("123", "test", None, {"n1": Path()}, "test"),
        ("123", "test", "subj_1", None, "subj_1: test"),
        ("123", "test", "subj_1", {"n1": Path()}, "subj_1: test"),
        (["123", "456"], "another test", None, None, "another test"),
        (["123", "456"], "another test", None, {"n1": Path()}, "another test"),
        (["123", "456"], "another test", "subj_1", None, "subj_1: another test"),
        (["123", "456"], "another test", "subj_1", {"n1": Path()}, "subj_1: another test"),
    ],
)
def test_send_message(
    telegram_connector: Telegram,
    recipient: str | list[str],
    msg: str,
    subject: str,
    images: dict[str, Path] | None,
    msg_expect: str,
    mocker: MockerFixture,
) -> None:
    """Test send_message of Telegram."""
    send_msg_mock = mocker.patch("multi_notifier.connectors.connector_telegram._send_html_message_async")

    # single recipient
    telegram_connector.send_message(recipient, msg, subject, images)

    recipient_list = recipient if isinstance(recipient, list) else [recipient]
    assert send_msg_mock.call_count == len(recipient_list)
    expected_calls = [mocker.call(telegram_connector._config.bot_token, recip, msg_expect, images) for recip in recipient_list]
    send_msg_mock.assert_has_calls(expected_calls)


def test_send_message_exception(telegram_connector: Telegram, mocker: MockerFixture) -> None:
    """Test exception handling of send_message."""
    mocker.patch("multi_notifier.connectors.connector_telegram._send_html_message_async", side_effect=Exception("Test error"))

    with pytest.raises(Exception, match="Failed to send message to 123"):
        telegram_connector.send_message("123", "test")


@pytest.mark.parametrize(
    "recipient, is_valid",
    [
        ("123", True),
        ("test", False),
        ("mail@domain.de", False),
    ],
)
def test_is_valid_recipient(recipient: str, is_valid: bool) -> None:
    """Test is_valid_recipient."""
    assert Telegram.is_valid_recipient(recipient) == is_valid
