from pathlib import Path

import pytest
from pytest_mock import MockerFixture

from multi_notifier.connectors.connector_mail import Mail, MailConfig
from multi_notifier.connectors.connector_telegram import Telegram, TelegramConfig


@pytest.fixture
def sample_image_path(tmp_path: Path) -> Path:
    """Create a sample image file for testing."""
    # Create a simple 1x1 PNG file (minimal valid PNG)
    png_data = b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\tpHYs\x00\x00\x0b\x13\x00\x00\x0b\x13\x01\x00\x9a\x9c\x18\x00\x00\x00\nIDATx\x9cc`\x00\x00\x00\x02\x00\x01\xe2!\xbc\x33\x00\x00\x00\x00IEND\xaeB`\x82"
    img_path = tmp_path / "test.png"
    img_path.write_bytes(png_data)
    return img_path


# =================================== Mail Connector ===================================
@pytest.fixture
def mail_config() -> MailConfig:
    """Create a test mail config."""
    return MailConfig(
        smtp_host="smtp.test.com",
        smtp_port=587,
        user="test@test.com",
        password="testpass",  # noqa: S106
    )


@pytest.fixture
def mail_connector(mail_config: MailConfig) -> Mail:
    """Create a test mail connector."""
    return Mail(mail_config)


# =================================== Telegram Connector ===================================
@pytest.fixture
def telegram_config() -> TelegramConfig:
    """Create a test telegram config."""
    return TelegramConfig(
        bot_token="test_token",  # noqa: S106
    )


@pytest.fixture
def telegram_connector(telegram_config: TelegramConfig, mocker: MockerFixture) -> Telegram:
    """Create a test telegram connector."""
    mocker.patch("multi_notifier.connectors.connector_telegram.Telegram._test_config")
    return Telegram(telegram_config)
