# Version 0.6.2 - 12.05.2026

- bumped requests (and other packages) to avoid security vulnerabilities

# Version 0.6.1 - 13.04.2026

- added py.typed

# Version 0.6.0 - 09.04.2026

## Breaking Changes

- renamed Exceptions to Error
- removed `connector_mail_imap`
- removed `send_handler`

# Features

- refactored `multi_notifier.connector_mail.Mail` connector to use `email` package (built-in python library)
- added possibility to send images and html with `multi_notifier.connector_telegram.Telegram`
- changed to new project structure with pyproject.toml and modern tools like ruff / prek

# Version 0.5.0 - 03.08.2024

## Features

- bumped versions:
  - requests~=2.32.0
  - pydantic>=2.6.0,\<3.0.0

# Version 0.4.0 - 19.03.2024

## Breaking Change

- changed `smtp_server` to `smtp_host`

## Features

- refactored config of all connectors to use pydantic validation.

# Version 0.3.0 - 16.03.2024

## Breaking Change

- the mail connector `multi_notifier.connectors.connector_mail` was replaced by a connector which only can send mail. If the IMAP features are needed the following class must be used: `multi_notifier.connectors.connector_mail_imap`

## Features

- changed mail to use the `redmail` package

# Version 0.2.3 - 12.03.2024

## Bugfix

- fixed bug in `multinotifier.conectors.connector_mail.Mail` which prevents sending multiple mails with a large interval

# Version 0.2.2 - 26.09.2023

## General

- switched to nose_helper python package

## Bugfix

- fixed bug which caused a complete crash if one connector could not be initialized

# Version 0.2.1 - 30.10.2022

## Bugfix

- fixed bug which caused a crash if called from debugger
- added timeout to telegram calls
