const esbuild = require("esbuild");
esbuild.buildSync({
  entryPoints: ["extension.js"],
  bundle: true,
  outfile: "dist/extension.js",
  external: ["vscode"],
  format: "cjs",
  platform: "node",
  minify: true,
});
