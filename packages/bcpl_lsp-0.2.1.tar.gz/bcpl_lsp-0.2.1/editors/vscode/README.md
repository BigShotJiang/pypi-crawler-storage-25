# BCPL Language Server

Full Language Server Protocol support for [Martin Richards' BCPL](https://www.cl.cam.ac.uk/~mr10/BCPL.html) in Visual Studio Code.

## Features

- **Syntax highlighting** — TextMate grammar for BCPL keywords, operators, strings, and comments
- **Completion** — keywords with snippets and document symbols
- **Go to Definition** — jump to function, variable, and global declarations
- **Find References** — locate all usages across files
- **Hover** — view symbol signatures and documentation
- **Rename** — rename symbols across files
- **Diagnostics** — unresolved symbols, duplicate globals, unused variables
- **Semantic Tokens** — context-aware highlighting
- **Document Symbols** — outline view of functions, globals, manifests
- **Workspace Symbols** — search symbols across the project
- **Call Hierarchy** — incoming and outgoing call graphs

## BCPL Dialect

Targets Martin Richards' canonical BCPL with uppercase keywords (`LET`, `IF`, `THEN`, `GET`, etc.). Also supports TRIPOS-era syntax variants.

## Requirements

The language server is written in Python and requires:

- **Python 3.10+**
- **[uv](https://docs.astral.sh/uv/)** (recommended) or pip

### Installation

```bash
# Install the language server
pip install bcpl-lsp

# Or with uv (recommended)
uv tool install bcpl-lsp

# Update to the latest version
pip install --upgrade bcpl-lsp
# or
uv tool install bcpl-lsp --upgrade
```

The extension will look for `bcpl-lsp` on your PATH. Alternatively, set `bcpl.server.path` in VS Code settings to point to a local clone of the project.

## Settings

| Setting | Default | Description |
|---------|---------|-------------|
| `bcpl.server.path` | `""` | Path to the bcpl-lsp project directory. If empty, expects `bcpl-lsp` on PATH. |
| `bcpl.logLevel` | `"info"` | Log verbosity: `debug`, `info`, `warning`, or `error`. |

## Commands

- **BCPL: Language Server Menu** — quick access to all commands
- **BCPL: Restart Language Server** — restart the server
- **BCPL: Show Version** — display the current version

## File Associations

The extension associates `.b` and `.bcpl` files with BCPL. Extensionless files are auto-detected by sniffing for BCPL constructs (`GET`, `SECTION`, `LET`, `GLOBAL`, etc.).

## License

MIT
