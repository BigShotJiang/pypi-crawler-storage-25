from dataclasses import dataclass
from pathlib import Path
from fastmcp import FastMCP
import os

# Initialize FastMCP server
mcp = FastMCP("mcp-code-gen-kd")

# Constants
ROOT = Path(__file__).parent
# 修改 main.py 中的常量
RULE_ROOT = ROOT / "src" / "rules"


@dataclass
class RuleDoc:
    id: str
    path: Path
    content: str


RULE_INDEX: dict[str, RuleDoc] = {}


def load_rule_index() -> dict[str, RuleDoc]:
    """Load all rule/template docs under src/rules."""
    index: dict[str, RuleDoc] = {}
    for rule_path in RULE_ROOT.rglob("*"):
        if rule_path.suffix.lower() in {".mdc", ".mdx"} and rule_path.is_file():
            rule_id = str(rule_path.relative_to(RULE_ROOT)).replace("\\", "/")
            index[rule_id] = RuleDoc(
                id=rule_id,
                path=rule_path,
                content=rule_path.read_text(encoding="utf-8"),
            )
    return index


def ensure_rule_index() -> None:
    """Lazy init for safety when tools are imported directly."""
    global RULE_INDEX
    if not RULE_INDEX:
        RULE_INDEX = load_rule_index()


def select_rules(scene: str, minimal: bool) -> list[RuleDoc]:
    """Select rule docs by scene."""
    scene_key = scene.lower().strip()
    rule_ids: list[str] = []

    if scene_key == "table":
        rule_ids.append("develop-structure/SKILL_TABLE/OUTLINE.mdc")
        rule_ids.append(
            "develop-structure/SKILL_TABLE/table-module-template.min.mdx"
            if minimal
            else "develop-structure/SKILL_TABLE/table-module-template.mdx"
        )
    elif scene_key in {"detail-basic", "detail"}:
        rule_ids.append("develop-structure/SKILL_DETAIL_BASIC/OUTLINE.mdc")
        rule_ids.append(
            "develop-structure/SKILL_DETAIL_BASIC/detail-basic-module-template.min.mdx"
            if minimal
            else "develop-structure/SKILL_DETAIL_BASIC/detail-basic-module-template.mdx"
        )

    return [RULE_INDEX[rule_id] for rule_id in rule_ids if rule_id in RULE_INDEX]


def compose_prompt(scene: str, requirement: str, minimal: bool) -> str:
    """Build final prompt from user requirement and selected rules."""
    docs = select_rules(scene, minimal)
    rules_text = "\n\n".join(f"# [{doc.id}]\n{doc.content}" for doc in docs)
    return f"""
你是代码生成器。严格遵守以下规则文档进行输出。

## 用户需求
{requirement}

## 规则与模板
{rules_text}

## 输出要求
1) 先输出目录结构
2) 再输出关键文件代码
3) 对每个关键设计点标注对应的规则来源（rule id）
""".strip()


@mcp.tool()
def list_rules() -> list[str]:
    """List all available rule/template IDs."""
    ensure_rule_index()
    return sorted(RULE_INDEX.keys())


@mcp.tool()
def preview_prompt(scene: str, requirement: str, minimal: bool = True) -> str:
    """Generate the full prompt without calling an LLM."""
    ensure_rule_index()
    return compose_prompt(scene, requirement, minimal)


@mcp.tool()
def generate_by_rules(scene: str, requirement: str, minimal: bool = True) -> str:
    """Generate output by selected rules (demo placeholder)."""
    ensure_rule_index()
    prompt = compose_prompt(scene, requirement, minimal)
    # TODO: Replace with actual LLM SDK call.
    return f"[DEMO] 已生成提示词，长度={len(prompt)}"


# def main() -> None:
#     ensure_rule_index()
#     mcp.run(transport="http", host="0.0.0.0", port=8000)
def main():
    ensure_rule_index()
    host = os.getenv("MCP_HOST", "0.0.0.0")
    port = int(os.getenv("MCP_PORT", "8000"))
    mcp.run(transport="http", host=host, port=port)

if __name__ == "__main__":
    main()