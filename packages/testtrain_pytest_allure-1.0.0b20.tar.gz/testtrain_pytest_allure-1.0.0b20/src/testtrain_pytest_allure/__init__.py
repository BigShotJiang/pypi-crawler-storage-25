"""testtrain-pytest-allure: streams Allure test results to Testtrain in real time."""

from testtrain_pytest_allure.plugin import pytest_addoption, pytest_configure

__all__ = ["pytest_addoption", "pytest_configure"]
