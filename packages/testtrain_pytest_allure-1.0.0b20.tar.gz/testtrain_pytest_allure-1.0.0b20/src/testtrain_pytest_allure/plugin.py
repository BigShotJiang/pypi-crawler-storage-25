"""Pytest plugin: streams Allure test results to Testtrain via allure_commons hooks."""

from __future__ import annotations

import copy
import io
import re
import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

import allure_commons
import pytest
import os
import requests
from allure_commons import hookimpl

if TYPE_CHECKING:
    from allure_commons.model2 import TestResult

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_MAX_RETRIES = 3
_RETRY_BACKOFF = 2.0  # seconds; doubles on each retry


# ---------------------------------------------------------------------------
# Status mapping
# ---------------------------------------------------------------------------

_STATUS_MAP: dict[str | None, str] = {
    "passed": "passed",
    "failed": "failed",
    "broken": "failed",
    "skipped": "skipped",
    "unknown": "failed",
    None: "failed",
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ms_to_iso(ts_ms: int | float | None) -> str | None:
    """Convert a millisecond POSIX timestamp to an ISO-8601 UTC string."""
    if ts_ms is None:
        return None
    dt = datetime.fromtimestamp(ts_ms / 1000.0, tz=timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def _map_parameters(params: list[Any]) -> list[dict[str, Any]] | None:
    if not params:
        return None
    result = []
    for p in params:
        item: dict[str, Any] = {
            "name": str(getattr(p, "name", "") or ""),
            "value": str(getattr(p, "value", "") or ""),
        }
        mode = getattr(p, "mode", None)
        if mode and mode != "default":
            item["mode"] = mode
        result.append(item)
    return result or None


def _map_step(step: Any, attachments_store: dict[str, bytes | str]) -> dict[str, Any]:
    """Recursively map an allure step to the Testtrain step schema."""
    status = getattr(step, "status", None)
    is_failed = status not in ("passed", None)

    start = getattr(step, "start", None)
    stop = getattr(step, "stop", None)
    duration: int | None = None
    if start is not None and stop is not None:
        duration = max(0, int(stop - start))

    item: dict[str, Any] = {
        "name": str(getattr(step, "name", "") or ""),
        "is_failed": is_failed,
    }

    if duration is not None:
        item["duration"] = duration

    params = _map_parameters(getattr(step, "parameters", None) or [])
    if params:
        item["parameters"] = params

    # Nested steps
    sub_steps = getattr(step, "steps", None) or []
    if sub_steps:
        item["steps"] = [_map_step(s, attachments_store) for s in sub_steps]

    # Status details → output
    status_details = getattr(step, "statusDetails", None)
    if status_details:
        parts = []
        msg = getattr(status_details, "message", None)
        trace = getattr(status_details, "trace", None)
        if msg:
            parts.append(msg)
        if trace:
            parts.append(trace)
        if parts:
            item["output"] = "\n\n".join(parts)

    # Attachments for this step
    raw_attachments = getattr(step, "attachments", None) or []
    mapped_attachments = _collect_attachment_refs(raw_attachments, attachments_store)
    if mapped_attachments is not None:
        item["attachments"] = mapped_attachments

    return item


def _collect_attachment_refs(
    raw_attachments: list[Any],
    attachments_store: dict[str, bytes | str],
) -> list[dict[str, str]] | None:
    """Return attachment ref list for in-memory attachments only."""
    refs = []
    for att in raw_attachments:
        source = getattr(att, "source", None)
        if source and source in attachments_store:
            refs.append({"field": source})
    return refs or None


def _get_label_value(labels: list[Any], name: str) -> str | None:
    for label in labels:
        if getattr(label, "name", None) != name:
            continue
        value = getattr(label, "value", None)
        if value:
            return str(value)
    return None


def _derive_node_id(result: TestResult) -> str | None:
    """Reconstruct a pytest-style nodeid from Allure metadata when possible."""
    full_name = getattr(result, "fullName", None)
    if not full_name:
        return None

    if "::" in full_name:
        return full_name

    labels = getattr(result, "labels", None) or []
    package_name = _get_label_value(labels, "package")
    sub_suite = _get_label_value(labels, "subSuite")
    title_path = getattr(result, "titlePath", None) or []

    module_name = package_name
    if not module_name and title_path and str(title_path[-1]).endswith(".py"):
        module_name = ".".join(str(part).removesuffix(".py") for part in title_path)

    if not module_name:
        return full_name

    module_path = f"{module_name.replace('.', '/')}.py"

    if "#" in full_name:
        left, test_name = full_name.split("#", 1)
    else:
        left, _, test_name = full_name.rpartition(".")
        if not left or not test_name:
            return full_name

    class_parts: list[str] = []
    if left == module_name:
        class_parts = []
    elif left.startswith(f"{module_name}."):
        class_suffix = left[len(module_name) + 1 :]
        class_parts = [part for part in class_suffix.split(".") if part]
    elif sub_suite:
        class_parts = [part for part in sub_suite.split(".") if part]

    node_parts = [module_path, *class_parts, test_name]
    return "::".join(part for part in node_parts if part)


def _map_result(
    result: TestResult,
    run_id: str,
    attachments_store: dict[str, bytes | str],
) -> dict[str, Any]:
    """Map an allure TestResult to the Testtrain /api/tests payload item."""
    status = getattr(result, "status", None)
    state = _STATUS_MAP.get(status, "failed")

    start_ms = getattr(result, "start", None)
    stop_ms = getattr(result, "stop", None)
    duration: int | None = None
    if start_ms is not None and stop_ms is not None:
        duration = max(0, int(stop_ms - start_ms))

    item: dict[str, Any] = {
        "testrunId": run_id,
        "name": str(getattr(result, "name", "") or ""),
        "state": state,
    }

    node_id = _derive_node_id(result)
    if node_id:
        item["nodeId"] = node_id

    if duration is not None:
        item["duration"] = duration

    started_at = _ms_to_iso(start_ms)
    if started_at:
        item["startedAt"] = started_at

    finished_at = _ms_to_iso(stop_ms)
    if finished_at:
        item["finishedAt"] = finished_at

    # Description
    description = getattr(result, "description", None)
    if description:
        item["description"] = description

    # Output from status details
    status_details = getattr(result, "statusDetails", None)
    if status_details:
        parts = []
        msg = getattr(status_details, "message", None)
        trace = getattr(status_details, "trace", None)
        if msg:
            parts.append(msg)
        if trace:
            parts.append(trace)
        if parts:
            item["output"] = "\n\n".join(parts)

    # Parameters
    params = _map_parameters(getattr(result, "parameters", None) or [])
    if params:
        item["parameters"] = params

    # Steps
    raw_steps = getattr(result, "steps", None) or []
    if raw_steps:
        item["steps"] = [_map_step(s, attachments_store) for s in raw_steps]

    # Defects from links with type "issue" only. A defect must have a url;
    # the Testtrain API requires defects[].url. Name is optional.
    links = getattr(result, "links", None) or []
    defects = []
    for link in links:
        link_type = getattr(link, "type", None)
        if link_type == "issue":
            url = getattr(link, "url", None)
            if not url:
                continue
            defect: dict[str, str] = {"url": url}
            name = getattr(link, "name", None)
            if name:
                defect["name"] = name
            defects.append(defect)
    if defects:
        item["defects"] = defects

    # Attachments at test level
    raw_attachments = getattr(result, "attachments", None) or []
    attachment_refs = _collect_attachment_refs(raw_attachments, attachments_store)
    if attachment_refs:
        item["attachments"] = attachment_refs

    return item


def _send_with_retries(
    url: str,
    auth_token: str,
    payload: dict[str, Any],
    attachments_store: dict[str, bytes | str],
    attachment_meta: dict[str, Any],
    max_retries: int = _MAX_RETRIES,
    backoff: float = _RETRY_BACKOFF,
) -> bool:
    """POST test result to Testtrain.  Returns True on success, False after all retries fail."""
    headers = {"Authorization": f"Bearer {auth_token}"}

    # Determine whether we need multipart (attachments present)
    all_refs: list[dict[str, str]] = _collect_all_attachment_refs(payload)

    for attempt in range(max_retries):
        try:
            if all_refs and attachments_store:
                response = _send_multipart(
                    url, headers, payload, attachments_store, attachment_meta
                )
            else:
                response = requests.post(
                    f"{url}/api/tests",
                    json={"tests": [payload]},
                    headers=headers,
                    timeout=30,
                )

            if response.status_code in (200, 201, 202):
                return True

            # 4xx errors are not retried (bad request, auth failure, etc.)
            if 400 <= response.status_code < 500:
                print(  # noqa: T201
                    f"[testtrain] Server rejected test result "
                    f"(HTTP {response.status_code}): {response.text[:200]}"
                )
                return False

            # 5xx — retryable
            print(  # noqa: T201
                f"[testtrain] Server error (HTTP {response.status_code}), "
                f"attempt {attempt + 1}/{max_retries}"
            )

        except requests.RequestException as exc:
            print(  # noqa: T201
                f"[testtrain] Network error on attempt {attempt + 1}/{max_retries}: {exc}"
            )

        if attempt < max_retries - 1:
            time.sleep(backoff * (2**attempt))

    return False


def _collect_all_attachment_refs(obj: Any) -> list[dict[str, str]]:
    """Recursively collect all attachment refs inside a payload item or step."""
    refs: list[dict[str, str]] = []
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key == "attachments" and isinstance(value, list):
                refs.extend(value)
            elif key == "steps" and isinstance(value, list):
                for step in value:
                    refs.extend(_collect_all_attachment_refs(step))
    return refs


def _map_container_entry(
    entry: Any, attachments_store: dict[str, bytes | str]
) -> dict[str, Any]:
    """Map a container 'before' or 'after' entry into a Testtrain step dict."""
    name = getattr(entry, "name", "") or ""
    status = getattr(entry, "status", None)
    is_failed = status not in ("passed", None)

    item: dict[str, Any] = {"name": str(name), "is_failed": is_failed}

    # Attachments on container entries
    raw_attachments = getattr(entry, "attachments", None) or []
    mapped_attachments = _collect_attachment_refs(raw_attachments, attachments_store)
    if mapped_attachments is not None:
        item["attachments"] = mapped_attachments

    # Any output/status details
    status_details = getattr(entry, "statusDetails", None)
    if status_details:
        parts = []
        msg = getattr(status_details, "message", None)
        trace = getattr(status_details, "trace", None)
        if msg:
            parts.append(msg)
        if trace:
            parts.append(trace)
        if parts:
            item["output"] = "\n\n".join(parts)

    return item


# Field name sanitizer for multipart form fields (only allow letters, digits,
# underscores and hyphens). Ensure uniqueness by appending a counter suffix.
_FIELD_RE = re.compile(r"[^A-Za-z0-9_-]")


def _sanitize_field_name(orig: str | None, used: dict[str, int]) -> str:
    if not orig:
        base = "attachment"
    else:
        base = _FIELD_RE.sub("_", orig)
    if not base:
        base = "attachment"

    count = used.get(base, 0)
    if count == 0:
        used[base] = 1
        return base
    # append counter to make it unique
    used[base] = count + 1
    return f"{base}-{count}"


def _send_multipart(
    base_url: str,
    headers: dict[str, str],
    payload: dict[str, Any],
    attachments_store: dict[str, bytes | str],
    attachment_meta: dict[str, Any],
) -> requests.Response:
    """Send test result as multipart/form-data with attached files."""
    import json

    # Build mapping orig_field -> safe_field and a sanitized payload for the
    # `meta` JSON so the server sees attachment `field` names that match the
    # multipart part names.
    all_refs = _collect_all_attachment_refs(payload)
    used_names: dict[str, int] = {}
    field_map: dict[str, str] = {}
    for ref in all_refs:
        orig_field = ref.get("field")
        if (
            orig_field
            and orig_field in attachments_store
            and orig_field not in field_map
        ):
            safe_field = _sanitize_field_name(orig_field, used_names)
            field_map[orig_field] = safe_field

    # Create a deep copy of the payload and replace attachment field names
    def _replace_fields(obj: Any) -> Any:
        if isinstance(obj, dict):
            new = {}
            for k, v in obj.items():
                if k == "attachments" and isinstance(v, list):
                    new_attachments = []
                    for att in v:
                        if isinstance(att, dict) and "field" in att:
                            orig = att.get("field")
                            new_field = field_map.get(orig, orig)
                            new_att = dict(att)
                            new_att["field"] = new_field
                            new_attachments.append(new_att)
                        else:
                            new_attachments.append(_replace_fields(att))
                    new[k] = new_attachments
                else:
                    new[k] = _replace_fields(v)
            return new
        elif isinstance(obj, list):
            return [_replace_fields(x) for x in obj]
        else:
            return obj

    sanitized_payload = _replace_fields(copy.deepcopy(payload))

    files: list[tuple[str, Any]] = []
    files.append(
        ("meta", (None, json.dumps({"tests": [sanitized_payload]}), "application/json"))
    )

    # Attach binary parts using sanitized field names but read data from the
    # original attachments_store keys.
    for orig_field, safe_field in field_map.items():
        data = attachments_store.get(orig_field)
        if data is None:
            continue
        meta = attachment_meta.get(orig_field, {})
        filename = meta.get("name", orig_field)
        mime = meta.get("mime", "application/octet-stream")

        if isinstance(data, str):
            data = data.encode("utf-8")

        files.append((safe_field, (filename, io.BytesIO(data), mime)))

    return requests.post(
        f"{base_url}/api/tests",
        files=files,
        headers=headers,
        timeout=60,
    )


# ---------------------------------------------------------------------------
# Allure commons listener
# ---------------------------------------------------------------------------


class TesttrainAllureListener:
    """Allure-commons plugin: intercepts test results and ships them to Testtrain."""

    def __init__(self, run_id: str, auth_token: str, testtrain_url: str) -> None:
        self.run_id = run_id
        self.auth_token = auth_token
        self.testtrain_url = testtrain_url.rstrip("/")

        # file_name → raw bytes/str captured via report_attached_data / report_attached_file
        self._attachments_store: dict[str, bytes | str] = {}
        # file_name → {"name": ..., "mime": ...}
        self._attachment_meta: dict[str, Any] = {}

        # Reverse index: child test uuid → list of containers that include that test.
        # Built in report_container; entries are removed once the test result is processed
        # so memory stays bounded to O(active tests) rather than growing with O(all tests).
        self._children_to_containers: dict[str, list[Any]] = {}

        self.failed = False
        self.fail_reason: str = ""

    @hookimpl
    def report_attached_data(self, body: bytes | str, file_name: str) -> None:
        self._attachments_store[file_name] = body

    @hookimpl
    def report_attached_file(self, source: str, file_name: str) -> None:
        try:
            with open(source, "rb") as fh:
                self._attachments_store[file_name] = fh.read()
        except OSError:
            pass

    @hookimpl
    def report_container(self, container: Any) -> None:
        """Capture container events (fixture befores/afters) for later correlation.

        Allure emits container JSON describing fixture befores/afters. We index
        each container by its child test uuids so report_result can look up only
        the relevant containers in O(1) instead of scanning all containers.
        """
        for child_uuid in getattr(container, "children", None) or []:
            self._children_to_containers.setdefault(child_uuid, []).append(container)

    @hookimpl
    def report_result(self, result: TestResult) -> None:
        payload = _map_result(result, self.run_id, self._attachments_store)

        # Inject container befores/afters (fixture setup/teardown) as steps
        test_uuid = getattr(result, "uuid", None)
        if test_uuid:
            setup_steps: list[dict[str, Any]] = []
            teardown_steps: list[dict[str, Any]] = []
            for container in self._children_to_containers.get(test_uuid, []):
                for before in getattr(container, "befores", []) or []:
                    setup_steps.append(
                        _map_container_entry(before, self._attachments_store)
                    )
                for after in getattr(container, "afters", []) or []:
                    teardown_steps.append(
                        _map_container_entry(after, self._attachments_store)
                    )
            # Free the index entry for this test — the container objects are still
            # referenced by entries for other children if this was a shared fixture.
            self._children_to_containers.pop(test_uuid, None)

            existing_steps = payload.get("steps", []) or []

            # If there are any setup/teardown entries, present them as
            # tier-1 grouped steps: Setup, Test Body, Tear Down. Otherwise
            # leave steps as-is (no extra grouping).
            if setup_steps or teardown_steps:

                def parent_item(
                    name: str, children: list[dict[str, Any]]
                ) -> dict[str, Any]:
                    is_failed = any(child.get("is_failed") for child in children)
                    item: dict[str, Any] = {"name": name, "is_failed": is_failed}
                    if children:
                        item["steps"] = children
                    return item

                grouped: list[dict[str, Any]] = []
                grouped.append(parent_item("Setup", setup_steps))
                grouped.append(parent_item("Test Body", existing_steps))
                grouped.append(parent_item("Tear Down", teardown_steps))

                payload["steps"] = grouped
            else:
                # no fixture containers — keep existing steps unchanged
                if existing_steps:
                    payload["steps"] = existing_steps
        ok = _send_with_retries(
            self.testtrain_url,
            self.auth_token,
            payload,
            self._attachments_store,
            self._attachment_meta,
        )
        if not ok:
            self.failed = True
            self.fail_reason = (
                f"[testtrain] Failed to send result for test '{payload.get('name')}' "
                f"after {_MAX_RETRIES} retries. Stopping session."
            )

        # Clean up attachment data that has been sent (or failed) to free memory
        for att_ref in _collect_all_attachment_refs(payload):
            field = att_ref.get("field")
            if field:
                self._attachments_store.pop(field, None)
                self._attachment_meta.pop(field, None)


# ---------------------------------------------------------------------------
# Pytest integration
# ---------------------------------------------------------------------------


def pytest_addoption(parser: pytest.Parser) -> None:
    group = parser.getgroup("testtrain", "Testtrain real-time reporting")
    group.addoption(
        "--testtrain-url",
        action="store",
        dest="testtrain_url",
        default=None,
        help="Testtrain platform base URL (e.g. http://localhost:3000)",
    )
    group.addoption(
        "--testtrain-auth-token",
        action="store",
        dest="testtrain_auth_token",
        default=None,
        help="Bearer token for Testtrain API authentication",
    )
    group.addoption(
        "--testtrain-run-id",
        action="store",
        dest="testtrain_run_id",
        default=None,
        help="UUID of an existing Testtrain testrun to report results to",
    )


def pytest_configure(config: pytest.Config) -> None:
    # Prefer explicit CLI options, fall back to environment variables.
    # `TESTTRAIN_URL` is optional and defaults to the public Testtrain URL.
    run_id = config.getoption("testtrain_run_id", default=None) or os.environ.get(
        "TESTTRAIN_RUN_ID"
    )
    auth_token = config.getoption(
        "testtrain_auth_token", default=None
    ) or os.environ.get("TESTTRAIN_AUTH_TOKEN")
    testtrain_url = (
        config.getoption("testtrain_url", default=None)
        or os.environ.get("TESTTRAIN_URL")
        or "https://testtrain.io"
    )

    if not (run_id and auth_token and testtrain_url):
        # Plugin is inactive when required values are not provided
        return

    listener = TesttrainAllureListener(run_id, auth_token, testtrain_url)
    allure_commons.plugin_manager.register(listener)
    config._testtrain_listener = listener  # type: ignore[attr-defined]

    def _cleanup() -> None:
        allure_commons.plugin_manager.unregister(plugin=listener)

    config.add_cleanup(_cleanup)


@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_protocol(item: pytest.Item, nextitem: pytest.Item | None):
    """Check for Testtrain send failures before each test and abort if needed."""
    listener: TesttrainAllureListener | None = getattr(
        item.config, "_testtrain_listener", None
    )
    if listener and listener.failed:
        pytest.exit(listener.fail_reason, returncode=1)
    yield
