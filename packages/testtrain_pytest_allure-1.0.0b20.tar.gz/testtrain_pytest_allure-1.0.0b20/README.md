# testtrain-pytest-allure

A pytest plugin that streams [Allure](https://allurereport.org/) test results to [Testtrain](https://testtrain.io) in real time using `allure-python-commons` hooks.

Each test result — including steps, parameters, attachments, and defect links — is posted to the Testtrain API immediately after the test finishes, with no file scanning required.

## Installation

```bash
pip install testtrain-pytest-allure
```

## Usage

```bash
pytest \
  --testtrain-url=http://localhost:3000 \
  --testtrain-auth-token=your-token \
  --alluredir=allure-results \
  --testtrain-run-id=testrun-id
```

The plugin activates automatically when all three `--testtrain-*` options are provided.

## Environment variables

You can provide the Testtrain settings via environment variables instead of command-line options. The plugin prefers CLI options but will fall back to env vars when options are not given.

```bash
export TESTTRAIN_RUN_ID="your-run-uuid"
export TESTTRAIN_AUTH_TOKEN="your-token"
export TESTTRAIN_URL="https://testtrain.io" # Optional (defaults to https://testtrain.io)
```

Run `pytest` normally (use `-s` to show plugin logs):

```bash
pytest -k <one_test> -s
```

## Options

| Option | Description |
|---|---|
| `--testtrain-url` | Testtrain platform base URL |
| `--testtrain-auth-token` | Bearer token for API authentication |
| `--testtrain-run-id` | UUID of an existing testrun to report results to |

## How It Works

The plugin registers a listener into `allure_commons.plugin_manager` that implements the `report_result` hook. When Allure finalises a test (after teardown), the listener:

1. Maps the `TestResult` object (status, steps, parameters, links) to the Testtrain API schema.
2. Collects any in-memory attachment data captured during the test run.
3. Sends everything to `POST /api/tests` (JSON or multipart when attachments are present).
4. Retries up to 3 times on transient errors with exponential back-off.
5. Stops the test session if all retries fail.

## Development

```bash
cd plugins/testtrain-pytest-allure
uv sync
uv run pytest tests/
```
