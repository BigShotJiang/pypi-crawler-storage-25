import asyncio
import json

from starlette.applications import Starlette
from starlette.responses import HTMLResponse, JSONResponse
from starlette.routing import Route, WebSocketRoute
from starlette.websockets import WebSocket

HTML = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>i4z-terminal-mcp</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@xterm/xterm@5/css/xterm.css">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{background:#0d1117;color:#c9d1d9;font-family:monospace;display:flex;height:100vh}
#sidebar{width:240px;background:#161b22;border-right:1px solid #30363d;display:flex;flex-direction:column}
#sidebar h2{padding:16px;font-size:14px;border-bottom:1px solid #30363d;color:#58a6ff}
#terminal-list{flex:1;overflow-y:auto;padding:8px}
.term-item{padding:8px 12px;cursor:pointer;border-radius:6px;font-size:12px;margin:2px 0;display:flex;align-items:center;gap:8px}
.term-item:hover{background:#1f2937}
.term-item.active{background:#1f6feb}
.status-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}
.status-dot.alive{background:#3fb950}
.status-dot.dead{background:#f85149}
#main{flex:1;display:flex;flex-direction:column;min-width:0}
#toolbar{padding:8px 16px;border-bottom:1px solid #30363d;display:flex;align-items:center;gap:12px;font-size:12px;flex-shrink:0}
#toolbar .label{color:#8b949e}
#content{flex:1;display:flex;flex-direction:column;overflow:hidden}
#terminal-panel{flex:1;min-height:0}
#terminal-container{height:100%;padding:4px}
.xterm{height:100%;padding:4px}
#grip{cursor:row-resize;height:4px;background:#21262d;border-top:1px solid #30363d;border-bottom:1px solid #30363d;flex-shrink:0}
#grip:hover{background:#30363d}
#history-panel{height:200px;overflow-y:auto;flex-shrink:0;border-top:1px solid #30363d}
#history-panel h3{position:sticky;top:0;background:#0d1117;padding:8px 12px;font-size:12px;color:#8b949e;border-bottom:1px solid #21262d;margin:0}
.history-entry{padding:4px 12px;font-size:12px;border-bottom:1px solid #161b22;white-space:pre-wrap;word-break:break-all}
.history-entry.input{color:#58a6ff}
.history-entry.output{color:#8b949e}
.history-time{font-size:10px;color:#484f58;margin-right:8px}
#empty{display:flex;align-items:center;justify-content:center;height:100%;color:#484f58;font-size:14px}
</style>
</head>
<body>
<div id="sidebar">
<h2>Terminals</h2>
<div id="terminal-list"><div style="color:#484f58;padding:12px;font-size:12px">No terminals</div></div>
</div>
<div id="main">
<div id="toolbar">
<span class="label" id="term-label">Select a terminal</span>
</div>
<div id="content">
<div id="terminal-panel">
<div id="terminal-container">
<div id="empty">Select a terminal from the sidebar</div>
</div>
</div>
<div id="grip"></div>
<div id="history-panel">
<h3>History</h3>
<div id="history-list"></div>
</div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/@xterm/xterm@5/lib/xterm.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@xterm/xterm-addon-fit@0.8/lib/xterm-addon-fit.js"></script>
<script>
const el={list:document.getElementById('terminal-list'),label:document.getElementById('term-label'),container:document.getElementById('terminal-container'),empty:document.getElementById('empty'),historyList:document.getElementById('history-list'),grip:document.getElementById('grip'),historyPanel:document.getElementById('history-panel'),terminalPanel:document.getElementById('terminal-panel')};
let activeId=null,term=null,socket=null,historyCursor=0,historyTimer=null;

async function refresh(){
  const r=await fetch('/api/terminals'),data=await r.json();
  if(!data.length){el.list.innerHTML='<div style="color:#484f58;padding:12px;font-size:12px">No terminals</div>';return}
  el.list.innerHTML=data.map(t=>`<div class="term-item${t.id===activeId?' active':''}" data-id="${t.id}" data-alive="${t.alive}">
    <span class="status-dot ${t.alive?'alive':'dead'}"></span>${t.id}
  </div>`).join('');
  el.list.querySelectorAll('.term-item').forEach(e=>e.onclick=()=>attach(e.dataset.id));
}

function attach(id){
  if(socket){socket.close();socket=null}
  if(term){term.dispose();term=null}
  if(historyTimer){clearInterval(historyTimer);historyTimer=null}
  activeId=id; historyCursor=0;
  el.label.textContent=id;
  el.empty.style.display='none';
  el.container.innerHTML='';
  el.historyList.innerHTML='';
  refresh();
  term=new Terminal({cursorBlink:true,fontSize:13,cols:100,rows:30,theme:{background:'#0d1117',foreground:'#c9d1d9',cursor:'#c9d1d9'}});
  term.open(el.container);
  const fitAddon=new FitAddon.FitAddon();
  term.loadAddon(fitAddon);
  fitAddon.fit();
  const observer=new ResizeObserver(()=>{try{fitAddon.fit()}catch(e){}});
  observer.observe(el.container);
  const wsProto=location.protocol==='https:'?'wss':'ws';
  socket=new WebSocket(`${wsProto}://${location.host}/ws/${id}`);
  socket.onmessage=e=>{if(term)term.write(e.data)};
  socket.onclose=()=>{if(term)term.write('\\r\\n[disconnected]\\r\\n')};
  historyTimer=setInterval(fetchHistory,1000);
  fetchHistory();
}

async function fetchHistory(){
  if(!activeId)return;
  try{
    const r=await fetch(`/api/history/${activeId}?since=${historyCursor}`);
    const data=await r.json();
    for(const e of data.events){
      const div=document.createElement('div');
      div.className=`history-entry ${e.type}`;
      const ts=e.timestamp.slice(11,19);
      div.innerHTML=`<span class="history-time">${ts}</span>${escapeHtml(e.text)}`;
      el.historyList.appendChild(div);
    }
    if(data.events.length) historyCursor=data.cursor;
    el.historyPanel.scrollTop=el.historyPanel.scrollHeight;
  }catch(e){}
}

function escapeHtml(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}

let dragging=false;
el.grip.onmousedown=e=>{dragging=true;e.preventDefault()};
document.onmousemove=e=>{
  if(!dragging)return;
  const main=document.getElementById('main');
  const rect=main.getBoundingClientRect();
  const y=e.clientY-rect.top;
  const topH=el.terminalPanel.getBoundingClientRect().height;
  const total=rect.height-32;
  const pct=Math.max(0.2,Math.min(0.8,(total-y)/total));
  el.terminalPanel.style.flex=pct;
  el.historyPanel.style.flex=(1-pct);
  if(term)term.refresh(0,term.rows);
};
document.onmouseup=()=>{dragging=false};

setInterval(refresh,2000);
refresh();
</script>
</body>
</html>"""


def create_app(manager):
    async def index(request):
        return HTMLResponse(HTML)

    async def api_terminals(request):
        return JSONResponse(manager.list_all())

    async def api_history(request):
        terminal_id = request.path_params["terminal_id"]
        since = int(request.query_params.get("since", 0))
        try:
            return JSONResponse(manager.get_history(terminal_id, since))
        except KeyError:
            return JSONResponse({"events": [], "cursor": since}, status_code=404)

    async def ws_terminal(ws: WebSocket):
        await ws.accept()
        terminal_id = ws.path_params["terminal_id"]
        try:
            session = manager.get(terminal_id)
        except KeyError:
            await ws.close()
            return

        cursor = 0
        while session.alive:
            output, cursor = session.read_since(cursor)
            if output:
                await ws.send_text(output)
            try:
                await asyncio.wait_for(ws.receive_text(), timeout=0.1)
            except asyncio.TimeoutError:
                pass
            except Exception:
                break
        await ws.close()

    return Starlette(routes=[
        Route("/", index),
        Route("/api/terminals", api_terminals),
        Route("/api/history/{terminal_id}", api_history),
        WebSocketRoute("/ws/{terminal_id}", ws_terminal),
    ])
