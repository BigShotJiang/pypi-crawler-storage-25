# Copyright (c) 2026 Sophia AI
# SPDX-License-Identifier: MIT
"""In-process FastAPI proxy that sits between the Claude Agent SDK and Anthropic.

Why a proxy even when calling the real Anthropic API:

- **Audit dump**: every request and response is persisted under <run>/audit/
  for compliance / regulatory / internal-audit defense. There is no way to
  retroactively reconstruct what the model saw without it.
- **Console events**: emit `proxy_request` / `proxy_response` events on every
  exchange so the user sees turns in real time.
- **Strip SDK noise**: the SDK injects a billing-header block and an identity
  line into the system field that are useless to us and cost tokens.
- **Future**: cost tracking, circuit breaker, schema preflight, prompt-cache
  marking. Hooks are already in place — we just need to wire them.

The proxy listens on a free local port chosen at start time. The Motor
points the SDK subprocess at it via `ANTHROPIC_BASE_URL` env var.
"""
from __future__ import annotations

import asyncio
import errno
import json
import re
import socket
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, TYPE_CHECKING

import httpx
import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse

from ._adapters import UpstreamAdapter, resolve_adapter
from .events import Event

if TYPE_CHECKING:
    from .config import MotorConfig
    from .events import EventBus


_SDK_IDENTITY_LINE = "You are a Claude agent, built on Anthropic's Claude Agent SDK."


@dataclass
class _RunState:
    """Per-run state held by the proxy: where to dump, request counter."""
    audit_dir: Path
    req_counter: int = 0


class ProxyServer:
    """Local FastAPI app that dispatches /run/{run_id}/v1/messages to upstream.

    Multi-run aware: each run registered via `register_run(run_id, audit_dir)`
    gets its own state slot. The agent's CLI subprocess receives a per-run
    base URL (`<proxy>/run/<run_id>`), so concurrent runs on the same Motor
    instance share the proxy without colliding on audit dump or request
    numbering.
    """

    def __init__(self, config: "MotorConfig", events: "EventBus") -> None:
        self.config = config
        self.events = events
        # Resolve the upstream adapter once at proxy creation. Accepts a
        # preset name (string) or an UpstreamAdapter instance. The adapter
        # owns provider-specific concerns (auth scheme, body shape, SSE
        # cleanup) so the proxy core stays provider-agnostic.
        self.adapter: UpstreamAdapter = resolve_adapter(config.upstream_adapter)
        # Active runs registered on this proxy. Keys are run_id strings,
        # values are per-run state. Multiple concurrent runs on the same
        # Motor coexist here without serialization.
        self._runs: dict[str, _RunState] = {}

        self.server: Optional[uvicorn.Server] = None
        self._task: Optional[asyncio.Task] = None
        self.port: Optional[int] = None
        self.app = self._build_app()

    # ── lifecycle ────────────────────────────────────────────────────

    async def start(self) -> str:
        """Bind to a port and start serving. Returns the base URL.

        Default (`proxy_port=None`): asks the kernel for a free port and
        keeps the socket open until uvicorn takes it over — no release-
        and-rebind race. Explicit `proxy_port` raises a clear error if
        the port is already in use, instead of leaking a uvicorn stack.
        """
        sock = _bind_socket(self.config.proxy_host, self.config.proxy_port or 0)
        self.port = sock.getsockname()[1]
        fd = sock.fileno()
        # Hand the socket fd to uvicorn. detach() releases ownership from
        # the Python wrapper so uvicorn — and only uvicorn — closes it.
        sock.detach()
        ucfg = uvicorn.Config(
            self.app,
            fd=fd,
            log_level="warning",
            access_log=False,
            # The proxy has no startup/shutdown handlers — the default
            # starlette lifespan loop only adds a `await receive()` that
            # never resolves cleanly when asyncio cancels at exit, which
            # leaks a CancelledError traceback for every standalone-script
            # example. Disable the lifespan protocol entirely.
            lifespan="off",
        )
        self.server = uvicorn.Server(ucfg)
        self._task = asyncio.create_task(self.server.serve())
        # poll for ready (server.started flips True once the socket is bound)
        for _ in range(100):
            if self.server.started:
                break
            await asyncio.sleep(0.05)
        if not self.server.started:
            raise RuntimeError("sophia-motor proxy did not start within 5s")
        await self.events.log("INFO", f"proxy listening on {self.base_url}")
        return self.base_url

    async def stop(self) -> None:
        if self.server is not None:
            self.server.should_exit = True
        if self._task is not None:
            try:
                await asyncio.wait_for(self._task, timeout=10)
            except asyncio.TimeoutError:
                self._task.cancel()
        await self.events.log("INFO", "proxy stopped")

    @property
    def base_url(self) -> str:
        if self.port is None:
            raise RuntimeError("proxy not started")
        return f"http://{self.config.proxy_host}:{self.port}"

    # ── per-run binding ──────────────────────────────────────────────

    def register_run(self, run_id: str, audit_dir: Path) -> None:
        """Open a slot for `run_id`. The CLI subprocess for this run will
        post to `/run/{run_id}/v1/messages` and the proxy will route the
        request + dump to `audit_dir`.

        Multiple runs can coexist — the registry is multi-tenant.
        """
        self._runs[run_id] = _RunState(audit_dir=audit_dir)

    def unregister_run(self, run_id: str) -> None:
        """Free the slot for `run_id`. Idempotent."""
        self._runs.pop(run_id, None)

    def base_url_for_run(self, run_id: str) -> str:
        """Per-run base URL the SDK subprocess uses as `ANTHROPIC_BASE_URL`."""
        return f"{self.base_url}/run/{run_id}"

    # ── app ──────────────────────────────────────────────────────────

    def _build_app(self) -> FastAPI:
        app = FastAPI(title="sophia-motor proxy")

        @app.get("/health")
        async def health():
            return {"status": "ok", "active_runs": list(self._runs.keys())}

        @app.post("/run/{run_id}/v1/messages")
        async def messages(run_id: str, req: Request):
            state = self._runs.get(run_id)
            if state is None:
                # The CLI was pointed at a base URL whose run_id we don't
                # know about — usually means the run was unregistered
                # before the request arrived (race) or the base URL was
                # tampered with. Return a structured error rather than
                # silently dumping into the wrong dir.
                raise HTTPException(
                    status_code=404,
                    detail=f"run_id {run_id!r} not registered with this proxy",
                )

            body_bytes = await req.body()
            try:
                body = json.loads(body_bytes)
            except Exception:
                body = {}

            stripped = (
                _strip_sdk_noise(body) if self.config.proxy_strip_sdk_noise else 0
            )
            user_reminders_stripped = (
                _strip_user_system_reminders(body)
                if self.config.proxy_strip_user_system_reminders
                else 0
            )
            rewritten_tools = _rewrite_tool_descriptions(
                body, self.config.tool_description_overrides,
            )

            # Provider-specific body transforms (sampling injection,
            # max_tokens clamp, image-block stripping for text-only
            # models, etc.). Anthropic adapter is no-op.
            body = self.adapter.transform_request(body)

            state.req_counter += 1
            req_idx = state.req_counter

            # ── persist request ──
            if self.config.proxy_dump_payloads:
                _dump_json(
                    state.audit_dir / f"request_{req_idx:03d}.json",
                    body,
                )

            await self.events.emit_event(Event(
                type="proxy_request",
                run_id=run_id,
                payload={
                    "idx": req_idx,
                    "model": body.get("model"),
                    "n_messages": len(body.get("messages", [])),
                    "n_tools": len(body.get("tools", [])),
                    "stream": body.get("stream", False),
                    "stripped_blocks": stripped,
                    "user_reminders_stripped": user_reminders_stripped,
                    "tool_descriptions_rewritten": rewritten_tools,
                },
            ))
            await self.events.log(
                "INFO",
                f"→ anthropic request #{req_idx}",
                run_id=run_id,
                model=body.get("model"),
                n_messages=len(body.get("messages", [])),
                n_tools=len(body.get("tools", [])),
                stream=body.get("stream", False),
            )

            # ── forward upstream ──
            sdk_headers = {k.lower(): v for k, v in req.headers.items()}
            headers = self.adapter.forward_headers(sdk_headers, self.config.api_key)
            headers.setdefault("anthropic-version", self.config.anthropic_version)
            target = self.adapter.forward_url(self.config.upstream_base_url)
            verify = self.adapter.verify_ssl()
            is_stream = body.get("stream", False)
            timeout = httpx.Timeout(600.0, connect=15.0)

            if is_stream:
                return StreamingResponse(
                    self._stream_upstream(target, body, headers, req_idx, run_id, state, verify),
                    media_type="text/event-stream",
                )

            try:
                async with httpx.AsyncClient(timeout=timeout, verify=verify) as client:
                    upstream = await client.post(target, json=body, headers=headers)
            except httpx.RequestError as e:
                # Network glitch (timeout, DNS fail, refused, reset). The
                # SDK retries above us — we map to a clean 502 instead of
                # leaking the httpx traceback through ASGI.
                await self.events.log(
                    "WARNING",
                    f"upstream unreachable on request #{req_idx} "
                    f"({type(e).__name__}: {e}); returning 502 — SDK will retry",
                    run_id=run_id,
                )
                return JSONResponse(
                    status_code=502,
                    content={"error": {
                        "type": "upstream_error",
                        "message": f"{type(e).__name__}: {e}",
                    }},
                )

            response_bytes = upstream.content
            try:
                response_body = json.loads(response_bytes)
            except Exception:
                response_body = {"_raw": response_bytes.decode(errors="replace")}

            response_body = self.adapter.transform_response(response_body)

            if self.config.proxy_dump_payloads:
                _dump_json(
                    state.audit_dir / f"response_{req_idx:03d}.json",
                    response_body,
                )

            usage = response_body.get("usage") or {}
            await self.events.emit_event(Event(
                type="proxy_response",
                run_id=run_id,
                payload={
                    "idx": req_idx,
                    "status": upstream.status_code,
                    "stop_reason": response_body.get("stop_reason"),
                    "usage": usage,
                },
            ))
            await self.events.log(
                "INFO",
                f"← anthropic response #{req_idx} status={upstream.status_code} "
                f"stop={response_body.get('stop_reason')}",
                run_id=run_id,
                input_tokens=usage.get("input_tokens"),
                output_tokens=usage.get("output_tokens"),
            )
            return JSONResponse(response_body, status_code=upstream.status_code)

        return app

    # ── streaming forward ────────────────────────────────────────────

    async def _stream_upstream(self, target, body, headers, req_idx, run_id, state, verify):
        """Pipe upstream SSE chunks straight to the client; collect for dump.

        Each chunk passes through `adapter.transform_sse_chunk` so a
        provider can scrub artifacts (e.g. Qwen XML closer fragments)
        before the SDK sees them. Default adapter is passthrough.
        """
        timeout = httpx.Timeout(600.0, connect=15.0)
        chunks: list[bytes] = []
        usage_seen: dict = {}
        stop_reason: Optional[str] = None
        try:
            async with httpx.AsyncClient(timeout=timeout, verify=verify) as client:
                async with client.stream("POST", target, json=body, headers=headers) as upstream:
                    async for chunk in upstream.aiter_bytes():
                        chunk = self.adapter.transform_sse_chunk(chunk)
                        chunks.append(chunk)
                        yield chunk
        except httpx.RequestError as e:
            # Network glitch during stream open or mid-stream. We can't
            # change the response status (already 200) — emit a synthetic
            # SSE error event so the SDK sees a clean termination instead
            # of an ASGI traceback. The SDK retries above us anyway.
            await self.events.log(
                "WARNING",
                f"upstream stream interrupted on request #{req_idx} "
                f"({type(e).__name__}: {e}); SDK will retry",
                run_id=run_id,
            )
            err_payload = json.dumps({
                "type": "error",
                "error": {
                    "type": "upstream_error",
                    "message": f"{type(e).__name__}: {e}",
                },
            })
            yield f"event: error\ndata: {err_payload}\n\n".encode()
            return
        full_text = b"".join(chunks).decode(errors="replace")
        for line in full_text.splitlines():
            if not line.startswith("data: "):
                continue
            data_str = line[6:]
            if data_str.strip() == "[DONE]":
                continue
            try:
                data = json.loads(data_str)
            except Exception:
                continue
            if data.get("type") == "message_delta":
                delta = data.get("delta", {}) or {}
                if delta.get("stop_reason"):
                    stop_reason = delta["stop_reason"]
                if isinstance(data.get("usage"), dict):
                    usage_seen.update(data["usage"])
            elif data.get("type") == "message_start":
                usage_seen.update((data.get("message", {}) or {}).get("usage", {}) or {})
        if self.config.proxy_dump_payloads:
            _dump_text(
                state.audit_dir / f"response_{req_idx:03d}.sse",
                full_text,
            )
        await self.events.emit_event(Event(
            type="proxy_response",
            run_id=run_id,
            payload={
                "idx": req_idx,
                "stream": True,
                "stop_reason": stop_reason,
                "usage": usage_seen,
            },
        ))
        await self.events.log(
            "INFO",
            f"← anthropic stream response #{req_idx} stop={stop_reason}",
            run_id=run_id,
            input_tokens=usage_seen.get("input_tokens"),
            output_tokens=usage_seen.get("output_tokens"),
        )


# ─────────────────────────────────────────────────────────────────────────
# helpers
# ─────────────────────────────────────────────────────────────────────────

def _bind_socket(host: str, port: int) -> socket.socket:
    """Open + bind + listen on `(host, port)`. Caller owns the fd.

    `port=0` lets the kernel assign a free port. Explicit non-zero
    ports get a friendly RuntimeError on EADDRINUSE so the caller
    learns to pass `proxy_port=None` instead of reading uvicorn's
    traceback.
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind((host, port))
    except OSError as e:
        s.close()
        if e.errno == errno.EADDRINUSE and port != 0:
            raise RuntimeError(
                f"sophia-motor proxy: port {port} on {host} is already "
                f"in use. Pass proxy_port=None to let the kernel pick "
                f"a free port, or pick a different value."
            ) from e
        raise
    s.listen(128)
    return s


def _strip_sdk_noise(body: dict) -> int:
    """Remove SDK-injected billing header and identity blocks from system field."""
    system = body.get("system")
    if not isinstance(system, list):
        return 0
    new_blocks: list = []
    removed = 0
    for block in system:
        if not isinstance(block, dict):
            new_blocks.append(block)
            continue
        text = block.get("text", "")
        if isinstance(text, str):
            if text.startswith("x-anthropic-billing-header:"):
                removed += 1
                continue
            if text.strip() == _SDK_IDENTITY_LINE:
                removed += 1
                continue
        new_blocks.append(block)
    if removed:
        body["system"] = new_blocks
    return removed


_SYSTEM_REMINDER_RE = re.compile(
    r"<system-reminder>.*?</system-reminder>\s*",
    re.DOTALL | re.IGNORECASE,
)

# Reminders that match this pattern carry information the model needs
# to function — chiefly the list of available skills. They look like:
#
#   <system-reminder>
#   The following skills are available for use with the Skill tool:
#   - my-skill: Use when ...
#   - other-skill: ...
#   </system-reminder>
#
# Stripping them blinds the model to the skill catalogue, so it ignores
# every skill the dev linked into the run. We preserve any reminder
# that mentions "skills available", "for use with", or shows a
# bulleted skill listing — everything else (date changes, "task tools
# haven't been used" nudges, etc.) gets removed as before.
_SKILL_LISTING_RE = re.compile(
    r"skills?\s+(are\s+available|for\s+use|available)"
    r"|for\s+use\s+with\s+the\s+Skill\s+tool",
    re.IGNORECASE | re.DOTALL,
)


def _strip_user_system_reminders(body: dict) -> int:
    """Remove <system-reminder>...</system-reminder> blocks from USER messages.

    The Claude CLI subprocess injects these from turn 2 onwards
    (currentDate, 'task tools haven't been used recently', etc). For
    task-driven agent runs they're noise — they consume tokens,
    distract the model, and aren't relevant to the task.

    Exception: reminders that contain the **skill catalogue** are
    preserved. The CLI uses these reminders as the only channel through
    which the model learns which skills the run has at its disposal —
    stripping them silently disables every linked skill.

    A text block whose content is ENTIRELY noise reminders is dropped.
    A text block with mixed content keeps the residual user text and
    any preserved skill-listing reminder.

    Returns the number of reminder blocks actually removed.
    """
    def _replace(m: "re.Match[str]") -> str:
        inner = m.group(0)
        if _SKILL_LISTING_RE.search(inner):
            return inner  # preserve: model needs the skill catalogue
        return ""

    count = 0
    for msg in body.get("messages", []):
        if msg.get("role") != "user":
            continue
        content = msg.get("content")
        if not isinstance(content, list):
            continue
        new_content: list = []
        for block in content:
            if not isinstance(block, dict) or block.get("type") != "text":
                new_content.append(block)
                continue
            text = block.get("text", "")
            if not isinstance(text, str) or "<system-reminder>" not in text:
                new_content.append(block)
                continue
            matches = _SYSTEM_REMINDER_RE.findall(text)
            if not matches:
                new_content.append(block)
                continue
            stripped = _SYSTEM_REMINDER_RE.sub(_replace, text).strip()
            # count = total reminders minus those we kept
            n_removed = sum(
                0 if _SKILL_LISTING_RE.search(m) else 1 for m in matches
            )
            count += n_removed
            if stripped:
                block["text"] = stripped
                new_content.append(block)
            # else: block became empty after stripping → drop it
        msg["content"] = new_content
    return count


def _rewrite_tool_descriptions(body: dict, overrides: dict[str, str]) -> int:
    """Replace the top-level `description` of tools whose name is in `overrides`.

    `input_schema` is left intact so the parameter contract is preserved.
    Returns the number of descriptions actually replaced.
    """
    if not overrides:
        return 0
    tools = body.get("tools")
    if not isinstance(tools, list):
        return 0
    count = 0
    for tool in tools:
        if not isinstance(tool, dict):
            continue
        name = tool.get("name")
        if name in overrides:
            tool["description"] = overrides[name]
            count += 1
    return count


def _dump_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _dump_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
