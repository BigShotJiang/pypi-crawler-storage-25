"""Tests for LoggingClient (sync) management API, runtime, and integration."""

from __future__ import annotations

import logging as stdlib_logging
from http import HTTPStatus
from unittest.mock import MagicMock, patch

import pytest

from smplkit import LogLevel
from smplkit._errors import SmplNotFoundError, SmplValidationError
from smplkit.logging.client import (
    LoggingClient,
    SmplLogGroup,
    SmplLogger,
    _LoggerRegistrationBuffer,
    _check_response_status,
)

_TEST_UUID = "550e8400-e29b-41d4-a716-446655440000"


def _make_logger_attrs(*, name="SQL Logger", level="DEBUG", group=None, managed=True):
    """Build mock logger attributes."""
    from smplkit._generated.logging.types import UNSET

    attrs = MagicMock()
    attrs.name = name
    attrs.level = level
    attrs.group = group if group is not None else UNSET
    attrs.managed = managed
    attrs.sources = UNSET
    attrs.environments = UNSET
    attrs.created_at = UNSET
    attrs.updated_at = UNSET
    return attrs


def _make_group_attrs(*, name="DB Loggers", level="WARN", group=None):
    """Build mock log group attributes."""
    from smplkit._generated.logging.types import UNSET

    attrs = MagicMock()
    attrs.name = name
    attrs.level = level
    attrs.group = group if group is not None else UNSET
    attrs.environments = UNSET
    attrs.created_at = UNSET
    attrs.updated_at = UNSET
    return attrs


def _make_resource(attrs, id=_TEST_UUID):
    resource = MagicMock()
    resource.id = id
    resource.attributes = attrs
    return resource


def _make_parsed(resource):
    parsed = MagicMock()
    parsed.data = resource
    return parsed


def _make_list_parsed(resources):
    parsed = MagicMock()
    parsed.data = resources
    return parsed


def _ok_response(parsed=None, status=HTTPStatus.OK):
    resp = MagicMock()
    resp.status_code = status
    resp.content = b""
    resp.parsed = parsed
    return resp


def _make_logging_client(**kwargs):
    """Create a LoggingClient with mocked parent."""
    parent = MagicMock()
    parent._api_key = "sk_test"
    parent._environment = "test"
    parent._service = kwargs.get("service", None)
    with patch("smplkit.logging.client.AuthenticatedClient"):
        client = LoggingClient(parent)
    return client


# ---------------------------------------------------------------------------
# new() — factory for unsaved loggers
# ---------------------------------------------------------------------------


class TestNew:
    def test_new_returns_unsaved_logger(self):
        client = _make_logging_client()
        lg = client.new("sql")
        assert isinstance(lg, SmplLogger)
        assert lg.id == "sql"
        assert lg.managed is False

    def test_new_with_name(self):
        client = _make_logging_client()
        lg = client.new("sql", name="SQL Logger")
        assert lg.name == "SQL Logger"

    def test_new_auto_generates_name(self):
        client = _make_logging_client()
        lg = client.new("checkout-v2")
        assert lg.name == "Checkout V2"

    def test_new_with_managed(self):
        client = _make_logging_client()
        lg = client.new("sql", managed=True)
        assert lg.managed is True


# ---------------------------------------------------------------------------
# new_group() — factory for unsaved log groups
# ---------------------------------------------------------------------------


class TestNewGroup:
    def test_new_group_returns_unsaved(self):
        client = _make_logging_client()
        grp = client.new_group("db-loggers")
        assert isinstance(grp, SmplLogGroup)
        assert grp.id == "db-loggers"

    def test_new_group_with_name(self):
        client = _make_logging_client()
        grp = client.new_group("db-loggers", name="DB Loggers")
        assert grp.name == "DB Loggers"

    def test_new_group_auto_generates_name(self):
        client = _make_logging_client()
        grp = client.new_group("db-loggers")
        assert grp.name == "Db Loggers"

    def test_new_group_with_parent_group(self):
        client = _make_logging_client()
        grp = client.new_group("child", group="parent-id")
        assert grp.group == "parent-id"


# ---------------------------------------------------------------------------
# list()
# ---------------------------------------------------------------------------


class TestList:
    @patch("smplkit.logging.client.list_loggers.sync_detailed")
    def test_list(self, mock_list):
        attrs = _make_logger_attrs()
        resource = _make_resource(attrs)
        mock_list.return_value = _ok_response(_make_list_parsed([resource]))

        client = _make_logging_client()
        result = client.list()
        assert len(result) == 1
        assert isinstance(result[0], SmplLogger)

    @patch("smplkit.logging.client.list_loggers.sync_detailed")
    def test_list_empty_parsed(self, mock_list):
        mock_list.return_value = _ok_response(None)
        client = _make_logging_client()
        result = client.list()
        assert result == []


# ---------------------------------------------------------------------------
# get(id) — direct lookup via get_logger
# ---------------------------------------------------------------------------


class TestGet:
    @patch("smplkit.logging.client.get_logger.sync_detailed")
    def test_get_by_id(self, mock_get):
        attrs = _make_logger_attrs()
        resource = _make_resource(attrs)
        mock_get.return_value = _ok_response(_make_parsed(resource))

        client = _make_logging_client()
        result = client.get("sql")
        assert isinstance(result, SmplLogger)
        mock_get.assert_called_once()
        assert mock_get.call_args.args[0] == "sql"

    @patch("smplkit.logging.client.get_logger.sync_detailed")
    def test_get_not_found_404(self, mock_get):
        mock_get.return_value = _ok_response(None, HTTPStatus.NOT_FOUND)
        client = _make_logging_client()
        with pytest.raises(SmplNotFoundError):
            client.get("sql")

    @patch("smplkit.logging.client.get_logger.sync_detailed")
    def test_get_not_found_null_parsed(self, mock_get):
        mock_get.return_value = _ok_response(None)
        client = _make_logging_client()
        with pytest.raises(SmplNotFoundError):
            client.get("sql")


# ---------------------------------------------------------------------------
# save() — create (id=None) and update (id set)
# ---------------------------------------------------------------------------


class TestSaveLogger:
    @patch("smplkit.logging.client.create_logger.sync_detailed")
    def test_save_creates_when_id_is_none(self, mock_create):
        attrs = _make_logger_attrs()
        resource = _make_resource(attrs)
        parsed = _make_parsed(resource)
        mock_create.return_value = _ok_response(parsed, HTTPStatus.CREATED)

        client = _make_logging_client()
        lg = client.new("sql", name="SQL Logger")
        lg.save()

        mock_create.assert_called_once()
        assert lg.id == _TEST_UUID  # populated from server response

    @patch("smplkit.logging.client.update_logger.sync_detailed")
    def test_save_updates_when_id_is_set(self, mock_update):
        attrs = _make_logger_attrs(level="ERROR")
        resource = _make_resource(attrs)
        parsed = _make_parsed(resource)
        mock_update.return_value = _ok_response(parsed)

        client = _make_logging_client()
        lg = SmplLogger(
            client,
            id=_TEST_UUID,
            name="SQL Logger",
            level="DEBUG",
            managed=True,
            group=None,
            environments={},
            created_at="2026-01-01T00:00:00Z",
        )
        lg.level = "ERROR"
        lg.save()

        mock_update.assert_called_once()
        body = mock_update.call_args.kwargs["body"]
        body_attrs = body.data.attributes
        assert body_attrs.level == "ERROR"

    @patch("smplkit.logging.client.update_logger.sync_detailed")
    def test_save_sends_all_fields(self, mock_update):
        attrs = _make_logger_attrs(name="SQL Logger", level="DEBUG", managed=True)
        resource = _make_resource(attrs)
        parsed = _make_parsed(resource)
        mock_update.return_value = _ok_response(parsed)

        client = _make_logging_client()
        lg = SmplLogger(
            client,
            id=_TEST_UUID,
            name="SQL Logger",
            level="DEBUG",
            managed=True,
            group=None,
            environments={"prod": {"level": "WARN"}},
            created_at="2026-01-01T00:00:00Z",
        )
        lg.save()

        body = mock_update.call_args.kwargs["body"]
        body_attrs = body.data.attributes
        assert body_attrs.name == "SQL Logger"
        assert body_attrs.level == "DEBUG"
        assert body_attrs.managed is True
        assert body_attrs.group is None

    @patch("smplkit.logging.client.update_logger.sync_detailed")
    def test_save_with_level_none(self, mock_update):
        attrs = _make_logger_attrs(level=None)
        resource = _make_resource(attrs)
        parsed = _make_parsed(resource)
        mock_update.return_value = _ok_response(parsed)

        client = _make_logging_client()
        lg = SmplLogger(
            client,
            id=_TEST_UUID,
            name="SQL Logger",
            level=None,
            managed=True,
            group=None,
            environments={},
            created_at="2026-01-01T00:00:00Z",
        )
        lg.save()

        body = mock_update.call_args.kwargs["body"]
        assert body.data.attributes.level is None

    @patch("smplkit.logging.client.update_logger.sync_detailed")
    def test_save_with_managed_false(self, mock_update):
        attrs = _make_logger_attrs(managed=False)
        resource = _make_resource(attrs)
        parsed = _make_parsed(resource)
        mock_update.return_value = _ok_response(parsed)

        client = _make_logging_client()
        lg = SmplLogger(
            client,
            id=_TEST_UUID,
            name="SQL Logger",
            level="DEBUG",
            managed=False,
            group=None,
            environments={},
            created_at="2026-01-01T00:00:00Z",
        )
        lg.save()

        body = mock_update.call_args.kwargs["body"]
        assert body.data.attributes.managed is False

    @patch("smplkit.logging.client.update_logger.sync_detailed")
    def test_save_updates_self_in_place(self, mock_update):
        response_attrs = _make_logger_attrs(name="SQL Logger v2", level="ERROR", managed=True)
        response_resource = _make_resource(response_attrs)
        response_parsed = _make_parsed(response_resource)
        mock_update.return_value = _ok_response(response_parsed)

        client = _make_logging_client()
        lg = SmplLogger(
            client,
            id=_TEST_UUID,
            name="SQL Logger",
            level="DEBUG",
            managed=True,
            group=None,
            environments={},
            created_at="2026-01-01T00:00:00Z",
        )
        lg.level = "ERROR"
        lg.save()

        assert lg.name == "SQL Logger v2"
        assert lg.level == "ERROR"
        assert lg.id == _TEST_UUID

    @patch("smplkit.logging.client.update_logger.sync_detailed")
    def test_save_null_parsed_raises_validation(self, mock_update):
        mock_update.return_value = _ok_response(None)
        client = _make_logging_client()
        lg = SmplLogger(client, id=_TEST_UUID, name="SQL Logger", created_at="2026-01-01T00:00:00Z")
        with pytest.raises(SmplValidationError):
            lg.save()


# ---------------------------------------------------------------------------
# delete(id) — direct delete via delete_logger
# ---------------------------------------------------------------------------


class TestDelete:
    @patch("smplkit.logging.client.delete_logger.sync_detailed")
    def test_delete_by_id(self, mock_delete):
        mock_delete.return_value = _ok_response(status=HTTPStatus.NO_CONTENT)

        client = _make_logging_client()
        client.delete("sql")
        mock_delete.assert_called_once()
        assert mock_delete.call_args.args[0] == "sql"

    @patch("smplkit.logging.client.delete_logger.sync_detailed")
    def test_delete_not_found(self, mock_delete):
        mock_delete.return_value = _ok_response(status=HTTPStatus.NOT_FOUND)
        client = _make_logging_client()
        with pytest.raises(SmplNotFoundError):
            client.delete("nonexistent")


# ---------------------------------------------------------------------------
# list_groups()
# ---------------------------------------------------------------------------


class TestListGroups:
    @patch("smplkit.logging.client.list_log_groups.sync_detailed")
    def test_list_groups(self, mock_list):
        attrs = _make_group_attrs()
        resource = _make_resource(attrs)
        mock_list.return_value = _ok_response(_make_list_parsed([resource]))

        client = _make_logging_client()
        result = client.list_groups()
        assert len(result) == 1
        assert isinstance(result[0], SmplLogGroup)

    @patch("smplkit.logging.client.list_log_groups.sync_detailed")
    def test_list_groups_empty_parsed(self, mock_list):
        mock_list.return_value = _ok_response(None)
        client = _make_logging_client()
        result = client.list_groups()
        assert result == []


# ---------------------------------------------------------------------------
# get_group(id) — direct lookup via get_log_group
# ---------------------------------------------------------------------------


class TestGetGroup:
    @patch("smplkit.logging.client.get_log_group.sync_detailed")
    def test_get_group_by_id(self, mock_get):
        attrs = _make_group_attrs()
        resource = _make_resource(attrs)
        mock_get.return_value = _ok_response(_make_parsed(resource))

        client = _make_logging_client()
        result = client.get_group("db-loggers")
        assert isinstance(result, SmplLogGroup)
        mock_get.assert_called_once()
        assert mock_get.call_args.args[0] == "db-loggers"

    @patch("smplkit.logging.client.get_log_group.sync_detailed")
    def test_get_group_not_found_404(self, mock_get):
        mock_get.return_value = _ok_response(None, HTTPStatus.NOT_FOUND)

        client = _make_logging_client()
        with pytest.raises(SmplNotFoundError):
            client.get_group("db-loggers")

    @patch("smplkit.logging.client.get_log_group.sync_detailed")
    def test_get_group_not_found_null_parsed(self, mock_get):
        mock_get.return_value = _ok_response(None)
        client = _make_logging_client()
        with pytest.raises(SmplNotFoundError):
            client.get_group("db-loggers")


# ---------------------------------------------------------------------------
# Group save() — create and update
# ---------------------------------------------------------------------------


class TestSaveGroup:
    @patch("smplkit.logging.client.create_log_group.sync_detailed")
    def test_save_creates_when_id_is_none(self, mock_create):
        attrs = _make_group_attrs()
        resource = _make_resource(attrs)
        parsed = _make_parsed(resource)
        mock_create.return_value = _ok_response(parsed, HTTPStatus.CREATED)

        client = _make_logging_client()
        grp = client.new_group("db-loggers", name="DB Loggers")
        grp.save()

        mock_create.assert_called_once()
        assert grp.id == _TEST_UUID

    @patch("smplkit.logging.client.update_log_group.sync_detailed")
    def test_save_updates_when_id_is_set(self, mock_update):
        attrs = _make_group_attrs(level="ERROR")
        resource = _make_resource(attrs)
        parsed = _make_parsed(resource)
        mock_update.return_value = _ok_response(parsed)

        client = _make_logging_client()
        grp = SmplLogGroup(
            client,
            id=_TEST_UUID,
            name="DB Loggers",
            level="WARN",
            group=None,
            environments={},
            created_at="2026-01-01T00:00:00Z",
        )
        grp.level = "ERROR"
        grp.save()

        mock_update.assert_called_once()
        body = mock_update.call_args.kwargs["body"]
        assert body.data.attributes.level == "ERROR"

    @patch("smplkit.logging.client.update_log_group.sync_detailed")
    def test_save_sends_all_fields(self, mock_update):
        attrs = _make_group_attrs(name="DB Loggers", level="WARN")
        resource = _make_resource(attrs)
        parsed = _make_parsed(resource)
        mock_update.return_value = _ok_response(parsed)

        client = _make_logging_client()
        grp = SmplLogGroup(
            client,
            id=_TEST_UUID,
            name="DB Loggers",
            level="WARN",
            group=None,
            environments={"prod": {"level": "ERROR"}},
            created_at="2026-01-01T00:00:00Z",
        )
        grp.save()

        body = mock_update.call_args.kwargs["body"]
        body_attrs = body.data.attributes
        assert body_attrs.name == "DB Loggers"
        assert body_attrs.level == "WARN"
        assert body_attrs.group is None

    @patch("smplkit.logging.client.update_log_group.sync_detailed")
    def test_save_with_level_none(self, mock_update):
        attrs = _make_group_attrs(level=None)
        resource = _make_resource(attrs)
        parsed = _make_parsed(resource)
        mock_update.return_value = _ok_response(parsed)

        client = _make_logging_client()
        grp = SmplLogGroup(
            client,
            id=_TEST_UUID,
            name="DB Loggers",
            level=None,
            group=None,
            environments={},
            created_at="2026-01-01T00:00:00Z",
        )
        grp.save()

        body = mock_update.call_args.kwargs["body"]
        assert body.data.attributes.level is None

    @patch("smplkit.logging.client.update_log_group.sync_detailed")
    def test_save_updates_self_in_place(self, mock_update):
        response_attrs = _make_group_attrs(name="DB Loggers v2", level="ERROR")
        response_resource = _make_resource(response_attrs)
        response_parsed = _make_parsed(response_resource)
        mock_update.return_value = _ok_response(response_parsed)

        client = _make_logging_client()
        grp = SmplLogGroup(
            client,
            id=_TEST_UUID,
            name="DB Loggers",
            level="WARN",
            group=None,
            environments={},
            created_at="2026-01-01T00:00:00Z",
        )
        grp.level = "ERROR"
        grp.save()

        assert grp.name == "DB Loggers v2"
        assert grp.level == "ERROR"
        assert grp.id == _TEST_UUID

    @patch("smplkit.logging.client.update_log_group.sync_detailed")
    def test_save_null_parsed_raises_validation(self, mock_update):
        mock_update.return_value = _ok_response(None)
        client = _make_logging_client()
        grp = SmplLogGroup(client, id=_TEST_UUID, name="DB Loggers", created_at="2026-01-01T00:00:00Z")
        with pytest.raises(SmplValidationError):
            grp.save()


# ---------------------------------------------------------------------------
# delete_group(id) — direct delete via delete_log_group
# ---------------------------------------------------------------------------


class TestDeleteGroup:
    @patch("smplkit.logging.client.delete_log_group.sync_detailed")
    def test_delete_group_by_id(self, mock_delete):
        mock_delete.return_value = _ok_response(status=HTTPStatus.NO_CONTENT)

        client = _make_logging_client()
        client.delete_group("db-loggers")
        mock_delete.assert_called_once()
        assert mock_delete.call_args.args[0] == "db-loggers"

    @patch("smplkit.logging.client.delete_log_group.sync_detailed")
    def test_delete_group_not_found(self, mock_delete):
        mock_delete.return_value = _ok_response(status=HTTPStatus.NOT_FOUND)
        client = _make_logging_client()
        with pytest.raises(SmplNotFoundError):
            client.delete_group("nonexistent")


# ---------------------------------------------------------------------------
# Model convenience methods: setLevel, clearLevel, environment methods
# ---------------------------------------------------------------------------


class TestLoggerConvenienceMethods:
    def test_setLevel(self):
        lg = SmplLogger(None, id="sql", name="SQL Logger")
        lg.setLevel(LogLevel.ERROR)
        assert lg.level == "ERROR"

    def test_clearLevel(self):
        lg = SmplLogger(None, id="sql", name="SQL Logger", level="DEBUG")
        lg.clearLevel()
        assert lg.level is None

    def test_setEnvironmentLevel(self):
        lg = SmplLogger(None, id="sql", name="SQL Logger")
        lg.setEnvironmentLevel("prod", LogLevel.WARN)
        assert lg.environments["prod"] == {"level": "WARN"}

    def test_clearEnvironmentLevel(self):
        lg = SmplLogger(None, id="sql", name="SQL Logger", environments={"prod": {"level": "WARN"}})
        lg.clearEnvironmentLevel("prod")
        assert "prod" not in lg.environments

    def test_clearEnvironmentLevel_missing_key(self):
        lg = SmplLogger(None, id="sql", name="SQL Logger")
        lg.clearEnvironmentLevel("nonexistent")  # should not raise

    def test_clearAllEnvironmentLevels(self):
        lg = SmplLogger(
            None, id="sql", name="SQL Logger", environments={"prod": {"level": "WARN"}, "dev": {"level": "DEBUG"}}
        )
        lg.clearAllEnvironmentLevels()
        assert lg.environments == {}


class TestLogGroupConvenienceMethods:
    def test_setLevel(self):
        grp = SmplLogGroup(None, id="db", name="DB")
        grp.setLevel(LogLevel.ERROR)
        assert grp.level == "ERROR"

    def test_clearLevel(self):
        grp = SmplLogGroup(None, id="db", name="DB", level="WARN")
        grp.clearLevel()
        assert grp.level is None

    def test_setEnvironmentLevel(self):
        grp = SmplLogGroup(None, id="db", name="DB")
        grp.setEnvironmentLevel("staging", LogLevel.DEBUG)
        assert grp.environments["staging"] == {"level": "DEBUG"}

    def test_clearEnvironmentLevel(self):
        grp = SmplLogGroup(None, id="db", name="DB", environments={"staging": {"level": "DEBUG"}})
        grp.clearEnvironmentLevel("staging")
        assert "staging" not in grp.environments

    def test_clearEnvironmentLevel_missing_key(self):
        grp = SmplLogGroup(None, id="db", name="DB")
        grp.clearEnvironmentLevel("nonexistent")

    def test_clearAllEnvironmentLevels(self):
        grp = SmplLogGroup(None, id="db", name="DB", environments={"a": {"level": "DEBUG"}, "b": {"level": "ERROR"}})
        grp.clearAllEnvironmentLevels()
        assert grp.environments == {}


# ---------------------------------------------------------------------------
# start() — public wrapper for _connect_internal()
# ---------------------------------------------------------------------------


class TestStart:
    @patch("smplkit.logging.client.list_log_groups.sync_detailed")
    @patch("smplkit.logging.client.list_loggers.sync_detailed")
    @patch("smplkit.logging.client.bulk_register_loggers.sync_detailed")
    @patch("smplkit.logging.client._auto_load_adapters")
    def test_start_connects(self, mock_auto_load, mock_bulk, mock_loggers, mock_groups):
        mock_adapter = MagicMock()
        mock_adapter.discover.return_value = []
        mock_auto_load.return_value = [mock_adapter]
        mock_bulk.return_value = _ok_response()
        mock_loggers.return_value = _ok_response(_make_list_parsed([]))
        mock_groups.return_value = _ok_response(_make_list_parsed([]))

        client = _make_logging_client()
        client.start()
        assert client._connected is True
        client._close()

    @patch("smplkit.logging.client.list_log_groups.sync_detailed")
    @patch("smplkit.logging.client.list_loggers.sync_detailed")
    @patch("smplkit.logging.client.bulk_register_loggers.sync_detailed")
    @patch("smplkit.logging.client._auto_load_adapters")
    def test_start_is_idempotent(self, mock_auto_load, mock_bulk, mock_loggers, mock_groups):
        mock_adapter = MagicMock()
        mock_adapter.discover.return_value = []
        mock_auto_load.return_value = [mock_adapter]
        mock_bulk.return_value = _ok_response()
        mock_loggers.return_value = _ok_response(_make_list_parsed([]))
        mock_groups.return_value = _ok_response(_make_list_parsed([]))

        client = _make_logging_client()
        client.start()
        client.start()  # second call should be no-op
        mock_auto_load.assert_called_once()
        client._close()


# ---------------------------------------------------------------------------
# on_change — dual-mode decorator
# ---------------------------------------------------------------------------


class TestOnChange:
    def test_bare_decorator_global(self):
        client = _make_logging_client()
        calls = []

        @client.on_change
        def handler():
            calls.append(True)

        assert handler in client._global_listeners

    def test_key_scoped_decorator(self):
        client = _make_logging_client()
        calls = []

        @client.on_change("sqlalchemy.engine")
        def handler():
            calls.append(True)

        assert handler in client._key_listeners["sqlalchemy.engine"]

    def test_parens_no_args_global(self):
        client = _make_logging_client()
        calls = []

        @client.on_change()
        def handler():
            calls.append(True)

        assert handler in client._global_listeners

    def test_returns_original_function(self):
        client = _make_logging_client()

        @client.on_change("key")
        def my_fn():
            pass

        assert my_fn.__name__ == "my_fn"


# ---------------------------------------------------------------------------
# Management works without connect
# ---------------------------------------------------------------------------


class TestManagementWithoutConnect:
    @patch("smplkit.logging.client.list_loggers.sync_detailed")
    def test_list_without_connect(self, mock_list):
        mock_list.return_value = _ok_response(_make_list_parsed([]))

        client = _make_logging_client()
        assert client._connected is False
        result = client.list()
        assert result == []


# ---------------------------------------------------------------------------
# Registration buffer
# ---------------------------------------------------------------------------


class TestLoggerRegistrationBuffer:
    def test_add_and_drain(self):
        buf = _LoggerRegistrationBuffer()
        buf.add("com.example", "INFO", "my-service")
        batch = buf.drain()
        assert len(batch) == 1
        assert batch[0] == {"id": "com.example", "level": "INFO", "service": "my-service"}

    def test_dedup(self):
        buf = _LoggerRegistrationBuffer()
        buf.add("com.example", "INFO", "svc")
        buf.add("com.example", "DEBUG", "svc")
        batch = buf.drain()
        assert len(batch) == 1

    def test_service_omitted_when_none(self):
        buf = _LoggerRegistrationBuffer()
        buf.add("com.example", "INFO", None)
        batch = buf.drain()
        assert "service" not in batch[0]

    def test_drain_clears_pending(self):
        buf = _LoggerRegistrationBuffer()
        buf.add("a", "INFO", None)
        buf.drain()
        assert buf.drain() == []

    def test_pending_count(self):
        buf = _LoggerRegistrationBuffer()
        assert buf.pending_count == 0
        buf.add("a", "INFO", None)
        assert buf.pending_count == 1
        buf.add("b", "DEBUG", None)
        assert buf.pending_count == 2

    def test_includes_service_when_provided(self):
        buf = _LoggerRegistrationBuffer()
        buf.add("x", "WARN", "api-gateway")
        batch = buf.drain()
        assert batch[0]["service"] == "api-gateway"


# ---------------------------------------------------------------------------
# Bulk flush (fire-and-forget)
# ---------------------------------------------------------------------------


class TestBulkFlush:
    @patch("smplkit.logging.client.bulk_register_loggers.sync_detailed")
    def test_flush_sends_batch(self, mock_bulk):
        mock_bulk.return_value = _ok_response()
        client = _make_logging_client()
        client._buffer.add("com.test", "INFO", None)
        client._flush_bulk_sync()
        mock_bulk.assert_called_once()

    @patch("smplkit.logging.client.bulk_register_loggers.sync_detailed")
    def test_flush_noop_when_empty(self, mock_bulk):
        client = _make_logging_client()
        client._flush_bulk_sync()
        mock_bulk.assert_not_called()

    @patch("smplkit.logging.client.bulk_register_loggers.sync_detailed")
    def test_flush_fire_and_forget(self, mock_bulk):
        """Flush should not raise even if the HTTP call fails."""
        mock_bulk.side_effect = Exception("network error")
        client = _make_logging_client()
        client._buffer.add("com.test", "INFO", None)
        client._flush_bulk_sync()

    @patch("smplkit.logging.client.bulk_register_loggers.sync_detailed")
    def test_flush_logs_warning_on_http_error(self, mock_bulk, caplog):
        """Flush should log a WARNING with status and body on non-2xx."""
        mock_bulk.return_value = _ok_response(
            status=HTTPStatus.BAD_REQUEST,
        )
        mock_bulk.return_value.content = b'{"errors":[{"detail":"Invalid level"}]}'
        client = _make_logging_client()
        client._buffer.add("com.test", "INFO", None)
        with caplog.at_level(stdlib_logging.WARNING, logger="smplkit"):
            client._flush_bulk_sync()
        assert len(caplog.records) == 1
        assert "400" in caplog.records[0].message
        assert "Invalid level" in caplog.records[0].message
        assert caplog.records[0].levelno == stdlib_logging.WARNING

    @patch("smplkit.logging.client.bulk_register_loggers.sync_detailed")
    def test_flush_logs_warning_on_network_error(self, mock_bulk, caplog):
        """Flush should log a WARNING on network-level exceptions."""
        mock_bulk.side_effect = Exception("connection refused")
        client = _make_logging_client()
        client._buffer.add("com.test", "INFO", None)
        with caplog.at_level(stdlib_logging.WARNING, logger="smplkit"):
            client._flush_bulk_sync()
        assert len(caplog.records) == 1
        assert caplog.records[0].levelno == stdlib_logging.WARNING

    @patch("smplkit.logging.client.bulk_register_loggers.sync_detailed")
    def test_flush_no_metrics_on_http_error(self, mock_bulk):
        """Metrics should NOT be recorded on non-2xx responses."""
        mock_bulk.return_value = _ok_response(status=HTTPStatus.BAD_REQUEST)
        mock_bulk.return_value.content = b'{"errors":[]}'
        client = _make_logging_client()
        client._buffer.add("com.test", "INFO", None)
        client._flush_bulk_sync()
        client._parent._metrics.record.assert_not_called()


# ---------------------------------------------------------------------------
# Level application
# ---------------------------------------------------------------------------


class TestLevelApplication:
    def test_managed_logger_gets_level_applied(self):
        client = _make_logging_client()
        test_name = "test.apply.managed_001"
        mock_adapter = MagicMock()
        client._adapters = [mock_adapter]
        client._name_map[test_name] = "test.apply.managed_001"
        client._loggers_cache = {
            "test.apply.managed_001": {
                "level": "ERROR",
                "group": None,
                "managed": True,
                "environments": {},
            }
        }
        client._groups_cache = {}

        client._apply_levels()
        mock_adapter.apply_level.assert_called_once_with(test_name, 40)

    def test_unmanaged_logger_not_touched(self):
        client = _make_logging_client()
        test_name = "test.apply.unmanaged_002"
        mock_adapter = MagicMock()
        client._adapters = [mock_adapter]
        client._name_map[test_name] = "test.apply.unmanaged_002"
        client._loggers_cache = {
            "test.apply.unmanaged_002": {
                "level": "ERROR",
                "group": None,
                "managed": False,
                "environments": {},
            }
        }
        client._groups_cache = {}

        client._apply_levels()
        mock_adapter.apply_level.assert_not_called()

    def test_logger_in_server_not_in_runtime(self):
        client = _make_logging_client()
        client._loggers_cache = {
            "some.remote.logger": {
                "level": "ERROR",
                "group": None,
                "managed": True,
                "environments": {},
            }
        }
        client._groups_cache = {}
        client._apply_levels()


# ---------------------------------------------------------------------------
# Refresh
# ---------------------------------------------------------------------------


class TestRefresh:
    @patch("smplkit.logging.client.list_log_groups.sync_detailed")
    @patch("smplkit.logging.client.list_loggers.sync_detailed")
    def test_refresh_fetches_and_applies(self, mock_loggers, mock_groups):
        mock_loggers.return_value = _ok_response(_make_list_parsed([]))
        mock_groups.return_value = _ok_response(_make_list_parsed([]))

        client = _make_logging_client()
        client._connected = True
        client.refresh()
        mock_loggers.assert_called_once()
        mock_groups.assert_called_once()

    @patch("smplkit.logging.client.list_log_groups.sync_detailed")
    @patch("smplkit.logging.client.list_loggers.sync_detailed")
    def test_refresh_without_connect_works(self, mock_loggers, mock_groups):
        """refresh() no longer raises SmplNotConnectedError."""
        mock_loggers.return_value = _ok_response(_make_list_parsed([]))
        mock_groups.return_value = _ok_response(_make_list_parsed([]))

        client = _make_logging_client()
        assert client._connected is False
        client.refresh()  # Should not raise
        mock_loggers.assert_called_once()


# ---------------------------------------------------------------------------
# Integration: connect flow
# ---------------------------------------------------------------------------


class TestConnectFlow:
    @patch("smplkit.logging.client.list_log_groups.sync_detailed")
    @patch("smplkit.logging.client.list_loggers.sync_detailed")
    @patch("smplkit.logging.client.bulk_register_loggers.sync_detailed")
    @patch("smplkit.logging.client._auto_load_adapters")
    def test_connect_runs_full_flow(self, mock_auto_load, mock_bulk, mock_loggers, mock_groups):
        mock_adapter = MagicMock()
        mock_adapter.discover.return_value = [("root", 30), ("myapp.db", 10)]
        mock_auto_load.return_value = [mock_adapter]
        mock_bulk.return_value = _ok_response()
        mock_loggers.return_value = _ok_response(_make_list_parsed([]))
        mock_groups.return_value = _ok_response(_make_list_parsed([]))

        client = _make_logging_client()
        client._connect_internal()

        assert client._connected is True
        mock_adapter.discover.assert_called_once()
        mock_adapter.install_hook.assert_called_once()
        mock_bulk.assert_called_once()
        mock_loggers.assert_called_once()
        mock_groups.assert_called_once()
        client._close()

    @patch("smplkit.logging.client.list_log_groups.sync_detailed")
    @patch("smplkit.logging.client.list_loggers.sync_detailed")
    @patch("smplkit.logging.client.bulk_register_loggers.sync_detailed")
    @patch("smplkit.logging.client._auto_load_adapters")
    def test_connect_applies_managed_levels(self, mock_auto_load, mock_bulk, mock_loggers, mock_groups):
        test_name = "test.connect.managed_apply_flow"
        stdlib_logging.getLogger(test_name).setLevel(stdlib_logging.DEBUG)

        mock_adapter = MagicMock()
        mock_adapter.discover.return_value = [(test_name, stdlib_logging.DEBUG)]
        mock_auto_load.return_value = [mock_adapter]
        mock_bulk.return_value = _ok_response()

        logger_attrs = _make_logger_attrs(level="ERROR", managed=True)
        logger_resource = _make_resource(logger_attrs, id=test_name)
        mock_loggers.return_value = _ok_response(_make_list_parsed([logger_resource]))
        mock_groups.return_value = _ok_response(_make_list_parsed([]))

        client = _make_logging_client()
        client._connect_internal()

        # Level is applied via the adapter
        mock_adapter.apply_level.assert_called()
        client._close()

    @patch("smplkit.logging.client.list_log_groups.sync_detailed")
    @patch("smplkit.logging.client.list_loggers.sync_detailed")
    @patch("smplkit.logging.client.bulk_register_loggers.sync_detailed")
    @patch("smplkit.logging.client._auto_load_adapters")
    def test_connect_idempotent(self, mock_auto_load, mock_bulk, mock_loggers, mock_groups):
        mock_adapter = MagicMock()
        mock_adapter.discover.return_value = []
        mock_auto_load.return_value = [mock_adapter]
        mock_bulk.return_value = _ok_response()
        mock_loggers.return_value = _ok_response(_make_list_parsed([]))
        mock_groups.return_value = _ok_response(_make_list_parsed([]))

        client = _make_logging_client()
        client._connect_internal()
        client._connect_internal()  # second call is no-op
        mock_auto_load.assert_called_once()
        client._close()


# ---------------------------------------------------------------------------
# Close
# ---------------------------------------------------------------------------


class TestClose:
    def test_close_uninstalls_adapters(self):
        client = _make_logging_client()
        adapter = MagicMock()
        client._adapters = [adapter]
        client._close()
        adapter.uninstall_hook.assert_called_once()

    def test_close_cancels_timer(self):
        client = _make_logging_client()
        timer = MagicMock()
        client._flush_timer = timer
        client._close()
        timer.cancel.assert_called_once()


# ---------------------------------------------------------------------------
# Error mapping
# ---------------------------------------------------------------------------


class TestCheckResponseStatus:
    def test_404_raises_not_found(self):
        with pytest.raises(SmplNotFoundError):
            _check_response_status(HTTPStatus.NOT_FOUND, b"not found")

    def test_422_raises_validation(self):
        with pytest.raises(SmplValidationError):
            _check_response_status(HTTPStatus.UNPROCESSABLE_ENTITY, b"validation error")

    def test_200_no_raise(self):
        _check_response_status(HTTPStatus.OK, b"")
