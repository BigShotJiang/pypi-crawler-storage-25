from __future__ import annotations

from http import HTTPStatus
from typing import Any


class MesaError(Exception):
    """Base exception for all Mesa SDK errors."""

    code: str

    def __init__(self, code: str, message: str) -> None:
        self.code = code
        super().__init__(message)


class MissingApiKeyError(MesaError):
    def __init__(self, env_var: str) -> None:
        super().__init__(
            "MISSING_API_KEY",
            f"Missing API key. Pass `api_key` or set `{env_var}` in your environment.",
        )


class InvalidApiUrlError(MesaError):
    def __init__(self, api_url: str) -> None:
        super().__init__("INVALID_API_URL", f"Invalid API URL: {api_url}")


class OrgResolutionError(MesaError):
    def __init__(self, message: str) -> None:
        super().__init__("ORG_RESOLUTION_FAILED", message)


class ApiError(MesaError):
    """Base exception for HTTP API errors. Contains the status code and raw response."""

    status_code: int
    body: Any

    def __init__(self, status_code: int, body: Any) -> None:
        self.status_code = status_code
        self.body = body
        # Try to extract a message from the error body
        message = str(body)
        if hasattr(body, "error") and hasattr(body.error, "message"):
            message = body.error.message
        super().__init__(f"API_ERROR_{status_code}", message)


class AuthenticationError(ApiError):
    """Raised on 401 responses."""


class AuthorizationError(ApiError):
    """Raised on 403 responses."""


class NotFoundError(ApiError):
    """Raised on 404 responses."""


class ValidationError(ApiError):
    """Raised on 400 responses."""


class ConflictError(ApiError):
    """Raised on 409 responses."""


class RateLimitError(ApiError):
    """Raised on 429 responses."""


class ServerError(ApiError):
    """Raised on 5xx responses."""


_STATUS_TO_ERROR: dict[int, type[ApiError]] = {
    400: ValidationError,
    401: AuthenticationError,
    403: AuthorizationError,
    404: NotFoundError,
    406: ValidationError,
    409: ConflictError,
    429: RateLimitError,
}


def raise_for_status(status_code: int | HTTPStatus, parsed: Any) -> None:
    """Raise a typed ApiError if the status code indicates an error."""
    code = int(status_code)
    if HTTPStatus.OK <= code < HTTPStatus.MULTIPLE_CHOICES:
        return

    error_cls = _STATUS_TO_ERROR.get(code)
    if error_cls is None and code >= HTTPStatus.INTERNAL_SERVER_ERROR:
        error_cls = ServerError
    if error_cls is None:
        error_cls = ApiError

    raise error_cls(code, parsed)
