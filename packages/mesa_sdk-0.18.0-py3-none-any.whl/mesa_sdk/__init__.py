"""Official Mesa Python SDK."""

try:
    from importlib.metadata import version as _version

    __version__ = _version("mesa-sdk")
except Exception:
    __version__ = "0.0.0-dev"

# Git types are re-exported but lazily imported so that dulwich is only
# required when users actually use git operations.  The TYPE_CHECKING guard
# keeps type checkers happy while deferring the runtime import.
from typing import TYPE_CHECKING

from mesa_sdk._mesa import Mesa
from mesa_sdk.errors import (
    ApiError,
    AuthenticationError,
    AuthorizationError,
    ConflictError,
    InvalidApiUrlError,
    MesaError,
    MissingApiKeyError,
    NotFoundError,
    OrgResolutionError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from mesa_sdk.types import Author, FileChange, FileDelete, FileUpsert

if TYPE_CHECKING:
    from mesa_sdk.git import GitClient, GitCommitResult, GitFileStatus, GitStatus

__all__ = [
    "ApiError",
    "AuthenticationError",
    "Author",
    "AuthorizationError",
    "ConflictError",
    "FileChange",
    "FileDelete",
    "FileUpsert",
    "GitClient",
    "GitCommitResult",
    "GitFileStatus",
    "GitStatus",
    "InvalidApiUrlError",
    "Mesa",
    "MesaError",
    "MissingApiKeyError",
    "NotFoundError",
    "OrgResolutionError",
    "RateLimitError",
    "ServerError",
    "ValidationError",
]


def __getattr__(name: str):
    if name in ("GitClient", "GitCommitResult", "GitFileStatus", "GitStatus"):
        from mesa_sdk import git

        return getattr(git, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
