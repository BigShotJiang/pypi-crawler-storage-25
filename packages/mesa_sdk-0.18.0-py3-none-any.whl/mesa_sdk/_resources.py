from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol, Union

from mesa_rest.api.bookmark import (
    create_bookmark,
    delete_bookmark,
    list_bookmarks,
    merge_bookmark,
    move_bookmark,
)
from mesa_rest.api.change import (
    create_change,
    get_change,
    get_diff,
    list_changes,
    update_change,
)
from mesa_rest.api.content import get_content
from mesa_rest.api.org import (
    create_api_key,
    get_org,
    list_api_keys,
    revoke_api_key,
)
from mesa_rest.api.repo import (
    create_repo,
    delete_repo,
    get_repo,
    list_repos,
    update_repo,
)
from mesa_rest.api.webhook import (
    create_webhook,
    delete_webhook,
    list_webhooks,
)
from mesa_rest.models.create_api_key_body import CreateApiKeyBody
from mesa_rest.models.create_api_key_body_scopes_item import CreateApiKeyBodyScopesItem
from mesa_rest.models.create_bookmark_body import CreateBookmarkBody
from mesa_rest.models.create_change_body import CreateChangeBody
from mesa_rest.models.create_change_body_author import CreateChangeBodyAuthor
from mesa_rest.models.create_change_body_committer import CreateChangeBodyCommitter
from mesa_rest.models.create_change_body_files_item_type_0 import CreateChangeBodyFilesItemType0
from mesa_rest.models.create_change_body_files_item_type_1 import CreateChangeBodyFilesItemType1
from mesa_rest.models.create_repo_body import CreateRepoBody
from mesa_rest.models.create_webhook_body import CreateWebhookBody
from mesa_rest.models.create_webhook_body_events_item import CreateWebhookBodyEventsItem
from mesa_rest.models.get_content_response_200_type_0 import GetContentResponse200Type0
from mesa_rest.models.get_content_response_200_type_1 import GetContentResponse200Type1
from mesa_rest.models.get_content_response_200_type_2 import GetContentResponse200Type2
from mesa_rest.models.merge_bookmark_body import MergeBookmarkBody
from mesa_rest.models.move_bookmark_body import MoveBookmarkBody
from mesa_rest.models.update_change_body import UpdateChangeBody
from mesa_rest.models.update_change_body_author import UpdateChangeBodyAuthor
from mesa_rest.models.update_change_body_committer import UpdateChangeBodyCommitter
from mesa_rest.models.update_change_body_files_item_type_0 import UpdateChangeBodyFilesItemType0
from mesa_rest.models.update_change_body_files_item_type_1 import UpdateChangeBodyFilesItemType1
from mesa_rest.models.update_repo_body import UpdateRepoBody
from mesa_rest.types import UNSET

from mesa_sdk._client import unwrap
from mesa_sdk.types import Author, FileChange, FileDelete

if TYPE_CHECKING:
    from mesa_rest.client import AuthenticatedClient
    from mesa_rest.models.create_api_key_response_201 import CreateApiKeyResponse201
    from mesa_rest.models.create_bookmark_response_201 import CreateBookmarkResponse201
    from mesa_rest.models.create_change_response_201 import CreateChangeResponse201
    from mesa_rest.models.create_repo_response_201 import CreateRepoResponse201
    from mesa_rest.models.create_webhook_response_201 import CreateWebhookResponse201
    from mesa_rest.models.delete_bookmark_response_200 import DeleteBookmarkResponse200
    from mesa_rest.models.delete_repo_response_200 import DeleteRepoResponse200
    from mesa_rest.models.delete_webhook_response_200 import DeleteWebhookResponse200
    from mesa_rest.models.get_change_response_200 import GetChangeResponse200
    from mesa_rest.models.get_diff_response_200 import GetDiffResponse200
    from mesa_rest.models.get_org_response_200 import GetOrgResponse200
    from mesa_rest.models.get_repo_response_200 import GetRepoResponse200
    from mesa_rest.models.list_api_keys_response_200 import ListApiKeysResponse200
    from mesa_rest.models.list_bookmarks_response_200 import ListBookmarksResponse200
    from mesa_rest.models.list_changes_response_200 import ListChangesResponse200
    from mesa_rest.models.list_repos_response_200 import ListReposResponse200
    from mesa_rest.models.list_webhooks_response_200 import ListWebhooksResponse200
    from mesa_rest.models.merge_bookmark_response_200 import MergeBookmarkResponse200
    from mesa_rest.models.move_bookmark_response_200 import MoveBookmarkResponse200
    from mesa_rest.models.revoke_api_key_response_200 import RevokeApiKeyResponse200
    from mesa_rest.models.update_change_response_200 import UpdateChangeResponse200
    from mesa_rest.models.update_repo_response_200 import UpdateRepoResponse200


def _opt(value: object) -> Any:
    """Convert None to UNSET at the mesa-rest boundary."""
    return UNSET if value is None else value


def _to_create_author(a: Author) -> CreateChangeBodyAuthor:
    return CreateChangeBodyAuthor(name=a.name, email=a.email, date=_opt(a.date))


def _to_create_committer(c: Author) -> CreateChangeBodyCommitter:
    return CreateChangeBodyCommitter(name=c.name, email=c.email, date=_opt(c.date))


def _to_create_file(
    f: FileChange,
) -> CreateChangeBodyFilesItemType0 | CreateChangeBodyFilesItemType1:
    if isinstance(f, FileDelete):
        return CreateChangeBodyFilesItemType1(path=f.path, action="delete")
    return CreateChangeBodyFilesItemType0(
        path=f.path,
        content=f.content,
        encoding=_opt(f.encoding),
        action=_opt(f.action),
        mode=_opt(f.mode),
    )


def _to_update_author(a: Author) -> UpdateChangeBodyAuthor:
    return UpdateChangeBodyAuthor(name=a.name, email=a.email, date=_opt(a.date))


def _to_update_committer(c: Author) -> UpdateChangeBodyCommitter:
    return UpdateChangeBodyCommitter(name=c.name, email=c.email, date=_opt(c.date))


def _to_update_file(
    f: FileChange,
) -> UpdateChangeBodyFilesItemType0 | UpdateChangeBodyFilesItemType1:
    if isinstance(f, FileDelete):
        return UpdateChangeBodyFilesItemType1(path=f.path, action="delete")
    return UpdateChangeBodyFilesItemType0(
        path=f.path,
        content=f.content,
        encoding=_opt(f.encoding),
        action=_opt(f.action),
        mode=_opt(f.mode),
    )


ContentResponse = Union[
    GetContentResponse200Type0, GetContentResponse200Type1, GetContentResponse200Type2
]


class OrgResolver(Protocol):
    async def __call__(self, org: str | None = None) -> str: ...


class OrgResource:
    def __init__(self, client: AuthenticatedClient, resolve_org: OrgResolver) -> None:
        self._client = client
        self._resolve_org = resolve_org

    async def get(self, *, org: str | None = None) -> GetOrgResponse200:
        resolved = await self._resolve_org(org)
        resp = await get_org.asyncio_detailed(resolved, client=self._client)
        return unwrap(resp)


class ApiKeys:
    def __init__(self, client: AuthenticatedClient, resolve_org: OrgResolver) -> None:
        self._client = client
        self._resolve_org = resolve_org

    async def list(
        self,
        *,
        org: str | None = None,
        cursor: str | None = None,
        limit: int | None = None,
    ) -> ListApiKeysResponse200:
        resolved = await self._resolve_org(org)
        resp = await list_api_keys.asyncio_detailed(
            resolved,
            client=self._client,
            cursor=_opt(cursor),
            limit=_opt(limit),
        )
        return unwrap(resp)

    async def create(
        self,
        *,
        org: str | None = None,
        name: str | None = None,
        scopes: list[str] | None = None,
        repo_ids: list[str] | None = None,
        expires_in_seconds: int | None = None,
    ) -> CreateApiKeyResponse201:
        resolved = await self._resolve_org(org)
        body = CreateApiKeyBody(
            name=_opt(name),
            scopes=[CreateApiKeyBodyScopesItem(s) for s in scopes] if scopes is not None else UNSET,
            repo_ids=_opt(repo_ids),
            expires_in_seconds=_opt(expires_in_seconds),
        )
        resp = await create_api_key.asyncio_detailed(
            resolved,
            client=self._client,
            body=body,
        )
        return unwrap(resp)

    async def revoke(self, *, key_id: str, org: str | None = None) -> RevokeApiKeyResponse200:
        resolved = await self._resolve_org(org)
        resp = await revoke_api_key.asyncio_detailed(
            resolved,
            key_id,
            client=self._client,
        )
        return unwrap(resp)


class Repos:
    def __init__(self, client: AuthenticatedClient, resolve_org: OrgResolver) -> None:
        self._client = client
        self._resolve_org = resolve_org

    async def list(
        self,
        *,
        org: str | None = None,
        cursor: str | None = None,
        limit: int | None = None,
        tags: str | None = None,
    ) -> ListReposResponse200:
        resolved = await self._resolve_org(org)
        resp = await list_repos.asyncio_detailed(
            resolved,
            client=self._client,
            cursor=_opt(cursor),
            limit=_opt(limit),
            tags=_opt(tags),
        )
        return unwrap(resp)

    async def create(
        self,
        *,
        org: str | None = None,
        name: str | None = None,
        default_bookmark: str | None = None,
    ) -> CreateRepoResponse201:
        resolved = await self._resolve_org(org)
        body = CreateRepoBody(name=_opt(name), default_bookmark=_opt(default_bookmark))
        resp = await create_repo.asyncio_detailed(
            resolved,
            client=self._client,
            body=body,
        )
        return unwrap(resp)

    async def get(self, *, repo: str, org: str | None = None) -> GetRepoResponse200:
        resolved = await self._resolve_org(org)
        resp = await get_repo.asyncio_detailed(
            resolved,
            repo,
            client=self._client,
        )
        return unwrap(resp)

    async def update(
        self,
        *,
        repo: str,
        org: str | None = None,
        name: str | None = None,
        default_bookmark: str | None = None,
    ) -> UpdateRepoResponse200:
        resolved = await self._resolve_org(org)
        body = UpdateRepoBody(name=_opt(name), default_bookmark=_opt(default_bookmark))
        resp = await update_repo.asyncio_detailed(
            resolved,
            repo,
            client=self._client,
            body=body,
        )
        return unwrap(resp)

    async def delete(self, *, repo: str, org: str | None = None) -> DeleteRepoResponse200:
        resolved = await self._resolve_org(org)
        resp = await delete_repo.asyncio_detailed(
            resolved,
            repo,
            client=self._client,
        )
        return unwrap(resp)


class Content:
    def __init__(self, client: AuthenticatedClient, resolve_org: OrgResolver) -> None:
        self._client = client
        self._resolve_org = resolve_org

    async def get(
        self,
        *,
        repo: str,
        org: str | None = None,
        change_id: str | None = None,
        path: str | None = None,
        depth: int | None = None,
    ) -> ContentResponse:
        resolved = await self._resolve_org(org)
        resp = await get_content.asyncio_detailed(
            resolved,
            repo,
            client=self._client,
            change_id=_opt(change_id),
            path=_opt(path),
            depth=_opt(depth),
        )
        return unwrap(resp)


class Bookmarks:
    def __init__(self, client: AuthenticatedClient, resolve_org: OrgResolver) -> None:
        self._client = client
        self._resolve_org = resolve_org

    async def list(
        self,
        *,
        repo: str,
        org: str | None = None,
        cursor: str | None = None,
        limit: int | None = None,
    ) -> ListBookmarksResponse200:
        resolved = await self._resolve_org(org)
        resp = await list_bookmarks.asyncio_detailed(
            resolved,
            repo,
            client=self._client,
            cursor=_opt(cursor),
            limit=_opt(limit),
        )
        return unwrap(resp)

    async def create(
        self,
        *,
        repo: str,
        name: str,
        change_id: str,
        org: str | None = None,
    ) -> CreateBookmarkResponse201:
        resolved = await self._resolve_org(org)
        body = CreateBookmarkBody(name=name, change_id=change_id)
        resp = await create_bookmark.asyncio_detailed(
            resolved,
            repo,
            client=self._client,
            body=body,
        )
        return unwrap(resp)

    async def delete(
        self,
        *,
        repo: str,
        bookmark: str,
        org: str | None = None,
    ) -> DeleteBookmarkResponse200:
        resolved = await self._resolve_org(org)
        resp = await delete_bookmark.asyncio_detailed(
            resolved,
            repo,
            bookmark,
            client=self._client,
        )
        return unwrap(resp)

    async def move(
        self,
        *,
        repo: str,
        bookmark: str,
        change_id: str,
        org: str | None = None,
    ) -> MoveBookmarkResponse200:
        resolved = await self._resolve_org(org)
        body = MoveBookmarkBody(change_id=change_id)
        resp = await move_bookmark.asyncio_detailed(
            resolved,
            repo,
            bookmark,
            client=self._client,
            body=body,
        )
        return unwrap(resp)

    async def merge(
        self,
        *,
        repo: str,
        source: str,
        target: str,
        delete_source: bool | None = None,
        org: str | None = None,
    ) -> MergeBookmarkResponse200:
        resolved = await self._resolve_org(org)
        body = MergeBookmarkBody(
            source=source,
            target=target,
            delete_source=_opt(delete_source),
        )
        resp = await merge_bookmark.asyncio_detailed(
            resolved,
            repo,
            client=self._client,
            body=body,
        )
        return unwrap(resp)


class Changes:
    def __init__(self, client: AuthenticatedClient, resolve_org: OrgResolver) -> None:
        self._client = client
        self._resolve_org = resolve_org

    async def list(
        self,
        *,
        repo: str,
        org: str | None = None,
        cursor: str | None = None,
        limit: int | None = None,
        bookmark: str | None = None,
    ) -> ListChangesResponse200:
        resolved = await self._resolve_org(org)
        resp = await list_changes.asyncio_detailed(
            resolved,
            repo,
            client=self._client,
            cursor=_opt(cursor),
            limit=_opt(limit),
            bookmark=_opt(bookmark),
        )
        return unwrap(resp)

    async def create(
        self,
        *,
        repo: str,
        base_change_id: str,
        org: str | None = None,
        message: str | None = None,
        author: Author | None = None,
        committer: Author | None = None,
        files: list[FileChange] | None = None,
    ) -> CreateChangeResponse201:
        resolved = await self._resolve_org(org)
        body = CreateChangeBody(
            base_change_id=base_change_id,
            message=_opt(message),
            author=_to_create_author(author) if author is not None else UNSET,
            committer=_to_create_committer(committer) if committer is not None else UNSET,
            files=[_to_create_file(f) for f in files] if files is not None else UNSET,
        )
        resp = await create_change.asyncio_detailed(
            resolved,
            repo,
            client=self._client,
            body=body,
        )
        return unwrap(resp)

    async def get(
        self,
        *,
        repo: str,
        change_id: str,
        org: str | None = None,
    ) -> GetChangeResponse200:
        resolved = await self._resolve_org(org)
        resp = await get_change.asyncio_detailed(
            resolved,
            repo,
            change_id,
            client=self._client,
        )
        return unwrap(resp)

    async def patch(
        self,
        *,
        repo: str,
        change_id: str,
        org: str | None = None,
        message: str | None = None,
        author: Author | None = None,
        committer: Author | None = None,
        files: list[FileChange] | None = None,
        base_commit_oid: str | None = None,
    ) -> UpdateChangeResponse200:
        resolved = await self._resolve_org(org)
        body = UpdateChangeBody(
            message=_opt(message),
            author=_to_update_author(author) if author is not None else UNSET,
            committer=_to_update_committer(committer) if committer is not None else UNSET,
            files=[_to_update_file(f) for f in files] if files is not None else UNSET,
            base_commit_oid=_opt(base_commit_oid),
        )
        resp = await update_change.asyncio_detailed(
            resolved,
            repo,
            change_id,
            client=self._client,
            body=body,
        )
        return unwrap(resp)


class Diffs:
    def __init__(self, client: AuthenticatedClient, resolve_org: OrgResolver) -> None:
        self._client = client
        self._resolve_org = resolve_org

    async def get(
        self,
        *,
        repo: str,
        base_change_id: str,
        head_change_id: str,
        org: str | None = None,
    ) -> GetDiffResponse200:
        resolved = await self._resolve_org(org)
        resp = await get_diff.asyncio_detailed(
            resolved,
            repo,
            client=self._client,
            base_change_id=base_change_id,
            head_change_id=head_change_id,
        )
        return unwrap(resp)


class Webhooks:
    def __init__(self, client: AuthenticatedClient, resolve_org: OrgResolver) -> None:
        self._client = client
        self._resolve_org = resolve_org

    async def list(
        self,
        *,
        org: str | None = None,
        cursor: str | None = None,
        limit: int | None = None,
    ) -> ListWebhooksResponse200:
        resolved = await self._resolve_org(org)
        resp = await list_webhooks.asyncio_detailed(
            resolved,
            client=self._client,
            cursor=_opt(cursor),
            limit=_opt(limit),
        )
        return unwrap(resp)

    async def create(
        self,
        *,
        url: str,
        org: str | None = None,
        events: list[str] | None = None,
        repo_ids: list[str] | None = None,
        secret: str | None = None,
    ) -> CreateWebhookResponse201:
        resolved = await self._resolve_org(org)
        body = CreateWebhookBody(
            url=url,
            events=[CreateWebhookBodyEventsItem(e) for e in events]
            if events is not None
            else UNSET,
            repo_ids=_opt(repo_ids),
            secret=_opt(secret),
        )
        resp = await create_webhook.asyncio_detailed(
            resolved,
            client=self._client,
            body=body,
        )
        return unwrap(resp)

    async def delete(
        self,
        *,
        webhook_id: str,
        org: str | None = None,
    ) -> DeleteWebhookResponse200:
        resolved = await self._resolve_org(org)
        resp = await delete_webhook.asyncio_detailed(
            resolved,
            webhook_id,
            client=self._client,
        )
        return unwrap(resp)
