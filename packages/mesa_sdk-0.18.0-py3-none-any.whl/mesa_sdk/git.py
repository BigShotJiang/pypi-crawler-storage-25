from __future__ import annotations

import asyncio
import functools
from collections.abc import Callable
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import ParamSpec, TypeVar

from dulwich import porcelain
from dulwich.repo import Repo

P = ParamSpec("P")
R = TypeVar("R")


@dataclass
class GitCommitResult:
    sha: str


@dataclass
class GitFileStatus:
    name: str
    status: str


@dataclass
class GitStatus:
    current_branch: str
    ahead: int
    behind: int
    branch_published: bool
    file_status: list[GitFileStatus]


def _async_wrap(fn: Callable[P, R]) -> Callable[P, asyncio.coroutines]:
    """Wrap a sync function to run in a thread pool, usable as a class attribute."""

    @functools.wraps(fn)
    async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        return await asyncio.to_thread(fn, *args, **kwargs)

    # staticmethod so Python doesn't pass `self` when used as a class attribute
    return staticmethod(wrapper)  # type: ignore[return-value]


def _decode(value: str | bytes) -> str:
    return value.decode() if isinstance(value, bytes) else value


@contextmanager
def _open_repo(path: str):
    repo = Repo(_resolve_path(path))
    try:
        yield repo
    finally:
        repo.close()


def _resolve_path(path: str) -> str:
    return str(Path(path).resolve())


def _get_current_branch(repo: Repo) -> str | None:
    """Get the current branch name, or None if HEAD is detached."""
    try:
        ref = repo.refs.get_symrefs().get(b"HEAD")
        if ref and ref.startswith(b"refs/heads/"):
            return ref[len(b"refs/heads/"):].decode()
    except KeyError:
        pass
    return None


def _require_branch(repo: Repo, operation: str) -> str:
    branch = _get_current_branch(repo)
    if branch is None:
        raise RuntimeError(f"Cannot {operation} while HEAD is detached. Checkout a branch first.")
    return branch


def _ahead_behind(repo: Repo, branch: str) -> tuple[int, int, bool]:
    """Compute ahead/behind counts relative to origin/<branch>."""
    remote_ref = f"refs/remotes/origin/{branch}".encode()
    if remote_ref not in repo.refs.allkeys():
        return 0, 0, False

    local_head = repo.refs[f"refs/heads/{branch}".encode()]
    remote_head = repo.refs[remote_ref]
    if local_head == remote_head:
        return 0, 0, True

    local_commits = [e.commit.id for e in repo.get_walker(include=[local_head])]
    remote_commits = [e.commit.id for e in repo.get_walker(include=[remote_head])]

    remote_set = set(remote_commits)
    ahead = next(
        (i for i, c in enumerate(local_commits) if c in remote_set),
        len(local_commits),
    )

    local_set = set(local_commits)
    behind = next(
        (i for i, c in enumerate(remote_commits) if c in local_set),
        len(remote_commits),
    )

    return ahead, behind, True


def _clone(
    url: str,
    path: str,
    *,
    branch: str | None = None,
    commit_id: str | None = None,  # NB: passing commit_id detaches HEAD
    depth: int | None = None,
    username: str | None = None,
    password: str | None = None,
) -> None:
    repo_dir = _resolve_path(path)
    porcelain.clone(
        url,
        repo_dir,
        branch=branch.encode() if branch else None,
        depth=depth,
        username=username,
        password=password,
    )
    if commit_id:
        with _open_repo(path) as repo:
            repo.refs[b"HEAD"] = commit_id.encode()
            porcelain.reset(repo, "hard", commit_id.encode())


def _add(path: str, files: list[str]) -> None:
    repo_dir = _resolve_path(path)
    for f in files:
        if f == ".":
            porcelain.add(repo_dir)
            return
    porcelain.add(repo_dir, paths=files)


def _commit(
    path: str,
    *,
    message: str,
    author: str,
    email: str,
    allow_empty: bool = False,
) -> GitCommitResult:
    repo_dir = _resolve_path(path)

    if not allow_empty:
        status = porcelain.status(repo_dir)
        has_staged = bool(
            status.staged["add"] or status.staged["modify"] or status.staged["delete"]
        )
        if not has_staged:
            raise RuntimeError(
                "No staged changes to commit. Set allow_empty=True to create an empty commit."
            )

    author_bytes = f"{author} <{email}>".encode()
    sha = porcelain.commit(
        repo_dir,
        message=message.encode(),
        author=author_bytes,
        committer=author_bytes,
        sign=False,
    )
    return GitCommitResult(sha=sha.decode())


def _push(
    path: str,
    *,
    remote: str = "origin",
    username: str | None = None,
    password: str | None = None,
) -> None:
    with _open_repo(path) as repo:
        branch = _require_branch(repo, "push")
    porcelain.push(
        _resolve_path(path),
        remote_location=remote,
        refspecs=f"refs/heads/{branch}".encode(),
        username=username,
        password=password,
    )


def _pull(
    path: str,
    *,
    remote: str = "origin",
    username: str | None = None,
    password: str | None = None,
) -> None:
    porcelain.pull(
        _resolve_path(path),
        remote_location=remote,
        username=username,
        password=password,
    )


def _status(path: str) -> GitStatus:
    with _open_repo(path) as repo:
        branch = _require_branch(repo, "read status")
        status = porcelain.status(_resolve_path(path))

        file_status = [
            *(GitFileStatus(name=_decode(f), status="added") for f in status.staged["add"]),
            *(GitFileStatus(name=_decode(f), status="staged") for f in status.staged["modify"]),
            *(GitFileStatus(name=_decode(f), status="deleted") for f in status.staged["delete"]),
            *(GitFileStatus(name=_decode(f), status="modified") for f in status.unstaged),
            *(GitFileStatus(name=_decode(f), status="untracked") for f in status.untracked),
        ]

        ahead, behind, branch_published = _ahead_behind(repo, branch)

    return GitStatus(
        current_branch=branch,
        ahead=ahead,
        behind=behind,
        branch_published=branch_published,
        file_status=file_status,
    )


def _branches(path: str) -> list[str]:
    with _open_repo(path) as repo:
        return sorted(
            ref[len(b"refs/heads/"):].decode()
            for ref in repo.refs.allkeys()
            if ref.startswith(b"refs/heads/")
        )


def _create_branch(path: str, name: str) -> None:
    porcelain.branch_create(_resolve_path(path), name)


def _checkout_branch(path: str, branch: str) -> None:
    porcelain.checkout(_resolve_path(path), target=branch)


def _delete_branch(path: str, name: str) -> None:
    with _open_repo(path) as repo:
        if _get_current_branch(repo) == name:
            raise RuntimeError(f"Cannot delete the currently checked out branch '{name}'")
    porcelain.branch_delete(_resolve_path(path), name)


class GitClient:
    """Async git client powered by dulwich. All operations run in a thread pool."""

    clone = _async_wrap(_clone)
    add = _async_wrap(_add)
    commit = _async_wrap(_commit)
    push = _async_wrap(_push)
    pull = _async_wrap(_pull)
    status = _async_wrap(_status)
    branches = _async_wrap(_branches)
    create_branch = _async_wrap(_create_branch)
    checkout_branch = _async_wrap(_checkout_branch)
    delete_branch = _async_wrap(_delete_branch)
