"""Public types for the Mesa SDK.

These provide a stable, ergonomic interface for SDK input parameters.
They are converted to the generated mesa-rest body models internally.
"""

from __future__ import annotations

import datetime
from dataclasses import dataclass
from typing import Literal, Union


@dataclass
class Author:
    """Commit author or committer identity."""

    name: str
    email: str
    date: datetime.datetime | None = None


@dataclass
class FileUpsert:
    """A file to create or update in a change."""

    path: str
    content: str
    encoding: Literal["base64"] | None = "base64"
    action: Literal["upsert"] | None = None
    mode: str | None = None


@dataclass
class FileDelete:
    """A file to delete in a change."""

    path: str
    action: Literal["delete"] = "delete"


FileChange = Union[FileUpsert, FileDelete]
