import argparse
import os
import shlex
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path

from repo_control import config, gh, git, ide, picker, setup, state

SKILL_NAME = "repo-control"


@dataclass(frozen=True)
class WorktreeRow:
    repo_slug: str
    pr_number: int | None
    branch: str | None
    path: Path
    status: str


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="repo-control",
        description="Mirror your open GitHub PRs as per-repo worktree folders under a base path.",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)
    sync_p = sub.add_parser("sync", help="Refresh worktrees from open PRs")
    sync_p.add_argument(
        "repo",
        nargs="?",
        default=None,
        help="Limit sync to one repo (owner/name or GitHub URL); default: all authored PRs",
    )
    sub.add_parser("list", help="Show all tracked worktrees")
    open_p = sub.add_parser("open", help="Open a PR's worktree in the IDE")
    open_p.add_argument("pr", help="PR number (or owner/repo#N for disambiguation)")
    open_p.add_argument(
        "--ide",
        default=None,
        help=f"Editor command ({', '.join(ide.KNOWN)}, or any binary on PATH; quote for args)",
    )
    clean_p = sub.add_parser("clean", help="Remove stale worktrees")
    clean_p.add_argument(
        "--force", action="store_true", help="Also drop dirty worktrees (with confirmation)"
    )
    install_p = sub.add_parser(
        "install-skill", help="Symlink the bundled Claude skill into ~/.claude/skills/"
    )
    install_p.add_argument("--uninstall", action="store_true", help="Remove the symlink")
    install_p.add_argument(
        "--force", action="store_true", help="Replace an existing non-symlink at the destination"
    )
    sub.add_parser("setup", help="Interactive first-run configuration (or re-configure later)")

    args = parser.parse_args()
    try:
        if args.cmd == "sync":
            return cmd_sync(repo_arg=args.repo)
        if args.cmd == "list":
            return cmd_list()
        if args.cmd == "open":
            return cmd_open(reference=args.pr, ide_override=args.ide)
        if args.cmd == "clean":
            return cmd_clean(force=args.force)
        if args.cmd == "install-skill":
            return cmd_install_skill(uninstall=args.uninstall, force=args.force)
        if args.cmd == "setup":
            return cmd_setup()
    except (gh.GhError, git.GitError, ValueError, RuntimeError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 1
    return 0


def cmd_sync(*, repo_arg: str | None = None) -> int:
    gh.check_auth()
    if not config.exists():
        print("No config found; running first-run setup.\n")
        rc = cmd_setup()
        if rc != 0:
            return rc
        print()
    cfg = config.load()
    skip = set(cfg["skip_repos"])
    base = config.base_path(cfg=cfg)
    base.mkdir(parents=True, exist_ok=True)

    single_repo = _parse_repo_arg(value=repo_arg) if repo_arg else None
    if repo_arg and single_repo is None:
        raise ValueError(f"could not parse {repo_arg!r} as owner/name or GitHub URL")

    prs = gh.list_open_prs()
    by_repo: dict[tuple[str, str], dict[int, gh.OpenPR]] = {}
    for pr in prs:
        if pr.base_slug in skip:
            continue
        if single_repo is not None and (pr.base_owner, pr.base_repo) != single_repo:
            continue
        by_repo.setdefault((pr.base_owner, pr.base_repo), {})[pr.number] = pr

    selected_repos = _select_repos_interactive(by_repo=by_repo, single_repo=single_repo)
    if selected_repos is None:
        print("sync cancelled")
        return 0
    desired = {key: prs_by_num for key, prs_by_num in by_repo.items() if key in selected_repos}

    created: list[Path] = []
    refreshed: list[Path] = []
    removed: list[Path] = []
    kept_dirty: list[Path] = []
    setup_steps: dict[Path, list[str]] = {}

    for (owner, name), prs_by_num in sorted(desired.items()):
        repo_path = state.resolve_repo_dir(base_path=base, owner=owner, name=name)
        main_path = state.ensure_main_path(
            repo_path=repo_path, name=name, prefix=cfg["prefix_worktrees"]
        )
        if repo_path.exists() and main_path.exists():
            existing = git.remote_url(repo_path=main_path)
            existing_parsed = git.parse_owner_repo(url=existing) if existing else None
            if existing_parsed is not None and existing_parsed != (owner, name):
                print(
                    f"skipping {owner}/{name}: {repo_path} already mirrors "
                    f"{existing_parsed[0]}/{existing_parsed[1]} (name collision)"
                )
                continue
        if not main_path.exists():
            print(f"cloning {owner}/{name} ...")
            if cfg["bare_repo"]:
                git_dir = repo_path / ".git"
                if not git_dir.exists():
                    git.clone_bare(owner=owner, name=name, git_dir=git_dir)
                default = git.default_branch(repo_path=git_dir)
                git.worktree_add_tracking(
                    repo_path=git_dir,
                    target=main_path,
                    local_branch=default,
                    upstream=f"origin/{default}",
                )
            else:
                main_path.parent.mkdir(parents=True, exist_ok=True)
                git.clone(owner=owner, name=name, target=main_path)
        git.fetch(repo_path=main_path)
        default = git.default_branch(repo_path=main_path)
        git.fast_forward(repo_path=main_path, branch=default)

        for pr_number, pr in sorted(prs_by_num.items()):
            wt_path = state.worktree_path(
                repo_path=repo_path,
                name=name,
                pr_number=pr_number,
                branch=pr.head_branch,
                layout=cfg["worktree_layout"],
                prefix=cfg["prefix_worktrees"],
            )
            wt_path.parent.mkdir(parents=True, exist_ok=True)
            local_branch = f"pr-{pr_number}" if pr.is_fork else pr.head_branch
            if wt_path.exists():
                if pr.is_fork and pr.fork_clone_url:
                    git.fetch_fork(
                        repo_path=main_path,
                        fork_url=pr.fork_clone_url,
                        head_branch=pr.head_branch,
                        local_branch=local_branch,
                    )
                else:
                    git.fetch(repo_path=main_path, refspec=pr.head_branch)
                refreshed.append(wt_path)
                continue
            if pr.is_fork and pr.fork_clone_url:
                git.fetch_fork(
                    repo_path=main_path,
                    fork_url=pr.fork_clone_url,
                    head_branch=pr.head_branch,
                    local_branch=local_branch,
                )
            else:
                git.fetch(repo_path=main_path, refspec=pr.head_branch)
            git.worktree_add(repo_path=main_path, target=wt_path, branch=local_branch)
            created.append(wt_path)
            setup_steps[wt_path] = setup.run_init(worktree_path=wt_path, cfg=cfg)

    for repo in state.discover_repos(base_path=base):
        if (repo.owner, repo.name) not in selected_repos:
            continue
        wanted = desired.get((repo.owner, repo.name), {})
        wanted_paths = {
            state.worktree_path(
                repo_path=repo.path,
                name=repo.name,
                pr_number=pr.number,
                branch=pr.head_branch,
                layout=cfg["worktree_layout"],
                prefix=cfg["prefix_worktrees"],
            )
            for pr in wanted.values()
        }
        wanted_paths.add(repo.main_path)
        default = git.default_branch(repo_path=repo.main_path)
        for worktree in state.existing_worktrees(repo=repo):
            wt_path = worktree.path.resolve()
            if wt_path == repo.main_path.resolve():
                continue
            if wt_path in {p.resolve() for p in wanted_paths}:
                continue
            if not git.is_clean(worktree_path=wt_path):
                kept_dirty.append(wt_path)
                continue
            git.worktree_remove(repo_path=repo.main_path, target=wt_path)
            if worktree.branch and worktree.branch != default:
                git.delete_branch(repo_path=repo.main_path, branch=worktree.branch)
            removed.append(wt_path)

    _print_sync_summary(
        created=created,
        refreshed=refreshed,
        removed=removed,
        kept_dirty=kept_dirty,
        setup_steps=setup_steps,
    )
    return 0


def cmd_list() -> int:
    rows = _collect_rows()
    if not rows:
        print("no worktrees tracked yet — run `repo-control sync`")
        return 0
    _print_table(rows=rows)
    return 0


def cmd_open(*, reference: str, ide_override: str | None) -> int:
    cfg = config.load()
    chosen = ide_override or cfg["ide"]
    path = _resolve_pr(reference=reference)
    if path is None:
        print(f"no worktree found for {reference!r}", file=sys.stderr)
        return 1
    ide.launch(ide=chosen, path=path)
    print(f"launching {chosen} on {path}")
    return 0


def cmd_clean(*, force: bool) -> int:
    gh.check_auth()
    cfg = config.load()
    base = config.base_path(cfg=cfg)
    prs = gh.list_open_prs()
    wanted_by_repo: dict[tuple[str, str], set[Path]] = {}
    for pr in prs:
        key = (pr.base_owner, pr.base_repo)
        repo_path = state.resolve_repo_dir(base_path=base, owner=pr.base_owner, name=pr.base_repo)
        wt = state.worktree_path(
            repo_path=repo_path,
            name=pr.base_repo,
            pr_number=pr.number,
            branch=pr.head_branch,
            layout=cfg["worktree_layout"],
            prefix=cfg["prefix_worktrees"],
        )
        wanted_by_repo.setdefault(key, set()).add(wt.resolve())

    stale_clean: list[tuple[Path, Path, str | None]] = []
    stale_dirty: list[tuple[Path, Path]] = []  # (main_path, wt_path)
    for repo in state.discover_repos(base_path=base):
        wanted = wanted_by_repo.get((repo.owner, repo.name), set())
        default = git.default_branch(repo_path=repo.main_path)
        for worktree in state.existing_worktrees(repo=repo):
            wt_path = worktree.path.resolve()
            if wt_path == repo.main_path.resolve():
                continue
            if wt_path in wanted:
                continue
            if git.is_clean(worktree_path=wt_path):
                stale_clean.append(
                    (
                        repo.main_path,
                        wt_path,
                        worktree.branch if worktree.branch != default else None,
                    )
                )
            else:
                stale_dirty.append((repo.main_path, wt_path))

    for main_path, wt_path, branch in stale_clean:
        git.worktree_remove(repo_path=main_path, target=wt_path)
        if branch:
            git.delete_branch(repo_path=main_path, branch=branch)
        print(f"removed {wt_path}")

    if not stale_dirty:
        return 0
    if not force:
        print(f"\n{len(stale_dirty)} dirty stale worktree(s) preserved:")
        for _, path in stale_dirty:
            print(f"  {path}")
        print("re-run with --force to drop them anyway")
        return 0
    print(f"\nabout to remove {len(stale_dirty)} dirty worktree(s):")
    for _, path in stale_dirty:
        print(f"  {path}")
    answer = input("type 'yes' to confirm: ").strip().lower()
    if answer != "yes":
        print("aborted")
        return 1
    for main_path, wt_path in stale_dirty:
        git.worktree_remove(repo_path=main_path, target=wt_path)
        print(f"removed {wt_path}")
    return 0


def _select_repos_interactive(
    *,
    by_repo: dict[tuple[str, str], dict[int, gh.OpenPR]],
    single_repo: tuple[str, str] | None,
) -> set[tuple[str, str]] | None:
    """Show a picker when there's a real choice; otherwise return everything in by_repo."""
    all_keys = set(by_repo.keys())
    if single_repo is not None or len(by_repo) <= 1 or not sys.stdin.isatty():
        return all_keys
    choices = [
        picker.Choice(key=f"{owner}/{name}", label=f"{owner}/{name} ({len(prs)} PRs)")
        for (owner, name), prs in sorted(by_repo.items())
    ]
    chosen_keys = picker.select_multi(
        title="Repos to sync:", choices=choices, default_selected=True
    )
    if chosen_keys is None:
        return None
    chosen_set = set(chosen_keys)
    return {(owner, name) for owner, name in by_repo if f"{owner}/{name}" in chosen_set}


def _parse_repo_arg(*, value: str) -> tuple[str, str] | None:
    candidate = value.strip()
    parsed = git.parse_owner_repo(url=candidate)
    if parsed is not None:
        return parsed
    cleaned = candidate.removesuffix(".git").strip("/")
    parts = cleaned.split("/")
    if len(parts) == 2 and all(parts):
        return parts[0], parts[1]
    return None


def _prompt(*, label: str, default: str) -> str:
    try:
        raw = input(f"{label} [{default}]: ").strip()
    except EOFError:
        return default
    return raw or default


def _prompt_bool(*, label: str, default: bool) -> bool:
    suffix = "Y/n" if default else "y/N"
    try:
        raw = input(f"{label} [{suffix}]: ").strip().lower()
    except EOFError:
        return default
    if not raw:
        return default
    return raw in {"y", "yes", "true", "1"}


def cmd_setup() -> int:
    cfg = config.load()
    print(f"Writing config to {config.config_path()}\n")

    print(
        "Workspace path: each open PR you author becomes a worktree under "
        "<workspace>/<repo>-control/<pr>-<branch>/, alongside <repo>-control/main/.\n"
        "Tip: ~/repos is a fine pick if you want everything in your home."
    )
    base = os.path.expanduser(
        _prompt(
            label="Workspace path",
            default=cfg["base_path"],
        )
    )

    ide_choice = _prompt(
        label=f"Default editor ({', '.join(ide.KNOWN)}, or any binary on PATH; quote for args)",
        default=cfg["ide"],
    )
    binary = shlex.split(ide_choice)[0] if ide_choice else ""
    if binary and shutil.which(binary) is None:
        print(f"  warning: {binary!r} not on PATH — saving anyway; install or fix before `open`")

    skip_raw = _prompt(
        label="Repos to skip (comma-separated owner/repo)",
        default=", ".join(cfg["skip_repos"]),
    )
    skip_repos = [item.strip() for item in skip_raw.split(",") if item.strip()]

    auto_install = _prompt_bool(
        label="Auto-run installers (mise install / uv sync / npm install) in fresh worktrees?",
        default=cfg["auto_install"],
    )
    auto_trust_mise = False
    if auto_install:
        auto_trust_mise = _prompt_bool(
            label="Auto-trust mise.toml in fresh worktrees (skips mise's trust prompt)?",
            default=cfg["auto_trust_mise"],
        )

    layout_choice = (
        _prompt(
            label=(
                "Worktree layout (hierarchical: <repo>/.worktrees/<pr>-<branch>; "
                "flat: <repo>/<pr>-<branch>)"
            ),
            default=cfg["worktree_layout"],
        )
        .strip()
        .lower()
    )
    if layout_choice not in {"hierarchical", "flat"}:
        print(f"  unknown layout {layout_choice!r}; using 'hierarchical'")
        layout_choice = "hierarchical"

    prefix_worktrees = _prompt_bool(
        label=(
            "Prefix worktree folders with the lowercase repo name "
            "(e.g. webapp-main, webapp-142-fix)?"
        ),
        default=cfg["prefix_worktrees"],
    )

    bare_repo = _prompt_bool(
        label="Store .git as a bare repo at <repo>/.git and treat main as a worktree?",
        default=cfg["bare_repo"],
    )

    Path(base).mkdir(parents=True, exist_ok=True)
    written = config.write(
        base_path=base,
        ide=ide_choice,
        skip_repos=skip_repos,
        auto_install=auto_install,
        auto_trust_mise=auto_trust_mise,
        worktree_layout=layout_choice,
        prefix_worktrees=prefix_worktrees,
        bare_repo=bare_repo,
    )
    print(f"\nWrote {written}")
    return 0


def cmd_install_skill(*, uninstall: bool, force: bool) -> int:
    source = _bundled_skill_source()
    target = Path.home() / ".claude" / "skills" / SKILL_NAME

    if uninstall:
        if not target.exists() and not target.is_symlink():
            print(f"{target} does not exist; nothing to remove")
            return 0
        if target.is_symlink():
            target.unlink()
            print(f"unlinked {target}")
            return 0
        if not force:
            print(
                f"refusing to remove {target}: not a symlink. "
                "Inspect manually or re-run with --force.",
                file=sys.stderr,
            )
            return 1
        if target.is_dir():
            _rmtree(target)
        else:
            target.unlink()
        print(f"removed {target}")
        return 0

    if not source.exists():
        print(
            f"bundled skill source not found at {source}; is this an editable install?",
            file=sys.stderr,
        )
        return 1

    target.parent.mkdir(parents=True, exist_ok=True)
    if target.is_symlink():
        if target.resolve() == source.resolve():
            print(f"{target} -> {source} already in place")
            return 0
        target.unlink()
    elif target.exists():
        if not force:
            print(
                f"refusing to overwrite {target}: not a symlink. "
                "Back it up and re-run with --force.",
                file=sys.stderr,
            )
            return 1
        if target.is_dir():
            _rmtree(target)
        else:
            target.unlink()

    target.symlink_to(source, target_is_directory=True)
    print(f"linked {target} -> {source}")
    return 0


def _rmtree(path: Path) -> None:
    import shutil

    shutil.rmtree(path)


def _bundled_skill_source() -> Path:
    return Path(__file__).resolve().parent / "skill"


def _collect_rows() -> list[WorktreeRow]:
    rows: list[WorktreeRow] = []
    cfg = config.load()
    base = config.base_path(cfg=cfg)
    for repo in state.discover_repos(base_path=base):
        default = git.default_branch(repo_path=repo.main_path)
        for worktree in state.existing_worktrees(repo=repo):
            wt_path = worktree.path
            if wt_path.resolve() == repo.main_path.resolve():
                rows.append(
                    WorktreeRow(
                        repo_slug=repo.slug,
                        pr_number=None,
                        branch=default,
                        path=wt_path,
                        status="main",
                    )
                )
                continue
            pr_number = _pr_number_from_dir(name=wt_path.name)
            status = "clean" if git.is_clean(worktree_path=wt_path) else "dirty"
            rows.append(
                WorktreeRow(
                    repo_slug=repo.slug,
                    pr_number=pr_number,
                    branch=worktree.branch,
                    path=wt_path,
                    status=status,
                )
            )
    return rows


def _pr_number_from_dir(*, name: str) -> int | None:
    head, _, _ = name.partition("-")
    if head.isdigit():
        return int(head)
    return None


def _resolve_pr(*, reference: str) -> Path | None:
    rows = _collect_rows()
    if "#" in reference:
        slug, _, num = reference.partition("#")
        target = int(num)
        for row in rows:
            if row.repo_slug == slug and row.pr_number == target:
                return row.path
        return None
    if not reference.isdigit():
        return None
    target = int(reference)
    matches = [row for row in rows if row.pr_number == target]
    if len(matches) == 0:
        return None
    if len(matches) > 1:
        print("ambiguous PR number; matches:", file=sys.stderr)
        for row in matches:
            print(f"  {row.repo_slug}#{row.pr_number}  {row.path}", file=sys.stderr)
        return None
    return matches[0].path


def _print_table(*, rows: list[WorktreeRow]) -> None:
    headers = ("repo", "pr", "branch", "status", "path")
    data = [
        (
            row.repo_slug,
            str(row.pr_number) if row.pr_number is not None else "-",
            row.branch or "-",
            row.status,
            str(row.path),
        )
        for row in rows
    ]
    widths = [len(h) for h in headers]
    for record in data:
        for i, cell in enumerate(record):
            widths[i] = max(widths[i], len(cell))
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    print(fmt.format(*headers))
    print(fmt.format(*["-" * w for w in widths]))
    for record in data:
        print(fmt.format(*record))


def _print_sync_summary(
    *,
    created: list[Path],
    refreshed: list[Path],
    removed: list[Path],
    kept_dirty: list[Path],
    setup_steps: dict[Path, list[str]],
) -> None:
    print()
    print(f"created:  {len(created)}")
    for path in created:
        steps = setup_steps.get(path, [])
        suffix = f" [{', '.join(steps)}]" if steps else ""
        print(f"  + {path}{suffix}")
    print(f"refreshed: {len(refreshed)}")
    for path in refreshed:
        print(f"  ~ {path}")
    print(f"removed:  {len(removed)}")
    for path in removed:
        print(f"  - {path}")
    if kept_dirty:
        print(f"kept dirty: {len(kept_dirty)} (PR closed but worktree has uncommitted work)")
        for path in kept_dirty:
            print(f"  ! {path}")


if __name__ == "__main__":
    sys.exit(main())
