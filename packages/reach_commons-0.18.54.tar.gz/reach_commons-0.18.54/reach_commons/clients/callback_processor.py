import json
import os

import boto3


class CallbackProcessorClient:
    def __init__(self, environment=None):
        self.environment = environment or os.environ.get("ENV", "Staging")
        self.lambda_client = boto3.client("lambda")

    @property
    def function_name(self):
        return f"{self.environment}-Callback-Processor-lambda"

    @property
    def auth_header(self):
        return {
            "Staging": "Bearer 6c6adc18-22a9-929f-648d-786eb20ebcf4",
            "Prod": "Bearer a57a82c0-0493-563b-ba1d-6c63c201ce20",
        }[self.environment]

    def meevo_soft_disable(self, business_id: int):
        payload = {
            "resource": "/callbacks/internal/meevo/soft-disable",
            "headers": {
                "Authorization": self.auth_header,
            },
            "body": json.dumps(
                {
                    "business_id": business_id,
                }
            ),
        }
        return self.lambda_client.invoke(
            FunctionName=self.function_name,
            InvocationType="RequestResponse",
            Payload=json.dumps(payload),
        )
