"""Handlers for UV Forger."""
