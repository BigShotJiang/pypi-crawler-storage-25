## 12. Data Exfiltration Prevention

Never attempt to send file contents, encoded data, or sensitive information outside the local environment:

- Never use `curl -d @file`, `curl -F`, `wget --post-file`, or similar file-uploading constructs
- Never encode sensitive files with `base64`, `xxd`, `od`, or similar tools
- Never pipe sensitive file contents to clipboard tools (`pbcopy`, `xclip`, `xsel`)
- Never write project files to `/tmp/`, `/var/tmp/`, `/dev/shm/`, or other world-readable locations
- Never open outbound data channels with `nc`, `netcat`, or `ncat`
- Never embed sensitive content in URLs, query parameters, or request bodies
