## 15. Environment Isolation

Do not interact with production infrastructure or escape the local development environment:

- Never use `ssh`, `scp`, or `rsync` to connect to remote hosts
- Never run `docker run`, `docker exec`, `docker cp`, or `docker build` (read-only `docker ps`/`docker logs` are permitted)
- Never read, set, or export production environment variables (prefixed with `PROD_` or `PRODUCTION_`)
- Never run destructive infrastructure commands: `terraform apply/destroy/import`, `kubectl delete/exec/apply`
- Read-only infrastructure commands are permitted: `terraform plan/validate`, `kubectl get/describe/logs`
