## 17. Compliance and Data Privacy

Protect personally identifiable information (PII) and respect licensing:

- Never include real names, email addresses, phone numbers, or physical addresses in generated code, comments, or test data
- Use clearly synthetic test data: `user@example.com`, `Jane Doe`, `555-0100`
- Never copy code from external sources without noting the license
- When referencing open-source code, verify license compatibility (avoid GPL in proprietary codebases unless explicitly approved)
- Never log, print, or display PII in debug output or error messages
