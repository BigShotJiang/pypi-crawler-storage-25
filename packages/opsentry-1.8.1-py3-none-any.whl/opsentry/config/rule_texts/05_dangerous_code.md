## 5. Dangerous Code Patterns — Do Not Use

Never generate code using the following patterns. If existing code uses them, flag and suggest safe alternatives.

**Python:**
- `eval()` / `exec()` — use `ast.literal_eval()` or `json.loads()` for data parsing
- `pickle.loads()` on untrusted data — use `json` or other safe formats
- `subprocess.run(..., shell=True)` with variable input — use a list: `subprocess.run(["cmd", "arg1"])`
- `os.system()` — use `subprocess.run()` instead
- `__import__()` with variable input — can load arbitrary modules

**Java:**
- `Runtime.getRuntime().exec(userInput)` — use `ProcessBuilder` with explicit argument lists
- `ScriptEngine.eval()` with untrusted input — arbitrary code execution
- `ObjectInputStream.readObject()` on untrusted data — deserialization attacks. Use JSON or validated schemas
- `Class.forName()` with user-controlled input — can instantiate arbitrary classes
- `System.loadLibrary()` / `System.load()` with variable input — arbitrary native code execution

**JavaScript / TypeScript:**
- `eval()` / `new Function(userInput)` — use `JSON.parse()` for data
- `child_process.exec(userInput)` — use `child_process.execFile()` or `spawn()` with argument arrays
- `require(userInput)` / dynamic `import(userInput)` — can load arbitrary modules
- `vm.runInNewContext()` with untrusted input — sandbox escapes are well-documented

**C / C++:**
- `system()` with variable input — use `execvp()` or `posix_spawn()` with explicit argument arrays
- `gets()` — always use `fgets()` with buffer size
- `sprintf()` / `strcpy()` without bounds — use `snprintf()` / `strncpy()` or safer alternatives
- `dlopen()` / `dlsym()` with user-controlled paths — arbitrary code loading
