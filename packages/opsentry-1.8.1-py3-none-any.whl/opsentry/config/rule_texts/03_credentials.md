## 3. Credentials and Connection Strings — NEVER Hardcode

You must never write credentials, API keys, tokens, passwords, or connection strings directly into code. This applies to all contexts including tests, scripts, configuration files, and documentation.

**Always do this:**
- Reference environment variables: `os.environ.get("DB_PASSWORD")`
- Use secrets manager references
- Use placeholder values in examples: `"your-api-key-here"` or `"<DB_TOKEN>"`
- Use `.env.example` files with empty values to document required variables

**Never do this:**
- `password = "actual_password_123"`
- `api_key = "sk-abc123..."`
- `connection_string = "postgresql://user:pass@host/db"`
- Embed tokens in URLs, headers, or query parameters as literal strings

If you see hardcoded credentials in existing code, flag it to the developer immediately and suggest refactoring to use environment variables or the secrets manager.
