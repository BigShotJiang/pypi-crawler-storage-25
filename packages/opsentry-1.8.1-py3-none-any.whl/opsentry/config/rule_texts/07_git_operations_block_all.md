## 7. Git Operations — Do Not Execute

You must not execute any git commands. The developer manages version control themselves.

**Never run:**
- `git commit`, `git push`, `git pull`, `git merge`
- `git reset` (especially `--hard`)
- `git push --force` or `git push --force-with-lease`
- `git checkout` to switch branches
- `git stash`, `git rebase`, `git cherry-pick`
- `git tag`, `git branch -d`, `git branch -D`

If a developer asks you to help with git workflows, provide the commands as text for them to review and run manually. Do not execute them.
