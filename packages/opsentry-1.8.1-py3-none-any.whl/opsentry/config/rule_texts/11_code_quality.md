## 11. Code Quality Standards

All code you generate must follow these standards regardless of language:

- Follow the existing code style of the project (check surrounding files for conventions)
- Never suppress linter or compiler warnings without a documented reason
- Never comment out code as a way to "disable" functionality — remove it or use feature flags
- Add `TODO` comments when something needs follow-up, including the reason
- Always catch specific exceptions/errors, never use bare catch-all handlers:
  - Python: no bare `except:` — catch specific exception types
  - Java: no bare `catch (Exception e)` — catch specific exception types
  - JavaScript/TypeScript: no empty `catch {}` — handle or rethrow with context
  - C/C++: always check return values from system calls and library functions
