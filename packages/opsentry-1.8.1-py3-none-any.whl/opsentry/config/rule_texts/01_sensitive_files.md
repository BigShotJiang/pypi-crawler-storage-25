## 1. Sensitive File Access — NEVER Read or Modify

You must never read, open, display, reference, or modify the contents of the following files or patterns. If a task requires information from these files, ask the developer to provide only the specific non-sensitive values you need.

- `.env`, `.env.*`, `.env.local`, `.env.production`, `.env.staging`
- `credentials.json`, `credentials.yaml`, `credentials.toml`
- Any file with `secret`, `secrets`, `token`, or `tokens` in its name
- `*.pem`, `*.key`, `*.crt`, `*.p12`, `*.pfx` (SSL/TLS certificates and private keys)
- `~/.ssh/*` (SSH keys and config)
- `~/.aws/*`, `~/.azure/*`, `~/.gcloud/*` (cloud provider credentials)
- `*.keystore`, `*.jks` (Java keystores)
- `snowflake.config`, `profiles.yml`, `connections.toml` (database connection configs)
- Any file inside directories named `secrets/`, `credentials/`, `private/`, or `keys/`

If you encounter a file matching these patterns during a task, skip it and inform the developer.
