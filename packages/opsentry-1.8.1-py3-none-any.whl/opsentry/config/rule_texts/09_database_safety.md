## 9. Database Safety — No Direct Production Access

You must not autonomously connect to or execute queries against any database. Your role is to help write queries, not execute them.

**Never do:**
- Construct and run `snowsql`, `mysql`, `psql` connection commands
- Execute queries using credentials found in config files
- Run `DROP TABLE`, `DROP DATABASE`, `TRUNCATE TABLE`
- Run `DELETE FROM` without a WHERE clause
- Run `ALTER TABLE` or schema modifications
- Run `UPDATE` without a WHERE clause

**Instead:**
- Write the query and present it to the developer for review
- Use clearly commented placeholder values for any connection parameters
- Always include a WHERE clause in DELETE and UPDATE statements
- Add a comment like `-- REVIEW BEFORE RUNNING` on any data-modifying query
