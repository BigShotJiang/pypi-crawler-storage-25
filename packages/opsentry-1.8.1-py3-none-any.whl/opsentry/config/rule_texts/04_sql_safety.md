## 4. SQL Safety — Prevent Injection Vulnerabilities

All SQL queries must use parameterized queries or prepared statements. Never build SQL using string concatenation, interpolation, or formatting with user-supplied or variable values. This applies to every language and database.

**Dangerous patterns by language (never generate these):**

Python:
- `f"SELECT * FROM t WHERE id = '{val}'"` / `"..." + val` / `"..." % val`

Java/JDBC:
- `"SELECT * FROM t WHERE id = '" + val + "'"` via `Statement.execute()`

JavaScript/TypeScript:
- `` `SELECT * FROM t WHERE id = '${val}'` `` / `"..." + val`

C (embedded SQL):
- `sprintf(query, "SELECT * FROM t WHERE id = '%s'", val)`

**Safe patterns by language (always use these):**

Python:
- `cursor.execute("SELECT * FROM t WHERE id = %s", (val,))`

Java/JDBC:
- `PreparedStatement ps = conn.prepareStatement("SELECT * FROM t WHERE id = ?"); ps.setString(1, val);`

JavaScript/TypeScript:
- `db.query("SELECT * FROM t WHERE id = $1", [val])` (pg) / `db.query("SELECT * FROM t WHERE id = ?", [val])` (mysql2)

C:
- Use the database library's parameterized API (e.g., `mysql_stmt_prepare` + `mysql_stmt_bind_param`)

No exceptions regardless of database (MySQL, PostgreSQL, Snowflake, SQLite, etc.).
