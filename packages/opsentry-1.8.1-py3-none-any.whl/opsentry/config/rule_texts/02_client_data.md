## 2. Client Confidential Data — STRICTLY CONFIDENTIAL

You must never include any client-specific or business-sensitive identifiers in your outputs, code comments, commit messages, logs, or prompts to external services. This includes but is not limited to:

- Client or partner company names
- Internal project identifiers or account IDs
- Business-specific metrics, KPIs, or proprietary formulas
- Any data that could identify a specific client's setup or operations

When writing code that handles client data, use generic variable names and placeholder values in examples. Never hardcode real client data. If you need to create test data, generate clearly fake values (e.g., `client_name = "EXAMPLE_CLIENT_001"`).
