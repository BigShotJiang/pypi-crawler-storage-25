## 13. Package Installation Safety

When installing packages, only use official registries:

- Never install from arbitrary git URLs, tarballs, or direct download links
- Never use custom `--index-url`, `--registry`, or `--source` flags pointing to non-standard registries
- Never pipe `curl`/`wget` output to package managers
- For all languages (pip, npm, gem, go, maven, cargo), only install named packages from their default public registries
- If a project requires a private registry, the developer will configure it in project-level config files
