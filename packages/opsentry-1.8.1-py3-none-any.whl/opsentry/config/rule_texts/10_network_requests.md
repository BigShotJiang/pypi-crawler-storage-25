## 10. Network Requests — Restrict Outbound Access

Do not make network requests to unknown or external domains. Specifically:

- Never run `curl`, `wget`, or `fetch` to external URLs unless the developer explicitly provides and approves the URL
- Never download and execute scripts from the internet
- Never send data to external APIs, webhooks, or logging services
- Never install packages from unknown or unofficial registries

If a task requires calling an external API, write the code and let the developer review it before execution.
