## 8. Destructive Commands — Never Execute

The following commands must never be run under any circumstances:

- `rm -rf` or any recursive forced deletion
- `rm -r` on directories outside the immediate working scope
- `sudo` anything — you should never need root access
- `chmod 777` — never set world-readable/writable/executable permissions
- `mkfs`, `dd`, `fdisk` — disk-level operations
- `kill -9` on system processes
- `systemctl stop`, `service stop` on production services
- Any command that downloads and pipes to shell: `curl ... | sh`, `wget ... | bash`
