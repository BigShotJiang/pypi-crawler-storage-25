## 16. Resource Limits

Operate efficiently and avoid unbounded operations:

- Never generate individual files exceeding {{ max_file_lines }} lines -- propose splitting into modules instead
- Avoid infinite loops or recursive operations without clear termination conditions
- If a task requires processing a large number of files, process them in bounded batches
- Do not make repeated failing tool calls -- after 2 failures, stop and explain the issue
