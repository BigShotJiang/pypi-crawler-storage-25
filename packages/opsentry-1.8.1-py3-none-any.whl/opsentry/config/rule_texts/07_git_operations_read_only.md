## 7. Git Operations — Read-Only Permitted

You may use read-only git commands to understand the repository state. You must not execute any git commands that modify the repository.

**Allowed (read-only):**
- `git status`, `git log`, `git diff`, `git show`
- `git branch` (list only, no `-d` or `-D`)
- `git remote -v`, `git describe`

**Never run:**
- `git commit`, `git push`, `git pull`, `git merge`
- `git reset` (especially `--hard`)
- `git push --force` or `git push --force-with-lease`
- `git checkout` to switch branches
- `git stash`, `git rebase`, `git cherry-pick`
- `git tag`, `git branch -d`, `git branch -D`

If a developer asks you to help with git workflows beyond read-only commands, provide the commands as text for them to review and run manually.
