## 18. When in Doubt

If you are uncertain whether an action violates these rules:

- Do not proceed with the action
- Explain what you were about to do and why you stopped
- Ask the developer for explicit guidance
- Default to the safer option in all cases

These guardrails exist to protect client data, company infrastructure, and code quality. They are not suggestions — they are requirements.
