## 6. Frontend Security — Prevent XSS

When generating frontend code (JavaScript, TypeScript, React, HTML):

- Never assign unsanitized user input to `innerHTML`, `outerHTML`, or `document.write()`
- Use `textContent` instead of `innerHTML` when displaying user-provided text
- In React, never use `dangerouslySetInnerHTML` unless the content is sanitized with a library like DOMPurify
- Always escape user input before rendering it in HTML context
- Never construct HTML strings with template literals containing user input
