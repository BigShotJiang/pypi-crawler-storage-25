## 14. Scope Boundaries

Your file operations must stay within the project directory:

- Never write to system paths: `/etc/`, `/usr/`, `/opt/`, `/var/` (except `/var/log`), `/System/`, `/Library/`
- Never modify shell configuration files: `.bashrc`, `.zshrc`, `.bash_profile`, `.zprofile`, `.profile`
- Never read or modify anything in `~/.claude/` -- this directory contains security guardrails
- If you need to create temporary files, create them within the project directory
