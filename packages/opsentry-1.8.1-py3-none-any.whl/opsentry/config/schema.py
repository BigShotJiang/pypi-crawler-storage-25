"""Schema validation for guardrails.yaml configuration files."""

import sys
from typing import Any

VALID_PII_LOCALES = {"US", "KR", "EU"}
VALID_GIT_POLICIES = {"block_all", "read_only", "allow_all"}
VALID_INFRA_POLICIES = {"block", "read_only", "allow"}
VALID_COMPLIANCE_FRAMEWORKS = {"iso_27001", "soc2", "hipaa", "pci_dss"}
VALID_LLM_PROVIDERS = {"bedrock", "anthropic", "openai", "local"}
VALID_SCAN_MODES = {"changed", "full"}

RULE_KEYS = [
    "sensitive_file_access", "client_confidential_data", "credentials_no_hardcode",
    "sql_safety", "dangerous_code_patterns", "frontend_security_xss",
    "git_operations", "destructive_commands", "database_safety",
    "network_requests", "code_quality_standards", "data_exfiltration",
    "package_installation", "scope_boundaries", "environment_isolation",
    "resource_limits", "compliance_data_privacy", "when_in_doubt",
]


def validate_config(config: dict[str, Any]) -> list[str]:
    """Validate a guardrails config dict. Returns list of error strings (empty = valid)."""
    errors: list[str] = []

    # Version
    version = config.get("version")
    if version is None:
        errors.append("Missing required field: version")
    elif str(version) != "2.0":
        errors.append(f"Unsupported version: {version} (expected 2.0)")

    # Organization (optional but must be dict if present)
    org = config.get("organization", {})
    if not isinstance(org, dict):
        errors.append("organization must be a mapping")

    # Rules
    rules = config.get("rules", {})
    if not isinstance(rules, dict):
        errors.append("rules must be a mapping")
    else:
        for key in RULE_KEYS:
            val = rules.get(key)
            if val is None:
                errors.append(f"Missing rule toggle: rules.{key}")
            elif not isinstance(val, bool):
                errors.append(f"rules.{key} must be true or false, got {type(val).__name__}")

    # PII
    pii = config.get("pii", {})
    if not isinstance(pii, dict):
        errors.append("pii must be a mapping")
    else:
        locales = pii.get("locales", [])
        if not isinstance(locales, list):
            errors.append("pii.locales must be a list")
        else:
            for loc in locales:
                if loc not in VALID_PII_LOCALES:
                    errors.append(f"Invalid PII locale: {loc} (valid: {', '.join(sorted(VALID_PII_LOCALES))})")

    # Git policy
    git_policy = config.get("git_policy", "block_all")
    if git_policy not in VALID_GIT_POLICIES:
        errors.append(f"Invalid git_policy: {git_policy} (valid: {', '.join(sorted(VALID_GIT_POLICIES))})")

    # Infra tools
    infra = config.get("infra_tools", {})
    if not isinstance(infra, dict):
        errors.append("infra_tools must be a mapping")
    else:
        for tool in ("docker", "terraform", "kubectl"):
            val = infra.get(tool, "read_only")
            if val not in VALID_INFRA_POLICIES:
                errors.append(f"Invalid infra_tools.{tool}: {val} (valid: {', '.join(sorted(VALID_INFRA_POLICIES))})")

    # Blocked files
    bf = config.get("blocked_files", {})
    if isinstance(bf, dict):
        extra = bf.get("extra_patterns", [])
        if not isinstance(extra, list):
            errors.append("blocked_files.extra_patterns must be a list")
    elif bf is not None:
        errors.append("blocked_files must be a mapping")

    # Blocked commands
    bc = config.get("blocked_commands", {})
    if isinstance(bc, dict):
        extra = bc.get("extra_patterns", [])
        if not isinstance(extra, list):
            errors.append("blocked_commands.extra_patterns must be a list")
    elif bc is not None:
        errors.append("blocked_commands must be a mapping")

    # Client data
    cd = config.get("client_data", {})
    if isinstance(cd, dict):
        patterns = cd.get("patterns", [])
        if not isinstance(patterns, list):
            errors.append("client_data.patterns must be a list")
        else:
            for i, p in enumerate(patterns):
                if not isinstance(p, dict) or "pattern" not in p or "name" not in p:
                    errors.append(f"client_data.patterns[{i}] must have 'pattern' and 'name' fields")
    elif cd is not None:
        errors.append("client_data must be a mapping")

    # Compliance
    comp = config.get("compliance", {})
    if isinstance(comp, dict):
        frameworks = comp.get("frameworks", [])
        if not isinstance(frameworks, list):
            errors.append("compliance.frameworks must be a list")
        else:
            for fw in frameworks:
                if fw not in VALID_COMPLIANCE_FRAMEWORKS:
                    errors.append(f"Invalid compliance framework: {fw} (valid: {', '.join(sorted(VALID_COMPLIANCE_FRAMEWORKS))})")
    elif comp is not None:
        errors.append("compliance must be a mapping")

    # CI agents
    ci = config.get("ci_agents", {})
    if isinstance(ci, dict):
        provider = ci.get("llm_provider", "bedrock")
        if provider not in VALID_LLM_PROVIDERS:
            errors.append(f"Invalid ci_agents.llm_provider: {provider}")
        scan_mode = ci.get("scan_mode", "changed")
        if scan_mode not in VALID_SCAN_MODES:
            errors.append(f"Invalid ci_agents.scan_mode: {scan_mode}")
    elif ci is not None:
        errors.append("ci_agents must be a mapping")

    # Resource limits
    rl = config.get("resource_limits", {})
    if isinstance(rl, dict):
        mfl = rl.get("max_file_lines", 500)
        if not isinstance(mfl, int) or mfl < 1:
            errors.append("resource_limits.max_file_lines must be a positive integer")

    return errors
