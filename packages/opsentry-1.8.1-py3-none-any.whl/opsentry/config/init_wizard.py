#!/usr/bin/env python3
"""Interactive setup wizard that generates guardrails.yaml from user choices."""

import argparse
import shutil
import sys
from pathlib import Path

CONFIG_DIR = Path(__file__).parent
TEMPLATES_DIR = CONFIG_DIR / "templates"

TEMPLATES = {
    "1": ("generic", "Generic (recommended starting point)"),
    "2": ("fintech", "Fintech / Banking"),
    "3": ("healthcare", "Healthcare"),
    "4": ("manufacturing", "Manufacturing / IoT"),
}

PII_LOCALES = {"US": "US (SSN, credit cards)", "KR": "KR (Korean RRN)", "EU": "EU (IBAN, national IDs)"}
GIT_POLICIES = {"1": "block_all", "2": "read_only", "3": "allow_all"}
INFRA_POLICIES = {"1": "block", "2": "read_only", "3": "allow"}
COMPLIANCE_OPTS = {"1": "iso_27001", "2": "soc2", "3": "hipaa", "4": "pci_dss"}
LLM_PROVIDERS = {"1": "bedrock", "2": "anthropic", "3": "openai", "4": "local"}


def ask(prompt: str, choices: dict[str, str] | None = None, default: str = "") -> str:
    """Ask user a question with optional numbered choices."""
    if choices:
        print()
        for key, label in choices.items():
            print(f"  [{key}] {label}")
    while True:
        suffix = f" [{default}]" if default else ""
        answer = input(f"\n{prompt}{suffix}: ").strip()
        if not answer and default:
            return default
        if choices and answer in choices:
            return answer
        if not choices and answer:
            return answer
        if choices:
            print(f"  Please enter one of: {', '.join(choices.keys())}")


def ask_multi(prompt: str, choices: dict[str, str]) -> list[str]:
    """Ask user to select multiple options (comma-separated)."""
    print()
    for key, label in choices.items():
        print(f"  [{key}] {label}")
    print(f"  [0] None")
    while True:
        answer = input(f"\n{prompt} (comma-separated, or 0 for none): ").strip()
        if answer == "0":
            return []
        parts = [p.strip() for p in answer.split(",")]
        if all(p in choices for p in parts):
            return [choices[p] for p in parts]
        print(f"  Please enter valid choices from: {', '.join(choices.keys())}, or 0")


def run_interactive() -> str:
    """Run the interactive wizard. Returns path to the generated guardrails.yaml."""
    print("=" * 50)
    print("  OpSentry Setup Wizard")
    print("=" * 50)

    # Step 1: Template
    choice = ask("Select an industry template:", TEMPLATES, default="1")
    template_name = TEMPLATES[choice][0]

    # Copy template
    src = TEMPLATES_DIR / f"{template_name}.yaml"
    dest = Path("guardrails.yaml")
    shutil.copy2(src, dest)

    # Load as text for in-place edits
    content = dest.read_text()

    # Step 2: Organization
    org_name = ask("Organization name (optional, press Enter to skip):", default="")
    if org_name:
        content = content.replace('  name: ""', f'  name: "{org_name}"')

    # Step 3: PII locales
    print("\nWhich PII locales do you need?")
    print("  US (SSN, credit cards) is always included.")
    extra_locales = []
    kr = input("  Include KR (Korean RRN)? [y/N]: ").strip().lower()
    if kr in ("y", "yes"):
        extra_locales.append("KR")
    eu = input("  Include EU (IBAN)? [y/N]: ").strip().lower()
    if eu in ("y", "yes"):
        extra_locales.append("EU")

    locales_str = ", ".join(f'"{l}"' for l in ["US"] + extra_locales)
    # Replace the locales line
    import re
    content = re.sub(r'locales:\s*\[.*?\]', f'locales: [{locales_str}]', content)

    # Step 4: Git policy
    print("\nGit policy for AI agents:")
    git_choice = ask("Select git policy:", {
        "1": "Block all git commands (most secure, recommended)",
        "2": "Allow read-only (status, log, diff)",
        "3": "Allow all (not recommended)",
    }, default="1")
    git_policy = GIT_POLICIES[git_choice]
    content = re.sub(r'git_policy:\s*".*?"', f'git_policy: "{git_policy}"', content)

    # Step 5: Infra tools
    print("\nInfrastructure tools policy:")
    for tool in ("docker", "terraform", "kubectl"):
        tool_choice = ask(f"  {tool}:", {
            "1": "Block all",
            "2": "Read-only (recommended)",
            "3": "Allow all",
        }, default="2")
        policy = INFRA_POLICIES[tool_choice]
        content = re.sub(rf'{tool}:\s*".*?"', f'{tool}: "{policy}"', content)

    # Step 6: Compliance
    frameworks = ask_multi("Compliance frameworks:", COMPLIANCE_OPTS)
    if frameworks:
        fw_str = ", ".join(f'"{f}"' for f in frameworks)
        content = re.sub(r'frameworks:\s*\[.*?\]', f'frameworks: [{fw_str}]', content)

    # Step 7: LLM provider
    llm_choice = ask("LLM provider for CI agents:", {
        "1": "AWS Bedrock",
        "2": "Anthropic API",
        "3": "OpenAI-compatible",
        "4": "Local (Ollama/LM Studio)",
    }, default="1")
    provider = LLM_PROVIDERS[llm_choice]
    content = re.sub(r'llm_provider:\s*".*?"', f'llm_provider: "{provider}"', content)

    # Write
    dest.write_text(content)
    print(f"\n{'=' * 50}")
    print(f"  Created {dest}")
    print(f"  Run: python3 config/generate.py guardrails.yaml")
    print(f"{'=' * 50}")
    return str(dest)


def run_non_interactive(args: argparse.Namespace) -> str:
    """Generate guardrails.yaml from CLI flags."""
    template_name = args.template or "generic"
    src = TEMPLATES_DIR / f"{template_name}.yaml"
    if not src.exists():
        print(f"ERROR: Template not found: {src}", file=sys.stderr)
        sys.exit(1)

    dest = Path(args.output or "guardrails.yaml")
    shutil.copy2(src, dest)

    content = dest.read_text()
    import re

    if args.org:
        content = content.replace('  name: ""', f'  name: "{args.org}"')

    if args.pii:
        locales_str = ", ".join(f'"{l}"' for l in args.pii.split(","))
        content = re.sub(r'locales:\s*\[.*?\]', f'locales: [{locales_str}]', content)

    if args.git_policy:
        content = re.sub(r'git_policy:\s*".*?"', f'git_policy: "{args.git_policy}"', content)

    if args.compliance:
        fw_str = ", ".join(f'"{f}"' for f in args.compliance.split(","))
        content = re.sub(r'frameworks:\s*\[.*?\]', f'frameworks: [{fw_str}]', content)

    if args.llm:
        content = re.sub(r'llm_provider:\s*".*?"', f'llm_provider: "{args.llm}"', content)

    dest.write_text(content)
    print(f"Created {dest}")
    return str(dest)


def main():
    parser = argparse.ArgumentParser(description="OpSentry Setup Wizard")
    parser.add_argument("--non-interactive", action="store_true", help="Run without prompts")
    parser.add_argument("--template", help="Template: generic, fintech, healthcare, manufacturing")
    parser.add_argument("--org", help="Organization name")
    parser.add_argument("--pii", help="PII locales, comma-separated: US,KR,EU")
    parser.add_argument("--git-policy", help="Git policy: block_all, read_only, allow_all")
    parser.add_argument("--compliance", help="Compliance frameworks, comma-separated: iso_27001,soc2,hipaa,pci_dss")
    parser.add_argument("--llm", help="LLM provider: bedrock, anthropic, openai, local")
    parser.add_argument("--output", "-o", help="Output path (default: guardrails.yaml)")
    args = parser.parse_args()

    if args.non_interactive:
        run_non_interactive(args)
    else:
        run_interactive()


if __name__ == "__main__":
    main()
