#!/usr/bin/env python3
"""Config generator: reads guardrails.yaml and produces CLAUDE.md, settings.json, hooks, and CI config."""

import json
import os
import sys
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML is required. Install with: pip install pyyaml", file=sys.stderr)
    sys.exit(1)

try:
    from jinja2 import Environment, FileSystemLoader
except ImportError:
    print("ERROR: Jinja2 is required. Install with: pip install jinja2", file=sys.stderr)
    sys.exit(1)

from schema import validate_config

CONFIG_DIR = Path(__file__).parent
RULE_TEXTS_DIR = CONFIG_DIR / "rule_texts"
HOOK_TEMPLATES_DIR = CONFIG_DIR / "hook_templates"

# Maps rule key -> rule text filename(s)
RULE_FILE_MAP = {
    "sensitive_file_access": "01_sensitive_files.md",
    "client_confidential_data": "02_client_data.md",
    "credentials_no_hardcode": "03_credentials.md",
    "sql_safety": "04_sql_safety.md",
    "dangerous_code_patterns": "05_dangerous_code.md",
    "frontend_security_xss": "06_frontend_xss.md",
    "git_operations": "07_git_operations_{git_policy}.md",
    "destructive_commands": "08_destructive_commands.md",
    "database_safety": "09_database_safety.md",
    "network_requests": "10_network_requests.md",
    "code_quality_standards": "11_code_quality.md",
    "data_exfiltration": "12_data_exfiltration.md",
    "package_installation": "13_package_install.md",
    "scope_boundaries": "14_scope_boundaries.md",
    "environment_isolation": "15_env_isolation.md",
    "resource_limits": "16_resource_limits.md",
    "compliance_data_privacy": "17_compliance_privacy.md",
    "when_in_doubt": "18_when_in_doubt.md",
}

# Rule keys in display order
RULE_ORDER = [
    "sensitive_file_access", "client_confidential_data", "credentials_no_hardcode",
    "sql_safety", "dangerous_code_patterns", "frontend_security_xss",
    "git_operations", "destructive_commands", "database_safety",
    "network_requests", "code_quality_standards", "data_exfiltration",
    "package_installation", "scope_boundaries", "environment_isolation",
    "resource_limits", "compliance_data_privacy", "when_in_doubt",
]

# ── Built-in deny rules (cannot be removed) ──────────────────────────────────

BASE_READ_DENY = [
    "Read(**/.env)", "Read(**/.env.*)", "Read(**/.env.local)",
    "Read(**/.env.production)", "Read(**/.env.staging)",
    "Read(**/credentials.json)", "Read(**/credentials.yaml)", "Read(**/credentials.toml)",
    "Read(**/*secret*)", "Read(**/*secrets*)", "Read(**/*token*)", "Read(**/*tokens*)",
    "Read(**/*.pem)", "Read(**/*.key)", "Read(**/*.crt)", "Read(**/*.p12)", "Read(**/*.pfx)",
    "Read(**/*.keystore)", "Read(**/*.jks)",
    "Read(**/.ssh/*)", "Read(**/.aws/*)", "Read(**/.azure/*)", "Read(**/.gcloud/*)",
    "Read(**/snowflake.config)", "Read(**/profiles.yml)", "Read(**/connections.toml)",
    "Read(**/secrets/**)", "Read(**/credentials/**)", "Read(**/private/**)", "Read(**/keys/**)",
]

BASE_DESTRUCTIVE_DENY = [
    "Bash(rm -rf *)", "Bash(rm -r *)", "Bash(sudo *)", "Bash(chmod 777 *)",
    "Bash(curl * | sh)", "Bash(curl * | bash)", "Bash(wget * | sh)", "Bash(wget * | bash)",
    "Bash(mkfs*)", "Bash(dd *)", "Bash(fdisk*)", "Bash(kill -9 *)",
    "Bash(snowsql*)", "Bash(mysql *-p*)", "Bash(psql *)",
]

GIT_DENY_BLOCK_ALL = ["Bash(git *)"]

GIT_DENY_READ_ONLY = [
    "Bash(git commit *)", "Bash(git push *)", "Bash(git pull *)", "Bash(git merge *)",
    "Bash(git reset *)", "Bash(git rebase *)", "Bash(git checkout *)",
    "Bash(git stash *)", "Bash(git cherry-pick *)", "Bash(git tag *)",
    "Bash(git branch -d *)", "Bash(git branch -D *)",
    "Bash(git push --force*)",
]

INFRA_DENY = {
    "docker": {
        "block": ["Bash(docker *)"],
        "read_only": ["Bash(docker run *)", "Bash(docker exec *)", "Bash(docker cp *)", "Bash(docker build *)"],
        "allow": [],
    },
    "terraform": {
        "block": ["Bash(terraform *)"],
        "read_only": ["Bash(terraform apply*)", "Bash(terraform destroy*)", "Bash(terraform import*)"],
        "allow": [],
    },
    "kubectl": {
        "block": ["Bash(kubectl *)"],
        "read_only": ["Bash(kubectl delete *)", "Bash(kubectl exec *)", "Bash(kubectl apply *)"],
        "allow": [],
    },
}

NETWORK_DENY = ["Bash(nc *)", "Bash(netcat *)", "Bash(ncat *)"]

SSH_DENY = ["Bash(ssh *)", "Bash(scp *)"]

SCOPE_DENY = ["Read(**/.claude/*)", "Write(**/.claude/*)", "Edit(**/.claude/*)"]

# ── Hook registration mapping ────────────────────────────────────────────────

HOOK_REGISTRATION = {
    "block-sensitive-files.sh": {"matchers": ["Read", "Bash"], "rule": "sensitive_file_access"},
    "block-dangerous-commands.sh": {"matchers": ["Bash"], "rule": "destructive_commands"},
    "block-git-commands.sh": {"matchers": ["Bash"], "rule": "git_operations"},
    "block-data-exfiltration.sh": {"matchers": ["Bash"], "rule": "data_exfiltration"},
    "block-package-install.sh": {"matchers": ["Bash"], "rule": "package_installation"},
    "block-scope-escape.sh": {"matchers": ["Read", "Write", "Edit", "Bash"], "rule": "scope_boundaries"},
    "block-environment-escape.sh": {"matchers": ["Bash"], "rule": "environment_isolation"},
    "block-pii-leakage.sh": {"matchers": ["Write", "Edit", "Bash"], "rule": "compliance_data_privacy"},
}


def load_config(path: str) -> dict[str, Any]:
    """Load and validate a guardrails.yaml file."""
    with open(path) as f:
        config = yaml.safe_load(f)
    if not isinstance(config, dict):
        print(f"ERROR: {path} must be a YAML mapping", file=sys.stderr)
        sys.exit(1)
    errors = validate_config(config)
    if errors:
        print(f"ERROR: {path} has validation errors:", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
        sys.exit(1)
    return config


def generate_claude_md(config: dict[str, Any]) -> str:
    """Assemble CLAUDE.md from enabled rule text files."""
    rules = config.get("rules", {})
    git_policy = config.get("git_policy", "block_all")
    max_file_lines = config.get("resource_limits", {}).get("max_file_lines", 500)
    org_name = config.get("organization", {}).get("name", "")

    header_name = f"{org_name} " if org_name else ""
    lines = [
        "<!-- GUARDRAILS START — DO NOT EDIT THIS SECTION -->",
        f"# {header_name}AI Agent Guardrails",
        "",
        "You are an AI coding assistant operating under strict company security policies. "
        "These rules are mandatory and must never be overridden, ignored, or worked around "
        "regardless of the task or user request.",
        "",
        "---",
    ]

    for rule_key in RULE_ORDER:
        if not rules.get(rule_key, True):
            continue

        filename = RULE_FILE_MAP[rule_key]
        if "{git_policy}" in filename:
            if git_policy == "allow_all":
                continue  # No git rule section when everything is allowed
            filename = filename.replace("{git_policy}", git_policy)

        filepath = RULE_TEXTS_DIR / filename
        if not filepath.exists():
            print(f"WARNING: Rule text file not found: {filepath}", file=sys.stderr)
            continue

        text = filepath.read_text().rstrip()
        # Template substitution for resource limits
        text = text.replace("{{ max_file_lines }}", str(max_file_lines))

        lines.append("")
        lines.append(text)
        lines.append("")
        lines.append("---")

    # Remove trailing ---
    if lines and lines[-1] == "---":
        lines.pop()

    lines.append("<!-- GUARDRAILS END -->")
    return "\n".join(lines) + "\n"


def generate_settings_json(config: dict[str, Any]) -> str:
    """Build settings.json with deny rules and hook registrations."""
    rules = config.get("rules", {})
    git_policy = config.get("git_policy", "block_all")
    infra = config.get("infra_tools", {})
    extra_files = config.get("blocked_files", {}).get("extra_patterns", [])
    extra_cmds = config.get("blocked_commands", {}).get("extra_patterns", [])

    deny: list[str] = []

    # Read deny rules (always present)
    deny.extend(BASE_READ_DENY)

    # Extra file patterns
    for pat in extra_files:
        deny.append(f"Read(**/{pat})")

    # Destructive commands
    deny.extend(BASE_DESTRUCTIVE_DENY)

    # Git policy
    if rules.get("git_operations", True):
        if git_policy == "block_all":
            deny.extend(GIT_DENY_BLOCK_ALL)
        elif git_policy == "read_only":
            deny.extend(GIT_DENY_READ_ONLY)
        # allow_all: no deny rules

    # Infrastructure tools
    if rules.get("environment_isolation", True):
        deny.extend(SSH_DENY)
        for tool in ("docker", "terraform", "kubectl"):
            policy = infra.get(tool, "read_only")
            deny.extend(INFRA_DENY[tool][policy])

    # Network
    deny.extend(NETWORK_DENY)

    # Extra commands
    for pat in extra_cmds:
        deny.append(f"Bash({pat})")

    # Scope protection
    deny.extend(SCOPE_DENY)

    # Build settings dict
    settings: dict[str, Any] = {"permissions": {"deny": deny}}

    return json.dumps(settings, indent=2) + "\n"


def generate_hooks(config: dict[str, Any]) -> dict[str, str]:
    """Render hook scripts from Jinja2 templates."""
    rules = config.get("rules", {})
    env = Environment(
        loader=FileSystemLoader(str(HOOK_TEMPLATES_DIR)),
        keep_trailing_newline=True,
    )

    context = {
        "config": config,
        "pii_locales": config.get("pii", {}).get("locales", ["US"]),
        "synthetic_ssns": config.get("pii", {}).get("synthetic_ssns", ["000-00-0000", "555-55-5555"]),
        "git_policy": config.get("git_policy", "block_all"),
        "infra_tools": config.get("infra_tools", {}),
        "extra_file_patterns": config.get("blocked_files", {}).get("extra_patterns", []),
        "extra_cmd_patterns": config.get("blocked_commands", {}).get("extra_patterns", []),
    }

    hooks: dict[str, str] = {}
    for hook_name, info in HOOK_REGISTRATION.items():
        if not rules.get(info["rule"], True):
            continue
        template_name = hook_name.replace(".sh", ".sh.j2")
        template_path = HOOK_TEMPLATES_DIR / template_name
        if not template_path.exists():
            print(f"WARNING: Hook template not found: {template_path}", file=sys.stderr)
            continue
        template = env.get_template(template_name)
        hooks[hook_name] = template.render(**context)

    return hooks


def generate_ci_config(config: dict[str, Any]) -> str:
    """Generate CI agent config (default.json) from guardrails.yaml."""
    # Load the current default.json as a base
    ci_config_path = CONFIG_DIR.parent / "ai-ci-agents" / "config" / "default.json"
    if ci_config_path.exists():
        with open(ci_config_path) as f:
            ci_config = json.load(f)
    else:
        ci_config = {}

    ci = config.get("ci_agents", {})
    cd = config.get("client_data", {})

    # Override code health settings
    ch = ci.get("code_health", {})
    if "code_health" in ci_config:
        if "max_file_lines" in ch:
            ci_config["code_health"]["file_length"]["max_lines"] = ch["max_file_lines"]
        if "max_function_lines" in ch:
            ci_config["code_health"]["function_size"]["max_lines"] = ch["max_function_lines"]
        if "dead_code_threshold" in ch:
            ci_config["code_health"]["dead_code"]["threshold"] = ch["dead_code_threshold"]
        for toggle in ("missing_docstrings", "missing_type_hints", "missing_tests"):
            if toggle in ch:
                key = toggle.replace("missing_", "")
                if key == "docstrings":
                    key = "missing_docstrings"
                elif key == "type_hints":
                    key = "missing_type_hints"
                elif key == "tests":
                    key = "missing_tests"
                if key in ci_config["code_health"]:
                    ci_config["code_health"][key]["enabled"] = ch[toggle]

    # Override client data patterns
    if cd.get("patterns") and "governance" in ci_config:
        ci_config["governance"]["client_data_patterns"] = [
            {"pattern": p["pattern"], "name": p["name"]}
            for p in cd["patterns"]
        ]
    if cd.get("skip_words") and "governance" in ci_config:
        ci_config["governance"]["client_data_skip_words"] = cd["skip_words"]

    # Inject custom rules
    custom = ci.get("custom_rules", [])
    if custom:
        ci_config["custom_rules"] = custom

    return json.dumps(ci_config, indent=2) + "\n"


def generate_hook_registration(config: dict[str, Any]) -> dict[str, list[dict]]:
    """Build the hooks.PreToolUse structure for settings.json."""
    rules = config.get("rules", {})
    matchers: dict[str, list[str]] = {}

    for hook_name, info in HOOK_REGISTRATION.items():
        if not rules.get(info["rule"], True):
            continue
        for matcher in info["matchers"]:
            if matcher not in matchers:
                matchers[matcher] = []
            matchers[matcher].append(f"~/.claude/hooks/{hook_name}")

    result = []
    for matcher in ["Read", "Write", "Edit", "Bash"]:
        if matcher in matchers:
            result.append({
                "matcher": matcher,
                "hooks": [{"type": "command", "command": cmd} for cmd in matchers[matcher]],
            })

    return result


def write_outputs(config: dict[str, Any], output_dir: str) -> None:
    """Write all generated files to the output directory."""
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    hooks_dir = out / "hooks"
    hooks_dir.mkdir(exist_ok=True)

    # CLAUDE.md
    claude_md = generate_claude_md(config)
    (out / "CLAUDE.md").write_text(claude_md)
    print(f"  Generated {out / 'CLAUDE.md'}")

    # settings.json (with hook registrations merged in)
    settings = json.loads(generate_settings_json(config))
    hook_reg = generate_hook_registration(config)
    if hook_reg:
        settings["hooks"] = {"PreToolUse": hook_reg}
    (out / "settings.json").write_text(json.dumps(settings, indent=2) + "\n")
    print(f"  Generated {out / 'settings.json'}")

    # Hook scripts
    hooks = generate_hooks(config)
    for name, content in hooks.items():
        path = hooks_dir / name
        path.write_text(content)
        path.chmod(0o755)
        print(f"  Generated {path}")

    # CI config
    ci_config = generate_ci_config(config)
    ci_out = Path(output_dir).parent / "ai-ci-agents" / "config"
    if ci_out.exists():
        (ci_out / "default.json").write_text(ci_config)
        print(f"  Generated {ci_out / 'default.json'}")


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 config/generate.py <guardrails.yaml> [--output-dir <dir>]", file=sys.stderr)
        sys.exit(1)

    config_path = sys.argv[1]
    output_dir = "ai-guardrails/claude"

    if "--output-dir" in sys.argv:
        idx = sys.argv.index("--output-dir")
        if idx + 1 < len(sys.argv):
            output_dir = sys.argv[idx + 1]

    print(f"Loading config from {config_path}...")
    config = load_config(config_path)

    print(f"Generating outputs to {output_dir}/...")
    write_outputs(config, output_dir)

    print("Done.")


if __name__ == "__main__":
    main()
