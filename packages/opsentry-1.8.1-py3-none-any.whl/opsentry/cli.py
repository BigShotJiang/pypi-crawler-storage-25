"""OpSentry CLI — AI agent security guardrails for engineering teams.

Entry point for the pip-installed opsentry command.
Resolves data files from the installed package, not a git checkout.
"""

import argparse
import json
import os
import shutil
import subprocess
import sys
import urllib.request
from pathlib import Path

# Package root — where data files live alongside this module
PKG_ROOT = Path(__file__).resolve().parent
VERSION_FILE = PKG_ROOT / "VERSION"
CONFIG_DIR = PKG_ROOT / "config"
DEPLOYMENT_DIR = PKG_ROOT / "deployment"
INSTALL_SCRIPT = DEPLOYMENT_DIR / "install.sh"
VERIFY_SCRIPT = DEPLOYMENT_DIR / "verify.sh"
PATROL_SCRIPT = DEPLOYMENT_DIR / "patrol.sh"
CLAUDE_HOME = Path.home() / ".claude"

GITHUB_REPO = "opsight-intelligence/opsentry"
RELEASES_API = f"https://api.github.com/repos/{GITHUB_REPO}/releases/latest"


def get_local_version() -> str:
    if VERSION_FILE.exists():
        return VERSION_FILE.read_text().strip()
    return "unknown"


def get_installed_version() -> str:
    installed = CLAUDE_HOME / "VERSION"
    if installed.exists():
        return installed.read_text().strip()
    return "not installed"


def check_latest_version() -> str | None:
    """Check GitHub for the latest release tag. Returns None on failure."""
    try:
        req = urllib.request.Request(
            RELEASES_API, headers={"Accept": "application/vnd.github.v3+json"}
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            return data.get("tag_name", "").lstrip("v")
    except Exception:
        return None


def print_version_status():
    local = get_local_version()
    installed = get_installed_version()
    print(f"  Repo version:      {local}")
    print(f"  Installed version: {installed}")

    latest = check_latest_version()
    if latest:
        print(f"  Latest release:    {latest}")
        if local != latest:
            print(f"\n  Update available: {local} -> {latest}")
            print("    Run: pip install --upgrade opsentry && opsentry install")
    else:
        print("  Latest release:    (could not check)")


def run_script(script: Path, label: str, cwd: Path | None = None) -> int:
    if not script.exists():
        print(f"ERROR: {label} not found at {script}", file=sys.stderr)
        return 1
    result = subprocess.run(
        ["bash", str(script)],
        cwd=str(cwd) if cwd else None,
        env={**os.environ, "OPSENTRY_PKG_ROOT": str(PKG_ROOT)},
    )
    return result.returncode


def check_deps():
    """Check required dependencies are available."""
    missing = []
    for cmd in ("jq", "bash"):
        if shutil.which(cmd) is None:
            missing.append(cmd)
    if missing:
        print(f"Missing dependencies: {', '.join(missing)}", file=sys.stderr)
        print("Install with:", file=sys.stderr)
        print("  macOS:  brew install " + " ".join(missing), file=sys.stderr)
        print("  Ubuntu: sudo apt install " + " ".join(missing), file=sys.stderr)
        return False
    return True


# -- Subcommands ---------------------------------------------------------------


def cmd_init(args):
    """Run the interactive setup wizard."""
    sys.path.insert(0, str(CONFIG_DIR))
    from init_wizard import main as wizard_main

    sys.argv = ["opsentry init"] + args.extra
    wizard_main()


def cmd_generate(args):
    """Generate enforcement files from guardrails.yaml."""
    guardrails_yaml = Path.cwd() / "guardrails.yaml"
    if not guardrails_yaml.exists():
        print(f"ERROR: guardrails.yaml not found in {Path.cwd()}", file=sys.stderr)
        print("Run 'opsentry init' first to create it.", file=sys.stderr)
        return 1

    sys.path.insert(0, str(CONFIG_DIR))
    from generate import load_config, write_outputs

    config = load_config(str(guardrails_yaml))
    output_dir = str(DEPLOYMENT_DIR / "claude")
    print(f"Generating from {guardrails_yaml}...")
    write_outputs(config, output_dir)
    print("Done.")
    return 0


def cmd_install(args):
    """Install guardrails to ~/.claude/."""
    if not check_deps():
        return 1

    print("=" * 50)
    print("  OpSentry Install")
    print("=" * 50)
    print()

    # Generate if guardrails.yaml exists in cwd
    guardrails_yaml = Path.cwd() / "guardrails.yaml"
    if guardrails_yaml.exists():
        print("Found guardrails.yaml — generating config...")
        ret = cmd_generate(args)
        if ret != 0:
            return ret
        print()

    ret = run_script(INSTALL_SCRIPT, "install.sh", cwd=DEPLOYMENT_DIR.parent)
    if ret == 0:
        print()
        print_version_status()
    return ret


def cmd_update(args):
    """Update opsentry to the latest version."""
    print("Updating opsentry...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--upgrade", "opsentry"],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(f"Upgrade failed: {result.stderr}", file=sys.stderr)
        return 1
    print(result.stdout.strip())
    print()
    return cmd_install(args)


def cmd_verify(args):
    """Check installed guardrails are intact."""
    ret = run_script(VERIFY_SCRIPT, "verify.sh", cwd=DEPLOYMENT_DIR.parent)
    if ret == 0:
        print()
        print_version_status()
    return ret


def cmd_patrol(args):
    """Run compliance patrol (extended audit)."""
    return run_script(PATROL_SCRIPT, "patrol.sh", cwd=DEPLOYMENT_DIR.parent)


def cmd_status(args):
    """Show installation status and version info."""
    print("=" * 50)
    print("  OpSentry Status")
    print("=" * 50)
    print()

    print_version_status()
    print()

    checks = [
        (CLAUDE_HOME / "CLAUDE.md", "CLAUDE.md"),
        (CLAUDE_HOME / "settings.json", "settings.json"),
        (CLAUDE_HOME / "hooks", "hooks/"),
    ]
    all_ok = True
    for path, label in checks:
        if path.exists():
            print(f"  + {label}")
        else:
            print(f"  x {label} — MISSING")
            all_ok = False

    hook_names = [
        "block-sensitive-files.sh",
        "block-dangerous-commands.sh",
        "block-git-commands.sh",
        "block-data-exfiltration.sh",
        "block-package-install.sh",
        "block-scope-escape.sh",
        "block-environment-escape.sh",
        "block-pii-leakage.sh",
    ]
    hooks_dir = CLAUDE_HOME / "hooks"
    if hooks_dir.exists():
        for h in hook_names:
            hp = hooks_dir / h
            if hp.exists() and os.access(hp, os.X_OK):
                print(f"  + hooks/{h}")
            else:
                status = "not executable" if hp.exists() else "MISSING"
                print(f"  x hooks/{h} — {status}")
                all_ok = False

    print()
    guardrails_yaml = Path.cwd() / "guardrails.yaml"
    if guardrails_yaml.exists():
        print(f"  Config: {guardrails_yaml}")
    else:
        print("  Config: none (using static files)")

    log = CLAUDE_HOME / "guardrail-blocks.log"
    if log.exists():
        line_count = sum(1 for _ in open(log))
        print(f"  Block log: {line_count} entries ({log})")
    else:
        print("  Block log: empty (no blocks recorded yet)")

    print()
    if all_ok:
        print("  Status: All guardrails installed and intact.")
    else:
        print("  Status: INCOMPLETE — run 'opsentry install' to fix.")

    return 0 if all_ok else 1


# -- Main ----------------------------------------------------------------------


def main():
    parser = argparse.ArgumentParser(
        prog="opsentry",
        description="OpSentry — AI agent security guardrails for engineering teams",
    )
    parser.add_argument(
        "--version", action="version", version=f"opsentry {get_local_version()}"
    )
    sub = parser.add_subparsers(dest="command")

    p_init = sub.add_parser("init", help="Interactive setup wizard")
    p_init.add_argument("extra", nargs="*", help="Extra args passed to init wizard")

    sub.add_parser("generate", help="Generate enforcement files from guardrails.yaml")
    sub.add_parser("install", help="Generate + install guardrails to ~/.claude/")
    sub.add_parser("update", help="Update to latest version + reinstall")
    sub.add_parser("verify", help="Check installed guardrails are intact")
    sub.add_parser("status", help="Show installation status and version info")
    sub.add_parser("patrol", help="Run compliance patrol (extended audit)")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 0

    commands = {
        "init": cmd_init,
        "generate": cmd_generate,
        "install": cmd_install,
        "update": cmd_update,
        "verify": cmd_verify,
        "status": cmd_status,
        "patrol": cmd_patrol,
    }
    return commands[args.command](args)


if __name__ == "__main__":
    sys.exit(main() or 0)
