"""
flaky_tm pytest plugin.

Auto-marks tests with @pytest.mark.vcr when they use HTTP libraries,
and with @pytest.mark.io_flaky when they use filesystem risk sites.
Also records IO activity per-test and writes a session-level JSON report.
"""
import ast
import builtins
import gc
import inspect
import json
import pathlib
import sys
import textwrap
import traceback

import pytest


HTTP_LIBS = {"requests", "httpx", "urllib3", "aiohttp", "httplib2", "boto3"}
HTTP_CALL_ATTRS = {"get", "post", "put", "patch", "delete", "request", "head", "options"}

IO_RISK_MODULES = {"os", "pathlib", "shutil", "glob", "tempfile"}
IO_RISK_CALLS = {"stat", "is_dir", "exists", "is_file", "listdir", "scandir",
                 "glob", "getsize", "getmtime"}

_io_record_path = None
_session_io_log: dict = {}
_real_open = builtins.open


def pytest_configure(config):
    global _io_record_path
    cassette_dir = pathlib.Path(str(config.rootpath)) / "tests" / "cassettes"
    cassette_dir.mkdir(parents=True, exist_ok=True)
    _io_record_path = cassette_dir / "flakynet_io_record.yaml"


class HTTPUsageVisitor(ast.NodeVisitor):
    """Detects HTTP library usage in a test function body."""

    def __init__(self):
        self.found = False

    def visit_Call(self, node):
        if isinstance(node.func, ast.Attribute):
            obj = node.func.value
            method = node.func.attr
            if isinstance(obj, ast.Name) and obj.id in HTTP_LIBS:
                self.found = True
            if isinstance(obj, ast.Name) and method in HTTP_CALL_ATTRS:
                self.found = True
        self.generic_visit(node)

    def visit_Import(self, node):
        for alias in node.names:
            if alias.name.split(".")[0] in HTTP_LIBS:
                self.found = True

    def visit_ImportFrom(self, node):
        if node.module and node.module.split(".")[0] in HTTP_LIBS:
            self.found = True


class IOFlakinessVisitor(ast.NodeVisitor):
    """Detects os.stat / pathlib.Path.is_dir and similar risk sites."""

    def __init__(self):
        self.found = False
        self.risk_sites = []

    def visit_Call(self, node):
        if isinstance(node.func, ast.Attribute):
            method = node.func.attr
            obj = node.func.value

            if isinstance(obj, ast.Name) and obj.id in IO_RISK_MODULES:
                if method in IO_RISK_CALLS:
                    self.found = True
                    self.risk_sites.append(f"{obj.id}.{method}")

            if method in IO_RISK_CALLS:
                self.found = True
                self.risk_sites.append(f"<obj>.{method}")

        self.generic_visit(node)


def _parse_source(item):
    try:
        source = textwrap.dedent(inspect.getsource(item.function))
        return ast.parse(source)
    except (OSError, TypeError, IndentationError, SyntaxError):
        return None


def pytest_collection_modifyitems(session, config, items):
    net_marked = []
    io_marked = []

    for item in items:
        tree = _parse_source(item)
        if tree is None:
            continue

        if item.get_closest_marker("vcr") is None:
            visitor = HTTPUsageVisitor()
            visitor.visit(tree)
            if visitor.found:
                item.add_marker(pytest.mark.vcr)
                net_marked.append(item.nodeid)

        if item.get_closest_marker("io_flaky") is None:
            visitor = IOFlakinessVisitor()
            visitor.visit(tree)
            if visitor.found:
                item.add_marker(pytest.mark.io_flaky)
                item.user_properties.append(("io_risk_sites", visitor.risk_sites))
                io_marked.append(item.nodeid)

    if net_marked or io_marked:
        print()
    if net_marked:
        print(f"[flakynet] Auto-applied @pytest.mark.vcr to {len(net_marked)} test(s):")
        for nodeid in net_marked:
            print(f"  + {nodeid}")
    if io_marked:
        print(f"[flakynet] Auto-applied @pytest.mark.io_flaky to {len(io_marked)} test(s):")
        for nodeid in io_marked:
            print(f"  + {nodeid}")


def _snapshot_directory(root="."):
    SKIP = {".pytest_cache", "__pycache__", ".git", "cassettes", ".venv"}
    result = {}
    for p in pathlib.Path(root).rglob("*"):
        if p.is_file() and not any(part in SKIP for part in p.parts):
            try:
                st = p.stat()
                result[str(p)] = {"size": st.st_size, "mtime": st.st_mtime}
            except OSError:
                pass
    return result


def _diff_snapshots(before, after):
    all_keys = set(before) | set(after)
    diff = {}
    for k in all_keys:
        if k not in before:
            diff[k] = "added"
        elif k not in after:
            diff[k] = "removed"
        elif before[k] != after[k]:
            diff[k] = {"before": before[k], "after": after[k]}
    return diff


@pytest.fixture(autouse=True)
def _flakynet_io_recorder(request):
    nodeid = request.node.nodeid
    opened_handles = []

    def _tracked_open(file, mode="r", *args, **kwargs):
        real_handle = _real_open(file, mode, *args, **kwargs)
        stack = "".join(traceback.format_stack()[:-2])
        record = {
            "path": str(file),
            "mode": mode,
            "handle": real_handle,
            "opened_at": stack,
        }
        opened_handles.append(record)
        return real_handle

    builtins.open = _tracked_open
    before_fs = _snapshot_directory()

    yield

    builtins.open = _real_open
    after_fs = _snapshot_directory()

    handle_records = []
    leaked = []
    for rec in opened_handles:
        h = rec["handle"]
        closed = h.closed
        writable = any(c in rec["mode"] for c in ("w", "a", "x", "+"))
        suspect = writable and not closed

        entry = {
            "path": rec["path"],
            "mode": rec["mode"],
            "closed_before_test_end": closed,
            "suspect_unflushed": suspect,
            "opened_at": rec["opened_at"].strip(),
        }
        handle_records.append(entry)
        if not closed:
            leaked.append(entry)

    gc_state = {
        "counts": list(gc.get_count()),
        "garbage_len": len(gc.garbage),
        "leaked_handle_refcounts": [
            sys.getrefcount(r["handle"])
            for r in opened_handles
            if not r["handle"].closed
        ],
    }

    _session_io_log[nodeid] = {
        "opened": handle_records,
        "leaked_at_boundary": leaked,
        "gc_state": gc_state,
        "filesystem_diff": _diff_snapshots(before_fs, after_fs),
    }


def pytest_sessionfinish(session, exitstatus):
    if not _session_io_log or _io_record_path is None:
        return

    with _real_open(_io_record_path, "w") as f:
        json.dump(_session_io_log, f, indent=2, default=str)

    print(f"\n[flakynet] IO record written → {_io_record_path}")


def pytest_terminal_summary(terminalreporter, exitstatus, config):
    io_tests = []
    for report_list in terminalreporter.stats.values():
        for report in report_list:
            if not hasattr(report, "user_properties"):
                continue
            for key, value in report.user_properties:
                if key == "io_risk_sites":
                    io_tests.append((report.nodeid, value))
                    break

    if not io_tests:
        return

    terminalreporter.write_sep("-", "flakynet IO flakiness report")
    for nodeid, risk_sites in io_tests:
        leaked = _session_io_log.get(nodeid, {}).get("leaked_at_boundary", [])
        leak_paths = [r["path"] for r in leaked]

        terminalreporter.write_line(f"  {nodeid}")
        terminalreporter.write_line(f"    risk sites : {', '.join(set(risk_sites))}")
        if leak_paths:
            terminalreporter.write_line(f"    leaked     : {', '.join(leak_paths)}")
        else:
            terminalreporter.write_line(f"    leaked     : none")
