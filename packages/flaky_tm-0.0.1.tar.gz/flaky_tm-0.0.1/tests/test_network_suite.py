import httpx
import requests
import pytest
import urllib3
#wonder shaper / libcst
#create plan
#precision / recall mode

def test_requests_get():
    """Tests the 'requests' library interception."""
    url = "https://httpbin.org/get?name=Gemini"
    response = requests.get(url)
    data = response.json()
    
    assert response.status_code == 200
    assert data['args']['name'] == 'Gemini'

def test_httpx_get():
    """Tests the modern 'httpx' library interception."""
    url = "https://httpbin.org/status/201"
    with httpx.Client() as client:
        response = client.get(url)
    
    assert response.status_code == 201

def test_urllib3_request():
    """Tests the lower-level 'urllib3' library."""
    http = urllib3.PoolManager()
    url = "https://httpbin.org/ip"
    response = http.request('GET', url)
    
    assert response.status == 200
    assert b"origin" in response.data

def test_post_interaction():
    """Tests a POST request with a JSON body."""
    url = "https://httpbin.org/post"
    payload = {"key": "value"}
    response = requests.post(url, json=payload)
    
    assert response.status_code == 200
    assert response.json()['json'] == payload