import json
import os
import pathlib
import tempfile
import stat
import time

# If size_bytes: 0 — that's the smoking gun. 
# The file exists on disk but the buffer hasn't been flushed yet because close() was never called. 
# This is exactly the evidence we need.

"""
builtins.stat
pathlib.Path.is_dir
"""


# Group 1: Bare open() — no context manager, relies on GC to close/flush
# These are the canonical examples from the architecture discussion.
# The recorder should flag: closed_before_test_end=False, flushed=False
def test_writes_config_no_close():
    """
    Opens a file for writing but never calls close().
    On CPython the refcount hits 0 at function exit so __del__ fires
    immediately — but this is an implementation detail, not a guarantee.
    PyPy / Jython will defer it, causing test_reads_config_after_write to
    see an empty or partial file.
    """
    f = open("config.json", "w")
    f.write('{"key": "value"}')
    # no f.close() — recorder should flag this


def test_reads_config_after_write():
    """
    Depends on test_writes_config_no_close having flushed its buffer.
    Will fail if the GC hasn't collected the previous test's file handle.
    os.stat here is intentional — the paper flagged this as a risk site.
    """
    info = os.stat("config.json")
    assert info.st_size > 0, "file is empty — previous test's buffer not flushed"

    with open("config.json", "r") as f:
        data = json.load(f)
    assert data["key"] == "value"


# ---------------------------------------------------------------------------
# Group 2: pathlib.Path.is_dir / .exists — state checks that are
# sensitive to whether a previous test cleaned up after itself
# ---------------------------------------------------------------------------

def test_creates_temp_directory():
    """
    Creates a directory but does not remove it.
    Leaves filesystem state that the next test may depend on.
    """
    p = pathlib.Path("scratch_dir")
    p.mkdir(exist_ok=True)
    (p / "data.txt").write_text("hello")
    # no cleanup — recorder should log this in the filesystem diff


def test_checks_directory_exists():
    """
    Uses Path.is_dir() — one of the paper's flagged call sites.
    Passes if test_creates_temp_directory ran first; fails otherwise.
    """
    p = pathlib.Path("scratch_dir")
    assert p.is_dir(), "scratch_dir missing — likely order-dependent"
    assert (p / "data.txt").read_text() == "hello"


def test_directory_cleanup_check():
    """
    Uses both os.stat and Path.is_dir — double risk site.
    Also fragile: passes only if scratch_dir still exists.
    """
    p = pathlib.Path("scratch_dir")
    if p.is_dir():
        info = os.stat(str(p))
        # st_nlink > 2 means the directory has children
        assert info.st_nlink >= 2


# ---------------------------------------------------------------------------
# Group 3: File handle leaked across a helper function boundary
# Static analysis may miss this — only runtime tracking will catch it.
# ---------------------------------------------------------------------------

def _open_log_file(path):
    """Returns an open file handle — caller is responsible for closing."""
    return open(path, "w")


def test_leaks_handle_via_helper():
    """
    The handle is returned by a helper and assigned locally.
    When the function returns, refcount drops to 0 on CPython.
    On other runtimes the handle — and its unflushed buffer — lingers.
    """
    handle = _open_log_file("app.log")
    handle.write("startup complete\n")
    # deliberate: no handle.close()


def test_reads_log_after_helper_leak():
    """
    Reads the file written by the previous test.
    Sensitive to whether the buffer was flushed.
    os.stat used to check size — flagged call site from the paper.
    """
    info = os.stat("app.log")
    assert info.st_size > 0, "log file empty — buffer from previous test not flushed"


# ---------------------------------------------------------------------------
# Group 4: Multiple handles to the same file — one writer, one reader,
# neither closed. The reader may see stale data depending on GC timing.
# ---------------------------------------------------------------------------

def test_write_settings():
    """Writes a settings file without closing."""
    w = open("settings.cfg", "w")
    w.write("[defaults]\ntimeout=30\n")
    # no close


def test_read_settings_concurrent_handle():
    """
    Opens the same file for reading while the writer handle from the
    previous test may still be alive. Content may be empty or partial.
    Path.exists() used here — another flagged call site.
    """
    p = pathlib.Path("settings.cfg")
    assert p.exists(), "settings.cfg not found"

    r = open("settings.cfg", "r")   # also not closed — double leak
    content = r.read()
    assert "timeout" in content


# ---------------------------------------------------------------------------
# Group 5: tempfile misuse — NamedTemporaryFile with delete=True
# and the name used after the with block. The file is deleted on close
# but tests sometimes try to reopen by name outside the context.
# ---------------------------------------------------------------------------

def test_writes_to_named_tempfile():
    """
    Stores the tempfile name on a module-level variable so other tests
    can try to read from it — but the file is deleted when the context
    exits.
    """
    global _shared_tmp_path
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json",
                                     delete=True, delete_on_close=False) as tf:
        tf.write('{"tmp": true}')
        tf.flush()
        _shared_tmp_path = tf.name
    # file is now deleted — next test will fail

# This test doesn't work
# def test_reads_deleted_tempfile():
#     """
#     Tries to read the tempfile written above.
#     Will fail because delete=True removed the file when the context exited.
#     os.stat used here — flagged call site, and will raise FileNotFoundError.
#     """
#     p = pathlib.Path(_shared_tmp_path)
#     # This is the flaky line — passes only if the file somehow still exists
#     info = os.stat(str(p))
#     assert info.st_size > 0


# ---------------------------------------------------------------------------
# Group 6: Timing-sensitive flush — explicit flush but delayed close,
# combined with a sleep that may or may not be long enough.
# This is a more subtle version of Group 1.
# ---------------------------------------------------------------------------

def test_writes_with_delayed_close():
    """
    Flushes but delays the close. Whether os.fsync completes before the
    next test reads depends on OS buffering and scheduler timing.
    """
    f = open("timed.dat", "w")
    f.write("payload")
    f.flush()
    # intentionally NOT calling os.fsync or f.close() here
    # on some systems the page cache may not be committed yet


def test_reads_after_delayed_close():
    """
    Reads immediately after. Combines os.stat (paper risk site) and
    Path.is_file() to check state before reading.
    """
    p = pathlib.Path("timed.dat")
    assert p.is_file(), "timed.dat not present"
    info = os.stat("timed.dat")
    assert info.st_size > 0
    with open("timed.dat", "r") as f:
        assert f.read() == "payload"


# ---------------------------------------------------------------------------
# Cleanup — a well-behaved test at the end to reset shared state.
# The recorder should show this test has zero leaked handles and a clean
# filesystem diff, giving a baseline to compare the others against.
# ---------------------------------------------------------------------------

def test_cleanup_shared_files():
    """
    Properly cleans up files left by the flaky tests above.
    This test should appear clean in the recorder output:
    no leaked handles, filesystem diff shows files removed.
    """
    for name in ["config.json", "app.log", "settings.cfg", "timed.dat"]:
        try:
            os.remove(name)
        except FileNotFoundError:
            pass

    p = pathlib.Path("scratch_dir")
    if p.is_dir():
        import shutil
        shutil.rmtree(str(p))

    assert not pathlib.Path("config.json").exists()
    assert not pathlib.Path("scratch_dir").is_dir()