Recorder/Replayer for flaky tests in python

## Running the tests

1. Install dependencies (e.g. `pip install requests vcrpy pytest`).
2. From the project root run `pytest -v`. A small ``tests/conftest.py`` file
   ensures modules are importable and the ``recorder`` decorator will write a
   cassette into ``recordings/`` when a decorated function runs.

