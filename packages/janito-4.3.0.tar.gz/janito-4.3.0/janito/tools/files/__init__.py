"""
File manager tools module.
"""