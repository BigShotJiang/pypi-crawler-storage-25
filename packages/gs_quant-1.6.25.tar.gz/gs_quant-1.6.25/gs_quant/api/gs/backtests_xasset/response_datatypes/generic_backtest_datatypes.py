"""
Copyright 2019 Goldman Sachs.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.
"""


def decode_strategy(data):
    """Decode a strategy dict into a gs_quant.backtests.strategy.Strategy instance."""
    if data is None:
        return None
    from gs_quant.backtests.strategy import Strategy

    if isinstance(data, Strategy):
        return data
    return Strategy.from_dict(data)


__all__ = ['decode_strategy']
