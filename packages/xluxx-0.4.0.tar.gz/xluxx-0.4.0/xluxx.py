"""
XLUXX Trust Layer — Python SDK
Makes AI agents reliable by providing runtime trust scores for MCP tools.

Usage:
    from xluxx import TrustLayer

    trust = TrustLayer(api_key="your_key")
    
    # Find the best tool for an intent
    result = trust.resolve("search the web")
    print(result.best_server)    # "brave-search"
    print(result.confidence)     # 0.985
    
    # Rank specific tools
    ranked = trust.rank(["github", "gitlab", "bitbucket"])
    
    # Get server details
    server = trust.server("github")
"""

import json
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from dataclasses import dataclass
from typing import Optional, List, Dict, Any


API_BASE = "https://web-production-44346.up.railway.app"


@dataclass
class ResolveResult:
    """Result from /resolve-tool"""
    best_server: Optional[str]
    confidence: float
    expected_latency: str
    risk_flags: List[str]
    fallback: Optional[str]
    candidates: List[Dict]
    intent: str
    resolved_at: str
    raw: Dict[str, Any]

    @classmethod
    def from_dict(cls, d):
        return cls(
            best_server=d.get("best_server") or d.get("best_tool"),
            confidence=d.get("confidence", 0),
            expected_latency=d.get("expected_latency", "unknown"),
            risk_flags=d.get("risk_flags", []),
            fallback=d.get("fallback"),
            candidates=d.get("candidates", d.get("ranked_tools", [])),
            intent=d.get("intent", ""),
            resolved_at=d.get("resolved_at", ""),
            raw=d
        )


@dataclass 
class RankResult:
    """Result from /rank-tools"""
    ranked: List[Dict]
    ranked_at: str

    @classmethod
    def from_dict(cls, d):
        return cls(ranked=d.get("ranked", []), ranked_at=d.get("ranked_at", ""))


class TrustLayerError(Exception):
    """Error from the XLUXX Trust Layer API"""
    def __init__(self, message, status_code=None):
        super().__init__(message)
        self.status_code = status_code


class TrustLayer:
    """
    XLUXX Trust Layer client.
    
    Provides runtime trust scores for MCP servers.
    Agents call this before using any tool to get the most reliable option.
    """
    
    def __init__(self, api_key: Optional[str] = None, base_url: str = API_BASE):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
    
    def _request(self, method: str, path: str, body: Optional[Dict] = None) -> Dict:
        url = f"{self.base_url}{path}"
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        
        data = json.dumps(body).encode() if body else None
        req = Request(url, data=data, headers=headers, method=method)
        
        try:
            with urlopen(req, timeout=10) as resp:
                return json.loads(resp.read())
        except HTTPError as e:
            body = e.read().decode() if e.fp else ""
            try:
                err = json.loads(body)
                msg = err.get("error", body)
            except:
                msg = body
            raise TrustLayerError(msg, e.code)
        except URLError as e:
            raise TrustLayerError(f"Connection failed: {e.reason}")
    
    def resolve(self, intent: str, tools: Optional[List[str]] = None, 
                category: Optional[str] = None,
                min_trust_score: Optional[float] = None,
                max_latency_ms: Optional[int] = None) -> ResolveResult:
        """
        Find the best MCP tool for a given intent.
        
        Args:
            intent: What the agent needs to do (e.g., "search the web")
            tools: Optional list of specific tool IDs to choose from
            category: Optional category filter (e.g., "database", "search")
            min_trust_score: Minimum acceptable trust score (0-100)
            max_latency_ms: Maximum acceptable latency in milliseconds
        
        Returns:
            ResolveResult with best_server, confidence, fallback, etc.
        """
        body = {"intent": intent}
        if tools:
            body["available_tools"] = tools
        if category:
            body["category"] = category
        if min_trust_score is not None:
            body["min_trust_score"] = min_trust_score
        if max_latency_ms is not None:
            body["max_latency_ms"] = max_latency_ms
        
        data = self._request("POST", "/resolve-tool", body)
        return ResolveResult.from_dict(data)
    
    def rank(self, tools: List[str]) -> RankResult:
        """
        Rank a list of MCP tools by trust score.
        
        Args:
            tools: List of tool/server IDs to rank
        
        Returns:
            RankResult with ranked list
        """
        data = self._request("POST", "/rank-tools", {"tools": tools})
        return RankResult.from_dict(data)
    
    def server(self, server_id: str) -> Dict:
        """Get detailed info about a specific MCP server."""
        return self._request("GET", f"/servers/{server_id}")
    
    def servers(self, limit: int = 50) -> List[Dict]:
        """List all tracked servers, sorted by trust score."""
        data = self._request("GET", f"/servers?limit={limit}")
        return data.get("servers", [])
    
    def search(self, query: str) -> List[Dict]:
        """Search servers by name, description, or category."""
        data = self._request("GET", f"/search?q={query}")
        return data.get("results", [])
    
    def health(self) -> Dict:
        """Check API health and stats."""
        return self._request("GET", "/health")
    
    @staticmethod
    def register(name: str, email: str, base_url: str = API_BASE) -> str:
        """
        Register for a free API key.
        
        Returns:
            API key string
        """
        client = TrustLayer(base_url=base_url)
        data = client._request("POST", "/register", {"name": name, "email": email})
        return data.get("api_key", "")


# Convenience function for quick one-shot resolution
def resolve(intent: str, api_key: Optional[str] = None, **kwargs) -> ResolveResult:
    """Quick resolve — find the best tool for an intent."""
    return TrustLayer(api_key=api_key).resolve(intent, **kwargs)
