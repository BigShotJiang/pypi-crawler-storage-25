from setuptools import setup

setup(
    name="xluxx",
    version="0.1.0",
    description="XLUXX Trust Layer — runtime trust scoring for 15,000+ MCP servers, with Resonance Engine and Context Gate",
    long_description="Makes AI agents reliable by providing real-time trust scores for 15,000+ MCP servers. Includes the Resonance Engine (fractal reliability, coherence drift) and the Context Gate (a context firewall that blocks responses when an agent has drifted from its original instructions). One API call tells your agent which tool is most reliable.",
    author="XLUXX",
    url="https://github.com/DrDMT-VR/xluxx-trust",
    py_modules=["xluxx"],
    python_requires=">=3.7",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries",
        "Programming Language :: Python :: 3",
    ],
)
