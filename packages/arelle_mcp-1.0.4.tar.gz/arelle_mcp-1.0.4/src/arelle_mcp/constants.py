"""
Constants for the arelle-mcp server.

Maps human-friendly names to Arelle's internal constants for arcroles,
disclosure systems, statement role patterns, and SEC EDGAR endpoints.
"""

from __future__ import annotations

# ─── XBRL Arcroles ───────────────────────────────────────────────────────────
# These map to arelle.XbrlConst values but are defined as strings to avoid
# importing Arelle at module load time (Arelle is heavy, load lazily).

ARCROLE_PARENT_CHILD = "http://www.xbrl.org/2003/arcrole/parent-child"
ARCROLE_SUMMATION_ITEM = "http://www.xbrl.org/2003/arcrole/summation-item"
ARCROLE_CONCEPT_LABEL = "http://www.xbrl.org/2003/arcrole/concept-label"
ARCROLE_CONCEPT_REFERENCE = "http://www.xbrl.org/2003/arcrole/concept-reference"
ARCROLE_DIMENSION_DOMAIN = "http://xbrl.org/int/dim/arcrole/dimension-domain"
ARCROLE_DOMAIN_MEMBER = "http://xbrl.org/int/dim/arcrole/domain-member"
ARCROLE_HYPERCUBE_DIMENSION = "http://xbrl.org/int/dim/arcrole/hypercube-dimension"
ARCROLE_ALL = "http://xbrl.org/int/dim/arcrole/all"
ARCROLE_NOT_ALL = "http://xbrl.org/int/dim/arcrole/notAll"

ARCROLE_MAP: dict[str, str] = {
    "presentation": ARCROLE_PARENT_CHILD,
    "parent-child": ARCROLE_PARENT_CHILD,
    "calculation": ARCROLE_SUMMATION_ITEM,
    "summation-item": ARCROLE_SUMMATION_ITEM,
    "label": ARCROLE_CONCEPT_LABEL,
    "reference": ARCROLE_CONCEPT_REFERENCE,
    "dimension-domain": ARCROLE_DIMENSION_DOMAIN,
    "domain-member": ARCROLE_DOMAIN_MEMBER,
    "hypercube-dimension": ARCROLE_HYPERCUBE_DIMENSION,
    "all": ARCROLE_ALL,
    "not-all": ARCROLE_NOT_ALL,
    "all-dimensions": "XBRL-dimensions",
    "all-formulas": "XBRL-formula",
}

# ─── Disclosure Systems ──────────────────────────────────────────────────────

DISCLOSURE_SYSTEMS: dict[str, str] = {
    "efm": "efm-pragmatic-all-years",
    "efm-strict": "efm-strict",
    "efm-pragmatic": "efm-pragmatic-all-years",
    "esef": "esef",
    "hmrc": "hmrc",
    "gfm": "gfm",
}

# ─── Financial Statement Role Patterns ────────────────────────────────────────
# Used to match link roles to known financial statement types.

STATEMENT_ROLE_PATTERNS: dict[str, list[str]] = {
    "balance_sheet": [
        "BalanceSheet",
        "FinancialPosition",
        "StatementOfFinancialPosition",
        "ConsolidatedBalanceSheet",
    ],
    "income_statement": [
        "IncomeStatement",
        "StatementsOfIncome",
        "StatementsOfOperations",
        "ProfitOrLoss",
        "StatementOfComprehensiveIncome",
        "ConsolidatedStatementsOfOperations",
    ],
    "cash_flow": [
        "CashFlow",
        "StatementOfCashFlows",
        "CashFlowStatement",
        "ConsolidatedStatementsOfCashFlows",
    ],
    "equity": [
        "StockholdersEquity",
        "ChangesInEquity",
        "StatementOfStockholdersEquity",
        "ShareholdersEquity",
    ],
}

# ─── SEC EDGAR Configuration ─────────────────────────────────────────────────

SEC_EDGAR_BASE = "https://data.sec.gov"
SEC_EDGAR_SUBMISSIONS = f"{SEC_EDGAR_BASE}/submissions/CIK{{cik}}.json"
SEC_EDGAR_COMPANY_FACTS = f"{SEC_EDGAR_BASE}/api/xbrl/companyfacts/CIK{{cik}}.json"
SEC_EDGAR_COMPANY_CONCEPT = (
    f"{SEC_EDGAR_BASE}/api/xbrl/companyconcept/CIK{{cik}}/{{taxonomy}}/{{concept}}.json"
)
SEC_EDGAR_FRAMES = f"{SEC_EDGAR_BASE}/api/xbrl/frames/{{taxonomy}}/{{concept}}/{{unit}}/{{period}}.json"
SEC_EDGAR_ARCHIVES = "https://www.sec.gov/Archives/edgar/data/{cik}/{accession}/"

# Required by SEC — 10 requests/sec max, must identify caller
# SEC format: "CompanyOrAppName AdminEmail@domain.com"
SEC_EDGAR_USER_AGENT = "arelle-mcp arelle.mcp.server@gmail.com"
SEC_EDGAR_RATE_LIMIT = 10  # requests per second

# ─── Calculation Modes ────────────────────────────────────────────────────────

CALC_MODES: dict[str, str] = {
    "none": "none",
    "xbrl21": "xbrl21",
    "round-to-nearest": "round-to-nearest",
    "truncation": "truncation",
    "xbrl-2.1": "xbrl21",
    "10d": "round-to-nearest",
}

# ─── Filing Cache ─────────────────────────────────────────────────────────────

DEFAULT_MAX_CACHED_FILINGS = 5
DEFAULT_CACHE_DIR = ".arelle-mcp-cache"

# ─── Common US-GAAP Concepts ─────────────────────────────────────────────────
# Frequently queried concepts for quick lookup hints.

COMMON_CONCEPTS: list[str] = [
    "Assets",
    "Liabilities",
    "StockholdersEquity",
    "Revenues",
    "CostOfGoodsSold",
    "GrossProfit",
    "OperatingIncomeLoss",
    "NetIncomeLoss",
    "EarningsPerShareBasic",
    "EarningsPerShareDiluted",
    "CashAndCashEquivalentsAtCarryingValue",
    "AccountsReceivableNetCurrent",
    "InventoryNet",
    "PropertyPlantAndEquipmentNet",
    "LongTermDebt",
    "CommonStockSharesOutstanding",
    "OperatingCashFlow",
    "CapitalExpenditures",
]
