"""
MCP Resources for arelle-mcp.

Provides read-only reference data about XBRL taxonomies,
disclosure systems, and common concepts.
"""

from __future__ import annotations

import json
from typing import Any

from arelle_mcp.constants import (
    CALC_MODES,
    COMMON_CONCEPTS,
    DISCLOSURE_SYSTEMS,
    STATEMENT_ROLE_PATTERNS,
)


def register_resources(mcp: Any) -> None:
    """Register MCP resources."""

    @mcp.resource("xbrl://reference/disclosure-systems")
    def get_disclosure_systems() -> str:
        """Available disclosure systems for XBRL validation.

        Lists all supported validation rulesets: SEC EFM, EU ESEF,
        UK HMRC, and generic GFM.
        """
        systems = {
            name: {
                "arelle_name": arelle_name,
                "description": _ds_description(name),
            }
            for name, arelle_name in DISCLOSURE_SYSTEMS.items()
        }
        return json.dumps(systems, indent=2)

    @mcp.resource("xbrl://reference/common-concepts")
    def get_common_concepts() -> str:
        """Frequently used US-GAAP XBRL concepts.

        A curated list of the most commonly queried financial
        statement concepts for quick reference.
        """
        return json.dumps({
            "taxonomy": "us-gaap",
            "concepts": COMMON_CONCEPTS,
            "note": "Use xbrl_extract_facts or xbrl_fact_details with these concept names.",
        }, indent=2)

    @mcp.resource("xbrl://reference/statement-types")
    def get_statement_types() -> str:
        """Financial statement types and their role pattern keywords.

        Maps statement types (balance_sheet, income_statement, etc.)
        to the keywords used to match presentation link roles.
        """
        return json.dumps(STATEMENT_ROLE_PATTERNS, indent=2)

    @mcp.resource("xbrl://reference/calculation-modes")
    def get_calculation_modes() -> str:
        """Available calculation checking modes for validation."""
        return json.dumps({
            name: {
                "arelle_value": value,
                "description": _calc_description(name),
            }
            for name, value in CALC_MODES.items()
        }, indent=2)

    @mcp.resource("xbrl://reference/xbrl-primer")
    def get_xbrl_primer() -> str:
        """Brief XBRL primer for LLMs.

        Explains key XBRL concepts: facts, contexts, units,
        taxonomies, linkbases, and dimensions.
        """
        return json.dumps({
            "what_is_xbrl": (
                "XBRL (eXtensible Business Reporting Language) is the global standard "
                "for machine-readable business reporting. Every SEC filing since 2009 "
                "includes XBRL data."
            ),
            "key_concepts": {
                "fact": "A single data point (e.g., Revenue = $274B) with concept, context, and value.",
                "concept": "A taxonomy element defining what is reported (e.g., us-gaap:Revenues).",
                "context": "Metadata defining WHO (entity), WHEN (period), and dimensional breakdowns.",
                "unit": "Measurement unit for numeric facts (USD, shares, pure ratio).",
                "taxonomy": "Dictionary of reportable concepts (us-gaap, dei, srt, ifrs).",
                "linkbase": "Relationships between concepts: presentation (display), calculation (math), definition (semantic).",
                "dimension": "Multi-dimensional breakdown axes (e.g., by segment, geography, product).",
                "inline_xbrl": "iXBRL embeds XBRL tags in HTML — human-readable AND machine-parseable.",
            },
            "workflow_hint": (
                "Typical workflow: xbrl_load_filing → xbrl_extract_facts / xbrl_validate / "
                "xbrl_presentation_tree → xbrl_render_statement"
            ),
        }, indent=2)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _ds_description(name: str) -> str:
    descs = {
        "efm": "SEC Electronic Filing Manual (pragmatic mode, all years)",
        "efm-strict": "SEC EFM strict mode — full compliance checking",
        "efm-pragmatic": "SEC EFM pragmatic mode (recommended for analysis)",
        "esef": "European Single Electronic Format (EU/ESMA)",
        "hmrc": "UK HM Revenue & Customs",
        "gfm": "Global Filing Manual (generic international)",
    }
    return descs.get(name, name)


def _calc_description(name: str) -> str:
    descs = {
        "none": "No calculation checking",
        "xbrl21": "Standard XBRL 2.1 calculation validation",
        "round-to-nearest": "XBRL calculation with round-to-nearest rounding (10-decimal)",
        "truncation": "XBRL calculation with truncation rounding",
    }
    return descs.get(name, name)
