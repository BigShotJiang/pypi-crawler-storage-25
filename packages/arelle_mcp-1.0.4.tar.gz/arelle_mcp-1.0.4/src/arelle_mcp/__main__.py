"""Allow running as: python -m arelle_mcp"""

from arelle_mcp.server import main

main()
