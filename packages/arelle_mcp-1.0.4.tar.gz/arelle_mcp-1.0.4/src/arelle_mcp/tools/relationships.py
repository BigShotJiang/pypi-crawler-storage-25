"""
Relationship traversal tools: presentation trees, calculation hierarchies, dimensions.
"""

from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import Context
from pydantic import BaseModel, ConfigDict, Field

from arelle_mcp.arelle_wrapper import ArelleManager
from arelle_mcp.serializers import (
    serialize_calculation_tree,
    serialize_dimension_structure,
    serialize_presentation_tree,
)


class PresentationTreeInput(BaseModel):
    """Input for getting presentation hierarchy."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    role_filter: str | None = Field(
        default=None,
        description=(
            "Filter to a specific role/statement. Substring match on role URI or definition. "
            "Examples: 'BalanceSheet', 'IncomeStatement', 'CashFlow', 'StockholdersEquity'"
        ),
    )
    max_depth: int = Field(
        default=3,
        description="Maximum tree depth (1-20, default 3 to control output size)",
        ge=1, le=20,
    )
    list_roles_only: bool = Field(
        default=False,
        description="If true, return only the list of available roles (no tree data)",
    )


class CalculationTreeInput(BaseModel):
    """Input for getting calculation relationships."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    concept_name: str | None = Field(
        default=None,
        description="Filter to calculation trees containing this concept (substring match)",
    )
    role_filter: str | None = Field(
        default=None,
        description="Filter to a specific link role (substring match)",
    )


class DimensionStructureInput(BaseModel):
    """Input for getting dimensional structure."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    dimension_name: str | None = Field(
        default=None,
        description="Filter to a specific dimension axis (substring match, e.g., 'ProductOrService')",
    )
    max_members: int = Field(
        default=10,
        description="Max members per dimension (default 10)",
        ge=1, le=200,
    )


def register_relationship_tools(mcp: Any) -> None:
    """Register relationship traversal tools."""

    @mcp.tool(
        name="xbrl_presentation_tree",
        annotations={
            "title": "Get Presentation Tree",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_presentation_tree(params: PresentationTreeInput, ctx: Context) -> str:
        """Get the presentation hierarchy (financial statement structure).

        The presentation linkbase defines how concepts are organized for
        display — each extended link role typically represents one financial
        statement (Balance Sheet, Income Statement, Cash Flow, etc.).

        Use role_filter to get a specific statement, or list_roles_only=true
        to see what statements are available.

        Args:
            params (PresentationTreeInput): Filing ID and filter options.

        Returns:
            str: JSON with hierarchical tree structure per role.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        from arelle_mcp.constants import ARCROLE_PARENT_CHILD

        # Get all roles with presentation relationships
        rel_set = model.relationshipSet(ARCROLE_PARENT_CHILD)
        roles_with_rels: dict[str, str] = {}
        for rel in rel_set.modelRelationships:
            if rel.linkrole not in roles_with_rels:
                role_types = model.roleTypes.get(rel.linkrole, [])
                role_label = role_types[0].definition if role_types else rel.linkrole
                roles_with_rels[rel.linkrole] = role_label

        if params.list_roles_only:
            roles_list = [
                {"role_uri": uri, "label": label}
                for uri, label in sorted(roles_with_rels.items(), key=lambda x: x[1])
            ]
            return json.dumps({
                "roles": roles_list,
                "count": len(roles_list),
            }, indent=2)

        # Filter roles
        target_roles = list(roles_with_rels.keys())
        if params.role_filter:
            rf = params.role_filter.lower()
            target_roles = [
                uri for uri, label in roles_with_rels.items()
                if rf in uri.lower() or rf in label.lower()
            ]

        if not target_roles:
            return json.dumps({
                "error": "NO_MATCHING_ROLES",
                "message": f"No presentation roles match '{params.role_filter}'",
                "available_roles": [
                    {"uri": u, "label": l}
                    for u, l in roles_with_rels.items()
                ],
            })

        trees = []
        for role in target_roles:
            tree = serialize_presentation_tree(model, role, params.max_depth)
            if tree["tree"]:
                trees.append(tree)

        return json.dumps({
            "trees": trees,
            "role_count": len(trees),
        }, indent=2, default=str)

    @mcp.tool(
        name="xbrl_calculation_tree",
        annotations={
            "title": "Get Calculation Tree",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_calculation_tree(params: CalculationTreeInput, ctx: Context) -> str:
        """Get calculation relationships showing how totals are computed.

        The calculation linkbase defines mathematical relationships between
        concepts — e.g., Assets = CurrentAssets + NoncurrentAssets.
        Each component has a weight (+1 or -1) indicating addition or subtraction.

        Args:
            params (CalculationTreeInput): Filing ID and filter options.

        Returns:
            str: JSON with calculation trees showing components and weights.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        # Find matching role if filtered
        linkrole = None
        if params.role_filter:
            rf = params.role_filter.lower()
            for role_uri in model.roleTypes:
                role_types = model.roleTypes.get(role_uri, [])
                label = role_types[0].definition if role_types else role_uri
                if rf in role_uri.lower() or rf in label.lower():
                    linkrole = role_uri
                    break

        trees = serialize_calculation_tree(
            model,
            linkrole=linkrole,
            root_concept_name=params.concept_name,
        )

        return json.dumps({
            "calculation_trees": trees,
            "role_count": len(trees),
        }, indent=2, default=str)

    @mcp.tool(
        name="xbrl_dimension_structure",
        annotations={
            "title": "Get Dimension Structure",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_dimension_structure(params: DimensionStructureInput, ctx: Context) -> str:
        """Get the dimensional structure of a filing.

        XBRL Dimensions enable multi-dimensional data breakdowns.
        Returns hypercubes, dimensions (axes), domains, and members.
        Example: Revenue broken down by ProductOrServiceAxis with
        members like SoftwareMember, HardwareMember.

        Args:
            params (DimensionStructureInput): Filing ID and optional dimension filter.

        Returns:
            str: JSON with dimensional hierarchy.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        dimensions = serialize_dimension_structure(
            model, dimension_filter=params.dimension_name,
            max_members=params.max_members,
        )

        # Dedup by dimension name (same dim can appear in multiple hypercubes)
        seen = set()
        unique_dims = []
        for d in dimensions:
            if d["dimension"] not in seen:
                seen.add(d["dimension"])
                unique_dims.append(d)
        dimensions = unique_dims[:20]  # Cap at 20 dimensions

        return json.dumps({
            "dimensions": dimensions,
            "dimension_count": len(dimensions),
            "total_before_dedup": len(seen),
        }, indent=2, default=str)
