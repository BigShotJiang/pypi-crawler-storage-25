"""
Financial statement rendering tool.

Reconstructs human-readable financial statements from XBRL data
using the presentation linkbase structure.
"""

from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import Context
from pydantic import BaseModel, ConfigDict, Field

from arelle_mcp.arelle_wrapper import ArelleManager
from arelle_mcp.serializers import render_statement


class RenderStatementInput(BaseModel):
    """Input for rendering financial statements."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    statement: str = Field(
        default="all",
        description=(
            "Which statement to render: "
            "'balance_sheet', 'income_statement', 'cash_flow', 'equity', 'all'. "
            "Default: 'all'"
        ),
    )
    format: str = Field(
        default="markdown",
        description="Output format: 'markdown' (human-readable) or 'json' (structured data)",
    )


def register_rendering_tools(mcp: Any) -> None:
    """Register rendering tools."""

    @mcp.tool(
        name="xbrl_render_statement",
        annotations={
            "title": "Render Financial Statement",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_render_statement(params: RenderStatementInput, ctx: Context) -> str:
        """Render financial statements from XBRL data.

        Reconstructs balance sheet, income statement, cash flow statement,
        or equity statement using the presentation linkbase hierarchy,
        filling in actual reported values from the instance document.

        Args:
            params (RenderStatementInput): Filing ID, statement type, and format.

        Returns:
            str: Financial statement in markdown or JSON format.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        await ctx.report_progress(0.2, message="Building financial statements...")
        statements = render_statement(
            model,
            statement_type=params.statement if params.statement != "all" else None,
        )

        if not statements:
            return json.dumps({
                "error": "NO_STATEMENTS_FOUND",
                "message": (
                    f"No {params.statement} statements found in the presentation linkbase. "
                    "Try statement='all' to see all available roles, or use "
                    "xbrl_presentation_tree with list_roles_only=true."
                ),
            })

        if params.format == "markdown":
            md_parts = []
            for stmt in statements:
                md_parts.append(_statement_to_markdown(stmt))
            return "\n\n---\n\n".join(md_parts)
        else:
            return json.dumps({
                "statements": statements,
                "count": len(statements),
            }, indent=2, default=str)


# ─── Markdown Rendering ──────────────────────────────────────────────────────

def _statement_to_markdown(stmt: dict[str, Any]) -> str:
    """Convert a rendered statement to markdown format."""
    lines = []
    title = stmt.get("title", stmt.get("statement_type", "Financial Statement"))
    lines.append(f"## {title}")
    lines.append("")

    rows = stmt.get("rows", [])
    if not rows:
        lines.append("*No data available*")
        return "\n".join(lines)

    # Collect all period columns
    all_periods: set[str] = set()
    for row in rows:
        values = row.get("values", {})
        all_periods.update(values.keys())

    periods = sorted(all_periods, reverse=True)[:4]  # Show up to 4 most recent

    if periods:
        # Header
        header = "| Item |"
        separator = "|------|"
        for p in periods:
            header += f" {p} |"
            separator += "------|"
        lines.append(header)
        lines.append(separator)

        # Rows
        for row in rows:
            indent = "  " * row.get("indent", 0)
            label = row.get("label", "")
            is_abstract = row.get("abstract", False)

            if is_abstract:
                display_label = f"**{indent}{label}**"
            else:
                display_label = f"{indent}{label}"

            row_str = f"| {display_label} |"
            for p in periods:
                val = row.get("values", {}).get(p, "")
                if val:
                    row_str += f" {_format_value(val)} |"
                else:
                    row_str += " |"
            lines.append(row_str)
    else:
        # No values, just show structure
        for row in rows:
            indent = "  " * row.get("indent", 0)
            label = row.get("label", "")
            prefix = "**" if row.get("abstract", False) else ""
            suffix = "**" if row.get("abstract", False) else ""
            lines.append(f"- {indent}{prefix}{label}{suffix}")

    return "\n".join(lines)


def _format_value(val: str) -> str:
    """Format a numeric value for display."""
    try:
        num = float(val.replace(",", ""))
        if abs(num) >= 1_000_000_000:
            return f"{num / 1_000_000_000:,.1f}B"
        elif abs(num) >= 1_000_000:
            return f"{num / 1_000_000:,.1f}M"
        elif abs(num) >= 1_000:
            return f"{num:,.0f}"
        else:
            return f"{num:,.2f}"
    except (ValueError, TypeError):
        return val
