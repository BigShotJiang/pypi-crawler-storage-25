"""
Taxonomy browsing and concept lookup tools.
"""

from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import Context
from pydantic import BaseModel, ConfigDict, Field

from arelle_mcp.arelle_wrapper import ArelleManager
from arelle_mcp.serializers import serialize_concept, serialize_concept_detailed


class BrowseTaxonomyInput(BaseModel):
    """Input for browsing taxonomy concepts."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    search: str | None = Field(
        default=None,
        description="Search string to filter concepts by name or label (case-insensitive)",
    )
    concept_type: str | None = Field(
        default=None,
        description=(
            "Filter by concept type: 'monetary', 'numeric', 'string', "
            "'dimension', 'hypercube', 'abstract', 'text', 'date', 'boolean'"
        ),
    )
    extensions_only: bool = Field(
        default=False,
        description="If true, show only company extension concepts (not standard taxonomy)",
    )
    with_facts_only: bool = Field(
        default=False,
        description="If true, show only concepts that have reported facts",
    )
    namespace: str | None = Field(
        default=None,
        description="Filter by namespace prefix (e.g., 'us-gaap', 'dei', 'aapl')",
    )
    offset: int = Field(default=0, ge=0)
    limit: int = Field(default=50, ge=1, le=200)


class ConceptDetailsInput(BaseModel):
    """Input for getting full concept details."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    concept_name: str = Field(
        ...,
        description=(
            "Concept name to look up. Can be local name (e.g., 'Assets') "
            "or full QName (e.g., 'us-gaap:Assets')"
        ),
    )


def register_taxonomy_tools(mcp: Any) -> None:
    """Register taxonomy browsing tools."""

    @mcp.tool(
        name="xbrl_browse_taxonomy",
        annotations={
            "title": "Browse Taxonomy Concepts",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_browse_taxonomy(params: BrowseTaxonomyInput, ctx: Context) -> str:
        """Search and browse concepts in the filing's taxonomy (DTS).

        The Discoverable Taxonomy Set includes all standard taxonomy
        concepts (us-gaap, dei, srt, ifrs) plus company extensions.
        Filter by name, type, namespace, or whether concepts have facts.

        Args:
            params (BrowseTaxonomyInput): Search and filter parameters.

        Returns:
            str: JSON with matching concepts and pagination info.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        # Collect all concepts, filtering out XBRL infrastructure by default
        concepts = list(model.qnameConcepts.values())

        # Remove internal XBRL plumbing (xl:, link:, xlink:, xbrli:, xbrldt:, etc.)
        _infra_prefixes = {"xl", "xlink", "link", "xbrli", "xbrldt", "xbrldi", "gen", "formula"}
        concepts = [
            c for c in concepts
            if not (c.qname and c.qname.prefix and c.qname.prefix in _infra_prefixes)
        ]

        # Apply filters
        if params.search:
            search_lower = params.search.lower()
            concepts = [
                c for c in concepts
                if search_lower in str(c.qname).lower()
                or search_lower in (
                    _safe_label(c) or ""
                ).lower()
            ]

        if params.concept_type:
            concepts = _filter_by_type(concepts, params.concept_type)

        if params.extensions_only:
            from arelle_mcp.serializers import _is_extension_concept
            concepts = [c for c in concepts if _is_extension_concept(c)]

        if params.with_facts_only:
            concepts = [
                c for c in concepts
                if c.qname in model.factsByQname and model.factsByQname[c.qname]
            ]

        if params.namespace:
            ns_lower = params.namespace.lower()
            concepts = [
                c for c in concepts
                if c.qname and c.qname.prefix and ns_lower in c.qname.prefix.lower()
            ]

        total = len(concepts)
        page = concepts[params.offset:params.offset + params.limit]

        serialized = [serialize_concept(c) for c in page]

        return json.dumps({
            "concepts": serialized,
            "total_count": total,
            "offset": params.offset,
            "limit": params.limit,
            "has_more": params.offset + params.limit < total,
        }, indent=2, default=str)

    @mcp.tool(
        name="xbrl_concept_details",
        annotations={
            "title": "Get Concept Details",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_concept_details(params: ConceptDetailsInput, ctx: Context) -> str:
        """Get full details for a taxonomy concept.

        Returns all labels (standard, terse, verbose, documentation),
        references to accounting standards, data type, period type,
        balance direction, substitution group, and sample reported facts.

        Args:
            params (ConceptDetailsInput): Filing ID and concept name.

        Returns:
            str: JSON with comprehensive concept information.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})

        # Find the concept by local name or full QName
        concept = None
        name = params.concept_name

        # Strip prefix if provided (e.g., "us-gaap:Assets" → "Assets")
        local_name = name.split(":")[-1] if ":" in name else name

        # 1. Try exact local name match
        matches = model.nameConcepts.get(local_name, [])
        if matches:
            # Prefer us-gaap namespace if multiple matches
            for m in matches:
                if m.qname and "us-gaap" in str(m.qname.namespaceURI or ""):
                    concept = m
                    break
            if concept is None:
                concept = matches[0]

        # 2. Try exact QName match (with prefix)
        if concept is None and ":" in name:
            for qn, c in model.qnameConcepts.items():
                if str(qn) == name:
                    concept = c
                    break

        # 3. Only then try substring (but prefer shorter/exact matches)
        if concept is None:
            candidates = [
                (qn, c) for qn, c in model.qnameConcepts.items()
                if local_name.lower() in str(qn).lower()
            ]
            # Sort by length (shorter = more likely exact match)
            candidates.sort(key=lambda x: len(str(x[0])))
            if candidates:
                concept = candidates[0][1]

        if concept is None:
            suggestions = [
                str(qn) for qn in model.qnameConcepts
                if local_name.lower() in str(qn).lower()
            ][:10]
            return json.dumps({
                "error": "CONCEPT_NOT_FOUND",
                "message": f"Concept '{name}' not found in taxonomy",
                "suggestions": suggestions,
            })

        result = serialize_concept_detailed(concept, model)
        return json.dumps(result, indent=2, default=str)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _safe_label(concept: Any) -> str | None:
    try:
        return concept.label(lang="en-US", fallbackToQname=False)
    except Exception:
        return None


def _filter_by_type(concepts: list[Any], type_filter: str) -> list[Any]:
    """Filter concepts by type category."""
    t = type_filter.lower()
    if t == "monetary":
        return [c for c in concepts if getattr(c, "isMonetary", False)]
    elif t in ("numeric", "number"):
        return [c for c in concepts if getattr(c, "isNumeric", False)]
    elif t == "dimension":
        return [c for c in concepts if getattr(c, "isDimensionItem", False)]
    elif t == "hypercube":
        return [c for c in concepts if getattr(c, "isHypercubeItem", False)]
    elif t == "abstract":
        return [c for c in concepts if getattr(c, "isAbstract", False)]
    elif t in ("string", "text"):
        return [c for c in concepts if getattr(c, "isTextBlock", False) or not getattr(c, "isNumeric", False)]
    elif t == "date":
        return [
            c for c in concepts
            if c.typeQname and "date" in str(c.typeQname).lower()
        ]
    elif t == "boolean":
        return [
            c for c in concepts
            if c.typeQname and "boolean" in str(c.typeQname).lower()
        ]
    return concepts
