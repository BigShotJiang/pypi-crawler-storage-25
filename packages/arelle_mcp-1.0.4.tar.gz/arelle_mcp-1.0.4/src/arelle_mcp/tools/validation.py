"""
Validation tool: validate XBRL/iXBRL filings against disclosure systems.
"""

from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import Context
from pydantic import BaseModel, ConfigDict, Field

from arelle_mcp.arelle_wrapper import ArelleManager
from arelle_mcp.constants import CALC_MODES, DISCLOSURE_SYSTEMS


class ValidateFilingInput(BaseModel):
    """Input for filing validation."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    file_path: str | None = Field(
        default=None,
        description="Path or URL to the XBRL/iXBRL filing to validate",
    )
    filing_id: str | None = Field(
        default=None,
        description="Or use a filing_id from a previously loaded filing",
    )
    disclosure_system: str = Field(
        default="efm",
        description=(
            "Disclosure system: 'efm' (SEC, default), 'efm-strict', "
            "'esef' (EU), 'hmrc' (UK), 'gfm', or 'none'"
        ),
    )
    check_calculations: str = Field(
        default="xbrl21",
        description="Calc mode: 'none', 'xbrl21' (default), 'round-to-nearest', 'truncation'",
    )
    check_utr: bool = Field(default=False, description="Validate units against UTR")
    plugins: str | None = Field(default=None, description="Pipe-separated plugins")
    taxonomy_packages: list[str] | None = Field(default=None, description="Taxonomy packages")


def register_validation_tools(mcp: Any) -> None:
    """Register validation tools."""

    @mcp.tool(
        name="xbrl_validate",
        annotations={
            "title": "Validate XBRL/iXBRL Filing",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    async def xbrl_validate(params: ValidateFilingInput, ctx: Context) -> str:
        """Validate an XBRL/iXBRL filing against a disclosure system.

        Returns structured validation results including errors, warnings,
        and informational messages. Supports SEC EFM, EU ESEF, UK HMRC,
        and generic XBRL validation.

        The filing does NOT need to be loaded first — this tool loads,
        validates, and closes in one operation.

        Args:
            params (ValidateFilingInput): Filing path and validation options.

        Returns:
            str: JSON with validation results (valid, error_count,
                 warning_count, errors, warnings).
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        # Resolve disclosure system alias
        ds = DISCLOSURE_SYSTEMS.get(
            params.disclosure_system, params.disclosure_system
        )
        calc_mode = CALC_MODES.get(
            params.check_calculations, params.check_calculations
        )

        # Resolve file_path from filing_id if needed
        file_path = params.file_path
        if not file_path and params.filing_id:
            try:
                info = manager.get_filing_info(params.filing_id)
                file_path = info.get("uri")
            except KeyError as e:
                return json.dumps({"error": "FILING_NOT_LOADED", "message": str(e)})
        if not file_path:
            return json.dumps({
                "error": "MISSING_INPUT",
                "message": "Provide either 'file_path' or 'filing_id'",
            })

        try:
            await ctx.report_progress(0.1, message=f"Validating against {ds}...")
            result = await manager.validate_filing(
                file_path=file_path,
                disclosure_system=ds if params.disclosure_system != "none" else "",
                calcs=calc_mode,
                check_utr=params.check_utr,
                plugins=params.plugins,
                packages=params.taxonomy_packages,
            )
            await ctx.report_progress(1.0, message="Validation complete")
            return json.dumps(result, indent=2, default=str)

        except Exception as e:
            return json.dumps({
                "error": "VALIDATION_FAILED",
                "message": str(e),
                "type": type(e).__name__,
                "suggestion": (
                    "Ensure the file path is correct and the filing is valid XBRL/iXBRL. "
                    "For SEC filings, try disclosure_system='efm'."
                ),
            })
