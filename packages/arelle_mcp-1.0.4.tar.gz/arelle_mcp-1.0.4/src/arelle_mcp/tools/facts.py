"""
Fact extraction and filtering tools.
"""

from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import Context
from pydantic import BaseModel, ConfigDict, Field

from arelle_mcp.arelle_wrapper import ArelleManager
from arelle_mcp.serializers import serialize_fact, serialize_fact_compact


class ExtractFactsInput(BaseModel):
    """Input for extracting facts from a loaded filing."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    concept: str | None = Field(
        default=None,
        description=(
            "Filter by concept name (case-insensitive substring match). "
            "Examples: 'Assets', 'Revenue', 'NetIncomeLoss', 'us-gaap:Assets'"
        ),
    )
    period_type: str | None = Field(
        default=None,
        description="Filter by period type: 'instant' or 'duration'",
    )
    dimension: str | None = Field(
        default=None,
        description="Filter facts that have this dimension (axis name, substring match)",
    )
    member: str | None = Field(
        default=None,
        description="Filter facts with this dimension member (substring match)",
    )
    unit: str | None = Field(
        default=None,
        description="Filter by unit (e.g., 'USD', 'shares', 'pure')",
    )
    numeric_only: bool = Field(
        default=False,
        description="If true, return only numeric facts (exclude text facts)",
    )
    exclude_dimensions: bool = Field(
        default=False,
        description="If true, return only default-dimension facts (no dimensional breakdowns)",
    )
    include_dimension_details: bool = Field(
        default=True,
        description="Include dimension details in output (set false for compact results)",
    )
    offset: int = Field(default=0, description="Pagination offset", ge=0)
    limit: int = Field(default=50, description="Max facts to return (1-200)", ge=1, le=200)


class FactDetailsInput(BaseModel):
    """Input for getting full details on a specific fact."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(..., description="The filing_id from xbrl_load_filing")
    concept_name: str = Field(
        ...,
        description="Exact concept local name (e.g., 'Assets', 'NetIncomeLoss')",
    )
    period: str | None = Field(
        default=None,
        description="Optional period filter (date string like '2024-09-28')",
    )


def register_facts_tools(mcp: Any) -> None:
    """Register fact extraction tools."""

    @mcp.tool(
        name="xbrl_extract_facts",
        annotations={
            "title": "Extract XBRL Facts",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_extract_facts(params: ExtractFactsInput, ctx: Context) -> str:
        """Extract and filter XBRL facts from a loaded filing.

        Supports filtering by concept name, period type, dimensions,
        units, and more. Returns paginated results with full fact details
        including values, contexts, periods, and dimensional breakdowns.

        The filing must be loaded first with xbrl_load_filing.

        Args:
            params (ExtractFactsInput): Filtering and pagination parameters.

        Returns:
            str: JSON with filtered facts, total count, and pagination info.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({
                "error": "FILING_NOT_LOADED",
                "message": str(e),
                "suggestion": "Call xbrl_load_filing first.",
            })

        # Start with all facts
        facts = list(model.facts)

        # Apply filters
        if params.concept:
            search = params.concept.lower()
            facts = [
                f for f in facts
                if f.qname and search in str(f.qname).lower()
            ]

        if params.period_type:
            pt = params.period_type.lower()
            if pt == "instant":
                facts = [f for f in facts if f.context and f.context.isInstantPeriod]
            elif pt == "duration":
                facts = [f for f in facts if f.context and f.context.isStartEndPeriod]

        if params.numeric_only:
            facts = [f for f in facts if f.isNumeric]

        if params.unit:
            unit_search = params.unit.lower()
            facts = [
                f for f in facts
                if f.unit and f.unit.measures and f.unit.measures[0]
                and unit_search in str(f.unit.measures[0][0]).lower()
            ]

        if params.exclude_dimensions:
            facts = [
                f for f in facts
                if f.context is None or len(f.context.qnameDims) == 0
            ]

        if params.dimension:
            dim_search = params.dimension.lower()
            facts = [
                f for f in facts
                if f.context and f.context.qnameDims
                and any(dim_search in str(dq).lower() for dq in f.context.qnameDims)
            ]

        if params.member:
            mem_search = params.member.lower()
            facts = [
                f for f in facts
                if f.context and f.context.qnameDims
                and any(
                    dv.isExplicit and dv.memberQname
                    and mem_search in str(dv.memberQname).lower()
                    for dv in f.context.qnameDims.values()
                )
            ]

        total = len(facts)
        page = facts[params.offset:params.offset + params.limit]

        # Use compact or full serialization
        if params.include_dimension_details:
            serialized = [serialize_fact(f, include_dimensions=True) for f in page]
        else:
            serialized = [serialize_fact_compact(f) for f in page]

        return json.dumps({
            "facts": serialized,
            "total_count": total,
            "offset": params.offset,
            "limit": params.limit,
            "has_more": params.offset + params.limit < total,
            "next_offset": params.offset + params.limit if params.offset + params.limit < total else None,
        }, indent=2, default=str)

    @mcp.tool(
        name="xbrl_fact_details",
        annotations={
            "title": "Get Fact Details",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_fact_details(params: FactDetailsInput, ctx: Context) -> str:
        """Get comprehensive details for all facts of a specific concept.

        Returns every reported value for the concept across all periods
        and dimensions, plus the concept's taxonomy definition with
        labels, data type, and balance direction.

        Args:
            params (FactDetailsInput): Filing ID and concept name.

        Returns:
            str: JSON with concept definition and all reported facts.
        """
        from arelle_mcp.serializers import serialize_concept_detailed

        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model = manager.get_model(params.filing_id)
        except KeyError as e:
            return json.dumps({
                "error": "FILING_NOT_LOADED",
                "message": str(e),
            })

        # Find the concept — strip prefix if provided (e.g., "us-gaap:Assets" → "Assets")
        local_name = params.concept_name.split(":")[-1] if ":" in params.concept_name else params.concept_name
        matching_facts = list(model.factsByLocalName.get(local_name, set()))
        if not matching_facts:
            # Try broader search
            all_names = list(model.factsByLocalName.keys())
            suggestions = [
                n for n in all_names
                if local_name.lower() in n.lower()
            ][:10]
            return json.dumps({
                "error": "CONCEPT_NOT_FOUND",
                "message": f"No facts found for concept '{params.concept_name}'",
                "suggestions": suggestions,
                "hint": "Use xbrl_extract_facts with a broader search to find available concepts.",
            })

        # Get concept definition
        concept_obj = matching_facts[0].concept
        concept_detail = serialize_concept_detailed(concept_obj, model)

        # Get all facts, optionally filtered by period
        facts = matching_facts
        if params.period:
            facts = [
                f for f in facts
                if f.context and params.period in str(
                    getattr(f.context, 'instantDatetime', '') or
                    getattr(f.context, 'endDatetime', '')
                )
            ]

        serialized_facts = [serialize_fact(f, include_dimensions=True) for f in facts[:20]]

        return json.dumps({
            "concept": concept_detail,
            "facts": serialized_facts,
            "fact_count": len(serialized_facts),
        }, indent=2, default=str)
