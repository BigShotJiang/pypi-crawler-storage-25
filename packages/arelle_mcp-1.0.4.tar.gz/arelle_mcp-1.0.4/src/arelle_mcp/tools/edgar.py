"""
SEC EDGAR integration tools.

Uses SEC EDGAR's free XBRL API (no authentication required).
Rate limit: 10 requests/sec. User-Agent header required.
"""

from __future__ import annotations

import json
from typing import Any

import httpx
from mcp.server.fastmcp import Context
from pydantic import BaseModel, ConfigDict, Field, field_validator

from arelle_mcp.constants import (
    SEC_EDGAR_COMPANY_CONCEPT,
    SEC_EDGAR_COMPANY_FACTS,
    SEC_EDGAR_SUBMISSIONS,
    SEC_EDGAR_USER_AGENT,
)

# ─── Input Models ─────────────────────────────────────────────────────────────

class FetchSecFilingInput(BaseModel):
    """Input for fetching an SEC EDGAR filing."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    cik: str | None = Field(
        default=None,
        description="SEC CIK number (e.g., '320193' for Apple). Will be zero-padded to 10 digits.",
    )
    ticker: str | None = Field(
        default=None,
        description="Stock ticker symbol (e.g., 'AAPL'). Used to look up CIK if cik not provided.",
    )
    filing_type: str = Field(
        default="10-K",
        description="SEC filing type: '10-K', '10-Q', '8-K', '20-F', 'S-1', etc.",
    )
    date: str | None = Field(
        default=None,
        description="Find filing nearest to this date (YYYY-MM-DD). Default: latest filing.",
    )
    load_filing: bool = Field(
        default=True,
        description="If true, automatically load the filing for analysis with other tools",
    )

    @field_validator("cik")
    @classmethod
    def validate_cik(cls, v: str | None) -> str | None:
        if v is not None:
            v = v.strip().lstrip("0")
            if not v.isdigit():
                raise ValueError("CIK must be numeric")
        return v

    @field_validator("ticker")
    @classmethod
    def validate_ticker(cls, v: str | None) -> str | None:
        if v is not None:
            return v.upper().strip()
        return v


class SearchSecConceptInput(BaseModel):
    """Input for searching SEC EDGAR XBRL concepts."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    cik: str = Field(
        ...,
        description="SEC CIK number for the company",
    )
    concept: str = Field(
        ...,
        description="XBRL concept name (e.g., 'Assets', 'Revenues', 'NetIncomeLoss')",
    )
    taxonomy: str = Field(
        default="us-gaap",
        description="Taxonomy namespace: 'us-gaap' (default), 'dei', 'srt', 'ifrs-full'",
    )


class CompanyFactsInput(BaseModel):
    """Input for getting all XBRL facts for a company."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    cik: str = Field(..., description="SEC CIK number")
    concept_filter: str | None = Field(
        default=None,
        description="Optional: filter to facts matching this concept name (substring)",
    )
    limit: int = Field(default=50, ge=1, le=500)


# ─── SEC API Client ──────────────────────────────────────────────────────────

async def _sec_get(url: str) -> dict[str, Any]:
    """Make a GET request to SEC EDGAR API with required headers.

    SEC EDGAR requires a descriptive User-Agent header and returns 403
    without one. The format must be: 'CompanyOrApp email@domain.com'
    """
    async with httpx.AsyncClient(
        headers={
            "User-Agent": SEC_EDGAR_USER_AGENT,
            "Accept": "application/json",
            "Accept-Encoding": "gzip, deflate",
        },
        timeout=30.0,
        follow_redirects=True,
    ) as client:
        response = await client.get(url)
        response.raise_for_status()
        return response.json()


def _pad_cik(cik: str) -> str:
    """Zero-pad CIK to 10 digits as SEC requires."""
    return cik.zfill(10)


async def _resolve_ticker_to_cik(ticker: str) -> str | None:
    """Resolve a ticker symbol to CIK using SEC's company tickers endpoint."""
    try:
        url = "https://www.sec.gov/files/company_tickers.json"
        data = await _sec_get(url)
        ticker_upper = ticker.upper()
        for entry in data.values():
            if entry.get("ticker", "").upper() == ticker_upper:
                return str(entry["cik_str"])
    except Exception:
        pass
    return None


# ─── Tool Registration ───────────────────────────────────────────────────────

def register_edgar_tools(mcp: Any) -> None:
    """Register SEC EDGAR tools."""

    @mcp.tool(
        name="xbrl_fetch_sec_filing",
        annotations={
            "title": "Fetch SEC EDGAR Filing",
            "readOnlyHint": False,
            "destructiveHint": False,
            "idempotentHint": False,
            "openWorldHint": True,
        },
    )
    async def xbrl_fetch_sec_filing(params: FetchSecFilingInput, ctx: Context) -> str:
        """Fetch an SEC EDGAR filing by CIK or ticker symbol.

        Finds the specified filing type (10-K, 10-Q, etc.) from SEC EDGAR,
        returns filing metadata, and optionally loads it for analysis.

        Either cik or ticker must be provided. If ticker is provided,
        it will be resolved to a CIK automatically.

        Args:
            params (FetchSecFilingInput): CIK/ticker and filing type.

        Returns:
            str: JSON with filing metadata and optionally a filing_id.
        """
        from arelle_mcp.arelle_wrapper import ArelleManager

        manager: ArelleManager = ctx.request_context.lifespan_context

        # Resolve CIK
        cik = params.cik
        if not cik and params.ticker:
            await ctx.report_progress(0.1, message=f"Resolving ticker {params.ticker}...")
            cik = await _resolve_ticker_to_cik(params.ticker)
            if not cik:
                return json.dumps({
                    "error": "TICKER_NOT_FOUND",
                    "message": f"Could not resolve ticker '{params.ticker}' to a CIK",
                    "suggestion": "Try providing the CIK directly.",
                })

        if not cik:
            return json.dumps({
                "error": "MISSING_IDENTIFIER",
                "message": "Provide either 'cik' or 'ticker'",
            })

        padded_cik = _pad_cik(cik)
        await ctx.report_progress(0.2, message=f"Fetching submissions for CIK {padded_cik}...")

        try:
            # Get company submissions
            url = SEC_EDGAR_SUBMISSIONS.format(cik=padded_cik)
            submissions = await _sec_get(url)
        except httpx.HTTPStatusError as e:
            return json.dumps({
                "error": "SEC_API_ERROR",
                "message": f"SEC EDGAR returned status {e.response.status_code}",
                "suggestion": "Verify the CIK is correct.",
            })
        except Exception as e:
            return json.dumps({
                "error": "NETWORK_ERROR",
                "message": str(e),
            })

        company_name = submissions.get("name", "Unknown")
        recent = submissions.get("filings", {}).get("recent", {})

        # Find matching filing
        forms = recent.get("form", [])
        accessions = recent.get("accessionNumber", [])
        dates = recent.get("filingDate", [])
        primary_docs = recent.get("primaryDocument", [])

        filing_type_upper = params.filing_type.upper()
        matches = []
        for i, form in enumerate(forms):
            if form.upper() == filing_type_upper:
                matches.append({
                    "index": i,
                    "form": form,
                    "accession": accessions[i] if i < len(accessions) else None,
                    "date": dates[i] if i < len(dates) else None,
                    "primary_doc": primary_docs[i] if i < len(primary_docs) else None,
                })

        if not matches:
            available_types = list(set(forms[:50]))
            return json.dumps({
                "error": "FILING_TYPE_NOT_FOUND",
                "message": f"No '{params.filing_type}' filings found for {company_name}",
                "available_types": sorted(available_types),
            })

        # Select target filing
        target = matches[0]  # Latest by default
        if params.date:
            # Find nearest to requested date
            target = min(
                matches,
                key=lambda m: abs(
                    _date_diff(m.get("date", ""), params.date)
                ),
            )

        # Build filing URL
        accession_clean = target["accession"].replace("-", "")
        filing_url = (
            f"https://www.sec.gov/Archives/edgar/data/{cik}/{accession_clean}/"
            f"{target['primary_doc']}"
        )

        result: dict[str, Any] = {
            "company_name": company_name,
            "cik": cik,
            "filing_type": target["form"],
            "filing_date": target["date"],
            "accession_number": target["accession"],
            "filing_url": filing_url,
        }

        # Optionally load the filing
        if params.load_filing:
            await ctx.report_progress(0.5, message="Loading filing into Arelle...")
            try:
                filing_id, summary = await manager.load_filing(filing_url)
                result["filing_id"] = filing_id
                result["filing_summary"] = summary
                await ctx.report_progress(1.0, message="Filing loaded")
            except Exception as e:
                result["load_error"] = str(e)
                result["suggestion"] = "Filing metadata was retrieved but loading failed. Try loading manually."

        return json.dumps(result, indent=2, default=str)

    @mcp.tool(
        name="xbrl_search_sec_concept",
        annotations={
            "title": "Search SEC XBRL Concept History",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    async def xbrl_search_sec_concept(params: SearchSecConceptInput, ctx: Context) -> str:
        """Search SEC EDGAR for a specific XBRL concept across all filings.

        Returns historical values for a concept (e.g., Assets, Revenue)
        across all available filing periods. Uses SEC's companyconcept API.
        Does NOT require loading a filing first.

        Args:
            params (SearchSecConceptInput): CIK, concept name, and taxonomy.

        Returns:
            str: JSON with historical values, periods, and units.
        """
        padded_cik = _pad_cik(params.cik)
        url = SEC_EDGAR_COMPANY_CONCEPT.format(
            cik=padded_cik,
            taxonomy=params.taxonomy,
            concept=params.concept,
        )

        try:
            data = await _sec_get(url)
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                return json.dumps({
                    "error": "CONCEPT_NOT_FOUND",
                    "message": (
                        f"Concept '{params.taxonomy}:{params.concept}' not found "
                        f"for CIK {params.cik}"
                    ),
                    "suggestion": (
                        "Check concept name spelling. Common concepts: "
                        "Assets, Revenues, NetIncomeLoss, CashAndCashEquivalentsAtCarryingValue"
                    ),
                })
            return json.dumps({"error": "SEC_API_ERROR", "message": str(e)})
        except Exception as e:
            return json.dumps({"error": "NETWORK_ERROR", "message": str(e)})

        # Extract and format results
        entity = data.get("entityName", "Unknown")
        units_data = data.get("units", {})

        result: dict[str, Any] = {
            "entity_name": entity,
            "cik": params.cik,
            "concept": f"{params.taxonomy}:{params.concept}",
            "label": data.get("label", params.concept),
            "description": data.get("description", ""),
        }

        # Format values by unit
        all_values = []
        for unit_key, entries in units_data.items():
            for entry in entries:
                all_values.append({
                    "value": entry.get("val"),
                    "unit": unit_key,
                    "period_end": entry.get("end"),
                    "period_start": entry.get("start"),
                    "form": entry.get("form"),
                    "filed": entry.get("filed"),
                    "accession": entry.get("accn"),
                    "fiscal_year": entry.get("fy"),
                    "fiscal_period": entry.get("fp"),
                })

        # Sort by period end date descending
        all_values.sort(key=lambda x: x.get("period_end", ""), reverse=True)

        result["values"] = all_values[:100]  # Cap at 100
        result["total_observations"] = len(all_values)

        return json.dumps(result, indent=2, default=str)

    @mcp.tool(
        name="xbrl_company_facts",
        annotations={
            "title": "Get All Company XBRL Facts",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": True,
        },
    )
    async def xbrl_company_facts(params: CompanyFactsInput, ctx: Context) -> str:
        """Get all available XBRL facts for a company from SEC EDGAR.

        Returns a summary of all concepts reported by the company
        across all filings, organized by taxonomy. Does NOT require
        loading a filing first.

        Args:
            params (CompanyFactsInput): CIK and optional concept filter.

        Returns:
            str: JSON with available concepts, their observation counts, and units.
        """
        padded_cik = _pad_cik(params.cik)
        url = SEC_EDGAR_COMPANY_FACTS.format(cik=padded_cik)

        try:
            data = await _sec_get(url)
        except httpx.HTTPStatusError as e:
            return json.dumps({"error": "SEC_API_ERROR", "message": str(e)})
        except Exception as e:
            return json.dumps({"error": "NETWORK_ERROR", "message": str(e)})

        entity = data.get("entityName", "Unknown")
        facts_data = data.get("facts", {})

        concepts: list[dict[str, Any]] = []
        for taxonomy, tax_concepts in facts_data.items():
            for concept_name, concept_data in tax_concepts.items():
                if params.concept_filter:
                    if params.concept_filter.lower() not in concept_name.lower():
                        continue

                label = concept_data.get("label", concept_name)
                description = concept_data.get("description", "")
                units_info = concept_data.get("units", {})

                total_obs = sum(len(entries) for entries in units_info.values())
                unit_types = list(units_info.keys())

                concepts.append({
                    "taxonomy": taxonomy,
                    "concept": concept_name,
                    "label": label,
                    "description": description[:200],
                    "units": unit_types,
                    "observation_count": total_obs,
                })

        # Sort by observation count
        concepts.sort(key=lambda x: x["observation_count"], reverse=True)

        return json.dumps({
            "entity_name": entity,
            "cik": params.cik,
            "concepts": concepts[:params.limit],
            "total_concepts": len(concepts),
        }, indent=2, default=str)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _date_diff(date1: str, date2: str) -> int:
    """Simple date difference in days (approximate)."""
    try:
        from datetime import datetime
        d1 = datetime.strptime(date1[:10], "%Y-%m-%d")
        d2 = datetime.strptime(date2[:10], "%Y-%m-%d")
        return abs((d1 - d2).days)
    except Exception:
        return 999999
