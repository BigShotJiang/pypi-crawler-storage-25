"""Tool modules for arelle-mcp. Each module registers tools on the server."""
