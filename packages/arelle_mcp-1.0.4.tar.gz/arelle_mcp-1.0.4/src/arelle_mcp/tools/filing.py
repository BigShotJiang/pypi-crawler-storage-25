"""
Filing operations: load, summarize, compare, and manage XBRL filings.
"""

from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import Context
from pydantic import BaseModel, ConfigDict, Field

from arelle_mcp.arelle_wrapper import ArelleManager

# ─── Pydantic Input Models ───────────────────────────────────────────────────

class LoadFilingInput(BaseModel):
    """Input for loading an XBRL/iXBRL filing."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    file_path: str = Field(
        ...,
        description=(
            "Path or URL to the XBRL/iXBRL filing. Accepts: "
            "local file paths, HTTP/HTTPS URLs, SEC EDGAR filing URLs, "
            "ZIP archives containing XBRL. "
            "Examples: '/data/10-K.htm', "
            "'https://www.sec.gov/Archives/edgar/data/320193/000032019324000123/aapl-20240928.htm'"
        ),
        min_length=1,
    )
    taxonomy_packages: list[str] | None = Field(
        default=None,
        description="Optional taxonomy package ZIP paths for offline/custom taxonomies",
    )
    offline: bool = Field(
        default=False,
        description="If true, only use cached/local taxonomies (no internet)",
    )
    plugins: str | None = Field(
        default=None,
        description="Pipe-separated Arelle plugins to load (e.g. 'validate/EFM|inlineXbrlDocumentSet')",
    )


class FilingIdInput(BaseModel):
    """Input requiring only a filing_id."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id: str = Field(
        ...,
        description="The filing_id returned by xbrl_load_filing",
        min_length=1,
        max_length=20,
    )


class CompareFilingsInput(BaseModel):
    """Input for comparing two loaded filings."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    filing_id_1: str = Field(..., description="First filing's ID (baseline)")
    filing_id_2: str = Field(..., description="Second filing's ID (comparison)")


# ─── Tool Functions ──────────────────────────────────────────────────────────

def register_filing_tools(mcp: Any) -> None:
    """Register all filing tools on the MCP server."""

    @mcp.tool(
        name="xbrl_load_filing",
        annotations={
            "title": "Load XBRL/iXBRL Filing",
            "readOnlyHint": False,
            "destructiveHint": False,
            "idempotentHint": False,
            "openWorldHint": True,
        },
    )
    async def xbrl_load_filing(params: LoadFilingInput, ctx: Context) -> str:
        """Load an XBRL or iXBRL filing for analysis.

        Accepts local file paths, HTTP/HTTPS URLs (including SEC EDGAR),
        and ZIP archives. Returns a filing_id for use with all other tools,
        plus a summary with entity name, document type, period, and fact counts.

        This is the entry point — call this first before using any other tool.

        Args:
            params (LoadFilingInput): Filing path/URL and options.

        Returns:
            str: JSON with filing_id and filing summary.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            await ctx.report_progress(0.1, message="Initializing Arelle session...")
            filing_id, summary = await manager.load_filing(
                file_path=params.file_path,
                packages=params.taxonomy_packages,
                offline=params.offline,
                plugins=params.plugins,
            )
            summary["filing_id"] = filing_id
            await ctx.report_progress(1.0, message="Filing loaded successfully")
            return json.dumps(summary, indent=2, default=str)

        except ValueError as e:
            return json.dumps({
                "error": "LOAD_FAILED",
                "message": str(e),
                "suggestion": (
                    "Check that the file path or URL is correct. "
                    "For SEC filings, use the full URL to the .htm file."
                ),
            })
        except Exception as e:
            return json.dumps({
                "error": "UNEXPECTED_ERROR",
                "message": str(e),
                "type": type(e).__name__,
            })

    @mcp.tool(
        name="xbrl_filing_summary",
        annotations={
            "title": "Get Filing Summary",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_filing_summary(params: FilingIdInput, ctx: Context) -> str:
        """Get detailed metadata about a loaded filing.

        Returns entity name, CIK, document type, reporting period,
        fact/context/unit counts, namespaces used, and more.

        Args:
            params (FilingIdInput): The filing_id from xbrl_load_filing.

        Returns:
            str: JSON with comprehensive filing metadata.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            info = manager.get_filing_info(params.filing_id)
            return json.dumps(info, indent=2, default=str)
        except KeyError as e:
            return json.dumps({
                "error": "FILING_NOT_LOADED",
                "message": str(e),
                "available_filings": manager.list_loaded_filings(),
            })

    @mcp.tool(
        name="xbrl_compare_filings",
        annotations={
            "title": "Compare Two Filings",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_compare_filings(params: CompareFilingsInput, ctx: Context) -> str:
        """Compare two loaded XBRL filings.

        Identifies added, removed, and changed facts between two filings.
        Useful for analyzing changes between quarterly or annual reports.
        Both filings must be loaded first with xbrl_load_filing.

        Args:
            params (CompareFilingsInput): Two filing IDs to compare.

        Returns:
            str: JSON with added/removed/changed facts and counts.
        """
        from arelle_mcp.serializers import compare_filings

        manager: ArelleManager = ctx.request_context.lifespan_context

        try:
            model1 = manager.get_model(params.filing_id_1)
            model2 = manager.get_model(params.filing_id_2)
        except KeyError as e:
            return json.dumps({
                "error": "FILING_NOT_LOADED",
                "message": str(e),
                "available_filings": manager.list_loaded_filings(),
            })

        await ctx.report_progress(0.3, message="Comparing filings...")
        loop = __import__("asyncio").get_running_loop()
        result = await loop.run_in_executor(
            None, compare_filings, model1, model2
        )

        return json.dumps(result, indent=2, default=str)

    @mcp.tool(
        name="xbrl_close_filing",
        annotations={
            "title": "Close a Loaded Filing",
            "readOnlyHint": False,
            "destructiveHint": True,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_close_filing(params: FilingIdInput, ctx: Context) -> str:
        """Close a loaded filing and free its memory (30-60MB per filing).

        Args:
            params (FilingIdInput): The filing_id to close.

        Returns:
            str: Confirmation message.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context
        closed = await manager.close_filing(params.filing_id)
        if closed:
            return json.dumps({"status": "closed", "filing_id": params.filing_id})
        return json.dumps({
            "error": "FILING_NOT_FOUND",
            "message": f"No filing with ID '{params.filing_id}' is loaded.",
            "available_filings": manager.list_loaded_filings(),
        })

    @mcp.tool(
        name="xbrl_list_filings",
        annotations={
            "title": "List Loaded Filings",
            "readOnlyHint": True,
            "destructiveHint": False,
            "idempotentHint": True,
            "openWorldHint": False,
        },
    )
    async def xbrl_list_filings(ctx: Context) -> str:
        """List all currently loaded filings with their IDs and basic info.

        Returns:
            str: JSON array of loaded filing summaries.
        """
        manager: ArelleManager = ctx.request_context.lifespan_context
        filings = manager.list_loaded_filings()
        return json.dumps({"loaded_filings": filings, "count": len(filings)})
