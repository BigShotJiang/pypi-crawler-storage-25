"""
MCP Prompts for arelle-mcp.

Reusable prompt templates that guide LLMs through common
XBRL analysis workflows.
"""

from __future__ import annotations

from typing import Any


def register_prompts(mcp: Any) -> None:
    """Register MCP prompt templates."""

    @mcp.prompt()
    def analyze_filing(filing_source: str, analysis_depth: str = "standard") -> str:
        """Comprehensive XBRL filing analysis workflow.

        Guides the LLM through loading, validating, extracting key metrics,
        and rendering financial statements from an XBRL filing.

        Args:
            filing_source: Path or URL to the XBRL/iXBRL filing
            analysis_depth: 'quick' (key metrics only), 'standard' (full analysis),
                          or 'deep' (includes dimensions, extensions, calculations)
        """
        base = (
            f"Analyze the XBRL filing at: {filing_source}\n\n"
            "Follow this workflow:\n\n"
            "1. Load the filing with xbrl_load_filing\n"
            "2. Review the filing summary (entity, period, document type)\n"
            "3. Extract key financial metrics:\n"
            "   - Assets, Liabilities, StockholdersEquity (Balance Sheet)\n"
            "   - Revenues, NetIncomeLoss, EarningsPerShareBasic (Income Statement)\n"
            "   - Use xbrl_extract_facts with each concept name\n"
            "4. Render the main financial statements with xbrl_render_statement\n"
        )

        if analysis_depth in ("standard", "deep"):
            base += (
                "5. Validate the filing with xbrl_validate (disclosure_system='efm')\n"
                "6. Check the presentation tree for available statements\n"
                "7. Analyze calculation relationships for key totals\n"
            )

        if analysis_depth == "deep":
            base += (
                "8. Examine dimensional breakdowns (segments, geographies)\n"
                "9. Identify company extension concepts with xbrl_browse_taxonomy(extensions_only=true)\n"
                "10. Compare calculation trees to verify mathematical consistency\n"
            )

        base += (
            "\nPresent findings as a structured financial summary with:\n"
            "- Company overview (name, CIK, period, filing type)\n"
            "- Key financial metrics with values and periods\n"
            "- Notable observations or anomalies\n"
        )

        return base

    @mcp.prompt()
    def compare_periods(
        filing_url_1: str,
        filing_url_2: str,
    ) -> str:
        """Compare two filing periods (e.g., Q3 vs Q2, or YoY comparison).

        Args:
            filing_url_1: URL/path to the first (earlier) filing
            filing_url_2: URL/path to the second (later) filing
        """
        return (
            f"Compare these two XBRL filings:\n"
            f"- Filing 1 (baseline): {filing_url_1}\n"
            f"- Filing 2 (comparison): {filing_url_2}\n\n"
            "Workflow:\n"
            "1. Load both filings with xbrl_load_filing\n"
            "2. Compare them with xbrl_compare_filings\n"
            "3. For key metrics (Revenue, NetIncome, Assets, EPS), extract facts from both\n"
            "4. Calculate period-over-period changes (absolute and percentage)\n"
            "5. Identify newly added or removed line items\n"
            "6. Check for changes in dimensional breakdowns\n\n"
            "Present a comparison table showing:\n"
            "- Metric | Period 1 | Period 2 | Change | % Change\n"
            "- Highlight significant changes (>10%)\n"
            "- Note any structural changes in reporting\n"
        )

    @mcp.prompt()
    def sec_company_deep_dive(
        identifier: str,
        filing_type: str = "10-K",
    ) -> str:
        """Deep dive analysis of a public company's SEC filings.

        Args:
            identifier: Company ticker (e.g., 'AAPL') or CIK number
            filing_type: Filing type to analyze ('10-K' or '10-Q')
        """
        id_field = "ticker" if identifier.isalpha() else "cik"
        return (
            f"Perform a deep dive analysis of {identifier}'s latest {filing_type} filing.\n\n"
            "Workflow:\n"
            f"1. Fetch the latest {filing_type} with xbrl_fetch_sec_filing({id_field}='{identifier}')\n"
            "2. Review the filing summary\n"
            "3. Extract and analyze these key areas:\n\n"
            "   **Profitability:**\n"
            "   - Revenues, CostOfGoodsSold, GrossProfit\n"
            "   - OperatingIncomeLoss, NetIncomeLoss\n"
            "   - EarningsPerShareBasic, EarningsPerShareDiluted\n\n"
            "   **Balance Sheet Strength:**\n"
            "   - Assets, Liabilities, StockholdersEquity\n"
            "   - CashAndCashEquivalentsAtCarryingValue\n"
            "   - LongTermDebt, CurrentAssets, CurrentLiabilities\n\n"
            "   **Cash Flow:**\n"
            "   - NetCashProvidedByOperatingActivities\n"
            "   - PaymentsToAcquirePropertyPlantAndEquipment\n"
            "   - PaymentsForRepurchaseOfCommonStock\n\n"
            "4. Check dimensional breakdowns for segment reporting\n"
            "5. Render all financial statements with xbrl_render_statement\n"
            "6. Validate the filing\n\n"
            "Also use xbrl_search_sec_concept to get historical trends for:\n"
            "- Revenue growth (last 5 years)\n"
            "- Net income trajectory\n"
            "- Asset growth\n\n"
            "Present a comprehensive investment analysis report.\n"
        )

    @mcp.prompt()
    def validate_and_fix(filing_source: str) -> str:
        """Validate a filing and analyze all errors/warnings.

        Args:
            filing_source: Path or URL to the filing to validate
        """
        return (
            f"Validate the XBRL filing at: {filing_source}\n\n"
            "Workflow:\n"
            "1. Run xbrl_validate with disclosure_system='efm' and check_calculations='xbrl21'\n"
            "2. Review all errors — categorize by type:\n"
            "   - Schema validation errors\n"
            "   - Calculation inconsistencies\n"
            "   - EFM rule violations\n"
            "   - Reference/label issues\n"
            "3. For each error, explain:\n"
            "   - What the error means\n"
            "   - Why it matters\n"
            "   - How to fix it\n"
            "4. Load the filing and cross-reference errors with actual fact data\n"
            "5. Check calculation trees for the concepts with calculation errors\n\n"
            "Present a prioritized error report with actionable fixes.\n"
        )

    @mcp.prompt()
    def taxonomy_explorer(filing_source: str) -> str:
        """Explore a filing's taxonomy — standard and extension concepts.

        Args:
            filing_source: Path or URL to the filing
        """
        return (
            f"Explore the taxonomy of the XBRL filing at: {filing_source}\n\n"
            "Workflow:\n"
            "1. Load the filing\n"
            "2. Browse standard taxonomy concepts with xbrl_browse_taxonomy\n"
            "3. Find company extensions with extensions_only=true\n"
            "4. For interesting extensions, get full details with xbrl_concept_details\n"
            "5. Examine the dimensional structure with xbrl_dimension_structure\n"
            "6. Map out the presentation hierarchy with xbrl_presentation_tree\n"
            "7. Check calculation relationships with xbrl_calculation_tree\n\n"
            "Present:\n"
            "- Summary of taxonomy usage (standard vs extension concepts)\n"
            "- List of custom extensions with their definitions\n"
            "- Dimensional axes and their members\n"
            "- Financial statement structure overview\n"
        )
