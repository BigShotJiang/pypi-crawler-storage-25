"""
ArelleManager: the engine of arelle-mcp.

Solves Arelle's single-session constraint with an asyncio.Lock and
run_in_executor pattern. Manages an LRU cache of loaded filings.
All Arelle operations are synchronous and CPU-bound — this wrapper
safely bridges them into the async MCP world.
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any

from arelle_mcp.constants import DEFAULT_MAX_CACHED_FILINGS

logger = logging.getLogger("arelle_mcp")


@dataclass
class LoadedFiling:
    """A loaded XBRL filing with its model and session reference."""

    filing_id: str
    uri: str
    model_xbrl: Any  # arelle.ModelXbrl.ModelXbrl — typed as Any to avoid import at class level
    session: Any  # arelle.api.Session.Session
    metadata: dict[str, Any] = field(default_factory=dict)


class ArelleManager:
    """Thread-safe manager for Arelle sessions.

    Core design:
    - asyncio.Lock serializes ALL Arelle operations (Arelle is not thread-safe)
    - run_in_executor offloads CPU-bound Arelle work to a thread pool
    - OrderedDict implements LRU eviction for the filing cache
    - Explicit model.close() on eviction frees 30-60MB per filing
    """

    def __init__(
        self,
        max_cached_filings: int = DEFAULT_MAX_CACHED_FILINGS,
        cache_dir: str | None = None,
    ) -> None:
        self._lock = asyncio.Lock()
        self._filings: OrderedDict[str, LoadedFiling] = OrderedDict()
        self._max_cached_filings = max_cached_filings
        self._cache_dir = cache_dir
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="arelle")
        logger.info(
            "ArelleManager initialized: max_cached=%d, cache_dir=%s",
            max_cached_filings,
            cache_dir,
        )

    # ─── Filing Operations ────────────────────────────────────────────────

    async def load_filing(
        self,
        file_path: str,
        packages: list[str] | None = None,
        offline: bool = False,
        plugins: str | None = None,
    ) -> tuple[str, dict[str, Any]]:
        """Load an XBRL/iXBRL filing and return (filing_id, summary).

        Supports: local files, URLs, SEC EDGAR URLs, ZIP archives.
        The filing is cached for subsequent tool calls.
        """
        async with self._lock:
            # Evict oldest if at capacity
            while len(self._filings) >= self._max_cached_filings:
                oldest_id = next(iter(self._filings))
                loop = asyncio.get_running_loop()
                await loop.run_in_executor(
                    self._executor, self._close_filing_sync, oldest_id
                )
                logger.info("Evicted filing %s (LRU)", oldest_id)

            filing_id = str(uuid.uuid4())[:8]
            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                self._executor,
                self._load_sync,
                file_path,
                packages,
                offline,
                plugins,
                filing_id,
            )
            return result

    def _load_sync(
        self,
        file_path: str,
        packages: list[str] | None,
        offline: bool,
        plugins: str | None,
        filing_id: str,
    ) -> tuple[str, dict[str, Any]]:
        """Synchronous loading — runs in thread executor."""
        from arelle.api.Session import Session
        from arelle.RuntimeOptions import RuntimeOptions

        options = RuntimeOptions(
            entrypointFile=file_path,
            keepOpen=True,
            packages=packages or [],
            plugins=plugins or "",
            internetConnectivity="offline" if offline else "online",
            logFormat="[%(messageCode)s] %(message)s - %(file)s",
        )

        session = Session()
        session.__enter__()

        try:
            session.run(options)
            models = session.get_models()

            if not models:
                session.__exit__(None, None, None)
                raise ValueError(
                    f"Failed to load filing from '{file_path}'. "
                    "Verify the path/URL is correct and the file is valid XBRL/iXBRL."
                )

            model_xbrl = models[0]
            summary = self._build_summary(model_xbrl, file_path)

            self._filings[filing_id] = LoadedFiling(
                filing_id=filing_id,
                uri=file_path,
                model_xbrl=model_xbrl,
                session=session,
                metadata=summary,
            )

            logger.info(
                "Loaded filing %s: %s (%d facts)",
                filing_id,
                file_path,
                summary.get("fact_count", 0),
            )
            return filing_id, summary

        except Exception:
            session.__exit__(None, None, None)
            raise

    def _build_summary(self, model: Any, uri: str) -> dict[str, Any]:
        """Extract comprehensive filing metadata."""
        from arelle.ModelDocument import Type as DocType

        # Extract entity info from DEI facts
        entity_name = self._extract_dei_fact(model, "EntityRegistrantName")
        entity_cik = self._extract_dei_fact(model, "EntityCentralIndexKey")
        doc_type = self._extract_dei_fact(model, "DocumentType")
        doc_period = self._extract_dei_fact(model, "DocumentPeriodEndDate")
        fiscal_year = self._extract_dei_fact(model, "DocumentFiscalYearFocus")

        # Collect namespace prefixes
        namespaces = set()
        for fact in model.facts:
            if fact.qname and fact.qname.prefix:
                namespaces.add(fact.qname.prefix)

        # Determine document type
        model_doc_type = "unknown"
        if model.modelDocument:
            type_val = model.modelDocument.type
            if type_val == DocType.INSTANCE:
                model_doc_type = "XBRL Instance"
            elif type_val == DocType.INLINEXBRL:
                model_doc_type = "Inline XBRL (iXBRL)"
            elif type_val == DocType.INLINEXBRLDOCUMENTSET:
                model_doc_type = "Inline XBRL Document Set"
            elif type_val == DocType.SCHEMA:
                model_doc_type = "Taxonomy Schema"
            else:
                model_doc_type = str(type_val)

        return {
            "filing_id": None,  # Set by caller
            "uri": uri,
            "format": model_doc_type,
            "entity_name": entity_name,
            "entity_cik": entity_cik,
            "document_type": doc_type,
            "period_end_date": doc_period,
            "fiscal_year": fiscal_year,
            "fact_count": len(model.facts),
            "context_count": len(model.contexts),
            "unit_count": len(model.units),
            "dts_document_count": len(model.urlDocs),
            "error_count": len(model.errors),
            "namespaces": sorted(namespaces),
            "has_dimensions": any(
                ctx.qnameDims for ctx in model.contexts.values()
            ),
        }

    @staticmethod
    def _extract_dei_fact(model: Any, local_name: str) -> str | None:
        """Extract a DEI (Document Entity Information) fact value."""
        facts = model.factsByLocalName.get(local_name, [])
        if facts:
            # Return the first non-nil fact value
            for fact in facts:
                if not fact.isNil and fact.value:
                    return fact.value.strip()
        return None

    # ─── Validation ───────────────────────────────────────────────────────

    async def validate_filing(
        self,
        file_path: str,
        disclosure_system: str = "efm-pragmatic-all-years",
        calcs: str = "xbrl21",
        check_utr: bool = False,
        plugins: str | None = None,
        packages: list[str] | None = None,
    ) -> dict[str, Any]:
        """Validate an XBRL filing and return structured results."""
        async with self._lock:
            loop = asyncio.get_running_loop()
            return await loop.run_in_executor(
                self._executor,
                self._validate_sync,
                file_path,
                disclosure_system,
                calcs,
                check_utr,
                plugins,
                packages,
            )

    def _validate_sync(
        self,
        file_path: str,
        disclosure_system: str,
        calcs: str,
        check_utr: bool,
        plugins: str | None,
        packages: list[str] | None,
    ) -> dict[str, Any]:
        """Synchronous validation."""
        import json as json_module

        from arelle.api.Session import Session
        from arelle.RuntimeOptions import RuntimeOptions

        options = RuntimeOptions(
            entrypointFile=file_path,
            validate=True,
            disclosureSystemName=disclosure_system,
            calcs=calcs,
            utrValidate=check_utr,
            plugins=plugins or "",
            packages=packages or [],
            logFormat="[%(messageCode)s] %(message)s - %(file)s",
            logFile="logToBuffer",
        )

        with Session() as session:
            session.run(options)
            try:
                logs_raw = session.get_logs("json")
            except (ValueError, AttributeError):
                # Fallback if json log format not supported by handler
                try:
                    logs_raw = session.get_logs("text")
                except Exception:
                    logs_raw = "[]"
            models = session.get_models()
            error_count = len(models[0].errors) if models else -1

        # Parse log entries
        log_entries = []
        try:
            parsed = json_module.loads(logs_raw) if isinstance(logs_raw, str) else logs_raw
            if isinstance(parsed, list):
                log_entries = parsed
            elif isinstance(parsed, dict) and "log" in parsed:
                log_entries = parsed["log"]
        except (json_module.JSONDecodeError, TypeError):
            log_entries = [{"raw": str(logs_raw)}]

        # Categorize
        errors = [e for e in log_entries if self._is_error(e)]
        warnings = [e for e in log_entries if self._is_warning(e)]
        info = [e for e in log_entries if not self._is_error(e) and not self._is_warning(e)]

        return {
            "valid": error_count == 0,
            "disclosure_system": disclosure_system,
            "error_count": len(errors),
            "warning_count": len(warnings),
            "info_count": len(info),
            "errors": errors[:50],  # Cap at 50 to avoid payload explosion
            "warnings": warnings[:50],
            "info": info[:20],
        }

    @staticmethod
    def _is_error(entry: dict[str, Any]) -> bool:
        level = str(entry.get("level", entry.get("severity", ""))).lower()
        return level in ("error", "err", "critical", "fatal")

    @staticmethod
    def _is_warning(entry: dict[str, Any]) -> bool:
        level = str(entry.get("level", entry.get("severity", ""))).lower()
        return level in ("warning", "warn")

    # ─── Model Access ─────────────────────────────────────────────────────

    def get_model(self, filing_id: str) -> Any:
        """Get a loaded ModelXbrl by filing_id. Moves it to end (LRU touch)."""
        if filing_id not in self._filings:
            available = list(self._filings.keys())
            raise KeyError(
                f"Filing '{filing_id}' not loaded. "
                f"Available filings: {available}. "
                "Use xbrl_load_filing first."
            )
        self._filings.move_to_end(filing_id)
        return self._filings[filing_id].model_xbrl

    def get_filing_info(self, filing_id: str) -> dict[str, Any]:
        """Get metadata for a loaded filing."""
        if filing_id not in self._filings:
            raise KeyError(f"Filing '{filing_id}' not loaded.")
        filing = self._filings[filing_id]
        info = {**filing.metadata, "filing_id": filing_id}
        return info

    def list_loaded_filings(self) -> list[dict[str, Any]]:
        """List all currently loaded filings."""
        return [
            {
                "filing_id": fid,
                "uri": f.uri,
                "entity_name": f.metadata.get("entity_name"),
                "document_type": f.metadata.get("document_type"),
                "period_end_date": f.metadata.get("period_end_date"),
                "format": f.metadata.get("format"),
                "fact_count": f.metadata.get("fact_count", 0),
            }
            for fid, f in self._filings.items()
        ]

    # ─── Cleanup ──────────────────────────────────────────────────────────

    def _close_filing_sync(self, filing_id: str) -> None:
        """Close a filing's model and session (synchronous)."""
        if filing_id in self._filings:
            filing = self._filings.pop(filing_id)
            try:
                filing.model_xbrl.close()
            except Exception as e:
                logger.warning("Error closing model for %s: %s", filing_id, e)
            try:
                filing.session.__exit__(None, None, None)
            except Exception as e:
                # Session thread affinity — safe to ignore on cleanup
                logger.debug("Session cleanup note for %s: %s", filing_id, e)

    async def close_filing(self, filing_id: str) -> bool:
        """Close a specific filing."""
        async with self._lock:
            if filing_id in self._filings:
                loop = asyncio.get_running_loop()
                await loop.run_in_executor(
                    self._executor, self._close_filing_sync, filing_id
                )
                return True
            return False

    async def close_all(self) -> None:
        """Cleanup all loaded filings and shut down executor."""
        async with self._lock:
            loop = asyncio.get_running_loop()
            for filing_id in list(self._filings.keys()):
                try:
                    await loop.run_in_executor(
                        self._executor, self._close_filing_sync, filing_id
                    )
                except Exception as e:
                    logger.debug("Cleanup note for %s: %s", filing_id, e)
            self._executor.shutdown(wait=True)
            logger.info("ArelleManager shut down — all filings closed")

    # ─── Run arbitrary Arelle operations ──────────────────────────────────

    async def run_with_model(
        self, filing_id: str, func: Any, *args: Any, **kwargs: Any
    ) -> Any:
        """Run a synchronous function with a model, holding the lock.

        Usage:
            result = await manager.run_with_model(
                filing_id, some_sync_func, arg1, arg2
            )
        """
        async with self._lock:
            model = self.get_model(filing_id)
            loop = asyncio.get_running_loop()
            return await loop.run_in_executor(
                self._executor, func, model, *args, **kwargs
            )
