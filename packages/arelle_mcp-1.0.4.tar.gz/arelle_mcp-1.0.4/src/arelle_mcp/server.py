"""
arelle-mcp server: The definitive MCP server for XBRL processing.

This is the entry point. It creates the FastMCP instance, manages the
Arelle lifecycle via the lifespan pattern, and registers all tools,
resources, and prompts.
"""

from __future__ import annotations

import logging
import os
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from mcp.server.fastmcp import FastMCP

from arelle_mcp.arelle_wrapper import ArelleManager
from arelle_mcp.constants import DEFAULT_MAX_CACHED_FILINGS

# ─── Logging ──────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=os.environ.get("ARELLE_MCP_LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    stream=sys.stderr,  # MCP stdio requires stderr for logging
)
logger = logging.getLogger("arelle_mcp")


# ─── Lifespan ─────────────────────────────────────────────────────────────────

@asynccontextmanager
async def arelle_lifespan(server: FastMCP) -> AsyncIterator[ArelleManager]:
    """Manage the ArelleManager lifecycle.

    Initializes the manager on server startup and cleans up all loaded
    filings and resources on shutdown. The manager is available to all
    tools via ctx.request_context.lifespan_context.
    """
    max_filings = int(os.environ.get("ARELLE_MCP_MAX_FILINGS", DEFAULT_MAX_CACHED_FILINGS))
    cache_dir = os.environ.get("ARELLE_MCP_CACHE_DIR", None)

    manager = ArelleManager(
        max_cached_filings=max_filings,
        cache_dir=cache_dir,
    )
    logger.info(
        "arelle-mcp v1.0.0 starting — max_filings=%d",
        max_filings,
    )

    try:
        yield manager
    finally:
        await manager.close_all()
        logger.info("arelle-mcp shut down cleanly")


# ─── Server Instance ──────────────────────────────────────────────────────────

mcp = FastMCP(
    "arelle_mcp",
    lifespan=arelle_lifespan,
    instructions=(
        "XBRL processing and financial analysis server powered by Arelle — "
        "the world's only free, open-source XBRL-certified processor.\n\n"
        "WORKFLOW:\n"
        "1. xbrl_load_filing (or xbrl_fetch_sec_filing) → get a filing_id\n"
        "2. Use filing_id with analysis tools:\n"
        "   - xbrl_extract_facts: query specific financial data points\n"
        "   - xbrl_validate: check filing compliance\n"
        "   - xbrl_presentation_tree: see financial statement structure\n"
        "   - xbrl_calculation_tree: see mathematical relationships\n"
        "   - xbrl_dimension_structure: see multi-dimensional breakdowns\n"
        "   - xbrl_render_statement: render complete financial statements\n"
        "   - xbrl_browse_taxonomy: explore available concepts\n"
        "   - xbrl_compare_filings: diff two filings\n"
        "3. SEC EDGAR tools (no filing load needed):\n"
        "   - xbrl_search_sec_concept: historical concept data\n"
        "   - xbrl_company_facts: all available concepts for a company\n\n"
        "TIPS:\n"
        "- Use xbrl_list_filings to see what's loaded\n"
        "- Each filing uses 30-60MB RAM; close when done with xbrl_close_filing\n"
        "- For SEC filings, provide ticker OR CIK to xbrl_fetch_sec_filing\n"
        "- Common concepts: Assets, Revenues, NetIncomeLoss, EarningsPerShareBasic\n"
    ),
)


# ─── Register Everything ─────────────────────────────────────────────────────

def _register_all() -> None:
    """Register all tools, resources, and prompts on the MCP server."""
    from arelle_mcp.prompts import register_prompts
    from arelle_mcp.resources import register_resources
    from arelle_mcp.tools.edgar import register_edgar_tools
    from arelle_mcp.tools.facts import register_facts_tools
    from arelle_mcp.tools.filing import register_filing_tools
    from arelle_mcp.tools.relationships import register_relationship_tools
    from arelle_mcp.tools.rendering import register_rendering_tools
    from arelle_mcp.tools.taxonomy import register_taxonomy_tools
    from arelle_mcp.tools.validation import register_validation_tools

    register_filing_tools(mcp)
    register_validation_tools(mcp)
    register_facts_tools(mcp)
    register_taxonomy_tools(mcp)
    register_relationship_tools(mcp)
    register_edgar_tools(mcp)
    register_rendering_tools(mcp)
    register_resources(mcp)
    register_prompts(mcp)

    logger.info("All tools, resources, and prompts registered")


_register_all()


# ─── Entry Point ──────────────────────────────────────────────────────────────

def main() -> None:
    """Run the arelle-mcp server."""
    transport = os.environ.get("ARELLE_MCP_TRANSPORT", "stdio")

    if transport == "streamable-http":
        port = int(os.environ.get("ARELLE_MCP_PORT", "8000"))
        logger.info("Starting arelle-mcp on HTTP port %d", port)
        mcp.run(transport="streamable-http", port=port)
    else:
        logger.info("Starting arelle-mcp on stdio")
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
