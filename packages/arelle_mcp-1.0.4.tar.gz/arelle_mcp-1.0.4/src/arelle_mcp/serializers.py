"""
Serializers for converting Arelle model objects to LLM-friendly formats.

Every function here takes raw Arelle objects and produces clean dicts
or markdown strings. No Arelle imports at module level — all lazy.
"""

from __future__ import annotations

from typing import Any

from arelle_mcp.constants import (
    ARCROLE_PARENT_CHILD,
    ARCROLE_SUMMATION_ITEM,
    STATEMENT_ROLE_PATTERNS,
)

# ─── Fact Serialization ──────────────────────────────────────────────────────

def serialize_fact(fact: Any, include_dimensions: bool = True) -> dict[str, Any]:
    """Serialize a ModelFact to a JSON-friendly dict."""
    result: dict[str, Any] = {
        "concept": str(fact.qname) if fact.qname else None,
        "local_name": fact.qname.localName if fact.qname else None,
        "value": fact.effectiveValue,
    }

    if fact.isNumeric:
        try:
            result["numeric_value"] = str(fact.xValue) if fact.xValue is not None else None
        except Exception:
            result["numeric_value"] = fact.value
        result["decimals"] = fact.decimals
        if fact.unit and fact.unit.measures:
            measures = fact.unit.measures
            if measures[0]:
                result["unit"] = str(measures[0][0].localName) if measures[0] else None
            if len(measures) > 1 and measures[1]:
                result["unit_denominator"] = str(measures[1][0].localName)
    else:
        result["is_text"] = True

    result["context_id"] = fact.contextID

    if fact.context is not None:
        ctx = fact.context
        ident = ctx.entityIdentifier
        if ident:
            result["entity_scheme"] = ident[0]
            result["entity_id"] = ident[1]

        if ctx.isInstantPeriod:
            result["period_type"] = "instant"
            result["period"] = _format_datetime(ctx.instantDatetime)
        elif ctx.isStartEndPeriod:
            result["period_type"] = "duration"
            result["period_start"] = _format_datetime(ctx.startDatetime)
            result["period_end"] = _format_datetime(ctx.endDatetime)
        elif ctx.isForeverPeriod:
            result["period_type"] = "forever"

        if include_dimensions and ctx.qnameDims:
            dims: dict[str, str] = {}
            for dim_qn, dim_val in ctx.qnameDims.items():
                dim_name = str(dim_qn.localName) if dim_qn else str(dim_qn)
                if dim_val.isExplicit:
                    dims[dim_name] = str(dim_val.memberQname.localName) if dim_val.memberQname else ""
                else:
                    typed = dim_val.typedMember
                    dims[dim_name] = (
                        typed.stringValue if typed is not None else "[typed]"
                    )
            result["dimensions"] = dims

    if fact.isNil:
        result["is_nil"] = True

    if fact.xmlLang and fact.xmlLang != "en-US":
        result["language"] = fact.xmlLang

    return result


def serialize_fact_compact(fact: Any) -> dict[str, Any]:
    """Compact fact serialization — minimal fields for large listings."""
    result: dict[str, Any] = {
        "concept": fact.qname.localName if fact.qname else None,
        "value": fact.effectiveValue,
    }
    if fact.isNumeric and fact.unit and fact.unit.measures and fact.unit.measures[0]:
        result["unit"] = str(fact.unit.measures[0][0].localName)
    if fact.context:
        if fact.context.isInstantPeriod:
            result["period"] = _format_datetime(fact.context.instantDatetime)
        elif fact.context.isStartEndPeriod:
            result["period"] = _format_datetime(fact.context.endDatetime)
    return result


# ─── Concept Serialization ───────────────────────────────────────────────────

def serialize_concept(concept: Any) -> dict[str, Any]:
    """Serialize a ModelConcept to a JSON-friendly dict."""
    label = None
    try:
        label = concept.label(lang="en-US", fallbackToQname=True)
    except Exception:
        label = str(concept.qname)

    return {
        "qname": str(concept.qname),
        "local_name": concept.qname.localName if concept.qname else None,
        "label": label,
        "type": str(concept.typeQname) if concept.typeQname else None,
        "period_type": getattr(concept, "periodType", None),
        "balance": getattr(concept, "balance", None),
        "abstract": getattr(concept, "isAbstract", False),
        "numeric": getattr(concept, "isNumeric", False),
        "monetary": getattr(concept, "isMonetary", False),
        "is_dimension": getattr(concept, "isDimensionItem", False),
        "is_hypercube": getattr(concept, "isHypercubeItem", False),
        "substitution_group": str(concept.substitutionGroupQname) if getattr(concept, "substitutionGroupQname", None) else None,
        "is_extension": _is_extension_concept(concept),
    }


def serialize_concept_detailed(concept: Any, model: Any) -> dict[str, Any]:
    """Full concept details including all labels, references, and reported facts."""
    base = serialize_concept(concept)

    # All labels
    labels: dict[str, str] = {}
    try:
        from arelle import XbrlConst
        label_rel_set = model.relationshipSet(XbrlConst.conceptLabel)
        for rel in label_rel_set.fromModelObject(concept):
            resource = rel.toModelObject
            if resource is not None:
                role = getattr(resource, "role", "standard")
                role_short = role.split("/")[-1] if "/" in role else role
                labels[role_short] = resource.textValue
    except Exception:
        pass
    base["labels"] = labels

    # References
    references: list[dict[str, str]] = []
    try:
        from arelle import XbrlConst
        ref_rel_set = model.relationshipSet(XbrlConst.conceptReference)
        for rel in ref_rel_set.fromModelObject(concept):
            resource = rel.toModelObject
            if resource is not None:
                ref_parts = {}
                for child in resource:
                    ref_parts[child.localName] = child.textValue
                if ref_parts:
                    references.append(ref_parts)
    except Exception:
        pass
    base["references"] = references

    # Reported facts for this concept
    facts = model.factsByQname.get(concept.qname, set())
    base["reported_fact_count"] = len(facts)
    base["sample_facts"] = [
        serialize_fact_compact(f) for f in list(facts)[:5]
    ]

    return base


# ─── Relationship / Tree Serialization ────────────────────────────────────────

def serialize_presentation_tree(
    model: Any,
    linkrole: str,
    max_depth: int = 10,
) -> dict[str, Any]:
    """Serialize a presentation hierarchy for a given link role."""
    rel_set = model.relationshipSet(ARCROLE_PARENT_CHILD, linkrole)

    role_types = model.roleTypes.get(linkrole, [])
    role_label = role_types[0].definition if role_types else linkrole

    def build_node(concept: Any, depth: int = 0) -> dict[str, Any]:
        label = None
        try:
            label = concept.label(lang="en-US", fallbackToQname=True)
        except Exception:
            label = str(concept.qname)

        node: dict[str, Any] = {
            "concept": str(concept.qname),
            "label": label,
            "abstract": getattr(concept, "isAbstract", False),
        }

        if depth < max_depth:
            children = []
            for rel in rel_set.fromModelObject(concept):
                child_obj = rel.toModelObject
                if child_obj is not None:
                    child = build_node(child_obj, depth + 1)
                    child["order"] = float(rel.order)
                    if rel.preferredLabel:
                        child["preferred_label"] = rel.preferredLabel.split("/")[-1]
                    children.append(child)
            if children:
                children.sort(key=lambda c: c.get("order", 0))
                node["children"] = children

        return node

    roots = [build_node(r) for r in rel_set.rootConcepts]
    return {"role": linkrole, "label": role_label, "tree": roots}


def serialize_calculation_tree(
    model: Any,
    linkrole: str | None = None,
    root_concept_name: str | None = None,
) -> list[dict[str, Any]]:
    """Serialize calculation relationships."""
    results = []

    if linkrole:
        roles = [linkrole]
    else:
        # Get all roles that have calculation relationships
        rel_set_all = model.relationshipSet(ARCROLE_SUMMATION_ITEM)
        roles = list(set(
            rel.linkrole for rel in rel_set_all.modelRelationships
        ))

    for role in roles:
        rel_set = model.relationshipSet(ARCROLE_SUMMATION_ITEM, role)
        role_types = model.roleTypes.get(role, [])
        role_label = role_types[0].definition if role_types else role

        def build_calc_node(concept: Any, depth: int = 0) -> dict[str, Any]:
            label = None
            try:
                label = concept.label(lang="en-US", fallbackToQname=True)
            except Exception:
                label = str(concept.qname)

            node: dict[str, Any] = {
                "concept": str(concept.qname),
                "label": label,
            }

            children = []
            for rel in rel_set.fromModelObject(concept):
                child_obj = rel.toModelObject
                if child_obj is not None:
                    child = build_calc_node(child_obj, depth + 1)
                    child["weight"] = float(rel.weight)
                    child["order"] = float(rel.order)
                    children.append(child)

            if children:
                children.sort(key=lambda c: c.get("order", 0))
                node["components"] = children

            return node

        roots = rel_set.rootConcepts
        if root_concept_name:
            roots = [
                r for r in roots
                if root_concept_name.lower() in str(r.qname).lower()
            ]

        trees = [build_calc_node(r) for r in roots]
        if trees:
            results.append({
                "role": role,
                "label": role_label,
                "trees": trees,
            })

    return results


def serialize_dimension_structure(
    model: Any, dimension_filter: str | None = None, max_members: int = 20,
) -> list[dict[str, Any]]:
    """Serialize the dimensional structure of a filing."""
    from arelle_mcp.constants import (
        ARCROLE_DIMENSION_DOMAIN,
        ARCROLE_DOMAIN_MEMBER,
        ARCROLE_HYPERCUBE_DIMENSION,
    )

    results = []

    hc_dim_set = model.relationshipSet(ARCROLE_HYPERCUBE_DIMENSION)
    dim_dom_set = model.relationshipSet(ARCROLE_DIMENSION_DOMAIN)
    dom_mem_set = model.relationshipSet(ARCROLE_DOMAIN_MEMBER)

    # Build dimension → members mapping
    for hc_rel in hc_dim_set.modelRelationships:
        dim_concept = hc_rel.toModelObject
        if dim_concept is None:
            continue

        dim_name = str(dim_concept.qname)
        if dimension_filter and dimension_filter.lower() not in dim_name.lower():
            continue

        dim_label = None
        try:
            dim_label = dim_concept.label(lang="en-US", fallbackToQname=True)
        except Exception:
            dim_label = dim_name

        # Get domain and members
        members = []
        for dom_rel in dim_dom_set.fromModelObject(dim_concept):
            domain = dom_rel.toModelObject
            if domain is None:
                continue
            _collect_members(dom_mem_set, domain, members, depth=0, max_depth=5)

        results.append({
            "dimension": dim_name,
            "label": dim_label,
            "hypercube": str(hc_rel.fromModelObject.qname) if hc_rel.fromModelObject is not None else None,
            "member_count": len(members),
            "members": members[:max_members],
            "truncated": len(members) > max_members,
        })

    return results


def _collect_members(
    rel_set: Any, parent: Any, result: list[dict[str, Any]],
    depth: int, max_depth: int
) -> None:
    """Recursively collect domain members."""
    try:
        label = parent.label(lang="en-US", fallbackToQname=True)
    except Exception:
        label = str(parent.qname)

    result.append({
        "qname": str(parent.qname),
        "label": label,
        "depth": depth,
    })

    if depth < max_depth:
        for rel in rel_set.fromModelObject(parent):
            child = rel.toModelObject
            if child is not None:
                _collect_members(rel_set, child, result, depth + 1, max_depth)


# ─── Statement Rendering ─────────────────────────────────────────────────────

def render_statement(
    model: Any,
    statement_type: str | None = None,
) -> list[dict[str, Any]]:
    """Render financial statements from presentation linkbase structure."""
    results = []

    for role_uri, role_type_list in model.roleTypes.items():
        if not role_type_list:
            continue

        role_def = role_type_list[0].definition or role_uri
        matched_type = _match_statement_type(role_def, role_uri)

        if statement_type and statement_type != "all":
            if matched_type != statement_type:
                continue

        # Only include roles that have presentation relationships
        role_rel_set = model.relationshipSet(ARCROLE_PARENT_CHILD, role_uri)
        roots = role_rel_set.rootConcepts
        if not roots:
            continue

        rows: list[dict[str, Any]] = []
        for root in roots:
            _render_tree_rows(role_rel_set, model, root, rows, indent=0)

        if rows:
            results.append({
                "statement_type": matched_type or "other",
                "role": role_uri,
                "title": role_def,
                "rows": rows,
            })

    return results


def _render_tree_rows(
    rel_set: Any, model: Any, concept: Any,
    rows: list[dict[str, Any]], indent: int
) -> None:
    """Recursively build financial statement rows from presentation tree."""
    try:
        label = concept.label(lang="en-US", fallbackToQname=True)
    except Exception:
        label = str(concept.qname)

    row: dict[str, Any] = {
        "label": label,
        "concept": str(concept.qname),
        "indent": indent,
        "abstract": getattr(concept, "isAbstract", False),
    }

    # Get fact values for this concept
    facts = model.factsByQname.get(concept.qname, set())
    if facts and not getattr(concept, "isAbstract", False):
        # Group by period
        period_values: dict[str, str] = {}
        for fact in facts:
            if fact.context is not None and len(fact.context.qnameDims) == 0:  # Only default dimension facts
                period_key = _get_period_key(fact.context)
                period_values[period_key] = fact.effectiveValue
        if period_values:
            row["values"] = period_values

    rows.append(row)

    # Process children
    children = rel_set.fromModelObject(concept)
    sorted_children = sorted(children, key=lambda r: float(r.order))
    for rel in sorted_children:
        child = rel.toModelObject
        if child is not None:
            _render_tree_rows(rel_set, model, child, rows, indent + 1)


# ─── Filing Comparison ────────────────────────────────────────────────────────

def compare_filings(model1: Any, model2: Any) -> dict[str, Any]:
    """Compare two filings — focus on key numeric changes, compact output."""
    def fact_key(fact: Any) -> str:
        parts = [str(fact.qname)]
        if fact.context:
            parts.append(fact.contextID)
        return "|".join(parts)

    # Only compare numeric, default-dimension facts (no segment breakdowns)
    def is_default_numeric(f: Any) -> bool:
        return f.isNumeric and (not f.context or not f.context.qnameDims)

    facts1 = {fact_key(f): f for f in model1.facts if is_default_numeric(f)}
    facts2 = {fact_key(f): f for f in model2.facts if is_default_numeric(f)}

    keys1 = set(facts1.keys())
    keys2 = set(facts2.keys())

    added_keys = keys2 - keys1
    removed_keys = keys1 - keys2
    common_keys = keys1 & keys2

    changed = []
    for key in common_keys:
        f1, f2 = facts1[key], facts2[key]
        if f1.effectiveValue != f2.effectiveValue:
            changed.append({
                "concept": f1.qname.localName if f1.qname else str(f1.qname),
                "old_value": f1.effectiveValue,
                "new_value": f2.effectiveValue,
            })

    changed.sort(key=lambda x: x.get("concept", ""))

    return {
        "filing1_facts": len(facts1),
        "filing2_facts": len(facts2),
        "added_count": len(added_keys),
        "removed_count": len(removed_keys),
        "changed_count": len(changed),
        "changed": changed[:15],
        "added_sample": [serialize_fact_compact(facts2[k]) for k in list(added_keys)[:5]],
        "removed_sample": [serialize_fact_compact(facts1[k]) for k in list(removed_keys)[:5]],
    }


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _format_datetime(dt: Any) -> str | None:
    """Format a datetime to ISO string, handling Arelle's datetime types."""
    if dt is None:
        return None
    try:
        return dt.isoformat()[:10]  # Date only for readability
    except Exception:
        return str(dt)


def _is_extension_concept(concept: Any) -> bool:
    """Determine if a concept is a company extension (not standard taxonomy)."""
    qname = concept.qname
    if qname is None:
        return False
    ns = qname.namespaceURI or ""
    standard_ns_patterns = [
        "fasb.org", "xbrl.org", "sec.gov/dei",
        "sec.gov/srt", "sec.gov/country", "sec.gov/stpr",
        "ifrs.org",
    ]
    return not any(pat in ns for pat in standard_ns_patterns)


def _match_statement_type(role_def: str, role_uri: str) -> str | None:
    """Match a role definition/URI to a known statement type."""
    combined = (role_def + " " + role_uri).lower()
    for stmt_type, patterns in STATEMENT_ROLE_PATTERNS.items():
        for pattern in patterns:
            if pattern.lower() in combined:
                return stmt_type
    return None


def _get_period_key(context: Any) -> str:
    """Create a human-readable period key from a context."""
    if context.isInstantPeriod:
        dt = context.instantDatetime
        return _format_datetime(dt) or "instant"
    elif context.isStartEndPeriod:
        start = context.startDatetime
        end = context.endDatetime
        if start and end:
            days = (end - start).days
            end_str = _format_datetime(end) or "?"
            if 80 <= days <= 100:
                return f"3M ended {end_str}"
            elif 170 <= days <= 200:
                return f"6M ended {end_str}"
            elif 260 <= days <= 290:
                return f"9M ended {end_str}"
            elif 355 <= days <= 375:
                return f"12M ended {end_str}"
            else:
                return f"{days}d ended {end_str}"
        return _format_datetime(end) or "duration"
    return "forever"
