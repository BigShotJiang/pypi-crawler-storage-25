# Changelog

## [1.0.1] — 2026-04-04

### Fixed
- **CRITICAL**: Removed broken `ctx.report_progress()` calls that crashed every tool call (MCP SDK expects `(float, float)`, not `(float, string)`)
- **CRITICAL**: Fixed SEC EDGAR 403 Forbidden — User-Agent header now uses SEC-required format `"CompanyName email@domain"`
- Added `Accept-Encoding` header to SEC EDGAR HTTP client
- Removed unused imports (`ProcessPoolExecutor`, `Path`)
- Fixed bare `except` → `except Exception`
- Cleaned all ruff lint warnings

### Changed
- Updated ruff config: dropped strict ANN rules, practical lint settings
- Added Docker test environment (Dockerfile, docker-compose.yml, Makefile)

## [1.0.0] — 2026-04-04

### Added
- 17 MCP tools covering the full XBRL processing lifecycle
- Filing operations: load, summary, compare, close, list
- Validation against SEC EFM, ESEF, HMRC, GFM disclosure systems
- Fact extraction with 10+ filter dimensions (concept, period, dimension, unit, etc.)
- Taxonomy browsing with concept search, type filtering, extension detection
- Relationship traversal: presentation trees, calculation hierarchies, dimension structures
- SEC EDGAR integration: fetch by ticker/CIK, historical concept search, company facts
- Financial statement rendering in markdown and JSON
- 5 MCP resources for reference data
- 5 MCP prompt templates for guided analysis workflows
- LRU filing cache with configurable capacity
- Thread-safe ArelleManager with asyncio.Lock serialization
- Support for stdio and streamable-http transports
- Comprehensive README with usage examples
