# arelle-mcp — API Quick Reference Card

> All 17 tools, 5 resources, 5 prompts at a glance.

---

## Tools

### Filing Operations

| Tool | Input | Output | Notes |
|------|-------|--------|-------|
| `xbrl_load_filing` | `file_path`, `taxonomy_packages?`, `offline?`, `plugins?` | `filing_id` + summary | Entry point — call first |
| `xbrl_filing_summary` | `filing_id` | Entity, CIK, period, counts | Quick metadata check |
| `xbrl_compare_filings` | `filing_id_1`, `filing_id_2` | Added/removed/changed facts | Both filings must be loaded |
| `xbrl_close_filing` | `filing_id` | Confirmation | Frees 30-60MB |
| `xbrl_list_filings` | (none) | List of loaded filings | Check what's in cache |

### Validation

| Tool | Input | Output | Notes |
|------|-------|--------|-------|
| `xbrl_validate` | `file_path`, `disclosure_system?`, `check_calculations?`, `check_utr?`, `plugins?` | valid/invalid + errors/warnings | No pre-load needed |

**Disclosure systems**: `efm` (SEC), `esef` (EU), `hmrc` (UK), `gfm` (generic)  
**Calc modes**: `none`, `xbrl21`, `round-to-nearest`, `truncation`

### Fact Extraction

| Tool | Input | Output | Notes |
|------|-------|--------|-------|
| `xbrl_extract_facts` | `filing_id`, `concept?`, `period_type?`, `dimension?`, `member?`, `unit?`, `numeric_only?`, `exclude_dimensions?`, `offset`, `limit` | Paginated fact list | 10+ filter dimensions |
| `xbrl_fact_details` | `filing_id`, `concept_name`, `period?` | Concept definition + all facts | Full taxonomy info |

### Taxonomy Browsing

| Tool | Input | Output | Notes |
|------|-------|--------|-------|
| `xbrl_browse_taxonomy` | `filing_id`, `search?`, `concept_type?`, `extensions_only?`, `with_facts_only?`, `namespace?` | Paginated concept list | Search DTS |
| `xbrl_concept_details` | `filing_id`, `concept_name` | Labels, references, type, sample facts | Full concept profile |

### Relationship Traversal

| Tool | Input | Output | Notes |
|------|-------|--------|-------|
| `xbrl_presentation_tree` | `filing_id`, `role_filter?`, `max_depth?`, `list_roles_only?` | Hierarchical tree per role | Financial statement structure |
| `xbrl_calculation_tree` | `filing_id`, `concept_name?`, `role_filter?` | Calculation trees with weights | Math relationships |
| `xbrl_dimension_structure` | `filing_id`, `dimension_name?` | Hypercubes, axes, members | Dimensional breakdowns |

### SEC EDGAR

| Tool | Input | Output | Notes |
|------|-------|--------|-------|
| `xbrl_fetch_sec_filing` | `cik?`, `ticker?`, `filing_type?`, `date?`, `load_filing?` | Filing metadata + optional filing_id | Auto-resolves ticker→CIK |
| `xbrl_search_sec_concept` | `cik`, `concept`, `taxonomy?` | Historical values across all filings | No filing load needed |
| `xbrl_company_facts` | `cik`, `concept_filter?`, `limit?` | All available concepts + counts | Discovery tool |

### Rendering

| Tool | Input | Output | Notes |
|------|-------|--------|-------|
| `xbrl_render_statement` | `filing_id`, `statement?`, `format?` | Financial statements | markdown or JSON |

**Statement types**: `balance_sheet`, `income_statement`, `cash_flow`, `equity`, `all`

---

## Resources

| URI | Content |
|-----|---------|
| `xbrl://reference/disclosure-systems` | All supported validation rulesets |
| `xbrl://reference/common-concepts` | Top US-GAAP concepts (Assets, Revenue, etc.) |
| `xbrl://reference/statement-types` | Statement type → role pattern mapping |
| `xbrl://reference/calculation-modes` | Calculation checking mode descriptions |
| `xbrl://reference/xbrl-primer` | XBRL explainer for LLMs |

---

## Prompts

| Prompt | Parameters | Purpose |
|--------|-----------|---------|
| `analyze_filing` | `filing_source`, `analysis_depth` | Full filing analysis workflow |
| `compare_periods` | `filing_url_1`, `filing_url_2` | Period-over-period comparison |
| `sec_company_deep_dive` | `identifier`, `filing_type` | Company deep dive from SEC |
| `validate_and_fix` | `filing_source` | Error analysis with fix suggestions |
| `taxonomy_explorer` | `filing_source` | Taxonomy discovery and mapping |

---

## Common Workflows

### 1. Quick Financial Summary
```
xbrl_fetch_sec_filing(ticker="AAPL") 
→ xbrl_extract_facts(concept="Revenues")
→ xbrl_extract_facts(concept="NetIncomeLoss")
→ xbrl_render_statement(statement="income_statement")
```

### 2. Validate & Debug
```
xbrl_validate(file_path="...", disclosure_system="efm")
→ review errors
→ xbrl_load_filing(file_path="...")
→ xbrl_calculation_tree(concept_name="Assets")
→ cross-reference errors with actual facts
```

### 3. Historical Trend
```
xbrl_search_sec_concept(cik="320193", concept="Revenues")
→ 5+ years of revenue data, no filing load needed
```

### 4. Quarter-over-Quarter
```
xbrl_load_filing(Q2_url) → filing_id_1
xbrl_load_filing(Q3_url) → filing_id_2
xbrl_compare_filings(filing_id_1, filing_id_2)
```

### 5. Taxonomy Discovery
```
xbrl_load_filing(...)
→ xbrl_browse_taxonomy(extensions_only=true)
→ xbrl_dimension_structure()
→ xbrl_presentation_tree(list_roles_only=true)
```

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `ARELLE_MCP_MAX_FILINGS` | `5` | Max cached filings |
| `ARELLE_MCP_CACHE_DIR` | (none) | Taxonomy cache directory |
| `ARELLE_MCP_TRANSPORT` | `stdio` | `stdio` or `streamable-http` |
| `ARELLE_MCP_PORT` | `8000` | HTTP port |
| `ARELLE_MCP_LOG_LEVEL` | `INFO` | Logging level |

---

## Quick Install

```bash
# PyPI
pip install arelle-mcp

# Claude Desktop
# Add to claude_desktop_config.json:
{"mcpServers": {"arelle-mcp": {"command": "arelle-mcp"}}}

# Claude Code
claude mcp add arelle-mcp -- arelle-mcp

# Run directly
arelle-mcp                    # stdio mode
ARELLE_MCP_TRANSPORT=streamable-http arelle-mcp   # HTTP mode
```
