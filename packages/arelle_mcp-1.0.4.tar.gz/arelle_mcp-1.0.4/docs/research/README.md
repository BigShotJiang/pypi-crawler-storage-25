# arelle-mcp Research Documents

This folder contains the complete research and design documentation
compiled during the architecture and development of arelle-mcp.

## Contents

| # | Document | Pages | Description |
|---|----------|-------|-------------|
| 01 | [Architecture Blueprint](01-architecture-blueprint.md) | ~15 | Arelle's internals, full API surface, MVC architecture, Session API, ModelXbrl, relationships, plugin system, memory management, MCP design decisions, competitive analysis |
| 02 | [API Reference Card](02-api-reference-card.md) | ~5 | Quick reference for all 17 tools, 5 resources, 5 prompts. Common workflows, environment variables, install commands |
| 03 | [XBRL Ecosystem Primer](03-xbrl-ecosystem-primer.md) | ~8 | XBRL data model, taxonomies, linkbases, dimensions, SEC EDGAR APIs, common US-GAAP concepts, file formats, validation rules |

## Key Findings

1. **No XBRL MCP server exists anywhere** — confirmed across PyPI, npm, GitHub, and all MCP registries
2. **Arelle's single-session constraint** is the #1 architectural challenge — solved with asyncio.Lock + ThreadPoolExecutor
3. **17 tools** cover the complete XBRL lifecycle — no compromises
4. **SEC EDGAR APIs** are free, no-auth, 10 req/sec — integrated directly via httpx

## Research Date
April 2026
