# XBRL Ecosystem Primer for arelle-mcp

> Everything you need to know about XBRL, taxonomies, SEC EDGAR,
> and how they connect to the arelle-mcp server.

---

## What is XBRL?

XBRL (eXtensible Business Reporting Language) is the global standard for machine-readable business and financial reporting. It transforms financial statements from unstructured documents into structured, tagged data that computers can process, compare, and analyze automatically.

Every SEC filing since 2009 includes XBRL data. Since June 2021, the SEC mandates **Inline XBRL (iXBRL)** — a format that embeds XBRL tags directly in HTML, making documents simultaneously human-readable in a browser and machine-parseable by software like Arelle.

---

## The XBRL Data Model

### Facts
A **fact** is a single data point. Example: "Revenue = $274,515,000,000 for the year ended September 28, 2024, reported by Apple Inc."

Every fact consists of:
- **Concept**: What is being reported (e.g., `us-gaap:Revenues`)
- **Context**: Who reported it, when, and any dimensional breakdowns
- **Value**: The actual data (number, text, date, boolean)
- **Unit**: Measurement (USD, shares, pure ratio) — for numeric facts only

### Contexts
A **context** defines:
- **Entity**: Who (identified by CIK for SEC filers)
- **Period**: When — either an instant (balance sheet date) or a duration (income statement period)
- **Dimensions**: Optional breakdowns (by segment, geography, product, etc.)

### Units
Numeric facts require units:
- Monetary: `iso4217:USD`, `iso4217:EUR`
- Shares: `xbrli:shares`
- Per-share: `iso4217:USD/xbrli:shares`
- Ratio/percentage: `xbrli:pure`

---

## Taxonomies — The Dictionary

Taxonomies define what can be reported. They contain:
- **Concepts** (elements): Named data points with types, period types, and balance directions
- **Linkbases**: Relationships between concepts

### Standard Taxonomies

| Taxonomy | Namespace | Maintainer | Purpose |
|----------|-----------|-----------|---------|
| **US-GAAP** | `http://fasb.org/us-gaap/2024` | FASB | US accounting standards (~18,000 concepts) |
| **DEI** | `http://xbrl.sec.gov/dei/2024` | SEC | Document metadata (company name, CIK, filing date) |
| **SRT** | `http://fasb.org/srt/2024` | SEC | SEC-specific requirements |
| **IFRS** | `http://xbrl.ifrs.org/taxonomy/2024-03-27/ifrs-full` | IASB | International standards |
| **Country** | `http://xbrl.sec.gov/country/2024` | SEC | Country codes |
| **STPR** | `http://xbrl.sec.gov/stpr/2024` | SEC | US state/province codes |
| **Currency** | `http://xbrl.sec.gov/currency/2024` | SEC | Currency codes |

### Extension Taxonomies
Companies create **extension taxonomies** for concepts not in standard taxonomies. Example: Apple might define `aapl:iPhoneRevenue` if no standard concept captures iPhone-specific revenue.

In arelle-mcp: `xbrl_browse_taxonomy(extensions_only=true)` finds these.

---

## Linkbases — The Relationships

### Presentation Linkbase
Defines **display order** — how concepts are organized in financial statements.

Structure: Tree hierarchy grouped by **Extended Link Roles (ELRs)**. Each ELR typically represents one financial statement:
- `http://apple.com/role/ConsolidatedBalanceSheets`
- `http://apple.com/role/ConsolidatedStatementsOfOperations`
- `http://apple.com/role/ConsolidatedStatementsOfCashFlows`

In arelle-mcp: `xbrl_presentation_tree(list_roles_only=true)` lists all ELRs.

### Calculation Linkbase
Defines **mathematical relationships** between concepts:
```
Assets (total)
  ├── CurrentAssets (weight: +1)
  └── NoncurrentAssets (weight: +1)
```

Weights are +1 (addition) or -1 (subtraction). Arelle validates these during filing validation.

In arelle-mcp: `xbrl_calculation_tree(concept_name="Assets")`

### Definition Linkbase
Defines **semantic/dimensional relationships**:
- Hypercube → Dimension relationships
- Dimension → Domain relationships
- Domain → Member hierarchies

### Label Linkbase
Maps concepts to **human-readable names** in multiple languages and roles:
- **Standard**: "Revenue from Contract with Customer" 
- **Terse**: "Revenue"
- **Verbose**: "Revenue from Contract with Customer, Excluding Assessed Tax"
- **Documentation**: Full definition text

### Reference Linkbase
Links concepts to **accounting standards**:
- Topic, Subtopic, Paragraph, Section from ASC (Accounting Standards Codification)
- IAS/IFRS references for international concepts

---

## XBRL Dimensions

Dimensions enable **multi-dimensional data breakdowns**. Think of them as pivot table axes.

### Structure
```
Hypercube (table container)
  └── Dimension (axis)
      └── Domain (root of valid values)
          ├── Member A
          ├── Member B
          └── Member C
              ├── Sub-member C1
              └── Sub-member C2
```

### Example
Apple reports revenue broken down by product:
```
Revenue ($274.5B total)
├── ProductOrServiceAxis
│   ├── IPhoneMember ($201.2B)
│   ├── MacMember ($29.4B)
│   ├── IPadMember ($28.3B)
│   ├── WearablesHomeAndAccessoriesMember ($39.8B)
│   └── ServiceMember ($85.2B)
├── StatementGeographicalAxis
│   ├── AmericasSegmentMember ($114.7B)
│   ├── EuropeSegmentMember ($94.3B)
│   ├── ChinaSegmentMember ($67.0B)
│   └── ...
```

### Types
- **Explicit dimensions**: Members defined in taxonomy (e.g., `IPhoneMember`)
- **Typed dimensions**: Values matching an XML type (e.g., a date range)

In arelle-mcp: `xbrl_dimension_structure()` reveals the complete dimensional structure.

---

## SEC EDGAR Integration

### Filing Types

| Form | Filing | Frequency |
|------|--------|-----------|
| 10-K | Annual report | Yearly |
| 10-Q | Quarterly report | 3x/year |
| 8-K | Current report | Event-driven |
| 20-F | Foreign annual | Yearly |
| S-1 | IPO registration | One-time |
| DEF 14A | Proxy statement | Yearly |
| Forms 3/4/5 | Insider ownership | Event-driven |

### Identifiers
- **CIK**: 10-digit Central Index Key (e.g., `0000320193` for Apple)
- **Ticker**: Stock symbol (e.g., `AAPL`) — resolved to CIK via SEC API
- **Accession Number**: Unique filing ID (e.g., `0001628280-25-045968`)

### SEC XBRL APIs (Free, No Auth Required)

**Company Submissions** — Filing history:
```
https://data.sec.gov/submissions/CIK0000320193.json
```

**Company Facts** — All XBRL facts ever reported:
```
https://data.sec.gov/api/xbrl/companyfacts/CIK0000320193.json
```

**Company Concept** — One concept across all filings:
```
https://data.sec.gov/api/xbrl/companyconcept/CIK0000320193/us-gaap/Revenues.json
```

**Frames** — Cross-company comparison for one concept/period:
```
https://data.sec.gov/api/xbrl/frames/us-gaap/Revenues/USD/CY2024Q3I.json
```

**Rate limit**: 10 requests/second. `User-Agent` header required.

---

## Common US-GAAP Concepts

### Balance Sheet (Instant)
| Concept | Label |
|---------|-------|
| `Assets` | Total Assets |
| `CurrentAssets` | Total Current Assets |
| `CashAndCashEquivalentsAtCarryingValue` | Cash and Cash Equivalents |
| `AccountsReceivableNetCurrent` | Accounts Receivable |
| `InventoryNet` | Inventory |
| `PropertyPlantAndEquipmentNet` | PP&E |
| `Liabilities` | Total Liabilities |
| `LongTermDebt` | Long-term Debt |
| `StockholdersEquity` | Total Equity |
| `CommonStockSharesOutstanding` | Shares Outstanding |

### Income Statement (Duration)
| Concept | Label |
|---------|-------|
| `Revenues` | Total Revenue |
| `CostOfGoodsSold` / `CostOfRevenue` | Cost of Revenue |
| `GrossProfit` | Gross Profit |
| `OperatingIncomeLoss` | Operating Income |
| `NetIncomeLoss` | Net Income |
| `EarningsPerShareBasic` | Basic EPS |
| `EarningsPerShareDiluted` | Diluted EPS |

### Cash Flow Statement (Duration)
| Concept | Label |
|---------|-------|
| `NetCashProvidedByOperatingActivities` | Operating Cash Flow |
| `PaymentsToAcquirePropertyPlantAndEquipment` | CapEx |
| `PaymentsForRepurchaseOfCommonStock` | Share Buybacks |
| `PaymentsOfDividends` | Dividends Paid |

---

## File Format Reference

| Extension | Format | Description |
|-----------|--------|-------------|
| `.xbrl` | XBRL Instance | Traditional XML-based XBRL |
| `.xml` | XBRL Instance | Alternative extension for XBRL |
| `.htm` / `.html` | Inline XBRL | iXBRL — HTML with embedded tags (SEC standard since 2021) |
| `.xsd` | Schema | Taxonomy definition |
| `.zip` | Archive | Filing package or taxonomy package |

---

## Validation Rules

### SEC EFM (Electronic Filing Manual)
- Entity and document metadata completeness
- Calculation consistency
- Dimension usage rules
- Extension concept naming conventions
- Inline XBRL formatting rules
- Filing fee calculations
- Cover page requirements

### ESEF (European Single Electronic Format)
- IFRS taxonomy usage
- iXBRL rendering rules
- Mandatory element tagging
- Block tagging of notes

### Calculation Validation Modes
| Mode | Description |
|------|-------------|
| `none` | Skip calculation checking |
| `xbrl21` | Standard XBRL 2.1 rules |
| `round-to-nearest` | 10-decimal rounding tolerance |
| `truncation` | Truncation-based rounding |

---

*This primer covers the XBRL knowledge needed to effectively use arelle-mcp.*
