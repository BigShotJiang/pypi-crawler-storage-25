# Arelle MCP Server — Research & Architecture Blueprint

> Compiled research for the arelle-mcp project.  
> Date: April 2026  
> Status: Research Complete → Implementation Complete

---

## 1. Executive Summary

**Arelle** is the world's only free, open-source XBRL-certified processor (Apache 2.0 license, latest v2.39.5 on PyPI as `arelle-release`). **No MCP server wrapping Arelle exists anywhere** — not on PyPI, npm, GitHub, or any MCP registry. This represents a greenfield opportunity to create the definitive XBRL processing tool for LLMs.

The arelle-mcp server exposes 17 tools, 5 resources, and 5 prompt templates covering the complete XBRL processing lifecycle: loading, validation, fact extraction, taxonomy browsing, relationship traversal, SEC EDGAR integration, filing comparison, and financial statement rendering.

---

## 2. Arelle Architecture Deep Dive

### 2.1 MVC Architecture

Arelle follows a strict **Model-View-Controller** pattern:

- **Model Layer**: All XBRL objects — instances, DTS schemas, linkbases, formulas, facts, contexts, units
- **View Layer**: Presentation as GUI windows, files, web responses, or JSON output
- **Controller Layer** (base class `Cntlr`):
  - `CntlrCmdLine` — CLI interface (2,393 lines, every feature exposed as flags)
  - `CntlrWinMain` — Tkinter GUI
  - `CntlrWebMain` — Bottle-based REST API
  - `Session` API — Programmatic Python interface (**our integration point**)

### 2.2 The Session API

The `arelle.api.Session` class is the correct integration point for the MCP server. It provides a context manager pattern with `RuntimeOptions`:

```python
from arelle.api.Session import Session
from arelle.RuntimeOptions import RuntimeOptions

options = RuntimeOptions(
    entrypointFile="https://www.sec.gov/Archives/edgar/data/...",
    validate=True,
    keepOpen=True,  # CRITICAL: required to access models after run()
    disclosureSystemName="efm-pragmatic-all-years",
    plugins="validate/EFM",
    internetConnectivity="online",
)
with Session() as session:
    session.run(options)
    models = session.get_models()        # list[ModelXbrl]
    logs = session.get_logs("xml")       # validation log output
```

### 2.3 Critical Constraint: Single-Session Global State

**Arelle uses shared global state (`PackageManager`, `PluginManager`) that is NOT thread-safe.** Only one `Session` can run at a time per process. This is the #1 architectural constraint driving the MCP server design.

**Solution implemented:**
- `asyncio.Lock` serializes ALL Arelle operations
- `ThreadPoolExecutor(max_workers=1)` isolates Arelle work
- `run_in_executor()` prevents blocking the MCP event loop
- LRU `OrderedDict` cache with `model.close()` on eviction

### 2.4 RuntimeOptions — Complete Configuration Surface

`RuntimeOptions` exposes every Arelle capability as typed fields:

| Field | Type | Purpose |
|-------|------|---------|
| `entrypointFile` | str | Path, URL, or JSON doc set |
| `validate` | bool | Enable validation |
| `disclosureSystemName` | str | efm, esef, hmrc, gfm |
| `plugins` | str | Pipe-separated plugin list |
| `packages` | list[str] | Taxonomy package ZIP paths |
| `keepOpen` | bool | Keep models after run() |
| `internetConnectivity` | str | online/offline |
| `calcs` | str | Calculation checking mode |
| `formulaAction` | str | validate/run/none |
| `parameters` | dict | Formula parameters |
| `pluginOptions` | dict | Plugin-specific settings |
| `logFormat` | str | Log output format |

---

## 3. Complete API Surface

### 3.1 ModelXbrl — The Central Model Object

Every fact, concept, context, unit, and relationship is accessible through `ModelXbrl`:

**Core data indexes (O(1) lookup):**

| Property | Type | Purpose |
|----------|------|---------|
| `facts` | list[ModelFact] | All facts in the instance |
| `factsInInstance` | set[ModelFact] | Facts directly in instance |
| `factsByQname` | dict[QName, set[ModelFact]] | Facts by concept QName |
| `factsByLocalName` | dict[str, list[ModelFact]] | Facts by local name |
| `qnameConcepts` | dict[QName, ModelConcept] | All DTS concepts |
| `nameConcepts` | defaultdict[str, list[ModelConcept]] | Concepts by local name |
| `contexts` | dict[str, ModelContext] | All contexts by ID |
| `units` | dict[str, ModelUnit] | All units by ID |
| `urlDocs` | dict[str, ModelDocument] | All documents by URL |
| `qnameDimensionDefaults` | dict[QName, QName] | Default dimension members |
| `roleTypes` | dict[str, list[ModelRoleType]] | Role type definitions |
| `errors` | list | Captured error codes |

**Critical methods:**

```python
# Relationship navigation (cached, lazy-evaluated)
rel_set = model_xbrl.relationshipSet(arcrole, linkrole)

# Fact filtering
model_xbrl.factsByPeriodType("instant")
model_xbrl.factsByDatatype(True, typeQname)
model_xbrl.factsByDimMemQname(dimQname, memQname)

# Lifecycle
model_xbrl.close()   # Dereferences ALL attributes, frees 30-60MB
model_xbrl.reload(nextaction="loading", reloadCache=False)
```

### 3.2 ModelFact — Individual Data Points

```python
fact.concept        # → ModelConcept
fact.qname          # → QName
fact.value          # → str (raw)
fact.xValue         # → typed (Decimal, datetime, etc.)
fact.effectiveValue # → str (display-ready)
fact.contextID      # → str
fact.context        # → ModelContext (period, entity, dimensions)
fact.unitID         # → str
fact.unit           # → ModelUnit (currency/measure)
fact.decimals       # → str (precision)
fact.isNumeric      # → bool
fact.isNil          # → bool
fact.xmlLang        # → str
```

### 3.3 ModelConcept — Taxonomy Elements

```python
concept.qname           # → QName
concept.label(preferredLabel=None, fallbackToQname=True, lang="en-US")
concept.periodType      # "instant" | "duration" | None
concept.balance         # "debit" | "credit" | None
concept.isNumeric       # → bool
concept.isMonetary      # → bool
concept.isAbstract      # → bool
concept.isHypercubeItem # → bool
concept.isDimensionItem # → bool
concept.typeQname       # → QName (data type)
concept.substitutionGroupQname  # → QName
```

### 3.4 Relationship Navigation

```python
# Standard arcroles
XbrlConst.parentChild    # Presentation hierarchy
XbrlConst.summationItem  # Calculation trees
XbrlConst.conceptLabel   # Concept → label resources
XbrlConst.conceptReference  # Concept → reference resources
XbrlConst.dimensionDomain   # Dimension → domain
XbrlConst.domainMember      # Domain → member hierarchy
XbrlConst.all_              # Primary item → hypercube

# Navigation
rel_set = model_xbrl.relationshipSet(XbrlConst.parentChild, linkrole)
roots = rel_set.rootConcepts
children = rel_set.fromModelObject(concept)
parents = rel_set.toModelObject(concept)

# Each ModelRelationship:
rel.fromModelObject  # Source concept
rel.toModelObject    # Target concept
rel.order            # Decimal ordering
rel.weight           # float (calculation: +1/-1)
rel.preferredLabel   # str (presentation display)
```

### 3.5 ModelContext — Period and Dimensional Data

```python
context.entityIdentifier       # (scheme, identifier)
context.isInstantPeriod        # → bool
context.isStartEndPeriod       # → bool
context.instantDatetime        # → datetime
context.startDatetime          # → datetime
context.endDatetime            # → datetime
context.qnameDims              # dict[QName, ModelDimensionValue]
```

---

## 4. XBRL Ecosystem Context

### 4.1 What is XBRL

XBRL (eXtensible Business Reporting Language) is the global standard for machine-readable business reporting. An XBRL report contains **facts** — individual data points tagged with a **concept** from a taxonomy, a **context** (entity + time period), and optionally **units**.

**Inline XBRL (iXBRL)** embeds XBRL tags directly in HTML. Since June 2021, the SEC mandates iXBRL for all periodic filings.

### 4.2 Taxonomies

| Taxonomy | Maintainer | Purpose |
|----------|-----------|---------|
| US-GAAP | FASB | US accounting standards |
| DEI | SEC | Document/entity info (company name, CIK, filing date) |
| SRT | SEC | SEC-specific requirements beyond GAAP |
| IFRS | IASB | International Financial Reporting Standards |
| Country/STPR | SEC | Geographic code lists |

Companies create **extension taxonomies** adding custom concepts.

### 4.3 Linkbases

| Linkbase | Purpose |
|----------|---------|
| Presentation | Display order (financial statement structure) |
| Calculation | Mathematical validation (Assets = Current + Noncurrent) |
| Definition | Semantic/dimensional relationships |
| Label | Human-readable names (standard, terse, verbose, documentation) |
| Reference | Links to accounting standards |

### 4.4 XBRL Dimensions

**Hypercubes** define valid combinations of **dimensions** (axes) for primary items. Each dimension has a **domain** with **members**. Example: Revenue by `ProductOrServiceAxis` with members `SoftwareMember`, `HardwareMember`.

- **Explicit dimensions**: predefined members in taxonomy
- **Typed dimensions**: arbitrary values matching an XML type

### 4.5 SEC EDGAR API Endpoints

| API | URL | Returns |
|-----|-----|---------|
| Submissions | `data.sec.gov/submissions/CIK{CIK}.json` | Filing history, company metadata |
| Company Facts | `data.sec.gov/api/xbrl/companyfacts/CIK{CIK}.json` | All XBRL facts for a company |
| Company Concept | `data.sec.gov/api/xbrl/companyconcept/CIK{CIK}/{taxonomy}/{tag}.json` | Single concept across all filings |
| Frames | `data.sec.gov/api/xbrl/frames/{taxonomy}/{tag}/{unit}/{period}.json` | Cross-company data |

**Rate limit**: 10 requests/sec, `User-Agent` header required.

---

## 5. Arelle CLI → MCP Tool Mapping

Arelle's CLI exposes the complete feature surface through 100+ flags. Key mapping:

| CLI Group | Flags | MCP Tool(s) |
|-----------|-------|-------------|
| Input | `-f`, `--import`, `--packages` | `xbrl_load_filing` |
| Validation | `-v`, `--efm`, `--disclosureSystem`, `--calc` | `xbrl_validate` |
| Facts output | `--facts`, `--factTable` | `xbrl_extract_facts`, `xbrl_fact_details` |
| Taxonomy output | `--concepts`, `--DTS` | `xbrl_browse_taxonomy`, `xbrl_concept_details` |
| Presentation | `--pre` | `xbrl_presentation_tree` |
| Calculation | `--cal` | `xbrl_calculation_tree` |
| Dimensions | `--dim` | `xbrl_dimension_structure` |
| Formula | `--formula` | (future: xbrl_run_formula) |
| Server | `--webserver` | Built-in via MCP transport |

---

## 6. Arelle Plugin System

Plugins use a `__pluginInfo__` dict with hook-based dispatch:

| Hook | When | Use |
|------|------|-----|
| `CntlrCmdLine.Xbrl.Loaded` | After loading | Post-load processing |
| `CntlrCmdLine.Xbrl.Run` | During processing | Custom analysis |
| `Validate.XBRL.Start` | Before validation | Pre-validation checks |
| `Validate.XBRL.Finally` | After validation | Post-validation |
| `ModelDocument.PullLoader` | During load | Custom document loading |

Key built-in plugins: `validate/EFM`, `validate/ESEF`, `validate/HMRC`, `inlineXbrlDocumentSet`, `loadFromOIM` (JSON/CSV), `xbrlDB` (database), `ixbrl-viewer`.

---

## 7. Memory Management

| Filing Size | Memory Usage |
|-------------|-------------|
| Typical US-GAAP filing | 30-60MB |
| Large filing (10-K with footnotes) | 60-120MB |
| DTS comparison | Up to 4.5GB |

**Strategies implemented:**
1. LRU cache with configurable capacity (default 5 filings)
2. Explicit `model.close()` on eviction (dereferences all attributes)
3. Arelle's `WebCache` for taxonomy files
4. Taxonomy packages for offline/pre-cached operation
5. Pagination on all fact/concept listings to control payload size

---

## 8. Competitive Landscape

**No XBRL MCP server exists.** Confirmed by searching:
- PyPI: "arelle-mcp", "xbrl-mcp", "xbrl mcp server" → 0 results
- npm: "xbrl-mcp", "arelle-mcp" → 0 results
- GitHub: "arelle mcp", "xbrl mcp server" → 0 results
- MCP registries (mcp.so, glama.ai) → 0 XBRL-related servers

Related but non-overlapping projects:
- `edgartools` — SEC EDGAR Python library (no MCP, no XBRL parsing)
- `sec-api` — Commercial SEC API (no MCP)
- `py-xbrl` — Basic XBRL parsing (no validation, no MCP)

---

## 9. MCP Design Best Practices Applied

| Practice | Implementation |
|----------|---------------|
| 8-15 tools per server | 17 tools (justified by breadth of XBRL domain) |
| Tool names with service prefix | `xbrl_` prefix on all tools |
| Pydantic input validation | Every tool has a BaseModel with Field constraints |
| Pagination on list operations | offset/limit on facts, concepts, SEC data |
| Actionable error messages | Structured errors with suggestions |
| Tool annotations | readOnlyHint, destructiveHint, idempotentHint, openWorldHint |
| Lifespan pattern | ArelleManager created/destroyed with server lifecycle |
| Progress reporting | `ctx.report_progress()` on long operations |
| Resources for reference data | 5 resources for disclosure systems, concepts, primers |
| Prompt templates | 5 guided workflow templates |

---

## 10. Technical Decisions Log

| Decision | Chosen | Alternatives Considered | Rationale |
|----------|--------|------------------------|-----------|
| Framework | Official MCP SDK (`mcp` package) | Standalone FastMCP | Standard, stable, compatible with all MCP clients |
| Language | Python | TypeScript | Arelle is Python; wrapping in TS would require subprocess |
| Concurrency | asyncio.Lock + ThreadPoolExecutor | ProcessPoolExecutor, multiprocessing | Single-process constraint; thread pool sufficient |
| Caching | OrderedDict LRU | Redis, SQLite, LRU decorator | In-memory is fastest; Arelle models can't be serialized |
| SEC EDGAR | Direct httpx calls | edgartools, sec-api | Zero dependencies, full control, no API key needed |
| Transport | stdio (default) + streamable-http (optional) | SSE | SSE deprecated in MCP spec |
| Serialization | Custom serializers → JSON | Arelle's built-in CSV/JSON/XML export | LLM-optimized output; Arelle's output too verbose |

---

## 11. Future Roadmap

### v1.1
- Formula processing tool (`xbrl_run_formula`)
- XBRL-JSON and xBRL-CSV support via `loadFromOIM` plugin
- Taxonomy package management tools
- Filing export to CSV/Excel

### v1.2
- Multi-filing comparative analysis (3+ periods)
- Cross-company benchmarking via SEC EDGAR Frames API
- Database storage integration via `xbrlDB` plugin
- Interactive iXBRL viewer generation

### v2.0
- Streaming support for large filings
- Process pool for true parallel filing loading
- Pre-computed taxonomy cache distribution
- WebSocket transport for real-time updates

---

## 12. References

- [Arelle Documentation](https://arelle.readthedocs.io/)
- [Arelle GitHub](https://github.com/Arelle/Arelle)
- [Arelle Python API](https://arelle.readthedocs.io/en/latest/python_api/python_api.html)
- [MCP Specification](https://modelcontextprotocol.io/)
- [MCP Python SDK](https://github.com/modelcontextprotocol/python-sdk)
- [SEC EDGAR API](https://www.sec.gov/edgar/sec-api-documentation)
- [XBRL International](https://www.xbrl.org/)
- [US-GAAP Taxonomy](https://xbrl.fasb.org/)
