#!/bin/bash
# entrypoint.sh — Docker entrypoint for Cloud Run deployment.
#
# Workflow:
#   1. Download auth DBs from GCS (small, fast)
#   2. Start MCP server (works without cache.db — API fallback)
#   3. Download cache.db in background (large, slow)
#   4. Start background GCS sync daemon (users.db + oauth_state.db upload only)
#   5. On SIGTERM: stop MCP server, stop daemon (triggers final GCS upload)
set -euo pipefail

PORT="${PORT:-8000}"
ENABLE_DAILY_FETCH="${ENABLE_DAILY_FETCH:-}"

echo "=== jquants-mcp startup ==="
echo "PORT=${PORT}"
echo "GCS_BUCKET=${GCS_BUCKET:-<not set>}"
echo "JQUANTS_CACHE_DIR=${JQUANTS_CACHE_DIR:-/tmp}"
echo "ENABLE_DAILY_FETCH=${ENABLE_DAILY_FETCH:-false}"

# Step 1: Download auth databases from GCS (small, needed for auth)
if [ -n "${GCS_BUCKET:-}" ]; then
    echo "Downloading auth databases from GCS..."
    python /app/scripts/gcs_sync.py --init
else
    echo "GCS_BUCKET not set, skipping GCS download"
fi

# Step 2: SIGTERM / SIGINT handler
GCS_DAEMON_PID=""
MCP_PID=""
CACHE_DL_PID=""
SUPERCRONIC_PID=""

_shutdown() {
    echo "Received shutdown signal"

    # Stop MCP server
    if [ -n "${MCP_PID:-}" ]; then
        echo "Stopping MCP server (PID=${MCP_PID})..."
        kill -TERM "${MCP_PID}" 2>/dev/null || true
        wait "${MCP_PID}" 2>/dev/null || true
    fi

    # Stop cache download if still running
    if [ -n "${CACHE_DL_PID:-}" ]; then
        kill -TERM "${CACHE_DL_PID}" 2>/dev/null || true
        wait "${CACHE_DL_PID}" 2>/dev/null || true
    fi

    # Stop GCS daemon (triggers final upload via its own SIGTERM handler)
    if [ -n "${GCS_DAEMON_PID:-}" ]; then
        echo "Stopping GCS sync daemon (PID=${GCS_DAEMON_PID})..."
        kill -TERM "${GCS_DAEMON_PID}" 2>/dev/null || true
        wait "${GCS_DAEMON_PID}" 2>/dev/null || true
    fi

    # Stop supercronic if running
    if [ -n "${SUPERCRONIC_PID:-}" ]; then
        echo "Stopping supercronic (PID=${SUPERCRONIC_PID})..."
        kill -TERM "${SUPERCRONIC_PID}" 2>/dev/null || true
        wait "${SUPERCRONIC_PID}" 2>/dev/null || true
    fi

    echo "Shutdown complete"
    exit 0
}

trap _shutdown SIGTERM SIGINT

# Step 3: Start MCP server (cache.db not yet available — API fallback)
echo "Starting MCP server on port ${PORT}..."
jquants-mcp --transport streamable-http --host 0.0.0.0 --port "${PORT}" &
MCP_PID=$!
echo "MCP server started (PID=${MCP_PID})"

# Step 3b: Start supercronic for scheduled daily fetch (opt-in)
if [ "${ENABLE_DAILY_FETCH}" = "true" ] || [ "${ENABLE_DAILY_FETCH}" = "1" ]; then
    echo "Starting supercronic for daily cache fetch..."
    supercronic /app/scripts/daily-fetch.crontab &
    SUPERCRONIC_PID=$!
    echo "supercronic started (PID=${SUPERCRONIC_PID})"
fi

# Step 4: Download cache.db in background, then signal MCP server to reload
if [ -n "${GCS_BUCKET:-}" ]; then
    echo "Starting background cache.db download..."
    (
        python /app/scripts/gcs_sync.py --init-cache
        echo "cache.db download complete; signaling MCP server to reload"
        kill -HUP "${MCP_PID}" 2>/dev/null || true
    ) &
    CACHE_DL_PID=$!
fi

# Step 5: Start GCS sync daemon (uploads users.db + oauth_state.db only)
if [ -n "${GCS_BUCKET:-}" ]; then
    echo "Starting GCS sync daemon..."
    python /app/scripts/gcs_sync.py --daemon &
    GCS_DAEMON_PID=$!
    echo "GCS sync daemon started (PID=${GCS_DAEMON_PID})"
fi

# Wait for MCP server to exit
wait "${MCP_PID}"
MCP_EXIT=$?
echo "MCP server exited with code ${MCP_EXIT}"

# If MCP server exited on its own (not via SIGTERM), stop daemon and exit
if [ -n "${CACHE_DL_PID:-}" ]; then
    kill -TERM "${CACHE_DL_PID}" 2>/dev/null || true
    wait "${CACHE_DL_PID}" 2>/dev/null || true
fi
if [ -n "${GCS_DAEMON_PID:-}" ]; then
    kill -TERM "${GCS_DAEMON_PID}" 2>/dev/null || true
    wait "${GCS_DAEMON_PID}" 2>/dev/null || true
fi
if [ -n "${SUPERCRONIC_PID:-}" ]; then
    kill -TERM "${SUPERCRONIC_PID}" 2>/dev/null || true
    wait "${SUPERCRONIC_PID}" 2>/dev/null || true
fi

exit "${MCP_EXIT}"
