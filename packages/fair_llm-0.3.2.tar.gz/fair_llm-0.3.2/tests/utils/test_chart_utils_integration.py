import unittest
import sys
import json
from unittest.mock import patch, MagicMock

# Import the module under test
from fairlib.utils.chart_utils import (
    extract_structured_data, infer_chart_type, validate_chart_code,
    write_da_script, clean_llm_code
)


class TestChartUtilsIntegration(unittest.TestCase):
    """Integration tests for chart_utils module"""

    def test_basic_pipeline(self):
        """Test basic chart generation pipeline"""
        # Test data
        data = {
            "chart_type": "bar",
            "labels": ["A", "B", "C"],
            "values": [10, 20, 15]
        }

        # Test chart type inference
        query = "Show me a bar chart"
        answer = "Here is the data"
        chart_type = infer_chart_type(query, answer)
        self.assertEqual(chart_type, "bar")

        # Test JSON extraction
        json_text = f'Data: {json.dumps(data)}'
        extracted = extract_structured_data(json_text, attempt_llm_fix=False)
        self.assertEqual(extracted, data)

        # Test code validation
        valid_code = "import matplotlib.pyplot as plt\nplt.bar([1,2,3], [4,5,6])\nplt.savefig('test.png')"
        is_valid = validate_chart_code(valid_code)
        self.assertTrue(is_valid)

    def test_error_handling(self):
        """Test error handling in pipeline"""
        # Test invalid JSON
        invalid_json = "Data: {invalid json"
        result = extract_structured_data(invalid_json, attempt_llm_fix=False)
        self.assertEqual(result, {})

        # Test invalid code
        invalid_code = "import matplotlib.pyplot as plt\nplt.plot([1,2,3\nplt.savefig('test.png')"
        result = validate_chart_code(invalid_code)
        self.assertFalse(result)

    def test_code_cleaning(self):
        """Test code cleaning functionality"""
        # Test with code block
        code_with_block = "Here's the code:\n```python\nimport matplotlib.pyplot as plt\nplt.plot([1,2,3])\nplt.savefig('test.png')\n```"
        cleaned = clean_llm_code(code_with_block)
        self.assertIn("import matplotlib.pyplot as plt", cleaned)

        # Test without code block
        code_without_block = "import matplotlib.pyplot as plt\nplt.plot([1,2,3])\nplt.savefig('test.png')"
        cleaned = clean_llm_code(code_without_block)
        self.assertIn("import matplotlib.pyplot as plt", cleaned)

    def test_da_script_generation(self):
        """Test DA script generation"""
        data = {
            "chart_type": "bar",
            "labels": ["A", "B", "C"],
            "values": [10, 20, 15],
            "title": "Test Chart"
        }
        chart_code = "import matplotlib.pyplot as plt\nplt.bar([1,2,3], [4,5,6])\nplt.savefig('test.png')"
        write_da_script(data, chart_code)
        # The function writes to a file, so we just verify it doesn't raise an exception
        self.assertTrue(True)  # If we get here, the function executed successfully

    def test_chart_type_inference_variations(self):
        """Test chart type inference with various inputs"""
        test_cases = [
            ("bar chart", "bar"),
            ("line graph", "line"),
            ("pie chart", "pie"),
            ("scatter plot", "scatter"),
            ("histogram", "histogram"),
            ("unknown type", "bar")  # Default
        ]

        for query, expected in test_cases:
            with self.subTest(query=query):
                result = infer_chart_type(f"Show me a {query}", "data")
                self.assertEqual(result, expected)


if __name__ == '__main__':
    unittest.main()
