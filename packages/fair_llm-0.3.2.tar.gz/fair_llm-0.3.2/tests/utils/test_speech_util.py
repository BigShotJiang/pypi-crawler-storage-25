import unittest
import sys
import tempfile
import numpy as np
from unittest.mock import patch, MagicMock, mock_open
import torch

# Mock the external dependencies before importing speech_util
sys.modules['transformers'] = MagicMock()
sys.modules['sounddevice'] = MagicMock()
sys.modules['scipy'] = MagicMock()
sys.modules['scipy.io'] = MagicMock()
sys.modules['scipy.io.wavfile'] = MagicMock()
sys.modules['pyttsx3'] = MagicMock()

# Now import the module under test
from fairlib.utils.speech_util import SpeechUtil


class TestSpeechUtil(unittest.TestCase):
    """Test cases for SpeechUtil functionality"""

    def setUp(self):
        """Set up test fixtures before each test method."""
        # Mock torch.cuda.is_available to return False for consistent testing
        with patch('torch.cuda.is_available', return_value=False):
            with patch('torch.cuda.device_count', return_value=0):
                # Mock the transformers model and processor
                with patch('fairlib.utils.speech_util.AutoModelForSpeechSeq2Seq') as mock_model_class:
                    with patch('fairlib.utils.speech_util.AutoProcessor') as mock_processor_class:
                        with patch('fairlib.utils.speech_util.pyttsx3.init') as mock_tts_init:
                            # Set up mock objects
                            self.mock_model = MagicMock()
                            self.mock_processor = MagicMock()
                            self.mock_tts_engine = MagicMock()
                            
                            mock_model_class.from_pretrained.return_value = self.mock_model
                            mock_processor_class.from_pretrained.return_value = self.mock_processor
                            mock_tts_init.return_value = self.mock_tts_engine
                            
                            # Initialize SpeechUtil
                            self.speech_util = SpeechUtil()

    def test_initialization_default_model(self):
        """Test SpeechUtil initialization with default model name."""
        with patch('torch.cuda.is_available', return_value=False):
            with patch('fairlib.utils.speech_util.AutoModelForSpeechSeq2Seq') as mock_model_class:
                with patch('fairlib.utils.speech_util.AutoProcessor') as mock_processor_class:
                    with patch('fairlib.utils.speech_util.pyttsx3.init') as mock_tts_init:
                        mock_model = MagicMock()
                        mock_processor = MagicMock()
                        mock_tts_engine = MagicMock()
                        
                        mock_model_class.from_pretrained.return_value = mock_model
                        mock_processor_class.from_pretrained.return_value = mock_processor
                        mock_tts_init.return_value = mock_tts_engine
                        
                        speech_util = SpeechUtil()
                        
                        # Verify initialization
                        self.assertEqual(speech_util.device, "cpu")
                        self.assertEqual(speech_util.torch_dtype, torch.float32)
                        self.assertEqual(speech_util.model, mock_model)
                        self.assertEqual(speech_util.processor, mock_processor)
                        self.assertEqual(speech_util.tts_engine, mock_tts_engine)
                        
                        # Verify model was loaded with correct parameters
                        mock_model_class.from_pretrained.assert_called_once_with(
                            "openai/whisper-large-v3",
                            torch_dtype=torch.float32,
                            low_cpu_mem_usage=True,
                            use_safetensors=True
                        )
                        mock_processor_class.from_pretrained.assert_called_once_with("openai/whisper-large-v3")

    def test_initialization_custom_model(self):
        """Test SpeechUtil initialization with custom model name."""
        custom_model = "openai/whisper-small"
        
        with patch('torch.cuda.is_available', return_value=False):
            with patch('fairlib.utils.speech_util.AutoModelForSpeechSeq2Seq') as mock_model_class:
                with patch('fairlib.utils.speech_util.AutoProcessor') as mock_processor_class:
                    with patch('fairlib.utils.speech_util.pyttsx3.init') as mock_tts_init:
                        mock_model = MagicMock()
                        mock_processor = MagicMock()
                        mock_tts_engine = MagicMock()
                        
                        mock_model_class.from_pretrained.return_value = mock_model
                        mock_processor_class.from_pretrained.return_value = mock_processor
                        mock_tts_init.return_value = mock_tts_engine
                        
                        speech_util = SpeechUtil(model_name=custom_model)
                        
                        # Verify custom model was used
                        mock_model_class.from_pretrained.assert_called_once_with(
                            custom_model,
                            torch_dtype=torch.float32,
                            low_cpu_mem_usage=True,
                            use_safetensors=True
                        )
                        mock_processor_class.from_pretrained.assert_called_once_with(custom_model)

    def test_initialization_with_cuda(self):
        """Test SpeechUtil initialization when CUDA is available."""
        with patch('torch.cuda.is_available', return_value=True):
            with patch('fairlib.utils.speech_util.AutoModelForSpeechSeq2Seq') as mock_model_class:
                with patch('fairlib.utils.speech_util.AutoProcessor') as mock_processor_class:
                    with patch('fairlib.utils.speech_util.pyttsx3.init') as mock_tts_init:
                        mock_model = MagicMock()
                        mock_processor = MagicMock()
                        mock_tts_engine = MagicMock()
                        
                        mock_model_class.from_pretrained.return_value = mock_model
                        mock_processor_class.from_pretrained.return_value = mock_processor
                        mock_tts_init.return_value = mock_tts_engine
                        
                        speech_util = SpeechUtil()
                        
                        # Verify CUDA settings
                        self.assertEqual(speech_util.device, "cuda:0")
                        self.assertEqual(speech_util.torch_dtype, torch.float16)
                        
                        # Verify model was loaded with CUDA parameters
                        mock_model_class.from_pretrained.assert_called_once_with(
                            "openai/whisper-large-v3",
                            torch_dtype=torch.float16,
                            low_cpu_mem_usage=True,
                            use_safetensors=True
                        )

    @patch('sounddevice.rec')
    @patch('sounddevice.wait')
    @patch('fairlib.utils.speech_util.write')
    @patch('tempfile.NamedTemporaryFile')
    def test_record_and_transcribe_success(self, mock_temp_file, mock_write, mock_wait, mock_rec):
        """Test successful recording and transcription."""
        # Set up mocks
        mock_recording = np.random.rand(80000).astype('float32')  # 5 seconds at 16kHz
        mock_rec.return_value = mock_recording
        
        mock_temp_file_instance = MagicMock()
        mock_temp_file_instance.name = "/tmp/test.wav"
        mock_temp_file.return_value.__enter__.return_value = mock_temp_file_instance
        
        # Mock processor and model responses
        mock_inputs = MagicMock()
        mock_inputs.input_features = MagicMock()
        self.mock_processor.return_value = mock_inputs
        
        mock_generated_ids = MagicMock()
        self.mock_model.generate.return_value = mock_generated_ids
        self.mock_processor.batch_decode.return_value = ["Hello, this is a test transcription"]
        
        # Execute the method
        result = self.speech_util.record_and_transcribe(duration=5, fs=16000)
        
        # Verify the result
        self.assertEqual(result, "Hello, this is a test transcription")
        
        # Verify method calls
        mock_rec.assert_called_once_with(80000, samplerate=16000, channels=1, dtype='float32')
        mock_wait.assert_called_once()
        mock_write.assert_called_once_with("/tmp/test.wav", 16000, mock_recording)
        self.mock_processor.assert_called_once_with("/tmp/test.wav", return_tensors="pt", sampling_rate=16000)
        self.mock_model.generate.assert_called_once()
        self.mock_processor.batch_decode.assert_called_once_with(mock_generated_ids, skip_special_tokens=True)

    @patch('sounddevice.rec')
    @patch('sounddevice.wait')
    def test_record_and_transcribe_keyboard_interrupt(self, mock_wait, mock_rec):
        """Test recording interruption with KeyboardInterrupt."""
        # Mock KeyboardInterrupt during recording
        mock_rec.side_effect = KeyboardInterrupt()
        
        result = self.speech_util.record_and_transcribe(duration=5, fs=16000)
        
        # Verify empty result on interruption
        self.assertEqual(result, "")

    @patch('sounddevice.rec')
    @patch('sounddevice.wait')
    @patch('fairlib.utils.speech_util.write')
    @patch('tempfile.NamedTemporaryFile')
    def test_record_and_transcribe_custom_parameters(self, mock_temp_file, mock_write, mock_wait, mock_rec):
        """Test recording with custom duration and sampling frequency."""
        # Set up mocks
        mock_recording = np.random.rand(32000).astype('float32')  # 2 seconds at 16kHz
        mock_rec.return_value = mock_recording
        
        mock_temp_file_instance = MagicMock()
        mock_temp_file_instance.name = "/tmp/test.wav"
        mock_temp_file.return_value.__enter__.return_value = mock_temp_file_instance
        
        mock_inputs = MagicMock()
        mock_inputs.input_features = MagicMock()
        self.mock_processor.return_value = mock_inputs
        
        mock_generated_ids = MagicMock()
        self.mock_model.generate.return_value = mock_generated_ids
        self.mock_processor.batch_decode.return_value = ["Custom test"]
        
        # Execute with custom parameters
        result = self.speech_util.record_and_transcribe(duration=2, fs=8000)
        
        self.assertEqual(result, "Custom test")
        
        # Verify custom parameters were used
        mock_rec.assert_called_once_with(16000, samplerate=8000, channels=1, dtype='float32')

    def test_get_available_voices(self):
        """Test getting available voices."""
        # Mock voices
        mock_voices = [MagicMock(), MagicMock()]
        self.mock_tts_engine.getProperty.return_value = mock_voices
        
        result = self.speech_util.get_available_voices()
        
        self.assertEqual(result, mock_voices)
        self.mock_tts_engine.getProperty.assert_called_once_with('voices')

    def test_set_voice(self):
        """Test setting voice for text-to-speech."""
        voice_id = "com.apple.speech.synthesis.voice.Alex"
        
        self.speech_util.set_voice(voice_id)
        
        # Verify the voice was set
        self.mock_tts_engine.setProperty.assert_called_once_with('voice', voice_id)

    def test_set_speech_rate(self):
        """Test setting speech rate for text-to-speech."""
        rate = 150
        
        self.speech_util.set_speech_rate(rate)
        
        # Verify the rate was set
        self.mock_tts_engine.setProperty.assert_called_once_with('rate', rate)

    def test_speak(self):
        """Test text-to-speech functionality."""
        text = "Hello, this is a test message."
        
        self.speech_util.speak(text)
        
        # Verify the text was spoken
        self.mock_tts_engine.say.assert_called_once_with(text)
        self.mock_tts_engine.runAndWait.assert_called_once()

    def test_speak_empty_text(self):
        """Test speaking empty text."""
        text = ""
        
        self.speech_util.speak(text)
        
        # Verify the empty text was still processed
        self.mock_tts_engine.say.assert_called_once_with(text)
        self.mock_tts_engine.runAndWait.assert_called_once()

    def test_speak_unicode_text(self):
        """Test speaking text with unicode characters."""
        text = "Hello 世界! This is a test with unicode: ñáéíóú"
        
        self.speech_util.speak(text)
        
        # Verify the unicode text was processed
        self.mock_tts_engine.say.assert_called_once_with(text)
        self.mock_tts_engine.runAndWait.assert_called_once()

    @patch('sounddevice.rec')
    @patch('sounddevice.wait')
    @patch('fairlib.utils.speech_util.write')
    @patch('tempfile.NamedTemporaryFile')
    def test_record_and_transcribe_whitespace_handling(self, mock_temp_file, mock_write, mock_wait, mock_rec):
        """Test that transcription properly strips whitespace."""
        # Set up mocks
        mock_recording = np.random.rand(80000).astype('float32')
        mock_rec.return_value = mock_recording
        
        mock_temp_file_instance = MagicMock()
        mock_temp_file_instance.name = "/tmp/test.wav"
        mock_temp_file.return_value.__enter__.return_value = mock_temp_file_instance
        
        # Mock processor and model responses with whitespace
        mock_inputs = MagicMock()
        mock_inputs.input_features = MagicMock()
        self.mock_processor.return_value = mock_inputs
        
        mock_generated_ids = MagicMock()
        self.mock_model.generate.return_value = mock_generated_ids
        self.mock_processor.batch_decode.return_value = ["   Hello world   "]
        
        result = self.speech_util.record_and_transcribe(duration=5, fs=16000)
        
        # Verify whitespace was stripped
        self.assertEqual(result, "Hello world")

    def test_model_to_device_called(self):
        """Test that model.to() is called with the correct device."""
        with patch('torch.cuda.is_available', return_value=False):
            with patch('fairlib.utils.speech_util.AutoModelForSpeechSeq2Seq') as mock_model_class:
                with patch('fairlib.utils.speech_util.AutoProcessor') as mock_processor_class:
                    with patch('fairlib.utils.speech_util.pyttsx3.init') as mock_tts_init:
                        mock_model = MagicMock()
                        mock_processor = MagicMock()
                        mock_tts_engine = MagicMock()
                        
                        mock_model_class.from_pretrained.return_value = mock_model
                        mock_processor_class.from_pretrained.return_value = mock_processor
                        mock_tts_init.return_value = mock_tts_engine
                        
                        speech_util = SpeechUtil()
                        
                        # Verify model.to() was called
                        mock_model.to.assert_called_once_with("cpu")

    def test_model_to_device_cuda(self):
        """Test that model.to() is called with CUDA device when available."""
        with patch('torch.cuda.is_available', return_value=True):
            with patch('fairlib.utils.speech_util.AutoModelForSpeechSeq2Seq') as mock_model_class:
                with patch('fairlib.utils.speech_util.AutoProcessor') as mock_processor_class:
                    with patch('fairlib.utils.speech_util.pyttsx3.init') as mock_tts_init:
                        mock_model = MagicMock()
                        mock_processor = MagicMock()
                        mock_tts_engine = MagicMock()
                        
                        mock_model_class.from_pretrained.return_value = mock_model
                        mock_processor_class.from_pretrained.return_value = mock_processor
                        mock_tts_init.return_value = mock_tts_engine
                        
                        speech_util = SpeechUtil()
                        
                        # Verify model.to() was called with CUDA device
                        mock_model.to.assert_called_once_with("cuda:0")


if __name__ == '__main__':
    unittest.main()