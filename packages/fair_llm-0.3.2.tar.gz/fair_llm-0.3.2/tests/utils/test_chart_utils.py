import unittest
import sys
import json
import subprocess
from unittest.mock import patch, MagicMock
from io import StringIO

# Import the module under test
from fairlib.utils.chart_utils import (
    extract_structured_data, perform_chart_focused_eda, infer_chart_type,
    generate_code_for_chart_visualization, write_da_script, run_da_script_capture_error,
    generate_chart, fix_chart_code_llm, clean_llm_code, validate_chart_code
)


class TestChartUtils(unittest.TestCase):
    """Test cases for chart_utils module"""

    def setUp(self):
        """Set up test fixtures"""
        # Reset any module-level state
        pass

    def test_extract_structured_data_valid_json(self):
        """Test extracting structured data from valid JSON"""
        data = {"chart_type": "bar", "labels": ["A", "B"], "values": [1, 2]}
        json_text = f'Data: {json.dumps(data)}'
        result = extract_structured_data(json_text, attempt_llm_fix=False)
        self.assertEqual(result, data)

    def test_extract_structured_data_invalid_json(self):
        """Test extracting structured data from invalid JSON"""
        invalid_json = "Data: {invalid json"
        result = extract_structured_data(invalid_json, attempt_llm_fix=False)
        self.assertEqual(result, {})

    def test_infer_chart_type_bar(self):
        """Test chart type inference for bar chart"""
        query = "Show me a bar chart"
        answer = "Here is the data"
        result = infer_chart_type(query, answer)
        self.assertEqual(result, "bar")

    def test_infer_chart_type_line(self):
        """Test chart type inference for line chart"""
        query = "Create a line chart"
        answer = "Here is the data"
        result = infer_chart_type(query, answer)
        self.assertEqual(result, "line")

    def test_infer_chart_type_pie(self):
        """Test chart type inference for pie chart"""
        query = "Display as pie chart"
        answer = "Here is the data"
        result = infer_chart_type(query, answer)
        self.assertEqual(result, "pie")

    def test_infer_chart_type_default(self):
        """Test chart type inference with no keywords"""
        query = "Show me some data"
        answer = "Here is the data"
        result = infer_chart_type(query, answer)
        self.assertEqual(result, "bar")  # Default should be bar

    def test_clean_llm_code_with_code_block(self):
        """Test cleaning LLM code with code block"""
        code_text = "Here's the code:\n```python\nimport matplotlib.pyplot as plt\nplt.plot([1,2,3])\nplt.savefig('test.png')\n```"
        result = clean_llm_code(code_text)
        self.assertIn("import matplotlib.pyplot as plt", result)

    def test_clean_llm_code_without_code_block(self):
        """Test cleaning LLM code without code block"""
        code_text = "import matplotlib.pyplot as plt\nplt.plot([1,2,3])\nplt.savefig('test.png')"
        result = clean_llm_code(code_text)
        self.assertIn("import matplotlib.pyplot as plt", result)

    def test_validate_chart_code_valid(self):
        """Test validating valid chart code"""
        valid_code = "import matplotlib.pyplot as plt\nplt.plot([1,2,3])\nplt.savefig('test.png')"
        result = validate_chart_code(valid_code)
        self.assertTrue(result)

    def test_validate_chart_code_invalid_syntax(self):
        """Test validating invalid chart code"""
        invalid_code = "import matplotlib.pyplot as plt\nplt.plot([1,2,3\nplt.savefig('test.png')"
        result = validate_chart_code(invalid_code)
        self.assertFalse(result)

    @patch('subprocess.run')
    def test_run_da_script_capture_error_success(self, mock_run):
        """Test running DA script successfully"""
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="Script executed successfully"
        )
        success, output = run_da_script_capture_error()
        self.assertTrue(success)
        self.assertIn("Script executed successfully", output)

    @patch('subprocess.run')
    def test_run_da_script_capture_error_failure(self, mock_run):
        """Test running DA script with failure"""
        mock_run.side_effect = subprocess.CalledProcessError(1, "python test_da.py")
        success, output = run_da_script_capture_error()
        self.assertFalse(success)
        self.assertIn("Script Execution Error", output)

    def test_write_da_script_basic(self):
        """Test writing DA script with basic data"""
        data = {"chart_type": "bar", "labels": ["A", "B"], "values": [1, 2]}
        chart_code = "import matplotlib.pyplot as plt\nplt.bar([1,2], [1,2])\nplt.savefig('test.png')"
        write_da_script(data, chart_code)
        # The function writes to a file, so we just verify it doesn't raise an exception
        self.assertTrue(True)  # If we get here, the function executed successfully

    def test_write_da_script_with_title(self):
        """Test writing DA script with title"""
        data = {
            "chart_type": "bar",
            "labels": ["A", "B"],
            "values": [1, 2],
            "title": "Test Chart"
        }
        chart_code = "import matplotlib.pyplot as plt\nplt.bar([1,2], [1,2])\nplt.savefig('test.png')"
        write_da_script(data, chart_code)
        self.assertTrue(True)  # If we get here, the function executed successfully

    def test_write_da_script_empty_data(self):
        """Test writing DA script with empty data"""
        data = {}
        chart_code = "import matplotlib.pyplot as plt\nplt.bar([1,2], [1,2])\nplt.savefig('test.png')"
        write_da_script(data, chart_code)
        self.assertTrue(True)  # If we get here, the function executed successfully

    @patch('fairlib.utils.chart_utils.MAX_EDA_SUMMARY_FOR_CHART_CODE_GEN', 1000)
    @patch('fairlib.utils.chart_utils.MAX_ANSWER_CONTEXT_FOR_CHART_CODE_GEN', 1000)
    @patch('fairlib.utils.chart_utils.CHART_IMAGE_OUTPUT_FILENAME', 'test_chart.png')
    def test_generate_code_for_chart_visualization(self):
        """Test generating code for chart visualization"""
        # Create a mock LLM model
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = "import matplotlib.pyplot as plt\nplt.bar([1,2,3], [4,5,6])\nplt.savefig('chart.png')"
        
        result = generate_code_for_chart_visualization(
            final_answer_text="Here is the data",
            chart_eda_summary="EDA analysis complete",
            data_vars_info_for_prompt_str="Data variables info",
            user_query="Show me a bar chart",
            actual_chart_type="bar",
            json_extracted_data_is_sufficient=True,
            llm_model=mock_llm
        )
        self.assertIsInstance(result, str)
        self.assertIn("import matplotlib.pyplot as plt", result)

    def test_fix_chart_code_llm(self):
        """Test fixing chart code with LLM"""
        # Create a mock LLM model
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = "import matplotlib.pyplot as plt\nplt.bar([1,2,3], [4,5,6])\nplt.savefig('chart.png')"
        
        broken_code = "import matplotlib.pyplot as plt\nplt.bar([1,2,3\nplt.savefig('chart.png')"
        result = fix_chart_code_llm(
            original_code=broken_code,
            error_message="Syntax error",
            user_query="Show me a bar chart",
            chart_type="bar",
            data_vars_info_str="Data variables info",
            json_extracted_data_is_sufficient=True,
            llm_model=mock_llm
        )
        self.assertIsInstance(result, str)
        self.assertIn("import matplotlib.pyplot as plt", result)

    def test_perform_chart_focused_eda(self):
        """Test performing chart-focused EDA"""
        # Create a mock LLM model
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = "EDA analysis complete"
        
        documents = ["Document 1", "Document 2"]
        query = "Show me a bar chart"
        result = perform_chart_focused_eda(documents, query, llm_model=mock_llm)
        self.assertIsInstance(result, str)

    @patch('subprocess.run')
    def test_generate_chart(self, mock_run):
        """Test generating chart"""
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="Script executed successfully"
        )
        chart_code = "import matplotlib.pyplot as plt\nplt.bar([1,2,3], [4,5,6])\nplt.savefig('chart.png')"
        data = {"chart_type": "bar", "labels": ["A", "B"], "values": [1, 2]}
        success, output = generate_chart(chart_code, data)
        self.assertIsInstance(success, bool)
        self.assertIsInstance(output, str)


if __name__ == '__main__':
    unittest.main()