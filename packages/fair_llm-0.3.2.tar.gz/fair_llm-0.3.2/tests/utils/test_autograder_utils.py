#!/usr/bin/env python3
"""
Unit tests for autograder_utils.py

These tests ensure the autograder utilities work correctly and provide
consistent, reliable grading results.
"""

import json
import pytest
import tempfile
import os
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
from typing import List, Dict

# Import the modules to test
from fairlib.utils.autograder_utils import (
    setup_knowledge_base,
    create_agent,
    format_report,
    FinalGrade,
    GradingCriterion,
    GradeAggregator,
    aggregate_and_format_report,
    run_consistent_grading,
    set_global_seed,
    configure_llm_deterministic
)


class TestGradingModels:
    """Test cases for Pydantic grading models."""
    
    def test_grading_criterion_creation(self):
        """Test creating a GradingCriterion."""
        criterion = GradingCriterion(
            criterion="Thesis Statement",
            score=8,
            max_score=10,
            justification="Strong, clear thesis that guides the essay."
        )
        
        assert criterion.criterion == "Thesis Statement"
        assert criterion.score == 8
        assert criterion.max_score == 10
        assert criterion.justification == "Strong, clear thesis that guides the essay."
    
    def test_final_grade_creation(self):
        """Test creating a FinalGrade."""
        criteria = [
            GradingCriterion(
                criterion="Thesis Statement",
                score=8,
                max_score=10,
                justification="Strong thesis."
            ),
            GradingCriterion(
                criterion="Evidence",
                score=7,
                max_score=10,
                justification="Good evidence used."
            )
        ]
        
        grade = FinalGrade(
            graded_criteria=criteria,
            overall_feedback="Good essay with room for improvement.",
            final_score=15
        )
        
        assert len(grade.graded_criteria) == 2
        assert grade.final_score == 15
        assert grade.overall_feedback == "Good essay with room for improvement."
    
    def test_final_grade_validation(self):
        """Test that FinalGrade validates correctly."""
        criteria = [
            GradingCriterion(
                criterion="Test",
                score=5,
                max_score=10,
                justification="Test justification."
            )
        ]
        
        # This should not raise an exception
        grade = FinalGrade(
            graded_criteria=criteria,
            overall_feedback="Test feedback.",
            final_score=5
        )
        
        assert grade.final_score == 5


class TestGradeAggregator:
    """Test cases for GradeAggregator class."""
    
    def create_test_grades(self) -> List[FinalGrade]:
        """Helper method to create test grades."""
        return [
            FinalGrade(
                graded_criteria=[
                    GradingCriterion(
                        criterion="Thesis",
                        score=8,
                        max_score=10,
                        justification="Good thesis"
                    ),
                    GradingCriterion(
                        criterion="Evidence",
                        score=7,
                        max_score=10,
                        justification="Good evidence"
                    )
                ],
                overall_feedback="Good essay",
                final_score=15
            ),
            FinalGrade(
                graded_criteria=[
                    GradingCriterion(
                        criterion="Thesis",
                        score=9,
                        max_score=10,
                        justification="Excellent thesis"
                    ),
                    GradingCriterion(
                        criterion="Evidence",
                        score=6,
                        max_score=10,
                        justification="Adequate evidence"
                    )
                ],
                overall_feedback="Very good essay",
                final_score=15
            ),
            FinalGrade(
                graded_criteria=[
                    GradingCriterion(
                        criterion="Thesis",
                        score=7,
                        max_score=10,
                        justification="Decent thesis"
                    ),
                    GradingCriterion(
                        criterion="Evidence",
                        score=8,
                        max_score=10,
                        justification="Strong evidence"
                    )
                ],
                overall_feedback="Solid essay",
                final_score=15
            )
        ]
    
    def test_aggregate_median(self):
        """Test median aggregation method."""
        grades = self.create_test_grades()
        result = GradeAggregator.aggregate(grades, method="median")
        
        # Thesis scores: 8, 9, 7 -> median = 8
        # Evidence scores: 7, 6, 8 -> median = 7
        thesis_criterion = next(c for c in result.graded_criteria if c.criterion == "Thesis")
        evidence_criterion = next(c for c in result.graded_criteria if c.criterion == "Evidence")
        
        assert thesis_criterion.score == 8
        assert evidence_criterion.score == 7
        assert result.final_score == 15  # 8 + 7
    
    def test_aggregate_mean(self):
        """Test mean aggregation method."""
        grades = self.create_test_grades()
        result = GradeAggregator.aggregate(grades, method="mean")
        
        # Thesis scores: 8, 9, 7 -> mean = 8
        # Evidence scores: 7, 6, 8 -> mean = 7
        thesis_criterion = next(c for c in result.graded_criteria if c.criterion == "Thesis")
        evidence_criterion = next(c for c in result.graded_criteria if c.criterion == "Evidence")
        
        assert thesis_criterion.score == 8
        assert evidence_criterion.score == 7
        assert result.final_score == 15
    
    def test_aggregate_trimmed_mean(self):
        """Test trimmed mean aggregation method."""
        grades = self.create_test_grades()
        result = GradeAggregator.aggregate(grades, method="trimmed_mean")
        
        # With 3 samples, 20% trimmed mean should remove 1 sample (0.6 rounded down)
        # So it should behave like median in this case
        thesis_criterion = next(c for c in result.graded_criteria if c.criterion == "Thesis")
        evidence_criterion = next(c for c in result.graded_criteria if c.criterion == "Evidence")
        
        assert thesis_criterion.score == 8
        assert evidence_criterion.score == 7
    
    def test_aggregate_robust_median(self):
        """Test robust median aggregation method with outlier detection."""
        # Create grades with an outlier
        grades = [
            FinalGrade(
                graded_criteria=[
                    GradingCriterion(criterion="Test", score=8, max_score=10, justification="Good")
                ],
                overall_feedback="Good",
                final_score=8
            ),
            FinalGrade(
                graded_criteria=[
                    GradingCriterion(criterion="Test", score=9, max_score=10, justification="Very good")
                ],
                overall_feedback="Very good",
                final_score=9
            ),
            FinalGrade(
                graded_criteria=[
                    GradingCriterion(criterion="Test", score=2, max_score=10, justification="Poor")  # Outlier
                ],
                overall_feedback="Poor",
                final_score=2
            ),
            FinalGrade(
                graded_criteria=[
                    GradingCriterion(criterion="Test", score=8, max_score=10, justification="Good")
                ],
                overall_feedback="Good",
                final_score=8
            )
        ]
        
        result = GradeAggregator.aggregate(grades, method="robust_median")
        test_criterion = next(c for c in result.graded_criteria if c.criterion == "Test")
        
        # Should use median of non-outlier scores (8, 9, 8) = 8
        assert test_criterion.score == 8
    
    def test_aggregate_empty_list(self):
        """Test that empty grade list raises ValueError."""
        with pytest.raises(ValueError, match="No grades provided for aggregation"):
            GradeAggregator.aggregate([], method="median")
    
    def test_aggregate_invalid_method(self):
        """Test that invalid aggregation method raises ValueError."""
        grades = self.create_test_grades()
        with pytest.raises(ValueError, match="Unsupported aggregation method"):
            GradeAggregator.aggregate(grades, method="invalid_method")
    
    def test_aggregate_from_json(self):
        """Test aggregation from JSON strings."""
        grades = self.create_test_grades()
        json_list = [grade.model_dump_json() for grade in grades]
        
        result = GradeAggregator.aggregate_from_json(json_list, method="median")
        
        thesis_criterion = next(c for c in result.graded_criteria if c.criterion == "Thesis")
        evidence_criterion = next(c for c in result.graded_criteria if c.criterion == "Evidence")
        
        assert thesis_criterion.score == 8
        assert evidence_criterion.score == 7
    
    def test_aggregate_from_json_with_invalid(self):
        """Test aggregation with some invalid JSON entries."""
        grades = self.create_test_grades()
        json_list = [grade.model_dump_json() for grade in grades]
        json_list.append("invalid json")
        json_list.append('{"error": "test error"}')
        
        result = GradeAggregator.aggregate_from_json(json_list, method="median")
        
        # Should still work with valid grades
        assert len(result.graded_criteria) == 2
        assert result.final_score == 15
    
    def test_calculate_grade_statistics(self):
        """Test grade statistics calculation."""
        grades = self.create_test_grades()
        stats = GradeAggregator.calculate_grade_statistics(grades)
        
        assert "Thesis" in stats
        assert "Evidence" in stats
        
        thesis_stats = stats["Thesis"]
        assert thesis_stats["mean"] == 8.0  # (8+9+7)/3
        assert thesis_stats["median"] == 8.0
        assert thesis_stats["min"] == 7
        assert thesis_stats["max"] == 9
        assert thesis_stats["count"] == 3
        
        evidence_stats = stats["Evidence"]
        assert evidence_stats["mean"] == 7.0  # (7+6+8)/3
        assert evidence_stats["median"] == 7.0
        assert evidence_stats["min"] == 6
        assert evidence_stats["max"] == 8
        assert evidence_stats["count"] == 3
    
    def test_consistency_threshold(self):
        """Test consistency threshold checking."""
        # Create grades with high variability
        grades = [
            FinalGrade(
                graded_criteria=[
                    GradingCriterion(criterion="Test", score=2, max_score=10, justification="Poor")
                ],
                overall_feedback="Poor",
                final_score=2
            ),
            FinalGrade(
                graded_criteria=[
                    GradingCriterion(criterion="Test", score=9, max_score=10, justification="Excellent")
                ],
                overall_feedback="Excellent",
                final_score=9
            )
        ]
        
        # Should include consistency warning
        result = GradeAggregator.aggregate(grades, method="median", consistency_threshold=0.8)
        assert "CONSISTENCY WARNINGS:" in result.overall_feedback
        assert "Low consistency for 'Test'" in result.overall_feedback


class TestFormatReport:
    """Test cases for format_report function."""
    
    def test_format_report_valid_grade(self):
        """Test formatting a valid grade."""
        grade = FinalGrade(
            graded_criteria=[
                GradingCriterion(
                    criterion="Thesis",
                    score=8,
                    max_score=10,
                    justification="Good thesis statement."
                )
            ],
            overall_feedback="Overall, this is a good essay.",
            final_score=8
        )
        
        result = format_report(grade.model_dump_json(), "test_essay.txt")
        
        assert "GRADE REPORT FOR: test_essay.txt" in result
        assert "FINAL SCORE: 8 / 10" in result
        assert "Overall, this is a good essay." in result
        assert "Thesis (8/10): Good thesis statement." in result
    
    def test_format_report_error_json(self):
        """Test formatting an error JSON."""
        error_json = json.dumps({"error": "Failed to grade essay"})
        result = format_report(error_json, "test_essay.txt")
        
        assert "GRADE REPORT FOR: test_essay.txt" in result
        assert "[ERROR]" in result
        assert "Failed to grade essay" in result
    
    def test_format_report_invalid_json(self):
        """Test formatting invalid JSON."""
        result = format_report("invalid json", "test_essay.txt")
        
        assert "GRADE REPORT FOR: test_essay.txt" in result
        assert "[ERROR]" in result
        assert "Could not parse" in result


class TestDeterminism:
    """Test cases for determinism utilities."""
    
    def test_set_global_seed(self):
        """Test setting global seed."""
        # This should not raise any exceptions
        set_global_seed(42)
        set_global_seed(None)
    
    def test_set_global_seed_with_torch(self):
        """Test setting global seed with PyTorch available."""
        # Skip this test for now as mocking torch is complex
        pytest.skip("Torch test requires complex mocking setup")
    
    def test_configure_llm_deterministic(self):
        """Test configuring LLM for deterministic behavior."""
        mock_llm = Mock()
        mock_llm.temperature = 0.5
        mock_llm.top_p = 0.9
        
        configure_llm_deterministic(mock_llm, temperature=0.0, top_p=1.0, seed=42)
        
        assert mock_llm.temperature == 0.0
        assert mock_llm.top_p == 1.0
        assert mock_llm.seed == 42
    
    def test_configure_llm_deterministic_with_method(self):
        """Test configuring LLM using configuration method."""
        mock_llm = Mock()
        mock_llm.set_sampling_params = Mock()
        
        configure_llm_deterministic(mock_llm, temperature=0.0, top_p=1.0, seed=42)
        
        mock_llm.set_sampling_params.assert_called_with(
            temperature=0.0, top_p=1.0, seed=42
        )


class TestAggregateAndFormatReport:
    """Test cases for aggregate_and_format_report function."""
    
    def test_aggregate_and_format_report_success(self):
        """Test successful aggregation and formatting."""
        grades = [
            FinalGrade(
                graded_criteria=[
                    GradingCriterion(
                        criterion="Thesis",
                        score=8,
                        max_score=10,
                        justification="Good thesis"
                    )
                ],
                overall_feedback="Good essay",
                final_score=8
            ),
            FinalGrade(
                graded_criteria=[
                    GradingCriterion(
                        criterion="Thesis",
                        score=9,
                        max_score=10,
                        justification="Excellent thesis"
                    )
                ],
                overall_feedback="Very good essay",
                final_score=9
            )
        ]
        
        json_list = [grade.model_dump_json() for grade in grades]
        result = aggregate_and_format_report(json_list, "test_essay.txt", method="median")
        
        assert "GRADE REPORT FOR: test_essay.txt" in result
        assert "FINAL SCORE: 8 / 10" in result  # median of 8 and 9 is 8
    
    def test_aggregate_and_format_report_failure(self):
        """Test aggregation failure handling."""
        result = aggregate_and_format_report([], "test_essay.txt", method="median")
        
        assert "GRADE REPORT FOR: test_essay.txt" in result
        assert "[ERROR]" in result
        assert "Failed to aggregate grades" in result
    
    def test_aggregate_and_format_report_with_consistency_threshold(self):
        """Test aggregation with consistency threshold."""
        grades = [
            FinalGrade(
                graded_criteria=[
                    GradingCriterion(criterion="Test", score=2, max_score=10, justification="Poor")
                ],
                overall_feedback="Poor",
                final_score=2
            ),
            FinalGrade(
                graded_criteria=[
                    GradingCriterion(criterion="Test", score=9, max_score=10, justification="Excellent")
                ],
                overall_feedback="Excellent",
                final_score=9
            )
        ]
        
        json_list = [grade.model_dump_json() for grade in grades]
        result = aggregate_and_format_report(json_list, "test_essay.txt", method="median", consistency_threshold=0.8)
        
        assert "GRADE REPORT FOR: test_essay.txt" in result
        assert "CONSISTENCY WARNINGS:" in result


class TestRunConsistentGrading:
    """Test cases for run_consistent_grading function."""
    
    @pytest.mark.asyncio
    async def test_run_consistent_grading_success(self):
        """Test successful consistent grading."""
        # Mock grading function
        async def mock_grading_function(submission, rubric):
            return FinalGrade(
                graded_criteria=[
                    GradingCriterion(criterion="Test", score=8, max_score=10, justification="Good")
                ],
                overall_feedback="Good submission",
                final_score=8
            ).model_dump_json()
        
        submission = "Test submission"
        rubric = "Test rubric"
        
        result = await run_consistent_grading(mock_grading_function, submission, rubric, num_runs=2)
        
        assert isinstance(result, FinalGrade)
        assert result.final_score == 8
        assert len(result.graded_criteria) == 1
    
    @pytest.mark.asyncio
    async def test_run_consistent_grading_with_variability(self):
        """Test consistent grading with variable results."""
        call_count = 0
        
        async def variable_grading_function(submission, rubric):
            nonlocal call_count
            call_count += 1
            # Return different scores on different calls
            scores = [7, 9, 8]  # Some variability
            score = scores[(call_count - 1) % len(scores)]
            return FinalGrade(
                graded_criteria=[
                    GradingCriterion(criterion="Test", score=score, max_score=10, justification=f"Score {score}")
                ],
                overall_feedback=f"Feedback {score}",
                final_score=score
            ).model_dump_json()
        
        submission = "Test submission"
        rubric = "Test rubric"
        
        result = await run_consistent_grading(variable_grading_function, submission, rubric, num_runs=3)
        
        assert isinstance(result, FinalGrade)
        # Should use robust_median by default, which should handle the variability
        assert result.final_score in [7, 8, 9]
    
    @pytest.mark.asyncio
    async def test_run_consistent_grading_failure(self):
        """Test consistent grading with failing function."""
        async def failing_grading_function(submission, rubric):
            raise Exception("Grading failed")
        
        submission = "Test submission"
        rubric = "Test rubric"
        
        # Should return a fallback grade instead of raising an exception
        result = await run_consistent_grading(failing_grading_function, submission, rubric, num_runs=2)
        assert isinstance(result, FinalGrade)
        assert result.overall_feedback == "All grading attempts failed"
        assert result.final_score == 0


class TestIntegration:
    """Integration tests for autograder utilities."""
    
    def test_full_grading_workflow(self):
        """Test a complete grading workflow."""
        # Create test grades with some variability
        grades = []
        for i in range(5):
            grade = FinalGrade(
                graded_criteria=[
                    GradingCriterion(
                        criterion="Content",
                        score=7 + (i % 3),  # Scores: 7, 8, 9, 7, 8
                        max_score=10,
                        justification=f"Content analysis {i+1}"
                    ),
                    GradingCriterion(
                        criterion="Style",
                        score=6 + (i % 2),  # Scores: 6, 7, 6, 7, 6
                        max_score=10,
                        justification=f"Style analysis {i+1}"
                    )
                ],
                overall_feedback=f"Essay feedback {i+1}",
                final_score=13 + (i % 3) + (i % 2)
            )
            grades.append(grade)
        
        # Test different aggregation methods
        median_result = GradeAggregator.aggregate(grades, method="median")
        mean_result = GradeAggregator.aggregate(grades, method="mean")
        
        # Content scores: 7, 8, 9, 7, 8 -> median=8, mean=7.8->8
        # Style scores: 6, 7, 6, 7, 6 -> median=6, mean=6.4->6
        content_median = next(c for c in median_result.graded_criteria if c.criterion == "Content")
        style_median = next(c for c in median_result.graded_criteria if c.criterion == "Style")
        content_mean = next(c for c in mean_result.graded_criteria if c.criterion == "Content")
        style_mean = next(c for c in mean_result.graded_criteria if c.criterion == "Style")
        
        assert content_median.score == 8
        assert style_median.score == 6
        assert content_mean.score == 8
        assert style_mean.score == 6
        
        # Test formatting
        json_list = [grade.model_dump_json() for grade in grades]
        report = aggregate_and_format_report(json_list, "integration_test.txt", method="median")
        
        assert "GRADE REPORT FOR: integration_test.txt" in report
        assert "FINAL SCORE: 14 / 20" in report  # 8 + 6 = 14


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
