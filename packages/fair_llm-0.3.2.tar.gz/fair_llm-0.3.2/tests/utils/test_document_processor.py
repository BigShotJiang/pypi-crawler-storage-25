import base64
import os
import types
from pathlib import Path

import pytest

import fairlib.utils.document_processor as dp_mod


def _mk_proc(tmp_path, exts=None, max_chars=80, enable_ocr=False):
    """Create a DocumentProcessor with explicit config to avoid relying on fairlib.settings."""
    cfg = {
        "files_directory": str(tmp_path / "files"),
        "supported_extensions": set(exts or [".txt", ".csv", ".sql", ".pdf", ".docx", ".pptx", ".xlsx"]),
        "max_chunk_chars": max_chars,
        "enable_ocr": enable_ocr,
        "ocr_dpi": 150,
    }
    return dp_mod.DocumentProcessor(cfg)


def _write(tmp_path, rel, data: bytes):
    p = tmp_path / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    return str(p)


def test_init_uses_config_and_creates_dir(tmp_path):
    tool = _mk_proc(tmp_path, exts=[".txt"], max_chars=50)

    assert Path(tool.files_directory).exists()
    assert isinstance(tool.supported_extensions, set)
    assert ".txt" in tool.supported_extensions
    assert tool.get_stats()["files_processed"] == 0


def test_save_uploaded_file_bytes_and_base64(tmp_path):
    tool = _mk_proc(tmp_path, exts=[".txt"])
    path1 = tool.save_uploaded_file({"name": "a.txt", "content": b"hello"})
    assert Path(path1).read_text() == "hello"

    b64 = base64.b64encode(b"world").decode()
    path2 = tool.save_uploaded_file({"name": "b.txt", "content": b64})
    assert Path(path2).read_text() == "world"


def test_save_uploaded_file_invalid_content_type_raises(tmp_path):
    tool = _mk_proc(tmp_path)
    with pytest.raises(ValueError):
        tool.save_uploaded_file({"name": "x.bin", "content": 123})


def test_save_uploaded_file_bad_base64_raises(tmp_path):
    tool = _mk_proc(tmp_path)
    with pytest.raises(ValueError):
        tool.save_uploaded_file({"name": "x.txt", "content": "!!not-base64!!"})


def test_extract_text_with_fallback_text_ok(tmp_path):
    tool = _mk_proc(tmp_path, exts=[".txt"])
    p = _write(tmp_path, "files/ok.txt", b"line1\n\nline2")
    segs = tool.extract_text_with_fallback(p)
    assert segs and segs[0]["text"].startswith("line1")
    # stats updated
    assert tool.get_stats()["files_processed"] == 1


def test_extract_text_with_fallback_unsupported_extension(tmp_path):
    tool = _mk_proc(tmp_path, exts=[".txt"])
    p = _write(tmp_path, "files/a.bin", b"raw")
    segs = tool.extract_text_with_fallback(p)
    assert segs == []


def test_split_text_semantic_chunks_respect_max(tmp_path):
    tool = _mk_proc(tmp_path, max_chars=20)
    text = "Para one. Short.\n\nPara two is a bit longer. Another sentence!"
    chunks = tool.split_text_semantic(text, max_chars=20)
    assert chunks  # non-empty
    assert all(len(c) <= 20 for c in chunks)
    # total_chunks increments
    assert tool.get_stats()["total_chunks"] >= len(chunks)


def test_process_file_builds_documents_and_metadata(tmp_path):
    tool = _mk_proc(tmp_path, exts=[".txt"], max_chars=15)
    p = _write(tmp_path, "files/many.txt", b"Sentence one. Sentence two. Sentence three.")
    docs = tool.process_file(p)
    # should split into multiple chunks
    assert len(docs) >= 2
    d0 = docs[0]
    # Document-like: page_content and metadata
    assert hasattr(d0, "page_content")
    assert hasattr(d0, "metadata")
    m = d0.metadata
    assert "segment_index" in m and "chunk_index" in m and "source" in m


def test_pdf_without_libs_returns_empty(tmp_path, monkeypatch):
    tool = _mk_proc(tmp_path, exts=[".pdf"])
    # Force PDF libs unavailable
    monkeypatch.setattr(dp_mod, "PDF_LIBS_AVAILABLE", False)
    p = _write(tmp_path, "files/x.pdf", b"%PDF-1.4 fake")
    segs = tool.extract_text_with_fallback(p)
    assert segs == []


def test_pdf_with_ocr_fallback(monkeypatch, tmp_path):
    tool = _mk_proc(tmp_path, exts=[".pdf"], enable_ocr=True)

    # Fake pdfplumber pages: no extractable text -> triggers OCR
    class _FakePage:
        def extract_text(self, **kwargs):
            return ""

    class _FakePDF:
        def __init__(self, _):
            self.pages = [_FakePage(), _FakePage()]
        def __enter__(self): return self
        def __exit__(self, *a): return False

    # Fake convert_from_path returns list of PIL-like images
    class _FakeIMG:
        def __init__(self): self._bytes = b"fake"
        # pytesseract reads images via PIL.Image, but we’ll pass object directly to mocked pytesseract

    def _fake_convert_from_path(file_path, **kwargs):
        return [_FakeIMG()]

    # Fake pytesseract
    class _FakeTess:
        @staticmethod
        def image_to_string(img):
            return "OCR TEXT"

    monkeypatch.setattr(dp_mod, "PDF_LIBS_AVAILABLE", True)
    monkeypatch.setattr(dp_mod, "pdfplumber", types.SimpleNamespace(open=_FakePDF))
    monkeypatch.setattr(dp_mod, "convert_from_path", _fake_convert_from_path)
    monkeypatch.setattr(dp_mod, "pytesseract", _FakeTess)

    p = _write(tmp_path, "files/y.pdf", b"%PDF fake")
    segs = tool.extract_text_with_fallback(p)
    # should have OCR text segments
    assert segs and any("OCR TEXT" in s["text"] for s in segs)
    st = tool.get_stats()
    assert st["ocr_attempts"] >= 1
    assert st["ocr_successes"] >= 1


def test_docx_extraction_basic(monkeypatch, tmp_path):
    tool = _mk_proc(tmp_path, exts=[".docx"])

    class _Para:  # simulate python-docx paragraph
        def __init__(self, t): self.text = t

    class _FakeDoc:
        def __init__(self, _): self.paragraphs = [_Para("Hello"), _Para("World")]

    # monkeypatch the docx.Document callable used in module
    monkeypatch.setattr(dp_mod.docx, "Document", _FakeDoc)

    p = _write(tmp_path, "files/a.docx", b"not real docx but path checked")
    segs = tool.extract_text_with_fallback(p)
    assert segs and "Hello" in segs[0]["text"] and "World" in segs[0]["text"]


def test_pptx_extraction_basic(monkeypatch, tmp_path):
    tool = _mk_proc(tmp_path, exts=[".pptx"])

    class _Shape:
        def __init__(self, text=None): self.text = text

    class _Slide:
        def __init__(self, shapes): self.shapes = shapes

    class _FakePresentation:
        def __init__(self, _): self.slides = [_Slide([_Shape("Title"), _Shape("Bullet 1")])]

    monkeypatch.setattr(dp_mod, "Presentation", _FakePresentation)

    p = _write(tmp_path, "files/a.pptx", b"fake")
    segs = tool.extract_text_with_fallback(p)
    assert segs and "Title" in segs[0]["text"] and "Bullet 1" in segs[0]["text"]


def test_xlsx_extraction_basic(monkeypatch, tmp_path):
    tool = _mk_proc(tmp_path, exts=[".xlsx"])

    # Fake pandas.ExcelFile and read_excel
    class _FakeExcelFile:
        def __init__(self, _): self.sheet_names = ["Sheet1", "Empty"]

    def _fake_read_excel(xls, sheet_name=None, engine=None):
        import pandas as pd
        if sheet_name == "Empty":
            return pd.DataFrame({"a": []})
        return pd.DataFrame({"Year": [2020, 2021], "Value": [1, 2]})

    monkeypatch.setattr(dp_mod.pd, "ExcelFile", _FakeExcelFile)
    monkeypatch.setattr(dp_mod.pd, "read_excel", _fake_read_excel)

    p = _write(tmp_path, "files/a.xlsx", b"fake bytes")
    segs = tool.extract_text_with_fallback(p)
    assert segs and any("Year" in s["text"] for s in segs)
    # includes an "Empty" sheet representation
    assert any("Empty" in s["text"] or "Sheet 'Empty' is empty." in s["text"] for s in segs)


def test_load_documents_from_folder_uses_process_file_and_progress(tmp_path, monkeypatch):
    tool = _mk_proc(tmp_path, exts=[".txt"])

    _write(tmp_path, "files/f1.txt", b"alpha")
    _write(tmp_path, "files/f2.txt", b"beta")
    _write(tmp_path, "files/sub/f3.txt", b"gamma")

    class _Doc:
        def __init__(self, pc, md): self.page_content, self.metadata = pc, md

    def fake_process(file_path):
        return [_Doc("c1", {"filename": os.path.basename(file_path)}),
                _Doc("c2", {"filename": os.path.basename(file_path)})]

    monkeypatch.setattr(tool, "process_file", fake_process)

    calls = []
    def progress_cb(progress, status):
        calls.append((progress, status))

    docs = tool.load_documents_from_folder(progress_callback=progress_cb)
    # 3 files * 2 docs each
    assert len(docs) == 6
    # progress called and final one reaches 1.0
    assert calls and any(abs(p - 1.0) < 1e-9 for p, _ in calls)