import os
import json
import tempfile
import torch

from fairlib.utils import nuextract


class FakeTokenizer:
    def __init__(self, decoded: str):
        self.decoded = decoded
        self.eos_token_id = 0

    def __call__(self, *args, **kwargs):
        return {"input_ids": torch.tensor([[1, 2, 3]])}

    def decode(self, out_ids, skip_special_tokens=True):
        return self.decoded


class FakeModel:
    def eval(self):
        return self

    def to(self, device):
        return self

    def generate(self, *args, **kwargs):
        return torch.tensor([[1, 2, 3, 4]])


def test_build_prompt_includes_template_examples_and_user_context():
    schema = {"field": ""}
    examples = [{"field": "value1"}, "{\n  \"field\": \"value2\"\n}"]
    user_context = "Additional info from user."
    prompt = nuextract._build_prompt("text body", schema, examples, user_context)
    assert "### Template:" in prompt
    assert "### Example:" in prompt
    assert "### UserContext:" in prompt
    assert "### Text:" in prompt


def test_extract_parses_json_with_fake_model_and_tokenizer(monkeypatch):
    decoded = "<|output|>\n{\n  \"a\": 1\n}\n<|end-output|>"
    fake_tok = FakeTokenizer(decoded)
    fake_model = FakeModel()

    # Monkeypatch internals to avoid loading real model
    monkeypatch.setattr(nuextract, "_TOKENIZER", fake_tok, raising=False)
    monkeypatch.setattr(nuextract, "_MODEL", fake_model, raising=False)
    monkeypatch.setattr(nuextract, "_ensure_loaded", lambda *a, **k: None)

    out = nuextract.extract(
        text="hello", schema={"a": 0}, examples=None, model_name="dummy", max_input_tokens=32, max_new_tokens=8
    )
    assert isinstance(out, dict)
    assert out == {"a": 1}


def test_extract_from_file_with_text(monkeypatch):
    # Prepare a temporary text file
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "sample.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write("Name: Alice\nAge: 30")

        decoded = "<|output|>\n{\n  \"name\": \"Alice\",\n  \"age\": 30\n}\n<|end-output|>"
        fake_tok = FakeTokenizer(decoded)
        fake_model = FakeModel()

        monkeypatch.setattr(nuextract, "_TOKENIZER", fake_tok, raising=False)
        monkeypatch.setattr(nuextract, "_MODEL", fake_model, raising=False)
        monkeypatch.setattr(nuextract, "_ensure_loaded", lambda *a, **k: None)

        result = nuextract.extract_from_file(
            file_path=path,
            schema={"name": "", "age": 0},
            examples=[{"name": "Bob", "age": 22}],
            model_name="dummy",
            max_input_tokens=64,
            max_new_tokens=16,
            user_context="Company: ACME",
            ocr_fallback=False,
        )

        assert isinstance(result, dict)
        assert result["name"] == "Alice"
        assert result["age"] == 30


