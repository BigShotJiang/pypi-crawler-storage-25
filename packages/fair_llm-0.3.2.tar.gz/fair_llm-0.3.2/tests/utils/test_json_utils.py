"""Tests for json_utils — sanitization and safe parsing of malformed LLM JSON."""

import json

import pytest

from fairlib.utils.json_utils import sanitize_json_string, safe_json_loads


# TestSanitizeJsonString

class TestSanitizeJsonString:
    """Verify backslash escape sanitization logic."""

    # --- No-op cases: input should pass through unchanged ---

    def test_no_backslashes_unchanged(self):
        text = '{"thought": "hello world"}'
        assert sanitize_json_string(text) == text

    def test_empty_string(self):
        assert sanitize_json_string("") == ""

    def test_valid_newline_escape_preserved(self):
        text = r'{"text": "line1\nline2"}'
        assert sanitize_json_string(text) == text

    def test_valid_tab_escape_preserved(self):
        text = r'{"text": "col1\tcol2"}'
        assert sanitize_json_string(text) == text

    def test_valid_quote_escape_preserved(self):
        text = r'{"text": "he said \"hello\""}'
        assert sanitize_json_string(text) == text

    def test_valid_backslash_escape_preserved(self):
        text = r'{"path": "C:\\Users\\admin"}'
        assert sanitize_json_string(text) == text

    def test_valid_unicode_escape_preserved(self):
        text = r'{"char": "\u00e9"}'
        assert sanitize_json_string(text) == text

    def test_valid_slash_escape_preserved(self):
        text = r'{"url": "http:\/\/example.com"}'
        assert sanitize_json_string(text) == text

    def test_valid_form_feed_preserved(self):
        text = r'{"x": "\f"}'
        assert sanitize_json_string(text) == text

    def test_valid_backspace_preserved(self):
        text = r'{"x": "\b"}'
        assert sanitize_json_string(text) == text

    def test_valid_carriage_return_preserved(self):
        text = r'{"x": "\r"}'
        assert sanitize_json_string(text) == text

    # --- LaTeX fixes: invalid escapes should be doubled ---

    def test_latex_inline_math(self):
        """\\( and \\) are not valid JSON escapes and should be doubled."""
        text = r'{"text": "solve \\(x + 1 = 2\\)"}'
        # After sanitization, the single backslash before ( and ) should be doubled
        # But \\( in the raw string is actually two chars: \ and (
        # Let's test with what the LLM actually produces
        bad = '{"text": "solve \\(x + 1 = 2\\)"}'
        result = sanitize_json_string(bad)
        # The invalid \( and \) should now be \\( and \\)
        assert json.loads(result)["text"] == "solve \\(x + 1 = 2\\)"

    def test_latex_log_command(self):
        """\\log is not a valid JSON escape — \\l is invalid."""
        bad = '{"text": "compute \\log_2(8)"}'
        result = sanitize_json_string(bad)
        parsed = json.loads(result)
        assert "\\log_2(8)" in parsed["text"]

    def test_latex_ln_command(self):
        bad = '{"text": "find \\ln(3)"}'
        result = sanitize_json_string(bad)
        parsed = json.loads(result)
        assert "\\ln(3)" in parsed["text"]

    def test_latex_frac_known_limitation(self):
        """\\f is a valid JSON escape (form feed), so \\frac becomes \\x0c + 'rac'.

        This is an inherent ambiguity: the sanitizer cannot distinguish LaTeX
        \\frac from a JSON form-feed escape followed by 'rac'. The sanitizer
        correctly identifies \\f as valid and preserves it. In practice, LLMs
        that wrap LaTeX in \\\\( ... \\\\) avoid this issue.
        """
        bad = '{"text": "\\frac{1}{2}"}'
        result = sanitize_json_string(bad)
        parsed = json.loads(result)
        # \f is consumed as form feed — this is correct sanitizer behavior
        assert parsed["text"] == "\x0crac{1}{2}"

    def test_latex_sqrt(self):
        bad = '{"text": "\\sqrt{4} = 2"}'
        result = sanitize_json_string(bad)
        parsed = json.loads(result)
        assert "\\sqrt{4}" in parsed["text"]

    # --- Mixed valid + invalid escapes ---

    def test_mixed_valid_and_invalid(self):
        """Valid \\n should stay, invalid \\( should be doubled."""
        bad = '{"text": "line1\\nsolve \\(x\\)"}'
        result = sanitize_json_string(bad)
        parsed = json.loads(result)
        assert "\n" in parsed["text"]  # \n decoded to actual newline
        assert "\\(" in parsed["text"]  # \( preserved as literal

    def test_valid_backslash_next_to_invalid(self):
        """A valid \\\\ followed by an invalid \\( should both be handled."""
        bad = '{"text": "path\\\\dir and \\(x\\)"}'
        result = sanitize_json_string(bad)
        parsed = json.loads(result)
        assert "\\" in parsed["text"]
        assert "\\(" in parsed["text"]

    # --- Edge cases ---

    def test_trailing_backslash(self):
        """A lone backslash at the end of string should be doubled."""
        bad = '{"text": "end\\'
        result = sanitize_json_string(bad)
        assert result.endswith("\\\\")

    def test_consecutive_invalid_escapes(self):
        bad = '{"text": "\\(\\)\\["}'
        result = sanitize_json_string(bad)
        parsed = json.loads(result)
        assert parsed["text"] == "\\(\\)\\["

    def test_invalid_unicode_too_short(self):
        """\\uXX (only 2 hex digits) is not a valid \\uXXXX escape."""
        bad = '{"text": "\\u00"}'
        result = sanitize_json_string(bad)
        parsed = json.loads(result)
        assert "\\u00" in parsed["text"]


# TestSafeJsonLoads

class TestSafeJsonLoads:
    """Verify two-pass parse strategy."""

    # --- Pass 1: valid JSON parsed directly ---

    def test_valid_json_parsed_directly(self):
        result = safe_json_loads('{"key": "value"}')
        assert result == {"key": "value"}

    def test_valid_json_with_escapes(self):
        result = safe_json_loads('{"text": "line1\\nline2"}')
        assert result == {"text": "line1\nline2"}

    def test_valid_json_array(self):
        result = safe_json_loads('[1, 2, 3]')
        assert result == [1, 2, 3]

    def test_valid_json_nested(self):
        result = safe_json_loads('{"a": {"b": "c"}}')
        assert result == {"a": {"b": "c"}}

    def test_valid_json_number(self):
        assert safe_json_loads("42") == 42

    def test_valid_json_string(self):
        assert safe_json_loads('"hello"') == "hello"

    # --- Pass 2: invalid JSON recovered after sanitization ---

    def test_latex_json_recovered(self):
        """JSON with LaTeX \\( should fail raw but succeed after sanitization."""
        bad = '{"thought": "solve \\(x\\)", "action": {"tool_name": "calc"}}'
        result = safe_json_loads(bad)
        assert result["thought"] == "solve \\(x\\)"
        assert result["action"]["tool_name"] == "calc"

    def test_latex_log_recovered(self):
        bad = '{"answer": "use \\log_2(n)"}'
        result = safe_json_loads(bad)
        assert "\\log_2(n)" in result["answer"]

    def test_multiple_latex_commands_recovered(self):
        """\\sqrt and \\ln are recovered; \\frac hits the \\f ambiguity (see sanitize tests)."""
        bad = '{"text": "\\sqrt{x} + \\ln(y)"}'
        result = safe_json_loads(bad)
        assert "\\sqrt" in result["text"]
        assert "\\ln" in result["text"]

    # --- Still raises on truly broken JSON ---

    def test_completely_broken_json_raises(self):
        with pytest.raises(json.JSONDecodeError):
            safe_json_loads("not json at all")

    def test_unclosed_brace_raises(self):
        with pytest.raises(json.JSONDecodeError):
            safe_json_loads('{"key": "value"')

    def test_empty_string_raises(self):
        with pytest.raises(json.JSONDecodeError):
            safe_json_loads("")

    def test_no_backslash_broken_json_raises(self):
        """Broken JSON without backslashes should raise immediately (no sanitize attempt)."""
        with pytest.raises(json.JSONDecodeError):
            safe_json_loads("{key: value}")

    # --- Original error preserved ---

    def test_raises_original_error_when_sanitization_fails(self):
        """If sanitization still can't fix it, the original error is raised."""
        bad = '{"broken \\(still broken'
        with pytest.raises(json.JSONDecodeError) as exc_info:
            safe_json_loads(bad)
        # Should be the original error from the first json.loads attempt
        assert exc_info.value is not None


# TestRealisticLLMOutput

class TestRealisticLLMOutput:
    """Test with realistic LLM JSON outputs containing LaTeX."""

    def test_react_planner_response_with_latex(self):
        """Simulates a ReAct planner response where thought contains LaTeX."""
        bad = (
            '{"thought": "The student wrote \\(2x + 3 = 7\\) but should use '
            '\\\\frac{4}{2}", "action": {"tool_name": "calculator", '
            '"tool_input": "2x + 3 = 7"}}'
        )
        result = safe_json_loads(bad)
        assert result["action"]["tool_name"] == "calculator"
        assert result["action"]["tool_input"] == "2x + 3 = 7"

    def test_manager_planner_delegate_with_latex(self):
        """Simulates a manager planner delegation with LaTeX in task."""
        bad = (
            '{"tool_name": "delegate", "tool_input": '
            '{"worker_name": "MathTutor", "task": "Help with \\(x^2 + 2x + 1 = 0\\)"}}'
        )
        result = safe_json_loads(bad)
        assert result["tool_name"] == "delegate"
        assert result["tool_input"]["worker_name"] == "MathTutor"

    def test_final_answer_with_latex(self):
        bad = (
            '{"tool_name": "final_answer", "tool_input": '
            '"The derivative of \\(x^2\\) is \\(2x\\) using the power rule."}'
        )
        result = safe_json_loads(bad)
        assert result["tool_name"] == "final_answer"
        assert "2x" in result["tool_input"]
