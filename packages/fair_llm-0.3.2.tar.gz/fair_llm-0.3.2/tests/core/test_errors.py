"""Tests for the typed error hierarchy in fairlib.core.errors."""

import pytest

from fairlib import (
    AdapterError,
    FairlibError,
    MaxStepsExceeded,
    PlannerParseError,
    ToolInvocationError,
)


class TestErrorHierarchy:
    def test_all_inherit_from_fairliberror(self):
        for cls in (AdapterError, ToolInvocationError, MaxStepsExceeded):
            assert issubclass(cls, FairlibError)

    def test_planner_parse_error_is_value_error_for_backward_compat(self):
        assert issubclass(PlannerParseError, ValueError)

    def test_fairliberror_is_catchable(self):
        try:
            raise AdapterError("boom")
        except FairlibError:
            pass
        try:
            raise ToolInvocationError("boom", tool_name="t")
        except FairlibError:
            pass
        try:
            raise MaxStepsExceeded(5)
        except FairlibError:
            pass


class TestPlannerParseErrorRawOutput:
    def test_raw_output_defaults_to_none(self):
        e = PlannerParseError("oops")
        assert e.raw_output is None

    def test_raw_output_is_preserved(self):
        e = PlannerParseError("oops", raw_output="the raw LLM text")
        assert e.raw_output == "the raw LLM text"

    def test_still_works_as_value_error(self):
        with pytest.raises(ValueError):
            raise PlannerParseError("oops", raw_output="r")


class TestAdapterError:
    def test_attributes(self):
        e = AdapterError("fail", raw_output="junk", provider="openai")
        assert str(e) == "fail"
        assert e.raw_output == "junk"
        assert e.provider == "openai"

    def test_provider_and_raw_optional(self):
        e = AdapterError("fail")
        assert e.raw_output is None
        assert e.provider is None

    def test_from_cause(self):
        try:
            try:
                raise RuntimeError("root")
            except RuntimeError as rc:
                raise AdapterError("wrap", provider="p") from rc
        except AdapterError as e:
            assert isinstance(e.__cause__, RuntimeError)


class TestToolInvocationError:
    def test_required_tool_name(self):
        e = ToolInvocationError("fail", tool_name="safe_calculator")
        assert e.tool_name == "safe_calculator"
        assert e.raw_output is None

    def test_raw_output_preserved(self):
        e = ToolInvocationError("fail", tool_name="t", raw_output="trace")
        assert e.raw_output == "trace"


class TestMaxStepsExceeded:
    def test_default_message_mentions_max_steps(self):
        e = MaxStepsExceeded(7)
        assert "7" in str(e)
        assert e.max_steps == 7
        assert e.partial_history is None

    def test_partial_history_preserved(self):
        history = [1, 2, 3]
        e = MaxStepsExceeded(3, partial_history=history)
        assert e.partial_history is history
