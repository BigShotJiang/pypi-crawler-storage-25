"""Tests for AbstractChatModel context window usage warning."""

import logging
from typing import Any, Dict, Generator, AsyncGenerator, List

import pytest

from fairlib.core.interfaces.llm import AbstractChatModel
from fairlib.core.message import Message


class FakeChatModel(AbstractChatModel):
    """Minimal concrete subclass for testing the context window check."""

    def __init__(self, max_context_window=None):
        self._max_context_window = max_context_window

    def invoke(self, messages, **kwargs):
        return Message(role="assistant", content="ok")

    async def ainvoke(self, messages, **kwargs):
        return Message(role="assistant", content="ok")

    def stream(self, messages, **kwargs) -> Generator[Message, None, None]:
        yield Message(role="assistant", content="ok")

    async def astream(self, messages, **kwargs) -> AsyncGenerator[Message, None]:
        yield Message(role="assistant", content="ok")

    def get_model_capabilities(self) -> Dict[str, Any]:
        caps: Dict[str, Any] = {"supports_streaming": True}
        if self._max_context_window is not None:
            caps["max_context_window"] = self._max_context_window
        return caps


class TestEstimateTokenCount:
    def test_default_heuristic(self):
        model = FakeChatModel(max_context_window=1000)
        # 40 chars → 10 tokens
        assert model.estimate_token_count("a" * 40) == 10

    def test_empty_string(self):
        model = FakeChatModel(max_context_window=1000)
        assert model.estimate_token_count("") == 0


class TestCheckContextWindowUsage:
    def test_no_warning_below_threshold(self, caplog):
        model = FakeChatModel(max_context_window=1000)
        # 80 chars → ~20 tokens → 2% of 1000
        messages = [Message(role="user", content="a" * 80)]
        with caplog.at_level(logging.WARNING):
            model._check_context_window_usage(messages)
        assert not caplog.records

    def test_warning_above_threshold(self, caplog):
        model = FakeChatModel(max_context_window=100)
        # 240 chars → ~60 tokens → 60% of 100
        messages = [Message(role="user", content="a" * 240)]
        with caplog.at_level(logging.WARNING):
            model._check_context_window_usage(messages)
        assert len(caplog.records) == 1
        assert "60.0%" in caplog.records[0].message

    def test_graceful_skip_no_max_context(self, caplog):
        model = FakeChatModel(max_context_window=None)
        messages = [Message(role="user", content="a" * 10000)]
        with caplog.at_level(logging.WARNING):
            model._check_context_window_usage(messages)
        assert not caplog.records

    def test_system_prompt_callout(self, caplog):
        model = FakeChatModel(max_context_window=100)
        messages = [
            Message(role="system", content="s" * 200),  # ~50 tokens
            Message(role="user", content="u" * 80),     # ~20 tokens → total ~70
        ]
        with caplog.at_level(logging.WARNING):
            model._check_context_window_usage(messages)
        assert len(caplog.records) == 1
        record = caplog.records[0].message
        assert "System prompt" in record
        assert "50.0%" in record

    def test_no_system_prompt_callout_when_absent(self, caplog):
        model = FakeChatModel(max_context_window=100)
        # 240 chars → ~60 tokens → 60%
        messages = [Message(role="user", content="a" * 240)]
        with caplog.at_level(logging.WARNING):
            model._check_context_window_usage(messages)
        assert len(caplog.records) == 1
        assert "System prompt" not in caplog.records[0].message

    def test_custom_threshold(self, caplog):
        model = FakeChatModel(max_context_window=100)
        # 120 chars → ~30 tokens → 30% (below default 50% but at custom 0.3)
        messages = [Message(role="user", content="a" * 120)]
        with caplog.at_level(logging.WARNING):
            model._check_context_window_usage(messages, threshold=0.3)
        assert len(caplog.records) == 1
        assert "30.0%" in caplog.records[0].message

    def test_empty_messages_no_warning(self, caplog):
        model = FakeChatModel(max_context_window=100)
        with caplog.at_level(logging.WARNING):
            model._check_context_window_usage([])
        assert not caplog.records

    def test_none_content_handled(self, caplog):
        model = FakeChatModel(max_context_window=100)
        messages = [Message(role="user", content=None)]
        with caplog.at_level(logging.WARNING):
            model._check_context_window_usage(messages)
        assert not caplog.records
