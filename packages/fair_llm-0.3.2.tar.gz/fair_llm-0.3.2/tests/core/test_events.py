"""Tests for fairlib.core.events — the typed event payloads.

The MemorySummarizedEvent dataclass is the canonical observability hook for
SummarizingMemory. The full event-bus on SimpleAgent (P1.3) will route this
same payload through a generic subscription API.
"""

import dataclasses

import pytest

from fairlib.core.events import MemorySummarizedEvent
from fairlib.core.message import Message


def _msg(role="user", content="x", importance="normal"):
    return Message(role=role, content=content, importance=importance)


class TestMemorySummarizedEventConstruction:
    """B1: dataclass constructs with required fields."""

    def test_minimal_construction(self):
        event = MemorySummarizedEvent(
            dropped=(_msg(content="dropped-1"),),
            kept=(_msg(content="kept-1"),),
            summary=Message(role="system", content="summary text"),
        )
        assert len(event.dropped) == 1
        assert len(event.kept) == 1
        assert event.summary.content == "summary text"

    def test_default_reason_is_max_history_length_exceeded(self):
        event = MemorySummarizedEvent(
            dropped=(),
            kept=(),
            summary=Message(role="system", content="s"),
        )
        assert event.reason == "max_history_length_exceeded"

    def test_explicit_reason_is_preserved(self):
        event = MemorySummarizedEvent(
            dropped=(),
            kept=(),
            summary=Message(role="system", content="s"),
            reason="adapter_failure_fallback",
        )
        assert event.reason == "adapter_failure_fallback"


class TestMemorySummarizedEventImmutability:
    """B2: the event is frozen so subscribers cannot mutate shared state."""

    def test_event_is_frozen(self):
        event = MemorySummarizedEvent(
            dropped=(_msg(),),
            kept=(_msg(),),
            summary=Message(role="system", content="s"),
        )
        with pytest.raises(dataclasses.FrozenInstanceError):
            event.reason = "tampered"  # type: ignore[misc]

    def test_dropped_is_tuple_not_list(self):
        # tuples are immutable — subscribers cannot append to or reorder
        # the dropped/kept slices a memory implementation handed them.
        event = MemorySummarizedEvent(
            dropped=(_msg(),),
            kept=(),
            summary=Message(role="system", content="s"),
        )
        assert isinstance(event.dropped, tuple)

    def test_kept_is_tuple_not_list(self):
        event = MemorySummarizedEvent(
            dropped=(),
            kept=(_msg(),),
            summary=Message(role="system", content="s"),
        )
        assert isinstance(event.kept, tuple)


class TestMemorySummarizedEventPayload:
    """B3: dropped/kept hold Message instances; summary is a Message."""

    def test_payload_contents_round_trip(self):
        d1 = _msg(content="dropped-1")
        d2 = _msg(content="dropped-2")
        k1 = _msg(content="kept-1")
        s = Message(role="system", content="summary of d1 and d2")

        event = MemorySummarizedEvent(
            dropped=(d1, d2),
            kept=(k1,),
            summary=s,
        )

        assert event.dropped == (d1, d2)
        assert event.kept == (k1,)
        assert event.summary is s

    def test_dropped_can_be_empty(self):
        # Edge case: a future memory implementation might fire the event
        # to signal compression even when nothing was structurally dropped
        # (e.g., a placeholder summary on adapter failure).
        event = MemorySummarizedEvent(
            dropped=(),
            kept=(_msg(),),
            summary=Message(role="system", content="<summary unavailable>"),
            reason="adapter_failure_fallback",
        )
        assert event.dropped == ()


class TestMemorySummarizedEventPublicAPI:
    """B4: the event is exported from fairlib top-level for ergonomic import.

    The pattern matches how the typed errors (FairlibError, AdapterError, etc.)
    are exposed — the addition has to be reflected in fairlib/__init__.py
    __all__ and the eager-import block.
    """

    def test_event_importable_from_fairlib_top_level(self):
        from fairlib import MemorySummarizedEvent as Exported

        assert Exported is MemorySummarizedEvent
