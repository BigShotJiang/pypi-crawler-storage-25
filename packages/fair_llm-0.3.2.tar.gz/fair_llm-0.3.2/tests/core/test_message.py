"""Tests for fairlib.core.message.Message — focused on the importance field.

Existing Message construction patterns must continue to work unchanged; the
importance field is purely additive with a sensible default.
"""

import pytest

from fairlib.core.message import Message


class TestMessageImportanceDefault:
    """A1: importance defaults to 'normal' for backwards compatibility."""

    def test_importance_defaults_to_normal_when_not_specified(self):
        msg = Message(role="user", content="hello")
        assert msg.importance == "normal"

    def test_importance_default_for_assistant_role(self):
        msg = Message(role="assistant", content="response")
        assert msg.importance == "normal"

    def test_importance_default_for_system_role(self):
        msg = Message(role="system", content="be helpful")
        assert msg.importance == "normal"

    def test_importance_default_for_tool_role(self):
        msg = Message(role="tool", content="42", name="calculator", tool_call_id="abc")
        assert msg.importance == "normal"


class TestMessageImportancePinned:
    """A2: importance='pinned' is accepted and preserved."""

    def test_pinned_message_constructs(self):
        msg = Message(role="user", content="answer is 42", importance="pinned")
        assert msg.importance == "pinned"

    def test_pinned_with_all_other_fields(self):
        msg = Message(
            role="assistant",
            content="reasoning",
            tool_calls=[{"name": "calc", "args": {"x": 1}}],
            name="calculator",
            tool_call_id="call-123",
            metadata={"source": "test"},
            importance="pinned",
        )
        assert msg.importance == "pinned"
        assert msg.role == "assistant"
        assert msg.content == "reasoning"
        assert msg.tool_calls == [{"name": "calc", "args": {"x": 1}}]
        assert msg.name == "calculator"
        assert msg.tool_call_id == "call-123"
        assert msg.metadata == {"source": "test"}


class TestMessageToDictRoundTrip:
    """A3: to_dict() includes importance so serialization is lossless."""

    def test_to_dict_includes_importance_when_default(self):
        msg = Message(role="user", content="hi")
        d = msg.to_dict()
        assert "importance" in d
        assert d["importance"] == "normal"

    def test_to_dict_includes_importance_when_pinned(self):
        msg = Message(role="user", content="answer is 42", importance="pinned")
        d = msg.to_dict()
        assert d["importance"] == "pinned"

    def test_to_dict_preserves_all_existing_fields(self):
        msg = Message(role="tool", content="result", name="t", tool_call_id="x")
        d = msg.to_dict()
        assert d["role"] == "tool"
        assert d["content"] == "result"
        assert d["name"] == "t"
        assert d["tool_call_id"] == "x"
        assert d["importance"] == "normal"


class TestMessageBackwardsCompatibility:
    """Existing Message construction patterns from across the codebase must
    keep working. These are not new tests of new behavior — they pin the
    contract so the importance addition cannot quietly break callers.
    """

    def test_minimal_construction_still_works(self):
        msg = Message(role="user", content="x")
        assert msg.role == "user"
        assert msg.content == "x"
        assert msg.tool_calls is None
        assert msg.name is None
        assert msg.tool_call_id is None
        assert msg.metadata == {}

    def test_kwarg_only_construction(self):
        msg = Message(role="system", content="instructions", metadata={"k": "v"})
        assert msg.metadata == {"k": "v"}

    def test_message_remains_a_dataclass(self):
        import dataclasses

        assert dataclasses.is_dataclass(Message)
