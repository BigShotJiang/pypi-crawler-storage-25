# test_mcp_client.py
"""
Tests for the MCP client module.

These tests verify:
- MCPClient configuration and initialization
- Transport type validation (stdio vs SSE)
- Connection error handling
- Tool discovery and caching
- Graceful disconnection
"""
import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch

from fairlib import MCPServerConfig


class TestMCPServerConfig:
    """Tests for MCPServerConfig validation."""

    def test_stdio_config_requires_command(self):
        """Stdio transport should have command specified."""
        config = MCPServerConfig(
            name="test-server",
            transport="stdio",
            command="python",
            args=["server.py"]
        )
        assert config.transport == "stdio"
        assert config.command == "python"
        assert config.args == ["server.py"]

    def test_sse_config_requires_url(self):
        """SSE transport should have URL specified."""
        config = MCPServerConfig(
            name="test-server",
            transport="sse",
            url="http://localhost:8080/sse"
        )
        assert config.transport == "sse"
        assert config.url == "http://localhost:8080/sse"

    def test_default_timeout(self):
        """Default timeout should be 30 seconds."""
        config = MCPServerConfig(
            name="test-server",
            transport="stdio",
            command="python"
        )
        assert config.timeout == 30

    def test_custom_timeout(self):
        """Custom timeout should be accepted."""
        config = MCPServerConfig(
            name="test-server",
            transport="stdio",
            command="python",
            timeout=60
        )
        assert config.timeout == 60

    def test_enabled_default_true(self):
        """Servers should be enabled by default."""
        config = MCPServerConfig(
            name="test-server",
            transport="stdio",
            command="python"
        )
        assert config.enabled is True

    def test_environment_variables(self):
        """Environment variables should be configurable."""
        config = MCPServerConfig(
            name="test-server",
            transport="stdio",
            command="python",
            env={"API_KEY": "secret", "DEBUG": "true"}
        )
        assert config.env == {"API_KEY": "secret", "DEBUG": "true"}


class TestMCPClientInitialization:
    """Tests for MCPClient initialization."""

    def test_client_raises_without_mcp_library(self):
        """Client should raise ImportError if mcp library not installed."""
        with patch.dict('sys.modules', {'mcp': None}):
            # This tests the import guard behavior
            pass  # The actual import guard is tested via integration

    def test_client_stores_config(self):
        """Client should store the provided configuration."""
        try:
            from fairlib.modules.mcp.client.mcp_client import MCPClient, MCP_INSTALLED
            if not MCP_INSTALLED:
                pytest.skip("MCP library not installed")

            config = MCPServerConfig(
                name="test-server",
                transport="stdio",
                command="python",
                args=["server.py"]
            )
            client = MCPClient(config)
            assert client.config == config
            assert client.name == "test-server"
        except ImportError:
            pytest.skip("MCP library not installed")

    def test_client_initial_state(self):
        """Client should start in disconnected state."""
        try:
            from fairlib.modules.mcp.client.mcp_client import MCPClient, MCP_INSTALLED
            if not MCP_INSTALLED:
                pytest.skip("MCP library not installed")

            config = MCPServerConfig(
                name="test-server",
                transport="stdio",
                command="python"
            )
            client = MCPClient(config)
            assert client.is_connected is False
            assert client.session is None
        except ImportError:
            pytest.skip("MCP library not installed")


class TestMCPClientSSETransport:
    """Tests for SSE transport functionality."""

    def test_sse_config_validation(self):
        """SSE transport requires URL."""
        config = MCPServerConfig(
            name="brave-search",
            transport="sse",
            url="http://localhost:8080/sse",
            timeout=30
        )
        assert config.transport == "sse"
        assert config.url == "http://localhost:8080/sse"

    @pytest.mark.asyncio
    async def test_sse_connection_error_handling(self):
        """SSE connection should handle errors gracefully."""
        try:
            from fairlib.modules.mcp.client.mcp_client import MCPClient, MCP_INSTALLED, SSE_AVAILABLE
            if not MCP_INSTALLED:
                pytest.skip("MCP library not installed")

            config = MCPServerConfig(
                name="test-sse",
                transport="sse",
                url="http://localhost:99999/sse",  # Invalid port
                timeout=2  # Short timeout for test
            )
            client = MCPClient(config)

            # Connection should fail with appropriate error
            with pytest.raises((ConnectionError, Exception)):
                await client.connect()

        except ImportError:
            pytest.skip("MCP library not installed")

    @pytest.mark.asyncio
    async def test_sse_missing_url_error(self):
        """SSE transport without URL should raise error."""
        try:
            from fairlib.modules.mcp.client.mcp_client import MCPClient, MCP_INSTALLED
            if not MCP_INSTALLED:
                pytest.skip("MCP library not installed")

            config = MCPServerConfig(
                name="test-sse",
                transport="sse",
                # No URL provided
                timeout=2
            )
            client = MCPClient(config)

            with pytest.raises((ConnectionError, ValueError)):
                await client.connect()

        except ImportError:
            pytest.skip("MCP library not installed")


class TestMCPClientStdioTransport:
    """Tests for stdio transport functionality."""

    @pytest.mark.asyncio
    async def test_stdio_missing_command_error(self):
        """Stdio transport without command should raise error."""
        try:
            from fairlib.modules.mcp.client.mcp_client import MCPClient, MCP_INSTALLED
            if not MCP_INSTALLED:
                pytest.skip("MCP library not installed")

            config = MCPServerConfig(
                name="test-stdio",
                transport="stdio",
                # No command provided
                timeout=2
            )
            client = MCPClient(config)

            with pytest.raises((ConnectionError, ValueError)):
                await client.connect()

        except ImportError:
            pytest.skip("MCP library not installed")


class TestMCPClientDisconnect:
    """Tests for client disconnection."""

    @pytest.mark.asyncio
    async def test_disconnect_when_not_connected(self):
        """Disconnect should be safe when not connected."""
        try:
            from fairlib.modules.mcp.client.mcp_client import MCPClient, MCP_INSTALLED
            if not MCP_INSTALLED:
                pytest.skip("MCP library not installed")

            config = MCPServerConfig(
                name="test-server",
                transport="stdio",
                command="python"
            )
            client = MCPClient(config)

            # Should not raise
            await client.disconnect()
            assert client.is_connected is False

        except ImportError:
            pytest.skip("MCP library not installed")


class TestMCPToolAdapter:
    """Tests for MCP tool adapter."""

    def test_adapter_builds_description(self):
        """Adapter should build rich description from MCP tool info."""
        try:
            from fairlib.modules.mcp.client.mcp_tool_adapter import MCPToolAdapter
            from fairlib.modules.mcp.client.mcp_client import MCP_INSTALLED
            if not MCP_INSTALLED:
                pytest.skip("MCP library not installed")

            # Mock MCP client and tool info
            mock_client = MagicMock()
            tool_info = {
                "name": "web_search",
                "description": "Search the web for information",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search query"},
                        "limit": {"type": "integer", "description": "Max results"}
                    },
                    "required": ["query"]
                }
            }

            adapter = MCPToolAdapter(mock_client, tool_info, prefix="brave")

            assert adapter.name == "brave_web_search"
            assert "Search the web" in adapter.description
            assert "query" in adapter.description

        except ImportError:
            pytest.skip("MCP library not installed")


class TestMCPToolRegistry:
    """Tests for MCP tool registry."""

    def test_registry_initialization(self):
        """Registry should initialize with tool prefix."""
        try:
            from fairlib.modules.mcp.client.mcp_tool_registry import MCPToolRegistry
            from fairlib.modules.mcp.client.mcp_client import MCP_INSTALLED
            if not MCP_INSTALLED:
                pytest.skip("MCP library not installed")

            registry = MCPToolRegistry(tool_prefix="mcp")
            assert registry._tool_prefix == "mcp"
            assert len(registry.get_all_tools()) == 0

        except ImportError:
            pytest.skip("MCP library not installed")

    @pytest.mark.asyncio
    async def test_registry_close_all_when_empty(self):
        """close_all should be safe when no servers connected."""
        try:
            from fairlib.modules.mcp.client.mcp_tool_registry import MCPToolRegistry
            from fairlib.modules.mcp.client.mcp_client import MCP_INSTALLED
            if not MCP_INSTALLED:
                pytest.skip("MCP library not installed")

            registry = MCPToolRegistry(tool_prefix="mcp")

            # Should not raise
            await registry.close_all()

        except ImportError:
            pytest.skip("MCP library not installed")


class TestMCPIntegrationScenarios:
    """Integration-style tests for MCP scenarios."""

    def test_hybrid_registry_concept(self):
        """Test that composite registry can combine MCP and local tools."""
        try:
            from fairlib.modules.action.tools.composite_registry import CompositeToolRegistry
            from fairlib import ToolRegistry, SafeCalculatorTool

            # Create local registry with a tool
            local_registry = ToolRegistry()
            local_registry.register_tool(SafeCalculatorTool())

            # Create another registry (simulating MCP)
            mcp_registry = ToolRegistry()

            # Combine them
            combined = CompositeToolRegistry([local_registry, mcp_registry])

            # Should have the local tool (registered by its .name property)
            tools = combined.get_all_tools()
            assert "safe_calculator" in tools

        except ImportError as e:
            pytest.skip(f"Required module not available: {e}")

    def test_mcp_config_from_settings(self):
        """Test creating MCP config programmatically."""
        config = MCPServerConfig(
            name="brave-search",
            transport="sse",
            url="http://localhost:8080/sse",
            timeout=30,
            enabled=True
        )

        # Verify all fields
        assert config.name == "brave-search"
        assert config.transport == "sse"
        assert config.url == "http://localhost:8080/sse"
        assert config.timeout == 30
        assert config.enabled is True
