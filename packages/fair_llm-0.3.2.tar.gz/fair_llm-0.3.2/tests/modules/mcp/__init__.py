# MCP module tests
