# test_planner_parse_error.py
"""Tests for PlannerParseError behavior at the SimpleReActPlanner boundary."""

import pytest

from fairlib.core.errors import PlannerParseError
from fairlib.core.message import FinalAnswer
from fairlib.modules.planning.react_planner import SimpleReActPlanner


class TestPlannerParseError:
    """The contract for malformed LLM output is to raise, not to launder."""

    def test_is_value_error_subclass(self):
        assert issubclass(PlannerParseError, ValueError)

    def test_parse_simplified_raises_planner_parse_error_on_garbage(self):
        planner = SimpleReActPlanner.__new__(SimpleReActPlanner)
        with pytest.raises(PlannerParseError):
            planner._parse_simplified_response("")

    def test_parse_simplified_raises_on_conversational_fallback(self):
        """Conversational text that does not match the contract must raise.

        Pre-strict-parsing this returned a FinalAnswer; that silently
        laundered a contract violation. Implementors need the signal.
        """
        planner = SimpleReActPlanner.__new__(SimpleReActPlanner)
        raw = "I think you should review the chain rule concept more carefully."
        with pytest.raises(PlannerParseError) as ei:
            planner._parse_simplified_response(raw)
        assert ei.value.raw_output == raw

    def test_well_formed_kv_block_returns_thought_action(self):
        """Sanity: the strict parser still accepts well-formed KV input."""
        planner = SimpleReActPlanner.__new__(SimpleReActPlanner)
        text = (
            "Thought: I will use the calculator.\n"
            "Action:\n"
            "tool_name: safe_calculator\n"
            "tool_input: 2+2"
        )
        result = planner._parse_simplified_response(text)
        assert not isinstance(result, FinalAnswer)
        thought, action = result
        assert "calculator" in thought.text.lower()
        assert action.tool_name == "safe_calculator"
        assert action.tool_input == "2+2"
