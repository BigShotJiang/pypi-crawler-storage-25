"""Round-trip tests for AbstractPlanner.format_turn_for_memory.

Every concrete planner must produce a Message whose content round-trips
through that planner's own parser. This locks in the contract that the
agent can always hand a plan step back to the planner for memory
serialization, without knowing the concrete planner subclass.
"""

import json

import pytest

from fairlib.core.message import Action, FinalAnswer, Message, Thought
from fairlib.modules.agent.multi_agent_runner import ManagerPlanner
from fairlib.modules.planning.react_planner import ReActPlanner, SimpleReActPlanner


def _make_simple_planner() -> SimpleReActPlanner:
    return SimpleReActPlanner.__new__(SimpleReActPlanner)


def _make_json_planner() -> ReActPlanner:
    return ReActPlanner.__new__(ReActPlanner)


def _make_manager_planner() -> ManagerPlanner:
    return ManagerPlanner.__new__(ManagerPlanner)


class TestAbstractContract:
    def test_format_turn_for_memory_is_abstract(self):
        from fairlib.core.interfaces.planner import AbstractPlanner

        assert "format_turn_for_memory" in AbstractPlanner.__abstractmethods__

    def test_every_concrete_planner_implements_it(self):
        for cls in (SimpleReActPlanner, ReActPlanner, ManagerPlanner):
            assert hasattr(cls, "format_turn_for_memory")


class TestSimpleReActPlannerFormat:
    def test_tool_step_uses_kv_scaffolding(self):
        p = _make_simple_planner()
        msg = p.format_turn_for_memory(
            (Thought(text="use calc"), Action(tool_name="safe_calculator", tool_input="2+2"))
        )
        assert msg.role == "assistant"
        assert "Thought: use calc" in msg.content
        assert "tool_name: safe_calculator" in msg.content
        assert "tool_input: 2+2" in msg.content

    def test_final_answer_is_kv_scaffolded(self):
        p = _make_simple_planner()
        msg = p.format_turn_for_memory(FinalAnswer(text="The answer is 4."))
        assert msg.role == "assistant"
        assert msg.content.lstrip().startswith("Thought:")
        assert "tool_name: final_answer" in msg.content
        assert "tool_input: The answer is 4." in msg.content

    def test_tool_step_roundtrips_through_parser(self):
        p = _make_simple_planner()
        original_thought = Thought(text="need to calculate")
        original_action = Action(tool_name="safe_calculator", tool_input="7 * 8")
        msg = p.format_turn_for_memory((original_thought, original_action))
        # Parse the formatted content back through the planner's own parser.
        parsed = p._parse_simplified_response(msg.content)
        assert not isinstance(parsed, FinalAnswer)
        thought, action = parsed
        assert thought.text == original_thought.text
        assert action.tool_name == original_action.tool_name
        assert action.tool_input == original_action.tool_input

    def test_final_answer_roundtrips_through_parser(self):
        p = _make_simple_planner()
        original = FinalAnswer(text="The answer is 42.")
        msg = p.format_turn_for_memory(original)
        parsed = p._parse_simplified_response(msg.content)
        assert isinstance(parsed, FinalAnswer)
        assert parsed.text == original.text


class TestReActPlannerFormat:
    def test_tool_step_is_valid_json(self):
        p = _make_json_planner()
        msg = p.format_turn_for_memory(
            (Thought(text="calc"), Action(tool_name="safe_calculator", tool_input="2+2"))
        )
        payload = json.loads(msg.content)
        assert payload["thought"] == "calc"
        assert payload["action"]["tool_name"] == "safe_calculator"
        assert payload["action"]["tool_input"] == "2+2"

    def test_final_answer_json_shape(self):
        p = _make_json_planner()
        msg = p.format_turn_for_memory(FinalAnswer(text="done"))
        payload = json.loads(msg.content)
        assert payload["action"]["tool_name"] == "final_answer"
        assert payload["action"]["tool_input"] == "done"

    def test_tool_step_roundtrips_through_parser(self):
        p = _make_json_planner()
        original_thought = Thought(text="need to calculate")
        original_action = Action(tool_name="safe_calculator", tool_input="7 * 8")
        msg = p.format_turn_for_memory((original_thought, original_action))
        parsed = p._parse_json_response(msg.content)
        thought, action = parsed
        assert thought.text == original_thought.text
        assert action.tool_name == original_action.tool_name
        assert action.tool_input == original_action.tool_input

    def test_final_answer_roundtrips_through_parser(self):
        p = _make_json_planner()
        original = FinalAnswer(text="The answer is 42.")
        msg = p.format_turn_for_memory(original)
        parsed = p._parse_json_response(msg.content)
        assert isinstance(parsed, FinalAnswer)
        assert parsed.text == original.text


class TestManagerPlannerFormat:
    def test_tool_step_preserves_thought_text_only(self):
        # Matches the legacy HierarchicalAgentRunner shape exactly.
        p = _make_manager_planner()
        msg = p.format_turn_for_memory(
            (
                Thought(text="delegate to researcher"),
                Action(
                    tool_name="delegate",
                    tool_input={"worker_name": "Researcher", "task": "X"},
                ),
            )
        )
        assert msg.role == "assistant"
        assert msg.content == "delegate to researcher"

    def test_final_answer_is_raw_text(self):
        p = _make_manager_planner()
        msg = p.format_turn_for_memory(FinalAnswer(text="all done"))
        assert msg.role == "assistant"
        assert msg.content == "all done"
