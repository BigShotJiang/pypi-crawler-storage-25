"""Contract tests: malformed LLM outputs raise PlannerParseError.

Every item in MALFORMED_RESPONSES simulates a real scaffolding leak that
has been observed in production runs. Every ReAct-family planner must
raise PlannerParseError (carrying the original raw_output) rather than
silently sanitizing the response into a FinalAnswer.

The library is not user-facing. Implementors who plug an LLM into these
planners need to know when their model violates the contract; the agent
loop retries once on PlannerParseError with a corrective system message,
then propagates the typed error to the caller on the second consecutive
failure.
"""

import pytest

from fairlib.core.errors import PlannerParseError
from fairlib.modules.planning.react_planner import (
    ReActPlanner,
    SimpleReActPlanner,
)


MALFORMED_RESPONSES = [
    # Leading Thought: prefix followed by usable prose.
    "Thought: ruminations\nGood answer content for the user that is long enough.",
    # Action block trailing usable prose.
    (
        "Here is the detailed explanation the user asked for.\n"
        "Action:\ntool_name: search\ntool_input: ignore me"
    ),
    # Stray tool JSON embedded mid-response.
    'Clean prose here. {"tool_name": "bad", "tool_input": "leak"} continuing on.',
    # Markdown-y wrapped response with scaffolding.
    "**Thought**: thinking\nResponse with substantive content the user can read.",
    # Final Answer: prefix leaked.
    "Final Answer: The solution is straightforward once you see the pattern.",
    # Mixed - Thought, then prose, then rogue JSON, then more prose.
    (
        "Thought: starting\n"
        "This is a coherent explanation about derivatives of polynomials.\n"
        '{"tool_name": "x", "tool_input": "y"}\n'
        "Ending thought."
    ),
    # Response containing protocol terms.
    "You can solve this by calling the final_answer tool_input pattern... "
    "but the real approach is to factor first and then substitute.",
    # Capitalised Action banner.
    "ACTION: ignore\nActually the answer depends on continuity at the endpoint.",
]


GARBAGE_RESPONSES = [
    "",
    "   ",
    "Thought:",
    "Thought:\nAction:",
    "Action:\ntool_name: x\ntool_input: y",
]


class TestSimpleReActPlannerHygiene:
    @pytest.mark.parametrize("raw", MALFORMED_RESPONSES)
    def test_malformed_raises_with_raw_output_preserved(self, raw):
        planner = SimpleReActPlanner.__new__(SimpleReActPlanner)
        with pytest.raises(PlannerParseError) as ei:
            planner._parse_simplified_response(raw)
        assert ei.value.raw_output == raw

    @pytest.mark.parametrize("raw", GARBAGE_RESPONSES)
    def test_garbage_raises_with_raw_output_preserved(self, raw):
        planner = SimpleReActPlanner.__new__(SimpleReActPlanner)
        with pytest.raises(PlannerParseError) as ei:
            planner._parse_simplified_response(raw)
        assert ei.value.raw_output == raw


class TestReActPlannerHygiene:
    @pytest.mark.parametrize("raw", MALFORMED_RESPONSES)
    def test_malformed_raises_with_raw_output_preserved(self, raw):
        planner = ReActPlanner.__new__(ReActPlanner)
        with pytest.raises(PlannerParseError) as ei:
            planner._parse_json_response(raw)
        assert ei.value.raw_output == raw

    @pytest.mark.parametrize("raw", GARBAGE_RESPONSES)
    def test_garbage_raises_with_raw_output_preserved(self, raw):
        planner = ReActPlanner.__new__(ReActPlanner)
        with pytest.raises(PlannerParseError) as ei:
            planner._parse_json_response(raw)
        assert ei.value.raw_output == raw
