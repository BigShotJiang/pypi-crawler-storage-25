import io
import json
import base64
from pathlib import Path
from PIL import Image
import pytest

import fairlib.modules.action.tools.graphing_tool as gt_mod


class FakeSecurityManager:
    """
    Simulates sandboxed code execution. Instead of executing the code,
    it just creates a valid PNG at the path (which GraphingTool already substituted).
    """
    def __init__(self, should_raise=False):
        self.should_raise = should_raise
        self.calls = []

    def sandbox_code_execution(self, code: str, language: str = "python"):
        self.calls.append((code, language))
        if self.should_raise:
            raise RuntimeError("Sandbox exploded")

        # Find the first occurrence of a .png path in the code to write the image.
        # GraphingTool replaces '__PLOT_PATH__' before calling, so the path is literal.
        target = None
        for line in code.splitlines():
            if ".png" in line and "savefig(" in line:
                # Extract between savefig('...') or savefig("...")
                start = line.find("savefig(")
                if start >= 0:
                    # naive parse
                    s = line[start:]
                    q1 = s.find("'")
                    q2 = s.find('"')
                    if q1 == -1 and q2 == -1:
                        continue
                    # pick the first quote char
                    if q1 == -1 or (q2 != -1 and q2 < q1):
                        q = '"'
                    else:
                        q = "'"
                    first = s.find(q)
                    last = s.find(q, first + 1)
                    if first != -1 and last != -1:
                        target = s[first + 1:last]
                        break

        # If we found a plot path, write a small PNG
        if target:
            p = Path(target)
            p.parent.mkdir(parents=True, exist_ok=True)
            img = Image.new("RGB", (64, 48), (40, 140, 220))
            img.save(p, format="PNG")
            return {"ok": True, "path": str(p)}

        return {"ok": True, "note": "no file path detected"}


class FakeLLM:
    """Returns raw or fenced code for the LLM-driven path."""
    def __init__(self, code: str):
        self.code = code
        self.calls = []

    def chat(self, messages):
        self.calls.append(messages)
        return self.code


def test_parse_input_from_extracted_data():
    tool = gt_mod.GraphingTool(security_manager=FakeSecurityManager(), output_dir="test_out")
    payload = {
        "extracted_data": [
            {
                "columns": ["year", "value"],
                "rows": [["2020", "1"], ["2021", "2"]],
            }
        ]
    }
    out = tool._parse_input(json.dumps(payload))
    assert out["data"]["columns"] == ["year", "value"]
    assert out["data"]["rows"] == [["2020", "1"], ["2021", "2"]]


def test_parse_input_convert_various_formats():
    tool = gt_mod.GraphingTool(security_manager=FakeSecurityManager())

    # Separate arrays format -> handled via _parse_input auto-convert
    data1 = {"data": {"months": ["Jan", "Feb"], "values": [1, 2]}}
    out1 = tool._parse_input(json.dumps(data1))
    assert out1["data"]["columns"] == ["months", "values"]
    assert out1["data"]["rows"] == [["Jan", 1], ["Feb", 2]]

    # List of dicts -> use the converter directly (since _parse_input only auto-converts dicts)
    list_of_dicts = [{"x": 1, "y": 5}, {"x": 2, "y": 9}]
    conv = tool._convert_to_standard_format(list_of_dicts)
    assert conv["columns"] == ["x", "y"]
    assert conv["rows"] == [[1, 5], [2, 9]]

    # x/y keys dict -> handled via _parse_input auto-convert
    data3 = {"data": {"x": [10, 20], "y": [3, 4]}}
    out3 = tool._parse_input(json.dumps(data3))
    assert out3["data"]["columns"] == ["x", "y"]
    assert out3["data"]["rows"] == [[10, 3], [20, 4]]


def test_parse_input_errors_when_no_data():
    tool = gt_mod.GraphingTool(security_manager=FakeSecurityManager())
    with pytest.raises(ValueError):
        tool._parse_input("{}")  # no data or extracted_data


def test_analyze_data_suggests_line_for_years():
    tool = gt_mod.GraphingTool(security_manager=FakeSecurityManager())
    data = {"columns": ["year", "value"], "rows": [[2020, 1], [2021, 2], [2022, 3]]}
    analysis = tool._analyze_data(data)
    assert analysis["has_time_series"] is True
    assert analysis["suggested_plot_type"] == "line"
    assert "year" in analysis["date_columns"]
    assert "value" in analysis["numeric_columns"]


def _assert_common_plot_elements(code: str):
    assert "__PLOT_PATH__" in code
    assert "plt.savefig(" in code
    assert "result = 'Plot saved successfully'" in code


def test_generate_line_code_from_time_series():
    tool = gt_mod.GraphingTool(security_manager=FakeSecurityManager())
    data = {"columns": ["date", "value"], "rows": [["2020-01-01", 1], ["2020-02-01", 2]]}
    analysis = tool._analyze_data(data)
    assert analysis["suggested_plot_type"] == "line"
    code = tool._generate_plot_code(data, analysis, instructions="", title="Line")
    _assert_common_plot_elements(code)
    assert "ax.plot(" in code  # line plot path


def test_generate_bar_code_from_small_categorical():
    tool = gt_mod.GraphingTool(security_manager=FakeSecurityManager())
    data = {"columns": ["category", "value"], "rows": [["A", 3], ["B", 5], ["A", 2]]}
    analysis = tool._analyze_data(data)
    # small row count + categorical -> bar
    assert analysis["suggested_plot_type"] == "bar"
    code = tool._generate_plot_code(data, analysis, instructions="", title="Bar")
    _assert_common_plot_elements(code)
    assert "groupby(" in code and "kind='bar'" in code


def test_generate_scatter_code_from_two_numeric():
    tool = gt_mod.GraphingTool(security_manager=FakeSecurityManager())
    data = {"columns": ["x", "y"], "rows": [[1, 2], [2, 3], [3, 5]]}
    analysis = tool._analyze_data(data)
    # two numeric, no time series -> scatter
    assert analysis["suggested_plot_type"] == "scatter"
    code = tool._generate_plot_code(data, analysis, instructions="", title="Scatter")
    _assert_common_plot_elements(code)
    assert "ax.scatter(" in code and "np.polyfit" in code  # trend line added


def test_generate_histogram_code_from_single_numeric():
    tool = gt_mod.GraphingTool(security_manager=FakeSecurityManager())
    data = {"columns": ["value"], "rows": [[1], [2], [2], [3], [5]]}
    analysis = tool._analyze_data(data)
    assert analysis["suggested_plot_type"] == "histogram"
    code = tool._generate_plot_code(data, analysis, instructions="", title="Hist")
    _assert_common_plot_elements(code)
    assert ".hist(" in code and "axvline" in code  # mean/median markers


def test_generate_box_code_from_large_categorical():
    tool = gt_mod.GraphingTool(security_manager=FakeSecurityManager())
    # many rows + categorical + numeric -> box (per _suggest_plot_type)
    rows = []
    for i in range(30):
        cat = "A" if i % 2 == 0 else "B"
        rows.append([cat, i % 7])
    data = {"columns": ["group", "score"], "rows": rows}
    analysis = tool._analyze_data(data)
    assert analysis["suggested_plot_type"] == "box"
    code = tool._generate_plot_code(data, analysis, instructions="", title="Box")
    _assert_common_plot_elements(code)
    assert "boxplot(" in code


def test_generate_default_code_when_heatmap_suggested():
    tool = gt_mod.GraphingTool(security_manager=FakeSecurityManager())
    # >2 numeric columns -> _suggest_plot_type returns 'heatmap'
    data = {
        "columns": ["n1", "n2", "n3"],
        "rows": [[1, 2, 3], [2, 4, 1], [3, 1, 5]],
    }
    analysis = tool._analyze_data(data)
    assert analysis["suggested_plot_type"] == "heatmap"
    code = tool._generate_plot_code(data, analysis, instructions="", title="Default")
    _assert_common_plot_elements(code)
    assert "numeric_cols = df.select_dtypes" in code



def test_execute_plot_code_success_creates_file(tmp_path):
    # Fake sandbox writes a PNG file at the path inside code
    sec = FakeSecurityManager()
    tool = gt_mod.GraphingTool(security_manager=sec, output_dir=str(tmp_path))

    # Minimal code that will be parsed by FakeSecurityManager to find the path and create a PNG
    code = "import matplotlib.pyplot as plt\nplt.figure(); plt.savefig('__PLOT_PATH__', dpi=200); result='Plot saved successfully'"

    res = tool._execute_plot_code(code)
    assert res["success"] is True
    assert Path(res["plot_path"]).exists()
    assert Path(res["plot_path"]).suffix == ".png"


def test_execute_plot_code_error_bubbles_as_error(tmp_path):
    sec = FakeSecurityManager(should_raise=True)
    tool = gt_mod.GraphingTool(security_manager=sec, output_dir=str(tmp_path))

    code = "plt.savefig('__PLOT_PATH__')"
    out = tool._execute_plot_code(code)
    assert out["success"] is False
    assert "Sandbox exploded" in out["error"]


def test_generate_plot_code_with_llm_prepends_data_when_missing(tmp_path):
    # LLM returns fenced code without "data ="
    fenced = "```python\nimport matplotlib.pyplot as plt\nplt.figure(); plt.savefig('__PLOT_PATH__')\nresult='Plot saved successfully'\n```"
    llm = FakeLLM(fenced)
    tool = gt_mod.GraphingTool(security_manager=FakeSecurityManager(), llm=llm, output_dir=str(tmp_path))

    data = {"columns": ["a", "b"], "rows": [[1, 2], [3, 4]]}
    analysis = tool._analyze_data({"columns": ["a", "b"], "rows": [[1, 2], [3, 4]]})
    code = tool._generate_plot_code(data, analysis, instructions="custom", title="LLM Plot")

    assert code.lstrip().startswith("data = ")
    assert "__PLOT_PATH__" in code
    assert llm.calls, "LLM should have been called"


def test_save_plot_and_preview(tmp_path):
    # Create a real small image on disk
    img_path = tmp_path / "plot.png"
    img = Image.new("RGB", (100, 50), (200, 100, 50))
    img.save(img_path, format="PNG")

    tool = gt_mod.GraphingTool(security_manager=FakeSecurityManager(), output_dir=str(tmp_path))
    input_data = {"data": {"columns": ["x", "y"], "rows": [[1, 2]]}, "title": "T"}
    analysis = {"suggested_plot_type": "line"}

    meta = tool._save_plot(str(img_path), input_data, analysis)
    assert meta["file_path"] == str(img_path)
    assert meta["dimensions"]["width"] == 100
    assert meta["dimensions"]["height"] == 50
    assert meta["plot_type"] == "line"
    assert meta["data_shape"]["rows"] == 1
    assert meta["title"] == "T"

    assert meta["preview"].startswith("data:image/png;base64,")
    base64.b64decode(meta["preview"].split(",", 1)[1])


def test_generate_preview_handles_errors(tmp_path, monkeypatch):
    tool = gt_mod.GraphingTool(security_manager=FakeSecurityManager(), output_dir=str(tmp_path))
    # Monkeypatch PIL to raise when opening
    class BadImage:
        def __enter__(self): raise OSError("bad image")
        def __exit__(self, *a): pass
    monkeypatch.setattr(gt_mod, "Image", type("ImgNS", (), {"open": lambda *a, **k: BadImage()}))
    assert tool._generate_preview(str(tmp_path / "nope.png")) == ""


def test_use_happy_path_end_to_end(tmp_path):
    sec = FakeSecurityManager()
    tool = gt_mod.GraphingTool(security_manager=sec, output_dir=str(tmp_path))

    payload = {
        "data": {
            "columns": ["year", "value"],
            "rows": [[2020, 1], [2021, 3], [2022, 2]]
        },
        "title": "Demo"
    }
    
    result = tool.use(json.dumps(payload))
    j = json.loads(result)
    assert j["status"] == "success"
    assert "plot_metadata" in j
    assert Path(j["plot_metadata"]["file_path"]).exists()
    assert "code_executed" in j
    assert "data_analysis" in j


def test_use_returns_error_when_execution_fails(tmp_path):
    sec = FakeSecurityManager(should_raise=True)
    tool = gt_mod.GraphingTool(security_manager=sec, output_dir=str(tmp_path))

    payload = {
        "data": {"columns": ["x", "y"], "rows": [[1, 2], [2, 3]]}
    }
    result = tool.use(json.dumps(payload))
    j = json.loads(result)
    assert j["status"] == "error"
    assert "error" in j
