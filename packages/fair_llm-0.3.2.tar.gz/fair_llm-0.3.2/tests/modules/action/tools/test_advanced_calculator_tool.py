import pytest
from sympy import simplify, expand, symbols
from fairlib.modules.action.tools.advanced_calculus_tool import AdvancedCalculusTool


class TestAdvancedCalculusTool:
    """Test cases for the AdvancedCalculusTool class."""

    def setup_method(self):
        """Set up test fixtures."""
        self.calculus_tool = AdvancedCalculusTool()
        
    def _extract_expression(self, result: str) -> str:
        """Extract the mathematical expression from the tool result."""
        if "is:\n" in result:
            return result.split("is:\n")[1].strip()
        if " is: " in result:
            return result.split(" is: ", 1)[1].strip()
        return result
        
    def _compare_expressions(self, result: str, expected: str) -> bool:
        """Compare two symbolic expressions for equality."""
        try:
            result_expr = self._extract_expression(result)
            x = symbols('x')
            # Convert to SymPy expressions and simplify
            result_sympy = simplify(result_expr)
            expected_sympy = simplify(expected)
            # Expand both expressions to handle different forms
            result_expanded = expand(result_sympy)
            expected_expanded = expand(expected_sympy)
            return result_expanded == expected_expanded
        except:
            # If parsing fails, fall back to string comparison
            return expected in result

    def test_tool_attributes(self):
        """Test that the tool has the correct name and description."""
        assert self.calculus_tool.name == "advanced_calculus_tool"
        assert "derivative" in self.calculus_tool.description
        assert "integral" in self.calculus_tool.description

    def test_derivative_basic(self):
        """Test basic derivative calculations."""
        test_cases = [
            ("derivative(x**2, x)", "2*x"),
            ("derivative(x**3, x)", "3*x**2"),
            ("derivative(sin(x), x)", "cos(x)"),
            ("derivative(cos(x), x)", "-sin(x)"),
            ("derivative(exp(x), x)", "exp(x)"),
            ("derivative(log(x), x)", "1/x"),
        ]
        
        for expression, expected in test_cases:
            result = self.calculus_tool.use(expression)
            assert "Error" not in result
            assert self._compare_expressions(result, expected), f"Expected {expected} in result: {result}"

    def test_derivative_complex(self):
        """Test complex derivative calculations."""
        test_cases = [
            ("derivative(x**2 + 2*x + 1, x)", "2*x + 2"),
            ("derivative(sin(x)**2, x)", "2*sin(x)*cos(x)"),
            ("derivative(x*sin(x), x)", "x*cos(x) + sin(x)"),
            ("derivative(exp(x)*sin(x), x)", "exp(x)*sin(x) + exp(x)*cos(x)"),
        ]
        
        for expression, expected in test_cases:
            result = self.calculus_tool.use(expression)
            assert "Error" not in result
            assert self._compare_expressions(result, expected), f"Expected {expected} in result: {result}"

    def test_indefinite_integral_basic(self):
        """Test basic indefinite integral calculations."""
        test_cases = [
            ("integral(x, x)", "x**2/2"),
            ("integral(x**2, x)", "x**3/3"),
            ("integral(sin(x), x)", "-cos(x)"),
            ("integral(cos(x), x)", "sin(x)"),
            ("integral(exp(x), x)", "exp(x)"),
            ("integral(1/x, x)", "log(x)"),
        ]
        
        for expression, expected in test_cases:
            result = self.calculus_tool.use(expression)
            assert "Error" not in result
            assert self._compare_expressions(result, expected), f"Expected {expected} in result: {result}"

    def test_indefinite_integral_complex(self):
        """Test complex indefinite integral calculations."""
        test_cases = [
            ("integral(x**2 + 2*x + 1, x)", "x**3/3 + x**2 + x"),
            ("integral(sin(x)*cos(x), x)", "sin(x)**2/2"),
            ("integral(x*exp(x), x)", "x*exp(x) - exp(x)"),
        ]
        
        for expression, expected in test_cases:
            result = self.calculus_tool.use(expression)
            assert "Error" not in result
            assert self._compare_expressions(result, expected), f"Expected {expected} in result: {result}"

    def test_definite_integral_basic(self):
        """Test basic definite integral calculations."""
        test_cases = [
            ("integral(x, x, 0, 1)", "1/2"),
            ("integral(x**2, x, 0, 2)", "8/3"),
            ("integral(sin(x), x, 0, pi)", "2"),
            ("integral(cos(x), x, 0, pi/2)", "1"),
        ]
        
        for expression, expected in test_cases:
            result = self.calculus_tool.use(expression)
            assert "Error" not in result
            assert self._compare_expressions(result, expected), f"Expected {expected} in result: {result}"

    def test_definite_integral_complex(self):
        """Test complex definite integral calculations."""
        test_cases = [
            ("integral(x**2 + 2*x + 1, x, 0, 1)", "7/3"),
            ("integral(exp(x), x, 0, 1)", "E - 1"),
            ("integral(sin(x)**2, x, 0, pi)", "pi/2"),
        ]
        
        for expression, expected in test_cases:
            result = self.calculus_tool.use(expression)
            assert "Error" not in result
            assert self._compare_expressions(result, expected), f"Expected {expected} in result: {result}"

    def test_derivative_error_handling(self):
        """Test error handling for invalid derivative expressions."""
        invalid_expressions = [
            "derivative(invalid_function(x), x)",
            "derivative(x**2, x, extra_param)",
            "derivative()",
            "derivative(x**2)",
            "derivative(x**2, x, y, z)",
        ]
        
        for expression in invalid_expressions:
            result = self.calculus_tool.use(expression)
            assert "Error" in result

    def test_integral_error_handling(self):
        """Test error handling for invalid integral expressions."""
        invalid_expressions = [
            "integral(invalid_function(x), x)",
            "integral(x**2, x, 0, 1, extra_param)",
            "integral()",
            "integral(x**2)",
            "integral(x**2, x, 0, 1, 2, 3)",
        ]
        
        for expression in invalid_expressions:
            result = self.calculus_tool.use(expression)
            assert "Error" in result

    def test_unsupported_commands(self):
        """Test handling of unsupported commands."""
        unsupported_commands = [
            "limit(x**2, x, 0)",
            "sum(x**2, x, 1, 10)",
            "solve(x**2 - 1, x)",
            "factor(x**2 - 1)",
            "expand((x + 1)**2)",
        ]
        
        for command in unsupported_commands:
            result = self.calculus_tool.use(command)
            assert "Unsupported command" in result

    def test_whitespace_handling(self):
        """Test that the tool handles whitespace correctly."""
        expressions_with_whitespace = [
            "  derivative(x**2, x)  ",
            "derivative(  x**2  ,  x  )",
            "  integral(x, x, 0, 1)  ",
            "integral(  x  ,  x  ,  0  ,  1  )",
        ]
        
        for expression in expressions_with_whitespace:
            result = self.calculus_tool.use(expression)
            assert "Error" not in result

    def test_mathematical_constants(self):
        """Test handling of mathematical constants."""
        test_cases = [
            ("derivative(pi*x, x)", "pi"),
            ("derivative(E*x, x)", "E"),
            ("integral(pi, x)", "pi*x"),
            ("integral(E, x)", "E*x"),
            ("integral(pi, x, 0, 1)", "pi"),
            ("integral(E, x, 0, 1)", "E"),
        ]
        
        for expression, expected in test_cases:
            result = self.calculus_tool.use(expression)
            assert "Error" not in result
            assert self._compare_expressions(result, expected), f"Expected {expected} in result: {result}"

    def test_trigonometric_functions(self):
        """Test trigonometric function derivatives and integrals."""
        test_cases = [
            ("derivative(tan(x), x)", "tan(x)**2 + 1"),
            ("derivative(cot(x), x)", "-cot(x)**2 - 1"),
            ("derivative(sec(x), x)", "tan(x)*sec(x)"),
            ("derivative(csc(x), x)", "-cot(x)*csc(x)"),
            ("integral(sec(x)**2, x)", "tan(x)"),
            ("integral(csc(x)**2, x)", "-cos(x)/sin(x)"),
        ]
        
        for expression, expected in test_cases:
            result = self.calculus_tool.use(expression)
            assert "Error" not in result
            assert self._compare_expressions(result, expected), f"Expected {expected} in result: {result}"

    def test_logarithmic_functions(self):
        """Test logarithmic function derivatives and integrals."""
        test_cases = [
            ("derivative(log(x), x)", "1/x"),
            ("derivative(log(x**2), x)", "2/x"),
            ("integral(1/x, x)", "log(x)"),
            ("integral(1/(x + 1), x)", "log(x + 1)"),
        ]
        
        for expression, expected in test_cases:
            result = self.calculus_tool.use(expression)
            assert "Error" not in result
            assert self._compare_expressions(result, expected), f"Expected {expected} in result: {result}"

    def test_exponential_functions(self):
        """Test exponential function derivatives and integrals."""
        test_cases = [
            ("derivative(exp(x), x)", "exp(x)"),
            ("derivative(exp(x**2), x)", "2*x*exp(x**2)"),
            ("integral(exp(x), x)", "exp(x)"),
            ("integral(x*exp(x), x)", "x*exp(x) - exp(x)"),
        ]
        
        for expression, expected in test_cases:
            result = self.calculus_tool.use(expression)
            assert "Error" not in result
            assert self._compare_expressions(result, expected), f"Expected {expected} in result: {result}"

    def test_polynomial_functions(self):
        """Test polynomial function derivatives and integrals."""
        test_cases = [
            ("derivative(x**5, x)", "5*x**4"),
            ("derivative(3*x**4 + 2*x**3 + x**2 + x + 1, x)", "12*x**3 + 6*x**2 + 2*x + 1"),
            ("integral(x**5, x)", "x**6/6"),
            ("integral(3*x**4 + 2*x**3 + x**2 + x + 1, x)", "3*x**5/5 + x**4/2 + x**3/3 + x**2/2 + x"),
        ]
        
        for expression, expected in test_cases:
            result = self.calculus_tool.use(expression)
            assert "Error" not in result
            assert self._compare_expressions(result, expected), f"Expected {expected} in result: {result}"

    def test_definite_integral_with_constants(self):
        """Test definite integrals with mathematical constants."""
        test_cases = [
            ("integral(sin(x), x, 0, pi)", "2"),
            ("integral(cos(x), x, 0, pi/2)", "1"),
            ("integral(exp(x), x, 0, 1)", "E - 1"),
            ("integral(1/x, x, 1, E)", "1"),
        ]
        
        for expression, expected in test_cases:
            result = self.calculus_tool.use(expression)
            assert "Error" not in result
            assert self._compare_expressions(result, expected), f"Expected {expected} in result: {result}"

    def test_edge_cases(self):
        """Test edge cases and boundary conditions."""
        edge_cases = [
            ("derivative(0, x)", "0"),
            ("derivative(1, x)", "0"),
            ("derivative(x, x)", "1"),
            ("integral(0, x)", "0"),
            ("integral(1, x)", "x"),
            ("integral(x, x)", "x**2/2"),
        ]
        
        for expression, expected in edge_cases:
            result = self.calculus_tool.use(expression)
            assert "Error" not in result
            assert self._compare_expressions(result, expected), f"Expected {expected} in result: {result}"

    def test_complex_expressions(self):
        """Test complex mathematical expressions."""
        complex_expressions = [
            ("derivative(sin(x)*cos(x)*exp(x), x)", "sin(x)*cos(x)*exp(x) + cos(x)**2*exp(x) - sin(x)**2*exp(x)"),
            ("integral(sin(x)*cos(x), x)", "sin(x)**2/2"),
            ("integral(x*sin(x), x)", "-x*cos(x) + sin(x)"),
        ]
        
        for expression, expected in complex_expressions:
            result = self.calculus_tool.use(expression)
            assert "Error" not in result
            assert self._compare_expressions(result, expected), f"Expected {expected} in result: {result}"

    def test_error_messages(self):
        """Test that error messages are informative."""
        # Test malformed derivative
        result = self.calculus_tool.use("derivative(x**2)")
        assert "Error" in result
        assert "parsing" in result or "Failed to compute" in result
        
        # Test malformed integral
        result = self.calculus_tool.use("integral(x**2, x, 0)")
        assert "Error" in result
        assert "Invalid number of arguments" in result or "Failed to compute" in result
        
        # Test invalid function
        result = self.calculus_tool.use("derivative(invalid_function(x), x)")
        assert "Error" in result
        assert "Failed to compute" in result or "parsing" in result
