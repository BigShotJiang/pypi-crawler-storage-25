# tests/modules/tools/builtin_tools/test_web_searcher.py
import json
import pytest

import fairlib.modules.action.tools.builtin_tools.web_searcher as ws


class _FakeResponse:
    def __init__(self, status_code=200, payload=None):
        self.status_code = status_code
        self._payload = payload or {}

    def json(self):
        return self._payload


class _FakeProvider(ws.SearchProvider):
    def __init__(self, name="fake", results=None, exc: Exception | None = None):
        self._name = name
        self._results = results or []
        self._exc = exc
        self.calls = []

    @property
    def name(self) -> str:
        return self._name

    def search(self, query: str, **kwargs):
        self.calls.append({"query": query, "kwargs": kwargs})
        if self._exc:
            raise self._exc
        return self._results


class _FakeDateContext:
    def __init__(self, suffix=""):
        self.suffix = suffix
        self.calls = 0

    def enhance_with_date(self, q: str) -> str:
        self.calls += 1
        return q + self.suffix  # deterministic & easy to assert


def test_google_pse_search_success(monkeypatch):
    prov = ws.GooglePSEProvider(api_key="KEY", search_engine_id="CX")

    # patch the session.get on this instance
    captured = {}
    def fake_get(url, params=None, timeout=None):
        captured["url"] = url
        captured["params"] = params
        captured["timeout"] = timeout
        payload = {
            "searchInformation": {"totalResults": "123"},
            "items": [
                {
                    "title": "T1",
                    "link": "https://example.com/a",
                    "displayLink": "example.com",
                    "snippet": "snippet one",
                    "pagemap": {"metatags": [{
                        "article:published_time": "2025-01-01",
                        "author": "Jane",
                        "og:description": "desc1"
                    }]}
                },
                {
                    "title": "T2",
                    "link": "https://nasa.gov/b",
                    "displayLink": "nasa.gov",
                    "snippet": "snippet two"
                }
            ],
        }
        return _FakeResponse(200, payload)

    monkeypatch.setattr(prov.session, "get", fake_get)

    results = prov.search("mars weather", count=7, safe_search="off", date_restrict="d7", site="nasa.gov")

    # params built correctly (num capped at 10)
    assert captured["url"].endswith("/customsearch/v1")
    assert captured["params"]["key"] == "KEY"
    assert captured["params"]["cx"] == "CX"
    assert captured["params"]["q"] == "mars weather"
    assert captured["params"]["num"] == 7
    assert captured["params"]["safe"] == "off"
    assert captured["params"]["dateRestrict"] == "d7"
    assert captured["params"]["siteSearch"] == "nasa.gov"
    assert captured["params"]["siteSearchFilter"] == "i"
    assert captured["timeout"] == 10

    # results parsed & metadata extracted
    assert len(results) == 2
    r0 = results[0]
    assert r0["title"] == "T1"
    assert r0["url"] == "https://example.com/a"
    assert r0["display_url"] == "example.com"
    assert r0["snippet"] == "snippet one"
    assert r0["source"] == "Google"
    assert r0["total_results"] == "123"
    assert r0["original_query"] == "mars weather"
    assert r0["date_published"] == "2025-01-01"
    assert r0["author"] == "Jane"
    assert r0["description"] == "desc1"


def test_google_pse_rate_limit(monkeypatch):
    prov = ws.GooglePSEProvider("KEY", "CX")
    monkeypatch.setattr(prov.session, "get", lambda *a, **k: _FakeResponse(429, {"error": {"message": "rate limit"}}))
    with pytest.raises(Exception) as exc:
        prov.search("q")
    assert "rate limit" in str(exc.value).lower()


def test_google_pse_non_200_error(monkeypatch):
    prov = ws.GooglePSEProvider("KEY", "CX")
    payload = {"error": {"message": "bad request"}}
    monkeypatch.setattr(prov.session, "get", lambda *a, **k: _FakeResponse(400, payload))
    with pytest.raises(Exception) as exc:
        prov.search("q")
    assert "bad request" in str(exc.value)


def test_google_pse_timeout_and_network(monkeypatch):
    prov = ws.GooglePSEProvider("KEY", "CX")

    class _Timeout(Exception): pass
    # emulate requests.Timeout & RequestException branches
    monkeypatch.setattr(ws.requests, "Timeout", _Timeout)
    monkeypatch.setattr(ws.requests, "RequestException", Exception)

    def raise_timeout(*a, **k):
        raise _Timeout()

    def raise_network(*a, **k):
        raise Exception("boom")

    # timeout
    monkeypatch.setattr(prov.session, "get", raise_timeout)
    with pytest.raises(Exception) as exc1:
        prov.search("q")
    assert "timed out" in str(exc1.value).lower()

    # network error
    monkeypatch.setattr(prov.session, "get", raise_network)
    with pytest.raises(Exception) as exc2:
        prov.search("q")
    assert "network error" in str(exc2.value).lower()


def test_cache_get_set_and_ttl_expiry(monkeypatch):
    cache = ws.SearchCache(ttl_seconds=60, max_size=100)

    # Fake datetime with controllable "now"
    class _FakeDT:
        current = None
        @classmethod
        def now(cls):
            return cls.current

    # patch datetime used inside web_searcher module
    monkeypatch.setattr(ws, "datetime", _FakeDT)

    from datetime import datetime as real_dt  # for making real timestamps
    t0 = real_dt(2025, 1, 1, 12, 0, 0)
    t1 = real_dt(2025, 1, 1, 12, 0, 30)  # within ttl
    t2 = real_dt(2025, 1, 1, 12, 2, 0)   # beyond ttl (120s later)

    _FakeDT.current = t0
    cache.set("alpha", [{"x": 1}])

    _FakeDT.current = t1
    assert cache.get("alpha") == [{"x": 1}]  # cache hit

    _FakeDT.current = t2
    assert cache.get("alpha") is None  # expired


def test_cache_size_eviction():
    cache = ws.SearchCache(ttl_seconds=3600, max_size=2)
    cache.set("k1", [1])
    cache.set("k2", [2])
    cache.set("k3", [3])

    assert len(cache.cache) <= 2


def test_initialize_providers_ok_and_missing(monkeypatch):
    cfg = {"google_api_key": "K", "google_search_engine_id": "CX", "cache_ttl": 1}
    tool = ws.WebSearcherTool(cfg)
    assert tool.providers and tool.providers[0].name == "Google PSE"

    with pytest.raises(ValueError):
        ws.WebSearcherTool({})


def test_enhance_query_variants(monkeypatch):
    tool = ws.WebSearcherTool({"google_api_key": "K", "google_search_engine_id": "CX"})
    # Monkeypatch date mixin so enhance_with_date is identity
    monkeypatch.setattr(tool, "date_context_mix", _FakeDateContext(""))

    # news"
    out = tool._enhance_query("mars rover", "news")
    assert "mars rover" in out and "news" in out and str(ws.datetime.now().year) in out
    # academic
    assert tool._enhance_query("quantum", "academic").endswith("research paper scholarly")
    # code
    assert tool._enhance_query("binary search", "code").endswith("programming code example")
    # financial
    assert tool._enhance_query("btc", "financial").endswith("finance market data")

    # time range "past 3 years" adds "YYYY-YYYY"
    q = tool._enhance_query("inflation past 3 years", "general")
    assert "-" in q and str(ws.datetime.now().year) in q


def test_rank_results_scoring_and_sorting(monkeypatch):
    tool = ws.WebSearcherTool({"google_api_key": "K", "google_search_engine_id": "CX"})
    monkeypatch.setattr(tool, "date_context_mix", _FakeDateContext(""))

    original = "global temperature dataset"
    results = [
        {"title": "Random blog", "snippet": "some text", "url": "https://example.com/x"},
        {"title": "NOAA climate data", "snippet": "download CSV dataset", "url": "https://noaa.gov/data"},
        {"title": "GitHub repo", "snippet": "API client for temperature", "url": "https://github.com/user/proj"},
    ]
    ranked = tool._rank_results(results, original)

    # NOAA/GitHub + dataset/download/api indicators should float to top
    assert ranked[0]["url"] in ("https://noaa.gov/data", "https://github.com/user/proj")
    # relevance_score exists and is numeric
    assert all("relevance_score" in r for r in ranked)


def test_use_happy_path_with_cache(monkeypatch):
    # Create tool with no real providers; we will inject our own fake provider list.
    tool = ws.WebSearcherTool({"google_api_key": "K", "google_search_engine_id": "CX", "max_results": 5})
    # Make date enhancer deterministic
    fake_date = _FakeDateContext(suffix=" [D]")
    monkeypatch.setattr(tool, "date_context_mix", fake_date)

    good_results = [
        {"title": "A", "snippet": "dataset csv", "url": "https://data.org/a"},
        {"title": "B", "snippet": "news", "url": "https://example.com/b"},
    ]
    provider = _FakeProvider(name="provider-1", results=good_results)
    monkeypatch.setattr(tool, "providers", [provider])

    # First call: cache miss, provider searched
    out1 = json.loads(tool.use("climate data", search_type="general"))
    assert out1["enhanced_query"].startswith("climate data")
    assert out1["results"]  # ranked results present
    assert "from_cache" not in out1  # first response shape (no from_cache key)
    assert provider.calls and provider.calls[0]["kwargs"]["count"] == 5

    # Second call with same (enhanced) query → should serve from cache
    out2 = json.loads(tool.use("climate data", search_type="general"))
    assert out2["from_cache"] is True
    assert out2["results"] == out1["results"]


def test_use_all_providers_fail_and_error_shape(monkeypatch):
    tool = ws.WebSearcherTool({"google_api_key": "K", "google_search_engine_id": "CX"})
    monkeypatch.setattr(tool, "date_context_mix", _FakeDateContext(""))

    p1 = _FakeProvider(name="p1", exc=Exception("bad A"))
    p2 = _FakeProvider(name="p2", exc=Exception("bad B"))
    monkeypatch.setattr(tool, "providers", [p1, p2])

    payload = json.loads(tool.use("query that fails", search_type="news"))
    assert payload["error"] == "All search providers failed"
    assert "p1: bad A" in payload["details"][0]
    assert "p2: bad B" in payload["details"][1]
    assert payload["query"].startswith("query that fails")
