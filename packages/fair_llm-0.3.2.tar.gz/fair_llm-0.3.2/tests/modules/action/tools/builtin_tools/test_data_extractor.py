# tests/modules/tools/builtin_tools/test_data_extractor.py
import json
import types
import sys
import pandas as pd

# Stub PyPDF2 before the SUT is imported, so no real module is loaded
sys.modules.setdefault("PyPDF2", types.SimpleNamespace(PdfReader=None))

import fairlib.modules.action.tools.builtin_tools.data_extractor as de_mod


class FakeLLM:
    """Minimal LLM double returning a JSON string; can inject fenced output."""
    def __init__(self, payload: dict | None = None, fenced: bool = False, raise_err: bool = False):
        self.payload = payload or {"url": "https://api.example.com?q=x", "method": "GET", "headers": {}, "explanation": "ok"}
        self.fenced = fenced
        self.raise_err = raise_err
        self.calls = []

    def chat(self, messages):
        self.calls.append(messages)
        if self.raise_err:
            raise RuntimeError("LLM boom")
        s = json.dumps(self.payload)
        if self.fenced:
            return "```json\n" + s + "\n```"
        return s


class FakeResp:
    """Fake requests.Response for ContentFetcher; supports streaming + headers."""
    def __init__(self, body: bytes, status=200, headers=None, url="https://ex", encoding="utf-8", raise_for_status_ok=True, chunk=4096):
        self._body = body
        self.status_code = status
        self.headers = headers or {"Content-Type": "text/plain"}
        self.url = url
        self.encoding = encoding
        self._raise_ok = raise_for_status_ok
        self._chunk = chunk

    def raise_for_status(self):
        if not self._raise_ok:
            class E(Exception): ...
            raise E("HTTP error")

    def iter_content(self, chunk_size=8192):
        b = self._body
        for i in range(0, len(b), self._chunk):
            yield b[i:i+self._chunk]

    def json(self):
        return json.loads(self._body.decode(self.encoding))


CSV_BYTES = b"year,value\n2020,1\n2021,2\n"

def test_urlcleaner_clean_and_extract():
    raw = 'https://example.com/path?x=1, and also http://foo.bar/a/b.;'
    urls = de_mod.URLCleaner.extract_urls_from_text(raw)
    assert urls == ["https://example.com/path?x=1", "http://foo.bar/a/b"]

    # trailing punctuation + missing scheme
    cleaned = de_mod.URLCleaner.clean_url('example.org/path?y=2,')
    assert cleaned.startswith("https://example.org/path?y=2")


def test_contentfetcher_fetch_ok(monkeypatch):
    cf = de_mod.ContentFetcher(timeout=5, max_size=1024 * 1024)
    # Patch the instance session.get
    body = b"<html><body>ok</body></html>"
    resp = FakeResp(body, headers={"Content-Type": "text/html; charset=utf-8"}, url="https://site/page")
    monkeypatch.setattr(cf.session, "get", lambda *a, **k: resp)

    content, ctype, meta = cf.fetch("https://site/page")
    assert content == body
    assert "html" in ctype
    assert meta["status_code"] == 200
    assert meta["url"] == "https://site/page"


def test_contentfetcher_size_limit(monkeypatch):
    cf = de_mod.ContentFetcher(timeout=5, max_size=10)
    big = b"x" * 50
    # stream that exceeds size
    resp = FakeResp(big, headers={"Content-Type": "text/plain", "Content-Length": f"{len(big)}"}, url="https://x")
    monkeypatch.setattr(cf.session, "get", lambda *a, **k: resp)

    content, ctype, meta = cf.fetch("https://x")
    assert content is None and ctype is None
    assert "Content too large" in meta["error"]


def test_contentfetcher_http_error(monkeypatch):
    cf = de_mod.ContentFetcher()
    resp = FakeResp(b"oops", status=500, raise_for_status_ok=False)
    monkeypatch.setattr(cf.session, "get", lambda *a, **k: resp)
    content, ctype, meta = cf.fetch("https://err")
    assert content is None and ctype is None and "HTTP error" in meta["error"]


def test_generic_api_identify_types():
    llm = FakeLLM()
    api = de_mod.GenericAPIConstructor(llm)

    # Looks like API docs (columns + rows contain 'parameter'/'endpoint')
    content_api = {"columns": ["Parameter", "Endpoint"], "rows": [["q", "/v1/search"]]}
    assert api._identify_content_type(content_api) == "api_documentation"

    # Data portal (download indicators)
    content_portal = {"links": ["Download CSV", "Export JSON"]}
    assert api._identify_content_type(content_portal) == "data_portal"

    # Form interface (select/option present)
    content_form = {"form": {"Select": ["A", "B"], "input": "x"}}
    assert api._identify_content_type(content_form) == "form_interface"

    # Unknown
    assert api._identify_content_type({"foo": "bar"}) == "unknown"


def test_generic_api_handlers_success_and_fenced_json():
    llm = FakeLLM(payload={"url": "https://api.ex/data?x=1", "method": "GET", "headers": {}, "explanation": "demo"}, fenced=True)
    api = de_mod.GenericAPIConstructor(llm)

    # api docs path
    base = "https://api.ex"
    content = {"columns": ["Parameter", "Endpoint"], "rows": [["q", "/v1"]]}
    out = api._handle_api_documentation(base, content, "get data")
    assert out["url"].startswith("https://")
    assert out["method"] in ("GET", "POST")
    assert llm.calls

    # data portal path
    llm2 = FakeLLM(payload={"download_urls": ["https://ex/file.csv"], "format": "csv", "explanation": "best"})
    api2 = de_mod.GenericAPIConstructor(llm2)
    portal = api2._handle_data_portal({"links": ["csv"]}, "dl")
    assert "download_urls" in portal

    # form interface
    llm3 = FakeLLM(payload={"url": "https://ex/form?y=1", "method": "GET", "params": {"y": 1}, "data": {}, "explanation": "ok"})
    api3 = de_mod.GenericAPIConstructor(llm3)
    form = api3._handle_form_interface("https://ex", {"select": ["A"]}, "fill form")
    assert form["url"].startswith("https://")


def test_generic_api_handlers_error_returns_none():
    api = de_mod.GenericAPIConstructor(FakeLLM(raise_err=True))
    assert api._handle_api_documentation("https://x", {}, "c") is None
    assert api._handle_data_portal({}, "c") is None
    assert api._handle_form_interface("https://x", {}, "c") is None


def test_html_data_parser_tables_and_lists(monkeypatch):
    html = """
    <html><body>
      <table>
        <tr><th>Year</th><th>Value</th></tr>
        <tr><td>2020</td><td>1</td></tr>
        <tr><td>2021</td><td>2</td></tr>
      </table>
      <dl>
        <dt>City</dt><dd>Paris</dd>
        <dt>Country</dt><dd>France</dd>
      </dl>
    </body></html>
    """
    parser = de_mod.HTMLDataParser()
    tables = parser.extract_tables(html, "https://site")
    lists = parser.extract_structured_lists(html, "https://site")
    assert tables and tables[0].data_type == "table" and tables[0].rows[0] == [2020, 1]
    assert lists and lists[0].data_type == "definition_list" and lists[0].rows == [["City", "Paris"], ["Country", "France"]]


def test_csv_parser_ok_and_error(caplog):
    p = de_mod.CSVDataParser()
    out = p.parse_csv_url(CSV_BYTES, "https://f.csv")
    assert out and out.data_type == "csv" and out.columns == ["year", "value"] and out.rows == [[2020, 1],[2021, 2]]

    # bad content causes None
    with caplog.at_level("ERROR"):
        assert p.parse_csv_url(b"\xff\xfe\x00", "https://f.csv") is None


def test_json_parser_variants_and_fallback():
    jp = de_mod.JSONDataParser()

    # array of objects
    data1 = b'[{"a":1,"b":2},{"a":2,"b":3}]'
    out1 = jp.parse_json(data1, "https://x.json")
    assert out1 and out1.data_type == "json_array" and out1.columns == ["a", "b"]

    # dict with nested list of dicts
    data2 = b'{"items":[{"x":1},{"x":2}]}'
    out2 = jp.parse_json(data2, "https://x.json")
    assert out2 and out2.data_type == "json_nested"

    # parallel arrays
    data3 = b'{"dates":["2020","2021"], "values":[1,2]}'
    out3 = jp.parse_json(data3, "https://x.json")
    assert out3 and out3.data_type == "json_parallel_arrays" and out3.columns == ["dates", "values"]

    # fallback flatten
    data4 = b'{"k":{"m":1}}'
    out4 = jp.parse_json(data4, "https://x.json")
    assert out4 and out4.data_type == "json_flattened"

    # error path
    assert jp.parse_json(b'{bad json}', "https://x.json") is None


def test_llm_data_extractor_happy_and_fenced_and_infer():
    payload = {"columns": ["date", "value"], "rows": [["2020", "1"], ["2021", "2"]]}
    llm = FakeLLM(payload=payload, fenced=True)
    ext = de_mod.LLMDataExtractor(llm)
    out = ext.extract_from_text("some text with numbers", "ctx", "https://s")
    assert out and out.data_type == "time_series" and out.columns == ["date", "value"]

    # key_value_pairs inference
    payload2 = {"columns": ["k", "v"], "rows": [["a", "1"]]}
    llm2 = FakeLLM(payload=payload2)
    ext2 = de_mod.LLMDataExtractor(llm2)
    out2 = ext2.extract_from_text("t", "c", "https://s")
    assert out2.data_type in ("key_value_pairs", "general_data")  # len==2 tends to key_value_pairs

    # error
    ext_err = de_mod.LLMDataExtractor(FakeLLM(raise_err=True))
    assert ext_err.extract_from_text("t", "c", "https://s") is None


def test_parse_input_from_search_results_json(monkeypatch):
    wd = de_mod.WebDataExtractor(FakeLLM())
    # make date context deterministic
    class FakeDC:
        def get_current_date_context(self): return {"now": "2025-01-01"}
    monkeypatch.setattr(wd, "date_context", FakeDC())

    data = {
        "query": "sea surface temperature",
        "results": [
            {"url": "https://ex.com/a,",
             "title": "T1",
             "snippet": "S1"},
            {"url": "http://foo.bar/b", "title": "T2", "snippet": "S2"}
        ]
    }
    parsed = wd._parse_input(json.dumps(data))
    assert parsed["original_query"] == "sea surface temperature"
    assert parsed["urls"][0]["url"].startswith("https://ex.com/a")
    assert parsed["urls"][1]["url"] == "http://foo.bar/b"
    assert parsed["date_context"]["now"] == "2025-01-01"


def test_parse_input_direct_url_json_and_plain_text(monkeypatch):
    wd = de_mod.WebDataExtractor(FakeLLM())
    class FakeDC:
        def get_current_date_context(self): return {"now": "X"}
    monkeypatch.setattr(wd, "date_context", FakeDC())

    parsed1 = wd._parse_input(json.dumps({"url": "example.org/x?y=1", "context": "need data"}))
    assert parsed1["urls"][0]["url"].startswith("https://example.org/x")
    assert parsed1["context"] == "need data"

    # plain text with urls + context
    text = "Get data from https://site/a.csv and also check https://x/b.json please."
    parsed2 = wd._parse_input(text)
    assert len(parsed2["urls"]) == 2
    assert "Get data from" in parsed2["original_query"]


def test_extract_data_routes_csv_json_html(monkeypatch):
    wd = de_mod.WebDataExtractor(FakeLLM(payload={"columns": [], "rows": []}))  # LLM returns no data
    # CSV
    out_csv = wd._extract_data("https://s.csv", CSV_BYTES, "text/csv", "ctx")
    assert out_csv and out_csv[0].data_type == "csv"

    # JSON
    js = b'[{"a":1},{"a":2}]'
    out_json = wd._extract_data("https://s.json", js, "application/json", "ctx")
    assert out_json and out_json[0].data_type in ("json_array", "json_nested", "json_flattened")

    # HTML → tables + lists (and no LLM since tables exist)
    html = b"<table><tr><th>x</th></tr><tr><td>1</td></tr></table><dl><dt>A</dt><dd=B></dd></dl>"
    out_html = wd._extract_data("https://s.html", html, "text/html", "ctx")
    assert out_html and any(d.data_type == "table" for d in out_html)


def test_extract_pdf_and_excel(monkeypatch):
    wd = de_mod.WebDataExtractor(FakeLLM(payload={"columns": ["item","value"], "rows":[["a","1"]]}))

    # Mock PyPDF2.PdfReader
    class FakePage:
        def extract_text(self): return "Some PDF text 123"
    class FakeReader:
        def __init__(self, _): self.pages = [FakePage(), FakePage()]
    # Patch the PyPDF2 object that the SUT already imported
    monkeypatch.setattr(de_mod, "PyPDF2", types.SimpleNamespace(PdfReader=FakeReader))

    pdf_bytes = b"%PDF anything"  # arbitrary; it won’t be parsed by real PyPDF2 now
    pdf_out = wd._extract_data("https://s.pdf", pdf_bytes, "application/pdf", "ctx")
    assert pdf_out and pdf_out[0].metadata["source_type"] == "pdf" and pdf_out[0].metadata["page_count"] == 2

    # Mock pandas.read_excel to avoid real Excel parsing
    def fake_read_excel(_bytes, sheet_name=None):
        return {
            "Sheet1": pd.DataFrame({"a": [1, 2]}),
            "Empty": pd.DataFrame({"a": []})
        }
    monkeypatch.setattr(de_mod.pd, "read_excel", fake_read_excel)

    xlsx = b"PK\x03\x04fake"  # arbitrary bytes; parser is mocked
    xl = wd._extract_data("https://s.xlsx", xlsx, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "ctx")
    assert xl and xl[0].data_type == "excel_sheet" and xl[0].metadata["sheet_name"] == "Sheet1"


def test_contains_actual_data_and_date_range():
    data = de_mod.ExtractedData(
        source_url="u",
        data_type="csv",
        columns=["year", "value"],
        rows=[["2020", "10"], ["2021", "11"]],
        metadata={}, extraction_method="t", confidence_score=1.0
    )
    wd = de_mod.WebDataExtractor(FakeLLM())
    assert wd._contains_actual_data(data) is True
    rng = wd._get_date_range(data)
    assert rng["start"] == "2020" and rng["end"] == "2021"


def test_intelligent_extract_direct_success(monkeypatch):
    wd = de_mod.WebDataExtractor(FakeLLM())
    # Direct fetch returns CSV bytes
    class CF:
        def fetch(self, url):
            return (CSV_BYTES, "text/csv", {"url": url})
    monkeypatch.setattr(wd, "content_fetcher", CF())

    extracted, strategies = wd._intelligent_extract("https://x/data.csv", "ctx", "orig")
    assert extracted and extracted[0].data_type == "csv"
    assert any("SUCCESS" in s for s in strategies)


def test_intelligent_extract_direct_fetch_then_success(monkeypatch):
    # initial fetch returns HTML with no structured data; then constructor gives a URL
    llm = FakeLLM(payload={"url": "https://x/data.json", "method": "GET", "headers": {}, "explanation": "try api"})
    wd = de_mod.WebDataExtractor(llm)

    class CF2:
        def __init__(self):
            self.calls = []
        def fetch(self, url):
            self.calls.append(url)
            if url == "https://x/data.json":
                return (b'[{"a":1},{"a":2}]', "application/json", {})
            return (None, None, {})

    monkeypatch.setattr(wd, "content_fetcher", CF2())
    extracted, strategies = wd._intelligent_extract("https://x/data.json", "ctx", "orig")
    assert extracted and extracted[0].data_type in ("json_array", "json_nested", "json_flattened")
    assert any("SUCCESS: Found data in initial fetch" in s for s in strategies)


def test_format_results_success_and_docs_only():
    wd = de_mod.WebDataExtractor(FakeLLM())

    data = de_mod.ExtractedData(
        source_url="u",
        data_type="time_series",
        columns=["date", "v"],
        rows=[["2020", 1], ["2021", 2]],
        metadata={}, extraction_method="x", confidence_score=1.0
    )
    docs = de_mod.ExtractedData(
        source_url="u2",
        data_type="general_data",
        columns=["Parameter", "Type"],
        rows=[["q", "str"]],
        metadata={}, extraction_method="x", confidence_score=1.0
    )
    # success path
    s = wd._format_results([data], ["Direct content fetch", "SUCCESS: Found data"])
    j = json.loads(s)
    assert j["status"] == "success" and j["data_found"] is True
    assert j["extracted_data"][0]["row_count"] == 2
    assert "summary" in j

    # docs-only / partial
    s2 = wd._format_results([docs], ["Direct content fetch"])
    j2 = json.loads(s2)
    assert j2["status"] in ("partial",) and j2["data_found"] is False
    assert "suggestions" in j2
