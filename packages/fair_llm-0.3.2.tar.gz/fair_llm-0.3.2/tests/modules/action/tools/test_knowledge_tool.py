import pytest
from fairlib.modules.action.tools.knowledge_tool import KnowledgeBaseQueryTool
from fairlib.core.types import Document


class _FakeRetriever:
    """Captures retrieve() calls and returns synthetic Document objects."""

    def __init__(self, docs=None):
        self.last_query = None
        self.last_top_k = None
        self._docs = docs if docs is not None else [Document(page_content="chunk A"), Document(page_content="chunk B")]

    def retrieve(self, query: str, top_k: int = 2, **kwargs):
        self.last_query = query
        self.last_top_k = top_k
        return self._docs[:top_k]


class TestKnowledgeBaseQueryToolTopK:
    def test_default_top_k_is_2(self):
        retriever = _FakeRetriever()
        tool = KnowledgeBaseQueryTool(retriever)
        assert tool.top_k == 2

    def test_custom_top_k_stored(self):
        retriever = _FakeRetriever()
        tool = KnowledgeBaseQueryTool(retriever, top_k=5)
        assert tool.top_k == 5

    def test_use_passes_top_k_to_retriever(self):
        retriever = _FakeRetriever()
        tool = KnowledgeBaseQueryTool(retriever, top_k=1)
        tool.use("some query")
        assert retriever.last_top_k == 1

    def test_use_passes_default_top_k_to_retriever(self):
        retriever = _FakeRetriever()
        tool = KnowledgeBaseQueryTool(retriever)
        tool.use("some query")
        assert retriever.last_top_k == 2

    def test_use_passes_query_string(self):
        retriever = _FakeRetriever()
        tool = KnowledgeBaseQueryTool(retriever)
        tool.use("test claim")
        assert retriever.last_query == "test claim"

    def test_use_formats_results(self):
        retriever = _FakeRetriever()
        tool = KnowledgeBaseQueryTool(retriever, top_k=2)
        result = tool.use("q")
        assert "chunk A" in result
        assert "chunk B" in result
        assert result.startswith("Observation:")

    def test_use_returns_no_results_message_on_empty(self):
        retriever = _FakeRetriever(docs=[])
        tool = KnowledgeBaseQueryTool(retriever)
        result = tool.use("q")
        assert "No relevant information" in result

    def test_use_handles_retriever_exception(self):
        class _BrokenRetriever:
            def retrieve(self, **kwargs):
                raise RuntimeError("db down")

        tool = KnowledgeBaseQueryTool(_BrokenRetriever())
        result = tool.use("q")
        assert "Error" in result
