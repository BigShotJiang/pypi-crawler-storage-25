# test_load_balancer_adapter.py

"""
Unit tests for the LoadBalancer adapter.
All tests mock the requests library — no real vLLM server needed.
"""

import pytest
import asyncio
import requests as _real_requests
from unittest.mock import MagicMock, patch, AsyncMock

from fairlib.core.errors import AdapterError
from fairlib.core.message import Message

# We need to keep the patch active for the adapter's lifetime because
# load_balancer_adapter uses `requests` at the module level.
# The _make_adapter helper returns a context that must stay active.

MODULE = "fairlib.modules.mal.load_balancer_adapter"


@pytest.fixture
def adapter_and_mocks():
    """Create a LoadBalancerAdapter with requests mocked for the duration of the test."""
    with patch(f"{MODULE}.requests") as mock_requests:
        mock_requests.exceptions = _real_requests.exceptions

        # Mock validate response
        mock_validate = MagicMock()
        mock_validate.json.return_value = {
            "supported_models": ["mistralai/Mistral-7B-Instruct-v0.3", "other-model"]
        }
        mock_validate.raise_for_status = MagicMock()
        mock_requests.get.return_value = mock_validate

        # Mock preload response
        mock_preload = MagicMock()
        mock_preload.json.return_value = {"choices": [{"message": {"content": "ok"}}]}
        mock_preload.raise_for_status = MagicMock()
        mock_preload.status_code = 200
        mock_requests.post.return_value = mock_preload

        from fairlib.modules.mal.load_balancer_adapter import LoadBalancerAdapter
        adapter = LoadBalancerAdapter(
            manager_ip="10.0.0.1",
            model="mistralai/Mistral-7B-Instruct-v0.3",
            port=8123,
            preload_model=False,
            verbose=False,
        )

        yield adapter, mock_requests


def _success_response(content="reply"):
    """Create a mock response with a successful chat completion."""
    resp = MagicMock()
    resp.json.return_value = {"choices": [{"message": {"content": content}}]}
    resp.raise_for_status = MagicMock()
    resp.status_code = 200
    return resp


# TestConstructor

class TestConstructor:

    def test_basic_init(self, adapter_and_mocks):
        adapter, _ = adapter_and_mocks
        assert adapter.model == "mistralai/Mistral-7B-Instruct-v0.3"
        assert adapter.base_url == "http://10.0.0.1:8123"

    def test_custom_port(self):
        with patch(f"{MODULE}.requests") as mock_requests:
            mock_requests.exceptions = _real_requests.exceptions
            mock_validate = MagicMock()
            mock_validate.json.return_value = {"supported_models": ["m"]}
            mock_validate.raise_for_status = MagicMock()
            mock_requests.get.return_value = mock_validate

            from fairlib.modules.mal.load_balancer_adapter import LoadBalancerAdapter
            adapter = LoadBalancerAdapter(
                manager_ip="10.0.0.1", model="m", port=9999,
                preload_model=False, verbose=False)
            assert adapter.base_url == "http://10.0.0.1:9999"

    def test_default_gen_kwargs(self, adapter_and_mocks):
        adapter, _ = adapter_and_mocks
        assert "temperature" in adapter.default_gen_kwargs
        assert "max_tokens" in adapter.default_gen_kwargs

    def test_custom_gen_kwargs(self):
        with patch(f"{MODULE}.requests") as mock_requests:
            mock_requests.exceptions = _real_requests.exceptions
            mock_validate = MagicMock()
            mock_validate.json.return_value = {"supported_models": ["m"]}
            mock_validate.raise_for_status = MagicMock()
            mock_requests.get.return_value = mock_validate

            from fairlib.modules.mal.load_balancer_adapter import LoadBalancerAdapter
            adapter = LoadBalancerAdapter(
                manager_ip="10.0.0.1", model="m",
                preload_model=False, verbose=False,
                temperature=0.3, max_tokens=1024)
            assert adapter.default_gen_kwargs["temperature"] == 0.3
            assert adapter.default_gen_kwargs["max_tokens"] == 1024

    def test_validation_fails_unsupported_model(self):
        with patch(f"{MODULE}.requests") as mock_requests:
            mock_requests.exceptions = _real_requests.exceptions
            mock_response = MagicMock()
            mock_response.json.return_value = {"supported_models": ["other-model"]}
            mock_response.raise_for_status = MagicMock()
            mock_requests.get.return_value = mock_response

            from fairlib.modules.mal.load_balancer_adapter import LoadBalancerAdapter
            with pytest.raises(ValueError, match="not in the supported models"):
                LoadBalancerAdapter(
                    manager_ip="10.0.0.1", model="unsupported-model",
                    verbose=False, preload_model=False)

    def test_validation_connection_error(self):
        with patch(f"{MODULE}.requests") as mock_requests:
            mock_requests.exceptions = _real_requests.exceptions
            mock_requests.get.side_effect = _real_requests.exceptions.ConnectionError("refused")

            from fairlib.modules.mal.load_balancer_adapter import LoadBalancerAdapter
            with pytest.raises(ConnectionError):
                LoadBalancerAdapter(
                    manager_ip="10.0.0.1", model="any",
                    verbose=False, preload_model=False)


# TestMessagesToApiFormat

class TestMessagesToApiFormat:

    def test_basic_messages(self, adapter_and_mocks):
        adapter, _ = adapter_and_mocks
        msgs = [
            Message(role="system", content="Be helpful"),
            Message(role="user", content="Hello"),
        ]
        result = adapter._messages_to_api_format(msgs)
        assert result == [
            {"role": "system", "content": "Be helpful"},
            {"role": "user", "content": "Hello"},
        ]

    def test_tool_call_id_included(self, adapter_and_mocks):
        adapter, _ = adapter_and_mocks
        msgs = [Message(role="tool", content="result", tool_call_id="c1", name="fn")]
        result = adapter._messages_to_api_format(msgs)
        assert result[0]["tool_call_id"] == "c1"
        assert result[0]["name"] == "fn"

    def test_optional_fields_excluded_when_none(self, adapter_and_mocks):
        adapter, _ = adapter_and_mocks
        msgs = [Message(role="user", content="hi")]
        result = adapter._messages_to_api_format(msgs)
        assert "tool_call_id" not in result[0]
        assert "name" not in result[0]


# TestInvoke

class TestInvoke:

    def test_invoke_returns_message(self, adapter_and_mocks):
        adapter, mock_requests = adapter_and_mocks
        mock_requests.post.return_value = _success_response("Hello from LB!")

        result = adapter.invoke([Message(role="user", content="hi")])
        assert isinstance(result, Message)
        assert result.role == "assistant"
        assert result.content == "Hello from LB!"

    def test_invoke_empty_choices_raises(self, adapter_and_mocks):
        adapter, mock_requests = adapter_and_mocks
        resp = MagicMock()
        resp.json.return_value = {"choices": []}
        resp.raise_for_status = MagicMock()
        resp.status_code = 200
        mock_requests.post.return_value = resp

        with pytest.raises(AdapterError) as ei:
            adapter.invoke([Message(role="user", content="hi")])
        assert ei.value.provider == "load_balancer"
        assert "no choices" in str(ei.value).lower()

    def test_invoke_posts_correct_payload(self, adapter_and_mocks):
        adapter, mock_requests = adapter_and_mocks
        mock_requests.post.return_value = _success_response()

        adapter.invoke([
            Message(role="system", content="sys"),
            Message(role="user", content="hi"),
        ])
        call_args = mock_requests.post.call_args
        payload = call_args.kwargs["json"]
        assert payload["model"] == "mistralai/Mistral-7B-Instruct-v0.3"
        assert len(payload["messages"]) == 2


# TestAInvoke

class TestAInvoke:

    def test_ainvoke_returns_message(self, adapter_and_mocks):
        adapter, mock_requests = adapter_and_mocks
        mock_requests.post.return_value = _success_response("async reply")

        result = asyncio.run(adapter.ainvoke([Message(role="user", content="hi")]))
        assert result.content == "async reply"


# TestStream

class TestStream:

    def test_stream_yields_single_message(self, adapter_and_mocks):
        """LoadBalancer doesn't support true streaming — returns full response."""
        adapter, mock_requests = adapter_and_mocks
        mock_requests.post.return_value = _success_response("full response")

        results = list(adapter.stream([Message(role="user", content="hi")]))
        assert len(results) == 1
        assert results[0].content == "full response"


# TestAStream

class TestAStream:

    def test_astream_yields_single_message(self, adapter_and_mocks):
        adapter, mock_requests = adapter_and_mocks
        mock_requests.post.return_value = _success_response("async stream")

        async def _run():
            results = []
            async for msg in adapter.astream([Message(role="user", content="hi")]):
                results.append(msg)
            return results

        results = asyncio.run(_run())
        assert len(results) == 1
        assert results[0].content == "async stream"


# TestGetModelCapabilities

class TestGetModelCapabilities:

    def test_capabilities(self, adapter_and_mocks):
        adapter, _ = adapter_and_mocks
        caps = adapter.get_model_capabilities()
        assert caps["function_calling"] is False
        assert caps["streaming"] is False
        assert caps["distributed"] is True
        assert caps["model"] == "mistralai/Mistral-7B-Instruct-v0.3"


# TestRetryLogic

class TestRetryLogic:

    def test_timeout_retries_once(self, adapter_and_mocks):
        adapter, mock_requests = adapter_and_mocks
        mock_requests.post.side_effect = [
            _real_requests.exceptions.Timeout("timed out"),
            _success_response("retry ok"),
        ]

        result = adapter.invoke([Message(role="user", content="hi")])
        assert result.content == "retry ok"
        assert mock_requests.post.call_count == 2

    def test_503_retries_once(self, adapter_and_mocks):
        adapter, mock_requests = adapter_and_mocks
        mock_503 = MagicMock()
        mock_503.status_code = 503
        mock_503.json.return_value = {"error": "queue full"}

        mock_requests.post.side_effect = [mock_503, _success_response("after retry")]

        result = adapter.invoke([Message(role="user", content="hi")])
        assert result.content == "after retry"


# TestHealthAndModels

class TestHealthAndModels:

    def test_get_health_status(self, adapter_and_mocks):
        adapter, mock_requests = adapter_and_mocks
        mock_response = MagicMock()
        mock_response.json.return_value = {"status": "healthy", "nodes": 3}
        mock_response.raise_for_status = MagicMock()
        mock_requests.get.return_value = mock_response

        result = adapter.get_health_status()
        assert result["status"] == "healthy"

    def test_get_supported_models(self, adapter_and_mocks):
        adapter, mock_requests = adapter_and_mocks
        mock_response = MagicMock()
        mock_response.json.return_value = {"supported_models": ["model-a", "model-b"]}
        mock_response.raise_for_status = MagicMock()
        mock_requests.get.return_value = mock_response

        result = adapter.get_supported_models()
        assert result == ["model-a", "model-b"]
