# test_openai_adapter.py

"""
Unit tests for the OpenAI adapter.
All tests mock the OpenAI client — no real API calls needed.
"""

import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch

from fairlib.core.errors import AdapterError
from fairlib.core.message import Message


# ---------------------------------------------------------------------------
# Helper to build a mock adapter
# ---------------------------------------------------------------------------

def _make_adapter(api_key="test-key", model_name="gpt-4o"):
    """Construct an OpenAIAdapter with mocked OpenAI clients."""
    with patch("fairlib.modules.mal.openai_adapter.OPENAI_INSTALLED", True), \
         patch("fairlib.modules.mal.openai_adapter.OpenAI") as mock_sync_cls, \
         patch("fairlib.modules.mal.openai_adapter.AsyncOpenAI") as mock_async_cls:

        mock_sync_client = MagicMock()
        mock_async_client = MagicMock()
        mock_sync_cls.return_value = mock_sync_client
        mock_async_cls.return_value = mock_async_client

        from fairlib.modules.mal.openai_adapter import OpenAIAdapter
        adapter = OpenAIAdapter(api_key=api_key, model_name=model_name)

        return adapter, {
            "sync_client": mock_sync_client,
            "async_client": mock_async_client,
        }


# TestConstructor

class TestConstructor:

    def test_import_error_without_openai(self):
        with patch("fairlib.modules.mal.openai_adapter.OPENAI_INSTALLED", False):
            from fairlib.modules.mal.openai_adapter import OpenAIAdapter
            with pytest.raises(ImportError, match="openai"):
                OpenAIAdapter(api_key="key")

    def test_missing_api_key_raises(self):
        with patch("fairlib.modules.mal.openai_adapter.OPENAI_INSTALLED", True), \
             patch("fairlib.modules.mal.openai_adapter.OpenAI"), \
             patch("fairlib.modules.mal.openai_adapter.AsyncOpenAI"), \
             patch.dict("os.environ", {}, clear=True):
            from fairlib.modules.mal.openai_adapter import OpenAIAdapter
            with pytest.raises(ValueError, match="API key"):
                OpenAIAdapter(api_key=None)

    def test_api_key_from_env(self):
        with patch.dict("os.environ", {"OPENAI_API_KEY": "env-key"}, clear=False), \
             patch("fairlib.modules.mal.openai_adapter.OPENAI_INSTALLED", True), \
             patch("fairlib.modules.mal.openai_adapter.OpenAI") as mock_sync, \
             patch("fairlib.modules.mal.openai_adapter.AsyncOpenAI"):
            from fairlib.modules.mal.openai_adapter import OpenAIAdapter
            adapter = OpenAIAdapter()
            mock_sync.assert_called_once_with(api_key="env-key")

    def test_model_name_stored(self):
        adapter, _ = _make_adapter(model_name="gpt-3.5-turbo")
        assert adapter.model_name == "gpt-3.5-turbo"


# TestPrepareMessages

class TestPrepareMessages:

    def test_basic_messages(self):
        adapter, _ = _make_adapter()
        msgs = [
            Message(role="system", content="You are helpful."),
            Message(role="user", content="Hello"),
        ]
        result = adapter._prepare_messages(msgs)
        assert result == [
            {"role": "system", "content": "You are helpful."},
            {"role": "user", "content": "Hello"},
        ]

    def test_none_content_becomes_empty_string(self):
        adapter, _ = _make_adapter()
        result = adapter._prepare_messages([Message(role="assistant", content=None)])
        assert result[0]["content"] == ""

    def test_optional_fields_excluded_when_none(self):
        adapter, _ = _make_adapter()
        result = adapter._prepare_messages([Message(role="user", content="hi")])
        d = result[0]
        assert "name" not in d
        assert "tool_calls" not in d
        assert "tool_call_id" not in d
        assert "metadata" not in d

    def test_tool_fields_included(self):
        adapter, _ = _make_adapter()
        result = adapter._prepare_messages([
            Message(role="assistant", content="",
                    tool_calls=[{"id": "c1", "function": {"name": "f", "arguments": "{}"}}]),
            Message(role="tool", content="result", tool_call_id="c1", name="f"),
        ])
        assert result[0]["tool_calls"][0]["id"] == "c1"
        assert result[1]["tool_call_id"] == "c1"
        assert result[1]["name"] == "f"


# TestInvoke

class TestInvoke:

    def test_invoke_returns_message(self):
        adapter, mocks = _make_adapter()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "Hello there!"
        mock_response.choices[0].message.tool_calls = None
        mocks["sync_client"].chat.completions.create.return_value = mock_response

        result = adapter.invoke([Message(role="user", content="hi")])
        assert isinstance(result, Message)
        assert result.role == "assistant"
        assert result.content == "Hello there!"

    def test_invoke_passes_model_name(self):
        adapter, mocks = _make_adapter(model_name="gpt-3.5-turbo")
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "reply"
        mock_response.choices[0].message.tool_calls = None
        mocks["sync_client"].chat.completions.create.return_value = mock_response

        adapter.invoke([Message(role="user", content="hi")])
        call_kwargs = mocks["sync_client"].chat.completions.create.call_args
        assert call_kwargs.kwargs["model"] == "gpt-3.5-turbo"

    def test_invoke_on_error_raises_adapter_error(self):
        adapter, mocks = _make_adapter()
        mocks["sync_client"].chat.completions.create.side_effect = Exception("API down")

        with pytest.raises(AdapterError) as ei:
            adapter.invoke([Message(role="user", content="hi")])
        assert ei.value.provider == "openai"
        assert "API down" in str(ei.value)

    def test_invoke_forwards_kwargs(self):
        adapter, mocks = _make_adapter()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "reply"
        mock_response.choices[0].message.tool_calls = None
        mocks["sync_client"].chat.completions.create.return_value = mock_response

        adapter.invoke([Message(role="user", content="hi")], temperature=0.2, max_tokens=100)
        call_kwargs = mocks["sync_client"].chat.completions.create.call_args.kwargs
        assert call_kwargs["temperature"] == 0.2
        assert call_kwargs["max_tokens"] == 100

    def test_invoke_preserves_tool_calls(self):
        adapter, mocks = _make_adapter()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = None
        mock_response.choices[0].message.tool_calls = [{"id": "c1"}]
        mocks["sync_client"].chat.completions.create.return_value = mock_response

        result = adapter.invoke([Message(role="user", content="hi")])
        assert result.tool_calls == [{"id": "c1"}]


# TestAInvoke

class TestAInvoke:

    def test_ainvoke_returns_message(self):
        adapter, mocks = _make_adapter()
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "async reply"
        mock_response.choices[0].message.tool_calls = None
        mocks["async_client"].chat.completions.create = AsyncMock(return_value=mock_response)

        result = asyncio.run(adapter.ainvoke([Message(role="user", content="hi")]))
        assert result.content == "async reply"

    def test_ainvoke_on_error_raises_adapter_error(self):
        adapter, mocks = _make_adapter()
        mocks["async_client"].chat.completions.create = AsyncMock(
            side_effect=Exception("async fail"))

        with pytest.raises(AdapterError) as ei:
            asyncio.run(adapter.ainvoke([Message(role="user", content="hi")]))
        assert ei.value.provider == "openai"
        assert "async fail" in str(ei.value)


# TestStream

class TestStream:

    def test_stream_yields_chunks(self):
        adapter, mocks = _make_adapter()
        chunk1 = MagicMock()
        chunk1.choices = [MagicMock()]
        chunk1.choices[0].delta.content = "Hello"
        chunk2 = MagicMock()
        chunk2.choices = [MagicMock()]
        chunk2.choices[0].delta.content = " world"
        chunk3 = MagicMock()
        chunk3.choices = [MagicMock()]
        chunk3.choices[0].delta.content = None
        chunk3.choices[0].delta = MagicMock(content=None)

        mocks["sync_client"].chat.completions.create.return_value = [chunk1, chunk2, chunk3]

        results = list(adapter.stream([Message(role="user", content="hi")]))
        assert len(results) == 2
        assert results[0].content == "Hello"
        assert results[1].content == " world"

    def test_stream_passes_stream_true(self):
        adapter, mocks = _make_adapter()
        mocks["sync_client"].chat.completions.create.return_value = []

        list(adapter.stream([Message(role="user", content="hi")]))
        call_kwargs = mocks["sync_client"].chat.completions.create.call_args.kwargs
        assert call_kwargs["stream"] is True

    def test_stream_on_error_yields_error(self):
        adapter, mocks = _make_adapter()
        mocks["sync_client"].chat.completions.create.side_effect = Exception("stream fail")

        results = list(adapter.stream([Message(role="user", content="hi")]))
        assert len(results) == 1
        assert "Error" in results[0].content


# TestAStream

class TestAStream:

    def test_astream_yields_chunks(self):
        adapter, mocks = _make_adapter()
        chunk1 = MagicMock()
        chunk1.choices = [MagicMock()]
        chunk1.choices[0].delta.content = "async "
        chunk2 = MagicMock()
        chunk2.choices = [MagicMock()]
        chunk2.choices[0].delta.content = "stream"

        async def mock_stream():
            for c in [chunk1, chunk2]:
                yield c

        mocks["async_client"].chat.completions.create = AsyncMock(return_value=mock_stream())

        results = asyncio.run(_collect_astream(adapter, [Message(role="user", content="hi")]))
        assert len(results) == 2
        assert results[0].content == "async "
        assert results[1].content == "stream"


async def _collect_astream(adapter, messages, **kwargs):
    results = []
    async for msg in adapter.astream(messages, **kwargs):
        results.append(msg)
    return results


# TestGetModelCapabilities

class TestGetModelCapabilities:

    def test_capabilities(self):
        adapter, _ = _make_adapter()
        caps = adapter.get_model_capabilities()
        assert caps["supports_streaming"] is True
        assert caps["supports_async"] is True
        assert caps["supports_tool_calling"] is True
        assert "max_context_window" in caps
