# test_huggingface_adapter.py

"""
Unit tests for the HuggingFace adapter with v4/v5 dual compatibility.
All tests mock torch, transformers, model, and tokenizer — no GPU or downloads needed.
"""

import pytest
import asyncio
from unittest.mock import MagicMock, patch, PropertyMock
from typing import Iterator

from fairlib.core.errors import AdapterError
from fairlib.core.message import Message


# ---------------------------------------------------------------------------
# Helpers to build a mock adapter without hitting real model loading
# ---------------------------------------------------------------------------

def _make_adapter(overrides=None, **init_kwargs):
    """
    Construct a HuggingFaceAdapter with all heavy dependencies mocked out.
    The overrides argument is an optional dict of attribute patches applied
    after __init__.
    """
    with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
         patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
         patch("fairlib.modules.mal.huggingface_adapter.pipeline") as mock_pipeline, \
         patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
         patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
         patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
         patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):

        mock_torch.float16 = "float16"

        mock_tokenizer = MagicMock()
        mock_tokenizer.apply_chat_template.return_value = "<formatted_prompt>"
        mock_tok_cls.from_pretrained.return_value = mock_tokenizer

        mock_model = MagicMock()
        mock_model.device = "cpu"
        mock_model_cls.from_pretrained.return_value = mock_model

        mock_gen = MagicMock()
        mock_gen.return_value = [{"generated_text": "Hello from the model"}]
        mock_pipeline.return_value = mock_gen

        defaults = {"verbose": False}
        defaults.update(init_kwargs)

        from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
        adapter = HuggingFaceAdapter(**defaults)

        if overrides:
            for k, v in overrides.items():
                setattr(adapter, k, v)

        return adapter, {
            "tokenizer_cls": mock_tok_cls,
            "model_cls": mock_model_cls,
            "pipeline": mock_pipeline,
            "generator": mock_gen,
            "tokenizer": mock_tokenizer,
            "model": mock_model,
            "torch": mock_torch,
        }


# TestVersionDetection

class TestVersionDetection:
    """Verify TRANSFORMERS_V5 flag behavior."""

    def test_v4_detected(self):
        with patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.transformers") as mock_tf:
            mock_tf.__version__ = "4.52.4"
            from packaging.version import parse as parse_version
            result = parse_version(mock_tf.__version__) >= parse_version("5.0.0")
            assert result is False

    def test_v5_detected(self):
        with patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.transformers") as mock_tf:
            mock_tf.__version__ = "5.0.0"
            from packaging.version import parse as parse_version
            result = parse_version(mock_tf.__version__) >= parse_version("5.0.0")
            assert result is True

    def test_v5_flag_is_bool(self):
        from fairlib.modules.mal.huggingface_adapter import TRANSFORMERS_V5
        assert isinstance(TRANSFORMERS_V5, bool)


# TestPrepareMessages

class TestPrepareMessages:
    """Clean dict output, None fields excluded, tool fields included when present."""

    def test_basic_message(self):
        adapter, _ = _make_adapter()
        msgs = [Message(role="user", content="hi")]
        result = adapter._prepare_messages(msgs)
        assert result == [{"role": "user", "content": "hi"}]

    def test_none_fields_excluded(self):
        adapter, _ = _make_adapter()
        msgs = [Message(role="user", content="hi", name=None, tool_calls=None, tool_call_id=None)]
        result = adapter._prepare_messages(msgs)
        d = result[0]
        assert "name" not in d
        assert "tool_calls" not in d
        assert "tool_call_id" not in d
        assert "metadata" not in d

    def test_tool_fields_included(self):
        adapter, _ = _make_adapter()
        msgs = [Message(
            role="assistant",
            content="calling tool",
            tool_calls=[{"id": "1", "function": {"name": "search", "arguments": "{}"}}],
            tool_call_id="tc-1",
            name="search"
        )]
        result = adapter._prepare_messages(msgs)
        d = result[0]
        assert d["name"] == "search"
        assert d["tool_calls"] == [{"id": "1", "function": {"name": "search", "arguments": "{}"}}]
        assert d["tool_call_id"] == "tc-1"

    def test_none_content_becomes_empty_string(self):
        adapter, _ = _make_adapter()
        msg = Message(role="assistant", content=None)
        result = adapter._prepare_messages([msg])
        assert result[0]["content"] == ""

    def test_multiple_messages(self):
        adapter, _ = _make_adapter()
        msgs = [
            Message(role="system", content="You are helpful."),
            Message(role="user", content="Hello"),
            Message(role="assistant", content="Hi there!"),
        ]
        result = adapter._prepare_messages(msgs)
        assert len(result) == 3
        assert [m["role"] for m in result] == ["system", "user", "assistant"]


# TestFormatPrompt

class TestFormatPrompt:
    """String return (v4), BatchEncoding return (v5), fallback on error."""

    def test_string_return_v4(self):
        adapter, mocks = _make_adapter()
        mocks["tokenizer"].apply_chat_template.return_value = "<s>User: hi</s>"
        msgs = [Message(role="user", content="hi")]
        result = adapter._format_prompt(msgs)
        assert result == "<s>User: hi</s>"

    def test_batch_encoding_return_v5(self):
        adapter, mocks = _make_adapter()
        # Simulate a BatchEncoding-like object
        batch_enc = MagicMock()
        batch_enc.input_ids = [[1, 2, 3]]
        mocks["tokenizer"].apply_chat_template.return_value = batch_enc
        mocks["tokenizer"].decode.return_value = "<decoded_prompt>"
        msgs = [Message(role="user", content="hi")]
        result = adapter._format_prompt(msgs)
        assert result == "<decoded_prompt>"
        mocks["tokenizer"].decode.assert_called_once_with([1, 2, 3], skip_special_tokens=False)

    def test_non_string_non_batch_encoding(self):
        adapter, mocks = _make_adapter()
        mocks["tokenizer"].apply_chat_template.return_value = 12345
        msgs = [Message(role="user", content="hi")]
        result = adapter._format_prompt(msgs)
        assert result == "12345"

    def test_fallback_on_exception(self):
        adapter, mocks = _make_adapter()
        mocks["tokenizer"].apply_chat_template.side_effect = Exception("template error")
        msgs = [
            Message(role="user", content="hello"),
            Message(role="assistant", content="world"),
        ]
        result = adapter._format_prompt(msgs)
        assert "user: hello" in result
        assert "assistant: world" in result

    def test_uses_prepare_messages(self):
        adapter, mocks = _make_adapter()
        msgs = [Message(role="user", content="hi", metadata={"key": "val"})]
        adapter._format_prompt(msgs)
        call_args = mocks["tokenizer"].apply_chat_template.call_args[0][0]
        # Should be clean dict without metadata
        assert "metadata" not in call_args[0]


# TestInvoke

class TestInvoke:
    """return_full_text=False used, correct Message returned."""

    def test_invoke_returns_message(self):
        adapter, mocks = _make_adapter()
        mocks["generator"].return_value = [{"generated_text": "  Sure thing!  "}]
        msgs = [Message(role="user", content="help me")]
        result = adapter.invoke(msgs)
        assert isinstance(result, Message)
        assert result.role == "assistant"
        assert result.content == "Sure thing!"

    def test_invoke_passes_return_full_text_false(self):
        adapter, mocks = _make_adapter()
        mocks["generator"].return_value = [{"generated_text": "reply"}]
        adapter.invoke([Message(role="user", content="hi")])
        _, kwargs = mocks["generator"].call_args
        assert kwargs["return_full_text"] is False

    def test_invoke_merges_kwargs(self):
        adapter, mocks = _make_adapter()
        mocks["generator"].return_value = [{"generated_text": "reply"}]
        adapter.invoke([Message(role="user", content="hi")], max_new_tokens=512, temperature=0.1)
        _, kwargs = mocks["generator"].call_args
        # On v5, generation params are wrapped in a GenerationConfig object
        # rather than passed as loose kwargs to the pipeline.
        from fairlib.modules.mal.huggingface_adapter import TRANSFORMERS_V5
        if TRANSFORMERS_V5:
            gen_config = kwargs["generation_config"]
            assert gen_config.max_new_tokens == 512
            assert gen_config.temperature == 0.1
        else:
            assert kwargs["max_new_tokens"] == 512
            assert kwargs["temperature"] == 0.1

    def test_ainvoke(self):
        adapter, mocks = _make_adapter()
        mocks["generator"].return_value = [{"generated_text": "async reply"}]
        result = asyncio.run(adapter.ainvoke([Message(role="user", content="hi")]))
        assert result.content == "async reply"


# TestModelRegistry

class TestModelRegistry:
    """Alias resolution, passthrough for unknown names."""

    def test_known_alias_resolves(self):
        from fairlib.modules.mal.huggingface_adapter import MODEL_REGISTRY
        assert MODEL_REGISTRY["mistral-7b"] == "mistralai/Mistral-7B-Instruct-v0.1"

    def test_unknown_name_passthrough(self):
        from fairlib.modules.mal.huggingface_adapter import MODEL_REGISTRY
        unknown = "my-org/my-custom-model"
        assert MODEL_REGISTRY.get(unknown, unknown) == unknown

    def test_new_qwen_entries(self):
        from fairlib.modules.mal.huggingface_adapter import MODEL_REGISTRY
        assert "qwen25-7b" in MODEL_REGISTRY
        assert "qwen25-14b" in MODEL_REGISTRY
        assert "qwen25-coder-7b" in MODEL_REGISTRY

    def test_new_gemma_entries(self):
        from fairlib.modules.mal.huggingface_adapter import MODEL_REGISTRY
        assert "gemma2-9b" in MODEL_REGISTRY
        assert "gemma3-12b" in MODEL_REGISTRY

    def test_new_phi4_entry(self):
        from fairlib.modules.mal.huggingface_adapter import MODEL_REGISTRY
        assert "phi4" in MODEL_REGISTRY
        assert MODEL_REGISTRY["phi4"] == "microsoft/phi-4"

    def test_mistral_nemo_entry(self):
        from fairlib.modules.mal.huggingface_adapter import MODEL_REGISTRY
        assert "mistral-nemo" in MODEL_REGISTRY


# TestConstructorValidation

class TestConstructorValidation:
    """ImportError without torch/transformers, env var auth token."""

    def test_import_error_without_torch(self):
        with patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", False), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True):
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(ImportError, match="torch"):
                HuggingFaceAdapter(verbose=False)

    def test_import_error_without_transformers(self):
        with patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", False):
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(ImportError, match="transformers"):
                HuggingFaceAdapter(verbose=False)

    def test_hf_token_env_var(self):
        with patch.dict("os.environ", {"HF_TOKEN": "test-token-123"}, clear=False):
            adapter, _ = _make_adapter(auth_token=None)
            assert adapter.auth_token == "test-token-123"

    def test_legacy_env_var_fallback(self):
        with patch.dict("os.environ", {"HUGGING_FACE_HUB_TOKEN": "legacy-token"}, clear=False), \
             patch.dict("os.environ", {}, clear=False) as env:
            env.pop("HF_TOKEN", None)
            adapter, _ = _make_adapter(auth_token=None)
            assert adapter.auth_token == "legacy-token"

    def test_explicit_token_takes_priority(self):
        with patch.dict("os.environ", {"HF_TOKEN": "env-token"}, clear=False):
            adapter, _ = _make_adapter(auth_token="explicit-token")
            assert adapter.auth_token == "explicit-token"


# TestStreaming

class TestStreaming:
    """NotImplementedError when disabled, stream/astream behavior."""

    def test_stream_raises_when_disabled(self):
        adapter, _ = _make_adapter(stream=False)
        with pytest.raises(NotImplementedError, match="Streaming not enabled"):
            list(adapter.stream([Message(role="user", content="hi")]))

    def test_astream_raises_when_disabled(self):
        adapter, _ = _make_adapter(stream=False)
        with pytest.raises(NotImplementedError, match="Streaming not enabled"):
            asyncio.run(_collect_astream(adapter, [Message(role="user", content="hi")]))

    def test_stream_yields_messages_when_enabled(self):
        adapter, mocks = _make_adapter(stream=True)

        # Mock tokenizer call to return tensor-like input
        mock_inputs = MagicMock()
        mock_inputs.to.return_value = {"input_ids": MagicMock()}
        mocks["tokenizer"].__call__ = MagicMock(return_value=mock_inputs)
        mocks["tokenizer"].return_value = mock_inputs

        # Patch TextIteratorStreamer to yield controlled chunks
        with patch("fairlib.modules.mal.huggingface_adapter.TextIteratorStreamer") as mock_streamer_cls:
            mock_streamer_instance = MagicMock()
            mock_streamer_instance.__iter__ = MagicMock(return_value=iter(["Hello", " world", ""]))
            mock_streamer_cls.return_value = mock_streamer_instance

            with patch("fairlib.modules.mal.huggingface_adapter.Thread") as mock_thread_cls:
                mock_thread = MagicMock()
                mock_thread_cls.return_value = mock_thread

                results = list(adapter.stream([Message(role="user", content="hi")]))

                assert len(results) == 2
                assert results[0].content == "Hello"
                assert results[1].content == " world"
                assert all(m.role == "assistant" for m in results)
                mock_thread.start.assert_called_once()
                mock_thread.join.assert_called_once()

    def test_astream_v4_fallback(self):
        """On v4, astream falls back to ainvoke."""
        with patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_V5", False):
            adapter, mocks = _make_adapter(stream=True)
            mocks["generator"].return_value = [{"generated_text": "fallback reply"}]
            results = asyncio.run(_collect_astream(adapter, [Message(role="user", content="hi")]))
            assert len(results) == 1
            assert results[0].content == "fallback reply"


async def _collect_astream(adapter, messages, **kwargs):
    """Helper to collect async generator results."""
    results = []
    async for msg in adapter.astream(messages, **kwargs):
        results.append(msg)
    return results


# TestAttentionInterface

class TestAttentionInterface:
    """attn_implementation passed on v5, omitted on v4."""

    def test_v5_sets_sdpa_attention(self):
        with patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_V5", True), \
             patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):

            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.return_value = MagicMock()
            mock_model_cls.from_pretrained.return_value = MagicMock()

            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            HuggingFaceAdapter(verbose=False)

            _, kwargs = mock_model_cls.from_pretrained.call_args
            assert kwargs["attn_implementation"] == "sdpa"

    def test_v4_omits_attention(self):
        with patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_V5", False), \
             patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):

            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.return_value = MagicMock()
            mock_model_cls.from_pretrained.return_value = MagicMock()

            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            HuggingFaceAdapter(verbose=False)

            _, kwargs = mock_model_cls.from_pretrained.call_args
            assert "attn_implementation" not in kwargs


# TestGetModelCapabilities

class TestGetModelCapabilities:
    def test_capabilities_no_streaming(self):
        adapter, _ = _make_adapter(stream=False)
        caps = adapter.get_model_capabilities()
        assert caps == {"function_calling": False, "streaming": False, "tool_calling": False}

    def test_capabilities_with_streaming(self):
        adapter, _ = _make_adapter(stream=True)
        caps = adapter.get_model_capabilities()
        assert caps["streaming"] is True

    def test_max_context_window_takes_min_of_tokenizer_and_config(self):
        """When both sources report an int, use the smaller value.

        Regression guard for Qwen-style setups where the tokenizer advertises
        a 128K sliding-window context but the model's actual positional
        embeddings stop at 32K.
        """
        adapter, mocks = _make_adapter()
        mocks["tokenizer"].model_max_length = 131072
        mocks["model"].config.max_position_embeddings = 32768

        caps = adapter.get_model_capabilities()

        assert caps["max_context_window"] == 32768

    def test_max_context_window_tokenizer_only(self):
        """Falls back to tokenizer value when config has no positional cap."""
        adapter, mocks = _make_adapter()
        mocks["tokenizer"].model_max_length = 4096
        mocks["model"].config.max_position_embeddings = None

        caps = adapter.get_model_capabilities()

        assert caps["max_context_window"] == 4096

    def test_max_context_window_config_only(self):
        """Falls back to config value when tokenizer reports sentinel."""
        adapter, mocks = _make_adapter()
        # 1e30-style sentinel HF uses to mean "no bound" — fails < 10_000_000
        mocks["tokenizer"].model_max_length = 1_000_000_000_000_000_019_884_624_838_656
        mocks["model"].config.max_position_embeddings = 8192

        caps = adapter.get_model_capabilities()

        assert caps["max_context_window"] == 8192

    def test_max_context_window_omitted_when_neither_source_valid(self):
        """No key emitted when both sources fail the sanity guard."""
        adapter, mocks = _make_adapter()
        mocks["tokenizer"].model_max_length = 1_000_000_000_000_000_019_884_624_838_656
        mocks["model"].config.max_position_embeddings = None

        caps = adapter.get_model_capabilities()

        assert "max_context_window" not in caps


# TestErrorHandling

class TestErrorHandling:
    """Student-friendly error messages for common failure modes."""

    # --- Tokenizer errors ---

    def test_tokenizer_trust_remote_code(self):
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM"), \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.side_effect = ValueError(
                "Loading this model requires trust_remote_code=True"
            )
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError, match="trust_remote_code"):
                HuggingFaceAdapter(verbose=False)

    def test_tokenizer_gated_repo(self):
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM"), \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.side_effect = OSError(
                "You are trying to access a gated repo."
            )
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError, match="gated model") as exc_info:
                HuggingFaceAdapter(verbose=False)
            assert "accept the license" in str(exc_info.value)
            assert "HF_TOKEN" in str(exc_info.value)

    def test_tokenizer_not_found(self):
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM"), \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.side_effect = OSError(
                "404 Client Error: Not Found"
            )
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError, match="not found") as exc_info:
                HuggingFaceAdapter(model_name="fake-org/nonexistent", verbose=False)
            assert "Double-check the model name" in str(exc_info.value)

    def test_tokenizer_network_error(self):
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM"), \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.side_effect = OSError(
                "Connection error"
            )
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError, match="internet connection"):
                HuggingFaceAdapter(verbose=False)

    # --- Model errors ---

    def test_model_oom(self):
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.return_value = MagicMock()
            mock_model_cls.from_pretrained.side_effect = RuntimeError(
                "CUDA out of memory. Tried to allocate 2.00 GiB"
            )
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError, match="GPU out of memory") as exc_info:
                HuggingFaceAdapter(verbose=False)
            assert "quantized=True" in str(exc_info.value)
            assert "nvidia-smi" in str(exc_info.value)

    def test_model_trust_remote_code(self):
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.return_value = MagicMock()
            mock_model_cls.from_pretrained.side_effect = ValueError(
                "Loading this model requires trust_remote_code=True"
            )
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError, match="trust_remote_code"):
                HuggingFaceAdapter(verbose=False)

    def test_model_gated_repo(self):
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.return_value = MagicMock()
            mock_model_cls.from_pretrained.side_effect = OSError(
                "401 Client Error: gated repo access denied"
            )
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError, match="gated model"):
                HuggingFaceAdapter(verbose=False)

    def test_model_not_found(self):
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.return_value = MagicMock()
            mock_model_cls.from_pretrained.side_effect = OSError(
                "404 Client Error: Not Found"
            )
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError, match="not found") as exc_info:
                HuggingFaceAdapter(verbose=False)
            assert "BERT" in str(exc_info.value) or "causal" in str(exc_info.value)

    def test_model_missing_quant_library(self):
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.return_value = MagicMock()
            mock_model_cls.from_pretrained.side_effect = ImportError(
                "No module named 'auto_gptq'"
            )
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(ImportError, match="pip install") as exc_info:
                HuggingFaceAdapter(verbose=False)
            assert "GPTQ" in str(exc_info.value)

    # --- Pipeline error ---

    def test_pipeline_creation_error(self):
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline") as mock_pipeline, \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.return_value = MagicMock()
            mock_model = MagicMock()
            mock_model_cls.from_pretrained.return_value = mock_model
            mock_pipeline.side_effect = ValueError("Unrecognized model type")

            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError, match="pipeline") as exc_info:
                HuggingFaceAdapter(verbose=False)
            assert "causal" in str(exc_info.value).lower()

    # --- Runtime errors (invoke / ainvoke) raise AdapterError; streams
    # still return error Messages because their contract is different.

    def test_invoke_raises_adapter_error(self):
        adapter, mocks = _make_adapter()
        mocks["generator"].side_effect = RuntimeError("some inference error")
        with pytest.raises(AdapterError) as ei:
            adapter.invoke([Message(role="user", content="hi")])
        assert ei.value.provider == "huggingface"
        assert "some inference error" in str(ei.value)

    def test_invoke_oom_raises_with_helpful_message(self):
        adapter, mocks = _make_adapter()
        mocks["generator"].side_effect = RuntimeError("CUDA out of memory. Tried to allocate 512 MiB")
        with pytest.raises(AdapterError) as ei:
            adapter.invoke([Message(role="user", content="hi")])
        assert ei.value.provider == "huggingface"
        assert "GPU out of memory" in str(ei.value)
        assert "max_new_tokens" in str(ei.value)

    def test_stream_returns_error_message(self):
        adapter, mocks = _make_adapter(stream=True)
        # Make the tokenizer call raise during stream
        mocks["tokenizer"].side_effect = RuntimeError("tokenizer crashed")
        results = list(adapter.stream([Message(role="user", content="hi")]))
        assert len(results) == 1
        assert "Error:" in results[0].content

    def test_stream_disabled_still_raises(self):
        """NotImplementedError for disabled streaming must NOT be caught."""
        adapter, _ = _make_adapter(stream=False)
        with pytest.raises(NotImplementedError, match="Streaming not enabled"):
            list(adapter.stream([Message(role="user", content="hi")]))

    def test_astream_disabled_still_raises(self):
        """NotImplementedError for disabled streaming must NOT be caught."""
        adapter, _ = _make_adapter(stream=False)
        with pytest.raises(NotImplementedError, match="Streaming not enabled"):
            asyncio.run(_collect_astream(adapter, [Message(role="user", content="hi")]))

    # --- Verbose printing for constructor errors ---

    def test_verbose_prints_error_on_not_found(self, capsys):
        """When verbose=True (default), constructor errors are printed before raising."""
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM"), \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.side_effect = OSError(
                "404 Client Error: Not Found"
            )
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError):
                HuggingFaceAdapter(model_name="fake/model", verbose=True)
            captured = capsys.readouterr()
            assert "[HuggingFaceAdapter] ERROR" in captured.out
            assert "not found" in captured.out.lower()
            assert "Double-check the model name" in captured.out

    def test_verbose_false_suppresses_error_print(self, capsys):
        """When verbose=False, constructor errors are NOT printed (only raised)."""
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM"), \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.side_effect = OSError(
                "404 Client Error: Not Found"
            )
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError):
                HuggingFaceAdapter(model_name="fake/model", verbose=False)
            captured = capsys.readouterr()
            assert "[HuggingFaceAdapter] ERROR" not in captured.out

    # --- Exception chaining ---

    def test_exception_chaining_preserved(self):
        """All _raise_with_print errors should chain the original exception via __cause__."""
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM"), \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            original = OSError("404 Client Error: Not Found")
            mock_tok_cls.from_pretrained.side_effect = original
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError) as exc_info:
                HuggingFaceAdapter(verbose=False)
            assert exc_info.value.__cause__ is original

    # --- Model network error ---

    def test_model_network_error(self):
        """Model download failure with generic OSError gets network-related message."""
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.return_value = MagicMock()
            mock_model_cls.from_pretrained.side_effect = OSError("Connection error")
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError, match="internet connection"):
                HuggingFaceAdapter(verbose=False)

    # --- Generic/unexpected exception fallbacks ---

    def test_tokenizer_unexpected_error(self):
        """Generic exceptions during tokenizer load get a clear message."""
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM"), \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.side_effect = TypeError("unexpected kwarg")
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError, match="Unexpected error loading tokenizer"):
                HuggingFaceAdapter(verbose=False)

    def test_model_unexpected_error(self):
        """Generic exceptions during model load get a clear message."""
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.return_value = MagicMock()
            mock_model_cls.from_pretrained.side_effect = TypeError("weird model error")
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError, match="Unexpected error loading model"):
                HuggingFaceAdapter(verbose=False)

    # --- ainvoke error handling ---

    def test_ainvoke_raises_adapter_error(self):
        """ainvoke should propagate AdapterError raised by invoke."""
        adapter, mocks = _make_adapter()
        mocks["generator"].side_effect = RuntimeError("ainvoke failure")
        with pytest.raises(AdapterError) as ei:
            asyncio.run(adapter.ainvoke([Message(role="user", content="hi")]))
        assert ei.value.provider == "huggingface"
        assert "ainvoke failure" in str(ei.value)

    # --- Stream OOM ---

    def test_stream_oom_returns_helpful_message(self):
        """Stream OOM should return a Message with GPU-specific guidance."""
        adapter, mocks = _make_adapter(stream=True)
        mocks["tokenizer"].side_effect = RuntimeError(
            "CUDA out of memory. Tried to allocate 512 MiB"
        )
        results = list(adapter.stream([Message(role="user", content="hi")]))
        assert len(results) == 1
        assert "GPU out of memory" in results[0].content
        assert "max_new_tokens" in results[0].content

    # --- Verbose printing for different error types ---

    def test_verbose_prints_oom_error(self, capsys):
        """Verbose mode prints OOM error before raising."""
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.return_value = MagicMock()
            mock_model_cls.from_pretrained.side_effect = RuntimeError(
                "CUDA out of memory. Tried to allocate 2.00 GiB"
            )
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError):
                HuggingFaceAdapter(verbose=True)
            captured = capsys.readouterr()
            assert "[HuggingFaceAdapter] ERROR" in captured.out
            assert "GPU out of memory" in captured.out

    def test_verbose_prints_gated_repo_error(self, capsys):
        """Verbose mode prints gated repo error with fix instructions."""
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM"), \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.side_effect = OSError(
                "You are trying to access a gated repo."
            )
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(RuntimeError):
                HuggingFaceAdapter(verbose=True)
            captured = capsys.readouterr()
            assert "[HuggingFaceAdapter] ERROR" in captured.out
            assert "gated model" in captured.out
            assert "HF_TOKEN" in captured.out

    def test_verbose_prints_quant_library_error(self, capsys):
        """Verbose mode prints missing quantization library with pip install hints."""
        with patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.return_value = MagicMock()
            mock_model_cls.from_pretrained.side_effect = ImportError(
                "No module named 'auto_gptq'"
            )
            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            with pytest.raises(ImportError):
                HuggingFaceAdapter(verbose=True)
            captured = capsys.readouterr()
            assert "[HuggingFaceAdapter] ERROR" in captured.out
            assert "pip install" in captured.out


# TestReconcileModelDtypes

class TestReconcileModelDtypes:
    """Verify FP8 parameter detection and auto-casting."""

    def test_no_fp8_params_noop(self):
        """Model with no FP8 parameters should be untouched."""
        adapter, mocks = _make_adapter()
        import torch
        param1 = MagicMock()
        param1.dtype = torch.bfloat16
        param1.data = MagicMock()
        param2 = MagicMock()
        param2.dtype = torch.bfloat16
        param2.data = MagicMock()
        adapter.model.named_parameters.return_value = [
            ("layer1.weight", param1),
            ("layer2.weight", param2),
        ]
        adapter.model.parameters.return_value = [param1, param2]
        adapter._reconcile_model_dtypes()
        param1.data.to.assert_not_called()
        param2.data.to.assert_not_called()

    def test_fp8_params_cast_to_dominant_dtype(self):
        """FP8 parameters should be cast to the most common non-FP8 dtype."""
        adapter, mocks = _make_adapter()
        import torch

        bf16_param1 = MagicMock()
        bf16_param1.dtype = torch.bfloat16
        bf16_param2 = MagicMock()
        bf16_param2.dtype = torch.bfloat16

        fp8_param = MagicMock()
        fp8_param.dtype = MagicMock()
        fp8_param.dtype.__str__ = lambda self: "torch.float8_e4m3fn"
        fp8_param.data = MagicMock()
        fp8_param.data.to.return_value = MagicMock()

        adapter.model.named_parameters.return_value = [
            ("layer1.weight", bf16_param1),
            ("layer2.weight", bf16_param2),
            ("expert.weight", fp8_param),
        ]
        adapter.model.parameters.return_value = [bf16_param1, bf16_param2, fp8_param]

        original_data = fp8_param.data  # capture before reassignment
        adapter._reconcile_model_dtypes()
        original_data.to.assert_called_once_with(dtype=torch.bfloat16)

    def test_fp8_params_verbose_prints_message(self, capsys):
        """When verbose=True, FP8 casting should print an informational message."""
        adapter, mocks = _make_adapter(verbose=True)
        import torch

        bf16_param = MagicMock()
        bf16_param.dtype = torch.bfloat16

        fp8_param = MagicMock()
        fp8_param.dtype = MagicMock()
        fp8_param.dtype.__str__ = lambda self: "torch.float8_e4m3fn"
        fp8_param.data = MagicMock()
        fp8_param.data.to.return_value = MagicMock()

        adapter.model.named_parameters.return_value = [
            ("layer.weight", bf16_param),
            ("expert.weight", fp8_param),
        ]
        adapter.model.parameters.return_value = [bf16_param, fp8_param]

        adapter._reconcile_model_dtypes()
        captured = capsys.readouterr()
        assert "FP8" in captured.out
        assert "1" in captured.out

    def test_all_fp8_falls_back_to_bfloat16(self):
        """If ALL params are FP8 (no non-FP8 majority), fallback to bfloat16."""
        adapter, mocks = _make_adapter()
        import torch

        fp8_param1 = MagicMock()
        fp8_param1.dtype = MagicMock()
        fp8_param1.dtype.__str__ = lambda self: "torch.float8_e5m2"
        fp8_param1.data = MagicMock()
        fp8_param1.data.to.return_value = MagicMock()

        fp8_param2 = MagicMock()
        fp8_param2.dtype = MagicMock()
        fp8_param2.dtype.__str__ = lambda self: "torch.float8_e4m3fn"
        fp8_param2.data = MagicMock()
        fp8_param2.data.to.return_value = MagicMock()

        adapter.model.named_parameters.return_value = [
            ("a.weight", fp8_param1),
            ("b.weight", fp8_param2),
        ]
        adapter.model.parameters.return_value = [fp8_param1, fp8_param2]

        original_data1 = fp8_param1.data  # capture before reassignment
        original_data2 = fp8_param2.data
        adapter._reconcile_model_dtypes()
        original_data1.to.assert_called_once_with(dtype=torch.bfloat16)
        original_data2.to.assert_called_once_with(dtype=torch.bfloat16)


# TestIsOomError

class TestIsOomError:
    """Verify OOM detection logic."""

    def test_runtime_error_with_cuda_oom_text(self):
        adapter, _ = _make_adapter()
        err = RuntimeError("CUDA out of memory. Tried to allocate 2.00 GiB")
        assert adapter._is_oom_error(err) is True

    def test_runtime_error_without_oom_text(self):
        adapter, _ = _make_adapter()
        err = RuntimeError("some other runtime error")
        assert adapter._is_oom_error(err) is False

    def test_non_runtime_error(self):
        adapter, _ = _make_adapter()
        err = ValueError("not an OOM")
        assert adapter._is_oom_error(err) is False

    def test_case_insensitive_match(self):
        adapter, _ = _make_adapter()
        err = RuntimeError("cuda OUT OF MEMORY error occurred")
        assert adapter._is_oom_error(err) is True


# TestDtypeDefaults

class TestDtypeDefaults:
    """Verify the dtype='auto' default and quantization coercion."""

    def test_default_dtype_is_auto(self):
        """When no dtype is passed, model loads with dtype='auto'."""
        with patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_V5", False), \
             patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig"):
            mock_torch.float16 = "float16"
            mock_tok_cls.from_pretrained.return_value = MagicMock()
            mock_model_cls.from_pretrained.return_value = MagicMock()

            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            HuggingFaceAdapter(verbose=False)

            _, kwargs = mock_model_cls.from_pretrained.call_args
            assert kwargs["torch_dtype"] == "auto"

    def test_quantized_coerces_auto_to_float16(self):
        """When quantized=True and dtype is 'auto', compute_dtype should be torch.float16."""
        with patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_V5", False), \
             patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig") as mock_bnb:
            import torch as real_torch
            mock_torch.float16 = real_torch.float16
            mock_torch.dtype = real_torch.dtype
            mock_tok_cls.from_pretrained.return_value = MagicMock()
            mock_model_cls.from_pretrained.return_value = MagicMock()

            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            HuggingFaceAdapter(quantized=True, verbose=False)

            _, bnb_kwargs = mock_bnb.call_args
            assert bnb_kwargs["bnb_4bit_compute_dtype"] == real_torch.float16

    def test_explicit_dtype_passed_to_quantization(self):
        """When an explicit torch.dtype is provided with quantized=True, it should be used."""
        with patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_V5", False), \
             patch("fairlib.modules.mal.huggingface_adapter.AutoTokenizer") as mock_tok_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.AutoModelForCausalLM") as mock_model_cls, \
             patch("fairlib.modules.mal.huggingface_adapter.pipeline"), \
             patch("fairlib.modules.mal.huggingface_adapter.torch") as mock_torch, \
             patch("fairlib.modules.mal.huggingface_adapter.TORCH_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.TRANSFORMERS_INSTALLED", True), \
             patch("fairlib.modules.mal.huggingface_adapter.BitsAndBytesConfig") as mock_bnb:
            import torch as real_torch
            mock_torch.float16 = real_torch.float16
            mock_torch.bfloat16 = real_torch.bfloat16
            mock_torch.dtype = real_torch.dtype
            mock_tok_cls.from_pretrained.return_value = MagicMock()
            mock_model_cls.from_pretrained.return_value = MagicMock()

            from fairlib.modules.mal.huggingface_adapter import HuggingFaceAdapter
            HuggingFaceAdapter(quantized=True, torch_dtype=real_torch.bfloat16, verbose=False)

            _, bnb_kwargs = mock_bnb.call_args
            assert bnb_kwargs["bnb_4bit_compute_dtype"] == real_torch.bfloat16


# TestRaiseWithPrint

class TestRaiseWithPrint:
    """Verify the _raise_with_print helper directly."""

    def test_raises_runtime_error_by_default(self):
        adapter, _ = _make_adapter()
        with pytest.raises(RuntimeError, match="test message"):
            adapter._raise_with_print("test message")

    def test_raises_custom_exception_type(self):
        adapter, _ = _make_adapter()
        with pytest.raises(ImportError, match="missing dep"):
            adapter._raise_with_print("missing dep", exc_type=ImportError)

    def test_chains_cause_exception(self):
        adapter, _ = _make_adapter()
        original = ValueError("original error")
        with pytest.raises(RuntimeError) as exc_info:
            adapter._raise_with_print("wrapper", cause=original)
        assert exc_info.value.__cause__ is original

    def test_verbose_true_prints(self, capsys):
        adapter, _ = _make_adapter(verbose=True)
        with pytest.raises(RuntimeError):
            adapter._raise_with_print("visible error")
        captured = capsys.readouterr()
        assert "[HuggingFaceAdapter] ERROR" in captured.out
        assert "visible error" in captured.out

    def test_verbose_false_suppresses_print(self, capsys):
        adapter, _ = _make_adapter(verbose=False)
        with pytest.raises(RuntimeError):
            adapter._raise_with_print("hidden error")
        captured = capsys.readouterr()
        assert captured.out == ""
