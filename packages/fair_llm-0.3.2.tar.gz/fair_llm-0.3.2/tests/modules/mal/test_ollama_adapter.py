# test_ollama_adapter.py

"""
Unit tests for the Ollama (local_llama) adapter.
All tests mock httpx — no real Ollama server needed.
"""

import pytest
import asyncio
import json
from unittest.mock import MagicMock, AsyncMock, patch

from fairlib.core.errors import AdapterError
from fairlib.core.message import Message


# ---------------------------------------------------------------------------
# Helper to build a mock adapter
# ---------------------------------------------------------------------------

def _make_adapter(model_name="llama3", host="http://localhost:11434"):
    """Construct an OllamaAdapter with a mocked httpx.AsyncClient."""
    with patch("fairlib.modules.mal.local_llama_adapter.HTTPX_INSTALLED", True), \
         patch("fairlib.modules.mal.local_llama_adapter.httpx") as mock_httpx:

        mock_client = MagicMock()
        mock_httpx.AsyncClient.return_value = mock_client

        from fairlib.modules.mal.local_llama_adapter import OllamaAdapter
        adapter = OllamaAdapter(model_name=model_name, host=host)

        return adapter, {
            "httpx": mock_httpx,
            "client": mock_client,
        }


# TestConstructor

class TestConstructor:

    def test_import_error_without_httpx(self):
        with patch("fairlib.modules.mal.local_llama_adapter.HTTPX_INSTALLED", False):
            from fairlib.modules.mal.local_llama_adapter import OllamaAdapter
            with pytest.raises(ImportError, match="httpx"):
                OllamaAdapter()

    def test_model_name_stored(self):
        adapter, _ = _make_adapter(model_name="mistral")
        assert adapter.model_name == "mistral"

    def test_api_url_constructed(self):
        adapter, _ = _make_adapter(host="http://10.0.0.1:11434")
        assert adapter.api_url == "http://10.0.0.1:11434/api/chat"

    def test_trailing_slash_stripped(self):
        adapter, _ = _make_adapter(host="http://localhost:11434/")
        assert adapter.api_url == "http://localhost:11434/api/chat"


# TestPreparePayload

class TestPreparePayload:

    def test_basic_payload(self):
        adapter, _ = _make_adapter()
        msgs = [Message(role="user", content="hello")]
        payload = adapter._prepare_payload(msgs, stream=False)
        assert payload["model"] == "llama3"
        assert payload["stream"] is False
        assert payload["messages"] == [{"role": "user", "content": "hello"}]

    def test_streaming_payload(self):
        adapter, _ = _make_adapter()
        msgs = [Message(role="user", content="hi")]
        payload = adapter._prepare_payload(msgs, stream=True)
        assert payload["stream"] is True

    def test_kwargs_in_options(self):
        adapter, _ = _make_adapter()
        msgs = [Message(role="user", content="hi")]
        payload = adapter._prepare_payload(msgs, stream=False, temperature=0.5)
        assert payload["options"]["temperature"] == 0.5

    def test_multiple_messages(self):
        adapter, _ = _make_adapter()
        msgs = [
            Message(role="system", content="Be helpful"),
            Message(role="user", content="Hello"),
            Message(role="assistant", content="Hi!"),
            Message(role="user", content="Bye"),
        ]
        payload = adapter._prepare_payload(msgs, stream=False)
        assert len(payload["messages"]) == 4
        assert [m["role"] for m in payload["messages"]] == ["system", "user", "assistant", "user"]


# TestAInvoke

class TestAInvoke:

    def test_ainvoke_returns_message(self):
        adapter, mocks = _make_adapter()
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "message": {"role": "assistant", "content": "  Hello there!  "}
        }
        mock_response.raise_for_status = MagicMock()
        mocks["client"].post = AsyncMock(return_value=mock_response)

        result = asyncio.run(adapter.ainvoke([Message(role="user", content="hi")]))
        assert isinstance(result, Message)
        assert result.role == "assistant"
        assert result.content == "Hello there!"

    def test_ainvoke_connection_error_raises_adapter_error(self):
        adapter, mocks = _make_adapter()

        import httpx
        mocks["client"].post = AsyncMock(side_effect=httpx.ConnectError("refused"))

        with pytest.raises(AdapterError) as ei:
            asyncio.run(adapter.ainvoke([Message(role="user", content="hi")]))
        assert ei.value.provider == "ollama"
        assert "Connection" in str(ei.value) or "failed" in str(ei.value)

    def test_ainvoke_posts_to_correct_url(self):
        adapter, mocks = _make_adapter()
        mock_response = MagicMock()
        mock_response.json.return_value = {"message": {"role": "assistant", "content": "ok"}}
        mock_response.raise_for_status = MagicMock()
        mocks["client"].post = AsyncMock(return_value=mock_response)

        asyncio.run(adapter.ainvoke([Message(role="user", content="hi")]))
        call_args = mocks["client"].post.call_args
        assert call_args[0][0] == "http://localhost:11434/api/chat"

    def test_ainvoke_missing_message_field(self):
        adapter, mocks = _make_adapter()
        mock_response = MagicMock()
        mock_response.json.return_value = {}
        mock_response.raise_for_status = MagicMock()
        mocks["client"].post = AsyncMock(return_value=mock_response)

        result = asyncio.run(adapter.ainvoke([Message(role="user", content="hi")]))
        assert result.role == "assistant"
        assert result.content == ""


# TestInvoke

class TestInvoke:

    def test_invoke_delegates_to_ainvoke(self):
        adapter, _ = _make_adapter()
        with patch.object(adapter, "ainvoke", new_callable=AsyncMock) as mock_ainvoke:
            mock_ainvoke.return_value = Message(role="assistant", content="sync reply")
            result = adapter.invoke([Message(role="user", content="hi")])
            assert result.content == "sync reply"


# TestGetModelCapabilities

class TestGetModelCapabilities:

    def test_capabilities(self):
        adapter, _ = _make_adapter()
        caps = adapter.get_model_capabilities()
        assert caps["function_calling"] is False
        assert caps["tool_calling"] is False
        assert caps["supports_streaming"] is True
        assert caps["supports_async"] is True
