# test_anthropic_adapter.py

"""
Unit tests for the Anthropic adapter.
All tests mock the Anthropic client — no real API calls needed.
Requires the 'anthropic' package to be installed (optional dependency).
"""

import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch

# Skip the entire module if the anthropic SDK is not installed.
# The adapter guards this with try/except ImportError, so Anthropic and
# AsyncAnthropic won't exist as module-level names to patch against.
pytest.importorskip("anthropic", reason="anthropic SDK not installed")

from fairlib.core.message import Message


# ---------------------------------------------------------------------------
# Helper to build a mock adapter
# ---------------------------------------------------------------------------

def _make_adapter(api_key="test-key", model_name="claude-3-opus-20240229"):
    """Construct an AnthropicAdapter with mocked clients."""
    with patch("fairlib.modules.mal.anthropic_adapter.ANTHROPIC_INSTALLED", True), \
         patch("fairlib.modules.mal.anthropic_adapter.Anthropic") as mock_sync_cls, \
         patch("fairlib.modules.mal.anthropic_adapter.AsyncAnthropic") as mock_async_cls:

        mock_sync_client = MagicMock()
        mock_async_client = MagicMock()
        mock_sync_cls.return_value = mock_sync_client
        mock_async_cls.return_value = mock_async_client

        from fairlib.modules.mal.anthropic_adapter import AnthropicAdapter
        adapter = AnthropicAdapter(api_key=api_key, model_name=model_name)

        return adapter, {
            "sync_client": mock_sync_client,
            "async_client": mock_async_client,
        }


# TestConstructor

class TestConstructor:

    def test_import_error_without_anthropic(self):
        with patch("fairlib.modules.mal.anthropic_adapter.ANTHROPIC_INSTALLED", False):
            from fairlib.modules.mal.anthropic_adapter import AnthropicAdapter
            with pytest.raises(ImportError, match="anthropic"):
                AnthropicAdapter(api_key="key")

    def test_missing_api_key_raises(self):
        with patch("fairlib.modules.mal.anthropic_adapter.ANTHROPIC_INSTALLED", True), \
             patch("fairlib.modules.mal.anthropic_adapter.Anthropic"), \
             patch("fairlib.modules.mal.anthropic_adapter.AsyncAnthropic"), \
             patch.dict("os.environ", {}, clear=True):
            from fairlib.modules.mal.anthropic_adapter import AnthropicAdapter
            with pytest.raises(ValueError, match="API key"):
                AnthropicAdapter(api_key=None)

    def test_api_key_from_env(self):
        with patch.dict("os.environ", {"ANTHROPIC_API_KEY": "env-key"}, clear=False), \
             patch("fairlib.modules.mal.anthropic_adapter.ANTHROPIC_INSTALLED", True), \
             patch("fairlib.modules.mal.anthropic_adapter.Anthropic") as mock_sync, \
             patch("fairlib.modules.mal.anthropic_adapter.AsyncAnthropic"):
            from fairlib.modules.mal.anthropic_adapter import AnthropicAdapter
            adapter = AnthropicAdapter()
            mock_sync.assert_called_once_with(api_key="env-key")

    def test_model_name_stored(self):
        adapter, _ = _make_adapter(model_name="claude-3-haiku-20240307")
        assert adapter.model_name == "claude-3-haiku-20240307"


# TestPrepareMessages

class TestPrepareMessages:

    def test_extracts_system_prompt(self):
        adapter, _ = _make_adapter()
        msgs = [
            Message(role="system", content="Be concise."),
            Message(role="user", content="Hello"),
        ]
        system_prompt, anthropic_msgs = adapter._prepare_messages(msgs)
        assert system_prompt == "Be concise."
        assert len(anthropic_msgs) == 1
        assert anthropic_msgs[0] == {"role": "user", "content": "Hello"}

    def test_no_system_prompt(self):
        adapter, _ = _make_adapter()
        msgs = [Message(role="user", content="Hello")]
        system_prompt, anthropic_msgs = adapter._prepare_messages(msgs)
        assert system_prompt == ""
        assert len(anthropic_msgs) == 1

    def test_multiple_messages(self):
        adapter, _ = _make_adapter()
        msgs = [
            Message(role="system", content="System"),
            Message(role="user", content="Q1"),
            Message(role="assistant", content="A1"),
            Message(role="user", content="Q2"),
        ]
        system_prompt, anthropic_msgs = adapter._prepare_messages(msgs)
        assert system_prompt == "System"
        assert len(anthropic_msgs) == 3
        assert [m["role"] for m in anthropic_msgs] == ["user", "assistant", "user"]

    def test_empty_messages(self):
        adapter, _ = _make_adapter()
        system_prompt, anthropic_msgs = adapter._prepare_messages([])
        assert system_prompt == ""
        assert anthropic_msgs == []


# TestAInvoke

class TestAInvoke:

    def test_ainvoke_returns_message(self):
        adapter, mocks = _make_adapter()
        mock_response = MagicMock()
        mock_response.content = [MagicMock()]
        mock_response.content[0].text = "Claude says hi"
        mocks["async_client"].messages.create = AsyncMock(return_value=mock_response)

        result = asyncio.run(adapter.ainvoke([Message(role="user", content="hi")]))
        assert isinstance(result, Message)
        assert result.role == "assistant"
        assert result.content == "Claude says hi"

    def test_ainvoke_passes_system_prompt_separately(self):
        adapter, mocks = _make_adapter()
        mock_response = MagicMock()
        mock_response.content = [MagicMock()]
        mock_response.content[0].text = "reply"
        mocks["async_client"].messages.create = AsyncMock(return_value=mock_response)

        asyncio.run(adapter.ainvoke([
            Message(role="system", content="Be brief."),
            Message(role="user", content="hi"),
        ]))
        call_kwargs = mocks["async_client"].messages.create.call_args.kwargs
        assert call_kwargs["system"] == "Be brief."
        assert len(call_kwargs["messages"]) == 1

    def test_ainvoke_default_max_tokens(self):
        adapter, mocks = _make_adapter()
        mock_response = MagicMock()
        mock_response.content = [MagicMock()]
        mock_response.content[0].text = "reply"
        mocks["async_client"].messages.create = AsyncMock(return_value=mock_response)

        asyncio.run(adapter.ainvoke([Message(role="user", content="hi")]))
        call_kwargs = mocks["async_client"].messages.create.call_args.kwargs
        assert call_kwargs["max_tokens"] == 2048

    def test_ainvoke_on_api_error(self):
        adapter, mocks = _make_adapter()
        # Simulate a generic exception (anthropic.APIError requires complex setup)
        mocks["async_client"].messages.create = AsyncMock(
            side_effect=Exception("API error"))

        # The adapter catches anthropic.APIError specifically, but generic Exception
        # will propagate — test that the adapter doesn't crash silently
        with pytest.raises(Exception):
            asyncio.run(adapter.ainvoke([Message(role="user", content="hi")]))


# TestInvoke

class TestInvoke:

    def test_invoke_delegates_to_ainvoke(self):
        """invoke() should call ainvoke() via asyncio.run."""
        adapter, mocks = _make_adapter()
        mock_response = MagicMock()
        mock_response.content = [MagicMock()]
        mock_response.content[0].text = "sync reply"
        mocks["async_client"].messages.create = AsyncMock(return_value=mock_response)

        # invoke uses asyncio.run(self.ainvoke(...)) internally
        # This will fail if an event loop is already running, so we call directly
        with patch.object(adapter, "ainvoke", new_callable=AsyncMock) as mock_ainvoke:
            mock_ainvoke.return_value = Message(role="assistant", content="sync reply")
            result = adapter.invoke([Message(role="user", content="hi")])
            assert result.content == "sync reply"


# TestAStream

class TestAStream:

    def test_astream_yields_chunks(self):
        adapter, mocks = _make_adapter()

        async def mock_text_stream():
            for chunk in ["Hello", " from", " Claude"]:
                yield chunk

        mock_stream_cm = MagicMock()
        mock_stream_obj = MagicMock()
        mock_stream_obj.text_stream = mock_text_stream()

        # The astream method uses: async with self.async_client.messages.stream(...) as stream
        mock_stream_cm.__aenter__ = AsyncMock(return_value=mock_stream_obj)
        mock_stream_cm.__aexit__ = AsyncMock(return_value=False)
        mocks["async_client"].messages.stream.return_value = mock_stream_cm

        results = asyncio.run(_collect_astream(adapter, [Message(role="user", content="hi")]))
        assert len(results) == 3
        assert results[0].content == "Hello"
        assert results[1].content == " from"
        assert results[2].content == " Claude"
        assert all(m.role == "assistant" for m in results)


async def _collect_astream(adapter, messages, **kwargs):
    results = []
    async for msg in adapter.astream(messages, **kwargs):
        results.append(msg)
    return results


# TestGetModelCapabilities

class TestGetModelCapabilities:

    def test_capabilities(self):
        adapter, _ = _make_adapter()
        caps = adapter.get_model_capabilities()
        assert caps["supports_streaming"] is True
        assert caps["supports_async"] is True
        assert caps["supports_system_prompt"] is True
        assert "max_context_window" in caps


# TestChat

class TestChat:

    def test_chat_returns_string(self):
        adapter, _ = _make_adapter()
        with patch.object(adapter, "invoke") as mock_invoke:
            mock_invoke.return_value = Message(role="assistant", content="chat reply")
            result = adapter.chat([Message(role="user", content="hi")])
            assert result == "chat reply"

    def test_chat_passes_temperature(self):
        adapter, _ = _make_adapter()
        with patch.object(adapter, "invoke") as mock_invoke:
            mock_invoke.return_value = Message(role="assistant", content="reply")
            adapter.chat([Message(role="user", content="hi")], temperature=0.3)
            mock_invoke.assert_called_once()
            call_kwargs = mock_invoke.call_args
            assert call_kwargs.kwargs["temperature"] == 0.3
