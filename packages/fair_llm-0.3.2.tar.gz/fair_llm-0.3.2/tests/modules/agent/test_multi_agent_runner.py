# tests/modules/agent/test_multi_agent_runner.py
import pytest
import fairlib.modules.agent.multi_agent_runner as mr_mod

class _Msg:
    def __init__(self, role: str, content: str, name: str | None = None):
        self.role = role
        self.content = content
        self.name = name

class _Thought:
    def __init__(self, text: str):
        self.text = text

class _Action:
    def __init__(self, tool_name: str, tool_input):
        self.tool_name = tool_name
        self.tool_input = tool_input

class _Final:
    def __init__(self, text: str):
        self.text = text


class _FakeLLM:
    def __init__(self, responses):
        """
        responses: list[str] contents to return for ainvoke calls (in order).
        Each string should be the full LLM response text.
        """
        self.responses = list(responses)
        self.calls = []

    async def ainvoke(self, messages):
        self.calls.append(messages)
        content = self.responses.pop(0) if self.responses else ""
        return _Msg(role="assistant", content=content)


class _FakePromptBuilder:
    def __init__(self):
        self.role_definition = None
        self.format_instructions = []
        self.examples = []
        self._workers_added = None

    def clone(self):
        return self

    def add_worker_dict(self, workers):
        self._workers_added = workers

    def build_message_list(self, history, user_input):
        return [
            _Msg("system", "role: manager"),
            _Msg("user", f"user_input: {user_input}"),
            _Msg("system", f"history_len: {len(history)}"),
        ]


class _Memory:
    def __init__(self):
        self._h = []

    def add_message(self, msg: _Msg):
        self._h.append(msg)

    def get_history(self):
        return list(self._h)

class _Agent:
    def __init__(self, planner=None):
        self.planner = planner
        self.memory = _Memory()

    async def arun(self, task):
        return f"completed: {task}"


def _patch_core_types(monkeypatch):
    monkeypatch.setattr(mr_mod, "Message", _Msg, raising=True)
    monkeypatch.setattr(mr_mod, "Thought", _Thought, raising=True)
    monkeypatch.setattr(mr_mod, "Action", _Action, raising=True)
    monkeypatch.setattr(mr_mod, "FinalAnswer", _Final, raising=True)

def _patch_prompt_builder(monkeypatch):
    monkeypatch.setattr(mr_mod, "_create_default_manager_prompt_builder", lambda: _FakePromptBuilder(), raising=True)


def test_parse_json_delegate_and_final_answer(monkeypatch):
    _patch_core_types(monkeypatch)

    mp = mr_mod.ManagerPlanner(llm=None, workers={}, prompt_builder=_FakePromptBuilder())

    text_delegate = (
        "Thought: let's delegate.\n"
        '{"tool_name":"delegate","tool_input":{"worker_name":"Researcher","task":"Find X"}}'
    )
    out = mp._parse_json_response(text_delegate)
    assert isinstance(out, tuple)
    thought, action = out
    assert isinstance(thought, _Thought) and isinstance(action, _Action)
    assert thought.text.lower().startswith("let's delegate")
    assert action.tool_name == "delegate"
    assert action.tool_input["worker_name"] == "Researcher"

    text_final = (
        "Thought: concluding.\n"
        '{"tool_name":"final_answer","tool_input":"Here is the final."}'
    )
    out2 = mp._parse_json_response(text_final)
    assert isinstance(out2, _Final)
    assert out2.text == "Here is the final."

def test_parse_json_malformed_raises_planner_parse_error(monkeypatch):
    """Conversational text and truncated JSON both raise PlannerParseError.

    The library no longer launders contract violations into FinalAnswer.
    Implementors of this API must learn that their model failed to emit
    a parsable delegation block; the runner's retry loop handles re-prompt.
    """
    _patch_core_types(monkeypatch)
    mp = mr_mod.ManagerPlanner(llm=None, workers={}, prompt_builder=_FakePromptBuilder())

    raw_conversational = "I can help you with that question about calculus."
    with pytest.raises(mr_mod.PlannerParseError) as ei:
        mp._parse_json_response(raw_conversational)
    assert ei.value.raw_output == raw_conversational

    raw_truncated = 'Thought: hi\n{"tool_name":'
    with pytest.raises(mr_mod.PlannerParseError) as ei2:
        mp._parse_json_response(raw_truncated)
    assert ei2.value.raw_output == raw_truncated


@pytest.mark.asyncio
async def test_managerplanner_aplan_calls_llm_and_parses(monkeypatch):
    _patch_core_types(monkeypatch)
    _patch_prompt_builder(monkeypatch)

    response = (
        "Thought: delegate step.\n"
        '{"tool_name":"delegate","tool_input":{"worker_name":"Analyst","task":"Compute 2+2"}}'
    )
    llm = _FakeLLM([response])
    mp = mr_mod.ManagerPlanner(llm=llm, workers={"Analyst": _Agent()}, prompt_builder=None)

    history = [_Msg("system", "session start")]
    out = await mp.aplan(history, "What's 2+2?")
    assert isinstance(out, tuple)
    thought, action = out
    assert thought.text.startswith("delegate")
    assert action.tool_name == "delegate"
    assert llm.calls and isinstance(llm.calls[0], list)


@pytest.mark.asyncio
async def test_hierarchical_runner_delegate_then_final(monkeypatch):
    _patch_core_types(monkeypatch)

    class _MgrPlanner:
        def __init__(self):
            self.calls = 0
        async def aplan(self, history, user_input):
            self.calls += 1
            if self.calls == 1:
                return _Thought("We need data"), _Action("delegate", {"worker_name": "Researcher", "task": "Find gold price"})
            else:
                return _Final("Gold price is $X. Final answer assembled.")
        def format_turn_for_memory(self, step):
            if isinstance(step, _Final):
                return _Msg(role="assistant", content=step.text)
            thought, _ = step
            return _Msg(role="assistant", content=thought.text)

    class _Worker(_Agent):
        async def arun(self, task):
            return "The current price is $X"

    manager_agent = _Agent(planner=_MgrPlanner())
    workers = {"Researcher": _Worker()}
    runner = mr_mod.HierarchicalAgentRunner(manager_agent, workers, max_steps=5)

    result = await runner.arun("Find current gold price and summarize.")
    assert "Final answer" in result

    roles = [m.role for m in manager_agent.memory.get_history()]
    assert "system" in roles
    obs_msgs = [m for m in manager_agent.memory.get_history() if m.role == "system"]
    assert any("Result from Researcher:" in m.content for m in obs_msgs)


@pytest.mark.asyncio
async def test_runner_invalid_delegate_input_message(monkeypatch):
    """Invalid delegate input is recorded to manager memory before the
    loop hits its max_steps limit and raises."""
    _patch_core_types(monkeypatch)

    class _BadPlanner:
        async def aplan(self, history, user_input):
            return _Thought("oops"), _Action("delegate", "not-a-dict")
        def format_turn_for_memory(self, step):
            thought, _ = step
            return _Msg(role="assistant", content=thought.text)

    manager_agent = _Agent(planner=_BadPlanner())
    runner = mr_mod.HierarchicalAgentRunner(manager_agent, workers={}, max_steps=1)

    with pytest.raises(mr_mod.MaxStepsExceeded):
        await runner.arun("x")
    tool_msgs = [m for m in manager_agent.memory.get_history() if m.role == "tool"]
    assert tool_msgs and "not a valid dictionary" in tool_msgs[-1].content


@pytest.mark.asyncio
async def test_runner_invalid_action_name(monkeypatch):
    """Unknown action names are recorded to manager memory before the
    loop hits its max_steps limit and raises."""
    _patch_core_types(monkeypatch)

    class _BadPlanner:
        async def aplan(self, history, user_input):
            return _Thought("bad action"), _Action("unknown_action", {"foo": "bar"})
        def format_turn_for_memory(self, step):
            thought, _ = step
            return _Msg(role="assistant", content=thought.text)

    manager_agent = _Agent(planner=_BadPlanner())
    runner = mr_mod.HierarchicalAgentRunner(manager_agent, workers={}, max_steps=1)

    with pytest.raises(mr_mod.MaxStepsExceeded):
        await runner.arun("x")
    tool_msgs = [m for m in manager_agent.memory.get_history() if m.role == "tool"]
    assert tool_msgs and "invalid action" in tool_msgs[-1].content


@pytest.mark.asyncio
async def test_runner_missing_worker_or_task(monkeypatch):
    """Delegations to unknown workers are recorded to manager memory
    before the loop hits its max_steps limit and raises."""
    _patch_core_types(monkeypatch)

    class _PlannerNoWorker:
        async def aplan(self, history, user_input):
            return _Thought("delegate"), _Action("delegate", {"worker_name": "Nope", "task": "do it"})
        def format_turn_for_memory(self, step):
            thought, _ = step
            return _Msg(role="assistant", content=thought.text)

    manager_agent = _Agent(planner=_PlannerNoWorker())
    runner = mr_mod.HierarchicalAgentRunner(manager_agent, workers={}, max_steps=1)

    with pytest.raises(mr_mod.MaxStepsExceeded):
        await runner.arun("x")
    errs = [m.content for m in manager_agent.memory.get_history() if m.role == "tool"]
    assert any("delegation failed" in e for e in errs)


@pytest.mark.asyncio
async def test_runner_max_steps_exhausted(monkeypatch):
    """Runner raises MaxStepsExceeded when the loop hits max_steps without
    the manager producing a FinalAnswer."""
    _patch_core_types(monkeypatch)

    class _LoopPlanner:
        async def aplan(self, history, user_input):
            return _Thought("loop"), _Action("delegate", {"worker_name": "Missing", "task": "t"})
        def format_turn_for_memory(self, step):
            thought, _ = step
            return _Msg(role="assistant", content=thought.text)

    manager_agent = _Agent(planner=_LoopPlanner())
    runner = mr_mod.HierarchicalAgentRunner(manager_agent, workers={}, max_steps=2)

    with pytest.raises(mr_mod.MaxStepsExceeded) as ei:
        await runner.arun("x")
    assert ei.value.max_steps == 2
    assert ei.value.partial_history is not None


# Strict-parsing tests: malformed manager output raises PlannerParseError

def test_parse_json_malformed_raises_on_thought_only(monkeypatch):
    """Thought: prose with no parsable JSON raises PlannerParseError."""
    _patch_core_types(monkeypatch)
    mp = mr_mod.ManagerPlanner(llm=None, workers={}, prompt_builder=_FakePromptBuilder())

    raw = "Thought: I need to think about the student's work on derivatives carefully."
    with pytest.raises(mr_mod.PlannerParseError) as ei:
        mp._parse_json_response(raw)
    assert ei.value.raw_output == raw


def test_parse_json_malformed_raises_on_action_only(monkeypatch):
    """Thought + truncated Action JSON raises PlannerParseError.

    The runner's retry loop is the right channel for re-prompting when the
    manager emits an Action block it failed to terminate. The library must
    not silently strip the broken JSON and surface the prose as an answer.
    """
    _patch_core_types(monkeypatch)
    mp = mr_mod.ManagerPlanner(llm=None, workers={}, prompt_builder=_FakePromptBuilder())

    raw = (
        "Thought: The student needs help with recursion.\n"
        'Action: {"tool_name": "delegate", "tool_input": '
    )
    with pytest.raises(mr_mod.PlannerParseError) as ei:
        mp._parse_json_response(raw)
    assert ei.value.raw_output == raw


def test_parse_json_malformed_empty_after_strip(monkeypatch):
    """Internal-reasoning-only responses raise PlannerParseError.

    The HierarchicalAgentRunner's retry-with-corrective-message loop is the
    only legitimate recovery path; the parser must surface the contract
    violation rather than collapsing into a user-facing fallback.
    """
    _patch_core_types(monkeypatch)
    mp = mr_mod.ManagerPlanner(llm=None, workers={}, prompt_builder=_FakePromptBuilder())

    raw = 'Thought:\nAction: {"tool_name": "delegate"'
    with pytest.raises(mr_mod.PlannerParseError):
        mp._parse_json_response(raw)


