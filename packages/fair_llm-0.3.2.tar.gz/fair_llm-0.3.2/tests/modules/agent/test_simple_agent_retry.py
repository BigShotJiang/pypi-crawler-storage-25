# test_simple_agent_retry.py
"""Tests for SimpleAgent retry-on-PlannerParseError behavior."""

import asyncio

import pytest
from unittest.mock import AsyncMock, MagicMock

from fairlib.core.errors import PlannerParseError
from fairlib.core.interfaces.planner import AbstractPlanner
from fairlib.core.interfaces.executor import AbstractToolExecutor
from fairlib.core.interfaces.memory import AbstractMemory
from fairlib.core.interfaces.llm import AbstractChatModel
from fairlib.core.message import FinalAnswer
from fairlib.modules.agent.simple_agent import SimpleAgent


@pytest.fixture
def mock_components():
    return {
        "planner": MagicMock(spec=AbstractPlanner),
        "tool_executor": MagicMock(spec=AbstractToolExecutor),
        "memory": MagicMock(spec=AbstractMemory),
        "llm": MagicMock(spec=AbstractChatModel),
    }


def test_retry_once_then_succeed(mock_components):
    """First call raises PlannerParseError, second succeeds."""
    agent = SimpleAgent(
        llm=mock_components["llm"],
        planner=mock_components["planner"],
        tool_executor=mock_components["tool_executor"],
        memory=mock_components["memory"],
    )

    mock_components["planner"].aplan = AsyncMock(
        side_effect=[
            PlannerParseError("empty"),
            FinalAnswer(text="Recovered response."),
        ]
    )
    mock_components["memory"].aget_history = AsyncMock(return_value=[])

    result = asyncio.run(agent.arun("test input"))

    assert result == "Recovered response."
    assert mock_components["planner"].aplan.await_count == 2
    # Should have added a retry system message to memory
    assert mock_components["memory"].add_message.call_count >= 1


def test_two_consecutive_failures_propagates_planner_parse_error(mock_components):
    """Two consecutive PlannerParseErrors propagate to the caller.

    The library does not return apology copy — the typed error reaches
    the implementor with raw_output preserved so they can route on cause.
    """
    agent = SimpleAgent(
        llm=mock_components["llm"],
        planner=mock_components["planner"],
        tool_executor=mock_components["tool_executor"],
        memory=mock_components["memory"],
    )

    raised = PlannerParseError("always empty", raw_output="garbage")
    mock_components["planner"].aplan = AsyncMock(side_effect=raised)
    mock_components["memory"].aget_history = AsyncMock(return_value=[])

    with pytest.raises(PlannerParseError) as ei:
        asyncio.run(agent.arun("test input"))
    assert ei.value.raw_output == "garbage"
    # Two attempts consumed: one initial, one retry.
    assert mock_components["planner"].aplan.await_count == 2


def test_parse_error_counter_resets_on_success(mock_components):
    """After a successful plan, the failure counter resets so a future
    parse error inside the same run still gets its retry chance."""
    agent = SimpleAgent(
        llm=mock_components["llm"],
        planner=mock_components["planner"],
        tool_executor=mock_components["tool_executor"],
        memory=mock_components["memory"],
    )

    mock_components["planner"].aplan = AsyncMock(
        side_effect=[
            PlannerParseError("empty"),
            FinalAnswer(text="Ok."),
        ]
    )
    mock_components["memory"].aget_history = AsyncMock(return_value=[])

    result = asyncio.run(agent.arun("test input"))
    assert result == "Ok."
