# test_simple_agent.py
import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock

from fairlib.core.interfaces.planner import AbstractPlanner
from fairlib.core.interfaces.executor import AbstractToolExecutor
from fairlib.core.interfaces.memory import AbstractMemory
from fairlib.core.interfaces.llm import AbstractChatModel

from fairlib.core.message import Message, Thought, Action, Observation, FinalAnswer
from fairlib.modules.agent.simple_agent import SimpleAgent


@pytest.fixture
def mock_components():
    """A pytest fixture to create all the mocks needed for the agent."""
    return {
        "planner": MagicMock(spec=AbstractPlanner),
        "tool_executor": MagicMock(spec=AbstractToolExecutor),
        "memory": MagicMock(spec=AbstractMemory),
        "llm": MagicMock(spec=AbstractChatModel)
    }

def test_agent_reaches_final_answer_pytest(mock_components):
    """
    A test for a successful agent run.
    """
    # Arrange
    agent = SimpleAgent(
        llm=mock_components["llm"],
        planner=mock_components["planner"],
        tool_executor=mock_components["tool_executor"],
        memory=mock_components["memory"]
    )

    # Configure the mock planner's async method to call 'search' tool and return finalanswer of weather. note: this loads two calls to aplan
    mock_components["planner"].aplan = AsyncMock(
        side_effect=[
            (Thought(text="The user wants to know the current weather, I must use the search tool to find it"), Action(tool_name="search", tool_input="weather")),
            FinalAnswer(text="It is sunny.")
        ]
    )
    # Observation message is returned by tool executor
    # SimpleAgent uses aexecute when available (for MCP tool support)
    mock_components["tool_executor"].aexecute = AsyncMock(return_value="Observation: sunny")
    mock_components["memory"].aget_history = AsyncMock(return_value=[])

    # Act
    result = asyncio.run(agent.arun("What's the weather?"))

    # Assert
    assert result == "It is sunny."
    mock_components["planner"].aplan.assert_awaited()
    mock_components["tool_executor"].aexecute.assert_awaited_once_with("search", "weather")


def test_agent_calls_aget_history_not_get_history(mock_components):
    """SimpleAgent.arun() must call aget_history (async) not get_history (sync)."""
    agent = SimpleAgent(
        llm=mock_components["llm"],
        planner=mock_components["planner"],
        tool_executor=mock_components["tool_executor"],
        memory=mock_components["memory"]
    )

    mock_components["planner"].aplan = AsyncMock(
        return_value=FinalAnswer(text="Done.")
    )
    mock_components["memory"].aget_history = AsyncMock(return_value=[])

    asyncio.run(agent.arun("test"))

    mock_components["memory"].aget_history.assert_awaited_once()
    mock_components["memory"].get_history.assert_not_called()
