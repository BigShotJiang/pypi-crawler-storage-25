# Tests for SimpleAgent.arun accepting a pre-built Message.
#
# A caller that wants to attach Message.importance="pinned" or
# Message.metadata to the user turn must be able to construct the Message
# itself and hand it to the agent. The agent then uses it verbatim in
# turn_messages instead of constructing a default Message from a string.

import asyncio
from unittest.mock import AsyncMock, MagicMock

import pytest

from fairlib.core.interfaces.executor import AbstractToolExecutor
from fairlib.core.interfaces.llm import AbstractChatModel
from fairlib.core.interfaces.memory import AbstractMemory
from fairlib.core.interfaces.planner import AbstractPlanner
from fairlib.core.errors import InvalidAgentInputError
from fairlib.core.message import FinalAnswer, Message
from fairlib.modules.agent.simple_agent import SimpleAgent


@pytest.fixture
def mock_components():
    return {
        "planner": MagicMock(spec=AbstractPlanner),
        "tool_executor": MagicMock(spec=AbstractToolExecutor),
        "memory": MagicMock(spec=AbstractMemory),
        "llm": MagicMock(spec=AbstractChatModel),
    }


def _build_agent(comps):
    return SimpleAgent(
        llm=comps["llm"],
        planner=comps["planner"],
        tool_executor=comps["tool_executor"],
        memory=comps["memory"],
    )


def _set_planner_final(comps, text="OK"):
    comps["planner"].aplan = AsyncMock(return_value=FinalAnswer(text=text))
    comps["memory"].aget_history = AsyncMock(return_value=[])
    comps["planner"].format_turn_for_memory = MagicMock(
        return_value=Message(role="assistant", content=text)
    )


def test_arun_accepts_message_and_preserves_importance_and_metadata(mock_components):
    agent = _build_agent(mock_components)
    _set_planner_final(mock_components)

    pinned_msg = Message(
        role="user",
        content="My final answer is 6x + 2",
        importance="pinned",
        metadata={"answer_seen": True, "turn_index": 5},
    )

    result = asyncio.run(agent.arun(pinned_msg))

    assert result == "OK"
    add_calls = [c.args[0] for c in mock_components["memory"].add_message.call_args_list]
    user_msgs = [m for m in add_calls if m.role == "user"]
    assert len(user_msgs) == 1
    assert user_msgs[0] is pinned_msg, "Caller's Message instance must be used verbatim"
    assert user_msgs[0].importance == "pinned"
    assert user_msgs[0].metadata == {"answer_seen": True, "turn_index": 5}


def test_arun_extracts_content_for_planner_current_request(mock_components):
    agent = _build_agent(mock_components)
    captured = {}

    async def fake_aplan(history, current_request):
        captured["current_request"] = current_request
        return FinalAnswer(text="OK")

    mock_components["planner"].aplan = AsyncMock(side_effect=fake_aplan)
    mock_components["memory"].aget_history = AsyncMock(return_value=[])
    mock_components["planner"].format_turn_for_memory = MagicMock(
        return_value=Message(role="assistant", content="OK")
    )

    asyncio.run(
        agent.arun(
            Message(
                role="user",
                content="What is the derivative?",
                importance="pinned",
            )
        )
    )

    assert captured["current_request"] == "What is the derivative?"


def test_arun_string_input_remains_supported(mock_components):
    agent = _build_agent(mock_components)
    _set_planner_final(mock_components)

    result = asyncio.run(agent.arun("plain string input"))
    assert result == "OK"

    add_calls = [c.args[0] for c in mock_components["memory"].add_message.call_args_list]
    user_msgs = [m for m in add_calls if m.role == "user"]
    assert len(user_msgs) == 1
    added = user_msgs[0]
    assert added.content == "plain string input"
    assert added.importance == "normal"
    assert added.metadata == {}


def test_arun_message_with_normal_importance_passes_through(mock_components):
    agent = _build_agent(mock_components)
    _set_planner_final(mock_components)

    msg = Message(role="user", content="hi", metadata={"trace_id": "abc"})
    asyncio.run(agent.arun(msg))

    add_calls = [c.args[0] for c in mock_components["memory"].add_message.call_args_list]
    user_msgs = [m for m in add_calls if m.role == "user"]
    assert user_msgs[0].importance == "normal"
    assert user_msgs[0].metadata == {"trace_id": "abc"}


def test_arun_rejects_non_user_role_message(mock_components):
    agent = _build_agent(mock_components)
    _set_planner_final(mock_components)

    bad = Message(role="assistant", content="i am not a user turn")
    with pytest.raises(InvalidAgentInputError, match="role"):
        asyncio.run(agent.arun(bad))
