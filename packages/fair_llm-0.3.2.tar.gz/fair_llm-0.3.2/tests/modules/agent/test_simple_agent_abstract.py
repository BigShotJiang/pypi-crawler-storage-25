"""SimpleAgent must work with ANY AbstractPlanner subclass.

These tests enforce the abstract-design invariant on SimpleAgent: no
concrete planner classes are imported by simple_agent.py, no
isinstance(self.planner, X) branches exist, and a planner that is not
a ReAct planner at all drives the agent correctly with its own memory
format.
"""

import inspect
from typing import Any, AsyncIterator, Dict, Iterator, List, Tuple, Union

import pytest

from fairlib.core.interfaces.llm import AbstractChatModel
from fairlib.core.interfaces.planner import AbstractPlanner
from fairlib.core.message import Action, FinalAnswer, Message, Thought
from fairlib.modules.action.executor import ToolExecutor
from fairlib.modules.action.tools.registry import ToolRegistry
from fairlib.modules.agent.simple_agent import SimpleAgent
from fairlib.modules.memory.base import WorkingMemory


class _DummyLLM(AbstractChatModel):
    """Never actually called by the tests below — planners return pre-canned steps."""

    def invoke(self, messages, **kwargs): return Message(role="assistant", content="")
    async def ainvoke(self, messages, **kwargs): return Message(role="assistant", content="")
    def stream(self, messages, **kwargs): yield Message(role="assistant", content="")
    async def astream(self, messages, **kwargs):
        yield Message(role="assistant", content="")
    def get_model_capabilities(self) -> Dict[str, Any]: return {}


class _FakePlanner(AbstractPlanner):
    """Returns a caller-provided sequence of plan steps and records what the
    agent hands back to format_turn_for_memory."""

    def __init__(self, steps: List[Union[Tuple[Thought, Action], FinalAnswer]]):
        self._steps = list(steps)
        self.format_calls = []

    def plan(self, history, user_input=None, **kwargs):
        return self._steps.pop(0)

    async def aplan(self, history, user_input=None, **kwargs):
        return self._steps.pop(0)

    def format_turn_for_memory(self, step) -> Message:
        self.format_calls.append(step)
        if isinstance(step, FinalAnswer):
            return Message(role="assistant", content=f"[fake-final]{step.text}")
        thought, action = step
        return Message(
            role="assistant",
            content=f"[fake-step]{thought.text}|{action.tool_name}|{action.tool_input}",
        )


class TestSimpleAgentHasNoConcreteCoupling:
    def test_source_has_no_concrete_planner_imports(self):
        from fairlib.modules.agent import simple_agent

        src = inspect.getsource(simple_agent)
        assert "SimpleReActPlanner" not in src
        assert "from fairlib.modules.planning.react_planner" not in src

    def test_source_has_no_isinstance_on_planner(self):
        from fairlib.modules.agent import simple_agent

        src = inspect.getsource(simple_agent)
        assert "isinstance(self.planner" not in src

    def test_source_has_no_inline_memory_formatting(self):
        """The JSON/KV memory dispatch used to live inline in simple_agent.py;
        now the planner owns that shape. Accessing action.tool_name for
        logging or executor dispatch is fine — what we forbid is the agent
        serializing a plan step into JSON or a KV template itself.
        """
        from fairlib.modules.agent import simple_agent

        src = inspect.getsource(simple_agent)
        # No inline JSON serialization of the plan step — this is the
        # exact construct the legacy code used for ReActPlanner memory.
        assert "json.dumps" not in src
        # No `import json` either — simple_agent no longer needs JSON at all.
        assert "import json" not in src


class TestSimpleAgentWorksWithArbitraryAbstractPlanner:
    @pytest.mark.asyncio
    async def test_final_answer_is_serialized_via_planner(self):
        planner = _FakePlanner([FinalAnswer(text="hello")])
        agent = SimpleAgent(
            llm=_DummyLLM(),
            planner=planner,
            tool_executor=ToolExecutor(ToolRegistry()),
            memory=WorkingMemory(),
        )
        result = await agent.arun("hi")
        assert result == "hello"
        # Exactly one format_turn_for_memory call, with the FinalAnswer.
        assert len(planner.format_calls) == 1
        assert isinstance(planner.format_calls[0], FinalAnswer)
        # Memory contains the planner-owned format verbatim.
        history = await agent.memory.aget_history()
        assistant_msgs = [m for m in history if m.role == "assistant"]
        assert assistant_msgs[0].content == "[fake-final]hello"

    @pytest.mark.asyncio
    async def test_tool_step_is_serialized_via_planner(self):
        # First step: call a tool. Second step: final answer.
        registry = ToolRegistry()

        from fairlib.core.interfaces.tools import AbstractTool

        class _EchoTool(AbstractTool):
            name = "echo"
            description = "echoes input"

            def use(self, tool_input):
                return f"echoed:{tool_input}"

        registry.register_tool(_EchoTool())

        planner = _FakePlanner(
            [
                (Thought(text="think"), Action(tool_name="echo", tool_input="payload")),
                FinalAnswer(text="done"),
            ]
        )
        agent = SimpleAgent(
            llm=_DummyLLM(),
            planner=planner,
            tool_executor=ToolExecutor(registry),
            memory=WorkingMemory(),
        )
        result = await agent.arun("hi")
        assert result == "done"
        assert len(planner.format_calls) == 2
        # Memory layout: user, assistant (step1 via planner), system (observation),
        # assistant (final via planner).
        history = await agent.memory.aget_history()
        assistant_msgs = [m for m in history if m.role == "assistant"]
        assert assistant_msgs[0].content == "[fake-step]think|echo|payload"
        assert assistant_msgs[1].content == "[fake-final]done"
