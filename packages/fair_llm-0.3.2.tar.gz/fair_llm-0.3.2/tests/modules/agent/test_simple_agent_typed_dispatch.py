"""Tests for SimpleAgent typed-error dispatch.

Covers four behaviors in arun():
  - AdapterError raised by the planner propagates to the caller.
  - ToolInvocationError raised by the executor surfaces as an observation
    to the planner; the loop continues.
  - bare Exception raised by the executor is wrapped to ToolInvocationError
    so the failure channel is uniform.
  - max_steps reached without a FinalAnswer raises MaxStepsExceeded.

PlannerParseError dispatch is covered separately in test_simple_agent_retry.

arun() returns the final-answer string on success and raises a typed
FairlibError subclass on failure. There is no apology copy and no
_last_error mirror — implementors catch the typed exception.
"""

import asyncio

import pytest
from unittest.mock import AsyncMock, MagicMock

from fairlib.core.errors import (
    AdapterError,
    MaxStepsExceeded,
    ToolInvocationError,
)
from fairlib.core.interfaces.planner import AbstractPlanner
from fairlib.core.interfaces.executor import AbstractToolExecutor
from fairlib.core.interfaces.memory import AbstractMemory
from fairlib.core.interfaces.llm import AbstractChatModel
from fairlib.core.message import Action, FinalAnswer, Message, Thought
from fairlib.modules.agent.simple_agent import SimpleAgent


@pytest.fixture
def mock_components():
    components = {
        "planner": MagicMock(spec=AbstractPlanner),
        "tool_executor": MagicMock(spec=AbstractToolExecutor),
        "memory": MagicMock(spec=AbstractMemory),
        "llm": MagicMock(spec=AbstractChatModel),
    }
    components["memory"].aget_history = AsyncMock(return_value=[])
    return components


def _build_agent(components, **overrides):
    return SimpleAgent(
        llm=components["llm"],
        planner=components["planner"],
        tool_executor=components["tool_executor"],
        memory=components["memory"],
        **overrides,
    )


# AdapterError dispatch

def test_adapter_error_propagates_with_typed_cause(mock_components):
    """When the planner raises AdapterError, arun propagates it.

    Adapter outages are not re-prompt-able, so there is no retry. The
    caller catches the typed exception and inspects provider/raw_output.
    """
    agent = _build_agent(mock_components)

    raised = AdapterError(
        "provider down",
        provider="openai",
        raw_output="HTTP 503",
    )
    mock_components["planner"].aplan = AsyncMock(side_effect=raised)

    with pytest.raises(AdapterError) as ei:
        asyncio.run(agent.arun("anything"))
    assert ei.value.provider == "openai"
    assert ei.value.raw_output == "HTTP 503"
    # No retry — adapter outage is not a re-prompt-able condition.
    assert mock_components["planner"].aplan.await_count == 1


# ToolInvocationError dispatch

def test_tool_invocation_error_surfaces_tool_name_in_observation(mock_components):
    """When the executor raises ToolInvocationError, the observation
    written to memory carries the tool_name verbatim and the agent
    continues to the next step."""
    agent = _build_agent(mock_components)

    thought = Thought(text="I'll use the calculator.")
    action = Action(tool_name="calculator", tool_input="2+2")

    mock_components["planner"].aplan = AsyncMock(
        side_effect=[
            (thought, action),
            FinalAnswer(text="Done despite tool failure."),
        ]
    )
    mock_components["planner"].format_turn_for_memory = MagicMock(
        return_value=Message(role="assistant", content="turn")
    )
    # SimpleAgent prefers aexecute when present; spec-based MagicMock
    # exposes it, so we configure that path.
    mock_components["tool_executor"].aexecute = AsyncMock(
        side_effect=ToolInvocationError(
            "tool blew up",
            tool_name="calculator",
            raw_output="ZeroDivisionError",
        )
    )

    result = asyncio.run(agent.arun("compute"))

    assert result == "Done despite tool failure."
    # Tool failures surface as observations in-loop; arun returns normally.

    # Inspect every Message added to memory for the typed observation
    # carrying the tool_name. We do not assume position because the
    # exact memory-write sequence is owned by the planner contract.
    added_contents = [
        call.args[0].content
        for call in mock_components["memory"].add_message.call_args_list
        if isinstance(call.args[0], Message)
    ]
    assert any(
        "calculator" in c and "Error" in c for c in added_contents
    ), f"Expected typed observation referencing 'calculator'; got {added_contents}"


def test_bare_executor_exception_is_wrapped_as_tool_invocation_error(mock_components):
    """When the executor raises a bare Exception, the agent must wrap
    it as ToolInvocationError so the failure channel is uniform."""
    agent = _build_agent(mock_components)

    thought = Thought(text="Try the search tool.")
    action = Action(tool_name="web_search", tool_input="quantum")

    mock_components["planner"].aplan = AsyncMock(
        side_effect=[
            (thought, action),
            FinalAnswer(text="Recovered."),
        ]
    )
    mock_components["planner"].format_turn_for_memory = MagicMock(
        return_value=Message(role="assistant", content="turn")
    )
    mock_components["tool_executor"].aexecute = AsyncMock(
        side_effect=ValueError("network is down")
    )

    result = asyncio.run(agent.arun("research"))

    assert result == "Recovered."
    # The observation must reference the tool_name (the wrapping carries
    # action.tool_name through), proving the bare Exception was wrapped.
    added_contents = [
        call.args[0].content
        for call in mock_components["memory"].add_message.call_args_list
        if isinstance(call.args[0], Message)
    ]
    assert any(
        "web_search" in c and "network is down" in c for c in added_contents
    ), f"Expected wrapped observation referencing 'web_search'; got {added_contents}"


# MaxStepsExceeded dispatch

def test_max_steps_exhausted_raises_with_partial_history(mock_components):
    """When the loop runs out of steps without a FinalAnswer, arun raises
    MaxStepsExceeded carrying the accumulated history on partial_history."""
    agent = _build_agent(mock_components, max_steps=3)

    thought = Thought(text="step")
    action = Action(tool_name="noop", tool_input="x")

    # Planner never produces a FinalAnswer — every step returns a (thought, action).
    mock_components["planner"].aplan = AsyncMock(return_value=(thought, action))
    mock_components["planner"].format_turn_for_memory = MagicMock(
        return_value=Message(role="assistant", content="turn")
    )
    mock_components["tool_executor"].aexecute = AsyncMock(return_value="ok")

    with pytest.raises(MaxStepsExceeded) as ei:
        asyncio.run(agent.arun("loop forever"))
    assert ei.value.max_steps == 3
    assert ei.value.partial_history is not None
    # Loop ran exactly max_steps times before exhaustion.
    assert mock_components["planner"].aplan.await_count == 3
