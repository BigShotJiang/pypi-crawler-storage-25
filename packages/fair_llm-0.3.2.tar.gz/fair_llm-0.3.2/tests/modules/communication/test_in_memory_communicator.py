import pytest
from fairlib.modules.communication.in_memory_communicator import InMemoryCommunicator
from fairlib.core.message import Message


class TestInMemoryCommunicator:
    """Test cases for the InMemoryCommunicator class."""

    def setup_method(self):
        """Set up test fixtures."""
        self.communicator = InMemoryCommunicator()
        self.agent1_id = "agent_1"
        self.agent2_id = "agent_2"
        self.agent3_id = "agent_3"

    def _create_message(self, sender_id: str, content: str, role: str = "user") -> Message:
        """Helper method to create a Message with sender_id in metadata."""
        message = Message(role=role, content=content)
        message.metadata["sender_id"] = sender_id
        return message

    def test_init(self):
        """Test that the communicator initializes correctly."""
        assert self.communicator._message_queues == {}
        assert self.communicator._registered_agents == []

    def test_register_agent(self):
        """Test agent registration."""
        self.communicator.register_agent(self.agent1_id)
        assert self.agent1_id in self.communicator._registered_agents
        
        # Test registering the same agent again (should not duplicate)
        self.communicator.register_agent(self.agent1_id)
        assert self.communicator._registered_agents.count(self.agent1_id) == 1

    def test_register_multiple_agents(self):
        """Test registering multiple agents."""
        self.communicator.register_agent(self.agent1_id)
        self.communicator.register_agent(self.agent2_id)
        self.communicator.register_agent(self.agent3_id)
        
        assert self.agent1_id in self.communicator._registered_agents
        assert self.agent2_id in self.communicator._registered_agents
        assert self.agent3_id in self.communicator._registered_agents
        assert len(self.communicator._registered_agents) == 3

    def test_send_message(self):
        """Test sending a message to an agent."""
        self.communicator.register_agent(self.agent1_id)
        message = Message(role="user", content="Hello, Agent 1!")
        message.metadata["sender_id"] = self.agent2_id
        
        self.communicator.send_message(self.agent1_id, message)
        
        assert len(self.communicator._message_queues[self.agent1_id]) == 1
        assert self.communicator._message_queues[self.agent1_id][0] == message

    def test_send_multiple_messages(self):
        """Test sending multiple messages to an agent."""
        self.communicator.register_agent(self.agent1_id)
        message1 = self._create_message(self.agent2_id, "First message")
        message2 = self._create_message(self.agent3_id, "Second message")
        message3 = self._create_message(self.agent2_id, "Third message")
        
        self.communicator.send_message(self.agent1_id, message1)
        self.communicator.send_message(self.agent1_id, message2)
        self.communicator.send_message(self.agent1_id, message3)
        
        queue = self.communicator._message_queues[self.agent1_id]
        assert len(queue) == 3
        assert queue[0] == message1
        assert queue[1] == message2
        assert queue[2] == message3

    def test_receive_message_empty_queue(self):
        """Test receiving a message from an empty queue."""
        self.communicator.register_agent(self.agent1_id)
        
        result = self.communicator.receive_message(self.agent1_id)
        assert result is None

    def test_receive_message_fifo_order(self):
        """Test that messages are received in FIFO order."""
        self.communicator.register_agent(self.agent1_id)
        message1 = self._create_message(self.agent2_id, "First message")
        message2 = self._create_message(self.agent3_id, "Second message")
        
        self.communicator.send_message(self.agent1_id, message1)
        self.communicator.send_message(self.agent1_id, message2)
        
        # Receive first message
        received1 = self.communicator.receive_message(self.agent1_id)
        assert received1 == message1
        assert len(self.communicator._message_queues[self.agent1_id]) == 1
        
        # Receive second message
        received2 = self.communicator.receive_message(self.agent1_id)
        assert received2 == message2
        assert len(self.communicator._message_queues[self.agent1_id]) == 0

    def test_receive_message_removes_from_queue(self):
        """Test that receiving a message removes it from the queue."""
        self.communicator.register_agent(self.agent1_id)
        message = self._create_message(self.agent2_id, "Test message")
        
        self.communicator.send_message(self.agent1_id, message)
        assert len(self.communicator._message_queues[self.agent1_id]) == 1
        
        self.communicator.receive_message(self.agent1_id)
        assert len(self.communicator._message_queues[self.agent1_id]) == 0

    def test_broadcast(self):
        """Test broadcasting a message to all registered agents except sender."""
        self.communicator.register_agent(self.agent1_id)
        self.communicator.register_agent(self.agent2_id)
        self.communicator.register_agent(self.agent3_id)
        
        message = self._create_message(self.agent1_id, "Broadcast message")
        self.communicator.broadcast(message)
        
        # Agent 1 should not receive the message (sender)
        assert len(self.communicator._message_queues[self.agent1_id]) == 0
        
        # Agent 2 and 3 should receive the message
        assert len(self.communicator._message_queues[self.agent2_id]) == 1
        assert len(self.communicator._message_queues[self.agent3_id]) == 1
        assert self.communicator._message_queues[self.agent2_id][0] == message
        assert self.communicator._message_queues[self.agent3_id][0] == message

    def test_broadcast_single_agent(self):
        """Test broadcasting when only one agent is registered."""
        self.communicator.register_agent(self.agent1_id)
        
        message = self._create_message(self.agent1_id, "Broadcast to self")
        self.communicator.broadcast(message)
        
        # Should not receive own broadcast
        assert len(self.communicator._message_queues[self.agent1_id]) == 0

    def test_broadcast_no_agents(self):
        """Test broadcasting when no agents are registered."""
        message = self._create_message(self.agent1_id, "Broadcast to none")
        self.communicator.broadcast(message)
        
        # Should not crash and should not create any queues
        assert len(self.communicator._message_queues) == 0

    @pytest.mark.asyncio
    async def test_asend_message(self):
        """Test asynchronous message sending."""
        self.communicator.register_agent(self.agent1_id)
        message = self._create_message(self.agent2_id, "Async message")
        
        await self.communicator.asend_message(self.agent1_id, message)
        
        assert len(self.communicator._message_queues[self.agent1_id]) == 1
        assert self.communicator._message_queues[self.agent1_id][0] == message

    @pytest.mark.asyncio
    async def test_areceive_message(self):
        """Test asynchronous message receiving."""
        self.communicator.register_agent(self.agent1_id)
        message = self._create_message(self.agent2_id, "Async receive test")
        
        self.communicator.send_message(self.agent1_id, message)
        
        received = await self.communicator.areceive_message(self.agent1_id)
        assert received == message
        assert len(self.communicator._message_queues[self.agent1_id]) == 0

    @pytest.mark.asyncio
    async def test_areceive_message_empty_queue(self):
        """Test asynchronous message receiving from empty queue."""
        self.communicator.register_agent(self.agent1_id)
        
        result = await self.communicator.areceive_message(self.agent1_id)
        assert result is None

    def test_message_queues_independence(self):
        """Test that message queues are independent for different agents."""
        self.communicator.register_agent(self.agent1_id)
        self.communicator.register_agent(self.agent2_id)
        
        message1 = self._create_message(self.agent2_id, "Message to agent 1")
        message2 = self._create_message(self.agent1_id, "Message to agent 2")
        
        self.communicator.send_message(self.agent1_id, message1)
        self.communicator.send_message(self.agent2_id, message2)
        
        assert len(self.communicator._message_queues[self.agent1_id]) == 1
        assert len(self.communicator._message_queues[self.agent2_id]) == 1
        assert self.communicator._message_queues[self.agent1_id][0] == message1
        assert self.communicator._message_queues[self.agent2_id][0] == message2

    def test_send_to_unregistered_agent(self):
        """Test sending a message to an unregistered agent."""
        message = self._create_message(self.agent1_id, "Message to unregistered")
        
        # Should not crash and should create a queue for the agent
        self.communicator.send_message(self.agent2_id, message)
        
        assert len(self.communicator._message_queues[self.agent2_id]) == 1
        assert self.communicator._message_queues[self.agent2_id][0] == message

    def test_receive_from_unregistered_agent(self):
        """Test receiving a message from an unregistered agent."""
        result = self.communicator.receive_message(self.agent1_id)
        assert result is None

    def test_message_with_complex_content(self):
        """Test sending and receiving messages with complex content."""
        self.communicator.register_agent(self.agent1_id)
        
        complex_content = {
            "text": "Hello",
            "numbers": [1, 2, 3],
            "nested": {"key": "value"},
            "boolean": True,
            "null": None
        }
        
        message = self._create_message(self.agent2_id, complex_content)
        self.communicator.send_message(self.agent1_id, message)
        
        received = self.communicator.receive_message(self.agent1_id)
        assert received == message
        assert received.content == complex_content

    def test_multiple_agents_communication(self):
        """Test communication between multiple agents."""
        self.communicator.register_agent(self.agent1_id)
        self.communicator.register_agent(self.agent2_id)
        self.communicator.register_agent(self.agent3_id)
        
        # Agent 1 sends to Agent 2
        message1 = self._create_message(self.agent1_id, "From 1 to 2")
        self.communicator.send_message(self.agent2_id, message1)
        
        # Agent 2 sends to Agent 3
        message2 = self._create_message(self.agent2_id, "From 2 to 3")
        self.communicator.send_message(self.agent3_id, message2)
        
        # Agent 3 broadcasts
        message3 = self._create_message(self.agent3_id, "Broadcast from 3")
        self.communicator.broadcast(message3)
        
        # Check message queues
        assert len(self.communicator._message_queues[self.agent1_id]) == 1  # Broadcast
        assert len(self.communicator._message_queues[self.agent2_id]) == 2  # From 1 + Broadcast
        assert len(self.communicator._message_queues[self.agent3_id]) == 1  # From 2
        
        # Verify correct messages
        assert self.communicator._message_queues[self.agent1_id][0] == message3
        assert self.communicator._message_queues[self.agent2_id][0] == message1  # First message
        assert self.communicator._message_queues[self.agent2_id][1] == message3  # Broadcast message
        assert self.communicator._message_queues[self.agent3_id][0] == message2
