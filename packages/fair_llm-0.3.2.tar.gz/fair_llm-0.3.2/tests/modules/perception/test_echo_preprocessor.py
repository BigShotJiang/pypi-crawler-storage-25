import pytest
from fairlib.modules.perception.echo_preprocessor import EchoPreprocessor


class TestEchoPreprocessor:
    """Test cases for the EchoPreprocessor class."""

    def setup_method(self):
        """Set up test fixtures."""
        self.preprocessor = EchoPreprocessor()

    def test_process_input_returns_input_unchanged(self):
        """Test that process_input returns the input exactly as received."""
        test_inputs = [
            "Hello, World!",
            42,
            {"key": "value"},
            [1, 2, 3],
            None,
            True,
            False,
            3.14,
            b"binary data"
        ]
        
        for test_input in test_inputs:
            result = self.preprocessor.process_input(test_input)
            assert result == test_input
            assert result is test_input  # Should be the same object

    def test_process_input_with_kwargs(self):
        """Test that process_input accepts and ignores kwargs."""
        test_input = "test data"
        result = self.preprocessor.process_input(
            test_input, 
            extra_param="ignored", 
            another_param=123
        )
        assert result == test_input

    @pytest.mark.asyncio
    async def test_aprocess_input_returns_input_unchanged(self):
        """Test that aprocess_input returns the input exactly as received."""
        test_inputs = [
            "Async Hello, World!",
            100,
            {"async_key": "async_value"},
            [4, 5, 6],
            None,
            True,
            False,
            2.718,
            b"async binary data"
        ]
        
        for test_input in test_inputs:
            result = await self.preprocessor.aprocess_input(test_input)
            assert result == test_input
            assert result is test_input  # Should be the same object

    @pytest.mark.asyncio
    async def test_aprocess_input_with_kwargs(self):
        """Test that aprocess_input accepts and ignores kwargs."""
        test_input = "async test data"
        result = await self.preprocessor.aprocess_input(
            test_input, 
            async_param="ignored", 
            another_async_param=456
        )
        assert result == test_input

    def test_process_input_complex_objects(self):
        """Test process_input with complex nested objects."""
        complex_input = {
            "nested": {
                "list": [1, 2, {"inner": "value"}],
                "tuple": (1, 2, 3),
                "set": {1, 2, 3}
            },
            "function": lambda x: x + 1,
            "class": type("TestClass", (), {})
        }
        
        result = self.preprocessor.process_input(complex_input)
        assert result == complex_input
        assert result is complex_input

    @pytest.mark.asyncio
    async def test_aprocess_input_complex_objects(self):
        """Test aprocess_input with complex nested objects."""
        complex_input = {
            "async_nested": {
                "async_list": [4, 5, {"async_inner": "async_value"}],
                "async_tuple": (4, 5, 6),
                "async_set": {4, 5, 6}
            },
            "async_function": lambda x: x * 2,
            "async_class": type("AsyncTestClass", (), {})
        }
        
        result = await self.preprocessor.aprocess_input(complex_input)
        assert result == complex_input
        assert result is complex_input

    def test_process_input_empty_inputs(self):
        """Test process_input with empty inputs."""
        empty_inputs = [
            "",
            [],
            {},
            set(),
            tuple(),
            None
        ]
        
        for empty_input in empty_inputs:
            result = self.preprocessor.process_input(empty_input)
            assert result == empty_input

    @pytest.mark.asyncio
    async def test_aprocess_input_empty_inputs(self):
        """Test aprocess_input with empty inputs."""
        empty_inputs = [
            "",
            [],
            {},
            set(),
            tuple(),
            None
        ]
        
        for empty_input in empty_inputs:
            result = await self.preprocessor.aprocess_input(empty_input)
            assert result == empty_input

    def test_process_input_unicode_strings(self):
        """Test process_input with unicode strings."""
        unicode_strings = [
            "Hello, 世界!",
            "Привет, мир!",
            "こんにちは、世界！",
            "مرحبا بالعالم!",
            "🌍 Hello World 🌍"
        ]
        
        for unicode_string in unicode_strings:
            result = self.preprocessor.process_input(unicode_string)
            assert result == unicode_string

    @pytest.mark.asyncio
    async def test_aprocess_input_unicode_strings(self):
        """Test aprocess_input with unicode strings."""
        unicode_strings = [
            "Async Hello, 世界!",
            "Async Привет, мир!",
            "Async こんにちは、世界！",
            "Async مرحبا بالعالم!",
            "Async 🌍 Hello World 🌍"
        ]
        
        for unicode_string in unicode_strings:
            result = await self.preprocessor.aprocess_input(unicode_string)
            assert result == unicode_string

    def test_process_input_large_data(self):
        """Test process_input with large data structures."""
        large_list = list(range(10000))
        large_dict = {f"key_{i}": f"value_{i}" for i in range(1000)}
        
        result_list = self.preprocessor.process_input(large_list)
        result_dict = self.preprocessor.process_input(large_dict)
        
        assert result_list == large_list
        assert result_dict == large_dict

    @pytest.mark.asyncio
    async def test_aprocess_input_large_data(self):
        """Test aprocess_input with large data structures."""
        large_list = list(range(10000))
        large_dict = {f"async_key_{i}": f"async_value_{i}" for i in range(1000)}
        
        result_list = await self.preprocessor.aprocess_input(large_list)
        result_dict = await self.preprocessor.aprocess_input(large_dict)
        
        assert result_list == large_list
        assert result_dict == large_dict
