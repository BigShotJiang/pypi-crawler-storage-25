# tests/modules/memory/test_vector_faiss.py
import os
import pickle
import types
import numpy as np
import pytest
import importlib, sys, types

import fairlib.modules.memory.vector_faiss as vf_mod

class _Doc:
    def __init__(self, page_content, metadata=None):
        self.page_content = page_content
        self.metadata = metadata or {}

class _DummyEmbedder:
    def __init__(self, dim=3):
        self.dim = dim

    def _vec_for_text(self, t: str):
        # Simple deterministic embedding:
        v = np.zeros(self.dim, dtype=np.float32)
        v[0] = float(len(t))
        v[1] = float(sum(1 for c in t.lower() if c == 'a'))
        v[2] = 1.0
        return v.tolist()

    def embed_documents(self, texts):
        return [self._vec_for_text(t) for t in texts]

    def embed_query(self, text):
        return self._vec_for_text(text)


class _FakeIndexFlatIP:
    def __init__(self, d: int):
        self.d = d
        self._vecs = np.zeros((0, d), dtype=np.float32)
        self.ntotal = 0

class _FakeIndexIDMap:
    def __init__(self, base: _FakeIndexFlatIP):
        self.base = base
        self.d = base.d
        self._ids = np.array([], dtype=np.int64)

    @property
    def ntotal(self) -> int:
        return int(self._ids.size)

    def add_with_ids(self, embs: np.ndarray, ids: np.ndarray):
        assert embs.shape[1] == self.d
        if self.base._vecs.size == 0:
            self.base._vecs = embs.astype(np.float32, copy=True)
        else:
            self.base._vecs = np.vstack([self.base._vecs, embs.astype(np.float32, copy=False)])
        self._ids = np.concatenate([self._ids, ids.astype(np.int64, copy=False)])

    def search(self, q: np.ndarray, k: int):
        # inner product search
        if self.ntotal == 0:
            return np.empty((q.shape[0], 0), dtype=np.float32), np.empty((q.shape[0], 0), dtype=np.int64)
        # q: (1, d); vecs: (N, d)
        sims = self.base._vecs @ q[0].astype(np.float32)
        # top-k indices in descending order
        order = np.argsort(-sims)[:k]
        I = self._ids[order][None, :]  # shape (1, k)
        D = sims[order][None, :].astype(np.float32)
        return D, I

def _normalize_L2(arr: np.ndarray):
    # Normalize each row to unit L2 norm (in place)
    if arr.ndim == 1:
        denom = np.linalg.norm(arr) + 1e-12
        arr /= denom
        return
    norms = np.linalg.norm(arr, axis=1, keepdims=True) + 1e-12
    arr /= norms

def _write_index(index: _FakeIndexIDMap, path: str):
    payload = {
        "d": index.d,
        "ids": index._ids,
        "vecs": index.base._vecs,
    }
    with open(path, "wb") as f:
        pickle.dump(payload, f)

def _read_index(path: str) -> _FakeIndexIDMap:
    with open(path, "rb") as f:
        payload = pickle.load(f)
    base = _FakeIndexFlatIP(payload["d"])
    base._vecs = payload["vecs"]
    idx = _FakeIndexIDMap(base)
    idx._ids = payload["ids"]
    return idx

class _FakeGpuResources:
    pass

def _index_cpu_to_gpu(resources, device, index_obj):
    # Just return the same object (pretend GPU mirror)
    return index_obj


def _install_fake_faiss():
    fake = types.SimpleNamespace(
        IndexFlatIP=_FakeIndexFlatIP,
        IndexIDMap=_FakeIndexIDMap,
        normalize_L2=_normalize_L2,
        write_index=_write_index,
        read_index=_read_index,
        StandardGpuResources=_FakeGpuResources,
        index_cpu_to_gpu=_index_cpu_to_gpu,
        omp_set_num_threads=lambda n: None,
    )
    sys.modules["faiss"] = fake
    importlib.reload(vf_mod)



def _install_no_torch(monkeypatch):
    monkeypatch.setattr(vf_mod, "_TORCH_AVAILABLE", False, raising=True)


def _install_torch_cuda_available(monkeypatch, available=True):
    class _Cuda:
        @staticmethod
        def is_available():
            return available
    class _Torch:
        cuda = _Cuda()
    monkeypatch.setattr(vf_mod, "_TORCH_AVAILABLE", True, raising=True)
    monkeypatch.setattr(vf_mod, "torch", _Torch(), raising=True)


def _patch_document(monkeypatch):
    monkeypatch.setattr(vf_mod, "Document", _Doc, raising=True)


def test_importerror_when_faiss_missing(monkeypatch):
    monkeypatch.setattr(vf_mod, "_FAISS_AVAILABLE", False, raising=True)
    with pytest.raises(ImportError):
        vf_mod.FaissVectorStore(embedder=_DummyEmbedder())


def test_add_and_search_cpu_basic(tmp_path, monkeypatch):
    _install_fake_faiss()
    _install_no_torch(monkeypatch)
    _patch_document(monkeypatch)

    emb = _DummyEmbedder(dim=3)
    store = vf_mod.FaissVectorStore(embedder=emb, index_dir=str(tmp_path), use_gpu=False, normalize=True)

    docs = [
        _Doc("alpha", {"id": 1}),
        _Doc("beta", {"id": 2}),
        _Doc("aardvark", {"id": 3}),
    ]
    store.add_documents(docs)

    assert store.ntotal == 3

    hits = store.similarity_search("aard", k=2)
    # Expect "aardvark" near top because 'a' count is high + length
    assert len(hits) == 2
    assert isinstance(hits[0], _Doc)
    assert any(h.page_content == "aardvark" for h in hits)


@pytest.mark.asyncio
async def test_async_search(tmp_path, monkeypatch):
    _install_fake_faiss()
    _install_no_torch(monkeypatch)
    _patch_document(monkeypatch)

    emb = _DummyEmbedder()
    store = vf_mod.FaissVectorStore(embedder=emb, index_dir=str(tmp_path))
    store.add_documents([_Doc("alpha"), _Doc("beta")])

    hits = await store.asimilarity_search("alp", k=1)
    assert len(hits) == 1
    assert hits[0].page_content in ("alpha", "beta")


def test_search_edge_cases(tmp_path, monkeypatch):
    _install_fake_faiss()
    _install_no_torch(monkeypatch)
    _patch_document(monkeypatch)

    store = vf_mod.FaissVectorStore(embedder=_DummyEmbedder(), index_dir=str(tmp_path))
    # No index yet
    assert store.similarity_search("", k=3) == []
    assert store.similarity_search("q", k=3) == []  # index is None / ntotal==0

    # After adding, empty query still returns []
    store.add_documents([_Doc("x")])
    assert store.similarity_search("", k=3) == []


def test_dimension_mismatch_raises(tmp_path, monkeypatch):
    _install_fake_faiss()
    _install_no_torch(monkeypatch)
    _patch_document(monkeypatch)

    emb3 = _DummyEmbedder(dim=3)
    store = vf_mod.FaissVectorStore(embedder=emb3, index_dir=str(tmp_path))
    store.add_documents([_Doc("aaa")])

    # New embedder with different dim used indirectly via store._encode_documents
    class _Embedder4(_DummyEmbedder):
        def __init__(self): super().__init__(dim=4)
    store.embedder = _Embedder4()

    with pytest.raises(ValueError):
        store.add_documents([_Doc("bbbb")])


def test_persist_and_load_roundtrip(tmp_path, monkeypatch):
    _install_fake_faiss()
    _install_no_torch(monkeypatch)
    _patch_document(monkeypatch)

    emb = _DummyEmbedder()
    store = vf_mod.FaissVectorStore(embedder=emb, index_dir=str(tmp_path))
    docs = [_Doc("alpha", {"i": 1}), _Doc("beta", {"i": 2})]
    store.add_documents(docs)

    # Files should exist
    idx_path = os.path.join(str(tmp_path), "index.faiss")
    map_path = os.path.join(str(tmp_path), "mapping.pkl")
    assert os.path.exists(idx_path) and os.path.exists(map_path)

    # New instance, same dir, load
    store2 = vf_mod.FaissVectorStore(embedder=emb, index_dir=str(tmp_path))
    ok = store2.load()
    assert ok is True
    assert store2.ntotal == 2

    # Search returns Documents with correct contents
    hits = store2.similarity_search("alp", k=2)
    assert any(h.page_content == "alpha" for h in hits)
    assert any(h.metadata.get("i") == 2 for h in hits)


def test_gpu_path_when_available(tmp_path, monkeypatch):
    _install_fake_faiss()
    _install_torch_cuda_available(monkeypatch, available=True)
    _patch_document(monkeypatch)

    emb = _DummyEmbedder()
    store = vf_mod.FaissVectorStore(embedder=emb, index_dir=str(tmp_path), use_gpu=True)

    store.add_documents([_Doc("gamma"), _Doc("delta")])
    # After add, GPU mirror should be attempted and marked
    assert store.use_gpu is True
    # In our fake, we always "succeed"
    assert store.faiss_on_gpu is True

    hits = store.similarity_search("gam", k=1)
    assert len(hits) == 1


def test_gpu_not_available_disables_gpu(tmp_path, monkeypatch):
    _install_fake_faiss()
    _install_torch_cuda_available(monkeypatch, available=False)
    _patch_document(monkeypatch)

    emb = _DummyEmbedder()
    store = vf_mod.FaissVectorStore(embedder=emb, index_dir=str(tmp_path), use_gpu=True)

    store.add_documents([_Doc("x"), _Doc("y")])
    assert store.faiss_on_gpu is False
    # Search should still work via CPU
    assert store.similarity_search("x", k=1)
