# tests/modules/memory/test_retriever_rerank.py
import asyncio
import pytest

import fairlib.modules.memory.retriever_rerank as rr_mod


class _Doc:
    def __init__(self, page_content, metadata=None):
        self.page_content = page_content
        self.metadata = metadata or {}


class _FakeBaseRetriever:
    def __init__(self, docs_sync=None, docs_async=None):
        self.docs_sync = docs_sync if docs_sync is not None else []
        self.docs_async = docs_async if docs_async is not None else list(self.docs_sync)
        self.sync_calls = []
        self.async_calls = []

    def retrieve(self, query: str, top_k: int = 5, **kwargs):
        # record calls for asserts
        self.sync_calls.append({"query": query, "top_k": top_k, "kwargs": kwargs})
        return list(self.docs_sync)[:top_k]

    async def aretrieve(self, query: str, top_k: int = 5, **kwargs):
        self.async_calls.append({"query": query, "top_k": top_k, "kwargs": kwargs})
        # pretend async work
        await asyncio.sleep(0)
        return list(self.docs_async)[:top_k]


class _FakeCrossEncoder:
    def __init__(self, scores):
        self.scores = scores
        self.calls = []

    def predict(self, pairs):
        self.calls.append(list(pairs))
        return list(self.scores[:len(pairs)])


def test_sync_rerank_basic(monkeypatch):
    monkeypatch.setattr(rr_mod, "Document", _Doc, raising=True)

    base_docs = [_Doc("d0"), _Doc("d1"), _Doc("d2")]
    base = _FakeBaseRetriever(docs_sync=base_docs)
    # scores for d0, d1, d2 -> best is d1, then d2, then d0
    ce = _FakeCrossEncoder(scores=[0.1, 0.9, 0.5])

    retr = rr_mod.CrossEncoderRerankingRetriever(base=base, cross_encoder=ce, rerank_k=10)

    out = retr.retrieve("q", top_k=2)
    assert [d.page_content for d in out] == ["d1", "d2"]
    # base was called once with rerank_k (10), not with requested top_k (2)
    assert base.sync_calls[0]["top_k"] == 10
    # cross-encoder saw 3 pairs with the original query and doc contents
    assert ce.calls and len(ce.calls[0]) == 3
    assert ce.calls[0][0] == ("q", "d0")


def test_sync_empty_candidates(monkeypatch):
    monkeypatch.setattr(rr_mod, "Document", _Doc, raising=True)
    base = _FakeBaseRetriever(docs_sync=[])
    ce = _FakeCrossEncoder(scores=[])
    retr = rr_mod.CrossEncoderRerankingRetriever(base, ce, rerank_k=5)

    out = retr.retrieve("q", top_k=3)
    assert out == []  # no candidates -> no results
    assert ce.calls == []  # predict not called


def test_sync_respects_rerank_k_and_kwargs(monkeypatch):
    monkeypatch.setattr(rr_mod, "Document", _Doc, raising=True)
    base_docs = [_Doc("a"), _Doc("b"), _Doc("c")]
    base = _FakeBaseRetriever(docs_sync=base_docs)
    ce = _FakeCrossEncoder(scores=[0.2, 0.3])  # only 2 will be considered due to rerank_k
    retr = rr_mod.CrossEncoderRerankingRetriever(base, ce, rerank_k=2)

    out = retr.retrieve("query", top_k=5, foo=123)
    # The base should have been asked for only rerank_k=2 docs
    assert base.sync_calls[0]["top_k"] == 2
    assert base.sync_calls[0]["kwargs"]["foo"] == 123
    # We ranked only 2 docs, so at most 2 returned
    assert len(out) == 2
    assert [d.page_content for d in out] in (["b", "a"], ["a", "b"])  # based on scores


def test_sync_topk_more_than_candidates(monkeypatch):
    monkeypatch.setattr(rr_mod, "Document", _Doc, raising=True)
    base_docs = [_Doc("x"), _Doc("y"), _Doc("z")]
    base = _FakeBaseRetriever(docs_sync=base_docs)
    ce = _FakeCrossEncoder(scores=[0.3, 0.1, 0.2])
    retr = rr_mod.CrossEncoderRerankingRetriever(base, ce, rerank_k=10)

    # Ask for more than available
    out = retr.retrieve("q", top_k=10)
    assert len(out) == 3
    # order by scores desc: x (0.3), z (0.2), y (0.1)
    assert [d.page_content for d in out] == ["x", "z", "y"]


@pytest.mark.asyncio
async def test_async_rerank_basic(monkeypatch):
    monkeypatch.setattr(rr_mod, "Document", _Doc, raising=True)

    base_docs = [_Doc("p"), _Doc("q"), _Doc("r")]
    base = _FakeBaseRetriever(docs_async=base_docs)
    ce = _FakeCrossEncoder(scores=[0.0, 2.0, 1.0])

    retr = rr_mod.CrossEncoderRerankingRetriever(base=base, cross_encoder=ce, rerank_k=5)
    out = await retr.aretrieve("query-async", top_k=2)

    # Should re-order by CE scores: q (2.0), r (1.0)
    assert [d.page_content for d in out] == ["q", "r"]
    # Base aretrieve used rerank_k
    assert base.async_calls[0]["top_k"] == 5
    # CE predict called via to_thread; pairs recorded
    assert ce.calls and ce.calls[0][1] == ("query-async", "q")


@pytest.mark.asyncio
async def test_async_empty_candidates(monkeypatch):
    monkeypatch.setattr(rr_mod, "Document", _Doc, raising=True)

    base = _FakeBaseRetriever(docs_async=[])
    ce = _FakeCrossEncoder(scores=[])
    retr = rr_mod.CrossEncoderRerankingRetriever(base, ce, rerank_k=3)

    out = await retr.aretrieve("q", top_k=2)
    assert out == []
    assert ce.calls == []
