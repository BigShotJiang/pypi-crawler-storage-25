# tests/modules/memory/test_retriever.py
import pytest

import fairlib.modules.memory.retriever as retriever_mod


class _FakeVectorStore:
    """
    Minimal fake for AbstractVectorStore that captures how it's called.
    - similarity_search(query, k, **kwargs) returns k docs out of a fixed pool
    - asimilarity_search(...) is the async counterpart
    """
    def __init__(self):
        self.pool = [f"DOC_{i}" for i in range(10)]
        self.last_sync = {"query": None, "k": None, "kwargs": None}
        self.last_async = {"query": None, "k": None, "kwargs": None}

    def similarity_search(self, query, k, **kwargs):
        self.last_sync = {"query": query, "k": k, "kwargs": kwargs}
        return self.pool[:k]

    async def asimilarity_search(self, query, k, **kwargs):
        self.last_async = {"query": query, "k": k, "kwargs": kwargs}
        return self.pool[:k]


def test_simple_retriever_initializes_with_vector_store():
    vs = _FakeVectorStore()
    r = retriever_mod.SimpleRetriever(vs)
    assert r.vector_store is vs


def test_retrieve_uses_vector_store_and_respects_top_k():
    vs = _FakeVectorStore()
    r = retriever_mod.SimpleRetriever(vs)

    out = r.retrieve("hello world", top_k=3)

    assert out == ["DOC_0", "DOC_1", "DOC_2"]
    assert vs.last_sync["query"] == "hello world"
    assert vs.last_sync["k"] == 3
    assert vs.last_sync["kwargs"] == {}


def test_retrieve_default_top_k_is_2():
    vs = _FakeVectorStore()
    r = retriever_mod.SimpleRetriever(vs)

    out = r.retrieve("q")  # no top_k provided

    assert len(out) == 2
    assert out == ["DOC_0", "DOC_1"]
    assert vs.last_sync["k"] == 2


def test_retrieve_ignores_extra_kwargs():
    vs = _FakeVectorStore()
    r = retriever_mod.SimpleRetriever(vs)

    out = r.retrieve("q", top_k=2, some_flag=True, threshold=0.7)

    assert out == ["DOC_0", "DOC_1"]
    # Ensure kwargs were NOT forwarded by the retriever (current contract)
    assert vs.last_sync["kwargs"] == {}


@pytest.mark.asyncio
async def test_aretrieve_uses_vector_store_async_and_respects_top_k():
    vs = _FakeVectorStore()
    r = retriever_mod.SimpleRetriever(vs)

    out = await r.aretrieve("async hello", top_k=4)

    assert out == ["DOC_0", "DOC_1", "DOC_2", "DOC_3"]
    assert vs.last_async["query"] == "async hello"
    assert vs.last_async["k"] == 4
    assert vs.last_async["kwargs"] == {}


@pytest.mark.asyncio
async def test_aretrieve_ignores_extra_kwargs():
    vs = _FakeVectorStore()
    r = retriever_mod.SimpleRetriever(vs)

    out = await r.aretrieve("q", top_k=1, unused="x")

    assert out == ["DOC_0"]
    assert vs.last_async["kwargs"] == {}


def test_retrieve_allows_top_k_zero():
    vs = _FakeVectorStore()
    r = retriever_mod.SimpleRetriever(vs)

    out = r.retrieve("q", top_k=0)

    assert out == []
    assert vs.last_sync["k"] == 0
