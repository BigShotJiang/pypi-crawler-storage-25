# tests/modules/memory/test_base.py
import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch

from fairlib.modules.memory.base import WorkingMemory, LongTermMemory

from fairlib.core.message import Message

from fairlib.core.interfaces.memory import AbstractVectorStore


@pytest.fixture
def mock_components():
    """A pytest fixture to create all the mocks needed for the agent."""
    return {
        "vector_store": MagicMock(spec=AbstractVectorStore)
    }

def test_WorkingMemory():
    """
    A test for the functions of working memory
    """

    memory = WorkingMemory(max_size=3) #Limit history size
    
    test_system_message = Message(role="system", content="you are an expert proofreader, you must proofread this document for clarity and diction.")
    test_user_message = Message(role="user", content="Examine this sentence for clarity: 'The quick brown fox jumps over the lazy dog'")
    test_assistant_message = Message(role="assistant", content="No clarity issues were found with this sentence.")
    

    memory.add_message(test_system_message)
    memory.add_message(test_user_message)
    memory.add_message(test_assistant_message)

    assert memory.get_history() == [test_system_message, test_user_message, test_assistant_message] #ensure messages are stored properly
    
    memory.add_message(test_user_message)

    assert len(memory.get_history()) == 3 #Ensure history trimming works

    memory.clear()

    assert len(memory.get_history()) == 0 #ensure history clears

class MockVectorStore(AbstractVectorStore):
    def __init__(self):
        self.documents = []
    def similarity_search(self,query, k):
        return self.documents[0:k]
    def add_documents(self, content, metadata):
        self.documents.extend(content)


def test_LongTermMemory(mock_components):
    memory = LongTermMemory(MockVectorStore())

    #test three cases of add document
    memory.add_document("this is a string")
    memory.add_document(["this is one string in a list"])
    memory.add_document(["this is a string in a list", "this is a second string in a list"])
    
    assert len(memory.retrieve_relevant_chunks("test",  top_k=2)) == 2
    
    

    
