# tests/modules/memory/test_embedder.py
import asyncio
import pytest
import numpy as np

import fairlib.modules.memory.embedder as embedder_mod
import fairlib.modules.memory.retriever as retriever_mod


def test_dummy_embedder_embed_documents_basic():
    e = embedder_mod.DummyEmbedder()
    texts = ["a", "b", "c"]
    out = e.embed_documents(texts)
    assert isinstance(out, list)
    assert len(out) == 3
    assert all(len(vec) == 10 for vec in out)
    assert all(all(v == 1.0 for v in vec) for vec in out)


def test_dummy_embedder_embed_documents_empty():
    e = embedder_mod.DummyEmbedder()
    out = e.embed_documents([])
    assert out == []


def test_dummy_embedder_embed_query_basic():
    e = embedder_mod.DummyEmbedder()
    out = e.embed_query("hello")
    assert isinstance(out, list)
    assert len(out) == 10
    assert all(v == 1.0 for v in out)


@pytest.mark.asyncio
async def test_dummy_embedder_async_methods_match_sync():
    e = embedder_mod.DummyEmbedder()
    texts = ["x", "y"]
    sync_docs = e.embed_documents(texts)
    sync_query = e.embed_query("q")
    async_docs = await e.aembed_documents(texts)
    async_query = await e.aembed_query("q")
    assert async_docs == sync_docs
    assert async_query == sync_query


def test_sentence_transformer_embedder_import_error_when_missing(monkeypatch):
    monkeypatch.setattr(embedder_mod, "SENTENCE_TRANSFORMERS_AVAILABLE", False, raising=True)
    with pytest.raises(ImportError) as exc:
        embedder_mod.SentenceTransformerEmbedder()
    assert "sentence-transformers" in str(exc.value)


class _FakeSentenceTransformer:
    """
    Lightweight fake that mimics the real API:
    - .encode(list[str]) -> np.ndarray (2D)
    - .encode(str)       -> np.ndarray (1D)

    Created so we dont have to invoke model from scentence transformers.
    """
    def __init__(self, model_name):
        self.model_name = model_name
        self.calls = []

    def encode(self, x):
        self.calls.append(x)
        if isinstance(x, list):
            return np.array([[float(i)] for i, _ in enumerate(x)], dtype=float)
        else:
            return np.array([42.0], dtype=float)


def _install_fake_sentence_transformer(monkeypatch):
    monkeypatch.setattr(embedder_mod, "SENTENCE_TRANSFORMERS_AVAILABLE", True, raising=True)
    monkeypatch.setattr(embedder_mod, "SentenceTransformer", _FakeSentenceTransformer, raising=True)


def test_sentence_transformer_embedder_documents(monkeypatch):
    _install_fake_sentence_transformer(monkeypatch)
    e = embedder_mod.SentenceTransformerEmbedder(model_name="all-MiniLM-L6-v2")
    texts = ["doc1", "doc2", "doc3"]
    out = e.embed_documents(texts)

    assert out == [[0.0], [1.0], [2.0]]
    assert isinstance(e.model, _FakeSentenceTransformer)
    assert e.model.calls[-1] == texts


def test_sentence_transformer_embedder_query(monkeypatch):
    _install_fake_sentence_transformer(monkeypatch)
    e = embedder_mod.SentenceTransformerEmbedder(model_name="all-MiniLM-L6-v2")
    out = e.embed_query("hello world!")
    assert out == [42.0]
    assert e.model.calls[-1] == "hello world!"


@pytest.mark.asyncio
async def test_sentence_transformer_embedder_async(monkeypatch):
    _install_fake_sentence_transformer(monkeypatch)
    e = embedder_mod.SentenceTransformerEmbedder()
    docs = await e.aembed_documents(["A", "B"])
    q = await e.aembed_query("C")
    assert docs == [[0.0], [1.0]]
    assert q == [42.0]


def test_retrieve_with_inmemory_vector_store():
    from fairlib.modules.memory.vector_store import InMemoryVectorStore
    vs = InMemoryVectorStore()
    # Add some docs; InMemoryVectorStore ignores query and returns first k docs
    vs.add_documents(["D0", "D1", "D2", "D3"])
    r = retriever_mod.SimpleRetriever(vs)

    out3 = r.retrieve("any query", top_k=3)
    out_default = r.retrieve("whatever")  # default top_k=2

    assert out3 == ["D0", "D1", "D2"]
    assert out_default == ["D0", "D1"]

