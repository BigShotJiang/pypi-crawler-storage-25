# tests/modules/memory/test_vector_store.py
import types
import builtins
import pytest

import fairlib.modules.memory.vector_store as vs_mod


class _FakeEmbedder:
    def embed_documents(self, documents):
        # embeddings: [[0.0], [1.0], ...]
        return [[float(i)] for i, _ in enumerate(documents)]

    def embed_query(self, query):
        return [99.0]


class _FakeCollection:
    def __init__(self):
        self.add_calls = []
        self.query_calls = []

    def add(self, *, embeddings, documents, metadatas, ids):
        self.add_calls.append(
            dict(embeddings=embeddings, documents=documents, metadatas=metadatas, ids=ids)
        )

    def query(self, *, query_embeddings, n_results):
        self.query_calls.append(dict(query_embeddings=query_embeddings, n_results=n_results))
        # Return documents shaped like Chroma's typical structure
        # (list-of-lists, one list per query; we only do single query)
        pool = [f"D{i}" for i in range(10)]
        return {"documents": [pool[:n_results]]}


class _FakeClient:
    def __init__(self):
        self.collections = {}

    def get_or_create_collection(self, name: str):
        if name not in self.collections:
            self.collections[name] = _FakeCollection()
        return self.collections[name]


def test_inmemory_add_and_similarity_basic():
    store = vs_mod.InMemoryVectorStore()
    docs = ["A", "B", "C", "D"]
    store.add_documents(docs)

    # all docs present in insertion order via values()
    out2 = store.similarity_search("ignored", k=2)
    out10 = store.similarity_search("ignored", k=10)

    assert out2 == ["A", "B"]
    assert out10 == ["A", "B", "C", "D"]

    # internal mappings created
    assert len(store.documents) == 4
    assert len(store.vectors) == 4
    # keys match across maps
    assert set(store.documents.keys()) == set(store.vectors.keys())


def test_inmemory_similarity_empty_store():
    store = vs_mod.InMemoryVectorStore()
    assert store.similarity_search("anything", k=3) == []


def test_inmemory_similarity_k_zero():
    store = vs_mod.InMemoryVectorStore()
    store.add_documents(["X", "Y"])
    assert store.similarity_search("ignored", k=0) == []


def test_chromadb_import_error(monkeypatch):
    """
    Force ImportError when the class tries to `import chromadb` in __init__.
    """
    real_import = builtins.__import__

    def _fake_import(name, *args, **kwargs):
        if name == "chromadb":
            raise ImportError("no chromadb here")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", _fake_import)
    with pytest.raises(ImportError):
        vs_mod.ChromaDBVectorStore(embedder=_FakeEmbedder(), client=_FakeClient())


def _install_fake_chromadb(monkeypatch):
    """
    Install a minimal 'chromadb' module in sys.modules so the guarded import succeeds.
    We don't need real functionality because we hand our own client into the ctor.
    """
    fake_chromadb = types.ModuleType("chromadb")
    monkeypatch.setitem(__import__("sys").modules, "chromadb", fake_chromadb)


def test_chromadb_add_documents_auto_metadata_and_embeddings(monkeypatch):
    _install_fake_chromadb(monkeypatch)

    embedder = _FakeEmbedder()
    client = _FakeClient()
    store = vs_mod.ChromaDBVectorStore(embedder=embedder, client=client, collection_name="col")

    docs = ["alpha", "beta", "gamma"]
    store.add_documents(docs)

    col = client.collections["col"]
    assert len(col.add_calls) == 1
    call = col.add_calls[0]

    # embeddings and docs aligned
    assert call["documents"] == docs
    assert call["embeddings"] == [[0.0], [1.0], [2.0]]
    # ids present and count matches
    assert len(call["ids"]) == 3
    # metadatas auto-generated with length == len(docs)
    assert call["metadatas"] == [{"source": "chunk_0"}, {"source": "chunk_1"}, {"source": "chunk_2"}]


def test_chromadb_add_documents_noop_on_empty(monkeypatch):
    _install_fake_chromadb(monkeypatch)

    embedder = _FakeEmbedder()
    client = _FakeClient()
    store = vs_mod.ChromaDBVectorStore(embedder=embedder, client=client)

    # Should not call collection.add at all
    store.add_documents([])
    # no collections accessed? ctor still creates one by name; check no add
    col = client.collections["fair_llm_collection"]
    assert col.add_calls == []


def test_chromadb_similarity_search_basic(monkeypatch):
    _install_fake_chromadb(monkeypatch)

    embedder = _FakeEmbedder()
    client = _FakeClient()
    store = vs_mod.ChromaDBVectorStore(embedder=embedder, client=client, collection_name="c1")

    out = store.similarity_search("search", k=4)
    assert out == ["D0", "D1", "D2", "D3"]

    col = client.collections["c1"]
    # query called once with our embedder's embedding and requested k
    assert len(col.query_calls) == 1
    qc = col.query_calls[0]
    assert qc["query_embeddings"] == [[99.0]]  # list-of-one embedding
    assert qc["n_results"] == 4


def test_chromadb_similarity_search_empty_query(monkeypatch):
    _install_fake_chromadb(monkeypatch)

    store = vs_mod.ChromaDBVectorStore(embedder=_FakeEmbedder(), client=_FakeClient())
    assert store.similarity_search("", k=5) == []  # early-return branch


def test_chromadb_similarity_search_handles_empty_results(monkeypatch):
    _install_fake_chromadb(monkeypatch)

    class _EmptyResultCollection(_FakeCollection):
        def query(self, *, query_embeddings, n_results):
            self.query_calls.append(dict(query_embeddings=query_embeddings, n_results=n_results))
            return {"documents": []}  # no per-query list

    class _ClientWithEmpty(_FakeClient):
        def get_or_create_collection(self, name: str):
            self.collections[name] = _EmptyResultCollection()
            return self.collections[name]

    store = vs_mod.ChromaDBVectorStore(embedder=_FakeEmbedder(), client=_ClientWithEmpty())
    assert store.similarity_search("anything", k=3) == []
