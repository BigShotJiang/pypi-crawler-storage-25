# tests/modules/memory/test_summarization.py
import logging

import pytest

import fairlib.modules.memory.summarization as summ_mod
from fairlib.core.errors import AdapterError
from fairlib.core.events import MemorySummarizedEvent
from fairlib.core.message import Message


class _FakeLLM:
    """
    Minimal async chat model double:
    - captures the last prompt (list[Message])
    - returns a Message with predictable content
    """
    def __init__(self, response_text="This is a concise summary."):
        self.response_text = response_text
        self.calls = 0
        self.last_prompt = None

    async def ainvoke(self, prompt):
        self.calls += 1
        self.last_prompt = prompt
        return Message(role="assistant", content=self.response_text)


def _mk_msgs(n_user_assistant_pairs=6):
    """
    Create a conversation with a leading system message + alternating user/assistant.
    Total length = 1 + 2 * n_user_assistant_pairs
    """
    msgs = [Message(role="system", content="Starting user/assistant message turns.")]
    for i in range(n_user_assistant_pairs):
        msgs.append(Message(role="user", content=f"U{i+1}"))
        msgs.append(Message(role="assistant", content=f"A{i+1}"))
    return msgs


def test_init_validation_error():
    fake_llm = _FakeLLM()
    with pytest.raises(ValueError):
        summ_mod.SummarizingMemory(fake_llm, max_history_length=5, messages_to_keep_at_end=5)
    with pytest.raises(ValueError):
        summ_mod.SummarizingMemory(fake_llm, max_history_length=5, messages_to_keep_at_end=6)


def test_add_and_clear():
    mem = summ_mod.SummarizingMemory(_FakeLLM(), max_history_length=10, messages_to_keep_at_end=4)
    m1 = Message(role="user", content="hi")
    m2 = Message(role="assistant", content="hello")
    mem.add_message(m1)
    mem.add_message(m2)
    assert mem.get_history() == [m1, m2]  # under limit, returns history as-is
    mem.clear()
    assert mem.get_history() == []


def test_get_history_under_limit_sync_does_not_summarize():
    fake_llm = _FakeLLM()
    mem = summ_mod.SummarizingMemory(fake_llm, max_history_length=10, messages_to_keep_at_end=4)
    msgs = _mk_msgs(n_user_assistant_pairs=3)  # total 7 messages (< 10)
    for m in msgs:
        mem.add_message(m)

    out = mem.get_history()
    assert out == msgs  # exact same list contents
    assert fake_llm.calls == 0  # sync path under limit should not call LLM


#TODO:: refactor when sync is fully implemented!
def test_get_history_over_limit_sync_returns_placeholder_and_does_not_mutate_internal_history(caplog):
    fake_llm = _FakeLLM()
    mem = summ_mod.SummarizingMemory(fake_llm, max_history_length=6, messages_to_keep_at_end=2)

    msgs = _mk_msgs(n_user_assistant_pairs=4)  # total 9 messages (> 6)
    for m in msgs:
        mem.add_message(m)

    with caplog.at_level(logging.WARNING):
        out = mem.get_history()

    assert len(out) == 1 + 1 + 2
    assert out[0] is msgs[0]
    assert out[1].role == "system" and out[1].content == "...summary..."
    assert out[-2:] == msgs[-2:]  # last N intact

    # Internal history is NOT mutated by sync get_history()
    assert len(mem.history) == len(msgs) == 9

    # Verify the warning was routed through the logging subsystem (not print)
    assert any("sync mode is not fully implemented" in r.getMessage()
               for r in caplog.records)


@pytest.mark.asyncio
async def test_aget_history_under_limit_async_does_not_call_llm():
    fake_llm = _FakeLLM()
    mem = summ_mod.SummarizingMemory(fake_llm, max_history_length=8, messages_to_keep_at_end=3)

    msgs = _mk_msgs(n_user_assistant_pairs=3)  # 7 total
    for m in msgs:
        mem.add_message(m)

    out = await mem.aget_history()
    assert out == msgs
    assert fake_llm.calls == 0


@pytest.mark.asyncio
async def test_aget_history_over_limit_summarizes_and_formats_correctly():
    fake_llm = _FakeLLM(response_text="Summary of middle turns.")
    mem = summ_mod.SummarizingMemory(fake_llm, max_history_length=6, messages_to_keep_at_end=2)
    msgs = _mk_msgs(n_user_assistant_pairs=4)  # total 9
    for m in msgs:
        mem.add_message(m)

    out = await mem.aget_history()

    # 1) First message preserved
    assert out[0] is msgs[0]
    # 2) Middle is summary system message with wrapper text
    summary_msg = out[1]
    assert summary_msg.role == "system"
    assert summary_msg.content.startswith("--- Start of Summarized Conversation ---")
    assert "Summary of middle turns." in summary_msg.content
    assert summary_msg.content.endswith("--- End of Summarized Conversation ---")
    # 3) Tail preserves the last 'messages_to_keep_at_end' messages verbatim
    assert out[-2:] == msgs[-2:]
    # 4) Length equals 1 (head) + 1 (summary) + keep_end
    assert len(out) == 1 + 1 + mem.messages_to_keep_at_end

    # The LLM should have been called exactly once with a 2-message prompt:
    #   system instruction + user block of joined messages-to-summarize
    assert fake_llm.calls == 1
    assert len(fake_llm.last_prompt) == 2
    assert fake_llm.last_prompt[0].role == "system"
    assert "concise summary" in fake_llm.last_prompt[0].content.lower()
    # The user content is the joined middle section
    user_block = fake_llm.last_prompt[1].content
    # Verify that some middle messages appear in the prompt
    assert "user: U1" in user_block and "assistant: A1" in user_block
    assert "user: U3" in user_block and "assistant: A3" in user_block

    # Internal history MUST be updated to the summarized structure
    assert mem.history == out


@pytest.mark.asyncio
async def test_aget_history_second_call_does_not_resummarize_if_within_limit():
    fake_llm = _FakeLLM()
    mem = summ_mod.SummarizingMemory(fake_llm, max_history_length=6, messages_to_keep_at_end=2)

    msgs = _mk_msgs(n_user_assistant_pairs=4)  # 9 total (will summarize once)
    for m in msgs:
        mem.add_message(m)

    out1 = await mem.aget_history()
    # After summarization, history length is 1 + 1 + keep_end = 4, now under limit
    assert len(out1) == 1 + 1 + mem.messages_to_keep_at_end
    calls_after_first = fake_llm.calls

    # Call again without adding new messages → should NOT summarize again
    out2 = await mem.aget_history()
    assert out2 == out1
    assert fake_llm.calls == calls_after_first  # no new calls


# =================================================================
# Phase C tests — Memory pinning + MemorySummarizedEvent
# =================================================================


class _RaisingLLM:
    """Async chat model double that raises AdapterError on ainvoke.

    Used to drive Phase D recovery paths.
    """

    def __init__(self, provider="fake"):
        self.provider = provider
        self.calls = 0

    async def ainvoke(self, prompt):
        self.calls += 1
        raise AdapterError(
            "simulated provider failure",
            provider=self.provider,
            raw_output=None,
        )


def _pin(content):
    """Convenience constructor for a pinned user message."""
    return Message(role="user", content=content, importance="pinned")


def _norm(content, role="user"):
    """Convenience constructor for a normal-importance message."""
    return Message(role=role, content=content)


class TestSummarizingMemoryPinningAsync:
    """C1, C3: pinned messages survive summarization verbatim and do not
    leak into the LLM summarization input.
    """

    @pytest.mark.asyncio
    async def test_c1_pinned_message_preserved_in_returned_history(self):
        fake_llm = _FakeLLM(response_text="Summary of normal turns.")
        mem = summ_mod.SummarizingMemory(
            fake_llm, max_history_length=6, messages_to_keep_at_end=2
        )
        # Layout: [system, U1, A1(pinned), U2, A2, U3, A3, U4, A4]
        msgs = [
            _norm("system instruction", role="system"),
            _norm("U1"),
            Message(role="assistant", content="A1-PINNED", importance="pinned"),
            _norm("U2"),
            _norm("A2", role="assistant"),
            _norm("U3"),
            _norm("A3", role="assistant"),
            _norm("U4"),
            _norm("A4", role="assistant"),
        ]
        for m in msgs:
            mem.add_message(m)

        out = await mem.aget_history()

        pinned_in_out = [m for m in out if m.importance == "pinned"]
        assert len(pinned_in_out) == 1
        assert pinned_in_out[0].content == "A1-PINNED"

    @pytest.mark.asyncio
    async def test_c3_pinned_messages_not_in_llm_summarization_prompt(self):
        fake_llm = _FakeLLM(response_text="Summary.")
        mem = summ_mod.SummarizingMemory(
            fake_llm, max_history_length=6, messages_to_keep_at_end=2
        )
        msgs = [
            _norm("system", role="system"),
            _norm("U1"),
            Message(role="assistant", content="PINNED-SHOULD-NOT-LEAK", importance="pinned"),
            _norm("U2"),
            _norm("A2", role="assistant"),
            _norm("U3"),
            _norm("A3", role="assistant"),
            _norm("U4"),
            _norm("A4", role="assistant"),
        ]
        for m in msgs:
            mem.add_message(m)

        await mem.aget_history()

        # The user-content block of the summarization prompt is fake_llm.last_prompt[1].content
        user_block = fake_llm.last_prompt[1].content
        assert "PINNED-SHOULD-NOT-LEAK" not in user_block

    @pytest.mark.asyncio
    async def test_pinned_messages_preserve_relative_order(self):
        """Multiple pinned messages keep their original relative order in the
        reconstructed history.
        """
        fake_llm = _FakeLLM()
        mem = summ_mod.SummarizingMemory(
            fake_llm, max_history_length=6, messages_to_keep_at_end=2
        )
        msgs = [
            _norm("system", role="system"),
            _norm("U1"),
            Message(role="user", content="P-FIRST", importance="pinned"),
            _norm("A1", role="assistant"),
            Message(role="user", content="P-SECOND", importance="pinned"),
            _norm("U2"),
            _norm("A2", role="assistant"),
            _norm("U3"),
            _norm("A3", role="assistant"),
        ]
        for m in msgs:
            mem.add_message(m)

        out = await mem.aget_history()

        pinned_contents = [m.content for m in out if m.importance == "pinned"]
        assert pinned_contents == ["P-FIRST", "P-SECOND"]

    @pytest.mark.asyncio
    async def test_pinned_message_keeps_importance_field_in_returned_history(self):
        fake_llm = _FakeLLM()
        mem = summ_mod.SummarizingMemory(
            fake_llm, max_history_length=6, messages_to_keep_at_end=2
        )
        msgs = [
            _norm("system", role="system"),
            _norm("U1"),
            Message(role="assistant", content="ANSWER", importance="pinned"),
            _norm("U2"),
            _norm("A2", role="assistant"),
            _norm("U3"),
            _norm("A3", role="assistant"),
            _norm("U4"),
            _norm("A4", role="assistant"),
        ]
        for m in msgs:
            mem.add_message(m)

        out = await mem.aget_history()

        # Find the pinned-in-out and assert importance is still "pinned"
        survivor = next(m for m in out if m.content == "ANSWER")
        assert survivor.importance == "pinned"

    @pytest.mark.asyncio
    async def test_all_middle_pinned_returns_verbatim_and_no_event_fires(self):
        """Closes the coverage gap on the all-pinned-middle branch. When every
        message in the summarizable slice is pinned, the framework returns the
        verbatim history (never silently drops pinned content) and does NOT
        fire the summarization event because no summarization actually
        occurred.
        """
        fake_llm = _FakeLLM()
        events = []
        mem = summ_mod.SummarizingMemory(
            fake_llm,
            max_history_length=4,
            messages_to_keep_at_end=2,
            on_summarize=events.append,
        )
        # Layout: [first] + 4 pinned middle + 2 last_n. Total 7 > max_history_length=4.
        msgs = [
            Message(role="system", content="first"),
            Message(role="user", content="P1", importance="pinned"),
            Message(role="user", content="P2", importance="pinned"),
            Message(role="user", content="P3", importance="pinned"),
            Message(role="user", content="P4", importance="pinned"),
            Message(role="user", content="last1"),
            Message(role="assistant", content="last2"),
        ]
        for m in msgs:
            mem.add_message(m)

        out = await mem.aget_history()

        # Verbatim history returned: no compression occurred
        assert out == msgs
        # Internal history unchanged
        assert mem.history == msgs
        # No LLM call was made
        assert fake_llm.calls == 0
        # No summarization event fired (no summarization occurred)
        assert events == []

    @pytest.mark.asyncio
    async def test_messages_to_keep_at_end_zero_does_not_duplicate_first(self):
        """Guards against the Python footgun where history[-0:] returns the
        full list, not empty. A messages_to_keep_at_end=0 configuration must
        produce a clean reconstruction without duplicating the first message.
        """
        fake_llm = _FakeLLM(response_text="Summary of all middle.")
        mem = summ_mod.SummarizingMemory(
            fake_llm, max_history_length=4, messages_to_keep_at_end=0
        )
        msgs = [
            Message(role="system", content="FIRST"),
            Message(role="user", content="m1"),
            Message(role="assistant", content="m2"),
            Message(role="user", content="m3"),
            Message(role="assistant", content="m4"),
            Message(role="user", content="m5"),
        ]
        for m in msgs:
            mem.add_message(m)

        out = await mem.aget_history()

        # Reconstruction is [first] + [summary] only when keep_at_end=0
        assert len(out) == 2
        assert out[0] is msgs[0]
        assert out[0].content == "FIRST"
        # First message must appear exactly once, not duplicated
        assert sum(1 for m in out if m.content == "FIRST") == 1
        # Summary is the second and last entry
        assert out[1].role == "system"
        assert "Summary of all middle." in out[1].content


class TestSummarizingMemoryOnSummarizeCallback:
    """C2, C4: on_summarize fires exactly once per summarization with a
    correctly populated payload. Does not fire when history is short.
    """

    @pytest.mark.asyncio
    async def test_c2_callback_fires_once_with_correct_payload(self):
        fake_llm = _FakeLLM(response_text="Summary content.")
        events = []
        mem = summ_mod.SummarizingMemory(
            fake_llm,
            max_history_length=6,
            messages_to_keep_at_end=2,
            on_summarize=events.append,
        )
        msgs = [
            _norm("system", role="system"),
            _norm("U1"),
            Message(role="assistant", content="A1-PINNED", importance="pinned"),
            _norm("U2"),
            _norm("A2", role="assistant"),
            _norm("U3"),
            _norm("A3", role="assistant"),
            _norm("U4"),
            _norm("A4", role="assistant"),
        ]
        for m in msgs:
            mem.add_message(m)

        await mem.aget_history()

        assert len(events) == 1
        event = events[0]
        assert isinstance(event, MemorySummarizedEvent)
        # dropped excludes the pinned message
        dropped_contents = [m.content for m in event.dropped]
        assert "A1-PINNED" not in dropped_contents
        # kept includes the pinned message
        kept_contents = [m.content for m in event.kept]
        assert "A1-PINNED" in kept_contents
        # summary is a Message with the LLM's response wrapped
        assert event.summary.role == "system"
        assert "Summary content." in event.summary.content
        # default reason
        assert event.reason == "max_history_length_exceeded"

    @pytest.mark.asyncio
    async def test_c4_callback_does_not_fire_when_history_under_limit(self):
        fake_llm = _FakeLLM()
        events = []
        mem = summ_mod.SummarizingMemory(
            fake_llm,
            max_history_length=10,
            messages_to_keep_at_end=4,
            on_summarize=events.append,
        )
        msgs = _mk_msgs(n_user_assistant_pairs=3)  # 7 total < 10
        for m in msgs:
            mem.add_message(m)

        await mem.aget_history()

        assert events == []
        assert fake_llm.calls == 0

    @pytest.mark.asyncio
    async def test_callback_is_optional(self):
        """on_summarize defaults to None and aget_history runs without it."""
        fake_llm = _FakeLLM()
        mem = summ_mod.SummarizingMemory(
            fake_llm, max_history_length=6, messages_to_keep_at_end=2
        )
        # Constructor must accept absence of on_summarize (already the default)
        assert mem.on_summarize is None

        msgs = _mk_msgs(n_user_assistant_pairs=4)  # 9 total > 6
        for m in msgs:
            mem.add_message(m)
        out = await mem.aget_history()
        # No exception, summarization happens normally
        assert len(out) == 1 + 1 + mem.messages_to_keep_at_end

    @pytest.mark.asyncio
    async def test_callback_exception_does_not_break_aget_history(self, caplog):
        """A bad subscriber must not take down the agent. The framework logs
        at WARNING (with exc_info) and continues.
        """
        fake_llm = _FakeLLM()

        def bad_subscriber(event):
            raise RuntimeError("subscriber explosion")

        mem = summ_mod.SummarizingMemory(
            fake_llm,
            max_history_length=6,
            messages_to_keep_at_end=2,
            on_summarize=bad_subscriber,
        )
        msgs = _mk_msgs(n_user_assistant_pairs=4)
        for m in msgs:
            mem.add_message(m)

        # Must not raise
        with caplog.at_level(logging.WARNING):
            out = await mem.aget_history()

        assert len(out) == 1 + 1 + mem.messages_to_keep_at_end
        # Some log record should reference the subscriber failure with exc_info
        relevant = [
            r for r in caplog.records
            if "on_summarize" in r.getMessage() or "subscriber" in r.getMessage().lower()
        ]
        assert relevant, "subscriber failure was not logged"
        assert any(r.exc_info is not None for r in relevant), "traceback was not captured"

    @pytest.mark.asyncio
    async def test_subscriber_mutation_does_not_corrupt_history(self):
        """Subscriber-isolation guarantee: a subscriber that mutates any field
        of any Message in event.kept or event.summary must NOT affect what
        the framework holds in self.history. Closes the subscriber-isolation
        gap on the success path; companion test below covers the fallback.
        """
        fake_llm = _FakeLLM(response_text="Concise summary.")

        captured = {}

        def hostile_subscriber(event):
            # Record original references and then attempt to corrupt them.
            captured["kept_len"] = len(event.kept)
            for m in event.kept:
                m.content = "TAMPERED"
                m.role = "system"
            event.summary.content = "TAMPERED"
            event.summary.role = "user"

        mem = summ_mod.SummarizingMemory(
            fake_llm,
            max_history_length=6,
            messages_to_keep_at_end=2,
            on_summarize=hostile_subscriber,
        )
        msgs = _mk_msgs(n_user_assistant_pairs=4)
        for m in msgs:
            mem.add_message(m)

        await mem.aget_history()

        # No message in self.history should have the tampered marker
        assert all(m.content != "TAMPERED" for m in mem.history), (
            "subscriber mutation bled back into self.history"
        )
        assert captured["kept_len"] > 0, "test sanity: subscriber must have run"

    @pytest.mark.asyncio
    async def test_subscriber_mutation_isolation_on_adapter_failure_path(self):
        """Same guarantee as above but on the adapter_failure_fallback path:
        kept items there are aliases of the verbatim self.history; copying
        them must keep self.history pristine when a subscriber tampers.
        """
        raising_llm = _RaisingLLM(provider="fake")

        def hostile_subscriber(event):
            for m in event.kept:
                m.content = "TAMPERED"

        mem = summ_mod.SummarizingMemory(
            raising_llm,
            max_history_length=6,
            messages_to_keep_at_end=2,
            on_summarize=hostile_subscriber,
        )
        msgs = _mk_msgs(n_user_assistant_pairs=4)
        for m in msgs:
            mem.add_message(m)

        await mem.aget_history()

        assert all(m.content != "TAMPERED" for m in mem.history), (
            "subscriber mutation bled back into self.history on the "
            "adapter_failure_fallback path"
        )


class TestSummarizingMemoryEightyPercentWarning:
    """Framework logs a warning when pinned messages exceed 80% of
    max_history_length. Latch is edge-triggered (fires on transition from
    below to at-or-above the threshold), not level-triggered.
    """

    def test_warning_fires_when_pinned_count_crosses_80pct(self, caplog):
        fake_llm = _FakeLLM()
        # 80% of 10 is 8 → threshold crosses on the 8th pinned message
        mem = summ_mod.SummarizingMemory(
            fake_llm, max_history_length=10, messages_to_keep_at_end=4
        )
        with caplog.at_level(logging.WARNING):
            for i in range(7):
                mem.add_message(_pin(f"P{i}"))
            # Up to 7 pinned, no warning yet (under 80% of 10 = 8.0)
            assert not any("pinned" in r.getMessage().lower() for r in caplog.records)
            # 8th pinned crosses the threshold
            mem.add_message(_pin("P7"))

        warnings = [r for r in caplog.records if r.levelno == logging.WARNING]
        pin_warnings = [w for w in warnings if "pinned" in w.getMessage().lower()]
        # Edge-trigger contract: exactly one warning fires at the crossing,
        # not multiple, even though add_message was called eight times in total.
        assert len(pin_warnings) == 1

    def test_warning_does_not_fire_when_pinned_count_stays_below_threshold(self, caplog):
        fake_llm = _FakeLLM()
        mem = summ_mod.SummarizingMemory(
            fake_llm, max_history_length=10, messages_to_keep_at_end=4
        )
        with caplog.at_level(logging.WARNING):
            for i in range(5):
                mem.add_message(_pin(f"P{i}"))
            for i in range(5):
                mem.add_message(_norm(f"N{i}"))

        warnings = [r for r in caplog.records if r.levelno == logging.WARNING]
        pin_warnings = [w for w in warnings if "pinned" in w.getMessage().lower()]
        assert pin_warnings == []

    def test_warning_is_edge_triggered_not_level_triggered(self, caplog):
        """Latch on the edge transition: cross from <80% to >=80% fires once.
        Subsequent adds while still over the threshold do NOT re-fire.
        """
        fake_llm = _FakeLLM()
        mem = summ_mod.SummarizingMemory(
            fake_llm, max_history_length=10, messages_to_keep_at_end=4
        )
        with caplog.at_level(logging.WARNING):
            # First 7 keep us below 80%
            for i in range(7):
                mem.add_message(_pin(f"P{i}"))
            # 8th crosses the edge → 1 warning
            mem.add_message(_pin("P7"))
            # 9th and 10th also above the edge but should not re-fire
            mem.add_message(_pin("P8"))
            mem.add_message(_pin("P9"))

        warnings = [r for r in caplog.records if r.levelno == logging.WARNING]
        pin_warnings = [w for w in warnings if "pinned" in w.getMessage().lower()]
        # Exactly one edge-triggered warning across the lifetime
        assert len(pin_warnings) == 1


class TestSummarizingMemorySyncPath:
    """C7: sync get_history() under-limit returns history as before. Over-limit
    behavior is unchanged from before P1.1 (placeholder pattern + warning) —
    pinning is not honored on the sync path because the sync path itself is
    not the supported summarization surface. Documented divergence; the
    backwards-compat tests above already pin this for non-pinned histories.
    This test pins it for pinned histories.
    """

    def test_sync_over_limit_does_not_honor_pinning_uses_placeholder(self, capsys):
        fake_llm = _FakeLLM()
        mem = summ_mod.SummarizingMemory(
            fake_llm, max_history_length=6, messages_to_keep_at_end=2
        )
        msgs = [
            _norm("system", role="system"),
            _norm("U1"),
            Message(role="assistant", content="PINNED", importance="pinned"),
            _norm("U2"),
            _norm("A2", role="assistant"),
            _norm("U3"),
            _norm("A3", role="assistant"),
            _norm("U4"),
            _norm("A4", role="assistant"),
        ]
        for m in msgs:
            mem.add_message(m)

        out = mem.get_history()

        # Sync path returns the unchanged placeholder layout: head + summary placeholder + last N
        assert len(out) == 1 + 1 + 2
        assert out[0] is msgs[0]
        # The placeholder summary is a normal system message — pinning was not honored
        assert out[1].role == "system"
        assert out[1].content == "...summary..."
        # Internal history is NOT mutated by sync get_history()
        assert mem.history == msgs


class TestSummarizingMemoryRecoveryPhaseD:
    """Phase D: when summarization LLM fails with AdapterError, aget_history
    returns the verbatim history (no compression that round) and emits the
    event with a placeholder summary message and reason='adapter_failure_fallback'.
    """

    @pytest.mark.asyncio
    async def test_d1_adapter_error_returns_verbatim_history_and_emits_event(self):
        raising_llm = _RaisingLLM(provider="fake")
        events = []
        mem = summ_mod.SummarizingMemory(
            raising_llm,
            max_history_length=6,
            messages_to_keep_at_end=2,
            on_summarize=events.append,
        )
        msgs = _mk_msgs(n_user_assistant_pairs=4)  # 9 total > 6
        for m in msgs:
            mem.add_message(m)

        out = await mem.aget_history()

        # Verbatim history returned (no compression that round)
        assert out == msgs
        # Internal history is unchanged
        assert mem.history == msgs
        # Event fired with adapter_failure_fallback reason
        assert len(events) == 1
        event = events[0]
        assert event.reason == "adapter_failure_fallback"
        # Summary is a placeholder Message
        assert isinstance(event.summary, Message)
        assert event.summary.role == "system"

    @pytest.mark.asyncio
    async def test_d2_adapter_error_without_callback_returns_verbatim_and_logs(
        self, caplog
    ):
        # When on_summarize is None, the AdapterError fallback must still
        # return the verbatim history and log a WARNING. Exercises the
        # _emit_summarized_event early-return branch on the failure path.
        raising_llm = _RaisingLLM(provider="fake")
        mem = summ_mod.SummarizingMemory(
            raising_llm,
            max_history_length=6,
            messages_to_keep_at_end=2,
        )
        msgs = _mk_msgs(n_user_assistant_pairs=4)  # 9 total > 6
        for m in msgs:
            mem.add_message(m)

        with caplog.at_level(
            logging.WARNING,
            logger="fairlib.modules.memory.summarization",
        ):
            out = await mem.aget_history()

        assert out == msgs
        assert mem.history == msgs
        assert any(
            "Summarization LLM failed" in r.getMessage()
            for r in caplog.records
        )
