"""
Golden test for Memory pinning in a 60-turn adversarial-tutor session.

This is the named acceptance bar: the student's answer-submission turn must remain
reachable from memory.get_history() after summarization, without any
evidence-detector-style inference.
"""

import pytest

from fairlib.core.events import MemorySummarizedEvent
from fairlib.core.message import Message
from fairlib.modules.memory.summarization import SummarizingMemory


_PINNED_INDEX = 8
_PINNED_CONTENT = (
    "I think the answer is 42, because the derivative of the cost function "
    "evaluated at the critical point yields the minimum."
)


class _DeterministicSummarizerLLM:
    """Async chat model double producing a deterministic, recognizable summary.

    Importantly, the produced summary content is a fixed string that does NOT
    contain the pinned-message content. Used to assert the pinned content does
    not leak into the LLM's input or its output.
    """

    def __init__(self):
        self.calls = 0
        self.last_prompt = None

    async def ainvoke(self, prompt):
        self.calls += 1
        self.last_prompt = prompt
        return Message(
            role="assistant",
            content="Conversation summary covering ongoing tutor dialog about quadratic optimization.",
        )


def _build_60_turn_session():
    """Construct a 60-message tutor history.

    Layout matches what a real tutor session would produce: a system prompt
    at index 0, scenario setup, an answer submission at index 8, then ongoing
    tutor dialog. Total length 60.
    """
    msgs = [
        Message(role="system", content="You are a math tutor."),
        Message(role="user", content="I have a problem about quadratic functions."),
        Message(role="assistant", content="Tell me about the problem."),
        Message(role="user", content="Find the minimum of x^2 - 4x + 7."),
        Message(role="assistant", content="What approach would you try?"),
        Message(role="user", content="I could complete the square."),
        Message(role="assistant", content="Walk me through the steps."),
        Message(role="user", content="x^2 - 4x = (x-2)^2 - 4, so minimum is at x=2."),
    ]
    # Index 8: the pinned answer submission.
    msgs.append(
        Message(
            role="user",
            content=_PINNED_CONTENT,
            importance="pinned",
        )
    )
    assert msgs[_PINNED_INDEX].content == _PINNED_CONTENT  # invariant

    # Fill out to 60 with ongoing dialog turns.
    while len(msgs) < 60:
        i = len(msgs)
        if i % 2 == 1:
            msgs.append(Message(role="assistant", content=f"Tutor turn {i}."))
        else:
            msgs.append(Message(role="user", content=f"Student turn {i}."))
    assert len(msgs) == 60
    return msgs


@pytest.mark.asyncio
async def test_e1_pinned_answer_submission_in_returned_history_after_summarization():
    """E1: After aget_history triggers summarization, the pinned answer-
    submission message at index 8 is in the returned history.
    """
    llm = _DeterministicSummarizerLLM()
    mem = SummarizingMemory(
        llm,
        max_history_length=50,
        messages_to_keep_at_end=12,
    )
    for m in _build_60_turn_session():
        mem.add_message(m)

    out = await mem.aget_history()

    pinned_in_out = [m for m in out if m.importance == "pinned"]
    assert len(pinned_in_out) == 1, "exactly one pinned message must survive"
    assert pinned_in_out[0].content == _PINNED_CONTENT


@pytest.mark.asyncio
async def test_e2_event_kept_contains_pinned_dropped_does_not():
    """E2: The on_summarize callback receives an event whose kept tuple
    includes the pinned message and whose dropped tuple does not.
    """
    llm = _DeterministicSummarizerLLM()
    received_events = []
    mem = SummarizingMemory(
        llm,
        max_history_length=50,
        messages_to_keep_at_end=12,
        on_summarize=received_events.append,
    )
    for m in _build_60_turn_session():
        mem.add_message(m)

    await mem.aget_history()

    assert len(received_events) == 1
    event = received_events[0]
    assert isinstance(event, MemorySummarizedEvent)

    kept_contents = [m.content for m in event.kept]
    dropped_contents = [m.content for m in event.dropped]

    assert _PINNED_CONTENT in kept_contents, "pinned message must be in event.kept"
    assert _PINNED_CONTENT not in dropped_contents, "pinned message must NOT be in event.dropped"


@pytest.mark.asyncio
async def test_e_pinned_content_not_in_summary_content():
    """The pinned message content must not appear inside the LLM-generated
    summary content. This pins the inverse of the kept/dropped split — the
    summary cannot contain the pinned text either, because the pinned text
    was never fed to the summarization LLM.
    """
    llm = _DeterministicSummarizerLLM()
    received_events = []
    mem = SummarizingMemory(
        llm,
        max_history_length=50,
        messages_to_keep_at_end=12,
        on_summarize=received_events.append,
    )
    for m in _build_60_turn_session():
        mem.add_message(m)

    await mem.aget_history()

    event = received_events[0]
    assert _PINNED_CONTENT not in event.summary.content


@pytest.mark.asyncio
async def test_e_pinned_content_not_in_llm_summarization_input():
    """The text fed to the summarization LLM as the user-content block must
    not contain the pinned message content. This is the upstream guarantee
    that makes the kept/dropped/summary properties hold.
    """
    llm = _DeterministicSummarizerLLM()
    mem = SummarizingMemory(
        llm,
        max_history_length=50,
        messages_to_keep_at_end=12,
    )
    for m in _build_60_turn_session():
        mem.add_message(m)

    await mem.aget_history()

    user_block = llm.last_prompt[1].content
    assert _PINNED_CONTENT not in user_block


@pytest.mark.asyncio
async def test_e_subsequent_sync_get_history_also_contains_pinned():
    """Once aget_history has summarized and mutated self.history, a sync
    get_history call sees the pinned message too. This is the property the
    roadmap names: 'reachable from memory.get_history() alone'.
    """
    llm = _DeterministicSummarizerLLM()
    mem = SummarizingMemory(
        llm,
        max_history_length=50,
        messages_to_keep_at_end=12,
    )
    for m in _build_60_turn_session():
        mem.add_message(m)

    await mem.aget_history()
    sync_out = mem.get_history()

    pinned_in_sync = [m for m in sync_out if m.importance == "pinned"]
    assert len(pinned_in_sync) == 1
    assert pinned_in_sync[0].content == _PINNED_CONTENT
