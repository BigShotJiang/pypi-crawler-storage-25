import pytest
from fairlib.modules.learning.model_selector import ModelSelector


class FakeModelManager:
    """Fake model manager for testing ModelSelector"""
    def __init__(self, models):
        self._models = models

    def list_models(self):
        return self._models


def test_select_model_exact_match():
    manager = FakeModelManager(["general-v1", "translation-v1", "summarizer-v2"])
    selector = ModelSelector(manager)

    result = selector.select_model("translation")
    assert result == "translation-v1"


def test_select_model_partial_match():
    manager = FakeModelManager(["general-v1", "qa-special", "summarizer-v2"])
    selector = ModelSelector(manager)

    result = selector.select_model("qa")
    assert result == "qa-special"


def test_select_model_fallback_first_if_no_match():
    manager = FakeModelManager(["general-v1", "summarizer-v2"])
    selector = ModelSelector(manager)

    # "image" doesn’t match anything, should return first model
    result = selector.select_model("image")
    assert result == "general-v1"


def test_select_model_none_if_no_models():
    manager = FakeModelManager([])
    selector = ModelSelector(manager)

    result = selector.select_model("general")
    assert result is None


def test_select_model_default_task_type():
    manager = FakeModelManager(["general-v1", "translation-v1"])
    selector = ModelSelector(manager)

    result = selector.select_model()
    assert result == "general-v1"
