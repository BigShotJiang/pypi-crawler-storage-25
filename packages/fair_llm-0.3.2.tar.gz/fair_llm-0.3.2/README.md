# **FAIR-LLM: A Flexible, Agnostic, and Interoperable Reasoning Framework**

FAIR-LLM is a Python framework designed to accelerate the development of powerful, consistent, and modular agentic applications. It provides a structured, interface-driven architecture that allows developers to easily build and customize agents with sophisticated reasoning capabilities, long-term memory, and collaborative multi-agent systems. Crafted to help engineers build powerful AI systems—without vendor lock-in.

## **Core Principles**

The FAIR framework is built on four core principles that guide its architecture and empower developers:

  * **Flexible**: The framework is highly modular. Every core component is built upon an abstract interface, allowing developers to easily swap implementations (e.g., swapping a simple memory system for a summarizing one) without altering the agent's core logic.
  * **Agnostic**: You are not locked into a single LLM provider. The Model Abstraction Layer (MAL) enables seamless switching between different models—from OpenAI and Anthropic to local models via HuggingFace or Ollama—ensuring you can always use the best tool for the job.
  * **Interoperable**: Components are designed to work together seamlessly. A standardized set of data structures, like the `Message` and `Document` types, ensures that data flows consistently between the agent's memory, planner, and tools.
  * **Reasoning**: At its heart, the framework is built to support sophisticated reasoning patterns. The default `ReActPlanner` allows agents to "think" step-by-step to solve complex problems, and the architecture is extensible enough to support more advanced paradigms like "Plan-and-Execute".

## **Key Features**

  * **🤖 Advanced Agent Patterns**: Built-in support for the powerful **ReAct (Reason+Act)** cognitive cycle. Two planner variants are provided: `ReActPlanner` (JSON-based, for powerful models like GPT-4 and Claude) and `SimpleReActPlanner` (key-value format, for smaller or local models that may struggle with strict JSON).
  * **🤝 Multi-Agent Collaboration**: Orchestrate teams of specialized agents with a hierarchical manager-worker architecture. The `HierarchicalAgentRunner` and `ManagerPlanner` allow a lead agent to delegate sub-tasks to workers, enabling the system to tackle complex, multi-faceted problems.
  * **🧠 Retrieval-Augmented Generation (RAG)**: Easily ground agents in your own documents and data. The framework includes all necessary components for a robust RAG pipeline, including document loaders, text splitters, embedders (`SentenceTransformerEmbedder`), and two queryable vector store backends (`FaissVectorStore` and `ChromaDBVectorStore`) made available to the agent through the `KnowledgeBaseQueryTool`. FAISS is the recommended default backend.
  * **🔌 Pluggable Model Support**: The **Model Abstraction Layer (MAL)** features concrete adapters for **OpenAI**, **Anthropic**, **HuggingFace Transformers**, **Ollama** (local models), and **LoadBalancerAdapter** (distributed vLLM inference clusters), allowing for unparalleled flexibility in model selection and deployment topology.
  * **🧩 Modular & Extensible by Design**: Every core component (LLM, Memory, Tools, Planner) is defined by an `Abstract` base class in the `core/interfaces/` directory. This interface-driven design makes the framework easy to extend and customize.
  * **✍️ Prompt Engineering System**: A first-class prompt engineering system lives in `core/prompts.py`, providing composable building blocks: `PromptBuilder`, `RoleDefinition`, `FormatInstruction`, `Example`, `ToolInstruction`, `WorkerInstruction`, and more. Specialized subclasses including `StrictFormatInstruction` (optimized for smaller models), `DelegationExample`, and `ManagerPromptBuilder` give fine-grained control over manager-agent prompting.
  * **🔗 MCP (Model Context Protocol) Integration**: A full `modules/mcp/` package provides first-class support for MCP tool servers. Agents can combine local FAIR tools with tools from any MCP-compatible server (stdio or SSE transport) using `MCPToolRegistry`, `CompositeToolRegistry`, and `create_mcp_enhanced_registry`. Configure MCP connections via `MCPServerConfig` in `settings.yml`.
  * **🛡️ Secure by Design**: The framework includes foundational components for security, such as the `BasicSecurityManager` for input validation and explicit warnings and placeholders for sandboxed tool execution to mitigate risks.
  * **📊 Reliable Structured Output**: Comes with patterns and demos (see `demo_structured_output.py`) for compelling LLMs to return clean, Pydantic-validated JSON, which is essential for reliable data extraction and tool integration.
  * **💾 Agent Configuration Persistence**: Save and reload complete agent configurations — including prompt definitions, tool setup, and model settings — via utilities in `fairlib.utils.config_manager`. Enables reproducible agent setups, team sharing, and prompt optimization workflows.

## **🚀 Getting Started: Your First Agent (5-Minute Quickstart)**

Follow these steps to get your first agent running.

### 1\. Prerequisites

  * Python 3.12+
  * Git

### 2\. Installation

Clone the repository and install the required dependencies. It is highly recommended to use a virtual environment.

```bash
git clone https://github.com/USAFA-AI-Center/fair_llm.git
cd fair_llm
pip install -e .
```

A `requirements.txt` is provided in the repository root. Core dependencies include: `openai`, `anthropic`, `pydantic`, `pyyaml`, `sentence-transformers`, `faiss-cpu` (or `faiss-gpu`), `chromadb`, `torch`, `transformers`, `httpx`, `sympy`, `python-docx`, `pypdf`.

### 3\. Configuration

The framework uses a centralized YAML configuration file for API keys and model settings.

1.  Navigate to `fairlib/config/`.
2.  Open `settings.yml` and add your API keys (e.g., for OpenAI or Anthropic).
3.  Review the model definitions and other settings (RAG paths, cache, security, MCP) to suit your environment.

### 4\. Run Your First Agent

The following code assembles and runs a simple agent that can use a calculator. Save it as `main.py` in the root of the project directory.

```python
# main.py
import asyncio
from fairlib import (
    settings,
    OpenAIAdapter,
    ToolRegistry,
    SafeCalculatorTool,
    ToolExecutor,
    WorkingMemory,
    ReActPlanner,
    SimpleAgent
)

async def main():
    print("Initializing a single agent...")

    # 1. The "Brain": Initialize the LLM adapter from the settings file
    llm = OpenAIAdapter(
        api_key=settings.api_keys.openai_api_key,
        model_name=settings.models["openai_gpt4"].model_name
    )

    # 2. The "Toolbelt": Create a registry and add tools
    tool_registry = ToolRegistry()
    tool_registry.register_tool(SafeCalculatorTool())

    # 3. The "Hands": Create an executor that uses the toolbelt
    executor = ToolExecutor(tool_registry)

    # 4. The "Memory": Set up short-term memory for the conversation
    memory = WorkingMemory()

    # 5. The "Mind": Create the planner that uses the brain and tools
    planner = ReActPlanner(llm, tool_registry)

    # 6. Assemble the Agent: Combine all parts into a functional unit
    agent = SimpleAgent(
        llm=llm,
        planner=planner,
        tool_executor=executor,
        memory=memory
    )
    print("✅ Agent created. Ask a math question or type 'exit'.")

    # 7. Run the agent in a loop
    while True:
        try:
            user_input = input("\n👤 You: ")
            if user_input.lower() == "exit":
                break
            response = await agent.arun(user_input)
            print(f"🤖 Agent: {response}")
        except KeyboardInterrupt:
            break

if __name__ == "__main__":
    asyncio.run(main())
```

Run the agent from your terminal:

```bash
python main.py
```

## **📚 Learn with Demos**

The `demos/` directory contains executable scripts that are the best way to learn the framework's capabilities.

  * `demo_single_agent_calculator.py`: The best place to start. Learn the fundamentals of building and running a single agent with a simple tool.
  * `demo_advanced_calculator_calculus.py`: Shows how to equip an agent with multiple, more complex tools.
  * `demo_rag_from_documents.py`: A deep dive into Retrieval-Augmented Generation using ChromaDB.
  * `demo_faiss_rag_from_readme.py`: RAG using the FAISS vector store backend with cross-encoder re-ranking (recommended for most use cases).
  * `demo_structured_output.py`: Learn how to reliably extract structured JSON data from unstructured text, complete with Pydantic validation and a self-correction loop.
  * `demo_model_comparison.py`: See the Model Abstraction Layer in action by comparing responses from different LLMs side-by-side.
  * `demo_multi_agent.py`: The most advanced agent demo. Learn how to orchestrate a team of specialized agents to solve a complex problem that's impossible for a single agent.
  * `demo_committee_of_agents_*.py`: Practical examples of the multi-agent architecture applied to autograding essays and code.
  * `demo_web_search_plot_agent.py`: An agent that combines web search and graphing tools to answer data-driven questions.

## **📚 Learn with Our Developer's Guide**

Our comprehensive developer's guide, **"A Guide to the FAIR Agentic Framework"**, is written for developers of all skill levels—from newcomers to experienced AI engineers. Whether you're building your first chatbot with a tool or architecting a complex network of distributed agents, this guide will give you the principles and practical techniques you need. The guide is available in the `docs/` directory.

## **🏛️ Framework Architecture**

The FAIR Agentic Framework is organized into a modular architecture. Below is an overview of the most critical components:

  * `core/`: Contains the architectural DNA of the framework.
      * `interfaces/`: Abstract Base Classes defining the "contract" for every major component (`AbstractChatModel`, `AbstractPlanner`, `AbstractMemory`, `AbstractTool`, `AbstractEmbedder`, `AbstractPerception`, `AbstractSecurityManager`). This is the key to the framework's modularity.
      * `message.py`: Core conversational data structures — `Message`, `Thought`, `Action`, `Observation`, and `FinalAnswer` — that flow between all components.
      * `types.py`: Domain data types such as `Document`, `GradingCriterion`, and `FinalGrade`.
      * `prompts.py`: The complete prompt engineering system — `PromptBuilder`, `ManagerPromptBuilder`, and all prompt item types (`RoleDefinition`, `FormatInstruction`, `StrictFormatInstruction`, `Example`, `DelegationExample`, `ToolInstruction`, `WorkerInstruction`, `EnhancedWorkerInstruction`, `AgentCapability`, `History`, `DateContextMixin`).
      * `base_agent.py`: The abstract `BaseAgent` class all agents inherit from.
      * `config.py` / `config_schemas.py`: Pydantic-validated configuration loading, including `MCPServerConfig` and `MCPSettings` schemas.
  * `modules/`: Contains the concrete implementations of the interfaces.
      * `mal/`: The **Model Abstraction Layer**, with adapters for `OpenAIAdapter`, `AnthropicAdapter`, `OllamaAdapter`, `HuggingFaceAdapter`, and `LoadBalancerAdapter` (distributed vLLM inference).
      * `agent/`: Agent definitions (`SimpleAgent`) and multi-agent orchestrators (`HierarchicalAgentRunner`, `ManagerPlanner`).
      * `planning/`: Reasoning engines — `ReActPlanner` (JSON-based, for powerful models) and `SimpleReActPlanner` (key-value format, for smaller/local models).
      * `mcp/`: Full **Model Context Protocol** support — `MCPClient`, `MCPToolAdapter`, `MCPToolRegistry`, `MCPServer`, and `create_mcp_enhanced_registry`. Supports both `stdio` and `SSE` transports.
      * `action/`: The `ToolExecutor`, `ToolRegistry`, `CompositeToolRegistry` (merges multiple registries for hybrid local+MCP setups), and the tool library — built-in tools (`SafeCalculatorTool`, `WebSearcherTool`, `WeatherTool`, `GraphingTool`, `WebDataExtractor`) and domain tools (`KnowledgeBaseQueryTool`, `GradeEssayFromRubricTool`, `GradeCodeFromRubricTool`, `CodeExecutionTool`, `AdvancedCalculusTool`).
      * `memory/`: Short-term (`WorkingMemory`, `SummarizingMemory`) and long-term/RAG memory components (`FaissVectorStore` — import via `fairlib.modules.memory.vector_faiss`, `ChromaDBVectorStore`, `InMemoryVectorStore`, `SentenceTransformerEmbedder`, `SimpleRetriever`, `retriever_rerank`).
      * `perception/`: Input preprocessing components (`TextParser`, `EchoPreprocessor`).
      * `communication/`: Agent-to-agent communication (`InMemoryCommunicator`).
      * `learning/`: Model selection and learning utilities.
      * `security/`: Security components like the `BasicSecurityManager`.
  * `config/`: Centralized YAML configuration (`settings.yml`), including MCP server configuration.
  * `utils/`: Utility code — `config_manager` (agent config save/load), `document_processor`, `autograder_utils`, `math_expression_parser`, `rag_prompts`, `chart_utils`, `WolframGPT`, and more.
  * `fairlib/__init__.py`: The central, user-facing API providing lazy-loaded access to all framework components.
  * `demos/`: A collection of scripts that serve as practical, executable examples of the framework's capabilities.

## **📁 Folder Structure**

```
fair_llm/
├── fairlib/
│   ├── config/
│   │   └── settings.yml
│   ├── core/
│   │   ├── interfaces/
│   │   │   ├── communicator.py
│   │   │   ├── embedder.py
│   │   │   ├── executor.py
│   │   │   ├── llm.py
│   │   │   ├── memory.py
│   │   │   ├── model_manager.py
│   │   │   ├── perception.py
│   │   │   ├── planner.py
│   │   │   ├── security.py
│   │   │   └── tools.py
│   │   ├── base_agent.py
│   │   ├── config.py
│   │   ├── config_schemas.py      (includes MCPServerConfig, MCPSettings)
│   │   ├── message.py
│   │   ├── prompts.py             (all prompt items + PromptBuilder)
│   │   └── types.py
│   ├── modules/
│   │   ├── action/
│   │   │   ├── tools/
│   │   │   │   ├── builtin_tools/
│   │   │   │   │   ├── data_extractor.py
│   │   │   │   │   ├── final_answer.py
│   │   │   │   │   ├── safe_calculator.py
│   │   │   │   │   ├── weather.py
│   │   │   │   │   └── web_searcher.py
│   │   │   │   ├── advanced_calculus_tool.py
│   │   │   │   ├── code_execution_tool.py
│   │   │   │   ├── composite_registry.py  (CompositeToolRegistry)
│   │   │   │   ├── grading_tool.py
│   │   │   │   ├── graphing_tool.py
│   │   │   │   ├── knowledge_tool.py
│   │   │   │   └── registry.py
│   │   │   └── executor.py
│   │   ├── agent/
│   │   │   ├── multi_agent_runner.py
│   │   │   └── simple_agent.py
│   │   ├── communication/
│   │   │   └── in_memory_communicator.py
│   │   ├── learning/
│   │   │   ├── base.py
│   │   │   └── model_selector.py
│   │   ├── mal/
│   │   │   ├── anthropic_adapter.py
│   │   │   ├── huggingface_adapter.py
│   │   │   ├── load_balancer_adapter.py   (LoadBalancerAdapter — vLLM)
│   │   │   ├── local_llama_adapter.py     (OllamaAdapter)
│   │   │   └── openai_adapter.py
│   │   ├── mcp/
│   │   │   ├── client/
│   │   │   │   ├── mcp_client.py
│   │   │   │   ├── mcp_tool_adapter.py
│   │   │   │   └── mcp_tool_registry.py
│   │   │   └── server/
│   │   │       └── mcp_server.py
│   │   ├── memory/
│   │   │   ├── base.py
│   │   │   ├── embedder.py
│   │   │   ├── retriever.py
│   │   │   ├── retriever_rerank.py
│   │   │   ├── summarization.py
│   │   │   ├── vector_faiss.py
│   │   │   └── vector_store.py            (ChromaDB)
│   │   ├── perception/
│   │   │   ├── echo_preprocessor.py
│   │   │   └── text_parser.py
│   │   ├── planning/
│   │   │   └── react_planner.py           (ReActPlanner + SimpleReActPlanner)
│   │   └── security/
│   │       └── basic_security_manager.py
│   ├── utils/
│   │   ├── autograder_utils.py
│   │   ├── chart_utils.py
│   │   ├── config_manager.py              (save_agent_config, load_agent)
│   │   ├── document_processor.py
│   │   ├── math_expression_parser.py
│   │   ├── nuextract.py
│   │   ├── rag_prompts.py
│   │   ├── speech_util.py
│   │   └── WolframGPT.py
│   └── __init__.py                        (central API with lazy loading)
├── demos/
├── docs/
│   ├── Agentic System Design Blueprint.pdf
│   ├── fair_lib_dev_doc.pdf
│   └── latex/
├── tests/
├── Jenkinsfile
├── LICENSE.md
├── pyproject.toml
├── README.md
├── requirements.txt
└── uv.lock
```
## 👥 Contributors

Developed by the USAFA AI Center team:
- Ryan R (rrabinow@uccs.edu)
- Austin W (austin.w@ardentinc.com)
- Eli G (elijah.g@ardentinc.com)
- Chad M (Chad.Mello@afacademy.af.edu)

## **🤝 Contributing**

Contributions are welcome! Please open an issue or submit a pull request with any enhancements, bug fixes, or new features.
