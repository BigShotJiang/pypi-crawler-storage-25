# fairlib/modules/mcp/client/mcp_tool_registry.py
"""
Tool registry that discovers and manages tools from MCP servers.

Implements AbstractToolRegistry to integrate with existing code.
"""
from typing import Dict, List, Optional, TYPE_CHECKING

from fairlib.core.interfaces.tools import AbstractTool, AbstractToolRegistry
from .mcp_client import MCPClient
from .mcp_tool_adapter import MCPToolAdapter

if TYPE_CHECKING:
    from fairlib.core.config_schemas import MCPServerConfig


class MCPToolRegistry(AbstractToolRegistry):
    """
    A tool registry that discovers tools from connected MCP servers.

    This registry manages multiple MCPClient connections and exposes
    discovered tools as AbstractTool instances via the standard
    AbstractToolRegistry interface.

    Usage:
        registry = MCPToolRegistry()
        await registry.add_server(config)
        await registry.discover_tools()
        # Now tools are available via get_tool() and get_all_tools()

    The registry can be used directly with ToolExecutor:
        executor = ToolExecutor(registry)
    """

    def __init__(self, tool_prefix: str = "mcp"):
        """
        Initialize the MCP tool registry.

        Args:
            tool_prefix: Prefix to add to all MCP tool names to avoid conflicts
                        with local tools. Set to empty string for no prefix.
        """
        self._clients: Dict[str, MCPClient] = {}
        self._tools: Dict[str, MCPToolAdapter] = {}
        self._prefix = tool_prefix
        self._discovered = False

    async def add_server(self, config: 'MCPServerConfig') -> None:
        """
        Add and connect to an MCP server.

        Args:
            config: Server configuration.

        Raises:
            ValueError: If server with same name already registered.
            ConnectionError: If connection fails.
        """
        if config.name in self._clients:
            raise ValueError(f"Server '{config.name}' already registered")

        client = MCPClient(config)
        await client.connect()
        self._clients[config.name] = client

        # Discover tools from this server
        await self._discover_server_tools(client)

    async def _discover_server_tools(self, client: MCPClient) -> None:
        """Discover and register tools from a single server."""
        tools = await client.list_tools()

        # Build prefix: mcp_servername_ or just servername_ if no global prefix
        if self._prefix:
            server_prefix = f"{self._prefix}_{client.name}_"
        else:
            server_prefix = f"{client.name}_"

        for tool_def in tools:
            adapter = MCPToolAdapter(client, tool_def, name_prefix=server_prefix)
            self._tools[adapter.name] = adapter
            print(f"Registered MCP tool: {adapter.name}")

    async def discover_tools(self, refresh: bool = False) -> None:
        """
        Discover tools from all connected servers.

        Args:
            refresh: If True, re-discover even if already done.
        """
        if self._discovered and not refresh:
            return

        for client in self._clients.values():
            await self._discover_server_tools(client)

        self._discovered = True

    async def remove_server(self, name: str) -> None:
        """
        Disconnect and remove an MCP server.

        Args:
            name: Server name to remove.
        """
        if name not in self._clients:
            return

        client = self._clients.pop(name)
        await client.disconnect()

        # Remove tools from this server
        if self._prefix:
            server_prefix = f"{self._prefix}_{name}_"
        else:
            server_prefix = f"{name}_"

        self._tools = {
            k: v for k, v in self._tools.items()
            if not k.startswith(server_prefix)
        }

    async def close_all(self) -> None:
        """Close all server connections."""
        for client in self._clients.values():
            try:
                await client.disconnect()
            except (Exception, BaseException):
                # Catch BaseException too for ExceptionGroup from anyio
                pass  # Best effort cleanup

        self._clients.clear()
        self._tools.clear()
        self._discovered = False

    # --- AbstractToolRegistry Implementation ---

    def register_tool(self, tool: AbstractTool) -> None:
        """
        Register a tool manually (not typical for MCP registry).

        Note: Normally tools come from MCP servers via discovery,
        but this supports manual registration if needed.
        """
        if not tool.name:
            raise ValueError("Tool must have a name attribute.")
        print(f"Registering tool: {tool.name}")
        self._tools[tool.name] = tool

    def get_tool(self, name: str) -> Optional[AbstractTool]:
        """Get a tool by name."""
        return self._tools.get(name)

    def get_all_tools(self) -> Dict[str, AbstractTool]:
        """Get all registered tools."""
        return dict(self._tools)

    def get_tools_by_server(self, server_name: str) -> Dict[str, AbstractTool]:
        """
        Get all tools from a specific server.

        Args:
            server_name: Name of the MCP server.

        Returns:
            Dictionary of tools from that server.
        """
        if self._prefix:
            prefix = f"{self._prefix}_{server_name}_"
        else:
            prefix = f"{server_name}_"

        return {k: v for k, v in self._tools.items() if k.startswith(prefix)}

    @property
    def connected_servers(self) -> List[str]:
        """List names of connected servers."""
        return list(self._clients.keys())

    @property
    def tool_count(self) -> int:
        """Return total number of registered tools."""
        return len(self._tools)

    async def __aenter__(self) -> 'MCPToolRegistry':
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit - closes all connections."""
        await self.close_all()
