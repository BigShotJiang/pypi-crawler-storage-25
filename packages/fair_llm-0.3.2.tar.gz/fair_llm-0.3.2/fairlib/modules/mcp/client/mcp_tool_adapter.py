# fairlib/modules/mcp/client/mcp_tool_adapter.py
"""
Adapter that wraps an MCP tool as a fair_llm AbstractTool.

Allows MCP tools to be used seamlessly with the existing ToolExecutor.
"""
import asyncio
import json
from typing import Any, Dict, TYPE_CHECKING

from fairlib.core.interfaces.tools import AbstractTool

if TYPE_CHECKING:
    from .mcp_client import MCPClient


class MCPToolAdapter(AbstractTool):
    """
    Wraps an MCP tool to conform to the AbstractTool interface.

    This adapter allows tools discovered from MCP servers to work
    with fair_llm's existing ToolExecutor without any modifications.

    The adapter handles:
    - Converting string input to the JSON arguments MCP expects
    - Running async MCP calls in a sync context
    - Prefixing tool names to avoid conflicts
    """

    def __init__(
        self,
        mcp_client: 'MCPClient',
        tool_definition: Dict[str, Any],
        name_prefix: str = ""
    ):
        """
        Initialize the adapter.

        Args:
            mcp_client: The MCPClient connected to the tool's server.
            tool_definition: Tool definition from MCP (name, description, inputSchema).
            name_prefix: Optional prefix for the tool name (e.g., "mcp_filesystem_").
        """
        self._client = mcp_client
        self._mcp_tool_name = tool_definition["name"]
        self._input_schema = tool_definition.get("inputSchema", {})

        # Set AbstractTool attributes
        self.name = f"{name_prefix}{self._mcp_tool_name}" if name_prefix else self._mcp_tool_name
        self.description = self._build_description(tool_definition)

    def _build_description(self, tool_definition: Dict[str, Any]) -> str:
        """Build a rich description including schema info."""
        base_desc = tool_definition.get("description", "No description available.")

        # Add input schema info for better LLM understanding
        schema = tool_definition.get("inputSchema", {})
        if schema.get("properties"):
            props = schema["properties"]
            required = schema.get("required", [])

            params_desc = []
            for prop_name, prop_def in props.items():
                req = " (required)" if prop_name in required else " (optional)"
                prop_type = prop_def.get("type", "any")
                prop_desc = prop_def.get("description", "")
                params_desc.append(f"  - {prop_name}{req}: {prop_type}. {prop_desc}")

            if params_desc:
                base_desc += "\n\nInput Parameters:\n" + "\n".join(params_desc)

        base_desc += f"\n\n[MCP Server: {self._client.name}]"
        return base_desc

    def use(self, tool_input: str) -> str:
        """
        Execute the MCP tool with the given input.

        The input is expected to be either:
        1. A JSON string that can be parsed into arguments
        2. A simple string that becomes {"input": tool_input} or similar

        Args:
            tool_input: String input from the agent.

        Returns:
            String result from the MCP tool.
        """
        # Parse input to arguments
        arguments = self._parse_input(tool_input)

        # Run async in sync context
        try:
            # Check if we're already in an async context
            try:
                loop = asyncio.get_running_loop()
                # We're in an async context - schedule on the running loop
                # Use run_coroutine_threadsafe to safely run from sync context
                # TODO:: potential deadlock risk
                future = asyncio.run_coroutine_threadsafe(
                    self._client.call_tool(self._mcp_tool_name, arguments),
                    loop
                )
                # Wait for result with timeout
                return future.result(timeout=self._client.config.timeout)
            except RuntimeError:
                # No running loop, we can use asyncio.run directly
                return asyncio.run(
                    self._client.call_tool(self._mcp_tool_name, arguments)
                )
        except Exception as e:
            return f"Error calling MCP tool '{self._mcp_tool_name}': {e}"

    async def ause(self, tool_input: str) -> str:
        """
        Async execution of the MCP tool.

        Args:
            tool_input: String input from the agent.

        Returns:
            String result from the MCP tool.
        """
        arguments = self._parse_input(tool_input)
        return await self._client.call_tool(self._mcp_tool_name, arguments)

    def _parse_input(self, tool_input: str) -> Dict[str, Any]:
        """
        Parse string input into arguments dict.

        Attempts to parse as JSON first, then falls back to
        simple string handling based on schema.
        """
        # Try JSON first
        try:
            parsed = json.loads(tool_input)
            if isinstance(parsed, dict):
                return parsed
            # If parsed to non-dict, wrap it
            return self._wrap_simple_input(str(parsed))
        except json.JSONDecodeError:
            pass

        # Fall back to simple string handling
        return self._wrap_simple_input(tool_input)

    def _wrap_simple_input(self, value: str) -> Dict[str, Any]:
        """
        Wrap a simple string value into the expected schema format.
        """
        schema = self._input_schema
        properties = schema.get("properties", {})
        required = schema.get("required", [])

        # If there's exactly one required string property, use it
        string_props = [
            name for name, prop in properties.items()
            if prop.get("type") == "string"
        ]

        if len(required) == 1 and required[0] in string_props:
            return {required[0]: value}

        if len(string_props) == 1:
            return {string_props[0]: value}

        # Common conventions
        for common_name in ["input", "query", "text", "content", "path", "message"]:
            if common_name in properties:
                return {common_name: value}

        # Last resort: first property or generic "input"
        if properties:
            first_prop = list(properties.keys())[0]
            return {first_prop: value}

        return {"input": value}

    @property
    def input_schema(self) -> Dict[str, Any]:
        """Return the JSON schema for this tool's input."""
        return self._input_schema

    @property
    def mcp_server_name(self) -> str:
        """Return the name of the MCP server this tool comes from."""
        return self._client.name

    @property
    def mcp_tool_name(self) -> str:
        """Return the original MCP tool name (without prefix)."""
        return self._mcp_tool_name
