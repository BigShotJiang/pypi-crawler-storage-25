# fairlib/modules/mcp/client/mcp_client.py
"""
MCP Client for connecting to Model Context Protocol servers.

Handles connection lifecycle, tool discovery, and tool invocation.
"""
from typing import Any, Dict, List, Optional
import asyncio

# Guard for optional dependency
try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    MCP_INSTALLED = True
except ImportError:
    MCP_INSTALLED = False
    ClientSession = None
    StdioServerParameters = None
    stdio_client = None

# Try to import SSE client (may not be available in all mcp versions)
try:
    from mcp.client.sse import sse_client
    SSE_AVAILABLE = True
except ImportError:
    SSE_AVAILABLE = False
    sse_client = None


class MCPClient:
    """
    A client for connecting to and interacting with MCP servers.

    This class manages the connection lifecycle, tool discovery, and
    tool invocation for a single MCP server.

    Usage:
        client = MCPClient(config)
        await client.connect()
        tools = await client.list_tools()
        result = await client.call_tool("tool_name", {"arg": "value"})
        await client.disconnect()

    Or as async context manager:
        async with MCPClient(config) as client:
            tools = await client.list_tools()
            result = await client.call_tool("tool_name", {"arg": "value"})
    """

    def __init__(self, config: 'MCPServerConfig'):
        """
        Initialize the MCP client with server configuration.

        Args:
            config: MCPServerConfig with connection details.

        Raises:
            ImportError: If the 'mcp' library is not installed.
        """
        if not MCP_INSTALLED:
            raise ImportError(
                "The 'mcp' library is not installed. "
                "Please install it with `pip install mcp` to use MCP features."
            )

        self.config = config
        self.session: Optional[ClientSession] = None
        self._connected = False
        self._tools_cache: Optional[List[Dict[str, Any]]] = None

        # Background task management for proper context lifecycle
        self._connection_task: Optional[asyncio.Task] = None
        self._shutdown_event: Optional[asyncio.Event] = None
        self._ready_event: Optional[asyncio.Event] = None
        self._connection_error: Optional[Exception] = None

    @property
    def name(self) -> str:
        """Return the server name."""
        return self.config.name

    @property
    def is_connected(self) -> bool:
        """Check if client is connected."""
        return self._connected and self.session is not None

    async def connect(self) -> None:
        """
        Establish connection to the MCP server.

        Raises:
            ConnectionError: If connection fails.
            TimeoutError: If connection times out.
            ValueError: If transport type is unknown or SSE not available.
        """
        if self._connected:
            return

        # Create events for coordination
        self._shutdown_event = asyncio.Event()
        self._ready_event = asyncio.Event()
        self._connection_error = None

        # Start background task that manages the connection lifecycle
        if self.config.transport == "stdio":
            self._connection_task = asyncio.create_task(
                self._run_stdio_connection(),
                name=f"mcp-connection-{self.name}"
            )
        elif self.config.transport == "sse":
            self._connection_task = asyncio.create_task(
                self._run_sse_connection(),
                name=f"mcp-connection-{self.name}"
            )
        else:
            raise ValueError(f"Unknown transport: {self.config.transport}")

        # Wait for connection to be ready or fail
        try:
            await asyncio.wait_for(
                self._ready_event.wait(),
                timeout=self.config.timeout
            )
        except asyncio.TimeoutError:
            self._shutdown_event.set()
            raise ConnectionError(f"Connection to MCP server '{self.name}' timed out")

        if self._connection_error:
            raise ConnectionError(f"Failed to connect to MCP server '{self.name}': {self._connection_error}")

    async def _run_stdio_connection(self) -> None:
        """Run the stdio connection lifecycle in a dedicated task."""
        if not self.config.command:
            self._connection_error = ValueError("stdio transport requires 'command' in config")
            self._ready_event.set()
            return

        server_params = StdioServerParameters(
            command=self.config.command,
            args=self.config.args or [],
            env=self.config.env
        )

        try:
            async with stdio_client(server_params) as (read_stream, write_stream):
                async with ClientSession(read_stream, write_stream) as session:
                    self.session = session
                    await session.initialize()
                    self._connected = True
                    self._ready_event.set()

                    # Wait for shutdown signal
                    await self._shutdown_event.wait()

        except Exception as e:
            self._connection_error = e
            self._ready_event.set()
        finally:
            self.session = None
            self._connected = False

    async def _run_sse_connection(self) -> None:
        """Run the SSE connection lifecycle in a dedicated task."""
        if not SSE_AVAILABLE:
            self._connection_error = ValueError(
                "SSE transport not available. "
                "Ensure you have the latest version of the 'mcp' library."
            )
            self._ready_event.set()
            return

        if not self.config.url:
            self._connection_error = ValueError("SSE transport requires 'url' in config")
            self._ready_event.set()
            return

        try:
            async with sse_client(self.config.url) as (read_stream, write_stream):
                async with ClientSession(read_stream, write_stream) as session:
                    self.session = session
                    await session.initialize()
                    self._connected = True
                    self._ready_event.set()

                    # Wait for shutdown signal
                    await self._shutdown_event.wait()

        except Exception as e:
            self._connection_error = e
            self._ready_event.set()
        finally:
            self.session = None
            self._connected = False

    async def disconnect(self) -> None:
        """Close the connection to the MCP server."""
        if not self._connected and self._connection_task is None:
            return

        try:
            # Signal the connection task to shut down
            if self._shutdown_event is not None:
                self._shutdown_event.set()

            # Wait for the connection task to complete with timeout
            if self._connection_task is not None:
                try:
                    await asyncio.wait_for(
                        asyncio.shield(self._connection_task),
                        timeout=5.0
                    )
                except asyncio.TimeoutError:
                    # Force cancel if it doesn't shut down gracefully
                    self._connection_task.cancel()
                    try:
                        await self._connection_task
                    except asyncio.CancelledError:
                        pass
                except asyncio.CancelledError:
                    pass

        finally:
            self.session = None
            self._connection_task = None
            self._shutdown_event = None
            self._ready_event = None
            self._connected = False
            self._tools_cache = None

    async def list_tools(self, refresh: bool = False) -> List[Dict[str, Any]]:
        """
        List all tools available from the MCP server.

        Args:
            refresh: If True, bypass cache and fetch fresh list.

        Returns:
            List of tool definitions with name, description, and inputSchema.

        Raises:
            ConnectionError: If not connected to MCP server.
        """
        if not self.is_connected:
            raise ConnectionError("Not connected to MCP server")

        if self._tools_cache is not None and not refresh:
            return self._tools_cache

        response = await self.session.list_tools()

        self._tools_cache = [
            {
                "name": tool.name,
                "description": tool.description or "",
                "inputSchema": tool.inputSchema if hasattr(tool, 'inputSchema') else {"type": "object", "properties": {}}
            }
            for tool in response.tools
        ]

        return self._tools_cache

    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> str:
        """
        Call a tool on the MCP server.

        Args:
            tool_name: Name of the tool to call.
            arguments: Dictionary of arguments to pass to the tool.

        Returns:
            String result from the tool.

        Raises:
            ConnectionError: If not connected.
            TimeoutError: If tool execution times out.
        """
        if not self.is_connected:
            raise ConnectionError("Not connected to MCP server")

        try:
            result = await asyncio.wait_for(
                self.session.call_tool(tool_name, arguments),
                timeout=self.config.timeout
            )

            # Convert result to string
            if hasattr(result, 'content'):
                contents = result.content
                if isinstance(contents, list):
                    text_parts = []
                    for c in contents:
                        if hasattr(c, 'text'):
                            text_parts.append(c.text)
                        else:
                            text_parts.append(str(c))
                    return "\n".join(text_parts)
                return str(contents)

            return str(result)

        except asyncio.TimeoutError:
            raise TimeoutError(f"Tool '{tool_name}' timed out after {self.config.timeout}s")

    async def __aenter__(self) -> 'MCPClient':
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.disconnect()
