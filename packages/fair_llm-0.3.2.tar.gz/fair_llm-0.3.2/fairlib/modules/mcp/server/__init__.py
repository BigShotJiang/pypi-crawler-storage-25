# fairlib/modules/mcp/server/__init__.py
"""
MCP Server components for exposing fair_llm tools.
"""
from .mcp_server import MCPServer

__all__ = ["MCPServer"]
