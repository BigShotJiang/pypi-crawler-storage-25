# fairlib/modules/mcp/server/mcp_server.py
# TODO:: extend too suport more than just tools. prompts, resources, etc.
"""
MCP Server that exposes fair_llm tools to external MCP clients.

Allows tools to be used by Claude Desktop and other MCP clients.
"""
import asyncio
import json
import sys
from typing import Any, Dict, List, Optional, Sequence

# Guard for optional dependency
try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import Tool, TextContent
    MCP_INSTALLED = True
except ImportError:
    MCP_INSTALLED = False
    Server = None
    stdio_server = None
    Tool = None
    TextContent = None

from fairlib.core.interfaces.tools import AbstractToolRegistry


class MCPServer:
    """
    Exposes fair_llm tools as an MCP server.

    This allows external MCP clients (like Claude Desktop) to use
    fair_llm tools via the MCP protocol.

    Usage:
        from fairlib import ToolRegistry, SafeCalculatorTool
        from fairlib.modules.mcp import MCPServer

        registry = ToolRegistry()
        registry.register_tool(SafeCalculatorTool())

        server = MCPServer(registry, name="fair_llm_tools")
        server.run()  # Blocks, runs stdio server

    For Claude Desktop integration, add to claude_desktop_config.json:
        {
          "mcpServers": {
            "fair_llm": {
              "command": "python",
              "args": ["/path/to/your/serve_mcp.py"]
            }
          }
        }
    """

    def __init__(
        self,
        tool_registry: AbstractToolRegistry,
        name: str = "fair_llm_tools",
        version: str = "1.0.0"
    ):
        """
        Initialize the MCP server.

        Args:
            tool_registry: Registry containing tools to expose.
            name: Server name for MCP identification.
            version: Server version.

        Raises:
            ImportError: If mcp library not installed.
        """
        if not MCP_INSTALLED:
            raise ImportError(
                "The 'mcp' library is not installed. "
                "Please install it with `pip install mcp` to run an MCP server."
            )

        self._registry = tool_registry
        self._name = name
        self._version = version
        self._server: Optional[Server] = None
        self._setup_server()

    def _setup_server(self) -> None:
        """Set up the MCP server with tool handlers."""
        self._server = Server(self._name)

        # Register the list_tools handler
        @self._server.list_tools()
        async def handle_list_tools() -> List[Tool]:
            """Handler for tools/list request."""
            tools = self._registry.get_all_tools()

            return [
                Tool(
                    name=tool.name,
                    description=tool.description or "No description available.",
                    inputSchema=self._get_input_schema(tool)
                )
                for tool in tools.values()
            ]

        # Register the call_tool handler
        @self._server.call_tool()
        async def handle_call_tool(name: str, arguments: Dict[str, Any]) -> Sequence[TextContent]:
            """Handler for tools/call request."""
            tool = self._registry.get_tool(name)

            if tool is None:
                return [TextContent(
                    type="text",
                    text=f"Error: Tool '{name}' not found"
                )]

            try:
                # Convert arguments to string input
                tool_input = self._arguments_to_input(arguments)

                # Execute the tool
                # Check if tool has async method
                if hasattr(tool, 'ause'):
                    result = await tool.ause(tool_input)
                else:
                    # Run sync tool in executor to not block
                    loop = asyncio.get_event_loop()
                    result = await loop.run_in_executor(None, tool.use, tool_input)

                return [TextContent(type="text", text=str(result))]

            except Exception as e:
                return [TextContent(
                    type="text",
                    text=f"Error executing tool '{name}': {str(e)}"
                )]

    def _get_input_schema(self, tool) -> Dict[str, Any]:
        """
        Get or infer the JSON schema for a tool's input.

        Args:
            tool: The tool to get schema for.

        Returns:
            JSON Schema dictionary for the tool's input.
        """
        # If tool has explicit schema, use it
        if hasattr(tool, 'input_schema') and tool.input_schema:
            return tool.input_schema

        # Default schema for string input tools
        return {
            "type": "object",
            "properties": {
                "input": {
                    "type": "string",
                    "description": "Input for the tool"
                }
            },
            "required": ["input"]
        }

    def _arguments_to_input(self, arguments: Dict[str, Any]) -> str:
        """
        Convert MCP arguments dict to the string format fair_llm tools expect.

        Args:
            arguments: Dictionary of arguments from MCP client.

        Returns:
            String input for the tool.
        """
        # If there's a single 'input' key, use its value directly
        if list(arguments.keys()) == ["input"]:
            return str(arguments["input"])

        # If there's a single key and it's a string, use it directly
        if len(arguments) == 1:
            value = list(arguments.values())[0]
            if isinstance(value, str):
                return value

        # Otherwise, serialize to JSON for tools that expect structured input
        return json.dumps(arguments)

    def run(self) -> None:
        """
        Run the MCP server (blocking).

        This starts the stdio server and blocks until terminated.
        Typically used as the main entry point for a server script.
        """
        print(f"Starting MCP server '{self._name}'...", file=sys.stderr)
        asyncio.run(self.arun())

    async def arun(self) -> None:
        """
        Run the MCP server asynchronously.

        Use this if you need to run the server within an existing
        async application.
        """
        async with stdio_server() as (read_stream, write_stream):
            init_options = self._server.create_initialization_options()
            await self._server.run(
                read_stream,
                write_stream,
                init_options
            )

    @property
    def name(self) -> str:
        """Return the server name."""
        return self._name

    @property
    def version(self) -> str:
        """Return the server version."""
        return self._version

    @property
    def tool_count(self) -> int:
        """Return the number of tools being served."""
        return len(self._registry.get_all_tools())
