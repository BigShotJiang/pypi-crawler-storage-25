# fairlib/modules/mcp/__init__.py
"""
MCP (Model Context Protocol) module for fair_llm.

This module provides both client and server capabilities for MCP:
- Client: Connect to external MCP servers and use their tools
- Server: Expose fair_llm tools as an MCP server

Example usage (client):
    from fairlib import ToolRegistry, SafeCalculatorTool
    from fairlib.modules.mcp import create_mcp_enhanced_registry
    from fairlib.core.config_schemas import MCPServerConfig

    local = ToolRegistry()
    local.register_tool(SafeCalculatorTool())

    configs = [MCPServerConfig(
        name="filesystem",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-filesystem", "/home/user"]
    )]

    registry = await create_mcp_enhanced_registry(local, mcp_configs=configs)

Example usage (server):
    from fairlib import ToolRegistry, SafeCalculatorTool
    from fairlib.modules.mcp import MCPServer

    registry = ToolRegistry()
    registry.register_tool(SafeCalculatorTool())

    server = MCPServer(registry)
    server.run()
"""
from typing import List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from fairlib.core.interfaces.tools import AbstractToolRegistry
    from fairlib.core.config_schemas import MCPServerConfig
    from .client.mcp_tool_registry import MCPToolRegistry
    from ..action.tools.composite_registry import CompositeToolRegistry


async def create_mcp_enhanced_registry(
    local_registry: 'AbstractToolRegistry',
    mcp_configs: Optional[List['MCPServerConfig']] = None,
    auto_load_from_settings: bool = True,
    tool_prefix: str = "mcp"
) -> 'CompositeToolRegistry':
    """
    Create a composite registry with both local and MCP tools.

    This is the recommended way to set up MCP client support. It combines
    your existing local tools with tools discovered from MCP servers.

    Args:
        local_registry: Your existing ToolRegistry with local tools.
        mcp_configs: Optional list of MCP server configs. If not provided
                    and auto_load_from_settings is True, loads from settings.yml.
        auto_load_from_settings: Whether to load MCP config from settings.
        tool_prefix: Prefix for MCP tool names (default: "mcp").

    Returns:
        CompositeToolRegistry with both local and MCP tools.

    Example:
        from fairlib import ToolRegistry, SafeCalculatorTool
        from fairlib.modules.mcp import create_mcp_enhanced_registry

        local = ToolRegistry()
        local.register_tool(SafeCalculatorTool())

        registry = await create_mcp_enhanced_registry(local)
        executor = ToolExecutor(registry)
    """
    from .client.mcp_tool_registry import MCPToolRegistry
    from ..action.tools.composite_registry import CompositeToolRegistry

    composite = CompositeToolRegistry([local_registry])

    # Load configs from settings if enabled and no explicit configs provided
    if auto_load_from_settings and mcp_configs is None:
        try:
            from fairlib.core.config import settings
            mcp_settings = getattr(settings, 'mcp', None)
            if mcp_settings and mcp_settings.enabled:
                mcp_configs = [c for c in mcp_settings.servers if c.enabled]
                tool_prefix = mcp_settings.tool_prefix
        except Exception:
            # Settings not configured or MCP not enabled
            pass

    if mcp_configs:
        mcp_registry = MCPToolRegistry(tool_prefix=tool_prefix)

        for config in mcp_configs:
            try:
                await mcp_registry.add_server(config)
                print(f"Connected to MCP server: {config.name}")
            except Exception as e:
                print(f"Warning: Failed to connect to MCP server '{config.name}': {e}")

        composite.add_registry(mcp_registry)

    return composite


# Lazy imports for convenience
def __getattr__(name: str):
    """Lazy loading of MCP components."""
    if name == "MCPClient":
        from .client.mcp_client import MCPClient
        return MCPClient
    elif name == "MCPToolAdapter":
        from .client.mcp_tool_adapter import MCPToolAdapter
        return MCPToolAdapter
    elif name == "MCPToolRegistry":
        from .client.mcp_tool_registry import MCPToolRegistry
        return MCPToolRegistry
    elif name == "MCPServer":
        from .server.mcp_server import MCPServer
        return MCPServer
    raise AttributeError(f"module 'fairlib.modules.mcp' has no attribute '{name}'")


__all__ = [
    "create_mcp_enhanced_registry",
    "MCPClient",
    "MCPToolAdapter",
    "MCPToolRegistry",
    "MCPServer",
]
