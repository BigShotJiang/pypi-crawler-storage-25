# fairlib.modules.memory/summarization.py
"""
Memory implementation that compresses long conversations via LLM summarization
to manage the context window. Honors the Message.importance="pinned" signal where
pinned messages survive summarization verbatim and are reinserted into the returned
history at their original relative positions.

Consumers receive a typed MemorySummarizedEvent payload through the optional
on_summarize callback. The callback is single-subscriber and synchronous;
P1.3 will generalize this to a multi-subscriber bus on SimpleAgent. Subscriber
exceptions are caught and logged so a misbehaving consumer cannot break the
agent loop.

The framework emits a one-time edge-triggered warning when the pinned message
count reaches 80 percent of max_history_length. Caller still owns the
context-budget responsibility; the framework does not silently drop pinned
messages even when over-pinning would defeat compression.
"""
import logging
from dataclasses import replace
from typing import Callable, List, Literal, Optional

from fairlib.core.errors import AdapterError
from fairlib.core.events import MemorySummarizedEvent
from fairlib.core.interfaces.llm import AbstractChatModel
from fairlib.core.interfaces.memory import AbstractMemory
from fairlib.core.message import Message

_logger = logging.getLogger(__name__)

# TODO:: persist to a config file. Downstream users should be able to tune
_PINNING_WARNING_FRACTION = 0.8


class SummarizingMemory(AbstractMemory):
    """
    A memory class that automatically summarizes the conversation history
    when it exceeds a specified length.

    This strategy helps manage the token count sent to the LLM, enabling longer
    conversations while saving on costs and preventing context window overflow.
    It works by keeping the first message, the most recent messages, and a
    generated summary of the messages in between. Messages with
    importance="pinned" survive summarization verbatim.
    """

    def __init__(
        self,
        llm: AbstractChatModel,
        max_history_length: int = 10,
        messages_to_keep_at_end: int = 4,
        on_summarize: Optional[Callable[[MemorySummarizedEvent], None]] = None,
    ):
        """
        Initializes the SummarizingMemory.

        Args:
            llm: An initialized chat model to be used for generating summaries.
            max_history_length: The number of messages to hold before summarization
                                is triggered.
            messages_to_keep_at_end: The number of recent messages to preserve
                                     verbatim, ensuring recent context is not lost.
            on_summarize: Optional callback fired exactly once per summarization
                          event with a MemorySummarizedEvent payload. The
                          callback is synchronous; subscribers that need async
                          work should spawn their own task.
        """
        # The LLM is a dependency, as it's required to perform the summarization.
        self.llm = llm
        self.history: List[Message] = []
        self.max_history_length = max_history_length
        self.messages_to_keep_at_end = messages_to_keep_at_end
        self.on_summarize = on_summarize

        # Edge-triggered latch for the 80 percent pinning warning. Tracks
        # whether the warning has already been emitted for the current
        # over-threshold streak. Resets when the pinned count drops back below.
        self._pinning_warning_active: bool = False

        # Ensure the number of messages to keep is less than the max history.
        if self.messages_to_keep_at_end >= self.max_history_length:
            raise ValueError("messages_to_keep_at_end must be less than max_history_length")

    def add_message(self, message: Message) -> None:
        """Adds a message to the conversation history."""
        self.history.append(message)
        self._check_pinning_threshold()

    def _check_pinning_threshold(self) -> None:
        """Edge-triggered check for the 80 percent pinning warning.

        Fires once when pinned count crosses from below to at-or-above the
        threshold. Resets when count drops back below so a subsequent crossing
        emits again.
        """
        pinned_count = sum(1 for m in self.history if m.importance == "pinned")
        threshold = _PINNING_WARNING_FRACTION * self.max_history_length
        is_over = pinned_count >= threshold
        if is_over and not self._pinning_warning_active:
            _logger.warning(
                "Pinned message count (%d) reached 80%% of max_history_length (%d). ",
                pinned_count,
                self.max_history_length,
            )
            self._pinning_warning_active = True
        elif not is_over and self._pinning_warning_active:
            self._pinning_warning_active = False

    def get_history(self) -> List[Message]:
        """
        Retrieves the conversation history.

        If the history is too long, this method returns a placeholder layout
        without actually performing summarization. The async aget_history is
        the supported summarization surface and is the only path that honors
        Message.importance="pinned". Sync callers are warned and should migrate
        to the async path.
        """
        # This is a simplified, blocking version. The async version is preferred.
        # A real-world sync implementation might use `asyncio.run(self.aget_history())`.
        if len(self.history) <= self.max_history_length:
            return self.history
        else:
            # The async version contains the full, correct logic. The sync
            # path returns a fixed placeholder layout and does not honor
            # pinning; consumers needing pinning support must call aget_history.
            _logger.warning(
                "get_history() called on SummarizingMemory with an over-limit history; "
                "sync mode is not fully implemented and pinning is not honored. Use aget_history()."
            )
            n = self.messages_to_keep_at_end
            tail = self.history[-n:] if n > 0 else []
            return self.history[:1] + [Message(role="system", content="...summary...")] + tail

    async def aget_history(self) -> List[Message]:
        """
        Asynchronously retrieves the conversation history, summarizing it if
        necessary.

        Honors Message.importance="pinned": pinned messages are excluded from
        the summarization input and reinserted into the returned history at
        their original relative positions. If on_summarize is set, fires
        exactly once per summarization with a MemorySummarizedEvent payload.

        On AdapterError from the summarization LLM, returns the verbatim
        history (no compression that round) and fires the event with a
        placeholder summary message and reason="adapter_failure_fallback".
        """
        if len(self.history) <= self.max_history_length:
            return self.history

        # Layout: [first] + middle + [last_n]. The summarization slice is the
        # subset of middle whose messages are NOT pinned. Pinned messages in
        # middle are excluded from the summary input and reinserted in order
        # between [first] and [summary].
        # Note: self.history[-0:] returns the full list, not an empty slice,
        # so messages_to_keep_at_end == 0 must be handled explicitly.
        first = self.history[0]
        n = self.messages_to_keep_at_end
        last_n = self.history[-n:] if n > 0 else []
        middle = self.history[1:len(self.history) - n] if n > 0 else self.history[1:]

        pinned_middle = [m for m in middle if m.importance == "pinned"]
        summarizable = [m for m in middle if m.importance != "pinned"]

        if not summarizable:
            # All messages in the summarizable slice are pinned.
            # Return verbatim history; do not fire the summarization event because no summarization
            # actually occurred.
            return self.history

        # Format the summarizable slice for the LLM.
        summarization_content = "\n".join(
            f"{m.role}: {m.content}" for m in summarizable
        )
        summarization_prompt = [
            Message(
                role="system",
                content="You are a conversation summarizer. Please provide a concise summary of the following exchange.",
            ),
            Message(role="user", content=summarization_content),
        ]

        try:
            summary_message = await self.llm.ainvoke(summarization_prompt)
        except AdapterError as exc:
            # Phase D recovery: do not compress this round. Return the verbatim
            # history. Fire the event with a typed placeholder so consumers can
            # observe the failed compression without inferring it.
            _logger.warning(
                "Summarization LLM failed (provider=%s): %s. Returning verbatim history.",
                getattr(exc, "provider", "unknown"),
                exc,
            )
            placeholder = Message(
                role="system",
                content="<summarization unavailable: adapter failure>",
            )
            # On the failure path, no compression occurred; the entire verbatim
            # history is preserved. event.kept therefore contains every message,
            # which differs in shape from the success path's
            # (first, *pinned_middle, *last_n). Subscribers iterating event.kept
            # to find anchors must tolerate both shapes.
            # Shallow-copy each kept Message so a subscriber that mutates
            # event.kept[i].content (or any other field) cannot bleed back
            # into self.history. Message is a mutable dataclass; the frozen
            # event payload cannot protect the inner Message's fields.
            self._emit_summarized_event(
                dropped=(),
                kept=tuple(replace(m) for m in self.history),
                summary=placeholder,
                reason="adapter_failure_fallback",
            )
            return self.history

        # Wrap the summary content with the existing format markers.
        summary_message.content = (
            "--- Start of Summarized Conversation ---\n"
            f"{summary_message.content}\n"
            "--- End of Summarized Conversation ---"
        )
        # Treat the summary as a system message in the reconstructed history.
        summary_message.role = "system"

        # Reconstruct: [first] + pinned-in-original-order + [summary] + last_n
        new_history = [first] + pinned_middle + [summary_message] + last_n
        self.history = new_history

        # Pass shallow copies of every kept Message and the summary into the
        # event so subscriber field mutation cannot bleed back into
        # self.history. Message is a mutable dataclass; the frozen event
        # payload cannot protect the inner Message's fields. dropped is safe
        # without copying — those messages were just removed from
        # self.history and have no remaining alias.
        self._emit_summarized_event(
            dropped=tuple(summarizable),
            kept=tuple(replace(m) for m in (first, *pinned_middle, *last_n)),
            summary=replace(summary_message),
            reason="max_history_length_exceeded",
        )

        return self.history

    def _emit_summarized_event(
        self,
        dropped: tuple[Message, ...],
        kept: tuple[Message, ...],
        summary: Message,
        reason: Literal[
            "max_history_length_exceeded",
            "adapter_failure_fallback",
        ],
    ) -> None:
        """Construct and dispatch the summarization event, isolating any
        subscriber exception so it cannot break the agent loop.
        """
        if self.on_summarize is None:
            return
        event = MemorySummarizedEvent(
            dropped=dropped,
            kept=kept,
            summary=summary,
            reason=reason,
        )
        try:
            self.on_summarize(event)
        except Exception:
            # A misbehaving subscriber must not break the agent loop. Log at
            # WARNING with exc_info so the traceback is captured but the
            # severity matches the recoverability of the situation.
            _logger.warning(
                "on_summarize subscriber raised; continuing without breaking the agent loop",
                exc_info=True,
            )

    def clear(self) -> None:
        """Clears the conversation history."""
        self.history = []
        self._pinning_warning_active = False
