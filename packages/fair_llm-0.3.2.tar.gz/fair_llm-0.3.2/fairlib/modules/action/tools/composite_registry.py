# fairlib/modules/action/tools/composite_registry.py
"""
A composite registry that combines multiple tool registries.

Allows using local tools and MCP tools together seamlessly.
"""
from typing import Dict, List, Optional

from fairlib.core.interfaces.tools import AbstractTool, AbstractToolRegistry


class CompositeToolRegistry(AbstractToolRegistry):
    """
    Combines multiple tool registries into a single interface.

    This allows the ToolExecutor to work with both local tools
    and MCP tools without any changes. Tools are looked up in order
    across all registries, with earlier registries having priority
    for duplicate tool names.

    Usage:
        local_registry = ToolRegistry()
        local_registry.register_tool(SafeCalculatorTool())

        mcp_registry = MCPToolRegistry()
        await mcp_registry.add_server(config)

        composite = CompositeToolRegistry([local_registry, mcp_registry])
        executor = ToolExecutor(composite)

    The executor and agents work exactly as before - they only see
    AbstractToolRegistry interface.
    """

    def __init__(self, registries: Optional[List[AbstractToolRegistry]] = None):
        """
        Initialize with a list of registries.

        Args:
            registries: List of registries to combine. First registry
                       has priority for duplicate tool names.
        """
        self._registries: List[AbstractToolRegistry] = registries or []

    def add_registry(self, registry: AbstractToolRegistry) -> None:
        """
        Add a registry to the composite.

        Args:
            registry: Registry to add. Will have lower priority than
                     previously added registries for duplicate names.
        """
        self._registries.append(registry)

    def insert_registry(self, index: int, registry: AbstractToolRegistry) -> None:
        """
        Insert a registry at a specific position.

        Args:
            index: Position to insert at (0 = highest priority).
            registry: Registry to insert.
        """
        self._registries.insert(index, registry)

    def remove_registry(self, registry: AbstractToolRegistry) -> None:
        """
        Remove a registry from the composite.

        Args:
            registry: Registry to remove.
        """
        self._registries.remove(registry)

    def register_tool(self, tool: AbstractTool) -> None:
        """
        Register a tool to the first (primary) registry.

        This allows the composite to be used as a drop-in replacement
        for a single registry, with new tools going to the primary
        (first) registry.

        Args:
            tool: Tool to register.

        Raises:
            ValueError: If no registries are configured.
        """
        if not self._registries:
            raise ValueError("No registries configured. Add at least one registry first.")
        self._registries[0].register_tool(tool)

    def get_tool(self, name: str) -> Optional[AbstractTool]:
        """
        Get a tool by name, checking registries in order.

        First match wins - earlier registries have priority.

        Args:
            name: Tool name to look up.

        Returns:
            Tool if found, None otherwise.
        """
        for registry in self._registries:
            tool = registry.get_tool(name)
            if tool is not None:
                return tool
        return None

    def get_all_tools(self) -> Dict[str, AbstractTool]:
        """
        Get all tools from all registries.

        Earlier registries have priority for duplicate names.

        Returns:
            Dictionary mapping tool names to tool instances.
        """
        all_tools: Dict[str, AbstractTool] = {}

        # Process in reverse order so first registry has priority
        for registry in reversed(self._registries):
            all_tools.update(registry.get_all_tools())

        return all_tools

    def get_tools_from_registry(self, index: int) -> Dict[str, AbstractTool]:
        """
        Get all tools from a specific registry by index.

        Args:
            index: Registry index (0 = first/primary registry).

        Returns:
            Dictionary of tools from that registry.

        Raises:
            IndexError: If index out of range.
        """
        return self._registries[index].get_all_tools()

    @property
    def registry_count(self) -> int:
        """Return number of registries in the composite."""
        return len(self._registries)

    @property
    def tool_count(self) -> int:
        """Return total number of unique tools across all registries."""
        return len(self.get_all_tools())

    def __len__(self) -> int:
        """Return total number of unique tools."""
        return self.tool_count
