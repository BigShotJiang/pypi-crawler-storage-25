# fairlib.modules.agent/simple_agent.py

"""
The Simple Agent module.

This module contains SimpleAgent, the primary concrete implementation of a
reasoning agent in the FAIR-LLM framework. It is the core workhorse that
powers most single-agent and worker-agent systems.

SimpleAgent orchestrates the fundamental cognitive cycle of an AI agent. It
connects the brain (the Planner), the hands (the Tool Executor), and the
memory into a cohesive loop, allowing the agent to perform multi-step
reasoning to solve problems. This loop is commonly known as the ReAct
(Reason + Act) pattern.
"""

import logging
from typing import List, Optional, Union

from fairlib.core.base_agent import BaseAgent
from fairlib.core.errors import (
    InvalidAgentInputError,
    MaxStepsExceeded,
    PlannerParseError,
    ToolInvocationError,
)
from fairlib.core.interfaces.executor import AbstractToolExecutor
from fairlib.core.interfaces.llm import AbstractChatModel
from fairlib.core.interfaces.memory import AbstractMemory
from fairlib.core.interfaces.planner import AbstractPlanner
from fairlib.core.message import Action, FinalAnswer, Message, Thought
from fairlib.core.prompts import AgentCapability

logger = logging.getLogger(__name__)


class SimpleAgent(BaseAgent):
    """
    An agent that uses a planner to reason and act in a loop. It can be
    configured to be stateful (for conversations) or stateless (for
    single-task execution as a worker).
    """
    def __init__(
        self,
        llm: AbstractChatModel,
        planner: AbstractPlanner,
        tool_executor: AbstractToolExecutor,
        memory: AbstractMemory,
        max_steps: int = 10,
        stateless: bool = False,
        capability: Optional['AgentCapability'] = None,
        role_description: Optional[str] = None
    ):
        """
        Initializes the SimpleAgent.

        Args:
            llm: The language model that powers the agent's planner.
            planner: The planning component that decides the next action.
            tool_executor: The component that executes tool actions.
            memory: The memory system for storing conversation history.
            max_steps: The maximum number of reasoning steps to prevent loops.
            stateless: If True, the agent clears its memory before each run,
                       making it suitable as a worker agent. Defaults to False.
        """
        self.llm = llm
        self.planner = planner
        self.tool_executor = tool_executor
        self.memory = memory
        self.max_steps = max_steps
        self.stateless = stateless
        self.capability = capability
        self.role_description: str = "A helpful AI assistant."

    async def arun(self, user_input: Union[str, Message]) -> str:
        """Run the agent's reasoning loop and return the final answer.

        Implements the ReAct cycle: plan, act, observe, repeat until the
        planner returns a FinalAnswer or max_steps is reached.

        Args:
            user_input: Either a plain string (the agent constructs a
                default user Message internally) or a pre-built Message
                with role="user". The Message form lets callers attach
                importance="pinned" or metadata to the user turn so
                those signals survive summarization in SummarizingMemory.

        Raises:
            InvalidAgentInputError: when user_input is a Message whose
                role is not "user". The user-turn entry point is
                contractually a user message; rejecting other roles
                early prevents silent memory corruption.
            PlannerParseError: when the planner fails to produce a
                parsable response on two consecutive attempts. The
                retry attempt with a corrective system message is
                handled internally; this surfaces only when retry is
                exhausted.
            AdapterError: when the LLM provider itself fails (timeout,
                quota, malformed response). Re-prompting cannot help.
            MaxStepsExceeded: when the loop reaches max_steps without
                the planner producing a FinalAnswer. Carries the
                accumulated history on partial_history.

        Returns:
            The agent's final answer as a string. Never returns a
            placeholder or apology copy on failure; failures raise.
        """
        # For stateless worker agents, clear memory at the start of each task.
        if self.stateless:
            self.memory.clear()

        if isinstance(user_input, Message):
            if user_input.role != "user":
                raise InvalidAgentInputError(
                    f"SimpleAgent.arun received a Message with role="
                    f"{user_input.role!r}; the user-turn entry point "
                    f"requires role='user'."
                )
            user_msg = user_input
            current_request = user_msg.content
        else:
            user_msg = Message(role="user", content=user_input)
            current_request = user_input

        turn_messages: List[Message] = [user_msg]

        _consecutive_parse_failures = 0

        for step in range(self.max_steps):
            logger.info(f"--- Step {step + 1}/{self.max_steps} ---")

            history = await self.memory.aget_history()

            # Parse errors are recoverable once via re-prompt; adapter
            # errors are not, and propagate immediately. After two
            # consecutive parse failures we give up and propagate too,
            # so the caller can route on the typed cause.
            try:
                plan_result = await self.planner.aplan(history, current_request)
                _consecutive_parse_failures = 0
            except PlannerParseError:
                _consecutive_parse_failures += 1
                if _consecutive_parse_failures < 2:
                    logger.warning(
                        "Planner returned empty/unparseable response "
                        "(attempt %d). Retrying.",
                        _consecutive_parse_failures,
                    )
                    retry_msg = Message(
                        role="system",
                        content=(
                            "Your previous response was empty or could not "
                            "be parsed. Restate your thought process and "
                            "try again. You MUST adhere to formatting instructions!"
                        ),
                    )
                    self.memory.add_message(retry_msg)
                    continue
                logger.error(
                    "Planner failed %d consecutive times. Propagating "
                    "PlannerParseError to caller.",
                    _consecutive_parse_failures,
                )
                raise

            if isinstance(plan_result, FinalAnswer):
                final_answer_text = plan_result.text
                logger.info(f"Thought: {final_answer_text}")
                logger.info("Action: Final Answer")
                # Dispatch memory serialization through the abstract
                # planner contract. The planner decides how its own
                # output must look in history so that the next turn's
                # prompt is consistent with its parser.
                turn_messages.append(
                    self.planner.format_turn_for_memory(plan_result)
                )
                for msg in turn_messages:
                    self.memory.add_message(msg)
                return final_answer_text

            try:
                thought, action = plan_result
            except (ValueError, TypeError) as exc:
                logger.error(
                    "Planner returned a value that is neither a "
                    "FinalAnswer nor a (Thought, Action) tuple: %r",
                    plan_result,
                )
                raise PlannerParseError(
                    "Planner returned a malformed plan_result. The "
                    "planner contract requires either a FinalAnswer "
                    "or a (Thought, Action) tuple.",
                    raw_output=repr(plan_result),
                ) from exc
            logger.info(f"Thought: {thought.text}")
            logger.info(f"Action: Using tool '{action.tool_name}' with input '{action.tool_input}'")

            # Memory format is owned by the planner — the agent only hands
            # the plan_result back to be serialized. This keeps SimpleAgent
            # free of any knowledge about concrete planner subclasses.
            turn_messages.append(
                self.planner.format_turn_for_memory(plan_result)
            )

            try:
                # Use async execution if available (for MCP tools, etc.)
                if hasattr(self.tool_executor, 'aexecute'):
                    observation_output = await self.tool_executor.aexecute(action.tool_name, action.tool_input)
                else:
                    observation_output = self.tool_executor.execute(action.tool_name, action.tool_input)
                logger.info(f"Observation: {observation_output}")
            except ToolInvocationError as exc:
                # Executor already typed the failure. Use the carried
                # tool_name verbatim so downstream consumers can route
                # on it without parsing the observation string.
                observation_output = (
                    f"Error in tool '{exc.tool_name}': {exc}"
                )
                logger.error(observation_output)
            except Exception as exc:
                # Executor raised an untyped error. Wrap it so the
                # tool-failure channel is uniform regardless of which
                # executor implementation is plugged in.
                wrapped = ToolInvocationError(
                    f"Tool '{action.tool_name}' raised: {exc}",
                    tool_name=action.tool_name,
                    raw_output=str(exc),
                )
                observation_output = (
                    f"Error in tool '{wrapped.tool_name}': {wrapped}"
                )
                logger.error(observation_output)

            # This creates the 'Observation' message for the LLM to react to in the next step.
            observation_message = Message(
                role="system",
                content=f"Observation: {str(observation_output)}"
            )
            turn_messages.append(observation_message)
            
            # Add all messages from this turn to the main memory.
            for msg in turn_messages:
                self.memory.add_message(msg)

            turn_messages = []
            
            # Clear the user request after the first turn.
            current_request = ""

        # Loop ended without a FinalAnswer. Raise so the caller can
        # route on cause and inspect partial_history if desired.
        exc = MaxStepsExceeded(
            self.max_steps,
            partial_history=await self.memory.aget_history(),
        )
        logger.warning(str(exc))
        raise exc

