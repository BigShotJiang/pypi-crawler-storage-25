# fairlib.modules.agent/multi_agent_runner.py
"""
Hierarchical multi-agent orchestrator.

This module implements a hierarchical multi-agent collaboration pattern, often
called the manager-worker or dispatcher model. It is designed for solving
complex problems that require multiple distinct steps or areas of expertise
that would be difficult for a single agent to handle alone.

The system is composed of a central manager agent that acts as a project lead
or dispatcher. The manager analyzes a complex task, breaks it down into
smaller logical sub-tasks, and delegates each sub-task to a specialized worker
agent. The workers execute their tasks and report the results back to the
manager, which then synthesizes the information into a final, comprehensive
answer.

Key components in this module:

1. ManagerPlanner — a specialized planner for the manager agent. Its sole
   purpose is to instruct the manager on how to delegate tasks. It uses a
   custom prompt designed to make the LLM think like a dispatcher.

2. HierarchicalAgentRunner — the central orchestrator that manages the entire
   workflow. It sits above the manager and the workers, passing tasks down and
   routing results back up.
"""

import asyncio
import json
import logging
import re
from typing import Dict, List, Any, Union, Tuple

# --- Core Framework Imports ---
from fairlib.core.interfaces.llm import AbstractChatModel
from fairlib.core.errors import MaxStepsExceeded, PlannerParseError
from fairlib.core.interfaces.planner import AbstractPlanner
from fairlib.core.base_agent import BaseAgent
from fairlib.core.message import Message, Thought, Action, FinalAnswer

# --- Prompt Engineering Imports ---
from fairlib.core.prompts import (
    PromptBuilder,
    RoleDefinition,
    FormatInstruction,
    Example
)

logger = logging.getLogger(__name__)


def _get_mandatory_manager_format_instructions() -> List[FormatInstruction]:
    """
    Returns the MANDATORY format instructions for the ManagerPlanner.

    These instructions are required for the parser to correctly interpret LLM output.
    They will be automatically prepended to any user-provided format instructions.
    """
    return [
        FormatInstruction(
            "# --- RESPONSE FORMAT (MANDATORY) ---\n"
            "Your response MUST contain EXACTLY ONE 'Thought' and ONE 'Action' block.\n"
            "The Action MUST be a single JSON object with 'tool_name' and 'tool_input'.\n\n"
            "Thought: [Your reasoning about what to do next]\n"
            "Action: {\"tool_name\": \"...\", \"tool_input\": ...}\n\n"
            "To delegate a task to a worker:\n"
            "Action: {\"tool_name\": \"delegate\", \"tool_input\": {\"worker_name\": \"WorkerName\", \"task\": \"The task description\"}}\n\n"
            "To provide a final answer:\n"
            "Action: {\"tool_name\": \"final_answer\", \"tool_input\": \"Your complete answer here\"}\n\n"
            "==> CRITICAL: Your response MUST end immediately after your Action JSON. "
            "Do NOT continue with more Thoughts or Actions. Do NOT simulate tool observations. "
            "Output exactly ONE Thought and ONE Action, then STOP."
        ),
        FormatInstruction(
            "# --- YOUR DECISION PROCESS ---\n"
            "On every turn, you must follow these steps:\n"
            "1. Look at the original 'User Request' to understand the overall goal.\n"
            "2. Look at the MOST RECENT message in the history. It will be a 'Tool Observation' from a worker if you have delegated a task.\n"
            "3. **Decide:** Based on the observation and the overall goal, what is the very next logical step?\n"
            "   - If you need more information to meet the goal, delegate the next sub-task to the correct worker.\n"
            "   - If the observation gives you all the information needed to complete the goal, use the 'final_answer' tool to provide the complete, synthesized answer.\n"
            "4. Output your Thought and Action, then STOP. Wait for the next turn."
        )
    ]


def _create_default_manager_prompt_builder() -> PromptBuilder:
    """
    Creates a robust, algorithm-driven prompt builder for the ManagerPlanner.

    Note: The mandatory format instructions are NOT included here because they
    are automatically merged in ManagerPlanner._prepare_and_build_messages().
    This allows the default builder to be customized without breaking the parser.
    """
    builder = PromptBuilder()
    builder.role_definition = RoleDefinition(
        "You are a manager agent. Your job is to analyze a user's request and delegate sub-tasks to your team of worker agents until the request is fully answered. You must follow the decision process and format rules perfectly."
    )
    # Note: Mandatory format instructions are merged automatically in aplan()
    builder.examples.append(
        Example(
            "User Request: Find the current price of gold and calculate how much 10 ounces would cost.\n\n"
            "Thought: The user request has two parts. I must delegate the FIRST step. The 'Researcher' is best for finding prices.\n"
            "Action: {\"tool_name\": \"delegate\", \"tool_input\": {\"worker_name\": \"Researcher\", \"task\": \"Find the current price of one ounce of gold.\"}}\n\n"
            "Tool Observation: Result from Researcher: The current price of one ounce of gold is $2,300.\n\n"
            "Thought: I have the price. I must delegate the NEXT step. The 'Analyst' is best for calculations.\n"
            "Action: {\"tool_name\": \"delegate\", \"tool_input\": {\"worker_name\": \"Analyst\", \"task\": \"Calculate 2300 * 10.\"}}\n\n"
            "Tool Observation: Result from Analyst: The result of '2300 * 10' is 23000.\n\n"
            "Thought: I have all the pieces. I will synthesize the final answer.\n"
            "Action: {\"tool_name\": \"final_answer\", \"tool_input\": \"Based on the current price of $2,300 per ounce, 10 ounces of gold would cost $23,000.\"}"
        )
    )
    return builder


class ManagerPlanner(AbstractPlanner):
    """
    A specialized planner for a manager agent that delegates tasks.
    This version uses robust JSON parsing and is truly asynchronous.

    The planner automatically merges mandatory format instructions with any
    user-provided prompt_builder, ensuring the parser always works correctly.
    """
    def __init__(self, llm: AbstractChatModel,
                 workers: Dict[str, BaseAgent],
                 prompt_builder: PromptBuilder = None):
        self.llm = llm
        self.workers = workers
        # Store user's builder separately to allow merging mandatory instructions
        self._user_prompt_builder = prompt_builder
        self._default_builder = _create_default_manager_prompt_builder()

    @property
    def prompt_builder(self) -> PromptBuilder:
        """
        Returns the effective prompt builder (user-provided or default).

        For backward compatibility with code that accesses planner.prompt_builder directly.
        """
        if self._user_prompt_builder is not None:
            return self._user_prompt_builder
        return self._default_builder

    @prompt_builder.setter
    def prompt_builder(self, value: PromptBuilder):
        """
        Set a custom prompt builder.

        Note: Mandatory format instructions will still be automatically merged.
        """
        self._user_prompt_builder = value

    def _prepare_and_build_messages(self, history: List[Message], user_input: str) -> List[Dict[str, str]]:
        """
        Prepare the prompt builder and build messages for the LLM.

        This method ensures mandatory format instructions are always included,
        even when a custom prompt_builder is provided.
        """
        if self._user_prompt_builder is not None:
            # User provided custom builder - merge mandatory instructions
            local_builder = self._user_prompt_builder.clone()
            mandatory_instructions = _get_mandatory_manager_format_instructions()
            # Prepend mandatory instructions to user's instructions
            local_builder.format_instructions = mandatory_instructions + local_builder.format_instructions
        else:
            # Use default builder - also needs mandatory instructions merged
            local_builder = self._default_builder.clone()
            mandatory_instructions = _get_mandatory_manager_format_instructions()
            local_builder.format_instructions = mandatory_instructions + local_builder.format_instructions

        # Add worker information
        local_builder.add_worker_dict(self.workers)
        return local_builder.build_message_list(history, user_input)

    async def aplan(self, history: List[Message], user_input: str) -> Union[FinalAnswer, Tuple[Thought, Action]]:
        """
        Asynchronously generates the manager's next plan.
        """
        messages = self._prepare_and_build_messages(history, user_input)

        # Use the proper async LLM call
        response_message = await self.llm.ainvoke(messages)

        # Use the robust JSON parser
        return self._parse_json_response(response_message.content)

    def plan(self, history: List[Message], user_input: str) -> Union[FinalAnswer, Tuple[Thought, Action]]:
        """Synchronous wrapper for aplan."""
        return asyncio.run(self.aplan(history, user_input))

    def format_turn_for_memory(
        self, step: Union[Tuple[Thought, Action], FinalAnswer]
    ) -> Message:
        """Serialize a manager plan step for storage in the manager's memory.

        For a (Thought, Action) tuple the runner historically stores only the
        thought text (the action drives delegation rather than history), so
        this method preserves that shape byte-for-byte. For a FinalAnswer
        the method emits the answer text directly; the default
        HierarchicalAgentRunner does not persist FinalAnswer turns, but
        subclasses or alternative runners may call this uniformly.
        """
        if isinstance(step, FinalAnswer):
            return Message(role="assistant", content=step.text)
        thought, _action = step
        return Message(role="assistant", content=thought.text)

    def _parse_json_response(self, response_text: str) -> Union[FinalAnswer, Tuple[Thought, Action]]:
        """Parse the manager's response under the strict delegation contract.

        Expects a JSON object with 'tool_name' and 'tool_input' keys. A
        leading 'Thought:' prefix before the JSON object is allowed. Any
        deviation raises PlannerParseError so the runner can re-prompt
        the manager rather than letting unstructured text reach the user.

        Raises:
            PlannerParseError: when the response does not contain a
                parsable JSON action block with the required keys. The
                original response text is preserved on the error's
                raw_output attribute.
        """
        try:
            from fairlib.utils.json_utils import safe_json_loads

            # Manager prompts may include a Thought: prose prefix before
            # the JSON object.
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if not json_match:
                raise ValueError("No JSON object found in the response.")

            action_json_str = json_match.group(0)
            thought_text = response_text.split(action_json_str)[0].strip()
            thought_text = re.sub(r'\*?\s*Thought\s*\*?:\s*', '', thought_text, flags=re.IGNORECASE).strip()

            action_data = safe_json_loads(action_json_str)
            tool_name = action_data.get("tool_name")
            tool_input = action_data.get("tool_input")

            if not tool_name or tool_input is None:
                raise KeyError("Parsed action JSON is missing 'tool_name' or 'tool_input'.")

            thought = Thought(text=thought_text if thought_text else "No thought provided.")

            if tool_name == "final_answer":
                return FinalAnswer(text=str(tool_input))

            return thought, Action(tool_name=tool_name, tool_input=tool_input)

        except (json.JSONDecodeError, KeyError, ValueError, AttributeError) as e:
            logger.warning("ManagerPlanner: response did not contain a parsable JSON action block.")
            raise PlannerParseError(
                "ManagerPlanner: LLM response did not contain a parsable "
                "JSON action block with the required keys. The planner "
                "contract requires a JSON object with 'tool_name' and "
                "'tool_input' (a 'Thought:' prefix before the JSON is "
                "allowed).",
                raw_output=response_text,
            ) from e


class HierarchicalAgentRunner:
    """Orchestrates a team of agents with a central manager and multiple workers."""
    def __init__(self, manager_agent: BaseAgent, workers: Dict[str, BaseAgent], max_steps: int = 15):
        self.manager = manager_agent
        self.workers = workers
        self.max_steps = max_steps
        
    async def arun(self, user_input: str) -> str:
        """Runs the hierarchical multi-agent workflow from start to finish."""
        logger.info(f"\n--- Running Hierarchical Team for Request: '{user_input}' ---")
        self.manager.memory.add_message(Message(role="user", content=user_input))

        current_request = user_input

        _consecutive_parse_failures = 0

        for i in range(self.max_steps):
            logger.info(f"\n--- Manager Turn {i+1}/{self.max_steps} ---")

            try:
                plan_result = await self.manager.planner.aplan(
                    self.manager.memory.get_history(), current_request
                )
                _consecutive_parse_failures = 0
            except PlannerParseError:
                _consecutive_parse_failures += 1
                if _consecutive_parse_failures < 2:
                    logger.warning(
                        "ManagerPlanner returned unparseable response "
                        "(attempt %d). Retrying.",
                        _consecutive_parse_failures,
                    )
                    retry_msg = Message(
                        role="system",
                        content=(
                            "Your previous response was not valid JSON or was "
                            "missing the required 'tool_name' and 'tool_input' "
                            "fields. Restate your delegation decision in the "
                            "required JSON format."
                        ),
                    )
                    self.manager.memory.add_message(retry_msg)
                    continue
                logger.error(
                    "ManagerPlanner failed %d consecutive times. "
                    "Propagating PlannerParseError to caller.",
                    _consecutive_parse_failures,
                )
                raise

            if isinstance(plan_result, FinalAnswer):
                logger.info(f"Manager has concluded the task with a final answer.")
                return plan_result.text

            try:
                thought, action = plan_result
            except (ValueError, TypeError) as exc:
                logger.error(
                    "ManagerPlanner returned a value that is neither a "
                    "FinalAnswer nor a (Thought, Action) tuple: %r",
                    plan_result,
                )
                raise PlannerParseError(
                    "ManagerPlanner returned a malformed plan_result. The "
                    "planner contract requires either a FinalAnswer or a "
                    "(Thought, Action) tuple.",
                    raw_output=repr(plan_result),
                ) from exc
            # Dispatch memory formatting through the planner so the runner
            # does not hard-code the manager's memory shape. Preserves the
            # legacy "thought-text-only" representation via
            # ManagerPlanner.format_turn_for_memory.
            self.manager.memory.add_message(
                self.manager.planner.format_turn_for_memory(plan_result)
            )
            logger.info(f"Manager Thought: {thought.text}")

            if action.tool_name == "delegate":
                if not isinstance(action.tool_input, dict):
                    error_msg = f"Error: Manager's delegate input was not a valid dictionary."
                    self.manager.memory.add_message(Message(role="tool", content=error_msg, name="delegate"))
                    continue
                worker_name = action.tool_input.get("worker_name")
                task = action.tool_input.get("task")
                
                # Case-insensitive worker lookup: LLMs may output
                # "safetyguard" instead of "SafetyGuard".
                resolved_name = None
                if worker_name:
                    for registered_name in self.workers:
                        if registered_name.lower() == worker_name.lower():
                            resolved_name = registered_name
                            break

                if resolved_name and task:
                    logger.info(f"Manager Action: Delegating task to '{resolved_name}': '{task}'")
                    worker = self.workers[resolved_name]
                    try:
                        worker_result = await worker.arun(task)
                    except Exception as e:
                        worker_result = f"Error: Worker '{resolved_name}' failed with exception: {e}"
                        logger.error(worker_result)
                    observation = f"Result from {resolved_name}: {worker_result}"
                    logger.info(f"Observation for Manager: {observation}")
                    # Use the 'system' role to provide observations from workers
                    self.manager.memory.add_message(Message(role="system", content=observation))

                else:
                    available = ", ".join(self.workers.keys())
                    error_msg = (
                        f"Error: Manager delegation failed. Worker '{worker_name}' not found or task not specified. "
                        f"Available workers: {available}"
                    )
                    logger.error(error_msg)
                    self.manager.memory.add_message(Message(role="tool", content=error_msg, name="delegate"))
            else:
                error_msg = f"Error: Manager attempted an invalid action '{action.tool_name}'."
                logger.error(error_msg)
                self.manager.memory.add_message(Message(role="tool", content=error_msg, name="delegate"))
            
            current_request = ""

        logger.warning("Agent team stopped after reaching max steps.")
        raise MaxStepsExceeded(
            self.max_steps,
            partial_history=self.manager.memory.get_history(),
        )