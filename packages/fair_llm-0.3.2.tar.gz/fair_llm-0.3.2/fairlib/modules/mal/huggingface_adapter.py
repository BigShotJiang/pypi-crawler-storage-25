# fairlib.modules.mal/huggingface_adapter.py

# TODO:: look into multi-GPU inference (v5 functionality)

"""
huggingface_adapter.py

A flexible adapter for running local Hugging Face transformer models as chat agents.
This module supports full precision and quantized models (via bitsandbytes),
streaming output, and CLI interaction. It wraps HuggingFace's transformers pipeline
into an interface that is agent-ready.

This module also includes:
- A CLI tool for interactive conversation with a model
- Alias-based model lookup
- Proper prompt formatting for chat models (with fallback)
- Dual compatibility with transformers v4 and v5
"""

import asyncio
import sys
import argparse
import os
from threading import Thread
from typing import List, Dict, Any, AsyncIterator, Iterator, Optional

# Import critical dependencies, detect install state
try:
    import torch
    TORCH_INSTALLED = True
except ImportError:
    TORCH_INSTALLED = False

try:
    from transformers import (
        AutoModelForCausalLM,
        AutoTokenizer,
        TextIteratorStreamer,
        pipeline,
        BitsAndBytesConfig
    )
    TRANSFORMERS_INSTALLED = True
except ImportError:
    TRANSFORMERS_INSTALLED = False

# [v5 CHANGE] Version detection — gates all v5-specific behavior in this module.
# Transformers v5 introduced several breaking changes:
#   - apply_chat_template() may return BatchEncoding instead of str
#   - Jinja2 chat templates reject unexpected dict keys (metadata, None fields)
#   - AsyncTextIteratorStreamer added for true async streaming
#   - attn_implementation kwarg added to from_pretrained()
# We detect the version once at import time so each method can branch accordingly.
# The try/except handles edge cases where transformers is mocked in tests.
TRANSFORMERS_V5 = False
if TRANSFORMERS_INSTALLED:
    try:
        from packaging.version import parse as parse_version
        import transformers
        TRANSFORMERS_V5 = parse_version(transformers.__version__) >= parse_version("5.0.0")
    except Exception:
        pass

from fairlib.core.errors import AdapterError
from fairlib.core.interfaces.llm import AbstractChatModel
from fairlib.core.message import Message

# Optional aliases for popular models
MODEL_REGISTRY = {

    # --- Dolphin Models ---
    "dolphin3-llama32-3b": "cognitivecomputations/Dolphin3.0-Llama3.2-3B",
    "dolphin3-llama31-8b": "cognitivecomputations/Dolphin3.0-Llama3.1-8B",
    "dolphin3-qwen25-0.5b": "cognitivecomputations/Dolphin3.0-Qwen2.5-0.5B",
    "dolphin3-qwen25-3b": "cognitivecomputations/Dolphin3.0-Qwen2.5-3b",
    "dolphin27-mixtral-8x7b": "cognitivecomputations/dolphin-2.7-mixtral-8x7b",

    # --- Mistral / Mixtral ---
    "mistral-7b": "mistralai/Mistral-7B-Instruct-v0.1",
    "mistral-8b": "mistralai/Ministral-8B-Instruct-2410",
    "mistral-nemo": "mistralai/Mistral-Nemo-Instruct-2407",
    "openhermes": "teknium/OpenHermes-2.5-Mistral-7B",
    "nous": "NousResearch/Nous-Hermes-2-Mixtral-8x7B-DPO",

    # --- Tiny and Fast Models ---
    "tinyllama": "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
    "phi": "microsoft/phi-2",
    "phi4-mini-r": "microsoft/Phi-4-mini-reasoning",
    "phi4": "microsoft/phi-4",

    # --- LLaMA 2 and 3 ---
    "llama2-7b": "meta-llama/Llama-2-7b-chat-hf",
    "llama2-13b": "meta-llama/Llama-2-13b-chat-hf",
    "llama3-8b": "meta-llama/Meta-Llama-3-8B-Instruct",
    "llama3-70b": "meta-llama/Llama-3.3-70B-Instruct",

    # --- Zephyr / RedPajama / DeepSeek ---
    "zephyr": "HuggingFaceH4/zephyr-7b-beta",
    "redpajama": "togethercomputer/RedPajama-INCITE-Chat-3B-v1",
    "deepseek-coder": "deepseek-ai/deepseek-coder-6.7b-instruct",

    # --- Reka R1 Family ---
    "reka-r1": "reka-ai/R1",
    "reka-mini": "reka-ai/R1-Mini",

    # --- Qwen 2.5 ---
    "qwen25-7b": "Qwen/Qwen2.5-7B-Instruct",
    "qwen25-14b": "Qwen/Qwen2.5-14B-Instruct",
    "qwen25-coder-7b": "Qwen/Qwen2.5-Coder-7B-Instruct",

    # --- Gemma 2/3 ---
    "gemma": "google/gemma-7b-it",
    "gemma2-9b": "google/gemma-2-9b-it",
    "gemma3-12b": "google/gemma-3-12b-it",

    # --- Other Good Models ---
    "openchat": "openchat/openchat-3.5-1210",
}


class HuggingFaceAdapter(AbstractChatModel):
    """
    Adapter for HuggingFace transformer models used in chat-style interactions.
    Supports both transformers v4 and v5.
    """
    def __init__(self, model_name: str = "dolphin3-llama32-3b",
                 quantized: bool = False, stream: bool = False,
                 auth_token: Optional[str] = None, **kwargs):

        self.model_name = MODEL_REGISTRY.get(model_name.lower(), model_name)
        self.verbose = kwargs.pop("verbose", True)
        self.enable_streaming = stream

        # [v5 CHANGE] HF_TOKEN is the standard env var recognized by huggingface_hub
        # and transformers v5. We check it first, with fallback to the legacy name
        # HUGGING_FACE_HUB_TOKEN for backwards compatibility with older setups.
        self.auth_token = auth_token or os.getenv("HF_TOKEN") or os.getenv("HUGGING_FACE_HUB_TOKEN")

        if not TORCH_INSTALLED or not TRANSFORMERS_INSTALLED:
            raise ImportError("This adapter requires both 'torch' and 'transformers' libraries.")

        if self.verbose:
            print(f"Loading HuggingFace model: {self.model_name} (quantized={quantized}, stream={stream})")

        loading_args = {"token": self.auth_token} if self.auth_token else {}

        self.tokenizer = self._load_tokenizer(loading_args)

        dtype = kwargs.pop("torch_dtype", kwargs.pop("dtype", "auto"))
        device_map = kwargs.pop("device_map", "auto")

        model_kwargs = {"device_map": device_map, **loading_args}

        if quantized:
            # BitsAndBytesConfig requires a concrete torch.dtype, not "auto"
            compute_dtype = dtype if isinstance(dtype, torch.dtype) else torch.float16
            model_kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True, bnb_4bit_compute_dtype=compute_dtype
            )
        else:
            # [v5 CHANGE] In transformers v5, `torch_dtype` was renamed to `dtype`
            # in from_pretrained(). Using the old name emits a deprecation warning.
            if TRANSFORMERS_V5:
                model_kwargs["dtype"] = dtype
            else:
                model_kwargs["torch_dtype"] = dtype

        # [v5 CHANGE] Auto-enable Scaled Dot-Product Attention (SDPA) on v5.
        # v5 exposes the attn_implementation kwarg on from_pretrained(). Setting
        # "sdpa" uses PyTorch's optimized attention kernel for significantly faster
        # inference. This kwarg does not exist in v4 and would cause an error.
        # Users can override via kwargs (e.g., attn_implementation="flash_attention_2").
        if TRANSFORMERS_V5:
            model_kwargs.setdefault("attn_implementation", "sdpa")

        self.model = self._load_model(model_kwargs)

        # Post-load: fix incomplete FP8 dequantization.
        # Some FP8 models (e.g. *-FP8) retain Float8 weights when loaded on
        # GPUs without native FP8 support (compute capability < 8.9).
        # Transformers logs "will dequantize to bf16" but may leave expert
        # layers in FP8, causing dtype mismatch crashes during forward passes.
        # We detect this and cast any remaining FP8 parameters to a usable dtype.
        self._reconcile_model_dtypes()

        self.default_gen_kwargs = {
            "max_new_tokens": kwargs.pop("max_new_tokens", 2048),
            "temperature": kwargs.pop("temperature", 0.7),
            "top_p": kwargs.pop("top_p", 0.9),
            "do_sample": True
        }

        try:
            self.generator = pipeline("text-generation", model=self.model, tokenizer=self.tokenizer, **kwargs)
        except Exception as e:
            self._raise_with_print(
                f"Failed to create text-generation pipeline for '{self.model_name}': {e}\n\n"
                "The model and tokenizer loaded successfully, but the generation pipeline "
                "could not be initialized. Possible causes:\n"
                "  - The model may not be a causal (text-generation) model. Models like\n"
                "    BERT, T5, or BART use different architectures and are not supported\n"
                "    by this adapter.\n"
                "  - A version mismatch between 'transformers' and 'torch'. Try:\n"
                "      pip install --upgrade transformers torch",
                cause=e,
            )

    def _raise_with_print(self, msg: str, exc_type=RuntimeError, cause=None):
        """Print a friendly error message (when verbose) and raise."""
        if self.verbose:
            print(f"\n[HuggingFaceAdapter] ERROR: {msg}\n")
        if cause is not None:
            raise exc_type(msg) from cause
        raise exc_type(msg)

    def _load_tokenizer(self, loading_args: dict):
        """Load tokenizer with student-friendly error messages."""
        try:
            return AutoTokenizer.from_pretrained(self.model_name, **loading_args)
        except ValueError as e:
            if "trust_remote_code" in str(e).lower():
                self._raise_with_print(
                    f"The model '{self.model_name}' requires custom code to load its tokenizer.\n\n"
                    "This model ships with custom Python code that must be explicitly trusted.\n"
                    "If you trust this model's source, pass trust_remote_code=True:\n"
                    "    HuggingFaceAdapter('model-name', trust_remote_code=True)\n\n"
                    "WARNING: Only do this for models from sources you trust — "
                    "trust_remote_code runs arbitrary Python from the model repo.",
                    cause=e,
                )
            self._raise_with_print(
                f"Failed to load tokenizer for '{self.model_name}': {e}",
                cause=e,
            )
        except OSError as e:
            err = str(e).lower()
            if "gated repo" in err or "401" in err:
                self._raise_with_print(
                    f"The model '{self.model_name}' is a gated model that requires access approval.\n\n"
                    "Steps to fix:\n"
                    "  1. Go to https://huggingface.co/{model} and accept the license agreement\n"
                    "  2. Create an access token at https://huggingface.co/settings/tokens\n"
                    "  3. Set the token: export HF_TOKEN=your_token_here\n"
                    "     Or pass it directly: HuggingFaceAdapter('model', auth_token='your_token')"
                    .format(model=self.model_name),
                    cause=e,
                )
            if "404" in err or "not found" in err:
                self._raise_with_print(
                    f"Model '{self.model_name}' was not found on HuggingFace Hub.\n\n"
                    "Double-check the model name for typos. You can search for models at:\n"
                    "  https://huggingface.co/models\n\n"
                    "Common format: 'organization/model-name' (e.g., 'meta-llama/Llama-3-8B-Instruct')",
                    cause=e,
                )
            self._raise_with_print(
                f"Failed to download tokenizer for '{self.model_name}': {e}\n\n"
                "Check your internet connection and try again. If you are behind a firewall\n"
                "or proxy, ensure HuggingFace Hub (huggingface.co) is accessible.",
                cause=e,
            )
        except Exception as e:
            self._raise_with_print(
                f"Unexpected error loading tokenizer for '{self.model_name}': {e}",
                cause=e,
            )

    def _load_model(self, model_kwargs: dict):
        """Load model with student-friendly error messages."""
        try:
            return AutoModelForCausalLM.from_pretrained(self.model_name, **model_kwargs)
        except (ImportError, NameError, ModuleNotFoundError) as e:
            self._raise_with_print(
                f"Failed to load '{self.model_name}': {e}\n\n"
                "This usually means the model requires a quantization library that is "
                "not installed. Common fixes:\n"
                "  - GPTQ models:  pip install optimum auto-gptq\n"
                "  - AWQ models:   pip install autoawq\n"
                "  - GGUF models:  use llama-cpp-python instead of this adapter\n"
                "If the model is not quantized, check that 'torch' and 'transformers' "
                "are up to date.",
                exc_type=ImportError,
                cause=e,
            )
        except RuntimeError as e:
            err = str(e).lower()
            if "cuda out of memory" in err or ("cuda" in err and "out of memory" in err):
                self._raise_with_print(
                    f"GPU out of memory while loading '{self.model_name}'.\n\n"
                    "The model is too large for your available GPU memory. Try:\n"
                    "  1. Use a quantized model: HuggingFaceAdapter('model', quantized=True)\n"
                    "  2. Use a smaller model (e.g., a 3B or 7B parameter variant)\n"
                    "  3. Free GPU memory: check what's using your GPU with 'nvidia-smi'\n"
                    "  4. If on a shared machine, wait for other jobs to finish",
                    cause=e,
                )
            self._raise_with_print(
                f"Failed to load model '{self.model_name}': {e}",
                cause=e,
            )
        except ValueError as e:
            if "trust_remote_code" in str(e).lower():
                self._raise_with_print(
                    f"The model '{self.model_name}' requires custom code to load.\n\n"
                    "This model ships with custom Python code that must be explicitly trusted.\n"
                    "If you trust this model's source, pass trust_remote_code=True:\n"
                    "    HuggingFaceAdapter('model-name', trust_remote_code=True)\n\n"
                    "WARNING: Only do this for models from sources you trust — "
                    "trust_remote_code runs arbitrary Python from the model repo.",
                    cause=e,
                )
            self._raise_with_print(
                f"Failed to load model '{self.model_name}': {e}",
                cause=e,
            )
        except OSError as e:
            err = str(e).lower()
            if "gated repo" in err or "401" in err:
                self._raise_with_print(
                    f"The model '{self.model_name}' is a gated model that requires access approval.\n\n"
                    "Steps to fix:\n"
                    "  1. Go to https://huggingface.co/{model} and accept the license agreement\n"
                    "  2. Create an access token at https://huggingface.co/settings/tokens\n"
                    "  3. Set the token: export HF_TOKEN=your_token_here\n"
                    "     Or pass it directly: HuggingFaceAdapter('model', auth_token='your_token')"
                    .format(model=self.model_name),
                    cause=e,
                )
            if "404" in err or "not found" in err:
                self._raise_with_print(
                    f"Model '{self.model_name}' was not found on HuggingFace Hub.\n\n"
                    "Double-check the model name for typos. You can search for models at:\n"
                    "  https://huggingface.co/models\n\n"
                    "If you're trying to load a non-causal model (like BERT, T5, or BART),\n"
                    "note that this adapter only supports causal (text-generation) models.",
                    cause=e,
                )
            self._raise_with_print(
                f"Failed to download model '{self.model_name}': {e}\n\n"
                "Check your internet connection and try again. If you are behind a firewall\n"
                "or proxy, ensure HuggingFace Hub (huggingface.co) is accessible.",
                cause=e,
            )
        except Exception as e:
            self._raise_with_print(
                f"Unexpected error loading model '{self.model_name}': {e}",
                cause=e,
            )

    # Also detect torch.cuda.OutOfMemoryError (PyTorch 1.13+) at module level
    _OOM_EXCEPTIONS = (RuntimeError,)
    if TORCH_INSTALLED and hasattr(torch, "cuda") and hasattr(torch.cuda, "OutOfMemoryError"):
        _OOM_EXCEPTIONS = (RuntimeError, torch.cuda.OutOfMemoryError)

    def _reconcile_model_dtypes(self):
        """
        Ensures all model parameters share a compute-compatible dtype.

        FP8-quantized models loaded on GPUs without native FP8 support
        (compute capability < 8.9) may retain Float8 weights despite
        transformers' attempted auto-dequantization.  This scans for any
        remaining FP8 parameters and casts them in-place to the dominant
        non-FP8 dtype already present in the model (typically bfloat16).

        Parameter-level casting preserves device placement for models
        distributed across multiple devices via device_map="auto".
        """
        fp8_params = []
        dtype_counts: Dict[str, int] = {}

        for name, param in self.model.named_parameters():
            dtype_str = str(param.dtype)
            dtype_counts[dtype_str] = dtype_counts.get(dtype_str, 0) + 1
            if "float8" in dtype_str:
                fp8_params.append((name, param))

        if not fp8_params:
            return

        # Pick the most common non-FP8 dtype as cast target (usually bfloat16)
        non_fp8 = {k: v for k, v in dtype_counts.items() if "float8" not in k}
        if non_fp8:
            target_name = max(non_fp8, key=non_fp8.get)
            # Map the string back to a torch dtype
            target_dtype = next(
                p.dtype for p in self.model.parameters()
                if str(p.dtype) == target_name
            )
        else:
            target_dtype = torch.bfloat16

        if self.verbose:
            print(
                f"[HuggingFaceAdapter] Detected {len(fp8_params)} FP8 parameter(s) "
                f"incompatible with this GPU. Casting to {target_dtype}. "
                f"This may increase memory usage."
            )

        for name, param in fp8_params:
            param.data = param.data.to(dtype=target_dtype)

    def _prepare_messages(self, messages: List[Message]) -> List[Dict[str, Any]]:
        """
        Convert Message objects to clean dicts with only populated fields.

        [v5 CHANGE] This method replaces the old Message.to_dict() / asdict() approach.
        The old code dumped every dataclass field, producing dicts like:
            {"role": "user", "content": "hi", "name": None, "tool_calls": None,
             "tool_call_id": None, "metadata": {}}
        In v4, apply_chat_template was lenient and ignored extra keys. In v5, the
        Jinja2 chat templates became strict — unexpected keys like "metadata" or
        None-valued fields cause template rendering errors or get inserted literally
        into the prompt. This method only includes fields that are actually set.
        """
        prepared = []
        for msg in messages:
            msg_dict = {"role": msg.role, "content": msg.content or ""}
            if msg.name:
                msg_dict["name"] = msg.name
            if msg.tool_calls:
                msg_dict["tool_calls"] = msg.tool_calls
            if msg.tool_call_id:
                msg_dict["tool_call_id"] = msg.tool_call_id
            prepared.append(msg_dict)
        return prepared

    def _format_prompt(self, messages: List[Message]) -> str:
        """
        Formats a list of Message objects into a single, correctly formatted
        prompt string using the tokenizer's chat template.

        [v5 CHANGE] In v4, apply_chat_template(tokenize=False) always returns a
        plain string. In v5, some tokenizers return a BatchEncoding object instead
        (a dict-like with input_ids, attention_mask, etc.). The old code passed
        this directly to the pipeline and crashed. We now check the return type:
          - str -> use directly (v4 behavior, also works on most v5 tokenizers)
          - BatchEncoding (has input_ids) -> decode back to string
          - anything else -> str() fallback
        """
        try:
            chat_history = self._prepare_messages(messages)
            templated = self.tokenizer.apply_chat_template(
                chat_history, tokenize=False, add_generation_prompt=True
            )
            if isinstance(templated, str):
                return templated
            # [v5 CHANGE] Handle BatchEncoding return — decode token ids back to text
            if hasattr(templated, "input_ids"):
                return self.tokenizer.decode(templated.input_ids[0], skip_special_tokens=False)
            return str(templated)
        except Exception:
            # Fallback for models without a chat template
            return "\n".join(f"{msg.role}: {msg.content}" for msg in messages)

    def _is_oom_error(self, e: Exception) -> bool:
        """Check if an exception is a CUDA out-of-memory error."""
        if hasattr(torch, "cuda") and hasattr(torch.cuda, "OutOfMemoryError"):
            if isinstance(e, torch.cuda.OutOfMemoryError):
                return True
        return isinstance(e, RuntimeError) and "cuda out of memory" in str(e).lower()

    def invoke(self, messages: List[Message], **kwargs) -> Message:
        """
        Synchronously generates a chat response given message history.

        [v5 CHANGE] Uses return_full_text=False instead of the old approach of
        slicing the prompt off by string length: result[0]['generated_text'][len(prompt):]
        That slicing is fragile — if the tokenizer re-encodes the prompt slightly
        differently (which v5 does in some cases), the slice index is wrong and
        output is garbled. return_full_text=False works correctly on both v4 and v5.
        """
        self._check_context_window_usage(messages)
        try:
            prompt_string = self._format_prompt(messages)

            # [v5 CHANGE] In v5, passing generation kwargs (max_new_tokens, temperature, etc.)
            # as loose arguments alongside the pipeline's built-in generation_config is
            # deprecated. We wrap them in a GenerationConfig object instead. We also set
            # max_length=None to avoid the "both max_new_tokens and max_length set" warning
            # (the model's default generation_config has max_length=20).
            # On v4, we pass all generation kwargs directly as before.
            if TRANSFORMERS_V5:
                from transformers import GenerationConfig
                merged_kwargs = {**self.default_gen_kwargs, **kwargs, "max_length": None}
                gen_config = GenerationConfig(**merged_kwargs)
                result = self.generator(prompt_string, generation_config=gen_config, return_full_text=False)
            else:
                generation_args = {**self.default_gen_kwargs, **kwargs, "return_full_text": False}
                result = self.generator(prompt_string, **generation_args)

            assistant_reply = result[0]['generated_text'].strip()
            return Message(role="assistant", content=assistant_reply)
        except Exception as e:
            if self._is_oom_error(e):
                error_msg = (
                    f"GPU out of memory during inference with '{self.model_name}'. "
                    "Try reducing max_new_tokens, shortening conversation history, "
                    "or using a quantized/smaller model."
                )
            else:
                error_msg = f"Inference failed (invoke): {e}"
            raise AdapterError(
                error_msg,
                provider="huggingface",
                raw_output=str(e),
            ) from e

    async def ainvoke(self, messages: List[Message], **kwargs) -> Message:
        """Async version of invoke, using a background thread.

        Raises:
            AdapterError: AdapterError raised inside invoke() propagates
                through unchanged so callers see one typed failure mode.
        """
        return await asyncio.to_thread(self.invoke, messages, **kwargs)

    def stream(self, messages: List[Message], **kwargs) -> Iterator[Message]:
        """
        Streams chat response tokens using TextIteratorStreamer and a background thread.

        [v5 CHANGE] Replaced the old TextStreamer (which only prints to stdout and
        cannot be iterated) with TextIteratorStreamer (produces an iterable queue).
        A background Thread runs model.generate() while the caller iterates chunks.
        This works on both v4 and v5.
        """
        if not self.enable_streaming:
            raise NotImplementedError("Streaming not enabled for this instance")

        try:
            prompt_string = self._format_prompt(messages)
            inputs = self.tokenizer(prompt_string, return_tensors="pt").to(self.model.device)

            streamer = TextIteratorStreamer(self.tokenizer, skip_prompt=True)
            generation_args = {**self.default_gen_kwargs, **kwargs}
            generation_args.pop("return_full_text", None)
            generation_args["streamer"] = streamer

            thread = Thread(target=self.model.generate, kwargs={**inputs, **generation_args})
            thread.start()

            for text_chunk in streamer:
                if text_chunk:
                    yield Message(role="assistant", content=text_chunk)

            thread.join()
        except Exception as e:
            if self._is_oom_error(e):
                error_msg = (
                    f"GPU out of memory during streaming with '{self.model_name}'.\n"
                    "Try reducing max_new_tokens, shortening conversation history, "
                    "or using a quantized/smaller model."
                )
            else:
                error_msg = f"An error occurred during inference (stream): {e}"
            print(error_msg)
            yield Message(role="assistant", content=f"Error: {error_msg}")

    async def astream(self, messages: List[Message], **kwargs) -> AsyncIterator[Message]:
        """
        Async streaming.

        [v5 CHANGE] Transformers v5 added AsyncTextIteratorStreamer, which is a
        native async iterable — it integrates with "async for" without blocking
        the event loop. On v4, this class does not exist, so we fall back to
        ainvoke() and yield a single complete Message.
        """
        if not self.enable_streaming:
            raise NotImplementedError("Streaming not enabled for this instance")

        try:
            # [v5 CHANGE] Use AsyncTextIteratorStreamer for true non-blocking async streaming
            if TRANSFORMERS_V5:
                from transformers import AsyncTextIteratorStreamer

                prompt_string = self._format_prompt(messages)
                inputs = self.tokenizer(prompt_string, return_tensors="pt").to(self.model.device)

                async_streamer = AsyncTextIteratorStreamer(self.tokenizer, skip_prompt=True)
                generation_args = {**self.default_gen_kwargs, **kwargs}
                generation_args.pop("return_full_text", None)
                generation_args["streamer"] = async_streamer

                thread = Thread(target=self.model.generate, kwargs={**inputs, **generation_args})
                thread.start()

                async for text_chunk in async_streamer:
                    if text_chunk:
                        yield Message(role="assistant", content=text_chunk)

                thread.join()
            else:
                # [v4 FALLBACK] AsyncTextIteratorStreamer does not exist in v4,
                # so we delegate to ainvoke() and yield a single complete Message.
                result = await self.ainvoke(messages, **kwargs)
                yield result
        except Exception as e:
            if self._is_oom_error(e):
                error_msg = (
                    f"GPU out of memory during async streaming with '{self.model_name}'.\n"
                    "Try reducing max_new_tokens, shortening conversation history, "
                    "or using a quantized/smaller model."
                )
            else:
                error_msg = f"An error occurred during inference (astream): {e}"
            print(error_msg)
            yield Message(role="assistant", content=f"Error: {error_msg}")

    def estimate_token_count(self, text: str) -> int:
        """Uses the real tokenizer for accurate token counting."""
        return len(self.tokenizer.encode(text))

    def get_model_capabilities(self) -> Dict[str, Any]:
        capabilities = {
            "function_calling": False,
            "streaming": self.enable_streaming,
            "tool_calling": False,
        }
        # Some tokenizers advertise a 128K-style context via sliding-window
        # scaling (e.g. YaRN) that is not active by default. The model's
        # max_position_embeddings is the hard positional limit and is the
        # safer upper bound. Take the minimum of the two to avoid warning
        # users they're "fine" well past the real cliff.
        tokenizer_max = getattr(self.tokenizer, "model_max_length", None)
        model_config = getattr(self.model, "config", None)
        config_max = getattr(model_config, "max_position_embeddings", None)

        candidates = [
            v for v in (tokenizer_max, config_max)
            if isinstance(v, int) and 0 < v < 10_000_000
        ]
        if candidates:
            capabilities["max_context_window"] = min(candidates)
        return capabilities


def run_cli():
    """
    Simple command-line interface to interact with a local LLM using the adapter.
    """
    parser = argparse.ArgumentParser(description="Run HuggingFace LLM in CLI")
    parser.add_argument("--model", type=str, default="mistral-7b", help="Model name or alias")
    parser.add_argument("--quant", action="store_true", help="Use quantized (4-bit) model")
    parser.add_argument("--stream", action="store_true", help="Enable streaming output")
    parser.add_argument("--token", type=str, default=None, help="Hugging Face Hub authentication token.")
    args = parser.parse_args()

    print(f"Using model: {args.model} (quantized={args.quant})")
    adapter = HuggingFaceAdapter(
        model_name=args.model,
        quantized=args.quant,
        stream=args.stream,
        auth_token=args.token
    )

    print("\nType 'exit' to quit.\n")

    history = []
    while True:
        try:
            user_input = input("You: ")
            if user_input.lower() in ["exit", "quit"]:
                break

            history.append(Message(role="user", content=user_input))

            response = adapter.invoke(history)

            if not args.stream:
                 print(f"Assistant: {response.content}\n")

            history.append(response)

        except KeyboardInterrupt:
            print("\nExiting...")
            break
        except Exception as e:
            print(f"\nAn unexpected error occurred: {e}", file=sys.stderr)

if __name__ == "__main__":
    run_cli()
