# fairlib.modules.mal/load_balancer_adapter.py

"""
load_balancer_adapter.py

A Model Abstraction Layer (MAL) adapter for connecting to a vLLM Load Manager.
This adapter routes chat requests to a distributed vLLM backend that handles
model loading and load balancing across multiple GPU nodes.

Features:
- Sends full chat history with each request (OpenAI-compatible format)
- Validates model against supported models endpoint on initialization
- Sends a dummy request to pre-load the model on initialization
- Retries once on timeout or queue full errors with informative logging
"""

import asyncio
import requests
from typing import List, Dict, Any, Iterator, AsyncIterator, Optional

from fairlib.core.errors import AdapterError
from fairlib.core.interfaces.llm import AbstractChatModel
from fairlib.core.message import Message


class LoadBalancerAdapter(AbstractChatModel):
    """
    Adapter for vLLM Load Manager that distributes chat requests across GPU nodes.
    
    This adapter connects to a vLLM load manager service and forwards chat requests
    in OpenAI-compatible format. It handles model validation, pre-loading, and
    automatic retry on transient failures.
    """
    
    def __init__(
        self, 
        manager_ip: str, 
        model: str,
        port: int = 8123,
        timeout: int = 1000,
        verbose: bool = True,
        preload_model: bool = True,
        **kwargs
    ):
        """
        Initialize the load balancer adapter.
        
        Args:
            manager_ip: IP address of the vLLM load manager
            model: Model identifier (e.g., "mistralai/Mistral-7B-Instruct-v0.3")
            port: Port of the load manager (default: 8123)
            timeout: Request timeout in seconds (default: 300)
            verbose: Whether to print status messages (default: True)
            preload_model: Whether to send a dummy request to load the model (default: True)
            **kwargs: Additional generation parameters (temperature, max_tokens, etc.)
        """
        self.manager_ip = manager_ip
        self.port = port
        self.model = model
        self.timeout = timeout
        self.verbose = verbose
        
        self.base_url = f"http://{manager_ip}:{port}"
        
        # Default generation parameters
        self.default_gen_kwargs = {
            "temperature": kwargs.pop("temperature", 0.7),
            "max_tokens": kwargs.pop("max_tokens", 512),
        }
        self.default_gen_kwargs.update(kwargs)
        
        if self.verbose:
            print(f"🔧 Initializing load balancer adapter for model: {self.model}")
            print(f"   Manager: {self.base_url}")
        
        # Validate that the model is supported
        self._validate_model()
        
        # Pre-load the model by sending a dummy request
        if preload_model:
            self._preload_model()
    
    def _validate_model(self) -> None:
        """
        Check that the requested model is in the supported models list.
        
        Raises:
            ValueError: If the model is not supported
            ConnectionError: If unable to connect to the load manager
        """
        try:
            response = requests.get(
                f"{self.base_url}/supported_models",
                timeout=30
            )
            response.raise_for_status()
            
            data = response.json()
            supported_models = data.get("supported_models", [])
            
            if self.model not in supported_models:
                raise ValueError(
                    f"Model '{self.model}' is not in the supported models list. "
                    f"Available models: {supported_models}"
                )
            
            if self.verbose:
                print(f"✓ Model '{self.model}' is supported")
                
        except requests.exceptions.RequestException as e:
            raise ConnectionError(
                f"Failed to connect to load manager at {self.base_url}: {e}"
            )
    
    def _preload_model(self) -> None:
        """
        Send a dummy request to trigger model loading on a node.
        This ensures the model is ready for subsequent requests.
        """
        if self.verbose:
            print(f"🔄 Pre-loading model '{self.model}' on a node...")
        
        dummy_messages = [{"role": "user", "content": "Hello"}]
        
        try:
            response = self._send_chat_request(dummy_messages, max_tokens=1)
            if self.verbose:
                print(f"✓ Model '{self.model}' is loaded and ready")
        except Exception as e:
            if self.verbose:
                print(f"⚠ Warning: Pre-load request failed: {e}")
                print("  The model will be loaded on the first actual request.")
    
    def _send_chat_request(
        self, 
        messages: List[Dict[str, Any]], 
        retry: bool = True,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Send a chat request to the load manager with retry logic.
        
        Args:
            messages: List of message dictionaries in OpenAI format
            retry: Whether to retry on transient failures (default: True)
            **kwargs: Additional generation parameters
            
        Returns:
            The parsed JSON response from the API
            
        Raises:
            RuntimeError: If the request fails after retries
        """
        gen_kwargs = {**self.default_gen_kwargs, **kwargs}
        
        payload = {
            "model": self.model,
            "messages": messages,
            **gen_kwargs
        }
        
        for attempt in range(2 if retry else 1):
            try:
                response = requests.post(
                    f"{self.base_url}/chat",
                    json=payload,
                    timeout=self.timeout
                )
                
                # Check for queue full or temporary errors (503)
                if response.status_code == 503:
                    error_msg = response.json().get("error", "No online nodes available")
                    if attempt == 0 and retry:
                        print(f"⚠ Queue full or no nodes available: {error_msg}")
                        print("  Retrying in 5 seconds...")
                        import time
                        time.sleep(5)
                        continue
                    else:
                        raise RuntimeError(f"Service unavailable after retry: {error_msg}")
                
                response.raise_for_status()
                return response.json()
                
            except requests.exceptions.Timeout:
                if attempt == 0 and retry:
                    print(f"⚠ Request timed out after {self.timeout}s")
                    print("  Retrying once...")
                    continue
                else:
                    raise RuntimeError(
                        f"Request timed out after {self.timeout}s (after retry)"
                    )
                    
            except requests.exceptions.RequestException as e:
                # Check if it's a response error we can parse
                if hasattr(e, 'response') and e.response is not None:
                    try:
                        error_data = e.response.json()
                        error_msg = error_data.get("error", str(e))
                    except:
                        error_msg = str(e)
                else:
                    error_msg = str(e)
                
                if attempt == 0 and retry:
                    print(f"⚠ Request failed: {error_msg}")
                    print("  Retrying once...")
                    import time
                    time.sleep(2)
                    continue
                else:
                    raise RuntimeError(f"Request failed after retry: {error_msg}")
        
        raise RuntimeError("Unexpected error in request loop")
    
    def _messages_to_api_format(self, messages: List[Message]) -> List[Dict[str, Any]]:
        """
        Convert Message objects to OpenAI-compatible API format.
        
        Args:
            messages: List of Message objects
            
        Returns:
            List of dictionaries with role and content keys
        """
        api_messages = []
        for msg in messages:
            api_msg = {
                "role": msg.role,
                "content": msg.content
            }
            # Include tool_call_id if present (for tool responses)
            if msg.tool_call_id:
                api_msg["tool_call_id"] = msg.tool_call_id
            if msg.name:
                api_msg["name"] = msg.name
            api_messages.append(api_msg)
        return api_messages
    
    def invoke(self, messages: List[Message], **kwargs) -> Message:
        """
        Synchronously send a chat request and get a response.

        Args:
            messages: List of Message objects representing the conversation history
            **kwargs: Additional generation parameters (temperature, max_tokens, etc.)

        Returns:
            A Message object containing the assistant's response

        Raises:
            AdapterError: on transport failure, retry exhaustion, or a
                response with no choices. The original RuntimeError /
                request exception is chained via __cause__.
        """
        api_messages = self._messages_to_api_format(messages)

        try:
            response = self._send_chat_request(api_messages, **kwargs)
        except RuntimeError as e:
            raise AdapterError(
                f"Load balancer request failed: {e}",
                provider="load_balancer",
                raw_output=str(e),
            ) from e

        # Extract the assistant's reply from OpenAI-compatible response
        choices = response.get("choices", [])
        if not choices:
            raise AdapterError(
                "Load balancer returned a response with no choices.",
                provider="load_balancer",
                raw_output=str(response),
            )

        assistant_message = choices[0].get("message", {})
        content = assistant_message.get("content", "")

        return Message(role="assistant", content=content)
    
    async def ainvoke(self, messages: List[Message], **kwargs) -> Message:
        """
        Asynchronously send a chat request and get a response.
        Uses a background thread for the HTTP request.
        
        Args:
            messages: List of Message objects representing the conversation history
            **kwargs: Additional generation parameters
            
        Returns:
            A Message object containing the assistant's response
        """
        return await asyncio.to_thread(self.invoke, messages, **kwargs)
    
    def stream(self, messages: List[Message], **kwargs) -> Iterator[Message]:
        """
        Streaming is not supported by the load manager.
        Falls back to returning the full response as a single message.
        
        Args:
            messages: List of Message objects
            **kwargs: Additional generation parameters
            
        Yields:
            A single Message object with the complete response
        """
        # Load manager doesn't expose streaming - return full response
        yield self.invoke(messages, **kwargs)
    
    async def astream(self, messages: List[Message], **kwargs) -> AsyncIterator[Message]:
        """
        Async streaming fallback - returns full response.
        
        Args:
            messages: List of Message objects
            **kwargs: Additional generation parameters
            
        Yields:
            A single Message object with the complete response
        """
        result = await self.ainvoke(messages, **kwargs)
        yield result
    
    def get_model_capabilities(self) -> Dict[str, Any]:
        """
        Return the capabilities of this adapter.
        
        Returns:
            Dictionary describing supported features
        """
        return {
            "function_calling": False,
            "streaming": False,
            "tool_calling": False,
            "distributed": True,
            "model": self.model
        }
    
    def get_health_status(self) -> Dict[str, Any]:
        """
        Get the health status of all nodes in the cluster.
        
        Returns:
            Dictionary with node status information
            
        Raises:
            ConnectionError: If unable to connect to the load manager
        """
        try:
            response = requests.get(
                f"{self.base_url}/health",
                timeout=30
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            raise ConnectionError(f"Failed to get health status: {e}")
    
    def get_supported_models(self) -> List[str]:
        """
        Get the list of models supported by the load manager.
        
        Returns:
            List of supported model identifiers
            
        Raises:
            ConnectionError: If unable to connect to the load manager
        """
        try:
            response = requests.get(
                f"{self.base_url}/supported_models",
                timeout=30
            )
            response.raise_for_status()
            data = response.json()
            return data.get("supported_models", [])
        except requests.exceptions.RequestException as e:
            raise ConnectionError(f"Failed to get supported models: {e}")

