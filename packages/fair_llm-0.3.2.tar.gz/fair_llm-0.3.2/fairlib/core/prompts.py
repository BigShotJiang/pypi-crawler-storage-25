# fairlib.core.prompts.py
"""
Core prompt engineering infrastructure.

This module provides a structured, object-oriented system for building complex
prompts for language models. It moves beyond static f-string templates to a
composable and maintainable approach, treating prompt engineering as a core
part of the application's architecture.

Key components:

- PromptItem: an abstract base class for any granular part of a prompt.
  Subclasses can be sorted and manipulated in lists.

- PromptBuilder: a flexible container for assembling PromptItem objects into a
  final prompt string. Its component lists (e.g. tool_instructions) are public
  attributes, allowing for direct access and manipulation.
"""
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
import copy
import re
from datetime import datetime
import logging
from dataclasses import dataclass, field

from fairlib.core.base_agent import BaseAgent
from fairlib.core.message import Message
from fairlib.core.interfaces.tools import AbstractTool, AbstractToolRegistry

logger = logging.getLogger(__name__)

# --- Foundational PromptItem Class ---

class PromptItem(ABC):
    """An abstract base class for any component of a system prompt."""
    @abstractmethod
    def render(self) -> str:
        """Renders the component's content into a string."""
        pass

# --- Granular Item Implementations ---

class RoleDefinition(PromptItem):
    """Defines the agent's role, goal, and overall purpose."""
    def __init__(self, text: str):
        self.text = text
    def render(self) -> str:
        return self.text

class ToolInstruction(PromptItem):
    """Describes a single available tool."""
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
    def render(self) -> str:
        return f"- {self.name}: {self.description}"

class WorkerInstruction(PromptItem):
    """Describes a single available worker agent."""
    def __init__(self, name: str, role_description: str):
        self.name = name
        self.role_description = role_description
    def render(self) -> str:
        return f"- {self.name}: {self.role_description}"

class FormatInstruction(PromptItem):
    """Provides a single, specific instruction on how the LLM should format its response."""
    def __init__(self, text: str):
        self.text = text
    def render(self) -> str:
        return self.text

class Example(PromptItem):
    """Provides a single few-shot example to guide the LLM's behavior."""
    def __init__(self, text: str):
        self.text = text
    def render(self) -> str:
        return self.text
    
class StrictFormatInstruction(FormatInstruction):
    """
    Format instruction with explicit DO/DON'T rules for smaller models.

    Smaller models (3B-7B) often need very explicit formatting guidance
    to avoid common mistakes like code fences, nested JSON, or multi-turn outputs.
    """

    @staticmethod
    def json_output_rules() -> 'StrictFormatInstruction':
        """Standard rules for JSON output without code fences."""
        return StrictFormatInstruction(
            "OUTPUT FORMAT RULES:\n"
            "1. Output EXACTLY one Thought line and one Action line\n"
            "2. Action must be a FLAT JSON object on a single line\n"
            "3. Do NOT wrap JSON in code fences (no ```)\n"
            "4. Do NOT nest the action inside another object\n"
            "5. Do NOT output multiple turns at once"
        )

    @staticmethod
    def delegation_rules(valid_workers: List[str]) -> 'StrictFormatInstruction':
        """Rules specific to manager delegation."""
        workers_str = ", ".join(valid_workers)
        return StrictFormatInstruction(
            "DELEGATION RULES:\n"
            f"- Valid workers: {workers_str}\n"
            "- You can ONLY use 'delegate' or 'final_answer' as tool_name\n"
            "- You CANNOT use worker tools directly - you MUST delegate\n"
            "- Delegate to ONE worker at a time, then wait for the result"
        )

    @staticmethod
    def correct_format_example() -> 'StrictFormatInstruction':
        """Shows correct vs incorrect format."""
        return StrictFormatInstruction(
            "CORRECT FORMAT:\n"
            "Thought: [your reasoning here]\n"
            'Action: {"tool_name": "delegate", "tool_input": {"worker_name": "WorkerName", "task": "task description"}}\n\n'
            "WRONG FORMATS (do not do these):\n"
            '- ```json\\n{...}\\n``` (no code fences)\n'
            '- {"thought": "...", "action": {...}} (no nested structure)\n'
            "- Multiple Thought/Action pairs in one response"
        )
    
class DateContextMixin:
    """Mixin to add date context to any component"""
    
    @staticmethod
    def get_current_date_context() -> Dict[str, str]:
        """Get comprehensive date context"""
        now = datetime.now()
        return {
            "current_date": now.strftime("%Y-%m-%d"),
            "current_year": str(now.year),
            "current_month": now.strftime("%B"),
            "current_day": str(now.day),
            "date_context": f"Today is {now.strftime('%A, %B %d, %Y')}",
            "timestamp": now.isoformat()
        }
    
    def enhance_with_date(self, text: str) -> str:
        """Add date context to any text"""
        date_info = self.get_current_date_context()
        
        # Create a string with the current date information
        date_context = f" (Current date: {date_info['current_month']} {date_info['current_day']}, {date_info['current_year']})"
        
        # Append the date context to the original text
        enhanced = text + date_context
        return enhanced
    
class DelegationExample(Example):
    """
    A single-turn delegation example for manager agents.
    
    Unlike multi-turn examples, these show ONE decision point at a time,
    which smaller models handle much better.
    """
    
    def __init__(self, 
                 context: str,
                 thought: str, 
                 worker_name: str, 
                 task: str,
                 is_final_answer: bool = False):
        """
        Create a single-turn delegation example.
        
        Args:
            context: The situation (e.g., "User Request: ..." or "Tool Observation: ...")
            thought: The manager's reasoning
            worker_name: Which worker to delegate to (or ignored if is_final_answer)
            task: The task description (or the final answer text if is_final_answer)
            is_final_answer: If True, creates a final_answer action instead of delegate
        """
        self.context = context
        self.thought = thought
        self.worker_name = worker_name
        self.task = task
        self.is_final_answer = is_final_answer
        
        # Build the example text
        if is_final_answer:
            action_json = f'{{"tool_name": "final_answer", "tool_input": "{task}"}}'
        else:
            action_json = f'{{"tool_name": "delegate", "tool_input": {{"worker_name": "{worker_name}", "task": "{task}"}}}}'
        
        text = f"{context}\n\nThought: {thought}\nAction: {action_json}"
        super().__init__(text)
    
    @staticmethod
    def initial_delegation(user_request: str, thought: str, worker_name: str, task: str) -> 'DelegationExample':
        """Create an example for the first delegation step."""
        return DelegationExample(
            context=f"User Request: {user_request}",
            thought=thought,
            worker_name=worker_name,
            task=task
        )
    
    @staticmethod
    def followup_delegation(observation: str, thought: str, worker_name: str, task: str) -> 'DelegationExample':
        """Create an example for a follow-up delegation after receiving results."""
        return DelegationExample(
            context=f"Tool Observation: {observation}",
            thought=thought,
            worker_name=worker_name,
            task=task
        )
    
    @staticmethod
    def final_answer_example(observation: str, thought: str, answer: str) -> 'DelegationExample':
        """Create an example for providing the final answer."""
        return DelegationExample(
            context=f"Tool Observation: {observation}",
            thought=thought,
            worker_name="",
            task=answer,
            is_final_answer=True
        )
    
@dataclass
class AgentCapability:
    """
    Structured description of what an agent can do.
    
    This provides a standardized way to describe agent capabilities
    that can be used for:
    - Generating worker instructions
    - Creating delegation guidance
    - Building agent descriptions
    """
    name: str
    primary_function: str
    capabilities: List[str] = field(default_factory=list)
    limitations: List[str] = field(default_factory=list)
    input_format: str = ""
    output_format: str = ""
    example_tasks: List[str] = field(default_factory=list)
    delegation_keywords: List[str] = field(default_factory=list)
    tools: List[str] = field(default_factory=list)
    
    def to_worker_instruction(self) -> WorkerInstruction:
        """Convert to a WorkerInstruction for use in prompts."""
        description = f"{self.primary_function}"
        if self.input_format:
            description += f" Input: {self.input_format}."
        if self.output_format:
            description += f" Output: {self.output_format}."
        return WorkerInstruction(self.name, description)
    
    def to_detailed_description(self) -> str:
        """Generate a detailed description for the agent."""
        parts = [
            f"AGENT: {self.name}",
            f"PRIMARY FUNCTION: {self.primary_function}",
        ]
        
        if self.capabilities:
            parts.append("CAPABILITIES:")
            parts.extend([f"- {cap}" for cap in self.capabilities])
        
        if self.limitations:
            parts.append("LIMITATIONS:")
            parts.extend([f"- {lim}" for lim in self.limitations])
        
        if self.input_format:
            parts.append(f"INPUT FORMAT: {self.input_format}")
        
        if self.output_format:
            parts.append(f"OUTPUT FORMAT: {self.output_format}")
        
        if self.tools:
            parts.append(f"TOOLS: {', '.join(self.tools)}")
        
        if self.example_tasks:
            parts.append("EXAMPLE TASKS:")
            parts.extend([f"- {task}" for task in self.example_tasks])
        
        return "\n".join(parts)
    
class EnhancedWorkerInstruction(WorkerInstruction):
    """
    Worker instruction that includes capability details.
    
    Provides richer context about what a worker can do, which helps
    the manager make better delegation decisions.
    """
    
    def __init__(self, capability: AgentCapability):
        self.capability = capability
        super().__init__(capability.name, capability.primary_function)
    
    def render(self) -> str:
        """Render with extended details."""
        parts = [f"- {self.capability.name}: {self.capability.primary_function}"]
        
        if self.capability.input_format:
            parts.append(f"  Input: {self.capability.input_format}")
        
        if self.capability.output_format:
            parts.append(f"  Output: {self.capability.output_format}")
        
        if self.capability.delegation_keywords:
            parts.append(f"  Use when: {', '.join(self.capability.delegation_keywords)}")
        
        return "\n".join(parts)

class History:
    """
    Renders the conversation history for inclusion in a prompt.

    This class plays a critical role in the ReAct loop by translating the
    agent's internal memory (a list of `Message` objects) into the specific
    textual format that the planner's Language Model is expecting to see.
    It deliberately formats certain message roles to match the patterns
    established in the planner's few-shot examples.
    """
    def __init__(self, history: List[Message]):
        """
        Initializes the History item.

        Args:
            history: A list of `Message` objects representing the conversation
                     and reasoning steps so far.
        """
        self.history = history

    def render(self) -> str:
        """
        Renders the list of messages into a single string.

        This method intelligently formats messages to align with the ReAct
        prompting style:
        - Messages with `role="user"` are prefixed with "User Request:".
        - Messages with `role="assistant"` are prefixed with "Thought:", as they
          represent the agent's internal reasoning.
        - Messages with `role="tool"` are prefixed with "Observation:", as they
          represent the result of an action.

        This explicit mapping is a deliberate design choice that is critical
        for ensuring the LLM can correctly parse the history and follow the
        Thought -> Action -> Observation pattern.

        Returns:
            A formatted string representing the conversation history, with each
            message on a new line, or a default string if the history is empty.
        """
        if not self.history:
            return "No history yet."

        rendered_parts = []
        for msg in self.history:
            if not hasattr(msg, 'role') or not hasattr(msg, 'content'):
                continue

            prefix = ""
            content = str(msg.content)

            # --- Remove the special case for role="tool" ---
            # The "Observation:" prefix is now added directly in the SimpleAgent.
            # We still map 'assistant' to 'Thought' for the SimpleReActPlanner's benefit.
            if msg.role == "user":
                prefix = "User Request:"
            elif msg.role == "assistant":
                # The assistant's messages contain either its thought or an observation.
                # We will now just use the raw content.
                rendered_parts.append(content)
                continue # Skip the generic prefix: content formatting
            
            if content.strip():
                 rendered_parts.append(f"{prefix} {content}")

        return "\n\n".join(rendered_parts)

# --- Refactored PromptBuilder ---

class PromptBuilder:
    """
    Assembles a system prompt and combines it with conversation history
    to create a structured list of messages for a chat model.
    """
    def __init__(self):
        self.role_definition: Optional[RoleDefinition] = None
        self.tool_instructions: List[ToolInstruction] = []
        self.worker_instructions: List[WorkerInstruction] = []
        self.format_instructions: List[FormatInstruction] = []
        self.examples: List[Example] = []
        self.date_context: DateContextMixin = DateContextMixin()

    def clone(self) -> 'PromptBuilder':
        """Creates a deep copy of this builder instance."""
        return copy.deepcopy(self)

    def add_tool_registry(self, tool_registry: AbstractToolRegistry):
        """Helper to populate tool instructions from a registry."""
        for name, tool in tool_registry.get_all_tools().items():
            self.tool_instructions.append(ToolInstruction(name, tool.description))

    def add_worker_dict(self, workers: Dict[str, BaseAgent]):
        """Helper to populate worker instructions from a dictionary."""
        for name, worker in workers.items():
            self.worker_instructions.append(WorkerInstruction(name, worker.role_description))
            
    def build_system_prompt_string(self) -> str:
        """
        Builds the static system prompt string from all configured items.
        This string contains the fairlib.core.instructions for the agent.
        """
        prompt_parts = []
        if self.role_definition:
            prompt_parts.append(f"# --- Role and Goal ---\n{self.role_definition.render()}")
        if self.tool_instructions:
            rendered_tools = "\n".join([item.render() for item in self.tool_instructions])
            prompt_parts.append(f"# --- Available Tools ---\n{rendered_tools}")
        if self.worker_instructions:
            rendered_workers = "\n".join([item.render() for item in self.worker_instructions])
            prompt_parts.append(f"# --- Available Workers ---\n{rendered_workers}")
        if self.format_instructions:
            rendered_formats = "\n".join([item.render() for item in self.format_instructions])
            prompt_parts.append(f"# --- Output Format ---\n{rendered_formats}")
        if self.examples:
            rendered_examples = "\n\n".join([f"--- Example {i+1} ---\n{item.render()}" for i, item in enumerate(self.examples)])
            prompt_parts.append(f"# --- Example Workflows ---\n{rendered_examples}")
        if self.date_context:
            prompt_parts.append(f"# --- Current Date Information ---\n{self.date_context.get_current_date_context()}")
            
        return "\n\n".join(prompt_parts)

    def build_message_list(self, history: List[Message], user_input: str) -> List[Message]:
        """
        Constructs the final list of messages to be sent to the LLM using the
        native chat format.
        """
        messages = []
        system_prompt_content = self.build_system_prompt_string()
        
        if system_prompt_content:
            messages.append(Message(role="system", content=system_prompt_content))
        
        messages.extend(history)
        
        if user_input:
            message = Message(role="user", content=user_input)
            if message not in history:
                messages.append(message)
            
        return messages

class ManagerPromptBuilder(PromptBuilder):
    """
    Specialized PromptBuilder for manager agents with strict formatting.
    
    This builder is optimized for smaller models (3B-7B) that need very
    explicit formatting guidance. It includes:
    - Strict JSON format rules (no code fences, no nesting)
    - Single-turn examples (not multi-turn)
    - Explicit DO/DON'T instructions
    - Clear listing of valid actions
    
    Usage:
        builder = ManagerPromptBuilder(strict_mode=True)
        builder.set_role("You are a research team manager...")
        builder.set_workflow(["Researcher", "DataExtractor", "Summarizer"])
        builder.add_delegation_examples([...])
    """
    
    def __init__(self, strict_mode: bool = True):
        """
        Initialize the manager prompt builder.
        
        Args:
            strict_mode: If True, adds strict formatting rules for smaller models.
        """
        super().__init__()
        self.strict_mode = strict_mode
        self.workflow: List[str] = []
    
    def set_role(self, role_text: str):
        """Set the manager's role definition."""
        self.role_definition = RoleDefinition(role_text)
        return self
    
    def set_workflow(self, worker_order: List[str]):
        """
        Set the expected workflow order for workers.
        
        Args:
            worker_order: List of worker names in execution order.
                          e.g., ["Researcher", "DataExtractor", "Summarizer"]
        """
        self.workflow = worker_order
        return self
    
    def add_strict_format_rules(self):
        """Add strict formatting rules optimized for smaller models."""
        self.format_instructions.extend([
            StrictFormatInstruction.json_output_rules(),
            StrictFormatInstruction.correct_format_example(),
        ])
        
        if self.workflow:
            self.format_instructions.append(
                StrictFormatInstruction.delegation_rules(self.workflow)
            )
        return self
    
    def add_workflow_guidance(self):
        """Add guidance about the expected workflow."""
        if self.workflow:
            workflow_str = " → ".join(self.workflow) + " → final_answer"
            self.format_instructions.append(FormatInstruction(
                f"WORKFLOW ORDER:\n"
                f"Always follow this order: {workflow_str}\n"
                f"Complete each step before moving to the next."
            ))
        return self
    
    def add_delegation_example(self, 
                               context: str, 
                               thought: str, 
                               worker_name: str, 
                               task: str):
        """Add a single-turn delegation example."""
        self.examples.append(DelegationExample(
            context=context,
            thought=thought,
            worker_name=worker_name,
            task=task
        ))
        return self
    
    def add_final_answer_example(self, observation: str, thought: str, answer: str):
        """Add an example showing how to provide the final answer."""
        self.examples.append(DelegationExample.final_answer_example(
            observation=observation,
            thought=thought,
            answer=answer
        ))
        return self
    
    def add_workflow_examples(self, user_request: str, workflow_steps: List[Dict[str, str]]):
        """
        Add examples for each step of a workflow.
        
        Args:
            user_request: The initial user request
            workflow_steps: List of dicts with keys:
                - thought: The reasoning
                - worker: Worker name (or None for final_answer)
                - task: The task or answer
                - observation: (optional) The observation that triggered this step
        """
        for i, step in enumerate(workflow_steps):
            if i == 0:
                # First step - triggered by user request
                context = f"User Request: {user_request}"
            else:
                # Subsequent steps - triggered by observation
                context = f"Tool Observation: {step.get('observation', 'Result received.')}"
            
            if step.get('worker'):
                self.examples.append(DelegationExample(
                    context=context,
                    thought=step['thought'],
                    worker_name=step['worker'],
                    task=step['task']
                ))
            else:
                # Final answer
                self.examples.append(DelegationExample(
                    context=context,
                    thought=step['thought'],
                    worker_name="",
                    task=step['task'],
                    is_final_answer=True
                ))
        return self
    
    def build_system_prompt_string(self) -> str:
        """Build the prompt, adding strict rules if enabled."""
        # Add strict format rules if not already present and strict_mode is on
        if self.strict_mode:
            has_strict_rules = any(
                isinstance(f, StrictFormatInstruction) 
                for f in self.format_instructions
            )
            if not has_strict_rules:
                self.add_strict_format_rules()
                self.add_workflow_guidance()
        
        return super().build_system_prompt_string()

# --- Standalone Demonstration ---
if __name__ == "__main__":
    # --- 1. Mock Objects for Demonstration ---
    # This allows us to run this script by itself to test the PromptBuilder.
    class MockTool(AbstractTool):

        def __init__(self, 
                     name: str = "Echo tool", 
                     description: str = "Just echos back user query"):
            self.name=name
            self.description=description

        def use(self, query: str) -> str:
            """
                echos back original query
            """

            # This is a hardcoded response for simulation purposes.
            # A real implementation would make an API call to a weather service here.
            return f"The mockup tool: {query}."

    class MockToolRegistry(AbstractToolRegistry):
        def __init__(self, name, description):
            self.name = name
            self.description = description

        """
        A concrete implementation of a tool registry that holds and manages a
        collection of tools for an agent.

        This implementation allows for tools to be dynamically registered, making it
        flexible for creating agents with different capabilities.
        """
        def __init__(self):
            """Initializes the ToolRegistry with an empty dictionary to store tools."""
            self._tools: Dict[str, AbstractTool] = {}

        def register_tool(self, tool: AbstractTool):
            """
            Adds a tool instance to the registry, making it available for use.

            The tool is stored using its `name` attribute as the key.

            Args:
                tool: An instance of a class that inherits from AbstractTool.
            """
            if not tool.name:
                raise ValueError("Tool must have a name attribute.")
            logger.debug(f"Registering tool: {tool.name}")
            self._tools[tool.name] = tool

        def get_tool(self, name: str) -> Optional[AbstractTool]:
            """
            Retrieves a single tool from the registry by its name.

            Args:
                name: The name of the tool to retrieve.

            Returns:
                The tool instance if found, otherwise None.
            """
            return self._tools.get(name)

        def get_all_tools(self) -> Dict[str, AbstractTool]:
            """
            Returns a dictionary of all tools currently in the registry.

            Returns:
                A dictionary where keys are tool names and values are the
                tool instances.
            """
            return self._tools

    # --- 2. Setup the Builder and Mock Data ---
    print("--- 🛠️ DEMONSTRATING PROMPT BUILDER 🛠️ ---")

    # Create a mock tool registry
    mock_registry = MockToolRegistry()
    mock_registry.register_tool(MockTool())
    mock_registry.register_tool(MockTool("weather_tool", "Gets the current weather for a city."))

    # Instantiate the builder
    builder = PromptBuilder()

    # --- 3. Manipulating the Prompt Items ---

    # Set the role directly
    builder.role_definition = RoleDefinition("You are a helpful AI assistant.")

    # Use the helper to add tools from the registry
    builder.add_tool_registry(mock_registry)

    # Manually add a tool instruction for the "final_answer" pseudo-tool,
    # which is not in the registry.
    final_answer_tool = ToolInstruction(
        name="final_answer",
        description="Use this tool to provide the final, complete answer to the user and end the task."
    )
    builder.tool_instructions.append(final_answer_tool)
    print("\n✅ Manually added 'final_answer' to tool instructions.")

    # Access and enumerate a list.
    print("\nIterating over current tool instructions:")
    for tool in builder.tool_instructions:
        print(f"  - Found tool: {tool.name}")

    # Remove an item from a list (the weather tool, in this demo).
    tool_to_remove = next((t for t in builder.tool_instructions if t.name == "weather_tool"), None)
    if tool_to_remove:
        builder.tool_instructions.remove(tool_to_remove)
        print(f"\n✅ Removed '{tool_to_remove.name}' from tool instructions.")

    # Manually add to other lists.
    builder.format_instructions.append(
        FormatInstruction("Your response must contain a 'Thought' and an 'Action' part.")
    )
    builder.format_instructions.append(
        FormatInstruction("The 'Action' part must be a single, valid JSON object.")
    )
    print("\n✅ Manually added two format instructions.")

    # Add other items
    builder.examples.append(Example("User: What is 2+2?\nThought: I should use the calculator.\nAction: {\"tool_name\": \"safe_calculator\", \"tool_input\": \"2+2\"}"))
    builder.history = History([Message("user", "Hello there!"), Message("assistant", "Hi! How can I help?"), Message("user", "What is the capital of France?")])

    # --- 4. Build and Print the Final Prompt ---
    final_prompt = builder.build_system_prompt_string()

    print("\n\n" + "="*50)
    print("      FINAL RENDERED PROMPT")
    print("="*50 + "\n")
    print(final_prompt)