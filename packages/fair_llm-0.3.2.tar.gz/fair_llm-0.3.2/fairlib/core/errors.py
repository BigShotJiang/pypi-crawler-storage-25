"""Typed exceptions for the FAIR-LLM framework.

Single source of truth for the framework's error taxonomy. Consumers
catch these to route recovery distinctly. The framework raises them
instead of returning magic strings or untyped error messages, so caller
retry / fallback / escalation logic can respond appropriately to the
kind of failure that occurred.

Hierarchy:

    FairlibError
        PlannerParseError       — planner could not extract usable content
                                  (also subclasses ValueError so legacy
                                  callers that catch ValueError still work)
        AdapterError            — LLM adapter / provider failure
        ToolInvocationError     — tool executor raised during tool.use()
        MaxStepsExceeded        — agent reached max_steps without a FinalAnswer
        InvalidAgentInputError  — caller handed an agent entry-point a
                                  malformed input (e.g. wrong role on a
                                  pre-built user Message)
"""

from typing import List, Optional

__all__ = [
    "FairlibError",
    "PlannerParseError",
    "AdapterError",
    "ToolInvocationError",
    "MaxStepsExceeded",
    "InvalidAgentInputError",
]


class FairlibError(Exception):
    """Base class for all framework-raised errors.

    Catch this to handle any fairlib-raised failure uniformly.
    """


class PlannerParseError(FairlibError, ValueError):
    """Raised when the planner cannot extract any usable content from the LLM response.

    Inherits from both FairlibError (so it is part of the typed framework
    error taxonomy) and ValueError (so legacy callers that catch
    ValueError still handle it).

    Part of the planner contract: concrete planners should raise this
    (rather than returning a generic FinalAnswer) when the LLM response
    contains nothing usable, so the agent or runner can trigger its
    retry-with-corrective-message loop.

    Attributes:
        raw_output: The unparsed LLM response, preserved so callers can
            log it or feed it back as context on retry. None when the
            raiser did not pass one.
    """

    def __init__(self, message: str = "", *, raw_output: Optional[str] = None) -> None:
        super().__init__(message)
        self.raw_output = raw_output


class AdapterError(FairlibError):
    """Raised when an LLM adapter fails in a way the caller should know about.

    Examples: authentication failure, API timeout, quota exhaustion,
    structured-output retries exhausted, malformed provider response.

    Attributes:
        raw_output: The unparsed response text from the provider, if any,
            so callers can log or display it for debugging.
        provider: Short name of the adapter that raised (e.g. "openai",
            "anthropic", "huggingface"), for routing / observability.
    """

    def __init__(
        self,
        message: str,
        *,
        raw_output: Optional[str] = None,
        provider: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.raw_output = raw_output
        self.provider = provider


class ToolInvocationError(FairlibError):
    """Raised when a tool's use() or ause() method fails.

    The agent catches this so tool failures can surface as a typed
    observation rather than a silently stringified "Error: ..." message.

    Attributes:
        tool_name: Which tool raised, so the agent can include it in the
            observation it hands back to the planner.
        raw_output: The original exception text or partial output, for
            debugging.
    """

    def __init__(
        self,
        message: str,
        *,
        tool_name: str,
        raw_output: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.tool_name = tool_name
        self.raw_output = raw_output


class InvalidAgentInputError(FairlibError, ValueError):
    """Raised when an agent's public entry point receives a malformed input.

    Inherits from both FairlibError (typed taxonomy) and ValueError (so
    legacy callers that catch ValueError keep working — same precedent as
    PlannerParseError).

    Today this is raised by SimpleAgent.arun when a caller passes a
    Message whose role is not "user". The agent's user-turn entry point
    is contractually a user message; any other role indicates a caller
    error that would otherwise corrupt memory silently.
    """


class MaxStepsExceeded(FairlibError):
    """Raised (or signalled) when the agent loop hits max_steps without
    arriving at a FinalAnswer.

    Attributes:
        max_steps: The configured limit that was reached.
        partial_history: The message list accumulated up to the point the
            limit was hit, so callers can inspect or resume.
    """

    def __init__(
        self,
        max_steps: int,
        *,
        partial_history: Optional[List] = None,
    ) -> None:
        super().__init__(
            f"Agent stopped after reaching max_steps={max_steps} without "
            f"producing a FinalAnswer."
        )
        self.max_steps = max_steps
        self.partial_history = partial_history
