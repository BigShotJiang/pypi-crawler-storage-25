"""
Typed event payloads.

Events are frozen dataclasses. Subscribers receive a value type they cannot
mutate, so a misbehaving subscriber cannot affect what other subscribers see
or what the framework does on subsequent calls.
"""

from dataclasses import dataclass
from typing import Literal

from fairlib.core.message import Message

__all__ = ["MemorySummarizedEvent"]


@dataclass(frozen=True)
class MemorySummarizedEvent:
    """Payload describing a single summarization pass on a memory implementation."""

    dropped: tuple[Message, ...]
    kept: tuple[Message, ...]
    summary: Message
    reason: Literal[
        "max_history_length_exceeded",
        "adapter_failure_fallback",
    ] = "max_history_length_exceeded"
