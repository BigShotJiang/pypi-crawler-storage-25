# fairlib.core.interfaces/llm.py
"""
This module defines the abstract interfaces for language models.

The framework supports two primary types of language model interactions, each
represented by its own abstract base class:
1.  `AbstractLanguageModel`: For simpler text-completion models (text-in, text-out).
2.  `AbstractChatModel`: For more sophisticated chat-based models that operate on a
    structured list of messages. This is the primary interface used for agentic workflows.

These contracts ensure that any language model can be seamlessly integrated into the
framework's Model Abstraction Layer (MAL).
"""

import abc
import logging
from typing import Any, List, Dict, Generator, AsyncGenerator
from ..message import Message

logger = logging.getLogger(__name__)

class AbstractLanguageModel(abc.ABC):
    """
    An abstract interface for a standard text-completion language model.

    This interface is best suited for models that take a single string prompt
    and return a single string completion.
    """
    @abc.abstractmethod
    def invoke(self, prompt: str, **kwargs: Any) -> str:
        """Makes a single, synchronous call to the language model."""
        ...

    @abc.abstractmethod
    async def ainvoke(self, prompt: str, **kwargs: Any) -> str:
        """Makes a single, asynchronous call to the language model."""
        ...

    @abc.abstractmethod
    def stream(self, prompt: str, **kwargs: Any) -> Generator[str, None, None]:
        """
        Creates a synchronous generator that streams chunks of the model's response.
        """
        ...

    @abc.abstractmethod
    async def astream(self, prompt: str, **kwargs: Any) -> AsyncGenerator[str, None]:
        """
        Creates an asynchronous generator that streams chunks of the model's response.
        """
        ...


class AbstractChatModel(abc.ABC):
    """
    An abstract interface for a chat-based language model.

    This is the primary and more powerful interface used for building agents.
    It operates on a list of `Message` objects, allowing it to understand
    conversational history and roles (system, user, assistant, tool).
    """
    @abc.abstractmethod
    def invoke(self, messages: List[Message], **kwargs: Any) -> Message:
        """
        Makes a single, synchronous call to the chat model with a list of messages.

        Args:
            messages: A list of `Message` objects representing the conversation.
            **kwargs: Provider-specific options, e.g., `temperature`, `top_p`.

        Returns:
            A single `Message` object containing the assistant's complete response.
        """
        ...

    @abc.abstractmethod
    async def ainvoke(self, messages: List[Message], **kwargs: Any) -> Message:
        """
        Makes a single, asynchronous call to the chat model with a list of messages.
        
        Args:
            messages: A list of `Message` objects representing the conversation.
            **kwargs: Provider-specific options.

        Returns:
            A single `Message` object containing the assistant's complete response.
        """
        ...

    @abc.abstractmethod
    def stream(self, messages: List[Message], **kwargs: Any) -> Generator[Message, None, None]:
        """
        Creates a synchronous generator that streams chunks of the model's response.

        Each yielded item should be a `Message` object, allowing the content to be
        built up incrementally.

        Args:
            messages: A list of `Message` objects representing the conversation.
            **kwargs: Provider-specific options.

        Yields:
            `Message` objects representing chunks of the response.
        """
        ...

    @abc.abstractmethod
    async def astream(self, messages: List[Message], **kwargs: Any) -> AsyncGenerator[Message, None]:
        """
        Creates an asynchronous generator that streams chunks of the model's response.

        Args:
            messages: A list of `Message` objects representing the conversation.
            **kwargs: Provider-specific options.

        Yields:
            `Message` objects representing chunks of the response.
        """
        ...

    @abc.abstractmethod
    def get_model_capabilities(self) -> Dict[str, Any]:
        """
        Returns a dictionary describing the capabilities of the model.

        This allows the framework to introspect the model and understand its features,
        such as whether it supports function calling, tool use, or other specific
        structured outputs.

        Example:
            return {"function_calling": True, "tool_calling": False}
        """
        ...

    def estimate_token_count(self, text: str) -> int:
        """
        Estimates the number of tokens in a text string.

        Default heuristic: len(text) // 4. Subclasses with access to a real
        tokenizer (e.g. HuggingFaceAdapter) can override for accuracy.
        """
        return len(text) // 4

    def _check_context_window_usage(self, messages: List[Message], threshold: float = 0.5) -> None:
        """
        Logs a warning if the messages consume a large portion of the model's
        context window.

        Args:
            messages: The messages about to be sent to the model.
            threshold: The fraction (0.0–1.0) of the context window at or above
                which a warning is emitted. Defaults to 0.5 (50%).
        """
        capabilities = self.get_model_capabilities()
        max_context = capabilities.get("max_context_window")
        if not max_context:
            return

        total_tokens = sum(
            self.estimate_token_count(msg.content or "")
            for msg in messages
        )

        usage_ratio = total_tokens / max_context
        if usage_ratio < threshold:
            return

        pct = usage_ratio * 100
        warning = (
            f"Context window usage is high: ~{total_tokens} tokens of "
            f"{max_context} ({pct:.1f}%)."
        )

        system_tokens = sum(
            self.estimate_token_count(msg.content or "")
            for msg in messages
            if msg.role == "system"
        )
        if system_tokens:
            sys_pct = (system_tokens / max_context) * 100
            warning += (
                f" System prompt accounts for ~{system_tokens} tokens "
                f"({sys_pct:.1f}% of context window)."
            )

        logger.warning(warning)

        # --- The `chat` method can now be a simple wrapper around `invoke` ---
    def chat(self, messages: List[Message], temperature: float = 0.7) -> str:
        """A simplified chat method for convenience, consistent with our demos."""
        response_message = self.invoke(messages, temperature=temperature)
        return response_message.content