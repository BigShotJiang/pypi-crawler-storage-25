import abc
from typing import List, Union, Tuple
from fairlib.core.message import Message, Thought, Action, FinalAnswer


class AbstractPlanner(abc.ABC):
    """
    An abstract interface for an agent's planner component.

    The Planner is the "brain" of the agent. Its primary responsibility is to
    analyze the current conversation history and decide on the next step. It
    determines what the agent should think and which tool it should use next,
    or whether the task is complete and a final answer can be given.

    Concrete planners may raise fairlib.core.errors.PlannerParseError from
    plan() / aplan() when the LLM response contains nothing usable, so the
    agent loop can route to a retry path rather than treating garbage as a
    valid plan step.
    """

    @abc.abstractmethod
    def plan(
        self, messages: List[Message], **kwargs
    ) -> Union[Tuple[Thought, Action], FinalAnswer]:
        """
        Synchronously determines the next step for the agent.

        Args:
            messages: A list of Message objects representing the full
                      conversation history.
            **kwargs: Placeholder for additional implementation-specific arguments.

        Returns:
            Either a FinalAnswer if the task is complete, or a tuple containing
            the agent's Thought and the next Action to execute.
        """
        ...

    @abc.abstractmethod
    async def aplan(
        self, messages: List[Message], **kwargs
    ) -> Union[Tuple[Thought, Action], FinalAnswer]:
        """
        Asynchronously determines the next step for the agent.

        This is the asynchronous version of `plan` and should be preferred in
        asyncio applications to avoid blocking the event loop.

        Args:
            messages: A list of Message objects representing the full
                      conversation history.
            **kwargs: Placeholder for additional implementation-specific arguments.

        Returns:
            Either a FinalAnswer if the task is complete, or a tuple containing
            the agent's Thought and the next Action to execute.
        """
        ...

    @abc.abstractmethod
    def format_turn_for_memory(
        self, step: Union[Tuple[Thought, Action], FinalAnswer]
    ) -> Message:
        """Render a plan step into the memory format this planner's parser
        can round-trip.

        The agent calls this after a successful plan step to write an
        assistant-role entry to memory. Every concrete planner owns its
        own memory serialization, so agents never need to know which
        concrete planner is in use.

        Contract:
            - The returned Message must have role="assistant".
            - Its content must parse cleanly under the same planner's
              aplan() on the next turn (i.e. round-trip via the parser).
            - For a FinalAnswer step, the content may still carry scaffolding
              so the planner's prompt examples and the stored history stay
              consistent; the FinalAnswer text itself is returned separately
              to the agent's caller.

        Args:
            step: Exactly what aplan() returned — either a (Thought, Action)
                tuple or a FinalAnswer.

        Returns:
            A single assistant-role Message ready to add to memory.
        """
        ...
