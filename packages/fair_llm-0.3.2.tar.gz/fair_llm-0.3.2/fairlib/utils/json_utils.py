"""JSON parsing utilities for handling malformed LLM output.

LLMs frequently produce invalid JSON when their output contains LaTeX notation
(e.g., \\(x\\), \\log_2, \\ln) or other backslash-heavy content. Standard
json.loads() rejects these because \\( , \\l, etc. are not valid JSON escape
sequences.

This module provides a sanitizer that fixes invalid backslash escapes before
parsing, allowing the JSON structure to be recovered without losing content.
"""

import json
import re
import logging
from typing import Any

logger = logging.getLogger(__name__)

# Valid JSON escape sequences after the backslash character:
# " \ / b f n r t uXXXX
_VALID_JSON_ESCAPES = re.compile(
    r'\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4})'
)


def sanitize_json_string(text: str) -> str:
    """Fix invalid backslash escape sequences in a JSON string.

    Replaces lone backslashes that are NOT part of a valid JSON escape
    sequence with double-backslashes so that json.loads() can parse them.

    Examples of what gets fixed:
        \\(x\\)  -> \\\\(x\\\\)     (LaTeX inline math)
        \\log_2  -> \\\\log_2       (LaTeX commands)
        \\ln(3)  -> \\\\ln(3)       (LaTeX commands)

    Valid escapes are left untouched:
        \\"      -> \\"             (escaped quote)
        \\n      -> \\n             (newline)
        \\\\     -> \\\\            (escaped backslash)
    """
    if '\\' not in text:
        return text

    result = []
    i = 0
    while i < len(text):
        if text[i] == '\\':
            # Check if this backslash starts a valid JSON escape
            remaining = text[i:]
            match = _VALID_JSON_ESCAPES.match(remaining)
            if match:
                # Valid escape — keep as-is and skip past it
                result.append(match.group())
                i += match.end()
            else:
                # Invalid escape — double the backslash
                result.append('\\\\')
                i += 1
        else:
            result.append(text[i])
            i += 1

    return ''.join(result)


def safe_json_loads(text: str) -> Any:
    """Parse JSON with automatic recovery from invalid backslash escapes.

    First attempts standard json.loads(). If that fails with a JSONDecodeError,
    sanitizes invalid escape sequences and retries. This two-pass approach
    avoids unnecessary modification of already-valid JSON.

    Args:
        text: JSON string to parse.

    Returns:
        Parsed JSON object.

    Raises:
        json.JSONDecodeError: If the text cannot be parsed even after
            sanitization.
    """
    try:
        return json.loads(text)
    except json.JSONDecodeError as original_error:
        # Only retry if the error mentions an escape issue
        if '\\' in text:
            sanitized = sanitize_json_string(text)
            try:
                result = json.loads(sanitized)
                logger.debug(
                    "Recovered JSON after sanitizing invalid backslash escapes"
                )
                return result
            except json.JSONDecodeError:
                pass  # Fall through to raise original error
        raise original_error
