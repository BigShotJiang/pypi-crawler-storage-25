import os, json, requests, re
from dotenv import load_dotenv
from .nuextract import extract
from fairlib.core.message import Message
from fairlib.modules.mal.local_llama_adapter import OllamaAdapter

load_dotenv()
WOLFRAM_APP_ID = os.getenv("WOLFRAM_APP_ID")
if not WOLFRAM_APP_ID:
    raise ValueError("WOLFRAM_APP_ID must be set in .env file")

# Ollama configuration
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "gpt-oss:120b")

# Initialize OllamaAdapter lazily
_ollama_adapter = None

def _get_ollama_adapter():
    """Get or create the OllamaAdapter instance."""
    global _ollama_adapter
    if _ollama_adapter is None:
        _ollama_adapter = OllamaAdapter(model_name=OLLAMA_MODEL, host=OLLAMA_BASE_URL)
    return _ollama_adapter

# --- LaTeX and Math Formatting Functions ---

def detect_math_expressions(text: str) -> list:
    """
    Detect mathematical expressions in text that should be formatted as LaTeX.
    """
    math_patterns = [
        r'\b\d+\s*[+\-*/]\s*\d+\b',  # Basic arithmetic
        r'\b\w+\s*[+\-*/]\s*\w+\b',  # Variable arithmetic
        r'\b\w+\^\d+\b',  # Powers
        r'\b\w+\^\{\w+\}\b',  # Powers with braces
        r'\b\w+\([^)]+\)\b',  # Functions
        r'\b\w+\s*=\s*\w+\b',  # Equations
        r'\b\w+\s*=\s*\d+\b',  # Simple equations
        r'\b\w+\s*=\s*[^=]+\b',  # Complex equations
        r'\b\w+\s*[<>≤≥]\s*\w+\b',  # Inequalities
        r'\b\w+\s*[<>≤≥]\s*\d+\b',  # Inequalities with numbers
    ]
    
    expressions = []
    for pattern in math_patterns:
        matches = re.finditer(pattern, text)
        for match in matches:
            expressions.append({
                'text': match.group(),
                'start': match.start(),
                'end': match.end(),
                'pattern': pattern
            })
    
    return expressions

def format_math_to_latex(text: str) -> str:
    """
    Convert mathematical expressions in text to LaTeX format with proper spacing and arrows.
    """
    # Common mathematical function mappings
    function_mappings = {
        'sin': r'\sin',
        'cos': r'\cos',
        'tan': r'\tan',
        'log': r'\log',
        'ln': r'\ln',
        'sqrt': r'\sqrt',
        'pi': r'\pi',
        'infinity': r'\infty',
        'alpha': r'\alpha',
        'beta': r'\beta',
        'gamma': r'\gamma',
        'delta': r'\delta',
        'theta': r'\theta',
        'lambda': r'\lambda',
        'mu': r'\mu',
        'sigma': r'\sigma',
        'phi': r'\phi',
        'omega': r'\omega'
    }
    
    # Replace common functions
    for func, latex in function_mappings.items():
        text = re.sub(r'\b' + func + r'\b', latex, text)
    
    # Handle powers - convert x^2 to x^{2} or x^y to x^{y}
    text = re.sub(r'(\w+)\^(\w+)', r'\1^{\2}', text)
    
    # Handle fractions - convert a/b to \frac{a}{b} for inline math
    text = re.sub(r'(\w+)/(\w+)', r'\\frac{\1}{\2}', text)
    
    # Handle square roots - convert sqrt(x) to \sqrt{x}
    text = re.sub(r'sqrt\(([^)]+)\)', r'\\sqrt{\1}', text)
    
    # Handle integrals - convert integral(f(x), x, a, b) to \int_a^b f(x) dx
    text = re.sub(r'integral\(([^,]+),\s*(\w+),\s*([^,]+),\s*([^)]+)\)', 
                  r'\\int_{\3}^{\4} \1 d\2', text)
    
    # Handle derivatives - convert derivative(f(x), x) to \frac{d}{dx}f(x)
    text = re.sub(r'derivative\(([^,]+),\s*(\w+)\)', r'\\frac{d}{d\2}\1', text)
    
    # Handle arrows and spacing - convert => to \Longrightarrow with proper spacing
    text = re.sub(r'\s*=>\s*', r' \\quad\\Longrightarrow\\quad ', text)
    text = re.sub(r'\s*->\s*', r' \\quad\\Longrightarrow\\quad ', text)
    text = re.sub(r'\s*implies\s*', r' \\quad\\Longrightarrow\\quad ', text)
    
    # Handle equals signs with proper spacing
    text = re.sub(r'\s*=\s*', r' = ', text)
    
    # Handle boxed answers
    text = re.sub(r'answer:\s*([^\n]+)', r'\\boxed{\1}', text)
    text = re.sub(r'result:\s*([^\n]+)', r'\\boxed{\1}', text)
    
    return text

def extract_latex_from_wolfram(wolfram_result: str) -> str:
    """
    Extract and format LaTeX expressions from Wolfram|Alpha results.
    """
    # Wolfram often returns results in formats that can be converted to LaTeX
    result = wolfram_result
    
    # Handle common Wolfram output patterns
    # Convert "x^2" to "x^{2}"
    result = re.sub(r'(\w+)\^(\d+)', r'\1^{\2}', result)
    
    # Convert "x^y" to "x^{y}"
    result = re.sub(r'(\w+)\^(\w+)', r'\1^{\2}', result)
    
    # Convert fractions like "1/2" to "\frac{1}{2}"
    result = re.sub(r'(\d+)/(\d+)', r'\\frac{\1}{\2}', result)
    
    # Convert "sqrt(x)" to "\sqrt{x}"
    result = re.sub(r'sqrt\(([^)]+)\)', r'\\sqrt{\1}', result)
    
    # Convert "pi" to "\pi"
    result = re.sub(r'\bpi\b', r'\\pi', result)
    
    # Convert "e" to "e" (Euler's number)
    result = re.sub(r'\be\b', r'e', result)
    
    return result

def clean_latex_expression(expression: str) -> str:
    """
    Clean and standardize LaTeX expressions for better readability.
    """
    if not expression or not expression.strip():
        return ""
    
    expr = expression.strip()
    
    # Remove any existing LaTeX delimiters
    expr = re.sub(r'^\\?\[|\\?\]$', '', expr)
    expr = re.sub(r'^\$\$?|\$\$?$', '', expr)
    
    # Clean up common formatting issues
    # Fix double backslashes
    expr = re.sub(r'\\\\+', r'\\', expr)
    
    # Fix spacing around operators
    expr = re.sub(r'\s*([+\-=<>])\s*', r' \1 ', expr)
    
    # Fix spacing around fractions
    expr = re.sub(r'\\frac\{([^}]+)\}\{([^}]+)\}', r'\\frac{\1}{\2}', expr)
    
    # Fix spacing around square roots
    expr = re.sub(r'\\sqrt\{([^}]+)\}', r'\\sqrt{\1}', expr)
    
    # Fix spacing around powers
    expr = re.sub(r'(\w+)\^\{([^}]+)\}', r'\1^{\2}', expr)
    
    # Clean up multiple spaces
    expr = re.sub(r'\s+', ' ', expr)
    
    # Ensure proper LaTeX formatting for common patterns
    # Convert "x2" to "x^2" if it looks like a power
    expr = re.sub(r'(\w+)2(?!\w)', r'\1^2', expr)
    expr = re.sub(r'(\w+)3(?!\w)', r'\1^3', expr)
    
    # Convert "sqrt" to "\sqrt"
    expr = re.sub(r'\bsqrt\b', r'\\sqrt', expr)
    
    expr = re.sub(r'\bpi\b', r'\\pi', expr)
    
    # Convert "infinity" to "\infty"
    expr = re.sub(r'\binfinity\b', r'\\infty', expr)
    
    return expr.strip()

def format_step_by_step_solution(problem_type: str, wolfram_result: str, original_query: str) -> str:
    """
    Format Wolfram result into the exact step-by-step format with proper LaTeX.
    """
    # Detect if this is a linear equation
    if "x" in original_query.lower() and any(op in original_query for op in ["+", "-", "="]):
        return format_linear_equation_solution(original_query, wolfram_result)
    
    # For other problem types, use general formatting
    return format_general_solution(problem_type, wolfram_result, original_query)

def format_linear_equation_solution(original_query: str, wolfram_result: str) -> str:
    """
    Format linear equation solutions in the exact template format.
    """
    # Extract the equation from the query
    equation_match = re.search(r'([\d\w\s+\-*/=]+)', original_query)
    equation = equation_match.group(1).strip() if equation_match else original_query
    
    # Extract the solution from Wolfram result
    solution_match = re.search(r'x\s*=\s*([\d\.\-\+\/\s]+)', wolfram_result)
    solution = solution_match.group(1).strip() if solution_match else wolfram_result
    
    # Format according to the exact template
    formatted_solution = f"""**Step 1: Write the given linear equation**

${equation}$

**Step 2: Isolate the term containing $x$**

Subtract the constant term from both sides:
${equation.replace('=', ' - constant =')} $\\quad\\Longrightarrow\\quad$ simplified form

**Step 3: Solve for $x$**

Divide both sides by the coefficient:
$\frac{{\\text{{coefficient}} \\cdot x}}{{\\text{{coefficient}}}} = \frac{{\\text{{constant}}}}{{\\text{{coefficient}}}} \quad\Longrightarrow\quad x = {solution}$

**Result**

$\boxed{{x = {solution}}}$

**Mathematical Solution**

\\[
\\begin{{aligned}}
{equation} \\\\
\\text{{simplified steps}} \\\\
\\boxed{{x = {solution}}}
\\end{{aligned}}
\\\\]"""
    
    return formatted_solution

def format_general_solution(problem_type: str, wolfram_result: str, original_query: str) -> str:
    """
    Format general mathematical solutions with proper LaTeX.
    """
    # Clean and format the Wolfram result
    cleaned_result = clean_latex_expression(wolfram_result)
    
    return f"""**Step 1: Identify the problem type**

{problem_type}

**Step 2: Apply the appropriate method**

Using the relevant mathematical technique...

**Step 3: Compute the solution**

{cleaned_result}

**Result**

$\\boxed{{{cleaned_result}}}$"""

def clean_latex_output(text: str) -> str:
    """
    Post-process the generated response to fix LaTeX formatting issues.
    """
    if not text:
        return text
    
    # Fix double backslashes by replacing them with single backslashes
    # Handle the specific patterns we see in the output using simple string replacement
    text = text.replace('\\\\frac', '\\frac')
    text = text.replace('\\\\boxed', '\\boxed')
    text = text.replace('\\\\quad', '\\quad')
    text = text.replace('\\\\Longrightarrow', '\\Longrightarrow')
    text = text.replace('\\\\Rightarrow', '\\Rightarrow')
    text = text.replace('\\\\sqrt', '\\sqrt')
    text = text.replace('\\\\pi', '\\pi')
    text = text.replace('\\\\infty', '\\infty')
    
    # Remove $\displaystyle and replace with just $
    text = re.sub(r'\$\\displaystyle\s+', '$', text)
    
    # Fix mixed delimiters - convert $$ to $ for inline math
    text = re.sub(r'\$\$([^$]+)\$\$', r'$\1$', text)
    
    # Fix text concatenation issues - separate "Result" from math expressions
    text = re.sub(r'(\$[^$]+\$)([A-Za-z]+)', r'\1\n\n**\2**', text)
    
    # Fix arrow spacing - ensure proper spacing around arrows
    text = re.sub(r'\\Rightarrow', r'\\;\\Rightarrow\\;', text)
    text = re.sub(r'\\Longrightarrow', r'\\;\\Longrightarrow\\;', text)
    
    # Fix step headers that got mangled - restore proper formatting
    text = re.sub(r'\*\*Step (\d+): ([^*]+)\$\*\*([^*]+)\$\*\*', r'**Step \1: \2$**', text)
    text = re.sub(r'\*\*Step (\d+): ([^*]+)\n\n\*\*', r'**Step \1: \2**', text)
    text = re.sub(r'\*\*Step (\d+): ([^*]+)\$\n\n\*\*', r'**Step \1: \2$**', text)
    
    # Fix any remaining broken step headers
    text = re.sub(r'\*\*([^*]+)\$\n\n\*\*', r'**\1$**', text)
    text = re.sub(r'\*\*([^*]+)\n\n\*\*', r'**\1**', text)
    
    # Fix specific formatting issues from the output
    text = re.sub(r'\$\*\*x\*\*\$', r'$x$', text)
    text = re.sub(r'\$\*\*([^*]+)\*\*\$', r'$\1$', text)
    
    # Clean up extra line breaks and fix step header spacing
    text = re.sub(r'\n\n\n+', '\n\n', text)
    text = re.sub(r'\$([^$]+)\$\*\*([^*]+)\*\*', r'$\1$\n\n**\2**', text)
    
    return text.strip()

def validate_and_complete_latex(latex_expr: str) -> str:
    """
    Validate and complete LaTeX expressions to prevent truncation issues.
    """
    if not latex_expr or not latex_expr.strip():
        return ""
    
    expr = latex_expr.strip()
    
    # Check for common truncation patterns and complete them
    # Check for incomplete fractions - look for \frac{...}{ pattern
    if '\\frac{' in expr:
        # Count opening and closing braces to see if fraction is complete
        open_braces = expr.count('{')
        close_braces = expr.count('}')
        if open_braces > close_braces:
            # Add missing closing braces
            expr += '}' * (open_braces - close_braces)
    
    # Check for incomplete square roots
    if '\\sqrt{' in expr:
        # Find the last \sqrt{ and ensure it has a closing brace
        last_sqrt = expr.rfind('\\sqrt{')
        if last_sqrt != -1:
            after_sqrt = expr[last_sqrt + 6:]  # Skip '\sqrt{'
            if '}' not in after_sqrt:
                expr += '}'
    
    # Check for incomplete expressions ending with operators
    if expr.endswith(('+', '-', '=', '\\pm', '\\cdot')):
        expr += '...'  # Indicate continuation
    
    # Check for incomplete expressions ending with incomplete fractions
    if expr.endswith('\\frac{'):
        expr += '...}'
    
    # Special case: if expression ends with { but no closing brace, add it
    if expr.endswith('{') and not expr.endswith('\\{'):
        expr += '}'
    
    return expr

# --- Tool: Wolfram|Alpha Short Answers API ---
def wolfram_short_answer(query: str) -> str:
    """
    Calls Wolfram|Alpha's Short Answers API for concise, computable results.
    Good for math, unit conversions, facts that should be exact.
    """
    url = "https://api.wolframalpha.com/v1/result"
    params = {"appid": WOLFRAM_APP_ID, "i": query}
    r = requests.get(url, params=params, timeout=20)
    if r.status_code == 200:
        return r.text.strip()
    # Fallback to Spoken or Full if Short Answer fails:
    url_spoken = "https://api.wolframalpha.com/v1/spoken"
    r2 = requests.get(url_spoken, params={"appid": WOLFRAM_APP_ID, "i": query}, timeout=20)
    return r2.text.strip() if r2.status_code == 200 else f"[Wolfram error {r.status_code}] {r.text}"

# --- Wolfram|Alpha integration functions ---

def generate_response(prompt: str, max_length: int = 512, temperature: float = 0.7) -> str:
    """
    Generate a response using OllamaAdapter via MAL modules.
    """
    try:
        adapter = _get_ollama_adapter()
        message = Message(role="user", content=prompt)
        response = adapter.invoke(
            [message],
            temperature=temperature,
            num_predict=max_length,
            stop=["</s>", "\n\n\n"]
        )
        return response.content.strip()
    except Exception as e:
        # Fallback to simple rule-based responses when Ollama is not available
        return generate_fallback_response(prompt, str(e))

def generate_fallback_response(prompt: str, error: str = "") -> str:
    """
    Generate a simple fallback response when Ollama is not available.
    """
    prompt_lower = prompt.lower()
    error_msg = f" (Error: {error})" if error else ""
    
    # Simple rule-based responses for common queries
    if "hello" in prompt_lower or "hi" in prompt_lower:
        return f"Hello! I'm WolframGPT, but I'm currently running in fallback mode because Ollama is not available{error_msg}. Please install and start Ollama with the {OLLAMA_MODEL} model to get full AI capabilities."
    
    elif "how are you" in prompt_lower:
        return f"I'm running in fallback mode because Ollama is not connected{error_msg}. To get full AI capabilities, please ensure Ollama is running with the {OLLAMA_MODEL} model."
    
    elif "wolfram" in prompt_lower or "math" in prompt_lower or "calculate" in prompt_lower:
        return f"I can help with mathematical queries using Wolfram|Alpha, but I need Ollama running with {OLLAMA_MODEL} for proper AI interpretation{error_msg}. Please set up Ollama to get the full experience."
    
    else:
        return f"I'm currently running in fallback mode because Ollama is not available{error_msg}. Please install and start Ollama with the {OLLAMA_MODEL} model to get full AI capabilities. For now, I can only provide basic responses."

def interpret_user_input(user_input: str) -> dict:
    """
    Use GPT-OSS-20B to write Mathematica code for Wolfram|Alpha queries.
    GPT-OSS's ONLY role: Convert user queries to Mathematica code. NO solving, NO interpretation.
    """
    interpretation_prompt = f"""
You are GPT-OSS-20B. Your ONLY job is to write Mathematica code for Wolfram|Alpha.

SIMPLE RULES:
1. If the user asks a math question → write Mathematica code
2. If the user asks a non-math question → don't use Wolfram|Alpha
3. That's it. No solving, no interpretation, no analysis.

User query: "{user_input}"

Return JSON:
{{
    "requires_wolfram": true/false,
    "interpreted_query": "Mathematica code or null"
}}

Examples:
- "What is 2+2?" → {{"requires_wolfram": true, "interpreted_query": "2 + 2"}}
- "How are you?" → {{"requires_wolfram": false, "interpreted_query": null}}
- "Solve x^2 = 4" → {{"requires_wolfram": true, "interpreted_query": "Solve[x^2 == 4, x]"}}
- "Find derivative of x^2" → {{"requires_wolfram": true, "interpreted_query": "D[x^2, x]"}}
- "Integrate x^2" → {{"requires_wolfram": true, "interpreted_query": "Integrate[x^2, x]"}}
- "Plot sin(x)" → {{"requires_wolfram": true, "interpreted_query": "Plot[Sin[x], {{x, -2*Pi, 2*Pi}}]"}}

Response (JSON only):
"""
    
    response = generate_response(interpretation_prompt, max_length=400, temperature=0.2)
    
    try:
        # Try to extract JSON from the response
        json_match = re.search(r'\{.*\}', response, re.DOTALL)
        if json_match:
            return json.loads(json_match.group())
        else:
            # Fallback if JSON parsing fails
            return {
                "requires_wolfram": should_use_wolfram(user_input),
                "interpreted_query": user_input if should_use_wolfram(user_input) else None
            }
    except Exception as e:
        return {
            "requires_wolfram": should_use_wolfram(user_input),
            "interpreted_query": user_input if should_use_wolfram(user_input) else None
        }

def get_mathematical_solution_schema() -> dict:
    """
    Define the schema for extracting mathematical solutions from Wolfram results.
    """
    return {
        "problem_type": "string describing the type of mathematical problem",
        "solution_method": "string describing the method used to solve the problem",
        "steps": [
            {
                "step_number": "integer",
                "description": "string describing what this step does",
                "latex_expression": "string with LaTeX mathematical expression",
                "explanation": "string explaining the step"
            }
        ],
        "final_answer": "string with the final answer in LaTeX format",
        "verification": "string with verification steps if applicable",
        "alternative_methods": "array of strings describing alternative solution methods if any"
        }

def interpret_wolfram_result(wolfram_result: str, original_query: str, interpretation: dict = None) -> dict:
    """
    Use NuExtract with GPT-OSS-20B to provide structured mathematical solutions.
    GPT-OSS's role: Extract and format Wolfram results, NOT solve problems.
    """
    # Extract LaTeX from Wolfram result
    latex_result = extract_latex_from_wolfram(wolfram_result)
    
    # Create the input text for NuExtract
    extraction_text = f"""
Original user query: {original_query}
Wolfram|Alpha result: {wolfram_result}
LaTeX formatted result: {latex_result}

Please extract the mathematical solution information from this Wolfram|Alpha result.
"""
    
    # Define examples for better extraction
    examples = [
        {
            "problem_type": "quadratic equation",
            "solution_method": "quadratic formula",
            "steps": [
                {
                    "step_number": 1,
                    "description": "Rearrange equation to standard form",
                    "latex_expression": "x^2 + 18 = 15x \\Longrightarrow x^2 - 15x + 18 = 0",
                    "explanation": "Move all terms to one side to get standard quadratic form"
                },
                {
                    "step_number": 2,
                    "description": "Calculate discriminant",
                    "latex_expression": "\\Delta = (-15)^2 - 4\\cdot1\\cdot18 = 225 - 72 = 153 = 9\\cdot17",
                    "explanation": "Use the discriminant formula b² - 4ac"
                },
                {
                    "step_number": 3,
                    "description": "Apply quadratic formula",
                    "latex_expression": "x = \\frac{15 \\pm \\sqrt{153}}{2} = \\frac{15 \\pm 3\\sqrt{17}}{2} = \\frac{3}{2}(5 \\pm \\sqrt{17})",
                    "explanation": "Substitute values into the quadratic formula"
                }
            ],
            "final_answer": "\\boxed{x = \\frac{3}{2}(5 + \\sqrt{17}) \\text{ or } x = \\frac{3}{2}(5 - \\sqrt{17})}",
            "verification": "Substitute back into original equation to verify",
            "alternative_methods": ["factoring", "completing the square"]
        }
    ]
    
    try:
        # Use NuExtract to extract structured data
        extracted_data = extract(
            text=extraction_text,
            schema=get_mathematical_solution_schema(),
            examples=examples,
            model_name="numind/NuExtract-large",
            max_input_tokens=4000,
            max_new_tokens=2048,
            user_context="Extract mathematical solution information with proper LaTeX formatting"
        )
        
        # Process the extracted data
        if isinstance(extracted_data, dict):
            # Extract LaTeX expressions from steps
            latex_expressions = []
            latex_steps = []
            
            if "steps" in extracted_data and isinstance(extracted_data["steps"], list):
                for step in extracted_data["steps"]:
                    if isinstance(step, dict) and "latex_expression" in step:
                        cleaned_expr = clean_latex_expression(step["latex_expression"])
                        validated_expr = validate_and_complete_latex(cleaned_expr)
                        latex_expressions.append(validated_expr)
                        latex_steps.append(validated_expr)
            
            # Get final answer
            final_answer = extracted_data.get("final_answer", "")
            if final_answer:
                cleaned_answer = clean_latex_expression(final_answer)
                final_answer = validate_and_complete_latex(cleaned_answer)
                if final_answer not in latex_expressions:
                    latex_expressions.append(final_answer)
            
            # If no expressions were extracted, fall back to the original result
            if not latex_expressions:
                clean_result = clean_latex_expression(latex_result if latex_result else wolfram_result)
                validated_result = validate_and_complete_latex(clean_result)
                if validated_result:
                    latex_expressions = [validated_result]
                    final_answer = validated_result
            
            return {
                "final_answer": final_answer,
                "latex_steps": latex_steps,
                "latex_expressions": latex_expressions,
                "extracted_data": extracted_data  # Include the full extracted data for reference
            }
        else:
            # Fallback if extraction returns string instead of dict
            clean_result = clean_latex_expression(latex_result if latex_result else wolfram_result)
            validated_result = validate_and_complete_latex(clean_result)
            return {
                "final_answer": validated_result,
                "latex_steps": [],
                "latex_expressions": [validated_result] if validated_result else [],
                "extracted_data": {"raw_extraction": str(extracted_data)}
            }
            
    except Exception as e:
        # Fallback to original method if NuExtract fails
        print(f"NuExtract failed, falling back to original method: {e}")
        clean_result = clean_latex_expression(latex_result if latex_result else wolfram_result)
        validated_result = validate_and_complete_latex(clean_result)
        return {
            "final_answer": validated_result,
            "latex_steps": [],
            "latex_expressions": [validated_result] if validated_result else [],
            "extracted_data": {"error": str(e), "fallback": True}
        }

def should_use_wolfram(user_message: str) -> bool:
    """
    Determine if the user message requires Wolfram|Alpha computation.
    """
    wolfram_keywords = [
        "integrate", "derivative", "solve", "calculate", "compute", "math", 
        "equation", "function", "graph", "plot", "convert", "unit", "formula",
        "algebra", "calculus", "statistics", "probability", "matrix", "vector"
    ]
    
    message_lower = user_message.lower()
    return any(keyword in message_lower for keyword in wolfram_keywords)

def extract_wolfram_query(user_message: str) -> str:
    """
    Extract or construct a Wolfram|Alpha query from the user message.
    """
    # For now, use the user message directly as the query
    # In a more sophisticated implementation, you could parse and reformat the query
    return user_message

def chat_with_tools(user_message: str) -> dict:
    """
    Uses GPT-OSS-20B to write Mathematica code for Wolfram|Alpha and present readable step-by-step solutions in LaTeX format.
    GPT-OSS's role: Convert queries to Mathematica code and present Wolfram answers as readable step-by-step solutions in LaTeX ONLY, NOT solving mathematical problems.
    """
    # Step 1: GPT-OSS-20B converts the user's input into Mathematica code
    interpretation = interpret_user_input(user_message)
    
    if interpretation["requires_wolfram"]:
        # Step 2: Use Wolfram|Alpha with the translated query (Wolfram does the solving)
        wolfram_query = interpretation["interpreted_query"] or user_message
        wolfram_result = wolfram_short_answer(wolfram_query)
        
        # Step 3: Use raw Wolfram result for LaTeX conversion
        interpreted_result = {
            "final_answer": wolfram_result,
            "latex_steps": [],
            "latex_expressions": [wolfram_result]
        }
        
        # Step 4: Present Wolfram answer as readable step-by-step solution in LaTeX
        final_prompt = f"""You are GPT-OSS-20B. Your primary job is to present Wolfram|Alpha's answer in a clear, readable, and step-by-step manner, ensuring all mathematical content is in proper LaTeX format.

User asked: "{user_message}"
Mathematica code used: "{wolfram_query}"
Wolfram|Alpha answered: "{wolfram_result}"

CRITICAL INSTRUCTIONS - Follow this EXACT format:

1. **Use the exact step-by-step structure:**
   - **Step 1: Write the given [equation type]**
   - **Step 2: [Action description]**
   - **Step 3: [Action description]**
   - **Result** (or **Mathematical Solution** for complex problems)

2. **LaTeX formatting rules:**
   - Use inline LaTeX with single $ delimiters for all mathematical expressions
   - Use \\quad or \\Longrightarrow for visual spacing/arrows between steps
   - Use \\frac{{numerator}}{{denominator}} for fractions
   - Use \\boxed{{answer}} for final answers
   - Keep sentences as plain text; put only mathematical symbols inside $...$
   - Use \\[ and \\] for display math blocks with \\begin{{aligned}}...\\end{{aligned}} for multi-line derivations

3. **For linear equations like 2x + 5 = 13, use this EXACT format:**
```
**Step 1: Write the given linear equation**

$2x + 5 = 13$

**Step 2: Isolate the term containing $x$**

Subtract $5$ from both sides:
$2x + 5 - 5 = 13 - 5 \\;\\Rightarrow\\; 2x = 8$

**Step 3: Solve for $x$**

Divide both sides by the coefficient $(2)$:
$\\frac{{2x}}{{2}} = \\frac{{8}}{{2}} \\;\\Rightarrow\\; x = 4$

**Result**

$\\boxed{{x = 4}}$
```

4. **For complex problems, add a Mathematical Solution block:**
```
**Mathematical Solution**

\\[
\\begin{{aligned}}
2x + 5 &= 13 \\\\
2x &= 13 - 5 \\\\
2x &= 8 \\\\
x &= \frac{{8}}{{2}} \\\\
\boxed{{x = 4}}
\\end{{aligned}}
\\\\]
```

5. **Do NOT solve the problem yourself.** Wolfram|Alpha has already provided the solution. Your role is to format and present it in this exact structure.

Response:"""
        
        response = generate_response(final_prompt, max_length=2000, temperature=0.3)
        
        # Clean up LaTeX formatting in the response
        cleaned_response = clean_latex_output(response)
        
        # Return simple response dictionary
        return {
            "response": cleaned_response,
            "wolfram_query": wolfram_query,
            "wolfram_result": wolfram_result,
            "interpretation": interpretation,
            "final_answer": interpreted_result.get("final_answer", ""),
            "latex_steps": interpreted_result.get("latex_steps", []),
            "latex_expressions": interpreted_result.get("latex_expressions", []),
            "requires_wolfram": True
        }
    else:
        # Answer directly without Wolfram|Alpha (conversational queries)
        direct_prompt = f"""You are GPT-OSS-20B. Answer this question directly: "{user_message}"

Response:"""
        
        response = generate_response(direct_prompt, max_length=512, temperature=0.7)
        
        # Return response dictionary for consistency
        return {
            "response": response,
            "wolfram_query": None,
            "wolfram_result": None,
            "interpretation": interpretation,
            "final_answer": None,
            "latex_steps": [],
            "latex_expressions": [],
            "requires_wolfram": False
        }


if __name__ == "__main__":
    # Demo prompts
    print("=== WolframGPT Demo ===")
    
    demo_queries = [
        "Compute the integral of sin(x)^3 from 0 to pi.",
        "What is the derivative of x^x?",
        "Solve 2x + 5 = 13",
        "Convert 100 miles to kilometers"
    ]
    
    for query in demo_queries:
        print(f"\nQuery: {query}")
        print("-" * 50)
        result = chat_with_tools(query)
        
        if isinstance(result, dict):
            print(f"Response: {result['response']}")
            if result['requires_wolfram']:
                print(f"Wolfram Query: {result['wolfram_query']}")
                print(f"Wolfram Result: {result['wolfram_result']}")
                print(f"LaTeX Expressions: {result['latex_expressions']}")
                print(f"Query Type: {result['query_type']}")
                print(f"Confidence: {result['confidence']}")
        else:
            print(f"Response: {result}")
        print("-" * 50)