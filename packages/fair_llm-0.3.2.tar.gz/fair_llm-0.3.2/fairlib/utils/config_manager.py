# fairlib/utils/config_manager.py
"""
Unified configuration management.

This module provides a clean API for saving and loading agent configurations.
It shares a schema with fair_prompt_optimizer so optimized configs can be
loaded directly into fairlib agents.

Key design:

- prompts section maps 1:1 to PromptBuilder fields
- model section defines LLM construction
- agent section defines agent construction
- optimization section (optional) tracks optimization provenance

This is the single source of truth for config format. fair_prompt_optimizer
uses the same schema, so configs flow seamlessly between optimization and
runtime.
"""

import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, Any

logger = logging.getLogger(__name__)

from fairlib import (
    PromptBuilder,
    BaseAgent,
    AbstractChatModel,
    HierarchicalAgentRunner
)

def _get_tool_registry() -> Dict[str, type]:
    """
    Returns a mapping of tool class names to their classes.
    """
    from fairlib.modules.action.tools.builtin_tools.safe_calculator import SafeCalculatorTool
    # TODO:: Design choice, is it correct principle to export all of our tools here??
    # from fairlib.modules.action.tools.builtin_tools.web_search import WebSearchTool
    
    return {
        "SafeCalculatorTool": SafeCalculatorTool,
        # "WebSearchTool": WebSearchTool,
    }

def extract_prompts(builder: 'PromptBuilder') -> Dict[str, Any]:
    """
    Extract prompts from a PromptBuilder into a serializable dict.

    This is the canonical serialization of PromptBuilder state.
    Maps exactly to the `prompts` section of config JSON.
    """
    # Handle role_definition - could be RoleDefinition object or string
    role_def = builder.role_definition
    if role_def is None:
        role_definition_text = None
    elif hasattr(role_def, 'text'):
        role_definition_text = role_def.text
    else:
        # It's a plain string
        role_definition_text = str(role_def)

    # Handle tool_instructions - could be ToolInstruction objects or dicts
    tool_instructions = []
    for ti in builder.tool_instructions:
        if hasattr(ti, 'name') and hasattr(ti, 'description'):
            tool_instructions.append({"name": ti.name, "description": ti.description})
        elif isinstance(ti, dict):
            tool_instructions.append(ti)

    # Handle worker_instructions
    worker_instructions = []
    for wi in builder.worker_instructions:
        if hasattr(wi, 'name') and hasattr(wi, 'role_description'):
            worker_instructions.append({"name": wi.name, "role_description": wi.role_description})
        elif isinstance(wi, dict):
            worker_instructions.append(wi)

    # Handle format_instructions - could be FormatInstruction objects or strings
    format_instructions = []
    for fi in builder.format_instructions:
        if hasattr(fi, 'text'):
            format_instructions.append(fi.text)
        else:
            format_instructions.append(str(fi))

    # Handle examples - could be Example objects or strings
    examples = []
    for ex in builder.examples:
        if hasattr(ex, 'text'):
            examples.append(ex.text)
        else:
            examples.append(str(ex))

    return {
        "role_definition": role_definition_text,
        "tool_instructions": tool_instructions,
        "worker_instructions": worker_instructions,
        "format_instructions": format_instructions,
        "examples": examples,
    }


def apply_prompts(prompts: Dict[str, Any], builder: 'PromptBuilder') -> 'PromptBuilder':
    """
    Apply prompts from a dict to a PromptBuilder.
    
    This is the canonical deserialization - restores saved prompts
    back to a PromptBuilder instance.
    """
    from fairlib.core.prompts import (
        RoleDefinition, ToolInstruction, WorkerInstruction,
        FormatInstruction, Example
    )
    
    # Role definition
    if prompts.get("role_definition"):
        builder.role_definition = RoleDefinition(prompts["role_definition"])
    
    # Tool instructions (clear and replace)
    builder.tool_instructions.clear()
    for ti in prompts.get("tool_instructions", []):
        builder.tool_instructions.append(
            ToolInstruction(ti["name"], ti["description"])
        )
    
    # Worker instructions (clear and replace)
    builder.worker_instructions.clear()
    for wi in prompts.get("worker_instructions", []):
        builder.worker_instructions.append(
            WorkerInstruction(wi["name"], wi["role_description"])
        )
    
    # Format instructions (clear and replace)
    builder.format_instructions.clear()
    for fi_text in prompts.get("format_instructions", []):
        builder.format_instructions.append(FormatInstruction(fi_text))
    
    # Examples (clear and replace)
    builder.examples.clear()
    for ex_text in prompts.get("examples", []):
        builder.examples.append(Example(ex_text))
    
    return builder


def extract_config(agent: 'BaseAgent') -> Dict[str, Any]:
    """
    Extract complete configuration from a running agent.
    
    Returns a dict that can be:
    1. Saved to JSON
    2. Loaded back to reconstruct the agent
    3. Used by fair_prompt_optimizer for optimization
    """
    # Extract prompts from planner's prompt_builder
    prompts = {}
    if hasattr(agent, 'planner') and hasattr(agent.planner, 'prompt_builder'):
        prompts = extract_prompts(agent.planner.prompt_builder)
    
    # Extract model info
    llm = agent.llm
    model = {
        "adapter": llm.__class__.__name__,
        "model_name": getattr(llm, 'model_name', getattr(llm, 'model', 'unknown')),
        "adapter_kwargs": {}
    }
    # TODO:: May need to extract more fields here
    if hasattr(llm, 'temperature'):
        model["adapter_kwargs"]["temperature"] = llm.temperature
    if hasattr(llm, 'max_tokens'):
        model["adapter_kwargs"]["max_tokens"] = llm.max_tokens
    
    # Extract tool names
    tools = []
    if hasattr(agent, 'planner') and hasattr(agent.planner, 'tool_registry'):
        tools = [
            tool.__class__.__name__
            for tool in agent.planner.tool_registry.get_all_tools().values()
        ]
    
    # Extract agent spec
    agent_spec = {
        "agent_type": agent.__class__.__name__,
        "planner_type": (
            agent.planner.__class__.__name__ 
            if hasattr(agent, 'planner') else "SimpleReActPlanner"
        ),
        "tools": tools,
        "max_steps": getattr(agent, 'max_steps', 10),
        "stateless": getattr(agent, 'stateless', False),
    }
    
    # Build config
    # TODO:: persist this version value somewhere else
    config = {
        "version": "1.0",
        "type": "agent",
        "prompts": prompts,
        "model": model,
        "agent": agent_spec,
        "metadata": {
            "exported_at": datetime.now().isoformat(),
            "source": "fairlib.utils.config_manager",
        }
    }
    
    return config


def save_agent_config(agent: 'BaseAgent', path: str) -> Dict[str, Any]:
    """
    Save an agent's complete configuration to a JSON file.
    
    The saved config can be:
    1. Loaded back into fairlib with load_agent()
    2. Used by fair_prompt_optimizer for optimization
    3. Manually edited and reloaded
    
    Args:
        agent: A configured FAIR-LLM agent
        path: Output file path
        
    Returns:
        The extracted config dict
    """
    config = extract_config(agent)
    
    filepath = Path(path)
    filepath.parent.mkdir(parents=True, exist_ok=True)
    
    with open(filepath, 'w') as f:
        json.dump(config, f, indent=2)
    
    logger.info(f"Saved agent configuration to {filepath}")
    return config


def load_agent_config(path: str) -> Dict[str, Any]:
    """
    Load a configuration file and return the raw dictionary.
    """
    filepath = Path(path)
    
    if not filepath.exists():
        raise FileNotFoundError(f"Config file not found: {filepath}")
    
    with open(filepath, 'r') as f:
        config = json.load(f)
    
    return config


def load_agent(path: str, llm: 'AbstractChatModel') -> 'BaseAgent':
    """
    Load an agent configuration and return a fully constructed agent.
    
    This handles configs from:
    1. save_agent_config() - standard fairlib configs
    2. fair_prompt_optimizer - optimized configs with provenance
    
    Args:
        path: Path to config JSON
        llm: The LLM to use (adapter instance)
        
    Returns:
        A fully configured SimpleAgent
    """
    from fairlib import (
        ToolRegistry,
        ToolExecutor,
        WorkingMemory,
        SimpleAgent,
        SimpleReActPlanner,
    )
    
    config = load_agent_config(path)
    
    # Get sections
    prompts = config.get("prompts", {})
    agent_spec = config.get("agent", {})
    
    # --- Build Tool Registry ---
    tool_registry = ToolRegistry()
    tool_classes = _get_tool_registry()
    
    for tool_name in agent_spec.get("tools", []):
        if tool_name in tool_classes:
            tool_registry.register_tool(tool_classes[tool_name]())
        else:
            logger.warning(f"Unknown tool '{tool_name}', skipping")
    
    # --- Build Planner with PromptBuilder ---
    planner = SimpleReActPlanner(llm, tool_registry)
    
    # Apply prompts to the planner's prompt_builder
    apply_prompts(prompts, planner.prompt_builder)
    
    # --- Build Agent ---
    agent = SimpleAgent(
        llm=llm,
        planner=planner,
        tool_executor=ToolExecutor(tool_registry),
        memory=WorkingMemory(),
        max_steps=agent_spec.get("max_steps", 10),
        stateless=agent_spec.get("stateless", False),
    )
    
    # Set role description for worker identification
    if prompts.get("role_definition"):
        agent.role_description = prompts["role_definition"]
    
    return agent


def load_prompts_into_agent(path: str, agent: 'BaseAgent'):
    """
    Load prompts from a config file into an existing agent.
    
    Useful for:
    1. Hot-reloading optimized prompts without rebuilding agent
    2. A/B testing different prompt versions
    
    Args:
        path: Path to config JSON
        agent: Existing agent to update
    """
    config = load_agent_config(path)
    prompts = config.get("prompts", {})
    
    if hasattr(agent, 'planner') and hasattr(agent.planner, 'prompt_builder'):
        apply_prompts(prompts, agent.planner.prompt_builder)
        logger.info(f"Loaded prompts into agent from {path}")
    else:
        raise ValueError("Agent does not have a planner with prompt_builder")


def extract_multi_agent_config(runner: 'HierarchicalAgentRunner') -> Dict[str, Any]:
    """
    Extract complete configuration from a HierarchicalAgentRunner.
    """
    config = {
        "version": "1.0",
        "type": "multi_agent",
        "manager": extract_config(runner.manager),
        "workers": {
            name: extract_config(worker)
            for name, worker in runner.workers.items()
        },
        "max_delegation_steps": runner.max_steps,
        "metadata": {
            "exported_at": datetime.now().isoformat(),
            "source": "fairlib.utils.config_manager",
        }
    }
    return config


def save_multi_agent_config(runner: 'HierarchicalAgentRunner', path: str) -> Dict[str, Any]:
    """
    Save a HierarchicalAgentRunner's complete configuration.
    """
    config = extract_multi_agent_config(runner)
    
    filepath = Path(path)
    filepath.parent.mkdir(parents=True, exist_ok=True)
    
    with open(filepath, 'w') as f:
        json.dump(config, f, indent=2)
    
    logger.info(f"Saved multi-agent configuration to {filepath}")
    return config


def load_multi_agent(path: str, llm: 'AbstractChatModel') -> 'HierarchicalAgentRunner':
    """
    Load a multi-agent configuration and return a HierarchicalAgentRunner.
    
    Args:
        path: Path to config JSON
        llm: Default LLM to use (can be overridden per-agent in config)
        
    Returns:
        A configured HierarchicalAgentRunner
    """
    from fairlib.modules.agent.multi_agent_runner import (
        HierarchicalAgentRunner,
        ManagerPlanner,
    )
    from fairlib import (
        ToolRegistry,
        ToolExecutor,
        WorkingMemory,
        SimpleAgent,
    )
    from fairlib.core.prompts import PromptBuilder
    
    config = load_agent_config(path)
    
    if config.get("type") != "multi_agent":
        raise ValueError(f"Expected multi_agent config, got: {config.get('type')}")
    
    # --- Build Workers ---
    workers = {}
    for worker_name, worker_config in config.get("workers", {}).items():
        # Each worker is a SimpleAgent
        worker = load_agent_from_config_dict(worker_config, llm)
        worker.stateless = True  # Workers are always stateless
        workers[worker_name] = worker
    
    # --- Build Manager ---
    manager_config = config.get("manager", {})
    manager_prompts = manager_config.get("prompts", {})
    
    # Build manager's prompt builder
    prompt_builder = PromptBuilder()
    apply_prompts(manager_prompts, prompt_builder)
    
    # Manager planner uses ManagerPlanner, not SimpleReActPlanner
    manager_planner = ManagerPlanner(llm, workers, prompt_builder)
    
    manager = SimpleAgent(
        llm=llm,
        planner=manager_planner,
        tool_executor=ToolExecutor(ToolRegistry()),  # Manager doesn't use tools
        memory=WorkingMemory(),
        max_steps=config.get("max_delegation_steps", 15),
    )
    
    if manager_prompts.get("role_definition"):
        manager.role_description = manager_prompts["role_definition"]
    
    # --- Build Runner ---
    runner = HierarchicalAgentRunner(
        manager_agent=manager,
        workers=workers,
        max_steps=config.get("max_delegation_steps", 15),
    )
    
    return runner


def load_agent_from_config_dict(config: Dict[str, Any], llm: 'AbstractChatModel') -> 'BaseAgent':
    """
    Build an agent from a config dict (not a file path).
    
    Internal helper for load_multi_agent.
    """
    from fairlib import (
        ToolRegistry,
        ToolExecutor,
        WorkingMemory,
        SimpleAgent,
        SimpleReActPlanner,
    )
    
    prompts = config.get("prompts", {})
    agent_spec = config.get("agent", {})
    
    # Build tool registry
    tool_registry = ToolRegistry()
    tool_classes = _get_tool_registry()
    
    for tool_name in agent_spec.get("tools", []):
        if tool_name in tool_classes:
            tool_registry.register_tool(tool_classes[tool_name]())
    
    # Build planner — respect the saved planner_type
    planner_type = agent_spec.get("planner_type", "SimpleReActPlanner")
    if planner_type == "ReActPlanner":
        from fairlib import ReActPlanner
        planner = ReActPlanner(llm, tool_registry)
    else:
        planner = SimpleReActPlanner(llm, tool_registry)
    apply_prompts(prompts, planner.prompt_builder)
    
    # Build agent
    agent = SimpleAgent(
        llm=llm,
        planner=planner,
        tool_executor=ToolExecutor(tool_registry),
        memory=WorkingMemory(),
        max_steps=agent_spec.get("max_steps", 10),
        stateless=agent_spec.get("stateless", False),
    )
    
    if prompts.get("role_definition"):
        agent.role_description = prompts["role_definition"]
    
    return agent