# fairlib.utils/chart_utils.py

import os
import re
import subprocess
import json
import ast
from typing import Tuple, List, Dict
import traceback
from re import IGNORECASE, DOTALL, MULTILINE # Import specific flags

# Import framework components
from fairlib.core.prompts import PromptBuilder, RoleDefinition
from fairlib.core.interfaces.llm import AbstractChatModel
from fairlib.core.config import settings
import logging

# Set up logging
logger = logging.getLogger(__name__)

def log_message(message: str, level: str = "info"):
    """Log a message with the specified level."""
    if level == "error":
        logger.error(message)
    elif level == "warning":
        logger.warning(message)
    else:
        logger.info(message)

# Configuration constants - these should eventually be moved to settings.yml
CHART_IMAGE_OUTPUT_FILENAME = "chart.png"
CHART_SCRIPT_FILENAME = "chart_script.py"
MAX_ANSWER_CONTEXT_FOR_CHART_CODE_GEN = 1000
MAX_EDA_SUMMARY_FOR_CHART_CODE_GEN = 500


def extract_structured_data(answer: str, attempt_llm_fix=True, llm_model=None) -> dict:
    log_message(f"Attempting to extract structured data from answer (first 100 chars): {answer[:100]}...")
    match_direct = re.search(r'(\{[\s\S]*\})', answer)
    if match_direct:
        json_candidate_str = match_direct.group(1)
        try:
            data = json.loads(json_candidate_str)
            log_message(f"Successfully parsed JSON directly: {list(data.keys()) if isinstance(data,dict) else 'Non-dict JSON'}")
            return data if isinstance(data, dict) else {}
        except json.JSONDecodeError as e:
            log_message(f"Direct JSON parsing failed: {e}. Content: '{json_candidate_str[:100]}...'", "warning")

    if not attempt_llm_fix or not llm_model:
        log_message("Skipping LLM fix for JSON extraction as per parameter or no model provided.")
        return {}

    log_message("Direct JSON parsing failed or no clear block found, attempting LLM-assisted extraction/fixing.")
    
    # Use PromptBuilder for structured prompt creation
    prompt_builder = PromptBuilder()
    prompt_builder.add_system_instruction(
        "You are a JSON extraction assistant. Extract or reconstruct JSON objects from text. "
        "Focus on keys like 'x', 'y', 'labels', 'values', 'chart_type'. "
        "If the JSON is malformed, try to fix it. If no clear JSON is present, return an empty JSON object {}."
    )
    prompt_builder.add_user_message(f"Extract JSON from this text:\n{answer}")
    
    try:
        # Use the LLM model through the framework
        json_str_from_llm = llm_model.invoke(prompt_builder.build_prompt_string())
    except Exception as e:
        log_message(f"LLM failed during JSON extraction: {e}", "error")
        return {}

    match_llm = re.search(r'(\{[\s\S]*\})', json_str_from_llm)
    cleaned_json_str = match_llm.group(1) if match_llm else json_str_from_llm.strip()

    try:
        data = json.loads(cleaned_json_str)
        log_message(f"Successfully parsed JSON via LLM: {list(data.keys()) if isinstance(data,dict) else 'Non-dict JSON'}")
        return data if isinstance(data, dict) else {}
    except json.JSONDecodeError:
        try:
            data = ast.literal_eval(cleaned_json_str) # Fallback to ast.literal_eval
            log_message(f"Successfully parsed Python literal via ast.literal_eval from LLM output: {list(data.keys()) if isinstance(data,dict) else 'Non-dict literal'}")
            return data if isinstance(data, dict) else {}
        except (ValueError, SyntaxError, TypeError) as e_ast:
            log_message(f"extract_structured_data: LLM-assisted parsing (json and ast) failed for: '{cleaned_json_str[:200]}...'. AST Error: {e_ast}", "warning")
            return {}

def extract_json_from_final_answer(final_answer: str, llm_model=None) -> dict:
    log_message("Extracting JSON from final answer using LLM model.")
    return extract_structured_data(final_answer, attempt_llm_fix=True, llm_model=llm_model)


def perform_chart_focused_eda(documents: List[str], query: str, llm_model=None) -> str:
    log_message(f"Performing chart-focused EDA for query: '{query[:70]}...'")
    if not documents:
        log_message("No documents provided for EDA.", "warning")
        return "No documents were available for EDA to analyze."

    concatenated_documents = "\n\n---\n\n".join([doc[:1000] for doc in documents[:10]])

    if not llm_model:
        log_message("No LLM model provided for EDA.", "warning")
        return "No LLM model available for Exploratory Data Analysis."

    prompt_builder = PromptBuilder()
    prompt_builder.role_definition = RoleDefinition(
        "You are a data analysis assistant specializing in chart creation. "
        "Analyze text snippets to identify data suitable for creating charts. "
        "Focus on extracting numerical data, categories, and relationships that can be visualized."
    )
    
    user_message = (
        f"User Query: \"{query}\"\n\n"
        f"Available Text Snippets (sample of {len(documents[:10])} snippets, up to 1000 chars each):\n{concatenated_documents}\n\n"
        "Task: Analyze these snippets to identify data suitable for creating a chart that addresses the user's query. Your analysis should cover:\n"
        "1. Potential Data Series: Explicitly list labels and corresponding numerical values (e.g., categories and counts, time periods and amounts).\n"
        "2. Key Numerical Data: Highlight any specific counts, sums, averages, or percentages directly relevant to the query.\n"
        "3. Relevant Categories: List distinct categories and their frequencies if they appear important for the query.\n"
        "4. Potential Relationships: Briefly describe relationships between data elements that could be visualized.\n"
        "5. Suggested Chart Data Structure: Propose a simple JSON structure for the plottable data. "
        "   Example: {{\"chart_type\": \"bar\", \"labels\": [...], \"values\": [...], \"x_axis_label\": \"Category\", \"y_axis_label\": \"Count\"}}\n"
        "   This structure should be easily translatable into variables like `labels_data`, `values_data` for a plotting script.\n\n"
        "Provide a concise and structured EDA summary focused *only* on information relevant to charting for the given query."
    )
    # Build the system prompt
    system_prompt = prompt_builder.build_system_prompt_string()
    
    # Combine system prompt and user message
    full_prompt = f"{system_prompt}\n\n{user_message}"

    try:
        eda_summary = llm_model.invoke(full_prompt)
    except Exception as e:
        log_message(f"Chart-focused EDA failed: {e}", "error")
        return f"Error during Exploratory Data Analysis: {e}"

    log_message("Chart-focused EDA performed successfully.")
    return eda_summary


def infer_chart_type(user_query: str, answer_or_eda: str) -> str:
    log_message(f"Inferring chart type. Query: '{user_query[:70]}...'. Answer/EDA (first 70): '{answer_or_eda[:70]}...'")
    query_lower = user_query.lower()
    chart_type_keywords = {
        "pie chart": "pie", "pie graph": "pie",
        "bar chart": "bar", "bar graph": "bar", "barchart": "bar",
        "horizontal bar": "barh", "horizontal graph": "barh",
        "line chart": "line", "line graph": "line", "trend chart": "line",
        "scatter plot": "scatter", "scatter graph": "scatter",
        "histogram": "histogram", "distribution chart": "histogram",
        "box plot": "box", "boxplot": "box",
        "area chart": "area", "stacked area": "area"
    }
    for keyword, chart_type_val in chart_type_keywords.items():
        if keyword in query_lower:
            log_message(f"Chart type '{chart_type_val}' inferred from query keyword: '{keyword}'")
            return chart_type_val

    text_lower = answer_or_eda.lower()
    for keyword, chart_type_val in chart_type_keywords.items():
        if keyword in text_lower:
            log_message(f"Chart type '{chart_type_val}' inferred from answer/EDA keyword: '{keyword}'")
            return chart_type_val

    if "distribution of" in text_lower: return "histogram"
    if "correlation between" in text_lower or "relationship between two numerical" in text_lower : return "scatter"
    if "proportions of" in text_lower or "percentage breakdown" in text_lower: return "pie"
    if "comparison of categories" in text_lower or "counts per category" in text_lower: return "bar"
    if "trend over time" in text_lower or "time series data" in text_lower: return "line"

    default_chart_type = "bar"
    log_message(f"Defaulting chart type to '{default_chart_type}' due to ambiguity.")
    return default_chart_type


def clean_llm_code(raw_code: str, is_final_pass=False) -> str:
    log_message(f"Cleaning LLM code (is_final_pass={is_final_pass}). Raw (first 100): {raw_code[:100]}...")
    code = re.sub(r"^.*?```(?:python)?\n", "", raw_code, flags=DOTALL | MULTILINE)
    code = re.sub(r"\n```.*?$", "", code, flags=DOTALL | MULTILINE)
    code = code.strip()

    code = re.sub(r"<think>.*?</think>", "", code, flags=DOTALL|IGNORECASE)
    code = re.sub(r"</?(?:code|python)>", "", code, flags=IGNORECASE)

    lines = code.splitlines()
    cleaned_lines = []

    explanation_phrases = [
        "this script", "this code", "here's the python code", "the python code above",
        "this will generate", "it uses matplotlib",
        "explanation:", "note:", "make sure you have", "to run this",
        "the data is assumed to be", "example usage:", "you can use this code"
    ]
    for ln_idx, ln in enumerate(lines):
        stripped_ln = ln.strip()
        if not stripped_ln: continue
        if stripped_ln.startswith("#"): continue
        if stripped_ln.lower() == "python": continue

        is_explanation = False
        if any(phrase in stripped_ln.lower() for phrase in explanation_phrases):
            if not re.match(r"^\s*(import|from|def|class|\w+\s*=|plt\.)", stripped_ln):
                if ln_idx > 0 and ("=" in lines[ln_idx-1] and not lines[ln_idx-1].strip().endswith(("\\", ","))):
                     is_explanation = True
                elif ln_idx == 0 :
                    is_explanation = True

        if is_explanation:
            log_message(f"Clean LLM Code: Skipping explanatory line: '{stripped_ln}'")
            continue
        cleaned_lines.append(ln)

    start_index = 0
    if is_final_pass and cleaned_lines:
        for i, ln in enumerate(cleaned_lines):
            if re.match(r"^\s*(import\s+matplotlib|from\s+matplotlib|def\s+\w+\s*\(|class\s+\w+\s*:|\w+\s*=[^=]|@\w+|\w+\s*\(|\s*plt\.)", ln):
                start_index = i
                break
        else:
            log_message("Clean LLM Code (final pass): No typical Python code start (import matplotlib, def, plt., etc.) found after filtering.", "warning")

    final_code_str = "\n".join(cleaned_lines[start_index:]).strip()

    if final_code_str.startswith("```python"): final_code_str = final_code_str[len("```python"):].strip()
    elif final_code_str.startswith("```"): final_code_str = final_code_str[len("```"):].strip()
    if final_code_str.endswith("```"): final_code_str = final_code_str[:-len("```")].strip()

    log_message(f"Cleaned LLM code (first 100): {final_code_str[:100]}...")
    return final_code_str


def validate_chart_code(code_str: str) -> bool:
    try:
        ast.parse(code_str)
    except SyntaxError as e:
        logger.error(f"Syntax error in generated code: {e}")
        return False
    try:
        # Flake8 might not be available in all environments, so this is optional
        lint = subprocess.run(
            ["flake8", "--max-line-length=100", "-"],
            input=code_str, text=True, capture_output=True, check=False
        )
        if lint.returncode != 0:
            logger.warning(f"Lint errors found in generated code:\n{lint.stdout}")
    except FileNotFoundError:
        logger.info("flake8 not found, skipping linting of generated code.")
    return True


def write_da_script(data: dict, chart_code: str):
    da_script_header = (
        "import matplotlib\n"
        "matplotlib.use('Agg') # Use Agg backend for non-interactive saving\n"
        "import matplotlib.pyplot as plt\n"
        "import pandas as pd # Often useful for plotting\n\n"
        "# Data provided from the application (may be empty if JSON extraction failed):\n"
        f"chart_type_data = {repr(data.get('chart_type'))}\n"
        f"x_data = {repr(data.get('x', []))}\n"
        f"y_data = {repr(data.get('y', []))}\n"
        f"labels_data = {repr(data.get('labels', []))}\n"
        f"values_data = {repr(data.get('values', []))}\n\n"
        "# User-generated chart code starts below (should handle potentially empty data vars and use Matplotlib ONLY):\n"
    )

    log_message(f"Code before user-specific regex in write_da_script (first 100): {chart_code[:100]}...")

    cleaned_code_pass_user_regex1 = re.sub(
        r'(?s)^.*?(?=^(?:import|from)\s)',
        '',
        chart_code,
        flags=MULTILINE
    )
    log_message(f"After user regex1 (strip before import/from) (first 100): {cleaned_code_pass_user_regex1[:100]}...")

    cleaned_code_pass_user_regex2 = re.sub(
        r'^(.*\([^)]*\)).*$',
        r'\1',
        cleaned_code_pass_user_regex1,
        flags=DOTALL
    )
    log_message(f"After user regex2 (truncate after last parenthesis block) (first 100): {cleaned_code_pass_user_regex2[:100]}...")

    final_chart_code_for_script = cleaned_code_pass_user_regex2.strip()
    if not final_chart_code_for_script:
        log_message("User regex2 resulted in empty code. Considering fallback.", "warning")
        final_chart_code_for_script = cleaned_code_pass_user_regex1.strip()
        if not final_chart_code_for_script:
            log_message("User regex1 also resulted in empty code. Falling back to chart_code before user regexes for da.py.", "warning")
            final_chart_code_for_script = chart_code.strip()
        else:
            log_message("Falling back to code after user regex1 only.", "info")
    else:
        log_message("Code after user regex2 seems non-empty.", "info")


    with open(CHART_SCRIPT_FILENAME, "w", encoding='utf-8') as f:
        f.write(da_script_header)
        f.write(final_chart_code_for_script)
    log_message(f"{CHART_SCRIPT_FILENAME} script written with processed chart code. Final written code (first 100): {final_chart_code_for_script[:100]}.")


def run_da_script_capture_error() -> Tuple[bool, str]:
    try:
        log_message(f"Executing {CHART_SCRIPT_FILENAME} script...")
        completed = subprocess.run(
            ["python", CHART_SCRIPT_FILENAME],
            check=True, capture_output=True, text=True, timeout=60, encoding='utf-8'
        )
        log_message(f"{CHART_SCRIPT_FILENAME} script executed successfully.")
        stdout_lower = completed.stdout.lower() if completed.stdout else ""
        if "error: data for chart is invalid or missing" in stdout_lower or \
           "could not determine data for chart" in stdout_lower or \
           "could not synthesize data from context" in stdout_lower:
            logger.warning(f"Script ran but indicated data insufficiency: {completed.stdout}")
        return True, completed.stdout if completed.stdout else "Script ran successfully (no stdout)."
    except subprocess.CalledProcessError as e:
        error_output = f"Script Execution Error (Return Code: {e.returncode}):\n"
        if e.stdout: error_output += f"STDOUT:\n{e.stdout}\n"
        if e.stderr: error_output += f"STDERR:\n{e.stderr}\n"
        if not e.stdout and not e.stderr: error_output += "No output from script."
        logger.error(f"{CHART_SCRIPT_FILENAME} script execution failed: {error_output}")
        return False, error_output
    except subprocess.TimeoutExpired:
        logger.error(f"{CHART_SCRIPT_FILENAME} script execution timed out.")
        return False, "Script execution timed out after 60 seconds."
    except Exception as e:
        logger.error(f"General error during {CHART_SCRIPT_FILENAME} script execution: {e}\n{traceback.format_exc()}")
        return False, f"General script execution error: {str(e)}"


def generate_chart(chart_code: str, data: dict) -> Tuple[bool, str]:
    write_da_script(data, chart_code)
    script_ran_successfully, output_message = run_da_script_capture_error()
    image_full_path = os.path.abspath(CHART_IMAGE_OUTPUT_FILENAME)

    if not script_ran_successfully:
        return False, output_message

    if os.path.exists(image_full_path) and os.path.getsize(image_full_path) > 100: # Basic check for valid image
        log_message(f"Chart image '{image_full_path}' found and seems valid.")
        return True, output_message
    else:
        log_message(f"Chart script ran (output: '{output_message}'), but image '{image_full_path}' not saved or is too small.")
        return False, f"Chart script ran, but the image ('{image_full_path}') was not saved correctly or is empty/too small.\nScript output:\n{output_message}"


def generate_code_for_chart_visualization(
    final_answer_text: str,
    chart_eda_summary: str,
    data_vars_info_for_prompt_str: str,
    user_query: str,
    actual_chart_type: str,
    json_extracted_data_is_sufficient: bool,
    llm_model=None
) -> str:
    log_message(f"Generating Matplotlib chart code. Type: '{actual_chart_type}'. JSON sufficient: {json_extracted_data_is_sufficient}. Query: '{user_query[:70]}...'.")

    data_usage_instruction = ""
    if json_extracted_data_is_sufficient:
        data_usage_instruction = (
            "3. Data Usage: Correctly use the global variables (`x_data`, `y_data`, `labels_data`, `values_data`) which are populated based on "
            "an attempt to extract structured JSON from the main textual answer. Ensure your script handles cases where these lists might still be empty or mismatched "
            "despite the extraction attempt (e.g., `len(labels_data) != len(values_data)`). If data is insufficient, print an informative error to stdout and avoid crashing."
        )
    else:
        data_usage_instruction = (
            "3. Data Usage: IMPORTANT! The global variables (`x_data`, `y_data`, `labels_data`, `values_data`) that would normally be populated from "
            "extracted JSON are expected to be EMPTY or INSUFFICIENT for this task. "
            "Therefore, your generated Python script MUST NOT rely on these global variables for plotting data. "
            "Instead, your script needs to DEFINE AND POPULATE ITS OWN DATA LISTS (e.g., local variables for labels and values, or x and y coordinates) "
            "DIRECTLY WITHIN THE SCRIPT. To create this data, analyze the 'User's Original Query', 'Exploratory Data Analysis (EDA) Summary', "
            "and 'Relevant part of the textual answer' provided in the 'CONTEXT FOR CHARTING' section. "
            "Synthesize plausible data that aligns with the query and the requested chart type using Matplotlib. "
            "For example, if the query is 'bar chart of fruit sales' and context suggests apples, bananas, oranges, your script should define "
            "something like `script_labels = ['Apples', 'Bananas', 'Oranges']` and `script_values = [10, 20, 15]`, and then use `plt.bar(script_labels, script_values)`. "
            "If context is too sparse even for this synthesis, your script should print an informative message like 'Error: Could not synthesize data from context for chart.' "
            f"to stdout, and can then save an empty chart to '{CHART_IMAGE_OUTPUT_FILENAME}' with a title such as 'No Data Synthesized' or 'Data Not Available from Context'. "
            "DO NOT attempt to use the global `labels_data`, `values_data`, etc., if you are in this data synthesis mode."
        )

    generation_prompt = (
        f"You are an expert Python data visualization programmer. Your task is to write a Python script to generate a '{actual_chart_type}' chart.\n"
        f"The user's original query was: \"{user_query}\"\n\n"
        f"{data_vars_info_for_prompt_str}\n\n"
        "CONTEXT FOR CHARTING:\n"
        "1. Exploratory Data Analysis (EDA) Summary (provides insights into available data patterns):\n"
        f"{chart_eda_summary[:MAX_EDA_SUMMARY_FOR_CHART_CODE_GEN]}" + ("..." if len(chart_eda_summary) > MAX_EDA_SUMMARY_FOR_CHART_CODE_GEN else "") + "\n\n"
        "2. Relevant part of the textual answer (for narrative understanding and potential data hints):\n"
        f"{final_answer_text[:MAX_ANSWER_CONTEXT_FOR_CHART_CODE_GEN]}" + ("..." if len(final_answer_text) > MAX_ANSWER_CONTEXT_FOR_CHART_CODE_GEN else "") + "\n\n"
        "SCRIPT REQUIREMENTS:\n"
        f"1. Chart Type: Create a '{actual_chart_type}' chart.\n"
        "2. Libraries: Use `matplotlib.pyplot` (as `plt`) ONLY. DO NOT use any other plotting library like Plotly or Seaborn. Assume `matplotlib.use('Agg')` is handled externally.\n"
        f"{data_usage_instruction}\n"
        "4. Styling (using Matplotlib):\n"
        "   - Set a clear chart title (e.g., `plt.title('My Chart Title')`).\n"
        "   - Add appropriate axis labels (e.g., `plt.xlabel('X Axis')`, `plt.ylabel('Y Axis')`).\n"
        "   - For pie charts, ensure labels or a legend are present. Use `autopct='%1.1f%%'` for percentages if applicable.\n"
        "   - If x-axis labels (e.g., from locally defined labels) are long text categories, rotate them for readability (e.g., `plt.xticks(rotation=45, ha='right')`).\n"
        "   - Use `plt.tight_layout()` before saving to prevent labels/titles from overlapping.\n"
        "5. Saving (using Matplotlib):\n"
        f"   - Save as '{CHART_IMAGE_OUTPUT_FILENAME}' using `plt.savefig('{CHART_IMAGE_OUTPUT_FILENAME}', bbox_inches='tight', dpi=150)`. Do NOT use `plt.show()`.\n"
        "6. Robustness (General, applies even if synthesizing data): Implement checks for data validity for the *data you are attempting to plot*. E.g., if plotting lists `my_labels` and `my_values` for a bar chart, check `if my_labels and my_values and len(my_labels) == len(my_values):` before plotting. Otherwise, print an informative error message to stdout like `print('Error: Data for chart is invalid or missing.')` and avoid crashing.\n"
        "7. Output: Provide ONLY the raw Python code for the script. No explanations, no comments outside of code, no markdown fences."
    )

    if not llm_model:
        log_message("No LLM model provided for chart code generation.", "warning")
        return "No LLM model available for chart code generation."

    try:
        initial_code_llm_output = llm_model.invoke(generation_prompt)
    except Exception as e:
        log_message(f"LLM error during Matplotlib chart code generation: {e}", "error")
        return f"LLM error during chart code generation: {e}"

    cleaned_code_pass1 = clean_llm_code(initial_code_llm_output, is_final_pass=False)

    if len(cleaned_code_pass1) < 50 or "```" in cleaned_code_pass1 or not ("import matplotlib.pyplot as plt" in cleaned_code_pass1 or "plt." in cleaned_code_pass1):
        log_message("First pass code cleaning for Matplotlib might be insufficient, attempting stricter extraction.", "warning")
        extraction_prompt = (
            "The following text is supposed to be Python code for Matplotlib, but might have surrounding text or markdown. "
            "Extract ONLY the raw Python code. Remove all explanations, comments outside code, and markdown.\n\n"
            "Text:\n" + initial_code_llm_output
        )
        try:
            final_pure_code_str = llm_model.invoke(extraction_prompt)
        except Exception as e:
            log_message(f"LLM failed during Matplotlib code cleaning. Falling back. Error: {e}", "error")
            final_pure_code_str = cleaned_code_pass1
    else:
        final_pure_code_str = cleaned_code_pass1

    return clean_llm_code(final_pure_code_str, is_final_pass=True)


def fix_chart_code_llm(
    original_code: str,
    error_message: str,
    user_query: str,
    chart_type: str,
    data_vars_info_str: str,
    json_extracted_data_is_sufficient: bool,
    llm_model=None
) -> str:
    log_message(f"Attempting to fix Matplotlib chart code. Error: {error_message[:150]}... JSON sufficient: {json_extracted_data_is_sufficient}")

    data_handling_advice = ""
    if not json_extracted_data_is_sufficient:
        data_handling_advice = (
            "REMEMBER: The original attempt might have failed because structured JSON data was NOT available. "
            "If the error indicates missing or empty data (like `labels_data`, `values_data`), the corrected code "
            "MUST synthesize its own data using Matplotlib from the user query, EDA, and textual answer context, and plot that synthesized data. "
            "It should NOT rely on the global `labels_data`, `values_data` etc. being populated if they were the source of the problem."
        )
    else:
        data_handling_advice = (
            "If the error is due to issues with `labels_data`, `values_data`, etc., ensure the code correctly "
            "handles potentially empty lists or mismatched lengths from these global variables using Matplotlib."
        )

    fix_prompt = (
        f"The following Python code, intended to generate a '{chart_type}' chart using Matplotlib for the user query \"{user_query}\", failed with an error.\n"
        f"Error Message:\n```text\n{error_message}\n```\n\n"
        f"Original Failing Code:\n```python\n{original_code}\n```\n\n"
        f"The script has access to these pre-populated global variables (which might be empty if JSON extraction failed, as indicated by `json_extracted_data_is_sufficient` being {json_extracted_data_is_sufficient}):\n{data_vars_info_str}\n\n"
        f"{data_handling_advice}\n\n"
        "Your task is to FIX the Python code. Pay close attention to the error message and the provided data variable information. Common issues include:\n"
        "- Incorrect use of variables or reliance on empty global data variables when data synthesis was required.\n"
        "- Mismatched data lengths or empty data that is not handled robustly.\n"
        "- Plotting library API misuse. The code MUST use `matplotlib.pyplot` (imported as `plt`) ONLY. Correct any usage of other libraries like Plotly or Seaborn.\n"
        "- Missing imports (though `matplotlib.pyplot as plt` and `pandas as pd` are usually available).\n"
        "- Syntax errors.\n"
        f"Ensure the fixed code still saves the chart to '{CHART_IMAGE_OUTPUT_FILENAME}' using `plt.savefig('{CHART_IMAGE_OUTPUT_FILENAME}', bbox_inches='tight', dpi=150)`. Do NOT use `plt.show()`.\n"
        "Adhere to robustness: if data is insufficient (either from globals or synthesized), print an informative message to stdout and avoid crashing (e.g., by drawing an empty chart with a 'No Data' title or just printing).\n"
        "Provide ONLY the corrected, complete Python code. No explanations, no markdown."
    )

    if not llm_model:
        log_message("No LLM model provided for chart code fixing.", "warning")
        return original_code

    try:
        fixed_code_llm_output = llm_model.invoke(fix_prompt)
    except Exception as e:
        log_message(f"LLM error during Matplotlib chart code fixing: {e}", "error")
        return original_code # Return original on LLM error to avoid breaking further

    return clean_llm_code(fixed_code_llm_output, is_final_pass=True)