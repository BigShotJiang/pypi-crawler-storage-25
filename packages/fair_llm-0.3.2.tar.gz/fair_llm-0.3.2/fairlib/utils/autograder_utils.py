# fairlib.utils.autograder_utils.py
"""
Shared utilities for the multi-agent autograder framework.

This module contains shared, reusable components for both the essay and
programming autograders. Centralizing common logic keeps the overall framework
modular, maintainable, and easier to extend, and ensures that improvements to
core functionality benefit all tools that use them.

Components:

- RAG knowledge base setup: a function to create and populate a vector store
  from course materials, used for context-aware grading.
- Pydantic schemas: data models (GradingCriterion, FinalGrade) that provide a
  standardized, structured format for grading output.
- Agent factory: a helper function (create_agent) that simplifies agent
  instantiation by encapsulating their standard setup.
- Reporting: a function (format_report) that turns the final structured JSON
  grade into a human-readable text report.
"""

from __future__ import annotations

import json
import logging
from typing import List, Optional, Dict

from pydantic import BaseModel, Field, ValidationError

# Framework imports
from fairlib.core.types import Document, FinalGrade, GradingCriterion
from fairlib.utils.document_processor import DocumentProcessor

from fairlib import (
    settings,
    SimpleAgent,
    ReActPlanner,
    ToolRegistry,
    ToolExecutor,
    SentenceTransformerEmbedder,
    ChromaDBVectorStore,
    LongTermMemory,
    SimpleRetriever,
    WorkingMemory,
)

# Chroma is optional; setup_knowledge_base will error if missing.

try:
    import chromadb
    _CHROMA_AVAILABLE = True
except Exception:
    chromadb = None
    _CHROMA_AVAILABLE = False

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------------------
# RAG Knowledge Base Setup
# ------------------------------------------------------------------------------

def setup_knowledge_base(materials_path: str) -> Optional[LongTermMemory]:
    """
    Creates and populates a RAG knowledge base from course materials.
    This enables agents to perform fact-checking against course-specific context.
    This method uses the ChromaDB vector store defined in vector_store.py
    """
    if not _CHROMA_AVAILABLE or chromadb is None:
        logger.error("Cannot set up knowledge base because `chromadb` is not installed.")
        return None

    logger.info("Setting up course knowledge base from: %s", materials_path)
    try:
        # 1) Parse + chunk with DocumentProcessor
        dp = DocumentProcessor({"files_directory": materials_path})
        docs: List[Document] = dp.load_documents_from_folder(materials_path)
        if not docs:
            logger.warning("No course materials found to build knowledge base.")
            return None

        # 2) Embedder
        embedder = SentenceTransformerEmbedder()

        # 3) Chroma vector store (in-memory client by default)
        chroma_client = chromadb.Client()
        vector_store = ChromaDBVectorStore(
            client=chroma_client,
            collection_name="course_kb",
            embedder=embedder
        )

        # 4) Ingest Documents into Chroma
        texts = [d.page_content for d in docs]
        metadatas = [d.metadata for d in docs] if docs and hasattr(docs[0], "metadata") else None
        vector_store.add_documents(texts, metadatas=metadatas)

        # 5) Wrap in LongTermMemory
        long_term_memory = LongTermMemory(vector_store)
        logger.info("✅ Knowledge base created successfully with %d chunks.", len(docs))
        return long_term_memory

    except Exception as e:
        logger.error(f"Failed to set up knowledge base: {e}", exc_info=True)
        return None


# ------------------------------------------------------------------------------
# Pydantic Schemas for Standardized Grading
# ------------------------------------------------------------------------------
# Note: GradingCriterion and FinalGrade are now imported from fairlib.core.types


# ------------------------------------------------------------------------------
# Agent Factory
# ------------------------------------------------------------------------------

def create_agent(llm, role_description, tools=None):
    """
    Helper factory to simplify agent creation.
    Encapsulates the standard setup for a SimpleAgent, ensuring consistency.
    """
    tool_registry = ToolRegistry()
    if tools:
        for tool in tools:
            tool_registry.register_tool(tool)

    planner = ReActPlanner(llm, tool_registry)
    executor = ToolExecutor(tool_registry) if tools else None
    memory = WorkingMemory()

    agent = SimpleAgent(llm, planner, executor, memory)
    agent.role_description = role_description
    return agent


# ------------------------------------------------------------------------------
# Reporting Utility
# ------------------------------------------------------------------------------

def format_report(grade_json_str: str, filename: str) -> str:
    """Formats the final JSON grade into a human-readable report."""
    try:
        raw_data = json.loads(grade_json_str)

        if "error" in raw_data:
            return f"GRADE REPORT FOR: {filename}\n\n[ERROR]\n{raw_data['error']}"

        data: FinalGrade = FinalGrade.model_validate_json(grade_json_str)

        report_lines = [f"GRADE REPORT FOR: {filename}\n", "=" * 40]

        total_max_score = sum(item.max_score for item in data.graded_criteria)
        final_score = data.final_score

        report_lines.append(f"FINAL SCORE: {final_score} / {total_max_score}\n")
        report_lines.append("**Overall Feedback:**")
        report_lines.append(data.overall_feedback)
        report_lines.append("\n**Rubric Breakdown:**")

        for item in data.graded_criteria:
            report_lines.append(f"- {item.criterion} ({item.score}/{item.max_score}): {item.justification.strip()}")

        return "\n".join(report_lines)

    except ValidationError as e:
        logger.error(
            f"Could not validate the final JSON evaluation against schema for {filename}. "
            f"Error: {e}. Raw output:\n{grade_json_str}"
        )
        return (
            f"GRADE REPORT FOR: {filename}\n\n[ERROR]\n"
            f"Could not validate the final AI evaluation against the expected format. Details: {e}\n\n"
            f"Raw Output:\n{grade_json_str}"
        )
    except (json.JSONDecodeError, TypeError) as e:
        logger.error(
            f"Could not parse the final JSON evaluation for {filename}. Error: {e}. Raw output:\n{grade_json_str}"
        )
        return (
            f"GRADE REPORT FOR: {filename}\n\n[ERROR]\n"
            f"Could not parse the final AI evaluation. Details: {e}\n\n"
            f"Raw Output:\n{grade_json_str}"
        )


# ------------------------------------------------------------------------------
# Grade Aggregator
# ------------------------------------------------------------------------------

class GradeAggregator:
    """A utility class for aggregating multiple grades using various statistical methods."""
    
    @staticmethod
    def aggregate(grades: List[FinalGrade], method: str = "median", consistency_threshold: float = 0.7) -> FinalGrade:
        """
        Aggregate multiple grades using the specified method.
        
        Args:
            grades: List of FinalGrade objects to aggregate
            method: Aggregation method ("median", "mean", "trimmed_mean", "robust_median")
            consistency_threshold: Threshold for consistency warnings (0.0 to 1.0)
            
        Returns:
            FinalGrade: Aggregated grade
        """
        if not grades:
            raise ValueError("No grades provided for aggregation")
            
        if method not in ["median", "mean", "trimmed_mean", "robust_median"]:
            raise ValueError(f"Unsupported aggregation method: {method}")
            
        # Get all unique criteria
        all_criteria = set()
        for grade in grades:
            for criterion in grade.graded_criteria:
                all_criteria.add(criterion.criterion)
        
        aggregated_criteria = []
        consistency_warnings = []
        
        for criterion_name in all_criteria:
            # Collect scores for this criterion
            scores = []
            max_scores = []
            justifications = []
            
            for grade in grades:
                for criterion in grade.graded_criteria:
                    if criterion.criterion == criterion_name:
                        scores.append(criterion.score)
                        max_scores.append(criterion.max_score)
                        justifications.append(criterion.justification)
                        break
            
            if not scores:
                continue
                
            # Calculate aggregated score
            if method == "median":
                aggregated_score = GradeAggregator._calculate_median(scores)
            elif method == "mean":
                aggregated_score = round(GradeAggregator._calculate_mean(scores))
            elif method == "trimmed_mean":
                aggregated_score = round(GradeAggregator._calculate_trimmed_mean(scores))
            elif method == "robust_median":
                aggregated_score = GradeAggregator._calculate_robust_median(scores)
            
            # Use the most common max_score
            max_score = max(set(max_scores), key=max_scores.count)
            
            # Check consistency
            if len(scores) > 1:
                consistency = GradeAggregator._calculate_consistency(scores)
                if consistency < consistency_threshold:
                    consistency_warnings.append(f"Low consistency for '{criterion_name}' (consistency: {consistency:.2f})")
            
            # Create aggregated criterion
            aggregated_criterion = GradingCriterion(
                criterion=criterion_name,
                score=aggregated_score,
                max_score=max_score,
                justification=f"Aggregated from {len(scores)} evaluations using {method} method."
            )
            aggregated_criteria.append(aggregated_criterion)
        
        # Calculate final score
        final_score = sum(criterion.score for criterion in aggregated_criteria)
        
        # Create overall feedback
        feedback_parts = []
        if consistency_warnings:
            feedback_parts.append("CONSISTENCY WARNINGS:")
            feedback_parts.extend(consistency_warnings)
            feedback_parts.append("")
        
        feedback_parts.append(f"Aggregated grade from {len(grades)} evaluations using {method} method.")
        
        overall_feedback = "\n".join(feedback_parts)
        
        return FinalGrade(
            graded_criteria=aggregated_criteria,
            overall_feedback=overall_feedback,
            final_score=final_score
        )
    
    @staticmethod
    def aggregate_from_json(json_list: List[str], method: str = "median", consistency_threshold: float = 0.7) -> FinalGrade:
        """
        Aggregate grades from JSON strings.
        
        Args:
            json_list: List of JSON strings representing FinalGrade objects
            method: Aggregation method
            consistency_threshold: Threshold for consistency warnings
            
        Returns:
            FinalGrade: Aggregated grade
        """
        grades = []
        for json_str in json_list:
            try:
                if json_str.strip() == "invalid json" or json_str.strip().startswith('{"error":'):
                    continue
                grade = FinalGrade.model_validate_json(json_str)
                grades.append(grade)
            except Exception as e:
                logger.warning(f"Failed to parse grade JSON: {e}")
                continue
                
        if not grades:
            raise ValueError("No valid grades found in JSON list")
            
        return GradeAggregator.aggregate(grades, method, consistency_threshold)
    
    @staticmethod
    def calculate_grade_statistics(grades: List[FinalGrade]) -> Dict[str, Dict[str, float]]:
        """
        Calculate statistics for each criterion across grades.
        
        Args:
            grades: List of FinalGrade objects
            
        Returns:
            Dict: Statistics for each criterion
        """
        stats = {}
        
        # Collect all criteria
        all_criteria = set()
        for grade in grades:
            for criterion in grade.graded_criteria:
                all_criteria.add(criterion.criterion)
        
        for criterion_name in all_criteria:
            scores = []
            for grade in grades:
                for criterion in grade.graded_criteria:
                    if criterion.criterion == criterion_name:
                        scores.append(criterion.score)
                        break
            
            if scores:
                stats[criterion_name] = {
                    "mean": sum(scores) / len(scores),
                    "median": GradeAggregator._calculate_median(scores),
                    "min": min(scores),
                    "max": max(scores),
                    "count": len(scores)
                }
        
        return stats
    
    @staticmethod
    def _calculate_median(scores: List[int]) -> int:
        """Calculate median of scores."""
        sorted_scores = sorted(scores)
        n = len(sorted_scores)
        if n % 2 == 0:
            return (sorted_scores[n//2 - 1] + sorted_scores[n//2]) // 2
        else:
            return sorted_scores[n//2]
    
    @staticmethod
    def _calculate_mean(scores: List[int]) -> float:
        """Calculate mean of scores."""
        return sum(scores) / len(scores)
    
    @staticmethod
    def _calculate_trimmed_mean(scores: List[int], trim_percent: float = 0.2) -> float:
        """Calculate trimmed mean of scores."""
        if len(scores) <= 2:
            return GradeAggregator._calculate_mean(scores)
            
        sorted_scores = sorted(scores)
        n = len(sorted_scores)
        trim_count = int(n * trim_percent)
        
        if trim_count == 0:
            return GradeAggregator._calculate_mean(scores)
            
        trimmed_scores = sorted_scores[trim_count:-trim_count]
        return sum(trimmed_scores) / len(trimmed_scores)
    
    @staticmethod
    def _calculate_robust_median(scores: List[int]) -> int:
        """Calculate robust median by removing outliers."""
        if len(scores) <= 2:
            return GradeAggregator._calculate_median(scores)
            
        # Simple outlier detection using IQR
        sorted_scores = sorted(scores)
        n = len(sorted_scores)
        
        q1_idx = n // 4
        q3_idx = 3 * n // 4
        
        q1 = sorted_scores[q1_idx]
        q3 = sorted_scores[q3_idx]
        iqr = q3 - q1
        
        # Remove outliers
        filtered_scores = []
        for score in scores:
            if q1 - 1.5 * iqr <= score <= q3 + 1.5 * iqr:
                filtered_scores.append(score)
        
        if not filtered_scores:
            return GradeAggregator._calculate_median(scores)
            
        return GradeAggregator._calculate_median(filtered_scores)
    
    @staticmethod
    def _calculate_consistency(scores: List[int]) -> float:
        """Calculate consistency score (1.0 = perfect consistency, 0.0 = no consistency)."""
        if len(scores) <= 1:
            return 1.0
            
        mean_score = sum(scores) / len(scores)
        variance = sum((score - mean_score) ** 2 for score in scores) / len(scores)
        std_dev = variance ** 0.5
        
        # Normalize consistency (higher std_dev = lower consistency)
        max_possible_std = max(scores) - min(scores) if max(scores) != min(scores) else 1
        consistency = max(0.0, 1.0 - (std_dev / max_possible_std))
        
        return consistency


# ------------------------------------------------------------------------------
# Aggregation and Formatting
# ------------------------------------------------------------------------------

def aggregate_and_format_report(json_list: List[str], filename: str, method: str = "median", consistency_threshold: float = 0.7) -> str:
    """
    Aggregate grades from JSON list and format as a report.
    
    Args:
        json_list: List of JSON strings representing FinalGrade objects
        filename: Name of the file being graded
        method: Aggregation method
        consistency_threshold: Threshold for consistency warnings
        
    Returns:
        str: Formatted report
    """
    try:
        aggregated_grade = GradeAggregator.aggregate_from_json(json_list, method, consistency_threshold)
        return format_report(aggregated_grade.model_dump_json(), filename)
    except Exception as e:
        logger.error(f"Failed to aggregate grades for {filename}: {e}")
        return f"GRADE REPORT FOR: {filename}\n\n[ERROR]\nFailed to aggregate grades: {e}"


# ------------------------------------------------------------------------------
# Determinism Utilities
# ------------------------------------------------------------------------------

def set_global_seed(seed: Optional[int] = None):
    """
    Set global random seed for reproducibility.
    
    Args:
        seed: Random seed to use. If None, no seed is set.
    """
    import random
    import numpy as np
    
    if seed is not None:
        random.seed(seed)
        np.random.seed(seed)
        
        # Try to set PyTorch seed if available
        try:
            import torch
            torch.manual_seed(seed)
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(seed)
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False
        except ImportError:
            pass


def configure_llm_deterministic(llm, temperature: float = 0.0, top_p: float = 1.0, seed: Optional[int] = None):
    """
    Configure an LLM for deterministic behavior.
    
    Args:
        llm: LLM instance to configure
        temperature: Temperature setting (0.0 for deterministic)
        top_p: Top-p setting (1.0 for deterministic)
        seed: Random seed
    """
    # Set basic parameters
    llm.temperature = temperature
    llm.top_p = top_p
    if seed is not None:
        llm.seed = seed
    
    # Try to use configuration method if available
    if hasattr(llm, 'set_sampling_params'):
        llm.set_sampling_params(temperature=temperature, top_p=top_p, seed=seed)


# ------------------------------------------------------------------------------
# Consistent Grading
# ------------------------------------------------------------------------------

async def run_consistent_grading(
    grading_function,
    submission: str,
    rubric: str,
    num_runs: int = 3,
    aggregation_method: str = "robust_median",
    consistency_threshold: float = 0.7
) -> FinalGrade:
    """
    Run grading multiple times and aggregate results for consistency.
    
    Args:
        grading_function: Async function that takes (submission, rubric) and returns JSON string
        submission: Submission to grade
        rubric: Grading rubric
        num_runs: Number of times to run grading
        aggregation_method: Method to aggregate results
        consistency_threshold: Threshold for consistency warnings
        
    Returns:
        FinalGrade: Aggregated grade
    """
    import asyncio
    
    # Set deterministic seed for reproducibility
    set_global_seed(42)
    
    results = []
    for i in range(num_runs):
        try:
            result = await grading_function(submission, rubric)
            if result and result.strip():
                results.append(result)
        except Exception as e:
            logger.warning(f"Grading attempt {i+1} failed: {e}")
            continue
    
    if not results:
        # Return fallback grade if all attempts failed
        return FinalGrade(
            graded_criteria=[],
            overall_feedback="All grading attempts failed",
            final_score=0
        )
    
    try:
        # Aggregate results
        aggregated_grade = GradeAggregator.aggregate_from_json(
            results, 
            method=aggregation_method, 
            consistency_threshold=consistency_threshold
        )
        return aggregated_grade
    except Exception as e:
        logger.error(f"Failed to aggregate grading results: {e}")
        # Return fallback grade
        return FinalGrade(
            graded_criteria=[],
            overall_feedback=f"Failed to aggregate results: {e}",
            final_score=0
        )