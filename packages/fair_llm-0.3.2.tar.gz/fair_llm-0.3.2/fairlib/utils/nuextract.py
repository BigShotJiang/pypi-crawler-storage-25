# fairlib.utils/nuextract.py

import io
import json
import os
import zipfile
from typing import Iterable, List, Optional, Tuple, Union

# Import framework components
from fairlib.core.prompts import PromptBuilder, RoleDefinition

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

# Import document processor for file loading
from fairlib.utils.document_processor import DocumentProcessor

# Optional dependencies for OCR (kept for nuextract-specific OCR needs if any)
try:
    from PIL import Image
except Exception:  # pragma: no cover
    Image = None  # type: ignore

try:
    import pytesseract  # type: ignore
except Exception:  # pragma: no cover
    pytesseract = None  # type: ignore


_MODEL = None
_TOKENIZER = None


def _ensure_loaded(model_name: str = "numind/NuExtract-large") -> None:
    global _MODEL, _TOKENIZER
    if _MODEL is not None and _TOKENIZER is not None:
        return
    _TOKENIZER = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
    torch_dtype = torch.bfloat16 if torch.cuda.is_available() else None
    _MODEL = AutoModelForCausalLM.from_pretrained(
        model_name, trust_remote_code=True, torch_dtype=torch_dtype
    )
    _MODEL.eval()
    if torch.cuda.is_available():
        _MODEL.to("cuda")


def _build_prompt(
    text: str,
    schema: Union[str, dict],
    examples: Optional[Iterable[Union[str, dict]]] = None,
    user_context: Optional[str] = None,
) -> str:
    """
    Build a prompt using the framework's PromptBuilder for structured data extraction.
    """
    # Build the system prompt using PromptBuilder
    prompt_builder = PromptBuilder()
    
    # Add system instruction
    prompt_builder.role_definition = RoleDefinition(
        "You are a structured data extraction assistant. Extract data from text according to the provided schema."
    )
    
    # Build the system prompt
    system_prompt = prompt_builder.build_system_prompt_string()
    
    # Build the user message manually
    user_parts = []
    
    # Add template/schema
    if isinstance(schema, dict):
        schema_str = json.dumps(schema, indent=4)
    else:
        schema_str = json.dumps(json.loads(schema), indent=4)
    
    user_parts.append(f"### Template:\n{schema_str}\n")
    
    # Add examples if provided
    if examples:
        for ex in examples:
            if isinstance(ex, dict):
                ex_str = json.dumps(ex, indent=4)
            else:
                ex_str = json.dumps(json.loads(ex), indent=4)
            if ex_str:
                user_parts.append(f"### Example:\n{ex_str}\n")
    
    # Add user context if provided
    if user_context:
        user_parts.append(f"### UserContext:\n{user_context.strip()}\n")
    
    # Add the text to extract from
    user_parts.append(f"### Text:\n{text}\n<|output|>\n")
    
    user_message = "\n".join(user_parts)
    
    # Combine system prompt and user message
    return f"{system_prompt}\n\n{user_message}"


def extract(
    text: str,
    schema: Union[str, dict],
    examples: Optional[Iterable[Union[str, dict]]] = None,
    *,
    model_name: str = "numind/NuExtract-large",
    max_input_tokens: int = 4000,
    max_new_tokens: int = 512,
    user_context: Optional[str] = None,
) -> Union[dict, str]:
    """
    Run NuExtract and return parsed JSON if possible, else the raw string.
    Keep dependencies minimal (transformers + torch).
    """
    _ensure_loaded(model_name)
    prompt = _build_prompt(text, schema, examples, user_context=user_context)
    inputs = _TOKENIZER(
        prompt, return_tensors="pt", truncation=True, max_length=max_input_tokens
    )
    if torch.cuda.is_available():
        inputs = {k: v.to("cuda") for k, v in inputs.items()}

    with torch.no_grad():
        out_ids = _MODEL.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            eos_token_id=_TOKENIZER.eos_token_id,
            pad_token_id=_TOKENIZER.eos_token_id,
        )[0]

    decoded = _TOKENIZER.decode(out_ids, skip_special_tokens=True)
    # Extract the section between <|output|> and optional <|end-output|>
    if "<|output|>" in decoded:
        decoded = decoded.split("<|output|>", 1)[1]
    if "<|end-output|>" in decoded:
        decoded = decoded.split("<|end-output|>", 1)[0]
    decoded = decoded.strip()

    try:
        return json.loads(decoded)
    except Exception:
        return decoded


def read_text_from_path(file_path: str) -> Tuple[str, str]:
    """
    Read the best-effort textual representation from a file using DocumentProcessor.
    Returns (text, detected_type)
    """
    ext = os.path.splitext(file_path)[1].lower()
    file_type = ext.lstrip(".") or "text"
    
    # Use DocumentProcessor for document loading
    try:
        dp = DocumentProcessor()
        segments = dp.extract_text_with_fallback(file_path)
        
        if segments:
            # Combine all segments into a single text
            text_parts = [seg.get("text", "") for seg in segments if seg.get("text")]
            combined_text = "\n\n".join(text_parts).strip()
            
            # Determine file type from metadata if available
            if segments and segments[0].get("metadata", {}).get("type"):
                file_type = segments[0]["metadata"]["type"]
            
            return combined_text, file_type
    except Exception:
        pass
    
    # Fallback for plain text files and images
    if ext in {".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tiff", ".webp"}:
        if Image is not None and pytesseract is not None:
            try:
                with open(file_path, "rb") as f:
                    img = Image.open(io.BytesIO(f.read()))
                return pytesseract.image_to_string(img), ext.lstrip(".")
            except Exception:
                pass
        return "", ext.lstrip(".")
    
    # Plain text fallback for anything else
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read(), file_type
    except Exception:
        try:
            with open(file_path, "rb") as f:
                data = f.read()
            try:
                return data.decode("utf-8", errors="ignore"), file_type
            except Exception:
                # last ditch, latin-1
                return data.decode("latin-1", errors="ignore"), file_type
        except Exception:
            return "", file_type


def extract_from_file(
    file_path: str,
    schema: Union[str, dict],
    examples: Optional[Iterable[Union[str, dict]]] = None,
    *,
    model_name: str = "numind/NuExtract-large",
    max_input_tokens: int = 4000,
    max_new_tokens: int = 512,
    user_context: Optional[str] = None,
    ocr_fallback: bool = True,
) -> Union[dict, str]:
    """
    Read a file, convert to text, and run NuExtract using the provided schema.
    Returns parsed JSON if possible, else the raw string output.
    
    Note: DocumentProcessor handles OCR automatically when enabled, so ocr_fallback
    is primarily for backward compatibility.
    """
    text, file_type = read_text_from_path(file_path)

    # OCR fallback for images (DocumentProcessor handles OCR for documents)
    if ocr_fallback and file_type in {"png", "jpg", "jpeg", "bmp", "gif", "tiff", "webp"}:
        if not text and Image is not None and pytesseract is not None:
            try:
                with open(file_path, "rb") as f:
                    img = Image.open(io.BytesIO(f.read()))
                ocr_text = pytesseract.image_to_string(img)
                if ocr_text.strip():
                    text = ocr_text
            except Exception:
                pass

    return extract(
        text=text,
        schema=schema,
        examples=examples,
        model_name=model_name,
        max_input_tokens=max_input_tokens,
        max_new_tokens=max_new_tokens,
        user_context=user_context,
    )


def _load_schema_arg(schema_arg: str) -> Union[str, dict]:
    # If it's a path to a file, read it; else treat as JSON string
    if os.path.exists(schema_arg):
        with open(schema_arg, "r", encoding="utf-8") as f:
            content = f.read()
    else:
        content = schema_arg
    try:
        return json.loads(content)
    except Exception:
        return content


def _load_examples_args(example_args: Optional[List[str]]) -> List[Union[str, dict]]:
    if not example_args:
        return []
    results: List[Union[str, dict]] = []
    for item in example_args:
        if os.path.exists(item):
            if item.lower().endswith(".jsonl"):
                with open(item, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            results.append(json.loads(line))
                        except Exception:
                            results.append(line)
            else:
                with open(item, "r", encoding="utf-8") as f:
                    content = f.read()
                try:
                    results.append(json.loads(content))
                except Exception:
                    results.append(content)
        else:
            try:
                results.append(json.loads(item))
            except Exception:
                results.append(item)
    return results


# CLI functionality removed from util module as per framework standards
# If CLI functionality is needed, it should be implemented in a separate script


