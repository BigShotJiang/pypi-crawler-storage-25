# fairlib.utils/speech_util.py

import torch
from transformers import AutoProcessor, AutoModelForSpeechSeq2Seq
import sounddevice as sd
from scipy.io.wavfile import write
import pyttsx3
import tempfile
import numpy as np
from typing import List

class SpeechUtil:
    """
    An enhanced utility class for handling speech-to-text and text-to-speech functionality.
    """
    def __init__(self, model_name: str = "openai/whisper-large-v3"):
        """
        Initializes the SpeechUtil class.

        Args:
            model_name (str): The name of the Whisper model to use.
        """
        self.device = "cuda:0" if torch.cuda.is_available() else "cpu"
        self.torch_dtype = torch.float16 if torch.cuda.is_available() else torch.float32

        self.model = AutoModelForSpeechSeq2Seq.from_pretrained(
            model_name, torch_dtype=self.torch_dtype, low_cpu_mem_usage=True, use_safetensors=True
        )
        self.model.to(self.device)

        self.processor = AutoProcessor.from_pretrained(model_name)
        
        self.tts_engine = pyttsx3.init()

    def record_and_transcribe(self, duration: int = 5, fs: int = 16000) -> str:
        """
        Records audio from the microphone and transcribes it into text.

        Args:
            duration (int): The duration of the recording in seconds.
            fs (int): The sampling frequency.

        Returns:
            str: The transcribed text.
        """
        print("Recording...")
        try:
            recording = sd.rec(int(duration * fs), samplerate=fs, channels=1, dtype='float32')
            sd.wait()
            print("Recording finished.")
        except KeyboardInterrupt:
            print("\nRecording stopped.")
            return ""

        with tempfile.NamedTemporaryFile(suffix=".wav", delete=True) as temp_file:
            write(temp_file.name, fs, recording)
            
            # The whisper model expects a file path.
            inputs = self.processor(temp_file.name, return_tensors="pt", sampling_rate=16000)

        input_features = inputs.input_features.to(self.device, dtype=self.torch_dtype)

        generated_ids = self.model.generate(inputs=input_features)
        
        transcription = self.processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
        return transcription.strip()

    def get_available_voices(self) -> List[pyttsx3.voice.Voice]:
        """
        Gets a list of available voices for text-to-speech.

        Returns:
            List[pyttsx3.voice.Voice]: A list of available voice objects.
        """
        return self.tts_engine.getProperty('voices')

    def set_voice(self, voice_id: str) -> None:
        """
        Sets the voice for text-to-speech.

        Args:
            voice_id (str): The ID of the voice to use.
        """
        self.tts_engine.setProperty('voice', voice_id)

    def set_speech_rate(self, rate: int) -> None:
        """
        Sets the speech rate for text-to-speech.

        Args:
            rate (int): The desired speech rate in words per minute.
        """
        self.tts_engine.setProperty('rate', rate)

    def speak(self, text: str) -> None:
        """
        Converts the given text to speech.

        Args:
            text (str): The text to be spoken.
        """
        self.tts_engine.say(text)
        self.tts_engine.runAndWait()