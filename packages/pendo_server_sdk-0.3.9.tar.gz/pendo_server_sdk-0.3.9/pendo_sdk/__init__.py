"""
Pendo Agent Observability SDK

A lightweight wrapper around OpenTelemetry that lets customers instrument
their AI agents with a single init() call. The SDK wraps OTel's TracerProvider
and exports completed spans via OTLP to Pendo's ingestion pipeline.

Usage:
    import pendo_sdk

    pendo_sdk.init(api_key="your-key", project_id="my-agent")
"""

from .core import init, shutdown, flush, get_tracer
from .decorators import trace_llm, trace_tool
from .exporter import PendoSpanExporter
from .schema import (
    AgentEvent,
    ContextItem,
    ContextType,
    ConversationOutcome,
    EventBatch,
    EventProps,
    EventType,
    ReactionType,
    SpanStatusCode,
    SpanType,
    ToolStatus,
)

__all__ = [
    "init",
    "shutdown",
    "flush",
    "get_tracer",
    "trace_llm",
    "trace_tool",
    "PendoSpanExporter",
    "AgentEvent",
    "ContextItem",
    "ContextType",
    "ConversationOutcome",
    "EventBatch",
    "EventProps",
    "EventType",
    "ReactionType",
    "SpanStatusCode",
    "SpanType",
    "ToolStatus",
]

__version__ = "0.3.9"
