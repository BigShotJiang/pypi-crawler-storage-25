"""
Tests for the httpcore compatibility alias.

When httpcorexyz is imported it registers itself under the ``httpcore`` name in
``sys.modules``, so that third-party libraries which do ``import httpcore`` or
check ``isinstance(obj, httpcore.Response)`` continue to work transparently.
"""

import sys

import httpcorexyz


def test_httpcore_alias_registered_in_sys_modules():
    assert "httpcore" in sys.modules


def test_import_httpcore_returns_httpcorexyz():
    import httpcore

    assert httpcore.Response is httpcorexyz.Response  # type: ignore[comparison-overlap]


def test_httpcore_response_isinstance():
    import httpcore

    response = httpcorexyz.Response(200, headers=[], content=b"")
    assert isinstance(response, httpcore.Response)


def test_httpcore_request_isinstance():
    import httpcore

    request = httpcorexyz.Request("GET", "https://example.com")
    assert isinstance(request, httpcore.Request)


def test_httpcore_connection_pool_isinstance():
    import httpcore

    with httpcorexyz.ConnectionPool() as pool:
        assert isinstance(pool, httpcore.ConnectionPool)
