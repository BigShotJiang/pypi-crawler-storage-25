"""Tests for trailing-dot FQDN hostname normalisation (issue #1063)."""

from __future__ import annotations

import ssl
import typing

import httpcorexyz
from httpcorexyz import MockBackend, MockStream, NetworkStream, Origin


class RecordingStream(MockStream):
    """MockStream that records the server_hostname passed to start_tls()."""

    def __init__(self, buffer: list[bytes]) -> None:
        super().__init__(buffer)
        self.start_tls_hostname: str | None = None

    def start_tls(
        self,
        ssl_context: ssl.SSLContext,
        server_hostname: str | None = None,
        timeout: float | None = None,
    ) -> NetworkStream:
        self.start_tls_hostname = server_hostname
        return self


class RecordingBackend(MockBackend):
    def __init__(self, buffer: list[bytes]) -> None:
        super().__init__(buffer)
        self.stream: RecordingStream | None = None

    def connect_tcp(
        self,
        host: str,
        port: int,
        timeout: float | None = None,
        local_address: str | None = None,
        socket_options: typing.Iterable[httpcorexyz.SOCKET_OPTION] | None = None,
    ) -> NetworkStream:
        self.stream = RecordingStream(list(self._buffer))
        return self.stream


def test_sni_hostname_strips_trailing_dot():
    """server_hostname passed to start_tls() must not carry the trailing dot."""
    origin = Origin(b"https", b"myhost.internal.", 443)
    network_backend = RecordingBackend(
        [
            b"HTTP/1.1 200 OK\r\n",
            b"Content-Length: 0\r\n",
            b"\r\n",
        ]
    )
    with httpcorexyz.HTTPConnection(
        origin=origin, network_backend=network_backend
    ) as conn:
        conn.request("GET", "https://myhost.internal./")

    assert network_backend.stream is not None
    assert network_backend.stream.start_tls_hostname == "myhost.internal"


def test_origin_str_strips_trailing_dot():
    """Origin.__str__ must strip the trailing dot from FQDNs.

    'myhost.internal.' is a valid FQDN but TLS certificates use
    'myhost.internal' (without the dot). Passing the raw hostname
    to ssl_wrap_socket would cause CERTIFICATE_VERIFY_FAILED.
    """
    origin = httpcorexyz.Origin(b"https", b"myhost.internal.", 443)
    assert str(origin) == "https://myhost.internal:443"


def test_origin_str_no_trailing_dot_unchanged():
    """Normal hostnames (no trailing dot) must not be modified."""
    origin = httpcorexyz.Origin(b"https", b"example.com", 443)
    assert str(origin) == "https://example.com:443"


def test_url_host_strips_trailing_dot():
    """URL.host used for SNI should not carry the trailing dot."""
    url = httpcorexyz.URL("https://myhost.internal.:8443/")
    assert url.host == b"myhost.internal."  # raw host preserved
    # but str(origin) strips it for TLS
    assert url.port is not None
    origin = httpcorexyz.Origin(b"https", url.host, url.port)
    assert str(origin) == "https://myhost.internal:8443"
