from __future__ import annotations

import asyncio
import sys
from typing import Any, Callable, Coroutine, Dict

import uvicorn

RESP = b"a" * 2000
SLEEP = 0.01

Receive = Callable[[], Coroutine[Any, Any, Dict[str, Any]]]
Send = Callable[[Dict[str, Any]], Coroutine[Any, Any, None]]


async def read_body(receive: Receive) -> bytes:
    chunks: list[bytes] = []
    while True:
        message = await receive()
        chunk = message.get("body", b"")
        if chunk:
            chunks.append(bytes(chunk))
        if not message.get("more_body", False):
            break
    return b"".join(chunks)


async def app(scope: dict[str, Any], receive: Receive, send: Send) -> None:
    assert scope["type"] == "http"

    if scope["path"] == "/req":
        # GET latency benchmark endpoint — small fixed response after a simulated delay
        await read_body(receive)
        await asyncio.sleep(SLEEP)
        await send(
            {
                "type": "http.response.start",
                "status": 200,
                "headers": [[b"content-type", b"text/plain"]],
            }
        )
        await send({"type": "http.response.body", "body": RESP})

    elif scope["path"] == "/upload":
        # POST throughput benchmark endpoint — drain the body, echo its size
        body = await read_body(receive)
        size_bytes = str(len(body)).encode()
        await send(
            {
                "type": "http.response.start",
                "status": 200,
                "headers": [
                    [b"content-type", b"text/plain"],
                    [b"content-length", str(len(size_bytes)).encode()],
                ],
            }
        )
        await send({"type": "http.response.body", "body": size_bytes})

    else:
        await send({"type": "http.response.start", "status": 404, "headers": []})
        await send({"type": "http.response.body", "body": b""})


async def run(port_file: str | None = None) -> None:
    config = uvicorn.Config(
        app,
        port=0,
        log_level="error",
        # Keep warmed up connections alive during the test to have consistent results
        # across test runs. This avoids timing differences with connections getting
        # closed and reopened in the background.
        timeout_keep_alive=100,
    )
    config.load()
    server = uvicorn.Server(config)
    server.lifespan = config.lifespan_class(config)
    await server.startup()
    port = server.servers[0].sockets[0].getsockname()[1]
    if port_file:
        with open(port_file, "w") as f:
            f.write(str(port))
    await server.main_loop()
    await server.shutdown()


if __name__ == "__main__":
    port_file = sys.argv[1] if len(sys.argv) > 1 else None
    asyncio.run(run(port_file))
