from __future__ import annotations

import asyncio
import os
import statistics
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from typing import Any, Callable, Coroutine, Iterator, List

import aiohttp
import httpcore
import matplotlib.pyplot as plt
import pyinstrument
import urllib3
from matplotlib.axes import Axes

import httpcorexyz

PORT = 0  # set in main()
URL = ""  # set in main()
UPLOAD_URL = ""  # set in main()
REPEATS = 10
REQUESTS = 500
CONCURRENCY = 20
POOL_LIMIT = 100
PROFILE = False
UPLOAD_SIZES_MB = [1, 4, 16, 64]
UPLOAD_REQUESTS = 5  # per size; fewer because payloads are large
os.environ["HTTPCORE_PREFER_ANYIO"] = "0"


def print_latency_stats(results: List[tuple[str, List[int], int]]) -> None:
    """Print a text summary table for latency benchmarks.

    Each entry is (name, per_request_timings_ms, total_ms).
    """
    header = f"{'name':<20} {'total':>8} {'mean':>8} {'median':>8} {'p99':>8} {'min':>8} {'max':>8}"
    print()
    print(header)
    print("-" * len(header))
    for name, timings, total in results:
        s = sorted(timings)
        p99_idx = max(0, int(len(s) * 0.99) - 1)
        print(
            f"{name:<20} {total:>7}ms {statistics.mean(s):>7.1f}ms "
            f"{statistics.median(s):>7.1f}ms {s[p99_idx]:>7}ms {s[0]:>7}ms {s[-1]:>7}ms"
        )
    print()


def duration(start: float) -> int:
    return int((time.monotonic() - start) * 1000)


@contextmanager
def profile():
    if not PROFILE:
        yield
        return
    with pyinstrument.Profiler() as profiler:
        yield
    profiler.open_in_browser()


async def run_async_requests(axis: Axes) -> List[tuple[str, List[int], int]]:
    async def gather_limited_concurrency(
        coros: Iterator[Coroutine[Any, Any, Any]], concurrency: int = CONCURRENCY
    ) -> None:
        sem = asyncio.Semaphore(concurrency)

        async def coro_with_sem(coro: Coroutine[Any, Any, Any]) -> None:
            async with sem:
                await coro

        await asyncio.gather(*(coro_with_sem(c) for c in coros))

    async def httpcore_get(
        pool: httpcorexyz.AsyncConnectionPool, timings: List[int]
    ) -> None:
        start = time.monotonic()
        res = await pool.request("GET", URL)
        assert len(await res.aread()) == 2000
        assert res.status == 200, f"status_code={res.status}"
        timings.append(duration(start))

    async def aiohttp_get(session: aiohttp.ClientSession, timings: List[int]) -> None:
        start = time.monotonic()
        async with session.request("GET", URL) as res:
            assert len(await res.read()) == 2000
            assert res.status == 200, f"status={res.status}"
        timings.append(duration(start))

    async def httpcore_upstream_get(
        pool: httpcore.AsyncConnectionPool, timings: List[int]
    ) -> None:
        start = time.monotonic()
        res = await pool.request("GET", URL)
        assert len(await res.aread()) == 2000
        assert res.status == 200, f"status_code={res.status}"
        timings.append(duration(start))

    results: List[tuple[str, List[int], int]] = []

    async with httpcorexyz.AsyncConnectionPool(max_connections=POOL_LIMIT) as pool:
        # warmup
        await gather_limited_concurrency(
            (httpcore_get(pool, []) for _ in range(REQUESTS)), CONCURRENCY * 2
        )

        timings: List[int] = []
        start = time.monotonic()
        with profile():
            for _ in range(REPEATS):
                await gather_limited_concurrency(
                    (httpcore_get(pool, timings) for _ in range(REQUESTS))
                )
        total = duration(start)
        results.append(("httpcorexyz", timings, total))
        axis.plot(
            [*range(len(timings))],
            timings,
            label=f"httpcorexyz (tot={total}ms)",
        )

    connector = aiohttp.TCPConnector(limit=POOL_LIMIT)
    async with aiohttp.ClientSession(connector=connector) as session:
        # warmup
        await gather_limited_concurrency(
            (aiohttp_get(session, []) for _ in range(REQUESTS)), CONCURRENCY * 2
        )

        timings = []
        start = time.monotonic()
        for _ in range(REPEATS):
            await gather_limited_concurrency(
                (aiohttp_get(session, timings) for _ in range(REQUESTS))
            )
        total = duration(start)
        results.append(("aiohttp", timings, total))
        axis.plot([*range(len(timings))], timings, label=f"aiohttp (tot={total}ms)")

    async with httpcore.AsyncConnectionPool(
        max_connections=POOL_LIMIT
    ) as upstream_pool:
        # warmup
        await gather_limited_concurrency(
            (httpcore_upstream_get(upstream_pool, []) for _ in range(REQUESTS)),
            CONCURRENCY * 2,
        )

        timings = []
        start = time.monotonic()
        for _ in range(REPEATS):
            await gather_limited_concurrency(
                (httpcore_upstream_get(upstream_pool, timings) for _ in range(REQUESTS))
            )
        total = duration(start)
        results.append(("httpcore", timings, total))
        axis.plot([*range(len(timings))], timings, label=f"httpcore (tot={total}ms)")

    return results


def run_sync_requests(axis: Axes) -> List[tuple[str, List[int], int]]:
    def run_in_executor(
        fns: Iterator[Callable[[], None]], executor: ThreadPoolExecutor
    ) -> None:
        futures = [executor.submit(fn) for fn in fns]
        for future in futures:
            future.result()

    def httpcore_get(pool: httpcorexyz.ConnectionPool, timings: List[int]) -> None:
        start = time.monotonic()
        res = pool.request("GET", URL)
        assert len(res.read()) == 2000
        assert res.status == 200, f"status_code={res.status}"
        timings.append(duration(start))

    def urllib3_get(pool: urllib3.HTTPConnectionPool, timings: List[int]) -> None:
        start = time.monotonic()
        res = pool.request("GET", "/req")
        assert len(res.data) == 2000
        assert res.status == 200, f"status={res.status}"
        timings.append(duration(start))

    def httpcore_upstream_get(
        pool: httpcore.ConnectionPool, timings: List[int]
    ) -> None:
        start = time.monotonic()
        res = pool.request("GET", URL)
        assert len(res.read()) == 2000
        assert res.status == 200, f"status_code={res.status}"
        timings.append(duration(start))

    results: List[tuple[str, List[int], int]] = []

    with httpcorexyz.ConnectionPool(max_connections=POOL_LIMIT) as pool:
        # warmup
        with ThreadPoolExecutor(max_workers=CONCURRENCY * 2) as exec:
            run_in_executor(
                (lambda: httpcore_get(pool, []) for _ in range(REQUESTS)),
                exec,
            )

        timings: List[int] = []
        exec = ThreadPoolExecutor(max_workers=CONCURRENCY)
        start = time.monotonic()
        with profile():
            for _ in range(REPEATS):
                run_in_executor(
                    (lambda: httpcore_get(pool, timings) for _ in range(REQUESTS)), exec
                )
        exec.shutdown(wait=True)
        total = duration(start)
        results.append(("httpcorexyz", timings, total))
        axis.plot(
            [*range(len(timings))],
            timings,
            label=f"httpcorexyz (tot={total}ms)",
        )

    with urllib3.HTTPConnectionPool(
        "localhost", PORT, maxsize=POOL_LIMIT
    ) as urllib3_pool:
        # warmup
        with ThreadPoolExecutor(max_workers=CONCURRENCY * 2) as exec:
            run_in_executor(
                (lambda: urllib3_get(urllib3_pool, []) for _ in range(REQUESTS)),
                exec,
            )

        timings = []
        exec = ThreadPoolExecutor(max_workers=CONCURRENCY)
        start = time.monotonic()
        for _ in range(REPEATS):
            run_in_executor(
                (lambda: urllib3_get(urllib3_pool, timings) for _ in range(REQUESTS)),
                exec,
            )
        exec.shutdown(wait=True)
        total = duration(start)
        results.append(("urllib3", timings, total))
        axis.plot([*range(len(timings))], timings, label=f"urllib3 (tot={total}ms)")

    with httpcore.ConnectionPool(max_connections=POOL_LIMIT) as upstream_pool:
        # warmup
        with ThreadPoolExecutor(max_workers=CONCURRENCY * 2) as exec:
            run_in_executor(
                (
                    lambda: httpcore_upstream_get(upstream_pool, [])
                    for _ in range(REQUESTS)
                ),
                exec,
            )

        timings = []
        exec = ThreadPoolExecutor(max_workers=CONCURRENCY)
        start = time.monotonic()
        for _ in range(REPEATS):
            run_in_executor(
                (
                    lambda: httpcore_upstream_get(upstream_pool, timings)
                    for _ in range(REQUESTS)
                ),
                exec,
            )
        exec.shutdown(wait=True)
        total = duration(start)
        results.append(("httpcore", timings, total))
        axis.plot([*range(len(timings))], timings, label=f"httpcore (tot={total}ms)")

    return results


def run_sync_post_benchmark(axis: Axes) -> None:
    """Measure upload throughput (MB/s) for POST requests at increasing payload sizes."""
    labels = [f"{s} MB" for s in UPLOAD_SIZES_MB]
    httpcore_mbps: List[float] = []
    urllib3_mbps: List[float] = []
    httpcore_upstream_mbps: List[float] = []

    for size_mb in UPLOAD_SIZES_MB:
        payload = b"x" * (size_mb * 1024 * 1024)

        with httpcorexyz.ConnectionPool(max_connections=1) as pool:
            pool.request("POST", UPLOAD_URL, content=payload)  # warmup
            start = time.monotonic()
            for _ in range(UPLOAD_REQUESTS):
                res = pool.request("POST", UPLOAD_URL, content=payload)
                assert res.status == 200, f"status={res.status}"
            elapsed = time.monotonic() - start
        httpcore_mbps.append(size_mb * UPLOAD_REQUESTS / elapsed)

        with urllib3.HTTPConnectionPool("localhost", PORT, maxsize=1) as u3pool:
            u3pool.request("POST", "/upload", body=payload)  # warmup
            start = time.monotonic()
            for _ in range(UPLOAD_REQUESTS):
                u3res = u3pool.request("POST", "/upload", body=payload)
                assert u3res.status == 200, f"status={u3res.status}"
            elapsed = time.monotonic() - start
        urllib3_mbps.append(size_mb * UPLOAD_REQUESTS / elapsed)

        with httpcore.ConnectionPool(max_connections=1) as pool:
            pool.request("POST", UPLOAD_URL, content=payload)  # warmup
            start = time.monotonic()
            for _ in range(UPLOAD_REQUESTS):
                hcres = pool.request("POST", UPLOAD_URL, content=payload)
                assert hcres.status == 200, f"status={hcres.status}"
            elapsed = time.monotonic() - start
        httpcore_upstream_mbps.append(size_mb * UPLOAD_REQUESTS / elapsed)

        print(
            f"  {size_mb:3d} MB  httpcorexyz={httpcore_mbps[-1]:.0f} MB/s"
            f"  urllib3={urllib3_mbps[-1]:.0f} MB/s"
            f"  httpcore={httpcore_upstream_mbps[-1]:.0f} MB/s"
        )

    x = list(range(len(UPLOAD_SIZES_MB)))
    width = 0.25
    axis.bar([i - width for i in x], httpcore_mbps, width, label="httpcorexyz")
    axis.bar(x, urllib3_mbps, width, label="urllib3")
    axis.bar([i + width for i in x], httpcore_upstream_mbps, width, label="httpcore")
    axis.set_xticks(x)
    axis.set_xticklabels(labels)
    axis.set_ylabel("Throughput (MB/s)")
    axis.set_title("POST upload throughput (sync, loopback)")
    axis.legend()


async def run_async_post_benchmark(axis: Axes) -> None:
    """Measure upload throughput (MB/s) for async POST requests at increasing payload sizes."""
    labels = [f"{s} MB" for s in UPLOAD_SIZES_MB]
    httpcore_mbps: List[float] = []
    aiohttp_mbps: List[float] = []
    httpcore_upstream_mbps: List[float] = []

    for size_mb in UPLOAD_SIZES_MB:
        payload = b"x" * (size_mb * 1024 * 1024)

        async with httpcorexyz.AsyncConnectionPool(max_connections=1) as pool:
            await pool.request("POST", UPLOAD_URL, content=payload)  # warmup
            start = time.monotonic()
            for _ in range(UPLOAD_REQUESTS):
                res = await pool.request("POST", UPLOAD_URL, content=payload)
                assert res.status == 200, f"status={res.status}"
                await res.aread()
            elapsed = time.monotonic() - start
        httpcore_mbps.append(size_mb * UPLOAD_REQUESTS / elapsed)

        connector = aiohttp.TCPConnector(limit=1)
        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.post(UPLOAD_URL, data=payload) as _:
                pass  # warmup
            start = time.monotonic()
            for _ in range(UPLOAD_REQUESTS):
                async with session.post(UPLOAD_URL, data=payload) as aiores:
                    assert aiores.status == 200, f"status={aiores.status}"
                    await aiores.read()
            elapsed = time.monotonic() - start
        aiohttp_mbps.append(size_mb * UPLOAD_REQUESTS / elapsed)

        async with httpcore.AsyncConnectionPool(max_connections=1) as pool:
            await pool.request("POST", UPLOAD_URL, content=payload)  # warmup
            start = time.monotonic()
            for _ in range(UPLOAD_REQUESTS):
                hcres = await pool.request("POST", UPLOAD_URL, content=payload)
                assert hcres.status == 200, f"status={hcres.status}"
                await hcres.aread()
            elapsed = time.monotonic() - start
        httpcore_upstream_mbps.append(size_mb * UPLOAD_REQUESTS / elapsed)

        print(
            f"  {size_mb:3d} MB  httpcorexyz={httpcore_mbps[-1]:.0f} MB/s"
            f"  aiohttp={aiohttp_mbps[-1]:.0f} MB/s"
            f"  httpcore={httpcore_upstream_mbps[-1]:.0f} MB/s"
        )

    x = list(range(len(UPLOAD_SIZES_MB)))
    width = 0.25
    axis.bar([i - width for i in x], httpcore_mbps, width, label="httpcorexyz")
    axis.bar(x, aiohttp_mbps, width, label="aiohttp")
    axis.bar([i + width for i in x], httpcore_upstream_mbps, width, label="httpcore")
    axis.set_xticks(x)
    axis.set_xticklabels(labels)
    axis.set_ylabel("Throughput (MB/s)")
    axis.set_title("POST upload throughput (async, loopback)")
    axis.legend()


STREAM_CONCURRENCY_LEVELS = [1, 10, 50, 100, 200]
STREAM_REQUESTS_PER_THREAD = 50


def run_stream_sync_benchmark(axis: Axes) -> None:
    """Measure streaming lock contention: many sync threads closing PoolByteStream concurrently."""

    def stream_worker(
        pool: httpcorexyz.ConnectionPool, n: int, timings: List[int]
    ) -> None:
        for _ in range(n):
            start = time.monotonic()
            with pool.stream("GET", URL) as response:
                body = b"".join(response.iter_stream())
                assert len(body) == 2000
            timings.append(duration(start))

    def stream_worker_upstream(pool: Any, n: int, timings: List[int]) -> None:
        for _ in range(n):
            start = time.monotonic()
            with pool.stream("GET", URL) as response:
                body = b"".join(response.iter_stream())
                assert len(body) == 2000
            timings.append(duration(start))

    httpcorexyz_totals: List[int] = []
    httpcore_totals: List[int] = []
    labels: List[str] = []

    for concurrency in STREAM_CONCURRENCY_LEVELS:
        labels.append(str(concurrency))

        # httpcorexyz
        with httpcorexyz.ConnectionPool(max_connections=POOL_LIMIT) as pool:
            # warmup
            stream_worker(pool, 10, [])

            timings: List[int] = []
            start = time.monotonic()
            with ThreadPoolExecutor(max_workers=concurrency) as exc:
                futures = [
                    exc.submit(stream_worker, pool, STREAM_REQUESTS_PER_THREAD, timings)
                    for _ in range(concurrency)
                ]
                for f in futures:
                    f.result()
            total = duration(start)
            httpcorexyz_totals.append(total)

        # httpcore (upstream)
        with httpcore.ConnectionPool(max_connections=POOL_LIMIT) as upstream_pool:
            stream_worker_upstream(upstream_pool, 10, [])

            timings = []
            start = time.monotonic()
            with ThreadPoolExecutor(max_workers=concurrency) as exc:
                futures = [
                    exc.submit(
                        stream_worker_upstream,
                        upstream_pool,
                        STREAM_REQUESTS_PER_THREAD,
                        timings,
                    )
                    for _ in range(concurrency)
                ]
                for f in futures:
                    f.result()
            total = duration(start)
            httpcore_totals.append(total)

        total_reqs = concurrency * STREAM_REQUESTS_PER_THREAD
        print(
            f"  {concurrency:>3} threads x {STREAM_REQUESTS_PER_THREAD} reqs = {total_reqs:>5}  "
            f"httpcorexyz={httpcorexyz_totals[-1]:>6}ms  "
            f"httpcore={httpcore_totals[-1]:>6}ms  "
            f"speedup={httpcore_totals[-1] / max(1, httpcorexyz_totals[-1]):.2f}x"
        )

    x = list(range(len(STREAM_CONCURRENCY_LEVELS)))
    width = 0.35
    axis.bar([i - width / 2 for i in x], httpcorexyz_totals, width, label="httpcorexyz")
    axis.bar([i + width / 2 for i in x], httpcore_totals, width, label="httpcore")
    axis.set_xticks(x)
    axis.set_xticklabels(labels)
    axis.set_xlabel("concurrent threads")
    axis.set_ylabel("total time (ms)")
    axis.set_title(
        f"Streaming GET lock contention (sync, {STREAM_REQUESTS_PER_THREAD} reqs/thread)"
    )
    axis.legend()


def main() -> None:
    global PORT, URL, UPLOAD_URL

    args = sys.argv[1:]
    port = 1234
    if "--port" in args:
        idx = args.index("--port")
        port = int(args[idx + 1])
        args = args[:idx] + args[idx + 2 :]

    mode = args[0] if len(args) == 1 else None
    assert mode in (
        "async",
        "sync",
        "post-sync",
        "post-async",
        "stream-sync",
    ), (
        "Usage: python client.py <async|sync|post-sync|post-async|stream-sync> [--port PORT]"
    )

    PORT = port
    URL = f"http://localhost:{port}/req"
    UPLOAD_URL = f"http://localhost:{port}/upload"

    fig, ax = plt.subplots()
    results = None

    if mode == "async":
        results = asyncio.run(run_async_requests(ax))
        ax.set_xlabel("# request")
        ax.set_ylabel("[ms]")
    elif mode == "sync":
        results = run_sync_requests(ax)
        ax.set_xlabel("# request")
        ax.set_ylabel("[ms]")
    elif mode == "post-sync":
        print("POST upload throughput (sync):")
        run_sync_post_benchmark(ax)
    elif mode == "post-async":
        print("POST upload throughput (async):")
        asyncio.run(run_async_post_benchmark(ax))
    elif mode == "stream-sync":
        print("Streaming GET lock contention (sync):")
        run_stream_sync_benchmark(ax)

    if results is not None:
        print_latency_stats(results)

    plt.legend(loc="upper left")
    chart_path = f"tests/benchmark/results_{mode}.png"
    fig.savefig(chart_path, dpi=150, bbox_inches="tight")
    print(f"Chart saved to {chart_path}")
    print("DONE", flush=True)


if __name__ == "__main__":
    main()
