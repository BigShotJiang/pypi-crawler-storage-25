"""
NotiLens Emitter — batches and delivers events to the NotiLens webhook.
"""

import atexit
import json
import logging
import queue
import threading
import time
import urllib.request
import urllib.error
from typing import Optional

logger = logging.getLogger("notilens")

WEBHOOK_URL = "https://hook.notilens.com/webhook/{token}/send"


class NotiLensEmitter:
    def __init__(
        self,
        token: str,
        secret: str,
        name: str,
        min_level: str = "info",
        batch_interval: float = 2.0,
        max_retries: int = 3,
    ):
        self.token = token
        self.secret = secret
        self.name = name
        self.min_level = min_level.lower()
        self.url = WEBHOOK_URL.format(token=token)
        self._queue: queue.Queue = queue.Queue()
        self._stop = threading.Event()
        self._max_retries = max_retries
        self._batch_interval = batch_interval
        self._thread = threading.Thread(target=self._worker, daemon=True)
        self._thread.start()
        atexit.register(self.flush)
        self._levels = {"debug": 0, "info": 1, "warning": 2, "error": 3, "critical": 4}

    # ── public API ───────────────────────────────────────────────────────────

    # Maps log level → notification display type
    _LEVEL_TO_TYPE = {
        "debug":    "info",
        "info":     "info",
        "warning":  "warning",
        "error":    "urgent",
        "critical": "urgent",
    }

    # Events that should be actionable by default
    _ACTIONABLE_EVENTS = {
        "task.error", "task.failed", "task.timeout", "task.retry",
        "task.loop", "output.failed", "input.required", "input.rejected",
    }

    # Events that map to success type
    _SUCCESS_EVENTS = {"task.completed", "output.generated", "input.approved"}

    def send(
        self,
        event: str,
        message: str,
        level: str = "info",
        meta: Optional[dict] = None,
    ) -> None:
        """Queue an event for delivery. Non-blocking."""
        if self._level_num(level) < self._level_num(self.min_level):
            return

        _meta = meta or {}

        # Derive notification type — success events override level mapping
        if event in self._SUCCESS_EVENTS:
            ntype = "success"
        else:
            ntype = self._LEVEL_TO_TYPE.get(level.lower(), "info")

        task_label = _meta.get("task", "") or _meta.get("task_id", "")
        title = f"{self.name} | {task_label} | {event}" if task_label else f"{self.name} | {event}"

        payload = {
            "event": event,
            "title": title,
            "message": message,
            "type": ntype,
            "agent": self.name,  # kept as "agent" for backend compatibility
            "task_id": task_label,
            "is_actionable": event in self._ACTIONABLE_EVENTS,
            "image_url": _meta.pop("image_url", ""),
            "open_url": _meta.pop("open_url", ""),
            "download_url": _meta.pop("download_url", ""),
            "tags": _meta.pop("tags", ""),
            "ts": time.time(),
            "meta": _meta,
        }
        self._queue.put(payload)

    def flush(self, timeout: float = 5.0) -> None:
        """Block until all queued events are delivered or timeout reached."""
        joined = threading.Event()

        def _join():
            self._queue.join()
            joined.set()

        t = threading.Thread(target=_join, daemon=True)
        t.start()
        joined.wait(timeout=timeout)

    def shutdown(self) -> None:
        self.flush()
        self._stop.set()

    # ── internals ────────────────────────────────────────────────────────────

    def _level_num(self, level: str) -> int:
        return self._levels.get(level.lower(), 1)

    def _worker(self) -> None:
        while not self._stop.is_set():
            batch = []
            try:
                item = self._queue.get(timeout=self._batch_interval)
                batch.append(item)
                for _ in range(9):
                    try:
                        batch.append(self._queue.get_nowait())
                    except queue.Empty:
                        break
            except queue.Empty:
                continue

            for item in batch:
                self._deliver(item)
                self._queue.task_done()

    def _deliver(self, payload: dict) -> None:
        body = json.dumps(payload).encode()
        headers = {
            "Content-Type": "application/json",
            "X-NOTILENS-KEY": self.secret,
            "User-Agent": "NotiLens-SDK/0.5.1",
        }
        req = urllib.request.Request(self.url, data=body, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=5) as resp:
                if resp.status < 300:
                    logger.debug("NotiLens delivered: %s", payload.get("event"))
        except Exception as e:
            logger.debug("NotiLens delivery failed: %s", e)
