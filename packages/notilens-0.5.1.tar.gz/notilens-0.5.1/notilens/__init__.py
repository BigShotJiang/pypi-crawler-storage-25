"""
notilens
========
Unified SDK + CLI for NotiLens push notifications.

Usage (SDK):
    import notilens
    nl = notilens.init("my-app", token="TOKEN", secret="SECRET")
    run = nl.task("email")
    run.start()
    run.progress("Processing...")
    run.complete("Done!")

Usage (auto-patch):
    nl = notilens.init("my-app", token="TOKEN", secret="SECRET", patch=True)
    # Now use OpenAI, Anthropic, LangChain etc. normally — events fire automatically.
"""

from __future__ import annotations

import atexit
import logging
import os
import secrets
import time
from typing import Optional

from .emitter import NotiLensEmitter
from .loop_detector import LoopDetector
from .state import (
    cleanup_stale_state,
    delete_pointer,
    delete_state,
    get_state_file,
    read_state,
    update_state,
    write_pointer,
    write_state,
)

__version__ = "0.5.1"
__all__ = ["init", "NotiLens", "Run"]


# Registry of initialised agents — key: agent name
_agents: dict[str, "NotiLens"] = {}
# The agent that owns auto-patching (only one allowed)
_patch_owner: Optional[str] = None


class Run:
    """
    Execution context for a single task run. Created by agent.task(label).
    Each run has a unique run_id; state is isolated per run.
    """

    def __init__(self, agent_obj: "NotiLens", label: str, run_id: str):
        self._agent = agent_obj
        self.label = label
        self.run_id = run_id
        self._sf = get_state_file(agent_obj.name, run_id)
        self._metrics: dict = {}

    # ── Metrics ───────────────────────────────────────────────────────────────

    def metric(self, key: str, value) -> "Run":
        """Set a metric. Numeric values accumulate; strings are replaced."""
        if isinstance(value, (int, float)) and key in self._metrics and isinstance(self._metrics[key], (int, float)):
            self._metrics[key] += value
        else:
            self._metrics[key] = value
        return self

    def reset_metrics(self, key: Optional[str] = None) -> "Run":
        """Reset one metric by key, or all metrics if no key given."""
        if key is not None:
            self._metrics.pop(key, None)
        else:
            self._metrics = {}
        return self

    # ── Task lifecycle ────────────────────────────────────────────────────────

    def queue(self) -> "Run":
        write_state(self._sf, {
            "agent": self._agent.name,
            "task": self.label,
            "run_id": self.run_id,
            "queued_at": int(time.time() * 1000),
            "retry_count": 0,
            "loop_count": 0,
            "error_count": 0,
            "pause_count": 0,
            "wait_count": 0,
            "pause_total_ms": 0,
            "wait_total_ms": 0,
        })
        self._send("task.queued", f"{self._agent.name} | {self.label} queued", level="info")
        return self

    def start(self) -> "Run":
        now = int(time.time() * 1000)
        state = read_state(self._sf)
        if state:
            update_state(self._sf, {"start_time": now})
        else:
            write_state(self._sf, {
                "agent": self._agent.name,
                "task": self.label,
                "run_id": self.run_id,
                "start_time": now,
                "retry_count": 0,
                "loop_count": 0,
                "error_count": 0,
                "pause_count": 0,
                "wait_count": 0,
                "pause_total_ms": 0,
                "wait_total_ms": 0,
            })
        self._send("task.started", f"{self._agent.name} | {self.label} started", level="info")
        return self

    def progress(self, message: str) -> None:
        self._send("task.progress", message, level="info")

    def loop(self, message: str) -> None:
        state = read_state(self._sf)
        update_state(self._sf, {"loop_count": state.get("loop_count", 0) + 1})
        self._send("task.loop", message, level="warning")

    def retry(self) -> None:
        state = read_state(self._sf)
        update_state(self._sf, {"retry_count": state.get("retry_count", 0) + 1})
        self._send("task.retry", f"{self._agent.name} | {self.label} retrying", level="warning")

    def pause(self, message: str) -> None:
        now = int(time.time() * 1000)
        state = read_state(self._sf)
        update_state(self._sf, {
            "paused_at": now,
            "pause_count": state.get("pause_count", 0) + 1,
        })
        self._send("task.paused", message, level="warning")

    def resume(self, message: str) -> None:
        now = int(time.time() * 1000)
        state = read_state(self._sf)
        updates: dict = {}
        if state.get("paused_at"):
            updates["pause_total_ms"] = state.get("pause_total_ms", 0) + (now - state["paused_at"])
            updates["paused_at"] = None
        if state.get("wait_at"):
            updates["wait_total_ms"] = state.get("wait_total_ms", 0) + (now - state["wait_at"])
            updates["wait_at"] = None
        if updates:
            update_state(self._sf, updates)
        self._send("task.resumed", message, level="info")

    def wait(self, message: str) -> None:
        now = int(time.time() * 1000)
        state = read_state(self._sf)
        update_state(self._sf, {
            "wait_at": now,
            "wait_count": state.get("wait_count", 0) + 1,
        })
        self._send("task.waiting", message, level="warning")

    def stop(self) -> None:
        self._send("task.stopped", f"{self._agent.name} | {self.label} stopped", level="info")

    def error(self, message: str) -> None:
        state = read_state(self._sf)
        update_state(self._sf, {"last_error": message, "error_count": state.get("error_count", 0) + 1})
        self._send("task.error", message, level="error")

    def complete(self, message: str) -> None:
        self._send("task.completed", message, level="info")
        self._terminal()

    def fail(self, message: str) -> None:
        self._send("task.failed", message, level="error")
        self._terminal()

    def timeout(self, message: str) -> None:
        self._send("task.timeout", message, level="error")
        self._terminal()

    def cancel(self, message: str) -> None:
        self._send("task.cancelled", message, level="warning")
        self._terminal()

    def terminate(self, message: str) -> None:
        self._send("task.terminated", message, level="error")
        self._terminal()

    # ── Input ─────────────────────────────────────────────────────────────────

    def input_required(self, message: str) -> None:
        self._send("input.required", message, level="warning")

    def input_approved(self, message: str) -> None:
        self._send("input.approved", message, level="info")

    def input_rejected(self, message: str) -> None:
        self._send("input.rejected", message, level="warning")

    # ── Output ────────────────────────────────────────────────────────────────

    def output_generated(self, message: str, meta: Optional[dict] = None) -> None:
        self._send("output.generated", message, level="info", extra_meta=meta or {})

    def output_failed(self, message: str, meta: Optional[dict] = None) -> None:
        self._send("output.failed", message, level="error", extra_meta=meta or {})

    # ── Generic track ─────────────────────────────────────────────────────────

    def track(self, event: str, message: str, level: str = "info", meta: Optional[dict] = None) -> None:
        self._send(event, message, level=level, extra_meta=meta or {})

    def notify(
        self,
        event: str,
        message: str,
        level: str = "info",
        meta: Optional[dict] = None,
        image_url: str = "",
        open_url: str = "",
        download_url: str = "",
        tags: str = "",
    ) -> None:
        extra: dict = {}
        if meta:
            extra.update(meta)
        if image_url:
            extra["image_url"] = image_url
        if open_url:
            extra["open_url"] = open_url
        if download_url:
            extra["download_url"] = download_url
        if tags:
            extra["tags"] = tags
        self._send(event, message, level=level, extra_meta=extra)

    # ── Internal ──────────────────────────────────────────────────────────────

    def _send(self, event: str, message: str, level: str = "info", extra_meta: Optional[dict] = None) -> None:
        meta = {
            "run_id": self.run_id,
            "task": self.label,
            "agent": self._agent.name,
            **_state_meta(self._sf),
            **(extra_meta or {}),
        }
        if self._metrics:
            meta.update(self._metrics)
        self._agent._emitter.send(event, message, level=level, meta=meta)

    def _terminal(self) -> None:
        delete_state(self._sf)
        delete_pointer(self._agent.name, self.label)


class NotiLens:
    """
    A configured NotiLens agent. Returned by notilens.init().
    Use agent.task(label) to create a Run execution context.
    """

    def __init__(
        self,
        name: str,
        token: str,
        secret: str,
        *,
        state_ttl: int = 86400,
        min_level: str = "info",
        call_timeout: float = 30.0,
    ):
        self.name = name
        self._call_timeout = call_timeout
        self._metrics: dict = {}
        self._emitter = NotiLensEmitter(
            token=token,
            secret=secret,
            name=name,
            min_level=min_level,
        )
        self._loop_detector = LoopDetector()
        cleanup_stale_state(name, state_ttl)
        self._state_ttl = state_ttl

    # ── Task factory ──────────────────────────────────────────────────────────

    def task(self, label: str) -> Run:
        """Create a new Run execution context for the given task label."""
        run_id = _gen_run_id()
        cleanup_stale_state(self.name, self._state_ttl)
        return Run(self, label, run_id)

    # ── Agent-level metrics ───────────────────────────────────────────────────

    def metric(self, key: str, value) -> "NotiLens":
        """Set an agent-level metric. Numeric values accumulate; strings are replaced."""
        if isinstance(value, (int, float)) and key in self._metrics and isinstance(self._metrics[key], (int, float)):
            self._metrics[key] += value
        else:
            self._metrics[key] = value
        return self

    def reset_metrics(self, key: Optional[str] = None) -> "NotiLens":
        """Reset one agent-level metric by key, or all metrics if no key given."""
        if key is not None:
            self._metrics.pop(key, None)
        else:
            self._metrics = {}
        return self

    # ── Generic track ─────────────────────────────────────────────────────────

    def track(self, event: str, message: str, level: str = "info", meta: Optional[dict] = None) -> None:
        self._send(event, message, level=level, meta=meta or {})

    def notify(
        self,
        event: str,
        message: str,
        level: str = "info",
        meta: Optional[dict] = None,
        image_url: str = "",
        open_url: str = "",
        download_url: str = "",
        tags: str = "",
    ) -> None:
        extra: dict = {}
        if meta:
            extra.update(meta)
        if image_url:
            extra["image_url"] = image_url
        if open_url:
            extra["open_url"] = open_url
        if download_url:
            extra["download_url"] = download_url
        if tags:
            extra["tags"] = tags
        self._send(event, message, level=level, meta=extra)

    # ── Patching ──────────────────────────────────────────────────────────────

    def _apply_patches(self, call_timeout: float) -> list:
        from .patchers import (
            patch_openai, patch_anthropic, patch_langchain,
            patch_crewai, patch_pydantic_ai, patch_http,
        )
        patched = []
        if patch_openai(self._emitter, self._loop_detector, call_timeout):
            patched.append("openai")
        if patch_anthropic(self._emitter, self._loop_detector, call_timeout):
            patched.append("anthropic")
        if patch_langchain(self._emitter, self._loop_detector, call_timeout):
            patched.append("langchain")
        if patch_crewai(self._emitter, self._loop_detector, call_timeout):
            patched.append("crewai")
        if patch_pydantic_ai(self._emitter, self._loop_detector, call_timeout):
            patched.append("pydantic-ai")
        patch_http(self._emitter, self._loop_detector, call_timeout)
        patched.append("http-fallback")
        return patched

    def shutdown(self) -> None:
        self._emitter.shutdown()

    # ── Internal send helper ──────────────────────────────────────────────────

    def _send(self, event: str, message: str, level: str = "info", meta: Optional[dict] = None) -> None:
        enriched = dict(meta or {})
        enriched["agent"] = self.name
        if self._metrics:
            enriched.update(self._metrics)
        self._emitter.send(event, message, level=level, meta=enriched)


# ── Module-level init ─────────────────────────────────────────────────────────

def init(
    name: str,
    token: Optional[str] = None,
    secret: Optional[str] = None,
    *,
    patch: bool = False,
    state_ttl: int = 86400,
    min_level: str = "info",
    call_timeout: float = 30.0,
    debug: bool = False,
) -> NotiLens:
    """
    Initialise a NotiLens agent.

    Parameters
    ----------
    name : str
        Name identifying the source of events (agent, app, service, script, etc.).
    token : str
        NotiLens topic token. Falls back to NOTILENS_TOKEN env var.
    secret : str
        NotiLens topic secret. Falls back to NOTILENS_SECRET env var.
    state_ttl : int
        Seconds before orphaned state files are auto-deleted (default: 86400 / 24h).
    patch : bool
        Auto-patch AI frameworks (OpenAI, Anthropic, LangChain, etc.). Only one
        agent can own patching — raises if another agent already claimed it.
    """
    global _patch_owner

    if debug:
        logging.basicConfig(level=logging.DEBUG)
        logging.getLogger("notilens").setLevel(logging.DEBUG)

    token = token or os.environ.get("NOTILENS_TOKEN", "")
    secret = secret or os.environ.get("NOTILENS_SECRET", "")

    if not token or not secret:
        raise ValueError(
            "NotiLens token and secret are required. "
            "Pass them to init() or set NOTILENS_TOKEN / NOTILENS_SECRET env vars."
        )

    instance = NotiLens(
        name=name,
        token=token,
        secret=secret,
        state_ttl=state_ttl,
        min_level=min_level,
        call_timeout=call_timeout,
    )

    if patch:
        if _patch_owner is not None and _patch_owner != name:
            raise RuntimeError(
                f"Patch already claimed by '{_patch_owner}'. "
                "Only one instance can own auto-patching."
            )
        _patch_owner = name
        instance._apply_patches(call_timeout)

    _agents[name] = instance
    atexit.register(instance.shutdown)
    return instance


# ── Helpers ───────────────────────────────────────────────────────────────────

def _gen_run_id() -> str:
    return f"run_{int(time.time() * 1000)}_{secrets.token_hex(4)}"


def _state_meta(state_file) -> dict:
    state = read_state(state_file)
    now = int(time.time() * 1000)
    result: dict = {}

    start_time  = state.get("start_time", 0)
    queued_at   = state.get("queued_at", 0)
    pause_total = state.get("pause_total_ms", 0)
    wait_total  = state.get("wait_total_ms", 0)

    if state.get("paused_at"):
        pause_total += now - state["paused_at"]
    if state.get("wait_at"):
        wait_total += now - state["wait_at"]

    total_ms  = (now - start_time)  if start_time else 0
    queue_ms  = (start_time - queued_at) if (start_time and queued_at) else 0
    active_ms = max(0, total_ms - pause_total - wait_total)

    if total_ms    > 0: result["total_duration_ms"] = total_ms
    if queue_ms    > 0: result["queue_ms"]           = queue_ms
    if pause_total > 0: result["pause_ms"]           = pause_total
    if wait_total  > 0: result["wait_ms"]            = wait_total
    if active_ms   > 0: result["active_ms"]          = active_ms

    if state.get("retry_count", 0) > 0: result["retry_count"] = state["retry_count"]
    if state.get("loop_count",  0) > 0: result["loop_count"]  = state["loop_count"]
    if state.get("error_count", 0) > 0: result["error_count"] = state["error_count"]
    if state.get("pause_count", 0) > 0: result["pause_count"] = state["pause_count"]
    if state.get("wait_count",  0) > 0: result["wait_count"]  = state["wait_count"]

    return result
