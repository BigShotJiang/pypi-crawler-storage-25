import json
import os
import tempfile
import time
from pathlib import Path


def _user() -> str:
    try:
        return os.getlogin()
    except OSError:
        return os.environ.get("USER", os.environ.get("USERNAME", "default"))


def get_state_file(name: str, run_id: str) -> Path:
    return Path(tempfile.gettempdir()) / f"notilens_{_user()}_{name}_{run_id}.json"


def get_pointer_file(name: str, label: str) -> Path:
    safe_label = label.replace("/", "_").replace("\\", "_")
    return Path(tempfile.gettempdir()) / f"notilens_{_user()}_{name}_{safe_label}.ptr"


def read_state(state_file: Path) -> dict:
    if not state_file.exists():
        return {}
    try:
        return json.loads(state_file.read_text())
    except Exception:
        return {}


def write_state(state_file: Path, state: dict) -> None:
    tmp = state_file.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=2))
    tmp.chmod(0o600)
    tmp.rename(state_file)


def update_state(state_file: Path, updates: dict) -> None:
    state = read_state(state_file)
    state.update(updates)
    write_state(state_file, state)


def delete_state(state_file: Path) -> None:
    if state_file.exists():
        state_file.unlink()


def read_pointer(name: str, label: str) -> str:
    pf = get_pointer_file(name, label)
    if pf.exists():
        try:
            return pf.read_text().strip()
        except Exception:
            pass
    return ""


def write_pointer(name: str, label: str, run_id: str) -> None:
    get_pointer_file(name, label).write_text(run_id)


def delete_pointer(name: str, label: str) -> None:
    pf = get_pointer_file(name, label)
    if pf.exists():
        pf.unlink()


def cleanup_stale_state(name: str, state_ttl_seconds: int) -> None:
    user = _user()
    tmp = Path(tempfile.gettempdir())
    cutoff = time.time() - state_ttl_seconds
    for pattern in (
        f"notilens_{user}_{name}_run_*.json",
        f"notilens_{user}_{name}_*.ptr",
    ):
        for f in tmp.glob(pattern):
            try:
                if f.stat().st_mtime < cutoff:
                    f.unlink()
            except Exception:
                pass
