"""
Patcher for the official openai Python sdk.
Wraps: openai.chat.completions.create (sync + async)
"""

import time
import functools
import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..emitter import NotiLensEmitter
    from ..loop_detector import LoopDetector

logger = logging.getLogger("notilens.openai")

_patched = False


def patch(emitter: "NotiLensEmitter", loop_detector: "LoopDetector", timeout: float) -> bool:
    global _patched
    if _patched:
        return True
    try:
        import openai

        from openai.resources.chat.completions import Completions
        CompletionsClass = Completions
        _orig = CompletionsClass.create

        @functools.wraps(_orig)
        def _sync_create(self, *args, **kwargs):
            model = kwargs.get("model", "unknown")
            messages = kwargs.get("messages", [])
            start = time.time()

            loop_msg = loop_detector.record()
            emitter.send("task.loop", loop_msg, level="warning", meta={"model": model, "source": "openai"})

            emitter.send("ai.call.start", f"OpenAI call — model={model}, messages={len(messages)}",
                         level="info", meta={"model": model, "messages": len(messages), "source": "openai"})
            try:
                result = _orig(self, *args, **kwargs)
                duration = round(time.time() - start, 3)

                if duration > timeout:
                    emitter.send("task.timeout", f"OpenAI call took {duration}s (threshold={timeout}s)",
                                 level="warning", meta={"model": model, "duration": duration, "source": "openai"})

                usage = getattr(result, "usage", None)
                meta = {"model": model, "duration": duration, "source": "openai"}
                if usage:
                    meta["prompt_tokens"] = getattr(usage, "prompt_tokens", 0)
                    meta["completion_tokens"] = getattr(usage, "completion_tokens", 0)
                    meta["total_tokens"] = getattr(usage, "total_tokens", 0)

                emitter.send("ai.call.complete", f"OpenAI done in {duration}s",
                             level="info", meta=meta)
                return result

            except Exception as exc:
                duration = round(time.time() - start, 3)
                emitter.send("task.error", f"OpenAI error: {exc}",
                             level="error", meta={"model": model, "error": str(exc), "source": "openai"})
                raise

        CompletionsClass.create = _sync_create

        # ── Async ──────────────────────────────────────────────────────────
        try:
            from openai.resources.chat.completions import AsyncCompletions
            AsyncCompletionsClass = AsyncCompletions
            _orig_async = AsyncCompletionsClass.create

            @functools.wraps(_orig_async)
            async def _async_create(self, *args, **kwargs):
                model = kwargs.get("model", "unknown")
                messages = kwargs.get("messages", [])
                start = time.time()

                loop_msg = loop_detector.record()
                if loop_msg:
                    emitter.send("task.loop", loop_msg, level="warning", meta={"model": model, "source": "openai"})

                emitter.send("ai.call.start", f"OpenAI async — model={model}",
                             level="info", meta={"model": model, "source": "openai"})
                try:
                    result = await _orig_async(self, *args, **kwargs)
                    duration = round(time.time() - start, 3)
                    emitter.send("ai.call.complete", f"OpenAI async done in {duration}s",
                                 level="info", meta={"model": model, "duration": duration, "source": "openai"})
                    return result
                except Exception as exc:
                    emitter.send("task.error", f"OpenAI async error: {exc}",
                                 level="error", meta={"model": model, "error": str(exc), "source": "openai"})
                    raise

            AsyncCompletionsClass.create = _async_create
        except Exception:
            pass

        _patched = True
        logger.debug("NotiLens: OpenAI patched")
        return True

    except ImportError:
        return False
    except Exception as e:
        logger.warning("NotiLens: failed to patch OpenAI — %s", e)
        return False
