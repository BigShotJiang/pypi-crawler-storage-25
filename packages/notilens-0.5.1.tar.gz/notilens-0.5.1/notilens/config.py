"""
NotiLens config — per-name token + secret stored in ~/.notilens_config.json
"""

import json
from pathlib import Path
from typing import Optional

CONFIG_FILE = Path.home() / ".notilens_config.json"


def read_config() -> dict:
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text())
    except Exception:
        return {}


def write_config(config: dict) -> None:
    CONFIG_FILE.write_text(json.dumps(config, indent=2))


def get_agent_config(name: str) -> Optional[dict]:
    return read_config().get(name)


def save_agent(name: str, token: str, secret: str) -> None:
    config = read_config()
    config[name] = {"token": token, "secret": secret}
    write_config(config)


def remove_agent(name: str) -> bool:
    config = read_config()
    if name not in config:
        return False
    del config[name]
    write_config(config)
    return True


def list_agents() -> list:
    return list(read_config().keys())
