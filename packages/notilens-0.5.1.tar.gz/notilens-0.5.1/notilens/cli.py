import sys
import time
from importlib.metadata import version

from .config import get_agent_config, save_agent, remove_agent, list_agents
from .emitter import NotiLensEmitter
from . import _gen_run_id
from .state import (
    cleanup_stale_state,
    delete_pointer,
    delete_state,
    get_state_file,
    read_pointer,
    read_state,
    update_state,
    write_pointer,
    write_state,
)

try:
    VERSION = version("notilens")
except Exception:
    VERSION = "0.4.0"


# ── Arg helpers ───────────────────────────────────────────────────────────────

def positional_args(args: list) -> list:
    result = []
    for a in args:
        if a.startswith("--"):
            break
        result.append(a)
    return result


def parse_flags(args: list) -> dict:
    flags = {
        "name": "",
        "task_label": "",
        "meta": {},
        "image_url": "",
        "open_url": "",
        "download_url": "",
        "tags": "",
        "is_actionable": "",
        "level": "",
    }

    i = 0
    while i < len(args):
        a = args[i]
        if a == "--name":
            flags["name"] = args[i + 1] if i + 1 < len(args) else ""
            i += 2
        elif a == "--task":
            flags["task_label"] = args[i + 1] if i + 1 < len(args) else ""
            i += 2
        elif a == "--level":
            flags["level"] = args[i + 1] if i + 1 < len(args) else ""
            i += 2
        elif a == "--image_url":
            flags["image_url"] = args[i + 1] if i + 1 < len(args) else ""
            i += 2
        elif a == "--open_url":
            flags["open_url"] = args[i + 1] if i + 1 < len(args) else ""
            i += 2
        elif a == "--download_url":
            flags["download_url"] = args[i + 1] if i + 1 < len(args) else ""
            i += 2
        elif a == "--tags":
            flags["tags"] = args[i + 1] if i + 1 < len(args) else ""
            i += 2
        elif a == "--is_actionable":
            flags["is_actionable"] = args[i + 1] if i + 1 < len(args) else ""
            i += 2
        elif a == "--meta":
            kv = args[i + 1] if i + 1 < len(args) else ""
            eq = kv.find("=")
            if eq != -1:
                flags["meta"][kv[:eq]] = kv[eq + 1:]
            i += 2
        else:
            i += 1

    if not flags["name"]:
        print("❌ --name is required", file=sys.stderr)
        sys.exit(1)

    return flags


def resolve_run_id(flags: dict) -> str:
    """Get current run_id from pointer file, or exit with error."""
    run_id = read_pointer(flags["name"], flags["task_label"])
    if not run_id:
        label = flags["task_label"] or "(no --task label)"
        print(f"❌ No active run for '{flags['name']}' task '{label}'. Run start first.",
              file=sys.stderr)
        sys.exit(1)
    return run_id


# ── Event helpers ─────────────────────────────────────────────────────────────

EVENT_LEVELS = {
    "task.queued":       "info",
    "task.started":      "info",
    "task.progress":     "info",
    "task.loop":         "warning",
    "task.retry":        "warning",
    "task.completed":    "info",
    "task.stopped":      "info",
    "task.failed":       "error",
    "task.error":        "error",
    "task.timeout":      "error",
    "task.cancelled":    "warning",
    "task.terminated":   "error",
    "task.paused":       "warning",
    "task.resumed":      "info",
    "task.waiting":      "warning",
    "output.generated":  "info",
    "output.failed":     "error",
    "input.required":    "warning",
    "input.approved":    "info",
    "input.rejected":    "warning",
}


_emitter_cache: dict = {}


def get_emitter(name: str) -> NotiLensEmitter:
    if name not in _emitter_cache:
        conf = get_agent_config(name)
        if not conf or not conf.get("token") or not conf.get("secret"):
            print(f"❌ '{name}' not configured. Run: notilens init --name {name} --token TOKEN --secret SECRET",
                  file=sys.stderr)
            sys.exit(1)
        _emitter_cache[name] = NotiLensEmitter(token=conf["token"], secret=conf["secret"], name=name)
    return _emitter_cache[name]


def flush_all() -> None:
    for emitter in _emitter_cache.values():
        emitter.flush(timeout=5.0)
        emitter.shutdown()


def send_event(event: str, message: str, flags: dict, run_id: str) -> None:
    emitter = get_emitter(flags["name"])
    state_file = get_state_file(flags["name"], run_id)
    state = read_state(state_file)
    now = int(time.time() * 1000)

    metrics = state.get("metrics", {})

    meta = {
        "run_id": run_id,
        "task": flags["task_label"],
        "agent": flags["name"],  # kept as "agent" for backend compatibility
        **metrics,
        **flags["meta"],
    }
    if flags["image_url"]:   meta["image_url"]    = flags["image_url"]
    if flags["open_url"]:    meta["open_url"]     = flags["open_url"]
    if flags["download_url"]: meta["download_url"] = flags["download_url"]
    if flags["tags"]:        meta["tags"]         = flags["tags"]
    if flags["is_actionable"]: meta["is_actionable"] = flags["is_actionable"]

    start_time  = state.get("start_time", 0)
    queued_at   = state.get("queued_at", 0)
    pause_total = state.get("pause_total_ms", 0)
    wait_total  = state.get("wait_total_ms", 0)

    if state.get("paused_at"):
        pause_total += now - state["paused_at"]
    if state.get("wait_at"):
        wait_total += now - state["wait_at"]

    total_ms  = (now - start_time) if start_time else 0
    queue_ms  = (start_time - queued_at) if (start_time and queued_at) else 0
    active_ms = max(0, total_ms - pause_total - wait_total)

    if total_ms    > 0: meta["total_duration_ms"] = total_ms
    if queue_ms    > 0: meta["queue_ms"]           = queue_ms
    if pause_total > 0: meta["pause_ms"]           = pause_total
    if wait_total  > 0: meta["wait_ms"]            = wait_total
    if active_ms   > 0: meta["active_ms"]          = active_ms

    if state.get("retry_count", 0) > 0: meta["retry_count"] = state["retry_count"]
    if state.get("loop_count",  0) > 0: meta["loop_count"]  = state["loop_count"]
    if state.get("error_count", 0) > 0: meta["error_count"] = state["error_count"]
    if state.get("pause_count", 0) > 0: meta["pause_count"] = state["pause_count"]
    if state.get("wait_count",  0) > 0: meta["wait_count"]  = state["wait_count"]

    level = flags["level"] or EVENT_LEVELS.get(event, "info")
    emitter.send(event, message, level=level, meta=meta)
    flush_all()


# ── Commands ──────────────────────────────────────────────────────────────────

def main():
    args = sys.argv[1:]
    command = args[0] if args else ""
    rest = args[1:]

    # ── Setup ─────────────────────────────────────────────────────────────────
    if command == "init":
        name = token = secret = ""
        i = 0
        while i < len(rest):
            if rest[i] == "--name" and i + 1 < len(rest):
                name = rest[i + 1]; i += 2
            elif rest[i] == "--token" and i + 1 < len(rest):
                token = rest[i + 1]; i += 2
            elif rest[i] == "--secret" and i + 1 < len(rest):
                secret = rest[i + 1]; i += 2
            else:
                i += 1
        if not name or not token or not secret:
            print("Usage: notilens init --name NAME --token TOKEN --secret SECRET", file=sys.stderr)
            sys.exit(1)
        save_agent(name, token, secret)
        print(f"✔ '{name}' configured")

    elif command == "agents":
        agents = list_agents()
        if agents:
            for a in agents:
                print(f"  • {a}")
        else:
            print("No agents configured.")

    elif command == "remove-agent":
        if not rest:
            print("Usage: notilens remove-agent NAME", file=sys.stderr)
            sys.exit(1)
        if remove_agent(rest[0]):
            print(f"✔ '{rest[0]}' removed")
        else:
            print(f"❌ '{rest[0]}' not found", file=sys.stderr)

    # ── Task lifecycle ────────────────────────────────────────────────────────
    elif command == "queue":
        flags = parse_flags(rest)
        run_id = _gen_run_id()
        sf = get_state_file(flags["name"], run_id)
        write_state(sf, {
            "agent": flags["name"],
            "task": flags["task_label"],
            "run_id": run_id,
            "queued_at": int(time.time() * 1000),
            "retry_count": 0,
            "loop_count": 0,
            "error_count": 0,
            "pause_count": 0,
            "wait_count": 0,
            "pause_total_ms": 0,
            "wait_total_ms": 0,
        })
        write_pointer(flags["name"], flags["task_label"], run_id)
        send_event("task.queued", f"{flags['name']} | {flags['task_label']} queued", flags, run_id)
        print(run_id)

    elif command == "start":
        flags = parse_flags(rest)
        existing = read_pointer(flags["name"], flags["task_label"])
        if existing:
            run_id = existing
            sf = get_state_file(flags["name"], run_id)
            update_state(sf, {"start_time": int(time.time() * 1000)})
        else:
            run_id = _gen_run_id()
            sf = get_state_file(flags["name"], run_id)
            write_state(sf, {
                "agent": flags["name"],
                "task": flags["task_label"],
                "run_id": run_id,
                "start_time": int(time.time() * 1000),
                "retry_count": 0,
                "loop_count": 0,
                "error_count": 0,
                "pause_count": 0,
                "wait_count": 0,
                "pause_total_ms": 0,
                "wait_total_ms": 0,
            })
            write_pointer(flags["name"], flags["task_label"], run_id)
        send_event("task.started", f"{flags['name']} | {flags['task_label']} started", flags, run_id)
        print(run_id)

    elif command == "progress":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        send_event("task.progress", msg, flags, run_id)
        print(f"⏳ Progress: {flags['name']} | {flags['task_label']}")

    elif command == "loop":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        sf = get_state_file(flags["name"], run_id)
        state = read_state(sf)
        loop_count = state.get("loop_count", 0) + 1
        update_state(sf, {"loop_count": loop_count})
        send_event("task.loop", msg, flags, run_id)
        print(f"🔄 Loop ({loop_count}): {flags['name']} | {flags['task_label']}")

    elif command == "retry":
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        sf = get_state_file(flags["name"], run_id)
        state = read_state(sf)
        update_state(sf, {"retry_count": state.get("retry_count", 0) + 1})
        send_event("task.retry", f"{flags['name']} | {flags['task_label']} retrying", flags, run_id)
        print(f"🔁 Retry: {flags['name']} | {flags['task_label']}")

    elif command == "stop":
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        send_event("task.stopped", f"{flags['name']} | {flags['task_label']} stopped", flags, run_id)
        print(f"⏹  Stopped: {flags['name']} | {flags['task_label']}")

    elif command == "pause":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        sf = get_state_file(flags["name"], run_id)
        now = int(time.time() * 1000)
        state = read_state(sf)
        update_state(sf, {"paused_at": now, "pause_count": state.get("pause_count", 0) + 1})
        send_event("task.paused", msg, flags, run_id)
        print(f"⏸  Paused: {flags['name']} | {flags['task_label']}")

    elif command == "resume":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        sf = get_state_file(flags["name"], run_id)
        now = int(time.time() * 1000)
        state = read_state(sf)
        updates: dict = {}
        if state.get("paused_at"):
            updates["pause_total_ms"] = state.get("pause_total_ms", 0) + (now - state["paused_at"])
            updates["paused_at"] = None
        if state.get("wait_at"):
            updates["wait_total_ms"] = state.get("wait_total_ms", 0) + (now - state["wait_at"])
            updates["wait_at"] = None
        if updates:
            update_state(sf, updates)
        send_event("task.resumed", msg, flags, run_id)
        print(f"▶️  Resumed: {flags['name']} | {flags['task_label']}")

    elif command == "wait":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        sf = get_state_file(flags["name"], run_id)
        now = int(time.time() * 1000)
        state = read_state(sf)
        update_state(sf, {"wait_at": now, "wait_count": state.get("wait_count", 0) + 1})
        send_event("task.waiting", msg, flags, run_id)
        print(f"⏳ Waiting: {flags['name']} | {flags['task_label']}")

    elif command == "complete":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        sf = get_state_file(flags["name"], run_id)
        send_event("task.completed", msg, flags, run_id)
        delete_state(sf)
        delete_pointer(flags["name"], flags["task_label"])
        print(f"✅ Completed: {flags['name']} | {flags['task_label']}")

    elif command == "error":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        sf = get_state_file(flags["name"], run_id)
        state = read_state(sf)
        update_state(sf, {"last_error": msg, "error_count": state.get("error_count", 0) + 1})
        send_event("task.error", msg, flags, run_id)
        print(f"❌ Error: {msg}", file=sys.stderr)

    elif command == "fail":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        sf = get_state_file(flags["name"], run_id)
        send_event("task.failed", msg, flags, run_id)
        delete_state(sf)
        delete_pointer(flags["name"], flags["task_label"])
        print(f"💥 Failed: {flags['name']} | {flags['task_label']}")

    elif command == "timeout":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        sf = get_state_file(flags["name"], run_id)
        send_event("task.timeout", msg, flags, run_id)
        delete_state(sf)
        delete_pointer(flags["name"], flags["task_label"])
        print(f"⏰ Timeout: {flags['name']} | {flags['task_label']}")

    elif command == "cancel":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        sf = get_state_file(flags["name"], run_id)
        send_event("task.cancelled", msg, flags, run_id)
        delete_state(sf)
        delete_pointer(flags["name"], flags["task_label"])
        print(f"🚫 Cancelled: {flags['name']} | {flags['task_label']}")

    elif command == "terminate":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        sf = get_state_file(flags["name"], run_id)
        send_event("task.terminated", msg, flags, run_id)
        delete_state(sf)
        delete_pointer(flags["name"], flags["task_label"])
        print(f"⚠️  Terminated: {flags['name']} | {flags['task_label']}")

    # ── Input ─────────────────────────────────────────────────────────────────
    elif command == "input.required":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        send_event("input.required", msg, flags, run_id)

    elif command == "input.approve":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        send_event("input.approved", msg, flags, run_id)

    elif command == "input.reject":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        send_event("input.rejected", msg, flags, run_id)

    # ── Output events ──────────────────────────────────────────────────────────
    elif command == "output.generate":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        send_event("output.generated", msg, flags, run_id)

    elif command == "output.fail":
        pos = positional_args(rest)
        msg = pos[0] if pos else ""
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        send_event("output.failed", msg, flags, run_id)

    # ── Metrics ───────────────────────────────────────────────────────────────
    elif command == "metric":
        pos = positional_args(rest)
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        sf = get_state_file(flags["name"], run_id)
        state = read_state(sf)
        metrics = state.get("metrics", {})

        for kv in pos:
            eq = kv.find("=")
            if eq == -1:
                continue
            key = kv[:eq]
            raw = kv[eq + 1:]
            try:
                val = float(raw) if "." in raw else int(raw)
                if key in metrics and isinstance(metrics[key], (int, float)):
                    metrics[key] += val
                else:
                    metrics[key] = val
            except ValueError:
                metrics[key] = raw

        update_state(sf, {"metrics": metrics})
        print(f"📊 Metrics: {metrics}")

    elif command == "metric.reset":
        pos = positional_args(rest)
        flags = parse_flags(rest)
        run_id = resolve_run_id(flags)
        sf = get_state_file(flags["name"], run_id)
        state = read_state(sf)
        metrics = state.get("metrics", {})

        if pos:
            key = pos[0]
            metrics.pop(key, None)
            print(f"📊 Metric '{key}' reset")
        else:
            metrics = {}
            print("📊 All metrics reset")

        update_state(sf, {"metrics": metrics})

    # ── Notify ────────────────────────────────────────────────────────────────
    elif command == "notify":
        pos = positional_args(rest)
        event = pos[0] if len(pos) > 0 else ""
        msg = pos[1] if len(pos) > 1 else ""
        if not event:
            print("Usage: notilens notify EVENT MESSAGE --name NAME", file=sys.stderr)
            sys.exit(1)
        flags = parse_flags(rest[2:])
        emitter = get_emitter(flags["name"])
        meta: dict = {}
        if flags["image_url"]:    meta["image_url"]    = flags["image_url"]
        if flags["open_url"]:     meta["open_url"]     = flags["open_url"]
        if flags["download_url"]: meta["download_url"] = flags["download_url"]
        if flags["tags"]:         meta["tags"]         = flags["tags"]
        meta.update(flags["meta"])
        level = flags["level"] or "info"
        emitter.send(event, msg, level=level, meta=meta)
        flush_all()
        print(f"📡 Notified: {event}")

    # ── Generic track ─────────────────────────────────────────────────────────
    elif command == "track":
        pos = positional_args(rest)
        event = pos[0] if len(pos) > 0 else ""
        msg = pos[1] if len(pos) > 1 else ""
        if not event:
            print("Usage: notilens track EVENT MESSAGE --name NAME [--task LABEL]", file=sys.stderr)
            sys.exit(1)
        flags = parse_flags(rest[2:])
        run_id = read_pointer(flags["name"], flags["task_label"]) or ""
        send_event(event, msg, flags, run_id)
        print(f"📡 Tracked: {event}")

    # ── Other ─────────────────────────────────────────────────────────────────
    elif command == "version":
        print(f"NotiLens v{VERSION}")

    else:
        print_usage()


def print_usage():
    print("""Usage: notilens <command> [options]

Setup:
  notilens init --name NAME --token TOKEN --secret SECRET
  notilens agents
  notilens remove-agent NAME

Notify:
  notilens notify EVENT "msg" --name NAME

Task Lifecycle:
  notilens queue --name NAME --task LABEL
  notilens start --name NAME --task LABEL
  notilens progress "msg" --name NAME --task LABEL
  notilens loop "msg" --name NAME --task LABEL
  notilens retry --name NAME --task LABEL
  notilens stop --name NAME --task LABEL
  notilens pause "msg" --name NAME --task LABEL
  notilens resume "msg" --name NAME --task LABEL
  notilens wait "msg" --name NAME --task LABEL
  notilens complete "msg" --name NAME --task LABEL
  notilens error "msg" --name NAME --task LABEL
  notilens fail "msg" --name NAME --task LABEL
  notilens timeout "msg" --name NAME --task LABEL
  notilens cancel "msg" --name NAME --task LABEL
  notilens terminate "msg" --name NAME --task LABEL

Input:
  notilens input.required "msg" --name NAME --task LABEL
  notilens input.approve "msg" --name NAME --task LABEL
  notilens input.reject "msg" --name NAME --task LABEL

Output:
  notilens output.generate "msg" --name NAME --task LABEL
  notilens output.fail "msg" --name NAME --task LABEL

Metrics:
  notilens metric tokens=512 cost=0.003 --name NAME --task LABEL
  notilens metric.reset tokens --name NAME --task LABEL
  notilens metric.reset --name NAME --task LABEL

Generic:
  notilens track EVENT "msg" --name NAME [--task LABEL]

Options:
  --name NAME
  --task LABEL              Task label (semantic name, e.g. "email", "report")
  --level debug|info|warning|error
  --meta key=value          (repeatable)
  --image_url URL
  --open_url URL
  --download_url URL
  --tags "tag1,tag2"
  --is_actionable true|false

Other:
  notilens version""")
