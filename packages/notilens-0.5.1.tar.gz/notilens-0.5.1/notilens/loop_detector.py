"""
Loop detector — tracks AI call count and reports on every call.
"""


class LoopDetector:
    def __init__(self):
        self._count = 0

    def record(self) -> str:
        self._count += 1
        return f"AI call #{self._count} recorded"
