"""Pydantic models for LS Securities OpenAPI SC2 (Stock order modify-confirm push).

SC2 is a Real-time WebSocket TR that pushes per-event notifications when
a stock order modification is confirmed by the exchange.  Subscription is
account-keyed (``tr_type='1'``); a single SC0..SC4 registration enables
all five order-event streams.

The ``SC2RealResponseBody`` inherits ``SC1RealResponseBody`` — same
~130 fields.  When ``ordxctptncode='12'`` the event is a modify-confirm.

Field source policy: identical to SC1 (see that module's docstring for
the full policy).
"""

from typing import Optional
from pydantic import BaseModel, Field, PrivateAttr
from websockets import Response

from ....models import BlockRealRequestHeader, BlockRealResponseHeader
from ..SC1.blocks import SC1RealResponseBody


class SC2RealRequestHeader(BlockRealRequestHeader):
    """SC2 real-time request header. Inherits the standard LS WS request header schema."""
    pass


class SC2RealResponseHeader(BlockRealResponseHeader):
    """SC2 real-time response header. Inherits the standard LS WS response header schema."""
    pass


class SC2RealRequestBody(BaseModel):
    """SC2RealRequestBody — WebSocket subscription envelope for stock order modify-confirm push."""

    tr_cd: str = Field(
        default="SC2",
        title="거래 CD (TR code)",
        description="Fixed TR code identifier for this subscription. Always 'SC2'.",
        examples=["SC2"],
    )
    tr_key: Optional[str] = Field(
        default=None,
        max_length=8,
        title="단축코드 (Short symbol code, optional)",
        description=(
            "Optional short symbol code. SC0..SC4 subscriptions are "
            "account-scoped (``tr_type='1'``) so this is typically left "
            "blank."
        ),
        examples=["", "005930"],
    )


class SC2RealRequest(BaseModel):
    """SC2 (stock-order modify-confirm) real-time subscription request."""
    header: SC2RealRequestHeader = Field(
        SC2RealRequestHeader(token="", tr_type="1"),
        title="요청 헤더 (Request header)",
        description="SC2 WebSocket subscription header block (token + tr_type; tr_type='1' register account / '2' unregister)."
    )
    body: SC2RealRequestBody = Field(
        SC2RealRequestBody(tr_cd="SC2", tr_key=""),
        title="요청 바디 (Request body)",
        description="SC2 input body — TR code 'SC2' for stock-order modify-confirm events; tr_key empty (account-level subscription)."
    )


class SC2RealResponseBody(SC1RealResponseBody):
    """SC2RealResponseBody — modify-confirm event (ordxctptncode='12').

    Inherits ``SC1RealResponseBody`` verbatim.  ``ordxctptncode='12'``
    indicates this event is a modify confirmation.
    """
    pass


class SC2RealResponse(BaseModel):
    """SC2 (stock-order modify-confirm) real-time response."""
    header: Optional[SC2RealResponseHeader]
    body: Optional[SC2RealResponseBody]

    rsp_cd: str = Field(..., title="응답 코드 (Response code)")
    rsp_msg: str = Field(..., title="응답 메시지 (Response message)")
    error_msg: Optional[str] = Field(None, title="오류 메시지 (Error message)")
    _raw_data: Optional[Response] = PrivateAttr(default=None)

    @property
    def raw_data(self) -> Optional[Response]:
        return self._raw_data

    @raw_data.setter
    def raw_data(self, raw_resp: Response) -> None:
        self._raw_data = raw_resp
