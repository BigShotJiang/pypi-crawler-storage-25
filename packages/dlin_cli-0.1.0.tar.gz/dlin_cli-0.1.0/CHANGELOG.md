# Changelog

## [0.1.0] - 2026-03-28

Initial release of **dlin**.
