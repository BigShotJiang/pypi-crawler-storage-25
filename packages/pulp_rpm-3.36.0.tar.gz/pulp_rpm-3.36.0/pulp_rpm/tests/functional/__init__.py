"""Tests for file plugin."""
