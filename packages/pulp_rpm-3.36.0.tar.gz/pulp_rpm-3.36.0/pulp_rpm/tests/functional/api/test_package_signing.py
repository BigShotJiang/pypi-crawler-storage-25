from dataclasses import dataclass
import hashlib
from pathlib import Path
import uuid

import pytest
import requests
from pulpcore.client.pulp_rpm.exceptions import ApiException
from pulpcore.exceptions.validation import InvalidSignatureError

from pulp_rpm.app.shared_utils import RpmTool
from pulp_rpm.tests.functional.constants import (
    RPM_PACKAGE_FILENAME,
    RPM_PACKAGE_FILENAME2,
    RPM_UNSIGNED_URL,
    RPM_UNSIGNED_URL2,
)
from pulp_rpm.tests.functional.utils import get_package_repo_path


def get_fixture(path: Path, url: str) -> Path:
    path.write_bytes(requests.get(url).content)
    return path


@pytest.mark.parallel
def test_register_rpm_package_signing_service(rpm_package_signing_service):
    """
    Register a sample rpmsign-based signing service and validate it works.
    """
    service = rpm_package_signing_service
    assert "/api/v3/signing-services/" in service.pulp_href


@dataclass
class GPGMetadata:
    pubkey: str
    fingerprint: str
    keyid: str


@pytest.fixture
def signing_gpg_extra(signing_gpg_metadata):
    """GPG instance with an extra gpg keypair registered."""
    PRIVATE_KEY_PULP_QE = (
        "https://raw.githubusercontent.com/pulp/pulp-fixtures/master/common/GPG-PRIVATE-KEY-pulp-qe"
    )
    gpg, fingerprint_a, keyid_a = signing_gpg_metadata

    response_private = requests.get(PRIVATE_KEY_PULP_QE)
    response_private.raise_for_status()
    import_result = gpg.import_keys(response_private.content)
    fingerprint_b = import_result.fingerprints[0]
    gpg.trust_keys(fingerprint_b, "TRUST_ULTIMATE")

    pubkey_a = gpg.export_keys(fingerprint_a)
    pubkey_b = gpg.export_keys(fingerprint_b)
    return (
        GPGMetadata(pubkey_a, fingerprint_a, fingerprint_a[-8:]),
        GPGMetadata(pubkey_b, fingerprint_b, fingerprint_b[-8:]),
    )


@pytest.mark.parallel
def test_sign_package_on_upload(
    tmp_path,
    pulpcore_bindings,
    monitor_task,
    gen_object_with_cleanup,
    download_content_unit,
    signing_gpg_extra,
    rpm_package_signing_service,
    rpm_package_api,
    rpm_repository_api,
    rpm_repository_factory,
    rpm_publication_factory,
    rpm_package_factory,
    rpm_distribution_factory,
):
    """
    Sign an Rpm Package with the Package Upload endpoint.

    This ensures different
    """
    # Setup RPM tool and package to upload
    gpg_a, gpg_b = signing_gpg_extra
    fingerprint_set = set([gpg_a.fingerprint, gpg_b.fingerprint])
    assert len(fingerprint_set) == 2

    rpm_tool = RpmTool(tmp_path)
    rpm_tool.import_pubkey_string(gpg_a.pubkey)
    rpm_tool.import_pubkey_string(gpg_b.pubkey)

    file_to_upload = tmp_path / RPM_PACKAGE_FILENAME
    file_to_upload.write_bytes(requests.get(RPM_UNSIGNED_URL).content)
    with pytest.raises(InvalidSignatureError, match="The package is not signed: .*"):
        rpm_tool.verify_signature(file_to_upload)

    # Upload Package to Repository
    # The same file is uploaded, but signed with different keys each time
    for fingerprint in fingerprint_set:
        prefixed_fingerprint = f"v4:{fingerprint}"
        repository = rpm_repository_factory(
            package_signing_service=rpm_package_signing_service.pulp_href,
            package_signing_fingerprint=prefixed_fingerprint,
        )
        upload_response = rpm_package_api.create(
            file=str(file_to_upload.absolute()),
            repository=repository.pulp_href,
        )
        package_href = monitor_task(upload_response.task).created_resources[2]
        package = rpm_package_api.read(package_href)
        assert package.signing_keys == [prefixed_fingerprint]

        # Verify that the final served package is signed
        publication = rpm_publication_factory(repository=repository.pulp_href)
        distribution = rpm_distribution_factory(publication=publication.pulp_href)
        downloaded_package = tmp_path / "package.rpm"
        downloaded_package.write_bytes(
            download_content_unit(
                distribution.base_path, get_package_repo_path(package.location_href)
            )
        )
        assert rpm_tool.verify_signature(downloaded_package)

        # Verify signing_key filter
        repository = rpm_repository_api.read(repository.pulp_href)
        assert (
            rpm_package_api.list(
                repository_version=repository.latest_version_href, signing_key=prefixed_fingerprint
            ).count
            == 1
        )


@pytest.fixture
def pulpcore_chunked_file_factory(tmp_path):
    """Returns a function to create chunks from file to be uploaded."""

    def _create_chunks(upload_path, chunk_size=512):
        """Chunks file to be uploaded."""
        chunks = {"chunks": []}
        hasher = hashlib.new("sha256")
        start = 0
        with open(upload_path, "rb") as f:
            data = f.read()
        chunks["size"] = len(data)

        while start < len(data):
            content = data[start : start + chunk_size]
            chunk_file = tmp_path / str(uuid.uuid4())
            hasher.update(content)
            chunk_file.write_bytes(content)
            content_sha = hashlib.sha256(content).hexdigest()
            end = start + len(content) - 1
            chunks["chunks"].append(
                (str(chunk_file), f"bytes {start}-{end}/{chunks['size']}", content_sha)
            )
            start += len(content)
        chunks["digest"] = hasher.hexdigest()
        return chunks

    return _create_chunks


@pytest.fixture
def pulpcore_upload_chunks(
    pulpcore_bindings,
    gen_object_with_cleanup,
    monitor_task,
):
    """Upload file in chunks."""

    def _upload_chunks(size, chunks, sha256, include_chunk_sha256=False):
        """
        Chunks is a list of tuples in the form of (chunk_filename, "bytes-ranges", optional_sha256).
        """
        upload = gen_object_with_cleanup(pulpcore_bindings.UploadsApi, {"size": size})

        for data in chunks:
            kwargs = {"file": data[0], "content_range": data[1], "upload_href": upload.pulp_href}
            if include_chunk_sha256:
                if len(data) != 3:
                    raise Exception(f"Chunk didn't include its sha256: {data}")
                kwargs["sha256"] = data[2]

            pulpcore_bindings.UploadsApi.update(**kwargs)

        return upload

    yield _upload_chunks


@pytest.mark.parallel
def test_sign_chunked_package_on_upload(
    tmp_path,
    pulpcore_bindings,
    monitor_task,
    gen_object_with_cleanup,
    download_content_unit,
    signing_gpg_extra,
    rpm_package_signing_service,
    rpm_package_api,
    rpm_repository_factory,
    rpm_publication_factory,
    rpm_package_factory,
    rpm_distribution_factory,
    pulpcore_upload_chunks,
    pulpcore_chunked_file_factory,
):
    """
    Sign an Rpm Package with the Package Upload endpoint.

    This ensures different
    """
    # Setup RPM tool and package to upload
    gpg_a, gpg_b = signing_gpg_extra
    fingerprint_set = set([gpg_a.fingerprint, gpg_b.fingerprint])
    assert len(fingerprint_set) == 2

    rpm_tool = RpmTool(tmp_path)
    rpm_tool.import_pubkey_string(gpg_a.pubkey)
    rpm_tool.import_pubkey_string(gpg_b.pubkey)

    file_to_upload = tmp_path / RPM_PACKAGE_FILENAME2
    file_to_upload.write_bytes(requests.get(RPM_UNSIGNED_URL2).content)
    with pytest.raises(InvalidSignatureError, match="The package is not signed: .*"):
        rpm_tool.verify_signature(file_to_upload)

    # Upload Package to Repository
    # The same file is uploaded, but signed with different keys each time
    for fingerprint in fingerprint_set:
        prefixed_fingerprint = f"v4:{fingerprint}"
        repository = rpm_repository_factory(
            package_signing_service=rpm_package_signing_service.pulp_href,
            package_signing_fingerprint=prefixed_fingerprint,
        )
        file_chunks_data = pulpcore_chunked_file_factory(file_to_upload)
        size = file_chunks_data["size"]
        chunks = file_chunks_data["chunks"]
        sha256 = file_chunks_data["digest"]

        upload = pulpcore_upload_chunks(size, chunks, sha256, include_chunk_sha256=True)
        upload_response = rpm_package_api.create(
            upload=upload.pulp_href,
            repository=repository.pulp_href,
        )
        package_href = monitor_task(upload_response.task).created_resources[2]
        package = rpm_package_api.read(package_href)
        assert package.signing_keys == [prefixed_fingerprint]

        # Verify that the final served package is signed
        publication = rpm_publication_factory(repository=repository.pulp_href)
        distribution = rpm_distribution_factory(publication=publication.pulp_href)
        downloaded_package = tmp_path / "package.rpm"
        downloaded_package.write_bytes(
            download_content_unit(
                distribution.base_path, get_package_repo_path(package.location_href)
            )
        )
        assert rpm_tool.verify_signature(downloaded_package)


def test_signed_repo_modify(
    tmp_path,
    delete_orphans_pre,
    monitor_task,
    download_content_unit,
    signing_gpg_metadata,
    rpm_package_signing_service,
    rpm_repository_factory,
    rpm_repository_api,
    rpm_package_factory,
    rpm_package_api,
    rpm_publication_factory,
    rpm_distribution_factory,
):
    """Ensure packages added via modify are signed before distribution."""

    gpg, fingerprint, _ = signing_gpg_metadata
    prefixed_fingerprint = f"v4:{fingerprint}"

    rpm_tool = RpmTool(tmp_path)
    rpm_tool.import_pubkey_string(gpg.export_keys(fingerprint))

    # Confirm the fixture RPM is initially unsigned.
    unsigned_package = tmp_path / RPM_PACKAGE_FILENAME
    unsigned_package.write_bytes(requests.get(RPM_UNSIGNED_URL).content)
    with pytest.raises(InvalidSignatureError, match="The package is not signed: .*"):
        rpm_tool.verify_signature(unsigned_package)

    repository = rpm_repository_factory(
        package_signing_service=rpm_package_signing_service.pulp_href,
        package_signing_fingerprint=prefixed_fingerprint,
    )

    created_package = rpm_package_factory(url=RPM_UNSIGNED_URL)
    assert created_package.signing_keys is None
    package_href = created_package.pulp_href
    modify_response = rpm_repository_api.modify(
        repository.pulp_href, {"add_content_units": [package_href]}
    )
    task_result = monitor_task(modify_response.task)

    repository = rpm_repository_api.read(repository.pulp_href)
    signed_package = rpm_package_api.list(
        repository_version=repository.latest_version_href
    ).results[0]
    assert signed_package.pulp_href != created_package.pulp_href
    assert signed_package.signing_keys == [prefixed_fingerprint]
    assert signed_package.time_file != created_package.time_file
    assert sorted(task_result.created_resources) == sorted(
        [repository.latest_version_href, signed_package.pulp_href, signed_package.artifact]
    )

    publication = rpm_publication_factory(repository=repository.pulp_href)
    distribution = rpm_distribution_factory(publication=publication.pulp_href)

    pkg_location_href = rpm_package_api.read(package_href).location_href
    downloaded_package = tmp_path / "modify-package.rpm"
    downloaded_package.write_bytes(
        download_content_unit(distribution.base_path, get_package_repo_path(pkg_location_href))
    )

    assert rpm_tool.verify_signature(downloaded_package)

    # attempt to add the package to the repository a second time (should produce same package href)
    modify_response = rpm_repository_api.modify(
        repository.pulp_href, {"add_content_units": [package_href]}
    )
    task_result = monitor_task(modify_response.task)

    repository = rpm_repository_api.read(repository.pulp_href)
    results = rpm_package_api.list(repository_version=repository.latest_version_href).results

    assert [signed_package.pulp_href] == [pkg.pulp_href for pkg in results]
    assert task_result.created_resources == []


def test_already_signed_package(
    delete_orphans_pre,
    monitor_task,
    signing_gpg_metadata,
    rpm_package_signing_service,
    rpm_repository_factory,
    rpm_repository_api,
    rpm_package_factory,
    rpm_package_api,
):
    """Don't sign a package if it's already signed with our key."""

    _, fingerprint, _ = signing_gpg_metadata
    prefixed_fingerprint = f"v4:{fingerprint}"

    repo_one = rpm_repository_factory(
        package_signing_service=rpm_package_signing_service.pulp_href,
        package_signing_fingerprint=prefixed_fingerprint,
    )
    repo_two = rpm_repository_factory(
        package_signing_service=rpm_package_signing_service.pulp_href,
        package_signing_fingerprint=prefixed_fingerprint,
    )

    created_package = rpm_package_factory(url=RPM_UNSIGNED_URL)
    package_href = created_package.pulp_href

    first_modify = rpm_repository_api.modify(
        repo_one.pulp_href,
        {"add_content_units": [package_href]},
    )
    task_result = monitor_task(first_modify.task)

    repo_one = rpm_repository_api.read(repo_one.pulp_href)
    repo_one_packages = rpm_package_api.list(
        repository_version=repo_one.latest_version_href
    ).results
    signed_package_href = repo_one_packages[0].pulp_href
    assert repo_one_packages[0].signing_keys == [prefixed_fingerprint]
    assert len(repo_one_packages) == 1
    assert sorted(task_result.created_resources) == sorted(
        [signed_package_href, repo_one_packages[0].artifact, repo_one.latest_version_href]
    )

    second_modify = rpm_repository_api.modify(
        repo_two.pulp_href,
        {"add_content_units": [signed_package_href]},
    )
    task_result = monitor_task(second_modify.task)

    repo_two = rpm_repository_api.read(repo_two.pulp_href)
    repo_two_packages = rpm_package_api.list(
        repository_version=repo_two.latest_version_href
    ).results
    assert len(repo_two_packages) == 1

    # The same signed package should be reused between repositories
    assert repo_two_packages[0].pulp_href == signed_package_href
    assert task_result.created_resources == [repo_two.latest_version_href]


def test_signed_repo_rejects_on_demand_content(
    init_and_sync,
    rpm_package_signing_service,
    signing_gpg_metadata,
    rpm_repository_factory,
    rpm_repository_api,
    rpm_package_api,
):
    """Ensure modify rejects on-demand content when signing is enabled."""
    source_repo, _ = init_and_sync(policy="on_demand")
    _, fingerprint, _ = signing_gpg_metadata
    destination_repo = rpm_repository_factory(
        package_signing_service=rpm_package_signing_service.pulp_href,
        package_signing_fingerprint=f"v4:{fingerprint}",
    )

    packages = rpm_package_api.list(repository_version=source_repo.latest_version_href).results
    package_href = packages[0].pulp_href

    with pytest.raises(ApiException) as exc:
        rpm_repository_api.modify(
            destination_repo.pulp_href,
            {"add_content_units": [package_href]},
        )

    assert "Cannot add on-demand packages" in exc.value.body
