"""Thread-safe utilities for concurrent execution with isolated logging."""

import contextlib
import io
import os
import sys
import threading
from pathlib import Path
from typing import Generator, TextIO, Type

from typing_extensions import override

from fused._udf.state import StdStreamProxy


class SyncingFileWrapper:
    """
    File wrapper that flushes and fsyncs on newlines.

    This ensures real-time visibility on network filesystems like EFS.
    """

    def __init__(self, file: TextIO) -> None:
        self._file = file

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def write(self, text: str) -> int:
        res = self._file.write(text)
        if "\n" in text:
            self.flush()
        return res

    def flush(self) -> None:
        self._file.flush()
        try:
            os.fsync(self._file.fileno())
        except (AttributeError, io.UnsupportedOperation, OSError):
            pass

    def close(self) -> None:
        self._file.close()

    def fileno(self) -> int:
        return self._file.fileno()


class MultipleTextIO:
    _outputs: list[TextIO]

    def __init__(self, *args: list[TextIO]) -> None:
        self._outputs = args

    def write(self, *args, **kwargs) -> int:
        res: int = 0
        for out in self._outputs:
            res = out.write(*args, **kwargs)
        return res

    def flush(self, *args, **kwargs):
        res = None
        for out in self._outputs:
            res = out.flush(*args, **kwargs)
        return res

    def getvalue(self) -> str:
        for out in self._outputs:
            if isinstance(out, io.StringIO):
                return out.getvalue()
        return ""

    def isatty(self) -> bool:
        return False

    @property
    def ranges(self) -> list[tuple[int, int, int]]:
        for out in self._outputs:
            if hasattr(out, "ranges"):
                return out.ranges
        raise AttributeError("Ranges not found")

    def fileno(self) -> int:
        """Return the file descriptor from the first output that supports it."""
        for out in self._outputs:
            try:
                if hasattr(out, "fileno"):
                    return out.fileno()
            except (AttributeError, io.UnsupportedOperation):
                continue
        # If none of the outputs support fileno, raise proper exception
        raise io.UnsupportedOperation("fileno() not supported on any underlying stream")


class ThreadLocalStreamRouter(TextIO):
    """
    A file-like object that routes writes to thread-local buffers.

    This is used for concurrent UDF execution where each thread
    needs isolated stdout/stderr. It's installed globally as sys.stdout/sys.stderr
    and routes writes based on the calling thread's ID.

    Architecture:
    - Parent thread installs this router globally
    - Each worker thread registers its own buffer (stored in thread-local storage)
    - Writes from threads with registered buffers are routed to their buffer
    - Writes from threads without registered buffers fall back to the original stream
    """

    def __init__(self, original_stream: TextIO):
        self.original_stream = original_stream
        self._thread_local = threading.local()

    def _get_buffer(self) -> TextIO:
        buffer = getattr(self._thread_local, "buffer", None)
        if buffer is None:
            # Fall back to original stream for threads without registered buffers
            # (e.g., main thread or threads that don't need isolation)
            return self.original_stream
        return buffer

    def register_buffer_for_current_thread(self, buffer: TextIO):
        """Register a buffer for the current thread."""
        self._thread_local.buffer = buffer

    def unregister_buffer_for_current_thread(self):
        """Unregister the current thread's buffer."""
        if hasattr(self._thread_local, "buffer"):
            delattr(self._thread_local, "buffer")

    @override
    def write(self, text: str) -> int:
        """Write to the appropriate buffer based on current thread."""
        buffer = self._get_buffer()
        return buffer.write(text)

    @override
    def flush(self) -> None:
        """Flush current thread's buffer."""
        buffer = self._get_buffer()
        buffer.flush()

    @override
    def isatty(self) -> bool:
        return False

    @override
    def close(self) -> None:
        # prevent closing the underlying stream
        self.flush()

    @override
    def writable(self) -> bool:
        return True

    @override
    def readable(self) -> bool:
        return False

    @override
    def fileno(self) -> int:
        """Return the file descriptor of the original stream."""
        try:
            return self.original_stream.fileno()
        except (AttributeError, io.UnsupportedOperation):
            # Raise proper exception instead of returning None
            # This allows multiprocessing to catch and handle it correctly
            raise io.UnsupportedOperation("fileno() not supported on underlying stream")


@contextlib.contextmanager
def isolate_streams_per_thread() -> Generator[
    tuple[ThreadLocalStreamRouter, ThreadLocalStreamRouter], None, None
]:
    """
    Context manager that sets up thread-local stream routing globally.

    If routers are already installed (e.g., from a parent thread pool), this will
    reuse them instead of creating new ones. This allows nested usage without conflicts.
    """
    # Check if routers are already installed
    if isinstance(sys.stdout, ThreadLocalStreamRouter) and isinstance(
        sys.stderr, ThreadLocalStreamRouter
    ):
        # Reuse existing routers - no need to install/restore
        yield sys.stdout, sys.stderr
    else:
        # Install new routers
        original_stdout = sys.stdout
        original_stderr = sys.stderr

        stdout_router = ThreadLocalStreamRouter(original_stdout)
        stderr_router = ThreadLocalStreamRouter(original_stderr)

        # Install globally
        sys.stdout = stdout_router
        sys.stderr = stderr_router

        try:
            yield stdout_router, stderr_router
        finally:
            # Restore original streams
            sys.stdout = original_stdout
            sys.stderr = original_stderr


@contextlib.contextmanager
def capture_current_thread_output(
    output_to_original_streams: bool = False,
    impl_class: Type[TextIO] = io.StringIO,
    log_dir: Path | None = None,
):
    """
    Context manager for worker threads to capture their own stdout/stderr.

    This should be used within a worker thread when isolate_streams_per_thread()
    is active in the parent.

    Args:
        output_to_original_streams: If True, also write to the original stdout/stderr
        impl_class: The class to use for the output buffers (default: io.StringIO)
        log_dir: If provided, logs will be streamed to files in this directory
                 (stdout, stderr files will be created). The directory will be
                 created if it doesn't exist.

    Usage:
        with capture_current_thread_output() as (out_buf, err_buf):
            # Do work
            print("This goes to out_buf")

            # Logs are automatically captured
            logs = out_buf.getvalue()

        # With disk logging:
        with capture_current_thread_output(log_dir=Path("/mount/logs/run123")) as (out_buf, err_buf):
            print("This streams to both memory and disk")

    Returns:
        Tuple of (stdout_buffer, stderr_buffer) as StringIO objects
    """

    # Ensure routers are installed
    stdout_router = sys.stdout
    stderr_router = sys.stderr
    if not isinstance(stdout_router, ThreadLocalStreamRouter) or not isinstance(
        stderr_router, ThreadLocalStreamRouter
    ):
        raise ValueError(
            "capture_current_thread_output() must be used in the worker thread after isolate_streams_per_thread()"
        )
    # Save previous buffers to support nested execution
    prev_stdout_buf = getattr(stdout_router._thread_local, "buffer", None)
    prev_stderr_buf = getattr(stderr_router._thread_local, "buffer", None)

    with contextlib.ExitStack() as stack:
        # Open disk log files if log_dir is provided
        stdout_file = None
        stderr_file = None
        if log_dir is not None:
            # Directory should already exist and be verified writeable by caller,
            # but ensure it exists as a safety measure
            log_dir.mkdir(parents=True, exist_ok=True)
            # Wrap with SyncingFileWrapper for real-time visibility on EFS
            stdout_file = stack.enter_context(
                SyncingFileWrapper(open(log_dir / "stdout.log", "w", buffering=1))
            )
            stderr_file = stack.enter_context(
                SyncingFileWrapper(open(log_dir / "stderr.log", "w", buffering=1))
            )

        out_buf = stack.enter_context(impl_class())
        err_buf = stack.enter_context(impl_class())

        # Build list of outputs for MultipleTextIO
        stdout_outputs = [out_buf]
        stderr_outputs = [err_buf]

        # Add disk file outputs if enabled
        if stdout_file is not None:
            stdout_outputs.append(stdout_file)
        if stderr_file is not None:
            stderr_outputs.append(stderr_file)

        # Add original stream outputs if enabled
        if output_to_original_streams:
            stdout_outputs.append(stdout_router.original_stream)
            stderr_outputs.append(stderr_router.original_stream)

        # Wrap with MultipleTextIO if we have multiple outputs
        if len(stdout_outputs) > 1:
            out_buf = MultipleTextIO(*stdout_outputs)
        if len(stderr_outputs) > 1:
            err_buf = MultipleTextIO(*stderr_outputs)

        # Register buffers for current thread (no thread_id needed!)
        stdout_router.register_buffer_for_current_thread(out_buf)
        stderr_router.register_buffer_for_current_thread(err_buf)

        try:
            with (
                # ensure that the standard streams are not closed by the UDF code
                StdStreamProxy("stdin"),
                StdStreamProxy("__stdin__"),
                StdStreamProxy("__stdout__"),
                StdStreamProxy("__stderr__"),
            ):
                yield out_buf, err_buf
        finally:
            # Restore previous buffers (or unregister if there were none)
            if prev_stdout_buf is not None:
                stdout_router.register_buffer_for_current_thread(prev_stdout_buf)
            else:
                stdout_router.unregister_buffer_for_current_thread()

            if prev_stderr_buf is not None:
                stderr_router.register_buffer_for_current_thread(prev_stderr_buf)
            else:
                stderr_router.unregister_buffer_for_current_thread()
