from datetime import datetime
from enum import Enum

from pydantic import BaseModel


class AccessScope(str, Enum):
    public = "public"
    team = "team"


class Collection(BaseModel):
    id: str
    name: str
    access_scope: AccessScope = AccessScope.team
    last_updated: datetime
    allow_public_read: bool
    dashboard_body: str | None = None
    share_token: str | None = None
    share_client_id: str | None = None
    #: Set when the server returns it (e.g. authenticated collection fetch).
    passcode: str | None = None


class SessionToken(BaseModel):
    session_token: str
    expires_at: datetime
