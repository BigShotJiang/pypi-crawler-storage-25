from typing import Literal

from fused.models.request import WHITELISTED_INSTANCE_TYPES

ENGINE_LOCAL = "local"
ENGINE_REMOTE = "remote"
Engine = Literal[ENGINE_LOCAL, ENGINE_REMOTE, WHITELISTED_INSTANCE_TYPES]
