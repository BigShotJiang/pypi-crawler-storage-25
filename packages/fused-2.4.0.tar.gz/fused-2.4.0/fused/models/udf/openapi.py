"""Generate OpenAPI 3.0.3 schemas from collections of Udf objects.

Usage::

    from fused.models.udf.openapi import generate_openapi_schema, openapi_schema_from_collection

    # From a list of Udf objects:
    schema = generate_openapi_schema(udfs, base_url="https://api.example.com")

    # From a canvas collection by name (requires authentication):
    schema = openapi_schema_from_collection("my_canvas")

    # By collection ID:
    schema = openapi_schema_from_collection(collection_id="col_abc123")
"""

from __future__ import annotations

import ast
import warnings
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from fused._global_api import get_api
from fused._options import options as _options
from fused.models.api.collection import AccessScope, Collection
from fused.models.udf.base_udf import METADATA_FUSED_IS_VISIBLE

if TYPE_CHECKING:
    from fused.models.udf.udf import Udf

# Sentinel for "no default value present"
_MISSING = object()

# Annotation strings that map to GeoDataFrame / spatial types (passed as JSON/WKT strings)
_GEODATAFRAME_ANNOTATIONS = frozenset(
    {
        "GeoDataFrame",
        "gpd.GeoDataFrame",
        "geopandas.GeoDataFrame",
    }
)
_DATAFRAME_ANNOTATIONS = frozenset(
    {
        "DataFrame",
        "pd.DataFrame",
        "pandas.DataFrame",
    }
)
_BBOX_LIKE_ANNOTATIONS = frozenset(
    {
        "Bbox",
        "Bounds",
        "Tile",
        "TileGDF",
        "TileXYZ",
        "ViewportGDF",
        "fused.types.Bbox",
        "fused.types.Bounds",
        "fused.types.Tile",
        "fused.types.TileGDF",
        "fused.types.TileXYZ",
        "fused.types.ViewportGDF",
    }
)
_GEOMETRY_ANNOTATIONS = frozenset(
    {
        "Geometry",
        "shapely.Geometry",
        "shapely.geometry.base.BaseGeometry",
    }
)


_STANDARD_PARAMETER_DEFINITIONS: dict = {
    "cache_max_age": {
        "name": "cache_max_age",
        "in": "query",
        "required": False,
        "description": (
            "Cache TTL in seconds. Overrides the UDF's default cache_max_age. "
            "Pass 0 to disable caching."
        ),
        "schema": {"type": "integer"},
    },
    "format": {
        "name": "format",
        "in": "query",
        "required": False,
        "description": "Output format for the UDF result.",
        "schema": {
            "type": "string",
            "default": "json",
            "enum": [
                "parquet",
                "json",
                "feather",
                "csv",
                "geojson",
                "mvt",
                "html",
                "excel",
                "xml",
                "png",
                "gif",
                "jpeg",
                "apng",
                "webp",
                "svg",
                "tiff",
                "npy",
            ],
        },
    },
}

# $ref entries used inside each operation's parameters list
_STANDARD_PARAMETER_REFS: list[dict] = [
    {"$ref": f"#/components/parameters/{name}"}
    for name in _STANDARD_PARAMETER_DEFINITIONS
]

_FUSED_SESSION_TOKEN_SCHEME: dict = {
    "type": "apiKey",
    "in": "query",
    "name": "fused_session_token",
    "description": (
        "Canvas-level session token. Authorises access to all UDFs in the collection."
    ),
}

_CANVAS_PASSCODE_SCHEME: dict = {
    "type": "apiKey",
    "in": "header",
    "name": "Authorization",
    "description": (
        "Canvas passcode sent as: Authorization: Fused-Canvas-Passcode <passcode>"
    ),
}


def _security_for_openapi(
    include_session_token: bool,
    include_canvas_passcode: bool,
) -> tuple[dict, list[dict]]:
    """Build components.securitySchemes and top-level security for the document.

    Team-scoped collections use the session token; passcode (if set) is an
    alternative credential. Public collections omit the session token scheme;
    if they have no passcode, the document has no security requirement.
    """
    schemes: dict = {}
    requirement: list[dict] = []
    if include_session_token:
        schemes["fused_session_token"] = _FUSED_SESSION_TOKEN_SCHEME
        requirement.append({"fused_session_token": []})
    if include_canvas_passcode:
        schemes["canvas_passcode"] = _CANVAS_PASSCODE_SCHEME
        requirement.append({"canvas_passcode": []})
    return schemes, requirement


@dataclass
class _ParamInfo:
    name: str
    schema: dict = field(default_factory=lambda: {"type": "string"})
    required: bool = True
    default: Any = _MISSING


def _annotation_node_to_json_schema(node: ast.expr | None) -> tuple[dict, bool]:
    """Convert an AST annotation node to a JSON Schema dict.

    Returns:
        (schema_dict, is_optional) where is_optional means the type includes None
        (i.e. Optional[X] or X | None).
    """
    if node is None:
        return {"type": "string"}, False

    annotation_str = ast.unparse(node)
    return _annotation_str_to_json_schema(annotation_str)


def _annotation_str_to_json_schema(annotation_str: str) -> tuple[dict, bool]:
    """Convert an annotation string to a JSON Schema dict.

    Returns:
        (schema_dict, is_optional)
    """
    s = annotation_str.strip()

    # --- Optional / Union with None ---
    # Handle: Optional[X], X | None, None | X
    if s.startswith("Optional[") and s.endswith("]"):
        inner = s[len("Optional[") : -1]
        schema, _ = _annotation_str_to_json_schema(inner)
        return schema, True

    # Handle X | None or None | X (Python 3.10+ union syntax)
    if "|" in s:
        parts = [p.strip() for p in s.split("|")]
        none_parts = [p for p in parts if p == "None"]
        non_none = [p for p in parts if p != "None"]
        if none_parts and len(non_none) == 1:
            schema, _ = _annotation_str_to_json_schema(non_none[0])
            return schema, True
        # Multi-type union (not just optional): fall through to string fallback
        return {"type": "string"}, bool(none_parts)

    # --- Primitive types ---
    if s == "str":
        return {"type": "string"}, False
    if s == "int":
        return {"type": "integer"}, False
    if s == "float":
        return {"type": "number"}, False
    if s == "bool":
        return {"type": "boolean"}, False

    # --- Container types ---
    if s in ("list", "List") or s.startswith("List[") or s.startswith("list["):
        return {"type": "array"}, False
    if s in ("dict", "Dict") or s.startswith("Dict[") or s.startswith("dict["):
        return {"type": "object"}, False
    if s in ("tuple", "Tuple") or s.startswith("Tuple[") or s.startswith("tuple["):
        return {"type": "array"}, False
    if s in ("set", "Set") or s.startswith("Set[") or s.startswith("set["):
        return {"type": "array"}, False

    # --- datetime / time types ---
    if s in ("datetime.datetime", "datetime"):
        return {"type": "string", "format": "date-time"}, False
    if s == "datetime.date":
        return {"type": "string", "format": "date"}, False
    if s == "datetime.time":
        return {"type": "string", "format": "time"}, False

    # --- UUID ---
    if s in ("uuid.UUID", "UUID"):
        return {"type": "string", "format": "uuid"}, False

    # --- Geospatial / Fused-specific types ---
    if s in _GEODATAFRAME_ANNOTATIONS:
        return {
            "type": "string",
            "description": "GeoJSON string or bounding box",
        }, False
    if s in _DATAFRAME_ANNOTATIONS:
        return {"type": "string", "description": "JSON-encoded DataFrame"}, False
    if s in _BBOX_LIKE_ANNOTATIONS:
        return {
            "type": "string",
            "description": "Bounding box as JSON array [xmin, ymin, xmax, ymax]",
        }, False
    if s in _GEOMETRY_ANNOTATIONS:
        return {
            "type": "string",
            "description": "WKT or GeoJSON geometry string",
        }, False

    # --- Fallback ---
    return {"type": "string"}, False


def _default_node_to_python(node: ast.expr) -> Any:
    """Convert an AST default value node to a Python literal.

    Returns _MISSING if the node cannot be represented as a JSON-serialisable literal.
    """
    try:
        val = ast.literal_eval(node)
        # Ensure JSON-serialisable (no sets, complex numbers, etc.)
        if isinstance(val, (str, int, float, bool, type(None), list, dict, tuple)):
            # Tuples are not valid JSON; convert to list
            if isinstance(val, tuple):
                return list(val)
            return val
    except (ValueError, TypeError):
        pass
    return _MISSING


def _extract_udf_params(code: str, entrypoint: str) -> list[_ParamInfo]:
    """Parse the UDF source code and return parameter info for the entrypoint function.

    Skips ``*args`` and ``**kwargs`` parameters.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError:
        try:
            tree = ast.parse(repr(code))
        except SyntaxError:
            return []

    for node in ast.walk(tree):
        if (
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name == entrypoint
        ):
            args = node.args
            all_args = args.args  # positional-or-keyword args
            defaults = args.defaults  # right-aligned

            # Align defaults with args (defaults cover the *last* N args)
            num_args = len(all_args)
            num_defaults = len(defaults)
            # Pad with _MISSING sentinel so zip works cleanly
            padded_defaults: list[Any] = [_MISSING] * (num_args - num_defaults) + list(
                defaults
            )

            params: list[_ParamInfo] = []
            for arg, default_node in zip(all_args, padded_defaults):
                schema, is_optional = _annotation_node_to_json_schema(arg.annotation)

                if default_node is _MISSING:
                    default_val = _MISSING
                    required = not is_optional
                else:
                    default_val = _default_node_to_python(default_node)
                    required = False

                params.append(
                    _ParamInfo(
                        name=arg.arg,
                        schema=schema,
                        required=required,
                        default=default_val,
                    )
                )

            # Also include keyword-only args (after *)
            kw_defaults = args.kw_defaults  # parallel list, None where no default
            for arg, default_node in zip(args.kwonlyargs, kw_defaults):
                schema, is_optional = _annotation_node_to_json_schema(arg.annotation)

                if default_node is None:
                    default_val = _MISSING
                    required = not is_optional
                else:
                    default_val = _default_node_to_python(default_node)
                    required = False

                params.append(
                    _ParamInfo(
                        name=arg.arg,
                        schema=schema,
                        required=required,
                        default=default_val,
                    )
                )

            return params

    return []


def _extract_entrypoint_docstring(code: str, entrypoint: str) -> str | None:
    """Return the entrypoint function's docstring, if present."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        try:
            tree = ast.parse(repr(code))
        except SyntaxError:
            return None

    for node in ast.walk(tree):
        if (
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name == entrypoint
        ):
            doc = ast.get_docstring(node)
            if not doc:
                return None
            stripped = doc.strip()
            return stripped or None

    return None


def _is_udf_decorator_func(func: ast.expr) -> bool:
    """True if *func* is the callable in ``@udf`` / ``@fused.udf`` / ``@pkg.udf``."""
    if isinstance(func, ast.Name):
        return func.id == "udf"
    if isinstance(func, ast.Attribute):
        return func.attr == "udf"
    return False


def _entrypoint_decorator_specifies_engine(code: str, entrypoint: str) -> bool:
    """True if the entrypoint function's source has ``@...udf(..., engine= / instance_type=)``."""
    try:
        tree = ast.parse(code)
    except SyntaxError:
        try:
            tree = ast.parse(repr(code))
        except SyntaxError:
            return False

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if node.name != entrypoint:
            continue
        for dec in node.decorator_list:
            if not isinstance(dec, ast.Call):
                continue
            if not _is_udf_decorator_func(dec.func):
                continue
            for kw in dec.keywords:
                if kw.arg in ("engine", "instance_type"):
                    return True
        return False

    return False


def _build_openapi_parameter(param: _ParamInfo) -> dict:
    """Build a single OpenAPI parameter object for a query parameter."""
    schema = dict(param.schema)  # shallow copy
    if param.default is not _MISSING:
        schema["default"] = param.default

    return {
        "name": param.name,
        "in": "query",
        "required": param.required,
        "schema": schema,
    }


def generate_openapi_schema(
    udfs: list[Udf],
    base_url: str,
    title: str = "UDF API",
    version: str = "1.0.0",
    *,
    include_session_token_security: bool = True,
    include_canvas_passcode_security: bool = False,
    include_non_visible_udfs: bool = False,
) -> dict:
    """Generate a valid OpenAPI 3.0.3 schema for a collection of UDFs.

    Each UDF becomes a ``GET`` endpoint named after the UDF.  The UDF's
    entrypoint function parameters are exposed as query parameters, with
    Python type annotations mapped to JSON Schema types and default values
    preserved.

    Args:
        udfs: Collection of :class:`~fused.models.udf.Udf` objects to document.
        base_url: The base URL of the API (e.g. ``"https://api.example.com"``).
        title: Title for the ``info`` section of the schema. Defaults to ``"UDF API"``.
        version: API version string. Defaults to ``"1.0.0"``.
        include_session_token_security: If True, document the fused session token
            query parameter. Use for team-scoped collections; omit for ``public``.
        include_canvas_passcode_security: If True, add the canvas passcode security
            scheme and requirement. Use when the canvas has a passcode set.
        include_non_visible_udfs: If True, include UDFs that are not visible in the canvas.

    Returns:
        A dict representing a valid OpenAPI 3.0.3 document.

    Example::

        import fused
        from fused.models.udf.openapi import generate_openapi_schema

        @fused.udf
        def my_udf(bbox, x: int = 5, label: str = "hello"):
            return None

        schema = generate_openapi_schema([my_udf], base_url="https://api.example.com")
    """
    paths: dict[str, dict] = {}
    seen_paths: dict[str, int] = {}

    filtered_udfs = [
        udf
        for udf in udfs
        if _include_udf_in_openapi_schema(udf, include_non_visible_udfs)
    ]
    for udf in filtered_udfs:
        udf_name = udf.name or udf.entrypoint
        if not udf_name:
            warnings.warn(
                f"Skipping a UDF with no name and no entrypoint: {udf!r}",
                stacklevel=2,
            )
            continue

        if (
            udf.entrypoint
            and udf.code
            and _entrypoint_decorator_specifies_engine(udf.code, udf.entrypoint)
        ):
            warnings.warn(
                f"Skipping UDF {udf_name!r}: OpenAPI share-run paths are not generated "
                "when the UDF source uses @fused.udf(...) with engine= or instance_type=.",
                stacklevel=2,
            )
            continue

        # De-duplicate path names
        path_key = f"/{udf_name}"
        if path_key in seen_paths:
            seen_paths[path_key] += 1
            path_key = f"/{udf_name}_{seen_paths[path_key]}"
        else:
            seen_paths[f"/{udf_name}"] = 1

        # Build operationId from path_key (strip leading slash, replace / with _)
        operation_id = "run_" + path_key.lstrip("/").replace("/", "_").replace("-", "_")

        # Description: fused:metadata first, else entrypoint docstring
        description: str | None = None
        if udf.metadata:
            description = udf.metadata.get("fused:description")
        if not description and udf.entrypoint and udf.code:
            description = _extract_entrypoint_docstring(udf.code, udf.entrypoint)

        # Parse parameters from the entrypoint function, then append standard ones
        openapi_parameters: list[dict] = []
        if udf.entrypoint and udf.code:
            param_infos = _extract_udf_params(udf.code, udf.entrypoint)
            for p in param_infos:
                openapi_parameters.append(_build_openapi_parameter(p))
        openapi_parameters.extend(_STANDARD_PARAMETER_REFS)

        operation: dict[str, Any] = {
            "operationId": operation_id,
            "summary": f"Run UDF: {udf_name}",
            "parameters": openapi_parameters,
            "responses": {
                "200": {"description": "Successful response"},
                "422": {"description": "Validation error"},
            },
        }
        if description:
            operation["description"] = description

        paths[path_key] = {"get": operation}

    security_schemes, security_requirement = _security_for_openapi(
        include_session_token_security,
        include_canvas_passcode_security,
    )

    return {
        "openapi": "3.0.3",
        "info": {
            "title": title,
            "version": version,
        },
        "servers": [{"url": base_url}],
        "security": security_requirement,
        "paths": paths,
        "components": {
            "parameters": _STANDARD_PARAMETER_DEFINITIONS,
            "securitySchemes": security_schemes,
        },
    }


def _is_runnable_udf(udf: Udf) -> bool:
    """Return False for canvas nodes that are not executable UDF endpoints.

    Node templates, frame nodes, and text editors are visual/structural canvas
    elements; they have no entrypoint to call and must be excluded from the
    OpenAPI schema.
    """
    metadata = udf.metadata or {}
    return not (
        metadata.get("isNodeTemplate")
        or metadata.get("nodeTemplateType")
        or metadata.get("frameType")
        or metadata.get("isTextEditor")
    )


def _include_udf_in_openapi_schema(
    udf: Udf, include_non_visible_udfs: bool = False
) -> bool:
    """True if this UDF should appear in a share-token OpenAPI document."""
    if not _is_runnable_udf(udf):
        return False
    if (
        not include_non_visible_udfs
        and udf._get_metadata_safe(METADATA_FUSED_IS_VISIBLE) is False
    ):
        return False
    if (
        udf.entrypoint
        and udf.code
        and _entrypoint_decorator_specifies_engine(udf.code, udf.entrypoint)
    ):
        return False
    return True


def openapi_schema_from_collection(
    collection_name: str | None = None,
    *,
    collection_id: str | None = None,
    title: str | None = None,
    version: str = "1.0.0",
) -> dict:
    """Generate a valid OpenAPI 3.0.3 schema for all UDFs in a canvas collection.

    Looks up the collection via the Fused API, derives the base URL from the
    collection's share token and the SDK's configured environment
    (e.g. ``https://udf.ai`` for production, ``https://unstable.udf.ai`` for
    unstable), then delegates to :func:`generate_openapi_schema`.

    Exactly one of ``collection_name`` or ``collection_id`` must be provided.

    Args:
        collection_name: The name of the collection (canvas) to generate a schema for.
        collection_id: The ID of the collection to generate a schema for.
        title: Title for the ``info`` section. Defaults to the collection name.
        version: API version string. Defaults to ``"1.0.0"``.

    Returns:
        A dict representing a valid OpenAPI 3.0.3 document.

    Raises:
        ValueError: If neither or both of ``collection_name``/``collection_id``
            are given, or if the collection has no share token.

    Example::

        from fused.models.udf.openapi import openapi_schema_from_collection

        schema = openapi_schema_from_collection("my_canvas")
        # or by ID:
        schema = openapi_schema_from_collection(collection_id="col_abc123")
    """
    if collection_name is None and collection_id is None:
        raise ValueError("Provide either 'collection_name' or 'collection_id'.")
    if collection_name is not None and collection_id is not None:
        raise ValueError(
            "Provide only one of 'collection_name' or 'collection_id', not both."
        )

    api = get_api()

    if collection_name is not None:
        raw = api._get_collection_by_name(collection_name)
        collection = Collection.model_validate(raw)
    else:
        collection = api.get_collection_by_id(collection_id)

    if not collection.share_token:
        raise ValueError(
            f"Collection '{collection.name}' has no share token. "
            "Share the collection first to obtain a token."
        )

    udf_registry = api.get_udfs(collection_name=collection.name)
    udfs = [udf for udf in udf_registry.values()]

    base_url = f"{_options.shared_udf_base_url}/{collection.share_token}"

    return generate_openapi_schema(
        udfs,
        base_url=base_url,
        title=title or collection.name,
        version=version,
        include_session_token_security=collection.access_scope == AccessScope.team,
        include_canvas_passcode_security=bool(collection.passcode),
    )
