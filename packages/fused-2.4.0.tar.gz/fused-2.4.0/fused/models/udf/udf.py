from __future__ import annotations

import ast
import re
import warnings
from datetime import timedelta
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    BinaryIO,
    Iterable,
    Literal,
    Sequence,
)

from pydantic import Field, PrivateAttr, RootModel, model_validator
from pydantic_core.core_schema import ValidationInfo
from typing_extensions import Annotated, Self, override

from fused.models.udf._engine import ENGINE_LOCAL, ENGINE_REMOTE, Engine
from fused.models.udf.base_udf import (
    METADATA_FUSED_ID,
    METADATA_FUSED_IS_VISIBLE,
    METADATA_FUSED_SLUG,
    BaseUdf,
    UdfType,
)
from fused.warnings import FusedUdfWarning

from .._inplace import _maybe_inplace

if TYPE_CHECKING:
    from fused._submit import JobPool
    from fused.models.api.job import UdfJobStepConfig
    from fused.models.udf._eval_result import UdfEvaluationResult


def _parse_cache_max_age(ttl: str | int | None, cache: bool = True) -> int | None:
    if ttl is None:
        if not cache:
            return 0
        return None
    elif not cache:
        raise ValueError("Cannot specify both `cache_max_age` and `cache=False`")

    if ttl == 0 or (isinstance(ttl, str) and ttl.strip() == "0"):
        return 0

    if isinstance(ttl, int):
        ttl = f"{ttl}s"

    quantifier = re.match(r"(\d+)([smhd])$", ttl.strip().lower())
    if not quantifier:
        raise ValueError(
            "Invalid `cache_max_age` parameter: Use a number followed by one of 's' (seconds), 'm' (minutes), 'h' (hours), or 'd' (days)."
        )

    value, unit = int(quantifier.group(1)), quantifier.group(2)
    delta_map = {
        "s": timedelta(seconds=value),
        "m": timedelta(minutes=value),
        "h": timedelta(hours=value),
        "d": timedelta(days=value),
    }
    return int(delta_map[unit].total_seconds())


class Udf(BaseUdf):
    """A user-defined function."""

    type: Literal[UdfType.GEOPANDAS_V2] = UdfType.GEOPANDAS_V2

    entrypoint: str
    """Name of the function within the code to invoke."""

    cache_max_age: int | None = None
    """The maximum age when returning a result from the cache."""

    engine: str | None = None
    """The engine to run this UDF on by default, if not specified in
    `fused.run()`, e.g., "small"/"medium"/"large".
    """
    disk_size_gb: int | None = None
    """The size of the disk in GB to use for remote execution.
    Used in batch jobs.
    """
    region: str | None = None
    """The region to use for remote execution. Used in batch jobs."""

    parameters: dict[str, Any] = Field(default_factory=dict)
    """Parameters to pass into the entrypoint."""

    _parameter_list: Sequence[str] | None = PrivateAttr(None)
    _parameter_has_kwargs: bool | None = PrivateAttr(None)
    original_headers: str | None = None
    """Deprecated."""

    _nested_callable = PrivateAttr(None)  # TODO : Find out type

    @model_validator(mode="after")
    # TODO: Maybe use this by default instead of _extract_parameter_list(inspect.signature) in _udf_internal?
    def _set_parameter_list(self, info: ValidationInfo) -> Self:
        load_parameter_list = (
            info.context["load_parameter_list"]
            if info.context and info.context.get("load_parameter_list") is not None
            else False
        )
        if load_parameter_list:
            params = self._detect_parameters(self.code)
            _parameter_list, _parameter_has_kwargs = params

            self._parameter_list = _parameter_list
            self._parameter_has_kwargs = _parameter_has_kwargs

        return self

    def _detect_parameters(self, src: str) -> tuple[list[str], bool]:
        # Originally from fused/_udf/load.py
        # Note: Removed default type parsing because using AST is high maintenance to cover all scenarios.

        try:
            parsed_ast = ast.parse(src)
        except SyntaxError:
            parsed_ast = ast.parse(repr(src))

        # Find and extract parameters
        params = []
        has_kwargs = False
        for node in ast.walk(parsed_ast):
            if (
                isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                and node.name == self.entrypoint
            ):
                for arg in node.args.args:
                    params.append(arg.arg)

                if node.args.kwarg:
                    has_kwargs = True
                break

        return params, has_kwargs

    @model_validator(mode="after")
    def _set_cache_max_age_from_code(self, info: ValidationInfo) -> Self:
        if self.cache_max_age is not None:
            return self

        cache_max_age = None
        if "cache_max_age" in self.code:
            try:
                tree = ast.parse(self.code)
                for node in ast.walk(tree):
                    if (
                        isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                        and node.name == self.entrypoint
                    ):
                        for decorator in node.decorator_list:
                            if isinstance(decorator, ast.Call):
                                for keyword in decorator.keywords:
                                    if keyword.arg == "cache_max_age":
                                        if isinstance(keyword.value, ast.Constant):
                                            cache_max_age = keyword.value.value
            except Exception:
                pass

        self.cache_max_age = _parse_cache_max_age(cache_max_age)
        return self

    def _with_udf_entrypoint(self) -> Self:
        """
        If the entrypoint is not "udf", replace it back to "udf" using AST manipulation.
        If a function named "udf" already exists, it will be renamed to "udf_updated".
        """
        target_new_name = "udf"
        if self.entrypoint == target_new_name:
            return self

        udf = self.model_copy()

        try:
            # Parse the code into an AST
            tree = ast.parse(udf.code, type_comments=True)

            # Rename existing udf -> udf_old
            visitor1 = RenameFunctionVisitor(
                old_name=target_new_name,
                new_name=f"{target_new_name}_old",
            )
            updated_tree = visitor1.visit(tree)

            # Rename the entrypoint -> udf
            visitor2 = RenameFunctionVisitor(
                old_name=self.entrypoint,
                new_name=target_new_name,
            )
            updated_tree = visitor2.visit(updated_tree)

            # Check if the original entrypoint function definition was found in the second pass
            if not visitor2.found_definition:
                raise ValueError(
                    f"Could not find the specified entrypoint function definition '{self.entrypoint}' in the UDF code."
                )

            # Ensure line numbers and column offsets are correct
            ast.fix_missing_locations(updated_tree)

            # Convert the potentially modified AST back to code
            udf.code = ast.unparse(updated_tree)
            udf.entrypoint = target_new_name

        except Exception as e:
            # Catch parsing, visiting, or unparsing errors
            raise RuntimeError(f"Failed to update entrypoint of UDF: {e}") from e

        return udf

    def set_parameters(
        self,
        parameters: dict[str, Any],
        replace_parameters: bool = False,
        inplace: bool = False,
    ) -> Udf:
        """Set the parameters on this UDF.

        Args:
            parameters: The new parameters dictionary.
            replace_parameters: If True, unset any parameters not in the parameters argument. Defaults to False.
            inplace: If True, modify this object. If False, return a new object. Defaults to True.

        Deprecated: Set parameters when calling the UDF or using `UDF.map()` instead.
        """
        ret = _maybe_inplace(self, inplace)
        new_parameters = (
            parameters
            if replace_parameters
            else {
                **ret.parameters,
                **parameters,
            }
        )
        ret.parameters = new_parameters
        return ret

    def eval_schema(self, inplace: bool = False) -> Udf:
        """Reload the schema saved in the code of the UDF.

        Note that this will evaluate the UDF function.

        Args:
            inplace: If True, update this UDF object. Otherwise return a new UDF object (default).

        Deprecated: Do not call this.
        """
        from fused._udf.execute_v2 import execute_for_decorator

        new_udf = execute_for_decorator(self)
        assert isinstance(new_udf, Udf), f"UDF has unexpected type: {type(new_udf)}"
        ret = _maybe_inplace(self, inplace)
        ret._parameter_list = new_udf._parameter_list
        ret._parameter_has_kwargs = new_udf._parameter_has_kwargs
        return ret

    def run_local(
        self,
        *,
        inplace: bool = False,
        **kwargs,
    ) -> UdfEvaluationResult:
        """Evaluate this UDF against a sample.

        Args:
            inplace: If True, update this UDF object with schema information. (default)

        Deprecated: Call the UDF instead.
        """
        from fused._udf.execute_v2 import execute_against_sample

        ret = _maybe_inplace(self, inplace)
        return execute_against_sample(
            udf=ret,
            input=[],
            **kwargs,
        )

    def to_file(self, where: str | Path | BinaryIO, *, overwrite: bool = False):
        """Write the UDF to disk or the specified file-like object.

        The UDF will be written as a Zip file.

        Args:
            where: A path to a file or a file-like object.

        Keyword Args:
            overwrite: If true, overwriting is allowed.
        """
        updated_udf = self._with_udf_entrypoint()
        job = updated_udf._to_job_step()
        job.export(where, how="zip", overwrite=overwrite)

    def to_directory(self, where: str | Path | None = None, *, overwrite: bool = False):
        """Write the UDF to disk as a directory (folder).

        Args:
            where: A path to a directory. If not provided, uses the UDF function name.

        Keyword Args:
            overwrite: If true, overwriting is allowed.
        """
        updated_udf = self._with_udf_entrypoint()
        job = updated_udf._to_job_step()
        where = where or self.name
        job.export(where, how="local", overwrite=overwrite)

    def _to_job_step(
        self, *, arg_list: Iterable[Any] | None = None, **kwargs
    ) -> UdfJobStepConfig:
        """Create a job from this UDF.

        Args:
            arg_list: A list of records to pass in to the UDF as input.
        """
        # cyclic dependency if imported at top-level
        from fused.models.api.job import UdfJobStepConfig

        with_params = self.model_copy()
        # TODO: Consider using with_parameters here, and validating that "context" and other reserved parameter names are not being passed.
        new_parameters = {**kwargs}
        if new_parameters:
            with_params.parameters = new_parameters

        if arg_list is not None and not len(arg_list):
            warnings.warn(
                FusedUdfWarning(
                    "An empty `arg_list` was passed in, no calls to the UDF will be made."
                )
            )

        return UdfJobStepConfig(
            udf=with_params,
            input=arg_list,
            name=self.name,
        )

    def __call__(
        self,
        *args,
        engine: Engine | None = None,
        cache_max_age: str | None = None,
        cache: bool = True,
        **kwargs,
    ):
        """Call this UDF.

        Args:
            *args: Positional arguments to pass to the UDF.
            engine: The engine to use for execution.
                "remote": Run remotely on a realtime instance. (Default)
                "local": Run locally.
                "small", "medium", "large": Run on a batch instance.
                Other values will be interpreted as a batch instance type.
            cache_max_age: The maximum age when returning a result from the cache.
                Supported units are seconds (s), minutes (m), hours (h), and days (d) (e.g. “48h”, “10s”, etc.).
                Default is `None` so a UDF will follow `cache_max_age` defined in `@fused.udf()` unless this value is changed.
            cache: Set to False as a shortcut for `cache_max_age='0s'` to disable caching. (Default True)
            verbose: Set to True to print stdout and stderr from the UDF execution.
            **kwargs: Keyword arguments to pass to the UDF.

        Returns:
            The result of the UDF execution.
        """
        from fused import run

        for arg_index, arg in enumerate(args):
            if not self._parameter_list:
                raise TypeError(
                    f"UDF {self.name} received {len(args)} positional arguments, but the UDF has no parameters"
                )
            elif arg_index >= len(self._parameter_list):
                raise TypeError(
                    f"UDF {self.name} has {len(self._parameter_list)} parameters, but got {len(args)} positional arguments"
                )
            elif self._parameter_list[arg_index] in kwargs:
                raise TypeError(
                    f"UDF {self.name} got multiple values for argument {self._parameter_list[arg_index]}"
                )
            else:
                kwargs[self._parameter_list[arg_index]] = arg

        instance_type = None
        if engine not in [ENGINE_LOCAL, ENGINE_REMOTE]:
            instance_type = engine
            engine = None

        return run(
            self,
            engine=engine,
            instance_type=instance_type,
            cache_max_age=cache_max_age,
            cache=cache,
            disk_size_gb=self.disk_size_gb,
            **kwargs,
        )

    def map(
        self,
        arg_list,
        *,
        engine: Engine | None = None,
        cache_max_age: str | None = None,
        max_workers: int | None = None,
        worker_concurrency: int | None = None,
        cache: bool = True,
        max_retry: int = 2,
    ) -> "JobPool":
        """Submit a job for each element in arg_list.

        Args:
            arg_list: A list of arguments to pass to the UDF. Each element
                in arg_list will become a job and run.
            engine: The engine to use for execution.
                "remote": Run on a realtime instance. (Default)
                "local": Run locally.
                "small", "medium", "large": Run on a batch instance.
                Other values will be interpreted as a batch instance type.
            max_workers: The maximum number of workers to use.
                For running on realtime instances, this is the number of
                instances to use. (Default 32)
                For running locally, this is the number of threads to use.
                (Default 1)
                For running on batch instances, this is the number of worker
                machines to use. (Default 1)
            worker_concurrency: The concurrency level for each worker.
                For running on realtime instances, this is the number of
                arguments to run in each instance at a time. (Default 1)
                For running locally, this cannot be set.
                For running on batch instances, this is the number of processes
                to use in each worker machine. (Default based on the number of
                cores in the machine.)
            cache_max_age: The maximum age when returning a result from the cache.
                Supported units are seconds (s), minutes (m), hours (h), and days (d) (e.g. “48h”, “10s”, etc.).
                Default is `None` so a UDF will follow `cache_max_age` defined in `@fused.udf()` unless this value is changed.
            cache: Set to False as a shortcut for `cache_max_age='0s'` to disable caching. (Default True)
            max_retry: The maximum number of retries for failed jobs. (Default 2)
                Note that retries will only be attempted if the object is waited on,
                e.g. with `pool.wait()`, `pool.tail()`, or `pool.df()`.

        Returns:
            A JobPool object. Call `.df()` to get the results.

        Example:
            >>> @fused.udf()
            ... def my_udf(x: int):
            ...     return x + 1
            ...
            >>> pool = my_udf.map([1, 2, 3])
            >>> results = pool.df()
            >>> print(results)
            [2, 3, 4]
        """
        from fused import submit

        instance_type = None
        if engine not in [ENGINE_LOCAL, ENGINE_REMOTE]:
            instance_type = engine
            engine = None

        return submit(
            self,
            arg_list,
            engine=engine,
            instance_type=instance_type,
            cache_max_age=cache_max_age,
            cache=cache,
            max_workers=max_workers,
            n_processes_per_worker=worker_concurrency,
            max_retry=max_retry,
            disk_size_gb=self.disk_size_gb,
            collect=False,
        )

    async def map_async(
        self,
        arg_list,
        *,
        engine: Engine | None = None,
        max_workers: int | None = None,
        cache_max_age: str | None = None,
        cache: bool = True,
        max_retry: int = 2,
    ) -> "JobPool":
        """Submit a job for each element in arg_list.

        Args:
            arg_list: A list of arguments to pass to the UDF. Each element
                in arg_list will become a job and run.
            engine: The engine to use for execution.
                "remote": Run on a realtime instance. (Default)
                "local": Run locally.
                Note: batch instance types are not supported for async map.
            max_workers: The maximum number of workers to use.
                For running on realtime instances, this is the number of
                instances to use. (Default 32)
                For running locally, this is the number of threads to use.
                (Default 1)
            cache_max_age: The maximum age when returning a result from the cache.
                Supported units are seconds (s), minutes (m), hours (h), and days (d) (e.g. “48h”, “10s”, etc.).
                Default is `None` so a UDF will follow `cache_max_age` defined in `@fused.udf()` unless this value is changed.
            cache: Set to False as a shortcut for `cache_max_age='0s'` to disable caching. (Default True)
            max_retry: The maximum number of retries for failed jobs. (Default 2)
                Note that retries will only be attempted if the object is waited on,
                e.g. with `pool.wait()`, `pool.tail()`, or `pool.df()`.

        Note worker_concurrency is not supported for async map.

        Returns:
            An AsyncJobPool object. Call `.df()` to get the results.

        Example:
            >>> @fused.udf()
            ... def my_udf(x: int):
            ...     return x + 1
            ...
            >>> pool = my_udf.map_async([1, 2, 3])
            >>> results = pool.df()
            >>> print(results)
            [2, 3, 4]
        """
        from fused import submit

        return submit(
            self,
            arg_list,
            engine=engine,
            cache_max_age=cache_max_age,
            cache=cache,
            max_workers=max_workers,
            max_retry=max_retry,
            collect=False,
            execution_type="async_loop",
        )


EMPTY_UDF = Udf(name="EMPTY_UDF", code="", entrypoint="")

AnyBaseUdf = Annotated[Udf, Field(..., discriminator="type")]


class RootAnyBaseUdf(RootModel[AnyBaseUdf]):
    pass


def load_udf_from_response_data(data: dict, context=None) -> RootAnyBaseUdf:
    """Return a UDF from an HTTP response body, adding in metadata if necessary"""

    if context is None:
        context = {}

    # Always generate parameter list during deserialization
    if "load_parameter_list" not in context:
        context["load_parameter_list"] = True

    udf = RootAnyBaseUdf.model_validate_json(data["udf_body"], context=context).root
    # Restore metadata fields if they were not already present
    if not udf._get_metadata_safe(METADATA_FUSED_ID) and "id" in data:
        udf._set_metadata_safe(METADATA_FUSED_ID, data["id"])
    if not udf._get_metadata_safe(METADATA_FUSED_SLUG) and "slug" in data:
        udf._set_metadata_safe(METADATA_FUSED_SLUG, data["slug"])
    if (
        udf._get_metadata_safe(METADATA_FUSED_IS_VISIBLE) is None
        and "is_visible" in data
    ):
        udf._set_metadata_safe(METADATA_FUSED_IS_VISIBLE, data["is_visible"])
    # Set collection-related fields as direct attributes (not in metadata)
    if "collection_id" in data and data["collection_id"] is not None:
        udf.collection_id = data["collection_id"]
    if "collection_name" in data and data["collection_name"] is not None:
        udf.collection_name = data["collection_name"]
    return udf


# Helper class for AST transformation
class RenameFunctionVisitor(ast.NodeTransformer):
    """
    AST visitor to rename a top level function definition AND its usages (ast.Name in calls/loads).
    """

    def __init__(self, old_name: str, new_name: str):
        super().__init__()
        self.old_name = old_name
        self.new_name = new_name
        self.found_definition = False  # Track if the definition was found

    @override
    def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.AST:
        if node.name == self.old_name:
            if self.found_definition:
                warnings.warn(
                    f"Found multiple definitions of entrypoint function '{self.old_name}'"
                )
            node.name = self.new_name
            self.found_definition = True
        # Continue visiting other nodes
        return self.generic_visit(node)

    @override
    def visit_Name(self, node: ast.Name) -> ast.AST:
        # Rename names used in a 'load' context (i.e., references/calls)
        if node.id == self.old_name and isinstance(node.ctx, ast.Load):
            node.id = self.new_name
        return node  # Return the node itself (potentially modified)
