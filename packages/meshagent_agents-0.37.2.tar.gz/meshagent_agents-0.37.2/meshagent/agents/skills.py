# Adapted from
# https://github.com/agentskills/agentskills/blob/main/skills-ref
# made async

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
import posixpath
from typing import Optional
import html
import logging
import aiofiles
import aiofiles.ospath
import strictyaml
from dataclasses import dataclass, field
import unicodedata

from meshagent.tools.storage import StorageToolLocalMount, StorageToolkit

logger = logging.getLogger(__name__)

type SkillLocationMapper = Callable[[Path], str]


@dataclass
class SkillProperties:
    """Properties parsed from a skill's SKILL.md frontmatter.

    Attributes:
        name: Skill name in kebab-case (required)
        description: What the skill does and when the model should use it (required)
        license: License for the skill (optional)
        compatibility: Compatibility information for the skill (optional)
        allowed_tools: FunctionTool patterns the skill requires (optional, experimental)
        metadata: Key-value pairs for client-specific properties (defaults to
            empty dict; omitted from to_dict() output when empty)
    """

    name: str
    description: str
    license: Optional[str] = None
    compatibility: Optional[str] = None
    allowed_tools: Optional[str] = None
    metadata: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary, excluding None values."""
        result = {"name": self.name, "description": self.description}
        if self.license is not None:
            result["license"] = self.license
        if self.compatibility is not None:
            result["compatibility"] = self.compatibility
        if self.allowed_tools is not None:
            result["allowed-tools"] = self.allowed_tools
        if self.metadata:
            result["metadata"] = self.metadata
        return result


"""Skill-related exceptions."""


class SkillError(Exception):
    """Base exception for all skill-related errors."""

    pass


class ParseError(SkillError):
    """Raised when SKILL.md parsing fails."""

    pass


class ValidationError(SkillError):
    """Raised when skill properties are invalid.

    Attributes:
        errors: List of validation error messages (may contain just one)
    """

    def __init__(self, message: str, errors: list[str] | None = None):
        super().__init__(message)
        self.errors = errors if errors is not None else [message]


async def find_skill_md(skill_dir: Path) -> Optional[Path]:
    """Find the SKILL.md file in a skill directory.

    Prefers SKILL.md (uppercase) but accepts skill.md (lowercase).
    """
    skill_dir = Path(skill_dir)
    for name in ("SKILL.md", "skill.md"):
        path = skill_dir / name
        if await aiofiles.ospath.exists(path):
            return path
    return None


async def discover_skill_folders(path: Path) -> list[Path]:
    """Discover immediate child folders that contain a skill definition.

    This allows callers to provide a parent directory containing multiple
    skill folders instead of pointing at each skill directory individually.
    """
    skill_root = Path(path)
    if not skill_root.is_dir():
        return []

    discovered: list[Path] = []
    for child in sorted(skill_root.iterdir(), key=lambda entry: entry.name):
        if not child.is_dir():
            continue
        if await find_skill_md(child) is not None:
            discovered.append(child)

    return discovered


def parse_frontmatter(content: str) -> tuple[dict, str]:
    """Parse YAML frontmatter from SKILL.md content."""
    if not content.startswith("---"):
        raise ParseError("SKILL.md must start with YAML frontmatter (---)")

    parts = content.split("---", 2)
    if len(parts) < 3:
        raise ParseError("SKILL.md frontmatter not properly closed with ---")

    frontmatter_str = parts[1]
    body = parts[2].strip()

    try:
        parsed = strictyaml.load(frontmatter_str)
        metadata = parsed.data
    except strictyaml.YAMLError as e:
        raise ParseError(f"Invalid YAML in frontmatter: {e}") from e

    if not isinstance(metadata, dict):
        raise ParseError("SKILL.md frontmatter must be a YAML mapping")

    if "metadata" in metadata and isinstance(metadata["metadata"], dict):
        metadata["metadata"] = {str(k): str(v) for k, v in metadata["metadata"].items()}

    return metadata, body


async def _read_properties_from_skill_md(skill_md: Path) -> SkillProperties:
    async with aiofiles.open(skill_md, "r", encoding="utf-8") as f:
        content = await f.read()

    metadata, _ = parse_frontmatter(content)

    if "name" not in metadata:
        raise ValidationError("Missing required field in frontmatter: name")
    if "description" not in metadata:
        raise ValidationError("Missing required field in frontmatter: description")

    name = metadata["name"]
    description = metadata["description"]

    if not isinstance(name, str) or not name.strip():
        raise ValidationError("Field 'name' must be a non-empty string")
    if not isinstance(description, str) or not description.strip():
        raise ValidationError("Field 'description' must be a non-empty string")

    return SkillProperties(
        name=name.strip(),
        description=description.strip(),
        license=metadata.get("license"),
        compatibility=metadata.get("compatibility"),
        allowed_tools=metadata.get("allowed-tools"),
        metadata=metadata.get("metadata"),
    )


async def read_properties(skill_dir: Path) -> SkillProperties:
    """Read skill properties from SKILL.md frontmatter (async).

    This function parses the frontmatter and returns properties.
    It does NOT perform full validation. Use validate() for that.
    """
    skill_dir = Path(skill_dir)
    skill_md = await find_skill_md(skill_dir)

    if skill_md is None:
        raise ParseError(f"SKILL.md not found in {skill_dir}")

    return await _read_properties_from_skill_md(skill_md)


def _resolve_configured_local_path(path: Path) -> Path:
    if path.is_absolute():
        return path.resolve()
    return (Path.cwd() / path).resolve()


def _normalize_configured_storage_path(path: Path) -> Path:
    if path.is_absolute():
        return path

    normalized = posixpath.normpath(f"/{path.as_posix()}")
    if not normalized.startswith("/"):
        normalized = f"/{normalized}"
    return Path(normalized)


def _default_prompt_storage(
    skill_dirs: list[Path],
) -> tuple[StorageToolkit, list[Path]]:
    cwd = Path.cwd().resolve()
    mounts = [
        StorageToolLocalMount(
            path="/",
            local_path=str(cwd),
        )
    ]
    normalized_skill_dirs: list[Path] = []
    mounted_paths = {"/"}

    for skill_dir in skill_dirs:
        resolved = _resolve_configured_local_path(skill_dir)
        if resolved.is_relative_to(cwd):
            relative = resolved.relative_to(cwd)
            virtual_path = Path("/") if relative == Path(".") else Path("/") / relative
        else:
            virtual_path = resolved
            mount_path = virtual_path.as_posix()
            if mount_path not in mounted_paths:
                mounts.append(
                    StorageToolLocalMount(
                        path=mount_path,
                        local_path=str(resolved),
                    )
                )
                mounted_paths.add(mount_path)

        normalized_skill_dirs.append(virtual_path)

    return StorageToolkit(read_only=True, mounts=mounts), normalized_skill_dirs


async def _find_skill_md_in_storage(
    *,
    storage_toolkit: StorageToolkit,
    skill_dir: Path,
) -> Optional[Path]:
    entries = await storage_toolkit.list_entries(path=skill_dir.as_posix())
    files = {entry.name for entry in entries if not entry.is_folder}

    for name in ("SKILL.md", "skill.md"):
        if name in files:
            return skill_dir / name

    return None


async def _discover_skill_folders_in_storage(
    *,
    storage_toolkit: StorageToolkit,
    path: Path,
) -> list[Path]:
    entries = await storage_toolkit.list_entries(path=path.as_posix())

    discovered: list[Path] = []
    for entry in sorted(entries, key=lambda item: item.name):
        if not entry.is_folder:
            continue

        child = path / entry.name
        if (
            await _find_skill_md_in_storage(
                storage_toolkit=storage_toolkit,
                skill_dir=child,
            )
            is not None
        ):
            discovered.append(child)

    return discovered


async def _read_properties_from_skill_md_in_storage(
    *,
    storage_toolkit: StorageToolkit,
    skill_md: Path,
) -> SkillProperties:
    content = await storage_toolkit.read_file(path=skill_md.as_posix())
    metadata, _ = parse_frontmatter(content.data.decode("utf-8"))

    if "name" not in metadata:
        raise ValidationError("Missing required field in frontmatter: name")
    if "description" not in metadata:
        raise ValidationError("Missing required field in frontmatter: description")

    name = metadata["name"]
    description = metadata["description"]

    if not isinstance(name, str) or not name.strip():
        raise ValidationError("Field 'name' must be a non-empty string")
    if not isinstance(description, str) or not description.strip():
        raise ValidationError("Field 'description' must be a non-empty string")

    return SkillProperties(
        name=name.strip(),
        description=description.strip(),
        license=metadata.get("license"),
        compatibility=metadata.get("compatibility"),
        allowed_tools=metadata.get("allowed-tools"),
        metadata=metadata.get("metadata"),
    )


"""Generate <available_skills> XML prompt block for agent system prompts."""


def _append_prompt_skill(
    *,
    lines: list[str],
    name: str,
    description: str,
    location: str,
) -> None:
    lines.append("<skill>")
    lines.append("<name>")
    lines.append(html.escape(name))
    lines.append("</name>")
    lines.append("<description>")
    lines.append(html.escape(description))
    lines.append("</description>")
    lines.append("<location>")
    lines.append(str(location))
    lines.append("</location>")
    lines.append("</skill>")


def _append_unavailable_prompt_skill(
    *,
    lines: list[str],
    name: str,
    location: str,
    error: str,
) -> None:
    _append_prompt_skill(
        lines=lines,
        name=name,
        description=f"Configured skill could not be loaded: {error}",
        location=location,
    )


async def _append_skill_prompt_entry(
    *,
    lines: list[str],
    skill_md_path: Path,
    storage_toolkit: StorageToolkit,
    missing_ok: bool,
    location_mapper: SkillLocationMapper | None,
) -> None:
    try:
        props = await _read_properties_from_skill_md_in_storage(
            storage_toolkit=storage_toolkit,
            skill_md=skill_md_path,
        )
    except (OSError, ParseError, ValidationError, UnicodeError) as exc:
        if not missing_ok:
            raise
        logger.warning("unable to load skill from %s: %s", skill_md_path, exc)
        _append_unavailable_prompt_skill(
            lines=lines,
            name=skill_md_path.parent.name or str(skill_md_path.parent),
            location=_render_prompt_location(
                location=skill_md_path,
                location_mapper=location_mapper,
            ),
            error=str(exc),
        )
        return

    _append_prompt_skill(
        lines=lines,
        name=props.name,
        description=props.description,
        location=_render_prompt_location(
            location=skill_md_path,
            location_mapper=location_mapper,
        ),
    )


def _render_prompt_location(
    *,
    location: Path,
    location_mapper: SkillLocationMapper | None,
) -> str:
    if location_mapper is None:
        return str(location)
    return location_mapper(location)


async def to_prompt(
    skill_dirs: list[Path],
    *,
    storage_toolkit: StorageToolkit | None = None,
    missing_ok: bool = True,
    location_mapper: SkillLocationMapper | None = None,
) -> str:
    """Generate the <available_skills> XML block for inclusion in agent prompts.

    This XML format is what Anthropic uses and recommends for Claude models.
    Skill Clients may format skill information differently to suit their
    models or preferences.

    Args:
        skill_dirs: List of paths to skill directories
        storage_toolkit: Optional storage toolkit used to inspect and read skill
            files. When omitted, a default local toolkit mounts the current
            working directory to `/`.
        missing_ok: When True, include a prompt entry for missing SKILL.md files
            instead of failing.
        location_mapper: Optional path remapper for emitted <location> values.

    Returns:
        XML string with <available_skills> block containing each skill's
        name, description, and location.

    Example output:
        <available_skills>
        <skill>
        <name>pdf-reader</name>
        <description>Read and extract text from PDF files</description>
        <location>/path/to/pdf-reader/SKILL.md</location>
        </skill>
        </available_skills>
    """
    if not skill_dirs:
        return "<available_skills>\n</available_skills>"

    if storage_toolkit is None:
        prompt_storage_toolkit, normalized_skill_dirs = _default_prompt_storage(
            skill_dirs
        )
    else:
        prompt_storage_toolkit = storage_toolkit
        normalized_skill_dirs = [
            _normalize_configured_storage_path(skill_dir) for skill_dir in skill_dirs
        ]
    lines = ["<available_skills>"]

    for skill_dir in normalized_skill_dirs:
        skill_md_path = await _find_skill_md_in_storage(
            storage_toolkit=prompt_storage_toolkit,
            skill_dir=skill_dir,
        )
        if skill_md_path is None:
            discovered_skill_dirs = await _discover_skill_folders_in_storage(
                storage_toolkit=prompt_storage_toolkit,
                path=skill_dir,
            )
            if discovered_skill_dirs:
                for discovered_skill_dir in discovered_skill_dirs:
                    discovered_skill_md_path = await _find_skill_md_in_storage(
                        storage_toolkit=prompt_storage_toolkit,
                        skill_dir=discovered_skill_dir,
                    )
                    if discovered_skill_md_path is None:
                        continue
                    await _append_skill_prompt_entry(
                        lines=lines,
                        skill_md_path=discovered_skill_md_path,
                        storage_toolkit=prompt_storage_toolkit,
                        missing_ok=missing_ok,
                        location_mapper=location_mapper,
                    )
                continue

            if not missing_ok:
                raise ParseError(f"SKILL.md not found in {skill_dir}")

            logger.warning("SKILL.md not found in %s", skill_dir)
            _append_prompt_skill(
                lines=lines,
                name=skill_dir.name or str(skill_dir),
                description=(
                    "Configured skill directory is missing SKILL.md and cannot be "
                    "loaded until the file is added."
                ),
                location=_render_prompt_location(
                    location=skill_dir,
                    location_mapper=location_mapper,
                ),
            )
            continue

        await _append_skill_prompt_entry(
            lines=lines,
            skill_md_path=skill_md_path,
            storage_toolkit=prompt_storage_toolkit,
            missing_ok=missing_ok,
            location_mapper=location_mapper,
        )

    lines.append("</available_skills>")

    return "\n".join(lines)


MAX_SKILL_NAME_LENGTH = 64
MAX_DESCRIPTION_LENGTH = 1024
MAX_COMPATIBILITY_LENGTH = 500

# Allowed frontmatter fields per Agent Skills Spec
ALLOWED_FIELDS = {
    "name",
    "description",
    "license",
    "allowed-tools",
    "metadata",
    "compatibility",
}


def _validate_name(name: str, skill_dir: Path) -> list[str]:
    """Validate skill name format and directory match.

    Skill names support i18n characters (Unicode letters) plus hyphens.
    Names must be lowercase and cannot start/end with hyphens.
    """
    errors = []

    if not name or not isinstance(name, str) or not name.strip():
        errors.append("Field 'name' must be a non-empty string")
        return errors

    name = unicodedata.normalize("NFKC", name.strip())

    if len(name) > MAX_SKILL_NAME_LENGTH:
        errors.append(
            f"Skill name '{name}' exceeds {MAX_SKILL_NAME_LENGTH} character limit "
            f"({len(name)} chars)"
        )

    if name != name.lower():
        errors.append(f"Skill name '{name}' must be lowercase")

    if name.startswith("-") or name.endswith("-"):
        errors.append("Skill name cannot start or end with a hyphen")

    if "--" in name:
        errors.append("Skill name cannot contain consecutive hyphens")

    if not all(c.isalnum() or c == "-" for c in name):
        errors.append(
            f"Skill name '{name}' contains invalid characters. "
            "Only letters, digits, and hyphens are allowed."
        )

    if skill_dir:
        dir_name = unicodedata.normalize("NFKC", skill_dir.name)
        if dir_name != name:
            errors.append(
                f"Directory name '{skill_dir.name}' must match skill name '{name}'"
            )

    return errors


def _validate_description(description: str) -> list[str]:
    """Validate description format."""
    errors = []

    if not description or not isinstance(description, str) or not description.strip():
        errors.append("Field 'description' must be a non-empty string")
        return errors

    if len(description) > MAX_DESCRIPTION_LENGTH:
        errors.append(
            f"Description exceeds {MAX_DESCRIPTION_LENGTH} character limit "
            f"({len(description)} chars)"
        )

    return errors


def _validate_compatibility(compatibility: str) -> list[str]:
    """Validate compatibility format."""
    errors = []

    if not isinstance(compatibility, str):
        errors.append("Field 'compatibility' must be a string")
        return errors

    if len(compatibility) > MAX_COMPATIBILITY_LENGTH:
        errors.append(
            f"Compatibility exceeds {MAX_COMPATIBILITY_LENGTH} character limit "
            f"({len(compatibility)} chars)"
        )

    return errors


def _validate_metadata_fields(metadata: dict) -> list[str]:
    """Validate that only allowed fields are present."""
    errors = []

    extra_fields = set(metadata.keys()) - ALLOWED_FIELDS
    if extra_fields:
        errors.append(
            f"Unexpected fields in frontmatter: {', '.join(sorted(extra_fields))}. "
            f"Only {sorted(ALLOWED_FIELDS)} are allowed."
        )

    return errors


def validate_metadata(metadata: dict, skill_dir: Optional[Path] = None) -> list[str]:
    """Validate parsed skill metadata.

    This is the core validation function that works on already-parsed metadata,
    avoiding duplicate file I/O when called from the parser.

    Args:
        metadata: Parsed YAML frontmatter dictionary
        skill_dir: Optional path to skill directory (for name-directory match check)

    Returns:
        List of validation error messages. Empty list means valid.
    """
    errors = []
    errors.extend(_validate_metadata_fields(metadata))

    if "name" not in metadata:
        errors.append("Missing required field in frontmatter: name")
    else:
        errors.extend(_validate_name(metadata["name"], skill_dir))

    if "description" not in metadata:
        errors.append("Missing required field in frontmatter: description")
    else:
        errors.extend(_validate_description(metadata["description"]))

    if "compatibility" in metadata:
        errors.extend(_validate_compatibility(metadata["compatibility"]))

    return errors


async def validate(skill_dir: Path) -> list[str]:
    """Validate a skill directory.

    Args:
        skill_dir: Path to the skill directory

    Returns:
        List of validation error messages. Empty list means valid.
    """
    skill_dir = Path(skill_dir)

    if not skill_dir.exists():
        return [f"Path does not exist: {skill_dir}"]

    if not skill_dir.is_dir():
        return [f"Not a directory: {skill_dir}"]

    skill_md = await find_skill_md(skill_dir)
    if skill_md is None:
        return ["Missing required file: SKILL.md"]

    try:
        async with aiofiles.open(skill_md, "r", encoding="utf-8") as f:
            content = await f.read()
        metadata, _ = parse_frontmatter(content)
    except ParseError as e:
        return [str(e)]

    return validate_metadata(metadata, skill_dir)
