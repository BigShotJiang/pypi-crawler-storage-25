---
tags: [finlet, claude-md, project-instructions]
keywords: Finlet, coding conventions, project rules, async Python, FastAPI, SQLModel
priority: normal
---

# Finlet — Project Conventions

## Source of Truth
Read `docs/ARCHITECTURE.md` for all architectural decisions. It is authoritative.
Path-scoped rules live in `.claude/rules/` — they are auto-loaded per file context.

## Tech Stack
- Python 3.12+, async throughout, type hints everywhere
- FastAPI for REST API
- FastMCP (`mcp` Python SDK) for MCP server
- SQLite via `aiosqlite` + SQLModel for persistence
- `httpx` for async HTTP calls in plugins
- `typer` for CLI
- `structlog` for structured logging
- pytest + pytest-asyncio for tests

## Code Rules
- All datetimes in UTC internally, convert for display only
- Every plugin response goes through the date ceiling enforcer — no exceptions
- Error responses to agents must be specific and actionable (e.g., "Finnhub rate limit exceeded: 0/60 calls remaining, resets in 42 seconds" not "API error")
- One file per module, no god files

## Agent Execution Model — Non-Negotiable

The main chat agent is a **team lead**, not a worker. Its context window must stay as lean as possible.

### Rules
1. **Never do work inline.** Every task — coding, research, exploration, testing, file reads beyond a quick glance — MUST be delegated to a subagent (`Agent` tool) or an agent team (`TeamCreate` + `SendMessage`).
2. **Use `TeamCreate` for multi-step or collaborative work.** When a task involves 2+ agents that need to coordinate (e.g., engine + tests, research + implementation), create a named team with a team-lead agent that owns the deliverable.
3. **Use `Agent` (subagent) for one-shot, isolated tasks.** Quick searches, single-file edits, running a test suite — these can be standalone subagents. But they still run outside the main context.
4. **Even recon is delegated.** Exploring the codebase, grepping for patterns, reading architecture docs — spawn an `Explore` agent or a `general-purpose` agent. The main agent should receive a summary, not raw tool output.
5. **Prefer `isolation: "worktree"` for any agent that writes code.** This prevents conflicts when multiple agents work in parallel.
6. **Main agent responsibilities are limited to:**
   - Understanding the user's intent
   - Deciding which agents/teams to spawn
   - Routing messages between teams
   - Summarizing results back to the user
   - Saving memories when appropriate
7. **Parallel by default.** If tasks are independent, launch agents concurrently in a single message. Sequential only when there's a true dependency.

### Anti-Patterns (Do NOT Do)
- Reading large files directly in the main context
- Running grep/glob searches inline when an Explore agent can do it
- Writing or editing code in the main context
- Accumulating tool output that could have been summarized by a subagent

## Tool References (Agent Teams)
Each department has a tool reference doc listing installed CLI tools and available MCP servers. Agents MUST check their department's tool reference before starting work to know what tooling is available.
- DevOps & Code Quality → `docs/tools/devops.md`
- AWS & Infrastructure → `docs/tools/aws.md`
- API & Data → `docs/tools/api-data.md`
- Plugin & Dependency Management → `docs/tools/plugin-mgmt.md`
- Full research catalog → `docs/DEV_TOOLS.md`

## Documentation — Non-Negotiable

After EVERY set of code changes (commit, PR, phase completion), update all affected documentation before considering the work done. This includes:
- `docs/ARCHITECTURE.md` — if any architectural component changed (new endpoints, new DB constraints, new plugin behavior, schema changes)
- `docs/REMAINING_TASKS.md` — mark completed items, add newly discovered items
- `docs/decisions/` — if a non-trivial technical decision was made, add or update a decision record
- `CLAUDE.md` — if conventions, tech stack, or workflows changed
- `docs/lessons.md` — if a deployment or operational lesson was learned

Delegate doc updates to a subagent if needed, but they MUST happen. Stale docs are worse than no docs — they actively mislead future agents and humans.

## Compaction Preservation
When compacting, always preserve: list of files modified in this session, active task context, module boundary rules, and the agent execution model.
