#!/usr/bin/env bash
# Finlet Rollback Script
# Restores DB from the most recent backup, checks out the previous git tag, restarts the service.
# Idempotent: safe to run multiple times.

set -euo pipefail

# --- Configuration ---
APP_DIR="${FINLET_APP_DIR:-/opt/finlet}"
DATA_DIR="${FINLET_DATA_DIR:-/home/finlet/.finlet}"
BACKUP_DIR="${DATA_DIR}/backups"
SERVICE_NAME="finlet"
LOG_FILE="/var/log/finlet/rollback.log"

log() {
    echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $*" | tee -a "$LOG_FILE"
}

die() {
    log "FATAL: $*"
    exit 1
}

mkdir -p "$(dirname "$LOG_FILE")"

log "=== Finlet rollback started ==="

# --- Step 1: Restore DB from most recent backup ---
log "Looking for most recent backup in $BACKUP_DIR..."

if [ ! -d "$BACKUP_DIR" ]; then
    die "Backup directory $BACKUP_DIR does not exist. Cannot rollback."
fi

# Find the most recent backup for each database
RESTORED=0
for db in "$DATA_DIR"/*.db; do
    [ -f "$db" ] || continue

    DB_NAME="$(basename "$db" .db)"
    # Find latest backup matching this database name
    LATEST_BACKUP="$(ls -t "$BACKUP_DIR/${DB_NAME}_"*.db.gz 2>/dev/null | head -1 || true)"

    if [ -z "$LATEST_BACKUP" ]; then
        log "WARNING: No backup found for $DB_NAME — skipping."
        continue
    fi

    log "Restoring $DB_NAME from $LATEST_BACKUP..."

    # Stop service before restoring (idempotent)
    if systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
        log "Stopping $SERVICE_NAME service..."
        sudo systemctl stop "$SERVICE_NAME" || true
    fi

    # Decompress backup to temp file, then replace
    TEMP_RESTORE="$(mktemp)"
    gunzip -c "$LATEST_BACKUP" > "$TEMP_RESTORE"

    # Verify the backup is a valid SQLite database
    if ! sqlite3 "$TEMP_RESTORE" "PRAGMA integrity_check;" >/dev/null 2>&1; then
        rm -f "$TEMP_RESTORE"
        log "WARNING: Backup $LATEST_BACKUP failed integrity check — skipping $DB_NAME."
        continue
    fi

    # Replace the live database
    cp "$TEMP_RESTORE" "$db"
    rm -f "$TEMP_RESTORE"
    RESTORED=$((RESTORED + 1))
    log "Restored $DB_NAME successfully."
done

log "Restored $RESTORED database(s)."

# --- Step 2: Check out the previous git tag/commit ---
cd "$APP_DIR"

# Look for the pre-deploy tag
PREV_TAG="$(git tag -l 'pre-deploy-*' --sort=-creatordate | head -1 || true)"

if [ -n "$PREV_TAG" ]; then
    log "Checking out previous deploy tag: $PREV_TAG"
    git checkout "$PREV_TAG" --force
    log "Checked out $PREV_TAG."
elif git rev-parse HEAD~1 >/dev/null 2>&1; then
    log "No pre-deploy tag found. Checking out previous commit (HEAD~1)."
    git checkout HEAD~1 --force
    log "Checked out HEAD~1."
else
    log "WARNING: No previous tag or commit to roll back to. Skipping git rollback."
fi

# --- Step 3: Reinstall dependencies ---
if [ -f "$APP_DIR/.venv/bin/activate" ]; then
    log "Reinstalling Python package..."
    source "$APP_DIR/.venv/bin/activate"
    pip install --quiet --upgrade pip
    pip install --quiet -e ".[server]"
    deactivate
fi

# --- Step 4: Restart the service ---
log "Restarting $SERVICE_NAME service..."
sudo systemctl start "$SERVICE_NAME"

# Wait briefly for startup
sleep 3

if systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
    log "Service $SERVICE_NAME is running."
else
    log "WARNING: Service $SERVICE_NAME failed to start after rollback."
    log "Check logs: sudo journalctl -u $SERVICE_NAME -n 50"
fi

# --- Step 5: Health check ---
HEALTH_URL="${FINLET_HEALTH_URL:-http://127.0.0.1:8000/health}"
HEALTH_OK=false

for i in 1 2 3 4 5; do
    if curl -sf --max-time 5 "$HEALTH_URL" >/dev/null 2>&1; then
        HEALTH_OK=true
        break
    fi
    log "Health check attempt $i/5 failed, waiting..."
    sleep 2
done

if [ "$HEALTH_OK" = true ]; then
    log "Health check passed after rollback."
else
    log "WARNING: Health check failed after rollback. Manual intervention may be needed."
    log "  Check: sudo systemctl status $SERVICE_NAME"
    log "  Logs:  sudo journalctl -u $SERVICE_NAME -n 100"
fi

log "=== Finlet rollback finished ==="
