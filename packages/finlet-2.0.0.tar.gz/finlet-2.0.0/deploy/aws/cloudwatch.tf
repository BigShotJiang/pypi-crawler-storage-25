# ──────────────────────────────────────────────────────────────────────────────
# Finlet — CloudWatch Monitoring
#
# Free-tier CloudWatch alarms for the Finlet EC2 instance.
# CPU utilization and status check alarms with SNS email notifications.
#
# Note: Disk monitoring requires the CloudWatch agent installed on the
# instance. For v1, use the /health endpoint for disk checks instead.
# ──────────────────────────────────────────────────────────────────────────────

# ── SNS Topic for Alarm Notifications ────────────────────────────────────────

resource "aws_sns_topic" "finlet_alarms" {
  count = var.alert_email != "" ? 1 : 0
  name  = "finlet-alarms"

  tags = {
    Name = "finlet-alarms"
  }
}

resource "aws_sns_topic_subscription" "email" {
  count     = var.alert_email != "" ? 1 : 0
  topic_arn = aws_sns_topic.finlet_alarms[0].arn
  protocol  = "email"
  endpoint  = var.alert_email
}

# ── CPU Utilization Alarm ────────────────────────────────────────────────────
# Triggers when average CPU exceeds 80% for 5 consecutive minutes.

resource "aws_cloudwatch_metric_alarm" "cpu_high" {
  count               = var.alert_email != "" ? 1 : 0
  alarm_name          = "finlet-cpu-high"
  alarm_description   = "Finlet EC2 CPU utilization exceeds 80% for 5 minutes"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 5
  metric_name         = "CPUUtilization"
  namespace           = "AWS/EC2"
  period              = 60
  statistic           = "Average"
  threshold           = 80
  treat_missing_data  = "notBreaching"

  dimensions = {
    InstanceId = aws_instance.finlet.id
  }

  alarm_actions = [aws_sns_topic.finlet_alarms[0].arn]
  ok_actions    = [aws_sns_topic.finlet_alarms[0].arn]

  tags = {
    Name = "finlet-cpu-high"
  }
}

# ── Status Check Failed Alarm ────────────────────────────────────────────────
# Triggers immediately when the instance fails system or instance status checks.

resource "aws_cloudwatch_metric_alarm" "status_check_failed" {
  count               = var.alert_email != "" ? 1 : 0
  alarm_name          = "finlet-status-check-failed"
  alarm_description   = "Finlet EC2 instance or system status check has failed"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "StatusCheckFailed"
  namespace           = "AWS/EC2"
  period              = 60
  statistic           = "Maximum"
  threshold           = 0
  treat_missing_data  = "breaching"

  dimensions = {
    InstanceId = aws_instance.finlet.id
  }

  alarm_actions = [aws_sns_topic.finlet_alarms[0].arn]
  ok_actions    = [aws_sns_topic.finlet_alarms[0].arn]

  tags = {
    Name = "finlet-status-check-failed"
  }
}
