# EC2 Backfill Launcher (`backfill-userdata.sh`)

Canonical hardened EC2 user-data template for running Finlet backfills
(yfinance price ingest + canonical fundamentals build). Use this for
Session 4 and every subsequent backfill — no more ad-hoc launchers.

## When to use

- Multi-hour price / fundamentals backfills on a spot or on-demand EC2.
- Any re-run that needs `ingest_yfinance_prices.py` + `build_canonical.py`.
- Do NOT use for quick one-shot scripts; just run them locally.

## Required env vars (set client-side before upload)

| Var          | Example                  | Notes                                         |
|--------------|--------------------------|-----------------------------------------------|
| `SESSION_ID` | `session4`               | Used in S3 log filenames                      |
| `BUCKET`     | `finlet-data-cccdea31`   | NEVER hardcoded in the template               |
| `TICKERS`    | `"AAPL MSFT SPY"`        | Space-separated; written to ticker list file  |
| `START_DATE` | `2010-01-04`             | YYYY-MM-DD                                    |
| `END_DATE`   | `2026-04-17`             | YYYY-MM-DD, exclusive                         |

Optional: `BATCH_SIZE` (5), `SAFETY_CAP_MIN` (1200 = 20h),
`RUN_CANONICAL` (1), `REPO_DIR`, `VENV_PY`, `LOG_PREFIX`.

## Launching from a workstation

Env-var substitution happens client-side via `envsubst` before upload;
the file that lands on EC2 has values baked in.

```bash
export SESSION_ID=session4 BUCKET=finlet-data-cccdea31 \
       TICKERS="AAPL MSFT SPY" START_DATE=2010-01-04 END_DATE=2026-04-17
envsubst < deploy/aws/backfill-userdata.sh > /tmp/ud.sh
aws ec2 run-instances \
    --image-id ami-xxxxxxxx --instance-type t3.medium \
    --iam-instance-profile Name=finlet-ingestor \
    --user-data file:///tmp/ud.sh
```

Progress log syncs to `s3://$BUCKET/reference/_backfill_logs/${SESSION_ID}_progress.log`
every 120s. Success writes `..._final-success.log`; any failure writes
`..._final-fail-<step>.log` and leaves the instance alive for post-mortem.

## Lesson references

- `feedback_spot_interruption_multihour.md` — don't use spot one-time for multi-hour runs
- `feedback_ec2_backfill_bucket_env.md` — all four `FINLET_*_BUCKET` vars must be set
- `feedback_shutdown_extend_doesnt_override.md` — `shutdown -c` alone doesn't override; use `override_safety_shutdown`
