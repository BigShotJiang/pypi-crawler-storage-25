# Remote state backend — S3 + DynamoDB locking.
# Cost: $0/month (S3 free tier + DynamoDB on-demand free tier).

terraform {
  backend "s3" {
    bucket         = "finlet-tfstate-8b0083d0"
    key            = "finlet/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "finlet-tfstate-lock"
    encrypt        = true
  }
}
