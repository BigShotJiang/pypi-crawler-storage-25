output "instance_id" {
  description = "EC2 instance ID"
  value       = aws_instance.finlet.id
}

output "public_ip" {
  description = "Public IP of the EC2 instance (may change on stop/start — use elastic_ip instead)"
  value       = aws_instance.finlet.public_ip
}

output "elastic_ip" {
  description = "Elastic IP permanently associated with the Finlet instance"
  value       = aws_eip.finlet.public_ip
}

output "s3_backup_bucket_name" {
  description = "S3 bucket name for SQLite backups"
  value       = aws_s3_bucket.backups.id
}


output "ssm_command" {
  description = "SSM Session Manager command to connect to the instance"
  value       = "aws ssm start-session --target ${aws_instance.finlet.id}"
}

output "s3_price_data_bucket_name" {
  description = "S3 bucket name for EOD price data (set as FINLET_PRICE_BUCKET env var)"
  value       = aws_s3_bucket.price_data.id
}
