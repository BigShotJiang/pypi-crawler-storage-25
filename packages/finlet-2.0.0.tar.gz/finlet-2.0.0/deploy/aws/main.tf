# ──────────────────────────────────────────────────────────────────────────────
# Finlet — AWS Infrastructure
#
# Provisions a single free-tier EC2 instance with HTTPS via Caddy, S3 backups,
# Route 53 DNS, and minimal IAM permissions. Designed for finlet.dev.
#
# Usage:
#   terraform init
#   terraform plan -var="key_pair_name=my-key"
#   terraform apply -var="key_pair_name=my-key"
# ──────────────────────────────────────────────────────────────────────────────

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project     = "finlet"
      Environment = "production"
      ManagedBy   = "terraform"
    }
  }
}

# Common tags applied to resources that don't inherit default_tags.
locals {
  common_tags = {
    Project     = "finlet"
    Environment = "production"
    ManagedBy   = "terraform"
  }
}

# ── Random suffix for globally-unique S3 bucket name ─────────────────────────

resource "random_id" "bucket_suffix" {
  byte_length = 4
}

# ── Latest Ubuntu 22.04 LTS AMI ─────────────────────────────────────────────

data "aws_ami" "ubuntu" {
  most_recent = true
  owners      = ["099720109477"] # Canonical

  filter {
    name   = "name"
    values = ["ubuntu/images/hvm-ssd/ubuntu-jammy-22.04-amd64-server-*"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

# ── Security Group ───────────────────────────────────────────────────────────

resource "aws_security_group" "finlet" {
  name        = "finlet-sg"
  description = "Allow SSH, HTTP, and HTTPS inbound; all outbound"

  # SSH — admin access
  # TODO: Replace 0.0.0.0/32 with admin IP (e.g., "203.0.113.5/32")
  ingress {
    description = "SSH"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/32"]
  }

  # HTTP — Caddy uses this for ACME challenge and redirects to HTTPS
  ingress {
    description = "HTTP"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  # HTTPS
  ingress {
    description = "HTTPS"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    description = "All outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "finlet-sg"
  }
}

# ── EC2 Instance ─────────────────────────────────────────────────────────────

resource "aws_instance" "finlet" {
  ami                    = data.aws_ami.ubuntu.id
  instance_type          = var.instance_type
  key_name               = var.key_pair_name
  vpc_security_group_ids = [aws_security_group.finlet.id]
  iam_instance_profile   = aws_iam_instance_profile.finlet.name

  user_data = file("${path.module}/user-data.sh")

  root_block_device {
    volume_size           = 8 # GB — free tier allows up to 30 GB
    volume_type           = "gp3"
    delete_on_termination = false
    encrypted             = true
  }

  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required"
    http_put_response_hop_limit = 1
  }

  lifecycle {
    ignore_changes = [ami, key_name, user_data] # Prevent drift from destroying a running instance
  }

  tags = {
    Name = "finlet"
  }
}

# ── Elastic IP ───────────────────────────────────────────────────────────────
# Keeps a stable public IP across instance stop/start cycles.

resource "aws_eip" "finlet" {
  domain = "vpc"

  tags = {
    Name = "finlet-eip"
  }
}

resource "aws_eip_association" "finlet" {
  instance_id   = aws_instance.finlet.id
  allocation_id = aws_eip.finlet.id
}

# ── DNS ──────────────────────────────────────────────────────────────────────
# DNS is managed via Cloudflare (registrar). Add an A record in the Cloudflare
# dashboard pointing finlet.dev → elastic_ip (DNS-only mode, grey cloud).

# ── S3 Backup Bucket ────────────────────────────────────────────────────────
# Stores nightly SQLite database backups. Versioning protects against
# accidental overwrites. Objects expire after 90 days to stay within free tier
# storage limits (~5 GB).

resource "aws_s3_bucket" "backups" {
  bucket = "finlet-backups-${random_id.bucket_suffix.hex}"

  tags = {
    Name = "finlet-backups"
  }
}

resource "aws_s3_bucket_versioning" "backups" {
  bucket = aws_s3_bucket.backups.id

  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "backups" {
  bucket = aws_s3_bucket.backups.id

  rule {
    id     = "expire-old-backups"
    status = "Enabled"

    filter {} # Apply to all objects

    expiration {
      days = 30
    }

    noncurrent_version_expiration {
      noncurrent_days = 30
    }
  }
}

resource "aws_s3_bucket_public_access_block" "backups" {
  bucket = aws_s3_bucket.backups.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_server_side_encryption_configuration" "backups" {
  bucket = aws_s3_bucket.backups.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "aws:kms"
    }
    bucket_key_enabled = true
  }
}

# ── IAM Role + Instance Profile ──────────────────────────────────────────────
# Grants the EC2 instance least-privilege access to the backup bucket only.

data "aws_iam_policy_document" "ec2_assume_role" {
  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "finlet" {
  name               = "finlet-ec2-role"
  assume_role_policy = data.aws_iam_policy_document.ec2_assume_role.json

  tags = {
    Name = "finlet-ec2-role"
  }
}

data "aws_iam_policy_document" "backup_access" {
  statement {
    sid = "AllowBackupBucketAccess"
    actions = [
      "s3:PutObject",
      "s3:GetObject",
      "s3:ListBucket",
      "s3:DeleteObject",
    ]
    resources = [
      aws_s3_bucket.backups.arn,
      "${aws_s3_bucket.backups.arn}/*",
    ]
  }
}

resource "aws_iam_role_policy" "finlet_backup" {
  name   = "finlet-backup-policy"
  role   = aws_iam_role.finlet.id
  policy = data.aws_iam_policy_document.backup_access.json
}

resource "aws_iam_role_policy_attachment" "finlet_ssm" {
  role       = aws_iam_role.finlet.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

resource "aws_iam_instance_profile" "finlet" {
  name = "finlet-instance-profile"
  role = aws_iam_role.finlet.name
}

# ── S3 Price Data Bucket ─────────────────────────────────────────────────────
# Stores EOD OHLCV Parquet files at prices/daily/{YYYY-MM-DD}.parquet.
# Immutable data — no versioning or lifecycle expiration needed.

resource "aws_s3_bucket" "price_data" {
  bucket = "finlet-data-${random_id.bucket_suffix.hex}"

  tags = {
    Name = "finlet-price-data"
  }
}

resource "aws_s3_bucket_public_access_block" "price_data" {
  bucket = aws_s3_bucket.price_data.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_server_side_encryption_configuration" "price_data" {
  bucket = aws_s3_bucket.price_data.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "aws:kms"
    }
    bucket_key_enabled = true
  }
}

# ── EC2 Access to Price Data Bucket ──────────────────────────────────────────
# Read access to the full bucket for serving data, plus scoped write access
# on ingestion paths so bulk scrapes can run directly on the EC2 instance.

data "aws_iam_policy_document" "price_data_access" {
  statement {
    sid = "AllowPriceBucketRead"
    actions = [
      "s3:GetObject",
      "s3:ListBucket",
    ]
    resources = [
      aws_s3_bucket.price_data.arn,
      "${aws_s3_bucket.price_data.arn}/*",
    ]
  }

  statement {
    sid = "AllowPriceBucketIngestWrite"
    actions = [
      "s3:PutObject",
    ]
    resources = [
      "${aws_s3_bucket.price_data.arn}/prices/daily/*",
      "${aws_s3_bucket.price_data.arn}/fundamentals/*",
      "${aws_s3_bucket.price_data.arn}/news/daily/*",
      "${aws_s3_bucket.price_data.arn}/sentiment/daily/*",
      "${aws_s3_bucket.price_data.arn}/reference/*",
      "${aws_s3_bucket.price_data.arn}/economic/*",
      "${aws_s3_bucket.price_data.arn}/edgar/*",
    ]
  }
}

resource "aws_iam_role_policy" "finlet_price_data" {
  name   = "finlet-price-data-policy"
  role   = aws_iam_role.finlet.id
  policy = data.aws_iam_policy_document.price_data_access.json
}

# ── SES Email Sending ───────────────────────────────────────────────────────
# Grants the EC2 instance permission to send email via Amazon SES.
# Scoped to the verified finlet.dev domain identity only.

data "aws_iam_policy_document" "ses_send" {
  statement {
    sid = "AllowSESSendEmail"
    actions = [
      "ses:SendEmail",
      "ses:SendRawEmail",
    ]
    resources = [
      "arn:aws:ses:us-east-1:*:identity/finlet.dev",
    ]
  }
}

resource "aws_iam_role_policy" "finlet_ses_send" {
  name   = "finlet-ses-send-policy"
  role   = aws_iam_role.finlet.id
  policy = data.aws_iam_policy_document.ses_send.json
}
