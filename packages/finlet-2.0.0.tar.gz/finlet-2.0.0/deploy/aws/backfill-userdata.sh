#!/bin/bash
# Finlet EC2 backfill launcher — canonical hardened template.
#
# Purpose:
#   Durable Session 4+ EC2 user-data template for running Finlet backfills
#   (yfinance price ingest + canonical fundamentals build) on a spot/on-demand
#   instance. Supersedes ad-hoc launchers generated for Sessions 1-3.5.
#
# Mandatory env vars (caller MUST set before invocation — see README-backfill.md):
#   SESSION_ID        e.g. "session4"  — used in log filenames on S3
#   BUCKET            e.g. "finlet-data-cccdea31"  — NO default; never hardcoded
#   TICKERS           space-separated list e.g. "AAPL MSFT ..."
#                     Written to scripts/ticker_lists/us_equities.txt
#                     (ingest_yfinance_prices.py reads from disk, not --tickers)
#   START_DATE        YYYY-MM-DD
#   END_DATE          YYYY-MM-DD (exclusive, yfinance convention)
#
# Optional env vars:
#   BATCH_SIZE        default 5
#   SAFETY_CAP_MIN    default 1200 (20h). NEVER tune to exact ETA — always
#                     exceed realistic worst-case by a comfortable margin.
#                     Session 3 died at its 14h cap mid-batch-47; 20h default
#                     reflects that lesson (see feedback_spot_interruption_multihour.md).
#   RUN_CANONICAL     "1" (default) to run build_canonical.py after prices;
#                     "0" to skip (e.g. prices-only rerun).
#   REPO_DIR          default /home/ubuntu/finlet
#   VENV_PY           default /home/ubuntu/finlet/.venv/bin/python
#   LOG_PREFIX        default reference/_backfill_logs  (S3 log location)
#
# Fail-safe posture:
#   - set -euo pipefail  (fail fast, no silent continues)
#   - 20h safety cap via `shutdown -h +1200` scheduled at boot. If the run
#     hangs or we forget to override, the instance still halts.
#   - NO shutdown-on-failure: any non-zero exit leaves the instance alive so
#     post-mortem logs (/tmp, journalctl) survive for inspection. The 20h
#     cap will eventually halt a truly stuck instance.
#   - Success path uses override_safety_shutdown() because `shutdown -c`
#     alone does NOT reliably override an already-scheduled halt on
#     Amazon Linux / Ubuntu. See feedback_shutdown_extend_doesnt_override.md.

set -euo pipefail

# ---------------------------------------------------------------------------
# Required env-var validation
# ---------------------------------------------------------------------------
: "${SESSION_ID:?SESSION_ID required (e.g. session4)}"
: "${BUCKET:?BUCKET required (e.g. finlet-data-<hash>); NEVER hardcode a value here}"
: "${TICKERS:?TICKERS required (space-separated list)}"
: "${START_DATE:?START_DATE required (YYYY-MM-DD)}"
: "${END_DATE:?END_DATE required (YYYY-MM-DD, exclusive)}"

BATCH_SIZE="${BATCH_SIZE:-5}"
SAFETY_CAP_MIN="${SAFETY_CAP_MIN:-1200}"
RUN_CANONICAL="${RUN_CANONICAL:-1}"
REPO_DIR="${REPO_DIR:-/home/ubuntu/finlet}"
VENV_PY="${VENV_PY:-/home/ubuntu/finlet/.venv/bin/python}"
LOG_PREFIX="${LOG_PREFIX:-reference/_backfill_logs}"

# ---------------------------------------------------------------------------
# Bucket env vars — all four are mandatory because different ingest/build
# scripts read different env names. Setting all four avoids the Session 2
# failure mode where scripts defaulted to a non-existent "finlet-data" bucket.
# See feedback_ec2_backfill_bucket_env.md.
# ---------------------------------------------------------------------------
export FINLET_PRICES_BUCKET="$BUCKET"
export FINLET_FUNDAMENTALS_BUCKET="$BUCKET"
export FINLET_REFERENCE_BUCKET="$BUCKET"
export FINLET_CANONICAL_BUCKET="$BUCKET"
# Legacy aliases consumed by older code paths; harmless to export.
export S3_PRICE_DATA_BUCKET="$BUCKET"

# ---------------------------------------------------------------------------
# Safety cap — must exceed realistic worst-case. NEVER tune to exact ETA.
# ---------------------------------------------------------------------------
sudo shutdown -h +"$SAFETY_CAP_MIN" "finlet ${SESSION_ID} safety cap (${SAFETY_CAP_MIN}min)"

# ---------------------------------------------------------------------------
# override_safety_shutdown — success-path helper.
#
# `sudo shutdown -c` alone does NOT reliably cancel a previously scheduled
# halt on Amazon Linux / Ubuntu (see feedback_shutdown_extend_doesnt_override.md).
# Kill the `shutdown` PID explicitly, then initiate an immediate halt.
# ---------------------------------------------------------------------------
override_safety_shutdown() {
    sudo pkill -f 'shutdown.*-h' 2>/dev/null || true
    sleep 2
    sudo shutdown -h now
}

# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------
LOG="/tmp/${SESSION_ID}.log"
: > "$LOG"

log() {
    echo "[$(date -u +%FT%TZ)] $*" | tee -a "$LOG"
}

upload_log() {
    # Upload current log to S3 under the given suffix. Best-effort: do not
    # fail the script if S3 is transiently unavailable.
    local suffix="$1"
    aws s3 cp "$LOG" "s3://$BUCKET/$LOG_PREFIX/${SESSION_ID}_${suffix}.log" 2>&1 | tee -a "$LOG" || true
}

log "=== ${SESSION_ID} launcher start ==="
log "hostname=$(hostname)"
log "bucket=$BUCKET"
log "tickers_count=$(echo $TICKERS | wc -w)"
log "start=$START_DATE end=$END_DATE batch_size=$BATCH_SIZE"
log "safety_cap_min=$SAFETY_CAP_MIN run_canonical=$RUN_CANONICAL"

# Background log-sync loop (every 120s) so progress is visible in S3.
(
    while true; do
        aws s3 cp "$LOG" "s3://$BUCKET/$LOG_PREFIX/${SESSION_ID}_progress.log" >/dev/null 2>&1 || true
        sleep 120
    done
) &
LOGSYNC_PID=$!
log "logsync_pid=$LOGSYNC_PID"

cleanup_logsync() {
    kill "$LOGSYNC_PID" 2>/dev/null || true
}

# ---------------------------------------------------------------------------
# Repo sanity + ticker-list substitution
#
# ingest_yfinance_prices.py reads scripts/ticker_lists/us_equities.txt from
# disk (no --tickers flag). Back up the original, substitute our list, and
# restore it on the way out (even on failure) so the repo isn't left dirty.
# ---------------------------------------------------------------------------
cd "$REPO_DIR" || { log "cd $REPO_DIR failed"; upload_log "final-fail-setup"; cleanup_logsync; exit 99; }

log "git status before run:"
git status 2>&1 | tee -a "$LOG" || true

TICKER_FILE="$REPO_DIR/scripts/ticker_lists/us_equities.txt"
BACKUP_FILE="$REPO_DIR/scripts/ticker_lists/us_equities.txt.${SESSION_ID}_backup"

if [ ! -f "$TICKER_FILE" ]; then
    log "ticker file missing: $TICKER_FILE"
    upload_log "final-fail-setup"
    cleanup_logsync
    exit 98
fi

cp "$TICKER_FILE" "$BACKUP_FILE"
log "ticker file backed up to $BACKUP_FILE"

# Write one ticker per line (TICKERS is space-separated input).
: > "$TICKER_FILE"
for t in $TICKERS; do
    echo "$t" >> "$TICKER_FILE"
done
log "ticker file replaced with $(wc -l < "$TICKER_FILE") tickers"

restore_tickers() {
    if [ -f "$BACKUP_FILE" ]; then
        cp "$BACKUP_FILE" "$TICKER_FILE"
        log "ticker file restored from backup"
    fi
}

# ---------------------------------------------------------------------------
# STEP 1: prices
# ---------------------------------------------------------------------------
log "=== STEP 1: ingest_yfinance_prices.py ==="
set +e
"$VENV_PY" scripts/ingest_yfinance_prices.py \
    --mode bulk \
    --asset-classes equities \
    --start "$START_DATE" \
    --end "$END_DATE" \
    --bucket "$BUCKET" \
    --batch-size "$BATCH_SIZE" \
    2>&1 | tee -a "$LOG"
STEP1_RC=${PIPESTATUS[0]}
set -e
log "step1_rc=$STEP1_RC"

# Always restore ticker file — even on failure — so repo isn't polluted.
restore_tickers

if [ "$STEP1_RC" -ne 0 ]; then
    log "STEP 1 FAILED — NOT shutting down, leaving instance alive for post-mortem"
    upload_log "final-fail-prices"
    cleanup_logsync
    exit 1
fi

# ---------------------------------------------------------------------------
# STEP 2: canonical build (optional)
# ---------------------------------------------------------------------------
if [ "$RUN_CANONICAL" = "1" ]; then
    log "=== STEP 2: build_canonical.py ==="
    set +e
    "$VENV_PY" scripts/build_canonical.py \
        --mode bulk \
        --bucket "$BUCKET" \
        2>&1 | tee -a "$LOG"
    STEP2_RC=${PIPESTATUS[0]}
    set -e
    log "step2_rc=$STEP2_RC"

    if [ "$STEP2_RC" -ne 0 ]; then
        log "STEP 2 FAILED — NOT shutting down, leaving instance alive for post-mortem"
        upload_log "final-fail-canonical"
        cleanup_logsync
        exit 1
    fi
else
    log "=== STEP 2 skipped (RUN_CANONICAL=0) ==="
fi

# ---------------------------------------------------------------------------
# SUCCESS
# ---------------------------------------------------------------------------
log "=== ALL STEPS SUCCEEDED ==="
FINAL_LOG="/tmp/${SESSION_ID}_final-success.log"
cp "$LOG" "$FINAL_LOG"
aws s3 cp "$FINAL_LOG" "s3://$BUCKET/$LOG_PREFIX/${SESSION_ID}_final-success.log" 2>&1 | tee -a "$LOG" || true

cleanup_logsync
override_safety_shutdown
