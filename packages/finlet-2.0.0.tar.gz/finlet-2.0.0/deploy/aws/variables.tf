variable "domain" {
  description = "Domain name for the Finlet application"
  type        = string
  default     = "finlet.dev"
}

variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
  default     = "us-east-1"
}

variable "instance_type" {
  description = "EC2 instance type (t3.micro is free-tier eligible)"
  type        = string
  default     = "t3.micro"
}

variable "key_pair_name" {
  description = "EC2 key pair name (legacy — SSH replaced by SSM Session Manager)"
  type        = string
  default     = ""
}

variable "alert_email" {
  description = "Email address for CloudWatch alarm notifications (used by ops monitoring)"
  type        = string
  default     = ""

  validation {
    condition     = var.alert_email != ""
    error_message = "alert_email must be set — CloudWatch alarms are silently disabled without it."
  }
}

