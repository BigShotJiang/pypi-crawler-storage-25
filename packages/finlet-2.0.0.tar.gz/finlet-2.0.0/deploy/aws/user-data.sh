#!/usr/bin/env bash
# Finlet EC2 bootstrap script — runs once on first launch via cloud-init user-data.
# Sole bootstrap script for production deployments.
set -euo pipefail
exec > >(tee /var/log/finlet-bootstrap.log) 2>&1

echo "=== Finlet bootstrap started at $(date -u) ==="

# --- Hostname ---
hostnamectl set-hostname finlet

# --- System update ---
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get upgrade -y

# --- Python 3.12 ---
# Ubuntu 22.04 ships 3.10; add deadsnakes PPA for 3.12.
apt-get install -y software-properties-common
add-apt-repository -y ppa:deadsnakes/ppa
apt-get update -y
apt-get install -y python3.12 python3.12-venv python3.12-dev

# Ensure pip is available for 3.12
curl -sS https://bootstrap.pypa.io/get-pip.py | python3.12

# --- Caddy (official apt repo) ---
apt-get install -y debian-keyring debian-archive-keyring apt-transport-https curl
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' \
  | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' \
  | tee /etc/apt/sources.list.d/caddy-stable.list
apt-get update -y
apt-get install -y caddy

# --- Utilities ---
apt-get install -y fail2ban sqlite3 awscli ufw

# --- System user ---
if ! id -u finlet &>/dev/null; then
  useradd --system --create-home --shell /bin/bash finlet
fi

# --- Application directories ---
mkdir -p /opt/finlet
chown finlet:finlet /opt/finlet

mkdir -p /home/finlet/.finlet/sessions
mkdir -p /home/finlet/.finlet/backups
chown -R finlet:finlet /home/finlet/.finlet

# --- Log directories ---
mkdir -p /var/log/caddy
chown caddy:caddy /var/log/caddy

mkdir -p /var/log/finlet
chown finlet:finlet /var/log/finlet

# --- UFW firewall (no SSH — access via SSM Session Manager) ---
ufw default deny incoming
ufw default allow outgoing
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

# --- SSM Agent (pre-installed on Ubuntu 22.04, ensure running) ---
systemctl enable snap.amazon-ssm-agent.amazon-ssm-agent
systemctl start snap.amazon-ssm-agent.amazon-ssm-agent

# --- Bootstrap .env from example ---
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ ! -f /opt/finlet/.env ]; then
    if [ -f "$SCRIPT_DIR/../.env.example" ]; then
        cp "$SCRIPT_DIR/../.env.example" /opt/finlet/.env
    elif [ -f /opt/finlet/deploy/.env.example ]; then
        cp /opt/finlet/deploy/.env.example /opt/finlet/.env
    else
        # Fallback: create a minimal .env so systemd doesn't fail on missing EnvironmentFile
        cat > /opt/finlet/.env <<'ENVEOF'
# Finlet Configuration — placeholder
# Edit this file with real values before starting the service.
FINLET_HOST=127.0.0.1
FINLET_PORT=8000
FINLET_LOG_LEVEL=info
ENVEOF
    fi
    chown finlet:finlet /opt/finlet/.env
    chmod 600 /opt/finlet/.env
    echo "WARNING: /opt/finlet/.env has been created from the example template."
    echo "         You MUST edit it and fill in real values before starting Finlet."
    echo ""
    echo "  Required production env vars (app will refuse to start without these):"
    echo "    FINLET_ENV=production"
    echo "    FINLET_MFA_SECRET=<generate with: python -c \"import secrets; print(secrets.token_hex(32))\">"
    echo "    EMAIL_BASE_URL=<your public URL, e.g. https://your-domain.com>"
else
    echo "/opt/finlet/.env already exists — not overwriting."
fi

# --- fail2ban configuration ---
echo "Configuring fail2ban..."
if [ -d /opt/finlet/deploy/fail2ban ]; then
    cp /opt/finlet/deploy/fail2ban/jail.local /etc/fail2ban/jail.local
    cp /opt/finlet/deploy/fail2ban/filter.d/finlet-auth.conf /etc/fail2ban/filter.d/finlet-auth.conf
    cp /opt/finlet/deploy/fail2ban/filter.d/finlet-api.conf /etc/fail2ban/filter.d/finlet-api.conf
    systemctl enable fail2ban
    systemctl restart fail2ban
    echo "fail2ban configured."
else
    echo "WARNING: fail2ban config not found at /opt/finlet/deploy/fail2ban — skipping."
fi

# --- Logrotate configuration ---
echo "Configuring logrotate..."
if [ -f /opt/finlet/deploy/finlet-logrotate.conf ]; then
    cp /opt/finlet/deploy/finlet-logrotate.conf /etc/logrotate.d/finlet
    echo "Logrotate configured."
else
    echo "WARNING: logrotate config not found — skipping."
fi

# --- Backup cron job ---
echo "Provisioning backup cron job..."
CRON_ENTRY="0 3 * * * /opt/finlet/deploy/backup-sqlite.sh"
crontab -u finlet -l 2>/dev/null | grep -v 'backup-sqlite' | cat - <(echo "$CRON_ENTRY") | crontab -u finlet -
echo "Backup cron job provisioned for user finlet."

# --- Bootstrap marker ---
echo "Bootstrap completed at $(date -u)" > /opt/finlet/.bootstrap-complete

echo "=== Finlet bootstrap finished at $(date -u) ==="
