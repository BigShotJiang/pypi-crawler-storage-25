# ── IAM Ingestor User ────────────────────────────────────────────────────────
# Used by scripts/ingest_daily.py to write ingestion data to S3.
# Covers: prices, fundamentals, news, sentiment, reference, economic, edgar.
# Runs outside EC2 (locally or in Lambda). Write-only access to data paths.
# For v1: IAM user with programmatic access. Migrate to Lambda role later.

resource "aws_iam_user" "ingestor" {
  name = "finlet-ingestor"

  tags = {
    Name = "finlet-ingestor"
  }
}

data "aws_iam_policy_document" "ingestor_access" {
  statement {
    sid = "AllowDataBucketWrite"
    actions = [
      "s3:PutObject",
    ]
    resources = [
      "${aws_s3_bucket.price_data.arn}/prices/daily/*",
      "${aws_s3_bucket.price_data.arn}/fundamentals/*",
      "${aws_s3_bucket.price_data.arn}/news/daily/*",
      "${aws_s3_bucket.price_data.arn}/sentiment/daily/*",
      "${aws_s3_bucket.price_data.arn}/reference/*",
      "${aws_s3_bucket.price_data.arn}/economic/*",
      "${aws_s3_bucket.price_data.arn}/edgar/*",
    ]
  }

  # GetObject needed for head_object (key_exists checks) before writing
  statement {
    sid = "AllowDataBucketRead"
    actions = [
      "s3:GetObject",
    ]
    resources = [
      "${aws_s3_bucket.price_data.arn}/prices/daily/*",
      "${aws_s3_bucket.price_data.arn}/fundamentals/*",
      "${aws_s3_bucket.price_data.arn}/news/daily/*",
      "${aws_s3_bucket.price_data.arn}/sentiment/daily/*",
      "${aws_s3_bucket.price_data.arn}/reference/*",
      "${aws_s3_bucket.price_data.arn}/economic/*",
      "${aws_s3_bucket.price_data.arn}/edgar/*",
    ]
  }

  statement {
    sid = "AllowPriceBucketList"
    actions = [
      "s3:ListBucket",
    ]
    resources = [
      aws_s3_bucket.price_data.arn,
    ]
  }
}

resource "aws_iam_user_policy" "ingestor" {
  name   = "finlet-ingestor-policy"
  user   = aws_iam_user.ingestor.name
  policy = data.aws_iam_policy_document.ingestor_access.json
}

resource "aws_iam_access_key" "ingestor" {
  user = aws_iam_user.ingestor.name
}

output "ingestor_access_key_id" {
  description = "Access key ID for the finlet-ingestor IAM user"
  value       = aws_iam_access_key.ingestor.id
}

output "ingestor_secret_access_key" {
  description = "Secret access key for the finlet-ingestor IAM user (sensitive)"
  value       = aws_iam_access_key.ingestor.secret
  sensitive   = true
}
