#!/usr/bin/env bash
# Creates the S3 bucket and DynamoDB table for Terraform remote state.
# Run once before migrating state: ./bootstrap-state.sh
set -euo pipefail

REGION="${AWS_DEFAULT_REGION:-us-east-1}"
SUFFIX=$(openssl rand -hex 4)
BUCKET="finlet-tfstate-${SUFFIX}"
TABLE="finlet-tfstate-lock"

echo "Creating state bucket: ${BUCKET}"
aws s3api create-bucket --bucket "${BUCKET}" --region "${REGION}"

aws s3api put-bucket-versioning --bucket "${BUCKET}" \
  --versioning-configuration Status=Enabled

aws s3api put-public-access-block --bucket "${BUCKET}" \
  --public-access-block-configuration \
  BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true

echo "Creating DynamoDB lock table: ${TABLE}"
aws dynamodb create-table \
  --table-name "${TABLE}" \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region "${REGION}"

echo ""
echo "State backend ready. Update deploy/aws/backend.tf with:"
echo ""
echo "  bucket = \"${BUCKET}\""
echo ""
echo "Then run: cd deploy/aws && terraform init -migrate-state"
