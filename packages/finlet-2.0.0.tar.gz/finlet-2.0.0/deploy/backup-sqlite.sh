#!/usr/bin/env bash
# Crontab entry:
# 0 3 * * * /opt/finlet/deploy/backup-sqlite.sh
#
# Safe hot backup of Finlet SQLite databases, compress, upload to S3, prune old backups.

set -euo pipefail

# --- Configuration ---
DATA_DIR="${FINLET_DATA_DIR:-/home/finlet/.finlet}"
BACKUP_DIR="${DATA_DIR}/backups"
LOG_FILE="/var/log/finlet/backup.log"
TIMESTAMP="$(date -u +%Y%m%dT%H%M%SZ)"
S3_BUCKET="${S3_BACKUP_BUCKET:-}"
LOCAL_RETENTION_DAYS=7
S3_RETENTION_DAYS=30

log() {
    echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $*" | tee -a "$LOG_FILE"
}

mkdir -p "$BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"

log "=== Finlet backup started ==="

# --- Back up critical databases (auth, leaderboard, finlet) ---
BACKUP_COUNT=0
for db in "$DATA_DIR"/*.db; do
    [ -f "$db" ] || continue

    DB_NAME="$(basename "$db" .db)"
    BACKUP_FILE="${BACKUP_DIR}/${DB_NAME}_${TIMESTAMP}.db"

    log "Backing up critical db $db -> $BACKUP_FILE"
    sqlite3 "$db" ".backup '$BACKUP_FILE'"

    log "Compressing $BACKUP_FILE"
    gzip "$BACKUP_FILE"
    BACKUP_COUNT=$((BACKUP_COUNT + 1))
done

if [ "$BACKUP_COUNT" -eq 0 ]; then
    log "No critical databases found to back up."
else
    log "Backed up $BACKUP_COUNT critical database(s)."
fi

# --- Back up session databases ---
for db in "$DATA_DIR"/sessions/*/session.db; do
    [ -f "$db" ] || continue

    SESSION_DIR="$(basename "$(dirname "$db")")"
    BACKUP_FILE="${BACKUP_DIR}/${SESSION_DIR}_${TIMESTAMP}.db"

    log "Backing up session db $db -> $BACKUP_FILE"
    sqlite3 "$db" ".backup '$BACKUP_FILE'"

    log "Compressing $BACKUP_FILE"
    gzip "$BACKUP_FILE"
    BACKUP_COUNT=$((BACKUP_COUNT + 1))
done

log "Backed up $BACKUP_COUNT total database(s)."

# --- Upload to S3 ---
if [ -n "$S3_BUCKET" ]; then
    log "Uploading backups to s3://$S3_BUCKET/backups/"
    aws s3 sync "$BACKUP_DIR/" "s3://$S3_BUCKET/backups/" \
        --exclude "*" --include "*_${TIMESTAMP}.db.gz" \
        --quiet
    log "S3 upload complete."

    # Prune S3 backups older than retention period
    log "Pruning S3 backups older than $S3_RETENTION_DAYS days..."
    CUTOFF_DATE="$(date -u -d "-${S3_RETENTION_DAYS} days" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null \
        || date -u -v-${S3_RETENTION_DAYS}d +%Y-%m-%dT%H:%M:%SZ)"
    aws s3api list-objects-v2 \
        --bucket "$S3_BUCKET" \
        --prefix "backups/" \
        --query "Contents[?LastModified<='$CUTOFF_DATE'].Key" \
        --output text \
    | tr '\t' '\n' \
    | while read -r key; do
        [ -z "$key" ] || [ "$key" = "None" ] && continue
        log "Deleting s3://$S3_BUCKET/$key"
        aws s3 rm "s3://$S3_BUCKET/$key" --quiet
    done
    log "S3 pruning complete."
else
    log "S3_BACKUP_BUCKET not set — skipping S3 upload."
fi

# --- Prune local backups ---
log "Pruning local backups older than $LOCAL_RETENTION_DAYS days..."
find "$BACKUP_DIR" -name "*.db.gz" -mtime +"$LOCAL_RETENTION_DAYS" -delete -print \
    | while read -r f; do log "Deleted $f"; done
log "Local pruning complete."

log "=== Finlet backup finished ==="
