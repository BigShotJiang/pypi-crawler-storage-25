# Finlet Operations Runbook

Production operations guide for deploying and maintaining Finlet on AWS.

---

## Prerequisites

- AWS account with free tier eligibility
- Registered domain (default: `finlet.dev`)
- AWS CLI with SSM Session Manager plugin installed
- GitHub repo with Actions enabled and secrets configured
- Terraform >= 1.5 installed locally

---

## First-Time Setup

### 1. Install Terraform

```bash
# macOS
brew install terraform

# Linux
wget -O- https://apt.releases.hashicorp.com/gpg | sudo gpg --dearmor -o /usr/share/keyrings/hashicorp-archive-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list
sudo apt-get update && sudo apt-get install terraform
```

### 2. Configure AWS Credentials

```bash
aws configure
# Enter: Access Key ID, Secret Access Key, Region (us-east-1), Output (json)
```

Or export environment variables:

```bash
export AWS_ACCESS_KEY_ID="..."
export AWS_SECRET_ACCESS_KEY="..."
export AWS_DEFAULT_REGION="us-east-1"
```

### 3. Create terraform.tfvars

```bash
cd deploy/aws
cat <<'EOF' > terraform.tfvars
domain      = "finlet.dev"
alert_email = "you@example.com"
EOF
```

### 4. Set Up Remote State Backend

```bash
cd deploy/aws
./bootstrap-state.sh
# Copy the bucket name from the output and update backend.tf
```

### 5. Provision Infrastructure

```bash
cd deploy/aws
terraform init          # Or: terraform init -migrate-state (if migrating from local state)
terraform plan          # Review changes
terraform apply         # Type "yes" to confirm
```

Save the outputs — you'll need the nameservers and SSM command.

### 5. Point Domain to Route 53

Copy the `route53_nameservers` output and update your domain registrar's nameserver records. DNS propagation can take up to 48 hours, but usually completes within 1-2 hours.

### 6. Verify Bootstrap Completed

```bash
# Connect via SSM Session Manager (use instance ID from terraform output)
aws ssm start-session --target <instance-id>

# Check cloud-init completed
cloud-init status --wait

# Verify services are installed
systemctl status caddy
python3 --version  # Should be 3.12+
```

### 7. Deploy the Application

```bash
# On the server (via SSM session)
cd /opt/finlet
git clone https://github.com/YOUR_ORG/finlet.git .

# Create environment file
cp .env.example .env
# Edit .env and fill in API keys:
#   FINNHUB_API_KEY=...
#   FRED_API_KEY=...
#   EDGAR_USER_AGENT=your-email@example.com

# Install the application
python3 -m venv .venv
source .venv/bin/activate
pip install -e .

# Start services
sudo cp deploy/Caddyfile /etc/caddy/Caddyfile
sudo cp deploy/finlet.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now finlet
sudo systemctl restart caddy
```

### 8. Verify HTTPS

```bash
curl https://finlet.dev/health
# Expected: {"status": "healthy", ...}
```

### 9. Install fail2ban (API rate limiting only — no SSH jail)

```bash
sudo apt-get install -y fail2ban
sudo cp deploy/fail2ban/jail.local /etc/fail2ban/jail.local
sudo cp deploy/fail2ban/filter.d/finlet-api.conf /etc/fail2ban/filter.d/
sudo cp deploy/fail2ban/filter.d/finlet-auth.conf /etc/fail2ban/filter.d/
sudo systemctl enable --now fail2ban
sudo fail2ban-client status
```

---

## Deploy Process

### Automatic (GitHub Actions)

Push to `main` triggers the CI/CD pipeline:
1. Tests run
2. SSM `send-command` to the instance
3. `git pull`, `pip install -e .`, restart `finlet` service

### Manual (Emergency Deploy)

```bash
aws ssm start-session --target <instance-id>
cd /opt/finlet
git pull origin main
source .venv/bin/activate
pip install -e .
sudo systemctl restart finlet
```

Verify after deploy:

```bash
curl https://finlet.dev/health
journalctl -u finlet --since "5 min ago" --no-pager
```

---

## Rollback

### Quick Rollback (Git Revert)

```bash
aws ssm start-session --target <instance-id>
cd /opt/finlet
git log --oneline -5          # Find the last good commit
git revert HEAD               # Or: git checkout <good-commit>
source .venv/bin/activate
pip install -e .
sudo systemctl restart finlet
```

### Database Rollback

SQLite backups run nightly to S3. To restore:

```bash
# List available backups
aws s3 ls s3://finlet-backups-XXXX/

# Download the backup
aws s3 cp s3://finlet-backups-XXXX/sessions-2026-03-19.tar.gz /tmp/

# Stop the service
sudo systemctl stop finlet

# Replace the session data
cd ~/.finlet
mv sessions sessions.broken
tar xzf /tmp/sessions-2026-03-19.tar.gz

# Restart
sudo systemctl start finlet
```

---

## Common Issues

### Caddy HTTPS Certificate Failures

**Symptoms:** Browser shows certificate error, Caddy logs show ACME errors.

**Causes:**
- DNS not propagated yet — wait and check: `dig finlet.dev`
- Let's Encrypt rate limit hit (5 certs per domain per week)
- Port 80 blocked — verify security group allows HTTP inbound

**Fix:**
```bash
sudo journalctl -u caddy --since "1 hour ago" | grep -i "acme\|tls\|cert"
# If DNS issue: wait for propagation
# If rate limit: wait 1 week or use staging endpoint temporarily
```

### systemd Restart Loops

**Symptoms:** Service shows `activating (auto-restart)` repeatedly.

**Diagnose:**
```bash
journalctl -u finlet -n 50 --no-pager
```

**Common causes:**
- Missing `.env` file or API keys
- Python import errors (missing dependency)
- Port already in use

**Fix:**
```bash
# Check environment
cat /opt/finlet/.env

# Test manually
cd /opt/finlet && source .venv/bin/activate
finlet serve  # See the actual error

# If port conflict
sudo lsof -i :8000
```

### Disk Full

**Symptoms:** Health endpoint returns `"status": "degraded"` or write errors in logs.

**Diagnose:**
```bash
df -h /
du -sh ~/.finlet/sessions/* | sort -rh | head -10
```

**Fix:**
```bash
# Remove old session databases
find ~/.finlet/sessions -name "*.db" -mtime +30 -delete

# Prune journal logs
sudo journalctl --vacuum-size=100M

# If persistent: resize EBS volume in AWS Console, then:
sudo growpart /dev/xvda 1
sudo resize2fs /dev/xvda1
```

### SQLite "Database is Locked"

**Symptoms:** 500 errors with "database is locked" in logs.

**Causes:** Long-running transaction, concurrent writers, backup process holding lock.

**Fix:**
```bash
# Check for processes holding the file
fuser ~/.finlet/sessions/*/session.db

# If backup is running, wait for it to complete
# If a stuck process, restart the service
sudo systemctl restart finlet
```

### fail2ban False Positives

**Symptoms:** Legitimate users getting blocked (403 from firewall).

**Diagnose:**
```bash
sudo fail2ban-client status finlet-api
sudo fail2ban-client status finlet-auth
```

**Fix:**
```bash
# Unban a specific IP
sudo fail2ban-client set finlet-api unbanip <IP>
sudo fail2ban-client set finlet-auth unbanip <IP>

# Check what matched
sudo fail2ban-regex /var/log/caddy/finlet-access.log /etc/fail2ban/filter.d/finlet-api.conf
```

---

## Monitoring

### Health Endpoint

```bash
# Quick check
curl -s https://finlet.dev/health | python3 -m json.tool

# Expected response:
# {
#     "status": "healthy",
#     "db_connected": true,
#     "disk_free_gb": 5.23,
#     "disk_usage_percent": 34.7,
#     "uptime_seconds": 86421.3,
#     "version": "0.1.0",
#     "timestamp": "2026-03-20T12:00:00+00:00"
# }
```

Status meanings:
- `healthy` — All checks pass
- `degraded` — Disk usage above 85%
- `unhealthy` — Database connectivity failed

### Application Logs

```bash
# Live tail
journalctl -u finlet -f

# Last hour
journalctl -u finlet --since "1 hour ago" --no-pager

# Errors only
journalctl -u finlet -p err --since today
```

### Caddy Access Logs

```bash
# Live tail (JSON format)
tail -f /var/log/caddy/finlet-access.log | python3 -m json.tool

# Count requests per IP in last hour
cat /var/log/caddy/finlet-access.log | python3 -c "
import json, sys, collections
ips = collections.Counter()
for line in sys.stdin:
    try:
        entry = json.loads(line)
        ips[entry.get('request', {}).get('remote_ip', 'unknown')] += 1
    except: pass
for ip, count in ips.most_common(20):
    print(f'{count:>6}  {ip}')
"
```

### CloudWatch

Alarms are configured for:
- **CPU > 80% for 5 min** — Consider upgrading instance type
- **Status Check Failed** — Instance is unreachable or has hardware issues

Email notifications go to the `alert_email` configured in terraform.tfvars.

View in AWS Console: CloudWatch > Alarms > filter by "finlet".

---

## Scaling Checklist

When the single t3.micro instance is no longer sufficient:

| Trigger | Action | Notes |
|---------|--------|-------|
| Sustained CPU > 60% or RAM constrained | t3.micro -> t3.small | Change `instance_type` in terraform.tfvars, `terraform apply` |
| SQLite DB > 1 GB, need concurrent writes | Add RDS PostgreSQL | Requires code changes to connection layer |
| Need zero-downtime deploys | Add ALB + Auto Scaling Group | Significant terraform changes |
| Managing EC2 is overhead | Move to ECS/Fargate | Container-based deploys, more managed |
| High dashboard traffic | Add CloudFront CDN | Global edge caching for static assets |
| Need shared rate limiting/sessions | Add Redis (ElastiCache) | Shared state across instances |

---

## Backup & Restore

### Schedule

- **Daily at 3:00 AM UTC** — Automated backup via cron/systemd timer
- SQLite databases compressed and uploaded to S3
- S3 versioning protects against accidental overwrites
- Objects expire after 90 days (configurable in terraform)

### Manual Backup

```bash
cd ~/.finlet
tar czf /tmp/finlet-backup-$(date +%Y%m%d).tar.gz sessions/
aws s3 cp /tmp/finlet-backup-$(date +%Y%m%d).tar.gz s3://finlet-backups-XXXX/
```

### Test Restore Procedure (Monthly)

```bash
# Download latest backup
aws s3 cp s3://finlet-backups-XXXX/sessions-latest.tar.gz /tmp/

# Extract to temp location
mkdir /tmp/finlet-restore-test
tar xzf /tmp/sessions-latest.tar.gz -C /tmp/finlet-restore-test

# Verify files are valid SQLite
for db in /tmp/finlet-restore-test/sessions/*/session.db; do
    sqlite3 "$db" "SELECT count(*) FROM sqlite_master;" && echo "OK: $db" || echo "CORRUPT: $db"
done

# Clean up
rm -rf /tmp/finlet-restore-test
```

---

## Security Incident Response

### 1. Assess

```bash
# Check fail2ban for blocked IPs
sudo fail2ban-client status
sudo fail2ban-client status finlet-api
sudo fail2ban-client status finlet-auth

# Review access logs for suspicious patterns
cat /var/log/caddy/finlet-access.log | python3 -c "
import json, sys
for line in sys.stdin:
    try:
        e = json.loads(line)
        status = e.get('status', 0)
        if status >= 400:
            print(f'{status} {e.get(\"request\",{}).get(\"method\",\"?\")} {e.get(\"request\",{}).get(\"uri\",\"?\")} from {e.get(\"request\",{}).get(\"remote_ip\",\"?\")}')
    except: pass
"

# Review SSM session history for unauthorized access
aws ssm describe-sessions --state History --max-results 20
```

### 2. Contain

```bash
# EMERGENCY: Block all inbound traffic except your IP
# In AWS Console: modify finlet-sg inbound rules
# Or via CLI:
aws ec2 revoke-security-group-ingress --group-name finlet-sg --protocol tcp --port 80 --cidr 0.0.0.0/0
aws ec2 revoke-security-group-ingress --group-name finlet-sg --protocol tcp --port 443 --cidr 0.0.0.0/0
```

### 3. Remediate

```bash
# Rotate API keys in .env
sudo systemctl stop finlet
vim /opt/finlet/.env   # Update all API keys
sudo systemctl start finlet

# Invalidate all sessions (deletes in-memory state)
sudo systemctl restart finlet

# If IAM credentials compromised: rotate access keys, review SSM session history
```

### 4. Recover

```bash
# Restore security group rules
aws ec2 authorize-security-group-ingress --group-name finlet-sg --protocol tcp --port 80 --cidr 0.0.0.0/0
aws ec2 authorize-security-group-ingress --group-name finlet-sg --protocol tcp --port 443 --cidr 0.0.0.0/0

# Verify services
curl https://finlet.dev/health
```

### 5. Document

Record the incident: what happened, how it was detected, what was done, and what preventive measures to add.
