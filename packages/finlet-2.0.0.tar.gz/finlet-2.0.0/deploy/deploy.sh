#!/usr/bin/env bash
# Finlet Deploy Script
# Pre-deploy: backup DB + tag current commit.
# Deploy: pull latest code, install dependencies, restart service.
# Post-deploy: health check. If it fails -> automatic rollback.

set -euo pipefail

trap 'log "TRAP: command failed at line $LINENO (exit status $?): $BASH_COMMAND"' ERR

# --- Configuration ---
APP_DIR="${FINLET_APP_DIR:-/opt/finlet}"
DATA_DIR="${FINLET_DATA_DIR:-/home/finlet/.finlet}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"
SERVICE_NAME="finlet"
HEALTH_URL="${FINLET_HEALTH_URL:-http://127.0.0.1:8000/health}"
HEALTH_RETRIES=5
HEALTH_WAIT=3
LOG_FILE="/var/log/finlet/deploy.log"
TIMESTAMP="$(date -u +%Y%m%dT%H%M%SZ)"

log() {
    echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $*" | tee -a "$LOG_FILE"
}

die() {
    log "FATAL: $*"
    exit 1
}

mkdir -p "$(dirname "$LOG_FILE")"

log "=== Finlet deploy started ==="

# SSM runs this script as root, but /opt/finlet is owned by user 'finlet'.
# Git's safe.directory check rejects operations in repos owned by a different
# user, causing rev-parse to fail silently and skipping both tagging and pull.
cd "$APP_DIR"
export HOME="${HOME:-/root}"
git config --global --add safe.directory "$APP_DIR"

# Ensure GitHub SSH host key is trusted (SSM root shell may lack known_hosts)
mkdir -p "$HOME/.ssh"
ssh-keyscan -t ed25519,rsa github.com >> "$HOME/.ssh/known_hosts" 2>/dev/null

# --- Pre-deploy steps (skip on re-exec — already done before git pull) ---
if [ -z "${_FINLET_DEPLOY_REEXEC:-}" ]; then

    # --- Pre-deploy Step 1: Backup database ---
    log "Running pre-deploy database backup..."

    BACKUP_SCRIPT="$SCRIPT_DIR/backup-sqlite.sh"
    if [ ! -f "$BACKUP_SCRIPT" ]; then
        BACKUP_SCRIPT="$APP_DIR/backup-sqlite.sh"
    fi

    if [ -f "$BACKUP_SCRIPT" ] && [ -x "$BACKUP_SCRIPT" ]; then
        "$BACKUP_SCRIPT"
        log "Pre-deploy backup completed."
    else
        log "WARNING: Backup script not found or not executable at $BACKUP_SCRIPT."
        log "Continuing without backup — THIS IS NOT RECOMMENDED."
    fi

    # --- Pre-deploy Step 1b: Provision backup cron job ---
    log "Provisioning backup cron job..."
    CRON_BACKUP_SCRIPT="$APP_DIR/deploy/backup-sqlite.sh"
    CRON_ENTRY="0 3 * * * $CRON_BACKUP_SCRIPT"
    { crontab -u finlet -l 2>/dev/null | grep -v 'backup-sqlite' || true; echo "$CRON_ENTRY"; } | crontab -u finlet -
    log "Backup cron job provisioned for user finlet: $CRON_ENTRY"

    # --- Pre-deploy Step 2: Tag current commit ---
    if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
        CURRENT_COMMIT="$(git rev-parse --short HEAD)"
        TAG_NAME="pre-deploy-${TIMESTAMP}-${CURRENT_COMMIT}"

        # Remove stale pre-deploy tags (keep last 10)
        STALE_TAGS="$(git tag -l 'pre-deploy-*' --sort=-creatordate | tail -n +11 || true)"
        if [ -n "$STALE_TAGS" ]; then
            echo "$STALE_TAGS" | xargs git tag -d 2>/dev/null || true
        fi

        git tag "$TAG_NAME"
        log "Tagged current commit as $TAG_NAME."
    else
        log "WARNING: Not a git repo — skipping commit tagging."
    fi

    # --- Deploy Step 1: Pull latest code ---
    log "Pulling latest code..."
    if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
        BRANCH="${DEPLOY_BRANCH:-main}"
        git fetch origin "$BRANCH"
        git checkout "$BRANCH"
        git reset --hard "origin/$BRANCH"
        log "Checked out latest $BRANCH."

        # Re-exec: git reset --hard replaced this script on disk, but bash
        # is still reading the OLD version via its open file descriptor.
        # Re-exec ensures pip install and all subsequent steps come from
        # the NEW deploy.sh.  Pre-deploy steps are skipped (already done).
        export _FINLET_DEPLOY_REEXEC=1
        log "Re-executing deploy.sh to pick up updated script from $BRANCH."
        exec bash "$SCRIPT_DIR/deploy.sh" "$@"
    else
        log "Not a git repo — skipping code pull."
    fi

fi  # end pre-deploy / re-exec guard

# --- Deploy Step 2: Install/update dependencies ---
log "Installing dependencies..."
if [ -f "$APP_DIR/.venv/bin/activate" ]; then
    source "$APP_DIR/.venv/bin/activate"
    pip install --quiet --upgrade pip
    pip install --quiet --no-cache-dir -e ".[server]"
    deactivate
    log "Dependencies installed."
else
    log "WARNING: No virtualenv found at $APP_DIR/.venv — skipping pip install."
fi

# --- Deploy Step 3: Run database migrations ---
# Migrations must run as the finlet user because FINLET_DIR resolves via
# Path.home() — running as root would target /root/.finlet/ instead of
# /home/finlet/.finlet/ where the real production databases live.
if sudo -u finlet "$APP_DIR/.venv/bin/python" -c "from finlet.db.migrations.runner import run_migrations; run_migrations()"; then
    log "Database migrations applied."
else
    die "Database migrations failed — aborting deploy (the service would crash anyway)."
fi

# --- Deploy Step 4: Copy service files and config ---
log "Copying service files and configs..."
if [ -f "$APP_DIR/deploy/finlet.service" ]; then
    sudo cp "$APP_DIR/deploy/finlet.service" /etc/systemd/system/finlet.service
fi
if [ -f "$APP_DIR/deploy/finlet-mcp.service" ]; then
    sudo cp "$APP_DIR/deploy/finlet-mcp.service" /etc/systemd/system/finlet-mcp.service
fi
if [ -f "$APP_DIR/deploy/Caddyfile" ]; then
    sudo cp "$APP_DIR/deploy/Caddyfile" /etc/caddy/Caddyfile
fi
if [ -f "$APP_DIR/deploy/finlet-logrotate.conf" ]; then
    sudo cp "$APP_DIR/deploy/finlet-logrotate.conf" /etc/logrotate.d/finlet
fi
sudo systemctl daemon-reload

# --- Deploy Step 4b: Resolve S3 bucket names (env → SSM → fail) and persist ---
# Canonical source of truth is SSM Parameter Store under /finlet/prod/*.
# The GitHub Actions workflow *may* pass FINLET_*_BUCKET env vars, but if a
# secret drifts (or Actions billing lapses) the deploy must not silently fall
# back to the code default "finlet-data" — that's the exact bug that hid
# 163 UBER partitions for a day on 2026-04-17. SSM is authoritative.
ENV_FILE="$APP_DIR/.env"
SSM_REGION="${AWS_REGION:-us-east-1}"

resolve_bucket_from_ssm() {
    local name="$1"
    aws ssm get-parameter \
        --name "/finlet/prod/${name}" \
        --region "$SSM_REGION" \
        --query 'Parameter.Value' \
        --output text 2>/dev/null || true
}

write_env_var() {
    local name="$1"
    local value="$2"
    if [ -f "$ENV_FILE" ] && grep -q "^${name}=" "$ENV_FILE"; then
        # BSD/GNU sed compat: write to tmp and move (avoids -i portability issues)
        sed "s|^${name}=.*|${name}=${value}|" "$ENV_FILE" > "${ENV_FILE}.tmp" && mv "${ENV_FILE}.tmp" "$ENV_FILE"
        log "Updated ${name} in $ENV_FILE."
    else
        echo "${name}=${value}" >> "$ENV_FILE"
        log "Wrote ${name} to $ENV_FILE."
    fi
}

resolve_and_persist_bucket() {
    local name="$1"
    # Dereference the env var named by $name (e.g. FINLET_PRICE_BUCKET)
    local env_value="${!name:-}"

    if [ -n "$env_value" ]; then
        log "$name resolved from env."
        write_env_var "$name" "$env_value"
        eval "${name}_RESOLVED=\"\$env_value\""
        return 0
    fi

    local ssm_value
    ssm_value=$(resolve_bucket_from_ssm "$name")
    if [ -n "$ssm_value" ] && [ "$ssm_value" != "None" ]; then
        log "$name resolved from SSM (/finlet/prod/${name})."
        write_env_var "$name" "$ssm_value"
        eval "${name}_RESOLVED=\"\$ssm_value\""
        return 0
    fi

    die "$name is not set via env or SSM Parameter Store (/finlet/prod/${name}). \
Refusing to deploy with silent fallback to code default 'finlet-data' — \
that would hide freshly-ingested data from the API."
}

resolve_and_persist_bucket FINLET_PRICE_BUCKET
resolve_and_persist_bucket FINLET_FUNDAMENTALS_BUCKET
# Function name is misleading: works for any env var sourced from /finlet/prod/<NAME>.
# GDPR Item G needs FINLET_DELETION_HASH_SALT to produce non-empty audit hashes.
resolve_and_persist_bucket FINLET_DELETION_HASH_SALT

# --- Deploy Step 4d: Clear stale price cache ---
# The PricePlugin caches S3 parquet files locally at $DATA_DIR/cache/prices/
# with a 24h TTL. When ingest overwrites an S3 object (e.g. merging in
# newly-backfilled UBER rows), the local cache holds the pre-overwrite copy
# for up to 24h and silently hides the new data. Clearing on every deploy is
# cheap (files re-download on first request) and makes deploys a natural
# refresh boundary. Root cause of Bug 1 on 2026-04-17.
PRICE_CACHE_DIR="$DATA_DIR/cache/prices"
if [ -d "$PRICE_CACHE_DIR" ]; then
    # bug-hunt 20260428T073733Z0944: use `find` (exits 0 on empty) instead of `ls *.parquet`
    # which under set -e -o pipefail dies when the glob has no matches.
    CACHE_COUNT=$(find "$PRICE_CACHE_DIR" -maxdepth 1 -name '*.parquet' -type f -print 2>/dev/null | wc -l | tr -d ' ')
    if [ "$CACHE_COUNT" -gt 0 ]; then
        sudo -u finlet find "$PRICE_CACHE_DIR" -maxdepth 1 -name '*.parquet' -type f -delete 2>/dev/null || true
        log "Cleared $CACHE_COUNT stale price-cache parquet(s) from $PRICE_CACHE_DIR."
    else
        log "Price cache at $PRICE_CACHE_DIR is already empty — nothing to clear."
    fi
else
    log "Price cache dir $PRICE_CACHE_DIR does not exist yet — skipping clear."
fi

# --- Deploy Step 5: Restart services ---
# Defense-in-depth: capture pre-restart MainPID and assert it flipped
# post-restart. systemctl restart can silently no-op under some systemd
# transactions — bug bit run 25954130891 on 2026-05-16 (d0461d6 deploy)
# and shipped soft-success with stale workers. See
# docs/handoffs/2026-05-16-next-session-deploy-restart-defense-in-depth.md
# and memory feedback_deploy_restart_silent_failure.md.
OLD_PID=$(systemctl show "$SERVICE_NAME" --property=MainPID --value 2>/dev/null || echo "0")
log "Pre-restart $SERVICE_NAME MainPID: $OLD_PID"

log "Restarting $SERVICE_NAME service..."
sudo systemctl restart "$SERVICE_NAME"

# systemctl returns immediately on async restart; the new master needs
# ~1-3s to fork workers under uvicorn default config.
sleep 3

NEW_PID=$(systemctl show "$SERVICE_NAME" --property=MainPID --value 2>/dev/null || echo "0")
log "Post-restart $SERVICE_NAME MainPID: $NEW_PID"

# Edge case: first-ever deploy on a fresh box has OLD_PID=0 (service not
# yet running). Skip the equality check on cold start; future deploys
# will see a non-zero OLD_PID and assert turnover.
if [ "$OLD_PID" != "0" ] && [ "$OLD_PID" = "$NEW_PID" ]; then
    die "Service restart no-op: $SERVICE_NAME MainPID unchanged ($OLD_PID). systemctl restart did not flip workers — refusing to declare deploy success. Manually verify with 'systemctl status $SERVICE_NAME' and 'journalctl -u $SERVICE_NAME -n 50'."
fi

if systemctl is-enabled finlet-mcp >/dev/null 2>&1; then
    OLD_MCP_PID=$(systemctl show finlet-mcp --property=MainPID --value 2>/dev/null || echo "0")
    log "Pre-restart finlet-mcp MainPID: $OLD_MCP_PID"
    log "Restarting finlet-mcp service..."
    sudo systemctl restart finlet-mcp
    sleep 3
    NEW_MCP_PID=$(systemctl show finlet-mcp --property=MainPID --value 2>/dev/null || echo "0")
    log "Post-restart finlet-mcp MainPID: $NEW_MCP_PID"
    if [ "$OLD_MCP_PID" != "0" ] && [ "$OLD_MCP_PID" = "$NEW_MCP_PID" ]; then
        die "finlet-mcp restart no-op: MainPID unchanged ($OLD_MCP_PID). systemctl restart did not flip workers — refusing to declare deploy success."
    fi
fi
if systemctl is-active caddy >/dev/null 2>&1; then
    log "Reloading Caddy..."
    sudo systemctl reload caddy
fi

# Wait for service to settle
sleep "$HEALTH_WAIT"

# --- Post-deploy: Health check + git_sha cross-check ---
# Closing assert: even with a fresh MainPID, the workers must report the
# deployed git SHA via /v1/health.git_sha. Catches the new-master-but-
# stale-children scenario. See Phase 2 of the defense-in-depth handoff.
EXPECTED_SHA=$(git -C "$APP_DIR" rev-parse --short HEAD)
log "Expected git_sha after deploy: $EXPECTED_SHA"

log "Running post-deploy health check..."
HEALTH_OK=false
SHA_OK=false
ACTUAL_SHA="missing"

for i in $(seq 1 "$HEALTH_RETRIES"); do
    HEALTH_BODY="$(curl -sf --max-time 5 "$HEALTH_URL" 2>/dev/null || echo "")"
    if [ -n "$HEALTH_BODY" ]; then
        HEALTH_OK=true
        ACTUAL_SHA="$(echo "$HEALTH_BODY" | python3 -c "import sys, json; print(json.loads(sys.stdin.read()).get('git_sha', 'missing'))" 2>/dev/null || echo "missing")"
        log "Health check $i/$HEALTH_RETRIES: HTTP 200, git_sha=$ACTUAL_SHA (expected $EXPECTED_SHA)."
        if [ "$ACTUAL_SHA" = "$EXPECTED_SHA" ]; then
            SHA_OK=true
            break
        fi
        log "Health check $i/$HEALTH_RETRIES: SHA mismatch, waiting ${HEALTH_WAIT}s for workers to catch up..."
    else
        log "Health check $i/$HEALTH_RETRIES: no response, waiting ${HEALTH_WAIT}s..."
    fi
    sleep "$HEALTH_WAIT"
done

if [ "$HEALTH_OK" != true ]; then
    log "ERROR: Post-deploy health check failed: workers did not return HTTP 200 within retry budget ($HEALTH_RETRIES attempts)."
elif [ "$SHA_OK" = true ]; then
    log "Deploy successful. Service is healthy at git_sha=$ACTUAL_SHA."
    log "=== Finlet deploy finished successfully ==="
    exit 0
else
    die "Post-deploy SHA mismatch: workers report git_sha=$ACTUAL_SHA but deployed $EXPECTED_SHA. The restart fired but workers are running stale code. Manually verify with 'systemctl status $SERVICE_NAME' and 'curl $HEALTH_URL'."
fi

# --- Health check failed: automatic rollback ---
log "ERROR: Health check failed after $HEALTH_RETRIES attempts."
log "Initiating automatic rollback..."

ROLLBACK_SCRIPT="$SCRIPT_DIR/rollback.sh"
if [ ! -f "$ROLLBACK_SCRIPT" ]; then
    ROLLBACK_SCRIPT="$APP_DIR/rollback.sh"
fi

if [ -f "$ROLLBACK_SCRIPT" ] && [ -x "$ROLLBACK_SCRIPT" ]; then
    "$ROLLBACK_SCRIPT"
    log "Automatic rollback completed."
else
    log "CRITICAL: Rollback script not found at $ROLLBACK_SCRIPT!"
    log "Manual intervention required."
    log "  1. Check service: sudo systemctl status $SERVICE_NAME"
    log "  2. View logs:     sudo journalctl -u $SERVICE_NAME -n 100"
    log "  3. Manual rollback: git checkout $TAG_NAME && sudo systemctl restart $SERVICE_NAME"
fi

log "=== Finlet deploy finished with errors ==="
exit 1
