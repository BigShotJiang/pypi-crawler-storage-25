-- Migration: 004_cto_approvals.sql
-- Purpose: Async approval queue for CTO escalations (severity=high|critical) and
--          workflow-fixer proposals. Supervisor does NOT block on Discord
--          sendAndWait — it INSERTs a pending row, posts a Discord message with
--          a short approval token, and exits. A separate poll-and-resume
--          workflow (Task #6: workflow-fixer) reads pending rows, watches for
--          user resolution (Discord reaction / slash command / web UI — TBD),
--          flips status, and resumes the paused task.
-- Target:  ops-postgres (Postgres 16-alpine), database `ops`, schema `ops`.
-- Author:  Finlet ops team
-- Depends: 001_cto_state.sql (FK to ops.cto_state.task_id, ON DELETE SET NULL)
--          002_cto_decisions.sql (FK to ops.cto_decisions.id, ON DELETE SET NULL)
--          pgcrypto (for gen_random_uuid() — optional; supervisor can also
--          generate the UUID in JS and pass it in).
-- Apply with: docker exec -i ops-postgres psql -U ops -d ops < 004_cto_approvals.sql
--
-- NOTE: ops.cto_approvals is the durable queue; Discord message id is stored so
--       reaction-based resolution can find the row without a lookup on content.
--       All status transitions are via UPDATE — no DELETE path in normal ops.

BEGIN;

-- pgcrypto provides gen_random_uuid(); idempotent — safe to re-run.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ----------------------------------------------------------------------------
-- Table: ops.cto_approvals
-- One row per escalation/approval request. Lifecycle:
--   pending -> approved | rejected | timed_out | auto_acted
-- auto_acted is reserved for future "if user doesn't respond within N, auto
-- take the proposed_action" behaviour (not MVP).
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ops.cto_approvals (
    id                   BIGSERIAL    PRIMARY KEY,
    requested_at         TIMESTAMPTZ  NOT NULL DEFAULT now(),
    task_id              UUID         REFERENCES ops.cto_state(task_id)     ON DELETE SET NULL,
    decision_id          BIGINT       REFERENCES ops.cto_decisions(id)      ON DELETE SET NULL,
    severity             TEXT         NOT NULL
        CHECK (severity IN ('high','critical')),  -- low/medium/info auto-act; high/critical queue
    prompt_text          TEXT         NOT NULL,   -- the question posed to the user
    proposed_action      JSONB        NOT NULL,   -- what the CTO will do if approved
    status               TEXT         NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending','approved','rejected','timed_out','auto_acted')),
    resolved_at          TIMESTAMPTZ,
    resolved_by          TEXT,                     -- Discord user ID or 'cron_timeout' / 'cron_auto_act'
    resolution_notes     TEXT,
    discord_message_id   TEXT                      -- stored for reaction-based resolution
);

-- ----------------------------------------------------------------------------
-- Indexes
-- ----------------------------------------------------------------------------
-- Queue scan: pending rows by age (workflow-fixer's poll cadence).
CREATE INDEX IF NOT EXISTS idx_cto_approvals_pending_requested_at
    ON ops.cto_approvals (requested_at)
    WHERE status = 'pending';

-- Status + time (digest / audit queries).
CREATE INDEX IF NOT EXISTS idx_cto_approvals_status_requested_at
    ON ops.cto_approvals (status, requested_at DESC);

-- FK-supporting indexes (Postgres doesn't auto-create them for REFERENCES).
CREATE INDEX IF NOT EXISTS idx_cto_approvals_task_id
    ON ops.cto_approvals (task_id);
CREATE INDEX IF NOT EXISTS idx_cto_approvals_decision_id
    ON ops.cto_approvals (decision_id);

-- Discord message id (reaction-based resolver lookup).
CREATE INDEX IF NOT EXISTS idx_cto_approvals_discord_message_id
    ON ops.cto_approvals (discord_message_id)
    WHERE discord_message_id IS NOT NULL;

-- ----------------------------------------------------------------------------
-- Grants: match the convention used in init-db.sql and migrations 001/002/003.
-- BIGSERIAL implicitly creates a sequence; grant on it so inserts work from
-- the `ops` role even if default privileges drift.
-- ----------------------------------------------------------------------------
GRANT ALL PRIVILEGES ON ops.cto_approvals TO ops;
GRANT ALL PRIVILEGES ON SEQUENCE ops.cto_approvals_id_seq TO ops;

COMMIT;

-- ============================================================================
-- ROLLBACK (run manually if you need to reverse this migration)
-- ============================================================================
-- BEGIN;
--   DROP TABLE IF EXISTS ops.cto_approvals CASCADE;
--   -- The BIGSERIAL sequence is dropped implicitly with the table.
--   -- pgcrypto extension is left in place — harmless and may be used elsewhere.
-- COMMIT;
--
-- Note: rollback drops the table only. Foreign keys into ops.cto_state and
-- ops.cto_decisions disappear with it; neither parent table is affected.
