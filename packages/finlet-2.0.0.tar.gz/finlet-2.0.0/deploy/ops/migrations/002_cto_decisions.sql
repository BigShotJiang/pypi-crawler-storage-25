-- Migration: 002_cto_decisions.sql
-- Purpose: Append-only audit log of every CTO decision AND every user<->CTO
--          Discord message. Provides conversation continuity across ephemeral
--          CTO spawns plus a searchable record of why each decision was made.
-- Target:  ops-postgres (Postgres 16-alpine), database `ops`, schema `ops`.
-- Author:  Finlet ops team
-- Depends: 001_cto_state.sql (foreign key to ops.cto_state.task_id).
-- Apply with: docker exec -i ops-postgres psql -U ops -d ops < 002_cto_decisions.sql
--
-- NOTE: This is a DRAFT. Do not apply without review. See the rollback section
--       at the bottom for reversal.

BEGIN;

-- ----------------------------------------------------------------------------
-- Table: ops.cto_decisions
-- Append-only. No UPDATE path in normal operation — every decision, correction,
-- escalation, and Discord message gets its own row. Drives three consumers:
--   1. Conversation replay for ephemeral CTO re-spawns (read by decided_at DESC).
--   2. Postmortems and audit: why did the CTO do X at time Y?
--   3. Full-text search over rationale/event_summary (weighted tsvector).
--
-- tsv column is STORED GENERATED — written on INSERT, not queried at runtime,
-- so the GIN index stays fast even under write load.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ops.cto_decisions (
    id             BIGSERIAL    PRIMARY KEY,
    decided_at     TIMESTAMPTZ  NOT NULL DEFAULT now(),
    task_id        UUID         REFERENCES ops.cto_state(task_id) ON DELETE SET NULL,
    event_type     TEXT         NOT NULL,  -- 'discord_user_msg','discord_cto_reply','dispatch','correction','escalate','pause','resume','approve','reject','workflow_fix_proposed','workflow_fix_approved',...
    event_summary  TEXT         NOT NULL,  -- human-readable one-liner
    action         TEXT,                   -- machine action taken, if any (e.g. 'dispatch:specialist-swe', 'escalate:user')
    rationale      TEXT,                   -- why CTO made this call — searchable
    inputs         JSONB        NOT NULL DEFAULT '{}'::jsonb,  -- event payload / relevant state snapshot
    outputs        JSONB        NOT NULL DEFAULT '{}'::jsonb,  -- downstream effects (messages sent, workflows dispatched, etc.)
    tsv            TSVECTOR     GENERATED ALWAYS AS (
        setweight(to_tsvector('english', coalesce(event_summary, '')), 'A') ||
        setweight(to_tsvector('english', coalesce(rationale,     '')), 'B') ||
        setweight(to_tsvector('english', coalesce(action,        '')), 'C')
    ) STORED
);

-- ----------------------------------------------------------------------------
-- Indexes
-- ----------------------------------------------------------------------------
-- Timeline scan: "show me the last N decisions" — dominant read pattern.
CREATE INDEX IF NOT EXISTS idx_cto_decisions_decided_at
    ON ops.cto_decisions(decided_at DESC);

-- "Show me everything that happened for task X" — conversation replay.
CREATE INDEX IF NOT EXISTS idx_cto_decisions_task_id
    ON ops.cto_decisions(task_id);

-- Filter by event type (e.g. all escalations in the last 24h).
CREATE INDEX IF NOT EXISTS idx_cto_decisions_event_type
    ON ops.cto_decisions(event_type, decided_at DESC);

-- Full-text search across rationale + summary + action.
CREATE INDEX IF NOT EXISTS idx_cto_decisions_tsv
    ON ops.cto_decisions USING GIN (tsv);

-- ----------------------------------------------------------------------------
-- Grants: match the convention used in init-db.sql.
-- BIGSERIAL implicitly creates a sequence; grant on it so inserts work from
-- the `ops` role even if default privileges drift.
-- ----------------------------------------------------------------------------
GRANT ALL PRIVILEGES ON ops.cto_decisions TO ops;
GRANT ALL PRIVILEGES ON SEQUENCE ops.cto_decisions_id_seq TO ops;

COMMIT;

-- ============================================================================
-- ROLLBACK (run manually if you need to reverse this migration)
-- ============================================================================
-- BEGIN;
--   DROP TABLE IF EXISTS ops.cto_decisions CASCADE;
--   -- The BIGSERIAL sequence is dropped implicitly with the table.
-- COMMIT;
--
-- Note: rollback drops the table only. The foreign key from cto_decisions.task_id
-- to ops.cto_state(task_id) disappears with it, so rolling back 002 alone leaves
-- ops.cto_state intact. Roll back 001 separately if you want a clean slate.
