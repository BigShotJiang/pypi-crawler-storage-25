-- Migration: 008_cto_approvals_status_extended.sql
-- Purpose: Extend ops.cto_approvals.status CHECK constraint to include two
--          new terminal states emitted by Task #8's cron-heartbeat-5min
--          workflow when it applies workflow-fixer patches:
--            - `applied`     — heartbeat successfully applied patches
--                              from an approved row
--            - `apply_failed`— apply attempt raised (n8n REST 4xx/5xx,
--                              JSON parse error, target workflow 404, etc.)
--          Without this migration, heartbeat Branch C's UPDATE would violate
--          the existing CHECK and the row would stay at status='approved',
--          causing the 5-min poll to retry forever.
-- Target:  ops-postgres (Postgres 16-alpine), database `ops`, schema `ops`.
-- Author:  Finlet ops team
-- Depends: 004_cto_approvals.sql (defines the original CHECK with 5 states).
-- Apply with: docker exec -i ops-postgres psql -U ops -d ops < 008_cto_approvals_status_extended.sql

BEGIN;

ALTER TABLE ops.cto_approvals DROP CONSTRAINT IF EXISTS cto_approvals_status_check;

ALTER TABLE ops.cto_approvals ADD CONSTRAINT cto_approvals_status_check
    CHECK (status IN (
        'pending',
        'approved',
        'rejected',
        'timed_out',
        'auto_acted',
        'applied',
        'apply_failed'
    ));

COMMIT;

-- Rollback:
-- BEGIN;
-- ALTER TABLE ops.cto_approvals DROP CONSTRAINT cto_approvals_status_check;
-- ALTER TABLE ops.cto_approvals ADD CONSTRAINT cto_approvals_status_check
--     CHECK (status IN ('pending','approved','rejected','timed_out','auto_acted'));
-- COMMIT;
-- Note: rollback will fail if any rows have status IN ('applied','apply_failed').
