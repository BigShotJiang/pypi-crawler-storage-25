-- Migration: 007_artifact_workflow_fixer.sql
-- Purpose: (a) Extend the ops.cto_artifacts.workflow_name CHECK constraint to
--              include `workflow-fixer`, the meta-workflow introduced by
--              Task #6 of CTO orchestration Phase 3. `intake` is already
--              allowed via migration 005. Both are MVP meta-workflows: intake
--              is the front-door classifier (routes raw human / machine
--              signals to the supervisor); workflow-fixer proposes
--              prompt/tool patches to failing target workflows and queues
--              them for user approval in ops.cto_approvals (apply path
--              lands in Task #8).
--          (b) Fix the STORED GENERATED content_sha256 column to use
--              digest(content, 'sha256') (pgcrypto) instead of
--              sha256(content::bytea). The original expression broke
--              inserts whenever `content` contained byte sequences that
--              Postgres interprets as bytea escape input (e.g. a literal
--              `\x9...` substring in LLM stderr leak text).  convert_to
--              is not IMMUTABLE and fails GENERATED-column validity;
--              pgcrypto's digest(text, 'sha256') IS IMMUTABLE and handles
--              arbitrary UTF-8 text without the bytea-escape gotcha.
-- Target:  ops-postgres (Postgres 16-alpine), database `ops`, schema `ops`.
-- Author:  Finlet ops team
-- Depends: 005_cto_artifacts.sql (defines the original enum),
--          006_artifact_workflow_names.sql (added specialist/merger names).
--          Takes the set of allowed workflow_name values from 006 and
--          appends `workflow-fixer`.
-- Apply with: docker exec -i ops-postgres psql -U ops -d ops < 007_artifact_workflow_fixer.sql
--
-- Event types emitted (documented here; ops.cto_decisions.event_type is a
-- free-text column, no constraint — no schema change needed for them):
--   intake_signal                  — intake workflow writes this
--   workflow_fixer_request         — workflow-fixer workflow writes this
--   workflow_fixer_applied         — future (Task #8)
--   workflow_fixer_rejected        — future (Task #8)
-- intake's action values: intake_routed_machine, intake_routed_human
-- workflow-fixer's action value: workflow_fixer_proposed
--
-- NOTE: this migration is idempotent. DROP IF EXISTS + ADD is safe to re-run.

BEGIN;

-- (a) Workflow name enum extension.
ALTER TABLE ops.cto_artifacts
    DROP CONSTRAINT IF EXISTS cto_artifacts_workflow_name_check;

ALTER TABLE ops.cto_artifacts
    ADD CONSTRAINT cto_artifacts_workflow_name_check CHECK (
        workflow_name IN (
            'intake',
            'brainstorm',
            'debate',
            'plan-features',
            'exec-plan',
            'specialist-swe',
            'specialist-swe-merger',
            'specialist-devops',
            'specialist-devops-merger',
            'specialist-security',
            'specialist-security-merger',
            'specialist-frontend-security',
            'specialist-frontend-security-merger',
            'specialist-ai-research',
            'specialist-ai-research-merger',
            'workflow-fixer'
        )
    );

-- (b) Replace the content_sha256 GENERATED expression.
-- Postgres STORED GENERATED columns cannot be ALTERed in place — DROP + ADD
-- is the only supported path.  This rebuilds the column on all existing rows
-- with the new, robust IMMUTABLE expression.
ALTER TABLE ops.cto_artifacts DROP COLUMN IF EXISTS content_sha256;
ALTER TABLE ops.cto_artifacts
    ADD COLUMN content_sha256 TEXT
    GENERATED ALWAYS AS (encode(digest(content, 'sha256'), 'hex')) STORED;

COMMIT;

-- ============================================================================
-- ROLLBACK (run manually if you need to reverse this migration)
-- ============================================================================
-- BEGIN;
--   ALTER TABLE ops.cto_artifacts DROP CONSTRAINT IF EXISTS cto_artifacts_workflow_name_check;
--   ALTER TABLE ops.cto_artifacts ADD CONSTRAINT cto_artifacts_workflow_name_check CHECK (
--       workflow_name IN (
--           'intake','brainstorm','debate','plan-features','exec-plan',
--           'specialist-swe','specialist-swe-merger',
--           'specialist-devops','specialist-devops-merger',
--           'specialist-security','specialist-security-merger',
--           'specialist-frontend-security','specialist-frontend-security-merger',
--           'specialist-ai-research','specialist-ai-research-merger'
--       )
--   );
-- COMMIT;
--
-- Note: rollback is destructive only if workflow-fixer artifact rows already
-- exist; those would fail the re-narrowed constraint. Purge first:
--   DELETE FROM ops.cto_artifacts WHERE workflow_name = 'workflow-fixer';
