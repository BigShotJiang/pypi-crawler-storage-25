-- Migration: 005_cto_artifacts.sql
-- Purpose: Durable artifact storage for CTO skill-graph workflows.
--          Each sub-workflow (intake, brainstorm, debate, plan-features, exec-plan)
--          writes exactly one artifact row per invocation carrying its OUTPUT DOC
--          as markdown. Artifacts are the handoff seam between stages (per the
--          mandate's separation-of-duties rule: each stage reads ONLY the prior
--          stage's output doc, never the prior agent's conversation). The table
--          replaces both filesystem-backed brainstorms/ and any S3/git artifact
--          stores — runtime-only, not checked in.
-- Target:  ops-postgres (Postgres 16-alpine), database `ops`, schema `ops`.
-- Author:  Finlet ops team
-- Depends: 001_cto_state.sql    (FK → ops.cto_state.task_id,  ON DELETE SET NULL)
--          002_cto_decisions.sql (FK → ops.cto_decisions.id,   ON DELETE SET NULL)
--          pgcrypto              (for gen_random_uuid() + sha256() via digest())
-- Apply with: docker exec -i ops-postgres psql -U ops -d ops < 005_cto_artifacts.sql
--
-- NOTE: content is markdown only — no binary artifacts. content_sha256 is a
--       STORED GENERATED column matching the mandate's tamper-evident reasoning-
--       trace principle. stage_input_ref is a self-reference (not an FK — the
--       prior artifact may have been purged; this is a lineage pointer, not a
--       hard constraint). workflow_name is a closed enum enforced at the table
--       level so a typo in a new sub-workflow surfaces at insert time.

BEGIN;

-- pgcrypto provides gen_random_uuid() AND digest() / sha256() via encode().
-- Idempotent — safe to re-run on top of migrations 001 / 004 which already
-- created the extension.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ----------------------------------------------------------------------------
-- Table: ops.cto_artifacts
-- One row per sub-workflow invocation. `ref` is the external handle that moves
-- between stages; callers never see the BIGINT `id` (internal only for FK
-- compatibility with future tables). `content` is the raw markdown body the
-- next stage will read — no chunking, no JSON wrapping, no base64. `metadata`
-- carries model id / token counts / prompt version / anything the workflow
-- wants to record for future audit.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ops.cto_artifacts (
    id              BIGSERIAL    PRIMARY KEY,
    ref             UUID         NOT NULL DEFAULT gen_random_uuid() UNIQUE,
    task_id         UUID         REFERENCES ops.cto_state(task_id)    ON DELETE SET NULL,
    decision_id     BIGINT       REFERENCES ops.cto_decisions(id)     ON DELETE SET NULL,
    workflow_name   TEXT         NOT NULL,
    stage_input_ref UUID,        -- ref of the prior stage's artifact; NULL for intake/first-stage
    content         TEXT         NOT NULL,
    content_sha256  TEXT         GENERATED ALWAYS AS (encode(sha256(content::bytea), 'hex')) STORED,
    metadata        JSONB        NOT NULL DEFAULT '{}'::jsonb,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now(),
    CONSTRAINT cto_artifacts_workflow_name_check CHECK (
        workflow_name IN ('intake','brainstorm','debate','plan-features','exec-plan')
    ),
    CONSTRAINT cto_artifacts_content_nonempty CHECK (length(content) > 0)
);

-- ----------------------------------------------------------------------------
-- Indexes
-- ----------------------------------------------------------------------------
-- `ref` already has a UNIQUE index via the UNIQUE constraint above — the
-- dominant lookup pattern (next-stage reads its input by ref) hits that index.

-- FK-supporting index: "show me all artifacts for task X" — used by
-- debugging / audit workflows and the hourly digest.
CREATE INDEX IF NOT EXISTS idx_cto_artifacts_task_id
    ON ops.cto_artifacts (task_id);

-- Per-workflow timeline: "last N brainstorm outputs", eval sweeps, etc.
CREATE INDEX IF NOT EXISTS idx_cto_artifacts_workflow_created
    ON ops.cto_artifacts (workflow_name, created_at DESC);

-- Lineage traversal: "what artifacts branched off this one?" Partial index
-- skips NULL rows (intake / first-stage artifacts) since those are the
-- majority and the lineage walker never queries them.
CREATE INDEX IF NOT EXISTS idx_cto_artifacts_stage_input_ref
    ON ops.cto_artifacts (stage_input_ref)
    WHERE stage_input_ref IS NOT NULL;

-- ----------------------------------------------------------------------------
-- Grants: match the convention used in migrations 001 / 002 / 003 / 004.
-- BIGSERIAL implicitly creates a sequence; grant on it so inserts work from
-- the `ops` role even if default privileges drift.
-- ----------------------------------------------------------------------------
GRANT ALL PRIVILEGES ON ops.cto_artifacts TO ops;
GRANT ALL PRIVILEGES ON SEQUENCE ops.cto_artifacts_id_seq TO ops;

COMMIT;

-- ============================================================================
-- ROLLBACK (run manually if you need to reverse this migration)
-- ============================================================================
-- BEGIN;
--   DROP TABLE IF EXISTS ops.cto_artifacts CASCADE;
--   -- The BIGSERIAL sequence is dropped implicitly with the table.
--   -- pgcrypto extension is left in place — used elsewhere.
-- COMMIT;
--
-- Note: rollback drops the table only. Foreign keys into ops.cto_state and
-- ops.cto_decisions disappear with it; neither parent table is affected.
