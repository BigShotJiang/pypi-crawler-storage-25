-- Migration: 003_cto_handoff.sql
-- Purpose: Single-row "living handoff" table — holds the current 7-day narrative
--          markdown that the ephemeral CTO reads on every spawn. Canonical-for-
--          humans copy lives at docs/ops/CTO_HANDOFF.md; this row is the runtime
--          source. The daily self-compact cron rewrites both (not built yet).
-- Target:  ops-postgres (Postgres 16-alpine), database `ops`, schema `ops`.
-- Author:  Finlet ops team
-- Depends: Schema `ops` already exists (created in init-db.sql). No FK to
--          001/002 — this table is independent state.
-- Apply with: docker exec -i ops-postgres psql -U ops -d ops < 003_cto_handoff.sql
--
-- NOTE: This is a DRAFT. Do not apply without review. See the rollback section
--       at the bottom for reversal.

BEGIN;

-- ----------------------------------------------------------------------------
-- Table: ops.cto_handoff
-- Single-row invariant enforced via a fixed PK + CHECK. Every UPDATE bumps
-- `version` for optimistic concurrency; concurrent writers can detect lost
-- updates with `UPDATE ... WHERE version = :expected`. `updated_at` is touched
-- automatically by a trigger so callers never have to remember.
--
-- The narrative is plain markdown — the same body the user reads in
-- docs/ops/CTO_HANDOFF.md. No length cap; Postgres TEXT handles anything the
-- compact cron emits (currently <2KB, long-term target <20KB after 7 days).
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ops.cto_handoff (
    id          BOOLEAN     PRIMARY KEY DEFAULT TRUE,
    narrative   TEXT        NOT NULL,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_by  TEXT,                      -- e.g. 'manual_seed', 'self_compact_cron', '<agent-name>'
    version     INTEGER     NOT NULL DEFAULT 1,
    CONSTRAINT cto_handoff_singleton CHECK (id = TRUE),
    CONSTRAINT cto_handoff_version_positive CHECK (version >= 1)
);

-- No secondary indexes — the table holds exactly one row by construction,
-- so the PK is sufficient for every access pattern.

-- ----------------------------------------------------------------------------
-- Trigger: auto-maintain updated_at AND auto-bump version on every UPDATE.
-- Keeps the application honest: callers can't forget either field. If a caller
-- explicitly sets `version`, that value wins (allows optimistic-concurrency
-- `SET version = version + 1 WHERE version = :expected` patterns without the
-- trigger double-bumping).
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION ops.cto_handoff_touch_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = now();
    -- Only auto-bump version if the caller did not change it themselves.
    IF NEW.version IS NOT DISTINCT FROM OLD.version THEN
        NEW.version = OLD.version + 1;
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS cto_handoff_updated_at ON ops.cto_handoff;
CREATE TRIGGER cto_handoff_updated_at
    BEFORE UPDATE ON ops.cto_handoff
    FOR EACH ROW
    EXECUTE FUNCTION ops.cto_handoff_touch_updated_at();

-- ----------------------------------------------------------------------------
-- Grants: match the convention used in init-db.sql and migrations 001/002.
-- ----------------------------------------------------------------------------
GRANT ALL PRIVILEGES ON ops.cto_handoff TO ops;

COMMIT;

-- ============================================================================
-- ROLLBACK (run manually if you need to reverse this migration)
-- ============================================================================
-- BEGIN;
--   DROP TRIGGER  IF EXISTS cto_handoff_updated_at ON ops.cto_handoff;
--   DROP FUNCTION IF EXISTS ops.cto_handoff_touch_updated_at();
--   DROP TABLE    IF EXISTS ops.cto_handoff;
-- COMMIT;
--
-- Note: this migration is independent of 001/002 — rollback has no cascading
-- impact on ops.cto_state or ops.cto_decisions.
