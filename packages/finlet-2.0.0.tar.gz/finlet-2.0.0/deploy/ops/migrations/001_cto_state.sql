-- Migration: 001_cto_state.sql
-- Purpose: Authoritative in-flight state for the ephemeral-CTO orchestration layer.
--          One row per active task the CTO is orchestrating (dispatch, debate, plan,
--          execute, merge, correction loops, etc.).
-- Target:  ops-postgres (Postgres 16-alpine), database `ops`, schema `ops`.
-- Author:  Finlet ops team
-- Depends: Schema `ops` already exists (created in init-db.sql).
-- Apply with: docker exec -i ops-postgres psql -U ops -d ops < 001_cto_state.sql
--
-- NOTE: This is a DRAFT. Do not apply without review. See the rollback section
--       at the bottom for reversal.

-- gen_random_uuid() lives in core on Postgres 13+, but pgcrypto is the historical
-- home; create it if missing so the migration is portable across minor version
-- bumps and restored dumps.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

BEGIN;

-- ----------------------------------------------------------------------------
-- Table: ops.cto_state
-- One row per active CTO-orchestrated task. Mutated in place as tasks progress
-- through stages; terminal rows (completed/failed/escalated) are retained for
-- join history with ops.cto_decisions.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ops.cto_state (
    task_id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    parent_task_id     UUID        REFERENCES ops.cto_state(task_id) ON DELETE SET NULL,
    team_name          TEXT        NOT NULL,  -- e.g. 'specialist-swe', 'brainstorm', 'exec-plan'
    stage              TEXT        NOT NULL,  -- 'brainstorm', 'debate', 'plan-features', 'exec-plan', 'execute', 'merge', 'direct'
    status             TEXT        NOT NULL DEFAULT 'pending',
    description        TEXT        NOT NULL,
    context            JSONB       NOT NULL DEFAULT '{}'::jsonb,  -- arbitrary state: bug_id, severity, prior-stage doc path, round count, etc.
    correction_round   INT         NOT NULL DEFAULT 0,  -- 0-4 per the correction loop
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_heartbeat_at  TIMESTAMPTZ,
    deadline_at        TIMESTAMPTZ,
    completed_at       TIMESTAMPTZ,
    CONSTRAINT cto_state_status_check CHECK (
        status IN ('pending','in_progress','paused','completed','failed','escalated')
    ),
    CONSTRAINT cto_state_round_check CHECK (correction_round BETWEEN 0 AND 4)
);

-- ----------------------------------------------------------------------------
-- Indexes
-- ----------------------------------------------------------------------------
-- Primary operational query: "show me active tasks, newest first".
CREATE INDEX IF NOT EXISTS idx_cto_state_status_updated
    ON ops.cto_state(status, updated_at DESC);

-- "What is team X doing right now?" — dashboards / per-team queues.
CREATE INDEX IF NOT EXISTS idx_cto_state_team_status
    ON ops.cto_state(team_name, status);

-- Tree traversal from a parent task to its spawned children.
CREATE INDEX IF NOT EXISTS idx_cto_state_parent
    ON ops.cto_state(parent_task_id);

-- Stuck-task detection: scan only in-progress rows, cheap because partial.
CREATE INDEX IF NOT EXISTS idx_cto_state_heartbeat
    ON ops.cto_state(last_heartbeat_at)
    WHERE status = 'in_progress';

-- ----------------------------------------------------------------------------
-- Trigger: auto-maintain updated_at on every UPDATE.
-- Kept in the ops schema to co-locate helper functions with the tables they
-- serve. Reused by future ops.* tables if desired.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION ops.cto_state_touch_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS cto_state_updated_at ON ops.cto_state;
CREATE TRIGGER cto_state_updated_at
    BEFORE UPDATE ON ops.cto_state
    FOR EACH ROW
    EXECUTE FUNCTION ops.cto_state_touch_updated_at();

-- ----------------------------------------------------------------------------
-- Grants: match the convention used in init-db.sql (full rights to `ops` role).
-- ----------------------------------------------------------------------------
GRANT ALL PRIVILEGES ON ops.cto_state TO ops;

COMMIT;

-- ============================================================================
-- ROLLBACK (run manually if you need to reverse this migration)
-- ============================================================================
-- BEGIN;
--   DROP TRIGGER  IF EXISTS cto_state_updated_at ON ops.cto_state;
--   DROP FUNCTION IF EXISTS ops.cto_state_touch_updated_at();
--   DROP TABLE    IF EXISTS ops.cto_state CASCADE;
-- COMMIT;
--
-- Note: dropping ops.cto_state CASCADE will also drop the task_id foreign key
-- from ops.cto_decisions (set ON DELETE SET NULL in migration 002). That is
-- intended — rollback assumes you are unwinding both migrations together.
