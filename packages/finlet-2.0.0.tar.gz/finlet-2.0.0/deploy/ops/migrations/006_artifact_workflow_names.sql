-- Migration: 006_artifact_workflow_names.sql
-- Purpose: Extend the ops.cto_artifacts.workflow_name CHECK constraint to
--          include the 10 new specialist + merger workflow names introduced
--          by Task #5 of CTO orchestration Phase 3 (5 specialist+merger
--          pairs). Pre-existing names (intake, brainstorm, debate,
--          plan-features, exec-plan) are retained. New names added:
--            specialist-swe,                 specialist-swe-merger
--            specialist-devops,              specialist-devops-merger
--            specialist-security,            specialist-security-merger
--            specialist-frontend-security,   specialist-frontend-security-merger
--            specialist-ai-research,         specialist-ai-research-merger
--          Per the separation-of-duties rule, specialists PROPOSE structured
--          changes (YAML-framed markdown) and mergers VALIDATE those
--          proposals against rules — both produce artifacts, both gated by
--          the same closed enum.
-- Target:  ops-postgres (Postgres 16-alpine), database `ops`, schema `ops`.
-- Author:  Finlet ops team
-- Depends: 005_cto_artifacts.sql (defines the constraint we are rewriting).
-- Apply with: docker exec -i ops-postgres psql -U ops -d ops < 006_artifact_workflow_names.sql
--
-- NOTE: the enum is enforced at insert time. Dropping and re-adding the
--       CHECK is idempotent if we gate on existence first. There is no
--       migration table in this stack — each migration is self-idempotent.

BEGIN;

ALTER TABLE ops.cto_artifacts
    DROP CONSTRAINT IF EXISTS cto_artifacts_workflow_name_check;

ALTER TABLE ops.cto_artifacts
    ADD CONSTRAINT cto_artifacts_workflow_name_check CHECK (
        workflow_name IN (
            'intake',
            'brainstorm',
            'debate',
            'plan-features',
            'exec-plan',
            'specialist-swe',
            'specialist-swe-merger',
            'specialist-devops',
            'specialist-devops-merger',
            'specialist-security',
            'specialist-security-merger',
            'specialist-frontend-security',
            'specialist-frontend-security-merger',
            'specialist-ai-research',
            'specialist-ai-research-merger'
        )
    );

COMMIT;

-- ============================================================================
-- ROLLBACK (run manually if you need to reverse this migration)
-- ============================================================================
-- BEGIN;
--   ALTER TABLE ops.cto_artifacts DROP CONSTRAINT IF EXISTS cto_artifacts_workflow_name_check;
--   ALTER TABLE ops.cto_artifacts ADD CONSTRAINT cto_artifacts_workflow_name_check CHECK (
--       workflow_name IN ('intake','brainstorm','debate','plan-features','exec-plan')
--   );
-- COMMIT;
--
-- Note: rollback is destructive only if specialist/merger artifact rows
-- already exist; those would fail the re-narrowed constraint. Purge first:
--   DELETE FROM ops.cto_artifacts WHERE workflow_name LIKE 'specialist-%';
