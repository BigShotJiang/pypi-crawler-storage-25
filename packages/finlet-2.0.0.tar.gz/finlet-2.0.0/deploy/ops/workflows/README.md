# Ops n8n Workflow Snapshots

**Exported:** 2026-04-21
**Count:** 21 workflows (18 CTO + 3 Phase 1)
**Source of truth:** Live `ops-n8n` at `ops.finlet.dev` (Hetzner CPX21, `87.99.156.168`)

These JSON files are **snapshots** of the live n8n workflows at the moment of export.
They exist so the workflow graph can be inspected/diffed in git without logging into n8n.
**The live n8n instance is the source of truth.** Edits go there first; this directory is regenerated.

## Scope

Each snapshot comes from `mcp__n8n__n8n_get_workflow` (mode=full) and has been sanitized:

- Removed: `shared`, `activeVersion`, `versionId`, `activeVersionId`, `versionCounter`, `triggerCount`, `isArchived` (these are local-to-instance and would conflict on restore)
- Kept: `name`, `id`, `active`, `nodes`, `connections`, `settings`, `staticData`, `meta`, `pinData`, `tags`

Credential references (e.g. `"credentials": {"postgres": {"id": "cQZd1wW1MLtHoMTH", "name": "ops-postgres"}}`) are kept by ID — they're safe because n8n stores credential values separately under the credential ID, not in the workflow body. Secret values (HMAC secret, JWT, Discord webhook URLs) are referenced via `$env.*` and live in the n8n container's env, not the workflow JSON.

A secret-leak scan runs as part of export. See `_index.json` for the export manifest.

## Restore procedure

To restore a workflow to a fresh n8n instance:

```javascript
// Using the n8n-mcp (preferred — handles credential references + validation)
const body = JSON.parse(fs.readFileSync('cto-supervisor.json', 'utf8'));
mcp__n8n__n8n_create_workflow({
  name: body.name,
  nodes: body.nodes,
  connections: body.connections,
  settings: body.settings
});
```

After creation, the new workflow will need:

1. **Credentials wired** — Postgres (`ops-postgres`), Discord bot (`finlet-ops-bot`) must exist by name in the target instance.
2. **Env vars set** — `CTO_WEBHOOK_HMAC_SECRET`, `N8N_INTERNAL_JWT`, `DISCORD_WEBHOOK_BUGHUNT`, `ANTHROPIC_API_KEY` (if not using claude-runner sidecar).
3. **Activation** — n8n creates workflows inactive by default; call `activateWorkflow` after verification.

## Re-export procedure

To refresh these snapshots after changes land in live n8n:

```bash
# From repo root:
python3 tools/export_cto_workflows.py  # TODO — helper script not yet extracted from /tmp
# Or: re-run the Q1 retrofit instructions in docs/ops/CTO_MANDATE.md
```

Until a helper script is extracted, the export process is:

1. `mcp__n8n__n8n_list_workflows` — enumerate IDs
2. For each: `mcp__n8n__n8n_get_workflow` mode=full
3. Sanitize (strip the fields listed above)
4. Write as `{slug(name)}.json`
5. Regenerate `_index.json` with {name, id, active, node_count, exported_at}
6. Scan sanitized output for secret leaks — block commit on any match

## File inventory

See `_index.json` for the machine-readable manifest.

### CTO core (3)
- `cto-supervisor.json` — main orchestrator (HMAC webhook, opus, routes to skill-graph/specialists)
- `intake.json` — classifies user-facing prompts into brainstorm/debate/plan/etc. and hands off to supervisor
- `workflow-fixer.json` — poll failing workflows, propose patches via Claude, queue for approval

### Skill graph (4)
- `skill-brainstorm.json` — ideation, writes to `cto_artifacts`
- `skill-debate.json` — 5-agent adversarial review
- `skill-plan-features.json` — multi-team execution plan
- `skill-exec-plan.json` — plan runner (STUB v1; specialist dispatch coming)

### Specialists & mergers (10)
- `specialist-swe.json` / `specialist-swe-merger.json` — code changes; allowlist: `finlet/core/`, `finlet/plugins/`, `finlet/api/`, `tests/`, `docs/`
- `specialist-devops.json` / `specialist-devops-merger.json` — `deploy/ops/`, `deploy/aws/`, `docs/ops/`, runbook/lessons
- `specialist-security.json` / `specialist-security-merger.json` — `docs/decisions/`, `docs/KNOWN_FAILURES.md`
- `specialist-frontend-security.json` / `specialist-frontend-security-merger.json` — `dashboard/`
- `specialist-ai-research.json` / `specialist-ai-research-merger.json` — `docs/`, `notebooks/`

Each `-merger` validates the specialist's YAML proposal against allowlist/banned-paths/size-cap/test-presence rules and writes a decision artifact into `ops.cto_artifacts` carrying `proposal_sha256_verified` (tamper-evidence anchor) + a human summary block.

### Phase 1 (3 — out of scope for Phase 3 work but included for completeness)
- `bug-hunt.json` — cron playwright probe of finlet.dev + Claude analysis → approval queue
- `bug-fix.json` — manual trigger with `bug_id`; calls local `bug-fix-runner` for PR
- `bug-verify.json` — cron-poll merged PRs and re-probe to confirm resolution

### Test/verification (1)
- `ops-hello-pipeline-verification.json` — end-to-end pipeline smoke: Claude → Discord
