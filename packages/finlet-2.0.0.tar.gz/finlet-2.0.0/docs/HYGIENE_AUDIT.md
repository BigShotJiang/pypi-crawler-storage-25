# Finlet Codebase Hygiene Audit

**Date**: 2026-03-26
**Scope**: Full codebase (all modules)

## Executive Summary

Finlet has solid architectural foundations — clean async patterns, no circular dependencies, proper module boundaries, and no sync I/O in async code. However, the codebase has outgrown its file organization: **26 files exceed 500 lines**, **60+ god files** exist, and **5 layering violations** undermine the intended architecture. The most critical structural issue is `api.auth` acting as a 20-importer hub, making it fragile to any change. Test coverage gaps (51 orphaned source files) are a launch risk for a financial simulation engine.

**Overall Grade: B-** — Good bones, needs a refactoring pass before scaling further.

---

## Critical Issues (Fix Now)

| # | Issue | Source | Impact |
|---|-------|--------|--------|
| 1 | **`api.auth` is a 20-importer hub** — any change cascades across the entire codebase | Dependency Recon | Single point of fragility; blocks safe refactoring |
| 2 | **5 layering violations** — auth/billing import from api layer (auth.mfa→api.auth, auth.mfa→api.mfa, billing.service→api.auth, billing.service→api.stripe_config, mcp.server→api.state) | Dependency Recon | Architectural integrity; will cause circular deps as codebase grows |
| 3 | **51 orphaned source files with no tests** — especially dangerous in core/ and plugins/ | Structure Recon | Financial simulation with untested enforcer/portfolio code is a launch risk |
| 4 | **Route files acting as Pydantic model containers** — routes_auth_mfa.py (10 classes, 0 routes), routes_billing.py (10 classes, 0 routes) | Structure Recon | Violates one-file-per-module; confuses code navigation |

## High Priority (Fix This Sprint)

| # | Issue | Source | Impact |
|---|-------|--------|--------|
| 5 | **db/models.py** — 602 lines, 16 classes spanning 3 domains (session, auth, leaderboard) | Structure Recon | God file; 17 importers; blocks independent domain evolution |
| 6 | **email_templates.py** — 1304 lines, 18 functions of inline HTML | Structure Recon | Largest file in codebase; impossible to review or maintain |
| 7 | **4 duplicated `_get_session()` helpers** across route files | Inconsistency Recon | Guaranteed inconsistency bugs; violates DRY |
| 8 | **7 duplicated path constants** (PLUGINS_CONFIG_PATH, FINLET_DIR) | Inconsistency Recon | Configuration drift risk |
| 9 | **test_plugins.py (1571 lines) and test_api.py (1465 lines)** — monolithic test files | Structure Recon | Hard to navigate, run selectively, or attribute failures |

## Medium Priority (Fix This Month)

| # | Issue | Source | Impact |
|---|-------|--------|--------|
| 10 | **24 broad `except Exception:` catches** — most defensive, but ssm.py should catch `ClientError` | Inconsistency Recon | Masks specific AWS errors in ssm.py |
| 11 | **Mixed logging imports** — structlog in API/core, stdlib logging in db/migrations/marketplace | Inconsistency Recon | Cosmetic but confusing for new contributors |
| 12 | **routes_marketplace_developer.py** — 1025 lines with 6 inline Pydantic classes | Structure Recon | Needs schema extraction |
| 13 | **`email-validator` dependency unused** | Dependency Recon | Dead dependency; remove from pyproject.toml |
| 14 | **Session security constants hardcoded** in session_auth.py | Inconsistency Recon | Should be configurable via config.py |
| 15 | **SQLite performance pragmas not explicitly set** (WAL, cache_size, mmap) | Optimization Research | Free performance gain for concurrent reads |

## Low Priority (Backlog)

| # | Issue | Source | Impact |
|---|-------|--------|--------|
| 16 | **4 TODO comments** in security_alerts.py ("send email when wired up") | Inconsistency Recon | Feature gap, not blocking |
| 17 | **datetime.now() without UTC** in 3 test fixtures | Inconsistency Recon | Convention violation in tests only |
| 18 | **Plugin entry-point registration** (pyproject.toml entry points) | Optimization Research | Only needed when third-party plugins are supported |
| 19 | **Exception Groups** (Python 3.11+ `except*`) for broad catches | Optimization Research | Modernization, not urgent |

---

## Refactoring Plan

### Phase A: Quick Wins (< 1 hour each)

- [ ] **A1**: Extract `_get_session()` to `finlet/api/deps.py` — deduplicate 4 identical 8-line functions from routes_clock.py, routes_market.py, routes_portfolio.py, routes_trade.py
- [ ] **A2**: Centralize `PLUGINS_CONFIG_PATH` and `FINLET_DIR` in `finlet/config.py` — replace 7 duplicated definitions
- [ ] **A3**: Remove `email-validator` from pyproject.toml dependencies
- [ ] **A4**: Fix 3 test fixtures to use `datetime.now(timezone.utc)` instead of `datetime.now()`
- [ ] **A5**: Replace `except Exception` in `ssm.py:62,92` with `except botocore.exceptions.ClientError`
- [ ] **A6**: Move hardcoded session security constants from `session_auth.py` to `config.py`
- [ ] **A7**: Add SQLite performance pragmas: `journal_mode=WAL`, `synchronous=NORMAL`, `cache_size=10000`, `temp_store=MEMORY`

### Phase B: Module Splits (1-3 hours each)

- [ ] **B1**: Split `tests/plugins/test_plugins.py` (1571 lines) into per-plugin test files:
  - `test_registry.py`, `test_price_plugin.py`, `test_edgar_plugin.py`, `test_fred_plugin.py`, `test_finnhub_plugin.py`
  - Extract shared fixtures to `conftest.py`
  - **Risk: LOW** — zero downstream consumers

- [ ] **B2**: Split `tests/api/test_api.py` (1465 lines) into per-domain test files:
  - `test_sessions.py`, `test_clock.py`, `test_trade.py`, `test_portfolio.py`, `test_auth.py`, `test_rate_limiting.py`, `test_leaderboard.py`, `test_trace.py`, `test_cors.py`
  - Extract shared fixtures to `conftest.py`
  - **Risk: LOW** — zero downstream consumers

- [ ] **B3**: Extract Pydantic schemas from route files into `finlet/api/schemas/`:
  - `schemas/auth_mfa.py` (from routes_auth_mfa.py — 10 classes)
  - `schemas/billing.py` (from routes_billing.py — 10 classes)
  - `schemas/marketplace_developer.py` (from routes_marketplace_developer.py — 6 classes)
  - **Risk: LOW** — schemas only used within their route files

- [ ] **B4**: Split `finlet/api/email_templates.py` (1304 lines) into `email_templates/` package:
  - `base.py` (shared styles/helpers), `auth.py`, `session.py`, `billing.py`, `security.py`
  - Re-export from `__init__.py` for backward compatibility
  - **Risk: LOW** — only 4 importers

- [ ] **B5**: Split `finlet/db/models.py` (602 lines, 16 classes) into domain-specific model files:
  - `session_models.py`, `auth_models.py`, `leaderboard_models.py`, `engine.py`, `helpers.py`
  - Re-export from `__init__.py` for backward compatibility (17 import sites)
  - Use `TYPE_CHECKING` guards for cross-file relationships
  - **Risk: MEDIUM** — 17 importers; requires careful re-export strategy

### Phase C: Architecture Improvements (half-day each)

- [ ] **C1**: Fix 5 layering violations — extract shared auth logic from `finlet/api/auth.py` into `finlet/auth/service.py`:
  - Move user authentication, API key validation, tier checking into `finlet/auth/`
  - Have `finlet/api/auth.py` re-export/wrap the service layer
  - Reduces api.auth from 20 importers to a thin delegation layer
  - Fixes: auth.mfa→api.auth, billing.service→api.auth, billing.service→api.stripe_config

- [ ] **C2**: Introduce service layer between routes and engine:
  - Create `finlet/api/services/` with `session_service.py`, `trade_service.py`, `market_service.py`
  - Routes become thin HTTP adapters; business logic moves to services
  - Eliminates duplicated session lookup patterns

- [ ] **C3**: Add property-based tests (Hypothesis) for critical invariants:
  - Portfolio: `value = cash + sum(position_values)` at all times
  - Date ceiling enforcer: never passes future data
  - Order fills: never produce negative cash
  - Clock: only moves forward
  - Equity curve: monotonically timestamped

### Phase D: Convention Alignment (ongoing)

- [ ] **D1**: Standardize logging imports — use `structlog.get_logger()` everywhere (stdlib is already bridged)
- [ ] **D2**: Add tests for highest-risk orphaned source files (prioritize `core/` and `plugins/`)
- [ ] **D3**: Document intent of remaining broad `except Exception:` catches with inline comments
- [ ] **D4**: Wire up email service for security_alerts.py TODOs
- [ ] **D5**: Extract serialization helpers from routes to shared utility module

---

## Metrics

| Metric | Value |
|--------|-------|
| Files > 500 lines | 26 (19% of codebase) |
| Files > 300 lines | 77 (51% of codebase) |
| God files (5+ classes or 10+ functions) | 60+ |
| Largest file | `test_plugins.py` (1571 lines) |
| Largest source file | `email_templates.py` (1304 lines) |
| Layering violations | 5 |
| Circular dependencies | 0 |
| Orphaned source files (no tests) | 51 |
| Duplicated helpers | 4 (`_get_session`) + 7 (path constants) |
| Broad exception catches | 24 |
| Unused dependencies | 1 (`email-validator`) |
| TODO/FIXME comments | 4 |

---

## Sources

- FastAPI Bigger Applications — fastapi.tiangolo.com
- FastAPI Best Practices (zhanymkanov) — github.com
- SQLModel Code Structure — sqlmodel.tiangolo.com
- Pytest Organizing Tests — pytest-with-eric.com
- FastAPI Clean Architecture Guide — blog.greeden.me
- Python Clean Architecture Patterns 2025 — glukhov.org
- SQLite Performance Tuning — phiresky.github.io
- MCP Best Practices — modelcontextprotocol.info
- Property-Based Testing Empirical Evaluation (OOPSLA 2025) — dl.acm.org
- 12 FastAPI Anti-Patterns Killing Throughput — medium.com
