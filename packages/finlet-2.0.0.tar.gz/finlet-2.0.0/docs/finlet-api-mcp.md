---
tags: [finlet, api, mcp, rest, fastapi]
keywords: REST API, MCP server, FastMCP, FastAPI, routes, services, authentication, bearer token, middleware
aliases: [finlet api, finlet mcp, api layer]
priority: normal
---

# Finlet API & MCP Layer

## REST API (`finlet/api/`)

FastAPI app with route groups: auth, clock, market, trading, portfolio, sessions, billing (Stripe), leaderboard, admin, health.

### Middleware Stack
1. CorrelationIDMiddleware (X-Request-ID)
2. SecurityHeadersMiddleware (HSTS, CSP, X-Frame-Options)
3. RequestSizeLimitMiddleware (1MB)
4. CORSMiddleware

### Auth
REST accepts cookie auth, `X-API-Key: fnlt_*`, or `Authorization: Bearer fnlt_*`. Hosted `/mcp` accepts `Authorization: Bearer <oauth_jwt>` or `Authorization: Bearer fnlt_*`; MCP tool-argument `api_key=...` is rejected. Public health, landing, terms, and privacy routes remain unauthenticated.

### Error Handling
Domain exceptions mapped to HTTP: SessionNotActiveError->409, PluginUnavailableError->503, RateLimitError->429, ValidationError->422. Always include actionable details.

### Services Layer (`finlet/api/services/`)
- market_service.py — Plugin routing, enforcer, tracing (canonical for REST + MCP)
- clock_service.py — Clock advance, price refresh, order fill
- trade_service.py — Order submission, auto-fill
- session_service.py — Session lifecycle

## MCP Server (`finlet/mcp/`)

MCP package for LLM agents. Hosted `/mcp` is the cloud transport, `finlet mcp serve` is the default local stdio bridge to hosted `/mcp`, and `finlet mcp serve --self-host` runs the local FastMCP server for self-host operators.

**Data:** get_price_data, search_news, get_fundamentals, get_filings, get_economic_data, list_available_tickers
**Trading:** submit_order, cancel_order
**Portfolio:** get_portfolio, get_equity_curve, get_trace
**Clock:** get_sim_time, advance_time, freeze_time
**Session:** create_session, list_sessions, get_session, delete_session, complete_session, set_session_visibility
**Benchmark:** start_benchmark, get_benchmark_progress, export_benchmark_results, set_benchmark_visibility
**Telemetry:** report_bug

## Leaderboard (`finlet/leaderboard/`)

5 frozen scenarios: Bull Run, COVID Crash, Sideways Chop, VIX Blowup, Recovery Rally.
Default universe: AAPL, MSFT, NVDA, AMZN, GOOGL, BTC-USD.

Composite score (0-100): 30% Sharpe, 25% return vs benchmark, 25% inverse max drawdown, 20% consistency.
Rate limited: 10 submissions/day/user.
