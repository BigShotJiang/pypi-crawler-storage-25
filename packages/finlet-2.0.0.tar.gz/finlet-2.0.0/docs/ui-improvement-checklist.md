# Finlet UI Improvement Checklist

> Synthesized from: frontend code audit, competitor analysis (Investopedia Simulator, TradingView, Thinkorswim, QuantConnect, Alpaca, Composer, Wealthfront, Betterment, Robinhood, Sharesight), and UI/UX masters research (TikTok, Notion, Robinhood, Duolingo, Linear, Figma).
>
> Generated: 2026-03-25

---

## Priority Legend

| Impact | Meaning |
|--------|---------|
| **P0 — Critical** | Blocks user conversion or causes confusion that drives abandonment |
| **P1 — High** | Significant friction; users can work around it but many won't |
| **P2 — Medium** | Polish and completeness; improves retention and perceived quality |
| **P3 — Low** | Nice-to-have; contributes to delight but not blocking |

| Feasibility | Meaning |
|-------------|---------|
| **Easy** | < 1 day, single file or small change |
| **Medium** | 1-3 days, multiple files, may need API integration |
| **Hard** | 3+ days, new pages/systems, design decisions required |

---

## P0 — Critical (Do These First)

### 1. Build a Public Landing Page
- **Impact**: Critical | **Feasibility**: Medium
- **Problem**: No public-facing page exists. Every visitor hits `auth.html` immediately — a login form with zero context about what Finlet is. This is the single biggest conversion killer.
- **Audit ref**: `dashboard/index.html:139-143` redirects unauthenticated users to auth.
- **Competitor insight**: Every competitor (Robinhood, Alpaca, Wealthfront, Composer) has a marketing landing page with value prop, social proof, and a clear CTA before asking for signup. Wealthfront's landing page is best-in-class — explains the product in 3 scroll sections.
- **UX pattern**: Robinhood and TikTok both use "show the product working" as their landing hero — a live preview or animation of the core experience. TikTok lets users experience core content BEFORE signup, proving value first. Wave (fintech) shows live metrics: "Over $24 billion in invoices sent each year."
- **Action items**:
  - [ ] Create `landing.html` (or a `/` route) with: hero section showing Finlet dashboard in action, 3 value props, "Get Started Free" CTA
  - [ ] Move `auth.html` to `/auth` — landing page links to it
  - [ ] Add social proof section with live counters: "X strategies running right now", "Y AI insights generated today"
  - [ ] Include a 30-second product demo GIF or interactive preview (show the dashboard working with real data)
  - [ ] Add trust signals prominently: security badges, data handling transparency (critical for fintech — trust architecture is non-negotiable per UX research)

### 2. Add "Create Session" UI in Dashboard
- **Impact**: Critical | **Feasibility**: Medium
- **Problem**: After signup, new users see an empty session selector and a banner telling them to run CLI commands (`finlet serve`, `finlet session create`). Web-only users hit a dead end.
- **Audit ref**: `dashboard/index.html:202-223`, `dashboard/app.js:655-660`
- **Competitor insight**: Alpaca and QuantConnect let users create paper trading sessions from the web UI in < 30 seconds. Composer auto-creates a first portfolio on signup.
- **UX pattern**: Notion's "empty state as onboarding" — when there's nothing to show, the empty state IS the creation flow. Duolingo auto-starts your first lesson; no manual setup. Canva shows "Start with a template" instead of a blank canvas. Best practice: "Two parts instruction, one part delight" — titles should be positive statements ("Start your first strategy") not negative ("You don't have any data").
- **Action items**:
  - [ ] Add "Create New Session" button in session selector dropdown
  - [ ] Build a session creation modal/form: name, starting capital, optional strategy description
  - [ ] Wire to existing `POST /v1/sessions` API endpoint
  - [ ] Auto-create a demo session on first signup (prefilled with sample data) so dashboard is never empty
  - [ ] Replace CLI-instruction banner with interactive session creation wizard
  - [ ] Offer 2-3 template strategies users can activate immediately (like Notion's template gallery) — e.g., "Conservative ETF", "Tech Growth", "AI Momentum"

### 3. Resolve Auth Model Confusion (API Key vs Password)
- **Impact**: Critical | **Feasibility**: Easy
- **Problem**: Login requires a 32-character API key. Signup only asks for email (no password). But Settings has a "Change Password" section. Three contradictory mental models.
- **Audit ref**: `dashboard/auth.html:114`, `dashboard/settings.html:138-167`
- **Competitor insight**: Alpaca cleanly separates web login (email/password or OAuth) from API keys (generated in settings). Robinhood uses standard email/password + 2FA. No competitor uses API keys as the primary login method.
- **Action items**:
  - [ ] Decide on auth model: either (a) email/password for web login + API keys for programmatic access, or (b) magic link login via email
  - [ ] Remove "Change Password" from Settings if keeping API-key-only auth
  - [ ] If adding password auth: update signup to collect password, update login flow, move API key to a separate "Developer" section in Settings
  - [ ] Add Google OAuth as primary login (GSI script already loaded in `auth.html`)

---

## P1 — High Impact

### 4. Guided First-Run Onboarding Flow
- **Impact**: High | **Feasibility**: Hard
- **Problem**: After signup + session creation, users still don't know what to do. No guided tour, no setup wizard, no "connect your AI agent" instructions.
- **Competitor insight**: Wealthfront has the best onboarding (5-question quiz to personalize). Duolingo's progressive disclosure — one step at a time, immediate reward. Robinhood guides users from signup to first trade in < 2 minutes. Supabase segments users into "experienced" (need confidence) vs "newcomers" (need reassurance) with different paths.
- **UX pattern**: TikTok's "zero-effort first experience" — content appears immediately, no setup required. Notion offers 3 use-case paths at signup (personal, school, team) and completes onboarding in under 50 seconds. Stripe's "inspectable" onboarding lets users map UI actions to API requests — powerful for developer-facing products.
- **Benchmarks**: Target < 2 minutes to first perceived value. Activation rate target: 40-60% (industry average 34%). Retention target: 50%+ month-over-month 30 days after aha moment.
- **Action items**:
  - [ ] Build a 3-step onboarding wizard: (1) "What describes you best?" — Retail Investor / Quant Developer / Financial Advisor (2) "Create your first session" (3) "Connect an agent or make a test trade"
  - [ ] Customize dashboard layout, default data sources, and checklist items per persona (like Notion's segmented paths)
  - [ ] Add a persistent progress checklist leveraging the Zeigarnik Effect (humans feel tension when a checklist is incomplete): (1) Set up profile, (2) Connect data source or load demo, (3) Run first AI analysis, (4) Save first strategy. Progress bar with satisfying checkmark animations.
  - [ ] Pre-populate first session with a sample portfolio and a few historical trades so the dashboard has data immediately
  - [ ] Add "Make a Test Trade" button — single click to submit a sample buy order
  - [ ] Add "Skip to dashboard" at every step (Linear reduced onboarding from 6 to 3 steps — "Skip" options are critical)
  - [ ] Offer two paths like Supabase: "I know what I'm doing" (skip to API docs) vs "Guide me through it" (full wizard)

### 5. Add User Menu to All Pages
- **Impact**: High | **Feasibility**: Easy
- **Problem**: Sign Out and Copy API Key are only accessible on `index.html`. Billing, Leaderboard, and Settings pages have no user menu — users can't sign out.
- **Audit ref**: `dashboard/billing.html:24-28`, `dashboard/leaderboard.html:23-27`, `dashboard/settings.html:24-28`
- **Competitor insight**: Universal pattern — every competitor has a persistent user menu across all pages.
- **Action items**:
  - [ ] Extract user menu into a shared component/partial
  - [ ] Include it in the header of `billing.html`, `leaderboard.html`, `settings.html`
  - [ ] Ensure Sign Out, Copy API Key, and user avatar are consistent across all pages

### 6. Replace Jargon-Filled Empty States
- **Impact**: High | **Feasibility**: Easy
- **Problem**: Empty panels show messages like "Submit orders via the MCP tools or REST API" — new users don't know what MCP is.
- **Audit ref**: `dashboard/index.html:329`
- **UX pattern**: Composer has the best empty states — visual illustration + single action button + one-sentence explanation. Linear uses "Learn more" links to documentation. Notion includes a Getting Started checklist directly in the first-use board. Rule of thumb: "Two parts instruction, one part delight."
- **Action items**:
  - [ ] Rewrite all empty state messages in plain language using positive framing: "Start your first trade" not "You don't have any trades yet"
  - [ ] Each empty state must have: (1) a visual illustration or icon, (2) a single prominent CTA button, (3) one sentence of explanation
  - [ ] Show a sample AI-powered insight card with demo data (clearly labeled) in the insights panel
  - [ ] Add "Generate demo data" button as an alternative to "Connect data source"
  - [ ] Link to relevant docs/guides from each empty state
  - [ ] Replace "MCP tools or REST API" with "your AI agent, the API, or the trade button above"

### 7. Remove Mock Data Fallbacks from Billing
- **Impact**: High | **Feasibility**: Easy
- **Problem**: If billing API returns null, `generateMockUsage()` and `generateMockInvoices()` render fake financial data. Users could see fabricated charges.
- **Audit ref**: `dashboard/billing.js:165-172`
- **Action items**:
  - [ ] Remove `generateMockUsage()` and `generateMockInvoices()` entirely
  - [ ] Replace with proper empty state: "No billing data yet — usage tracking begins after your first API call"
  - [ ] Add error state for API failures distinct from "no data" state

### 8. Mobile Responsive Navigation
- **Impact**: High | **Feasibility**: Medium
- **Problem**: Nav links wrap/overflow on small screens. No hamburger menu. Auth page brand panel pushes login below fold on mobile.
- **Audit ref**: `dashboard/auth.css:932`
- **Competitor insight**: Robinhood is mobile-first. TradingView uses a collapsible sidebar. Every competitor handles mobile nav.
- **Action items**:
  - [ ] Add hamburger menu for screens < 768px
  - [ ] Collapse header nav into slide-out drawer
  - [ ] On auth page: hide or minimize brand panel on mobile, prioritize the login form
  - [ ] Test all pages at 375px, 768px, 1024px breakpoints

---

## P2 — Medium Impact

### 9. Fix Theme Switcher (Light Theme)
- **Impact**: Medium | **Feasibility**: Medium
- **Problem**: Settings offers Light/System theme options but only dark theme CSS variables exist. Selecting light theme does nothing.
- **Audit ref**: `dashboard/settings.html:79-88, 438-457`, `dashboard/styles.css:6-52`
- **Action items**:
  - [ ] Either implement light theme CSS variables (`:root[data-theme="light"]`) or remove the theme switcher from Settings
  - [ ] If implementing: define full light variable set, test all components, respect `prefers-color-scheme` for System option
  - [ ] Recommendation: remove for now, ship light theme as a separate initiative

### 10. Consistent Navigation and Breadcrumbs
- **Impact**: Medium | **Feasibility**: Easy
- **Problem**: Only `billing.html` has breadcrumbs. Legal pages (`/privacy`, `/terms`) have no nav back to dashboard.
- **Action items**:
  - [ ] Add breadcrumbs to all sub-pages (Leaderboard, Settings, Billing)
  - [ ] Add "Back to Dashboard" link on legal pages (`/privacy`, `/terms`)
  - [ ] Standardize header across all pages using a shared template

### 11. Leaderboard — Meaningful Empty State and Context
- **Impact**: Medium | **Feasibility**: Easy
- **Problem**: Shows "No agents ranked yet" with no explanation of scoring methodology or sample data.
- **Audit ref**: `dashboard/leaderboard.js:50`
- **Competitor insight**: Investopedia Simulator shows a public leaderboard with top performers even for non-participants. TradingView shows popular traders to inspire competition.
- **Action items**:
  - [ ] Add explanation of how scoring works (Sharpe ratio, total return, etc.)
  - [ ] Show sample/demo leaderboard data for new installations
  - [ ] Add "How to get on the leaderboard" CTA linking to session creation

### 12. Session Management UI
- **Impact**: Medium | **Feasibility**: Medium
- **Problem**: No way to delete, rename, clone, or view details of sessions from the UI. Only a session selector dropdown exists.
- **Competitor insight**: TradingView and QuantConnect both have full portfolio/strategy management panels. Alpaca lets you switch between paper and live accounts with full management.
- **Action items**:
  - [ ] Add session details panel (creation date, strategy description, performance summary)
  - [ ] Add rename, delete, and clone actions
  - [ ] Wire to existing API endpoints

### 13. Build Marketplace UI
- **Impact**: Medium | **Feasibility**: Hard
- **Problem**: Extensive backend marketplace routes exist (`finlet/api/`) with zero frontend. This is a major feature with no user-facing surface.
- **Competitor insight**: Composer's strategy marketplace and QuantConnect's algorithm marketplace drive community engagement and retention.
- **UX pattern**: Figma's community/plugin marketplace — browsable gallery with search, preview, one-click install.
- **Action items**:
  - [ ] Build `marketplace.html` with: plugin gallery grid, search/filter, plugin detail modal
  - [ ] Wire to existing marketplace API endpoints
  - [ ] Add marketplace link to main navigation
  - [ ] Include ratings, install counts, and plugin descriptions

### 14. Trade Submission UI
- **Impact**: Medium | **Feasibility**: Medium
- **Problem**: No way to submit trades from the web UI. Even a test trade button would dramatically improve onboarding.
- **Competitor insight**: Every trading platform (Robinhood, TradingView, Alpaca, Thinkorswim) has a trade ticket UI. This is table stakes.
- **Action items**:
  - [ ] Build a trade ticket component: symbol search, buy/sell, quantity, order type (market/limit)
  - [ ] Wire to existing order submission API
  - [ ] Add as a slide-out panel or modal accessible from the dashboard
  - [ ] Include a "Test Trade" quick action for onboarding

---

## P3 — Polish and Delight

### 15. "Connect Your AI Agent" Guide
- **Impact**: Low | **Feasibility**: Easy
- **Problem**: No guidance on how to connect an AI agent to Finlet — the core value proposition.
- **Competitor insight**: Alpaca has excellent developer onboarding docs with code snippets. QuantConnect has interactive tutorials.
- **Action items**:
  - [ ] Create an in-dashboard guide: "Connect Your Agent in 3 Steps" (get API key, configure MCP, run first command)
  - [ ] Include copy-pasteable code snippets for popular frameworks
  - [ ] Link from the onboarding wizard and empty states

### 16. Accessibility Gaps
- **Impact**: Low | **Feasibility**: Easy
- **Problem**: Good foundations (skip links, ARIA, focus-visible, WCAG AA contrast) but error boundary lacks focus trapping and panel toggles use bare Unicode chevrons.
- **Action items**:
  - [ ] Add focus trapping to error boundary modal
  - [ ] Replace Unicode chevrons with proper ARIA-labeled icons
  - [ ] Test full keyboard navigation flow

### 17. Security Hardening
- **Impact**: Low | **Feasibility**: Easy
- **Problem**: API keys stored in localStorage (acknowledged TODO). Client-side rate limiting trivially bypassable. No SRI on Google Sign-In script.
- **Action items**:
  - [ ] Move API key storage to httpOnly cookies (requires backend change)
  - [ ] Remove client-side rate limiting (enforce server-side only)
  - [ ] Add SRI hash to Google Sign-In CDN script

### 18. Settings Page Cleanup
- **Impact**: Low | **Feasibility**: Easy
- **Problem**: Avatar upload UI exists but may not be functional. Non-working features erode trust.
- **Action items**:
  - [ ] Verify avatar upload works end-to-end; remove if backend doesn't support it
  - [ ] Remove Chart Preferences if not wired to anything
  - [ ] Audit all Settings sections — remove any that don't function

---

## Cross-Cutting Patterns (Apply Everywhere)

These principles emerged from cross-referencing all three research lanes:

### Progressive Disclosure (Duolingo, Robinhood, TikTok)
- Show the minimum needed at each step; reveal complexity as users demonstrate readiness
- **Duolingo** invented "Time Spent Learning Well" (TSLW) to ensure engagement serves the goal, not just clicks. Leagues, quests, and streak freezes are revealed gradually — not dumped on day one.
- **Robinhood** uses large, easy-to-tap cards one at a time, with regulatory disclosures collapsible. Options trading unlocks progressively.
- **TikTok** shows only 3 sign-up options at once (hiding the rest) to eliminate decision paralysis.
- Apply to: onboarding wizard, dashboard panels, session creation, trade submission
- Anti-pattern to fix: Finlet currently shows everything at once (session selector, metrics, chart, positions, orders, reasoning, plugin health) with no progressive reveal

### Empty State = Onboarding (Composer, Notion, Canva)
- Every empty state should be a call to action, not a dead end
- **Notion** includes a Getting Started checklist directly in the first-use board + Template Gallery for structured starts
- **Canva** shows "Start with a template" with curated options instead of a blank canvas
- Formula: visual illustration + single action button + one-sentence explanation
- Apply to: all 6 dashboard panels, leaderboard, marketplace (when built)
- Anti-pattern to fix: current empty states are informational text with no actionable next step

### Time-to-Value Under 60 Seconds (Vercel, Linear, Robinhood)
- Users should see the product working within their first minute
- **Vercel** deploys code in seconds, drives 100K monthly signups and $200M+ revenue from self-serve
- **Linear** reduced onboarding from 6 to 3 steps with smart defaults, reached $400M valuation
- **Benchmarks**: < 2 minutes to first perceived value, 40-60% activation rate target (industry average 34%)
- Apply to: auto-created demo session, pre-populated sample data, test trade button
- Anti-pattern to fix: current time-to-value is infinite for web-only users (requires CLI)

### Persona Segmentation (Supabase, Notion, Figma)
- Different users need different onboarding paths
- **Supabase** identified "create your first database" as the critical activation event, then built separate paths for experienced vs. newcomer users
- **Notion** offers 3 use-case paths at signup; personal/school completes in < 50 seconds
- **Figma** uses hyper-fast 3-step onboarding with differentiating features highlighted first
- Apply to: signup flow, dashboard layout defaults, checklist items, documentation links
- Finlet personas: Retail Investor (needs simplicity), Quant/Developer (needs API docs + speed), Financial Advisor (needs reporting + trust)

### Consistent Shell (Every Competitor)
- Header, nav, user menu, and footer should be identical across all pages
- Apply to: extract shared layout, use on all pages
- Anti-pattern to fix: user menu only on index.html, breadcrumbs only on billing

### Micro-Interactions and Loading States (Industry Standard)
- 12% higher click-through rates with subtle motion elements (Gartner predicts 75% of customer-facing apps incorporate micro-interactions)
- Use skeleton screens (not spinners) for loading states
- Smooth number transitions for portfolio values, subtle slide-in for insight cards, gentle shake for errors
- All animations under 500ms, must support `prefers-reduced-motion` accessibility
- **Critical for fintech**: avoid celebratory animations for financial decisions (Robinhood regulatory lesson). Every animation must solve a problem: clarify, guide, or confirm.

### Celebrate Milestones (Duolingo, Robinhood)
- Acknowledge user progress: first trade, first profitable session, leaderboard ranking
- **Duolingo** uses streaks, XP points, and 10-tier leaderboards — highest retention in EdTech
- **Monzo & Monarch** (fintech) use checklists providing small dopamine boosts per completed item
- Apply to: post-trade confirmation, session performance milestones, onboarding completion
- Consider a "Portfolio Readiness" percentage that fills as users complete setup steps
- Currently missing entirely from Finlet

### Trust Architecture (Fintech-Specific)
- 78% of users expect personalized financial advice; AI-personalized apps show 25-30% higher retention
- Every design choice builds or erodes trust — security badges, compliance certifications, and data handling transparency are non-negotiable in fintech
- Card-based layouts where each card encapsulates a specific metric; drill-down charts foster trust and reduce support calls
- Apply to: landing page, dashboard, billing, any page showing financial data

---

## Recommended Implementation Order

| Phase | Items | Timeline |
|-------|-------|----------|
| **Phase 1: Unblock conversion** | #1 Landing page, #3 Auth fix, #5 User menu on all pages | Week 1 |
| **Phase 2: Unblock activation** | #2 Session creation UI, #6 Empty states, #7 Remove mock billing | Week 2 |
| **Phase 3: First experience** | #4 Onboarding wizard, #14 Trade ticket, #8 Mobile nav | Week 3 |
| **Phase 4: Completeness** | #10 Nav consistency, #11 Leaderboard, #12 Session management, #9 Theme | Week 4 |
| **Phase 5: Growth features** | #13 Marketplace UI, #15 Agent guide, #18 Settings cleanup | Week 5 |
| **Phase 6: Hardening** | #16 Accessibility, #17 Security | Week 6 |

---

## Differentiation Opportunities (Finlet-Specific)

These are areas where Finlet can leapfrog competitors rather than just catching up:

1. **MCP-Native Onboarding**: No competitor has an "AI agent marketplace" onboarding flow. Finlet can own this UX — "Connect your Claude/GPT agent in 30 seconds" could be a unique selling point.
2. **Plugin Marketplace**: Composer has strategy sharing but no one has a plugin marketplace for financial AI tools. The backend already exists.
3. **AI-Narrated Insights**: Use the reasoning trace data (already captured) to generate plain-English explanations of portfolio decisions. No competitor does this well. 78% of users expect personalized financial advice — AI-personalized apps show 25-30% higher retention.
4. **Agent vs Agent Leaderboard**: The leaderboard concept is unique among competitors. Gamify it with Duolingo-style mechanics — streaks, XP, 10-tier rankings, head-to-head comparisons, strategy type badges.
5. **Real-Time Strategy Visualization**: Show what an AI agent is "thinking" as it makes decisions. The reasoning trace panel exists but could be made much more visual and engaging.
6. **Inspectable API Actions** (Stripe pattern): Let users map Dashboard UI actions to underlying API requests. This "inspectability" is a powerful learning tool for developer users — Stripe saw a 5.3% conversion increase from their express onboarding flow which incorporated this. Finlet could show the API call behind every dashboard action in a collapsible panel.
