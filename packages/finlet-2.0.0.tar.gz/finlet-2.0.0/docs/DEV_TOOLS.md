# Finlet Dev Tools Reference

## Overview

This document was compiled from a 9-agent research sweep on 2026-03-25. It covers CLI tools, MCP servers, and development utilities organized by department. Agent teams should use this as the primary reference for discovering available tooling.

---

## CLI Tools

### DevOps & Code Quality

| Tool | Description | License | Install |
|------|-------------|---------|---------|
| **Ruff** | Python linter/formatter (Rust). Already in use. | MIT | `pip install ruff` |
| **ty** | Astral's Rust type checker, 10-60x faster than mypy | MIT | `uv tool install ty` |
| **Bandit** | Python security SAST (hardcoded passwords, SQL injection, insecure crypto) | Apache-2.0 | `pip install bandit` |
| **Gitleaks** | Secret detection in git repos, pre-commit hook. 25.5k stars | MIT | `brew install gitleaks` |
| **TruffleHog** | Finds/verifies 800+ secret types across git history | AGPL-3.0 | `brew install trufflehog` |
| **Vulture** | Find dead/unused Python code | MIT | `pip install vulture` |
| **deptry** | Detect missing/unused dependencies | MIT | `pip install deptry` |
| **complexipy** | Cognitive complexity analysis (Rust) | MIT | `pip install complexipy` |
| **pre-commit** | Hook orchestration framework | MIT | `pip install pre-commit` |
| **act** | Run GitHub Actions locally. 69.5k stars | MIT | `brew install act` |
| **Commitizen** | Conventional commits + auto version bumping | MIT | `pipx install commitizen` |
| **git-cliff** | Changelog generator from git history | MIT | `brew install git-cliff` |
| **Semgrep** | Multi-language SAST with custom rules and --autofix | LGPL-2.1 | `brew install semgrep` (pip fails on macOS) |
| **AgentLint** | Purpose-built Claude Code guardrails, hooks into PreToolUse/PostToolUse | MIT | `pip install agentlint` |

### AWS & Infrastructure

| Tool | Description | License | Install |
|------|-------------|---------|---------|
| **AWS CLI v2** | Foundation AWS tool | Apache-2.0 | `brew install awscli` |
| **Terraform** | IaC for 3900+ providers | BUSL | `brew install terraform` |
| **OpenTofu** | Fully open-source Terraform fork with state encryption | MPL-2.0 | `brew install opentofu` |
| **Pulumi** | IaC in real Python (no HCL) | Apache-2.0 | `brew install pulumi` |
| **AWS CDK** | Python IaC via CloudFormation | Apache-2.0 | `npm install -g aws-cdk` |
| **Infracost** | Estimate AWS costs before terraform apply | Apache-2.0 | `brew install infracost` |
| **Prowler** | One-command AWS security audit (CIS, NIST, SOC2) | Apache-2.0 | `pip install prowler` |
| **Checkov** | Static analysis for IaC (Terraform, CloudFormation, Dockerfile) | Apache-2.0 | `pip install checkov` |
| **cfn-lint** | CloudFormation template linter | MIT | `pip install cfn-lint` |
| **aws-vault** | Secure credential storage with temp sessions | MIT | `brew install --cask aws-vault` |
| **Steampipe** | Query AWS resources with SQL | AGPL-3.0 | `brew install turbot/tap/steampipe` |
| **LocalStack** | Emulate 100+ AWS services locally, free tier available | — | `pip install localstack` |
| **TFLint** | Pluggable Terraform linter with AWS ruleset (700+ rules) | MPL-2.0 | `brew install tflint` |
| **ScoutSuite** | Multi-cloud security audit with HTML reports | GPL-2.0 | `pip install scoutsuite` |

### API & Data

| Tool | Description | License | Install |
|------|-------------|---------|---------|
| **HTTPie** | Human-friendly HTTP client | BSD-3 | `pip install httpie` |
| **xh** | Rust reimplementation of HTTPie (faster, no Python deps) | MIT | `brew install xh` |
| **Hurl** | Declarative API test files (.hurl), CI-ready | Apache-2.0 | `brew install hurl` |
| **Mockoon CLI** | Mock API servers from JSON/OpenAPI specs | MIT | `npm install -g @mockoon/cli` |
| **Prism** | Mock server + validation proxy from OpenAPI spec | Apache-2.0 | `npm install -g @stoplight/prism-cli` |
| **respx** | Native httpx mocking for Python tests | BSD-3 | `pip install respx` |
| **mitmproxy** | Intercepting HTTP proxy for traffic debugging | MIT | `pip install mitmproxy` |
| **httpstat** | Visualize HTTP connection timing | MIT | `pip install httpstat` |
| **Vegeta** | HTTP load testing at constant rate | MIT | `brew install vegeta` |
| **Spectral** | OpenAPI spec linter | Apache-2.0 | `npm install -g @stoplight/spectral-cli` |
| **sqlite-utils** | CLI for SQLite manipulation (insert JSON, query, export) | Apache-2.0 | `pip install sqlite-utils` |
| **litecli** | Interactive SQLite client with auto-completion | BSD-3 | `pip install litecli` |
| **Datasette** | Publish SQLite as browsable JSON API | Apache-2.0 | `pip install datasette` |
| **jq** | JSON processor | MIT | `brew install jq` |
| **gron** | Make JSON greppable | MIT | `brew install gron` |
| **dasel** | Query/modify JSON/YAML/TOML/CSV with unified syntax | MIT | `brew install dasel` |
| **check-jsonschema** | JSON Schema validation CLI + pre-commit hook | MIT | `pip install check-jsonschema` |

### Plugin & Dependency Management

| Tool | Description | License | Install |
|------|-------------|---------|---------|
| **uv** | 10-100x faster Python package manager (replaces pip+venv+pyenv+pipx+twine) | MIT | `curl -LsSf https://astral.sh/uv/install.sh \| sh` |
| **Copier** | Project scaffolding with `copier update` for template propagation | MIT | `uv tool install copier` |
| **Cookiecutter** | One-shot project scaffolding from templates | BSD | `pip install cookiecutter` |
| **just** | Modern command runner (Makefile replacement) | CC0 | `brew install just` |
| **nox** | Python test automation with Python-based config | Apache-2.0 | `pip install nox` |
| **Renovate** | Automated dependency update bot (90+ package managers) | AGPL-3.0 | GitHub App |
| **mise** | Polyglot version manager (replaces pyenv+direnv+nvm) | MIT | `curl https://mise.run \| sh` |
| **pluggy** | Hook-based plugin management (used by pytest) | MIT | `pip install pluggy` |
| **Hatch** | PyPA project manager with env matrices and version bumping | MIT | `pip install hatch` |

---

## MCP Servers

### DevOps & Code Quality

| Server | Stars | License | Description | Install |
|--------|-------|---------|-------------|---------|
| **GitHub Official MCP** | 28.2k | MIT | 100+ tools: PRs, issues, Actions, security alerts, Dependabot | `claude mcp add github -- docker run -i --rm -e GITHUB_PERSONAL_ACCESS_TOKEN ghcr.io/github/github-mcp-server` |
| **cyanheads/git-mcp-server** | 199 | Apache-2.0 | 28 tools including worktree management | `claude mcp add git-advanced -- npx @cyanheads/git-mcp-server@latest` |
| **mcp-server-analyzer** | — | MIT | Ruff + Vulture integration | `claude mcp add analyzer -- uvx mcp-server-analyzer` |
| **Trivy MCP** | — | MIT | Container + dependency vulnerability scanning (Aqua Security) | `trivy plugin install mcp` |
| **Semgrep MCP** | — | MIT | SAST + secrets detection (archived but functional) | `pip install semgrep-mcp` |
| **SonarQube MCP** | 443 | — | Code quality gates | Docker-based |
| **Snyk MCP** | — | Apache-2.0 | All-in-one SAST + SCA + IaC + container scanning | — |

### AWS & Infrastructure

| Server | Stars | License | Description | Install |
|--------|-------|---------|-------------|---------|
| **awslabs/mcp monorepo** | 8.5k | Apache-2.0 | 68+ official AWS MCP servers (see sub-servers below) | `claude mcp add <name> uvx awslabs.<name>@latest` |
| **AWS Knowledge MCP** | — | Free managed | Broadest AWS knowledge source | Add `"url": "https://knowledge-mcp.global.api.aws"` to .mcp.json |
| **HashiCorp Terraform MCP** | 1.3k | MPL-2.0 | Official Terraform registry integration | `docker run -i --rm hashicorp/terraform-mcp-server:0.4.0` |
| **Docker MCP** | 691 | GPL-3.0 | Container management | `claude mcp add docker uvx mcp-server-docker` |
| **Kubernetes MCP** | 1.4k | MIT | Full kubectl/helm API | `npx mcp-server-kubernetes` |
| **AWS FinOps MCP** | 176 | MIT | Cost analysis + waste audit | `uvx aws-finops-mcp-server` |

#### awslabs/mcp Sub-Servers

All installed via `claude mcp add <name> uvx awslabs.<name>@latest`:

| Sub-Server | Purpose |
|------------|---------|
| aws-documentation-mcp-server | Real-time AWS docs |
| aws-iac-mcp-server | CDK/CloudFormation with security validation |
| cloudwatch-mcp-server | Query metrics, alarms, dashboards |
| cost-explorer-mcp-server | Track AWS spending |
| aws-pricing-mcp-server | Estimate costs before provisioning |
| aws-serverless-mcp-server | Lambda + API Gateway |
| ecs-mcp-server | Container deployment/scaling |
| cloudtrail-mcp-server | Audit log queries |
| iam-mcp-server | IAM policy management |
| aws-network-mcp-server | VPC/subnet/security group management |
| aws-diagram-mcp-server | Generate architecture diagrams |
| terraform-mcp-server | AWS-specific Terraform support |

### API & Data

| Server | Stars | License | Description | Install |
|--------|-------|---------|-------------|---------|
| **mcp-sqlite** | 93 | MIT | Full CRUD on SQLite databases | `npx -y mcp-sqlite /path/to/db.db` |
| **mcp-rest-api** | 92 | MIT | Full HTTP methods for API testing | `npx -y dkmaker-mcp-rest-api` |
| **OpenAPI MCP (AWS)** | — | Apache-2.0 | Auto-generate tools from OpenAPI specs | `uvx awslabs.openapi-mcp-server@latest` |
| **mcp-finnhub** | — | MIT | Direct Finnhub access (15 tools) | `pip install -e .` from repo |
| **Alpha Vantage MCP** | 107 | MIT | Official, secondary market data source | — |
| **Financial Datasets MCP** | 1.7k | MIT | Income statements, balance sheets, cash flow | — |
| **Alpaca MCP** | 578 | MIT | 70+ tools, paper trading + market data | — |
| **Postgres MCP Pro** | 2.4k | MIT | If/when migrating beyond SQLite | — |

### Plugin & Dependency Management

| Server | Stars | License | Description | Install |
|--------|-------|---------|-------------|---------|
| **pypi-query-mcp** | 18 | — | 24 tools for PyPI package lookup, compatibility, versions | `uvx pypi-query-mcp-server` |
| **code-graph-mcp** | 84 | — | Cross-file reference tracking, call graphs, complexity | `pip install code-graph-mcp` |
| **mcp-python-refactoring** | 13 | MIT | Guided refactoring with rope/radon/vulture/jedi/bandit. Listed on official MCP Registry | — |
| **uv-mcp** | 14 | Apache-2.0 | uv wrapper for env diagnostics and self-healing | — |
| **mcp-code-checker** | 16 | — | pylint + pytest + mypy formatted for LLM consumption | — |

---

## Tools We Evaluated and Skipped

| Tool | Reason |
|------|--------|
| **Obsidian** | Strong ecosystem (official CLI, multiple MCP servers) but current CLAUDE.md + docs/ + .claude/ pattern already works. Revisit if going multi-project. |
| **AWS Copilot CLI** | End-of-support June 2026. |
| **SST** | Development stalled, team pivoted. |
| **Dendron** | Dead project, maintenance mode since 2023. |
| **Notion** | Cloud-dependent, paid for serious use. |

---

## Potential CI Pipeline Upgrade

**Current pipeline:**
```
ruff lint -> mypy -> pip-audit -> pytest -> deploy
```

**Proposed pipeline:**
```
ruff lint -> ty -> bandit -> semgrep -> pip-audit -> deptry -> gitleaks -> complexipy -> pytest -> deploy
```

Key changes:
- **ty** replaces mypy (10-60x faster, same Astral ecosystem as Ruff)
- **bandit** added for security SAST before dependency audit
- **semgrep** added for multi-language SAST with custom rules
- **deptry** added to catch missing/unused dependencies
- **gitleaks** added as a secrets gate before test execution
- **complexipy** added as a cognitive complexity gate (fail on functions exceeding threshold)

---

*Research conducted 2026-03-25 by 9 parallel research agents across 4 departments.*
