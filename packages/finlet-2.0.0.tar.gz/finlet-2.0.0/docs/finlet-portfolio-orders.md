---
tags: [finlet, core, portfolio, orders, trading]
keywords: portfolio engine, order system, positions, equity curve, slippage, market order, limit order, stop order
aliases: [portfolio, order book, trading engine]
priority: normal
---

# Finlet Portfolio & Order System

## Portfolio Engine (`finlet/core/portfolio.py`)

Tracks: cash, positions (ticker, quantity, avg_entry_price, current_price, unrealized/realized P&L), computed metrics (total_value, sharpe_ratio, max_drawdown, win_rate, alpha_vs_benchmark), equity curve (time series of EquitySnapshot).

- Cash rounded to 2 decimals after every mutation (prevents floating-point drift)
- Epsilon cleanup: positions < 1e-9 quantity are closed
- Concurrency: all mutations protected by asyncio.Lock()
- Persistence: atomic upsert via SQLite INSERT ... ON CONFLICT DO UPDATE

## Order System (`finlet/core/orders.py`)

### Types
- MARKET — auto-fill immediately at current price. If price unavailable, degrades to PENDING
- LIMIT — fills when price crosses limit with price improvement (BUY at min(current, limit))
- STOP — converts to MARKET when stop price triggered

### Time in Force
- GTC (good til cancelled, default)
- DAY — expires at market close

### Status Flow
PENDING -> FILLED | CANCELLED | REJECTED

### Slippage Model
FixedPercentageSlippage (default 10 bps) or NoSlippage. Configured per session via SessionConfig.slippage_bps.

## Session (`finlet/core/session.py`)

Lifecycle: CREATED -> ACTIVE -> PAUSED -> ACTIVE -> COMPLETED

Each session owns: user_id, SimClock, Portfolio, OrderBook, TraceLog.

SessionConfig: start_time, end_time, initial_capital ($100k default), universe (tickers), time_step, commission (0 for v1), slippage_bps (10), benchmark_ticker (SPY).

## Reasoning Trace (`finlet/core/trace.py`)

Append-only, tamper-evident audit log. Every interaction logged with: action_type, sim_time, real_time, request_params, response_summary, reasoning, latency_ms.

Rolling SHA-256 hash over all fields. Sealed when session completes — no further entries allowed.
