# Agent Ops Stack — Archive

Frozen snapshot of the Finlet agent ops stack at `ops.finlet.dev` (Hetzner CPX21, Ashburn). Captured 2026-05-01 immediately before teardown.

**Stack lifetime:** 2026-04-17 — 2026-05-01 (~14 days).
**Cost over lifetime:** ~$7 ($14/mo prorated).
**Cause of death:** Pre-revenue cognitive tax + n8n systemic gaps.

## What this is

Everything you'd need to rebuild the autonomous-CTO + bug-hunt orchestration we ran on n8n + Postgres + claude-runner during the 2-week experiment. Snapshot includes:

- `workflows/` — full JSON for all 32 n8n workflows (19 with full parameters from the n8n MCP `n8n_get_workflow` API; 13 abridged-but-faithful with topology, prompts, SQL queries, and node configs preserved — the omitted parts are duplicate `activeVersion` blocks the API returns)
- `executions-sample.json` — 20 most recent execution rows (~90 min of cron firings) confirming the stack was healthy at teardown
- This README

For the design rationale + runbook + all the gotchas already booked, the canonical doc is **`/Users/justnau/finlet/docs/AGENT_OPS_STACK.md`** in the main repo. That doc is authoritative for stack operation; this archive is the frozen artifact.

## Why we killed it

Full reasoning: **`/Users/justnau/finlet/docs/research/n8n-vs-sota-agent-orchestration.md`** (audit dated 2026-05-01).

TL;DR: pre-revenue, the cost of running an autonomous-CTO loop on n8n was higher than the value it produced. The autonomous loop never closed end-to-end — `skill-exec-plan` was a stub, specialists were built but the supervisor → specialist → merger handoff was untested in production. The systemic n8n gaps (no mid-flow checkpoint/resume, no native idempotency, brittle LLM-output branching, prompts buried in JSON) meant every step needed defensive plumbing. Cheaper to kill the substrate, keep the design as a paper trail, and rebuild post-revenue on a code-first durable runtime (Hatchet/DBOS hybrid recommended in the SOTA report).

## What was running

32 workflows total. By group:

### Bug-hunt loop (3 workflows, 1 active)
- **`bug-hunt`** (active, cron 12h) — Playwright probe of finlet.dev → Claude analyse → ops.bugs insert + Discord approval flow → on approve, trigger bug-fix-runner
- **`bug-fix`** (inactive, manual) — POST to bug-fix-runner :9101/fix; runner clones repo, opens worktree, runs Claude Opus, opens PR via `gh`
- **`bug-verify`** (inactive, cron 6h) — for merged PRs, re-probe + Claude verdict {resolved, reason} → finalize (resolved | triaged) + cleanup worktree/branch

### Blind-tester loop (1 workflow, active)
- **`blind-tester`** (active, cron 4h) — fresh Claude Opus pretends to be a new user, registers + creates strategy + runs benchmark; reports broken/annoying/nice. Self-deactivates after 2 consecutive 'green' runs (UPDATE workflow_entity SET active=false)

### CTO autonomous layer (12 workflows, 11 active)
- **`cto-supervisor`** (active, HMAC webhook) — central decision router; 4 actions: log_only / post_to_discord / spawn_sub_workflow / escalate_to_user
- **`intake`** (active, HMAC webhook) — front door; signs incoming events, calls supervisor
- **`cto-smart-chat`** (active) — interactive chat path
- **`cto-discord-listener`** (inactive) — Discord bot gateway → intake (with inline pure-JS HMAC because n8n task runner blocks `require('crypto')`)
- **`cto-daily-briefing`** (active, cron 20:00 UTC) — end-of-day CEO briefing to #cto-decisions
- **`cto-morning-research`** (active, cron 00:17 UTC) — daily 3-7-item research feed to #cto-research
- **`cto-prompt-drift-audit`** (active, cron 06:13 every 3 days) — scans active workflows for stale model/file/CLI/date refs
- **`cron-digest-hourly`** (active, cron `0 * * * *`) — last-hour cto_decisions → Discord digest
- **`cron-heartbeat-5min`** (active, cron */5min) — health probes; biggest source of executions by volume
- **`cron-self-compact-24h`** (active, cron 00:00) — re-writes ops.cto_handoff narrative from last 24h decisions
- **`workflow-fixer`** (active) — proposes prompt/tool patches inside other workflows; gated by Discord approval
- **`ops-decision-log-relay`** (active, webhook) — tight INSERT INTO ops.cto_decisions endpoint; path is bearer secret

### Skill graph (4 workflows, all active)
- **`skill-brainstorm`** → **`skill-debate`** → **`skill-plan-features`** → **`skill-exec-plan`** (STUB) — agentic pipeline backed by ops.cto_artifacts lineage chain via `stage_input_ref`. First three were chain-tested 2026-04-20; exec-plan was never wired to specialists.

### Specialists + mergers (10 workflows, all active)
SWE / DevOps / Security / Frontend-Security / AI-Research, each paired with a Merger sibling. Per CTO governance v2: specialist plans, merger commits — separation of duties so the planner cannot bless its own output. Built but not wired to a live workflow.

### Plumbing (2 workflows, both active)
- **`discord-post-relay`** (webhook, path acts as bearer secret, validates body, posts via Bot token to default channel 1497462256613593189)
- **`ops-hello (pipeline verification)`** (manual, smoke-test of n8n → claude-runner → Discord)

## What survives

- **`docs/AGENT_OPS_STACK.md`** — full design + runbook, decisions table, gotchas. Read this first if rebuilding.
- **`docs/research/n8n-vs-sota-agent-orchestration.md`** — the SOTA audit that justified the kill + recommended hybrid for v2.
- **`~/.claude/projects/-Users-justnau-finlet/memory/project_cto_governance.md`** — CTO governance v2 design (separation of duties, NO BULLSHIT, skill-graph, 4-round correction loop). Authoritative for v2 reconstruction.
- **`~/.claude/projects/-Users-justnau-finlet/memory/project_agent_ops_stack.md`** — short-form summary (will go stale after teardown but the why is preserved).
- **bug-hunt skill** (`.claude/skills/bug-hunt/`) — local Claude Code chat skill that does what the n8n bug-hunt workflow did, without the orchestration overhead. Already proven; keeps working post-kill.
- **Repo: `/Users/justnau/finlet/finlet-repo`** — the actual product code (Finlet) is unaffected. This kill only removes the agent-ops layer.

## What's gone (after main agent runs the kill)

- **Hetzner CPX21** — `finlet-ops`, server ID `127276276` at IP `87.99.156.168`
- **Postgres on that box** — n8n schema + `ops.*` schema (cto_state, cto_decisions, cto_handoff, cto_artifacts, cto_approvals, bugs, agent_runs, approval_queue). All 14 days of decision history dies with the box.
- **claude-runner systemd unit** — `:9099` HTTP shim that ran `claude -p` against the user's Max OAuth
- **bug-hunt-runner / bug-fix-runner systemd units** — `:9100` Playwright probe + `:9101` git-worktree + PR-opener
- **Cron jobs in n8n** — heartbeat-5min, digest-hourly, self-compact-24h, daily-briefing, morning-research, prompt-drift-audit, blind-tester, bug-hunt, bug-verify
- **Long-lived OAuth token** at `/opt/finlet-ops/claude-runner/.env` — `sk-ant-oat01-*` (Max-quota). Should be revoked at console.anthropic.com → Settings → API Keys after kill
- **DNS `ops.finlet.dev` → 87.99.156.168** — Cloudflare proxied; will return NXDOMAIN once DNS record removed (or just leave it; harmless)

## Restore notes for v2

When rebuilding post-revenue, **DO NOT recreate this stack as-is**. The SOTA audit's recommendation:

1. **Hybrid: keep n8n as the perimeter, move agent runtime to code-first**. n8n's webhook + Discord + cron + integrations are still earning their $0; the agent-state-machine + prompt-versioning + idempotency layer is where it bleeds.
2. **Pick Hatchet (Postgres-only mode) OR DBOS Transact** for the durable agent runtime. Both run on the existing CPX21 budget. Both make checkpointed steps + retries default-safe instead of a per-author rediscovery.
3. **Anchor agent prompts in git, not n8n JSON nodes**. PR review > Discord ack on a JSON edit.
4. **Keep CTO governance v2 design** (separation of duties, NO BULLSHIT, skill-graph stages, 4-round correction loop). It's still right. Just port it to typed Python state machines instead of n8n IF/Switch nodes.
5. **Don't reuse the Discord bot credential ID `dPXLeL3rJnK3JaKC`** — the token's encrypted in the dead Postgres, will need re-issue from Discord Developer Portal.

Re-read before reusing patterns:
- `~/.claude/projects/-Users-justnau-finlet/memory/feedback_n8n_schedule_trigger_testability.md` — cron-only workflows aren't externally triggerable; webhook side-door always required
- `~/.claude/projects/-Users-justnau-finlet/memory/reference_skill_graph_webhook_naming.md` — `skill-*` path prefix vs canonical name; translation map mismatch
- `~/.claude/projects/-Users-justnau-finlet/memory/reference_claude_oauth_token.md` — long-lived OAuth flow (`claude setup-token` → `CLAUDE_CODE_OAUTH_TOKEN` env, NOT `ANTHROPIC_API_KEY`)
- `docs/AGENT_OPS_STACK.md` "Gotchas" section — 20 booked gotchas including UFW Docker bridges, n8n env-access flag, Cloudflare LE through proxy, deploy-key-can-push-but-not-PR, and the bug-verify merged-window timing. All still apply.

## Known incomplete (at teardown)

- **`skill-exec-plan` was a stub.** v1 single-LLM-call enumerating "Tasks Dispatched" without actually spawning specialists. Task #5 (specialists + mergers wired through it) was the gating work and was never delivered.
- **The autonomous CTO loop never closed end-to-end.** Supervisor → spawn skill → spawn specialist → merger commit → cycle back was tested per-stage but never run as a single autonomous chain in production.
- **Specialists exist but were never invoked from a live trigger.** `specialist-swe` + paired `specialist-swe-merger` (and 4 other charters) were wired in n8n but the supervisor never routed to them in a real run.
- **Workflow-fixer never landed an autonomous patch.** Discord-approval gate was implemented but the end-to-end loop (workflow-fixer proposes patch → user approves on Discord → patch applied to other workflow) was never exercised live.
- **`cto-discord-listener` was never activated.** Discord bot credential placeholder (`REPLACE_WITH_CTO_CHAT_CHANNEL_ID`) was deliberately left for later; user wanted to gate listener-driven autonomy on more confidence.
- **No paid-tier integrations.** Composio, Langfuse, Stripe, Gmail were all "planned" — none arrived. Cost stayed at $14/mo Hetzner-only.

## Secret scrubbing

The archive was scanned for token literals matching `sk-ant-*`, `sk_live_*`, `xox*`, `ghp_*`, `ghs_*`, `password`, `secret`, `api_key`, plus Discord webhook URLs. No raw token values found in workflow JSON — n8n stores credential references by ID (e.g. `cQZd1wW1MLtHoMTH` for ops-postgres) and resolves the secret value at execution time from its encrypted Postgres credentials store. That store dies with the box. The credential IDs in the archived JSON are useless without the encryption key.

The hard-coded Discord channel ID `1497462256613593189` (default channel for discord-post-relay) and guild ID `1494757362437849270` are public-tier IDs, not secrets — left in the archive for v2 reference.
