---
tags: [finlet, oauth, mcp, migration, auth]
keywords: Finlet, MCP, OAuth 2.1, Bearer token, api_key, migration, Phase 4
priority: high
---

# MCP OAuth 2.1 Migration Guide

> **Status:** v2.0.0 current contract — OAuth JWT Bearer is canonical; `Authorization: Bearer fnlt_<api_key>` remains accepted for hosted `/mcp` compatibility; the legacy tool-argument `api_key=...` shape is rejected.
> **Audience:** anyone connecting an MCP client (Claude Desktop, Cursor, Windsurf, custom agents, the Finlet CLI) to Finlet's MCP server.
> **TL;DR:** run `finlet auth login`, then wire `finlet mcp serve` into your MCP client with no env vars. Headless clients may set `FINLET_API_KEY`; the stdio bridge forwards it as a Bearer credential to hosted `/mcp`.

## What changed

Finlet's hosted MCP server is an **OAuth 2.1 Resource Server**. Tool calls authenticate with an `Authorization: Bearer ...` credential:

- OAuth JWT Bearer is the canonical interactive path.
- `fnlt_<api_key>` as a Bearer credential is accepted for headless and compatibility flows.
- The old tool-argument shape (`{"api_key": "..."}` inside MCP tool arguments) is still rejected. Passing it returns the documented 401-style envelope with a pointer to this guide.

The default v2 stdio setup is `finlet mcp serve`: a local stdio bridge that reads `~/.finlet/credentials`, refreshes OAuth tokens near expiry, falls back to `FINLET_API_KEY` for headless runs, and proxies requests to hosted `/mcp`.

### Phase 4 sub-phases (chronological)

| Phase | Date | What shipped |
|-------|------|--------------|
| **4a** — design | 2026-05-08 | Decision record locking 5 OAuth choices: own AS via `mcp[auth]>=1.27.0`, EdDSA Ed25519 JWT (RFC 9068), open Dynamic Client Registration (RFC 7591), Resource Indicators (RFC 8707), same `UserRecord` identity binding. |
| **4b** — Authorization Server | 2026-05-08 | `/oauth/authorize`, `/oauth/token`, `/oauth/jwks`, `/oauth/.well-known/oauth-authorization-server`, `/oauth/register`. Four DB tables (`oauth_clients`, `oauth_authorizations`, `oauth_refresh_tokens`, `oauth_keys`) via migration `014`. |
| **4c** — Resource Server | 2026-05-09 | 16 MCP tools accept Bearer JWTs; `enforce_scope()` enforces `finlet:read` / `finlet:trade` / `finlet:benchmark` / `finlet:admin`. Dual-accept window opened (Bearer + api_key both worked). |
| **4d** — CLI client flow | 2026-05-09 | `finlet auth login` opens the system browser, drives the Authorization Code + PKCE flow, persists `{access_token, refresh_token, expires_at}` at `~/.finlet/credentials` (POSIX 0600). |
| **4e** — tool-argument api_key cutover | 2026-05-09 | Legacy tool-argument `api_key` on MCP calls began returning the documented 401 envelope. |
| **4e retraction / v1.0.1 hotfix** | 2026-05-11 | Hosted `/mcp` restored compatibility for `Authorization: Bearer fnlt_<api_key>` while keeping OAuth JWT as canonical and keeping tool-argument `api_key=...` rejected. |
| **v2.0.0 stdio bridge** | 2026-05-22 | `finlet mcp serve` became the canonical local bridge to hosted `/mcp`; `finlet mcp serve --self-host` keeps the local FastMCP server path for self-host operators. |

### Current resolver behavior

- `finlet/mcp/auth.py:_authenticate_oauth_or_key` validates OAuth JWT first, then falls back to `auth_service.validate_key()` for Bearer `fnlt_*` API keys.
- `finlet/mcp/bearer_context.py:resolve_credential` still rejects legacy tool-argument `api_key=...` when no Bearer credential is present.
- `finlet/mcp/stdio_proxy.py` is the default `finlet mcp serve` transport: it forwards stdio requests to hosted `/mcp` with a normal Authorization header.

### What was preserved

- `finlet/mcp/auth.py:_authenticate(api_key)` — the legacy primitive is still used by REST callers + a handful of unit tests; hosted MCP compatibility goes through the Bearer fallback in `_authenticate_oauth_or_key`.
- The MCP tool function signatures still carry `api_key: str | None = None` for call-site stability; the argument is silently ignored when a Bearer is present and triggers the rejection envelope when it is the only credential.
- The REST surface (`/v1/...` endpoints, plus deprecated unversioned aliases where they still exist) is **unchanged**. api_keys still work there.

## Per-client migration paths

### Claude Desktop

If you previously configured an `apiKey`, `env`, or HTTP variant in your Claude Desktop MCP server entry, remove it from the canonical setup. Authenticate once with `finlet auth login`, then let the stdio bridge handle hosted MCP calls.

Steps:

1. In your `claude_desktop_config.json`, ensure the Finlet entry uses `command: "finlet"` + `args: ["mcp", "serve"]` for stdio.
2. Run `finlet auth login` once from a terminal. Approve the consent screen.
3. The stdio bridge reads `~/.finlet/credentials`, refreshes near expiry, and forwards calls to hosted `/mcp`.

### Cursor / Windsurf / Continue

Same pattern as Claude Desktop: configure the local stdio command `finlet mcp serve` and remove legacy `apiKey`, `env`, or HTTP snippets from the canonical setup. If you are intentionally calling hosted `/mcp` directly, send `Authorization: Bearer <oauth_jwt>` or `Authorization: Bearer fnlt_<api_key>`.

### Finlet CLI (`finlet auth login`)

The CLI is the canonical OAuth client.

```bash
# One-time setup — opens browser, captures callback, persists credentials.
finlet auth login

# Inspect status
finlet auth status
ls -la ~/.finlet/credentials   # mode 0600

# Logout
finlet auth logout
```

Token storage:

- Path: `${HOME}/.finlet/credentials`
- POSIX mode 0600 enforced atomically on write AND on every read; if the mode drifts, the CLI raises a `RuntimeError` with `chmod 600` remediation guidance.
- JSON shape: `{"access_token": <JWT>, "refresh_token": <opaque>, "expires_at": <epoch-int>}`.

`finlet mcp serve` refreshes the access token before hosted MCP calls when the stored credential is near expiry. If refresh fails after expiry, re-run `finlet auth login` to mint a fresh pair.

The CLI's `--api-key=<key>` flag continues to work for **REST verification** — calling an authenticated REST endpoint to confirm a key is valid. For MCP, pass API keys as Bearer credentials (`FINLET_API_KEY` for the stdio bridge, or `Authorization: Bearer fnlt_<api_key>` for direct hosted `/mcp` callers), not as tool arguments.

### Custom agents / direct MCP-over-HTTP callers

Drive the standard OAuth 2.1 Authorization Code + PKCE flow against:

```
GET ${FINLET_URL}/oauth/authorize?
  response_type=code&
  client_id=<your_client_id>&
  redirect_uri=<your_redirect>&
  code_challenge=<S256_challenge>&
  code_challenge_method=S256&
  resource=https://finlet.dev/mcp&
  scope=finlet:read+finlet:trade+finlet:benchmark&
  state=<csrf>
```

Then exchange the captured `code` at `POST ${FINLET_URL}/oauth/token` with `grant_type=authorization_code` + `code_verifier` + `redirect_uri`. The resulting access token is an EdDSA-signed JWT with audience `https://finlet.dev/mcp` (per RFC 8707 — Resource Indicators are mandatory).

If you're a public client (e.g., a CLI tool), register dynamically via `POST /oauth/register` (RFC 7591 — open DCR with rate-limit + abuse heuristics). Self-hosters who want to lock down DCR can set `FINLET_OAUTH_DCR_ALLOWLIST_ONLY=1`.

Forward the access token to MCP tool calls as `Authorization: Bearer <jwt>`. Headless callers may also forward `Authorization: Bearer fnlt_<api_key>`. The `BearerContextMiddleware` plumbs the header through to every `@mcp.tool()` body; `api_key=...` inside tool arguments is still rejected.

## FAQ

### Why is `api_key=...` rejected if `fnlt_*` Bearer works?

The transport credential is the contract. `Authorization: Bearer ...` works consistently for OAuth JWTs and headless `fnlt_*` API keys, while tool-argument credentials keep sensitive tokens inside agent-visible JSON payloads and copied examples. Finlet rejects `api_key=...` so new client configs do not spread that pattern.

### Is REST `api_key` affected?

**No.** The REST surface continues to accept `X-API-Key: <key>` headers exactly as before:

- `/v1/...` endpoints — unaffected.
- The CLI's `--api-key=<key>` flag — calls REST verification, unaffected.
- The CLI's `FINLET_API_KEY` env var — used for REST `Authorization: Bearer <api_key>` headers and as the headless fallback for `finlet mcp serve`.

The split is intentional: REST accepts API keys in REST header form; MCP accepts credentials in Bearer transport form; MCP tool arguments do not carry credentials.

### What about scopes?

Scope enforcement from Phase 4c is **unchanged**. Bearer JWTs carry a space-delimited `scope` claim (RFC 6749 §3.3); the resource server's `enforce_scope(claims, required, user_record)` checks the requested scope against the granted set:

| Tool category | Required scope | Examples |
|---------------|----------------|----------|
| Read tools | `finlet:read` | `get_session`, `list_sessions`, `get_portfolio`, `get_price_data`, `get_fundamentals`, `get_filings`, `get_economic_data`, `get_sim_time`, `advance_time`, `freeze_time`, `cancel_order`, `get_trace` |
| Trade tools | `finlet:trade` | `submit_order` |
| Benchmark tools | `finlet:benchmark` | `start_benchmark`, `get_benchmark_progress`, `export_benchmark_results` |

Scopes are **gates inside a tier** — a user's tier (FREE / BUILDER / etc.) gates rate limits + feature flags first; the OAuth scope gates the specific capability the agent was authorized for. Tier does NOT veto scope and scope does NOT veto tier. See `docs/decisions/mcp-api-key-sunset.md` §3 for the locked contract (still in force post-retraction; only the sunset commitment is rescinded, not the scope-vs-tier semantics).

Bearer `fnlt_*` API keys resolve with `claims=None`, so `enforce_scope()` short-circuits on that compatibility path. Tier-based rate limits and feature flags still apply downstream through the resolved `UserRecord`.

### Where do I file an issue?

Check `docs/REMAINING_TASKS.md` for known gaps. For OAuth-specific issues, the decision records below are the contract source of truth — they describe what behavior is intentional vs. accidental.

## Lineage

This guide cross-references three decision records:

- `docs/decisions/mcp-oauth-2-1-auth-model.md` (Phase 4a) — the 5 OAuth decisions: AS topology, DCR posture, OAuth library, identity binding, token strategy.
- `docs/decisions/auth-login-cli-vs-api-key.md` (Phase 1 + 4d + 4e addenda) — the CLI's `auth login` semantics: credential verification (Phase 1), OAuth Authorization Code flow with PKCE + token storage (Phase 4d), and the MCP auth transition.
- `docs/decisions/mcp-api-key-sunset.md` (Phase 4c, retracted by the v1.0.1 hotfix) — the 90-day dual-accept window contract, fail-closed default, scope-vs-tier semantics. The retraction supersedes the sunset-window prose; the scope-vs-tier semantics remain in force.
