# Codex Audit — 2026-03-31

> Instances: 9 (9 succeeded, 0 failed) | Findings: 72 | Critical: 0 | High: 27 (10 RESOLVED) | Medium: 18 (3 RESOLVED) | Low: 27 (2 RESOLVED)

## Summary

| Concern | Findings | Critical | High | Medium | Low |
|---------|----------|----------|------|--------|-----|
| datetime-correctness | 7 | 0 | 2 | 4 | 1 |
| async-correctness | 8 | 0 | 1 | 4 | 3 |
| sql-input-safety | 6 | 0 | 0 | 1 | 5 |
| error-handling-gaps | 9 | 0 | 5 | 2 | 2 |
| api-auth-security | 10 | 0 | 2 | 1 | 7 |
| api-contract-consistency | 5 | 0 | 2 | 1 | 2 |
| plugin-resilience | 10 | 0 | 9 | 1 | 0 |
| state-concurrency | 8 | 0 | 6 | 2 | 0 |
| dead-code | 9 | 0 | 0 | 2 | 7 |

## High Findings

### datetime-correctness

#### H-DT-1: Clock silently reinterprets naive datetimes as UTC — RESOLVED
- **File:** finlet/core/clock.py:159
- **Check failed:** No timezone-naive objects crossing function boundaries
- **Evidence:**
```python
if start_time.tzinfo is None:
    start_time = start_time.replace(tzinfo=timezone.utc)
if end_time is not None and end_time.tzinfo is None:
    end_time = end_time.replace(tzinfo=timezone.utc)
```
- **Severity:** HIGH
- **Why:** Core clock entrypoints silently reinterpret naive inputs as UTC, so offsetless caller datetimes can move a simulation to the wrong instant.
- **Resolution:** `_require_aware()` guard added to all 5 clock entry points. Naive datetimes now raise `ValueError` instead of being silently reinterpreted. API returns 422 on naive input.

#### H-DT-2: SQLite reload produces naive datetimes — RESOLVED
- **File:** finlet/db/persistence.py:105
- **Check failed:** No timezone-naive objects crossing function boundaries
- **Evidence:**
```python
session.created_at = model.created_at
submitted_at=om.submitted_at,
timestamp=sm.timestamp,
sim_time=tm.timestamp_sim,
real_time=tm.timestamp_real,
```
- **Severity:** HIGH
- **Why:** Reloading a session from SQLite repopulates core session, order, snapshot, and trace objects with raw DB datetimes without UTC repair, which can yield offsetless API output and aware/naive comparison failures after restart.
- **Resolution:** `_ensure_utc()` applied to all datetime fields during SQLite reload in `persistence.py`, attaching UTC timezone to any naive datetimes returned by SQLite.

### async-correctness

#### H-AC-1: Blocking Stripe SDK calls on event loop — RESOLVED
- **File:** finlet/billing/service.py:193
- **Check failed:** No sync I/O (file reads, network calls) in async functions
- **Evidence:**
```python
session = stripe.checkout.Session.create(**checkout_params)
portal_session = stripe.billing_portal.Session.create(
stripe_invoices = stripe.Invoice.list(
promo_codes = stripe.PromotionCode.list(code=code, active=True, limit=1)
stripe.Subscription.modify(
```
- **Severity:** HIGH
- **Why:** These async billing paths make blocking Stripe SDK network calls on the event loop, so a slow Stripe response can stall unrelated requests.
- **Resolution:** All 6 blocking Stripe SDK calls wrapped in `asyncio.to_thread()` to offload to a thread pool, preventing event loop stalls.

### error-handling-gaps

#### H-EH-1: Stripe failure returns empty invoice list
- **File:** finlet/billing/service.py:295
- **Check failed:** External API errors wrapped with actionable detail
- **Evidence:**
```python
except stripe.StripeError as e:
    logger.warning("invoice_list_failed", user_id=user.id, error=str(e))
    return []
```
- **Severity:** HIGH
- **Why:** A Stripe failure is surfaced as an empty invoice list, so users get incorrect billing history instead of an actionable error.

#### H-EH-2: Stripe outage makes promo codes look invalid
- **File:** finlet/billing/service.py:361
- **Check failed:** External API errors wrapped with actionable detail
- **Evidence:**
```python
except stripe.StripeError as e:
    logger.warning("promo_validation_failed", code=code, error=str(e))
    return {"valid": False, "code": code}
```
- **Severity:** HIGH
- **Why:** Stripe outages make a promo code look invalid, which can wrongly block discounts and mislead the user about the cause.

#### H-EH-3: Tax failure returns zero-tax result
- **File:** finlet/marketplace/tax.py:302
- **Check failed:** External API errors wrapped with actionable detail
- **Evidence:**
```python
# Fail open
return TaxCalculationResult(
    subtotal_cents=amount_cents,
    tax_amount_cents=0,
    total_cents=amount_cents,
```
- **Severity:** HIGH
- **Why:** Stripe Tax HTTP failures are converted into a zero-tax result, so buyers can be shown "no tax applicable" when tax could not actually be calculated.

#### H-EH-4: Stripe failure makes developers appear tax-noncompliant
- **File:** finlet/marketplace/tax_forms.py:340
- **Check failed:** External API errors wrapped with actionable detail
- **Evidence:**
```python
except httpx.HTTPError as exc:
    logger.error(
        "stripe_account_http_error",
        developer_id=developer_id,
        error=str(exc),
```
- **Severity:** HIGH
- **Why:** On Stripe account lookup failure this path falls back to default DeveloperTaxInfo, which makes developers appear tax-noncompliant and can incorrectly block payouts.

#### H-EH-5: Webhook errors misreported as signature failures
- **File:** finlet/api/routes_marketplace_developer.py:502
- **Check failed:** External API errors wrapped with actionable detail
- **Evidence:**
```python
except Exception as e:
    logger.warning("marketplace_webhook_signature_failed", error=str(e))
    raise HTTPException(status_code=400, detail="Invalid webhook signature.")
```
- **Severity:** HIGH
- **Why:** Any unexpected Stripe/SDK failure is misreported as a client-side signature problem, which hides the real cause and sends operators in the wrong direction.

### api-auth-security

#### H-AA-1: Password-reset tokens in URL path — RESOLVED
- **File:** finlet/api/routes_email.py:417
- **Check failed:** No sensitive data in URL parameters or logs
- **Evidence:**
```python
reset_url = f"{config.base_url}/email/reset-password/{raw_token}"
```
- **Severity:** HIGH
- **Why:** Password-reset bearer tokens in the URL path can leak via browser history, referrers, proxy logs, and app logs, enabling account takeover if replayed.
- **Resolution:** 3 endpoints (`verify-token`, `process-reset`, `unsubscribe`) moved tokens from URL path to POST body via new `TokenRequest` Pydantic model. Tokens no longer appear in URLs, referrer headers, or request logs.

#### H-AA-2: Token URLs logged verbatim by middleware
- **File:** finlet/api/middleware.py:54
- **Check failed:** No sensitive data in URL parameters or logs
- **Evidence:**
```python
path=request.url.path,
```
- **Severity:** HIGH
- **Why:** Every request path is logged verbatim, so the tokenized /email/.../{token} routes write reset and verification secrets directly into structured logs.

### api-contract-consistency

#### H-CC-1: Billing errors use non-standard error format — RESOLVED
- **File:** finlet/api/routes_billing.py:61
- **Check failed:** Error responses use consistent format across all routes
- **Evidence:**
```python
return JSONResponse(
    status_code=502,
    content={"error": {"message": msg}},
)
```
- **Severity:** HIGH
- **Why:** POST /billing/checkout, GET /billing/portal, and POST /billing/cancel return an error object without the contract's required code and details, so clients cannot parse billing failures the same way as other API errors.
- **Resolution:** Custom `_stripe_error_response()` replaced with standard `HTTPException(status_code=502)`, which goes through the centralized error handler and produces the standard `{"error": {"code": "...", "message": "...", "details": [...]}}` envelope.

#### H-CC-2: Disabled marketplace returns 200 OK — RESOLVED
- **File:** finlet/api/app.py:417
- **Check failed:** HTTP status codes are correct for each operation type
- **Evidence:**
```python
_COMING_SOON = {"status": "coming_soon", "message": "The Finlet Strategy Marketplace is coming soon."}

async def _marketplace_coming_soon(request: Request) -> JSONResponse:
    return JSONResponse(_COMING_SOON)
```
- **Severity:** HIGH
- **Why:** When marketplace is disabled, any /marketplace/... path returns 200 OK, so unsupported or nonexistent endpoints look like successful operations instead of a missing/unavailable API.
- **Resolution:** Disabled marketplace handler now returns HTTP 503 with the standard error envelope `{"error": {"code": "SERVICE_UNAVAILABLE", "message": "..."}}` instead of 200 OK.

### plugin-resilience

#### H-PR-1: EDGAR filing_date not recognized by enforcer
- **File:** finlet/plugins/edgar_plugin.py:161
- **Check failed:** Date ceiling enforcer applied to every plugin response
- **Evidence:**
```python
"filing_date": filed_dt.isoformat(),
```
- **Severity:** HIGH
- **Why:** EDGAR returns filing_date instead of an enforcer-recognized timestamp key like date, so successful filings are stripped out by the global ceiling enforcer.

#### H-PR-2: Price search results lack timestamp — enforcer strips all
- **File:** finlet/plugins/price_plugin.py:341
- **Check failed:** Date ceiling enforcer applied to every plugin response
- **Evidence:**
```python
items = [{"symbol": sym, "name": "", "exchange": "US", "type": "EQUITY"} for sym in sorted(matches)[:20]]
```
- **Severity:** HIGH
- **Why:** Price search results contain no timestamp field, so the strict ceiling enforcer drops every returned item.

#### H-PR-3: Econ metadata items lack timestamp — enforcer strips all
- **File:** finlet/plugins/econ_plugin.py:632
- **Check failed:** Date ceiling enforcer applied to every plugin response
- **Evidence:**
```python
matches.append(
```
- **Severity:** HIGH
- **Why:** Econ search/info responses build metadata items without any timestamp key, so the ceiling enforcer strips them before callers see results.

#### H-PR-4: FRED metadata items lack timestamp — enforcer strips all
- **File:** finlet/plugins/fred_plugin.py:296
- **Check failed:** Date ceiling enforcer applied to every plugin response
- **Evidence:**
```python
items.append(
```
- **Severity:** HIGH
- **Why:** FRED search/info responses return metadata items with no timestamp field, so the ceiling enforcer removes all of them.

#### H-PR-5: Finnhub company_news — no timeout, no cache — RESOLVED
- **File:** finlet/plugins/finnhub_plugin.py:178
- **Check failed:** Every external HTTP call has a timeout set; Plugin cache used to avoid redundant calls
- **Evidence:**
```python
news = await asyncio.to_thread(self._client.company_news, ticker, _from=start, to=ceiling_date)
```
- **Severity:** HIGH
- **Why:** This hot path makes a fresh upstream call with no explicit timeout and no cache lookup/store, so identical requests can hang and rapidly consume Finnhub quota.
- **Resolution:** 30-second timeout and plugin cache integration added. Queries check cache before calling Finnhub API; results stored on miss.

#### H-PR-6: FRED observations — no timeout, no cache — RESOLVED
- **File:** finlet/plugins/fred_plugin.py:225
- **Check failed:** Every external HTTP call has a timeout set; Plugin cache used to avoid redundant calls
- **Evidence:**
```python
series = await asyncio.to_thread(self._client.get_series, series_id, **kwargs)
```
- **Severity:** HIGH
- **Why:** Each observations query hits FRED live with no explicit timeout and no cache layer, so repeated calls can stall and burn the daily request budget.
- **Resolution:** 30-second timeout and plugin cache integration added. Queries check cache before calling FRED API; results stored on miss.

#### H-PR-7: SEC EDGAR — no timeout, no cache — RESOLVED
- **File:** finlet/plugins/edgar_plugin.py:138
- **Check failed:** Every external HTTP call has a timeout set; Plugin cache used to avoid redundant calls
- **Evidence:**
```python
filings = company.get_filings()
```
- **Severity:** HIGH
- **Why:** SEC fetches are executed live on every query with no explicit timeout and no cache reuse, so repeated requests can hang and amplify provider throttling/outage impact.
- **Resolution:** 30-second timeout and plugin cache integration added. Queries check cache before hitting SEC EDGAR; results stored on miss.

#### H-PR-8: S3 downloads — no timeout — RESOLVED
- **File:** finlet/plugins/price_plugin.py:449
- **Check failed:** Every external HTTP call has a timeout set
- **Evidence:**
```python
await asyncio.to_thread(client.download_file, self._bucket, s3_key, str(local_path))
```
- **Severity:** HIGH
- **Why:** S3 downloads use the default boto3 client configuration, so a stalled network read can block a worker thread indefinitely.
- **Resolution:** boto3 S3 client configured with `Config(connect_timeout=10, read_timeout=30)` to prevent indefinite blocking on stalled network reads.

#### H-PR-9: BLS rate limit counter never enforced
- **File:** finlet/plugins/econ_plugin.py:741
- **Check failed:** Rate limit tracking and backoff implemented
- **Evidence:**
```python
self._bls_calls_today += 1
```
- **Severity:** HIGH
- **Why:** The BLS counter is only incremented and never enforced or used for backoff, so the plugin can continue sending requests into quota exhaustion and 429s.

### state-concurrency

#### H-SC-1: Race in play_continuous — double tick tasks
- **File:** finlet/core/session.py:238
- **Check failed:** Session state changes are atomic
- **Evidence:**
```python
await self.stop_continuous()
self._tick_interval = tick_interval
self._on_tick = on_tick
state = self.clock.enter_continuous_mode(speed)
self._continuous_task = asyncio.create_task(self._tick_loop())
```
- **Severity:** HIGH
- **Why:** Two concurrent play_continuous() calls can both get past stop_continuous() and each start a tick task, so one session can advance, fill orders, and snapshot twice.

#### H-SC-2: complete() races with tick loop
- **File:** finlet/core/session.py:154
- **Check failed:** Session state changes are atomic
- **Evidence:**
```python
self.clock.freeze()
self._status = SessionStatus.COMPLETED
self.trace.seal()
```
- **Severity:** HIGH
- **Why:** complete() does not synchronize with _tick_loop(), so a tick already inside its awaited callback/snapshot path can resume and call trace.record() on a sealed log, killing the background runner.

#### H-SC-3: Order marked FILLED before portfolio mutation
- **File:** finlet/core/session.py:431
- **Check failed:** Session state changes are atomic
- **Evidence:**
```python
filled = await self.order_book.process_pending_orders(prices, sim_time)
for order in filled:
    fill_price = order.fill_price or prices[order.ticker]
    try:
        if order.side == OrderSide.BUY:
```
- **Severity:** HIGH
- **Why:** Orders are marked FILLED before the portfolio mutation runs, so concurrent readers or persisters can observe a filled order while cash/positions still reflect the pre-fill state.

#### H-SC-4: Position upsert TOCTOU — duplicate rows
- **File:** finlet/db/persistence.py:299
- **Check failed:** No TOCTOU (time-of-check-time-of-use) patterns
- **Evidence:**
```python
result = await db.execute(
    select(PositionModel).where(
        PositionModel.session_id == session_id,
        PositionModel.ticker == position.ticker,
    )
)
existing = result.scalar_one_or_none()
```
- **Severity:** HIGH
- **Why:** This read-then-insert upsert is not protected by a unique key on (session_id, ticker), so concurrent saves can both observe "missing" and create duplicate position rows.

#### H-SC-5: Order submission spans multiple transactions
- **File:** finlet/api/services/trade_service.py:67
- **Check failed:** Database operations use proper transaction boundaries
- **Evidence:**
```python
await save_order(session_id, result)
await save_session(session)

await save_trace_entry(session_id, entry)
```
- **Severity:** HIGH
- **Why:** One logical order submission is committed in multiple independent transactions, so a mid-sequence failure can leave the order persisted while session state or trace rows are missing.

#### H-SC-6: Clock tick persists in separate commits
- **File:** finlet/api/services/clock_service.py:140
- **Check failed:** Database operations use proper transaction boundaries
- **Evidence:**
```python
await save_position(session.id, pos)

filled_orders = await session.process_pending_orders(prices)

await save_order(session.id, order)
```
- **Severity:** HIGH
- **Why:** A single refresh tick persists price updates, order fills, and later position changes in separate commits, so a failure can leave the database with filled orders but stale or missing position state.

## Medium Findings

### datetime-correctness

#### M-DT-1: Enforcer silently stamps UTC on naive ceilings
- **File:** finlet/core/enforcer.py:82
- **Check failed:** No timezone-naive objects crossing function boundaries
- **Evidence:**
```python
if ceiling.tzinfo is None:
    ceiling = ceiling.replace(tzinfo=timezone.utc)
if ts.tzinfo is None:
    ts = ts.replace(tzinfo=timezone.utc)
```
- **Severity:** MEDIUM
- **Why:** The date ceiling enforcer accepts naive datetimes and silently stamps UTC onto them, so future-data filtering can run against the wrong instant instead of rejecting bad inputs.

#### M-DT-2: Idempotency module strips timezone info
- **File:** finlet/api/idempotency.py:65
- **Check failed:** Every datetime object is timezone-aware (UTC)
- **Evidence:**
```python
now = datetime.now(timezone.utc).replace(tzinfo=None)
expires = now + _IDEMPOTENCY_TTL
created_at=now,
expires_at=expires,
```
- **Severity:** MEDIUM
- **Why:** Idempotency timestamps are intentionally stripped to naive values before storage and comparison, so this module violates the UTC-aware invariant and is fragile when mixed with aware datetimes.

#### M-DT-3: MFA state uses naive datetimes
- **File:** finlet/api/mfa.py:182
- **Check failed:** Every datetime object is timezone-aware (UTC)
- **Evidence:**
```python
return datetime.now(timezone.utc).replace(tzinfo=None)
if _utcnow_naive() > row.expires_at:
    await db.delete(row)
"expires_at": row.expires_at,
```
- **Severity:** MEDIUM
- **Why:** MFA session/OTP state is stored, compared, and returned with naive datetimes, so downstream code can receive offsetless expirations and mis-handle them when combined with aware UTC values.

#### M-DT-4: Session auth returns naive datetimes from SQLite
- **File:** finlet/api/session_auth.py:125
- **Check failed:** No timezone-naive objects crossing function boundaries
- **Evidence:**
```python
user_id=model.user_id,
created_at=model.created_at,
expires_at=model.expires_at,
)
```
- **Severity:** MEDIUM
- **Why:** lookup_session() returns SessionInfo with raw SQLite datetimes, so naive created_at/expires_at can escape the auth layer even though only a local copy is normalized for expiry checking.

### async-correctness

#### M-AC-1: Fire-and-forget auth persistence tasks
- **File:** finlet/auth/service.py:458
- **Check failed:** Every coroutine call is awaited
- **Evidence:**
```python
loop = asyncio.get_running_loop()
loop.create_task(self._persist_record(hashed, record))
loop = asyncio.get_running_loop()
loop.create_task(self._persist_record(key_hash, record))
```
- **Severity:** MEDIUM
- **Why:** Both persistence coroutines are launched fire-and-forget with no task tracking, so write failures become unobserved task exceptions and SQLite can diverge from in-memory auth state.

#### M-AC-2: Fire-and-forget benchmark task
- **File:** finlet/api/routes_leaderboard.py:165
- **Check failed:** Every coroutine call is awaited
- **Evidence:**
```python
from finlet.leaderboard.runner import run_benchmark_job

asyncio.create_task(run_benchmark_job(job_id, agent_id, mode="api_driven"))
```
- **Severity:** MEDIUM
- **Why:** The benchmark task handle is discarded immediately, so the API cannot await, cancel, or observe task failure cleanly.

#### M-AC-3: Sync Parquet reads on event loop
- **File:** finlet/plugins/price_plugin.py:470
- **Check failed:** No sync I/O (file reads, network calls) in async functions
- **Evidence:**
```python
if local_path.exists():
    try:
        table = pq.read_table(str(local_path))
        df = table.to_pandas()
```
- **Severity:** MEDIUM
- **Why:** Price search runs synchronous Parquet file reads and DataFrame materialization on the event loop, which can block other async work under load.

#### M-AC-4: Sync filesystem ops in async persistence
- **File:** finlet/db/persistence.py:206
- **Check failed:** No sync I/O (file reads, network calls) in async functions
- **Evidence:**
```python
if not SESSIONS_DIR.exists():
for session_dir in SESSIONS_DIR.iterdir():
if not db_file.exists():
if session_dir.exists():
    shutil.rmtree(session_dir)
```
- **Severity:** MEDIUM
- **Why:** Session startup and deletion paths perform blocking filesystem scans and recursive deletion inside async functions, which can pause the event loop.

### sql-input-safety

#### M-SI-1: Session ID path traversal before validation — RESOLVED
- **File:** finlet/db/engine.py:230
- **Check failed:** Path traversal prevention on file operations
- **Evidence:**
```python
db_dir = SESSIONS_DIR / session_id
db_dir.mkdir(parents=True, exist_ok=True)

engine = await _get_or_create_engine(_session_db_url(session_id))
```
- **Severity:** MEDIUM
- **Why:** A caller can supply .. or path separators and cause directory creation outside SESSIONS_DIR before validate_session_id() runs inside _session_db_url().
- **Resolution:** Validation guard added to `create_session_db` to reject path traversal before any filesystem operations.

### error-handling-gaps

#### M-EH-1: CSP reports silently dropped
- **File:** finlet/api/routes_csp.py:62
- **Check failed:** No exceptions caught and silently ignored
- **Evidence:** `except (json.JSONDecodeError, Exception): pass  # Malformed reports are silently dropped`
- **Severity:** MEDIUM
- **Why:** Malformed or unexpected failures in the CSP/client-error telemetry handlers disappear with no log, so monitoring blind spots are created.

#### M-EH-2: Auth persistence silently dropped outside event loop
- **File:** finlet/auth/service.py:629
- **Check failed:** No exceptions caught and silently ignored
- **Evidence:**
```python
try:
    loop = asyncio.get_running_loop()
    loop.create_task(self._persist_record(key_hash, record))
except RuntimeError:
    pass
```
- **Severity:** MEDIUM
- **Why:** Outside a running event loop, password-hash upgrades are dropped silently instead of being persisted, and the same silent skip is used for last-used/fingerprint persistence.

### api-auth-security

#### M-AA-1: Full phone numbers logged in MFA — RESOLVED
- **File:** finlet/api/mfa.py:331
- **Check failed:** No sensitive data in URL parameters or logs
- **Evidence:**
```python
logger.info("sms_otp_sent", phone=phone_number)
```
- **Severity:** MEDIUM
- **Why:** Full MFA phone numbers are written to logs, exposing a sensitive recovery factor to anyone with log access.
- **Resolution:** Phone numbers masked with `_mask_phone()` before logging.

### api-contract-consistency

#### M-CC-1: Request body too large uses non-standard error format
- **File:** finlet/api/security_middleware.py:84
- **Check failed:** Error responses use consistent format across all routes
- **Evidence:**
```python
return Response(
    content=f'{{"detail":"Request body too large. Maximum size is {self.max_bytes} bytes."}}',
    status_code=413,
    media_type="application/json",
)
```
- **Severity:** MEDIUM
- **Why:** Oversized requests bypass the app's standard error envelope and instead return a one-off {"detail": ...} shape.

### plugin-resilience

#### M-PR-1: Econ plugin requests bypass cache
- **File:** finlet/plugins/econ_plugin.py:394
- **Check failed:** Plugin cache used to avoid redundant calls
- **Evidence:**
```python
resp = await self._client.get(url, params=params)
```
- **Severity:** MEDIUM
- **Why:** BEA/BLS/Treasury/Fed requests in this plugin go straight upstream with no cache lookup/store, so repeated identical queries add latency and unnecessary quota pressure.

### state-concurrency

#### M-SC-1: Position property exposes mutable references
- **File:** finlet/core/portfolio.py:102
- **Check failed:** Portfolio mutations are serialized per session
- **Evidence:**
```python
@property
def positions(self) -> dict[str, Position]:
    return dict(self._positions)
```
- **Severity:** MEDIUM
- **Why:** This only copies the dict, not the Position objects, so callers receive live mutable positions that can be changed outside Portfolio._lock.

#### M-SC-2: Session visible before DB exists — RESOLVED
- **File:** finlet/api/services/session_service.py:73
- **Check failed:** Session state changes are atomic
- **Evidence:**
```python
sessions = get_sessions()
sessions[session.id] = session

await create_session_db(session.id)
await save_session(session)
```
- **Severity:** MEDIUM
- **Why:** The new session becomes visible in shared in-memory state before its database exists, so concurrent requests can use a half-created session.
- **Resolution:** Reordered to create DB first, then add session to in-memory map.

### dead-code

#### M-DC-1: Unused failed-auth rate limit functions
- **File:** finlet/api/rate_limit.py:475
- **Check failed:** No functions/classes that are never called/instantiated
- **Evidence:** `async def record_failed_auth(ip: str) -> None:` / `async def clear_failed_auth_log() -> None:`
- **Severity:** MEDIUM
- **Why:** The failed-auth burst path is completely unreferenced, so the codebase advertises security alerting and test cleanup that never actually runs.

#### M-DC-2: Unused session maintenance helpers
- **File:** finlet/api/session_auth.py:170
- **Check failed:** No functions/classes that are never called/instantiated
- **Evidence:** `async def revoke_all_user_sessions(user_id: str) -> int:` / `async def cleanup_expired_sessions() -> int:`
- **Severity:** MEDIUM
- **Why:** These session-maintenance helpers are unreferenced, so the code suggests revocation/cleanup flows exist when no live path invokes them.

## Low Findings

### datetime-correctness

#### L-DT-1: last_used_at left naive in UserRecord
- **File:** finlet/auth/service.py:148
- **Check failed:** No timezone-naive objects crossing function boundaries
- **Evidence:**
```python
last_ip=model.last_ip,
last_user_agent=model.last_user_agent,
last_used_at=model.last_used_at,
secondary_key_hash=model.secondary_key_hash,
secondary_key_created_at=_ensure_utc(model.secondary_key_created_at),
```
- **Severity:** LOW
- **Why:** _model_to_record() repairs some SQLite-loaded datetimes but leaves last_used_at naive, so callers receive inconsistent datetime semantics from the same UserRecord.

### async-correctness

#### L-AC-1: Sync markdown reads in legal routes
- **File:** finlet/api/routes_legal.py:154
- **Check failed:** No sync I/O (file reads, network calls) in async functions
- **Evidence:**
```python
raw = md_path.read_text(encoding="utf-8")
html_body, title, raw = _render_page("privacy")
html_body, title, raw = _render_page("terms")
```
- **Severity:** LOW
- **Why:** Both async legal-page handlers read markdown from disk synchronously on each request, which blocks the event loop for filesystem access.

#### L-AC-2: Sync filesystem ops in DB engine init
- **File:** finlet/db/engine.py:115
- **Check failed:** No sync I/O (file reads, network calls) in async functions
- **Evidence:**
```python
FINLET_DIR.mkdir(parents=True, exist_ok=True)
db_dir.mkdir(parents=True, exist_ok=True)
if not db_path.exists():
if not AUTH_DB_PATH.exists():
```
- **Severity:** LOW
- **Why:** Core async database helpers perform synchronous filesystem creation/stat calls on the event loop before opening async sessions.

#### L-AC-3: httpx client missing explicit timeout
- **File:** finlet/leaderboard/api_strategy.py:244
- **Check failed:** httpx clients use timeout parameters
- **Evidence:**
```python
async with httpx.AsyncClient(
    transport=httpx.ASGITransport(app=app),
    base_url="http://testserver",
) as client:
```
- **Severity:** LOW
- **Why:** This httpx.AsyncClient relies on implicit defaults instead of an explicit timeout bound.

### sql-input-safety

#### L-SI-1: Migration runner path traversal
- **File:** finlet/db/migrations/runner.py:156
- **Check failed:** Path traversal prevention on file operations
- **Evidence:**
```python
db_path = FINLET_DIR / "sessions" / session_id / "session.db"
if not db_path.exists():
    return
```
- **Severity:** LOW
- **Why:** session_id is concatenated into a filesystem path with no validation, so a crafted value can redirect migrations to an unintended SQLite file.

#### L-SI-2: Alembic env path traversal
- **File:** finlet/db/migrations/env.py:65
- **Check failed:** Path traversal prevention on file operations
- **Evidence:**
```python
elif db_type == "session":
    if not session_id:
        raise ValueError("session_id required when db_type=session")
    return f"sqlite:///{FINLET_DIR / 'sessions' / session_id / 'session.db'}"
```
- **Severity:** LOW
- **Why:** Alembic -x session_id=... input is inserted into the SQLite path without validation, so ../ segments can escape the intended session directory.

#### L-SI-3: Migration 004 — interpolated ALTER TABLE
- **File:** finlet/db/migrations/versions/004_add_mfa_fields.py:52
- **Check failed:** No raw string interpolation in SQL queries
- **Evidence:**
```python
for col_name, col_type in columns_to_add:
    if col_name not in existing_cols:
        conn.execute(sa.text(f"ALTER TABLE api_keys ADD COLUMN {col_name} {col_type}"))
```
- **Severity:** LOW
- **Why:** Executes interpolated SQL text rather than parameterized; values are static today, but any future non-literal input here becomes an injection sink.

#### L-SI-4: Migration 006 — interpolated ALTER TABLE
- **File:** finlet/db/migrations/versions/006_add_session_fingerprinting.py:42
- **Check failed:** No raw string interpolation in SQL queries
- **Evidence:** Same pattern as L-SI-3.
- **Severity:** LOW
- **Why:** Same interpolation risk as L-SI-3.

#### L-SI-5: Migration 007 — interpolated ALTER TABLE
- **File:** finlet/db/migrations/versions/007_add_key_rotation_fields.py:42
- **Check failed:** No raw string interpolation in SQL queries
- **Evidence:** Same pattern as L-SI-3.
- **Severity:** LOW
- **Why:** Same interpolation risk as L-SI-3.

### error-handling-gaps

#### L-EH-1: Malformed Content-Length bypasses size guard
- **File:** finlet/api/security_middleware.py:89
- **Check failed:** No exceptions caught and silently ignored
- **Evidence:** `except ValueError: pass`
- **Severity:** LOW
- **Why:** If a malformed Content-Length header reaches this middleware, the request-size guard is bypassed without any rejection or log.

#### L-EH-2: Plugin error logging uses % formatting
- **File:** finlet/plugins/price_plugin.py:179
- **Check failed:** Logging includes structured context (not just str(e))
- **Evidence:**
```python
except Exception as e:
    logger.error("PricePlugin query error for %s: %s", ticker, e)
    return PluginResponse(
```
- **Severity:** LOW
- **Why:** The failure is flattened into a formatted string instead of structured fields, making production query errors harder to filter and correlate.

### api-auth-security

#### L-AA-1: Verification token in URL — RESOLVED
- **File:** finlet/api/routes_email.py:330
- **Check failed:** No sensitive data in URL parameters or logs
- **Evidence:** `verification_url = f"{config.base_url}/email/verify/{raw_token}"`
- **Severity:** LOW
- **Why:** The email-verification secret is placed in the URL path, so anyone with URL visibility can replay it.
- **Resolution:** Moved to POST body by Team B.

#### L-AA-2: Unsubscribe token in URL — RESOLVED
- **File:** finlet/api/routes_email.py:305
- **Check failed:** No sensitive data in URL parameters or logs
- **Evidence:** `return f"{base_url}/email/unsubscribe/{raw_token}"`
- **Severity:** LOW
- **Why:** The unsubscribe bearer token is embedded in the URL path and can be exposed anywhere URLs are stored or logged.
- **Resolution:** Moved to POST body by Team B.

#### L-AA-3: Forgot-key endpoint leaks existence to logs
- **File:** finlet/auth/mfa.py:111
- **Check failed:** No sensitive data in URL parameters or logs
- **Evidence:** `logger.info("forgot_key_no_user", email=email)`
- **Severity:** LOW
- **Why:** This defeats the endpoint's generic forgot-key response by preserving account-existence results and the submitted email in logs.

#### L-AA-4: Password-reset endpoint leaks existence to logs
- **File:** finlet/api/routes_email.py:444
- **Check failed:** No sensitive data in URL parameters or logs
- **Evidence:** `logger.info("reset_email_no_user", email=body.email)`
- **Severity:** LOW
- **Why:** This preserves password-reset account-existence results and raw email addresses in logs even though the HTTP response is intentionally enumeration-safe.

#### L-AA-5: Session endpoint lacks rate limiting
- **File:** finlet/api/routes_auth.py:644
- **Check failed:** Rate limiting applied to auth endpoints
- **Evidence:** `record = validate_key(body.api_key)`
- **Severity:** LOW
- **Why:** The public session-establishment endpoint validates API keys with no explicit throttle.

#### L-AA-6: MFA sign-in endpoint lacks rate limiting
- **File:** finlet/api/routes_auth_mfa.py:181
- **Check failed:** Rate limiting applied to auth endpoints
- **Evidence:** `return await sign_in(body.api_key)`
- **Severity:** LOW
- **Why:** This public API-key sign-in endpoint performs credential validation with no rate-limit check.

#### L-AA-7: Auth session endpoint exempt from CSRF
- **File:** finlet/api/security_middleware.py:37
- **Check failed:** CSRF protection on state-changing operations
- **Evidence:** `"/v1/auth/session",  # Session creation endpoint (exchanges API key for cookie)`
- **Severity:** LOW
- **Why:** The cookie-establishing auth endpoint is explicitly exempt from CSRF checks, creating a login-CSRF/session-fixation risk.

### api-contract-consistency

#### L-CC-1: CSP route returns bare status-only errors
- **File:** finlet/api/routes_csp.py:72
- **Check failed:** Error responses use consistent format across all routes
- **Evidence:**
```python
body = await request.body()
if len(body) > 10_000:  # 10KB limit
    return Response(status_code=413)
```
- **Severity:** LOW
- **Why:** This telemetry route returns bare status-only error responses, so clients hitting its failure paths do not receive the API's standard JSON error envelope.

#### L-CC-2: Market route lacks interval/period validation
- **File:** finlet/api/routes_market.py:117
- **Check failed:** Missing request validation on route parameters
- **Evidence:**
```python
ticker: str = Query(..., description="Ticker symbol (e.g. 'AAPL', 'BTC-USD')"),
interval: str = Query("1d", description="Data interval: '1d', '1h', '5m'"),
period: str = Query("1mo", description="Lookback period: '5d', '1mo', '3mo', '1y'"),
```
- **Severity:** LOW
- **Why:** The route documents finite allowed values for interval and period but does not enforce them at the HTTP boundary.

### dead-code

#### L-DC-1: Unused email request model and helper
- **File:** finlet/api/routes_email.py:44
- **Check failed:** No functions/classes that are never called/instantiated
- **Evidence:** `class SendVerificationRequest(BaseModel):` / `async def should_send_notification(user_id: str, notification_type: str) -> bool:`
- **Severity:** LOW
- **Why:** This module carries an unused request model and an unused cross-module helper.

#### L-DC-2: Unused PluginHealthResponse model
- **File:** finlet/api/routes_health.py:16
- **Check failed:** No functions/classes that are never called/instantiated
- **Evidence:** `class PluginHealthResponse(BaseModel):` / `async def plugins_health() -> list[dict[str, Any]]:`
- **Severity:** LOW
- **Why:** The endpoint returns raw dictionaries, so this response model is dead.

#### L-DC-3: Unused marketplace admin helpers
- **File:** finlet/api/routes_marketplace_admin.py:49
- **Check failed:** No functions/classes that are never called/instantiated
- **Evidence:** `def set_admin_users(user_ids: set[str]) -> None:` / `def add_admin_user(user_id: str) -> None:` / `class ApproveRequest(BaseModel):`
- **Severity:** LOW
- **Why:** The admin module exposes mutation helpers and a request model that nothing in the repository uses.

#### L-DC-4: Unused ExportDataRequest model
- **File:** finlet/api/routes_settings.py:86
- **Check failed:** No functions/classes that are never called/instantiated
- **Evidence:** `class ExportDataRequest(BaseModel):` / `async def export_data(`
- **Severity:** LOW
- **Why:** The export endpoint does not accept this model, so the unused request type is misleading dead surface.

#### L-DC-5: Orphaned DMCA helpers
- **File:** finlet/marketplace/dmca.py:19
- **Check failed:** No functions/classes that are never called/instantiated
- **Evidence:** `async def generate_dmca_registration_data(` / `async def get_current_dmca_agent() -> dict[str, Any] | None:`
- **Severity:** LOW
- **Why:** The DMCA helper API is defined but never consumed anywhere in the repo.

#### L-DC-6: Orphaned marketplace persistence helpers
- **File:** finlet/marketplace/persistence.py:108
- **Check failed:** No functions/classes that are never called/instantiated
- **Evidence:** `async def get_developer_by_id(developer_id: str) -> DeveloperProfile | None:` / `async def get_attestation_history(developer_id: str) -> list[ComplianceAttestation]:` / `async def get_review_by_id(review_id: str) -> AdminReview | None:`
- **Severity:** LOW
- **Why:** These repository helpers have no callers, leaving dead database access paths.

#### L-DC-7: Orphaned tax DTOs and methods
- **File:** finlet/marketplace/tax.py:49
- **Check failed:** No functions/classes that are never called/instantiated
- **Evidence:** `class NexusStatus(str, Enum):` / `class TaxLineItem:` / `class TaxCalculationRequest(BaseModel):` / `async def get_nexus_recommendations(self) -> list[dict[str, Any]]:`
- **Severity:** LOW
- **Why:** This tax module contains multiple unreferenced DTOs and a service method, making the tax integration look more complete than it is.

## Duplicates Merged

No exact file:line duplicates found across concerns. Notable cross-concern overlaps (different lines, same file):

1. **finlet/auth/service.py** — Fire-and-forget task pattern flagged by both async-correctness (M-AC-1, line 458) and error-handling-gaps (M-EH-2, line 629). Same root cause: untracked background tasks with swallowed failures.

2. **finlet/billing/service.py** — Flagged by async-correctness (H-AC-1, line 193 — blocking Stripe calls) and error-handling-gaps (H-EH-1/H-EH-2, lines 295/361 — swallowed Stripe errors). Different aspects of the same Stripe integration gaps.

3. **finlet/api/security_middleware.py** — Flagged by error-handling-gaps (L-EH-1, line 89), api-contract-consistency (M-CC-1, line 84), and api-auth-security (L-AA-7, line 37). Three different concerns in one middleware file.
