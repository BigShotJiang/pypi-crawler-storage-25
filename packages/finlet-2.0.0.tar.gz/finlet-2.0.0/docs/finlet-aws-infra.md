---
tags: [finlet, aws, terraform, infrastructure]
keywords: terraform, aws, ec2, s3, iam, cloudwatch, deploy
aliases: [finlet infra, finlet terraform]
priority: normal
---

# Finlet AWS Infrastructure (Terraform)

All configs in `finlet/deploy/aws/`. Single-server, free-tier-optimized.

## Compute
- **EC2** — t3.micro, Ubuntu 22.04 LTS, 8GB gp3 encrypted root, IMDSv2 required
- **Elastic IP** — stable public IP across stop/start
- **SSM Session Manager** — primary shell access (SSH SG rule blocks all by default)
- **user-data.sh** — cloud-init bootstrap (referenced, not inline)

## Storage — 2 S3 Buckets

| Bucket | Purpose | Policy |
|--------|---------|--------|
| `finlet-backups-{hex}` | Nightly SQLite backups | Versioned, 30-day expiry, KMS encrypted |
| `finlet-data-{hex}` | EOD OHLCV Parquet + all plugin data | No versioning (immutable), KMS encrypted |

Both have full public access blocks.

## IAM — 2 Principals

1. **EC2 instance role** (`finlet-ec2-role`):
   - Read/write backups bucket
   - Read + scoped write to data bucket (prices/daily, fundamentals, news/daily, sentiment/daily, reference, economic, edgar)
   - SES send for finlet.dev
   - SSM core

2. **Ingestor IAM user** (`finlet-ingestor`):
   - Write-only to data bucket paths + read for head_object checks + ListBucket
   - For `scripts/ingest_daily.py` running outside EC2
   - Access key output as sensitive

## Monitoring (CloudWatch)
- SNS topic + email subscription (gated on `alert_email` var)
- CPU alarm: >80% for 5 consecutive minutes
- Status check alarm: immediate on any failure

## State Backend
- S3: `finlet-tfstate-8b0083d0` + DynamoDB locking
- Terraform >= 1.5, AWS provider ~> 5.0

## DNS
Not in Terraform. Cloudflare registrar, A record for finlet.dev -> EIP, DNS-only mode.

## Deploy Pipeline Env Vars

The GitHub Actions deploy workflow (`deploy.yml`) passes these env vars via SSM to the EC2 instance, where `deploy.sh` writes them to `/opt/finlet/.env`:

| Env Var | Purpose | Source |
|---------|---------|--------|
| `FINLET_PRICE_BUCKET` | S3 bucket for price data plugin | GitHub secret |
| `FINLET_FUNDAMENTALS_BUCKET` | S3 bucket for fundamentals data plugin | GitHub secret |

Both default to `finlet-data` in code if not set.

## What's NOT Provisioned
No ALB, ASG, RDS, Lambda, custom VPC, CloudFront, or WAF. Single-box with Caddy handling TLS on-instance.

## Files
- `main.tf` — Provider, EC2, EIP, SG, S3 buckets, IAM role, SES permissions
- `iam-ingestor.tf` — Ingestor IAM user + policy
- `cloudwatch.tf` — SNS + CPU/status alarms
- `variables.tf` — domain, region, instance_type, key_pair_name, alert_email
- `outputs.tf` — instance_id, public_ip, elastic_ip, bucket names, SSM command
- `backend.tf` — Remote S3 + DynamoDB state
- `versions.tf` — Provider version constraints
