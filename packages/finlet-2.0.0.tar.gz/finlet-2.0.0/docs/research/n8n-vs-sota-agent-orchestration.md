# n8n vs SOTA Agent Orchestration — Architectural Audit

**Date:** 2026-05-01
**Author:** Architecture audit for the Finlet CTO agent stack
**Authoritative scope:** Is n8n the right substrate for an autonomous-engineer ("CTO agent") control plane? Or are we hitting systemic limits and need to migrate?

---

## 1. TL;DR

**The CTO agent's pain points are systemic to n8n, not bugs.** n8n has no checkpoint/resume of agent state mid-flow, no native idempotency, weak prompt-versioning, and JSON-branching that requires defensive parsing — these are architectural choices, not patch targets. **Recommendation: hybrid migration.** Keep n8n as the cron/glue/Discord-fanout layer; move the skill-graph + supervisor to a code-first durable runtime (Hatchet or DBOS, both Postgres-native, both run on the existing CPX21). Don't full-migrate yet — n8n's webhook + integrations layer is still earning its $0.

---

## 2. Current State (validated against docs)

- **Host:** Hetzner CPX21 Ashburn ($14/mo, 3 vCPU / 4GB / 80GB), Docker compose: Postgres 16 + n8n 2.16.1 + Caddy. `claude-runner` systemd service on host exposes `claude -p` over `:9099`, billing every LLM call against the user's Max subscription. ([`docs/AGENT_OPS_STACK.md`](../AGENT_OPS_STACK.md))
- **Active workflows (as of 2026-04-20):** `cto-supervisor` (HMAC-protected webhook), `skill-brainstorm`, `skill-debate`, `skill-plan-features`, `skill-exec-plan` (v1 stub). All four skill-graph stages chain-tested 2026-04-20. `bug-hunt`, `bug-fix`, `bug-verify`, `ops-hello` imported but inactive.
- **State backbone:** Postgres `ops.*` schema — `cto_state` (in-flight task tree, heartbeats), `cto_decisions` (append-only with FTS), `cto_handoff` (singleton 7-day rolling narrative), `cto_artifacts` (lineage chain via `stage_input_ref`), `cto_approvals` (severity ≥ high gate).
- **Governance (CTO v2, 2026-04-18):** CTO never touches code. Skill-graph orchestration. 4-round correction loop → workflow-fixer (Discord-approval-gated) → escalate. Severity {high, medium, low, info} auto-dispatch; **critical** escalates. Discord is sole human surface. ([`memory/project_cto_governance.md`](../../../.claude/projects/-Users-justnau-finlet/memory/project_cto_governance.md))
- **Known friction (already booked):**
  - Cron-only workflows can't be smoke-tested via `mcp__n8n__n8n_test_workflow` — webhook trigger node required as a side door. ([`memory/feedback_n8n_schedule_trigger_testability.md`](../../../.claude/projects/-Users-justnau-finlet/memory/feedback_n8n_schedule_trigger_testability.md))
  - Webhook path naming mismatch (`brainstorm` → `/webhook/skill-brainstorm`) requires a translation map in the supervisor's `spawn: sign + prepare` node. ([`memory/reference_skill_graph_webhook_naming.md`](../../../.claude/projects/-Users-justnau-finlet/memory/reference_skill_graph_webhook_naming.md))
  - Public API has no `POST /workflows/{id}/execute` (returns 405 in 2.16.x). Internal `/rest/workflows/{id}/run` works but needs cookie auth + `triggerToStartFrom` payload. (Gotcha #11, AGENT_OPS_STACK)
  - `dbTime.getTime is not a function` errors in container logs (separate known bug, doesn't affect correctness).

**Contradiction to flag:** AGENT_OPS_STACK documents Phase 3 ephemeral-CTO supervisor as live + skill-graph chain-tested through `plan-features`, but `skill-exec-plan` is a stub that doesn't actually spawn specialists. The current stack cannot autonomously execute fixes through the skill graph yet — Task #5 (specialists + mergers) is the gating work. The pain you're reporting is real, but it's hitting the part of the system where n8n is doing the most work, not where it's most validated.

---

## 3. State-of-the-Art Landscape (April 2026)

### Durable execution engines

| Tool | Lead | Why it matters |
|---|---|---|
| **Temporal 1.0** (Jan 2026, $5B raise Feb 2026) | enterprise leader | "Very long-running workflows" pattern enables agents with weeks-to-years state. 1.86T AI-native action executions on cloud. Heavy operational footprint (7+ services). |
| **DBOS Transact** (Postgres-only, 2026-Q1) | self-host minimalist | Annotate Python functions → checkpointed in Postgres. Zero new infrastructure beyond the DB you already have. |
| **Hatchet v1** (YC W24, prod 2026) | hybrid | Postgres-only mode for <100 events/sec. Built for "background tasks, AI agents, durable workflows" — explicit AI agent positioning. |
| **Inngest 1.0 self-host** (Jan 2026) | event-driven | Single-binary self-host. 50k execs/mo free on cloud. Event-first model fits human-in-loop. |
| **Trigger.dev v4** (early 2026) | TS-first | "Easier Temporal with integrations." Self-host needs ~8GB worker — too heavy for CPX21. |
| **Restate** (commercial March 2026) | minimalist | Lighter than Temporal, journal/replay, but newer and less battle-tested. |

**Leaders for our case:** **Hatchet** and **DBOS** — both run on the existing Postgres, both fit the CPX21 budget.

### Agent-native orchestrators

| Tool | Lead | Why |
|---|---|---|
| **LangGraph** | multi-agent leader | Checkpointer persists thread state — workflows resumable across sessions. Steepest learning curve. Self-host needs Postgres + Redis (no extra infra for us). |
| **Anthropic Claude Managed Agents** (April 8, 2026) | Anthropic-native | Hosted-only, $0.08/session-hour + token cost, vendor lock-in risk. Decouples session/harness/sandbox into independent failure domains. NOT compatible with Max-OAuth zero-marginal-cost model. |
| **Claude Agent SDK** (general-purpose, 2026) | self-host Anthropic | Extracted from Claude Code internals. Python + TypeScript. Runs on your infra. Compatible with our Max-OAuth `claude -p` shim. |
| **Pydantic AI / Pydantic Graph** | typed Python agents | Type-safe, lightweight. Less mature multi-agent than LangGraph. |
| **Mastra** | TS-first | Out for us — we're Python. |

**Leader for our case:** **LangGraph** for the agent runtime, OR roll directly with **Claude Agent SDK** (preserves Max-OAuth path).

### Code-first workflow runners

- **Prefect 3** — Python-native, agent-based execution, low ceremony. Best for ML/operational flows.
- **Dagster** — asset-first, lineage. Overkill for agent ops; designed for data pipelines.
- **Kestra** — YAML + multi-language. Powerful for heterogeneous stitching.
- **Airflow 3** — too heavyweight, not agent-native.

Not the right category for autonomous agents specifically.

### No-code competitors to n8n

- **Activepieces** — closest n8n alt, MIT, native MCP support, AI-agent forward.
- **Windmill** — code-first; constant ~150MB orchestrator memory; Rust core. n8n by contrast "balloons to 2GB+ on complex workflows."
- **Make.com / Zapier / Pipedream** — managed-only, expensive at scale, sovereignty fail.

### AI-native ops + observability

- **LangSmith** — LangChain-native, prompt versioning, A/B, deployment.
- **Braintrust** — eval-science-first, blocks deploys that fail staging evals. Strongest prompt-versioning + quality-gate story.
- **Latitude / Helicone** — narrower scope.
- **Langfuse** (already planned) — self-hostable, OpenTelemetry-style traces.

---

## 4. Capability Matrix — n8n vs Top 3 Alternatives

For each row: **green** = strong fit, **yellow** = workable with effort, **red** = systemic mismatch.

| Capability | **n8n 2.16** | **Hatchet (self-host)** | **DBOS Transact** | **LangGraph (self-host)** |
|---|---|---|---|---|
| Durable state across mid-flow LLM death | **Red** — no agent-state checkpoint/resume mid-flow; restart-from-scratch is the model. ([ZenML LangGraph vs n8n](https://www.zenml.io/blog/langgraph-vs-n8n)) | **Green** — durable queues, checkpointed steps, retry semantics. | **Green** — every annotated step journals to Postgres, replay returns cached results. | **Green** — checkpointer persists after every execution. |
| Branching on LLM outputs | **Yellow** — IF/Switch nodes work but smaller LLMs return non-schema-conformant JSON; "contains" is more robust than "equal to," structured-output parser is buggy with Agent node. ([n8n issue #17535](https://github.com/n8n-io/n8n/issues/17535)) | **Green** — typed Python state machines. | **Green** — type-safe Python control flow. | **Green** — typed graph state, explicit transitions. |
| Retry + idempotency | **Red** — no native idempotency. Default retries fire immediately, "burning AI tokens on requests that were never going to complete." Workaround: Redis idempotency table, per-node retry caps, manual dedup. ([flowgenius.in](https://flowgenius.in/n8n-idempotency-retry-failures/), [n8n community](https://community.n8n.io/t/n8n-workflow-fails-to-resume-safely-after-partial-execution-idempotency-checkpointing-issue/293072)) | **Green** — exactly-once, configurable backoff. | **Green** — workflow IDs, `OAOO` semantics. | **Green** — checkpointer is the dedup boundary. |
| Observability into agent decisions | **Yellow** — Executions UI shows step-by-step I/O; token/cost tracking added 2026 but via templates/Sheets, not first-class. No cross-execution causal traces. ([Medium](https://medium.com/@Nexumo_/n8n-observability-you-can-actually-trust-93448ffcb94a)) | **Yellow** — built-in dashboards; pair with Langfuse. | **Yellow** — Conductor self-hosted console + OTel. | **Green** — LangSmith-native traces, replays, time-travel. |
| Prompt + skill versioning | **Red** — git source-control supports push/pull but **no PR review/merge process**, pulls overwrite local changes if not pushed first. Prompts live in Code/Set nodes inside JSON; reviewing diffs is painful. ([n8n docs](https://docs.n8n.io/source-control-environments/understand/git/)) | **Green** — code in git, prompts in code. | **Green** — same. | **Green** — same; LangSmith Hub for prompt-as-asset. |
| Multi-agent coordination | **Red** — "n8n has no native AI agent layer. n8n added basic AI nodes but does not support multi-agent orchestration, agent memory, or autonomous reasoning chains." ([unleashx.ai](https://unleashx.ai/blogs/n8n-alternatives-that-actually-scale-7-tools-teams-are-switching-to-in-2026/)) Sub-workflows + Postgres bus is what we have. | **Green** — first-class. | **Yellow** — durable queues + workflows; less opinionated about agent topology. | **Green** — designed for it. |
| Local dev + testing | **Red** — cron-only workflows can't be externally triggered (we already hit this). Webhook side-door required. ([memory feedback](../../../.claude/projects/-Users-justnau-finlet/memory/feedback_n8n_schedule_trigger_testability.md)) | **Green** — `pytest`. | **Green** — `pytest`. | **Green** — `pytest`. |
| Recovery from LLM stochasticity | **Red** — no native "agent did the wrong thing" path. CTO v2's 4-round correction loop has to be hand-built across nodes + Postgres. | **Yellow** — durable retries, but agent-semantic recovery is your code. | **Yellow** — same. | **Green** — graph state + conditional edges + human-in-loop are the design idiom. |
| Cost ($14/mo Hetzner parity) | **Green** — already paid. | **Green** — Postgres-only mode runs on existing CPX21. ([Hatchet docs](https://docs.hatchet.run/self-hosting/docker-compose)) | **Green** — runs *inside* your app, no new server. ([DBOS pricing](https://www.dbos.dev/dbos-pricing)) | **Yellow** — needs Postgres + Redis on top. CPX21 might need CPX31 ($25/mo) at scale. |
| Sovereignty (self-host on small VPS) | **Green** — runs anywhere. | **Green** — explicit small-deployment story. | **Green** — minimal footprint by design. | **Yellow** — Docker compose viable; Trigger.dev v4 (8GB worker) and Temporal (7+ services) are NOT viable on CPX21. |

---

## 5. Verdict — Systemic vs Bug

For each pain point you're feeling on the CTO agent:

| Pain | Verdict | Evidence |
|---|---|---|
| Long-running agent runs lose state mid-flow | **Systemic.** No checkpoint/resume of full agent state mid-flow exists in n8n. ([ZenML](https://www.zenml.io/blog/langgraph-vs-n8n)) Patches don't fix this. |
| LLM-output branching is brittle | **Systemic.** IF/Switch + Structured Output Parser is buggy for AI Agent node; the n8n-blessed workaround is "use 'contains' not 'equal to' and a custom validation loop." ([n8n template #4316](https://n8n.io/workflows/4316-reliable-ai-agent-output-without-structured-output-parser-w-openai-and-switch/)) That's a design smell. |
| Token-burning retries | **Systemic by default, patchable in practice.** n8n's defaults retry-immediately. You can tame this with per-node retry caps + Redis idempotency keys, but every workflow author has to remember. ([flowgenius.in](https://flowgenius.in/n8n-idempotency-retry-failures/)) Hatchet/DBOS make this default-safe. |
| Cron-only workflows un-testable | **Bug, kind of.** Workaround already booked (webhook side-door). Lives forever. |
| Prompt versioning | **Systemic.** No PR review, prompts buried in JSON. Real prompt engineering wants git diffs. |
| Multi-agent coordination | **Systemic for native n8n; we already routed around it via Postgres `ops.*` and sub-workflows.** That's *exactly* what a durable execution engine would give us natively. |
| Observability into agent decisions | **Half-systemic.** UI traces work for "what happened in this execution"; cross-execution causal chains, token-cost-by-decision, prompt-version-attribution all need bolt-ons (Langfuse). |

**Bottom line:** ~6 of 10 problems are systemic. The remaining 3 are either already booked or trivially patchable. The systemic ones are not flaws you fix in n8n — they're design choices that say n8n is a workflow engine for humans, not an agent runtime. The user has been asked to build a NASA mission-control on a Zapier UI. It works, but it's the wrong tool for the job at the layer where the CTO actually does its thinking.

---

## 6. Recommendation — Three Options Ranked

### Option B (RECOMMENDED): Hybrid — n8n as glue, Hatchet OR DBOS as agent runtime

Keep n8n for what it's good at — webhooks, Discord fanout, cron, the bug-hunt/bug-fix HTTP-stitching layer. Move the **CTO supervisor + skill-graph stages + correction-loop state machine** into a code-first durable runtime running on the same CPX21.

- **Hatchet (Postgres-only mode)** is the safest bet. Runs against your existing `ops` Postgres, has explicit AI-agent positioning, durable queues + retries are default-safe.
- **DBOS Transact** is the lightest-weight option. Annotate Python functions, no new server, durable execution lives inside your app process. Best if the CTO becomes a single Python service called from n8n via HTTP.

**Effort:** ~1-2 weeks. Port `cto-supervisor` + 4 skill-graph workflows to Python. n8n keeps owning Discord posts, GitHub PR triggers, cron schedules, the HMAC webhook surface. The code-first runtime owns the parts where stochasticity, retries, branching, and durable state matter.

**Risk:** Workflow-fixer governance assumes prompts live in n8n nodes (Decision #7, CTO_MANDATE). Moving prompts to git changes the approval surface — but arguably *improves* it (PR review > Discord ack on a JSON node edit).

### Option A: Stay + patches

Add Redis-based idempotency keys, per-node retry caps, structured-output retry loops, cookie-auth smoke-test harness. Adopt Langfuse for tracing.

**Effort:** ~3-5 days of patching. **Why not first choice:** patches don't fix the systemic gaps (no mid-flow resume, no native multi-agent, prompt-as-JSON-blob). You'll be back here in 6 weeks asking the same question with more sunk cost.

### Option C: Full migration

Rip n8n, go all-in on LangGraph + Claude Agent SDK, or Temporal (NOT viable on CPX21).

**Effort:** 4-6 weeks + opportunity cost. Loses n8n's integration library (Discord, GitHub, scheduling). Currently overkill — n8n IS earning its keep at the perimeter.

**Why not:** the user's situation is "rent is real, time-to-revenue is the metric." Full rewrites for architectural purity = wrong call. Hybrid keeps shipping; full migration delays the actual revenue path (Finlet launch).

---

## 7. Riskiest Unknown

**Whether the Max-OAuth gray-area survives a code-first runtime.** The current `claude-runner` shim is what makes the $0-marginal-cost model work. Hatchet/DBOS will call `claude -p` the same way — as long as we keep the subprocess shim. But Anthropic's April 2026 launch of **Managed Agents** ($0.08/session-hour + tokens) signals they're productizing exactly this layer; if they tighten Max ToS to forbid headless `claude -p` on a VPS, the entire stack regardless of orchestration choice gets hit. Migrating orchestrators doesn't help if the LLM runtime itself becomes API-billing-only.

---

## 8. Citations

### Durable execution
- [Inngest vs Temporal](https://www.inngest.com/compare-to-temporal) — Inngest 2026
- [Durable Execution: Temporal, Restate, DBOS](https://devstarsj.github.io/2026/04/03/durable-execution-temporal-restate-dbos-distributed-workflows-2026/) — Apr 2026
- [Render: Durable Workflow Platforms for AI Agents](https://render.com/articles/durable-workflow-platforms-ai-agents-llm-workloads) — 2026
- [Zylos: Durable Execution Patterns for AI Agents](https://zylos.ai/research/2026-02-17-durable-execution-ai-agents) — Feb 2026
- [Pkg Pulse: Hatchet vs Trigger.dev vs Inngest 2026](https://www.pkgpulse.com/blog/hatchet-vs-trigger-dev-v3-vs-inngest-durable-workflows-2026)
- [Temporal Pricing](https://temporal.io/pricing) and [Estimating Cost](https://temporal.io/blog/estimating-the-cost-of-temporal-cloud)

### Agent orchestrators
- [LangGraph vs n8n — ZenML](https://www.zenml.io/blog/langgraph-vs-n8n)
- [Speakeasy: Agent Framework Comparison](https://www.speakeasy.com/blog/ai-agent-framework-comparison) — 2026
- [Anthropic: Managed Agents](https://www.anthropic.com/engineering/managed-agents) — Apr 8 2026
- [InfoQ: Anthropic Managed Agents](https://www.infoq.com/news/2026/04/anthropic-managed-agents/) — Apr 2026
- [QubitTool: Claude Agent SDK vs Strands vs LangGraph 2026](https://qubittool.com/blog/ai-agent-framework-comparison-2026)

### n8n limitations
- [n8n issue #17535: Structured Output Parser receives string](https://github.com/n8n-io/n8n/issues/17535)
- [flowgenius.in: n8n idempotency failures](https://flowgenius.in/n8n-idempotency-retry-failures/)
- [n8n community: Idempotency & Checkpointing Issue](https://community.n8n.io/t/n8n-workflow-fails-to-resume-safely-after-partial-execution-idempotency-checkpointing-issue/293072)
- [n8n community: Long workflow execution time with AI agent](https://community.n8n.io/t/long-workflow-execution-time-with-ai-agent/78734)
- [n8n docs: Git source control](https://docs.n8n.io/source-control-environments/understand/git/)
- [unleashx.ai: n8n alternatives 2026](https://unleashx.ai/blogs/n8n-alternatives-that-actually-scale-7-tools-teams-are-switching-to-in-2026/)
- [Hatchworks: n8n cost controls](https://hatchworks.com/blog/ai-agents/n8n-cost-controls/)

### Self-host fit
- [Hatchet docs: Docker Compose deployment](https://docs.hatchet.run/self-hosting/docker-compose)
- [DBOS Transact (GitHub)](https://github.com/dbos-inc/dbos-transact-py) and [pricing](https://www.dbos.dev/dbos-pricing)
- [Inngest self-host](https://www.inngest.com/docs/self-hosting)
- [Trigger.dev v4 self-host](https://trigger.dev/blog/self-hosting-trigger-dev-v4-docker)
- [Windmill vs n8n](https://hostadvice.com/blog/ai/automation/n8n-vs-windmill/)

### Observability
- [Braintrust: LangSmith alternatives 2026](https://www.braintrust.dev/articles/langsmith-alternatives-2026)
- [Medium: n8n Observability You Can Actually Trust](https://medium.com/@Nexumo_/n8n-observability-you-can-actually-trust-93448ffcb94a) — Jan 2026
- [n8n template: LLM usage tracker](https://n8n.io/workflows/7398-llm-usage-tracker-and-cost-monitor-with-node-level-analytics-v2/)

### Internal references
- [`docs/AGENT_OPS_STACK.md`](../AGENT_OPS_STACK.md)
- [`docs/ops/CTO_MANDATE.md`](../ops/CTO_MANDATE.md)
- [`docs/ops/skill-graph-DESIGN.md`](../ops/skill-graph-DESIGN.md)
