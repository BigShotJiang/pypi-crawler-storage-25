# Context Engineering as Cognitive Architecture

> Captured 2026-03-26 after the hygiene audit retro.

## Frame 1 (Active Focus): Brain-First Context Engineering

The main-agent-as-coordinator pattern mirrors prefrontal cortex function — hold the plan, route between specialists, maintain intent across time. Already implemented: dream skill (memory consolidation), main-agent delegation model, specialist offloading. Next frontiers to mine from neuroscience: attention gating, salience filtering, hippocampal replay. The goal is better cognitive architecture for the agent system, not more features.

## Frame 2 (Parked — Emerges from #1): AI as Cognitive Degradation Testbed

AI context management failures map onto human cognitive degradation with uncomfortable precision:

| AI failure | Cognitive parallel |
|---|---|
| Context window overflow | Cognitive overload / attention collapse |
| Stale memory applied as current truth | Confabulation |
| Hallucination from pattern-matching without grounding | Delusional reasoning in Lewy body dementia |
| Loss of plan coherence over long conversations | Executive dysfunction |
| Training data bias → systematic blind spots | Developmental environment → cognitive schema |
| Compaction losing critical context | Memory consolidation failure during sleep deprivation |

Key insight: sleep-deprived humans produce confidently wrong output that feels internally coherent — same as a model after critical context is compacted away. The system doesn't know what it lost.

## Why #1 First

Building a better cognitive simulation IS the prerequisite for #2. You can't study degradation patterns without first having a well-understood system to degrade.

## Design Heuristic

When designing new skills or improving existing ones, ask "how does the brain solve this?" before "how do other AI systems solve this?" The neuroscience analogy has been consistently more productive than the software engineering analogy for context management problems.
