---
tags: [finlet, project, startup, fintech, trading, AI]
keywords: Finlet, evaluation harness, AI trading agents, backtesting alternative, solo founder
aliases: [finlet project, the startup, trading harness]
priority: high
---

# Finlet — Project Overview

## What It Is
An evaluation harness for AI trading agents. Not a backtester. Tests whether AI agents make sound reasoning decisions with information available at a given point in time. The core innovation is a simulation clock controlling what data agents can see, plus a date ceiling enforcer stripping future data from every response.

## Key Positioning
- Daily-timeframe, US equities + crypto, long-only evaluation
- Tests reasoning quality, not execution speed
- Date Ceiling Enforcer (runtime defense-in-depth)
- SHA-256 reasoning trace (tamper-evident audit)
- Cross-scenario leaderboard with composite scoring

## Tech Stack
- Python 3.12+ (fully async — httpx, aiosqlite, asyncio)
- FastAPI (REST API) + hosted MCP (`/mcp`) with the default `finlet mcp serve` stdio bridge; `--self-host` runs local FastMCP
- SQLModel + aiosqlite (per-session SQLite, WAL mode)
- Vanilla HTML/JS/CSS dashboard with TradingView Lightweight Charts
- Typer CLI
- Structlog (JSON logging)
- Pydantic models everywhere, mypy enforced

## Project Structure
- `finlet/core/` — Engine (clock, enforcer, portfolio, orders, session, trace)
- `finlet/plugins/` — Data plugins (price, news, fundamentals, filings, economic, sentiment)
- `finlet/api/` — REST API (routes, services, auth, billing, rate limiting)
- `finlet/mcp/` — Hosted MCP integration, stdio proxy, and self-host FastMCP server
- `finlet/db/` — Persistence (per-session + global auth + leaderboard DBs)
- `finlet/leaderboard/` — Benchmark runner & scoring
- `finlet/marketplace/` — Agent marketplace
- `dashboard/` — Web UI
- `docs/` — ARCHITECTURE.md (authoritative, 112K), V1_SCOPE.md, LESSONS.md

## Who
Solo founder, 19, university (math + physics). Revenue-first, automation-critical.
