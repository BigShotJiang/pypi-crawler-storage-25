## Broken (will be fixed this iteration)
- fred plugin shows green/healthy indicator dot but status text says "fred plugin not initialized" — health dot color contradicts the message text on the same row. [evidence: "the 'fred' (economic) plugin has a green status dot (same as fully-healthy plugins like 'price' and 'fundamentals_s3') yet displays the message 'fred plugin not initialized.' All other uninitialised plugins (finnhub, edgar) show a red/orange dot. The visual health signal directly contradicts the status text."] [scope hint: dashboard/app.js, dashboard/settings.js, finlet/api/routes_health.py, finlet/plugins/fred_plugin.py]

## Logged (not actioned)
- Finlet Benchmark MCP tool not present in tool list. [classification: ambiguous]
- news_s3 / sentiment plugins degraded on a brand-new account with no clear in-UI guidance beyond the Ingest button. [classification: annoying]
- Trade Ticket dialog does not auto-close after a successful FILLED order. [classification: annoying]
- Session creation takes ~15 seconds with no progress indicator. [classification: annoying]
- "Set up a fundamentals strategy" has no discoverable path; "strategy" concept does not exist as a UI surface. [classification: nice-to-have]
- "Run first analysis" checklist row checks off after a manual market-buy — copy mislabeling. [classification: annoying]
- "Set up profile" checklist item does not auto-check after wizard persona step (requires Display Name + Bio save). [classification: working-as-designed]
- Two duplicate "API Keys" entries in Settings sidebar navigation. [classification: annoying]
- Reasoning column in Order Log always shows "—" for web-UI trades; no reasoning input field in Trade Ticket. [classification: annoying]
- No direct "Get API Key" links for finnhub, fred, or edgar plugins. [classification: nice-to-have]
- No prompt to advance simulation time after a fill to observe unrealized P&L. [classification: nice-to-have]
- No fundamentals-driven strategy template or wizard. [classification: nice-to-have]
- econ plugin 357ms response time vs <1ms for S3-backed plugins. [classification: annoying]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260506T061637Z6594 — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made.
6. `docs/bug-hunt/20260506T061637Z6594/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log,
   deploy_status.txt, retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260506T061637Z6594","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline.
   Team D MUST stage the file. If a refactor verdict pruned entries this
   iteration, Team D MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`.

Team D's commit message must reference iteration 20260506T061637Z6594 and name which docs were
touched (e.g., "docs: bug-hunt 20260506T061637Z6594 — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
