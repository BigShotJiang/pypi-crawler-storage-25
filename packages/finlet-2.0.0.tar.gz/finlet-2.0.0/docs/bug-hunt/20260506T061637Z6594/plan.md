# Bug Hunt 20260506T061637Z6594 — Execution Plan

> Generated from `docs/bug-hunt/20260506T061637Z6594/triage.md` on 2026-05-06.
> Baseline HEAD: `60bd34fc5723c4a1383cf5815a6a5b835d69f326` (origin/main).

## Constraints

- Single real-broken finding this iteration → minimal team count (Team A fix + Team D docs).
- Fix must be surgical: this is a `dashboard-state-sync` bug already covered by 24 prior ledger entries; widening scope here would invite a regression in a category that has multiple shipped refactors.
- Server-side `PluginHealthStatus` enum is canonical (`finlet/plugins/base.py:135-140`) — the fix lives in the dashboard predicates, NOT in the server enum or in `routes_health.py`. Do not touch server code.
- New unit test must pin the exact predicate behavior so future drift is caught at `node --test` time, not at user-walkthrough time.

## File Conflict Table

### Shared File Conflicts
| File | Touched by Teams |
|------|-----------------|
| _none_ — Team A and Team D touch disjoint paths | — |

Team A → `dashboard/app.js`, `dashboard/settings.js`, `tests/dashboard/plugin-health-dot.spec.js` (new).
Team D → `docs/REMAINING_TASKS.md`, `docs/LESSONS.md`, `docs/bug-hunt/20260506T061637Z6594/*` (artifacts), `docs/bug-hunt/ledger.jsonl`, `docs/ARCHITECTURE.md` (only if Team A's fix shifts surface, which it does NOT — predicate semantics only).

## Dependency Graph

- **Team A (fix)** — independent. Can start immediately.
- **Team D (docs)** — blocked by Team A. Needs Team A's merge SHA to write the ledger entry's `commit` field.

## Critical Path

`Team A → Team D`

---

## Teams

### Team A: dashboard plugin-health predicate — handle `unhealthy` server status

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/app.js:2427-2494` — `renderPlugins()`, the dashboard sidebar Plugin Health panel render path.
- `dashboard/settings.js:1040-1080` — Settings → Plugins panel render path that draws `plugin-health-dot--{class}` rows.
- `dashboard/settings.css:711-721` — CSS color buckets for the settings-page dot (`--healthy`, `--degraded`, `--error`, `--unknown`).
- `dashboard/styles.css:1213-1228` — CSS color buckets for the dashboard-sidebar dot (`--ok`, `--degraded`, `--error`, `--rate-limited`, `--unknown`).
- `finlet/plugins/base.py:135-140` — canonical `PluginHealthStatus` enum (server source of truth).
- `tests/dashboard/event-bus.spec.js:1-50` — pattern for a `node --test` JS unit test using `vm.createContext` to load a dashboard JS file.

**Recon evidence (verified by recon agent + live API + live DOM at HEAD `60bd34f`):**

Server enum (canonical status strings):

```python finlet/plugins/base.py:135-140
class PluginHealthStatus(str, Enum):
    """Plugin health status."""
    HEALTHY = 'healthy'
    DEGRADED = 'degraded'
    UNHEALTHY = 'unhealthy'
```

Dashboard sidebar predicate (BUG #1):

```javascript dashboard/app.js:2458-2465
        const status = (p.status || 'unknown').toLowerCase();
        const dotClass = (status === 'healthy' || status === 'ok')
            ? 'ok'
            : (status === 'degraded' || status === 'rate-limited' || status === 'rate_limited')
                ? 'degraded'
                : status === 'error'
                    ? 'error'
                    : 'unknown';
```

Settings page predicate (BUG #2 — same drift):

```javascript dashboard/settings.js:1057-1060
        const status = (p.status || 'unknown').toLowerCase();
        const healthClass = (status === 'healthy' || status === 'ok') ? 'healthy'
            : (status === 'degraded' || status === 'rate_limited' || status === 'rate-limited') ? 'degraded'
            : status === 'error' ? 'error' : 'unknown';
```

Both predicates handle `'error'` but NOT `'unhealthy'`. The server emits `'unhealthy'` (per the enum above) for any plugin where `_initialized=False` (see `finlet/plugins/base.py:246-256` — base-class `health_check` returns `PluginHealthStatus.UNHEALTHY` for uninitialized plugins). So `fred`, `finnhub`, `edgar` (all uninitialized) reach the predicates with `status='unhealthy'`, miss every arm, and fall through to `'unknown'` (gray). The user sees "Status: Unknown" with a gray dot for plugins the server has explicitly classified as `unhealthy`.

Live API confirmation (taken at 2026-05-06T06:32:00Z against finlet.dev with the bug-hunt test user's API key):

```json
[
  {"name": "fred",    "status": "unhealthy", "message": "fred plugin not initialized."},
  {"name": "finnhub", "status": "unhealthy", "message": "finnhub plugin not initialized."},
  {"name": "edgar",   "status": "unhealthy", "message": "edgar plugin not initialized."}
]
```

Live DOM confirmation (Playwright `evaluate` against finlet.dev `/index.html`, same timestamp):

```
fred card → classes: ['plugin-status-dot', 'plugin-status-dot--unknown']
            bgColor: rgb(145, 152, 161)  // gray
expected   → classes: ['plugin-status-dot', 'plugin-status-dot--error']
            bgColor: rgb(248, 81, 73)    // red
```

The blind agent reported the dot as "green"; the actual rendered color is gray (`rgb(145, 152, 161)`). The dashboard-state-sync bug is real — it's just that the symptom is "uninitialized plugins look indistinguishable from unknown-state plugins" rather than "uninitialized plugins look healthy." Same severity (user can't read the system's actual health), different surface than the blind report.

Comment-vs-code drift evidence (`dashboard/app.js:2451-2457`):

```javascript dashboard/app.js:2451-2457
        // Mirror dashboard/settings.js:1043 — both surfaces consume the same
        // canonical /v1/plugins/health response, so a missing-status default
        // must mean the same thing on both. We default to 'unknown' (gray),
        // never 'healthy' (green), so missing data fails closed instead of
        // lying to the user. Color is derived ONLY from the canonical
        // `status` string — never from cache_count, files_found, or a
        // message-substring heuristic.
```

The comment claims the predicate mirrors settings.js. The actual code on both sides has the same `'unhealthy'`-arm gap, so the *drift* this fix closes is from the SERVER ENUM to BOTH dashboard predicates — neither dashboard predicate currently knows the server's vocabulary.

**Files touched:**
- Modified: `dashboard/app.js` — extend the predicate at lines 2463-2465 to map `status === 'unhealthy'` to the `'error'` bucket alongside `status === 'error'`. No other lines change.
- Modified: `dashboard/settings.js` — extend the predicate at line 1060 the same way: `(status === 'error' || status === 'unhealthy') ? 'error' : 'unknown'`.
- New: `tests/dashboard/plugin-health-dot.spec.js` — a `node --test` unit test that loads each dashboard JS file in a VM context and asserts the predicate's mapping for every `PluginHealthStatus` enum value plus `'rate-limited'` / `'rate_limited'` / `'ok'` / missing-status. The test must FAIL on HEAD (proves it pins the bug) and PASS after the predicate fix.

**Deliverable:** Both dashboard predicates map server-emitted `'unhealthy'` to the `'error'` (red) CSS class, and a new `node --test` spec pins the full mapping table so any future predicate-drift regression is caught at unit-test time.

**Validation:**
- [ ] `node --test tests/dashboard/plugin-health-dot.spec.js` — all assertions pass on the fixed code; revert the predicate fix locally and confirm the new test FAILS (proving it pins the bug, not the patch).
- [ ] `node --test tests/dashboard/` — full dashboard suite still green.
- [ ] `bash scripts/lint-trusted-types.sh` — no new bare `.innerHTML =` violations introduced (the predicate change is inside the existing `trustedHTML(...)` wrapper, but verify nothing slipped).
- [ ] `bash scripts/lint-event-bus.sh` — no new direct-bus violations (no event-bus surface touched, but run for parity).
- [ ] `uv run pytest tests/api/test_plugin_health.py -x -q` — server-side health route tests still pass (no server change but make sure the server contract is intact).
- [ ] Manual smoke (optional, post-merge): visit `https://finlet.dev/index.html` and `/settings.html#plugins` after deploy, confirm `fred`, `finnhub`, `edgar` rows now show red dots with a "Status: Error" sr-only label.

**Agent instructions:**
- You MUST `git add` + `git commit` the predicate fix AND the new test in a single commit before finishing.
- The new spec must mirror the structure of `tests/dashboard/event-bus.spec.js`: `vm.createContext` sandbox, load the dashboard JS file as text, exercise the predicate as a pure function. Do NOT spin up a browser. Do NOT depend on `fetch` / a live `/plugins/health` route.
- The spec MUST cover at minimum: every `PluginHealthStatus` value (`healthy`, `degraded`, `unhealthy`), the alias `'ok'`, `'rate-limited'`, `'rate_limited'`, missing/null/undefined, and an unknown string `'foobar'`. Use a table-driven test (`.forEach` over a `[input, expected_dotClass, expected_statusLabel]` array) so adding a new status value in the future is one row.
- The spec MUST also assert the `statusLabel` fallback in `dashboard/app.js:2466-2472` — `dotClass='error'` ⇒ `statusLabel='Error'` (sr-only label visible to screen readers must read "Error" not "Unknown" for unhealthy plugins).
- Extracting the predicate to a shared module is OUT OF SCOPE for this iteration — do NOT refactor. The two predicates remain duplicated; the unit test pins both copies. Adding a shared module adds 2-3 files of churn and a refactor doc; we have neither budget nor a `status: ready` queue doc for it. If you observe more drift cases later, file a refactor doc under `docs/bug-hunt/refactor-queue/` and let the next iteration's gate route to it.
- Do NOT touch `finlet/plugins/base.py`, `finlet/api/routes_health.py`, or any plugin's `_probe()` — the server contract is correct.
- Follow existing patterns in `tests/dashboard/event-bus.spec.js` for the spec scaffolding (require `node:test`, `node:assert/strict`, `node:fs`, `node:path`, `node:vm`).

---

### Team D: Required docs + ledger update

**Blocked by:** Team A merge — needs the merge SHA on `main` to write the ledger entry's `commit` field.

**Read these files first:**
- `docs/bug-hunt/20260506T061637Z6594/triage.md:30-65` — the Required Docs Updates block this team owns.
- `docs/bug-hunt/ledger.jsonl` (last 10 lines) — schema and category-tag conventions for new entries.
- `docs/REMAINING_TASKS.md` (search for the most recent "Bug Hunt YYYYMMDDTHHMMSSZ — Closed" subsection) — pattern to mirror.
- `docs/LESSONS.md` (search for the most recent dashboard / dashboard-state-sync entry) — voice and structure.
- `docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md`, `…/trade-ticket-state-sync-v3.md` — both shipped refactors with `dashboard-state-sync` category — Team D must verify whether either refactor "should have caught" this drift and, if so, append a verdict-relevant note to the queue doc (NOT change the verdict — that's Phase 6 orchestrator territory).

**Recon evidence:** N/A — Team D writes docs, not code. The required-docs block is the spec.

**Files touched:**
- New section in `docs/REMAINING_TASKS.md` titled `## Bug Hunt 20260506T061637Z6594 — Closed` listing the 1 broken finding closed.
- New section in `docs/LESSONS.md` (at least one lesson — see below).
- Append to `docs/bug-hunt/ledger.jsonl` exactly 1 JSONL line:
  ```json
  {"iteration_ts":"20260506T061637Z6594","finding_id":"plugin-health-dot-unhealthy-falls-to-unknown","category":"dashboard-state-sync","summary":"dashboard predicates in app.js (sidebar) and settings.js (settings page) handle status='error' but not 'unhealthy'; uninitialized plugins (fred/finnhub/edgar) render as gray Unknown instead of red Error","scope_files":["dashboard/app.js","dashboard/settings.js","tests/dashboard/plugin-health-dot.spec.js"],"team":"A","commit":"<TEAM_A_MERGE_SHA>"}
  ```
- Stage + commit every artifact under `docs/bug-hunt/20260506T061637Z6594/` (blind_report.json, blind_report_raw.json, blind_findings.json, cleanup.log, isolation_warning.txt, triage.md, triage.json, plan.md, plus deploy_status.txt and retest_results.json after Phase 5.5 produces them).
- `docs/ARCHITECTURE.md` — leave UNTOUCHED. The fix is a predicate alignment, no surface change. Note this in the commit message ("ARCHITECTURE.md: unchanged — predicate-only fix, server contract intact").
- `docs/KNOWN_FAILURES.md` — pre-flight scan for any existing entry referencing the dashboard plugin-health predicate. If none, note "no pre-existing entries removed".
- `docs/decisions/` — write a 1-page record IF the team decides to leave the predicate duplicated rather than extract a shared module; otherwise skip. Title suggestion: `docs/decisions/dashboard-plugin-health-predicate-duplication.md`. The decision body must explicitly cite the refactor-gate trade-off (one new file + a shared-module migration is more churn than the recurrence cost in a 1-bug iteration).
- `docs/bug-hunt/pending_recurrences.jsonl` — Phase 5.5 will append if the retest fails; Team D stages whatever the orchestrator wrote. If Phase 5.5 produced no new lines, Team D's commit notes "no patch-ineffective signals this iteration".

**Lessons MUST cover at minimum:**
1. **Class-of-mistake lesson:** When a server emits a structured enum, every client predicate that consumes that enum MUST be unit-pinned to the FULL enum (not just the subset the predicate's author remembered). The `'error'`-vs-`'unhealthy'` drift here is a textbook contract-vocabulary skew — the comment at `dashboard/app.js:2451-2457` even claimed the predicate "mirrors settings.js" while neither side knew the canonical server vocabulary. Lesson rule: any time a JS predicate enumerates server-emitted strings, add a unit test that iterates the server's enum source-of-truth (or its full known value set) and asserts the mapping for every value, including the values the predicate intends to fall through.
2. **Recon hygiene lesson:** The plan-features recon agent produced a fabricated `HealthIndicator` class-and-method quote for `dashboard/settings.js:1058-1069` whose contents disagreed with HEAD. The plan would have been authored against a non-existent surface (PF-16 / PF-18 failure mode). The orchestrator caught it by going to live DOM + grep instead of trusting the recon paraphrase. Lesson rule: when a recon paraphrase says "this predicate handles X" but a live spot-check or `grep -n` shows the file's actual content differs, REJECT the recon and re-quote against HEAD before drafting team specs. The verbatim grep is cheap; the team-stall is expensive.
3. **Triage hygiene lesson (optional):** The blind agent's "green status dot" claim was visually wrong (the dot is gray, `rgb(145, 152, 161)`), but the bug it pointed at was real. When a triage report's surface description disagrees with the live DOM but the underlying invariant violation is real, the orchestrator must NOT discard the finding — they must re-frame it against the live surface and let the fix scope follow the actual broken predicate, not the symptom narrative.

**Deliverable:** Single commit titled `docs: bug-hunt 20260506T061637Z6594 — record fixes for plugin-health predicate drift; LESSONS +2 (or +3); ARCHITECTURE unchanged this iteration; ledger +1` containing all the docs updates above.

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` increases by exactly 1 from the pre-Team-D count.
- [ ] `git status docs/bug-hunt/20260506T061637Z6594/` reports a clean tree (every artifact tracked).
- [ ] `jq -c . docs/bug-hunt/ledger.jsonl | tail -1` parses cleanly and contains the keys `iteration_ts`, `finding_id`, `category`, `summary`, `scope_files`, `team`, `commit`.
- [ ] `git log -1 --format=%s` on Team D's commit references iteration `20260506T061637Z6594`.
- [ ] `grep -c "Bug Hunt 20260506T061637Z6594 — Closed" docs/REMAINING_TASKS.md` returns 1.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- The ledger line MUST use the merge SHA of Team A on `origin/main` — read it via `git log origin/main --grep "<Team A subject>" --format=%H -n 1` AFTER Team A merges, not from your own worktree's HEAD.
- When tagging refactor-queue verdicts on docs that match this iteration's category, do NOT change the verdict frontmatter — that is Phase 6 orchestrator territory. You may, however, append a one-line "iteration note" inside the doc body referencing this iteration's ledger entry.
- Do NOT modify `dashboard/`, `finlet/`, or `tests/` — Team D is docs-only.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Predicate fix breaks existing e2e test (`tests/e2e/journey-04-dashboard.spec.ts:745-769`) that asserts plugin-cards content | Low | Medium | Read the e2e test before editing; the existing assertions check for `.plugin-card` and `.plugin-latency` presence, not dot-class color, so the fix is additive. Validation includes `node --test tests/dashboard/` which won't catch e2e drift, but the existing journey passes today and our diff doesn't change render structure. |
| Adding a unit test that fails on HEAD blocks CI before the predicate fix lands | Low | Low | Write test + predicate fix in the SAME commit. Never push the test alone. (Standard practice; flagged here only because a worktree agent might commit incrementally.) |
| Hidden third predicate in `dashboard/marketplace.js` or `dashboard/leaderboard.js` also has the bug | Low | Medium | Recon already grep'd the codebase: `marketplace.js:201-254` uses `.plugin-card` class for marketplace strategies (not plugins), no health-status predicate. No other surfaces matched `plugin-status-dot--` or `plugin-health-dot--` other than the two we're fixing. If a third surface is discovered during fix work, agent stops and reports it; we expand scope ONLY if the unit test naturally exercises it. |
| Server starts emitting a new status string (e.g. `'rate-limited'` upgraded to its own enum value) and the unit test misses it | Medium | Low | Test is table-driven over the *current* `PluginHealthStatus` enum values plus aliases. When the server adds a new enum value, the new value's row must be added to the test table. Document this expectation in the test file's header comment. |
| Recon fabricated `HealthIndicator` class — could there be other invented symbols in the recon report this team uses? | Low | High | The recon evidence subsection in this plan was REWRITTEN by the orchestrator using verbatim file reads + live API + live DOM after the recon paraphrase failed verification. Team A reads the actual file lines, not the recon paraphrase. |
| Team D writes an incorrect category tag and breaks recurrence detection | Low | Medium | The plan specifies `category: "dashboard-state-sync"` verbatim — Team D copies it. Pre-merge `jq` validation ensures the line parses. |

## Session Plan

### Session 1
**Sequential merge order:** Team A → Team D
- Team A merges first (fix + unit test in one commit). Targeted gate: `node --test tests/dashboard/plugin-health-dot.spec.js` + `node --test tests/dashboard/` + `bash scripts/lint-trusted-types.sh` + `bash scripts/lint-event-bus.sh` on `main` after merge.
- Team D merges after Team A's commit lands on `origin/main` (so it can read the merge SHA). Targeted gate: `wc -l docs/bug-hunt/ledger.jsonl` increased by exactly 1; `jq -c . docs/bug-hunt/ledger.jsonl | tail -1` parses; git status is clean.
**Session checkpoint:** `uv run pytest -x -q` (full backend suite) + `node --test tests/dashboard/` (full dashboard suite). Both green = session complete.

No second session needed — single broken finding, two teams, linear merge.

---

## Quality Checklist (orchestrator pre-handoff scan)

- [x] Every team has a "Read these files first" list.
- [x] Every team has "git add + git commit" in agent instructions.
- [x] Every team has specific validation commands.
- [x] File conflict table accounts for all shared files (none — table empty by design).
- [x] No team touches >8 files (Team A: 3 files; Team D: ~6 docs files, all of one team's work).
- [x] Dependencies match file conflict table (only logical dep: D blocked by A's merge SHA).
- [x] Critical path is the longest chain (`A → D`).
- [x] Session grouping respects all dependency constraints.
- [x] Every "current state" claim in a team spec is backed by a quoted-excerpt fenced block (server enum, both buggy predicates, comment-drift, live API JSON, live DOM observation). PF-18: PASS.
