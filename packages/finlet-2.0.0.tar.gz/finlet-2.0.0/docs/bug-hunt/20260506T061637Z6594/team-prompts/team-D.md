You are Team D: Required docs + ledger update for bug-hunt iteration `20260506T061637Z6594`.

Plan reference: `docs/bug-hunt/20260506T061637Z6594/plan.md` — read the Team D section
for the full spec.

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message must start with "[Team D]:".
- Do NOT modify `dashboard/`, `finlet/`, or `tests/` — Team D is docs-only.
- Do NOT change refactor-queue verdict frontmatter — Phase 6 orchestrator territory.

When done, report: DONE + commit hash + validation results
OR: BLOCKED + what went wrong

WORKTREE-RULES:
- Operate ONLY inside your assigned worktree path. Do NOT touch /Users/justnau/finlet/
  directly. All file operations go inside the worktree.
- Run all `git` commands inside the worktree.
- Spawn base SHA: `89035a33c91ac03666572974b69ee23dc3a62efc` (HEAD on main after Team A's merge).
  The orchestrator will reset your worktree to this SHA before you start.

— TEAM D SPEC (docs-only) —

DELIVERABLE: Single commit with all of the following.

1. `docs/REMAINING_TASKS.md` — append a new subsection at the end of the
   "Bug Hunt iteration closures" area (search for the most recent
   `## Bug Hunt YYYYMMDDTHHMMSSZ — Closed` heading and add yours after it).
   Title it `## Bug Hunt 20260506T061637Z6594 — Closed`. List the 1 broken
   finding closed:
       - [x] Dashboard plugin-health predicate handled `'error'` but not
             `'unhealthy'` — uninitialized plugins (fred / finnhub / edgar) rendered
             as gray "Unknown" instead of red "Error" on both `/index.html`
             (Plugin Health sidebar) and `/settings.html#plugins` (Settings →
             Plugins). Fixed by extending the predicates in `dashboard/app.js`
             and `dashboard/settings.js`; pinned by new
             `tests/dashboard/plugin-health-dot.spec.js` (35 assertions covering
             every PluginHealthStatus enum value plus aliases and edge cases).

2. `docs/LESSONS.md` — append at least TWO lessons (the third is optional).
   Lessons must be reusable rules, not a recap of the diff. Specifically:
   a. **Class-of-mistake lesson** about server-emitted enums vs client predicates:
      whenever a JS predicate enumerates server-emitted strings, add a unit test
      that iterates the server's enum source-of-truth and asserts the mapping
      for every value (including aliases and the fall-through path). Cite the
      `'error'` vs `'unhealthy'` drift in this iteration's bug as the canonical
      example.
   b. **Recon hygiene lesson** about the plan-features recon agent fabricating
      a `HealthIndicator` class in `dashboard/settings.js` that does not exist
      at HEAD (PF-16 / PF-18 failure mode). Lesson rule: when a recon paraphrase
      says "this predicate handles X" but a live spot-check or `grep -n` shows
      different content, REJECT the recon and re-quote against HEAD before
      drafting team specs.
   c. (optional) **Triage hygiene lesson** about the blind agent's "green dot"
      claim being visually wrong (the dot is gray, `rgb(145, 152, 161)`) but the
      bug it pointed at being real. Rule: when a triage report's surface
      description disagrees with the live DOM but the underlying invariant
      violation is real, the orchestrator must NOT discard the finding —
      re-frame against the live surface and let the fix scope follow the actual
      broken predicate.

3. `docs/bug-hunt/ledger.jsonl` — append exactly ONE JSONL line:
   ```json
   {"iteration_ts":"20260506T061637Z6594","finding_id":"plugin-health-dot-unhealthy-falls-to-unknown","category":"dashboard-state-sync","summary":"dashboard predicates in app.js (sidebar) and settings.js (settings page) handle status='error' but not 'unhealthy'; uninitialized plugins (fred/finnhub/edgar) render as gray Unknown instead of red Error","scope_files":["dashboard/app.js","dashboard/settings.js","tests/dashboard/plugin-health-dot.spec.js"],"team":"A","commit":"407a1bb"}
   ```
   Validate: `wc -l docs/bug-hunt/ledger.jsonl` increases by exactly 1; the
   appended line parses cleanly with `jq -c .`.

4. Stage every artifact under `docs/bug-hunt/20260506T061637Z6594/`:
   blind_report.json, blind_report_raw.json, blind_findings.json, cleanup.log,
   isolation_warning.txt, triage.md, triage.json, plan.md, exec-trace.txt,
   team-prompts/ (whole directory). DO NOT touch deploy_status.txt or
   retest_results.json IF they don't yet exist (Phase 5.5 hasn't run yet).
   If they DO exist by the time you run, stage them too.

5. `docs/ARCHITECTURE.md` — leave UNTOUCHED. The fix is a predicate alignment;
   no surface change. Note this in the commit message body
   ("ARCHITECTURE.md: unchanged — predicate-only fix, server contract intact").

6. `docs/KNOWN_FAILURES.md` — pre-flight scan: search for any existing entry
   referencing the dashboard plugin-health predicate or `plugin-status-dot--`.
   If none exists, that's expected. Note in the commit message
   ("KNOWN_FAILURES.md: no pre-existing entries removed").

7. `docs/decisions/dashboard-plugin-health-predicate-duplication.md` — write a
   ~1-page decision record explaining why the fix LEFT the predicate duplicated
   in two files (app.js and settings.js) instead of extracting a shared module.
   Cite the refactor-gate trade-off (one new file + a shared-module migration
   would be more churn than the recurrence cost in a 1-bug iteration; if drift
   recurs, file a refactor doc under `docs/bug-hunt/refactor-queue/` and let the
   next iteration's gate route to it). Frontmatter:
       ---
       date: 2026-05-06
       status: accepted
       ---

8. Refactor-queue verdict notes (read-only with one-line append): for each
   `docs/bug-hunt/refactor-queue/*.md` whose `category:` frontmatter equals
   `dashboard-state-sync`, you MAY append a one-line iteration note INSIDE THE
   DOC BODY (NOT the frontmatter) referencing this iteration's ledger entry,
   e.g.:
       > Iteration note (2026-05-06, bug-hunt 20260506T061637Z6594): a fresh
       > dashboard-state-sync drift surfaced (plugin-health predicate
       > 'unhealthy' vs 'error' string skew). Closed by Team A in commit
       > 407a1bb. Not within the scope this refactor was authored against.
   Do NOT change `verdict:` frontmatter — that's Phase 6 orchestrator territory.
   Skip docs that already have a verdict-note for an unrelated cluster.

9. `docs/bug-hunt/pending_recurrences.jsonl` — Phase 5.5 will append if the
   retest fails. By the time you run, this file may or may not have new lines.
   Stage whatever the orchestrator wrote. Note its state in the commit message
   ("pending_recurrences: <N> new patch-ineffective signals" or "no new
   patch-ineffective signals this iteration").

VALIDATION:
- `wc -l docs/bug-hunt/ledger.jsonl` increased by exactly 1.
- `jq -c . docs/bug-hunt/ledger.jsonl | tail -1` parses cleanly.
- `git status docs/bug-hunt/20260506T061637Z6594/` reports a clean tree.
- `grep -c "Bug Hunt 20260506T061637Z6594 — Closed" docs/REMAINING_TASKS.md`
  returns 1.

COMMIT MESSAGE (template — fill in the blanks):
```
[Team D]: docs: bug-hunt 20260506T061637Z6594 — record fixes for plugin-health predicate drift; LESSONS +2; ARCHITECTURE unchanged this iteration; ledger +1

- REMAINING_TASKS.md: 1 closure (plugin-health predicate drift, dashboard-state-sync)
- LESSONS.md: +2 (or +3) (server-enum/client-predicate drift; recon hygiene; optional triage)
- ARCHITECTURE.md: unchanged — predicate-only fix, server contract intact
- KNOWN_FAILURES.md: no pre-existing entries removed
- ledger.jsonl: +1 (finding_id=plugin-health-dot-unhealthy-falls-to-unknown, team=A, commit=407a1bb)
- decisions/: +1 (dashboard-plugin-health-predicate-duplication.md)
- refactor-queue/: <list of queue docs given an iteration note, or "none — no dashboard-state-sync refactor docs needed verdict-relevant note">
- pending_recurrences.jsonl: <N> new patch-ineffective signals (or "no new signals — Phase 5.5 still pending or all retests passed")
- bug-hunt/20260506T061637Z6594/: all artifacts staged
```

Time budget: 20 minutes.
