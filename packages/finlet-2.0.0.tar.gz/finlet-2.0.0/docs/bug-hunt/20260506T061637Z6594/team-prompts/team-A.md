You are Team A: dashboard plugin-health predicate — handle `unhealthy` server status.

This is the bug-hunt iteration `20260506T061637Z6594` patch. The full plan lives at:
`docs/bug-hunt/20260506T061637Z6594/plan.md`. Read your team section there for the full
spec including the recon-evidence subsection (you can rely on the recon evidence — it
was verified against HEAD `60bd34f` via verbatim file reads + live API + live DOM).

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report any of those as issues you
  introduced.
- Read the "Read these files first" list in your spec BEFORE writing any code.
- Follow existing patterns in those files.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message must start with "[Team A]:" — suggest:
  `[Team A]: dashboard: map server 'unhealthy' status to red error dot (predicate drift fix)`.
- Run the validation commands from your spec before finishing.
- If validation fails, fix the issue and re-commit.

When done, report: DONE + commit hash + validation results
OR: BLOCKED + what went wrong

— Team A spec (excerpt — full version in plan.md) —

Goal: Both dashboard predicates (`dashboard/app.js:2463-2465` and `dashboard/settings.js:1060`)
extend their `: status === 'error' ? 'error' : 'unknown'` arm to handle the
canonical server enum value `'unhealthy'` (per `finlet/plugins/base.py:135-140`).

Deliverable:
1. `dashboard/app.js`: predicate at lines 2463-2465 maps both `'error'` and
   `'unhealthy'` to the `'error'` (red) bucket.
2. `dashboard/settings.js`: predicate at line 1060 maps both `'error'` and
   `'unhealthy'` to the `'error'` (red) bucket.
3. `tests/dashboard/plugin-health-dot.spec.js` (new) — `node --test` unit test
   that loads each dashboard JS file as text in a `vm.createContext` sandbox and
   asserts the predicate's full mapping table. The spec must FAIL on HEAD before
   the predicate fix and PASS after.

Coverage requirements for the new spec (table-driven):
- Every `PluginHealthStatus` enum value: `'healthy'`, `'degraded'`, `'unhealthy'`.
- Aliases / equivalences: `'ok'` (alias for healthy), `'rate-limited'`, `'rate_limited'`.
- Edge cases: missing/null/undefined status, an unknown string `'foobar'`, mixed case `'Unhealthy'`.
- Both predicates (app.js's `dotClass` AND settings.js's `healthClass`).
- Also assert `app.js`'s `statusLabel` mapping at lines 2466-2472 — `dotClass='error'`
  must produce `statusLabel='Error'` (the sr-only label visible to screen readers
  must say "Error" not "Unknown" for unhealthy plugins).

How to extract the predicates for unit testing without spinning up a browser:

The two predicates are inline expressions inside `renderPlugins()` (app.js) and
inside `plugins.map(p => { ... })` (settings.js). The cleanest pattern, mirroring
`tests/dashboard/event-bus.spec.js`, is:

  - Read each file as text via `fs.readFileSync`.
  - Either (preferred) extract the predicate expressions with a regex and rebuild
    them as standalone functions inside a vm context; OR (acceptable if regex is
    fragile) define the same predicate logic in your spec file as the assertion
    target and pin the file's source content with a separate string-equality
    assertion that the predicate text in the source file matches the expected
    code (so a future predicate change cannot drift without breaking this spec).

  Whichever you pick, the test must reference the actual file content — a
  hand-rolled copy of the predicate that doesn't read the source defeats the
  drift-detection purpose.

Recommended approach: write the predicates as named function bodies inside the
spec ("expectedDotClass(status)" / "expectedHealthClass(status)" / "expectedStatusLabel(dotClass)"),
then read each source file and assert that the predicate's source-text
substring (e.g., the exact characters from the const expression's `=` to its
closing `;`) equals the spec's authoritative copy. That way:
  - The spec FAILS on HEAD because the source predicate doesn't match the
    authoritative copy (the authoritative copy includes `|| status === 'unhealthy'`).
  - After Team A's predicate fix, the source matches the authoritative copy and
    the spec PASSES.

If the substring extraction is too brittle, an alternative is `eval`-ing the
predicate source inside a vm context. Either approach is acceptable — pick the
one that is simpler to read and that fails clearly when the predicate drifts.

DO NOT:
- Refactor the predicates into a shared module — out of scope this iteration.
- Touch `finlet/plugins/base.py`, `finlet/api/routes_health.py`, or any plugin's
  `_probe()` — server contract is correct.
- Edit the comment block at `dashboard/app.js:2451-2457` (the comment IS the contract
  reminder; updating its claim that "we mirror settings.js" is fine but optional).
- Change CSS variables, dot sizes, or any class names other than the predicate output.

Validation commands (run all and ensure all pass before committing):
- `node --test 'tests/dashboard/*.spec.js'` (NOT `node --test tests/dashboard/` — bare
  directory fails with MODULE_NOT_FOUND; use the glob).
- `bash scripts/lint-trusted-types.sh`
- `bash scripts/lint-event-bus.sh`
- `uv run pytest tests/api/test_plugin_health.py -x -q`
- Drift-proof check: locally revert your `dashboard/app.js` predicate change, re-run
  `node --test 'tests/dashboard/plugin-health-dot.spec.js'`, confirm the new spec FAILS,
  then restore the fix and re-run to confirm GREEN. (This proves the spec pins the
  bug, not the patch.) Don't leave the revert in your committed diff.

Working directory: your assigned worktree (you'll be told the path). Spawn base SHA:
`60bd34fc5723c4a1383cf5815a6a5b835d69f326` (the orchestrator will reset your
worktree to this SHA before you start).

Time budget: ~25 minutes.
