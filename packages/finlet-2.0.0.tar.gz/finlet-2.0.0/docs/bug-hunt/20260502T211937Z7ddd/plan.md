# Bug Hunt 20260502T211937Z7ddd — Execution Plan

> Generated from docs/bug-hunt/20260502T211937Z7ddd/triage.md. Last updated: 2026-05-02

## Constraints

- **Scope is patch-level, not architectural.** The trade-ticket-state-sync v2 refactor (commit 1cd2b5b) just shipped and Phase 6 will set its verdict. Don't bundle architecture changes into this iteration.
- **Bug 1 is a UI-feedback fix to a stub endpoint shipped last iteration** (commits 59d56e3 + bb9bef6). The endpoint stays a stub — only the click-side UX wiring needs work. Don't widen scope to actual ingestion pipeline.
- **Bug 2 is a render-side default-value fix on the dashboard widget.** Don't touch the canonical /v1/plugins/health endpoint — it's working; only the dashboard's interpretation is wrong. Settings already renders correctly (commit bb9bef6) — Settings code is the convergence target, not the thing to change.
- **Trusted-types lint** is enforced by `scripts/lint-trusted-types.sh` (pre-commit). Any `.innerHTML =` write under `dashboard/` must go through `trustedHTML(...)`.
- **Event bus contract:** all dashboard pub/sub goes through `window.finletBus.subscribe(event, handler)` / `publish(event, payload)`. Direct `addEventListener('finlet:...')` is forbidden. If a new bus event is introduced, update `dashboard/event-contract.md`.

## File Conflict Table

### Shared File Conflicts
| File | Touched by Teams |
|------|-----------------|
| (none) | — |

Teams A and B touch DISJOINT files: A touches `dashboard/settings.*`, B touches `dashboard/app.js` (+ a one-line `dashboard/index.html` if widget HTML must change). No conflicts → both can run fully in parallel.

Team D (docs) touches only `docs/*` — no conflict with code teams.

## Dependency Graph

```
Team A (Ingest button feedback)        ── independent, can start immediately
Team B (Dashboard color default fix)   ── independent, can start immediately
Team D (Docs + ledger + pending file)  ── BLOCKED BY A + B (must read merge SHAs into ledger entries)
```

## Critical Path

```
(A or B, parallel) → Team D
```

Critical path = max(A, B) + D. A and B are tiny patches (≤3 files each), so parallel A+B finishes fast. D is purely doc updates.

---

## Teams

### Team A: Settings Ingest button feedback

**Blocked by:** none — can start immediately.

**Read these files first** (to avoid building on stale assumptions):

- `dashboard/settings.js:1009-1100` — `loadPlugins()` is the canonical render path; lines 1020-1023 show the silent-empty fallback that lets the container "disappear" when /plugins/health returns null. **READ this whole function — your fix must not break the existing render contract.**
- `dashboard/settings.js:1108-1142` — `triggerIngest()` is the click handler you are modifying. Lines 1110-1114 show the POST; 1115-1128 show the success-toast path; 1130-1134 show the (currently silent) error path.
- `dashboard/settings.js:1038-1044` — the canonical status→color mapping you should NOT change but should mirror in any new pending-state CSS class.
- `finlet/api/routes_plugins.py` — verify the stub endpoint still returns `202 + {job_id: <uuid>}` on the happy path. Do NOT modify the endpoint contract.
- `dashboard/event-contract.md` — if you publish a new bus event (e.g., `finlet:plugin-ingest-queued`), document it here in the same commit.
- `docs/decisions/plugin-ingest-stub-endpoint.md` — context for why the endpoint is a stub.
- `scripts/lint-trusted-types.sh` — your `.innerHTML =` writes under `dashboard/` must wrap through `trustedHTML(...)`.

**Files touched:**

- Modified: `dashboard/settings.js` — `triggerIngest()` (1108-1142): set the row into a "queuing" pending state immediately on click (button disabled + label "Ingesting…" or aria-busy=true), keep the toast on 202, surface a row-level inline error message on non-2xx (don't silently re-render), and re-enable the button after the next /plugins/health poll lands. Keep the existing 2s polling — DO NOT spin up a parallel poll. The bug today is that the click handler relies on the toast-only feedback path while something else (probably the next poll cycle's DOM swap during re-render) blows away the panel; fix is: own the row's pending-state lifecycle in the click handler, do not depend on the global re-render to communicate progress.
- Modified: `dashboard/settings.css` — add `.plugin-row[aria-busy="true"]` styling and a `.plugin-row .ingest-pending` indicator (small spinner or "Ingesting…" badge).
- Modified: `dashboard/settings.html` — only if the existing template lacks an `aria-busy` slot per row; otherwise leave alone. Prefer attribute-only changes over template surgery.

**Deliverable:** Clicking Ingest on a degraded plugin row in Settings > Plugins (a) immediately shows in-row feedback (button disabled + spinner OR "Ingesting…" label OR aria-busy=true) within 1s, (b) keeps the plugin tabpanel rendered (does NOT collapse to empty), (c) keeps showing the existing success toast on 202, (d) surfaces a row-level error message on non-2xx without silently rerendering to "No plugins registered".

**Validation:**
- [ ] `uv run pytest tests/api/test_routes_plugins.py -x -q` passes (sanity that endpoint contract didn't drift).
- [ ] `bash scripts/lint-trusted-types.sh` passes (no raw `.innerHTML =` writes added).
- [ ] Manual smoke test (locally OR by reading retest): click Ingest on a degraded plugin row, verify (a) row enters busy state within 1s, (b) tabpanel remains rendered (do NOT collapse), (c) toast appears on 202, (d) row exits busy state on next /plugins/health poll.
- [ ] No new bus events published without updating `dashboard/event-contract.md`.

**Agent instructions:**
- You MUST `git add` + `git commit` your work in your worktree before finishing — uncommitted work is destroyed when the worktree is cleaned up.
- Commit message format: `[Team A]: dashboard/settings: Ingest button row-level feedback (close dead-recovery-affordance)`
- Follow the existing `loadPlugins()` render pattern (template literals + `trustedHTML(...)`) in `dashboard/settings.js:1009-1100`.
- Do NOT touch the stub endpoint at `finlet/api/routes_plugins.py` — it is intentionally a stub for this iteration.
- Do NOT add a new poll loop. Reuse the existing /plugins/health poll for the resolution signal.
- If you change the `triggerIngest()` signature, update all callers — there should be exactly one (the row's button click).

---

### Team B: Dashboard plugin-health widget default-status fix

**Blocked by:** none — can start immediately.

**Read these files first:**

- `dashboard/app.js:2187-2234` — `renderPlugins()` is the bug site. Lines 2212-2218 contain the status→color mapping. The bug is line 2212: `const status = (p.status || 'healthy').toLowerCase();` — defaulting to `'healthy'` when `p.status` is null/undefined renders a degraded plugin as green.
- `dashboard/settings.js:1038-1044` — the canonical-correct mapping. Settings defaults missing status to `'unknown'`, which renders gray. **Mirror this contract on the dashboard.**
- `finlet/api/routes_health.py:84-114` — verify the endpoint response shape. The `PluginHealthItem` schema returns `status` as a string enum value. Confirm with `curl -fsS -H "Authorization: Bearer $FINLET_TEST_USER_API_KEY" $FINLET_BASE_URL/v1/plugins/health | jq '.[] | select(.name=="news_s3")'` whether the field is actually missing in the response or is being misread by the dashboard. (If the field IS present and correct in the response, the dashboard fix is just the default-value change. If the field is missing, the fix is in `routes_health.py`. **Do not assume** — verify.)
- `dashboard/app.js:1747-1749` — the 2s fallback poll loop (`scheduleFallbackFetch`) that calls `renderPlugins()`. Confirm your fix is reached on every poll, not just on initial load.
- `dashboard/event-contract.md` — if any bus event change is introduced.

**Files touched:**

- Modified: `dashboard/app.js` — `renderPlugins()` (2187-2234): change the missing-status default from `'healthy'` to `'unknown'` to match `dashboard/settings.js:1040`, AND add an explicit defensive check that the rendered dot color reflects the canonical `status` field (not derived from `cache_count`, `files_found`, or `message` substring). If the verify-step above shows the endpoint actually omits `status` for a degraded plugin, also patch `finlet/api/routes_health.py:84-114` so `status` is always populated — but this is a fallback; the primary fix is the dashboard default.

**Deliverable:** Dashboard Plugin Health widget renders the same color dot as Settings > Plugins for the same plugin in the same session. A plugin whose canonical status is `degraded` (or any non-healthy value) renders the degraded color on BOTH surfaces. A missing/null status defaults to `unknown` (gray) on BOTH surfaces, never to `healthy`.

**Validation:**
- [ ] `uv run pytest tests/api/test_plugin_health.py -x -q` passes (verifies endpoint contract).
- [ ] `bash scripts/lint-trusted-types.sh` passes.
- [ ] Manual smoke test (locally OR by reading retest): hit `GET /v1/plugins/health` with the test user's API key; verify every plugin's `status` field is present and string-typed; navigate to /index.html, verify the Plugin Health widget renders the news_s3 row with the same color as Settings > Plugins.
- [ ] If any change to `routes_health.py`, add/extend the unit test in `tests/api/test_plugin_health.py` to cover the missing-status path explicitly.

**Agent instructions:**
- You MUST `git add` + `git commit` your work in your worktree before finishing.
- Commit message: `[Team B]: dashboard/app: plugin-health widget defaults missing status to unknown (close dashboard-state-sync news_s3 mismatch)`
- The PRIMARY fix is the one-line default-value change at `dashboard/app.js:2212`. Anything beyond that needs explicit justification by the curl verification step. Do not over-engineer.
- Use `trustedHTML(...)` for any `.innerHTML =` writes.
- The dashboard's `renderPlugins` and Settings's `loadPlugins` are NOT yet a shared helper — DO NOT extract one this iteration. That's a refactor, not a patch. Just make the two contracts agree.

---

### Team D: Docs + ledger + pending-recurrences staging

**Blocked by:** Team A AND Team B (must read merge SHAs to populate the ledger).

**Read these files first:**

- `docs/bug-hunt/20260502T211937Z7ddd/triage.md` — the iteration's broken/logged bullets and the Required Docs Updates block. Treat it as the authoritative scope.
- `docs/bug-hunt/ledger.jsonl` — read the most recent ~10 lines to mirror the schema and category vocabulary.
- `docs/bug-hunt/pending_recurrences.jsonl` — one open entry: `trade-ticket-stale-cash` from 20260502T142726Z7b36. **Do NOT modify this file** — Phase 6 (orchestrator) handles pruning based on verdict-setting. Just stage it for commit if it changes.
- `docs/REMAINING_TASKS.md` — most recent "Bug Hunt — Closed" subsection for the formatting pattern.
- `docs/LESSONS.md` — most recent entries for tone/format.
- `docs/ARCHITECTURE.md` — only update if a real architectural surface changed (CSP, route surface, plugin registry, dashboard event bus). For this iteration, neither bug touches architecture; mark "ARCHITECTURE.md unchanged this iteration" in the commit message.
- `docs/KNOWN_FAILURES.md` — refresh; remove any entry resolved by A or B.
- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v2.md` — the orchestrator (Phase 6) sets verdict on this; Team D ONLY stages it for commit if the orchestrator touches it. Do not write a verdict yourself.

**Files touched:**

- Modified: `docs/REMAINING_TASKS.md` — append a "Bug Hunt 20260502T211937Z7ddd — Closed" subsection listing the 2 broken items and the merge SHAs from A + B.
- Modified: `docs/LESSONS.md` — append at least one new lesson per real-broken finding. Suggested lessons:
  - "Stub endpoints shipped without UI feedback wiring create dead-recovery-affordance follow-ups: when shipping a stub-endpoint button, ALWAYS include the click-side pending-state lifecycle in the same commit so the row doesn't depend on the next-poll re-render to communicate progress."
  - "Two surfaces rendering the same canonical state must share the same default-value contract for missing fields. The bug today: dashboard defaults `p.status || 'healthy'` (green), settings defaults `p.status || 'unknown'` (gray). Same data, different lies. Use the same default everywhere; prefer 'unknown' over 'healthy' so missing data fails closed."
- Modified: `docs/KNOWN_FAILURES.md` — refresh; remove any entry that A or B resolved.
- Modified: `docs/bug-hunt/ledger.jsonl` — APPEND exactly 2 new JSON lines:
  ```jsonl
  {"iteration_ts":"20260502T211937Z7ddd","finding_id":"<short-slug-A>","category":"dead-affordance","summary":"Settings Ingest button: row-level pending state on click; tabpanel persists during ingest","scope_files":["dashboard/settings.js","dashboard/settings.css","dashboard/settings.html"],"team":"A","commit":"<merge-sha-A>"}
  {"iteration_ts":"20260502T211937Z7ddd","finding_id":"<short-slug-B>","category":"dashboard-state-sync","summary":"Dashboard Plugin Health widget defaults missing status to unknown (was: healthy); aligns with Settings render","scope_files":["dashboard/app.js"],"team":"B","commit":"<merge-sha-B>"}
  ```
  Read the merge SHAs from `git log --oneline main` after A and B have merged. Suggested slugs: `settings-ingest-row-pending-state` and `dashboard-plugin-health-default-status`. Reuse `dead-affordance` (existing tag from ledger), NOT `dead-recovery-affordance` — DO NOT mint a near-duplicate tag.
- Staged (NOT modified by Team D): `docs/bug-hunt/pending_recurrences.jsonl` and `docs/bug-hunt/pending_recurrences.resolved.jsonl` — orchestrator handles content; Team D stages whatever the orchestrator wrote.
- Staged: every artifact in `docs/bug-hunt/20260502T211937Z7ddd/` produced this iteration (blind_report.json, triage.md, triage.json, plan.md, cleanup.log, isolation_warning.txt, deploy_status.txt, retest_results.json).
- Optional: `docs/decisions/<...>.md` — only if a non-trivial reversible decision was made. None expected this iteration; both fixes are direct.

**Deliverable:** A single commit on `main` titled `docs: bug-hunt 20260502T211937Z7ddd — close 2 broken (Ingest UX, dashboard plugin-health default); LESSONS +2; ledger +2; ARCHITECTURE unchanged this iteration` with all the docs and artifacts above staged + committed.

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` grew by exactly 2 (one per real-broken closed).
- [ ] `jq -c . docs/bug-hunt/ledger.jsonl | tail -2` parses cleanly (every new line is valid JSON, has all 7 schema fields).
- [ ] `git status` shows zero untracked files under `docs/bug-hunt/20260502T211937Z7ddd/`.
- [ ] `docs/REMAINING_TASKS.md` has a "Bug Hunt 20260502T211937Z7ddd — Closed" subsection.
- [ ] `docs/LESSONS.md` has 2 new entries (one per real-broken).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Commit message: as in Deliverable above.
- DO NOT modify `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v2.md` — orchestrator handles verdicts.
- DO NOT modify `docs/bug-hunt/pending_recurrences.jsonl` content — orchestrator handles pruning. You only stage it for commit if it changed.
- Read the merge SHA for A and B from `git log --oneline main -10` after they have merged.
- If you cannot infer a clean `finding_id` slug from the bug description, use the literal string: `settings-ingest-row-pending-state` for A and `dashboard-plugin-health-default-status` for B.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A's pending-state CSS interferes with the existing `loadPlugins()` re-render and causes a visual flicker on poll | Medium | Low | Keep pending state as a row-level attribute (`aria-busy`), not a global panel state. Existing `loadPlugins()` will re-render the row and the attribute resets naturally. |
| Team A regresses the existing toast-on-202 path while adding the row-level pending state | Medium | Medium | Validation step: manual smoke test must verify the toast STILL appears on 202. Don't remove existing toast code; only add row-level state alongside. |
| Team B's default-value change masks a real backend bug where status is genuinely missing | Low | Medium | Curl verification step in "Read these files first" forces the agent to confirm the field is present. If the field is absent, agent patches `routes_health.py` to populate it; otherwise the dashboard default-fix is the entire fix. |
| Team B over-engineers and extracts a shared status-mapping helper | Low | Low | Explicit "do NOT extract a shared helper this iteration" instruction. Refactor is the next iteration's call, not this one's. |
| Team D commits before A or B merges, missing merge SHAs | Medium | Low | Team D is BLOCKED BY A AND B in the dependency graph. exec-plan enforces this. Worker reads SHAs from `git log --oneline main` AFTER A and B have merged. |
| Phase 5.5 retest agent finds Bug 2 not fully fixed because cache invalidation on the 2s poll lags the patch by one cycle | Low | Low | Retest assertion #1 already accounts for the 2s poll cycle (waits up to 30s). If retest still fails, it's a real fix gap, not a timing issue. |
| Iteration's same_root_cause_as forward signals trip the next iteration's refactor gate | High | Medium (intentional) | This is the system working as designed. If A or B's fix is patch-ineffective, Phase 5.5 will append to pending_recurrences.jsonl and the NEXT iteration's gate will route to refactor. Don't try to suppress this. |

## Session Plan

### Session 1 — Patches + Docs
**Parallel:** Team A and Team B start immediately, in separate worktrees, no shared files.
**Merge order (sequential):** A merges → targeted test gate (`uv run pytest tests/api/test_routes_plugins.py -x -q` + `bash scripts/lint-trusted-types.sh`) → B merges → targeted test gate (`uv run pytest tests/api/test_plugin_health.py -x -q` + `bash scripts/lint-trusted-types.sh`).
**Then:** Team D, blocked by both A and B, runs after both merge. Team D reads the merge SHAs and writes the ledger.
**Session checkpoint:** `uv run pytest -x -q` (full suite) + `bash scripts/lint-trusted-types.sh` (final). Then push to `origin/main`.

There is no Session 2 — this is a one-session iteration.

---

## Phase 5.5 / Phase 6 hand-off (orchestrator scope, NOT a team)

After Session 1's push:
- Phase 5.5 polls the deploy workflow on `origin/main` until `conclusion=success` or timeout.
- On deploy success, Phase 5.5 spawns the retest agent which executes the 2 retest envelopes from `triage.json` against finlet.dev.
- Phase 5.5c appends any `retest_status: fail` rows to `docs/bug-hunt/pending_recurrences.jsonl`.
- Phase 6 evaluates the verdict on `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v2.md` (currently `status: shipped`, no verdict). Strong prior signal: the blind report did NOT report a Trade Ticket stale cash issue this iteration. If `dashboard-state-sync` count for trade-ticket specifically is zero in this triage (it is — news_s3 is a different broken predicate even though same category), set `verdict: effective` and prune the open `trade-ticket-stale-cash` entry from `pending_recurrences.jsonl` into `pending_recurrences.resolved.jsonl`.
- Phase 6 emits the final summary with deploy status, retest pass/fail, systemic candidates (recurrence check), and refactor outcomes.
