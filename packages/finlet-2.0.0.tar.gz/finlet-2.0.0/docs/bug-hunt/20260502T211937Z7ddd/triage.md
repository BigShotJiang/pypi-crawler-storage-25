## Broken (will be fixed this iteration)
- Clicking 'Ingest' on Settings > Plugins price row collapses the tabpanel to empty with zero visual feedback (no spinner, no toast, no error); ingestion succeeds eventually but the Settings surface gives no confirmation of the click [evidence: "After clicking Ingest on the price plugin (status: DEGRADED, 'No price data available for the last 7 days'), the tabpanel content disappeared in the accessibility tree (collapsed to empty generic[ref=e41]). No success toast, no loading indicator. Had to re-click the Plugins nav button to reload the section. Ingestion DID eventually succeed -- the dashboard Plugin Health panel later showed price as HEALTHY with 'OK -- 8 cached files' -- but the Settings page gave no confirmation."] [scope hint: dashboard/settings.js, dashboard/settings.html, dashboard/settings.css, finlet/api/routes_plugins.py]
- news_s3 plugin renders a green/healthy status dot in the dashboard Plugin Health widget while the row's message text says DEGRADED ('No cached news data files found'); Settings > Plugins correctly shows yellow/degraded for the same plugin -- two surfaces, one truth contradicted [evidence: "In Settings > Plugins, news_s3 correctly shows a yellow dot and 'DEGRADED'. But in the dashboard Plugin Health panel (post-trade), news_s3 appears to render a green dot alongside the text 'No cached news data files found. Run ingestion first.' -- the status color indicator contradicts the status message."] [scope hint: dashboard/app.js, dashboard/index.html, finlet/api/routes_health.py]

## Logged (not actioned)
- Finlet benchmark MCP tools not accessible to ToolSearch in blind subprocess (launcher/env infra issue, not a finlet.dev product bug; user-facing site fine) [classification: working-as-designed]
- No 'fundamentals strategy' wizard or template in UI; new user has no UI path matching the task wording [classification: annoying]
- finnhub/fred/edgar plugins show 'not initialized' with blank API-key field but no key-format hint or signup link [classification: annoying]
- Trade Ticket stays open after successful order submission with no auto-close or success toast (sell-radio + symbol/qty reset is the only indirect cue) [classification: annoying]
- Onboarding wizard Step 1 'Continue' button is disabled with no helper text or tooltip explaining a persona must be picked [classification: annoying]
- Dashboard browser tab title says 'AI Trading Agent ITE' (unexplained acronym) inconsistent with landing page branding 'AI Trading Agent Backtesting Platform' [classification: annoying]
- Win Rate card reads 'N/A -- 0 closed -- 1 filled' after a successful fill; technically correct but reads as failure to first-time users [classification: annoying]
- Plugin not-initialized cards should link directly to provider API-key signup pages [classification: nice-to-have]
- Guided 'Fundamentals Strategy' setup flow missing despite landing-page mention [classification: nice-to-have]
- Manual Trade Ticket has no Reasoning text field so Order Log always shows '--' for UI-placed trades [classification: nice-to-have]
- 'Advance to next trading day' shortcut button on the empty-state equity curve would orient new users faster [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260502T211937Z7ddd — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. `docs/bug-hunt/20260502T211937Z7ddd/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log,
   deploy_status.txt, retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260502T211937Z7ddd","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline (see
   Phase 5.5c). Team D MUST stage the file. If a refactor verdict pruned entries
   this iteration, Team D MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`
   (the audit log of resolved signals).

Team D's commit message must reference iteration 20260502T211937Z7ddd and name which docs were
touched (e.g., "docs: bug-hunt 20260502T211937Z7ddd — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
