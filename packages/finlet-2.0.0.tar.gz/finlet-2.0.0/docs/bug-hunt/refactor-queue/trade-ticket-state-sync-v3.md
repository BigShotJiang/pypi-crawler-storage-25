---
status: shipped
verdict: incomplete
verdict_set_in: 20260503T030227Z2009
verdict_v3_evidence: "v3 (render-on-read from canonical store, ea9ee7e) shipped the correct architectural shape — DOM reads from currentSession.portfolio_metrics.cash with bus.getLastPublished as the cold-open backstop, payload values intentionally ignored — but missed the closed-panel persistent-DOM-rot publisher-vs-subscriber-lifetime gap. submitTradeTicket calls closeTradeTicket() which tears down the dialog-state-mirror's bus subscriber BEFORE the post-submit IIFE in dashboard/trade-ticket.js#submitTradeTicket publishes portfolio:updated. The persistent <aside id='trade-ticket-panel'> DOM stays mounted across open/close cycles, so #tt-cash-balance keeps its pre-fill text — bus.publish lands on zero subscribers for that surface, no consumer is listening at publish time, the DOM rots until the next openTradeTicket() runs onOpen → repaintCash. The same gap surfaces for SSE-driven fills when the panel happens to be closed (no mirror subscriber listening). v3.1 (Team A, commit 8c55a90, merged as 8e78c5a) closes the gap by appending a terminal repaintCash() call at every publisher site that mutates currentSession.portfolio_metrics.cash before publishing portfolio:updated — three sites, 1 line each: dashboard/trade-ticket.js#submitTradeTicket post-submit IIFE, dashboard/app.js SSE portfolio handler, dashboard/app.js SSE orders deferred-portfolio-refetch IIFE. The render-on-read contract is preserved end-to-end: repaintCash() still reads canonical only (currentSession.portfolio_metrics.cash with bus.getLastPublished('portfolio:updated').cash as fallback) — payload values are intentionally ignored, so the journey-05 poison-publish-after-close assertion at tests/e2e/journey-05-trade.spec.ts:447-463 still passes. Atomic-mutate-then-publish contract preserved; we just append a mutate-then-publish-then-repaint terminal step. Surfaced by bug-hunt iteration 20260503T030227Z2009."
shipped_at: 2026-05-02
shipped_in: ea9ee7e (after merge 42ffd2e of [b715dfd revert v2, acdfb80 v3 core, fda69be test align] + ea9ee7e window.currentSession alias fix-forward)
deploy_run: 25266871370 (success)
verdict_v3_1: effective
verdict_v3_1_set_at: 2026-05-05
verdict_v3_1_set_in: convention-enforcement-2026-05-05
verdict_v3_1_evidence: "v3.1 (commit 8c55a90, bug-hunt 20260503T030227Z2009 Team A) appended a terminal repaintCash() at every publisher site that mutates currentSession.portfolio_metrics.cash before publishing portfolio:updated — three sites: dashboard/trade-ticket.js#submitTradeTicket post-submit IIFE, dashboard/app.js SSE portfolio handler, dashboard/app.js SSE orders deferred-portfolio-refetch IIFE. The pending_recurrences.resolved.jsonl entry for `trade-ticket-stale-cash` (patch_iteration_ts 20260502T142726Z7b36, deploy_sha 433c01c) records v3.1 as the closer. Latest trade-ticket-tagged ledger entry is `trade-ticket-stale-cash` (iter 20260503T030227Z2009, commit 8c55a90); zero subsequent trade-ticket entries in the ledger across iterations 20260503T195318Z43db, 20260503T230405Z2601, and 20260504T165106Z1ab2. The render-on-read contract is preserved end-to-end (repaintCash reads canonical only — payload values intentionally ignored, journey-05 poison-publish-after-close test still passes), and the persistent-DOM closed-panel rot gap is closed by construction."
category: dashboard-state-sync
drafted: 2026-05-02
drafted_in: refactor-gate-trip-from-pending-recurrences-third-pass
instances: 1
iterations: [20260502T142726Z7b36]
related_ledger_entries: [trade-ticket-stale-cash]
trigger: patch-ineffective
prior_refactor: trade-ticket-state-sync-v2.md (regressed — always-on subscription broke open/close DOM teardown contract)
prior_patches: [109686c (iter 7b36 Team A), c712d98 (v2 Team A)]
deploy_blocked: false
revert_v2_required: true
next_step: Render-on-read refactor — `paintCash` reads cash at call time from a single canonical store (`getCanonicalCash()` over `currentSession.portfolio_metrics.cash` with bus-cache fallback). Drop the v2 always-on `portfolio:updated` subscriber. Bus events become repaint TRIGGERS, not value carriers. Both per-open mirror and SSE/post-fill publishers fire `paintCash()` (no payload arg) which always reads from the store — eliminates "subscriber painted from a payload it shouldn't trust" failure mode.
---

# Refactor — Trade Ticket cash header: render-on-read from a single canonical store

## Why we're here (3rd time on this surface)

Three iterations. Three different failure modes. All on the same `<span id="tt-cash-balance">` text node.

**v1 (`efdd44316`, 2026-04-30 — effective for its design surface).** Shipped `dashboard/dialog-state-mirror.js`. Closed three recurrence shapes for *true dialogs whose DOM lifecycle equals their visibility lifecycle*:
- pre-publish gap (open-after-publish) — bus `getLastPublished` cache primes synchronously on open
- mid-fill stale (panel open during fill) — live subscription paints on `portfolio:updated`
- shape-drift / transient-failure stomp — `refetch` + `refuseClobber` fallbacks

What v1 did NOT cover, and could not have known to cover: the iter 7b36 case where `submitTradeTicket()` calls `closeTradeTicket()` BEFORE its own post-submit IIFE republishes (`dashboard/trade-ticket.js:414` close, `:484` publish). The mirror is unsubscribed by line 484. The DOM `#tt-cash-balance` is persistent (slide-out `<aside>`, `dashboard/index.html:435`), so it keeps the pre-fill text — verified by Phase 5.5 retest of iter 7b36 against deploy `433c01c`: panel showed `$100,000.00` while Key Metrics showed `$94,846.45`.

**v2 (`c712d98`, merged in `1cd2b5b`, 2026-05-02 — regressed, deploy-blocked).** Added a page-lifetime `portfolio:updated` subscriber inside `initTradeTicket()` (`dashboard/trade-ticket.js:141-147`) that calls `paintCash(payload.cash)` on every publish, regardless of panel visibility. Closes iter 7b36's recurrence in principle. Breaks `tests/e2e/journey-05-trade.spec.ts:447-463` — the existing regression test explicitly asserts that after `closeTradeTicket()`, an `bus.publish('portfolio:updated', { cash: 999999 })` MUST NOT mutate `#tt-cash-balance`. The v2 subscriber is unconditional, so the poison-cash 999999 lands on the DOM. Deploy run `25263179874` failed at `journey-05-trade.spec.ts:389`. Production is still on `a34ac9d` (pre-v2). v2 is shipped-broken.

**Pattern.** Every iteration patches the symptom one publisher/subscriber edge at a time. v1 added a primer + shape-drift fallback. iter 7b36 added a third publisher (post-submit IIFE). v2 added a permanent subscriber. The set of "places that read or write `#tt-cash-balance`" keeps growing; the rules for which write should land on the DOM keep growing in lockstep. v4 will recur as soon as the next surprising publisher/subscriber asymmetry surfaces.

## Root cause

Architectural, not behavioural: **`#tt-cash-balance` has multiple write paths and no single read source.** The v1 mirror writes from `primeFromCache` (synchronous read of `currentSession.portfolio_metrics.cash`), from `onUpdate` (read of `payload.cash`), and from `refetch → fetchCashBalance` (read of `result.data.cash` from `/portfolio` endpoint). The v2 subscriber writes from `payload.cash` again, on a different lifetime. The iter 7b36 IIFE writes (transitively) by mutating `currentSession.portfolio_metrics.cash` then publishing, hoping a downstream reader will repaint.

Each of these read-and-write sites is its own `paintCash(payload.cash)` invocation. There is no module-internal contract that says: *"the only legitimate value to paint is the canonical cash, and every paint must agree on what `canonical` means."* Instead, each paint trusts the value its own caller supplied. When a publisher (any publisher — including a test, including a future feature, including the v2 always-on path) hands the subscriber an untrusted value, the subscriber paints it. When a publisher and the canonical store get out of sync (iter 7b36: panel closed before publish, no subscriber to consume), the DOM rots. Both failure modes share one root: **the panel does not own its read; it lets publishers push values into it.**

Symptomatic candidates from the v2 doc's `next_step` (rejected for v3 — see "Approach"):
- (a) Cash displayed in two places with two update paths — yes, but coupling them is the consequence of the deeper issue, not its root.
- (b) Lifecycle mismatch between panel DOM and subscription — true description of the v2 failure, not the v1+iter-7b36 failure. A lifecycle fix wouldn't have caught iter 7b36 unless we also picked the right lifecycle.
- (c) `portfolio:updated` is noisy — true, but adding a source predicate just relocates the problem ("which publishers do we trust this iteration?"). The next surprising publisher we don't anticipate trips it again.

## Approach

**Pick option 3: render-on-read, single source of truth.** The bus event becomes a repaint TRIGGER, not a value carrier. The store is the only thing the panel reads from.

### Sketch

```js
// dashboard/trade-ticket.js — replace the current paintCash(cash) signature

// Single canonical reader. Order: session-state mirror → bus last-published cache → undefined.
// Both upstream sources are SSE-fed and atomically updated by the post-fill paths;
// either is an acceptable canonical value, never a payload from an arbitrary publisher.
function getCanonicalCash() {
    const sess = (typeof currentSession !== 'undefined') ? currentSession : null;
    if (sess && sess.portfolio_metrics && typeof sess.portfolio_metrics.cash === 'number'
        && !Number.isNaN(sess.portfolio_metrics.cash)) {
        return sess.portfolio_metrics.cash;
    }
    if (window.finletBus && typeof window.finletBus.getLastPublished === 'function') {
        const last = window.finletBus.getLastPublished('portfolio:updated');
        if (last && typeof last.cash === 'number' && !Number.isNaN(last.cash)) {
            return last.cash;
        }
    }
    return undefined;
}

// Repaint reads. Never accepts a value argument. Returns silently when no canonical value.
function repaintCash() {
    const cash = getCanonicalCash();
    const cashDisplay = document.getElementById('tt-cash-balance');
    if (!cashDisplay) return;
    if (typeof cash !== 'number') return;  // refuse-clobber baked in: never paint placeholder over known-good
    tradeTicketCashBalance = cash;
    cashDisplay.textContent = '$' + Number(cash).toLocaleString('en-US',
        { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// Per-open mirror still owns the open lifecycle, but its handlers all funnel
// through repaintCash() — they no longer pass payload.cash directly.
// onOpen: repaintCash(); refetch();    // refetch's success path mutates currentSession.portfolio_metrics
// onUpdate: repaintCash();              // payload triggers a re-read; payload's cash field is ignored
```

The v2 always-on subscriber is dropped. The journey-05 poison test (`bus.publish('portfolio:updated', { cash: 999999 })` after close) does NOT mutate `currentSession.portfolio_metrics.cash` — `app.js:1456-1466` is the only writer of that field, and it's only reachable from the SSE handler. So even if some leaked subscriber on `portfolio:updated` calls `repaintCash()` after close, the read returns the canonical (non-poisoned) value and the DOM text is unchanged. The test passes by construction, regardless of subscriber leak topology.

The iter 7b36 case (panel closed mid-submit, post-submit IIFE republishes) is closed because the IIFE at `trade-ticket.js:443-494` already mutates `currentSession.portfolio_metrics.{cash,total_value}` BEFORE publishing (lines 460-477). When a future panel `openTradeTicket()` fires, `primeFromCache` reads the post-fill cash and `paintCash` lands on the fresh value. AND — separately — when the next SSE `portfolio` tick arrives (~1s later via `_PUSH_INTERVAL`), `app.js:1442-1478` mutates the same store, and any open mirror's `onUpdate` calls `repaintCash()` which reads canonical and lands on the fresh value. Belt and suspenders, both correct, neither bleeding into the closed-panel poison-test contract.

### Scoring

| Approach | Diff size | Regresses journey-05:389 | Closes iter 7b36 | Survives v4? |
|----------|-----------|--------------------------|------------------|--------------|
| 1. Source-predicate gate on v2 subscriber | ~10 LOC subscriber + payload schema change at 3 publish sites + test stubs | Likely passes (only `source: 'sse' \| 'post-fill-refetch'` paints, not arbitrary `bus.publish`) | Yes — post-fill IIFE and SSE both whitelisted | **No**: introduces a new convention (every publish must carry a `source`) that lint can't enforce. The next forgetful publisher omits `source` and either (a) gets ignored when it shouldn't, or (b) we make the predicate permissive and the test poison sneaks through. |
| 2. Dedicated `panel-cash:repaint` event | ~15 LOC + 1 new event in `event-contract.md` + 3 publisher migrations | Likely passes (test pokes `portfolio:updated`, panel listens to a different event) | Yes — emit on the post-fill paths | **No**: same fundamental pattern as v2 (subscriber paints from publisher's payload), just renamed. Different failure mode of the same shape will surface — e.g., what if a publisher fires the new event with a value that disagrees with the canonical store? |
| 3. Render-on-read store-canonical (this doc) | ~30 LOC net in `trade-ticket.js` (new `getCanonicalCash` + `repaintCash`, drop v2 subscriber, simplify mirror handlers) | **Passes by construction** — bus payload value is ignored by the panel; only the canonical store is read | Yes — `currentSession.portfolio_metrics.cash` is mutated by post-fill IIFE before publish | **Yes**: removes the entire class of "subscriber painted from a payload it shouldn't trust" bugs. New publishers that don't update the canonical store harmlessly trigger a repaint of whatever IS canonical. |

Option 3 wins on the only criterion that matters at this point: **the recurrence cost is real**. Three iterations of patches, three teams of agent time, one shipped-broken deploy currently on `main` blocking the next bug-hunt iteration. The total LOC across all three patches plus their tests is comfortably more than option 3's diff. Option 3 also removes lines (v2's subscriber, v1's `paintCash(value)` callsite churn, the sandbox that v2's spec.js needs).

The bar for "small patch is sufficient" was already high after v2; v2 made it higher by demonstrating that the small-patch instinct is what put us here. **Default to the architecturally cleaner option.**

## Files

- **`dashboard/trade-ticket.js`** (modify): Replace `paintCash(cash)` signature with `repaintCash()` reader. Add `getCanonicalCash()` private. Update both `paintCash` callsites in `openTradeTicket`'s mirror block (`:216` `onOpen`, `:226` `onUpdate`) — both become `repaintCash()`. Drop v2 always-on subscriber block (`:114-147`) entirely. `fetchCashBalance` (`:282-316`) keeps its current shape but transitions its terminal write to call `repaintCash()` (mutates `currentSession.portfolio_metrics.cash` from `result.data.cash` first, then triggers repaint). Net: ~30 LOC net change, mostly reductions; `paintCash` callsites simplify because the value-passing argument disappears.
- **`dashboard/event-contract.md`** (modify): Update the `portfolio:updated` Subscribers section to remove the always-on convention bullet (`:140`). Add a new "Render-on-read pattern" note under `portfolio:updated` documenting that the Trade Ticket panel uses bus events as repaint triggers and never reads `payload.cash` directly. Cross-link to a new decision record.
- **`docs/decisions/trade-ticket-render-on-read.md`** (new): One-page decision record explaining the render-on-read pattern, why v1/v2 failed, the canonical-store contract (`currentSession.portfolio_metrics.cash` is the single source; bus cache is the cold-open backstop), and the policy that bus payloads carry data but the panel's reader path never trusts them.
- **`tests/dashboard/trade-ticket-render-on-read.spec.js`** (new, ~120 LOC, node --test): Unit tests for `getCanonicalCash()` precedence, `repaintCash()` no-paint when canonical is undefined, `repaintCash()` no-paint when canonical is NaN, and the contract that publishing `portfolio:updated` with `{ cash: <poison> }` does NOT change the painted text when `currentSession.portfolio_metrics.cash` is set to a different value.
- **`tests/dashboard/trade-ticket-panel-mirror.spec.js`** (delete): v2's regression spec is obsolete — the contract it encoded ("always-on subscriber paints on every publish") is the contract v3 inverts. Replaced by the render-on-read spec above.
- **`tests/e2e/journey-05-trade.spec.ts`** (modify): The existing assertion at `:447-463` (poison cash after close) stays untouched and continues to gate the contract. Add ONE new closed-panel assertion mirroring the iter 7b36 retest envelope: after `submitTradeTicket()` returns success and `closeTradeTicket()` fires, the next `openTradeTicket()` within 3s MUST show `#tt-cash-balance` text equal to `#cash-value` text within $0.01. This catches the failure mode iter 7b36 surfaced (panel rotting between close and next open) without coupling to subscriber lifetime.

## Validation

**Required green:**
- `tests/e2e/journey-05-trade.spec.ts:389` — "available cash header never shows -- across open/close cycles" — MUST pass. The poison-publish at `:456` lands on a subscriber that calls `repaintCash()` which reads canonical (unchanged) and writes the same text — `expect(afterPoison).toBe(beforePoison)` holds.
- iter 7b36 retest envelope — fresh $100k session, MARKET BUY 10 SPY, wait for `order:filled` SSE, read `#tt-cash-balance.textContent` after `closeTradeTicket()` and `openTradeTicket()`. Strictly less than 100000. Equals `#cash-value` within $0.01. Both within 3s of `order:filled`. Zero console errors.
- All four existing journey-05 trade specs (open/close cycle, cold-open `--`, mid-fill stale, post-fill re-open) — MUST continue passing.

**New regression (`tests/dashboard/trade-ticket-render-on-read.spec.js`):**
- `getCanonicalCash()` returns `currentSession.portfolio_metrics.cash` when set; falls back to `bus.getLastPublished('portfolio:updated').cash` when session is empty; returns `undefined` when both are empty.
- `repaintCash()` writes nothing when `getCanonicalCash()` returns `undefined`.
- `repaintCash()` writes nothing when canonical is `NaN`.
- `bus.publish('portfolio:updated', { cash: 999999 })` while `currentSession.portfolio_metrics.cash === 94846.45` → after the panel's `onUpdate` runs, `#tt-cash-balance.textContent === '$94,846.45'`. Poison ignored.
- `bus.publish('portfolio:updated', { cash: 88000 })` while `currentSession.portfolio_metrics.cash === 88000` → `repaintCash()` writes `$88,000.00`. (Trivial: canonical and bus agree.)

## Deploy-blocked handling

**Revert v2 first.** Set `revert_v2_required: true`.

Justification: v2's direction is fundamentally wrong, not incomplete. The v2 patch teaches the panel to trust arbitrary publishers; v3 teaches the panel to trust only the canonical store. Stacking v3 on v2 leaves a regressed always-on subscriber in `dashboard/trade-ticket.js:141-147` whose existence the v3 design specifically forbids — even if v3 makes `paintCash` ignore the payload, the subscriber and its sandbox spec at `tests/dashboard/trade-ticket-panel-mirror.spec.js` would still need to be removed for the diff to be coherent. Reverting v2 first gives a clean diff against the last green deploy (`a34ac9d`):

1. `git revert 1cd2b5b` (the v2 merge commit) — undoes `dashboard/trade-ticket.js:114-147`, `dashboard/event-contract.md:140`, and `tests/dashboard/trade-ticket-panel-mirror.spec.js`. journey-05:389 returns to passing on the post-revert HEAD.
2. Apply v3 on top of the reverted base.

Net deploy diff is "iter 7b36's `109686c` plus v3" against `a34ac9d`. Cleaner to read, cleaner to revert if v3 itself regresses.

There is no compelling argument for stacking. v2's only retained behaviour worth preserving (closed-panel cash freshness via `currentSession.portfolio_metrics.cash` mutation) is already provided by `109686c`'s post-submit IIFE — that part is untouched by the revert.

## Break-even

Ledger trace on this surface:
- iter `20260428T031818Z2efa` (v0.1) — initial CustomEvent fan-out patch, `eee6914`. ~1h.
- iter `20260429T052717Z1a13` (v0.2) — cold-open `--` patch, `f8a8365`. ~1h.
- iter `20260429T232205Z17ff` (v0.3) — mid-fill SSE-mirror + shape-drift patch, `086c558`. ~1h.
- v1 refactor (extracted `dialogStateMirror`) — `efdd44316`, 2026-04-30. Effective for one bug-hunt iteration.
- iter `20260501T234103Z1a49` Team B — SSE `orders` post-fill refetch+republish, `3a2bf46`. ~1h.
- iter `20260502T142726Z7b36` Team A — submit-time post-fill refetch+republish, `109686c`. ~1h. **Patch-ineffective at Phase 5.5.**
- v2 refactor (always-on subscriber) — `c712d98`, merged `1cd2b5b`, 2026-05-02. **Regressed at deploy gate (run 25263179874).**

7+ patches across 7 iterations on the same `<span>`. Average cost per recurrence ~1h agent time + ~30min review/triage; v2 also burned a full deploy + Phase 5.5 retest cycle. Status quo is "this surface generates ~1 patch per bug-hunt iteration, sometimes more."

**Predicted next failure mode without v3:** the gate keeps re-tripping. Either we ship a third small patch (v2.5) layering a source predicate or a dedicated event — same shape as v2, will regress on a different surprising publisher within 1-2 iterations — or we re-attempt v2 after the existing test gets weakened, which is a step backward. Without render-on-read, this `<span>` will produce a fourth recurrence.

**v3 cost:** ~30 LOC net in `trade-ticket.js`, ~5 LOC in `event-contract.md`, ~50 LOC in the new decision record, ~120 LOC in the new unit spec, deletion of the v2 spec, ~25 LOC new e2e assertion. Total ~3-4h agent time including the revert and the validation pass.

**Break-even:** v3 pays back on the FIRST avoided recurrence. Given the surface has produced 6+ patches and 1 regressed refactor in 5 days, a 4th recurrence under any non-render-on-read v3 is high-probability within 1-2 iterations. v3's diff is smaller than the cumulative cost of "one more patch" plus the eventual retry.

## Risks

**Risk 1 — `currentSession.portfolio_metrics.cash` not updated atomically with bus publish on some path.** Audited in `app.js`: SSE `portfolio` handler mutates then publishes (`:1456-1475`); SSE `orders` post-fill IIFE mutates then publishes (`:1591-1608`); `submitTradeTicket` post-submit IIFE mutates then publishes (`:460-484`). All three publishers are atomic-mutate-then-publish. The v3 contract is "any new publisher of `portfolio:updated` MUST mutate `currentSession.portfolio_metrics.cash` before publishing." This must be added as a bullet to `event-contract.md` and to the decision record. Implementer must grep `bus.publish.*portfolio:updated` and verify each call site before claiming done.

**Risk 2 — `currentSession` is null at first paint.** v1's `primeFromCache` already handles this (returns `undefined`, mirror falls through). `repaintCash()` returns silently when `getCanonicalCash()` is undefined. The DOM keeps its initial `--` until either `currentSession` populates or the bus cache primes. The cold-open path is unchanged from v1.

**Risk 3 — `repaintCash` called from a closed panel paints the persistent DOM with stale-but-canonical cash.** This is a NON-issue: the canonical store mutates atomically with every publisher we care about, so "stale-but-canonical" is "fresh as of the last publish." The panel-DOM-rot from iter 7b36 was caused by the panel having NO subscriber when the publish landed; v3 keeps a subscriber alive (the v1 mirror, on open) AND mutates the canonical store on every publisher path so the next open paints fresh. Closed-panel reads of the persistent DOM (e.g., the journey-05 test reading `#tt-cash-balance.textContent` directly without re-opening) will see the value as of the last open's `repaintCash()` call, which is at most one open/close cycle stale and the next open repaints. If the test reads BEFORE re-opening, it gets `beforePoison === afterPoison`, which is the contract.

**Risk 4 — A future read-only consumer outside the panel reads `#tt-cash-balance.textContent` directly and is bothered by the "stale until next open" behaviour.** Currently no such consumer exists; the journey-05 poison test reads the DOM specifically to verify the inverse contract. If a future consumer needs always-fresh `#tt-cash-balance`, the right answer is for that consumer to read `getCanonicalCash()` (or `currentSession.portfolio_metrics.cash`) directly, not to hook into the panel's DOM. Document this in the decision record.

**Risk 5 — The decision record drift.** Implementer must write `docs/decisions/trade-ticket-render-on-read.md` in the same commit as the code change (CLAUDE.md doc-touch rule). Audit by `grep -l render-on-read docs/decisions/` before merge.

## Out of scope

- Generalising render-on-read into a new module (`renderOnRead.js`). Single consumer; defer until a second instance appears, same break-even logic v1 used (3 instances before extraction).
- Removing the v1 `dialogStateMirror`. Still owns open-time prime, refetch, refuseClobber for the panel's open lifetime. v3 simplifies its handlers' bodies but keeps the abstraction.
- Auditing or migrating other slide-out panels. The trade ticket is the only persistent-DOM bus-mirror surface today; if a second one appears (sticky positions sidebar, always-visible mini-card), revisit then.
- Server contract. Publishers (`app.js:1442-1478` SSE portfolio, `:1572-1612` SSE orders post-fill, `trade-ticket.js:443-494` post-submit) are correct — they all atomically mutate `currentSession.portfolio_metrics` before publishing. v3 codifies that pre-existing pattern as a contract; it does not change any publisher.


---

_Iteration note 2026-05-06 (bug-hunt `20260506T061637Z6594`):_ this iteration shipped one new `dashboard-state-sync` finding (`plugin-health-dot-unhealthy-falls-to-unknown`) — predicate drift on the canonical `PluginHealthStatus` enum across `dashboard/app.js` and `dashboard/settings.js`. The bug is on a different surface than this refactor (predicate-vs-server-enum vocabulary skew, not the persistent-DOM / chart-Y-axis / config-propagation / overflow-contract surfaces). No verdict change implied for this refactor; cross-reference for category-recurrence tracking only. Ledger entry: `docs/bug-hunt/ledger.jsonl` (line 65).
