---
status: shipped
shipped_at: 2026-04-30
shipped_in: efdd44316fcd2c21d7d024301abd24ed82c55dd3
category: dashboard-state-sync
drafted: 2026-04-29
drafted_in: 20260429T232205Z17ff
instances: 3
iterations: [20260428T031818Z2efa, 20260429T052717Z1a13, 20260429T232205Z17ff]
related_ledger_entries: [trade-ticket-stale-cash, trade-ticket-cash-dash, trade-ticket-cash-stale-during-fill]
verdict: effective
verdict_set_at: 2026-04-30
verdict_set_in: 20260430T222711Z3666
verdict_evidence: "Zero trade-ticket-state-sync findings in this iteration's triage (the open-then-subscribe + on-open prime + shape-drift fallback patterns held across the blind walkthrough)."
---

# Refactor — Trade Ticket dialog state-sync (open-then-subscribe + on-open prime + shape-drift fallback)

## Why we're here

Three real-broken instances of the same shape across three bug-hunt iterations, all on the Trade Ticket "Available Cash" header:

1. `trade-ticket-stale-cash` — iter `20260428T031818Z2efa`, commit `8838ff1`. After a filled order, the dashboard Overview correctly updated Cash but the open Trade Ticket dialog still showed the pre-fill value. Patched by broadcasting a `CustomEvent('finlet:portfolio-update', { detail })` from the SSE handler in `app.js` and adding a paired listener in `trade-ticket.js` to re-render on the broadcast.
2. `trade-ticket-cash-dash` — iter `20260429T052717Z1a13`, commit `f8a8365`. The header stuck on `--` on first open even when `currentSession.portfolio_metrics.cash` was a known value. Patched by adding `seedCashFromSessionSummary()` (synchronous read on open before any await yields), moving the bus subscription BEFORE the seed paint, and making `fetchCashBalance()` defensive (refuse to clobber a known-good value with `--` on fetch failure).
3. `trade-ticket-cash-stale-during-fill` — iter `20260429T232205Z17ff`, commit `086c558`. After a BUY 10 SPY MARKET filled at $545.15, the dashboard Overview updated Cash to $94,548.49 but the still-open Trade Ticket dialog held `$100,000.00`. Patched by mirroring `cash` and `total_value` onto `currentSession.portfolio_metrics` in the SSE handler so `seedCashFromSessionSummary()` reads the post-fill value within `_PUSH_INTERVAL`, AND making the bus-subscriber inside `trade-ticket.js` fall back to `fetchCashBalance()` when the published payload's shape drifts.

Same shape: a dialog opens, subscribes to `portfolio:updated` on the bus, and renders. The "open → subscribe → render" lifecycle has gaps that allow stale state to flash before, during, or after fills:
- **Pre-publish gap:** the most recent publish happened before the dialog subscribed; subscriber attaches after publish, no replay.
- **Mid-fill gap:** SSE handler publishes a payload but the dialog's read of `currentSession.portfolio_metrics` returns yesterday's snapshot because the SSE handler updated `currentSession.portfolio` but not `currentSession.portfolio_metrics`.
- **Shape-drift gap:** the published payload's field shape differs from what the handler expects (e.g., consumer reads `payload.cash` but publisher emitted `payload.portfolio.cash`); handler renders nothing useful and keeps the placeholder.
- **Transient-failure gap:** the on-open `fetchCashBalance()` errors out (network blip, 502, race); the dialog clobbers a known-good value with `--`.

The patches keep accumulating per-finding workarounds; the convention is the gap.

## Root cause

Every dialog that subscribes to a bus event has an "open-then-subscribe" race window. Each fix layer (open-time fetch, shape-drift fallback, SSE-side mirror) closes one specific gap. There's no general "dialog snapshot" convention that says: "subscribe to event X, prime with last value on open, refetch on shape mismatch, refuse to clobber on transient failure, unsubscribe on close." Authors of new dialogs that mirror live state are forced to invent these protections from scratch — and the inventory grows until the convention is extracted.

The dashboard event-bus refactor (commit `db7f637`, 2026-04-28) gave us the publisher/subscriber primitive (`window.finletBus.subscribe(event, handler) → unsubscribe`, `bus.publish(event, payload)`) but stopped short of the on-open prime + shape-drift fallback policy. That's the gap this refactor fills.

## Refactor scope

One team. One worktree. ~2-3 hours of agent work. Smaller than modal-stacking — the surface area is two consumer files plus one new module.

### Files touched

- **New: `dashboard/dialog-state-mirror.js`** — single module exporting:
  ```js
  // Subscribe to a bus event, prime with last published value on open,
  // refetch on shape-drift, unsubscribe on close.
  // Returns a { close } handle.
  dialogStateMirror({
    eventName,        // e.g. 'portfolio:updated'
    onOpen,           // ({ initialState, refetch }) => void — paint with prime; refetch is a function the consumer calls when payload shape drifts
    onUpdate,         // (payload, { refetch }) => void — paint on bus publish
    onClose,          // () => void — optional cleanup hook
    primeFromCache,   // () => initialState | undefined — read from `currentSession.portfolio_metrics` or wherever the canonical "already-known state" lives
    refetch,          // () => Promise<initialState> — REST call when bus payload shape doesn't match what onUpdate expects
    refuseClobber,    // (currentValue, nextValue) => boolean — return true if nextValue should NOT replace currentValue (e.g., '--' should never replace '$X')
  })
  ```
  Internally maintains a `lastPublished` cache keyed by `eventName` so a dialog opened AFTER the most recent publish gets the latest value synchronously. Subscribes to the bus before calling `onOpen` so a concurrent publish during the open() lifecycle lands on the live handler.
- **Modified: `dashboard/trade-ticket.js`** — rewrite to consume `dialogStateMirror`. Drop the bespoke `seedCashFromSessionSummary()` + `fetchCashBalance()` orchestration; the new module handles all three gaps. Net LOC change is roughly -40 / +20.
- **Modified: `dashboard/api-utils.js`** — add `getLastPublished(eventName)` if not already present. The bus would expose this so the mirror module can read the most recent payload synchronously on open.
- **Modified: `dashboard/event-contract.md`** — document the `lastPublished` cache invariant (bus retains the most recent payload per event for synchronous-on-open consumers).

### File conflict table

| File | Touched by |
|------|-----------|
| `dashboard/dialog-state-mirror.js` (new) | this refactor |
| `dashboard/trade-ticket.js` | this refactor (rewrite to consume) |
| `dashboard/api-utils.js` | this refactor (add `getLastPublished`) |
| `dashboard/event-contract.md` | this refactor |

No conflict with `modal-stacking.md` queue doc (different files). No conflict with `dirty-state-tracker.md` (different files; dirty-state-tracker is about form snapshot timing, not bus-subscriber dialogs).

## Validation

- **Unit:** `dialogStateMirror` opened with no prior publish → `onOpen` receives `initialState: undefined`. `dialogStateMirror` opened after a publish → `onOpen` receives the cached payload synchronously.
- **Unit:** Bus publishes `{cash: 95000}` while dialog is open → `onUpdate` fires with the new payload.
- **Unit:** `refuseClobber('$100000', '--')` returns `true` → mirror does NOT call `onUpdate` with the placeholder; cache retains the prior value.
- **Unit:** Shape-drift simulation — publish `{portfolio: {cash: 95000}}` when consumer expects `{cash}` → `onUpdate` calls `refetch`, mirror primes the next paint with the REST-fetched state.
- **Existing journey-05 tests** — must continue to pass without modification. The Trade Ticket open/close/reopen × 3 spec, the BUY-fill-then-reopen spec, and the open-during-fill spec all exercise the same surface the refactor migrates.
- **New property test:** `tests/dashboard/dialog-state-mirror.spec.js` (node --test) covering: open-before-subscribe, open-after-publish, shape-drift triggers refetch, refuseClobber prevents placeholder paint, close unsubscribes (no leaked listeners).

## Break-even

Status quo: 3 instances across 3 iterations, ~1 hour of patch + test work per instance. The 4th instance is a near-certainty under the current convention because every new dialog (e.g., a future "Add Funds" or "Set Leverage" panel) inherits the same shape with no scaffolding. Refactor pays back on the 4th instance — by then the convention has prevented one full bug-hunt loop's worth of work, and net LOC is lower because each consumer drops its bespoke orchestration.

## Reversal path

Single merge SHA. `dialog-state-mirror.js` is one file (~150 LOC); the trade-ticket migration is mechanical (replace the open() body's seed/subscribe/fetch dance with a single `dialogStateMirror({...})` call). Revert is ~20 minutes if the new module's contract turns out to be wrong; downstream consumers fall back to their bespoke flows.

## Out of scope

- **Non-bus state.** Dialogs that read REST state once at open and don't subscribe to a bus event (e.g., the order-detail view that reads `/orders/{oid}` and never updates) — separate concern. Their failure mode is "stale on long-open," not "open-then-subscribe race."
- **Modal stacking.** The modal-controller (commit `db7f637`) owns z-order and pointer-events. This refactor doesn't touch that surface — it composes ON TOP of the modal-controller (the dialog still opens via `modal.open(id)`).
- **SSE replay / connection-loss recovery.** Bus is the abstraction; the SSE-to-bus bridge is upstream and out of scope. If the SSE drops and the bus stops publishing, this module's last-published cache goes stale — but that's a transport-layer concern owned by `dashboard/app.js`'s SSE handler.
- **Form-dirty interaction.** Dialogs that contain editable forms (e.g., the Create Session modal) interact with `dashboard/form-dirty-tracker.js` separately. The mirror module is for read-only live state; editable form state is the dirty-tracker's domain.

## Verdict (pending — to be set by next bug-hunt iteration)

Refactor not yet shipped. Per the refactor-gate convention, the next bug-hunt iteration after this refactor merges will retest the three real-broken instances:

- Trade Ticket "Available Cash" stale after fill (recurrence shape from `20260428T031818Z2efa` — open dialog, fill order, dialog header reflects post-fill cash)
- Trade Ticket "Available Cash" stuck on `--` on first open (recurrence shape from `20260429T052717Z1a13` — open dialog, header shows `$X` not `--` synchronously)
- Trade Ticket "Available Cash" stale during fill while dialog stays open (recurrence shape from `20260429T232205Z17ff` — open dialog, BUY MARKET, dialog header tracks fill without close-and-reopen)

If all three pass cleanly with no new failures of the same shape, mark `verdict: effective`. If any of the same shape recurs, mark `incomplete` or `regressed`.


---

_Iteration note 2026-05-06 (bug-hunt `20260506T061637Z6594`):_ this iteration shipped one new `dashboard-state-sync` finding (`plugin-health-dot-unhealthy-falls-to-unknown`) — predicate drift on the canonical `PluginHealthStatus` enum across `dashboard/app.js` and `dashboard/settings.js`. The bug is on a different surface than this refactor (predicate-vs-server-enum vocabulary skew, not the persistent-DOM / chart-Y-axis / config-propagation / overflow-contract surfaces). No verdict change implied for this refactor; cross-reference for category-recurrence tracking only. Ledger entry: `docs/bug-hunt/ledger.jsonl` (line 65).
