---
category: onboarding-checklist
status: shipped
shipped: 2026-04-30
shipped_in: 40368b2
instances: 4
iterations: 2
latest_instance: 20260428T031818Z2efa
drafted: 2026-04-30
related_ledger_entries: [strategy-checklist-dead-div, strategy-item-opens-leaderboard, onboarding-wizard-form-drift, checklist-no-advance-after-fill]
verdict: incomplete
verdict_set_at: 2026-04-30
verdict_set_in: 20260430T222711Z3666
verdict_evidence: "Finding 5 (checklist-rest-cli-no-advance) recurred this iteration with same_root_cause_as: checklist-no-advance-after-fill. Refactor 40368b2 introduced CHECKLIST_STEPS / WIZARD_STEPS registries and a dispatchChecklistAction() helper, closing the wizard-flow gaps (strategy-checklist-dead-div, strategy-item-opens-leaderboard, onboarding-wizard-form-drift, checklist-no-advance-after-fill). The session-step trigger remained pinned to session:switched, which was only published from the UI modal create path — sessions created via REST API or CLI showed up in fetchSessions() but never published the trigger. Team D (commit 91922c7) closed the gap by moving the publish into selectSession() (the canonical activation site every flow funnels through). Pattern is sound; original scope did not cover non-UI session-create paths."
verdict_v2: effective
verdict_v2_set_at: 2026-05-05
verdict_v2_set_in: convention-enforcement-2026-05-05
verdict_v2_evidence: "Latest onboarding-checklist ledger entry is `checklist-set-up-profile-auto-complete` (iter 20260501T234103Z1a49, commit 4924948 — Team D introduced the `profile:saved` bus event gated on display_name+bio non-empty); follow-on commit 076109c (close-patch-ineffective-2026-05-02 Team B) deleted the second `markStepComplete('profile')` reach-in for existing users at `dashboard/onboarding.js:383-389`. The in-code comment at lines 383-389 documents both reach-ins as closed: the registry-driven `profile:saved` subscriber is the only legal advance site. Zero new onboarding-checklist entries in the ledger across iterations 20260502T142726Z7b36, 20260502T211937Z7ddd, 20260503T030227Z2009, 20260503T195318Z43db, 20260503T230405Z2601, and 20260504T165106Z1ab2 — the cluster is closed."
verdict_v3: incomplete
verdict_v3_set_at: 2026-05-06
verdict_v3_set_in: 20260506T154910Z0b41
verdict_v3_evidence: "Iteration 20260506T154910Z0b41 produced a new onboarding-checklist instance (`onboarding-wizard-heading-not-repainted`, finding closed by Team A merge `efdbba1`): wizard step heading stayed on the prior step's title because `showStep()` updated dots, lines, and the Next button label from `WIZARD_STEPS` but never repainted the active step's h2. The refactor was correct as drafted (it converged step CONTENT data onto the registry — title, subtitle, body, nextLabel, advanceTrigger), but it did NOT converge the RENDERER onto the registry — `showStep()` reads `wizardStep.nextLabel` on every transition but did not read `wizardStep.title` until this iteration's fix. Step 3's bespoke `populateStep3FromRegistry()` masked the gap (only step 3 had a special-cased title repaint path), so the 1→2 transition was the visible failure mode. Refactor scope was 'data drift on step content'; the under-scope is 'renderer drift on the same data the registry now owns'. The fix was 2-3 lines inside `showStep()` reading `WIZARD_STEPS[step-1].title` and writing via `textContent`. The pattern is sound; the next refactor pass should add a renderer-completeness audit step (every registry field must be read on every transition function, OR documented as init-only with a comment)."
verdict_v4: effective_for_user
verdict_v4_set_at: 2026-05-07
verdict_v4_set_in: bug-hunt-handoff-2026-05-07-path-a
verdict_v4_evidence: "Iteration 20260506T185234Z542e produced finding `checklist-analysis-label-mismatch` (retest evidence in `pending_recurrences.jsonl`): the user-visible label was correctly relabeled from 'Run first analysis' to 'Place first trade' (Team C commit `2c3989d`), but the retest charter expected DECOUPLING (split the registry key from the trigger so the internal `key: 'analysis'` could become `key: 'trade'` while preserving the `trigger: 'order:filled'`). The decoupling was not done — `CHECKLIST_STEPS[2]` still has `key: 'analysis'`. Per the all-must-pass retest contract this counts as a fail, but the user-experienced bug (misleading 'Run first analysis' copy) IS fixed. The retest charter was over-specified — decoupling internal-key-vs-trigger is not part of the user-facing semantics. Accept the bug-as-experienced bar; do NOT plan a v4 refactor for this finding alone. If the registry-key-vs-trigger split becomes load-bearing later (e.g., a future tier adds a 'demo trade' affordance that publishes `order:filled` but should NOT advance the trade-checklist row), reopen with a fresh scope doc. For now: cluster remains 'effective at user layer' from v2 (2026-05-05) onward, with one charter-strict miss that does not warrant a code change. Pending entry moved to `pending_recurrences.resolved.jsonl`. Decision recorded in handoff `docs/bug-hunt/HANDOFF.md` (Action plan step 5, recommendation Path A: accept bug-as-experienced)."
---

# Refactor — Onboarding checklist (state machine + canonical-action registry + persona-step3 step contract)

## Why we're here

Four real-broken instances of the same shape across two bug-hunt iterations, all on the dashboard "Getting Started" checklist + onboarding wizard:

1. `strategy-checklist-dead-div` — iter `20260428T013300Z6e79`, commit `4908f98`. The "Save first strategy" checklist row was a non-interactive `<div>` with no click handler — a documented affordance with no action wired. Patched indirectly by exporting `openLeaderboardSubmitModal` to `window` (`dashboard/leaderboard-submit.js:441`) and removing a dead Sentry CDN tag from `dashboard/index.html:13,588`. The actual click-wiring was deferred to the next iteration.
2. `strategy-item-opens-leaderboard` — iter `20260428T031818Z2efa`, commit `6c256fb` (branch tip `dd3377e`). The previous iteration's "fix" wired the row to open the Submit-to-Leaderboard modal — wrong action, wrong surface. The leaderboard modal already has its own CTA at `#btn-submit-leaderboard` and it does NOT advance the `strategy` step counter. Patched by relabeling the row to "Learn how to build a strategy", redirecting to `agent-guide.html#strategies` (with a new `id="strategies"` anchor added to `dashboard/agent-guide.html:285`), and calling `markStepComplete('strategy')` directly on click (`dashboard/onboarding.js:743-757`). A `TODO(post-launch)` was inlined at `onboarding.js:34-40` to wire to a real `strategy:saved` event when the strategy product surface ships.
3. `onboarding-wizard-form-drift` — iter `20260428T031818Z2efa`, commit `6c256fb`. The wizard's Step 2 carried a bespoke 4-input session form (`name`, `start`, `capital`, `universe`) that did not match the canonical "New Session" dialog opened by the top-bar `#btn-new-session` button (which has a 3-template-card picker: Conservative ETF / Tech Growth / Custom). Two code paths claimed the same job with different contracts. Patched by deleting the wizard's inline form + `handleSessionCreate()` body (~80 LOC removed at `onboarding.js`), exposing `window.openCreateSessionModal` (`dashboard/app.js:1207-1212`), and replacing the Step 2 body with a single "Open Session Creator" button (`onboarding.js:302-308`) that delegates to the canonical modal.
4. `checklist-no-advance-after-fill` — iter `20260428T031818Z2efa`, commit `6c256fb`. The "Run first analysis" row never advanced after a trade filled — no SSE-side hook fired `markStepComplete('analysis')`. Patched by adding a zero-to-positive `filledCount` transition guard inside the SSE `orders` handler (`dashboard/app.js:1444-1455` in the original patch; later refactored at `app.js:1498-1525` to publish `order:filled` on the bus, after the `7085ea7` event-bus migration).

Same shape across all four: a documented step in the checklist or wizard fails to advance because the affordance, the action, and the persisted state are wired by hand at three different sites — and any one of the three drifts independently. Two of the four findings landed in the same bug-hunt iteration. The third and fourth findings landed in that same iteration alongside the second. Three out of four were one team-day apart, which is the structural-blind-spot signature, not the slow-drip signature.

The intervening event-bus refactor (`7085ea7`, "Team B: feat(dashboard): onboarding state machine on event bus") **partly** addressed the underlying drift by introducing `STEP_TRIGGERS` (`dashboard/onboarding.js:42-47`) — a declarative table mapping each checklist key to a bus event name. That refactor moved the analysis-step wiring from a reach-in (`window.finletOnboarding.markStepComplete('analysis')` from inside the SSE handler) to a bus subscriber (`finletBus.subscribe('order:filled', ...)`). It is a real improvement and the right direction. But it stopped short of three things:

- It did not extract a "checklist row contract" (label + action + step-key + completion-event). Each row is still hand-wired with a bespoke click handler and a hand-edited HTML literal.
- It did not formalize the "Step N action contract" for the wizard. Step 2 happens to delegate to a canonical modal; Step 3 still hand-builds persona-specific action cards inside `populateStep3()` with no shared shape.
- It did not address the `strategy` step's missing trigger event — that step is `null` in `STEP_TRIGGERS` (manual click only), with a TODO comment that has lived through two iterations.

A 5th instance is the near-certainty. The next time someone adds a checklist row, a wizard step, or a new persona path, the same drift surfaces.

## Root cause

Three separate registries claim authority over "what does the user do next":

1. **Step state** — `state.steps` in `localStorage` (`onboarding.js:54-59`), keys: `profile`, `session`, `analysis`, `strategy`. Persisted as a flat boolean map.
2. **Step triggers** — `STEP_TRIGGERS` constant (`onboarding.js:42-47`), maps step key → bus event name OR `null` (manual). Subscriber wiring at `wireBusSubscribers()` (`onboarding.js:172-196`).
3. **Step affordance** — the HTML rendered by `buildChecklistItem(key, label, done)` (`onboarding.js:761-769`) and the wizard's per-step DOM literal in `buildWizardHTML()` (`onboarding.js:257-328`). Each row's click handler is wired separately inside `renderChecklist()` (`onboarding.js:730-758`).

All three lists are hand-maintained:

- `state.steps.strategy` exists since the file was created (commit `21e3629`), but `STEP_TRIGGERS.strategy = null` and the row's click handler is the bespoke `agent-guide.html` redirect at `onboarding.js:743-757`. Three sites, all hand-edited, and the contract between them is "match by string key + remember to wire click."
- `state.steps.analysis` is wired declaratively via `STEP_TRIGGERS.analysis = 'order:filled'` — but only because Team B did that one specific migration in `7085ea7`. The wizard's Step 3 persona action cards (test trade, agent setup, clock advance) build their own DOM with `populateStep3()` (`onboarding.js:411+`), not via `buildChecklistItem`, and not via `STEP_TRIGGERS`. Adding a 4th persona means hand-editing `PERSONAS` (`onboarding.js:89-114`) AND hand-editing `populateStep3` AND deciding by hand whether to add a new step-key.
- The "documented affordance vs. actual action" gap (instances 1 and 2) is a specific case of "no source of truth for what each step does." When `21e3629` shipped, the row label said "Save first strategy" but no click handler existed. When `4908f98` shipped, the click was added but pointed at the wrong surface (Leaderboard, not strategy guidance). When `6c256fb` shipped, the row was relabeled to match the action — but the action is still a stub redirect to a guide page with no real `strategy:saved` event. Each iteration patched one site without enforcing the other two.
- The "two session-creation surfaces" gap (instance 3) is the same shape one level up. The wizard's Step 2 had its own form because Step 2's HTML literal in `buildWizardHTML()` was hand-authored before `app.js`'s canonical Create Session modal existed. Both surfaces existed in production simultaneously for ~15 days before the bug-hunt agent walked the wizard end-to-end.
- The "fill never advances" gap (instance 4) is what prompted Team B's `7085ea7` bus refactor. That refactor closed THIS specific gap (analysis step advances on `order:filled`) but did not extract the convention so the next step (`strategy`) inherits it for free.

There is no single "checklist row" or "wizard step" data structure that owns label + click action + completion-event + persistence-key. Each row is reassembled from three places every time.

## Refactor scope

One team. One worktree. ~3-4 hours of agent work. Smaller than `trusted-types` — the surface area is one file (`dashboard/onboarding.js`) with auxiliary publisher additions and one new test file. No new modules.

### Files touched

- **Modified: `dashboard/onboarding.js`** — Replace the three hand-maintained registries (`state.steps`, `STEP_TRIGGERS`, `buildChecklistItem` callers) with a single `CHECKLIST_STEPS` registry of the form:

  ```js
  const CHECKLIST_STEPS = [
    {
      key: 'profile',
      label: 'Set up profile',
      trigger: null,                    // manual — flipped during wizard Step 1 advance
      action: null,                     // no row click — wizard owns this
    },
    {
      key: 'session',
      label: 'Create first session',
      trigger: 'session:switched',      // bus event — auto-advance via subscriber
      action: { type: 'open-modal', target: 'create-session' },
    },
    {
      key: 'analysis',
      label: 'Run first analysis',
      trigger: 'order:filled',
      action: { type: 'open-modal', target: 'trade-ticket' },
    },
    {
      key: 'strategy',
      label: 'Learn how to build a strategy',
      trigger: 'strategy:saved',        // post-launch event; null-tolerant subscriber
      action: { type: 'navigate', href: 'agent-guide.html#strategies' },
    },
  ];
  ```

  Each entry's `action` is dispatched through a small `dispatchChecklistAction(action)` helper that knows three action types (`open-modal`, `navigate`, `noop`). The helper resolves `open-modal` targets through a registry map (`{ 'create-session': () => window.openCreateSessionModal?.(), 'trade-ticket': () => window.openTradeTicket?.() }`) — adding a new modal target is one line.

  Net behavior is identical to today on all four step keys; what changes is that **adding a 5th step is one entry in `CHECKLIST_STEPS`**, with no edits to `state.steps` defaults (derived from the registry), no edits to `STEP_TRIGGERS` (folded in), and no bespoke click handler in `renderChecklist()` (folded into the dispatcher).

- **Modified: `dashboard/onboarding.js`** — Extract a `WIZARD_STEPS` registry for the 3-step wizard. Same shape as `CHECKLIST_STEPS` but with wizard-specific fields (`title`, `subtitle`, `body` factory, `advanceTrigger`). Step 2's body factory returns the "Open Session Creator" button + status-line; Step 3's body factory consumes `PERSONAS[selectedPersona].step3Action` and renders the canonical action cards. The `populateStep3` and `buildWizardHTML` literals collapse into `WIZARD_STEPS.map(buildStepDOM)`.

  The wizard's auto-advance logic (currently a special case at `onboarding.js:827-840`: "if step is `session` AND wizard is on Step 2, call `showStep(3)`") becomes a general rule: each `WIZARD_STEPS` entry carries an optional `advanceTrigger` step-key; when `markStepComplete(key)` is called and `key === current-wizard-step.advanceTrigger`, advance the wizard. Step 2's `advanceTrigger` is `'session'`, Step 3's `advanceTrigger` is `'analysis'` (so the wizard auto-completes when the user submits a real first order, not just when they click "Go to Dashboard").

- **Modified: `dashboard/onboarding.js`** — Add a single `STRATEGY_STEP_PUBLISHER` placeholder. The strategy step's trigger is `'strategy:saved'`, but no publisher exists today (the strategy product surface ships post-launch). To preserve current behavior, the row's click handler still calls `markStepComplete('strategy')` directly via the dispatcher (action type `navigate` with a `markOnClick: true` flag). When the strategy surface ships post-launch, removing `markOnClick: true` and adding a `finletBus.publish('strategy:saved', { strategy_id })` call from the strategy module is the entire migration — no checklist edits.

- **Modified: `dashboard/app.js:1498-1525`** — No structural changes. The `order:filled` publisher stays where it is (SSE `orders` handler). Verify only that the publish call is not gated on the onboarding global (it currently is not, post-`7085ea7`).

- **Modified: `dashboard/event-contract.md`** — Document the `strategy:saved` event shape (post-launch placeholder) and document the `onboarding:step-completed` payload's `step` field as a closed enum derived from `CHECKLIST_STEPS[].key`. Add a one-paragraph "Adding a new checklist step" recipe pointing at the registry.

- **Modified: `docs/REMAINING_TASKS.md`** — Update the existing post-launch entry that was added in `7085ea7` ("wire `STEP_TRIGGERS.strategy` to a real `strategy:saved` event") to reflect the new convention: the row in `CHECKLIST_STEPS` already carries `trigger: 'strategy:saved'`; the post-launch task is to PUBLISH the event from the strategy module, not to edit `onboarding.js`.

- **New: `tests/dashboard/onboarding-checklist.spec.js`** (node --test) — fixtures and assertions:
  - `CHECKLIST_STEPS` is the single source of truth: deleting any entry from the array makes the corresponding row disappear from the DOM AND removes the corresponding bus subscription. Adding a new entry creates both.
  - `dispatchChecklistAction({type: 'open-modal', target: 'create-session'})` calls `window.openCreateSessionModal` exactly once.
  - `dispatchChecklistAction({type: 'navigate', href: 'agent-guide.html#strategies', markOnClick: true})` calls `markStepComplete` synchronously before navigation.
  - Wizard Step 2 auto-advance fires when `markStepComplete('session')` is called AND wizard is on Step 2; does NOT fire when wizard is closed; does NOT fire when wizard is on Step 1 or 3.
  - `state.steps` keys exactly match `CHECKLIST_STEPS.map(s => s.key)` after `loadState()` — orphaned keys from older versions get migrated forward, missing keys get defaulted to `false`.

- **New: `tests/playwright/onboarding-end-to-end.spec.js`** — single Playwright spec that walks: load dashboard fresh → wizard appears → pick `Retail` persona → wizard advances to Step 2 → click "Open Session Creator" → canonical Create Session modal appears → submit → wizard advances to Step 3 → click "Test Trade" action card → trade ticket opens → submit BUY 1 SPY MARKET → assert `Run first analysis` row in checklist becomes ticked AND wizard auto-completes → click "Learn how to build a strategy" row → assert navigation to `agent-guide.html#strategies` AND assert checklist row becomes ticked. This is the regression test for all four real-broken instances in one walk.

### File conflict table

| File | Owning team | Touched by | Conflict? |
|------|-------------|-----------|-----------|
| `dashboard/onboarding.js` | dashboard | this refactor (rewrite registries) | **none** — no other in-flight refactor touches this file. The `7085ea7` event-bus migration is already merged. |
| `dashboard/app.js` | dashboard | this refactor (verify-only — no edits to publishers) | **low** — `trade-ticket-state-sync` (shipped, `efdd44316f`) added `getLastPublished` to the bus; that lives in `dashboard/api-utils.js`, not `app.js`. The `app.js` SSE handler was last modified by `trade-ticket-state-sync` (portfolio-metrics mirror at lines 1444-1455) and `7085ea7` (the `order:filled` publish at lines 1498-1525). This refactor reads those publishers but does not modify them. |
| `dashboard/event-contract.md` | dashboard | this refactor (additive — document `strategy:saved` + recipe) | **none** — last touched by `trusted-types` (HTML-safety section, lines 83-89) and `trade-ticket-state-sync` (bus-cache invariant). Different sections. |
| `dashboard/agent-guide.html` | dashboard | this refactor (verify-only — `id="strategies"` anchor at line 285 already shipped in `6c256fb`) | **none** |
| `tests/dashboard/onboarding-checklist.spec.js` (new) | dashboard | this refactor | **none** |
| `tests/playwright/onboarding-end-to-end.spec.js` (new) | dashboard | this refactor | **none** — no conflict with `trusted-types`'s planned `tests/playwright/trusted-types-telemetry.spec.js` (different file). |
| `docs/REMAINING_TASKS.md` | docs | this refactor (one-line update) | **low** — small file, single-line edit; merge conflicts unlikely. |

No conflict with `trade-ticket-state-sync.md` (different files; the trade-ticket refactor introduced `dialogStateMirror` for read-only dialogs that mirror live state, which is orthogonal to the checklist registry). No conflict with `trusted-types.md` (different files; trusted-types broadens the lint regex and adds a runtime reporter, neither touches `onboarding.js`). No conflict with `dirty-state-tracker.md` (different files).

### Cross-team note

`dashboard/agent-guide.html:285` carries the `id="strategies"` anchor that the `strategy` checklist row navigates to. This anchor was added in `6c256fb` and is the canonical landing for "Learn how to build a strategy." Any future docs-team rewrite of `agent-guide.html` must preserve the `id="strategies"` anchor or update `CHECKLIST_STEPS.strategy.action.href` in lockstep. The validation Playwright spec catches this — it asserts the navigation lands on a section visible at the `#strategies` fragment.

## Validation

- **Unit:** Loading `onboarding.js` with a freshly-cleared `localStorage` produces `state.steps` keys exactly equal to `CHECKLIST_STEPS.map(s => s.key)`. Adding a 5th hypothetical entry to the registry (in a test fixture) produces a 5th `state.steps` key and a 5th rendered row.
- **Unit:** Removing the `analysis` entry from `CHECKLIST_STEPS` (in a test fixture) — `wireBusSubscribers` does NOT subscribe to `order:filled`. The DOM does NOT contain a `[data-checklist-key="analysis"]` element. No explicit deletion in three places needed; it's one edit.
- **Unit:** `dispatchChecklistAction({ type: 'open-modal', target: 'create-session' })` invokes `window.openCreateSessionModal` exactly once. With the function undefined, the dispatcher logs a warning and shows a toast (matching today's fallback at `onboarding.js:743-758`).
- **Unit:** Wizard auto-advance — `markStepComplete('session')` while wizard is on Step 2 calls `showStep(3)` exactly once. Repeated calls (idempotent) do NOT re-fire `showStep`.
- **Unit:** State migration — a `localStorage` `state.steps` blob from before the refactor (with `strategy` key, no new keys) loads cleanly via `loadState()` and merges with `CHECKLIST_STEPS` defaults. Old keys not in the new registry are dropped on next save.
- **Playwright:** Full end-to-end walk (the new `onboarding-end-to-end.spec.js`) — wizard appears on fresh load, all four checklist rows tick in order across the persona-retail journey, no console errors, no `securitypolicyviolation` events.
- **Playwright:** Regression for instance 2 (`strategy-item-opens-leaderboard`) — clicking the strategy row navigates to `agent-guide.html#strategies`, NOT the leaderboard modal. Asserted by inspecting the URL after click and asserting no `#leaderboard-submit-modal` element appears with `display: block`.
- **Playwright:** Regression for instance 3 (`onboarding-wizard-form-drift`) — wizard Step 2 contains exactly ONE button ("Open Session Creator") and ZERO `<input>` elements. Clicking the button opens the canonical Create Session modal. Asserts the wizard's Step 2 DOM does not regrow a bespoke form.
- **Playwright:** Regression for instance 4 (`checklist-no-advance-after-fill`) — submit a BUY 1 SPY MARKET that fills, assert the `analysis` row ticks within 4 seconds (one SSE push interval + slack).
- **Existing tests:** All `tests/dashboard/*.spec.js` and `tests/playwright/*.spec.js` continue to pass without modification. The `7085ea7` bus migration's existing tests for `STEP_TRIGGERS` (if any) are migrated to read from `CHECKLIST_STEPS` instead.

## Break-even

Status quo: 4 instances across 2 iterations, ~1 hour of patch + verification per instance, plus the post-7085ea7 partial-fix tax (every patch needs to remember which of three registries to edit). Three of the four instances landed in the SAME bug-hunt iteration, which means this category is acute, not chronic. The 5th instance is near-certain because: (a) the strategy step's trigger event still does not exist and the row's "Learn how to build" stub action is a known TODO; (b) post-launch the strategy product surface will ship and SOMEONE will need to wire `strategy:saved` — under the current convention they'll edit `onboarding.js` `STEP_TRIGGERS`, the row click handler in `renderChecklist`, AND the action map by hand; under the refactor they edit one entry; (c) any new persona path (e.g., a "Beginner" track) requires editing both the wizard's `PERSONAS` table AND the wizard's `populateStep3` AND deciding whether to add a new checklist step — a triple-touch pattern that has already misfired four times.

Refactor cost is ~3-4 hours of agent work (registry extraction + dispatcher + wizard state-machine collapse + new Playwright spec + state-migration test). Pays back on the 5th instance, which is observable today as the open `strategy:saved` TODO. Break-even is effectively immediate because the post-launch strategy-publisher migration alone saves more LOC than the refactor adds.

## Reversal path

Single merge SHA. The registry extraction is mechanical to revert: `CHECKLIST_STEPS` and `WIZARD_STEPS` arrays + their consumers are net ~150 LOC; the equivalent hand-edited surfaces they replace are ~120 LOC across four sites. Revert is ~30 minutes if the dispatcher's contract turns out to be wrong; the post-`7085ea7` baseline (declarative `STEP_TRIGGERS` + per-row click handlers) remains intact in git history and can be cherry-picked back. The new Playwright spec is additive — leaving it in after a revert is harmless.

If the post-launch `strategy:saved` migration ships first and the refactor lands second, the refactor migrates the existing `STEP_TRIGGERS.strategy = 'strategy:saved'` value into `CHECKLIST_STEPS` as a one-line move; no behavior change.

## Out of scope

- **The strategy product surface itself.** This refactor wires the strategy step's `trigger: 'strategy:saved'` and `action: navigate-to-guide`, but it does NOT ship a strategy-builder UI, a `POST /v1/strategies` endpoint, or a `strategy:saved` publisher. Those are the post-launch product spec items in `docs/REMAINING_TASKS.md` and remain owned by product, not this refactor.
- **Server-side onboarding state.** The 4 instances are entirely client-side: `state` lives in `localStorage`, persistence is per-browser, and there is no `/v1/onboarding/progress` REST endpoint. (The marketplace's `finlet/marketplace/onboarding_service.py` is a different feature — developer marketplace onboarding, not the dashboard checklist — and is not in scope here.) If we later decide to persist progress server-side (cross-device sync), that's a separate decision record.
- **Wizard skipping / partial-completion analytics.** The wizard's `dismissWizard` and `state.wizardDismissed` flags are unchanged. Analytics for "% of users who skip Step 2" is post-launch.
- **Persona definition expansion.** Adding a 4th persona (`PERSONAS.beginner` etc.) is enabled by the `WIZARD_STEPS` registry but is not done in this refactor. Any new persona is a one-entry addition to `PERSONAS` + a corresponding `step3Action` in the entry; the registry handles the rendering.
- **Cross-page checklist persistence.** The checklist widget is rendered on `index.html` only. If the user navigates to `agent-guide.html` (via the strategy row), the checklist disappears because the widget script doesn't run there. That's pre-existing behavior, not a regression introduced by this refactor; `state.steps.strategy` still ticks via `markStepComplete('strategy')` at click time before the navigation.
- **Toast-on-step-complete.** The current behavior shows no celebration toast when a step ticks. The bus publishes `onboarding:step-completed` (`onboarding.js:851`) which a future analytics or celebration-UI subscriber can consume; that subscriber is not in scope here.
- **Dialog state mirror integration.** The wizard's Step 2 delegates to the canonical Create Session modal but does NOT use `dialogStateMirror` (`trade-ticket-state-sync` refactor). The Create Session modal is a write-side editable form, not a read-only mirror of live bus state. Form-dirty tracking on that modal is the dirty-state-tracker refactor's domain.

## Verdict (pending — to be set by next bug-hunt iteration)

Refactor not yet shipped. Per the refactor-gate convention, the next bug-hunt iteration after this refactor merges will retest the four real-broken instances:

- "Save first strategy" / "Learn how to build a strategy" row is interactive and ticks the counter (recurrence shape from `20260428T013300Z6e79` and `20260428T031818Z2efa` F2 — load dashboard fresh, click the row, assert it advances AND assert it lands on `agent-guide.html#strategies` rather than the leaderboard modal).
- Wizard Step 2 has no bespoke form — it delegates to the canonical Create Session modal (recurrence shape from `20260428T031818Z2efa` F5 — open the wizard, advance to Step 2, assert exactly one button and zero `<input>` elements; assert clicking it opens `#create-session-modal`).
- "Run first analysis" row ticks after a real fill (recurrence shape from `20260428T031818Z2efa` F6 — open wizard, complete persona + session, submit a BUY 1 SPY MARKET that fills, assert the row ticks within 4s of the SSE push).
- No new "documented affordance with no action" rows — adding a hypothetical 5th entry to `CHECKLIST_STEPS` automatically produces a row with a wired click handler, a bus subscription (if `trigger` is non-null), and a state.steps default. Verified by the unit test fixture, not the live walk.

If all four pass cleanly with no new failures of the same shape (including no new wizard-step-form-drift, no new "row exists but does nothing" rows, and no new "fill happens but counter doesn't advance" cases), mark `verdict: effective`. If any of the same shape recurs, mark `incomplete` or `regressed`.

## Implementation notes

Shipped 2026-04-30 across two merges. Refactor commit `ef9f293` (Team A: step-contract registry + wizard state-machine collapse + recurrence-shape Playwright spec; 6 files, +1471/-282). Test-seed fix-up commit `40368b2` (4 Playwright test seed bugs surfaced in the post-merge gate when the registry-driven wizard enforced contracts the older seed fixtures didn't satisfy; 1 file, +35/-1, test-only — no production code changed). Pre/post-merge gates both green: lint 2/2, unit specs 15/15 + sibling 29/29, pytest 3902 passed (570.74s), Playwright 5 pass / 1 skip (pre-existing fixme). Lesson logged: registry-driven refactors that tighten invariants will surface latent test-seed bugs in the post-merge gate, even when per-merge gates pass cleanly — budget time for surgical test-only fix-ups.

## Recurrence — bug-hunt 20260501T234103Z1a49 (2026-05-01)

- Finding: "Set up profile" checklist row checks itself complete after the user only selects an onboarding persona; Settings > Profile remains empty (`finding_id: checklist-set-up-profile-auto-complete`).
- Same root cause as prior closed finding: `checklist-no-advance-after-fill` (iter `20260428T031818Z2efa`) and `checklist-rest-cli-no-advance` (iter `20260430T222711Z3666`).
- Patched by: Team D (commit `4924948`) — introduces a new `profile:saved` bus event published from `dashboard/settings.js#saveProfile` AFTER the successful `PUT /v1/settings/profile`, gated on both `display_name` AND `bio` being non-empty. `CHECKLIST_STEPS[0].trigger` is changed from `null` to `'profile:saved'` so the registry-driven subscriber owns the transition. The wizard's `handleNext()` no longer reaches in to `markStepComplete('profile')` on Step 1 advance. Decision record: `docs/decisions/profile-saved-bus-event.md`.
- Implication: prior verdict (`incomplete`) is confirmed at a deeper layer. The registry refactor was sound for the three trigger paths that already had outcome publishers (`session:switched`, `order:filled`, `strategy:saved` post-launch); the `profile` step was punted as `trigger: null` because no outcome publisher existed and it seemed cheap to mark on wizard advance. That short-cut conflated navigation with outcome — the same shape as the four prior recurrences. The class is "checklist trigger MUST be the bus event published from the action that mutates the persisted state, not from the navigation handler." Consider expanding the next refactor pass to either: (1) a lint rule that flags any `markStepComplete(...)` reach-in from `dashboard/onboarding.js` outside the bus-subscriber path (the only legal site is the registry's auto-wired subscriber), OR (2) a documentation invariant that every `CHECKLIST_STEPS[].trigger` must be a non-null bus-event name AND every checklist row must have a documented outcome publisher (no more `null` trigger placeholders).
