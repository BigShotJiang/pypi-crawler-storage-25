---
status: shipped
shipped_at: 2026-05-02
shipped_in: c712d98 (merge: 1cd2b5b)
superseded_by: trade-ticket-state-sync-v3.md
superseded_at: 2026-05-02
superseded_in: b715dfd (revert merge 1cd2b5b) + acdfb80 (v3 render-on-read core) + fda69be (test align) + ea9ee7e (window.currentSession alias fix-forward); merged as 42ffd2e; deploy run 25266871370 success
verdict: regressed
verdict_set_in: 20260502T211937Z7ddd
verdict_evidence: "v2 always-on portfolio:updated subscription installed at initTradeTicket() persists across open/close cycles, violating panel-DOM teardown contract. Existing journey-05-trade.spec.ts:380-475 regression test 'available cash header never shows -- across open/close cycles' fails on c712d98 — after closeTradeTicket(), bus.publish('portfolio:updated', {cash: 999999}) MUTATES #tt-cash-balance to $999,999.00 because the always-on subscriber is still attached. Deploy run 25263179874 failed with this exact assertion at journey-05-trade.spec.ts:389. Production currently on a34ac9d (pre-v2). v2 patches in iter 20260502T211937Z7ddd (c489d53, 4837c7f, 54bde9a) merged but undeployed."
category: dashboard-state-sync
drafted: 2026-05-02
drafted_in: refactor-gate-trip-from-pending-recurrences-second-pass
instances: 1
iterations: [20260502T142726Z7b36]
related_ledger_entries: [trade-ticket-stale-cash]
trigger: patch-ineffective
prior_refactor: trade-ticket-state-sync.md (v1 — effective for the open-while-fill / cold-open / shape-drift gaps; does NOT cover panel DOM persisting between open/close)
prior_patch: 109686c (Team A iter 7b36 — submitTradeTicket post-success refetch + splice currentSession.portfolio_metrics + republish portfolio:updated; ineffective per Phase 5.5 retest)
next_step: v3 refactor required — reconcile "panel-DOM persists" backstop with "subscription must NOT respond to events from outside the panel's open lifetime". Likely shape: gate the always-on subscriber on a payload-source predicate (only paint from `portfolio:updated` whose source ∈ {sse, post-fill-refetch}, not from arbitrary publishers). Or: add a dedicated `panel-cash:repaint` event the publisher emits explicitly, decoupling from the noisy general-purpose `portfolio:updated` channel.
---

# Refactor — Trade Ticket panel cash mirror (decouple `tt-cash-balance` repaint from per-open dialog mirror lifecycle)

> **Honest classification up front:** this is a 5-line patch dressed up as a
> refactor doc because the bug-hunt gate convention requires a refactor-queue
> entry to unlock the next iteration. The architectural insight (the v1 mirror
> abstraction conflates "live subscriber lifetime" with "DOM presence
> lifetime", and slide-out panels with persistent DOM violate that
> conflation) is real and worth the doc; the actual code change to close
> the recurrence is a few lines plus a regression test. See
> "Refactor scope" → "Minimal-fix variant (recommended)".

## Why we're here

Phase 5.5 retest of iteration `20260502T142726Z7b36` against deploy
`433c01ceceb034f4bd159514fedb415a50f84003`
(actual code commit: `109686c`):

- Created fresh session ($100k start, 2024-06-03)
- Opened Trade Ticket panel — pre-trade `#tt-cash-balance` correctly primed to `$100,000.00`
- Submitted `BUY 10 SPY MARKET` via the form
- Order filled at `$515.36` (1 `order:filled` bus event captured)
- Bus published `portfolio:updated` with `cash=$94,846.45` (assertion #4 PASS)
- Key Metrics `Cash` tile updated correctly to `$94,846.45`
- **`#tt-cash-balance` remained `$100,000.00` at t+3s and t+8s** (assertions #1 + #2 FAIL — `$5,153.55` divergence = exact SPY cost basis)
- Screenshot: `/Users/justnau/finlet/retest-trade-ticket-stale-cash.png` — panel visibly shows `AVAILABLE CASH $100,000.00` while order log shows the SPY fill at `$515.36`

The v1 refactor (`efdd44316`, 2026-04-30) shipped `dialog-state-mirror.js` and rewrote `openTradeTicket()` to consume it. The mirror was correct for its design surface — *true dialogs whose DOM lifecycle equals their visibility lifecycle*. It closed three recurrence shapes:
- pre-publish gap (open-after-publish)
- mid-fill stale (panel open during fill)
- shape-drift / transient-failure stomp

Iter 7b36's Team A patch (`109686c`) added a fourth layer: post-submit `dashFetch('/portfolio')` + splice `currentSession.portfolio_metrics.{cash,total_value}` + `bus.publish('portfolio:updated', ...)`. The patch was correct for its target — closing the SSE-tick gap when the user re-opens the panel within `_PUSH_INTERVAL` of the fill. It does NOT close this iteration's recurrence because the recurrence happens on a path the patch never touches.

### The actual failure mode

The Trade Ticket *panel* is a slide-out `<aside>` (`dashboard/index.html:427` — `<aside class="trade-ticket" id="trade-ticket-panel" ...>`), not a true dialog. Its DOM (including `<span id="tt-cash-balance">`) is rendered exactly once at page load and persists for the lifetime of the page. `openTradeTicket()` just adds the `trade-ticket--open` CSS class; `closeTradeTicket()` removes it. The DOM element is always present.

The v1 mirror is owned by `tradeTicketMirror`, allocated on `openTradeTicket()` and torn down on `closeTradeTicket()` (`dashboard/trade-ticket.js:138-141, 238-241`). Between close and the next open, **there is no subscriber on `portfolio:updated` that keeps `tt-cash-balance` in sync.** The element keeps whatever `paintCash(...)` last wrote to it. After a fill that the user submits while the panel is open, `submitTradeTicket()` calls `closeTradeTicket()` (line 379) BEFORE the post-submit refetch IIFE (line 408) resolves and republishes — so the mirror is already torn down by the time the post-fill `portfolio:updated` lands on the bus. The bus has zero subscribers for that publish (the panel mirror is gone, and `renderPortfolio` doesn't touch `tt-cash-balance`). The DOM textContent rots at `$100,000.00` until the next `openTradeTicket()` call.

The Phase 5.5 retest then reads `#tt-cash-balance.textContent` directly without re-opening the panel, and observes the rotted value. The panel visible in the screenshot is open because the test (or the user) re-opened it for capture — but in any case, by reading the persistent DOM element, the test surfaces the rot.

This is a **panel-vs-dialog assumption violation**, not a bus-subscriber gap and not a publisher gap. Both halves of the system (publisher, bus cache) are working correctly. The consumer pattern is wrong for this surface.

## Root cause

`dashboard/trade-ticket.js:138-141, 238-241` couples the bus subscription's lifetime to `openTradeTicket()` / `closeTradeTicket()`. This was correct under the v1 mirror's design assumption (a dialog's DOM is created on open and destroyed on close, so a stale subscriber would write to a non-existent node). It is wrong for the slide-out panel surface where the DOM persists.

Specifically:
1. `dashboard/trade-ticket.js:161-207` — `tradeTicketMirror = window.dialogStateMirror({...})` is the only `portfolio:updated` subscriber for `tt-cash-balance`.
2. `dashboard/trade-ticket.js:238-241` — `closeTradeTicket()` calls `tradeTicketMirror.close()` which unsubscribes.
3. `dashboard/app.js:1896-1909` — `renderPortfolio()` updates `#cash-value` (Key Metrics tile) but never `#tt-cash-balance`.
4. `dashboard/trade-ticket.js:379` — `submitTradeTicket` calls `closeTradeTicket()` synchronously on submit-success, BEFORE the line 408 post-submit IIFE awaits its refetch and republishes. So even though Team A's patch republishes correctly (verified by retest assertion #4 passing), the only subscriber that would have repainted `tt-cash-balance` was already torn down between line 379 and the line 449 publish.

Net: the `tt-cash-balance` DOM element has no listener to keep it fresh while the panel is closed. Because the element persists in the document, any read of it (test, screen-reader, an unrelated component) returns the last `paintCash` value, which can be arbitrarily stale.

## Refactor scope

### Minimal-fix variant (recommended)

Hoist the `portfolio:updated` subscription that paints `tt-cash-balance` out of the per-open mirror lifecycle and into a module-level always-on subscription installed by `initTradeTicket()` at page load.

**Files touched:** `dashboard/trade-ticket.js` (one new ~5-line block in `initTradeTicket`, no new modules).

**Pseudocode (illustrative, do not lift verbatim):**
```js
// Inside initTradeTicket(), after the existing wiring:
window.finletBus.subscribe('portfolio:updated', (payload) => {
    if (payload && typeof payload.cash === 'number' && !Number.isNaN(payload.cash)) {
        paintCash(payload.cash);
    }
});
// Also: prime synchronously at init from bus.getLastPublished('portfolio:updated')
// so a page-load that lands AFTER the first SSE tick paints immediately.
```

The per-open `dialogStateMirror` continues to own the open-time prime + shape-drift refetch + refuseClobber gating for the *visible* lifetime of the panel. The new always-on subscriber backstops the closed lifetime by keeping the persistent DOM in sync. Both subscribers paint via the existing `paintCash(cash)` so there's a single shape.

**Why "5-line patch" not "refactor":** the v1 abstraction is correct as-is; the only change is that one consumer (the Trade Ticket panel) needs an additional always-on subscription because its DOM persists. No new module, no schema change, no API change. Roughly 5 lines of net code plus 1 regression test.

### Convention-level variant (NOT recommended for this iteration)

Promote the always-on pattern into `dialog-state-mirror.js` as a separate `panelStateMirror({...})` export with semantics:
- subscribes at install (page load), not at open
- always paints DOM on publish, regardless of visibility
- per-open mirror layered on top continues to own focus/transient/refetch concerns

Cost: ~80 LOC new module + tests + documentation in `event-contract.md` + migration of trade-ticket.js to the new pattern. Benefit: a future read-only persistent panel (e.g. a sticky positions sidebar, an always-visible portfolio-value mini-card in a drawer) gets the convention for free.

There is currently exactly **one** consumer that needs this (the trade ticket panel). Promoting a single-call-site pattern to a convention is premature abstraction. Defer until a second instance appears (matching the v1 refactor's break-even logic of "shipped after 3 instances of the same shape, not the first").

### File conflict table

| File | Touched by |
|------|-----------|
| `dashboard/trade-ticket.js` | this fix (add always-on subscription in `initTradeTicket`; the existing mirror block at lines 161-207 stays untouched) |
| `tests/dashboard/trade-ticket-panel-mirror.spec.js` (new, ~30 LOC) | regression test for the closed-panel repaint case |
| `tests/e2e/journey-05-trade.spec.ts` | one new assertion (read `#tt-cash-balance.textContent` AFTER `closeTradeTicket()` and an `order:filled` SSE — must equal post-fill cash, not the pre-fill value) |

No conflict with any in-flight queue doc. No conflict with v1 — the always-on subscription composes orthogonally to the per-open mirror.

## Validation

- **Unit (node --test):** With bus stubbed and `paintCash` spy installed, publish `portfolio:updated` with `{ cash: 94846.45 }` BEFORE any `openTradeTicket()` call → spy invoked once with `94846.45`. Same publish AFTER an `openTradeTicket()` + `closeTradeTicket()` cycle → spy invoked exactly once (no double-paint from the now-closed mirror).
- **Unit (node --test):** Init runs, bus has prior publish in `getLastPublished('portfolio:updated')` with `{ cash: 87000 }` → after `initTradeTicket()`, `tt-cash-balance.textContent === '$87,000.00'` synchronously.
- **Existing journey-05 tests** — the four existing trade-ticket specs (open/close/reopen, cold-open `--`, mid-fill stale, post-fill re-open) MUST still pass without modification.
- **New e2e regression** (mirrors the Phase 5.5 retest envelope from `triage.json:24-36`):
  - Login to `finlet.dev`, fresh $100k session, MARKET BUY 10 SPY, wait for `order:filled` SSE.
  - **Without re-opening the panel**, read `#tt-cash-balance.textContent` directly via `page.locator('#tt-cash-balance').textContent()`.
  - Assert: parsed cash strictly less than 100000 within 3s of `order:filled`.
  - Assert: parsed cash equals Key Metrics `#cash-value` text (within rounding) within 3s.
  - Assert: zero console errors during the flow.
  - Cleanup: `DELETE /v1/sessions/{sid}` → 200.
- **Smoke (Playwright MCP, manual)**: same envelope as above against prod after deploy. This is the assertion the iteration 7b36 retest measured and found failing; passing here marks the fix effective.

## Break-even

Status quo: 1 patch-ineffective signal in iter `20260502T142726Z7b36`. Without this fix, the next bug-hunt iteration re-trips the gate on the same recurrence shape. The same 5-line subscription closes the recurrence permanently for this surface.

The recurrence is HIGH-confidence to repeat without a fix because the closed-panel-DOM-rot is structural: any future `portfolio:updated` publish (every SSE tick, every fill, every clock advance with positions held) writes to the bus but skips `tt-cash-balance`. The next time a blind agent or a real user closes the panel, places a trade, then reads the persistent DOM (programmatically or via accessibility tools), they will see stale cash.

Cost is dominated by the test write, not the production fix. Total: ~30 minutes of agent time including the new unit + e2e assertions. Reversal is `git revert` of one commit; the always-on subscription has no API contract that downstream depends on.

## Reversal path

Single small commit. The new always-on subscription is one `bus.subscribe(...)` call returning an unsubscribe closure that is never invoked (intentional — it lives for the page lifetime). Removing the call un-fixes the bug but breaks nothing else; the v1 mirror continues to function exactly as before. Revert is safe in either direction; no schema, API, or contract changes.

## Out of scope (explicit acknowledgements)

- **Generalising into a `panelStateMirror` convention.** Single consumer; defer until a second instance appears (see "Convention-level variant" above).
- **Removing the v1 `dialogStateMirror`.** It still owns the focus / transient-failure / shape-drift / refuseClobber semantics for the OPEN-PANEL lifetime — those concerns are real and the new always-on subscriber doesn't replace them. The mirror remains the per-open authority; the always-on subscriber is a closed-panel backstop.
- **Auditing other slide-out panels.** Search of `dashboard/` shows the trade ticket is the only slide-out `<aside>` with persistent DOM that mirrors live bus state. Other dialogs (session creator, settings sub-panels) either own form state (covered by `form-dirty-tracker.js`) or are read-once-on-open (no mirror needed). If a future surface joins this category, lift this code into `panelStateMirror.js` then.
- **Server contract.** Publisher (`dashboard/app.js:1456-1475` SSE handler + `dashboard/app.js:1572-1612` post-fill handler + `dashboard/trade-ticket.js:408-459` post-submit IIFE) is correct and unchanged. The bus cache is correct and unchanged. Only the consumer wiring needs the closed-panel backstop.

## Verdict — REGRESSED (set by iter `20260502T211937Z7ddd`)

The v2 always-on subscription closes the original closed-panel-DOM-rot recurrence shape, but introduces a new regression class: any publisher of `portfolio:updated` (test code, unrelated component, future feature wiring) now mutates `#tt-cash-balance` regardless of panel visibility or trust.

Existing regression test at `tests/e2e/journey-05-trade.spec.ts:380-475` ("available cash header never shows -- across open/close cycles") encodes the inverse contract: after `closeTradeTicket()`, the cash header text MUST NOT change in response to bus events. v2 violates this contract.

**Deploy evidence:** GitHub Actions run `25263179874` (commit `54bde9a`, this iteration's HEAD) failed at `journey-05-trade.spec.ts:389`. Same test was already failing on the immediate predecessor `068e4f5` (run `25261964914`). Last green deploy was `a34ac9d` (2026-05-02T18:08:50Z), pre-v2. Production is currently on `a34ac9d`; the v2 fix and this iteration's fixes are merged-but-undeployed.

**`pending_recurrences.jsonl` retention:** the `trade-ticket-stale-cash` entry is NOT pruned. Verdict is `regressed`, not `effective` — the original recurrence shape may be closed but the patch is shipped-broken on prod. Treat this as a still-open pending recurrence until v3 lands.

### Required v3 follow-up (next iteration's refactor-queue trigger)

Either:
1. **Source-gated subscriber** (preferred): the always-on subscriber checks a payload property (`source: 'sse' | 'post-fill-refetch' | 'test-poison'`) and ignores publishes the panel doesn't trust. Cost: payload schema change in 3 publish sites, ~5 LOC subscriber filter.
2. **Dedicated repaint channel**: publishers emit a separate `panel-cash:repaint` event when (and only when) the panel should repaint. The general `portfolio:updated` stays a noisy notify-only channel. Cost: 1 new event in `event-contract.md`, repaint at the existing 3 publish sites, drop the `portfolio:updated` subscriber from `initTradeTicket`.
3. **Reconcile-on-open + close-time-cleanup hybrid** (least preferred): keep the always-on subscriber, but on `closeTradeTicket()` write the LAST KNOWN authoritative cash value into `#tt-cash-balance` and detach the subscriber until next open; on `openTradeTicket()` re-attach + re-read `bus.getLastPublished('portfolio:updated')`. Effectively v1 mirror semantics with a close-time freeze frame. Cost: ~10 LOC subscriber lifecycle redesign in trade-ticket.js. Risk: re-introduces the iter `7b36` recurrence the v2 was designed to close — needs a different mechanism for the closed-panel-DOM-rot case (e.g., write authoritative value on every fill via the post-fill IIFE directly into the DOM regardless of subscriber state).

Draft the v3 refactor-queue doc as `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` before re-attempting deploy.


---

_Iteration note 2026-05-06 (bug-hunt `20260506T061637Z6594`):_ this iteration shipped one new `dashboard-state-sync` finding (`plugin-health-dot-unhealthy-falls-to-unknown`) — predicate drift on the canonical `PluginHealthStatus` enum across `dashboard/app.js` and `dashboard/settings.js`. The bug is on a different surface than this refactor (predicate-vs-server-enum vocabulary skew, not the persistent-DOM / chart-Y-axis / config-propagation / overflow-contract surfaces). No verdict change implied for this refactor; cross-reference for category-recurrence tracking only. Ledger entry: `docs/bug-hunt/ledger.jsonl` (line 65).
