---
status: shipped
shipped_at: 2026-05-01
shipped_in: fc58c4d (Team B merge — completes the refactor; Team A merge at 57ae3fe lands the server contract)
category: dashboard-state-sync
drafted: 2026-05-01
drafted_in: 20260501T172055Z127b (patch-ineffective signal)
revised: 2026-05-01 (post Codex adversarial review — collapsed onto existing PUT /settings/plugins)
instances: 1
iterations: [20260501T172055Z127b]
related_ledger_entries: [edgar-plugin-stale-after-cli-config]
trigger: patch-ineffective
verdict: effective
verdict_set_at: 2026-05-02
verdict_set_in: bug-hunt-skill-gate-housekeeping-2026-05-02
verdict_evidence: |
  Re-tested against live finlet.dev after the refactor (commits 57ae3fe + fc58c4d) shipped
  post-deploy_sha=13af780d. Retest envelope from pending_recurrences.jsonl line 1 executed
  via working-tree CLI against https://finlet.dev:

    $ FINLET_API_URL=https://finlet.dev FINLET_API_KEY=[REDACTED] \
        uv run python -m finlet plugins add edgar --email retest@example.com
    Plugin 'edgar' status: unhealthy — edgar health check failed:
      [Errno 30] Read-only file system: '/home/finlet/.edgar/_tcache/data.sec.gov'
    (exit 0)

    $ curl https://finlet.dev/v1/plugins/health   # 3s post-add
    { "name": "edgar", "type": "filings", "status": "unhealthy",
      "message": "edgar health check failed: [Errno 30] Read-only file system: ...",
      "latency_ms": 80.04, "rate_limit_remaining": null }

  The original patch-ineffective signal asserted "edgar plugin not initialized." persisted
  3s post-add. That assertion is FALSIFIED on main: the message has changed (no longer
  "not initialized"), latency_ms is populated (80.04ms — the health check actually
  executed), and `plugins remove edgar` round-trips back to `latency_ms: null` /
  "not initialized" — proving the in-process reload + uninit pipeline both fire end-to-end.

  The original signal was a deploy-lag artifact (retest measured deploy_sha=13af780d, which
  predates the 57ae3fe + fc58c4d refactor merges). The refactor closed the underlying
  config-propagation gap.

  NOTE: a NEW production-ops bug is now visible (read-only filesystem at
  /home/finlet/.edgar/_tcache/) — the EDGAR client tries to write its cache to a path the
  finlet user cannot write to in the prod container. This is a fresh deploy/ops issue, NOT
  a plugin-config-propagation gap. Filing as a separate ledger entry for the next iteration.
---

# Refactor — Unify plugin config writes onto `PUT /settings/plugins` (CLI parity with dashboard)

## Why we're here

Iteration `20260501T172055Z127b` shipped commit `9c115e6` ("[Team A]: EDGAR plugin hot-reload + actionable CLI message"), adding `POST /v1/plugins/{name}/reload` and rewriting `finlet plugins add` to write the entry to the caller's local `~/.finlet/plugins.json` and then POST that reload endpoint. Tests passed. Phase 5.5 retest of the same iteration ran the working-tree CLI against `https://finlet.dev`: CLI exit 0, "Restart server to apply" wording gone, but `GET /v1/plugins/health` 3s later still returned edgar `unhealthy: edgar plugin not initialized.`. Re-probed today against prod — same response.

The patch's hot-reload mechanism (`PluginRegistry.reload`, `POST /reload`) is correct in isolation. The bug is that the CLI bypassed the **existing** authenticated config path the dashboard uses:

- `PUT /v1/settings/plugins` (`finlet/api/routes_settings.py:128-137`) — `Depends(require_user)`, calls `settings_service.update_plugin(user_id, plugin=, api_key=, email=, enabled=)`.
- `update_plugin` (`finlet/api/services/settings_service.py:209-250`) — stores in per-user `_user_plugin_config`, calls `target.initialize(config.get(plugin, {}))` directly (NOT `registry.reload`), wraps the init in `contextlib.suppress(Exception)`, returns `{"status": "updated", "plugin": plugin}` regardless of init outcome.
- Dashboard already PUTs to `/settings/plugins` (`dashboard/settings.js:1040, 1051`) and polls `/plugins/health` separately.

The previous iteration's CLI change wrote to a different filesystem (`~/.finlet/plugins.json` on the laptop), then poked a server endpoint that re-read the **server's** filesystem. The two never met. The fix is not a third config endpoint — it is repointing the CLI at the existing one and tightening the existing one's response so the CLI can surface the live status.

## Root cause

Two converging gaps:

1. **CLI/dashboard contract divergence.** Dashboard PUTs `/settings/plugins` (authenticated, per-user, in-memory). CLI writes a local JSON file and POSTs `/reload` (unauthenticated, host-global, server-side filesystem). For a remote-server deploy (the actual finlet.dev model), the CLI's writes never reach the server.

2. **`update_plugin` swallows init failures.** The handler catches every exception from `target.initialize(...)` and returns `{"status": "updated"}` with no signal of whether init succeeded. EDGAR rejects empty identity, swallowed; CLI/dashboard caller sees "updated" and assumes healthy. Combined with (1), even an authenticated CLI caller couldn't tell their config didn't take.

The CLI's `plugins list` docstring (`finlet/cli.py:235-247`) already names the symptom: *"the running server only loads plugin config at startup, so a fresh plugins add won't flip the server-reported health status until the next restart. The local marker keeps the CLI honest about what the user has done in the meantime."* That comment is honest about gap (1) but predates the existence of `/settings/plugins` as a real write path; the CLI never migrated.

## Refactor scope

One team. One worktree. ~3-4 hours of agent work. Smaller than the original draft — no new endpoint, no `PluginConfigStore` extraction, no new schemas. Pure CLI redirect + service-layer response tightening.

### Files touched (~8 files)

- **Modified: `finlet/api/services/settings_service.py`** (`update_plugin`, lines ~209-250):
  - Drop `contextlib.suppress(Exception)` around `target.initialize(...)`. Catch the exception explicitly, capture it, and surface it.
  - Replace the direct `target.initialize(...)` call with `registry.reload(plugin, config.get(plugin, {}))` so the per-plugin `_reload_lock` (`finlet/plugins/base.py:_reload_lock`) serializes against concurrent `/reload` and `/plugins/health` callers.
  - After reload, run `await registry.health_check_all()` and pluck the matching post-reload health record.
  - Return a richer response (new shape — see schema below): `{"status": <"updated"|"unhealthy"|"degraded">, "plugin": str, "health": PluginHealthItem-compatible dict, "message": str | None}`.
- **Modified: `finlet/api/schemas/settings.py`** (`PluginUpdateResponse`):
  - Extend response model to carry the post-reload status. Reuse `PluginHealthItem` from `finlet/api/schemas/health.py` directly (do NOT duplicate the model).
  - Backward compat: keep `status` and `plugin` keys in the same positions; the new `health` key is additive. Dashboard's existing handler doesn't read `health` yet — it'll just ignore the extra key.
- **Modified: `finlet/api/routes_settings.py`** (`update_plugin` route, lines ~128-145):
  - Pass through the richer response. No auth or path changes.
- **Modified: `finlet/cli.py`** (`plugins_add`, lines ~286-330):
  - Stop writing to local `~/.finlet/plugins.json`. Drop the `PLUGINS_CONFIG_PATH` write block entirely (it's only there because the CLI predates `/settings/plugins`).
  - Replace the `POST $API/v1/plugins/{name}/reload` call with `PUT $API/v1/settings/plugins` carrying `{"plugin": name, "api_key": ..., "email": ..., "enabled": true}`.
  - Auth: existing `--server-api-key` / `FINLET_API_KEY` env var becomes mandatory (the new endpoint requires `require_user`). Surface a clear error if the var is missing: *"finlet plugins add requires FINLET_API_KEY (the API key for your finlet.dev account). Get one from `finlet auth login` or the dashboard."*
  - Surface the response: read `health.status` and `health.message`, print one of the same three lines the previous patch used (`Plugin 'X' status: healthy — OK`, `... status: unhealthy — <message>`, network error path unchanged).
  - Drop the `--server-api-key` separate flag if `FINLET_API_KEY` is now load-bearing — keep the env var only.
  - `plugins list` (lines ~229-285): drop the local-file cross-reference (`configured` marker driven by local plugins.json). Replace with a server-side `GET /v1/settings/plugins` call (which already exists at `routes_settings.py:119` and returns masked configs). The CLI can show "configured" based on what the server holds for the calling user — true source of truth.
- **Modified: `finlet/api/routes_health.py`** (`POST /plugins/{name}/reload`, lines ~138-205):
  - Add a one-paragraph docstring update explaining the role split: this endpoint is the "reapply existing persisted config" knob; new config writes should go through `PUT /settings/plugins`. No code change here, just docstring.
- **Modified: `tests/api/test_routes_settings.py`** (existing test class for `PUT /settings/plugins`):
  - Extend the existing happy-path test to assert the response now contains `health` with `status: "healthy"` (or whatever EDGAR/Finnhub returns).
  - New test: `update_plugin` with edgar + missing email returns 200, `health.status == "unhealthy"`, `health.message` mentions identity (not silent suppression).
  - New test: `update_plugin` with edgar + valid email returns 200, `health.status == "healthy"` within the same response (no separate poll needed).
  - New test: concurrent `update_plugin` + `health_check_all` serializes — one of the two waits for `_reload_lock`, neither sees a half-built plugin instance.
- **Modified: `tests/test_cli.py`** (`TestPluginsAddCommand`):
  - Replace the existing fixtures that assert local `~/.finlet/plugins.json` writes with assertions that the test's stub server saw a `PUT /settings/plugins` with the expected body.
  - Regression test: `plugins add` without `FINLET_API_KEY` exits non-zero with the actionable error message (not a generic 401 surface).
  - Keep the network-error and unhealthy-surfacing tests; they still apply to the new endpoint.
- **Modified: `docs/ARCHITECTURE.md`**:
  - One-paragraph "Plugin config write paths" subsection: `PUT /v1/settings/plugins` is the canonical write surface used by both dashboard and CLI; `POST /v1/plugins/{name}/reload` is the no-config-change kicker for ops/debugging; legacy local `~/.finlet/plugins.json` is dev-only (single-host installs where the CLI runs on the same machine as the API server, not for finlet.dev users).
  - Note the multi-user limitation explicitly (it's already in `settings_service.py:223-226`'s docstring): EDGAR's `set_identity()` is a global call; full per-request identity isolation is post-launch work and is **not delivered by this refactor**.
- **NOT TOUCHED: `dashboard/settings.js`** — already uses `PUT /settings/plugins`. The new richer response is additive (extra `health` key); the dashboard's existing `/plugins/health` poll continues to drive its UI. Confirmed by reading the file (`dashboard/settings.js:952-1054`).

### File conflict table

| File | Touched by |
|------|-----------|
| `finlet/api/services/settings_service.py` | this refactor |
| `finlet/api/schemas/settings.py` | this refactor |
| `finlet/api/routes_settings.py` | this refactor |
| `finlet/api/routes_health.py` | this refactor (docstring only) |
| `finlet/cli.py` | this refactor |
| `tests/api/test_routes_settings.py` | this refactor |
| `tests/test_cli.py` | this refactor |
| `docs/ARCHITECTURE.md` | this refactor + bug-hunt Team D pattern |

No conflict with any in-flight queue doc (modal-stacking, dirty-state-tracker, onboarding-checklist, trade-ticket-state-sync, trusted-types are all `status: shipped` with verdicts).

## Validation

- **Unit (settings_service):** `update_plugin(uid, plugin="edgar", email="x@y.com")` with the registry stubbed returns a response whose `health.status == "healthy"`. Same call with `email=None` returns `health.status == "unhealthy"` and a non-empty `health.message`. No exception escapes the function.
- **Unit (concurrency):** simulate concurrent `update_plugin` and `registry.health_check_all()` against the same plugin — neither sees `_initialized: False` from outside the reload window. The `_reload_lock` already serializes the writer; the reader takes a snapshot via `_all_plugins.get(name)` which is fine because `initialize()` mutates in place.
- **API (`PUT /v1/settings/plugins`):** authenticated request with `{plugin: "edgar", email: "x@y.com"}` returns 200, body contains `{status: "updated", plugin: "edgar", health: {status: "healthy", ...}}`. Unauthenticated request returns 401 (regression — `require_user` is unchanged).
- **API (`PUT /v1/settings/plugins` + finnhub):** request with `{plugin: "finnhub", api_key: "sk_..."}` returns 200 with `health.status == "healthy"` if the key validates, or `degraded`/`unhealthy` with the actual error if not.
- **CLI:** `finlet plugins add edgar --email retest@example.com` with `FINLET_API_KEY` set against a stub server invokes `PUT /settings/plugins` exactly once, exit 0, stdout shows `Plugin 'edgar' status: healthy — OK`. Same command without `FINLET_API_KEY` exits non-zero with the actionable env-var message.
- **CLI (`plugins list`):** queries `/v1/settings/plugins` for the configured-by-this-user marker. No local-file read.
- **End-to-end against prod (Phase 5.5 retest after deploy):** from laptop, `finlet plugins add edgar --email retest@example.com` against `https://finlet.dev`, then `GET /v1/plugins/health` → edgar `status="healthy"`. This is the assertion the previous iteration's retest measured and found failing; if it passes here, the refactor is verdict-effective. Cleanup: `PUT /v1/settings/plugins` with `{plugin: "edgar", email: ""}` to reset (or a delete path if one exists).

## Break-even

Status quo: 1 patch-ineffective signal in iter `20260501T172055Z127b`. Without this refactor, the next bug-hunt iteration re-trips the gate on the same signal. Refactor pays back on the next iteration: the gap becomes a closed convention, both CLI and dashboard funnel through one authenticated path, and `update_plugin` no longer silently swallows init failures (which fixes a class of "configured but doesn't work" bugs that aren't even on the bug-hunt ledger yet because they look like working-as-designed `{"status": "updated"}` responses).

The "tighten `update_plugin`'s response" half of the work is partly bug-fix (suppressed exceptions are real bug source) and partly necessary scaffolding for the CLI redirect — they share a deliverable.

## Reversal path

Single merge SHA. The CLI change is a function rewrite; the service change replaces a `with contextlib.suppress(Exception)` block with an explicit catch. Reverting drops the new endpoint usage from the CLI and re-adds the local file write + POST /reload sequence. The richer response shape is additive (existing dashboard handler ignores the extra key), so reverting the service change without reverting clients is safe in either direction. ~30 minutes to revert if a deployment problem surfaces.

## Out of scope (explicit acknowledgements)

- **Multi-user runtime isolation.** `update_plugin` mutates the per-user `_user_plugin_config` dict but `target.initialize(...)` (now `registry.reload(...)`) reinitializes the **singleton** plugin instance with the most recent caller's credentials. EDGAR's `set_identity()` is a global call. Finnhub/FRED API keys are also global once `initialize()` runs. The existing docstring at `settings_service.py:223-226` already names this limitation. **This refactor preserves the limitation; it does not introduce or worsen it.** Per-request plugin identity / per-session plugin instance is a separate refactor that is required before hosted multi-tenant BYOK launches.
- **Plugin secret encryption at rest.** `_user_plugin_config` is process-memory-only (in-memory dict, lost on restart). API keys are not persisted to disk by `update_plugin`. Whether to persist (DB-backed) and how to encrypt at rest is a separate scope.
- **Local `~/.finlet/plugins.json` deprecation.** The CLI stops reading/writing it. Whether to also remove the file at upgrade time, or leave it as a vestigial artifact for users who downgrade, is a packaging concern, not a refactor concern. Default in this scope: leave existing files alone, don't write new ones.
- **Dashboard plugins-config UI gaps.** `dashboard/settings.js:993-1000` only renders an API-key input for plugins that need it; EDGAR's email/identity field isn't surfaced in the dashboard form. The CLI fix unblocks EDGAR users via CLI; the dashboard form gap is a separate UX scope.
- **Pre-existing pypi-release-lag findings (Findings 1+4 from iter `20260501T172055Z127b`).** Upstream dependency releases unrelated to config propagation; remain deferred.

## Verdict (pending — to be set by next bug-hunt iteration)

Refactor not yet shipped. Per the refactor-gate convention, the next bug-hunt iteration after this refactor merges will retest:

- `edgar-plugin-stale-after-cli-config` shape from iter `20260501T172055Z127b` — from the laptop with `FINLET_API_KEY` set, `finlet plugins add edgar --email X` against `finlet.dev`, then GET `/v1/plugins/health` shows edgar `status="healthy"` within a single tick.
- Implicit additional retest: `update_plugin` with edgar + empty email returns `health.status == "unhealthy"` rather than the previous always-`{"status": "updated"}` response.

If both pass cleanly with no new patch-ineffective signals in `dashboard-state-sync` or a new `cli-server-state-mismatch` instance, mark `verdict: effective`. If the same shape recurs (or a new variant — e.g., dashboard PUT works but CLI PUT doesn't), mark `incomplete` and document which sub-gap survived.

## Verdict Investigation 2026-05-02

Run from refactor iteration `close-patch-ineffective-2026-05-02` (Team A). Probe executed against `https://finlet.dev` from the working-tree CLI before any code edit, with `FINLET_API_KEY=$FINLET_TEST_USER_API_KEY` from `~/.bug-hunt-loop/secrets.env`.

### Probe steps and outputs

```
$ uv run python -m finlet plugins add edgar --email retest@example.com
Plugin 'edgar' status: unhealthy — edgar health check failed: [Errno 30] Read-only file system: '/home/finlet/.edgar/_tcache/data.sec.gov'
CLI exit: 0
```

```
$ curl -fsS -H "Authorization: Bearer $FINLET_API_KEY" https://finlet.dev/v1/plugins/health | jq '.[] | select(.name == "edgar")'
{
  "name": "edgar",
  "type": "filings",
  "status": "unhealthy",
  "message": "edgar health check failed: [Errno 30] Read-only file system: '/home/finlet/.edgar/_tcache/data.sec.gov'",
  "last_checked": "2026-05-02T06:16:09.274777+00:00",
  "latency_ms": 83.56794994324446,
  "rate_limit_remaining": null
}
```

### What changed vs Signal 1 from `20260501T172055Z127b`

The original patch-ineffective signal was: CLI exits 0 saying success, but `GET /v1/plugins/health` returned edgar `unhealthy: edgar plugin not initialized.` — proving the CLI's local-file write never reached the server.

The current probe shows:
1. **The CLI is now hitting the server.** The CLI prints the live status from the server response (`unhealthy — edgar health check failed: [Errno 30] Read-only file system: ...`). The CLI no longer says "Restart server to apply" or otherwise lies about state.
2. **The "plugin not initialized" symptom is gone.** The plugin IS being initialized — it actually got far enough to attempt a health check, which then failed at the prod-side filesystem layer.
3. **A new orthogonal defect surfaces.** The `edgartools` library (used by `EdgarPlugin`) writes to `~/.edgar/_tcache/` on disk during health probes. The production EC2 user `finlet` has its `~/.edgar/` on a read-only mount (or the directory is not writable), causing every probe to fail with `[Errno 30]`.

### Verdict assessment

The original Signal 1 symptom — CLI write doesn't reach server — is **fixed**. Both the CLI and the dashboard now go through the same authenticated `PUT /v1/settings/plugins` write path, and the server's `update_plugin` handler reloads the plugin and returns the live health record.

However, the post-reload health is `unhealthy` (not `healthy`). Per the strict probe-result branching for this iteration ("If probe shows EDGAR `unhealthy` → file investigation, ship only `plugins remove`"), I am NOT marking `verdict: effective` in this iteration. The new failure mode (`Errno 30: Read-only file system`) is NOT a config-propagation defect; it is a deployment/environment issue affecting the `edgartools` cache directory on the production host.

### Follow-up for ops/infra (out of scope for this refactor)

Next bug-hunt or ops iteration should:
- Verify whether `/home/finlet/.edgar/` exists and is writable on the prod EC2 host.
- If writable, investigate why `edgartools` reports read-only — possibly a SELinux/AppArmor block, container overlay, or misconfigured volume mount.
- If not writable, set `EDGAR_LOCAL_DATA_DIR` to a writable path (e.g. `/tmp/edgar`) via the systemd service's `Environment=` directive, OR mount a writable volume at `~/.edgar/`.
- Optionally: pre-create `~/.edgar/_tcache/data.sec.gov/` with `0700` ownership in the deploy hook so first-probe-after-restart doesn't crash on a missing directory.

This is an ops finding, not a config-propagation gap — leaving the verdict on this refactor as **pending** until the EDGAR runtime cache lands somewhere writable on prod, at which point the probe should rerun and (assuming the CLI/server path stays clean) mark `effective`.

### Refactor-iteration shipped scope

This iteration (`close-patch-ineffective-2026-05-02`) ships:
- `finlet plugins remove <name>` CLI subcommand (PUTs `/v1/settings/plugins` with empty-string credentials + `enabled=False`) — symmetric counterpart to `plugins add`, relies on the existing empty-string-clears contract in `update_plugin`.
- Documentation update on `update_plugin`'s docstring naming the empty-string-clears behaviour explicitly so the contract is discoverable from the source.
- Test coverage: `TestPluginsRemoveCommand` (4 tests) + extended `TestPlugins.test_update_plugin_clears_credentials_with_empty_strings`.

No changes to `update_plugin` body or `registry.reload` — the existing path already handles empty-string clears correctly (verified via probe: the CLI's PUT with `email=retest@example.com` reached the server and reloaded the plugin).


---

_Iteration note 2026-05-06 (bug-hunt `20260506T061637Z6594`):_ this iteration shipped one new `dashboard-state-sync` finding (`plugin-health-dot-unhealthy-falls-to-unknown`) — predicate drift on the canonical `PluginHealthStatus` enum across `dashboard/app.js` and `dashboard/settings.js`. The bug is on a different surface than this refactor (predicate-vs-server-enum vocabulary skew, not the persistent-DOM / chart-Y-axis / config-propagation / overflow-contract surfaces). No verdict change implied for this refactor; cross-reference for category-recurrence tracking only. Ledger entry: `docs/bug-hunt/ledger.jsonl` (line 65).
