---
status: shipped
shipped_at: 2026-04-30
shipped_in: bbbf7cc32e88809e3dc9bd91f65053f528f66966
category: trusted-types
drafted: 2026-04-30
drafted_in:
instances: 3
iterations: [20260428T013300Z6e79, 20260428T031818Z2efa]
related_ledger_entries: [trusted-types-default-svg, google-sso-goog-html-csp, trusted-types-vendor-svg]
verdict: effective
verdict_set_at: 2026-04-30
verdict_set_in: 20260430T222711Z3666
verdict_evidence: "Zero trusted-types findings in this iteration's triage (broadened lint coverage + runtime CSP-violation reporter held; no console CSP violations reported by the blind agent)."
---

# Refactor — Trusted Types convention (lint-coverage broaden + runtime CSP-violation reporter + .html sink audit)

## Why we're here

Three real-broken instances of the same shape across two bug-hunt iterations, all surfacing as console-noisy Trusted Types / CSP violations on dashboard page loads:

1. `trusted-types-default-svg` — iter `20260428T013300Z6e79`, commit `4908f98`. SVG icon was being injected via the unnamed `default` Trusted Types policy instead of the `finlet-default` named policy. Patched by removing a dead Sentry CDN script tag from `dashboard/index.html` and exporting `openLeaderboardSubmitModal` (the actual SVG-via-default-policy site moved into `api-utils.js:439-455`'s default-policy fallback path, which logs but doesn't fix the caller). The lint guard never fired because the offending HTML lived in the index template, not a `.js` file.
2. `google-sso-goog-html-csp` — iter `20260428T013300Z6e79`, commit `4908f98`. Google's SSO bundle creates a `goog#html` Trusted Types policy at script-load time. The original CSP header listed `trusted-types finlet-default default;` so the third-party policy creation was blocked. Patched by adding `goog#html` to the allowlist in `finlet/api/security_middleware.py:214`. This is a CSP-policy gap, not a code gap — but it surfaced only because no automation tested the auth.html path against the live CSP header.
3. `trusted-types-vendor-svg` — iter `20260428T031818Z2efa`, commit `9c5a917`. `dashboard/api-utils.js:441` (the default-policy `console.warn` callback itself) was firing on every page load because the vendored `lightweight-charts.standalone.production.js` had a minified `innerHTML =` write the lint guard couldn't safely rewrite. Patched by adding the `// trusted-types-vendor-allowlist` marker to the vendor file. Symptom suppressed; the underlying issue (no convention for "third-party JS that we vendor and cannot wrap") was deferred.

Same shape across all three: a Trusted Types violation slips into production because the lint guard, the CSP allowlist, and the runtime policy each cover a different sink and the seams between them are unguarded. Each fix has been a per-instance patch — broaden the CSP, add a marker comment, remove a dead tag — without extracting the convention. Two of the three findings landed in the SAME bug-hunt iteration, which suggests the gap is not a slow drip but a structural blind spot.

## Root cause

The dashboard already has three layers of Trusted Types enforcement:

1. **Runtime policy** (`dashboard/api-utils.js:413-458`) — `finlet-default` named policy passes input through unchanged (callers pre-escape via `esc()`); a `default` policy logs `console.warn` for any caller that bypassed the named policy. `trustedHTML(html)` at line 469 is the documented wrap.
2. **CSP header** (`finlet/api/security_middleware.py:211-228`) — `trusted-types finlet-default default goog#html; require-trusted-types-for 'script';` plus `report-uri /v1/csp-report` and a matching endpoint at `finlet/api/routes_csp.py:40-64` that logs each violation to `structlog`.
3. **Pre-commit lint** (`scripts/lint-trusted-types.sh`) — scans `dashboard/**/*.js` for `\.innerHTML\s*=` writes that aren't routed through `trustedHTML(...)`, with same-line and next-line forgiveness.

The bugs slipped through because each layer has a specific blind spot:

- **Lint script scans `*.js` only** (line 154: `find "$DASH_DIR" -type f -name '*.js'`). It does NOT scan `*.html` files, even though `dashboard/verify.html`, `dashboard/setup.html`, and `dashboard/agent-guide.html` all contain inline `<script>` blocks with `.innerHTML =` writes. `verify.html:101,120,126,133` has FOUR bare `statusEl.innerHTML = '...'` writes that are unwrapped TODAY — they would surface as default-policy warnings the moment a user hits an email-verification error path. `setup.html:397,401,415,418` has FOUR more bare writes for the copy-button success state.
- **Lint regex matches only `\.innerHTML\s*=`.** The other Trusted Types-relevant DOM HTML sinks are not covered: `outerHTML =`, `insertAdjacentHTML(`, `document.write(`, `Range.createContextualFragment(`, `DOMParser.parseFromString(..., 'text/html')` injection paths, `srcdoc =`, and `<template>.innerHTML`. None of these appear in the dashboard today (audited 2026-04-30) but the lint cannot promise that's still true after the next refactor — the convention is silent on these sinks, so a developer who switches one site from `innerHTML` to `insertAdjacentHTML` to avoid replacing existing children would slip past CI.
- **No production telemetry on Trusted Types violations.** The CSP `report-uri` endpoint logs CSP violations, but the runtime `default` policy at `api-utils.js:439-455` logs to `console.warn` ONLY. Production browsers run with the user's console closed; we have no signal when the default policy fires until a bug-hunt agent stumbles on it. The `client-error_report` endpoint at `routes_csp.py:67-84` is wired and rate-limited but no client code POSTs Trusted Types violations to it.
- **No CI smoke against the live CSP header.** The `goog#html` regression slipped because nothing in CI loads `auth.html`, opens the SSO redirect, and asserts no `Refused to create a TrustedTypePolicy` in the console. The Playwright suite doesn't fail on console errors of class `securitypolicyviolation`.

## Refactor scope

One team. One worktree. ~2-3 hours of agent work. Three coordinated changes; all narrow.

### Files touched

- **Modified: `scripts/lint-trusted-types.sh`** — broaden the file glob and the sink regex.
  - **Glob change:** the `find` invocation at line 154 currently emits only `*.js`; replace with `find "$DASH_DIR" -type f \( -name '*.js' -o -name '*.html' \) -print0`. The vendor allowlist marker check (line 93) already handles `lightweight-charts.standalone.production.js`; HTML files have no vendor cases.
  - **Regex change:** the `\.innerHTML[[:space:]]*=` predicate at lines 138 and 144 expands to a single regex covering all in-scope sinks: `\.(innerHTML|outerHTML)[[:space:]]*=|\.insertAdjacentHTML[[:space:]]*\(|document\.write[[:space:]]*\(|\.createContextualFragment[[:space:]]*\(`. Same forgiveness rules apply: same-line or next-line `trustedHTML(`. The error message at line 165 updates accordingly ("bare HTML-sink write site(s)" instead of "bare .innerHTML write site(s)").
  - **HTML-block scoping:** when scanning a `.html` file, only lines between `<script>` and `</script>` participate. Implemented as a one-pass awk state-machine flag toggled by those tags (case-insensitive). Outside `<script>` blocks, HTML attribute writes like `onclick="..."` are out of scope for this refactor (handled by CSP `script-src` already).

- **Modified: `dashboard/verify.html`** — wrap the four bare `statusEl.innerHTML = '...'` writes at lines 101, 120, 126, 133 in `trustedHTML(...)`. Each block is a static string concat (no user data); semantically identical wrap, no escape changes needed.

- **Modified: `dashboard/setup.html`** — wrap the four bare `btn.innerHTML = '...'` writes at lines 397, 401, 415, 418 in `trustedHTML(...)`. Static SVG markup; mechanical wrap. Pattern matches the already-wrapped `agent-guide.html:450-471` precedent.

- **Modified: `dashboard/api-utils.js`** — add a Trusted Types violation reporter inside the `default` policy callbacks at lines 440-453. Each callback (`createHTML`, `createScript`, `createScriptURL`) currently calls `console.warn` only; add a paired `reportClientError({ type: 'trusted_types_violation', sink, sample: input.substring(0, 120), source: <stack trace's first frame> })` call using the existing `reportClientError` helper at `api-utils.js:380-402` (already POSTs to `/v1/telemetry/client-error` via `sendBeacon`). Wrap in try/catch so a telemetry failure can never block the page render. Also add a top-level `document.addEventListener('securitypolicyviolation', ...)` handler that POSTs the same payload — catches CSP-side violations the default policy doesn't see (e.g., third-party policy creation blocked, like the `goog#html` case before its allowlist).

- **Modified: `tests/dashboard/lint-trusted-types.spec.sh`** (new, node --test or bash-test) — fixtures: a `.js` file with `outerHTML =` (must fail), a `.html` file with bare `innerHTML =` inside `<script>` (must fail), a `.html` file with the same write outside `<script>` (must pass — that's an attribute, out of scope), a `.js` file with `insertAdjacentHTML(...)` wrapped in `trustedHTML()` (must pass), and the existing same-line / next-line forgiveness cases.

- **Modified: `dashboard/event-contract.md`** — update the "HTML safety pattern" cross-reference at lines 83-89 to enumerate the broader sink list (`innerHTML`, `outerHTML`, `insertAdjacentHTML`, `document.write`, `createContextualFragment`) and to document the Trusted Types violation reporter as the runtime fallback for any sink the lint missed.

### File conflict table

| File | Touched by | Conflict? |
|------|-----------|-----------|
| `scripts/lint-trusted-types.sh` | this refactor | none — owned by infra; no other in-flight refactor touches it |
| `dashboard/verify.html` | this refactor | none |
| `dashboard/setup.html` | this refactor | none |
| `dashboard/api-utils.js` | this refactor (additive — adds reporter inside existing default policy) | none — `dirty-state-tracker` (shipped, `db7f637`), `modal-stacking` (shipped, `db7f637`), `trade-ticket-state-sync` (shipped, `efdd44316f`) all touched different blocks of `api-utils.js`; the Trusted Types policy block at lines 404-474 has not been modified by any of those three |
| `tests/dashboard/lint-trusted-types.spec.sh` (new) | this refactor | none |
| `dashboard/event-contract.md` | this refactor (additive — extends HTML-safety section) | none — last touched by `trade-ticket-state-sync` for bus-cache invariant; no overlap |

No conflict with `modal-stacking.md` (different files). No conflict with `dirty-state-tracker.md` (different files). No conflict with `trade-ticket-state-sync.md` (different files; the trade-ticket refactor added `getLastPublished` to the bus, not to the Trusted Types policy block).

## Validation

- **Lint unit (negative):** new fixture file `tests/dashboard/_fixtures/bare-outer-html.js` containing `el.outerHTML = '<x/>'` — `bash scripts/lint-trusted-types.sh` exits 1 with the file:line in stderr.
- **Lint unit (negative):** fixture `_fixtures/bare-iah.js` with `el.insertAdjacentHTML('beforeend', '<x/>')` — exits 1.
- **Lint unit (negative):** fixture `_fixtures/bare-html-block.html` with `<script>el.innerHTML = '<x/>'</script>` — exits 1.
- **Lint unit (positive):** fixture `_fixtures/wrapped-iah.js` with `el.insertAdjacentHTML('beforeend', trustedHTML('<x/>'))` — exits 0.
- **Lint unit (positive — out-of-scope):** fixture `_fixtures/attribute-only.html` with `<button onclick="alert(1)">` and NO `<script>` block — exits 0 (attribute-context handlers are CSP-scope, not Trusted Types-scope).
- **Lint sweep on real tree:** `bash scripts/lint-trusted-types.sh --check` against the post-refactor tree exits 0. (Today, against the unmodified tree but with the broader regex, it exits 1 on the eight `verify.html` + `setup.html` sites — that's the audit step, fixed in this refactor.)
- **Runtime telemetry check:** Playwright spec `tests/playwright/trusted-types-telemetry.spec.js` (new) — load `auth.html` with a forced `default`-policy invocation (e.g., a synthetic `el.innerHTML = '<x/>'` injected via `browser_evaluate`); assert a POST to `/v1/telemetry/client-error` with body containing `type: "trusted_types_violation"` lands within 2 seconds. Use `mcp__playwright__browser_network_requests` to inspect.
- **CSP regression — auth.html:** Playwright spec asserts `auth.html` loads with zero `securitypolicyviolation` console events when Google SSO is initialized. Failure mode being tested: a future CSP regression (e.g., dropping `goog#html` from the allowlist) breaks the SSO bundle's policy creation; the test catches it before merge.
- **Pre-commit hook:** `bash scripts/setup-git-hooks.sh` reinstalls; subsequent `git commit` on a deliberately bad change (add `el.outerHTML = '<x/>'` to `app.js`) is blocked.
- **Existing journey tests** — must continue to pass without modification. The `verify.html` and `setup.html` flows are exercised by the auth-onboarding journey; mechanical wrap shouldn't change rendering.

## Break-even

Status quo: 3 instances across 2 iterations, ~1 hour of patch + verification per instance, plus ongoing console noise on every page load until the violations are individually hunted. Two findings landed in the same iteration, which means this category accelerates under the current convention — every new HTML file or new DOM-sink usage is unguarded. The 4th instance is near-certain because: (a) `verify.html` and `setup.html` already hold eight unwrapped writes that the broadened lint will surface, (b) `api-utils.js`'s default-policy `console.warn` is the only signal we get for new bypasses and that signal never reaches production telemetry. Refactor cost is ~2-3 hours of agent work (lint regex + 8 mechanical wraps + reporter wiring + tests). Pays back on the 4th instance, which is already partly observable today (the 8 unwrapped writes), so the break-even is effectively immediate.

## Reversal path

Single merge SHA. Lint-script changes are ~30 LOC of awk + glob; mechanical to revert. Eight `trustedHTML(...)` wraps in `verify.html` + `setup.html` are mechanical to unwrap (the wrap is identity in browsers without Trusted Types — no behavior change to revert). The reporter addition in `api-utils.js` is one new try/catch block + one event listener (~25 LOC). Total revert is ~15 minutes if the convention turns out to be wrong; the named-policy + lint baseline that exists today remains intact.

## Out of scope

- **Comprehensive XSS audit.** This refactor closes the Trusted Types lint and runtime gaps. It is NOT a top-to-bottom XSS review — the `esc()` helper at `api-utils.js`, the user-data sanitization paths, and the CSP `script-src` allowlist are separate concerns. If a caller passes attacker-controlled HTML through `trustedHTML(...)` without first escaping it via `esc()`, this refactor does not catch that — the named policy is a trust boundary, not a sanitizer (per `api-utils.js:417-420`).
- **CSRF protection.** The `X-Requested-With` header check at `security_middleware.py:194` is owned by the auth team and out of scope here.
- **Authentication / authorization gaps.** Bearer-token validation, session ownership, MFA — all separate.
- **Vendor JS replacement.** `lightweight-charts.standalone.production.js` keeps the `// trusted-types-vendor-allowlist` marker. Replacing the vendor library or wrapping its `innerHTML` write is a separate ticket; for now the marker + default-policy reporter give us a runtime signal if the vendor's behavior changes.
- **Server-rendered HTML safety.** FastAPI templates and Jinja2 escaping (if any) are not touched. The Trusted Types policy operates client-side only.
- **`new Function()` / `eval` / inline event handlers.** The CSP `script-src 'strict-dynamic' 'nonce-...'` directive already blocks these. This refactor does not duplicate that gate.

## Verdict (pending — to be set by next bug-hunt iteration)

Refactor not yet shipped. Per the refactor-gate convention, the next bug-hunt iteration after this refactor merges will retest the three real-broken instances:

- Trusted Types default-policy invocation on dashboard page load (recurrence shape from `20260428T013300Z6e79` — open dashboard, watch console for `[Finlet] Trusted Types default policy invoked`, assert zero matches AND zero `trusted_types_violation` POSTs to `/v1/telemetry/client-error`).
- Google SSO `goog#html` policy creation succeeds on `auth.html` (recurrence shape from `20260428T013300Z6e79` — load auth.html, click "Sign in with Google", assert no `Refused to create a TrustedTypePolicy named "goog#html"` in console).
- Vendor SVG injection no longer triggers the default-policy warning (recurrence shape from `20260428T031818Z2efa` — load any page that mounts a TradingView chart, assert zero default-policy invocations from the vendor file).

If all three pass cleanly with no new failures of the same shape (including no new bare `outerHTML`/`insertAdjacentHTML` slips and no new HTML-file sink slips that the broadened lint should now catch), mark `verdict: effective`. If any of the same shape recurs, mark `incomplete` or `regressed`.
