---
status: shipped
category: multi (dashboard-state-sync, onboarding-checklist, dirty-state-tracker)
drafted: 2026-05-02
drafted_in: refactor-gate-trip-from-pending-recurrences
instances: 3
iterations: [20260501T172055Z127b, 20260501T234103Z1a49]
related_ledger_entries: [edgar-plugin-stale-after-cli-config, profile-checklist-marks-on-persona, settings-dirty-banner-on-cold-load]
trigger: patch-ineffective
shipped_at: 2026-05-02
shipped_in: 5f18f8b (cumulative — Team A merge after Teams B + C; sub-shas: 076189c B, e4cdb5e C, 6c72541 A)
verdict: incomplete
verdict_set_in: 20260502T142726Z7b36
verdict_evidence: |
  Per-category outcome:
    - onboarding-checklist:  effective — zero new instances in 20260502T142726Z7b36 triage.
    - dirty-state-tracker:   effective — zero new instances in 20260502T142726Z7b36 triage.
    - dashboard-state-sync:  incomplete — TWO new instances appeared in this iteration's triage:
        (1) trade-ticket-stale-cash — Trade Ticket Available Cash stays at $100k after
            BUY 10 SPY fills while Key Metrics Cash tile correctly updates to $94,846.45.
            Patch from this iteration's Team A (post-submit refetch + republish) FAILED Phase
            5.5 retest — bus event publishes correctly with post-fill cash, but Trade Ticket
            DOM does not consume it. Filed in pending_recurrences.jsonl as a new
            patch-ineffective signal at deploy_sha=433c01c.
        (2) plugin-health-divergence-settings-vs-dashboard — Settings vs Dashboard reported
            different price-plugin status (Settings degraded / Dashboard healthy). Closed
            this iteration by Team C (canonical /v1/plugins/health). Phase 5.5 retest PASSED.
  Conclusion: the refactor's three named signals (edgar, profile-checklist, settings-dirty-banner)
  did not reappear, so the refactor was correct as-scoped. But the three categories
  it claimed to close still produced new dashboard-state-sync instances — the
  refactor was correct but under-scoped relative to the category-level claim. The
  trade-ticket-stale-cash signal is now the active forward-signal for the next iteration.
verdict_v2: effective
verdict_v2_set_at: 2026-05-05
verdict_v2_set_in: convention-enforcement-2026-05-05
verdict_v2_evidence: "All three refactor-named signals are recorded in pending_recurrences.resolved.jsonl with `resolved_by` referencing this doc: `profile-checklist-marks-on-persona` (onboarding-checklist, iter 20260501T234103Z1a49, resolved 2026-05-02), `settings-dirty-banner-on-cold-load` (dirty-state-tracker, iter 20260501T234103Z1a49, resolved 2026-05-02), and `edgar-plugin-stale-after-cli-config` (dashboard-state-sync, iter 20260501T172055Z127b, resolved 2026-05-02 — sub-shas 076109c B / e4cdb5e C / 6c72541 A under shipped_in 5f18f8b). The forward-signal `trade-ticket-stale-cash` that was active when v1 was set was a separate `dashboard-state-sync` recurrence that this refactor did not target; it was independently closed by trade-ticket-state-sync-v3.1 (commit 8c55a90). Zero new instances of the three refactor-named signals in the ledger across iterations 20260502T142726Z7b36, 20260502T211937Z7ddd, 20260503T030227Z2009, 20260503T195318Z43db, 20260503T230405Z2601, and 20260504T165106Z1ab2 — refactor scope is closed."
verdict_v3: incomplete
verdict_v3_set_at: 2026-05-06
verdict_v3_set_in: 20260506T154910Z0b41
verdict_v3_evidence: "Iteration 20260506T154910Z0b41 produced a new onboarding-checklist cluster instance (`onboarding-wizard-heading-not-repainted`, finding closed by Team A merge `efdbba1`): wizard step heading stayed on the prior step's title because `showStep()` updated dots, lines, and the Next button label from `WIZARD_STEPS` but never repainted the active step's h2. This refactor's onboarding-checklist sub-scope (Signal 2 — `profile-checklist-marks-on-persona`, deleting the unconditional `markStepComplete('profile')` reach-in at `dashboard/onboarding.js:384`) was correct AS scoped (it closed the named reach-in path), and remained closed across all subsequent iterations through 20260506T061637Z6594. But the broader cluster (`onboarding-checklist` category) produced a new instance of a different shape — registry-renderer convergence drift, not reach-in drift. Per refactor-gate convention, ANY new instance of a cluster's category in a subsequent iteration's triage marks the refactor `incomplete` even when the refactor's named signals stayed closed; the under-scope is that the refactor closed reach-in shapes but did not require the renderer to read every registry field on every transition. The new instance was closed in the same iteration as a one-shot fix (~3 lines inside `showStep()`); the under-scope is documented here for the next refactor pass to expand the convention."
---

# Refactor — close 3 patch-ineffective signals from iterations 20260501T172055Z127b + 20260501T234103Z1a49

This refactor closes the three signals still open in
`docs/bug-hunt/pending_recurrences.jsonl` after the 2026-05-01 deploys.
Each signal below is independently scoped so `/plan-features` can split
fixes across teams without coupling them. Team A is api/plugins/cli.
Team B is dashboard.

The verifications under each signal have been done — quoted line
numbers below are from working tree as of `e264d61` (HEAD of `main`).

> **Surprise:** Signal 1's retest was run against `deploy_sha=13af780d`
> (a docs commit on 2026-05-01 that immediately follows commit
> `9c115e6`, the original Team A `[Team A]: EDGAR plugin hot-reload +
> actionable CLI message` patch). The plugin-config-propagation
> *refactor* (commits `57ae3fe` + `fc58c4d`, then doc commit `ab1f438`)
> shipped AFTER `13af780d` and is on `main` today. So the retest
> measured the pre-refactor state, not the refactor's effect. **Before
> committing to the Signal 1 fix scope below, /exec-plan must run the
> retest envelope against `main` first** — if EDGAR comes back
> `healthy`, the refactor was effective and Signal 1 should be closed
> with `verdict_v2: effective` instead of repatched. Scope is provided
> for the residual gap (`plugins remove` subcommand + a real-prod
> retest) which exists either way.

---

## Signal 1: edgar plugin in-process re-init after PUT /settings/plugins

### Why we're here

From `docs/bug-hunt/pending_recurrences.jsonl` line 1:

> "Used working-tree CLI via `uv run python -m finlet plugins add edgar
> --email retest@example.com`. Exit code 0 PASS. Stdout did NOT contain
> 'Restart server to apply' PASS … However, GET /v1/plugins/health 3s
> after add still returns edgar status='unhealthy', message='edgar
> plugin not initialized.', latency_ms=null — so the in-process
> hot-reload assertion FAILS. The 'Restart server' user-facing copy was
> removed but the underlying server-side reinit never happened. Patch
> is partial: copy fix landed, hot-reload behavior did not. Cleanup
> attempted but `plugins remove` subcommand does not exist in working
> tree (no-op)."
>
> patch_iteration_ts: `20260501T172055Z127b`
> deploy_sha: `13af780dff99dcc79a11cbdfdf4cfb600df4ca3c`

### Root cause

Two distinct gaps. The first is a deploy-timing artifact; the second
is a real residual gap in the CLI surface.

1. **Retest measured the wrong revision.** `13af780d` is just docs from
   2026-05-01. The `plugin-config-propagation` refactor (which is what
   was meant to make CLI `plugins add` actually hot-reload the
   in-process plugin) shipped AFTER `13af780d`:
   - `57ae3fe` — Team A merge (`PUT /v1/settings/plugins` returns
     post-reload `PluginHealthItem`; drop `suppress(Exception)`).
   - `fc58c4d` — Team B merge (`finlet plugins add/list` use `PUT
     /v1/settings/plugins`; drop local `~/.finlet/plugins.json`
     writes).
   - `ab1f438` — refactor doc marked shipped.

   The current `main` code paths satisfy the retest's assertions:

   - `finlet/cli.py:306-368` — `plugins_add` requires `FINLET_API_KEY`
     (`cli.py:327-330`), PUTs to `/v1/settings/plugins` with `{plugin,
     api_key, email, enabled}` (`cli.py:339-345`), and prints
     `Plugin '<name>' status: <health.status> — <message>` from the
     response (`cli.py:364-368`). The local `~/.finlet/plugins.json`
     write is gone.
   - `finlet/api/routes_settings.py:128-148` — `PUT /settings/plugins`
     is `Depends(require_user)` and delegates to
     `settings_service.update_plugin`.
   - `finlet/api/services/settings_service.py:212-344` — on a
     credential change (`api_key` or `email`), calls
     `registry.reload(plugin, config[plugin])`
     (`settings_service.py:291`), then `registry.health_check_all()`
     (`settings_service.py:303`), and folds the matching
     `PluginHealth` record into the response under the new `health`
     key (`settings_service.py:333-343`). No more
     `contextlib.suppress(Exception)`.
   - `finlet/plugins/registry.py:680-731` — `reload()` takes
     `_reload_lock`, sets `_initialized=False`, calls
     `plugin.initialize(config)`, and on raised exception restores the
     previous `_initialized` state (`registry.py:710-723`).
   - `finlet/plugins/edgar_plugin.py:76-94` — EDGAR's `initialize()`
     looks up `config.get("identity", config.get("email"))` and
     returns `False` if neither is set (`edgar_plugin.py:87-94`). With
     `email="retest@example.com"` passed through, identity will be
     populated and `initialize()` should set `_initialized=True`.

   This means: against `main`, the assertion ("`GET /v1/plugins/health`
   3s after add returns edgar `status="healthy"`") should now pass.
   The retest envelope below is the single probe that decides whether
   Signal 1 is effective-on-main or whether a residual server-side bug
   exists.

2. **`plugins remove` subcommand doesn't exist** (`finlet/cli.py`
   has only `plugins list` at `cli.py:226-303` and `plugins add` at
   `cli.py:306-368`). The retest cleanup step found this. With the
   refactor in place, the canonical "remove" surface should also go
   through `PUT /v1/settings/plugins` (with empty creds + `enabled:
   False`) — there is no separate DELETE endpoint and the dashboard
   does not have a "remove plugin" button either, so adding a CLI-only
   delete affordance is the simplest closure. This is real residual
   work regardless of (1).

### Refactor scope

Pure CLI + verification. ~1-2 hours of agent work. Smaller than the
original plugin-config-propagation refactor — the unification already
landed.

#### Files touched

- **Verify-only against `main` first:** before any code change, run the
  retest envelope under `### Validation` against `https://finlet.dev`
  with the working-tree CLI. If EDGAR returns `healthy`, do NOT
  modify `settings_service.update_plugin` or `registry.reload` — the
  refactor was effective and the retest measured a stale deploy.
  Surface the prod-deploy timing in the post-merge eval note. Skip the
  CLI-server changes below; just add `plugins remove` and ship.

- **Modified: `finlet/cli.py`** (`plugins_app` Typer group, lines
  ~212-368):
  - Add `@plugins_app.command("remove")` that takes `name: str` arg
    and `api_key: str | None = typer.Option(... envvar="FINLET_API_KEY")`.
  - Body: `httpx.put(f"{_API_URL}/v1/settings/plugins", json={"plugin":
    name, "enabled": False, "api_key": "", "email": ""}, headers=...)`.
    Surface the response's `health.status` / `message` like
    `plugins_add` does.
  - Same `_MISSING_API_KEY_MESSAGE` / `_AUTH_REJECTED_MESSAGE` /
    `httpx.ConnectError` paths as `plugins_add` for symmetry. Reuse
    `_api_headers` and `_print_error`.
  - Docstring: explicit that this clears credentials and disables the
    plugin for the calling user; it does NOT unload the plugin from
    the server-side singleton (multi-tenant limitation already
    documented in `settings_service.py:226-229`).

- **Modified: `finlet/api/services/settings_service.py`**
  (`update_plugin`, lines ~212-344):
  - Defensive: when a caller sends `api_key=""` or `email=""` (the
    "clear" path used by `plugins remove`), the current code stores
    those empty strings into `config[plugin]["api_key"]` /
    `config[plugin]["identity"]` then calls `registry.reload(...)`. For
    EDGAR, an empty identity will cause `initialize()` to return False
    and `health.status=="unhealthy"` — which is exactly the desired
    "removed" state. Document this contract in the docstring (no code
    change needed). Confirms current `settings_service.py:249-256`
    already does the right thing on empty strings.

- **Modified: `tests/test_cli.py`** (`TestPluginsCommands` class, or
  add new `TestPluginsRemoveCommand`):
  - Happy path: `plugins remove edgar` with a stub server returning
    `{"status": "unhealthy", "health": {"status": "unhealthy",
    "message": "EDGAR plugin requires an identity..."}}` — assert exit
    0, stdout contains `Plugin 'edgar' status: unhealthy`. (Status
    "unhealthy" is correct: a removed plugin is unhealthy.)
  - Auth: `plugins remove` without `FINLET_API_KEY` exits non-zero
    with `_MISSING_API_KEY_MESSAGE`.
  - Network error: same coverage as `plugins_add`'s ConnectError test.

- **Modified: `tests/api/test_routes_settings.py`** (existing
  `TestUpdatePluginEndpoint` class):
  - New assertion: `PUT /settings/plugins` with `{plugin: "edgar",
    api_key: "", email: "", enabled: false}` returns 200 with
    `health.status == "unhealthy"` and a non-empty `health.message`.
    The clear-then-unhealthy round trip is the contract the
    `plugins remove` CLI relies on.

- **NOT TOUCHED:** `finlet/api/routes_settings.py`,
  `finlet/api/schemas/settings.py`, `finlet/plugins/registry.py`,
  `finlet/plugins/base.py`, `finlet/plugins/edgar_plugin.py`,
  `dashboard/settings.js`. Confirmed by reading each file at HEAD.

#### File conflict table

| File | Touched by |
|------|-----------|
| `finlet/cli.py` | this refactor (Team A) |
| `finlet/api/services/settings_service.py` | this refactor (docstring only) |
| `tests/test_cli.py` | this refactor (Team A) |
| `tests/api/test_routes_settings.py` | this refactor (Team A) |

No file overlap with Signal 2 or Signal 3 (those are dashboard).

### Validation

Reusable as Phase 5.5 retest envelope verbatim.

- **Retest envelope (decides verdict):**

  ```yaml
  kind: cli-shell
  trigger: |
    export FINLET_API_KEY=$FINLET_TEST_API_KEY
    uv run python -m finlet plugins add edgar --email retest@example.com
  assertions:
    - cli_exit_code == 0
    - stdout contains "Plugin 'edgar' status:"
    - stdout does NOT contain "Restart server to apply"
    - cli_exit_code == 0 AND within 3s of CLI exit, GET https://finlet.dev/v1/plugins/health (Authorization: Bearer $FINLET_TEST_API_KEY) returns a JSON array containing an item where name=="edgar" AND status=="healthy" AND message is null-or-empty
  cleanup:
    - uv run python -m finlet plugins remove edgar  # NEW subcommand from this refactor
    - assert subsequent GET /v1/plugins/health shows edgar status=="unhealthy" with message containing "identity"
  ```

- **Unit (cli):** `plugins remove edgar` invokes `httpx.put` exactly
  once against `/v1/settings/plugins` with body `{"plugin": "edgar",
  "enabled": False, "api_key": "", "email": ""}` and the
  `Authorization: Bearer <FINLET_API_KEY>` header. Exit 0 on 200,
  exit 1 on 401/403, exit 1 on `httpx.ConnectError`, exit 2 if
  `FINLET_API_KEY` unset.

- **Unit (settings_service):** `update_plugin(uid, plugin="edgar",
  email="")` returns `health.status == "unhealthy"`, `health.message`
  contains `"identity"`. No exception escapes.

- **API:** `PUT /v1/settings/plugins` body `{plugin: "edgar", email:
  "", api_key: "", enabled: false}` authenticated → 200 with
  `{status: "unhealthy", plugin: "edgar", health: {status:
  "unhealthy", ...}}`.

---

## Signal 2: onboarding.js:384 unconditional markStepComplete('profile') for existing users

### Why we're here

From `docs/bug-hunt/pending_recurrences.jsonl` line 2:

> "PATCH-INEFFECTIVE. The Settings.js fix (only publish 'profile:saved'
> when display_name AND bio are non-empty) is correct, BUT a second
> code path in dashboard/onboarding.js:384 unconditionally calls
> markStepComplete('profile') for any 'existing user' (any user with
> sessions) inside checkFirstLogin().then(...) — bypassing the
> profile-completeness invariant entirely. Live observation: Settings >
> Profile shows Display Name='' and Bio='' for the test user, yet the
> dashboard 'Set up profile' checklist row carries class
> 'checklist-item--done' and is rendered with a green checkmark.
> Cleared localStorage.finlet_onboarding to all-false steps; reloaded
> /index.html; the row immediately re-flipped to --done with
> localStorage repopulated as {profile:true, session:true,
> analysis:true, strategy:false}."
>
> patch_iteration_ts: `20260501T234103Z1a49`
> deploy_sha: `ab9949d730b56e006e996823f35b065677bda3d1`

### Root cause

Verified at `dashboard/onboarding.js:376-387` (HEAD `e264d61`):

```js
// Show wizard on first login (no wizard previously dismissed, not completed)
if (!state.completed && !state.wizardDismissed) {
    // Check if user has any sessions — if so, skip wizard
    checkFirstLogin().then(isFirstLogin => {
        if (isFirstLogin) {
            showWizard();
        } else {
            // Existing user — mark profile step done at minimum
            markStepComplete('profile');
        }
    });
}
```

The Team D fix in iter `20260501T234103Z1a49` (commit `0ba9b8c` /
merge `4924948`) correctly migrated `CHECKLIST_STEPS[0].trigger` to
`'profile:saved'` and gated `dashboard/settings.js#saveProfile`'s
publish on `display_name && bio` being non-empty
(`settings.js:279-291`). It also removed the `markStepComplete(
'profile')` reach-in from `handleNext()` Step-1 advance
(`onboarding.js:692-705` carries the `NOTE: do NOT mark 'profile'
complete here` comment).

But it did NOT remove the second reach-in at `onboarding.js:384`,
which fires unconditionally for any account with `sessions.length >
0` (`checkFirstLogin` at `onboarding.js:431-440` returns
`sessions.length === 0`). For a test account that has created any
session at all, opening `/index.html` flips
`state.steps.profile = true` regardless of whether
`PUT /v1/settings/profile` ever ran with non-empty fields.

This is a literal recurrence of the same shape Team D was patching:
two code paths claim authority over "profile is complete," and the
fix only updated one of them. It also violates the convention written
into `docs/bug-hunt/refactor-queue/onboarding-checklist.md` line 191:
"the only legal site is the registry's auto-wired subscriber."

### Refactor scope

One file. ~30 minutes of agent work. Pure deletion + a unit test.

#### Files touched

- **Modified: `dashboard/onboarding.js`** (lines 376-387):
  - Delete the `else { markStepComplete('profile'); }` branch
    entirely. The "existing user" path should NOT touch checklist
    state — the registry-driven `profile:saved` subscriber is the only
    legal site that flips this step.
  - Replace with a comment explaining why the branch is intentionally
    empty: "Existing user — do NOT mark profile complete here.
    Profile completeness is owned by `CHECKLIST_STEPS[0].trigger ===
    'profile:saved'`, published from `settings.js#saveProfile` when
    both display_name AND bio are non-empty. Marking on
    'has-sessions' (this branch's old behavior) bypassed that
    invariant. Bug-hunt iter `20260501T234103Z1a49` (Team D) closed
    one of two reach-ins; this closes the second."
  - The `if (isFirstLogin) { showWizard(); }` branch is unchanged.

  Resulting code:

  ```js
  if (!state.completed && !state.wizardDismissed) {
      checkFirstLogin().then(isFirstLogin => {
          if (isFirstLogin) {
              showWizard();
          }
          // Existing user — do NOT touch checklist state here.
          // CHECKLIST_STEPS[0].trigger === 'profile:saved' is the only
          // legal advance for the profile step. See comment block.
      });
  }
  ```

- **Modified: `tests/dashboard/onboarding-checklist.spec.js`**
  (existing node --test file from the onboarding-checklist refactor):
  - New test case: `initOnboarding for existing user (has sessions)
    does NOT mark 'profile' step complete`. Stub `apiFetch('/sessions')`
    to return `[{id: 'sess-1'}]`. Stub `localStorage` `finlet_onboarding`
    to `{steps: {profile: false, session: false, analysis: false,
    strategy: false}, ...}`. Call `initOnboarding`, await microtask
    queue, assert `state.steps.profile === false` and
    `localStorage.finlet_onboarding`'s `steps.profile === false`.
  - New test case: `markStepComplete('profile') only fires from the
    'profile:saved' bus subscriber`. Initialize the registry
    subscribers, publish `'profile:saved'`, assert step ticks.
    Without publish, no other code path (including `checkFirstLogin`
    success → existing-user branch) ticks the step.

- **Modified: `tests/playwright/onboarding-end-to-end.spec.js`**
  (existing Playwright spec):
  - New regression test: load dashboard fresh as existing user with
    one created session, no profile saved (`display_name=''`,
    `bio=''`). Wait 2s. Assert `localStorage.finlet_onboarding`'s
    `steps.profile === false`. Open the checklist (if dismissed by
    fresh load), assert the "Set up profile" row does NOT carry
    `checklist-item--done`.
  - Then navigate to Settings, fill `display_name + bio`, click Save
    Profile, assert the bus publishes `profile:saved`, navigate back
    to dashboard, assert the row IS now `--done`.

- **NOT TOUCHED:** `dashboard/app.js`, `dashboard/checklist.js` (does
  not exist), `dashboard/settings.js`. Confirmed by reading the
  initOnboarding flow at `onboarding.js:359-388`. The original
  pending_recurrences `scope_files` mentioned `app.js` + `checklist.js`
  but neither carries the regressing reach-in. The fix is one branch
  deletion in `onboarding.js`.

#### File conflict table

| File | Touched by |
|------|-----------|
| `dashboard/onboarding.js` | this refactor (Team B) |
| `tests/dashboard/onboarding-checklist.spec.js` | this refactor (Team B) |
| `tests/playwright/onboarding-end-to-end.spec.js` | this refactor (Team B) |

Signal 3 also touches `dashboard/` files — see Team Assignments below
for the within-team merge order.

### Validation

Reusable as Phase 5.5 retest envelope verbatim.

- **Retest envelope:**

  ```yaml
  kind: playwright
  trigger: |
    1. Authenticate as test user with at least one created session.
    2. Verify Settings > Profile shows Display Name='' AND Bio=''.
       If not, edit them empty and save.
    3. Run in DevTools console: localStorage.setItem(
       'finlet_onboarding',
       JSON.stringify({completed: false, persona: null, wizardDismissed: true,
                       checklistDismissed: false,
                       steps: {profile: false, session: false,
                               analysis: false, strategy: false}})
       );
    4. Reload /index.html. Wait 3s for checkFirstLogin() to resolve.
  assertions:
    - "After reload, document.querySelector('[data-checklist-key=\"profile\"]') does NOT carry the class 'checklist-item--done'"
    - "JSON.parse(localStorage.finlet_onboarding).steps.profile === false"
    - "After save with display_name='Test' AND bio='Test bio' on Settings page (which publishes 'profile:saved'), the same selector NOW carries 'checklist-item--done' AND localStorage.steps.profile === true"
    - "0 console errors during the load"
  cleanup:
    - "On Settings > Profile, clear display_name and bio, click Save Profile."
    - "localStorage.removeItem('finlet_onboarding')"
  ```

- **Unit (onboarding-checklist.spec.js):**
  - Stub `apiFetch('/sessions')` → `[{id: 'sess-1'}]`. Stub
    `localStorage` → all-false steps. Call `initOnboarding`. Await
    microtasks. Assert `state.steps.profile === false`.
  - Stub `apiFetch('/sessions')` → `[]`. Call `initOnboarding`. Assert
    `showWizard` was called exactly once and `markStepComplete` was
    NOT called.
  - Publish `'profile:saved'` on the bus. Assert `state.steps.profile
    === true` AND `onboarding:step-completed` was published with
    `{step: 'profile'}`.

- **Playwright (onboarding-end-to-end.spec.js):** described above —
  the existing-user reload test plus the save-flips-row test. Both
  share the same fixture (existing user with one session, empty
  profile).

---

## Signal 3: settings dirty-banner visual rendering on cold load

### Why we're here

From `docs/bug-hunt/pending_recurrences.jsonl` line 3:

> "PATCH-INEFFECTIVE. Cold-loaded /settings.html as logged-in test
> user with no field interaction. The unsaved-changes banner is
> visually rendered: full-page screenshot shows yellow 'You have
> unsaved changes' text with Discard and Save Changes buttons pinned
> to the bottom of the viewport. Element inspection: <div
> id='unsaved-banner' role='status' aria-live='polite'
> aria-hidden='true'> at rect={w:1200, h:51, top:803, bottom:854},
> getComputedStyle => display:flex, visibility:visible, opacity:1.
> The fix attempted to suppress the banner by setting aria-hidden='true'
> (which satisfies assertion 1's 'aria-hidden=true' criterion in
> isolation) BUT the banner is still visually rendered and screen-readable
> to sighted users via Playwright's accessibility tree."
>
> patch_iteration_ts: `20260501T234103Z1a49`
> deploy_sha: `ab9949d730b56e006e996823f35b065677bda3d1`

### Root cause

Verified — multi-axis state drift. Three things must be in sync, but
the visual axis is wrong.

1. **Banner element exists in DOM at all times.** It is
   unconditionally rendered at `dashboard/settings.html:541-545`
   immediately on parse:

   ```html
   <div class="unsaved-banner" id="unsaved-banner"
        data-testid="unsaved-banner"
        role="status" aria-live="polite" aria-hidden="true">
       <span class="unsaved-banner-text">You have unsaved changes</span>
       <button class="btn-settings btn-settings--sm" id="discard-changes-btn" type="button">Discard</button>
       <button class="btn-settings btn-settings--primary btn-settings--sm" id="save-changes-btn" type="button">Save Changes</button>
   </div>
   ```

2. **Visual hide uses `transform: translateY(100%)`.** From
   `dashboard/settings.css:870-891`:

   ```css
   .unsaved-banner {
       position: fixed;
       bottom: 0;
       left: 0;
       right: 0;
       /* ... padding/flex/etc. */
       transform: translateY(100%);  /* parked off-screen */
       transition: transform 0.3s ease;
   }
   .unsaved-banner--visible {
       transform: translateY(0);
   }
   ```

   `translateY(100%)` moves the banner off-screen but does NOT remove
   it from layout, paint, or the accessibility tree. `display: flex`,
   `visibility: visible`, `opacity: 1` remain set. A
   `browser_snapshot` from Playwright reads `role=status` with
   children `'You have unsaved changes'`, `'Discard'`, `'Save
   Changes'` regardless of the transform state.

3. **The Team C aria-hidden sync (commit `87a37b6`) is correct as far
   as it goes** — `dashboard/form-dirty-tracker.js:77-92` toggles
   `aria-hidden` in lockstep with `.unsaved-banner--visible`. But
   aria-hidden alone does not stop accessibility-tree readers from
   surfacing the text; it stops *announcement* by screen readers but
   not *exposure*. Playwright's accessibility tree (used by
   `browser_snapshot`) honors `aria-hidden` only at the
   subtree-suppression level, and even then only consistently in
   recent versions; the bug-hunt blind agent's snapshot tooling read
   the text anyway.

The fix is to make the visual hide do what the aria-hidden tries to
do: actually remove the element from layout/paint AND the
accessibility tree when not dirty. Three options:

   a. Replace `transform: translateY(100%)` with `display: none`
      (when not `--visible`) — kills layout AND a11y-tree exposure.
      Loses the slide-up transition. Trivial fix.

   b. Combine `transform: translateY(100%)` + `visibility: hidden`
      (with `transition` on visibility delayed until after the
      transform completes for the show direction, or
      `pointer-events: none`). Keeps the transition. More CSS.

   c. Don't render the banner at all unless dirty — gate the
      `<div id="unsaved-banner">` insertion on the form-tracker's
      first dirty event. Requires moving from a static HTML block
      to a JS-injected one.

Option (a) is the smallest, most reversible change and matches the
"banner appears only when dirty" mental model. Option (b) preserves
the slide animation, which has zero functional value on a banner
that should literally never appear cold. Option (c) is over-engineered
for a static element.

This refactor picks **option (a) with `pointer-events: none`** as a
belt-and-suspenders fallback in case some browser keeps painting at
`display: none`. The `display: none` form already removes the element
from the accessibility tree per WAI-ARIA spec.

### Refactor scope

One file primary, one file ancillary. ~45 minutes of agent work.

#### Files touched

- **Modified: `dashboard/settings.css`** (lines 870-891):
  - Replace the `.unsaved-banner` rule's `transform: translateY(100%)`
    with `display: none` (default-hidden). Drop the `transition:
    transform 0.3s ease` (no transition needed when toggling
    `display`). Preserve all positioning / flex / spacing properties
    when `--visible` is set.
  - Replace `.unsaved-banner--visible { transform: translateY(0); }`
    with `.unsaved-banner--visible { display: flex; }`.
  - Add `.unsaved-banner { pointer-events: none; } .unsaved-banner--visible
    { pointer-events: auto; }` belt-and-suspenders so any browser
    that paints `display:none` still can't focus the buttons.

- **Modified: `dashboard/form-dirty-tracker.js`** (lines ~77-92,
  `_updateBanner`):
  - No code change required. The existing `classList.toggle(
    'unsaved-banner--visible', visible)` already drives the new CSS
    correctly. The aria-hidden sync stays — it's defense-in-depth
    even though `display:none` already removes from a11y tree.
  - Update the JSDoc comment block at lines 66-76 to reflect that
    the visual hide is now `display: none` (not `translateY`), and
    that `aria-hidden` is the secondary safety net.

- **Modified: `dashboard/settings.html`** (lines 524-540):
  - Update the inline IMPORTANT block above the `<div
    id="unsaved-banner">` to describe the new
    visual-hide-via-display-none invariant. The `data-testid` and
    role/aria attributes are unchanged.

- **Modified: `tests/playwright/settings-dirty-banner.spec.js`** (or
  new file if the existing one targets a different shape):
  - Cold-load `/settings.html` as authenticated test user. Wait 2s
    (form-tracker init + rAF re-snapshot). Assert:
    - `getComputedStyle(unsavedBanner).display === 'none'`
    - The accessibility-tree snapshot does NOT contain "You have
      unsaved changes" (Playwright's `getByRole('status')` returns
      empty for the banner's role).
    - `unsavedBanner.matches(':focus-within') === false` (no
      focusable descendant).
  - Edit a profile field (e.g. `display_name`). Assert within 200ms:
    `getComputedStyle(unsavedBanner).display === 'flex'`. Snapshot now
    finds the banner text. Discard button is reachable via Tab.
  - Click Discard. Assert banner returns to `display: none`.
  - Click Save (no edits — should be a no-op no-banner round trip).
  - Edge: theme card click + frequency option click (synthetic-key
    paths) at cold load do NOT trip the banner during init guard.
    Existing dirty-state-tracker v2 test already covers this; verify
    it still passes.

- **NOT TOUCHED:** `dashboard/settings.js` (the consumer is
  unchanged), `dashboard/form-dirty-tracker.js` core logic (still
  toggles the same class).

#### File conflict table

| File | Touched by |
|------|-----------|
| `dashboard/settings.css` | this refactor (Team B) |
| `dashboard/form-dirty-tracker.js` | this refactor (docstring only) (Team B) |
| `dashboard/settings.html` | this refactor (comment update only) (Team B) |
| `tests/playwright/settings-dirty-banner.spec.js` | this refactor (Team B) |

Signal 2 touches `dashboard/onboarding.js` + tests; this signal touches
`dashboard/settings.css` + `settings.html` + `form-dirty-tracker.js`
docstring. **Zero file overlap with Signal 2** — both can land in the
same Team B worktree merged in either order. See Team Assignments.

### Validation

Reusable as Phase 5.5 retest envelope verbatim.

- **Retest envelope:**

  ```yaml
  kind: playwright
  trigger: |
    1. Authenticate as test user (any account with non-empty profile).
    2. Cold-load https://finlet.dev/settings.html in a fresh tab.
    3. Wait 3s for form-tracker init + rAF re-snapshot.
    4. Take browser_snapshot of the page.
  assertions:
    - "getComputedStyle(document.getElementById('unsaved-banner')).display === 'none'"
    - "browser_snapshot text content does NOT contain 'You have unsaved changes'"
    - "browser_snapshot text content does NOT contain 'Discard'"
    - "browser_snapshot text content does NOT contain 'Save Changes' (other than as a section button label, not the banner button)"
    - "Tab-key navigation through the page does NOT focus #discard-changes-btn or #save-changes-btn while no field is dirty"
    - "After typing into #profile-name (a tracked field), within 200ms getComputedStyle(unsavedBanner).display === 'flex' AND browser_snapshot now contains 'You have unsaved changes'"
    - "After clicking #discard-changes-btn, getComputedStyle(unsavedBanner).display === 'none' again"
    - "0 console errors during the entire flow"
  cleanup:
    - "Click #discard-changes-btn if banner is visible"
    - "navigate away or close tab"
  ```

- **Playwright (existing settings-dirty-banner / new spec):**
  - Cover the assertions above plus the synthetic-key edge cases
    (theme card, email-frequency option) — these continue to fire
    `setFieldDirty` only when not in `_loaderUpdating` guard, so cold
    load should keep the banner at `display: none`.

- **Unit (form-dirty-tracker tests):** existing tests for
  `_updateBanner` continue to pass — they assert `classList.toggle`
  behavior, which is unchanged. The CSS change is invisible to the
  tracker module.

---

## Team Assignments

Two parallel teams, no inter-team file conflicts.

### Team A — api / plugins / cli

**Owns:** Signal 1.

**File ownership (per `.claude/rules/file-ownership.md`):**
- `finlet/cli.py` → api team
- `finlet/api/` → api team
- `tests/test_cli.py` → api team
- `tests/api/` → api team

**First action:** run the Signal 1 retest envelope against `main` (no
code change yet). The plugin-config-propagation refactor is already on
main (`57ae3fe` + `fc58c4d`); the original retest at `13af780d`
measured the pre-refactor state. If EDGAR returns `healthy`, mark the
plugin-config-propagation refactor `verdict: effective` in
`docs/bug-hunt/refactor-queue/plugin-config-propagation.md` and ship
ONLY the `plugins remove` subcommand + tests. If EDGAR still returns
`unhealthy`, file a fresh root-cause investigation (the refactor scope
above retains the `update_plugin` defensive contract notes for that
case).

**Files this team writes:**
- `finlet/cli.py` (add `plugins_remove` command)
- `finlet/api/services/settings_service.py` (docstring only)
- `tests/test_cli.py` (new test class)
- `tests/api/test_routes_settings.py` (new assertions)

### Team B — dashboard

**Owns:** Signals 2 + 3.

**File ownership (per `.claude/rules/file-ownership.md`):** all
`dashboard/` files plus `tests/dashboard/` and
`tests/playwright/` for dashboard shapes.

**Within-team file map (zero overlap between sub-tasks):**

- Signal 2 touches:
  - `dashboard/onboarding.js`
  - `tests/dashboard/onboarding-checklist.spec.js`
  - `tests/playwright/onboarding-end-to-end.spec.js`
- Signal 3 touches:
  - `dashboard/settings.css`
  - `dashboard/settings.html` (comment-only)
  - `dashboard/form-dirty-tracker.js` (JSDoc-only)
  - `tests/playwright/settings-dirty-banner.spec.js`

The two signals share no files. /exec-plan can run them as two
parallel agent worktrees within Team B and merge in either order
without conflict — or sequentially in one worktree if the planner
prefers a single PR. **Recommended:** two worktrees, one PR per
signal, parallel execution. Merge gate is per-signal (each is a
separate retest envelope), so coupling them in a single PR adds risk
without saving review effort.

### No third team needed

Signal 1's CLI surface is owned by api team per `.claude/rules/
file-ownership.md` ("`finlet/cli.py` → api"). The plugin code
(`finlet/plugins/`) is NOT touched by this refactor — the existing
`registry.reload` + EDGAR `initialize` paths already do the right
thing. No plugins-team coordination required.

---

## Out of scope (explicit acknowledgements)

- **`POST /v1/plugins/{name}/reload` deprecation.** It still exists
  for ops/debugging callers and is documented in
  `finlet/api/routes_health.py` as the no-config-change kicker. Not
  removing it in this refactor.
- **Dashboard "remove plugin" UI.** The dashboard's plugins tab does
  not have a remove button. Adding one is a separate dashboard scope;
  the CLI `plugins remove` subcommand here is the parity surface for
  scriptable cleanup, not the user-facing UI.
- **Multi-tenant plugin isolation.** EDGAR's `set_identity()` is
  still process-global. The existing `settings_service.py:226-229`
  docstring documents the limitation. Not addressed here.
- **Banner slide-up animation.** Replacing `translateY` with
  `display: none` removes the 0.3s transition. The banner now
  appears/disappears instantly. Net UX is better — the banner should
  never appear cold, so the animation was hiding a bug, not improving
  a feature.
- **Onboarding wizard auto-advance for non-first-login users.** The
  `if (!state.completed && !state.wizardDismissed)` outer gate plus
  `checkFirstLogin` correctly ensures the wizard only opens for
  brand-new users. Removing the existing-user `markStepComplete`
  reach-in does NOT change wizard visibility — the wizard still does
  not appear for existing users. The only change is that the profile
  step does not auto-tick.

## Verdict (pending — to be set by next bug-hunt iteration)

For each signal, the next bug-hunt iteration's Phase 5.5 retest will
run the envelope under that signal's `### Validation`. If all three
pass cleanly with no new patch-ineffective signals in the same
category (`dashboard-state-sync`, `onboarding-checklist`,
`dirty-state-tracker`), each signal gets `verdict: effective`. If any
recurs, that signal gets `incomplete` or `regressed` and the
post-mortem documents which sub-axis survived.

Special-case for Signal 1: if Team A's pre-refactor verification probe
shows EDGAR already healthy on main, the plugin-config-propagation
refactor's verdict gets set to `effective` in its own file in the same
PR; the residual `plugins remove` work ships under this refactor's
verdict.
