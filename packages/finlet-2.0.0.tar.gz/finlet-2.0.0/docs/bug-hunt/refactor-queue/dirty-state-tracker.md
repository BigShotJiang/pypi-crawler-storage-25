---
status: shipped
shipped_at: 2026-04-28
shipped_in: db7f637 (modal-stacking + dirty-state-tracker chain on main)
category: dirty-state-tracker
drafted: 2026-04-28
instances: 2
iterations: [20260428T031818Z2efa, 20260428T163727Z4f4f]
verdict: incomplete
verdict_set_at: 2026-04-29
verdict_set_in: 20260429T052717Z1a13
verdict_evidence: "settings-dirty-banner recurred this iteration (forward signal `same_root_cause_as: settings-dirty-banner-onload`); the per-loader snapshot pattern was correct in concept but the gate at `settings.js:23-59` only awaited 3 of 6 loaders. Team A patch (`31c3255`) extends `Promise.allSettled` to all 6. Pattern is sound; enumeration was incomplete."
verdict_v2: effective
verdict_v2_set_at: 2026-04-29
verdict_v2_set_in: 20260429T232205Z17ff
verdict_v2_evidence: "v2 (ed15c6c) verified to cover Plugins-tab cold-load on main. Blind agent's recurrence report was a deploy-lag artifact (last successful prod deploy 2026-04-28T23:21Z, before v2 shipped). New regression test in b758698 prevents future regression. Plugins-tab inputs intentionally have no `id` so they're correctly excluded from the dirty-state graph."
verdict_v3: effective
verdict_v3_set_at: 2026-05-05
verdict_v3_set_in: convention-enforcement-2026-05-05
verdict_v3_evidence: "v3 (commit 87a37b6) closed the third axis — aria-hidden sync on `.unsaved-banner` plus the synthetic-key `setFieldDirty(_loaderUpdating)` guard at `dashboard/form-dirty-tracker.js:259-267`. Latest dirty-state-tracker ledger entry is `settings-dirty-banner-onload` (iter 20260501T234103Z1a49, commit 87a37b6); zero new entries in subsequent iterations 20260502T142726Z7b36, 20260502T211937Z7ddd, 20260503T030227Z2009, 20260503T195318Z43db, 20260503T230405Z2601, and 20260504T165106Z1ab2. close-patch-ineffective-2026-05-02 (commit e4cdb5e) further reinforced the visual hide via `display:none`; the in-code state of the loader-update guard at form-dirty-tracker.js:259-267 plus the four-iteration ledger gap confirms the cluster is closed."
---

# Refactor — Dirty-state tracker convention

## Why we're here

Two real-broken instances of the same shape across two iterations:

1. `settings-dirty-banner-onload` (commit `c82caca`, iter `20260428T031818Z2efa`) — Settings page Profile tab fires "You have unsaved changes" banner on every load before any user input. False-positive dirty state. Patched with a one-frame rAF deferral (commit `1f9c126`).
2. Plugins-tab dirty banner (iter `20260428T163727Z4f4f`) — same banner fires on initial Plugins page load with zero user interaction, plus the Discard button is positioned offscreen ("element is outside of the viewport" per Playwright). Yesterday's rAF fix is live but doesn't cover this loader race.

Same shape: form-dirty tracker captures `originalValues` baseline before async loaders populate fields. After loaders complete, fields differ from baseline → tracker reports dirty → banner fires. The Profile-tab fix patched the symptom (one specific loader) without fixing the convention. The Plugins tab uses a slower async chain and the rAF deferral isn't enough.

## Root cause

The form-dirty tracker treats the form as a synchronous unit: snapshot once at mount, compare on every input change. Async loaders that populate fields after mount are an unmodeled state. The fix path "wait one frame longer" doesn't generalize because each loader has a different async depth.

There's also a separate-but-related bug: the Discard button is `position: absolute` relative to the form, so on tall forms it can scroll off-viewport. Users can't discard their changes if they don't know the button is below the fold.

## Refactor scope

One team. One worktree. ~1.5-2 hours of agent work (smaller than modal-stacking — it's mostly settings.js and one CSS change).

### Files touched

- **Modified: `dashboard/settings.js`** — replace single-shot `originalValues = readForm()` with a per-loader snapshot pattern. Each `await apiFetch(...)` call inside a loader appends the loaded fields to `originalValues` only after resolve. Concretely:
  ```js
  // Before (current pattern):
  async function loadProfile() {
    const data = await apiFetch('/profile');
    document.getElementById('name').value = data.name;
    // ... set other fields ...
    // (originalValues was captured BEFORE this loader ran — now stale)
  }

  // After (refactor pattern):
  async function loadProfile() {
    const data = await apiFetch('/profile');
    document.getElementById('name').value = data.name;
    // ... set other fields ...
    snapshotFields(['name', 'email', 'timezone']);  // declare which fields this loader owns
  }
  ```
  Each loader explicitly declares which fields it owns; `snapshotFields(ids)` reads those fields' current values into `originalValues` and marks them clean.
- **Modified: `dashboard/settings.js`** — Discard button positioning fix: replace `position: absolute` (relative to form) with a sticky bar inside the page chrome (sticky to the bottom of the viewport while the form is dirty). The bar is hidden when no fields are dirty.
- **Modified: `dashboard/styles.css`** — sticky discard-bar styles.
- **Optional (recommended):** extract the dirty-tracker into `dashboard/form-dirty-tracker.js` so the convention applies across pages, not just Settings. If extracted, both Profile and Plugins tabs (and any future settings page) use the same `snapshotFields()` API.

### File conflict table

| File | Touched by |
|------|-----------|
| `dashboard/settings.js` | this refactor |
| `dashboard/form-dirty-tracker.js` (new, optional) | this refactor |
| `dashboard/styles.css` | this refactor (sticky discard bar) |

No conflict with `modal-stacking.md` queue doc (different files).

## Validation

- **Cold load — Profile tab:** open Settings → Profile, wait 1s, assert no "unsaved changes" banner. Open browser console, assert no errors.
- **Cold load — Plugins tab:** open Settings → Plugins, wait 1s, assert no banner.
- **User edit:** load Profile tab, modify the `name` field, assert banner appears within 200ms.
- **Discard reachable:** load any tab with a tall form, modify a field at the top, scroll halfway down, assert Discard button is in viewport (sticky bar visible).
- **Save flow:** modify a field, click Save Changes, assert banner disappears, assert subsequent reload starts clean.
- **Playwright regression:** add a test that loads each settings tab cold and asserts no banner within 1s.

## Break-even

Status quo: 2 instances; settings.js is the only tracker site today, but every future settings-style page would inherit the same bug. The refactor is small (one or two files) but the convention extension is the real value — declaring "this loader owns these fields" makes the bug class structurally impossible.

## Reversal path

Single merge SHA. Settings.js diffs are mechanical; the optional extraction is rebuildable. Revert is ~15 minutes.

## Out of scope

- Per-field validation (separate concern; doesn't interact with dirty-state).
- Optimistic save / debounced autosave — the refactor preserves the explicit "Save Changes" button flow.
- Cross-page dirty-state (e.g., warning when navigating away with unsaved changes) — separate feature; can build on this convention later.

## Verdict (pending — to be set by next bug-hunt iteration)

Refactor merged. Per the refactor-gate convention, the next bug-hunt iteration will retest the two real-broken instances:

- Profile-tab cold-load false positive (recurrence shape from `20260428T031818Z2efa` — Settings → Profile, wait 1s, no "unsaved changes" banner expected)
- Plugins-tab cold-load false positive (recurrence shape from `20260428T163727Z4f4f` — Settings → Plugins, wait 1s, no banner expected)

If both pass cleanly with no new failures of the same shape, mark verdict: `effective`.
If any of the same shape recurs, mark `incomplete` or `regressed`.

## Recurrence — bug-hunt 20260501T234103Z1a49 (2026-05-01)

- Finding: Settings page shows "You have unsaved changes" banner on cold load before any user interaction (`finding_id: settings-dirty-banner-onload`).
- Same root cause as prior closed finding: `settings-dirty-banner-onload` (iter `20260428T031818Z2efa`) and `settings-dirty-banner-synthetic-key-flash` (iter `20260430T222711Z3666`).
- Patched by: Team C (commit `87a37b6`) — two gaps closed together: (a) the banner is visually hidden via CSS `transform: translateY(100%)` which leaves the element FULLY in the accessibility tree (blind agents and screen readers read it regardless of class state); fix defaults `aria-hidden="true"` on the banner element and toggles aria-hidden in sync with the visible class inside `_updateBanner()`. (b) Synthetic-key dirty paths (theme, email-frequency) called `setFieldDirty(_, true)` from non-input affordances during init without respecting `_loaderUpdating`; fix gates synthetic-key dirty signals on the loader-update guard like DOM-bound fields.
- Implication: prior verdicts (`incomplete` v1 → `effective` v2) covered the loader-enumeration race and the synthetic-key snapshot-clear, but not the accessibility-tree axis. The CSS-only hide pattern is the third dimension of the same bug class — visual, dirty-state, and accessibility-state must all be toggled in sync. Consider expanding the next refactor pass to either: (1) a lint check that flags `transform: translateY` / `opacity: 0` / `visibility: hidden` on banner-class elements without a paired `aria-hidden` attribute, OR (2) extracting an `unsaved-banner.js` module that owns the visibility-class + aria-hidden toggle pair as one atomic operation. Pattern is sound across multiple iterations; the convention surface needs one more axis.
