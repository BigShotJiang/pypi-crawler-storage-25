---
category: aria-label-mismatch
status: shipped
instances: 2
iterations: 2
latest_instance: shared-nav-collapsed-label-stale
drafted: 2026-05-06
shipped: 2026-05-07
shipped_in: b9ccf4a
verdict:
source_handoff: docs/bug-hunt/HANDOFF.md
triggered_by: pending_recurrences.jsonl entry shared-nav-collapsed-label-stale (iteration 20260506T185234Z542e)
---

# Refactor — API-key affordance label (single source-of-truth across desktop user-menu + mobile nav drawer)

## Why we're here

Two real-broken instances of the same shape across two consecutive bug-hunt iterations, both on user-visible labels that drift from their actual click semantics:

1. `freeze-btn-visible-text-stale` — iter `20260505T234713Z0c8a`, commit `c6b72a7`. Clock-mode handler updated `freezeBtn.aria-label` but not `textContent`; visible label stuck at "Freeze" while `mode=frozen`. Patched in-place on `dashboard/app.js` + `dashboard/index.html`. Different surface than the API-key affordance, same shape: two label sites for one affordance, one updated, one not.
2. `shared-nav-collapsed-label-stale` — iter `20260506T185234Z542e`, commit `74a368c`. The previous iteration's fix (`docs/decisions/copy-api-key-dead-affordance.md` addendum, 2026-05-06) extracted `_relabelCopyApiKeyButton(button)` and called it from `_initSharedUserMenu()` on mount AND from the trigger's open-branch — but only for `#menu-copy-key` (the desktop user-menu button rendered by `_buildHeaderHTML` in `dashboard/shared-nav.js:198`). The parallel `#nav-drawer-copy-key` button, which lives in **static HTML across 4 pages** (`dashboard/index.html:68`, `dashboard/billing.html:63`, `dashboard/leaderboard.html:62`, `dashboard/settings.html:63`) plus a `.click()` proxy in `dashboard/mobile-nav.js:175-195` (with its own hardcoded `'Copy API Key'` reset literal at `mobile-nav.js:188`), was never relabeled. Retest evidence (`pending_recurrences.jsonl`): "Assertion A1 FAILS: collapsed-state accessible name = 'Copy API Key' (must NOT equal 'Copy API Key'). … the parallel `nav-drawer-user` surface (`#nav-drawer-copy-key`) was missed and still ships the stale 'Copy API Key' static markup."

Same shape across both: a visible-text label and an accessible-name label live at multiple DOM sites for the same affordance, hand-maintained string-literal copies in HTML/JS files. Each patch updates one site; the other sites drift independently. Team B's 2026-05-06 fix was correct in shape (extract helper, call on mount + open) but scoped to one of the two parallel surfaces. The bug recurred in the same iteration's retest.

A 3rd instance is the near-certainty under the current convention. The next time someone adds a new dashboard page (or a new affordance whose label tracks auth state), the static HTML literal and the JS render path drift again. The two-surface split is the structural-blind-spot signature.

## Root cause

The "API-key affordance label" has **two unrelated rendering paths** that both claim authority over the user-visible text:

1. **JS-rendered** (`#menu-copy-key`, desktop user-menu): `_buildHeaderHTML()` in `dashboard/shared-nav.js:198` writes the literal `'Copy API Key'` into the button's `textContent` at construction time. `_relabelCopyApiKeyButton()` (`dashboard/shared-nav.js:417-422`) is a one-line override that reads `FinletAuth.getApiKey()` and writes the correct label. It is called from two sites: `_initSharedUserMenu()` line 288 (initial mount) and the trigger click handler line 298 (gated on `if (isOpen)`).
2. **Static HTML** (`#nav-drawer-copy-key`, mobile nav drawer): four separate HTML files (`dashboard/{index,billing,leaderboard,settings}.html`) each carry a `<button … id="nav-drawer-copy-key">Copy API Key</button>` literal in the page source. **No JS hydration runs** to relabel these on mount. The mobile drawer click handler in `dashboard/mobile-nav.js:175-195` proxies to the desktop button via `desktopCopyKey.click()` — but the proxy fires the desktop button's CLICK behavior, NOT its label. The drawer button's own `textContent` is never read by `_relabelCopyApiKeyButton()` (which hard-targets `#menu-copy-key`). Worse, `mobile-nav.js:188` carries a SECOND hardcoded literal `'Copy API Key'` used as a clipboard-success-toast reset — a third site that drifts independently.

Three things conspire:

- **No render contract.** The drawer button's label is plain HTML in four files. There is no helper that owns "what label goes on a button whose semantics depend on `FinletAuth.getApiKey()`." Each new page must remember to import the right shared script AND somehow run the relabel — and today neither happens.
- **`_relabelCopyApiKeyButton()` hard-codes `getElementById('menu-copy-key')`.** It has no parameter for "which button id to relabel" — it cannot be reused for the drawer button without a signature change. The handoff sketches `_relabelCopyApiKeyButton(button)` taking a parameter; the current code does not accept one.
- **The `if (isOpen)` gate at `shared-nav.js:298`.** The handoff calls this out as the original bug site. It is no longer the active bug — the mount-time call at line 288 already exists (Team B's 2026-05-06 fix). But the gate is still there as dead-weight: the relabel is idempotent, and the open-branch can call it unconditionally (or, after this refactor, the bus-driven re-render replaces it entirely).

Result: any page that ships a `nav-drawer-copy-key` button (4 today; N tomorrow as new pages are added) carries a misleading collapsed-state label on cookie-session auth from page load until — never. The label is never corrected because nothing runs to correct it.

## Files

Verified against HEAD (`d4e847c`). All paths and line numbers checked via `grep` + targeted reads on 2026-05-06.

- **`dashboard/shared-nav.js`** — `_buildHeaderHTML` literal at line 198 (`'<button … id="menu-copy-key">Copy API Key</button>'`). Helper `_relabelCopyApiKeyButton()` at lines 417-422. Two call sites: line 288 (mount, in `_initSharedUserMenu`) and line 298 (trigger click open-branch, gated on `if (isOpen)`). The helper hard-codes `getElementById('menu-copy-key')` and writes `textContent`.
- **`dashboard/mobile-nav.js`** — `drawerCopyKey = document.getElementById('nav-drawer-copy-key')` at line 34. Click handler at lines 175-195: proxies to `desktopCopyKey.click()` (line 180) and on the fallback path resets the drawer button's `textContent = 'Copy API Key'` at line 188 after clipboard write. Drawer button's label is otherwise never relabeled.
- **`dashboard/index.html`** — `<button class="nav-drawer-action" id="nav-drawer-copy-key" type="button">Copy API Key</button>` at line 68. Inside the static `<div id="nav-drawer">…</div>` block.
- **`dashboard/billing.html`** — same literal at line 63.
- **`dashboard/leaderboard.html`** — same literal at line 62.
- **`dashboard/settings.html`** — same literal at line 63.
- **`tests/dashboard/shared-nav.spec.js`** — 8 `node --test` cases pinning `_relabelCopyApiKeyButton` against `#menu-copy-key` only. Tests 1-4 exercise the helper in isolation; tests 5-8 exercise it through `_initSharedUserMenu`. No coverage of `#nav-drawer-copy-key`.
- **`tests/e2e/journey-shared-nav.spec.ts`** — single Playwright test asserting cookie-session-path collapsed AND expanded `#menu-copy-key` reads "Manage API Key", and clicking navigates to `settings.html#api-keys`. No assertion on `#nav-drawer-copy-key`.
- **`tests/e2e/journey-09-mobile.spec.ts`** — line 60 asserts `#nav-drawer-copy-key` is visible (existence only); no label assertion.

Decision-record reference (load-bearing): `docs/decisions/copy-api-key-dead-affordance.md` — main record (2026-05-03) + addendum (2026-05-06). The dual-label semantics ("Copy API Key" when client has the key in memory; "Manage API Key" otherwise) is intentional and security-load-bearing. The refactor MUST preserve those semantics; only the unification of surfaces changes.

## Proposed shape

**One team. One worktree. ~2-3 hours of agent work.** The surface area is `dashboard/shared-nav.js` + `dashboard/mobile-nav.js` + 4 HTML literal edits + tests. No new module file required.

### Recommended option: parameterize the existing helper + drive both surfaces from a single bus subscriber

Two competing options were considered (handoff sketches both):

**Option A (recommended):** Keep the helper in `dashboard/shared-nav.js`. Change the signature from `_relabelCopyApiKeyButton()` (zero params, hard-coded id) to `_relabelCopyApiKeyButton(buttonOrId)` (accepts an element OR an id). Add a new `_relabelAllApiKeyAffordances()` umbrella that iterates a known id list (`['menu-copy-key', 'nav-drawer-copy-key']`) and calls the helper for each. Wire the umbrella to:
  1. Run on `_initSharedUserMenu()` mount (replaces the current line-288 call). Both buttons relabel before any user interaction.
  2. Run on `initMobileNav()` mount (new call, mirrors the desktop mount-time call). Same effect for pages where mobile nav initializes after shared nav.
  3. Subscribe to `auth:state-change` on `window.finletBus` (an event the auth module already publishes when `saveAuth` / `logout` / `setApiKey` mutate the in-memory key state — verify the event name during plan-features Step 1; if it doesn't exist, add a publisher in `dashboard/auth.js` as part of this refactor). The subscriber re-runs the umbrella so any auth-state mutation (signup, logout, key rotation) repaints both surfaces atomically without requiring page reload.
  4. Delete the `if (isOpen)` gate at `shared-nav.js:298` (and the per-open relabel call) — the bus subscriber covers any case where a key is minted between page load and menu open.

In `dashboard/mobile-nav.js`, replace the hardcoded `'Copy API Key'` reset literal at line 188 with a call to `_relabelCopyApiKeyButton(drawerCopyKey)` — eliminates the third drift site.

The static HTML `<button … id="nav-drawer-copy-key">Copy API Key</button>` literals across the 4 pages can stay as-is (the umbrella's mount-time pass overrides the literal before paint), OR be changed to a placeholder textContent (e.g., `aria-busy="true"` and empty textContent until hydration). Recommend leaving the literal as a graceful-degradation fallback for the case where JS fails to load — "Copy API Key" is the wrong label on cookie-session paths but it is at least a label that doesn't read as broken.

**Option B (rejected):** New module `dashboard/api-key-affordance.js` with the same logic. Same blast radius (still must edit `shared-nav.js` to drop the existing helper + bus wiring, still must edit `mobile-nav.js` to call the new module, still must edit 4 HTML files if static literals are removed). One additional file to load via `<script>` tags in 4 HTML pages — net cost is +1 file + 4 script-tag edits for zero behavior gain. Rejected: the existing helper is already in `shared-nav.js`, both surfaces (`#menu-copy-key` and `#nav-drawer-copy-key`) are already coupled to shared-nav (the desktop button via `_buildHeaderHTML`, the drawer button via `mobile-nav.js`'s `.click()` proxy at line 180). Keeping the umbrella in `shared-nav.js` keeps related code colocated and avoids the script-tag plumbing.

Option A wins on smaller blast radius and avoids creating a new top-level module that the dashboard team would have to thread through every new page's `<head>` block.

### Net behavior

Identical on both auth paths today + correct on the cookie-session path for the drawer button (the regression). Adding a 3rd surface in the future is one entry in the umbrella's id list; adding a 5th dashboard page is zero edits to the affordance code (the umbrella runs on mount and finds whatever ids are present in the DOM). The `auth:state-change` subscriber pattern matches the established `dashboard/event-bus.js` convention (see `docs/decisions/dashboard-event-bus.md`).

## Constraints

- **Dual-label semantics are load-bearing.** From `docs/decisions/copy-api-key-dead-affordance.md` (main record + 2026-05-06 addendum): the button shows "Copy API Key" when `FinletAuth.getApiKey()` returns a non-null key (clipboard-write affordance, signup/just-rotated path); it shows "Manage API Key" when `getApiKey()` returns null (redirect-to-Settings affordance, cookie-session path). The hash-only key storage invariant (server stores key hashes; cleartext is unrecoverable post-handshake by design) is the security property that forces the dual semantics. The refactor MUST preserve which label shows when. Only the unification of surfaces changes.
- **File ownership.** All affected files live under `dashboard/` (`shared-nav.js`, `mobile-nav.js`, four `.html` files) and `tests/{dashboard,e2e}/`. Per `.claude/rules/file-ownership.md`, this is the **dashboard team**'s domain. There is no separate "shared-nav" team — `dashboard/` is one ownership boundary.
- **Event bus.** All cross-component dashboard wiring goes through `window.finletBus` per `CLAUDE.md`. The `auth:state-change` subscription must be added via `bus.subscribe(event, handler) → unsubscribe` (NOT `addEventListener('finlet:…')`) and the unsubscribe handle must be retained for cleanup. Pre-commit hook `scripts/lint-event-bus.sh` blocks bare event-bus bypasses under `dashboard/`.
- **Trusted Types.** `_relabelCopyApiKeyButton` already writes via `textContent` (not `innerHTML`), so no `trustedHTML(…)` wrap is required. Keep it that way; pre-commit hook `scripts/lint-trusted-types.sh` blocks bare `.innerHTML =` writes under `dashboard/`.
- **Backwards compatibility on `_relabelCopyApiKeyButton`.** The helper is exposed at sandbox scope (the unit tests in `tests/dashboard/shared-nav.spec.js` call `env.sandbox._relabelCopyApiKeyButton()` with zero arguments). The new signature must accept zero args (defaulting to `#menu-copy-key`) to keep the existing tests green, OR the existing tests must be updated in lockstep. Recommend defaulting to `#menu-copy-key` for the no-arg call — preserves test surface AND adds the parameterized form for the umbrella.
- **No server-side change.** No new endpoint, no destructive action on click. Hash-only key storage invariant preserved end-to-end.

## Validation plan

### Unit (`tests/dashboard/shared-nav.spec.js`)

- **Existing 8 tests must keep passing unchanged.** The no-arg call to `_relabelCopyApiKeyButton()` continues to relabel `#menu-copy-key`.
- **New tests:**
  - `_relabelCopyApiKeyButton('nav-drawer-copy-key')` relabels the drawer button's `textContent` to "Manage API Key" on cookie-session path (apiKey null) and "Copy API Key" on signup path (apiKey non-null).
  - `_relabelCopyApiKeyButton(elementShim)` accepts an element directly (idempotent with the id-string form).
  - `_relabelAllApiKeyAffordances()` iterates the known id list and relabels every present button. Missing ids are no-ops (no throw).
  - The `auth:state-change` bus subscriber, when fired, re-runs the umbrella and repaints both `#menu-copy-key` and `#nav-drawer-copy-key` on the next tick.
  - The `mobile-nav.js` click handler's clipboard-success path calls `_relabelCopyApiKeyButton(drawerCopyKey)` instead of the hardcoded reset literal — verified by asserting the drawer button's textContent equals what the helper would produce for the current auth state, NOT the static `'Copy API Key'` literal.

### E2E (`tests/e2e/journey-shared-nav.spec.ts` — extend the existing single-test spec)

The single test in this file currently asserts ONE surface (`#menu-copy-key`) on ONE auth path (cookie-session). Extend to cover both surfaces × both auth paths × both lifecycle states (collapsed + expanded for the desktop menu; pre-open + post-open for the drawer):

- **Cookie-session path × `#menu-copy-key`:** existing assertions unchanged (collapsed reads "Manage API Key", expanded reads "Manage API Key", click navigates to `settings.html#api-keys`).
- **Cookie-session path × `#nav-drawer-copy-key`:** open hamburger (`#hamburger-btn` click), drawer becomes visible, drawer button reads "Manage API Key" (NOT "Copy API Key" — the regression), click navigates to `settings.html#api-keys`. Assert BEFORE the hamburger is opened the drawer button's textContent is also "Manage API Key" (the static-literal regression: the button is in the DOM from page load).
- **Signup path × `#menu-copy-key`:** with `FinletAuth.setApiKey('k_test_…')` set in a beforeEach hook, button reads "Copy API Key" in both states; click writes to clipboard.
- **Signup path × `#nav-drawer-copy-key`:** same — button reads "Copy API Key" in pre-open AND post-open drawer states; click triggers clipboard write via the desktop proxy.
- **Bus repaint:** with the dashboard loaded on signup-path, simulate a logout (`FinletAuth.logout()` via `page.evaluate`); within 500ms both buttons must repaint to "Manage API Key" without page reload. Pins the `auth:state-change` subscriber.

### Existing E2E tests must keep passing

- `tests/e2e/journey-09-mobile.spec.ts` — line 60 asserts `#nav-drawer-copy-key` visible. Still passes (the button still exists; its label is what changed).
- All `tests/dashboard/*.spec.js` and `tests/e2e/*.spec.ts` — unchanged.

### Lint gates

- `bash scripts/lint-trusted-types.sh` — passes (no new `.innerHTML =` writes).
- `bash scripts/lint-event-bus.sh` — passes (the new bus subscription uses `bus.subscribe`, not `addEventListener('finlet:…')`).

## Break-even estimate

Status quo: 2 instances across 2 iterations, ~1 hour of patch + retest per instance. The 3rd instance is the near-certainty: any new dashboard page that includes the static `<button id="nav-drawer-copy-key">` literal inherits the drift, and any new auth-state-dependent label (e.g. a future "Manage Subscription" / "Upgrade" button on the user menu that varies by tier) inherits the same two-surface split. Both are foreseeable: the post-launch billing page expansion already calls for tier-aware affordances (see `docs/REMAINING_TASKS.md`).

Refactor cost: ~2-3 hours of agent work (parameterize helper + add umbrella + bus subscriber + mobile-nav literal swap + 4 unit tests + extend the journey-shared-nav E2E). Pays back on the 3rd instance, which is observable today as the open `pending_recurrences.jsonl` entry. Break-even is effectively immediate.

### Team split estimate for `/plan-features`

Plan-features will likely split into **2 teams** (NOT 3 — file conflict on `shared-nav.js` argues for sequential merging, not parallel):

- **Team A (JS surface + bus wiring + tests):** owns `dashboard/shared-nav.js` (parameterize helper + umbrella + bus subscriber + delete `if (isOpen)` gate), `dashboard/mobile-nav.js` (replace line-188 literal + add mount-time umbrella call), `tests/dashboard/shared-nav.spec.js` (new test cases), `tests/e2e/journey-shared-nav.spec.ts` (extend coverage).
- **Team B (HTML literal sweep — optional):** owns the 4 `.html` files IF the proposed shape changes the static literals. If the literals stay as graceful-degradation fallbacks (recommended), Team B is unnecessary — fold the work into Team A as a single-merge worktree.

The handoff's "2-3 teams" estimate over-allocates given the recommended shape leaves the HTML literals untouched. Single team A in one worktree is the recommended dispatch — `dashboard/shared-nav.js` is the file every other change reads, and serializing edits there avoids merge conflict.

## Notes for the planner

Findings during HEAD verification (`d4e847c`, 2026-05-06):

1. **`if (isOpen)` gate location drift.** The handoff says "lines 278-294" for the gated relabel. The actual gated call is at `shared-nav.js:298` (inside the trigger click handler). The mount-time call already exists at line 288 (Team B's 2026-05-06 fix is partially shipped — the `_initSharedUserMenu` mount path is correct; only the drawer surface was missed). The gate is now dead weight, not the active bug; the active bug is the drawer button has no relabel path at all.
2. **Third drift site discovered:** `dashboard/mobile-nav.js:188` carries a hardcoded `'Copy API Key'` literal used as a clipboard-success-toast reset (`drawerCopyKey.textContent = 'Copy API Key'` after the 2-second timeout). The handoff did NOT enumerate this site. It is a third place where the label drifts from the dual-semantics contract and must be unified through `_relabelCopyApiKeyButton(drawerCopyKey)`. Without this swap, a signup-path user who clicks the drawer button on a logout-then-signup-cycle within the same page session would see a wrong-state label flash.
3. **`auth:state-change` event existence is unverified.** The proposed shape relies on a bus event that mutates when `FinletAuth.{saveAuth,logout,setApiKey}` runs. Verify this exists at `dashboard/event-contract.md` during plan-features Step 1; if absent, add a publisher in `dashboard/auth.js` as part of this refactor (one-line `bus.publish('auth:state-change', { hasKey: !!_inMemoryApiKey })` after each mutation site). The decision record `docs/decisions/dashboard-event-bus.md` documents the convention.
4. **Static HTML literal across 4 pages is consistent.** All four files use the identical literal `<button class="nav-drawer-action" id="nav-drawer-copy-key" type="button">Copy API Key</button>` at near-identical line offsets (68, 63, 62, 63). No drift in markup shape. Recommendation in the proposed shape leaves these as graceful-degradation fallbacks; if the planner decides to remove them, a single sed-style sweep handles all four atomically.
5. **The earlier `freeze-btn-visible-text-stale` instance** (iter `20260505T234713Z0c8a`, commit `c6b72a7`) was patched in-place on the freezeBtn surface and is NOT a candidate for this refactor's umbrella. It demonstrates the SHAPE (one affordance, two label sites, one updated, one not) but lives on `dashboard/app.js` + `dashboard/index.html` in a different module (clock controls). Listed in the `instances: 2` count for category-recurrence accounting only; the refactor does not touch the freeze button.
6. **Decision-record continuity.** The 2026-05-06 addendum to `docs/decisions/copy-api-key-dead-affordance.md` documents Team B's helper extraction. After this refactor merges, append a SECOND addendum (or revise the existing one) noting that the helper is now parameterized + drives both surfaces + is bus-subscribed, so the surface-set is the closed enum `['menu-copy-key', 'nav-drawer-copy-key']` and adding a new surface is a one-line umbrella-list edit. Decision-record updates fall under the docs team in `.claude/rules/file-ownership.md`; coordinate via the standard PR pattern.

## Shipped

Merged 2026-05-07 in commit `b9ccf4a` on `origin/main` (Team A, single-team single-worktree dispatch as recommended in the team-split estimate above; local pre-rebase SHA was `18f54a8`, rebased on PR merge). The 2026-05-07 addendum at the bottom of `docs/decisions/copy-api-key-dead-affordance.md` documents the parameterized helper, the closed `API_KEY_AFFORDANCE_IDS` enum + umbrella, the `auth:state-change` bus event (7th canonical event in `dashboard/event-contract.md`), and the three-call-site mount + bus-repaint contract. The static HTML literals across `dashboard/{index,billing,leaderboard,settings}.html` were intentionally preserved as graceful-degradation fallbacks per Option A. Verdict left blank — the next bug-hunt iteration's blind walkthrough sets it.
