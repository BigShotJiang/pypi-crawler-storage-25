---
status: shipped
shipped_at: 2026-05-05
shipped_in: f1b3cf7e607198229cdf9de49bb63581c636470d
team_a_commit: f1b3cf7e607198229cdf9de49bb63581c636470d
team_b_commit: ae410d1c02d419ba96a0d7fbb6f585d098a28309
verdict: effective
category: dashboard-state-sync
drafted: 2026-05-05
drafted_in: bug-hunt-gate-trip-20260505T175445Z750b-pending-recurrence
trigger: patch-ineffective + forward-signal
instances: 2
iterations: [20260503T230405Z2601, 20260505T175445Z750b]
related_ledger_entries: [sim-time-tile-em-dash-artefact, sim-time-card-truncates-with-ellipsis]
prior_patches:
  - "828003d (iter 20260503T230405Z2601, Team A) — added `hyphens:none; word-break:keep-all; overflow-wrap:normal; white-space:nowrap; overflow:hidden; text-overflow:ellipsis` on `.stat-value`. Closed em-dash hyphenation artefact, but introduced unconditional `text-overflow:ellipsis` as a safety net that subsequently fired when content overshot the card."
  - "f1d6581 (iter 20260505T175445Z750b, Team C) — JS-only fix: shortened `#sim-time` content to `formatDateShort` (date-only, 10 chars), exposed full timestamp via `title=`. Patch-ineffective: 10-char date at 20px mono bold still produces scrollWidth=120 vs clientWidth=119 (1px overshoot at 1200px viewport), so the CSS-painted ellipsis still fires; sighted users without hovering see `2025-05-…`."
deploy_blocked: false
break_even: 1 iteration. Two prior patches in this lane (CSS-only, then JS-only) failed to close the cluster — a third surgical patch is the same gamble. Refactor cost ≈ one bug-hunt iteration; recurrence cost = at least one more user-visible bug ship + another retest cycle. Pre-launch we eat real cost for every iteration spent in patch-loop mode.
---

# Refactor — Stat-Card Overflow Contract

## Root cause (one mechanism, two symptoms)

`.stat-value` (dashboard/styles.css:800) sits inside `.stat-card` (line 778) which sets `min-width: 150px; padding: 12px 16px`. Inner content area = 150 − 32 = **118px**. The Overview "SIM TIME" tile renders monospace bold 20px text; at this font sizing the rendered date string `2025-05-05` measures **120px** — a 2px overshoot.

The current `.stat-value` rule pins six contracts in series:

```css
hyphens: none;
word-break: keep-all;
overflow-wrap: normal;
white-space: nowrap;
overflow: hidden;
text-overflow: ellipsis;   /* ← fires on the 2px overshoot */
```

The first four lines are load-bearing: they prevent the Chromium auto-hyphenation that produced the visual em-dash artefact in iteration `20260503T230405Z2601` ([commit 828003d](https://github.com/justnau/finlet/commit/828003d)). The last two are a "safety net" that — by design — should NEVER fire on the happy path; if it fires, the tile is silently lying about the value it's meant to display. **The safety net IS the bug now.**

Two distinct broken predicates have shipped from the same root cause:
1. **`sim-time-tile-em-dash-artefact`** (iter `20260503T230405Z2601`) — auto-hyphenation injected a CSS-painted em-dash. Patched at the CSS layer, but the patch added the ellipsis fallback that produces failure mode 2.
2. **`sim-time-card-truncates-with-ellipsis`** (iter `20260505T175445Z750b`) — content overshoots tile by 1–2px, ellipsis paints. Team C patched at the JS layer (shorter content + `title=`) but the CSS contract still allows truncation when realistic content marginally overshoots.

Both share the exact same fix surface (`.stat-value` CSS contract). `triage.json` for the second occurrence carries `same_root_cause_as: "sim-time-tile-em-dash-artefact"` — explicit forward signal.

## Why patch-loop won't close it

Patch-loop fixes treat each tile-overshoot symptom in isolation:
- Iter 1 patched the em-dash side (CSS hyphenation rules).
- Iter 2 patched the SIM TIME content layer (JS shorter string + title attr).
- Iter 3 (if we keep patch-looping) would shorten `formatDateShort` further, OR widen ONLY the SIM TIME card via a per-id rule, OR drop SIM TIME from the Overview tiles entirely.

Each surgical patch leaves the contract for the OTHER stat tiles unaltered. Any future tile that ships with realistic content marginally exceeding 118px will recur — and the failure mode is silent (no error, no warning, just "the tile lies"). The fundamental gap is: **`.stat-value` has no test-enforced size contract; it has only a fallback that hides overflow when the contract silently breaks.**

## Refactor scope (this lands at once)

Make the stat-card sizing predicate explicit, enforced, and uniform. No more "safety net that lies."

### 1. CSS contract change (`dashboard/styles.css`)

`.stat-value`:
- KEEP the four load-bearing no-hyphenation rules (`hyphens:none; word-break:keep-all; overflow-wrap:normal; white-space:nowrap`).
- KEEP `overflow: hidden` (defense-in-depth — prevents any future bug where content escapes the card boundary breaking layout).
- **CHANGE** `text-overflow: ellipsis` → `text-overflow: clip`. If a tile ever DOES overshoot, the user sees a hard cutoff, not a deceptive `…` that pretends to be the rendered value. Hard cutoff is a bug we'll catch in QA; ellipsis is a bug that ships silently.

`.stat-card`:
- BUMP `min-width: 150px` → `min-width: 13ch` at the card level... actually no — `ch` doesn't compose with parent padding cleanly. Use **explicit numeric: `min-width: 184px`** (chosen so 150px content area = 184 − 32px padding = 152px, a ~30% headroom over the longest realistic stat-value content). Mobile breakpoint `min-width: 120px` (line 1895) bumped proportionally to `144px`.

`.stat-value` font sizing audit:
- 20px mono bold renders ~12px/char on the project's font stack. 152px / 12 = **12.6 chars** of headroom — fits `2025-05-05` (10 chars), `$1,234,567.89` (13 chars, just), and known existing tile content.
- If any single tile demands a string longer than 12 chars at 20px, that tile MUST set `font-size` lower (e.g., 16px) at the per-tile level. The CSS contract is: **the tile is sized to fit its expected content; overflow means the tile is mis-sized, and the test enforces that.**

### 2. Test-enforced size contract (new + extended)

Add a new Playwright spec OR extend `tests/e2e/journey-sim-time-tile.spec.ts` to assert at three desktop viewport widths (1024px, 1200px, 1440px) that EVERY `.stat-value` element on the dashboard satisfies:

```javascript
const fits = await el.evaluate(node => node.scrollWidth <= node.clientWidth);
expect(fits).toBe(true);
const computedTextOverflow = await el.evaluate(node => getComputedStyle(node).textOverflow);
expect(computedTextOverflow).toBe('clip');
```

The first assertion enforces that NO tile silently truncates. The second enforces the contract change at the CSS layer (a future regression that switches back to `ellipsis` would fail loudly).

The spec runs after a session is created and the dashboard has its first portfolio fill, so all tiles render with realistic content (cash, portfolio value, SIM TIME, P&L, etc.) — not just placeholder `--`.

### 3. Audit existing tile content (no code change unless overshoot found)

Walk the four Overview tiles in `dashboard/index.html` (`#sim-time`, `#portfolio-value`, `#cash-balance`, `#pnl`) and any other `.stat-value` site (sub-stats `#total-return`, `#max-drawdown`, `#sharpe-ratio` — see lines 168–245 of index.html). For each, list the longest realistic content string and confirm it fits within the new 152px content area at 20px mono bold. Document the audit inline as a comment in styles.css:

```css
/* Overview .stat-value content audit (bug-hunt refactor stat-card-overflow-contract):
   - #sim-time:        "2025-12-31"   (10 chars, ~120px) — fits
   - #portfolio-value: "$1,234,567.89" (13 chars, ~156px) — fits margin
   - #cash-balance:    "$999,999.99"  (11 chars, ~132px) — fits
   - #pnl:             "+$12,345.67%" (12 chars, ~144px) — fits
   - #total-return:    "+12.34%"      (7 chars, ~84px)   — fits
   - #max-drawdown:    "-12.34%"      (7 chars, ~84px)   — fits
   - #sharpe-ratio:    "1.234"        (5 chars, ~60px)   — fits
   If any new tile overshoots 152px, lower its font-size or compress content; do NOT
   bump min-width per-tile (would break grid uniformity). The CSS contract is uniform. */
```

If any tile DOES overshoot in the audit, the refactor includes the per-tile font-size adjustment. (This is unlikely given current content, but mandatory to verify before declaring the refactor effective.)

## Files in scope

- `dashboard/styles.css` — `.stat-card` min-width, `.stat-value` text-overflow + audit comment, mobile-breakpoint min-width
- `dashboard/index.html` — no change expected; only re-read to confirm tile content
- `tests/e2e/journey-sim-time-tile.spec.ts` — extend with the all-tile-fits-without-truncation spec at 3 viewport widths
- `docs/decisions/stat-card-overflow-contract.md` — NEW decision record explaining the contract, the failure mode it closes, and the rule for adding new stat tiles
- `docs/ARCHITECTURE.md` — append one bullet to the Dashboard section noting the stat-card overflow contract is test-enforced

## Validation gate

Pass conditions (ALL must hold post-merge, evaluated by Phase 5.5 retest after deploy):
1. New Playwright spec passes at 1024px, 1200px, 1440px viewports — every `.stat-value` has `scrollWidth <= clientWidth` after a session is created and a fill lands.
2. Computed `text-overflow` on every `.stat-value` is `'clip'` (not `'ellipsis'`).
3. Existing `tests/e2e/journey-sim-time-tile.spec.ts` em-dash regression test still passes (no `U+2014` glyph artefacts).
4. Visual regression: open `https://finlet.dev/index.html` after a fresh-session + first-fill; SIM TIME card reads `2025-05-05` (or whatever the sim date is), no `…` glyph, no glyph cutoff.

Fail conditions trip a `verdict: incomplete` next iteration:
- Any `.stat-value` overshoots at any of the three viewports.
- Any new bug-hunt finding in the next iteration carries `category: dashboard-state-sync` AND `scope_hint` mentioning `stat-value` / stat-card / Overview tile truncation.

## Out of scope

- Mobile layout below 1024px viewport — covered by the existing mobile-breakpoint `.stat-card { min-width: 120px → 144px }` bump but not viewport-width-tested at narrow sizes (no current bug-hunt blind walk uses mobile viewports).
- Other tile surfaces (positions table cells, leaderboard rows). Only `.stat-value` Overview-tile content is in scope; positions-table and leaderboard cells have their own column-width contracts, separately tested.
- Per-tile font-size customization beyond the audit findings. If the audit reports zero overshoots, no font-size code lands.
- TradingView equity-curve label sizing (governed by chart library, not CSS).

## Verdict criteria (set next iteration's Phase 6)

- **`verdict: effective`** — next iteration's bug-hunt triage shows zero new findings with `category: dashboard-state-sync` and `scope_hint` mentioning stat-value / Overview tile width / truncation.
- **`verdict: incomplete`** — at least one new finding lands with that scope_hint OR Phase 5.5 retest of `sim-time-card-truncates-with-ellipsis` still fails.
- **`verdict: regressed`** — a new finding lands tied to the changed CSS rules (e.g., a layout overflow that the previous `text-overflow: ellipsis` was masking surfaces visibly).

## Verdict evidence (2026-05-05, bug-hunt `20260505T213116Z45f1`)

Set `verdict: effective`. The blind-agent walk for iteration `20260505T213116Z45f1` (see `docs/bug-hunt/20260505T213116Z45f1/blind_report.json` and `triage.md`) surfaced four real-broken findings — `order-log-fee-disclosure-hover-only` (price-discrepancy), `modal-stacking-wizard-create-session-visible` (modal-stacking), `trade-ticket-panel-stays-open-after-fill` (dashboard-state-sync), and `test-plugin-toast-only` (dead-affordance). None of the four mention SIM TIME card truncation, `.stat-value` ellipsis painting, Overview-tile width overshoot, or any sibling stat-card surface. The triage's real-broken section explicitly contains zero stat-card / overflow / truncation symptoms, satisfying the verdict-effective predicate documented above ("zero new findings with `category: dashboard-state-sync` and `scope_hint` mentioning stat-value / Overview tile width / truncation"). The new Playwright spec (`tests/e2e/journey-sim-time-tile.spec.ts`) shipped with Team A's merge `f1b3cf7e607198229cdf9de49bb63581c636470d` continues to enforce `scrollWidth <= clientWidth` and `text-overflow: 'clip'` at 1024/1200/1440 viewport widths, so any future regression fails loudly at gate-time rather than reaching production.


---

_Iteration note 2026-05-06 (bug-hunt `20260506T061637Z6594`):_ this iteration shipped one new `dashboard-state-sync` finding (`plugin-health-dot-unhealthy-falls-to-unknown`) — predicate drift on the canonical `PluginHealthStatus` enum across `dashboard/app.js` and `dashboard/settings.js`. The bug is on a different surface than this refactor (predicate-vs-server-enum vocabulary skew, not the persistent-DOM / chart-Y-axis / config-propagation / overflow-contract surfaces). No verdict change implied for this refactor; cross-reference for category-recurrence tracking only. Ledger entry: `docs/bug-hunt/ledger.jsonl` (line 65).
