---
status: shipped
shipped_at: 2026-04-28
shipped_in: db7f637 (modal-stacking + dirty-state-tracker chain on main)
category: modal-stacking
drafted: 2026-04-28
instances: 2
iterations: [20260428T013300Z6e79, 20260428T163727Z4f4f]
verdict: effective
verdict_set_at: 2026-04-29
verdict_set_in: 20260429T052717Z1a13
verdict_evidence: "Zero modal-stacking findings in iteration 20260429T052717Z1a13's triage (the post-refactor `fl-modal` convention held across blind walk)."
---

# Refactor — Modal stacking convention

## Why we're here

Two real-broken instances of the same shape across two iterations:

1. `modal-stacking-leaderboard` (commit `9a58cce`, iter `20260428T013300Z6e79`) — "Submit to Leaderboard" dialog blocked because the always-rendered "Create New Session" modal sat at the same display:block with no z-index coordination. User clicks landed on the wrong modal.
2. Wizard-blocks-create-session (iter `20260428T163727Z4f4f`, retest evidence: `docs/bug-hunt/20260428T163727Z4f4f/modal-stacking-retest.png`) — onboarding wizard overlay (`#onboarding-overlay`, z-index 500, `pointer-events: auto`) sits above the spawned Create Session modal (z-index 300) and intercepts every click. `document.elementFromPoint(submitX, submitY)` returns the overlay, not the submit button.

Same shape: two modals/overlays open simultaneously, the older one is visually behind but pointer-events-active, the newer one is unreachable. Each fix has been a per-modal hack (toggle `display:none` on the older modal, or add a one-off z-index bump). No convention exists for "newest modal owns the input layer."

## Root cause

Dashboard modals coordinate visibility manually. Each modal has its own:
- z-index value (hard-coded per modal: 300, 400, 500, ...)
- show/hide mechanism (`classList.toggle('hidden')`, `display: block`, `removeAttribute('hidden')`)
- pointer-events posture (some have `pointer-events: auto` even when "hidden")

There's no central authority that says "while modal X is open, modals Y and Z are pointer-events: none and behind X in z-order, regardless of how they were shown." Adding a new modal requires a developer to know every other modal that might co-exist with theirs. Step 2 of any "find every modal that might collide" check fails silently every time. That's the recurrence.

## Refactor scope

One team. One worktree. ~2-3 hours of agent work (smaller than the event-bus refactor — the modal universe is ~5 files).

### Files touched

- **New: `dashboard/modal-controller.js`** — single module exporting:
  ```
  modal.open(id) → returns close handle
  modal.close(id)
  modal.suppress(id, while_open_id)  // useful for the onboarding overlay case
  modal.topmost() → string | null
  ```
  Maintains an internal stack of open modal IDs. Maintains an active z-index counter starting at `--modal-base-z` (CSS var, default 1000). When a modal opens, it gets `topZ++` and is the only one with `pointer-events: auto`. When it closes, the next modal in the stack reclaims the input layer.
- **Modified: `dashboard/index.html`** — every modal element gets `data-modal-id="..."` and a CSS class `.fl-modal` that defaults to `pointer-events: none; z-index: 0;`. The controller flips these per-modal at open/close time. Remove all per-modal hard-coded z-index values from `dashboard/styles.css`.
- **Modified: `dashboard/onboarding.js`** — replace ad-hoc visibility toggling of `.onboarding-overlay--hidden` (around `:355-360`, the "Open Session Creator" handler) with `modal.suppress('onboarding-overlay', 'create-session-modal')`. The suppression auto-restores when create-session closes.
- **Modified: `dashboard/app.js`, `dashboard/leaderboard.js`, `dashboard/session-create.js`** — replace direct `display: block` / `classList.toggle('hidden')` with `modal.open(id)` / `modal.close(id)`.
- **Modified: `dashboard/styles.css`** — z-index variables consolidated under `--modal-base-z` and `--overlay-base-z`. No per-modal hard-coded values.

### File conflict table

| File | Touched by |
|------|-----------|
| `dashboard/modal-controller.js` (new) | this refactor |
| `dashboard/onboarding.js` | this refactor (additive — uses suppress API) |
| `dashboard/app.js` | this refactor (replace toggles with controller calls) |
| `dashboard/leaderboard.js` | this refactor |
| `dashboard/session-create.js` | this refactor |
| `dashboard/index.html` | this refactor (data attributes + class) |
| `dashboard/styles.css` | this refactor (z-index consolidation) |

No other refactors touch these files in the queue. Single-team execution.

## Validation

- **Unit:** `modal.open(a)` then `modal.open(b)` → `modal.topmost() === b`. `modal.close(b)` → `modal.topmost() === a`. `modal.close(a)` → `modal.topmost() === null`.
- **Playwright regression — wizard + create session:**
  1. Navigate to dashboard with onboarding wizard active.
  2. Click "Open Session Creator."
  3. Assert `document.elementFromPoint(submitBtnX, submitBtnY)` resolves to the submit button (not the overlay).
  4. Click submit → assert form submits.
- **Playwright regression — leaderboard + create session:**
  1. Navigate to dashboard.
  2. Open Create New Session.
  3. While it's open, click "Submit to Leaderboard."
  4. Assert leaderboard modal is topmost; create-session is suppressed; close leaderboard → create-session reclaims input.
- **Manual:** open every modal one at a time, then in pairs, then triples — visual inspection: only the topmost is interactive.

## Break-even

Status quo: 2 instances already, both with 1+ hour of patch + test work. Modal stacking is the third-most-touched dashboard surface (after onboarding and trade-ticket), so a third recurrence is a near-certainty under the current convention. Refactor pays back if it prevents 1 future iteration.

## Reversal path

Single merge SHA. The controller is one file; consumer migrations are mechanical (each `display: block` becomes `modal.open(id)`). Revert is ~30 minutes.

## Out of scope

- Modal animation/transitions — keep current CSS transitions. The controller doesn't own visual style.
- Dialog focus trapping (a11y) — separate concern; if added, build on top of this controller.
- Server-driven modals (e.g., "session expired" toast) — out of scope; toasts != modals.

## Verdict (pending — to be set by next bug-hunt iteration)

Refactor merged. Per the refactor-gate convention, the next bug-hunt iteration will retest the two real-broken instances:

- "Submit to Leaderboard" + Create Session stacking (recurrence shape from `20260428T013300Z6e79`)
- Onboarding wizard + Create Session click-through (recurrence shape from `20260428T163727Z4f4f`)

If both pass cleanly with no new failures of the same shape, mark verdict: `effective`.
If any of the same shape recurs, mark `incomplete` or `regressed`.
