---
status: shipped
shipped_at: 2026-05-05
shipped_sha: 717a87867dc30a60b9d7f1fb5ce58062b1a191ea
verdict: effective
verdict_set_at: 2026-05-05
verdict_set_in: convention-enforcement-2026-05-05
verdict_evidence: "Phase 5.5 retest 2026-05-05 against finlet.dev confirmed delete-account modal triggers ZERO 'Password forms should have...' warnings (peer attrs name=username autocomplete=username hidden=true aria-hidden=true verified live). Event-bus lint guard (scripts/lint-event-bus.sh) active in pre-commit chain alongside trusted-types lint. 4 refactor-queue verdicts refreshed (dirty-state-tracker v3, onboarding-checklist v2, trade-ticket-state-sync-v3.1, close-patch-ineffective-2026-05-02 v2). Self-heal commit 717a878 fixed journey-06:1250 e2e test (button-not-visible because Plugins-tab cold-load doesn't show data-privacy section's Delete Account button — switched to data-privacy section before click)."
drafted: 2026-05-05
drafted_by: orchestrator (overnight refactor session)
category: convention-enforcement
target_categories:
  - password-form-aria      # closes the orphaned patch-ineffective signal
  - dashboard-event-bus     # codifies the documented convention
  - verdict-bookkeeping     # refreshes stale verdicts on shipped docs
instances_closed: 1         # password-form-aria residual
verdicts_refreshed: 4       # dirty-state-tracker, onboarding-checklist, trade-ticket-state-sync-v3, close-patch-ineffective-2026-05-02
expected_loc: ~250
expected_files: 11
break_even_iterations: 1
parallelism: 3 teams
---

# Refactor — Convention enforcement: hardening + verdict refresh

## Why we're here

Three things are tripping the bug-hunt gate that aren't a fresh refactor — they're cleanup that future-proofs the conventions we already shipped:

1. **One orphaned patch-ineffective signal** (legacy schema, no `category` field) blocks the gate's auto-prune. The fix it points at — apply the hidden username-peer pattern to `#delete-account-form` — is a 5-line replication of an already-shipped pattern (commit `b08ddb8`, plugin cards).
2. **Documented event-bus convention has no enforcement.** `CLAUDE.md` says "All cross-component dashboard wiring goes through `window.finletBus`. Direct `addEventListener('finlet:...')` and `window.dispatchEvent(new CustomEvent('finlet:...'))` are forbidden." Today the codebase has zero violations — but no pre-commit guard exists. One PR can drift the convention silently. Trusted-types has a lint guard (`scripts/lint-trusted-types.sh`); event-bus does not.
3. **Verdict bookkeeping is stale.** Four shipped queue docs have `verdict: incomplete` from earlier evaluations, but follow-up patches in subsequent iterations closed each gap. The verdicts were never refreshed. This is what makes the gate's count trigger keep firing on closed clusters.

## Root cause

The last 14 days of bug-hunt loops shipped real fixes faster than the verdict-tracking convention could keep up. The skill's `verdict_v2` / `verdict_v3` field convention exists (see `dirty-state-tracker.md`) but isn't applied consistently — when a v3 patch lands inline and closes the cluster, the queue doc isn't always touched. Combined with one legacy-schema patch-ineffective entry that the auto-prune can't process, the gate state has decayed.

The fix is to (a) close the legacy entry by shipping the actual residual, (b) turn one documented convention into an enforced one so it can't drift, and (c) audit shipped queue docs and refresh verdicts with evidence.

## Refactor scope — three parallel teams

### Team A — `password-form-aria` residual + pending_recurrences migration

**Owns:** `dashboard/settings.html`, `dashboard/settings.js`, `tests/e2e/journey-06-settings.spec.ts`, `docs/bug-hunt/pending_recurrences.jsonl`, `docs/bug-hunt/pending_recurrences.resolved.jsonl`.

**What lands:**

1. **Add hidden username peer to `#delete-account-form` modal in `dashboard/settings.html`** (currently at line 559-568, between the modal-body `<p>` and the form's password input at line 562):
   ```html
   <form id="delete-account-form" onsubmit="return false;" autocomplete="off">
     <!-- Hidden username peer for Chromium password-manager autocomplete heuristic.
          See plugin-card pattern at b08ddb8 / bug-hunt 20260503T230405Z2601 Team C. -->
     <input type="text" id="delete-account-username-peer"
            name="username" hidden autocomplete="username"
            readonly tabindex="-1" aria-hidden="true" value="">
     <div class="form-group" style="margin-top: 16px;">
       <label class="form-label" for="delete-confirm-password">Enter your password...</label>
       <input type="password" id="delete-confirm-password" ...>
     </div>
     ...
   ```

2. **Populate the peer's `value` when the delete-account modal opens** in `dashboard/settings.js`. Find the function that opens the delete-account modal (search for `delete-account-modal` or `openDeleteAccountModal`); when opening, set `document.getElementById('delete-account-username-peer').value = currentUserEmail` (or whichever store holds the logged-in user's email). If no email is reachable in client state, leave value=''  — Chromium's heuristic only requires the peer's PRESENCE, not a specific value, but a non-empty value is preferred when available.

3. **Extend the existing `tests/e2e/journey-06-settings.spec.ts` console-warning assertion** to also exercise the delete-account modal:
   ```ts
   // After existing settings cold-load assertion:
   await page.click('#delete-account-btn');  // or whatever opens the modal
   await page.waitForSelector('#delete-account-modal:not([style*="display: none"])');
   const warnings = consoleMessages.filter(m => /Password forms should have .* username fields/.test(m));
   expect(warnings).toHaveLength(0);
   await page.click('#delete-cancel-btn');
   ```

4. **Migrate the legacy pending_recurrences entry.** Read `docs/bug-hunt/pending_recurrences.jsonl`, find the legacy entry (the one with `iteration` / `team` / `bug` / `reason` keys instead of the new schema). Remove it from `pending_recurrences.jsonl`. Append a properly-schema'd resolved entry to `docs/bug-hunt/pending_recurrences.resolved.jsonl`:
   ```json
   {"patch_iteration_ts":"20260503T230405Z2601","finding_id":"settings-password-form-aria-residual-delete-account","category":"password-form-aria","retest_kind":"playwright","deploy_sha":"<this-iteration's-merge-sha>","evidence":"Original blind walk counted 9 password-form-aria warnings; iter 20260503 commit b08ddb8 closed 8 (plugin cards); residual 2 from #delete-account-form modal closed by this refactor. Same hidden-username-peer pattern replicated to settings.html line 559-568.","scope_files":"dashboard/settings.html, dashboard/settings.js","resolved_by":"convention-enforcement-2026-05-05.md (Team A)","resolved_at_ts":"<this-iteration-ts>","resolved_at_date":"2026-05-05","resolved_note":"Schema migration: original entry used legacy {iteration, team, bug, reason} keys; this entry restates with {patch_iteration_ts, finding_id, category, retest_kind, deploy_sha, evidence, scope_files, resolved_by, resolved_at_ts, resolved_at_date} per current spec."}
   ```

**Validation (Team A):**
- Cold-load `settings.html` → zero `Password forms should have ... username fields` console warnings.
- Open `#delete-account-modal` → zero `Password forms should have ... username fields` console warnings.
- The hidden peer is `aria-hidden=true` and `tabindex=-1` (not focusable, not announced).
- The peer is inside the same `<form>` as the password input (Chromium's heuristic requires same-form proximity).
- `pending_recurrences.jsonl` no longer contains the legacy entry; `resolved.jsonl` gained one new line.

**Files (Team A):**
| File | Change |
|------|--------|
| `dashboard/settings.html` | +5 lines (hidden username peer) |
| `dashboard/settings.js` | +2 lines (peer value population on modal open) |
| `tests/e2e/journey-06-settings.spec.ts` | +8-12 lines (delete-account modal assertion) |
| `docs/bug-hunt/pending_recurrences.jsonl` | -1 line (legacy entry removed) |
| `docs/bug-hunt/pending_recurrences.resolved.jsonl` | +1 line (migrated entry) |

---

### Team B — Event-bus lint guard + pre-commit wiring

**Owns:** `scripts/lint-event-bus.sh`, `scripts/git-hooks/pre-commit`, `docs/decisions/dashboard-event-bus.md`, `docs/ARCHITECTURE.md` (mention only).

**What lands:**

1. **New script `scripts/lint-event-bus.sh`.** Scans every `.js` file under `dashboard/` (excluding `dashboard/event-bus.js` itself, and excluding test files / vendor) for two patterns:
   - `addEventListener\s*\(\s*['"]finlet:` — direct subscription bypassing the bus
   - `dispatchEvent\s*\(\s*new\s+CustomEvent\s*\(\s*['"]finlet:` — direct dispatch bypassing the bus

   Pattern follows the existing `scripts/lint-trusted-types.sh` shape: `set -uo pipefail`, `--check` flag for CI mode, exit 1 on violation with file:line evidence. Allowlist marker `// finlet-bus-lint-allowlist` for any future case requiring an exemption (none expected — this is purely defensive).

   Document at the top of the script: "Why" (the convention from `docs/decisions/dashboard-event-bus.md` and `CLAUDE.md`), "What" (the patterns), "Allowlist marker" (the comment), "Usage" (`bash scripts/lint-event-bus.sh [--check]`).

2. **Modify `scripts/git-hooks/pre-commit`** to chain the new lint after `lint-trusted-types.sh`. Both must pass for the commit to proceed. Preserve existing semantics (locate via symlink resolution; fallback via `git rev-parse`). Print clear failure messages naming which lint failed.

3. **Update `docs/decisions/dashboard-event-bus.md`** — add an "Enforcement" section near the top (or wherever the existing enforcement-style content lives) noting that `scripts/lint-event-bus.sh` is the pre-commit guard for this convention. Cross-link to `scripts/lint-trusted-types.sh` as the sibling guard.

4. **Update `docs/ARCHITECTURE.md`** — if it has a "Conventions" / "Lint guards" section, add the event-bus lint to the list. Skip if no such section exists (do not invent a new one for this purpose alone).

**Validation (Team B):**
- Run `bash scripts/lint-event-bus.sh` from repo root → exit 0 on current main (no violations).
- Add a synthetic violation locally (e.g., `dashboard/test-violation.js` with `addEventListener('finlet:foo', ...)`) → script exits 1 with the file:line. Remove the synthetic.
- `bash scripts/lint-event-bus.sh --check` returns clean exit code in CI mode.
- `bash scripts/setup-git-hooks.sh` re-installs hooks; pre-commit blocks any future violation.
- Existing `scripts/lint-trusted-types.sh` still runs and still passes.

**Files (Team B):**
| File | Change |
|------|--------|
| `scripts/lint-event-bus.sh` | NEW (~120-150 lines, mirroring lint-trusted-types.sh shape) |
| `scripts/git-hooks/pre-commit` | +5-10 lines (chain second lint) |
| `docs/decisions/dashboard-event-bus.md` | +5-10 lines (Enforcement section) |
| `docs/ARCHITECTURE.md` | +1-2 lines if Lint section exists, else no change |

---

### Team C — Verdict refresh + pending_recurrences pruning

**Owns:** `docs/bug-hunt/refactor-queue/dirty-state-tracker.md`, `docs/bug-hunt/refactor-queue/onboarding-checklist.md`, `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md`, `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md`, `docs/bug-hunt/pending_recurrences.jsonl`, `docs/bug-hunt/pending_recurrences.resolved.jsonl` (this team APPENDS pruning entries; Team A's legacy-entry migration is a separate set of lines).

**What lands:** four verdict refreshes, each with documented evidence, plus per-spec pruning.

For EACH of the four queue docs below, append (don't replace) a new verdict block with `verdict_vN: effective` and `verdict_vN_evidence: <text>`. The `vN` is the next version number after the last verdict on the doc. The evidence must cite ledger entries by finding_id and the closing commit SHA.

1. **`dirty-state-tracker.md`** — current state has `verdict: incomplete` (v1) and `verdict_v2: effective`, then a "Recurrence — bug-hunt 20260501T234103Z1a49" addendum at the bottom describing the v3 patch (commit `87a37b6`). Add `verdict_v3: effective` with evidence citing zero new `dirty-state-tracker` ledger entries since `20260501T234103Z1a49` (verify via `jq -c 'select(.category == "dirty-state-tracker") | .iteration_ts' docs/bug-hunt/ledger.jsonl | sort -u`).

2. **`onboarding-checklist.md`** — current verdict is `incomplete`. The 40368b2 refactor + 91922c7 (`checklist-rest-cli-no-advance` fix) + 4924948 (`checklist-set-up-profile-auto-complete` fix) closed the pattern. Add `verdict_v2: effective` citing zero new `onboarding-checklist` ledger entries since `20260501T234103Z1a49` (verify via the same `jq` query). Also fold in evidence from `dashboard/onboarding.js:383-391` — the source comments document both reach-ins as closed.

3. **`trade-ticket-state-sync-v3.md`** — current verdict is `incomplete`. Commit `8c55a90` (v3.1 inline patch in iter `20260503T030227Z2009`) closed the closed-panel persistent-DOM-rot gap. The resolved.jsonl already documents this. Add `verdict_v3_1: effective` citing the resolved.jsonl entry and zero new `trade-ticket` ledger entries since `8c55a90`.

4. **`close-patch-ineffective-2026-05-02.md`** — current verdict is `incomplete`. The entries it closed are already in resolved.jsonl. Verify each (profile-checklist-marks-on-persona, settings-dirty-banner-on-cold-load, edgar-plugin-stale-after-cli-config) has `resolved_by` pointing at this doc. If all three are resolved with no recurrence in the same shape since the close, add `verdict_v2: effective`.

5. **Per-spec pruning of `pending_recurrences.jsonl`.** For each verdict that becomes `effective` in steps 1-4, run the pruning recipe from `bug-hunt/SKILL.md` Phase 6:
   ```bash
   PENDING_FILE="docs/bug-hunt/pending_recurrences.jsonl"
   EFFECTIVE_CATEGORY="<the category just made effective>"
   EFFECTIVE_SHIPPED_TS="<refactor-shipped iteration ts; e.g., 20260501T234103Z1a49 for v3>"
   jq -c --arg cat "$EFFECTIVE_CATEGORY" --arg ts "$EFFECTIVE_SHIPPED_TS" \
     'select(.category != $cat or .patch_iteration_ts >= $ts)' \
     "$PENDING_FILE" > "$PENDING_FILE.kept"
   jq -c --arg cat "$EFFECTIVE_CATEGORY" --arg ts "$EFFECTIVE_SHIPPED_TS" \
     'select(.category == $cat and .patch_iteration_ts < $ts)' \
     "$PENDING_FILE" >> docs/bug-hunt/pending_recurrences.resolved.jsonl
   mv "$PENDING_FILE.kept" "$PENDING_FILE"
   ```
   Most categories' pending entries are already in `resolved.jsonl` (per the inspection above) — the pruning will no-op on those, which is fine (jq `select` produces empty output). The pruning is run as documentation that we applied the spec's contract.

**Validation (Team C):**
- Each of the four queue docs has the new verdict block at the END of the frontmatter (before `---` close), preserving prior verdicts.
- The evidence in each verdict block cites at least one finding_id and one commit SHA.
- `wc -l docs/bug-hunt/pending_recurrences.jsonl` does not grow (pruning is subtractive).
- `jq -c '.' docs/bug-hunt/pending_recurrences.jsonl` parses every remaining line cleanly (no schema drift).

**Files (Team C):**
| File | Change |
|------|--------|
| `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` | +5-8 lines (new verdict block) |
| `docs/bug-hunt/refactor-queue/onboarding-checklist.md` | +5-8 lines |
| `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` | +5-8 lines |
| `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md` | +5-8 lines |
| `docs/bug-hunt/pending_recurrences.jsonl` | possibly -0 to -2 lines (pruning) |
| `docs/bug-hunt/pending_recurrences.resolved.jsonl` | possibly +0 to +2 lines (pruned entries archived) |

---

## File conflict table

| File | Touched by |
|------|-----------|
| `dashboard/settings.html` | Team A |
| `dashboard/settings.js` | Team A |
| `tests/e2e/journey-06-settings.spec.ts` | Team A |
| `docs/bug-hunt/pending_recurrences.jsonl` | Team A (legacy migration) AND Team C (pruning) — **sequence: A → C** |
| `docs/bug-hunt/pending_recurrences.resolved.jsonl` | Team A AND Team C — **sequence: A → C** |
| `scripts/lint-event-bus.sh` | Team B (NEW file) |
| `scripts/git-hooks/pre-commit` | Team B |
| `docs/decisions/dashboard-event-bus.md` | Team B |
| `docs/ARCHITECTURE.md` | Team B |
| `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` | Team C |
| `docs/bug-hunt/refactor-queue/onboarding-checklist.md` | Team C |
| `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` | Team C |
| `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md` | Team C |

**Two-file overlap (Team A → Team C, sequential):** `pending_recurrences.jsonl` and `pending_recurrences.resolved.jsonl`. Team A migrates the legacy entry first; Team C runs the per-category pruning recipe second. plan-features should sequence Team C after Team A.

**Otherwise full parallelism between A, B, C.**

## Validation (cross-team)

- All three teams' branches must pass `bash scripts/lint-trusted-types.sh --check` (existing gate).
- All three teams' branches must pass `bash scripts/lint-event-bus.sh --check` once Team B's script is in main (Team A and Team C should not introduce any new finlet:* dispatch — they don't touch event-emitting code paths, so they should be naturally clean).
- After all three merge: run `journey-06-settings.spec.ts` against deployed prod URL and assert zero password-form-aria console warnings on cold-load AND on delete-account-modal open.
- After all three merge: run `gh run list --workflow="Deploy Finlet" --branch main --limit 1 --json conclusion` — must be `success` before declaring the refactor closed.
- After deploy success: verify the bug-hunt gate would now PASS by running:
  ```bash
  cat docs/bug-hunt/pending_recurrences.jsonl | wc -l   # should be 0 (or no schema-orphans)
  ```

## Break-even

This is a 1-iteration break-even refactor:
- Closes the only currently-firing gate trigger (patch-ineffective on legacy entry) → next `/bug-hunt` runs gate-clean.
- Adds a permanent guard for the event-bus convention → prevents the entire class of "convention drift" bugs that drove the original event-bus refactor.
- Refreshes 4 stale verdicts → gate-state report becomes accurate going forward, no false alarms.

Without this work, every future `/bug-hunt` invocation would falsely trip the patch-ineffective gate on the legacy entry, and the count trigger would keep accumulating against already-closed clusters.

## Reversal path

- Team A: revert is mechanical (drop hidden peer line, drop test assertion, restore legacy pending_recurrences entry from git history).
- Team B: revert is `rm scripts/lint-event-bus.sh` + revert pre-commit chaining + revert decisions/ note. ~5 minutes.
- Team C: revert is mechanical (drop verdict blocks). The pruning is the only operation with a "lossy" feel — but pruned entries are appended to resolved.jsonl, so no information is lost; revert restores the lines to pending.

## Out of scope

- Generalizing the form-dirty-tracker to billing.html (billing has 9 form-input/select/textarea/toggle elements but its dirty-state needs are unverified — punt to a separate refactor pass once recurrence evidence emerges).
- Generalizing the render-on-read pattern from trade-ticket.js into a reusable module (verification report concluded N=1 is too few; defer until a 2nd persistent-DOM bus-mirror surface emerges).
- Adding aria-hidden parity guard for banner-class elements (interesting but out of scope tonight; the dirty-state-tracker journey identified this as a candidate for a future pass).
- Auditing other dashboard surfaces for canonical-store opportunities (no recurrence evidence demands it tonight).

## Per-spec doc updates required

This refactor itself produces ledger entries via Team C's verdict refreshes. The standard "Required Docs Updates" block from `bug-hunt/SKILL.md` does not apply directly (this isn't a bug-hunt iteration), but the equivalent updates to ship are:

- `docs/REMAINING_TASKS.md` — close: legacy patch-ineffective entry, event-bus lint guard
- `docs/LESSONS.md` — append at least one lesson on "shipped-without-verdict-refresh" pattern (Team C's domain) and one on "documented-but-unenforced convention" pattern (Team B's domain)
- `docs/ARCHITECTURE.md` — Team B updates lint section if it exists
- `docs/decisions/` — Team B's decisions/dashboard-event-bus.md update; no new decision record needed (this codifies an existing decision, not a new one)

These are folded into Team B's commit message for items they own, and Team C's commit for verdict-tracking items.
