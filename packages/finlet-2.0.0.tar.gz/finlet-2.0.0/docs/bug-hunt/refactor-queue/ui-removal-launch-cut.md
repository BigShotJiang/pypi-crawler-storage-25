---
category: ui-removal-launch-cut
status: shipped
instances: 65
iterations: 24
latest_instance: blind-walk-mcp-undiscoverable
drafted: 2026-05-06
shipped: 2026-05-07
shipped_in: 93eec0e (HEAD of exec-plan run for docs/refactor/ui-cut/plan.md; verdict pending next bug-hunt iteration)
verdict:
source_handoff: docs/decisions/ui-removal-launch-cut.md
triggered_by: blind walkthrough 20260507T042257Z3c76 + cumulative ledger pattern
---

# Refactor — Cut UI write paths for launch (move to legacy/dashboard-ui/)

## Why we're here

Finlet's product is an agentic trading evaluation harness for AI agents. Memory `project_finlet_positioning.md` (2026-03-30) established this. Despite the positioning, the dashboard ships full human-facing trading-SaaS write paths: trade ticket, onboarding wizard, plugin install/configure UI, settings tabs, modals.

The bug-hunt ledger has accumulated 69 real-broken findings across ~24 iterations. ~65 of 69 (94%) live in UI write paths. Twelve refactor docs have shipped against those surfaces with a 50% effectiveness rate. The pattern of "ship refactor → verdict incomplete → next iteration finds the same category → ship another refactor" indicates we are patching the wrong layer: the surfaces themselves should not exist for the launch user (an LLM agent).

Blind walkthrough `20260507T042257Z3c76/blind_report.json` made the misalignment vivid. The agent's #1 BROKEN finding: *"Finlet benchmark MCP tools not present in the tool registry."* The agent then fell back to clicking the trade ticket UI to complete its task. We have been polishing the fallback while the front door is broken.

A 13th refactor on `dashboard-state-sync` is the near-certainty under the current shape. The structural fix is: cut the surfaces.

## Root cause

The dashboard contains two unrelated product surfaces collapsed into one codebase:

1. **Read-only monitoring surface** — equity curve, positions table, trade log, sessions list, plugin health, leaderboard. This is the surface an agent's developer (or a curious human) opens to see what the agent did. Pure observation. Low bug density: 4 of 69 ledger entries.
2. **Write-path SaaS surface** — trade ticket, onboarding wizard, settings forms, plugin install/configure UI. This is the surface a human-as-trader would use. Zero of the launch user base wants this. High bug density: 65 of 69 ledger entries.

Every bug-hunt iteration finds new bugs in (2) because (2) is feature-rich, dirty-state-prone, and modal-stacked. We refactor it; users (agents) never benefit (they use CLI/MCP); the next iteration finds more bugs in the same surface.

The launch cut is the structural fix. Surface (2) becomes inaccessible from the production dashboard. Code is preserved in `legacy/dashboard-ui/` (decision record `docs/decisions/ui-removal-launch-cut.md` explains why dir-not-tag-only).

## Files

Verified against HEAD `fbb5bb3`. Full file map at `docs/bug-hunt/20260507T042257Z3c76/surface_map.md` (44 dashboard files + 26 e2e tests + event contract + 11 API routes classified). Summary:

**KEEP (18 dashboard files):** landing.html, auth.html, leaderboard.html, verify.html, setup.html, agent-guide.html, api-utils.js, auth.js, auth-guard.js, shared-nav.js, mobile-nav.js, empty-states.js, security-telemetry.js, feedback.js, event-bus.js, leaderboard.js, vendor/lightweight-charts.standalone.production.js, favicon.svg, llms.txt + their CSS (styles.css, auth.css, landing.css, setup.css, agent-guide.css)

**CUT (15 dashboard files):** trade-ticket.js, onboarding.js, onboarding.css, settings.html, settings.css, billing.html, billing.js, billing.css, pricing.html, marketplace.html, marketplace.js, marketplace.css, dialog-state-mirror.js, form-dirty-tracker.js — plus the entire CUT-only block of settings.js (see TRIM)

**TRIM (5 files):** app.js (~30% CUT — trade ticket + onboarding handlers), index.html (~35% CUT — trade ticket panel, session details panel, onboarding checklist, modals), settings.js (~92% CUT — extract API key listing only), leaderboard-submit.js (~23% CUT — extract submit modal), modal-controller.js (KEEP as infrastructure but currently called only by CUT consumers — keep the module, remove the dead callers' references)

**Tests:** 9 KEEP e2e (read-only journeys), 9 CUT e2e (write-path journeys → `legacy/tests/e2e/`), 8 INFRA e2e (cross-cutting — mobile, keyboard, CSRF, trusted-types, sim-time — keep as-is; refactor as needed in a follow-up if they break against the trimmed surface)

**Event contract:** retain `portfolio:updated`, `session:switched`, `auth:state-change`. Prune `order:filled`, `onboarding:step-completed`, `profile:saved`, `strategy:saved` (only CUT consumers).

**API routes (`finlet/api/`):** 10 read-only routes stay (called by KEEP dashboard). 8 write-path routes (POST orders, PATCH settings, POST profile, POST password, POST plugins/install, PATCH plugins/config, POST subscriptions/plans, POST account/delete) are NOT removed — they remain as the CLI/MCP write surface. Just confirm they're not orphaned (i.e., CLI/MCP actually calls them) before merging.

## Proposed shape

**Five teams, parallel where possible, sequential merge gate. ~6-10 hours of agent work.**

Team boundaries follow `.claude/rules/file-ownership.md`. Critical: the user wants the cut code preserved at `legacy/dashboard-ui/` (visible, walkable directory), NOT just behind a git tag. A safety-net tag (`pre-ui-cut-2026-05-06`) is also created before any team starts.

### Team A — Pre-cut tag + structural moves (`dashboard/` → `legacy/dashboard-ui/`)

Owner: dashboard team
Worktree: yes
Depends on: nothing (runs first)

Scope:
1. **Pre-cut safety net.** Before any move: `git tag pre-ui-cut-2026-05-06 main && git push origin pre-ui-cut-2026-05-06`. Validation: `git tag --list pre-ui-cut-*` returns the tag.
2. **Create legacy/ structure.** `mkdir -p legacy/dashboard-ui legacy/tests/e2e`. Write a `legacy/README.md` warning that this is preserved-but-deactivated code — see decision record `docs/decisions/ui-removal-launch-cut.md` and refactor scope `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`. Do NOT modify; restore via `git checkout pre-ui-cut-2026-05-06 -- dashboard/<file>` or copy from `legacy/`.
3. **git-mv the 15 CUT files** from `dashboard/` → `legacy/dashboard-ui/`. Preserve history. List from surface map:
   - `dashboard/trade-ticket.js`
   - `dashboard/onboarding.js`, `dashboard/onboarding.css`
   - `dashboard/settings.html`, `dashboard/settings.css`
   - `dashboard/billing.html`, `dashboard/billing.js`, `dashboard/billing.css`
   - `dashboard/pricing.html`
   - `dashboard/marketplace.html`, `dashboard/marketplace.js`, `dashboard/marketplace.css`
   - `dashboard/dialog-state-mirror.js`
   - `dashboard/form-dirty-tracker.js`
4. **Strip `<script>` and `<link>` includes** from the KEEP HTML pages (`dashboard/{landing,auth,leaderboard,verify,setup,agent-guide,index}.html` — index.html still references trade-ticket.js etc.) for any of the moved files. Just remove the include tags; the actual move is git-mv-only. Index.html's TRIM (panel removal) is Team B's scope, NOT Team A's.

Validation:
- `git status` shows the 15 files renamed to `legacy/dashboard-ui/`, history preserved (`git log --follow legacy/dashboard-ui/trade-ticket.js` returns full history).
- `dashboard/` no longer contains any of the 15 CUT files.
- `dashboard/index.html` (and other KEEP HTMLs) no longer have `<script src="trade-ticket.js">` or similar includes for moved files.
- `legacy/README.md` exists with the right content.
- Tag `pre-ui-cut-2026-05-06` exists locally and on origin.

### Team B — TRIM operations (`dashboard/` mixed files + event contract)

Owner: dashboard team
Worktree: yes (separate from Team A)
Depends on: Team A merged (so includes are already removed; avoids merge conflicts on HTML)

Scope:
1. **app.js (2970 lines, ~30% CUT).** Identify trade-ticket event handlers (`openTradeTicket`, `closeTradeTicket`, related SSE branches that re-render trade ticket state) and onboarding handlers (any `window.finletOnboarding?.markStepComplete?.(...)` reach-ins, onboarding-related bus subscribers). Two paths:
   - **Path A (recommended):** Delete the CUT sections from `dashboard/app.js`. The full original app.js is preserved in `legacy/dashboard-ui/app.js` (Team A copies it there as part of their move — UPDATE: app.js is NOT in Team A's CUT list because it's TRIM. Solution: Team B copies the full app.js to `legacy/dashboard-ui/app.js` BEFORE trimming, then trims the in-place dashboard/app.js. `git log --follow` will still work if the copy is git-tracked.)
   - **Path B:** Wrap CUT sections in `if (window.__FINLET_LAUNCH_CUT) return;` no-op guards. Rejected: leaves dead code paths in production, defeats the cut's bug-density benefit.
   - Path A wins. Recommend git-cp-pattern: `cp dashboard/app.js legacy/dashboard-ui/app.js && git add legacy/dashboard-ui/app.js && [edit dashboard/app.js to remove CUT sections]`. Annotate the legacy file's first comment with `// Pre-launch-cut snapshot of dashboard/app.js (commit fbb5bb3, 2026-05-06). Production version trimmed to read-only surfaces. See docs/decisions/ui-removal-launch-cut.md.`
2. **index.html (598 lines, ~35% CUT).** Same pattern: copy current index.html → `legacy/dashboard-ui/index.html` first, then strip CUT panels (trade ticket slide-out, session details panel, onboarding checklist DOM, all modals) from `dashboard/index.html`. Keep nav, session selector, equity chart, portfolio metrics, positions table, order log, plugin health.
3. **settings.js (1915 lines, ~92% CUT).** Extract the read-only API key listing logic into a new file `dashboard/api-keys.js` (~150 lines, just: list keys, show masked, revoke button). Move full settings.js → `legacy/dashboard-ui/settings.js` via git-mv. The new `dashboard/api-keys.js` is included from a new `dashboard/api-keys.html` page (very minimal — list + revoke only) replacing the cut settings.html for the API key surface only.
4. **leaderboard-submit.js (497 lines, ~23% CUT).** Extract the table rendering into the existing `dashboard/leaderboard.js` (or keep as `leaderboard-table.js` if cleaner). Move the submit modal section → `legacy/dashboard-ui/leaderboard-submit.js`. Verify `dashboard/leaderboard.html` no longer references the submit modal.
5. **modal-controller.js (267 lines).** Keep in production `dashboard/`. It's infrastructure that future read-only modals (e.g., "view session details" lightbox) can use. Remove any dead imports from CUT consumers (those are gone now via Team A's moves). Add a one-line top comment: `// Modal controller — currently has zero callers post-2026-05-06 launch cut. Retained for future read-only modal use. See docs/decisions/ui-removal-launch-cut.md.`
6. **dashboard/event-contract.md.** Prune the four CUT-only events (`order:filled`, `onboarding:step-completed`, `profile:saved`, `strategy:saved`). Retain documentation for `portfolio:updated`, `session:switched`, `auth:state-change`. Update event-contract.md's preamble to note that the document was pruned during the 2026-05-06 launch cut and reference the decision record.

Validation:
- `dashboard/app.js` no longer contains `openTradeTicket`, `closeTradeTicket`, or any onboarding step-complete reach-ins.
- `dashboard/index.html` no longer contains `id="trade-ticket"`, `id="onboarding-checklist"`, or any modal `<dialog>` elements except those used by KEEP surfaces.
- `dashboard/api-keys.js` and `dashboard/api-keys.html` exist and load correctly when accessed via browser (covered by browser smoke test in Team C).
- `legacy/dashboard-ui/app.js`, `legacy/dashboard-ui/index.html`, `legacy/dashboard-ui/settings.js`, `legacy/dashboard-ui/leaderboard-submit.js` exist with the pre-trim content.
- `dashboard/event-contract.md` is pruned to 3 events; preamble updated.
- `dashboard/leaderboard.html` still renders the table (Team C verifies via Playwright).

### Team C — Test moves + INFRA test refactor (`tests/`)

Owner: api team (tests/) per file ownership rules — but coordinate with dashboard team for the e2e/ split since those tests directly exercise dashboard surfaces.
Worktree: yes
Depends on: Team A merged (the cut files exist at `legacy/dashboard-ui/` so legacy tests can find them) AND Team B merged (so the trimmed HTML/JS doesn't break read-only journeys)

Scope:
1. **git-mv the 9 CUT e2e tests** to `legacy/tests/e2e/`:
   - `journey-05-trade.spec.ts`
   - `journey-06a-settings-profile.spec.ts`
   - `journey-06b-settings-plugins.spec.ts`
   - `journey-06c-settings-billing.spec.ts`
   - `journey-06d-settings-danger-zone.spec.ts`
   - `journey-08-billing.spec.ts`
   - `journey-12-forgot-password.spec.ts` — DOUBLE-CHECK: forgot-password is auth, not write-path-trading-UI. If it's an auth flow and we keep auth, this test should KEEP. Reclassify if needed during execution.
   - `journey-onboarding.spec.ts`
   - `journey-modal-stacking.spec.ts`
2. **Verify KEEP e2e tests still pass against trimmed dashboard.** Run `npx playwright test tests/e2e/journey-{01,02,03,04,07,10,14,15,shared-nav}.spec.ts`. Expect failures only for assertions that referenced removed DOM (e.g., `journey-04-dashboard.spec.ts` may have asserted "trade ticket button visible" — those assertions need updating, not the test removed). Update assertions to match the trimmed surface.
3. **INFRA e2e tests (`mobile`, `keyboard`, `cli-serve`, `benchmark-blindness`, `csrf-hydration`, `sim-time-tile`, `trusted-types`)** stay in production tests/. If any reference a CUT surface assertion, update the assertion to point at a KEEP surface (e.g., mobile drawer test that opens the user menu — keep that, just remove the "Manage Plugins" drawer item assertion if it's gone).
4. **Update `playwright.config.ts`** (or wherever the test path glob is) to exclude `legacy/tests/e2e/` from default runs. Add a separate npm script `test:legacy-e2e` for executing the legacy tests on demand.

Validation:
- `npm run test:e2e` (default) runs only the production tests, all green.
- `npm run test:legacy-e2e` runs the moved tests (they'll likely fail because the surfaces are gone — that's expected; the script is for archaeological / future-restore use only).
- `git log --follow legacy/tests/e2e/journey-05-trade.spec.ts` shows full history.

### Team D — Documentation + CLAUDE.md + REMAINING_TASKS

Owner: docs team
Worktree: yes
Depends on: nothing (runs in parallel with A/B/C)

Scope:
1. **`docs/ARCHITECTURE.md`** — major revision. Replace any references to onboarding wizard, trade ticket, settings forms, plugin install UI, billing UI, marketplace UI with a section explaining the launch cut. Note that those routes still exist in `finlet/api/` for CLI/MCP use, but no UI consumes them.
2. **`README.md`** — update the "what is Finlet" section to lead with CLI/MCP usage. Quickstart should be `npm install -g finlet && finlet quickstart`, NOT "go to finlet.dev and click Sign Up." The website is now described as "monitoring dashboard for your agent's sessions."
3. **`docs/REMAINING_TASKS.md`** — add a "2026-05-06: UI write-path cut" section. Close any pending UI-bug TODOs that the cut retires.
4. **`CLAUDE.md`** — update the dashboard conventions block. Specifically:
   - The `dashboard-form-dirty-tracker.js` and `dialog-state-mirror.js` invariants reference modules that have moved. Either remove those invariants or note "applies to legacy/dashboard-ui/ only — production dashboard has no forms or write-path dialogs."
   - The trade-ticket render-on-read exception (`docs/decisions/trade-ticket-render-on-read.md`) becomes legacy. Note it.
   - The onboarding registry block references modules that moved. Same treatment.
   - Keep the trusted-types invariant (the lint guard still runs, defensive).
   - Keep the event-bus invariant (read-only surfaces still use it).
5. **`legacy/README.md`** — Team A creates this with a stub; Team D writes the full content. Sections: "Why this exists" (link decision record), "What's here" (link surface map), "How to restore" (the two paths: dir-copy or tag-checkout), "Do NOT modify" (the pre-commit guard from Team E enforces this; explain why).
6. **Move `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` to `status: shipped`** AFTER all team merges land. This is the last step — Team D's final commit on this refactor.
7. **Append to `docs/LESSONS.md`:** "When >90% of bug-hunt findings cluster in a UI surface that the launch user (an LLM agent) doesn't touch, the answer is to cut the surface, not refactor it. Twelve refactors with 50% effectiveness on the same dashboard cluster were the trigger." This is the meta-lesson for future bug-hunt-loop tuning.

Validation:
- `docs/ARCHITECTURE.md` no longer describes UI write paths as production features.
- `README.md` quickstart leads with CLI/MCP.
- `CLAUDE.md` invariants for `form-dirty-tracker`, `dialog-state-mirror`, `onboarding registries`, `trade-ticket render-on-read` are either removed or annotated as `legacy/`-only.
- `legacy/README.md` is full content (not stub).
- `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` shows `status: shipped` after all other teams merge (Team D's last commit).

### Team E — CI guards + pre-commit hook

Owner: ops team (`.github/`) + infra team (`scripts/`)
Worktree: yes
Depends on: Teams A, B, C merged (legacy/ structure stable before guards lock it down)

Scope:
1. **New script: `scripts/lint-no-legacy-edits.sh`** — pre-commit hook that fails if any staged file under `legacy/` has been modified (added is allowed for the initial migration commits; modified after that is blocked). Logic: `git diff --cached --name-only --diff-filter=M | grep -E '^legacy/' && exit 1`.
2. **Update `scripts/setup-git-hooks.sh`** to install the new lint script alongside the existing `lint-trusted-types.sh` and `lint-event-bus.sh`.
3. **Update `.gitattributes`** — add `legacy/** linguist-vendored` so GitHub's language stats don't count legacy code, and `legacy/** linguist-generated=true` so diffs are collapsed by default in PR review.
4. **Update `.github/workflows/ci.yml`** to exclude `legacy/` from:
   - pytest collection (`--ignore=legacy/`)
   - ruff lint (it already only targets `finlet/` and `tests/`, but verify)
   - mypy
   - npm test:e2e (Team C handled this in playwright.config.ts; Team E verifies)
   - any pip-audit / npm-audit scans (legacy code has no production exposure)
5. **Update `.github/workflows/deploy.yml`** to verify `legacy/` is NOT included in the Cloudflare Pages / dashboard deploy artifact. The deploy should ship `dashboard/` only.

Validation:
- `git commit` with a modified file under `legacy/` is blocked by pre-commit.
- `git commit` with a new file under `legacy/` succeeds (initial migration must be allowed).
- CI run on a feature branch: tests pass, lint passes, no legacy/ errors surfacing.
- Deployed dashboard at finlet.dev does NOT serve any path under `/legacy/`.

### Team F (optional, can defer to next iteration) — Backend route audit

Owner: api team
Worktree: yes
Depends on: nothing

Scope: Verify the 8 write-path API routes flagged in the surface map are actually exercised by CLI/MCP. If any route exists ONLY for the now-removed UI consumer, flag it for deletion in a follow-up refactor. Don't delete anything in this iteration — this is just an audit producing a report at `docs/bug-hunt/20260507T042257Z3c76/api_route_audit.md`. The report informs the next /bug-hunt iteration's planning.

Validation:
- Report exists with one line per route: `route → consumer (CLI command, MCP tool name, or "ORPHANED — no CLI/MCP consumer found")`.

## Validation (refactor-level acceptance)

Before the queue doc is set to `verdict: effective`, the next bug-hunt iteration must satisfy:

1. **Blind walk completes the trade-placement task entirely via CLI/MCP** without falling back to the UI. Specifically: the agent's `_isolation_check` should NOT include "I had to use the trade ticket UI because MCP tools weren't available."
2. **Zero new ledger entries** in any of these categories: `dashboard-state-sync`, `onboarding-checklist`, `dirty-state-tracker`, `dead-affordance`, `modal-stacking`, `aria-label-mismatch`, `password-form-aria`, `price-discrepancy`. (The lint-guarded `trusted-types` category may still surface if a vendor file regresses; that's not a verdict-breaker.)
3. **Production dashboard at finlet.dev** loads and renders all KEEP surfaces (login, equity curve, positions table, trade log, sessions list, plugin health, leaderboard, API key listing).
4. **CI green** on main with the legacy/ exclusion in place.
5. **At least one new ledger entry surfaces a CLI or MCP bug** (or zero new entries at all). The bug-hunt focus shifts from UI to CLI/MCP discoverability — the next iteration's blind walk should expose those surfaces, and finding bugs there is success-mode for this refactor.

If criteria 1 fails (UI fallback still happens), the cut was incomplete — likely a missed write-path surface. Verdict: `incomplete`, follow-up scope drafted.

If criteria 2 fails (one of the listed categories still surfaces), it's likely a TRIM that wasn't trimmed deeply enough. Verdict: `incomplete`, follow-up scope drafted.

If criteria 3 fails (production dashboard breaks), this is a regression — Team A or B left a dangling include or removed a KEEP surface by accident. Verdict: `regressed`, hotfix required before next bug-hunt iteration.

## Risk register

- **Cloudflare Pages cache** may serve the old dashboard for up to 24 hours after deploy. Mitigation: Team E verifies post-deploy cache purge, or accept the 24h transition period.
- **Existing user sessions with bookmarks to `/settings.html`, `/billing.html`, etc.** will 404. Mitigation: add 301 redirects from the cut paths to `/index.html` (or to the API-keys-only `/api-keys.html`). Out of scope for this refactor doc; flag as a follow-up if user traffic warrants.
- **CI / deploy pipeline assumes `dashboard/` is the source of truth** — if any pipeline step globs over `dashboard/**` and the include resolves to a moved file, build breaks. Team E must run a test deploy in a staging branch before merging.
- **Legacy code may have accumulated security debt** that wasn't a problem when it was deployed (e.g., XSS in a rarely-used flow). Once moved to `legacy/`, it's no longer scanned. Mitigation: Team E adds a comment in `legacy/README.md`: "If we ever restore a legacy file to production, run a security review on it first — this code has been frozen since 2026-05-06 and may not meet current standards."
- **Cut files referenced in `docs/`** (architecture diagrams, decision records pointing at module paths) will silently rot. Team D's job to grep for those during the docs sweep.
- **Team A and Team B both touch index.html** — Team A removes `<script>` tags, Team B trims panels. Hard sequence: A merges first, then B. The plan-features dependency graph must enforce this.

## Out of scope (defer)

- **Migrating CLI/MCP onboarding UX.** The blind walk found "Finlet benchmark MCP tools not present in tool registry" — that's a separate refactor (CLI/MCP discoverability) that this cut enables but doesn't address.
- **Adding new monitoring widgets** (live order log SSE, session comparison, leaderboard filtering). These can be added post-cut as new KEEP-class surfaces.
- **Removing the cut API routes from `finlet/api/`.** Team F audits, doesn't remove. Removal is a future refactor if Team F finds orphaned routes.
- **301 redirects for cut paths.** Mention in risk register; defer unless user traffic warrants.
- **Marketing landing page rework.** The cut keeps `landing.html` as-is. A future refactor may rewrite it to lead with CLI/MCP setup, but this iteration just preserves it.

## Break-even

The refactor saves at least one bug-hunt iteration per week (current cadence: ~2 iterations/week, ~1.5 of which find UI write-path bugs). At ~$2 per blind walk + ~$5-15 per iteration's exec-plan run, the refactor pays back in <2 iterations of avoided UI bug-hunting. With the 12-shipped refactors at 50% effectiveness on the same surfaces, the alternative cost (continuing the patch-cycle) is order-of-magnitude higher than this one-time cut.
