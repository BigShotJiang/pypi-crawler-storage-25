# Bug-Hunt 20260427T231917Z3b58 — Execution Plan

> Generated from `docs/bug-hunt/20260427T231917Z3b58/triage.md`. Last updated: 2026-04-27.
> Source: blind-agent walkthrough of finlet.dev, triage rule = design-intent contradiction.

## Constraints

- Fix 6 real-broken items only. Do not act on the 7 logged items (annoying / nice-to-have).
- Each team merges to `main` individually. No long-lived feature branches.
- All teams must `git add` + `git commit` before exiting their worktree.
- All bug fixes must come with a regression test or a manual repro note explaining why a test isn't feasible.
- No new dependencies. Reuse existing patterns in the touched files.

## File Conflict Table

| File | Touched by Teams |
|------|------------------|
| `dashboard/onboarding.js` | A |
| `dashboard/app.js` | A, B |
| `finlet/core/portfolio.py` | B |
| `finlet/api/routes_session.py` (PortfolioResponse / metric DTO) | B (read-only, may extend) |
| `finlet/api/security_middleware.py` | C |
| `dashboard/index.html` | (none — Sentry script tag stays; only CSP changes) |

**Shared file:** `dashboard/app.js` is touched by both A and B. They modify different regions (A: `handleCreateSession` modal success callback ~line 1300; B: `fetchPortfolioAndOrders` overview tile render ~line 1700) but share the file → must merge sequentially.

## Dependency Graph

- **Team A** (onboarding correctness) — independent, no blockers.
- **Team B** (win-rate metric) — file-conflicts with A on `dashboard/app.js`. Blocked by A.
- **Team C** (Sentry CSP allowlist) — independent, no blockers.

```
Team A ──→ Team B
Team C (parallel, independent)
```

## Critical Path

```
Team A → Team B
```

C runs in parallel with A and B; it gates only on its own per-merge tests.

---

## Teams

### Team A: Onboarding Flow Correctness

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/onboarding.js` (~700 lines) — wizard logic, checklist state, localStorage `finlet_onboarding` schema, `handleSessionCreate` at line 358–410, `buildChecklistItem` at line 647
- `dashboard/app.js` lines 1266–1332 — `handleCreateSession()` modal handler that POSTs `start_time` (the working contract)
- `finlet/api/routes_session.py` lines 36–46 — `SessionCreateRequest` Pydantic model; `start_time: datetime` is the canonical field, no `start_date` accepted

**Files touched:**
- Modified: `dashboard/onboarding.js` — three changes:
  1. `handleSessionCreate` (line 375): change request payload key from `start_date` to `start_time`, and emit a full ISO datetime (e.g. `start + "T09:30:00Z"` instead of `+ "T00:00:00Z"`) to match the modal contract.
  2. `buildChecklistItem` for the `'strategy'` row (line 618): add a click handler on the rendered `.checklist-item[data-checklist-key="strategy"]` that opens the existing Submit-to-Leaderboard modal (or whatever modal exposes the strategy-category selector). Use the same `document.querySelector` + `.click()` pattern other handlers use, or wire a real onclick.
  3. Export a `markStepComplete(stepKey)` helper from `onboarding.js` (or add to existing exported surface) so other files can flip checklist steps without reaching into localStorage themselves.
- Modified: `dashboard/app.js` lines 1266–1332 — in the modal `handleCreateSession()` success branch (right after the 201 response), call the new `markStepComplete('session')` helper from `onboarding.js`. This fixes the desync where modal-created sessions never tick the checklist.

**Deliverable:** A new user can complete the onboarding wizard end-to-end without 422; OR they can use the modal and the checklist updates correctly. The "Save first strategy" row opens the strategy picker on click.

**Validation:**
- [ ] `cd dashboard && npx eslint onboarding.js app.js` passes (or the project's existing JS linter — check `package.json`)
- [ ] Manual: open `dashboard/index.html` against a local Finlet server, complete the onboarding wizard, verify `POST /sessions` returns 201 and the checklist ticks `Create first session`
- [ ] Manual: click `Save first strategy` on the checklist; verify a modal opens
- [ ] Manual: create a session via the modal "New" button; verify the checklist `Create first session` ticks
- [ ] No regressions in the wizard's other steps (profile, analysis flow if any)

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Use a clear message: `fix(dashboard): align wizard session payload + wire modal checklist + strategy click handler`.
- Follow the existing code patterns in `dashboard/onboarding.js` — it's vanilla JS, no framework. Look at `apiPost`, `saveState`, `updateChecklist` and reuse them.
- Do NOT change `finlet/api/routes_session.py`. The API contract is correct; the wizard is wrong.
- If the strategy modal does not exist with a clear DOM id, surface the gap in your commit message and degrade `Save first strategy` to a `console.warn` / no-op rather than fabricating a modal — but at minimum the click should not be silent.

---

### Team B: Win Rate Metric Correctness

**Blocked by:** Team A (file conflict on `dashboard/app.js`; A merges first).

**Read these files first:**
- `finlet/core/portfolio.py` lines 305–373 — `win_rate` and `trade_count` properties; `_trade_pnls` is appended only in `_sell_unlocked()` (line 210) on realized exits. Buys do NOT increment.
- `finlet/api/routes_session.py` (or wherever `PortfolioResponse` is defined) — find the response model that surfaces `win_rate` and `trade_count` to the dashboard. Grep `class PortfolioResponse`.
- `dashboard/app.js` lines 1697–1747 — overview tile render; `wrEl = document.getElementById('win-rate')` is the Win Rate tile output.

**Files touched:**
- Modified: `finlet/core/portfolio.py` — add (or expose) a `total_orders_filled` count (number of `OrderStatus.FILLED` events seen, both BUY and SELL). The existing `trade_count` property stays as the count of *closed* trades (preserves the win-rate semantics). Do NOT redefine `trade_count` — that breaks the win-rate denominator semantics.
- Modified: `finlet/api/routes_session.py` (or the response file) — extend `PortfolioResponse` with the new field (e.g. `orders_filled: int`). Backwards-compatible additive change.
- Modified: `dashboard/app.js` lines 1697–1747 — change the Win Rate tile copy so it is not misleading when `trade_count == 0`. Two acceptable shapes:
  - `Win Rate — N/A (0 closed trades, X open positions)` when no closed trades yet.
  - Or keep `Win Rate X%` but append `(M closed / N filled)` so it's clear that 0 closed ≠ no activity.
- Modified or new: `tests/core/test_portfolio.py` — add a test: after a single BUY fill, `orders_filled == 1` and `trade_count == 0` and `win_rate == 0.0`. After matching SELL, `trade_count == 1`, `win_rate` reflects the realized P&L.

**Deliverable:** After a BUY-only fill, the Win Rate tile no longer reads "Win Rate 0.0% — 0 trades" in a way that contradicts visible Order Log activity. Backend reports both metrics; dashboard renders them honestly.

**Validation:**
- [ ] `uv run pytest tests/core/test_portfolio.py -x -q` passes (or pytest path that exists today)
- [ ] `uv run mypy finlet/core/portfolio.py finlet/api/routes_session.py` clean
- [ ] Manual: place a BUY via dashboard, verify Win Rate tile reads sensibly (not "0 trades" when 1 order filled)

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Message: `fix(core+dashboard): show orders-filled alongside win-rate so single BUY isn't misleading`.
- Reuse the existing `Portfolio` mutation lock — any new counter must be incremented under the same `asyncio.Lock()` as `_trade_pnls`.
- Do NOT change the semantic of `win_rate` (wins / closed trades). The tile is what's wrong, not the metric.
- If `PortfolioResponse` lives in `finlet/api/dto/` or similar, follow that pattern; do not re-define it inline.

---

### Team C: Sentry CSP Allowlist

**Blocked by:** none — can start immediately, parallel with A.

**Read these files first:**
- `finlet/api/security_middleware.py` lines 218–230 — current CSP `script-src` directive: `'self' 'strict-dynamic' 'nonce-{nonce}' https://cdn.jsdelivr.net https://accounts.google.com`
- `dashboard/feedback.js` lines 26–65 — Sentry init (reads DSN from meta tag, falls back silently)
- `dashboard/index.html` line 589 — `<script src="https://browser.sentry-cdn.com/8.x/bundle.min.js">`

**Files touched:**
- Modified: `finlet/api/security_middleware.py` lines 218–230 — append `https://browser.sentry-cdn.com` to the `script-src` directive. Append it to any other directives Sentry's runtime needs (`connect-src` for ingest endpoint, e.g. `https://*.ingest.sentry.io` or the DSN host — check current Sentry SDK 8.x docs in-code; if `feedback.js` only initializes the SDK and uses the configured DSN, `connect-src` likely needs the DSN's host as well).
- Modified or new: `tests/api/test_security_middleware.py` — add a test that asserts the CSP `script-src` directive contains `https://browser.sentry-cdn.com`.

**Deliverable:** Sentry script tag loads without console 403; runtime errors on production are captured.

**Validation:**
- [ ] `uv run pytest tests/api/test_security_middleware.py -x -q` passes
- [ ] Manual: load `dashboard/index.html` against a local server with the new middleware; verify Network tab shows `200` for `browser.sentry-cdn.com/8.x/bundle.min.js` and no CSP violation in console
- [ ] Manual: trigger a JS error (`throw new Error('test')` in console); verify a Sentry network call goes out

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Message: `fix(api): allowlist sentry CDN + ingest in CSP so runtime error capture works`.
- Do NOT relax `'strict-dynamic'` or remove the nonce. Append, don't replace.
- Do NOT add `'unsafe-inline'`. The fix is host allowlist only.
- If the production DSN is set in deploy env vars (look at `deploy/`), do not log it in any test or commit.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Wizard `start_time` change breaks an unknown second consumer | Low | Medium | Grep `dashboard/` for other `start_date` posters; only `onboarding.js:375` matches. |
| `markStepComplete` import cycle between `onboarding.js` and `app.js` | Low | Medium | Add the helper as a top-level export on a `window.finletOnboarding` object (the codebase is non-module vanilla JS); call it via the global. |
| Strategy modal click handler dispatches to a non-existent modal | Medium | Low | If modal id missing, fall back to `console.warn` instead of fabricating; surface in commit. |
| `PortfolioResponse` schema change breaks an MCP consumer | Low | Medium | Field addition is backwards-compatible. Verify via `grep PortfolioResponse finlet/`. |
| CSP `connect-src` needs Sentry ingest host but it's tenant-specific | Medium | Low | Read DSN from env or `dashboard/index.html` meta tag at boot; if not feasible, allowlist `https://*.ingest.sentry.io` (Sentry SaaS pattern) and document. |
| Sentry SDK 8.x bundle changes since CSP was authored — may need `worker-src` or `report-uri` | Low | Low | Test page-load + capture in dev; if SDK warns about missing directive, add it. |

## Session Plan

### Session 1 (this iteration)

**Sequential merge order:**
1. **Team A merges first** (onboarding correctness, no dependencies)
2. After A merges → run targeted tests (`uv run pytest tests/api -x` + manual dashboard load)
3. **Team B merges** (depends on A; resolves any app.js merge conflict cleanly because regions don't overlap)
4. After B merges → run `uv run pytest tests/core tests/api -x`

**Parallel:**
- **Team C** runs alongside A and B, merges whenever it's ready (no file conflicts). Gate is its own targeted test.

**Session checkpoint after all three teams merged:**
- [ ] Full pytest suite: `uv run pytest -x -q`
- [ ] Full lint: `uv run ruff check finlet/ tests/` + `uv run mypy finlet/`
- [ ] Manual smoke: load `dashboard/index.html`, complete onboarding wizard, place a BUY, verify Win Rate tile, verify no CSP console errors

If the checkpoint passes, push to `main`. The bug-hunt iteration is complete.

---

## Execution Status — COMPLETED 2026-04-27

| Team | Branch | Commit | Merge | Status |
|------|--------|--------|-------|--------|
| A | worktree-agent-ad159dde23eee55ab | c17a8ed | ca9c3a0 | COMPLETED |
| B | worktree-agent-a9e604cf692109680 | fc2a212 | 6c2a89b | COMPLETED |
| C | worktree-agent-a0dd5e43af2856ac6 | e1827ec | 8cad791 | COMPLETED |

Session 1 checkpoint: 3883 passed, 0 failed (full suite).
