# CLI session-create 429 trace

Recon doc — bug-hunt 20260504T165106Z1ab2 follow-up. The blind-agent symptom
("HTTP 429 on `httpx.ReadTimeout` retry with same Idempotency-Key") was
real, but the previous fix-shape assumption (`check_session_creation`
running before idempotency lookup) is wrong. This trace replaces it.

## All 429 origin sites

| File:Line | Origin | Triggered when |
|---|---|---|
| `finlet/api/rate_limit/session.py:34-41` | `check_session_creation` — concurrent-session limit | `user.active_sessions >= max_concurrent` (FREE=1, BUILDER=10, INSIGHTS=50, ENTERPRISE=None) |
| `finlet/api/rate_limit/session.py:50-77` | `check_session_creation` — daily session limit | `user.sessions_today >= max_sessions_day` (FREE=4, +1 with research_network; BUILDER+ unlimited) |
| `finlet/api/routes_market.py:113` | `_route_query_with_rate_limit` | `RateLimitError` raised by Finnhub-rate-limited plugin queries |
| `finlet/api/routes_auth_credentials.py:249` | `register` (auth) | per-IP registration burst limit |
| `finlet/api/routes_auth_credentials.py:339` | `forgot password` flow | per-IP reset rate |
| `finlet/api/routes_auth_mfa.py:69-70` | MFA endpoint | `RateLimitExceeded` from MFA recovery rate limiter |
| `finlet/api/routes_csp.py:96` | `/telemetry/client-security` | per-IP, 20/min — telemetry only, NOT in `/sessions` path |
| `finlet/auth/mfa/recovery.py:28` | `RateLimitExceeded` (forgot-key) | 3 per hour per email |

For `POST /sessions` specifically, only the two `check_session_creation`
branches in `finlet/api/rate_limit/session.py` apply. There are no other
429-emitting middleware/routes wrapping `/sessions`.

## routes_session.py order of operations (`POST /sessions`)

(`finlet/api/routes_session.py:95-177`)

1. `:99` — FastAPI extracts `Idempotency-Key` header into `idempotency_key: str | None`.
2. `:111` — `idem_session_ns = f"user:{user.id}:sessions"` (per-user namespace).
3. `:112-121` — `cached = await _idempotency_store.get(idempotency_key, idem_session_ns)`. **If cached, return immediately** — no rate-limit check, no session-creation work.
4. `:124` — `check_session_creation(user)` (raises 429 on either concurrent or daily ceiling).
5. `:127-139` — `await create_session(...)` — slow path: `_validate_coverage` (HTTP/I-O), `create_session_db`, `save_session`, lock acquisition.
6. `:140-160` — `CoverageError` → 400; `ValidationError` → 422.
7. `:162` — `record_session_created(user)` — sync, in-memory mutation: `user.sessions_today += 1; user.active_sessions += 1`. **No DB persist** (see ``finlet/api/rate_limit/session.py:80-84``).
8. `:163` — `response = session_response(session)`.
9. `:165-175` — `await _idempotency_store.store(idempotency_key, idem_session_ns, response)` (best-effort; logs on failure).
10. `:177` — `return response`.

Key fact: the idempotency cache lookup at step 3 IS before the rate-limit
check at step 4. The previous fix plan was based on a misreading.

The vulnerability is that step 5 (slow `create_session`) runs BEFORE step 7
(`record_session_created`) AND BEFORE step 9 (`_idempotency_store.store`).
This creates an interleaving window where a second concurrent request with
the same key sees `active_sessions=0` and no cached entry — but if the
original request has by then completed step 7 (counter mutation) without
yet completing step 9 (cache write), the retry will trip step 4's 429.

## CLI retry path

- File: `finlet/cli.py:75-160`
- Idempotency-Key handling: **REUSED on `httpx.ReadTimeout`**. The header
  dict is built once at lines 103-104 and reused at line 125 for the
  retry. New UUID is only generated per CLI invocation.
- Snippet (lines 98-129, abridged):

  ```python
  # Send an idempotency key so the server can dedupe a retried POST after a
  # client-side ReadTimeout. Plugin init can take longer than 10s on a cold
  # start, which previously caused the CLI to report failure on a session
  # that had actually been created server-side ...
  headers = _api_headers(api_key)
  headers["Idempotency-Key"] = f"cli-session-create-{uuid.uuid4()}"
  ...
  try:
      resp = httpx.post(f"{_API_URL}/sessions", json=body, headers=headers, timeout=60)
      resp.raise_for_status()
      _print_created(resp.json())
  except httpx.ConnectError:
      ...
  except httpx.ReadTimeout:
      # Retry with the same Idempotency-Key so the server returns the
      # cached first response if it completed.
      try:
          retry_resp = httpx.post(
              f"{_API_URL}/sessions", json=body, headers=headers, timeout=60
          )
          retry_resp.raise_for_status()
          _print_created(retry_resp.json())
          return
      except httpx.HTTPStatusError as retry_err:
          # Idempotency replay failed — fall back to a name-based GET ...
  ```

  The retry reuses `headers` verbatim, including the same UUID Idempotency-Key.

## Hypothesis verdicts

### H1 cold-start race (plugin init)

- Verdict: **CONTRADICTED** as a 429-cause, but **CONFIRMED** as the
  trigger for the underlying ReadTimeout that exposes the race.
- Evidence: `finlet/api/app.py:200-236` — `registry.initialize_all` is
  awaited in the `lifespan` startup hook AND `wait_until_ready(timeout=30s)`
  blocks the server from accepting requests until plugins are ready or
  timeout fires. So plugin-init is not racing per request — it's a
  startup-only event. However, `_validate_coverage`
  (`finlet/api/services/session_service.py:39-93`) calls
  `get_ticker_availability()` which can be slow on cold cache; combined
  with `create_session_db`/`save_session`, the create path can exceed
  the CLI's `timeout=60`. The slow create is what triggers
  `httpx.ReadTimeout` in the first place — but it does not produce 429
  by itself.

### H2 separate dedup path

- Verdict: **CONTRADICTED**.
- Evidence: I grep'd the entire `/sessions` middleware/handler chain —
  no per-user cooldown, no Redis throttle, no IP throttle on session
  create. The only 429 paths reachable from `POST /sessions` are the
  two in `check_session_creation` (`session.py:34-77`). The 429 IS the
  rate-limit, not a parallel dedup check.

### H3 upstream 429 propagation

- Verdict: **CONTRADICTED**.
- Evidence: `routes_market.py:112-113` shows the only path where a
  plugin's `RateLimitError` is converted to HTTP 429. That conversion
  happens inside `_route_query_with_rate_limit`, which is wired to
  `/v1/market/...` endpoints, NOT to `/sessions`. `create_session`'s
  call into `_validate_coverage` → `get_ticker_availability` does NOT
  raise `RateLimitError` (`routes_market.py:622+`); it reads cached
  availability JSON. The 429 the user sees on retry is generated locally
  by `check_session_creation`, not propagated from a plugin.

## Most likely root cause

The 429 is produced by `check_session_creation` on the RETRY — not the
first request. The original (slow) request is still mid-flight inside
`create_session(...)` when the CLI's 60s timeout fires, but it has
ALREADY (a) returned from `create_session` and (b) executed
`record_session_created(user)` (step 7), which mutates the SHARED
in-memory `UserRecord` to `active_sessions=1`. It has NOT YET completed
`_idempotency_store.store(...)` (step 9). The CLI then retries; the
retry's `_idempotency_store.get(...)` returns `None` (cache row not yet
written or commit not yet flushed); the retry falls through to
`check_session_creation`, which sees `user.active_sessions=1 >= max_concurrent=1`
on a FREE tier user (or an equivalent ceiling on higher tiers when the
account is genuinely at the limit) and raises 429.

A simpler degenerate variant: the CLI's `timeout=60` is exceeded by
`create_session` even when nothing is wrong server-side; the server
eventually completes successfully and writes the idempotency cache row
**after** the CLI has already given up and retried. If the retry's
`get()` fires before the original's `store()` commits (likely, given
the `await create_session()` is the slow phase and `record_session_created`
runs before `store`), the retry reads `None` and trips the rate limit.

In short: the in-memory counter mutation (step 7) and the persistent
idempotency-cache write (step 9) are not atomic. When a retry slips
between them, the rate-limit gate fires before the dedup gate can match.
The comment on `cli.py:99-102` correctly identifies the symptom but the
server-side ordering does not actually protect against it.

## Recommended fix shape (for next iteration's plan-features)

Goal: the second request with the same Idempotency-Key MUST NOT trip the
rate-limit gate, even if the first request hasn't yet finished writing
its cache row.

Two complementary changes — pick one or stack:

- **File:** `finlet/api/routes_session.py:111-167`
  **Change:** Reserve the idempotency key BEFORE the rate-limit check.
  Insert a placeholder row into `idempotency_keys` (key + namespace +
  empty response) immediately after the cache lookup miss, using the
  UNIQUE constraint on `key` to atomically claim the slot. If the
  insert raises `IntegrityError`, another request already owns this
  key — wait briefly (e.g. retry the SELECT 2-3 times with 100ms
  back-off, capped at 1s) for the original to complete, then return
  the cached row. Only AFTER successful claim should
  `check_session_creation`/`create_session`/`record_session_created`
  run. Update `_idempotency_store.store` to UPDATE the placeholder
  with the real `response_json` rather than INSERT.
  **Test:** `tests/api/test_session_idempotency.py` —
  hypothesis/asyncio test that fires N=10 concurrent POSTs with the
  same Idempotency-Key from the same user and asserts (a) exactly one
  session was created, (b) all responses are equal, (c) no 429 is
  returned.

- **File:** `finlet/api/rate_limit/session.py:80-84` and
  `finlet/api/routes_session.py:124-162`
  **Change:** Move `record_session_created` to run BEFORE
  `await create_session(...)` (or merge it into `check_session_creation`
  so the check-and-claim is one critical section). On `create_session`
  failure (CoverageError, ValidationError, exception), call a
  compensating `record_session_failed` that reverts the counter. This
  closes a separate latent bug where a `CoverageError`/`ValidationError`
  return path skips the counter increment yet the response is still
  cached on retry — but combined with the placeholder above, it
  guarantees that a retry sees `active_sessions` reflecting the
  in-flight original.
  **Test:** `tests/api/test_session_rate_limit.py` — direct call test
  that asserts `record_session_created` is invoked even when
  `create_session` raises, and that `record_session_deleted`/the
  compensator restores the counter on the failure path.

- **Optional, defense-in-depth:** `finlet/cli.py:113-130`
  **Change:** On `httpx.ReadTimeout`, attempt a name-based `GET /sessions`
  FIRST (fall-through path that already exists at `cli.py:134-144`),
  treating an existing-name-match as success. Only retry the POST if
  the GET returns no match. This avoids the doomed-retry pattern
  entirely on the happy path where the original POST did succeed
  server-side.
  **Test:** `tests/test_cli.py` — patch `httpx.post` to raise
  `ReadTimeout`, patch `httpx.get` to return one matching session,
  assert no second POST is fired.

## Secondary observations (not the bug, but worth noting)

- `record_session_created` (`session.py:80-84`) mutates the in-memory
  `UserRecord` only. The DB row in `api_keys.active_sessions` is not
  touched on the create path. It's mutated through
  `auth_service.increment_active_sessions()` (`auth/service.py:637-644`),
  but that helper has no caller in the create-session route — only in
  marketplace/billing flows. After a process restart, `active_sessions`
  is reloaded from the (stale) DB value, which can either over- or
  under-count. This is a pre-existing inconsistency but not the cause
  of the 429-on-retry bug.
- The `idempotency_keys` table has no Alembic migration. Creation
  happens via `create_auth_db` (`db/engine.py:200-207`) at startup,
  which uses `checkfirst=True` and runs unconditionally
  (`api/app.py:169`), so the table is created on the first server boot
  with this model registered. Existing production DBs will pick it up
  on next deploy. Not a bug, but worth recording — moving to a real
  migration would make the schema lifecycle auditable.
- The CLI's name-based fallback at `cli.py:134-144` uses the session
  NAME as the dedupe key. That is fragile: two sessions with the same
  name could exist (if the user re-runs after rotating an old session
  out), and the fallback would silently surface the wrong session ID.
