# Bug-Hunt Post-Mortem — 2026-04-28

> Decision: refactor the dashboard event surface. Next chat session executes the plan below via `/plan-features` → `/exec-plan`.

## Why we're here

Two bug-hunt iterations (`20260428T013300Z6e79`, `20260428T031818Z2efa`) shipped 14 real-broken patches. Source of truth: `docs/bug-hunt/ledger.jsonl`.

10 of 14 (71%) cluster in three categories:
- **onboarding-checklist** — 4 instances
- **dashboard-state-sync** — 3 instances
- **trusted-types** — 3 instances

Each iteration we patched one subscriber-to-event wiring at a time. Same shape, different file. This is a missing-convention bug, not 14 independent bugs.

## Root cause

The dashboard has no event-bus convention. State changes propagate via:
- direct SSE listener attach inside the consumer (Trade Ticket adds its own `EventSource` consumer logic at open / removes at close — the *consumer* owns lifecycle, not the bus)
- ad-hoc `CustomEvent('finlet:portfolio-update', ...)` re-broadcast on top of SSE because the SSE handler couldn't be subscribed to directly
- `window.finletOnboarding?.markStepComplete?.('analysis')` reach-ins from the orders SSE handler at `dashboard/app.js:~1444`
- bespoke checklist row click wiring per row, with no contract for "row activated → mark step + advance counter"

When a feature ships a new mutation, the author has to:
1. Pick a propagation mechanism (direct, SSE, CustomEvent, reach-in)
2. Find every consumer of the now-stale state
3. Wire each one manually
4. Hope future authors find the wiring they didn't write

Step 2 fails silently every time. That's the recurrence.

For Trusted Types specifically: the dashboard has a working `trustedHTML()` wrapper at `dashboard/api-utils.js:469`, but vendor bundles (TradingView lightweight-charts) and ad-hoc innerHTML calls bypass it. There's no lint guard, so each new innerHTML call is one bug-hunt iteration away from a console violation.

## Refactor scope

Three teams, one session of `/exec-plan`. Estimate ~6–8 hours of agent work.

### Team 1: Event-bus convention codification

**Files touched:**
- New: `dashboard/event-bus.js` — single module exporting `bus.subscribe(event, handler) → unsubscribe` and `bus.publish(event, payload)`. Backed by a `Map<event, Set<handler>>`. No global window leaks except `window.finletBus` for hot-path consumers.
- New: `dashboard/event-contract.md` — enumerates every event name (`portfolio:updated`, `order:filled`, `session:switched`, `onboarding:step-completed`, etc.), payload shape, and which surface owns publish vs subscribe.
- Modified: `dashboard/app.js` — replace direct CustomEvent fanout (~line ~1444 area) with `bus.publish('order:filled', detail)` and `bus.publish('portfolio:updated', detail)`. SSE handler becomes the single publisher.

**Deliverable:** every dashboard mutation publishes one event; no consumer attaches to SSE directly.

### Team 2: Onboarding state machine

**Files touched:**
- Modified: `dashboard/onboarding.js` — collapse the four checklist steps into a state machine indexed by step key. Each step subscribes to its trigger event via the bus (`bus.subscribe('order:filled', ...) → markStepComplete('analysis')`). Counter advancement falls out of subscription, not bespoke per-row wiring.
- Modified: `dashboard/index.html` — checklist rows declare `data-trigger-event` so the state machine wires them at boot; remove the per-row click handlers that hard-code the wrong dialog (the recent leaderboard-modal regression was this exact shape).

**Deliverable:** adding a new checklist step requires only declaring the event it subscribes to. No wiring drift.

### Team 3: State-sync subscribers + Trusted Types CI guard

**Files touched:**
- Modified: `dashboard/trade-ticket.js` — replace module-scoped `tradeTicketPortfolioHandler` ref + add/remove dance with `bus.subscribe('portfolio:updated', ...)` returning an unsubscribe function called on close. Drop `tradeTicketCashSessionId` invalidation hack (bus delivers fresh state each publish).
- Modified: `dashboard/api-utils.js` (or wherever the dashboard metric subscribers live) — same pattern.
- New: ESLint rule (or simple grep-based pre-commit hook) banning bare `.innerHTML =` outside `trustedHTML()` wrap inside `dashboard/`. Allowlist vendor files explicitly, with a `// trusted-types-vendor-allowlist` comment marker. `dashboard/vendor/lightweight-charts.standalone.production.js` keeps its IIFE patch and the marker.

**Deliverable:** Trade Ticket cash header always fresh, dashboard metrics always fresh, every new innerHTML at PR-time is either wrapped or explicitly allowlisted.

## File conflict table

| File | Touched by |
|------|-----------|
| `dashboard/app.js` | Team 1 |
| `dashboard/onboarding.js` | Team 2 |
| `dashboard/trade-ticket.js` | Team 3 |
| `dashboard/index.html` | Team 2 |

No shared files between Teams 2 and 3. Team 1 must merge first because Teams 2 and 3 import the bus.

## Critical path

Team 1 → Team 2 ∥ Team 3 (parallel after Team 1 merges)

## Validation per team

- Team 1: `bus.publish` and `bus.subscribe` unit tests. Manual: open dashboard, observe one SSE event reaches all three legacy consumers.
- Team 2: Playwright test — submit BUY 10 AAPL, assert checklist 2/4 → 3/4 within 2s of order fill notification.
- Team 3: Playwright test — open Trade Ticket, submit a fill, assert "Available Cash" header drops by the fill cost within 1s. CI lint pass with deliberate `.innerHTML =` insertion failing the new rule.

## Break-even

Status quo: ~3 broken state-sync findings per iteration × 1 hour patch each = 3 hours/iteration. With this refactor: ~0 (or contained to Team 1's bus + the contract doc). Refactor pays for itself in 2–3 iterations.

## Decision criterion for next session

The orchestrator should NOT re-litigate this. The recurrence data justifies the refactor; spending the next chat re-deciding wastes the iteration window.

Next session executes:
```
/plan-features --doc docs/bug-hunt/POST_MORTEM_2026-04-28.md --output docs/refactor/dashboard-event-bus/plan.md
/exec-plan docs/refactor/dashboard-event-bus/plan.md
```

If `/plan-features` returns a plan that materially differs in scope (more teams, larger blast radius), surface the divergence to the user before invoking `/exec-plan`. Otherwise execute.

## Reversal path

If the refactored bus produces worse bugs than the bespoke wiring (unlikely but possible), revert via the merge commit. The bus module is one file; the consumer migrations are mechanical. Rollback is 30 minutes.
