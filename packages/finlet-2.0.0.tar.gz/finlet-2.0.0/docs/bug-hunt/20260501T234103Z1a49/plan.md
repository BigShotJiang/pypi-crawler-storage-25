# Bug-Hunt 20260501T234103Z1a49 — Execution Plan

> Generated from docs/bug-hunt/20260501T234103Z1a49/triage.md. 5 real-broken findings + Team F (docs).

## Constraints

- Pre-launch; refactor cost ≈ patch cost; gate will trip on next iteration due to forward-signal recurrences.
- 3 of 5 findings are recurrences (C, D, E indirectly); fixes MUST add regression tests, not just patches.
- Dashboard wiring MUST go through `window.finletBus.publish/subscribe`. Bare `addEventListener('finlet:...')` / `window.dispatchEvent` are forbidden by `.claude/rules/file-ownership.md` + `docs/decisions/dashboard-event-bus.md`. New event names MUST be added to `dashboard/event-contract.md` in the same commit.
- Form-dirty tracking on Settings goes through `dashboard/form-dirty-tracker.js` (`registerLoader`, `snapshotFields`, `setFieldDirty`). No bare DOM-mutation of `dirtyFields`.
- Onboarding state derives from `CHECKLIST_STEPS` / `WIZARD_STEPS` registries in `dashboard/onboarding.js`. Hand-edited `state.steps.*` defaults, parallel wizard-step special cases, and bespoke per-row click handlers are forbidden.
- All datetimes in UTC; date ceiling enforcer untouched.
- One file per module; no god files.

## File Conflict Table (verified via grep, not eyeballed)

| File | Teams that touch it | Notes |
|---|---|---|
| `finlet/core/session.py` | A | `Session.fill_order()` — add `await self.portfolio.snapshot(self.clock.get_time())` after a successful fill (under `_tick_lock`). Process-pending parallel path also missing snapshot — patch both sites. |
| `finlet/core/portfolio.py` | A (read-only ref) | `_snapshot_unlocked()` already exists at line 278. Don't modify; just call the existing `snapshot()` from `fill_order()`. |
| `finlet/api/services/trade_service.py` | A | Persist-after-fill block at line 138-154 already serialises `save_session(session, db=db)` → snapshot is already covered if `fill_order()` writes to `_equity_curve`. Verify but no edit needed unless persistence cuts it out. |
| `finlet/db/persistence.py` | A | `save_session` MUST persist new equity-curve points; line 226 `session.portfolio._equity_curve.append(snap)` confirms reload path uses the field. Verify save side. |
| `dashboard/app.js` | (none from A; B/D do not touch it) | A's chart-render already buffers + replays via `equity-curve-buffer-and-replay.md`; client side doesn't need changes — A is server-only. **No multi-team conflict here.** |
| `dashboard/trade-ticket.js` | B | Existing `dialog-state-mirror` already subscribes to `portfolio:updated`. Bug: `app.js` publishes `portfolio:updated` only on session reload, not on order-fill SSE event. Fix is in `dashboard/app.js` SSE handler — see Team B scope below. |
| `dashboard/app.js` | B | SSE `order:filled` handler at line 1525 must also publish `portfolio:updated` with refreshed cash, OR `fetchSessions()` must run on `order:filled` then publish. Confirm in recon — Team B's edit is here. |
| `dashboard/onboarding.js` | D | Line 694 `markStepComplete('profile')` in `handleNext()` is the recurrence. Fix: detach 'profile' from wizard advance; subscribe to a new `profile:saved` bus event. |
| `dashboard/settings.js` | C, D | C: investigate which loader writes a synthetic-key dirty flash on cold-load (Profile tab — likely `loadAppearance` `setFieldDirty('theme', true)` race or theme localStorage reapply). D: publish `profile:saved` from `saveProfile()` after successful `apiRequest`. |
| `dashboard/event-contract.md` | C (if C adds an event), D | Any new event name MUST be documented same-commit. `profile:saved` is a new event. |
| `finlet/plugins/price_plugin.py` | E | `_probe()` at line 762 only checks LOCAL cache. Trade quotes succeed via `_query_quote` -> `_read_date_range` (S3 fetch with on-demand cache write). Health probe must reflect S3 reachability + recent successful query, not just disk state. |
| `finlet/api/routes_health.py` | E | `_check_price_data_status()` and `plugins_health` consume `health_check()` results. No changes if E fixes the plugin's `_probe()` semantics; verify behaviour. |
| `tests/core/test_session.py` (new test) | A | New regression: fill_order → equity_curve length >= 1. |
| `tests/api/test_portfolio.py` | A | Add E2E: POST /trade/order MARKET → GET /portfolio/history returns `equity_curve` with >= 1 snapshot. |
| `tests/api/test_plugin_health.py` | E | Add: when S3 read succeeds for a recent ticker, plugin health is HEALTHY. |
| `tests/dashboard/onboarding-checklist.spec.js` | D | Add: persona pick alone does NOT mark profile complete. |
| `tests/e2e/journey-06-settings.spec.ts` | C | Add: cold-load `/settings.html` → no unsaved-banner. |
| `tests/e2e/journey-05-trade.spec.ts` | B | Add: post-fill, Trade Ticket cash header equals overview cash. |

**Critical conflict**: `dashboard/app.js` is touched only by Team B (SSE handler publishes `portfolio:updated`). Team A is server-side only. Team C touches `dashboard/settings.js` only. Team D touches `dashboard/onboarding.js` and `dashboard/settings.js` (publish `profile:saved`). Team E is server-side only.

**Two-team contention on dashboard/settings.js (C + D)** → sequence C first (banner-quench), then D (publish `profile:saved` from `saveProfile()`). C's edit will likely be near `loadAppearance`/`selectTheme` (lines ~1170-1232); D's edit at `saveProfile()` (lines ~231-254). Different functions, low merge risk, but still merge sequentially.

## Dependency Graph

```
                ┌──────────┐
                │  Team A  │ engine + tests/api  (server-only)
                │ equity   │
                └────┬─────┘
                     │
                ┌────▼─────┐    ┌──────────┐
                │  Team E  │    │  Team B  │ dashboard/app.js + trade-ticket.js
                │  price   │    │  trade   │
                │  health  │    │  ticket  │
                └────┬─────┘    └────┬─────┘
                     │               │
                     │          ┌────▼─────┐
                     │          │  Team C  │ dashboard/settings.js (banner)
                     │          │  dirty   │
                     │          │  banner  │
                     │          └────┬─────┘
                     │               │
                     │          ┌────▼─────┐
                     │          │  Team D  │ dashboard/onboarding.js +
                     │          │ checklist│ dashboard/settings.js
                     │          └────┬─────┘
                     │               │
                     └───────────────┴────► Team F (docs) ─► main
```

## Critical Path

A → (C → D) → F. Length 4. Independent: A, E, B can run in parallel. C and D contend on `dashboard/settings.js`, so C must merge before D.

Total expected wall time: ~25-35 min agent work per team; sessions can overlap.

---

## Teams

### Team A — Equity-curve snapshot-on-fill (engine + tests/api)

**Blocked by**: none.
**File ownership**: engine + api (per `.claude/rules/file-ownership.md`). Single-team scope; no split needed (≤4 files).

**Read these files first**:
- `finlet/core/session.py:403-441` — `fill_order()` happy path; portfolio mutations execute under `_tick_lock` but no `portfolio.snapshot()` call after fill. This is the gap.
- `finlet/core/session.py:443-490` — `process_pending_orders()`; same gap (no post-fill snapshot).
- `finlet/core/session.py:298-299` — current snapshot site (only on tick).
- `finlet/core/portfolio.py:273-291` — `snapshot()` and `_snapshot_unlocked()`; deduplicates by timestamp, so calling once-per-fill is idempotent against the tick path.
- `finlet/api/services/trade_service.py:128-154` — auto-fill block; `save_session` already runs after fill, so DB persistence is fine if the in-memory `_equity_curve` gets the new snap.
- `finlet/db/persistence.py:226` — reload path uses `session.portfolio._equity_curve.append(snap)`; saves work via `save_session`.
- `finlet/api/routes_portfolio.py:42-59` — GET `/v1/sessions/{id}/portfolio/history` reader; no changes needed.
- `docs/decisions/equity-curve-buffer-and-replay.md` — explicit "open follow-up" reference: `Session.fill_order()` does not snapshot the portfolio after a fill. THIS plan closes it.
- `tests/core/test_portfolio.py:351-573` — pattern for portfolio-level snapshot tests.
- `tests/api/test_portfolio.py` — pattern for API-level history tests.

**Files touched** (modified):
- `finlet/core/session.py` — `fill_order()` and `process_pending_orders()` call `await self.portfolio.snapshot(sim_time)` AFTER the buy/sell execute, INSIDE `_tick_lock`. Use `self._snapshot_unlocked()`-equivalent path if needed to avoid lock-acquisition twice (portfolio has its own lock — verify whether `snapshot()` re-enters or uses internal `_snapshot_unlocked`).
- `tests/core/test_session.py` — NEW test: after `await session.fill_order(order, price)` with ACTIVE session, `len(session.portfolio.equity_curve) >= 1`.
- `tests/api/test_portfolio.py` — NEW test: full path. POST /sessions → POST /trade/order MARKET (mock price plugin) → GET /portfolio/history asserts `equity_curve` non-empty.

**Deliverable**: After a MARKET order fills (auto-fill in `trade_service.submit_order` OR explicit `session.fill_order`), `session.portfolio.equity_curve` contains at least one snapshot at `clock.get_time()`. `GET /v1/sessions/{id}/portfolio/history` returns a non-empty `equity_curve` array.

**Validation**:
- `uv run pytest tests/core/test_session.py -x -q`
- `uv run pytest tests/core/test_portfolio.py -x -q`
- `uv run pytest tests/api/test_portfolio.py -x -q`
- `uv run ruff check finlet/core/session.py tests/core tests/api`
- `uv run mypy finlet/core/session.py`

**Agent instructions**:
- You are working in a worktree. Use `isolation: "worktree"`.
- Read the files listed above BEFORE coding.
- Follow the snapshot pattern in `finlet/core/session.py:298-299`. The existing tick path calls `await self.portfolio.snapshot(self.clock.get_time())` — replicate inside `fill_order()` and `process_pending_orders()` AFTER the portfolio mutation.
- Verify the snapshot call does NOT deadlock. `Session._tick_lock` is the outer lock; `Portfolio._lock` is acquired inside `snapshot()`. They are separate locks, so re-entry is safe — but confirm by reading `portfolio.snapshot()` (line 273) and `_tick_lock` semantics in session.py.
- Add ONE regression test per change site. Test names should match the schema: `test_fill_order_snapshots_equity_curve`, `test_process_pending_orders_snapshots_each_fill`, `test_portfolio_history_endpoint_returns_snapshot_after_market_fill`.
- Do NOT touch `dashboard/app.js` — the buffer-and-replay client fix (commit `3379fdf`) already handles client-side; this team is the durable server-side half.
- You MUST `git add` + `git commit` before finishing. Commit subject: `fix(engine): snapshot equity curve on fill_order + process_pending_orders`.

**Retest envelope** (Phase 5.5): `triage.json items[1].retest` (curl-based). Asserts `equity_curve` length ≥ 1 after MARKET BUY.

---

### Team B — Trade Ticket Available Cash refresh on fill (dashboard)

**Blocked by**: none.

**Read these files first**:
- `dashboard/trade-ticket.js:130-207` — existing `dialog-state-mirror` integration; subscribes to `portfolio:updated`, primes from `currentSession.portfolio_metrics.cash`, refetches via `fetchCashBalance()` on open. The mechanism is correct.
- `dashboard/trade-ticket.js:247-298` — `fetchCashBalance()` writes the DOM via dashFetch.
- `dashboard/app.js:1472-1474` — `portfolio:updated` is published when fresh portfolio data is loaded (e.g., during `fetchSessions()` poll). Confirm.
- `dashboard/app.js:1498-1525` — SSE `order:filled` handler. **Bug location**: when a fill SSE event arrives, `order:filled` is published but `portfolio:updated` is NOT republished from the fill payload. Trade Ticket subscriber thus does not see fresh cash.
- `dashboard/event-contract.md:46-75` — last-published cache; `portfolio:updated` semantics.
- `dashboard/dialog-state-mirror.js` — onUpdate / refuseClobber contract.
- `docs/decisions/dialog-state-mirror-prime-ordering.md`.
- `tests/e2e/journey-05-trade.spec.ts` — pattern for trade-ticket E2E.

**Files touched** (modified):
- `dashboard/app.js` — In the SSE `order:filled` handler (line 1525-ish), after publishing `order:filled`, also (a) refetch portfolio via the existing fetch path AND publish `portfolio:updated` with the fresh payload, OR (b) publish `portfolio:updated` directly using the cash delta from the fill. Prefer (a) so we always reflect the canonical /portfolio truth (no client-side cash math).
- `tests/e2e/journey-05-trade.spec.ts` — extend or NEW assertion in the existing trade-fill spec: after MARKET BUY fills, `#tt-cash-balance` text < pre-trade value AND equals the Overview `Cash` tile within $0.01.

**Deliverable**: When a MARKET BUY fills, the still-open Trade Ticket's `#tt-cash-balance` updates within ~1s to match the Overview cash tile.

**Validation**:
- `npx playwright test tests/e2e/journey-05-trade.spec.ts --project=chromium`
- Manual smoke (post-deploy): open Trade Ticket, BUY 1 SPY MARKET, observe header updates without re-open.

**Agent instructions**:
- You are working in a worktree. Use `isolation: "worktree"`.
- Read the files listed above BEFORE coding.
- Follow the bus contract — publish via `window.finletBus.publish('portfolio:updated', payload)`. Bare `window.dispatchEvent` is forbidden.
- Do NOT touch `dashboard/trade-ticket.js`. The mirror is already wired correctly; the bug is the missing publish on the SSE side.
- Update `dashboard/event-contract.md` ONLY if you change the `portfolio:updated` payload shape. If the existing shape (cash, positions_value, total_value) is preserved, the contract doc is unchanged.
- You MUST `git add` + `git commit` before finishing. Commit subject: `fix(dashboard): republish portfolio:updated on order:filled SSE so trade ticket cash refreshes`.

**Retest envelope** (Phase 5.5): `triage.json items[2].retest` (playwright). Asserts post-fill TT cash equals Overview cash.

---

### Team C — Settings dirty banner cold-load false-positive (dashboard)

**Blocked by**: none.

**Read these files first**:
- `dashboard/settings.js:75-100` — `initFormTracker` call site; loader registry sequencing.
- `dashboard/settings.js:170-260` — `initProfile` + `loadProfile` + `snapshotFields(['profile-name', 'profile-email', 'profile-bio', 'profile-timezone'])` at line 228.
- `dashboard/settings.js:1150-1232` — `initAppearance` + `selectTheme(theme, silent)` + `loadAppearance`. **Suspect site**: `selectTheme(theme)` at line 1172 calls `setFieldDirty('theme', true)` at line 1185 unless `silent === true`. If `selectTheme` is called during init from `localStorage.getItem('finlet_theme')` re-application path, it sets a synthetic dirty flag before the gate clears.
- `dashboard/settings.js:1164-1170` — load saved theme path. The current call at 1167 may not pass `silent=true`; verify.
- `dashboard/form-dirty-tracker.js:249-310` — gate logic. Pre-clear at line 297 (`dirtyFields.clear()`) is meant to swallow synthetic-key flashes; if a `setFieldDirty('theme', true)` fires AFTER the gate clears, the banner re-shows.
- `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` — prior refactor verdict (`shipped`, `verdict_v2: effective` for cold-load on Plugins tab). The verdict stamp is from 2026-04-29; this iteration's recurrence on the **Profile tab** indicates the refactor missed a non-Plugins synthetic-key path.
- `docs/decisions/dashboard-form-dirty-tracker-registry.md`.
- `tests/e2e/journey-06-settings.spec.ts`.

**Files touched** (modified):
- `dashboard/settings.js` — Diagnose: which loader/init path sets a dirty flag during cold-load on the Profile tab? Likely candidates: (a) `selectTheme` invoked from `loadAppearance` or theme-init without `silent=true`, OR (b) a `setFieldDirty` call inside an `initX()` runs after the gate's pre-clear but before the gate releases `_loaderUpdating=false`. Fix: ensure all init-time `setFieldDirty` calls are gated by `_loaderUpdating` (which `setFieldDirty` should respect — confirm in `form-dirty-tracker.js`), OR pass `silent=true` to all init-time `selectTheme` paths.
- `tests/e2e/journey-06-settings.spec.ts` — NEW assertion: cold-load `/settings.html` (no interaction) → `[data-testid=unsaved-banner]` is hidden / has `aria-hidden=true` / not in accessibility tree. Reload-idempotent (assert twice across cold loads).

**Deliverable**: Cold-loading `/settings.html` shows NO unsaved-banner with no user interaction. Idempotent across page reloads.

**Validation**:
- `npx playwright test tests/e2e/journey-06-settings.spec.ts --project=chromium`
- Manual: open `/settings.html`, observe no banner. Reload, repeat.

**Agent instructions**:
- You are working in a worktree. Use `isolation: "worktree"`.
- Read `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` FIRST — the prior refactor's verdict is "shipped, v2 effective" but this is a recurrence on the Profile tab. The fix is incremental, not a rewrite.
- Likely root cause: `selectTheme()` synthetic-key dirty path in `loadAppearance`. Verify by adding a `console.log('synthetic-dirty:', id, value)` inside `setFieldDirty` and reproducing locally before patching.
- Do NOT mutate `dirtyFields` directly — use `setFieldDirty(id, false)` only.
- Do NOT touch `dashboard/onboarding.js` — that's Team D.
- You MUST `git add` + `git commit` before finishing. Commit subject: `fix(dashboard): suppress synthetic-key dirty flash on settings cold-load`.

**Retest envelope** (Phase 5.5): `triage.json items[6].retest` (playwright). Asserts no unsaved-banner on cold-load /settings.html.

---

### Team D — Onboarding 'Set up profile' check on real save, not persona pick (dashboard)

**Blocked by**: Team C (both teams touch `dashboard/settings.js`).

**Read these files first**:
- `dashboard/onboarding.js:30-55` — `CHECKLIST_STEPS` registry. `profile` entry: `trigger: null` (manual), `action: { type: 'noop' }` — wizard owns the trigger. **This is the bug**: profile is mark-on-wizard-advance, not mark-on-real-event.
- `dashboard/onboarding.js:686-711` — `handleNext()`. Line 694: `markStepComplete('profile')` fires immediately on Step 1 advance (after persona pick). This is the recurrence: documented affordance fires on the wrong trigger.
- `dashboard/onboarding.js:194` — wizard Step 1 entry: `advanceTrigger: null` (advances on Continue button click).
- `dashboard/onboarding.js:992-1051` — `markStepComplete()` and bus publish path.
- `docs/bug-hunt/refactor-queue/onboarding-checklist.md` — prior refactor verdict (`shipped` 2026-04-30 but `verdict: incomplete`); the refactor introduced `CHECKLIST_STEPS` but left `profile.trigger: null` because the only persistent profile state is from `PUT /v1/settings/profile` and there was no bus event for it.
- `dashboard/settings.js:231-254` — `saveProfile()`. Saves to `/settings/profile` then `snapshotFields(...)`. **No bus publish** here today. Add `window.finletBus.publish('profile:saved', { display_name, bio })` AFTER the success branch.
- `dashboard/event-contract.md` — add new `profile:saved` event docs.
- `dashboard/app.js:792-796` — pattern for publishing on the bus with try/catch.
- `tests/dashboard/onboarding-checklist.spec.js` — pattern.
- `tests/e2e/journey-onboarding.spec.ts` — pattern.

**Files touched** (modified):
- `dashboard/onboarding.js` — In `CHECKLIST_STEPS[0]`, change `trigger: null` to `trigger: 'profile:saved'`. In `handleNext()` for `currentStep === 1`, REMOVE the `markStepComplete('profile')` call — the bus subscriber owns the transition now. Step 1 still advances to Step 2 via `showStep(2)`. Verify the existing trigger-subscriber loop (around lines 380-420) attaches the new bus subscriber automatically from the registry; if not, add the subscriber wiring.
- `dashboard/settings.js` — In `saveProfile()` (line 231), AFTER the successful `apiRequest` + toast, publish `window.finletBus.publish('profile:saved', { display_name: body.display_name, bio: body.bio })` only when both `display_name` AND `bio` are non-empty (to match the assertion in `triage.json items[5].retest.assertions[1]`).
- `dashboard/event-contract.md` — Add a new `profile:saved` section: name, payload shape `{ display_name: string, bio: string }`, publisher (`dashboard/settings.js#saveProfile`), subscribers (onboarding registry).
- `tests/dashboard/onboarding-checklist.spec.js` — NEW test: persona pick alone does NOT mark profile complete; profile completes only after a `profile:saved` publish or a real `PUT /v1/settings/profile` with non-empty fields.

**Deliverable**: Selecting "Retail Investor" in the wizard does NOT check off "Set up profile". The checklist row only flips to complete after the user saves a non-empty Display Name + Bio in Settings > Profile.

**Validation**:
- `npx playwright test tests/dashboard/onboarding-checklist.spec.js --project=chromium`
- `npx playwright test tests/e2e/journey-onboarding.spec.ts --project=chromium`
- Manual: fresh user, open onboarding, pick Retail Investor, advance Step 1 → checklist still shows "Set up profile" UNCHECKED. Then go to Settings > Profile, fill Display Name + Bio, Save → checklist flips to checked.

**Agent instructions**:
- You are working in a worktree. Use `isolation: "worktree"`.
- This is a recurrence (`same_root_cause_as: checklist-rest-cli-no-advance`). Read `docs/bug-hunt/refactor-queue/onboarding-checklist.md` to understand why the prior refactor was verdict-incomplete — the registry was added but the `profile` step's trigger was left `null` because no bus event existed. THIS fix introduces that event.
- Follow the registry-advanceTrigger pattern: do NOT add a hand-wired bus subscriber. The CHECKLIST_STEPS entry's `trigger` field should be enough if the existing subscriber-loop is registry-driven. Verify in `onboarding.js` lines 380-420.
- Update `dashboard/event-contract.md` in the SAME commit (per rules). Mention the `profile:saved` event in the commit body.
- Do NOT touch fields outside Profile (display_name + bio). The assertion in triage requires BOTH non-empty before the step flips.
- You MUST `git add` + `git commit` before finishing. Commit subject: `fix(dashboard): mark profile checklist on profile:saved bus event, not persona pick`.

**Retest envelope** (Phase 5.5): `triage.json items[5].retest` (playwright). Asserts persona-only flow does NOT mark profile complete.

---

### Team E — Plugin Health 'price' status reflects real data path (api + plugins)

**Blocked by**: none.

**Read these files first**:
- `finlet/plugins/price_plugin.py:762-779` — `_probe()`. **Bug**: only checks `self._cache_dir.glob("*.parquet")`. If no quote has been requested yet, the cache dir is empty even though S3 is reachable. After a successful `_query_quote`, the cache dir does have files — but cold-start health is wrong.
- `finlet/plugins/price_plugin.py:297-362` — `_query_quote` happy path; reads from `_read_date_range` which fetches from S3 and writes the local cache as a side effect.
- `finlet/plugins/price_plugin.py:405-460` — `_read_date_range` and `_get_or_download` (verify lines); confirms S3 is the canonical source and disk cache is a write-through.
- `finlet/api/routes_health.py:24-55` — `_check_price_data_status()` consumes `health_check()`. Logic translates DEGRADED + "no cached" → `no_data`. If the plugin's probe semantics change to "S3 reachable", this top-level translator must continue to work.
- `finlet/api/routes_health.py:84-114` — `plugins_health` endpoint.
- `finlet/api/state.py` — registry singleton; `_all_plugins`.
- `tests/api/test_plugin_health.py` — pattern.
- `docs/ARCHITECTURE.md` plugin section (search for "PricePlugin" / "price_plugin").

**Files touched** (modified):
- `finlet/plugins/price_plugin.py` — Rewrite `_probe()`: if `_cache_dir` exists, check S3 reachability instead (e.g., a HEAD on the prefix or a recent date file). If S3 reachable AND (cache files exist OR S3 prefix non-empty) → HEALTHY. If S3 unreachable → DEGRADED with "S3 unreachable" message. Drop "Run ingestion first" copy unless cache dir is empty AND S3 has zero parquet files in the recent window. **Acceptance**: while a successful `_query_quote` for SPY just returned a fill price, `health_check()` MUST return HEALTHY (not DEGRADED with "No cached price data files found").
- `finlet/api/routes_health.py` — verify `_check_price_data_status` translator still returns "available" for the new HEALTHY path; adjust if the message wording changed.
- `tests/api/test_plugin_health.py` — NEW tests: (1) cold start with S3 mock returning recent parquet → HEALTHY; (2) S3 mock unreachable → DEGRADED with S3 message (NOT "Run ingestion first"); (3) regression: when a quote succeeds, immediately polling /v1/plugins/health returns price=Healthy.

**Deliverable**: Either (a) Plugin Health reports `price` as Healthy when S3 is reachable and a quote can be served, OR (b) MARKET BUY fails when health is Degraded — the two contracts MUST not disagree. We pick (a) because S3 IS the data path; the disk cache is performance-optional.

**Validation**:
- `uv run pytest tests/api/test_plugin_health.py -x -q`
- `uv run pytest tests/plugins -k price -x -q`
- `uv run ruff check finlet/plugins/price_plugin.py finlet/api/routes_health.py`
- `uv run mypy finlet/plugins/price_plugin.py`

**Agent instructions**:
- You are working in a worktree. Use `isolation: "worktree"`.
- Read `docs/decisions/equity-curve-buffer-and-replay.md` (briefly) and `docs/lessons.md` for the "S3 not equals queryable" pattern from the backfill post-mortem (`feedback_s3_not_equals_queryable.md` in user memory).
- The fix MUST NOT add a new dependency or new HTTP call on every page-load — `health_check()` is called frequently. Use a short-lived cached probe (e.g., last successful S3 reach within 60s = HEALTHY).
- Use `httpx` for any new HTTP. Use `boto3` consistent with the existing plugin's S3 access pattern.
- Update `docs/ARCHITECTURE.md` plugin section IF the probe semantics change is non-trivial. (Team F will then carry it over to the iteration's docs commit.)
- You MUST `git add` + `git commit` before finishing. Commit subject: `fix(plugins): price health probe reflects S3 reachability, not just disk cache`.

**Retest envelope** (Phase 5.5): `triage.json items[9].retest` (curl). Asserts `(price plugin Healthy) OR (MARKET BUY fails)` — must not both succeed-and-disagree.

---

### Team F — Docs (per Required Docs Updates block)

**Blocked by**: A, B, C, D, E (must merge first; F references their merge SHAs in the ledger).

**Read these files first**:
- `docs/bug-hunt/20260501T234103Z1a49/triage.md` — Required Docs Updates block (lines 22-63).
- `docs/bug-hunt/ledger.jsonl` — pattern for the JSONL append. Each closed real-broken finding gets exactly one line. Schema specified in triage.md.
- `docs/REMAINING_TASKS.md` — pattern for "Bug Hunt iteration_ts — Closed" subsection from prior iterations.
- `docs/LESSONS.md` — pattern; one lesson per real-broken finding that exposed a class of mistake.
- `docs/ARCHITECTURE.md` — verify which sections changed (price plugin probe semantics; new `profile:saved` bus event).
- `docs/KNOWN_FAILURES.md` — pre-flight refresh.
- `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` and `onboarding-checklist.md` — update verdict if THIS iteration shows the prior refactor verdict was premature (likely yes for both — write a new verdict block).
- `docs/bug-hunt/pending_recurrences.jsonl` and (if applicable) `pending_recurrences.resolved.jsonl` — Phase 5.5 may write to these.

**Files touched** (modified):
- `docs/REMAINING_TASKS.md` — add "Bug Hunt 20260501T234103Z1a49 — Closed" subsection listing the 5 closed items with their categories and merge SHAs.
- `docs/LESSONS.md` — append at least 1 lesson per real-broken finding. Suggested lessons:
  - "Server-side state-mutation events MUST snapshot derivative time-series at the same critical section. (Team A)" — generalize from fill_order missing snapshot.
  - "Dialog-state mirror requires the producer to publish on every state transition, not only on poll-driven refresh. (Team B)"
  - "Synthetic-key dirty signals (theme, frequency) must respect the loader-update guard, not just DOM-bound fields. (Team C)"
  - "Wizard-step advance ≠ outcome event. Wire checklist completion to the action that mutates the persisted state, not the navigation event. (Team D)"
  - "Plugin health probes must reflect the actual data path, not the convenience cache. (Team E)"
- `docs/ARCHITECTURE.md` — update plugin section IF Team E changed probe semantics; update dashboard section IF Team D added the `profile:saved` bus event. Otherwise note "ARCHITECTURE unchanged this iteration".
- `docs/KNOWN_FAILURES.md` — refresh.
- `docs/decisions/` — add 1-page records ONLY for non-trivial reversible decisions. Likely candidates: (a) Team E's "health probe = S3 reachability, not disk cache" decision; (b) Team A's "snapshot-on-fill" decision IF it deviates from `equity-curve-buffer-and-replay.md`.
- `docs/bug-hunt/20260501T234103Z1a49/` — stage and commit ALL artifacts: `plan.md` (this file), `triage.md`, `triage.json`, `blind_report.json`, `blind_report_wrapper.json`, `cleanup.log`, `team_*_verify.md`, `deploy_status.txt`, `retest_results.json`. Confirm via `git status docs/bug-hunt/20260501T234103Z1a49/` after staging.
- `docs/bug-hunt/ledger.jsonl` — APPEND exactly 5 JSON lines (one per closed real-broken finding). Schema (from triage.md):
  ```json
  {"iteration_ts":"20260501T234103Z1a49","finding_id":"<short-slug>","category":"<tag>","summary":"<short>","scope_files":["..."],"team":"<A|B|C|D|E>","commit":"<merge-sha-on-main>"}
  ```
  Categories to reuse: `dashboard-state-sync` (A, B, E), `dirty-state-tracker` (C), `onboarding-checklist` (D). `wc -l docs/bug-hunt/ledger.jsonl` MUST grow by exactly 5 after this append.
- `docs/bug-hunt/pending_recurrences.jsonl` — stage only.
- `docs/bug-hunt/pending_recurrences.resolved.jsonl` — stage only IF a refactor verdict pruned entries this iteration.

**Deliverable**: Single docs commit referencing iteration `20260501T234103Z1a49` and naming which docs were touched.

**Validation**:
- `git status` — no untracked files under `docs/bug-hunt/20260501T234103Z1a49/`.
- `wc -l docs/bug-hunt/ledger.jsonl` — grew by exactly 5.
- `python -c "import json; [json.loads(l) for l in open('docs/bug-hunt/ledger.jsonl')]"` — all lines valid JSON.

**Agent instructions**:
- You are working in a worktree. Use `isolation: "worktree"`.
- Run AFTER all 5 merges land on main. Read `git log --oneline -20` to grab merge SHAs for the ledger.
- Use HEREDOC for the commit message (multi-line). Subject MUST reference the iteration: `docs: bug-hunt 20260501T234103Z1a49 — record fixes for A/B/C/D/E; LESSONS +5; ARCHITECTURE updated for price-health + profile:saved; ledger +5`.
- You MUST `git add` + `git commit` before finishing.

**Retest envelope** (Phase 5.5): N/A — docs-only. Phase 5.5 retests run against A/B/C/D/E.

---

## Risk Register

| # | Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| R1 | Team A's `portfolio.snapshot()` call inside `fill_order` deadlocks against `_tick_lock` × `Portfolio._lock` | Low | High | Verify lock order before merging; existing tick path at session.py:298-299 already uses `await self.portfolio.snapshot(...)` outside `_tick_lock` (it's just under the lock context). Replicate that exact pattern. |
| R2 | Team C's fix only patches Profile-tab synthetic-key path; another tab regresses next iteration | Medium | Med | Add a journey-06 reload-loop test (cold-load × 2 reloads, no banner). Document in LESSONS that synthetic keys always need `silent=true` at init. The refactor-queue doc gets a v2 verdict update from Team F. |
| R3 | Team D's `profile:saved` event fires before BOTH display_name AND bio are non-empty (eager publish) | Medium | Low | Gate the publish in `saveProfile()` on `body.display_name && body.bio`. Add a unit test in `tests/dashboard/onboarding-checklist.spec.js` for the empty-bio case. |
| R4 | Team E's "S3 reachability" probe adds latency to every health-poll | Medium | Med | Cache the last-successful probe for 60s; only re-probe S3 on miss. Document in the new decision record. |
| R5 | Team E's fix is a server-side reporting bug, not a CLI/code-path bug | High | Med | This is by design — the data path works, the report is wrong. The fix is in `_probe()` semantics. This is NOT a "fix the trade path" task. |
| R6 | C and D both edit `dashboard/settings.js` and merge conflict | Medium | Low | Sequential merge (Session 2): C first, then D. Different functions (`loadAppearance`/`selectTheme` vs `saveProfile`); near-zero textual overlap. |
| R7 | Team B's `portfolio:updated` republish adds a second SSE-driven cash refetch on every fill (perf) | Low | Low | The existing fetchSessions poll already does this every 2s. One extra fetch per fill is negligible. |
| R8 | Recurrence: prior refactor verdicts (`dirty-state-tracker.md`, `onboarding-checklist.md`) were premature | High (already evident this iteration) | Med | Team F MUST update both refactor-queue verdicts with a 2026-05-01 stamp and `verdict_v3: incomplete` evidence block. |
| R9 | Phase 5.5 retest for E fails because S3 reachability check is mocked in tests but unmocked in prod | Low | Med | Run `tests/plugins/test_price_plugin.py` against a test S3 fixture. Smoke against prod after deploy. |

## Session Plan

### Session 1 — Parallel work, sequential merge (A, B, E)

Run A, B, E in parallel worktrees. Independent file scopes:
- A: `finlet/core/session.py`, `tests/core/`, `tests/api/test_portfolio.py`
- B: `dashboard/app.js`, `tests/e2e/journey-05-trade.spec.ts`
- E: `finlet/plugins/price_plugin.py`, `tests/api/test_plugin_health.py`

Merge order (any sequence — no shared files):
1. A merges → main
2. E merges → main
3. B merges → main

Each merge runs CI: `ruff` → `mypy` → `pytest` → `playwright`. Block on red.

### Session 2 — Dashboard contention (C, D)

C and D both touch `dashboard/settings.js`. Sequential merge:
1. C merges first (Profile-tab dirty-banner cold-load fix). Different function from D, but settings.js is a single file → conservative ordering.
2. D merges after C. D adds `bus.publish('profile:saved')` in `saveProfile`; touches `onboarding.js` + `settings.js` + `event-contract.md`.

Both teams can WORK in parallel; only the merge is sequential.

### Session 3 — Docs (F)

After all 5 merges land on main:
1. Read `git log --oneline -10` to grab the 5 merge SHAs.
2. Append 5 lines to `docs/bug-hunt/ledger.jsonl`.
3. Update `docs/REMAINING_TASKS.md`, `docs/LESSONS.md`, `docs/ARCHITECTURE.md`, `docs/KNOWN_FAILURES.md`.
4. Update refactor-queue verdicts (`dirty-state-tracker.md`, `onboarding-checklist.md`) with `verdict_v3: incomplete` evidence.
5. Stage all `docs/bug-hunt/20260501T234103Z1a49/` artifacts.
6. Commit and merge.
