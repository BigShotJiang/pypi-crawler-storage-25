## Broken (will be fixed this iteration)

- Trade Ticket "Available Cash" shows stale pre-trade value after a market order fills — UI state ≠ backend state. [evidence: "After submitting BUY 1 SPY MARKET (filled $548.80), the Trade Ticket dialog still displayed 'Available Cash: $100,000.00'. The Overview panel correctly updated to 'Cash: $99,451.20'. The dialog fetches cash once on open and never refreshes, so any trade placed without closing and reopening the ticket will show an incorrect available balance."] [scope hint: dashboard/trade-ticket.js, dashboard/app.js]
- Plugin Health 'price' status reports "Degraded — No cached price data files found. Run ingestion first." while market orders simultaneously fill at real prices — health panel state contradicts the system's actual data-availability state. [evidence: "Plugin Health: 'price — Degraded — No cached price data files found. Run ingestion first.' Yet BUY 1 SPY MARKET filled at $548.80 with no error. No explanation of where the fill price came from. A user who trusts the Plugin Health display would expect orders to fail or use stale data, but they silently succeed. If an alternate price source is being used, Plugin Health should reflect it."] [scope hint: finlet/api/services/market_service.py, finlet/api/routes_health.py, finlet/plugins/price.py]
- Settings page fires "You have unsaved changes" banner on cold-load before any user interaction — UI dirty state ≠ backend reality. [evidence: "Immediately after navigating to settings.html (Profile tab), the snapshot shows: generic 'You have unsaved changes' with 'Discard' and 'Save Changes' buttons. No field was touched. Likely a JS initialization writing a default value to a watched field and triggering the dirty-check."] [scope hint: dashboard/settings.js, dashboard/form-dirty-tracker.js]
- "Set up profile" checklist row checks itself complete after the user only selects an onboarding persona — checklist state ≠ profile state (Display Name and Bio remain empty). Documented affordance fires its done-state on the wrong trigger. [evidence: "Getting Started checklist shows 'Set up profile' with green checkmark (1/4 complete incremented to show it done) immediately after selecting 'Retail Investor' in the wizard. Settings > Profile still shows empty Display Name and Bio fields."] [scope hint: dashboard/onboarding.js, dashboard/app.js]
- Equity Curve chart remains empty after a market order fills (no plotted points, only TradingView watermark) — server-side snapshot-on-fill gap leaves an empty equity series despite a recorded FILLED trade. [evidence: "After BUY 1 SPY filled at $548.80 (confirmed in Order Log and Positions table), the Equity Curve chart section shows only the TradingView watermark with no plotted points."] [scope hint: finlet/core/portfolio.py, finlet/core/orders.py, finlet/api/services/trade_service.py, dashboard/app.js]

## Logged (not actioned)

- Finlet benchmark MCP tool not callable in evaluation context — the blind agent's harness was not connected to finlet's MCP server. [classification: working-as-designed]
- 3 of 8 plugins permanently in 'Error' state because they require user-supplied API keys (finnhub, fred, edgar). Settings > Plugins exposes the API key input — first-impression UX is rough but the state is correct. [classification: annoying]
- No 'fundamentals strategy' install/configure flow — the task brief asked for a concept (strategy installer) the dashboard does not implement. Strategies are agent-authored, not dashboard-installable. [classification: nice-to-have]
- Onboarding wizard 'Continue' button is disabled with no tooltip explaining the persona-selection prerequisite. [classification: annoying]
- Two identically-labelled 'Open Session Creator' buttons in the onboarding wizard cause Playwright strict-mode collisions and screen-reader ambiguity. [classification: annoying]
- Plugin Health 'Degraded — Run ingestion first' messages on price/news_s3/sentiment expose a CLI-only concept in the UI with no in-app action. [classification: annoying]
- Session dropdown crams name + status + date into one option string when status is already shown as a separate badge. [classification: annoying]
- No strategy library or fundamentals strategy template; users must build from scratch using the documented MCP tools. [classification: nice-to-have]
- Plugin API key input rows have no link to where to obtain the required key. [classification: nice-to-have]
- Trade ticket form has no 'Reasoning' textarea so manual orders show '--' in the Reasoning column of the Order Log. [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260501T234103Z1a49 — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made.
6. `docs/bug-hunt/20260501T234103Z1a49/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json,
   blind_report_wrapper.json, cleanup.log, team_*_verify.md, deploy_status.txt,
   retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260501T234103Z1a49","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline.
   Team D MUST stage the file. If a refactor verdict pruned entries
   this iteration, Team D MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`.

Team D's commit message must reference iteration 20260501T234103Z1a49 and name which docs were
touched (e.g., "docs: bug-hunt 20260501T234103Z1a49 — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
