# Team A — Finding 2 (EDGAR plugin hot-reload + actionable CLI message) — verify

**Bug-hunt iteration:** 20260501T172055Z127b
**Team:** A
**Branch:** worktree-agent-a100c4871ca9ae7d4
**Worktree root:** `.claude/worktrees/agent-a100c4871ca9ae7d4`

## Bug recap

Running `finlet plugins add edgar --email x@y.com` printed:

> Plugin 'edgar' configured. Restart server to apply.

But the server never picked the new config up — even after a restart in some
deployments — and the CLI never confirmed whether the plugin was actually
healthy. Result: the user (or agent) thinks the plugin is configured, but
`/v1/plugins/health` keeps reporting `unhealthy`.

The fix has two halves:

1. **Hot-reload on the server side**, so a fresh `plugins add` takes effect
   without a restart.
2. **Live status surfacing on the CLI side**, so the user sees the real
   post-reload health record (`healthy`, `degraded`, or `unhealthy` with the
   reason) instead of a hardcoded "Restart server to apply" string.

## Files changed

- `finlet/plugins/base.py` — added `PluginRegistry.reload(name, config)` (re-runs
  `initialize()` on the existing plugin instance, resets per-plugin circuit
  breakers, serialises concurrent reloads via a new `_reload_lock`).
- `finlet/api/routes_health.py` — added `POST /v1/plugins/{name}/reload`.
  Re-reads `~/.finlet/plugins.json`, calls `registry.reload(name, plugin_cfg)`,
  then runs a single health check and returns the post-reload
  `PluginHealthItem`. Returns `404` for unknown plugin names; reload-failure
  is reported as `200 + status="unhealthy"` (more actionable than `500`).
- `finlet/cli.py` — `plugins_add` no longer prints "Restart server to apply".
  Instead it: (a) writes the config to `~/.finlet/plugins.json`, (b) `POST`s
  `/v1/plugins/{name}/reload`, (c) prints the live status from the response.
  Connection error -> warns the config is saved but server isn't running.
  404 -> typo-actionable error. Other HTTP errors -> standard error envelope.
- `tests/test_cli.py` — new `TestPluginsAddCommand` class with 4 tests:
    - drops "Restart server" wording AND surfaces live status (regression for
      Finding 2),
    - surfaces unhealthy status when the server reports it,
    - server-unreachable case still writes the config + prints a clear note,
    - 404 case (plugin name typo) prints typo-actionable error.
- `tests/api/test_plugin_health.py` — new `TestPluginReload` class with 3 tests
  exercising the new endpoint:
    - 404 for unknown plugin,
    - end-to-end (write config -> POST reload -> GET health reflects new state),
    - bad config returns `200 + status=unhealthy`, not `500`.

## Validation evidence

### 1. CLI plugins_add tests (new)

```
$ .venv/bin/pytest tests/test_cli.py -k plugins_add -x -q
....                                                                     [100%]
4 passed, 41 deselected in 0.32s
```

All 4 new tests in `TestPluginsAddCommand` pass.

### 2. Plugin / registry tests (existing + new)

```
$ .venv/bin/pytest tests/api/ tests/plugins/ -k "plugin or registry" -x -q
........................................................................ [  9%]
... (snip) ...
....................................                                     [100%]
756 passed, 1164 deselected, 1 warning in 36.79s
```

All 756 plugin/registry-keyworded tests pass — including the 3 new reload
tests in `TestPluginReload` and every existing plugin-health, registry,
circuit-breaker, init-handshake, and resilience test.

### 3. Combined plugin_health.py + test_cli.py spot check

```
$ .venv/bin/pytest tests/api/test_plugin_health.py tests/test_cli.py -q
.............................................................            [100%]
61 passed, 1 warning in 3.22s
```

61 / 61 pass (45 CLI tests + 16 plugin-health tests with the 3 new reload
tests included).

### 4. Ruff lint

```
$ .venv/bin/ruff check finlet/cli.py finlet/api/ finlet/plugins/base.py
All checks passed!

$ .venv/bin/ruff check tests/test_cli.py tests/api/test_plugin_health.py
All checks passed!
```

Clean on every file changed (source + tests).

### 5. Mypy type check

```
$ .venv/bin/mypy finlet/api/ finlet/plugins/base.py
pyproject.toml: note: unused section(s): module = ['mcp.*', 'uvicorn.*']
Success: no issues found in 83 source files
```

Clean. Took ~30s — well under the 2 min cap.

### 6. Manual sanity (skipped)

Did not run a live `finlet plugins add edgar --email x@y.com` against
`finlet.dev` — the validation evidence above (3 reload-endpoint integration
tests in `tests/api/test_plugin_health.py::TestPluginReload` plus 4 CLI tests
in `tests/test_cli.py::TestPluginsAddCommand`) covers the end-to-end
contract: the CLI no longer prints "Restart server", the CLI surfaces the
live `/v1/plugins/health` status, and the server's `GET /v1/plugins/health`
reflects the reload result without a restart.

## Concurrency safety

- `PluginRegistry._reload_lock` (an `asyncio.Lock`) serialises concurrent
  `reload()` calls.
- Concurrent readers (`health_check_all`, `query_plugin*`, dashboard's 2 s
  poll) intentionally do NOT take the lock. They read the same
  `_all_plugins[name]` dict slot whether a reload is in flight or not — and
  because `reload()` mutates the existing plugin instance in place via
  `initialize()`, callers will see either the pre-reload or post-reload
  state, never a half-built object. The same pattern is already used at
  startup (`initialize_all`), where the `is_ready` gate exists for global
  startup readiness; per-plugin reloads do not need that gate because the
  plugin is already registered.
- Per-plugin circuit breakers are reset on reload so old failures from the
  pre-reload config don't keep the breaker open.

## Bug-hunt rules compliance

- KNOWN_FAILURES.md was read at the start; nothing in this change re-enters
  any listed entry.
- All edits are within `worktree-agent-a100c4871ca9ae7d4/`.
- `plugins list` was NOT modified (Finding 4 is out of scope).
- Portfolio command was NOT modified (Finding 1 is out of scope).
- The fix works without requiring users to restart the server (the entire
  point of the bug, verified by `test_reload_writes_then_reads_new_config_without_restart`).
- Concurrent-read safety: `_reload_lock` added; no race against the
  dashboard's 2 s polling.
