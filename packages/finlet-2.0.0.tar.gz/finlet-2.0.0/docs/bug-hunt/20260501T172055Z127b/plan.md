# Bug-Hunt 20260501T172055Z127b — Execution Plan

> Generated from `docs/bug-hunt/20260501T172055Z127b/triage.md`. Last updated: 2026-05-01

## Constraints

- All work runs on isolated worktrees and merges sequentially through the `/exec-plan` gate.
- Team prompts MUST include the worktree-rules block (memory: `feedback_worktree_prompts.md`) so files don't leak to the main tree.
- Docs commit (Team C) and ledger commit (Team D) must reference iteration ts `20260501T172055Z127b`.
- **Pre-flight finding (recon discovery):** Findings 1 and 4 in the triage are pypi-release-lag artifacts, NOT live code bugs. The blind agent's `finlet` CLI lives at `/opt/homebrew/lib/python3.14/site-packages/finlet/cli.py`, which is from an older pypi release. The fixes for both are already in main:
  - Finding 1 (`portfolio` AttributeError): fixed by commit `cc6cddf` ("[Team C]: fix portfolio CLI crash when iterating dict-format positions"). Working tree `finlet/cli.py:552` uses `for pos in positions.values():`. Installed `cli.py:378` uses `for pos in positions:`.
  - Finding 4 (CLI `plugins list` mismatch): fixed by commit `1a3c17e` ("[Team B]: CLI session-create timeout + plugins list parity with dashboard"). Working tree `finlet/cli.py:229-273` calls `GET /v1/plugins/health`. Installed CLI returns a hardcoded list.
  - Tests for both pass on main: `uv run pytest tests/test_cli.py -k "portfolio or plugins_list"` → 9/9 pass.
  - Therefore Teams A/B do NOT cover Findings 1 or 4 — there is no code to change. They are recorded in the ledger and called out in lessons (`pypi-release-lag` is a real UX problem; the fix is a pypi release, not a code patch — out of scope for this skill).
  - Phase 5.5 retest envelopes for Findings 1 and 4 will be classified `skipped-pypi-release-lag` by Team C (overriding the triage's cli-shell envelopes) so the retest agent does not falsely report `fail` against pypi-stale CLI. See Team C deliverable.

## File Conflict Table

| File | Team A | Team B | Team C | Team D |
|------|--------|--------|--------|--------|
| `finlet/cli.py` (line 285 only — `plugins_add` message) | ✓ | | | |
| `finlet/api/routes_plugins.py` | ✓ | | | |
| `finlet/api/routes_health.py` | ✓ (read-only) | | | |
| `finlet/plugins/registry.py` | ✓ | | | |
| `tests/test_cli.py` | ✓ (`plugins add` message test) | | | |
| `tests/api/test_routes_plugins.py` (or new) | ✓ | | | |
| `dashboard/settings.html` | | ✓ | | |
| `dashboard/settings.js` | | ✓ | | |
| `docs/REMAINING_TASKS.md` | | | ✓ | |
| `docs/LESSONS.md` | | | ✓ | |
| `docs/ARCHITECTURE.md` | | | ✓ | |
| `docs/KNOWN_FAILURES.md` | | | ✓ | |
| `docs/bug-hunt/20260501T172055Z127b/*` (artifacts) | | | ✓ | |
| `docs/bug-hunt/20260501T172055Z127b/triage.json` (override retest envelopes for F1/F4) | | | ✓ | |
| `docs/bug-hunt/ledger.jsonl` | | | | ✓ |

**No shared-file conflicts between any pair of teams.** A and B can run fully in parallel; C and D both wait on A+B then run in parallel.

## Dependency Graph

- Team A (Finding 2: EDGAR plugin hot-reload + CLI message) — independent, can start immediately
- Team B (Finding 3: settings.html password-form) — independent, can start immediately
- Team C (Docs) — blocked by A AND B (needs to know what landed)
- Team D (Ledger) — blocked by A AND B (needs merge SHAs from main after each merges)

## Critical Path

Team A (or B) → Team C → push

3-step chain. A and B in parallel cuts wall-clock by half vs sequential.

---

## Teams

### Team A: EDGAR plugin hot-reload + actionable CLI message (Finding 2)

**Blocked by:** none — can start immediately

**Read these files first:**
- `finlet/cli.py:283-291` — `plugins_add` command emits "Restart server to apply" (the wrong message)
- `finlet/cli.py:225-273` — pattern for the existing `plugins_list` command that calls the API correctly (reference for `plugins_add` to do the same — should hit a hot-reload endpoint)
- `finlet/api/routes_plugins.py` — current plugin configure routes; verify whether a `POST /v1/plugins/{name}/configure` exists or if persistence happens elsewhere
- `finlet/api/routes_health.py:82-110` — `GET /plugins/health` (the endpoint the dashboard polls every 2s and the CLI reads from)
- `finlet/plugins/registry.py` — `PluginRegistry` class, especially `register()` / `_all_plugins` / `health_check_all()` (line 673-682)
- `tests/api/test_routes_plugins.py` (if it exists) — existing test pattern for plugin routes
- `tests/test_cli.py:225-275` — pattern for testing `plugins_add` CLI behavior

**Files touched:**
- Modified: `finlet/cli.py` — `plugins_add` (around line 277-291): drop "Restart server to apply" message; replace with a confirmation that reads from `/v1/plugins/health` after configuring (e.g., "Plugin 'edgar' configured. Status: ready" or whatever the live status is) — pattern mirrors `plugins_list`.
- Modified: `finlet/api/routes_plugins.py` — wherever the plugin configure endpoint lives, ensure the registry is reloaded for the affected plugin so subsequent `GET /v1/plugins/health` reflects the new state without a server restart. Likely a call to `registry.reload(name)` or `registry.register(plugin_factory(name, config))` after persisting the new config.
- Modified: `finlet/plugins/registry.py` — if no `reload(name)` method exists, add one that re-instantiates the plugin from the persisted config and replaces the entry in `_all_plugins`. Must be idempotent and safe under concurrent reads (the dashboard polls `health_check_all()` every 2s).
- Modified: `tests/test_cli.py` — add or extend a test for `plugins_add` that verifies (a) the new message wording does NOT contain "Restart server" and (b) it surfaces the plugin's live status after configuring (mock the health endpoint).
- Modified: `tests/api/test_routes_plugins.py` (or `tests/plugins/test_registry.py` — pick the closest match to existing pattern) — add a test that POST configure → GET health returns the new state without a server restart.

**Deliverable:** A user (or agent via CLI) running `finlet plugins add edgar --email x@y.com` against a running finlet.dev sees a confirmation including the live plugin status (NOT "Restart server to apply"), AND `GET /v1/plugins/health` immediately reflects the new state without restarting the server. The dashboard's existing 2s polling will therefore display the updated status within ≤2s of the CLI command returning.

**Validation:**
- [ ] `uv run pytest tests/test_cli.py -k plugins_add -x -q` passes (new test)
- [ ] `uv run pytest tests/api/ tests/plugins/ -k "plugin or registry" -x -q` passes (existing + new registry-reload tests)
- [ ] `uv run ruff check finlet/cli.py finlet/api/routes_plugins.py finlet/plugins/registry.py` clean
- [ ] `uv run mypy finlet/api/routes_plugins.py finlet/plugins/registry.py` clean
- [ ] Manual sanity: in this branch's worktree, run `finlet plugins add edgar --email x@y.com` against a local `uv run finlet serve`; confirm the new message wording AND that `curl http://localhost:8000/v1/plugins/health | jq '.[] | select(.name=="edgar")'` shows ready (or whatever the registry reports for an EDGAR with valid email).
- [ ] Write `docs/bug-hunt/20260501T172055Z127b/team_A_verify.md` with the validation evidence (command + output excerpts).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Without an explicit commit, your worktree changes are lost.
- Worktree-rules block: every file you create or modify MUST live under `<worktree-root>/...` — the orchestrator detects leaks via `git -C <worktree-root> status` and a clean main-tree `git status`. If you accidentally write to `/Users/justnau/finlet/...` instead of the worktree root, the merge will be rejected.
- Follow existing patterns in `finlet/cli.py:225-273` (the `plugins_list` command that already calls the API correctly) for how to talk to the API from the CLI.
- Do NOT change the `plugins list` command itself (Finding 4 is already fixed).
- Do NOT change the portfolio command (Finding 1 is already fixed).
- The fix MUST work without requiring users to restart the server — that is the entire point of the bug.
- If the registry needs a thread/async lock to safely reload under concurrent reads, add one; do not introduce a race.

---

### Team B: Settings password fields wrapped in `<form>` (Finding 3)

**Blocked by:** none — can start immediately

**Read these files first:**
- `dashboard/settings.html:539` — static password field (delete-account modal) outside any form
- `dashboard/settings.html:287-316` — "API Keys & Security" section start (mount point context)
- `dashboard/settings.js:970-1015` — plugin config card rendering loop; line 996 has the dynamic `<input type="password">` template
- `dashboard/settings.js:1013` — button event listener for `savePluginConfig` (wrapping in `<form>` must NOT break this — keep `type="button"` on the save button OR add `e.preventDefault()` in the form-submit handler)
- The existing pattern of `<form>` usage in the dashboard (e.g., `dashboard/auth.html` login form, or any other settings.html `<form>` if present) — copy the pattern, don't invent new structure
- `dashboard/settings.html` browser-console output: blind agent counted 8 warnings, one per dynamically-rendered plugin password input

**Files touched:**
- Modified: `dashboard/settings.html` — wrap the static delete-account password input (line 539) in a `<form>` (with `onsubmit="return false"` or equivalent if no submit handler is desired)
- Modified: `dashboard/settings.js` — change the template at line 996 to wrap each plugin's password input in a `<form>` (or wrap the entire `.plugin-config-body` in a `<form>` per card). Add `autocomplete="new-password"` to the input (or `autocomplete="off"` if appropriate) so password managers don't try to autofill stale values into the wrong card.
- Verify trusted-types lint guard still passes (`scripts/lint-trusted-types.sh`) — the existing `trustedHTML(...)` wrapping must be preserved.

**Deliverable:** Loading `https://finlet.dev/settings.html` produces zero `[VERBOSE] [DOM] Password field is not contained in a form` console messages. Every `<input type="password">` on the page has an ancestor `<form>` element. Existing plugin save / delete-account flows still work.

**Validation:**
- [ ] `bash scripts/lint-trusted-types.sh` passes (no `.innerHTML =` outside `trustedHTML(...)` wrap)
- [ ] Manual browser check: open `dashboard/settings.html` (`uv run finlet serve` then `open http://localhost:8000/settings.html`); look at DevTools console for the warning string. Should be zero occurrences.
- [ ] Run a dirty-state-tracker smoke (memory: dirty-state-tracker refactor): no false-positive "unsaved changes" banner appears on cold load.
- [ ] Verify "Save" button in plugin config card still triggers `savePluginConfig` (click it, confirm a network request goes out)
- [ ] Verify delete-account modal still functions (open it, confirm the field accepts input — don't actually delete)
- [ ] Write `docs/bug-hunt/20260501T172055Z127b/team_B_verify.md` with screenshots of zero console warnings and confirmation the save/delete flows still work.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Worktree-rules block: every file you create or modify MUST live under `<worktree-root>/...` — the orchestrator detects leaks. Do NOT write to `/Users/justnau/finlet/dashboard/...` directly.
- Follow the trusted-types convention — every dashboard `.innerHTML =` write goes through `trustedHTML(...)`.
- Do NOT touch `finlet/` Python files in this team.
- Do NOT regress the existing form-dirty-tracker pattern (memory: `feedback_dirty_state_tracker_registry`); if you wrap an input in a new form, the dirty tracker should still see it via the registry pattern at `dashboard/form-dirty-tracker.js` — verify by checking that the "unsaved changes" banner does NOT fire on cold load.
- Bus events (memory: dashboard event bus rule): no direct `addEventListener('finlet:...')` — wire through `window.finletBus.subscribe`. Don't add event handlers in this PR; if you discover one needed, leave a TODO and ship the form fix.

---

### Team C: Docs updates (covers Required Docs Updates block + pypi-lag lesson)

**Blocked by:** Team A AND Team B (must wait until both merge so Team C can document what shipped)

**Read these files first:**
- `docs/bug-hunt/20260501T172055Z127b/triage.md` — Required Docs Updates block (lines 20-62)
- `docs/bug-hunt/20260501T172055Z127b/triage.json` — full classification + retest envelopes (Team C MUST update this file in-place to override retest envelopes for Findings 1 and 4 — see deliverable)
- `docs/bug-hunt/20260501T172055Z127b/blind_report.json` — original findings
- `docs/LESSONS.md` — existing lesson format
- `docs/REMAINING_TASKS.md` — existing closed-section format (mirror the prior `Bug Hunt YYYYMMDD... — Closed` subsection pattern)
- `docs/ARCHITECTURE.md` — current state (only update if Team A's plugin-registry hot-reload changed the registry surface)
- `docs/KNOWN_FAILURES.md` — pre-flight refresh
- Recent commit messages: `git log --oneline -10` to mirror the project's voice

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — add `## Bug Hunt 20260501T172055Z127b — Closed` subsection. List Finding 2 (real fix this iteration) and Finding 3 (real fix this iteration). For Findings 1 and 4, note "already fixed in main (cc6cddf, 1a3c17e); awaiting pypi release — see lesson."
- Modified: `docs/LESSONS.md` — at least 3 lessons:
  1. **Lesson: pypi-release-lag is a class of bug** — when a CLI bug shows up in a blind walk but the working-tree code is already fixed, it's a pypi staleness artifact, not a code bug. Document the diagnostic pattern (compare blind report's traceback path against working-tree line numbers; if they differ, suspect pypi-lag) and the proper response (mark retest as `skipped-pypi-release-lag`, don't spin a fix team, queue a release-cadence followup).
  2. **Lesson: "Restart server to apply" is a footgun on hosted services** — any CLI message that requires user-side server access is broken when the server is hosted (finlet.dev). Code-review heuristic: search for the literal string "restart server" / "restart your" in CLI command output and reject any message that requires hosted-server intervention.
  3. **Lesson: HTML password inputs without `<form>` wrappers break browser-native autofill** — Chromium logs `[VERBOSE] [DOM] Password field is not contained in a form` for every standalone `<input type=password>`. Convention: every password input in dashboard/* must have an ancestor `<form>`, even if the form has `onsubmit="return false"`. Add a lint rule if recurrence ever shows up in the bug-hunt ledger.
- Modified: `docs/ARCHITECTURE.md` — IF Team A added a `registry.reload(name)` method or otherwise changed the public registry surface, document that. Otherwise add an explicit note: "ARCHITECTURE.md unchanged this iteration (Team A's hot-reload was internal to PluginRegistry; no public API surface changed)."
- Modified: `docs/KNOWN_FAILURES.md` — refresh; if any pre-existing failure is closed by Team A or Team B, remove it.
- Modified: `docs/bug-hunt/20260501T172055Z127b/triage.json` — for the items with `category: cli-server-state-mismatch` (Finding 1) and `category: plugin-registry-routing` (Finding 4), REPLACE the `retest` envelope with:
  ```json
  {"kind": null, "description": "skipped-pypi-release-lag — code already fixed in main at <sha>; bug is in the pypi-installed CLI version. Cannot retest until a pypi release is cut.", "setup": "", "trigger": "", "assertions": []}
  ```
  Substitute `<sha>` with `cc6cddf` for Finding 1 and `1a3c17e` for Finding 4.
- New: `docs/decisions/<date>-pypi-release-cadence.md` (optional — only if Team C judges this is a non-trivial decision worth a 1-page record). The decision is: "Until we have a release pipeline, fixes that only land in main don't reach pypi-installed CLIs. Bug-hunt iterations should triage CLI-only bugs against working-tree state and mark them `skipped-pypi-release-lag` if the working tree is correct." If you write this doc, include a single follow-up action: "Cut a pypi release after this iteration to make Findings 1 and 4 actually go away for real users."
- Modified: stage every artifact in `docs/bug-hunt/20260501T172055Z127b/` (cleanup.log, blind_report.json, blind_stderr.log, triage.md, triage.json, plan.md, team_A_verify.md, team_B_verify.md, deploy_status.txt, retest_results.json — whichever exist after Phase 5.5 also runs).

**Deliverable:** All required docs are updated and committed in a single commit. The commit message follows the iteration template: `docs: bug-hunt 20260501T172055Z127b — fix EDGAR plugin hot-reload (F2); fix settings password-form (F3); F1+F4 deferred (pypi release-lag); LESSONS +3; ARCHITECTURE <updated|unchanged>; ledger appended by Team D`.

**Validation:**
- [ ] `git status` shows only docs/* + docs/bug-hunt/20260501T172055Z127b/* modifications
- [ ] `git log -1 --format=%s` matches the commit-message template above
- [ ] `wc -l docs/LESSONS.md` grew by at least 6 lines (3 lessons × ≥2 lines each)
- [ ] Every artifact in `docs/bug-hunt/20260501T172055Z127b/` is `git ls-files`-tracked
- [ ] Triage retest overrides for Findings 1 and 4 are in place (`jq '.items[] | select(.category=="cli-server-state-mismatch" or .category=="plugin-registry-routing") | .retest.kind' docs/bug-hunt/20260501T172055Z127b/triage.json` returns `null`-only)

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Worktree-rules block: file leaks to main tree get rejected.
- Do NOT touch the ledger (Team D's job) — that's append-only and Team D has the merge SHAs.
- Do NOT touch any code under `finlet/` or `dashboard/` — Team A and Team B own those.
- The triage.json override is REQUIRED, not optional — without it, Phase 5.5 will run a CLI retest against pypi-stale code and report a false `fail` that pollutes `pending_recurrences.jsonl` and trips the next iteration's gate incorrectly.

---

### Team D: Ledger entries (4 lines covering all findings)

**Blocked by:** Team A AND Team B (needs the merge SHAs from main; if Team C runs in parallel and hasn't merged yet, that's fine — Team D doesn't depend on Team C)

**Read these files first:**
- `docs/bug-hunt/ledger.jsonl` — last 5 lines for schema reference (use `tail -5`); confirm the flat schema with fields `iteration_ts`, `finding_id`, `category`, `summary`, `scope_files`, `team`, `commit`
- `git log --oneline -10 origin/main` — to grab merge SHAs for Teams A and B
- `docs/bug-hunt/20260501T172055Z127b/plan.md` (this file, Constraints section) — for Findings 1 and 4 commit refs

**Files touched:**
- Modified: `docs/bug-hunt/ledger.jsonl` — append exactly 4 JSON lines (one per real-broken finding):
  1. **Finding 1** (portfolio AttributeError): `{"iteration_ts":"20260501T172055Z127b","finding_id":"cli-portfolio-positions-iter","category":"cli-server-state-mismatch","summary":"finlet portfolio CLI crashed because installed pypi version iterated dict keys instead of values; fix already on main (cc6cddf)","scope_files":["finlet/cli.py:552"],"team":"-","commit":"cc6cddf"}`
  2. **Finding 2** (EDGAR plugin stale): `{"iteration_ts":"20260501T172055Z127b","finding_id":"edgar-plugin-restart-required","category":"dashboard-state-sync","summary":"finlet plugins add edgar required server restart and dashboard never refreshed; fixed by hot-reloading registry on configure and updating CLI message","scope_files":["finlet/cli.py","finlet/api/routes_plugins.py","finlet/plugins/registry.py"],"team":"A","commit":"<TEAM_A_MERGE_SHA>"}`
  3. **Finding 3** (password fields outside form): `{"iteration_ts":"20260501T172055Z127b","finding_id":"settings-password-no-form","category":"password-form-aria","summary":"settings.html rendered 8 password inputs outside any <form>; wrapped each plugin card and the delete-account modal","scope_files":["dashboard/settings.html","dashboard/settings.js"],"team":"B","commit":"<TEAM_B_MERGE_SHA>"}`
  4. **Finding 4** (CLI plugins list mismatch): `{"iteration_ts":"20260501T172055Z127b","finding_id":"cli-plugins-list-pypi-stale","category":"plugin-registry-routing","summary":"finlet plugins list returned 4 plugins vs dashboard's 8; fix already on main (1a3c17e), pypi version stale","scope_files":["finlet/cli.py:229-273"],"team":"-","commit":"1a3c17e"}`

  Substitute `<TEAM_A_MERGE_SHA>` and `<TEAM_B_MERGE_SHA>` with the actual short SHAs from `git log --oneline -5 origin/main`. Look for commit subjects like `Merge Team A:` and `Merge Team B:` (matching the team's commit subject — Team A's branch likely commits as `[Team A]: ...` and `/exec-plan`'s merge commit will reference Team A).

**Deliverable:** `docs/bug-hunt/ledger.jsonl` grows by exactly 4 lines. Each line parses as JSON; each contains the 7 schema fields; each `commit` field is a real git SHA reachable from `origin/main`.

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` grew by exactly 4
- [ ] `tail -4 docs/bug-hunt/ledger.jsonl | jq -e '.iteration_ts == "20260501T172055Z127b"'` returns true for all 4
- [ ] `tail -4 docs/bug-hunt/ledger.jsonl | jq -r '.commit' | xargs -I {} git cat-file -e {} 2>&1` produces no "Not a valid object name" errors
- [ ] Categories used match either an existing ledger category OR a new one (only `password-form-aria` is new — that's intentional)

**Agent instructions:**
- You MUST `git add docs/bug-hunt/ledger.jsonl` + `git commit -m "ledger: bug-hunt 20260501T172055Z127b — append 4 findings (2 fixed this iteration, 2 pypi-stale)"` before finishing.
- Worktree-rules block: file leaks to main tree get rejected.
- Do NOT modify the ledger schema — append-only, flat schema, one JSON object per line, no trailing comma.
- If you cannot find the merge SHAs for Teams A or B in `origin/main`, BLOCK and report. Do NOT guess SHAs or write placeholder strings.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A's registry hot-reload introduces a race under concurrent dashboard polling (every 2s) | Medium | Medium | Add a lock around `registry.reload(name)` (or `_all_plugins[name] = ...`); add a regression test that exercises N concurrent reads + 1 write |
| Team A's CLI message change breaks an existing test that asserts the literal "Restart server to apply" string | Low | Low | grep `tests/` for "Restart server to apply" before changing — update the assertion alongside the message change |
| Team B's `<form>` wrapping accidentally triggers form submit on Enter, navigating away from the page | Medium | High | Use `<form onsubmit="return false">` OR add `e.preventDefault()` in any submit handler; manual test "press Enter inside the password input" should remain on the same page |
| Team B regresses the form-dirty tracker — wrapping inputs in a new form may shift baseline-snapshot timing | Medium | Medium | Validation step explicitly checks no false-positive "unsaved changes" banner on cold load |
| Team C's triage.json override is missed — Phase 5.5 runs cli-shell retests against pypi-stale CLI and reports false `fail` | Medium | High | Validation checks `jq '.items[] | select(.category=="cli-server-state-mismatch" or .category=="plugin-registry-routing") | .retest.kind' == null` |
| Team D writes wrong merge SHAs (typos, picks the branch SHA instead of merge SHA) | Medium | Medium | Validation runs `git cat-file -e <sha>` on every commit field |
| Findings 1+4 get classified as `patch-ineffective` next iteration because the override didn't take or the retest fell through | Low | High | Team C's retest override is a hard requirement; Phase 5.5 will respect `kind: null` per the skill spec ("treat null retests as skipped — not retestable, NOT as a fail") |
| Plugin registry refactor candidate gets prematurely promoted | High | Low | The pypi-lag for Finding 4 (`plugin-registry-routing`) does NOT trip a real refactor signal — the underlying convention works; noted in lesson 1 so the next iteration's gate doesn't false-trigger |

## Session Plan

### Session 1 — Parallel code fixes
**Parallel:** Team A + Team B (no shared files, fully independent)
**Merge order:** A and B can merge in any order. After EACH merge, `/exec-plan` runs the targeted test gate (`uv run pytest tests/test_cli.py -k plugins_add` for A; `bash scripts/lint-trusted-types.sh` + `pytest tests/api/ -k smoke -x -q` for B).
**Session checkpoint:** Full test suite (`uv run pytest -q`) after both A and B have merged.

### Session 2 — Docs + ledger
**Parallel:** Team C + Team D (no shared files; both wait on Session 1)
**Merge order:** Order does not matter — they touch disjoint files.
**Session checkpoint:** `git log --oneline -6 origin/main` should show the 4 merge commits (A, B, C, D) in any order, with the iteration-ts referenced in C and D commit messages. `wc -l docs/bug-hunt/ledger.jsonl` confirms +4 growth.

---

## Worktree Rules (paste into every team prompt — memory: feedback_worktree_prompts.md)

```
WORKTREE RULES (mandatory):
- Your working dir is the worktree root assigned to you. ALL file paths in your edits must be relative to that root.
- Do NOT cd to /Users/justnau/finlet/. Do NOT write to absolute paths under /Users/justnau/finlet/<not-your-worktree>.
- Verify with `git -C <worktree-root> status` before and after; the main tree's `git status` must remain clean for files outside your scope.
- Commit with `git -C <worktree-root> commit ...`. The orchestrator merges your branch back to main.
```
