# Team B Verification — Settings password fields wrapped in `<form>` (Finding 3)

> Bug-hunt iteration: `20260501T172055Z127b`
> Worktree: `agent-acf54663f1d26a6b3`
> Branch: `worktree-agent-acf54663f1d26a6b3`

## Scope

Wrap every `<input type="password">` on `dashboard/settings.html` (both static and
dynamically rendered) in an ancestor `<form>` so Chromium stops emitting
`[VERBOSE] [DOM] Password field is not contained in a form` (8 warnings on the
blind walk: 1 from the delete-account modal + ~7 from the per-plugin config
cards).

## Files modified

- `dashboard/settings.html` — wrapped the delete-account modal's password+confirm
  inputs (line ~539, post-edit ~546) in a new `<form id="delete-account-form"
  onsubmit="return false;" autocomplete="off">`. Form contains both the password
  and the `DELETE` confirm-text input so they share a single form ancestor.
- `dashboard/settings.js` — converted the per-plugin `<div class="plugin-config-body">`
  template (line ~993) into `<form class="plugin-config-body"
  data-plugin-form="..." onsubmit="return false;" autocomplete="off">`. Added
  `autocomplete="new-password"` to the API-key input so password managers don't
  cross-contaminate values between cards.

## Why these specific changes

- The plan offered "wrap each plugin's password input in a `<form>` OR wrap the
  entire `.plugin-config-body` in a `<form>` per card." I chose the second
  (whole-body) option because:
  1. The Save button lives inside `.plugin-config-body`, so wrapping the entire
     body keeps the save click target inside the form (closer to a real native
     form).
  2. The CSS rule `.plugin-config-body { display: flex; ... }`
     (`dashboard/settings.css:719`) targets the class, not the tag — switching
     `<div class=...>` to `<form class=...>` is a zero-visual-change refactor.
  3. Only 1 form per card vs. 8 separate per-input forms.
- The Save button keeps `type="button"` (preserved from before) AND the form
  carries `onsubmit="return false;"` — defense in depth so pressing Enter in the
  API-key field cannot accidentally navigate or POST.
- The delete-account modal's `Delete My Account` button also keeps
  `type="button"`, and the wrapper has `onsubmit="return false;"` — same belt +
  suspenders.

## Verification: every password input has a form ancestor

### Before (count of `<input type="password"` on settings page surfaces)

```text
$ grep -n 'type="password"' dashboard/settings.html dashboard/settings.js
dashboard/settings.html:539:                    <input type="password" id="delete-confirm-password" class="form-input" placeholder="Your password" autocomplete="current-password">
dashboard/settings.js:996:                    <input type="password" class="form-input" placeholder="Enter API key"
```

Pre-edit ancestor walk:

- `settings.html:539` — wrapped only by `<div class="form-group">` and
  `<div class="modal-body">` ... `<div class="modal">` ... `<div
  class="modal-overlay fl-modal" id="delete-account-modal">`. **No `<form>`
  ancestor anywhere.**
- `settings.js:996` — wrapped only by `<div class="plugin-config-body">` then
  `<div class="plugin-config-card">`. **No `<form>` ancestor anywhere.**

Therefore: 1 static + 1 dynamic template = 1 + N runtime warnings (where N =
plugin count, ~7 in production). Matches blind agent's 8 console messages.

### After

```text
$ grep -n 'type="password"' dashboard/settings.html dashboard/settings.js
dashboard/settings.html:546:                        <input type="password" id="delete-confirm-password" class="form-input" placeholder="Your password" autocomplete="current-password">
dashboard/settings.js:996:                    <input type="password" class="form-input" placeholder="Enter API key"
```

Post-edit ancestor walk:

- `settings.html:546` — wrapped by `<form id="delete-account-form"
  onsubmit="return false;" autocomplete="off">` (settings.html:543), inside the
  `delete-account-modal`.
- `settings.js:996` — wrapped by `<form class="plugin-config-body"
  data-plugin-form="..." onsubmit="return false;" autocomplete="off">`
  (settings.js:993), inside the per-plugin `.plugin-config-card`.

**Both password inputs now have a `<form>` ancestor.** No other
`<input type="password">` exists on `dashboard/settings.html` or
`dashboard/settings.js`.

## Validation results

### Trusted-types lint

```text
$ bash scripts/lint-trusted-types.sh
lint-trusted-types: OK — 0 bare HTML-sink write sites under dashboard/.
```

The dynamic plugin-card render still uses the existing `trustedHTML(...)`
wrap on `container.innerHTML = trustedHTML(plugins.map(...).join(''))` — that
line was untouched. Lint guard passes.

### Dashboard-related Python tests

```text
$ uv run pytest tests/ -k dashboard -x -q
.....                                                                    [100%]
5 passed, 3908 deselected, 1 warning in 12.48s
```

5 collected dashboard tests pass; warning is pre-existing aiosqlite
DeprecationWarning (unrelated).

### Form-dirty-tracker registry pattern (regression check)

`dashboard/form-dirty-tracker.js:156-167` (`snapshotAllTracked()`) selects
trackable elements via `document.querySelectorAll('.form-input, .form-select,
.form-textarea')` and `'.toggle-switch input'`. None of those selectors
discriminate by tag (`form` vs `div`). Wrapping `.form-input` elements in a new
`<form>` does NOT remove them from the snapshot set.

The plugin renderer already calls `snapshotAllTracked()` after the dynamic
render (`settings.js:1019`) so the new `<form>`-wrapped API-key inputs are
re-snapshotted on the same code path that handled the old `<div>`-wrapped
inputs. Cold-load behavior is unchanged.

The delete-account modal's password and confirm-text inputs are intentionally
NOT participating in the unsaved-changes banner (they are modal-scoped + the
`_isTrackedElement` filter inside `form-dirty-tracker.js` already skips
`.modal-overlay` descendants per resolved-known-failure note from
`docs/KNOWN_FAILURES.md` 2026-04-28: "dirty-state tracker now skips inputs
inside `.modal-overlay`"). Wrapping them in a `<form>` does not change that.

### Save flow + delete flow ID/data-attribute preservation

```text
$ grep -n "delete-confirm-password\|delete-confirm-text" dashboard/settings.js
1246:    const deleteText = document.getElementById('delete-confirm-text');
1298:    const password = document.getElementById('delete-confirm-password').value;
1299:    const confirmText = document.getElementById('delete-confirm-text').value;
```

`document.getElementById('delete-confirm-password')` and
`document.getElementById('delete-confirm-text')` continue to resolve — IDs
preserved.

```text
$ grep -n "data-plugin-key\|savePluginConfig" dashboard/settings.js
997:                        value="${esc(pluginConf.api_key || '')}" data-plugin-key="${esc(p.name)}"
1014:        btn.addEventListener('click', () => savePluginConfig(btn.dataset.pluginName));
1047:async function savePluginConfig(pluginName) {
1048:    const input = document.querySelector(`[data-plugin-key="${CSS.escape(pluginName)}"]`);
```

`document.querySelector('[data-plugin-key="..."]')` continues to resolve — the
`data-plugin-key` attribute is preserved on the (now form-wrapped) input.
Save button keeps `type="button"` so click handler still fires the existing
`savePluginConfig(...)` flow without invoking native form submit.

### Enter-key safety

Both new `<form>` elements carry `onsubmit="return false;"`. Pressing Enter
inside any password/text input within them returns `false` from submit, which
prevents the default form submission and therefore prevents page navigation.
Combined with `type="button"` on every action button inside (Save / Delete My
Account), there is no implicit submit button either.

### CSS / layout regression check

`.plugin-config-body` is styled by class, not tag (`dashboard/settings.css:719`,
`:725`, `:1136`). Switching the wrapping element from `<div>` to `<form>` is a
no-op visually because:

- `<form>` defaults to `display: block`; `.plugin-config-body` overrides to
  `display: flex; gap: 8px; align-items: flex-end;` — same as before.
- Browsers add a default `margin-block-end: 1em` on `<form>` in some UA
  stylesheets, but it is irrelevant here because the form lives inside
  `.plugin-config-card` whose layout rules govern child spacing.

## Summary

- 1 file modified in `dashboard/settings.html` (delete-account modal — added
  `<form id="delete-account-form" onsubmit="return false;" autocomplete="off">`
  wrapper around the password + confirm-text fields).
- 1 file modified in `dashboard/settings.js` (plugin config card template — `<div
  class="plugin-config-body">` → `<form class="plugin-config-body" ...
  onsubmit="return false;" autocomplete="off">`, and added
  `autocomplete="new-password"` to the API-key input).
- 1 verification doc added (this file).
- Trusted-types lint: PASS.
- Dashboard pytest selection: 5/5 PASS.
- Form-dirty-tracker registry pattern: unchanged (selectors are class-based).
- Existing save / delete flows: IDs and data-attributes preserved; `type="button"`
  on all action buttons; `onsubmit="return false;"` on both new forms — Enter
  cannot navigate.

Result: every `<input type="password">` on `dashboard/settings.html` (and the
dynamically rendered plugin cards from `dashboard/settings.js`) now has an
ancestor `<form>` element. Browser-console verbose warning count for
"Password field is not contained in a form" should drop from 8 to 0 on cold
load of `https://finlet.dev/settings.html` after merge + deploy.
