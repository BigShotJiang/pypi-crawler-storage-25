## Broken (will be fixed this iteration)

- `finlet portfolio -s <session_id>` crashes with `AttributeError: 'str' object has no attribute 'get'` at cli.py:378 — CLI assumes positions are dicts but the API/SDK returns strings. Reproduced 100%, blocks portfolio inspection from CLI. [evidence: "Traceback at /opt/homebrew/lib/python3.14/site-packages/finlet/cli.py:378 — `AttributeError: 'str' object has no attribute 'get'`. The positions list from the API appears to return strings instead of dicts; the CLI assumes dicts at line 378 (`pos.get('unrealized_pnl', 0.0)`). Reproduced 100%."] [scope hint: finlet/cli.py:378, finlet/api/routes_portfolio.py, tests/test_cli.py]
- EDGAR plugin status is stale in the web UI after CLI configuration — Plugin Health panel still shows red dot + "edgar plugin not initialized" after `finlet plugins add edgar` succeeded with "Plugin edgar configured. Restart server to apply." UI state contradicts backend mutation, and the user-facing "Restart server to apply" message is impossible to act on against a hosted service. [evidence: "Ran `finlet plugins add edgar --email jgn0017@auburn.edu`; CLI responded 'Plugin edgar configured. Restart server to apply.' The dashboard Plugin Health panel continued to show red dot + 'edgar plugin not initialized.' after a full page reload."] [scope hint: finlet/api/routes_plugins.py, finlet/plugins/registry.py, finlet/cli.py (plugins add), dashboard/settings.js plugin-health panel]
- Settings page renders 8 password fields outside any `<form>` element — Chromium DOM verbose log "Password field is not contained in a form" fires 8 times on every load of settings.html, breaking native password-manager autofill on the API Keys & Security section. Console-error-on-happy-path predicate. [evidence: "Console log at .playwright-mcp/console-2026-05-01T17-26-43-750Z.log lines 1–9: '[VERBOSE] [DOM] Password field is not contained in a form' × 8. This breaks browser-native password-manager autofill and may break accessibility for screen readers on the API Keys & Security section."] [scope hint: dashboard/settings.html (API Keys & Security section), dashboard/settings.js]
- CLI `finlet plugins list` shows 4 plugins (price/edgar/fred/finnhub) while the dashboard's Plugin Health panel shows 8 (price, fundamentals_s3, news_s3, sentiment, finnhub, fred, econ, edgar) — two surfaces of the same registry disagree, and an agent driving via CLI cannot see fundamentals_s3 (the only healthy data source). Documented happy-path mismatch between two code paths claiming the same job. [evidence: "Web UI lists: price, fundamentals_s3, news_s3, sentiment, finnhub, fred, econ, edgar. CLI lists only: price, edgar, fred, finnhub. The four UI-only plugins (fundamentals_s3, news_s3, sentiment, econ) are not configurable or visible via CLI."] [scope hint: finlet/cli.py (plugins list — should already be calling GET /v1/plugins/health per ledger 1616ade), finlet/api/routes_plugins.py, tests/test_cli.py — verify deployed CLI version]

## Logged (not actioned)

- Finlet MCP server not available as a tool in the blind Claude session [classification: ambiguous]
- Existing API keys show only last 4 chars with no copy button on existing rows — must create a new key to get a usable value [classification: annoying]
- CLI `finlet status` requires `--session`/`-s` flag and won't accept session ID as a positional argument [classification: annoying]
- "Fundamentals strategy" terminology in docs/onboarding does not map to any named UI feature [classification: annoying]
- Equity Curve TradingView chart blank after a filled trade until clock advances at least once — no tooltip explains the empty state [classification: annoying]
- Onboarding wizard Continue button (id=ob-next) reachable only via DOM id, not via accessibility-tree role/name selectors [classification: annoying]
- No "Fundamentals Strategy" session template (only Conservative ETF / Tech Growth / Custom) [classification: nice-to-have]
- No in-app MCP configuration helper — connecting Claude Code requires manual JSON editing of claude_desktop_config.json [classification: nice-to-have]
- CLI has no `--play` / `--speed` / `--count` flag on `finlet advance` to run multi-day simulations headlessly [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260501T172055Z127b — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. `docs/bug-hunt/20260501T172055Z127b/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log,
   deploy_status.txt, retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260501T172055Z127b","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline (see
   Phase 5.5c). Team D MUST stage the file. If a refactor verdict pruned entries
   this iteration, Team D MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`
   (the audit log of resolved signals).

Team D's commit message must reference iteration 20260501T172055Z127b and name which docs were
touched (e.g., "docs: bug-hunt 20260501T172055Z127b — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
