You are Team B: Plugin Health Probe Stops Lying About Historical Data.

Working dir: your worktree (already isolated). Base SHA: b99220ef5ad52303b4b8e3ccea549a258cc64578 (the orchestrator will reset your worktree to this before you start).

**Blocked by:** none — independent.

**This is a RECURRENCE.** The prior fix at commit `76f4724` (iter 20260501T234103Z1a49) patched the symptom and didn't close the root cause. You MUST `git show 76f4724 -- finlet/plugins/price_plugin.py` and document, in `team_b_verify.md`, what 76f4724 actually changed and WHY this iteration's fix closes the root cause that 76f4724 missed. If you can't articulate the gap, you're about to ship the same fix again — STOP and report BLOCKED with what you saw.

**Read these files first:**
- `docs/KNOWN_FAILURES.md` — these are pre-existing failures; do NOT report them as issues you caused.
- `finlet/plugins/price_plugin.py:797-822` — current `health_check()` docstring (states design intent: reachability-only, NOT date-window awareness — but the implementation contradicts this)
- `finlet/plugins/price_plugin.py:843-859` — `health_check()` body. Calls `_check_s3_reachable()` then `_render_probe_health()`. Has NO session/ceiling context.
- `finlet/plugins/price_plugin.py:861-895` — `_render_probe_health()`. Returns DEGRADED with `"No price data available for the last {PROBE_RECENT_DAYS} days. Run ingestion first."` when S3 reachable but the recent-window prefix has zero parquet files. THIS IS THE FALSE POSITIVE — the engine clearly has data (orders fill at $560.90 against May-2025 simulated dates) but the probe checks today−7d real-world dates, where there's no fresh data.
- `finlet/plugins/base.py:246` — `async def health_check(self) -> PluginHealth:` (current protocol; no session/ceiling argument)
- `finlet/api/routes_health.py:84-114` — `/plugins/health` route handler; calls `registry.health_check_all()` with no session context
- `git show 76f4724 --stat` AND `git show 76f4724 -- finlet/plugins/price_plugin.py` — what the prior recurrence fix actually changed; **REQUIRED reading before designing this fix**
- `tests/plugins/test_price_plugin.py` — current health_check coverage (recon notes this exists but doesn't assert date-window awareness)

**Files touched:**
- Modified: `finlet/plugins/price_plugin.py` — replace the "last 7 real-world days" probe with a probe that succeeds whenever ANY parquet exists for the relevant historical lookback window. Concrete options ranked: (1) drop recent-window probe, just check S3 reachability + at-least-one-recent-year partition exists; (2) parameterize probe lookback to 365 days to match the historical data shape; (3) make health session-aware (requires base.py + routes_health.py changes — only do this if (1)/(2) are insufficient).
- Modified: `tests/plugins/test_price_plugin.py` — add a regression test that asserts: (a) `health_check()` returns HEALTHY when S3 has price data older than 7 real-world days but within the historical lookback; (b) the response message does NOT contain `"Run ingestion first"` or `"No price data available for the last"`; (c) the prior failure mode (degraded false positive) is reproduced and now passes.
- Modified (only if option 3 above): `finlet/plugins/base.py:246` (signature) and `finlet/api/routes_health.py:84-114` (pass session). Avoid this if simpler options work.

**Risk register binding:** add a separate test asserting that S3-unreachable still produces UNHEALTHY (not just HEALTHY-because-recency-was-dropped). Health check MUST still detect a true outage.

**Deliverable:** GET `/v1/plugins/health` reports `price.status == "healthy"` whenever a market BUY against the active session's simulated date can fill, with a non-misleading message. Verified by the curl retest envelope in `triage.json` item #2.

**Validation:**
- [ ] `uv run pytest tests/plugins/test_price_plugin.py -x -q` — all tests pass, including the new regression and the S3-unreachable still-UNHEALTHY assertion.
- [ ] `uv run ruff check finlet/plugins/price_plugin.py tests/plugins/test_price_plugin.py` — zero warnings.
- [ ] `uv run mypy finlet/plugins/price_plugin.py` — zero errors.
- [ ] `team_b_verify.md` documents what 76f4724 changed and why this fix closes the root cause that 76f4724 missed.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing — worktree is cleaned up otherwise.
- Your commit message MUST start with `[Team B]:`.
- DO NOT just add another `or` clause to the prior fix — understand WHY the probe is wrong and pick the simplest fix that closes the root cause.
- DO NOT touch `finlet/plugins/base.py` or `finlet/api/routes_health.py` unless option (3) is chosen and justified in `team_b_verify.md`. The simplest fix is best.
- Write `docs/bug-hunt/20260503T230405Z2601/team_b_verify.md` with: a section "Why 76f4724 didn't close this" (concrete diff analysis), the chosen option (1/2/3) with justification, file diffs, validation command output.

CRITICAL RULES (apply to every team):
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues
- Read the "Read these files first" list BEFORE writing any code
- Follow existing patterns in those files
- You MUST `git add` and `git commit` all your changes before finishing
- Your commit message must start with "[Team B]:"
- Run the validation commands from your spec before finishing
- If validation fails, fix the issue and re-commit

When done, report: DONE + commit hash + validation results
OR: BLOCKED + what went wrong
