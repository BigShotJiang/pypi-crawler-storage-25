You are Team C: Settings Plugin Cards Stop Emitting 9 Console Errors.

Working dir: your worktree (already isolated). Base SHA: b99220ef5ad52303b4b8e3ccea549a258cc64578 (the orchestrator will reset your worktree to this before you start).

**Blocked by:** none — independent.

**This is a RECURRENCE.** Prior fixes at commits `ce5fa52` (iter 20260501T172055Z127b) and `78ee51f` patched form-wrapping but didn't add the username peer that Chromium's password-autofill heuristic actually requires. You MUST `git show ce5fa52 -- dashboard/` AND `git show 78ee51f -- dashboard/` and document, in `team_c_verify.md`, what those changed and WHY this iteration's fix closes the root cause they missed.

**Read these files first:**
- `docs/KNOWN_FAILURES.md` — these are pre-existing failures; do NOT report them as issues you caused.
- `dashboard/settings.js:1079-1085` — current plugin card template. Recon says the password input IS already inside a `<form>` with `autocomplete="off"` and `autocomplete="new-password"` on the input. The browser STILL emits the warning because the form has NO `<input type="text"|"email" autocomplete="username">` peer. Chromium's password-autofill heuristic requires a username peer (visible OR hidden) inside the same form ancestor.
- `dashboard/settings.html:562` — separate delete-account password input pattern (different context, NOT a model — it has different form requirements)
- `git show ce5fa52 --stat` AND `git show ce5fa52 -- dashboard/` — **REQUIRED reading**
- `git show 78ee51f -- dashboard/` if 78ee51f exists — **REQUIRED reading** if it touched dashboard/
- `dashboard/event-contract.md` — bus naming conventions (only relevant if the fix introduces a new event; likely not)
- Chromium guidance: <https://goo.gl/9p2vKq> — the URL the warning itself links to. Read it before fixing.

**Files touched:**
- Modified: `dashboard/settings.js` — for each plugin card form, add a hidden `<input type="text" autocomplete="username" hidden value="<plugin-slug>" name="username">` peer immediately before the password input. Use the plugin's slug or display name as the username value (it's a label for password managers, not a real credential). The form ALREADY exists per recon; only the peer input is missing.
- Modified: `tests/e2e/journey-06-settings.spec.ts` (or whichever covers Settings) — add a Playwright assertion: cold-load `settings.html#plugins`, capture `browser_console_messages` with `all: true`, and assert ZERO entries match `/Password forms should have.*username fields/i` AND zero match `/goo\.gl\/9p2vKq/`. Plus a structural assertion: every `<input type="password">` has a sibling `<input ... autocomplete="username">` inside the same `<form>`.

**Risk register binding:** Use a plugin-slug value (not "username") for the hidden peer so password managers don't treat it as a real credential.

**Deliverable:** Cold load of `settings.html#plugins` produces zero password-form accessibility warnings in the console, regardless of viewport or session state. Verified by the playwright retest envelope in `triage.json` item #3.

**Validation:**
- [ ] `bash scripts/lint-trusted-types.sh` — zero `.innerHTML` violations.
- [ ] `uv run pytest tests/api -k "settings" -x -q` — relevant API tests pass.
- [ ] `npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-06-settings.spec.ts` — passes including the new console-warning assertion. (Note: e2e tests may need `finlet serve` running. If you can't run e2e locally, document why and run a structural-only assertion.)
- [ ] `team_c_verify.md` includes a section "Why ce5fa52/78ee51f didn't close this".

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Your commit message MUST start with `[Team C]:`.
- DO NOT just re-add the form wrapper. The username peer is the missing piece.
- DO NOT change the password input's `autocomplete="new-password"` attribute. DO NOT remove the form ancestor.
- The username peer can be `hidden` and use the plugin slug as its value — it's a label for the heuristic, not a real credential.
- Write `docs/bug-hunt/20260503T230405Z2601/team_c_verify.md` with: a section "Why ce5fa52/78ee51f didn't close this" (concrete diff analysis), the file diff, validation command output, and a Playwright snapshot or structural verification of the absence of warnings.

CRITICAL RULES (apply to every team):
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues
- Read the "Read these files first" list BEFORE writing any code
- Follow existing patterns in those files
- You MUST `git add` and `git commit` all your changes before finishing
- Your commit message must start with "[Team C]:"
- Run the validation commands from your spec before finishing
- If validation fails, fix the issue and re-commit

When done, report: DONE + commit hash + validation results
OR: BLOCKED + what went wrong
