You are Team E: Docs + Ledger.

You are running directly on `main` at /Users/justnau/finlet (NOT in a worktree). Always use `git -C /Users/justnau/finlet <op>` for git ops to avoid CWD drift.

**Blocked by:** Team A, Team B, Team C, Team D — all merged. Their merge SHAs (THESE are what you write into the ledger's `commit` field):
- Team A: `828003d` (worktree commit `0422d80`) — Sim Time CSS auto-hyphenation prevention
- Team B: `cc20161` (worktree commit `b6cf709`) — Plugin Health probe replaced with unscoped S3 reachability
- Team C: `b08ddb8` (worktree commit `d6c175e`) — Settings password forms get hidden autocomplete=username peer
- Team D: `3dc28c2` (worktree commit `0e54b8d`) — OrderResponse cash-disclosure (commission + slippage_amount + total_cost)

Iteration timestamp: `20260503T230405Z2601`. Artifact dir: `docs/bug-hunt/20260503T230405Z2601/`.

**Read these files first:**
- `docs/KNOWN_FAILURES.md` — pre-existing failures.
- `docs/REMAINING_TASKS.md` — pattern for adding "Bug Hunt 20260503T230405Z2601 — Closed".
- `docs/LESSONS.md` — pattern for adding lessons.
- `docs/ARCHITECTURE.md` — confirm whether anything changed (this iteration: dashboard tile CSS rules, plugin-health probe contract, settings DOM shape, OrderResponse schema gained 3 fields, dashboard order-log gained a column).
- `docs/bug-hunt/ledger.jsonl` — read the LAST 5 lines to confirm the JSONL schema before appending. Run: `tail -5 docs/bug-hunt/ledger.jsonl`. Pre-edit count: `wc -l docs/bug-hunt/ledger.jsonl` (should be 47).
- `docs/bug-hunt/pending_recurrences.jsonl` — currently EMPTY. DO NOT MODIFY. Phase 5.5 (post-exec-plan) handles patch-ineffective signals separately.
- The team verify docs (already on main from teams' merges):
  - `docs/bug-hunt/20260503T230405Z2601/team_a_verify.md`
  - `docs/bug-hunt/20260503T230405Z2601/team_b_verify.md`
  - `docs/bug-hunt/20260503T230405Z2601/team_c_verify.md`
  - `docs/bug-hunt/20260503T230405Z2601/team_d_verify.md`
  Use these to source the LESSONS lessons accurately (each verify doc has a "why prior fix didn't close this" or rationale section).
- `docs/decisions/` — list directory for naming conventions; only add a new record if a non-trivial reversible decision was made.

**Files to write/modify:**

1. `docs/REMAINING_TASKS.md` — add a new subsection "Bug Hunt 20260503T230405Z2601 — Closed" (mirror prior iteration patterns). List the four broken items with their resolving merge SHAs and one-line summaries. Place in the appropriate section per existing conventions.

2. `docs/LESSONS.md` — append AT LEAST one reusable lesson per real-broken finding. Phrase each as a rule, not a diff recap. Candidates (refine using the verify docs):
   - **Sim Time tile (Team A):** "When a metric tile renders ASCII text (datetime, ID), set `hyphens: none; word-break: keep-all; white-space: nowrap;` defensively. Chrome's auto-hyphenation inserts U+2014 silently when the value doesn't fit the cell. CSS rule of thumb: every `.metric-value` / `.stat-value` style block should include hyphens-prevention."
   - **Plugin Health (Team B):** "Plugin health probes MUST be reachability/data-presence checks, not 'last N real-world days' probes. Finlet operates on simulated dates that can be months/years stale relative to real-world today. A date-scoped probe lies about historical data and contradicts the engine's actual data path. The right shape: one unscoped `list_objects_v2` with MaxKeys=1, asking 'is the data lake populated at all?'"
   - **Settings password forms (Team C):** "Wrapping `<input type=password>` in a `<form>` is necessary but not sufficient — Chromium's password-autofill heuristic emits two distinct warnings, one for missing form ancestor and one for missing username peer. A complete fix needs BOTH a form ancestor AND a sibling `<input autocomplete=username>` peer (hidden is fine) inside that form. Form-only fixes produce a recurrence on the second warning shape."
   - **Cash math (Team D):** "Server-computed cash deltas MUST be reconcilable from API response fields alone. If the engine rounds fill_price for display, expose `slippage_amount` and `total_cost` in the response — do not require the client to re-derive math the engine already did at higher precision. Disclosure is the fix; do NOT change the model defaults to make math 'work out'."

3. `docs/ARCHITECTURE.md` — touch the relevant sections:
   - Dashboard surface: note `.stat-value` defensive hyphenation rule and the new Total Cost column on the order log table.
   - Plugin registry / health: note the price plugin probe is now reachability-only (no date window).
   - API schema (OrderResponse): note the three new optional disclosure fields (commission, slippage_amount, total_cost).
   - Settings forms: note the hidden autocomplete=username peer pattern in plugin cards.
   If any of these areas already documented in ARCHITECTURE.md, update them in place; if not, add a brief note.

4. `docs/KNOWN_FAILURES.md` — pre-flight reported zero pre-existing failures resolved this iteration. Confirm by reading the file: if any rows match this iteration's fix scope (price_plugin health, settings password forms, etc.), remove them and the corresponding `@pytest.mark.xfail` marker in the test files. If nothing matches, leave the file alone and note "no failures resolved" in the Team E commit message.

5. `docs/decisions/` — likely candidates this iteration (only write if non-trivial AND reversible):
   - `docs/decisions/plugin-health-probe-reachability-only.md` (Team B's Option 1 vs 2 vs 3 choice — this is reversible, decision-worthy).
   - `docs/decisions/order-response-cash-disclosure-fields.md` (Team D's choice to add 3 disclosure fields — reversible, decision-worthy).
   The Team A and Team C fixes are not really decisions — they're bug fixes with one obvious answer. Skip those.

6. `docs/bug-hunt/20260503T230405Z2601/ledger.jsonl` increment — append EXACTLY 4 JSON lines, one per real-broken finding. Schema (per Required Docs Updates block in `triage.md`):
```
{"iteration_ts":"20260503T230405Z2601","finding_id":"<short-slug>","category":"<tag>","summary":"<short>","scope_files":["<file1>","<file2>"],"team":"<A|B|C|D>","commit":"<merge-sha-on-main>"}
```
Use these finding_ids and categories (must match what the triage.json `items[]` use):
- `sim-time-tile-em-dash-artefact` (category: `dashboard-state-sync`) — Team A — commit 828003d
  scope_files: ["dashboard/styles.css","tests/e2e/journey-sim-time-tile.spec.ts"]
- `plugin-health-degraded-but-fills-succeed` (category: `dashboard-state-sync`) — Team B — commit cc20161
  scope_files: ["finlet/plugins/price_plugin.py","tests/plugins/test_price_plugin.py"]
- `settings-password-form-aria-recurrence` (category: `password-form-aria`) — Team C — commit b08ddb8
  scope_files: ["dashboard/settings.js","tests/e2e/journey-06-settings.spec.ts"]
- `order-cash-disclosure-undisclosed-delta` (category: `price-discrepancy`) — Team D — commit 3dc28c2
  scope_files: ["finlet/api/schemas/trade.py","finlet/api/services/trade_service.py","finlet/core/orders.py","dashboard/index.html","dashboard/app.js","tests/api/test_orders.py","tests/core/test_clock_step_integration.py"]

Validation hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should equal 51 (47 + 4).

7. Stage all artifacts under `docs/bug-hunt/20260503T230405Z2601/` — including `triage.md`, `triage.json`, `blind_report.json`, `blind_report.parsed.json`, `cleanup.log`, `isolation_warning.txt`, `plan.md`, `exec-trace.txt`, `team-prompts/*.md`, the four `team_*_verify.md`. (Some are already on main from team merges; others are still untracked. Stage the untracked ones.)

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` == 51.
- [ ] `jq -c '.iteration_ts' docs/bug-hunt/ledger.jsonl | tail -4` — all four lines `"20260503T230405Z2601"`.
- [ ] `jq -c '.commit' docs/bug-hunt/ledger.jsonl | tail -4` — four distinct merge SHAs (828003d, cc20161, b08ddb8, 3dc28c2 — exact 7-char prefixes are fine if they uniquely identify; full SHAs preferred).
- [ ] `git -C /Users/justnau/finlet diff --cached --stat` — every artifact under `docs/bug-hunt/20260503T230405Z2601/` is staged.
- [ ] `bash scripts/lint-trusted-types.sh` — zero violations.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Commit message: `docs: bug-hunt 20260503T230405Z2601 — close 4 fixes (A/B/C/D); LESSONS +4; ARCHITECTURE [touched|unchanged]; ledger +4` (replace bracketed phrase with what actually happened).
- DO NOT modify any non-docs file. Code is fixed; this commit is purely audit-trail + reusable-knowledge.
- DO NOT modify `docs/bug-hunt/pending_recurrences.jsonl` — Phase 5.5 owns that file.
- Write `docs/bug-hunt/20260503T230405Z2601/team_e_verify.md` with: ledger line-count delta, list of files touched, validation command output, and a one-line summary per LESSONS lesson added.

CRITICAL RULES (apply to every team):
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues
- Read the "Read these files first" list BEFORE writing any code
- Follow existing patterns in those files
- You MUST `git add` and `git commit` all your changes before finishing
- Your commit message must start with "docs: bug-hunt 20260503T230405Z2601" (this team's convention; matches /exec-plan's convention but lowercase prefix)
- Run the validation commands from your spec before finishing
- If validation fails, fix the issue and re-commit

When done, report: DONE + commit hash + validation results + ledger line count.
OR: BLOCKED + what went wrong.
