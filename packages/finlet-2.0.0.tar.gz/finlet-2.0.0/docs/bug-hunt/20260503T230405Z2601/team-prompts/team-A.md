You are Team A: Sim Time Tile Renders Without Em-Dash Artefact.

Working dir: your worktree (already isolated). Branch: yours. Base SHA: b99220ef5ad52303b4b8e3ccea549a258cc64578 (the orchestrator will reset your worktree to this before you start).

**Blocked by:** none — independent.

**Read these files first:**
- `docs/KNOWN_FAILURES.md` — these are pre-existing failures; do NOT report them as issues you caused.
- `dashboard/styles.css:778-810` — current `.stat-card` and `.stat-value` rules (recon confirms no explicit `hyphens` / `word-break` on `.stat-value`, so the em-dash is browser-default hyphenation kicking in on the monospace narrow-card layout)
- `dashboard/index.html:174` — `<div class="stat-value" id="sim-time">--</div>` (markup the value lands in)
- `dashboard/app.js:1903` — `document.getElementById('sim-time').textContent = formatDateTime(simTime);` (writer)
- `dashboard/app.js:2449-2457` — `formatDateTime()` returns `iso.replace('T', ' ').slice(0, 19) + ' UTC'`; recon confirms NO U+2014 in the source string — the em-dash is purely visual, inserted by the browser's auto-hyphenation
- `tests/e2e/journey-01-onboarding.spec.ts` (or whichever journey covers post-session-create dashboard render) — pattern for adding a Playwright assertion against the Sim Time tile content

**Files touched:**
- Modified: `dashboard/styles.css` — add (under `.stat-value`): `hyphens: none; word-break: keep-all; overflow-wrap: normal; white-space: nowrap;` plus an explicit `text-overflow: ellipsis; overflow: hidden;` for narrow viewports OR a min-width that lets the full datetime fit on one line. Pick whichever survives the existing dashboard layout test.
- Modified: `tests/e2e/journey-XX-*.spec.ts` (or new file `tests/e2e/journey-sim-time-tile.spec.ts`) — Playwright assertion: after session create, the `#sim-time` textContent does NOT contain U+2014, matches `/^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s+UTC$/`, and `browser_console_messages` has zero error/warning entries referencing the tile.

**Deliverable:** `#sim-time` renders the full ISO datetime on one logical line with zero CSS-injected hyphenation artefacts. Verified by Playwright e2e and the Phase 5.5 retest envelope (already in `triage.json` item #1).

**Validation:**
- [ ] `npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-sim-time-tile.spec.ts` (or whichever file holds the new test) passes locally — note: e2e tests need `finlet serve` running. If you can't run e2e locally, instead run the structural assertion via `node -e` against the rendered HTML and document why e2e was deferred.
- [ ] `bash scripts/lint-trusted-types.sh` (no `.innerHTML =` regression).
- [ ] Manual reasoning check: confirm the CSS rule will prevent hyphenation in narrow viewports.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing — worktree is cleaned up otherwise and your work is lost.
- Your commit message MUST start with `[Team A]:` (e.g., `[Team A]: prevent CSS auto-hyphenation in stat-value tiles`).
- DO NOT touch `dashboard/index.html` or `dashboard/app.js` unless you discover the em-dash is JS-injected (recon says it isn't). If you must, document the deviation in `team_a_verify.md`.
- DO NOT introduce a `hyphens: auto` rule anywhere.
- Write `docs/bug-hunt/20260503T230405Z2601/team_a_verify.md` with: file diffs (filename + line ranges), validation command output, and a manual-check note confirming the Sim Time tile visual.

CRITICAL RULES (apply to every team):
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues
- Read the "Read these files first" list BEFORE writing any code
- Follow existing patterns in those files
- You MUST `git add` and `git commit` all your changes before finishing
- Your commit message must start with "[Team A]:"
- Run the validation commands from your spec before finishing
- If validation fails, fix the issue and re-commit

When done, report: DONE + commit hash + validation results
OR: BLOCKED + what went wrong
