You are Team D: Order Fill Cash Math Becomes Reproducible (slippage_amount + total_cost Disclosure).

Working dir: your worktree (already isolated). Base SHA: b99220ef5ad52303b4b8e3ccea549a258cc64578 (the orchestrator will reset your worktree to this before you start).

**Blocked by:** none — independent.

**V1 contract is binding.** Read `docs/finlet-v1-scope.md` first. Commission=0 by design, slippage=10bps fixed. The fix is DISCLOSURE, not math. DO NOT introduce a non-zero commission. DO NOT change the slippage model.

**Read these files first (REQUIRED — V1 contract is binding):**
- `docs/KNOWN_FAILURES.md` — pre-existing failures; do NOT report as your issues.
- `docs/finlet-v1-scope.md` — confirms commission=0 by design and slippage=10bps fixed.
- `finlet/core/orders.py:207-210` — `_fill()` applies slippage to fill_price via `self._slippage_model.apply(price, order.side)`. Stores at 6-digit precision via `round(price * factor, 6)`. The displayed $560.90 is the round-2 of an actual $560.897.
- `finlet/core/slippage.py:57-61` — `FixedPercentageSlippage.apply()` formula. Required to compute `slippage_amount` correctly server-side.
- `finlet/core/portfolio.py:160` — `cost = round(quantity * price + commission, 2)` — this is where the $5,608.97 comes from (10 × 560.897 + 0 = 5608.97).
- `finlet/core/session.py:422-427` — order execution path that wires `portfolio.execute_buy(...)` with `fill_price` (slippage already applied) + `commission=self.config.commission`. Required to understand which value to surface.
- `finlet/api/schemas/trade.py:8-25` — current `OrderResponse` field set: `id, ticker, side, quantity, order_type, limit_price, stop_price, status, submitted_at, filled_at, fill_price, reasoning, reject_reason, time_in_force`. Missing: `slippage_amount`, `total_cost`, `commission`.
- `finlet/api/services/trade_service.py` — find the OrderResponse serializer (likely `_to_response` or similar). Required to populate the new fields.
- `dashboard/index.html:307` — `<th scope="col">Fill Price</th>` (current order log header set; one new column or one tooltip refactor needed).
- `dashboard/app.js:2151-2183` — order row render. Line 2177: `${o.fill_price != null ? formatCurrency(o.fill_price) : '--'}`. Required to surface the new fields.
- `tests/api/test_orders.py` — find an existing test that asserts the OrderResponse shape.
- `tests/core/test_clock_step_integration.py:201,213,305,318,364` — pattern for asserting fill_price.
- `dashboard/event-contract.md` — bus events; only relevant if the order-row render path changes its event subscription (likely no change needed).

**Files touched:**
- Modified: `finlet/api/schemas/trade.py` — add three optional fields to `OrderResponse`: `commission: float | None = None`, `slippage_amount: float | None = None`, `total_cost: float | None = None`. Document each in `Field(description=...)` so OpenAPI consumers see what they mean.
- Modified: `finlet/api/services/trade_service.py` — populate the three new fields. `slippage_amount` MUST be the actual slippage charged on this fill (i.e., `(fill_price − pre_slippage_mid_price) × quantity` for BUY, signed accordingly for SELL). `total_cost = fill_price * quantity + commission` for BUY; `total_cost = fill_price * quantity - commission` for SELL (this should match the cash delta exactly to within float-rounding). `commission = config.commission` (read from session; will be 0.0 in v1).
- Modified: `finlet/core/orders.py` — if the engine doesn't already retain the pre-slippage mid_price, add a minimal `slippage_amount` attribute or expose the value via a method so trade_service.py can compute slippage_amount/total_cost without re-running slippage. KEEP the engine change minimal.
- Modified: `dashboard/index.html` — add one new column to the order log: either `<th scope="col">Total Cost</th>` (preferred) or surface slippage_amount in a tooltip on the existing Fill Price cell. Pick whichever fits the existing column density.
- Modified: `dashboard/app.js:2151-2183` — extend the order row render to display the new column/tooltip. Use the existing `formatCurrency` helper.
- Modified: `tests/api/test_orders.py` — extend the existing OrderResponse-shape test: assert the three new fields exist and are non-null on a FILLED order. Add an integration test asserting cash delta == quantity × fill_price + commission to within 1¢ tolerance, AND that `total_cost` in the response matches the cash delta exactly.
- Modified: `tests/core/test_clock_step_integration.py` — extend one existing fill_price assertion to also check `slippage_amount > 0` (when slippage_bps > 0) and `total_cost ≈ fill_price * quantity` (when commission == 0).

**Risk register binding:**
- Write the integration test asserting cash-delta reconciliation BEFORE implementing the fields. Do not commit if the assertion fails.
- Verify the dashboard column doesn't break mobile layout (tooltip-on-existing-cell is the safer fallback if the table is already wide).

**Deliverable:** OrderResponse exposes commission + slippage_amount + total_cost. Dashboard order log renders enough information for a user to reconstruct cash math (`PRE − POST == total_cost` for BUY). Verified by the curl retest envelope in `triage.json` item #4 (the assertion suite is already written there — do not change it; just satisfy it).

**Validation:**
- [ ] `uv run pytest tests/api/test_orders.py tests/core/test_clock_step_integration.py tests/core/test_portfolio.py -x -q` — all pass including new assertions.
- [ ] `uv run ruff check finlet/api/schemas/trade.py finlet/api/services/trade_service.py finlet/core/orders.py finlet/core/portfolio.py` — zero warnings.
- [ ] `uv run mypy finlet/api/schemas/trade.py finlet/api/services/trade_service.py` — zero errors.
- [ ] `bash scripts/lint-trusted-types.sh` — no `.innerHTML =` regressions.
- [ ] `team_d_verify.md` includes the cash-reconciliation walkthrough (PRE, POST, fill_price, slippage_amount, total_cost — show the arithmetic).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Your commit message MUST start with `[Team D]:`.
- DO NOT change v1 commission default (must remain 0). The commission field becomes a disclosure, not a feature gate.
- DO NOT change the slippage model. DO NOT change `slippage_bps` default.
- DO NOT bypass the date ceiling enforcer or any plugin response invariant.
- All cross-component dashboard wiring goes through `window.finletBus`. Bare `.innerHTML =` writes under `dashboard/` MUST be wrapped in `trustedHTML(...)`. Run `bash scripts/lint-trusted-types.sh` before commit.
- Write `docs/bug-hunt/20260503T230405Z2601/team_d_verify.md` with: file diffs, the cash-reconciliation walkthrough (PRE, POST, fill_price, slippage_amount, total_cost — show the arithmetic), validation command output.

CRITICAL RULES (apply to every team):
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues
- Read the "Read these files first" list BEFORE writing any code
- Follow existing patterns in those files
- You MUST `git add` and `git commit` all your changes before finishing
- Your commit message must start with "[Team D]:"
- Run the validation commands from your spec before finishing
- If validation fails, fix the issue and re-commit

When done, report: DONE + commit hash + validation results
OR: BLOCKED + what went wrong
