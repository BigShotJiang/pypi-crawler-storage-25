# Team B Verify — Plugin Health Probe Stops Lying About Historical Data

**Iteration:** `20260503T230405Z2601`
**Base SHA:** `b99220ef5ad52303b4b8e3ccea549a258cc64578`
**Branch:** worktree branch (orchestrator-managed)
**Status:** DONE — implementation + regression tests + risk-binding test landed; full validation gate green.
**Recurrence:** YES — supersedes prior fix `76f4724` (bug-hunt `20260501T234103Z1a49` Team E).

## Why 76f4724 didn't close this

### What 76f4724 actually changed

`git show 76f4724 -- finlet/plugins/price_plugin.py` shows Team E's prior
fix added a brand-new "cold-start S3 reachability probe" that the prior
implementation lacked entirely. Specifically:

1. Introduced `PROBE_RECENT_DAYS = 7` and `PROBE_CACHE_TTL_SECONDS = 60.0`
   constants.
2. Added per-instance probe-cache fields
   (`_probe_last_ok_ts`, `_probe_last_reachable`, `_probe_last_recent_files`)
   invalidated on `initialize()`.
3. Replaced the trivial `_probe()` that only read `cache_dir.glob("*.parquet")`
   with a three-branch contract:
   - Fast path (cache files exist) → HEALTHY.
   - Cold-start path (cache empty) → cached `_check_s3_reachable()` call.
   - Cache-dir-missing path → DEGRADED with config-flavoured message.
4. Added `_render_probe_health(reachable, recent_files)` to translate
   `(bool, int)` into a `PluginHealth` value.
5. Added `_check_s3_reachable()` that loops **`PROBE_RECENT_DAYS=7` times**,
   each iteration calling `list_objects_v2` with
   `Prefix=f"{self._prefix}/{check_date.isoformat()}"` for
   `check_date = today - timedelta(days=days_back)` where
   `today = datetime.now(timezone.utc).date()` (real-world today). Stops
   at the first hit; returns `(True, 0)` if all 7 days have KeyCount=0;
   returns `(False, 0)` on `EndpointConnectionError` /
   `ClientError` / `BotoCoreError` / generic `Exception`.

### The root cause 76f4724 missed

The probe pinned reachability + recency to **real-world today**:

```python
today = datetime.now(timezone.utc).date()
for days_back in range(PROBE_RECENT_DAYS):
    check_date = today - timedelta(days=days_back)
    prefix = f"{self._prefix}/{check_date.isoformat()}"
    # list_objects_v2(Bucket=…, Prefix=prefix, MaxKeys=1)
```

Finlet is an **agentic trading evaluation harness** (per
`docs/ARCHITECTURE.md` and `MEMORY.md::project_finlet_positioning.md`).
A live session has a **simulated ceiling time** that is independent of
real-world today — sessions evaluate trades against historical
partitions (e.g., May 2025 simulated dates while real-world today is
May 2026). The engine's quote path scans
`ceiling_date - 7 days .. ceiling_date` (see `_query_quote` at
`finlet/plugins/price_plugin.py:336`), where `ceiling_date` is the
**simulated** ceiling, not real-world today.

The triage report for this iteration is explicit:

> "the engine clearly has data (orders fill at $560.90 against May-2025
> simulated dates) but the probe checks today−7d real-world dates,
> where there's no fresh data."

So 76f4724 closed the symptom ("disk-cache-only check is wrong") but
missed the deeper conflation: it replaced a too-narrow check (disk
cache only) with another too-narrow check (last-7-real-world-days
ingest only), instead of asking the right question — **"is there
ANY price data in the lake?"**. The engine's success path requires
historical partitions, not today's ingest. The probe was checking the
wrong invariant.

The prior fix's `"No price data available for the last 7 days. Run
ingestion first."` message is therefore a structural lie: it says
"there is no data" while the engine is actively filling orders against
historical data the probe never bothered to look at.

### Why "just add another `or` clause" wouldn't have fixed it

A naive patch on top of 76f4724 — e.g., extending the loop to 365 days
or adding "if cache_dir is empty BUT last query succeeded recently,
return HEALTHY" — would have re-papered over the same architectural
mistake (probe pinned to real-world recency, in conflict with the
engine's simulated-time data path). The **right** question is "does
the data lake contain anything?", and that question is answered by a
single unscoped `list_objects_v2` against the canonical prefix.

## Chosen option

**Option (1) from the spec:** drop the recent-window probe; check S3
reachability + at-least-one parquet under the canonical prefix.
**Rejected option (2)** (parameterise lookback to 365 days): still
encodes a real-world-recency assumption, just a more permissive one;
fails the same way for sessions running on dates older than one year.
**Rejected option (3)** (session-aware probe): would require touching
`finlet/plugins/base.py:246` (signature change) and
`finlet/api/routes_health.py:84-114` (pass session); the spec
explicitly says "avoid this if simpler options work", and option (1)
DOES work because the actual question — "is the data lake
populated?" — is session-independent.

The simplest fix that closes the root cause is to ask the right
question: "does the data lake contain anything under the canonical
prefix?". That answer is binary and session-independent, so it doesn't
need to know about ceiling time at all.

## Files modified

### 1. `finlet/plugins/price_plugin.py`

#### Constant retained for backwards-compatible test imports

`PROBE_RECENT_DAYS = 7` is kept (with a comment explaining its
deprecation) so that any out-of-tree test file that imports it for
documentation still works. The probe no longer references it.

#### `_probe()` docstring rewritten

The contract now explicitly calls out:

- The disk cache is performance-optional.
- S3 IS the canonical data source.
- Sessions evaluate against simulated ceiling dates that may be
  months/years stale relative to real-world today.
- The probe MUST NOT pin to real-world recency.
- Cold-start path issues a single cheap `list_objects_v2` against the
  canonical prefix (NOT a date-scoped subprefix).
- DEGRADED with "Run ingestion first" ONLY when the canonical prefix
  has ZERO parquet files (genuine "data lake never populated" case).

#### `_render_probe_health(reachable, recent_files)` updated

The `recent_files` parameter is repurposed as a **binary signal**
("any parquet under the canonical prefix exists?") instead of a count
of recent date-partitions. Messages updated:

- HEALTHY: `"OK — S3 reachable, price data available"` (no longer
  mentions a count of recent parquets).
- DEGRADED + S3 unreachable: unchanged
  (`"S3 unreachable: price data store cannot be listed. Check network
  connectivity and AWS credentials."`) — preserves the
  `routes_health._check_price_data_status` translator's
  `"unreachable"` / `"connect"` substring contract.
- DEGRADED + reachable + empty lake:
  `"No price data available. Run ingestion first."` (no longer
  mentions "the last N days").

#### `_check_s3_reachable()` rewritten

The 7-iteration date-scoped loop is replaced with **exactly one**
cheap `list_objects_v2` call against `f"{self._prefix}/"`
(unscoped — trailing slash to avoid name-stem-prefix collisions with
sibling prefixes). Returns `(True, 1)` if `KeyCount > 0`,
`(True, 0)` if `KeyCount == 0`, `(False, 0)` on any boto3 / botocore
exception. The boto3 exception envelope (EndpointConnectionError,
ClientError, BotoCoreError, generic Exception) is preserved
verbatim — the routes_health translator and existing
test_health_message_never_contains_bucket_name_when_unreachable
contract still hold.

### 2. `tests/plugins/test_price_plugin.py`

#### Existing tests updated for the new contract

- `test_price_plugin_health_check_cold_start_s3_reachable`: docstring
  updated; **added** an assertion that the single call's `Prefix`
  equals `f"{plugin._prefix}/"` (the canonical prefix), proving the
  fix uses the new code path and not a date-scoped subprefix.
- `test_price_plugin_health_check_cold_start_empty_recent_window`:
  docstring updated; **added** an assertion that the message does
  NOT contain `"for the last"` — pins the wording so a future
  regression that reintroduces the date-window probe trips this
  assertion.

#### New regression test (spec-required)

`test_price_plugin_health_check_historical_data_only_real_world_recent_empty`
reproduces the bug-hunt finding directly:

- Mocks `list_objects_v2` to return `KeyCount=0` for any
  date-scoped prefix and `KeyCount=1` for the unscoped canonical
  prefix. Under the prior 76f4724 implementation this would resolve
  to DEGRADED ("No price data available for the last 7 days. Run
  ingestion first."). Under this fix it resolves to HEALTHY.
- Asserts (a) HEALTHY, (b) message does NOT contain
  `"run ingestion"` or `"no price data available for the last"`,
  (c) the probe issued at least one unscoped list call.

#### New risk-register-binding test (spec-required)

`test_price_plugin_health_check_s3_unreachable_still_unhealthy`
asserts that S3 outage detection still works after dropping the
recency probe. Mocks `list_objects_v2` to raise
`EndpointConnectionError`; expects `status != HEALTHY`, then
specifically `status == DEGRADED` with `"unreachable"` or
`"connect"` in the message — ensuring the routes_health translator
still maps to `s3_unreachable`. Without this test, "drop the
recency probe" could regress into "always HEALTHY because we
stopped looking".

## Validation results

```
$ uv run pytest tests/plugins/test_price_plugin.py -x -q
....................................................                     [100%]
52 passed in 10.57s
```

```
$ uv run pytest tests/api/test_plugin_health.py -x -q
.........................                                                [100%]
25 passed, 1 warning in 4.66s
```

```
$ uv run pytest tests/plugins/ -x -q
[698 dots]
698 passed in 22.27s
```

```
$ uv run ruff check finlet/plugins/price_plugin.py tests/plugins/test_price_plugin.py
All checks passed!
```

```
$ uv run mypy finlet/plugins/price_plugin.py
Success: no issues found in 1 source file
```

All four spec validation gates green:

- [x] `uv run pytest tests/plugins/test_price_plugin.py -x -q` — 52
  passed (includes new regression + new s3-unreachable risk-binding).
- [x] `uv run ruff check finlet/plugins/price_plugin.py
  tests/plugins/test_price_plugin.py` — zero warnings.
- [x] `uv run mypy finlet/plugins/price_plugin.py` — zero errors.
- [x] `team_b_verify.md` documents the 76f4724 diff analysis and the
  root cause this fix closes.

## Live-site retest envelope (Phase 5.5)

Per the deliverable in the team prompt:

> GET `/v1/plugins/health` reports `price.status == "healthy"` whenever
> a market BUY against the active session's simulated date can fill,
> with a non-misleading message.

The orchestrator will run the curl retest envelope in `triage.json`
item #2 against the live deployment. The fix asserts:

1. After deploy, GET `/v1/plugins/health` returns `price.status =
   "healthy"` with message `"OK — S3 reachable, price data available"`
   (or the cache-fast-path equivalent when the disk cache has files).
2. The dashboard's plugin-health widget no longer shows the
   "Run ingestion first" banner when the engine can fill orders.
3. The previously-misleading `"No price data available for the last 7
   days"` copy never appears on a populated data lake.
