# Deploy Failure Handoff — bug-hunt 20260503T230405Z2601

> **Iteration:** `20260503T230405Z2601`
> **Failed run:** https://github.com/justnau1020/finlet/actions/runs/25295412755
> **Failed commit:** `a9a90a9` (HEAD of main; iteration's 4 fixes A/B/C/D + Team E docs are inside this SHA)
> **Failed job:** `e2e` — 23/145 chromium tests failed; deploy job skipped
> **Status of fixes on prod:** **NOT LIVE.** Patches merged to `main` but `deploy` job was skipped because `e2e` failed first.

---

## Pattern: this is the SECOND consecutive iteration where deploy was blocked by e2e

- Prior iteration `20260503T195318Z43db` (HEAD `a903b80`): 1 e2e test failed (`journey-06-settings:667 — settings profile save persists via API`). Handoff doc proposed two fixes: (1) make Phase 5.5a deploy-failure visible+blocking; (2) add thin pre-push smoke. The pre-push smoke shipped (`aaaf42f ci: add 3-journey e2e smoke to pre-push hook`). Yet THIS iteration's wider regression still slipped through — the smoke covers 3 journeys, not journey-06.

- This iteration: 23 e2e tests fail, of which **20 are journey-06-settings**. The pre-push smoke either (a) doesn't include journey-06 or (b) doesn't catch the cold-load init failure mode that CI hit.

The systemic gap from prior iteration is therefore **partially closed**: pre-push smoke exists, but it doesn't cover the regression pattern Teams keep introducing. The smoke needs to include journey-06-settings (cold load + nav-link active) since this is the third consecutive iteration where settings-page regressions slipped past local validation.

---

## What broke (specific)

```
journey-06-settings.spec.ts: 8/28 PASS, 20/28 FAIL
journey-17-csrf-hydration.spec.ts: 9/11 PASS, 2 FAIL (both #create-api-key-btn timeouts — settings element)
journey-sim-time-tile.spec.ts: 1/2 PASS, 1 FAIL (Team A's hard-coded datetime — see "Test spec bug" below)
```

The 22 settings/csrf failures all share one signature: **a settings-page element fails to become visible after timeout (10s for nav, 60s for create-key button)**. The very first test fails at `a.header-nav-link--active[href="settings.html"]` not visible, which means the active-nav class never gets applied — settings.html init is failing somewhere mid-bootstrap.

**Compare with prior deploy** (`b99220e`, pre-iteration HEAD):
- Run 25293348944 → journey-06-settings: 27/28 PASS, 1 FAIL (only the line 667 test from prior iteration)
- Run 25295412755 → journey-06-settings: 8/28 PASS, 20/28 FAIL

Conclusion: **this iteration introduced 19 new settings-page failures.** Almost certainly a JS error during settings.html init that halts page boot.

### Test spec bug (Team A — non-blocking, separate issue)

`journey-sim-time-tile.spec.ts:118` hardcodes `expect(text).toBe('2024-06-15 13:42:07 UTC')` but the runtime session emits `'2025-05-26 00:00:03 UTC'`. The fix it covers (CSS no-hyphenation rule on `.stat-value`) is verified by the sibling test at line 142 which PASSES — so the user-facing bug IS fixed; only the test assertion is bad. Team A wrote the assertion against a fixed datetime instead of pulling from the session API. Easy follow-up edit: replace the hardcoded comparison with a regex shape check (already present at line 117) and drop the strict equality.

---

## Suspected culprit (regression — needs bisect)

Listed by likelihood:

### Hypothesis 1 — Team D — `dashboard/app.js` + `dashboard/index.html`

Team D added a Total Cost column to the order log table (colspan 8 → 9). The table is on dashboard.html, not settings.html, BUT both pages load `dashboard/app.js`. If Team D's app.js change has any module-init code that throws on settings.html (where the order-log DOM doesn't exist), shared init halts → settings.js never finishes setting up event handlers → nav-link active class never set → first journey-06 test fails.

**How to test:**
```bash
git -C /Users/justnau/finlet checkout 0e54b8d^  # parent of Team D worktree commit
bash scripts/dev-server.sh &
SERVE_PID=$!
sleep 5
npx playwright test --config=tests/e2e/playwright.config.ts \
  tests/e2e/journey-06-settings.spec.ts:18 --project=chromium
kill $SERVE_PID
git -C /Users/justnau/finlet checkout main
```
If that PASSES, Team D is the culprit.

### Hypothesis 2 — Team C — `dashboard/settings.js`

Team C's diff is +19 lines, all inside the `loadPlugins()` template literal — a hidden username peer per plugin card. The change is gated to `loadPlugins()`, which only runs when the Plugins tab is selected. The journey-06 first failing test is on the Profile tab (default), which doesn't call `loadPlugins()`. So this should NOT be the culprit. But cross-check by reverting.

### Hypothesis 3 — Team A — `dashboard/styles.css`

CSS-only change to `.stat-value`. Cannot cause JS init failure. Lowest likelihood.

### Hypothesis 4 — Team B — `finlet/plugins/price_plugin.py`

Server-side only. Cannot cause client-side init failure. Lowest likelihood.

---

## Two ways forward (pick one before next iteration)

1. **Cheap path — fix-forward by reverting + re-merging the culprit team after isolating the breakage.** Bisect via Hypothesis 1 first. Whatever team broke it gets a `[Team X-fix]:` follow-up commit on main with the regression closed. Re-fire deploy. Patches go live.

2. **Right path — add journey-06-settings (cold load + first 3 tests) to the pre-push e2e smoke.** This is what prior iteration's handoff already proposed. Each consecutive iteration where journey-06 regresses without local detection is one more data point that the 3-journey smoke is too narrow. Settings page is touched by every dashboard team — it needs to be in the smoke.

I'd do BOTH — (1) to unblock this deploy now, (2) to prevent the next one. (2) costs maybe 90s on pre-push hook for a regression that has now blocked deploy on 2/3 of the last 3 iterations.

---

## Phase 5.5 retest: SKIPPED

Per skill: "we do not infer ineffectiveness from a failed deploy." `pending_recurrences.jsonl` was NOT appended.

The 4 patches in this iteration (A/B/C/D) cannot be verified live because they aren't live. Their LOCAL validation passed (5 teams' verify docs all show green — see `team_{a,b,c,d,e}_verify.md`). Their PROD verdict is deferred until deploy succeeds.
