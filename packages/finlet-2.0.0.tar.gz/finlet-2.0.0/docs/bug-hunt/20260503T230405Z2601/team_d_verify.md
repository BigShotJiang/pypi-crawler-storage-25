# Team D Verification — OrderResponse cash-disclosure contract

**Bug-hunt iteration:** `20260503T230405Z2601`
**Triage finding:** #4 — "Order fill cash math does not reconcile in any user-visible field"
**Base SHA:** `b99220ef5ad52303b4b8e3ccea549a258cc64578`

## Summary

Surfaced three new fields on `OrderResponse` so a user can reconstruct the cash math from the order response alone:

- `commission` — session config (v1: 0.0 by design)
- `slippage_amount` — absolute slippage charged on this fill, in dollars
- `total_cost` — signed cash impact (`fill_price × quantity ± commission`)

This is a **disclosure** fix, not a math change: V1 contract is binding (`commission == 0`, `slippage_bps == 10` default fixed). The bug was that the cash delta was real (slippage was real), but no field on the response told the user what it was.

## Files modified

| File | Change |
|---|---|
| `finlet/core/orders.py` | Added `slippage_amount: float \| None` field on `Order` model, populated in `_fill()` |
| `finlet/api/schemas/trade.py` | Added `commission`, `slippage_amount`, `total_cost` to `OrderResponse` with `Field(description=...)` |
| `finlet/api/services/trade_service.py` | `order_dict(order, *, session=None)` now enriches the dict with the three disclosure fields |
| `finlet/api/routes_trade.py` | Pass `session=session` to `order_dict` calls |
| `dashboard/index.html` | Added `<th>Total Cost</th>` column + abbr tooltip; updated empty-state colspan 8→9 |
| `dashboard/app.js` | Render `total_cost` cell with breakdown tooltip (gross + commission + slippage) |
| `tests/api/test_orders.py` | New `TestOrderResponseCashDisclosure` class — 4 tests including the cash-delta reconciliation integration test (written BEFORE implementation per risk register) |
| `tests/core/test_clock_step_integration.py` | New `TestOrderCashDisclosureWithSlippage` class — 1 test asserting `slippage_amount > 0` when `slippage_bps > 0` and `total_cost ≈ fill_price * quantity` when `commission == 0` |

## Cash-reconciliation walkthrough

Reproducing the exact triage scenario (BUY 10 SPY, displayed fill price $560.90, observed cash deduction $5,608.97) with the new disclosure fields:

```
PRE cash (GET /portfolio.cash):       $100,000.00
POST cash (GET /portfolio.cash):       $94,391.03
cash delta (PRE − POST):                $5,608.97  ← was unexplained before this fix

Order response (after fix):
  fill_price:                           $560.897000   (server precision; displayed as $560.90)
  quantity:                             10
  commission:                           $0.00         (v1 contract; disclosed for transparency)
  slippage_amount:                      $5.6034        (10 bps × $560.34 pre-slippage × 10 shares)
  total_cost:                           $5,608.97     ← matches cash delta exactly

RECONCILIATION:
  total_cost == cash delta:              TRUE   (within 1¢)
  total_cost == fill_price × qty + commission:
                                         TRUE   ($560.897 × 10 + 0 = $5,608.97)
```

The previously-mysterious −$0.03 difference vs the user's mental model (`10 × $560.90 = $5,609.00`) is just the rounding gap between the displayed `fill_price` ($560.90, round-2) and the engine's stored `fill_price` ($560.897, round-6). The engine math is consistent; the missing piece was disclosure.

For BUY: `cash_delta = total_cost = fill_price × quantity + commission`.
For SELL: `−cash_delta = total_cost = fill_price × quantity − commission` (i.e. proceeds credited).

## Engine internals

`OrderBook._fill(order, price, sim_time)` now records `order.slippage_amount` at fill time:

```python
fill_price = self._slippage_model.apply(price, order.side)
order.fill_price = fill_price
if order.side == OrderSide.BUY:
    order.slippage_amount = round((fill_price - price) * order.quantity, 6)
else:
    order.slippage_amount = round((price - fill_price) * order.quantity, 6)
```

This is the absolute dollar slippage charged — positive for both sides (cost increase for BUY, proceeds reduction for SELL). The slippage model itself is untouched.

`trade_service.order_dict(order, *, session=...)` derives `total_cost` from `fill_price × quantity ± commission` (signed by side) so the engine's cash math is reproducible by any consumer of the order response.

## Validation results

```
$ uv run pytest tests/api/test_orders.py tests/core/test_clock_step_integration.py tests/core/test_portfolio.py -x -q
96 passed, 1 warning in 27.79s

$ uv run ruff check finlet/api/schemas/trade.py finlet/api/services/trade_service.py finlet/core/orders.py finlet/core/portfolio.py
All checks passed!

$ uv run mypy finlet/api/schemas/trade.py finlet/api/services/trade_service.py
Success: no issues found in 2 source files

$ bash scripts/lint-trusted-types.sh
lint-trusted-types: OK — 0 bare HTML-sink write sites under dashboard/.
```

Wider regression sweep (no new failures introduced):

```
$ uv run pytest tests/api/ tests/leaderboard/ -q
1481 passed in 234.96s

$ uv run pytest tests/core/ -q
451 passed in 30.25s

$ uv run pytest tests/plugins/ -q
698 passed in 23.00s

$ node --test tests/dashboard/*.spec.js
71 pass, 0 fail
```

## Risk-register satisfaction

- [x] **Test-first**: integration test asserting cash-delta reconciliation was written and committed FAILING (TDD red) before implementation. Implementation drove the suite green; the failing-state was confirmed.
- [x] **Mobile layout**: Total Cost column added; the orders table is inside `.table-wrap.scrollable` (overflow:auto), so an extra column does not break narrow viewports — it scrolls. The cell uses an `<abbr>` header tooltip + cell-level `title=` for breakdown disclosure (gross / commission / slippage).
- [x] **V1 contract preserved**: commission default unchanged (0.0), slippage model unchanged, slippage_bps default unchanged (10), date-ceiling enforcer untouched.
- [x] **Bus contract unchanged**: no new dashboard event names; no `addEventListener('finlet:...')` regressions; no bare `.innerHTML =` writes outside `trustedHTML(...)`.
