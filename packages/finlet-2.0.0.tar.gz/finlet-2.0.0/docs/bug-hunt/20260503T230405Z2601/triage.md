## Broken (will be fixed this iteration)
- Sim Time metric card renders date with literal em-dash artefact ('2025-05-—' on its own line) — rendered string contradicts source date format [evidence: "Sim Time card renders as '2025-05-—' / '03' / '00:00:00' / 'UTC' on separate lines. The em-dash artefact in '2025-05-—' suggests a CSS hyphenation or word-break rule is incorrectly fragmenting the date string."] [scope hint: dashboard/index.html, dashboard/styles.css, dashboard/app.js]
- Price plugin Plugin Health panel says 'degraded — No price data available for the last 7 days. Run ingestion first.' yet a BUY 10 SPY filled at $560.90 — UI state ≠ backend state (recurrence of plugin-health-degraded-but-fills-succeed) [evidence: "Plugin Health panel shows: 'price — degraded — No price data available for the last 7 days. Run ingestion first.' Despite this, BUY 10 SPY filled immediately at $560.90. The health check appears to check for data in the last 7 real-world days (Apr 26–May 3 2026) while the simulation date is May 2025, where historical data clearly exists."] [scope hint: finlet/plugins/price_plugin.py, finlet/api/routes_health.py]
- Settings plugins page emits 9 identical browser accessibility console errors — password inputs lack associated username fields (recurrence of settings-password-no-form shape) [evidence: "Browser console (verbose level, all:true): 9 identical messages — '[VERBOSE] [DOM] Password forms should have (optionally hidden) username fields for accessibility: https://goo.gl/9p2vKq @ https://finlet.dev/settings.html:0'. All 8 plugin API key inputs are likely typed as password fields without a paired username input"] [scope hint: dashboard/settings.html, dashboard/settings.js]
- BUY 10 SPY @ $560.90 deducted $5,608.97 (expected $5,609.00) with no commission/slippage line item disclosed in the order log or UI — undisclosed delta makes cash math irreproducible [evidence: "Expected cash deduction: 10 × $560.90 = $5,609.00. Actual deduction: $100,000.00 − $94,391.03 = $5,608.97. Difference: −$0.03. No commission line item shown in the order log, no fee disclosure in the UI."] [scope hint: finlet/core/orders.py, finlet/core/portfolio.py, finlet/api/services/trade_service.py, dashboard/trade-ticket.js]

## Logged (not actioned)
- Finlet benchmark MCP tool not registered — clean-room launcher subprocess (env -i) does not see the `finlet` CLI on PATH; same classification as iteration 20260503T195318Z43db [classification: working-as-designed]
- Three dialogs (Session Details, Trade Ticket, onboarding wizard) mounted in DOM simultaneously after first login — Session Details is hidden but present with '--' values [classification: annoying]
- API Key textbox + Save button rendered for plugins that need no key (fundamentals_s3, price, econ) [classification: annoying]
- Uninitialized plugins (finnhub, fred, edgar) show 'not initialized' with no Get-API-Key link, doc URL, or placeholder [classification: annoying]
- Settings sidebar has both 'API Keys & Security' and 'API Keys' as separate items — confusing labels [classification: annoying]
- 'Test Connection' button shows no inline feedback after click; status paragraph unchanged, no toast/spinner [classification: annoying]
- Clock starts FROZEN with no onboarding callout pointing at the unfreeze action [classification: annoying]
- Root URL `/` redirects to `/landing.html` instead of serving as canonical landing path [classification: annoying]
- 'Conservative ETF' template description ('SPY, BND, GLD') implies universe restriction but Trade Ticket accepts any ticker without warning [classification: annoying]
- No 'Get Quote' / fill-price preview before order submission [classification: nice-to-have]
- Plugin Health rows on dashboard are not deep-linkable to the matching Settings > Plugins row [classification: nice-to-have]
- 'Submit to Leaderboard' has no preview/confirmation/minimum-session-duration gate [classification: nice-to-have]
- No dark/light mode toggle visible despite an Appearance settings section [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260503T230405Z2601 — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. `docs/bug-hunt/20260503T230405Z2601/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log,
   deploy_status.txt, retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260503T230405Z2601","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline (see
   Phase 5.5c). Team D MUST stage the file. If a refactor verdict pruned entries
   this iteration, Team D MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`
   (the audit log of resolved signals).

Team D's commit message must reference iteration 20260503T230405Z2601 and name which docs were
touched (e.g., "docs: bug-hunt 20260503T230405Z2601 — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
