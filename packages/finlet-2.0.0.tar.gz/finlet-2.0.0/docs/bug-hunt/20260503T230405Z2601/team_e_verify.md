# Team E Verify — Docs + Ledger Close-Out

**Iteration:** `20260503T230405Z2601`
**Branch:** `main` (running directly, not a worktree)
**Status:** DONE — docs landed, ledger appended +4, two new decision records written, ARCHITECTURE.md touched in 5 places, LESSONS.md gained 4 reusable rules.

## Ledger line-count delta

```
$ wc -l docs/bug-hunt/ledger.jsonl
       51 docs/bug-hunt/ledger.jsonl
```

Pre-edit: 47. Post-edit: 51. Delta: +4 (one per real-broken finding).

## Validation command output

```
$ jq -c '.iteration_ts' docs/bug-hunt/ledger.jsonl | tail -4
"20260503T230405Z2601"
"20260503T230405Z2601"
"20260503T230405Z2601"
"20260503T230405Z2601"

$ jq -c '.commit' docs/bug-hunt/ledger.jsonl | tail -4
"828003d"
"cc20161"
"b08ddb8"
"3dc28c2"

$ jq -c '.finding_id, .category, .team' docs/bug-hunt/ledger.jsonl | tail -12
"sim-time-tile-em-dash-artefact"
"dashboard-state-sync"
"A"
"plugin-health-degraded-but-fills-succeed"
"dashboard-state-sync"
"B"
"settings-password-form-aria-recurrence"
"password-form-aria"
"C"
"order-cash-disclosure-undisclosed-delta"
"price-discrepancy"
"D"

$ bash scripts/lint-trusted-types.sh
lint-trusted-types: OK — 0 bare HTML-sink write sites under dashboard/.
```

All four validation gates green:
- [x] `wc -l docs/bug-hunt/ledger.jsonl` == 51 (47 + 4)
- [x] `jq -c '.iteration_ts' ... | tail -4` — all four lines `"20260503T230405Z2601"`
- [x] `jq -c '.commit' ... | tail -4` — four distinct merge SHAs (`828003d`, `cc20161`, `b08ddb8`, `3dc28c2`)
- [x] `bash scripts/lint-trusted-types.sh` — zero violations

## Files touched

### Docs (modified)

- `docs/REMAINING_TASKS.md` — added "Bug Hunt 20260503T230405Z2601 — Closed" subsection (above the prior `20260503T195318Z43db` close-out, mirroring the existing pattern). Four bullets, one per finding, each citing the resolving merge SHA + worktree commit + category + one-paragraph summary.
- `docs/LESSONS.md` — appended a new section "Bug Hunt 20260503T230405Z2601 — CSS Auto-Hyphenation, Probe-Question Wrong-Layer, Password-Form Username-Peer, Cash-Disclosure Reconcile (2026-05-03)" with four reusable lessons (one per real-broken finding). Each lesson is phrased as a rule, not a diff recap, with explicit lint candidates and audit pass instructions.
- `docs/ARCHITECTURE.md` — five touchpoints:
  1. PricePlugin row in the plugin table (`Health probe (post bug-hunt 20260503T230405Z2601 Team B, supersedes the 20260501T234103Z1a49 Team E real-world-recency loop)`) — rewrote the probe contract paragraph in place to reflect reachability-only, session-time-independent question.
  2. Section "4. Order System" — added a new paragraph after the Slippage model paragraph documenting the three new disclosure fields on `OrderResponse` + `Order.slippage_amount`, with explicit V1-contract-preserved language.
  3. Dashboard surface item 2 (`index.html`) — annotated the order log description with the new Total Cost column + colspan 8→9 + breakdown tooltip note.
  4. Shared-infrastructure section — new bullet documenting the defensive no-hyphenation contract on `.stat-value` (the four-property chain + ellipsis fallback + audit guidance).
  5. Shared-infrastructure section — new bullet documenting the Settings plugin-card hidden `autocomplete=username` peer pattern + form-dirty-tracker exclusion.

### Decisions (new)

- `docs/decisions/plugin-health-probe-reachability-only.md` — supersedes the prior `price-plugin-health-probe-s3-reachability.md` (2026-05-01) decision record. Documents the architectural shift from "real-world-recency loop" to "reachability + any-data binary question". Rejection rationale for Options 2 (parameterise lookback) and 3 (session-aware probe). Risk-binding test reasoning.
- `docs/decisions/order-response-cash-disclosure-fields.md` — three new optional fields on `OrderResponse` (commission, slippage_amount, total_cost) plus `Order.slippage_amount`. V1 contract binding rationale. Five rejected alternatives (round at engine, doc-only, round total_cost only, total_cost-only field, precision flag). TDD red-phase commitment for the cash-reconciliation integration test.

### Ledger

- `docs/bug-hunt/ledger.jsonl` — appended 4 lines (one per finding). Schema matches existing entries (iteration_ts / finding_id / category / summary / scope_files / team / commit). All four `iteration_ts` values match `"20260503T230405Z2601"`. Categories: `dashboard-state-sync` (Teams A, B), `password-form-aria` (Team C), `price-discrepancy` (Team D).

### Untracked iteration artifacts staged

The following files were on disk but untracked at start of Team E. Staged in the same commit as the docs changes:

- `docs/bug-hunt/20260503T230405Z2601/blind_report.json`
- `docs/bug-hunt/20260503T230405Z2601/blind_report.parsed.json`
- `docs/bug-hunt/20260503T230405Z2601/blind_stderr.log`
- `docs/bug-hunt/20260503T230405Z2601/blind_stdout.log`
- `docs/bug-hunt/20260503T230405Z2601/cleanup.log`
- `docs/bug-hunt/20260503T230405Z2601/exec-trace.txt`
- `docs/bug-hunt/20260503T230405Z2601/isolation_warning.txt`
- `docs/bug-hunt/20260503T230405Z2601/plan.md`
- `docs/bug-hunt/20260503T230405Z2601/triage.json`
- `docs/bug-hunt/20260503T230405Z2601/triage.md`
- `docs/bug-hunt/20260503T230405Z2601/team-prompts/team-A.md`
- `docs/bug-hunt/20260503T230405Z2601/team-prompts/team-B.md`
- `docs/bug-hunt/20260503T230405Z2601/team-prompts/team-C.md`
- `docs/bug-hunt/20260503T230405Z2601/team-prompts/team-D.md`
- `docs/bug-hunt/20260503T230405Z2601/team-prompts/team-E.md`

The four `team_*_verify.md` files (Teams A/B/C/D) were already committed via their respective merge commits (`828003d`, `cc20161`, `b08ddb8`, `3dc28c2`). This file (`team_e_verify.md`) is added in Team E's commit.

### Files NOT touched (per spec)

- `docs/bug-hunt/pending_recurrences.jsonl` — left empty, untouched. Phase 5.5 owns this file.
- `docs/KNOWN_FAILURES.md` — pre-flight reported zero pre-existing failures resolved this iteration; confirmed by re-reading the file (no rows match this iteration's fix scope: price_plugin probe, settings password forms, sim-time tile, OrderResponse). Left alone per spec; commit message notes "no failures resolved".
- All non-docs files. Code is fixed by Teams A/B/C/D; Team E is purely audit-trail + reusable knowledge.

## Lessons added (one-line summary per lesson)

1. **CSS auto-hyphenation prevention on metric tiles (Team A):** every `.stat-value` / `.metric-value` / `.tile-value` rule MUST pin the four-property contract `hyphens: none; word-break: keep-all; overflow-wrap: normal; white-space: nowrap;` because Chromium's auto-hyphenation engine paints visual hyphen glyphs into mid-word breaks of unbreakable strings even when the source contains no Unicode dashes.
2. **Probe-question alignment with engine data path (Team B):** a health probe that pins reachability/recency to real-world today is a structural lie when the engine operates on simulated time — collapse the probe to a session-independent reachability-only question (`is the data lake populated AT ALL?`) rather than escalating real-world-recency loops, and pair with a risk-binding test against `EndpointConnectionError` so the fix doesn't regress into "always HEALTHY because we stopped looking".
3. **Password-form Chromium two-warning family (Team C):** wrapping `<input type=password>` in a `<form>` is necessary but NOT sufficient — Chromium's password-autofill heuristic emits TWO distinct verbose warnings, and a complete fix needs BOTH a form ancestor AND a sibling hidden `<input autocomplete="username">` peer (with a semantic value, not the literal `"username"` string) inside that form.
4. **Server-computed delta disclosure (Team D):** every server-computed delta the user-facing UI presents MUST be reconcilable from the API response alone — if the engine rounds a value for display while computing math at higher precision, expose the precision-bridging fields (commission, slippage_amount, total_cost) on the response rather than changing the model defaults to make the displayed math "work out", and write the cash-reconciliation integration test FIRST (TDD red) before implementing the disclosure.

## Notes for Phase 5.5

- The orchestrator now runs Phase 5.5 (deploy wait + retest envelope from `triage.json`) against the live `finlet.dev` deployment.
- Retest envelopes per finding:
  - **#1 Sim Time tile** — Playwright `tests/e2e/journey-sim-time-tile.spec.ts` against the live site; both tests should pass once the new CSS lands.
  - **#2 Plugin Health** — `curl -s https://finlet.dev/v1/plugins/health` should report `price.status == "healthy"` whenever a market BUY against any active session's simulated date can fill, with message `"OK — S3 reachable, price data available"` (or the cache-fast-path equivalent).
  - **#3 Settings password forms** — `mcp__playwright__browser_console_messages` captured on a cold-load of `https://finlet.dev/settings.html#plugins` should report zero entries matching `/Password forms should have.*username fields/i`.
  - **#4 Order cash disclosure** — submit a BUY through the live API; `OrderResponse` must include `commission`, `slippage_amount`, `total_cost`; `total_cost` must reconcile with `cash_before - cash_after` within 1 cent.
- All four findings have full Playwright + pytest coverage on the worktree-merged commits. Phase 5.5 verifies the deploy reached production, not the underlying logic.
