# Bug Hunt 20260503T230405Z2601 — Execution Plan

> **Status:** COMPLETED 2026-05-03 — all 5 teams (A/B/C/D/E) merged.
> Generated from `docs/bug-hunt/20260503T230405Z2601/triage.md`. Last updated: 2026-05-03

## Constraints

- **Scope:** 4 real-broken findings + mandatory docs commit. No annoying/nice items in scope.
- **V1 spec (binding for Team D):** commission=0 by design, slippage=10 bps fixed (configurable). DO NOT introduce a non-zero commission. The cash discrepancy is a **disclosure** issue (slippage_amount and total_cost not exposed), not a math bug. Source: `docs/finlet-v1-scope.md`.
- **Forward signals (binding for Team B and Team C):** two of the four broken items are RECURRENCES of patches that landed and didn't close the root cause:
  - `plugin-health-degraded-but-fills-succeed` (last fixed at commit `76f4724`, iter `20260501T234103Z1a49`)
  - `settings-password-no-form` (last fixed at commit `ce5fa52`, iter `20260501T172055Z127b`)
  Each team MUST `git show <sha>` and explicitly note in their verify report what changed in that prior fix and why this iteration's fix closes the root cause (not the same surface symptom).
- **Module boundaries:** team workers span departmental boundaries (Team D touches engine + api + dashboard). This is acceptable; the single-worker-per-worktree model coordinates changes across departments without merge coordination.
- **Worktree isolation:** every worker agent runs in `isolation: "worktree"` per `/exec-plan` defaults. Each MUST `git add` + `git commit` before finishing or work is lost.

## File Conflict Table

No file conflicts among the four fix teams (A/B/C/D). Team E (docs) writes only `docs/**` and the ledger.

| File | Touched by Teams |
|------|------------------|
| `dashboard/styles.css` | A |
| `dashboard/index.html` | D (order log table) |
| `dashboard/app.js` | D (order row render) |
| `dashboard/settings.js` | C |
| `finlet/plugins/price_plugin.py` | B |
| `finlet/plugins/base.py` | B (only if health protocol signature changes) |
| `finlet/api/routes_health.py` | B (only if response shape changes) |
| `finlet/api/schemas/trade.py` | D |
| `finlet/api/services/trade_service.py` | D |
| `finlet/core/orders.py` | D |
| `finlet/core/portfolio.py` | D |
| `tests/plugins/test_price_plugin.py` | B |
| `tests/api/test_orders.py` | D |
| `tests/e2e/journey-*.spec.ts` | A, C, D (different files per team) |
| `docs/REMAINING_TASKS.md`, `docs/LESSONS.md`, `docs/ARCHITECTURE.md`, `docs/KNOWN_FAILURES.md`, `docs/bug-hunt/20260503T230405Z2601/**`, `docs/bug-hunt/ledger.jsonl`, `docs/bug-hunt/pending_recurrences.jsonl` | E |

## Dependency Graph

- **Team A** (independent) — Sim Time CSS fix, can start immediately.
- **Team B** (independent) — Plugin health logic, can start immediately.
- **Team C** (independent) — Settings password form fix, can start immediately.
- **Team D** (independent) — Cash math disclosure (engine + api + dashboard), can start immediately.
- **Team E** (blocked by A + B + C + D merging) — needs commit SHAs for the ledger.

## Critical Path

Team D → Team E. Team D is the largest (5–7 files spanning 3 departments) and a hard prerequisite for E's ledger entry.

A, B, C can complete in any order parallel to D's execution.

---

## Teams

### Team A: Sim Time Tile Renders Without Em-Dash Artefact

**Blocked by:** none — independent.

**Read these files first:**
- `dashboard/styles.css:778-810` — current `.stat-card` and `.stat-value` rules (recon confirms no explicit `hyphens` / `word-break` on `.stat-value`, so the em-dash is browser-default hyphenation kicking in on the monospace narrow-card layout)
- `dashboard/index.html:174` — `<div class="stat-value" id="sim-time">--</div>` (markup the value lands in)
- `dashboard/app.js:1903` — `document.getElementById('sim-time').textContent = formatDateTime(simTime);` (writer)
- `dashboard/app.js:2449-2457` — `formatDateTime()` returns `iso.replace('T', ' ').slice(0, 19) + ' UTC'`; recon confirms NO U+2014 in the source string — the em-dash is purely visual, inserted by the browser's auto-hyphenation
- `tests/e2e/journey-01-onboarding.spec.ts` (or whichever journey covers post-session-create dashboard render) — pattern for adding a Playwright assertion against the Sim Time tile content

**Files touched:**
- Modified: `dashboard/styles.css` — add (under `.stat-value`): `hyphens: none; word-break: keep-all; overflow-wrap: normal; white-space: nowrap;` plus an explicit `text-overflow: ellipsis; overflow: hidden;` for narrow viewports OR a min-width that lets the full datetime fit on one line. Pick whichever survives the existing dashboard layout test.
- Modified: `tests/e2e/journey-XX-*.spec.ts` (or new file `tests/e2e/journey-sim-time-tile.spec.ts`) — Playwright assertion: after session create, the `#sim-time` textContent does NOT contain U+2014, matches `/^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s+UTC$/`, and `browser_console_messages` has zero error/warning entries referencing the tile.

**Deliverable:** `#sim-time` renders the full ISO datetime on one logical line with zero CSS-injected hyphenation artefacts. Verified by Playwright e2e and the Phase 5.5 retest envelope (already in `triage.json` item #1).

**Validation:**
- [ ] `uv run pytest tests/e2e/journey-sim-time-tile.spec.ts` (or whichever file holds the new test) passes locally.
- [ ] `bash scripts/lint-trusted-types.sh` (no `.innerHTML =` regression).
- [ ] Manual: open `dashboard/index.html` locally with a created session — visual check that the Sim Time tile renders the full datetime as one line, no em-dash, no character fragmentation.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing — worktree is cleaned up otherwise and your work is lost.
- DO NOT touch `dashboard/index.html` or `dashboard/app.js` unless you discover the em-dash is JS-injected (recon says it isn't). If you must, document the deviation in `team_a_verify.md`.
- DO NOT introduce a `hyphens: auto` rule anywhere.
- Write `docs/bug-hunt/20260503T230405Z2601/team_a_verify.md` with: file diffs (filename + line ranges), validation command output, and a manual-check note confirming the Sim Time tile visual.

---

### Team B: Plugin Health Probe Stops Lying About Historical Data

**Blocked by:** none — independent.

**Read these files first:**
- `finlet/plugins/price_plugin.py:797-822` — current `health_check()` docstring (states design intent: reachability-only, NOT date-window awareness — but the implementation contradicts this)
- `finlet/plugins/price_plugin.py:843-859` — `health_check()` body. Calls `_check_s3_reachable()` then `_render_probe_health()`. Has NO session/ceiling context.
- `finlet/plugins/price_plugin.py:861-895` — `_render_probe_health()`. Returns DEGRADED with `"No price data available for the last {PROBE_RECENT_DAYS} days. Run ingestion first."` when S3 reachable but the recent-window prefix has zero parquet files. THIS IS THE FALSE POSITIVE — the engine clearly has data (orders fill at $560.90 against May-2025 simulated dates) but the probe checks today−7d real-world dates, where there's no fresh data.
- `finlet/plugins/base.py:246` — `async def health_check(self) -> PluginHealth:` (current protocol; no session/ceiling argument)
- `finlet/api/routes_health.py:84-114` — `/plugins/health` route handler; calls `registry.health_check_all()` with no session context
- `git show 76f4724 --stat` AND `git show 76f4724 -- finlet/plugins/price_plugin.py` — what the prior recurrence fix actually changed; required reading before designing this fix
- `tests/plugins/test_price_plugin.py` — current health_check coverage (recon notes this exists but doesn't assert date-window awareness)

**Files touched:**
- Modified: `finlet/plugins/price_plugin.py` — replace the "last 7 real-world days" probe with a probe that succeeds whenever ANY parquet exists for the relevant historical lookback window (e.g., last 90 days, OR check the most recent partition prefix that has data, OR drop the recency assertion and report DEGRADED only when S3 itself is unreachable). The choice is the agent's, but the message MUST stop lying — it MUST NOT say "Run ingestion first" when ingestion is irrelevant (S3 has historical data; sessions read from sim-date partitions). Concrete options ranked: (1) drop recent-window probe, just check S3 reachability + at-least-one-recent-year partition exists; (2) parameterize probe lookback to 365 days to match the historical data shape; (3) make health session-aware (requires base.py + routes_health.py changes — only do this if (1)/(2) are insufficient).
- Modified: `tests/plugins/test_price_plugin.py` — add a regression test that asserts: (a) `health_check()` returns HEALTHY when S3 has price data older than 7 real-world days but within the historical lookback; (b) the response message does NOT contain `"Run ingestion first"` or `"No price data available for the last"`; (c) the prior failure mode (degraded false positive) is reproduced and now passes.
- Modified (only if option 3 above): `finlet/plugins/base.py:246` (signature) and `finlet/api/routes_health.py:84-114` (pass session). Avoid this if simpler options work.

**Deliverable:** GET `/v1/plugins/health` reports `price.status == "healthy"` whenever a market BUY against the active session's simulated date can fill, with a non-misleading message. Verified by the curl retest envelope in `triage.json` item #2.

**Validation:**
- [ ] `uv run pytest tests/plugins/test_price_plugin.py -x -q` — all tests pass, including the new regression.
- [ ] `uv run ruff check finlet/plugins/price_plugin.py tests/plugins/test_price_plugin.py` — zero warnings.
- [ ] `uv run mypy finlet/plugins/price_plugin.py` — zero errors.
- [ ] Manual reasoning check: the agent has explicitly read commit `76f4724`'s diff and `team_b_verify.md` documents what 76f4724 changed and why this fix closes the root cause that 76f4724 missed.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing — worktree is cleaned up otherwise.
- This is a RECURRENCE. The prior fix at `76f4724` patched the symptom, not the cause. DO NOT just add another `or` clause — understand WHY the probe is wrong and pick the simplest fix that closes the root cause.
- DO NOT touch `finlet/plugins/base.py` or `finlet/api/routes_health.py` unless option (3) is chosen and justified in `team_b_verify.md`. The simplest fix is best.
- Write `docs/bug-hunt/20260503T230405Z2601/team_b_verify.md` with: a section "Why 76f4724 didn't close this" (concrete diff analysis), the chosen option (1/2/3) with justification, file diffs, validation command output.

---

### Team C: Settings Plugin Cards Stop Emitting 9 Console Errors

**Blocked by:** none — independent.

**Read these files first:**
- `dashboard/settings.js:1079-1085` — current plugin card template. Recon says the password input IS already inside a `<form>` with `autocomplete="off"` and `autocomplete="new-password"` on the input. The browser STILL emits the warning because the form has NO `<input type="text"|"email" autocomplete="username">` peer. Chromium's password-autofill heuristic requires a username peer (visible OR hidden) inside the same form ancestor.
- `dashboard/settings.html:562` — separate delete-account password input pattern (different context, NOT a model — it has different form requirements)
- `git show ce5fa52 --stat` AND `git show ce5fa52 -- dashboard/` — what the prior recurrence fix actually changed (recon notes commit `78ee51f` may also be relevant — the form wrapper landed there but didn't add the username peer)
- `dashboard/event-contract.md` — bus naming conventions (only relevant if the fix introduces a new event; likely not)
- Chromium guidance: <https://goo.gl/9p2vKq> — the URL the warning itself links to. Read it before fixing.

**Files touched:**
- Modified: `dashboard/settings.js` — for each plugin card form, add a hidden `<input type="text" autocomplete="username" hidden value="<plugin-slug>" name="username">` peer immediately before the password input. Use the plugin's slug or display name as the username value (it's a label for password managers, not a real credential). The form ALREADY exists per recon; only the peer input is missing.
- Modified: `tests/e2e/journey-06-settings.spec.ts` (or whichever covers Settings) — add a Playwright assertion: cold-load `settings.html#plugins`, capture `browser_console_messages` with `all: true`, and assert ZERO entries match `/Password forms should have.*username fields/i` AND zero match `/goo\.gl\/9p2vKq/`. Plus a structural assertion: every `<input type="password">` has a sibling `<input ... autocomplete="username">` inside the same `<form>`.

**Deliverable:** Cold load of `settings.html#plugins` produces zero password-form accessibility warnings in the console, regardless of viewport or session state. Verified by the playwright retest envelope in `triage.json` item #3.

**Validation:**
- [ ] `bash scripts/lint-trusted-types.sh` — zero `.innerHTML` violations.
- [ ] `uv run pytest tests/api -k "settings" -x -q` — relevant API tests pass.
- [ ] Playwright e2e: `npx playwright test tests/e2e/journey-06-settings.spec.ts` (or new file) — passes including the new console-warning assertion.
- [ ] Manual: open `settings.html#plugins` in Chrome with DevTools console set to `all`, no warnings about password forms.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- This is a RECURRENCE. `ce5fa52` (and `78ee51f`) added form wrappers but missed the username peer. DO NOT just re-add the form wrapper. The username peer is the missing piece.
- DO NOT change the password input's `autocomplete="new-password"` attribute. DO NOT remove the form ancestor.
- The username peer can be `hidden` and use the plugin slug as its value — it's a label for the heuristic, not a real credential.
- Write `docs/bug-hunt/20260503T230405Z2601/team_c_verify.md` with: a section "Why ce5fa52/78ee51f didn't close this" (concrete diff analysis), the file diff, validation command output, screenshot of the DevTools console showing zero matching warnings.

---

### Team D: Order Fill Cash Math Becomes Reproducible (slippage_amount + total_cost Disclosure)

**Blocked by:** none — independent.

**Read these files first (REQUIRED — V1 contract is binding):**
- `docs/finlet-v1-scope.md` — confirms commission=0 by design and slippage=10bps fixed. The fix is DISCLOSURE, not math. DO NOT introduce a non-zero commission.
- `finlet/core/orders.py:207-210` — `_fill()` applies slippage to fill_price via `self._slippage_model.apply(price, order.side)`. Stores at 6-digit precision via `round(price * factor, 6)`. The displayed $560.90 is the round-2 of an actual $560.897.
- `finlet/core/slippage.py:57-61` — `FixedPercentageSlippage.apply()` formula. Required to compute `slippage_amount` correctly server-side.
- `finlet/core/portfolio.py:160` — `cost = round(quantity * price + commission, 2)` — this is where the $5,608.97 comes from (10 × 560.897 + 0 = 5608.97).
- `finlet/core/session.py:422-427` — order execution path that wires `portfolio.execute_buy(...)` with `fill_price` (slippage already applied) + `commission=self.config.commission`. Required to understand which value to surface.
- `finlet/api/schemas/trade.py:8-25` — current `OrderResponse` field set: `id, ticker, side, quantity, order_type, limit_price, stop_price, status, submitted_at, filled_at, fill_price, reasoning, reject_reason, time_in_force`. Missing: `slippage_amount`, `total_cost`, `commission` (commission can stay implicit at 0 — but documenting it makes the math reconcilable).
- `finlet/api/services/trade_service.py` — find the OrderResponse serializer (likely `_to_response` or similar). Required to populate the new fields.
- `dashboard/index.html:307` — `<th scope="col">Fill Price</th>` (current order log header set; one new column or one tooltip refactor needed).
- `dashboard/app.js:2151-2183` — order row render. Line 2177: `${o.fill_price != null ? formatCurrency(o.fill_price) : '--'}`. Required to surface the new fields.
- `tests/api/test_orders.py` — find an existing test that asserts the OrderResponse shape. Required to add the slippage_amount/total_cost assertions.
- `tests/core/test_clock_step_integration.py:201,213,305,318,364` — pattern for asserting fill_price; extend to assert slippage_amount/total_cost.
- `dashboard/event-contract.md` — bus events; only relevant if the order-row render path changes its event subscription (likely no change needed).

**Files touched:**
- Modified: `finlet/api/schemas/trade.py` — add three optional fields to `OrderResponse`: `commission: float | None = None`, `slippage_amount: float | None = None`, `total_cost: float | None = None`. Document each in the field's `Field(description=...)` so OpenAPI consumers see what they mean.
- Modified: `finlet/api/services/trade_service.py` — populate the three new fields from the engine's order. `slippage_amount = round(abs(fill_price - mid_price) * quantity, 4)` (or read from a stored slippage component if the engine tracks it; otherwise compute from the slippage_bps × quantity × mid_price). `total_cost = round(fill_price * quantity + commission, 2)` for BUY, `total_cost = round(fill_price * quantity - commission, 2)` for SELL (or signed accordingly). `commission = 0.0` for v1 (read from session config to be safe).
- Modified: `finlet/core/orders.py` — if the engine doesn't already retain enough context (e.g., the pre-slippage mid_price), add a minimal `slippage_amount` attribute or expose the value via a method so trade_service.py can compute total_cost without re-running slippage. KEEP the engine change minimal — prefer passing through what's already computed.
- Modified: `dashboard/index.html` — add one new column to the order log: either `<th scope="col">Total Cost</th>` (preferred — matches cash deduction directly) or surface slippage_amount in a tooltip on the existing Fill Price cell. Pick whichever fits the existing column density. If the table is already crowded, use a tooltip on Fill Price showing "Fill: $X.XXX • Slippage: $Y.YY • Total: $Z.ZZ".
- Modified: `dashboard/app.js:2151-2183` — extend the order row render to display the new column/tooltip. Use the existing `formatCurrency` helper for consistency.
- Modified: `tests/api/test_orders.py` — extend the existing OrderResponse-shape test: assert the three new fields exist and are non-null on a FILLED order. Add an integration test asserting cash delta == quantity × fill_price + commission to within 1¢ tolerance, AND that `total_cost` in the response matches the cash delta exactly.
- Modified: `tests/core/test_clock_step_integration.py` — extend one of the existing fill_price assertions to also check `slippage_amount > 0` (when slippage_bps > 0) and `total_cost == fill_price * quantity` (when commission == 0).

**Deliverable:** OrderResponse exposes commission + slippage_amount + total_cost. Dashboard order log renders enough information for a user to reconstruct cash math (`PRE − POST == total_cost` for BUY). Verified by the curl retest envelope in `triage.json` item #4 (the assertion suite is already written there — do not change it; just satisfy it).

**Validation:**
- [ ] `uv run pytest tests/api/test_orders.py tests/core/test_clock_step_integration.py tests/core/test_portfolio.py -x -q` — all pass including new assertions.
- [ ] `uv run ruff check finlet/api/schemas/trade.py finlet/api/services/trade_service.py finlet/core/orders.py finlet/core/portfolio.py` — zero warnings.
- [ ] `uv run mypy finlet/api/schemas/trade.py finlet/api/services/trade_service.py` — zero errors.
- [ ] Playwright e2e (existing or new): place a market BUY 10 SPY, assert dashboard order row shows total_cost matching the API response and matching the cash delta.
- [ ] Manual reasoning check: write 3 lines in `team_d_verify.md` explaining what `slippage_amount` is exposing (slippage charged) and why total_cost reconciles `PRE − POST`.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- DO NOT change v1 commission (must remain 0 by default; commission field becomes a disclosure, not a feature gate).
- DO NOT change the slippage model. DO NOT change `slippage_bps` default.
- DO NOT bypass the date ceiling enforcer or any plugin response invariant.
- All cross-component dashboard wiring goes through `window.finletBus` per `CLAUDE.md` (this likely doesn't apply since you're modifying an existing render path, not adding a new event — but verify if you touch any subscribe call).
- Bare `.innerHTML =` writes under `dashboard/` MUST be wrapped in `trustedHTML(...)`. Run `bash scripts/lint-trusted-types.sh` before commit.
- Write `docs/bug-hunt/20260503T230405Z2601/team_d_verify.md` with: file diffs, the cash-reconciliation walkthrough (PRE, POST, fill_price, slippage_amount, total_cost — show the arithmetic), validation command output, and a screenshot or DOM snapshot showing the new order-log column/tooltip.

---

### Team E: Docs + Ledger

**Blocked by:** Team A merged + Team B merged + Team C merged + Team D merged (needs all four commit SHAs for the ledger).

**Read these files first:**
- `docs/REMAINING_TASKS.md` — pattern for adding a "Bug Hunt 20260503T230405Z2601 — Closed" subsection.
- `docs/LESSONS.md` — pattern for adding lessons (rules, not diff recaps).
- `docs/ARCHITECTURE.md` — confirm whether this iteration changed CSP, security headers, middleware stack, route surface, schema fields, plugin registry, or dashboard surface. If yes, update; if no, write an explicit "no architectural change this iteration" line in the Team E commit message.
- `docs/KNOWN_FAILURES.md` — pre-flight refresh; remove any pre-existing failures that this iteration resolved.
- `docs/decisions/` — only add a new decision record if a non-trivial reversible decision was made. Likely candidates this iteration: (a) chosen option for Team B's health-probe semantics (drop recency vs lookback-365 vs session-aware); (b) chosen disclosure shape for Team D (new column vs tooltip).
- `docs/bug-hunt/ledger.jsonl` — read the last 5 lines to confirm the schema before appending.
- `docs/bug-hunt/pending_recurrences.jsonl` — currently empty; only modify if Phase 5.5 produced new patch-ineffective signals (orchestrator handles this automatically in Phase 5.5c, but Team D MUST stage the file in the docs commit if non-empty).

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — add "Bug Hunt 20260503T230405Z2601 — Closed" subsection listing the four broken items with their resolving commit SHAs.
- Modified: `docs/LESSONS.md` — append at least one reusable lesson per real-broken finding. Candidate lessons:
  - Sim Time tile (Team A): "When a metric tile renders ASCII text (datetime, ID), set `hyphens: none; word-break: keep-all; white-space: nowrap;` defensively — Chrome's auto-hyphenation inserts U+2014 silently when the value doesn't fit the cell."
  - Plugin Health (Team B): "Plugin health probes MUST be reachability/data-presence checks, not 'last N real-world days' probes — this lies about historical data and contradicts the engine's actual data path."
  - Settings password forms (Team C): "Wrapping `<input type=password>` in a `<form>` is necessary but not sufficient — Chromium's password-autofill heuristic requires a sibling `<input autocomplete=username>` peer (hidden is fine) for every password input. Form wrapping alone produces a recurrence."
  - Cash math (Team D): "Server-computed cash deltas MUST be reconcilable from API response fields alone. If the engine rounds fill_price for display, expose slippage_amount and total_cost in the response — do not require the client to re-derive math the engine already did at higher precision."
- Modified (conditional): `docs/ARCHITECTURE.md` — only if any architectural change. Else explicit no-op line in commit.
- Modified (conditional): `docs/KNOWN_FAILURES.md` — only if a pre-existing failure was resolved. Else explicit no-op line in commit.
- New (conditional): `docs/decisions/<slug>.md` — one per non-trivial reversible decision (likely 1–2 records this iteration).
- Modified: `docs/bug-hunt/ledger.jsonl` — append exactly four JSON lines (one per real-broken finding closed). Use the schema in the Required Docs Updates block in `triage.md`. Read commit SHAs from `git log --oneline main` after Teams A–D have merged.
- Stage all artifacts under `docs/bug-hunt/20260503T230405Z2601/` — including any `team_*_verify.md`, `triage.md`, `triage.json`, `blind_report.json`, `blind_report.parsed.json`, `cleanup.log`, `isolation_warning.txt`, `plan.md`, `deploy_status.txt`, `retest_results.json`, `blind_diagnostic.log` (if present).

**Deliverable:** A single docs commit on `main` referencing iteration `20260503T230405Z2601`, listing which docs were touched and the ledger increment count. After this commit, `wc -l docs/bug-hunt/ledger.jsonl` should report exactly 51 lines (47 prior + 4 this iteration).

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` — equals 51.
- [ ] `jq -c '.iteration_ts' docs/bug-hunt/ledger.jsonl | tail -4` — all four lines show `"20260503T230405Z2601"`.
- [ ] `jq -c '.commit' docs/bug-hunt/ledger.jsonl | tail -4` — four distinct SHAs matching Teams A/B/C/D's merge commits on main.
- [ ] `git diff --stat HEAD~1` (or appropriate range) — every artifact under `docs/bug-hunt/20260503T230405Z2601/` is staged.
- [ ] `bash scripts/lint-trusted-types.sh` (no incidental dashboard changes from staging files).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- The commit message MUST reference iteration `20260503T230405Z2601` and name which docs were touched in the "type 1, 2, 3, 4 unchanged" pattern from prior iterations (e.g., `docs: bug-hunt 20260503T230405Z2601 — close 4 fixes; LESSONS +4; ARCHITECTURE unchanged; ledger +4`).
- DO NOT skip docs items silently. If a section was untouched this iteration, write it explicitly in the commit message.
- DO NOT modify any non-docs file. If you discover a code bug while writing docs, file a follow-up — do not patch in this commit.
- Write `docs/bug-hunt/20260503T230405Z2601/team_e_verify.md` with: ledger line-count delta, list of files touched, validation command output, and a one-line summary per LESSONS lesson added.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team B's "drop the recency probe" choice masks a future legit ingest-failure mode (e.g., S3 partition empty for current month) | Medium | Medium | Team B MUST add a separate test asserting that S3-unreachable still produces UNHEALTHY (not just HEALTHY-because-recency-was-dropped). Health check must still detect a true outage. |
| Team C's hidden username peer breaks password manager autofill on a real user (e.g., 1Password attaches to the hidden field) | Low | Low | Use a plugin-slug value (not "username") so password managers don't treat it as a real credential. Test in Chrome with no extensions to verify the warning is gone, then verify with 1Password / Bitwarden installed that autofill still works for the visible password input. |
| Team D's `slippage_amount` field shape disagrees between engine and api (e.g., engine treats slippage as a multiplier, api expects an absolute amount) | Medium | High | Team D MUST write the integration test BEFORE implementing the field — assert the math reconciles end-to-end. Do not commit if the assertion fails. |
| Team D adds a new dashboard column that breaks mobile layout | Low | Medium | Tooltip-on-existing-cell is the safer choice if the table is already wide. Team D's verify must include a mobile screenshot OR an explicit note that the column doesn't change the table width footprint. |
| Team A's CSS rule (`white-space: nowrap`) breaks the tile on extremely narrow viewports (<360px) | Low | Low | Add a `@media (max-width: 360px)` fallback that wraps on whitespace ONLY (not mid-character) if the unrestricted rule overflows. Otherwise accept overflow-clip as the trade-off. |
| Team E commits before A/B/C/D merge — ledger SHAs are stale or wrong | Medium | High | Team E is BLOCKED until exec-plan reports A/B/C/D merged. /exec-plan handles this via the dependency graph; do not override. |
| Recurrence: B and C don't actually close the root cause; Phase 5.5 retest fails again → patch-ineffective signal lands | Medium | High | The verify reports MUST include a "why prior fix didn't close this" section. If the agent can't articulate the gap, it's the same fix again — escalate to refactor BEFORE Phase 5. |

## Session Plan

### Session 1 — Parallel: A, B, C, D (independent)

**Parallel:** Teams A, B, C, D launch concurrently in worktrees. Each merges to `main` independently with a per-merge targeted test gate.

**Merge order:** Whichever team finishes first merges first. There are NO file conflicts and NO logical dependencies between them. The exec-plan merge gate runs the team's specific validation block (per Per-Team Specs) on `main` after each merge.

**Targeted gate per merge:**
- After A merges: `npx playwright test tests/e2e/journey-sim-time-tile.spec.ts` (or whichever file Team A used)
- After B merges: `uv run pytest tests/plugins/test_price_plugin.py -x -q`
- After C merges: `npx playwright test tests/e2e/journey-06-settings.spec.ts`
- After D merges: `uv run pytest tests/api/test_orders.py tests/core/test_clock_step_integration.py tests/core/test_portfolio.py -x -q`

**Session checkpoint:** Full suite — `uv run pytest -x -q` + `bash scripts/lint-trusted-types.sh` after all four have merged.

### Session 2 — Sequential: E (after A, B, C, D)

**Sequential:** Team E only.

**Merge gate:** ledger line-count assertion (`wc -l docs/bug-hunt/ledger.jsonl` == 51) + `git diff --stat` shows expected docs paths only.

**Session checkpoint:** Same as Session 1's checkpoint plus `git push origin main` (handled by /exec-plan).
