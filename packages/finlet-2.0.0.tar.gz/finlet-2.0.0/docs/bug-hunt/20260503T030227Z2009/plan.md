# Bug-Hunt 20260503T030227Z2009 — Execution Plan

> Generated from `docs/bug-hunt/20260503T030227Z2009/triage.md` on 2026-05-02.

## Constraints

- Keep blast-radius minimal. trade-ticket-stale-cash is a 4th recurrence after THREE refactor attempts; if Team A discovers the fix needs architectural rework beyond a 5-line gap, STOP and document so v4 can be drafted.
- Plugin Ingest visual feedback code already exists per `dashboard/settings.js:1141-1251` and `dashboard/settings.css:723-749` (commit `c489d53`). Team B's job is to find why it isn't reaching the user (event delegation, button rendering, or render-on-refetch race), not re-implement.
- Vanilla HTML+JS+CSS dashboard — no build step, no framework (per `.claude/rules/dashboard.md`).
- All bus interactions go through `window.finletBus.subscribe / publish` (per CLAUDE.md). Direct `addEventListener('finlet:...')` is forbidden.
- All cross-component state mirrors go through `dashboard/dialog-state-mirror.js` for read-only dialogs, OR render-on-read pattern for persistent-DOM bus-mirror surfaces (per CLAUDE.md exception). Trade Ticket cash header uses render-on-read.

## File Conflict Table

| File | Touched by Teams |
|------|------------------|
| `dashboard/trade-ticket.js` | A |
| `dashboard/app.js` | A |
| `dashboard/event-contract.md` | A (if event semantics change) |
| `tests/dashboard/trade-ticket-post-submit.spec.js` | A |
| `tests/e2e/journey-05-trade.spec.ts` | A |
| `dashboard/settings.js` | B |
| `dashboard/settings.css` | B |
| `tests/e2e/journey-06-settings.spec.ts` | B (if regression test added) |
| `docs/REMAINING_TASKS.md` | D |
| `docs/LESSONS.md` | D |
| `docs/ARCHITECTURE.md` | D (likely no change) |
| `docs/KNOWN_FAILURES.md` | D |
| `docs/bug-hunt/20260503T030227Z2009/*` | D (artifact stage) |
| `docs/bug-hunt/ledger.jsonl` | E |
| `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` | E (verdict update) |
| `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v4.md` | E (NEW — only if Team A escalates) |

**No file conflicts between A, B, D.** Team E touches refactor-queue/v3 + ledger; no overlap with A/B/D.

## Dependency Graph

- **Team A** (trade-ticket cash) — independent, can start immediately.
- **Team B** (plugin ingest feedback) — independent, can start immediately.
- **Team D** (docs) — depends on A + B (needs to know what shipped to write LESSONS).
- **Team E** (ledger + refactor-queue verdict) — depends on A + B + D (needs merge SHAs).

## Critical Path

```
[A, B] (parallel) → D → E
```

Team A's investigation depth determines the iteration's wall-clock time. If A escalates (no fix attempted), it still merges a `team_a_verify.md` document explaining the escalation.

---

## Teams

### Team A: Trade Ticket Cash — find why v3 repaint doesn't fire on open dialog

**Blocked by:** none — can start immediately

**Read these files first** (CRITICAL — v3 just shipped 2026-05-02; do NOT re-architect without understanding it):

- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` — the v3 design contract (render-on-read from canonical store; bus events as triggers, not value carriers).
- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v2.md` — v2 verdict: regressed. Explains WHY the always-on subscription pattern failed (broke open/close DOM teardown). Don't reintroduce.
- `docs/decisions/trade-ticket-render-on-read.md` — the architectural decision record for render-on-read.
- `dashboard/trade-ticket.js:14-42` — `getCanonicalCash()` and `repaintCash()`. Reads `currentSession.portfolio_metrics.cash` first, falls back to `bus.getLastPublished('portfolio:updated').cash`.
- `dashboard/trade-ticket.js:178-235` — `dialogStateMirror` config: `primeFromCache`, `refetch`, `onOpen`, `onUpdate`, `refuseClobber`. Note `onUpdate` (line 208) calls `repaintCash()` ignoring payload.
- `dashboard/trade-ticket.js:265-269` — `closeTradeTicket` tears down `tradeTicketMirror` (unsubscribes from `portfolio:updated`).
- `dashboard/trade-ticket.js:447-498` — post-submit refetch+mutate+republish IIFE inside `submitOrder` (the path the blind agent triggered).
- `dashboard/dialog-state-mirror.js:142-161` — `applyUpdate` and the `bus.subscribe` handler. Note `applyUpdate` is gated by `refuseClobber(appliedValue, nextValue)`.
- `dashboard/app.js:32-34` — `window.currentSession` two-way alias (commit `ea9ee7e`).
- `dashboard/app.js:1456-1493` — portfolio SSE handler (mutates currentSession.portfolio_metrics.cash + publishes portfolio:updated).
- `dashboard/app.js:1509-1633` — orders SSE handler with deferred portfolio refetch IIFE (lines 1589-1627).
- `dashboard/event-contract.md` — `portfolio:updated` and `order:filled` contracts.
- `tests/e2e/journey-05-trade.spec.ts` — existing regression tests, especially the "available cash header never shows --" test that v2 broke.

**The investigation, not the fix:**

The blind agent's evidence: after submitting BUY AAPL 10 @ MARKET via the web UI, `#tt-cash-balance.textContent` stayed at `$100,000.00`. Dashboard KPI Cash tile correctly read `$97,953.37`. Closing and re-opening the dialog rendered `$97,953.37` — proving `currentSession.portfolio_metrics.cash` IS being mutated to the post-fill value somewhere.

The architecture per v3 says: post-submit IIFE mutates `currentSession.portfolio_metrics.cash` then `bus.publish('portfolio:updated', ...)`. The dialog's `dialog-state-mirror` bus subscriber calls `onUpdate` → `repaintCash()` which reads the canonical store. If reopening shows the right value but the open dialog doesn't, ONE of these is failing on the still-open dialog:

1. **Subscriber not firing.** `dialog-state-mirror.js:158` `bus.subscribe` may unsubscribe earlier than expected, OR the publish is silently dropped.
2. **`refuseClobber` blocking the update.** Check `refuseClobber(appliedValue, nextValue)` at `trade-ticket.js:226-234` — its predicate refuses when nextValue's cash is non-numeric. Verify `portfolioRes.data.cash` is actually `number`-typed in the publish path.
3. **Post-submit IIFE silently throwing.** Lines 447-498 are wrapped in try/catch with `console.error` — the blind agent didn't capture console errors. Check whether `dashFetch` returns an unexpected shape, whether `renderPortfolio` is undefined, etc.
4. **`window.finletBus.publish` undefined or alternate-window.** `trade-ticket.js:487` checks `window.finletBus`. If this is an iframe / module-isolation issue introduced by the `ea9ee7e` window aliasing, the publish lands on a different bus instance than the subscriber listens on.
5. **Order processed by different code path.** The blind agent submitted via #tt-symbol/#tt-quantity/#tt-submit. Confirm `submitOrder` (the function containing the IIFE at line 447) IS the handler bound to that submit, NOT a different function that bypasses the post-submit refetch.

**Fix scope discipline:**

- If the bug is a 1-5 line gap (missing event publish, wrong type coercion, wrong condition guard), fix it. Add ONE targeted regression test in `tests/dashboard/trade-ticket-post-submit.spec.js` that fails on `main` pre-fix and passes post-fix.
- If the bug requires architectural change (e.g., the bus subscriber needs a different lifetime, the canonical store needs different ownership, refuseClobber semantics need rework), DO NOT attempt the fix. Write `docs/bug-hunt/20260503T030227Z2009/team_a_verify.md` documenting:
  - What you found (the failure mechanism)
  - Why a 5-line patch can't close it
  - The shape of v4 (which file, which contract change)
  - And commit only the verify doc + nothing else.

**Files touched (worst case):**

- Modified: `dashboard/trade-ticket.js` — targeted fix
- Modified: `dashboard/app.js` — only if SSE handler is the gap
- Modified: `dashboard/event-contract.md` — only if event semantics change
- New / modified: `tests/dashboard/trade-ticket-post-submit.spec.js` — regression test
- Modified: `tests/e2e/journey-05-trade.spec.ts` — only if E2E coverage gap is exposed

**Files touched (escalation):**

- New: `docs/bug-hunt/20260503T030227Z2009/team_a_verify.md` (only)

**Deliverable:** Either (a) targeted fix that makes a fresh blind walk see `#tt-cash-balance` update post-fill without close+reopen, OR (b) a verify doc explaining why v4 is needed.

**Validation:**
- [ ] `uv run pytest tests/dashboard/trade-ticket-post-submit.spec.js -x -q` passes (if test added)
- [ ] `uv run pytest tests/e2e/journey-05-trade.spec.ts -x -q` passes (existing v2-regression test must still pass — open/close DOM teardown contract intact)
- [ ] Manual playwright sanity: with a session active, open Trade Ticket, submit BUY AAPL 1 MARKET, observe `#tt-cash-balance` updates within 2s without closing the dialog.
- [ ] OR (escalation) `team_a_verify.md` exists with the four required sections (failure mechanism, why 5-line patch fails, v4 shape, no other file changes).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Worktree work is lost if not committed.
- Follow render-on-read v3 pattern. DO NOT reintroduce v2's always-on subscription (regressed: broke open/close teardown).
- DO NOT change `closeTradeTicket`'s mirror.close() — that's load-bearing per v2's regression.
- DO NOT widen scope to fix unrelated trade ticket UX issues from the triage's annoying/nice-to-have list.
- Run the existing journey-05 regression test BEFORE merging — if it fails, you've regressed v2's fix.

---

### Team B: Plugin Ingest — find why visual feedback isn't reaching the user

**Blocked by:** none — can start immediately

**Read these files first:**

- `dashboard/settings.js:995-998` — `_pluginNeedsIngest()` predicate (substring-match `"run ingestion"` in plugin.message, case-insensitive).
- `dashboard/settings.js:1004-1007` — `renderIngestButton()` — DOM creation for the Ingest button with `data-action="ingest-plugin"`.
- `dashboard/settings.js:1107` — event delegation binding for `data-action="ingest-plugin"`.
- `dashboard/settings.js:1141-1251` — `triggerIngest()` — the click handler. Sets `aria-busy="true"` on card synchronously (line 1149), inserts `.ingest-pending` span (line 1157-1171), disables button + relabels to "Ingesting..." (line 1173-1175), shows toast on 202 (line 1195) or error (line 1209/1214), schedules `loadPlugins()` refetch after 2s on success (line 1225-1238), failure path re-enables button + clears pending (line 1239-1250).
- `dashboard/settings.js:1257-1270` — `_renderIngestRowError()` — row-level inline error renderer.
- `dashboard/settings.css:723-749` — `.plugin-config-card[aria-busy="true"]`, `.ingest-pending`, `.ingest-error` styling.
- `dashboard/app.js:314-340, 911, 1063, 1104, 1381` — `showToast` call sites + signature (object form `{type, title, message, duration}`).
- `git log --oneline dashboard/settings.js dashboard/settings.css | head -5` — recent commits for context (`c489d53` Team A 20260502T211937Z7ddd added the row-level pending state).

**The investigation, not the fix:**

The blind agent's evidence: clicking Ingest fires POST → 202 Accepted, but the button does NOT change state, no toast appears, the row's status text does NOT update. The job DOES complete in the background (verified later).

The code at `triggerIngest` does ALL the right things synchronously — sets `aria-busy="true"`, inserts `.ingest-pending`, disables the button, calls `showToast`. So one of these is wrong:

1. **`triggerIngest` isn't being called at all.** Event delegation binding at `settings.js:1107` might be looking for a different `data-action` value than `renderIngestButton` emits, OR the button is rendered without the `data-action` attribute, OR the binding is on a stale parent that doesn't contain the button.
2. **`triggerIngest` is called but `card` lookup fails.** Line 1143: `btn.closest('.plugin-config-card')`. If the button's parent class is named differently, `card` is null and lines 1149-1171 silently no-op (every assignment is `if (card) ...`).
3. **`showToast` signature mismatch.** Compare line 1195 (`showToast('Ingestion queued${tail}', 'success')` — string + string) against the canonical `showToast` signature visible at `app.js:314` (`showToast({type, title, message, duration})` — object). If `showToast` requires an object, the string-form call silently produces no UI.
4. **CSS not loaded / not in cascade.** `.plugin-config-card[aria-busy="true"]` styling at `settings.css:733-737` may not be applying if the card class is different from `.plugin-config-card`, OR if a higher-specificity rule overrides it.
5. **`loadPlugins()` 2s refetch (line 1225-1238) clobbers the row before the user perceives the pending state.** This is unlikely — 2s is ample — but the blind agent reports `_pluginNeedsIngest`-driven row may STILL show the same "Run ingestion first" message after refetch (because the ingest is still running in the background; the next health poll hasn't yet reflected new cached files). If `loadPlugins()` re-renders the row identically, the pending indicator is replaced by a fresh non-pending button, looking like nothing happened.

**Fix scope discipline:**

- Most likely: a `showToast` signature mismatch (item 3) OR an event-delegation gap (item 1). Either is a 1-3 line fix.
- If the issue is the 2s refetch clobbering the pending state (item 5), ship a small fix that keeps the pending indicator until the row's status text actually changes (poll-and-reconcile, not blind setTimeout). Cap fix scope at the existing `triggerIngest` function.
- DO NOT add a new toast system, new polling mechanism, or new server endpoint. The existing scaffolding is sufficient.

**Files touched:**
- Modified: `dashboard/settings.js` — targeted fix in `triggerIngest` (signature, event delegation, or refetch-reconciliation)
- Modified: `dashboard/settings.css` — only if a CSS specificity issue is the root cause
- New / modified: `tests/e2e/journey-06-settings.spec.ts` — Playwright assertion that clicking Ingest produces visible pending state within 500ms AND a toast within 1s

**Deliverable:** Clicking the Ingest button on a degraded plugin row makes the row show a visible pending state and a toast appear within 1s of click. Verified by E2E test.

**Validation:**
- [ ] `uv run pytest tests/e2e/journey-06-settings.spec.ts -x -q` passes (with new pending-state assertion)
- [ ] Manual playwright sanity: login → Settings → Plugins, click Ingest on price plugin → observe row turns pending + toast appears within 1s
- [ ] No regression in existing settings tab tests

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Follow existing toast and event-delegation patterns in `dashboard/settings.js`.
- DO NOT replace `setTimeout(() => loadPlugins(), 2000)` with a long-poll loop — that's scope creep. If clobber is the issue, gate the refetch on a row-state check.
- DO NOT widen scope to address the news_s3 / sentiment "Ingest button missing in onboarding" finding — that was triaged needs-investigation, not real-broken.

---

### Team D: Documentation updates per Required Docs Updates block

**Blocked by:** A + B (need to know what was fixed to write LESSONS.md and REMAINING_TASKS.md)

**Read these files first:**

- `docs/REMAINING_TASKS.md` — most recent "Bug Hunt YYYYMMDD — Closed" subsection for pattern.
- `docs/LESSONS.md` — most recent additions for tone/format.
- `docs/ARCHITECTURE.md` — header sections to confirm no architecture change is needed (unless A or B touch route surface / middleware / schema).
- `docs/KNOWN_FAILURES.md` — current known-failures list.
- `docs/bug-hunt/20260503T030227Z2009/triage.md` — full iteration scope.
- `docs/bug-hunt/20260503T030227Z2009/triage.json` — for finding-specific summaries.
- Team A and Team B's commits + verify.md files (if any) on `main` — read after their merges land.

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — append "Bug Hunt 20260503T030227Z2009 — Closed" subsection
- Modified: `docs/LESSONS.md` — at least one lesson per real-broken finding (so 2 lessons minimum). Lessons must be reusable rules, NOT diff recaps. Examples: "When a bus event publish completes but a subscribed handler doesn't paint, suspect…" / "When click-handler feedback exists in code but doesn't reach the user, suspect signature mismatch on a shared helper."
- Modified: `docs/ARCHITECTURE.md` — likely no change. If unchanged, state explicitly in commit message: "ARCHITECTURE.md: no architectural change this iteration."
- Modified: `docs/KNOWN_FAILURES.md` — pre-flight refresh + remove anything resolved this iteration.
- Add: `docs/decisions/` — only if a non-trivial reversible decision was made (likely none this iteration).
- Stage: ALL artifacts in `docs/bug-hunt/20260503T030227Z2009/` (plan.md, triage.md, triage.json, blind_report.json, cleanup.log, isolation_warning.txt, deploy_status.txt, retest_results.json, blind_diagnostic.log if present, team_a_verify.md if present)

**Deliverable:** Single docs commit referencing iteration `20260503T030227Z2009`, naming which docs were touched.

**Validation:**
- [ ] `git status docs/bug-hunt/20260503T030227Z2009/` — every artifact tracked, no untracked files in the iteration dir
- [ ] `wc -l docs/REMAINING_TASKS.md` grew by ≥4 lines (subsection + at least 2 closed items)
- [ ] `wc -l docs/LESSONS.md` grew by ≥6 lines (2 lessons minimum, ~3 lines each)
- [ ] commit message contains `20260503T030227Z2009` and `bug-hunt`

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Mirror the format of the most recent prior iteration's docs commit (see `git log docs/REMAINING_TASKS.md | head -10`).
- LESSONS.md entries must be REUSABLE RULES, not "we fixed X by doing Y." Pattern: "When you see <symptom>, suspect <class of cause> first. Why: <past incident>. How to apply: <where to look>."
- If Team A escalated (no fix, only verify.md), still document the escalation in LESSONS.md as a class lesson ("When a refactor reaches v3 with the same recurrence, draft the next refactor scope BEFORE another patch attempt.").

---

### Team E: Ledger + refactor-queue verdict update

**Blocked by:** A + B + D (need merge SHAs from A/B and final docs touch from D)

**Read these files first:**

- `docs/bug-hunt/ledger.jsonl` — last 5 lines for schema/format pattern.
- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` — current `verdict:` field state (currently absent; this team sets it).
- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v2.md` — example of a `verdict_v2_evidence` follow-on field for context.
- `docs/bug-hunt/pending_recurrences.jsonl` — current pending entries.
- `docs/bug-hunt/pending_recurrences.resolved.jsonl` — pattern for moved-resolved entries.
- The Phase 5.5 `retest_results.json` (orchestrator-emitted before this team runs).
- Team A and Team B's merge commit SHAs on `main` (`git log --oneline main | head -10`).

**Files touched:**
- Modified: `docs/bug-hunt/ledger.jsonl` — append exactly one JSON line per real-broken finding closed this iteration. Schema:
  ```json
  {"iteration_ts":"20260503T030227Z2009","finding_id":"trade-ticket-stale-cash","category":"dashboard-state-sync","summary":"<short>","scope_files":["dashboard/trade-ticket.js","dashboard/app.js"],"team":"A","commit":"<merge-sha-on-main>"}
  {"iteration_ts":"20260503T030227Z2009","finding_id":"plugin-ingest-no-feedback","category":"dead-affordance","summary":"<short>","scope_files":["dashboard/settings.js","dashboard/settings.css"],"team":"B","commit":"<merge-sha-on-main>"}
  ```
  (If Team A escalated without a fix, omit the trade-ticket-stale-cash entry — only successful fixes go in the ledger.)
- Modified: `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` — set `verdict:` field. Decision logic:
  - If Team A shipped a fix AND the Phase 5.5 retest passed: `verdict: incomplete` with `verdict_evidence` describing the gap v3 missed.
  - If Team A shipped a fix AND the Phase 5.5 retest failed: `verdict: incomplete` with `verdict_evidence` noting v3 + Team A's patch were insufficient.
  - If Team A escalated (no fix): `verdict: incomplete` with `verdict_evidence` noting "v3 architecture is correct in shape but the post-fill paint path has a gap that requires v4. See `team_a_verify.md`."
  - If Team A's investigation revealed v3 broke an existing path: `verdict: regressed`.
- Modified: `docs/bug-hunt/pending_recurrences.jsonl` — orchestrator handles append in Phase 5.5c. This team only stages it.
- (Optional) New: `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v4.md` with `status: ready` — only if Team A escalated AND has a clear v4 shape documented in `team_a_verify.md`.

**Deliverable:** Ledger updated with N lines (N = real-broken items successfully closed). Refactor-queue v3 doc has its `verdict:` field set.

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` grew by exactly the number of real-broken items closed this iteration (0, 1, or 2)
- [ ] Each new ledger line is valid JSON: `tail -2 docs/bug-hunt/ledger.jsonl | jq .`
- [ ] `grep '^verdict:' docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` returns one line
- [ ] commit message references `20260503T030227Z2009` and names the verdict set on v3

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Read commit SHAs from `git log --oneline main` AFTER Team A/B merges land — do not guess.
- If a v4 refactor doc is drafted, its scope MUST be derived from Team A's `team_a_verify.md`, not invented.
- Pruning of `pending_recurrences.jsonl` happens in Phase 6 (orchestrator), NOT this team.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A regresses v2's fix (open/close DOM teardown contract) by reintroducing always-on subscription | Medium | High | Mandatory pre-merge run of `tests/e2e/journey-05-trade.spec.ts` "available cash header never shows --" assertion; explicit DO-NOT in Team A's agent instructions. |
| Team A patch is also patch-ineffective (4th recurrence becomes 5th) | High | Medium | Phase 5.5 retest catches it; Phase 6 sets v3 verdict accordingly; next iteration's gate trips on patch-ineffective signal. The escalation path (verify.md instead of patch) lets Team A fail-fast without burning a patch attempt. |
| Team B's fix removes the loadPlugins refetch and breaks the eventual UI reconciliation | Low | Medium | Team B instructions explicitly forbid replacing the 2s refetch with a long-poll. Validation requires the existing journey-06 settings tests still pass. |
| Team D documents a fix that didn't actually ship (Team A escalated) | Medium | Low | Team D instructions cover the escalation case explicitly: document the escalation as a LESSONS entry. |
| Team E sets verdict on v3 incorrectly (e.g., effective when retest failed) | Low | Medium | Decision logic in Team E spec ties verdict to Phase 5.5 retest outcome explicitly. |
| Pending_recurrences.jsonl grows unbounded if v3 keeps failing | Medium | Low | Phase 6 prune logic is gated on `verdict: effective` — entries stay live until the underlying root cause is closed, which is the design intent. |

---

## Session Plan

### Session 1 — Parallel fixes

**Parallel:** Teams A and B (no shared files).

**Merge order:** A merges first → run targeted tests on `main` → B merges → run targeted tests on `main`. (Order is arbitrary; A first by convention.)

**Per-team gate after merge:**
- After A merge: `uv run pytest tests/dashboard/trade-ticket-post-submit.spec.js tests/e2e/journey-05-trade.spec.ts -x -q`
- After B merge: `uv run pytest tests/e2e/journey-06-settings.spec.ts -x -q`

**Session checkpoint:** `uv run pytest -x -q` (full suite) after both merge.

### Session 2 — Docs

**Sequential:** Team D (after Session 1 complete).

**Per-team gate after merge:** `git status docs/` clean; `wc -l` checks pass.

### Session 3 — Ledger + verdict

**Sequential:** Team E (after Session 2 complete; needs full main state).

**Per-team gate after merge:** `tail -2 docs/bug-hunt/ledger.jsonl | jq .` succeeds; `grep '^verdict:' docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` returns 1 line.

---

## Notes for the executor

- Worker type: `general-purpose` (Opus 4.7) per skill default. The work is JS DOM/event-debugging + targeted test authoring — NOT shell-loop / desktop-GUI / >200K context territory where Codex would win.
- Worktree isolation: required for Teams A and B (write to dashboard/). Teams D and E touch docs/ only — worktree still recommended for hygiene but the merge conflict risk is lower.
- If Team A escalates, the Phase 5.5 retest's `trade-ticket-stale-cash` assertion will obviously fail — that's expected. Phase 6 records `verdict: incomplete` regardless.
