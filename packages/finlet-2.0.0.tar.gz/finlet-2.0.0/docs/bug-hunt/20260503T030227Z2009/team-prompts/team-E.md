You are Team E: Refactor-queue v3 verdict update.

WORKING DIR: this is a git worktree forked from main at SHA 3b0f6dd16fcb6f2f6ecf3d21a81736a8432a2adb.

**Blocked by:** A + B + D (all merged on main before this team starts).

**Important context — Team D pre-empted ledger and pending_recurrences work:**

Team D's commit `769ddcc` already:
- Appended the 2 ledger entries for this iteration's real-broken findings (trade-ticket-stale-cash → Team A `8c55a90`; plugin-ingest-no-feedback → Team B `cbd8340`).
- Pruned `pending_recurrences.jsonl` (cleared the pre-existing trade-ticket-stale-cash entry from iteration `20260502T142726Z7b36`).
- Moved the resolved entry into `pending_recurrences.resolved.jsonl` with a full `resolved_note` describing the v3 → v3.1 gap closure.

**You MUST NOT re-touch any of these files:**
- `docs/bug-hunt/ledger.jsonl` (would create duplicates)
- `docs/bug-hunt/pending_recurrences.jsonl` (already pruned)
- `docs/bug-hunt/pending_recurrences.resolved.jsonl` (entry already moved)

If you find yourself wanting to edit any of those files, STOP — Team D already handled them. Verify by:
- `tail -2 docs/bug-hunt/ledger.jsonl | jq -r '.iteration_ts'` should both equal `20260503T030227Z2009`.
- `wc -l docs/bug-hunt/pending_recurrences.jsonl` should be 0.
- `tail -1 docs/bug-hunt/pending_recurrences.resolved.jsonl | jq -r '.resolved_at_ts'` should equal `20260503T030227Z2009`.

**Your single deliverable: set the `verdict:` field on `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md`.**

**Read these files first:**

- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` — currently has `status: shipped` but no `verdict:` field. This team adds it.
- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v2.md` — example of a `verdict_v2_evidence` follow-on field for context (look for the format).
- `docs/bug-hunt/pending_recurrences.resolved.jsonl` — read the most recent `trade-ticket-stale-cash` entry's `resolved_note` field. Your `verdict_v3_evidence` block on the v3 doc should reference the same gap analysis (closed-panel persistent-DOM-rot; v3.1 commit `8c55a90` adds terminal `repaintCash()` at every publisher site).
- Team A's commit on main: `git show 8c55a90 --stat` to confirm the 3 publisher sites changed.

**Files touched:**

- Modified: `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` — add a `verdict:` field below the existing `status: shipped` line. Decision logic for THIS iteration:
  - Team A shipped a fix (commit `8c55a90`, merged as `8e78c5a`). Phase 5.5 retest has NOT yet run at the time you execute (the orchestrator runs it after deploy in Phase 5.5).
  - Set `verdict: incomplete` (NOT `effective`, NOT `regressed`).
  - Add a `verdict_v3_evidence:` field directly below `verdict:` describing the specific gap v3 missed and how v3.1 closed it. Format like the existing `verdict_v2_evidence:` field on `trade-ticket-state-sync-v2.md`. Content must include:
    - The gap: v3's render-on-read contract (DOM reads from canonical store, payload ignored) is correct in shape, BUT the post-submit IIFE in `dashboard/trade-ticket.js#submitTradeTicket` publishes `portfolio:updated` AFTER `closeTradeTicket()` has already torn down the dialog-state-mirror subscriber. The persistent `<aside id="trade-ticket-panel">` DOM remains mounted with its stale text because no consumer is listening at publish time — bus.publish goes to zero subscribers for that surface.
    - The v3.1 closure: Team A appended a terminal `repaintCash()` call at every publisher site that mutates `currentSession.portfolio_metrics.cash` before publishing `portfolio:updated`. Three sites (1 line each): `dashboard/trade-ticket.js#submitTradeTicket` post-submit IIFE, `dashboard/app.js` SSE portfolio handler, `dashboard/app.js` SSE orders deferred-portfolio-refetch IIFE.
    - The contract preserved: `repaintCash()` still reads canonical only (`currentSession.portfolio_metrics.cash`, fallback `bus.getLastPublished('portfolio:updated').cash`) — payload values are intentionally ignored, so the journey-05 poison-publish-after-close assertion still passes.
    - Reference the v3.1 fix commit: `8c55a90` (merge `8e78c5a`).
    - Reference the bug-hunt iteration that surfaced the gap: `20260503T030227Z2009`.

- DO NOT touch any other file. (Specifically: ledger.jsonl, pending_recurrences.jsonl, pending_recurrences.resolved.jsonl — Team D already handled. No code, no tests.)

**Deliverable:** v3 doc has `verdict: incomplete` and a `verdict_v3_evidence:` block describing the closed-panel persistent-DOM-rot gap and v3.1's terminal-repaintCash closure.

**Validation:**
- [ ] `git diff --stat HEAD~1 HEAD` shows ONLY `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` modified (1 file, no others).
- [ ] `grep -c '^verdict:' docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` returns 1.
- [ ] `grep -c '^verdict_v3_evidence:' docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` returns 1 (or `verdict_v3_evidence:` appears once as a YAML-style key block).
- [ ] commit message references `20260503T030227Z2009` and names `verdict: incomplete` on v3.

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- You MUST `git add` + `git commit` before finishing.
- DO NOT modify any code (no `dashboard/`, no `finlet/`, no `tests/`).
- DO NOT touch ledger.jsonl, pending_recurrences.jsonl, or pending_recurrences.resolved.jsonl — Team D already handled them. Re-touching would create duplicates.
- DO NOT draft a v4 doc — v3.1 is the closure for the v3 gap.
- Your commit message must start with "[Team E]:".
- When done, report: DONE + commit hash + validation results, OR: BLOCKED + what went wrong.
