You are Team A: Trade Ticket Cash — find why v3 repaint doesn't fire on open dialog.

WORKING DIR: this is a git worktree forked from main at SHA 9568aa1834c178e660210e2c4363b3b2dd7bce4b.

**Blocked by:** none — can start immediately.

**Read these files first** (CRITICAL — v3 just shipped 2026-05-02; do NOT re-architect without understanding it):

- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` — the v3 design contract (render-on-read from canonical store; bus events as triggers, not value carriers).
- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v2.md` — v2 verdict: regressed. Explains WHY the always-on subscription pattern failed (broke open/close DOM teardown). Don't reintroduce.
- `docs/decisions/trade-ticket-render-on-read.md` — the architectural decision record for render-on-read.
- `dashboard/trade-ticket.js:14-42` — `getCanonicalCash()` and `repaintCash()`. Reads `currentSession.portfolio_metrics.cash` first, falls back to `bus.getLastPublished('portfolio:updated').cash`.
- `dashboard/trade-ticket.js:178-235` — `dialogStateMirror` config: `primeFromCache`, `refetch`, `onOpen`, `onUpdate`, `refuseClobber`. Note `onUpdate` (line 208) calls `repaintCash()` ignoring payload.
- `dashboard/trade-ticket.js:265-269` — `closeTradeTicket` tears down `tradeTicketMirror` (unsubscribes from `portfolio:updated`).
- `dashboard/trade-ticket.js:447-498` — post-submit refetch+mutate+republish IIFE inside `submitOrder` (the path the blind agent triggered).
- `dashboard/dialog-state-mirror.js:142-161` — `applyUpdate` and the `bus.subscribe` handler. Note `applyUpdate` is gated by `refuseClobber(appliedValue, nextValue)`.
- `dashboard/app.js:32-34` — `window.currentSession` two-way alias (commit `ea9ee7e`).
- `dashboard/app.js:1456-1493` — portfolio SSE handler (mutates currentSession.portfolio_metrics.cash + publishes portfolio:updated).
- `dashboard/app.js:1509-1633` — orders SSE handler with deferred portfolio refetch IIFE (lines 1589-1627).
- `dashboard/event-contract.md` — `portfolio:updated` and `order:filled` contracts.
- `tests/e2e/journey-05-trade.spec.ts` — existing regression tests, especially the "available cash header never shows --" test that v2 broke.
- `docs/KNOWN_FAILURES.md` — do NOT report listed failures as issues introduced by your work.

**The investigation, not the fix:**

The blind agent's evidence: after submitting BUY AAPL 10 @ MARKET via the web UI, `#tt-cash-balance.textContent` stayed at `$100,000.00`. Dashboard KPI Cash tile correctly read `$97,953.37`. Closing and re-opening the dialog rendered `$97,953.37` — proving `currentSession.portfolio_metrics.cash` IS being mutated to the post-fill value somewhere.

The architecture per v3 says: post-submit IIFE mutates `currentSession.portfolio_metrics.cash` then `bus.publish('portfolio:updated', ...)`. The dialog's `dialog-state-mirror` bus subscriber calls `onUpdate` → `repaintCash()` which reads the canonical store. If reopening shows the right value but the open dialog doesn't, ONE of these is failing on the still-open dialog:

1. **Subscriber not firing.** `dialog-state-mirror.js:158` `bus.subscribe` may unsubscribe earlier than expected, OR the publish is silently dropped.
2. **`refuseClobber` blocking the update.** Check `refuseClobber(appliedValue, nextValue)` at `trade-ticket.js:226-234` — its predicate refuses when nextValue's cash is non-numeric. Verify `portfolioRes.data.cash` is actually `number`-typed in the publish path.
3. **Post-submit IIFE silently throwing.** Lines 447-498 are wrapped in try/catch with `console.error` — the blind agent didn't capture console errors. Check whether `dashFetch` returns an unexpected shape, whether `renderPortfolio` is undefined, etc.
4. **`window.finletBus.publish` undefined or alternate-window.** `trade-ticket.js:487` checks `window.finletBus`. If this is an iframe / module-isolation issue introduced by the `ea9ee7e` window aliasing, the publish lands on a different bus instance than the subscriber listens on.
5. **Order processed by different code path.** The blind agent submitted via #tt-symbol/#tt-quantity/#tt-submit. Confirm `submitOrder` (the function containing the IIFE at line 447) IS the handler bound to that submit, NOT a different function that bypasses the post-submit refetch.

**Fix scope discipline:**

- If the bug is a 1-5 line gap (missing event publish, wrong type coercion, wrong condition guard), fix it. Add ONE targeted regression test in `tests/dashboard/trade-ticket-post-submit.spec.js` that fails on `main` pre-fix and passes post-fix.
- If the bug requires architectural change (e.g., the bus subscriber needs a different lifetime, the canonical store needs different ownership, refuseClobber semantics need rework), DO NOT attempt the fix. Write `docs/bug-hunt/20260503T030227Z2009/team_a_verify.md` documenting:
  - What you found (the failure mechanism)
  - Why a 5-line patch can't close it
  - The shape of v4 (which file, which contract change)
  - And commit only the verify doc + nothing else.

**Files touched (worst case):**
- Modified: `dashboard/trade-ticket.js` — targeted fix
- Modified: `dashboard/app.js` — only if SSE handler is the gap
- Modified: `dashboard/event-contract.md` — only if event semantics change
- New / modified: `tests/dashboard/trade-ticket-post-submit.spec.js` — regression test
- Modified: `tests/e2e/journey-05-trade.spec.ts` — only if E2E coverage gap is exposed

**Files touched (escalation):**
- New: `docs/bug-hunt/20260503T030227Z2009/team_a_verify.md` (only)

**Deliverable:** Either (a) targeted fix that makes a fresh blind walk see `#tt-cash-balance` update post-fill without close+reopen, OR (b) a verify doc explaining why v4 is needed.

**Validation:**
- [ ] `uv run pytest tests/dashboard/trade-ticket-post-submit.spec.js -x -q` passes (if test added — note: this is a JS spec, run via `npx playwright test --config=tests/e2e/playwright.config.ts tests/dashboard/trade-ticket-post-submit.spec.js` if it's a Playwright test, OR via your existing JS test runner setup if not.)
- [ ] `npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-05-trade.spec.ts` passes (existing v2-regression test must still pass — open/close DOM teardown contract intact)
- [ ] OR (escalation) `team_a_verify.md` exists with the four required sections (failure mechanism, why 5-line patch fails, v4 shape, no other file changes).

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues
- Read the "Read these files first" list BEFORE writing any code
- Follow render-on-read v3 pattern. DO NOT reintroduce v2's always-on subscription (regressed: broke open/close teardown).
- DO NOT change `closeTradeTicket`'s mirror.close() — that's load-bearing per v2's regression.
- DO NOT widen scope to fix unrelated trade ticket UX issues from the triage's annoying/nice-to-have list.
- Run the existing journey-05 regression test BEFORE merging — if it fails, you've regressed v2's fix.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message must start with "[Team A]:".
- When done, report: DONE + commit hash + validation results, OR: BLOCKED + what went wrong.
