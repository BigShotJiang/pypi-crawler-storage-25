You are Team D: Documentation updates per Required Docs Updates block.

WORKING DIR: this is a git worktree forked from main at SHA 7cda2969496a4978eb064a995a55361318544ae7.

**Blocked by:** A + B (both already merged on main; their commit SHAs available via `git log --oneline main | head -10`).

**Read these files first:**

- `docs/REMAINING_TASKS.md` — most recent "Bug Hunt YYYYMMDD — Closed" subsection for pattern.
- `docs/LESSONS.md` — most recent additions for tone/format.
- `docs/ARCHITECTURE.md` — header sections to confirm no architecture change is needed (likely unchanged this iteration).
- `docs/KNOWN_FAILURES.md` — current known-failures list.
- `docs/bug-hunt/20260503T030227Z2009/triage.md` — full iteration scope.
- `docs/bug-hunt/20260503T030227Z2009/triage.json` — for finding-specific summaries.
- Team A's commit `8c55a90` and Team B's commit `cbd8340` on `main` — read what they actually changed via `git show 8c55a90 --stat` and `git show cbd8340 --stat`.

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — append "Bug Hunt 20260503T030227Z2009 — Closed" subsection
- Modified: `docs/LESSONS.md` — at least one lesson per real-broken finding (so 2 lessons minimum). Lessons must be reusable rules, NOT diff recaps. Examples: "When a bus event publish completes but a subscribed handler doesn't paint, suspect…" / "When a refactor reaches v3 and the recurrence persists, draft v4 BEFORE another patch attempt."
- Modified: `docs/ARCHITECTURE.md` — likely no change. If unchanged, state explicitly in commit message: "ARCHITECTURE.md: no architectural change this iteration."
- Modified: `docs/KNOWN_FAILURES.md` — pre-flight refresh + remove anything resolved this iteration.
- Add: `docs/decisions/` — only if a non-trivial reversible decision was made (likely none this iteration).
- Stage: ALL artifacts in `docs/bug-hunt/20260503T030227Z2009/` (plan.md, triage.md, triage.json, blind_report.json, cleanup.log, isolation_warning.txt, exec-trace.txt, team-prompts/, deploy_status.txt if present, retest_results.json if present, blind_diagnostic.log if present, team_a_verify.md if present)

**Iteration context for the lessons:**

Both real-broken findings this iteration are *recurrence-pattern* findings — they are NOT new bug classes. The patterns to extract:

1. **trade-ticket-stale-cash (4th recurrence after 3 refactor attempts):** v3 (render-on-read from canonical store, shipped 2026-05-02) was correct in shape but had a closed-panel persistent-DOM-rot gap — submitTradeTicket closes the panel BEFORE the post-submit IIFE publishes portfolio:updated, so the dialog-state-mirror is torn down by then but the `<aside>` element remains in the DOM with stale text. Team A's v3.1 fix added terminal `repaintCash()` calls at every publisher mutation+publish site (3 sites × 1 line each in `dashboard/trade-ticket.js` + `dashboard/app.js`). Lesson class: "When a refactor's design contract holds but the user-visible bug recurs, look for DOM lifecycle vs publisher lifecycle skew — publishers that fire after the consumer's lifecycle ended."

2. **plugin-ingest-no-feedback (1st instance, classification dead-affordance):** The click handler did all the right things synchronously (aria-busy, .ingest-pending, toast, button disable+relabel) but a blind 2-second `setTimeout(loadPlugins, 2000)` after the 202 ack re-rendered the row with the SAME `_pluginNeedsIngest()` predicate true (background ingest still running, server still says "Run ingestion first..."), clobbering the visible pending state. Team B's fix replaced the blind setTimeout with a recursive `pollOnce` capped at 30 ticks, gated on a snapshot of `[data-plugin-message]` — only re-renders when the server-side message text changes. Lesson class: "When pre-render UI feedback is correct in code but invisible to the user, suspect a refetch+re-render that runs before server-side state has actually changed — gate refetches on observable state-change, not blind timers."

**Deliverable:** Single docs commit referencing iteration `20260503T030227Z2009`, naming which docs were touched.

**Validation:**
- [ ] `git status docs/bug-hunt/20260503T030227Z2009/` — every artifact tracked, no untracked files in the iteration dir
- [ ] `wc -l docs/REMAINING_TASKS.md` grew by ≥4 lines (subsection + at least 2 closed items)
- [ ] `wc -l docs/LESSONS.md` grew by ≥6 lines (2 lessons minimum, ~3 lines each)
- [ ] commit message contains `20260503T030227Z2009` and `bug-hunt`

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues
- You MUST `git add` + `git commit` before finishing.
- Mirror the format of the most recent prior iteration's docs commit (see `git log --oneline -- docs/REMAINING_TASKS.md | head -10`).
- LESSONS.md entries must be REUSABLE RULES, not "we fixed X by doing Y." Pattern: "When you see <symptom>, suspect <class of cause> first. Why: <past incident>. How to apply: <where to look>."
- DO NOT modify any code (no `dashboard/`, no `finlet/`, no `tests/`).
- Your commit message must start with "[Team D]:".
- When done, report: DONE + commit hash + validation results, OR: BLOCKED + what went wrong.
