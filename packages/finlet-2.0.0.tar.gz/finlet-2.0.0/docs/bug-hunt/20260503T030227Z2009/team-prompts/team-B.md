You are Team B: Plugin Ingest — find why visual feedback isn't reaching the user.

WORKING DIR: this is a git worktree forked from main at SHA 9568aa1834c178e660210e2c4363b3b2dd7bce4b.

**Blocked by:** none — can start immediately.

**Read these files first:**

- `dashboard/settings.js:995-998` — `_pluginNeedsIngest()` predicate (substring-match `"run ingestion"` in plugin.message, case-insensitive).
- `dashboard/settings.js:1004-1007` — `renderIngestButton()` — DOM creation for the Ingest button with `data-action="ingest-plugin"`.
- `dashboard/settings.js:1107` — event delegation binding for `data-action="ingest-plugin"`.
- `dashboard/settings.js:1141-1251` — `triggerIngest()` — the click handler. Sets `aria-busy="true"` on card synchronously (line 1149), inserts `.ingest-pending` span (line 1157-1171), disables button + relabels to "Ingesting..." (line 1173-1175), shows toast on 202 (line 1195) or error (line 1209/1214), schedules `loadPlugins()` refetch after 2s on success (line 1225-1238), failure path re-enables button + clears pending (line 1239-1250).
- `dashboard/settings.js:1257-1270` — `_renderIngestRowError()` — row-level inline error renderer.
- `dashboard/settings.css:723-749` — `.plugin-config-card[aria-busy="true"]`, `.ingest-pending`, `.ingest-error` styling.
- `dashboard/app.js:314-340, 911, 1063, 1104, 1381` — `showToast` call sites + signature (object form `{type, title, message, duration}`).
- Run `git log --oneline dashboard/settings.js dashboard/settings.css | head -5` for context (`c489d53` Team A 20260502T211937Z7ddd added the row-level pending state).
- `docs/KNOWN_FAILURES.md` — do NOT report listed failures as issues introduced by your work.

**The investigation, not the fix:**

The blind agent's evidence: clicking Ingest fires POST → 202 Accepted, but the button does NOT change state, no toast appears, the row's status text does NOT update. The job DOES complete in the background (verified later).

The code at `triggerIngest` does ALL the right things synchronously — sets `aria-busy="true"`, inserts `.ingest-pending`, disables the button, calls `showToast`. So one of these is wrong:

1. **`triggerIngest` isn't being called at all.** Event delegation binding at `settings.js:1107` might be looking for a different `data-action` value than `renderIngestButton` emits, OR the button is rendered without the `data-action` attribute, OR the binding is on a stale parent that doesn't contain the button.
2. **`triggerIngest` is called but `card` lookup fails.** Line 1143: `btn.closest('.plugin-config-card')`. If the button's parent class is named differently, `card` is null and lines 1149-1171 silently no-op (every assignment is `if (card) ...`).
3. **`showToast` signature mismatch.** Compare line 1195 (`showToast('Ingestion queued${tail}', 'success')` — string + string) against the canonical `showToast` signature visible at `app.js:314` (`showToast({type, title, message, duration})` — object). If `showToast` requires an object, the string-form call silently produces no UI.
4. **CSS not loaded / not in cascade.** `.plugin-config-card[aria-busy="true"]` styling at `settings.css:733-737` may not be applying if the card class is different from `.plugin-config-card`, OR if a higher-specificity rule overrides it.
5. **`loadPlugins()` 2s refetch (line 1225-1238) clobbers the row before the user perceives the pending state.** This is unlikely — 2s is ample — but the blind agent reports `_pluginNeedsIngest`-driven row may STILL show the same "Run ingestion first" message after refetch (because the ingest is still running in the background; the next health poll hasn't yet reflected new cached files). If `loadPlugins()` re-renders the row identically, the pending indicator is replaced by a fresh non-pending button, looking like nothing happened.

**Fix scope discipline:**

- Most likely: a `showToast` signature mismatch (item 3) OR an event-delegation gap (item 1). Either is a 1-3 line fix.
- If the issue is the 2s refetch clobbering the pending state (item 5), ship a small fix that keeps the pending indicator until the row's status text actually changes (poll-and-reconcile, not blind setTimeout). Cap fix scope at the existing `triggerIngest` function.
- DO NOT add a new toast system, new polling mechanism, or new server endpoint. The existing scaffolding is sufficient.

**Files touched:**
- Modified: `dashboard/settings.js` — targeted fix in `triggerIngest` (signature, event delegation, or refetch-reconciliation)
- Modified: `dashboard/settings.css` — only if a CSS specificity issue is the root cause
- New / modified: `tests/e2e/journey-06-settings.spec.ts` — Playwright assertion that clicking Ingest produces visible pending state within 500ms AND a toast within 1s

**Deliverable:** Clicking the Ingest button on a degraded plugin row makes the row show a visible pending state and a toast appear within 1s of click. Verified by E2E test.

**Validation:**
- [ ] `npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-06-settings.spec.ts` passes (with new pending-state assertion)
- [ ] No regression in existing settings tab tests

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues
- Read the "Read these files first" list BEFORE writing any code
- Follow existing toast and event-delegation patterns in `dashboard/settings.js`.
- DO NOT replace `setTimeout(() => loadPlugins(), 2000)` with a long-poll loop — that's scope creep. If clobber is the issue, gate the refetch on a row-state check.
- DO NOT widen scope to address the news_s3 / sentiment "Ingest button missing in onboarding" finding — that was triaged needs-investigation, not real-broken.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message must start with "[Team B]:".
- When done, report: DONE + commit hash + validation results, OR: BLOCKED + what went wrong.
