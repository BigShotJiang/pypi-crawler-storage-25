## Broken (will be fixed this iteration)
- Trade Ticket 'Available Cash' shows stale value after a trade is submitted while the ticket remains open [evidence: "After submitting BUY AAPL 10 @ market (which filled at $204.66, spending $2,046.63), document.getElementById('tt-cash-balance').textContent was '$100,000.00'. Dashboard KPI 'Cash' correctly showed '$97,953.37'. Re-opening the Trade Ticket (clicking #btn-trade again) then correctly displayed '$97,953.37'. The reactive binding on #tt-cash-balance does not update on order fill — only on ticket open."] [scope hint: dashboard/trade-ticket.js, dashboard/app.js]
- Plugin Ingest gives zero user feedback — no spinner, toast, status change, or progress indicator [evidence: "Clicking 'Ingest' on the price plugin fired POST /v1/plugins/price/ingest → 202 Accepted. The button did not change state, no notification appeared, and the status paragraph still read 'No price data available for the last 7 days. Run ingestion first.' The job ran in the background and succeeded (verified on dashboard: 'OK — 5 cached files'), but the user gets no indication that anything happened."] [scope hint: dashboard/settings.js, dashboard/settings.css]

## Logged (not actioned)
- Finlet benchmark MCP tool not loaded in evaluation environment [classification: needs-investigation]
- news_s3 and sentiment plugins are degraded with no data and Ingest was not triggered for them — leaving two data types unavailable [classification: needs-investigation]
- No 'Fundamentals Strategy' concept exists in the UI — task step has no mapped flow [classification: annoying]
- Dashboard on first login has three simultaneous layered dialogs competing for attention [classification: annoying]
- Clock starts FROZEN with no explanation; keyboard shortcut hint is the only guidance [classification: annoying]
- 'Run first analysis' checklist item auto-checked after placing a trade, which is a misleading label [classification: annoying]
- Settings nav has two near-identical buttons: 'API Keys & Security' and 'API Keys' [classification: annoying]
- Plugin names are opaque technical identifiers with no plain-English description in the settings card [classification: annoying]
- A 'Fundamentals Strategy' session template in the session creator [classification: nice-to-have]
- Ingestion progress: real-time status updates or completion notification after clicking Ingest [classification: nice-to-have]
- Reasoning field in the web Trade Ticket so UI-submitted orders don't always show '—' in the Order Log [classification: nice-to-have]
- A guided plugin setup wizard — especially for API-key-dependent plugins (finnhub, fred, edgar) [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   $TS — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made.
6. `docs/bug-hunt/$TS/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log,
   deploy_status.txt, retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"$TS","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline.
   Team D MUST stage the file. If a refactor verdict pruned entries this
   iteration, Team D MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`.

Team D's commit message must reference iteration $TS and name which docs were
touched (e.g., "docs: bug-hunt $TS — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").

## Iteration context for /plan-features

**CRITICAL — trade-ticket-stale-cash is a 4th-recurrence after 3 refactor attempts.**

Prior context the planner MUST consider:
- v1 refactor `efdd443` (open-then-subscribe + on-open prime) shipped 2026-04-30, verdict: effective
- patch `d6e1bd5` iter 7b36 (post-submit refetch+republish in submitOrder) shipped 2026-05-02, verdict: patch-ineffective
- v2 refactor `c712d98` (always-on subscription) shipped 2026-05-02, verdict: regressed (broke open/close DOM teardown)
- v3 refactor `ea9ee7e` (render-on-read from canonical store) shipped 2026-05-02 deploy 25266871370 success — currently being verified by THIS iteration
- This iteration's blind report: "reactive binding on #tt-cash-balance does not update on order fill — only on ticket open" → v3 IS PATCH-INEFFECTIVE

The Team A worker MUST:
1. Read `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` first to understand v3's contract.
2. Read `dashboard/trade-ticket.js`'s `repaintCash()` and the order:filled / portfolio:updated bus subscribers to find why repaintCash isn't called post-fill on the open dialog.
3. The fix is likely a one-line gap (e.g., order:filled handler doesn't fire repaintCash, or canonical store mutation order is wrong) — NOT another full refactor.
4. If the fix requires architectural change beyond a 5-line gap, STOP and document in `team_a_verify.md` so v4 can be drafted.
