## Broken (will be fixed this iteration)
- Trade Ticket "Available Cash" field renders blank after a BUY order submission while the panel remains open (UI state desyncs from backend state — backend-known cash exists but UI shows empty value) [evidence: "When Trade Ticket panel is first opened on a fresh session it correctly shows 'AVAILABLE CASH $100,000.00'. After submitting a BUY AAPL order and the panel remains/is reopened, the Available Cash value renders as blank — the label is present but the dollar figure is gone."] [scope hint: dashboard/trade-ticket.js, dashboard/app.js, dashboard/index.html]
- Equity curve TradingView Y-axis auto-scales to a $0.04 range around $99,999.94 after a single $2,046.63 BUY on $100k starting capital, rendering the equity trajectory as a flat horizontal line (chart-display contract violated — equity should remain ~$100k and chart Y-axis should reflect a meaningful range anchored to starting capital, not a 4-cent zoom that hides every other portfolio data point) [evidence: "After buying 10 shares of AAPL for $2,046.63 the TradingView chart auto-scaled its Y-axis to a $0.04 range around ~$99,999.94, making the equity curve appear as a horizontal flat line with no visible variation. ... Expected: Y-axis should span a meaningful range anchored to starting capital ($100,000)."] [scope hint: dashboard/app.js, dashboard/index.html]
- Overview "SIM TIME" card always truncates the timestamp ("S025-05-..." instead of "2025-05-05 00:00:00 UTC") with no tooltip or alternate way to read the value (display contract violated — card's job is to display the sim time but it cannot show the data) [evidence: "The Overview 'SIM TIME' card consistently renders 'S025-05-…' (truncated). The actual sim time is '2025-05-05 00:00:00 UTC' but the card is not wide enough to show it. No tooltip on hover. A user cannot read the simulation date from the overview without opening the full-page date display in the header."] [scope hint: dashboard/styles.css, dashboard/index.html]

## Logged (not actioned)
- Finlet benchmark MCP not accessible from a fresh Claude Code session — agent observed no finlet MCP tools in deferred tool registry but did not actually attempt to invoke them; launcher wires `finlet mcp` via stdio, so visibility-without-invocation evidence is inconclusive [classification: needs-investigation]
- No "Fundamentals Strategy" setup flow — task wording matches no UI affordance; fundamentals_s3 plugin is already healthy out-of-the-box but the discoverability copy is the rough surface, not a contract violation [classification: annoying]
- Double-hyphen vs em-dash inconsistency in Plugin Configuration status messages ("OK -- 21 cached files" vs "OK — 6 cached files") — copy hygiene only, both message paths function correctly [classification: annoying]
- Page title inconsistency between app ("AI Trading Agent ITE") and landing ("AI Trading Agent Backtesting Platform"); "ITE" never expanded — copy-only, no functional impact [classification: annoying]
- Plugin Health dashboard widget shows 5 red/amber plugins on first load with no severity guidance — all five are correctly degraded (cold-cache or unconfigured optional plugins); no false-positive contract violation, just missing optional/required severity hints in copy [classification: annoying]
- Session Name field does not auto-fill when "Tech Growth" template is clicked (Conservative ETF default fills, then clearing on Tech Growth click leaves it blank) — session creation still works, name field is editable, no state contradiction [classification: annoying]
- Trade fill price multiplication: 10 × $204.66 displayed = $2,046.60 but Total Cost shows $2,046.63 (engine computes at 6dp internally, displays at 2dp) — disclosure-only gap, math is internally consistent and the recently-shipped commission/slippage_amount/total_cost columns address this for new orders; this is the same disclosure shape as ledger order-cash-disclosure-undisclosed-delta (already fixed iter 20260503T230405Z2601), repeating only because the user-visible per-share fill_price still rounds to 2dp [classification: annoying]
- Two competing onboarding mechanisms fire simultaneously — wizard dialog AND bottom checklist — both function correctly in isolation; UX duplication is rough but neither contract is violated [classification: annoying]
- Reasoning Trace entries show bare "details" links with no preview of contents (no hover, no inline expansion) — links are functional, content reachable, just no preview [classification: annoying]
- No simulation end date in session creation — feature gap, not a broken contract; current 1x/10x/60x/3600x play-speed flow works as designed [classification: nice-to-have]
- Manual Trade Ticket has no "Reasoning" field — Order Log REASONING column shows '—' for human-placed trades — feature gap; no contract violation since the field is documented as agent-rationale-only [classification: nice-to-have]
- Plugin Health dashboard widget has no inline "Ingest" trigger for news_s3/sentiment (Settings → Plugins has the button) — discoverability gap; navigation path exists [classification: nice-to-have]
- No session description/notes field at session creation time — feature gap; only Name/Capital/Start Date supported by design [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260505T175445Z750b — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. `docs/bug-hunt/20260505T175445Z750b/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log,
   deploy_status.txt, retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260505T175445Z750b","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline (see
   Phase 5.5c). Team D MUST stage the file. If a refactor verdict pruned entries
   this iteration, Team D MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`
   (the audit log of resolved signals).

Team D's commit message must reference iteration 20260505T175445Z750b and name which docs were
touched (e.g., "docs: bug-hunt 20260505T175445Z750b — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
