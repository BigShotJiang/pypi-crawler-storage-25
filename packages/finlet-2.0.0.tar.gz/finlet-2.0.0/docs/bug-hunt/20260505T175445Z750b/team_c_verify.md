# Team C Verify — SIM TIME card timestamp truncates ("S025-05-...")

> Bug-hunt iteration `20260505T175445Z750b`. Branch `worktree-agent-aea83571bf5d3639a`. Spawn base SHA `f04c1a2`.

## Root cause (from triage)

The Overview "SIM TIME" card (`#sim-time`) is the first `.stat-card` on the dashboard, marked `.stat-card--primary`. The `.stat-card` rule at `dashboard/styles.css:783-784` sets `min-width: 150px; flex: 1` — that's roughly 12 characters at 20px mono. The `.stat-value` rule at `dashboard/styles.css:815-816` then sets `overflow: hidden; text-overflow: ellipsis` unconditionally.

`renderClock()` was writing the 24-character `formatDateTime(simTime)` output (`YYYY-MM-DD HH:MM:SS UTC`) to that 12-char-wide tile. The CSS truncated it; the blind agent screenshot reported `S025-05-...` (the leading `2` glyph clipped to look like `S` at the agent's zoom level).

The unconditional ellipsis came from bug-hunt `20260503T230405Z2601` Team A (commit `828003d`), which added `overflow: hidden + text-overflow: ellipsis` plus `hyphens: none; word-break: keep-all; white-space: nowrap` to fix em-dash artefacts. Those rules are correct — they're just over-applying because the content didn't fit.

## Fix approach

Option 1 from the plan: shorten the content rendered to the tile, expose the full timestamp via `title=` for hover tooltip. Header bar (`#header-sim-time`) keeps the full format.

Three concrete diffs:

### `dashboard/app.js` — `renderClock()` (lines 1898-1916)

```javascript
function renderClock(clock) {
    const simTime = clock.current_time || clock.sim_time || '--';
    const mode = (clock.mode || '').toLowerCase();

    // Overview SIM TIME card has min-width:150px (~12 chars at 20px mono);
    // the full 24-char `YYYY-MM-DD HH:MM:SS UTC` does not fit and the
    // unconditional `text-overflow: ellipsis` on `.stat-value` (added by
    // bug-hunt 20260503T230405Z2601 Team A to prevent em-dash artefacts)
    // would clip it to e.g. "2025-05-…". Render date-only on the tile and
    // expose the full timestamp via `title=` for hover tooltips. The
    // header bar's `#header-sim-time` keeps the full format unchanged.
    // See bug-hunt 20260505T175445Z750b Team C.
    const fullSimTime = formatDateTime(simTime);
    const shortSimTime = formatDateShort(simTime) || '--';
    const simEl = document.getElementById('sim-time');
    simEl.textContent = shortSimTime;
    simEl.setAttribute('title', fullSimTime);
    document.getElementById('header-sim-time').textContent = fullSimTime;
    // ...
```

`formatDateShort('--')` → `'--'` (catches the placeholder via the try/catch path); the `|| '--'` guard handles the empty-string case from `formatDateShort('')`.

### `dashboard/index.html` (line 174)

```html
<div class="stat-value" id="sim-time" title="--">--</div>
```

Initial `title="--"` so screen readers / hover see a label before the first `renderClock` fires.

### `dashboard/styles.css` — UNCHANGED

The `hyphens/word-break/keep-all/white-space` rules at lines 811-814 are preserved (em-dash artefact prevention). The `text-overflow: ellipsis + overflow: hidden` rules at lines 815-816 are kept as a safety net — they no longer trigger because the date-only string fits in 150px, but they protect against any future surface that might still feed long content into a `.stat-value` tile.

## Regression assertion (added)

Extended `tests/e2e/journey-sim-time-tile.spec.ts` with one new test case (`#sim-time renders date-only with full UTC timestamp on title= (bug-hunt 20260505T175445Z750b)`) that:

1. Stubs `**/v1/sessions/*/state` so the dashboard's 2s poll uses a deterministic `current_time`.
2. Calls `window.renderClock({ current_time: '2025-05-05T00:00:00Z', mode: 'frozen' })` directly to drive the real production code path.
3. Asserts:
   - `#sim-time` textContent matches `^\d{4}-\d{2}-\d{2}$` (10-char date).
   - `#sim-time` `title=` attribute matches `^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} UTC$` (full UTC timestamp).
   - `#header-sim-time` keeps the full datetime format (`^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} UTC$`) — pin the no-regress contract for the header bar.

Also updated the existing test (`#sim-time renders full ISO datetime with no em-dash and pinned no-hyphenation CSS` → renamed to `#sim-time renders date-only with no em-dash and pinned no-hyphenation CSS`) to:
- Drive the real `window.renderClock()` path instead of seeding `el.textContent` directly with the (now-stale) full ISO format.
- Assert the new short-date contract while keeping the em-dash / no-hyphenation invariants intact (those still apply class-wide on `.stat-value`).

The third test (`.stat-value rule applies the no-hyphenation contract to all stat tiles`) is unchanged — it pins computed CSS, not textContent.

## Validation output

Worktree `dashboard/` was served via a separate `finlet serve --port 8001` instance with `FINLET_DASHBOARD_DIR=<worktree>/dashboard`, and Playwright was pointed at `localhost:8001` for the duration of the run.

```
$ npx playwright test --config=tests/e2e/playwright.config.ts \
    tests/e2e/journey-sim-time-tile.spec.ts --reporter=line
[global-setup] Authenticated as test@finlet.dev, storageState saved

Running 3 tests using 1 worker

[1/3] [chromium] › tests/e2e/journey-sim-time-tile.spec.ts:42:7 › Sim Time tile renders without CSS hyphenation artefact › #sim-time renders date-only with no em-dash and pinned no-hyphenation CSS
[2/3] [chromium] › tests/e2e/journey-sim-time-tile.spec.ts:147:7 › Sim Time tile renders without CSS hyphenation artefact › #sim-time renders date-only with full UTC timestamp on title= (bug-hunt 20260505T175445Z750b)
[3/3] [chromium] › tests/e2e/journey-sim-time-tile.spec.ts:219:7 › Sim Time tile renders without CSS hyphenation artefact › .stat-value rule applies the no-hyphenation contract to all stat tiles
3 passed (1.8s)
```

Sanity-check passes for the only other journeys that touch `#header-sim-time`:

```
$ npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-04-dashboard.spec.ts --reporter=line
9 passed (27.4s)

$ npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-05-trade.spec.ts --reporter=line
1 skipped
10 passed (19.7s)
```

The `1 skipped` in journey-05 is a pre-existing skip path ("Local MARKET order REJECTED (no S3 price data); skipping v3 close-reopen assertion") not related to this iteration.

```
$ uv run ruff check dashboard/
warning: No Python files found under the given path(s)
All checks passed!
```

After validation, the temporary `localhost:8001` baseURL changes were reverted in `tests/e2e/playwright.config.ts`, `tests/e2e/fixtures.ts`, and `tests/e2e/global-setup.ts` (none of those files are in the team's allowed-touch list, so they remain at `localhost:8000` in the final commit).

## Files touched

- `dashboard/app.js` — `renderClock()` updated (16-line diff: split the single full-format write into a short-format write + `title=` attribute set).
- `dashboard/index.html` — line 174 gains an initial `title="--"` attribute.
- `tests/e2e/journey-sim-time-tile.spec.ts` — existing test 1 updated to the new contract; one new test case added pinning the date-only textContent + `title=` full UTC timestamp + `#header-sim-time` non-regression.
- `dashboard/styles.css` — UNCHANGED. (hyphens/word-break/white-space rules preserved; ellipsis kept as safety net.)
- `docs/bug-hunt/20260505T175445Z750b/team_c_verify.md` — this file.

## Out of scope (not touched)

- `dashboard/trade-ticket.js` (Team A territory)
- SSE handlers around `dashboard/app.js:1456-1670` (Team A)
- Chart code around `dashboard/app.js:2080-2446` (Team B)
- `#header-sim-time` rendering format (preserved unchanged)
