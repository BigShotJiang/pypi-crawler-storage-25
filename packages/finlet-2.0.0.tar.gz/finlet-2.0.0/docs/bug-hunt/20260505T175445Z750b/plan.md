# Bug-Hunt 20260505T175445Z750b — Execution Plan

> Generated from `docs/bug-hunt/20260505T175445Z750b/triage.md`. Iteration baseline SHA: `f04c1a2`. Last updated: 2026-05-05.

## Constraints

- Patch-only iteration. No refactors. The refactor gate already passed the pre-flight check (pending_recurrences empty, no `status: ready` queue docs).
- All three real-broken findings are in `dashboard/` only. No backend, no API, no plugin code.
- Two of three findings are forward-signals to prior ledger entries:
  - Finding 1 (`trade-ticket-cash-blank-after-buy`) → `same_root_cause_as: trade-ticket-stale-cash` — the v3.1 fix at commit `8c55a90` is in place; symptom mutated from "stale value" to "blank value", not regressed-to-stale. Treat as **patch-incomplete**, not patch-regressed: the canonical-store render-on-read contract still holds, but a different path (likely `openTradeTicket()` line 150 dropping `tradeTicketCashBalance` to null + a race against the post-submit IIFE's splice) leaves the panel showing "Loading..." or empty before the dashFetch resolves.
  - Finding 3 (`sim-time-card-truncates`) → `same_root_cause_as: sim-time-tile-em-dash-artefact` — the 828003d fix added unconditional `overflow: hidden + text-overflow: ellipsis` to `.stat-value`. That CSS is now over-applying on the narrow `.stat-card--primary` cell at desktop widths.
- Finding 2 (`equity-curve-y-axis-collapse`) is new (no `same_root_cause_as`). Bug is in chart Y-axis auto-scale behavior with low-variance data.

## File Conflict Table

| File | Touched by Teams |
|------|-----------------|
| `dashboard/app.js` | A, B, C |
| `dashboard/index.html` | A, C |
| `dashboard/trade-ticket.js` | A |
| `dashboard/styles.css` | C |
| `tests/e2e/journey-05-trade.spec.ts` | A |
| `tests/e2e/journey-04-clock-control.spec.ts` (or similar) | B |
| `tests/e2e/journey-02-session-create.spec.ts` (or similar) | C |
| `docs/REMAINING_TASKS.md` | D |
| `docs/LESSONS.md` | D |
| `docs/ARCHITECTURE.md` | D |
| `docs/KNOWN_FAILURES.md` | D |
| `docs/bug-hunt/20260505T175445Z750b/*` | D |
| `docs/bug-hunt/ledger.jsonl` | E |
| `docs/bug-hunt/pending_recurrences.jsonl` (and `.resolved.jsonl`) | E |

## Dependency Graph

- Team A (Trade Ticket cash) — independent — can start immediately.
- Team B (Equity curve Y-axis) — touches `dashboard/app.js`, sequences after A's merge.
- Team C (SIM TIME card) — touches `dashboard/app.js` + `dashboard/index.html` + `dashboard/styles.css`, sequences after B's merge.
- Team D (Docs) — depends on A, B, C completion (needs final commit SHAs and verify reports).
- Team E (Ledger) — depends on D completion (Team D writes the doc artifacts; Team E records the ledger lines and updates pending_recurrences).

## Critical Path

Team A → Team B → Team C → Team D → Team E

Estimated: 5 teams × ~10–15 min/team = 50–75 min wall-clock with sequential merges.

---

## Teams

### Team A: Trade Ticket Available Cash blank after BUY

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/trade-ticket.js:1-90` — Trade ticket state, getCanonicalCash, repaintCash, fetchCashBalance contracts.
- `dashboard/trade-ticket.js:120-245` — openTradeTicket and dialogStateMirror wiring.
- `dashboard/trade-ticket.js:347-552` — submitTradeTicket post-submit IIFE (the v3.1 terminal repaintCash site).
- `dashboard/app.js:1456-1511` — SSE `portfolio` handler with terminal repaintCash.
- `dashboard/app.js:1525-1670` — SSE `orders` deferred-refetch IIFE with terminal repaintCash.
- `dashboard/dialog-state-mirror.js` — primeFromCache + onOpen ordering contract.
- `docs/decisions/trade-ticket-render-on-read.md` — v3 contract that REQUIRES payload values to be ignored.
- `docs/refactor-queue/trade-ticket-state-sync-v3.md` — v3.1 verdict (the fix was scoped to closed-panel persistent-DOM rot).

**Recon evidence (verified by recon agent against HEAD `f04c1a2`):**

```javascript dashboard/trade-ticket.js:7-42
let tradeTicketOpen = false;
let tradeTicketCashBalance = null;
// Per-open mirror handle, set on open() and closed on close(). Owns the
// bus subscription + last-applied-cash state for the dialog's lifetime.
let tradeTicketMirror = null;

// Single canonical reader. Order: session-state mirror → bus last-published cache → undefined.
function getCanonicalCash() {
    const sess = (typeof currentSession !== 'undefined') ? currentSession : null;
    if (sess && sess.portfolio_metrics && typeof sess.portfolio_metrics.cash === 'number'
        && !Number.isNaN(sess.portfolio_metrics.cash)) {
        return sess.portfolio_metrics.cash;
    }
    if (window.finletBus && typeof window.finletBus.getLastPublished === 'function') {
        const last = window.finletBus.getLastPublished('portfolio:updated');
        if (last && typeof last.cash === 'number' && !Number.isNaN(last.cash)) {
            return last.cash;
        }
    }
    return undefined;
}

function repaintCash() {
    const cash = getCanonicalCash();
    const cashDisplay = document.getElementById('tt-cash-balance');
    if (!cashDisplay) return;
    if (typeof cash !== 'number') return;
    tradeTicketCashBalance = cash;
    cashDisplay.textContent = '$' + Number(cash).toLocaleString('en-US',
        { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
```

```javascript dashboard/trade-ticket.js:135-160
function openTradeTicket() {
    const panel = document.getElementById('trade-ticket-panel');
    const backdrop = document.getElementById('trade-ticket-backdrop');
    const trigger = document.getElementById('btn-trade');

    if (!panel) return;

    tradeTicketOpen = true;
    panel.classList.add('trade-ticket--open');
    if (backdrop) backdrop.classList.add('trade-ticket-backdrop--visible');
    if (trigger) trigger.setAttribute('aria-expanded', 'true');

    // Drop any stale cached balance — the mirror's primeFromCache /
    // last-published cache will repopulate immediately, and the always-on
    // refetch in onOpen guarantees a /portfolio round-trip on every open.
    tradeTicketCashBalance = null;
    ...
```

```javascript dashboard/trade-ticket.js:275-320
async function fetchCashBalance() {
    if (!currentSessionId) return;
    const cashDisplay = document.getElementById('tt-cash-balance');
    if (!cashDisplay) return;

    // Only show "Loading..." when we have no cached / seeded value.
    if (tradeTicketCashBalance === null) {
        cashDisplay.textContent = 'Loading...';
    }
    ...
    if (result.ok && result.data) {
        const cash = result.data.cash !== undefined ? result.data.cash : null;
        if (typeof cash === 'number' && !Number.isNaN(cash)) {
            // Render-on-read v3 atomic-mutate-then-paint contract:
            if (typeof currentSession !== 'undefined' && currentSession) {
                if (!currentSession.portfolio_metrics) currentSession.portfolio_metrics = {};
                currentSession.portfolio_metrics.cash = cash;
            }
            repaintCash();
        } else if (tradeTicketCashBalance === null) {
            cashDisplay.textContent = '--';
        }
    } else if (tradeTicketCashBalance === null) {
        cashDisplay.textContent = '--';
    }
}
```

```javascript dashboard/trade-ticket.js:412-524
if (result.ok) {
    showToast({ ... });
    closeTradeTicket();   // line 418 — tears down mirror, panel DOM stays
    resetTradeForm();     // line 419

    // ...the post-submit IIFE...
    const sid = currentSessionId;
    (async () => {
        try {
            const portfolioRes = await dashFetch(`/sessions/${sid}/portfolio`);
            if (currentSessionId !== sid) return;
            if (!portfolioRes.ok || !portfolioRes.data) return;

            // Re-render Overview metric cards inline
            if (typeof renderPortfolio === 'function') { renderPortfolio(portfolioRes.data); }

            // Splice cash + total_value onto currentSession.portfolio_metrics
            if (typeof currentSession !== 'undefined' && currentSession && ...) {
                if (typeof portfolioRes.data.cash === 'number' && !Number.isNaN(portfolioRes.data.cash)) {
                    currentSession.portfolio_metrics.cash = portfolioRes.data.cash;
                }
            }

            // Republish portfolio:updated
            window.finletBus.publish('portfolio:updated', portfolioRes.data);

            // Render-on-read v3.1 — terminal repaintCash
            repaintCash();
        } catch (err) { ... }
    })();
}
```

The render-on-read v3.1 invariant is preserved at HEAD: `submitTradeTicket()` calls `closeTradeTicket()` (which tears down `tradeTicketMirror`), then the post-submit IIFE awaits `dashFetch /portfolio`, splices `currentSession.portfolio_metrics.cash`, publishes `portfolio:updated`, and ends with a terminal `repaintCash()` that reads canonical and writes `#tt-cash-balance`. (verified by recon agent against HEAD `f04c1a2`)

**Hypothesis (Team A must verify locally before fixing):**

The blind agent observed BLANK (the dollar figure is gone) after BUY. With the render-on-read contract preserved, the only paths that produce a non-numeric cash render are:
1. `repaintCash()` returns silently when `getCanonicalCash()` returns undefined — the persistent DOM keeps its prior text. This is **NOT blank** — it's whatever was last painted.
2. `fetchCashBalance()` line 286 writes `"Loading..."` when `tradeTicketCashBalance === null` — could LOOK blank in a screenshot.
3. `fetchCashBalance()` line 315/318 writes `"--"` when both `tradeTicketCashBalance === null` AND the dashFetch failed/returned no `cash` — could LOOK blank.

The most likely root cause is the **race between the post-submit IIFE's splice and the user's re-open**:
- Post-submit IIFE awaits `dashFetch /portfolio`. This is async — typically resolves in 50-200ms, but if the API is slow, it can take longer.
- `openTradeTicket()` resets `tradeTicketCashBalance = null` (line 150).
- Mirror's `primeFromCache` reads `currentSession.portfolio_metrics.cash` — if the IIFE hasn't yet completed its splice, this returns the pre-fill cash (from the SSE handler's prior splice), NOT undefined.
- Mirror's `onOpen` calls `repaintCash()` — paints the pre-fill cash, sets `tradeTicketCashBalance`.
- Mirror's `onOpen` also calls `refetch()` → `fetchCashBalance()` — `tradeTicketCashBalance !== null` so skips "Loading..." path. Awaits dashFetch. On success: paints post-fill cash.

Under this hypothesis, the blind agent should have observed the pre-fill cash transitioning to post-fill cash. NOT blank.

**More plausible hypothesis (the actual root cause):** `currentSession.portfolio_metrics.cash` is undefined because the BUY response did not splice it (or was reset by another code path). Specifically: at `dashboard/trade-ticket.js:467-481`, the post-submit IIFE checks `if (!currentSession.portfolio_metrics || typeof !== 'object')` and sets `currentSession.portfolio_metrics = {}` — clobbering any prior shape. If `portfolioRes.data.cash` is `undefined` (server returned no cash field) or `NaN`, the cash splice is skipped (lines 473-476 require `typeof number && !NaN`). Net result: `currentSession.portfolio_metrics.cash` is now undefined. On re-open, `getCanonicalCash()` falls through to `bus.getLastPublished('portfolio:updated').cash` — but the post-submit IIFE just published `portfolioRes.data` which also lacks cash → fallback also undefined. `repaintCash()` returns silently. `fetchCashBalance()` finds `tradeTicketCashBalance === null` and writes `"Loading..."`.

Investigation must verify:
- What does `GET /sessions/{id}/portfolio` return after a BUY? Does the response include `cash`?
- Is there a code path that clobbers `currentSession.portfolio_metrics.cash` to undefined between BUY-success and re-open?
- Does the `journey-05` E2E test exercise the full close-then-reopen path on the SAME panel DOM?

**Files touched:**
- Modified: `dashboard/trade-ticket.js` — likely 2-10 lines added/changed in the post-submit IIFE region (lines 446-524) and/or `repaintCash()` to be more defensive when canonical is undefined.
- Modified: `dashboard/app.js` — possibly a 1-3 line guard in the SSE `portfolio` handler (lines 1456-1511) or the SSE `orders` deferred-refetch IIFE (lines 1525-1670).
- Possibly modified: `dashboard/index.html` — only if the fix changes the `tt-cash-balance` element initial text or attributes (unlikely, scope as optional).
- Modified: `tests/e2e/journey-05-trade.spec.ts` (or new spec) — add a regression assertion for the close-and-reopen path: after BUY → close → reopen, `#tt-cash-balance` text must match the post-fill cash via canonical (NOT empty, NOT "Loading...", NOT pre-fill).

**Deliverable:** After this team merges, opening the Trade Ticket panel after a BUY must show the post-fill cash within ≤500ms of click — never blank, never "Loading..." persisting beyond the dashFetch round-trip, never the pre-fill cash sticking.

**Validation:**
- [ ] `uv run pytest tests/e2e/journey-05-trade.spec.ts -x -q` passes (existing tests + new regression).
- [ ] Manual repro on local dev: create session → BUY 10 AAPL → close trade ticket → re-open → verify cash is post-fill, not blank.
- [ ] `npx ruff check` and `npm run lint` (if dashboard linter exists) pass.
- [ ] Existing journey-05 poison-publish-after-close assertion at `tests/e2e/journey-05-trade.spec.ts:447-463` still passes (do NOT regress the v3.1 closed-panel persistent-DOM rot fix).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Worktree-isolated work that doesn't commit is lost.
- Reproduce the bug LOCALLY first via `uv run finlet serve` + a manual browser session. Capture the exact `#tt-cash-balance.textContent` value at each step (open / submit / close / reopen).
- Only then write the fix. Do NOT add a defensive splice that makes the symptom invisible without verifying the root cause.
- Preserve the v3.1 render-on-read contract: `repaintCash()` must continue to read canonical-only; never trust payload values.
- Add ONE regression assertion to `tests/e2e/journey-05-trade.spec.ts` (or the most relevant spec) covering the BUY → close → reopen cash-display path. Do NOT bypass with a `value`-pinning or SSE-stub workaround — feedback `feedback_e2e_smoke_too_narrow` is in scope here.
- Report a recon-paraphrased root cause in `team_a_verify.md` BEFORE writing the fix. If the root cause cannot be reproduced locally, demote the finding to `needs-investigation` in `triage.json` and skip the fix.

---

### Team B: Equity curve Y-axis collapses to $0.04 range after first trade

**Blocked by:** Team A merge (shared file: `dashboard/app.js`).

**Read these files first:**
- `dashboard/app.js:2370-2446` — `initChart()` LightweightCharts configuration.
- `dashboard/app.js:2079-2155` — `renderEquityCurve()` data feed and `equityChart.timeScale().fitContent()`.
- TradingView Lightweight Charts docs (cached in `node_modules/lightweight-charts` if present, otherwise `https://tradingview.github.io/lightweight-charts/docs`) for `priceScale.applyOptions`, `setVisibleRange`, `autoScale`.

**Recon evidence (verified by recon agent against HEAD `f04c1a2`):**

```javascript dashboard/app.js:2378-2400
equityChart = LightweightCharts.createChart(container, {
    layout: {
        background: { type: 'solid', color: '#161b22' },
        textColor: '#9198a1',
        fontFamily: "'SF Mono', 'Cascadia Code', 'Fira Code', 'Consolas', monospace",
    },
    grid: {
        vertLines: { color: '#21262d' },
        horzLines: { color: '#21262d' },
    },
    crosshair: { mode: LightweightCharts.CrosshairMode.Normal },
    rightPriceScale: { borderColor: '#30363d' },
    timeScale: { borderColor: '#30363d', timeVisible: true },
    handleScroll: true,
    handleScale: true,
});
```

```javascript dashboard/app.js:2402-2413
equitySeries = equityChart.addLineSeries({
    color: '#58a6ff',
    lineWidth: 2,
    title: 'Portfolio',
});

benchmarkSeries = equityChart.addLineSeries({
    color: '#9198a1',
    lineWidth: 1,
    lineStyle: LightweightCharts.LineStyle.Dashed,
    title: 'Buy & Hold',
});
```

```javascript dashboard/app.js:2095-2134
const equityData = snapshots.map((s) => ({
    time: toChartTime(s.timestamp || s.time),
    value: s.total_value ?? s.value ?? 0,
})).sort((a, b) => a.time - b.time);

// Deduplicate timestamps (Lightweight Charts requires unique times)
const deduped = [];
const seen = new Set();
for (const pt of equityData) {
    if (!seen.has(pt.time)) {
        seen.add(pt.time);
        deduped.push(pt);
    }
}

equitySeries.setData(deduped);
// ...benchmarkSeries.setData(...)
equityChart.timeScale().fitContent();
```

The chart at HEAD has NO Y-axis range configuration. `rightPriceScale` only sets `borderColor`. The `autoScale` option is not specified — it defaults to `true`, meaning Y-axis fits to data range. With one or few low-variance equity points (e.g., $99,999.94 ± $0.04 around starting capital), the Y-axis collapses to that ~$0.04 window. (verified by recon agent against HEAD `f04c1a2`)

**Hypothesis (Team B can act on this without further investigation):**

LightweightCharts auto-scales Y-axis to fit data. When equity changes only by cents (small fill on a small position vs $100k starting capital), the visible price range becomes meaningless — chart looks like a flat line. The fix: configure `rightPriceScale` to expand the visible range to a meaningful window anchored to starting capital.

Two viable approaches:
1. **Pin the visible range explicitly** when starting capital is known: after `equitySeries.setData(deduped)`, compute `[startingCapital * 0.5, startingCapital * 1.5]` as visible-range floor/ceiling and call `equityChart.priceScale('right').applyOptions({ autoScale: false })` + use a baseline series option.
2. **Force a minimum range expansion** via `priceScale.applyOptions({ scaleMargins: { top: 0.2, bottom: 0.2 } })` plus a "minimum chart Y-span" computed at render time. If `max - min < 0.05 * startingCapital`, pad the data series with two invisible anchor points at `startingCapital ± 0.05 * startingCapital` to force the auto-scale to expand.

Recommended: approach 1 (explicit range) is cleaner. Reference: TradingView docs `priceScale.applyOptions` with `autoScale: false`. After data set, call `equityChart.timeScale().fitContent()` to keep the X-axis behavior, but pin Y-axis to the starting-capital-anchored range read from `currentSession.config.starting_capital` (or fall back to the first equity value).

**Files touched:**
- Modified: `dashboard/app.js` — ~10-25 lines in `initChart()` (lines 2378-2400) and/or `renderEquityCurve()` (lines 2095-2134) to configure Y-axis range.
- Modified: `tests/e2e/journey-04-clock-control.spec.ts` (or whichever E2E covers equity-curve rendering — verify via grep) — add an assertion that after the first FILLED order, `window.__finletEquitySeries.options().priceScale().options()` reports a price range >= 5% of starting capital (or equivalent).

**Deliverable:** After this team merges, the equity curve Y-axis must span a meaningful range relative to starting capital — never a sub-cent zoom that hides equity trajectory variance.

**Validation:**
- [ ] `uv run pytest tests/e2e/journey-04-*.spec.ts -x -q` passes (existing tests + new regression).
- [ ] Manual repro: create session ($100k start) → BUY 10 AAPL → verify equity curve Y-axis spans >=$1000, not $0.04.
- [ ] `npx ruff check` and dashboard linters pass.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Read the LightweightCharts docs for `priceScale.applyOptions` BEFORE writing the fix. The library has multiple ways to configure Y-axis; pick the simplest.
- Do NOT remove the `equityChart.timeScale().fitContent()` call at line 2134 — that controls X-axis (time) which is separate.
- Preserve the buffered-history replay at lines 2439-2445 (`_pendingEquityHistory`).

---

### Team C: SIM TIME card timestamp truncates ("S025-05-...")

**Blocked by:** Team B merge (shared file: `dashboard/app.js`).

**Read these files first:**
- `dashboard/styles.css:770-825` — `.overview-grid`, `.stat-card`, `.stat-card--primary`, `.stat-value` rules.
- `dashboard/index.html:165-210` — Overview panel markup (sim-time card is the first stat-card).
- `dashboard/app.js:1898-1908` — `renderClock()` writes formatted datetime to `#sim-time`.
- `dashboard/app.js:2520-2528` — `formatDateTime()` returns `YYYY-MM-DD HH:MM:SS UTC` (24 chars).
- `docs/refactor-queue/sim-time-tile-em-dash-artefact` ledger entry (commit `828003d`) — the prior fix that added `text-overflow: ellipsis` unconditionally.

**Recon evidence (verified by recon agent against HEAD `f04c1a2`):**

```css dashboard/styles.css:778-817
.stat-card {
    background: var(--bg-tertiary);
    border: 1px solid var(--border-light);
    border-radius: var(--radius);
    padding: 12px 16px;
    min-width: 150px;
    flex: 1;
}

.stat-card--primary {
    border-color: var(--accent);
}
/* ... */
.stat-value {
    font-family: var(--font-mono);
    font-size: 20px;
    font-weight: 700;
    color: var(--text-primary);
    /* Prevent browser auto-hyphenation from injecting visual em-dash artefacts
       into mid-word breaks on narrow stat-card layouts (e.g. the Sim Time
       full ISO datetime). The string never contains U+2014 — it's purely
       a CSS-rendered hyphen. Pin keep-all + nowrap so the datetime renders
       on one logical line, with ellipsis fallback if the viewport truly
       can't fit. See bug-hunt 20260503T230405Z2601 Team A. */
    hyphens: none;
    word-break: keep-all;
    overflow-wrap: normal;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
```

```html dashboard/index.html:170-176
<div class="overview-grid" role="group" aria-label="Key metrics" aria-live="polite">
    <div class="stat-card stat-card--primary">
        <h3 class="stat-label">Sim Time</h3>
        <div class="stat-value" id="sim-time">--</div>
    </div>
    <div class="stat-card">
        <h3 class="stat-label">Portfolio Value</h3>
```

```javascript dashboard/app.js:1899-1904
function renderClock(clock) {
    const simTime = clock.current_time || clock.sim_time || '--';
    const mode = (clock.mode || '').toLowerCase();

    document.getElementById('sim-time').textContent = formatDateTime(simTime);
    document.getElementById('header-sim-time').textContent = formatDateTime(simTime);
```

```javascript dashboard/app.js:2520-2528
function formatDateTime(dt) {
    if (!dt || dt === '--') return '--';
    try {
        const d = new Date(dt);
        return d.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
    } catch {
        return esc(String(dt));
    }
}
```

The Overview SIM TIME card at HEAD writes the full 24-char `2025-05-05 00:00:00 UTC` string to `#sim-time` via `formatDateTime`. The card has `min-width: 150px` (≈12 chars at 20px mono) and `text-overflow: ellipsis` cuts the rest. The agent's observed `S025-05-...` rendering is the truncated prefix (the leading `2` may visually look like `S` on certain font/zoom combinations, or the agent's screenshot tool truncated mid-character glyph). (verified by recon agent against HEAD `f04c1a2`)

**Fix approach:**

The SIM TIME card cannot fit `2025-05-05 00:00:00 UTC` at `min-width: 150px`. Three fix options ranked by simplicity:

1. **Use date-only format on the SIM TIME card; keep full timestamp in the header.** Modify `renderClock()` at `dashboard/app.js:1903` to use `formatDateShort(simTime)` (10 chars `2025-05-05`) and add a `title` attribute with the full timestamp for hover tooltip. The header's `#header-sim-time` keeps `formatDateTime`. Smallest blast radius, highest readability.

2. **Widen the SIM TIME card.** Override `.stat-card--primary` min-width to ≈260px so the full 24-char timestamp fits at 20px mono. Side effect: breaks the equal-width grid layout.

3. **Reduce font size on `.stat-value` for the SIM TIME card.** Add `.stat-card--primary .stat-value { font-size: 14px; }`. Side effect: SIM TIME visually de-emphasized vs other Overview tiles.

**Recommended:** Option 1. Cleanest, smallest blast radius, preserves grid layout and font hierarchy. Adds tooltip-on-hover for users who want the full UTC timestamp.

**Files touched:**
- Modified: `dashboard/app.js` — change line 1903 to use `formatDateShort` + add `title` attribute (≈3 lines diff).
- Modified: `dashboard/index.html` — if option 1 needs a `title` attribute on `#sim-time`, modify line 174 (`<div class="stat-value" id="sim-time" title="--">--</div>`).
- Modified: `dashboard/styles.css` — possibly remove redundant `overflow:hidden + text-overflow:ellipsis` from `.stat-value` if option 1 makes it unnecessary; OR keep them as a safety net (no diff).
- Modified: `tests/e2e/journey-02-session-create.spec.ts` (or the most relevant spec — verify via grep) — add an assertion that `#sim-time.textContent` matches `^\\d{4}-\\d{2}-\\d{2}$` AND has a `title` attribute with full ISO datetime.

**Deliverable:** After this team merges, the SIM TIME card displays the date as `YYYY-MM-DD` (10 chars, fits in 150px) with full `YYYY-MM-DD HH:MM:SS UTC` available via `title=` hover tooltip. The header bar's full-format sim-time remains unchanged.

**Validation:**
- [ ] `uv run pytest tests/e2e/journey-02-*.spec.ts -x -q` passes (existing tests + new regression).
- [ ] Manual repro: load dashboard with active session → verify SIM TIME card shows `2025-05-05` (date-only, not truncated) → hover → tooltip shows full UTC timestamp.
- [ ] CSS lint (if any) passes; no `dashboard/event-bus.js` changes (not in scope).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Choose option 1 unless local repro shows option 1 is insufficient.
- Do NOT remove the `hyphens/word-break/white-space` rules at `styles.css:811-814` — those still serve the em-dash artefact prevention even with option 1.
- The `#header-sim-time` element (different from `#sim-time`) is in the page header; it has different layout constraints. Do NOT change its format.

---

### Team D: Documentation updates

**Blocked by:** Teams A, B, C completion (need merge SHAs and `team_*_verify.md` artifacts).

**Read these files first:**
- `docs/REMAINING_TASKS.md` — mirror prior Bug-Hunt-Closed subsection patterns.
- `docs/LESSONS.md` — append at the top under "## Recent" (or wherever the convention is).
- `docs/ARCHITECTURE.md` — search for `dashboard` section; this iteration likely doesn't change architecture.
- `docs/KNOWN_FAILURES.md` — pre-flight refresh.
- Prior bug-hunt iteration's docs commits: `git log --oneline docs/bug-hunt/ledger.jsonl | head -10` to find the most recent docs commit pattern.

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — add "Bug Hunt 20260505T175445Z750b — Closed" subsection listing the 3 fixes.
- Modified: `docs/LESSONS.md` — append at least 3 lessons (one per real-broken finding) covering reusable rules. Suggested topics:
  1. **Patch-incomplete vs patch-regressed:** when a fix's symptom mutates (stale → blank), verify the underlying contract still holds before declaring regression. The render-on-read v3.1 contract was preserved; the new symptom is a different code path failing.
  2. **CSS overflow side-effects:** unconditional `text-overflow: ellipsis` on tile-display elements can cripple readability when content exceeds tile width. Prefer "shorten content + tooltip" over "add ellipsis to fixed-width container".
  3. **Chart auto-scale defaults:** TradingView's Lightweight Charts defaults `priceScale.autoScale: true`, which collapses Y-axis to data range. For dashboards anchored to a known reference value (starting capital), explicitly configure the visible range.
- Modified: `docs/ARCHITECTURE.md` — only if any of A/B/C touch architectural surfaces. Likely no-op — note explicitly in commit message.
- Modified: `docs/KNOWN_FAILURES.md` — refresh pre-flight section.
- Staged + committed: every artifact in `docs/bug-hunt/20260505T175445Z750b/`:
  - `triage.md`, `triage.json`, `plan.md`, `blind_report.json`, `cleanup.log`,
  - `isolation_warning.txt`, `blind_diagnostic.log`, `team_a_verify.md`, `team_b_verify.md`, `team_c_verify.md`,
  - (later, after Phase 5.5) `deploy_status.txt`, `retest_results.json`.
- Modified: `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new patch-ineffective signals, the orchestrator already appended them. Stage the file.

**Deliverable:** A single docs commit with message:
> `docs: bug-hunt 20260505T175445Z750b — record fixes for trade-ticket-cash-blank, equity-curve-y-axis-collapse, sim-time-truncate; LESSONS +3; ARCHITECTURE unchanged this iteration; ledger pending Team E`

**Validation:**
- [ ] `git status` shows only docs paths staged.
- [ ] `git log -1 --stat` shows the expected file set.
- [ ] All 3 LESSONS entries are reusable rules (not diff recaps).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Do NOT include the ledger update or pending_recurrences.resolved in this commit — those belong to Team E's separate commit.
- If a doc category has no relevant change (e.g., ARCHITECTURE), state so explicitly in the commit message rather than silently omitting.

---

### Team E: Ledger + pending_recurrences

**Blocked by:** Team D merge.

**Read these files first:**
- `docs/bug-hunt/ledger.jsonl` — last 10 lines (read for schema parity: `tail -10 docs/bug-hunt/ledger.jsonl`).
- `docs/bug-hunt/pending_recurrences.jsonl` — current contents (`cat docs/bug-hunt/pending_recurrences.jsonl`).
- `docs/bug-hunt/20260505T175445Z750b/triage.json` — for the 3 finding_id slugs and category tags.
- `git log --oneline -10 main` — to grab merge SHAs for each finding.

**Files touched:**
- Append-only: `docs/bug-hunt/ledger.jsonl` — add EXACTLY 3 lines (one per real-broken finding) using the schema from `triage.md` Required Docs Updates §7.
- Modified: `docs/bug-hunt/pending_recurrences.jsonl` — Phase 5.5 appends inline; Team E only stages the file (no manual mutation).
- Modified: `docs/bug-hunt/pending_recurrences.resolved.jsonl` — only if a verdict-effective prune happened this iteration (none expected based on pre-flight; skip if file unchanged).

**Deliverable:** A single commit with message:
> `docs: bug-hunt 20260505T175445Z750b ledger — append 3 entries (trade-ticket-cash-blank-after-buy, equity-curve-y-axis-collapse, sim-time-card-truncates)`

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` grows by exactly 3 vs pre-iteration.
- [ ] Each new line is valid JSON: `tail -3 docs/bug-hunt/ledger.jsonl | jq -c .`.
- [ ] Each line has `iteration_ts: "20260505T175445Z750b"`, valid `category`, valid `commit` SHA on `main`.
- [ ] `git log -1 --stat` shows only `docs/bug-hunt/ledger.jsonl` and (if relevant) `docs/bug-hunt/pending_recurrences*.jsonl`.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Reuse existing categories (`dashboard-state-sync` for all three) — do NOT mint new tags.
- The `commit` field is the merge SHA on `main` for the team that closed the item. Run `git log --oneline -10 main` to find it.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A's fix masks the bug instead of root-causing it | Medium | High | Team A must reproduce locally + report root cause in `team_a_verify.md` BEFORE patching. Demote to needs-investigation if unable to reproduce. |
| Team B's chart-range pinning breaks existing equity-curve E2E tests | Medium | Medium | Run journey-04 + any chart-related specs before commit; verify the existing watermark-only test still passes. |
| Team C's date-format change breaks header sim-time | Low | Low | Team C scopes change to `#sim-time` only; do NOT touch `#header-sim-time` (line 1904). |
| Team A and Team B both edit `dashboard/app.js` near each other | Low | Low | Sequential merge. Team B rebases on Team A's main before working. Recon shows non-overlapping line ranges (A: 1456-1670, B: 2080-2446). |
| Phase 5.5 retest fails for Bug 1 (patch-ineffective) | Medium | Medium | If retest fails, the iteration auto-promotes `dashboard-state-sync` (specifically `trade-ticket-cash` cluster) to refactor on next iteration. The forward-signal in this triage already primes this. |

## Session Plan

### Session 1 — Code fixes (sequential merges, parallel work)

**Spawn order:** All three code teams (A, B, C) spawn in parallel as worktree-isolated agents.

**Merge order:** Strictly sequential.

1. **Team A merges first.**
   - Targeted gate: `uv run pytest tests/e2e/journey-05-trade.spec.ts -x -q` passes.
   - If fail → block merge, fix-forward in worktree, retry.
2. **Team B rebases on main, merges second.**
   - Targeted gate: `uv run pytest tests/e2e/journey-04-*.spec.ts -x -q` passes.
3. **Team C rebases on main, merges third.**
   - Targeted gate: `uv run pytest tests/e2e/journey-02-*.spec.ts -x -q` (or whichever covers SIM TIME) passes.

**Session 1 checkpoint:** Full E2E suite (`uv run pytest tests/e2e/ -x -q`) passes after all three code teams merged.

### Session 2 — Docs + ledger

4. **Team D merges fourth.**
   - Targeted gate: `git status` is clean after staging; `git log -1 --stat` shows only docs paths.
5. **Team E merges fifth.**
   - Targeted gate: `wc -l docs/bug-hunt/ledger.jsonl` grew by exactly 3.

**Session 2 checkpoint:** `git push origin main` + watch deploy workflow.

---

## Quality Checklist

- [x] Every team has a "Read these files first" list with file:line cites.
- [x] Every team has "You MUST git add + git commit" in agent instructions.
- [x] Every team has specific validation commands.
- [x] File conflict table accounts for all shared files.
- [x] No team touches >8 files (Team A: 4; Team B: 2; Team C: 4; Team D: 6+ artifacts; Team E: 2).
- [x] Dependencies match the file conflict table (sequential A→B→C→D→E for all shared-file teams).
- [x] Critical path is the longest chain (5 teams sequential = 5 stages).
- [x] Session grouping respects all dependency constraints.
- [x] Every "current state" claim in a team spec is backed by a quoted-excerpt fenced block tagged `(verified by recon agent against HEAD f04c1a2)`.
