# Team A Verification — `trade-ticket-cash-blank-after-buy`

**Iteration:** 20260505T175445Z750b
**Team:** A (Trade Ticket Available Cash blank after BUY)
**Verdict:** **DEMOTED — cannot reproduce locally OR against live deploy.**

## Reproduction (local + live)

Walked the path the blind agent described:

1. Login as `jgn0017@auburn.edu` (test user from `~/.bug-hunt-loop/secrets.env`).
2. Create a fresh ACTIVE session ($100,000 starting capital).
3. Open Trade Ticket panel via `#btn-trade`.
4. Submit MARKET BUY of 10 AAPL via the form.
5. Observe `#tt-cash-balance.textContent` at every stage.

### Local repro (`uv run finlet serve`, S3 unreachable)

| Step | `#tt-cash-balance.textContent` |
| ---- | ------------------------------ |
| Step 1 (after openTradeTicket on fresh session) | `$100,000.00` |
| Step 2 (after BUY submit success — ORDER REJECTED locally, no S3 price data) | `$100,000.00` |
| Step 3 (after closeTradeTicket auto-fired by submit success) | `$100,000.00` (persistent DOM) |
| Step 4 (after reopen via openTradeTicket) | `$100,000.00` |
| Step 5 (after async dashFetch resolves on reopen) | `$100,000.00` |

Local can't fully exercise the fill path (S3 unreachable on dev → orders REJECTED), but the post-submit IIFE still runs because `result.ok` is true regardless of fill status. The persistent DOM never goes blank, never goes to "Loading...", never goes to "--".

### Live repro on `https://finlet.dev` (real S3, real fills)

Logged in with the same user, created a fresh `tech_growth` session ($100,000 starting capital, start 2025-05-01), and ran the BUY 10 AAPL flow. The order **filled** successfully (no S3 issues live).

Polled `#tt-cash-balance.textContent` every 100ms for 3 seconds spanning the submit-then-auto-close cycle:

| Time (ms after submit dispatch) | `#tt-cash-balance.textContent` | Panel open? | `currentSession.portfolio_metrics.cash` |
| ------------------------------- | ------------------------------ | ----------- | --------------------------------------- |
| 0–300 | `$100,000.00` | open | 100000 |
| 400 | `$97,882.11` | **closed** (auto-close) | 97882.11 |
| 500–2900 | `$97,882.11` (persistent) | closed | 97882.11 |

After clicking `#btn-trade` to **reopen** the panel and polling another 3 seconds:

| Time (ms after reopen click) | `#tt-cash-balance.textContent` | Panel open? |
| ---------------------------- | ------------------------------ | ----------- |
| 0–2900 (steady) | `$97,882.11` | open |

A second BUY in the same session (5 AAPL) and an explicit close→reopen cycle 600ms after submit also rendered the post-fill cash continuously: `$97,882.11 → $96,819.08`, never blank, never `Loading...`, never `--` on either side of the close/reopen boundary.

DOM-level inspection on the reopened panel after fill (live):
```js
{
  textContent: "$97,882.11",
  innerText: "$97,882.11",
  innerHTML: "$97,882.11",
  childNodes: [{ type: 3, content: "$97,882.11" }],
  boundingRect: { x: 1089.69, y: 89, w: 90.31, h: 22.5 },  // visible, non-zero
  style: "block, vis=visible, op=1, col=rgb(63, 185, 80)",  // green, opaque
}
```

## Root Cause

**No root cause found.** With the v3.1 render-on-read contract preserved end-to-end (verified at `dashboard/trade-ticket.js:34-42` `repaintCash`, `:178-235` `dialogStateMirror.onOpen/onUpdate`, `:446-524` `submitTradeTicket` post-submit IIFE; `dashboard/app.js:1456-1511` SSE `portfolio` handler with terminal `repaintCash`; `:1525-1670` SSE `orders` deferred IIFE with terminal `repaintCash`), there is no code path in `dashboard/trade-ticket.js` or `dashboard/app.js` that produces an *empty string* in `#tt-cash-balance.textContent`:

- `repaintCash()` only writes `'$' + Number(cash).toLocaleString(...)` — never empty. Returns silently when canonical is `undefined`/`NaN` (refuse-clobber), leaving the persistent DOM as last painted.
- `fetchCashBalance()` writes one of `'Loading...'`, `'--'`, or `repaintCash()`'s formatted output — never empty.
- HTML default initial content is `'--'` (`dashboard/index.html:436`) — only seen on cold-load before any SSE tick.
- `resetTradeForm()` calls `form.reset()`, but `#tt-cash-balance` is **outside** `<form id="trade-ticket-form">` (sibling elements under `<aside id="trade-ticket-panel">`), so form reset cannot blank it.

`grep -rn "tt-cash-balance" dashboard/` shows only two writers (`repaintCash` and `fetchCashBalance` in `trade-ticket.js`); both produce non-empty strings under all input shapes (verified via edge-case eval: `undefined → "$NaN"`, `null → "$0.00"`, `NaN → "$NaN"`, `0 → "$0.00"`, etc., none empty).

## Fix Approach

**No fix written — finding demoted.**

Per the team prompt's CRITICAL PROCESS step 3:
> If you cannot reproduce the bug (cash always shows correctly): demote this finding. Write to `team_a_verify.md`: "DEMOTED — cannot reproduce locally. Triage assertion was based on blind-agent observation that does not hold in repro. Recommend re-running blind walk to confirm symptom." Then SKIP the fix, do NOT modify any code, but DO commit team_a_verify.md.

The blind-agent screenshot (`/Users/justnau/finlet/trade-confirmed-positions.png`) clearly shows the cash row blank below the "AVAILABLE CASH" label, but multiple repro attempts on the **same live deploy commit (`f04c1a2`, verified via `diff <(curl -s https://finlet.dev/trade-ticket.js) <(cat dashboard/trade-ticket.js)` → identical)** with the **same test user** and the **same session lineage** (existing fundamentals_strategy session that was the target of the screenshot, plus a fresh tech_growth session) cannot reproduce the BLANK state.

Possible non-bug explanations for the blind-agent observation (offered as recon, not as fix):
1. **Screenshot timing artifact.** The blind agent's screenshot was taken in the middle of an SSE flush window where the persistent DOM had been transiently blanked by an external script (browser extension, screenshot helper, devtools eval) and immediately repainted. Our 100ms-poll timeline never sees this.
2. **One-shot DOM stomp by external tooling.** The agent's headless browser environment may have had a tracker/extension that briefly mutated `#tt-cash-balance` for accessibility/snapshot purposes. The repro environment (Playwright MCP, fresh) has none.
3. **Misclassified pixel artifact.** The screenshot shows the value area is dark (essentially empty) but the persistent text node exists in DOM. A high-DPR rendering glitch / partial page-paint at screenshot-capture time could erase the rendered glyphs without removing the underlying text. Our DOM-level inspection (`innerText`, `getBoundingClientRect`, `getComputedStyle`) shows the value is fully rendered, visible (block, op=1, color rgb(63,185,80)), and at expected dimensions (90×22.5px).

**DEMOTED — cannot reproduce locally OR live. Triage assertion was based on a blind-agent observation that does not hold in repro. Recommend re-running blind walk to confirm symptom.**

## Validation

- Local server (`uv run finlet serve`) brought up at `http://localhost:8000`, test user logged in via `/v1/auth/login` (cookie auth + CSRF), fresh session created with `start_time: '2024-01-02T14:30:00Z'`. BUY of 10 AAPL submitted via form-submit dispatch on `#trade-ticket-form`. Cash text polled every 100ms for 3s after submit and after reopen — never blank.
- Live deploy `https://finlet.dev` (commit SHA matches local `f04c1a2`, verified by JS file diff), same test user logged in, fresh `tech_growth` session created (`start_time: '2025-05-01T14:30:00Z'`). BUY of 10 AAPL filled successfully (cash $100,000 → $97,882.11, AAPL position +10). Cash text polled every 100ms for 6s spanning open → submit → close → reopen → second BUY → close → reopen — **never blank**, never `Loading...`, never `--`.
- DOM-level inspection on live post-fill reopened panel: `textContent` and `innerHTML` both equal `"$97,882.11"`, single text-node child, visible 90×22.5px element.
- v3.1 render-on-read contract verified intact: `grep -c "Render-on-read v3.1" dashboard/trade-ticket.js dashboard/app.js` returns 1 + 2 (matches commits `8c55a90`/iter 20260503T030227Z2009).
- KNOWN_FAILURES checked at `docs/KNOWN_FAILURES.md` — no pre-existing entry for this surface.
- No code modified. Commit contains only this verify document.
