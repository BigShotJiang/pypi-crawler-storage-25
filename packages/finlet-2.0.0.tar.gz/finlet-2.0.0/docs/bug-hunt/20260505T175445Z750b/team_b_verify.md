# Team B Verify — Equity curve Y-axis collapse fix

**Iteration:** 20260505T175445Z750b
**Finding:** `equity-curve-y-axis-collapse`
**Base SHA:** `f04c1a2`

## Fix approach chosen

**Hidden anchor series pattern.** The plan suggested two approaches: (1) `priceScale.applyOptions({ autoScale: false }) + setVisibleRange`, or (2) the `autoscaleInfoProvider` series option. Neither worked against the LightweightCharts v4.2.1 standalone bundle:

- `priceScale.setVisibleRange` does not exist on price scales in v4 — it is a TimeScale-only API. Pinning `autoScale: false` without it leaves the chart frozen on whatever the last fit was, and the public PriceScale interface has no `setMinPrice`/`setMaxPrice`.
- `autoscaleInfoProvider` is a documented v4 series option, but the standalone production bundle (`dashboard/vendor/lightweight-charts.standalone.production.js`) does not propagate it onto `series.options()` whether passed at `addLineSeries({...})` time or via `series.applyOptions({...})`. I verified this empirically by exposing the inner option store and inspecting it through the test harness — `typeof series.options().autoscaleInfoProvider === 'undefined'` and the callback never fires (counter stays at 0). The bundled `Al(t,i)` method does check `void 0 !== this.cn.autoscaleInfoProvider`, but `this.cn` is reached through `T()` deep-merge in a way that drops the key in the standalone build. Filing this against TradingView is out of scope for this iteration.

The hidden anchor series pattern is a documented TradingView idiom that does not depend on `autoscaleInfoProvider`. A third LineSeries with fully-transparent stroke (`color: 'rgba(0,0,0,0)'`, `priceLineVisible: false`, `lastValueVisible: false`, `crosshairMarkerVisible: false`) is added to the chart; it shares the same right price scale as the equity and benchmark series, so the chart's auto-scale takes the union of all series' data ranges. When `renderEquityCurve()` detects low variance vs the session's `initial_capital`, it populates the anchor series with two points at `[anchor*0.95, anchor*1.05]` — a 10% window centered on starting capital. When real variance exceeds the threshold, the anchor series is cleared (`setData([])`) and the Y-axis tracks the real data range natively.

This is the smallest-blast-radius fix that is verified to work against the actual vendored bundle.

## Files modified

- `dashboard/app.js`
  - Added module-scope `let equityYAxisAnchorSeries = null` (with comment pointing to the bug-hunt iteration).
  - In `initChart()`: added a third `addLineSeries(...)` after `benchmarkSeries` with the transparent-stroke configuration.
  - In `renderEquityCurve()`: after `equitySeries.setData(deduped)` and the benchmark block, added a low-variance guard. Computes `anchor = currentSession.config.initial_capital` (canonical field, with defensive fallbacks to first plotted value, then $100k). Computes `dataSpan` from `deduped`. If `dataSpan < anchor * 0.10`, populates the anchor series with two points at the equity series's first and last timestamps with values `[anchor*0.95, anchor*1.05]`. Else `setData([])` to clear.
  - Exposed `window.__finletEquityAnchorSeries` and `window.__finletRenderEquityCurve` for test introspection (no production code uses these).

- `tests/e2e/journey-04-dashboard.spec.ts`
  - Added one regression test: `equity curve Y-axis spans meaningful range with low-variance data (regression for 20260505T175445Z750b)`.

The `equityChart.timeScale().fitContent()` call on line 2185 (formerly 2134) is preserved — that controls the X-axis (time), separate from the Y-axis fix. The buffered-history replay block at the end of `initChart()` is also preserved.

## New regression assertion

The test drives the bug condition deterministically. It loads the dashboard, dismisses any modals, waits for the chart series to be ready, then injects a low-variance synthetic equity history through the production `renderEquityCurve()` entry point (exposed via `window.__finletRenderEquityCurve`):

```javascript
const snapshots = [
  { timestamp: '2025-05-01T00:00:00Z', total_value: 100000.00 },
  { timestamp: '2025-05-02T00:00:00Z', total_value: 99999.94 },
  { timestamp: '2025-05-03T00:00:00Z', total_value: 99999.96 },
  { timestamp: '2025-05-04T00:00:00Z', total_value: 99999.98 },
  { timestamp: '2025-05-05T00:00:00Z', total_value: 100000.02 },
];
window.__finletRenderEquityCurve({ snapshots }, null);
```

This is the exact data shape the live blind walkthrough produced. The assertion reads the rendered Y-axis visible range by sampling top and bottom pixel coordinates of the chart container and converting them to prices via `series.coordinateToPrice(0)` and `series.coordinateToPrice(chartHeight)`:

```javascript
expect(priceSpan).toBeGreaterThanOrEqual(initialCapital * 0.05);
```

Pre-fix this returns ~$0.13 (sub-cent zoom). Post-fix it returns ~$10,000 (10% window of $100k starting capital). The 5% threshold gives headroom for the chart's 10% top/bottom scaleMargins to trim the visible window.

The assertion is deterministic — no timing dependence on session-state SSE plumbing or trade-fill timing. It exercises the production `renderEquityCurve()` code path end-to-end.

## Validation output

### Playwright — full journey-04 suite

```
Running 10 tests using 1 worker

  ok  1 [chromium] tests/e2e/journey-04-dashboard.spec.ts:8:7   shared navigation is present with correct links
  ok  2 [chromium] tests/e2e/journey-04-dashboard.spec.ts:48:7  first-run banner or session selector is visible
  ok  3 [chromium] tests/e2e/journey-04-dashboard.spec.ts:68:7  first-run banner distinguishes empty-sessions from server-down
  ok  4 [chromium] tests/e2e/journey-04-dashboard.spec.ts:120:7 create session modal opens and creates session
  ok  5 [chromium] tests/e2e/journey-04-dashboard.spec.ts:246:7 template switch syncs session name (Conservative -> Custom clears)
  ok  6 [chromium] tests/e2e/journey-04-dashboard.spec.ts:306:7 clock controls: freeze, step, play, stop
  ok  7 [chromium] tests/e2e/journey-04-dashboard.spec.ts:392:7 SSE connection is active (not fallback polling)
  ok  8 [chromium] tests/e2e/journey-04-dashboard.spec.ts:447:7 equity curve renders data after market buy + clock step
  ok  9 [chromium] tests/e2e/journey-04-dashboard.spec.ts:596:7 equity curve Y-axis spans meaningful range with low-variance data (regression for 20260505T175445Z750b)
  ok 10 [chromium] tests/e2e/journey-04-dashboard.spec.ts:702:7 Plugin Health latency badges render canonical format (regression for 20260505T142400Z3330)

  10 passed (29.0s)
```

The pre-existing `equity curve renders data after market buy + clock step` test (the watermark-only regression from prior bug-hunt) still passes — the anchor-series pattern does not interfere with the buffered-history replay path or the SSE-history-arrives-before-initChart race.

### Lints

```
$ uv run ruff check dashboard/
warning: No Python files found under the given path(s)
All checks passed!

$ bash scripts/lint-trusted-types.sh
lint-trusted-types: OK — 0 bare HTML-sink write sites under dashboard/.

$ bash scripts/lint-event-bus.sh
lint-event-bus: OK — 0 direct event-bus bypass sites under dashboard/.

$ node --check dashboard/app.js
(no output — syntax OK)
```

## Notes for downstream teams

- Team C touches `dashboard/app.js` after Team B. The Y-axis fix lives in `initChart()` (~lines 2402-2418, the third `addLineSeries` call) and `renderEquityCurve()` (~lines 2139-2188, the anchor block after benchmark `setData`). Neither overlaps with Team C's `renderClock()` (line ~1900) or the SIM TIME format change (line ~1903).
- The new test exposures (`window.__finletEquityAnchorSeries`, `window.__finletRenderEquityCurve`) are additive; no production caller uses them. Existing `__finletChart`, `__finletEquitySeries`, `__finletBenchmarkSeries` exposures are preserved.
- The fix uses `currentSession.config.initial_capital` (canonical backend field name verified in `finlet/core/session.py:44` and `finlet/api/routes_session.py:53`). The team prompt referred to `currentSession.config.starting_capital` — that field does not exist; renaming was intentional.
