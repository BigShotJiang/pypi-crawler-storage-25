You are Team E — Ledger + pending_recurrences for bug-hunt iteration 20260505T175445Z750b.

This is bug-hunt iteration 20260505T175445Z750b. Your worktree was forked at SPAWN_BASE_SHA = f04c1a2 (the orchestrator has already reset your worktree to this SHA + Team D's docs commit). The full plan is at `docs/bug-hunt/20260505T175445Z750b/plan.md` — read your team's section first ("Team E").

CONTEXT (UPDATED FROM PLAN):
Three code teams ran this iteration. Outcomes:
- Team A — DEMOTED: trade-ticket-cash-blank-after-buy NOT REPRODUCIBLE locally or on live finlet.dev. v3.1 render-on-read contract verified intact. NO ledger entry (no fix landed).
- Team B — DONE: equity-curve-y-axis-collapse fixed. Merge SHA on main: `548eac3`.
- Team C — DONE: sim-time-card-truncates fixed. Merge SHA on main: `f1d6581`.

**You append EXACTLY 2 ledger entries (NOT 3 — Team A demoted).**

READ THESE FILES FIRST:
- `docs/bug-hunt/ledger.jsonl` — last 10 lines (`tail -10 docs/bug-hunt/ledger.jsonl`) for schema parity.
- `docs/bug-hunt/pending_recurrences.jsonl` — current contents (`cat docs/bug-hunt/pending_recurrences.jsonl`).
- `docs/bug-hunt/20260505T175445Z750b/triage.json` — for finding_id slugs and category tags.
- `git log --oneline -10 main` — to verify merge SHAs.

YOUR DELIVERABLE:

1. **Append 2 lines to `docs/bug-hunt/ledger.jsonl`** using this flat schema:
```json
{"iteration_ts":"20260505T175445Z750b","finding_id":"<slug>","category":"<tag>","summary":"<short>","scope_files":["..."],"team":"<letter>","commit":"<merge-sha>"}
```

The 2 entries:
- **Entry 1** — Team B (equity curve Y-axis):
  - `finding_id`: `equity-curve-y-axis-collapse-after-first-trade`
  - `category`: `dashboard-state-sync` (or whatever the triage.json category is — read it from triage)
  - `summary`: short description
  - `scope_files`: `["dashboard/app.js", "tests/e2e/journey-04-dashboard.spec.ts"]`
  - `team`: `B`
  - `commit`: `548eac3` (the merge SHA of Team B on main — verify with `git log --oneline -15 main | grep 'Team B'`)

- **Entry 2** — Team C (SIM TIME card):
  - `finding_id`: `sim-time-card-truncates-with-ellipsis`
  - `category`: same as in triage.json
  - `summary`: short description
  - `scope_files`: `["dashboard/app.js", "dashboard/index.html", "tests/e2e/journey-sim-time-tile.spec.ts"]`
  - `team`: `C`
  - `commit`: `f1d6581` (merge SHA of Team C on main)

**Do NOT append a Team A entry** — A demoted, no fix shipped.

2. **`docs/bug-hunt/pending_recurrences.jsonl`** — Phase 5.5 hasn't run yet. Do NOT mutate this file manually. If it has prior-iteration content, leave it. If it's empty, leave it.

3. **`docs/bug-hunt/pending_recurrences.resolved.jsonl`** — only stage if Team D pruned via verdict-effective. Pre-flight indicates none expected. Skip if file unchanged.

COMMIT MESSAGE:
> `docs: bug-hunt 20260505T175445Z750b ledger — append 2 entries (equity-curve-y-axis-collapse, sim-time-card-truncates); trade-ticket-cash-blank DEMOTED (no entry)`

VALIDATION:
- `wc -l docs/bug-hunt/ledger.jsonl` grew by exactly 2 vs pre-iteration baseline (compare with `git show main:docs/bug-hunt/ledger.jsonl | wc -l` against the base before your commit).
- Each new line is valid JSON: `tail -2 docs/bug-hunt/ledger.jsonl | jq -c .`.
- Each line has `iteration_ts: "20260505T175445Z750b"`, valid `category`, valid `commit` SHA on `main` (verify with `git cat-file -e <sha>`).
- `git log -1 --stat` shows only `docs/bug-hunt/ledger.jsonl` (and possibly `docs/bug-hunt/pending_recurrences*.jsonl` if applicable).

CRITICAL RULES:
- You MUST `git add` and `git commit` ALL your changes before finishing.
- Commit message must start with `[Team E]:` OR begin with `docs:` (per the prior pattern in `git log`).
- Touch ONLY: `docs/bug-hunt/ledger.jsonl` (and pending_recurrences if applicable). Do NOT touch dashboard/, finlet/, tests/, ARCHITECTURE/LESSONS/REMAINING_TASKS.
- Append 2 entries — NOT 3 — Team A is DEMOTED.
- Reuse existing categories from triage.json — do NOT mint new tags.
- Read `docs/KNOWN_FAILURES.md` first.

WHEN DONE, REPORT:
- `DONE` + commit hash + summary of ledger entries appended, OR
- `BLOCKED` + what went wrong.
