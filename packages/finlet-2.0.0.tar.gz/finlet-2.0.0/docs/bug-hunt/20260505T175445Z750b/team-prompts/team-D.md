You are Team D — Documentation updates for bug-hunt iteration 20260505T175445Z750b.

This is bug-hunt iteration 20260505T175445Z750b. Your worktree was forked at SPAWN_BASE_SHA = f04c1a2 (the orchestrator has already reset your worktree to this SHA). The full plan is at `docs/bug-hunt/20260505T175445Z750b/plan.md` — read your team's section first ("Team D").

CONTEXT (UPDATED FROM PLAN):
Three code teams ran this iteration. Outcomes:
- Team A — DEMOTED: trade-ticket-cash-blank-after-buy NOT REPRODUCIBLE locally or on live finlet.dev. v3.1 render-on-read contract verified intact. Commit `545e1de` is docs-only (verify report). Lesson: blind-agent observations may include screenshot timing artifacts; require local repro before fixing.
- Team B — DONE: equity-curve-y-axis-collapse fixed via hidden anchor LineSeries pattern (TradingView v4.2.1 standalone bundle does not propagate `autoscaleInfoProvider` from options). Commit on main: `548eac3` (merge of `edc5ce7`).
- Team C — DONE: sim-time-card-truncates fixed by rendering `formatDateShort` to `#sim-time.textContent` and exposing full `formatDateTime` on `title=` attribute. `#header-sim-time` unchanged. Commit on main: `f1d6581` (merge of `125f2b2`).

Two real-broken findings closed (B, C). One demoted (A).

READ THESE FILES FIRST:
- `docs/REMAINING_TASKS.md` — mirror prior Bug-Hunt-Closed subsection patterns.
- `docs/LESSONS.md` — append at the top under "## Recent" (or wherever the convention is).
- `docs/ARCHITECTURE.md` — search for `dashboard` section; this iteration's changes don't alter architecture.
- `docs/KNOWN_FAILURES.md` — pre-flight refresh.
- Prior bug-hunt iteration's docs commits: `git log --oneline docs/bug-hunt/ledger.jsonl | head -10` to find the most recent docs commit pattern.

YOUR DELIVERABLE:
A single docs commit covering:

1. **`docs/REMAINING_TASKS.md`** — add "Bug Hunt 20260505T175445Z750b — Closed" subsection listing the 2 fixes (B, C) + 1 demotion (A).

2. **`docs/LESSONS.md`** — append AT LEAST 3 lessons covering REUSABLE RULES (not diff recaps):
   - Lesson on Team A's demotion: blind-agent screenshots may capture timing artifacts. Require local repro on `localhost:8000` AND live `finlet.dev` before patching. If neither reproduces and the contract still passes, demote to `needs-investigation` rather than patch defensively.
   - Lesson on Team B's chart fix: TradingView Lightweight Charts v4.2.1 standalone production bundle does NOT propagate `autoscaleInfoProvider` from `addLineSeries()` options or `applyOptions()` (verified empirically: `series.options().autoscaleInfoProvider === undefined`). Use the hidden-anchor-LineSeries pattern when forced to widen Y-axis on low-variance data.
   - Lesson on Team C's CSS overflow side-effect: unconditional `text-overflow: ellipsis` on tile-display elements can clip readable values when the content exceeds tile width. Prefer "shorten content + tooltip" over "add ellipsis to fixed-width container".

3. **`docs/ARCHITECTURE.md`** — only update if architectural surfaces changed. This iteration's changes are dashboard-only and do NOT change architecture. Note explicitly in commit message: "ARCHITECTURE unchanged this iteration".

4. **`docs/KNOWN_FAILURES.md`** — refresh pre-flight section. The pre-flight reported 3974 tests passing; mark any prior failures resolved.

5. **Stage + commit every artifact** in `docs/bug-hunt/20260505T175445Z750b/`:
   - `triage.md`, `triage.json`, `plan.md`, `blind_report.json`, `cleanup.log`,
   - `isolation_warning.txt` (if present), `blind_diagnostic.log` (if present),
   - `team_a_verify.md`, `team_b_verify.md`, `team_c_verify.md`,
   - `exec-trace.txt`, `team-prompts/team-A.md`, `team-prompts/team-B.md`, `team-prompts/team-C.md`, `team-prompts/team-D.md`, `team-prompts/team-E.md`.
   - (Phase 5.5 will append `deploy_status.txt` + `retest_results.json` AFTER your commit. Do NOT block on those.)

6. **`docs/bug-hunt/pending_recurrences.jsonl`** — Phase 5.5 hasn't run yet. If the file is unchanged from base, do NOT touch it. If it has new content from a prior iteration, leave it alone — only Team E or Phase 5.5 mutates this file.

COMMIT MESSAGE:
> `docs: bug-hunt 20260505T175445Z750b — record fixes for equity-curve-y-axis-collapse, sim-time-card-truncates; trade-ticket-cash-blank DEMOTED (not reproducible); LESSONS +3; ARCHITECTURE unchanged this iteration; ledger pending Team E`

VALIDATION:
- `git status` shows only docs paths staged.
- `git log -1 --stat` shows the expected file set.
- All 3 LESSONS entries are reusable rules (not diff recaps).
- Run `uv run ruff check dashboard/` (sanity).

CRITICAL RULES:
- You MUST `git add` and `git commit` ALL your changes before finishing.
- Commit message must start with `[Team D]:` OR begin with `docs:` (per the prior pattern in `git log`).
- Touch ONLY: `docs/` files (REMAINING_TASKS, LESSONS, ARCHITECTURE, KNOWN_FAILURES) AND `docs/bug-hunt/20260505T175445Z750b/` artifacts. Do NOT touch ledger.jsonl, pending_recurrences*, dashboard/, finlet/, tests/.
- Read `docs/KNOWN_FAILURES.md` first.
- Tools available: gh, aws, stripe, wrangler, uv, git, jq, curl, rg, fd, npx, playwright.

WHEN DONE, REPORT:
- `DONE` + commit hash + which docs were touched, OR
- `BLOCKED` + what went wrong.
