You are Team C — SIM TIME card timestamp truncates ("S025-05-...").

This is bug-hunt iteration 20260505T175445Z750b. Your worktree was forked at SPAWN_BASE_SHA = f04c1a2 (the orchestrator has already reset your worktree to this SHA). The full plan is at `docs/bug-hunt/20260505T175445Z750b/plan.md` — read your team's section first.

CONTEXT:
The blind agent observed: Overview "SIM TIME" card consistently renders "S025-05-…" (truncated). The actual sim time is "2025-05-05 00:00:00 UTC" but the card is not wide enough. No tooltip on hover. Same surface as ledger entry `sim-time-tile-em-dash-artefact` (commit 828003d) — that fix added unconditional `text-overflow: ellipsis + overflow: hidden` to `.stat-value` to prevent em-dash artifacts. The CSS now over-applies and clips the timestamp on the SIM TIME card at desktop widths.

READ THESE FILES FIRST:
- `docs/bug-hunt/20260505T175445Z750b/plan.md` — your team spec is "Team C".
- `docs/KNOWN_FAILURES.md` — do NOT report these as issues.
- `dashboard/styles.css:770-825` — `.overview-grid`, `.stat-card`, `.stat-card--primary`, `.stat-value` rules.
- `dashboard/index.html:165-210` — Overview panel markup.
- `dashboard/app.js:1898-1908` — `renderClock()` writes formatted datetime to `#sim-time`.
- `dashboard/app.js:2520-2538` — `formatDateTime()` and `formatDateShort()`.

RECON EVIDENCE (verified at HEAD f04c1a2):
- `.stat-value` has `text-overflow: ellipsis; overflow: hidden; white-space: nowrap` unconditionally (styles.css:815-816).
- `.stat-card` has `min-width: 150px; flex: 1` (styles.css:783-784) — ~12 chars at 20px mono fit.
- `formatDateTime` returns 24-char `YYYY-MM-DD HH:MM:SS UTC` (app.js:2524).
- `formatDateShort` returns 10-char `YYYY-MM-DD` (app.js:2530-2538).
- Overview SIM TIME is the FIRST stat-card, marked `.stat-card--primary` (index.html:172-175).
- `renderClock()` writes `formatDateTime(simTime)` to BOTH `#sim-time` (overview) AND `#header-sim-time` (header bar) at app.js:1903-1904.

YOUR DELIVERABLE:
After this team merges, the SIM TIME card must display the date as `YYYY-MM-DD` (10 chars, fits in 150px) with full `YYYY-MM-DD HH:MM:SS UTC` available via `title=` hover tooltip. The header's `#header-sim-time` keeps full format unchanged.

FIX APPROACH (DO THIS):

Modify `dashboard/app.js` `renderClock()`:
1. Compute the full timestamp once: `const fullSimTime = formatDateTime(simTime);`
2. Compute the short date: `const shortSimTime = formatDateShort(simTime);`
3. Write to overview card: `const simEl = document.getElementById('sim-time'); simEl.textContent = shortSimTime; simEl.setAttribute('title', fullSimTime);`
4. Header bar unchanged: `document.getElementById('header-sim-time').textContent = fullSimTime;`

Modify `dashboard/index.html` line 174 if needed: `<div class="stat-value" id="sim-time" title="--">--</div>` — adds the initial `title` attribute so screen readers know it's a label.

Modify `dashboard/styles.css` ONLY if necessary. Do NOT remove the `hyphens/word-break/keep-all/white-space` rules at lines 811-814 — those still serve em-dash artefact prevention. The `text-overflow: ellipsis` (line 816) and `overflow: hidden` (line 815) can stay as a safety net (they won't trigger now that the date-only string fits in 150px).

VALIDATION:
- `npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-02-*.spec.ts` — existing + new regression assertions pass. (If journey-02 doesn't cover SIM TIME, find the spec that loads the dashboard and add the assertion there — verify via `grep -rn 'sim-time' tests/e2e/`.)
- Add ONE regression assertion: `#sim-time.textContent` matches `^\d{4}-\d{2}-\d{2}$` (10-char date) AND `#sim-time` has a `title` attribute matching `^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} UTC$`.
- `uv run ruff check dashboard/` clean (if relevant).

CRITICAL RULES:
- You MUST `git add` and `git commit` ALL your changes before finishing.
- Commit message must start with `[Team C]:`.
- Touch ONLY: dashboard/app.js (renderClock around 1899-1908), dashboard/index.html (line 174), dashboard/styles.css (only if absolutely necessary), tests/e2e/journey-*-*.spec.ts (the most relevant one), team_c_verify.md.
- Do NOT touch dashboard/trade-ticket.js, the SSE handlers around app.js:1456-1670, or the chart code around app.js:2080-2446.
- Do NOT change `#header-sim-time` rendering.
- Read `docs/KNOWN_FAILURES.md` first.
- Tools available: gh, aws, stripe, wrangler, uv, git, jq, curl, rg, fd, npx, playwright.

WRITE TO `/Users/justnau/finlet/docs/bug-hunt/20260505T175445Z750b/team_c_verify.md`:
- The fix approach
- The regression assertion
- Validation output

WHEN DONE, REPORT:
- `DONE` + commit hash + validation results, OR
- `BLOCKED` + what went wrong.
