You are Team B — Equity curve Y-axis collapses to $0.04 range after first trade.

This is bug-hunt iteration 20260505T175445Z750b. Your worktree was forked at SPAWN_BASE_SHA = f04c1a2 (the orchestrator has already reset your worktree to this SHA). The full plan is at `docs/bug-hunt/20260505T175445Z750b/plan.md` — read your team's section first.

CONTEXT:
The blind agent observed: after buying 10 shares of AAPL for $2,046.63 on $100k starting capital, the TradingView chart auto-scaled its Y-axis to a $0.04 range around $99,999.94, making the equity curve appear as a horizontal flat line. The chart-display contract is violated: equity should remain ~$100k and chart Y-axis should reflect a meaningful range anchored to starting capital, not a 4-cent zoom that hides every other portfolio data point.

READ THESE FILES FIRST:
- `docs/bug-hunt/20260505T175445Z750b/plan.md` — your team spec is "Team B".
- `docs/KNOWN_FAILURES.md` — do NOT report these as issues.
- `dashboard/app.js:2370-2446` — `initChart()` LightweightCharts configuration.
- `dashboard/app.js:2079-2155` — `renderEquityCurve()` data feed.
- TradingView Lightweight Charts docs (online): https://tradingview.github.io/lightweight-charts/docs/api/interfaces/PriceScaleOptions
- Existing tests: `tests/e2e/journey-04-*.spec.ts` (find via `ls tests/e2e/journey-04*`).

RECON EVIDENCE (verified at HEAD f04c1a2):
The chart at HEAD has NO Y-axis range configuration. `rightPriceScale` only sets `borderColor`. `autoScale` is not specified → defaults to `true`, meaning Y-axis fits to data range. With low-variance equity points around $100k starting capital, the Y-axis collapses to that ~$0.04 window.

YOUR DELIVERABLE:
After this team merges, the equity curve Y-axis must span a meaningful range relative to starting capital — never a sub-cent zoom that hides equity trajectory variance.

FIX APPROACH:
The simplest, smallest-blast-radius fix:

In `dashboard/app.js` `renderEquityCurve()` (around line 2095-2134), after `equitySeries.setData(deduped)` and before `equityChart.timeScale().fitContent()`:

1. Read starting capital: `const startingCapital = currentSession?.config?.starting_capital ?? deduped[0]?.value ?? 100000;`
2. Compute data range from `deduped`: `const minVal = Math.min(...deduped.map(p => p.value)); const maxVal = Math.max(...deduped.map(p => p.value));`
3. If `(maxVal - minVal) < 0.01 * startingCapital` (low variance), pin a range that anchors to starting capital with at least ±5% padding. Use LightweightCharts API: `equityChart.priceScale('right').applyOptions({ autoScale: false }); equityChart.priceScale('right').setVisibleRange({ from: startingCapital * 0.95, to: startingCapital * 1.05 });`
4. Else: leave autoScale: true (default behavior).

ALTERNATIVELY: always pin Y-axis to `[Math.min(startingCapital * 0.9, minVal), Math.max(startingCapital * 1.1, maxVal)]`. This is even simpler but loses fine-grained zoom on stable trajectories.

Pick whichever is cleaner. Verify against TradingView docs before writing.

VALIDATION:
- `npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-04-*.spec.ts` — existing tests + your new regression must pass.
- Add ONE regression assertion: after first FILLED order, the equity chart's Y-axis spans >= 5% of starting capital (not a sub-cent zoom). Use `await page.evaluate(() => window.__finletChart.priceScale('right').options())` or equivalent inspection.
- `uv run ruff check dashboard/` clean.

CRITICAL RULES:
- You MUST `git add` and `git commit` ALL your changes before finishing.
- Commit message must start with `[Team B]:`.
- Touch ONLY: dashboard/app.js (renderEquityCurve / initChart region around 2080-2446), tests/e2e/journey-04-*.spec.ts, team_b_verify.md.
- Do NOT touch dashboard/trade-ticket.js, dashboard/styles.css, dashboard/index.html, the SSE handlers around app.js:1456-1670, or the SIM TIME format change at app.js:1903.
- Preserve `equityChart.timeScale().fitContent()` at line 2134 — that's X-axis (time), separate from Y-axis (price).
- Preserve buffered-history replay at lines 2439-2445 (`_pendingEquityHistory`).
- Read `docs/KNOWN_FAILURES.md` first — do NOT report those as issues.
- Tools available: gh, aws, stripe, wrangler, uv, git, jq, curl, rg, fd, npx, playwright.

WRITE TO `/Users/justnau/finlet/docs/bug-hunt/20260505T175445Z750b/team_b_verify.md`:
- The fix approach you chose and why
- The new regression assertion
- Validation output (playwright + ruff)

WHEN DONE, REPORT:
- `DONE` + commit hash + validation results, OR
- `BLOCKED` + what went wrong.
