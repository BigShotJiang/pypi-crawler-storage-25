You are Team A — Trade Ticket Available Cash blank after BUY.

This is bug-hunt iteration 20260505T175445Z750b. Your worktree was forked at SPAWN_BASE_SHA = f04c1a2 (the orchestrator has already reset your worktree to this SHA before you started). The plan with full context is at `docs/bug-hunt/20260505T175445Z750b/plan.md` — read your team's section before doing anything else.

CONTEXT:
The blind agent observed: opening Trade Ticket on a fresh session shows "AVAILABLE CASH $100,000.00". After submitting a BUY AAPL order and the panel remains/is reopened, the value renders BLANK (label still present, dollar figure gone). This is the same surface as ledger entry `trade-ticket-stale-cash` (closed by v3.1 commit 8c55a90) — but the symptom mutated from "stale value" to "blank value", suggesting the v3.1 render-on-read contract is preserved but a different code path is failing.

READ THESE FILES FIRST:
- `docs/bug-hunt/20260505T175445Z750b/plan.md` — your team spec is "Team A".
- `docs/KNOWN_FAILURES.md` — do NOT report these as issues.
- `dashboard/trade-ticket.js:1-90` — getCanonicalCash, repaintCash contracts.
- `dashboard/trade-ticket.js:120-245` — openTradeTicket and dialogStateMirror wiring.
- `dashboard/trade-ticket.js:347-552` — submitTradeTicket post-submit IIFE (the v3.1 terminal repaintCash site).
- `dashboard/app.js:1456-1511` — SSE `portfolio` handler with terminal repaintCash.
- `dashboard/app.js:1525-1670` — SSE `orders` deferred-refetch IIFE with terminal repaintCash.
- `dashboard/dialog-state-mirror.js` — primeFromCache + onOpen ordering contract.
- `docs/decisions/trade-ticket-render-on-read.md` — v3 contract that REQUIRES payload values to be ignored.
- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` — v3.1 verdict.

YOUR DELIVERABLE:
After this team merges, opening the Trade Ticket panel after a BUY must show the post-fill cash within ≤500ms of click — never blank, never "Loading..." persisting beyond the dashFetch round-trip, never the pre-fill cash sticking.

PROCESS (CRITICAL — DO IT IN THIS ORDER):

1. **Reproduce the bug LOCALLY first** before writing any fix. Spin up `uv run finlet serve` in one terminal and open a browser to http://localhost:8000. Use the test user credentials from `~/.bug-hunt-loop/secrets.env` (FINLET_TEST_USER_EMAIL, FINLET_TEST_USER_PASSWORD). Walk the path: create session → open Trade Ticket → BUY 10 AAPL → close panel → reopen panel. Observe the `#tt-cash-balance.textContent` at each step (use DevTools console: `document.getElementById('tt-cash-balance').textContent`).

2. **Write your reproduction observations to `/Users/justnau/finlet/docs/bug-hunt/20260505T175445Z750b/team_a_verify.md`** in this format:
   ```
   ## Reproduction
   - Step 1 (after openTradeTicket on fresh session): textContent = "..."
   - Step 2 (after BUY submit success): textContent = "..."
   - Step 3 (after closeTradeTicket): textContent = "..."
   - Step 4 (after reopen via openTradeTicket): textContent = "..."
   - Step 5 (after async dashFetch resolves on reopen): textContent = "..."

   ## Root Cause
   [one paragraph: what code path produces the blank state, with file:line cite]

   ## Fix Approach
   [one paragraph: what change closes the gap]
   ```

3. **If you cannot reproduce the bug** (cash always shows correctly): demote this finding. Write to `team_a_verify.md`: "DEMOTED — cannot reproduce locally. Triage assertion was based on blind-agent observation that does not hold in repro. Recommend re-running blind walk to confirm symptom." Then SKIP the fix, do NOT modify any code, but DO commit team_a_verify.md (so we don't lose your repro work). Report `DEMOTED` in your final response and exit.

4. **If you can reproduce the bug**: write the targeted fix.
   - Modify `dashboard/trade-ticket.js` and/or `dashboard/app.js` to close the actual root cause you identified.
   - Preserve the v3.1 render-on-read contract: `repaintCash()` must continue to read canonical-only; never trust payload values.
   - Add ONE regression assertion to `tests/e2e/journey-05-trade.spec.ts` covering the BUY → close → reopen cash-display path. Do NOT use `value`-pinning or SSE-stub workarounds — those bypass the user-facing assertion this test must enforce.

5. **Validate** before commit:
   - `npx playwright test --config=tests/e2e/playwright.config.ts journey-05-trade.spec.ts` — your new regression assertion plus existing ones MUST pass.
   - `uv run ruff check dashboard/` (if dashboard is in ruff scope; otherwise dashboard linter equivalent).
   - The journey-05 poison-publish-after-close assertion at `tests/e2e/journey-05-trade.spec.ts:447-463` MUST still pass (do NOT regress the v3.1 closed-panel persistent-DOM rot fix).

CRITICAL RULES:
- You MUST `git add` and `git commit` ALL your changes before finishing. Worktree-isolated work that doesn't commit is lost when the worktree is cleaned up.
- Your commit message must start with `[Team A]:`.
- Do NOT modify files outside your scope (dashboard/trade-ticket.js, dashboard/app.js around lines 1456-1670, tests/e2e/journey-05-trade.spec.ts, and team_a_verify.md).
- Do NOT touch dashboard/styles.css or the equity-chart code in app.js (Teams B/C own those).
- Tools available: gh, aws, stripe, wrangler, uv, git, jq, curl, rg, fd, npx, playwright. See docs/tools/*.md for catalog.
- Read `docs/KNOWN_FAILURES.md` first — do NOT report those as issues.

WHEN DONE, REPORT:
- `DONE` + commit hash + validation results, OR
- `DEMOTED` + reason (cannot reproduce), OR
- `BLOCKED` + what went wrong (e.g., test infrastructure broken).
