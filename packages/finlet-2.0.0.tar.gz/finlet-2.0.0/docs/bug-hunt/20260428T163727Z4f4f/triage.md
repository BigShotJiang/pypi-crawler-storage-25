# Triage — 20260428T163727Z4f4f

## Broken (will be fixed this iteration)
- 401 on /v1/auth/session/validate fires on every page load while user is authenticated [evidence: "[ERROR] Failed to load resource: the server responded with a status of 401 () @ https://finlet.dev/v1/auth/session/validate:0 — appears in console on every navigation including the logged-in dashboard"] [scope hint: finlet/api/auth_routes.py, finlet/auth/session.py, dashboard/api-utils.js, dashboard/auth-bootstrap.js] [category: auth-validate-401]
- Welcome banner says "API server isn't running" while header simultaneously shows "● Connected" — UI state contradicts itself [evidence: "Header shows '● Connected' simultaneously with the alert 'It looks like the API server isn't running or you haven't created a session yet.' The API was fully operational — the misleading condition is the absence of a session, not a dead server."] [scope hint: dashboard/index.html, dashboard/app.js, dashboard/welcome-banner.js] [category: session-state-copy-mismatch]
- Three Plugin Health entries (finnhub, fred, edgar) show red "not initialized" with API key fields configured but no initialization handshake [evidence: "Plugin Health panel shows: 'finnhub plugin not initialized.', 'fred plugin not initialized.', 'edgar plugin not initialized.' All three have red dots. The Plugin Configuration page has API Key fields for them but they still show uninitialized."] [scope hint: dashboard/settings.js, dashboard/plugin-health.js, finlet/api/plugin_routes.py, finlet/plugins/__init__.py] [category: plugin-init-handshake]
- Spurious "Unsaved changes" banner on Plugins page with no user interaction — recurrence of iteration 20260428T031818Z2efa Item 3 [evidence: "Navigated directly to settings.html#plugins, did not modify any field, but a sticky 'You have unsaved changes | Discard | Save Changes' bar appeared at page bottom. Click on Discard timed out: 'element is outside of the viewport' after 5000ms."] [scope hint: dashboard/settings.html, dashboard/settings.js] [category: dirty-state-tracker]

## Logged (not actioned)
- settings.html 8 "Password field is not contained in a form" verbose DOM warnings — browser dev hint, not user-visible breakage [classification: annoying]
- Finlet benchmark MCP tool not present in .mcp.json — setup gap on bug-hunt-skill sandbox side, not a Finlet product defect (matches prior iteration triage) [classification: working-as-designed]
- Session name field does not auto-update when switching templates (Conservative ETF → Tech Growth keeps prior name) [classification: annoying]
- No "Fundamentals" strategy template in session creator despite fundamentals being a marketing headline [classification: annoying]
- news_s3 / sentiment plugins say "Run ingestion first" with no in-UI ingestion affordance [classification: annoying]
- Equity Curve blank after first trade on frozen clock — no in-UI hint that clock must advance [classification: annoying]
- Order Log "Reasoning" column shows "—" for UI-placed trades with no header tooltip / empty-state copy [classification: annoying]
- Onboarding step 2 copy lists template names but never mentions fundamentals plugin activation [classification: annoying]
- "Fundamentals" named strategy template (Value Stocks universe + EDGAR + fundamentals_s3 enabled) [classification: nice-to-have]
- "Run Ingestion Now" button on Plugin cards that show "No cached files" [classification: nice-to-have]
- Contextual "Advance the clock to see your equity curve update" nudge after first trade on frozen clock [classification: nice-to-have]
- MCP server setup wizard / one-click .mcp.json generator in the dashboard [classification: nice-to-have]

## Notes

### 1. Refactor effectiveness check

This walk evaluates whether today's dashboard event-bus refactor (commits `631d1b1`, `c0d8edb`, `798904c`) closed the recurring categories.

| Category | Morning iteration `20260428T073733Z0944` | This walk `20260428T163727Z4f4f` | Verdict |
|----------|------------------------------------------|----------------------------------|---------|
| `dashboard-state-sync` (Trade Ticket cash header stale post-FILL) | Item 2 | NOT REPORTED | ✅ Refactor closed for the trade-ticket surface — `bus.subscribe` wiring works live |
| `onboarding-checklist` (checklist desync) | NOT EXERCISED meaningfully here | NOT REPORTED | ✅ Provisional — flow not deeply re-tested |
| `trusted-types` (CSP/innerHTML violations) | Pre-commit guard added | NOT REPORTED | ✅ Provisional — pre-commit guard appears effective |
| `modal-stacking` (wizard overlay blocks Create Session modal) | Item 1 | NOT REPORTED | ⚠️ Cannot conclude — agent's flow this walk did not include the same modal interaction; needs targeted re-test |
| `dirty-state-tracker` (Settings unsaved-changes banner on initial load) | Item 3 | RECURS (Plugins page) | ❌ Refactor did NOT touch `settings.js` — known scope gap, must be addressed in this iteration |

### 2. Isolation leak

The blind report's `_isolation_check` field is non-empty — the agent listed 6 Finlet-specific facts despite clean-room instructions:

1. "This project is the Finlet server codebase (FastAPI + FastMCP backend, static HTML frontend)."
2. "MCP server has 16 tools: get_price_data, search_news, get_fundamentals, get_filings, get_economic_data, submit_order, get_portfolio, cancel_order, get_orders, get_sim_time, advance_time, freeze_time, start_benchmark, get_benchmark_progress, export_benchmark_results."
3. "Leaderboard has 5 frozen scenarios: Bull Run, COVID Crash, Sideways Chop, VIX Blowup, Recovery Rally."
4. "fundamentals_s3 plugin had 21 cached files; price plugin had 6; news_s3 and sentiment had 0."
5. "API base is /v1 on finlet.dev. Auth is Bearer token via X-API-Key header."
6. "The session created was named 'Fundamentals Strategy', Tech Growth template, $100k capital, start date 2025-04-28."

Clean-room isolation is failing. Note for the skill maintainer; not a hard-fail this iteration.

### 3. Recurrence ledger lookup

Buckets across `/Users/justnau/finlet/docs/bug-hunt/ledger.jsonl` (14 entries across 2 prior iterations + 4 new from this iteration):

| Category | Prior count | This iter | Total | Recurring? |
|----------|-------------|-----------|-------|------------|
| `onboarding-checklist` | 4 | 0 | 4 | ✅ recurring (4×) |
| `trusted-types` | 3 | 0 | 3 | ✅ recurring (3×) |
| `dashboard-state-sync` | 3 | 0 | 3 | ✅ recurring (3×) |
| `dirty-state-tracker` | 1 | 1 | 2 | ✅ recurring (2×) |
| `modal-stacking` | 1 | 0 | 1 | (1×) |
| `connection-toast-stuck` | 1 | 0 | 1 | (1×) |
| `vendor-bypass` | 1 | 0 | 1 | (1×) |
| `auth-validate-401` (NEW) | 0 | 1 | 1 | (1×) |
| `session-state-copy-mismatch` (NEW) | 0 | 1 | 1 | (1×) |
| `plugin-init-handshake` (NEW) | 0 | 1 | 1 | (1×) |

The refactor was specifically aimed at closing `dashboard-state-sync`, `onboarding-checklist`, and `trusted-types` — all three are absent in this walk. `dirty-state-tracker` is now confirmed recurring (2×) and was outside the refactor's scope. Three new categories minted this iteration.
