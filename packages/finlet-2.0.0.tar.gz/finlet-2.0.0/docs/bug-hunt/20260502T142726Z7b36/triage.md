## Broken (will be fixed this iteration)

- Trade Ticket "Available Cash" does not refresh after a filled order — dialog stays at $100,000.00 while Key Metrics "Cash" tile correctly shows $94,473.07; recurrence of `trade-ticket-stale-cash` post-refactor (efdd443). [evidence: "After BUY 10 SPY @ $552.69 filled (POST /v1/sessions/a180bb24ec2a/trade/order → 201), the #trade-ticket-panel Available Cash field still shows $100,000.00. The Key Metrics 'Cash' tile correctly updated to $94,473.07. The Trade Ticket never refreshed its cash figure; a second trade placed immediately could overdraft without warning."] [scope hint: dashboard/trade-ticket.js, dashboard/app.js]
- Price plugin reports conflicting health between Settings (degraded — "Run ingestion first") and Dashboard (healthy — "OK — 6 cached files") in the same session 3 minutes apart — two health-check paths disagree. [evidence: "Settings > Plugins (visited ~14:33 UTC) shows 'price' with a yellow/degraded dot and message: 'No price data files found in s3://finlet-data-cccdea31/prices/daily/ for the last 7 days. Run ingestion first.' Dashboard Plugin Health widget (captured ~14:36 UTC, screenshot: dashboard-post-trade.png) shows 'price' with a green/healthy dot and 'OK — 6 cached files'. Same session, same user, 3 minutes apart. The two health-check paths disagree."] [scope hint: dashboard/settings.js, finlet/api/routes_health.py, finlet/plugins/price_plugin.py]
- Internal S3 bucket name (`finlet-data-cccdea31`) leaked verbatim in user-facing plugin error copy — internal infrastructure must not appear in UI strings. [evidence: "The price plugin degraded message reads verbatim: 'No price data files found in s3://finlet-data-cccdea31/prices/daily/ for the last 7 days.' The bucket name (finlet-data-cccdea31) is internal infrastructure and should not appear in user-facing UI copy. Screenshot: settings-plugins.png."] [scope hint: finlet/plugins/price_plugin.py, finlet/api/routes_health.py]
- news_s3 and sentiment plugin rows show "Run ingestion first" guidance with no Ingest/Refresh/Sync button anywhere in the UI — documented recovery action has no affordance. [evidence: "news_s3 and sentiment show yellow: 'No cached … data files found. Run ingestion first.' There is no 'Initialize', 'Enable', or 'Run ingestion' button anywhere in the UI. Users are left with broken plugins and no recovery path from the browser."] [scope hint: dashboard/settings.html, dashboard/settings.js]

## Logged (not actioned)

- Finlet benchmark MCP tool not registered in this evaluation session [classification: working-as-designed] — launcher-infra concern (clean-room subprocess strips PATH that includes finlet MCP), not a finlet.dev product bug.
- finnhub/fred/edgar plugins show "not initialized" — these have an API-key input and Save button which IS the documented recovery affordance [classification: working-as-designed]
- "Set up a fundamentals strategy — Install and configure it" maps to no named UI concept [classification: annoying]
- Settings sidebar has two separate "API Keys" navigation items [classification: annoying]
- Onboarding wizard Step 2 does not auto-advance after session creation completes [classification: annoying]
- Onboarding wizard Step 2 body has two identically-labeled "Open Session Creator" buttons [classification: annoying]
- "Getting Started" checklist does not tick "Set up profile" after persona selection [classification: annoying]
- Report a Bug mailto link bakes in a stale page-load timestamp [classification: annoying]
- Equity curve y-axis shows floating-point imprecision at $100,000 starting value [classification: annoying]
- Clock defaults to FROZEN on session start with no prompt to begin simulation [classification: annoying]
- No in-UI trigger for data ingestion (CLI required) [classification: nice-to-have]
- No documentation link or tooltip per plugin explaining required API key [classification: nice-to-have]
- No strategy builder or saved-strategy concept [classification: nice-to-have]
- Order Log has no "Closed P&L" column [classification: nice-to-have]
- No search or filter on Plugin Health dashboard widget [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260502T142726Z7b36 — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. `docs/bug-hunt/20260502T142726Z7b36/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log,
   deploy_status.txt, retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260502T142726Z7b36","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline (see
   Phase 5.5c). Team D MUST stage the file. If a refactor verdict pruned entries
   this iteration, Team D MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`
   (the audit log of resolved signals).

Team D's commit message must reference iteration 20260502T142726Z7b36 and name which docs were
touched (e.g., "docs: bug-hunt 20260502T142726Z7b36 — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
