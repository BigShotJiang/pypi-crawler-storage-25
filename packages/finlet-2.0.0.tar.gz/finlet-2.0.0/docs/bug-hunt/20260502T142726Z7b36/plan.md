# Bug Hunt 20260502T142726Z7b36 — Execution Plan

> Generated from `docs/bug-hunt/20260502T142726Z7b36/triage.md`. Last updated: 2026-05-02

## Constraints

- 4 real-broken findings to close. Two are post-refactor recurrences (forward signals for the next refactor gate; this iteration patches them, the gate handles them next iteration if they recur again).
- Bug-hunt loop is patch-only. Do NOT attempt convention-level rewrites.
- Every team MUST `git add` + `git commit` before finishing — worktree cleanup destroys uncommitted work.
- All changes merge to `origin/main`; deploy auto-triggers via `.github/workflows/deploy.yml` and Phase 5.5 retest verifies on `https://finlet.dev`.
- Team B and Team C share a contract for the ingest endpoint: `POST /v1/plugins/{name}/ingest → 202 Accepted, body {"job_id": "<string>"}`. Define this contract in Team B; Team C calls it as the documented surface. Stub implementations are acceptable as long as they return 202 with a job_id.

## File Conflict Table

| File | Touched by Teams |
|------|------------------|
| `dashboard/trade-ticket.js` | A |
| `dashboard/app.js` | A |
| `dashboard/settings.js` | C |
| `dashboard/settings.html` | C |
| `finlet/plugins/price_plugin.py` | B |
| `finlet/plugins/news_plugin.py` (or similar S3-cache plugin) | B |
| `finlet/plugins/sentiment_plugin.py` | B |
| `finlet/plugins/fundamentals_plugin.py` | B |
| `finlet/api/routes_health.py` | B |
| `finlet/api/routes_plugins.py` (or new file for ingest endpoint) | B |
| `tests/dashboard/trade-ticket.spec.js` (if exists) | A |
| `tests/api/test_plugin_health.py` | B |
| `tests/api/test_plugins.py` (or new) | B |
| `tests/dashboard/settings.spec.js` (if exists) | C |
| `docs/REMAINING_TASKS.md`, `docs/LESSONS.md`, `docs/ARCHITECTURE.md`, `docs/KNOWN_FAILURES.md`, `docs/bug-hunt/20260502T142726Z7b36/*`, `docs/bug-hunt/ledger.jsonl` | D |

**No A/B/C file conflicts.** Teams A, B, C are fully parallelizable.

## Dependency Graph

- **Team A** — independent. Frontend trade-ticket cash refresh fix. No upstream dependency.
- **Team B** — independent. Backend plugin probe message sanitization + new `POST /v1/plugins/{name}/ingest` endpoint contract. No upstream dependency.
- **Team C** — logically coupled to Team B (calls B's new ingest endpoint), but no file conflict. Can develop in parallel against the documented contract above.
- **Team D** — blocked by A + B + C. Records what landed in `ledger.jsonl`, refreshes docs, commits artifacts.

## Critical Path

`A,B,C (parallel) → D`

Critical path length: 2 stages. A/B/C run concurrently; D follows once all three are merged on `main`.

---

## Teams

### Team A: Trade Ticket Cash Refresh (frontend)

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/trade-ticket.js` — `paintCash()` at lines 20-25 (renders `#trade-ticket-panel` Available Cash); `tradeTicketMirror` at lines 161-207 (subscribes to `portfolio:updated` via `dialogStateMirror`). Note: this file owns the dialog-mirror lifecycle; investigate whether the panel surface uses the same lifecycle or a panel-only override.
- `dashboard/app.js` — order-filled SSE handler region around line 1608 (where prior fix `3a2bf46` republished `portfolio:updated`). Line 1472 region publishes `portfolio:updated` from generic SSE refetch.
- `dashboard/event-contract.md` — documents `portfolio:updated` payload shape; if you add a new publish site, update the contract in the same commit.
- Prior ledger entries that closed the same shape: `trade-ticket-stale-cash` (commit `3a2bf46`), `trade-ticket-cash-stale-during-fill` (commit `086c558`), `trade-ticket-cash-dash` (commit `f8a8365`). The pattern fix has shipped 3x already — check what specifically the panel-vs-modal distinction is hiding.

**Files touched:**
- Modified: `dashboard/trade-ticket.js` — ensure `paintCash()` runs on every `portfolio:updated` AND that the mirror subscribes BEFORE the dialog/panel opens (open-then-subscribe race is a known prior failure mode for this category).
- Modified: `dashboard/app.js` — verify the `order:filled` SSE handler refetches the portfolio and republishes `portfolio:updated` with the post-fill cash. If the publish is missing or shape-drifted, fix it.
- Modified: `dashboard/event-contract.md` — only if the publish site or payload changes.
- Add or update: regression test under `tests/e2e/journey-05-trade.spec.ts` (or `tests/dashboard/trade-ticket.spec.js`) — assert Trade Ticket panel cash equals Key Metrics cash within 3 seconds of `order:filled` SSE.

**Deliverable:** After a MARKET BUY fills, `#trade-ticket-panel` Available Cash header equals the Key Metrics Cash tile within 3 seconds, and `portfolio:updated` carries the post-fill cash figure.

**Validation:**
- [ ] `uv run pytest tests/dashboard/ tests/e2e/ -k 'trade_ticket or cash' -q` passes (or the equivalent npm/Playwright command for the e2e suite if applicable).
- [ ] Manually verify in a local browser tab: log in, create a session, place BUY 10 SPY market — Trade Ticket cash header changes from $100,000.00 to the post-fill value within 3s. Key Metrics tile and Trade Ticket header agree.
- [ ] No regressions in `journey-04-dashboard.spec.ts` or `journey-05-trade.spec.ts`.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Worktree cleanup destroys uncommitted work.
- Use existing `window.finletBus` API — do NOT use raw `addEventListener('finlet:...')` or `dispatchEvent(new CustomEvent('finlet:...'))`. CLAUDE.md and `docs/decisions/dashboard-event-bus.md` enforce this.
- Re-read `paintCash()` and `tradeTicketMirror` after your edit to confirm subscribe-before-open ordering. The shape is documented in `docs/decisions/dialog-state-mirror-prime-ordering.md`.
- Commit message must reference iteration `20260502T142726Z7b36` and the prior ledger ID `trade-ticket-stale-cash`. Example: `[Team A] dashboard: Trade Ticket cash refresh post order:filled (close trade-ticket-stale-cash recurrence; iteration 20260502T142726Z7b36)`.

---

### Team B: Plugin Probe Sanitization + Ingest Endpoint (backend)

**Blocked by:** none — can start immediately.

**Read these files first:**
- `finlet/plugins/price_plugin.py` — `_probe()` at lines 792-883, `_render_probe_health()` at lines 857-883. **Line 880 is the f-string that interpolates the bucket name into the user-facing message.** That string is the leak.
- `finlet/api/routes_health.py` — `_check_price_data_status()` at lines 25-52, `plugins_health()` endpoint at lines 84-114 (this is the canonical health surface).
- `finlet/api/routes_settings.py` — GET `/plugins` at lines 119-127, PUT `/plugins` at lines 128-146 (this is where Settings UI hits today; verify whether settings.js queries a different surface than `/v1/plugins/health`).
- `finlet/plugins/news_plugin.py` (or `news_s3` plugin file), `finlet/plugins/sentiment_plugin.py`, `finlet/plugins/fundamentals_plugin.py` — grep for any `s3://` or `finlet-data-` literal in error/probe message strings; same pattern leak.
- Prior ledger entry: `plugin-health-degraded-but-fills-succeed` (commit `76f4724`). Read commit `76f4724`'s diff — the prior fix rewrote `_probe()` for cache-non-empty fast path; check that follow-on plugins follow the same convention.

**Files touched:**
- Modified: `finlet/plugins/price_plugin.py` — replace bucket-leaking message with generic copy: "No price data available for the last 7 days. Run ingestion first." (no `s3://`, no bucket name). Same for `_render_probe_health`.
- Modified: `finlet/plugins/news_plugin.py` (or `news_s3_plugin.py`), `sentiment_plugin.py`, `fundamentals_plugin.py` — apply the same generic-copy convention if they leak bucket names.
- Modified: `finlet/api/routes_health.py` — verify `plugins_health()` propagates the sanitized message; verify `_check_price_data_status` translator does NOT reintroduce the bucket name.
- New: `POST /v1/plugins/{name}/ingest` endpoint — define in `finlet/api/routes_plugins.py` (create the file if it does not exist). Contract: returns 202 Accepted with body `{"job_id": "<string>"}`. Stub implementation acceptable for v1 (return a UUID + log "ingest requested for {name}"); real ingestion job-runner can follow.
- Modified or new: `tests/api/test_plugin_health.py` — assert no plugin-health response field contains `s3://` or `finlet-data-`. Add `tests/api/test_plugins_ingest.py` for the new endpoint (auth required, returns 202 + job_id).

**Deliverable:** `GET /v1/plugins/health` (and any other plugin-health surface) never returns a string containing `s3://` or `finlet-data-` substrings. `POST /v1/plugins/{name}/ingest` returns 202 + `{"job_id": "<string>"}` with auth, 401 without.

**Validation:**
- [ ] `uv run pytest tests/api/test_plugin_health.py tests/plugins/ -q` passes.
- [ ] `uv run pytest tests/api/test_plugins_ingest.py -q` passes (new file).
- [ ] `grep -rE 's3://|finlet-data-' finlet/plugins/ finlet/api/` returns zero matches in user-facing message strings (matches in comments/log statements are fine — focus on strings that flow to API responses).
- [ ] `curl -fsS -H "Authorization: Bearer $FINLET_TEST_USER_API_KEY" $FINLET_BASE_URL/v1/plugins/health | jq '.plugins[].message' | grep -E 's3://|finlet-data-'` returns nothing on prod after deploy.
- [ ] `uv run ruff check finlet/` passes.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Generic copy convention: never include bucket names, file paths inside the AWS account, or env-suffixed identifiers in user-facing strings. The user-facing message must be reproducible across staging/prod without revealing infra topology.
- The ingest endpoint can be a stub for this iteration. Do not block on building a real job runner — the v1 goal is closing the dead-affordance bug. Add a TODO comment referencing the iteration.
- Commit message: `[Team B] plugins+api: sanitize probe messages + add POST /v1/plugins/{name}/ingest stub (close info-leak-in-error-copy + scaffold dead-recovery-affordance; iteration 20260502T142726Z7b36)`.

---

### Team C: Settings Health Endpoint Convergence + Ingest Button (frontend)

**Blocked by:** none for development. Validation against prod requires Team B's ingest endpoint to be deployed; Team C's UI MUST call the documented contract `POST /v1/plugins/{name}/ingest → 202 + {"job_id"}` regardless.

**Read these files first:**
- `dashboard/settings.js` — `loadPlugins()` at lines 982-1057 (renders plugin cards), `savePluginConfig()` referenced at line 1053. Find the exact endpoint settings.js currently fetches for plugin health (grep `/v1/plugins`, `/plugins/health`, `/api/plugins`). The dashboard widget calls `/v1/plugins/health`; Settings must call the same.
- `dashboard/settings.html` — plugin config section at lines 324-330 (`#plugin-config-list` container).
- `dashboard/index.html` (or `dashboard/app.js`) — find the dashboard Plugin Health widget's fetch call (this is the canonical surface Settings should mimic).
- `dashboard/event-contract.md` — if you add a new bus event for "ingest requested" or similar, document it.
- Prior ledger entry: `cli-plugins-list-mismatch` (commit `1616ade`) — the CLI was reporting different plugin set than the dashboard; convergence fix moved CLI to GET `/v1/plugins/health`. Same shape applies here.

**Files touched:**
- Modified: `dashboard/settings.js` — change the plugin-health fetch to `GET /v1/plugins/health` (the same endpoint the dashboard widget uses). Render `status` + `message` fields directly from that response — no client-side reinterpretation. Add `renderIngestButton(plugin)` helper that shows an "Ingest" button on each row whose `message` contains the substring "Run ingestion" (case-insensitive). On click: `POST /v1/plugins/{plugin.name}/ingest`, on 202 show "Ingestion queued (job: {job_id})" toast, on error show generic failure toast.
- Modified: `dashboard/settings.html` — only if a new container is needed for the Ingest button (likely the row template can absorb it inline; minimal HTML change).
- Modified or new: `tests/e2e/journey-06-settings.spec.ts` — extend with assertions: (1) Settings price status text equals Dashboard price status text within the same login; (2) news_s3 row exposes an enabled "Ingest" button when its message says "Run ingestion first"; (3) clicking the button issues a POST to `/v1/plugins/news_s3/ingest`.

**Deliverable:** Settings > Plugins and Dashboard Plugin Health widget report identical status + message for every plugin in the same login. Plugin rows whose `message` contains "Run ingestion" expose an enabled "Ingest" button that POSTs to the documented endpoint.

**Validation:**
- [ ] Local: `npx playwright test tests/e2e/journey-06-settings.spec.ts` passes.
- [ ] Local: log in, open `/settings.html#plugins`, observe price plugin status. Open `/index.html`, observe price plugin row in dashboard widget. Statuses match.
- [ ] Local: open `/settings.html#plugins`, news_s3/sentiment rows show an Ingest button. Click → network tab shows POST to `/v1/plugins/{name}/ingest`. Toast appears.
- [ ] No regressions in any other Settings tab — dirty-state tracker, password forms, etc. Re-run `journey-06-settings.spec.ts` end to end.
- [ ] `bash scripts/lint-trusted-types.sh` passes (any new innerHTML must be wrapped in `trustedHTML(...)`).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Use `window.finletBus` for any cross-component event publishing — never `addEventListener('finlet:...')` raw.
- Use `trustedHTML(...)` for any new innerHTML write under `dashboard/`. The pre-commit hook (`scripts/lint-trusted-types.sh`) blocks bare `.innerHTML =` writes.
- Form-dirty-tracker: if your changes register new inputs that the tracker should observe, register their loader promise via `registerLoader(promise)`. The dirty-state-tracker convention is documented in `docs/decisions/dashboard-form-dirty-tracker-registry.md`.
- The Ingest button click handler MUST NOT block the UI. Show an in-flight state (button disabled + spinner) until the 202 response or error.
- Commit message: `[Team C] dashboard: Settings calls canonical /v1/plugins/health + add Ingest button for S3-cache plugins (close plugin-health-degraded-but-fills-succeed recurrence + dead-recovery-affordance; iteration 20260502T142726Z7b36)`.

---

### Team D: Docs + Ledger

**Blocked by:** A + B + C all merged to `main`.

**Read these files first:**
- `docs/REMAINING_TASKS.md` — see prior "Bug Hunt YYYYMMDDT… — Closed" subsections; mirror the structure.
- `docs/LESSONS.md` — see prior lessons added per real-broken finding; lessons must be reusable rules, not diff recaps.
- `docs/ARCHITECTURE.md` — touch only if any architectural surface (route surface, plugin registry, dashboard component contract) changed. The new `POST /v1/plugins/{name}/ingest` endpoint IS a route-surface change — add it.
- `docs/KNOWN_FAILURES.md` — refresh; remove any pre-existing failure resolved this iteration.
- `docs/bug-hunt/ledger.jsonl` — see prior entries; the schema is `{"iteration_ts","finding_id","category","summary","scope_files","team","commit"}` per JSON line.
- `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md` — set `verdict:` once Phase 6 evaluates this iteration's outcome (Team D may not own this; orchestrator handles in Phase 6).

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — add "Bug Hunt 20260502T142726Z7b36 — Closed" subsection listing the 4 real-broken findings closed.
- Modified: `docs/LESSONS.md` — append at least one lesson per real-broken finding. Examples:
  - "Plugin probe messages must never include bucket names, S3 paths, or env-suffixed identifiers — generic copy only."
  - "Settings UI must consume the same plugin-health surface as the dashboard widget — divergent surfaces drift."
  - "When a recurrence carries `same_root_cause_as` to a recently-closed entry, patch the recurrence AND surface the cluster for next iteration's gate (do not assume the prior refactor was incomplete; recurrences are forward signals)."
  - "Documented recovery actions in error copy ('Run ingestion first') must have a UI affordance, not just CLI guidance."
- Modified: `docs/ARCHITECTURE.md` — add `POST /v1/plugins/{name}/ingest` to the API surface section. Skip with explicit note if no other architectural change.
- Modified: `docs/KNOWN_FAILURES.md` — refresh.
- Append: `docs/bug-hunt/ledger.jsonl` — exactly 4 JSON lines, one per real-broken finding closed. Schema:
  ```jsonl
  {"iteration_ts":"20260502T142726Z7b36","finding_id":"trade-ticket-cash-recurrence-2","category":"dashboard-state-sync","summary":"Trade Ticket Available Cash stale after fill — recurrence post 3a2bf46","scope_files":["dashboard/trade-ticket.js","dashboard/app.js"],"team":"A","commit":"<merge-sha>"}
  {"iteration_ts":"20260502T142726Z7b36","finding_id":"plugin-health-info-leak","category":"info-leak-in-error-copy","summary":"Internal S3 bucket name finlet-data-cccdea31 leaked in plugin probe messages","scope_files":["finlet/plugins/price_plugin.py","finlet/api/routes_health.py"],"team":"B","commit":"<merge-sha>"}
  {"iteration_ts":"20260502T142726Z7b36","finding_id":"plugin-health-settings-dashboard-divergence","category":"plugin-registry-routing","summary":"Settings vs Dashboard price plugin health disagree — Settings calls non-canonical health surface","scope_files":["dashboard/settings.js","finlet/api/routes_health.py"],"team":"C","commit":"<merge-sha>"}
  {"iteration_ts":"20260502T142726Z7b36","finding_id":"news-sentiment-no-ingest-button","category":"dead-recovery-affordance","summary":"news_s3/sentiment plugins say 'Run ingestion first' with no UI affordance — added Ingest button + POST /v1/plugins/{name}/ingest stub","scope_files":["dashboard/settings.js","dashboard/settings.html","finlet/api/routes_plugins.py"],"team":"B+C","commit":"<merge-sha>"}
  ```
  After commit, `wc -l docs/bug-hunt/ledger.jsonl` must grow by exactly 4 lines.
- Stage: every file under `docs/bug-hunt/20260502T142726Z7b36/` (plan.md, triage.md, triage.json, blind_report.json, blind_wrapper.json, blind_run.log, blind_exit.txt, cleanup.log, isolation_warning.txt, blind_result.txt, deploy_status.txt, retest_results.json — whichever exist post Phase 5.5).

**Deliverable:** All required docs updated; ledger grew by 4 lines; iteration artifacts committed; commit message references iteration `20260502T142726Z7b36`.

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` = (prior count) + 4.
- [ ] `jq -c .` passes on every line of `ledger.jsonl` (each line is valid JSON).
- [ ] `git status` shows zero unstaged changes after commit.
- [ ] Commit message includes iteration ID and a one-line summary per doc touched.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Read each prior ledger entry's structure before appending. Reuse existing categories (`dashboard-state-sync`, `info-leak-in-error-copy`, `plugin-registry-routing`, `dead-recovery-affordance`) — only mint new ones if no existing fits. The triage already chose categories for you.
- The `commit` field for each ledger line MUST be the SHA of the merge commit (or the team's commit on `main`) for that team's work. Read `git log --oneline main -10` after Teams A/B/C merge to find the SHAs.
- Skip nothing silently. If `ARCHITECTURE.md` truly has nothing to update, say so explicitly in the commit message: `ARCHITECTURE: + POST /v1/plugins/{name}/ingest`. If `LESSONS.md` has no new lessons (very unlikely with 4 real-broken items), say `LESSONS: no new lessons this iteration` in the commit message.
- Commit message: `[Team D] docs: bug-hunt 20260502T142726Z7b36 — record fixes for trade-ticket cash, plugin info-leak, settings/dashboard health divergence, dead-recovery-affordance; LESSONS +4; ARCHITECTURE +ingest; ledger +4`.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Team A fix is yet another partial — the fourth recurrence of `trade-ticket-stale-cash` | Medium | High (forward signal trips refactor gate next iteration) | Read all three prior ledger entries in this category before patching. Add an e2e regression test that exercises the panel-vs-modal distinction explicitly. |
| Team B's stub ingest endpoint passes the retest but doesn't actually ingest | Medium | Medium | The retest only asserts 202 + job_id, which the stub satisfies. Real-ingestion follow-up is out of scope this iteration; surface as a known limitation in `docs/REMAINING_TASKS.md`. |
| Team C's Settings health endpoint change breaks an unrelated Settings tab | Medium | Medium | Re-run `journey-06-settings.spec.ts` end to end after change. Verify dirty-state tracker, password forms, profile, notifications, appearance tabs all still render. |
| Team C's Ingest button violates trusted-types CSP | Medium | High (page-load CSP violation) | Use `trustedHTML(...)` for any innerHTML write. Pre-commit hook `scripts/lint-trusted-types.sh` enforces this — make sure it runs. |
| `dashboard/settings.js` change introduces a new `setFieldDirty` path that flashes the unsaved-changes banner on cold load | Medium | Medium (recurrence of `dirty-state-tracker`) | Any new field registration MUST go through `registerLoader(promise)` per `docs/decisions/dashboard-form-dirty-tracker-registry.md`. Re-test cold load — banner must not appear. |
| Team B's generic-copy change breaks an existing test that asserts the bucket-name string | Low | Low | Search for the exact substring `finlet-data-cccdea31` and `s3://` in `tests/` before changing the message. Update assertions. |
| Phase 5.5 retest agent leaks sessions and cascades to rate-limit (per-tier 1-session concurrent limit) | Medium | Medium | Each retest's `cleanup` field MUST run regardless of assertion outcome — agent must wrap in try/finally semantics. (Already documented in skill spec.) |
| The same-root-cause forward signals (trade-ticket-stale-cash, plugin-health-degraded-but-fills-succeed) trip the refactor gate next iteration | High | Pre-launch acceptable | Expected. The next iteration's gate routes both clusters to refactor. This iteration patches; next iteration converts to convention. |

## Session Plan

### Session 1 (this iteration)

**Parallel:** Teams A, B, C — no shared files, fully concurrent.
**Merge order:** A merges first (smallest blast radius, frontend-only) → targeted tests on main → B merges → tests → C merges → tests.
**Reasoning for merge order:** A is purely frontend with the smallest diff. B introduces a new API surface (ingest endpoint) — merging it before C means C can call the live endpoint in the post-deploy retest. C merges last because it consumes B's contract.

**Per-merge gate:** after each team merges, run that team's validation block (above) on `main` before the next merge. If a team's validation fails on `main`, BLOCK the next merge and surface the failure in the iteration's report.

**Session checkpoint after A+B+C merged:** full test suite — `uv run pytest -q` for backend, `npx playwright test` for frontend. Zero failures gates Team D.

### Session 2 (sequential)

**Single team:** Team D — docs + ledger.
**Merge:** D merges to main once A+B+C are in. No further teams.

**Final checkpoint:** `git log --oneline main -10` shows 4 team commits + (optionally) merge commits. `wc -l docs/bug-hunt/ledger.jsonl` grew by 4.

---

## Notes for the Phase 5.5 retest agent

Each real-broken item carries a `retest:` envelope in `triage.json`. The retest agent will exercise these against the live `https://finlet.dev` after deploy. Two of the four envelopes have a `cleanup` step — the cleanup MUST run regardless of assertion outcome to avoid the per-tier 1-session-concurrent rate-limit cascade.

The Settings/Dashboard convergence retest (Finding 2) needs only login + page navigation — no session creation. Run it first; it cannot leak any state.
