# Bug-Hunt Iteration 20260429T052717Z1a13 — Execution Plan

> Generated from `docs/bug-hunt/20260429T052717Z1a13/triage.md` via `/plan-features`.
> Last updated: 2026-04-29.
> Blind walk: `docs/bug-hunt/20260429T052717Z1a13/blind_report.json` (15 findings, 5 real-broken, isolation clean).
> Excluded from this iteration: `auth-validate-401` (deploy-lag, fixed on main at `17fccf1`/`275c7c0`, will resolve when next deploy fires).

## Constraints

- 4 real-broken items to fix (5 minus the deploy-lag exclusion).
- 3 of the 4 are `dashboard-state-sync` category; 1 is `dirty-state-tracker` (recurring after the 2026-04-28 refactor — verdict will be set `incomplete` in Phase 6).
- Heavy file contention on `dashboard/app.js` (Bug 1 + Bug 3 both write it) forces sequential merge.
- Dirty-state-tracker refactor's per-loader snapshot pattern (commit `7d09997`) must be respected in the Bug 2 fix; do not rip it out.
- All E2E regressions must use `page.route()` stubs where possible (avoid live API dependency on the merge gate).

## File Conflict Table

| File | Bugs / Teams touching it (write) |
|------|------|
| `dashboard/app.js` | Team B (Bug 1), Team C (Bug 3) — **sequential** |
| `dashboard/index.html` | Team C (Bug 3) only — read-only by Team B |
| `dashboard/settings.js` | Team A (Bug 2) only |
| `dashboard/settings.html` | Team A (Bug 2) only |
| `dashboard/trade-ticket.js` | Team D (Bug 4) only |
| `finlet/api/routes_portfolio.py` | Team C (Bug 3) only — read-only verification |
| `tests/e2e/journey-04-dashboard.spec.ts` | Team C (Bug 3) — equity curve regression |
| `tests/e2e/journey-05-trade-ticket.spec.ts` (or sibling) | Team D (Bug 4) — cash regression |
| `tests/e2e/journey-06-settings.spec.ts` | Team A (Bug 2) — dirty banner regression |
| `tests/e2e/journey-04-dashboard.spec.ts` (session create) | Team B (Bug 1) — template-switch regression. SHARED with Team C |
| `docs/bug-hunt/ledger.jsonl` | Team E — append-only, last to merge |
| `docs/REMAINING_TASKS.md`, `docs/LESSONS.md`, `docs/KNOWN_FAILURES.md`, `docs/ARCHITECTURE.md`, `docs/bug-hunt/20260429T052717Z1a13/*` | Team E — last to merge |

**Key conflict:** `dashboard/app.js` (Teams B + C) and `tests/e2e/journey-04-dashboard.spec.ts` (Teams B + C). Forces B → C sequential.

## Dependency Graph

```
Team A (Bug 2 — settings dirty banner) ── independent, parallel-safe
Team B (Bug 1 — session-name template) ── independent at start, blocks Team C on app.js
Team C (Bug 3 — equity curve)          ── blocked by Team B (app.js + journey-04 spec)
Team D (Bug 4 — trade ticket cash)     ── independent, parallel-safe
Team E (docs + ledger)                 ── blocked by ALL bug teams (needs merge SHAs)
```

## Critical Path

`Team B → Team C → Team E` (3 sequential teams). Teams A and D run in parallel with B/C.

---

## Teams

### Team A: Bug 2 — Settings Dirty Banner (recurring)

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/settings.js:23-59` — DOMContentLoaded handler that awaits loaders.
- `dashboard/settings.js:160-216` — `initFormTracking()` including the rAF re-snapshot at line 201.
- `dashboard/settings.js:302-322` — `loadProfile()` and its `snapshotFields()` call.
- `dashboard/settings.js:118-129` — comments referencing the per-loader snapshot pattern (introduced in commit `7d09997`).
- Commit `7d09997` (Team A dirty-state-tracker refactor): `git show 7d09997 -- dashboard/settings.js` to see the intended fix.
- `dashboard/settings.html` — to confirm the unsaved-changes banner element selector.

**Files touched:**
- Modified: `dashboard/settings.js` — fix the load-vs-baseline race in the rAF re-snapshot path.
- Modified (test): `tests/e2e/journey-06-settings.spec.ts` — add or extend a test that asserts the banner is hidden on cold load with the Profile section active.

**Deliverable:** On a fresh load of `settings.html` with the Profile section active, the "You have unsaved changes" banner is NOT visible until the user actually edits a field. The dirty-state-tracker refactor's per-loader snapshot pattern is preserved (don't revert to the pre-refactor approach).

**Validation:**
- [ ] `npx playwright test tests/e2e/journey-06-settings.spec.ts -g "unsaved" --reporter=line` — new/extended test passes.
- [ ] `npx playwright test tests/e2e/journey-06-settings.spec.ts --reporter=line` — full settings suite still passes (16/16 expected, after the modal-stacking migration).
- [ ] `bash scripts/lint-trusted-types.sh` — passes.
- [ ] Manual sanity: hard-reload `settings.html`, confirm no yellow banner pre-input.

**Agent instructions:**
- You MUST `git add` + `git commit` on the worktree branch before finishing.
- Read commit `7d09997` first — the dirty-state-tracker refactor was supposed to fix this. Identify what it did and why it failed in the load-vs-baseline race.
- Do NOT revert the per-loader snapshot pattern. Tighten it.
- Stay inside `dashboard/settings*` and `tests/e2e/journey-06-settings.spec.ts`. If a fix requires touching the global dirty-state module, flag and stop.

---

### Team B: Bug 1 — Session-Name Template Stale

**Blocked by:** none — can start immediately. **Will block Team C on `dashboard/app.js`.**

**Read these files first:**
- `dashboard/app.js:1166-1187` — `selectTemplate()` function (the stale-name predicate is at line 1184: `!nameInput.value.trim()`).
- `dashboard/app.js:1112-1116` — `SESSION_TEMPLATES` object (Custom template's name is empty string).
- `dashboard/index.html:369-384` — template selector markup with `data-template` attributes.

**Files touched:**
- Modified: `dashboard/app.js` — change `selectTemplate()` so switching templates always overwrites the name field with the new template's name, including clearing for Custom.
- Modified (test): `tests/e2e/journey-04-dashboard.spec.ts` — add a regression assertion that switching from Conservative ETF → Custom clears the Session Name input.

**Deliverable:** When the user clicks a template in the Create Session modal, the Session Name field updates to that template's name (or clears for Custom), regardless of prior content. Custom must clear, not retain.

**Validation:**
- [ ] `npx playwright test tests/e2e/journey-04-dashboard.spec.ts -g "template" --reporter=line` — new test passes.
- [ ] `npx playwright test tests/e2e/journey-04-dashboard.spec.ts --reporter=line` — full journey-04 suite still passes (existing 6 tests, including the banner regression added 2026-04-28).
- [ ] `bash scripts/lint-trusted-types.sh` — passes.

**Agent instructions:**
- You MUST `git add` + `git commit` on the worktree branch before finishing.
- The simplest fix is to drop the `if empty` guard at line 1184 and always assign. Verify this doesn't break other code paths reading from `nameInput.value`.
- Stay inside `dashboard/app.js` (only the `selectTemplate()` block) and `tests/e2e/journey-04-dashboard.spec.ts`. Do NOT touch `dashboard/index.html`.

---

### Team C: Bug 3 — Equity Curve Blank

**Blocked by:** Team B (shared write to `dashboard/app.js` and `tests/e2e/journey-04-dashboard.spec.ts`).

**Read these files first:**
- `dashboard/app.js:2109-2162` — `initChart()` function (LightweightCharts instance creation).
- `dashboard/app.js:1903-1970` — `renderEquityCurve()` and its `if (!equityChart) return;` early-return guard at line 1904.
- `dashboard/app.js:1439-1448` — SSE 'history' event listener calling `renderEquityCurve(...)`.
- `dashboard/app.js:1646-XXX` — `/sessions/{id}/portfolio/history` fetch path.
- `dashboard/index.html:247-254` — Equity Curve chart container markup.
- `finlet/api/routes_portfolio.py:42` — verify the history endpoint returns snapshot data after a fill (sanity check; do NOT modify unless the endpoint is broken).

**Files touched:**
- Modified: `dashboard/app.js` — fix the chart-init-vs-SSE-data race. Either: (a) defer SSE rendering until `equityChart` is initialized, OR (b) initialize the chart synchronously before subscribing to history events, OR (c) buffer the latest history event and replay it once `initChart` resolves.
- Modified (test): `tests/e2e/journey-04-dashboard.spec.ts` — add a test that creates a session, places a MARKET BUY, waits for fill, and asserts the equity curve has at least one data point (not just the watermark).
- POSSIBLY modified: `dashboard/index.html` — only if the chart container needs an attribute change.
- READ-ONLY: `finlet/api/routes_portfolio.py` — verify; flag if the API itself is the bug, don't fix it here.

**Deliverable:** After a session is created and a MARKET BUY fills, the Equity Curve renders an equity line (and benchmark, if present), not just the TradingView watermark. The fix must not introduce a flicker or extra fetch.

**Validation:**
- [ ] `npx playwright test tests/e2e/journey-04-dashboard.spec.ts -g "equity" --reporter=line` — new test passes.
- [ ] `npx playwright test tests/e2e/journey-04-dashboard.spec.ts --reporter=line` — full journey-04 suite (now 7 tests with Team B's addition) passes.
- [ ] `bash scripts/lint-trusted-types.sh` — passes.

**Agent instructions:**
- You MUST `git add` + `git commit` on the worktree branch before finishing.
- Pull main into your worktree before starting (`git fetch origin main && git merge origin/main`) so you pick up Team B's `dashboard/app.js` changes.
- Look at `dashboard/app.js:1903-1970` AND `dashboard/app.js:2109-2162` together — the bug is in the ordering of initialization and subscription.
- If the issue is server-side (no snapshot data after fill), STOP and flag — that's an api-team scope, out of bounds.

---

### Team D: Bug 4 — Trade Ticket Available Cash Stuck on `--`

**Blocked by:** none — can start immediately, parallel-safe.

**Read these files first:**
- `dashboard/trade-ticket.js:107-150` — `openTradeTicket()` including `fetchCashBalance()` and bus subscription setup.
- `dashboard/trade-ticket.js:186-224` — `handlePortfolioUpdateForTicket()` and `fetchCashBalance()` body.
- `dashboard/app.js:1675-1677` — `renderPortfolio()` showing how the Overview correctly renders cash (the working pattern).
- `dashboard/app.js:1425-1432` — `portfolio:updated` SSE event publishing through the bus.

**Files touched:**
- Modified: `dashboard/trade-ticket.js` — ensure the bus subscription is attached BEFORE `fetchCashBalance()` resolves, OR fall back to reading `currentSession.cash` if available, OR re-fetch portfolio on open instead of relying on bus.
- New: `tests/e2e/journey-05-trade-ticket.spec.ts` (or extend the existing trade-related spec) — open the Trade Ticket on a session with known cash and assert the Available Cash field is NOT `--`.

**Deliverable:** Opening the Trade Ticket on an active session with non-zero cash displays the cash value (e.g., "$98,952.81"), never `--`, on the first open and on every reopen.

**Validation:**
- [ ] `npx playwright test tests/e2e/journey-05-*.spec.ts -g "cash" --reporter=line` — new test passes.
- [ ] `npx playwright test tests/e2e/journey-05-*.spec.ts --reporter=line` — full trade-ticket suite passes.
- [ ] `bash scripts/lint-trusted-types.sh` — passes.

**Agent instructions:**
- You MUST `git add` + `git commit` on the worktree branch before finishing.
- Stay inside `dashboard/trade-ticket.js` and `tests/e2e/journey-05-*`. Do NOT touch `dashboard/app.js` (Teams B and C are working on it).
- If the only correct fix requires changing the publishing side (`dashboard/app.js`), STOP and flag — that becomes Team C's responsibility.

---

### Team E: Docs + Ledger (Required Docs Updates)

**Blocked by:** Teams A, B, C, D (needs merge SHAs for ledger entries and verdict assignment).

**Read these files first:**
- `docs/bug-hunt/20260429T052717Z1a13/triage.md` — full Required Docs Updates checklist at the bottom.
- `docs/bug-hunt/ledger.jsonl` — schema example from prior iterations.
- `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` — frontmatter to be updated with `verdict: incomplete`.
- `docs/bug-hunt/refactor-queue/modal-stacking.md` — frontmatter to be updated with `verdict: effective` (zero modal-stacking findings this iteration).
- `docs/REMAINING_TASKS.md`, `docs/LESSONS.md`, `docs/KNOWN_FAILURES.md`, `docs/ARCHITECTURE.md` — current state.
- `git log --oneline main -10` — to grab the merge SHAs for each bug team.

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — add "Bug Hunt 20260429T052717Z1a13 — Closed" subsection with the 4 closed items.
- Modified: `docs/LESSONS.md` — append at least one reusable lesson per real-broken finding (e.g., "rAF re-snapshot must wait for all async loaders, not just DOMContentLoaded", "always-overwrite vs if-empty is the right pattern when a control field's value depends on a sibling selection", "chart-init must precede event subscription", "modal-open initial fetch must read currentSession before relying on bus events").
- Modified: `docs/KNOWN_FAILURES.md` — re-baseline; if any pre-flight failures resolved this iteration, move them to Resolved.
- Possibly modified: `docs/ARCHITECTURE.md` — if any dashboard surface or bus-event contract changed; otherwise add explicit "no change" note in commit message.
- New (if applicable): `docs/decisions/<slug>.md` — only if a non-trivial reversible decision was made (e.g., "trade-ticket reads cash from currentSession instead of bus"). Skip otherwise.
- Append: `docs/bug-hunt/ledger.jsonl` — exactly 4 new lines (one per real-broken closed: Bug 1, 2, 3, 4). Schema:
  ```json
  {"iteration_ts":"20260429T052717Z1a13","finding_id":"<slug>","category":"<tag>","summary":"<short>","scope_files":["dashboard/x.js"],"team":"<A|B|C|D>","commit":"<merge-sha-on-main>"}
  ```
- Modified: `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` — add `verdict: incomplete` to frontmatter, with one-line evidence: "settings-dirty-banner recurred this iteration (same `same_root_cause_as: settings-dirty-banner-onload` link); the per-loader snapshot pattern was correct in concept but the rAF re-snapshot at settings.js:201 fires before async loaders resolve. Team A patch tightens the ordering."
- Modified: `docs/bug-hunt/refactor-queue/modal-stacking.md` — add `verdict: effective` to frontmatter, with one-line evidence: "zero modal-stacking findings in this iteration's triage; the post-refactor `fl-modal` convention held."
- Stage: `docs/bug-hunt/20260429T052717Z1a13/{triage.md, triage.json, plan.md, blind_report.json, blind_stderr.log, cleanup.log}` — every artifact tracked.

**Deliverable:** Single commit on the worktree branch that touches all required doc files. Commit message format:
```
docs: bug-hunt 20260429T052717Z1a13 — record fixes for session-name-template-stale, settings-dirty-banner, equity-curve-blank, trade-ticket-cash-dash; LESSONS +N; ARCHITECTURE [unchanged|note]; ledger +4; refactor-queue verdicts: dirty-state-tracker=incomplete, modal-stacking=effective
```

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` — grew by exactly 4 since last iteration.
- [ ] `jq -r .finding_id docs/bug-hunt/ledger.jsonl | tail -4` — emits the 4 new finding_ids.
- [ ] `grep -c "verdict:" docs/bug-hunt/refactor-queue/*.md` — 2 (both queue docs have a verdict line).
- [ ] `git status --short docs/bug-hunt/20260429T052717Z1a13/` — empty (every artifact committed).

**Agent instructions:**
- You MUST `git add` + `git commit` on the worktree branch before finishing.
- Read main's HEAD log AFTER all bug teams have merged so you have the right merge SHAs for the ledger.
- Do NOT touch any code file (dashboard/, finlet/, tests/) — your scope is `docs/` only.
- If a `same_root_cause_as` link points to a ledger finding_id that doesn't exist, leave the link null and add a note in LESSONS.md about the recurrence.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team C's `dashboard/app.js` fix conflicts with Team B's | Medium | Medium | Team C MUST `git fetch && git merge origin/main` before starting. The fixes are in different functions (selectTemplate vs renderEquityCurve), so manual conflict resolution should be straightforward. |
| Bug 2 fix breaks the dirty-state-tracker refactor's other consumers (Plugins tab) | Medium | High | Validate on the Plugins tab too — `journey-06` tests already cover this since the modal-stacking migration. Run the FULL journey-06 suite, not just the dirty-banner test. |
| Bug 3 turns out to be a server-side issue (history endpoint returns empty) | Low | Medium | Team C must verify the API response in Bash before assuming the fix is client-side. If server-side, STOP and flag — out of scope for the dashboard team. |
| Bug 4 fix subscribes the trade ticket to the bus too early and creates a memory leak | Low | Medium | Test must include opening AND closing the ticket multiple times to assert the subscription is unsubscribed on close. |
| Ledger gets out-of-sync if a bug team merges but Team E doesn't pick it up | Low | Low | Team E reads `git log` AFTER all bug merges; the validation step `wc -l ledger.jsonl` catches a miscount. |
| `auth-validate-401` deploy-lag causes blind walk to flag the same bug NEXT iteration | Medium | Low | Already noted in triage; verify after next deploy. If it persists past next deploy, the fix didn't actually deploy and we re-investigate. |

## Session Plan

### Session 1 — Bug fixes (parallel + sequential mix)

**Parallel start:** Teams A, B, D — all independent at branch creation.
**Sequential:** Team C waits for Team B to merge (shared `dashboard/app.js` and journey-04 spec).

**Merge order:**
1. Team A merges first → `pytest tests/e2e/journey-06-settings.spec.ts --list` parses + targeted "unsaved" test passes.
2. Team B merges → `npx playwright test tests/e2e/journey-04-dashboard.spec.ts --list` parses + full journey-04 (now 7 tests).
3. Team C waits for Team B's merge SHA, fetches main, merges → full journey-04 (now 8 tests with the equity curve regression).
4. Team D merges → trade-ticket spec passes.

**Session 1 checkpoint:**
- `npx playwright test tests/e2e/journey-04-dashboard.spec.ts tests/e2e/journey-05-*.spec.ts tests/e2e/journey-06-settings.spec.ts --reporter=line` — all GREEN.
- `bash scripts/lint-trusted-types.sh` — clean.
- `.venv/bin/ruff check finlet/api dashboard tests` — clean (dashboard isn't ruff-scoped, but check for accidental finlet/ touches).

### Session 2 — Docs + ledger

**Sequential:** Team E only.

**Merge order:** Team E merges last after all bug merges have landed and SHAs are stable.

**Session 2 checkpoint:**
- `wc -l docs/bug-hunt/ledger.jsonl` — exactly 4 more than before.
- `git log --oneline -8` — shows 5 fix commits + 4 merge commits + 1 docs commit, in expected order.
- Both refactor-queue docs have a `verdict:` field set.

---

## Out of scope (this iteration)

- `auth-validate-401` — deploy-lag, fix is on main; will resolve at next deploy. If it persists, re-add to the next iteration.
- All ANNOYING and NICE_TO_HAVE findings (5 + 4 = 9 items in the Logged section) — not actioned per the bug-hunt v1 contract (real-broken only).
- The MCP `finlet not in PATH` finding — classified WAI; the blind agent's clean-room subprocess doesn't have the venv on PATH, this is harness env, not a finlet.dev bug.
