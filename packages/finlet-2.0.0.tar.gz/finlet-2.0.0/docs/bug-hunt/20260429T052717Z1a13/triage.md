## Broken (will be fixed this iteration)
- Session name field retains previous template name when switching to Custom template [evidence: "After selecting Conservative ETF (which pre-fills name as 'Conservative ETF'), clicking Custom leaves 'Conservative ETF' in the Session Name field. The name does not clear or update. User must manually erase it."] [scope hint: dashboard/index.html, dashboard/session-create.js, dashboard/app.js]
- 'You have unsaved changes' footer bar appears on Settings page before the user changes anything [evidence: "On fresh load of settings.html with the Profile section active, the yellow 'You have unsaved changes / Discard / Save Changes' bar renders immediately at the bottom. No edits were made. Likely the profile form initializes to values that differ from the stored state, triggering a false dirty flag."] [scope hint: dashboard/settings.html, dashboard/settings.js]
- Equity Curve chart renders blank (only TradingView watermark) even after a trade is placed and the page is fully loaded [evidence: "After creating a session and placing a MARKET BUY for 5 AAPL (order filled at $209.44, cash correctly dropped to $98,952.81), the Equity Curve section shows only the TradingView logo — no equity line, no buy-and-hold benchmark, no data at all. Persists across page reload."] [scope hint: dashboard/index.html, dashboard/app.js, dashboard/equity-curve.js]
- Trade Ticket 'Available Cash' always shows '--', never populates [evidence: "The Trade Ticket panel (opened via the '+ Trade' button) shows 'Available Cash: --' even when a session with $98,952.81 cash is active. The metric is displayed correctly in the Overview section, but the Trade Ticket never fetches or renders it. Observed in accessibility snapshot: `generic [ref=e227]: \"--\"` for the Available Cash field."] [scope hint: dashboard/trade-ticket.js, dashboard/index.html, dashboard/api-utils.js]

## Already fixed on main (deploy-lag — exclude from this iteration's /plan-features)

- REST API returns 401 on /v1/auth/session/validate on every page load — fixed today on main at commits `17fccf1`/`275c7c0` (new `optional_user` dep makes anon probes return 200 with `valid=False`). finlet.dev's most recent deploy is `a1027c4` (2026-04-28T23:21Z), which predates the fix. Verified deploy-lag via `curl https://finlet.dev/v1/auth/session/validate` → still returns 401. Will resolve when the next deploy fires (covering main HEAD `46a7e0d`).

## Logged (not actioned)
- Finlet benchmark MCP server fails to start because 'finlet' binary is not in PATH [classification: working-as-designed]
- No 'Fundamentals' session template — user has no quick-start for fundamentals-based strategy [classification: annoying]
- Plugin health shows 'Run ingestion first' for 3 plugins but provides no UI button or workflow to run ingestion [classification: annoying]
- Three fundamentals/news plugins (finnhub, fred, edgar) show 'plugin not initialized' with zero guidance on how to fix it [classification: annoying]
- REST API uses 'ticker' but UI calls it 'Symbol' — silent field mismatch trips up API users [classification: annoying]
- Onboarding wizard shows 'Open Session Creator' in two spots simultaneously with different visual weights, causing confusion [classification: annoying]
- No 'Fundamentals Strategy' session template with value/dividend stocks pre-loaded [classification: nice-to-have]
- No 'Run Ingestion' button in the Plugin Health section or Settings > Plugins [classification: nice-to-have]
- No in-app REST API reference or link to API docs from dashboard [classification: nice-to-have]
- Equity curve doesn't show a single data point at T=0 when clock is frozen [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260429T052717Z1a13 — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. `docs/bug-hunt/20260429T052717Z1a13/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log).
   No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260429T052717Z1a13","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.

Team D's commit message must reference iteration 20260429T052717Z1a13 and name which docs were
touched (e.g., "docs: bug-hunt 20260429T052717Z1a13 — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
