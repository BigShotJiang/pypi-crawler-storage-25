## Broken (will be fixed this iteration)
- TOTAL P&L tile renders red `▼ -0.00%` with down-arrow when P&L is exactly $0.00 (Return + Max Drawdown cards repeat the same artifact) — UI state contradicts design intent (zero is not a loss). [evidence: "After SPY BUY filled at sim-start price with no price movement, the TOTAL P&L tile shows '+$0.00' on the primary line and '▼ -0.00%' with a red down-arrow on the subtitle. Return and Max Drawdown cards show the same red '▼ -0.00%'."] [scope hint: dashboard/app.js, dashboard/index.html, dashboard/styles.css]
- Plugin Health latency badges render the malformed unit string `8es` on 4 of 8 plugins (price, fundamentals_s3, news_s3, sentiment) while econ correctly shows `349ms` — documented affordance produces nonsensical text. [evidence: "In the Plugin Health dashboard panel, price, fundamentals_s3, news_s3, and sentiment all render their response time as '8es'. The econ plugin correctly shows '349ms'. Standard units would be '8s' or '8000ms'."] [scope hint: dashboard/app.js (Plugin Health renderer), dashboard/index.html]

## Logged (not actioned)
- Finlet benchmark MCP tool not present in tool registry — agent fell back to UI to place trade. [classification: needs-investigation]
- Session creation takes ~26 seconds with no progress feedback beyond the button label. [classification: annoying]
- App-wide `<title>` uses unexplained acronym `ITE`; contradicts marketing copy. [classification: annoying]
- Three plugins (finnhub, fred, edgar) toggled ON show UNHEALTHY/`not initialized` with no actionable guidance. [classification: annoying]
- API Key input shown for S3-backed plugins (price, fundamentals_s3, econ) that need no key. [classification: annoying]
- Win Rate shows `N/A` with no tooltip explaining it requires a closed trade. [classification: annoying]
- Onboarding wizard and session creator are two separate stacked dialogs — flow is choppy. [classification: annoying]
- Reasoning column shows `--` for manual trades with no clarifying label/tooltip. [classification: annoying]
- No `strategy` concept in the UI — `set up a fundamentals strategy` maps to no screen. [classification: nice-to-have]
- No `Get API key` links for finnhub, fred, edgar inside the plugin config panel. [classification: nice-to-have]
- No fundamentals data browser — can't inspect which tickers/periods are in the 21 cached files. [classification: nice-to-have]
- Manual trades cannot include a reasoning annotation. [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260505T142400Z3330 — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. `docs/bug-hunt/20260505T142400Z3330/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log,
   deploy_status.txt, retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260505T142400Z3330","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline (see
   Phase 5.5c). Team D MUST stage the file. If a refactor verdict pruned entries
   this iteration, Team D MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`
   (the audit log of resolved signals).

Team D's commit message must reference iteration 20260505T142400Z3330 and name which docs were
touched (e.g., "docs: bug-hunt 20260505T142400Z3330 — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
