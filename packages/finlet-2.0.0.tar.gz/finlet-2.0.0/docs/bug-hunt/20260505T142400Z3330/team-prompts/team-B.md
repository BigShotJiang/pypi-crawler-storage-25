You are Team B: Plugin Health latency `8es` investigation + fix.

**Blocked by:** Team A merge (`dashboard/app.js` overlap). New base SHA: `30a1d9cefbde5f4a39216b7763374bd3f9801d33` — your worktree starts at this SHA.

**Read these files first:**
- `dashboard/app.js:2279-2319` — `renderPlugins(plugins)` function. Latency badge built at line 2312.
- `dashboard/index.html:345-350` — Plugin Health widget container.
- `finlet/api/routes_plugins.py` — find the `GET /v1/plugins/health` route handler. Look for `latency_ms` field construction.
- `finlet/api/services/plugin_service.py` (if it exists; grep first).
- `finlet/plugins/price.py`, `fundamentals_s3.py`, `news_s3.py`, `sentiment.py` — the 4 affected plugins.
- Compare against `econ.py` (the plugin that DOES render correctly).
- `docs/KNOWN_FAILURES.md` — do NOT report these as issues.

**Recon evidence at HEAD `449a6417`** (full quote in `docs/bug-hunt/20260505T142400Z3330/plan.md`):

```javascript dashboard/app.js:2303-2317
2303         return `<div class="plugin-card" role="listitem">
...
2312                 ${p.latency_ms != null ? `<div class="plugin-latency">${esc(String(Number(p.latency_ms).toFixed(0)))}<span class="sr-only"> milliseconds</span>ms</div>` : ''}
```

The visible-text rendering at line 2312 is `${number}<span sr-only>...</span>ms`. For `p.latency_ms = 8000`, this renders visibly as `8000ms` (the `sr-only` span is hidden). For `p.latency_ms = "8es"`, `Number("8es") = NaN`, `NaN.toFixed(0) = "NaN"`, visible becomes `NaNms`. Neither path produces the literal `8es` the blind agent saw — root cause is unverified.

**INVESTIGATION SCOPE (FIRST step of Team B's work):**

1. Source secrets and run a live curl against the deployed API:
   ```
   set -a; . "$HOME/.bug-hunt-loop/secrets.env"; set +a
   : "${FINLET_BASE_URL:=https://finlet.dev}"; export FINLET_BASE_URL
   curl -fsS -H "Authorization: Bearer $FINLET_TEST_USER_API_KEY" \
     "$FINLET_BASE_URL/v1/plugins/health" | jq '.plugins[] | {name, latency_ms, type: (.latency_ms | type), message}'
   ```
   Identify the actual shape of `latency_ms` for `price`, `fundamentals_s3`, `news_s3`, `sentiment` vs `econ`.
   NEVER echo `FINLET_TEST_USER_API_KEY` — refer to it as [REDACTED] in any output.

2. **Decision tree based on what the API returns:**
   - **(A) API returns a number for all plugins, but FE renders `8es`.** Then there's a second render path or CSS truncation. Check CSS `.plugin-latency` width rules; search for any other site that writes to `<div class="plugin-latency">`.
   - **(B) API returns a string like `"8es"` for the 4 affected plugins.** Then the BE is malformed. Inspect `finlet/api/routes_plugins.py` and the underlying service for a serializer that produces `"8es"` from `8` seconds via a botched substring/regex.
   - **(C) API returns a number for `econ` but `null` for the 4 affected.** Then the FE skips rendering and the visible "8es" comes from `p.message` text overlapping the latency div. Visual separation in CSS may be needed.

3. Based on (A)/(B)/(C), produce the actual fix.

**Files touched (depends on investigation):**
- Modified: `dashboard/app.js` (line 2312 area) — at minimum, replace inline `Number(p.latency_ms).toFixed(0)` with a `formatLatency(latency_ms)` helper that returns `null` for non-finite numbers and short-circuits the `<div class="plugin-latency">` if helper returns `null`. Defense-in-depth against future BE drift.
- Modified or New: `finlet/api/routes_plugins.py` AND/OR `finlet/api/services/plugin_service.py` — only if case (B). Ensure `latency_ms` is always emitted as a finite numeric, never a string.
- Modified or New: `tests/api/test_plugins_health.py` (or sibling) — assert that `GET /v1/plugins/health` returns `latency_ms` as numeric (or null), never string, for every plugin in the registry.
- Modified or New: `tests/e2e/journey-*.spec.ts` — add a Playwright assertion that every visible `.plugin-latency` element's textContent matches `/^\d+(\.\d+)?ms$/` (canonical form).

**Validation (run before commit):**
- `bash scripts/lint-trusted-types.sh` — clean.
- `bash scripts/lint-event-bus.sh` — clean.
- `uv run pytest tests/api/ -k plugins_health -x -q` — green if BE diff (else N/A).

**CRITICAL RULES:**
- Read `docs/KNOWN_FAILURES.md` first — do NOT report those as issues.
- Read the "Read these files first" list BEFORE writing any code.
- You MUST `git add` and `git commit` all your changes before finishing — uncommitted changes are lost when the worktree is cleaned up.
- Your commit message MUST start with `[Team B]:` and reference iteration `20260505T142400Z3330`.
- Run the curl investigation FIRST. Pick the smallest fix that closes the case — do not refactor unrelated plugin-health code.
- If the fix is BE-only, you do NOT need to modify `dashboard/app.js`. (But add the FE robustness coercion regardless.)
- If the fix needs both BE and FE, the BE fix is primary; the FE coercion is secondary.
- Cleanup: if your investigation creates server-side test sessions, delete them. The test user has a 1-session-concurrent quota.
- Run lint validations before commit.

**Worktree rules:**
- Your work happens in your assigned worktree. Do NOT cd out of it. Do NOT commit to /Users/justnau/finlet directly. The orchestrator merges your branch to main after you complete.
- Allowed scope: `dashboard/`, `finlet/api/`, `tests/api/`, `tests/e2e/`. Do not touch other directories.

When done, report: `DONE` + worktree branch name + commit hash + what case (A)/(B)/(C) held + lint validation results.
OR: `BLOCKED` + what went wrong.
