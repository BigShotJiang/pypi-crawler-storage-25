You are Team E: Ledger maintenance.

The orchestrator spawned you in a worktree off main. Immediately after spawn the orchestrator runs `git reset --hard c1edc8c0e10efa2b81d4dc8a9fc819a031c7bd5a` (post-Team-B merge) in your worktree. Your first git read should observe HEAD at exactly that SHA.

**Blocked by:** Teams A and B (merged). Team A commit: `b5dc82f0936f465180b0d8650ed640c0dede5747`. Team B commit: `f7d932a60cdf7802349d8ba170ac79bf31c5d5b4`.

**Read these files first:**
- `docs/bug-hunt/ledger.jsonl` — last 5 lines for schema reference. Note the flat one-line-per-finding JSON shape.
- `docs/bug-hunt/pending_recurrences.jsonl` — should be empty; verify.
- `docs/bug-hunt/20260505T142400Z3330/triage.json` — to confirm the 2 real-broken findings and their categories.
- `docs/bug-hunt/refactor-queue/*.md` — only check that no doc has `status: shipped` AND lacks a `verdict:` field. None expected this iteration.
- `docs/KNOWN_FAILURES.md` — do NOT report these as issues.

**Files touched:**
- Modified: `docs/bug-hunt/ledger.jsonl` — append exactly 2 JSON lines, one per closed real-broken finding.

**Exact ledger lines to append (two lines, one per finding):**

Line 1 (Team A — P&L sign-of-zero):
```json
{"iteration_ts":"20260505T142400Z3330","finding_id":"pnl-zero-loss-class","category":"dashboard-state-sync","summary":"P&L / Return / Max Drawdown / Sharpe tiles classified on raw value not rounded display value, causing red ▼ -0.00% at functionally-zero P&L; Max Drawdown also hardcoded ▼ + pnl-negative regardless of value. Fixed by rounding-then-classifying in pnlArrow / pnlClass / formatPct, and re-routing max-drawdown through the helpers.","scope_files":["dashboard/app.js","tests/e2e/journey-05-trade.spec.ts"],"team":"A","commit":"b5dc82f0936f465180b0d8650ed640c0dede5747"}
```

Line 2 (Team B — Plugin Health latency):
```json
{"iteration_ts":"20260505T142400Z3330","finding_id":"plugin-health-latency-sub-1ms-collapse","category":"dashboard-state-sync","summary":"Plugin Health latency badges rendered '0ms' for sub-1ms latencies because Number(p.latency_ms).toFixed(0) collapses 0.131 to '0'. (Blind agent's '8es' report was a visual misread of '0ms' in small mono font.) Fixed by introducing formatLatency() helper with branches: null/undefined→null, non-finite→null (defense-in-depth), exact 0→'0ms', 0<n<1→'<1ms', n≥1→'${Math.round(n)}ms'. New e2e regression test stubs all four branches plus the literal '8es' string for defense-in-depth.","scope_files":["dashboard/app.js","tests/e2e/journey-04-dashboard.spec.ts"],"team":"B","commit":"f7d932a60cdf7802349d8ba170ac79bf31c5d5b4"}
```

These are the EXACT line contents — copy-paste verbatim (including the JSON-escaped quotes inside summary). Append both as the last two lines of `docs/bug-hunt/ledger.jsonl`.

**Validation (run before commit):**
- Capture `wc -l docs/bug-hunt/ledger.jsonl` BEFORE edit, then AFTER edit; difference must be exactly 2.
- `tail -2 docs/bug-hunt/ledger.jsonl | jq -c '.iteration_ts'` — both lines print `"20260505T142400Z3330"`.
- `tail -2 docs/bug-hunt/ledger.jsonl | jq -e 'has("commit") and (.commit | length == 40)'` — both lines have a 40-char commit SHA.
- `tail -2 docs/bug-hunt/ledger.jsonl | jq -c '.commit' | tr -d '"' | xargs -I {} git cat-file -e {}^{commit} && echo "all SHAs reachable"` — confirms both commits exist.

**CRITICAL RULES:**
- Read `docs/KNOWN_FAILURES.md` first — do NOT report those as issues.
- You MUST `git add` and `git commit` all your changes before finishing — uncommitted changes are lost.
- Commit message MUST start with `[Team E]:` and reference iteration `20260505T142400Z3330`. Suggested: `[Team E]: ledger +2 for bug-hunt 20260505T142400Z3330 (pnl-zero-loss-class, plugin-health-latency-sub-1ms-collapse)`.
- Run all 4 validations from the spec before commit.
- Do NOT modify `pending_recurrences.jsonl` (orchestrator handles Phase 5.5 inline appends).
- Do NOT touch any refactor-queue doc (none have status:shipped without verdict this iteration).

**Worktree rules:**
- Allowed scope: `docs/bug-hunt/ledger.jsonl`. Do NOT touch other directories.
- Do not commit to /Users/justnau/finlet directly; commit on your worktree branch and let orchestrator merge.

When done, report: `DONE` + worktree branch name + commit hash + before/after `wc -l ledger.jsonl` numbers + validation results.
OR: `BLOCKED` + what went wrong.
