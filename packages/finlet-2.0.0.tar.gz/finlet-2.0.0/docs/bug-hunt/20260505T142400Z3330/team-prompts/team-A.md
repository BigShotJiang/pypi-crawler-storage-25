You are Team A: P&L + Max Drawdown sign-of-zero.

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/app.js:1939-1943` — `pnlArrow(value)` helper.
- `dashboard/app.js:2499-2503` — `pnlClass(value)` helper.
- `dashboard/app.js:2464-2467` — `formatPct(value)` helper (uses `value >= 0` for sign — negative-zero classifies as positive).
- `dashboard/app.js:1945-1990` — `renderPortfolio(portfolio)` body, especially the Total P&L / Return / Max Drawdown / Sharpe blocks.
- `dashboard/styles.css:993-1020` — `.pnl-positive` / `.pnl-negative` classes (red/green coloring).
- `dashboard/index.html:184-204` — KPI tile HTML scaffold.
- `tests/e2e/journey-*.spec.ts` — grep for any existing assertions on `▼`, `▲`, `pnl-negative`, or KPI tile percent format. Add a regression test in the most relevant journey (likely `journey-05-trade.spec.ts` since the bug surfaces post-fill).
- `docs/KNOWN_FAILURES.md` — do NOT report these as issues.

**Recon evidence (verified by recon agent against HEAD `449a6417`):**

```javascript dashboard/app.js:1939-1943
1939  function pnlArrow(value) {
1940      if (value > 0) return '▲ '; // up triangle
1941      if (value < 0) return '▼ '; // down triangle
1942      return '';
1943  }
```

```javascript dashboard/app.js:2499-2503
2499  function pnlClass(value) {
2500      if (value > 0) return 'pnl-positive';
2501      if (value < 0) return 'pnl-negative';
2502      return '';
2503  }
```

```javascript dashboard/app.js:2464-2467
2464  function formatPct(value) {
2465      if (value == null || isNaN(value)) return '--';
2466      return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
2467  }
```

```javascript dashboard/app.js:1980-1984
1980      // Max drawdown
1981      const ddEl = document.getElementById('max-drawdown');
1982      const dd = portfolio.max_drawdown;
1983      ddEl.textContent = dd != null ? `▼ ${(dd * 100).toFixed(1)}%` : '--';
1984      ddEl.className = 'stat-value pnl-negative';
```

```javascript dashboard/app.js:1974-1978
1974      // Sharpe ratio
1975      const sharpeEl = document.getElementById('sharpe-ratio');
1976      const sharpe = portfolio.sharpe_ratio;
1977      sharpeEl.textContent = sharpe != null ? `${pnlArrow(sharpe)}${sharpe >= 0 ? '+' : ''}${sharpe.toFixed(2)}` : '--';
1978      sharpeEl.className = 'stat-value ' + (sharpe != null ? pnlClass(sharpe) : '');
```

**Root cause:**
- DEFECT 1 (P&L tile, Return tile): `totalReturnPct` can be a tiny negative float like `-0.0001` due to fees/slippage on a fresh BUY at sim-start price. `pnlArrow(-0.0001)` returns `▼` (line 1941: value < 0). `formatPct(-0.0001)` returns `-0.00%` (negative-zero rendering). `pnlClass(-0.0001)` returns `pnl-negative` red. The DISPLAYED rounds to 0.00% but the CLASSIFICATION is on raw value.
- DEFECT 2 (Max Drawdown tile): line 1983-1984 hardcode `▼` and `pnl-negative` regardless of value. When `dd === 0`, still renders `▼ 0.0%` red.

**Fix:**
- Modify `pnlArrow(value)`, `pnlClass(value)`, and `formatPct(value)` to classify based on the rounded display value, not the raw value. Cleanest approach: round to 2 decimals first (e.g., `Math.round(value * 100) / 100`), then check `> 0` / `< 0` / `=== 0`. Apply same shape to all three helpers.
- Modify max-drawdown renderer at 1981-1984: replace hardcoded `▼` and `pnl-negative` with `pnlArrow(dd * 100)` + `pnlClass(dd * 100)`. (`dd` is a fraction; multiply by 100 for the rounded-display sign check.)
- Modify sharpe renderer at 1977-1978: same fix — use `pnlClass(sharpe)` and route the sign-prefix logic through the rounded value (Sharpe rounds to 2 decimals via `.toFixed(2)`).

**Files touched:**
- Modified: `dashboard/app.js`
- Modified or skip: `dashboard/styles.css` — only if a new neutral class needed; usually NOT needed (empty class string already produces neutral state).
- New or Modified: `tests/e2e/journey-05-trade.spec.ts` — add ONE Playwright assertion: after a fresh BUY fills at sim-start price, the TOTAL P&L tile, RETURN tile, and MAX DRAWDOWN tile do NOT contain `▼` or `▲` glyph in textContent, AND className does NOT include `pnl-negative` or `pnl-positive`. Use existing test session pattern; clean up the session at end.

**Deliverable:** When P&L / Return / Max Drawdown / Sharpe display value rounds to `0.00%` (or `0.00`), the corresponding tile shows neutral state (no arrow, no red/green class). Underlying tiny non-zero floats no longer leak into UI classification.

**Validation (run before commit):**
- `npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-05-trade.spec.ts` — green, including the new neutral-zero assertion. (Note: requires running server. If server not running, document in your report and let the orchestrator handle the gate.)
- `bash scripts/lint-trusted-types.sh` — clean.
- `bash scripts/lint-event-bus.sh` — clean.

**Agent instructions:**
- Working dir is your worktree; the orchestrator has reset it to spawn_base_sha (`449a6417e4cf83f8fb32ef956d757a33fc7c8d3d`).
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message MUST start with "[Team A]:" and reference the bug-hunt iteration `20260505T142400Z3330`.
- Pick the simplest fix surface — DO NOT refactor unrelated KPI tile code. Keep the change small: a 4-6 line delta in the three helpers + max-drawdown re-route + ONE new e2e assertion.
- The fix MUST preserve the existing behavior for legitimately negative values (e.g., -2.5% should still render `▼ -2.50%` red). Test BOTH neutral-zero and negative-value paths.
- The Max-Drawdown semantics: by definition drawdown is non-positive (zero or negative). When zero, render neutral. When negative, render `▼ X.X%` red as before. Do NOT introduce a positive branch.

When done, report: DONE + commit hash + validation results
OR: BLOCKED + what went wrong
