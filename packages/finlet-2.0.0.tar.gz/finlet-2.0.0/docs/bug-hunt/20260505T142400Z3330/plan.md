# Bug-Hunt Iteration 20260505T142400Z3330 — Execution Plan

> Generated from `docs/bug-hunt/20260505T142400Z3330/triage.md`. Last updated: 2026-05-05.
> Baseline SHA: `449a6417e4cf83f8fb32ef956d757a33fc7c8d3d` (origin/main).

## Constraints

- Two real-broken findings after triage. Both are dashboard render bugs.
- **Team A and Team B both touch `dashboard/app.js` at disjoint line ranges** — sequence merges: A first, then B (B branches from main after A merges).
- Per-iteration ledger maintenance (Team E) and docs (Team D) are mandatory (skill-required).
- Cleanup MUST run after every retest that creates server-side state — the test user has 1-session-concurrent quota.
- All team commits MUST be on `main` before Phase 5.5 deploy poll begins.
- Per CLAUDE.md and `.claude/rules/file-ownership.md`:
  - `dashboard/` → dashboard team
  - `finlet/api/` → api team (Team B may need to read this if `8es` is server-side)
  - `docs/` → docs team
  - `tests/e2e/` → dashboard team (covers `journey-*.spec.ts`)

## File Conflict Table

| File | Team(s) | Notes |
|------|---------|-------|
| `dashboard/app.js` | A, B | A: `pnlArrow` `pnlClass` `formatPct` `renderPortfolio`. B: `renderPlugins` (line 2279-2317). Disjoint line ranges. **Sequential merge: A → B.** |
| `dashboard/styles.css` | A | only if `.pnl-neutral` class needed; else skip |
| `tests/e2e/journey-*.spec.ts` | A, B | A: KPI tile assertions. B: Plugin Health latency assertions. Different files (likely `journey-04-portfolio.spec.ts` for A, `journey-06-settings.spec.ts` for B if reused, or net-new if needed). |
| `finlet/api/routes_plugins.py` | B (conditional) | only if Team B's investigation shows BE returns malformed `latency_ms` |
| `finlet/api/services/plugin_service.py` (or sibling) | B (conditional) | only if BE-side fix |
| `tests/api/test_plugins_health.py` (or sibling) | B (conditional) | only if BE-side fix |
| `docs/bug-hunt/ledger.jsonl` | E | append per-finding row |
| `docs/bug-hunt/pending_recurrences.jsonl` | E | prune resolved entries (if any verdict: effective set) |
| `docs/bug-hunt/pending_recurrences.resolved.jsonl` | E | audit log if any pruning happens |
| `docs/REMAINING_TASKS.md` | D | close items |
| `docs/LESSONS.md` | D | append lessons |
| `docs/ARCHITECTURE.md` | D | update if applicable |
| `docs/KNOWN_FAILURES.md` | D | refresh |
| `docs/decisions/*.md` | D | only if non-trivial decision made |
| `docs/bug-hunt/20260505T142400Z3330/*` | D | stage all artifacts |

**Sequential merge order: A → B → E → D.** A and B touch `dashboard/app.js` so cannot merge in parallel; E reads merge SHAs from A/B; D stages E's output.

## Dependency Graph

- **Team A** (P&L + Max Drawdown sign-of-zero) — independent, can start immediately.
- **Team B** (Plugin Health `8es`) — `dashboard/app.js` overlap with A; sequence merge after A. Team B may begin work in its own worktree in parallel; B re-bases (or merges main) before its own merge gate.
- **Team E** (ledger + pending_recurrences) — blocked by A and B (needs merge SHAs).
- **Team D** (docs) — blocked by E (must stage E's files in same commit).

## Critical Path

```
Team A (merge) → Team B (rebase + merge) → Team E → Team D
```

Four-step minimum chain. Team B may work in a worktree during Team A's merge gate; the gate is at merge time, not work time.

---

## Teams

### Team A: P&L + Max Drawdown sign-of-zero

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/app.js:1939-1943` — `pnlArrow(value)` helper.
- `dashboard/app.js:2499-2503` — `pnlClass(value)` helper.
- `dashboard/app.js:2464-2467` — `formatPct(value)` helper (uses `value >= 0` for sign — negative-zero classifies as positive).
- `dashboard/app.js:1945-1990` — `renderPortfolio(portfolio)` body, especially the Total P&L / Return / Max Drawdown / Sharpe blocks.
- `dashboard/styles.css:993-1020` — `.pnl-positive` / `.pnl-negative` classes (red/green coloring).
- `dashboard/index.html:184-204` — KPI tile HTML scaffold.
- `tests/e2e/journey-*.spec.ts` — grep for any existing assertions on `▼`, `▲`, `pnl-negative`, or KPI tile percent format. Add a regression test in the most relevant journey (likely `journey-05-trade.spec.ts` since the bug surfaces post-fill).

**Recon evidence (verified by recon agent against HEAD `449a6417`):**

```javascript dashboard/app.js:1939-1943
1939  function pnlArrow(value) {
1940      if (value > 0) return '▲ '; // up triangle
1941      if (value < 0) return '▼ '; // down triangle
1942      return '';
1943  }
```

```javascript dashboard/app.js:2499-2503
2499  function pnlClass(value) {
2500      if (value > 0) return 'pnl-positive';
2501      if (value < 0) return 'pnl-negative';
2502      return '';
2503  }
```

```javascript dashboard/app.js:2464-2467
2464  function formatPct(value) {
2465      if (value == null || isNaN(value)) return '--';
2466      return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
2467  }
```

```javascript dashboard/app.js:1980-1984
1980      // Max drawdown
1981      const ddEl = document.getElementById('max-drawdown');
1982      const dd = portfolio.max_drawdown;
1983      ddEl.textContent = dd != null ? `▼ ${(dd * 100).toFixed(1)}%` : '--';
1984      ddEl.className = 'stat-value pnl-negative';
```

```javascript dashboard/app.js:1974-1978
1974      // Sharpe ratio
1975      const sharpeEl = document.getElementById('sharpe-ratio');
1976      const sharpe = portfolio.sharpe_ratio;
1977      sharpeEl.textContent = sharpe != null ? `${pnlArrow(sharpe)}${sharpe >= 0 ? '+' : ''}${sharpe.toFixed(2)}` : '--';
1978      sharpeEl.className = 'stat-value ' + (sharpe != null ? pnlClass(sharpe) : '');
```

**Root cause analysis (verified by recon agent against HEAD `449a6417`):**

The blind agent observed `▼ -0.00%` (red) on TOTAL P&L, RETURN, and MAX DRAWDOWN tiles after a single SPY BUY filled at the sim-start price (zero price movement). The screen-capture confirms all three tiles show a down-arrow + red coloring at functionally-zero P&L.

There are **two distinct defects**:

1. **Floating-point underflow + sign-on-raw-value (P&L tile, Return tile).** `totalReturnPct` is computed at line 1952-1954 as `((totalValue - initialCapital) / initialCapital) * 100`. With one filled BUY and zero price movement, `totalValue ≈ initialCapital - fees - slippage`, producing a tiny negative value like `-0.0001%`. `pnlArrow(-0.0001)` returns `▼ ` (line 1941: `value < 0`). `formatPct(-0.0001)` returns `-0.00%` (line 2466: `-0.0001 >= 0` is `false`, so no `+` prefix; `(-0.0001).toFixed(2)` = `'-0.00'`). `pnlClass(-0.0001)` returns `pnl-negative` (line 2501: `-0.0001 < 0`). The DISPLAYED value rounds to 0.00% but the CLASSIFICATION uses raw value. Fix: classify on the displayed (rounded-to-2dp) value, not the raw value.

2. **Hardcoded loss class on Max Drawdown (line 1983-1984).** Max Drawdown's renderer ALWAYS prepends `▼` and ALWAYS applies `pnl-negative` class regardless of value. When `max_drawdown === 0`, the tile still displays `▼ 0.0%` red. Fix: branch on value sign — at zero, render no arrow + no `pnl-negative` class. (Drawdown values cannot be positive by definition; the symbol asymmetry between "drawdown is some loss number" vs. "drawdown is exactly zero" is what the user expects.)

**Files touched:**
- Modified: `dashboard/app.js`
  - `pnlArrow(value)` and `pnlClass(value)` and `formatPct(value)` should classify based on a rounded value (e.g., `Math.round(value * 100) / 100` for 2-decimal display, or accept a precision argument). Pick the simplest invariant: introduce a small helper `_roundForDisplay(value, decimals = 2)` that returns `Math.round(value * 10**decimals) / 10**decimals`, then route the existing trio through it. Or, equivalently, change `>` and `<` checks to compare against a small epsilon (e.g., `value > 0.005` for 2dp). The first approach is more honest because the boundary aligns with what the user sees.
  - Max-drawdown renderer at 1981-1984: replace the hardcoded `▼` and `pnl-negative` with `pnlArrow(dd * 100)` + `pnlClass(dd * 100)`. (NOTE: `dd` is a fraction like `-0.05` for -5%; multiply by 100 for the sign-of-rounded-display check.)
  - Sharpe renderer at 1977-1978: same fix — use `pnlClass(sharpe)` and adjust the sign-prefix logic (`sharpe >= 0` to `_roundForDisplay(sharpe, 2) >= 0` or equivalent).

- Modified or New: `dashboard/styles.css` — only if a new `.pnl-neutral` class is needed. Most likely NOT needed: returning `''` from `pnlArrow`/`pnlClass` already produces the neutral state (no class, no arrow). Verify.

- New or Modified: `tests/e2e/journey-05-trade.spec.ts` (or sibling) — add a Playwright assertion: after a fresh BUY fills at sim-start price, the TOTAL P&L tile, RETURN tile, and MAX DRAWDOWN tile all do NOT contain the `▼` or `▲` glyph in their textContent, AND their className does NOT include `pnl-negative` or `pnl-positive`. Use the existing test session pattern; clean up the session at end.

**Deliverable:** When P&L / Return / Max Drawdown / Sharpe display value rounds to `0.00%` (or `0.00`), the corresponding tile shows neutral state (no arrow, no red/green class). Underlying tiny non-zero floats no longer leak into UI classification.

**Validation:**
- [ ] `npx playwright test tests/e2e/journey-05-trade.spec.ts -x` — green, including the new neutral-zero assertion.
- [ ] `bash scripts/lint-trusted-types.sh` — clean (no new bare `.innerHTML =` writes).
- [ ] `bash scripts/lint-event-bus.sh` — clean (no new direct `addEventListener('finlet:...')` calls).
- [ ] Manual: load `https://finlet.dev/index.html` (after deploy), submit a SPY MARKET BUY for 1 share, wait for FILLED, confirm the four KPI tiles render without red `▼ -0.00%`. (Phase 5.5 retest envelope.)

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Push your branch.
- Pick the simplest fix surface — DO NOT refactor unrelated KPI tile code.
- The fix MUST preserve the existing behavior for legitimately negative values (e.g., -2.5% should still render `▼ -2.50%` red). Test BOTH neutral-zero and negative-value paths.
- The Max-Drawdown semantics: by definition drawdown is non-positive (zero or negative). When zero, render neutral. When negative, render `▼ X.X%` red as before. Do NOT introduce a positive branch — there is no such thing as positive drawdown.
- Keep the change small: 4-6 line delta in `pnlArrow`/`pnlClass`/`formatPct`, plus the max-drawdown re-route. Add ONE new e2e assertion (not a whole new spec file).

---

### Team B: Plugin Health latency `8es` investigation + fix

**Blocked by:** Team A merge (`dashboard/app.js` overlap). Team B may BEGIN work in its own worktree in parallel; merge gate sequences after A.

**Read these files first:**
- `dashboard/app.js:2279-2319` — `renderPlugins(plugins)` function. Latency badge is built at line 2312.
- `dashboard/index.html:345-350` — Plugin Health widget container.
- `finlet/api/routes_plugins.py` — find the `GET /v1/plugins/health` route handler. Look for `latency_ms` field construction.
- `finlet/api/services/plugin_service.py` (if it exists; grep for `plugin_health` / `latency_ms` if not).
- The 4 affected plugin files in `finlet/plugins/` — `price.py`, `fundamentals_s3.py`, `news_s3.py`, `sentiment.py` — to see if any of them returns a non-numeric latency that the API surface forwards.
- Compare against `econ.py` (the plugin that DOES render correctly) for the contract difference.

**Recon evidence (verified by recon agent against HEAD `449a6417`):**

```javascript dashboard/app.js:2303-2317
2303         return `<div class="plugin-card" role="listitem">
2304             <div class="plugin-status-dot plugin-status-dot--${dotClass}" aria-hidden="true"></div>
2305             <span class="sr-only">Status: ${statusLabel}</span>
2306             <div class="plugin-info">
2307                 <div class="plugin-name">${esc(p.name)}</div>
2308                 <div class="plugin-type">${esc(p.plugin_type || p.type || '')}</div>
2309                 ${p.message ? `<div class="plugin-message">${esc(p.message)}</div>` : ''}
2310             </div>
2311             <div class="plugin-meta">
2312                 ${p.latency_ms != null ? `<div class="plugin-latency">${esc(String(Number(p.latency_ms).toFixed(0)))}<span class="sr-only"> milliseconds</span>ms</div>` : ''}
2313                 ${p.rate_limit_remaining != null
2314                     ? `<div class="plugin-rate">${esc(String(p.rate_limit_remaining))} <span class="sr-only">API calls</span> remaining</div>`
2316                     : ''}
2317             </div>
2318         </div>`;
```

The visible-text rendering at line 2312 is `${number}<span sr-only>...</span>ms`. For `p.latency_ms = 8000`, this renders visibly as `8000ms` (the `sr-only` span is hidden). For `p.latency_ms = "8es"` (a string the FE failed to validate), `Number("8es")` = `NaN`, `NaN.toFixed(0)` = `"NaN"`, and the visible text becomes `NaNms`. **Neither path produces the literal visible string `8es`**, so the recon agent's hypothesis is that `p.latency_ms` is being received as the literal string `"8es"` AND the rendering pipeline is being short-circuited, OR there is a separate render path the recon did not find.

**INVESTIGATION SCOPE (FIRST step of Team B's work):**

1. Run a live curl against the deployed API:
   ```
   curl -fsS -H "Authorization: Bearer $FINLET_TEST_USER_API_KEY" \
     "$FINLET_BASE_URL/v1/plugins/health" | jq '.plugins[] | {name, latency_ms, type: (.latency_ms | type)}'
   ```
   Identify the actual shape of `latency_ms` for `price`, `fundamentals_s3`, `news_s3`, `sentiment` vs `econ`.

2. **Decision tree based on what the API returns:**

   - **(A) API returns a number for all plugins, but FE renders `8es` anyway.** Then there is a second render path or a CSS truncation. Check: is the `.plugin-latency` element width-clipped by CSS so `8000ms` truncates visually to `8es` (e.g., `font-size` rendering "00" as smaller)? Inspect `dashboard/styles.css` for `.plugin-latency` width rules. Search for any other site that writes to `.plugin-latency` or to `<div class="plugin-latency">` content. Fix in `dashboard/`.
   - **(B) API returns a string like `"8es"` for the 4 affected plugins.** Then the BE is malformed. Inspect `finlet/api/routes_plugins.py` and the underlying service. Likely culprit: a serializer that converts `8` (seconds) into `"8s"`, or a humanize-style formatter that produced `"8es"` from `"8.something seconds"` via a botched substring/regex. Fix in `finlet/api/`. Also, harden `dashboard/app.js:2312` to coerce non-numeric to a sensible fallback (e.g., display the raw string verbatim, or `--`).
   - **(C) API returns a number for `econ` but `null`/`undefined` for the 4 affected.** Then the FE skips rendering (line 2312 ternary). The `8es` text must come from somewhere else (maybe `p.message`?). Check `p.message` for the affected plugins — possibly the message contains `8es` and the blind agent visually merged the message line with the latency line. Fix in BE (populate `latency_ms` for the affected plugins) AND/OR clarify visual separation in CSS.

3. Based on (A)/(B)/(C), produce the actual fix. **The team's deliverable is the fix appropriate to whichever case (A)/(B)/(C) holds.**

**Files touched:** depends on investigation outcome:
- Modified: `dashboard/app.js` (line 2312 area) — at minimum, coerce `Number(p.latency_ms)` and reject `NaN`. Replace the inline ternary with a small `formatLatency(latency_ms)` helper that returns `null` for non-finite numbers, then short-circuit the `<div class="plugin-latency">` if helper returned `null`. This makes the FE robust against any future BE drift.
- Modified or New: `finlet/api/routes_plugins.py` AND/OR `finlet/api/services/plugin_service.py` — only if case (B). Ensure `latency_ms` is always emitted as a finite numeric, never a pre-formatted string.
- Modified or New: `tests/api/test_plugins_health.py` (or sibling) — assert that `GET /v1/plugins/health` returns `latency_ms` as a numeric (or `null`), never a string, for every plugin in the registry. Iterate over the full plugin set, not a single fixture.
- Modified or New: `tests/e2e/journey-*.spec.ts` — add a Playwright assertion that every visible `.plugin-latency` element's textContent matches the regex `/^\d+(\.\d+)?ms$/` (canonical form). Re-uses the existing journey fixture pattern. Use the test user's session.

**Deliverable:** Plugin Health latency badges render as canonical `Nms` (or `N.Ns`) for every plugin in the registry. The malformed string `8es` no longer appears anywhere in the dashboard. The FE is robust against non-numeric `latency_ms` (coerces or omits, never renders garbage).

**Validation:**
- [ ] `uv run pytest tests/api/ -k plugins_health -x -q` — green (only if BE fix; else N/A).
- [ ] `npx playwright test tests/e2e/journey-*.spec.ts -k 'plugin' -x` — green, including the new latency-format assertion.
- [ ] `bash scripts/lint-trusted-types.sh` — clean.
- [ ] `bash scripts/lint-event-bus.sh` — clean.
- [ ] Manual: `curl -fsS -H "Authorization: Bearer $FINLET_TEST_USER_API_KEY" "$FINLET_BASE_URL/v1/plugins/health" | jq '.plugins[] | .latency_ms | type' | sort -u` returns either `"number"` or `"null"`, never `"string"`. (Phase 5.5 retest envelope.)
- [ ] Manual: load `https://finlet.dev/index.html` (after deploy) and confirm every Plugin Health row's latency badge ends in `ms` or `s` (no `8es`). (Phase 5.5 retest.)

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Push your branch.
- Run the curl investigation FIRST. Pick the smallest fix that closes the case — do not refactor unrelated plugin-health code.
- If the fix is BE-only, you do NOT need to modify `dashboard/app.js`. (But add the FE robustness coercion regardless — defense-in-depth against future drift.)
- If the fix needs both BE and FE, the BE fix is primary; the FE coercion is secondary.
- Cleanup: if your investigation creates server-side test sessions, delete them. The test user has a 1-session-concurrent quota.
- After Team A's merge, your worktree must rebase or merge `origin/main` BEFORE running validation. The worktree may have started with `dashboard/app.js` pre-A; the `pnlArrow`/`pnlClass` changes from A must be present.

---

### Team E: Ledger + pending_recurrences maintenance

**Blocked by:** Teams A and B (needs their merge SHAs).

**Read these files first:**
- `docs/bug-hunt/ledger.jsonl` — last ~20 lines for schema reference. The flat one-line-per-finding schema is documented in the Required Docs Updates block of `triage.md`.
- `docs/bug-hunt/pending_recurrences.jsonl` — currently empty. Confirm.
- All `docs/bug-hunt/refactor-queue/*.md` — look for any with `status: shipped` AND no `verdict:` field set. None expected this iteration; the convention-enforcement-2026-05-05 doc already has `verdict: effective`.

**Files touched:**
- Modified: `docs/bug-hunt/ledger.jsonl` — append exactly 2 JSON lines, one per closed real-broken finding:
  - `{"iteration_ts":"20260505T142400Z3330","finding_id":"pnl-zero-loss-class","category":"dashboard-state-sync","summary":"P&L / Return / Max Drawdown tiles render red ▼ -0.00% at zero — sign classification used raw value instead of rounded display value, and Max Drawdown was hardcoded to pnl-negative regardless of value","scope_files":["dashboard/app.js"],"team":"A","commit":"<merge SHA from team A>"}`
  - `{"iteration_ts":"20260505T142400Z3330","finding_id":"plugin-health-latency-8es","category":"<reuse-existing-or-mint>","summary":"Plugin Health latency badges rendered malformed unit string '8es' on 4 of 8 plugins — <root cause from Team B>","scope_files":[<from Team B's actual diff>],"team":"B","commit":"<merge SHA from team B>"}`
  - For finding 2's category: read what Team B actually changed. If it's `dashboard/app.js` only (FE coercion), reuse `dashboard-state-sync`. If it's `finlet/api/` (BE serializer), prefer `plugin-registry-routing` (existing tag) or `cli-server-state-mismatch` (existing) if the contract drift maps. Mint a new tag like `plugin-health-data-shape` only if no existing tag fits.
- Modified: `docs/bug-hunt/pending_recurrences.jsonl` — no pruning expected this iteration (it's already empty). Verify and leave unchanged. If Phase 5.5 produces patch-ineffective signals later, the orchestrator appends inline.
- New (only if pruning occurs): `docs/bug-hunt/pending_recurrences.resolved.jsonl` — not expected this iteration.

**Deliverable:** `docs/bug-hunt/ledger.jsonl` grows by exactly 2 lines, one per closed finding, with correct merge SHAs. `pending_recurrences.jsonl` unchanged.

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` — value is 2 greater than baseline (capture baseline before edit).
- [ ] `tail -2 docs/bug-hunt/ledger.jsonl | jq -c '.iteration_ts'` — both lines have `"20260505T142400Z3330"`.
- [ ] `tail -2 docs/bug-hunt/ledger.jsonl | jq -e 'has("commit") and (.commit | length == 40)'` — both lines have a 40-char commit SHA.
- [ ] `tail -2 docs/bug-hunt/ledger.jsonl | jq -c '.commit'` — both SHAs exist on `main`: `git cat-file -e <sha>^{commit}` returns 0.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Push your branch.
- Read the actual merge SHAs from `git log main` AFTER Teams A and B have merged (use `git log -2 --pretty=%H main` for the last two merge SHAs in order).
- The `category` field for finding 2 is determined by Team B's actual diff scope — DO NOT pick it before reading their diff.
- Do NOT modify `pending_recurrences.jsonl` unless Phase 5.5 produced new patch-ineffective signals (the orchestrator handles that step inline; you only stage what's already written).

---

### Team D: Documentation update

**Blocked by:** Team E (must stage E's output as part of "all artifacts" commit).

**Read these files first:**
- `docs/bug-hunt/20260505T142400Z3330/triage.md` — § "Required Docs Updates" block for the mandatory list.
- `docs/REMAINING_TASKS.md` — find the most recent "Bug Hunt" subsection for pattern.
- `docs/LESSONS.md` — last few entries for tone/format reference.
- `docs/ARCHITECTURE.md` — verify whether anything Team A or Team B changed alters CSP, security headers, middleware stack, route surface, schema field, plugin registry, or dashboard surface. Most likely UNCHANGED this iteration (both fixes are render-formatting bugs, not architectural).
- `docs/KNOWN_FAILURES.md` — refresh against current main.

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — add a "Bug Hunt 20260505T142400Z3330 — Closed" subsection mirroring prior iterations. Two bullets, one per finding, with merge-SHA cross-references.
- Modified: `docs/LESSONS.md` — append at least one reusable lesson. Suggested:
  - "Sign classification on raw floating-point values can leak into UI when the displayed (rounded) value is zero. Classify on the rounded display value, not the raw input. — bug-hunt 20260505T142400Z3330"
  - "Hardcoded loss-class affordances (e.g., always-red Max Drawdown tile) violate the contract that visual style follows data state. Drive style from value sign, not from semantic intent of the metric. — bug-hunt 20260505T142400Z3330"
  - "When the FE consumes a numeric API field, ALWAYS coerce + validate at the render boundary. `${Number(x).toFixed(0)}ms` looks safe but `Number('8es') = NaN` propagates 'NaNms' to the user. Use a validated helper that returns `null` for non-finite. — bug-hunt 20260505T142400Z3330" (if Team B's diff includes the FE coercion).
- Modified or skip: `docs/ARCHITECTURE.md` — explicit statement "no architectural surface changed this iteration" if untouched.
- Modified: `docs/KNOWN_FAILURES.md` — refresh; remove any pre-existing failures resolved this iteration.
- Modified or skip: `docs/decisions/*.md` — only if a non-trivial decision was made (e.g., "FE coerces numeric latency at render boundary as defense-in-depth"). Optional.
- Staged in same commit:
  - `docs/bug-hunt/20260505T142400Z3330/blind_report.json`
  - `docs/bug-hunt/20260505T142400Z3330/cleanup.log`
  - `docs/bug-hunt/20260505T142400Z3330/triage.md`
  - `docs/bug-hunt/20260505T142400Z3330/triage.json`
  - `docs/bug-hunt/20260505T142400Z3330/plan.md`
  - `docs/bug-hunt/20260505T142400Z3330/isolation_warning.txt`
  - `docs/bug-hunt/20260505T142400Z3330/deploy_status.txt` (after Phase 5.5)
  - `docs/bug-hunt/20260505T142400Z3330/retest_results.json` (after Phase 5.5)
  - `docs/bug-hunt/ledger.jsonl` (Team E's output)
  - `docs/bug-hunt/pending_recurrences.jsonl` (unchanged but staged for the same commit)

**Deliverable:** All artifacts staged + committed; LESSONS.md grows by ≥1 entry; REMAINING_TASKS.md has the new closed subsection; commit message explicitly references iteration `20260505T142400Z3330` and names which docs were touched.

**Validation:**
- [ ] `git status` shows zero untracked files in `docs/bug-hunt/20260505T142400Z3330/`.
- [ ] `git log -1 --name-only` shows all expected files in the docs commit.
- [ ] Commit message matches the required format: `docs: bug-hunt 20260505T142400Z3330 — record fixes for X, Y; LESSONS +N; ARCHITECTURE unchanged; ledger +2`.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Push your branch.
- Run AFTER Phase 5.5 completes (so `deploy_status.txt` and `retest_results.json` exist to be staged).
- The orchestrator will run Phase 5.5's inline writes (deploy_status, retest_results, pending_recurrences appends) BEFORE invoking you. You stage what's there.
- Skip `docs/ARCHITECTURE.md` if unchanged; document the skip in the commit message.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team B's investigation finds the bug is BE-side, requires touching `finlet/api/` which the dashboard team is not the canonical owner of | Medium | Low | Cross-cutting bug-hunt teams are an established pattern. The bug is in dashboard render path; root cause may be elsewhere. Team B has both surfaces in scope. |
| Team A's `_roundForDisplay` helper introduces new behavior at non-zero boundary (e.g., -0.005% rounds to -0.01% but -0.004% rounds to 0.00% — flipping classification) | Low | Low | Add explicit test at boundary values; document the expected behavior. The whole point is to align CLASS with VISIBLE TEXT — boundary flips are intentional. |
| `dashboard/app.js` merge conflict between A and B at non-disjoint lines | Low | Medium | A modifies 1939-1943, 2464-2467, 2499-2503, 1980-1984, 1974-1978. B modifies 2279-2317. Disjoint. Merge clean. |
| Plugin Health regression — Team B's coercion accidentally hides legitimate latency values | Low | Medium | Test with both finite-numeric inputs (existing behavior preserved) and non-numeric inputs (new safe-fallback). |
| Team B can't determine root cause without live curl evidence | Medium | Medium | Investigation is part of Team B's scope. Phase 5.5 retest will catch a wrong fix. |
| Phase 5.5 retest fails because the deploy lags behind the merge | Low | High | Phase 5.5 polls deploy completion before retest. If timeout, retest is skipped (not failed). |

## Session Plan

### Session 1 — fix teams (sequential merge on `dashboard/app.js`)

**Sequential merge:** Team A → Team B
**Parallel work:** Both teams may begin in their own worktrees in parallel. Team B rebases on `origin/main` before its merge gate.
**Targeted gate after each merge:**
- After A: `npx playwright test tests/e2e/journey-05-trade.spec.ts -x` AND `bash scripts/lint-trusted-types.sh` AND `bash scripts/lint-event-bus.sh`.
- After B: same e2e gate (B's new test) AND lint gates AND `uv run pytest tests/api/ -k plugins_health -x -q` (if BE diff).

**Session checkpoint:** full e2e smoke suite (the 7 standard journeys) green on `main`.

### Session 2 — bookkeeping (sequential)

**Sequential merge:** Team E → Phase 5.5 (deploy poll + retest, orchestrator-run) → Team D
**Targeted gate after each merge:**
- After E: `wc -l docs/bug-hunt/ledger.jsonl` is +2; `tail -2 | jq -c '.iteration_ts'` matches.
- After Phase 5.5: see Phase 5.5d output (counts + pending_recurrences appended inline by orchestrator).
- After D: `git status` clean in `docs/bug-hunt/20260505T142400Z3330/`; commit message regex matches.

**Session checkpoint:** `git log --oneline main -10` shows the four merges (A, B, E, D) in order, plus orchestrator's Phase 5.5 status update if any.
