## Broken (will be fixed this iteration)
- GET /v1/sessions/{id}/market/fundamentals always returns Finnhub initialization error even though fundamentals_s3 plugin is HEALTHY [evidence: "Called GET /v1/sessions/4cdfde60a19b/market/fundamentals?ticker=SPY (and with &provider=fundamentals_s3 and &plugin=fundamentals_s3 query params). All three variants returned {\"error\":{\"code\":\"service_unavailable\",\"message\":\"Finnhub plugin not initialized. Provide 'api_key' config. Get a key at https://finnhub.io/\",\"details\":[]}}. The Plugin Health panel shows fundamentals_s3 as Status: Healthy with 'OK -- 21 cached files'. The API ignores the healthy cached plugin and hardcodes a Finnhub dependency for the fundamentals endpoint."] [scope hint: finlet/api/routes/market.py, finlet/plugins/registry.py, finlet/plugins/fundamentals_s3.py]
- Settings > Plugins page shows "You have unsaved changes" banner immediately on load before any user interaction [evidence: "Navigating to Settings > Plugins without touching any form field triggers the orange 'You have unsaved changes' bar with Discard / Save Changes buttons. Screenshot saved to plugins-page.png confirms the bar is visible at page load. Clicking Discard dismisses it but it returns on next navigation to the page."] [scope hint: dashboard/settings.js, dashboard/form-dirty-tracker.js]
- Trade Ticket "Available Cash" shows stale pre-trade value after an order fills [evidence: "After BUY 10 SPY MARKET filled at $545.15, the dashboard Overview correctly updated Cash to $94,548.49. However the Trade Ticket dialog (which remained open) still displayed 'Available Cash: $100,000.00'. A second trade placed from the same open dialog would show incorrect available cash to the user."] [scope hint: dashboard/trade-ticket.js, dashboard/api-utils.js]

## Logged (not actioned)
- Finlet benchmark MCP tools (submit_order, get_fundamentals, create_session, etc.) are not registered in the Claude Code MCP environment despite being advertised [classification: needs-investigation]
- 9 console errors: "Password field is not contained in a form" on Settings page [classification: annoying]
- The "Welcome to Finlet" CLI-instructions banner persists on the dashboard after a session is created and active [classification: annoying]
- Trade Ticket dialog stays open silently after a successful order — no success feedback inside the dialog [classification: annoying]
- Onboarding wizard "Continue" button is disabled with no explanation — requires clicking a persona card first but there is no hint text [classification: annoying]
- Conservative ETF session template defaults start date to today (2025-04-29), giving zero days of historical replay [classification: annoying]
- The auth page has 3 duplicate email inputs in the DOM (sign-in, sign-up, forgot-password tabs), causing strict-mode selector failures [classification: annoying]
- Multiple overlapping dialogs/modals rendered simultaneously in the DOM at dashboard load [classification: needs-investigation]
- Trade Ticket UI has no "Reasoning" field — trades placed via UI always show "--" in the Reasoning column [classification: nice-to-have]
- No "Strategy" concept in the UI — "fundamentals strategy" is not surfaced as a configurable, named thing [classification: nice-to-have]
- Plugin health panel shows cached file counts but not which tickers or date ranges are covered [classification: nice-to-have]
- news_s3 and sentiment plugins show "Degraded — Run ingestion first" with no in-app button or link to trigger ingestion [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260429T232205Z17ff — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made.
6. `docs/bug-hunt/20260429T232205Z17ff/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt, team_*_verify.md, blind_diagnostic.log).
   No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260429T232205Z17ff","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main`.
   Validation hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl`
   should grow by exactly 3 lines this iteration.

Team D's commit message must reference iteration 20260429T232205Z17ff and name which docs were
touched (e.g., "docs: bug-hunt 20260429T232205Z17ff — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +3").

## Forward-signal note (read by Phase 6 verdict tracker)

This iteration's triage emitted TWO same_root_cause_as forward signals:

- `dirty-state-tracker` recurrence (Settings > Plugins cold-load banner) → links
  to ledger entry `settings-dirty-banner` (iter 20260429T052717Z1a13). This is
  the THIRD instance of the same shape (entry 11 `settings-dirty-banner-onload`,
  entry 15 `settings-dirty-banner`, now this). Note that v2 of the
  dirty-state-tracker refactor (`ed15c6c`) shipped between the prior iteration
  and this one. v2 is therefore demonstrated to be incomplete — Plugins tab
  not covered, or loader registry has a gap. Phase 6 must update the queue doc
  verdict (currently locked at "incomplete" from v1) to reflect v2 outcome.
- `dashboard-state-sync` recurrence (Trade Ticket Available Cash stale) → links
  to ledger entry `trade-ticket-stale-cash` (iter 20260428T031818Z2efa) and
  `trade-ticket-cash-dash` (iter 20260429T052717Z1a13). This is the THIRD
  instance of the same shape across THREE iterations. The event-bus refactor
  closed the broader cluster but Trade Ticket dialog re-opens a stale snapshot
  every time. Phase 6 must consider drafting a focused refactor queue doc:
  "Trade Ticket dialog state-sync — open-then-subscribe + on-open republish".

The third broken item (`plugin-registry-routing`) is a NEW category — not a
recurrence. Standard patch path. Likely root cause: plugin registry first-match
returning Finnhub before fundamentals_s3 because of registration order (see
project memory `project_plugin_ordering_bug.md` from 2026-04-07 — register
free plugins BEFORE API-key plugins).
