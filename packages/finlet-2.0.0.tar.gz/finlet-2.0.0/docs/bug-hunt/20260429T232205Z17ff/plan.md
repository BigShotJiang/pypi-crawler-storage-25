# Bug-Hunt 20260429T232205Z17ff — Execution Plan

> Generated from `docs/bug-hunt/20260429T232205Z17ff/triage.md`. Last updated: 2026-04-29.
>
> Three real-broken findings + mandatory docs team. Two of three findings are
> recurrences with `same_root_cause_as` forward signals — patches OK this iteration,
> but the next iteration's gate will fire on these unless the fixes hold.

## Constraints

- **Scope:** patch-only this iteration (no refactor-quality work). The three forward
  signals will route to refactor on the next /bug-hunt invocation per the
  Refactor Gate. Do not let scope creep into "while we're here" cleanups.
- **Worktree-isolated agents only.** Every code team runs in its own worktree
  (per Finlet CLAUDE.md rule 5). Team D (docs) also runs in a worktree.
- **Per-merge gate:** each team merges to main individually with targeted tests
  on the touched files, NOT a full-suite run after all merges.
- **No emoji in code or docs unless already present.** Per global rules.
- **Three lines added to ledger.jsonl** — exactly one JSON line per closed broken
  item, by Team D, in the order A → B → C.

## File Conflict Table

| File | Touched by Teams |
|------|------------------|
| `finlet/api/services/market_service.py` | A |
| `finlet/api/routes_market.py` | A |
| `finlet/api/app.py` | A |
| `finlet/plugins/base.py` | A (read-only — recon already mapped) |
| `dashboard/settings.js` | B |
| `dashboard/form-dirty-tracker.js` | B |
| `dashboard/trade-ticket.js` | C |
| `dashboard/app.js` | C |
| `dashboard/api-utils.js` | C (read-only unless lastValue API needed) |
| `tests/api/...` (new test) | A |
| `tests/e2e/journey-06-settings.spec.ts` | B |
| `tests/e2e/journey-05-trade.spec.ts` | C |
| `docs/REMAINING_TASKS.md` | D |
| `docs/LESSONS.md` | D |
| `docs/ARCHITECTURE.md` | D (skip if untouched-with-explicit-note) |
| `docs/KNOWN_FAILURES.md` | D |
| `docs/bug-hunt/ledger.jsonl` | D |
| `docs/bug-hunt/20260429T232205Z17ff/*` | D (stage all artifacts) |

**No code-team-vs-code-team file conflicts.** A/B/C can work in parallel
worktrees and merge sequentially without rebase pain. Team D depends on A+B+C
merge SHAs.

## Dependency Graph

- **Team A** (plugin-registry-routing) — independent, can start immediately
- **Team B** (dirty-state-tracker / Plugins tab) — independent, can start immediately
- **Team C** (Trade Ticket cash sync) — independent, can start immediately
- **Team D** (docs + ledger) — blocked by A, B, C (needs merge SHAs)

## Critical Path

`max(A, B, C) → D` — all three fix teams in parallel; D last.

---

## Teams

### Team A: Plugin Registry Routing — fundamentals_s3 fallthrough fix

**Blocked by:** none — can start immediately

**Read these files first:**
- `finlet/api/app.py:100-121` — current plugin registration site. Comment at 100-101 confirms FundamentalsPlugin (S3) is registered BEFORE FinnhubPlugin "so it is the default for PluginType.FUNDAMENTALS."
- `finlet/api/services/market_service.py:69-91` — `route_query` fallback chain: gets plugins by type, tries each in registration order, accepts response if `not response.error or terminal_empty`. NO health check before dispatch.
- `finlet/api/routes_market.py:161-232` — fundamentals route handler. Accepts `ticker, concept, action, statement_type, limit` only. Does NOT accept `provider`/`plugin` query params despite the blind agent trying them.
- `finlet/plugins/base.py:312-389` — circuit breaker (5 consecutive failures, 60s reset) and `get_plugins_by_type` (returns in registration order).
- `finlet/plugins/fundamentals_s3.py` — confirm class exists and what `query()` returns when S3 has data vs. when it doesn't.

**Root cause hypothesis (verify before fixing):** the FundamentalsPlugin (S3) is healthy per the dashboard panel, but its circuit breaker may be open in the production process due to earlier failures, OR its `query()` returns a `PluginResponse` with `error` set even when data exists, causing `market_service.route_query` to fall through to FinnhubPlugin which is unconfigured → 503.

Run before fixing:
```bash
# Reproduce on a real session via cURL (use the test user's API key)
SESSION=$(curl -fsS -H "Authorization: Bearer $FINLET_TEST_USER_API_KEY" https://finlet.dev/sessions | jq -r '.[0].id // empty')
curl -fsS -H "Authorization: Bearer $FINLET_TEST_USER_API_KEY" \
  "https://finlet.dev/v1/sessions/$SESSION/market/fundamentals?ticker=SPY" | jq
# Expected pre-fix: Finnhub error. Expected post-fix: data from S3 plugin.
```

**Files touched:**
- Modified: `finlet/api/services/market_service.py` — fix the fallback chain so a healthy S3 plugin's empty/error response does NOT cascade to Finnhub when Finnhub has no API key (better: short-circuit the chain when the next plugin is unconfigured; OR explicitly check plugin health before dispatch).
- Modified: `finlet/api/routes_market.py` — accept an optional `provider` query param that pins the plugin (useful for diagnosis and lets the user route around a bad fallback). Already accepted by `_route_query_with_rate_limit`? If yes, just thread it through the route handler.
- Modified: `finlet/api/app.py` (only if registration order needs adjustment — recon says it's already correct, so likely no change here).
- New: `tests/api/test_market_fundamentals_routing.py` — case 1: `fundamentals_s3` returns data, response is the S3 data (not Finnhub error). Case 2: `fundamentals_s3` errors, FinnhubPlugin has no API key, response is the S3 error (not Finnhub init error — surface the FIRST error, don't fall through to a misconfigured plugin). Case 3: `?provider=fundamentals_s3` pins the plugin, no fallthrough.

**Deliverable:** GET `/v1/sessions/{id}/market/fundamentals?ticker=SPY` returns S3 cached data when fundamentals_s3 is healthy. When S3 errors, the response surfaces the S3 error, not a misleading Finnhub-init error. Optional `?provider=fundamentals_s3` query param pins the plugin.

**Validation:**
- [ ] `uv run pytest tests/api/test_market_fundamentals_routing.py -x -q` passes (3+ cases)
- [ ] `uv run pytest tests/api -q` passes (no regression elsewhere)
- [ ] `uv run ruff check finlet/api tests/api` clean
- [ ] `uv run mypy finlet/api --ignore-missing-imports` clean
- [ ] Manual cURL on staging or local server: `?ticker=SPY` returns S3 data, not Finnhub error.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Branch name: `bug-hunt/20260429T232205Z17ff/team-A-plugin-routing`.
- Follow patterns in existing route handlers (e.g., `finlet/api/routes_market.py:get_price`). Domain exception → HTTP mapping is set up at the FastAPI exception-handler layer; don't reinvent.
- Do NOT touch `finlet/plugins/base.py` registration logic — fix the dispatch in `market_service.py` instead.
- If reproduction shows a different root cause than the hypothesis, write a one-paragraph note in the team verify file explaining what you found. Don't fix the wrong thing.

---

### Team B: Dirty-State Tracker — Plugins-tab cold-load false-positive

**Blocked by:** none — can start immediately

**Read these files first:**
- `dashboard/settings.js:942-1020` — `initPlugins()` and `loadPlugins()`. Line 946 calls `registerLoader(loadPlugins())`. Line 1019 calls `snapshotAllTracked()` AFTER plugin cards render. Lines 970-1003 dynamically render toggle-switch inputs and password inputs that are NOT in the DOM during the form-tracker's initial baseline pass.
- `dashboard/form-dirty-tracker.js:260-295` — registry drain loop (lines 274-278), `_loaderUpdating` guard (line 292), and the second `_attachListeners()` post-gate at line 288. Recon shows the gate re-attaches listeners but the dynamically-created toggle inputs may already have a `change` event queued before `_loaderUpdating` flips to false.
- Run `git show ed15c6c -- dashboard/settings.js dashboard/form-dirty-tracker.js | head -300` — see what v2 refactor (the previous attempt) actually changed and why Plugins tab slipped through.
- `tests/e2e/journey-06-settings.spec.ts` — current Settings test surface; the dirty-banner regression test from the previous iteration (commit `6a8d798`) lives here.

**Root cause hypothesis (verify before fixing):** dynamically-rendered Plugins-tab toggle inputs are not part of the form-dirty-tracker's baseline snapshot. When the toggle's `change` event fires (browser-generated or autofill-related) before `_loaderUpdating` is released, the synthetic field is marked dirty and the banner shows. v2's "self-enumerating loader registry" handles loader timing but doesn't cover dynamically-injected DOM.

**Files touched:**
- Modified: `dashboard/settings.js` — in `loadPlugins()` line ~1019, ensure the dynamic toggle inputs are included in the baseline snapshot AFTER they're injected. Two viable patterns:
  1. **Snapshot-after-render** (simpler): pass the rendered card element's input refs to `snapshotAllTracked()` so they're added to `originalValues` immediately.
  2. **Suppress-during-bind** (more robust): keep `_loaderUpdating: true` until both `Promise.all` resolves AND `snapshotAllTracked()` has captured the dynamic fields, then release.
- Modified: `dashboard/form-dirty-tracker.js` — if the snapshot API doesn't currently support "add these fields to the baseline post-init", extend it. Keep the registry self-enumerating contract from v2.
- Modified: `tests/e2e/journey-06-settings.spec.ts` — add a test: `cold-load Plugins tab → wait 1s → assert no .unsaved-changes-banner visible`. This is the regression test that catches the recurrence.

**Deliverable:** `Settings → Plugins` tab cold-load shows zero "You have unsaved changes" banner within 1s of navigation. Banner appears within 200ms of an actual user input change. Discard / Save flow still works.

**Validation:**
- [ ] `npx playwright test tests/e2e/journey-06-settings.spec.ts -x` passes (incl. the new cold-load assertion)
- [ ] Manual: open `/settings.html#plugins` cold, wait 1s, no banner. Toggle a plugin → banner appears within 200ms. Click Discard → banner clears, toggle reverts.
- [ ] Same manual flow for `/settings.html` (Profile tab) — must NOT regress.
- [ ] `dashboard/css.lint` (or whatever lint covers dashboard) clean — `bash scripts/lint-trusted-types.sh` passes.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Branch: `bug-hunt/20260429T232205Z17ff/team-B-dirty-state-plugins`.
- Follow the v2 self-enumerating loader registry contract — do not introduce a per-tab Promise.allSettled enumeration in consuming pages (banned per project convention in `docs/decisions/dashboard-form-dirty-tracker-registry.md`).
- The fix must be local to settings.js + form-dirty-tracker.js. Do NOT touch other pages' tracker logic — they're not in scope this iteration.
- If you discover the v2 refactor IS covering Plugins correctly and the bug is a different shape (e.g., the banner is firing for a separate non-dirty-tracker reason), STOP, write a one-page diagnosis to `docs/bug-hunt/20260429T232205Z17ff/team_B_diagnosis.md`, and do not push a wrong fix.

---

### Team C: Trade Ticket Cash Sync — open-stays-stale fix

**Blocked by:** none — can start immediately

**Read these files first:**
- `dashboard/trade-ticket.js:14, 136-139, 215-217, 230-245` — `tradeTicketBusUnsubscribe` lifecycle. Line 136-139 subscribes on open. Line 215-217 unsubscribes on close. Line 230-239 is `handlePortfolioUpdateForTicket(data)` which checks `if (!tradeTicketOpen)` but does NOT update if the data shape is unexpected. Line 245 is `fetchCashBalance()` which DOES validate `currentSessionId`.
- `dashboard/app.js:1395, 1441, 762-775` — SSE connection lifecycle. Line 1441 publishes `portfolio:updated` on every SSE `portfolio` event. Line 762-775 is session-switch handling (reconnects SSE).
- Run `git show f8a8365 -- dashboard/trade-ticket.js | head -200` — see what the previous Trade-Ticket-cash-dash fix (entry 18 in ledger) changed. Was it open-time fetch only? Did it fix the dialog-stays-open-during-fill case?
- `dashboard/api-utils.js` — check whether there's already a "give me the last published value of this event" API (often called something like `getLastPublished` or `latestSnapshot`). If yes, use it. If no, the team may need to add one (small addition; coordinate with the contract in `docs/decisions/dashboard-event-bus.md`).

**Root cause hypothesis (verify before fixing):** the Trade Ticket dialog subscribes to `portfolio:updated` on open. When a fill happens while the dialog is open, the SSE event publishes, but the handler at trade-ticket.js:230-239 either returns early (some `tradeTicketOpen` race) or the cash-display element selector doesn't match the dialog's actual cash field. Most likely fix: add a `fetchCashBalance()` call on every `portfolio:updated` event for the open dialog, OR ensure `handlePortfolioUpdateForTicket` actually writes to the dialog's cash field (selector might have drifted).

Reproduction script:
```javascript
// In browser console while on dashboard with active session:
window.finletBus.publish('portfolio:updated', { cash: 99999.99 });
// Expected: open Trade Ticket cash field updates to $99,999.99 immediately.
// Bug: cash field stays at original value.
```

**Files touched:**
- Modified: `dashboard/trade-ticket.js` — fix `handlePortfolioUpdateForTicket(data)` so the cash element actually updates. Either:
  1. Update the cash DOM element directly with the bus payload's `cash` value (verify the selector points to the dialog's cash field, not the dashboard tile).
  2. Call `fetchCashBalance()` on every `portfolio:updated` (slightly heavier but bullet-proof).
- Modified: `dashboard/app.js` — only if the SSE publish payload is missing the `cash` field; in that case, ensure publish payload includes `{cash, ...}`.
- Modified: `tests/e2e/journey-05-trade.spec.ts` — add a test: open Trade Ticket → fill an order via API → assert dialog Available Cash updates within 2s.

**Deliverable:** With Trade Ticket dialog open, executing a BUY/SELL fill updates the dialog's "Available Cash" within 2s of the SSE event. Dashboard tile and dialog never disagree by more than one event-loop tick.

**Validation:**
- [ ] `npx playwright test tests/e2e/journey-05-trade.spec.ts -x` passes (incl. the new same-dialog-fill assertion)
- [ ] Manual: open Trade Ticket. In another tab/window, place a BUY 1 SPY MARKET. Within 2s, the original dialog's Available Cash updates.
- [ ] Manual: with dialog open, switch session → Available Cash updates to new session's cash, OR dialog auto-closes (either is acceptable; document which).
- [ ] `bash scripts/lint-trusted-types.sh` passes.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Branch: `bug-hunt/20260429T232205Z17ff/team-C-trade-ticket-cash`.
- Use `window.finletBus.subscribe` + `unsubscribe` only — no direct `addEventListener('finlet:portfolio:updated', ...)` per `docs/decisions/dashboard-event-bus.md`.
- This is a **patch**, not a refactor. Do NOT extract a "dialog-state-sync framework" or rewrite the open/close lifecycle. Targeted fix only — the broader pattern goes to refactor on the next iteration.
- If reproduction shows the publish never fires (publisher-side bug), STOP and report — fixing trade-ticket.js for a dashboard/app.js bug is the wrong direction.

---

### Team D: Docs + Ledger

**Blocked by:** Teams A, B, C all merged to main (need merge SHAs for ledger)

**Read these files first:**
- `docs/bug-hunt/20260429T232205Z17ff/triage.md` — the iteration's bugs and the Required Docs Updates block (mandatory scope).
- `docs/bug-hunt/ledger.jsonl` — schema reference for new entries.
- `docs/REMAINING_TASKS.md` — pattern for "Bug Hunt $TS — Closed" subsections.
- `docs/LESSONS.md` — pattern for new lessons (reusable rules, not diff recaps).
- `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` — to update v2 verdict tracking (this iteration is a recurrence after v2 ship).

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — add "Bug Hunt 20260429T232205Z17ff — Closed" subsection listing the 3 fixes.
- Modified: `docs/LESSONS.md` — at least one new lesson per real-broken finding:
  1. Plugin fallback chain must distinguish "next plugin is healthy but empty" from "next plugin is unconfigured" — surface the first plugin's error instead of leaking a misleading second-plugin error.
  2. Self-enumerating loader registry covers loader-timing races but does NOT cover dynamically-injected DOM — every loader that injects new inputs after fetch must extend the snapshot.
  3. Bus-subscriber dialogs that "open and listen" miss any event that fired before subscription. The fix pattern is "open and prime" (fetch latest state on open) plus subscribe — never subscribe-only.
- Modified: `docs/ARCHITECTURE.md` — only if the plugin-registry-routing fix changed the route surface (added `?provider=` param) or the dispatch contract; else add an explicit "no architecture changes this iteration" note in the commit message.
- Modified: `docs/KNOWN_FAILURES.md` — refresh; remove resolved entries.
- Modified: `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` — append a `verdict_v2:` field tracking that v2 is incomplete (Plugins tab recurrence), with evidence pointer to this iteration's triage. Keep `verdict:` (v1's) untouched per "verdict is set once" rule.
- New: `docs/bug-hunt/refactor-queue/trade-ticket-state-sync.md` — pre-draft refactor scope for the Trade Ticket open/listen/republish pattern (3 instances across 3 iterations is a strong refactor candidate). Status: `ready`. Drafted: 2026-04-29. The next /bug-hunt invocation's gate will pick this up and pause for refactor.
- Modified: `docs/bug-hunt/ledger.jsonl` — append exactly 3 lines, one per closed broken item, in order A → B → C, with merge SHAs from main.
- New: `docs/decisions/<short-name>.md` — only if a non-trivial decision was made (e.g., "fundamentals route accepts ?provider= override"); else skip with note.
- Staged + committed: every artifact in `docs/bug-hunt/20260429T232205Z17ff/` (blind_report.json, cleanup.log, isolation_warning.txt, triage.md, triage.json, plan.md, team_*_verify.md if any).

**Deliverable:** all docs updated, ledger has 3 new lines, refactor queue has new `trade-ticket-state-sync.md` status: ready, dirty-state-tracker.md updated with v2 verdict tracking. `wc -l docs/bug-hunt/ledger.jsonl` returns 21 (was 18, +3 this iteration).

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` → 21
- [ ] `jq -c . docs/bug-hunt/ledger.jsonl | wc -l` → 21 (every line is valid JSON)
- [ ] `git ls-files docs/bug-hunt/20260429T232205Z17ff/` shows all artifacts tracked, none missing.
- [ ] `cat docs/bug-hunt/refactor-queue/trade-ticket-state-sync.md | head -10` shows `status: ready`.
- [ ] Commit message references iteration `20260429T232205Z17ff` and names which docs were touched.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Branch: `bug-hunt/20260429T232205Z17ff/team-D-docs`.
- Read the Required Docs Updates block in triage.md as your spec — every numbered item is in scope.
- For ledger.jsonl: the `commit` field is the merge SHA on `main` (use `git log main --oneline | head -10` to find each team's merge commit; recognize them by the team-A/B/C branch prefix in the merge title).
- Do NOT silently omit any item from the Required Docs Updates block. If something is genuinely not applicable (e.g., ARCHITECTURE.md has no surface change), say so explicitly in the commit message, e.g., "ARCHITECTURE.md: no surface changes this iteration."
- The refactor queue doc for trade-ticket-state-sync should follow the schema of existing queue docs (frontmatter with status/category/instances/iterations/drafted, then sections: Why, Root cause, Refactor scope, Files touched, Validation, Break-even, Reversal path, Out of scope, Verdict pending).

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A's hypothesis is wrong (bug isn't fallback chain — could be fundamentals_s3.query() returning error always) | Medium | Medium | Reproduction script in Team A spec runs first; if S3 plugin errors, fix the S3 plugin OR shortcut the chain — both are in-scope |
| Team B fixes Profile but not the actual Plugins-tab cause (banner from a non-tracker source) | Medium | High | Diagnosis-first: if the bug isn't a tracker false-positive, write team_B_diagnosis.md and HALT — don't ship a wrong fix that pushes the bug into "fixed" status with no real fix |
| Team C breaks dialog-close behavior or session-switch behavior | Low | Medium | Validation includes both same-session-fill (primary) AND session-switch behavior (regression check) |
| Team D forgets to capture all 3 ledger entries | Low | High | Validation step `wc -l docs/bug-hunt/ledger.jsonl` → 21 catches this |
| The forward-signal recurrences indicate Team B/C patches won't hold | High (per Refactor Gate logic) | Medium (next iteration catches) | Team D pre-drafts `trade-ticket-state-sync.md` in refactor-queue with status: ready so next /bug-hunt invocation's gate fires deterministically. Dirty-state-tracker.md gets v2 verdict tracking so next iteration knows v2 was incomplete |

## Session Plan

### Session 1
**Parallel:** Teams A, B, C in their own worktrees.

**Merge order:** whichever team finishes first merges first (race-to-finish). Per-merge gate is the targeted test command in each team's Validation section. After all three merge:

**Per-merge micro-gate (after each of A/B/C):**
- A merges → `uv run pytest tests/api -q` (or just the new test) → must pass
- B merges → `npx playwright test tests/e2e/journey-06-settings.spec.ts -x` → must pass
- C merges → `npx playwright test tests/e2e/journey-05-trade.spec.ts -x` → must pass

If any per-merge gate fails, that team's merge is reverted; the team re-spawns to fix; subsequent teams in the queue continue (their work is independent).

**Session 1 checkpoint after all three merge:** `uv run pytest -q` full suite + `npx playwright test -x` full E2E suite. Must pass before Session 2 starts.

### Session 2
**Sequential:** Team D only.

**Merge gate after D:**
- `wc -l docs/bug-hunt/ledger.jsonl` → 21
- `jq -c . docs/bug-hunt/ledger.jsonl > /dev/null` → no JSON errors
- `git status docs/bug-hunt/20260429T232205Z17ff/` → clean (all artifacts tracked)

**Final session checkpoint:** push `main` → CI green (ruff + mypy + pip-audit + pytest) → SSM deploy succeeds → `curl https://finlet.dev/health` returns 200.

---

## Notes for Phase 6 (recurrence + verdict tracking)

After Team D completes, Phase 6 of the bug-hunt skill must:
1. Run the recurrence-check `jq` query — expected output now includes:
   - `dashboard-state-sync` count=7, iterations=4 (will be over 2/2 — refactor candidate)
   - `dirty-state-tracker` count=3, iterations=3 (will be over 2/2 — v2 demonstrated incomplete)
   - `plugin-registry-routing` count=1, iterations=1 (under gate)
2. Set verdicts on shipped queue docs:
   - `modal-stacking.md` — already has verdict, do NOT re-evaluate (skill rule).
   - `dirty-state-tracker.md` — already has v1 verdict; **v2 verdict must be appended this iteration** as `verdict_v2: incomplete` with this iteration's evidence. (Schema extension; flag for skill maintainer if the "verdict is set once" rule needs amending for multi-attempt refactors.)
   - `trade-ticket-state-sync.md` (new this iteration) — status: ready, no verdict yet (set by a future iteration).
3. Phase 6 report MUST list:
   - "Refactor outcomes: dirty-state-tracker.md v2: incomplete — Plugins-tab recurrence after v2 ship in `ed15c6c`."
   - "Systemic candidates: dashboard-state-sync (count=7, iterations=4), dirty-state-tracker (count=3, iterations=3)."
