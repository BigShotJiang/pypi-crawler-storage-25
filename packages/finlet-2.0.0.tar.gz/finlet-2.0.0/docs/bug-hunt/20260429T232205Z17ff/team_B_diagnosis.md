# Team B — Dirty-State Tracker / Plugins-Tab Cold-Load Diagnosis

> Iteration: `20260429T232205Z17ff`
> Branch: `bug-hunt/20260429T232205Z17ff/team-B-dirty-state-plugins`
> Date: 2026-04-29

## Verdict

**No code fix shipped.** v2 of the dirty-state-tracker (Team A merge `ed15c6c`,
2026-04-29 15:50) ALREADY covers the Plugins-tab cold-load on `main`. The blind
agent's report described the v1 production behavior — it was running against
`https://finlet.dev` BEFORE production was redeployed with v2. The bug is a
**deploy-lag artifact**, not a residual code defect.

Per the plan's stop-condition:
> If you discover the v2 refactor IS covering Plugins correctly and the bug is
> a different shape (e.g., the banner is firing for a separate non-dirty-tracker
> reason), STOP, write a one-page diagnosis... and do not push a wrong fix.

Following that instruction. The single change shipped is a strengthened
regression test that asserts no banner-flash on direct-hash navigation.

## Evidence

### 1. Production (v1) — has the bug

`curl https://finlet.dev/settings.js` returned the v1 implementation:
- `let _profileLoaded, _notificationsLoaded, _appearanceLoaded;` — only THREE
  named loader globals, hand-maintained.
- The DOMContentLoaded gate awaits exactly those three:
  ```js
  await Promise.allSettled([_profileLoaded, _notificationsLoaded, _appearanceLoaded]);
  initFormTracking();
  ```
- `loadPlugins()`, `loadMfaStatus()`, `loadApiKeys()` all run in parallel but
  their promises are NOT in the gate. If the network response for
  `/plugins/health` resolves AFTER `initFormTracking()`'s rAF re-snapshot,
  any tracked field on the page that the loader writes (or any side effect
  of the innerHTML render that triggers a `change` on a tracked field) will
  flip dirty-state on, and the banner appears.
- The blind agent (https://finlet.dev/settings.html#plugins, 2026-04-29) saw
  exactly that shape: "Navigating to Settings > Plugins... triggers the orange
  'You have unsaved changes' bar."

### 2. Worktree (v2 / `main` HEAD) — bug is gone

Live verification on a local server running the worktree code (commit
`56eb8d2`, includes Team A's v2 merge `ed15c6c`):

```
GET /settings.html#plugins → wait 2s
{
  bannerVisible: false,
  dirtyFields: [],
  loaderUpdating: false,
  registryLen: 6
}
```

The v2 self-enumerating loader registry catches `loadPlugins()` via the
`registerLoader(loadPlugins())` call at `dashboard/settings.js:946`. The
gate's drain loop (`form-dirty-tracker.js:273-278`) re-reads the registry
until it stops growing, so `_loaderUpdating` stays true until the plugins
loader (and every other registered loader) settles. After settle the rAF
re-snapshot at `:284` plus `_attachListeners()` + `snapshotAllTracked()` at
`:288-289` re-baseline against the post-render DOM. Banner stays hidden.

### 3. Why the dynamic Plugins toggle/password inputs are NOT a separate failure mode

The plan's hypothesis was that dynamically-rendered Plugins-tab inputs
(toggle-switch, api-key password) trigger false-positive dirty events. They
do NOT, because:

- The inputs in `loadPlugins()`'s render at `dashboard/settings.js:986-1000`
  have NO `id` attribute (they use `data-action` / `data-plugin-name` /
  `data-plugin-key` instead).
- `_isTrackedElement()` at `form-dirty-tracker.js:60-64` rejects elements
  without `el.id`.
- `_attachListeners()` at `:109-125` therefore never binds an `input`/`change`
  listener to those nodes, so no event path can call `_markDirty` for them.
- `snapshotAllTracked()` at `:156-168` ALSO skips no-id elements, so they
  never enter `originalValues` either.

So the dynamic Plugins inputs are completely outside the dirty-state graph
by design. (A consequence: editing the api-key password field does NOT
surface the unsaved-changes banner — each plugin card has its own per-card
"Save" button, intentionally independent.)

The plan's hypothesis ("synthetic toggle change event before _loaderUpdating
release") is unreachable in the v2 code path: there is no listener to fire
the synthetic event INTO, regardless of `_loaderUpdating` state.

### 4. Manual reproduction of the user's "click toggle / type api-key / discard"
flow on the worktree

- Click first plugin toggle → `dirtyFields: []`, banner hidden. Toggle state
  changes, `togglePlugin()` fires the API call directly. Correct.
- Type into first plugin password input → dispatch `input`+`change` →
  `dirtyFields: []`, banner hidden. Correct (per design — see above).
- Re-navigate to Plugins tab → banner stays hidden.

No path under v2 produces the false-positive banner the blind agent saw.

## Action Item — outside Team B's scope

This iteration's bug closes when the v2 code is deployed to
`https://finlet.dev`. Recommend Team D add a one-line note to
`docs/LESSONS.md` under the "deploy lag" or "production-vs-main" lesson
(or mint one) noting:

> Bug-hunt blind agents always run against production, not main. When a
> finding's root cause has already shipped to main between iterations, the
> diagnosis MUST verify the bug shape against `main` HEAD before scoping a
> code fix. A real-broken finding that disappears on `main` is a deploy
> queue artifact, not a code bug.

## Single change shipped this branch

- `tests/e2e/journey-06-settings.spec.ts` — added one new test
  `Plugins tab direct-hash cold-load never flashes unsaved-changes banner`
  that:
  1. Navigates directly to `/settings.html#plugins` (no nav-click race).
  2. Samples the banner class every animation frame for 1s.
  3. Fails if the banner ever flashes the `--visible` modifier.
  4. Asserts post-settle banner-hidden + `dirtyFields.size === 0`.

  This is the no-flash analog of the existing single-sample
  `Plugins tab does not show unsaved-changes banner on cold load`
  test. Together they cover both nav-click and direct-hash entry shapes,
  matching the blind agent's reported reproduction path.

## Validation

- `npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-06-settings.spec.ts`
  → 21 passed, 1 pre-existing known-failure (`settings API key create and
  revoke flow`, documented in `docs/KNOWN_FAILURES.md` since 2026-04-29
  pre-flight). New `Plugins tab direct-hash cold-load` test passes in 2.0s.
- `bash scripts/lint-trusted-types.sh` → clean (0 bare innerHTML sites).
- Profile tab cold-load (existing `Profile tab does not show unsaved-changes
  banner on cold load` + the no-flash variant) still pass — no regression.

## Branch + commit

Branch: `bug-hunt/20260429T232205Z17ff/team-B-dirty-state-plugins`
Files touched:
- `tests/e2e/journey-06-settings.spec.ts` — +47 lines (one new test).
- `docs/bug-hunt/20260429T232205Z17ff/team_B_diagnosis.md` — this file.

`dashboard/settings.js` and `dashboard/form-dirty-tracker.js` are deliberately
unchanged. Pushing a code fix on top of a working v2 implementation would
be the "wrong fix" the plan's stop-condition warns against.
