# Bug-Hunt Iteration 20260504T165106Z1ab2 — Execution Plan

> Generated from `docs/bug-hunt/20260504T165106Z1ab2/triage.md` (with recon corrections).
> Last updated: 2026-05-04

## Constraints

- Two real-broken root causes after recon (down from 5 — Surfaces 3 and 4 were triage misclassifications, see `triage.md` § "Recon Correction").
- No file overlap between Team A and Team B → parallel work OK.
- Per-iteration ledger maintenance (Team E) and docs (Team D) are mandatory (skill-required).
- Cleanup MUST run after every test that creates server-side state — the test user has a 1-session-concurrent quota and a small daily cap.
- All team commits MUST be on `main` before Phase 5.5 deploy poll begins.
- Per CLAUDE.md and `.claude/rules/file-ownership.md`:
  - `finlet/api/`, `finlet/cli.py`, `tests/api/`, `tests/test_cli.py` → api team
  - `finlet/leaderboard/`, `tests/leaderboard/` → leaderboard team
  - `dashboard/` → dashboard team
  - `docs/` → docs team
  - These ownership rules are enforced via `.claude/rules/`; Team A spans leaderboard+dashboard, which is acceptable per the established pattern of cross-cutting bug-hunt teams.

## File Conflict Table

| File | Team(s) | Notes |
|------|---------|-------|
| `finlet/api/schemas/leaderboard.py` | A | extend `LeaderboardEntry` |
| `finlet/api/routes_leaderboard.py` | A | enrich `get_leaderboard()` response |
| `dashboard/leaderboard.js` | A | render new fields |
| `dashboard/leaderboard.html` | A | column structure if needed |
| `tests/leaderboard/test_leaderboard_api.py` | A | regression test |
| `finlet/leaderboard/scoring.py` | A (read) | reference only |
| `finlet/api/routes_session.py` | B | reorder idempotency vs rate-limit |
| `finlet/api/rate_limit/session.py` | B | defer counter increment |
| `tests/api/test_sessions.py` (or sibling) | B | regression test |
| `tests/test_cli.py` | B | timeout/idempotency replay test |
| `finlet/cli.py` | B (read; modify only if needed) | reference only — actual fix is server-side |
| `docs/bug-hunt/ledger.jsonl` | E | append per-finding row |
| `docs/bug-hunt/pending_recurrences.jsonl` | E | prune resolved entries |
| `docs/bug-hunt/pending_recurrences.resolved.jsonl` | E (new file if any pruning) | audit log |
| `docs/REMAINING_TASKS.md` | D | close items |
| `docs/LESSONS.md` | D | append lessons |
| `docs/ARCHITECTURE.md` | D | update if applicable |
| `docs/KNOWN_FAILURES.md` | D | refresh |
| `docs/decisions/*.md` | D | only if non-trivial decision made |
| `docs/bug-hunt/20260504T165106Z1ab2/*` | D | stage all artifacts |

**No file overlap between Team A and Team B.** Teams D and E write to disjoint files inside `docs/bug-hunt/`, but D depends on E (D stages E's output as part of "all artifacts").

## Dependency Graph

- **Team A** (leaderboard) — independent, can start immediately
- **Team B** (CLI session create) — independent, can start immediately
- **Team E** (ledger + pending_recurrences) — blocked by A and B (needs their merge SHAs for `commit` field)
- **Team D** (docs) — blocked by E (must stage E's files in same commit)

## Critical Path

```
max(Team A, Team B) → Team E → Team D
```

Three-step minimum chain.

---

## Teams

### Team A: Leaderboard component metrics

**Blocked by:** none — can start immediately.

**Read these files first:**
- `finlet/api/schemas/leaderboard.py:1-100` — current `LeaderboardEntry` schema (line 10-19) and `ProfileResponse` schema (line 86-99). The fix extends `LeaderboardEntry` toward `ProfileResponse` parity, but only the fields users need on the table (per_scenario_scores, sharpe_ratio, total_return_pct, max_drawdown_pct).
- `finlet/api/routes_leaderboard.py:40-60` — `get_leaderboard()` calls `LeaderboardEntry(**p.to_summary())` at line 49. Inspect `AgentProfile.to_summary()` to see what's currently returned and what needs to be added.
- `finlet/leaderboard/scoring.py:110-140` — `compute_composite_score()` weights Sharpe (0.30), return (0.25), drawdown (0.25), consistency (0.20). Confirms component values are computed; bug is they don't reach the API response. **Do NOT change scoring weights** — they're a v1 contract; only expose the supporting metrics.
- `dashboard/leaderboard.js:180-220` — `renderRow()` uses `entry.scenario_scores?.length` (line 195) for sparkline; `'--'` is the fallback at line 196. After the schema enrichment, `renderRow()` must consume the new fields and render Sharpe / return / drawdown numbers in the SCENARIOS/TRADES/WIN_RATE columns (or rename those columns if the original semantics don't fit — preserve column count).
- `dashboard/leaderboard.html` — current column headers. May need column rename/reorder to match the schema extensions.
- `tests/leaderboard/` — find or grep for any test asserting `/v1/leaderboard` response shape. Existing test will need updating; add a new assertion that all 5 component fields are present and non-default for at least one populated entry.

**Files touched:**
- Modified: `finlet/api/schemas/leaderboard.py` — add fields `per_scenario_scores: list[dict] | None`, `sharpe_ratio: float | None`, `total_return_pct: float | None`, `max_drawdown_pct: float | None` to `LeaderboardEntry` (or whatever names align with the existing `ProfileResponse`). Default to `None` so seeded fixtures without component data still serialize.
- Modified: `finlet/api/routes_leaderboard.py` — extend the `LeaderboardEntry(**p.to_summary())` path so component metrics are populated. Either (a) extend `to_summary()` in `finlet/leaderboard/profile.py` (or wherever it's defined) to include the new fields, or (b) build `LeaderboardEntry` from `p.to_full()` / `to_profile()` and project down. Pick whichever has the smaller blast radius.
- Modified: `dashboard/leaderboard.js` — read `entry.sharpe_ratio` / `total_return_pct` / `max_drawdown_pct`; render formatted numbers (e.g., `1.42`, `+12.4%`, `-8.1%`) instead of `'--'` when populated. Keep `'--'` as the fallback for seeded entries without metrics.
- Modified: `dashboard/leaderboard.html` — if columns are misnamed for the new data, rename. If the existing SCENARIOS / TRADES / WIN_RATE labels don't fit Sharpe/return/drawdown, rename to `SHARPE / RETURN / DRAWDOWN` to match landing-page promise.
- Modified or New: `tests/leaderboard/test_leaderboard_api.py` — assert that the API response for a populated leaderboard includes `sharpe_ratio`, `total_return_pct`, `max_drawdown_pct` as numbers (not None) for entries that have run scenarios. Use existing fixture pattern.

**Deliverable:** `GET /v1/leaderboard` returns Sharpe/return/drawdown for entries with run scenarios; the leaderboard page renders those numbers in the corresponding columns instead of `'--'`.

**Validation:**
- [ ] `uv run pytest tests/leaderboard/ -x -q` — all green, including the new schema assertion
- [ ] `uv run ruff check finlet/api/schemas/leaderboard.py finlet/api/routes_leaderboard.py` — clean
- [ ] `uv run mypy finlet/api/schemas/leaderboard.py finlet/api/routes_leaderboard.py` — clean
- [ ] Manual: `curl -fsS https://finlet.dev/v1/leaderboard | jq '.entries[0] | keys'` (after deploy) — must include `sharpe_ratio`, `total_return_pct`, `max_drawdown_pct`. (This is implicitly the Phase 5.5 retest for retest envelope `kind=curl` finding #1.)
- [ ] Manual: open `https://finlet.dev/leaderboard.html` (after deploy) and confirm at least one row renders numeric values (not `'--'`) in the renamed/repurposed columns. (Phase 5.5 retest for `kind=playwright` finding #5.)

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Push your branch.
- The composite-score weights are a v1 contract — do NOT modify `compute_composite_score()`. Only expose the inputs.
- Schema additions MUST default to `None` / optional so existing fixtures with bare entries (e.g., the seeded "model_used: ''" row the blind agent saw) don't break serialization.
- Frontend renderer MUST handle `null` values gracefully — preserve the `'--'` fallback path for entries without component data; only render numbers when fields are populated.
- If you rename columns in `leaderboard.html`, update any test selectors in `tests/e2e/journey-*-leaderboard*.spec.ts` (grep first; may not exist).
- Cross-cutting team — touches both `finlet/leaderboard/` and `dashboard/`. The leaderboard ownership rule covers backend; dashboard rule covers frontend; this is an accepted pattern for bug-hunt cross-cutting fixes.

---

### Team B: CLI session create — idempotency before rate limit

**Blocked by:** none — can start immediately.

**Read these files first:**
- `finlet/api/routes_session.py:80-150` — current order is rate-limit-check (line 124: `check_session_creation(user)`) BEFORE idempotency cache lookup (line 112-121). On retry with the same Idempotency-Key, `check_session_creation` raises 429 because counters were already incremented by the first attempt — the cached response is never read.
- `finlet/api/rate_limit/session.py:26-77` — `check_session_creation()` increments `user.sessions_today` (line 59) at check time, BEFORE the actual session row is created. If the request times out mid-flight, the counter stays incremented for nothing.
- `finlet/cli.py:90-160` — CLI generates `idempotency_key` (line 104), sets `timeout=60` (line 114), retries on `httpx.ReadTimeout` (line 120-150) with the same key. Works if and only if the server treats a same-key replay as "return cached response without re-checking quota" — which currently it doesn't.
- `finlet/api/main.py` — middleware stack order. Confirm rate-limit middleware (if any) does not double-count alongside the route-level `check_session_creation`.
- Recent git log for `routes_session.py`: `git log -10 --oneline finlet/api/routes_session.py` — confirm prior `1616ade` (or whichever) commit's intent and what it actually changed.

**Files touched:**
- Modified: `finlet/api/routes_session.py` — reorder so idempotency cache lookup runs FIRST (before `check_session_creation`). On cache hit, return the stored response immediately without invoking the rate-limit check. Cache miss falls through to existing flow (rate-limit → create session → store result keyed by idempotency_key).
- Modified: `finlet/api/rate_limit/session.py` — defer `user.sessions_today += 1` until AFTER session insert succeeds. Wrap as a transactional update: check current count → if under limit, proceed; only increment after the new session row is committed. This prevents stranded counter increments when a request fails mid-flight.
- Modified: `tests/api/test_sessions.py` (or whichever file covers POST /v1/sessions; grep first) — add two regression tests:
  1. Same Idempotency-Key replayed within TTL after a successful first call returns the cached response without consuming a second quota slot.
  2. A timed-out first call that did NOT create a session does NOT increment the daily counter (re-fetch the user; counter unchanged).
- Modified: `tests/test_cli.py` — add or extend a test that mocks `httpx.ReadTimeout` on first POST and verifies the retry succeeds (no 429), provided the first POST didn't actually hit the server. Use `respx` or `httpx-mock` (whichever the existing tests use; check first).

**Deliverable:** `finlet session create` survives a transient ReadTimeout retry without hitting 429; daily session counter does not increment for failed/timed-out attempts; same Idempotency-Key replay returns the cached response on the happy path.

**Validation:**
- [ ] `uv run pytest tests/api/test_sessions.py tests/test_cli.py -x -q` — all green, including new regressions
- [ ] `uv run ruff check finlet/api/routes_session.py finlet/api/rate_limit/session.py` — clean
- [ ] `uv run mypy finlet/api/routes_session.py finlet/api/rate_limit/session.py` — clean
- [ ] Manual smoke (after deploy, with cleanup before AND after to avoid leaking counter state):
  ```bash
  set -a; . ~/.bug-hunt-loop/secrets.env; set +a
  # Cleanup any leaked sessions first
  curl -fsS -H "Authorization: Bearer $FINLET_TEST_USER_API_KEY" https://finlet.dev/v1/sessions | jq -r '.[].session_id' | while read s; do curl -fsS -X DELETE -H "Authorization: Bearer $FINLET_TEST_USER_API_KEY" "https://finlet.dev/v1/sessions/$s" >/dev/null; done
  finlet --api-url https://finlet.dev session create --name retest-$(date +%s) --start 2024-01-02 --capital 100000 --universe AAPL,MSFT
  # Confirm exit 0; clean up the new session
  ```
  This matches the Phase 5.5 retest envelope `kind=cli-shell` for the CLI bug.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Push your branch.
- The fix is server-side. Do NOT change the CLI's timeout (60s is fine) or its retry-with-same-Idempotency-Key behavior — those are correct; the server is wrong.
- Idempotency cache TTL: read whatever the existing `idempotency_store.set(...)` call uses; do not change it.
- Tests MUST use mocks/fixtures for `httpx.ReadTimeout` simulation — no real network in unit tests.
- If `check_session_creation()` increments counters in the same DB transaction as session insert, decoupling may require a small refactor — keep it surgical, do not introduce a saga / unit-of-work pattern. The desired end state is "increment after commit, not at check time."
- Watch for race conditions: two concurrent POSTs from the same user can both pass the pre-creation check and both succeed → counter goes to N+2 when limit was N+1. If you see this risk, add a SELECT FOR UPDATE or a unique-constraint guard; document the choice in a one-line comment on the increment site.

---

### Team E: Ledger + pending_recurrences maintenance

**Blocked by:** Teams A and B (needs their merge SHAs).

**Read these files first:**
- `docs/bug-hunt/ledger.jsonl` — schema is one JSON object per line: `{"iteration_ts","finding_id","category","summary","scope_files","team","commit"}`. Last 10 lines for style reference.
- `docs/bug-hunt/pending_recurrences.jsonl` — current entry: hand-written carryover from prior iteration (Team C, password-form-aria delete-account-form residual). Schema is non-standard (`iteration`, `team`, `bug`, `reason`).
- `docs/bug-hunt/20260504T165106Z1ab2/triage.json` — read `.items[]` filtered by `classification == "real-broken"` for finding metadata (category, summary, scope_hint). 3 items map to 2 unique root causes.

**Files touched:**
- Modified: `docs/bug-hunt/ledger.jsonl` — append exactly **3 lines** (one per real-broken finding closed this iteration):

  Line 1 (Team A — leaderboard composite_score placeholder, finding 1 in triage):
  ```
  {"iteration_ts":"20260504T165106Z1ab2","finding_id":"leaderboard-component-metrics-missing","category":"leaderboard-placeholder-data","summary":"<60-80 char summary>","scope_files":["finlet/api/schemas/leaderboard.py","finlet/api/routes_leaderboard.py","dashboard/leaderboard.js","dashboard/leaderboard.html"],"team":"A","commit":"<Team A merge SHA>"}
  ```

  Line 2 (Team B — CLI session create rate-limit-before-idempotency):
  ```
  {"iteration_ts":"20260504T165106Z1ab2","finding_id":"cli-session-create-rate-limit-before-idempotency","category":"cli-server-state-mismatch","summary":"<60-80 char summary>","scope_files":["finlet/api/routes_session.py","finlet/api/rate_limit/session.py"],"team":"B","commit":"<Team B merge SHA>"}
  ```

  Line 3 (Team A — leaderboard UI '--' columns, finding 5 in triage; same root cause as line 1 but separate finding_id for ledger granularity since the user-visible symptom differs):
  ```
  {"iteration_ts":"20260504T165106Z1ab2","finding_id":"leaderboard-ui-component-columns-dashes","category":"leaderboard-placeholder-data","summary":"<60-80 char summary>","scope_files":["dashboard/leaderboard.js","dashboard/leaderboard.html"],"team":"A","commit":"<Team A merge SHA>"}
  ```

  Resolve `<Team A merge SHA>` and `<Team B merge SHA>` via `git log --oneline -20 main` — find the merge commits for each team's worktree.

- Modified: `docs/bug-hunt/pending_recurrences.jsonl` — evaluate the existing entry. The blind walk THIS iteration did NOT report password-form-aria warnings. Two interpretations:
  - **(a) The residual was not surfaced** because the blind agent didn't open delete-account-form (a hidden modal triggered by an explicit user action). Evidence absence ≠ evidence of fix. The entry should remain.
  - **(b) The residual is implicitly unresolvable in this iteration's scope** (no team is fixing it).
  - **Decision: leave the existing entry in place** for now. The next iteration's blind walk should include opening Settings > Account > Delete-Account before judging. Add a one-line comment in the team_e_verify.md explaining the keep decision.
- New (if any verdicts pruned): `docs/bug-hunt/pending_recurrences.resolved.jsonl` — only if a refactor verdict pruned entries. Phase 6 of the orchestrator handles the pruning logic; if no verdicts are set this iteration, this file is not touched. Team E confirms (and reports) that no pruning was done.

**Deliverable:** `wc -l docs/bug-hunt/ledger.jsonl` grows by exactly 3; `pending_recurrences.jsonl` unchanged (carryover preserved with documented reason).

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` — was N before, is N+3 after
- [ ] `jq -c '.' < docs/bug-hunt/ledger.jsonl | tail -3` — three valid JSON lines, all with `iteration_ts == "20260504T165106Z1ab2"`
- [ ] `jq -c '.' < docs/bug-hunt/pending_recurrences.jsonl | wc -l` — equals previous count (no rows added or removed by this team; new patch-ineffective signals are appended later by the orchestrator inside Phase 5.5c, NOT by Team E)
- [ ] Each appended ledger line has a non-empty `commit` field that resolves to a real SHA on `origin/main`: `for sha in $(jq -r '.commit' < <(tail -3 docs/bug-hunt/ledger.jsonl)); do git -C /Users/justnau/finlet rev-parse --verify "$sha^{commit}" >/dev/null 2>&1 || echo "BAD SHA: $sha"; done` should print nothing.

**Agent instructions:**
- You MUST `git add docs/bug-hunt/ledger.jsonl` + `git commit` before finishing. Push your branch.
- DO NOT touch any other files. Your blast radius is the JSONL ledger and the resolved-audit log only.
- Schema validation: run `python3 -c "import json; [json.loads(l) for l in open('docs/bug-hunt/ledger.jsonl')]"` — must succeed (no trailing comma, no unicode mishaps).
- Write a short `team_e_verify.md` documenting:
  1. The 3 lines you appended (with finding_id + commit SHA)
  2. The decision to keep the existing pending_recurrences entry (with reason)
  3. Whether any refactor verdicts pruned entries (likely none this iteration)

---

### Team D: Documentation

**Blocked by:** Team E (must stage E's modified ledger + pending_recurrences file).

**Read these files first:**
- `docs/REMAINING_TASKS.md` — find a "Bug Hunt — Open" or similar section. Mirror prior iterations' "Bug Hunt {prev_ts} — Closed" pattern.
- `docs/LESSONS.md` — last 30 lines for style. Each lesson is a reusable rule, not a recap.
- `docs/ARCHITECTURE.md` — check if Team A's leaderboard schema additions or Team B's idempotency-before-rate-limit reorder are architecturally noteworthy. Schema additions are usually NOT (they're additive); reorder of authorization-vs-idempotency in a route IS (it's a contract semantic). Update only if so.
- `docs/KNOWN_FAILURES.md` — confirm pre-existing entries; if any reference issues now resolved by this iteration, remove them.
- `docs/decisions/` — last 5 files for tone. Add a new decision record only if a non-trivial reversible choice was made — likely candidates this iteration:
  - "Leaderboard schema exposes Sharpe/return/drawdown" → schema decision (yes, document — it's a public contract change).
  - "Idempotency cache lookup must precede rate-limit enforcement" → architectural decision (yes, document).

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — close this iteration's items; add a "Bug Hunt 20260504T165106Z1ab2 — Closed" subsection.
- Modified: `docs/LESSONS.md` — append at least 2 lessons (one per real-broken root cause):
  - Lesson 1 (leaderboard): public list-API responses must include all fields the UI claims to expose; the rule of "expose what you promise" applies to landing-page copy as much as to schema.
  - Lesson 2 (CLI session create): idempotency caches MUST short-circuit BEFORE quota/rate-limit gates, otherwise replay-on-timeout is functionally broken. Sequence-of-checks matters.
  - (Optional) Lesson 3 (triage discipline): the blind agent's chronology in step 3 ("placed a trade") explained both Surface 3's cache-state divergence AND Surface 4's `order:filled` advance. Recon agents must read the blind report's `completed_steps` ordering before judging "behavior contradicts intent."
- Modified (only if applicable): `docs/ARCHITECTURE.md` — add a sentence to the session-create / idempotency section noting the new "idempotency-before-quota" invariant (if the file documents this surface).
- Modified: `docs/KNOWN_FAILURES.md` — refresh; remove any entry resolved this iteration.
- New (likely): `docs/decisions/leaderboard-schema-exposes-component-metrics.md` — 1-page decision record (context, decision, consequences, alternatives).
- New (likely): `docs/decisions/session-create-idempotency-precedes-rate-limit.md` — 1-page decision record.
- Stage all `docs/bug-hunt/20260504T165106Z1ab2/*` artifacts (plan.md, triage.md, triage.json, blind_report.json, blind_report.parsed.json, blind_result.txt, cleanup.log, isolation_warning.txt, team_*_verify.md, deploy_status.txt, retest_results.json — whichever exist at commit time).
- Stage `docs/bug-hunt/ledger.jsonl` and `docs/bug-hunt/pending_recurrences.jsonl` — i.e., Team E's deliverables (commit them in Team D's commit since E commits the file changes but D commits the bundle as part of the iteration's docs).

**Important wrinkle:** Team E commits its ledger changes in its own commit (Team E pushes its branch + merges). Team D's job is then to stage any remaining `docs/bug-hunt/$TS/` artifacts AND any `docs/decisions/` additions. The ledger itself is already committed by E — D just confirms it's staged and present on main. No double-commit.

**Deliverable:** `git status docs/` is clean (every artifact committed); `docs/REMAINING_TASKS.md` reflects this iteration's outcomes; `docs/LESSONS.md` has ≥2 new lessons; ≥1 new decision record exists.

**Validation:**
- [ ] `git status docs/bug-hunt/20260504T165106Z1ab2/` — clean (no untracked or modified)
- [ ] `git -C /Users/justnau/finlet log --oneline -3 docs/REMAINING_TASKS.md docs/LESSONS.md` — at least one Team D commit visible in the recent history
- [ ] `wc -l docs/LESSONS.md` — grew by ≥10 lines (2 lessons of ≥5 lines each)
- [ ] `ls docs/decisions/` — at least one new file dated 2026-05-04 (or recently)

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Push your branch.
- Commit message format: `docs: bug-hunt 20260504T165106Z1ab2 — record fixes for leaderboard + CLI session create; LESSONS +2; ledger committed by Team E (+3); ARCHITECTURE <touched|untouched this iteration>`.
- DO NOT amend Team E's commit — write your own commit on top.
- Lessons MUST be reusable rules, not recaps. "Always XYZ when ABC because incident DEF" is good; "We fixed the leaderboard today" is bad.
- Decision records use the existing format; copy a recent one as a template.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A schema change breaks an undiscovered consumer of `/v1/leaderboard` (CLI? MCP tool?) | Medium | Medium | Keep new fields **optional with `None` default**; existing consumers ignore unknown fields if Pydantic config allows; grep `from finlet.api.schemas.leaderboard` to find all importers and confirm. |
| Team B rate-limit reorder introduces a race (two concurrent POSTs both pass pre-creation check) | Medium | High | Document the chosen guard in a one-line comment; add a regression test for concurrent POSTs if existing test infra supports it (skip if not — note the gap). |
| Team B idempotency cache TTL races against the CLI's retry window | Low | Medium | Don't change the TTL; rely on the existing value. If the existing TTL is shorter than the CLI's max retry window, surface that as a follow-up note in `team_b_verify.md`. |
| Team A column rename breaks any Playwright test asserting `'TRADES'` or `'WIN RATE'` strings | Medium | Low | Grep `tests/e2e/` for those literals BEFORE renaming. If found, update the spec in the same commit. |
| Team E uses wrong merge SHA in the ledger | Low | Low | Validation step: every appended `commit` field MUST resolve via `git rev-parse --verify`. |
| Team D commits before Team E pushes (race) | Medium | Low | Sequencing: the orchestrator dispatches Team D ONLY after Team E's commit is on `origin/main`. Team D's verify step asserts `git ls-files docs/bug-hunt/ledger.jsonl` shows the latest hash. |
| Phase 5.5 deploy is blocked by an unrelated test regression | Medium | High (blocks retest) | Pre-merge gate on each team's `pytest` and `ruff/mypy` validation. If e2e fails post-merge, surface the failure in `deploy_status.txt`; Phase 5.5 will skip retest with `Deploy: failure` (NOT a patch-ineffective signal). |
| The pending password-form-aria carryover stays unresolved | Low | Low | Already documented in Team E's verify; the next iteration's blind walk should explicitly open delete-account-form to surface it. |

## Session Plan

### Session 1 — Parallel A + B
**Parallel:** Team A (leaderboard) + Team B (CLI session create) — no shared files.
**Merge order:** A merges first (or B — doesn't matter; whichever finishes first); each merge runs the per-team validation gate listed above; second team merges; per-team validation gate runs again.
**Session checkpoint:** `uv run pytest -x -q` (full suite) on `main` after BOTH teams have merged. Push to `origin/main` only after the full suite is green.

### Session 2 — Team E
**Sequential:** Team E (depends on A + B merge SHAs).
**Merge order:** E merges; validation gate (`wc -l ledger.jsonl == N+3`); push.

### Session 3 — Team D
**Sequential:** Team D (depends on E).
**Merge order:** D merges; validation gate (`git status docs/` clean); push.

### Phase 5.5 starts after Session 3 push
The orchestrator polls `Deploy Finlet` workflow on `origin/main` HEAD until terminal. On `success`, runs the retest agent against the 3 real-broken items' retest envelopes. On non-success, skips retest and reports the deploy outcome.

