## Broken (will be fixed this iteration)
- Leaderboard returns composite_score=0.5 for every entry; SCENARIOS/TRADES/WIN_RATE columns all show '--' on the UI [evidence: "GET /v1/leaderboard response: all 5 entries have composite_score:0.5, no individual metrics returned. Landing page advertises ranking by 'Sharpe ratio, total return, and maximum drawdown' — none visible in the UI. One entry has model_used: '' (empty string). The leaderboard scoring appears to be a placeholder default, not computed results."] [scope hint: finlet/leaderboard/, finlet/api/routes_leaderboard.py, dashboard/leaderboard.js, dashboard/leaderboard.html]
- finlet CLI session create throws httpx.ReadTimeout on first invocation, then 429 Too Many Requests on retry [evidence: "First run: httpx.ReadTimeout at httpcore/_sync/http11.py:136 after the request was sent. Second run (immediate retry): 'Client error 429 Too Many Requests for url https://finlet.dev/sessions'. Session was eventually created via the browser UI without issue. Workaround: use the browser. CLI timeout is too short and rate limit fires on the second request within seconds."] [scope hint: finlet/cli.py, finlet/api/routes_session.py]
- price plugin health message differs between Settings page and Dashboard at the same moment [evidence: "Settings page shows: 'OK — S3 reachable, price data available'. Dashboard Plugin Health panel shows: 'OK — 0 cached files'. Same plugin, same session, captured within minutes of each other. Suggests two separate health check calls return different status strings — one reports by reachability, the other by local cache count."] [scope hint: dashboard/settings.js, dashboard/app.js, finlet/api/routes_health.py, finlet/plugins/price_plugin.py]
- Getting Started checklist marks 'Run first analysis' complete without the user performing any analysis action [evidence: "After creating the session (no analysis), the checklist item 'Run first analysis' gained the class 'checklist-item--done'. The user was never prompted to run an analysis, and nothing in the UI is labeled 'analysis'. This either auto-fires on session creation/first trade, or the trigger condition is invisible to the user."] [scope hint: dashboard/onboarding.js (CHECKLIST_STEPS registry), dashboard/app.js, dashboard/event-contract.md]
- Leaderboard SCENARIOS/TRADES/WIN_RATE columns show '--' for every entry; Sharpe/return/drawdown promised on landing page are absent [evidence: "Landing page: 'Compete with other AI agents on Sharpe ratio, total return, and maximum drawdown.' The leaderboard API response contains only composite_score (0.5 for all), no Sharpe/return/drawdown fields. The UI columns for those metrics are empty. Users submitting to the leaderboard have no way to compare detailed performance."] [scope hint: finlet/leaderboard/, finlet/api/routes_leaderboard.py, dashboard/leaderboard.js, dashboard/leaderboard.html]

## Logged (not actioned)
- User menu API key label is 'Copy API Key' on dashboard but 'Manage API Key' on the settings page [classification: annoying]
- Onboarding wizard 'Continue' button is disabled with no explanation when no persona is selected [classification: annoying]
- Existing API keys are permanently masked with no reveal or copy button [classification: working-as-designed]
- 'Create New Session' dialog auto-fills 'Conservative ETF' in the name field by default [classification: annoying]
- Page title in browser tab reads 'Finlet — AI Trading Agent ITE' while landing page says 'Finlet — AI Trading Agent Backtesting Platform' [classification: annoying]
- Multiple plugins shown as degraded/unhealthy on every page load with no in-app path to fix them [classification: annoying]
- CLI returns a raw Python traceback (20+ lines) for both the ReadTimeout and 429 errors [classification: annoying]
- No 'Fundamentals' session template in the Create New Session dialog [classification: nice-to-have]
- No way to reveal or copy an existing API key — only create new ones [classification: working-as-designed]
- Plugin health panel uses internal identifiers (fundamentals_s3, news_s3, econ) not human-readable names [classification: nice-to-have]
- No session data coverage indicator when creating a session [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260504T165106Z1ab2 — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. `docs/bug-hunt/20260504T165106Z1ab2/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log,
   deploy_status.txt, retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260504T165106Z1ab2","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline (see
   Phase 5.5c). Team D MUST stage the file. If a refactor verdict pruned entries
   this iteration, Team D MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`
   (the audit log of resolved signals).

Team D's commit message must reference iteration 20260504T165106Z1ab2 and name which docs were
touched (e.g., "docs: bug-hunt 20260504T165106Z1ab2 — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").

## Recon Correction — 2026-05-04

After /plan-features recon, two real-broken classifications flipped to working-as-designed:

- **Surface 3 (plugin-health-divergence Settings vs Dashboard)** → working-as-designed.
  `PricePlugin._probe()` has two intentional HEALTHY messages:
  - Fast path (`finlet/plugins/price_plugin.py:853`): `"OK — {len(cached_files)} cached files"` when cache dir has parquet files.
  - Cold-start (`finlet/plugins/price_plugin.py:907`): `"OK — S3 reachable, price data available"` when cache dir empty + S3 reachable.
  Both surfaces (`dashboard/settings.js:1020`, `dashboard/app.js:1819`) hit the canonical `/v1/plugins/health` endpoint and render `health.message` verbatim. Blind agent placed a trade between visiting Settings and Dashboard, populating the cache; the divergence is the cache-state difference, not a contract drift.

- **Surface 4 (checklist 'Run first analysis' auto-completes)** → working-as-designed.
  CHECKLIST_STEPS entry at `dashboard/onboarding.js:50-54` has `trigger: 'order:filled'`, NOT `session:created`. The bus publisher at `dashboard/app.js:1541-1568` only fires `order:filled` on a real SSE `orders` event with a 0-to-≥1 filled-count transition. Blind agent's report ordered events as "create session → checklist marked done" but actually placed a trade in between (their step 3); the trade filled, fired `order:filled`, advanced the step. Trigger wiring is correct.
  (The label "Run first analysis" IS misleading copy — placing+filling a trade is not "analysis" — but copy ≠ broken predicate. Logged as annoying-class for a future iteration.)

Effective broken count: **2** (down from 5). Two distinct root causes:
1. **Leaderboard placeholder data** — covers original triage items #1 and #5 (same root cause: LeaderboardEntry schema strips per-scenario component metrics from the response).
2. **CLI session create rate-limit-before-idempotency** — original triage item #2 (idempotency cache lookup happens AFTER `check_session_creation()` rate-limit check, so retries hit 429 even with replay headers).

Plan teams accordingly; Surfaces 3 and 4 do NOT get fix teams this iteration.

## Recon Correction #2 — Team B aborted mid-execution (2026-05-04)

Team B stalled at 10min watchdog. The agent's stalled-output transcript revealed the plan's premise was based on a misreading of `finlet/api/routes_session.py`:

- **Plan claimed** (verbatim): "current order is rate-limit-check (line 124: `check_session_creation(user)`) BEFORE idempotency cache lookup (line 112-121)"
- **Actual code state** (re-verified post-stall):
  - Lines 112-121: idempotency cache lookup (`_idempotency_store.get(...)` → return cached if hit)
  - Line 124: `check_session_creation(user)` — runs only if cache miss
  - Line 162: `record_session_created(user)` — counter increment AFTER `create_session()` succeeds
  
  The order is already idempotency-first, increment-after-commit. The plan's "fix" would re-implement the existing code.

- **What the blind agent's 429 actually was:** correct concurrent-session-limit enforcement after the first slow CLI invocation succeeded server-side. The CLI generates a fresh `Idempotency-Key` per invocation (cli.py:104 — `uuid.uuid4()`); the second invocation sends a NEW key, bypassing the cache, hitting the limit because the user already has 1 active session. WAI.

- **Real bug shape (different from plan):** plugin init on cold-start can exceed the 60s client timeout, causing the CLI to report ReadTimeout while the server eventually creates the session. The CLI's name-based GET fallback (cli.py:134-144) does exist but apparently didn't recover the session in the blind agent's flow. This is a CLI-UX/ResponseRecovery bug, not a route-ordering bug. Needs fresh recon next iteration.

→ **Demoting CLI session create finding to `needs-investigation` for next iteration.** Triage misread; not actionable as scoped this iteration.

→ **Effective broken count: 1** (down from 3 — leaderboard placeholder data only).

→ **Plan adjustment:**
- Drop Team B for this iteration.
- Team A re-spawned with same scope (leaderboard fix unaffected).
- Team E's scope reduces from 3 ledger entries to 2 (both for leaderboard, same root cause but separate finding_ids per plan).
- Team D's lessons gain a new entry: "Plan recon must verify the broken predicate against current code, not the blind agent's assumed root cause. Spec the fix scope from observed behavior + verified code state, not from the blind report alone."
