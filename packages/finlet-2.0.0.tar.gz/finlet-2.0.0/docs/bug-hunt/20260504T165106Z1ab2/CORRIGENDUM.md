# Corrigendum — bug-hunt 20260504T165106Z1ab2

**Written 2026-05-05** in a follow-up session, after independent verification of the iteration's handoff and a journey-16 root-cause investigation.

## What the handoff got wrong

The handoff (`handoff.md`) and Phase 5.5 docs treated the Deploy Finlet failure on `214546c` (run 25341303587, journey-16-benchmark-blindness:49) as **unrelated to iteration scope**, with Hypothesis B (flake) rated "most likely."

Independent verification disproved both the "unrelated" and "flake" attributions:

1. **Three consecutive deploys failed deterministically** with the identical `bull_run` leak error on `214546c`, `40f5253`, and `8120ff4`. The latter two are docs-only commits; a flake would not have been deterministic across three pushes that don't touch any code path the test exercises.

2. **The leak was introduced by this iteration's own commit `af12d9f`** (Team A leaderboard fix). The change added:

   ```python
   per_scenario_scores: list[dict] | None = [s.model_dump() for s in scenarios]
   ```

   to `AgentProfile.to_summary()` in `finlet/leaderboard/profiles.py`. `model_dump()` exposed raw `ScenarioScore.scenario_id` ("bull_run", "covid_crash", etc.) through `GET /v1/leaderboard`, which is precisely the surface `journey-16-benchmark-blindness:49` asserts on. Same root cause for `to_detail()` at line 100.

3. **The narrative "iteration scope was leaderboard + ledger + docs. Zero changes touched `finlet/benchmark/`"** was technically true about file paths but misleading about behavior — the leaderboard schema expansion crossed the benchmark-blindness invariant boundary even though the directory tree didn't change.

## What was done in the follow-up

Five branches landed in sequence on `main` after the iteration closed:

| SHA | Subject |
|-----|---------|
| `5972ecf` | `fix(leaderboard): redact scenario_id from /leaderboard responses (journey-16)` — `_blind_scenario_dump(score, idx)` helper substitutes opaque `scenario_<N>` for `scenario_id` in `to_summary()` and `to_detail()` payloads. Internal `ScenarioScore.scenario_id` retained for scoring/runner code. 5 regression tests added (model + HTTP boundary). |
| `455717d` | `fix(leaderboard): redact /benchmarks endpoint (security invariant)` — companion fix for the secondary leak. `GET /v1/leaderboard/benchmarks` was returning `BenchmarkScenarioInfo.id`/`.name`/`.description` with raw values; redacted at serialization. New `TestLeaderboardBenchmarkBlindness::test_benchmarks_endpoint_redacts_scenario_names`. |
| `70c9a2f` | `chore(ci): expand pre-push e2e smoke to journeys 06/07/16` — addresses the pattern where 3 consecutive iterations have had a regression slip past the pre-push smoke into the GH-Actions deploy gate. |
| `98bfb09` | `chore(skill: plan-features): require recon-verified line-claims (PF-16)` — adds PF-18 to the plan-features skill: "current state X at file:line" claims must be backed by a quoted excerpt or a recon-paraphrase tagged with the iteration baseline SHA. |
| `docs/bug-hunt/cli-session-429-trace.md` | Recon doc for the deferred Surface 2 (CLI session-create idempotency). Identifies the real race window in `routes_session.py:127-167` (record_session_created mutates active_sessions BEFORE `_idempotency_store.store(...)`) — distinct from the plan's claimed root cause. |

## Lessons (added to memory)

- **`feedback_handoff_unrelated_attribution.md`** — when a handoff claims a deploy-blocking e2e failure is "unrelated to iteration scope," verify against the iteration's API surface changes before accepting. The directory tree is not a sufficient predicate.
- **`feedback_e2e_smoke_too_narrow.md`** — marked RESOLVED 2026-05-05 with the smoke expansion to 6 journeys.

## Live status (at time of writing)

- `origin/main` HEAD: `b7598f1`
- Deploy 25355121561 (on `a41027d`, journey-16 fix only) — `in_progress` at the time of the follow-up push
- Deploy on `b7598f1` (full 4-objective set) — queued/running

The leaderboard fix on finlet.dev will land with whichever deploy finishes successfully first; the smoke now includes journey-16 so a similar regression in a future iteration would be caught pre-push.
