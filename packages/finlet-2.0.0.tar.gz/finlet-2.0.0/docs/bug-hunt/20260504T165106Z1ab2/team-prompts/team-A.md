You are **Team A: Leaderboard component metrics** for bug-hunt iteration `20260504T165106Z1ab2`.

**RESPAWN CONTEXT:** Prior Team A spawn stalled at 10min stream-watchdog timeout with partial uncommitted work (modified `finlet/api/schemas/leaderboard.py` only, no commit, no other files touched). That worktree was cleaned up. You start fresh from `spawn_base_sha=17f1f2db7156c2e781629f78e823444f59bfefc9`. Bake the prior agent's discovered findings (below) into your work; don't rediscover.

**Worktree-rules block:**
- Your worktree is provided by the orchestrator. ALL file edits MUST be in that worktree path. NEVER write to `/Users/justnau/finlet/` directly.
- Verify CWD before writes: `pwd` should show a path under `.claude/worktrees/`.
- For git ops in your worktree, use `git -C <your-worktree-path> ...`.
- The orchestrator resets your worktree to `spawn_base_sha=17f1f2db7156c2e781629f78e823444f59bfefc9` immediately after spawn. Confirm `git rev-parse HEAD` matches that SHA before your first edit.

**Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.**

---

## Pre-discovered findings (from prior stalled agent — use, don't rediscover)

1. **Schema location**: `finlet/api/schemas/leaderboard.py:10-19` defines `LeaderboardEntry`. The `ProfileResponse` at lines 86-99 already includes `sharpe_ratio`, `total_return_pct`, `max_drawdown_pct`. Mirror those names exactly.

2. **Unit conventions** (verified by prior agent reading `tests/leaderboard/test_leaderboard.py` + `finlet/leaderboard/scoring.py`):
   - `total_return_pct` is stored as **percent**: e.g., `10.0` means 10%. Don't multiply by 100.
   - `max_drawdown` (fraction in [0,1]) is the raw scoring input. For the API field `max_drawdown_pct`, **multiply by 100**: `avg_drawdown * 100`.
   - `sharpe_ratio` is a unitless ratio (e.g., 1.42).
   - `dashboard/leaderboard.js:361` already does `${maxDrawdown.toFixed(2)}%` without multiplying by 100 in a per-scenario detail panel — that's a separate latent bug; LEAVE IT ALONE this iteration.

3. **Composite score weights** (`finlet/leaderboard/scoring.py:110-140`): Sharpe 0.30, return 0.25, drawdown reduction 0.25, consistency 0.20. **DO NOT MODIFY** — v1 contract.

4. **Approach selected by prior agent**: extend `to_summary()` in the profile module (smaller blast radius than projecting from full). Build on this.

5. **Frontend renderer**: `dashboard/leaderboard.js:180-220` — `renderRow()` at `:195` uses `entry.scenario_scores?.length` for sparkline; `'--'` fallback at `:196`. After enrichment, render Sharpe/return/drawdown numbers. Preserve `'--'` fallback for null fields.

---

## Spec

**Files touched (in this order; commit incrementally):**

1. **Schema** — `finlet/api/schemas/leaderboard.py`:
   Add to `LeaderboardEntry`:
   ```python
   sharpe_ratio: float | None = None
   total_return_pct: float | None = None
   max_drawdown_pct: float | None = None
   per_scenario_scores: list[dict] | None = None
   ```
   All default `None`. Update class docstring to note these mirror compute_composite_score inputs.

2. **Profile/route** — `finlet/api/routes_leaderboard.py` + wherever `to_summary()` lives (likely `finlet/leaderboard/profiles.py` based on the import you saw):
   Extend `to_summary()` to populate the four new fields when scenarios have run; emit `None` when none have. `max_drawdown_pct = avg_drawdown * 100` (per unit convention #2).

3. **Frontend** — `dashboard/leaderboard.js`:
   In `renderRow()`, render formatted values (`1.42`, `+12.4%`, `-8.1%`) when populated; `'--'` when null. The columns to fill: SCENARIOS, TRADES, WIN_RATE — these labels are misleading post-fix, so rename to **SHARPE, RETURN, DRAWDOWN** in the HTML (next step) and update the JS to match.

4. **HTML** — `dashboard/leaderboard.html`:
   Rename column headers SCENARIOS → SHARPE, TRADES → RETURN, WIN_RATE → DRAWDOWN. Preserve column count.

5. **Tests** — `tests/leaderboard/test_leaderboard_api.py` (or sibling — grep for the existing test of `/v1/leaderboard` shape):
   Extend or add: assert API response for a populated leaderboard entry includes `sharpe_ratio`, `total_return_pct`, `max_drawdown_pct` as numbers (not None) for entries with scenarios; assert `None` for entries without scenarios. Use existing fixture pattern.

6. **E2E selectors** — grep `tests/e2e/journey-*-leaderboard*.spec.ts`. If column names are asserted, update strings to match new headers in the same commit. (May not exist; ignore if grep is empty.)

**Validation (run BEFORE finishing):**
- `uv run pytest tests/leaderboard/ -x -q` — all green
- `uv run ruff check finlet/api/schemas/leaderboard.py finlet/api/routes_leaderboard.py finlet/leaderboard/profiles.py` — clean
- `uv run mypy finlet/api/schemas/leaderboard.py finlet/api/routes_leaderboard.py finlet/leaderboard/profiles.py` — clean

**Commit + push:**
- Single commit, message starts with `[Team A]: `
- Brief but specific (e.g., `[Team A]: Leaderboard exposes Sharpe/return/drawdown component metrics; rename UI columns`)
- `git push` your branch

---

## Anti-stall guidance (this is a respawn — work efficiently)

- Don't re-explore the codebase from scratch — the discoveries above are correct.
- Read 4 files inline at most (schema, profiles, leaderboard.js, leaderboard.html); avoid wide grep sweeps.
- If a sub-task takes >3 minutes of analysis, commit your partial work and continue — uncommitted progress is lost on watchdog timeout.

---

## When done, report (in your final message):

```
DONE
commit: <SHA>
worktree_path: <path>
files_changed: <list>
validation:
  pytest tests/leaderboard/: <pass/fail counts>
  ruff: <clean/issues>
  mypy: <clean/issues>
column_renames: <yes/no — describe>
e2e_selectors_updated: <yes/no — describe>
```

OR `BLOCKED: <reason>`.

Do NOT cleanup the worktree yourself. Commit + push + exit.
