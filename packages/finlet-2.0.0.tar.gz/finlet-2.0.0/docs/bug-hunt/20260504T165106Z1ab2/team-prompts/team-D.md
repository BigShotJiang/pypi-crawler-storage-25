You are **Team D: Documentation** for bug-hunt iteration `20260504T165106Z1ab2`.

**Worktree-rules block:**
- Your worktree is provided by the orchestrator. ALL file edits MUST be in that worktree path. NEVER write to `/Users/justnau/finlet/` directly.
- Verify CWD before writes: `pwd` should show a path under `.claude/worktrees/`.
- For git ops, use `git -C <your-worktree-path> ...`.
- The orchestrator will reset your worktree to `spawn_base_sha=babfa15afb2298649de96f2159223ae91c6358e3` (Team E merge) immediately after spawn. Confirm `git rev-parse HEAD` matches before your first edit.

**Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.**

---

## Scope adjustments vs original plan (CRITICAL — read carefully)

The plan listed two real-broken root causes (leaderboard + CLI session create) and recommended 2 decision records. Mid-execution:

1. **Team B was ABORTED.** The plan's premise (idempotency lookup runs AFTER rate-limit check; counter increments at check-time) was contradicted by current code in `finlet/api/routes_session.py`. Verified by inline read: idempotency cache lookup IS already first (lines 112-121); `record_session_created(user)` IS already after session insert (line 162). The CLI symptom (Idempotency-Key replay returning 429) is real but a different shape — likely a cold-start race in plugin init or a separate deduplication path. Demoted to `needs-investigation` for next iteration. **Do NOT write a `session-create-idempotency-precedes-rate-limit.md` decision record** — that decision is already in effect; documenting "we kept the existing behavior" would be misleading.

2. **Surfaces 3 (plugin-health-divergence) and 4 (checklist auto-complete after order:filled)** were flipped to `working-as-designed` during plan-features recon (the blind agent placed a trade BETWEEN the two settings checks → cache rebuilt; the checklist `trigger: 'order:filled'` is by design).

3. **Effective real-broken count for this iteration: 2** (both leaderboard, same root cause — schema missing component metrics + UI columns showing `--`). Ledger received 2 entries from Team E (commit `6e21f44...`, merge `babfa15...`).

---

## Inputs

- `docs/REMAINING_TASKS.md` — find the "Bug Hunt — Open" section (or similar). Mirror the prior iterations' "Bug Hunt {prev_ts} — Closed" pattern. Search for `Bug Hunt 20260503T230405Z2601` (most recent prior closed iteration) for the format.
- `docs/LESSONS.md` — last 30 lines for style. Each lesson is a reusable rule, not a recap.
- `docs/ARCHITECTURE.md` — schema additions to leaderboard are additive (NOT noteworthy). Do NOT modify unless you find an explicit "leaderboard schema" or "list-API contract" section that's now stale.
- `docs/KNOWN_FAILURES.md` — confirm pre-existing entries; remove any resolved this iteration.
- `docs/decisions/` — read the last 5 files for tone/format. Use the most recent as a template.
- `docs/bug-hunt/20260504T165106Z1ab2/triage.md` and `triage.json` — for context on what was real-broken vs demoted.
- `docs/bug-hunt/20260504T165106Z1ab2/team_e_verify.md` — Team E's verification doc (for cross-references).
- Team A merge SHA: `4b7ba2397982233cfc3dc9552302705e1167eedc`. Team A direct commit: `af12d9f9e183c47c41bec10d4b8dce7e0dc88dde`. Team E merge SHA: `babfa15afb2298649de96f2159223ae91c6358e3`.

## Files touched

### 1. `docs/REMAINING_TASKS.md` — Modified

Add a "Bug Hunt 20260504T165106Z1ab2 — Closed" subsection in the same place as prior closed iterations. Document:
- 2 real-broken findings shipped (leaderboard schema + UI columns; same root cause, separate finding_ids per granularity rule)
- 1 finding aborted (CLI session-create idempotency replay) — demoted to `needs-investigation`; reason: plan premise contradicted current code
- 2 findings flipped to working-as-designed during recon (plugin health, checklist after order:filled)
- 1 carryover preserved in pending_recurrences (password-form-aria delete-account-form residual)
- Refactor verdicts: none pruned this iteration

### 2. `docs/LESSONS.md` — Modified, append ≥2 lessons

Lessons are **reusable rules**, not recaps. Append:

**Lesson 1 — Public list-API responses must include all fields the UI claims to expose.**
- Context: leaderboard surfaced `--` columns because the API response omitted Sharpe/return/drawdown even though the landing-page copy and column headers promised them. The UI rendered the placeholder `--` fallback, masking the contract gap.
- Rule: when extending a list response, audit BOTH the schema AND every consumer that renders it. The blind agent's "expose what you promise" intuition applies to API contracts as much as marketing copy.

**Lesson 2 — Plan recon must verify the broken predicate against current code, not the blind agent's assumed root cause.**
- Context: the bug-hunt plan for surface 2 (CLI Idempotency-Key replay) named a specific server-side ordering bug (rate-limit-check before idempotency lookup; counter increment at check-time). Both premises were false in the current code. Team B stalled with no useful output; abort cost ≈ 1 worktree spawn + 10 min watchdog.
- Rule: every plan that names a code-level root cause MUST cite file:line evidence in "Read these files first" AND a one-paragraph paraphrase of what the recon agent SAW vs what the plan claims. If the paraphrase doesn't contradict working-as-designed, reroute to needs-investigation before spawning a fix team.

**Optional Lesson 3 — Blind-agent chronology is load-bearing for triage.**
- Context: the blind agent placed a trade BETWEEN visiting Settings → Plugins twice. The first visit showed cold cache (no plugins listed); the second visit showed warm cache (plugins listed). The agent reported this as "plugin health divergence." Triage initially flagged it real-broken; recon caught it as a working-as-designed cache-warmup artifact. Same iteration: the checklist auto-completed `place_first_trade` after the trade, which the agent reported as `data-step="place_first_trade"` advancing without the user clicking it — by-design behavior of the `trigger: 'order:filled'` registry.
- Rule: triage agents must read `blind_report.json#completed_steps` ordering BEFORE classifying. Two findings with different surfaces but the same chronological gap (a state-changing action between observations) are usually one root cause and usually working-as-designed.

(Lesson 3 is optional but recommended — it's the meta-lesson from this iteration's two recon corrections. If you're tight on space, prioritize Lessons 1 + 2.)

### 3. `docs/ARCHITECTURE.md` — Modified ONLY IF APPLICABLE

Schema additions to `LeaderboardEntry` are additive (`Optional[float] = None`) and don't change architectural invariants. **Default: do not modify.** Only edit if you find a section explicitly documenting "what fields the leaderboard exposes" — in which case add a one-line note that `sharpe_ratio`, `total_return_pct`, `max_drawdown_pct`, `per_scenario_scores` are now exposed for entries with completed scenarios.

If you don't modify it, mention "ARCHITECTURE.md untouched this iteration" in the commit message.

### 4. `docs/KNOWN_FAILURES.md` — Modified, refresh

Read the file. For each entry:
- If the test is now passing (i.e., bug fixed by Team A's leaderboard work), remove the entry AND remove the `@pytest.mark.xfail` marker from the test file in the same commit.
- If the test still xfails for an unrelated reason, leave it.

Quick check: `grep -l "leaderboard" docs/KNOWN_FAILURES.md` — if any entry references leaderboard tests, verify it's still failing on current main; if not, prune.

### 5. `docs/decisions/leaderboard-schema-exposes-component-metrics.md` — NEW (1 page)

Use the most recent file in `docs/decisions/` as a template. Sections:
- **Context** — why was this needed (UI rendered `--` in three columns; landing copy claimed Sharpe/return/drawdown).
- **Decision** — `LeaderboardEntry` exposes `sharpe_ratio`, `total_return_pct`, `max_drawdown_pct`, `per_scenario_scores` as `Optional[float] | Optional[list[dict]]`, all defaulting to `None` for entries with no completed scenarios. UI columns renamed SCENARIOS → SHARPE, TRADES → RETURN, WIN_RATE → DRAWDOWN.
- **Consequences** — additive change; existing consumers ignoring unknown fields are unaffected. Frontend `--` fallback preserved for `None` values. Per-scenario detail panel (`leaderboard.js:361`) has a separate latent unit bug (`max_drawdown.toFixed(2)%` without `*100`); explicitly out of scope this iteration; flagged for follow-up.
- **Alternatives considered** — (1) Project from full per-scenario scoring on every list call → rejected (performance); (2) Add a `/v1/leaderboard?expand=metrics` query flag → rejected (V1 contract complexity); (3) Mirror `ProfileResponse` field names → chosen (consistency).
- **References** — Team A direct commit `af12d9f9e183c47c41bec10d4b8dce7e0dc88dde`; merge `4b7ba2397982233cfc3dc9552302705e1167eedc`. Bug-hunt iteration `20260504T165106Z1ab2`.

**Do NOT write `session-create-idempotency-precedes-rate-limit.md`** — Team B was aborted, the decision is already in effect, and writing it would falsely imply this iteration changed behavior.

### 6. Stage `docs/bug-hunt/20260504T165106Z1ab2/*` artifacts

Run `ls docs/bug-hunt/20260504T165106Z1ab2/` to enumerate. Stage all of:
- `plan.md`, `triage.md`, `triage.json`, `triage.json.tmp` (if exists — the temp file is harmless to commit; leaving it untracked clutters `git status`)
- `blind_report.json`, `blind_report.parsed.json`, `blind_result.txt`, `cleanup.log`, `isolation_warning.txt`
- `exec-trace.txt`
- `team_e_verify.md`
- `team-prompts/team-A.md`, `team-prompts/team-B.md`, `team-prompts/team-D.md`, `team-prompts/team-E.md`

If `team_a_verify.md` was not written by Team A (Team A respawn focused on the implementation), it's acceptable to skip — note in commit message.

`docs/bug-hunt/ledger.jsonl` and `pending_recurrences.jsonl` are already committed by Team E (commit `6e21f44...`); do NOT re-stage. Confirm with `git log --oneline docs/bug-hunt/ledger.jsonl | head -2` — Team E's commit should be HEAD's parent or close.

## Validation

- [ ] `git -C <wt> status docs/` — clean (no untracked or modified) after final commit.
- [ ] `wc -l docs/LESSONS.md` — must have grown by ≥10 lines (typically 15-25 for 2-3 lessons).
- [ ] `ls docs/decisions/leaderboard-schema-exposes-component-metrics.md` — file exists.
- [ ] `git -C <wt> log --oneline -1 docs/REMAINING_TASKS.md` — your commit is HEAD.
- [ ] `cat docs/bug-hunt/ledger.jsonl | wc -l` — still 53 (Team E already committed; no double-write).
- [ ] `git -C <wt> log --oneline -2 docs/bug-hunt/ledger.jsonl` — most recent commit is Team E's, not yours.

## Commit + push

- Single commit. Message:

  `docs: bug-hunt 20260504T165106Z1ab2 — record fixes for leaderboard; LESSONS +2 (or +3); ledger committed by Team E (+2); Team B aborted (premise invalid); ARCHITECTURE <touched|untouched this iteration>`

- Pick `touched` or `untouched` based on whether you actually edited ARCHITECTURE.md.
- `git push` your branch.

---

## When done, report:

```
DONE
commit: <SHA>
worktree_path: <path>
files_changed:
  - docs/REMAINING_TASKS.md
  - docs/LESSONS.md (+N lines)
  - docs/KNOWN_FAILURES.md (refreshed | unchanged)
  - docs/ARCHITECTURE.md (touched | untouched)
  - docs/decisions/leaderboard-schema-exposes-component-metrics.md (new)
  - docs/bug-hunt/20260504T165106Z1ab2/* (staged: <list>)
lessons_appended: 2 | 3
decisions_added: 1
known_failures_pruned: <count>
```

OR `BLOCKED: <reason>`.

Do NOT cleanup the worktree yourself. Commit + push + exit.
