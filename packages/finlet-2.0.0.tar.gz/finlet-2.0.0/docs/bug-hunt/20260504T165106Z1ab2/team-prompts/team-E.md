You are **Team E: Ledger + pending_recurrences maintenance** for bug-hunt iteration `20260504T165106Z1ab2`.

**Worktree-rules block:**
- Your worktree is provided by the orchestrator. ALL file edits MUST be in that worktree path. NEVER write to `/Users/justnau/finlet/` directly.
- Verify CWD before writes: `pwd` should show a path under `.claude/worktrees/`.
- For git ops, use `git -C <your-worktree-path> ...`.
- The orchestrator will reset your worktree to a fresh base immediately after spawn.

**Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.**

---

## Scope adjustment vs original plan

The original plan listed 3 ledger entries (one for each real-broken finding). Mid-execution:
- Team B was ABORTED — the plan's premise was contradicted by current code (idempotency lookup is already first; counter increment is already after session insert). The CLI bug is real but a different shape (cold-start race in plugin init), demoted to `needs-investigation` for next iteration.
- Surfaces 3 (plugin-health-divergence) and 4 (checklist auto-complete) were also flipped to working-as-designed during plan-features recon.

**Your scope: append exactly 2 ledger entries** (both for Team A's leaderboard fix; same root cause, two finding_ids per the plan's granularity rule for separately-observed user symptoms).

---

## Inputs

- `docs/bug-hunt/ledger.jsonl` — historical ledger. Read last 5 lines for style.
- `docs/bug-hunt/pending_recurrences.jsonl` — current entry (Team C carryover from prior iteration). Schema is hand-written, non-standard. Do NOT modify.
- `docs/bug-hunt/20260504T165106Z1ab2/triage.json` — triage state (you can read for finding-metadata).

## Verified merge SHAs

- **Team A merge SHA on main**: `4b7ba2397982233cfc3dc9552302705e1167eedc`
- Team A direct commit (parent 2 of the merge): `af12d9f9e183c47c41bec10d4b8dce7e0dc88dde`

Use the merge SHA in the `commit` field (it's what landed on main).

## Files touched

- Modified: `docs/bug-hunt/ledger.jsonl` — append exactly 2 lines:

  Line 1 — leaderboard placeholder data (composite_score=0.5 + missing component metrics):
  ```json
  {"iteration_ts":"20260504T165106Z1ab2","finding_id":"leaderboard-component-metrics-missing","category":"leaderboard-placeholder-data","summary":"<60-90 char summary describing the schema fix + UI column rename + new tests>","scope_files":["finlet/api/schemas/leaderboard.py","finlet/leaderboard/profiles.py","dashboard/leaderboard.js","tests/leaderboard/test_leaderboard.py","tests/api/test_leaderboard.py"],"team":"A","commit":"4b7ba2397982233cfc3dc9552302705e1167eedc"}
  ```

  Line 2 — leaderboard UI '--' columns (separately-observed user symptom; same root cause):
  ```json
  {"iteration_ts":"20260504T165106Z1ab2","finding_id":"leaderboard-ui-component-columns-dashes","category":"leaderboard-placeholder-data","summary":"<60-90 char summary about the UI column rename SCENARIOS/TRADES/WIN_RATE → SHARPE/RETURN/DRAWDOWN>","scope_files":["dashboard/leaderboard.js","tests/e2e/journey-07-leaderboard.spec.ts"],"team":"A","commit":"4b7ba2397982233cfc3dc9552302705e1167eedc"}
  ```

  Mint short, specific summaries that future-you can grok at a glance. Keep `category` exactly as `leaderboard-placeholder-data` (already in the ledger from the original triage; reuse, don't mint).

- Modified or unchanged: `docs/bug-hunt/pending_recurrences.jsonl` — DO NOT touch. The existing entry (password-form-aria delete-account-form residual) is a tracked carryover. The blind walk this iteration did not surface password-form warnings (likely because the agent didn't open the delete-account-form modal). Leave the entry in place; the next iteration's blind walk should explicitly open that surface.

## Validation

- [ ] `wc -l docs/bug-hunt/ledger.jsonl` — was N before, is N+2 after.
- [ ] `tail -2 docs/bug-hunt/ledger.jsonl | jq -c '.iteration_ts'` — both lines must print `"20260504T165106Z1ab2"`.
- [ ] `tail -2 docs/bug-hunt/ledger.jsonl | jq -c '.commit'` — both must print `"4b7ba2397982233cfc3dc9552302705e1167eedc"`.
- [ ] `git -C <wt> rev-parse --verify "4b7ba2397982233cfc3dc9552302705e1167eedc^{commit}"` — must succeed.
- [ ] `python3 -c "import json; [json.loads(l) for l in open('docs/bug-hunt/ledger.jsonl')]"` — no parse errors.
- [ ] `wc -l docs/bug-hunt/pending_recurrences.jsonl` — unchanged.

## Write `team_e_verify.md`

Path: `docs/bug-hunt/20260504T165106Z1ab2/team_e_verify.md`. Document:
1. The 2 lines you appended (verbatim with finding_id + commit SHA).
2. Why the ledger has 2 entries instead of the plan's 3 (Team B abort).
3. Why pending_recurrences.jsonl is unchanged (carryover preserved with reason).
4. Whether any refactor verdicts pruned entries (none this iteration — confirm by inspecting `docs/bug-hunt/refactor-queue/*.md` for any `verdict: effective` set THIS iteration).

## Commit + push

- Single commit, message: `[Team E]: ledger +2 (Team A leaderboard fix); Team B aborted (premise invalid); pending_recurrences unchanged`
- `git push`

---

## When done, report:

```
DONE
commit: <SHA>
worktree_path: <path>
files_changed:
  - docs/bug-hunt/ledger.jsonl (+2 lines)
  - docs/bug-hunt/20260504T165106Z1ab2/team_e_verify.md (new)
ledger_entries_appended: 2
pending_recurrences_changed: no
verdicts_pruned: 0
```

OR `BLOCKED: <reason>`.

Do NOT cleanup the worktree yourself. Commit + push + exit.
