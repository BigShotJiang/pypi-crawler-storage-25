You are **Team B: CLI session create — idempotency before rate limit** for bug-hunt iteration `20260504T165106Z1ab2`.

**Worktree-rules block (READ THIS BEFORE WRITING ANY FILE):**
- Your worktree is at the path the orchestrator provides. ALL file edits MUST be in that worktree path. NEVER write to `/Users/justnau/finlet/` directly — that is the main checkout, not your worktree.
- Verify your CWD before any write: `pwd` should show a path under `.claude/worktrees/`, not `/Users/justnau/finlet`.
- For ANY git op inside your worktree, use `git -C <your-worktree-path> ...` rather than relying on inherited CWD.
- DO NOT touch the orchestrator's main checkout. Anything you need to read can be read from your worktree (it has the full repo).

**Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.**

**Pre-flight note:** the plan refers to `finlet/api/main.py` for middleware order, but the actual file is `finlet/api/app.py`. Verify the path when you read.

---

## Spec (verbatim from `docs/bug-hunt/20260504T165106Z1ab2/plan.md`)

**Blocked by:** none — can start immediately.

**Read these files first:**
- `finlet/api/routes_session.py:80-150` — current order is rate-limit-check (line 124: `check_session_creation(user)`) BEFORE idempotency cache lookup (line 112-121). On retry with the same Idempotency-Key, `check_session_creation` raises 429 because counters were already incremented by the first attempt — the cached response is never read.
- `finlet/api/rate_limit/session.py:26-77` — `check_session_creation()` increments `user.sessions_today` (line 59) at check time, BEFORE the actual session row is created. If the request times out mid-flight, the counter stays incremented for nothing.
- `finlet/cli.py:90-160` — CLI generates `idempotency_key` (line 104), sets `timeout=60` (line 114), retries on `httpx.ReadTimeout` (line 120-150) with the same key. Works if and only if the server treats a same-key replay as "return cached response without re-checking quota" — which currently it doesn't.
- `finlet/api/app.py` (NOT `main.py`; plan misnamed) — middleware stack order. Confirm rate-limit middleware (if any) does not double-count alongside the route-level `check_session_creation`.
- Recent git log for `routes_session.py`: `git log -10 --oneline finlet/api/routes_session.py` — confirm prior commit's intent.

**Files touched:**
- Modified: `finlet/api/routes_session.py` — reorder so idempotency cache lookup runs FIRST (before `check_session_creation`). On cache hit, return the stored response immediately without invoking the rate-limit check. Cache miss falls through to existing flow (rate-limit → create session → store result keyed by idempotency_key).
- Modified: `finlet/api/rate_limit/session.py` — defer `user.sessions_today += 1` until AFTER session insert succeeds. Wrap as a transactional update: check current count → if under limit, proceed; only increment after the new session row is committed. This prevents stranded counter increments when a request fails mid-flight.
- Modified: `tests/api/test_sessions.py` (or whichever file covers POST /v1/sessions; grep first) — add two regression tests:
  1. Same Idempotency-Key replayed within TTL after a successful first call returns the cached response without consuming a second quota slot.
  2. A timed-out first call that did NOT create a session does NOT increment the daily counter (re-fetch the user; counter unchanged).
- Modified: `tests/test_cli.py` — add or extend a test that mocks `httpx.ReadTimeout` on first POST and verifies the retry succeeds (no 429), provided the first POST didn't actually hit the server. Use `respx` or `httpx-mock` (whichever the existing tests use; check first).

**Deliverable:** `finlet session create` survives a transient ReadTimeout retry without hitting 429; daily session counter does not increment for failed/timed-out attempts; same Idempotency-Key replay returns the cached response on the happy path.

**Validation:**
- [ ] `uv run pytest tests/api/test_sessions.py tests/test_cli.py -x -q` — all green, including new regressions
- [ ] `uv run ruff check finlet/api/routes_session.py finlet/api/rate_limit/session.py` — clean
- [ ] `uv run mypy finlet/api/routes_session.py finlet/api/rate_limit/session.py` — clean

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message starts with `[Team B]:`. Push your branch.
- The fix is server-side. Do NOT change the CLI's timeout (60s is fine) or its retry-with-same-Idempotency-Key behavior — those are correct; the server is wrong.
- Idempotency cache TTL: read whatever the existing `idempotency_store.set(...)` call uses; do not change it.
- Tests MUST use mocks/fixtures for `httpx.ReadTimeout` simulation — no real network in unit tests.
- If `check_session_creation()` increments counters in the same DB transaction as session insert, decoupling may require a small refactor — keep it surgical, do not introduce a saga / unit-of-work pattern. The desired end state is "increment after commit, not at check time."
- Watch for race conditions: two concurrent POSTs from the same user can both pass the pre-creation check and both succeed → counter goes to N+2 when limit was N+1. If you see this risk, add a SELECT FOR UPDATE or a unique-constraint guard; document the choice in a one-line comment on the increment site.

---

## When done, report:

```
DONE
commit: <SHA>
validation:
  - pytest tests/api/test_sessions.py tests/test_cli.py: <result>
  - ruff: <result>
  - mypy: <result>
worktree_path: <path>
files_changed: <list>
```

OR `BLOCKED: <reason>` if you hit a blocker.

CRITICAL: do NOT cleanup the worktree yourself; the orchestrator will. Just commit + push your branch and exit.
