# Deploy Failure Handoff — bug-hunt 20260503T195318Z43db

> **Iteration:** `20260503T195318Z43db`
> **Failed run:** https://github.com/justnau1020/finlet/actions/runs/25290698021
> **Failed commit:** `a903b80` (HEAD of main when deploy fired; the patches Teams A+B added are inside this SHA)
> **Failed job:** `e2e` — single test failure, all others passed
> **Status of fixes on prod:** **NOT LIVE.** Patches merged to `main` but `deploy` job was skipped because `e2e` failed first.

---

## Systemic issue (read this before yak-shaving on the e2e fix)

**The bug-hunt loop's contract is half-true.** The skill says "Phase 5: tests passed → push → fix ships to prod." Reality on this iteration: tests passed locally (3962 in 5:14), push succeeded, but deploy never ran because CI's e2e gate failed on a test no local hook ever runs. We told the user "fix shipped" when actually "fix merged, prod still broken."

This will recur on every iteration where any e2e test is broken — including pre-existing flakes that have nothing to do with the bug-hunt patches. Until this is closed, every bug-hunt report is conditional on `gh run view` checking deploy-step success, not on the skill's own self-report.

**Two ways to close it (pick one):**

1. **Cheap fix — make Phase 5.5a deploy-failure visible and blocking in the bug-hunt report.** Already partly done (this iteration's report includes `Deploy: failure`), but the loop should hard-loop the user: "patches merged but NOT live; rerun deploy or expect next iteration to behave as if these patches don't exist." Probably already true based on how I worded the summary, but make it impossible to miss in the skill template.
2. **Real fix — add a thin e2e smoke (3-5 critical journeys, not all 142) to the local pre-push gate.** Costs ~30-60s on every push from any contributor. Benefit: bug-hunt's "fix shipped" claim stops being conditional on CI weather. Full e2e suite (5min) stays in CI; smoke-suite catches the "did Team B's nav change break the settings page" class of regression before merge.

I'd push for (2) before next iteration. (1) is a Band-Aid; (2) closes the gap.

---

## What broke (specific)

Single test failure in the e2e job:

```
[chromium] › tests/e2e/journey-06-settings.spec.ts:667:7
  Journey 6: Settings Page › settings profile save persists via API

  Error: expect(received).toBeGreaterThanOrEqual(expected)
  Expected: >= 1
  Received:    0

  >  706 | expect(profilePayload.length).toBeGreaterThanOrEqual(1);
       |                                   ^

   135 passed, 5 skipped, 1 failed (5.0m)
```

The test loads settings.html, edits a profile field, clicks save, and intercepts the PUT request to `/v1/users/me` (or similar). It expects exactly one PUT to fire. It got zero.

**Three possible root causes (in priority order):**

### Hypothesis 1 — Team B's `shared-nav.js` change broke shared init for the settings page

Team B's commit `056b417` modified `dashboard/shared-nav.js` (+31/-1). The change made the Copy API Key click handler call `FinletAuth.getApiKey()` and dynamically relabel the button when it returns null. Settings.html loads shared-nav.js at page boot. If the new code throws during init (e.g., calls `getApiKey()` before `FinletAuth` is hydrated), it can short-circuit subsequent JS in the same page including settings.js's PUT-on-save wiring.

**How to test:**
```bash
# Check if the test was passing immediately before Team B merged
git -C /Users/justnau/finlet checkout 4c4e7da  # post-Team-A, pre-Team-B
npx playwright test tests/e2e/journey-06-settings.spec.ts -g "settings profile save persists via API" --project=chromium
# vs.
git -C /Users/justnau/finlet checkout 0baa8d5  # post-Team-B
npx playwright test tests/e2e/journey-06-settings.spec.ts -g "settings profile save persists via API" --project=chromium
git -C /Users/justnau/finlet checkout main
```

If 4c4e7da passes and 0baa8d5 fails → Team B caused it. Either revert + re-fix Copy API Key with init-safe ordering, or fix the regression and ship a v2.

### Hypothesis 2 — Pre-existing flake (no relation to A or B)

This test is a network-interception assertion. Playwright network listeners can race the PUT firing if the Page object isn't fully ready when `route()` is registered. The test has been on `main` for a while; it's possible it just flakes occasionally and we got unlucky.

**How to test:**
```bash
gh run rerun 25290698021                       # rerun the failed run
gh run watch <new-run-id>                       # wait for outcome
```

If the rerun passes → flake. Document in `docs/KNOWN_FAILURES.md` with `xfail(flaky=True)` and move on.

### Hypothesis 3 — KNOWN_FAILURES.md drift

Pre-flight on this iteration ran on local pytest only. Pytest doesn't run Playwright. So the e2e suite has never had a `KNOWN_FAILURES.md`-equivalent. If `journey-06-settings.spec.ts:706` has been broken on `main` for some time (silently, since deploy was last green), nobody noticed because the prior bug-hunt iterations either had clean iterations (no patches → no deploy attempt) or coincidentally the test passed.

**How to test:**
```bash
gh run list --workflow="Deploy Finlet" --branch main --limit 20 --json conclusion,createdAt,headSha,databaseId
# Look for prior failures on this same test before our iteration
```

If 5+ recent deploys also failed on this test → it's been broken for a while; this iteration just made it visible by being the first one to need a deploy in a while.

---

## The fix path (decision tree)

```
1. gh run rerun 25290698021
   ├── PASS  → flake. Open `docs/KNOWN_FAILURES.md` entry, mark xfail-flaky, skip to step 4.
   └── FAIL  → real, deterministic.
       │
       ├── Bisect: does 4c4e7da pass and 0baa8d5 fail?
       │   ├── YES  → Team B caused it. Open new bug-hunt finding or
       │   │         direct patch reverting + re-fixing init order in
       │   │         shared-nav.js. Likely fix: defer getApiKey() call
       │   │         until inside the click handler (already true);
       │   │         look for an init-time read I missed. ~30 min.
       │   └── NO   → it's pre-existing. Read journey-06 test source +
       │             current settings.js save flow. Likely an unrelated
       │             regression masked by deploy not running for a while.
       │             Treat as standalone bug, not bug-hunt scope.
       │
       └── Either way: once green, deploy ships, both patches go live.

4. After deploy is green:
   - Manually run the two retest envelopes from triage.json against
     https://finlet.dev (curl for /v1/sessions/{id}/orders, playwright
     for Copy API Key redirect).
   - If both pass → update docs/bug-hunt/20260503T195318Z43db/retest_results.json
     to "pass" and commit. The two findings count as effectively-shipped.
   - If either fails → append to docs/bug-hunt/pending_recurrences.jsonl
     manually (Phase 5.5c didn't auto-run because deploy was failure).

5. Then run `/bug-hunt` in a fresh chat for the next iteration.
```

---

## Concrete commands

```bash
# Step 1 — rerun the failed deploy
gh run rerun 25290698021
gh run list --branch main --commit a903b80b4a8918139626e2b73865b88fb4177a39 --limit 5

# Step 2 — if rerun fails, bisect
git -C /Users/justnau/finlet log --oneline 3420145..a903b80
# Test post-A, pre-B:
git -C /Users/justnau/finlet checkout 4c4e7da
npx playwright test tests/e2e/journey-06-settings.spec.ts:667 --project=chromium --reporter=line
# Test post-B:
git -C /Users/justnau/finlet checkout 0baa8d5
npx playwright test tests/e2e/journey-06-settings.spec.ts:667 --project=chromium --reporter=line
git -C /Users/justnau/finlet checkout main

# Step 3 — manual retest of bug-hunt fixes against the (eventually-green) deploy
# Curl test for Team A's /sessions/{id}/orders alias
source ~/.bug-hunt-loop/secrets.env
SESSION_ID=$(curl -fsS -X POST -H "Authorization: Bearer $FINLET_TEST_USER_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"name":"retest-sessions-orders","start_date":"2024-01-02","capital":100000,"universe":["AAPL"]}' \
  "$FINLET_BASE_URL/v1/sessions" | jq -r '.session_id')
curl -fsS -o /tmp/orders.json -w '%{http_code}\n' \
  -H "Authorization: Bearer $FINLET_TEST_USER_API_KEY" \
  "$FINLET_BASE_URL/v1/sessions/$SESSION_ID/orders"  # expect 200
curl -X DELETE -H "Authorization: Bearer $FINLET_TEST_USER_API_KEY" "$FINLET_BASE_URL/v1/sessions/$SESSION_ID"

# Playwright test for Team B's Copy API Key redirect: open finlet.dev, login,
# click user-menu → Copy API Key, observe redirect to settings.html#api-keys
# (no clipboard receives literal 'session'). Manual eyeball is fine.
```

---

## My recommendation (one paragraph)

**Rerun first** (`gh run rerun 25290698021`) — 80% odds it's a flake on a network-interception test. If it passes, you're done; both patches ship. If it fails twice in a row, Hypothesis 1 (Team B regression) is the next priority — `dashboard/shared-nav.js` is the only file change between the last green deploy and this one that touches code loaded on settings.html. If Team B is the cause, the fix is a 30-minute targeted patch to defer the auth read inside the handler instead of at init. **Then close the systemic gap**: add a 3-journey smoke (login + place trade + settings save, ~1min Playwright run) to `scripts/setup-git-hooks.sh`'s pre-push hook before the next `/bug-hunt`. That stops the bug-hunt loop's "fix shipped" report from quietly being a lie.

---

## Files to update after fix lands

- `docs/bug-hunt/20260503T195318Z43db/retest_results.json` — flip `skipped-no-deploy` → `pass`/`fail` after manual retest
- `docs/KNOWN_FAILURES.md` — entry for `journey-06-settings.spec.ts:706` if classified as flake
- `docs/bug-hunt/pending_recurrences.jsonl` — only if manual retest of either Team A or B finding fails on the eventually-deployed prod
- `docs/decisions/e2e-in-pre-push-gate.md` — new decision record if you adopt the smoke-in-pre-push closing
