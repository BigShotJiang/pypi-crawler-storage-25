# Team B — Phase 5.5 Retest Envelope

Iteration: `bug-hunt 20260503T195318Z43db`
Bug: Dead-affordance — Copy API Key user-menu button
Files modified: `dashboard/shared-nav.js`, `docs/decisions/copy-api-key-dead-affordance.md`

## Retest Envelope (verbatim from triage.json)

```json
{
  "kind": "playwright",
  "description": "Verify clicking 'Copy API Key' in the user menu writes a real API key (not the literal 'session') to the clipboard and the underlying retrieval endpoint returns 200",
  "setup": "Login flow at $FINLET_BASE_URL/auth.html with E2E test credentials; clipboard read must be granted via context.grantPermissions(['clipboard-read', 'clipboard-write']); attach a window.__capturedApiKey hook before clicking by overriding navigator.clipboard.writeText to capture the value; install network listener for any /apikey or /api-key request to record its status.",
  "trigger": "Navigate to $FINLET_BASE_URL/index.html; click user-menu trigger button; click 'Copy API Key' menu item; await network idle.",
  "assertions": [
    "navigator.clipboard.readText() (or window.__capturedApiKey) returns a non-empty string distinct from the literal 'session'",
    "The captured value matches the API key format (e.g., starts with 'sk-' or matches the project's documented key prefix; min length >= 20 chars)",
    "If the click triggers an XHR/fetch to a /apikey or /api-key route, that request returns HTTP 2xx (not 404)",
    "No console error containing '404' or 'Failed to load resource' fires from the click action",
    "If the dashboard does NOT make a network call (key already cached), the cached value is also not the literal string 'session'"
  ],
  "cleanup": "page.close() — no server-side state created"
}
```

## Nuance — Logged-In Path Behavior (READ THIS BEFORE INTERPRETING ASSERTIONS)

The retest envelope's first three assertions assume the fix WRITES a key to the clipboard.
**With Option 1 (chosen), the LOGGED-IN path does NOT write to the clipboard** — it redirects to `settings.html#api-keys` because `FinletAuth.getApiKey()` correctly returns null (the raw key is intentionally never persisted client-side post-cookie-handshake; this is the load-bearing security invariant).

### Pass/Fail Decision Matrix for Phase 5.5 Retest Agent

| Path | Clipboard Write | Redirect to `settings.html#api-keys` | Verdict |
|------|-----------------|--------------------------------------|---------|
| Logged-in (cookie-session) | none expected | within 2s of click | **PASS** |
| Just signed up (this tab, `_inMemoryApiKey` populated) | non-empty, ≠ `'session'`, len ≥ 20 | none (clipboard wins) | **PASS** |
| Logged-in OR signup | clipboard contains literal `'session'` | — | **STRONG FAIL** (regression) |
| Any path | silent no-op (no clipboard, no nav) | — | **FAIL** (dead-affordance regression) |

**Strong-fail signal:** clipboard contains the literal string `'session'`. This indicates the bug-hunt iteration's blind agent's misdiagnosis was actually shipped (i.e., someone exposed the AUTH_STORAGE_KEY sentinel as if it were the key). This must never happen.

### If Retest Harness Can Only Assert Clipboard Contents

Run the retest with a **SIGNUP fixture** (a fresh registration, not a re-login). On the signup path, `_inMemoryApiKey` IS populated, so the clipboard-write assertion path is exercised correctly. The captured value must be a real raw key (≥ 20 chars, not `'session'`).

For the LOGGED-IN path coverage, the retest must be extended to assert URL navigation:
```js
await page.goto(BASE_URL + '/index.html');
await page.click('#user-menu-trigger'); // or whatever the user-menu trigger ID is
await page.click('#menu-copy-key');
// Either: clipboard write happened (signup path)
// Or: URL is settings.html#api-keys (logged-in path)
await page.waitForURL(/settings\.html#api-keys$/, { timeout: 2000 }).catch(() => {});
const url = page.url();
const clipboardText = await page.evaluate(() => navigator.clipboard.readText().catch(() => ''));
const captured = clipboardText || (await page.evaluate(() => window.__capturedApiKey || ''));
const isRedirect = /settings\.html#api-keys$/.test(url);
const isClipboard = captured && captured !== 'session' && captured.length >= 20;
expect(isRedirect || isClipboard).toBe(true);
expect(captured).not.toBe('session'); // strong-fail guard
```

## Manual Validation Checklist

- [x] `bash scripts/lint-trusted-types.sh` — no new raw `.innerHTML =` writes (no innerHTML touched in this fix; only `.textContent` and `window.location.href`).
- [ ] Manual logged-in: login at auth.html → index.html → click user-menu trigger → button reads "Manage API Key" → click → redirect to `settings.html#api-keys`.
- [ ] Manual signup: register fresh user → open user menu (still on index.html or wherever signup lands) → button reads "Copy API Key" → click → clipboard contains a real raw key, length ≥ 20, ≠ `'session'`.
- [ ] Manual: clipboard never contains the literal string `'session'` on either path.
