# Bug-Hunt 20260503T195318Z43db — Execution Plan

> Generated from `docs/bug-hunt/20260503T195318Z43db/triage.md` on 2026-05-03.
>
> **Status: COMPLETED 2026-05-03 — Team A=4c4e7da, Team B=0baa8d5b, Team D=039ac1f**

## Constraints

- Two real-broken findings + the mandatory docs team. Two-team code work + Team D = clean iteration.
- **Team A** ships a server-side route alias OR a sibling registration. The router for `/sessions/{session_id}/trade` already exposes `GET /orders` (see `finlet/api/routes_trade.py:125-141`) — the bug is that the cleaner non-`/trade/` URL the agents and ecosystem expect (`GET /v1/sessions/{id}/orders`) is missing. Don't refactor the existing route; add the missing one.
- **Team B** has a non-trivial design decision: the dashboard NEVER stores the raw API key client-side after the cookie-session migration. `sessionStorage.finlet_api_key` is an INTENTIONAL sentinel string ('cookie' | 'memory' | 'session') indicating which auth path is active — NOT the real key. After login, the key cannot be retrieved (it's hash-stored in the DB; only shown once at signup or post-rotate). The Copy API Key affordance is therefore dead **by-design** for any user who logged in (vs. signed up in the same browser tab). Fix is to neuter the dead affordance: redirect "Copy API Key" to the existing Settings → API Keys flow (where users can create a new named key with one-time display via `POST /v1/settings/api-keys`). Do NOT (a) leak hash, (b) auto-rotate-and-copy (destructive), or (c) silently expose a new retrieve-raw-key endpoint that breaks the security model.
- All cross-component dashboard wiring goes through `window.finletBus`. No new bus events expected this iteration.
- Trusted-types lint is enforced via `bash scripts/lint-trusted-types.sh` (pre-commit). Any `.innerHTML =` writes under `dashboard/` must be wrapped through `trustedHTML(...)`.
- Vanilla HTML+JS+CSS dashboard — no build step, no framework.
- Server-side scope: `finlet/api/routes_trade.py` already owns `GET /sessions/{session_id}/trade/orders`. Adding a non-`/trade/` alias creates a new file or extends the existing file; no DB schema change.

## File Conflict Table

| File | Touched by Teams |
|------|------------------|
| `finlet/api/routes_trade.py` | A (read-only — reuse `list_orders` service) |
| `finlet/api/routes_session.py` | A (add new `GET /sessions/{id}/orders` route here, or via a new sibling file) |
| `finlet/api/services/trade_service.py` | A (read-only — `list_orders` already exists at `:167`) |
| `finlet/api/app.py` | A (only if a NEW router file is added — register it) |
| `tests/api/test_orders.py` | A (NEW) |
| `tests/api/test_trade.py` | A (read-only reference) |
| `dashboard/shared-nav.js` | B |
| `dashboard/mobile-nav.js` | B |
| `dashboard/index.html` | B (only if button label/markup changes) |
| `dashboard/settings.html` | B (only if drawer button label/markup changes) |
| `dashboard/billing.html` | B (only if drawer button label/markup changes) |
| `dashboard/leaderboard.html` | B (only if drawer button label/markup changes) |
| `dashboard/auth.js` | B (read-only — `FinletAuth.getApiKey()` semantics already documented at `:1641-1645`) |
| `tests/e2e/journey-04-settings-api-key.spec.ts` | B (NEW or extended) |
| `docs/decisions/copy-api-key-dead-affordance.md` | B (NEW — non-trivial decision record) |
| `docs/REMAINING_TASKS.md` | D |
| `docs/LESSONS.md` | D |
| `docs/ARCHITECTURE.md` | D (only if route surface changes — likely yes for Team A) |
| `docs/KNOWN_FAILURES.md` | D |
| `docs/bug-hunt/20260503T195318Z43db/*` | D (artifact stage) |
| `docs/bug-hunt/ledger.jsonl` | D (append +2 lines) |
| `docs/bug-hunt/pending_recurrences.jsonl` | D (stage if orchestrator wrote anything) |

**No file conflicts between A, B, and D.** Team A is server-side; Team B is dashboard-side; Team D is docs-side. Parallel-safe (sequential merge per exec-plan model).

## Dependency Graph

```
Team A (missing-rest-endpoint)  ── independent, can start immediately
Team B (dead-affordance)        ── independent, can start immediately
Team D (docs + ledger)          ── BLOCKED BY A + B (needs merge SHAs for ledger)
```

## Critical Path

```
[A, B] (parallel) → D
```

Both A and B are small patches (≤6 files each). D is purely docs.

---

## Teams

### Team A: Missing REST endpoint — `GET /v1/sessions/{id}/orders`

**Blocked by:** none — can start immediately.

**Read these files first** (with `path:line` attribution):

- `finlet/api/routes_trade.py:125-141` — existing `GET /sessions/{session_id}/trade/orders` route (`list_orders_route`). The handler that already does the right thing — pattern + service call to mirror.
- `finlet/api/routes_trade.py:29` — router prefix is `/sessions/{session_id}/trade`. **This is why the non-`/trade/` URL 404s.**
- `finlet/api/services/trade_service.py:167` — `list_orders(session, filter_status)` service function. The new alias must call this same service (don't fork business logic).
- `finlet/api/routes_session.py:34` — `router = APIRouter(tags=["sessions"])` (no prefix). Plain `/sessions/{session_id}/...` routes live here. **This is the natural home for the new alias.**
- `finlet/api/routes_session.py:1-30` — module docstring + imports. Add a single import line for `list_orders` from `trade_service` and `OrderResponse` from `schemas.trade`.
- `finlet/api/schemas/trade.py` — `OrderResponse` Pydantic model (response shape).
- `finlet/api/auth.py:18` — `require_user` import (used to gate the new route).
- `finlet/api/deps.py` — `get_user_session(session_id, user)` — same auth+ownership check the trade route uses.
- `finlet/api/app.py:498-501` — `v1_router.include_router(r)` is the registration loop. If `routes_session.py` is the home of the new route, no app.py change is needed (already registered). If a new module is created, app.py must include it here.
- `tests/api/test_trade.py:81` — existing test for `GET /sessions/{id}/trade/orders` returning 200. Pattern to mirror in the new `test_orders.py` (or extend `test_trade.py`).
- `tests/api/test_e2e.py:272-853` — e2e patterns for orders flow.
- `docs/bug-hunt/20260503T195318Z43db/triage.json` — the verbatim retest envelope reproduced below.

**The decision (where to register the alias):**

Two viable shapes — pick ONE and document why in the commit message:

1. **In `routes_session.py`**: add a `GET /sessions/{session_id}/orders` route at the bottom of the file. Import `list_orders` from `trade_service`. Call it the same way `list_orders_route` does. **Cheaper** — one file change, ~15 lines added. Recommended.
2. **New `routes_orders.py`**: create a sibling router with its own prefix. Register it in `app.py`. **More files**, slightly cleaner separation. Only do this if Team A finds session-level orders semantics that diverge from trade-level (they don't, currently).

The shared service function `list_orders(session, filter_status)` MUST be the single business-logic source. **Do not** duplicate the body of `list_orders_route` — call the service, return its result.

**The fix scope:**

- The router prefix mismatch is ALL the bug is. The agent expects `/v1/sessions/{id}/orders`, the route lives at `/v1/sessions/{id}/trade/orders`.
- Add `GET /sessions/{session_id}/orders` (and optionally `GET /sessions/{session_id}/orders/{order_id}` for symmetry — but NOT required by triage; do it ONLY if the regression test in `tests/api/test_trade.py` is extended without contortion).
- Keep the existing `/trade/orders` endpoint intact — many existing tests rely on it. The new endpoint is an alias, not a replacement.
- Do NOT change `OrderResponse` schema, `list_orders` service, or the order data model.

**Files touched:**
- Modified: `finlet/api/routes_session.py` — add `GET /sessions/{session_id}/orders` (and maybe `/orders/{order_id}`) route(s) at the end of the file. Import what you need from `trade_service`, `schemas.trade`, `core.orders`.
- New: `tests/api/test_orders.py` — pytest module with at minimum:
  - test that `GET /v1/sessions/{id}/orders` returns 200 (not 404) with a list-shaped body
  - test that the response includes a known filled order placed via `POST /trade/order`
  - test that `?status=FILLED` query param filters
  - test that an unauthenticated call returns 401 (or 404 per the deny-by-default contract — match the existing pattern at `tests/api/test_trade.py:81`)
- (Optional) Modified: `tests/api/test_trade.py` — add a sanity assertion that the existing `/trade/orders` endpoint still returns 200 and equals the new `/orders` response (parity check).
- (Only if going with option 2) New: `finlet/api/routes_orders.py` + Modified: `finlet/api/app.py:500` to register the new router.

**Deliverable:** `GET /v1/sessions/{id}/orders` returns 200 with a list of orders for the authenticated session owner. Mirrors `/trade/orders` semantics 1:1. Filed orders are visible. Status filter works.

**Validation:**
- [ ] `uv run pytest tests/api/test_orders.py -x -q` passes (new module, ≥3 tests)
- [ ] `uv run pytest tests/api/test_trade.py -x -q` passes (no regression on existing route)
- [ ] `uv run pytest tests/api/test_e2e.py -x -q` passes (no e2e regression)
- [ ] `uv run ruff check finlet/api/ tests/api/test_orders.py` passes
- [ ] `uv run mypy finlet/api/ --ignore-missing-imports` passes
- [ ] Manual curl sanity (post-deploy, in Phase 5.5): `curl -sS -o /tmp/o.json -w '%{http_code}\n' -H "X-API-Key: $FINLET_API_KEY" "$FINLET_BASE_URL/v1/sessions/$SESSION_ID/orders"` returns `200`.

**Phase 5.5 retest envelope (verbatim from triage.json — copy into `team_a_verify.md`):**

```json
{
  "kind": "curl",
  "description": "Verify GET /v1/sessions/{id}/orders returns 200 with a list-shaped order response (not 404) on the live deploy",
  "setup": "Requires a valid X-API-Key (export FINLET_API_KEY=...) and an existing session_id with at least one filled order. Create session: POST /v1/sessions with template payload; place order: POST /v1/sessions/{id}/trade/order body={\"symbol\":\"AAPL\",\"side\":\"BUY\",\"quantity\":1,\"order_type\":\"MARKET\"}; capture session_id from creation response.",
  "trigger": "curl -sS -o /tmp/orders.json -w '%{http_code}\\n' -H \"X-API-Key: $FINLET_API_KEY\" \"$FINLET_BASE_URL/v1/sessions/$SESSION_ID/orders\"",
  "assertions": [
    "HTTP status code is 200 (not 404)",
    "Response body parses as JSON",
    "Response body contains a list/array of orders (e.g., top-level array OR an object with key 'orders' / 'items' / 'data' that is an array)",
    "Each order in the list contains at minimum: order_id (or id), symbol, side, quantity, status fields",
    "When the session has a filled AAPL BUY, that order is present in the response"
  ],
  "cleanup": "rm -f /tmp/orders.json (the test session is left in place — sessions aren't deleted by this retest)"
}
```

**Agent instructions:**
- You MUST `git add` + `git commit` your work in your worktree before finishing — uncommitted work is destroyed when the worktree is cleaned up.
- Commit message format: `[Team A]: api: add GET /v1/sessions/{id}/orders alias (close missing-rest-endpoint)`
- Reuse the existing `list_orders` service function in `finlet/api/services/trade_service.py:167`. **Do not** duplicate the route body.
- The new route MUST share auth (`Depends(require_user)`) + session-ownership (`get_user_session(session_id, user)`) with the trade route — copy the dependency wiring exactly.
- Match the existing response shape: `list[OrderResponse]` (the same model as `/trade/orders`).
- DO NOT touch `OrderResponse`, `list_orders` (service), or `OrderBook.get_orders` (`finlet/core/orders.py:215`). Schema changes are out of scope.
- DO NOT remove or rename the existing `/trade/orders` route. It's the alias, the new one is the alias-friendlier-URL — both exist.
- Copy the Phase 5.5 retest envelope above into `docs/bug-hunt/20260503T195318Z43db/team_a_verify.md` for traceability, plus the test names + their pass/fail status as your verify evidence.

---

### Team B: Dead-affordance — Copy API Key user-menu button

**Blocked by:** none — can start immediately.

**Read these files first** (with `path:line` attribution):

- `dashboard/shared-nav.js:301-326` — desktop user-menu Copy API Key click handler. Calls `FinletAuth.getApiKey()`; toast on success; **shows the misleading "No Key — Create a new API key in Settings" toast on failure**, but does NOT take the user to settings or open the key-creation flow.
- `dashboard/auth.js:1641-1645` — `FinletAuth.getApiKey()` definition. Returns `_inMemoryApiKey || sessionStorage.getItem('finlet_created_api_key') || null`. **The literal `'session'` from `sessionStorage.finlet_api_key` is NEVER returned by this function — that is `AUTH_STORAGE_KEY` and only stores a sentinel: 'cookie' | 'memory' | 'session'.** The blind agent confused the marker with the key.
- `dashboard/auth.js:760` — login flow sets `sessionStorage.setItem(AUTH_STORAGE_KEY, 'session')` AFTER successful POST `/auth/login`. The literal string 'session' is intentional: the cookie does the auth, this marker just says "auth path is alive". `_inMemoryApiKey` is NEVER populated on the login path.
- `dashboard/auth.js:815-821` — signup flow stores `data.api_key` into `_inMemoryApiKey` via `saveAuth(apiKey, ...)`. THIS is why a fresh signup tab can copy the key briefly; a logged-in tab cannot.
- `dashboard/auth.js:362-392` — `saveAuth(apiKey, user)`. After successfully exchanging the API key for a cookie session at `POST /auth/session`, it intentionally leaves `_inMemoryApiKey = null` and stores 'cookie' in sessionStorage. The key was used and discarded.
- `dashboard/settings.js:832` — when Settings creates a new named key, the raw key is shown ONCE and stored in `sessionStorage.finlet_created_api_key`. This sentinel is wiped on next page-nav cleanup (this is the one-time-display pattern).
- `dashboard/mobile-nav.js:174-195` — drawer's Copy API Key button. Calls `desktopCopyKey.click()` — i.e., it's a thin proxy to `shared-nav.js`'s handler. Fix the desktop handler and the drawer follows automatically.
- `finlet/api/routes_settings.py:78-94` — `GET /v1/settings/api-keys` (lists masked metadata only) + `POST /v1/settings/api-keys` (creates new key, returns raw value once). These endpoints already exist — Team B's fix uses them, not new ones.
- `finlet/api/services/settings_service.py:125-189` — `list_api_keys`, `create_api_key`, `revoke_api_key`, `rotate_api_key`. **Note `rotate_api_key` is destructive** — do not invoke from the user-menu Copy click.
- `dashboard/index.html:68`, `dashboard/settings.html:63`, `dashboard/billing.html:63`, `dashboard/leaderboard.html:62` — drawer-button markup `<button id="nav-drawer-copy-key">Copy API Key</button>`. Update label if button semantics change.

**The decision — what does "Copy API Key" mean if the key isn't retrievable?**

The button can be in one of three states by-design:

| Auth path | `_inMemoryApiKey` | `sessionStorage.finlet_created_api_key` | Copy result |
|-----------|-------------------|------------------------------------------|-------------|
| Just signed up (this tab) | populated | empty | works |
| Just rotated/created in Settings (this tab) | empty | populated | works |
| Logged in (any tab) OR refreshed signup tab | empty | empty | dead button (the bug) |

The fix MUST pick one of two paths:

**Option 1 (RECOMMENDED — graceful redirect):** When `getApiKey()` returns null, the click navigates to `settings.html#api-keys` (or opens a Settings → API Keys deep-link modal) where the user can create a NEW named key. Re-label the button to "Manage API Key" when no copyable key is in memory; keep "Copy API Key" + clipboard write when a key IS in memory. The button is no longer dead — it always does *something useful* on click.

**Option 2:** Remove the button entirely from `shared-nav.js:198` and the four `*.html` drawer files. Replace with a permanent "Manage API Keys" link. Cleaner for security model but loses the convenience for fresh-signup users.

**Pick Option 1.** Document the decision in `docs/decisions/copy-api-key-dead-affordance.md`. Cite this triage iteration.

**The fix scope:**

- `shared-nav.js:301-326` (desktop handler): on click, if `FinletAuth.getApiKey()` returns a string (truthy non-empty), do the existing clipboard write + toast. If it returns null/empty, redirect to `settings.html?tab=api-keys` (or whatever Settings tab anchor is current — verify in `dashboard/settings.js`). Show a toast message: "Open Settings to create a new key" rather than the current misleading "No Key — Create a new API key in Settings".
- Optionally: re-label the button TEXT dynamically to "Manage API Key" when no copyable key is in memory. Read `FinletAuth.getApiKey()` on user-menu open (the `trigger.addEventListener('click', ...)` at `shared-nav.js:278-282`) and toggle `copyKeyBtn.textContent` accordingly.
- Drawer mobile button (`mobile-nav.js:175-195`) automatically inherits the fix because it `.click()`s the desktop button (line 180).
- DO NOT add a new server endpoint. The blind agent probed `GET /api/user/apikey` and got 404 — that endpoint should NEVER exist (it would expose hash-stored keys in plaintext). Don't even tempt it.
- DO NOT auto-invoke `rotate_api_key` on click — that's destructive (user's existing keys still in flight in their agents would break).

**Files touched:**
- Modified: `dashboard/shared-nav.js` — line 301-326 click handler. ~15 lines changed.
- Modified: `dashboard/index.html`, `dashboard/settings.html`, `dashboard/billing.html`, `dashboard/leaderboard.html` — only if the drawer button label changes (or stays "Copy API Key" with click-time relabel JS — preferred). Static HTML changes preferred OFF; dynamic JS toggle preferred ON.
- New: `docs/decisions/copy-api-key-dead-affordance.md` — 1-page record of why the button now redirects vs. exposes raw key.
- New / extended: `tests/e2e/journey-04-settings-api-key.spec.ts` — Playwright assertion that:
  - logged-in user clicks Copy API Key → redirected to `settings.html#api-keys` (or modal opens)
  - signed-up user (with `_inMemoryApiKey` populated) → clipboard receives a real key
  - clipboard never receives literal string `'session'`

**Deliverable:** Clicking "Copy API Key" never silently fails. Either (a) writes a real key to the clipboard (signup/rotate path), OR (b) redirects to Settings → API Keys (login path). The clipboard NEVER receives the literal string `'session'`.

**Validation:**
- [ ] `bash scripts/lint-trusted-types.sh` passes (no new raw `.innerHTML =` writes)
- [ ] `npx playwright test tests/e2e/journey-04-settings-api-key.spec.ts` passes (new assertion)
- [ ] No regression in `npx playwright test tests/e2e/journey-01-onboarding.spec.ts tests/e2e/journey-05-trade.spec.ts`
- [ ] Manual: log in (don't sign up); click Copy API Key in user menu → verify redirect to `settings.html#api-keys` (or modal); verify clipboard does NOT contain 'session'.
- [ ] Manual: sign up; immediately click Copy API Key → clipboard contains a real key (not 'session', length ≥20).
- [ ] `docs/decisions/copy-api-key-dead-affordance.md` exists with sections: Context, Decision, Alternatives Rejected, Consequences.

**Phase 5.5 retest envelope (verbatim from triage.json — copy into `team_b_verify.md`):**

```json
{
  "kind": "playwright",
  "description": "Verify clicking 'Copy API Key' in the user menu writes a real API key (not the literal 'session') to the clipboard and the underlying retrieval endpoint returns 200",
  "setup": "Login flow at $FINLET_BASE_URL/auth.html with E2E test credentials; clipboard read must be granted via context.grantPermissions(['clipboard-read', 'clipboard-write']); attach a window.__capturedApiKey hook before clicking by overriding navigator.clipboard.writeText to capture the value; install network listener for any /apikey or /api-key request to record its status.",
  "trigger": "Navigate to $FINLET_BASE_URL/index.html; click user-menu trigger button; click 'Copy API Key' menu item; await network idle.",
  "assertions": [
    "navigator.clipboard.readText() (or window.__capturedApiKey) returns a non-empty string distinct from the literal 'session'",
    "The captured value matches the API key format (e.g., starts with 'sk-' or matches the project's documented key prefix; min length >= 20 chars)",
    "If the click triggers an XHR/fetch to a /apikey or /api-key route, that request returns HTTP 2xx (not 404)",
    "No console error containing '404' or 'Failed to load resource' fires from the click action",
    "If the dashboard does NOT make a network call (key already cached), the cached value is also not the literal string 'session'"
  ],
  "cleanup": "page.close() — no server-side state created"
}
```

**Note for Team B agent:** the Phase 5.5 retest envelope's first three assertions assume the fix WRITES a key to the clipboard. With Option 1 (redirect when no key in memory), the retest agent for the LOGGED-IN path will NOT see a clipboard write — it will see a navigation to Settings. The retest harness should treat "no clipboard write but valid Settings → API Keys redirect within 2s" as PASS, and "clipboard contains the literal 'session'" as the strong-fail signal. Document this nuance in `team_b_verify.md` so the Phase 5.5 retest agent has it inline. If the retest harness can only assert clipboard contents, the test should be run with a SIGNUP fixture (where `_inMemoryApiKey` IS populated) to satisfy the clipboard-write assertion path.

**Agent instructions:**
- You MUST `git add` + `git commit` your work in your worktree before finishing.
- Commit message format: `[Team B]: dashboard: Copy API Key button redirects to Settings on cookie-session path (close dead-affordance)`
- Follow the existing event-binding pattern in `dashboard/shared-nav.js:301-326`. Use `showToast({type, title, message})` (object form) — see `dashboard/app.js` for canonical signature.
- DO NOT add a new server endpoint. Specifically DO NOT add `GET /v1/auth/apikey` or `GET /v1/user/apikey` — those would compromise the hash-only key storage model.
- DO NOT auto-invoke `POST /v1/settings/api-keys/rotate` on click — that's destructive.
- Use `window.location.href = 'settings.html?tab=api-keys'` (or the existing tab anchor — verify in `dashboard/settings.js`) for the redirect path.
- Document the decision in `docs/decisions/copy-api-key-dead-affordance.md`. Cite the triage iteration `20260503T195318Z43db` and explain why redirect > silent fail > rotate-and-copy > expose raw key.
- Copy the Phase 5.5 retest envelope above into `docs/bug-hunt/20260503T195318Z43db/team_b_verify.md` (with the nuance note about clipboard vs. redirect for logged-in path).

---

### Team D: Documentation updates per Required Docs Updates block

**Blocked by:** A + B (need merge SHAs from both for the ledger and to know what shipped for LESSONS).

**Read these files first** (with `path:line` attribution):

- `docs/bug-hunt/20260503T195318Z43db/triage.md:22-59` — the Required Docs Updates block. **Authoritative scope.**
- `docs/bug-hunt/20260503T195318Z43db/triage.json` — finding-specific summaries.
- `docs/REMAINING_TASKS.md` — most recent "Bug Hunt YYYYMMDD — Closed" subsection (look at the prior iteration `20260503T030227Z2009`) for pattern.
- `docs/LESSONS.md` — most recent additions for tone/format. Lessons must be REUSABLE RULES, not diff recaps.
- `docs/ARCHITECTURE.md` — header sections; verify whether the route surface section needs a line for `GET /v1/sessions/{id}/orders` (Team A added it).
- `docs/KNOWN_FAILURES.md` — pre-flight refresh; remove anything resolved.
- `docs/bug-hunt/ledger.jsonl` — last 5 lines for schema/category vocabulary. Confirm `dead-affordance` exists (it does, 3 entries) and confirm `missing-rest-endpoint` is NEW (it is — minted this iteration).
- `docs/bug-hunt/pending_recurrences.jsonl` — current pending entries; orchestrator may have appended in Phase 5.5c.
- `docs/decisions/copy-api-key-dead-affordance.md` — Team B's decision record (read after B merges).
- Team A and Team B's commits + verify.md files (read after their merges land on `main`).

**Files touched:**

- Modified: `docs/REMAINING_TASKS.md` — append "Bug Hunt 20260503T195318Z43db — Closed" subsection listing the 2 broken items + their merge SHAs.
- Modified: `docs/LESSONS.md` — append at least one new lesson per real-broken finding (so 2 lessons minimum). Suggested:
  - "When an HTTP route 404s but the underlying service is correct, look for a router-prefix mismatch first. The blind agent expected `/v1/sessions/{id}/orders`; the route lives at `/v1/sessions/{id}/trade/orders`. Both shapes are reasonable — ship aliases for the shape ecosystem code is more likely to type. (How to apply: when adding a router prefix, search the codebase + docs for callers using the prefix-less form and add an alias if found.)"
  - "When a UI affordance silently fails for one auth path but works for another, look for a sentinel value vs. real value confusion. The dashboard's `sessionStorage.finlet_api_key` was an INTENTIONAL marker ('cookie' | 'memory' | 'session') indicating WHICH auth path is active — NOT the key. The API key itself was never retrievable post-cookie-session-handshake (correct security model). The bug was a dead button shipping anyway. (How to apply: when storage holds a sentinel, name the variable to indicate the sentinel-ness — `auth_path_marker` not `finlet_api_key`. Or remove the affordance that depends on the value being the key.)"
- Modified: `docs/ARCHITECTURE.md` — add a line under the route surface section noting the new `GET /v1/sessions/{id}/orders` alias. If the route surface section doesn't list every endpoint, add only the high-level note: "Order listing exposed at both `/sessions/{id}/orders` and `/sessions/{id}/trade/orders` post-20260503T195318Z43db." If untouched otherwise, state in commit message explicitly.
- Modified: `docs/KNOWN_FAILURES.md` — pre-flight refresh; remove anything resolved this iteration.
- Add: `docs/decisions/copy-api-key-dead-affordance.md` — Team B writes this as part of their fix; Team D verifies it's tracked + commits if untracked.
- Modified: `docs/bug-hunt/ledger.jsonl` — APPEND exactly 2 new JSON lines (one per real-broken closed):
  ```jsonl
  {"iteration_ts":"20260503T195318Z43db","finding_id":"sessions-orders-route-alias","category":"missing-rest-endpoint","summary":"Add GET /v1/sessions/{id}/orders alias to existing trade-prefixed orders route","scope_files":["finlet/api/routes_session.py","tests/api/test_orders.py"],"team":"A","commit":"<merge-sha-A>"}
  {"iteration_ts":"20260503T195318Z43db","finding_id":"copy-api-key-redirect-on-cookie-session","category":"dead-affordance","summary":"User-menu Copy API Key redirects to Settings when no key in memory; never writes literal 'session' to clipboard","scope_files":["dashboard/shared-nav.js","dashboard/settings.html","docs/decisions/copy-api-key-dead-affordance.md"],"team":"B","commit":"<merge-sha-B>"}
  ```
  Read merge SHAs from `git log --oneline main -10` AFTER A and B have merged. Suggested slugs above; adjust if the actual commit message uses a different slug. **`missing-rest-endpoint` is a NEW category** — confirmed no existing tag fits (`info-leak`, `dashboard-state-sync`, `dead-affordance`, etc. don't describe a missing route).
- Stage (NOT modified by Team D unless orchestrator wrote): `docs/bug-hunt/pending_recurrences.jsonl` and (if pruning happened) `docs/bug-hunt/pending_recurrences.resolved.jsonl`.
- Stage: every artifact in `docs/bug-hunt/20260503T195318Z43db/` produced this iteration:
  - `plan.md` (this file)
  - `triage.md`, `triage.json`
  - `blind_report.json`, `blind_report.parsed.json`
  - `cleanup.log`, `blind_stdout.log`, `blind_stderr.log`
  - `team_a_verify.md`, `team_b_verify.md` (after A and B commit them)
  - `deploy_status.txt`, `retest_results.json` (orchestrator-emitted in Phase 5.5)

**Deliverable:** A single docs commit on `main` titled `docs: bug-hunt 20260503T195318Z43db — close 2 broken (sessions/orders alias, Copy API Key redirect); LESSONS +2; ledger +2` with all the docs and artifacts above staged + committed.

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` grew by exactly 2 (one per real-broken closed)
- [ ] `jq -c . docs/bug-hunt/ledger.jsonl | tail -2` parses cleanly (every new line is valid JSON, has all 7 schema fields: iteration_ts, finding_id, category, summary, scope_files, team, commit)
- [ ] `git status docs/bug-hunt/20260503T195318Z43db/` shows no untracked files in the iteration dir
- [ ] `docs/REMAINING_TASKS.md` has a "Bug Hunt 20260503T195318Z43db — Closed" subsection
- [ ] `docs/LESSONS.md` grew by ≥6 lines (2 lessons minimum, ~3 lines each)
- [ ] Commit message contains `20260503T195318Z43db` and `bug-hunt`

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Commit message: as in Deliverable above. Use a HEREDOC for multi-line clarity.
- LESSONS.md entries must be REUSABLE RULES, not "we fixed X by doing Y." Pattern: "When you see <symptom>, suspect <class of cause> first. Why: <past incident>. How to apply: <where to look>."
- Read merge SHAs from `git log --oneline main -10` AFTER A and B merge. Do not guess.
- The category `missing-rest-endpoint` is NEW — confirmed in plan recon that no existing ledger tag fits. Use it for Team A's entry.
- If Team B's `docs/decisions/copy-api-key-dead-affordance.md` is missing on main when D runs, prompt fail-fast (do not write a placeholder); the decision MUST come from Team B's understanding of why redirect > silent-fail.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A duplicates `list_orders_route` body instead of calling the shared service | Medium | Medium | Team A instructions explicitly require calling `trade_service.list_orders` and forbid duplicating the route body. Code review against `routes_trade.py:125-141` pattern. |
| Team A's new route wires auth differently from `/trade/orders` (e.g., uses `optional_user` instead of `require_user`) | Low | High | Validation step requires `tests/api/test_orders.py` to include an unauthenticated test that asserts 401/404 (matching `/trade/orders` behavior). |
| Team A breaks the existing `/trade/orders` route by accidentally renaming/removing it | Low | High | Mandatory pre-merge run of `tests/api/test_trade.py`. Existing tests at `:81, :98, :115, :120, :162, :177, :183` rely on the existing URL. |
| Team B's redirect URL doesn't match the actual Settings tab anchor — clicking "Copy API Key" lands on a Settings page that doesn't open the API Keys tab | Medium | Medium | Validation step: manual click verifies the redirect lands on `settings.html#api-keys` AND the API Keys tab is visible. If `settings.js` uses `?tab=api-keys` query param vs. `#api-keys` hash, Team B uses whichever the existing tab-switch wiring honors. |
| Team B re-introduces a server-side `GET /v1/auth/apikey` endpoint that exposes raw keys | Low | Critical | Team B instructions explicitly forbid this. Decision record `docs/decisions/copy-api-key-dead-affordance.md` must articulate why this is rejected. |
| Team B's E2E test for the LOGIN path can't assert clipboard write because the fix is a redirect — test is misclassified as failing | Medium | Low | Team B instructions explicitly note the retest envelope's clipboard-write assertion only fires for the SIGNUP path. The logged-in path PASSes on a redirect-within-2s assertion. Document this in `team_b_verify.md`. |
| Team D commits before A or B merges, missing merge SHAs | Medium | Low | Team D is BLOCKED BY A AND B in the dependency graph. exec-plan enforces this. Worker reads SHAs from `git log --oneline main` AFTER A and B have merged. |
| Team D mints `missing-rest-endpoint` category when an existing tag fits | Low | Low | Plan recon confirmed no existing tag fits (12 categories listed: cli-server-state-mismatch, connection-toast-stuck, dashboard-state-sync, dead-affordance, dirty-state-tracker, info-leak, modal-stacking, onboarding-checklist, password-form-aria, plugin-registry-routing, trusted-types, vendor-bypass). NEW tag justified. |
| Phase 5.5 retest's clipboard-read assertion fires before the redirect lands and reports a false fail | Low | Medium | Team B's `team_b_verify.md` notes the redirect-within-2s alternate assertion path. Phase 5.5 retest agent reads `team_b_verify.md` for inline guidance. |

---

## Session Plan

### Session 1 — Parallel patches

**Parallel:** Teams A and B start immediately, in separate worktrees, NO shared files.

**Per-team gate after merge:**
- After A merge: `uv run pytest tests/api/test_orders.py tests/api/test_trade.py -x -q && uv run ruff check finlet/api/`
- After B merge: `bash scripts/lint-trusted-types.sh && npx playwright test tests/e2e/journey-04-settings-api-key.spec.ts`

**Merge order:** A first (server-side, cheaper validation), then B. Sequential merge per exec-plan model.

**Session checkpoint:** `uv run pytest -x -q` (full suite) + `bash scripts/lint-trusted-types.sh` (final).

### Session 2 — Docs

**Sequential:** Team D (after Session 1 complete; reads merge SHAs).

**Per-team gate after merge:** `git status docs/bug-hunt/20260503T195318Z43db/` clean; `tail -2 docs/bug-hunt/ledger.jsonl | jq -c .` succeeds; `wc -l` checks pass.

There is no Session 3 — this is a 2-session iteration (parallel code work in S1; docs in S2). No Team E this iteration because there is no refactor-queue verdict to set (no live refactor scoped this iteration).

---

## Phase 5.5 / Phase 6 hand-off (orchestrator scope, NOT a team)

After Session 1's push:
- Phase 5.5 polls the deploy workflow on `origin/main` until `conclusion=success` or timeout.
- On deploy success, Phase 5.5 spawns the retest agent which executes the 2 retest envelopes from `triage.json` against finlet.dev.
- Team B's retest envelope has a nuance: the LOGIN path is a redirect, not a clipboard write. `team_b_verify.md` documents this — the retest agent reads it inline.
- Phase 5.5c appends any `retest_status: fail` rows to `docs/bug-hunt/pending_recurrences.jsonl`.
- Phase 6 emits the final summary with deploy status, retest pass/fail, and ledger growth (+2 expected).

---

## Notes for the executor

- Worker type: `general-purpose` (Opus 4.7) per skill default. Server-side route alias + dashboard click-handler patch are both standard scope.
- Worktree isolation: required for Teams A and B (write to finlet/api/ and dashboard/ respectively). Team D touches docs/ only — worktree still recommended for hygiene but merge conflict risk is low.
- Team A and Team B have ZERO file overlap. Parallel-launch confirmed safe.
- Team B's decision (Option 1: redirect on logged-in path) is documented in the plan; if the executing agent wants Option 2 (remove button entirely), they MUST update the decision record AND the plan's risk register before merging — but the recommended path is Option 1.
