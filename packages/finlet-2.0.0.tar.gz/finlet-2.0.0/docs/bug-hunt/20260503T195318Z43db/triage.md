## Broken (will be fixed this iteration)
- GET /v1/sessions/{id}/orders returns 404 — order-listing REST endpoint missing. A trade was successfully placed via POST /v1/sessions/{id}/trade/order (201) and visible in the dashboard order log, but agents querying orders via REST get 404. [evidence: "Network log request #34: [GET] /v1/sessions/c534213e0551/orders => 404 ... POST /v1/sessions/c534213e0551/trade/order => 201"] [scope hint: finlet/api/routes_session.py, finlet/api/routes_orders.py (if missing), tests/api/test_orders.py]
- "Copy API Key" user-menu affordance is a dead button — clicking it fails to retrieve the real API key. sessionStorage.finlet_api_key contains the literal string "session" (not a key), and the only programmatic retrieval path GET /api/user/apikey returns 404. [evidence: "After login, sessionStorage.getItem('finlet_api_key') === 'session' (the string, not a key). The user-menu 'Copy API Key' click did not populate window.__capturedApiKey (clipboard interception found nothing). Probing GET /api/user/apikey returned 404"] [scope hint: dashboard/app.js (user-menu Copy API Key handler), dashboard/index.html, finlet/api/routes_auth.py / routes_user.py]

## Logged (not actioned)
- Finlet Benchmark MCP tool not registered in this Claude Code session — agent traded via UI fallback. [classification: working-as-designed] (launcher clean-room PATH issue, not a finlet.dev product bug)
- news_s3 plugin DEGRADED + Ingest button "no progress feedback" — prior iteration 20260503T030227Z2009 (commit cbd8340) shipped aria-busy + ingest-pending span + button text-swap within ~500ms of click; Phase 5.5 retest confirmed all assertions PASS post-deploy. Blind report has no click-moment screenshot to refute prior fix. [classification: needs-investigation]
- finnhub/fred/edgar plugins UNHEALTHY without API key signup guidance — UNHEALTHY status is correct (plugins genuinely need keys); missing help links is a UX gap. [classification: annoying]
- Settings sidebar has both "API Keys & Security" and "API Keys" — purpose unclear. [classification: annoying]
- SIM TIME metric card wraps "2024-01-01 00:00:00 UTC" across 4 lines — narrow card breaks ISO datetime mid-value. [classification: annoying]
- Clock defaults to FROZEN on every new session with no tooltip/onboarding hint. [classification: annoying]
- Plugin health status strings ("OK -- 21 cached files", "plugin not initialized") are developer-facing debug copy. [classification: annoying]
- UI Trade Ticket has no Reasoning field — manual trades log "--" in Reasoning column. [classification: annoying]
- Playwright ref-based input targeting fails stochastically on auth page — required JS fallback. [classification: annoying]
- Onboarding wizard persona cards are <button role='radio'> not native radios — Continue stayed disabled until JS click. [classification: annoying]
- No "step clock" prompt or auto-advance after first trade — P&L stays at +$0.00 with no guidance. [classification: nice-to-have]
- No API key management UI — can't view masked key, regenerate it, or see creation date. [classification: nice-to-have]
- No third-party API key signup links on Plugin Configuration page. [classification: nice-to-have]
- No Strategies section — no way to define/name/version trading hypotheses inside the app. [classification: nice-to-have]
- fundamentals_s3 shows "21 cached files" with no ticker/date-range coverage indication. [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260503T195318Z43db — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake. Lessons must be reusable rules, not a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made.
6. `docs/bug-hunt/20260503T195318Z43db/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json,
   blind_report.parsed.json, cleanup.log, blind_stdout.log, blind_stderr.log,
   team_*_verify.md, deploy_status.txt, retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260503T195318Z43db","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. Validation hint: after Team E commits,
   `wc -l docs/bug-hunt/ledger.jsonl` should grow by exactly the number of
   broken items closed this iteration (expected: +2).
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline.
   Team D MUST stage the file. If a refactor verdict pruned entries this iteration,
   Team D MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`.

Team D's commit message must reference iteration 20260503T195318Z43db and name which docs were
touched (e.g., "docs: bug-hunt 20260503T195318Z43db — record fixes for X; LESSONS +N; ledger +2").
