# Team A — Verify: GET /v1/sessions/{id}/orders alias

## Phase 5.5 retest envelope (verbatim from triage.json)

```json
{
  "kind": "curl",
  "description": "Verify GET /v1/sessions/{id}/orders returns 200 with a list-shaped order response (not 404) on the live deploy",
  "setup": "Requires a valid X-API-Key (export FINLET_API_KEY=...) and an existing session_id with at least one filled order. Create session: POST /v1/sessions with template payload; place order: POST /v1/sessions/{id}/trade/order body={\"symbol\":\"AAPL\",\"side\":\"BUY\",\"quantity\":1,\"order_type\":\"MARKET\"}; capture session_id from creation response.",
  "trigger": "curl -sS -o /tmp/orders.json -w '%{http_code}\\n' -H \"X-API-Key: $FINLET_API_KEY\" \"$FINLET_BASE_URL/v1/sessions/$SESSION_ID/orders\"",
  "assertions": [
    "HTTP status code is 200 (not 404)",
    "Response body parses as JSON",
    "Response body contains a list/array of orders (e.g., top-level array OR an object with key 'orders' / 'items' / 'data' that is an array)",
    "Each order in the list contains at minimum: order_id (or id), symbol, side, quantity, status fields",
    "When the session has a filled AAPL BUY, that order is present in the response"
  ],
  "cleanup": "rm -f /tmp/orders.json (the test session is left in place — sessions aren't deleted by this retest)"
}
```

## Implementation summary

- Added `GET /sessions/{session_id}/orders` and `GET /sessions/{session_id}/orders/{order_id}` aliases in `finlet/api/routes_session.py`. They call the existing `list_orders` / `get_order` services in `finlet/api/services/trade_service.py` — no business-logic fork.
- `routes_session.py` has no router prefix, so the new routes mount at `/sessions/{id}/orders` (and via the `/v1` group at `/v1/sessions/{id}/orders`). The existing `/sessions/{id}/trade/orders` routes in `routes_trade.py` are untouched.
- Auth + ownership shared with the trade route: `Depends(require_user)` + `get_user_session(session_id, user)`.
- Response shape unchanged: `list[OrderResponse]`.

## New tests (`tests/api/test_orders.py`)

| Test | Status |
|------|--------|
| `test_list_orders_returns_200_with_list` | pass |
| `test_list_orders_includes_submitted_order` | pass |
| `test_status_filter_works` | pass |
| `test_unauthenticated_returns_401` | pass |
| `test_get_order_by_id_alias` | pass |
| `test_get_order_by_id_alias_not_found` | pass |
| `test_alias_response_matches_trade_orders` | pass |

Regression: `tests/api/test_trade.py` continues to pass (existing `/trade/orders` route unaffected).
