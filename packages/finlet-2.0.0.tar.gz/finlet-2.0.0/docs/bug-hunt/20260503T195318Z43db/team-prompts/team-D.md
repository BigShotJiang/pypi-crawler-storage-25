You are Team D.

### Team D: Documentation updates per Required Docs Updates block

**Blocked by:** A + B (need merge SHAs from both for the ledger and to know what shipped for LESSONS).

**Read these files first** (with `path:line` attribution):

- `docs/bug-hunt/20260503T195318Z43db/triage.md:22-59` — the Required Docs Updates block. **Authoritative scope.**
- `docs/bug-hunt/20260503T195318Z43db/triage.json` — finding-specific summaries.
- `docs/REMAINING_TASKS.md` — most recent "Bug Hunt YYYYMMDD — Closed" subsection (look at the prior iteration `20260503T030227Z2009`) for pattern.
- `docs/LESSONS.md` — most recent additions for tone/format. Lessons must be REUSABLE RULES, not diff recaps.
- `docs/ARCHITECTURE.md` — header sections; verify whether the route surface section needs a line for `GET /v1/sessions/{id}/orders` (Team A added it).
- `docs/KNOWN_FAILURES.md` — pre-flight refresh; remove anything resolved.
- `docs/bug-hunt/ledger.jsonl` — last 5 lines for schema/category vocabulary. Confirm `dead-affordance` exists (it does, 3 entries) and confirm `missing-rest-endpoint` is NEW (it is — minted this iteration).
- `docs/bug-hunt/pending_recurrences.jsonl` — current pending entries; orchestrator may have appended in Phase 5.5c.
- `docs/decisions/copy-api-key-dead-affordance.md` — Team B's decision record (read after B merges).
- Team A and Team B's commits + verify.md files (read after their merges land on `main`).

**Files touched:**

- Modified: `docs/REMAINING_TASKS.md` — append "Bug Hunt 20260503T195318Z43db — Closed" subsection listing the 2 broken items + their merge SHAs.
- Modified: `docs/LESSONS.md` — append at least one new lesson per real-broken finding (so 2 lessons minimum). Suggested:
  - "When an HTTP route 404s but the underlying service is correct, look for a router-prefix mismatch first. The blind agent expected `/v1/sessions/{id}/orders`; the route lives at `/v1/sessions/{id}/trade/orders`. Both shapes are reasonable — ship aliases for the shape ecosystem code is more likely to type. (How to apply: when adding a router prefix, search the codebase + docs for callers using the prefix-less form and add an alias if found.)"
  - "When a UI affordance silently fails for one auth path but works for another, look for a sentinel value vs. real value confusion. The dashboard's `sessionStorage.finlet_api_key` was an INTENTIONAL marker ('cookie' | 'memory' | 'session') indicating WHICH auth path is active — NOT the key. The API key itself was never retrievable post-cookie-session-handshake (correct security model). The bug was a dead button shipping anyway. (How to apply: when storage holds a sentinel, name the variable to indicate the sentinel-ness — `auth_path_marker` not `finlet_api_key`. Or remove the affordance that depends on the value being the key.)"
- Modified: `docs/ARCHITECTURE.md` — add a line under the route surface section noting the new `GET /v1/sessions/{id}/orders` alias. If the route surface section doesn't list every endpoint, add only the high-level note: "Order listing exposed at both `/sessions/{id}/orders` and `/sessions/{id}/trade/orders` post-20260503T195318Z43db." If untouched otherwise, state in commit message explicitly.
- Modified: `docs/KNOWN_FAILURES.md` — pre-flight refresh; remove anything resolved this iteration.
- Add: `docs/decisions/copy-api-key-dead-affordance.md` — Team B writes this as part of their fix; Team D verifies it's tracked + commits if untracked.
- Modified: `docs/bug-hunt/ledger.jsonl` — APPEND exactly 2 new JSON lines (one per real-broken closed):
  ```jsonl
  {"iteration_ts":"20260503T195318Z43db","finding_id":"sessions-orders-route-alias","category":"missing-rest-endpoint","summary":"Add GET /v1/sessions/{id}/orders alias to existing trade-prefixed orders route","scope_files":["finlet/api/routes_session.py","tests/api/test_orders.py"],"team":"A","commit":"<merge-sha-A>"}
  {"iteration_ts":"20260503T195318Z43db","finding_id":"copy-api-key-redirect-on-cookie-session","category":"dead-affordance","summary":"User-menu Copy API Key redirects to Settings when no key in memory; never writes literal 'session' to clipboard","scope_files":["dashboard/shared-nav.js","dashboard/settings.html","docs/decisions/copy-api-key-dead-affordance.md"],"team":"B","commit":"<merge-sha-B>"}
  ```
  Read merge SHAs from `git log --oneline main -10` AFTER A and B have merged. Suggested slugs above; adjust if the actual commit message uses a different slug. **`missing-rest-endpoint` is a NEW category** — confirmed no existing tag fits (`info-leak`, `dashboard-state-sync`, `dead-affordance`, etc. don't describe a missing route).
- Stage (NOT modified by Team D unless orchestrator wrote): `docs/bug-hunt/pending_recurrences.jsonl` and (if pruning happened) `docs/bug-hunt/pending_recurrences.resolved.jsonl`.
- Stage: every artifact in `docs/bug-hunt/20260503T195318Z43db/` produced this iteration:
  - `plan.md` (this file)
  - `triage.md`, `triage.json`
  - `blind_report.json`, `blind_report.parsed.json`
  - `cleanup.log`, `blind_stdout.log`, `blind_stderr.log`
  - `team_a_verify.md`, `team_b_verify.md` (after A and B commit them)
  - `deploy_status.txt`, `retest_results.json` (orchestrator-emitted in Phase 5.5)

**Deliverable:** A single docs commit on `main` titled `docs: bug-hunt 20260503T195318Z43db — close 2 broken (sessions/orders alias, Copy API Key redirect); LESSONS +2; ledger +2` with all the docs and artifacts above staged + committed.

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` grew by exactly 2 (one per real-broken closed)
- [ ] `jq -c . docs/bug-hunt/ledger.jsonl | tail -2` parses cleanly (every new line is valid JSON, has all 7 schema fields: iteration_ts, finding_id, category, summary, scope_files, team, commit)
- [ ] `git status docs/bug-hunt/20260503T195318Z43db/` shows no untracked files in the iteration dir
- [ ] `docs/REMAINING_TASKS.md` has a "Bug Hunt 20260503T195318Z43db — Closed" subsection
- [ ] `docs/LESSONS.md` grew by ≥6 lines (2 lessons minimum, ~3 lines each)
- [ ] Commit message contains `20260503T195318Z43db` and `bug-hunt`

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Commit message: as in Deliverable above. Use a HEREDOC for multi-line clarity.
- LESSONS.md entries must be REUSABLE RULES, not "we fixed X by doing Y." Pattern: "When you see <symptom>, suspect <class of cause> first. Why: <past incident>. How to apply: <where to look>."
- Read merge SHAs from `git log --oneline main -10` AFTER A and B merge. Do not guess.
- The category `missing-rest-endpoint` is NEW — confirmed in plan recon that no existing ledger tag fits. Use it for Team A's entry.
- If Team B's `docs/decisions/copy-api-key-dead-affordance.md` is missing on main when D runs, prompt fail-fast (do not write a placeholder); the decision MUST come from Team B's understanding of why redirect > silent-fail.

---


CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read merge SHAs from `git log --oneline main -10` AFTER A and B merge — do not guess.
- You MUST `git add` and `git commit` before finishing.
- Commit message format: `docs: bug-hunt 20260503T195318Z43db — close 2 broken (sessions/orders alias, Copy API Key redirect); LESSONS +2; ledger +2`
- Validation: `wc -l docs/bug-hunt/ledger.jsonl` should grow by exactly 2.

When done, reply with: DONE + commit hash + ledger line count delta, OR BLOCKED. Keep reply under 150 words.
