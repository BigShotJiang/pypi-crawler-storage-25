You are Team A.

### Team A: Missing REST endpoint — `GET /v1/sessions/{id}/orders`

**Blocked by:** none — can start immediately.

**Read these files first** (with `path:line` attribution):

- `finlet/api/routes_trade.py:125-141` — existing `GET /sessions/{session_id}/trade/orders` route (`list_orders_route`). The handler that already does the right thing — pattern + service call to mirror.
- `finlet/api/routes_trade.py:29` — router prefix is `/sessions/{session_id}/trade`. **This is why the non-`/trade/` URL 404s.**
- `finlet/api/services/trade_service.py:167` — `list_orders(session, filter_status)` service function. The new alias must call this same service (don't fork business logic).
- `finlet/api/routes_session.py:34` — `router = APIRouter(tags=["sessions"])` (no prefix). Plain `/sessions/{session_id}/...` routes live here. **This is the natural home for the new alias.**
- `finlet/api/routes_session.py:1-30` — module docstring + imports. Add a single import line for `list_orders` from `trade_service` and `OrderResponse` from `schemas.trade`.
- `finlet/api/schemas/trade.py` — `OrderResponse` Pydantic model (response shape).
- `finlet/api/auth.py:18` — `require_user` import (used to gate the new route).
- `finlet/api/deps.py` — `get_user_session(session_id, user)` — same auth+ownership check the trade route uses.
- `finlet/api/app.py:498-501` — `v1_router.include_router(r)` is the registration loop. If `routes_session.py` is the home of the new route, no app.py change is needed (already registered). If a new module is created, app.py must include it here.
- `tests/api/test_trade.py:81` — existing test for `GET /sessions/{id}/trade/orders` returning 200. Pattern to mirror in the new `test_orders.py` (or extend `test_trade.py`).
- `tests/api/test_e2e.py:272-853` — e2e patterns for orders flow.
- `docs/bug-hunt/20260503T195318Z43db/triage.json` — the verbatim retest envelope reproduced below.

**The decision (where to register the alias):**

Two viable shapes — pick ONE and document why in the commit message:

1. **In `routes_session.py`**: add a `GET /sessions/{session_id}/orders` route at the bottom of the file. Import `list_orders` from `trade_service`. Call it the same way `list_orders_route` does. **Cheaper** — one file change, ~15 lines added. Recommended.
2. **New `routes_orders.py`**: create a sibling router with its own prefix. Register it in `app.py`. **More files**, slightly cleaner separation. Only do this if Team A finds session-level orders semantics that diverge from trade-level (they don't, currently).

The shared service function `list_orders(session, filter_status)` MUST be the single business-logic source. **Do not** duplicate the body of `list_orders_route` — call the service, return its result.

**The fix scope:**

- The router prefix mismatch is ALL the bug is. The agent expects `/v1/sessions/{id}/orders`, the route lives at `/v1/sessions/{id}/trade/orders`.
- Add `GET /sessions/{session_id}/orders` (and optionally `GET /sessions/{session_id}/orders/{order_id}` for symmetry — but NOT required by triage; do it ONLY if the regression test in `tests/api/test_trade.py` is extended without contortion).
- Keep the existing `/trade/orders` endpoint intact — many existing tests rely on it. The new endpoint is an alias, not a replacement.
- Do NOT change `OrderResponse` schema, `list_orders` service, or the order data model.

**Files touched:**
- Modified: `finlet/api/routes_session.py` — add `GET /sessions/{session_id}/orders` (and maybe `/orders/{order_id}`) route(s) at the end of the file. Import what you need from `trade_service`, `schemas.trade`, `core.orders`.
- New: `tests/api/test_orders.py` — pytest module with at minimum:
  - test that `GET /v1/sessions/{id}/orders` returns 200 (not 404) with a list-shaped body
  - test that the response includes a known filled order placed via `POST /trade/order`
  - test that `?status=FILLED` query param filters
  - test that an unauthenticated call returns 401 (or 404 per the deny-by-default contract — match the existing pattern at `tests/api/test_trade.py:81`)
- (Optional) Modified: `tests/api/test_trade.py` — add a sanity assertion that the existing `/trade/orders` endpoint still returns 200 and equals the new `/orders` response (parity check).
- (Only if going with option 2) New: `finlet/api/routes_orders.py` + Modified: `finlet/api/app.py:500` to register the new router.

**Deliverable:** `GET /v1/sessions/{id}/orders` returns 200 with a list of orders for the authenticated session owner. Mirrors `/trade/orders` semantics 1:1. Filed orders are visible. Status filter works.

**Validation:**
- [ ] `uv run pytest tests/api/test_orders.py -x -q` passes (new module, ≥3 tests)
- [ ] `uv run pytest tests/api/test_trade.py -x -q` passes (no regression on existing route)
- [ ] `uv run pytest tests/api/test_e2e.py -x -q` passes (no e2e regression)
- [ ] `uv run ruff check finlet/api/ tests/api/test_orders.py` passes
- [ ] `uv run mypy finlet/api/ --ignore-missing-imports` passes
- [ ] Manual curl sanity (post-deploy, in Phase 5.5): `curl -sS -o /tmp/o.json -w '%{http_code}\n' -H "X-API-Key: $FINLET_API_KEY" "$FINLET_BASE_URL/v1/sessions/$SESSION_ID/orders"` returns `200`.

**Phase 5.5 retest envelope (verbatim from triage.json — copy into `team_a_verify.md`):**

```json
{
  "kind": "curl",
  "description": "Verify GET /v1/sessions/{id}/orders returns 200 with a list-shaped order response (not 404) on the live deploy",
  "setup": "Requires a valid X-API-Key (export FINLET_API_KEY=...) and an existing session_id with at least one filled order. Create session: POST /v1/sessions with template payload; place order: POST /v1/sessions/{id}/trade/order body={\"symbol\":\"AAPL\",\"side\":\"BUY\",\"quantity\":1,\"order_type\":\"MARKET\"}; capture session_id from creation response.",
  "trigger": "curl -sS -o /tmp/orders.json -w '%{http_code}\\n' -H \"X-API-Key: $FINLET_API_KEY\" \"$FINLET_BASE_URL/v1/sessions/$SESSION_ID/orders\"",
  "assertions": [
    "HTTP status code is 200 (not 404)",
    "Response body parses as JSON",
    "Response body contains a list/array of orders (e.g., top-level array OR an object with key 'orders' / 'items' / 'data' that is an array)",
    "Each order in the list contains at minimum: order_id (or id), symbol, side, quantity, status fields",
    "When the session has a filled AAPL BUY, that order is present in the response"
  ],
  "cleanup": "rm -f /tmp/orders.json (the test session is left in place — sessions aren't deleted by this retest)"
}
```

**Agent instructions:**
- You MUST `git add` + `git commit` your work in your worktree before finishing — uncommitted work is destroyed when the worktree is cleaned up.
- Commit message format: `[Team A]: api: add GET /v1/sessions/{id}/orders alias (close missing-rest-endpoint)`
- Reuse the existing `list_orders` service function in `finlet/api/services/trade_service.py:167`. **Do not** duplicate the route body.
- The new route MUST share auth (`Depends(require_user)`) + session-ownership (`get_user_session(session_id, user)`) with the trade route — copy the dependency wiring exactly.
- Match the existing response shape: `list[OrderResponse]` (the same model as `/trade/orders`).
- DO NOT touch `OrderResponse`, `list_orders` (service), or `OrderBook.get_orders` (`finlet/core/orders.py:215`). Schema changes are out of scope.
- DO NOT remove or rename the existing `/trade/orders` route. It's the alias, the new one is the alias-friendlier-URL — both exist.
- Copy the Phase 5.5 retest envelope above into `docs/bug-hunt/20260503T195318Z43db/team_a_verify.md` for traceability, plus the test names + their pass/fail status as your verify evidence.

---


CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns in those files (especially `routes_trade.py:125-141` for the route shape).
- You MUST `git add` and `git commit` all your changes before finishing — uncommitted work in worktrees is destroyed when cleaned up.
- Your commit message must start with "[Team A]:".
- Run the validation commands from your spec before finishing.
- If validation fails, fix the issue and re-commit.
- Working dir is your isolated worktree. Find it with `git rev-parse --show-toplevel` if needed.

When done, reply with: DONE + commit hash + validation results, OR BLOCKED + what went wrong. Keep reply under 150 words.
