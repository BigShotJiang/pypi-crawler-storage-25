You are Team B.

### Team B: Dead-affordance — Copy API Key user-menu button

**Blocked by:** none — can start immediately.

**Read these files first** (with `path:line` attribution):

- `dashboard/shared-nav.js:301-326` — desktop user-menu Copy API Key click handler. Calls `FinletAuth.getApiKey()`; toast on success; **shows the misleading "No Key — Create a new API key in Settings" toast on failure**, but does NOT take the user to settings or open the key-creation flow.
- `dashboard/auth.js:1641-1645` — `FinletAuth.getApiKey()` definition. Returns `_inMemoryApiKey || sessionStorage.getItem('finlet_created_api_key') || null`. **The literal `'session'` from `sessionStorage.finlet_api_key` is NEVER returned by this function — that is `AUTH_STORAGE_KEY` and only stores a sentinel: 'cookie' | 'memory' | 'session'.** The blind agent confused the marker with the key.
- `dashboard/auth.js:760` — login flow sets `sessionStorage.setItem(AUTH_STORAGE_KEY, 'session')` AFTER successful POST `/auth/login`. The literal string 'session' is intentional: the cookie does the auth, this marker just says "auth path is alive". `_inMemoryApiKey` is NEVER populated on the login path.
- `dashboard/auth.js:815-821` — signup flow stores `data.api_key` into `_inMemoryApiKey` via `saveAuth(apiKey, ...)`. THIS is why a fresh signup tab can copy the key briefly; a logged-in tab cannot.
- `dashboard/auth.js:362-392` — `saveAuth(apiKey, user)`. After successfully exchanging the API key for a cookie session at `POST /auth/session`, it intentionally leaves `_inMemoryApiKey = null` and stores 'cookie' in sessionStorage. The key was used and discarded.
- `dashboard/settings.js:832` — when Settings creates a new named key, the raw key is shown ONCE and stored in `sessionStorage.finlet_created_api_key`. This sentinel is wiped on next page-nav cleanup (this is the one-time-display pattern).
- `dashboard/mobile-nav.js:174-195` — drawer's Copy API Key button. Calls `desktopCopyKey.click()` — i.e., it's a thin proxy to `shared-nav.js`'s handler. Fix the desktop handler and the drawer follows automatically.
- `finlet/api/routes_settings.py:78-94` — `GET /v1/settings/api-keys` (lists masked metadata only) + `POST /v1/settings/api-keys` (creates new key, returns raw value once). These endpoints already exist — Team B's fix uses them, not new ones.
- `finlet/api/services/settings_service.py:125-189` — `list_api_keys`, `create_api_key`, `revoke_api_key`, `rotate_api_key`. **Note `rotate_api_key` is destructive** — do not invoke from the user-menu Copy click.
- `dashboard/index.html:68`, `dashboard/settings.html:63`, `dashboard/billing.html:63`, `dashboard/leaderboard.html:62` — drawer-button markup `<button id="nav-drawer-copy-key">Copy API Key</button>`. Update label if button semantics change.

**The decision — what does "Copy API Key" mean if the key isn't retrievable?**

The button can be in one of three states by-design:

| Auth path | `_inMemoryApiKey` | `sessionStorage.finlet_created_api_key` | Copy result |
|-----------|-------------------|------------------------------------------|-------------|
| Just signed up (this tab) | populated | empty | works |
| Just rotated/created in Settings (this tab) | empty | populated | works |
| Logged in (any tab) OR refreshed signup tab | empty | empty | dead button (the bug) |

The fix MUST pick one of two paths:

**Option 1 (RECOMMENDED — graceful redirect):** When `getApiKey()` returns null, the click navigates to `settings.html#api-keys` (or opens a Settings → API Keys deep-link modal) where the user can create a NEW named key. Re-label the button to "Manage API Key" when no copyable key is in memory; keep "Copy API Key" + clipboard write when a key IS in memory. The button is no longer dead — it always does *something useful* on click.

**Option 2:** Remove the button entirely from `shared-nav.js:198` and the four `*.html` drawer files. Replace with a permanent "Manage API Keys" link. Cleaner for security model but loses the convenience for fresh-signup users.

**Pick Option 1.** Document the decision in `docs/decisions/copy-api-key-dead-affordance.md`. Cite this triage iteration.

**The fix scope:**

- `shared-nav.js:301-326` (desktop handler): on click, if `FinletAuth.getApiKey()` returns a string (truthy non-empty), do the existing clipboard write + toast. If it returns null/empty, redirect to `settings.html?tab=api-keys` (or whatever Settings tab anchor is current — verify in `dashboard/settings.js`). Show a toast message: "Open Settings to create a new key" rather than the current misleading "No Key — Create a new API key in Settings".
- Optionally: re-label the button TEXT dynamically to "Manage API Key" when no copyable key is in memory. Read `FinletAuth.getApiKey()` on user-menu open (the `trigger.addEventListener('click', ...)` at `shared-nav.js:278-282`) and toggle `copyKeyBtn.textContent` accordingly.
- Drawer mobile button (`mobile-nav.js:175-195`) automatically inherits the fix because it `.click()`s the desktop button (line 180).
- DO NOT add a new server endpoint. The blind agent probed `GET /api/user/apikey` and got 404 — that endpoint should NEVER exist (it would expose hash-stored keys in plaintext). Don't even tempt it.
- DO NOT auto-invoke `rotate_api_key` on click — that's destructive (user's existing keys still in flight in their agents would break).

**Files touched:**
- Modified: `dashboard/shared-nav.js` — line 301-326 click handler. ~15 lines changed.
- Modified: `dashboard/index.html`, `dashboard/settings.html`, `dashboard/billing.html`, `dashboard/leaderboard.html` — only if the drawer button label changes (or stays "Copy API Key" with click-time relabel JS — preferred). Static HTML changes preferred OFF; dynamic JS toggle preferred ON.
- New: `docs/decisions/copy-api-key-dead-affordance.md` — 1-page record of why the button now redirects vs. exposes raw key.
- New / extended: `tests/e2e/journey-04-settings-api-key.spec.ts` — Playwright assertion that:
  - logged-in user clicks Copy API Key → redirected to `settings.html#api-keys` (or modal opens)
  - signed-up user (with `_inMemoryApiKey` populated) → clipboard receives a real key
  - clipboard never receives literal string `'session'`

**Deliverable:** Clicking "Copy API Key" never silently fails. Either (a) writes a real key to the clipboard (signup/rotate path), OR (b) redirects to Settings → API Keys (login path). The clipboard NEVER receives the literal string `'session'`.

**Validation:**
- [ ] `bash scripts/lint-trusted-types.sh` passes (no new raw `.innerHTML =` writes)
- [ ] `npx playwright test tests/e2e/journey-04-settings-api-key.spec.ts` passes (new assertion)
- [ ] No regression in `npx playwright test tests/e2e/journey-01-onboarding.spec.ts tests/e2e/journey-05-trade.spec.ts`
- [ ] Manual: log in (don't sign up); click Copy API Key in user menu → verify redirect to `settings.html#api-keys` (or modal); verify clipboard does NOT contain 'session'.
- [ ] Manual: sign up; immediately click Copy API Key → clipboard contains a real key (not 'session', length ≥20).
- [ ] `docs/decisions/copy-api-key-dead-affordance.md` exists with sections: Context, Decision, Alternatives Rejected, Consequences.

**Phase 5.5 retest envelope (verbatim from triage.json — copy into `team_b_verify.md`):**

```json
{
  "kind": "playwright",
  "description": "Verify clicking 'Copy API Key' in the user menu writes a real API key (not the literal 'session') to the clipboard and the underlying retrieval endpoint returns 200",
  "setup": "Login flow at $FINLET_BASE_URL/auth.html with E2E test credentials; clipboard read must be granted via context.grantPermissions(['clipboard-read', 'clipboard-write']); attach a window.__capturedApiKey hook before clicking by overriding navigator.clipboard.writeText to capture the value; install network listener for any /apikey or /api-key request to record its status.",
  "trigger": "Navigate to $FINLET_BASE_URL/index.html; click user-menu trigger button; click 'Copy API Key' menu item; await network idle.",
  "assertions": [
    "navigator.clipboard.readText() (or window.__capturedApiKey) returns a non-empty string distinct from the literal 'session'",
    "The captured value matches the API key format (e.g., starts with 'sk-' or matches the project's documented key prefix; min length >= 20 chars)",
    "If the click triggers an XHR/fetch to a /apikey or /api-key route, that request returns HTTP 2xx (not 404)",
    "No console error containing '404' or 'Failed to load resource' fires from the click action",
    "If the dashboard does NOT make a network call (key already cached), the cached value is also not the literal string 'session'"
  ],
  "cleanup": "page.close() — no server-side state created"
}
```

**Note for Team B agent:** the Phase 5.5 retest envelope's first three assertions assume the fix WRITES a key to the clipboard. With Option 1 (redirect when no key in memory), the retest agent for the LOGGED-IN path will NOT see a clipboard write — it will see a navigation to Settings. The retest harness should treat "no clipboard write but valid Settings → API Keys redirect within 2s" as PASS, and "clipboard contains the literal 'session'" as the strong-fail signal. Document this nuance in `team_b_verify.md` so the Phase 5.5 retest agent has it inline. If the retest harness can only assert clipboard contents, the test should be run with a SIGNUP fixture (where `_inMemoryApiKey` IS populated) to satisfy the clipboard-write assertion path.

**Agent instructions:**
- You MUST `git add` + `git commit` your work in your worktree before finishing.
- Commit message format: `[Team B]: dashboard: Copy API Key button redirects to Settings on cookie-session path (close dead-affordance)`
- Follow the existing event-binding pattern in `dashboard/shared-nav.js:301-326`. Use `showToast({type, title, message})` (object form) — see `dashboard/app.js` for canonical signature.
- DO NOT add a new server endpoint. Specifically DO NOT add `GET /v1/auth/apikey` or `GET /v1/user/apikey` — those would compromise the hash-only key storage model.
- DO NOT auto-invoke `POST /v1/settings/api-keys/rotate` on click — that's destructive.
- Use `window.location.href = 'settings.html?tab=api-keys'` (or the existing tab anchor — verify in `dashboard/settings.js`) for the redirect path.
- Document the decision in `docs/decisions/copy-api-key-dead-affordance.md`. Cite the triage iteration `20260503T195318Z43db` and explain why redirect > silent fail > rotate-and-copy > expose raw key.
- Copy the Phase 5.5 retest envelope above into `docs/bug-hunt/20260503T195318Z43db/team_b_verify.md` (with the nuance note about clipboard vs. redirect for logged-in path).

---


CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the "Read these files first" list BEFORE writing any code (the auth.js + sentinel-vs-key insight is essential).
- Follow existing patterns in those files (`shared-nav.js:301-326` for click handler, `auth.js:1641-1645` for getApiKey contract).
- DO NOT add any server endpoint that exposes raw API keys (e.g., GET /v1/auth/apikey, GET /v1/user/apikey). Hash-only key storage is a load-bearing security invariant.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message must start with "[Team B]:".
- Run the validation commands from your spec before finishing (lint-trusted-types.sh + Playwright if you can).
- If you can't run Playwright in the worktree (no playwright deps), document that in your reply and just run the lint + manual reasoning checklist.

When done, reply with: DONE + commit hash + validation results, OR BLOCKED + what went wrong. Keep reply under 150 words.
