# Bug-Hunt 20260428T013300Z6e79 — Execution Plan

> Generated from `triage.md` (8 broken items). Last updated: 2026-04-27.
> 8 bugs grouped into **4 teams** by file ownership and natural cohesion.

## Constraints

- Tech stack: Python 3.12 async, FastAPI, vanilla HTML/JS dashboard (no build step).
- Worktree isolation: every team writes in its own worktree, merges to `main` sequentially.
- Per-merge gate: targeted `pytest`/manual smoke after each merge; full suite at session end.
- Worker type: `general-purpose` (Opus 4.7, default for SWE-Bench Pro work).
- File ownership map (CLAUDE.md):
  - `dashboard/` -> dashboard team
  - `finlet/api/` -> api team
  - `finlet/core/` -> engine team
- All datetimes UTC. No new sync I/O. No new direct `s3_client.put_object`.
- Pre-existing fix (commit `fc2a212`) already shipped `orders_filled` schema + dashboard tile rewrite. Plan accounts for this.

## File Conflict Table

| File | Touched by Teams |
|------|------------------|
| `dashboard/index.html` | A (modal style fix), B (Sentry script tag, checklist link), C (no edits — read-only verify) |
| `dashboard/styles.css` | A (dedupe `.modal-overlay` rules) |
| `dashboard/app.js` | A (modal open/close), B (none — checklist lives in onboarding.js) |
| `dashboard/leaderboard-submit.js` | A (success-path UI feedback), B (none) |
| `dashboard/onboarding.js` | B (export + dead-affordance hardening) |
| `dashboard/api-utils.js` | B (route SVG injection through `finlet-default` policy) |
| `dashboard/auth.html` | B (Sentry removal, optional `goog#html` allow) |
| `dashboard/landing.html` | B (Sentry removal — currently no Sentry tag, verify) |
| `finlet/api/security_middleware.py` | B (CSP `trusted-types` directive — add `goog#html`) |
| `finlet/core/portfolio.py` | C (verify-only, no edit expected) |

**No two write-teams touch the same file.** Team A owns dashboard interaction fixes; Team B owns dashboard hardening + 1 middleware file; Team C is verify-only on engine code. Teams A and B can run in parallel.

## Dependency Graph

- **Team A — Dashboard Interaction Fixes** (independent) — can start immediately.
- **Team B — Frontend Hardening & CSP** (independent) — can start immediately.
- **Team C — trade_count Verification** (independent, verify-only) — can start immediately.
- **Team D — Documentation & Lessons Update** (blocked by A, B, C) — runs once others are merged.

No cross-team file conflicts. A, B, C run concurrently in separate worktrees. D merges last.

## Critical Path

`Team A (or B — whichever is longer) -> Team D`

A and B each touch ~4–5 files of dashboard JS/HTML/CSS plus 1 middleware (B). A is the heaviest because it requires manual browser smoke testing of the modal stacking and the leaderboard success toast. C is a 5-minute API curl + grep. D is a 10-minute doc bump.

---

## Teams

### Team A: Dashboard Interaction Fixes (modal blocking + leaderboard submit feedback + dead checklist link)

**Bug coverage:** triage items #1 (modal stacking), #3 (Connection Lost toast on submit), #8 (no leaderboard submit feedback).

**Blocked by:** none — can start immediately.

**Read these files first:** (CRITICAL — prevents agents from rebuilding what's already there)
- `dashboard/styles.css` lines 383–422 AND lines 3120–3160 — there are TWO `.modal-overlay` rule blocks. The first (line 383) sets `display: flex` with no opacity/visibility transition; the second (line 3123) is the modern rule with `opacity:0; visibility:hidden`. Cascade winner = the second, but the first is a footgun and any edit to either MUST account for both. Pick ONE definition (the modern one) and delete the other.
- `dashboard/index.html` lines 358–488 — current markup for `#create-session-modal`, `#delete-session-modal` (which has inline `style="display:none"`), and `#leaderboard-submit-modal`. Note that `delete-session-modal` ships defensive inline styling and the others do not. Decide whether to add inline `style="display:none"` defensively, OR rely solely on the `--visible` class toggle after CSS dedup.
- `dashboard/app.js` lines 1095–1210 — `initCreateSessionModal`, `openCreateSessionModal`, `closeCreateSessionModal`. They toggle `modal-overlay--visible`. Pattern is correct; do not change it.
- `dashboard/leaderboard-submit.js` lines 60–162 — `openLeaderboardSubmitModal` / `closeLeaderboardSubmitModal` use the same `modal-overlay--visible` pattern. Lines 240–280 — the success path hides `#lb-submit-form-body` + `#lb-submit-footer` and shows `#lb-submit-loading`. After polling (lines 277–end) it should render a result card, but the bug is that on the happy 202 path the user only sees the spinner area; if the polling is interrupted by an SSE blip (the Connection Lost toast), the form stays open with no terminal toast/state.
- `dashboard/app.js` lines 2220–2260 — `updateConnectionStatus()` is the source of the `Connection Lost` toast. It fires whenever `status === 'disconnected' && prevStatus !== 'disconnected'`. The leaderboard submit POST does NOT touch SSE, so the toast must be coming from EventSource flapping during the submit. Investigate whether `apiPost('/leaderboard/submit', ...)` triggers a status change or whether unrelated SSE retry coincides. If the toast is unrelated, suppress it during active leaderboard submit (set a flag), OR ensure the leaderboard success path always shows its own success toast that visibly outranks the connection toast.

**Files touched:**
- Modified: `dashboard/styles.css` — dedupe `.modal-overlay` (delete the line 383–391 block; keep the line 3123 block).
- Modified: `dashboard/index.html` — defensively add `style="display:none"` to `#create-session-modal` and `#leaderboard-submit-modal` (matches existing `#delete-session-modal` pattern). Belt-and-suspenders against any future CSS regression.
- Modified: `dashboard/app.js` — `openCreateSessionModal` and `closeCreateSessionModal` MUST also toggle inline `style.display` (set to '' on open, 'none' on close) so the inline defensive style does not trap the modal closed.
- Modified: `dashboard/leaderboard-submit.js` — same inline-style toggle in `openLeaderboardSubmitModal` / `closeLeaderboardSubmitModal`. AND: in `handleLeaderboardSubmit` (lines 211–250), on a successful 202 immediately call `showToast({type:'success', title:'Submission accepted', message:'Job ID ' + result.job_id + '. Polling for results...'})` so the user sees confirmation BEFORE the polling begins. Also suppress connection-lost toast during the submit poll: set `window._lbSubmitInFlight = true` on submit, clear on completion; have `updateConnectionStatus` skip showing `connection-lost` toast when this flag is set.
- Modified: `dashboard/app.js` `updateConnectionStatus` — read `window._lbSubmitInFlight` and skip the `Connection Lost` toast when truthy. The header dot still updates (so the user can see state) but the persistent overlay toast is gated.

**Deliverable:** After this team finishes:
1. Loading the dashboard does NOT show any modal until the user clicks an open trigger.
2. Clicking "Submit to Leaderboard" opens ONE modal with no overlap.
3. Clicking the submit button shows a success toast within 500 ms of the 202 response.
4. The "Connection Lost" toast does NOT appear during a happy-path leaderboard submit. Header dot may briefly turn yellow/red, but the persistent overlay toast is suppressed.

**Validation:**
- [ ] `uv run ruff check dashboard/` — no new violations (informational; dashboard has no enforced lint).
- [ ] Manual smoke (Playwright MCP or browser):
  - Load `/index.html` -> assert `getComputedStyle(document.getElementById('create-session-modal')).visibility === 'hidden'` and `display === 'none'`.
  - Same assertion for `#leaderboard-submit-modal`.
  - Click "New Session" -> create-session-modal visible. Click overlay -> hidden again.
  - Click "Submit to Leaderboard" -> leaderboard-submit-modal visible AND create-session-modal still hidden.
  - Submit valid form -> within 500 ms a success toast appears with the job id; no `Connection Lost` toast appears within 10 s.
- [ ] `uv run pytest tests/api/test_routes_leaderboard.py -x -q` — backend submit path still 202s.
- [ ] Manually cURL `POST /v1/leaderboard/submit` with a real session and confirm 202 + `job_id` shape unchanged.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message format: `[Team A] dashboard: dedupe modal-overlay CSS, defensive display:none, leaderboard submit success toast + connection-lost gating`.
- Use the EXACT pattern from `delete-session-modal` (inline `style="display:none"` + class toggle) — it is the proven defensive idiom in this codebase.
- Do NOT modify `dashboard/onboarding.js` — that is Team B.
- Do NOT modify `finlet/api/` — that is Team B's middleware-only edit.
- Do NOT touch `finlet/core/portfolio.py` — that is Team C.
- Keep changes additive in `app.js`/`leaderboard-submit.js`. Do not refactor the modal helpers.
- After commit, run the full validation block and capture screenshots/console output for the merge gate.

---

### Team B: Frontend Hardening (Sentry + Trusted Types + CSP + dead checklist export)

**Bug coverage:** triage items #4 (Sentry 403), #5 (Trusted Types default policy SVG injection), #6 (Google `goog#html` CSP block), #7 (`Save first strategy` checklist dead affordance — already half-fixed in onboarding.js but the `window.openLeaderboardSubmitModal` export is missing, fallback chain is fragile).

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/index.html` line 14 (`<meta name="sentry-dsn" content="YOUR_SENTRY_DSN_HERE">`) and line 589 (`<script src="https://browser.sentry-cdn.com/8.x/bundle.min.js" ...>`). The DSN is a placeholder. The CDN URL `8.x/bundle.min.js` does NOT exist on Sentry's CDN — they require a specific version path like `8.0.0/bundle.min.js`. There is NO `Sentry.init(...)` call anywhere in the codebase (`grep "Sentry.init" dashboard/*.js` returns 0 hits). The Sentry script is dead weight that produces a 403 on every page load. There is no `dashboard/sentry-init.js` despite the triage hint — file does not exist.
- `dashboard/api-utils.js` lines 405–474 — Trusted Types policy registration. Two policies are created: `finlet-default` (named) and `default` (catch-all that warns when invoked). The warning at line 441 fires every time some caller does `el.innerHTML = '<svg>...'` directly instead of `el.innerHTML = trustedHTML('<svg>...')`. The triage item is the WARN itself — not an error. To clear it, audit all `innerHTML = ...` assignments in dashboard JS and route through `trustedHTML(...)` (which is what `leaderboard-submit.js` already does at line 118).
- `dashboard/api-utils.js` line 107 — `div.innerHTML.replace(...)` is read-only inside `esc()`, not a sink. Safe.
- Run `grep -nrE "innerHTML\s*=" dashboard/ | grep -v trustedHTML | grep -v "//"` to enumerate every offending assignment. Triage hint says line 441 — that is the WARNING source, not the offender. The actual offenders are wherever the warning was logged in the user session.
- `finlet/api/security_middleware.py` lines 175–247 — CSP header construction. Line 214: `"trusted-types finlet-default default; "`. Google's `gsi/client.js` creates a Trusted Types policy named `goog#html`, which is rejected because that name is not in the `trusted-types` directive. Add `goog#html` to the allowlist. Note: `script-src` already includes `https://accounts.google.com` so the script LOADS, but the policy CREATION is blocked.
- `dashboard/auth.html` line 14 — `<script src="https://accounts.google.com/gsi/client" async defer></script>` is the Google Sign-In loader. This is where the `goog#html` Trusted Types violation surfaces.
- `dashboard/onboarding.js` lines 615–698 — `Save first strategy` checklist item. It IS clickable (lines 649–687 attach handlers, set `role='button'`, `tabindex='0'`). The handler tries `window.openLeaderboardSubmitModal` first, then bare `openLeaderboardSubmitModal`, then falls back to clicking `#btn-submit-leaderboard`. The triage agent saw `<div class='checklist-item'>` and assumed dead. The CTA fallback works but is fragile — `leaderboard-submit.js` does NOT export `openLeaderboardSubmitModal` to `window` (`grep "window.openLeaderboardSubmitModal" dashboard/leaderboard-submit.js` returns 0 hits). The bare-name lookup also fails because functions defined inside the IIFE in leaderboard-submit.js are not on the global scope. So in production it falls back to `cta.click()`. Harden by: (a) explicitly setting `window.openLeaderboardSubmitModal = openLeaderboardSubmitModal;` at the bottom of `leaderboard-submit.js`; (b) verify the checklist item now opens the modal directly (no CTA click intermediary).

**Files touched:**
- Modified: `dashboard/index.html` — DELETE line 589 (`<script src="https://browser.sentry-cdn.com/8.x/bundle.min.js" ...>`). DELETE line 14 (`<meta name="sentry-dsn" ...>`). DELETE the `data-feedback="sentry"` attribute on the Report-a-Bug link at line 572 if it gates on Sentry being loaded — verify by reading `dashboard/feedback.js`. If Sentry must stay (revenue-gated decision), pin the version: `https://browser.sentry-cdn.com/8.0.0/bundle.min.js` AND add `Sentry.init({ dsn: ..., ... })` in a new `dashboard/sentry-init.js` AND update CSP to allow it (already in `script-src`). Default decision: REMOVE the dead Sentry references; client error reporting already goes through `reportClientError()` in api-utils.js to `/v1/client-errors`.
- Modified: `dashboard/api-utils.js` — find every `innerHTML = '<svg ...>'` (and any other `innerHTML =` assignment outside `trustedHTML()`) and route through `trustedHTML()`. The warning at line 441 should fire ZERO times during normal authenticated dashboard navigation after this fix.
- Modified: `dashboard/leaderboard-submit.js` — at end of file (last line, after the closing `}` of the last function), add `window.openLeaderboardSubmitModal = openLeaderboardSubmitModal;` so the onboarding checklist's primary lookup path succeeds.
- Modified: `finlet/api/security_middleware.py` line 214 — change `"trusted-types finlet-default default; "` to `"trusted-types finlet-default default goog#html; "`. This allows Google Sign-In's policy creation without weakening any other restriction.
- Verified, NOT modified: `dashboard/landing.html` and `dashboard/auth.html` — confirmed no Sentry tags exist on those pages (recon grep returned 0 hits). Triage's "all pages" claim was wrong — only `index.html` has Sentry. Document this in the team's commit message.

**Deliverable:** After this team finishes:
1. No 403 on `browser.sentry-cdn.com` on any page load.
2. Trusted Types default-policy warning at api-utils.js:441 fires zero times during a clean dashboard navigation (load -> open session -> submit leaderboard -> close).
3. Google `goog#html` policy creation succeeds; no CSP violation in console on `/auth.html`.
4. Clicking the "Save first strategy" checklist row opens the leaderboard submit modal via the direct `window.openLeaderboardSubmitModal` path (verified by setting a breakpoint or temporary `console.log`).

**Validation:**
- [ ] `uv run pytest tests/api/test_security_middleware.py -x -q` — CSP header tests pass with new directive.
- [ ] `uv run ruff check finlet/api/security_middleware.py` — clean.
- [ ] `uv run ruff format --check finlet/api/security_middleware.py` — clean.
- [ ] Manual smoke: load `/index.html` in a fresh browser tab with DevTools open. Console MUST show:
  - Zero `403` errors.
  - Zero `[Finlet] Trusted Types default policy invoked` warnings during normal navigation.
- [ ] Manual smoke: load `/auth.html` -> console MUST NOT show `goog#html ... violates CSP directive`.
- [ ] Manual smoke: open dashboard, ensure onboarding checklist is visible, click "Save first strategy" row -> leaderboard submit modal opens. Confirm via DevTools that `window.openLeaderboardSubmitModal` is a function.
- [ ] `curl -sI http://localhost:8000/v1/health | grep -i 'content-security-policy'` -> contains `trusted-types finlet-default default goog#html`.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message format: `[Team B] frontend hardening: remove dead Sentry CDN, route SVG injection through finlet-default, allow goog#html Trusted Types policy, export openLeaderboardSubmitModal`.
- Do NOT modify `dashboard/styles.css` — that is Team A's territory (modal CSS dedup).
- Do NOT modify `dashboard/app.js` — that is Team A's territory (modal helpers + connection toast gating).
- Do NOT modify `dashboard/leaderboard-submit.js` beyond adding the `window.openLeaderboardSubmitModal` export at the bottom (Team A is editing the open/close/submit handlers).
- For the Sentry decision: default = REMOVE. If you encounter blockers (e.g., a launch checklist item demands Sentry), STOP and surface to the user — do not silently version-pin.
- For the Trusted Types audit: use `grep -nrE "innerHTML\s*=" dashboard/` and prioritize files that are loaded on the authenticated dashboard (`app.js`, `empty-states.js`, `onboarding.js`). Fix only the actual sinks — read-only `innerHTML` reads (like in `esc()`) are safe.
- After commit, paste the cleaned-up DevTools console transcript into the merge-gate notes.

---

### Team C: trade_count Verify-Only (no code change expected)

**Bug coverage:** triage item #2 (`trade_count` stays 0 after BUY fill).

**Blocked by:** none — can start immediately.

**Classification: VERIFY-ONLY. No code fix expected.** Commit `fc2a212` (2026-04-27, ~6 hours before the blind-agent run) shipped the complete fix:
- `finlet/core/portfolio.py` — added `_orders_filled` counter, incremented under the same lock as `_trade_pnls` at the same point in the fill flow (lines 179, 218). Property exposed at line 390.
- `finlet/api/schemas/portfolio.py` and `finlet/api/schemas/session.py` — `orders_filled: int = 0` added to both response schemas.
- `dashboard/app.js` lines 1743–1781 — three-case rendering: `0 trades` when nothing filled, `0 closed · X filled` when fills exist but nothing closed, `Y% / C closed · T filled` when at least one trade closed.
- `tests/core/test_portfolio.py` — 49 lines of new tests (per the commit diff).

The blind agent's claim "trade_count=0, win_rate=0, dashboard says '0.0% — 0 trades'" is technically CORRECT — `trade_count` IS the round-trip-trades counter, and the dashboard correctly distinguishes a freshly-filled BUY (no closed trade) from "no fills at all". The user's observation of "0 trades" likely means the agent hit the dashboard BEFORE the new build was live, OR the agent only ran the BUY (no SELL) and saw the literal `0 closed · X filled` text and misread it as "0 trades".

This team's job is to confirm the fix is live and behaves correctly. No source edits expected.

**Read these files first:**
- The git log: `git log --oneline -5 finlet/core/portfolio.py dashboard/app.js finlet/api/schemas/portfolio.py finlet/api/schemas/session.py`. Confirm `fc2a212` is in the current HEAD ancestry.
- `finlet/core/portfolio.py` lines 70–90 (dataclass + ctor), lines 175–225 (fill methods incrementing `_orders_filled`), lines 380–435 (properties + serializers).
- `dashboard/app.js` lines 1743–1781 — three-case rendering logic.
- `tests/core/test_portfolio.py` — find the new tests added by `fc2a212` and confirm they pass.

**Files touched:**
- None expected. If verification finds a real regression or incompleteness, ESCALATE to Team A or Team C-fix (do not silently fix in this team's worktree).

**Deliverable:** A short verification note (committed to `docs/bug-hunt/20260428T013300Z6e79/team_c_verify.md`) with:
1. The exact API response from `GET /v1/sessions/{id}` after a freshly-filled BUY — capture `portfolio_metrics.trade_count`, `portfolio_metrics.orders_filled`, `portfolio_metrics.win_rate`.
2. A screenshot or DevTools snippet of the Win Rate tile rendering, proving it shows `0 closed · 1 filled` (not `0 trades`).
3. A second API call after a matched SELL closes the round-trip — proving `trade_count` increments to 1 and the tile shows `1 trade` or `1 closed · 2 filled`.
4. Triage classification: `verify-only no-fix` (confirmed `fc2a212` is live and complete) OR `escalate to Team A` with specific reproducer steps.

**Validation:**
- [ ] `uv run pytest tests/core/test_portfolio.py -x -q -k orders_filled` — new tests added by `fc2a212` all pass.
- [ ] `uv run pytest tests/core/test_portfolio.py -x -q` — full portfolio test file passes (regression check).
- [ ] Live API check (running locally via `uv run finlet api`):
  - `POST /v1/sessions` to create a session.
  - `POST /v1/sessions/{id}/orders` with BUY 10 AAPL MARKET.
  - `POST /v1/sessions/{id}/clock/advance` to fill it.
  - `GET /v1/sessions/{id}` -> assert `portfolio_metrics.orders_filled == 1` and `portfolio_metrics.trade_count == 0`.
  - `POST /v1/sessions/{id}/orders` with SELL 10 AAPL MARKET.
  - `POST /v1/sessions/{id}/clock/advance` to fill it.
  - `GET /v1/sessions/{id}` -> assert `portfolio_metrics.orders_filled == 2` and `portfolio_metrics.trade_count == 1`.
- [ ] Browser smoke: load dashboard with the post-BUY session -> Win Rate tile shows `N/A` value and `0 closed · 1 filled` subtext.

**Agent instructions:**
- You MUST `git add` + `git commit` the verification note before finishing. Commit message: `[Team C] verify trade_count/orders_filled fix from fc2a212 — confirmed live`.
- Do NOT modify any source file unless the verification fails AND you have explicit reason to believe the fix is incomplete. If you find a real bug, STOP and surface to the user.
- If you find that `fc2a212` is in HEAD but tests pass and live behavior is correct, classify as `verify-only no-fix` and commit only the note.
- Use `uv run finlet api` to start the local server; use a fresh test API key (do NOT reuse production keys).

---

### Team D: Documentation & Lessons Update

**Bug coverage:** none directly. Captures the iteration's lessons + updates `REMAINING_TASKS.md`.

**Blocked by:** Teams A, B, C all merged.

**Read these files first:**
- `docs/REMAINING_TASKS.md` — find any items related to: dashboard modal hygiene, Sentry, Trusted Types, CSP, leaderboard submit feedback, onboarding checklist. Mark them done.
- `docs/lessons.md` (or `docs/LESSONS.md`) — confirm the lesson schema, then add a new entry for this iteration.
- `CLAUDE.md` and `docs/ARCHITECTURE.md` — only update if a CSP directive change (Team B's `goog#html` addition) needs to be documented as a security-architecture decision. If yes, update `docs/ARCHITECTURE.md` CSP section AND add a one-liner to `docs/decisions/`.
- `docs/bug-hunt/20260428T013300Z6e79/triage.md` — the iteration's source.

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — strike or check completed items.
- Modified: `docs/lessons.md` (or `docs/LESSONS.md`) — add 1 entry summarizing the iteration:
  - "Modal-overlay had two CSS rule blocks; second overrode first by cascade — but having both is a footgun. Always defensive-style critical UI elements with inline `style='display:none'`."
  - "Triage agents that observe a number literally (`trade_count=0`) without checking the rendering surface or recent commits will report false positives. Always check `git log --since='1 day ago' -- <file>` before flagging UI-state bugs."
  - "Sentry CDN URL `8.x/bundle.min.js` does not exist; Sentry requires pinned versions. If keeping Sentry, pin to `8.0.0/`. We removed it instead because client-error reporting goes through `/v1/client-errors`."
- Modified: `docs/ARCHITECTURE.md` — if the `goog#html` CSP addition is significant, add to the CSP section.
- Modified: `docs/decisions/` — optional: a 1-page decision record on "remove Sentry, rely on `/v1/client-errors`" if Team B took that path.

**Deliverable:** Docs reflect the iteration's outcome. `REMAINING_TASKS.md` has fewer items.

**Validation:**
- [ ] `git diff docs/` is non-empty and reviewable.
- [ ] `grep -i sentry docs/REMAINING_TASKS.md` returns no open items if Sentry was removed.
- [ ] No links broken (`grep -nE 'docs/[^)]*\.md' docs/ARCHITECTURE.md` and spot-check).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message: `docs: bug-hunt 20260428T013300Z6e79 — record fixes for modal stacking, Sentry removal, Trusted Types, CSP goog#html`.
- Do NOT modify any source file. Docs only.
- Read Teams A, B, C commit messages first to know what actually shipped.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A removes the wrong `.modal-overlay` CSS block and breaks all modals | Low | High | The "Read these files first" list explicitly identifies BOTH blocks (line 383 and line 3123) and tells the agent to keep the line 3123 block (modern, has opacity/visibility transitions). Validation includes assertion that modals are hidden on page load. |
| Team A's `_lbSubmitInFlight` flag leaks across submits (set but never cleared on error) | Medium | Medium | Validation requires checking that `Connection Lost` toast appears normally AFTER a leaderboard submit completes (success or error). Use `try/finally` to clear the flag. |
| Team B removes Sentry but a launch decision wanted it kept | Low | Medium | Default = remove. Agent instructions say "If you encounter blockers, STOP and surface to the user." |
| Team B's CSP `goog#html` addition breaks an existing CSP test | Low | Low | Validation runs `tests/api/test_security_middleware.py`. If a test asserts the exact CSP string, it must be updated as part of Team B's diff. |
| Team B's Trusted Types audit misses an `innerHTML =` assignment, warning still fires | Medium | Low | Validation requires zero warnings during specific user journey (load -> session -> submit -> close). Iterate if any warning is found. |
| Team C finds that `fc2a212` is NOT live in the deployed build (pre-deploy ancestry but not on prod) | Medium | Low | Verify-only team's job is to detect this. If found, the iteration's deploy step (after Team D) handles it. |
| Onboarding checklist's `Save first strategy` was previously bound but the binding broke after a refactor | Low | Low | Recon confirmed the binding exists at lines 649–687. Team B only adds the `window.openLeaderboardSubmitModal` export to harden the primary lookup. |
| Sentry script removal breaks `dashboard/feedback.js` (which has `data-feedback="sentry"`) | Low | Medium | Team B MUST read `dashboard/feedback.js` before removing the data-attribute on the Report-a-Bug link. If feedback.js gates on `window.Sentry`, refactor to use `reportClientError()` instead. |

## Session Plan

### Session 1 — All four teams

**Parallel:** Teams A, B, C run concurrently in separate worktrees.

**Merge order:** C merges first (lowest blast radius — verification note only) -> targeted gate (`pytest tests/core/test_portfolio.py -x -q`) -> B merges next (1 middleware file + dashboard JS changes, has its own pytest gate) -> targeted gate (`pytest tests/api/test_security_middleware.py -x -q` + manual console check) -> A merges last (heaviest dashboard surface area, requires manual modal smoke) -> targeted gate (manual Playwright run on `/index.html`).

**Then:** Team D runs after A, B, C are all merged.

**Session checkpoint:** Full test suite (`uv run pytest -x -q`) + full dashboard smoke walkthrough (load -> create session -> place order -> submit to leaderboard -> close) with DevTools open. Console MUST be free of 403s and Trusted Types warnings.

**Deploy gate:** After Team D commits docs, push to `main`. The deployed dashboard MUST be re-tested via the same blind-agent flow that produced `triage.md` to confirm the iteration's fixes are live.

---

## Notes

- The `trade_count` triage item is a **false positive** by ~95% confidence — `fc2a212` shipped the complete fix and the dashboard correctly distinguishes "no fills" from "fills but no closed trade". Team C's verify-only assignment is the correct response. Do NOT spawn a fix team unless verification fails.
- All four teams should use `general-purpose` worker type with `isolation: "worktree"`.
- No team touches >8 files. Largest is Team A at ~5 files (styles.css, index.html, app.js, leaderboard-submit.js, plus the optional onboarding read).
- File conflict table is empty — A, B, C have NO file overlap (verified by recon). They can be fully parallel.
