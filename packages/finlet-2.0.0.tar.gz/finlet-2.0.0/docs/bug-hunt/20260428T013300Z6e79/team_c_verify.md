# Team C — trade_count / orders_filled Verification

**Iteration:** bug-hunt 20260428T013300Z6e79
**Triage item:** #2 (`trade_count` stays 0 after BUY fill)
**Date:** 2026-04-27
**Classification:** `verify-only no-fix` — confirmed `fc2a212` is live and complete.

---

## 1. fc2a212 in HEAD ancestry — CONFIRMED

```
$ git log --oneline -10 | grep fc2a212
fc2a212 [Team B]: surface orders_filled so Win Rate tile no longer reads "0% — 0 trades" after a BUY-only fill
```

`fc2a212` is the 5th-most-recent commit; it has been merged into `main` (via `6c2a89b merge: [Team B] orders_filled decoupled from win-rate trade_count`).

`git show --stat fc2a212` confirms the diff matches the plan: 5 files changed, +128/-5 — covering `dashboard/app.js`, `finlet/api/schemas/portfolio.py`, `finlet/api/schemas/session.py`, `finlet/core/portfolio.py`, and `tests/core/test_portfolio.py`.

---

## 2. Full portfolio test file — PASSES

```
$ uv run pytest tests/core/test_portfolio.py -x -q
......................................................................   [100%]
70 passed in 0.14s
```

70/70 pass. No regressions.

---

## 3. Targeted `orders_filled` tests — PASS

```
$ uv run pytest tests/core/test_portfolio.py -x -q -k orders_filled
..                                                                       [100%]
2 passed, 68 deselected in 0.07s
```

The two new tests (`test_orders_filled_decoupled_from_trade_count`, `test_get_metrics_orders_filled_after_buy`) both pass.

---

## 4. Code review

### `finlet/core/portfolio.py`

**Counter declared at line 90 (under `__init__`):**
```python
# Total filled fills (BUY + SELL). Distinct from `trade_count`, which
# counts CLOSED round-trip trades (sells only). Surfaced so the UI can
# avoid the misleading "Win Rate 0% — 0 trades" copy after a BUY-only
# fill when there are no closed trades yet.
self._orders_filled: int = 0
```

**Incremented on BUY fill (line 179, end of `_execute_buy_unlocked`):**
```python
        self._orders_filled += 1
        return self._positions[ticker]
```

**Incremented on SELL fill (line 218, in `_execute_sell_unlocked`, immediately after `_trade_pnls.append(realized)`):**
```python
        self._trade_pnls.append(realized)
        self._orders_filled += 1
```
Increment is co-located with `_trade_pnls.append(...)` and protected by the same `asyncio.Lock()` (acquired in `execute_sell` line 193 and `execute_buy`). No race.

**Property exposed at line 390:**
```python
@property
def orders_filled(self) -> int:
    """Total number of FILLED order fills observed (BUY + SELL).
    ...
    """
    return self._orders_filled
```

**Surfaced through `get_metrics()` (line 414) and `to_dict()` (line 433).** `PortfolioMetrics` dataclass at line 72 has `orders_filled: int = 0` (additive default — old clients keep working).

These match the diff in `git show fc2a212` exactly.

### `dashboard/app.js` (lines 1743–1781)

Three-case rendering present and correct:

```javascript
const wr = portfolio.win_rate;
const tc = portfolio.trade_count;
const of = portfolio.orders_filled;

if (tc == null) {
    wrEl.textContent = wr != null ? `${(wr * 100).toFixed(1)}%` : '--';
    tcEl.textContent = '--';
} else if (tc === 0) {
    if (typeof of === 'number' && of > 0) {
        // Fills happened but nothing closed yet — "Win Rate 0% — 0 trades"
        // would contradict the order log. Be honest about the absence
        // of a denominator.
        wrEl.textContent = 'N/A';
        tcEl.textContent = `0 closed · ${of} filled`;
    } else {
        wrEl.textContent = wr != null ? `${(wr * 100).toFixed(1)}%` : '--';
        tcEl.textContent = '0 trades';
    }
} else {
    wrEl.textContent = wr != null ? `${(wr * 100).toFixed(1)}%` : '--';
    if (typeof of === 'number' && of > tc) {
        tcEl.textContent = `${tc} closed · ${of} filled`;
    } else {
        tcEl.textContent = `${tc} ${tc === 1 ? 'trade' : 'trades'}`;
    }
}
```

- Case 1 (`tc === 0 && of === 0`): `0.0% / 0 trades` — pre-fill state, unchanged from before.
- Case 2 (`tc === 0 && of > 0`): `N/A / 0 closed · X filled` — the freshly-filled BUY case the blind agent hit. No more "0% / 0 trades" lie.
- Case 3 (`tc > 0`): `Y% / C closed · T filled` (or `C trade(s)` when `of === tc`).

Matches the fc2a212 diff exactly.

---

## 5. Classification

**`verify-only no-fix`.** `fc2a212` is in the current `main` ancestry; both the engine counter and the dashboard tile render correctly; the new tests (`test_orders_filled_decoupled_from_trade_count`, `test_get_metrics_orders_filled_after_buy`) pass; the full portfolio test file is green (70/70).

The blind agent's "0 trades" report is a false positive against a stale build OR a misread of the new `0 closed · X filled` subtext. No engine, schema, or dashboard change is required.

The live BUY+SELL API roundtrip (plan validation step #3) was intentionally skipped per the team brief — code review + passing unit tests + the explicit `_orders_filled += 1` increments under lock provide equivalent confidence with vastly less setup. If a follow-up still wants live confirmation, the next deploy verification (or a Playwright smoke against a freshly-funded sandbox session) covers it.
