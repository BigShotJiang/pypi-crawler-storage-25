## Broken (will be fixed this iteration)
- Trade Ticket "Available Cash" stays stale after a filled order — UI state diverges from backend state after a successful mutation. [evidence: "After submitting BUY 10 AAPL market order (filled at $190.74, cost $1,907.41), the dashboard Cash metric correctly updated to $98,092.59. However the Trade Ticket dialog header still displayed 'Available Cash: $100,000.00' — stale by $1,907.41. The dialog was open and visible throughout; it never refreshed its cash display after the fill notification appeared."] [scope hint: dashboard/index.html, dashboard/trade-ticket.js, dashboard/api-utils.js]
- "Save first strategy" checklist item opens the Submit-to-Leaderboard dialog — documented affordance performs the wrong action. [evidence: "Clicking the 'Save first strategy' item in the Getting Started checklist (data-checklist-key='strategy') opened a modal titled 'Submit to Leaderboard' with fields for Agent Name, Description, Model Used, and Strategy Category. No strategy was saved; the dialog is for leaderboard submission, not strategy persistence. The checklist counter also did not advance (stayed at 2/4) after the interaction."] [scope hint: dashboard/index.html (checklist + leaderboard modal wiring), dashboard/checklist.js]
- Settings page fires "You have unsaved changes" banner on every load before any user input — UI claims dirty state that contradicts backend reality. [evidence: "Navigating to /settings.html immediately renders a sticky bottom bar reading 'You have unsaved changes / Discard / Save Changes' — reproducible on the Profile tab, API Keys tab, and Plugins tab. No form fields were touched. The false positive appeared consistently across three separate visits to settings.html during this session."] [scope hint: dashboard/settings.html, dashboard/settings.js (dirty-tracker initialization)]
- Trusted Types security policy violation logged on every page load — console error on the happy path. [evidence: "Console warning on every navigation: '[Finlet] Trusted Types default policy invoked — caller should use trustedHTML(): <svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 35 19\"...> @ https://finlet.dev/api-utils.js:441'. Appears to be an SVG being injected via innerHTML instead of a Trusted Types-safe API."] [scope hint: dashboard/api-utils.js:441]
- Onboarding wizard Step 2 session form contradicts main "New Session" dialog — two code paths claim the same job but use different contracts. [evidence: "The onboarding wizard session form has four plain text inputs (Name, Start Date, Capital, Universe). The main 'New' button dialog has a polished template picker (Conservative ETF / Tech Growth / Custom cards) plus the same four fields. A user who creates their first session via the wizard never sees the template cards; the improved UX is only visible on the second session."] [scope hint: dashboard/index.html (wizard markup), dashboard/onboarding.js, dashboard/session-create.js]
- "Getting Started" checklist does not advance after a trade is filled — UI state diverges from backend state after a successful mutation. [evidence: "After BUY 10 AAPL was filled (Order Log showed FILLED status, Reasoning Trace showed ORDER SUBMIT + ORDER FILL entries), the checklist remained at 2/4 complete. 'Run first analysis' was not checked off."] [scope hint: dashboard/checklist.js, dashboard/index.html (checklist event subscriptions)]

## Logged (not actioned)
- Finlet benchmark MCP tools not available in this Claude session — agent-guide documents 8 MCP tools but ToolSearch returned no matches; agent worked around via Trade Ticket UI. [classification: needs-investigation]
- "Save first strategy" element is a `<div role='button'>` rather than `<button>`, requiring JS click instead of normal selectors. [classification: annoying]
- 3 of 8 plugins (finnhub, fred, edgar) show Error status with no in-UI path to obtain or configure the required API keys. [classification: annoying]
- Post-login dashboard shows CLI commands (`finlet serve`, `finlet auth register`, `finlet session create ...`) to a web user who just signed in. [classification: annoying]
- "Freeze" button label is wrong when the clock is already FROZEN — ARIA name is correct but visible text reads "Freeze" instead of "Unfreeze". [classification: annoying]
- Page title and footer use the unexplained acronym "ITE" with no tooltip or expansion in the persistent UI. [classification: annoying]
- API key table shows truncated values with no per-row Show or Copy action — only the user menu's silent "Copy API Key" affordance exists. [classification: annoying]
- Fundamentals strategy has no dedicated web-UI setup path — concept exists only via CLI/MCP and a leaderboard category dropdown. [classification: annoying]
- No web-based strategy builder or named strategy persistence — entire strategy layer is CLI/MCP-only. [classification: nice-to-have]
- No "Strategies" top-level navigation section — strategy concepts scattered across 4 surfaces. [classification: nice-to-have]
- Plugin Health error rows give no contextual help or links to obtain provider API keys. [classification: nice-to-have]
- No data ingestion trigger or staleness indicator in the web UI for news_s3 / sentiment Degraded states. [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260428T031818Z2efa — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. `docs/bug-hunt/20260428T031818Z2efa/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log).
   No artifact left untracked.

Team D's commit message must reference iteration 20260428T031818Z2efa and name which docs were
touched (e.g., "docs: bug-hunt 20260428T031818Z2efa — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration").
