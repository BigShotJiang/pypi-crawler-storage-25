# Bug-Hunt 20260428T031818Z2efa — Execution Plan

> Generated from `docs/bug-hunt/20260428T031818Z2efa/triage.md`. Iteration TS: `20260428T031818Z2efa`.
>
> **Status: COMPLETED 2026-04-27.** All 5 teams merged to main. Full suite: 3883 passed.
> - Team A: `dd3377e` → `6c256fb` (merge) — F2/F5/F6 onboarding & checklist
> - Team B: `8838ff1` → `eee6914` (merge) — F1 Trade Ticket cash sync
> - Team C: `1f9c126` → `c82caca` (merge) — F3 Settings dirty banner
> - Team D: `6d7c10e` → `9c5a917` (merge) — F4 Trusted Types vendor SVG
> - Team E: `9c3f60e` → `a1cad3e` (merge) — docs (REMAINING_TASKS, LESSONS x6, ARCHITECTURE, 2 decisions, artifacts)

## Constraints

- All real-broken items live in `dashboard/` (vanilla HTML/JS/CSS — no build step). Fixes ship by editing the files directly; no transpilation.
- Trusted Types policy is enforced site-wide via `dashboard/api-utils.js`. New `innerHTML` paths must go through `trustedHTML()` or the `_finletPolicy.createHTML` named policy — never raw assignment.
- Existing SSE event channel is `app.js`'s `EventSource` (`portfolio`, `orders`, `history`, `trace`, `health`). New consumers either listen on the EventSource directly (if accessible) or hook a thin re-dispatch layer; do not introduce a new transport.
- Onboarding state persists to `localStorage` via `onboarding.js` (`loadState` / `saveState`). Touching step keys requires keeping `loadState` resilient — the existing try/catch silently resets on parse error, so don't break the JSON shape.
- Team D (docs) MUST follow the Required Docs Updates block at the tail of `triage.md`. Missing docs commits = iteration is incomplete.
- Each team commits inside its worktree. `/exec-plan` enforces sequential merge gates and per-merge tests; teams that share a file must be sequenced.

## File Conflict Table

| File | Touched by Teams |
|------|------------------|
| `dashboard/app.js` | A, B |
| `dashboard/onboarding.js` | A |
| `dashboard/leaderboard-submit.js` | A |
| `dashboard/index.html` | A |
| `dashboard/trade-ticket.js` | B |
| `dashboard/settings.js` | C |
| `dashboard/api-utils.js` | D |
| `dashboard/shared-nav.js` | D |
| `docs/REMAINING_TASKS.md` | E |
| `docs/LESSONS.md` | E |
| `docs/ARCHITECTURE.md` | E |
| `docs/KNOWN_FAILURES.md` | E |
| `docs/bug-hunt/20260428T031818Z2efa/*` | E |

**Only shared file is `dashboard/app.js`** between Teams A and B. Everything else is single-team-owned.

## Dependency Graph

- **Team A** (Onboarding/Checklist) — independent except for `app.js` overlap with B.
- **Team B** (Trade Ticket Cash Sync) — blocked by A on the `app.js` lock.
- **Team C** (Settings Dirty Banner) — independent. Can run anytime.
- **Team D** (Trusted Types Warning) — independent. Can run anytime.
- **Team E** (Docs) — independent on file ownership, but must merge LAST so the docs commit captures all artifacts (including any `team_*_verify.md` produced by other teams).

## Critical Path

`Team A → Team B → Team E`

Teams C and D run fully in parallel with A/B and merge whenever ready. Team E waits for everyone else.

---

## Teams

### Team A: Onboarding & Checklist Wiring

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/onboarding.js` — current checklist step keys (`profile`, `session`, `analysis`, `strategy` at lines ~18-21), `buildChecklistItem` (~lines 690-698), `markStepComplete` (~lines 741-748), `loadState` / `saveState`, and the `strategy` item click handler (~lines 652-687) that wires to `window.openLeaderboardSubmitModal()`. This is the misrouted affordance.
- `dashboard/leaderboard-submit.js` — `openLeaderboardSubmitModal` (~line 68) so you understand the modal you're being misdirected into.
- `dashboard/index.html` — Create Session Modal (~lines 361-422) including the template-card picker (Conservative ETF / Tech Growth / Custom). This is the canonical session-creation surface; the onboarding wizard's plain 4-input form must converge on it.
- `dashboard/app.js` — SSE `orders` listener (~lines 1423-1441) where `filledCount` is tracked. This is where the `analysis` step auto-advance hook lives.
- Search `grep -nE "wizard|onboarding" dashboard/index.html dashboard/onboarding.js` to find the wizard's session-creation step DOM and confirm whether it is a separate modal, an inline panel, or rendered programmatically by `onboarding.js`. Triage said "Step 2 of the onboarding wizard"; identify exactly where that lives before editing.

**Files touched:**
- Modified: `dashboard/onboarding.js`
  - Fix F2: stop wiring the `strategy` checklist item to the leaderboard modal. Either route it to a real strategy-save flow (only do this if a save endpoint already exists — verify with `grep -nE "/strategies|saveStrategy|persistStrategy" finlet/api dashboard/`), OR if no such endpoint exists, repurpose the item to open the strategy-related onboarding step (e.g., link to `agent-guide.html#strategies`) AND rename the `data-checklist-key` and visible label so the affordance matches the action. Ensure the click handler advances the checklist counter (currently stuck at 2/4 after click).
  - Fix F5: collapse the wizard's session-creation step to invoke the same Create Session modal opened by the top-bar "New" button (template-card picker). Remove the duplicate 4-input form or replace it with a button that calls the existing `window.openCreateSessionModal()` (or whatever the canonical opener is — confirm in `dashboard/app.js`).
- Modified: `dashboard/leaderboard-submit.js`
  - Update only if F2 leaves `openLeaderboardSubmitModal` as a callsite needing a comment / flag — otherwise leave untouched. Do not refactor unrelated code.
- Modified: `dashboard/index.html`
  - Remove or rewrite the wizard's Step 2 session form DOM if it lives in markup. If the wizard is built dynamically in `onboarding.js`, no `index.html` change is needed.
- Modified: `dashboard/app.js`
  - Fix F6: in the `orders` SSE listener, when `filledCount` increments past zero (first fill), call `window.finletOnboarding?.markStepComplete?.('analysis')`. Guard against double-firing (only call when transitioning from 0 → ≥1 fills, or use `markStepComplete`'s built-in idempotency if it has one — verify in `onboarding.js`).

**Deliverable:** Three behaviors are correct after merge:
1. The "Save first strategy" checklist item either persists a strategy or routes to the strategy guidance flow (NOT the leaderboard modal), and clicking it advances the checklist counter.
2. The onboarding wizard's session-creation step opens the same templated dialog as the top-bar "New" button — no drift between the two paths.
3. After a trade fills, the "Run first analysis" checklist item auto-checks without a page reload.

**Validation:**
- [ ] `uv run pytest tests/dashboard tests/api -x -q` passes (or skip dashboard tests if none exist — confirm via `ls tests/dashboard 2>/dev/null`).
- [ ] Manual smoke: spin up the local server (`finlet serve`), visit `/`, confirm the three behaviors above.
- [ ] Browser console clean (no new warnings introduced beyond the pre-existing Trusted Types warning, which Team D owns).
- [ ] `git add` + `git commit` — changes must be on the branch before the worktree is harvested.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Worktree contents are lost otherwise.
- Follow vanilla-JS patterns already in `dashboard/` — no build step, no module loaders, no new dependencies. Functions attach to `window` for cross-file access.
- Where the existing code uses `dashFetch` / `dashPost` / `dashGet` for API calls, keep using them. Do NOT introduce raw `fetch()`.
- Do NOT add Trusted Types violations — any new `innerHTML` write must go through `trustedHTML()`. If you add HTML strings, wrap them.
- Idempotency on `markStepComplete('analysis')`: read `onboarding.js` first; if `markStepComplete` is already a no-op when the step is complete, you can call it on every fill. Otherwise gate on a transition (e.g., a module-level `_analysisStepFired` flag in `app.js`).
- If you cannot find a real "save strategy" endpoint and have to repurpose the checklist item, document the change in your commit message so Team E (docs) can capture the rationale.
- Worktree-rules: edit only files inside the worktree. Do not run commands that touch the parent tree (`/Users/justnau/finlet/dashboard/...` outside the worktree path).

---

### Team B: Trade Ticket Cash Sync

**Blocked by:** Team A merging first (both touch `dashboard/app.js`).

**Read these files first:**
- `dashboard/trade-ticket.js` — `fetchCashBalance` (~lines 145-165), `openTradeTicket` (~line 101), module-level `tradeTicketCashBalance` (~line 8), and any close/cleanup logic.
- `dashboard/app.js` — SSE listeners block (~lines 1390-1460), specifically the `portfolio` event handler (~lines 1400-1408) that updates `#cash-value`, and the `orders` listener (~lines 1423-1441) where Team A added the checklist hook. You must not collide with that hook.
- `dashboard/api-utils.js` — `dashFetch` and any global event-emit helpers (look for `window.dispatchEvent`, `CustomEvent`, or a pub-sub pattern). If none exists, decide whether to broadcast a `CustomEvent` from `app.js` or expose a `window.finletPortfolio?.refresh` hook.

**Files touched:**
- Modified: `dashboard/trade-ticket.js`
  - Subscribe to portfolio updates so the dialog header re-renders when cash changes. Cleanest path: when the modal opens, install a listener (CustomEvent on `window` or direct hook into `window.finletPortfolio`); when the modal closes, remove the listener. Keep `fetchCashBalance()` as the fallback for initial load.
  - Reset `tradeTicketCashBalance` on session switch (see Landmine 6 in recon report). Hook this off whatever app.js fires on session change, OR clear in `openTradeTicket` by always re-fetching.
- Modified: `dashboard/app.js`
  - In the `portfolio` SSE listener (~line 1400-1408), broadcast a `CustomEvent('finlet:portfolio-update', { detail: portfolioData })` on `window` so trade-ticket can listen without depending on direct callbacks. Place the dispatch AFTER the existing `renderPortfolio(...)` call. Single line addition + comment.
  - Do NOT touch the `orders` listener — Team A owns that block this iteration.

**Deliverable:** Trade Ticket dialog header `Available Cash` reflects the post-fill balance immediately. No reload needed.

**Validation:**
- [ ] Manual smoke: open Trade Ticket → submit BUY 1 AAPL @ MARKET → confirm header cash drops by the fill cost without closing/reopening the dialog.
- [ ] Open dialog → close → open again → confirm cash is current (no stale cache from Landmine 6).
- [ ] Open dialog in Session A → switch sessions to B → reopen Trade Ticket → confirm balance matches Session B's cash.
- [ ] No new console warnings; no double-listener leaks (open/close 5 times, confirm DOM/listener counts stable via `getEventListeners(window)` in DevTools).
- [ ] `git add` + `git commit` before finishing.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- DO NOT touch the SSE `orders` listener block — Team A's commit is already there. Edit only the `portfolio` listener block and `trade-ticket.js`.
- Use `CustomEvent` + `window.addEventListener('finlet:portfolio-update', handler)` pattern unless you find a pre-existing pub-sub helper in `api-utils.js` worth reusing.
- Always remove listeners on modal close to prevent the stacking leak (Landmine 4 in recon).
- Keep changes minimal — this is a focused 2-file fix, not a refactor.

---

### Team C: Settings Dirty Banner Race

**Blocked by:** none — independent.

**Read these files first:**
- `dashboard/settings.js` — initialization block (~lines 43-49) where `Promise.allSettled(...)` resolves and `initFormTracking()` is called. Specifically `initFormTracking` (~lines 109-134), `markDirty` (~lines 136-145), `markDirtyToggle` (~lines 147-161), and `updateUnsavedBanner` (search for the banner show/hide function).
- `dashboard/settings.html` — banner DOM (search for "unsaved changes" string) and any tab-switch wiring.

**Files touched:**
- Modified: `dashboard/settings.js`
  - Diagnose why the banner appears before any input. Likely causes:
    - `initFormTracking` runs before form fields are populated by their async loaders, so `originalValues[fieldId]` captures empty/default and any subsequent loader-driven population fires `markDirty`.
    - The `change` / `input` listeners are attached to fields whose loaders later overwrite `value`, programmatically triggering `markDirty`.
    - `Promise.allSettled` resolves even on rejection, so a failed loader leaves a field in an indeterminate state.
  - Fix: gate `initFormTracking` on a "form populated" signal — either re-call it after each loader finishes, or have `initFormTracking` re-snapshot `originalValues` after a `requestAnimationFrame` to guarantee DOM writes have settled.
  - Ensure programmatic `value` assignments by loaders DO NOT fire `markDirty`. If listeners use `input`/`change` events, programmatic writes don't normally fire those — but if the code dispatches synthetic events, fix that. Otherwise add a `_loaderUpdating` guard.

**Deliverable:** `/settings.html` loads with the banner hidden on every tab. Banner appears only after the user actually edits a field, and disappears on save or discard.

**Validation:**
- [ ] Manual: open `/settings.html` → confirm banner is NOT visible on Profile, API Keys, Plugins tabs.
- [ ] Edit a field → banner appears.
- [ ] Discard → banner disappears, field reverts.
- [ ] Save → banner disappears, field value is what was saved.
- [ ] Switch tabs without editing → banner stays hidden.
- [ ] `git add` + `git commit`.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Do NOT add a band-aid that hides the banner unconditionally — find the false-positive trigger and fix it at the source.
- Keep the existing dirty-tracking semantics for actual user edits (the test plan must still pass).
- Single-file change. Do not refactor neighboring modules.

---

### Team D: Trusted Types Default Policy Warning

**Blocked by:** none — independent.

**Read these files first:**
- `dashboard/api-utils.js` — `createPolicy` (~lines 415-420), `_finletPolicy` (~line 438), the default-handler warning at line 442, and `trustedHTML` (~lines 469-474). Understand exactly what triggers the default-policy warning vs. the named-policy passthrough.
- `dashboard/shared-nav.js` — `_navSetHTML` (~lines 36-37), `_buildHeaderHTML` (~lines 94-219). The blind report stack-trace blamed `api-utils.js:441` with an SVG payload (`viewBox="0 0 35 19"`) — find which caller that SVG belongs to. Search: `grep -nE 'viewBox="0 0 35 19"' dashboard/`.
- All other dashboard JS files — run `grep -nE "innerHTML\\s*=|insertAdjacentHTML|outerHTML\\s*=" dashboard/*.js` and audit each callsite. The default-policy warning fires whenever ANY innerHTML write hits the default policy instead of going through `trustedHTML()`.

**Files touched:**
- Modified: `dashboard/api-utils.js`
  - If the default policy is a noisy warning meant to surface bypass paths, that's working as intended — the fix is on the caller side. But if the warning fires on every page load with an SVG payload that belongs to a recurring nav render, the named policy is being bypassed somewhere. Confirm by reading line 441's exact context.
- Modified: `dashboard/shared-nav.js` (or whatever file owns the offending SVG injection)
  - Route the SVG through `trustedHTML()` — pre-import or use the existing `_navSetHTML` wrapper. If `_navSetHTML` is already wrapping properly, the warning is coming from a different caller — find and fix.
- Possibly modified: any other dashboard JS file that writes `innerHTML` with SVG content. Audit all hits from the grep above.

**Deliverable:** Page navigation produces zero `[Finlet] Trusted Types default policy invoked` warnings in the console for the happy path (login → dashboard → settings → leaderboard → back).

**Validation:**
- [ ] Open DevTools console → navigate the happy path above → no Trusted Types default-policy warnings.
- [ ] All affected pages still render correctly (header SVGs visible).
- [ ] `grep -nE "innerHTML\\s*=" dashboard/*.js` audit: every remaining hit is either via `trustedHTML()` or has an inline comment explaining why it's safe.
- [ ] `git add` + `git commit`.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Do NOT silence the warning by removing it from `api-utils.js` — fix the calling code.
- If you find the warning is correct and load-bearing (i.e., it surfaces a real bypass), still fix the bypass — the warning is the symptom, the bypass is the bug.
- Keep the named policy `finlet-default` intact. Don't introduce additional policies unless a callsite genuinely needs different escaping rules.
- Single-pass code change. Don't refactor the policy structure.

---

### Team E: Documentation Updates

**Blocked by:** Teams A, B, C, D merging FIRST. Team E captures the result.

**Read these files first:**
- `docs/bug-hunt/20260428T031818Z2efa/triage.md` — including the **Required Docs Updates (mandatory — Team D scope)** block at the tail. (Note: the triage block calls this "Team D" — in this plan it is Team E. Same mandate.)
- `docs/REMAINING_TASKS.md` — current state, recent "Bug Hunt" subsections.
- `docs/LESSONS.md` — current format, prior bug-hunt lessons.
- `docs/ARCHITECTURE.md` — sections most likely to change: dashboard surfaces, security-headers / CSP, middleware stack.
- `docs/KNOWN_FAILURES.md` — current open failures.
- `docs/decisions/` — directory listing; only add a new decision record if a non-trivial reversible decision was made (e.g., "removed the wizard's standalone session form, consolidated to template-card modal").
- The merge commits from Teams A, B, C, D so the lesson and architecture entries reflect what actually shipped (not what was planned).

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — add a "Bug Hunt 20260428T031818Z2efa — Closed" subsection mirroring the prior iteration's pattern. Close every item this iteration resolves.
- Modified: `docs/LESSONS.md` — at least one lesson per real-broken finding that exposed a class of mistake (e.g., "UI dialogs that read backend state on open must subscribe to mutation events, not snapshot once"; "never use `<div role='button'>` in production for documented affordances — use `<button>`"; "default Trusted Types policies in production must surface as test failures, not console warnings").
- Modified: `docs/ARCHITECTURE.md` — update if any of: dashboard surface, plugin registry, middleware stack, route surface, schema fields changed. If nothing applies, state explicitly in the commit message: "ARCHITECTURE.md unchanged this iteration — no architectural surface touched."
- Modified: `docs/KNOWN_FAILURES.md` — refresh; remove any pre-existing failures that this iteration closed.
- Possibly added: `docs/decisions/<NNNN>-<slug>.md` — one-page record only for non-trivial reversible decisions made by Teams A–D (e.g., wizard consolidation, repurposing the strategy checklist item, custom event for portfolio updates).
- Added: every artifact under `docs/bug-hunt/20260428T031818Z2efa/` MUST be `git add`'d and committed.

**Deliverable:** A single docs commit on `main` (after the four code merges) that satisfies all six items in the triage's Required Docs Updates block. Commit message references iteration `20260428T031818Z2efa` and names which docs were touched.

**Validation:**
- [ ] `git status` clean for `docs/` after the commit.
- [ ] All artifacts under `docs/bug-hunt/20260428T031818Z2efa/` are tracked (no untracked files in that dir post-commit).
- [ ] `docs/REMAINING_TASKS.md` has a fresh "Bug Hunt 20260428T031818Z2efa — Closed" subsection.
- [ ] `docs/LESSONS.md` has at least 6 new lesson entries (one per broken finding).
- [ ] If `docs/ARCHITECTURE.md` was unchanged, the commit message says so explicitly.
- [ ] Commit message format: `docs: bug-hunt 20260428T031818Z2efa — record fixes for X, Y, Z; LESSONS +N; ARCHITECTURE <touched|unchanged>`.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Do NOT add lessons that just recap the diff — every lesson must be a reusable rule.
- Reference iteration `20260428T031818Z2efa` in the commit message.
- If a Required Docs Update item is genuinely not applicable, state so explicitly in the commit body — never silently omit.
- Stage every artifact under `docs/bug-hunt/20260428T031818Z2efa/` even if it predates this commit (e.g., `triage.md`, `triage.json`, `blind_report.json`, `cleanup.log`, `plan.md`).

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A and B both touch `dashboard/app.js` and produce a merge conflict | Medium | Medium | Sequential merge gate (A first, B second). B's `app.js` change is restricted to the `portfolio` SSE listener block; A owns the `orders` block. |
| Team A breaks the wizard's session-creation step by removing the duplicate form before the canonical opener works for first-time users | Medium | High | Validation requires manual smoke for both wizard and standalone "New" button paths. If the canonical opener depends on an authenticated session that the wizard's first-time flow doesn't have yet, the wizard must call the same modal but skip prerequisites. |
| F2 fix repurposes the "Save first strategy" item to a guidance link, but the underlying truth — there is no save-strategy endpoint — is itself a product gap that re-surfaces in the next bug-hunt iteration | High | Low | Document the repurposing decision in `docs/decisions/` (Team E). Add to `REMAINING_TASKS.md` as an open product decision. |
| Trusted Types fix at Team D misses a callsite, warning still fires on a non-happy path | Medium | Medium | Validation requires the full `grep -nE "innerHTML"` audit. Each remaining callsite must be either wrapped or commented as safe. |
| Team C's settings dirty-banner fix masks a real bug (e.g., a loader genuinely is racing with `initFormTracking`) | Low | Medium | Diagnose the trigger first, then fix at the source. Don't add a `setTimeout` band-aid. |
| Team E commits before Teams A–D, missing artifacts | Low | Medium | `/exec-plan` enforces merge order; Team E is sequenced last. |
| First fill on a fresh session triggers `markStepComplete('analysis')` AND `markStepComplete('strategy')` in close succession, racing the auto-dismiss logic in `updateChecklist` | Low | Low | Read `updateChecklist` before adding the hook — confirm step transitions are idempotent and ordering-safe. |
| `dashboard/api-utils.js` is required for trustedHTML; if Team D refactors the policy, Teams A and B's HTML writes break | Medium | High | Team D commits the simplest possible fix (route the SVG through `trustedHTML()`); does NOT refactor the policy itself. Teams A and B should not need to touch `api-utils.js`. |

## Session Plan

### Session 1

**Sequential lane (shared file `dashboard/app.js`):**
- Team A merges first → targeted tests on main → Team B merges → targeted tests.

**Parallel lane (no shared files with each other or with A/B's owned-file changes outside `app.js`):**
- Team C merges whenever ready → targeted tests.
- Team D merges whenever ready → targeted tests.

**Final lane (waits for A, B, C, D):**
- Team E merges last → targeted tests + full doc completeness check.

**Per-merge targeted gate:**
- Lint: `uv run ruff check . --fix` (fast, no-op for dashboard but catches stray Python).
- Smoke: `uv run pytest tests/api -x -q` (excludes long-running suites; confirms backend is intact since dashboard fixes can't break Python tests but a misrouted JS edit could foul a static-asset path).
- Manual: per-team validation checklist above.

**Session checkpoint after E merges:**
- Full suite: `uv run pytest -x -q`.
- Manual: full happy-path walkthrough (login → onboarding wizard → session create → trade fill → settings → leaderboard).
- Browser console clean across all visited pages.
