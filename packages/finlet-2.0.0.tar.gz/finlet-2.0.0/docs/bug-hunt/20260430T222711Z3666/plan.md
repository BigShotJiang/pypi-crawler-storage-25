# Bug-Hunt 20260430T222711Z3666 — Execution Plan

> Generated from `docs/bug-hunt/20260430T222711Z3666/triage.md`. Last updated: 2026-04-30.

5 real-broken findings closed across 4 worker teams + 1 docs/ledger team.

## Constraints
- One iteration of /bug-hunt; this plan must close every real-broken finding from `triage.md`.
- Two findings carry forward-signal `same_root_cause_as` links to prior ledger entries:
  - Finding 3 (settings dirty banner) → `settings-dirty-banner` (RECURRENCE; dirty-state-tracker refactor already shipped + verdict_v2 effective).
  - Finding 5 (checklist not advancing on REST/CLI session-create) → `checklist-no-advance-after-fill` (RECURRENCE; onboarding-checklist refactor shipped TODAY in commit 40368b2 — pending verdict will be `incomplete` given this gap).
- Per CLAUDE.md: dashboard event wiring goes through `window.finletBus.subscribe / publish`. Direct `window.dispatchEvent` is forbidden. Update `dashboard/event-contract.md` if a new event is added.
- Per CLAUDE.md: onboarding checklist + wizard steps go through `CHECKLIST_STEPS` and `WIZARD_STEPS` registries in `dashboard/onboarding.js` (post-40368b2). New trigger events go in the same registry — not parallel maps.
- Per CLAUDE.md: bare `.innerHTML =` writes in dashboard/* are blocked by pre-commit unless wrapped in `trustedHTML(...)`.
- Each team `git add && git commit` before finishing — worktrees are otherwise wiped.

## File Conflict Table

| File | Touched by Teams |
|------|-----------------|
| `finlet/cli.py` | B (Findings 2 + 4 bundled) |
| `finlet/api/routes_session.py` (or `routes_sessions.py`) | B (idempotency / status), D (SSE publish on create) — **shared** |
| `tests/test_cli.py` | B |
| `dashboard/settings.js` | C |
| `dashboard/onboarding.js` | D |
| `dashboard/app.js` | D |

Only one inter-team file conflict: **`routes_session.py`** is touched by B (timeout/idempotency clarity) and D (publish a `session:created` SSE event). They must be sequenced — see Dependency Graph.

## Dependency Graph
- **Team A — Auth 401 fix** — no shared files; independent; can start immediately.
- **Team B — CLI timeout + plugin-list parity** — touches `finlet/cli.py` + `finlet/api/routes_session.py` + `tests/test_cli.py`; independent of A and C; **blocks D** on `routes_session.py`.
- **Team C — Settings dirty banner** — touches `dashboard/settings.js` + dirty tracker only; no shared files; independent.
- **Team D — Checklist on REST/CLI session-create** — touches `dashboard/onboarding.js`, `dashboard/app.js`, and `finlet/api/routes_session.py` (SSE publish hook); **blocked by B** on `routes_session.py`.
- **Team E — Docs + ledger** — blocked by A, B, C, D (needs all merge SHAs for ledger.jsonl); merges last.

## Critical Path
**B → D → E** (B unblocks D; D unblocks E; A and C run in parallel and are absorbed into the same wall-clock window).

---

## Teams

### Team A: Auth — 401 on /v1/auth/session/validate fires on every dashboard load
**Blocked by:** none — can start immediately.

**Read these files first:**
- `finlet/api/routes_auth_sessions.py:146` — current `/v1/auth/session/validate` handler.
- `finlet/auth/deps.py:195-231` — `_OptionalUser` dependency. Lines 212-228 raise HTTPException(401) when the cookie is present but the session lookup returns None. **This is the bug.** The intent of `optional_user` is "anonymous-on-failure" for routes that should not 401 logged-out callers; the cookie path violates that contract.
- `dashboard/auth.js` — client-side auth guard that calls `/v1/auth/session/validate` on every page load.
- `dashboard/api-utils.js` — global fetch wrapper; verify it doesn't transform a 401 from this endpoint into a forced logout.
- `tests/api/test_routes_auth.py` — existing coverage for auth endpoints.

**Files touched:**
- Modified: `finlet/auth/deps.py` — change cookie-validation-failure path (lines 220-228) to return `None` (anonymous) instead of `raise HTTPException(401)`. Match the contract Bearer-token path uses on fall-through.
- Modified: `tests/api/test_routes_auth.py` — add a test that exercises `/v1/auth/session/validate` with a stale/invalid cookie and asserts 200 + anonymous body, NOT 401.

**Deliverable:** `/v1/auth/session/validate` returns 200 with `{authenticated: false}` (or whatever the existing anonymous shape is) when the cookie is invalid; never console-401 on a happy-path dashboard load.

**Validation:**
- [ ] `uv run pytest tests/api/test_routes_auth.py -x -q` passes (existing + new test).
- [ ] `uv run pytest tests/api/ -k auth -x -q` passes.
- [ ] Manual: `curl -i -b 'session=garbage' https://finlet.dev/v1/auth/session/validate` returns 200, not 401.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Do NOT change the Bearer-token path in `_OptionalUser`. Tampered Bearer tokens should still 401 — only stale/invalid cookies must downgrade to anonymous.
- If the codebase calls this dependency from any route that intentionally relies on the cookie 401 (i.e., wants "logged-out users get 401 here"), keep that behavior by adding a separate `required_user` dependency rather than weakening `optional_user`. Grep for `_OptionalUser` usages before broad-stroke changes.

---

### Team B: CLI — session-create ReadTimeout + plugin-list parity
**Blocked by:** none — can start immediately. Touches files Team D also needs (`routes_session.py`); B merges first by convention.

**Read these files first:**
- `finlet/cli.py:79-113` — current `session_create` handler. Line 100 sets `timeout=10`; the except block at lines 108-113 does NOT catch `httpx.ReadTimeout`, so it crashes uncaught.
- `finlet/cli.py:180-192` — current `plugins_list` handler. Plugins are hardcoded to a 4-element dict (price, edgar, fred, finnhub). The web UI sources from the registry and shows 8.
- `finlet/api/app.py:77-137` — `_register_plugins()`. Source of truth for the plugin list (8 plugins). CLI must consult this.
- `finlet/api/routes_health.py:82-106` — `plugins_health()` calls `registry.health_check_all()`. Plugin status answer should match this.
- `finlet/api/idempotency.py:47` — existing idempotency support; if POST /sessions accepts an `Idempotency-Key`, the CLI fix can resubmit safely on timeout instead of guessing whether the server received the first request.
- `finlet/api/routes_session.py` (or `routes_sessions.py`) — the POST /sessions handler. Confirm whether it supports idempotency keys and how long it actually takes (plugin warm-up?).
- `tests/test_cli.py` — existing CLI tests, especially around timeouts and plugin commands.

**Files touched:**
- Modified: `finlet/cli.py` — bundled fix for two findings:
  1. **Finding 2** — extend `session_create`'s except block to catch `httpx.ReadTimeout`. On ReadTimeout, do `GET /v1/sessions?name=<requested>` and report the truth (created vs. truly failed), or pass `Idempotency-Key` on the POST so retries are safe and report the first authoritative response. Bump `timeout=10` → `timeout=60` because plugin init can take longer than 10s.
  2. **Finding 4** — replace the hardcoded 4-plugin dict in `plugins_list()` with a call to `GET /v1/plugins/health` (the same endpoint the dashboard hits). The CLI then derives status from the live registry, matching the web UI.
- Modified: `finlet/api/routes_session.py` (or `routes_sessions.py`) — only if needed to support idempotency keys on POST /sessions. If the route already supports idempotency, no edit. Document the choice in the team verify file.
- Modified: `tests/test_cli.py` — two new tests:
  1. `session create` with a mocked `httpx.ReadTimeout` — verify CLI exits with a clear message AND reports the correct created-vs-failed state.
  2. `plugins list` — verify CLI reports the same plugin set the API does (mock `/v1/plugins/health` and assert the table matches).

**Deliverable:** `finlet session create` no longer reports failure on a successfully-created session; `finlet plugins list` reports the same 8 plugins the dashboard does, with matching health status.

**Validation:**
- [ ] `uv run pytest tests/test_cli.py -x -q` passes (existing + new tests).
- [ ] Manual: with the dev server running, `finlet plugins list` lists 8 plugins matching `curl /v1/plugins/health`.
- [ ] Manual: `finlet session create --name probe-$RANDOM ...` does not exit non-zero on a successful create. (Hard to manually trigger the ReadTimeout — rely on the unit test.)

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Do not refactor unrelated CLI commands.
- If you choose the SDK-style fix where `plugins list` calls `/v1/plugins/health` over the network, make sure the CLI degrades gracefully when the API is unreachable (print a useful message, exit non-zero). Prior tests may assume offline-capable behavior — check before changing.
- If you touch `routes_session.py`, keep the diff minimal — Team D will also touch this file. Add idempotency support but don't restructure the handler.
- After your commit, write your changed file list + line counts to `docs/bug-hunt/20260430T222711Z3666/team_B_verify.md` so Team D knows what's already in `routes_session.py`.

---

### Team C: Dashboard — Settings dirty banner false-positive on cold load
**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/form-dirty-tracker.js:69-77` — `_updateBanner()` shows the banner when `dirtyFields.size > 0`.
- `dashboard/form-dirty-tracker.js:181-187` — `registerLoader(promise)` API. Loaders register; the gate at lines 249-294 (`initFormTracker()`) drains the registry repeatedly until no new loaders register, then snapshots fields as the baseline.
- `dashboard/form-dirty-tracker.js:114` — baseline snapshot of `originalValues[el.value]`.
- `dashboard/form-dirty-tracker.js:84` — `_markDirty()` compares current vs original and marks dirty.
- `dashboard/settings.js` — every loader on the settings page. Identify which loader writes to a tracked field WITHOUT either (a) registering its promise via `registerLoader(promise)` so the gate awaits it, or (b) calling `snapshotFields(loadedFieldIds)` after writing.
- `docs/decisions/dashboard-form-dirty-tracker-registry.md` — the convention this code is supposed to follow.
- Prior ledger entries: `settings-dirty-banner-onload` (20260428T031818Z2efa, fix 31c3255), `settings-dirty-banner` (20260429T052717Z1a13, fix 6a8d798), `plugins-tab-dirty-banner-deploy-lag` (20260429T232205Z17ff, fix ed15c6c). The convention closed those; this is a new offender on the same surface.

**Files touched:**
- Modified: `dashboard/settings.js` — find the loader(s) that write tracked fields without registering or re-snapshotting. Either register their promise via `registerLoader(loaderFn())` at init or call `snapshotFields(loaderIds)` after the loader writes the DOM.
- Modified (only if the registry abstraction needs hardening): `dashboard/form-dirty-tracker.js` — but the convention doc says the registry is sufficient. Prefer to fix the offender, not the registry.
- Tests: a new regression test under `tests/dashboard/` (or `tests/e2e/journey-06-settings.spec.ts` if that's the pattern). Verify cold-load of settings.html does NOT show `#unsaved-banner`.

**Deliverable:** Cold loading `/settings.html` shows zero dirty banner until the user actually edits a field. No regression on existing dirty-detect-after-edit behavior.

**Validation:**
- [ ] `bash scripts/lint-trusted-types.sh` passes.
- [ ] `uv run pytest tests/dashboard/ -x -q` passes (or whatever pattern matches dashboard tests).
- [ ] If e2e tests are configured: `npx playwright test tests/e2e/journey-06-settings.spec.ts` passes.
- [ ] Manual: load `https://finlet.dev/settings.html` → `#unsaved-banner` is hidden.
- [ ] Manual: edit a tracked field → banner appears. Save → banner clears. Reload → banner stays cleared.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Find the offender empirically — don't assume which loader is at fault. Add `console.debug('[loader-X] registered')` lines briefly during diagnosis if helpful, but remove them before committing.
- Do NOT remove fields from dirty-tracking just to silence the banner — that defeats the feature. The fix is to register or re-snapshot, not to delist.
- The previous fix patches were 31c3255 / 6a8d798 / ed15c6c — `git show` them for context on the intended pattern.

---

### Team D: Dashboard + API — Checklist 'Create first session' advances on REST/CLI session-create
**Blocked by:** Team B (file conflict on `finlet/api/routes_session.py`). Wait for Team B's commit + verify file before starting your own touch on that file.

**Read these files first:**
- `dashboard/onboarding.js` — CHECKLIST_STEPS array (post-40368b2 refactor). The `session` step's `trigger` field declares the bus event that flips the box.
- `dashboard/onboarding.js:407-425` — bus subscriber that consumes the trigger event.
- `dashboard/app.js:1368` — current `session:switched` publish on dropdown change. This is the only path that fires the trigger today.
- `dashboard/event-contract.md` — bus event registry. New events MUST be added here in the same commit.
- `finlet/api/routes_session.py` (or `routes_sessions.py`) — POST /sessions handler. Decide: does the backend publish a server-sent event for new sessions? If yes, where? If not, where to add it.
- `finlet/api/routes_sse.py` — SSE infrastructure. Where dashboard listens for server pushes.
- `dashboard/dialog-state-mirror.js` — possibly relevant for prime-on-open semantics if the new event needs them.
- `team_B_verify.md` (in this iteration's bug-hunt dir) — Team B's edits to `routes_session.py`. Read this before touching the file to avoid stomping idempotency code.
- `docs/decisions/onboarding-checklist-step-contract.md` — the convention the post-40368b2 registry follows.
- Prior ledger entries closed by 40368b2: `strategy-checklist-dead-div`, `strategy-item-opens-leaderboard`, `onboarding-wizard-form-drift`, `checklist-no-advance-after-fill`. The new finding's `same_root_cause_as` is `checklist-no-advance-after-fill` — this is the gap the refactor under-scoped.

**Files touched:**
- Modified: `dashboard/onboarding.js` — change the `session` step's `trigger` from `session:switched` only to listen for **either** `session:switched` OR a new `session:created` event. The cleanest implementation is to make `trigger` accept an array, OR to publish `session:switched` whenever a new session lands in the dropdown regardless of source.
- Modified: `dashboard/app.js` — wherever the dashboard receives a server-side "new session exists" signal (SSE message, or polling refresh of the session list), publish `session:switched` (or a new `session:created`) on the bus. The trigger should fire when the user already has an active session, regardless of how it was created.
- Modified: `dashboard/event-contract.md` — register the new event (if added) with one-line semantics + payload shape.
- Modified: `finlet/api/routes_session.py` (or `routes_sessions.py`) — only if backend SSE is needed. **Read `team_B_verify.md` first** to avoid undoing Team B's idempotency work. Add an SSE publish on successful POST /sessions if the dashboard does not already detect new sessions through polling/SSE.
- Tests: regression test under `tests/e2e/` or `tests/dashboard/` that creates a session via `POST /v1/sessions` (no UI wizard) and asserts the checklist's `session` step flips to `complete` within a deterministic window.

**Deliverable:** Creating a session via REST API or CLI flips the checklist's `Create first session` step to complete just as the wizard UI does today.

**Validation:**
- [ ] `bash scripts/lint-trusted-types.sh` passes.
- [ ] `uv run pytest tests/api/ -k session -x -q` passes (Team B's CLI tests + your event tests).
- [ ] If e2e tests are configured: regression test for REST-driven checklist advancement passes.
- [ ] Manual: log in fresh, run `curl -X POST .../v1/sessions ...`, refresh dashboard → checklist shows `Create first session` ✓.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Pull `main` immediately before starting so you pick up Team B's commit.
- If `team_B_verify.md` shows Team B already added an SSE publish on POST /sessions, **don't add another**; just wire the dashboard subscriber.
- Do NOT bypass the bus — `window.finletBus.publish` / `subscribe`, never raw `dispatchEvent`.
- Update `dashboard/event-contract.md` in the same commit if you add a new event name.

---

### Team E: Docs + ledger
**Blocked by:** A, B, C, D (needs every merged commit SHA on `main`).

**Read these files first:**
- `docs/REMAINING_TASKS.md` — pattern for "Bug Hunt $TS — Closed" subsection (mirror prior iterations 20260429T232205Z17ff, 20260429T052717Z1a13).
- `docs/LESSONS.md` — append a lesson per real-broken finding, framed as a reusable rule.
- `docs/ARCHITECTURE.md` — only update if any of the merged team changes touched: CSP / security headers / middleware / route surface / schema / plugin registry / dashboard surface. Team A (auth dep), Team B (idempotency on POST /sessions, plugins list endpoint), and Team D (SSE publish + new bus event) likely qualify. Team C does not.
- `docs/KNOWN_FAILURES.md` — refresh.
- `docs/bug-hunt/ledger.jsonl` — append exactly 5 lines (one per real-broken finding closed). Schema is fixed in the Required Docs Updates block of `triage.md`. Categories MUST reuse existing tags.

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md`.
- Modified: `docs/LESSONS.md`.
- Modified: `docs/ARCHITECTURE.md` (if Team A/B/D made changes that affect the architecture surface).
- Modified: `docs/KNOWN_FAILURES.md` (only if a pre-existing failure was resolved).
- New: `docs/decisions/<short>.md` ONLY if a non-trivial reversible decision was made (e.g., "CLI plugins list now hits API instead of static dict — single source of truth"). Skip otherwise.
- New: `docs/bug-hunt/20260430T222711Z3666/*` — every artifact produced this iteration must be committed (already on disk: triage.md, triage.json, blind_report.json, blind_diagnostic.log, cleanup.log, plan.md, plus the screenshots in the same dir, plus team_*_verify.md as teams produce them).
- Modified: `docs/bug-hunt/refactor-queue/onboarding-checklist.md` — set `verdict: incomplete` (refactor under-scoped — REST/CLI session-create event was not covered). Add `verdict_set_at: 2026-04-30`, `verdict_set_in: 20260430T222711Z3666`, and a one-paragraph `verdict_evidence:` explaining the gap.
- Modified: `docs/bug-hunt/refactor-queue/trade-ticket-state-sync.md` — set `verdict: effective` (no trade-ticket-state-sync findings in this triage).
- Modified: `docs/bug-hunt/refactor-queue/trusted-types.md` — set `verdict: effective` (no trusted-types findings in this triage).
- Modified: `docs/bug-hunt/ledger.jsonl` — append 5 lines, one per closed finding, with the merge commit SHA from each team.

**Deliverable:** A single docs commit titled `docs: bug-hunt 20260430T222711Z3666 — record fixes for X, Y, Z; LESSONS +N; ARCHITECTURE updated/unchanged; ledger +5; refactor verdicts set` that closes the iteration's documentation obligation.

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` increases by exactly 5.
- [ ] `jq -e '.' < <(tail -5 docs/bug-hunt/ledger.jsonl)` parses cleanly (each line is valid JSON).
- [ ] Every artifact in `docs/bug-hunt/20260430T222711Z3666/` is `git ls-files`-tracked.
- [ ] All three pending-verdict refactor-queue docs (onboarding-checklist, trade-ticket-state-sync, trusted-types) have a verdict.
- [ ] `git log --oneline -1` shows your docs commit on `main`.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Wait until A, B, C, D are merged to `main` before pulling commit SHAs. Use `git log --grep '<keyword from team scope>' -n 1 --pretty=%H` to find each.
- Reuse existing ledger categories: `dashboard-state-sync` (Finding 1), `cli-server-state-mismatch` (mint NEW — no existing tag fits Finding 2), `dirty-state-tracker` (Finding 3), `plugin-registry-routing` (Finding 4), `onboarding-checklist` (Finding 5).
- The CLI cli-server-state-mismatch tag is a new mint — it fits Finding 2's "client thinks it failed but server succeeded" predicate, which doesn't match any existing tag. Document the new tag in your commit message.
- Do NOT delete any artifact under `docs/bug-hunt/20260430T222711Z3666/` — every file is the audit trail.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team B's CLI fix changes the `plugins list` output shape, breaking downstream scripts | Medium | Medium | Keep CLI table columns identical to today; only update which plugins appear. New tests assert column names. |
| Team B + D both touch `routes_session.py` and produce a merge conflict | Medium | Low | Sequence B → D. Team D pulls main + reads `team_B_verify.md` before editing the file. |
| Team A's auth-deps change affects routes that intentionally relied on cookie 401 | Medium | High | Grep `_OptionalUser` usages before broad-stroke change. If any route relies on the strict behavior, add a `required_user` dependency rather than weakening `optional_user`. |
| Team C "fixes" the dirty banner by removing fields from tracking | Low | High | Explicit "do not delist" in agent instructions. Reviewer should reject diffs that shrink the tracked-fields set. |
| Team D adds a new bus event but forgets `event-contract.md` | Medium | Low | Explicit instruction to update both in the same commit; reviewer rejects otherwise. |
| Team D over-fires `session:switched` and triggers spurious checklist re-flips | Medium | Low | Subscriber should be idempotent (already-checked stays checked). Verify by stress-test or unit. |
| Onboarding-checklist refactor verdict is wrongly set to `effective` | High (verdict-eval is mechanical) | Medium | Phase 6 spec is mechanical: any recurrence with same_root_cause_as → not effective. Team E follows spec; orchestrator double-checks. |

## Session Plan

### Session 1 — parallel work, sequential merges
**Parallel execution:** Teams A, B, C, D all start in their own worktrees concurrently.

**Merge order:**
1. ✅ **Team A merged** (independent; clean diff on auth + tests). Merge: `47c7e79` · Worktree commit: `091fd24`.
   - Targeted gate: `uv run pytest tests/api/ -k auth -x -q`.
2. ✅ **Team B merged** (independent; needed to unblock Team D). Merge: `1616ade` · Worktree commit: `1a3c17e`.
   - Targeted gate: `uv run pytest tests/test_cli.py -x -q` and the new `plugins list` parity test.
3. ✅ **Team C merged** (independent of A and B; clean dashboard diff). Merge: `dba4c83` · Worktree commit: `92dc626`.
   - Targeted gate: trusted-types lint + dashboard tests.
4. ✅ **Team D merged** (after pulling B's `routes_session.py` changes). Merge: `91922c7` · Worktree commit: `9ba0eb8`.
   - Targeted gate: session-create-via-REST checklist regression test.

**Session 1 checkpoint after all four merge:**
- `uv run pytest -x -q` (full suite) green.
- `bash scripts/lint-trusted-types.sh` green.
- `uv run ruff check .` green.

**Status:** ✅ Session 1 complete. Teams A (`47c7e79`), B (`1616ade`), C (`dba4c83`), D (`91922c7`) all merged on `main`. Checkpoint gates green: full pytest suite (3913 passed), ruff, mypy, trusted-types lint, node dashboard tests (47 passed). Ready for Team E.

### Session 2 — Team E (docs + ledger)
- **Sequential:** Team E starts only after Session 1 checkpoint passes.
- Team E pulls all four merge SHAs from `git log` and writes them into the ledger lines + the team verify file.
- Targeted gate: `wc -l docs/bug-hunt/ledger.jsonl` increased by exactly 5; `jq` validates the appended lines; all three pending refactor-queue verdicts are set.
- Final commit on `main`.
