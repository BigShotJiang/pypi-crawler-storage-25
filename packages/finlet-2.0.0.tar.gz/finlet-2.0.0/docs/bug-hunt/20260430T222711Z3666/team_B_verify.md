# Team B verification

Two bundled findings: CLI session-create timeout and CLI/dashboard plugin-list parity.

## Files changed

| File | Lines (post-edit) | Net change |
|------|-------------------|------------|
| `finlet/cli.py` | 655 | +94 / -19 |
| `finlet/api/routes_session.py` | 246 | +47 / -1 |
| `tests/test_cli.py` | 735 | +144 / -0 |
| `docs/bug-hunt/20260430T222711Z3666/team_B_verify.md` | (this file) | +new |

## `finlet/api/routes_session.py` — lines touched (for Team D coordination)

Imports / module setup (lines 8-37):
- L8: added `structlog`
- L9: added `Header` to fastapi import
- L15: added `from finlet.api.idempotency import IdempotencyStore`
- L32: added `logger = structlog.get_logger()`
- L36: added `_idempotency_store = IdempotencyStore()`

Route handler `create_session_route` (lines 90-170):
- L94: added `idempotency_key: str | None = Header(None, alias="Idempotency-Key")` parameter
- L96-103: docstring extended to document idempotency contract
- L104-115: cache-lookup block added at the top of the handler (before `check_session_creation`)
- L156-166: cache-store block added after `record_session_created`, before the `return`

Untouched in this commit (Team D-safe):
- L40-78 — `SessionCreateRequest` / `SessionConfigureRequest` Pydantic models
- L139-149 — `list_sessions`, `get_session` route handlers
- L172-end — `delete_session_route`, `configure_session_route`, `complete_session_route`

The idempotency wrapper sits inside `create_session_route` only; everything else in the file is byte-for-byte identical to the pre-edit version.

## `finlet/cli.py` — fixes

1. `session_create` (now lines ~78-160):
   - Added `Idempotency-Key` header (uuid4-suffixed) on every POST so the server can dedupe a retried request.
   - Added a `_print_created` helper to keep success-output one-shot.
   - Bumped POST timeout from 10s -> 60s (plugin init is slow on cold start).
   - New `except httpx.ReadTimeout:` branch — retries with the same Idempotency-Key, then falls back to `GET /sessions` and matches by name if the retry returns 4xx (e.g. 409 concurrent-session-limit).

2. `plugins_list` (now lines ~228-273):
   - Replaced the hardcoded 4-plugin dict with a call to `GET /v1/plugins/health` (the same endpoint the dashboard uses).
   - Added `--api-key/-k` flag for parity with the rest of the CLI.
   - Graceful degradation: prints "Cannot connect" and exits 1 on `ConnectError`; surfaces server detail on HTTPStatusError; surfaces a generic transport error on other `httpx.HTTPError`.

## Tests added in `tests/test_cli.py`

- `TestSessionCommands.test_session_create_read_timeout_recovers_via_idempotency` — first POST raises `httpx.ReadTimeout`, second POST returns 201 with cached body. Asserts both POSTs use the *same* Idempotency-Key header value.
- `TestSessionCommands.test_session_create_read_timeout_falls_back_to_session_list` — first POST raises `ReadTimeout`, retry returns 409, CLI falls back to `GET /sessions` and finds the session by name.
- `TestPluginsListCommand.test_plugins_list_reports_dashboard_plugin_set` — mocks the API to return all 8 dashboard plugins; asserts every name + status appears in CLI output and that the CLI hit `/v1/plugins/health`.
- `TestPluginsListCommand.test_plugins_list_connection_error` — `ConnectError` -> exit 1 + "Cannot connect" message.

## Validation

- `uv run pytest tests/test_cli.py -x -q` -> 37 passed in 0.48s (was 33 before; +4 new).
- `uv run ruff check finlet/cli.py finlet/api/routes_session.py tests/test_cli.py` -> All checks passed.
- `uv run mypy finlet/cli.py finlet/api/routes_session.py` -> Success: no issues found in 2 source files.
- Spot-checked the broader API-side test surface: `tests/api/test_sessions.py`, `test_api_versioning.py`, `test_session_name.py`, `test_session_complete.py`, `test_e2e_session_flow.py`, `test_session_isolation.py`, `test_session_coverage.py`, `test_session_auth.py` -> 70 passed; `tests/api/test_idempotency.py` -> 3 passed; `tests/api/test_plugin_health.py` -> 13 passed.
