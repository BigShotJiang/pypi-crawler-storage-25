## Broken (will be fixed this iteration)
- 401 error on /v1/auth/session/validate fires on every dashboard load while fully logged in [evidence: "Browser console (all pages): [ERROR] Failed to load resource: the server responded with a status of 401 () @ https://finlet.dev/v1/auth/session/validate. Appears on every navigation to index.html while fully logged in — session validation endpoint rejects the cookie-based auth."] [scope hint: finlet/api/routes_auth.py, dashboard/api-utils.js, dashboard/auth.js]
- `finlet session create` CLI exits with httpx.ReadTimeout but the session is created server-side [evidence: "Running `finlet session create --name fundamentals-eval --start 2024-01-02 --capital 100000 --universe AAPL,MSFT,GOOGL,NVDA` exits with code 1 and httpx.ReadTimeout. However the session WAS created on the server (confirmed via subsequent GET /v1/sessions). A new user would believe the command failed and retry — hitting the 1-session concurrent limit with a confusing 'rate_limited' error."] [scope hint: finlet/cli.py, finlet/api/routes_sessions.py]
- 'You have unsaved changes' banner appears on fresh Settings page load before any edits [evidence: "Navigated directly to /settings.html (no prior edits in this session). Snapshot immediately shows #unsaved-banner with 'You have unsaved changes', Discard and Save Changes buttons. Reproduced on two separate page loads."] [scope hint: dashboard/settings.html, dashboard/settings.js, dashboard/form-dirty-tracker.js]
- Plugin list mismatch: CLI shows 4 plugins, web UI shows 8 — and edgar shows 'ready' in CLI but 'unhealthy' in web UI [evidence: "`finlet plugins list` returns: price (ready), edgar (ready), fred (needs API key), finnhub (needs API key). Web UI Plugin Health shows 8 plugins: price, fundamentals_s3, news_s3, sentiment, finnhub, fred, econ, edgar — where edgar is 'unhealthy: edgar plugin not initialized' and fundamentals_s3/news_s3/sentiment/econ are absent from the CLI entirely."] [scope hint: finlet/cli.py, finlet/api/routes_admin.py, finlet/plugins/registry.py, dashboard/settings.js]
- 'Getting Started' checklist does not mark 'Create first session' complete even with an active session [evidence: "After creating session 'fundamentals-eval' (ACTIVE, visible in the session dropdown), the checklist shows 2/4 complete: 'Set up profile' ✓ and 'Run first analysis' ✓ — but 'Create first session' remains unchecked. The checklist only marks it complete when created through the wizard's specific UI flow, not via REST API or CLI."] [scope hint: dashboard/onboarding.js, dashboard/app.js]

## Logged (not actioned)
- Settings sidebar has two separate 'API Keys' entries — 'API Keys & Security' and 'API Keys' — with no visual distinction [classification: annoying]
- No way to view full existing API key values — 'Copy API Key' gives no visual confirmation of what was copied [classification: annoying]
- Onboarding wizard blocks the entire page with a modal overlay — impossible to reach the user menu or nav while it's open [classification: annoying]
- Plugin Health shows internal names (fundamentals_s3, news_s3, econ) — no human-readable display names [classification: annoying]
- Fundamentals API returns raw XBRL field names, not human-readable labels [classification: annoying]
- Session clock starts FROZEN with no contextual hint to the user about what to do next [classification: annoying]
- Page title reads 'Finlet — AI Trading Agent ITE' — 'ITE' is unexplained jargon for a first-time visitor [classification: annoying]
- REST API validation error message exposes internal field name 'body.start_time' rather than a user-friendly name [classification: annoying]
- No 'Fundamentals' session template — only Conservative ETF, Tech Growth, Custom [classification: nice-to-have]
- No computed financial ratios endpoint — only raw XBRL fields [classification: nice-to-have]
- No guided MCP setup flow in the web UI — requires manual JSON editing of Claude Desktop config [classification: nice-to-have]
- Strategy example library — no pre-built prompts or starter agent code for fundamentals, momentum, or mean-reversion strategies [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260430T222711Z3666 — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made.
6. `docs/bug-hunt/20260430T222711Z3666/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   blind_diagnostic.log, team_*_verify.md, screenshots).
   No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260430T222711Z3666","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.

Team D's commit message must reference iteration 20260430T222711Z3666 and name which docs were
touched (e.g., "docs: bug-hunt 20260430T222711Z3666 — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
