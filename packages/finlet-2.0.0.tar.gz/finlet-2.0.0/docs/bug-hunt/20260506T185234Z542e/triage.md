## Broken (will be fixed this iteration)
- Plugin Health widget shows "Connect a data source" empty state on initial load even though 8 plugins are configured — UI state contradicts backend reality [evidence: "Before selecting any session, the Plugin Health panel displays 'Connect a data source — Add a market data plugin…' with a link to the Setup Guide. But navigating to Settings > Plugins shows 8 plugins already installed (price, fundamentals_s3, news_s3, sentiment, finnhub, fred, econ, edgar). The empty state is false: plugins exist, they just can't be queried without an active session."] [scope hint: dashboard/app.js, dashboard/index.html]
- User-menu label "Copy API Key" (collapsed) vs "Manage API Key" (expanded) — same documented affordance presents two different contracts; the collapsed-menu label sets a clipboard expectation the click never satisfies [evidence: "In the collapsed menu ARIA snapshot: menuitem 'Copy API Key'. In the expanded menu ARIA snapshot: menuitem 'Manage API Key'. Clicking it navigates to settings.html#api-keys — it does NOT copy anything to clipboard. The label shown before clicking ('Copy API Key') sets a wrong expectation."] [scope hint: dashboard/shared-nav.js]
- "Run first analysis" checklist row auto-checks on a trade fill — checklist state contradicts the row's documented meaning (a trade is not an analysis) [evidence: "After submitting a BUY SPY order via the CLI, the checklist updated to '2/4 complete' and showed 'Run first analysis' checked. Placing a market order is not the same as 'running an analysis' — this conflates two different user actions and will confuse users about what constitutes an analysis."] [scope hint: dashboard/onboarding.js, dashboard/app.js]

## Logged (not actioned)
- Finlet MCP server tools never surface in subprocess [classification: working-as-designed]
- Benchmark REST endpoints return 404/405 [classification: nice-to-have]
- news_s3 / sentiment plugins degraded with no dashboard-level fix path [classification: nice-to-have]
- Settings sidebar has two API-key sections "API Keys & Security" and "API Keys" [classification: annoying]
- Full API key value is never displayed (only last-4 truncation) [classification: working-as-designed]
- Wizard Continue button disabled with no explanation; Welcome alert + wizard rendered simultaneously [classification: annoying]
- Plugin internal names "fundamentals_s3" / "news_s3" exposed in user copy [classification: annoying]
- finnhub / fred / edgar plugins show "plugin not initialized" with no CTA [classification: annoying]
- Session creation dialog took ~24 seconds with no progress indicator [classification: annoying]
- Trade Ticket dialog has no current-sim-price / estimated-cost preview before submit [classification: nice-to-have]
- Plugin Health error cards have no "Fix in Settings" deep-link [classification: nice-to-have]
- Benchmark scenarios are invisible from the UI (MCP/CLI-only) [classification: nice-to-have]
- No price/fundamentals lookup affordance inside Trade Ticket [classification: nice-to-have]
- "Set up profile" checklist item never completes after Profile-tab visit [classification: needs-investigation]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260506T185234Z542e — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. `docs/bug-hunt/20260506T185234Z542e/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log,
   deploy_status.txt, retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260506T185234Z542e","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline (see
   Phase 5.5c). Team D MUST stage the file. If a refactor verdict pruned entries
   this iteration, Team D MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`
   (the audit log of resolved signals).

Team D's commit message must reference iteration 20260506T185234Z542e and name which docs were
touched (e.g., "docs: bug-hunt 20260506T185234Z542e — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
