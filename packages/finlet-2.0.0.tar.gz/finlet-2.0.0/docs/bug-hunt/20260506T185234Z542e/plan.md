# Bug Hunt 20260506T185234Z542e — Execution Plan

> Generated from `docs/bug-hunt/20260506T185234Z542e/triage.md`. Baseline: HEAD `a851358`.

## Constraints
- Three real-broken findings to close: Plugin Health "Connect a data source" empty-state mismatch on no-session (`dashboard/app.js`), user-menu API-key label race between collapsed/expanded states (`dashboard/shared-nav.js`), and "Run first analysis" checklist label mismatch with its trigger (`dashboard/onboarding.js`).
- No file conflicts between Teams A, B, C — they run fully in parallel under worktree isolation. Team E (ledger) and Team D (docs) run last, sequenced after merge SHAs are known.
- Dashboard CLAUDE.md rules apply: vanilla HTML/JS/CSS only, event-bus wiring via `window.finletBus.subscribe`, no direct `addEventListener('finlet:...')`. Trusted-types lint applies to any `.innerHTML =` writes (use `trustedHTML(...)`).
- Existing onboarding registry contract (`WIZARD_STEPS` / `CHECKLIST_STEPS`) stays canonical — Team C may NOT add a parallel step or rename the internal `key`. Only the user-visible `label` field is in scope.
- Renaming the `key: 'analysis'` would ripple to 7+ sites (`onboarding.js:50,159,249,263,273,849,889` + `event-contract.md:163,213`). Out of scope for this iteration; minimal-blast-radius fix is the label only.

## File Conflict Table

| File | Touched by Teams |
|------|------------------|
| `dashboard/app.js` | A |
| `dashboard/shared-nav.js` | B |
| `dashboard/onboarding.js` | C |
| `tests/e2e/journey-04-dashboard.spec.ts` | A |
| `tests/e2e/journey-onboarding.spec.ts` (or sibling) | B, C |
| `docs/bug-hunt/ledger.jsonl` | E |
| `docs/REMAINING_TASKS.md`, `docs/LESSONS.md`, `docs/ARCHITECTURE.md`, `docs/KNOWN_FAILURES.md`, `docs/decisions/*`, `docs/bug-hunt/20260506T185234Z542e/*`, `docs/bug-hunt/pending_recurrences.jsonl` | D |

If Team B and Team C both want to add Playwright assertions to `tests/e2e/journey-onboarding.spec.ts`, they conflict. **Resolution:** Team B uses a fresh spec `tests/e2e/journey-shared-nav.spec.ts` (or the existing `tests/dashboard/shared-nav.spec.js` if present); Team C extends `tests/e2e/journey-05-trade.spec.ts` (the trade-fill + checklist surface) or onboarding.spec.ts if no other team is touching it.

## Dependency Graph

- **Team A** (Plugin Health no-session empty state) — independent, can start immediately.
- **Team B** (user-menu API-key label race) — independent, can start immediately.
- **Team C** (checklist analysis-label mismatch) — independent, can start immediately.
- **Team E** (ledger) — blocked by A, B, C all merged (needs their merge SHAs).
- **Team D** (docs) — blocked by Team E.

## Critical Path

`max(Team A, Team B, Team C) → Team E → Team D`

Team E and Team D are short and mechanical. Real critical path is whichever of A/B/C takes longest to land.

---

## Teams

### Team A: Plugin Health — distinguish "no session" from "no plugins"

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/app.js:1815-1900` — `fallbackPollNow(sessionId)` and the parallel fetch batch including `/plugins/health`.
- `dashboard/app.js:2425-2455` — `renderPlugins(plugins)` empty-state guards.
- `dashboard/app.js:2613-2660` — `clearDashboard()` no-session fallback paths.
- `dashboard/app.js:700-730` — `showContextEmptyState(target, contextKey)` registry (find where `'no-plugins'` is mapped) to discover whether a `'no-session'` (or equivalent) context key already exists.
- `dashboard/index.html:350-360` — initial static markup for the plugin-cards widget.

**Recon evidence (verified by recon agent against HEAD `a851358`):**

```javascript dashboard/app.js:2428-2450
function renderPlugins(plugins) {
    const container = document.getElementById('plugin-cards');

    if (!plugins || (Array.isArray(plugins) && !plugins.length)) {
        if (typeof showContextEmptyState === 'function') {
            showContextEmptyState('plugin-cards', 'no-plugins');
        } else {
            setStaticHTML(container, '<div class="empty-state"><p class="empty-state__headline">Connect a data source</p><p class="empty-state__text">Add a market data plugin to power your trading agent.</p></div>');
        }
        return;
    }
```

```javascript dashboard/app.js:2640-2650
showContextEmptyState('plugin-cards', 'no-plugins');
} else {
    setStaticHTML(document.getElementById('positions-body'),
        '<tr class="empty-row">…</tr>');
    /* … */
    setStaticHTML(document.getElementById('plugin-cards'),
        '<div class="empty-state"><p class="empty-state__headline">Connect a data source</p><p class="empty-state__text">Add a market data plugin to power your trading agent.</p></div>');
}
```

```javascript dashboard/app.js:1817-1824
const [sessionRes, clockRes, portfolioRes, historyRes, ordersRes, traceRes, pluginHealthRes] = await Promise.all([
    dashFetch(`/sessions/${sessionId}`),
    dashFetch(`/sessions/${sessionId}/clock`),
    dashFetch(`/sessions/${sessionId}/portfolio`),
    dashFetch(`/sessions/${sessionId}/portfolio/history`),
    dashFetch(`/sessions/${sessionId}/trade/orders`),
    dashFetch(`/sessions/${sessionId}/trace`),
    dashFetch('/plugins/health'),
]);
```

`/plugins/health` is NOT session-scoped — the URL is `/plugins/health` (line 1823), unlike its siblings which all use `/sessions/${sessionId}/...`. The reason it's not fetched on no-session is purely structural: the whole batch is gated by `fallbackPollNow(sessionId)`, which only runs when a session is active.

**Conclusion:** the bug is a copy-vs-state confusion — `clearDashboard()` (no-session) renders the SAME empty-state copy as `renderPlugins([])` (genuinely zero plugins on backend). Fix surfaces the distinction.

**Files touched:**
- Modified: `dashboard/app.js` — distinguish no-session from no-plugins, either by:
  - **(preferred)** Adding a new `'no-session'` context key to `showContextEmptyState`'s registry that emits "Select a session to see plugin status" copy; route `clearDashboard()`'s plugin-cards path to `'no-session'` instead of `'no-plugins'`.
  - **(alternative)** Drop the session gate on `/plugins/health` only — fetch unconditionally on app init so the widget shows actual plugin list before session selection. (Higher blast radius — touches the fetch sequencing.)
- Modified: `tests/e2e/journey-04-dashboard.spec.ts` — add an assertion that on dashboard load with no active session, the plugin-cards widget does NOT contain the substring "Connect a data source".
- Optional: update `dashboard/index.html:355` to use the no-session copy as initial markup so the first paint matches.

Pick the (preferred) approach unless the registry doesn't exist — then fall back to either alternative.

**Deliverable:** On `https://finlet.dev/index.html` with no active session, the Plugin Health widget no longer shows "Connect a data source" copy. New e2e assertion catches the regression.

**Validation:**
- [ ] `uv run pytest tests/dashboard/ -x -q` — vitest unit tests for dashboard pass (if relevant tests exist there).
- [ ] `npx playwright test tests/e2e/journey-04-dashboard.spec.ts -x` — new + existing assertions pass.
- [ ] Manual smoke (locally or via `npx playwright codegen`): load dashboard with no session, verify plugin-cards widget copy matches new contract.
- [ ] `bash scripts/lint-trusted-types.sh` passes (no bare `.innerHTML =` writes added).
- [ ] `bash scripts/lint-event-bus.sh` passes (no direct `addEventListener('finlet:...')` added).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message format: `dashboard: distinguish no-session from no-plugins empty state (close 20260506T185234Z542e plugin-health-no-session-empty-state)`.
- Follow existing patterns in `dashboard/app.js` for context-key registry usage — do NOT introduce a parallel mechanism.
- Use `trustedHTML(...)` if you need any `.innerHTML =` write under `dashboard/`.
- Keep the static-HTML fallback (the `else` branch when `showContextEmptyState` is undefined) consistent with the new copy — both branches must agree.

---

### Team B: User-menu API-key label — fix collapsed-state stale text

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/shared-nav.js:190-300` — full user-menu render block + click handler.
- `docs/decisions/copy-api-key-dead-affordance.md` — the load-bearing security rationale for the dual-label affordance (cookie-session keys are hash-only; in-memory key is null post-handshake by design).

**Recon evidence (verified by recon agent against HEAD `a851358`):**

```javascript dashboard/shared-nav.js:198
'<button class="user-menu-item" role="menuitem" id="menu-copy-key">Copy API Key</button>'
```

```javascript dashboard/shared-nav.js:278-294
trigger.addEventListener('click', function(e) {
    e.stopPropagation();
    var isOpen = menu.classList.toggle('user-menu--open');
    trigger.setAttribute('aria-expanded', String(isOpen));
    // On open, dynamically relabel the Copy API Key button based on
    // whether a copyable key is actually in memory. The button is one
    // affordance with two semantics:
    //   - "Copy API Key" → clipboard write (signup/just-rotated path)
    //   - "Manage API Key" → redirect to Settings → API Keys (login path)
    // See docs/decisions/copy-api-key-dead-affordance.md.
    if (isOpen) {
        var copyKeyBtnLabel = document.getElementById('menu-copy-key');
        if (copyKeyBtnLabel) {
            var hasKey = (typeof FinletAuth !== 'undefined') && !!FinletAuth.getApiKey();
            copyKeyBtnLabel.textContent = hasKey ? 'Copy API Key' : 'Manage API Key';
        }
    }
});
```

Recon conclusion: the relabel logic IS implemented (288-293) but only fires inside `if (isOpen)`. Any aria-snapshot or screen reader scan taken with the menu CLOSED reads the static `'Copy API Key'` literal from line 198. The collapsed-state text is the lie — the click navigates to settings on the cookie-session path, never copying.

**Files touched:**
- Modified: `dashboard/shared-nav.js` — relabel the button on initial render (after FinletAuth is available) so the static "Copy API Key" text from line 198 is replaced before any user interaction. Two possible patterns:
  - **(preferred)** Run the relabel logic in a one-time post-render init (after the user-menu HTML is mounted to the DOM and FinletAuth is loaded). Re-run it every time the menu's auth state could change (e.g., after login/logout events on the bus, if those exist), so the button stays in sync.
  - **(alternative)** Move the `hasKey` check to the build-time render of the button so the literal at line 198 is never rendered with the wrong text. Requires async-aware rendering since FinletAuth may not be ready at user-menu mount time.
- Modified: `tests/dashboard/shared-nav.spec.js` (if exists) OR `tests/e2e/journey-shared-nav.spec.ts` (new) — assert that the menuitem accessible name is `'Manage API Key'` (cookie-session path) BEFORE the menu is opened, AND remains `'Manage API Key'` after open. Both states must match.

**Deliverable:** On `https://finlet.dev/index.html` (cookie-session login), the user-menu API-key item shows the correct label in both collapsed and expanded ARIA snapshots — never "Copy API Key" when the click navigates rather than copies.

**Validation:**
- [ ] New/updated test assertion passes: collapsed-state menuitem accessible name does NOT equal "Copy API Key" on cookie-session auth.
- [ ] Regression check: the signup/just-rotated path (where `FinletAuth.getApiKey()` returns a non-null key) STILL shows "Copy API Key" and the click STILL writes to clipboard.
- [ ] `bash scripts/lint-trusted-types.sh` passes.
- [ ] `bash scripts/lint-event-bus.sh` passes.
- [ ] Manual smoke: log in with cookie-session, open user-menu, verify label is "Manage API Key" on first paint (before clicking).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message format: `dashboard: relabel user-menu API-key button on initial render (close 20260506T185234Z542e shared-nav-collapsed-label-stale)`.
- Read `docs/decisions/copy-api-key-dead-affordance.md` BEFORE writing the fix — the dual-label affordance is load-bearing, do not collapse it to a single label.
- Do not alter the click handler's behavior — only the LABEL rendering. The redirect-to-settings path on cookie-session auth is correct and intentional.
- If `FinletAuth.getApiKey()` is async or not yet available at user-menu mount time, defer the relabel using a one-shot init pattern (e.g., a `requestAnimationFrame` or microtask, or an existing `auth:ready` bus event if one is wired up).

---

### Team C: Checklist label — rename "Run first analysis" → "Place first trade"

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/onboarding.js:40-60` — `CHECKLIST_STEPS` registry, specifically the `key: 'analysis'` entry.
- `dashboard/onboarding.js:155-165` — persona definitions referencing `step3Action: 'analysis'`.
- `dashboard/onboarding.js:240-260` — `WIZARD_STEPS[2]` (step 3) referencing `advanceTrigger: 'analysis'`.
- `dashboard/onboarding.js:825-895` — `handleTestTrade` and any sibling action handlers that call `markStepComplete('analysis')`.
- `dashboard/event-contract.md:160-220` — bus contract referencing the `analysis` step key.

**Recon evidence (verified by recon agent against HEAD `a851358`):**

```javascript dashboard/onboarding.js:50-54
{
    key: 'analysis',
    label: 'Run first analysis',
    trigger: 'order:filled',
    action: { type: 'open-modal', target: 'trade-ticket' },
},
```

```javascript dashboard/onboarding.js:436-451
for (const step of CHECKLIST_STEPS) {
    if (!step.trigger) continue;
    const stepKey = step.key;
    const eventName = step.trigger;
    window.finletBus.subscribe(eventName, function (payload) {
        if (eventName === 'session:switched'
            && payload && typeof payload.session_id === 'string') {
            createdSessionId = payload.session_id;
        }
        markStepComplete(stepKey);
    });
}
```

```javascript dashboard/onboarding.js:828-850
async function handleTestTrade(btn) {
    if (!createdSessionId) {
        showActionResult('error', 'No session created yet. Please create a session first.');
        return;
    }
    btn.classList.add('action-card--loading');
    try {
        const result = await apiPost(`/sessions/${createdSessionId}/trade/orders`, {
            ticker: 'AAPL', side: 'buy', qty: 1, order_type: 'market',
        });
        if (result) {
            showActionResult('success', 'Test trade submitted! Buy 1 AAPL at market. Check the Order Log panel for status.');
            markStepComplete('analysis');
        }
```

Recon conclusion: the step's `trigger: 'order:filled'` and `action: { type: 'open-modal', target: 'trade-ticket' }` are BOTH consistent with "place a trade" semantics. The `label: 'Run first analysis'` is the only piece that contradicts. Minimal-blast-radius fix: change the label literal. The internal `key: 'analysis'` and all 7 ripple sites stay untouched.

**Files touched:**
- Modified: `dashboard/onboarding.js:51` — change `label: 'Run first analysis'` to `label: 'Place first trade'` (or equivalent honest copy that matches the trigger + action). The internal `key: 'analysis'` MUST stay as-is to preserve the 7 ripple sites and the `event-contract.md` enum.
- Modified: `tests/e2e/journey-05-trade.spec.ts` (or sibling) — add an assertion that after submitting a market order, the checklist row whose `data-step="analysis"` (or equivalent selector) shows visible text matching the new label `'Place first trade'` (or chosen alternative). Verify the row IS still marked complete on `order:filled` — the trigger wiring is correct, only the label was wrong.
- Optional: update any user-facing copy elsewhere in `dashboard/onboarding.js` that references "analysis" as a user-visible string in the wizard's persona-action card for `step3Action: 'analysis'`. Do NOT change the internal key string.

**Deliverable:** On `https://finlet.dev/index.html`, the onboarding checklist row that completes when a trade fills is now labeled "Place first trade" (or equivalent), matching the trigger and action it actually performs.

**Validation:**
- [ ] New/updated `tests/e2e/journey-05-trade.spec.ts` assertion passes: after a MARKET BUY fills, the checklist row's visible label matches the new copy.
- [ ] Regression check: `markStepComplete('analysis')` still fires (line 449 + line 849) — the label change must NOT break the trigger wiring.
- [ ] Regression check: `WIZARD_STEPS[2].advanceTrigger === 'analysis'` (line 249) still resolves correctly — the wizard auto-advances on the same key.
- [ ] `bash scripts/lint-trusted-types.sh` passes.
- [ ] `bash scripts/lint-event-bus.sh` passes.
- [ ] Manual smoke: place a trade via Trade Ticket, watch the checklist row update with the new label.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message format: `dashboard: relabel onboarding 'analysis' step → 'Place first trade' (close 20260506T185234Z542e checklist-analysis-label-mismatch)`.
- Do NOT rename the internal `key: 'analysis'` — it has 7 ripple sites including `event-contract.md`. Only the user-visible `label` is in scope.
- If you find user-visible "analysis" copy in the wizard's persona step 3 cards (e.g., a card titled "Run analysis" routed to the same `step3Action: 'analysis'` flow), align that copy too — but again, no internal key changes.
- If the choice of replacement label is ambiguous, prefer "Place first trade" — it matches `action: { type: 'open-modal', target: 'trade-ticket' }` and the order-filled trigger.

---

### Team E: Ledger entries

**Blocked by:** Teams A, B, C all merged.

**Read these files first:**
- `docs/bug-hunt/ledger.jsonl` — last 5 entries to confirm flat schema and field ordering.
- `docs/bug-hunt/20260506T185234Z542e/triage.json` — read each real-broken item's `category` and `summary` for the ledger line.
- `git log --oneline -n 10` — capture the merge SHAs for Teams A, B, C.

**Files touched:**
- Modified: `docs/bug-hunt/ledger.jsonl` — append exactly 3 JSON lines, one per real-broken finding closed this iteration. Schema:

```json
{"iteration_ts":"20260506T185234Z542e","finding_id":"<short-slug>","category":"<tag>","summary":"<short>","scope_files":["dashboard/x.js","tests/e2e/y.spec.ts"],"team":"<A|B|C>","commit":"<merge-sha-on-main>"}
```

Use these `finding_id` slugs (must match Phase 5.5 retest_results entries):
- Team A: `finding_id: "plugin-health-no-session-empty-state"`, `category: "dashboard-state-sync"`
- Team B: `finding_id: "shared-nav-collapsed-label-stale"`, `category: "aria-label-mismatch"`
- Team C: `finding_id: "checklist-analysis-label-mismatch"`, `category: "onboarding-checklist"`

**Deliverable:** `wc -l docs/bug-hunt/ledger.jsonl` grows by exactly 3 (one per closed broken finding).

**Validation:**
- [ ] `tail -3 docs/bug-hunt/ledger.jsonl | jq .` parses cleanly (3 valid JSON objects).
- [ ] Each line has all 7 required fields: `iteration_ts`, `finding_id`, `category`, `summary`, `scope_files`, `team`, `commit`.
- [ ] Each `commit` field is a real SHA on `origin/main` (`git log origin/main --grep <finding_id> --oneline` returns 1 hit, OR `git show <SHA>` succeeds).

**Agent instructions:**
- You MUST `git add docs/bug-hunt/ledger.jsonl` + `git commit` before finishing. Commit message format: `ledger: bug-hunt 20260506T185234Z542e — plugin-health-no-session (Team A), shared-nav-label (Team B), checklist-analysis-label (Team C)`.
- Read the `team` and `commit` fields from `git log --oneline origin/main` — match the team's commit to the correct entry.
- If a team's merge failed, write its ledger line with `commit: ""` and a comment noting the failure; Team D will surface the gap in the docs commit.

---

### Team D: Documentation updates

**Blocked by:** Team E merged.

**Read these files first:**
- `docs/bug-hunt/20260506T185234Z542e/triage.md` — full triage with Required Docs Updates block.
- `docs/REMAINING_TASKS.md` — find the open items (if any) that align with the closed findings; close them.
- `docs/LESSONS.md` — last 3 entries to confirm format and tone.
- `docs/ARCHITECTURE.md` — find any section that may need updating (likely none this iteration — these are minor dashboard fixes).
- `docs/bug-hunt/ledger.jsonl` — read the 3 entries Team E just appended; reference their commit SHAs in the Team D commit message.
- `docs/decisions/copy-api-key-dead-affordance.md` — referenced by Team B's fix; if the relabel-on-initial-render pattern is added, append an addendum noting the timing fix.

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — add the "Bug Hunt 20260506T185234Z542e — Closed" subsection mirroring prior iteration patterns (see `git log --grep 'Bug Hunt 20260505T'` for examples).
- Modified: `docs/LESSONS.md` — append at least one reusable lesson per real-broken finding:
  - **Plugin Health widget**: empty-state copy must not conflate "no session" with "no plugins" — distinguish session-gating from data-availability empty states explicitly.
  - **User-menu label race**: deferred-relabel logic that fires only on toggle leaks the static markup text to ARIA snapshots; relabel-on-initial-render is required when the static literal is the wrong default.
  - **Checklist label-trigger consistency**: the `label`, `trigger`, and `action` fields of a CHECKLIST_STEPS entry MUST be semantically aligned. If the trigger is `order:filled` and the action opens the trade ticket, the label is about trades — not analysis.
- Modified: `docs/ARCHITECTURE.md` — likely no-op this iteration. State explicitly in the commit message: "ARCHITECTURE.md unchanged this iteration (only minor dashboard copy fixes)."
- Modified: `docs/KNOWN_FAILURES.md` — pre-flight refresh; remove any entry resolved this iteration; add any newly discovered pre-existing failure noted in triage.
- New (optional): `docs/decisions/<short-name>.md` — add a 1-page record ONLY if Team B's fix introduced a non-trivial reversible decision (e.g., "user-menu relabel runs on initial render, not just toggle"). If just a one-line bug fix, skip with explicit note.
- Modified: `docs/bug-hunt/pending_recurrences.jsonl` — stage as-is (Phase 5.5c will append entries inline if any retest fails; if no fails, file is unchanged but staged anyway).
- New: `docs/bug-hunt/20260506T185234Z542e/team_*_verify.md` (if any team produced verification notes outside the standard validation checks) — stage them too.
- Stage: every artifact in `docs/bug-hunt/20260506T185234Z542e/` produced this iteration (`triage.md`, `triage.json`, `plan.md`, `blind_report.json`, `blind_report.envelope.json`, `cleanup.log`, `isolation_warning.txt`, `blind_stdout.log`, `blind_stderr.log`, `deploy_status.txt`, `retest_results.json` if Phase 5.5 ran).

**Deliverable:** Single docs commit on `main` that references the 3 ledger entries from Team E and stages every artifact produced this iteration.

**Validation:**
- [ ] `git status docs/` shows zero untracked files in `docs/bug-hunt/20260506T185234Z542e/`.
- [ ] `git log -1 --format=%s` matches the format: `docs: bug-hunt 20260506T185234Z542e — record fixes for X; LESSONS +N; ARCHITECTURE unchanged this iteration; ledger +3 (Team E commit <sha>)`.
- [ ] `wc -l docs/LESSONS.md` grows by ≥3 (one lesson per real-broken finding) OR commit message states "no new lessons this iteration" with justification.
- [ ] `docs/REMAINING_TASKS.md` has a new "Bug Hunt 20260506T185234Z542e — Closed" subsection.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message format: `docs: bug-hunt 20260506T185234Z542e — record plugin-health/shared-nav/checklist-label fixes; LESSONS +N; ARCHITECTURE unchanged this iteration; refactor-queue: <verdicts set this iteration>; ledger +3 (Team E commit <sha>)`.
- Stage every artifact from `docs/bug-hunt/20260506T185234Z542e/` — none should remain untracked.
- If Phase 6 sets a refactor-queue verdict, mention it in the commit message (e.g., "refactor-queue: 0 verdicts set this iteration" if none).
- If Phase 5.5 produces patch-ineffective signals, the orchestrator already appended them to `docs/bug-hunt/pending_recurrences.jsonl` — Team D ONLY stages the file; do not edit it.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A's empty-state copy change breaks an existing Playwright test that asserts the literal "Connect a data source" string | Medium | Low | Team A's spec includes updating `tests/e2e/journey-04-dashboard.spec.ts`; do a `grep -rn "Connect a data source" tests/` BEFORE editing the dashboard to find all assertion sites. |
| Team B's relabel-on-initial-render runs before `FinletAuth` is loaded → races to wrong label | Medium | Medium | Defer the relabel via a microtask or wait for a `FinletAuth.ready` signal (if one exists); if not, document the timing dependency in the decision record and add a regression test that mounts the menu after a simulated `FinletAuth` ready event. |
| Team C's label change affects the wizard's persona action card copy | Low | Low | Recon shows the wizard step's `advanceTrigger` and `step3Action` use the internal `key: 'analysis'` (string identifier) — they don't reference the `label`. Sanity-check with `grep -n 'Run first analysis' dashboard/` before editing to confirm only one site uses the user-visible string. |
| Tests run as worker = `general-purpose` (Opus 4.7) but the team accidentally uses Codex — wrong model for SWE-Bench-Pro-class fixes | Low | Medium | `/exec-plan` defaults to `general-purpose`; only flip with `--worker-type codex:codex-rescue` for shell/CLI loops. None of these teams qualify. Worker type stays default. |
| Team E reads the wrong merge SHA (e.g., grabs the worktree-local SHA instead of the merged-to-main SHA) | Low | High | Team E's spec explicitly says "read from `git log origin/main`" and includes a validation check: `git show <SHA>` must succeed. |
| Phase 5.5 retest of finding C (checklist) interferes with finding A (plugin health) state on shared test account — leaked session leaves stale UI state | Medium | Medium | Each retest is independent and cleans up its own state. The retest agent's prompt (Phase 5.5b) mandates try/finally cleanup on every retest, regardless of assertion outcome. |
| Static `'Connect a data source'` literal appears in `dashboard/index.html:355` AND in `dashboard/app.js:2438,2649` — Team A misses one site | Low | Medium | Spec lists all three sites under "Files touched". Team A must `grep -rn 'Connect a data source' dashboard/` before declaring DONE. |

## Session Plan

### Session 1 — Parallel fixes
**Parallel:** Teams A, B, C (no shared files; no logical dependencies; no test-spec conflict if Team B and C use sibling specs as advised).
**Merge order:** A merges first → targeted spec-04-dashboard tests pass on main → B merges → shared-nav targeted tests pass → C merges → spec-05-trade tests pass.
**Session checkpoint:** `uv run pytest -x -q` (full Python suite) + `npx playwright test` (full e2e suite) after all three merge.

### Session 2 — Ledger + docs
**Sequential:** Team E (ledger append, 3 lines) → Team D (docs commit referencing Team E's SHA).
**Merge order:** E merges → `wc -l docs/bug-hunt/ledger.jsonl` shows +3 → D merges → `git log --grep 20260506T185234Z542e --oneline` shows the docs commit at HEAD.
**Session checkpoint:** Phase 5.5 deploy wait + retest sub-step. Real-world signal of "did the fix actually ship" lives there, not in this plan.

---

## Plan Validation (PF-18 scan)

Scanned plan body for unverified "current state" claims. All file:line claims about HEAD behavior are backed by either:
- A fenced code block with `file:line_start-line_end` info string and HEAD-quoted content (Teams A, B, C have these in their "Recon evidence" sections).
- A paraphrase ending with `(verified by recon agent against HEAD a851358)` (Team A, B, C all carry this tag in their recon-evidence subsections).

All "current state" claims pass the PF-18 scan.
