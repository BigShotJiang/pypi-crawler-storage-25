You are Team C: Checklist label — rename "Run first analysis" → "Place first trade".

Working dir is the worktree. Use `git -C $(pwd)` for git ops. Plan: `docs/bug-hunt/20260506T185234Z542e/plan.md` — read your section (Team C, lines ~184-260).

**Blocked by:** none — start immediately.

**Read these files first:**
- `dashboard/onboarding.js:40-60` — `CHECKLIST_STEPS` registry, specifically the `key: 'analysis'` entry.
- `dashboard/onboarding.js:155-165` — persona definitions referencing `step3Action: 'analysis'`.
- `dashboard/onboarding.js:240-260` — `WIZARD_STEPS[2]` (step 3) referencing `advanceTrigger: 'analysis'`.
- `dashboard/onboarding.js:825-895` — `handleTestTrade` and any sibling action handlers that call `markStepComplete('analysis')`.
- `dashboard/event-contract.md:160-220` — bus contract referencing the `analysis` step key.
- `docs/KNOWN_FAILURES.md` — pre-existing test failures; do NOT report these as issues.

**Recon evidence (verified by recon agent against HEAD `a851358`):**

```javascript dashboard/onboarding.js:50-54
{
    key: 'analysis',
    label: 'Run first analysis',
    trigger: 'order:filled',
    action: { type: 'open-modal', target: 'trade-ticket' },
},
```

The step's `trigger: 'order:filled'` and `action: { type: 'open-modal', target: 'trade-ticket' }` are BOTH consistent with "place a trade" semantics. The `label: 'Run first analysis'` is the only piece that contradicts. Minimal-blast-radius fix: change the label literal. The internal `key: 'analysis'` and all 7 ripple sites stay untouched (`onboarding.js:50,159,249,263,273,849,889` + `event-contract.md:163,213`).

**Files touched:**
- Modified: `dashboard/onboarding.js:51` — change `label: 'Run first analysis'` to `label: 'Place first trade'` (or equivalent honest copy that matches the trigger + action). The internal `key: 'analysis'` MUST stay as-is.
- Modified: `tests/e2e/journey-05-trade.spec.ts` (or create a sibling) — add an assertion that after submitting a market order, the checklist row whose `data-step="analysis"` (or equivalent selector) shows visible text matching the new label `'Place first trade'`. Verify the row IS still marked complete on `order:filled` — the trigger wiring is correct, only the label was wrong.
- Optional: update any user-visible "analysis" copy elsewhere in `dashboard/onboarding.js` that's part of the wizard's persona-action card for `step3Action: 'analysis'` if it phrases the action as "analysis" rather than "trade." DO NOT change the internal key string.

**Deliverable:** On `https://finlet.dev/index.html`, the onboarding checklist row that completes when a trade fills is now labeled "Place first trade" (or equivalent), matching the trigger and action it actually performs.

**Validation (run before declaring DONE):**
- [ ] New/updated `tests/e2e/journey-05-trade.spec.ts` assertion passes: after a MARKET BUY fills, the checklist row's visible label matches the new copy.
- [ ] Regression check: `markStepComplete('analysis')` still fires (line 449 + line 849) — the label change must NOT break the trigger wiring.
- [ ] Regression check: `WIZARD_STEPS[2].advanceTrigger === 'analysis'` (line 249) still resolves correctly — the wizard auto-advances on the same key.
- [ ] `grep -n "'analysis'" dashboard/onboarding.js | wc -l` returns ≥7 (your label change must NOT remove any internal-key occurrences).
- [ ] `bash scripts/lint-trusted-types.sh` passes.
- [ ] `bash scripts/lint-event-bus.sh` passes.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message format: `[Team C]: dashboard: relabel onboarding 'analysis' step → 'Place first trade' (close 20260506T185234Z542e checklist-analysis-label-mismatch)`.
- Do NOT rename the internal `key: 'analysis'` — it has 7 ripple sites including `event-contract.md`. Only the user-visible `label` is in scope.
- If you find user-visible "analysis" copy in the wizard's persona step 3 cards (e.g., a card titled "Run analysis"), align that copy too — but again, no internal key changes.
- If the choice of replacement label is ambiguous, prefer "Place first trade" — matches the trigger + action.
- Use `tests/e2e/journey-05-trade.spec.ts` for your e2e test — do NOT touch `tests/e2e/journey-onboarding.spec.ts` (Team B may use a sibling spec).

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns in those files.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message must start with `[Team C]:`.
- Run the validation commands from your spec before finishing.
- If validation fails, fix the issue and re-commit.

When done, report: `DONE + commit hash + validation results`. OR `BLOCKED + what went wrong`.
