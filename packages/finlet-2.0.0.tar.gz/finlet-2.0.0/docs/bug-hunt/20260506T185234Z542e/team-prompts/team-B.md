You are Team B: User-menu API-key label — fix collapsed-state stale text.

Working dir is the worktree. Use `git -C $(pwd)` for git ops. Plan: `docs/bug-hunt/20260506T185234Z542e/plan.md` — read your section (Team B, lines ~124-181).

**Blocked by:** none — start immediately.

**Read these files first:**
- `dashboard/shared-nav.js:190-300` — full user-menu render block + click handler.
- `docs/decisions/copy-api-key-dead-affordance.md` — the load-bearing security rationale for the dual-label affordance (cookie-session keys are hash-only; in-memory key is null post-handshake by design). The dual-label affordance is intentional — DO NOT collapse it to a single label.
- `docs/KNOWN_FAILURES.md` — pre-existing test failures; do NOT report these as issues.

**Recon evidence (verified by recon agent against HEAD `a851358`):**

The relabel logic IS implemented in `dashboard/shared-nav.js:288-293` but only fires inside `if (isOpen)`. Any aria-snapshot or screen reader scan taken with the menu CLOSED reads the static `'Copy API Key'` literal from line 198. The collapsed-state text is the lie — the click navigates to settings on the cookie-session path, never copying.

```javascript dashboard/shared-nav.js:198
'<button class="user-menu-item" role="menuitem" id="menu-copy-key">Copy API Key</button>'
```

```javascript dashboard/shared-nav.js:278-294
trigger.addEventListener('click', function(e) {
    e.stopPropagation();
    var isOpen = menu.classList.toggle('user-menu--open');
    trigger.setAttribute('aria-expanded', String(isOpen));
    if (isOpen) {
        var copyKeyBtnLabel = document.getElementById('menu-copy-key');
        if (copyKeyBtnLabel) {
            var hasKey = (typeof FinletAuth !== 'undefined') && !!FinletAuth.getApiKey();
            copyKeyBtnLabel.textContent = hasKey ? 'Copy API Key' : 'Manage API Key';
        }
    }
});
```

**Files touched:**
- Modified: `dashboard/shared-nav.js` — relabel the button on initial render (after FinletAuth is available) so the static "Copy API Key" text from line 198 is replaced before any user interaction.
  - **(preferred)** Run the relabel logic in a one-time post-render init (after the user-menu HTML is mounted to the DOM and FinletAuth is loaded). Re-run on auth-state-change events if the bus exposes them.
  - **(alternative)** Move the `hasKey` check to the build-time render of the button so the literal at line 198 is never rendered with the wrong text.
- Modified: `tests/dashboard/shared-nav.spec.js` (if it exists) OR a new `tests/e2e/journey-shared-nav.spec.ts` — assert that the menuitem accessible name is `'Manage API Key'` (cookie-session path) BEFORE the menu is opened, AND remains `'Manage API Key'` after open. Both states must match.

**Deliverable:** On `https://finlet.dev/index.html` (cookie-session login), the user-menu API-key item shows the correct label in both collapsed and expanded ARIA snapshots — never "Copy API Key" when the click navigates rather than copies.

**Validation (run before declaring DONE):**
- [ ] New/updated test assertion passes: collapsed-state menuitem accessible name does NOT equal "Copy API Key" on cookie-session auth.
- [ ] Regression check: the signup/just-rotated path (where `FinletAuth.getApiKey()` returns a non-null key) STILL shows "Copy API Key" and the click STILL writes to clipboard.
- [ ] `bash scripts/lint-trusted-types.sh` passes.
- [ ] `bash scripts/lint-event-bus.sh` passes.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message format: `[Team B]: dashboard: relabel user-menu API-key button on initial render (close 20260506T185234Z542e shared-nav-collapsed-label-stale)`.
- Read `docs/decisions/copy-api-key-dead-affordance.md` BEFORE writing the fix — the dual-label affordance is load-bearing, do not collapse it to a single label.
- Do not alter the click handler's behavior — only the LABEL rendering. The redirect-to-settings path on cookie-session auth is correct and intentional.
- If `FinletAuth.getApiKey()` is async or not yet available at user-menu mount time, defer the relabel using a one-shot init pattern (e.g., a `requestAnimationFrame` or microtask, or an existing `auth:ready` bus event).
- Use `tests/e2e/journey-shared-nav.spec.ts` (new) for your e2e test if you create one — do NOT add to `tests/e2e/journey-onboarding.spec.ts` (Team C may touch that file).

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns in those files.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message must start with `[Team B]:`.
- Run the validation commands from your spec before finishing.
- If validation fails, fix the issue and re-commit.

When done, report: `DONE + commit hash + validation results`. OR `BLOCKED + what went wrong`.
