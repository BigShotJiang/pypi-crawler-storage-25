You are Team A: Plugin Health — distinguish "no session" from "no plugins".

Working dir is the worktree. Use `git -C $(pwd)` for git ops. Plan: `docs/bug-hunt/20260506T185234Z542e/plan.md` — read your section (Team A, lines ~44-120).

**Blocked by:** none — start immediately.

**Read these files first:**
- `dashboard/app.js:1815-1900` — `fallbackPollNow(sessionId)` and the parallel fetch batch including `/plugins/health`.
- `dashboard/app.js:2425-2455` — `renderPlugins(plugins)` empty-state guards.
- `dashboard/app.js:2613-2660` — `clearDashboard()` no-session fallback paths.
- `dashboard/app.js:700-730` — `showContextEmptyState(target, contextKey)` registry — find where `'no-plugins'` is mapped to discover whether a `'no-session'` (or equivalent) context key already exists.
- `dashboard/index.html:350-360` — initial static markup for the plugin-cards widget.
- `docs/KNOWN_FAILURES.md` — pre-existing test failures; do NOT report these as issues.

**Recon evidence (verified by recon agent against HEAD `a851358`):** see Plan section Team A "Recon evidence" — three fenced excerpts confirming `clearDashboard()` (no-session path) renders the same "Connect a data source" copy as `renderPlugins([])` (genuinely zero plugins). Bug is copy-vs-state confusion: the empty-state literal at `dashboard/app.js:2438` AND `dashboard/app.js:2649` AND `dashboard/index.html:355` is shared between two distinct UI states.

**Files touched:**
- Modified: `dashboard/app.js` — distinguish no-session from no-plugins:
  - **(preferred)** Add `'no-session'` context key to `showContextEmptyState`'s registry that emits "Select a session to see plugin status" copy; route `clearDashboard()`'s plugin-cards path to `'no-session'` instead of `'no-plugins'`.
  - **(alternative)** Drop the session gate on `/plugins/health` only — fetch unconditionally on app init so the widget shows actual plugin list before session selection.
  - Pick (preferred) unless the registry doesn't exist; then fall back.
- Modified: `tests/e2e/journey-04-dashboard.spec.ts` — add an assertion that on dashboard load with no active session, the plugin-cards widget does NOT contain the substring "Connect a data source" (or asserts the new no-session copy).
- Optional: update `dashboard/index.html:355` initial markup to match the new no-session copy so the first paint is consistent.

**Deliverable:** On `https://finlet.dev/index.html` with no active session, the Plugin Health widget no longer shows "Connect a data source" copy. New e2e assertion catches the regression.

**Validation (run before declaring DONE):**
- [ ] `grep -rn 'Connect a data source' dashboard/ tests/` — confirm you've updated all sites that still need to assert/render the OLD copy. Count matches expected.
- [ ] `cd /Users/justnau/finlet && uv run pytest tests/dashboard/ -x -q` (if dashboard tests exist).
- [ ] `npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-04-dashboard.spec.ts` — new + existing assertions pass. (Note: Playwright config lives at `tests/e2e/playwright.config.ts`, NOT repo root.)
- [ ] `bash scripts/lint-trusted-types.sh` passes.
- [ ] `bash scripts/lint-event-bus.sh` passes.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message format: `[Team A]: dashboard: distinguish no-session from no-plugins empty state (close 20260506T185234Z542e plugin-health-no-session-empty-state)`.
- Follow existing patterns in `dashboard/app.js` for context-key registry usage — do NOT introduce a parallel mechanism.
- Use `trustedHTML(...)` if you need any `.innerHTML =` write under `dashboard/`.
- Keep the static-HTML fallback (the `else` branch when `showContextEmptyState` is undefined) consistent with the new copy.

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns in those files.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message must start with `[Team A]:`.
- Run the validation commands from your spec before finishing.
- If validation fails, fix the issue and re-commit.

When done, report: `DONE + commit hash + validation results`. OR `BLOCKED + what went wrong`.
