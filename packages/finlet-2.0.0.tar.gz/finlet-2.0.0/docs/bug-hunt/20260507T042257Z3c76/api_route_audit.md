# API Route Audit — UI Write-Path Launch Cut Follow-up

> Generated: 2026-05-07. Baseline SHA: `70bde71354ee20bb8f4aef12fb17abb8fb643904`. Scope: 8 write-path routes flagged in `docs/bug-hunt/20260507T042257Z3c76/surface_map.md` lines 220-228 ("CUT Routes (Write-Path)").

## Methodology

For each of the 8 write-path routes flagged in the surface map, searched:

- **Routes definitions**: `finlet/api/` (all `routes_*.py` files), to resolve the actual mounted path. Routers are mounted twice in `finlet/api/app.py:497-505` — once under `/v1/...` (canonical) and once unversioned (deprecated alias).
- **CLI consumers**: `finlet/cli.py` for `httpx.(post|put|patch|delete)` calls and Typer `@app.command()` definitions.
- **MCP consumers**: `finlet/mcp/` (`server.py`, `tools_trading.py`, `tools_portfolio.py`, `tools_benchmark.py`) for `@mcp.tool()` decorated handlers.
- **Internal/indirect consumers**: `finlet/leaderboard/`, `finlet/billing/`, `finlet/api/services/` for in-process `httpx` clients (e.g. ASGI transport benchmarks) and service-layer wrappers.
- **Dashboard consumers**: `dashboard/*.html`, `dashboard/*.js` (sanity check — these are the routes being CUT in this refactor; reads here only confirm "still wired from UI").

Search patterns:
- CLI: `grep -rEn 'httpx\.(post|put|patch|delete)' finlet/cli.py`
- MCP: `grep -rEn '@mcp\.tool' finlet/mcp/` (then read each decorated function for the route it reaches)
- Internal: `grep -rEn '/sessions/.*/trade|/v1/settings|/v1/billing|/sessions/.*/configure' finlet/`

## Surface-Map Path → Actual Route Path Reconciliation

The surface map (`surface_map.md:220-228`) listed `/api/...`-prefixed paths, but **no route file in `finlet/api/` mounts an `/api` prefix**. The canonical mount is `/v1/...`; an unversioned alias is also live. The audit therefore uses the actual route paths below, with surface-map labels alongside.

| # | Surface-map label                              | Actual canonical route                                  | Handler file                          |
|---|------------------------------------------------|----------------------------------------------------------|---------------------------------------|
| 1 | `POST /api/sessions/<id>/orders`               | `POST /v1/sessions/{session_id}/trade/order`             | `finlet/api/routes_trade.py:51`       |
| 2 | `PATCH /api/sessions/<id>/settings`            | `POST /v1/sessions/{session_id}/configure`               | `finlet/api/routes_session.py:211`    |
| 3 | `POST /api/me/profile`                         | `PUT /v1/settings/profile`                               | `finlet/api/routes_settings.py:52`    |
| 4 | `POST /api/me/password`                        | `PUT /v1/settings/password`                              | `finlet/api/routes_settings.py:65`    |
| 5 | `POST /api/me/plugins/<id>/install`            | `PUT /v1/settings/plugins` (shared with config)          | `finlet/api/routes_settings.py:128`   |
| 6 | `PATCH /api/me/plugins/<id>/config`            | `PUT /v1/settings/plugins` (same endpoint as #5)         | `finlet/api/routes_settings.py:128`   |
| 7 | `POST /api/subscriptions/plans/<id>`           | `POST /v1/billing/checkout` + `POST /v1/billing/cancel`  | `finlet/api/routes_billing.py:66,174` |
| 8 | `POST /api/me/account/delete`                  | `DELETE /v1/settings/account`                            | `finlet/api/routes_settings.py:195`   |

(#5 and #6 collapse to a single canonical write-path: `PUT /v1/settings/plugins` is "the canonical write path for plugin credentials" per the route docstring at `routes_settings.py:128-148`. Install vs configure is body-driven, not path-driven.)

## Findings

### 1. `POST /v1/sessions/{session_id}/trade/order`  (surface-map: `POST /api/sessions/<id>/orders`)

**Handler:** `finlet/api/routes_trade.py:51-100` (`submit_order_route`) — delegates to `finlet.api.services.trade_service.submit_order`.

**Consumers:**
- **CLI:** `finlet order` at `finlet/cli.py:604-656`. POSTs to `f"{_API_URL}/sessions/{session}/trade/order"` (unversioned alias) at `cli.py:638`.
- **MCP:** `submit_order` tool at `finlet/mcp/tools_trading.py:18-81`. Calls service-layer `svc_submit_order` directly (in-process), not over HTTP. Same code path as the route handler.
- **INDIRECT:** `finlet/leaderboard/api_strategy.py:435,459,481,517,555` — the API-driven benchmark strategy POSTs to `/sessions/{sid}/trade/order` via in-process `httpx` ASGI transport to validate the full agent-facing surface end-to-end. Used by leaderboard scoring; not user-visible.

**Verdict:** **CLI+MCP** (with additional INDIRECT use by leaderboard benchmark validator). Route is actively used. Highest-redundancy of the 8.

---

### 2. `POST /v1/sessions/{session_id}/configure`  (surface-map: `PATCH /api/sessions/<id>/settings`)

**Handler:** `finlet/api/routes_session.py:211-240` (`configure_session_route`) — delegates to `finlet.api.services.session_service.configure_session`. Updates session name (handled inline at line 224-225), universe, time_step, market_hours_only, plugin_configs.

**Consumers:**
- **CLI:** None. `finlet/cli.py` has no `/configure` POST. Session creation (`finlet session create`) hits `POST /sessions`; there is no CLI command for configure-after-create.
- **MCP:** None. No `configure_session` or `update_settings` tool exists. `finlet/mcp/server.py` exposes `create_session` (line 144), `list_sessions`, `get_session`, `delete_session`, `complete_session`, `pause_session`, `resume_session` — but **no configure**.
- **INDIRECT:** None found via grep.
- **Dashboard:** YES — but dashboard is the surface being CUT; that's the whole point of this audit.

**Verdict:** **ORPHANED** (post-UI-cut). No CLI, no MCP, no internal consumer. The route is reachable only via the to-be-cut dashboard. Candidate for follow-up deletion in a future iteration **OR** add an MCP `configure_session` tool to preserve the capability for agents (recommended — sessions can be paused/resumed but not reconfigured via MCP, which is a real capability gap).

---

### 3. `PUT /v1/settings/profile`  (surface-map: `POST /api/me/profile`)

**Handler:** `finlet/api/routes_settings.py:52-59` (`update_profile`) — delegates to `settings_service.update_profile`.

**Consumers:**
- **CLI:** None. No `finlet profile` / `finlet settings` command exists in `finlet/cli.py`.
- **MCP:** None. No profile-update tool in `finlet/mcp/`.
- **INDIRECT:** None found.

**Verdict:** **ORPHANED** (post-UI-cut). Profile updates (display name, bio, timezone) have no CLI or MCP consumer. The dashboard is the only client. Candidate for follow-up deletion **OR** keep as REST-only (still callable via `curl` with API key — useful for power users editing their public profile shown on the leaderboard).

---

### 4. `PUT /v1/settings/password`  (surface-map: `POST /api/me/password`)

**Handler:** `finlet/api/routes_settings.py:65-72` (`update_password`) — delegates to `settings_service.update_password`.

**Consumers:**
- **CLI:** None. No `finlet password` command.
- **MCP:** None (and password change should never be an MCP tool — credential rotation is a human-in-the-loop operation).
- **INDIRECT:** Referenced in service error string at `settings_service.py:448` (`"PUT /settings/password before deleting your account"`) — guidance, not an internal call.

**Verdict:** **ORPHANED** (post-UI-cut). However, password change is a **mandatory user-facing capability** for any account-bearing service. Cannot truly delete without a replacement (e.g. `finlet password` CLI or a forgot-password email flow that bypasses session login). The forgot-password flow at `routes_auth_credentials.py:327` (`POST /auth/forgot-password`) covers reset-via-email; in-session change still needs this route OR a new CLI command.

**Recommendation:** Keep route, do NOT delete — flag as "ORPHANED but required."

---

### 5 & 6. `PUT /v1/settings/plugins`  (surface-map: `POST .../install` + `PATCH .../config`)

**Handler:** `finlet/api/routes_settings.py:128-148` (`update_plugin`). Single canonical write path for plugin credentials per the docstring: persists per-user config and hot-reloads the plugin via `registry.reload()`. Install vs configure is body-driven (`enabled=True` for install/configure, `enabled=False` to disable), not path-driven.

**Consumers:**
- **CLI:** YES — `finlet plugins add` at `finlet/cli.py:307-368` and `finlet plugins remove` at `finlet/cli.py:371-441`. Both `httpx.put` to `f"{_API_URL}/v1/settings/plugins"` (lines 340, 413). Documented as "the same path the dashboard settings page uses" at `cli.py:315`.
- **MCP:** None. No plugin-config tool in `finlet/mcp/`.
- **INDIRECT:** Referenced by `finlet/api/routes_health.py:145` — docstring on `POST /v1/plugins/{name}/reload` notes that `PUT /v1/settings/plugins` is the canonical write path; reload is the no-config-change kicker.

**Verdict:** **CLI** (single CLI consumer, no MCP). Route is actively used. Highest-priority KEEP because the CLI is the agent's only way to set up plugin credentials (e.g. Finnhub API key, EDGAR User-Agent email).

---

### 7. `POST /v1/billing/checkout` + `POST /v1/billing/cancel`  (surface-map: `POST /api/subscriptions/plans/<id>`)

**Handlers:**
- `finlet/api/routes_billing.py:66-92` (`create_checkout_session`) — Stripe Checkout Session for upgrade.
- `finlet/api/routes_billing.py:174-185` (`cancel_subscription_route`) — downgrade to free tier.

**Consumers:**
- **CLI:** None. No `finlet billing` / `finlet subscribe` / `finlet upgrade` command.
- **MCP:** None (and billing should never be an MCP tool — financial transactions are a human-in-the-loop operation).
- **INDIRECT:** None over HTTP. Stripe webhook at `routes_billing.py:95` handles incoming Stripe events; `process_webhook_event` is a separate ingress, not a caller of `/checkout` or `/cancel`.

**Verdict:** **ORPHANED** (post-UI-cut). Billing has no CLI or MCP consumer. However, like password change, billing is a **user-facing payment operation** that should not be agentic. Two options:

1. Keep the routes; users hit them via `curl` after the UI-cut. Painful but viable for a closed-beta launch.
2. Replace the dashboard checkout/cancel UI with a hosted Stripe checkout link and a CLI command (`finlet billing upgrade --tier=...`).

**Recommendation:** Keep routes for now (Stripe webhook depends on the same router). Do NOT delete pre-launch. Consider adding minimal CLI sugar post-launch.

---

### 8. `DELETE /v1/settings/account`  (surface-map: `POST /api/me/account/delete`)

**Handler:** `finlet/api/routes_settings.py:195-202` (`delete_account`) — delegates to `settings_service.delete_account` (requires password confirmation in body).

**Consumers:**
- **CLI:** None.
- **MCP:** None (account deletion should never be an MCP tool).
- **INDIRECT:** None.

**Verdict:** **ORPHANED** (post-UI-cut). However, GDPR/CCPA right-to-erasure obligations may require a user-accessible deletion path. Like password and billing, this is a **legal-requirement route** that cannot simply be deleted.

**Recommendation:** Keep route, do NOT delete. Flag for follow-up: add a `finlet account delete --confirm` CLI command or a hosted `/delete-account` page so the capability remains discoverable without the SPA dashboard.

---

## Summary

| # | Route                                              | Verdict          | CLI | MCP | INDIRECT | Notes |
|---|----------------------------------------------------|------------------|-----|-----|----------|-------|
| 1 | `POST /v1/sessions/{id}/trade/order`               | **CLI+MCP**      | YES | YES | leaderboard benchmark | Highest redundancy. Safe. |
| 2 | `POST /v1/sessions/{id}/configure`                 | **ORPHANED**     | no  | no  | no       | Real capability gap — recommend adding MCP `configure_session` |
| 3 | `PUT /v1/settings/profile`                         | **ORPHANED**     | no  | no  | no       | Low-priority; safe to leave REST-only |
| 4 | `PUT /v1/settings/password`                        | **ORPHANED but required** | no | no | no   | Mandatory user-facing op — must keep until CLI replacement |
| 5+6 | `PUT /v1/settings/plugins`                       | **CLI** (only)   | YES | no  | health-route docstring | Active. CLI is sole consumer. Critical for agent setup. |
| 7 | `POST /v1/billing/{checkout,cancel}`               | **ORPHANED but required** | no | no | Stripe webhook (separate) | Legal/payment op — keep until CLI replacement |
| 8 | `DELETE /v1/settings/account`                      | **ORPHANED but required** | no | no | no   | GDPR/CCPA — keep until CLI replacement |

**Verdict counts:**
- CLI+MCP: 1 (route #1)
- CLI only: 1 (routes #5/#6 collapsed)
- MCP only: 0
- INDIRECT: 0 (route #1 has bonus indirect, but is already CLI+MCP)
- ORPHANED: 6 (routes #2, #3, #4, #7-checkout, #7-cancel, #8 — but four of those are "ORPHANED but required" by user-facing/legal contract)

Net safe-to-delete-today candidates if we wanted to act on this audit: **0 routes**.
- Route #2 (`/sessions/{id}/configure`) is a true ORPHAN but represents a real capability gap — the right move is to **add an MCP tool**, not delete.
- Routes #3, #4, #7, #8 are ORPHANED-but-required by user-facing or legal obligation; deleting them eliminates capabilities the user must retain.

## Follow-up Recommendations

1. **Add MCP `configure_session` tool** (`finlet/mcp/server.py`) to close the route #2 capability gap. One-shot subagent task.
2. **Add CLI commands** for the four ORPHANED-but-required routes (post-launch follow-up):
   - `finlet account password-change` → wraps `PUT /v1/settings/password`
   - `finlet account delete --confirm` → wraps `DELETE /v1/settings/account`
   - `finlet billing upgrade --tier=<name>` → wraps `POST /v1/billing/checkout`
   - `finlet billing cancel` → wraps `POST /v1/billing/cancel`
   - (`finlet profile update --bio=...` for route #3 is nice-to-have, low-priority.)
3. **Surface-map correction**: `surface_map.md:220-228` lists `/api/...`-prefixed paths that don't exist in the codebase. Update to use the canonical `/v1/...` paths, or note that `/api/...` was an error.
4. **Routes #5/#6 (plugin install vs config) are a single endpoint** — the surface map double-counts them. The `enabled=True/False` flag in the request body distinguishes install/disable; "config update" is the same endpoint. Update surface_map to reflect "1 plugin write-path, not 2."

## Audit Constraints

- This audit modifies no production code.
- No routes are deleted.
- All findings are advisory; deletion or migration decisions require explicit follow-up planning.
