# Dashboard Surface Map: UI Removal for Launch Cut

**Date**: 2026-05-06  
**Decision**: Cut all write-path UI surfaces; preserve read-only monitoring dashboard  
**Reference**: `docs/decisions/ui-removal-launch-cut.md`

---

## Summary

### File Counts
| Status | Count | Files |
|--------|-------|-------|
| **KEEP** | 18 | Core read-only dashboard, auth, landing, leaderboard, infrastructure |
| **CUT** | 15 | Trade ticket, onboarding, settings write tabs, billing, marketplace, modals |
| **TRIM** | 5 | Index.html, settings.js, leaderboard-submit.js, modal-controller.js, app.js |
| **INFRA** | 6 | CSS (global, auth, landing), vendor, favicon, llms.txt |
| **Total Dashboard Files** | 44 | |

### Tests (26 files)
| Status | Count |
|--------|-------|
| **KEEP** | 9 | Read-only journeys: landing, signup, login, dashboard, leaderboard, CLI |
| **CUT** | 9 | Write-path journeys: trade, settings, billing, onboarding, modals |
| **INFRA** | 8 | Mobile, keyboard (a11y), CLI serve, blindness, CSRF, trusted-types, sim-time |

### Event Contract
| Status | Event | Action |
|--------|-------|--------|
| **KEEP** | `portfolio:updated` | Core monitoring; equity curve + metrics use this |
| **KEEP** | `session:switched` | Session selector uses this |
| **KEEP** | `auth:state-change` | Nav bar + API key affordance use this |
| **PRUNE** | `order:filled` | Only onboarding analyzer step consumes (CUT) |
| **PRUNE** | `onboarding:step-completed` | Only onboarding telemetry consumes (CUT) |
| **PRUNE** | `profile:saved` | Only onboarding profile step consumes (CUT) |
| **PRUNE** | `strategy:saved` | Only onboarding strategy step consumes (CUT) |

---

## Dashboard Files: Detailed Classification

### KEEP: Core Read-Only Pages

#### HTML Pages
- **landing.html** (331 lines) — Marketing page with product demo, features, curl/MCP setup snippets. Zero write paths. Status: **KEEP**
- **auth.html** (544 lines) — Login, signup, password reset flows. Required for all access. Status: **KEEP**
- **leaderboard.html** (122 lines) — Read-only agent rankings display. Status: **KEEP**
- **verify.html** (145 lines) — Email verification landing (auth flow). Status: **KEEP**

#### Core Dashboard JS
- **api-utils.js** (630 lines) — API_BASE, apiFetch(), apiPost(), getAuthHeaders(), trustedHTML(). Used by all pages. Status: **KEEP**
- **auth.js** (1769 lines) — Google Sign-In, session management, API key storage, auth state. Status: **KEEP**
- **auth-guard.js** (91 lines) — Redirects unauthenticated users to landing. Status: **KEEP**
- **shared-nav.js** (527 lines) — Navigation bar, user menu, session selector, connection indicator. Subscribes to `auth:state-change`. Status: **KEEP**
- **mobile-nav.js** (228 lines) — Mobile navigation drawer. Status: **KEEP**
- **empty-states.js** (222 lines) — Empty state UI patterns (no sessions, no results). Status: **KEEP**
- **security-telemetry.js** (131 lines) — Client error reporting to backend. Used by all pages. Status: **KEEP**
- **feedback.js** (189 lines) — Sentry integration + fallback mailto feedback widget. Used by all pages. Status: **KEEP**
- **event-bus.js** (131 lines) — Pub/sub system for dashboard communication. Publishers: app.js, settings.js, onboarding.js, auth.js. Subscribers: shared-nav.js, app.js. Status: **KEEP**
- **leaderboard.js** (385 lines) — Read-only leaderboard table with agent rankings. Status: **KEEP**

#### CSS (Read-Only)
- **styles.css** (3835 lines) — Global styles for all pages. Status: **INFRA**
- **auth.css** (1152 lines) — Auth page styling. Status: **INFRA**
- **landing.css** (795 lines) — Landing page styling. Status: **INFRA**

#### Assets
- **favicon.svg** (4 lines) — Icon. Status: **INFRA**
- **llms.txt** (57 lines) — LLM context file. Status: **INFRA**

#### Vendor
- **vendor/lightweight-charts.standalone.production.js** (28378 lines) — TradingView charting library. Status: **INFRA**

---

### CUT: Write-Path Surfaces (Move to `legacy/dashboard-ui/`)

#### Order Entry
- **trade-ticket.js** (569 lines) — Slide-out panel for order entry. Pure write-path. Status: **CUT**

#### Onboarding
- **onboarding.js** (1215 lines) — 3-step wizard: persona, session creation, strategy. Status: **CUT**
- **onboarding.css** (554 lines) — Onboarding wizard styling. Status: **CUT**

#### Settings (Write Tabs)
- **settings.html** (654 lines) — Settings page with profile, security, plugins, billing tabs. Status: **CUT**
- **settings.js** (1915 lines) — Settings tab logic. Status: **TRIM** (see below)
- **settings.css** (1225 lines) — Settings page styling. Status: **CUT**

#### Billing & Subscription
- **billing.html** (459 lines) — Billing page with subscription management. Status: **CUT**
- **billing.js** (790 lines) — Plan selection, payment methods, invoice history. Status: **CUT**
- **billing.css** (1083 lines) — Billing page styling. Status: **CUT**
- **pricing.html** (229 lines) — Pricing/subscription page. Status: **CUT**

#### Marketplace
- **marketplace.html** (139 lines) — Strategy marketplace search/browse/purchase. Status: **CUT**
- **marketplace.js** (519 lines) — Strategy search, purchase, rating logic. Status: **CUT**
- **marketplace.css** (613 lines) — Marketplace styling. Status: **CUT**

#### Modal & Form Infrastructure (CUT-only)
- **dialog-state-mirror.js** (233 lines) — State sync for dialogs. Used only by CUT surfaces. Status: **CUT**
- **form-dirty-tracker.js** (366 lines) — Dirty state tracking for forms. Used only by settings.js. Status: **CUT**

---

### TRIM: Mixed KEEP/CUT Logic (Refactor Required)

#### app.js (2970 lines)
- **KEEP sections**: SSE subscription, portfolio metric updates, equity curve rendering, session selection, clock controls
- **CUT sections**: trade ticket event handlers, onboarding checklist handlers
- **Action**: Carve out CUT sections; move to legacy. Keep equity curve, metrics, SSE, session switching.
- **Status**: **TRIM** — 70% KEEP / 30% CUT

#### index.html (598 lines)
- **KEEP sections**: Nav, session selector, equity chart, portfolio metrics, positions table, order log, plugin health
- **CUT sections**: Trade ticket slide-out, session details panel, onboarding checklist, modals
- **Action**: Remove CUT HTML blocks. Move to legacy/dashboard-ui/index.html.
- **Status**: **TRIM** — 65% KEEP / 35% CUT

#### settings.js (1915 lines)
- **KEEP sections**: API key listing (display only), API key revoke button
- **CUT sections**: Profile form, password change, plugin config, notification preferences, appearance
- **Action**: Extract API key listing to dashboard/api-keys.js. Move main settings.js to legacy.
- **Status**: **TRIM** — 8% KEEP / 92% CUT

#### leaderboard-submit.js (497 lines)
- **KEEP sections**: Leaderboard table rendering with rankings
- **CUT sections**: "Submit to Leaderboard" modal, form submission
- **Action**: Keep leaderboard.js table. Move submit modal to legacy/dashboard-ui/.
- **Status**: **TRIM** — 77% KEEP / 23% CUT

#### modal-controller.js (267 lines)
- **Infrastructure**: Centralized modal stacking, z-index management
- **KEEP usage**: Could be used by future read-only modals
- **CUT usage**: create-session, create-api-key, edit-session, marketplace modals
- **Action**: Keep as infrastructure. Remove references from CUT modals.
- **Status**: **TRIM** — INFRA with 100% CUT callers at launch

---

### INFRA: Educational Pages & Global Assets

#### Educational Pages (Read-Only)
- **setup.html** (433 lines) — Setup guide: what is Finlet, registration, API key, CLI install. Status: **KEEP**
- **agent-guide.html** (484 lines) — Agent connection guide: REST API, MCP, authentication. Status: **KEEP**
- **setup.css** (569 lines) — Setup guide styling. Status: **KEEP**
- **agent-guide.css** (368 lines) — Agent guide styling. Status: **KEEP**

---

## Supporting Surfaces

### e2e Tests (26 files)

#### KEEP: Read-Only Journeys (9 files)
1. journey-01-landing.spec.ts
2. journey-02-signup.spec.ts
3. journey-03-login.spec.ts
4. journey-04-dashboard.spec.ts
5. journey-07-leaderboard.spec.ts
6. journey-10-authguard.spec.ts
7. journey-14-cli-session.spec.ts
8. journey-15-cli-plugins.spec.ts
9. journey-shared-nav.spec.ts

#### CUT: Write-Path Journeys (9 files → move to `legacy/tests/e2e/`)
1. journey-05-trade.spec.ts
2. journey-06a-settings-profile.spec.ts
3. journey-06b-settings-plugins.spec.ts
4. journey-06c-settings-billing.spec.ts
5. journey-06d-settings-danger-zone.spec.ts
6. journey-08-billing.spec.ts
7. journey-12-forgot-password.spec.ts
8. journey-onboarding.spec.ts
9. journey-modal-stacking.spec.ts

#### INFRA: Cross-Cutting (8 files)
1. journey-09-mobile.spec.ts — Responsive UI (refactor to test KEEP surfaces only)
2. journey-11-keyboard.spec.ts — Keyboard a11y (refactor to test KEEP surfaces only)
3. journey-13-cli-serve.spec.ts — CLI server startup
4. journey-16-benchmark-blindness.spec.ts — Blind agent testing methodology
5. journey-17-csrf-hydration.spec.ts — CSRF token setup
6. journey-sim-time-tile.spec.ts — Clock controls
7. journey-trusted-types.spec.ts — TrustedTypes policy enforcement

---

## Event Contract Pruning

**File**: `/dashboard/event-contract.md`

### Events to PRUNE
- `order:filled` — Only onboarding analyzer step consumes (CUT)
- `onboarding:step-completed` — Only onboarding telemetry consumes (CUT)
- `profile:saved` — Only onboarding profile step consumes (CUT)
- `strategy:saved` — Only onboarding strategy step consumes (CUT)

### Events to RETAIN
- `portfolio:updated` → equity curve + dashboard metrics
- `session:switched` → app.js chart/metrics refresh
- `auth:state-change` → shared-nav.js user menu + API key affordance

---

## API Routes

### KEEP Routes (Read-Only, Called by Dashboard)
- `GET /api/sessions` — List sessions
- `GET /api/sessions/<id>/state` — Portfolio state, positions, cash, P&L
- `GET /api/sessions/<id>/equity` — Historical equity curve
- `GET /api/sessions/<id>/orders` — Order log (read-only)
- `GET /api/sessions/<id>/plugins` — Plugin health status
- `GET /api/leaderboard` — Agent rankings
- `GET /api/me` — Current user profile
- `GET /api/me/api-keys` — List API keys
- `DELETE /api/me/api-keys/<id>` — Revoke API key (UI: revoke button only)
- `GET /api/sessions/<id>/subscribe` — SSE stream for real-time updates

### CUT Routes (Write-Path, Not Called by Read-Only Dashboard)
- `POST /api/sessions/<id>/orders` — Submit trade order
- `PATCH /api/sessions/<id>/settings` — Update session name
- `POST /api/me/profile` — Update user profile
- `POST /api/me/password` — Change password
- `POST /api/me/plugins/<id>/install` — Install plugin
- `PATCH /api/me/plugins/<id>/config` — Configure plugin
- `POST /api/subscriptions/plans/<id>` — Change subscription plan
- `POST /api/me/account/delete` — Delete account

---

## Refactor Checklist

### Phase 1: Move CUT Code
- [ ] Move all 15 CUT files to legacy/dashboard-ui/
- [ ] Move 9 CUT test files to legacy/tests/e2e/
- [ ] Preserve git history with git-mv

### Phase 2: TRIM Files
- [ ] Split app.js: extract CUT event handlers
- [ ] Split index.html: remove CUT panels
- [ ] Extract settings.js API key display to dashboard/api-keys.js
- [ ] Move main settings.js to legacy
- [ ] Refactor leaderboard-submit.js: keep table logic

### Phase 3: Update Imports & CI
- [ ] Remove CUT script includes from HTML
- [ ] Prune event-contract.md (7→3 events)
- [ ] Update CI: exclude legacy/ from tests
- [ ] Create legacy/README.md with edit prohibition
- [ ] Update .gitattributes: mark legacy/** as linguist-vendored

### Phase 4: Validation
- [ ] Dashboard renders without errors
- [ ] SSE connects and updates portfolio
- [ ] Session selector works
- [ ] Leaderboard displays rankings
- [ ] API key revoke button works
- [ ] Auth flow works (login, logout)
- [ ] Plugin health widget displays status
- [ ] CI passes with KEEP + INFRA tests only
- [ ] Blind agent walkthrough uses CLI/MCP, not UI

---

**Total Files**: 44 dashboard + 26 tests + event contract + 11 API routes.  
**Effort**: ~2 days for move, TRIM, and CI updates.  
**Reversibility**: Full. Tag `pre-ui-cut-2026-05-06` before cut.
