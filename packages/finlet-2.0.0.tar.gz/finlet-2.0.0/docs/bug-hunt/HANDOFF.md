# Bug-Hunt Loop — Handoff

> **For the next agent picking up the loop.** Read top to bottom; everything below is load-bearing for your first action.
> Last updated: 2026-05-06 by the agent that shipped Phase 3.5 + PF-19 (commit `d4e847c`).

## TL;DR — What to do next

**DO NOT run `/bug-hunt`.** The patch-ineffective gate fired at the end of iteration `20260506T185234Z542e`. Per the Refactor Gate rules in `.claude/skills/bug-hunt/SKILL.md`, the loop is paused until a refactor lands.

Your first action is to draft a refactor scope doc for the **`aria-label-mismatch`** category, then run `/plan-features --doc <that file>` → `/exec-plan`. After that lands, decide whether to ship a follow-on for `onboarding-checklist` v4 or run `/bug-hunt` again.

## State at handoff

- **Branch:** `main` at `d4e847c` (origin and local in sync).
- **Last bug-hunt iteration:** `20260506T185234Z542e`. Retest result: 1 pass / 2 fails. Artifacts in `docs/bug-hunt/20260506T185234Z542e/`.
- **Skill changes shipped this session (PR #23):**
  - `.claude/skills/bug-hunt/SKILL.md` — new **Phase 3.5** between Phase 3 (triage) and Phase 4 (plan): runs `codex exec` (gpt-5.5, xhigh reasoning) for an independent grep-first surgery-surface recon. Skipped when `triage.broken == 0`. Writes `docs/bug-hunt/$TS/codex_recon.md`. Non-blocking on failure.
  - `.claude/skills/plan-features/skill.md` — new **PF-19** reconciliation rule in Step 2: when `codex_recon.md` is present alongside the input doc, the planner unions surgery surfaces from both reports. Root-cause disagreement → `needs-investigation`; scope disagreement → union (not demotion).
  - These are wired to the next `/bug-hunt` invocation. **They will fire automatically next iteration** — no further setup needed.
- **Codex CLI gotcha (memorized in `reference_codex_cli_stdin.md`):** `codex exec` blocks on stdin even when the prompt is passed as an argument. The skill pipes `< /dev/null` to fix this. If you're invoking `codex exec` outside the skill, do the same.

## Gate state — why /bug-hunt is paused

`docs/bug-hunt/pending_recurrences.jsonl` has **2 unresolved entries** from iteration `20260506T185234Z542e`. Each represents a fix that landed locally but didn't change user-visible behavior on prod (Phase 5.5 retest fail). Per the gate, **one signal is enough — do not wait for the count to grow**.

### Unresolved entry 1: `shared-nav-collapsed-label-stale`
- **Category:** `aria-label-mismatch`
- **No matching `refactor-queue/*.md`** with `status: shipped` AND `verdict: effective`. **This is the priority refactor target.**
- **Why the patch failed:** Team B's fix relabeled `#menu-copy-key` in `dashboard/shared-nav.js` for the cookie-session path. But the parallel surface `#nav-drawer-copy-key` lives in static markup across **4 HTML files** plus a click handler in `mobile-nav.js`, none of which Team B touched. The retest confirmed: collapsed-state accessible name is still "Copy API Key" on cookie-session auth — the same lying affordance, different DOM.
- **Surfaces hardcoding the copy** (verified via `grep -rln "Copy API Key\|nav-drawer-copy-key\|menu-copy-key" dashboard/ tests/`):
  - `dashboard/index.html` — static `#nav-drawer-copy-key` button
  - `dashboard/billing.html` — same
  - `dashboard/leaderboard.html` — same
  - `dashboard/settings.html` — same
  - `dashboard/shared-nav.js` — `#menu-copy-key` button + relabel logic gated on `if (isOpen)`
  - `dashboard/mobile-nav.js` — `#nav-drawer-copy-key` click handler
  - `tests/dashboard/shared-nav.spec.js`, `tests/e2e/journey-shared-nav.spec.ts`, `tests/e2e/journey-09-mobile.spec.ts` — assertions
- **Refactor scope direction (the planner needs to verify against HEAD before authoring):**
  - Single source-of-truth for the API-key affordance label. Likely shape: a small render helper in `dashboard/shared-nav.js` (or a new `dashboard/api-key-affordance.js`) that takes a button id + auth state and renders the correct label + click behavior. Both `#menu-copy-key` and `#nav-drawer-copy-key` consume it on initial render AND on `auth:state-change` bus events.
  - Static HTML in the 4 pages either becomes a placeholder the helper hydrates on mount, OR the helper is invoked from a single shared init that the pages already call (e.g., `mountSharedNav()`).
  - The `if (isOpen)` gate in `shared-nav.js:278-294` (the original bug site) goes away — relabel runs on initial render and on auth-state-change, not on menu-open.
  - Decision record `docs/decisions/copy-api-key-dead-affordance.md` is load-bearing — the dual-label affordance ("Copy API Key" when client has the key in memory; "Manage API Key" otherwise) is intentional. The refactor MUST preserve that semantics; only the unification of surfaces changes.
- **Existing test you can build on:** `tests/e2e/journey-shared-nav.spec.ts` was added by Team B last iteration. Extend it to assert BOTH `#menu-copy-key` and `#nav-drawer-copy-key` show the correct label in collapsed AND expanded state, on cookie-session AND on signup/just-rotated paths.

### Unresolved entry 2: `checklist-analysis-label-mismatch`
- **Category:** `onboarding-checklist`
- **Matching `refactor-queue/onboarding-checklist.md`** has `verdict_v3: incomplete` set 2026-05-06 — so per the gate's "shipped AND verdict: effective" rule, this entry is technically unresolved.
- **Why the patch is debatable:** Team C's fix relabeled the user-visible "Run first analysis" → "Place first trade" — the bug-as-experienced (misleading copy) is fixed. But the retest charter expected DECOUPLING (split the registry key from the trigger) and the trigger is still hardcoded to `order:filled` in `CHECKLIST_STEPS`. Retest evidence note: "the bug-as-experienced is fixed but the retest charter expected decoupling."
- **Lower priority than #1.** Two paths:
  - **Accept the bug-as-experienced bar.** Update `refactor-queue/onboarding-checklist.md` with `verdict_v4: effective_for_user` (or similar) + a note that the retest charter was over-spec'd. Mark `pending_recurrences.jsonl` entry resolved. This unblocks the gate cheaply.
  - **Ship the decoupling refactor.** Smaller scope than #1 — likely just a registry-key / trigger split in `dashboard/onboarding.js`. Pays off if we expect more checklist trigger drift; otherwise it's polish.
- **Recommendation:** make this a follow-up after #1. The user's framing ("bug-as-experienced is fixed") suggests the first path is acceptable.

## Action plan for the next agent

1. **Draft the refactor scope doc** at `docs/bug-hunt/refactor-queue/aria-label-mismatch.md`. Use the existing scope docs in that directory as templates (e.g., `onboarding-checklist.md`, `trade-ticket-state-sync.md`). Required frontmatter: `category`, `status: ready`, `instances`, `iterations`, `latest_instance`, `drafted`. Body must include: root cause, files (the list above), proposed shape, validation plan, break-even estimate.
2. **Run `/plan-features --doc docs/bug-hunt/refactor-queue/aria-label-mismatch.md --output docs/refactor/aria-label-mismatch/plan.md`.** This is `/plan-features` invoked OUTSIDE bug-hunt — no `codex_recon.md` will exist alongside the input doc, so PF-19 reconciliation no-ops (Claude recon is the sole source). That's expected and correct for refactor planning.
3. **Run `/exec-plan docs/refactor/aria-label-mismatch/plan.md`.** Standard exec-plan flow: pre-flight, sequential merges with micro-gates, finalize, doc updates, eval, PR.
4. **After the refactor PR merges to main:**
   - Edit `docs/bug-hunt/refactor-queue/aria-label-mismatch.md` to `status: shipped`, add `shipped: <date>`, `shipped_in: <commit-sha>`. Leave `verdict:` blank — the next bug-hunt iteration's blind walkthrough sets it.
   - Append a resolution line to `docs/bug-hunt/pending_recurrences.jsonl` for the `shared-nav-collapsed-label-stale` finding (or rewrite the file to remove the entry — pick whichever the existing convention is; check current contents).
5. **Decide on entry 2** (`checklist-analysis-label-mismatch`) — accept-bug-as-experienced (update `refactor-queue/onboarding-checklist.md` + drop the pending entry) OR plan a v4 decoupling refactor.
6. **Run `/bug-hunt`** for the next loop tick. Phase 3.5 will fire automatically; check `docs/bug-hunt/<new-TS>/codex_recon.md` for the parallel-recon artifact and verify the planner's "Read these files first" lists union both recons.

## Reference pointers

- **Iteration artifacts:** `docs/bug-hunt/20260506T185234Z542e/` — triage, plan, retest, deploy logs.
- **Skill source of truth:** `.claude/skills/bug-hunt/SKILL.md`, `.claude/skills/plan-features/skill.md`.
- **Refactor queue:** `docs/bug-hunt/refactor-queue/` — existing scope docs as templates.
- **Ledger:** `docs/bug-hunt/ledger.jsonl` — every real-broken finding across all iterations. Use to confirm category counts before invoking the gate.
- **Pending recurrences:** `docs/bug-hunt/pending_recurrences.jsonl` — the gate's primary input.
- **Known failures:** `docs/KNOWN_FAILURES.md` — pre-existing test failures; not iteration regressions.
- **PR-gated CI:** main is branch-protected. Use the PR pattern (`git push origin main:refs/heads/<branch>` → `gh pr create` → `gh pr checks --watch` → `gh pr merge --rebase`). Direct `git push origin main` is rejected.

## Open questions / risks

- **Phase 3.5 hasn't been exercised end-to-end yet.** Smoke test passed (the prompt produced a `codex_recon.md` and surfaced the parallel `#nav-drawer-copy-key` ID). The first real iteration is the validation. Watch the `codex_recon.stdout.log` for stdin-wait hangs (mitigated by `< /dev/null`) and any sandbox violations (mitigated by the post-run `git status` check + auto-revert).
- **Codex API tokens cost money.** Each Phase 3.5 run is ~30-60s of wall time + tokens for gpt-5.5 xhigh. Monitor the spend on the first few iterations. If it's significant, consider gating Phase 3.5 to "broken count >= 2" (a single-finding iteration is unlikely to need parallel recon).
- **The aria-label-mismatch refactor has a non-trivial blast radius** (5 files in `dashboard/`, 3 in `tests/`). Plan-features will likely split it into 2-3 teams. Watch for shared-file conflicts — `dashboard/shared-nav.js` is touched by everything.
