You are Team A: Plugin Test Connection — eliminate status duplication.

Worktree base SHA: f098962318d6e54f791e402952a9670697e78cc2

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns in those files.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message subject must start with "[Team A]:".
- Run the validation commands from your spec before finishing.
- If validation fails, fix the issue and re-commit.

---

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/settings.js:1370-1445` — `_reflectPluginHealthToRow()` and `testPlugin()` — the two functions involved in the corruption.
- `dashboard/settings.js:1060-1115` — initial plugin row render template (where `data-plugin-message` is first populated by `loadPlugins` / `renderPlugins`).
- `.claude/rules/dashboard.md` — vanilla-HTML/JS conventions.

**Recon evidence (verified by recon agent against HEAD `84074be`):**

```javascript dashboard/settings.js:1380-1405
1380  if (statusEl) {
1381      const latencySuffix = latencyMs ? ` (${latencyMs})` : '';
1382      statusEl.textContent = `${status}${latencySuffix} — tested ${testedAt}`;
1383  }
1385  // Update / create the message hint with the freshest detail.
1389  let messageEl = card.querySelector('[data-plugin-message]');
1390  const detail = plugin && (plugin.message || plugin.error) ? (plugin.message || plugin.error) : '';
1391  const headline = (status === 'healthy' || status === 'ok') ? 'OK' : status;
1392  const messageText = detail
1393      ? `${headline} — ${detail} (tested ${testedAt}${latencyMs ? `, ${latencyMs}` : ''})`
1394      : `${headline} (tested ${testedAt}${latencyMs ? `, ${latencyMs}` : ''})`;
1405  messageEl.textContent = messageText;
```

```javascript dashboard/settings.js:1427-1443
1427  async function testPlugin(pluginName) {
1428      showToast(`Testing ${pluginName} connection...`, 'info');
1429      const health = await apiFetch('/plugins/health');
1432      const plugin = health.find(p => p.name === pluginName);
1433      if (plugin) {
1434          const status = (plugin.status || '').toLowerCase();
1443          _reflectPluginHealthToRow(pluginName, plugin);
1444      }
1445  }
```

When `plugin.message` from the server already starts with the headline (e.g. `"OK -- 21 cached files"`), the template at line 1393 produces `"OK — OK -- 21 cached files (tested 6:51:00 PM, 0ms)"` — the literal symptom captured by the blind agent.

**Files touched:**
- Modified: `dashboard/settings.js` — `_reflectPluginHealthToRow()` template construction at lines 1389-1405. Strip leading-headline duplication from `detail` before composing `messageText`. Use a single canonical separator (em dash `—`) consistently; do not change the server response, normalize on render.

**Deliverable:** After Test Connection on a healthy plugin where the server returns `message: "OK -- 21 cached files"`, the rendered status hint reads `"OK — 21 cached files (tested 6:51:00 PM, 0ms)"` — single headline, single em-dash separator, no duplication. Initial render (before Test Connection) and post-test render produce the same shape.

**Implementation guidance:**
- Add a small normalizer: if `detail` matches `/^(OK|ok)\s*[-—]+\s*/i`, strip the leading `OK` and any trailing dashes/spaces before composing `messageText`. Treat both `--` (double-hyphen) and `—` (em-dash) as the duplicated separator.
- Apply the same normalizer to the initial-render path (where `data-plugin-message` is first set) so the BEFORE and AFTER states match.
- Do NOT change the API response shape or any server-side code. The fix is render-side only.

**Validation:**
- `bash scripts/lint-trusted-types.sh` passes.
- `bash scripts/lint-event-bus.sh` passes.
- Manual sanity: simulate `_reflectPluginHealthToRow('fundamentals_s3', { status: 'healthy', message: 'OK -- 21 cached files', latency_ms: 0 })` and confirm rendered text is `"OK — 21 cached files (tested HH:MM:SS, 0ms)"`.
- Re-render with `message: '21 cached files'` (no leading OK) → `"OK — 21 cached files (tested HH:MM:SS, 0ms)"` (normalizer is no-op).
- Re-render with `message: 'connection refused'` for an unhealthy plugin → headline becomes the unhealthy status (not "OK"), detail unchanged.

**Agent instructions:**
- You MUST `git add dashboard/settings.js` and `git commit` before finishing.
- Commit subject: `[Team A]: settings.js — strip duplicated headline from plugin Test Connection message render`.
- Reference iteration `20260505T234713Z0c8a` and finding category `dashboard-state-sync` in the commit body.
- Do NOT touch any file other than `dashboard/settings.js`.
- The normalizer should be a 1–3 line `const normalizedDetail = detail.replace(...)` — do not introduce a new helper file.

When done, report: DONE + commit hash + validation results.
