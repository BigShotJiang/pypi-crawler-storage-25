You are Team C: Freeze button visible label — sync with aria-label.

Worktree base SHA: f098962318d6e54f791e402952a9670697e78cc2

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns in those files.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message subject must start with "[Team C]:".
- Run the validation commands from your spec before finishing.
- If validation fails, fix the issue and re-commit.

---

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/index.html:213` — freeze button markup (initial visible text and aria-label).
- `dashboard/app.js:1925-1950` — clock-mode update handler that toggles aria-label and class but not textContent.
- `.claude/rules/dashboard.md` — vanilla-HTML/JS conventions.

**Recon evidence (verified by recon agent against HEAD `84074be`):**

```html dashboard/index.html:213
213  <button class="btn btn--disabled" id="btn-freeze" type="button" aria-label="Freeze clock (Space)" disabled>Freeze</button>
```

```javascript dashboard/app.js:1928-1944
1928  const freezeBtn = document.getElementById('btn-freeze');
1929  const playBtn = document.getElementById('btn-play');
1930  freezeBtn.classList.toggle('btn--active', mode === 'frozen');
1931  playBtn.classList.toggle('btn--active', mode === 'continuous');
1933  if (mode === 'continuous') {
1934      playBtn.setAttribute('aria-label', 'Pause simulation (Space)');
1935  } else {
1936      playBtn.setAttribute('aria-label', 'Start continuous simulation (Space)');
1937  }
1941  if (mode === 'frozen') {
1942      freezeBtn.setAttribute('aria-label', 'Unfreeze clock (Space)');
1943  } else {
1944      freezeBtn.setAttribute('aria-label', 'Freeze clock (Space)');
1945  }
```

Aria-label flips with clock mode, visible text stays static at `"Freeze"`. The play button has the same potential symmetry concern — check `dashboard/index.html` around `id="btn-play"` and apply the same fix if play's visible text similarly does not flip between Play/Pause.

**Files touched:**
- Modified: `dashboard/app.js` — extend the clock-mode handler at lines 1941-1945 to also update `freezeBtn.textContent` (`"Unfreeze"` when `mode === 'frozen'`, `"Freeze"` otherwise). If the play button has the same defect, apply the symmetric fix at lines 1933-1937 (`"Pause"` / `"Play"` textContent flip).
- Modified: `dashboard/index.html` — no markup change strictly required (the JS now mutates textContent), but if you discover the play button's initial textContent disagrees with its aria-label, fix that markup.

**Deliverable:** When clock mode flips between `continuous` and `frozen`, both `aria-label` AND visible button text update on `#btn-freeze`. After session load with mode = `frozen`, the button reads visibly `"Unfreeze"` and announces `"Unfreeze clock (Space)"`. After Play, the button reads `"Freeze"` and announces `"Freeze clock (Space)"`. Same behavior holds for `#btn-play` if the same defect exists.

**Implementation guidance:**
- Two-line addition to the existing `if (mode === 'frozen') { ... } else { ... }` block. Mutate textContent inside each branch.
- Do NOT use `.innerHTML =` (trusted-types lint will reject). `textContent` only.
- Do NOT introduce a new event-bus subscription if the existing handler is already invoked from the clock-mode change site — extend in place.

**Validation:**
- `bash scripts/lint-trusted-types.sh` passes.
- `bash scripts/lint-event-bus.sh` passes.
- Manual: load dashboard with a session, observe `#btn-freeze` reads `"Unfreeze"` initially (mode=frozen on cold session). Click Play → button reads `"Freeze"`. Click Freeze → button reads `"Unfreeze"`.

**Agent instructions:**
- You MUST `git add dashboard/app.js dashboard/index.html` (only if HTML actually changed) and `git commit` before finishing.
- Commit subject: `[Team C]: app.js — sync btn-freeze visible text with aria-label across clock modes`.
- Reference iteration `20260505T234713Z0c8a` and finding category `aria-label-mismatch` in the commit body.
- Do NOT touch any file other than `dashboard/app.js` and (only if needed) `dashboard/index.html`.

When done, report: DONE + commit hash + validation results.
