You are Team B: Onboarding wizard — persist currentStep across navigation.

Worktree base SHA: f098962318d6e54f791e402952a9670697e78cc2

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns in those files.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message subject must start with "[Team B]:".
- Run the validation commands from your spec before finishing.
- If validation fails, fix the issue and re-commit.

---

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/onboarding.js:80-130` — `state` shape (lines 87-96), `loadState()` (99-122), `saveState()` (124-126).
- `dashboard/onboarding.js:155-165` — `currentStep` module-scope variable initialization.
- `dashboard/onboarding.js:355-395` — `initOnboarding()` — page-load entry that calls `loadState()`.
- `dashboard/onboarding.js` — find `WIZARD_STEPS` registry and the function(s) that mutate `currentStep` (likely `nextStep` / `advanceStep` / similar). Persist on those mutations.
- `CLAUDE.md` (project) — note the onboarding registry contract: a single state object, no parallel persistence maps.

**Recon evidence (verified by recon agent against HEAD `84074be`):**

```javascript dashboard/onboarding.js:87-96
87   let state = {
88       completed: [],
89       persona: null,
90       steps: {},
91       wizardDismissed: false,
92       checklistDismissed: false,
93   };
```

```javascript dashboard/onboarding.js:99-126
99   function loadState() {
100      try {
101          const stored = localStorage.getItem('finlet_onboarding');
102          if (stored) {
103              const parsed = JSON.parse(stored);
104              state = { ...state, ...parsed };
105          }
106      } catch (e) {
107          console.error('Failed to load onboarding state:', e);
108      }
109  }
```

```javascript dashboard/onboarding.js:158
158  let currentStep = 1;
```

```javascript dashboard/onboarding.js:359-365
359  function initOnboarding() {
360      const isFirstLogin = !localStorage.getItem('finlet_onboarding');
361      loadState();
```

`state.persona` and `state.steps` are persisted to `localStorage['finlet_onboarding']` and restored on `loadState()`, but `currentStep` resets to 1 on every page load.

**Files touched:**
- Modified: `dashboard/onboarding.js` — extend `state` shape to include `wizardCurrentStep` (or similar canonical key). Persist on every step mutation. Restore in `initOnboarding()` after `loadState()`. Replace the module-scope `let currentStep = 1` initial with a derived value that reads from `state` (e.g., set `currentStep = state.wizardCurrentStep || 1` AFTER `loadState()`).

**Deliverable:** After selecting "Retail Investor" persona and clicking Continue (Step 1 → Step 2), navigating to settings.html and back to index.html restores the wizard to Step 2 with persona pre-selected. localStorage `finlet_onboarding` contains `wizardCurrentStep: 2`. Hard-refresh on index.html with no prior wizard state still defaults to Step 1.

**Implementation guidance:**
- Add `wizardCurrentStep: 1` to the `state` default object. Defaults inside `state` are part of the registry contract — do NOT add a sibling top-level let.
- Anywhere `currentStep` is mutated (advance, back, jump), also set `state.wizardCurrentStep = currentStep` and call `saveState()`. If multiple mutation sites, a tiny `setCurrentStep(n)` helper is acceptable.
- After `loadState()` in `initOnboarding()`, set `currentStep = state.wizardCurrentStep || 1`.
- If `state.completed` already includes a "wizard_done" / "complete" flag, prefer that over a numeric step when `currentStep > WIZARD_STEPS.length` — do not drift past the registry.
- Watch for the dismissal case: if `state.wizardDismissed === true`, the wizard is closed and `currentStep` should not re-render. Preserve that behavior.

**Validation:**
- `bash scripts/lint-event-bus.sh` passes.
- `bash scripts/lint-trusted-types.sh` passes.
- Manual smoke: on a fresh `localStorage.clear()`, advance the wizard to Step 2, navigate away, return, observe Step 2 still active.
- Manual smoke: after `localStorage.clear()`, observe wizard starts at Step 1 (no regression on cold-start).

**Agent instructions:**
- You MUST `git add dashboard/onboarding.js` and `git commit` before finishing.
- Commit subject: `[Team B]: onboarding.js — persist wizardCurrentStep across navigation`.
- Reference iteration `20260505T234713Z0c8a` and finding category `onboarding-checklist` in the commit body.
- Do NOT touch any file other than `dashboard/onboarding.js`. The registry-contract rule in CLAUDE.md is non-negotiable — a parallel persistence map is forbidden, extend the single state object.

When done, report: DONE + commit hash + validation results.
