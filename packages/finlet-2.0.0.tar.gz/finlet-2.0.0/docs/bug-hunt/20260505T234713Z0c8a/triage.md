## Broken (will be fixed this iteration)
- Test Connection corrupts fundamentals_s3 status string — concatenates response in front of stored string instead of replacing, mixing em-dash and double-hyphen separators (UI state diverges from canonical status after a successful mutation) [evidence: "Before Test Connection: status text reads 'OK -- 21 cached files'. After clicking Test Connection on fundamentals_s3: status text renders as 'OK — OK -- 21 cached files (tested 6:51:00 PM, 0ms)'. The response payload is being concatenated in front of the stored string rather than replacing it. Also exposes the underlying inconsistency: stored value uses double-hyphen '--' while the test-result prefix uses an em dash '—'."] [scope hint: dashboard/settings.js (renderTestConnectionResult / loadPlugins), dashboard/settings.html plugin status template]
- Onboarding wizard loses state on page navigation — Step 2 progress evaporates after navigating to settings.html and back (documented multi-step flow does nothing across navigation; persistence contract violated) [evidence: "Selected 'Retail Investor', clicked Continue, wizard advanced to Step 2 ('Create a Session'). Navigated to settings.html, then returned to index.html. Wizard reopened at Step 1 with no persona selected and Continue disabled. State was not persisted to localStorage or sessionStorage across the navigation. Reproduces every time you leave the page mid-wizard."] [scope hint: dashboard/onboarding.js (WIZARD_STEPS state persistence), dashboard/index.html]
- Freeze button visible label contradicts aria-label while clock is FROZEN — button text reads "Freeze" but aria-label reads "Unfreeze clock" with the clock already frozen (sighted users see a label that contradicts both the current state and the click action) [evidence: "After session load, Clock mode status = 'FROZEN'. The button text visible to sighted users reads 'Freeze' (implying the clock is NOT frozen and clicking will freeze it). The aria-label reads 'Unfreeze clock (Space)' (correctly describing what the click will do). Sighted users would interpret the button as a no-op or think the clock is not frozen. Accessibility snapshot: button 'Unfreeze clock (Space)' [ref=e357]: Freeze"] [scope hint: dashboard/app.js (clock-freeze button label render path), dashboard/index.html]

## Logged (not actioned)
- Plugin 'not initialized' error messages provide no actionable guidance for finnhub/fred/edgar; toggle is ON despite being non-functional [classification: annoying]
- Plugin health status labels inconsistent between Settings ("unhealthy") and Dashboard Plugin Health ("Status: Unknown") for the same plugins [classification: annoying]
- Degraded plugins on dashboard say "Run ingestion first" with no link or button to trigger ingestion (the affordance exists, just only on Settings) [classification: annoying]
- Win Rate stat shows 'N/A' with sub-label '0 closed · 1 filled' — technically correct but ambiguous after first filled trade [classification: annoying]
- Trade Ticket fields exist in DOM and accept input before panel is visually open; pre-filled values persist but submit fails opaquely [classification: annoying]
- Report-a-Bug mailto uses page-load timestamp not click-time timestamp [classification: annoying]
- Finlet benchmark MCP tool was not available in this evaluation session; trade placed via UI instead [classification: nice-to-have]
- No 'Fundamentals' session template surfaced at session creation despite landing-page billing [classification: nice-to-have]
- No success toast/banner after order fill — only feedback is silent dashboard update [classification: nice-to-have]
- Plugin Health dashboard widget has no direct link to Settings > Plugins for degraded/unknown plugins [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260505T234713Z0c8a — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. `docs/bug-hunt/20260505T234713Z0c8a/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log,
   deploy_status.txt, retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260505T234713Z0c8a","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline (see
   Phase 5.5c). Team D MUST stage the file. If a refactor verdict pruned entries
   this iteration, Team D MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`
   (the audit log of resolved signals).

Team D's commit message must reference iteration 20260505T234713Z0c8a and name which docs were
touched (e.g., "docs: bug-hunt 20260505T234713Z0c8a — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
