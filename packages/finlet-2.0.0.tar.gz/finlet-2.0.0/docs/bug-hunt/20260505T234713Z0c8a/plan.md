# Bug Hunt 20260505T234713Z0c8a — Execution Plan

> Generated from `docs/bug-hunt/20260505T234713Z0c8a/triage.md`. Baseline: HEAD `84074be78d1f3c2327d27aabfdebee50a4bea7db`.

## Constraints
- Three real-broken findings to close: plugin Test Connection status corruption (settings.js), onboarding wizard state loss across navigation (onboarding.js), and freeze-button visible text/aria-label mismatch (app.js + index.html).
- No file conflicts between Teams A, B, C — they run fully in parallel under worktree isolation. Team D depends on the merge SHAs of A/B/C and runs last.
- Dashboard CLAUDE.md rules apply: vanilla HTML/JS/CSS only, event-bus wiring via `window.finletBus.subscribe`, no direct `addEventListener('finlet:...')`. Trusted-types lint applies to any `.innerHTML =` writes (use `trustedHTML(...)`).
- Existing onboarding registry contract (`WIZARD_STEPS` / `CHECKLIST_STEPS`) stays canonical — Team B may NOT add a parallel persistence map; it must extend the single state object.

## File Conflict Table

| File | Touched by Teams |
|------|------------------|
| `dashboard/settings.js` | A |
| `dashboard/onboarding.js` | B |
| `dashboard/app.js` | C |
| `dashboard/index.html` | C |
| `docs/REMAINING_TASKS.md` | D |
| `docs/LESSONS.md` | D |
| `docs/bug-hunt/20260505T234713Z0c8a/*` | D |
| `docs/bug-hunt/ledger.jsonl` | D |

No two non-D teams touch the same file. A, B, C are conflict-free in parallel.

## Dependency Graph

- **Team A** (settings status) — independent, can start immediately.
- **Team B** (wizard persistence) — independent, can start immediately.
- **Team C** (freeze button label) — independent, can start immediately.
- **Team D** (docs + ledger) — blocked by A, B, C all merged (needs their merge SHAs for `ledger.jsonl`).

## Critical Path

`max(Team A, Team B, Team C) → Team D`

Team D is short (mechanical doc updates + 3 ledger lines). Real critical path is whichever of A/B/C takes longest to land.

---

## Teams

### Team A: Plugin Test Connection — eliminate status duplication

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/settings.js:1370-1445` — `_reflectPluginHealthToRow()` and `testPlugin()` — the two functions involved in the corruption.
- `dashboard/settings.js:1060-1115` — initial plugin row render template (where `data-plugin-message` is first populated by `loadPlugins` / `renderPlugins`).
- `.claude/rules/dashboard.md` — vanilla-HTML/JS conventions.

**Recon evidence (verified by recon agent against HEAD `84074be`):**

```javascript dashboard/settings.js:1380-1405
1380  if (statusEl) {
1381      const latencySuffix = latencyMs ? ` (${latencyMs})` : '';
1382      statusEl.textContent = `${status}${latencySuffix} — tested ${testedAt}`;
1383  }
1385  // Update / create the message hint with the freshest detail.
1389  let messageEl = card.querySelector('[data-plugin-message]');
1390  const detail = plugin && (plugin.message || plugin.error) ? (plugin.message || plugin.error) : '';
1391  const headline = (status === 'healthy' || status === 'ok') ? 'OK' : status;
1392  const messageText = detail
1393      ? `${headline} — ${detail} (tested ${testedAt}${latencyMs ? `, ${latencyMs}` : ''})`
1394      : `${headline} (tested ${testedAt}${latencyMs ? `, ${latencyMs}` : ''})`;
1405  messageEl.textContent = messageText;
```

```javascript dashboard/settings.js:1427-1443
1427  async function testPlugin(pluginName) {
1428      showToast(`Testing ${pluginName} connection...`, 'info');
1429      const health = await apiFetch('/plugins/health');
1432      const plugin = health.find(p => p.name === pluginName);
1433      if (plugin) {
1434          const status = (plugin.status || '').toLowerCase();
1443          _reflectPluginHealthToRow(pluginName, plugin);
1444      }
1445  }
```

The bug premise matches HEAD: when `plugin.message` from the server already starts with the headline (e.g. `"OK -- 21 cached files"`), the template at line 1393 produces `"OK — OK -- 21 cached files (tested 6:51:00 PM, 0ms)"` — the literal symptom captured by the blind agent. The duplication is structural: the renderer always prepends `${headline} — `, ignoring whether `detail` already starts with a redundant headline.

**Files touched:**
- Modified: `dashboard/settings.js` — `_reflectPluginHealthToRow()` template construction at lines 1389-1405. Strip leading-headline duplication from `detail` before composing `messageText`. Use a single canonical separator (em dash `—`) consistently; do not change the server response, normalize on render.

**Deliverable:** After Test Connection on a healthy plugin where the server returns `message: "OK -- 21 cached files"`, the rendered status hint reads `"OK — 21 cached files (tested 6:51:00 PM, 0ms)"` — single headline, single em-dash separator, no duplication. Initial render (before Test Connection) and post-test render produce the same shape.

**Implementation guidance:**
- Add a small normalizer: if `detail` matches `/^(OK|ok)\s*[-—]+\s*/i`, strip the leading `OK` and any trailing dashes/spaces before composing `messageText`. Treat both `--` (double-hyphen) and `—` (em-dash) as the duplicated separator.
- Apply the same normalizer to the initial-render path (where `data-plugin-message` is first set) so the BEFORE and AFTER states match.
- Do NOT change the API response shape or any server-side code. The fix is render-side only.

**Validation:**
- [ ] `bash scripts/lint-trusted-types.sh` passes (no new bare `.innerHTML =` writes under dashboard/).
- [ ] `bash scripts/lint-event-bus.sh` passes.
- [ ] `npx playwright test tests/e2e/journey-04-plugin-toggle.spec.ts -x` (if it exists; otherwise `ls tests/e2e | grep -i plugin` to find the right spec) — does not regress.
- [ ] Manual: open dashboard locally (or just inspect the rendered template via static unit if available), simulate `_reflectPluginHealthToRow('fundamentals_s3', { status: 'healthy', message: 'OK -- 21 cached files', latency_ms: 0 })` and confirm rendered text is `"OK — 21 cached files (tested HH:MM:SS, 0ms)"` — no double `OK`, no `--`.
- [ ] Re-render with `message: '21 cached files'` (no leading OK) and confirm output is `"OK — 21 cached files (tested HH:MM:SS, 0ms)"` (the normalizer is a no-op when no duplication is present).
- [ ] Re-render with `message: 'connection refused'` for an unhealthy plugin and confirm headline becomes the unhealthy status (not "OK"), and detail is unchanged.

**Agent instructions:**
- You MUST `git add dashboard/settings.js` and `git commit` before finishing.
- Commit subject: `[Team A]: settings.js — strip duplicated headline from plugin Test Connection message render`.
- Reference iteration `20260505T234713Z0c8a` and finding category `dashboard-state-sync` in the commit body.
- Do NOT touch any file other than `dashboard/settings.js`.
- Follow the existing template-string render style in `_reflectPluginHealthToRow`. The normalizer should be a 1–3 line `const normalizedDetail = detail.replace(...)` — do not introduce a new helper file.

---

### Team B: Onboarding wizard — persist currentStep across navigation

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/onboarding.js:80-130` — `state` shape (lines 87-96), `loadState()` (99-122), `saveState()` (124-126).
- `dashboard/onboarding.js:155-165` — `currentStep` module-scope variable initialization.
- `dashboard/onboarding.js:355-395` — `initOnboarding()` — page-load entry that calls `loadState()`.
- `dashboard/onboarding.js` — find `WIZARD_STEPS` registry and the function(s) that mutate `currentStep` (likely `nextStep` / `advanceStep` / similar). Persist on those mutations.
- `CLAUDE.md` (project) — note the onboarding registry contract: a single state object, no parallel persistence maps.

**Recon evidence (verified by recon agent against HEAD `84074be`):**

```javascript dashboard/onboarding.js:87-96
87   let state = {
88       completed: [],
89       persona: null,
90       steps: {},
91       wizardDismissed: false,
92       checklistDismissed: false,
93   };
```

```javascript dashboard/onboarding.js:99-126
99   function loadState() {
100      try {
101          const stored = localStorage.getItem('finlet_onboarding');
102          if (stored) {
103              const parsed = JSON.parse(stored);
104              state = { ...state, ...parsed };
105          }
106      } catch (e) {
107          console.error('Failed to load onboarding state:', e);
108      }
109  }
124  function saveState() { /* persists state to localStorage */ }
```

```javascript dashboard/onboarding.js:158
158  let currentStep = 1;
```

```javascript dashboard/onboarding.js:359-365
359  function initOnboarding() {
360      const isFirstLogin = !localStorage.getItem('finlet_onboarding');
361      loadState();
```

The bug premise matches HEAD: `state.persona` and `state.steps` are persisted to `localStorage['finlet_onboarding']` and restored on `loadState()`, but the wizard's `currentStep` is a module-scope variable that resets to `1` on every page load. Navigation away and back produces a re-init at line 158 → currentStep = 1 → wizard shows Step 1 even though state.persona may still be populated.

**Files touched:**
- Modified: `dashboard/onboarding.js` — extend `state` shape to include `wizardCurrentStep` (or similar canonical key). Persist on every step mutation. Restore in `initOnboarding()` after `loadState()`. Replace the module-scope `let currentStep = 1` initial with a derived value that reads from `state` (e.g., set `currentStep = state.wizardCurrentStep || 1` AFTER `loadState()`).

**Deliverable:** After selecting "Retail Investor" persona and clicking Continue (Step 1 → Step 2), navigating to settings.html and back to index.html restores the wizard to Step 2 with persona pre-selected. localStorage `finlet_onboarding` contains `wizardCurrentStep: 2`. Hard-refresh on index.html with no prior wizard state still defaults to Step 1.

**Implementation guidance:**
- Add `wizardCurrentStep: 1` to the `state` default object (line 88-95 area). Defaults inside `state` are part of the registry contract — do NOT add a sibling top-level let.
- Anywhere `currentStep` is mutated (advance, back, jump), also set `state.wizardCurrentStep = currentStep` and call `saveState()`. If there is a single mutation site, that's one line; if multiple, a tiny `setCurrentStep(n)` helper at the top is acceptable.
- After `loadState()` in `initOnboarding()`, set `currentStep = state.wizardCurrentStep || 1` (or however the wizard derives the initial render — read the existing init flow first).
- If `state.completed` already includes a "wizard_done" / "complete" flag, prefer that over a numeric step when `currentStep > WIZARD_STEPS.length` — do not drift past the registry.
- Watch for the dismissal case: if `state.wizardDismissed === true`, the wizard is closed and `currentStep` should not re-render. Preserve that behavior.

**Validation:**
- [ ] `bash scripts/lint-event-bus.sh` passes.
- [ ] `bash scripts/lint-trusted-types.sh` passes.
- [ ] If `tests/e2e/journey-01-onboarding.spec.ts` (or similar) exists, it passes against your changes (`npx playwright test <spec> -x`). If no spec exists, that's fine — Phase 5.5 retest covers the live behavior.
- [ ] Manual smoke (or via local Playwright): on a fresh `localStorage.clear()` page, advance the wizard to Step 2, navigate away, return, observe Step 2 still active.
- [ ] Manual smoke: after `localStorage.clear()`, observe wizard starts at Step 1 (no regression on the cold-start path).

**Agent instructions:**
- You MUST `git add dashboard/onboarding.js` and `git commit` before finishing.
- Commit subject: `[Team B]: onboarding.js — persist wizardCurrentStep across navigation`.
- Reference iteration `20260505T234713Z0c8a` and finding category `onboarding-checklist` in the commit body.
- Do NOT touch any file other than `dashboard/onboarding.js`. The registry-contract rule in CLAUDE.md is non-negotiable — a parallel persistence map is forbidden, extend the single state object.

---

### Team C: Freeze button visible label — sync with aria-label

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/index.html:213` — freeze button markup (initial visible text and aria-label).
- `dashboard/app.js:1925-1950` — clock-mode update handler that toggles aria-label and class but not textContent.
- `.claude/rules/dashboard.md` — vanilla-HTML/JS conventions.

**Recon evidence (verified by recon agent against HEAD `84074be`):**

```html dashboard/index.html:213
213  <button class="btn btn--disabled" id="btn-freeze" type="button" aria-label="Freeze clock (Space)" disabled>Freeze</button>
```

```javascript dashboard/app.js:1928-1944
1928  const freezeBtn = document.getElementById('btn-freeze');
1929  const playBtn = document.getElementById('btn-play');
1930  freezeBtn.classList.toggle('btn--active', mode === 'frozen');
1931  playBtn.classList.toggle('btn--active', mode === 'continuous');
1933  if (mode === 'continuous') {
1934      playBtn.setAttribute('aria-label', 'Pause simulation (Space)');
1935  } else {
1936      playBtn.setAttribute('aria-label', 'Start continuous simulation (Space)');
1937  }
1941  if (mode === 'frozen') {
1942      freezeBtn.setAttribute('aria-label', 'Unfreeze clock (Space)');
1943  } else {
1944      freezeBtn.setAttribute('aria-label', 'Freeze clock (Space)');
1945  }
```

A grep across `dashboard/app.js` for `freezeBtn` confirms only `classList.toggle` and `setAttribute('aria-label', …)` mutations — no `textContent`, `innerText`, or `innerHTML` writes. Bug premise matches HEAD: aria-label flips with clock mode, visible text stays static at `"Freeze"`.

The play button has the same potential symmetry concern (its label is "Play" in markup, not visible in this recon snippet — Team C SHOULD also check `dashboard/index.html` around `id="btn-play"` and apply the same fix if the play button's visible text similarly does not flip between Play/Pause). If the play button's visible text already mirrors the aria-label via some other path, leave it alone.

**Files touched:**
- Modified: `dashboard/app.js` — extend the clock-mode handler at lines 1941-1945 to also update `freezeBtn.textContent` (`"Unfreeze"` when `mode === 'frozen'`, `"Freeze"` otherwise). If the play button has the same defect, apply the symmetric fix at lines 1933-1937 (`"Pause"` / `"Play"` textContent flip).
- Modified: `dashboard/index.html` — no markup change strictly required (the JS now mutates textContent), but if the initial markup at line 213 needs to match the initial mode (continuous, button disabled-but-visible-as-Freeze), leave it as `>Freeze<`. If you discover the play button's initial textContent disagrees with its aria-label, fix that markup too.

**Deliverable:** When clock mode flips between `continuous` and `frozen`, both `aria-label` AND visible button text update on `#btn-freeze`. After session load with mode = `frozen`, the button reads visibly `"Unfreeze"` and announces `"Unfreeze clock (Space)"`. After Play, the button reads `"Freeze"` and announces `"Freeze clock (Space)"`. Same behavior holds for `#btn-play` if the same defect exists.

**Implementation guidance:**
- Two-line addition to the existing `if (mode === 'frozen') { ... } else { ... }` block. Mutate textContent inside each branch.
- Do NOT use `.innerHTML =` (trusted-types lint will reject). `textContent` only.
- Do NOT introduce a new event-bus subscription if the existing handler is already invoked from the clock-mode change site — extend in place.

**Validation:**
- [ ] `bash scripts/lint-trusted-types.sh` passes.
- [ ] `bash scripts/lint-event-bus.sh` passes.
- [ ] If `tests/e2e/journey-02-clock.spec.ts` (or similar) exists, it passes (`npx playwright test <spec> -x`).
- [ ] Manual: load dashboard with a session, observe `#btn-freeze` reads `"Unfreeze"` initially (mode=frozen on cold session). Click Play → button reads `"Freeze"`. Click Freeze → button reads `"Unfreeze"`.
- [ ] DOM check via DevTools: `document.getElementById('btn-freeze').textContent` matches `aria-label` semantically across both modes.

**Agent instructions:**
- You MUST `git add dashboard/app.js dashboard/index.html` (only if HTML actually changed) and `git commit` before finishing.
- Commit subject: `[Team C]: app.js — sync btn-freeze visible text with aria-label across clock modes`.
- Reference iteration `20260505T234713Z0c8a` and finding category `aria-label-mismatch` in the commit body.
- Do NOT touch any file other than `dashboard/app.js` and (only if needed) `dashboard/index.html`.

---

### Team D: Docs + ledger

**Blocked by:** Teams A, B, C all merged to `main` (Team D needs their merge SHAs for `ledger.jsonl`).

**Read these files first:**
- `docs/bug-hunt/20260505T234713Z0c8a/triage.md` — the Required Docs Updates block at the bottom is your spec.
- `docs/bug-hunt/ledger.jsonl` (last 10 lines via `tail -10`) — flat-schema reference.
- `docs/LESSONS.md` (last 50 lines) — voice and structure pattern.
- `docs/REMAINING_TASKS.md` (the most recent "Bug Hunt … — Closed" subsection) — pattern for the new closed subsection.
- `docs/bug-hunt/pending_recurrences.jsonl` — should be empty after the previous iteration's pruning. Confirm.
- The merge commits for Teams A, B, C on `main` (run `git log --oneline main -10` after they merge to capture SHAs).

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — add a "Bug Hunt 20260505T234713Z0c8a — Closed" subsection listing the 3 fixes.
- Modified: `docs/LESSONS.md` — append at least one reusable-rule lesson per finding (3 lessons minimum). Examples: (1) "Render templates that always prepend a headline must normalize the detail field for headline-prefix duplication" (Team A), (2) "Page-scoped UI state that survives navigation must live in the persisted state object, not module-scope let bindings" (Team B), (3) "When toggling aria-label on a button, also toggle visible textContent — sighted/non-sighted users should see consistent affordances" (Team C).
- Modified: `docs/ARCHITECTURE.md` — IF any architectural surface changed (plugin status render contract, onboarding state shape, or freeze-button contract). All three are dashboard-internal patches, so most likely add nothing or one line under the dashboard surface section. Skip with explicit note in commit message if untouched.
- Modified: `docs/KNOWN_FAILURES.md` — refresh; remove any entry resolved this iteration.
- Optional: `docs/decisions/` — only if a non-trivial reversible decision was made (unlikely for these 3 fixes).
- Modified: `docs/bug-hunt/ledger.jsonl` — append exactly 3 JSON lines (one per finding), flat schema:
  ```json
  {"iteration_ts":"20260505T234713Z0c8a","finding_id":"plugin-test-connection-status-duplication","category":"dashboard-state-sync","summary":"Test Connection prepends 'OK — ' to message that already starts with 'OK -- ', producing duplicated headline","scope_files":["dashboard/settings.js"],"team":"A","commit":"<Team A merge SHA>"}
  {"iteration_ts":"20260505T234713Z0c8a","finding_id":"wizard-currentstep-not-persisted","category":"onboarding-checklist","summary":"Wizard currentStep resets to 1 on every page load — module-scope let, not persisted to state object","scope_files":["dashboard/onboarding.js"],"team":"B","commit":"<Team B merge SHA>"}
  {"iteration_ts":"20260505T234713Z0c8a","finding_id":"freeze-btn-visible-text-stale","category":"aria-label-mismatch","summary":"Clock-mode handler updates freezeBtn aria-label but not textContent; visible label stuck at 'Freeze' while mode=frozen","scope_files":["dashboard/app.js","dashboard/index.html"],"team":"C","commit":"<Team C merge SHA>"}
  ```
  After your commit, `wc -l docs/bug-hunt/ledger.jsonl` MUST grow by exactly 3.
- Modified: `docs/bug-hunt/20260505T234713Z0c8a/` — `git add` every artifact in this directory (plan.md, triage.md, triage.json, blind_report.json, blind_envelope.json, cleanup.log, deploy_status.txt if present, retest_results.json if present).
- Modified: `docs/bug-hunt/pending_recurrences.jsonl` — stage even if unchanged. (Phase 5.5c may have appended; confirm before staging.)

**Deliverable:** A single docs commit referencing iteration `20260505T234713Z0c8a` that touches all of the above per the Required Docs Updates contract. `git log -1 --stat docs/` shows REMAINING_TASKS, LESSONS, the artifact directory, and ledger.jsonl in the same commit.

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` returned exactly N+3 where N is the pre-commit line count.
- [ ] Every JSON line in `ledger.jsonl` is valid JSON (`jq -c . docs/bug-hunt/ledger.jsonl >/dev/null`).
- [ ] `git status docs/bug-hunt/20260505T234713Z0c8a/` shows zero untracked files.
- [ ] Commit message includes iteration TS and names every doc category touched (per the Required Docs Updates spec at triage.md bottom).

**Agent instructions:**
- You MUST `git add` every doc file you touch (and every artifact under `docs/bug-hunt/20260505T234713Z0c8a/`) and `git commit` before finishing.
- Commit subject: `docs: bug-hunt 20260505T234713Z0c8a — record fixes for plugin-status-duplication, wizard-step-persistence, freeze-btn-label-sync; LESSONS +3; ledger +3`.
- Do NOT touch any file under `dashboard/`, `finlet/`, or `tests/`.
- The ledger SHAs are mandatory — do not write `<Team A merge SHA>` literally. Read the actual SHAs from `git log` after A/B/C merge.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Team A's normalizer over-strips a legitimate "OK ..." status that is NOT a duplicated headline (e.g., a plugin whose real status text genuinely begins with "OK") | Low | Medium | Anchor regex to start-of-string AND require a separator (`/^OK\s*[-—]+\s*/i`). Validate with the cold-state and unhealthy paths in Team A's manual checks. |
| Team B's `state.wizardCurrentStep` collides with an existing `state.steps[<step-id>]` key semantics — checklist rows happen to use numeric keys | Low | Medium | Use a distinct key name (`wizardCurrentStep`, not `step`). Read the `state.steps` shape before naming. |
| Team C breaks the disabled-state visual (button text changes while disabled) | Very Low | Low | Disabled state is purely a `class="btn--disabled"` and `disabled` attribute; textContent change is independent and harmless when disabled. |
| Team D ships ledger lines with wrong merge SHAs (e.g., Team A merge commit SHA vs. team commit SHA) | Medium | Medium | The contract is the merge SHA on `main`. After A/B/C merge, run `git log --oneline -10 main | head` and pick the SHA whose subject matches the team's commit subject. Validate ledger entries by running `git show <sha>` on each. |
| `pending_recurrences.jsonl` is non-empty unexpectedly (a stale signal from a prior iteration that wasn't pruned) | Low | Low | Team D inspects before staging; if non-empty, surface in the commit message instead of silently shipping. |

## Session Plan

### Session 1 (parallel)

**Parallel:** Teams A, B, C — fully independent, no shared files.
**Merge order:** any of A → B → C in any order. Each merges to `main` individually with targeted lint after each merge:
- After A merges: `bash scripts/lint-trusted-types.sh && bash scripts/lint-event-bus.sh`.
- After B merges: same lint.
- After C merges: same lint.
- After all three merge: full Playwright dashboard journey suite (`npx playwright test tests/e2e -x` or whatever the project's full E2E run is).

### Session 2 (sequential after Session 1)

**Sequential:** Team D — single team, runs after all of A/B/C have landed and their merge SHAs are visible in `git log main`.
**Merge order:** D merges → no targeted test gate (docs-only commit). Skip lint.
**Session checkpoint:** none — final state is the docs commit; Phase 5.5 deploy + retest is the next pipeline stage and is owned by the orchestrator, not Team D.
