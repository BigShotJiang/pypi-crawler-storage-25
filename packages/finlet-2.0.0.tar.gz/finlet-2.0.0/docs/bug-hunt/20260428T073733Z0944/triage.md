# Triage — 20260428T073733Z0944

## Broken (will be fixed this iteration)
- Onboarding wizard overlay intercepts pointer events on the Create Session dialog it spawned — wizard's `#onboarding-overlay` (role=dialog) blocks clicks on `#create-session-submit`, blind agent had to "Skip to dashboard" to dismiss the wizard before the form became clickable. [evidence: "Playwright timed out (5 s) clicking #create-session-submit with error: '<div role=\"dialog\" … id=\"onboarding-overlay\"> intercepts pointer events'. Had to click 'Skip to dashboard' to dismiss the wizard before the Create Session form became clickable."] [scope hint: dashboard/onboarding wizard overlay z-index / pointer-events; likely `dashboard/js/onboarding.js` + related CSS] [category: modal-stacking]
- Trade Ticket "Available Cash" stays at pre-trade $100,000 after a successful FILLED order while dashboard Cash metric correctly drops to $99,455.06 — UI state diverges from backend state after a successful mutation. [evidence: "After BUY 1 SPY filled ($544.94 deducted), the dashboard Cash metric correctly updated to $99,455.06, but the Trade Ticket dialog 'Available Cash' label still showed $100,000.00. The dialog remained open post-fill and never polled for the new balance."] [scope hint: dashboard trade ticket dialog post-fill refresh path; should subscribe to portfolio update event on the new event bus] [category: dashboard-state-sync]

## Logged (not actioned)
- Price plugin shows "Degraded / No cached price data files found" yet trades fill at real-looking prices ($544.94 for SPY) — fill price provenance undocumented. [classification: needs-investigation]
- Finlet benchmark MCP tools not available in blind session — ToolSearch returned zero results for finlet/order/trade queries. [classification: working-as-designed]
- "You have unsaved changes" bar appears immediately on Settings page load with zero user interaction, on both Profile and Plugins tabs. [classification: real-broken-already-logged-as-annoying — see notes]
- Post-login "Welcome to Finlet" alert shows CLI-only setup instructions (finlet serve / finlet auth register / finlet session create) with no web-based equivalent path. [classification: annoying]
- Sim Time metric card wraps to three lines while all other overview cards stay single-line — visual inconsistency. [classification: annoying]
- Session Create Date defaults to today (2025-04-28) with no hint that historical dates are the main use-case. [classification: annoying]
- No "Fundamentals" session template — only Conservative ETF, Tech Growth, Custom. [classification: nice-to-have]
- Trade Ticket symbol field has no universe hint / autocomplete from session universe. [classification: nice-to-have]
- No in-browser fundamentals data explorer — 21 cached fundamental files invisible without AI agent or CLI. [classification: nice-to-have]
- Price ingestion should auto-run for the session universe on session creation — current Degraded state alarming for new users. [classification: nice-to-have]

## Notes

### MCP finding investigation
- `which finlet` → `finlet: aliased to cd /Users/justnau/finlet && claude` (it is a SHELL ALIAS, not a binary)
- `finlet mcp --help` → printed `claude mcp` help text (the alias resolved through `claude` because the alias doesn't expand in non-interactive subprocess command lookup; bash/zsh aliases are shell-only and not exported to child processes)
- The blind launcher's MCP config (`{"command":"finlet","args":["mcp"]}`) would have failed to spawn a real Finlet MCP server inside the headless `claude` subprocess because there is no `finlet` executable on PATH. Only `claude mcp` (a CLI subcommand) exists.
- **Classification: working-as-designed from the FINLET PRODUCT perspective.** This is a setup/infra gap on the bug-hunt-skill side — the launcher needs to either (a) install a real `finlet` binary entrypoint, (b) point the MCP config at `python -m finlet.mcp` or equivalent, or (c) drop the Finlet MCP from the blind config and document that only Playwright is available. Logged for the skill maintainer, not as a Finlet bug.

### Recurrence-after-refactor signal
- **HIT: `dashboard-state-sync`.** The dashboard event-bus refactor (commits ac08c5e..798904c) just landed this session and is supposed to STRUCTURALLY prevent state-sync class bugs. The Trade Ticket "Available Cash" stale-balance finding is squarely in that class — the dialog never re-reads the portfolio after a fill. Either the trade-ticket component was missed by the refactor (didn't subscribe to the new event bus) or the event-bus event for portfolio updates isn't being emitted on order-filled. Worth flagging as a refactor-coverage gap, not just another point bug.
- No recurrence on `onboarding-checklist` (the prior recurring tag); the new finding is `modal-stacking` (overlay z-index/pointer-events), which is a different class.

### Dirty-state tracker on Settings page
- The "You have unsaved changes appears on page load" finding was reported by the blind agent as ANNOYING, but by the design-intent-contradiction predicate it qualifies as `real-broken` (UI state contradicts design intent — form claims to be dirty when no field has been touched, matches the existing `dirty-state-tracker` tag). However: it is already a known recurring tag in the ledger and the blind agent only labeled it ANNOYING. Per the spec ("A finding the blind agent worked around can still be real-broken"), I am classifying it as `real-broken` with category `dirty-state-tracker` and adding it to the Broken list.

### Correction to Broken list
Adding the dirty-state finding to Broken (it slipped into "Logged" above for clarity of reasoning — the JSON output below has it correctly classified as real-broken).

- Settings page "You have unsaved changes" sticky footer renders on initial load with zero user interaction, on both Profile and Plugins tabs — form initializes in a dirty state. [evidence: "On both the Profile tab and the Plugins tab, the sticky footer 'You have unsaved changes / Discard / Save Changes' was visible as soon as the page rendered. No form fields had been touched. The form is apparently initialising in a dirty state. Clicking 'Discard' and re-loading the same tab reproduced it each time."] [scope hint: dashboard settings page form-dirty tracker — initial baseline snapshot likely captured AFTER bound values populate, causing first paint to register as a diff] [category: dirty-state-tracker]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260428T073733Z0944 — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. `docs/bug-hunt/20260428T073733Z0944/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log).
   No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260428T073733Z0944","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.

Team D's commit message must reference iteration 20260428T073733Z0944 and name which docs were
touched (e.g., "docs: bug-hunt 20260428T073733Z0944 — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
