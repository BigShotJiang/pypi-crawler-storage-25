# Bug-Hunt 20260428T073733Z0944 — Execution Plan

> Generated from `docs/bug-hunt/20260428T073733Z0944/triage.md` (3 real-broken findings) and post-mortem `docs/bug-hunt/POST_MORTEM_2026-04-28.md`. Last updated: 2026-04-28.

## Constraints

- Closed-source repo deployed to `finlet.dev`. No external trackers (GitHub Issues, etc.).
- Iteration timestamp: `20260428T073733Z0944`. Bake into Team D commit message and Team E ledger lines.
- File ownership (`.claude/rules/file-ownership.md`): `dashboard/` → dashboard team, `deploy/` → ops team, `docs/` → docs team.
- Per `.claude/rules/dashboard.md`: vanilla HTML/JS/CSS, no build step. Cross-component wiring goes through `window.finletBus.subscribe/publish` per `dashboard/event-contract.md`. Bare `.innerHTML =` outside `trustedHTML()` is blocked at pre-commit.
- Per `CLAUDE.md`: B2C+B2B production site; Team 1's deploy fix is on the critical path because the `dashboard-state-sync` patch (commit on main, NOT live) cannot be validated until deploys land again.
- Last successful deploy: `00aeed1` at 2026-04-28 03:33 UTC. Every deploy since failed at `deploy/deploy.sh:219`.

## File Conflict Table

| File | Touched by Teams |
|------|------------------|
| `deploy/deploy.sh` | 1 |
| `dashboard/onboarding.js` | 2 |
| `dashboard/onboarding.css` | 2 |
| `dashboard/settings.js` | 3 |
| `dashboard/event-contract.md` | 2 (only if Team 2 mints a new bus event) |
| `docs/REMAINING_TASKS.md` | D |
| `docs/LESSONS.md` | D |
| `docs/ARCHITECTURE.md` | D |
| `docs/KNOWN_FAILURES.md` | D |
| `docs/decisions/*.md` | D (only if a non-trivial decision was made) |
| `docs/bug-hunt/20260428T073733Z0944/*` | D (artifact stage) |
| `docs/bug-hunt/ledger.jsonl` | E |

**Conflict verification:** Teams 1, 2, 3 share zero source files. Teams D and E touch only docs/ledger paths that no source-fixing team writes. `dashboard/event-contract.md` is a Team 2 contingent file — only modified if Team 2 mints a new event (Option C in the recon notes). If Team 2 picks Option B (the simplest fix, recommended), the contract doc is untouched.

## Dependency Graph

- **Team 1 (Deploy unblock)** — independent. Can start immediately.
- **Team 2 (Modal-stacking)** — independent of Team 1 source-wise but BLOCKED by Team 1 for live validation. Code-merge-only validation (load wizard locally, click "Open Session Creator") works without a deploy.
- **Team 3 (Dirty-tracker race)** — independent of Team 1 source-wise but BLOCKED by Team 1 for live validation.
- **Team D (Docs)** — blocked by Teams 1, 2, 3 (needs merge SHAs and final code state).
- **Team E (Ledger)** — blocked by Teams 1, 2, 3 (reads merge SHAs from `git log`).

## Critical Path

**Team 1 → Team 2 ∥ Team 3 → Team D ∥ Team E**

Team 1 must merge AND a successful deploy must land before any other team's "live" validation passes. Teams 2 and 3 can develop and merge in parallel, but their behavioural validation on `finlet.dev` requires a green deploy. Teams D and E run after Teams 1-3 are all merged.

---

## Teams

### Team 1: Deploy Pipeline Unblock

**Blocked by:** none — can start immediately.

**Read these files first:**
- `deploy/deploy.sh:200-230` — [why: the failing block lives at line 219; need to understand the surrounding `set -e` + `set -o pipefail` envelope before rewriting]
- `deploy/deploy.sh:1-50` — [why: confirm the `set -e -o pipefail` directive is set at the top, since that's why `ls` exit 2 propagates]
- `.github/workflows/deploy.yml` — [why: invocation context — what env vars are exported and how `deploy.sh` is run on the EC2 host]
- `.claude/rules/deploy-ops.md` — [why: deploy-ops conventions, POSIX-compatible shell expectation, rollback testing requirement]
- `docs/bug-hunt/20260428T073733Z0944/triage.md` Item 2 block — [why: ground truth for what's broken and the three candidate fixes]

**Files touched:**
- Modified: `deploy/deploy.sh` — replace the `ls -1 "$PRICE_CACHE_DIR"/*.parquet 2>/dev/null | wc -l | tr -d ' '` pattern with a `find`-based count or a `|| echo 0` tolerance so an empty/missing directory does NOT exit non-zero under `set -e -o pipefail`. Recommended (per recon): `CACHE_COUNT=$(find "$PRICE_CACHE_DIR" -maxdepth 1 -name '*.parquet' 2>/dev/null | wc -l | tr -d ' ' || echo 0)`. Verify behavior under all three states: directory missing, directory empty, directory with N parquet files.

**Deliverable:** A successful production deploy of the current `main` HEAD lands on `finlet.dev`, replacing the legacy `window.addEventListener('finlet:portfolio-update', ...)` snapshot of `dashboard/trade-ticket.js` with the current `window.finletBus.subscribe('portfolio:updated', ...)` code.

**Validation:**
- [ ] `bash -n deploy/deploy.sh` — syntax check passes.
- [ ] Local dry-run with empty fake dir: `mkdir -p /tmp/finlet-test/cache/prices && PRICE_CACHE_DIR=/tmp/finlet-test/cache/prices bash -c 'set -e -o pipefail; CACHE_COUNT=$(find "$PRICE_CACHE_DIR" -maxdepth 1 -name "*.parquet" 2>/dev/null | wc -l | tr -d " " || echo 0); echo "count=$CACHE_COUNT"' && echo PASS` returns `count=0` and `PASS`.
- [ ] Local dry-run with missing dir: `rm -rf /tmp/finlet-test-missing && PRICE_CACHE_DIR=/tmp/finlet-test-missing bash -c 'set -e -o pipefail; if [ -d "$PRICE_CACHE_DIR" ]; then ...' — confirm the existence guard short-circuits before the count expression runs.
- [ ] After merge to `main`, the deploy workflow auto-triggers. Confirm with `gh run list --workflow=deploy.yml --limit 3` that the latest run completes with status `success` (not `failure`).
- [ ] After deploy lands: `curl -s https://finlet.dev/trade-ticket.js | grep -c "window.finletBus.subscribe"` returns `>= 1` (proves the new event-bus subscriber is now live).
- [ ] After deploy lands: `curl -s -I https://finlet.dev/trade-ticket.js | grep -i "Last-Modified"` shows a timestamp within the last 30 minutes.

**Agent instructions:**
- File ownership: `deploy/` is owned by the **ops** team — this team should be spawned with the ops department's tool reference (`docs/tools/devops.md` if it exists). Do not edit any `dashboard/`, `finlet/`, or `docs/` file.
- Make the smallest possible diff that fixes the cache-count expression robustly. Do NOT refactor surrounding deploy steps.
- Add a one-line comment above the new expression citing this iteration: `# Bug-hunt 20260428T073733Z0944: tolerate empty/missing cache dir under set -e -o pipefail`.
- You MUST `git add deploy/deploy.sh` + `git commit -m "[Team 1] fix(deploy): tolerate empty price cache dir under set -e -o pipefail (bug-hunt 20260428T073733Z0944)"` before finishing. Use `Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>` trailer.
- Constraint: do NOT skip or weaken `set -e -o pipefail` — those flags are load-bearing for the rest of the script.
- After commit, you MUST manually trigger or wait for the deploy workflow and verify the success outcome before declaring done. Validation step 4 is non-negotiable.

---

### Team 2: Modal-Stacking — Wizard Overlay Coordination

**Blocked by:** none for code merge. Live validation on `finlet.dev` requires Team 1 deploy to land.

**Read these files first:**
- `dashboard/onboarding.js:340-400` — [why: the "Open Session Creator" click handler at line 355-378 is the trigger site that fires `window.openCreateSessionModal()` without lowering the wizard overlay]
- `dashboard/onboarding.js:600-700` — [why: locate `dismissWizard()` (~line 642-643) which already toggles `--hidden` (with `pointer-events: none`); the same modifier is the recommended fix vector for the spawned-modal duration]
- `dashboard/onboarding.css:1-30` — [why: confirm `.onboarding-overlay { z-index: 500 }` and the existing `.onboarding-overlay--hidden { pointer-events: none; opacity: 0 }` rule that's already defined and just needs a new toggle site]
- `dashboard/styles.css:3100-3140` — [why: confirm Create Session modal has no explicit z-index — read the modal's CSS class to verify before claiming the stacking gap]
- `dashboard/event-contract.md` — [why: required reading before adding ANY new bus event. If you mint a new event, it MUST be documented here in the same commit]
- `dashboard/app.js` — [why: locate the modal close handler so the wizard overlay can be re-shown on modal-close. Search for `closeCreateSessionModal` or the `session:switched` publish site]
- `docs/bug-hunt/20260428T073733Z0944/triage.md` Item 1 block — [why: ground truth on the bug, three candidate fixes, why Option B is recommended]

**Files touched:**
- Modified: `dashboard/onboarding.js` — in the "Open Session Creator" click handler (line ~355-378), before invoking `window.openCreateSessionModal()`, add the `--hidden` modifier to `#onboarding-overlay`. Restore (remove the modifier) when the spawned modal closes — subscribe via `window.finletBus.subscribe('session:switched', ...)` (already documented in the contract as fired on session creation success) OR use a `transitionend`/explicit-close listener on the Create Session modal close button. The bus subscriber is preferred since it composes with the existing event-bus convention; a fallback `setTimeout` or close-button listener is acceptable if the bus event semantics don't fit. Use a one-shot listener pattern — `const off = bus.subscribe(...); ... off();`.
- Modified: `dashboard/onboarding.css` — only if a new modifier class (e.g. `.onboarding-overlay--passthrough`) is needed. The existing `.onboarding-overlay--hidden` already has `pointer-events: none` and `opacity: 0`, so reusing it works. If reuse is acceptable, this file is NOT modified.
- Modified (contingent): `dashboard/event-contract.md` — only if a NEW bus event is minted (e.g., `wizard:expecting-modal`). Per the contract doc, new events MUST be documented in the same commit. If reusing existing `session:switched`, this file is NOT modified.

**Deliverable:** When the wizard's "Open Session Creator" button fires from Step 2, the wizard overlay no longer intercepts pointer events on the spawned Create Session modal. After the modal closes (via session creation OR cancel), the wizard overlay is restored to interactive state so the user can continue Step 3.

**Validation:**
- [ ] `grep -n "onboarding-overlay--hidden\|finletBus.subscribe" dashboard/onboarding.js` shows the new toggle wiring.
- [ ] Manual local: `python -m http.server 8080` from `dashboard/`, navigate to `index.html` with the onboarding wizard open at Step 2, click "Open Session Creator", confirm Create Session modal is fully clickable (no pointer-event interception).
- [ ] Manual local: after closing/submitting Create Session modal, the wizard overlay restores its overlay state — confirm by interacting with Step 3.
- [ ] Playwright smoke (after Team 1 deploy): `mcp__playwright__browser_navigate` to `https://finlet.dev/`, sign in, open wizard to Step 2, `mcp__playwright__browser_click('#ob-open-create-session')`, then `mcp__playwright__browser_click('#create-session-submit')` — assert NO 5s timeout with `intercepts pointer events` error (the original blind-walk symptom).
- [ ] If a new bus event was added: `dashboard/event-contract.md` includes a new section with publisher/subscriber/payload, AND `grep -n "<new-event-name>" dashboard/` shows ≥1 publisher AND ≥1 subscriber.

**Agent instructions:**
- File ownership: `dashboard/` is owned by the **dashboard** team. Spawn with `dashboard-conventions` skill in mind.
- **Default to Option B (reuse `--hidden` modifier).** Mint a new event only if the modal-close-listener path is materially cleaner. The contract doc is mandatory in the same commit if you do.
- Do NOT touch `dashboard/app.js`, `dashboard/trade-ticket.js`, or any non-onboarding file. The Create Session modal close path is OWNED by app.js — only READ it; don't modify it.
- Do NOT introduce a `setTimeout`-based hack as the primary fix. A timeout is acceptable ONLY as a defensive secondary layer (e.g., 30s backstop in case the modal close event never fires).
- You MUST `git add` the modified files + `git commit -m "[Team 2] fix(dashboard/onboarding): lower wizard overlay during spawned Create Session modal (bug-hunt 20260428T073733Z0944, modal-stacking)"` before finishing. Use `Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>` trailer.
- Use the worktree `agent-ace7ec0d5e6d2f40e` if running in isolation; otherwise the main tree is fine since no other team writes these files.
- Pre-commit hook check: `scripts/lint-trusted-types.sh` will run if installed; do not introduce bare `.innerHTML =` writes.

---

### Team 3: Dirty-Tracker Loader Race Investigation + Fix

**Blocked by:** none for code merge. Live validation on `finlet.dev` requires Team 1 deploy to land.

**Read these files first:**
- `dashboard/settings.js:1-50` — [why: locate `_loaderUpdating` declaration and module-init order. The recon found `_loaderUpdating = true` at line 20]
- `dashboard/settings.js:100-170` — [why: `initFormTracking()` and the rAF tick that clears `_loaderUpdating` at line 153-165. This is yesterday's fix from commit 1f9c126 — understand exactly what it does before extending it]
- `dashboard/settings.js:240-300` — [why: `loadProfile()` at line 252 — confirm the loader is async, awaited via `_profileLoaded`, and writes to inputs at line 261-264. This is the prime suspect for the loader race]
- `dashboard/settings.js:960-1100` — [why: `loadPlugins()` at line 971 — second async loader. Writes to plugin config DOM via innerHTML+trustedHTML. Verify if it touches form fields tracked by `originalValues`]
- `dashboard/settings.js:1100-1230` — [why: line 1115 and 1214-1217 also write to `originalValues` — surface every loader site]
- `dashboard/api-utils.js` — [why: `apiFetch` is the loader transport. Confirm it returns a promise and does NOT have side-effects that touch `<input>` values outside the loader closures]
- `dashboard/event-contract.md` — [why: required reading before adding ANY new bus event. If you mint a `settings:loader-completed` event, document it]
- `docs/bug-hunt/20260428T073733Z0944/triage.md` Item 3 block — [why: ground truth on what's still broken despite yesterday's rAF fix]
- Commit `1f9c126` — [why: `git show 1f9c126` to see exactly what shipped yesterday and why the rAF approach is incomplete]

**Files touched:**
- Modified: `dashboard/settings.js` — replace the single rAF-based snapshot with a per-loader snapshot pattern. Each loader (`loadProfile`, `loadPlugins`, and any other site found in step "Read these files first") MUST re-snapshot `originalValues` and clear `dirtyFields` for the fields it just populated AFTER its `await apiFetch(...)` resolves. The module-level `_loaderUpdating` guard can stay as a belt-and-suspenders safety, but the authoritative baseline must be set by each loader at its own completion. Suggested structure: a helper `function snapshotLoaderFields(fieldIds) { fieldIds.forEach(id => { const el = document.getElementById(id); if (el) originalValues[id] = el.type === 'checkbox' ? el.checked : el.value; dirtyFields.delete(id); }); updateUnsavedBanner(); }`. Call it at the end of each loader.

**Deliverable:** "You have unsaved changes" sticky footer does NOT render on initial page load on either the Profile or Plugins tab. The banner appears only after a real user-initiated edit to a tracked input.

**Validation:**
- [ ] `grep -n "snapshotLoaderFields\|originalValues\[" dashboard/settings.js` shows the helper is called from each loader, and the rAF block (line 153-165) is either removed or reduced to a defensive belt.
- [ ] Manual local: open `dashboard/settings.html` (Profile tab) — confirm `#unsaved-banner` does NOT have the `unsaved-banner--visible` class on initial load (use DevTools, `document.getElementById('unsaved-banner').classList`).
- [ ] Manual local: open `dashboard/settings.html` (Plugins tab) — same assertion.
- [ ] Manual local: type a character into `#profile-name`, confirm banner DOES appear. Discard, confirm banner clears. Type again, save, confirm banner clears post-save.
- [ ] Playwright smoke (after Team 1 deploy): `mcp__playwright__browser_navigate` to `https://finlet.dev/settings.html`, `mcp__playwright__browser_evaluate('() => document.getElementById("unsaved-banner")?.classList.contains("unsaved-banner--visible")')` returns `false` immediately after page load (within 2s of `domcontentloaded`).
- [ ] Playwright smoke: same for `https://finlet.dev/settings.html#plugins` (Plugins tab).
- [ ] No regression: `mcp__playwright__browser_type` into `#profile-name`, then evaluate same selector returns `true` after the edit.

**Agent instructions:**
- File ownership: `dashboard/` is owned by the **dashboard** team.
- This is the THIRD attempt at this bug class. Yesterday's `requestAnimationFrame` fix shipped on commit `1f9c126` but reproduces. Do NOT repeat the same approach with a longer delay or a `setTimeout` instead of `requestAnimationFrame` — that's the same shape of bug. The fix is to attach the snapshot to LOADER COMPLETION, not to a global timing tick.
- Do NOT touch `dashboard/api-utils.js` unless you discover that `apiFetch` is the actual cause. If you do touch it, surface the discovery in the commit message and update the file conflict table. (The expectation is `api-utils.js` stays untouched.)
- Do NOT introduce a new `Promise.allSettled` over loaders unless that's the natural shape of the fix — a per-loader callback is simpler and more localized.
- If a new bus event would simplify the wiring (e.g., `settings:loader-completed`), document it in `dashboard/event-contract.md` in the same commit. Otherwise, prefer keeping the change scope-minimal.
- You MUST `git add` modified files + `git commit -m "[Team 3] fix(dashboard/settings): snapshot dirty baseline per-loader to eliminate rAF race (bug-hunt 20260428T073733Z0944, dirty-state-tracker)"` before finishing. Use `Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>` trailer.

---

### Team D: Documentation Updates

**Blocked by:** Teams 1, 2, 3 (must read final code state and merge SHAs).

**Read these files first:**
- `docs/bug-hunt/20260428T073733Z0944/triage.md` (full document) — [why: the "Required Docs Updates" block is the canonical task list for this team]
- `docs/REMAINING_TASKS.md` — [why: locate the prior iteration's "Closed" subsection to mirror format]
- `docs/LESSONS.md` — [why: read existing lessons to avoid duplication; new lessons must be reusable rules, not diff recaps]
- `docs/ARCHITECTURE.md` — [why: confirm whether middleware/route/plugin surface changed (Teams 1-3 should not have touched any of those, but verify — if untouched, state so explicitly per the triage.md block)]
- `docs/KNOWN_FAILURES.md` — [why: pre-flight refresh; remove any pre-existing failure resolved this iteration]
- `docs/bug-hunt/POST_MORTEM_2026-04-28.md` — [why: contextualize the dashboard-state-sync recurrence as a deploy-pipeline gap, not a refactor regression. Lesson must capture: "code can be correct on main yet still broken in production — verify deploy pipeline AS PART OF triage when 'fix' commits show no behavior change."]
- `docs/bug-hunt/20260428T031818Z2efa/` directory listing — [why: prior iteration artifact set is the format template for this iteration's stage]
- Final state of all files modified by Teams 1, 2, 3 — [why: docs must accurately describe what shipped]

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — add a "Bug Hunt 20260428T073733Z0944 — Closed" subsection mirroring the prior iteration pattern. List the 3 real-broken findings closed (Item 1 modal-stacking, Item 2 dashboard-state-sync via deploy fix, Item 3 dirty-state-tracker). Close any prior "Bug Hunt" items resolved this iteration.
- Modified: `docs/LESSONS.md` — append at minimum:
  - Lesson 1 (modal-stacking): "When a wizard overlay spawns a modal, the spawn site MUST coordinate z-index/pointer-events with the spawned modal. Stacking by raw z-index numbers is fragile — prefer a `--passthrough` modifier toggled at spawn/close to make the coordination explicit in the code."
  - Lesson 2 (dashboard-state-sync deploy gap): "Code-on-main does not equal code-on-production. When a 'fix' commit shows no behavioural change in production, check `Last-Modified` on the deployed file BEFORE assuming the patch is wrong. The deploy pipeline failure mode (`set -e -o pipefail` + `ls`-on-empty-dir) was invisible to triage until I ran `gh run list --workflow=deploy.yml`."
  - Lesson 3 (dirty-state-tracker race): "Global timing ticks (`requestAnimationFrame`, `setTimeout`) are not a substitute for attaching state-baseline-capture to the actual loader-completion event. If yesterday's fix used a global tick and the bug recurred, do not extend the tick — move the capture to the loader."
- Modified: `docs/ARCHITECTURE.md` — only if Team 2 minted a new bus event OR Team 3 changed the loader-completion convention. Otherwise add a one-liner: `Bug-hunt 20260428T073733Z0944: no architectural surface changed.` (Per the triage.md block: skip-with-explicit-note is acceptable.)
- Modified: `docs/KNOWN_FAILURES.md` — refresh and remove any item resolved this iteration. If nothing changed, state so explicitly.
- Modified (contingent): `docs/decisions/<slug>.md` — add a 1-page decision record ONLY if a non-trivial reversible decision was made this iteration. Candidate: "deploy-script-empty-dir-tolerance" if Team 1's choice of `find` over `ls` warrants a record. Skip otherwise.
- New: `docs/bug-hunt/20260428T073733Z0944/plan.md` (this file) — already exists, just `git add`.
- New (stage): `docs/bug-hunt/20260428T073733Z0944/triage.md`, `triage.json`, `blind_report.json`, `cleanup.log`, `team_*_verify.md`, `blind_diagnostic.log`, `isolation_warning.txt` (if present). Stage every artifact produced this iteration. No artifact left untracked.

**Deliverable:** A single docs commit references iteration `20260428T073733Z0944`, names which docs were touched, and stages every artifact in `docs/bug-hunt/20260428T073733Z0944/`. Stale docs eliminated.

**Validation:**
- [ ] `git status docs/bug-hunt/20260428T073733Z0944/` shows zero untracked files.
- [ ] `grep -c "20260428T073733Z0944" docs/REMAINING_TASKS.md` returns ≥ 1.
- [ ] `grep -c "20260428T073733Z0944" docs/LESSONS.md` returns ≥ 3 (one per lesson section, or one anchor per finding).
- [ ] `git log -1 --format=%B` (after Team D commit) contains the iteration timestamp AND names the docs touched (e.g., "REMAINING +1 closed-section; LESSONS +3; ARCHITECTURE no-change; ledger +3 (Team E next)").
- [ ] Verify the prior iteration `docs/bug-hunt/20260428T031818Z2efa/` directory layout matches what we just staged for this iteration (artifact parity check).

**Agent instructions:**
- File ownership: `docs/` is owned by the **docs** team.
- Do NOT modify any source file. If you discover during writing that the code state contradicts the triage, surface the contradiction; do not silently rewrite.
- Lessons must be reusable rules, not diff recaps. If you find yourself writing "Team 1 changed line 219 of deploy.sh", that's a diff recap — restate as a reusable rule about deploy-pipeline failure modes.
- For the artifact stage: `git add docs/bug-hunt/20260428T073733Z0944/` (the whole directory). Verify with `git status` before committing.
- You MUST `git add` modified docs + staged artifacts and `git commit -m "[Team D] docs: bug-hunt 20260428T073733Z0944 — record fixes for modal-stacking + deploy unblock + dirty-tracker race; LESSONS +3; ARCHITECTURE unchanged this iteration; artifacts staged"` before finishing. Use `Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>` trailer.
- Tune the commit message subject to match what's actually in `docs/ARCHITECTURE.md` after your edit (e.g., "ARCHITECTURE +1 bus event" if Team 2 minted one).

---

### Team E: Ledger Append

**Blocked by:** Teams 1, 2, 3 (reads merge SHAs from `git log` after each merges to `main`).

**Read these files first:**
- `docs/bug-hunt/ledger.jsonl` (full file) — [why: existing schema and category vocabulary. Required reading before minting any new tag]
- `docs/bug-hunt/20260428T073733Z0944/triage.md` "Required Docs Updates" #7 — [why: ground-truth schema for this iteration's lines]
- `docs/bug-hunt/20260428T073733Z0944/triage.json` — [why: structured source for category, summary, scope_files per finding]

**Files touched:**
- Modified: `docs/bug-hunt/ledger.jsonl` — append exactly 3 JSON lines (one per real-broken finding closed this iteration). Schema:
  ```json
  {"iteration_ts":"20260428T073733Z0944","finding_id":"<short-slug>","category":"<tag>","summary":"<short>","scope_files":["dashboard/x.js"],"team":"<1|2|3>","commit":"<merge-sha-on-main>"}
  ```
  - Line 1 (Item 2 — landed via Team 1 deploy fix):
    - `finding_id`: `trade-ticket-stale-cash-deploy-gap` (or similar; reuse `dashboard-state-sync` category since the underlying class is unchanged — the deploy gap is the proximate cause but the recurrence-class tag is the right one for ledger analytics)
    - `category`: `dashboard-state-sync` (existing tag — reuse, do NOT mint new)
    - `scope_files`: `["deploy/deploy.sh"]` (the file actually changed — even though the design intent was to fix `dashboard/trade-ticket.js`, the merge that closed the issue was in `deploy/deploy.sh`)
    - `team`: `1`
    - `commit`: Team 1's merge SHA on main (read with `git log --format='%H' -n 1 deploy/deploy.sh` after merge, or equivalent)
  - Line 2 (Item 1 — modal-stacking):
    - `finding_id`: `wizard-overlay-blocks-spawned-modal`
    - `category`: `modal-stacking` (existing tag — reuse)
    - `scope_files`: include `dashboard/onboarding.js` plus `dashboard/onboarding.css` and/or `dashboard/event-contract.md` if Team 2 modified them
    - `team`: `2`
    - `commit`: Team 2's merge SHA on main
  - Line 3 (Item 3 — dirty-tracker):
    - `finding_id`: `settings-dirty-banner-onload-loader-race`
    - `category`: `dirty-state-tracker` (existing tag — reuse)
    - `scope_files`: `["dashboard/settings.js"]` (plus `dashboard/event-contract.md` if Team 3 minted a `settings:loader-completed` event)
    - `team`: `3`
    - `commit`: Team 3's merge SHA on main

**Deliverable:** `docs/bug-hunt/ledger.jsonl` grows by exactly 3 lines. Each line is valid JSON. Categories reuse existing tags from prior iterations. Recurrence detection (Phase 6) can read these lines without parser changes.

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` increased by exactly 3 since this iteration started.
- [ ] `tail -3 docs/bug-hunt/ledger.jsonl | jq -c .` parses 3 lines without error (valid JSON each).
- [ ] `tail -3 docs/bug-hunt/ledger.jsonl | jq -r .iteration_ts | sort -u` returns exactly `20260428T073733Z0944`.
- [ ] `tail -3 docs/bug-hunt/ledger.jsonl | jq -r .category | sort -u` returns ONLY tags already present in earlier ledger lines (verify with `cat docs/bug-hunt/ledger.jsonl | jq -r .category | sort -u`). No new tag minted.
- [ ] `tail -3 docs/bug-hunt/ledger.jsonl | jq -r .commit` returns 3 non-empty SHA strings, each verifiable with `git cat-file -t <sha>` returning `commit`.

**Agent instructions:**
- File ownership: `docs/` is owned by the **docs** team.
- Read merge SHAs from `git log` AFTER Teams 1-3 have merged. Do NOT use placeholder hashes.
- Do NOT mint new categories. The triage analysis already mapped each finding to an existing tag (`modal-stacking`, `dashboard-state-sync`, `dirty-state-tracker`). All three recur and the recurrence signal is the value of reuse.
- Append-only — do NOT modify earlier lines in the ledger. Use `>>` redirection (carefully — newline at end), not Edit-replace on the whole file.
- You MUST `git add docs/bug-hunt/ledger.jsonl` + `git commit -m "[Team E] ledger: bug-hunt 20260428T073733Z0944 — append 3 closed findings (modal-stacking, dashboard-state-sync, dirty-state-tracker; all recurring tags)"` before finishing. Use `Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>` trailer.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team 1's deploy fix doesn't actually unblock the pipeline (different latent failure surfaces) | Medium | Critical | Validation step 4 requires `gh run list --workflow=deploy.yml` to show success BEFORE declaring done. Teams 2/3 can still merge code, but their live validation gates remain failing — Phase 6 will flag this. |
| Team 2 picks the wrong restoration trigger and the wizard overlay stays hidden after modal close | Medium | High | Validation step 3 (manual local) explicitly tests the post-close re-show path. If `session:switched` doesn't fire on modal-cancel (only on success), use a fallback close-button listener — both paths must be covered. |
| Team 3's loader-completion fix misses a third loader site | Medium | Medium | "Read these files first" includes lines 1100-1230 specifically because there are MORE `originalValues` writes there. Validation step 1 grep-checks every loader site. |
| Team 2 mints a new bus event but forgets to update `dashboard/event-contract.md` | Low | High | Validation step 5 requires the doc update in the SAME commit. Pre-merge review must check both diffs. |
| Team D writes lesson recaps instead of reusable rules | Medium | Medium | Lesson templates given in agent instructions. Validation step 4 requires the iteration timestamp in commit message — review that text before merging. |
| Team E appends ledger lines with wrong merge SHAs (e.g. branch SHA, not main merge) | Low | Medium | Validation step 5 requires `git cat-file -t <sha>` returning `commit` and the SHA must be reachable from `main` HEAD. |
| Team 3's fix attempt repeats yesterday's `requestAnimationFrame` mistake with a longer delay | Medium | High | Agent instruction explicitly forbids same-shape extension. Reviewer must confirm the snapshot now hangs off loader completion, not a global tick. |
| Team 1 and Team 2 simultaneously modify `dashboard/event-contract.md` (Team 1 should NOT, Team 2 may) | Very Low | Low | Team 1 instructed not to touch dashboard/. Team 2 owns event-contract.md if it changes at all. |

---

## Session Plan

### Session 1 — Deploy unblock + parallel dashboard fixes

**Sequential gate:** Team 1 first (deploy unblock is critical-path).
**Merge order:**
1. Team 1 merges → run validation (`bash -n`, local dry-run, post-merge `gh run list` → green) → confirm `https://finlet.dev/trade-ticket.js` serves the bus subscriber.
2. Teams 2 and 3 develop in parallel against `main` post-Team-1.
3. Team 2 merges → run Team 2 validation block (no shared files with Team 3, can merge in either order).
4. Team 3 merges → run Team 3 validation block.

**Session checkpoint:** After Teams 1, 2, 3 are all merged AND `finlet.dev` serves the latest:
- Run the 3 Playwright smokes from Teams 1/2/3 validation against `finlet.dev` end-to-end.
- Confirm zero regressions on the "Run first analysis" checklist advance test (POST_MORTEM_2026-04-28 invariant).

### Session 2 — Bookkeeping (Teams D and E)

**Parallel:** Teams D and E share zero files (D writes docs/*, E writes ledger.jsonl). Both blocked by Session 1 completion.
**Merge order:** D and E merge in any order. Each runs its own validation block.

**Session checkpoint:** After D and E are merged:
- Run `wc -l docs/bug-hunt/ledger.jsonl` and confirm growth of exactly 3.
- Confirm `docs/bug-hunt/20260428T073733Z0944/plan.md` (this file) is committed and tracked.
- Phase 6 recurrence check reads the new ledger lines and reports — that's the next (post-plan) phase, not this team's scope.
