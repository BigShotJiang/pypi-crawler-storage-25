# Bug-Hunt 20260506T154910Z0b41 — Execution Plan

> Generated from `docs/bug-hunt/20260506T154910Z0b41/triage.md` against HEAD `4d620b1f30379540c65bb41e34e5a06a1cd0ebae`. Last updated: 2026-05-06.

## Constraints

- **Scope** is the two `real-broken` findings from this iteration's triage, plus the mandatory docs + ledger commits.
- **One finding demoted by recon.** Finding 2 (plugin cards duplicated) — recon at HEAD found a single `#plugin-config-list` container, a single `loadPlugins()` call registered via `registerLoader()`, and no duplicate render path. The blind agent's `.plugin-card` selector does not match the actual class (`.plugin-config-card`). Per PF-18 reroute rule, this finding is demoted to `needs-investigation` and NOT actioned this iteration. A live DevTools repro is required before spawning a fix team.
- **Refactor-outcome flag.** Both broken finding's categories (`onboarding-checklist`, `dashboard-state-sync`) are in the recurrence-watch list. Phase 6 will set verdicts on the relevant shipped refactor docs against this iteration's triage.

## File Conflict Table

| File | Touched by Teams |
|------|-----------------|
| `dashboard/onboarding.js` | A |
| `docs/REMAINING_TASKS.md` | D |
| `docs/LESSONS.md` | D |
| `docs/ARCHITECTURE.md` | D (skip-with-note) |
| `docs/KNOWN_FAILURES.md` | D (skip-with-note unless pre-existing failure resolved) |
| `docs/bug-hunt/refactor-queue/onboarding-checklist.md` | D (verdict update) |
| `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md` | D (verdict update) |
| `docs/bug-hunt/20260506T154910Z0b41/*` | All (artifact stage) |
| `docs/bug-hunt/ledger.jsonl` | E |
| `docs/bug-hunt/pending_recurrences.jsonl` | D (after Phase 5.5 inline append) |

No two teams touch the same code file. Teams D and E both append to artifact dir but to different files (docs/* vs ledger.jsonl), so they merge sequentially with no conflict.

## Dependency Graph

- **Team A** (onboarding heading fix) — independent; can start immediately.
- **Team D** (docs) — blocked by A (needs to reference A's commit + LESSONS entry); also blocked by Phase 5.5 retest results existing.
- **Team E** (ledger) — blocked by A (needs A's merge SHA on main).

## Critical Path

`Team A → Team E → Team D` (ledger needs A's SHA; docs reference A's commit and ledger entry; docs is also gated by Phase 5.5 artifacts which run between exec-plan completion and the docs commit — so D is the natural tail).

---

## Teams

### Team A: Onboarding wizard step-heading update

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/onboarding.js:583-590` — heading is rendered ONCE in `buildWizardHTML()` with a static `s.title`; never re-rendered on step transition.
- `dashboard/onboarding.js:683-745` — `showStep(step)` is the transition function; updates dots, lines, button text — but no heading update.
- `dashboard/onboarding.js` (full registry block) — `WIZARD_STEPS` array entries each have a `title` field; the registry is the source of truth (see `docs/decisions/onboarding-checklist-step-contract.md`).

**Recon evidence (verified by recon agent against HEAD `4d620b1`):**

```javascript dashboard/onboarding.js:683-745
let showStep = function showStep(step) {
    currentStep = step;
    if (state) {
        state.wizardCurrentStep = currentStep;
        saveState(state);
    }
    const overlay = document.getElementById('onboarding-overlay');
    if (!overlay) return;
    const wizardStep = WIZARD_STEPS[step - 1];
    if (!wizardStep) return;

    // Update step visibility
    overlay.querySelectorAll('.onboarding-step').forEach(el => {
        el.classList.remove('onboarding-step--active');
    });
    const activeStep = document.getElementById(`ob-step-${step}`);
    if (activeStep) activeStep.classList.add('onboarding-step--active');

    // Update progress dots
    for (let i = 1; i <= WIZARD_STEPS.length; i++) {
        const dot = document.getElementById(`ob-dot-${i}`);
        if (!dot) continue;
        dot.classList.remove('onboarding-progress-dot--active', 'onboarding-progress-dot--complete');
        if (i < step) {
            dot.classList.add('onboarding-progress-dot--complete');
            dot.textContent = '✓';
        } else if (i === step) {
            dot.classList.add('onboarding-progress-dot--active');
        }
    }

    // ... progress lines update (similar shape) ...

    // Update Next button text and state from the registry entry.
    const nextBtn = document.getElementById('ob-next');
    if (nextBtn) {
        nextBtn.textContent = wizardStep.nextLabel;
        nextBtn.disabled = (step === 1 && !selectedPersona);
    }

    // Step-specific body population (Step 3 needs the persona for
    // action-card generation).
    if (step === 3) {
        populateStep3FromRegistry();
    }
};
```

`showStep()` toggles `.onboarding-step--active` on each step DIV, repaints dots/lines, and updates the Next button label from `wizardStep.nextLabel`. It does NOT update the h2 element inside the active step. The h2 is rendered once at module init via `buildWizardHTML()` and never re-painted.

The blind agent observed the symptom directly: after clicking Continue on step 1, the visible h2 stayed "What describes you?" while the button label correctly updated to "Open Session Creator". Step 2 → 3 worked because step 3 has a special-cased `populateStep3FromRegistry()` path that re-paints step-3-specific content (including its title node `#ob-step3-title`).

**Files touched:**
- Modified: `dashboard/onboarding.js` — add heading repaint inside `showStep()` so the active step's h2 always reflects the registry's `title` field. Keep step-3's `populateStep3FromRegistry()` branch intact (or fold the title-paint into a single line that runs for ALL steps and have step-3's specialized path stop touching the title).

**Deliverable:** After clicking the Next/Continue button on any wizard step, the visible h2 heading inside the now-active step matches `WIZARD_STEPS[step - 1].title` from the registry. No regression on step 1, 2, or 3.

**Validation:**
- [ ] `uv run pytest tests/ -x -q -k "onboarding or wizard"` passes (note: most onboarding tests are JS-side; backend pytest is sanity only).
- [ ] Manual visual check via the deployed retest in Phase 5.5: log in as test user, dismiss any prior wizard state, walk steps 1 → 2 → 3, confirm each step's h2 text matches the registry entry.
- [ ] Pre-commit hooks pass (`bash scripts/lint-trusted-types.sh`, `bash scripts/lint-event-bus.sh`).
- [ ] Diff is small (<30 lines), localized to `showStep()` + (optional) the step-3 branch cleanup.

**Agent instructions:**
- You MUST `git add dashboard/onboarding.js` + `git commit` before finishing. Worktree agents that don't commit lose all work.
- Worktree-rules: you are in an ISOLATED worktree. Do NOT touch files outside `dashboard/`. Do NOT modify files in the main checkout — only in your assigned worktree path.
- Follow the registry contract from `docs/decisions/onboarding-checklist-step-contract.md`: every wizard step's title MUST come from `WIZARD_STEPS[i].title`, not from a hand-edited h2.
- Minimal-diff: prefer adding 2-3 lines inside `showStep()` over restructuring `buildWizardHTML()`.
- If you find that step-3's title is repainted twice after your fix (once in `showStep()`, once in `populateStep3FromRegistry()`), pick ONE source-of-truth — likely `showStep()` — and remove the redundant assignment from `populateStep3FromRegistry()`.
- Commit message format: `[Team A]: dashboard: paint wizard step heading from registry on every showStep transition (close 20260506T154910Z0b41 onboarding-checklist)`.

---

### Team D: Docs

**Blocked by:** A merged AND Phase 5.5 retest_results.json exists.

**Read these files first:**
- `docs/bug-hunt/20260506T154910Z0b41/triage.md` — has the Required Docs Updates block at the bottom listing every doc to touch this iteration.
- `docs/bug-hunt/20260506T154910Z0b41/blind_report.json` — full finding set.
- `docs/bug-hunt/20260506T154910Z0b41/retest_results.json` (after Phase 5.5) — for the Phase 5.5 outcome.
- `docs/bug-hunt/refactor-queue/onboarding-checklist.md` — append `verdict: incomplete` (refactor was supposed to close onboarding-checklist cluster; this iteration shows another instance, so the refactor was under-scoped).
- `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md` — append `verdict: incomplete` for the same reason (it explicitly listed onboarding-checklist).
- Existing `docs/LESSONS.md` for current voice/format.
- Existing `docs/REMAINING_TASKS.md` for the "Bug Hunt — Closed" subsection format.

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — add "Bug Hunt 20260506T154910Z0b41 — Closed" subsection with the closed onboarding-heading item; add a "Demoted to needs-investigation" line for the plugin-cards-duplicated finding referencing the recon contradiction.
- Modified: `docs/LESSONS.md` — append at least one lesson per real-broken finding fixed AND one for the demoted finding. Suggested:
  - `LESSONS-####`: Step-transition functions that paint dots/buttons must paint the heading too — registry contracts cover the data, but the renderer must read every field on every transition or partial-paint bugs are guaranteed.
  - `LESSONS-####`: Blind-agent symptom selectors do not always match the codebase's actual class names (`.plugin-card` vs `.plugin-config-card`); recon must verify the symptom predicate against HEAD, not just the named scope, and demote when the bug surface is not present where claimed.
- Modified: `docs/ARCHITECTURE.md` — `skip-with-note` (no architectural surface changed: no new endpoint, no new middleware, no schema field, no new plugin contract).
- Modified: `docs/KNOWN_FAILURES.md` — pre-flight refresh; remove any pre-existing failure resolved this iteration (likely none — the heading-paint bug was not previously logged).
- Modified: `docs/bug-hunt/refactor-queue/onboarding-checklist.md` — set `verdict: incomplete` with a one-line reason: "iteration 20260506T154910Z0b41 produced a new onboarding-checklist instance (heading not repainted on step 1→2 transition); refactor was correct but under-scoped — it converged step-content onto the registry but did not converge the renderer onto the registry."
- Modified: `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md` — set `verdict: incomplete` with a similar one-line reason citing the new onboarding-checklist instance.
- New: stage every artifact in `docs/bug-hunt/20260506T154910Z0b41/` (plan.md, triage.md, triage.json, blind_report.json, cleanup.log, isolation_warning.txt, retest_results.json, deploy_status.txt, any team-verify scratch files).
- Modified (only if Phase 5.5 produced new patch-ineffective signals): `docs/bug-hunt/pending_recurrences.jsonl`. The orchestrator appends inline; Team D just stages the file.

**Deliverable:** A single commit with all docs updates and artifacts, message referencing iteration `20260506T154910Z0b41` and naming each doc touched.

**Validation:**
- [ ] `git diff --name-only HEAD~1` lists every file in the touched list above (or has an explicit skip-with-note in commit message for skipped items).
- [ ] No code files modified — only docs/* and refactor-queue/*.
- [ ] Commit message names: REMAINING_TASKS, LESSONS (count of new entries), ARCHITECTURE (touched/skipped), KNOWN_FAILURES (touched/skipped), refactor-queue (verdicts set), ledger reference.

**Agent instructions:**
- You MUST `git add` every file you modify or create + `git commit` before finishing.
- Commit message: `[Team D]: docs: bug-hunt 20260506T154910Z0b41 — record onboarding heading-paint fix; demote plugin-cards finding to needs-investigation; LESSONS +2; ARCHITECTURE unchanged this iteration; refactor-queue: 2 verdicts set (incomplete); ledger +1`.
- The verdict on the two refactor-queue docs should be `incomplete` with a one-line evidence pointer to this iteration's triage. Do NOT delete the refactor docs.
- If Phase 5.5 retest_results.json shows the onboarding fix as `fail` (patch-ineffective), reflect that in the LESSONS entry and in the REMAINING_TASKS subsection (mark it patch-ineffective rather than closed).

---

### Team E: Ledger

**Blocked by:** A merged.

**Read these files first:**
- `docs/bug-hunt/ledger.jsonl` — last 10 lines for schema reference.
- The merge SHA on `main` for Team A's commit (read from `git log --oneline main -5`).

**Files touched:**
- Append-only: `docs/bug-hunt/ledger.jsonl` — exactly ONE line for Team A's fix.

**Deliverable:** One JSONL line appended:

```json
{"iteration_ts":"20260506T154910Z0b41","finding_id":"onboarding-wizard-heading-not-repainted","category":"onboarding-checklist","summary":"Wizard step heading stays on prior step's title because showStep() updates dots/button but not h2","scope_files":["dashboard/onboarding.js"],"team":"A","commit":"<Team A merge SHA>"}
```

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` grew by exactly 1 since Phase 0.
- [ ] `tail -1 docs/bug-hunt/ledger.jsonl | jq .` parses cleanly.
- [ ] `commit` field is the actual merge SHA on main, not a placeholder.

**Agent instructions:**
- You MUST `git add docs/bug-hunt/ledger.jsonl` + `git commit` before finishing.
- Commit message: `[Team E]: ledger: bug-hunt 20260506T154910Z0b41 — onboarding-checklist (Team A)`.
- Demoted Finding 2 (plugin cards duplicated → needs-investigation) is NOT a ledger entry — only `real-broken` items closed this iteration go in the ledger. Team D's REMAINING_TASKS update is where the demotion is recorded.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A's heading fix conflicts with step-3's `populateStep3FromRegistry()` (double-paint) | Low | Low | Read instructions: pick one source of truth, remove the redundant assignment from the step-3 branch if needed. |
| Team A's diff exceeds 30 lines because the agent restructures `buildWizardHTML()` | Low | Med | Instructions explicitly say minimal-diff inside `showStep()`. If the diff balloons, the QA gate flags it and the team is sent back. |
| Phase 5.5 retest fails (heading still stale on prod) — patch-ineffective signal | Med | Med | The orchestrator appends to `pending_recurrences.jsonl` automatically; the next iteration's gate trips and routes to refactor instead of another patch. Team D reflects this in LESSONS. |
| Refactor-queue verdict misclassification (calling something `effective` when it's actually `incomplete`) | Low | Med | The verdict criteria are mechanical (any new instance of the cluster's category in this iteration's triage = `incomplete`). Both onboarding-checklist refactor docs get `incomplete` because this iteration produced an onboarding-checklist instance. |
| Plugin-cards finding is real but recon missed it — demoted unfairly | Low | Low | Demotion is reversible: a future iteration with DevTools-snapshot evidence can re-elevate. The `needs-investigation` line in REMAINING_TASKS keeps it visible. |

## Session Plan

### Session 1
- **Sequential:** Team A (only fix team this iteration).
- **Merge order:** A merges first → targeted test on main (`uv run pytest -x -q tests/dashboard/` if any exists, else lint pass) → push.
- **Session checkpoint:** none — only one fix team. The orchestrator proceeds directly to Phase 5.5 once A is merged + pushed.

### Session 2 (post-Phase-5.5)
- **Sequential:** Team E (ledger) → Team D (docs).
- **Merge order:** E merges first (one-line append, low risk) → tests/lint sanity → D merges with all docs + verdicts + artifacts → tests/lint sanity → push.
- **Session checkpoint:** `bash scripts/preflight-test.sh` (or equivalent), then verify `wc -l docs/bug-hunt/ledger.jsonl` grew by exactly 1 and `git log --oneline -3` shows A, E, D in that order.

---

## Plan Validation (PF-18 self-scan)

Scan results for `(currently|current order|runs .* (BEFORE|AFTER)|increments at|the predicate at line)`:

- Team A's "Recon evidence" subsection: contains a fenced code block with file:line info string, quoting `dashboard/onboarding.js:683-745` directly from HEAD `4d620b1`. The paraphrase below the block ends with `(verified by recon agent against HEAD ...)`. ✅ Verified.
- Team D's "Read these files first" — pointers only, no "current state" claims about behavior. ✅ Out-of-scope for PF-18.
- Team E's spec — append-only, no code-state claims. ✅ Out-of-scope.

No unverified `current state` claims found. Plan is ready for handoff to `/exec-plan`.
