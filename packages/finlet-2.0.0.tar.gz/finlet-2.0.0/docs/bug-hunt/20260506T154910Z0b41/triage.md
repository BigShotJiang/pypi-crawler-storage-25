## Broken (will be fixed this iteration)

- Onboarding wizard heading does not update when transitioning from step 1 to step 2 — visible h2 stays on prior step's text while button label advances [evidence: "After selecting Retail Investor and clicking Continue, the modal heading in the accessibility tree remained 'What describes you?' while the button text changed to 'Open Session Creator'. The step 2 heading 'Create Your First Session' exists in the DOM but the visual transition did not update the displayed h2."] [scope hint: dashboard/onboarding.js, dashboard/index.html]
- Plugin cards rendered twice in the DOM — every plugin appears as two `.plugin-card` nodes in the accessibility tree on settings.html#plugins [evidence: "Querying '.plugin-card' returns each plugin exactly twice (e.g. two entries for 'price', two for 'fundamentals_s3', etc.) suggesting a duplicate-render bug or the plugin list is rendered into two different DOM trees that are both queryable."] [scope hint: dashboard/settings.js, dashboard/settings.html]

## Logged (not actioned)

- finnhub/fred/edgar plugins show UNHEALTHY on first load with no setup guidance [classification: nice-to-have]
- news_s3 and sentiment plugins DEGRADED with opaque recovery action [classification: annoying]
- POST /v1/sessions/{id}/trade returns 405; correct path is /v1/sessions/{id}/trade/order [classification: working-as-designed]
- CSRF token requirement not mentioned on API Keys page [classification: annoying]
- Selecting a session template overwrites typed Session Name silently [classification: annoying]
- No 'fundamentals strategy' concept exposed in UI labels [classification: nice-to-have]
- API Keys page shows only truncated values with no in-page reveal/copy per row [classification: nice-to-have]
- Clock defaults to FROZEN with no proactive prompt to advance [classification: nice-to-have]
- No 'Fundamentals' session template (only Conservative ETF, Tech Growth, Custom) [classification: nice-to-have]
- No per-plugin 'how to fix' link/guidance for UNHEALTHY plugins [classification: nice-to-have]
- No 'Run Benchmark' entry point in dashboard UI [classification: nice-to-have]
- Win Rate N/A after a single filled order is accurate but confusing copy [classification: annoying]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260506T154910Z0b41 — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. `docs/bug-hunt/20260506T154910Z0b41/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log,
   deploy_status.txt, retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260506T154910Z0b41","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline.
   Team D MUST stage the file. If a refactor verdict pruned entries
   this iteration, Team D MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`
   (the audit log of resolved signals).

Team D's commit message must reference iteration 20260506T154910Z0b41 and name which docs were
touched (e.g., "docs: bug-hunt 20260506T154910Z0b41 — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
