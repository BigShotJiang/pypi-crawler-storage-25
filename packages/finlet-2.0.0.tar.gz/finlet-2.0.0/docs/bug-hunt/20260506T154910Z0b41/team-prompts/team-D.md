You are Team D: Docs commit for bug-hunt iteration 20260506T154910Z0b41.

**Blocked by:** Team A merged (`efdbba1`); Team E merged (`cb1dc78`); Phase 5.5 retest_results.json exists.

## Context

This iteration:
- Team A fixed: onboarding wizard step heading not repainted on transition. Fix at `dashboard/onboarding.js` showStep() — repaint h2 from registry on every step.
- Finding 2 (plugin cards duplicated) was DEMOTED to `needs-investigation` by plan-features recon per PF-18. No fix shipped for it.
- Phase 5.5 retest: Finding 1 PASS on live finlet.dev (heading repaint verified). Finding 2 skipped-not-retestable.
- No patch-ineffective signals appended to pending_recurrences.jsonl.

## Read these files first

- `docs/KNOWN_FAILURES.md` — known pre-existing failures; do NOT report these as issues.
- `docs/bug-hunt/20260506T154910Z0b41/triage.md` — Required Docs Updates block at the bottom.
- `docs/bug-hunt/20260506T154910Z0b41/blind_report.json` — full finding set (truth source for what the blind agent saw).
- `docs/bug-hunt/20260506T154910Z0b41/triage.json` — classification results.
- `docs/bug-hunt/20260506T154910Z0b41/plan.md` — execution plan (incl. why Finding 2 was demoted).
- `docs/bug-hunt/20260506T154910Z0b41/retest_results.json` — Phase 5.5 outcomes.
- `docs/bug-hunt/refactor-queue/onboarding-checklist.md` — append `verdict: incomplete`.
- `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md` — append `verdict: incomplete`.
- Existing `docs/LESSONS.md` for current voice/format (read tail).
- Existing `docs/REMAINING_TASKS.md` for the "Bug Hunt — Closed" subsection format (read tail).

## Files touched

1. **Modified: `docs/REMAINING_TASKS.md`** — add "Bug Hunt 20260506T154910Z0b41 — Closed" subsection. Two entries:
   - Closed: `onboarding-wizard-heading-not-repainted` (category onboarding-checklist) — heading repaint added in `showStep()`. Phase 5.5 retest PASSED on live prod.
   - Demoted to needs-investigation: `plugin-cards-duplicated` (category dashboard-state-sync) — recon at HEAD `4d620b1` could not locate a duplicate-render path; the blind agent's `.plugin-card` selector does not match the actual class name (`.plugin-config-card`). Future iteration with DevTools-snapshot evidence may re-elevate.

2. **Modified: `docs/LESSONS.md`** — append at least TWO lessons:
   - LESSON-####: Step-transition functions that paint dots/buttons must paint the heading too. Registry contracts (e.g., `WIZARD_STEPS`) cover the data, but the renderer must read every field on every transition or partial-paint bugs are guaranteed. Reusable rule: "When a registry exists, audit the renderer for completeness, not just the producer."
   - LESSON-####: Blind-agent symptom selectors do not always match the codebase's actual class names. Recon must verify the symptom predicate against HEAD, not just the named scope. When the bug surface is not present where claimed, demote to `needs-investigation` rather than guess at a fix. PF-18 reroute rule applied this iteration.

3. **Modified: `docs/ARCHITECTURE.md`** — `skip-with-note` (no architectural surface changed: no new endpoint, no new middleware, no schema field, no new plugin contract). Mention this explicitly in the commit message ("ARCHITECTURE unchanged this iteration").

4. **Modified: `docs/KNOWN_FAILURES.md`** — refresh as needed. Pre-flight already updated this; if no new failures appeared during execution, no further edit needed (note in commit message).

5. **Modified: `docs/bug-hunt/refactor-queue/onboarding-checklist.md`** — read existing frontmatter, then add `verdict: incomplete` field. The reason: "iteration 20260506T154910Z0b41 produced a new onboarding-checklist instance (heading not repainted on step 1→2 transition); refactor was correct but under-scoped — it converged step-content onto the registry but did not converge the renderer onto the registry." Place this verdict + reason in the frontmatter or just below it, matching how other refactor-queue docs format their verdicts.

6. **Modified: `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md`** — read existing frontmatter, then add `verdict: incomplete` with similar reason citing the new onboarding-checklist instance.

7. **New (stage all):** every artifact in `docs/bug-hunt/20260506T154910Z0b41/`:
   - blind_report.json
   - cleanup.log
   - isolation_warning.txt
   - triage.md, triage.json
   - plan.md
   - exec-trace.txt
   - team-prompts/team-A.md, team-prompts/team-E.md, team-prompts/team-D.md (this file itself!)
   - deploy_status.txt
   - retest_results.json
   `git add` the entire directory.

8. **NOT modified:** `docs/bug-hunt/pending_recurrences.jsonl` is empty (no patch-ineffective signals this iteration). Don't touch it. `docs/bug-hunt/pending_recurrences.resolved.jsonl` is also untouched (no refactor verdicts pruned this iteration — incomplete verdicts do NOT prune pending entries; only `effective` does).

## Deliverable

A single commit with all docs updates and artifacts.

## Validation

- [ ] `git diff --name-only HEAD~1 HEAD` lists every file in the touched list above.
- [ ] No code files modified — only `docs/*` and `docs/bug-hunt/refactor-queue/*`.
- [ ] Commit message names: REMAINING_TASKS, LESSONS (with new entry count), ARCHITECTURE (unchanged this iteration), KNOWN_FAILURES (unchanged this iteration), refactor-queue (2 verdicts set), ledger reference (Team E's commit).
- [ ] `tail docs/REMAINING_TASKS.md` shows the new "Bug Hunt 20260506T154910Z0b41 — Closed" subsection.
- [ ] Both refactor-queue docs now contain `verdict: incomplete`.

## CRITICAL RULES

- You MUST `git add` every file you modify or create + `git commit` before finishing.
- Commit message format (single line, then body):
  ```
  [Team D]: docs: bug-hunt 20260506T154910Z0b41 — record onboarding heading-paint fix; demote plugin-cards finding to needs-investigation; LESSONS +2; ARCHITECTURE unchanged this iteration; refactor-queue: 2 verdicts set (incomplete); ledger +1
  ```
- Do NOT delete the refactor-queue docs.
- If you find another untracked artifact in `docs/bug-hunt/20260506T154910Z0b41/` not listed above (e.g., a scratch file), include it in the `git add` and mention it in the commit message.
- Run on `/Users/justnau/finlet` main checkout (no worktree). Use `git -C /Users/justnau/finlet ...` for all git ops.

When done, report: DONE + commit hash + list of files in the commit + tail of REMAINING_TASKS.md (new subsection only).
