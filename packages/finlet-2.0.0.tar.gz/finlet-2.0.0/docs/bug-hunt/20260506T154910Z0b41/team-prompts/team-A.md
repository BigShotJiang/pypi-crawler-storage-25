You are Team A: Onboarding wizard step-heading update.

**Iteration:** bug-hunt 20260506T154910Z0b41
**Plan:** docs/bug-hunt/20260506T154910Z0b41/plan.md
**Spawn base SHA:** 2885a916a4ae05e7e8f235159c3105767b976a76 (your worktree starts here after auto-reset)
**Blocked by:** none — start immediately.

## Read these files first

- `docs/KNOWN_FAILURES.md` — pre-existing failures; do NOT report these as issues.
- `dashboard/onboarding.js` — full file. The relevant block is lines ~583-590 (`buildWizardHTML()` static h2 render) and lines ~683-745 (`showStep(step)` transition function which paints dots/lines/button text but NOT the heading).
- `docs/decisions/onboarding-checklist-step-contract.md` — every wizard step's title MUST come from `WIZARD_STEPS[i].title`, not from a hand-edited h2.

## Recon evidence (verified by recon agent against HEAD `4d620b1`)

```javascript dashboard/onboarding.js:683-745
let showStep = function showStep(step) {
    currentStep = step;
    if (state) {
        state.wizardCurrentStep = currentStep;
        saveState(state);
    }
    const overlay = document.getElementById('onboarding-overlay');
    if (!overlay) return;
    const wizardStep = WIZARD_STEPS[step - 1];
    if (!wizardStep) return;

    // Update step visibility
    overlay.querySelectorAll('.onboarding-step').forEach(el => {
        el.classList.remove('onboarding-step--active');
    });
    const activeStep = document.getElementById(`ob-step-${step}`);
    if (activeStep) activeStep.classList.add('onboarding-step--active');

    // Update progress dots
    // ... dot/line repaint ...

    // Update Next button text and state from the registry entry.
    const nextBtn = document.getElementById('ob-next');
    if (nextBtn) {
        nextBtn.textContent = wizardStep.nextLabel;
        nextBtn.disabled = (step === 1 && !selectedPersona);
    }

    // Step-specific body population (Step 3 needs the persona for
    // action-card generation).
    if (step === 3) {
        populateStep3FromRegistry();
    }
};
```

`showStep()` toggles `.onboarding-step--active`, repaints dots/lines, updates the Next button label — but does NOT update the h2 element inside the active step. The h2 is rendered once at module init via `buildWizardHTML()` and never re-painted. Step 2 → 3 worked in the blind walk because step-3 has a special-cased `populateStep3FromRegistry()` path that re-paints the title node `#ob-step3-title`.

## Bug surface

Symptom: clicking Continue on step 1 leaves the visible h2 reading "What describes you?" while the button label correctly updates to "Open Session Creator". Same registry-driven repaint should run for ALL steps.

## Files touched

- Modified: `dashboard/onboarding.js` — add heading repaint inside `showStep()` so the active step's h2 always reflects the registry's `title` field.

## Deliverable

After clicking the Next/Continue button on any wizard step, the visible h2 heading inside the now-active step matches `WIZARD_STEPS[step - 1].title` from the registry. No regression on step 1, 2, or 3.

## Validation

- [ ] `uv run pytest tests/ -x -q -k "onboarding or wizard"` passes (note: most onboarding tests are JS-side; backend pytest is sanity only).
- [ ] Pre-commit hooks pass (`bash scripts/lint-trusted-types.sh`, `bash scripts/lint-event-bus.sh`).
- [ ] Diff is small (<30 lines), localized to `showStep()` + (optional) the step-3 branch cleanup.
- [ ] No regressions in `dashboard/onboarding.js` outside `showStep()`.

## Implementation guidance

- Minimal-diff: prefer adding 2-3 lines inside `showStep()` over restructuring `buildWizardHTML()`.
- The fix: inside `showStep()`, after `const activeStep = document.getElementById(\`ob-step-${step}\`);` and the `activeStep.classList.add('onboarding-step--active')` line, query the heading and set its textContent from the registry. Suggested code:
  ```javascript
  if (activeStep) {
      activeStep.classList.add('onboarding-step--active');
      const heading = activeStep.querySelector('h2.onboarding-step-title');
      if (heading) heading.textContent = wizardStep.title;
  }
  ```
- If you find that step-3's title is repainted twice after your fix (once in `showStep()`, once in `populateStep3FromRegistry()`), pick ONE source-of-truth — likely `showStep()` — and remove the redundant assignment from `populateStep3FromRegistry()`. If `populateStep3FromRegistry()` is doing more than just title-paint (it likely populates action cards, which is fine), only remove the title-paint line.

## CRITICAL RULES

- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns in those files.
- You MUST `git add dashboard/onboarding.js` and `git commit` all your changes before finishing.
- Your commit message must start with `[Team A]:`. Suggested message: `[Team A]: dashboard: paint wizard step heading from registry on every showStep transition (close 20260506T154910Z0b41 onboarding-checklist)`
- Run the validation commands from your spec before finishing. Surface PASS/FAIL.
- If validation fails, fix the issue and re-commit.
- **Worktree-rules:** you are in an ISOLATED worktree. Do NOT touch files outside `dashboard/`. Do NOT modify files in the main checkout — only in your assigned worktree path.

When done, report: DONE + commit hash + validation results
OR: BLOCKED + what went wrong
