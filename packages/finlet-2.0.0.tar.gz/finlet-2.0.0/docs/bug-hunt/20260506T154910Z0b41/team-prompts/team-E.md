You are Team E: Ledger entry for bug-hunt iteration 20260506T154910Z0b41.

**Blocked by:** Team A merged on origin/main as `efdbba1331445e60d83d25ff6d9db0c717a07171` ("[Team A]: dashboard: paint wizard step heading from registry on every showStep transition").

## Read these files first

- `docs/KNOWN_FAILURES.md` — known pre-existing failures; do NOT report these as issues.
- `docs/bug-hunt/ledger.jsonl` — last 5 lines for schema reference. Use the EXACT same flat schema.

## Files touched

- Append-only: `docs/bug-hunt/ledger.jsonl` — exactly ONE JSONL line for Team A's fix.

## Deliverable

Append exactly this JSON line (single-line, no trailing comma) to `docs/bug-hunt/ledger.jsonl`:

```json
{"iteration_ts":"20260506T154910Z0b41","finding_id":"onboarding-wizard-heading-not-repainted","category":"onboarding-checklist","summary":"Wizard step heading stays on prior step's title because showStep() updates dots/button but not h2","scope_files":["dashboard/onboarding.js"],"team":"A","commit":"efdbba1331445e60d83d25ff6d9db0c717a07171"}
```

Note the demoted Finding 2 (plugin cards duplicated) is NOT a ledger entry — only `real-broken` items closed this iteration go in the ledger. Team D's REMAINING_TASKS update is where the demotion is recorded.

## Validation

- [ ] `wc -l docs/bug-hunt/ledger.jsonl` grew by exactly 1 (run before and after to confirm).
- [ ] `tail -1 docs/bug-hunt/ledger.jsonl | jq .` parses cleanly and matches the JSON above.
- [ ] `commit` field equals `efdbba1331445e60d83d25ff6d9db0c717a07171` (40-char SHA).

## CRITICAL RULES

- You MUST `git add docs/bug-hunt/ledger.jsonl` and `git commit` before finishing.
- Commit message: `[Team E]: ledger: bug-hunt 20260506T154910Z0b41 — onboarding-checklist (Team A)`.
- Do NOT modify any other file.
- Run on `/Users/justnau/finlet` main checkout (no worktree). Use `git -C /Users/justnau/finlet ...` for all git ops to avoid CWD drift.

When done, report: DONE + commit hash + tail -1 of the ledger.jsonl file.
