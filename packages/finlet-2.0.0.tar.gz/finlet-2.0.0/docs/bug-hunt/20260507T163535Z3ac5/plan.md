# Bug-Hunt 20260507T163535Z3ac5 — Execution Plan

> Generated from `docs/bug-hunt/20260507T163535Z3ac5/triage.md`. Recon reconciled per PF-19 from `claude_recon.md` (Claude Explore) and `codex_recon.md` (Codex gpt-5.5 xhigh). Last updated: 2026-05-07.
> Baseline HEAD: `23505f49b90c873677a6b5c4b7c22cf86d1bfd32`

## Constraints

- **Bug-hunt scope.** This iteration acts on `real-broken` findings from the blind walk only. Tangential recon observations (e.g., ARCHITECTURE.md self-contradiction at lines 225-232 vs 184 — see Pending Investigations) are logged but NOT actioned this iteration.
- **Post-launch-cut.** Production dashboard had a write-path-cut on 2026-05-06 (commits `ce57ac8`, `d41aa95`). Cut code preserved at `legacy/dashboard-ui/`. Teams MUST NOT touch `legacy/` files (a pre-commit hook blocks legacy edits — `scripts/lint-no-legacy-edits.sh`). If a fix needs a piece of cut UI, restore it in `dashboard/` rather than editing `legacy/`.
- **Worktree isolation.** Every fix team works in an isolated git worktree. Shared-file conflicts (see File Conflict Table) determine merge order.
- **Doc updates mandatory.** Per the Required Docs Updates block in `triage.md`, Team F MUST run last and produce a docs commit covering REMAINING_TASKS, LESSONS, ledger, KNOWN_FAILURES, decisions/, and bug-hunt artifact tracking.

## PF-19 Reconciliation Notes

Both `claude_recon.md` and `codex_recon.md` exist in this iteration's directory. Per PF-19, the planner reconciled both reports BEFORE writing team specs. Reconciliation outcomes per finding:

| Finding | Recon agreement | Action |
|---------|-----------------|--------|
| F1 finlet auth register | Full agreement on 4-file scope | Union (= same 4 files) → Team A |
| F2 cli plugins-add prod symptom | Both agree HEAD CLI is fixed; deploy/install lag suspected | **Demoted to needs-investigation** (PF-19 rule 3) |
| F3 favicon 404 | Full agreement on missing static asset / no route | Union (= same surfaces) → Team D |
| F4 plugin permanent-degraded | Codex broader: parallel "Run ingestion first" surfaces in price/fundamentals plugins; Ingest button stranded in `legacy/` | Scope clarified: honest-copy fix on news+sentiment producers; do NOT special-case dashboard wiring → Team C |
| F5 setup.html key reveal | Codex broader: also flagged ARCHITECTURE.md:1054-1056 stale "Settings page" copy | Union → Team A (setup.html copy fix; ARCHITECTURE drift logged for Team F to mention but not fix this iter) |
| F6 session modal prefill | Both agents disagree with blind framing (hardcoded template default, NOT active-session state); Codex caught e2e test that pins bad behavior | Scope clarified: fix is one-line `nameInput.value = ''` + e2e test update → Team B |

## File Conflict Table

| File | Touched by Teams | Notes |
|------|------------------|-------|
| `dashboard/index.html` | A (lines 84-88), B (lines 306-328) | Different line ranges, but same file → sequential merge |
| `dashboard/api-keys.html` | A | sole touch |
| `dashboard/api-keys.js` | A | sole touch |
| `dashboard/agent-guide.html` | A | sole touch |
| `dashboard/setup.html` | A | sole touch |
| `dashboard/app.js` | B | sole touch |
| `dashboard/favicon.ico` | D (NEW file) | sole touch |
| `finlet/api/app.py` | D | only if route-redirect approach chosen |
| `finlet/plugins/news_plugin.py` | C | sole touch |
| `finlet/plugins/sentiment_plugin.py` | C | sole touch |
| `tests/e2e/journey-04-dashboard.spec.ts` | B | sole touch |
| `tests/plugins/test_news_plugin.py` | C | sole touch (regression test) |
| `tests/plugins/test_sentiment_plugin.py` | C | sole touch (regression test) |
| `docs/REMAINING_TASKS.md` | F | sole touch |
| `docs/LESSONS.md` | F | sole touch |
| `docs/KNOWN_FAILURES.md` | F | sole touch |
| `docs/bug-hunt/ledger.jsonl` | F | sole touch (append-only) |
| `docs/bug-hunt/20260507T163535Z3ac5/` | F | sole touch (stage all artifacts) |

The only sequential constraint is `dashboard/index.html` between Teams A and B. Everything else is independent.

## Dependency Graph

- Team A (independent) — can start immediately
- Team B (file conflict on `dashboard/index.html` with A) — merges AFTER A
- Team C (independent) — can start immediately
- Team D (independent) — can start immediately
- Team F (logical: needs commit SHAs from A, B, C, D; needs all artifacts to exist) — merges LAST

## Critical Path

A → B → F (the longest chain). C and D run truly parallel and don't constrain merge order.

## Session Plan

### Session 1 — fix teams (parallel work, sequential merge for A/B; parallel for C/D)
**Parallel work:** Teams A, B, C, D all spawn worktrees concurrently and produce diffs.
**Merge order:**
1. Team C merges (no file conflicts; smallest diff; targeted tests on main).
2. Team D merges (no file conflicts; smallest diff).
3. Team A merges (touches `dashboard/index.html` first because it's the smaller index.html change).
4. Team B merges (rebase against post-A main; targeted tests on main).
**Session checkpoint:** Full test suite after all 4 teams merged. CI deploy-cycle starts.

### Session 2 — docs sync (after Session 1 fully landed)
**Sequential:** Team F runs last, reads `git log` for the merge SHAs from A, B, C, D and embeds them into the ledger entries.
**Merge order:** F merges directly (no conflicts).
**Session checkpoint:** Full test suite + manual verify that all bug-hunt artifacts are tracked.

---

## Teams

### Team A: Dashboard copy fixes (F1 + F5)

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/api-keys.html:39-43` — current page-subtitle string referencing `finlet auth register` (cited by both Claude recon and Codex recon)
- `dashboard/api-keys.js:52-60` — empty-state copy referencing `finlet auth register` (cited by both)
- `dashboard/agent-guide.html:53-65` — copy-button + `<pre>` block both referencing `finlet auth register` (cited by both)
- `dashboard/index.html:84-88` — first-run-step banner referencing `finlet auth register` (cited by both)
- `dashboard/setup.html:124-149` — Step 2 "Create your account" with `auth.html` link claiming "API key on the confirmation screen" (cited by both)
- `finlet/cli.py:447-462` — actual `register` command (NO `auth` Typer group exists) (cited by both)
- `dashboard/auth.html:205-214` — auth-success markup; confirms there is NO post-signup API-key reveal flow (cited by Codex recon)
- `dashboard/auth.js:831-852` — signup flow saves `apiKey` to `/auth/session` cookie but NEVER displays it to the user (cited by Codex recon)

**Recon evidence (verified by both recon agents against HEAD `23505f49`):**

```python finlet/cli.py:40-43
session_app = typer.Typer(help="Session management")
plugins_app = typer.Typer(help="Plugin management")
app.add_typer(session_app, name="session")
app.add_typer(plugins_app, name="plugins")
```
```python finlet/cli.py:447-462
@app.command()
def register(
    email: str = typer.Option(..., "--email", "-e", help="Email address for registration"),
) -> None:
    """Register a new account and receive an API key."""
```
*// Both recons: only `finlet register` exists. There is NO `auth` Typer group; `finlet auth --help` exits "No such command auth." A user copying `finlet auth register` from any of the 4 dashboard surfaces gets an immediate error.*

```html dashboard/api-keys.html:39-43
<h1 class="page-title">API Keys</h1>
<p class="page-subtitle">Read-only listing of API keys for your Finlet account. Use the CLI (<code>finlet auth register</code>) to create new keys. See <a href="agent-guide.html">the agent guide</a> for usage.</p>
```
*// cited by both recons*

```html dashboard/setup.html:124-149
<p class="setup-desc">
    Register a free account — no credit card required. The fastest way is to <a href="auth.html">sign up through the website</a>, which gives you an API key on the confirmation screen.
</p>
```
*// Codex recon — also notes the `<details>` REST-API alternative below (lines 144-149) IS correct. Only the website-signup sentence promises something that doesn't happen.*

```html dashboard/auth.html:205-214
<div class="auth-success" id="signup-success">
    <h3>Account created</h3>
    <p>You're all set. You can now sign in with your email and password.</p>
    <button type="button" class="auth-btn" id="go-to-dashboard-btn">Go to Dashboard</button>
```
*// Codex recon — confirms the post-signup screen does NOT show an API key. The promise in setup.html is unmet.*

**Files touched:**
- Modified: `dashboard/api-keys.html` — replace `finlet auth register` with `finlet register` in line 42 page-subtitle
- Modified: `dashboard/api-keys.js` — replace `finlet auth register` with `finlet register` in line 59 empty-state-desc
- Modified: `dashboard/agent-guide.html` — replace `finlet auth register` with `finlet register` in line 60 `data-copy=` attribute AND in line 65 `<pre><code>` block (TWO occurrences in this file)
- Modified: `dashboard/index.html` — replace `finlet auth register` with `finlet register` in line 86 first-run-step `<code>` block
- Modified: `dashboard/setup.html` — rewrite the website-signup paragraph (lines 127-129) to match actual flow. Replacement copy: "Register a free account — no credit card required. The fastest way is to [sign up through the website](auth.html). Once signed in, create an API key from the dashboard or use the REST API below to register and receive your key in one step." (do NOT promise a confirmation-screen reveal that doesn't exist)

**Deliverable:** Five surfaces in `dashboard/` no longer document non-existent `finlet auth register`; setup.html no longer promises a non-existent post-signup key reveal.

**Validation:**
- [ ] `rg "finlet auth register" -- dashboard/` returns ZERO matches.
- [ ] `rg "confirmation screen" -- dashboard/` returns ZERO matches OR only matches that have been rewritten to remove the false promise.
- [ ] `rg "finlet register" -- dashboard/` returns matches in api-keys.html, api-keys.js, agent-guide.html (×2), index.html.
- [ ] `uv run pytest tests/e2e/journey-shared-nav.spec.ts -x -q` passes (sanity check no shared-nav regression).
- [ ] Manual: load each of the 4 modified dashboard pages locally, view source, confirm `finlet register` (no `auth`) is rendered.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- The fix is mechanical string replacement plus one paragraph rewrite. Do NOT invent new copy beyond what's specified.
- For `setup.html`, preserve the existing `<details>` REST-API alternative block (lines 144-149) verbatim — it's correct.
- Do NOT touch any file in `legacy/` (pre-commit hook will block).
- Do NOT modify `dashboard/auth.html` or `dashboard/auth.js` — those are correct as-is per Codex recon. The fix is in setup.html copy, not auth implementation.

---

### Team B: Session-creation modal default name (F6)

**Blocked by:** Team A (file conflict on `dashboard/index.html`). Worktree may run in parallel; merge after A.

**Read these files first:**
- `dashboard/app.js:847-853` — `SESSION_TEMPLATES` registry, including `conservative.name = 'Conservative ETF'` (cited by both recons)
- `dashboard/app.js:901-941` — `selectTemplate()` and `openCreateSessionModal()` — the actual prefill site (cited by both)
- `dashboard/index.html:306-328` — `<div class="form-group">` containing `<input type="text" id="session-name">` (cited by both)
- `tests/e2e/journey-04-dashboard.spec.ts:277-299` — e2e test that PINS the current bad behavior (`expect(nameInput).toHaveValue('Conservative ETF')`) (cited by Codex recon ONLY — Claude recon missed this critical surface)

**Recon evidence (verified by both recon agents against HEAD `23505f49`):**

```js dashboard/app.js:847-853
// Codex recon
const SESSION_TEMPLATES = {
    conservative: { name: 'Conservative ETF', tickers: ['SPY', 'BND', 'GLD'] },
    tech: { name: 'Tech Growth', tickers: ['AAPL', 'GOOGL', 'MSFT', 'NVDA', 'META'] },
    custom: { name: 'Custom', tickers: [] },
};
```

```js dashboard/app.js:921-941
// Codex recon — selectTemplate writes the template's name into #session-name on every template click, INCLUDING on modal open via openCreateSessionModal → selectTemplate('conservative')
const nameInput = document.getElementById('session-name');
if (nameInput) {
    nameInput.value = templateKey === 'custom'
        ? ''
        : SESSION_TEMPLATES[templateKey]?.name || '';
}
```

```ts tests/e2e/journey-04-dashboard.spec.ts:277-299
// Codex recon — test PINS the bad behavior. Fix MUST update this test to assert empty name on open.
const modal = page.locator('#create-session-modal');
await expect(modal).toHaveClass(/fl-modal--visible/);
const nameInput = page.locator('#session-name');
// Modal opens with conservative template, name pre-filled.
await expect(nameInput).toHaveValue('Conservative ETF');
// Switch to Tech Growth — name should follow the template choice.
await page.click('[data-template="tech"]');
await expect(nameInput).toHaveValue('Tech Growth');
```

```html dashboard/index.html:306-328
// Both recons
<button type="button" class="template-card template-card--selected" data-template="conservative">
    <span class="template-card-name">Conservative ETF</span>
    <span class="template-card-tickers">SPY, BND, GLD</span>
</button>
...
<input type="text" id="session-name" class="form-input" placeholder="e.g. My First Simulation" maxlength="100" required autocomplete="off">
```

**Both recons disagree with the blind report's framing:** The bug is NOT that the modal reads the active session's name. The modal is hardcoded to default-select the `conservative` template, and `selectTemplate()` writes `SESSION_TEMPLATES[conservative].name = 'Conservative ETF'` into the name field. Every time `openCreateSessionModal()` runs, it calls `selectTemplate('conservative')`, which writes "Conservative ETF" into the input. Two consecutive opens produce the same default name → duplicate sessions named "Conservative ETF" if the user doesn't customize.

**Files touched:**
- Modified: `dashboard/app.js` — change `selectTemplate()` so that on the FIRST call (from `openCreateSessionModal()`) the name field is left empty. Implementation: add an `opts = {seedName: true}` parameter; `openCreateSessionModal` calls `selectTemplate('conservative', {seedName: false})`. User-driven template clicks keep `seedName: true` so switching templates still updates the name (preserves the "switch template → name follows" UX). Lines 921-925.
- Modified: `dashboard/index.html` — keep the existing `placeholder="e.g. My First Simulation"` (it already exists at line 322 per Codex recon excerpt). Verify no template-name leak via the `template-card-name` <span> — those are display only, not form values. NO CHANGE NEEDED to index.html unless validation reveals an unexpected leak.
- Modified: `tests/e2e/journey-04-dashboard.spec.ts:277-299` — update the regression assertions: open modal → expect empty name (not "Conservative ETF"); user clicks Tech Growth → expect "Tech Growth"; clicks Conservative → expect "Conservative ETF" (template-click DOES seed); clicks Custom → expect empty.

**Deliverable:** Opening the New Session modal leaves the name field EMPTY (placeholder visible). Selecting a non-Custom template after opening seeds the field with that template's name. Custom always clears. Two consecutive opens without user input cannot produce duplicate auto-named sessions.

**Validation:**
- [ ] `npx playwright test tests/e2e/journey-04-dashboard.spec.ts -g "Session-Name Template" -x` passes with the new assertions.
- [ ] `uv run pytest tests/api/test_session_create.py -x -q` passes (sanity — server-side session creation contract unchanged).
- [ ] Manual: load `/index.html`, click "New Session", confirm name field is empty with placeholder; click Tech Growth, name fills; click Conservative, name fills; click Custom, name clears; close + reopen modal, name is empty again.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- DO NOT change `SESSION_TEMPLATES`. The registry is correct.
- DO NOT remove the `placeholder=` attribute from the input — it's the correct UX for the empty-on-open state.
- The test file at `tests/e2e/journey-04-dashboard.spec.ts:277-299` PINS the current bad behavior. You MUST update it; failing to do so will cause the test to fail after your `app.js` change. (See Codex recon for the full pinned-assertion block.)
- Do NOT touch any file in `legacy/`.

---

### Team C: Plugin health honest copy (F4)

**Blocked by:** none — can start immediately.

**Read these files first:**
- `finlet/plugins/news_plugin.py:475-486` — current degraded message "No cached news data files found. Run ingestion first." (cited by both recons)
- `finlet/plugins/sentiment_plugin.py:461-469` — current degraded message "No cached sentiment data files found. Run ingestion first." (cited by both)
- `finlet/plugins/price_plugin.py:910-918` — parallel "Run ingestion first" message in price plugin — for reference, NOT to be modified (cited by Codex recon ONLY)
- `finlet/plugins/fundamentals_plugin.py:1064-1071` — parallel message in fundamentals plugin — for reference, NOT to be modified (cited by Codex recon ONLY)
- `finlet/api/routes_plugins.py:7-18` — confirms `POST /plugins/{name}/ingest` is a STUB (returns 202 + uuid; no real ingest) (cited by Codex recon)
- `legacy/dashboard-ui/settings.js:995-1006` — the ORIGINAL Ingest button affordance, cut by the launch — for reference only (cited by Codex recon)
- `tests/plugins/test_news_plugin.py` — existing health test coverage (find current health assertions; new test must assert the new copy)
- `tests/plugins/test_sentiment_plugin.py` — existing health test coverage

**Recon evidence (verified by both recon agents against HEAD `23505f49`):**

```python finlet/plugins/news_plugin.py:475-486
// Both recons
if cached_files:
    return PluginHealth(
        status=PluginHealthStatus.HEALTHY,
        message=f"OK — {len(cached_files)} cached files",
    )
return PluginHealth(
    status=PluginHealthStatus.DEGRADED,
    message="No cached news data files found. Run ingestion first.",
)
```

```python finlet/plugins/sentiment_plugin.py:461-469
// Both recons
return PluginHealth(
    status=PluginHealthStatus.HEALTHY,
    message=f"OK — {len(cached_files)} cached files",
)
return PluginHealth(
    status=PluginHealthStatus.DEGRADED,
    message="No cached sentiment data files found. Run ingestion first.",
)
```

```python finlet/api/routes_plugins.py:7-18
// Codex recon
- ``POST /plugins/{name}/ingest`` — stub endpoint that the dashboard
  Ingest button calls when the plugin reports a "Run ingestion first"
  degraded message. Returns 202 Accepted with ``{"job_id": "<uuid>"}``.
  Auth required (Bearer API key) so anonymous traffic cannot enqueue
  jobs. The actual ingest pipeline wiring lives in
  ``scripts/ingest_yfinance_prices.py`` etc. and is not yet exposed
  via this endpoint — that is the next iteration.
```
*// The stub endpoint exists but does NOT actually ingest. Wiring an Ingest button to it would create a "click does nothing visible" dead affordance — exactly the dead-affordance pattern this iteration is trying to fix.*

**Why honest copy, not Ingest button restoration:** The launch cut removed the Ingest button from the production dashboard. Restoring it would also require either (a) wiring to a real ingest pipeline (out of scope for one bug-hunt iteration) or (b) accepting that clicking the button does nothing visible (dead affordance — the bug we're trying to fix). The cleanest fix for this iteration is to update the user-visible message so it doesn't promise an action the user can take.

**Scope decision (do NOT widen):** Only `news_plugin.py` and `sentiment_plugin.py` get updated copy. `price_plugin.py` and `fundamentals_plugin.py` keep their "Run ingestion first" message — those plugins ARE expected to have data on prod (the data lake is populated for them) and a Degraded status there indicates a real ops problem, not a permanent unsupported state.

**Files touched:**
- Modified: `finlet/plugins/news_plugin.py:475-486` — replace the degraded message body. New text: `"News data not yet available. Ingestion infrastructure pending — this plugin will activate once news ingestion is wired."`
- Modified: `finlet/plugins/sentiment_plugin.py:461-469` — replace the degraded message body. New text: `"Sentiment data not yet available. Ingestion infrastructure pending — this plugin will activate once sentiment ingestion is wired."`
- Modified: `tests/plugins/test_news_plugin.py` — update or add a regression test that asserts the new copy text. Pattern: assert `"not yet available" in health.message` AND assert `"Run ingestion" not in health.message`.
- Modified: `tests/plugins/test_sentiment_plugin.py` — same pattern as news.

**Deliverable:** Plugin Health for news and sentiment shows a Degraded badge with a message that does NOT promise a user-actionable fix. The rest of the producer plugins (price, fundamentals) keep their existing "Run ingestion first" message because their Degraded state IS ops-actionable.

**Validation:**
- [ ] `uv run pytest tests/plugins/test_news_plugin.py -x -q` passes with new assertion.
- [ ] `uv run pytest tests/plugins/test_sentiment_plugin.py -x -q` passes with new assertion.
- [ ] `uv run pytest tests/plugins/test_price_plugin.py -x -q` passes UNCHANGED (no regression on the producer plugins we did NOT modify).
- [ ] `rg "Run ingestion first" finlet/plugins/news_plugin.py finlet/plugins/sentiment_plugin.py` returns ZERO matches.
- [ ] `rg "Run ingestion first" finlet/plugins/price_plugin.py finlet/plugins/fundamentals_plugin.py` STILL returns matches (we didn't touch those).
- [ ] Manual: load `/index.html` against a session, confirm news/sentiment plugin cards show the new honest message and no orange "Run ingestion first" copy.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- The scope is EXACTLY `news_plugin.py` and `sentiment_plugin.py` plus their two test files. DO NOT widen to `price_plugin.py` or `fundamentals_plugin.py` — those messages are intentionally left as-is.
- Keep `PluginHealthStatus.DEGRADED` — the status code stays Degraded; only the message text changes.
- Do NOT touch any file in `legacy/`.

---

### Team D: Favicon (F3)

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/favicon.svg` — existing SVG favicon (referenced from all 8 HTML pages) (cited by both recons)
- `dashboard/index.html:8-10` — `<link rel="icon" type="image/svg+xml" href="favicon.svg">` pattern (cited by both)
- `dashboard/setup.html:6-9` — same pattern (cited by Codex recon as evidence the pattern is uniform)
- `finlet/api/app.py:609-612` — current `StaticFiles(directory=str(dashboard_dir), html=True)` mount at `/`; no explicit `/favicon.ico` route exists (cited by Codex recon)

**Recon evidence (verified by both recon agents against HEAD `23505f49`):**

```python finlet/api/app.py:609-612
// Codex recon — root StaticFiles mount serves whatever exists in dashboard/. No favicon.ico file → 404.
app.routes.insert(0, Route("/pricing", _serve_pricing, methods=["GET", "HEAD"]))
app.routes.insert(0, Route("/login", _serve_login, methods=["GET", "HEAD"]))
app.mount("/", StaticFiles(directory=str(dashboard_dir), html=True), name="dashboard")
```

```bash
// Both recons — find dashboard finlet deploy -iname '*favicon*' returns ONLY:
dashboard/favicon.svg
```

**Browsers always request `/favicon.ico` regardless of the `<link rel="icon">` tag** — that's a baked-in browser convention. The `<link>` tag adds an additional fetch but doesn't suppress the legacy `/favicon.ico` request. Two valid fix paths:

1. **Static asset path:** Add `dashboard/favicon.ico` (an actual `.ico` file). Simplest fix; the StaticFiles mount serves it automatically.
2. **Route redirect path:** Add `Route("/favicon.ico", _serve_favicon_redirect, ...)` to `finlet/api/app.py` that returns a 301 to `/favicon.svg`. More flexible (one source of truth) but requires a route handler.

**Choose path 1 (static asset)** for simplicity and zero-runtime-cost. Generate an `.ico` from the existing `favicon.svg` (e.g., via `convert` / `rsvg-convert` / online tool); commit the binary.

**Files touched:**
- New: `dashboard/favicon.ico` — 16x16 + 32x32 multi-size .ico generated from `dashboard/favicon.svg`. Binary file; commit as-is.
- Modified: NONE in `finlet/api/app.py` (path 1 chosen — no route needed).

**Deliverable:** `GET /favicon.ico` against `https://finlet.dev` returns 200 + `image/x-icon` (or `image/vnd.microsoft.icon`) instead of 404. Console error on every page load is gone.

**Validation:**
- [ ] After commit, `curl -sI https://finlet.dev/favicon.ico` (post-deploy) returns `200` and `Content-Type: image/x-icon` or `image/vnd.microsoft.icon`. (This is the post-deploy retest assertion; pre-deploy you can validate against a local `finlet serve` instance.)
- [ ] `uv run pytest tests/api/test_static_routes.py -x -q` passes (or whatever test currently asserts static-mount behavior; if no such test exists, no regression check is needed — adding one is out of scope).
- [ ] `ls -la dashboard/favicon.ico` shows the file is committed and non-empty (>500 bytes typically for a multi-size .ico).
- [ ] Manual: open `/index.html` in a browser, open DevTools console, confirm no 404 entry for `/favicon.ico`.

**Agent instructions:**
- You MUST `git add` + `git commit` the binary `.ico` before finishing.
- Generate the `.ico` from `dashboard/favicon.svg` so the visual identity matches. Acceptable tools: `rsvg-convert dashboard/favicon.svg -o /tmp/favicon.png && convert /tmp/favicon.png dashboard/favicon.ico` or any equivalent. The .ico should contain at least one 16x16 raster.
- Do NOT add a route handler to `finlet/api/app.py` — path 1 (static asset) is the chosen approach.
- Do NOT modify any of the existing HTML `<link rel="icon">` tags — they're correct for SVG-capable browsers; the .ico is the legacy fallback.
- Do NOT touch any file in `legacy/`.

---

### Team F: Docs sync (Required Docs Updates block)

**Blocked by:** Teams A, B, C, D (logical: Team F needs commit SHAs from each merged team to populate the ledger).

**Read these files first:**
- `docs/bug-hunt/20260507T163535Z3ac5/triage.md` — including the appended Required Docs Updates block (lines 25+ of the appended block).
- `docs/bug-hunt/ledger.jsonl` — last ~30 lines for category/format reference.
- `docs/REMAINING_TASKS.md` — for the closed-items append pattern.
- `docs/LESSONS.md` — for the lesson-format pattern (recent entries).
- `docs/KNOWN_FAILURES.md` — for any pre-existing failure entries that might be resolved this iteration.
- `docs/bug-hunt/pending_recurrences.jsonl` — currently empty; check it after Phase 5.5 to see if any patch-ineffective entries got appended.

**Recon evidence:** N/A — Team F is administrative docs sync, not a code surgery team. It does not assert "current state" claims about file:line behavior; it records what the prior teams did.

**Files touched:**
- Modified: `docs/REMAINING_TASKS.md` — add a "Bug Hunt 20260507T163535Z3ac5 — Closed" subsection enumerating the 5 actioned findings (F1, F3, F4, F5, F6 — note F2 is demoted, not closed).
- Modified: `docs/LESSONS.md` — append at least one lesson per finding that exposed a class of mistake. Specific lessons to write:
  - **finlet auth register stale across 4 surfaces** — When a CLI command is renamed, grep ALL of `dashboard/`, `docs/`, `tests/` for the old command string. The bug was in 4 separate files; a search-replace check would have caught all 4.
  - **Recon disagreement with blind framing → demote** — On F6 (session modal), both recons rejected the blind agent's "active-session state" framing and identified hardcoded template default. The triage classification (`dashboard-state-sync`) was wrong; the actual fix lives in the modal's default-select policy, not in any state-sync logic. **Triage categories should be reviewed by recon before they enter the ledger.**
  - **Plugin Ingest button cut without backend retraction** — F4 exists because the launch cut removed the UI affordance but left the producer plugin reporting an actionable-sounding "Run ingestion first" message. **When cutting a UI affordance, audit producer-side strings that assumed it existed.**
  - **PF-19 caught a parallel surface** — On F2's recon, Codex caught `tests/e2e/journey-04-dashboard.spec.ts:277-299` PINNING the bad behavior; Claude missed it. Without the union-recon, Team B's fix would have shipped against a passing local test that fails on the next prod run. **Single-source recon misses pinned-bad-behavior tests by construction.**
- Modified: `docs/ARCHITECTURE.md` — NO TOUCHES THIS ITERATION. Note in the Team F commit message: "ARCHITECTURE.md unchanged — known doc-drift at lines 225-232 and 1054-1056 logged as pending-investigation; not actioned this iter."
- Modified: `docs/KNOWN_FAILURES.md` — pre-flight refresh; remove any pre-existing entry that's now resolved (none expected this iteration; if so, note "no pre-existing failures resolved").
- New (optional): `docs/decisions/<short-name>.md` — only if a non-trivial reversible decision was made. The "honest copy over Ingest-button restoration" choice on F4 IS such a decision; write a 1-page record. Also: the "static .ico over route redirect" choice on F3 is a reasonable decision-record candidate but optional.
- Append: `docs/bug-hunt/ledger.jsonl` — exactly 5 JSON lines (one per closed finding: F1, F3, F4, F5, F6). Schema:
  ```json
  {"iteration_ts":"20260507T163535Z3ac5","finding_id":"<slug>","category":"<tag>","summary":"<short>","scope_files":["..."],"team":"A|B|C|D","commit":"<merge-sha-on-main>"}
  ```
  Use `git log --oneline main` to find each team's merge SHA after they land.
- Stage all artifacts in `docs/bug-hunt/20260507T163535Z3ac5/`: `triage.md`, `triage.json`, `blind_report.json`, `blind_report_raw.json`, `cleanup.log`, `isolation_warning.txt`, `claude_recon.md`, `codex_recon.md`, `codex_recon_prompt.txt`, `codex_recon.stdout.log`, `blind_launcher.{stdout,stderr}.log`, `plan.md`, `deploy_status.txt` (if Phase 5.5 ran), `retest_results.json` (if Phase 5.5 ran).

**Deliverable:** A single docs commit that closes all 5 actioned findings in the ledger, records lessons, and tracks every iteration artifact.

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` grew by EXACTLY 5 vs the pre-iter count.
- [ ] `jq -s '.[]' docs/bug-hunt/ledger.jsonl | jq 'select(.iteration_ts == "20260507T163535Z3ac5")' | jq -s 'length'` returns `5`.
- [ ] `git log --oneline -1 docs/bug-hunt/20260507T163535Z3ac5/` shows Team F's commit.
- [ ] `git status docs/bug-hunt/20260507T163535Z3ac5/` returns "clean working tree" (no untracked artifacts).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- The 5 ledger entries MUST cite real merge SHAs from `git log` — DO NOT invent SHAs.
- Each lesson in LESSONS.md MUST be a reusable rule, not a recap of the diff. If you can't write a generalizable lesson, omit that finding from LESSONS.md and note "no general lesson" in the Team F commit message.
- Do NOT touch ARCHITECTURE.md this iteration. The known drift at 225-232 and 1054-1056 is logged in Pending Investigations below; it's a separate cleanup task.
- Do NOT touch any file in `legacy/`.

---

## Pending Investigations (NOT actioned this iteration)

These items were surfaced by recon but are out-of-scope for the bug-hunt loop. Each is logged here so the next iteration's planner can act on them with full context.

### F2 — `cli-plugins-add-prod-symptom` (demoted from real-broken via PF-19 rule 3)

**Symptom from blind report:** Running `finlet plugins add edgar --email ...` and `finlet plugins add finnhub --api-key ...` both responded "Plugin configured. Restart server to apply." Plugin Health on `https://finlet.dev` did NOT update.

**Recon finding (both agents):** The CLI source at HEAD `23505f49` is FIXED. `finlet/cli.py:306-369` shows `plugins_add` PUTs to `/v1/settings/plugins` and prints live status. `tests/test_cli.py:741-808` includes coverage that REJECTS `"Restart server"` output and asserts the canonical endpoint is hit. Both Claude and Codex recon agree no source-level surgery is required.

**Possible root causes (need investigation):**
1. **Stale PyPI install** — the test user installed `finlet` at a version that predates the fix. The fix is on `main` but the published package wasn't bumped.
2. **Deploy lag** — production server is on an older deploy SHA than HEAD (unlikely but verifiable via `gh run list --branch main --limit 5`).
3. **Cached binary** — the test user's local `~/.cache/pip/wheels/...` has an old finlet wheel that pip is preferring.

**To resolve:**
- Check `pip show finlet` on the test user's machine — version number.
- Check `gh run list --branch main --workflow=deploy.yml --limit 3` — most recent deploy SHA.
- Check `aws s3 ls s3://<deploy-bucket>/...` or equivalent for the actual deployed artifact.

**Recommendation:** Open as a follow-up issue or re-run `/bug-hunt` after the test user verifies they're on the latest finlet from PyPI. The HEAD CLI is correct; there is no fix-team work here.

### Tangential recon observations (NOT in blind report)

These are doc-drift bugs the recon discovered but the blind agent did NOT flag. Out-of-scope for bug-hunt v1 (we only act on real-broken blind findings). Logged for a future general-cleanup iteration.

- `docs/ARCHITECTURE.md:225-232` describes the OLD `~/.finlet/plugins.json` + `POST /v1/plugins/{name}/reload` flow as canonical. `docs/ARCHITECTURE.md:184` correctly describes the NEW `PUT /v1/settings/plugins` flow. The two paragraphs in the same document contradict each other.
- `docs/ARCHITECTURE.md:1054-1056` describes a Settings page with API-key create/copy-once/revoke UI — that page was cut in the 2026-05-06 launch cut.
- `docs/PRIVACY_POLICY.md:546` claims user-provided API keys are stored in `~/.finlet/plugins.json`. The CLI no longer writes that file (per Codex recon `tests/test_cli.py:807-808` asserts `not (tmp_path / "plugins.json").exists()`).
- `finlet/plugins/edgar_plugin.py:86-93` error message tells the user to set identity in `~/.finlet/plugins.json` or via `finlet config set edgar.identity ...`. Both paths are stale; the canonical path is `finlet plugins add edgar --email ...`.

**Recommendation:** Spawn a single follow-up team in a future iteration (or a manual cleanup PR) that updates these 4 surfaces in lockstep. ~1 hour of work; no code change, just doc/error-string sync.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team B's e2e test update breaks main if A merges first and the index.html change moves the `#session-name` selector | Low | Medium | Team A only edits line 86 of index.html (first-run-step); the form-input lives at line 322 and is untouched by Team A. The selector is stable. Team B should still run `git pull --rebase` against post-A main before opening its PR. |
| Team C's test files don't exist yet (no `test_news_plugin.py` / `test_sentiment_plugin.py` in `tests/plugins/`) | Medium | Low | If absent, Team C creates them as new files following the `test_price_plugin.py` pattern. Sole-touch ownership remains — no conflict. |
| Team D's `.ico` generation pipeline fails on the agent's machine (no `convert` / `rsvg-convert` available) | Low | Medium | Fallback: agent uses an online SVG-to-ICO converter and pastes the output bytes. OR: agent commits a placeholder 16x16 .ico downloaded from a public CC0 source and notes the limitation in the commit message. |
| Team F's ledger SHAs are wrong because A/B/C/D merged with squash and the SHAs visible in `git log --oneline` are squash-commits, not the team's worktree commits | Medium | Low | Team F uses the SHA of the squash-merge commit on `main` (the one returned by the merge), NOT the worktree commit. `gh pr view <num> --json mergeCommit` returns this directly if PR-based; otherwise read from `git log --oneline main` after merge. |
| F2's prod symptom recurs in the next iteration if the test user doesn't upgrade their local CLI | High | Low | Team F's LESSONS.md entry calls out the version-pin convention. The Pending Investigations section gives the user a clear resolution path. |
| Codex's "parallel producer surfaces" insight on F4 prompts an over-scoped fix touching `price_plugin.py` and `fundamentals_plugin.py` | Medium | High | Team C's spec explicitly forbids widening to those plugins. Validation step `rg "Run ingestion first" finlet/plugins/price_plugin.py` STILL has matches enforces the no-widen contract. |

---

## Quality Checklist (Plan Validation)

- [x] Every team has a "Read these files first" list.
- [x] Every team has "You MUST git add + git commit" in agent instructions.
- [x] Every team has specific validation commands (not "run tests").
- [x] File conflict table accounts for ALL shared files.
- [x] No team touches >8 files.
- [x] Dependencies match the file conflict table (no hidden conflicts).
- [x] Critical path is actually the longest chain.
- [x] Session grouping respects all dependency constraints.
- [x] **Every "current state" claim in a team spec is backed by either a quoted-excerpt fenced block or a `(verified by recon agent against HEAD <SHA>)`-tagged paraphrase.** (PF-18) — All "current state" claims (e.g., "selectTemplate writes ... INTO #session-name") are backed by quoted excerpts from `claude_recon.md` and `codex_recon.md`, both verified against HEAD `23505f49`.
- [x] **If `codex_recon.md` exists, every team spec's "Read these files first" list AND "Files touched" list is the UNION of files cited by Claude recon and Codex recon, with attribution where only one agent cited a file.** (PF-19) — Surfaces only-cited-by-Codex (e.g., `tests/e2e/journey-04-dashboard.spec.ts:277-299` for Team B; ARCHITECTURE.md:1054-1056 for Pending Investigations) and only-cited-by-Claude (none material this iteration) are explicitly attributed in the team specs.

---

## Execution Status — COMPLETED 2026-05-07

- Pre-flight: 571570d
- Team A: 267a793 (F1 + F5 closed)
- Team B: 9d68d35 (F6 closed)
- Team C: 38b41d7 (F4 closed)
- Team D: 05430f2 (F3 closed)
- Team F (docs): ccaab51

F2 demoted to needs-investigation. See plan body "Pending Investigations" section.

Final test suite: 3976 passed, 0 failures.
