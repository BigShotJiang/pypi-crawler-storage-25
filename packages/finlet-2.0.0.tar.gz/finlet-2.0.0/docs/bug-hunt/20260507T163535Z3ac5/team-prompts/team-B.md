You are Team B: Session-creation modal default name (F6) for bug-hunt iteration 20260507T163535Z3ac5.

WORKING DIR: this is your isolated git worktree. Pre-flight pinned spawn_base_sha = 571570d4c18f2b6b3d7f28ebbb63a33a0882a20b. Your worktree was reset to that SHA before you started.

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report any test in that file as a regression.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns in those files.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message MUST start with "[Team B]:".
- Run the validation commands from your spec before finishing.
- If validation fails, fix the issue and re-commit.
- Do NOT touch any file in `legacy/` (pre-commit hook will block).
- DO NOT change `SESSION_TEMPLATES`. The registry is correct.
- DO NOT remove the `placeholder=` attribute from the input — it's the correct UX for the empty-on-open state.
- The test file at `tests/e2e/journey-04-dashboard.spec.ts:277-299` PINS the current bad behavior. You MUST update it; failing to do so will cause the test to fail after your `app.js` change.
- Note: Team A may merge before you on `dashboard/index.html`. You are unlikely to need to modify index.html (your fix is in app.js + the e2e test). If you DO need to touch index.html, the orchestrator will rebase your branch against post-A main before merging.

YOUR SPEC (verbatim from docs/bug-hunt/20260507T163535Z3ac5/plan.md):

### Team B: Session-creation modal default name (F6)

**Blocked by:** Team A (file conflict on `dashboard/index.html`). Worktree may run in parallel; merge after A.

**Read these files first:**
- `dashboard/app.js:847-853` — `SESSION_TEMPLATES` registry, including `conservative.name = 'Conservative ETF'`
- `dashboard/app.js:901-941` — `selectTemplate()` and `openCreateSessionModal()` — the actual prefill site
- `dashboard/index.html:306-328` — `<div class="form-group">` containing `<input type="text" id="session-name">`
- `tests/e2e/journey-04-dashboard.spec.ts:277-299` — e2e test that PINS the current bad behavior (`expect(nameInput).toHaveValue('Conservative ETF')`) — Codex recon caught this; Claude recon missed it

**Both recons disagree with the blind report's framing:** The bug is NOT that the modal reads the active session's name. The modal is hardcoded to default-select the `conservative` template, and `selectTemplate()` writes `SESSION_TEMPLATES[conservative].name = 'Conservative ETF'` into the name field. Every time `openCreateSessionModal()` runs, it calls `selectTemplate('conservative')`, which writes "Conservative ETF" into the input. Two consecutive opens produce the same default name → duplicate sessions named "Conservative ETF" if the user doesn't customize.

**Files touched:**
- Modified: `dashboard/app.js` — change `selectTemplate()` so that on the FIRST call (from `openCreateSessionModal()`) the name field is left empty. Implementation: add an `opts = {seedName: true}` parameter; `openCreateSessionModal` calls `selectTemplate('conservative', {seedName: false})`. User-driven template clicks keep `seedName: true` so switching templates still updates the name (preserves the "switch template → name follows" UX). Lines 921-925.
- Modified: NONE expected in `dashboard/index.html` — the existing `placeholder="e.g. My First Simulation"` is correct UX for the empty-on-open state.
- Modified: `tests/e2e/journey-04-dashboard.spec.ts:277-299` — update the regression assertions: open modal → expect empty name (not "Conservative ETF"); user clicks Tech Growth → expect "Tech Growth"; clicks Conservative → expect "Conservative ETF" (template-click DOES seed); clicks Custom → expect empty.

**Deliverable:** Opening the New Session modal leaves the name field EMPTY (placeholder visible). Selecting a non-Custom template after opening seeds the field with that template's name. Custom always clears. Two consecutive opens without user input cannot produce duplicate auto-named sessions.

**Validation:**
- [ ] `cd /Users/justnau/finlet && npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-04-dashboard.spec.ts -g "Session-Name Template" 2>&1 | tail -20` passes with the new assertions. (Note: this runs against a local dev server; if no local server, this validation may fail with URL-fetch errors — in that case run the targeted unit tests below instead.)
- [ ] `cd /Users/justnau/finlet && uv run pytest tests/api/test_session_create.py -x -q --timeout=60 -p no:cacheprovider 2>&1 | tail -10` passes (sanity — server-side session creation contract unchanged).
- [ ] `cd /Users/justnau/finlet && uv run pytest tests/ -q --timeout=120 -p no:cacheprovider 2>&1 | tail -10` — full suite still passes (no regression).
- [ ] Manual reading: `dashboard/app.js:901-941` shows the new `seedName` parameter wired correctly.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message starts with "[Team B]:".
- DO NOT change `SESSION_TEMPLATES`. The registry is correct.
- DO NOT remove the `placeholder=` attribute from the input — it's the correct UX for the empty-on-open state.

When done, report: DONE + commit hash + validation results.
OR: BLOCKED + what went wrong.
