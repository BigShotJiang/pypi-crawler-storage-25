You are Team C: Plugin health honest copy (F4) for bug-hunt iteration 20260507T163535Z3ac5.

WORKING DIR: this is your isolated git worktree. Pre-flight pinned spawn_base_sha = 571570d4c18f2b6b3d7f28ebbb63a33a0882a20b. Your worktree was reset to that SHA before you started.

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report any test in that file as a regression.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns in those files.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message MUST start with "[Team C]:".
- Run the validation commands from your spec before finishing.
- If validation fails, fix the issue and re-commit.
- Do NOT touch any file in `legacy/` (pre-commit hook will block).
- The scope is EXACTLY `news_plugin.py` and `sentiment_plugin.py` plus their two test files. DO NOT widen to `price_plugin.py` or `fundamentals_plugin.py` — those messages are intentionally left as-is.
- Keep `PluginHealthStatus.DEGRADED` — the status code stays Degraded; only the message text changes.

YOUR SPEC (verbatim from docs/bug-hunt/20260507T163535Z3ac5/plan.md):

### Team C: Plugin health honest copy (F4)

**Blocked by:** none — can start immediately.

**Read these files first:**
- `finlet/plugins/news_plugin.py:475-486` — current degraded message "No cached news data files found. Run ingestion first."
- `finlet/plugins/sentiment_plugin.py:461-469` — current degraded message "No cached sentiment data files found. Run ingestion first."
- `finlet/plugins/price_plugin.py:910-918` — parallel "Run ingestion first" message in price plugin — for reference, NOT to be modified
- `finlet/plugins/fundamentals_plugin.py:1064-1071` — parallel message in fundamentals plugin — for reference, NOT to be modified
- `finlet/api/routes_plugins.py:7-18` — confirms `POST /plugins/{name}/ingest` is a STUB
- `tests/plugins/test_news_plugin.py` — existing health test coverage (find current health assertions; new test must assert the new copy). If file does not exist, create it following the pattern of `tests/plugins/test_price_plugin.py`.
- `tests/plugins/test_sentiment_plugin.py` — existing health test coverage. If absent, create following price test pattern.

**Why honest copy, not Ingest button restoration:** The launch cut removed the Ingest button from the production dashboard. Restoring it would also require either (a) wiring to a real ingest pipeline (out of scope for one bug-hunt iteration) or (b) accepting that clicking the button does nothing visible (dead affordance — the bug we're trying to fix). The cleanest fix for this iteration is to update the user-visible message so it doesn't promise an action the user can take.

**Scope decision (do NOT widen):** Only `news_plugin.py` and `sentiment_plugin.py` get updated copy. `price_plugin.py` and `fundamentals_plugin.py` keep their "Run ingestion first" message — those plugins ARE expected to have data on prod (the data lake is populated for them) and a Degraded status there indicates a real ops problem, not a permanent unsupported state.

**Files touched:**
- Modified: `finlet/plugins/news_plugin.py:475-486` — replace the degraded message body. New text: `"News data not yet available. Ingestion infrastructure pending — this plugin will activate once news ingestion is wired."`
- Modified: `finlet/plugins/sentiment_plugin.py:461-469` — replace the degraded message body. New text: `"Sentiment data not yet available. Ingestion infrastructure pending — this plugin will activate once sentiment ingestion is wired."`
- Modified: `tests/plugins/test_news_plugin.py` — update or add a regression test that asserts the new copy text. Pattern: assert `"not yet available" in health.message` AND assert `"Run ingestion" not in health.message`.
- Modified: `tests/plugins/test_sentiment_plugin.py` — same pattern as news.

**Deliverable:** Plugin Health for news and sentiment shows a Degraded badge with a message that does NOT promise a user-actionable fix. The rest of the producer plugins (price, fundamentals) keep their existing "Run ingestion first" message because their Degraded state IS ops-actionable.

**Validation:**
- [ ] `cd /Users/justnau/finlet && uv run pytest tests/plugins/test_news_plugin.py -x -q --timeout=60 -p no:cacheprovider 2>&1 | tail -10` passes with new assertion.
- [ ] `cd /Users/justnau/finlet && uv run pytest tests/plugins/test_sentiment_plugin.py -x -q --timeout=60 -p no:cacheprovider 2>&1 | tail -10` passes with new assertion.
- [ ] `cd /Users/justnau/finlet && uv run pytest tests/plugins/test_price_plugin.py -x -q --timeout=60 -p no:cacheprovider 2>&1 | tail -10` passes UNCHANGED.
- [ ] `rg "Run ingestion first" finlet/plugins/news_plugin.py finlet/plugins/sentiment_plugin.py` returns ZERO matches.
- [ ] `rg "Run ingestion first" finlet/plugins/price_plugin.py finlet/plugins/fundamentals_plugin.py` STILL returns matches (we didn't touch those).
- [ ] `cd /Users/justnau/finlet && uv run pytest tests/ -q --timeout=120 -p no:cacheprovider 2>&1 | tail -10` — full suite still passes.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message starts with "[Team C]:".

When done, report: DONE + commit hash + validation results.
OR: BLOCKED + what went wrong.
