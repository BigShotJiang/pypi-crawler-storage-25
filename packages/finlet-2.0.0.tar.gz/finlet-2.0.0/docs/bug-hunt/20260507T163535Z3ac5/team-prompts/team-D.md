You are Team D: Favicon (F3) for bug-hunt iteration 20260507T163535Z3ac5.

WORKING DIR: this is your isolated git worktree. Pre-flight pinned spawn_base_sha = 571570d4c18f2b6b3d7f28ebbb63a33a0882a20b. Your worktree was reset to that SHA before you started.

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report any test in that file as a regression.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns in those files.
- You MUST `git add` and `git commit` all your changes before finishing (yes, including the binary .ico file).
- Your commit message MUST start with "[Team D]:".
- Run the validation commands from your spec before finishing.
- Do NOT add a route handler to `finlet/api/app.py` — path 1 (static asset) is the chosen approach.
- Do NOT modify any of the existing HTML `<link rel="icon">` tags.
- Do NOT touch any file in `legacy/`.

YOUR SPEC (verbatim from docs/bug-hunt/20260507T163535Z3ac5/plan.md):

### Team D: Favicon (F3)

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/favicon.svg` — existing SVG favicon (referenced from all 8 HTML pages)
- `dashboard/index.html:8-10` — `<link rel="icon" type="image/svg+xml" href="favicon.svg">` pattern
- `finlet/api/app.py:609-612` — current `StaticFiles(directory=str(dashboard_dir), html=True)` mount at `/`; no explicit `/favicon.ico` route exists

**Browsers always request `/favicon.ico` regardless of the `<link rel="icon">` tag** — that's a baked-in browser convention. The `<link>` tag adds an additional fetch but doesn't suppress the legacy `/favicon.ico` request.

**Choose path 1 (static asset)** for simplicity and zero-runtime-cost. Generate an `.ico` from the existing `favicon.svg` (e.g., via `convert` / `rsvg-convert` / online tool); commit the binary.

**Files touched:**
- New: `dashboard/favicon.ico` — 16x16 + 32x32 multi-size .ico generated from `dashboard/favicon.svg`. Binary file; commit as-is.
- Modified: NONE in `finlet/api/app.py` (path 1 chosen — no route needed).

**Deliverable:** `GET /favicon.ico` against `https://finlet.dev` returns 200 + `image/x-icon` (or `image/vnd.microsoft.icon`) instead of 404.

**Validation:**
- [ ] `ls -la dashboard/favicon.ico` shows the file is committed and non-empty (>500 bytes typically for a multi-size .ico).
- [ ] `file dashboard/favicon.ico` reports "MS Windows icon resource" or similar valid .ico format.
- [ ] `cd /Users/justnau/finlet && uv run pytest tests/ -q --timeout=120 -p no:cacheprovider 2>&1 | tail -10` — full suite still passes.

**Agent instructions:**
- You MUST `git add` + `git commit` the binary `.ico` before finishing. Commit message starts with "[Team D]:".
- Generate the `.ico` from `dashboard/favicon.svg` so the visual identity matches.

Tools to try in order (use the first one that works):
1. `which rsvg-convert magick convert imagemagick python3 2>&1` — check what's available
2. If `magick` is available: `magick dashboard/favicon.svg -resize 32x32 -background transparent -define icon:auto-resize=16,32 dashboard/favicon.ico`
3. If `convert` (legacy ImageMagick) is available: `convert -background transparent dashboard/favicon.svg -define icon:auto-resize=16,32 dashboard/favicon.ico`
4. If `rsvg-convert` is available: `rsvg-convert -w 32 -h 32 dashboard/favicon.svg -o /tmp/favicon-32.png && convert /tmp/favicon-32.png dashboard/favicon.ico` (also requires convert)
5. If Python 3 with Pillow available: write a small script using PIL to convert. Pseudocode:
   ```python
   from PIL import Image
   import cairosvg, io
   # Render SVG to 32x32 and 16x16 PNGs, then save as .ico
   png_32 = cairosvg.svg2png(url='dashboard/favicon.svg', output_width=32, output_height=32)
   png_16 = cairosvg.svg2png(url='dashboard/favicon.svg', output_width=16, output_height=16)
   img32 = Image.open(io.BytesIO(png_32))
   img16 = Image.open(io.BytesIO(png_16))
   img32.save('dashboard/favicon.ico', format='ICO', sizes=[(32, 32), (16, 16)])
   ```
6. LAST RESORT: if NO conversion tool works, write a 16x16 single-color blue PNG (matching the SVG's primary color), wrap it in a minimal .ico header, and commit it. The .ico must be a valid binary .ico file or browsers will treat it as a 404.

If you cannot produce a valid `.ico` after trying all 6 paths, report BLOCKED with the exact error from each attempt. Do NOT commit a placeholder text file.

When done, report: DONE + commit hash + validation results + tool used to generate the .ico.
OR: BLOCKED + what went wrong.
