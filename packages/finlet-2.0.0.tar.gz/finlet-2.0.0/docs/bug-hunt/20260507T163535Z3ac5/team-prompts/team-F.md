You are Team F: Docs sync (Required Docs Updates block) for bug-hunt iteration 20260507T163535Z3ac5.

WORKING DIR: /Users/justnau/finlet (no worktree — Team F runs directly on main; doc updates don't need isolation).

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report any test in that file as a regression.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message MUST start with "[Team F]:" and reference iteration 20260507T163535Z3ac5.
- The 5 ledger entries MUST cite REAL merge SHAs from `git log --oneline main` — DO NOT invent SHAs.
- Each lesson in LESSONS.md MUST be a reusable rule, not a recap of the diff. If you can't write a generalizable lesson for a finding, omit that finding from LESSONS.md and note "no general lesson" in the commit message.
- Do NOT touch ARCHITECTURE.md this iteration. The known drift at lines 225-232 and 1054-1056 is logged in plan.md "Pending Investigations" — it's a separate cleanup task.
- Do NOT touch any file in `legacy/`.

TEAM MERGE SHAs (use these in ledger entries — these are the merge commits on main):
- Team A: 267a793 → fixed F1 (finlet auth register) + F5 (setup.html post-signup key reveal)
- Team B: 9d68d35 → fixed F6 (session modal default-empty name)
- Team C: 38b41d7 → fixed F4 (plugin honest copy for news + sentiment)
- Team D: 05430f2 → fixed F3 (favicon.ico static asset)

YOUR TASKS:

1. **`docs/REMAINING_TASKS.md`** — read existing, then add a new subsection "Bug Hunt 20260507T163535Z3ac5 — Closed" enumerating the 5 fixes, mirroring prior iteration patterns (look at the most recent "Bug Hunt YYYYMMDD..." entry for format reference).

2. **`docs/LESSONS.md`** — append at least one lesson per finding that exposed a class of mistake. Specific lessons to write (paraphrase as needed for naturalness):
   - **finlet auth register stale across 4 surfaces.** When a CLI command is renamed, grep ALL of `dashboard/`, `docs/`, `tests/` for the old command string. The bug was in 4 separate dashboard files; a search-replace check would have caught all 4.
   - **Recon disagreement with blind framing → demote.** On F6 (session modal), both Claude and Codex recon rejected the blind agent's "active-session state" framing and identified hardcoded template default. The triage classification (`dashboard-state-sync`) was wrong; the actual fix lives in the modal's default-select policy. Triage categories should be reviewed by recon before they enter the ledger.
   - **Plugin Ingest button cut without backend retraction (F4).** When cutting a UI affordance (the Ingest button removed in the 2026-05-06 launch cut), audit producer-side strings that assumed it existed. The news/sentiment plugin probe still emitted "Run ingestion first" as if a UI affordance was available — leaving users with no actionable path.
   - **PF-19 caught a pinned-bad-behavior test (F6).** Codex recon caught `tests/e2e/journey-04-dashboard.spec.ts:277-299` pinning the bad behavior; Claude recon missed it. Without union-recon, Team B's fix would have shipped against a passing local test that fails on the next prod run. Single-source recon misses pinned-bad-behavior tests by construction.
   - **Browser /favicon.ico request is independent of `<link rel="icon">` (F3).** Browsers request `/favicon.ico` regardless of the HTML `<link>` tag. SVG `<link rel="icon" type="image/svg+xml">` does NOT suppress the legacy .ico request. Always ship a literal `favicon.ico` (or a route redirect) alongside the SVG.

3. **`docs/KNOWN_FAILURES.md`** — pre-flight already updated this in commit `571570d` (banner-only refresh). Verify content is current; no further changes expected this iteration. Note in your commit message: "KNOWN_FAILURES.md: no new failures resolved or added beyond pre-flight banner refresh."

4. **`docs/decisions/`** — add ONE 1-page decision record this iteration. The "honest copy over Ingest-button restoration" choice on F4 is the right candidate. Filename: `docs/decisions/plugin-honest-copy-over-ingest-restore.md`. Include: context (launch cut removed Ingest UI), decision (update producer-side message), alternatives (restore Ingest, hide row), consequences (users see honest "not yet available" instead of dead-affordance "Run ingestion first"), reversibility (high — message text only). Reference iteration 20260507T163535Z3ac5 + Team C commit `38b41d7`.

5. **`docs/bug-hunt/ledger.jsonl`** — append exactly 5 JSON lines (one per closed finding: F1, F3, F4, F5, F6). Schema:
   ```json
   {"iteration_ts":"20260507T163535Z3ac5","finding_id":"<slug>","category":"<tag>","summary":"<short>","scope_files":["..."],"team":"A|B|C|D","commit":"<merge-sha-on-main>"}
   ```
   Use the team merge SHAs above. Reuse existing categories from prior ledger entries:
   - F1 + F5: category `ui-removal-launch-cut` (per triage), team `A`, commit `267a793`. Two SEPARATE ledger entries (F1 and F5 are distinct findings):
     - F1 finding_id: `api-keys-doc-finlet-auth-register-stale`
     - F5 finding_id: `setup-html-api-key-reveal-never-fires`
   - F4: category `dead-affordance`, team `C`, commit `38b41d7`, finding_id: `plugin-permanent-degraded-news-sentiment`
   - F3: category `dead-affordance`, team `D`, commit `05430f2`, finding_id: `favicon-404-every-page`
   - F6: category `dashboard-state-sync` (note: triage said this; both recons disagreed but the user-visible class is a state-sync-adjacent default-prefill issue, so reusing the existing tag), team `B`, commit `9d68d35`, finding_id: `session-creation-modal-prefill-stale-name`

   Total: 5 lines (F1, F3, F4, F5, F6).

   Validation: after append, `wc -l docs/bug-hunt/ledger.jsonl` should grow by exactly 5 vs the pre-iter count.

6. **Stage all artifacts** in `docs/bug-hunt/20260507T163535Z3ac5/`:
   - `triage.md`, `triage.json`, `blind_report.json`, `blind_report_raw.json`, `cleanup.log`
   - `isolation_warning.txt`, `claude_recon.md`, `codex_recon.md`, `codex_recon_prompt.txt`, `codex_recon.stdout.log`
   - `blind_launcher.stdout.log`, `blind_launcher.stderr.log`
   - `plan.md`
   - `team-prompts/team-A.md`, `team-prompts/team-B.md`, `team-prompts/team-C.md`, `team-prompts/team-D.md`, `team-prompts/team-F.md`
   - `exec-trace.txt`
   No artifact left untracked. Do NOT include screenshot .png files at repo root (those are eval/screenshot artifacts handled separately).

**One commit, mention iteration in message:**
```
[Team F]: docs sync — bug-hunt 20260507T163535Z3ac5 — REMAINING_TASKS +5 closed; LESSONS +5; ledger +5; decisions/plugin-honest-copy-over-ingest-restore.md; ARCHITECTURE.md unchanged this iter; KNOWN_FAILURES.md banner-only

Closes F1 (267a793), F3 (05430f2), F4 (38b41d7), F5 (267a793), F6 (9d68d35) from docs/bug-hunt/20260507T163535Z3ac5/triage.md.
F2 demoted to needs-investigation per PF-19 rule 3 (see plan.md Pending Investigations).
```

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` grew by EXACTLY 5 vs pre-iter count.
- [ ] `jq -s '. | map(select(.iteration_ts == "20260507T163535Z3ac5")) | length' docs/bug-hunt/ledger.jsonl` returns `5`.
- [ ] `git -C /Users/justnau/finlet status docs/bug-hunt/20260507T163535Z3ac5/` returns "clean working tree".
- [ ] `git -C /Users/justnau/finlet log --oneline -1` shows your commit.
- [ ] `cd /Users/justnau/finlet && uv run pytest tests/ -q --timeout=120 -p no:cacheprovider 2>&1 | tail -5` — full suite still passes (no regression — docs commits should not affect tests).

When done, report: DONE + commit hash + summary of which docs were touched.
OR: BLOCKED + what went wrong.
