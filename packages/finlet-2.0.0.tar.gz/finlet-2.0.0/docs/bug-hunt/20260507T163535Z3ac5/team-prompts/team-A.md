You are Team A: Dashboard copy fixes (F1 + F5) for bug-hunt iteration 20260507T163535Z3ac5.

WORKING DIR: this is your isolated git worktree. Pre-flight pinned spawn_base_sha = 571570d4c18f2b6b3d7f28ebbb63a33a0882a20b. Your worktree was reset to that SHA before you started.

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report any test in that file as a regression.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns in those files.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message MUST start with "[Team A]:".
- Run the validation commands from your spec before finishing.
- If validation fails, fix the issue and re-commit.
- Do NOT touch any file in `legacy/` (pre-commit hook will block).
- Do NOT modify `dashboard/auth.html` or `dashboard/auth.js` — those are correct as-is per recon.

YOUR SPEC (verbatim from docs/bug-hunt/20260507T163535Z3ac5/plan.md):

### Team A: Dashboard copy fixes (F1 + F5)

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/api-keys.html:39-43` — current page-subtitle string referencing `finlet auth register`
- `dashboard/api-keys.js:52-60` — empty-state copy referencing `finlet auth register`
- `dashboard/agent-guide.html:53-65` — copy-button + `<pre>` block both referencing `finlet auth register`
- `dashboard/index.html:84-88` — first-run-step banner referencing `finlet auth register`
- `dashboard/setup.html:124-149` — Step 2 "Create your account" with `auth.html` link claiming "API key on the confirmation screen"
- `finlet/cli.py:447-462` — actual `register` command (NO `auth` Typer group exists)
- `dashboard/auth.html:205-214` — auth-success markup; confirms there is NO post-signup API-key reveal flow
- `dashboard/auth.js:831-852` — signup flow saves `apiKey` to `/auth/session` cookie but NEVER displays it to the user

**Files touched:**
- Modified: `dashboard/api-keys.html` — replace `finlet auth register` with `finlet register` in line 42 page-subtitle
- Modified: `dashboard/api-keys.js` — replace `finlet auth register` with `finlet register` in line 59 empty-state-desc
- Modified: `dashboard/agent-guide.html` — replace `finlet auth register` with `finlet register` in line 60 `data-copy=` attribute AND in line 65 `<pre><code>` block (TWO occurrences in this file)
- Modified: `dashboard/index.html` — replace `finlet auth register` with `finlet register` in line 86 first-run-step `<code>` block
- Modified: `dashboard/setup.html` — rewrite the website-signup paragraph (lines 127-129) to match actual flow. Replacement copy: "Register a free account — no credit card required. The fastest way is to [sign up through the website](auth.html). Once signed in, create an API key from the dashboard or use the REST API below to register and receive your key in one step." (do NOT promise a confirmation-screen reveal that doesn't exist)

**Deliverable:** Five surfaces in `dashboard/` no longer document non-existent `finlet auth register`; setup.html no longer promises a non-existent post-signup key reveal.

**Validation:**
- [ ] `rg "finlet auth register" -- dashboard/` returns ZERO matches.
- [ ] `rg "confirmation screen" -- dashboard/` returns ZERO matches OR only matches that have been rewritten to remove the false promise.
- [ ] `rg "finlet register" -- dashboard/` returns matches in api-keys.html, api-keys.js, agent-guide.html (×2), index.html.
- [ ] `cd /Users/justnau/finlet && uv run pytest tests/ -q --timeout=120 -p no:cacheprovider 2>&1 | tail -10` — full suite still passes (no regression).
- [ ] Manual: cat each of the 4 modified dashboard pages, confirm `finlet register` (no `auth`) is rendered.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message starts with "[Team A]:".
- The fix is mechanical string replacement plus one paragraph rewrite. Do NOT invent new copy beyond what's specified.
- For `setup.html`, preserve the existing `<details>` REST-API alternative block (lines 144-149) verbatim — it's correct.

When done, report: DONE + commit hash + validation results.
OR: BLOCKED + what went wrong.
