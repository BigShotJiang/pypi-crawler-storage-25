## Broken (will be fixed this iteration)

- API Keys page documents non-existent CLI command `finlet auth register` [evidence: "Page body reads: 'Use the CLI (finlet auth register) to create new keys.' Running `finlet auth --help` exits with: 'No such command auth.' The correct command is `finlet register`. A new user who copies this command gets an immediate error."] [scope hint: dashboard/api-keys.html, dashboard/setup.html]
- `finlet plugins add` is local-only and has no effect on the hosted server — fundamentals strategy cannot be fully set up via CLI for finlet.dev [evidence: "Running `finlet plugins add edgar --email jgn0017@auburn.edu` and `finlet plugins add finnhub --api-key <key>` both respond 'Plugin configured. Restart server to apply.' Config is written to a local ~/.finlet/plugins.json. After running both commands, the Plugin Health dashboard still shows: finnhub → 'Error: finnhub plugin not initialized.' and edgar → 'Error: edgar plugin not initialized.' The hosted server never sees the local config."] [scope hint: finlet/cli.py, dashboard/api-keys.html, dashboard/setup.html, finlet/api/routes_plugins.py]
- favicon.ico missing — 404 on every page load [evidence: "Console error logged on every page: 'Failed to load resource: the server responded with a status of 404 () @ https://finlet.dev/favicon.ico'. Minor but persistent noise in every console log."] [scope hint: dashboard/favicon.ico, finlet/api/static_routes.py, deploy/]
- news_s3 and sentiment plugins permanently Degraded with no actionable path to fix [evidence: "Plugin Health panel shows news_s3 → 'Degraded: No cached news data files found. Run ingestion first.' and sentiment → 'Degraded: No cached sentiment data files found. Run ingestion first.' There is no 'Run ingestion' button, no ingestion documentation linked from the dashboard, and no ingestion page on the site. A fresh user sees two persistent orange warnings with no way to resolve them."] [scope hint: dashboard/index.html, dashboard/app.js, finlet/api/routes_plugins.py]
- setup.html documents an API-key reveal on confirmation screen that never fires [evidence: "The setup.html suggests the website gives an API key 'on the confirmation screen' after signup but this did not happen during evaluation — no key was shown post-login."] [scope hint: dashboard/setup.html, dashboard/auth.html, finlet/auth/]
- Session creation modal pre-fills name with the current active session's template name, causing likely duplicate names [evidence: "When clicking 'New session', the modal's Session Name field is pre-populated with 'Conservative ETF' — the name of the currently active session. A user clicking through without noticing will create a second session named 'Conservative ETF', making the session dropdown ambiguous."] [scope hint: dashboard/app.js, dashboard/index.html]

## Logged (not actioned)

- settings.html returns 404 — no web settings page exists at all [classification: working-as-designed]
- plugins.html returns 404 — no plugin management page exists [classification: working-as-designed]
- GET /v1/plugins and GET /v1/sessions/{id}/plugins both return 404 — dashboard plugin health data source is unclear [classification: working-as-designed]
- No way to create API keys from the web UI — forced CLI installation to get started [classification: nice-to-have]
- 'Restart server to apply' message in CLI is meaningless for a hosted SaaS product [classification: annoying]
- Plugin Health errors are displayed but completely non-actionable from the web UI — dead end for users [classification: annoying]
- Win Rate metric displays '0 closed · 1 filled' — 'filled' is non-standard and confusing alongside 'closed' [classification: annoying]
- Primary navigation lacks a Settings link — settings features (API keys) are buried and hard to discover [classification: annoying]
- Web UI for plugin management — no way to install/configure third-party data plugins (finnhub, fred, edgar) without the CLI [classification: nice-to-have]
- First-run onboarding wizard — no guidance after login on what to do next [classification: nice-to-have]
- Ingestion trigger UI for news and sentiment plugins — 'Run ingestion first' message has no action [classification: nice-to-have]
- API key copy button or one-time reveal on creation — currently impossible to retrieve a key's full value post-creation [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260507T163535Z3ac5 — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. `docs/bug-hunt/20260507T163535Z3ac5/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log,
   deploy_status.txt, retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E (or designated docs team) MUST append exactly
   one JSON line per real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260507T163535Z3ac5","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after the docs team commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline (see
   bug-hunt Phase 5.5c). Docs team MUST stage the file. If a refactor verdict pruned
   entries this iteration, the docs team MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`
   (the audit log of resolved signals).

Docs team's commit message must reference iteration 20260507T163535Z3ac5 and name which docs were
touched (e.g., "docs: bug-hunt 20260507T163535Z3ac5 — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
