# Independent Recon: 6 Real-Broken Findings (Claude Explore)
**Baseline HEAD:** 23505f49b90c873677a6b5c4b7c22cf86d1bfd32

---

## Finding 1 — api-keys-doc-finlet-auth-register-stale

**Independent recon (Claude Explore against HEAD 23505f49b90c873677a6b5c4b7c22cf86d1bfd32):**

Grepped for `finlet auth register` and `finlet auth` across all surfaces:

```html finlet/dashboard/api-keys.html:42
<p class="page-subtitle">Read-only listing of API keys for your Finlet account. Use the CLI (<code>finlet auth register</code>) to create new keys. See <a href="agent-guide.html">the agent guide</a> for usage.</p>
```

```javascript finlet/dashboard/api-keys.js:59
<div class="api-key-empty-desc">Use the CLI to create an API key: <code>finlet auth register</code>.</div>
```

```html finlet/dashboard/agent-guide.html:59-64
<button class="btn-copy" type="button" aria-label="Copy command to clipboard" data-copy="finlet auth register">
    <svg>...</svg>
    Copy
</button>
...
<pre><code class="lang-bash">finlet auth register</code></pre>
```

```html finlet/dashboard/index.html:86
<code>finlet auth register</code>
```

CLI evidence shows the actual command is `finlet register` (no `auth` subcommand):
```python finlet/finlet/cli.py:447-451
@app.command()
def register(
    email: str = typer.Option(..., "--email", "-e", help="Email address for registration"),
) -> None:
    """Register a new account and receive an API key."""
```

No `auth` command or subcommand exists in cli.py. The typer app only has:
- `app.add_typer(session_app, name="session")`
- `app.add_typer(plugins_app, name="plugins")`
- Standalone commands: `serve`, `register`, `advance`, `order`, `portfolio`, `status`, `mcp`

**Conclusion:** The stale command `finlet auth register` appears in **4 surfaces**: api-keys.html, api-keys.js, agent-guide.html, and index.html. All 4 must change to `finlet register` (no `auth` prefix). The correct command exists only in cli.py and setup.html. Parallel surfaces: setup.html documents the correct path at lines 128-149 (uses REST API, mentions "sign up through the website" + API key on confirmation screen).

**Disagreement risk:** scope-only. The fix is straightforward: replace all instances of the wrong command string in the 4 dashboard files and any related help strings.

---

## Finding 2 — cli-plugins-add-local-only-no-server-effect

**Independent recon:**

Verified the plugins_add command at finlet/finlet/cli.py:306-369:

```python finlet/finlet/cli.py:338-345
resp = httpx.put(
    f"{_API_URL}/v1/settings/plugins",
    json=body,
    headers=_api_headers(finlet_key),
    timeout=30,
)
resp.raise_for_status()
data = resp.json()
```

The CLI **does** make a server call to `PUT /v1/settings/plugins` (not local). The docstring at lines 312-323 explicitly states:
```python
"""Configure a plugin with API key or settings.

Writes the plugin config via the canonical, authenticated server
endpoint ``PUT /v1/settings/plugins`` — the same path the dashboard
settings page uses. The server hot-reloads the plugin in place and
returns the post-reload health status...
"""
```

The old behavior (local-only write + "Restart server to apply" message) **no longer exists** in this codebase. The code has been refactored to make the server call.

However, dashboard surfaces still document the **old broken behavior**:

```html finlet/dashboard/api-keys.html:42
Use the CLI (<code>finlet auth register</code>) to create new keys.
```

And setup.html at line 128-129:
```html finlet/dashboard/setup.html:127-129
Register a free account — no credit card required. The fastest way is to <a href="auth.html">sign up through the website</a>, which gives you an API key on the confirmation screen.
```

The dashboard docs don't mention `finlet plugins add` at all (no docs for plugin configuration from CLI). The triage evidence says users who run `finlet plugins add` locally see "Plugin configured. Restart server to apply" — but that message is NOT in the current cli.py code (lines 364-368 show it prints the actual post-reload status instead).

**Conclusion:** The CLI code has been **fixed** — it now POSTs to the server and prints real status. However:
- Dashboard/setup.html docs do **not** describe how users can configure plugins via the CLI for finlet.dev (no affordance exists)
- The triage evidence captured stale behavior that is no longer in HEAD
- Root cause: The CLI fix has shipped, but docs haven't been updated to explain the new server-side plugin configuration path.

**Disagreement risk:** root-cause. The code shows this was already refactored. The real issue is **docs/affordance surfaces** need to be updated to document the working path (`finlet plugins add finlet.dev --api-key ...` + server-side reload), not a code fix.

---

## Finding 3 — favicon-404-every-page

**Independent recon:**

Searched for favicon in dashboard:

```bash
find /Users/justnau/finlet/dashboard -name "favicon.*"
/Users/justnau/finlet/dashboard/favicon.svg
```

The file **exists** at `/Users/justnau/finlet/dashboard/favicon.svg`.

Every HTML page references it:

```html finlet/dashboard/api-keys.html:9
<link rel="icon" type="image/svg+xml" href="favicon.svg">
```

Same pattern in: auth.html, setup.html, verify.html, landing.html, leaderboard.html, agent-guide.html, index.html.

The href is **relative path `favicon.svg`** (not `/favicon.ico` or `/favicon.svg`). When serving from nested routes like `/api-keys.html`, the relative path resolves to the same directory (correct for static files served from dashboard/ root).

No static route handler found in finlet/api/ for serving `/favicon.ico` or favicon. Searched: `rg "favicon\|static" /Users/justnau/finlet/finlet/api/*.py` — zero matches.

**Conclusion:** The file exists at the correct path (dashboard/favicon.svg) and is referenced correctly in all HTML pages. The 404 error for `/favicon.ico` (not `.svg`) suggests:
1. **Root cause A (most likely):** Browsers request `/favicon.ico` by default (standard favicon location), but the pages only provide `favicon.svg`. The `.svg` reference works, but legacy browser auto-requests for `.ico` fail.
2. **Root cause B:** FastAPI static mount for /dashboard/ does not serve SVG files or has incorrect MIME type configuration.

The surgery surface is: either (a) add a `/favicon.ico` file, (b) set a `<link>` with absolute href `/favicon.svg` and ensure it's served at the root, or (c) add a FastAPI route to redirect/serve `/favicon.ico` from `favicon.svg`.

**Disagreement risk:** scope-only. The file exists; the issue is routing/browser expectations, not a missing file.

---

## Finding 4 — plugin-permanent-degraded-news-sentiment

**Independent recon:**

Found the "Run ingestion first" messages in plugin code:

```python finlet/finlet/plugins/news_plugin.py:482
message="No cached news data files found. Run ingestion first.",
```

```python finlet/finlet/plugins/sentiment_plugin.py:467
message="No cached sentiment data files found. Run ingestion first.",
```

Dashboard health panel renders these messages. No search found an "Ingest" button or link in dashboard/index.html or app.js.

**Conclusion:** The two plugins report a degraded state with "Run ingestion first" message. The dashboard displays this message **without any affordance** (no button, no link, no docs). The fix surface includes:
1. finlet/plugins/news_plugin.py and sentiment_plugin.py — the health probe message
2. dashboard/index.html — plugin health card rendering
3. dashboard/app.js — health status display logic
4. (Optional) finlet/api/routes_plugins.py — if an ingest endpoint exists (per triage hint at line 10: "Ingest button calls when the plugin reports a 'Run ingestion first'")

The user-visible message is actionable only if:
- An `POST /v1/plugins/{name}/ingest` endpoint exists and the UI calls it, OR
- The message is updated to be honest ("not yet supported") OR
- A help link is added

**Disagreement risk:** scope-only. The fix is surface-level message + optional UI affordance, contingent on backend capability.

---

## Finding 5 — setup-html-api-key-reveal-never-fires

**Independent recon:**

setup.html line 128-129:
```html finlet/dashboard/setup.html:128-129
Register a free account — no credit card required. The fastest way is to <a href="auth.html">sign up through the website</a>, which gives you an API key on the confirmation screen.
```

This claims an API key is revealed "on the confirmation screen" post-signup.

Verified: there is no API key reveal flow documented or implemented in the codebase. The auth.html is the signup flow, but no post-signup confirmation screen with key reveal is visible.

The blind report triage evidence (item 118-122) confirms: "A new user who signs up via the website has no API key until they install a CLI. The setup.html suggests the website gives an API key 'on the confirmation screen' after signup but this did not happen during evaluation — no key was shown post-login."

**Conclusion:** setup.html line 128-129 **falsely documents a feature that does not exist**. Either:
1. The post-signup confirmation screen should reveal an API key (feature not implemented), OR
2. setup.html line 128-129 must be reworded to reflect the actual flow (no in-UI key reveal; must use CLI)

Surgery surfaces: finlet/dashboard/setup.html (line 128-129) and finlet/dashboard/auth.html (the signup flow implementation, verify it does NOT generate or display a key).

**Disagreement risk:** scope-only. The fix is either implement the promised feature or update the docs.

---

## Finding 6 — session-creation-modal-prefill-stale-name

**Independent recon:**

app.js lines 847-926 define the session creation modal logic:

```javascript finlet/dashboard/app.js:847-851
const SESSION_TEMPLATES = {
    conservative: { name: 'Conservative ETF', tickers: ['SPY', 'BND', 'GLD'] },
    tech: { name: 'Tech Growth', tickers: ['AAPL', 'GOOGL', 'MSFT', 'NVDA', 'META'] },
    custom: { name: 'Custom', tickers: [] },
};
```

```javascript finlet/dashboard/app.js:937-938
selectTemplate('conservative');
```

When `openCreateSessionModal()` is called (line 929), it resets the form and calls `selectTemplate('conservative')` (line 938).

`selectTemplate()` (lines 901-926) syncs the name field:

```javascript finlet/dashboard/app.js:921-926
const nameInput = document.getElementById('session-name');
if (nameInput) {
    nameInput.value = templateKey === 'custom'
        ? ''
        : SESSION_TEMPLATES[templateKey]?.name || '';
}
```

**The modal always resets to 'Conservative ETF'** when opened, regardless of the currently active session. This is **correct behavior** — the modal resets on every open, so the name field is empty or defaulted, not stale.

However, the triage evidence (lines 148-149) states: "When clicking 'New session', the modal's Session Name field is pre-populated with 'Conservative ETF' — the name of the currently active session."

The code shows the modal is reset and the conservative template is selected, which pre-fills the name with "Conservative ETF". **This is by design**, not a bug — the modal always defaults to the conservative template, so the name field will always show "Conservative ETF" until the user either (a) selects a different template or (b) types a custom name.

The issue is **user expectation**: A new user might not realize they need to type a different name before clicking Create. The name field should be **cleared** (empty) on modal open, or it should have a **placeholder** like "e.g., My First Sim" to signal that it's editable and should be customized.

**Conclusion:** The modal does pre-fill with "Conservative ETF" (by design, not a bug). The fix surfaces are:
1. finlet/dashboard/app.js line 923-926 — clear the name input when opening the modal (set to empty string) OR
2. finlet/dashboard/index.html — add a `placeholder` attribute to the session-name input to clarify it's editable

The current behavior is borderline — it's not wrong, but it's not obvious to users that they need to customize the name.

**Disagreement risk:** scope-only. The fix is a one-line UI tweak (clear field or add placeholder).

---

## Summary: Surgery Surfaces

| Finding | Files to Change | Parallel Surfaces |
|---------|-----------------|-------------------|
| 1. finlet auth register | api-keys.html, api-keys.js, agent-guide.html, index.html | setup.html (already correct) |
| 2. plugins-add-server-effect | finlet/cli.py (no change — already fixed); docs need update | dashboard/setup.html (no affordance for plugin config) |
| 3. favicon-404 | finlet/dashboard/favicon.svg (exists); FastAPI static route or browser redirect needed | All HTML pages reference favicon.svg correctly |
| 4. plugin-degraded-no-affordance | finlet/plugins/{news,sentiment}_plugin.py; dashboard/index.html; dashboard/app.js | finlet/api/routes_plugins.py (ingest endpoint location) |
| 5. api-key-reveal-stale | finlet/dashboard/setup.html:128-129; finlet/dashboard/auth.html (verify no key flow) | None |
| 6. session-name-prefill | finlet/dashboard/app.js:923-926 (clear field) or finlet/dashboard/index.html (placeholder) | None |

