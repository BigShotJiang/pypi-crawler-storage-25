### Finding 1 — api-keys-stale-finlet-auth-register

**Independent recon (Codex gpt-5.5 xhigh against HEAD 23505f49b90c873677a6b5c4b7c22cf86d1bfd32):**

```html dashboard/index.html:84-88
                <li class="first-run-step">
                    <span class="first-run-step-num" aria-hidden="true">2</span>
                    <code>finlet auth register</code>
                    <span class="first-run-step-desc">Create your <abbr title="Application Programming Interface">API</abbr> key</span>
                </li>
```

```html dashboard/agent-guide.html:53-65
            <div class="guide-content">
                <p class="guide-text">Run the following command to register and receive your API key:</p>

                <div class="code-block">
                    <div class="code-block-header">
                        <span class="code-block-lang">Terminal</span>
                        <button class="btn-copy" type="button" aria-label="Copy command to clipboard" data-copy="finlet auth register">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"></path></svg>
                            Copy
                        </button>
                    </div>
                    <pre><code class="lang-bash">finlet auth register</code></pre>
                </div>
```

```html dashboard/api-keys.html:39-43
            <div class="page-header">
                <div>
                    <h1 class="page-title">API Keys</h1>
                    <p class="page-subtitle">Read-only listing of API keys for your Finlet account. Use the CLI (<code>finlet auth register</code>) to create new keys. See <a href="agent-guide.html">the agent guide</a> for usage.</p>
                </div>
```

```js dashboard/api-keys.js:52-60
    const data = await apiFetch('/settings/api-keys');

    if (!data || !data.keys || data.keys.length === 0) {
        container.innerHTML = trustedHTML(`
            <div class="api-key-empty">
                <div class="api-key-empty-icon">&#128273;</div>
                <div class="api-key-empty-title">No API keys yet</div>
                <div class="api-key-empty-desc">Use the CLI to create an API key: <code>finlet auth register</code>.</div>
```

```python finlet/cli.py:40-43
session_app = typer.Typer(help="Session management")
plugins_app = typer.Typer(help="Plugin management")
app.add_typer(session_app, name="session")
app.add_typer(plugins_app, name="plugins")
```

```python finlet/cli.py:447-462
@app.command()
def register(
    email: str = typer.Option(..., "--email", "-e", help="Email address for registration"),
) -> None:
    """Register a new account and receive an API key."""
    import httpx

    body = {"email": email}

    try:
        resp = httpx.post(f"{_API_URL}/auth/register", json=body, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        api_key = data.get("api_key", "")
        typer.echo("Registration successful!")
        typer.echo(f"  API Key: {api_key}")
```

**Conclusion:** The bug is stale dashboard copy, not CLI implementation. `finlet/cli.py` registers root command `finlet register`; there is no `auth` Typer group and grep found no `finlet/auth register` producer in `finlet/`. Complete production surgery surface is `dashboard/index.html`, `dashboard/agent-guide.html`, `dashboard/api-keys.html`, and `dashboard/api-keys.js`. `scope_hint` only named API keys/setup; it misses the first-run banner and agent guide copy/copy-button. No setup.html hit for the exact `finlet auth register` string.

**Disagreement risk:** scope-only.

### Finding 2 — plugins-add-hosted-config-propagation

**Independent recon (Codex gpt-5.5 xhigh against HEAD 23505f49b90c873677a6b5c4b7c22cf86d1bfd32):**

```python finlet/cli.py:306-323
@plugins_app.command("add")
def plugins_add(
    name: str = typer.Argument(..., help="Plugin name (e.g. 'finnhub', 'fred')"),
    api_key: str | None = typer.Option(None, "--api-key", "-k", help="API key for the plugin"),
    email: str | None = typer.Option(None, "--email", "-e", help="Email (for EDGAR User-Agent)"),
) -> None:
    """Configure a plugin with API key or settings.

    Writes the plugin config via the canonical, authenticated server
    endpoint ``PUT /v1/settings/plugins`` — the same path the dashboard
    settings page uses. The server hot-reloads the plugin in place and
    returns the post-reload health status, which the CLI prints so the
    caller knows whether their config was accepted (e.g. EDGAR reports
    ``unhealthy`` if no email / identity was supplied).

    Authentication uses ``FINLET_API_KEY`` from the environment (a
    Finlet account API key, NOT a third-party plugin key). The CLI no
    longer writes a local ``~/.finlet/plugins.json``.
```

```python finlet/cli.py:338-368
    try:
        resp = httpx.put(
            f"{_API_URL}/v1/settings/plugins",
            json=body,
            headers=_api_headers(finlet_key),
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
    except httpx.ConnectError:
        typer.echo(
            "Error: Cannot connect to Finlet server. Run 'finlet serve' first or "
            "set FINLET_API_URL to a reachable host.",
            err=True,
        )
        raise typer.Exit(1)
    except httpx.HTTPStatusError as e:
        if e.response.status_code in (401, 403):
            typer.echo(_AUTH_REJECTED_MESSAGE, err=True)
            raise typer.Exit(1)
        _print_error(e)
        raise typer.Exit(1)
    except httpx.HTTPError as e:
        typer.echo(f"Error: Could not write plugin config: {e}", err=True)
        raise typer.Exit(1)

    health = data.get("health") or {}
    status = health.get("status") or data.get("status", "unknown")
    message = health.get("message") or data.get("message") or ""
    suffix = f" — {message}" if message else ""
    typer.echo(f"Plugin '{name}' status: {status}{suffix}")
```

```python tests/test_cli.py:741-749
class TestPluginsAddCommand:
    """Verify `finlet plugins add` writes config via the canonical authenticated
    server path (PUT /v1/settings/plugins) and surfaces post-reload health.

    Regression coverage for bug-hunt 20260501T172055Z127b Finding 2: the
    old CLI told the user to "Restart server to apply" and additionally
    bypassed the dashboard's authenticated config write path by writing
    a local ``~/.finlet/plugins.json`` and poking ``POST /v1/plugins/{name}/reload``.
```

```python tests/test_cli.py:788-808
        out = _strip_ansi(result.output)
        # Bug regression: must NOT instruct the user to restart.
        assert "Restart server" not in out, (
            f"plugins add still tells user to restart: {out!r}"
        )
        # Must surface the LIVE status from the post-reload health probe.
        assert "edgar" in out
        assert "healthy" in out
        assert "OK" in out

        # Verify the CLI hit the canonical settings endpoint.
        called_url = mock_put.call_args[0][0]
        assert called_url.endswith("/v1/settings/plugins"), called_url

        # Body payload must carry the canonical PluginConfigUpdate fields.
        body = mock_put.call_args.kwargs.get("json") or {}
        assert body.get("plugin") == "edgar"
        assert body.get("email") == "x@y.com"
        assert body.get("enabled") is True

        # Auth header must use the env-var FINLET_API_KEY as a Bearer token.
```

```python tests/test_cli.py:807-808
        # No local file must be written (CLI dropped the legacy plugins.json).
        assert not (tmp_path / "plugins.json").exists()
```

```md docs/ARCHITECTURE.md:225-232
**Per-plugin hot-reload (`PluginRegistry.reload(name, config)` + `POST /v1/plugins/{name}/reload`).** Shipped 2026-05-01 (commit `1a07a1e`, bug-hunt `20260501T172055Z127b` Team A) so `finlet plugins add <name>` no longer needs a server restart on hosted finlet.dev. `PluginRegistry.reload(name, config)` in `finlet/plugins/base.py` re-runs `initialize()` on the existing plugin instance (in-place mutation; the dict slot at `_all_plugins[name]` is never swapped, so concurrent readers either see the pre-reload or post-reload state — never a half-built object), resets the per-plugin circuit breakers (so old failures from the pre-reload config don't keep the breaker open), and serialises concurrent reload calls via a new `asyncio.Lock` (`_reload_lock`). Concurrent readers (`health_check_all`, `query_plugin*`, dashboard's 2s poll) intentionally do NOT take the lock — the same pattern used at startup (`initialize_all`, where the `is_ready` gate exists for global startup readiness; per-plugin reloads do not need that gate because the plugin is already registered). `POST /v1/plugins/{name}/reload` in `finlet/api/routes_health.py` re-reads `~/.finlet/plugins.json`, calls `registry.reload(name, plugin_cfg)`, runs a single `health_check()`, and returns the post-reload `PluginHealthItem`. Returns `404` for unknown plugin names; reload-failure surfaces as `200 + status="unhealthy"` (more actionable than `500` — the CLI can render the live error reason instead of a generic "internal server error"). The CLI's `plugins_add` command (in `finlet/cli.py`) writes the config to `~/.finlet/plugins.json`, POSTs the reload endpoint, and prints the live status from the response — replacing the previous "Plugin '<name>' configured. Restart server to apply." message that was impossible to act on against hosted finlet.dev. See `tests/api/test_plugin_health.py::TestPluginReload` (3 reload-endpoint tests) and `tests/test_cli.py::TestPluginsAddCommand` (4 CLI tests) for the coverage.

#### Plugin config write paths

Two endpoints write plugin state, with a strict role split:

- **`PUT /v1/settings/plugins`** — *canonical write path* for application code (dashboard settings page, CLI `finlet plugins add`, third-party API clients). It owns the per-user config store (`_user_plugin_config` in `finlet/api/services/settings_service.py`), persists the new credentials, and on a credential-bearing change (`api_key` or `email`) calls `await registry.reload(plugin, config)` followed by `await registry.health_check_all()`. The response (`PluginUpdateResponse` in `finlet/api/schemas/settings.py`) carries the post-reload `PluginHealthItem` and a top-level `status` derived from the live health: `HEALTHY → "updated"`, `DEGRADED → "degraded"`, `UNHEALTHY → "unhealthy"`. Older clients that read only `status` continue to work because the success-case string is still `"updated"`; new clients (CLI, new dashboard surfaces) can read `health` and `message` for the live reason without a second round-trip. The route catches `registry.reload`'s exceptions explicitly — there is no blanket `contextlib.suppress(Exception)` masking init failures (see `docs/decisions/refactor/plugin-config-propagation.md` for the rationale).
- **`POST /v1/plugins/{name}/reload`** — *no-config-change kicker* for ops/debug. It does NOT touch the per-user config store; it re-reads `~/.finlet/plugins.json` from disk and re-initialises the named plugin. Useful when the persisted JSON has been edited out-of-band (operator hand-edit) and the registry needs to pick up the new state without a server restart. Application code that owns the credentials MUST go through `PUT /v1/settings/plugins` instead — using `/reload` from app code would silently drop the per-user persistence step.
```

```md docs/PRIVACY_POLICY.md:546
**User-provided API keys.** If you provide your own API keys for third-party services (e.g., Finnhub), those keys are stored locally in your plugin configuration file (`~/.finlet/plugins.json`) and are transmitted directly to the respective third-party when the Service makes API calls on your behalf. These keys are never committed to version control or stored on Finlet's servers.
```

```python finlet/plugins/edgar_plugin.py:86-93
        """
        identity = config.get("identity", config.get("email"))
        if not identity:
            logger.error(
                "EDGAR plugin requires an identity. "
                'Set it in ~/.finlet/plugins.json: {"edgar": {"identity": "YourName your@email.com"}} '
                "or via CLI: finlet config set edgar.identity 'YourName your@email.com'"
            )
```

**Conclusion:** Against this HEAD, the blind symptom is not present in `finlet/cli.py`: `finlet plugins add` requires `FINLET_API_KEY`, PUTs to hosted `/v1/settings/plugins`, prints live status, and test coverage rejects `"Restart server"` plus local `plugins.json` writes. If production/PyPI still behaves as blind reported, root cause is release/deploy/package lag, not current source. Complete source-level surgery surface is docs/string drift: contradictory `docs/ARCHITECTURE.md:225` versus `:231-232`, stale legal copy in `docs/PRIVACY_POLICY.md:546`, and stale EDGAR error strings still pointing users at `~/.finlet/plugins.json`/`finlet config set`.

**Disagreement risk:** root-cause. Codex reads current HEAD as fixed in CLI/runtime; blind/prod evidence implies a different deployed artifact or stale package, while source surgery is residual docs/error-copy cleanup.

### Finding 3 — missing-favicon-ico

**Independent recon (Codex gpt-5.5 xhigh against HEAD 23505f49b90c873677a6b5c4b7c22cf86d1bfd32):**

```html dashboard/index.html:8-10
    <title>Finlet — AI Trading Agent ITE</title>
    <link rel="icon" type="image/svg+xml" href="favicon.svg">
    <link rel="stylesheet" href="styles.css">
```

```html dashboard/setup.html:6-9
    <title>Finlet — Setup Guide</title>
    <meta name="description" content="Set up Finlet in minutes. Connect your AI trading agent via REST API, MCP, or pip install. Complete guide from registration to first trade.">
    <link rel="icon" type="image/svg+xml" href="favicon.svg">
    <link rel="stylesheet" href="styles.css">
```

```python finlet/api/app.py:609-612
        app.routes.insert(0, Route("/pricing", _serve_pricing, methods=["GET", "HEAD"]))
        app.routes.insert(0, Route("/login", _serve_login, methods=["GET", "HEAD"]))

        app.mount("/", StaticFiles(directory=str(dashboard_dir), html=True), name="dashboard")
```

**Conclusion:** The bug is a missing static asset/route. Grep found no production `favicon.ico` references and `find dashboard finlet deploy -iname '*favicon*'` returns only `dashboard/favicon.svg`; all eight dashboard HTML pages (`index`, `auth`, `agent-guide`, `leaderboard`, `api-keys`, `verify`, `landing`, `setup`) link the SVG. Browsers still request `/favicon.ico`; the root `StaticFiles` mount 404s because no `dashboard/favicon.ico` exists and no explicit `/favicon.ico` route redirects. Minimum surgery: add `dashboard/favicon.ico` or add an explicit `/favicon.ico` route/redirect. Parallel surfaces: the same SVG-only link appears across all eight HTML pages, but the actual missing surface is global, not per-page.

**Disagreement risk:** none.

### Finding 4 — plugin-ingest-dead-affordance-post-cut

**Independent recon (Codex gpt-5.5 xhigh against HEAD 23505f49b90c873677a6b5c4b7c22cf86d1bfd32):**

```python finlet/plugins/news_plugin.py:475-486
        if cached_files:
            return PluginHealth(
                status=PluginHealthStatus.HEALTHY,
                message=f"OK — {len(cached_files)} cached files",
            )
        return PluginHealth(
            status=PluginHealthStatus.DEGRADED,
            message="No cached news data files found. Run ingestion first.",
        )
```

```python finlet/plugins/sentiment_plugin.py:461-469
            return PluginHealth(
                status=PluginHealthStatus.HEALTHY,
                message=f"OK — {len(cached_files)} cached files",
            )
        return PluginHealth(
            status=PluginHealthStatus.DEGRADED,
            message="No cached sentiment data files found. Run ingestion first.",
        )
```

```python finlet/plugins/price_plugin.py:910-918
        # lake never populated" case. Keep the actionable copy here only.
        # Wording does NOT mention a "last N days" window, since the
        # probe no longer pins to real-world recency.
        return PluginHealth(
            status=PluginHealthStatus.DEGRADED,
            message="No price data available. Run ingestion first.",
        )
```

```python finlet/plugins/fundamentals_plugin.py:1064-1071
                message=f"OK -- {len(cached_files)} cached files",
            )
        return PluginHealth(
            status=PluginHealthStatus.DEGRADED,
            message="No cached fundamentals data files found. Run ingestion first.",
        )
```

```html dashboard/index.html:281-295
        <!-- Plugin Health -->
        <section class="panel plugins-panel" id="plugins-panel" role="region" aria-labelledby="plugins-title">
            <div class="panel-header">
                <h2 class="panel-title" id="plugins-title">Plugin Health</h2>
                <button class="panel-toggle" type="button" data-panel="plugins-panel" aria-label="Collapse Plugin Health panel" aria-expanded="true" aria-controls="plugins-panel"></button>
            </div>
            <div class="plugin-cards" id="plugin-cards" role="list" aria-label="Plugin status list">
                <div class="empty-state">
                    <div class="empty-state__icon">
                        <svg width="40" height="40" viewBox="0 0 40 40" fill="none" aria-hidden="true"><rect x="8" y="8" width="10" height="10" rx="2" stroke="var(--text-muted)" stroke-width="1.5"/><rect x="22" y="8" width="10" height="10" rx="2" stroke="var(--text-muted)" stroke-width="1.5"/><rect x="8" y="22" width="10" height="10" rx="2" stroke="var(--text-muted)" stroke-width="1.5"/><rect x="22" y="22" width="10" height="10" rx="2" stroke="var(--text-muted)" stroke-width="1.5" stroke-dasharray="3 2"/></svg>
                    </div>
                    <p class="empty-state__headline">Select a session to see plugin status</p>
                    <p class="empty-state__text">Plugin health is reported per active session. Create or select one to view live status.</p>
                </div>
```

```js dashboard/app.js:1995-2037
        // message-substring heuristic.
        const status = (p.status || 'unknown').toLowerCase();
        const dotClass = (status === 'healthy' || status === 'ok')
            ? 'ok'
            : (status === 'degraded' || status === 'rate-limited' || status === 'rate_limited')
                ? 'degraded'
                : (status === 'error' || status === 'unhealthy')
                    ? 'error'
                    : 'unknown';
        const statusLabel = dotClass === 'ok'
            ? 'Healthy'
            : dotClass === 'degraded'
                ? 'Degraded'
                : dotClass === 'error'
                    ? 'Error'
                    : 'Unknown';

        // formatLatency returns null for non-finite values; short-circuit
        // the badge when null so we never render `NaNms` or `8esms` if the
        // BE serializer ever drifts from the canonical numeric contract.
        const latencyDisplay = formatLatency(p.latency_ms);
        return `<div class="plugin-card" role="listitem">
            <div class="plugin-status-dot plugin-status-dot--${dotClass}" aria-hidden="true"></div>
            <span class="sr-only">Status: ${statusLabel}</span>
            <div class="plugin-info">
                <div class="plugin-name">${esc(p.name)}</div>
                <div class="plugin-type">${esc(p.plugin_type || p.type || '')}</div>
                ${p.message ? `<div class="plugin-message">${esc(p.message)}</div>` : ''}
            </div>
            <div class="plugin-meta">
                ${latencyDisplay !== null ? `<div class="plugin-latency">${esc(latencyDisplay)}<span class="sr-only"> response time</span></div>` : ''}
                ${p.rate_limit_remaining != null
                    ? `<div class="plugin-rate">${esc(String(p.rate_limit_remaining))} <span class="sr-only">API calls</span> remaining</div>`
                    : ''}
            </div>
        </div>`;
```

```python finlet/api/routes_plugins.py:7-18
Currently exposes:

- ``POST /plugins/{name}/ingest`` — stub endpoint that the dashboard
  Ingest button calls when the plugin reports a "Run ingestion first"
  degraded message. Returns 202 Accepted with ``{"job_id": "<uuid>"}``.
  Auth required (Bearer API key) so anonymous traffic cannot enqueue
  jobs. The actual ingest pipeline wiring lives in
  ``scripts/ingest_yfinance_prices.py`` etc. and is not yet exposed
  via this endpoint — that is the next iteration.

  TODO(iteration 20260502T142726Z7b36): wire to the real ingest
  scheduler / queue, persist job state in the ops database, and
```

```js legacy/dashboard-ui/settings.js:995-1006
function _pluginNeedsIngest(plugin) {
    const msg = (plugin && plugin.message) ? String(plugin.message).toLowerCase() : '';
    return msg.includes('run ingestion');
}

// Build the per-row Ingest button HTML (escaped name + disabled-by-default
// false). Returns '' for plugins whose message does not signal a missing
// data condition. Centralised here so the row template + any future
// surface (e.g. a bulk-ingest dropdown) read the same affordance contract.
function renderIngestButton(plugin) {
    if (!_pluginNeedsIngest(plugin)) return '';
    return `<button class="btn-settings btn-settings--sm" data-action="ingest-plugin" data-plugin-name="${esc(plugin.name)}" type="button" style="margin-top: 6px;">Ingest</button>`;
```

**Conclusion:** The bug lives in the post-cut production dashboard widget: `dashboard/app.js#renderPlugins` renders status/message/latency only, while the only Ingest affordance is stranded in `legacy/dashboard-ui/settings.js`. The server endpoint exists but is explicitly a stub/no-op job-id minter, so UI wiring alone would still not perform real ingestion unless the accepted-stub semantics are intentional. Complete surgery surface: `dashboard/app.js` (predicate + button + click handler), likely `dashboard/styles.css` for button/pending/error states, and `finlet/api/routes_plugins.py` if the desired fix is real ingestion rather than honest disabled/help copy. Parallel producer surfaces are `price`, `fundamentals`, `news`, and `sentiment`; a fix that only special-cases `news_s3`/`sentiment` would leave the same user-visible `"Run ingestion first"` dead path elsewhere. Production `dashboard/` grep found no `Ingest` button.

**Disagreement risk:** scope-only.

### Finding 5 — setup-api-key-confirmation-copy

**Independent recon (Codex gpt-5.5 xhigh against HEAD 23505f49b90c873677a6b5c4b7c22cf86d1bfd32):**

```html dashboard/setup.html:124-149
                        <h3 class="setup-step-title">Create your account</h3>
                    </div>
                    <div class="setup-step-content">
                        <p class="setup-desc">
                            Register a free account — no credit card required. The fastest way is to <a href="auth.html">sign up through the website</a>, which gives you an API key on the confirmation screen.
                        </p>

                        <details class="setup-details">
                            <summary>Register via the REST API instead</summary>
                            <div class="setup-details-content">
                                <p class="setup-desc">If you'd rather register programmatically, POST to the auth endpoint:</p>
                                <div class="code-block">
                                    <div class="code-block-header">
                                        <span class="code-block-lang">cURL</span>
                                        <button class="btn-copy" type="button" aria-label="Copy register command" data-copy='curl -X POST https://finlet.dev/v1/auth/register \
  -H "Content-Type: application/json" \
  -d &apos;{"email": "you@example.com", "password": "your-password"}&apos;'>
                                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"></path></svg>
                                            Copy
                                        </button>
                                    </div>
                                    <pre><code class="lang-bash">curl -X POST https://finlet.dev/v1/auth/register \
```

```html dashboard/setup.html:148-149
                                </div>
                                <p class="setup-desc">Response includes your API key: <code>{"api_key": "your_api_key_here"}</code>.</p>
```

```js dashboard/auth.js:831-852
            var res = await fetch(API_BASE + '/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email: els.signupEmail.value.trim(),
                    password: els.signupPassword.value,
                    research_network: els.signupResearch.checked,
                }),
            });

            var data = await res.json().catch(function () { return {}; });

            if (res.status === 201 || res.ok) {
                var apiKey = data.api_key;

                await saveAuth(apiKey, {
                    email: els.signupEmail.value.trim(),
                    tier: data.tier || 'free',
                    research_network: data.research_network || false,
                });

                // Show success state
                els.signupFields.style.display = 'none';
```

```js dashboard/auth.js:365-384
    async function saveAuth(apiKey, user) {
        if (user) {
            sessionStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
        }

        try {
            var res = await fetch(API_BASE + '/auth/session', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ api_key: apiKey }),
            });
            if (res.ok) {
                var data = await res.json();
                _csrfToken = data.csrf_token;
                _hasSessionCookie = true;
                sessionStorage.setItem(AUTH_STORAGE_KEY, 'cookie');
                if (_csrfToken) sessionStorage.setItem('finlet_csrf', _csrfToken);
```

```html dashboard/auth.html:205-214
                    <div class="auth-success" id="signup-success">
                        <div class="auth-success-icon">
                            <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>
                        </div>
                        <h3>Account created</h3>
                        <p>You're all set. You can now sign in with your email and password.</p>

                        <button type="button" class="auth-btn" id="go-to-dashboard-btn" style="margin-top: 20px;">
                            Go to Dashboard
```

```md docs/ARCHITECTURE.md:1054-1056
### API Key Auth

API keys are issued at registration and persisted to SQLite with an in-memory cache for fast lookups. Session tokens are SHA-256 hashed at rest — the raw token is returned to the client on creation but only the hash is stored in the database. Database compromise does not yield usable session tokens. All protected endpoints use the `require_user` dependency (dual auth: session cookie + Bearer token). `require_user` checks for a valid httpOnly session cookie first, then falls back to `Authorization: Bearer <key>` header. This applies to all route files — not just auth routes. The dashboard frontend prefers cookie-based auth (set at sign-in) and falls back to bearer token only when no cookie session exists. API keys are managed from the Settings page: users can create named keys (shown once with copy-once pattern), view masked keys (`fnlt_...xxxx`) with last-used timestamps, and revoke keys with confirmation. Session ownership is enforced — keys can only access sessions belonging to the same `user_id`.
```

**Conclusion:** The bug lives in `dashboard/setup.html` copy. The website registration flow reads `data.api_key` only to create `/auth/session`, then shows an auth success message with no key. That matches the blind symptom and contradicts setup Step 2. Complete surgery surface: update `dashboard/setup.html` to distinguish website signup (session cookie, no visible key) from CLI/REST API key creation, or change `dashboard/auth.js`/`dashboard/auth.html` if the product wants a one-time reveal. Parallel surfaces: `dashboard/api-keys.html` and `dashboard/api-keys.js` also give stale CLI guidance from Finding 1, and `docs/ARCHITECTURE.md:1056` still describes cut Settings-page create/revoke flows. No other production page contains the exact `"confirmation screen"` promise.

**Disagreement risk:** scope-only.

### Finding 6 — session-modal-duplicate-template-name

**Independent recon (Codex gpt-5.5 xhigh against HEAD 23505f49b90c873677a6b5c4b7c22cf86d1bfd32):**

```js dashboard/app.js:847-853
const SESSION_TEMPLATES = {
    conservative: { name: 'Conservative ETF', tickers: ['SPY', 'BND', 'GLD'] },
    tech: { name: 'Tech Growth', tickers: ['AAPL', 'GOOGL', 'MSFT', 'NVDA', 'META'] },
    custom: { name: 'Custom', tickers: [] },
};

let selectedTemplate = 'conservative';
```

```js dashboard/app.js:901-925
function selectTemplate(templateKey) {
    selectedTemplate = templateKey;
    const modal = document.getElementById('create-session-modal');
    if (!modal) return;

    // Update selected state
    modal.querySelectorAll('.template-card').forEach(card => {
        card.classList.toggle('template-card--selected', card.dataset.template === templateKey);
    });

    // Show/hide custom universe input
    const customGroup = document.getElementById('custom-universe-group');
    if (customGroup) {
        customGroup.style.display = templateKey === 'custom' ? 'block' : 'none';
    }

    // Sync name field with the selected template. Custom clears (empty
    // string) so users can type their own; named templates always
    // overwrite — switching templates should follow the template choice,
    // not retain stale text from a prior selection.
    const nameInput = document.getElementById('session-name');
    if (nameInput) {
        nameInput.value = templateKey === 'custom'
            ? ''
```

```js dashboard/app.js:923-941
    if (nameInput) {
        nameInput.value = templateKey === 'custom'
            ? ''
            : SESSION_TEMPLATES[templateKey]?.name || '';
    }
}

function openCreateSessionModal() {
    const modal = document.getElementById('create-session-modal');
    if (!modal) return;

    // Reset form
    const form = document.getElementById('create-session-form');
    if (form) form.reset();

    // Reset template to conservative
    selectTemplate('conservative');
```

```html dashboard/index.html:306-328
                    <div class="form-group">
                        <label class="form-label">Start from a template</label>
                        <div class="template-selector" role="radiogroup" aria-label="Session template">
                            <button type="button" class="template-card template-card--selected" data-template="conservative">
                                <span class="template-card-name">Conservative ETF</span>
                                <span class="template-card-tickers">SPY, BND, GLD</span>
                            </button>
                            <button type="button" class="template-card" data-template="tech">
                                <span class="template-card-name">Tech Growth</span>
                                <span class="template-card-tickers">AAPL, GOOGL, MSFT, NVDA, META</span>
                            </button>
                            <button type="button" class="template-card" data-template="custom">
                                <span class="template-card-name">Custom</span>
                                <span class="template-card-tickers">Choose your own tickers</span>
                            </button>
                        </div>
                    </div>

                    <!-- Session Name -->
                    <div class="form-group">
                        <label class="form-label" for="session-name">Session Name <span class="form-required" aria-label="required">*</span></label>
                        <input type="text" id="session-name" class="form-input" placeholder="e.g. My First Simulation" maxlength="100" required autocomplete="off">
                        <span class="form-error" id="session-name-error" role="alert"></span>
```

```js dashboard/app.js:1002-1011
    const name = document.getElementById('session-name').value.trim();
    if (!name) {
        setFormError('session-name', 'Session name is required');
        valid = false;
    } else if (name.length > 100) {
        setFormError('session-name', 'Name must be 100 characters or fewer');
        valid = false;
    }

    const capital = parseFloat(document.getElementById('session-capital').value);
```

```js dashboard/app.js:1068-1075
            name: name,
            start_time: startTime,
            initial_capital: capital,
            universe: universe,
        };

        const result = await dashPost('/sessions', body);
```

```ts tests/e2e/journey-04-dashboard.spec.ts:277-299
    const modal = page.locator('#create-session-modal');
    await expect(modal).toHaveClass(/fl-modal--visible/);

    const nameInput = page.locator('#session-name');

    // Modal opens with conservative template, name pre-filled.
    await expect(nameInput).toHaveValue('Conservative ETF');

    // Switch to Tech Growth — name should follow the template choice.
    await page.click('[data-template="tech"]');
    await expect(nameInput).toHaveValue('Tech Growth');

    // Switch back to Conservative — name should follow again.
    await page.click('[data-template="conservative"]');
    await expect(nameInput).toHaveValue('Conservative ETF');

    // Switch to Custom — name MUST clear, not retain the stale "Conservative ETF".
    // This is the regression assertion for Bug 1 (Session-Name Template Stale).
    await page.click('[data-template="custom"]');
    await expect(nameInput).toHaveValue('');
```

**Conclusion:** The user-visible duplicate risk is real, but the root cause is not a read of the current active session. `openCreateSessionModal()` always calls `selectTemplate('conservative')`; `selectTemplate()` always writes `SESSION_TEMPLATES[conservative].name` into `#session-name`; submit then sends that unedited value to `/sessions`. If the active or common first session is already "Conservative ETF", the next modal opens with the duplicate name by construction. Complete surgery surface: `dashboard/app.js` default-name policy, `dashboard/index.html` static selected template if default selection changes, and `tests/e2e/journey-04-dashboard.spec.ts` because it currently pins the bad prefill as expected behavior. Parallel surfaces: `legacy/dashboard-ui/app.js` preserves the same code but is cut/non-production; no additional production session-creation surface found.

**Disagreement risk:** root-cause. Codex differs from the blind framing: the modal is not prefilled from current active session state; it is hardcoded through the conservative template default.
