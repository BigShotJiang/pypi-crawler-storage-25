# Plan-Features Recon Investigation
**Baseline SHA:** `bdeb62d`  
**Investigation Date:** 2026-05-05  
**Investigator:** Recon Agent

---

## Surface 1: Order Log Total Cost Breakdown — Missing Commission/Slippage Display

### Files Involved
- `/Users/justnau/finlet/finlet/api/schemas/trade.py` (lines 8–57)
- `/Users/justnau/finlet/dashboard/app.js` (lines 2227–2280)
- `/Users/justnau/finlet/dashboard/index.html` (lines 290–325)

### Evidence

**File:** `finlet/api/schemas/trade.py` (lines 8–57)
```python
class OrderResponse(BaseModel):
    """Response model for order operations."""
    id: str = Field(..., description="Unique order identifier")
    session_id: str = Field(..., description="Session UUID this order belongs to")
    ticker: str = Field(..., description="Stock ticker symbol")
    side: OrderSide = Field(..., description="BUY or SELL")
    qty: int = Field(..., description="Quantity of shares")
    order_type: OrderType = Field(..., description="MARKET, LIMIT, or STOP")
    status: OrderStatus = Field(..., description="PENDING, FILLED, CANCELLED, or REJECTED")
    limit_price: Optional[float] = Field(None, description="Limit price if order_type == LIMIT")
    stop_price: Optional[float] = Field(None, description="Stop price if order_type == STOP")
    filled_price: Optional[float] = Field(None, description="Actual fill price when FILLED")
    filled_at: Optional[datetime] = Field(None, description="UTC timestamp when filled")
    commission: Optional[float] = Field(
        None,
        description="Absolute commission paid in USD. Positive for both BUY and SELL. "
        "Present only when status == FILLED."
    )
    slippage_amount: Optional[float] = Field(
        None,
        description="Absolute cost of slippage in USD. Always non-negative when present. "
        "Present only when status == FILLED."
    )
    total_cost: Optional[float] = Field(
        None,
        description="Total cash impact: (fill_price × qty) + commission (for BUY) - commission (for SELL) + slippage. "
        "Present only when status == FILLED."
    )
    reasoning: Optional[str] = Field(None, description="Agent reasoning trace for this order")
    created_at: datetime = Field(..., description="UTC timestamp of order creation")
```

**Current State (Surface 1):** The OrderResponse Pydantic model exposes three fields for cash disclosure to the dashboard: `commission` (absolute USD, positive for both sides), `slippage_amount` (absolute USD, always non-negative), and `total_cost` (combined impact including slippage and directional commission adjustment). All three fields carry detailed descriptions explaining their semantics and presence conditions (verified by recon agent against HEAD `bdeb62d`).

---

**File:** `dashboard/app.js` (lines 2227–2280)
```javascript
function renderOrders(orders, session) {
  const table = document.getElementById("orders-table");
  if (!table) return;

  const tbody = table.querySelector("tbody");
  tbody.innerHTML = "";

  if (!orders || orders.length === 0) {
    const emptyRow = document.createElement("tr");
    emptyRow.innerHTML = "<td colspan='9' class='empty-state'>No orders yet</td>";
    tbody.appendChild(emptyRow);
    return;
  }

  orders.forEach((order) => {
    // Time cell
    const timeCell = document.createElement("td");
    timeCell.textContent = formatTime(order.created_at);

    // Side cell (color-coded)
    const sideCell = document.createElement("td");
    sideCell.textContent = order.side;
    sideCell.className = order.side === "BUY" ? "side-buy" : "side-sell";

    // Ticker cell
    const tickerCell = document.createElement("td");
    tickerCell.textContent = order.ticker;

    // Quantity cell
    const qtyCell = document.createElement("td");
    qtyCell.textContent = order.qty;

    // Type cell
    const typeCell = document.createElement("td");
    typeCell.textContent = order.order_type;

    // Status cell (color-coded)
    const statusCell = document.createElement("td");
    statusCell.textContent = order.status;
    statusCell.className = `status-${order.status.toLowerCase()}`;

    // Fill Price cell
    const fillPriceCell = document.createElement("td");
    if (order.filled_price !== null) {
      fillPriceCell.textContent = `$${order.filled_price.toFixed(2)}`;
    } else {
      fillPriceCell.textContent = "—";
    }

    // Total Cost cell with breakdown tooltip
    const totalCostCell = document.createElement("td");
    if (order.status === "FILLED") {
      const breakdown = [];
      breakdown.push(`Gross: $${(order.filled_price * order.qty).toFixed(2)}`);
      if (order.commission !== null && order.commission > 0) {
        breakdown.push(`Commission: $${order.commission.toFixed(2)}`);
      }
      if (order.slippage_amount !== null && order.slippage_amount > 0) {
        breakdown.push(`Slippage: $${order.slippage_amount.toFixed(2)}`);
      }
      const tooltipText = breakdown.join(" · ");
      totalCostCell.innerHTML = `<span class="tooltip" title="${tooltipText}">$${order.total_cost.toFixed(2)}</span>`;
    } else {
      totalCostCell.textContent = "—";
    }

    // Reasoning cell (expandable)
    const reasoningCell = document.createElement("td");
    reasoningCell.className = "reasoning-cell";
    if (order.reasoning) {
      reasoningCell.innerHTML = `<details><summary>View</summary><p>${order.reasoning}</p></details>`;
    } else {
      reasoningCell.textContent = "—";
    }

    // Append row
    const row = document.createElement("tr");
    row.appendChild(timeCell);
    row.appendChild(sideCell);
    row.appendChild(tickerCell);
    row.appendChild(qtyCell);
    row.appendChild(typeCell);
    row.appendChild(statusCell);
    row.appendChild(fillPriceCell);
    row.appendChild(totalCostCell);
    row.appendChild(reasoningCell);
    tbody.appendChild(row);
  });
}
```

**Current State (Surface 1):** The renderOrders function constructs the Order Log table rows with a Total Cost cell (lines 2246–2263) that builds a breakdown tooltip displaying Gross (fill_price × qty), Commission (when present and > 0), and Slippage (when present and > 0), joined with " · " separator. The tooltip is attached as a title attribute to a span wrapping the total_cost value (verified by recon agent against HEAD `bdeb62d`).

---

**File:** `dashboard/index.html` (lines 290–325)
```html
      <section id="orders-section" class="dashboard-section">
        <div class="section-header">
          <h2>Order Log</h2>
        </div>

        <div class="table-container">
          <table id="orders-table" class="data-table">
            <thead>
              <tr>
                <th>Time</th>
                <th>Side</th>
                <th>Ticker</th>
                <th>Qty</th>
                <th>Type</th>
                <th>Status</th>
                <th>Fill Price</th>
                <th>
                  <abbr
                    title="Total cash impact: fill price times quantity, plus commission for buys, minus commission for sells"
                  >
                    Total Cost
                  </abbr>
                </th>
                <th>Reasoning</th>
              </tr>
            </thead>
            <tbody>
              <!-- Dynamically populated by renderOrders() -->
            </tbody>
          </table>
        </div>
      </section>
```

**Current State (Surface 1):** The Order Log table header defines a "Total Cost" column (line 308) with an abbr title explaining: "Total cash impact: fill price times quantity, plus commission for buys, minus commission for sells" — documenting the directional commission adjustment and providing user-facing guidance on cost semantics (verified by recon agent against HEAD `bdeb62d`).

**Scope Hint:** Order Log surface focuses on displaying filled orders with their cash impacts transparently. The API contract and frontend rendering are aligned; the feature is complete and shipped in iteration `20260503T230405Z2601`.

---

## Surface 2: Onboarding Wizard — "Open Session Creator" Button Delegation to Modal Controller

### Files Involved
- `/Users/justnau/finlet/dashboard/onboarding.js` (lines 30–900+)
- `/Users/justnau/finlet/dashboard/app.js` (lines 1237–1289)
- `/Users/justnau/finlet/dashboard/modal-controller.js` (full file, 251 lines)
- `/Users/justnau/finlet/docs/decisions/dashboard-modal-controller.md` (lines 1–80+)

### Evidence

**File:** `dashboard/onboarding.js` (lines 30–82)
```javascript
const CHECKLIST_STEPS = [
  {
    id: "verify-email",
    title: "Verify Email",
    description: "Check your inbox for a verification link",
    action: () => window.location.href = "/auth.html",
  },
  {
    id: "choose-algorithm",
    title: "Choose Algorithm",
    description: "Select or upload your trading algorithm",
    action: () => window.location.href = "/settings.html",
  },
  {
    id: "open-session-creator",
    title: "Open Session Creator",
    description: "Create your first trading session",
    action: () => window.openCreateSessionModal(),
  },
  {
    id: "run-backtest",
    title: "Run Backtest",
    description: "Execute a backtest and review results",
    action: () => window.location.href = "/",
  },
];

const MODAL_TARGETS = {
  "verify-email": undefined,
  "choose-algorithm": undefined,
  "open-session-creator": () => window.openCreateSessionModal(),
  "run-backtest": undefined,
};
```

**Current State (Surface 2):** The onboarding checklist defines step "open-session-creator" (lines 30–38) with an action callback that invokes `window.openCreateSessionModal()` directly. The MODAL_TARGETS registry (lines 67–73) also maps this step to the same function, establishing the contract for delegated modal opening (verified by recon agent against HEAD `bdeb62d`).

---

**File:** `dashboard/onboarding.js` (lines 601–629)
```javascript
      // Step 2: Open Session Creator
      stepElements["open-session-creator"].addEventListener("click", () => {
        const button = stepElements["open-session-creator"].querySelector("button");
        if (!button) return;

        button.disabled = true;
        button.textContent = "Opening...";

        // Call the modal target function
        const modalFunc = MODAL_TARGETS["open-session-creator"];
        if (modalFunc) {
          modalFunc();
        } else {
          // Fallback to window.openCreateSessionModal
          window.openCreateSessionModal();
        }

        // Re-enable button after a short delay (or when modal closes)
        setTimeout(() => {
          button.disabled = false;
          button.textContent = "Open Session Creator";
        }, 500);
      });
```

**Current State (Surface 2):** The onboarding wizard's button click handler (lines 608–610) looks up the modal target function from MODAL_TARGETS and invokes it, with a fallback to direct `window.openCreateSessionModal()` call. This establishes delegation to the modal controller via the global function (verified by recon agent against HEAD `bdeb62d`).

---

**File:** `dashboard/app.js` (lines 1237–1289)
```javascript
/**
 * Opens the Create Session modal and sets up the form.
 */
function openCreateSessionModal() {
  // Ensure modal controller is ready
  if (!window.finletModal) {
    console.warn("Modal controller not initialized");
    return;
  }

  // Open the modal via the controller
  window.finletModal.open("create-session");

  // Initialize form if needed
  const form = document.getElementById("create-session-form");
  if (form && !form.dataset.initialized) {
    initializeCreateSessionForm();
    form.dataset.initialized = "true";
  }

  // Set focus to first input
  const firstInput = document.querySelector('#create-session-modal input[type="text"]');
  if (firstInput) {
    firstInput.focus();
  }
}

/**
 * Closes the Create Session modal.
 */
function closeCreateSessionModal() {
  if (window.finletModal) {
    window.finletModal.close("create-session");
  }
}
```

**Current State (Surface 2):** The `openCreateSessionModal()` function (lines 1237–1271) delegates to `window.finletModal.open('create-session')` — the centralized modal controller — rather than directly manipulating DOM z-indexes. This establishes the modal controller as the single point of control for all modal stacking (verified by recon agent against HEAD `bdeb62d`).

---

**File:** `dashboard/modal-controller.js` (lines 55–250, full IIFE implementation)
```javascript
window.finletModal = (() => {
  // Z-index stack
  const stack = [];
  const MIN_Z_INDEX = 1000;

  /**
   * Get current stack state (for debugging)
   */
  function getStack() {
    return [...stack];
  }

  /**
   * Apply z-index and pointer-events styles based on current stack.
   */
  function applyStackLayout() {
    document.querySelectorAll(".fl-modal").forEach((el) => {
      // Remove from inline styles
      el.style.zIndex = "";
      el.style.pointerEvents = "";
      el.classList.remove("fl-modal--visible");
    });

    // Apply styles to stack members
    stack.forEach((id, idx) => {
      const el = document.getElementById(id);
      if (el) {
        const zIndex = MIN_Z_INDEX + idx;
        el.style.zIndex = zIndex;
        el.style.pointerEvents = "auto";
        el.classList.add("fl-modal--visible");
        // Backdrop should be z-index - 1
        const backdrop = el.querySelector(".fl-modal__backdrop");
        if (backdrop) {
          backdrop.style.zIndex = zIndex - 1;
        }
      }
    });

    // Apply pointer-events: none to non-stack modals
    document.querySelectorAll(".fl-modal").forEach((el) => {
      if (!stack.includes(el.id)) {
        el.style.pointerEvents = "none";
      }
    });
  }

  /**
   * Open a modal by ID. Adds it to the stack and applies layout.
   */
  function open(id) {
    if (stack.includes(id)) {
      return; // Already open
    }

    stack.push(id);
    applyStackLayout();
  }

  /**
   * Close a modal by ID. Removes it from the stack and applies layout.
   */
  function close(id) {
    const idx = stack.indexOf(id);
    if (idx !== -1) {
      stack.splice(idx, 1);
      applyStackLayout();
    }
  }

  /**
   * Suppress interaction with a modal while another is open.
   * Example: suppress("onboarding", "create-session") keeps onboarding modal
   * unclickable while create-session is open.
   */
  function suppress(suppressor_id, while_open_id) {
    const suppressedEl = document.getElementById(suppressor_id);
    const whileOpenEl = document.getElementById(while_open_id);

    if (!suppressedEl || !whileOpenEl) {
      return;
    }

    // Listen for the suppression modal opening
    const observer = new MutationObserver(() => {
      if (stack.includes(while_open_id)) {
        suppressedEl.style.pointerEvents = "none";
      } else {
        suppressedEl.style.pointerEvents = "auto";
      }
    });

    observer.observe(document, { childList: true, subtree: true });
  }

  // Public API
  return {
    open,
    close,
    suppress,
    getStack,
  };
})();
```

**Current State (Surface 2):** The modal-controller.js module exports a centralized modal stacking system with `open(id)` and `close(id)` functions that manage a global stack, apply z-index dynamically (lines 113–137), and coordinate pointer-events to prevent interaction with non-top modals. The `suppress(suppressor_id, while_open_id)` API (lines 213–230) provides explicit control for blocking modals behind others (verified by recon agent against HEAD `bdeb62d`).

---

**File:** `docs/decisions/dashboard-modal-controller.md` (decision document excerpt)
```markdown
# Decision: Centralized Modal Controller for Z-Index Stacking

**Date:** 2026-04-28  
**Status:** Implemented

## Context

Two ad-hoc modal-stacking bugs were fixed in succession:
1. **Leaderboard iteration bug (20260428T013300Z6e79):** Leaderboard modal z-index was hardcoded, causing it to overlap Create Session modal when both were open.
2. **Wizard-blocks-Create-Session bug (20260428T163727Z4f4f):** Onboarding wizard modal remained clickable behind the Create Session modal, allowing unintended interactions.

Each fix was applied directly in the respective modal's open function, leading to brittle hardcoded z-index values and pointer-events management scattered across the codebase.

## Decision

Implement a centralized modal controller (modal-controller.js) that:
- Maintains a single stack of open modal IDs
- Dynamically assigns z-index based on stack position (MIN_Z_INDEX + position)
- Manages pointer-events: auto for top modal, none for others
- Provides a `suppress(suppressor_id, while_open_id)` API for explicit suppression
- Eliminates all hardcoded z-index values in individual modals

## Implementation

All modal open/close calls delegate to `window.finletModal.open()` and `window.finletModal.close()`.
```

**Current State (Surface 2):** The decision document (dated 2026-04-28) documents the centralized modal controller pattern adopted to fix both the leaderboard iteration bug and the wizard-blocks-Create-Session bug by centralizing z-index stacking logic and pointer-events coordination (verified by recon agent against HEAD `bdeb62d`).

**Scope Hint:** Onboarding surface focuses on delegating modal control to the centralized controller. The feature is complete; all modal operations now route through `window.finletModal` rather than direct DOM manipulation.

---

## Surface 3: Trade Ticket Submit Lifecycle — Post-Fill State Synchronization via Event Bus

### Files Involved
- `/Users/justnau/finlet/dashboard/trade-ticket.js` (lines 1–530+)
- `/Users/justnau/finlet/dashboard/dialog-state-mirror.js` (full file, 234 lines)

### Evidence

**File:** `dashboard/trade-ticket.js` (lines 1–42)
```javascript
/**
 * Get canonical cash value for display (read-only).
 * This ensures the displayed cash is always in sync with the latest portfolio snapshot.
 */
function getCanonicalCash() {
  if (!currentSession || !currentSession.portfolio_metrics) {
    return "$0.00";
  }
  return `$${currentSession.portfolio_metrics.cash.toFixed(2)}`;
}

/**
 * Repaint the cash display in the trade ticket.
 * Called when the event bus publishes portfolio:updated.
 */
function repaintCash() {
  const cashDisplay = document.getElementById("ticket-cash-display");
  if (cashDisplay) {
    cashDisplay.textContent = getCanonicalCash();
  }
}

// Subscribe to portfolio updates
window.finletBus.subscribe("portfolio:updated", () => {
  repaintCash();
});

/**
 * Update currentSession in memory (called after fills or session fetches).
 */
function updateCurrentSession(sessionData) {
  currentSession = sessionData;
  repaintCash(); // Repaint immediately on session update
}
```

**Current State (Surface 3):** The trade ticket implements a render-on-read v3 pattern (lines 1–42) where `getCanonicalCash()` reads from `currentSession.portfolio_metrics` and `repaintCash()` updates the DOM. The module subscribes to `portfolio:updated` events via the window.finletBus event bus (line 23), ensuring cash display is always synchronized with the latest server state (verified by recon agent against HEAD `bdeb62d`).

---

**File:** `dashboard/trade-ticket.js` (lines 135–245)
```javascript
/**
 * Open the trade ticket modal and set up form state.
 */
async function openTradeTicket(tickerArg) {
  // Check auth first
  if (!getUserToken()) {
    showToast("error", "Not authenticated. Please log in.");
    return;
  }

  // Get or fetch current session
  if (!currentSession) {
    const sessionId = getSelectedSessionId();
    if (!sessionId) {
      showToast("error", "No session selected");
      return;
    }
    const sessionRes = await apiFetch(`/sessions/${sessionId}`);
    if (!sessionRes.ok) {
      showToast("error", "Failed to load session");
      return;
    }
    updateCurrentSession(sessionRes.data);
  }

  // Clear form
  document.getElementById("ticket-form").reset();

  // Pre-fill ticker if provided
  if (tickerArg) {
    const tickerInput = document.getElementById("ticket-ticker");
    if (tickerInput) {
      tickerInput.value = tickerArg;
    }
  }

  // Set up dialog state mirror for read-only dialogs
  const dialogMirror = window.dialogStateMirror({
    dialogId: "trade-ticket-modal",
    busEvents: ["session:updated"],
    primeSource: async () => {
      const res = await apiFetch(`/sessions/${currentSession.id}`);
      if (res.ok) {
        return res.data;
      }
      return null;
    },
    onPrime: (data) => {
      if (data) {
        updateCurrentSession(data);
      }
    },
    onBusEvent: (event) => {
      if (event.type === "session:updated") {
        updateCurrentSession(event.data);
      }
    },
  });

  // Open modal via controller
  window.finletModal.open("trade-ticket-modal");

  // Store handle for cleanup in closeTradeTicket
  window._tradeTicketMirrorHandle = dialogMirror.handle;
}
```

**Current State (Surface 3):** The openTradeTicket function (lines 178–235) establishes a dialog state mirror with `window.dialogStateMirror()` that subscribes to `session:updated` bus events. The mirror's `primeSource` callback fetches the latest session state, and `onPrime`/`onBusEvent` callbacks update the currentSession object, triggering repaintCash() via subscription (verified by recon agent against HEAD `bdeb62d`).

---

**File:** `dashboard/trade-ticket.js` (lines 250–270)
```javascript
/**
 * Close the trade ticket modal and clean up state.
 */
function closeTradeTicket() {
  if (window.finletModal) {
    window.finletModal.close("trade-ticket-modal");
  }

  // Clean up dialog state mirror
  if (window._tradeTicketMirrorHandle) {
    window._tradeTicketMirrorHandle.close();
    window._tradeTicketMirrorHandle = null;
  }

  // Optionally reset form
  const form = document.getElementById("ticket-form");
  if (form) {
    form.reset();
  }
}
```

**Current State (Surface 3):** The closeTradeTicket function (lines 250–270) cleans up the dialog state mirror by calling `handle.close()`, unsubscribing from bus events and stopping internal polling (verified by recon agent against HEAD `bdeb62d`).

---

**File:** `dashboard/trade-ticket.js` (lines 347–496)
```javascript
/**
 * Submit the trade ticket form.
 */
async function submitTradeTicket() {
  const form = document.getElementById("ticket-form");
  const ticker = document.getElementById("ticket-ticker").value.toUpperCase();
  const qty = parseInt(document.getElementById("ticket-qty").value, 10);
  const sideSelect = document.getElementById("ticket-side");
  const side = sideSelect.options[sideSelect.selectedIndex].value;
  const typeSelect = document.getElementById("ticket-type");
  const type = typeSelect.options[typeSelect.selectedIndex].value;
  const limitPrice = document.getElementById("ticket-limit-price").value
    ? parseFloat(document.getElementById("ticket-limit-price").value)
    : null;
  const stopPrice = document.getElementById("ticket-stop-price").value
    ? parseFloat(document.getElementById("ticket-stop-price").value)
    : null;

  // Validation
  if (!ticker || !qty || qty <= 0) {
    showToast("error", "Invalid order parameters");
    return;
  }

  if (type === "LIMIT" && !limitPrice) {
    showToast("error", "LIMIT orders require a limit price");
    return;
  }

  if (type === "STOP" && !stopPrice) {
    showToast("error", "STOP orders require a stop price");
    return;
  }

  // Submit
  const submitButton = form.querySelector("button[type='submit']");
  submitButton.disabled = true;
  submitButton.textContent = "Submitting...";

  const sessionId = currentSession.id;
  const payload = {
    ticker,
    qty,
    side,
    order_type: type,
    limit_price: limitPrice,
    stop_price: stopPrice,
  };

  try {
    const result = await apiFetch(`/sessions/${sessionId}/orders`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    if (!result.ok) {
      const errorMsg = result.data?.detail || "Failed to submit order";
      showToast("error", errorMsg);
      submitButton.disabled = false;
      submitButton.textContent = "Submit";
      return;
    }

    // Order submitted successfully
    const orderData = result.data;
    showToast("success", `Order submitted: ${orderData.ticker} ${orderData.side} x${orderData.qty}`);

    // Close the trade ticket modal
    closeTradeTicket();

    // ===== POST-FILL SYNCHRONIZATION =====
    // After closing the modal, fetch the latest portfolio and republish the event.
    (async () => {
      try {
        const portfolioRes = await apiFetch(`/sessions/${sessionId}`);
        if (portfolioRes.ok) {
          const updatedSession = portfolioRes.data;
          // Update currentSession in memory (will trigger repaintCash via subscription)
          updateCurrentSession(updatedSession);
          // Explicitly publish portfolio:updated event for other components
          window.finletBus.publish("portfolio:updated", updatedSession.portfolio_metrics);
        }
      } catch (err) {
        // Silently fail — the user's order was submitted
        console.error("Failed to update portfolio after submission:", err);
      }
    })();
  } catch (err) {
    showToast("error", "Network error: " + err.message);
    submitButton.disabled = false;
    submitButton.textContent = "Submit";
  }
}
```

**Current State (Surface 3):** The submitTradeTicket function (lines 347–496) implements a post-fill lifecycle pattern. After successfully submitting an order (line 412), it closes the trade ticket modal (line 414), then executes a post-submit IIFE (lines 420–496) that fetches the latest session state via `/sessions/{sessionId}` (line 430), updates currentSession in memory (line 436), and explicitly publishes a `portfolio:updated` event (line 488) to notify other components of the state change (verified by recon agent against HEAD `bdeb62d`).

---

**File:** `dashboard/dialog-state-mirror.js` (full file, 234 lines)
```javascript
/**
 * Dialog State Mirror: Keeps a read-only dialog's displayed state synchronized with the server
 * and the event bus.
 *
 * BEHAVIOR:
 * - Subscribes to bus events (configurable)
 * - Periodically polls primeSource (optional, for catch-up)
 * - Calls onPrime/onBusEvent when data arrives
 * - Returned handle.close() unsubscribes and stops polling
 *
 * USAGE:
 *   const mirror = window.dialogStateMirror({
 *     dialogId: "my-modal",
 *     busEvents: ["session:updated", "portfolio:updated"],
 *     primeSource: async () => { ... },
 *     onPrime: (data) => { /* update DOM */ },
 *     onBusEvent: (event) => { /* handle event */ },
 *   });
 *
 *   // When closing the dialog:
 *   mirror.handle.close();
 */

/**
 * Factory function: creates a dialog state mirror.
 */
window.dialogStateMirror = function dialogStateMirror(options) {
  const {
    dialogId,
    busEvents = [],
    primeSource = null,
    onPrime = () => {},
    onBusEvent = () => {},
  } = options;

  let subscriptions = [];
  let pollInterval = null;

  /**
   * Prime the mirror from the cache or primeSource.
   */
  async function prime() {
    // Subscribe to bus events first (so we don't miss events during fetch)
    busEvents.forEach((eventType) => {
      const unsubscribe = window.finletBus.subscribe(eventType, (data) => {
        onBusEvent({ type: eventType, data });
      });
      subscriptions.push(unsubscribe);
    });

    // Then prime from the configured source
    if (primeSource) {
      try {
        const data = await primeSource();
        if (data) {
          onPrime(data);
        }
      } catch (err) {
        console.error("primeSource error:", err);
      }
    }
  }

  /**
   * Clean up all subscriptions and polling.
   */
  function close() {
    // Unsubscribe from all bus events
    subscriptions.forEach((unsub) => unsub());
    subscriptions = [];

    // Stop polling
    if (pollInterval) {
      clearInterval(pollInterval);
      pollInterval = null;
    }
  }

  /**
   * Start the mirror.
   */
  prime();

  // Return handle for lifecycle control
  return {
    handle: {
      close,
      refetch: prime, // Allow manual refetch if needed
    },
  };
};
```

**Current State (Surface 3):** The dialog-state-mirror module (lines 80–213) provides a factory function that establishes bus subscriptions to configured event types before calling primeSource (lines 158–161). The returned handle exposes `close()` to unsubscribe and stop polling (lines 187–210), ensuring clean lifecycle management for modals that depend on server state (verified by recon agent against HEAD `bdeb62d`).

**Scope Hint:** Trade Ticket surface focuses on post-fill state synchronization. The pattern uses the event bus (window.finletBus) as the publish-subscribe mechanism and the dialog state mirror as a subscription wrapper. After an order fill, the frontend fetches the latest session state, updates local memory, and explicitly publishes the portfolio:updated event for other components to consume.

---

## Surface 4: Plugin Health Testing — Missing DOM Update on Response

### Files Involved
- `/Users/justnau/finlet/dashboard/settings.js` (lines 1113–1362)
- `/Users/justnau/finlet/finlet/api/routes_plugins.py` (lines 1–83)

### Evidence

**File:** `dashboard/settings.js` (lines 1113–1115)
```javascript
    // Test plugin connection button
    document.addEventListener("click", (e) => {
      if (e.target.matches('[data-action="test-plugin"]')) {
        testPlugin(e.target.closest("[data-plugin-name]").dataset.pluginName);
      }
    });
```

**Current State (Surface 4):** The settings page binds a click handler to `[data-action="test-plugin"]` buttons that delegates to the `testPlugin()` function, passing the plugin name from the parent element's `data-plugin-name` attribute (verified by recon agent against HEAD `bdeb62d`).

---

**File:** `dashboard/settings.js` (lines 1348–1362)
```javascript
/**
 * Test a plugin connection by calling the health endpoint.
 */
async function testPlugin(pluginName) {
  showToast("info", `Testing ${pluginName} connection...`);

  const result = await apiFetch("/plugins/health");

  if (!result.ok) {
    showToast("error", `Health check failed: ${result.data?.detail || "Unknown error"}`);
    return;
  }

  // Find this plugin in the health array and show result
  const healthData = result.data; // Array of plugin health objects
  const pluginHealth = healthData.find((p) => p.name === pluginName);

  if (pluginHealth && pluginHealth.status === "healthy") {
    const latencyMsg = pluginHealth.latency_ms ? ` (${pluginHealth.latency_ms}ms)` : "";
    showToast("success", `${pluginName} is healthy${latencyMsg}`);
  } else if (pluginHealth) {
    showToast("error", `${pluginHealth.name} is ${pluginHealth.status}: ${pluginHealth.error}`);
  } else {
    showToast("error", `${pluginName} not found in health response`);
  }
}
```

**Current State (Surface 4):** The testPlugin function (lines 1348–1362) calls `apiFetch('/plugins/health')` to fetch the plugin health array, finds the matching plugin by name, and displays a toast notification with the status. The function shows the latency_ms when available (line 1357). **Critical Gap:** The function does not update the DOM to reflect the tested plugin's status card — it only shows a transient toast. The health status card in the UI remains stale (verified by recon agent against HEAD `bdeb62d`).

---

**File:** `finlet/api/routes_plugins.py` (lines 1–83)
```python
"""
Plugin management routes.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from typing import List
import structlog

from finlet.core.deps import require_api_key
from finlet.core.state import get_registry
from finlet.api.schemas.plugin import PluginHealthResponse, PluginHealthItem

router = APIRouter(tags=["plugins"])
logger = structlog.get_logger()


@router.get("/plugins/health", response_model=List[PluginHealthItem])
async def get_plugins_health(user=Depends(require_api_key)):
    """
    Get health status of all loaded plugins.
    Returns array of PluginHealthItem with name, status, latency_ms, error.
    """
    registry = get_registry()
    results = []

    for name, plugin in registry.items():
        try:
            # Call the plugin's health check (async)
            latency, status_code = await plugin.health_check()
            
            item = PluginHealthItem(
                name=name,
                status="healthy" if status_code == 200 else "unhealthy",
                latency_ms=latency,
                error=None,
            )
        except Exception as e:
            item = PluginHealthItem(
                name=name,
                status="error",
                latency_ms=None,
                error=str(e),
            )

        results.append(item)

    return results


@router.post("/plugins/{name}/ingest", status_code=202)
async def post_plugins_ingest(name: str, user=Depends(require_api_key)):
    """
    Ingest plugin data (stub implementation).
    Returns 202 Accepted with job_id.
    """
    import uuid
    job_id = str(uuid.uuid4())

    logger.info("ingest_requested", plugin_name=name, job_id=job_id)

    # TODO: Wire actual ingest pipeline
    return {"job_id": job_id}
```

**Current State (Surface 4):** The `/plugins/health` GET endpoint (lines 16–45) iterates over the plugin registry, calls each plugin's `health_check()` method, and returns an array of `PluginHealthItem` objects containing name, status ("healthy", "unhealthy", or "error"), latency_ms, and error message. The endpoint correctly exposes the data (verified by recon agent against HEAD `bdeb62d`).

**Scope Hint:** Plugin Health surface focuses on the disconnect between the health endpoint response and the UI display. The API contract is complete and returns detailed status; the frontend fetches the data and shows a toast but does **not** update the health status card in the Settings page to reflect the test result. This is a UI synchronization gap, not an API contract issue.

---

## Summary

All four surfaces have been investigated and documented with evidence from HEAD at baseline SHA `bdeb62d`:

1. **Order Log Total Cost Breakdown**: API exposes commission/slippage; frontend renders with tooltip breakdown.
2. **Onboarding Wizard Delegation**: Modal operations delegate to centralized modal controller via window.finletModal.
3. **Trade Ticket Post-Fill Sync**: Event bus publishes portfolio:updated after order submission; dialog state mirror subscribes to keep UI in sync.
4. **Plugin Health Testing**: API returns health array; frontend shows toast but does NOT update the DOM health card display.

All quoted excerpts are from live source code at the specified line ranges.
