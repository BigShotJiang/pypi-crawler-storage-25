## Broken (will be fixed this iteration)

- $0.03 unexplained gap on BUY 10 SPY @ $560.90 — order log shows total $5,608.97 with no field disclosing commission/slippage breakdown to the user, contradicting the disclosure contract shipped 2026-05-03 [evidence: "Order Log row: BUY SPY 10 MARKET FILLED $560.90 $5,608.97. 10 × $560.90 = $5,609.00. The $0.03 difference is either a hidden commission fee or a floating-point rounding error. No fee disclosure appears anywhere in the Trade Ticket or order confirmation."] [scope hint: dashboard/index.html, dashboard/app.js, finlet/api/schemas/trade.py]
- Create Session dialog and onboarding wizard render simultaneously when user clicks "Open Session Creator" inside wizard step 2 — two display:block dialogs stacked, modal-stacking contract violated on a different code path than the prior leaderboard fix [evidence: "Clicking 'Open Session Creator' inside wizard step 2 opened dialog[aria-label='Create New Session'] on top of dialog[aria-label='Welcome to Finlet onboarding wizard']. Both dialogs were visible and active at the same time. After session creation, the wizard remained open underneath the now-dismissed session dialog."] [scope hint: dashboard/onboarding.js, dashboard/app.js, dashboard/index.html]
- Trade Ticket dialog does not close or acknowledge after a successful fill — Order Log row shows FILLED but the dialog gives zero in-UI feedback (no toast, no auto-close, no banner), UI state diverges from backend state [evidence: "After BUY SPY 10 filled (FILLED status visible in Order Log), the Trade Ticket dialog remained open with an empty form, available cash updated to $94,391.03. No success toast inside the dialog, no auto-close, no 'Order filled!' banner. The user must manually close the dialog and scroll down to confirm the fill."] [scope hint: dashboard/trade-ticket.js, dashboard/app.js]
- Test Connection button on fundamentals_s3 fires but produces no visible feedback — documented affordance click yields no toast, no status update, no timestamp; user cannot tell success from silent failure [evidence: "Clicked [data-action='test-plugin'][data-plugin-name='fundamentals_s3']. Button briefly showed [active] state, then returned to normal. Paragraph below still read 'OK -- 21 cached files' (unchanged). No toast notification appeared. No timestamp updated. The user has no confirmation that the test ran successfully versus silently failed."] [scope hint: dashboard/settings.js, dashboard/settings.html]

## Logged (not actioned)

- Finlet benchmark MCP tool not available in agent environment [classification: ambiguous]
- browser_take_screenshot times out every attempt — font loading hangs at 5000ms [classification: ambiguous]
- Accessibility tree ref IDs reassigned on every snapshot, breaking sequential automation [classification: ambiguous]
- Onboarding wizard 'Continue' button disabled with no explanation — user has no cue to select a persona [classification: annoying]
- Session name auto-fills with template name 'Conservative ETF', leading to generic default names [classification: nice-to-have]
- Plugin page shows 4 plugins as degraded/unhealthy with no actionable setup path for 3 of them [classification: annoying]
- App title says 'AI Trading Agent ITE' but landing page calls it 'Backtesting Platform' — 'ITE' unexplained [classification: annoying]
- Session creation spinner shows 'Creating...' for ~12 seconds with no progress indication [classification: annoying]
- No 'Fundamentals' session template — the concept central to step 2 of the eval has no dedicated starting point [classification: nice-to-have]
- Trade Ticket has no reasoning/notes field — manually placed orders always log '--' in the Reasoning column [classification: nice-to-have]
- No guided API key setup flow for finnhub / fred / edgar — users are left with 'not initialized' and no next step [classification: nice-to-have]
- No way to see the session's stock universe from the dashboard — need to re-open session creator to recall it [classification: nice-to-have]

## Required Docs Updates (mandatory — Team D scope)

Every bug-hunt iteration MUST produce a docs commit that touches the following.
Skip an item ONLY if it is genuinely not applicable; in that case state so explicitly
in the docs commit message ("LESSONS.md: no new lessons this iteration"). Do not
silently omit.

1. `docs/REMAINING_TASKS.md` — close items resolved this iteration; add a "Bug Hunt
   20260505T213116Z45f1 — Closed" subsection mirroring prior iteration patterns.
2. `docs/LESSONS.md` — append at least one lesson per real-broken finding that
   exposed a class of mistake (triage misread, CSP/CSS footgun, agent isolation
   leak, false-positive predicate, etc.). Lessons must be reusable rules, not
   a recap of the diff.
3. `docs/ARCHITECTURE.md` — update if any: CSP / security-headers / middleware
   stack / route surface / schema field / plugin registry / dashboard surface
   changed. Skip with explicit note if untouched.
4. `docs/KNOWN_FAILURES.md` — pre-flight refresh and any pre-existing failure
   resolved this iteration removed.
5. `docs/decisions/` — add a 1-page record only if a non-trivial reversible
   decision was made (e.g., "remove Sentry, rely on /v1/client-errors").
6. `docs/bug-hunt/20260505T213116Z45f1/` — stage and commit every artifact produced this
   iteration (plan.md, triage.md, triage.json, blind_report.json, cleanup.log,
   isolation_warning.txt if present, team_*_verify.md, blind_diagnostic.log,
   deploy_status.txt, retest_results.json). No artifact left untracked.
7. `docs/bug-hunt/ledger.jsonl` — Team E MUST append exactly one JSON line per
   real-broken finding closed this iteration, using this flat schema:
       {"iteration_ts":"20260505T213116Z45f1","finding_id":"<short-slug>","category":"<tag>",
        "summary":"<short>","scope_files":["dashboard/x.js"],
        "team":"<A|B|C|D|E|...>","commit":"<merge-sha-on-main>"}
   Reuse existing categories from the ledger; only mint a new tag if no
   existing one fits. The `commit` field is the merge SHA on `main` for the
   team that closed the item — read it from `git log` after merges. Validation
   hint: after Team E commits, `wc -l docs/bug-hunt/ledger.jsonl` should grow
   by exactly the number of broken items closed this iteration.
8. `docs/bug-hunt/pending_recurrences.jsonl` — if Phase 5.5 produced new
   patch-ineffective signals, the orchestrator already appended them inline (see
   Phase 5.5c). Team D MUST stage the file. If a refactor verdict pruned entries
   this iteration, Team D MUST also stage `docs/bug-hunt/pending_recurrences.resolved.jsonl`
   (the audit log of resolved signals).

Team D's commit message must reference iteration 20260505T213116Z45f1 and name which docs were
touched (e.g., "docs: bug-hunt 20260505T213116Z45f1 — record fixes for X; LESSONS +N; ARCHITECTURE
unchanged this iteration; ledger +N").
