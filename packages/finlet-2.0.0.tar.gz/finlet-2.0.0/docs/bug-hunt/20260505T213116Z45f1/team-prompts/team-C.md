You are Team C — Trade Ticket close removes panel visibility class.

CONTEXT:
- Plan: /Users/justnau/finlet/docs/bug-hunt/20260505T213116Z45f1/plan.md (read your team spec at "### Team C")
- Recon: /Users/justnau/finlet/docs/bug-hunt/20260505T213116Z45f1/recon.md (Surface 3)
- Working dir: this is your worktree. Worktree base auto-reset to 6df1b4f.

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first
- Read the "Read these files first" list BEFORE writing code:
  - `dashboard/trade-ticket.js:1-50` (render-on-read pattern), `:130-170` (openTradeTicket), `:240-280` (closeTradeTicket), `:340-500` (submitTradeTicket post-fill)
  - `dashboard/styles.css:2806-2890` — .trade-ticket and .trade-ticket--open visibility rules
  - `dashboard/index.html:425-440` — `<aside class="trade-ticket" id="trade-ticket-panel">` and backdrop structure
  - `docs/decisions/trade-ticket-render-on-read.md` — render-on-read v3 contract (cash header reads from canonical store; bus events are repaint TRIGGERS, never value carriers)
- Follow existing patterns in trade-ticket.js
- You MUST `git add` and `git commit` before finishing
- Commit message must start with "[Team C]:"
- Run validation before finishing

YOUR DELIVERABLE:
After a successful order fill, the Trade Ticket panel becomes invisible AND the backdrop becomes invisible AND the form is reset. Cash repaint and `portfolio:updated` bus publish remain unchanged.

ROOT CAUSE (explicit):
The recon's pasted snippet of `closeTradeTicket()` claimed it calls `window.finletModal.close("trade-ticket-modal")` — but the actual element id is `trade-ticket-panel`, NOT `trade-ticket-modal`. `finletModal.close()` against a non-existent id is a silent no-op (the controller's `findElement('trade-ticket-modal')` returns null). The trade-ticket panel is a `<aside class="trade-ticket">`, NOT a `.fl-modal`. So the controller never manages it. Visibility is controlled by the `.trade-ticket--open` class (CSS at styles.css:2822) which must be added/removed in trade-ticket.js itself.

YOUR FIRST TASK: read trade-ticket.js carefully and verify which class openTradeTicket adds and what closeTradeTicket actually does. The recon may have mis-pasted snippets — VERIFY against HEAD before fixing.

IMPLEMENTATION:
- In `closeTradeTicket()`: explicitly run `panel.classList.remove('trade-ticket--open')` AND remove `trade-ticket-backdrop--visible` from the backdrop AND form.reset(). If any of these are already present, no harm — keep them.
- In `openTradeTicket()`: verify `panel.classList.add('trade-ticket--open')` is called. If missing (bug-symmetric to close), fix it.
- DO NOT remove the existing `window.finletModal.close('trade-ticket-modal')` call if it exists — leave it as a defensive no-op (or update the id to 'trade-ticket-panel' if you want the controller to ALSO track it; document choice in a one-line comment).
- Preserve the post-fill IIFE that fetches portfolio + publishes `portfolio:updated`. This stays as-is.

CONSTRAINT — render-on-read v3 contract (NON-NEGOTIABLE):
- Bus events stay as repaint TRIGGERS, never value carriers
- Cash repaint must read from `currentSession.portfolio_metrics.cash` (canonical store), NOT from event payload
- Do NOT introduce `bus.publish('portfolio:updated', { cash: someValue })` where someValue comes from anywhere other than the canonical store

FILES TO TOUCH:
- Modified: dashboard/trade-ticket.js (closeTradeTicket and possibly openTradeTicket only)
- DO NOT touch: dashboard/modal-controller.js (Team B), dashboard/styles.css (Team B), dashboard/app.js (Team A), dashboard/settings.js (Team D), dashboard/index.html

VALIDATION:
- `cd <worktree-root> && uv run pytest tests/dashboard -k trade -x -q` (if exists)
- `cd <worktree-root> && uv run ruff check dashboard/`
- Sanity check by reasoning: trace through openTradeTicket → submitTradeTicket success path → closeTradeTicket. Confirm panel.classList ends up WITHOUT trade-ticket--open and backdrop ends up WITHOUT trade-ticket-backdrop--visible.
- Sanity check render-on-read: confirm no bus event payload is read for the cash value

When done, report:
DONE
commit_hash: <sha>
validation: <pass/fail summary>
files_modified: <list>
notes: <any divergence from the recon-pasted snippets you found while verifying against HEAD>

OR:
BLOCKED
reason: <what went wrong>
