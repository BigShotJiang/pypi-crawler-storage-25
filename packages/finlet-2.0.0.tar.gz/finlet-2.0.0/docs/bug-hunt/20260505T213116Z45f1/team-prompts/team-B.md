You are Team B — modal stacking visibility fix.

CONTEXT:
- Plan: /Users/justnau/finlet/docs/bug-hunt/20260505T213116Z45f1/plan.md (read your team spec at "### Team B")
- Recon: /Users/justnau/finlet/docs/bug-hunt/20260505T213116Z45f1/recon.md (Surface 2)
- Working dir: this is your worktree. Worktree base auto-reset to 6df1b4f.

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first
- Read the "Read these files first" list BEFORE writing code:
  - `dashboard/modal-controller.js:55-250` — IIFE applyStackLayout, suppress, open, close
  - `dashboard/onboarding.js:475-490` — wizard's suppress() + open() flow
  - `dashboard/styles.css:80-130` — .fl-modal--visible rules
  - `docs/decisions/dashboard-modal-controller.md` — established convention
  - `docs/bug-hunt/refactor-queue/modal-stacking.md` — prior leaderboard fix (verdict: effective)
- Follow existing patterns in modal-controller.js
- You MUST `git add` and `git commit` before finishing
- Commit message must start with "[Team B]:"
- Run validation before finishing

YOUR DELIVERABLE:
When `create-session` opens while `onboarding` is in the stack, only `create-session` is visible (wizard hidden). When `create-session` closes, `onboarding` becomes visible again.

IMPLEMENTATION:
- Modify `applyStackLayout()` so non-top stack members AND suppressed modals get a visually-hidden state via a new class (e.g., `el.classList.add('fl-modal--hidden')`); top stack member gets the class removed.
- Add CSS rule `.fl-modal--hidden { display: none !important; }` (or `visibility: hidden; opacity: 0; pointer-events: none;` if CSS transitions need to play). Pick one and document the choice in a one-line comment.
- Preserve all existing pointer-events and z-index logic. The new class is ADDITIVE.

CONSTRAINT:
The trade-ticket panel (`<aside class="trade-ticket" id="trade-ticket-panel">`) is NOT a `.fl-modal` element. Your CSS rule applies only to `.fl-modal.fl-modal--hidden` — DO NOT make it apply to non-fl-modal elements (no `*--hidden` global rules). Use a class selector scoped to `.fl-modal`.

FILES TO TOUCH:
- Modified: dashboard/modal-controller.js (applyStackLayout function only)
- Modified: dashboard/styles.css (add ONE new rule scoped to `.fl-modal.fl-modal--hidden`)
- DO NOT touch: dashboard/trade-ticket.js, dashboard/onboarding.js, dashboard/app.js, dashboard/settings.js, dashboard/index.html

VALIDATION:
- `cd <worktree-root> && uv run pytest tests/dashboard -k modal -x -q` (if exists; otherwise note absence)
- `cd <worktree-root> && uv run ruff check dashboard/` — should pass; this is JS but ruff still checks docs
- Sanity check: open the file, verify `applyStackLayout` now toggles a visibility class on every iteration of the stack walk, in addition to existing z-index + pointer-events
- Sanity check: existing leaderboard modal flow (single-modal-only) still produces a visible modal — the `fl-modal--hidden` class should NOT be added when stack.length === 1 and the only entry is the topId.

When done, report:
DONE
commit_hash: <sha>
validation: <pass/fail summary>
files_modified: <list>

OR:
BLOCKED
reason: <what went wrong>
