You are Team A — Order Log fee disclosure.

CONTEXT:
- Plan: /Users/justnau/finlet/docs/bug-hunt/20260505T213116Z45f1/plan.md (read your team spec at the "### Team A" section)
- Recon: /Users/justnau/finlet/docs/bug-hunt/20260505T213116Z45f1/recon.md (Surface 1 quoted excerpts)
- Working dir: this is your worktree. Do NOT cd to /Users/justnau/finlet. The worktree base SHA has been auto-reset to 6df1b4f.

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first — do NOT report any of those tests as new issues
- Read the "Read these files first" list BEFORE writing any code:
  - `dashboard/app.js:2227-2280` — renderOrders() Total Cost cell construction
  - `dashboard/index.html:290-325` — Order Log table header
  - `finlet/api/schemas/trade.py:8-57` — OrderResponse fields
- Follow existing patterns in dashboard/app.js (use document.createElement + textContent, NOT innerHTML, per Trusted-Types convention; if you must wrap with innerHTML for a span+sub-line, use trustedHTML(...))
- You MUST `git add` and `git commit` all your changes before finishing
- Your commit message must start with "[Team A]:"
- Run validation before finishing
- If validation fails, fix the issue and re-commit

YOUR DELIVERABLE:
The Order Log row's Total Cost cell shows the gross / commission / slippage breakdown inline (no hover required) whenever (filled_price × qty) − total_cost is non-zero, AND explicitly indicates direction. Specifically:
- Add an always-visible sub-line below the total cost number, e.g. "= 10 × $560.897 (price improvement: $0.03)" or "= $5,609.00 + $0.03 commission".
- Remove the `commission > 0` and `slippage_amount > 0` filters in the breakdown loop (lines 2251-2256) so price improvement (negative slippage) is also disclosed.
- Keep the existing tooltip as supplementary backup.
- Edge case: if (filled_price × qty) exactly equals total_cost, do NOT render a noisy "= 10 × $560.90" line — only show when delta != 0.

FILES TO TOUCH:
- Modified: dashboard/app.js (renderOrders function only)
- DO NOT touch: dashboard/trade-ticket.js, dashboard/index.html, dashboard/styles.css, dashboard/modal-controller.js, dashboard/settings.js, finlet/api/schemas/trade.py, finlet/api/routes_plugins.py
- DO NOT touch any backend Python.

VALIDATION:
- `cd <worktree-root> && uv run pytest tests/dashboard -k orders -x -q` (if tests exist; if not, note "no test coverage for renderOrders inline breakdown — manual verification only")
- `cd <worktree-root> && uv run ruff check dashboard/`
- Manual reasoning: trace through the code change with a sample FILLED order: `{filled_price: 560.897, qty: 10, total_cost: 5608.97, commission: null, slippage_amount: null}` — confirm the breakdown line is rendered visibly without hover.

When done, report:
DONE
commit_hash: <sha>
validation: <pass/fail summary>
files_modified: <list>

OR if blocked:
BLOCKED
reason: <what went wrong>
