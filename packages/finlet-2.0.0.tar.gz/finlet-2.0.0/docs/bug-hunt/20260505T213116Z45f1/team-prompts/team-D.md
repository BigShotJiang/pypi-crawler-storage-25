You are Team D — Test Connection feedback updates plugin row DOM.

CONTEXT:
- Plan: /Users/justnau/finlet/docs/bug-hunt/20260505T213116Z45f1/plan.md (read your team spec at "### Team D")
- Recon: /Users/justnau/finlet/docs/bug-hunt/20260505T213116Z45f1/recon.md (Surface 4)
- Working dir: this is your worktree. Worktree base auto-reset to 6df1b4f.

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` first
- Read the "Read these files first" list BEFORE writing code:
  - `dashboard/settings.js:1110-1120` — [data-action="test-plugin"] click handler
  - `dashboard/settings.js:1340-1370` — testPlugin() function (current toast-only feedback)
  - `finlet/api/routes_plugins.py:1-83` — /plugins/health endpoint
  - `dashboard/CLAUDE.md` — render-on-read for persistent-DOM bus-mirror surfaces; Trusted-Types convention
- Follow existing patterns in dashboard/settings.js
- You MUST `git add` and `git commit` before finishing
- Commit message must start with "[Team D]:"
- Run validation before finishing

YOUR DELIVERABLE:
Clicking Test Connection on `fundamentals_s3` causes:
(a) the existing toast (preserved unchanged), AND
(b) the plugin row's status text updates to reflect freshly-fetched health (e.g., "OK — 21 cached files (tested HH:MM:SS, 12ms)" with latency_ms appended), AND
(c) a small "tested at" timestamp text appears or updates on the row.

The change is durable: the toast can fade, the DOM update remains.

IMPLEMENTATION:
- Extend `testPlugin(pluginName)` to:
  1. After the apiFetch resolves and pluginHealth is identified
  2. Locate the plugin row via `document.querySelector('[data-plugin-name="<name>"]')`
  3. Find the status pill / row text element within it (read the existing settings.html or settings render logic to find the right selector)
  4. Update its textContent (NOT innerHTML) to reflect the fresh status
  5. Add or update a "tested at" timestamp element on the row (use new Date().toLocaleTimeString() or similar)
  6. Keep the existing showToast() calls unchanged
- DO NOT add a new backend endpoint. The /plugins/health endpoint already returns fresh data per call.
- DO NOT introduce innerHTML writes. Use textContent or trustedHTML(...) per Trusted-Types convention.

DEFENSIVE NOTE:
If, while reading the code, you discover that `showToast()` itself is broken (no toast container, broken CSS, dead selector), record that finding in your DONE message but do NOT fix it in this team. The DOM update is the durable fix; toast resilience is separate scope.

FILES TO TOUCH:
- Modified: dashboard/settings.js (testPlugin function only)
- DO NOT touch: dashboard/app.js (Team A), dashboard/modal-controller.js + styles.css (Team B), dashboard/trade-ticket.js (Team C), dashboard/index.html, finlet/api/routes_plugins.py, finlet/core/

VALIDATION:
- `cd <worktree-root> && uv run pytest tests/dashboard -k plugin -x -q` (if tests exist)
- `cd <worktree-root> && uv run ruff check dashboard/`
- Sanity check by reasoning: trace through testPlugin('fundamentals_s3') with a mock response `{name: 'fundamentals_s3', status: 'healthy', latency_ms: 12, error: null}` — confirm the DOM update path runs and the row's status text changes.
- Edge case: test a plugin returning unhealthy — DOM should reflect the error message, not silent.

When done, report:
DONE
commit_hash: <sha>
validation: <pass/fail summary>
files_modified: <list>
notes: <any toast-resilience or other findings observed>

OR:
BLOCKED
reason: <what went wrong>
