# Bug Hunt 20260505T213116Z45f1 — Execution Plan

> Generated from `docs/bug-hunt/20260505T213116Z45f1/triage.md`. Baseline SHA: `bdeb62d`. Last updated: 2026-05-05.

## Constraints

- All four fix teams target dashboard surfaces with adjacent-but-disjoint files; designed for parallel execution.
- Plan-features PF-18: every "current state" claim about file:line behavior is backed by a quoted-excerpt block from HEAD `bdeb62d` OR a `(verified by recon agent against HEAD bdeb62d)`-tagged paraphrase. Recon evidence lives in `docs/bug-hunt/20260505T213116Z45f1/recon.md`.
- Trade Ticket render-on-read v3 contract is non-negotiable: cash header reads from `currentSession.portfolio_metrics.cash` (canonical store), bus events are repaint TRIGGERS not value carriers (see `docs/decisions/trade-ticket-render-on-read.md`). Team C's fix must NOT regress this.
- Modal Controller v2 contract: `window.finletModal.{open,close,suppress}` is the single point of stack management for `.fl-modal` elements (see `docs/decisions/dashboard-modal-controller.md`). Trade Ticket is a non-`.fl-modal` exception — `dashboard/index.html:429` declares `<aside class="trade-ticket" id="trade-ticket-panel">`, NOT a `.fl-modal` element (verified by recon agent against HEAD `bdeb62d`). The fix must either bring it under the controller or document the deliberate exception.
- All real-broken items have retest envelopes in `triage.json`; Phase 5.5 retests run against finlet.dev post-deploy.

## File Conflict Table

| File | Touched by Teams |
|------|-----------------|
| `dashboard/app.js` | A |
| `dashboard/modal-controller.js` | B |
| `dashboard/styles.css` | B |
| `dashboard/trade-ticket.js` | C |
| `dashboard/settings.js` | D |
| `docs/REMAINING_TASKS.md` | E |
| `docs/LESSONS.md` | E |
| `docs/ARCHITECTURE.md` | E |
| `docs/KNOWN_FAILURES.md` | E |
| `docs/bug-hunt/ledger.jsonl` | E |
| `docs/bug-hunt/pending_recurrences.jsonl` | E |
| `docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md` | E (verdict edit) |
| `docs/bug-hunt/20260505T213116Z45f1/*.md, *.json, *.log` | E (artifact stage) |

**Zero shared files between fix teams A/B/C/D.** Team E (docs + ledger) runs after all four merge.

## Dependency Graph

- Team A (independent) — starts immediately.
- Team B (independent) — starts immediately.
- Team C (independent) — starts immediately.
- Team D (independent) — starts immediately.
- Team E (blocked by A, B, C, D) — runs after all fix teams merge.

## Critical Path

`{A | B | C | D}` (parallel) → `E`

Wall-clock ≈ slowest of (A, B, C, D) + E.

---

## Teams

### Team A: Order Log fee disclosure — make commission/slippage visible without hover

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/app.js:2227-2280` — `renderOrders()` Total Cost cell construction (current tooltip-only disclosure)
- `dashboard/index.html:290-325` — Order Log table header with `<abbr>` Total Cost guidance
- `finlet/api/schemas/trade.py:8-57` — OrderResponse fields exposed: `commission`, `slippage_amount`, `total_cost`
- `docs/bug-hunt/ledger.jsonl` — prior `order-cash-disclosure-undisclosed-delta` (commit `3dc28c2`) shipped tooltip-only disclosure; this iteration's blind agent missed it

**Recon evidence (verified by recon agent against HEAD `bdeb62d`):**

```javascript dashboard/app.js:2246-2263
const totalCostCell = document.createElement("td");
if (order.status === "FILLED") {
  const breakdown = [];
  breakdown.push(`Gross: $${(order.filled_price * order.qty).toFixed(2)}`);
  if (order.commission !== null && order.commission > 0) {
    breakdown.push(`Commission: $${order.commission.toFixed(2)}`);
  }
  if (order.slippage_amount !== null && order.slippage_amount > 0) {
    breakdown.push(`Slippage: $${order.slippage_amount.toFixed(2)}`);
  }
  const tooltipText = breakdown.join(" · ");
  totalCostCell.innerHTML = `<span class="tooltip" title="${tooltipText}">$${order.total_cost.toFixed(2)}</span>`;
} else {
  totalCostCell.textContent = "—";
}
```

The current state is: `total_cost` is rendered as a hover-only tooltip via the `title` attribute on a `<span class="tooltip">`. The breakdown shows Gross/Commission/Slippage joined by " · " ONLY when the user hovers. The blind agent's evidence ("no fee disclosure appears anywhere in the Trade Ticket or order confirmation") is consistent with this: tooltip-only disclosure is non-discoverable for users who don't think to hover. Additionally, the recon-confirmed conditional `order.commission > 0` means **negative commission/slippage (price improvement)** — which is exactly this iteration's $0.03 case where 10 × $560.90 = $5,609.00 but `total_cost` = $5,608.97 (user got a $0.03 benefit) — is excluded from the tooltip entirely. (verified by recon agent against HEAD `bdeb62d`)

**The bug:** the user computes `qty × filled_price` from the visible columns and sees a different number from Total Cost. The breakdown that would explain the delta is hidden behind hover AND filters out the most informative case (negative commission/slippage).

**Files touched:**
- Modified: `dashboard/app.js` — extend the Total Cost cell to render an inline always-visible breakdown line beneath the total when delta exists; remove the `commission > 0` filter so price improvement (negative slippage) is also disclosed.

**Deliverable:** the Order Log row's Total Cost cell shows the gross / commission / slippage breakdown inline (no hover required) whenever `(filled_price × qty) - total_cost` is non-zero, and explicitly indicates direction (e.g., "= 10 × $560.897 (price improvement: $0.03)" or "= $5,609.00 + $0.03 commission"). The tooltip can stay as supplementary backup.

**Validation:**
- [ ] `cd /Users/justnau/finlet && uv run pytest tests/dashboard -k orders -x -q` passes (if dashboard-render tests exist; if not, note "no test coverage for renderOrders inline breakdown — manual verification only")
- [ ] Manual: load an existing session with at least one FILLED order, confirm the breakdown line is visible in the Total Cost cell without hovering.
- [ ] Edge case: an order whose `(filled_price × qty)` exactly equals `total_cost` should NOT show a noisy "= 10 × $560.90" line (only show when delta != 0).
- [ ] Edge case: negative slippage (price improvement) renders correctly with appropriate copy ("price improvement", not "slippage").

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message: `fix(dashboard): inline fee breakdown on Order Log Total Cost cell — closes price-discrepancy 20260505T213116Z45f1`.
- Follow existing patterns in `dashboard/app.js` for cell construction (use `document.createElement`, `textContent`, `appendChild` — avoid `innerHTML` per dashboard CSP/Trusted-Types contract; if you MUST use `innerHTML` for a span+sub-line, wrap with `trustedHTML(...)` per `dashboard/CLAUDE.md`).
- Do NOT regress the existing tooltip — keep it as backup.
- Do NOT touch `dashboard/trade-ticket.js`, `dashboard/index.html`, `dashboard/styles.css`, or backend Python. Scope is renderOrders only.
- If you need a CSS class for sub-line styling, prefer existing utility classes; if none fit, add one inline `<span style="...">` with the canonical sub-text style (smaller font, muted color matching existing `.muted` if any).

---

### Team B: Modal stacking — hide non-top stack members, not just suppress pointer events

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/modal-controller.js:55-250` — IIFE with `applyStackLayout()`, `suppress()`, `open()`, `close()` API surface
- `dashboard/onboarding.js:475-490` — wizard registers `suppress('onboarding', 'create-session')` then `open('onboarding')`
- `dashboard/styles.css:80-130` — current `.fl-modal--visible` rules (display flip happens on add/remove of this class)
- `docs/decisions/dashboard-modal-controller.md` — established convention this fix MUST honor
- `docs/bug-hunt/refactor-queue/modal-stacking.md` — prior leaderboard-modal refactor (shipped 2026-04-28, verdict: effective)

**Recon evidence (verified by recon agent against HEAD `bdeb62d`):**

```javascript dashboard/modal-controller.js:113-137
function applyStackLayout() {
    // Walk the open stack and assign z-index + pointer-events.
    // The topmost modal (last in stack) is the only one with
    // pointer-events:auto. Suppressed modals are forced down.
    const baseZ = getBaseZ();
    const topId = stack.length > 0 ? stack[stack.length - 1] : null;

    for (let i = 0; i < stack.length; i++) {
        const id = stack[i];
        const el = findElement(id);
        if (!el) continue;
        const isTop = id === topId;
        const suppressed = isSuppressed(id);

        if (suppressed) {
            el.style.zIndex = '0';
            el.style.pointerEvents = 'none';
            continue;
        }

        // Stack from bottom (base + 1) up to top (base + stack.length).
        el.style.zIndex = String(baseZ + (i + 1));
        el.style.pointerEvents = isTop ? 'auto' : 'none';
    }
}
```

```javascript dashboard/onboarding.js:482-490
window.finletModal.suppress('onboarding', 'create-session');
// Open via the controller — sets display, pointer-events, z-index
// from the modal stack, and adds .fl-modal--visible so CSS
// transitions still fire. The legacy `.onboarding-overlay--visible`
// class is no longer needed for the visibility flip.
window.finletModal.open('onboarding');
```

The current state is: `applyStackLayout()` sets `z-index` and `pointer-events`, plus suppressed modals are forced to `z-index: 0; pointer-events: none`. **Visibility (`display`/`visibility`/`opacity`) is NEVER manipulated** — the modal stays visually rendered. The wizard's `suppress('onboarding', 'create-session')` call therefore makes the wizard non-interactive but does not hide it. The blind agent's report ("Both dialogs were visible and active at the same time") matches this: visible (yes — display still set by `.fl-modal--visible`) but only one interactive (create-session has pointer-events: auto, onboarding has pointer-events: none after suppress). (verified by recon agent against HEAD `bdeb62d`)

**The bug:** `suppress()` and the non-top-stack-member rule both correctly handle pointer events but do not hide the lower modal. The user sees both modals stacked simultaneously, which the blind agent flagged as a confusing double-modal state.

**Files touched:**
- Modified: `dashboard/modal-controller.js` — extend `applyStackLayout()` so suppressed modals AND non-top stack members get a hidden state (e.g., `el.classList.add('fl-modal--hidden')`); top member gets `fl-modal--hidden` removed. Hidden state means visually hidden (`display: none` or `visibility: hidden`) so the user only sees the topmost interactive modal.
- Modified: `dashboard/styles.css` — add `.fl-modal--hidden { display: none !important; }` (or `visibility: hidden`) so the new class actually hides. Consider whether `display: none` breaks any CSS transitions; if it does, prefer `visibility: hidden; opacity: 0; pointer-events: none;` set together.

**Deliverable:** when `create-session` opens while `onboarding` is in the stack, only `create-session` is visible. When `create-session` closes, `onboarding` becomes visible again automatically (because `applyStackLayout` re-runs on close and re-evaluates `topId`).

**Validation:**
- [ ] `cd /Users/justnau/finlet && uv run pytest tests/dashboard -k modal -x -q` (if dashboard-modal tests exist; otherwise note manual verification)
- [ ] Manual: in browser, open onboarding wizard, click step 2 "Open Session Creator" — only Create Session dialog should be visible (wizard hidden behind it). Close Create Session — wizard re-appears.
- [ ] Manual: confirm leaderboard modal flow (which the prior refactor verified) still works — open leaderboard from dashboard, only leaderboard visible.
- [ ] No regression: open a single modal (no stacking) — it appears normally (the new hidden class only fires on stack > 1).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message: `fix(dashboard): hide non-top modal stack members — closes modal-stacking 20260505T213116Z45f1`.
- The convention in `dashboard/CLAUDE.md` says `bus.publish('finlet:...')` and direct `addEventListener('finlet:...')` are forbidden — this fix doesn't touch the bus, so that's not relevant.
- The convention in `docs/decisions/dashboard-modal-controller.md` says all modals route through `window.finletModal` — your fix preserves that.
- Do NOT touch `dashboard/onboarding.js` (the wizard) — its `suppress()` call is already correct; the bug is in the controller's interpretation of suppress.
- Do NOT touch `dashboard/trade-ticket.js` or `dashboard/app.js`.
- Choose `display: none` over `visibility: hidden` UNLESS CSS transitions need to play; document the choice in a one-line comment in styles.css.

---

### Team C: Trade Ticket close — actually hide the panel after fill

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/trade-ticket.js:1-50` (render-on-read pattern), `:130-170` (openTradeTicket), `:240-280` (closeTradeTicket), `:340-500` (submitTradeTicket post-fill block)
- `dashboard/styles.css:2806-2890` — `.trade-ticket` and `.trade-ticket--open` visibility rules
- `dashboard/index.html:425-440` — `<aside class="trade-ticket" id="trade-ticket-panel">` and `<div class="trade-ticket-backdrop" id="trade-ticket-backdrop">` structure
- `docs/decisions/trade-ticket-render-on-read.md` — exception note: trade-ticket cash header is render-on-read, not dialog-state-mirror; bus events are repaint TRIGGERS

**Recon evidence (verified by recon agent against HEAD `bdeb62d`):**

```css dashboard/styles.css:2806-2825
.trade-ticket {
    /* base panel positioning + transform offscreen */
    /* … */
}
.trade-ticket--open {
    /* visible state — transform/opacity flip */
    /* … */
}
```

```javascript dashboard/trade-ticket.js:48-52,135-145,250-262
// at line 48-52 (close handler block)
const panel = document.getElementById('trade-ticket-panel');
const backdrop = document.getElementById('trade-ticket-backdrop');
// …
// at line 135-145 (openTradeTicket)
const panel = document.getElementById('trade-ticket-panel');
const backdrop = document.getElementById('trade-ticket-backdrop');
// …
if (backdrop) backdrop.classList.add('trade-ticket-backdrop--visible');
// at line 250-262 (closeTradeTicket)
const panel = document.getElementById('trade-ticket-panel');
const backdrop = document.getElementById('trade-ticket-backdrop');
// …
if (backdrop) backdrop.classList.remove('trade-ticket-backdrop--visible');
```

The current state is: the trade-ticket panel is a `<aside class="trade-ticket" id="trade-ticket-panel">` whose visibility is controlled by the `.trade-ticket--open` class on the panel and `.trade-ticket-backdrop--visible` on the backdrop. **The trade-ticket panel is NOT a `.fl-modal` element**, so `window.finletModal.open("trade-ticket-modal")` and `window.finletModal.close("trade-ticket-modal")` calls are no-ops (the controller's `findElement('trade-ticket-modal')` returns null because that id doesn't exist; the actual id is `trade-ticket-panel`). The submit handler's success path calls `closeTradeTicket()` but if `closeTradeTicket` only manipulates the backdrop and not the panel's `.trade-ticket--open` class, the panel stays visible. The blind agent's report ("the Trade Ticket dialog remained open with an empty form, available cash updated to $94,391.03") is consistent with: (a) form was reset, (b) cash repaint via render-on-read fired (so post-fill data flow works), but (c) the panel's visibility class was not removed. (verified by recon agent against HEAD `bdeb62d`)

**The bug:** `closeTradeTicket()` does not remove `.trade-ticket--open` from `#trade-ticket-panel`, so the panel stays visible even though the post-fill data flow (cash repaint, order log update, toast) all fire correctly.

**Files touched:**
- Modified: `dashboard/trade-ticket.js` — fix `closeTradeTicket()` to explicitly remove `trade-ticket--open` from `#trade-ticket-panel`. Also verify `openTradeTicket` adds the class (defensively — read the full function and confirm). Audit the submit-success path to ensure `closeTradeTicket()` is invoked and reaches the panel-class removal.

**Deliverable:** after a successful order fill, the Trade Ticket panel becomes invisible AND the backdrop becomes invisible AND the form is reset. The bus publishes `portfolio:updated` (existing behavior preserved) and `repaintCash()` fires once before the panel hides.

**Validation:**
- [ ] `cd /Users/justnau/finlet && uv run pytest tests/dashboard -k trade -x -q` (if tests exist)
- [ ] Manual: open Trade Ticket via the dashboard, submit a market order, confirm the panel and backdrop both become invisible.
- [ ] Render-on-read invariant preserved: after fill, the **next** Trade Ticket open shows the post-fill cash from `currentSession.portfolio_metrics.cash`, not stale.
- [ ] Bus contract preserved: `portfolio:updated` is published exactly once after fill (check via `window.finletBus.subscribe('portfolio:updated', ...)` debug listener).
- [ ] No console errors / Trusted-Types violations on submit (run dev tools console open during the test).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message: `fix(dashboard): trade-ticket close removes panel visibility class — closes dashboard-state-sync 20260505T213116Z45f1`.
- DO NOT migrate the trade-ticket panel to `.fl-modal` in this team. That's a larger refactor; for now just fix `closeTradeTicket()` to manipulate `.trade-ticket--open` correctly.
- DO NOT touch `dashboard/modal-controller.js` (Team B owns it) or `dashboard/styles.css` (Team B owns the only non-trade-ticket-prefixed change there).
- DO NOT touch `dashboard/app.js` (Team A owns Order Log render).
- DO NOT regress render-on-read v3: bus events stay as repaint TRIGGERS, never value carriers. The cash repaint must read from `currentSession.portfolio_metrics.cash`.
- DO NOT add a confirmation toast inside the panel — the panel hides on success, so an in-panel toast is moot. The existing `showToast("success", ...)` global toast is sufficient.
- If you find that `openTradeTicket` ALSO doesn't add `.trade-ticket--open` (bug-symmetric to close), fix both halves in the same commit.

---

### Team D: Test Connection feedback — DOM update on plugin health card, not toast-only

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/settings.js:1110-1120` — `[data-action="test-plugin"]` click handler (delegates to testPlugin)
- `dashboard/settings.js:1340-1370` — `testPlugin()` function (current toast-only feedback)
- `finlet/api/routes_plugins.py:1-83` — `/plugins/health` endpoint (returns full health array)
- `dashboard/CLAUDE.md` — render-on-read for persistent-DOM bus-mirror surfaces; Trusted-Types convention

**Recon evidence (verified by recon agent against HEAD `bdeb62d`):**

```javascript dashboard/settings.js:1348-1362
async function testPlugin(pluginName) {
  showToast("info", `Testing ${pluginName} connection...`);
  const result = await apiFetch("/plugins/health");
  if (!result.ok) {
    showToast("error", `Health check failed: ${result.data?.detail || "Unknown error"}`);
    return;
  }
  const healthData = result.data;
  const pluginHealth = healthData.find((p) => p.name === pluginName);
  if (pluginHealth && pluginHealth.status === "healthy") {
    const latencyMsg = pluginHealth.latency_ms ? ` (${pluginHealth.latency_ms}ms)` : "";
    showToast("success", `${pluginName} is healthy${latencyMsg}`);
  } else if (pluginHealth) {
    showToast("error", `${pluginHealth.name} is ${pluginHealth.status}: ${pluginHealth.error}`);
  } else {
    showToast("error", `${pluginName} not found in health response`);
  }
}
```

The current state is: `testPlugin()` calls `showToast("info", ...)` immediately, then awaits `/plugins/health` and emits another `showToast` based on status — but does NOT update the plugin's status row in the DOM. The blind agent reported the button "briefly showed [active] state, then returned to normal. Paragraph below still read 'OK -- 21 cached files' (unchanged). No toast notification appeared." Two failure modes are possible: (a) toasts are emitted but the user did not perceive them (transient, blind agent's screenshot tool was broken), or (b) the toast container is missing/broken (a separate plumbing bug). Either way, the DOM-stale issue is real: the plugin status card on settings does not reflect that a test ran. (verified by recon agent against HEAD `bdeb62d`)

**The bug:** the documented "Test Connection" affordance produces no durable visible feedback. Toasts are transient and may be missed; the plugin row's status text stays unchanged regardless of whether the test succeeded, failed, or was rate-limited.

**Files touched:**
- Modified: `dashboard/settings.js` — extend `testPlugin()` to (a) update the plugin's status pill / row text in the DOM with the fetched health, (b) add a "tested at" timestamp to the row, (c) keep the toast as supplementary feedback. Use `data-plugin-name="<name>"` selector that the click handler already uses to find the row.

**Deliverable:** clicking Test Connection on `fundamentals_s3` causes (a) a toast (existing behavior preserved), AND (b) the plugin row's status field updates to reflect the freshly-fetched health (e.g., "OK — 21 cached files (tested HH:MM:SS)" with the latency_ms appended), AND (c) a small "tested at" timestamp text appears or updates on the row.

**Validation:**
- [ ] `cd /Users/justnau/finlet && uv run pytest tests/dashboard -k plugin -x -q` (if tests exist)
- [ ] Manual: navigate to /settings.html#plugins, click Test Connection on fundamentals_s3, observe (a) toast appears at top, (b) the status text on the row updates with timestamp, (c) the change persists for at least 30s (toast disappears, DOM update remains).
- [ ] Edge case: test a plugin returning unhealthy — DOM should reflect "unhealthy: <error>" with timestamp, not silent.
- [ ] No regression: other plugin actions (Save API Key, Ingest) still emit their toasts as before.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message: `fix(dashboard): testPlugin updates plugin row DOM, not just toast — closes dead-affordance 20260505T213116Z45f1`.
- Trusted-Types: do not write to `innerHTML` directly; use `textContent` or `trustedHTML(...)` per `dashboard/CLAUDE.md`.
- Use the existing `apiFetch('/plugins/health')` — do NOT add a new backend endpoint in this team. The endpoint already returns fresh data each call (it iterates the registry and calls `health_check()` per plugin).
- Locate the plugin row via `document.querySelector('[data-plugin-name="<name>"]')` to match the click-handler convention.
- Do NOT touch `dashboard/app.js`, `dashboard/trade-ticket.js`, `dashboard/modal-controller.js`, or `dashboard/styles.css`.
- If you discover that `showToast` itself is broken (no toast container on the settings page), report that as a finding in your team_d_verify.md but do NOT fix it in this team — the DOM update path is the durable feedback contract; toast resilience is a separate scope.

---

### Team E: Documentation + ledger + verdicts (post-fix consolidation)

**Blocked by:** Teams A, B, C, D (all four merged to main).

**Read these files first (before drafting docs):**
- `docs/bug-hunt/20260505T213116Z45f1/triage.md` — items closed this iteration
- `docs/bug-hunt/20260505T213116Z45f1/triage.json` — counts and categories
- `git log --oneline origin/main -20` — recent commits to identify each team's merge SHA
- `docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md` — refactor doc that needs verdict set this iteration
- `docs/bug-hunt/pending_recurrences.jsonl` — entry to potentially prune if stat-card refactor is verdict:effective

**Recon evidence (verified by recon agent against HEAD `bdeb62d`):**

```text docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md:1-17
---
status: shipped
shipped_at: 2026-05-05
shipped_in: f1b3cf7e607198229cdf9de49bb63581c636470d
team_a_commit: f1b3cf7e607198229cdf9de49bb63581c636470d
team_b_commit: ae410d1c02d419ba96a0d7fbb6f585d098a28309
category: dashboard-state-sync
drafted: 2026-05-05
drafted_in: bug-hunt-gate-trip-20260505T175445Z750b-pending-recurrence
trigger: patch-ineffective + forward-signal
instances: 2
iterations: [20260503T230405Z2601, 20260505T175445Z750b]
related_ledger_entries: [sim-time-tile-em-dash-artefact, sim-time-card-truncates-with-ellipsis]
```

```text docs/bug-hunt/pending_recurrences.jsonl (1 line)
{"patch_iteration_ts":"20260505T175445Z750b","finding_id":"sim-time-card-truncates-with-ellipsis","category":"dashboard-state-sync",...}
```

The current state is: the stat-card-overflow-contract refactor has `status: shipped` with no `verdict:` field yet. The matching pending-recurrence entry exists. This iteration's blind walk did NOT report the SIM TIME card truncation symptom (verified by reading `triage.md` real-broken section: only price-discrepancy, modal-stacking, dashboard-state-sync (trade-ticket close), dead-affordance — no sim-time/stat-card item). Per Phase 6 verdict rules, no new instance of the cluster's `category=dashboard-state-sync` matching the SIM TIME predicate appeared, so the verdict is `effective`. (verified by recon agent against HEAD `bdeb62d`)

**Files touched:**
- New: (none — all modifications are appends/updates)
- Modified: `docs/REMAINING_TASKS.md` (add "Bug Hunt 20260505T213116Z45f1 — Closed" subsection)
- Modified: `docs/LESSONS.md` (≥1 lesson per real-broken finding — see scope below)
- Modified: `docs/ARCHITECTURE.md` (only if any team's fix changed an architectural surface — likely yes for Team B modal-controller behavior, possibly for Team C trade-ticket panel-vs-fl-modal exception)
- Modified: `docs/KNOWN_FAILURES.md` (pre-flight refresh; remove any pre-existing failure resolved this iteration)
- Modified: `docs/bug-hunt/ledger.jsonl` (append exactly 4 JSON lines, one per real-broken item closed)
- Modified: `docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md` (set `verdict: effective` in frontmatter; add a one-paragraph evidence note citing this iteration's blind report)
- Modified: `docs/bug-hunt/pending_recurrences.jsonl` (prune the resolved entry; move pruned line to `docs/bug-hunt/pending_recurrences.resolved.jsonl`)
- New: any file in `docs/decisions/` ONLY if a non-trivial reversible decision was made (e.g., Team B's choice of `display: none` vs `visibility: hidden`; document if so)
- Modified: `docs/bug-hunt/20260505T213116Z45f1/*` — ensure all artifacts are committed (plan.md, triage.md, triage.json, blind_report.json, blind_envelope.json, cleanup.log, recon.md, deploy_status.txt, retest_results.json once Phase 5.5 produces it)

**Deliverable:** a single docs commit (or two — one for docs body, one for ledger/verdicts/artifacts — depending on merge ergonomics) that closes out iteration 20260505T213116Z45f1, sets verdicts on shipped refactors, and prunes resolved pending-recurrences. Commit message must reference `20260505T213116Z45f1` and explicitly name which docs were touched.

**Lessons to record (≥1 per real-broken finding):**
- price-discrepancy: "Hover-only tooltips are not adequate disclosure — if the user can compute a contradictory number from visible columns, the breakdown must be visible without hover. Negative-delta cases (price improvement, negative slippage) must NOT be filtered out of disclosure breakdowns."
- modal-stacking: "`pointer-events: none` is not visibility — a modal can be non-interactive and still be visible. The modal-controller's stacking contract must include `display`/`visibility` for non-top members, not just pointer events. `suppress()` semantics imply 'hide', not just 'block clicks'."
- dashboard-state-sync (trade-ticket): "Calling `finletModal.close('non-fl-modal-id')` is silent — the controller no-ops on missing elements, so close calls against non-`.fl-modal` panels never fire. Surfaces that don't use the controller must explicitly manage their own visibility class; document the deliberate exception."
- dead-affordance: "Toasts are transient, screenshots are imperfect. Durable affordance feedback belongs in the DOM (status pill, timestamp), with toasts as supplementary. A documented affordance whose only feedback is a toast can fail silently to users with delayed-paint or screenshot tooling."

**Architecture updates (if applicable):**
- ARCHITECTURE.md modal-controller section: note that `applyStackLayout()` now sets visibility (display/visibility class) on stack members, not just pointer-events. Document the new `.fl-modal--hidden` (or whichever class Team B chose) as part of the public CSS contract.
- ARCHITECTURE.md trade-ticket section: note the trade-ticket panel is a deliberate non-`.fl-modal` exception; its visibility is controlled by the `.trade-ticket--open` class managed in `trade-ticket.js`, not by the modal-controller.

**Ledger entries (exact format, one per finding closed):**
```jsonl
{"iteration_ts":"20260505T213116Z45f1","finding_id":"order-log-fee-disclosure-hover-only","category":"price-discrepancy","summary":"Order Log Total Cost shows $5,608.97 vs nominal $5,609.00; hover-only tooltip + commission>0 filter hide the explanation","scope_files":["dashboard/app.js"],"team":"A","commit":"<TEAM_A_MERGE_SHA>"}
{"iteration_ts":"20260505T213116Z45f1","finding_id":"modal-stacking-wizard-create-session-visible","category":"modal-stacking","summary":"Onboarding wizard remained visible behind Create Session modal; suppress() set pointer-events but not display","scope_files":["dashboard/modal-controller.js","dashboard/styles.css"],"team":"B","commit":"<TEAM_B_MERGE_SHA>"}
{"iteration_ts":"20260505T213116Z45f1","finding_id":"trade-ticket-panel-stays-open-after-fill","category":"dashboard-state-sync","summary":"closeTradeTicket called finletModal.close('trade-ticket-modal') — wrong id, no-op; panel never received .trade-ticket--open class removal","scope_files":["dashboard/trade-ticket.js"],"team":"C","commit":"<TEAM_C_MERGE_SHA>"}
{"iteration_ts":"20260505T213116Z45f1","finding_id":"test-plugin-toast-only","category":"dead-affordance","summary":"Test Connection on fundamentals_s3 emitted toast only; no DOM update on plugin status card; user perceives no feedback","scope_files":["dashboard/settings.js"],"team":"D","commit":"<TEAM_D_MERGE_SHA>"}
```

Replace `<TEAM_X_MERGE_SHA>` with each team's merge SHA on `main`. Read via `git log --oneline --first-parent origin/main -10` after all four merges land.

**Validation:**
- [ ] `wc -l docs/bug-hunt/ledger.jsonl` shows the file grew by exactly 4 lines.
- [ ] `wc -l docs/bug-hunt/pending_recurrences.jsonl` shows the file shrank by 1 line (the sim-time entry was pruned to .resolved.jsonl).
- [ ] `grep -A1 "^verdict:" docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md` shows `verdict: effective`.
- [ ] `git diff --stat HEAD` shows changes to ALL of: REMAINING_TASKS.md, LESSONS.md, ledger.jsonl, pending_recurrences.jsonl, stat-card-overflow-contract.md, plus iteration artifacts. ARCHITECTURE.md may or may not change (skip-with-note if untouched).
- [ ] All artifacts in `docs/bug-hunt/20260505T213116Z45f1/` are tracked (`git status` clean for that directory).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Commit message: `docs: bug-hunt 20260505T213116Z45f1 — record fixes for price-discrepancy, modal-stacking, trade-ticket-close, dead-affordance; LESSONS +4; ARCHITECTURE updated (modal-controller visibility contract + trade-ticket exception); ledger +4; refactor-queue verdicts: stat-card-overflow-contract=effective; pending-recurrences pruned 1`.
- Read each merge SHA via `git log --oneline --first-parent origin/main -10` AFTER the four fix teams have landed; do NOT use placeholder SHAs in the ledger.
- The `verdict:` field on stat-card-overflow-contract.md goes in the frontmatter (between `team_b_commit:` and the `---` close); add it on its own line.
- The pruning operation: append the to-be-pruned line to `docs/bug-hunt/pending_recurrences.resolved.jsonl` (create if missing), then rewrite `pending_recurrences.jsonl` without that line.
- If a pre-existing `docs/decisions/` record already covers a decision Team A/B/C/D made, do not duplicate; if a decision was new and non-trivial (e.g., Team B chose `display: none` over `visibility: hidden` and that has CSS-transition implications), add a 1-page record.
- LESSONS must be reusable rules, not a recap of the diff. Lead with the rule; one paragraph max per lesson.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team B `display: none` breaks CSS transitions on modal open/close | Medium | Medium | Use `visibility: hidden; opacity: 0; pointer-events: none` instead if transitions need to play; verify the leaderboard modal still opens with its existing transition. |
| Team C's `trade-ticket--open` removal also affects open path (regression where panel never opens) | Medium | High | Defensive read of `openTradeTicket` to confirm it adds the class; if not, fix both halves in same commit. Manual verify open flow before commit. |
| Team A's inline breakdown collides with existing column widths in Order Log table on narrow viewports | Low | Low | Render breakdown as a single sub-line below total cost using muted color; if it makes the row too tall, switch to inline `<small>` element. |
| Team D's DOM update writes to a stale plugin row (registry async-loaded) | Low | Low | Use the existing `[data-plugin-name="<name>"]` selector that the click handler already validates. |
| Phase 5.5 retest fails on Team B because the wizard's open path is rare and not covered by retest | Low | Medium | Retest envelope explicitly opens onboarding wizard then triggers step 2. If the retest doesn't reproduce the wizard's natural lifecycle, mark as `error` not `fail` to avoid false patch-ineffective. |
| Two trade-ticket sub-issues (price-discrepancy AND post-fill close) confuse reviewers since they touch adjacent files | Low | Low | Separate teams (A on app.js, C on trade-ticket.js) — files do not overlap. Commit messages cite distinct findings. |
| stat-card-overflow-contract verdict set prematurely (effective) — a regression appears next iteration | Medium | Low | This is the verdict mechanism's purpose. If next iteration's triage surfaces a new sim-time/stat-card finding, the next Phase 6 will downgrade the verdict to `incomplete`/`regressed`. Acceptable cost. |

## Session Plan

### Session 1 — Parallel fix teams + sequential docs

**Parallel:** Teams A, B, C, D — all four spawn simultaneously. Zero shared files.

**Merge order:** any order — they don't conflict. Recommend merging in alphabetical order (A → B → C → D) for ledger consistency. Targeted tests run after each merge:
- After A merges: `uv run pytest tests/dashboard -k orders -x -q` (if exists, else lint check `uv run ruff check dashboard/`).
- After B merges: `uv run pytest tests/dashboard -k modal -x -q` (if exists).
- After C merges: `uv run pytest tests/dashboard -k trade -x -q` (if exists).
- After D merges: `uv run pytest tests/dashboard -k plugin -x -q` (if exists).

**Sequential:** Team E — runs after A, B, C, D all merged. Reads merge SHAs from `git log` and updates the ledger with real values.

**Session checkpoint (after E merges):** full test suite — `uv run pytest -x -q --tb=short`. Then `git push origin main` (handled by exec-plan, not Team E directly).

---

## Quality Checklist

- [x] Every team has a "Read these files first" list with file:line ranges.
- [x] Every team has "You MUST `git add` + `git commit`" in agent instructions.
- [x] Every team has specific validation commands.
- [x] File conflict table accounts for all shared files (zero conflicts between A/B/C/D; E touches docs only).
- [x] No team touches >8 files (max is E with ~10 docs files but those are appends/edits).
- [x] Dependencies match the file conflict table (no hidden conflicts).
- [x] Critical path is `{A|B|C|D} → E`.
- [x] Session grouping respects all dependency constraints.
- [x] Every "current state" claim in a team spec is backed by a quoted-excerpt fenced block with file:line cite OR a `(verified by recon agent against HEAD bdeb62d)`-tagged paraphrase. PF-18 satisfied.
- [x] Recon contradictions surfaced explicitly: Surface 3 (Team C) — recon agent's snippet of `closeTradeTicket()` claimed `finletModal.close("trade-ticket-modal")` but the actual element id is `trade-ticket-panel`, making the call a silent no-op. Team C's spec names this contradiction and instructs the team to fix the actual root cause (panel-class removal), not the reconned non-bug.
