---
tags: [finlet, plugins, data, market-data]
keywords: DataPlugin, PluginRegistry, price plugin, S3 Parquet data lake, EDGAR, FRED, Finnhub fallback, circuit breaker
aliases: [data plugins, plugin system, market data]
priority: normal
---

# Finlet Plugin System

## DataPlugin Interface (`finlet/plugins/base.py`)

All plugins extend DataPlugin ABC with: plugin_type, name, requires_api_key, free_tier_limits, initialize(), query(params, ceiling_time), health_check().

## Built-in Plugins

Listed in registry order — S3-backed plugins serve as defaults; API-key plugins follow as fallbacks. `PluginRegistry.get_plugin(type)` returns the first registered match (see `finlet/api/app.py:_register_plugins`).

| Plugin | Data | Source | Rate Limits |
|--------|------|--------|-------------|
| PricePlugin | OHLCV | S3 Parquet (Databento + Quandl). Hot path — no Finnhub fallback. | None (self-hosted) |
| FundamentalsPlugin | Company Financials | S3 Parquet (quarterly). Default for fundamentals queries. | None |
| NewsPlugin | News Articles | S3 Parquet (daily). Default for news queries. | None |
| SentimentPlugin | Analyst Ratings | S3 Parquet (per-ticker). | None |
| FinnhubPlugin | News + Fundamentals (fallback only) | Finnhub API — used only when S3 news or fundamentals are unavailable. | 60 calls/min free |
| EDGARPlugin | SEC Filings | edgartools (10-K, 10-Q, 8-K, 13-F, Form 4) | SEC limits |
| FREDPlugin | Economic | Federal Reserve (GDP, CPI, rates) | ALFRED vintage dates |

## Plugin Registry & Circuit Breaker

PluginRegistry centralizes all queries with:
1. Transient error classification (retryable: timeouts, 429/502/503/504 vs permanent: bad config)
2. Retry with exponential backoff (3 retries: 0.5s, 1.0s, 2.0s)
3. Circuit breaker (5 failures open, 60s reset timeout, fail-fast when open)
