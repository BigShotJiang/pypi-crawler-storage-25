# Finlet Marketplace — Architecture Specification (v3)

> **Publish, discover, and run AI trading strategies on a time-locked simulation platform.**

The Finlet Marketplace enables developers to publish AI trading strategies that other users can discover, purchase, and run against Finlet's simulation engine. Strategies are **declarative configuration packages** — not arbitrary code — evaluated inside the existing session/clock/enforcer pipeline. All performance data is simulated; the marketplace never implies real trading returns.

---

## Table of Contents

1. [Strategy Package Format](#1-strategy-package-format)
2. [Marketplace Data Model](#2-marketplace-data-model)
3. [API Endpoints](#3-api-endpoints)
4. [MCP Tools](#4-mcp-tools)
5. [Leaderboard Integration](#5-leaderboard-integration)
6. [Revenue Model](#6-revenue-model)
7. [Security Model](#7-security-model)
8. [Data Provider Licensing Architecture](#8-data-provider-licensing-architecture)

---

## 1. Strategy Package Format

### Design Decision: Config-Only (Declarative)

Strategies are **declarative JSON/YAML configuration packages** — not executable code. This eliminates the entire class of arbitrary code execution vulnerabilities (RCE, sandbox escapes, supply chain attacks) while remaining expressive enough for the vast majority of trading strategies that Finlet's simulation engine supports.

**Rationale:** Executing user-uploaded Python, WASM, or Docker containers introduces attack surface that is disproportionate to the value delivered at v3. The simulation engine already defines the full vocabulary of actions an agent can take (query data, submit orders, advance time). A declarative format composes these primitives without introducing new execution semantics.

### Package Structure

```
my-strategy/
├── strategy.json          # Required: strategy manifest + rules
├── README.md              # Required: description, usage, disclaimers
├── scenarios/             # Optional: custom benchmark scenarios
│   └── custom_scenario.json
└── assets/                # Optional: images for listing page
    └── thumbnail.png
```

### Strategy Manifest (`strategy.json`)

```json
{
  "format_version": "1.0",
  "metadata": {
    "name": "Momentum Breakout v2",
    "slug": "momentum-breakout-v2",
    "description": "Enters long positions when 20-day price momentum exceeds 2 standard deviations.",
    "version": "2.1.0",
    "category": "momentum",
    "tags": ["equities", "large-cap", "technical"],
    "min_capital": 50000,
    "supported_universes": ["SP500", "NASDAQ100"],
    "data_requirements": ["price", "fundamentals"]
  },
  "session_defaults": {
    "initial_capital": 100000,
    "time_step": "1d",
    "universe": ["AAPL", "MSFT", "GOOGL", "AMZN", "NVDA"]
  },
  "rules": [
    {
      "id": "momentum_entry",
      "trigger": "on_step",
      "conditions": [
        {"type": "indicator", "indicator": "momentum", "period": 20, "operator": ">", "value": 2.0, "value_unit": "stddev"},
        {"type": "indicator", "indicator": "volume_sma", "period": 10, "operator": ">", "value": 1.5, "value_unit": "multiplier"}
      ],
      "actions": [
        {"type": "order", "side": "BUY", "sizing": "equal_weight", "order_type": "MARKET"}
      ]
    },
    {
      "id": "trailing_stop",
      "trigger": "on_step",
      "conditions": [
        {"type": "position", "field": "unrealized_pnl_pct", "operator": "<", "value": -0.05}
      ],
      "actions": [
        {"type": "order", "side": "SELL", "sizing": "full_position", "order_type": "MARKET"}
      ]
    }
  ],
  "risk_controls": {
    "max_position_pct": 0.20,
    "max_portfolio_drawdown_pct": 0.15,
    "max_positions": 10
  }
}
```

### Rule Engine

The strategy rule engine evaluates declarative rules within the existing session pipeline:

| Component | Description |
|-----------|-------------|
| **Trigger** | `on_step` (every clock advance), `on_fill` (after order fills), `on_session_start` |
| **Conditions** | Indicator comparisons, position state checks, portfolio metric thresholds, time-based filters |
| **Actions** | Order submission (BUY/SELL with sizing), position close, clock advance |
| **Indicators** | Built-in library: SMA, EMA, RSI, MACD, momentum, Bollinger Bands, ATR, volume averages |
| **Sizing** | `equal_weight`, `fixed_shares`, `fixed_dollars`, `pct_of_portfolio`, `full_position` |

Rules are evaluated top-to-bottom. Each rule's conditions are AND'd. The engine uses only data available through the existing plugin system, subject to the date ceiling enforcer.

### Package Validation

Before publishing, packages are validated:

1. **Schema validation** — `strategy.json` conforms to the JSON Schema
2. **Rule validation** — all referenced indicators, conditions, and actions are recognized
3. **Dry-run validation** — strategy executes against a short synthetic scenario without errors
4. **Size limits** — total package ≤ 5 MB, `strategy.json` ≤ 500 KB, ≤ 50 rules
5. **Content policy** — README scanned for prohibited claims (guaranteed returns, not-simulated language)

### Future: Code Execution (v4+)

If user demand requires executable strategies, the planned path is:

1. **WebAssembly sandboxing** — strategies compiled to WASM, executed in a sandboxed runtime with only Finlet SDK bindings exposed. No filesystem, network, or system call access.
2. **Resource limits** — CPU time cap (5s per step), memory cap (128 MB), no persistent state between steps.
3. **Mandatory code review** — all WASM strategies require manual review before marketplace listing.

This is explicitly out of scope for v3.

---

## 2. Marketplace Data Model

All marketplace tables live in `~/.finlet/marketplace.db` — a dedicated SQLite database following the same `aiosqlite` + SQLModel pattern used by `auth.db` and `leaderboard.db`.

### Entity Relationship

```
DeveloperProfile 1──N StrategyListing
StrategyListing  1──N StrategyVersion
StrategyListing  1──N Review
StrategyListing  1──N Purchase
DeveloperProfile 1──N Payout
Purchase         1──1 Revenue
```

### SQLModel Definitions

```python
class DeveloperProfile(SQLModel, table=True):
    __tablename__ = "developer_profiles"

    id: str = Field(default_factory=_new_id, primary_key=True)
    user_id: str = Field(index=True, unique=True)  # FK to auth user
    display_name: str
    bio: str = ""
    website: str = ""
    stripe_connect_id: str | None = None  # Stripe Connect account for payouts
    verified: bool = Field(default=False)
    total_revenue_cents: int = Field(default=0)
    total_sales: int = Field(default=0)
    created_at: datetime = Field(default_factory=_utcnow)
    updated_at: datetime = Field(default_factory=_utcnow)


class StrategyListing(SQLModel, table=True):
    __tablename__ = "strategy_listings"

    id: str = Field(default_factory=_new_id, primary_key=True)
    developer_id: str = Field(index=True)  # FK to developer_profiles.id
    slug: str = Field(index=True, unique=True)  # URL-safe identifier
    name: str
    description: str
    category: str  # momentum | mean-reversion | fundamental | hybrid | other
    tags_json: str = Field(default="[]")  # JSON array of tags
    current_version: str = Field(default="1.0.0")  # semver
    price_cents: int = Field(default=0)  # 0 = free
    license_type: str = Field(default="single")  # single | team | unlimited
    status: str = Field(default="draft")  # draft | in_review | published | suspended | delisted
    download_count: int = Field(default=0)
    avg_rating: float = Field(default=0.0)
    review_count: int = Field(default=0)
    leaderboard_agent_id: str | None = None  # Link to leaderboard entry
    leaderboard_composite_score: float | None = None
    featured: bool = Field(default=False)
    created_at: datetime = Field(default_factory=_utcnow)
    updated_at: datetime = Field(default_factory=_utcnow)
    published_at: datetime | None = None


class StrategyVersion(SQLModel, table=True):
    __tablename__ = "strategy_versions"

    id: str = Field(default_factory=_new_id, primary_key=True)
    listing_id: str = Field(index=True)  # FK to strategy_listings.id
    version: str  # semver (e.g. "2.1.0")
    strategy_json: str  # The full strategy.json content
    readme: str = ""
    changelog: str = ""
    package_hash: str  # SHA-256 of the full package for integrity
    validation_status: str = Field(default="pending")  # pending | passed | failed
    validation_errors_json: str = Field(default="[]")
    created_at: datetime = Field(default_factory=_utcnow)


class Review(SQLModel, table=True):
    __tablename__ = "reviews"

    id: str = Field(default_factory=_new_id, primary_key=True)
    listing_id: str = Field(index=True)  # FK to strategy_listings.id
    user_id: str = Field(index=True)  # FK to auth user
    rating: int  # 1-5 stars
    title: str = ""
    body: str = ""
    verified_purchase: bool = Field(default=False)
    helpful_count: int = Field(default=0)
    status: str = Field(default="visible")  # visible | hidden | flagged
    created_at: datetime = Field(default_factory=_utcnow)
    updated_at: datetime = Field(default_factory=_utcnow)


class Purchase(SQLModel, table=True):
    __tablename__ = "purchases"

    id: str = Field(default_factory=_new_id, primary_key=True)
    listing_id: str = Field(index=True)  # FK to strategy_listings.id
    version_id: str  # FK to strategy_versions.id (version at time of purchase)
    buyer_user_id: str = Field(index=True)  # FK to auth user
    price_cents: int  # Price paid (snapshot at purchase time)
    platform_fee_cents: int  # Finlet's cut
    developer_revenue_cents: int  # Developer's cut
    stripe_payment_id: str | None = None  # Stripe PaymentIntent ID
    status: str = Field(default="completed")  # completed | refunded | disputed
    refunded_at: datetime | None = None
    created_at: datetime = Field(default_factory=_utcnow)


class Payout(SQLModel, table=True):
    __tablename__ = "payouts"

    id: str = Field(default_factory=_new_id, primary_key=True)
    developer_id: str = Field(index=True)  # FK to developer_profiles.id
    amount_cents: int  # Amount paid out
    currency: str = Field(default="usd")
    stripe_transfer_id: str | None = None  # Stripe Transfer ID
    status: str = Field(default="pending")  # pending | processing | completed | failed
    period_start: datetime  # Payout covers purchases from this date
    period_end: datetime  # ...to this date
    created_at: datetime = Field(default_factory=_utcnow)
    completed_at: datetime | None = None
```

### Database Initialization

Following the pattern from `create_auth_db()` and `create_leaderboard_db()`:

```python
MARKETPLACE_DB_PATH = FINLET_DIR / "marketplace.db"

_MARKETPLACE_TABLES = [
    DeveloperProfile.__table__,
    StrategyListing.__table__,
    StrategyVersion.__table__,
    Review.__table__,
    Purchase.__table__,
    Payout.__table__,
]

async def create_marketplace_db() -> None:
    """Create the marketplace database with all tables."""
    FINLET_DIR.mkdir(parents=True, exist_ok=True)
    engine = create_async_engine(f"sqlite+aiosqlite:///{MARKETPLACE_DB_PATH}")
    async with engine.begin() as conn:
        for table in _MARKETPLACE_TABLES:
            await conn.run_sync(table.create, checkfirst=True)
    await engine.dispose()
```

---

## 3. API Endpoints

All marketplace endpoints live under the `/marketplace` prefix. Authentication follows the existing `require_api_key` / `optional_api_key` pattern.

### Strategy Browsing

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `GET` | `/marketplace/strategies` | Optional | Browse/search/filter published strategies |
| `GET` | `/marketplace/strategies/{slug}` | Optional | Get strategy detail page |
| `GET` | `/marketplace/strategies/{slug}/versions` | Optional | List all versions |
| `GET` | `/marketplace/strategies/{slug}/versions/{version}` | Optional | Get specific version detail |
| `GET` | `/marketplace/strategies/{slug}/reviews` | Optional | List reviews for a strategy |
| `GET` | `/marketplace/categories` | None | List available strategy categories |
| `GET` | `/marketplace/featured` | None | Get editorially featured strategies |

**`GET /marketplace/strategies` query parameters:**

| Param | Type | Default | Description |
|-------|------|---------|-------------|
| `q` | string | - | Full-text search across name, description, tags |
| `category` | string | - | Filter by strategy category |
| `tags` | string | - | Comma-separated tag filter (AND logic) |
| `price` | string | - | `free`, `paid`, or `all` |
| `sort` | string | `popular` | `popular`, `newest`, `rating`, `price_asc`, `price_desc`, `performance` |
| `limit` | int | 20 | Page size (1-100) |
| `offset` | int | 0 | Pagination offset |

### Strategy Publishing (Developer Flow)

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `POST` | `/marketplace/developer/register` | Required | Register as a developer (creates DeveloperProfile) |
| `GET` | `/marketplace/developer/profile` | Required | Get own developer profile |
| `PUT` | `/marketplace/developer/profile` | Required | Update developer profile |
| `POST` | `/marketplace/developer/strategies` | Required (Developer) | Create a new strategy listing (draft) |
| `PUT` | `/marketplace/developer/strategies/{slug}` | Required (Owner) | Update listing metadata |
| `POST` | `/marketplace/developer/strategies/{slug}/versions` | Required (Owner) | Upload a new version |
| `POST` | `/marketplace/developer/strategies/{slug}/submit` | Required (Owner) | Submit for review (draft → in_review) |
| `DELETE` | `/marketplace/developer/strategies/{slug}` | Required (Owner) | Delist a strategy |

### Purchasing / Licensing

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `POST` | `/marketplace/strategies/{slug}/purchase` | Required | Purchase a strategy |
| `GET` | `/marketplace/purchases` | Required | List user's purchased strategies |
| `GET` | `/marketplace/purchases/{purchase_id}` | Required | Get purchase details |
| `POST` | `/marketplace/purchases/{purchase_id}/refund` | Required | Request a refund (within 7-day window) |

### Reviews and Ratings

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `POST` | `/marketplace/strategies/{slug}/reviews` | Required (Buyer) | Submit a review |
| `PUT` | `/marketplace/strategies/{slug}/reviews/{review_id}` | Required (Author) | Edit a review |
| `DELETE` | `/marketplace/strategies/{slug}/reviews/{review_id}` | Required (Author) | Delete a review |
| `POST` | `/marketplace/strategies/{slug}/reviews/{review_id}/helpful` | Required | Mark review as helpful |

### Developer Dashboard

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `GET` | `/marketplace/developer/analytics` | Required (Developer) | Revenue summary, download trends |
| `GET` | `/marketplace/developer/analytics/revenue` | Required (Developer) | Revenue breakdown by strategy/period |
| `GET` | `/marketplace/developer/analytics/downloads` | Required (Developer) | Download/purchase counts over time |
| `GET` | `/marketplace/developer/payouts` | Required (Developer) | Payout history |
| `POST` | `/marketplace/developer/stripe-connect` | Required (Developer) | Initialize Stripe Connect onboarding |

### Admin Moderation

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `GET` | `/marketplace/admin/review-queue` | Required (Admin) | Strategies pending review |
| `POST` | `/marketplace/admin/strategies/{slug}/approve` | Required (Admin) | Approve for publishing |
| `POST` | `/marketplace/admin/strategies/{slug}/reject` | Required (Admin) | Reject with reason |
| `POST` | `/marketplace/admin/strategies/{slug}/suspend` | Required (Admin) | Suspend a published strategy |
| `POST` | `/marketplace/admin/reviews/{review_id}/hide` | Required (Admin) | Hide a review |
| `GET` | `/marketplace/admin/reports` | Required (Admin) | View flagged content |

### Request/Response Examples

**Create Strategy Listing:**

```http
POST /marketplace/developer/strategies
Authorization: Bearer <key>
Content-Type: application/json

{
  "name": "Momentum Breakout v2",
  "slug": "momentum-breakout-v2",
  "description": "Enters long positions on 20-day momentum breakouts with volume confirmation.",
  "category": "momentum",
  "tags": ["equities", "large-cap", "technical"],
  "price_cents": 4999,
  "license_type": "single"
}
```

**Response:**

```json
{
  "id": "lst_a1b2c3d4e5f6",
  "slug": "momentum-breakout-v2",
  "name": "Momentum Breakout v2",
  "status": "draft",
  "created_at": "2026-03-23T00:00:00Z",
  "message": "Strategy listing created as draft. Upload a version with POST /marketplace/developer/strategies/momentum-breakout-v2/versions, then submit for review."
}
```

### Error Handling

Follows existing API conventions:

| Code | Meaning |
|------|---------|
| `400` | Invalid strategy package, failed validation |
| `401` | Missing or invalid API key |
| `403` | Not a developer, not the owner, not admin |
| `404` | Strategy/review/purchase not found |
| `409` | Slug already taken, duplicate review |
| `422` | Request body validation errors |
| `429` | Developer rate limits exceeded |

Error messages are specific and actionable, per the ARCHITECTURE.md convention:

- Good: `"Strategy validation failed: rule 'momentum_entry' references unknown indicator 'rsi_custom'. Available indicators: sma, ema, rsi, macd, momentum, bollinger, atr, volume_sma."`
- Bad: `"Invalid strategy"`

---

## 4. MCP Tools

New MCP tools for AI agents to discover and use marketplace strategies. These follow the exact pattern of existing tools in `finlet/mcp/server.py`.

```python
@mcp.tool()
async def search_strategies(
    query: str | None = None,
    category: str | None = None,
    price: str = "all",
    sort: str = "popular",
    limit: int = 10,
) -> dict[str, Any]:
    """Search the Finlet Marketplace for AI trading strategies.

    Args:
        query: Search text (matches strategy name, description, tags)
        category: Filter by category — "momentum", "mean-reversion", "fundamental", "hybrid"
        price: "free", "paid", or "all"
        sort: "popular", "newest", "rating", "performance"
        limit: Maximum results (1-50, default 10)

    Returns published strategies with simulated performance scores.
    All performance data is simulated — it does not predict real trading returns.
    """


@mcp.tool()
async def get_strategy_details(
    slug: str,
) -> dict[str, Any]:
    """Get full details for a marketplace strategy including rules and simulated benchmark scores.

    Args:
        slug: Strategy identifier (e.g. "momentum-breakout-v2")

    Returns strategy description, rules summary, simulated performance data, reviews, and pricing.
    All performance data is simulated and does not predict real trading returns.
    """


@mcp.tool()
async def run_strategy(
    slug: str,
    session_id: str | None = None,
    override_universe: list[str] | None = None,
    override_capital: float | None = None,
) -> dict[str, Any]:
    """Run a marketplace strategy in a simulation session.

    The strategy's declarative rules will be evaluated against your session's
    simulation clock. You must own (purchased or free) the strategy to run it.

    Args:
        slug: Strategy identifier (e.g. "momentum-breakout-v2")
        session_id: Session ID (optional if only one session exists)
        override_universe: Override the strategy's default ticker universe
        override_capital: Override the strategy's default initial capital

    Returns the session ID and initial strategy state. Use get_portfolio and
    advance_time to observe strategy execution over simulated time.
    All results are simulated and do not predict real trading returns.
    """


@mcp.tool()
async def list_purchased_strategies() -> dict[str, Any]:
    """List all strategies you have purchased or have access to (including free strategies you've added).

    Returns strategy names, slugs, versions, and purchase dates.
    """
```

---

## 5. Leaderboard Integration

The existing leaderboard (agent profiles, composite scores, scenario benchmarks) becomes a discovery mechanism for marketplace strategies.

### How It Works

1. **Automatic benchmark on publish** — When a strategy is published, the platform automatically runs it against all standard benchmark scenarios (the same ones used by the leaderboard). Results are stored as an `AgentProfile` linked to the `StrategyListing.leaderboard_agent_id`.

2. **Leaderboard badges on listings** — Strategy listing pages display the leaderboard composite score and per-scenario results. All labels use "simulated performance" language per legal requirements.

3. **"Top Simulated Performers" section** — The marketplace browse page includes a section showing strategies ranked by leaderboard composite score. This section carries a prominent disclaimer.

4. **Leaderboard → Marketplace links** — Leaderboard entries that correspond to published marketplace strategies include a "Get this strategy" link.

### Required Disclaimers

Per `LEGAL_AUDIT.md` Section 9 (Marketing Compliance) and Section 3 (Financial Regulation):

- The word "performance" is always qualified: "simulated performance" or "benchmark results"
- Leaderboard rankings on marketplace listings include: *"Rankings reflect simulated performance on historical benchmark scenarios. Past simulated performance does not guarantee future results. See full disclaimer."*
- Strategy listings with leaderboard data include the Performance Disclaimer from `LEGAL_AUDIT.md` Section 3.7

### API Surface

The existing leaderboard endpoints remain unchanged. New cross-references:

| Endpoint | Addition |
|----------|----------|
| `GET /leaderboard` | Each entry gains optional `marketplace_slug` field linking to the strategy listing |
| `GET /marketplace/strategies/{slug}` | Response includes `leaderboard` object with composite score and per-scenario results |
| `GET /marketplace/strategies?sort=performance` | Sorts by leaderboard composite score |

---

## 6. Revenue Model

### Fee Structure

| Component | Split |
|-----------|-------|
| **Developer share** | 80% of sale price |
| **Platform fee** | 20% of sale price |

The 80/20 split is competitive with modern developer marketplaces and reflects that Finlet provides the execution infrastructure, discovery, payment processing, and leaderboard benchmarking.

### Pricing Tiers

| Tier | Price Range | Description |
|------|-------------|-------------|
| **Free** | $0 | Open access. Developer gets exposure and leaderboard positioning. |
| **Standard** | $4.99 – $49.99 | Single-user license. Buyer can run in unlimited sessions. |
| **Team** | $49.99 – $499.99 | Up to 10 users in a single organization. |
| **Custom/Enterprise** | Negotiated | Unlimited users, SLA, priority support. |

### Payment Processing — Stripe Connect

Stripe Connect (Standard) handles all payment flows:

| Flow | Stripe Product | Description |
|------|---------------|-------------|
| **Buyer payment** | PaymentIntent | Charged at purchase time |
| **Platform fee** | Application fee | 20% automatically deducted |
| **Developer payout** | Transfer / automatic payout | Sent to developer's connected bank account |
| **Refund** | Refund API | Full refund within 7-day window |

### Payout Schedule

| Frequency | Conditions |
|-----------|------------|
| **Weekly** | Automatic every Monday for completed purchases from the prior week |
| **Minimum threshold** | $25 minimum balance before payout is initiated |
| **Hold period** | 7-day hold on new purchases (matches refund window) |

### Refund Policy

- **7-day refund window** — buyers can request a full refund within 7 days of purchase, no questions asked.
- **Post-7-day** — refunds only for material defects (strategy fails validation on current version, strategy description is materially misleading).
- **Abuse prevention** — users who refund >3 purchases in 30 days are flagged for review. Repeated abuse results in purchase restrictions.
- **Developer impact** — refunded sales are deducted from the next payout cycle. If insufficient balance, the deficit carries forward.

---

## 7. Security Model

### Strategy Sandboxing

Since v3 strategies are declarative (config-only), the sandboxing model is fundamentally different from code execution sandboxing:

| Layer | Protection |
|-------|-----------|
| **Schema validation** | `strategy.json` must conform to a strict JSON Schema. Unknown fields are rejected. |
| **Rule allowlisting** | Only recognized triggers, conditions, actions, and indicators are permitted. The rule engine has no `eval()`, `exec()`, or dynamic dispatch. |
| **Resource limits** | Max 50 rules per strategy. Max 500 KB for `strategy.json`. Max 5 MB total package size. |
| **Data access** | Strategies can only access data through the existing plugin system, subject to the date ceiling enforcer. No filesystem, network, or system access. |
| **Rate limiting** | Strategy execution is bounded by session rate limits. A strategy cannot make more plugin queries than a manual user. |

### Code Review / Approval Pipeline

```
Developer uploads version
    ↓
Automated validation (schema, rules, dry-run)
    ↓ pass
    ↓ fail → reject with specific errors
Queued for admin review
    ↓
Admin reviews: strategy logic, README claims, pricing
    ↓ approve → status: published
    ↓ reject → status: draft + rejection reason
```

**Automated checks run on every version upload:**

1. JSON Schema validation of `strategy.json`
2. All rule references resolve to known indicators/conditions/actions
3. Dry-run against a 5-day synthetic scenario completes without errors
4. README scanned for prohibited terms (guaranteed returns, risk-free, etc.)
5. Package hash (SHA-256) computed and stored for integrity verification

**Admin review is required for:**

- First-time strategy submissions from unverified developers
- Strategies priced above $99.99
- Strategies with custom benchmark scenarios
- Re-review after a version update changes >50% of rules

### Malicious Strategy Detection

| Threat | Mitigation |
|--------|-----------|
| **Rule bomb** (excessive rules designed to DoS the engine) | Hard limit: 50 rules, 500 KB strategy.json. Dry-run must complete within 30 seconds. |
| **Data harvesting** (rules designed to extract maximum data from plugins) | Strategy execution inherits session-level plugin rate limits. Excessive query patterns flagged in admin review. |
| **Misleading descriptions** | Automated scan for prohibited marketing claims. Admin review of README content. |
| **Plagiarism** | Package hash comparison against existing strategies. Fuzzy rule similarity scoring during review. |
| **Version poisoning** (malicious update to a previously clean strategy) | All version updates go through automated validation. Updates changing >50% of rules trigger re-review. Buyers receive notification of updates and can pin to a specific version. |

### Per-Developer Rate Limiting

| Action | Limit |
|--------|-------|
| Strategy creation | 5 per day |
| Version upload | 10 per day per strategy |
| Review submission (for reviews endpoint) | 3 per day |

### Strategy Versioning and Rollback

- All versions are immutable once uploaded. Updates create new versions.
- Buyers who purchased an earlier version automatically get access to all future versions of that listing.
- Developers can set any published version as the "current" version.
- If a version is found to be malicious or defective, admins can suspend the specific version while leaving other versions available.
- Buyers can pin their session to run a specific version rather than always using "current."

---

## 8. Data Provider Licensing Architecture

### Current Provider Landscape

| Provider | Current License | Marketplace Impact |
|----------|----------------|-------------------|
| **PricePlugin** (S3/Parquet) | Platform-licensed data | No per-user impact — all strategies use the same data lake |
| **Finnhub** | Free: 60 calls/min (dev/test). Paid: $49+/mo | Rate limit sharing across strategies is a concern |
| **FRED** | Free API key per user | Attribution required. Low rate impact. |
| **EDGAR** | Free, public domain | 10 req/sec rate limit. No licensing concern. |

### BYOK (Bring Your Own Key) Model

The marketplace uses a tiered data access model:

| Tier | Data Access | How It Works |
|------|-------------|--------------|
| **Platform data** | PricePlugin (S3/Parquet), EDGAR | Always available. Finlet pays for the data lake. No user key needed. |
| **Shared pool** | Finnhub, FRED | Platform holds a paid Finnhub plan. Marketplace strategies share the pool, subject to per-session rate limits. Platform fee (20%) partially funds this. |
| **BYOK** | User's own keys | User configures their own Finnhub/FRED/other keys via `finlet plugins add`. These keys get priority routing and higher per-user rate limits. |

### Rate Limit Allocation for Marketplace Strategies

When a marketplace strategy runs in a session:

1. **Check BYOK first** — if the user has configured their own API key for the required plugin, use it with the user's full rate limit allocation.
2. **Fall back to platform pool** — if no BYOK key, use the platform's shared pool with proportional rate limiting: `platform_rate_limit / active_strategy_sessions`.
3. **Degrade gracefully** — if the pool is exhausted, return a specific error: `"Shared Finnhub pool exhausted: 0/60 calls remaining, resets in 42 seconds. Configure your own key with 'finlet plugins add finnhub --api-key=YOUR_KEY' for dedicated rate limits."`

### Data Requirements Metadata

Each strategy declares its `data_requirements` in the manifest:

```json
"data_requirements": ["price", "fundamentals"]
```

This allows:
- The marketplace UI to show "Requires: Price Data, Fundamentals" on the listing
- Pre-flight validation before running a strategy (are all required plugins available and initialized?)
- Accurate cost estimation for strategies requiring paid data providers

### Future: Per-Strategy Data Licensing (v4+)

If Finlet negotiates bulk data provider agreements, strategies could include data access as part of the purchase price (bundled licensing). This requires:
- Revenue sharing agreements with data providers
- Per-query metering and accounting
- Clear user disclosure of data provider costs included in strategy price

This is out of scope for v3.

---

## File Organization

New files and modules for the marketplace implementation:

```
finlet/
├── marketplace/
│   ├── __init__.py
│   ├── models.py              # SQLModel entities (DeveloperProfile, StrategyListing, etc.)
│   ├── persistence.py         # CRUD operations for marketplace DB
│   ├── validation.py          # Strategy package validation (schema, rules, dry-run)
│   ├── rule_engine.py         # Declarative rule evaluation engine
│   ├── indicators.py          # Built-in technical indicator library
│   └── payments.py            # Stripe Connect integration
├── api/
│   ├── routes_marketplace.py  # All /marketplace/* REST endpoints
│   └── routes_admin.py        # Admin moderation endpoints
├── mcp/
│   └── server.py              # Add marketplace MCP tools to existing server
└── db/
    └── models.py              # Add marketplace DB helpers (create_marketplace_db, etc.)
```

---

## Implementation Priority

| Phase | Scope | Dependency |
|-------|-------|------------|
| **Phase 1** | Data model, strategy package format, validation pipeline, developer registration | None |
| **Phase 2** | Browse/search endpoints, MCP discovery tools, rule engine + indicator library | Phase 1 |
| **Phase 3** | Stripe Connect integration, purchase flow, developer dashboard | Phase 2 |
| **Phase 4** | Reviews, ratings, admin moderation queue | Phase 3 |
| **Phase 5** | Leaderboard integration (auto-benchmark on publish, cross-linking) | Phase 2 + existing leaderboard |
| **Phase 6** | Featured strategies, editorial curation, marketplace dashboard UI | Phase 4 |

---

## Regulatory Compliance Checklist

Per `LEGAL_AUDIT.md`, the marketplace introduces these additional compliance requirements:

| Requirement | Status | Action |
|------------|--------|--------|
| Consult securities counsel on v3 marketplace | Required before launch | Budget: $2-5K (LEGAL_AUDIT.md item #21) |
| "Simulated performance" language on all leaderboard data | Required | Enforce in listing validation and UI |
| Performance disclaimers on all strategy pages | Required | Auto-injected by the API, not developer-controlled |
| No implied guarantee of real trading returns | Required | Automated README scanning + admin review |
| Stripe Connect compliance (1099-K reporting, KYC) | Required | Stripe handles KYC/1099-K for connected accounts |
| GDPR: developer data deletion rights | Required | Add developer profile deletion endpoint |
| FTC: truthful marketing claims | Required | Prohibited terms list in automated validation |
