# Finlet v3 Marketplace — Legal Brief

**Date:** 2026-03-23
**Prepared by:** Legal Counsel (Security Council)
**Foundation:** [docs/LEGAL_AUDIT.md](LEGAL_AUDIT.md) (2026-03-22)
**Scope:** Regulatory, IP, data, and liability analysis for marketplace feature enabling developers to publish, share, and sell AI trading strategies/agents on the Finlet simulation platform.

---

## Executive Summary

The v3 Marketplace transforms Finlet from a single-user simulation tool into a multi-party commercial platform where third-party developers publish and sell AI trading strategies with visible performance data. This shift introduces **significant new legal exposure** across four axes:

1. **Securities regulation** — Marketplace strategies with performance claims may trigger Investment Advisers Act registration for Finlet and/or strategy developers. The Howey test analysis for strategy sales is complex but manageable with structural safeguards.
2. **Marketing enforcement** — SEC AI-washing and FTC deceptive claims enforcement is at a high-water mark (2024-2026). Performance claims on paid strategies will receive commercial-grade scrutiny.
3. **International regulation** — MiFID II, the EU AI Act, FCA, MAS, and IOSCO copy-trading guidance all have potential applicability if the marketplace is globally accessible.
4. **Data provider ToS** — Commercializing strategies that depend on Finnhub and FRED data may violate free-tier and redistribution restrictions.

**Overall v3 Risk Assessment: MEDIUM-HIGH** (up from MEDIUM at v1)

---

## Table of Contents

1. [Investment Advisers Act Exposure](#1-investment-advisers-act-exposure)
2. [SEC AI-Washing Compliance](#2-sec-ai-washing-compliance)
3. [FTC Compliance for Marketplace](#3-ftc-compliance-for-marketplace)
4. [Securities Law — Strategy Sales Under the Howey Test](#4-securities-law--strategy-sales-under-the-howey-test)
5. [International Regulatory Considerations](#5-international-regulatory-considerations)
6. [Data Provider ToS Impact](#6-data-provider-tos-impact)
7. [Marketplace Legal Document Checklist](#7-marketplace-legal-document-checklist)
8. [Safe vs. Unsafe Marketing Language](#8-safe-vs-unsafe-marketing-language)
9. [Consolidated Action Items](#9-consolidated-action-items)
10. [Risk Matrix](#10-risk-matrix)

---

## 1. Investment Advisers Act Exposure

**Risk Rating: MEDIUM-HIGH**

### 1.1 The Three-Prong Test

Under Section 202(a)(11) of the Investment Advisers Act of 1940 (15 U.S.C. § 80b-2(a)(11)), a person is an "investment adviser" if they: (1) provide advice about securities, (2) as a business, and (3) for compensation.

**v1 analysis (LOW risk):** Finlet provides a simulation platform; the user's AI agent makes decisions; compensation is for platform access, not advice. The publisher's exclusion (*Lowe v. SEC*, 472 U.S. 181 (1985)) provides additional safe harbor.

**v3 analysis (MEDIUM-HIGH risk):** The marketplace fundamentally changes this calculus:

| Prong | v1 (Simulation) | v3 (Marketplace) |
|-------|-----------------|-------------------|
| Advice about securities | No — user's agent decides | **Arguable YES** — strategy developers encode trading logic that constitutes advice about which securities to buy/sell and when |
| As a business | No | **YES** — developers sell strategies commercially |
| For compensation | Platform fee only | **YES** — direct strategy purchase revenue |

### 1.2 Who Triggers Registration?

**Strategy developers (sellers):** Individual developers selling AI strategies that make buy/sell decisions about securities are providing investment advice for compensation. Unless an exclusion applies, each developer may need to register as an investment adviser (SEC or state level, depending on AUM thresholds). This is the most significant regulatory risk.

**Finlet (platform operator):** Finlet's exposure depends on its role:
- **Pure marketplace (lower risk):** If Finlet only hosts strategies without curating, recommending, or endorsing specific strategies, it may avoid IA status. Analogous to an app store hosting financial apps.
- **Curated marketplace (higher risk):** If Finlet features, ranks, or recommends strategies to users based on performance, it begins to look like it is advising on the "advisability of investing in securities." The leaderboard is the critical risk vector here — ranking strategies by simulated returns and making that ranking visible to paying customers looks advisory.
- **Revenue share model (highest risk):** If Finlet takes a cut of strategy sales, it is compensated in connection with advice about securities, even if indirectly. The SEC has pursued platforms that received referral fees for directing clients to advisers under the "solicitor" rules (now the Marketing Rule's "promoter" provisions).

### 1.3 Available Exclusions and Safe Harbors

| Exclusion | Applicability | Assessment |
|-----------|---------------|------------|
| **Publisher's exclusion** (*Lowe v. SEC*) | Impersonal advice of a general nature published to subscribers | **WEAKENED at v3** — strategies are personalized trading algorithms, not general market commentary |
| **Broker-dealer exclusion** (§ 202(a)(11)(C)) | Advice incidental to brokerage | **NOT AVAILABLE** — Finlet is not a registered B/D |
| **Software/tool exclusion** (interactive software) | Tools that enable users to make their own decisions | **AVAILABLE WITH CONSTRAINTS** — if strategies are sold as "tools" that the user must configure, deploy, and choose to run, rather than as managed portfolios, this exclusion has potential. The SEC's 2024 Internet Adviser Exemption reform (compliance date March 31, 2025) is relevant. |

### 1.4 Recent SEC Enforcement Context (2024-2026)

- **SEC 2025/2026 Exam Priorities:** AI use by investment advisers is a designated examination priority. The Division of Examinations is reviewing whether firms' AI claims are substantiated and whether adequate compliance policies exist.
- **SEC AI Task Force (August 2025):** Launched to enhance regulatory oversight of AI in finance. A marketplace selling AI trading agents will be squarely in scope.
- **Marketing Rule enforcement escalation:** The December 2025 SEC Risk Alert specifically addressed advisers' compliance with the Marketing Rule, including third-party ratings provisions — directly applicable to marketplace leaderboards.

### 1.5 Recommended Mitigations

1. **Obtain a formal legal opinion** from securities counsel on whether Finlet's marketplace structure triggers IA registration. Budget: **$5-10K**.
2. **Structure the marketplace as a "tool store," not an "advisory service."** Strategies should be sold as software tools that the user deploys, configures, and runs — not as managed advice. Critical language distinction.
3. **Require strategy developers to include their own disclaimers** and, if applicable, obtain their own IA registration.
4. **Do not curate, recommend, or endorse specific strategies.** If a leaderboard exists, it must display simulated performance only, with prominent disclaimers, and must not constitute a "recommendation."
5. **Avoid revenue share models tied to strategy performance.** Flat listing fees or flat commission rates are lower risk than percentage-of-profit models.

**Citation:** 15 U.S.C. § 80b-2(a)(11); *Lowe v. SEC*, 472 U.S. 181 (1985); SEC Release IA-5653 (Marketing Rule); SEC 2026 Examination Priorities

---

## 2. SEC AI-Washing Compliance

**Risk Rating: HIGH**

### 2.1 The Delphia / Global Predictions Precedent

On March 18, 2024, the SEC settled its first-ever "AI-washing" enforcement actions (File Nos. 3-21895, 3-21896):

- **Delphia (USA) Inc.** — $225,000 penalty. From 2019-2023, Delphia claimed it "put[s] collective data to work to make our artificial intelligence smarter so it can predict which companies and trends are about to make it big." The SEC found Delphia did not in fact have the AI/ML capabilities it claimed.
- **Global Predictions, Inc.** — $175,000 penalty. Falsely claimed to be the "first regulated AI financial advisor" and to produce "[e]xpert AI driven forecasts."

Both were charged under Sections 206(2) and 206(4) of the Investment Advisers Act and violations of the Marketing Rule and Compliance Rule.

### 2.2 Key Takeaways for Finlet v3

The SEC is enforcing a simple principle: **do not claim AI capabilities you do not have, and do not overstate what AI can achieve.**

In the marketplace context, the risk multiplies because:
1. **Third-party developers** will make their own claims about their strategies' AI capabilities. Finlet may be liable as the platform hosting those claims.
2. **Leaderboard performance data** could be construed as an implied AI capability claim ("these AI agents beat the market").
3. **Marketing copy** describing the marketplace will inevitably reference AI and performance.

### 2.3 SEC 2025-2026 Enforcement Environment

- The SEC's Division of Examinations incorporated AI-washing into its 2024 examination priorities after a 2023 sweep identified numerous advisers making unsubstantiated AI claims.
- The 2026 Exam Priorities continue to highlight AI as a focus area, with examiners reviewing whether firms have "implemented adequate policies and procedures to monitor or supervise their use of AI."
- The SEC launched an AI task force in August 2025 for enhanced AI regulatory oversight.

### 2.4 Required Safeguards

1. **Pre-publication review process** for strategy descriptions — no unsubstantiated AI/ML claims.
2. **Mandatory developer attestation** that all capability claims are truthful and verifiable.
3. **Platform-level disclaimers** that Finlet does not verify developer AI capability claims.
4. **Prohibited language list** enforced in strategy listings (see Section 8).
5. **Internal compliance policy** documenting review procedures (required by Compliance Rule).

**Citation:** SEC Administrative Proceedings File Nos. 3-21895, 3-21896 (March 2024); Sections 206(2), 206(4) of the Investment Advisers Act; Rule 206(4)-1 (Marketing Rule); SEC 2026 Examination Priorities

---

## 3. FTC Compliance for Marketplace

**Risk Rating: MEDIUM-HIGH**

### 3.1 FTC Enforcement Landscape

The FTC has been aggressively pursuing deceptive AI and fintech claims:

- **Operation AI Comply (September 2024):** Five simultaneous enforcement actions targeting companies making unsubstantiated AI claims. Key actions:
  - **DoNotPay** — $193,000 settlement for claiming AI chatbot could replace lawyers
  - **Rytr LLC** — Targeted for facilitating fake reviews (consent order later set aside in December 2025)
  - **Multiple business opportunity schemes** — At least $25 million in consumer harm from false AI income claims

- **Cleo AI (2025):** $17 million settlement for deceiving consumers about financial services.

- **FloatMe (January 2024):** Charged for baseless claims about algorithmic cash advance systems.

The enforcement priority has continued across administrations, with new cases throughout 2025 following the same blueprint.

### 3.2 Marketplace-Specific FTC Risks

| Risk | Description | Severity |
|------|-------------|----------|
| **Deceptive earnings claims** | Leaderboard showing strategy returns could imply real-world earnings potential | HIGH |
| **Unsubstantiated AI claims** | Developer strategy descriptions overstating AI capabilities | MEDIUM |
| **Testimonials/endorsements** | User reviews of strategies constituting unsubstantiated endorsements | MEDIUM |
| **Income opportunity** | Marketing the marketplace as a way to make money from trading | HIGH |

### 3.3 FTC Deceptive Earnings Claims Rule (16 CFR Part 461)

If marketplace marketing implies that purchasing a strategy will lead to financial returns, this triggers the FTC's deceptive earnings claims framework. Key requirements:
- Must have substantiation for any earnings claims BEFORE making them
- Must disclose what a typical purchaser can expect
- Cannot use atypical results without clear disclaimers

### 3.4 Required Safeguards

1. **All performance figures labeled "simulated" or "backtested"** — never "returns" or "profits."
2. **CFTC Rule 4.41-style disclaimer** on all performance displays (see Section 8).
3. **No implied earnings claims** in marketplace marketing or strategy descriptions.
4. **Review process for user-generated content** (strategy descriptions, reviews).
5. **FTC endorsement guide compliance** for any testimonials or user reviews.

**Citation:** 15 U.S.C. § 45 (FTC Act Section 5); 16 CFR Part 461 (Deceptive Earnings Claims); FTC Operation AI Comply (September 2024)

---

## 4. Securities Law — Strategy Sales Under the Howey Test

**Risk Rating: MEDIUM**

### 4.1 Could a Trading Strategy Be a Security?

Under the Howey test (*SEC v. W.J. Howey Co.*, 328 U.S. 293 (1946)), an "investment contract" (and therefore a security) exists when there is:

1. **Investment of money** — YES. Buyer pays for the strategy.
2. **In a common enterprise** — ARGUABLE. Horizontal commonality (pooling of funds) is absent — each buyer uses the strategy independently. Vertical commonality (buyer's fortune tied to seller's efforts) is the closer question.
3. **Reasonable expectation of profits** — ARGUABLE. Buyers expect to profit from deploying the strategy, but the strategy is a tool, not a profit-sharing arrangement.
4. **Derived from the efforts of others** — THIS IS THE KEY PRONG. If the strategy runs autonomously after purchase with no ongoing effort by the developer, the buyer's profits derive from the *strategy's code*, not the developer's ongoing efforts. But if the developer provides updates, parameter tuning, or ongoing management, this prong strengthens.

### 4.2 Analysis: Software License vs. Investment Contract

| Factor | Software License (Non-Security) | Investment Contract (Security) |
|--------|--------------------------------|-------------------------------|
| Purchase model | One-time or subscription for software tool | Investment with expected return |
| Buyer's role | Active — must configure, deploy, decide when to run | Passive — developer manages everything |
| Developer's ongoing role | Bug fixes, updates (standard software) | Ongoing management of trading decisions |
| Profit expectation | Buyer uses tool to trade; profit from buyer's own use | Profit from developer's expertise |
| Common enterprise | No pooling; each buyer operates independently | Revenue sharing, pooled returns |

**Assessment:** A **one-time purchase of strategy code** that the buyer must configure and deploy themselves is more likely a software license than a security. A **managed strategy subscription** where the developer continuously updates parameters and the buyer passively follows is closer to an investment contract.

### 4.3 Structural Safeguards

1. **Sell strategies as software tools, not managed investments.** The buyer must take active steps to deploy and configure.
2. **No performance guarantees or expected return claims.**
3. **No revenue-sharing or profit-pooling arrangements.**
4. **Developer updates should be "software updates" (bug fixes, compatibility), not "strategy updates" (new trading signals, parameter tuning in response to market conditions).**
5. **Each buyer operates independently** — no pooled execution or shared positions.

### 4.4 CFTC Commodity Trading Adviser Analysis

If strategies trade futures, options, or derivatives (not currently in scope for v1 Finlet, but possible in future versions), developers could be classified as Commodity Trading Advisors (CTAs) under the Commodity Exchange Act (7 U.S.C. § 1a(12)). CTA registration with the CFTC and NFA membership would be required.

Even for securities-only strategies, the CFTC's Rule 4.41 hypothetical performance disclaimer requirements are best practice and should be adopted:

> "These results are based on simulated or hypothetical performance results that have certain inherent limitations. Unlike the results shown in an actual performance record, these results do not represent actual trading. Also, because these trades have not actually been executed, these results may have under-or over-compensated for the impact, if any, of certain market factors, such as lack of liquidity. Simulated or hypothetical trading programs in general are also subject to the fact that they are designed with the benefit of hindsight. No representation is being made that any account will or is likely to achieve profits or losses similar to those shown."

**Citation:** *SEC v. W.J. Howey Co.*, 328 U.S. 293 (1946); 7 U.S.C. § 1a(12); CFTC Rule 4.41(b)(1); NFA Compliance Rule 2-29(c)(1)

---

## 5. International Regulatory Considerations

**Risk Rating: MEDIUM-HIGH (if globally accessible)**

### 5.1 European Union — MiFID II + EU AI Act

#### MiFID II (Markets in Financial Instruments Directive)

**Applicability:** If EU-based users purchase and deploy algorithmic trading strategies from the Finlet marketplace, MiFID II Article 17 obligations may apply:

- Investment firms using algorithmic trading must have effective systems, risk controls, and governance arrangements.
- Algorithmic trading strategies must be tested and validated before deployment and after material changes.
- ESMA published a supervisory briefing in 2025 on algorithmic trading controls, with specific attention to AI and outsourcing.

**Key concern:** ESMA's proposed reforms are taking a holistic approach to reviewing all algorithmic trading requirements. A marketplace selling trading strategies could be classified as providing "direct electronic access" or facilitating algorithmic trading, potentially bringing the platform under MiFID II scope.

#### EU AI Act

**Applicability: HIGH.** The EU AI Act entered into force August 1, 2024, with full compliance for high-risk systems required by August 2, 2026.

- **Algorithmic trading systems** are classified as potential high-risk AI systems in financial services.
- **Robo-advisors** are explicitly mentioned as in-scope.
- High-risk system requirements include: risk management systems, human oversight, transparency, auditability, ongoing monitoring, data governance, and technical documentation.
- **Penalties:** Up to 7% of global annual turnover or EUR 35 million, whichever is greater.

**Impact on Finlet:** If marketplace strategies qualify as high-risk AI systems, both Finlet (as deployer/distributor) and strategy developers (as providers) may have compliance obligations. The European Commission is mandated to issue classification guidelines by February 2, 2026.

### 5.2 United Kingdom — FCA

**Applicability:** UK financial markets are regulated under the onshored MiFID II framework (MAR 7A in the FCA Handbook).

- **FCA Multi-Firm Review (August 2025):** Published observations on algorithmic trading controls, emphasizing governance, pre-trade controls, and monitoring. Although the review does not introduce new rules, it signals continued supervisory scrutiny.
- **Copy trading:** The FCA applies suitability assessment and conduct of business requirements to copy trading. A strategy marketplace functionally resembles copy trading and may trigger these requirements.

**Key risk:** If UK users purchase strategies that execute trades on their behalf, the FCA may classify Finlet as providing "investment advice" or operating as an "electronic system in relation to lending" under relevant UK regulatory perimeters.

### 5.3 Singapore — MAS

**Applicability:** MAS has been increasingly focused on AI in financial services.

- **AI Risk Management Guidelines (November 2025):** MAS issued proposed guidelines applying to all financial institutions, with specific attention to "agentic" AI models in algorithmic trading and robo-advisory products.
- MAS expects supervisory guidance measures to be particularly relevant to entities rolling out agentic AI models for algorithmic trading.
- **MAS-FCA Strategic Partnership (November 2025):** Joint initiative on safe and responsible AI in finance.

**Key risk:** If Singapore-based users access the marketplace, MAS regulations on capital markets services licensing (Securities and Futures Act) may apply to strategy sellers providing "financial advisory services."

### 5.4 IOSCO Global Standards — Copy Trading

**IOSCO Final Report on Online Imitative Trading Practices (May 2025):** This report is directly relevant to the Finlet marketplace.

Key findings and good practices:
- Copy trading platforms should apply conduct of business requirements, including suitability assessment.
- Regulators should assess whether copy trading constitutes investment advice in their jurisdictions.
- Platforms should monitor strategy provider behavior and ensure marketing is not misleading.
- Clear disclosure of risks, costs, and performance limitations is required.

**Impact on Finlet:** The IOSCO report provides a framework that national regulators will increasingly adopt. Designing the marketplace to comply with IOSCO good practices from the start will reduce future regulatory friction.

### 5.5 Recommended Mitigations

1. **Geo-blocking:** Consider restricting marketplace access to US-only for initial launch. Budget for international regulatory analysis when expanding.
2. **Terms of Service:** Include governing law and jurisdiction clauses (recommend Delaware or New York).
3. **Developer attestation:** Require developers to self-certify their own regulatory compliance in their jurisdiction.
4. **Monitor EU AI Act classification guidance** (expected February 2026) for algorithmic trading applicability.

**Citation:** MiFID II Article 17; EU AI Act (Regulation (EU) 2024/1689); FCA MAR 7A; MAS Securities and Futures Act; IOSCO Final Report FR/06/2025

---

## 6. Data Provider ToS Impact

**Risk Rating: MEDIUM-HIGH (escalated from MEDIUM at v1)**

### 6.1 Finnhub

**Current status (v1):** Free tier used for news and fundamentals. Free tier is for "testing" and "development" only.

**v3 impact: SIGNIFICANT.** A commercial marketplace where strategies use Finnhub data to generate trading signals that are then sold represents:
1. **Commercial use** of free-tier data — explicitly prohibited.
2. **Potential redistribution** — if strategy outputs include or derive from Finnhub data visible to buyers.

**Required actions:**
- **Upgrade to paid plan** ($49+/month startup tier) before marketplace launch. This was already identified in the v1 audit but becomes mandatory at v3.
- **Review paid plan redistribution terms.** Even paid plans likely restrict redistribution of raw data. Strategy outputs that incorporate Finnhub data (e.g., news sentiment scores) may need separate licensing.
- **Contact Finnhub sales** to discuss marketplace use case and obtain written authorization.

### 6.2 FRED API

**Current status (v1):** Free API key with attribution requirements.

**v3 impact: ELEVATED.** FRED Terms of Use contain critical restrictions for marketplace scenarios:
- Third-party proprietary data series (e.g., BLS, BEA, Census data) may not be redistributed for commercial use without express written permission from the data owner.
- Series with "Copyrighted: Citation required" labels may be displayed in reports to clients with proper attribution.
- **Key restriction:** "Before using data series owned by third parties for anything other than personal use, you must contact the data owner to obtain permission."

**Required actions:**
- **Audit which FRED series** strategies commonly use and identify third-party data owners.
- **Ensure attribution** ("Source: [Original Source] via FRED") is included in all strategy outputs that use FRED data.
- **Contact data owners** for any series used commercially in marketplace strategies.
- **Consider restricting marketplace strategies** to public-domain FRED series only, or implementing a data source compliance check.

### 6.3 SEC EDGAR

**Current status:** Low risk. Public domain data, freely usable.

**v3 impact: MINIMAL.** SEC filings are public domain. No additional ToS concerns for marketplace use. Continue to comply with rate limits (10 req/sec) and User-Agent requirements.

### 6.4 S3 Parquet Data Lake (PricePlugin)

**Impact depends on data source licensing.** The legal audit notes the PricePlugin reads from an S3-backed Parquet data lake with "officially licensed data sources." The specific license terms for this data must be reviewed to confirm that marketplace redistribution is covered.

**Required action:** Review S3 data lake source licensing agreements for redistribution rights in a marketplace context.

**Citation:** FRED API Terms of Use (https://fred.stlouisfed.org/docs/api/terms_of_use.html); Finnhub Pricing (https://finnhub.io/pricing-startups-and-enterprise)

---

## 7. Marketplace Legal Document Checklist

Beyond the ToS and Privacy Policy already identified in the v1 audit, the following documents are needed for marketplace launch:

### 7.1 Required Documents

| # | Document | Purpose | Est. Cost |
|---|----------|---------|-----------|
| 1 | **Developer Agreement** | Governs relationship between Finlet and strategy developers (publishers). Covers IP license, revenue share, content standards, compliance obligations, indemnification, termination. | $3-5K (attorney) |
| 2 | **Marketplace Terms of Use** | Separate from platform ToS. Governs buyer-seller relationship, payment terms, refund policy, dispute resolution for marketplace transactions. | $2-4K (attorney) |
| 3 | **Strategy Listing Guidelines** | Content standards for strategy descriptions, prohibited claims, required disclaimers, review process. Can be part of Developer Agreement. | $0 (internal) |
| 4 | **IP License Agreement** | Clarifies IP ownership — developer retains IP, grants Finlet a license to host, display, and distribute. Addresses derivative works, modifications, and competing platforms. | Included in Developer Agreement |
| 5 | **Revenue Share Terms** | Commission structure, payment schedule, tax reporting (1099-K for US developers), minimum payout thresholds, chargebacks. | Included in Developer Agreement |
| 6 | **Refund/Dispute Resolution Policy** | Refund windows, dispute escalation, mediation vs. arbitration clause, chargebacks. | $1-2K (attorney) |
| 7 | **DMCA/IP Takedown Policy** | Process for handling IP infringement claims between developers, counter-notification procedures. Safe harbor under 17 U.S.C. § 512. | $1-2K (attorney) |
| 8 | **Financial Disclaimer Addendum** | Marketplace-specific disclaimers supplementing the platform-level disclaimers from the v1 audit. Must appear on every strategy listing. | $0 (internal) |
| 9 | **Developer Compliance Attestation** | Self-certification form for regulatory compliance in developer's jurisdiction (IA registration, FCA authorization, etc.). | $0 (internal) |

### 7.2 Recommended (Phase 2) Documents

| # | Document | Purpose | Est. Cost |
|---|----------|---------|-----------|
| 10 | **Acceptable Use Policy (Marketplace)** | Prohibited strategy behaviors (market manipulation patterns, excessive risk, etc.). | $0 (internal) |
| 11 | **Data Processing Agreement (DPA)** | GDPR Article 28 compliance for processing developer and buyer data. | $2-3K (attorney) |
| 12 | **Bug Bounty / Responsible Disclosure** | For security vulnerabilities in strategies or platform. | $0 (internal) |
| 13 | **International Regulatory Addendum** | Country-specific terms for jurisdictions with heightened requirements (EU, UK, Singapore). | $3-5K per jurisdiction |

**Total estimated legal document cost for marketplace launch: $7-13K**

---

## 8. Safe vs. Unsafe Marketing Language

### 8.1 Strategy Descriptions — Developer-Facing Guidelines

| UNSAFE (Prohibited) | SAFE (Permitted) | Why |
|---------------------|-------------------|-----|
| "This strategy generates 15% annual returns" | "This strategy achieved 15% simulated annual returns in backtesting over period X-Y" | Unqualified return claims imply real-world performance |
| "AI-powered alpha generation" | "Uses machine learning to analyze historical price patterns" | "Alpha generation" implies market-beating real returns |
| "Beat the market with our AI" | "Evaluate your AI agent's decision-making against historical benchmarks" | Implies future market-beating capability |
| "Proven trading strategy" | "Backtested trading strategy" | "Proven" implies real-world validation |
| "Make money with AI trading" | "Explore AI-driven trading approaches in simulation" | Earnings claim |
| "Our algorithm predicts market movements" | "Our algorithm identifies historical patterns in market data" | Prediction claims trigger SEC AI-washing |
| "Guaranteed profits" / "Risk-free" | Never use these under any circumstances | Per se deceptive under FTC and SEC standards |
| "The first AI that..." / "The only AI that..." | Must be verifiable factual claims if used | Delphia/Global Predictions precedent |

### 8.2 Platform Marketing — Finlet-Facing Guidelines

| UNSAFE (Prohibited) | SAFE (Permitted) |
|---------------------|-------------------|
| "Marketplace of profitable AI trading strategies" | "Marketplace of AI trading strategies for simulation and research" |
| "Find strategies that beat the market" | "Explore strategies and evaluate their historical simulation performance" |
| "Top-performing AI agents" | "AI agents ranked by simulated benchmark results" |
| "Invest in AI trading" | "Build and test AI trading strategies" |
| "Our marketplace strategies outperform..." | "Compare strategy simulation results across historical periods" |

### 8.3 Required Disclaimer — Every Strategy Listing

The following must appear prominently on every marketplace strategy listing:

> **IMPORTANT:** This strategy's performance data reflects simulated results using historical market data on the Finlet platform. Simulated performance has inherent limitations: it is designed with the benefit of hindsight, does not reflect actual trading, and cannot account for real market conditions including liquidity, slippage, and market impact. Past simulated performance does not guarantee future results. No representation is made that any strategy will or is likely to achieve profits or losses similar to those shown. This strategy is a software tool for simulation and research purposes only and does not constitute investment advice. Finlet does not verify the accuracy of developer claims about strategy capabilities.

### 8.4 Required Disclaimer — Leaderboard

> **SIMULATION RESULTS ONLY.** Rankings reflect simulated benchmark performance on historical data. Simulated results have inherent limitations — they are designed with the benefit of hindsight and do not represent actual trading. Rankings do not constitute investment advice or recommendations. Finlet does not endorse any strategy.

---

## 9. Consolidated Action Items

### P0 — Before Marketplace Launch

| # | Action | Area | Est. Cost | Timeline |
|---|--------|------|-----------|----------|
| 1 | Obtain securities counsel opinion on marketplace IA registration | Regulatory | $5-10K | 4-6 weeks |
| 2 | Draft and execute Developer Agreement | Legal Docs | $3-5K | 2-4 weeks |
| 3 | Draft Marketplace Terms of Use | Legal Docs | $2-4K | 2-4 weeks |
| 4 | Draft Refund/Dispute Resolution Policy | Legal Docs | $1-2K | 2-4 weeks |
| 5 | Implement strategy listing review process (AI-washing compliance) | Compliance | Dev time | 2-3 weeks |
| 6 | Add mandatory disclaimers to all strategy listings and leaderboard | Compliance | Dev time | 1 week |
| 7 | Create prohibited language list and automated screening | Compliance | Dev time | 1-2 weeks |
| 8 | Upgrade Finnhub to paid plan and obtain commercial use authorization | Data ToS | $49+/mo | 1-2 weeks |
| 9 | Audit FRED series used in strategies for redistribution restrictions | Data ToS | Dev time | 1-2 weeks |
| 10 | Implement developer compliance attestation flow | Compliance | Dev time | 1 week |
| 11 | Review S3 data lake licensing for marketplace redistribution rights | Data ToS | $0-1K | 1 week |

### P1 — Within 30 Days of Marketplace Launch

| # | Action | Area | Est. Cost |
|---|--------|------|-----------|
| 12 | Draft DMCA/IP Takedown Policy | Legal Docs | $1-2K |
| 13 | Implement 1099-K tax reporting infrastructure for developers | Compliance | Dev time |
| 14 | Draft Marketplace Acceptable Use Policy | Legal Docs | $0 |
| 15 | Implement geo-blocking for sanctioned countries (OFAC) | Export Control | Dev time |

### P2 — Pre-International Expansion

| # | Action | Area | Est. Cost |
|---|--------|------|-----------|
| 16 | EU AI Act compliance assessment for marketplace strategies | International | $5-10K |
| 17 | MiFID II analysis for EU marketplace access | International | $5-10K |
| 18 | FCA analysis for UK marketplace access | International | $3-5K |
| 19 | MAS analysis for Singapore marketplace access | International | $3-5K |
| 20 | Draft international regulatory addenda for ToS | Legal Docs | $3-5K/jurisdiction |
| 21 | GDPR DPA for developer and buyer data | Privacy | $2-3K |

### Total Estimated Pre-Launch Legal Costs

| Category | Estimate |
|----------|----------|
| Securities counsel opinion | $5-10K |
| Legal documents (Developer Agreement, Marketplace ToS, policies) | $7-13K |
| Finnhub commercial plan | $49+/mo ongoing |
| **Total one-time** | **$12-23K** |
| **Total ongoing** | **$600+/year (Finnhub)** |

### International Expansion (if pursued)

| Category | Estimate |
|----------|----------|
| Per-jurisdiction regulatory analysis | $3-10K each |
| EU AI Act compliance | $5-10K |
| International legal addenda | $3-5K/jurisdiction |
| **Total for EU + UK + Singapore** | **$16-30K** |

---

## 10. Risk Matrix

### By Area — v3 Marketplace

| Area | v1 (Current) | v3 (Marketplace) | Key Driver |
|------|-------------|-------------------|------------|
| Investment Advisers Act | LOW | **MEDIUM-HIGH** | Strategy sales = advice for compensation |
| SEC AI-Washing | MEDIUM | **HIGH** | Commercial AI claims by third-party developers |
| FTC Deceptive Claims | LOW | **MEDIUM-HIGH** | Performance data on paid strategies |
| Howey Test (Securities) | NONE | **MEDIUM** | Strategy subscription models |
| CFTC/CTA | NONE | **LOW** | No futures/derivatives in v1 universe |
| MiFID II (EU) | N/A | **MEDIUM-HIGH** | If EU users access marketplace |
| EU AI Act | N/A | **HIGH** | Algorithmic trading classified high-risk |
| FCA (UK) | N/A | **MEDIUM** | Copy trading suitability requirements |
| MAS (Singapore) | N/A | **MEDIUM** | Agentic AI + robo-advisory focus |
| IOSCO Copy Trading | N/A | **MEDIUM** | Good practices framework |
| Finnhub ToS | MEDIUM | **HIGH** | Commercial use on free tier prohibited |
| FRED ToS | MEDIUM | **MEDIUM-HIGH** | Third-party data redistribution restrictions |
| EDGAR ToS | LOW | **LOW** | Public domain, no change |
| Data Lake Licensing | LOW | **MEDIUM** | Redistribution rights unclear |

### Overall Risk Summary

| Risk Level | Count | Items |
|------------|-------|-------|
| **HIGH** | 3 | SEC AI-Washing, EU AI Act, Finnhub ToS |
| **MEDIUM-HIGH** | 5 | Investment Advisers Act, FTC Claims, FRED ToS, MiFID II, Data Lake |
| **MEDIUM** | 4 | Howey Test, FCA, MAS, IOSCO |
| **LOW** | 2 | CFTC, EDGAR ToS |

---

## Legal Framework References (Marketplace-Specific)

### Federal Statutes & Rules
- **Investment Advisers Act of 1940** — 15 U.S.C. § 80b-2(a)(11)
- **SEC Marketing Rule** — Rule 206(4)-1 (effective Nov. 4, 2022)
- **FTC Act Section 5** — 15 U.S.C. § 45
- **FTC Deceptive Earnings Claims Rule** — 16 CFR Part 461
- **CFTC Rule 4.41(b)(1)** — Hypothetical performance disclaimers
- **NFA Compliance Rule 2-29(c)(1)** — Simulated results promotional material
- **DMCA Safe Harbor** — 17 U.S.C. § 512

### Case Law
- *SEC v. W.J. Howey Co.*, 328 U.S. 293 (1946) — Investment contract test
- *Lowe v. SEC*, 472 U.S. 181 (1985) — Publisher's exclusion
- *SEC v. Barry* (9th Cir. 2025) — Howey test still applies to digital assets

### SEC Enforcement Actions
- Delphia (USA) Inc. — File No. 3-21895 (March 2024) — AI-washing, $225K penalty
- Global Predictions, Inc. — File No. 3-21896 (March 2024) — AI-washing, $175K penalty

### FTC Enforcement Actions
- Operation AI Comply (September 2024) — Five simultaneous actions
- DoNotPay — $193K settlement (September 2024)
- FloatMe — deceptive algorithmic claims (January 2024)
- Cleo AI — $17M settlement (2025)

### International Regulations
- **MiFID II** — Directive 2014/65/EU, Article 17 (algorithmic trading)
- **EU AI Act** — Regulation (EU) 2024/1689 (entered force August 1, 2024)
- **FCA Handbook** — MAR 7A (algorithmic trading, onshored MiFID II)
- **MAS** — Securities and Futures Act; AI Risk Management Guidelines (proposed November 2025)
- **IOSCO** — Final Report FR/06/2025 on Online Imitative Trading Practices

### SEC Regulatory Guidance
- SEC 2026 Examination Priorities (AI focus)
- SEC AI Task Force (launched August 2025)
- SEC Marketing Rule FAQs (updated March 19, 2025)
- December 2025 SEC Risk Alert on Marketing Rule compliance

---

*This brief is for informational purposes and does not constitute legal advice. Consult qualified securities counsel licensed in your jurisdiction before making legal or business decisions based on these findings. Specific emphasis: the Investment Advisers Act and Howey test analyses in Sections 1 and 4 require a formal legal opinion from securities counsel before marketplace launch.*
