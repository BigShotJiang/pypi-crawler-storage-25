# Finlet — Competitive & Marketplace Analysis

**Date:** 2026-03-23
**Author:** Market Research Agent (Security Council)
**Status:** Complete

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Direct Competitor Analysis](#2-direct-competitor-analysis)
3. [Competitor Comparison Table](#3-competitor-comparison-table)
4. [AWS Marketplace Landscape](#4-aws-marketplace-landscape)
5. [Competitive Positioning](#5-competitive-positioning)
6. [Pricing Strategy Recommendation](#6-pricing-strategy-recommendation)
7. [Market Size Estimates](#7-market-size-estimates)
8. [Go-to-Market Priorities](#8-go-to-market-priorities)

---

## 1. Executive Summary

Finlet occupies a unique position in the financial technology landscape: it is an **AI agent testing environment**, not an algorithmic trading platform. While competitors focus on strategy execution, backtesting for humans, or copy-trading marketplaces, Finlet's core value proposition is evaluating AI agent reasoning against historical market data with rigorous time-integrity guarantees.

**Key finding:** No direct competitor offers time-locked simulation with a date ceiling enforcer specifically designed for AI agent evaluation. This is a genuinely unoccupied niche at the intersection of two fast-growing markets: algorithmic trading ($25B in 2026, 14.4% CAGR) and AI agent tooling ($10.9B in 2026, 46.3% CAGR).

**Recommended positioning:** "The testing lab for AI trading agents" — not another backtesting tool, not another algo trading platform.

---

## 2. Direct Competitor Analysis

### 2.1 QuantConnect (Lean Engine)

**Overview:** The world's leading open-source, multi-asset algorithmic trading platform. 475,000 registered users, 50,000 MAU, 170+ countries. Processes $45B in notional volume monthly.

**Pricing:**
| Plan | Monthly | Annual |
|------|---------|--------|
| Researcher | $60 | $600 |
| Team | $120 | $1,200 |
| Trading Firm | $336 | $3,360 |
| Institution | $1,080 | $10,800 |

Live trading nodes start at $24/month. GPU research nodes at $400/month.

**Alpha Streams Marketplace:** QuantConnect's strategy marketplace uses a fixed monthly subscription model (not revenue share). Funds pay a "Shared Price" or an "Exclusive Price" to license alphas. QuantConnect takes a 30% fee for hosting and serving algorithms.

**Regulatory Approach:** QuantConnect is not registered as a broker-dealer or RIA. They position as infrastructure/tooling. Strict IP protection via code encryption (AES-256) and non-reverse-engineering clauses. They only work with funds that have their own internal compliance departments.

**Lessons for Finlet:**
- The subscription model for alpha licensing (vs. revenue share) simplifies regulatory exposure — no need for performance audits or allocation tracking
- Code encryption and IP protection are table stakes for any marketplace
- Positioning as infrastructure/tooling (not advice) keeps regulatory burden low
- 400TB+ of included data is a major competitive moat

---

### 2.2 Composer

**Overview:** No-code trading strategy builder with AI-powered strategy creation. Users can build, backtest, and execute real trading strategies without coding.

**Pricing:** $30/month or $288/year. Zero commissions, zero management fees. FINRA/SEC regulatory fees charged on securities sales.

**Regulatory Status:** **Dual-registered.** Composer Securities LLC is a broker-dealer registered with the SEC and member of FINRA/SIPC. Composer Technologies Inc. is registered as an investment adviser with the SEC.

**User Base:** Smaller than QuantConnect but growing. Backed by venture funding. Focused on retail US investors.

**Lessons for Finlet:**
- Composer's dual registration (B/D + RIA) is expensive and complex — they need it because they execute real trades and provide strategy recommendations
- Their no-code approach lowers the barrier to entry dramatically
- Finlet's simulation-only model avoids the need for B/D or RIA registration entirely
- Community strategy sharing is a strong engagement driver

---

### 2.3 Alpaca

**Overview:** Commission-free trading API for developers. Brokerage-as-a-service model. Achieved Nasdaq exchange membership.

**Pricing:** Commission-free for self-directed accounts. Revenue from payment for order flow and brokerage-as-a-service licensing to fintechs.

**Regulatory Status:** Registered broker-dealer, FINRA member, SIPC member. Full regulatory compliance for real securities transactions.

**Marketplace Features:** Paper trading for strategy testing. No formal strategy marketplace — they are infrastructure (API), not a strategy platform.

**Lessons for Finlet:**
- Alpaca proves the developer-first API model works for trading infrastructure
- Their paper trading is the closest analog to Finlet's simulation, but lacks time-locking, date ceiling enforcement, or AI agent-specific features
- Alpaca is a potential integration partner for Finlet's future v5 Live Trading layer
- B2B (brokerage-as-a-service) can be more lucrative than B2C

---

### 2.4 Numerai

**Overview:** Crowdsourced hedge fund using AI tournament model. $500M valuation after Series C ($30M raised). JPMorgan allocated $500M through the fund. 25.45% net return in 2024. $450M AUM.

**Tournament Model:** Data scientists build ML models on encrypted/obfuscated data. They stake NMR (Numeraire) cryptocurrency on their predictions. Positive scores earn NMR; negative scores burn staked NMR.

**Securities Law Approach:** Numerai's model is architecturally designed to minimize regulatory exposure:
- Participants never see raw financial data — they receive obfuscated, normalized datasets
- Participants submit predictions, not trading strategies — Numerai's internal team makes actual trading decisions
- NMR staking is framed as a "skin in the game" mechanism, not an investment contract
- The fund itself is a traditional hedge fund with LP structure (institutional investors like JPMorgan)
- The tournament/prediction layer is separate from the fund management layer

**Lessons for Finlet:**
- Separating "intelligence contribution" from "fund management" is a powerful regulatory architecture
- Cryptocurrency rewards create regulatory complexity but also global accessibility
- Institutional validation (JPMorgan) legitimizes the crowdsourced approach
- Obfuscated data prevents participants from front-running
- Finlet's date ceiling enforcer serves a similar purpose (preventing data leakage) but for a different use case

---

### 2.5 TradingView

**Overview:** The dominant financial charting and social trading platform. 100M+ users globally. Founded 2011.

**Pricing:**
| Plan | Annual Price |
|------|-------------|
| Basic | Free |
| Essential | ~$208/year |
| Plus | ~$360/year |
| Premium | ~$720/year |
| Expert | ~$1,440/year |
| Ultimate | ~$3,215/year |
| Enterprise | Custom |

**Strategy Marketplace:** Pine Script-based community strategies (free sharing, not paid marketplace). Users publish indicators and strategies that others can use. Revenue comes from subscriptions, not strategy sales.

**Regulatory Approach:** TradingView does not provide brokerage services or financial advice directly. They partner with regulated brokers. Professional plans exist for FINRA-registered traders with enhanced data and compliance features.

**Lessons for Finlet:**
- Community-driven content (strategies, indicators) drives massive engagement and retention
- The "platform, not broker" positioning minimizes regulatory burden
- 100M users shows the scale possible with a charting/analysis platform
- Free tier is essential for building community
- Not a direct competitor to Finlet, but the community engagement model is relevant

---

### 2.6 Collective2

**Overview:** Strategy marketplace with auto-trading. Matches strategy developers with investors who want to follow/copy trades. Partners with CFTC and NFA within the US. Authorized by CySEC in Europe (MEXEM LTD brand).

**Pricing:**
- Strategy subscribers: $50-$200/month per strategy (set by strategy developer)
- Strategy developers: $19-$39/month for single strategy, $99/month for up to 3 strategies
- AutoTrade: Free (Europe), included with subscription (US)

**Regulatory Approach:** CFTC/NFA partner in US. CySEC license (CIF 325/17) in Europe. This is one of the most regulated strategy marketplace models.

**Lessons for Finlet:**
- Collective2 proves that a strategy marketplace *can* operate within regulatory frameworks, but it requires significant compliance investment
- CFTC/NFA partnership is specifically for futures strategies — equities would require different registration
- The developer-pays-to-list model creates quality filtering
- Auto-trading across multiple brokers adds significant complexity
- **Most relevant competitor for Finlet's future v3 Marketplace** — study their regulatory structure carefully

---

### 2.7 Regional Platforms: Streak, Mudrex

#### Streak (Zerodha)
- **Market:** India-focused, integrated with Zerodha (India's largest discount broker)
- **Pricing:** ₹690-₹1,400/month ($8-$17/month)
- **Model:** No-code strategy builder + backtesting + live deployment
- **Regulation:** Operates under Zerodha's SEBI registration
- **Limitation:** Only works with Zerodha's Kite platform. Max 5 live deployments.

#### Mudrex
- **Market:** Crypto-focused, India + international
- **Pricing:** No management fees, trading fees 0.45%/0.45% (maker/taker)
- **Regulation:** FIU-IND (India), OAM (Italy), Bank of Lithuania. No Tier-1 regulation.
- **Model:** Invest in premade crypto bots/strategies. Strategy marketplace with performance stats.
- **Notable:** Recently launched Mudrex MCP (Model Context Protocol integration), making them one of the few platforms with native AI agent support.

**Lessons for Finlet:**
- Regional pricing must reflect local purchasing power
- Integration with local brokers is critical for regional adoption
- Mudrex's MCP integration is a direct competitive signal — AI agent integration is becoming standard
- Crypto platforms face different (often lighter) regulatory requirements

---

## 3. Competitor Comparison Table

| Feature | **Finlet** | **QuantConnect** | **Composer** | **Alpaca** | **Numerai** | **TradingView** | **Collective2** |
|---------|-----------|-----------------|-------------|-----------|-------------|-----------------|----------------|
| **Primary Function** | AI agent testing | Algo trading platform | No-code trading | Trading API | Crowdsourced hedge fund | Charting + social | Strategy marketplace |
| **Target User** | AI/ML developers, quant researchers | Quant developers | Retail investors | Developers, fintechs | Data scientists | All traders | Strategy developers + followers |
| **Real Trading** | No (simulation only) | Yes | Yes | Yes | Yes (internal) | Via broker partners | Yes (auto-trade) |
| **Time-Locked Sim** | Yes (core feature) | No | No | No | N/A | No | No |
| **Date Ceiling Enforcer** | Yes (defense-in-depth) | No | No | No | Obfuscated data | No | No |
| **MCP Integration** | Yes (native) | No | No | No | No | No | No |
| **AI Agent-First** | Yes | No (human-first, AI assistant) | No (human-first) | No | Partially (ML models) | No | No |
| **Strategy Marketplace** | Future (v3) | Yes (Alpha Streams) | Community sharing | No | Tournament | Community (free) | Yes (paid) |
| **Pricing Model** | SaaS subscription | $60-$1,080/month | $30/month | Free (commission-free) | Free (stake NMR) | Free-$3,215/year | $50-$200/mo per strategy |
| **Regulatory Status** | None required (v1) | None (infrastructure) | B/D + RIA | B/D, FINRA, SIPC | Hedge fund (LP) | Platform (no B/D) | CFTC/NFA + CySEC |
| **User Base** | Pre-launch | 475K registered | ~50K est. | 100K+ developers | ~10K data scientists | 100M+ | ~50K est. |
| **Data Sources** | SEC EDGAR, FRED, Finnhub, S3 Parquet | 400TB+ included | Market data via B/D | Real-time + historical | Obfuscated/encrypted | Multi-source | Via broker feeds |

---

## 4. AWS Marketplace Landscape

### 4.1 Search Findings

AWS Marketplace was searched for: algorithmic trading, backtesting, AI trading, financial simulation, and market data platforms. Key findings:

**No direct competitors found on AWS Marketplace.** The search returned:
- Professional services (Geniusee custom trading software development)
- Enterprise infrastructure (Aeron low-latency messaging by Adaptive, Numerix quantitative analytics)
- Market data transfer (Zenlayer FSI Market Data Transfer)
- Risk/compliance tools (EAGLE AI TradeWatch, ACA Market Abuse Surveillance)
- Financial analytics platforms (AlphaSense, Deloitte 10X Analyst, PwC Advanced Finance Analytics)
- Data platforms (FINBOURNE LUSID, Caylent FinLake, Digital Alpha Market Intelligence)

**Notable finds:**
- **AlphaSense** — 4.6/5 rating, 308 reviews. AI-powered financial research platform. Enterprise-grade. Not a simulation tool, but shows demand for AI-powered financial intelligence on AWS.
- **Deloitte 10X Analyst** — Agentic AI platform for financial services. Shows enterprise appetite for AI agents in finance.
- **Digital Alpha Market Intelligence** — S3-based data lake for public financial data. Similar architecture to Finlet's PricePlugin.

### 4.2 AWS Marketplace Opportunity Assessment

| Factor | Assessment |
|--------|-----------|
| **Competition** | **NONE** — No AI agent testing/simulation platforms found |
| **Adjacent Products** | Enterprise financial analytics, risk tools, data platforms |
| **Buyer Persona** | Quant teams at hedge funds, banks, fintechs with AWS infrastructure |
| **Pricing Fit** | SaaS subscription model is standard on AWS Marketplace |
| **Distribution** | AWS Marketplace provides procurement simplification for enterprise buyers |
| **Revenue Impact** | AWS takes 3-5% on SaaS listings (lower than most app stores) |

### 4.3 Recommendation: List on AWS Marketplace

**YES — Finlet should be listed on AWS Marketplace as a SaaS product.** Rationale:

1. **Zero competition** in the AI agent testing/simulation category
2. **Enterprise procurement** — AWS Marketplace simplifies purchasing for enterprise buyers (consolidated billing, pre-negotiated terms)
3. **AWS credits** — Customers can apply AWS credits/EDPs to Marketplace purchases, lowering effective cost
4. **Trust signal** — AWS Marketplace listing adds credibility for enterprise sales
5. **Low take rate** — 3-5% is reasonable compared to the distribution benefit
6. **Finlet already runs on AWS** — Natural alignment

**Listing approach:** Start with a SaaS listing (contract-based pricing). Offer free trial tier. Position in "Financial Services" and "Machine Learning" categories.

---

## 5. Competitive Positioning

### 5.1 Unique Positioning: "The Testing Lab for AI Trading Agents"

Finlet is NOT:
- An algorithmic trading platform (QuantConnect)
- A no-code strategy builder (Composer, Streak)
- A trading API (Alpaca)
- A crowdsourced hedge fund (Numerai)
- A charting/social platform (TradingView)
- A strategy marketplace (Collective2)

Finlet IS:
- An Integrated Testing Environment (ITE) for AI trading agents
- The only platform with time-locked simulation + date ceiling enforcement
- Built for the MCP/AI agent ecosystem (Claude, GPT, etc.)
- A reasoning evaluation tool, not just a P&L tracker

### 5.2 Key Differentiators

| Differentiator | Why It Matters | Who Cares |
|---------------|----------------|-----------|
| **Time-locked simulation clock** | Prevents future data leakage that invalidates backtests | Quant researchers, AI labs |
| **Date ceiling enforcer (defense-in-depth)** | Double-layer data integrity that no competitor offers | Institutional investors evaluating AI agents |
| **MCP-native integration** | Works with Claude, other AI agents out of the box | AI developers, agent builders |
| **Reasoning trace capture** | Records *why* an agent made decisions, not just what it did | AI safety researchers, compliance teams |
| **Plugin architecture** | Multi-source data (SEC EDGAR, FRED, Finnhub) with unified ceiling enforcement | Data-intensive research teams |
| **Simulation-only (no real trading)** | Eliminates B/D and RIA regulatory requirements | Finlet's legal/compliance posture |

### 5.3 Competitive Moat

1. **Technical moat:** The date ceiling enforcer + simulation clock architecture is non-trivial to replicate and potentially patentable (see Legal Audit P3 action item #20)
2. **Ecosystem moat:** First-mover in MCP-native financial simulation. As the AI agent ecosystem grows, Finlet is the native testing tool.
3. **Data integrity moat:** Point-in-time accuracy (FRED ALFRED vintage dates, SEC filing dates) is hard to get right and easy to get wrong
4. **Regulatory moat:** By staying simulation-only, Finlet avoids the compliance costs that burden competitors who touch real money

---

## 6. Pricing Strategy Recommendation

### 6.1 Recommended Pricing Tiers

Based on competitive benchmarks and Finlet's positioning:

| Tier | Price | Target | Includes |
|------|-------|--------|----------|
| **Explorer** (Free) | $0 | Individual developers, students | 1 session, 5 tickers, FROZEN mode only, community data, 1,000 API calls/day |
| **Developer** | $49/month ($468/year) | AI developers, indie quants | 5 concurrent sessions, 50 tickers, all clock modes, all plugins, 10K API calls/day, MCP access |
| **Team** | $149/month ($1,428/year) | Small quant teams, startups | 20 sessions, unlimited tickers, team collaboration, priority support, 50K API calls/day, API key management |
| **Enterprise** | $499/month ($4,788/year) | Hedge funds, AI labs, institutions | Unlimited sessions, dedicated infrastructure, SSO/SAML, SLA, custom data plugins, audit logs, 500K API calls/day |
| **Custom** | Contact sales | Large institutions | On-premise deployment, custom integrations, dedicated support, compliance packages |

### 6.2 Pricing Rationale

- **Free tier is essential** — QuantConnect, TradingView, and Alpaca all offer free tiers. This drives adoption and community.
- **$49 Developer tier** sits below QuantConnect's $60 Researcher plan and above Streak's ~$17. Sweet spot for individual developers.
- **$149 Team tier** is competitive with QuantConnect's $120 Team plan while offering AI-specific features they don't have.
- **$499 Enterprise tier** is well below QuantConnect's $1,080 Institution plan and far below AlphaSense's enterprise pricing ($25K+/year).
- **No per-trade fees** — Finlet is simulation-only, so per-trade pricing doesn't apply. This simplifies billing.

### 6.3 Future Marketplace Revenue (v3)

When the v3 Marketplace launches, adopt QuantConnect's subscription model (not revenue share):
- Strategy developers set monthly prices
- Finlet takes 20-30% platform fee (QuantConnect takes 30%)
- Avoid revenue share to minimize regulatory exposure (no need for performance audits)
- Require all marketplace listings to include simulation-only disclaimers

---

## 7. Market Size Estimates

### 7.1 Total Addressable Market (TAM)

Finlet sits at the intersection of two markets:

| Market | 2026 Size | 2030 Projection | CAGR |
|--------|-----------|-----------------|------|
| Algorithmic Trading Platforms | $25.04B | $44.34B | 14.4% |
| AI Agent Tooling & Evaluation | $10.91B | $52.62B | 46.3% |

**Combined TAM:** ~$36B (2026), with significant overlap.

However, Finlet's specific TAM is the intersection: **AI agent financial testing tools.** This is a nascent category.

### 7.2 Serviceable Addressable Market (SAM)

Finlet's SAM includes:
- Quant researchers building AI trading agents (~50,000 globally, based on QuantConnect's MAU)
- AI/ML teams at hedge funds and asset managers (~5,000 firms globally)
- AI agent developers who need financial domain testing (~100,000 globally, growing rapidly)
- University research labs (AI + finance departments, ~2,000 programs)

**Estimated SAM:** ~$500M-$1B annually (assuming 150K potential users at $50-$500/month average)

### 7.3 Serviceable Obtainable Market (SOM)

Year 1-2 realistic targets:
- 5,000 free tier users
- 500 paid Developer tier users ($49/month = $294K ARR)
- 50 Team accounts ($149/month = $89K ARR)
- 10 Enterprise accounts ($499/month = $60K ARR)

**Year 2 target ARR:** ~$443K

Year 3-5 with marketplace (v3):
- 20,000 free tier users
- 3,000 paid users across tiers
- 200 marketplace strategy listings (20-30% take rate)

**Year 5 target ARR:** $2-5M

---

## 8. Go-to-Market Priorities

### 8.1 Phase 1: Developer Adoption (Months 1-6)

| Priority | Action | Why |
|----------|--------|-----|
| 1 | **Launch free tier** | Table stakes. Every competitor offers free access. |
| 2 | **MCP integration docs + Claude Code tutorial** | Unique differentiator. No competitor has this. |
| 3 | **Publish on AWS Marketplace** | Enterprise distribution + credibility. Zero competition. |
| 4 | **Developer blog content** | "How to test your AI trading agent" series. SEO play for the emerging category. |
| 5 | **GitHub presence** | Open-source the MCP tools/SDK (not the core engine). Community building. |

### 8.2 Phase 2: Community & Content (Months 6-12)

| Priority | Action | Why |
|----------|--------|-----|
| 1 | **Leaderboard launch** | Gamification drives engagement (see Numerai's tournament model). Use "simulated benchmark results" language per Legal Audit. |
| 2 | **University partnerships** | AI + finance programs. Free Enterprise tier for academic research. Pipeline for future paying users. |
| 3 | **Conference presence** | NeurIPS, ICAIF, QuantCon. This is where the target audience gathers. |
| 4 | **Integration partnerships** | Alpaca (future live trading), Anthropic (MCP ecosystem), OpenAI (agent tooling). |

### 8.3 Phase 3: Enterprise & Marketplace (Months 12-24)

| Priority | Action | Why |
|----------|--------|-----|
| 1 | **Enterprise sales motion** | Direct outreach to hedge funds and AI labs. AWS Marketplace as procurement vehicle. |
| 2 | **v3 Marketplace beta** | Consult securities counsel first (Legal Audit P3 #21, budget $2-5K). |
| 3 | **SOC 2 Type II** | Required for enterprise sales. Start process at month 12. |
| 4 | **Patent filing** | Provisional patent for date ceiling enforcer architecture (Legal Audit P3 #20, budget $1.5-3K). |

### 8.4 Key Risks

| Risk | Mitigation |
|------|-----------|
| QuantConnect adds AI agent features | Finlet's time-locking and MCP-native design are hard to retrofit. First-mover advantage in the niche. |
| Mudrex MCP integration gains traction | Mudrex is crypto-only and India-focused. Finlet covers equities, filings, economic data. |
| Market category doesn't emerge | Hedge against by positioning as "advanced backtesting" as well as "AI agent testing." |
| Enterprise sales cycle too long | AWS Marketplace + free tier create self-serve pipeline. Don't depend solely on enterprise. |
| Regulatory changes | Simulation-only positioning is the strongest defense. Monitor SEC AI guidance. |

---

## Appendix: Sources

### Competitor Research
- QuantConnect: quantconnect.com/pricing, G2 reviews, LuxAlgo review
- Composer: composer.trade/pricing, SEC EDGAR ADV filing (CRD# 311289)
- Alpaca: alpaca.markets, SmartAsset review, BrokerChooser review
- Numerai: numer.ai, Crunchbase, Crowdsourcing Week (JPMorgan investment)
- TradingView: tradingview.com/pricing, StockBrokers.com review, Strike Money review
- Collective2: trade.collective2.com/pricing, AlgoTrades review, DayTradeReview
- Streak: thebeststockbroker.com/zerodha-streak, AlgoTest comparison
- Mudrex: SoftwareSuggest, TradersUnion review, Mudrex blog (MCP announcement)

### Market Size
- Algorithmic Trading: Technavio, Grand View Research, Precedence Research, Fortune Business Insights
- AI Agent Market: MarketsandMarkets, Grand View Research, CB Insights
- AI Tooling: Pragmatic Engineer newsletter, StackOne landscape report

### AWS Marketplace
- Direct catalog search via AWS Marketplace API (March 2026)
- AWS Marketplace report guidelines (recommendations workflow)

---

*This analysis is for internal strategic planning purposes. Market data and competitor information are based on publicly available sources as of March 2026.*
