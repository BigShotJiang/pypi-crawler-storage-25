# Blind-Agent Cold-Start Report — v1.0.0 Re-walk

> Walk performed: 2026-05-10T21:00 — 21:06 UTC
> Deployed SHA: f679447 (matches local HEAD; /health does not expose SHA)
> Walker: claude-opus-4-7 cold-context subagent
> Editable install used (per task instruction): `pip install -e /Users/justnau/finlet` against `pyproject.toml` `version = "1.0.0"`
> Python: 3.14.3
> Account created: blind-walker-1778446745@finlet-test.dev (web), blind-walker-cli-… (CLI register), blind-pypi-… (stale-wheel control)

## TL;DR

- **BLOCKERs: 2**
  1. **`pip install finlet` (the only install command in the public docs) does NOT install `mcp`, but every v1.0.0 CLI command imports `mcp.client.session` at module load — every `finlet --help`, `finlet session ...`, `finlet portfolio ...` invocation crashes with `ModuleNotFoundError: No module named 'mcp'` before any business logic runs.**
  2. **`finlet auth login` — the only path the v1.0.0 CLI offers to talk to the prod MCP tool surface — fails at the OAuth `/oauth/authorize` step with `{"error":"invalid_client","error_description":"Unknown client_id='finlet-cli'. Register the client via POST /oauth/register first."}`. The CLI hardcodes `_OAUTH_CLIENT_ID = "finlet-cli"` (cli.py:56), but no static `finlet-cli` client is seeded on the prod OAuth server. DCR works (POST /oauth/register returns 201) but the CLI never calls it.**
- **HIGHs: 4** (documentation tells the user the wrong server URL; documented happy path with FINLET_API_KEY is dead on the v1.0.0 MCP surface; CLI dispatch logs `Failed to parse JSONRPC message` traceback before printing the user-friendly error; web-signup identity vs CLI-register identity are split with no UX bridge)
- **MEDIUMs: 3** (UI session-create takes 26.9s vs REST direct ~250ms; agent-guide's `Tip` says set `FINLET_API_KEY=your_api_key_here` then config block uses literal `"your_api_key_here"` placeholder; `web` identity has no in-product way to mint an API key — message says "Use the CLI to create an API key: `finlet register`", but that creates a *different* identity)
- **LOWs: 1** (auth.html uses `Sign In` as default tab even on the "Get Started Free" CTA)
- **Overall verdict: HOLD on BLOCKERs.** Do NOT tag v1.0.0. Two independent install/launch-blockers in the documented happy path. The currently-published PyPI `finlet 0.1.1` IS what users would install today, and that path *does* work end-to-end against prod with the documented commands — shipping v1.0.0 to PyPI in its current form would *regress* the working flow that v0.1.1 delivers.

## Phase 1 — Discovery

Opened https://finlet.dev/. Landing page is well-designed and clear:
- H1: "Backtest your AI agent against real market data"
- Three trust signals: "Free tier — 4 sessions/day", "No credit card required", "API key in 30 seconds"
- Two CTAs visible above the fold: "Get Started Free" → /auth.html, "Setup Guide" → /setup.html
- Footer "Sign In" → /auth.html

Sign-up CTA findability: trivially obvious. Two large buttons, no friction.

`/health` returns `{"status":"ok","dashboard_available":true,"data_status":{"prices":"available"}}` (HTTP 200, ~210ms). No SHA exposed; cannot independently confirm deployed-version match without comparing behavior.

## Phase 2 — Signup

- Clicked "Get Started Free" → /auth.html → switched to "Create Account" tab.
- Filled email `blind-walker-1778446745@finlet-test.dev`, password `BlindWalker2026!`, ticked Terms checkbox.
- Submitted "Create Account" — instant success: `Account created. You're all set. You can now sign in with your email and password.` ([Go to Dashboard] button rendered.)
- Clicked → landed on `/index.html` Dashboard, header shows "blind-walker-1778446745@finlet-test.dev / Free tier".
- "Welcome to Finlet" alert: "You don't have a session yet. Create your first session below to start backtesting your trading agent." with [Create Your First Session] button **and** the text "or use `finlet session create` from the CLI".

Finding: web-signup completes cleanly. **No credentials shown**. The user has an account but not an API key. Banner directs to the CLI for that.

## Phase 3 — CLI installation

Followed the task-supplied workaround (editable install) to exercise v1.0.0 code:

```
$ python3 -m venv /tmp/finlet-blind-walk
$ source /tmp/finlet-blind-walk/bin/activate
$ pip install -e /Users/justnau/finlet
Successfully installed ... finlet-1.0.0 ... typer-0.25.1 httpx-0.28.1 rich-15.0.0 ... 
```

Build OK. Wheel: `finlet-1.0.0-py3-none-any.whl`.

Then:

```
$ /tmp/finlet-blind-walk/bin/finlet --help
Traceback (most recent call last):
  File "/tmp/finlet-blind-walk/bin/finlet", line 3, in <module>
    from finlet.cli import app
  File "/Users/justnau/finlet/finlet/cli.py", line 34, in <module>
    from finlet.cli_mcp_client import MCPDispatchError, call_tool_sync
  File "/Users/justnau/finlet/finlet/cli_mcp_client.py", line 41, in <module>
    from mcp.client.session import ClientSession
ModuleNotFoundError: No module named 'mcp'
```

**This is BLOCKER #1.** `pip install finlet` (the literal docs instruction at https://finlet.dev/setup.html step 1) installs only `typer`, `httpx`, `rich`, but `finlet/cli_mcp_client.py:41` does `from mcp.client.session import ClientSession` at module top, which `cli.py:34` imports unconditionally. Every command crashes at module load, before Typer ever sees `--help`.

Validated by inspecting `pyproject.toml`:

```toml
dependencies = [
    "typer>=0.12",
    "httpx>=0.27",
    "rich>=13.0",
]
[project.optional-dependencies]
server = [
    ...
    "mcp[auth]>=1.27.0",
    ...
]
```

`mcp` lives in the `server` extra, not in `dependencies`. The docs do NOT mention `pip install finlet[server]` (verified via `WebFetch` of setup.html — only `pip install finlet` appears).

**To proceed with the walk** I installed `pip install -e '/Users/justnau/finlet[server]'` — 80+ transitive deps pulled (boto3, edgartools, sqlmodel, etc., ~80 MB) — which then made `finlet --help` work. **No real cold-start user would do this**; they would file a bug and walk away, OR (more likely) they would `pip install finlet` and get the **PyPI 0.1.1** wheel, which (see Phase 4 ground-truth control) actually works.

I also installed the published `finlet==0.1.1` from PyPI in a separate venv as a control. That install succeeds with the same 4 transitive deps, AND `finlet --help` works fine — because 0.1.1 routes everything through REST, not MCP-over-stdio.

## Phase 4 — First command

### v1.0.0 (editable install + `[server]` extras)

After `register` (succeeded; api_key minted; ~0.4s), I ran the documented first command verbatim from agent-guide.html:

```
$ export FINLET_API_KEY=<32-char hex string>
$ time finlet session create --name my-first-session --start 2024-01-01 --capital 100000 --universe AAPL,GOOGL,MSFT
[05/10/26 16:01:32] INFO     Processing request of type            server.py:727
                             CallToolRequest                                    
Failed to parse JSONRPC message from server
Traceback (most recent call last):
  File "/private/tmp/finlet-blind-walk/lib/python3.14/site-packages/mcp/client/stdio/__init__.py", line 155, in stdout_reader
    message = types.JSONRPCMessage.model_validate_json(line)
  ...
pydantic_core._pydantic_core.ValidationError: 1 validation error for JSONRPCMessage
  Invalid JSON: trailing characters at line 1 column 5 [type=json_invalid, input_value='2026-05-10 16:01:32 [war...reason=malformed_header', input_type=str]
                    INFO     Processing request of type            server.py:727
                             ListToolsRequest                                   
Error: Authentication required. Provide an api_key parameter to access Finlet MCP tools.
finlet session create ...  1.10s user 0.17s system 24% cpu 5.197 total
```

Exit 1. Two stacked failures:

1. **HIGH** — JSONRPC parse error pre-bias: the spawned `finlet mcp serve` subprocess emits a structured-log line on stderr/stdout that the MCP client tries to decode as JSONRPC and crashes. The walker sees the full pydantic traceback before the friendly error. (Likely a logging-handler-on-stdout misconfiguration in the spawned subprocess.)
2. **BLOCKER #2 (sub-finding)** — final error `Authentication required. Provide an api_key parameter to access Finlet MCP tools.` — the v1.0.0 MCP tool surface validates the bearer as a JWT and rejects api_key strings (Phase 4e api_key sunset, per `finlet/mcp/auth.py:62`), but the CLI's documented onboarding path is `finlet register` → `export FINLET_API_KEY=...` → `finlet session create`, which sends the api_key as the bearer. **The documented path is dead.**

To work around BLOCKER #2 I tried `finlet auth login`:

```
$ finlet auth login
Opening browser for Finlet OAuth login…
  If your browser does not open, visit:
    https://finlet.dev/oauth/authorize?response_type=code&client_id=finlet-cli&redirect_uri=...
```

Loaded that URL. Server response (HTTP 200, with valid web session cookie):

```json
{"error":"invalid_client","error_description":"Unknown client_id='finlet-cli'. Register the client via POST /oauth/register first."}
```

**This is BLOCKER #2 proper.** `cli.py:56` hardcodes `_OAUTH_CLIENT_ID = "finlet-cli"` per the design comment ("MVP client identity (decision record §1, §3). Hardcoded constant — the CLI ships as a public-by-default OAuth client. First-run DCR (Option B) is documented as a future improvement"). But the prod OAuth server has no `finlet-cli` static client seeded. I confirmed:
- `grep -rln "finlet-cli" finlet/auth/` returns zero hits.
- `grep -rln "finlet-cli" finlet/` returns only `finlet/cli.py` and tests.
- DCR works (`POST /oauth/register` with proper PKCE returns 201 + opaque client_id like `<redacted-client-id>`), but the CLI does not call it.

**Net effect**: with v1.0.0 deployed and the v1.0.0 CLI in the user's hand, there is **no working CLI path to authenticate against prod** — neither api_key (rejected) nor OAuth (client_id rejected).

### Stale PyPI 0.1.1 (the actual user happy path today)

```
$ pip install finlet  # installs finlet-0.1.1
$ FINLET_API_URL=https://finlet.dev finlet register --email "blind-pypi-...@finlet-test.dev"
Registration successful!
  API Key: <32-char hex string>
  Tier: free
$ export FINLET_API_KEY=<32-char hex string> FINLET_API_URL=https://finlet.dev
$ time finlet session create --name pypi-blind-walk --start 2024-01-01 --capital 100000 --universe AAPL,GOOGL,MSFT
Session created: 9cdf7dadfeb5 (pypi-blind-walk)
  Start: 2024-01-01T00:00:00Z
  Capital: $100,000.00
  Universe: AAPL, GOOGL, MSFT
finlet session create ...  0.40s total
```

**Stale 0.1.1 + prod = documented happy path works in ~0.4s.** This is the strongest evidence that tagging v1.0.0 as-is would *regress* the live experience.

### Dashboard UI fallback (web user without CLI)

I also tested the dashboard's [Create Your First Session] modal:
- Selected "Tech Growth" template (AAPL, GOOGL, MSFT, NVDA, META).
- Entered name `blind-walk-session`.
- Submitted: `POST /v1/sessions` returned **HTTP 201 in 26.9 seconds** (single request).
- Session id `0d1ec6fef2e1` ACTIVE.

**MEDIUM** — 26.9s for a UI session create is jarring. REST direct on the api_key path took 250ms. The slowness is likely a cold-path warmup specific to the cookie-auth route, but with no progress UI the user has to wait nearly half a minute.

## Phase 5 — Portfolio query

### v1.0.0 CLI

```
$ finlet portfolio --session-id 0d1ec6fef2e1
Error: No such option: --session-id Did you mean --session?
$ finlet portfolio --session 0d1ec6fef2e1
[same JSONRPC parse traceback + Authentication required as Phase 4]
```

Cannot read state back via the v1.0.0 CLI for the same auth reason. Also note the flag drift (`--session-id` was the agent-guide convention; v1.0.0 uses `--session`).

### REST direct (api_key)

```
$ curl -H "Authorization: Bearer <32-char hex string>" \
       https://finlet.dev/v1/sessions/9cdf7dadfeb5/portfolio
{"cash":98092.59,"positions":{"AAPL":{"ticker":"AAPL","quantity":10.0,"avg_entry_price":190.741,"market_value":1907.41,...}},"total_value":100000.00011,"orders_filled":1,...}
HTTP 200, 116ms.
```

### Stale 0.1.1 CLI (`finlet portfolio --session ...`)

Renders a Rich table in ~250ms. Works.

### Order submission

`finlet order --session 9cdf7dadfeb5 --ticker AAPL --side BUY --quantity 10` (via 0.1.1) returned in ~0.7s:

```
Order submitted:
  ID: b349f74b0a07
  Status: FILLED
  Fill price: $190.74
```

Portfolio re-read confirmed cash dropped to $98,092.59 with AAPL 10 shares at $190.74.

## Phase 6 — Auth flow (exercised, broken)

`finlet auth login` flow:

1. CLI opens `https://finlet.dev/oauth/authorize?response_type=code&client_id=finlet-cli&...&scope=finlet:read+finlet:trade+finlet:benchmark&resource=https://finlet.dev/mcp`.
2. With a valid web session cookie, server returns `{"error":"invalid_client","error_description":"Unknown client_id='finlet-cli'. Register the client via POST /oauth/register first."}` (HTTP 200, JSON body — not a redirect, so the CLI's loopback callback never fires).
3. Without a session cookie, `/oauth/authorize` returns HTTP 401 `Authentication required. Provide a session cookie or Authorization: Bearer <key> header.` — meaning even an authenticated *agent* (not a human in a browser) cannot complete this flow programmatically.

**No `~/.finlet/credentials` file is written** because the flow never completes the code-for-token exchange. Mode-0600 verification is moot.

For completeness, DCR works correctly:

```
$ curl -X POST https://finlet.dev/oauth/register -H 'Content-Type: application/json' \
       -d '{"client_name":"finlet-cli","redirect_uris":["http://127.0.0.1/callback"],"code_challenge_methods":["S256"]}'
{"client_id":"<redacted-client-id>","client_id_issued_at":1778446993,"client_secret_expires_at":0,"redirect_uris":["http://127.0.0.1/callback"],"grant_types":["authorization_code","refresh_token"],"response_types":["code"],"token_endpoint_auth_method":"none","code_challenge_methods":["S256"],"scope":"finlet:read","client_name":"finlet-cli"}
HTTP 201.
```

The fix is one of:
- (a) Seed a static `finlet-cli` client on the prod OAuth server (matches the cli.py:56 design comment intent).
- (b) Have the CLI perform first-run DCR and persist the issued client_id alongside `~/.finlet/credentials` (the "future improvement" the comment defers).

Either is a one-day fix.

## Findings (severity-grouped)

### BLOCKER

1. **`pip install finlet` does not install `mcp`, but v1.0.0 CLI imports `mcp.client.session` at module load — every command crashes with `ModuleNotFoundError`.** Documented install instruction is `pip install finlet`. v1.0.0 ships `mcp[auth]` only in the `server` extra. The docs do not mention extras. Fix options: (a) move `mcp` (the client-side import) into `dependencies`, (b) lazy-import inside Typer command handlers, or (c) update setup.html / agent-guide.html to require `pip install finlet[server]` and explain why. Evidence: `pyproject.toml` lines 31-37 (deps) vs 39-65 (server extra); `finlet/cli_mcp_client.py:41`. Impact: every blind-stranger user who follows the docs literally cannot run `finlet --help`.

2. **`finlet auth login` fails at `/oauth/authorize` with `invalid_client: Unknown client_id='finlet-cli'`.** CLI hardcodes the client_id (`cli.py:56`); prod OAuth server does not seed it. Combined with BLOCKER-adjacent finding #2-bis (api_key path is dead on the v1.0.0 MCP tool surface), there is **no CLI path to authenticate to prod** in v1.0.0. Evidence: `cli.py:56`, response body from `https://finlet.dev/oauth/authorize?...&client_id=finlet-cli&...`, `finlet/mcp/auth.py:62-81`, `grep -rn "finlet-cli" finlet/` returns only the CLI itself. Impact: even users who solve BLOCKER #1 (somehow installing `mcp`) cannot use any MCP-tool-routed CLI command (`session create`, `portfolio`, `status`, `order`, `advance`).

### HIGH

3. **Documentation says the wrong server URL.** Agent-guide's "Run Your First Command" section says "First, make sure the API server is running and create a session" implying a local `finlet serve`. Setup.html consistently uses `https://finlet.dev/v1/...` (correct SaaS pointer). The contradiction means a stranger reading both is told to do contradictory things. The agent-guide REST examples reference `http://localhost:8000` rather than `https://finlet.dev`. Verified via WebFetch of agent-guide.html. Fix: rewrite agent-guide to point at `https://finlet.dev` and remove the `finlet serve` instruction from the SaaS user flow (or split into two pages: SaaS user vs self-hosted).

4. **The documented happy path (`finlet register` → `export FINLET_API_KEY=...` → `finlet session create`) is dead on the v1.0.0 MCP tool surface.** Phase 4e closed the api_key bearer fallthrough on the MCP surface but the documented flow still tells users to use api_key. The CLI forwards FINLET_API_KEY as a Bearer JWT (which it isn't), JWT validation returns None, server returns "Authentication required." The user has no path to discover that `finlet auth login` is required — and `finlet auth login` doesn't work either (BLOCKER #2). Fix: either keep api_key working on the MCP surface for the CLI's forwarding path, OR update docs and prompt the user to run `auth login` after `register`. Right now, with both broken, neither remedy is in reach.

5. **CLI surfaces a 13-line pydantic traceback before the user-friendly error.** `Failed to parse JSONRPC message from server` + full traceback prints on every dispatched command before "Error: Authentication required …". The spawned MCP subprocess is emitting a structured-log line on the same stream the JSONRPC reader is parsing. Fix: route the subprocess's structured logs to stderr (or a file) so they don't pollute the JSONRPC channel. Cosmetic for v1.0.0 but degrades trust: it looks like the CLI is about to crash even when the eventual error is a clean auth message.

6. **Identity split between web signup and CLI register, with no UX bridge.** Web user `blind-walker-…@finlet-test.dev` (signed up via dashboard) and CLI user `blind-walker-cli-…@finlet-test.dev` (created via `finlet register`) are two different accounts. The dashboard's API Keys page says "Use the CLI to create an API key: `finlet register`" — but `finlet register` requires `--email` and creates a **new** account if the email differs. There is no way for the web user to mint an api_key for their existing dashboard account. Fix: either (a) add an "Issue API Key" button on /api-keys.html that mints a key tied to the logged-in user's account, or (b) support `finlet register --email <existing-email>` and have it generate a key for the existing account (with an MFA / OTP confirmation), or (c) make `finlet auth login` work and stop offering api_key as the agent-onboarding primitive.

### MEDIUM

7. **Dashboard UI session-create takes 26.9s end-to-end (POST /v1/sessions).** REST direct with api_key for the same payload is 250ms. The cookie-auth route appears to do extra work (warmup? plugin health probe? CSRF dance?). Fix: investigate; meanwhile add a progress spinner because 26.9s of "nothing happening" feels broken.

8. **Agent-guide's tip block uses literal placeholder `your_api_key_here` in two adjacent code blocks.** The first is `export FINLET_API_KEY=your_api_key_here` (fine — clear placeholder). The second is the Claude Desktop JSON config block with `"FINLET_API_KEY": "your_api_key_here"`. A user copying both and not search-replacing will end up with `FINLET_API_KEY=your_api_key_here` in their MCP config and be very confused when nothing works. Fix: callout banner that says "Replace `your_api_key_here` with your actual key from `finlet register`."

9. **/api-keys.html is read-only with no minting affordance.** "No API keys yet — Use the CLI to create an API key: `finlet register`." But (a) `finlet register` only works for *new* email addresses (creating a sibling account, not minting on the current one), (b) the CLI is broken per BLOCKER #1, (c) the user is already authenticated in the browser. The page title and breadcrumb both say "API Keys" but offer no way to manage them. Fix: add the "Generate New Key" button and a copy-to-clipboard reveal modal.

### LOW

10. **/auth.html opens with "Sign In" tab selected even when arrived from "Get Started Free" / "Create Free Account" CTAs.** Cosmetic; the user clicks the "Create Account" tab once. Fix: read URL hash or referrer to default to "Create Account" when the inbound link was a sign-up CTA.

## Notes for the launch decision

**Recommendation: HOLD. Do NOT tag v1.0.0.**

Two independent BLOCKERs (CLI-import-crash, OAuth-client_id-unregistered) make the v1.0.0 CLI unusable against prod via the documented happy path. The currently-published PyPI `finlet 0.1.1` works end-to-end (register → session create → order → portfolio) in well under 10 seconds on prod, so users following the docs *today* succeed. Tagging v1.0.0 (which would presumably trigger a PyPI publish of v1.0.0) replaces a working onboarding with a broken one.

**Minimum scope for v1.0.1 (or a v1.0.0 re-cut):**
- Move `mcp` (client portions) into `dependencies` OR lazy-import in CLI command handlers OR change the documented install to `pip install finlet[server]`. (One file change.)
- Either seed a static `finlet-cli` client on the prod OAuth server, or add first-run DCR to the CLI. (One file change either way.)
- Decide whether the documented path is api_key→REST or OAuth→MCP-stdio, then make the docs and the CLI agree. (Docs sync.)

These three fixes are a single PR; it should be possible to re-tag within 1-2 hours of consensus on the direction.

If a tag *must* go out, the safest narrow tag is to bump 0.1.1 → 1.0.0 with **only** the doc/website work that has already shipped to f679447, and *defer* publishing the v1.0.0 wheel to PyPI until the CLI fixes land in v1.0.1. That preserves the working stranger experience while letting the brand-rolled "v1.0.0 launch" announcement go forward.
