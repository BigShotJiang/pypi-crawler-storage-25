# Blind-Agent Cold-Start Report — finlet.dev

> Walkthrough date: 2026-05-10. Spawn-base SHA: `d8e13dd8364d278a1709c66dc70f10c37defcef4` (post-Phase-5 CLI MCP-over-stdio rewire).
> Coordinator: Team B (Launch v1).
> Method: clean-room agent walked finlet.dev as a stranger using only WebFetch + Bash + Read on self-created files. The agent did NOT read the finlet repo at any point.

---

## Verbatim findings — what a stranger experiences

### Step 1 — Land on finlet.dev

- **What I tried:** `curl https://finlet.dev` → opened the rendered page.
- **What I expected:** A marketing landing page with a clear value-prop, a "Sign Up" / "Get Started" CTA, and a link to docs/install.
- **What actually happened:**
  - HTTP 200, `text/html; charset=utf-8`, 29,537 bytes.
  - Page title: "Welcome to Finlet" (literally the hero text).
  - The page is a **dashboard, not a landing page**. The body is a half-loaded operations console showing real-time error states to an unauthenticated visitor:
    - `"Can't reach the Finlet server"`
    - `"The dashboard couldn't reach the API server."`
    - `"Connection Lost"`
    - `"Something went wrong"`
    - `"Finlet encountered an error loading the dashboard."`
    - `"You don't have a session yet."`
  - Visible nav: Dashboard / Leaderboard / API Keys. **No "Sign In", "Sign Up", "Docs", "Pricing", "Get Started", or "Login" link in the global nav.** Everything in the nav requires auth.
  - The only non-app text framing the product is a single "Connect your agent" link to `agent-guide.html`, buried in an empty-state message.
  - Visible CTAs (mostly disabled or error-state): Sign Out, Copy API Key, Freeze, Step, Play, Stop, Cancel, Create Session, Retry Now, Reload Page, Retry, Reload.
  - All page-level hrefs found in the HTML: `index.html`, `leaderboard.html`, `api-keys.html`, `agent-guide.html`, `/privacy`, `/terms`, `auth.css`, `favicon.svg`, `styles.css`. No `login`, `signup`, `register`, or `docs` link.
- **Time to complete:** ~10s for the page to render. ~30s of confused scrolling before I gave up looking for "Sign Up".
- **Severity:** **BLOCKER**. A stranger cannot tell what Finlet is or how to start using it. The site shows them error messages instead of a value prop.

### Step 2 — Find the signup flow

- **What I tried:** Scanned the landing page HTML for `sign[- ]?up|sign[- ]?in|register|account|login`. Then probed `/login`, `/signup`, `/register`, `/auth/login` directly.
- **What I expected:** The landing page should link to a sign-up form. If signup is CLI-only, the landing should say so loudly.
- **What actually happened:**
  - `/signup` → HTTP 404 `{"detail":"Not Found"}`
  - `/register` → HTTP 404 `{"detail":"Not Found"}`
  - `/auth/login` → HTTP 404
  - `/login` → HTTP 200 — **a fully functional sign-in page exists** with: "Continue with Google", email/password sign-in form, "Don't have an account? Create one for free" link, account-creation form with email/password, Research Network opt-in checkbox, Terms-of-Service / Privacy-Policy agreement, password recovery, 2FA flows. Page title: "Finlet — Sign In". Tagline: "Test your AI trading agent's reasoning against real market data."
  - **The `/login` page is NOT linked from the landing page anywhere.** A stranger has no way to find it without already knowing the URL or guessing.
  - The agent-guide page directs users to `finlet register` (CLI-only). The presence of a real `/login` web flow that isn't linked from the landing page is a contradiction — there are TWO signup paths, and neither is discoverable from the home page.
- **Time to complete:** Couldn't find via the UI. Discovered `/login` only by URL-guessing.
- **Severity:** **BLOCKER**. The web signup page exists but is unreachable from the landing. A stranger gives up before discovering it.

### Step 3 — Find CLI installation instructions and install

- **What I tried:**
  1. Loaded `https://finlet.dev/agent-guide.html` (the only product link from the landing page).
  2. Found `pip install finlet` documented in passing inside the requirements section.
  3. Ran `python3 -m venv blind_test_venv && source blind_test_venv/bin/activate && pip install finlet`.
- **What I expected:** A clear "Install Finlet" section at the top of the agent-guide, the latest CLI version (matching the Phase 5 CLI MCP-over-stdio shipped at `d8e13dd`), and a working `finlet --help` after install.
- **What actually happened:**
  - `pip install finlet` succeeded — installed `finlet-0.1.1` from PyPI.
  - **PyPI's latest release is 0.1.1, uploaded 2026-04-07.** Published versions: `['0.0.1', '0.1.0', '0.1.1']`.
  - `home_page: None`, `project_urls: None` on the PyPI release — no link back to finlet.dev or the docs.
  - `finlet --help` works. Installed commands: `serve`, `register`, `advance`, `order`, `portfolio`, `status`, `mcp`, `session`, `plugins`. Tagline: "Finlet — Integrated Testing Environment for AI Trading Agent Reasoning".
  - **The PyPI build is 33 days stale.** The repo's HEAD `d8e13dd` ships `auth login` / `auth logout` (Phase 4d), the renamed `mcp serve` subcommand (Phase 5), and OAuth Bearer JWT flow over stdio. The PyPI wheel has none of these. Every Phase 4 + Phase 5 feature is invisible to a stranger.
  - The agent-guide.html shows `claude_desktop_config.json` snippet with `"command": "finlet", "args": ["mcp"]` (matches PyPI wheel), but the docs in the repo's spawn-base SHA say the new entry point is `finlet mcp serve`. Whichever the new docs say, the published CLI doesn't have it.
- **Time to complete:** Install + PATH troubleshooting: ~3 minutes. Discovery of stale PyPI: ~5 minutes more.
- **Severity:** **BLOCKER**. A stranger who follows the agent-guide installs a 33-day-stale CLI that's missing the entire Phase 4 + Phase 5 surface. Whatever auth model is "current" in the docs at launch is contradicted by the wheel that `pip install finlet` actually delivers.

### Step 4 — Run OAuth login

- **What I tried:** `finlet auth login` and `finlet auth login --help`.
- **What I expected:** An OAuth login flow per the repo's `docs/decisions/cli-mcp-stdio-auth.md` (Bearer JWT via env, credentials at `~/.finlet/credentials` mode 0600).
- **What actually happened:**
  ```
  Usage: finlet [OPTIONS] COMMAND [ARGS]...
  Try 'finlet --help' for help.
  ╭─ Error ──────────────────────────────────────────────────────────────────────╮
  │ No such command 'auth'.                                                      │
  ╰──────────────────────────────────────────────────────────────────────────────╯
  ```
  - The PyPI wheel has NO `auth` subcommand at all. `finlet auth login` is impossible. A stranger cannot exercise the OAuth flow as documented in the repo.
  - Probed `https://finlet.dev/.well-known/oauth-authorization-server` → 404. `https://finlet.dev/.well-known/oauth-protected-resource` → 404. `https://finlet.dev/v1/oauth/authorize` → 404. The OAuth surface either lives at non-standard paths or isn't publicly announced.
  - The only working "register and get credentials" path is `finlet register --email <addr>`, which mints a bare-hex API key (not a JWT, not a Bearer token).
- **Time to complete:** ~30s to discover the command doesn't exist. ~5min trying alternative subcommand spellings before giving up.
- **Severity:** **BLOCKER**. The auth model documented in the repo (Bearer-via-env, OAuth login) is unreachable from a stranger's installed CLI.

### Step 5 — Create your first session

- **What I tried:**
  1. `finlet register --email blind-agent-coldstart-test@example.com` → success, returned bare-hex `API Key: c430dfd3...`.
  2. **`FINLET_API_URL=https://finlet.dev FINLET_API_KEY=<key> finlet session create --name first-session --start 2024-01-01 --capital 100000 --universe AAPL,GOOGL,MSFT`** (verbatim from agent-guide).
- **What I expected:** Session created in a few seconds.
- **What actually happened:**
  - **Crashed with a 60-line raw httpx traceback ending in `ReadTimeout: The read operation timed out`.** No retry, no friendly error envelope, no actionable hint. A stranger sees Python internals and assumes Finlet is broken.
  - Reduced universe to `AAPL` (single ticker) → session created in ~25s. Output:
    ```
    Session created: 8dde54d30d6c (first-session)
      Start: 2024-01-01T00:00:00Z
      Capital: $100,000.00
      Universe: AAPL
    ```
  - The agent-guide's verbatim example (3-ticker universe) hits a backend slow path that exceeds the CLI's default httpx timeout. The example as documented does not work as a first command for a stranger.
  - The api_key returned by `finlet register` (bare hex `c430dfd363ab9fda3c74384adff1e5ff`) does NOT match the format documented in the agent-guide (`fnlt_sk_abc123def456...`). The docs are stale relative to the running server.
- **Time to complete:** ~25s on the working path (`AAPL` only). The documented path crashed at timeout (~60s).
- **Severity:** **BLOCKER**. The verbatim "Run Your First Command" example from the agent-guide crashes with an unhandled exception. No new user makes it past this step using the docs as written.

### Step 6 — Submit your first trade

- **What I tried:** `finlet order --session 8dde54d30d6c --ticker AAPL --side BUY --quantity 10`.
- **What I expected:** A trade fills, then `finlet portfolio --session <id>` shows it.
- **What actually happened:**
  - Order succeeded: `Order submitted: ID: 246c95d2a000, Status: FILLED, Fill price: $190.74`.
  - `finlet portfolio --session 8dde54d30d6c` → **crashed with raw AttributeError traceback**:
    ```
    File "/private/tmp/blind_test_venv/.../finlet/cli.py:378 in portfolio
        pnl = pos.get("unrealized_pnl", 0.0)
    AttributeError: 'str' object has no attribute 'get'
    ```
  - The shipped CLI 0.1.1 expects positions to be a list of dicts; the production server is returning a list of strings. Schema drift between server and PyPI client. A stranger sees a stack trace and concludes their portfolio is unreadable.
  - No way to recover from the CLI. Only the (gated) `dashboard/index.html` would show the portfolio — but the dashboard's main page shows a half-loaded error state to anonymous visitors and is not the obvious place to look post-trade.
- **Time to complete:** Order submit ~3s. Portfolio command crash immediate.
- **Severity:** **BLOCKER**. The first thing a user does after a successful trade — read their portfolio — crashes the CLI.

---

## Additional friction surfaced during the walk

- **No `Sign Up` / `Get Started` / `Docs` / `Pricing` link on the landing page** — Severity: **BLOCKER**. (Restated; this is the single biggest top-of-funnel leak.)
- **`Link: <https://docs.finlet.dev/mcp>; rel="successor-version"`** is set in the API response headers but `docs.finlet.dev` is **not registered in DNS** — `dig +short docs.finlet.dev` returns nothing, `curl https://docs.finlet.dev/mcp` returns HTTP 000 (DNS/TLS error). Severity: **BLOCKER** (broken successor-version pointer = a stranger following the deprecation header lands nowhere).
- **`finlet register` CLI vs. `/login` web signup are two parallel paths with different credential shapes** — CLI returns bare-hex 32-char keys; the web signup creates an account behind a Google OAuth or email/password gate. The docs don't reconcile them, and the `/login` page isn't linked from the landing. Severity: **BLOCKER**.
- **`api-keys.html` is read-only** ("Use the CLI (`finlet register`) to create new keys.") — A user who lands on this page from the nav cannot do anything without already having a CLI install and an account. Severity: **FRICTION**.
- **agent-guide example uses a 3-ticker universe (`AAPL,GOOGL,MSFT`) that triggers a backend timeout** on the production CLI default. Severity: **BLOCKER** (it's the verbatim "first command" the docs hand a stranger and it crashes).
- **Documented api_key format (`fnlt_sk_abc123...`) does not match what the running server issues (bare hex)**. Severity: **FRICTION** (cosmetic but suggests staleness).
- **PyPI release `finlet-0.1.1` lists `home_page: None` and `project_urls: None`** — no link from PyPI back to finlet.dev or the docs. Severity: **NICE-TO-HAVE**.
- **No "Try a demo session" or "Watch the agent guide video" path** for non-coders. Finlet is positioned as a developer tool, but a stranger who isn't ready to `pip install` cannot evaluate the product. Severity: **NICE-TO-HAVE**.
- **The empty-state copy on the landing dashboard mentions `<code>finlet register</code>` and links to `agent-guide.html`** — this is the only effective sign-up CTA, and it's a code snippet inside an error message. Severity: **FRICTION**.
- **CSP `report-uri /v1/csp-report`** is configured (good) but `report-to: csp-endpoint` points at `/v1/csp-report` for a `report-to` group named `csp-endpoint` — modern browsers prefer `report-to`-based reporting; the configuration is informationally fine. Not a stranger-facing issue. Severity: **NICE-TO-HAVE**.
- **`/v1/health` returns `{"status":"ok","dashboard_available":true,"data_status":{"prices":"available"}}`** — but the dashboard at `/index.html` simultaneously shows "Can't reach the Finlet server" to anonymous visitors. The dashboard's "server is up" check disagrees with the dashboard rendering. Severity: **FRICTION** (the dashboard's offline-banner triggers on anon-not-authed, not on actual server-down — confusing copy).

---

## Triage summary

| Severity | Count |
|----------|------:|
| **BLOCKER** | **9** |
| **FRICTION** | **3** |
| **NICE-TO-HAVE** | **3** |

### BLOCKERs — must-fix-before-v1.0.0 (one-line recommendation each)

1. **Landing page shows error-state dashboard, not a value prop** — must-fix-before-v1.0.0: replace `finlet.dev/index.html` with a marketing landing for unauthenticated visitors that explains "agentic trading evaluation harness" and links to /login + agent-guide above the fold.
2. **`/login` exists but is unlinked from the landing** — must-fix-before-v1.0.0: add a "Sign In" / "Sign Up" link to the global nav (visible to anonymous visitors).
3. **PyPI `finlet 0.1.1` is 33 days stale; missing Phase 4 OAuth + Phase 5 stdio rewire** — must-fix-before-v1.0.0: cut a fresh release matching the spawn-base SHA `d8e13dd` and bump to 0.2.0 so `pip install finlet` delivers the documented surface.
4. **`finlet auth login` does not exist in the published CLI** — must-fix-before-v1.0.0: same as #3 — release the Phase 4d/4e/5 wheel; the `auth` subcommand is the documented modern auth path.
5. **`finlet session create --universe AAPL,GOOGL,MSFT` (verbatim from agent-guide) crashes with `ReadTimeout`** — must-fix-before-v1.0.0: either bump the CLI's default httpx timeout for first-session creation or warm the universe-resolution path so 3-ticker creation completes within the default window. Also add a friendly error envelope around `httpx.ReadTimeout` so the user doesn't see a raw traceback.
6. **`finlet portfolio` crashes with `AttributeError: 'str' object has no attribute 'get'`** — must-fix-before-v1.0.0: align the CLI client's expected schema with the server's actual response shape (positions as list-of-dicts), or release the fixed wheel from #3 if main is already correct.
7. **`Link: rel="successor-version"` points at `https://docs.finlet.dev/mcp` which doesn't resolve in DNS** — must-fix-before-v1.0.0: either register `docs.finlet.dev` and stand up the docs site, or drop the deprecation header until the docs URL is live.
8. **CLI `finlet register` and web `/login` are parallel signup paths with different credential shapes; docs don't reconcile them** — must-fix-before-v1.0.0: pick one canonical signup story for v1.0.0 (recommend: web `/login` is primary; CLI `register` is for headless/CI). Update agent-guide.html to link `/login` first and explain the CLI path as a secondary option.
9. **Verbatim agent-guide first-command example documents `fnlt_sk_*` key format that the server doesn't issue** — must-fix-before-v1.0.0: regenerate agent-guide.html from a script that pulls real example keys (or at minimum match the bare-hex format the server actually returns).

### FRICTIONs (post-launch acceptable, but visible)

1. **`api-keys.html` is read-only with no path forward for users without a CLI install** — Add a "Get the CLI" CTA on this page.
2. **The empty-state copy on the landing dashboard buries `finlet register` inside an error message** — Surface it more prominently as a primary CTA.
3. **`/v1/health` reports OK while the dashboard renders "Can't reach the Finlet server" to anonymous visitors** — Distinguish "server unreachable" from "you're not authenticated" in the dashboard's offline banner copy.

### NICE-TO-HAVEs (post-launch)

1. **PyPI `finlet 0.1.1` ships with `home_page: None` and no `project_urls`** — Add `homepage = "https://finlet.dev"` and `repository = "..."` to `pyproject.toml`.
2. **No demo/preview path for non-developer evaluators** — Add a hosted "watch a sample agent run" demo for prospective users not ready to `pip install`.
3. **CSP `report-to` group is configured but the modern `Reporting-Endpoints` header is absent** — Add `Reporting-Endpoints: csp-endpoint="https://finlet.dev/v1/csp-report"` for browsers that have moved past the legacy `Report-To` header.

---

*End of report — produced by the Team B blind-agent walk for launch v1.*
