# Finlet Launch Templates — 2026-05-15

> Drafts. User edits before posting. DO NOT post automatically — every channel is manual.

---

## Tone calibration (from research)

Studied 6 recent Show HN posts in the agent-eval / dev-tool / harness space (Oct 2025 – Mar 2026). Three lessons fell out:

- **Lesson 1 — Name the wedge in the first sentence.** Posts that opened with "We built an X that does Y because Z annoyed us" (Dbt-LLM-evals, Gambit) outperformed posts that opened with feature lists. HN readers will close the tab in two seconds if the wedge is buried. Lead with the eval angle, not the data-source list.
- **Lesson 2 — Acknowledge what you're NOT before commenters do it for you.** The high-engagement posts (Gambit at 91 points / 27 comments; jj-benchmark) explicitly said "this is not X" early, which redirected the comment thread from "why isn't this just X" to actual feedback. For Finlet that means: pre-empt "this is just a backtester" and "this is just paper trading" in the post body.
- **Lesson 3 — The author's first comment is the second pitch.** All four posts I could read had an author comment within the first hour, framing scope, conceding limitations, and asking a specific question. Show-HN guidelines confirm: be present, be a contributor, not a marketer. Skip "thanks for the upvotes" — say something useful.

**Examples studied:**
- `Show HN: Gambit, an open-source agent harness for building reliable AI agents` — https://news.ycombinator.com/item?id=46641362 (91 pts / 27 cmts). Won on clear wedge ("inverts the pattern: LLM decides, harness obeys") + concession ("we built this after struggling with quality in our video editor").
- `Show HN: jj-benchmark — Evaluating AI agents on Jujutsu version control` — https://news.ycombinator.com/item?id=47352189. Won on concrete numbers in description ("63 tasks, Claude 4.6 Sonnet 92%, GPT-5.4 leading on speed"). Specificity beat hand-waving.
- `Show HN: Dbt-LLM-evals — Monitor LLM quality in your data warehouse` — https://news.ycombinator.com/item?id=46694397. Won on "the existing approach feels backwards because…" framing.
- `Show HN: Relai-SDK — simulate → evaluate → optimize AI agents` — https://news.ycombinator.com/item?id=45723102. Tight three-verb framing in the title — worth borrowing the cadence.
- `Show HN: Continuous-eval — Granular evaluation of GenAI pipelines` — https://news.ycombinator.com/item?id=39503469. Older but proved the eval-tooling crowd shows up if you frame it as eval.
- `Show HN: AvaKill — Deterministic safety firewall for AI agents` — https://news.ycombinator.com/item?id=47297025. Cautionary: posts that lead with "deterministic" / "guaranteed" without explanation get torn apart in the comments.

**Show HN rules** (https://news.ycombinator.com/showhn.html): something readers can run. No signup wall to try it. Be present in the comments. Marketing voice gets downvoted. "Project needn't be polished" — early-stage is fine, hype is not.

**Net direction chosen for Finlet:** earnest builder voice, wedge in the first sentence (date-ceiling enforcer = agent can't cheat on time), explicit "not a backtester / not a paper trader" disclaimer, concrete numbers (36 MCP tools as of 2026-05-23 — confirm with `grep -REn '@mcp\.tool\(\)' finlet/mcp/ | wc -l` before posting; $0/$29; EOD US equities long-only), invite skepticism.

---

## 1. Hacker News — Show HN

### Variant A (primary) — earnest builder, wedge-first

**Title:** Show HN: Finlet — an evaluation harness for trading agents

**Alt title:** Show HN: Finlet — your AI trading agent can't cheat on time

**Description:**

Finlet tests whether an AI agent reasons well about markets when it can only see what was actually knowable on a given date. The agent makes plugin calls — prices, SEC filings, news, fundamentals — and a date-ceiling enforcer strips every response of any data timestamped after the simulation clock. No future leak, no perfect-hindsight oracle.

It's not a backtester. Backtesters score algorithms against historical data. Finlet scores reasoning given the information a human analyst would have had on that date. It's also not paper trading — no real orders, no live broker connection. It's the gym, not the race.

Daily timeframe, US equities, long-only at v1 (deliberately scoped). Connect Claude Code via MCP, or any non-MCP agent via REST. Free tier runs end-to-end with no card. Live demo session: https://finlet.dev/sessions/{CURATED_SESSION_ID}

**First comment (author):**

Hi, builder here. Short context: I kept seeing "we backtested our agent on 2023 data and it returned 47%" posts where the agent had quietly seen the future via training data, prompt leakage, or an unbounded news API. So I built the harness I wanted — one that physically can't hand the agent anything past the sim clock, even by accident.

The wedge is the date-ceiling enforcer: every plugin response runs through a defense-in-depth strip on the way out. Items with timestamps past `clock.now` are dropped; items with no timestamp are dropped by default (the conservative direction). The strip count is never returned to the agent — telling it "I dropped 3 items" leaks future information.

What's intentionally NOT in scope at v1: intraday, options, shorting, multi-asset, partial fills. EOD data doesn't support order-book depth, so I refuse to fake it. Add those when daily-long-US is solid.

Easiest path to try it: `pip install finlet`, `finlet auth login`, and wire `finlet mcp serve` into your agent host (Claude Desktop, Codex CLI, Cursor — JSON snippet at finlet.dev/setup), then ask the agent: "Create a session named 'my-first-sim' starting 2024-01-02 with $100,000 capital and tickers AAPL, MSFT, GOOGL. Then place a market BUY order for 10 shares of AAPL and show me the portfolio." Free tier is 1 concurrent session with unlimited tickers per session — enough to feel whether the enforcer changes how your agent behaves. Paid Builder tier is $29/mo for more concurrency.

I'd especially like feedback on: (a) is the eval-vs-backtester framing actually landing, or does the audience hear "backtester" anyway, and (b) what scenarios should ship at v1 — I have 5 baseline ones and they all probably need to be harder.

### Variant B (alt) — punchier, wedge-first, more provocative

**Title:** Show HN: Finlet — agent backtests where the agent can't see the future

**Alt title:** Show HN: Finlet — a trading-agent eval harness with no look-ahead

**Description:**

Most "AI trading agent" demos quietly leak future information — through training-cutoff dates, unbounded news APIs, or fundamentals endpoints that return the latest snapshot regardless of `as_of`. Finlet is an eval harness that physically can't.

You give an agent a simulation clock and a tool surface (prices, SEC filings, news, fundamentals, economic data). It makes calls. A date-ceiling enforcer strips every response of items past the clock. The agent gets only what it asked for, and only what was knowable on that date. Then you score it: returns, Sharpe, drawdown, reasoning quality, information efficiency.

Daily timeframe, US equities, long-only at v1 — by design, not by gap. Demo: https://finlet.dev/sessions/{CURATED_SESSION_ID}. Free tier, no card.

**First comment (author):**

Hi, builder here. This will read as a backtester to half the audience and as paper trading to the other half — both framings will miss the point, so let me pre-empt.

It's not a backtester. Backtesters take a strategy (a function) and run it over a price series. Finlet takes an agent (an LLM with tool access) and asks: given the same plugin calls available to a human analyst on that date, did it reason well? The score includes information efficiency — returns per API call — because an agent that buys NVDA on 2023-01-03 after reading 400 filings should not score the same as one that bought it after reading two.

It's also not paper trading. No live broker. No real money. Ever. The point is evaluation, not execution.

The defense-in-depth piece I'm proudest of: items with no timestamp are dropped by default. Most backtesting frameworks include them ("better to have data than not"), which is the bug. If you can't prove an item existed before the clock, the safe default is to exclude it. Property-based tests cover the enforcer; the trace is SHA-256-checksummed so cheating is detectable post-hoc.

Try it: `pip install finlet`, then either `finlet mcp serve` from a Claude Desktop / Cursor / Windsurf config, or REST API directly. Free tier covers a full eval session.

Specific questions I'd value feedback on: (a) what's the right v1 scenario set — currently 5, probably needs to be 15, (b) is the "no timestamp = drop" default too aggressive for filings (filing-availability vs filing-effective-date is a known gotcha), (c) what eval signals am I missing from the composite score.

---

## 2. X / Twitter — 4-tweet thread

### Variant A — wedge-first, audience: agent-builder Twitter

**Tweet 1 (hook, 268 chars):**

I built Finlet — an evaluation harness for AI trading agents.

Not a backtester. Not paper trading.

It tests whether your agent reasons well about markets when it can only see what was actually knowable on a given date.

Live: finlet.dev

**Tweet 2 (the wedge, 265 chars):**

The unfair advantage of most "trading AI" demos is leak. Future news scraped from an unbounded API. Fundamentals snapshots from "now." A model whose training cutoff is after the simulated date.

Finlet's date-ceiling enforcer strips every plugin response. The agent can't cheat.

**Tweet 3 (show don't tell, 248 chars):**

Here's a live public session — an agent driving a portfolio against historical data, with full reasoning trace + plugin calls:

finlet.dev/sessions/{CURATED_SESSION_ID}

Click through the orders. Read what it saw and when. That's the eval.

**Tweet 4 (CTA + pricing, 259 chars):**

Free tier runs end-to-end, no card, 1 concurrent session, unlimited tickers per session.

Builder tier is $29/mo for more concurrency.

`pip install finlet` and wire `finlet mcp serve` into Claude Desktop / Cursor / Windsurf — or hit the REST API directly.

Skeptical takes welcome. finlet.dev

### Variant B — quant-twitter pre-empt, expect hostility, lean into it

**Tweet 1 (hook, 269 chars):**

If you tried to backtest an AI trading agent in the last 18 months, you probably leaked the future to it without knowing.

Training cutoffs, unbounded news APIs, fundamentals endpoints that always return latest.

I built Finlet to fix this. It's an eval harness, not a backtester.

**Tweet 2 (concede + redirect, 256 chars):**

Quant Twitter will (correctly) point out that real PMs don't trade EOD, US equities, long-only. Finlet doesn't either.

It's an evaluation surface for agents — the gym, not the race. The constraints exist so the eval signal is clean. Daily data can't fake order-book depth.

**Tweet 3 (show don't tell, 258 chars):**

The wedge is the date-ceiling enforcer: every plugin response is stripped of items past the sim clock. Items with no timestamp are dropped by default.

Reasoning trace is SHA-256-checksummed. Cheating is detectable post-hoc.

Live: finlet.dev/sessions/{CURATED_SESSION_ID}

**Tweet 4 (CTA, 251 chars):**

Free tier, no card. `pip install finlet`. MCP server for Claude / Cursor / Windsurf, REST API for everything else.

Paid Builder tier is $29/mo.

Closed source. Looking for early users who'll be honest about what's broken.

finlet.dev

---

## 3. Product Hunt

### Variant A — earnest builder

**Tagline (58 chars):** An evaluation harness for AI trading agents

**Short description (138 chars):** Test your trading agent's reasoning — not its hindsight. Date-ceiling enforcer strips future data from every plugin call.

**Long description (~300 words):**

Most "AI trading agent" demos secretly leak the future. The training data cutoff is after the simulated trade date. The news API returns articles by publication date, but the publication date is "now" for archived items. The fundamentals endpoint returns the latest snapshot regardless of `as_of`. The agent looks brilliant because the eval is broken.

Finlet is the eval harness I wanted: one where the agent physically cannot see past the simulation clock.

You give the agent a clock and a tool surface. It calls `get_price_data`, `search_news`, `get_filings`, `get_fundamentals`, `get_economic_data`, `submit_order`. Every response runs through a date-ceiling enforcer: items with timestamps past `clock.now` are stripped, items with no timestamp are dropped by default. The strip count is never returned to the agent (that would itself leak future information).

Daily timeframe, US equities, long-only at v1. Those are design choices, not gaps. Intraday adds order-book depth that EOD data can't support honestly. Shorting and options layer mechanics on top of reasoning, which is what we're trying to isolate.

Connect Claude Code, Cursor, or Windsurf as a trading agent via MCP — 36 purpose-built tools, OAuth 2.1 with PKCE Bearer auth. Or drive it from the REST API in any language.

The leaderboard scores agents across five scenarios on returns, Sharpe, drawdown, reasoning quality, and information efficiency (returns per API call — an agent that buys NVDA after two filings should not score the same as one that buys it after four hundred).

Free tier runs end-to-end, no credit card. Builder tier is $29/mo for more concurrent sessions and higher rate limits. Larger tiers post-launch.

Closed source. Built by a solo founder. Try a live session at finlet.dev/sessions/{CURATED_SESSION_ID}.

**Seed comments (post these from the maker account on launch day):**

1. *(Hour 1, scope concession)* — "Worth saying out loud: v1 is deliberately narrow. Daily EOD, US equities, long-only. Intraday and options matter, but they layer mechanics on top of the reasoning signal — which is what the eval is trying to isolate. The roadmap expands the scope only once the date-ceiling primitive holds up under load. Curious what scenarios people would want first."

2. *(Hour 3, technical depth invite)* — "For folks asking how the date-ceiling enforcer actually works: it's a runtime middleware between every plugin response and the agent. Items with `timestamp > clock.now` are dropped. Items with no timestamp are dropped by default (the conservative direction — if you can't prove an item existed pre-clock, you don't include it). Property-based tests with Hypothesis cover the strip logic. The trace is SHA-256-checksummed end-to-end so any post-hoc cheating is detectable. Happy to go deeper if useful."

3. *(Hour 6, honest gap)* — "Things I know I'll get asked about and want to be upfront on: (a) data coverage is currently US-only, (b) the leaderboard scenarios are 5 deep and need to be 15+, (c) no shorting/options yet, (d) the reasoning-quality score uses an LLM judge which has its own bias problem. None of these are launch blockers but all are real. Email is on the site if you want to talk through any of them."

### Variant B — punchier, wedge-first

**Tagline (54 chars):** Your trading agent can't cheat on time

**Short description (132 chars):** AI trading agents leak the future. Finlet's date-ceiling enforcer strips it back out. Eval harness, not a backtester.

**Long description (~290 words):**

Backtests are broken for AI agents.

Not because the math is wrong — because the agent quietly sees the future. Training cutoffs land after the trade date. News APIs return articles by publication date with `publication_date = now`. Fundamentals endpoints always return latest. The agent's "alpha" is actually the leak.

Finlet is an eval harness designed around that problem. You hand the agent a simulation clock and a tool surface. It calls plugins. A date-ceiling enforcer strips every response of items past the clock. No future news. No future filings. No "today's" fundamentals dressed as "January 2024." The agent gets only what was knowable on that date — and only what it explicitly asked for.

This is not a backtester. Backtesters test algorithms; Finlet tests reasoning. The score includes information efficiency (returns per API call) because an agent that earns 12% after two filings should not score the same as one that earns 12% after four hundred.

This is not paper trading either. No live broker. No real money. Ever. The eval is the product.

What you do with it: connect Claude Code, Cursor, or Windsurf via MCP. Or drive the REST API from any language. Daily EOD, US equities, long-only at v1 — by design, not by gap. The reasoning trace is SHA-256-checksummed, so cheating is detectable post-hoc.

Pricing: free tier runs end-to-end, no card. Builder is $29/mo for more concurrency and higher rate limits.

Closed source. Solo founder. Try a live public session at finlet.dev/sessions/{CURATED_SESSION_ID} — click through the orders and watch what the agent saw before each decision.

**Seed comments:**

1. *(Hour 1, the wedge restated)* — "If you take one thing from this: the agent can't cheat on time. Everything else is downstream of that. The whole eval design exists to make information access auditable. Open to skeptical questions about edge cases — there are real ones around filing-availability vs filing-effective dates."

2. *(Hour 4, scope honesty)* — "v1 deliberately ships narrow. Daily, US, long-only. I'd rather have a tight, honest eval signal than a wide, leaky one. Intraday and options are on the post-launch roadmap once daily holds up."

3. *(Hour 8, invite specifics)* — "What I'd love from the PH crowd: (a) scenario suggestions — 5 baseline ones today, need 15+, (b) which agent frameworks I should support natively beyond MCP, (c) what's missing from the scorecard. Reply or email — both eyes on this thread."

---

## 4. Community posts

> Each one is shorter and tone-tuned for the channel. Variant A only — Variant B not needed for community posts, but feel free to ask if you want one.

### Anthropic Builder Discord

> Channel norm: technical, MCP-aware, Claude-positive. Lead with MCP, eval rigor, and the fact that Claude is the target agent. Don't oversell.

```
Hey — shipping Finlet today (https://finlet.dev). It's an evaluation harness for trading agents, MCP-first. Add it to your Claude Desktop config and Claude becomes the trading agent — 36 MCP tools (get_price_data, search_news, get_filings, get_fundamentals, submit_order, advance_time, etc.) over stdio, OAuth 2.1 + PKCE for auth.

The eval wedge: a date-ceiling enforcer strips every plugin response of items past the simulation clock. Items with no timestamp are dropped by default. So when Claude calls get_filings for 2023-01-03, it physically cannot see the 8-K filed on 2023-01-04 — even if the data source has it. The reasoning trace is SHA-256-checksummed, so cheating is detectable post-hoc.

Daily, US equities, long-only at v1 — by design. Free tier runs end-to-end. Builder tier $29/mo.

Live demo session: finlet.dev/sessions/{CURATED_SESSION_ID}. Install with `pip install finlet`; MCP config is in the README.

Would love feedback specifically on the MCP surface — tool granularity, error envelopes, scope design. Closed source, solo founder, in the channel for the rest of the day.
```

### OpenAI Dev Forum

> Channel norm: framework-agnostic, eval-focused, slightly more formal. Tool-use angle. No Claude-specific phrasing.

```
**Show: Finlet — an evaluation harness for trading agents (eval-first, not a backtester)**

Posting in case it's useful to anyone here building tool-using agents.

Finlet evaluates whether an agent reasons well about markets when its information access is bounded by a simulation clock. The agent makes tool calls — prices, SEC filings, news, fundamentals, economic data. A date-ceiling enforcer strips every response of items past the clock. Items with no timestamp are dropped by default (the conservative direction). The agent's strip count is never returned, because revealing that information leaks the existence of future data.

It's not a backtester. Backtesters score strategies against historical price series. Finlet scores reasoning given the same plugin calls a human analyst would have on that date. The score is composite: returns, Sharpe, max drawdown, reasoning quality (LLM judge), and information efficiency (returns per API call).

v1 is scoped narrow: daily EOD, US equities, long-only. Those are design choices to keep the eval signal clean — daily data can't honestly support order-book mechanics, so we don't fake them.

Works with any HTTP-capable agent — REST, CLI, or MCP. Free tier runs end-to-end without a card. Live public demo: finlet.dev/sessions/{CURATED_SESSION_ID}.

Specifically interested in feedback on (a) tool-use eval design — are there axes the score is missing, (b) whether function-calling-only agents (no MCP) hit any friction.
```

### r/LocalLLaMA

> Channel norm: BYO-model, skeptical of API gatekeeping, hostile to closed-source pitches. Lead with "use any model you want." Concede closed-source up front so it's not the surprise that tanks the thread.

```
**Finlet — an evaluation harness for trading agents (BYO model, any HTTP-capable agent)**

Shipped today. Posting here because the eval interface is open enough to use with any local model you want — Finlet evaluates the agent, not the model. You write the agent shell (whatever framework, whatever inference backend), point it at Finlet's REST or MCP surface, and it runs.

The eval wedge is a date-ceiling enforcer: every plugin response (prices, SEC filings, news, fundamentals) is stripped of items past the simulation clock. Items with no timestamp are dropped by default. So your local model can't accidentally see the future via a leaky data source. The reasoning trace is SHA-256-checksummed end-to-end.

Daily, US equities, long-only at v1 — by design.

Up-front honesty: Finlet itself is closed source. The interface is open in the "use any model, any framework" sense, but the harness implementation is not on GitHub. Free tier runs end-to-end without a card; Builder tier is $29/mo. If that's a dealbreaker, totally fair — wanted to be upfront.

Demo: finlet.dev/sessions/{CURATED_SESSION_ID}. CLI: `pip install finlet`.

Curious whether the eval signal lines up with what you've seen evaluating local models on quant tasks.
```

### r/AlgoTrading

> Channel norm: hostile to "AI trading" pitches, will assume you don't know what a backtest is, will assume look-ahead until proven otherwise. Open with concession, not pitch.

```
**Not a backtester, not paper trading — an eval harness for AI trading agents**

Posting fully expecting pushback, and reading carefully. Pre-empt up front: this is not a competitor to QuantConnect, Backtrader, Zipline, or VectorBT. As a backtester it would lose on every metric — data coverage, asset classes, speed. As an eval harness for AI agents it's solving a different problem.

The problem: when you point an LLM-backed agent at a backtest, the agent often sees the future. Training data cutoffs land after the simulated date. News APIs return articles ordered by publication date but with publication-date metadata reset to "now" for archived items. Fundamentals endpoints return the latest snapshot regardless of `as_of`. The "alpha" is the leak.

Finlet is a sandbox that fixes this with a runtime date-ceiling enforcer. Every plugin response — prices, SEC filings, news, fundamentals, economic data — runs through a middleware that drops items with `timestamp > clock.now`. Items with no timestamp are dropped by default (conservative direction). The strip count is never returned to the agent, since telling it "I dropped N items" leaks future information.

v1 is scoped narrow on purpose: daily EOD, US equities, long-only. Daily data can't honestly support order-book depth or fill modeling, so we don't fake them. Intraday and shorting are on the post-launch roadmap.

Not for live trading. Not for human discretionary backtesting. It is specifically for evaluating whether an LLM-backed agent reasons well under information constraints. If that's not the problem you have, your existing backtest framework is fine.

Live demo: finlet.dev/sessions/{CURATED_SESSION_ID}. Free tier, no card.

If you do try it, the most useful feedback is "your enforcer leaked the future via X" — that's the load-bearing piece.
```

### LangChain Discord

> Channel norm: framework-aware, agent-eval-curious, more comfortable with abstraction. Position Finlet as the eval layer, not the agent.

```
**Finlet — an eval layer for trading agents (LangChain-compatible via REST/MCP)**

Just shipped. Sharing here because the obvious integration point is "LangChain agent → Finlet REST or MCP → eval scorecard."

Finlet doesn't ship an agent. It ships the eval surface: a simulation clock, a plugin layer (prices / SEC filings / news / fundamentals / economic data), and a date-ceiling enforcer that strips every plugin response of items past the clock. Bring your own agent — LangChain, LangGraph, AutoGen, raw function calling — and Finlet scores it on returns, Sharpe, drawdown, reasoning quality, and information efficiency (returns per API call).

Why a separate eval layer: the failure mode in agent-trading demos isn't strategy quality, it's information leak. A backtest where the agent sees the future scores great and means nothing. Finlet's enforcer is the part you can't easily bolt onto an existing eval — it has to be in the request path.

Daily, US equities, long-only at v1 — design choice, not gap.

Demo: finlet.dev/sessions/{CURATED_SESSION_ID}. Free tier, no card. CLI: `pip install finlet`.

If you have a LangChain agent you want to throw at it, I'd love to see what breaks. The REST interface is in the README.
```

---

## Pre-launch checklist (for user)

- [ ] Fill in `{CURATED_SESSION_ID}` everywhere. Today's session id is hardcoded as `4a2f92c0438f` in `dashboard/landing.html:239` — confirm it's still the right curated session (and that it's marked `public_anonymous`) before posting. The env-var name `FINLET_CURATED_PUBLIC_SESSION_ID` from the brief did not surface anywhere in the repo as of this draft; the value lives in the landing-page template, not in config.
- [ ] Verify `https://finlet.dev/v1/health` returns 200/ok.
- [ ] Confirm the curated demo session loads anonymously (incognito tab on `/sessions/4a2f92c0438f`).
- [ ] Stripe Dashboard pinned to the "Subscriptions" tab in live mode.
- [ ] Tail logs: `journalctl -u finlet -f | grep -iE "ERROR|500|webhook_signature_failed"`.
- [ ] Post HN at 08:00 ET (max US + EU overlap window).
- [ ] Post X thread within 30 min of HN going live. Drop the HN link in tweet 4 as a reply, not in the main thread (HN ranking penalises self-promotion bumps).
- [ ] Drop community posts (Anthropic / OpenAI / LangChain Discords, r/LocalLLaMA, r/AlgoTrading) within 2 hours of HN, NOT before — reddit + discord moderators will see HN front-page traction and that buys goodwill.
- [ ] Schedule Product Hunt for Tuesday or Wednesday next week. Skip PH if rushing — PH launches go badly when under-prepped and the failure is loud.
- [ ] Hold an empty browser tab pinned at `news.ycombinator.com/show` so you can grab the HN URL the second it's posted and paste into X tweet 4.
- [ ] Confirm `support@finlet.dev` is being checked every 30 min for the first 6 hours.
- [ ] Have a "things that will break under load" tab open: API rate limits per plugin, Stripe webhook signature failures, OAuth client_id seeding.
