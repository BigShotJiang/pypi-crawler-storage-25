# v1.0.3 — Docs Patch + Rotation Diagnostic — Session Summary

**Date:** 2026-05-11
**Predecessor chain:** v1.0.0 (held) → v1.0.1 (hotfix) → v1.0.2 (hotfix) → **v1.0.3 (this session)**
**Status:** Chain closed.

---

## What shipped

| Artifact | PR | Merge SHA | Surface |
|----------|-----|-----------|---------|
| Generic MCP Client config fix | [#58](https://github.com/justnau1020/finlet/pull/58) | `3994ac9` | `dashboard/agent-guide.html` lines 185/198 (`["mcp"]` → `["mcp", "serve"]`), CHANGELOG `[1.0.3]` |
| API key rotation diagnostic | [#59](https://github.com/justnau1020/finlet/pull/59) | `ce0ae9d` | `docs/REMAINING_TASKS.md` — "Post-launch — Credential hygiene" section |

No Python version bump. PyPI stays at `1.0.2`. Dashboard fix deployed via `Deploy Finlet` workflow on push to main; prod verified live (`curl -s https://finlet.dev/agent-guide.html | grep -c '"args": \["mcp", "serve"\]'` = 4, broken pattern = 0).

---

## Why this session existed

The v1.0.2 hotfix corrected the Claude Desktop MCP config block but **missed the Generic MCP Client block** (used by Cursor / Cline / Continue). Bare `finlet mcp` prints help and exits 0 — those clients would see "MCP server crashed immediately." This patch closes that gap.

A separate launch-tail concern: a real `fnlt_*` API key was committed to the v1.0.0 cold-start launch artifact as a curl example. CI is green (fingerprint is `.gitleaksignore`-allowlisted), but the key is still active on prod and represents a real credential leak.

---

## Notable findings (caught in flight)

Three corrections to the handoff's diagnostic template, surfaced while preparing the rotation entry — preserved here so the user doesn't need to rediscover them at revoke time:

1. **Leaked key has 4 hits in the doc, not 1.** `docs/launch/blind-agent-coldstart-report-v1.0.0-fullwalk.md` references `fnlt_defe75cb…` at lines 113, 116, 124, 170. The handoff only flagged line 124.
2. **Schema is `key_hash`, not `key_prefix`.** Keys are SHA256-hashed at rest. Hash for the leaked key: `7f73323f818d990dc2199efed4f44cb89e6d913c8b9fec95b6e4d3da412ea0dd`.
3. **Table is `named_api_keys`, not `api_keys`.** The leaked key was minted via the Settings UI ("named keys" flow), not the legacy `api_keys` table.

These three corrections are already baked into the one-line revoke command in `docs/REMAINING_TASKS.md`.

**Owner of the leaked key (read-only SELECT via AWS SSM SendCommand):**
- `id`: `0db802c0a2b2`
- `user_id`: `eda329c02a5b`
- `name`: `blind-walk-fullwalk`
- `email`: `blindwalk-fullwalk-2026-05-11@finlet-test.dev` (free tier)
- `last_used_at`: NULL — never used in production traffic
- `revoked_at`: NULL — still active

This is a test account, not the user's prod credential. Revocation is safe; no re-issuance needed.

---

## Process notes

- **SSH to prod is blocked on port 22** (Cloudflare-proxied). Rotation diagnostic used `aws ssm send-command --region us-east-1 --instance-ids i-0363a2afc714dccf9 …` for read-only queries. Same path applies for the revoke `UPDATE`.
- **Worktree-isolated subagents have no `.venv`.** Both agents symlinked `/Users/justnau/finlet/.venv` (untracked) so the pre-push hook's path-aware logic could skip mypy/pytest/e2e on docs-only PRs. Ruff still ran clean. Considered a worktree-template fix but deferred — not blocking.
- **PR #59 needed `gh pr update-branch`** after #58 merged (BEHIND main). CI re-ran (~5 min). Auto-merge is not enabled on the repo; orchestrator manual-merged after green.

---

## Outstanding (user-gated, not blocking launch)

| Item | State | Action |
|------|-------|--------|
| Revoke leaked key `fnlt_defe75cb…` | Diagnostic landed; key still active on prod | One-line `aws ssm send-command …` in `docs/REMAINING_TASKS.md` — run when awake |
| Pre-commit hook scanning launch artifacts for `fnlt_[a-f0-9]{32}` | Suggested in diagnostic; not built | Optional future-proof; not blocking |
| Worktree-template `.venv` symlink | Workaround applied per-spawn; not codified | Deferred — small papercut, not user-facing |

---

## Chain closure

The v1.0.0 → v1.0.3 launch chain is closed. PyPI artifact at `1.0.2` is the live Python release; dashboard at `3994ac9`+ is the live web surface. No additional v1.0.x patches planned.
