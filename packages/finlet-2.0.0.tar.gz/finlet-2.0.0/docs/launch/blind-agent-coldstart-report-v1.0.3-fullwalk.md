# Blind Agent Cold-Start Report — v1.0.3 Full Walk

**Walker:** clean-context general-purpose subagent (worktree isolation)
**Tag under test:** PyPI finlet==1.0.2 + dashboard surface at main HEAD fb5ea88
**Walk timestamp:** 2026-05-12T04:12-04:18Z
**Evidence dir:** /tmp/v1-0-3-walk-evidence-20260511-231230/
**Test account:** blindwalk-1-0-3-clean-1778559185@finlet-test.dev
**Test key (in-report):** fnlt_***MASKED***
**Venv:** /tmp/v1-0-3-walk-venv-1778559216/ (Python 3.12.13)

## TL;DR

**Severity counts:** BLOCKERs: 0, HIGHs: 1, MEDIUMs: 2, LOWs: 3

**Launch verdict:** NEEDS-PATCH

The v1.0.2 happy path is clean: pip install resolves to 1.0.2 with mcp 1.27.1 bundled; REST signup mints a working api_key; `finlet session create` → `session list` → `portfolio` → `order` → `portfolio` all complete without traceback storms (v1.0.2 traceback wrap is holding). However, **agent-guide.html publishes an auth path that the server rejects**: the doc claims MCP accepts `Authorization: Bearer fnlt_<api_key>`, but the HTTP MCP server explicitly responds "api_key authentication is no longer supported on MCP tools" when you try. Any third-party AI agent that reads the agent-guide and constructs a Bearer-with-api_key request will fail with no diagnostic indication of why the docs lied. That single contradiction is the launch gate. Everything else — `finlet --version` missing, CLI exit code 0 on auth errors, `/dashboard/` 404 vs `/dashboard` 200 — is polish.

## Findings

### F-1 — Agent-guide.html publishes a Bearer auth path the MCP server rejects — HIGH
**Phase:** 5 (MCP HTTP probe)
**Repro:**
```
# Per agent-guide.html: "MCP accepts BOTH Authorization: Bearer <oauth_jwt> AND Authorization: Bearer fnlt_<api_key>"
# Step 1: init session
curl -sS -i -X POST https://finlet.dev/mcp/ -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","method":"initialize","id":1,"params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"x","version":"1"}}}'
# capture mcp-session-id from response header

# Step 2: call a tool with fnlt_<api_key> Bearer
curl -sS -i -X POST https://finlet.dev/mcp/ -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -H "Authorization: Bearer fnlt_***MASKED***" \
  -H "Mcp-Session-Id: <captured>" \
  -d '{"jsonrpc":"2.0","method":"tools/call","id":4,"params":{"name":"list_sessions","arguments":{}}}'
```
**Expected:** per agent-guide.html line 60-62 ("MCP accepts BOTH `Authorization: Bearer <oauth_jwt>` AND `Authorization: Bearer fnlt_<api_key>`. Pick whichever fits your client."), a 200 with the session list.
**Observed:** 200 envelope with body `{"error":"Authentication required. Provide an api_key parameter to access Finlet MCP tools."}`. Tested three variants (Bearer bare-hex, Bearer fnlt_-prefixed, api_key as tool argument); only the api_key-as-argument variant produced a different (also-failing) error: `{"error":"api_key authentication is no longer supported on MCP tools. Run 'finlet auth login' to obtain an OAuth Bearer token. See docs/MCP_OAUTH_MIGRATION.md."}`. This matches the project memory note that Phase 4e shipped Bearer-only (OAuth JWT) enforcement on the MCP tool surface and that the 90-day dual-accept window was retracted pre-launch.
**Evidence:**
- /tmp/v1-0-3-walk-evidence-20260511-231230/35-tool-call-noauth.txt (no auth)
- /tmp/v1-0-3-walk-evidence-20260511-231230/36-tool-call-bare.txt (Bearer bare-hex)
- /tmp/v1-0-3-walk-evidence-20260511-231230/37-tool-call-apikey-arg.txt (api_key argument — server-side deprecation message)
- /tmp/v1-0-3-walk-evidence-20260511-231230/38-tool-call-prefix.txt (Bearer fnlt_-prefixed)
- /tmp/v1-0-3-walk-evidence-20260511-231230/03-agent-guide.txt (the stale published claim, near line 60)
**Recommended fix:** rewrite the "Auth path" tip in agent-guide.html to say "MCP only accepts `Authorization: Bearer <oauth_jwt>` (from `finlet auth login`). For api_key clients use the REST API at `https://finlet.dev/v1/...` or the bundled `finlet mcp serve` stdio bridge (which translates `FINLET_API_KEY` internally)." Same correction applies anywhere in setup.html that describes MCP-over-HTTP with an api_key.

### F-2 — `finlet --version` not implemented — MEDIUM
**Phase:** 3 (CLI install)
**Repro:** `finlet --version`
**Expected:** exit 0, print `1.0.2`.
**Observed:** exit 2 with "Error: No such option: --version" (Typer default). Workaround: `python -c "import importlib.metadata as m; print(m.version('finlet'))"`.
**Evidence:** /tmp/v1-0-3-walk-evidence-20260511-231230/41-finlet-version.txt
**Recommended fix:** add a `--version` callback to the Typer root app in `finlet/cli.py` that reads `importlib.metadata.version("finlet")` and exits 0. Standard Typer pattern: `typer.Option(None, "--version", callback=version_callback, is_eager=True)`.

### F-3 — CLI exits 0 on MCP auth errors (no FINLET_API_KEY, no creds) — MEDIUM
**Phase:** 4 (CLI help) / 6 (CLI MCP dispatch)
**Repro:** `env -i PATH=... finlet session list` (no FINLET_API_KEY, no ~/.finlet/credentials).
**Expected:** exit non-zero (1 or 2), and print a friendly hint pointing at `finlet auth login` or `export FINLET_API_KEY=...`, matching the friendlier `auth status` message ("Not logged in. Run `finlet auth login`.").
**Observed:** prints `Error: Authentication required. Provide an api_key parameter to access Finlet MCP tools.` and exits 0. The error text is the raw MCP envelope, not a CLI-localized hint; users invoking the CLI from a shell script will not detect failure via `$?`.
**Evidence:** /tmp/v1-0-3-walk-evidence-20260511-231230/68-cli-no-auth.txt
**Recommended fix:** in the CLI's MCP dispatch wrapper (likely `finlet/cli.py`'s `_invoke_mcp_tool` helper or whatever wraps stdio call results), detect `"Authentication required"` and `"api_key authentication is no longer supported"` in the envelope, surface a localized message ("Not authenticated. Set FINLET_API_KEY or run `finlet auth login`."), and exit non-zero.

### F-4 — `/dashboard/` (trailing slash) returns 404 while `/dashboard` returns 200 — LOW
**Phase:** 7 (Dashboard spot-check)
**Repro:** `curl -sS -o /dev/null -w "%{http_code}\n" https://finlet.dev/dashboard/` → 404; `curl -sS -o /dev/null -w "%{http_code}\n" https://finlet.dev/dashboard` → 200.
**Expected:** both variants should serve the same dashboard shell, or `/dashboard/` should 301/302 to `/dashboard`.
**Observed:** 404 with body `{"detail":"Not Found"}`. No app-shell page; just a JSON error.
**Evidence:** /tmp/v1-0-3-walk-evidence-20260511-231230/70-page-status-codes.txt, /tmp/v1-0-3-walk-evidence-20260511-231230/74-dashboard-slash.txt
**Recommended fix:** in the FastAPI / dashboard router, add a trailing-slash redirect for `/dashboard` (FastAPI's `redirect_slashes=True` default app behavior, or an explicit `@app.get("/dashboard/")` mirroring the handler at `/dashboard`).

### F-5 — `finlet mcp serve --help` references FINLET_OAUTH_BEARER but published configs set FINLET_API_KEY — LOW
**Phase:** 4 (CLI help) / 8 (Claude Desktop config sanity)
**Repro:** read `finlet mcp serve --help`; read agent-guide.html "Claude Desktop config" and "Generic MCP Client" tabs.
**Expected:** consistent env-var name across help-text and published configs.
**Observed:** `finlet mcp serve --help` docstring says "The subprocess reads `FINLET_OAUTH_BEARER` from its environment to authenticate the tool call (see `docs/decisions/cli-mcp-stdio-auth.md`)." Published Claude Desktop and Generic MCP configs both set `FINLET_API_KEY` instead. The functional path works (CLI accepts FINLET_API_KEY and the stdio bridge translates it internally), so this is doc-internal drift, not a UX bug.
**Evidence:** /tmp/v1-0-3-walk-evidence-20260511-231230/53-help-mcp-serve.txt vs /tmp/v1-0-3-walk-evidence-20260511-231230/03-agent-guide.txt lines 161-186 / 201-222
**Recommended fix:** update the `finlet mcp serve` docstring (likely in `finlet/cli.py`) to mention both env vars and which one wins, OR update the published configs to use FINLET_OAUTH_BEARER (after confirming the canonical name post-Phase 4e). Reconcile.

### F-6 — `finlet auth login --api-key` help still advertises the "90-day dual-accept window" — LOW
**Phase:** 4 (CLI help)
**Repro:** `finlet auth login --help`.
**Expected:** per project memory `project_mcp_first_phase4_shipped.md`: "Bearer-only enforcement on MCP tool surface; 90-day dual-accept window retracted (pre-launch, no consumers); MCP-First migration CLOSED." So the help text should NOT advertise an active 90-day dual-accept window.
**Observed:** docstring says "Legacy mode preserved during the 90-day dual-accept window (`docs/decisions/mcp-api-key-sunset.md`)." and "the two legacy paths are explicit opt-ins for compatibility during the dual-accept window." The OAuth path is correct as the default, but the framing of the legacy paths is stale.
**Evidence:** /tmp/v1-0-3-walk-evidence-20260511-231230/51-auth-login-help.txt
**Recommended fix:** rewrite the `auth login` docstring in `finlet/cli.py` to drop "90-day dual-accept window" language. The `--api-key` mode is now best framed as "key-verification utility for users who already exported FINLET_API_KEY and want to confirm it works", not as a transitional fallback.

## Phase summary

| Phase | Status | Notes |
|-------|--------|-------|
| 1 Discovery | PASS | Landing copy says "1 concurrent simulation" (no stale "4 sessions/day"); navigation hrefs point at `auth.html` not `login.html`; CSP + HSTS + nonce-based scripts all clean; setup.html/agent-guide.html carry `deprecation: true` + `sunset: 2026-08-06` headers (intentional rollout, not a finding) |
| 2 Signup | PASS | `POST /v1/auth/register` returns 201 with `api_key`, `user_id`, `tier`, csrf_token, and message about email verification. Session cookie set. Key is bare hex (no `fnlt_` prefix in the returned value). |
| 3 CLI install | PASS | `pip install --no-cache-dir --index-url https://pypi.org/simple/ finlet` resolves to finlet 1.0.2 + mcp 1.27.1; cold install completes in seconds; no warnings |
| 4 CLI help | MOSTLY PASS | All `--help` surfaces render via Typer/Rich cleanly. `finlet --version` is missing (F-2). `finlet auth login --help` carries stale "90-day dual-accept" framing (F-6). `auth status` (cold) exits 0 with clean message. |
| 5 MCP HTTP probe | FAIL | api_key Bearer auth is rejected (F-1). `Authorization: Bearer fnlt_<key>` and `Authorization: Bearer <bare_hex_key>` both return "Authentication required". The tool argument `api_key` returns an explicit deprecation message. OAuth JWT is the only working bearer. The published agent-guide explicitly promises dual-auth and is wrong. |
| 6 CLI MCP dispatch | PASS | Full path clean: `session create` → `session list` → `portfolio` (empty) → `order BUY 1 AAPL MARKET` → fills at $190.74 → `portfolio` (1 AAPL position, cash $99,809.26) → `status` (FROZEN clock) → `session delete`. **Zero asyncio traceback storms.** v1.0.2 traceback wrap is holding. |
| 7 Dashboard spot-check | MOSTLY PASS | Landing/setup/agent-guide/api-keys/auth.html/leaderboard.html all 200; `/login.html` 404 (correct — landing links to `auth.html`); `/dashboard` 200 with auth-guard shell; `/dashboard/` 404 (F-4); all referenced JS assets 200. |
| 8 Claude Desktop config | PASS | JSON parses; `"command": "finlet"`, `"args": ["mcp", "serve"]` is correct (the v1.0.2 fix for the `["mcp"]` bug is held). Env uses `FINLET_API_KEY`. F-5 is the minor doc/help-text drift but the published config is the canonical UX path and works. |
| 9 Generic MCP config | PASS | Same shape as Claude Desktop; JSON parses; correct `args`; correct env var. |

## What went well

- **No traceback storms.** Earlier walks saw asyncio/ConnectionReset traceback storms on `finlet session list` and similar commands. v1.0.2's traceback wrap held cleanly across `session list`, `session create`, `portfolio`, `order`, `status`, and `session delete`.
- **PyPI installation is one command and resolves to the intended version.** `pip install finlet` with no version pin lands on 1.0.2 with mcp 1.27.1 bundled. Fresh venv → first command in under 30 seconds.
- **Signup via REST is clean.** `curl -X POST https://finlet.dev/v1/auth/register` returns a complete envelope (api_key, user_id, tier, csrf, expiry, verification message). 201 status. Zero friction for programmatic agents.
- **Happy-path CLI ergonomics are tight.** `session create -n NAME -c CAPITAL -s ISO_DATE` reads well. `order -s SESSION -t TICKER --side BUY -q N --type MARKET` reads well. Rich tables for `portfolio` output are readable.
- **Error messages on the REST surface are specific and actionable.** Free-tier concurrent-session limit returned `{"error":{"code":"rate_limited","message":"Concurrent session limit reached: 1/1 active. Delete an existing session before creating a new one."}}` — matches landing copy promise and tells the user exactly how to fix.
- **MCP protocol implementation is conformant.** `initialize` returns proper `protocolVersion`, `capabilities`, `serverInfo` (finlet 1.27.0). `Mcp-Session-Id` header is emitted on init. `tools/list` returns full JSON-RPC envelopes with input/output schemas. `tools/call` enforces auth at the tool level.
- **CSP / HSTS / nonce-based scripts on every HTML page.** Trusted Types declared (`finlet-default default goog#html`). No mixed content. No third-party trackers.
- **Landing copy honest about scope:** "1 concurrent simulation" matches actual rate limit. No "4 sessions/day" remnant anywhere.

## Closing assessment

v1.0.3 is **not launch-blocked**, but it is **NEEDS-PATCH** before any third-party AI agent integration goes live. The agent-guide.html "MCP accepts BOTH Bearer oauth_jwt AND Bearer fnlt_api_key" claim is the only finding that materially misleads a stranger trying to integrate: anyone who codes against that doc will write a Bearer-with-api-key header and get back an error that doesn't reference the doc-vs-reality drift. Patch is a few lines of HTML edit in `dashboard/agent-guide.html` plus a corresponding correction in `setup.html` if it carries the same claim. Once F-1 is fixed, the remaining findings (F-2 through F-6) are polish for the next minor — the happy path is genuinely solid and the v1.0.2 traceback regression is fully fixed.
