# Blind-Agent Cold-Start Report — v1.0.0 FULL re-walk

> Date: 2026-05-11
> Walk performed: 2026-05-11T05:57 — 06:06 UTC
> Branch/tag tested: PyPI `finlet==1.0.0` (NOT editable / NOT source) — confirms post-tag PyPI artifact
> Prior report: `docs/launch/blind-agent-coldstart-report-v1.0.0.md`
> Walker: claude-opus-4-7 cold-context subagent (no insider knowledge, no source reads)
> Python: 3.14.3 (Homebrew, macOS arm64)
> Test account: `blindwalk-fullwalk-2026-05-11@finlet-test.dev` (created via dashboard)
> Screenshots: `docs/launch/screenshots-v1.0.0-fullwalk/`

## TL;DR

**FAIL. Do NOT launch / Do NOT advertise. v1.0.1 hotfix required.**

The previous walk's 2 BLOCKERs were addressed (PyPI `finlet==1.0.0` installs `mcp-1.27.1` as a top-level dep; `finlet auth login` completes and writes `~/.finlet/credentials` at 0600), but the CLI **still cannot execute a single MCP-routed command end-to-end** because the locally-spawned `finlet mcp serve` subprocess that the CLI relies on cannot validate the OAuth JWT minted by `https://finlet.dev` (`oauth_jwt_validation_failed reason=unknown_kid`). The legacy `--api-key` fallback path on the same CLI also fails (`reason=malformed_header`). Two new BLOCKERs replace the two old ones.

REST direct (curl + Bearer api_key) works fine: account create, session create, trade submit, portfolio query, leaderboard probe — all 200 OK. Dashboard UI works for sign-up, API key mint, session create (single only), and live portfolio mirror after REST trades. So the **product itself is alive**; only the CLI as a working onboarding path is dead.

- BLOCKERs: **2**
- HIGHs: **3**
- MEDIUMs: **4**
- LOWs: **2**

Launch decision: **v1.0.1 hotfix needed** before advertising the CLI as a supported entry point. If the launch narrative is "REST + Dashboard only, CLI is beta," ship is OK — but the agent-guide and setup pages still teach `pip install finlet` and CLI commands as primary, so that narrative is not currently in the docs.

## Phase 1 — Discovery

- Visited `https://finlet.dev/` — automatically 302'd to `/dashboard` because the Playwright browser session was already logged into a prior blind-walk account (carry-over state from a previous run). Manually signed out, then visited `https://finlet.dev/landing.html` to see the public marketing page a stranger would actually see.
- Landing page is clean, three CTAs (Get Started Free, Setup Guide, Create Free Account at footer). Promises **"Free tier includes 4 sessions per day"**. Setup Guide link goes to `/setup.html`. Agent Guide is at `/agent-guide.html` (link is on the API Keys page and the auth.html sidebar).
- `WebFetch` of `/setup.html`: documented install is `pip install finlet` (no extras). Includes 3 curl examples (`/v1/health`, `/v1/auth/register`, `POST /v1/sessions`) and a Claude Desktop JSON block that uses `FINLET_API_KEY` env var.
- `WebFetch` of `/agent-guide.html`: separately states `pip install finlet`, then says explicitly:
  > "Auth path matters: `finlet auth login` (OAuth Bearer) is required for the CLI and any MCP-routed dispatch — `FINLET_API_KEY` is not accepted on the MCP tool surface."
  Yet the same page's Claude Desktop config block sets `"FINLET_API_KEY": "your_api_key_here"` in the MCP server's env — directly contradicting that narrative.

## Phase 2 — Signup (web)

- Public landing → "Get Started Free" → `/auth.html?from=signup`. Default selected tab is **Create Account** (LOW#10 verification, PASS — see screenshot `01-get-started-free-default-tab.png`).
- Filled email `blindwalk-fullwalk-2026-05-11@finlet-test.dev`, password `BlindWalk-FullPass-2026!`, checked the Terms checkbox.
- Submit → "Account created. You're all set." → [Go to Dashboard] → landed on `/index.html` showing "blindwalk-fullwalk-2026-05-11@finlet-test.dev / Free tier" in the user menu.

Signup works. No friction. No password reveal. No MFA prompt. ~3 seconds round-trip.

## Phase 3 — CLI install

```
$ python3 -m venv /tmp/v1-fullwalk
$ /tmp/v1-fullwalk/bin/pip install finlet==1.0.0
Successfully installed finlet-1.0.0 mcp-1.27.1 pydantic-2.13.4 typer-0.25.1
                       cryptography-48.0.0 httpx-0.28.1 rich-15.0.0 ... (38 packages)
$ /tmp/v1-fullwalk/bin/finlet --help    # exit 0, full help text
```

**Prior BLOCKER #1 cleared.** `mcp` is now a direct dependency of `finlet==1.0.0` (verified: `mcp-1.27.1` in the pip install output). `pip install finlet` from the public PyPI is sufficient to get a CLI that does not crash at module import.

CLI surface as printed:
- Top-level: `serve register advance order portfolio status session plugins auth mcp`
- `auth login` and `auth logout` exist. **`auth status` does NOT exist** — the task spec asks to test `finlet auth status` for HIGH#5 verification, but the command was never shipped in v1.0.0. `finlet auth status` exits with "No such command 'status'."
- `session create / list / delete`, `plugins`, and `mcp` subcommands all show clean `--help` output.

## Phase 4 — First command + auth

### OAuth login (clean)

```
$ finlet auth login
Opening browser for Finlet OAuth login…
  If your browser does not open, visit:
    https://finlet.dev/oauth/authorize?response_type=code&client_id=finlet-cli&...&state=...
  [Playwright navigated to the URL on behalf of the user]
Login successful!
  Credentials saved to /Users/justnau/.finlet/credentials (mode 0600)
  Access token expires in 900 seconds; the CLI will pick it up automatically on subsequent commands.
$ ls -la ~/.finlet/credentials
-rw-------  1 justnau  staff  585 May 11 01:00 /Users/justnau/.finlet/credentials
```

**Prior BLOCKER #2 cleared.** OAuth Authorization Code + PKCE round-trip completes against prod. Loopback callback fires. Credentials persisted at 0600. **Excellent UX** — clear messages, no traceback noise.

### First MCP-routed command (FAILS — new BLOCKER #A)

```
$ finlet session list
[stderr — 1.7KB of structured-log JSON, then:]
Error: Authentication required. Provide an api_key parameter to access Finlet MCP tools.

[stdout — also pollutes:]
Error: Local MCP server requires the full Finlet installation.
Use MCP-over-HTTP with finlet.dev instead.
Install server with: pip install finlet[server]
[180-line pydantic + asyncio + ExceptionGroup traceback chain]
McpError: Connection closed
```

The CLI's design is to spawn `finlet mcp serve` locally and proxy MCP-over-stdio to the local subprocess. But:

1. **`pip install finlet==1.0.0` does NOT include enough to actually spawn `finlet mcp serve` locally.** The spawned subprocess emits the error string `Local MCP server requires the full Finlet installation. Use MCP-over-HTTP with finlet.dev instead. Install server with: pip install finlet[server]`. That error string is then printed on stdout, which IS the JSONRPC channel — the parent CLI tries to parse it as JSON-RPC, fails inside `mcp.client.stdio.stdout_reader`, and crashes through 180 lines of `BaseExceptionGroup` / `McpError: Connection closed`.

   **HIGH#5 (clean JSONRPC stream) FAILS** — the CLI's only documented MCP path produces JSONRPC parse errors and stack traces on every single MCP-routed command, out of the box, with the documented install.

2. After installing the workaround (`pip install 'finlet[server]==1.0.0'`, +80 transitive deps including boto3, edgartools, pandas, numpy, sqlmodel — ~80 MB), the spawned subprocess now runs but **rejects the OAuth JWT** that `auth login` just minted:

```
{"reason": "unknown_kid", "kid": "MyHyseGwwcE", "event": "oauth_jwt_validation_failed", ...}
{"event": "Warning: SecurityWarning: EdDSA is deprecated via RFC 9864", ...}
Error: Authentication required. Provide an api_key parameter to access Finlet MCP tools.
```

The local MCP server has its OWN JWT signing keys (regenerated per process), but the access token was minted by `https://finlet.dev`'s authorization server with a different KID. **The locally-spawned subprocess fundamentally cannot validate cloud-issued OAuth tokens.** This is architectural, not a bug in token forwarding — there is no path for the local stdio MCP server to know about the cloud server's public keys.

### Fallback: --api-key path (FAILS — new BLOCKER #B)

Minted an API key in the dashboard (`fnlt_defe75cb3d34ff4f2e7cb8abcf3d751f`) and retried:

```
$ finlet session list --api-key fnlt_defe75cb3d34ff4f2e7cb8abcf3d751f
{"reason": "malformed_header", "event": "oauth_jwt_validation_failed", ...}
Error: Authentication required. Provide an api_key parameter to access Finlet MCP tools.
```

The CLI forwards the api_key to the locally-spawned MCP server, which tries to JWT-decode it and fails (`malformed_header` — the api_key isn't a JWT) and falls through to "Authentication required." Note: the SAME api_key works perfectly when sent as `Authorization: Bearer fnlt_...` directly to `https://finlet.dev/v1/sessions` (REST):

```
$ curl https://finlet.dev/v1/sessions -H "Authorization: Bearer fnlt_defe75cb3d34ff4f2e7cb8abcf3d751f"
[]
```

So the api_key is valid at the cloud REST layer, just not at the CLI's spawned local MCP layer. **The CLI has no working auth path against prod, period.**

### Side note — HIGH#5 stream pollution surface

The `oauth_jwt_validation_failed` events DO appear on the subprocess stdout (the JSONRPC channel) — verifiable because the parent CLI re-prints them in its error path. The HIGH#5 fix from the prior bug-hunt iteration evidently isolated some structlog handlers but not these particular ones. The 13-line pydantic traceback from the prior walk is now a 180-line `BaseExceptionGroup` traceback, which is arguably worse: the user sees an ExceptionGroup chain through asyncio internals before reaching the actual "Authentication required" message.

## Phase 5 — Trade + portfolio (via REST since CLI is broken)

Discovered the correct endpoint via `https://finlet.dev/openapi.json` — `POST /v1/sessions/{id}/trade/order` with body `{"ticker":"AAPL","side":"BUY","quantity":1,"order_type":"MARKET"}`. Note the field is `ticker` not `symbol` — and the agent-guide / setup curl examples use `symbol` in their narrative when they discuss session config but NEVER show a trade-submit curl example, so the actual order-submit shape is undocumented.

```
$ SESSION_ID=$(curl -sS -X POST https://finlet.dev/v1/sessions \
    -H "Authorization: Bearer $TEST_KEY" -H "Content-Type: application/json" \
    -d '{"name":"my-first-sim","start_time":"2024-01-01","initial_capital":100000,"universe":["AAPL","GOOGL","MSFT"]}' \
    | jq -r .id)
# 5cce36f15e32

$ curl -X POST "https://finlet.dev/v1/sessions/$SESSION_ID/trade/order" \
    -H "Authorization: Bearer $TEST_KEY" -H "Content-Type: application/json" \
    -d '{"ticker":"AAPL","side":"BUY","quantity":1,"order_type":"MARKET"}'
{"id":"1f942db0e149","ticker":"AAPL","side":"BUY","quantity":1.0,"order_type":"MARKET",
 "status":"FILLED","fill_price":190.741011,"total_cost":190.74,...}

$ curl https://finlet.dev/v1/sessions/$SESSION_ID/portfolio -H "Authorization: Bearer $TEST_KEY"
{"cash":99809.26,"positions_value":190.741,
 "positions":{"AAPL":{"quantity":1.0,"avg_entry_price":190.741,...}},
 "orders_filled":1,...}
```

REST works flawlessly. Trade submitted at the session's frozen sim-time (2024-01-01), filled at $190.74, cash decremented, position added. Slippage 0.19, commission 0.

## Phase 6 — Dashboard end-to-end

### 1. Landing → Get Started Free → Create Account tab default (LOW#10)

PASS. Visiting `/auth.html?from=signup` directly opens with "Create Account" tab pre-selected. Same page visited without query string opens with "Sign In" pre-selected. Screenshot: `01-get-started-free-default-tab.png`.

### 2. Settings → API Keys → Generate New Key → mint + reveal once (HIGH#6 / MED#9)

PASS. Clicked "Generate New Key" from `/api-keys.html` empty-state. Modal asked for name + permission tier (Read & Write / Read Only). Submitted "blind-walk-fullwalk" / Read & Write. Modal closed and a new modal appeared titled "Your new API key" with:

- Bold callout: **"Copy this key now — it won't be shown again."**
- Read-only input pre-filled with `fnlt_defe75cb3d34ff4f2e7cb8abcf3d751f`
- "Copy to clipboard" + "Done" buttons

Screenshots: `02-api-keys-empty-state.png`, `03-api-key-mint-modal.png`, `04-api-key-reveal-once.png`.

This is exactly what HIGH#6 / MED#9 specified. The reveal-once UX is correct.

### 3. Sessions → Create Session → spinner during wait (MED#7)

PARTIAL PASS. The Create Session submit button does include a spinner element (`<span class="btn-modal-spinner">` inside `<button id="create-session-submit">`). However, **on this account's first session-create attempt from the dashboard UI, the request 429'd** (`POST /v1/sessions` returned HTTP 429 with `Rate limited on /sessions. Retry-After: null` per the console warning).

The 429 is suspect because (a) the landing page promises "4 sessions per day", (b) this was the user's SECOND session-create overall — the first was a REST session-create via curl, the second was the dashboard click. So one prior session existed but was active, not deleted.

Investigation via REST showed the actual semantics: **"Concurrent session limit reached: 1/1 active. Delete an existing session before creating a new one."** (error message from the v1 API). The Free tier enforces **1 concurrent session**, not 4 daily. The dashboard's 429 surfaces this as a generic Retry-After warning with no UI feedback to the user — the modal **stays open with the user's typed name field cleared**, no error banner, no alert. The user is stranded.

Screenshots: `06-create-session-spinner.png` (modal mid-submit), `08-modal-stuck-after-429.png` (modal still visible 30s later, no error feedback).

(The spinner element exists; whether it renders in-flight is moot when the request is rejected synchronously.)

### 4. Agent Guide curl examples (HIGH#3)

PASS. Two curl examples shown verbatim on the agent-guide page:

```
$ curl https://finlet.dev/v1/health
{"status":"ok","dashboard_available":true,"data_status":{"prices":"available"}}

$ curl -X POST https://finlet.dev/v1/sessions \
    -H "Authorization: Bearer $TEST_KEY" -H "Content-Type: application/json" \
    -d '{"name":"agent-guide-curl-verify","start_time":"2024-01-01","initial_capital":100000,"universe":["AAPL","GOOGL"]}'
{"error":{"code":"rate_limited","message":"Concurrent session limit reached: 1/1 active. Delete an existing session before creating a new one."}}
```

Both URLs are correct (`https://finlet.dev`, not `localhost`). The example shape is right. The rate limit hit because I already had an active session — that's not a curl-example bug, it's a separate finding (see MED#13 below).

### 5. Agent Guide MCP auth narrative (HIGH#4)

PARTIAL PASS — and contradictory. The narrative paragraph explicitly states:

> "Auth path matters: `finlet auth login` (OAuth Bearer) is required for the CLI and any MCP-routed dispatch — `FINLET_API_KEY` is not accepted on the MCP tool surface."

But the very next section (Claude Desktop config block) sets `"FINLET_API_KEY": "your_api_key_here"` in the MCP server's env. A reader following the page top-to-bottom is told "FINLET_API_KEY is not accepted on the MCP tool surface" and then asked to put FINLET_API_KEY into the MCP server's env. The two statements are flatly inconsistent.

If the dual-accept window is intentional (api_key as a fallback during the 90-day sunset), the narrative needs to say so. Right now it reads like the author meant to fix the config block to use a Bearer-token mechanism but only finished the prose half.

### 6. Claude Desktop config "Replace…" callout (MED#8)

PASS. Above the JSON config block on `/agent-guide.html`:

> "Before you copy: Replace every `your_api_key_here` placeholder below with the actual value — your API key from `finlet register` (when the client speaks the REST API), or your OAuth Bearer token from `finlet auth login` (when the client routes through the MCP server). The literal string `your_api_key_here` is not a credential."

The callout is well-written. (Caveat: see HIGH#4 — the JSON block uses `FINLET_API_KEY` env var while the prose says OAuth Bearer is required for MCP. The placeholder is replaced; the schema mismatch remains.)

Screenshot: `05-agent-guide.png` (full-page).

## Prior fixes verification matrix

| ID     | Fix description                                          | Verified? | Notes                                                                                                  |
|--------|----------------------------------------------------------|-----------|--------------------------------------------------------------------------------------------------------|
| HIGH#3 | Agent guide curl examples use correct URL                | PASS      | Both examples on `/agent-guide.html` use `https://finlet.dev`.                                         |
| HIGH#4 | Agent guide says `finlet auth login` (not API_KEY) for MCP | PARTIAL | Narrative paragraph says it; Claude Desktop JSON config block still uses `FINLET_API_KEY` env — contradictory. |
| HIGH#5 | `finlet auth status` clean JSONRPC stream                | FAIL      | `finlet auth status` doesn't exist as a command. The closest proxy (`session list`) emits 180 lines of pydantic traceback through `BaseExceptionGroup` BEFORE the friendly error envelope. Stream is heavily polluted. |
| HIGH#6 | API key mint+reveal in Settings                          | PASS      | Modal + reveal-once flow on `/api-keys.html`. Clear "Copy this key now" callout.                       |
| MED#7  | Session create spinner during wait                       | PARTIAL   | Spinner element exists in DOM (`<span class="btn-modal-spinner">`); cannot verify runtime visibility because the dashboard's session-create 429'd synchronously on this account's first attempt with no user-visible error. |
| MED#8  | Claude Desktop config "Replace…" callout exists          | PASS      | Callout is present and well-written.                                                                   |
| MED#9  | API key reveal-once flow                                 | PASS      | Same modal as HIGH#6.                                                                                  |
| LOW#10 | "Get Started Free" defaults to Create Account tab        | PASS      | `/auth.html?from=signup` opens with Create Account tab selected.                                       |

## Findings (severity-grouped)

### BLOCKER (count: 2)

**#A — CLI cannot execute any MCP-routed command. Local subprocess fundamentally cannot validate cloud-issued OAuth JWTs.**

`pip install finlet==1.0.0` (the documented install) installs `mcp-1.27.1` but NOT the `[server]` extra. When the user runs any MCP-routed CLI command (e.g. `finlet session list`), the CLI spawns `finlet mcp serve` as a local stdio subprocess. The subprocess immediately fails with:

```
Error: Local MCP server requires the full Finlet installation.
Use MCP-over-HTTP with finlet.dev instead.
Install server with: pip install finlet[server]
```

This error string is printed on stdout, which IS the JSONRPC channel. The parent CLI's `mcp.client.stdio.stdout_reader` tries to parse it as JSON-RPC, fails inside pydantic, and dies through a 180-line `BaseExceptionGroup` / `McpError: Connection closed` traceback chain.

Even after installing the recommended workaround (`pip install 'finlet[server]==1.0.0'`, +80 transitive deps), the now-spawnable subprocess rejects the OAuth JWT with `oauth_jwt_validation_failed reason=unknown_kid` — the LOCAL MCP server cannot validate JWTs minted by the CLOUD OAuth authorization server because they use different signing keys.

**The CLI's "spawn local mcp serve and route MCP-over-stdio" design is fundamentally incompatible with using cloud-minted OAuth tokens.** Either the CLI must dispatch over HTTP to `https://finlet.dev/mcp` (as the error message accidentally suggests), or the local subprocess needs to be taught the cloud's JWKS endpoint.

Fix options (any one):
- Make the CLI dispatch MCP over HTTP/SSE directly to `https://finlet.dev/mcp` instead of spawning local stdio.
- Have the local `finlet mcp serve` subprocess fetch and trust the cloud's JWKS (`https://finlet.dev/.well-known/jwks.json` or similar) at startup when the bearer token is a cloud-issued JWT.
- Bundle a thin REST-over-MCP shim in the base `finlet` package so the CLI talks to `https://finlet.dev` directly and never spawns a local server.

Impact: **every single MCP-routed CLI command** (`session list`, `session create`, `session delete`, `portfolio`, `orders`, `order`, `status`, `advance`, `plugins ...`) fails. The CLI is decorative.

Evidence: `pip install finlet==1.0.0` followed by `finlet auth login` (succeeds) followed by `finlet session list` (fails with stack trace). Reproduced 3x in a clean venv. Logs at `/tmp/blind-walk-v1/session_list*.std{out,err}`.

**#B — Even the legacy `--api-key` fallback path on the CLI is dead.**

The locally-spawned MCP subprocess tries to JWT-decode the `fnlt_*` api_key as if it were a JWT, fails with `oauth_jwt_validation_failed reason=malformed_header`, and falls through to "Authentication required." The same api_key works perfectly when sent as `Authorization: Bearer fnlt_...` to `https://finlet.dev` directly.

This blocks the documented "dual-accept window" / api_key fallback the agent-guide narrative references.

Fix: same as BLOCKER #A — the local MCP server needs to accept api_key headers the same way the cloud's MCP surface does, OR the CLI needs to skip the local spawn for api_key paths and dispatch to the cloud.

### HIGH (count: 3)

**#11 — HIGH#5 fix is incomplete / regressed.** `finlet auth status` (the command the prior bug-hunt explicitly listed as the verification command for HIGH#5) does not exist in shipped v1.0.0. The closest proxy commands (`session list`, etc.) produce 180-line `BaseExceptionGroup` tracebacks BEFORE the user-friendly error message. The stream pollution is worse than the prior walk's 13-line pydantic traceback.

**#12 — Agent-guide internal contradiction on MCP auth.** The narrative paragraph says "FINLET_API_KEY is not accepted on the MCP tool surface" while the Claude Desktop config block teaches `"FINLET_API_KEY": "your_api_key_here"`. Even if both are technically true during the dual-accept window, a stranger reading the page top-to-bottom is told contradictory things.

**#13 — Free tier marketing says "4 sessions/day" but enforced policy is "1 concurrent session" (any tier).** Landing page hero promises "Free tier includes 4 sessions per day. No credit card required." Reality: REST `POST /v1/sessions` returns `{"error":{"code":"rate_limited","message":"Concurrent session limit reached: 1/1 active. Delete an existing session before creating a new one."}}` on a Free-tier account's second session-create with one already active. Either the marketing copy needs to say "1 concurrent" instead of "4 per day" or the policy needs to allow 4 ACTIVE sessions.

### MEDIUM (count: 4)

**#14 — Dashboard session-create 429 has no user-visible error feedback.** When the dashboard's `POST /v1/sessions` hits the rate limit, the modal stays open, the typed name field is cleared, and no alert/banner/inline error appears. The user is silently stranded. Console-only warning is not enough.

**#15 — Documented install (`pip install finlet`) is insufficient to run the CLI's documented happy path.** Even now that `mcp-1.27.1` ships in the base wheel, the spawned local MCP server prints "Use MCP-over-HTTP with finlet.dev instead. Install server with: pip install finlet[server]". The install command stops being correct at the second CLI invocation. Update setup.html to either (a) recommend `pip install finlet[server]` upfront, or (b) ensure the base install is enough.

**#16 — Undocumented body field for trade submission (`ticker` vs `symbol`).** Agent guide and setup curl examples use `symbol` in their session-config payloads (`"universe": ["AAPL","GOOGL","MSFT"]`). When a user infers the trade-submit shape and uses `{"symbol":"AAPL",...}`, the API returns `validation_error: Field required: body.ticker`. No example shows the actual `ticker` field name. Add a trade-submit curl example to setup.html and agent-guide.html.

**#17 — `finlet trade submit` is not the CLI command name; it's `finlet order`.** The task spec (and reasonable user intuition) expects `finlet trade submit --side buy --symbol AAPL`. The shipped CLI uses `finlet order --side BUY --ticker AAPL --quantity 1` — different verb, different flag names. If the docs or any external collateral teach `trade submit`, they're wrong. (LOW could argue: but it's a stranger-facing API surface mismatch and likely to recur in agent-guide expansions, so MED.)

### LOW (count: 2)

**#18 — `/v1/auth/register` curl example in setup.html still teaches password-based registration even though the dashboard signup is the recommended path.** Minor consistency issue.

**#19 — Auto-redirect from `https://finlet.dev/` to `/dashboard` for a logged-in user means they can never see the marketing/landing page without signing out. The "Finlet home" header link from inside the app also goes to `/dashboard`, not the landing. Cosmetic but makes it hard to send a colleague to the marketing page without explicit path.

## Launch decision recommendation

**v1.0.1 hotfix needed.** Do NOT advertise the CLI as a primary integration path until BLOCKER #A and #B are fixed.

Minimum scope for v1.0.1:
1. **Pick a CLI dispatch architecture and commit.** Either (a) HTTP transport to `https://finlet.dev/mcp` so cloud-issued JWTs Just Work, or (b) make the local spawned `finlet mcp serve` accept cloud-issued JWTs by fetching the cloud's JWKS, or (c) bundle a REST shim so the CLI never spawns. Right now the CLI is in a triple-tied state where none of the three works against prod.
2. **Reconcile the agent-guide internal contradiction.** Pick one: api_key OR OAuth Bearer for MCP, and make narrative + Claude Desktop config block agree.
3. **Either ship `auth status` or remove it from the verification spec.** Currently the command tested in the verification matrix doesn't exist.
4. **Fix the dashboard's 429 silent-fail UX.** When session-create rate limits, show an inline error on the modal explaining the 1-concurrent policy and offering [Delete existing session].
5. **Reconcile "4 sessions/day" marketing copy with "1 concurrent" policy.**

What ships safely TODAY (v1.0.0 as-is) without re-cutting:
- The dashboard end-to-end flow (signup → API key mint → portfolio view after a REST-submitted trade) — works.
- REST API curl integration — works (modulo MED#16 and #18 documentation gaps).
- The marketing landing page and signup flow — work.

What is BROKEN in v1.0.0 as-is:
- The CLI as an end-to-end integration path. Every MCP-routed command fails.
- The "auth status" verification scenario the prior bug-hunt thought was fixed.

If the launch narrative is REST-first and the CLI is explicitly "preview / beta", current v1.0.0 ships fine for the REST/dashboard story. If the CLI is supposed to be a supported primary path, **do NOT launch** until v1.0.1.

## Agent-side issues hit during the walk

- Playwright browser session arrived pre-logged-in to a prior blind-walk account (carry-over state from prior runs of this skill). Mitigated by signing out and visiting `/landing.html` directly.
- `finlet auth status` didn't exist, so I substituted `finlet session list` (the next MCP-routed command) as the HIGH#5 stream-pollution probe.
- No real human OAuth was required because the same Playwright session was logged into the freshly-created blind-walk account when the CLI's `/oauth/authorize` redirect arrived; consent auto-completed.
