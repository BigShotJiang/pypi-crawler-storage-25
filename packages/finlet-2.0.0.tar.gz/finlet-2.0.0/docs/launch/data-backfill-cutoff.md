# Data Backfill Cutoff — v1.0.0 Launch Knowledge Horizon

> **Status:** REFRESH RECOMMENDED before tag. See `## Refresh recommendation`.
>
> Inspected 2026-05-10 by Team E (Launch v1.0.0 exec-plan)
> against canonical S3 bucket resolved via SSM Parameter Store.

## Cutoff date

**Knowledge horizon for v1.0.0: 2026-04-16** (the MIN of all 5 spot-check ticker most-recent-dates in `prices/daily/`).

Today is 2026-05-10 — the canonical data lake is **24 days stale** at inspection time.

## Inspection method

Inspected S3 partitions via AWS CLI from local laptop on 2026-05-10. Did NOT run a fresh
backfill — full backfills are an EC2 ops task per `project_backfill_session3_postmortem.md`
(8-14h wall-clock, persistent-spot or on-demand instance required) and a synchronous
worktree subagent cannot complete one. The agent's job here is INSPECT + DOCUMENT only;
the runbook (Team F) will dispatch the actual refresh on EC2 before tag.

For fundamentals canonical/quarterly, partition coverage and `filed_at` / `period_end`
horizons were extracted by downloading the per-ticker parquet files for AAPL, NVDA, BRK-B,
TSLA and reading them with `pyarrow.parquet`. SPY is absent from fundamentals (ETF, no
SEC filings — expected behavior; this is not a gap).

For prices, the latest daily partition (`2026-04-16.parquet`, 293 tickers) was downloaded
and inspected directly; all 5 spot-check tickers (AAPL, NVDA, BRK-B, TSLA, SPY) were
present with non-null OHLCV.

## Bucket names

Both prices and fundamentals resolve to the **same** canonical bucket:

```
FINLET_PRICE_BUCKET=finlet-data-cccdea31         (SSM /finlet/prod/FINLET_PRICE_BUCKET)
FINLET_FUNDAMENTALS_BUCKET=finlet-data-cccdea31  (SSM /finlet/prod/FINLET_FUNDAMENTALS_BUCKET)
```

AWS account: `877173392475` (root caller). Per `feedback_ec2_backfill_bucket_env.md`, the
runbook MUST set both env vars explicitly on the EC2 backfill instance — do NOT default
to `finlet-data` (no-hash; that bucket would 404).

S3 layout under `finlet-data-cccdea31/`:

```
prices/daily/                               # current canonical EOD prices
prices/daily-backup-2026-04-10/             # snapshot of pre-2026-04-17 state (frozen)
fundamentals/canonical/                     # build_canonical@unknown writer (per-ticker)
fundamentals/quarterly/                     # ingest_edgar_fundamentals@unknown writer (per-ticker)
fundamentals/_checkpoints/                  # sentinel `.done` markers from prior backfill runs
edgar/filings/, edgar/insider_trades/       # raw EDGAR
news/, economic/, reference/                # other ingest streams (out of scope here)
_deploy/                                    # backfill code tarballs (out of scope)
```

## Manifest sidecar verification

Per the partition-completeness invariant
(`docs/decisions/partition-completeness-invariant.md`), every parquet under
`prices/daily/`, `fundamentals/canonical/`, and `fundamentals/quarterly/` has a
`*.parquet.manifest.json` sidecar emitted by `S3ParquetWriter` at write time. There is no
top-level `_manifest.json` (intentional — manifests are per-partition, not bucket-wide).

Sample listings:

```
$ aws s3 ls s3://finlet-data-cccdea31/prices/daily/2026-04-16.parquet*
2026-04-17 14:37:45      14712 2026-04-16.parquet
2026-04-17 14:37:45       2436 2026-04-16.parquet.manifest.json

$ aws s3 ls s3://finlet-data-cccdea31/fundamentals/canonical/AAPL.parquet*
2026-04-17 13:50:53      30892 AAPL.parquet
2026-04-17 13:50:53        546 AAPL.parquet.manifest.json

$ aws s3 ls s3://finlet-data-cccdea31/fundamentals/quarterly/AAPL.parquet*
2026-04-16 22:14:09     128438 AAPL.parquet
2026-04-16 22:14:09        564 AAPL.parquet.manifest.json
```

Spot-check of `2026-04-16.parquet.manifest.json` content (truncated):

```json
{
  "version": 1,
  "partition_key": "prices/daily/2026-04-16.parquet",
  "partition_type": "date",
  "writer": "ingest_yfinance_prices@unknown",
  "source": "yfinance",
  "written_at": "2026-04-17T19:37:44.798989Z",
  "row_count": 293,
  "schema_hash": "sha256:a390ff15...",
  "parquet_sha256": "sha256:cb54bdd4...",
  "coverage": {
    "partition_type": "date",
    "date": "2026-04-16",
    "ticker_count": 293,
    "universe_id": "us_equities_v1"
  },
  "retroactive": false
}
```

All inspected partitions carry valid sidecars. **Manifest sidecar verification: PASS.**

## Ticker spot-checks

### Prices (`prices/daily/2026-04-16.parquet`, 293 tickers, schema = `[date, ticker, open, high, low, close, volume]`)

| Ticker | Most recent date | Rows in partition | Null fields | Notes |
|--------|------------------|-------------------|-------------|-------|
| AAPL   | 2026-04-16       | 1                 | none        | OHLCV complete |
| NVDA   | 2026-04-16       | 1                 | none        | OHLCV complete |
| BRK-B  | 2026-04-16       | 1                 | none        | Stored as `BRK-B` (yfinance convention) — `BRK.B` is the public form. Plugins resolve via the same canonical key. |
| TSLA   | 2026-04-16       | 1                 | none        | OHLCV complete |
| SPY    | 2026-04-16       | 1                 | none        | OHLCV complete |

The full spot-check sample for the last month (2026-04-01 .. 2026-04-16):
the `prices/daily/` listing shows continuous coverage from 2010-01-04 (first
partition) through **2026-04-16** (latest partition). No date gaps detected
in the last-month tail (16 partitions, all weekdays present).

### Fundamentals (`fundamentals/canonical/<ticker>.parquet`, 196 tickers; schema = `[ticker, period_end, filed_at, concept, value, currency, source_tag, is_amendment, is_financial_firm]`)

| Ticker | period_end range            | Latest filed_at | Rows  | Null fields | Notes |
|--------|------------------------------|-----------------|-------|-------------|-------|
| AAPL   | 2006-09-30 .. 2025-12-27     | 2026-01-30      | 4810  | none        | Q1-FY26 10-Q on file |
| NVDA   | 2007-01-28 .. 2026-01-25     | 2026-02-25      | 4897  | none        | FY26 Q4 / annual recently filed |
| BRK-B  | 2006-12-31 .. 2025-12-31     | 2026-03-02      | 2295  | none        | FY25 10-K on file |
| TSLA   | 2008-12-31 .. 2025-12-31     | 2026-01-29      | 4176  | none        | FY25 10-K on file |
| SPY    | n/a                          | n/a             | n/a   | n/a         | ETF — no SEC fundamentals filing. Absence is expected, NOT a gap. |

The fundamentals partitions at `quarterly/` mirror the canonical partitions one-to-one
(196/196 tickers) with the same 2026-04-16 backfill run timestamp.

## Gaps + retries

Only one stale-data finding:

- **Prices `prices/daily/`**: latest partition is `2026-04-16` (24 calendar days behind 2026-05-10).
  All 5 spot-check tickers are present with non-null OHLCV at that date; the staleness is a
  fleet-wide gap, not a ticker-specific one. Coverage from 2010-01-04 through 2026-04-16 is
  continuous on weekdays; no intra-range gaps.
- **Fundamentals canonical/quarterly**: per-ticker partitions are current relative to filing
  cadence (latest `filed_at` ranges from 2026-01-29 to 2026-03-02 across the 4 spot-checks).
  Fundamentals are inherently slower-moving than prices — the quarterly cycle means a 30-90
  day filed_at lag is normal, not a gap.
- **SPY fundamentals**: ABSENT (expected — ETFs do not file 10-K/10-Q). Not a gap.
- No ticker showed null core fields. No retry needed at the ticker level.

## Refresh recommendation

**(b) Delta refresh recommended — runbook Team F dispatches an EC2-side delta backfill
before tag.**

Rationale:
- The 24-day prices staleness exceeds the 7-day threshold the launch plan calls "horizon
  acceptable for v1.0.0". Tagging at 2026-04-16 horizon would advertise a launch with
  ~3.5 weeks of stale market data — visible to any agent that runs a recent-date backtest.
- Fundamentals horizons are within the normal 10-Q/10-K filing cadence; no delta needed
  there unless the prices delta surfaces a new ticker outside `us_equities_v1`.
- Manifest sidecar coverage is intact and schemas are healthy — a **full** refresh (c)
  would be wasteful (8-14h on EC2 vs ~1-2h delta for ~24 trading days).

### Runbook step (for Team F to incorporate)

On the EC2 backfill instance, **before** v1.0.0 tag:

```bash
# 1) Set canonical bucket env vars EXPLICITLY (per feedback_ec2_backfill_bucket_env.md).
#    Default-to-finlet-data is a NoSuchBucket trap and is BANNED.
export FINLET_PRICE_BUCKET=finlet-data-cccdea31
export FINLET_FUNDAMENTALS_BUCKET=finlet-data-cccdea31

# 2) Resolve via SSM if you need to verify (avoids drift if the bucket is rotated):
export FINLET_PRICE_BUCKET=$(aws ssm get-parameter \
  --name /finlet/prod/FINLET_PRICE_BUCKET --query Parameter.Value --output text)
export FINLET_FUNDAMENTALS_BUCKET=$(aws ssm get-parameter \
  --name /finlet/prod/FINLET_FUNDAMENTALS_BUCKET --query Parameter.Value --output text)

# 3) Delta-refresh prices for the gap window (2026-04-17 .. today):
#    See scripts/ingest_yfinance_prices.py:1012 for the main entrypoint and CLI flags.
#    Use --start 2026-04-17 --end <today> (whatever the script's date-range flags are
#    in the live tree at run time — the exact flag names are NOT pinned by this doc;
#    Team F should consult `python scripts/ingest_yfinance_prices.py --help`).
nohup uv run python scripts/ingest_yfinance_prices.py \
  --start 2026-04-17 \
  > /tmp/finlet-delta-prices.log 2>&1 &

# 4) (Optional) refresh fundamentals if any new 10-K/10-Q has filed since 2026-03-02.
#    Most likely no-op pre-launch, but the runbook should run it anyway for completeness:
nohup uv run python scripts/ingest_edgar_fundamentals.py \
  > /tmp/finlet-delta-fundamentals.log 2>&1 &

# 5) Validate post-run: every NEW partition has a manifest sidecar.
#    Pick the latest partition in prices/daily/ and confirm its sidecar exists:
LATEST_PRICE_PARTITION=$(aws s3 ls s3://$FINLET_PRICE_BUCKET/prices/daily/ \
  | grep '\.parquet$' | tail -1 | awk '{print $NF}')
aws s3 ls "s3://$FINLET_PRICE_BUCKET/prices/daily/${LATEST_PRICE_PARTITION}.manifest.json" \
  || { echo "MANIFEST MISSING — DO NOT TAG"; exit 1; }
```

ETA for delta: **1-3 hours wall-clock** (24 trading days × 293 tickers via yfinance).
This is a soft block on the v1.0.0 tag, not a hard one — if launch timing is critical
the team can ship at the 2026-04-16 horizon and announce the staleness explicitly. The
runbook should make that call live, not this doc.

## Cache invalidation note

Per `feedback_s3_not_equals_queryable.md`, **S3 write != queryable on the deployed
instance**. After the delta backfill completes:

- The deployed FastAPI instance's `PricePlugin` keeps a 24-hour local Parquet cache
  (`CACHE_TTL_SECONDS = 86400` per `finlet/plugins/price_plugin.py:38`). Until that
  TTL elapses or the cache is purged, queries for `2026-04-17` and later may still
  return "no data" even though S3 has fresh partitions.
- The probe cache (`PROBE_CACHE_TTL_SECONDS = 60`) is separate and self-resolves
  within a minute — no action required there.

**Runbook step (for Team F to incorporate, post-deploy smoke):**

```bash
# Option A: restart the FastAPI process to drop the in-process cache.
sudo systemctl restart finlet-api    # or whatever the prod service unit is

# Option B: clear the local parquet cache directory if cache eviction is needed
# without a restart (path is per-instance — see PricePlugin._cache_dir resolution).

# After restart, smoke-verify a recent-date query through the public API:
curl -sS "https://finlet.dev/api/v1/plugins/price/query?ticker=AAPL&start=2026-05-01&end=$(date -u +%Y-%m-%d)" \
  | jq '.items_post_filter, .ceiling_applied'
# Expect items_post_filter > 0 with the most recent date matching the post-delta horizon.
```

---

## Validation checklist

- [x] File exists at `docs/launch/data-backfill-cutoff.md`.
- [x] Cutoff date is filled in: **2026-04-16**.
- [x] All 5 spot-check tickers have a row in the table (AAPL, NVDA, BRK-B, TSLA, SPY).
- [x] Manifest sidecar status documented for both prices and fundamentals.
- [x] Refresh recommendation explicitly picks one of (a), (b), (c): **(b) delta refresh**.
