---
tags: [finlet, architecture, design, system]
keywords: Finlet architecture, SimClock, DateCeilingEnforcer, plugin system, FastAPI, MCP server
priority: normal
---

# Finlet — Architecture Specification

> **An evaluation harness for AI trading agents.** Daily-timeframe. US equities. Long-only. Test your AI agent's reasoning — not just its algorithms.

Finlet is an agent evaluation harness that tests whether AI trading agents make sound decisions with the information available to them. It provides a simulation clock that controls what data the agent can see, a Date Ceiling Enforcer that strips future data from every response, a portfolio engine for tracking trades, and a tamper-evident reasoning trace with SHA-256 checksums — all purpose-built for evaluating agent reasoning, not backtesting strategies.

---

## v1 Scope

Finlet v1 is intentionally scoped as a **daily-timeframe, US-equities + crypto, long-only agent evaluation harness**. Every boundary below is a design choice for the evaluation use case, not a limitation waiting to be resolved.

**What's in:** S3 Parquet data lake as the primary data hot path — EOD price data (Databento, supporting equities and crypto datasets), quarterly fundamentals, daily news headlines, analyst sentiment — plus SEC EDGAR filings, FRED economic indicators, and Finnhub as a fallback for news and fundamentals when the S3 data lake is unavailable. Long-only trading with market/limit/stop orders, fixed slippage (10 bps default), Date Ceiling Enforcer, SHA-256 reasoning trace, cross-scenario leaderboard, MCP server (18 tools), REST API, web dashboard, auth/billing/marketplace infrastructure.

**What's out (by design):** Intraday data (tests execution speed, not reasoning), multi-asset beyond equities and crypto (options/futures/forex lack equivalent data quality), short selling (margin mechanics orthogonal to reasoning evaluation), partial fills (require order book depth unavailable at EOD), live/paper trading (different product category with different compliance requirements), commission modeling (adds noise to reasoning evaluation).

**Competitive differentiators:**
- **Date Ceiling Enforcer** — Runtime defense-in-depth with property-based proofs. No competitor equivalent.
- **SHA-256 Reasoning Trace** — Tamper-evident audit of every agent action. No backtester tracks reasoning.
- **Cross-Scenario Leaderboard** — Composite scoring across 5 dimensions including reasoning quality (coverage, research ratio, query diversity). Unique evaluation dimension.

See [V1_SCOPE.md](V1_SCOPE.md) for the complete scope document with per-decision rationale.

---

## Core Concepts

### 1. Simulation Clock

The clock is the central mechanism that prevents future data leakage. It has three modes:

| Mode | Behavior |
|------|----------|
| **FROZEN** | Clock is stopped. Agent can make unlimited queries at the current time. Clock never advances implicitly. |
| **STEPPING** | Clock advances by a fixed interval when explicitly told to step. |
| **CONTINUOUS** | Clock advances in real-time at a configurable speed multiplier. |

**Key invariant:** The clock ONLY moves forward when explicitly advanced. No implicit time progression.

Methods: `freeze()`, `step(interval)`, `step_to(datetime)`, `play(speed)`, `get_time()`.

**Internal-only methods:** `_advance_to()` is the internal clock advancement method. It is not part of the public API — external callers must use `step()`, `step_to()`, or `play()` to advance the clock. This prevents bypassing monotonicity guarantees.

**Idempotency at current_time + explicit end_time guard (MCP_BENCHMARK_FIXES, 2026-05-19 — Team B `a15092b`):** `step_to(target)` rejects `target < current_time` (strict monotonicity preserved), but treats `target == current_time` as an idempotent no-op so an agent calling `advance_time(target_date=current_time)` returns the current state instead of raising. Both `step_to()` and `step()` raise `ValueError("Target time ... exceeds session end_time ...")` when the resulting target overshoots `end_time` — agents now see an actionable bound instead of silently clamping. The continuous-mode `play()` path keeps the silent clamp inside `_advance_to()` (strict-error would crash the simulation) but now emits a `sim_clock.advance_clamped_to_end` structured log when it triggers. See `docs/decisions/2026-05-19-clock-step-to-idempotency-and-end-time-guards.md`.

**Timezone safety:** All 5 clock entry points (`freeze()`, `step()`, `step_to()`, `play()`, `get_time()`) enforce timezone awareness via `_require_aware()`. Naive (offsetless) datetimes are rejected with `ValueError` instead of being silently reinterpreted as UTC. This closes the risk of a caller passing a local-time datetime that gets stamped as UTC, which could shift the simulation to the wrong instant.

The clock handles market hours awareness — it can skip weekends and after-hours when configured. NYSE holidays are computed algorithmically for 2010–2035 using the Meeus/Jones/Butcher Easter algorithm (for Good Friday), covering all 9 standard NYSE holidays plus early closures. This replaces the earlier static holiday table (2024–2027). All times stored in UTC.

### 2. Date Ceiling Enforcer (Defense-in-Depth)

Every piece of data that flows from a plugin to the agent passes through the date ceiling enforcer. This is the most critical safety mechanism in Finlet.

**Rules:**
- All timestamps in response data must be ≤ current sim clock time
- Items with timestamps after the ceiling are **stripped**
- Items without timestamps are **excluded by default**
- The enforcer logs how many items were stripped (but NEVER exposes this count to the agent — doing so would leak information about future data existence)
- `filing_date` is a recognized timestamp key (used by EDGAR filings plugin)
- Non-temporal query types (search, info, catalog) use `allow_missing_timestamp=True` to pass through items that lack timestamps, since these queries return reference data rather than time-series
- This is defense-in-depth: plugins also filter, but we don't trust them
- **All price query paths are enforcer-wrapped**: REST services (`market_service`, `trade_service`, `clock_service`) and MCP tools (`submit_order` auto-fill, `advance_time` price refresh) all route price queries through `DateCeilingEnforcer.enforce()`. No code path bypasses the enforcer.

### 3. Portfolio Engine

Tracks:
- **Cash**: Starting capital minus purchases plus sales. Rounded to 2 decimal places after every mutation (initialization, buy, sell) to prevent floating-point drift over many trades.
- **Positions**: ticker, quantity, avg_entry_price, current_price, unrealized P&L, realized P&L
- **Computed metrics**: total_value, sharpe_ratio, max_drawdown, win_rate
- **Order activity metrics**: `orders_filled` (count of `OrderStatus.FILLED` events, both BUY and SELL) is exposed alongside `trade_count` (count of *closed* trades — the win-rate denominator). Backwards-compatible additive field on `PortfolioMetrics`, `PortfolioResponse` (`schemas/portfolio.py`), and `PortfolioMetricsResponse` (`schemas/session.py`). Counter is incremented under the same `asyncio.Lock()` as `_trade_pnls`. The dashboard Win Rate tile uses both fields to disambiguate `0 closed trades` from `0 activity` — e.g. `Win Rate N/A (0 closed / 1 filled)` after a single BUY.
- **Equity curve**: Time series of portfolio value snapshots for charting. Deduplicates timestamps — if two steps advance to the same time, the last entry at that timestamp is replaced rather than appending a duplicate. **Snapshots are taken AFTER price refresh and order fills** (inside `refresh_prices_and_fill_orders()`) to ensure they capture post-fill portfolio state. Snapshots are persisted to the database via `save_snapshot()` from the clock routes.

**Percentage-scale metrics contract:** All `*_pct` fields on `PortfolioMetrics` are in **percentage scale** (e.g. `5.0` for 5%, not `0.05`). This applies to `unrealized_pnl_pct`, `total_return_pct`, `benchmark_return_pct`, and `alpha_vs_benchmark`. The same convention propagates through the leaderboard pipeline — `ScenarioResult.return_pct`, `ScenarioScore.total_return_pct`, and the scoring composite — and through the REST API schemas (`schemas/portfolio.py`, `schemas/session.py`), the dashboard (`dashboard/app.js`), and CLI output. Clients and frontends render `value + "%"` without multiplying by 100. `scoring.compute_composite_score` expects percentage-scale inputs and its sigmoid range mapping is calibrated accordingly. See `docs/decisions/portfolio-percentage-scale.md`.

Portfolio value updates whenever the clock advances by looking up current prices. All portfolio mutations are protected by an `asyncio.Lock()` to ensure concurrency safety under concurrent API requests. Position persistence uses atomic upsert via SQLite `INSERT ... ON CONFLICT DO UPDATE` on the `(session_id, ticker)` UNIQUE constraint, preventing duplicate rows from concurrent saves.

**Epsilon cleanup:** A constant `EPSILON = 1e-9` is used to clean up floating-point dust in positions. After a sell execution in `_execute_sell_unlocked()`, if a position's remaining quantity falls below `EPSILON`, the position is closed (quantity set to zero) rather than left with a tiny residual like `1e-14`. This prevents phantom positions from accumulating across many buy/sell cycles.

**Commission handling:** In `_execute_sell_unlocked()`, commission is deducted from the cash balance at the time of the sale. The realized P&L calculation does NOT subtract commission separately — doing so would double-count it since cash already reflects the deduction. This is correct for the current model where commission = 0 in v1, and will remain correct when commissions are enabled.

### 4. Order System

Order types for v1:
- **MARKET**: Auto-fills immediately on submission at the current market price. Both the MCP `submit_order` tool and the REST `POST /trade/order` endpoint fill MARKET orders synchronously — the order is returned with status FILLED and a `fill_price`. If the current price is unavailable (e.g., no cached data for the ticker), the order degrades gracefully to PENDING and will fill on the next clock advance. This eliminates the need for agents to call `advance_time` just to fill a simple market order. **Immediate rejection on price error:** If the price plugin returns an error (circuit breaker OPEN, S3 unreachable, etc.), MARKET orders are immediately REJECTED with the plugin error message instead of degrading to PENDING. This gives agents an actionable error to respond to rather than silently queuing an unfillable order.
- **LIMIT**: Fills when price crosses the limit price, with **price improvement** — BUY LIMIT fills at `min(current_price, limit_price)`, SELL LIMIT fills at `max(current_price, limit_price)`, matching standard exchange behavior where the order fills at the better of the two prices
- **STOP**: Converts to MARKET when stop price is triggered

Each order has BUY/SELL side, an optional `reasoning` field for trace logging, and a `time_in_force` field.

**Time in force (TIF):** Orders support `TimeInForce.GTC` (good til cancelled, default) and `TimeInForce.DAY` (expires at end of trading day). GTC is the default for backwards compatibility — all existing orders and API consumers that don't specify TIF continue to work unchanged. DAY orders are expired (status set to CANCELLED with reason "DAY order expired") during `process_pending_orders()` before fill attempts, when `sim_time.date() > order.submitted_at.date()`. TIF is exposed in the REST API (`POST /sessions/{id}/trade/order`), MCP tools, and CLI (`--tif DAY|GTC`).

**Slippage model:** Orders are subject to simulated slippage at fill time. `finlet/core/slippage.py` defines a `SlippageModel` ABC with two implementations: `NoSlippage` (identity) and `FixedPercentageSlippage` (applies ±bps based on buy/sell side). The default is 10 bps (0.1%). Slippage is configured per-session via `SessionConfig.slippage_bps` and applied in `OrderBook._fill()` before setting `fill_price`. This is separate from commission handling (which occurs in Portfolio).

**Cash-disclosure fields on `Order` and `OrderResponse` (post bug-hunt 20260503T230405Z2601 Team D, commit `3dc28c2`):** the `Order` model gains a `slippage_amount: float | None` field populated by `OrderBook._fill()` at fill time as the absolute dollar slippage charged on this fill (positive for both sides — cost increase for BUY, proceeds reduction for SELL). The REST `OrderResponse` schema (`finlet/api/schemas/trade.py`) gains three optional disclosure fields: `commission` (session config, currently 0.0 by v1 contract), `slippage_amount` (mirrors the engine field), and `total_cost` (signed cash impact: `fill_price × quantity ± commission`, sign by side — positive for BUY cash outflow, negative for SELL cash inflow). The disclosure is wired through `trade_service.order_dict(order, *, session=None)` so REST and MCP both surface the fields. This is a DISCLOSURE fix, not a math change — the engine's cash math was already consistent at 6dp internally; the missing piece was that the response only exposed `fill_price` and `quantity`, forcing the client to multiply (`displayed_fill_price × quantity`) and observe a pennies-level mismatch with the actual cash delta because `fill_price` was being rounded to 2dp for display while the math was computed at 6dp. V1 contract is binding: `commission` default is 0.0 and `slippage_bps` default is 10 — disclosure does not change those defaults. Decision record: `docs/decisions/order-response-cash-disclosure-fields.md`.

**v1 simplifications:** No partial fills, no short selling, no commission. Time-in-force supports DAY and GTC (default).

Order status flow: `PENDING → FILLED | CANCELLED | REJECTED`

- **FILLED**: Order matched against market data and executed in the portfolio.
- **CANCELLED**: Order actively cancelled by the user before execution.
- **REJECTED**: Order could not be executed (e.g., insufficient cash, portfolio constraint violation). On rejection, `fill_price` and `filled_at` are cleared to prevent stale data from a prior fill attempt.

The OrderBook uses an `asyncio.Lock()` to serialize order submissions and fills, preventing race conditions on concurrent access. `Session.process_pending_orders` delegates to `OrderBook.process_pending_orders`, which fills all eligible orders atomically under a single lock acquisition (no per-order lock churn). Portfolio mutations (buy/sell execution) happen after the atomic fill batch, with `try/except` to handle insufficient cash gracefully — if a portfolio execution fails, the order is REJECTED (not CANCELLED) to distinguish system rejections from user cancellations. Order submission and clock tick persistence are atomic — all position saves, order saves, and snapshot writes within a single tick share one database transaction via a caller-managed `AsyncSession`.

**Fill→persist atomic invariant:** `trade_service.submit_order` persists positions inline with the order and session, inside the same `async with get_session_db(...) as db:` block. When a MARKET auto-fill produces a non-zero position (BUY, partial SELL) the service calls `save_position`; when a SELL zeroes the position it calls `delete_position`. Position persistence is never deferred to a post-fill hook — the order row, the session row, and the position row all commit together so that session reload sees the same cost basis and quantity the in-memory portfolio held at fill time. This applies equally to REST `/trade/order` and MCP `submit_order` since both route through `trade_service`. See `docs/decisions/avg-entry-persistence-fix.md`.

**REJECTED envelope contract (Codex bug `9a85b8bd`, 2026-05-22):** Semantic order rejections (insufficient cash, insufficient shares, plugin error, validate-order failure) raise `finlet.errors.OrderRejected(ValueError)` AFTER the REJECTED record is persisted in memory (`OrderBook._orders`) and DB (`_persist_market_terminal`), so audit lookup by `order_id` always finds the rejection. `OrderRejected.VALID_CODES` frozenset (`insufficient_cash`, `insufficient_shares`, `plugin_error`, `validate_order_failed`, `circuit_breaker_open`) is the canonical taxonomy. REST surfaces shape as HTTP 422 with `{error, code, order_id, doc}` detail (via `app.install_error_handlers`, which now preserves dict details verbatim); MCP envelope shape is `{error, code, order_id}` (path-sanitized via `sanitize_paths`). The MCP envelope shaping happens in `@blind_error_mapper` BEFORE the blind-mapping lookup re-raise path so non-blind rejections never escape unshaped. `OrderRejected` subclasses `ValueError` for back-compat; the swallow site at `trade_service.py:368` (broad `except Exception:` that fell through to a PENDING-fallback persist) is fixed by an `except OrderRejected: raise` above it. `Session.reject_unfillable_orders` stays non-throwing per the clock-service save-loop invariant. See `docs/decisions/order-rejected-envelope-contract.md`.

### 5. Session

A session is the top-level container. Each session owns:
- A `user_id` linking it to the authenticated owner
- A simulation clock
- A portfolio
- A reasoning trace log
- Plugin configurations

All API access enforces ownership — users can only read, modify, or delete their own sessions.

**SessionConfig:**
- `start_time`: Simulation start datetime
- `end_time`: Optional simulation end datetime
- `initial_capital`: Starting cash (default: $100,000). Validated to be > 0 at `SessionConfig` creation; raises `ValueError` for zero or negative values.
- `universe`: List of ticker symbols to trade
- `time_step`: Default step interval (e.g., "1d", "1h")
- `plugin_configs`: Per-plugin configuration overrides
- `commission`: 0 for v1
- `slippage_bps`: Slippage in basis points applied at order fill (default: 10 = 0.1%)
- `benchmark_ticker`: Ticker for buy-and-hold benchmark tracking (default: "SPY")
- `public`: Visibility flag (default: `False`). When `True`, the session is exposed read-only and anonymously at `finlet.dev/sessions/<id>` and via the `/v1/public/sessions/{id}/*` route group. Set via the MCP `set_session_visibility` tool or the REST `PATCH /v1/sessions/{id}/visibility` endpoint. The consumer derives the share URL as `https://finlet.dev/sessions/{id}`. See `docs/decisions/session-public-visibility.md`.
- `public_anonymous`: Anonymous display mode (default: `True`). Governs ONLY the `name` field on the public-session response — when `True`, `session.name` is replaced with the literal `"Anonymous Finlet session"`. Owner-supplied positions, orders, equity curve, and reasoning trace are exposed identically regardless of anonymous mode. Owner opts out via `--attributed` on the CLI or `anonymous=False` on the MCP tool / REST PATCH.

**Benchmark tracking:** Equity snapshots include a `benchmark_value` field that tracks SPY (or the configured `benchmark_ticker`) buy-and-hold performance from session start. `PortfolioMetrics` includes `alpha_vs_benchmark` computed as portfolio total return minus benchmark total return. Both `benchmark_return_pct` and `alpha_vs_benchmark` follow the percentage-scale contract above.

**Coverage validation at session creation:** `create_session()` in `session_service.py` validates that `start_time` falls within the available **price** coverage for every ticker in the universe (the fundamentals branch was deleted in the MCP benchmark harness fix — 2026-05-19; see `docs/decisions/mcp-benchmark-fundamentals-coverage.md` D1). Coverage is checked via the `get_ticker_availability()` helper (same S3 manifest rollup as `GET /market/tickers`). Default behavior is **hard reject** — if any ticker's earliest available price date is after `start_time`, session creation fails with `CoverageError` (HTTP 422) containing an actionable per-ticker coverage echo. Opt-in `clamp_to_coverage=True` flag auto-clamps `start_time` forward to the latest `earliest_date` across all tickers (rejects if clamped start would be after `end_time`). The `CoverageError` exception lives in `finlet/errors.py` as part of the `FinletError` hierarchy. Fundamentals coverage is intentionally **not** checked — fundamentals are point-in-time snapshots with no semantic notion of "start date," and the date ceiling enforcer correctly returns empty results for `get_fundamentals(ticker)` queries against ranges the data lake doesn't cover.

Session lifecycle: `CREATED → ACTIVE → PAUSED → ACTIVE → COMPLETED`

**Status guards:** All mutation methods on `Session` (order submission, order processing, clock operations, portfolio updates) raise `SessionNotActiveError` if the session status is not `ACTIVE`. Guards are enforced at the domain layer — the API catches `SessionNotActiveError` and returns HTTP 409 Conflict; the MCP server catches it and returns a structured error message. This prevents corruption of completed sessions' traces, portfolios, and leaderboard submissions.

**Session durability:** Session state — including name, clock position, and trace seal/checksum — fully survives save/load cycles. `save_session()` persists the session name (via `session.name`, not the old `_name` attribute), clock state, and trace seal metadata (`_sealed`, `_checksum`). `persist_session()` in the service layer also writes clock state (current_time, mode). Clock routes (`step_clock`, `step_to_clock`) call `save_session()` after every advance to ensure clock position persists across restarts.

**`end_time` defense-in-depth (MCP_BENCHMARK_FIXES, 2026-05-19 — Team D `7f8f6c7`):** `SessionConfig.end_time: datetime | None = None` allows ad-hoc `create_session()` calls to omit an end_time (intentional for open-ended user-driven sessions); benchmark scenario sessions always have a non-null end_time by construction (`BenchmarkScenario.end_time` is a required non-Optional field, and `create_scenario_session` forwards it). `load_session()` emits a `session_loaded_with_null_end_time` structured warning (with `session_id` + `user_id`) when a session reloads with `end_time is None`, so prod telemetry signals when an agent's report points here next time. Regression locked by `tests/db/test_persistence.py` (round-trip with `end_time` set) and `tests/leaderboard/test_benchmark_state.py` (scenario session save→load preserves end_time). See `docs/decisions/2026-05-19-session-end-time-defense-in-depth.md`.

**Trace sealing:** When `session.complete()` is called (async), it sets status to `COMPLETED` and seals the reasoning trace (finalizes the checksum). Once sealed, no further entries can be appended and the status guard rejects all subsequent mutations. Session lifecycle operations (`start()`, `pause()`, `resume()`, `complete()`) are serialized via an `asyncio.Lock` (`_lifecycle_lock`) to prevent race conditions between concurrent API calls.

### 6. Reasoning Trace

Every interaction is logged with:
- **Action type**: SEARCH, PRICE_QUERY, FUNDAMENTAL_QUERY, FILING_QUERY, ECONOMIC_QUERY, ORDER_SUBMIT, ORDER_FILL, CLOCK_ADVANCE
- **sim_time**: The simulation clock time when the action occurred
- **real_time**: Wall clock time
- **request_params**: What was requested
- **response_summary**: Summary of what was returned
- **reasoning**: Optional agent-provided reasoning text
- **latency_ms**: How long the operation took

**Trace checksum:** The trace computes a rolling SHA-256 checksum for tamper detection on leaderboard submissions. `_compute_checksum()` hashes all 7 `TraceEntry` fields (action_type, sim_time, real_time, request_params, response_summary, reasoning, latency_ms) by serializing each entry via `model_dump()` + `json.dumps(sort_keys=True)`. This ensures the full content of every trace entry is covered, not just timestamps.

---

## Plugin System

### Plugin Interface

Every plugin implements the `DataPlugin` abstract class:

```python
class DataPlugin(ABC):
    plugin_type: str          # "price" | "news" | "fundamentals" | "filings" | "economic" | "sentiment"
    name: str                 # Human-readable name
    requires_api_key: bool
    free_tier_limits: dict    # Rate limit info

    async def initialize(self, config: dict) -> bool: ...
    async def query(self, params: dict, ceiling_time: datetime) -> PluginResponse: ...
    async def health_check(self) -> PluginHealth: ...
```

**Default health check:** The base class provides a default `health_check()` implementation that calls an overridable `_probe()` hook. Plugins that need custom health probing override `_probe()` only; plugins with no special health check requirements inherit the default behavior. This eliminates boilerplate `health_check()` implementations that were previously duplicated across all 5 plugins.

### PluginResponse

```python
@dataclass
class PluginResponse:
    items: list[dict]              # The actual data items
    source: str                    # Plugin name
    query_params: dict             # Echo of query parameters
    ceiling_applied: datetime      # The ceiling time used for filtering
    items_pre_filter: int          # Count before ceiling filter
    items_post_filter: int         # Count after ceiling filter
    rate_limit_remaining: int | None  # Remaining API calls if applicable
    rate_limit_reset: datetime | None # When rate limit resets
    error: str | None              # Structured error (replaces error dicts in items[])
    metadata: dict | None          # Plugin-specific metadata (e.g., attribution)
```

Errors are returned via the `error` field, not as dicts inside `items[]`. The `metadata` field carries plugin-specific context such as attribution strings.

### PluginRegistry

Manages loading and routing queries to the correct plugin by type. Multiple plugins can serve the same type (e.g., multiple news sources).

**Registration order determines priority.** `registry.get_plugin(type)` returns the first plugin registered for that type. This is a first-match resolution — the plugin registered first wins. Current registration order in `app.py:_register_plugins()`:

1. **PricePlugin** (price)
2. **FundamentalsPlugin** (fundamentals) — registered before FinnhubPlugin so S3 Parquet data is the default for fundamentals queries
3. **FinnhubPlugin** (news + fundamentals fallback) — serves as fallback for fundamentals only when S3 data is unavailable
4. **EdgarPlugin** (filings)
5. **EconPlugin** (economic) — registered before FredPlugin so free government APIs are the default
6. **FredPlugin** (economic fallback) — serves series only available via FRED

`PluginRegistry.query_plugin()` is the **single call-site** for all plugin queries in production. It centralizes both retry logic and circuit breaker protection:

1. **Transient error classification** — `_is_transient_error()` distinguishes retryable errors (timeouts, connection errors, 429/502/503/504, rate limits) from permanent errors (bad config, unsupported operations, missing tickers). Permanent errors return immediately without retry.
2. **Retry with exponential backoff** — transient failures are retried up to 3 times with exponential backoff (0.5s, 1.0s, 2.0s base delays). Logged via structlog with attempt number and error type.
3. **Circuit breaker integration** — failure is only recorded after all retries are exhausted; success on any attempt resets the breaker.

`market_service.route_query()`, `clock_service.refresh_prices_and_fill_orders()`, and `trade_service` auto-fill all route through `registry.query_plugin()` (not calling `plugin.query()` directly), ensuring every production query path gets retry + circuit breaker protection.

**Fallback chain skips uninitialized plugins.** When a plugin returns an error, `market_service.route_query()` walks to the next registered plugin of the same type — but only if that plugin's `_initialized` flag is True. Plugins that need configuration (e.g., FinnhubPlugin without `api_key`) are skipped over so their stale init error does not mask the upstream plugin's actual error response. Without this guard, a healthy `FundamentalsPlugin` (S3) error would cascade to an uninitialized `FinnhubPlugin` and surface the misleading `"Finnhub plugin not initialized"` 503 instead of the real S3 error. Test plugins used in fallback-chain tests must set `_initialized = True` in their `__init__` to participate in fallback. Shipped 2026-04-29 (commit `783fe83`, bug-hunt `20260429T232205Z17ff` Team A). Decision record: `docs/decisions/fundamentals-route-provider-override.md`.

**`?provider=` query param escape hatch.** `route_query()` accepts an optional `provider: str | None` argument. When set, it pins dispatch to the named plugin only — no fallback chain runs. `routes_market.get_fundamentals` exposes this as a `?provider=` query param on `GET /v1/sessions/{id}/market/fundamentals`. Useful for diagnosis (force-route around a misbehaving fallback) and for clients that explicitly want `fundamentals_s3` vs `fundamentals_finnhub`. Returns `PluginUnavailableError` (503) if no plugin with that name is registered for the type. The pinned plugin's response — success or error, including init errors from unconfigured plugins — is returned as-is.

**Envelope `status="data_unavailable_at_simtime"` (FUNDAMENTALS_HERO_SAVE, 2026-05-19 — Team C `02d2f73`).** When `_is_terminal_informational_empty_result` returns True (the terminal-informational gate fires for a `fundamentals_s3` post-ceiling-empty response — predicate unchanged), `route_query()` stamps three additional fields on the response envelope: (1) `status="data_unavailable_at_simtime"` — first-class field for agents to pattern-match on; (2) `earliest_available` — ISO-date string parsed from the plugin error tail `"Earliest available filing is YYYY-MM-DD"` via the defensive `_EARLIEST_AVAILABLE_RE` regex (returns `None` when the tail doesn't match, e.g. the gate fired on the "at or before" branch alone); (3) `data_layer` — surfaces `response.metadata["data_layer"]` from Team A's metadata when present (`"canonical"` or `"quarterly"`). When `terminal_empty` is False (normal success OR a genuine plugin error), the envelope is byte-identical to the pre-change contract — `status`, `earliest_available`, and `data_layer` are absent. Agents that pattern-matched on `result["items"]` (empty vs non-empty) or `result["error"]` (string vs absent) continue working unchanged; new agents and bug-report harnesses can pattern-match on `result["status"] == "data_unavailable_at_simtime"` for an unambiguous "data lake doesn't cover this sim time, plugin is healthy" signal. Closes Codex's 2026-05-19 empty-success bug-report ambiguity. Decision record: `docs/decisions/fundamentals-canonical-fallback.md`.

**Per-plugin hot-reload (`PluginRegistry.reload(name, config)` + `POST /v1/plugins/{name}/reload`).** Shipped 2026-05-01 (commit `1a07a1e`, bug-hunt `20260501T172055Z127b` Team A) so `finlet plugins add <name>` no longer needs a server restart on hosted finlet.dev. `PluginRegistry.reload(name, config)` in `finlet/plugins/base.py` re-runs `initialize()` on the existing plugin instance (in-place mutation; the dict slot at `_all_plugins[name]` is never swapped, so concurrent readers either see the pre-reload or post-reload state — never a half-built object), resets the per-plugin circuit breakers (so old failures from the pre-reload config don't keep the breaker open), and serialises concurrent reload calls via a new `asyncio.Lock` (`_reload_lock`). Concurrent readers (`health_check_all`, `query_plugin*`, dashboard's 2s poll) intentionally do NOT take the lock — the same pattern used at startup (`initialize_all`, where the `is_ready` gate exists for global startup readiness; per-plugin reloads do not need that gate because the plugin is already registered). `POST /v1/plugins/{name}/reload` in `finlet/api/routes_health.py` re-reads `~/.finlet/plugins.json`, calls `registry.reload(name, plugin_cfg)`, runs a single `health_check()`, and returns the post-reload `PluginHealthItem`. Returns `404` for unknown plugin names; reload-failure surfaces as `200 + status="unhealthy"` (more actionable than `500` — the CLI can render the live error reason instead of a generic "internal server error"). The CLI's `plugins_add` command (in `finlet/cli.py`) writes the config to `~/.finlet/plugins.json`, POSTs the reload endpoint, and prints the live status from the response — replacing the previous "Plugin '<name>' configured. Restart server to apply." message that was impossible to act on against hosted finlet.dev. See `tests/api/test_plugin_health.py::TestPluginReload` (3 reload-endpoint tests) and `tests/test_cli.py::TestPluginsAddCommand` (4 CLI tests) for the coverage.

#### Plugin config write paths

Two endpoints write plugin state, with a strict role split:

- **`PUT /v1/settings/plugins`** — *canonical write path* for application code (dashboard settings page, CLI `finlet plugins add`, third-party API clients). It owns the per-user config store (`_user_plugin_config` in `finlet/api/services/settings_service.py`), persists the new credentials, and on a credential-bearing change (`api_key` or `email`) calls `await registry.reload(plugin, config)` followed by `await registry.health_check_all()`. The response (`PluginUpdateResponse` in `finlet/api/schemas/settings.py`) carries the post-reload `PluginHealthItem` and a top-level `status` derived from the live health: `HEALTHY → "updated"`, `DEGRADED → "degraded"`, `UNHEALTHY → "unhealthy"`. Older clients that read only `status` continue to work because the success-case string is still `"updated"`; new clients (CLI, new dashboard surfaces) can read `health` and `message` for the live reason without a second round-trip. The route catches `registry.reload`'s exceptions explicitly — there is no blanket `contextlib.suppress(Exception)` masking init failures (see `docs/decisions/refactor/plugin-config-propagation.md` for the rationale).
- **`POST /v1/plugins/{name}/reload`** — *no-config-change kicker* for ops/debug. It does NOT touch the per-user config store; it re-reads `~/.finlet/plugins.json` from disk and re-initialises the named plugin. Useful when the persisted JSON has been edited out-of-band (operator hand-edit) and the registry needs to pick up the new state without a server restart. Application code that owns the credentials MUST go through `PUT /v1/settings/plugins` instead — using `/reload` from app code would silently drop the per-user persistence step.

Multi-user note: the per-user config store is scoped by `user_id`, but EDGAR's `set_identity()` is a global call (the last user to configure their identity wins for all subsequent EDGAR requests). Full per-request identity isolation is out of scope for this iteration and is acknowledged in `update_plugin`'s docstring.

### CircuitBreaker

Circuit breakers are scoped **per `(plugin_name, ticker)` pair**, not per plugin. Each breaker has the same thresholds (5 failures, 60s reset timeout) and state machine (`CLOSED → OPEN → HALF_OPEN`). When a breaker is open, queries for that specific ticker fail fast, but queries for other tickers on the same plugin continue to route normally. `PluginRegistry._circuit_breakers` is a nested dict keyed as `{plugin_name: {ticker: CircuitBreaker}}`. Queries without a ticker (e.g. economic series, macro data) fall back to a per-plugin `__default__` breaker. `get_circuit_breaker(plugin_name, ticker)` is the single lookup helper.

**Rationale:** A single bad symbol (e.g. an MSFT data hole) previously tripped the plugin-wide breaker and blocked every other ticker served by that plugin until the reset timeout. Per-ticker scoping contains failures to the offending symbol while healthy tickers continue to flow.

**Data-absent classification:** Errors indicating the plugin is healthy but has no data for the requested symbol (S3 `NoSuchKey`, `"no data for"`, `"no data available for ticker"`) are classified as **permanent** in `_is_transient_error()` and do NOT count toward the breaker failure count. Retrying cannot fix a missing symbol, so these errors neither retry nor trip the breaker. Only true transient failures (timeouts, 429/5xx, connection errors) count against the failure threshold.

**Reset:** `CircuitBreaker.reset()` resets a single breaker to `CLOSED` (zero failure count). `PluginRegistry.reset_all_circuit_breakers()` walks the nested dict and resets every registered breaker across all plugins and tickers. `create_session()` calls `reset_all_circuit_breakers()` so each new session starts with all plugins in a clean state — a breaker tripped during a previous session does not bleed into the next one.

### Plugin Cache

A separate SQLite database (`~/.finlet/data_cache.db`) caches plugin responses. Cache key is a hash of plugin_type + query_params + ceiling_time (rounded to day for daily data).

TTL rules:
- **Price data**: indefinite
- **News**: 24 hours
- **Filings**: indefinite
- **Economic**: 30 days (until next known revision date)
- **Fundamentals**: 7 days

### Built-in Plugins

| Plugin | Type | Library | API Key | Notes |
|--------|------|---------|---------|-------|
| **PricePlugin** | price | `pyarrow` + `boto3` | AWS credentials | Historical OHLCV from S3 Parquet data lake (Databento DBEQ.BASIC for equities, configurable crypto datasets). Accepts both equity and crypto tickers (e.g., BTC-USD, ETH-USD) — crypto tickers return empty results when no S3 data is available (no rejection). Local file cache after first download. `_read_date_range()` uses `asyncio.gather` for concurrent Parquet downloads across the date range. **EOD bar timestamps use NYSE market close time (16:00 ET)** instead of midnight UTC — this ensures the date ceiling enforcer correctly hides same-day close data during simulated market hours. UTC equivalent is 21:00 UTC (EST) or 20:00 UTC (EDT). **S3 client timeout:** boto3 `Config(connect_timeout=10, read_timeout=30)` prevents stalled S3 downloads from blocking worker threads indefinitely. **Error on empty history:** `_query_history()` now returns an error response when no data is found for the requested ticker/date range, matching `_query_quote()` behavior. Previously it silently returned an empty result. **Health probe (post bug-hunt 20260503T230405Z2601 Team B, supersedes the 20260501T234103Z1a49 Team E real-world-recency loop):** `_probe()` reports HEALTHY when S3 is reachable and ANY parquet exists under the canonical prefix — the disk cache is performance-optional, not a health gate, and the probe is session-time-independent because Finlet sessions evaluate trades against historical partitions that may be months/years stale relative to real-world today. Fast path: cache dir non-empty → HEALTHY (zero S3 calls). Cold-start path: exactly ONE `list_objects_v2(Prefix=f"{self._prefix}/", MaxKeys=1)` against the canonical (unscoped) prefix — answers the right question ("is the data lake populated AT ALL?") rather than the wrong question ("was it ingested in the last N real-world days?"). Result cached on the instance for `PROBE_CACHE_TTL_SECONDS=60` so the dashboard's 2s `/v1/plugins/health` poll does not amplify against AWS. `EndpointConnectionError` / `ClientError` / `BotoCoreError` → DEGRADED with "S3 unreachable" wording (the `routes_health._check_price_data_status` translator maps the substring to `s3_unreachable`). DEGRADED with `"No price data available. Run ingestion first."` is reserved for the genuine "data lake never populated" case (S3 reachable, canonical prefix empty, cache dir empty). The constant `PROBE_RECENT_DAYS = 7` is retained for backwards-compatible test imports but is no longer referenced by the probe. Decision record: `docs/decisions/plugin-health-probe-reachability-only.md`. |
| **EDGAR** | filings | `edgartools` | None (needs User-Agent email) | SEC filings: 10-K, 10-Q, 8-K, 13-F, Form 4. Filter by `filedAt <= ceiling`. **Timeout (30s) + cache integration** for upstream SEC fetches — queries check plugin cache before hitting SEC EDGAR live, and store results on miss. |
| **FRED** | economic | `fredapi` | Free key | GDP, UNRATE, CPI, etc. Use ALFRED vintage dates for point-in-time accuracy. All responses include "Source: [Original Source] via FRED" attribution in `PluginResponse.metadata` (FRED ToS requirement). **Timeout (30s) + cache integration** — observations queries check plugin cache before hitting FRED API live, and store results on miss. |
| **Finnhub** | news + fundamentals | `finnhub-python` | User key | Company news, fundamentals, earnings. Serves both `news` and `fundamentals` plugin types. **Per-user rate limit isolation:** two-tier system — 30 calls/min/user (configurable via `plugin_rate_per_user_per_minute`) with a 150 calls/min global backstop (configurable via `plugin_rate_global_per_minute`). Rate tracking via `check_plugin_rate()` / `record_plugin_request()` / `get_plugin_rate_info()` / `clear_plugin_rate_log()` in `rate_limit.py`. Market data responses include `X-RateLimit-Remaining`, `X-RateLimit-Limit`, and `X-RateLimit-Reset` headers. **Timeout (30s) + cache integration** for company_news queries — checks plugin cache before calling Finnhub API, stores results on miss. |
| **EconPlugin** | economic | `httpx` | None (free gov APIs) | Unified economic data from BLS, BEA, US Treasury, and Fed Board. Routes FRED-compatible series IDs internally to the correct agency. Not yet registered as default — FRED remains the active economic source. Split into 3 modules: `econ_plugin.py` (main plugin class), `econ_sources.py` (data source definitions), `econ_fetchers.py` (individual data fetcher implementations). |
| **FundamentalsPlugin** | fundamentals | `pyarrow` + `boto3` | AWS credentials | Quarterly financial statements from S3 data lake (income statement, balance sheet, cash flow). Dual-table read: canonical data (default) from `fundamentals/canonical/`, raw data from `fundamentals/quarterly/`. Supports the expanded schema with `accession_number`, `form_type`, `is_amendment`, and `is_financial_firm` columns (gracefully handles old-schema parquets by defaulting missing columns). Financial firm routing: loads `scripts/financial_firms.json` to tag 66 financial tickers, applies bank-specific concept mappings, and rejects non-applicable concept queries with actionable errors. Ceiling timestamp is `filed_at`. Additive to FinnhubPlugin's `fundamentals` type — Finnhub provides real-time company profiles; this plugin provides point-in-time quarterly financials. Actions: `financials` (time series), `latest` (most recent filing). **Cache invalidation:** local Parquet cache files are invalidated if older than 24h (`CACHE_TTL_SECONDS`) or 0 bytes; stale/empty files are deleted and re-downloaded on next access. **Atomic downloads:** `_download_from_s3()` writes to a `.parquet.tmp` file and atomically renames on success, so mid-flight failures never leave partial/0-byte files; any leftover `.tmp` is cleaned up on failure. |
| **NewsPlugin** | news | `pyarrow` + `boto3` | AWS credentials | Historical news headlines from S3 data lake. Date-partitioned Parquet files (one per day, all tickers). Ceiling timestamp is `published_at`. Actions: `headlines` (date-range query), `latest` (most recent N headlines). Concurrent date-file downloads via `asyncio.gather`. |
| **SentimentPlugin** | sentiment | `pyarrow` + `boto3` | AWS credentials | Analyst ratings, upgrades/downgrades, and price targets from S3 data lake. One Parquet file per ticker. Ceiling timestamp is `rated_at`. Actions: `ratings` (date-range query), `consensus` (latest rating per firm), `price_targets` (items with price targets). |

### Error Messages

All error messages to agents must be **specific and actionable**. Examples:
- Good: `"Finnhub rate limit exceeded: 0/60 calls remaining, resets in 42 seconds"`
- Bad: `"API error"`
- Good: `"PricePlugin: No data available for ticker 'INVALID'. Check ticker symbol against supported universe"`
- Bad: `"Data not found"`

**No infra topology in user-facing copy.** Plugin error strings (and any user-facing message that surfaces upstream-failure context) MUST NOT contain bucket names, `s3://` URIs, env-suffixed identifiers (e.g. `finlet-data-cccdea31`), IAM role ARNs, file paths under `/opt`, region codes, IP addresses, or any other infrastructure identifier. Operators get the full context via `structlog.bind(bucket=..., key=...)` structured logs (preserved in all S3-backed plugins); users get an actionable but topology-free summary. Sanitization shipped 2026-05-02 in bug-hunt `20260502T142726Z7b36` Team B (commit `ad0adb0`) across `finlet/plugins/{price,news,fundamentals}_plugin.py`. **Translator-stability corollary:** when a sanitized phrase is consumed by a downstream layer for keying (the `routes_health._check_price_data_status` translator maps the literal substring `"S3 unreachable"` → `s3_unreachable`), the wording is a fixed convention — pin it as part of the response contract rather than ad-hoc strings. Same rule applies to error-string sanitization in any new plugin or upstream-failure path. Decision record: `docs/decisions/probe-message-sanitization-translator-coupling.md`.

---

## Data Pipeline

### Overview

Finlet's data pipeline ingests market data from external sources, normalizes it into Parquet files on S3, and serves it to agents through plugins with date ceiling enforcement. The pipeline is designed so that swapping data providers requires changing only the ingestion module -- S3 schemas, plugins, the enforcer, and all downstream code remain unchanged.

```
                         Ingestion (offline)                    Serving (runtime)
                    +--------------------------+         +---------------------------+
                    |                          |         |                           |
  yfinance -------->  Ingestion Scripts        |         |  Plugins (S3 Parquet)     |
  SEC EDGAR ------->  (ingest_yfinance_       |         |  - PricePlugin            |
  (companyfacts)   |   prices.py,             |         |  - FundamentalsPlugin     |
  (or future       |   ingest_edgar_          |         |    (raw + canonical)      |
   provider)       |   fundamentals.py,       |         |  - NewsPlugin             |
                    |   build_canonical.py)    |         |  - SentimentPlugin        |
                    |         |                |         |         |                 |
                    |         v                |         |         v                 |
                    |  S3 Data Lake            |         |  Date Ceiling Enforcer    |
                    |  (Parquet files)  -------+-------->+         |                 |
                    |                          |         |         v                 |
                    +--------------------------+         |  Agent (via API/MCP)      |
                                                         +---------------------------+
```

**Data flow:** `yfinance / SEC EDGAR / FRED --> Ingestion Scripts --> S3 Parquet --> Plugins --> Enforcer --> Agent`

### Ingestion Framework (`finlet/ingestion/`)

The ingestion framework provides a swappable provider interface. Implementing a new data source means creating one class that implements `DataIngester`.

**`DataIngester` ABC** (`finlet/ingestion/base.py`):

```python
class DataIngester(ABC):
    name: str

    async def fetch_bulk(self, tickers: list[str], start: date, end: date) -> tuple[pa.Table, IngestionResult]: ...
    async def fetch_daily(self, tickers: list[str], target_date: date) -> tuple[pa.Table, IngestionResult]: ...
    def get_supported_asset_classes(self) -> list[AssetClass]: ...

    @staticmethod
    def canonical_schema() -> pa.Schema:
        """date: date32, ticker: string, open/high/low/close: float64, volume: int64"""

    def validate_table(self, table: pa.Table) -> pa.Table:
        """Validates required columns and casts to canonical schema."""
```

Key design points:
- All providers must produce the canonical Parquet schema (enforced by `validate_table()`)
- Providers handle rate-limiting internally (throttle, backoff)
- Errors are classified as transient (retry with exponential backoff) vs. permanent (skip + log)
- All blocking I/O wrapped in `asyncio.to_thread()`

**`YFinanceProvider`** (`finlet/ingestion/yfinance_provider.py`):
- Interim data source for pre-revenue operation ($0/month)
- Supports US equities, ETFs, and crypto
- Batches tickers in groups of 950 with 2s cooldown between batches
- Retries transient errors up to 3 times with exponential backoff (1s, 2s, 4s)
- Normalizes yfinance's DataFrame format (single-ticker flat columns, multi-ticker MultiIndex columns) into canonical Arrow schema

**`S3ParquetWriter`** (`finlet/ingestion/s3_writer.py`):
- Partitions tables by date and uploads one Parquet file per date
- Integrity check: every upload is verified via round-trip read before writing to S3
- Retries transient S3 errors up to 3 times; non-retryable errors (AccessDenied, InvalidSecurity, etc.) fail immediately
- Default S3 prefix: `prices/daily`
- **Ticker-coverage ratchet guard (FUNDAMENTALS_HERO_SAVE, 2026-05-19 — Team B `1c1939c`).** `upload_to_key()` accepts an `allow_shrink: bool = False` kwarg. When `emit_manifest=True`, the supplied `coverage` is a `CoverageTicker`, and the target parquet key already exists in S3, the writer reads the existing `{key}.manifest.json` sidecar via `_read_existing_manifest()` and compares `existing.coverage.period_start` against the new `coverage.period_start`. If the new value is later (the write would shrink historical coverage) AND `allow_shrink=False`, the writer raises `CoverageShrinkError` BEFORE the parquet PUT — no bytes land. Equal/wider coverage proceeds normally with structured-log breadcrumbs at `s3_writer.ratchet.{accepted, widened, shrink_allowed, manifest_read_failed}`. **FAIL CLOSED on manifest-read error:** any S3 error other than `NoSuchKey`/`404` raises `CoverageShrinkError` rather than silently proceeding; operators opt into overwriting with `--allow-shrink`. First-write paths (no existing parquet key) skip the manifest read entirely. The ratchet applies ONLY to `CoverageTicker` — `CoverageDate` / `CoverageSeries` / `CoverageSingleton` writes flow through unchanged because their shrinkage semantics differ (daily-delta re-runs legitimately overwrite the same `{date}.parquet`, not a category error). `scripts/ingest_fundamentals.py` surfaces the kwarg as a `--allow-shrink` CLI flag with a prominent `structlog.warning` + stderr banner when enabled. Closes the 2026-05-18 launch-day clobber root cause. Decision record: `docs/decisions/fundamentals-canonical-fallback.md`.

### S3 Data Lake Schema

All data lives in a single S3 bucket (`finlet-data`). Data types use different partitioning strategies based on their access patterns.

#### Prices (`prices/daily/`)

One Parquet file per trading day, containing all tickers.

**S3 path:** `prices/daily/{YYYY-MM-DD}.parquet`

**Parquet schema:**
| Column | Type | Description |
|--------|------|-------------|
| `date` | `date32` | Trading date |
| `ticker` | `string` | Ticker symbol (e.g., "AAPL", "BTC-USD") |
| `open` | `float64` | Opening price |
| `high` | `float64` | Highest price |
| `low` | `float64` | Lowest price |
| `close` | `float64` | Closing price |
| `volume` | `int64` | Trading volume |

**Enforcer timestamp:** EOD bars use NYSE market close time (16:00 ET / 20:00-21:00 UTC depending on DST). Set at read time in PricePlugin, not stored in Parquet. See [price-close-timestamps.md](decisions/price-close-timestamps.md).

**Ingestion script:** `scripts/ingest_yfinance_prices.py`
- Modes: `bulk` (2010-present, month-by-month chunks), `daily` (yesterday)
- Ticker lists: `scripts/ticker_lists/us_equities.txt` (~238 tickers), `us_etfs.txt` (~96), `crypto_pairs.txt` (~60)
- Asset classes selectable via `--asset-classes equities,etfs,crypto`

#### Fundamentals — Raw (`fundamentals/quarterly/`)

One Parquet file per ticker, containing all quarterly filings (income statement, balance sheet, cash flow). Two ingestion paths exist: the legacy yfinance script and the new SEC EDGAR companyfacts bulk script.

**S3 path:** `fundamentals/quarterly/{TICKER}.parquet`

**Parquet schema (expanded):**
| Column | Type | Description |
|--------|------|-------------|
| `ticker` | `string` | Ticker symbol |
| `accession_number` | `string` | SEC EDGAR accession number (unique per filing) |
| `form_type` | `string` | SEC form type (e.g., "10-K", "10-Q") |
| `filed_at` | `timestamp[us, tz=UTC]` | SEC filing date (actual from EDGAR, or estimated period_end + 45 days for legacy) |
| `period_end` | `date32` | Fiscal quarter/year end date |
| `statement_type` | `string` | `income_statement`, `balance_sheet`, or `cash_flow` |
| `field_name` | `string` | us-gaap tag name (e.g., "Revenues", "NetIncomeLoss") |
| `value` | `float64` | Metric value in USD |
| `currency` | `string` | Currency code (always "USD" for v1) |
| `is_amendment` | `bool` | True if the filing is an amended re-statement |
| `is_financial_firm` | `bool` | True for financial sector tickers (JPM, BAC, GS, etc.) |

**Point-in-time correctness:** Original + amended filings are preserved, keyed on `(accession_number, filed_at)`. The plugin filters by `filed_at` (not `period_end`) to ensure agents see filings only after their SEC publication date. Amendments are included with `is_amendment=True` so agents can see corrections as they become available.

**Financial firm tagging:** 66 financial sector tickers are tagged via `scripts/financial_firms.json`. These tickers receive bank-specific canonical concepts (e.g., `net_interest_income`) and skip non-applicable corporate concepts (e.g., `cost_of_revenue`).

**Enforcer timestamp:** `filed_at` is the timestamp key. The enforcer auto-detects `filed_at` for ceiling filtering, ensuring agents cannot see filings before their SEC publication date.

**Ingestion scripts:**

1. `scripts/ingest_edgar_fundamentals.py` (primary, SEC EDGAR)
   - Downloads the bulk `companyfacts.zip` (~1GB) from SEC EDGAR — sidesteps the 10 req/s rate limit
   - Parses JSON per CIK, maps CIK to tickers via `company_tickers.json`
   - Stores ALL us-gaap tags raw with the expanded schema above
   - Per-CIK checkpoints to S3 for resumable backfill
   - Modes: `bulk` (all tickers from companyfacts ZIP)
   - Supports `--tickers`, `--dry-run`, `--skip-download`

2. `scripts/ingest_fundamentals.py` (legacy, yfinance)
   - Modes: `bulk` (all available quarters), `daily` (refresh to pick up new filings)
   - Default universe: top 10 tickers (expand via `--tickers`)
   - Filing date estimation: `filed_at = period_end + 45 days` (the SEC 10-Q deadline for large accelerated filers)

#### Fundamentals — Canonical (`fundamentals/canonical/`)

Normalized view of raw fundamentals, mapping ~32k us-gaap tags down to 29 agent-facing canonical concepts (plus 15 bank-specific concepts). Built by an offline ETL script; served by the FundamentalsPlugin as the default query path.

**S3 path:** `fundamentals/canonical/{TICKER}.parquet`

**Canonical concept layer:**
- `finlet/data/canonical_concepts.json` — 29 agent-facing concepts (e.g., `revenue`, `net_income`, `total_assets`, `operating_cash_flow`) with their associated us-gaap tag mappings
- `finlet/data/bank_concepts.json` — 15 bank-specific concepts (e.g., `net_interest_income`, `provision_for_credit_losses`, `total_deposits`) that override or supplement canonical concepts for financial firms
- `finlet/data/gaap_mappings.json` — Vendored from `edgartools` (MIT license, 234 canonical concepts from 32k filings). Source mappings for the canonical concept layer. See `finlet/data/ATTRIBUTION.md`

**Build script:** `scripts/build_canonical.py`
- Reads raw `fundamentals/quarterly/{TICKER}.parquet` from S3/cache
- Maps `field_name` via canonical + bank concept JSON definitions
- Writes to `fundamentals/canonical/{TICKER}.parquet`
- Modes: `bulk` (all tickers in raw prefix), per-ticker via `--tickers`
- Supports `--dry-run`, `--no-skip-existing`

**Plugin routing:** The FundamentalsPlugin defaults to `canonical=True`. When canonical data is requested, it reads from the canonical prefix and applies the bank-concept routing for financial firm tickers. Raw data is available via `canonical=False` in query params. Non-applicable concept queries for financial firms (e.g., requesting `cost_of_revenue` for JPM) return an actionable error.

**Canonical-as-fallback contract (FUNDAMENTALS_HERO_SAVE, 2026-05-19 — Team A `34e0fa3`).** `_query_canonical_financials` and `_query_canonical_latest` now call `_read_canonical_data(ticker, force_s3=True)` unconditionally — the previous `force_s3=bool(concept)` gate is gone. The new semantics: canonical S3 is always attempted; if canonical returns rows post-ceiling, they serve the request with `PluginResponse.metadata = {"data_layer": "canonical"}`. If canonical returns nothing post-ceiling AND the caller did not pass an SEC `concept`, the fallback falls through to the quarterly raw-data path and stamps `metadata = {"data_layer": "quarterly"}` via `model_copy(update={"metadata": ...})`. If the caller DID pass a `concept` and canonical has no usable rows, the existing canonical-empty error template (`"No canonical filings for '{ticker}' at or before … Earliest available filing is YYYY-MM-DD."`) is preserved verbatim so `market_service._is_terminal_informational_empty_result`'s substring match still fires. `PluginResponse.source` stays `"fundamentals_s3"` for both layers (the gate's source-string equality check requires it). Canonical-served items are normalized via `_normalize_canonical_items` to expose BOTH `concept` and `field_name` keys — a 15-entry `_CANONICAL_CONCEPT_TO_FIELD_NAME` mapping covers the most common concepts (`revenue → total_revenue`, `net_income → net_income`, `net_interest_income → net_interest_income`, etc.); unmapped concepts default to `field_name = concept`. Mapping is additive — the original `concept` key is preserved on every normalized item. Closes the 2026-05-18 launch-day quarterly clobber + Codex's empty-success repro at sim 2023-10-02 for the default-universe tickers. Decision record: `docs/decisions/fundamentals-canonical-fallback.md`.

#### News (`news/daily/`)

One Parquet file per day, containing all tickers' headlines for that day.

**S3 path:** `news/daily/{YYYY-MM-DD}.parquet`

**Parquet schema:**
| Column | Type | Description |
|--------|------|-------------|
| `ticker` | `string` | Ticker symbol |
| `published_at` | `timestamp[us, tz=UTC]` | Article publication timestamp |
| `title` | `string` | Headline (max 500 chars) |
| `summary` | `string` | Article summary (max 1000 chars) |
| `source` | `string` | Publisher name (max 200 chars) |
| `url` | `string` | Article URL (max 500 chars) |

**Enforcer timestamp:** `published_at` is the timestamp key. The NewsPlugin filters to `published_at <= ceiling_time`.

**Ingestion script:** `scripts/ingest_news.py`
- Modes: `bulk` (all available news), `daily` (yesterday)
- Default universe: 25 equities + 3 crypto tickers
- `--coverage-report` mode: fetch and print stats without uploading

#### Sentiment (`sentiment/recommendations/`)

One Parquet file per ticker, containing all analyst recommendations and upgrades/downgrades.

**S3 path:** `sentiment/recommendations/{TICKER}.parquet`

**Parquet schema:**
| Column | Type | Description |
|--------|------|-------------|
| `ticker` | `string` | Ticker symbol |
| `rated_at` | `timestamp[us, tz=UTC]` | Recommendation date |
| `firm` | `string` | Analyst firm name |
| `action` | `string` | `upgrade`, `downgrade`, `maintained`, `initiated`, `reiterated` |
| `from_grade` | `string` (nullable) | Previous rating grade |
| `to_grade` | `string` (nullable) | New rating grade |
| `price_target` | `float64` (nullable) | Price target (when available) |

**Enforcer timestamp:** `rated_at` is the timestamp key. The SentimentPlugin filters to `rated_at <= ceiling_time`.

**Ingestion script:** `scripts/ingest_sentiment.py`
- Modes: `bulk` (all available history), `daily` (latest recommendations)
- Default universe: top 50 US equities

#### Sectors (`reference/sectors/`)

One-time reference data: GICS sector and industry classifications for all tickers. Not part of the daily pipeline.

**S3 path:** `reference/sectors/{TICKER}.parquet` or `reference/sectors/all.parquet`

**Ingestion script:** `scripts/ingest_sectors.py`
- One-time bulk ingestion (not scheduled daily)
- Maps tickers to GICS sectors and industries

#### FRED Economic Indicators (`economic/fred/`)

Macroeconomic time series from the Federal Reserve Economic Data (FRED) API.

**S3 path:** `economic/fred/{SERIES_ID}.parquet`

**Ingestion script:** `scripts/ingest_fred.py`
- Modes: `bulk` (full history), `daily` (latest values)
- Series include GDP, CPI, unemployment rate, federal funds rate, treasury yields, etc.

#### EDGAR SEC Filings (`edgar/`)

SEC filing data from the EDGAR system. Three data types with separate sub-paths.

**S3 paths:**
- `edgar/filings/{TICKER}.parquet` — SEC filings (10-K, 10-Q, 8-K)
- `edgar/insider/{TICKER}.parquet` — Insider transactions (Form 4)
- `edgar/institutional/{TICKER}.parquet` — Institutional holdings (13-F)

**Ingestion script:** `scripts/ingest_edgar.py`
- `--data-type filings` — SEC filings (daily, weekdays)
- `--data-type insider` — Insider transactions (daily, weekdays)
- `--data-type institutional` — Institutional holdings (quarterly, but checked daily)

### Daily Delta Pipeline

The daily pipeline runs all ingestion types sequentially, with failure isolation.

**Orchestrator:** `scripts/ingest_daily.py`
- Runs each ingestion script as a subprocess to isolate failures (one type failing does not block others)
- Execution order: prices, fundamentals, news, sentiment, fred, edgar_filings, edgar_insider, edgar_institutional
- Weekend mode (`--skip-weekday-types`): skips weekday-only types (prices, fundamentals, fred, edgar_filings, edgar_insider), runs news, sentiment, and edgar_institutional
- Script paths may include inline arguments (e.g., `scripts/ingest_edgar.py --data-type filings`), split via `shlex` before subprocess execution
- Exit code = number of failures

**CI Cron:** `.github/workflows/ingest-daily.yml`
- Weekdays at 2:00 AM UTC: all data types
- Weekends at 2:00 AM UTC: non-weekday types only (news, sentiment, edgar_institutional)
- Manual trigger via `workflow_dispatch` with optional `skip_weekday_types`
- AWS credentials via OIDC (`id-token: write`)
- Failure alert via webhook (`ALERT_WEBHOOK_URL` secret)

**IAM:** `deploy/aws/iam-ingestor.tf`
- Dedicated `finlet-ingestor` IAM user with write-only S3 access
- Scoped to 7 path prefixes: `prices/daily/*`, `fundamentals/*` (covers both `quarterly/` and `canonical/`), `news/daily/*`, `sentiment/daily/*`, `reference/*`, `economic/*`, `edgar/*`
- ListBucket permission for prefix enumeration
- Programmatic access keys (migrate to Lambda execution role post-v1)

### S3 Plugin Architecture

All 4 S3-backed plugins follow the same pattern:

1. **Lazy S3 client** -- boto3 client created on first use (`_get_s3_client()`), allowing the plugin to initialize without AWS credentials (for local development)
2. **Local cache** -- Parquet files downloaded from S3 are cached locally under `~/.finlet/cache/{type}/` after first access
3. **Ceiling filtering** -- Each plugin applies its own timestamp filter (`close_time`, `filed_at`, `published_at`, `rated_at`) before returning results. The Date Ceiling Enforcer re-filters as defense-in-depth.
4. **Actionable errors** -- S3 failures produce specific error messages. The FundamentalsPlugin further classifies the failure cause (MCP_BENCHMARK_FIXES, 2026-05-19 — Team C `3098ac8`): `_download_from_s3()` now returns a typed `S3DownloadResult(ok, error_kind, error_message)` where `error_kind` is one of `none`, `no_credentials`, `no_such_key`, `connection_error`, or `other`. The caller (`_classify_s3_failure_error` / `_classify_no_data_error`) distinguishes ETFs (via `is_known_etf()` against `KNOWN_ETF_TICKERS` in `finlet/plugins/base.py` — 22 most-traded US ETFs) from non-ETF unknown tickers and from real infra failures, so an agent querying `SPY` for fundamentals gets "fundamentals not applicable for ETFs; use get_price_data" rather than the misleading "Check network connectivity and AWS credentials" message that the legacy catch-all still emits for actual infra failures. See `docs/decisions/2026-05-19-fundamentals-etf-and-s3-error-classification.md`.

| Plugin | Class | Type | Timestamp Key | Partition | Cache Path |
|--------|-------|------|---------------|-----------|------------|
| PricePlugin | `PricePlugin` | `price` | close time (16:00 ET) | By date | `~/.finlet/cache/prices/` |
| FundamentalsPlugin | `FundamentalsPlugin` | `fundamentals` | `filed_at` | By ticker | `~/.finlet/cache/fundamentals/` (raw), `~/.finlet/cache/canonical/` (canonical) |
| NewsPlugin | `NewsPlugin` | `news` | `published_at` | By date | `~/.finlet/cache/news/` |
| SentimentPlugin | `SentimentPlugin` | `sentiment` | `rated_at` | By ticker | `~/.finlet/cache/sentiment/` |

### Partition Completeness Invariant

Every S3 Parquet write is paired with a sidecar JSON manifest at `{parquet_key}.manifest.json`. The manifest declares what the partition contains (row count, schema hash, parquet sha256, coverage); consumers in STRICT mode fail closed on missing or mismatched manifests. This closes the silent-corruption gap where `put_object` atomicity made "object exists" look like "partition complete."

- **Producers** funnel through `S3ParquetWriter` (`finlet/ingestion/s3_writer.py`) and supply a `Coverage*` instance describing the partition they wrote. Writers are: `upload_date_partition`, `upload_partitioned`, `upload_to_key` (for ticker / series / singleton layouts). Direct `s3_client.put_object` is banned in ingest paths.
- **Consumers** call `validate_partition(s3_client, bucket, parquet_key, local_parquet_path, mode)` from `finlet/ingestion/manifest_reader.py` after download. Checks in order: manifest presence, `parquet_sha256`, `row_count`, `schema_hash`.
- **Mode switch:** `FINLET_PARTITION_VALIDATION=OFF|WARN|STRICT` (default `OFF`), read at process start through `settings.ingestion.partition_validation_mode`. `OFF` skips; `WARN` logs structured `partition_validation_failed` events; `STRICT` raises `PartitionValidationError`.
- **Retroactive backfill:** `scripts/backfill_manifests.py` walks an existing S3 prefix and emits manifests with `retroactive=True`. Consumers can distinguish verified-at-write from reconstructed manifests.

See [partition-completeness-invariant.md](decisions/partition-completeness-invariant.md) for the full decision record and rollout plan.

### Migration Path: yfinance to Licensed Providers

yfinance is the interim data source for pre-revenue operation. When revenue justifies licensed data:

1. Implement a new `DataIngester` subclass (e.g., `PolygonProvider`, `FinnhubBusinessProvider`) in `finlet/ingestion/`
2. Update ingestion scripts to instantiate the new provider
3. Re-run bulk ingestion to backfill S3 with higher-quality data
4. **Nothing else changes** -- S3 Parquet schemas, all 4 plugins, the Date Ceiling Enforcer, the API, MCP tools, and the dashboard are provider-agnostic

See [yfinance-data-source.md](decisions/yfinance-data-source.md) for cost rationale and [parquet-partitioning.md](decisions/parquet-partitioning.md) for the partitioning scheme decision.

---

## API Layer

### REST API (FastAPI)

#### MCP as Canonical Surface (Phase 3 — 2026-05-08)

Per Phase 3 of the MCP-First Migration (decision record: `docs/decisions/mcp-canonical-surface.md`), MCP is the canonical agent surface for Finlet; REST is the human/operations layer (dashboard, SSE, webhooks, `/health`, OpenAPI mirror, browser auth). REST agent-CRUD routes are sunsetting on `2026-08-06` (90 days from 2026-05-08); the keep-list (auth, webhooks, SSE, ops/health, public legal, telemetry, admin, async job acceptance, OpenAPI mirror, public reads) emits no deprecation signal. The full keep-list policy — exact paths, prefixes, patterns, exceptions, and the REST→MCP tool mapping — is path-scoped in `.claude/rules/api-routes.md` and code-canonical in `finlet/api/deprecation.py`.

#### OAuth 2.1 Authorization Server (Phase 4b — 2026-05-08)

Per Phase 4b of the MCP-First Migration (decision record: `docs/decisions/mcp-oauth-2-1-auth-model.md`), Finlet runs its **own** OAuth 2.1 Authorization Server in-process alongside the FastAPI app. This is the canonical agent auth surface for paid GA — replacing the MCP-spec-forbidden "API key as tool argument" (token-passthrough) pattern. Current hosted `/mcp` accepts OAuth JWT Bearer first and Bearer `fnlt_*` API keys as a compatibility path; legacy tool-argument `api_key=...` remains rejected.

**Endpoints** (mounted on the main FastAPI app via `finlet/auth/oauth/router.py`; `/oauth/` added to `_KEEP_PREFIXES` in `finlet/api/deprecation.py` per the drift policy at `finlet/api/deprecation.py:28-31`, mirrored in `.claude/rules/api-routes.md`):
- `GET /oauth/.well-known/oauth-authorization-server` — RFC 8414 metadata document
- `GET /oauth/jwks` — RFC 7517 JSON Web Key Set (current public signing keys for token verification)
- `GET /oauth/authorize` — RFC 6749 authorization endpoint; PKCE-S256 mandatory (`plain` rejected); Resource Indicator (RFC 8707) `resource=https://finlet.dev/mcp` required byte-for-byte; user consent via cookie session (the human is logging in here, not the agent). `_redirect_uri_matches()` in `finlet/auth/oauth/authorize.py` performs exact-string match for HTTPS redirects, and **RFC 8252 §7.3 wildcard-port match** for `http://127.0.0.1` / `http://localhost` / `http://[::1]` (v1.0.0 BLOCKER #2 — 2026-05-11): a registered `http://127.0.0.1` redirect matches any `http://127.0.0.1:<port>/...` callback URL, so the CLI's ephemeral-port loopback listener can register a single fixed seed row.
- `POST /oauth/token` — RFC 6749 token endpoint; supports `grant_type=authorization_code` (with PKCE verifier check) and `grant_type=refresh_token` (single-use rotation); mints 15-minute EdDSA Ed25519 JWT access tokens (RFC 9068) + opaque 256-bit refresh tokens (90-day absolute / 30-day sliding lifetime)
- `POST /oauth/register` — RFC 7591 §3 Dynamic Client Registration; **open** by default with rate-limit (10/hour/IP, 100/day global), exact-match HTTPS redirect-URI validation, mandatory PKCE-S256, and `authorization_code`+`refresh_token` grant-type allowlist; self-hosted operators may flip to allowlist mode via `FINLET_OAUTH_DCR_ALLOWLIST_ONLY=1` env var

**Storage** (auth.db / `default` chain, migrations `014_add_oauth_clients.py` + `015_seed_finlet_cli_client.py`): 4 tables —
- `oauth_clients` — DCR client metadata per RFC 7591 §2 (`client_id`, `client_secret_hash`, `client_name`, `redirect_uris`, `grant_types`, `response_types`, `token_endpoint_auth_method`, `scope`, `software_id`, `software_version`, etc.). Migration `015_seed_finlet_cli_client.py` (v1.0.0 BLOCKER #2 — 2026-05-11) seeds the `finlet-cli` public client row (no secret, PKCE-only, `token_endpoint_auth_method = "none"`) with a wildcard loopback redirect URI `http://127.0.0.1` so `finlet auth login` can complete the Authorization Code flow on first install without manual DB priming.
- `oauth_authorizations` — one row per authorization-code grant (`code`, `code_challenge`, `code_challenge_method`, `client_id`, `user_id`, `redirect_uri`, `resource`, `scope`, `expires_at`, `consumed_at`)
- `oauth_refresh_tokens` — one row per refresh token (`token_hash`, `client_id`, `user_id`, `scope`, `resource`, `created_at`, `expires_at`, `revoked_at`); rotated on each refresh, single-use enforced
- `oauth_keys` — persisted EdDSA Ed25519 signing keys with 90-day rotation cadence and 30-day overlap (added in B1 per decision record §5; not in the original 3-table plan text — scope drift authorized)

**Token strategy** — 15-min EdDSA Ed25519 JWT (RFC 9068, `iss`/`aud`/`sub`/`exp`/`nbf`/`scope`/`client_id`/`resource` claims; `aud == "https://finlet.dev/mcp"` required; `sub == UserRecord.id` per decision record §4 — OAuth tokens resolve to the SAME `UserRecord` as API keys, no separate identity store) + opaque 256-bit refresh hashed at rest, single-use rotation, 90-day absolute / 30-day sliding lifetime. CLI persists at `~/.finlet/credentials` mode 0600 and the v2 stdio bridge refreshes near expiry before forwarding to hosted `/mcp`.

**Identity binding** (per decision record §4): OAuth tokens carry `sub = UserRecord.id`, so the existing `auth_service.get_by_id(...)` flow resolves both Bearer-JWT and api_key callers to the same user. MFA, password rotation, key rotation, and tier all carry over — no fork in the identity store.

**Scope model** (Phase 4c enforces — see "OAuth 2.1 Resource Server" subsection below): `finlet:read`, `finlet:trade`, `finlet:benchmark`, `finlet:admin`. Per the locked contract in `docs/decisions/mcp-api-key-sunset.md`, scopes are additional gates **inside** a tier — a tier's billing/usage gating runs first (REST + MCP both), and the scope check (`enforce_scope` in `finlet/mcp/auth.py`) is layered on top for OAuth-authenticated calls; tier does NOT veto scope and scope does NOT veto tier. Bearer `fnlt_*` API keys resolve with `claims=None` and bypass OAuth scope checks by compatibility contract; tier-based service gates still apply via the resolved `UserRecord`.

**OAuth library**: `mcp[auth]>=1.27.0` (Anthropic-shipped `OAuthAuthorizationServerProvider` scaffold) + `joserfc>=1.0` (JWT signing/verification). `authlib` was rejected per decision record §3 due to Flask/Django-only AS support and an open RFC 8707 issue since 2023.

#### OAuth 2.1 Resource Server (Phase 4c → v2 stdio bridge)

The hosted MCP server is an OAuth 2.1 Resource Server in front of the AS shipped in Phase 4b. **Authentication Precedence:** the MCP transport accepts `Authorization: Bearer ...`; OAuth JWT is preferred, and Bearer `fnlt_*` API keys remain accepted for headless/compatibility flows. The legacy tool-argument `api_key=...` shape is rejected. The REST surface (`/v1/...`, plus deprecated unversioned aliases where they still exist) is unchanged and continues to accept api_key (`X-API-Key` / `Authorization: Bearer <api_key>`) + cookie session as before.

**Phase 4e (2026-05-09) rejected legacy tool-argument api_keys; v1.0.1 re-opened Bearer api_key compatibility.** `resolve_credential()` still returns `_API_KEY_REJECTED_MESSAGE` when `api_key=...` is the only credential, but `_authenticate_oauth_or_key()` falls back to `auth_service.validate_key()` when the Bearer token is not a valid OAuth JWT. The current contract is documented in `docs/MCP_OAUTH_MIGRATION.md`.

**Bearer resolver** (`finlet/mcp/auth.py:_authenticate_oauth_or_key`): every authenticated MCP tool routes through one resolver that takes a single Bearer token string (with optional `"Bearer "` prefix, case-insensitive) and returns `(user_id, auth_method, claims)` on success. OAuth JWT success returns `AUTH_METHOD_OAUTH` with non-None `OAuthClaims`; Bearer `fnlt_*` API key success returns `AUTH_METHOD_BEARER` with `claims=None`. Failure modes (missing input, validator/key lookup miss, sub doesn't resolve to a UserRecord) raise `ValueError("Authentication required. ...")` with the canonical wording closed-beta clients pattern-match on. The legacy `_authenticate(api_key)` primitive is preserved at `finlet/mcp/auth.py` for non-MCP callers (REST surface, CLI's `--api-key` verification mode, a handful of unit tests).

**JWT validator** (`finlet/auth/oauth/jwt_validator.py:validate_bearer_jwt`): wraps `joserfc.jwt.decode` with `algorithms=["EdDSA"]` (the `none`/HS\*/RS\* allowlist gap is closed at this layer — joserfc rejects mismatched algorithms before claim parsing). The validator builds an in-process `joserfc.jwk.KeySet` from `storage.list_keys_for_jwks()` (the same source the AS `/oauth/jwks` endpoint serves), enforces `header.kid` is present and resolves to a known key (joserfc otherwise silently picks the first key in the keyset), and validates `iss == ISSUER`, `aud == "https://finlet.dev/mcp"` (byte-equal — must match the Resource Indicator the AS minted the token for), `exp`, `nbf`, and `scope subset`. Failures return `None` and emit a `oauth_jwt_validation_failed` structlog with a stable `reason` field; the raw token is never logged.

**Bearer extraction** (`finlet/mcp/bearer_context.py:BearerContextMiddleware`): an ASGI middleware writes the incoming HTTP `Authorization: Bearer <token>` into a `ContextVar` so FastMCP tool bodies (which only receive the named tool parameters) can read it via `_extract_bearer_from_context()` without a transport-coupled function signature. The read-side `resolve_credential(tool_name, bearer, api_key) -> tuple[str, str, OAuthClaims | None] | dict[str, str]` rejects legacy tool-argument api_key calls: when `bearer` is None and `api_key` is non-None, it returns `_API_KEY_REJECTED_MESSAGE`. When neither credential is present it returns the canonical `{"error": "Authentication required..."}` envelope. The `api_key` parameter is preserved in the function signature for call-site stability, but is silently ignored when a Bearer is present.

**4 OAuth scopes** (defined in the locked decision record):
- `finlet:read` — portfolio queries, market data, sessions, clock — the default for every read tool
- `finlet:trade` — `submit_order` only (the canonical write-path scope)
- `finlet:benchmark` — the 3 benchmark tools (`start_benchmark`, `get_benchmark_progress`, `export_benchmark_results`)
- `finlet:admin` — reserved for future privileged tools

`cancel_order` requires `finlet:read` (NOT `finlet:trade`) — cancelling one's own pending order is a session-state operation, not a fresh write-path action; the trading authority was granted at `submit_order` time. This is locked in `finlet/mcp/tools_trading.py` per the scope-as-additional-gates contract below.

**Scope enforcement** (`finlet/mcp/auth.py:enforce_scope`): every authenticated tool calls `enforce_scope(claims, required_scope, user_record)`. Per the locked contract (`docs/decisions/mcp-api-key-sunset.md` §3 — still in force post-retraction; only the sunset commitment is rescinded), scopes are **additional gates INSIDE a tier** — the user's tier already gates billing/usage, the OAuth scope gates the specific capability the agent was authorized for. Tier does NOT veto scope, and scope does NOT veto tier; both must permit the call. Bearer `fnlt_*` API keys surface `claims=None`, so `enforce_scope` short-circuits on that compatibility path and downstream tier/rate-limit gates remain load-bearing.

**Tool→scope map** (declared at the top of each tool module):

| Module | Scope | Tools |
|--------|-------|-------|
| `mcp/server.py`, `mcp/tools_session.py`, `mcp/tools_market.py`, `mcp/tools_clock.py` | `finlet:read` | `get_session`, `list_sessions`, `delete_session`, `complete_session`, `create_session`, `get_price_data`, `search_news`, `get_fundamentals`, `get_filings`, `get_economic_data`, `list_available_tickers`, `get_sim_time`, `advance_time`, `freeze_time`, `get_trace` |
| `mcp/tools_portfolio.py` | `finlet:read` | `get_portfolio`, `get_equity_curve`, `get_trace` (3 tools) |
| `mcp/tools_trading.py` | `finlet:trade` | `submit_order` |
| `mcp/tools_trading.py` | `finlet:read` | `cancel_order` (intentional — see above) |
| `mcp/tools_benchmark.py` | `finlet:benchmark` | `start_benchmark`, `get_benchmark_progress`, `export_benchmark_results` (3 tools) |
| `mcp/tools_telemetry.py` | `finlet:read` | `report_bug` (intentional — re-uses existing read scope rather than minting `finlet:telemetry`; see decision record) |

**Phase 4e cutover artifacts**:
- `finlet/mcp/bearer_context.py` — `_API_KEY_REJECTED_MESSAGE` constant carries the Phase 4e rejection envelope wording (matches the existing `{"error": "..."}` shape — no new error contract introduced).
- `finlet/mcp/stdio_proxy.py` — the default `finlet mcp serve` stdio bridge that forwards to hosted `/mcp` with a Bearer Authorization header.
- `docs/MCP_OAUTH_MIGRATION.md` — the user-facing migration guide naming `finlet auth login` + `finlet mcp serve` as the canonical path, with Bearer `fnlt_*` compatibility and legacy tool-argument rejection documented explicitly.
- `docs/decisions/mcp-api-key-sunset.md` — carries a Retraction (2026-05-09) header at the top.
- `docs/decisions/auth-login-cli-vs-api-key.md` — carries a Phase 4e Addendum (2026-05-09) at the bottom.

Key files:
- `finlet/auth/oauth/jwt_validator.py` — `validate_bearer_jwt(token) -> OAuthClaims | None`
- `finlet/auth/deps.py` — `class _RequireOAuth` + `require_oauth = _RequireOAuth()` FastAPI dependency
- `finlet/auth/__init__.py` — re-exports `AUTH_METHOD_OAUTH`, `AUTH_METHOD_BEARER`, `AUTH_METHOD_COOKIE`
- `finlet/mcp/auth.py` — `_authenticate_oauth_or_key` (OAuth JWT first, Bearer api_key fallback), `enforce_scope`, preserved `_authenticate(api_key)` primitive
- `finlet/mcp/bearer_context.py` — `BearerContextMiddleware`, `resolve_credential`, `_extract_bearer_from_context`, `_API_KEY_REJECTED_MESSAGE`
- `finlet/mcp/stdio_proxy.py` — hosted MCP proxy used by default stdio onboarding

**Current v2 contract:** agents use MCP through `finlet mcp serve` over stdio; that bridge calls hosted `/mcp`. Self-host operators can still run the local FastMCP server with `finlet mcp serve --self-host`.

Base URL: `http://localhost:8000`

All routes are registered under both `/v1/` (canonical) and unversioned (deprecated agent-CRUD aliases) paths. Per Phase 3 of the MCP-First Migration (decision record: `docs/decisions/mcp-canonical-surface.md`), MCP is the canonical agent surface; REST agent-CRUD routes are sunsetting on `2026-08-06` and emit `Deprecation: true` and `Sunset: 2026-08-06` headers (RFC 8594). The `Link: rel="successor-version"` header was dropped at the v1.0.0 launch cut (Team E launch-blockers, commit `f54b66c`) because `docs.finlet.dev` DNS was not yet provisioned; the `link_header_url()` helper and URL constants remain in `finlet/api/deprecation.py` for one-line v1.1 reactivation once the docs subdomain ships. Keep-list routes (auth, webhooks, SSE, /health, /metrics, legal, admin, OpenAPI mirror) emit no deprecation signal — see `.claude/rules/api-routes.md` for the full keep-list policy.

**API Documentation** is publicly accessible in all environments (including production):
- `/docs` — Swagger UI (interactive API explorer)
- `/redoc` — ReDoc (read-only API reference)
- `/openapi.json` — OpenAPI 3.x schema

These paths are exempt from geo-blocking (via `geo_config.py` exempt_paths) and require no authentication. The CSP policy omits Trusted Types directives for `/docs` and `/redoc` paths to allow Swagger UI's DOM manipulation.

**Trusted Types vendor coverage:** the dashboard's `trusted-types finlet-default default goog#html` policy is enforced site-wide via `dashboard/api-utils.js`, and the `default` policy emits a `[Finlet] Trusted Types default policy invoked` warning whenever an `innerHTML` write bypasses the named `finlet-default` policy. First-party code goes through `trustedHTML()` exclusively. Vendor blobs are NOT exempt — bug-hunt 20260428T031818Z2efa (Team D, commit `6d7c10e`) patched `dashboard/vendor/lightweight-charts.standalone.production.js` to route its internal SVG `innerHTML` write through `window.trustedHTML(...)`. Vendor patches are fragile by design (a bundle upgrade overwrites them); document each one in `docs/decisions/` and re-apply after every dependency bump. See `docs/decisions/trustedhtml-vendor-patch-tradingview.md`.

**Trusted Types pre-commit guard:** `scripts/lint-trusted-types.sh` (introduced 2026-04-28 in the dashboard event-bus refactor; broadened 2026-04-30 in the trusted-types refactor, commit `bbbf7cc3`) is a grep/awk-based pre-commit hook that fails any commit which adds a bare HTML-sink write under `dashboard/` outside a `trustedHTML(...)` wrap. Coverage now extends to **both `*.js` and `*.html` files** (HTML-block scoping uses an awk state-machine that only scans content inside `<script>` blocks). The sink regex covers `\.(innerHTML|outerHTML)\s*=`, `\.insertAdjacentHTML(`, `document\.write(`, and `\.createContextualFragment(` — matching the full Trusted Types-relevant DOM HTML sink list. Vendor files keep their patches via an explicit `// trusted-types-vendor-allowlist` comment marker (see `dashboard/vendor/lightweight-charts.standalone.production.js`). Install via `scripts/setup-git-hooks.sh`, which symlinks `scripts/git-hooks/pre-commit` into `.git/hooks/`. Chosen over an ESLint rule because the dashboard has no ESLint config and no bundler — adding one to host a single rule was higher cost than a 50-line shell script. Future HTML-sink regressions are blocked at PR-time rather than caught a bug-hunt iteration later.

**Trusted Types runtime telemetry:** the `default` policy callbacks in `dashboard/api-utils.js` (`createHTML`, `createScript`, `createScriptURL`) and a top-level `document.addEventListener('securitypolicyviolation', ...)` handler POST to `/v1/telemetry/client-error` via `reportClientError({type: 'trusted_types_violation', sink, sample, source})`. Both sinks are wrapped in try/catch so a telemetry failure can never block page render. This closes the production-observability gap (added 2026-04-30 in the trusted-types refactor) — `console.warn` is invisible in production where browsers run with consoles closed; the telemetry POST surfaces violations on the server side. CSP-side violations (e.g., a third-party policy creation blocked because its name is missing from the `trusted-types` allowlist, like the `goog#html` regression before its fix) flow through the same channel via the `securitypolicyviolation` event. Decision record: `docs/decisions/trusted-types-broaden-lint-and-runtime-reporter.md`.

**Event-bus pre-commit guard:** `scripts/lint-event-bus.sh` (introduced 2026-05-05 in the convention-enforcement refactor) is a sibling grep/awk-based pre-commit hook that fails any commit which adds a direct `addEventListener('finlet:...')` or `dispatchEvent(new CustomEvent('finlet:...'))` call under `dashboard/` outside `dashboard/event-bus.js`. Coverage extends to both `*.js` and `*.html` files (HTML-block scoping mirrors the trusted-types lint's awk state-machine). The bus's own implementation is path-allowlisted; future legitimate exceptions can opt out via the marker comment `// finlet-bus-lint-allowlist`. The pre-commit hook (`scripts/git-hooks/pre-commit`) chains the two dashboard lints — trusted-types first, event-bus second — and any failure blocks the commit. Together with the trusted-types guard above, the dashboard's two structural conventions (HTML-sink wrapping + bus dispatch) are now enforceable at commit-time. Decision record: `docs/decisions/dashboard-event-bus.md` (Enforcement section).

#### Session Endpoints
- `POST /v1/sessions` — Create session. Accepts an optional `Idempotency-Key` request header (since 2026-04-30, bug-hunt `20260430T222711Z3666` Team B, commit `1616ade`); if the same key is resubmitted within 24h the cached response from the first successful create is returned without creating a duplicate session. Cache namespace is keyed per-user (`user:{user_id}:sessions`) so different users sharing a key don't collide. Backed by the existing `IdempotencyStore` (same mechanism as `POST /sessions/{id}/trade/order`). Protects CLI/SDK retries after a client-side `ReadTimeout` from accidentally hitting the per-tier concurrent-session limit.
- `GET /v1/sessions` — List sessions
- `GET /v1/sessions/{id}` — Get session state
- `DELETE /v1/sessions/{id}` — End session
- `POST /v1/sessions/{id}/complete` — Complete/seal session (freezes clock, seals trace, sets status to COMPLETED). Returns session summary.
- `POST /v1/sessions/{id}/configure` — Update config

#### Clock Endpoints
- `GET /v1/sessions/{id}/clock` — Current clock state
- `POST /v1/sessions/{id}/clock/freeze` — Freeze clock
- `POST /v1/sessions/{id}/clock/step` — Step by interval
- `POST /v1/sessions/{id}/clock/step-to` — Step to specific datetime. Pre-validates timezone awareness; returns 422 on naive datetime input.
- `POST /v1/sessions/{id}/clock/play` — Start continuous mode
- `POST /v1/sessions/{id}/clock/stop` — Stop continuous mode

#### Market Data Endpoints (Plugin-Routed)
- `GET /v1/sessions/{id}/market/price` — Price data (→ S3 Parquet via PricePlugin)
- `POST /v1/sessions/{id}/market/search-news` — News search (→ Finnhub)
- `GET /v1/sessions/{id}/market/fundamentals` — Fundamentals (default → `FundamentalsPlugin` (S3 Parquet); fallback → `FinnhubPlugin` only if it's initialized). Optional `?provider=fundamentals_s3` or `?provider=fundamentals_finnhub` query param pins dispatch to a single plugin, no fallback chain runs. The plugin's response is returned as-is (success or error). Useful for diagnosis when a downstream fallback is masking a plugin's true response. Unknown provider names return 503.
- `GET /v1/sessions/{id}/market/filings` — SEC filings (→ EDGAR)
- `GET /v1/sessions/{id}/market/economic` — Economic data (→ FRED)
- `GET /v1/market/tickers` — List all tickers in the universe with `has_prices` and `has_fundamentals` flags, plus per-ticker coverage metadata: `earliest_price_date`, `latest_price_date`, `earliest_fundamentals_date`, `latest_fundamentals_date`, `fundamentals_filings_count`, and `last_updated_utc`. Session-independent — registered under the public `/market` router and auth-gated via `require_user`. Uses efficient S3 probing (1 read for the most recent prices parquet, 1 list for the fundamentals prefix) plus S3 manifest sidecar rollup (via `finlet/api/helpers/coverage_rollup.py`) for date-range metadata. Coverage enrichment is best-effort — if manifest reads fail, coverage fields are `None`. Results are module-level cached for 1 hour. Buckets configured via `FINLET_PRICE_BUCKET` and `FINLET_FUNDAMENTALS_BUCKET`. Call this before `POST /v1/sessions` to validate data availability for the chosen universe and start date.

#### Public Session Sharing (Anonymous Read)

Public sessions opt in via `PATCH /v1/sessions/{id}/visibility` (owner-only, REST + MCP). Once `session.public == True`, the session is exposed read-only and anonymously at five `/v1/public/sessions/{id}/*` GET routes. All five routes are anonymous (NO `Depends(require_user)`); the precedent is `GET /v1/leaderboard` at `finlet/api/routes_leaderboard.py:38`. Shared helper `_get_public_session(session_id)` returns 404 for unknown ID **and** for `session.public == False` (info-leak parity with `get_user_session()` — identical 404 for "not found" vs "not public"). The response uses an allowlist-based `public_session_response()` serializer (`_PUBLIC_SESSION_KEYS` tuple in `finlet/api/services/session_service.py`) — `user_id`, email, `last_used_at`, and idempotency keys are NEVER exposed. When `session.public_anonymous == True`, the `name` field is replaced with the literal `"Anonymous Finlet session"`; all other fields (config, portfolio metrics, positions, orders, trace, equity curve) are exposed identically regardless of anonymous mode. Keep-list pattern entry in `.claude/rules/api-routes.md` + `finlet/api/deprecation.py` ensures the sunset middleware does not mark these routes deprecated. No app-layer rate limit for v1 (reverse-proxy floor only).

- `GET /v1/public/sessions/{id}` — Anonymous read of session metadata (config, status, portfolio metrics summary). PII-redacted via allowlist serializer; `name` anonymized when `session.public_anonymous == True`.
- `GET /v1/public/sessions/{id}/portfolio` — Current portfolio + positions
- `GET /v1/public/sessions/{id}/portfolio/history` — Equity curve time series (the equity curve panel on `dashboard/public.html` consumes this)
- `GET /v1/public/sessions/{id}/orders` — Order log
- `GET /v1/public/sessions/{id}/trace` — Reasoning trace
- `PATCH /v1/sessions/{id}/visibility` — Owner-only toggle. Request body: `{public: bool, anonymous: bool = True}`. Authenticated 404 (not 401) on owner B touching owner A's session, matching `get_user_session()` info-leak parity. Anonymous attempt returns 401 (`Depends(require_user)`). Decision record: `docs/decisions/session-public-visibility.md`.

**Public-trace PII redaction chokepoint (Codex bug `9a7d7f07`, 2026-05-22):** Trace `request_params` and `response_summary` payloads on anonymous read surfaces route through `trace_data(... public_surface=True, owner_id=session.user_id or "")`. The `_public_redact_payload` recursive helper in `finlet/api/serializers.py` (a) drops dict keys matching the denylist (`user_id`, `email`, `phone`, `api_key`, `bearer_token`, `mfa_code`, `oauth_token`, `owner`) OR starting with `_` (catches `_user_id` smuggled by the API layer), AND (b) replaces string values at any depth that contain `owner_id` as a substring of length ≥ 8 (catches owner-id smuggled under non-denylisted keys per Codex STRONG #10). Composition order: blind walker FIRST (tickers/dates → opaque), then PII redactor. `routes_public_session.py` opts in on all four public read paths (`trace`/`portfolio`/`history`/`orders`). The write-time companion fix removed the smuggled `params["_user_id"] = owner_id` mutation at `finlet/api/services/market_service.py:767` — that mutation flowed verbatim into `session.trace.record(... request_params=params)` and persisted to disk. Per Codex STRONG #9: any future anonymous-public-readable SSE event must also pass `public_surface=True`. Regression locked by `tests/api/test_public_session_pii_hygiene.py` (10 grep tests asserting both `_user_id` key absence AND ≥8-char owner-id substring absence on every public read endpoint). See `docs/decisions/public-trace-redaction-chokepoint.md`.

**Accept-routing on `/sessions/{id}` (followups, 2026-05-13, squash `f6441dd`):** the static `/sessions/{id}` URL flipped to HTML-by-default. The `_HtmlAcceptRoute.matches()` predicate now routes default `Accept: */*` and missing-Accept headers to `dashboard/public.html`; explicit `Accept: application/json` (without `text/html`) still falls through to the deprecated JSON endpoint until the 2026-08-06 sunset. This removes the curl/probe deprecation-header surprise — external traffic without an explicit Accept header now sees the public view instead of a 401 from the deprecated JSON path. Coverage: `tests/api/test_public_session_accept_routing.py` (5 new tests) plus 7 existing JSON-path call-sites opted in with explicit `Accept: application/json`.

#### Trading Endpoints
- `POST /v1/sessions/{id}/trade/order` — Submit order
- `GET /v1/sessions/{id}/trade/orders` — List orders
- `GET /v1/sessions/{id}/trade/orders/{oid}` — Order detail
- `DELETE /v1/sessions/{id}/trade/orders/{oid}` — Cancel order
- `GET /v1/sessions/{id}/orders` — List orders (alias of `/trade/orders` since 2026-05-03, bug-hunt `20260503T195318Z43db` Team A, commit `4c4e7da`). Aliases mount in `routes_session.py` (no router prefix) under the `/v1` group; existing `/trade/orders` routes in `routes_trade.py` are unchanged. Both shapes call the same `list_orders` service in `trade_service.py` — no business-logic fork. Auth + ownership shared via `Depends(require_user)` + `get_user_session(session_id, user)`. Response shape `list[OrderResponse]` is identical on both paths.
- `GET /v1/sessions/{id}/orders/{oid}` — Order detail (alias of `/trade/orders/{oid}`, same lineage as the list alias above).

#### Portfolio Endpoints
- `GET /v1/sessions/{id}/portfolio` — Current state + metrics
- `GET /v1/sessions/{id}/portfolio/history` — Equity curve time series
- `GET /v1/sessions/{id}/trace` — Reasoning trace (with optional filters)

#### Real-time
- `GET /v1/sessions/{id}/stream` — **SSE stream** of all session state updates (clock, portfolio, orders, trace, plugin health). Uses `StreamingResponse(media_type="text/event-stream")` with `Cache-Control: no-cache`, `X-Accel-Buffering: no`. Events: `session`, `clock`, `portfolio`, `history`, `orders`, `trace`, `health`. Auto-closes after 30 minutes (client should reconnect). Requires authentication (same session cookie/Bearer auth as other routes). The dashboard uses native `EventSource` API instead of polling for real-time updates.

#### Auth Endpoints
- `GET /v1/auth/config` — Public auth config (Google, SMS MFA availability)
- `POST /v1/auth/register` — Register new account (rate-limited 5/hr/IP). Dual-mode: if `password` field provided, registers with email + password; otherwise, legacy API key registration (backward compatible)
- `POST /v1/auth/login` — Sign in with email + password. Returns session cookie directly, or MFA challenge if MFA enabled
- `GET /v1/auth/me` — Current user profile
- `POST /v1/auth/research-network/opt-in` — Opt in to Research Network (+1 daily session for free tier)
- `POST /v1/auth/research-network/opt-out` — Opt out
- `POST /v1/auth/sign-in` — Sign in with API key (returns MFA challenge if enabled). Preserved for programmatic clients
- `POST /v1/auth/mfa/validate` — Complete MFA challenge
- `GET /v1/auth/mfa/status` — Get MFA enrollment status (TOTP enabled, SMS enabled, backup codes remaining, masked phone)
- `POST /v1/auth/mfa/totp/setup` — Start TOTP setup (returns QR code + secret)
- `POST /v1/auth/mfa/totp/verify` — Confirm TOTP setup with first code
- `POST /v1/auth/mfa/totp/disable` — Disable TOTP
- `POST /v1/auth/mfa/sms/setup` — Start SMS MFA setup (E.164 phone number)
- `POST /v1/auth/mfa/sms/verify` — Confirm SMS setup
- `POST /v1/auth/mfa/sms/disable` — Disable SMS MFA (requires valid SMS code for confirmation)
- `POST /v1/auth/mfa/sms/send` — Re-send SMS OTP code during MFA challenge
- `POST /v1/auth/google` — Sign in via Google OAuth (improved error handling, account linking)
- `POST /v1/auth/forgot-key` — Initiate forgot-key flow (sends verification code)
- `POST /v1/auth/verify-code` — Verify code and retrieve API key
- `POST /v1/auth/forgot-password` — Initiate password reset (sends verification code via email). Anti-enumeration: always returns success
- `POST /v1/auth/reset-password` — Complete password reset (email + code + new password)
- `POST /v1/auth/set-password` — Set a password for OAuth-only users who have no password yet. Authenticated (requires `require_user`). Returns 409 if user already has a password (use `PUT /settings/password` instead). Password validated: min 8, max 128 characters.
- `POST /v1/auth/session` — Create auth session (login via session cookie)
- `DELETE /v1/auth/session` — Destroy auth session (logout)
- `GET /v1/auth/session/validate` — Validate current session cookie. Returns `{ valid, user_id, email, tier, csrf_token }`. The `csrf_token` in the response body allows the dashboard to restore the CSRF token after page navigation

#### Billing Endpoints
- `POST /v1/billing/checkout` — Create Stripe Checkout session for tier upgrade
- `POST /v1/billing/webhook` — Stripe webhook handler (hidden from schema)
- `GET /v1/billing/portal` — Create Stripe Customer Portal session
- `GET /v1/billing/subscription` — Current subscription status and tier
- `GET /v1/billing/usage` — Current billing period usage vs limits
- `GET /v1/billing/invoices` — Invoice history from Stripe
- `POST /v1/billing/validate-promo` — Validate promo/coupon code
- `POST /v1/billing/cancel` — Cancel subscription (downgrade to free)

#### Email Endpoints
- `POST /v1/email/verify` — Send verification email
- `POST /v1/email/verify-token` — Verify email address (no auth required). Token sent in POST body (`TokenRequest` model) instead of URL path to prevent leakage via browser history, referrer headers, proxy logs, and middleware request logs.
- `GET /v1/email/preferences` — Get notification preferences
- `PUT /v1/email/preferences` — Update notification preferences
- `POST /v1/email/unsubscribe` — One-click unsubscribe (no auth required). Token sent in POST body (`TokenRequest` model) instead of URL path.

#### Settings Endpoints
- `GET /v1/settings/profile` — Get user profile
- `PUT /v1/settings/profile` — Update display name, bio, timezone
- `PUT /v1/settings/password` — Update password (requires current password, or first-time set for OAuth-only users without a password)
- `GET /v1/settings/api-keys` — List API keys (masked `fnlt_...xxxx`, with name, created, last_used timestamps)
- `POST /v1/settings/api-keys` — Create named API key (returns raw key exactly once; copy-once pattern)
- `DELETE /v1/settings/api-keys/{key_id}` — Revoke API key
- `POST /v1/settings/api-keys/rotate` — Rotate API key (revoke old, create new; returns raw key once)
- `GET /v1/settings/plugins` — Get plugin config (API keys masked)
- `PUT /v1/settings/plugins` — Update plugin API key, email (for EDGAR User-Agent identity), or enabled status. **Canonical write path** — persists the per-user config and (on credential changes) hot-reloads the plugin via `registry.reload()`, returning the post-reload `PluginHealthItem` folded into `PluginUpdateResponse` so the caller can render the live status without a second round-trip. Top-level `status` is derived from the live health (`healthy → "updated"`, `degraded → "degraded"`, `unhealthy → "unhealthy"`). See `## Plugin config write paths` above for the role split with `POST /v1/plugins/{name}/reload`. Plugin config is scoped per-user (in-memory; DB persistence is TODO).
- `GET /v1/settings/notifications` — Get notification preferences
- `PUT /v1/settings/notifications` — Update notification preferences
- `DELETE /v1/settings/account` — **DEPRECATED — returns 410 Gone as of 2026-05-14** (GDPR Item G, D9 — `docs/decisions/gdpr-deletion-pattern.md`). Returns an actionable error envelope pointing callers at the new endpoint pair `POST /v1/account/delete` + `GET /v1/account/delete/{job_id}` + `DELETE /v1/account/delete/{job_id}`. The legacy synchronous handler deleted only the `ApiKeyModel` row and orphaned 28 other user-scoped tables; superseded by the full Article 17 cascade. See the "Account Endpoints (GDPR Article 17 — right to erasure)" section below for the replacement contract.

#### Account Endpoints (GDPR Article 20 — data portability)
- `POST /v1/account/export` — Create or return an in-flight data-export job. **OAuth Bearer only** (`Depends(require_oauth)`). Returns `202 Accepted` + `ExportJobResponse(job_id, status="pending")`. Idempotent: a duplicate POST while a job is `pending` or `running` for the same user returns the SAME `job_id` instead of spawning a second background task. Background work runs via `asyncio.create_task(run_gdpr_export_job(job_id, user.id))` — the HTTP response does NOT block on completion.
- `GET /v1/account/export/{job_id}` — Poll one job's current state. **OAuth Bearer only.** Returns `ExportJobResponse` reflecting `pending | running | success | failed`. On `success`: response carries a freshly-minted 24h presigned S3 download URL (never persisted to the audit row — re-minted on every poll), the archive size in bytes, and the URL expiry timestamp. On `failed`: response carries the sanitized error summary. 404 if the `job_id` is unknown or owned by a different user (same info-leak posture as `get_user_session`).

#### Account Endpoints (GDPR Article 17 — right to erasure)
- `POST /v1/account/delete` — Initiate or confirm an account deletion. **OAuth Bearer only.** Single endpoint, dual call shape. **First POST** (no `confirmation_token` in body, optional `include_export` flag): mints a job + single-use 256-bit confirmation token, persists the `gdpr_deletion_requests` audit row in `pending_confirmation`, returns `202 Accepted` + `DeletionJobResponse` with the token + 24h expiry. **Second POST** (`confirmation_token` present, optional `job_id`): atomically validates + consumes the token, flips the row to `pending_execution`, schedules the cascade runner via `schedule_grace_period_executor` (sleeps until `grace_expires_at`, then fires `run_gdpr_deletion_job`). Token mismatch / wrong user / non-pending status → `401`. Idempotent for first-POST shape: a duplicate POST while a job is in any pre-terminal state (`pending_confirmation`, `pending_execution`, `running`) returns the existing job's record.
- `GET /v1/account/delete/{job_id}` — Poll the 6-state machine (`pending_confirmation | pending_execution | running | success | failed | canceled`). **OAuth Bearer only.** Hot path: in-memory `_deletion_jobs` dict. Cold path: `load_deletion_job_from_db()` (survives process restart). On `success` with `include_export=True` and `archive_object_key` set, re-mints a fresh 24h presigned URL via F's `GdprS3Storage.generate_download_url`. 404 for missing job OR job owned by another user (no info leak between the two states).
- `DELETE /v1/account/delete/{job_id}` — Cancel a deletion job during the grace window. **OAuth Bearer only.** Valid in `pending_confirmation` or `pending_execution`. Returns `204 No Content` on success, `404 Not Found` for missing/foreign jobs, `409 Conflict` for jobs that have already started running, completed, failed, or were previously canceled. The cascade runner observes the status change at its audit-row re-read so a cancel during the grace window short-circuits the runner cleanly even when the executor task is mid-sleep.
- `DELETE /v1/settings/account` — **410 Gone** (deprecated 2026-05-14 by GDPR Item G). Returns an actionable error pointing to `POST /v1/account/delete`. The legacy route called `auth_service.delete_user(user_id)` which deleted ONLY the `ApiKeyModel` row and left 28 other user-scoped tables orphaned — superseded by the full Article 17 cascade. See `docs/decisions/gdpr-deletion-pattern.md` for the supersede rationale.

#### Legal Endpoints
- `GET /v1/privacy` — Privacy Policy (HTML for browsers, JSON for API consumers)
- `GET /v1/terms` — Terms of Service (HTML for browsers, JSON for API consumers)

#### Leaderboard Endpoints
- `GET /v1/leaderboard` — Public rankings
- `POST /v1/leaderboard/submit` — Submit benchmark run (rate-limited 10/day/user)
- `GET /v1/leaderboard/submit/{job_id}` — Benchmark job status (poll after submit)
- `GET /v1/leaderboard/agents/{id}` — Agent profile detail
- `GET /v1/leaderboard/benchmarks` — List benchmark scenarios

The dashboard includes a "Submit to Leaderboard" button and modal (`dashboard/leaderboard-submit.js`) that allows users to submit benchmark runs directly from the main dashboard. The modal collects agent name, description, model, strategy category, and data sharing preference, then polls the benchmark job status until completion.

#### Admin Endpoints
- `POST /v1/admin/cache/invalidate` — Flush and reload the AuthService in-memory key cache. Protected by `FINLET_ADMIN_USER_IDS`. Eliminates the need for a service restart after direct DB edits.

#### Health & Metrics
- `GET /v1/health` — Health check. Returns `status` ("ok"), `dashboard_available` (boolean), and `data_status` (one of "ok", "degraded", or "unavailable") indicating whether price data is reachable. Startup logs warn if price data is unavailable. No internal filesystem paths or server metadata are exposed.
- `GET /v1/plugins/health` — Per-plugin health status (circuit breaker state, last success/failure timestamps). **Canonical surface** — both the dashboard's Plugin Health widget and the Settings tab's plugin list consume this endpoint (settings convergence shipped 2026-05-02 in bug-hunt `20260502T142726Z7b36` Team C, commit `2d200db`). Client-side helpers (CLI `finlet plugins list`, Settings `loadPlugins()`, future SDKs) MUST query this endpoint rather than re-deriving health from a parallel code path — divergent surfaces drift silently.
- `POST /v1/plugins/{name}/ingest` — Trigger ingestion for a plugin's data store. Returns `202 Accepted` + `{"job_id": "<uuid>"}`. Auth-gated (Bearer API key required) so anonymous traffic cannot enqueue jobs. Lives in `finlet/api/routes_plugins.py` (distinct from `routes_health.py` which owns `/plugins/health` + `/plugins/{name}/reload`) so the ingest pipeline can grow into a fully-typed surface without bloating the health module. **Stub for iteration `20260502T142726Z7b36`** (commit `ad0adb0`) — the dashboard Settings Ingest button calls this when a plugin's health probe reports the "Run ingestion first" degraded state; the stub logs the request via `structlog`, mints a UUID `job_id`, and returns 202. Real pipeline wiring (`scripts/ingest_yfinance_prices.py` etc.) is the next iteration's work — see `TODO(iteration 20260502T142726Z7b36)` markers in `finlet/api/routes_plugins.py` and decision record `docs/decisions/plugin-ingest-stub-endpoint.md`. Returns 404 if no plugin with the given name is registered.
- `GET /v1/metrics` — Prometheus exposition format (not JSON). Includes SLO targets for API latency and upstream plugin availability.

#### Error Handling

All API errors use a centralized error envelope installed via `install_error_handlers()` in `finlet/api/app.py`:

```json
{"error": {"code": "...", "message": "...", "details": [...]}}
```

Standard codes:
- `409` — Session not active (raised by `SessionNotActiveError` when mutating a completed/paused/created session)
- `422` — Validation errors (including naive datetime rejection from clock endpoints)
- `404` — Missing sessions/orders (also returned for unauthorized sessions to prevent info leakage)
- `429` — Rate limits (pass through from plugins with details)
- `502` — Upstream service errors (e.g., Stripe failures in billing routes — uses standard `HTTPException` instead of custom error responses)
- `503` — Plugin unavailability; also returned when marketplace is disabled (see below)

**Error-anchor convention (USER_MANUAL_OVERHAUL, 2026-05-15):** every agent-facing error envelope's human-readable string (REST `error.message`, MCP `{"error": "..."}`, plugin `PluginResponse.error`, billing/OAuth modeled-envelope `detail`) ends with the literal suffix `See: finlet manual errors#<anchor>`, where `<anchor>` is one of the 13 frozen kebab-case anchor IDs defined in `finlet/manual/errors.md`. The suffix is appended at the call site, not by middleware — keeps the string self-contained and grep-friendly. The 13 anchors: `rate-limit`, `expired-token`, `missing-bearer`, `missing-scope`, `missing-api-key`, `plugin-timeout`, `plugin-malformed`, `plugin-rate-limit`, `transport-mismatch`, `port-conflict`, `date-ceiling-violation`, `invalid-session`, `order-rejected`. The 19 MCP tool sites that previously each minted their own `"Authentication required..."` string now reference the shared `_AUTH_REQUIRED_MESSAGE` constant in `finlet/mcp/auth.py`, which carries the `#missing-bearer` anchor once — eliminates per-tool drift. Triage agents observing any error class can route the same recovery doc regardless of subsystem. Decision record: `docs/decisions/error-anchor-convention.md`. Per-surface contract gates in `tests/api/test_error_anchors.py` + `tests/billing/test_error_anchors.py` + `tests/auth/oauth/test_error_anchors.py` + `tests/plugins/test_error_anchors.py` assert every envelope carries a valid anchor suffix. Auth-required dedup justifies the `/mcp(/.*)?$` whitelist in `finlet/api/deprecation.py` (the legacy deprecation-header middleware that would otherwise tag MCP paths as deprecated alongside `/v1/` routes).

### GDPR Article 20 data export

End-to-end async pipeline for the user's right to data portability (shipped 2026-05-14 via `GDPR_EXPORT_F_EXECUTION_PLAN.md`). Replaces the legacy `POST /settings/export-data` stub (which dumped in-memory state only — see `docs/decisions/gdpr-export-cascade-pattern.md` for the supersede rationale).

**Endpoint pair (OAuth Bearer only):**
- `POST /v1/account/export` returns `202 Accepted` + `{job_id, status: "pending"}` and spawns the runner via `asyncio.create_task(run_gdpr_export_job(job_id, user.id))`. Idempotent — duplicate POST while pending/running returns the existing `job_id`, never spawns a second task. IP is captured from `request.client.host` (with `X-Forwarded-For` fallback) onto the audit row.
- `GET /v1/account/export/{job_id}` re-mints a 24h presigned S3 URL on every successful poll (the URL itself is never persisted — only the S3 object key + size + expiry timestamp land on the audit row). Hot-path lookup hits the in-memory `_export_jobs` dict; cold-path falls through to `load_job_from_db()` so historical jobs survive process restarts. 404 for missing job OR job owned by another user (no info leak between the two states).

**Cascade walker (`finlet/gdpr/walkers/ALL_WALKERS`):** allowlist-only redaction. Each walker is `async def walk_*(user_id: str) -> list[WalkerResult]`, where `WalkerResult = {table_name, rows, schema_hash, redacted_columns}`. The registry covers every user-scoped surface:
- **Auth DB** (`~/.finlet/auth.db`): `api_keys`, `named_api_keys`, `mfa_sessions`, `pending_totp_setups`, `sms_otps`, `verification_codes`, `session_tokens`, `oauth_clients`, `oauth_authorizations`, `oauth_refresh_tokens`, `gdpr_export_requests`. Credential material (`*_hash`, `*_secret`, raw OTP codes, OAuth `client_secret_hash`, raw refresh tokens) is **stripped at the walker stage** — not post-hoc.
- **Leaderboard / global DB** (`~/.finlet/leaderboard.db`, `~/.finlet/finlet.db`): `users` (api_key_hash redacted), `agent_profiles`, `scenario_scores`, `benchmark_jobs`, `benchmark_runs`, `benchmark_scenario_results`.
- **Marketplace DB** (`~/.finlet/marketplace.db`): `developer_profiles`, `onboarding_progress`, `compliance_attestations`, `strategy_listings`, `admin_reviews`. Global `dmca_designated_agents` is NOT user-scoped and is intentionally excluded.
- **Billing surface** (lives on `SubscriptionModel` in the auth DB): **REDACT NOTHING** — Stripe customer_id + subscription state IS the user's own data and they get to take it.
- **Per-session DBs** (`~/.finlet/sessions/{session_id}/session.db`): cascade walker disk-scans `SESSIONS_DIR`, opens each `session.db`, verifies `SessionModel.user_id == target`, and emits 5 `WalkerResult` entries (one per table: `sessions`, `orders`, `positions`, `portfolio_snapshots`, `trace_entries`) per matching session. Per-session errors (corrupted DB, deleted mid-walk) are caught and surfaced as sentinel `__error__` WalkerResults so one bad session does not fail the whole export.

**Default-deny safety net:** `finlet/gdpr/walkers/_common.py:_DENY_RE` (`secret|hash|password|private_key|key_material|token$`) is asserted against every walker's KEEP set at module import. A future schema change that adds a column named `*_hash` and forgets to update the KEEP allowlist surfaces as an immediate `ValueError` at import time, not as a leaked credential in production exports.

**Archive format (`finlet/gdpr/archive.py:build_archive`):** ZIP with `ZIP_DEFLATED`. Layout:
```
{user_id}.zip
├── api_keys.jsonl
├── subscriptions.jsonl
├── …
├── sessions/{session_id}/orders.jsonl
└── manifest.json
```
Manifest schema: `{schema_version: "1", generated_at: <ISO 8601 UTC>, user_id, tables: [{name, row_count, schema_hash, redacted_columns}]}`. The runner also tacks `archive_size_bytes` + `archive_sha256` onto the caller's response (NOT inside the in-zip manifest — that would create a hash-of-self recursion) for audit-row bookkeeping.

**S3 storage (`finlet/gdpr/storage.py:GdprS3Storage`):** bucket from `FINLET_EXPORTS_BUCKET` env (default `finlet-exports`), key `gdpr-exports/{user_id}/{job_id}.zip`. The 24h object-lifecycle policy is scoped to that bucket so it never sweeps the parquet ingestion lake. Presigned URLs are 24h TTL (signed locally — no S3 round-trip), matching the lifecycle so URLs cannot outlive their objects. Parallel to (not replacing) `finlet/ingestion/s3_writer.py` — the parquet writer stays pure parquet-only.

**Audit table:** `gdpr_export_requests` (migration `016_add_gdpr_export_requests`) records `{id, user_id, requested_at, completed_at, status, archive_size_bytes, archive_object_key, expires_at, ip_address, error_detail}`. State machine: `pending → running → success | failed`. The runner is the only writer of `running` / `success` / `failed`; the API layer creates the `pending` row before spawning the task.

**Property-based completeness gate:** `tests/gdpr/test_export_property.py` — Hypothesis (`@settings(max_examples=50, deadline=None)`, pinned seed `12345`) seeds two synthetic users with N tables × K rows each, drives the full export pipeline for user_A with a mocked S3 client, and asserts every user_A marker appears in the archive AND zero user_B markers leak. This is the load-bearing cross-user isolation gate the requirements doc demands.

**Decision record:** `docs/decisions/gdpr-export-cascade-pattern.md` (self-contained — readable cold). Establishes the audit-row + cascade-walker pattern that **Item G (account deletion / GDPR Article 17)** reuses: `delete_for(user_id) -> int` per-walker, a sibling `gdpr_deletion_requests` audit table, and the same async job-runner shape.

### GDPR Article 17 account deletion

End-to-end two-step async deletion pipeline for the user's right to erasure (shipped 2026-05-14 via `GDPR_DELETION_G_EXECUTION_PLAN.md`). Reuses the cascade-registry + audit-row pattern established by F (`docs/decisions/gdpr-export-cascade-pattern.md`) with a 24-hour grace window for cancellation and Stripe-side subscription cancellation. Supersedes the legacy `DELETE /settings/account` route (now 410 Gone — see `docs/decisions/gdpr-deletion-pattern.md` for the supersede rationale).

**Endpoint pair (OAuth Bearer only):** see the "Account Endpoints (GDPR Article 17 — right to erasure)" section above for the full contract (`POST /v1/account/delete`, `GET /v1/account/delete/{job_id}`, `DELETE /v1/account/delete/{job_id}`).

**Cascade deleter registry (`finlet/gdpr/deleters/ALL_DELETERS`):** explicit list of 29 deleters, each `async def delete_<table>_for_user(user_id: str) -> int` returning rowcount. OAuth refresh tokens are deleted FIRST (D6 — closes the "user mints a new session during deletion" attack window before any other work). Cascade order mirrors F's `ALL_WALKERS` (auth → leaderboard → marketplace → billing → composite-key → per-session DB sweep) so the post-mortem trace is diff-friendly across the two flows.

**Stripe-side cancellation (`finlet/gdpr/stripe_cancellation.py`):** isolated module separate from `finlet/billing/service.py`. Calls `stripe.Subscription.delete()` via `asyncio.to_thread`. Fail-loud (D2) — ANY exception aborts the job at `failed` status. Free-tier users (no `SubscriptionModel` row) successfully no-op.

**Salted SHA-256 audit-identifier hashing (`finlet/gdpr/hashing.py`):** computes `user_id_hash` and `email_hash` (64-char hex) before the cascade fires using salt from `FINLET_DELETION_HASH_SALT` (SSM-sourced in production). The audit row IS retained after cascade — hashes prove the deletion happened without retaining identifiers an auditor or attacker could re-bind to a real user (D1).

**Async job runner + grace executor (`finlet/gdpr/deletion_job_runner.py`):** `run_gdpr_deletion_job(job_id, user_id)` drives one user's deletion from `running` to `success | failed` via the 8-step pipeline (snapshot email → flip to `running` → revoke OAuth → cancel Stripe → iterate `ALL_DELETERS` → wipe per-session DB directories → flip audit row to `success`). `schedule_grace_period_executor(job_id, user_id, grace_expires_at)` is the in-process sleep+run path called by the confirmation endpoint. `sweep_orphaned_pending_execution_jobs()` runs at app startup to re-schedule jobs whose grace timer elapsed during downtime — a process restart mid-grace does not strand a deletion.

**Audit table:** `gdpr_deletion_requests` (migration `017_add_gdpr_deletion_requests`) records `{id, user_id, requested_at, confirmed_at, grace_started_at, grace_expires_at, started_at, completed_at, canceled_at, status, include_export, archive_object_key, stripe_subscription_canceled_at, confirmation_token, user_id_hash, email_hash, ip_address, error_detail}`. State machine: `pending_confirmation → pending_execution → running → success | failed | canceled`. The API layer creates the `pending_confirmation` row BEFORE returning the response so a polling GET cannot race the audit write.

**Cross-cascade invariants:**
- F's `gdpr_export_requests` rows are NOT deleted by G's cascade (D8 — F-audit immutability extends to F's audit). The property test asserts surviving F-audit rows after G's cascade runs.
- `oauth_keys` + `dmca_designated_agents` (global non-user-scoped tables) survive untouched.
- `include_export=True` (D10) makes the runner call F's `run_gdpr_export_job` BEFORE the cascade fires and stash the resulting `archive_object_key` on the deletion-audit row. The user polls one endpoint to get both the export URL and deletion status — "give me my data, then delete me" in one request.

**Property-based completeness gate:** `tests/gdpr/test_deletion_property.py` — Hypothesis (`@settings(max_examples=20, deadline=None)`, pinned seed `0`) seeds 2-4 synthetic users with N rows per table across every user-scoped surface, drives `run_gdpr_deletion_job` for user_ids[0] (Stripe stubbed to succeed), and asserts the six load-bearing invariants (completeness, cross-user isolation, audit-row hash population, F-audit immunity, global-table survival, registry-shrink gate). This is the load-bearing cross-user isolation gate the requirements doc demands — the analog of F's `tests/gdpr/test_export_property.py`.

**Decision record:** `docs/decisions/gdpr-deletion-pattern.md` (self-contained — readable cold). Captures the ten load-bearing decisions (D1-D10), the five load-bearing pieces, the property-test invariants, the API surface contract, and the supersede rationale for the legacy `DELETE /settings/account` route.

### Marketplace API

Gated behind `FINLET_MARKETPLACE_ENABLED` feature flag. When disabled, all `/marketplace/**` paths return HTTP 503 with the standard error envelope `{"error": {"code": "SERVICE_UNAVAILABLE", "message": "The Finlet Strategy Marketplace is coming soon."}}`, correctly signaling service unavailability instead of 200 OK.

#### Developer Onboarding (7-step sequential flow)
- `POST /v1/marketplace/developer/register` — Step 2: Developer registration
- `POST /v1/marketplace/developer/attest` — Step 3: Compliance attestation
- `POST /v1/marketplace/developer/stripe-connect` — Step 4: Stripe Connect onboarding
- `POST /v1/marketplace/developer/tax-form` — Step 5: W-9/W-8BEN collection
- `POST /v1/marketplace/developer/acknowledge-guidelines` — Step 6: Listing guidelines acknowledgment
- `GET /v1/marketplace/developer/onboarding` — Get current onboarding progress
- `GET /v1/marketplace/developer/profile` — Get developer profile
- `POST /v1/marketplace/developer/strategies` — Create strategy listing
- `POST /v1/marketplace/developer/strategies/{slug}/submit` — Submit for admin review (Step 7)

#### Admin Moderation
- `GET /v1/marketplace/admin/review-queue` — Pending review queue (sorted by priority)
- `POST /v1/marketplace/admin/strategies/{slug}/approve` — Approve and publish
- `POST /v1/marketplace/admin/strategies/{slug}/reject` — Reject with reason
- `POST /v1/marketplace/admin/strategies/{slug}/request-changes` — Request changes
- `POST /v1/marketplace/admin/strategies/{slug}/suspend` — Suspend published strategy

#### Compliance
- `POST /v1/marketplace/tax/preview` — Tax calculation preview (pre-purchase FTC transparency)
- `GET /v1/marketplace/developer/payout-eligibility` — Developer payout eligibility check
- `POST /v1/marketplace/developer/withholding-preview` — FATCA withholding preview
- `GET /v1/marketplace/admin/geo-block-status` — Geo-blocking config (admin only)

### MCP Server (FastMCP)

The MCP server is structured as a package (`finlet/mcp/`) with domain-grouped tool modules (~645 lines in `server.py`, down from 1,011 after Phase 3 consolidation). The main `server.py` is a thin registration layer that imports and registers tools from focused modules:

- `mcp/server.py` — Server setup and tool registration only (~645 lines). The duplicate `_resolve_user_record` helper that briefly lived here in early Phase 4c (Surprise A/B) was removed by Team C2; the canonical `_resolve_user_record` lives in `finlet/auth/deps.py`.
- `mcp/auth.py` — MCP authentication. `_authenticate_oauth_or_key(bearer) -> tuple[str, str, OAuthClaims | None]` is the canonical Bearer resolver: OAuth JWT first, Bearer `fnlt_*` API key fallback. Legacy `_authenticate(api_key)` is preserved as a primitive for non-MCP callers (REST, CLI verification, tests). Session helpers (`_get_session()`, `_default_session_id()`, `_resolve_session()`) are unchanged. Phase 4c's `enforce_scope(claims, required, user_record)` remains the OAuth scope gate; `claims=None` bypasses on the Bearer api_key compatibility path.
- `mcp/bearer_context.py` — Bearer extraction + legacy argument rejection. `BearerContextMiddleware` is the ASGI middleware that writes incoming `Authorization: Bearer <token>` to a ContextVar; `resolve_credential(tool_name, bearer, api_key)` is the read-side resolver consumed by tool bodies. It returns `_API_KEY_REJECTED_MESSAGE` when bearer is None and legacy tool-argument `api_key` is non-None, and the canonical "Authentication required" envelope when both are None.
- `mcp/stdio_proxy.py` — Default `finlet mcp serve` transport. Provides a local stdio server that lists/calls hosted `/mcp` tools with an Authorization header derived from `~/.finlet/credentials` or `FINLET_API_KEY`.
- `mcp/tools_session.py` — Session lifecycle tools (create, list, get, delete, complete)
- `mcp/tools_market.py` — Market data tools (price, news, fundamentals, filings, economic)
- `mcp/tools_trading.py` — Trading tools (submit_order, cancel_order). **Delegates to `trade_service`** for order submission, gaining universe validation and atomic persistence — eliminating the prior logic duplication between MCP and REST. **Phase 2 Team C (2026-05-07):** the `submit_order` tool now resolves a `UserRecord` and passes it into the service so MCP inherits the per-user trade rate gate (`check_trade_rate`), the idempotency cache (no-op for MCP — no header-equivalent on stdio), `record_trade_request` post-success, and the rich-shape response (commission / slippage_amount / total_cost). The MCP tool returns the service dict directly — closing audit H6 (previously the bare `to_dict(result)` shape was missing those cash-disclosure fields). `HTTPException(429)` from the gate is converted to the MCP-shallow envelope (`{"error": "<message>"}`) via `ServiceError(...).to_mcp_shallow()` so existing pattern-match-on-string consumers keep working.
- `mcp/tools_portfolio.py` — Portfolio query tools (get_portfolio, get_equity_curve, get_trace)
- `mcp/tools_clock.py` — Clock/time tools (get_sim_time, advance_time, freeze_time). **Delegates to `clock_service`** for advance/freeze operations.
- `mcp/tools_benchmark.py` — Benchmark tools (start_benchmark, get_benchmark_progress, export_benchmark_results)
- `mcp/tools_telemetry.py` — Telemetry tools (`report_bug`) for agents to file structured bug reports against the Finlet tool surface; storage delegated to `finlet/telemetry/bug_storage.py` (boto3 + JSON to S3 bucket `finlet-bug-reports`, follows the `GdprS3Storage.upload_archive` precedent rather than the `S3ParquetWriter` data-lake-shaped pattern).
- `mcp/_instance.py` — Shared MCP app instance

20 tools across four categories (post 2026-05-19 — `report_bug` added under Diagnostics/Telemetry; `set_session_visibility` added under Session Lifecycle 2026-05-12):

**Authentication (v2 current):** Every authenticated MCP tool routes through `resolve_credential(tool_name, bearer, api_key)` in `finlet/mcp/bearer_context.py`, which delegates to `_authenticate_oauth_or_key` in `finlet/mcp/auth.py`. OAuth JWT Bearer is validated by `validate_bearer_jwt()` (EdDSA-pinned, audience-bound to `https://finlet.dev/mcp`, scope-checked via `enforce_scope()`); Bearer `fnlt_*` API keys fall back to `auth_service.validate_key()` and return `claims=None`. MCP tool signatures still carry `api_key: str | None = None` for call-site stability, but the argument is silently ignored when a Bearer is present and triggers a documented rejection envelope (`_API_KEY_REJECTED_MESSAGE`) when only an api_key argument is supplied. Unauthenticated access (neither credential) returns the canonical "Authentication required" envelope. The resolved Bearer path maps to a `UserRecord` (per `docs/decisions/mcp-oauth-2-1-auth-model.md` §4) so MFA, rotation, tier, and the existing session-ownership invariants carry over. The REST `/v1/...` surface is unchanged — api_key remains a valid REST credential for the dashboard, CLI bootstrap, and webhook callbacks.

**Session ownership:** `list_sessions` filters results by the authenticated user's `user_id`. `_get_session()` enforces ownership — users can only access their own sessions.

**Session resolution (audit C3, Phase 1 — 2026-05-07):** All MCP tools that resolve a session by id (or auto-resolve when omitted) call the `_resolve_session(session_id, user_id) -> tuple[Session, str] | dict` helper in `finlet/mcp/auth.py`. The helper wraps `_default_session_id()` + `_get_session()` and converts their `ValueError` failures (not-found, wrong-owner, no/multiple sessions) into `{"error": "..."}` dicts. Raw `ValueError` raised from a FastMCP tool body becomes an unrecoverable protocol-level error — agents pattern-match on dict shape, so the helper is mandatory for any tool that takes a `session_id`. `_get_session` and `_default_session_id` are kept as primitives for use **inside** `_resolve_session` (and re-exported from `mcp/server.py` for tests that exercise raw exception paths). The rule is codified in `.claude/rules/mcp-server.md`.

**Session-id format validation (Phase 2 Team A, audit C1 prep — 2026-05-07):** `_get_session` in `finlet/mcp/auth.py` calls `validate_session_id(session_id)` from `finlet.db.models` before lookup, matching the REST-surface validation. A malformed session id (wrong length, illegal chars) now raises `ValueError` from `validate_session_id` rather than silently missing the lookup, and `_resolve_session` converts it to the standard agent-readable `{"error": "..."}` shape. This closes a parity gap where REST returned 422 and MCP returned 404 for the same input.

**Session Lifecycle (6 tools):**
- `create_session` — Create a simulation session (name, start_time, capital, universe, commission, slippage_bps, etc.). The `commission` and `slippage_bps` parameters are now exposed in the MCP tool, allowing agents to configure transaction costs at session creation.
- `list_sessions` — List sessions with optional status filter. Excludes completed sessions by default. Filtered by authenticated user.
- `get_session` — Get detailed session state. Auto-resolves to the only session when just one exists. Enforces ownership.
- `delete_session` — End and clean up a session (stops continuous mode, removes from store, deletes DB files). **Refuses with structured `session_is_benchmark_current` error when the target session is a benchmark's `current_session_id`** (Codex bug `ce8de077`, 2026-05-19 — Team A); agents must call `complete_session` (advance scenario) or `delete_benchmark_run` (abandon run) instead. See `docs/decisions/complete-session-benchmark-idempotency.md`.
- `complete_session` — Seal a session (freezes clock, seals reasoning trace, sets status to COMPLETED). Returns session summary with final portfolio value, total return, trade count, and simulation time range. Truly idempotent — repeat calls return the original `benchmark_transition` envelope rebuilt from the recorded `ScenarioResult` instead of double-advancing (Codex bug `ce8de077`, 2026-05-19 — Team A; see `docs/decisions/complete-session-benchmark-idempotency.md` Invariant 1).
- `set_session_visibility(session_id, public, anonymous=True)` — Owner-only visibility toggle. Mirrors `PATCH /v1/sessions/{id}/visibility` and delegates to the same `session_service.set_visibility()` helper. Returns the session response with updated `public` + `public_anonymous` flags. The MCP tool deliberately does NOT return a `share_url` field; consumers derive the share URL as `https://finlet.dev/sessions/{id}` from the returned `session_id` (decision: `docs/decisions/v2-pure-mcp-migration.md`; anti-shape-drift test in `tests/mcp/test_decrypt_visibility_tools.py`). Standard MCP Bearer auth via `_authenticate_oauth_or_key` + `_resolve_session`. See `docs/decisions/session-public-visibility.md`.

**Market Data (6 tools):**
- `get_price_data` — Only daily (`1d`) and weekly (`1w`) intervals are supported in v1. Intraday intervals (e.g., `1h`, `5m`) are rejected with an actionable error listing allowed intervals.
- `search_news`, `get_fundamentals`, `get_filings`, `get_economic_data`
- `list_available_tickers` — Returns every ticker in the universe with `has_prices` and `has_fundamentals` availability flags, per-ticker coverage dates (`earliest_price_date`, `latest_price_date`, `earliest_fundamentals_date`, `latest_fundamentals_date`, `fundamentals_filings_count`), and a `cached_at` timestamp. Delegates to the same shared `get_ticker_availability()` helper as `GET /market/tickers`, so both paths share the same 1-hour cache, efficient S3 probing, and manifest sidecar rollup. Agents should call this before `create_session` to validate data availability for the chosen universe and start date. Authenticated through the standard MCP Bearer resolver.

**Fundamentals time-distance guard:** `get_fundamentals` checks the distance between the simulation clock and real wall-clock time. If the sim time is more than 30 calendar days from real time, the request is rejected with an actionable error explaining that fundamentals data may be inaccurate at that distance. When within 30 days, responses include a `_data_warning` field noting the potential for temporal mismatch.

**Data warning propagation:** Warnings generated by plugins (e.g., `NON_POINT_IN_TIME_DATA` from Finnhub fundamentals) are propagated through both REST and MCP responses to callers. `market_service.route_query()` includes a `warnings` array extracted from `PluginResponse.metadata["data_warnings"]`. MCP tool responses include the same `warnings` field. Empty warnings array `[]` when no warnings are present — never `None`.

**Trading & Clock (5 tools):**
- `submit_order`, `get_portfolio`
- `get_sim_time`, `advance_time`, `freeze_time`

**Benchmark (3 tools):**
- `start_benchmark` — Start a benchmark run (see Benchmark Flow below)
- `get_benchmark_progress` — Check benchmark run progress
- `export_benchmark_results` — Export structured results for a completed benchmark run. Returns agent metadata, composite score, rank, and per-scenario breakdown (return, sharpe, drawdown, trades, win rate). Only works for completed runs owned by the authenticated user.

**Structured error envelope on benchmark tools (MCP_BENCHMARK_FIXES, 2026-05-19 — Team A `1979a20`):** Every error return on the 3 benchmark tools now routes through `structured_error(code, message, **extra)` in `finlet/mcp/_errors.py`, yielding `{"error": {"code": "<snake_case>", "message": "<human text>", **extra}}`. The top-level `"error"` key is preserved so legacy `if "error" in result` callers still detect failure; the value migrates from `str` to `dict`. For error paths that occur on a session (start-benchmark lockout, get-progress active-run), the envelope includes a `resume_hint` extra carrying the full canonical metadata an agent needs to resume: `session_id`, scenario `end_time`, `universe`, `initial_capital`, clock `current_time`, portfolio `cash`. The same canonical shape is returned from `get_benchmark_progress` on success — single source of truth across error and success paths. Adjacent MCP tool surfaces (`tools_session`, `tools_portfolio`, `tools_market`, `auth.py`, `bearer_context.py`) continue to return flat strings; migrate when touched for another reason. See `docs/decisions/2026-05-19-mcp-structured-error-envelope.md`.

**Diagnostics & Telemetry (2 tools):**
- `get_trace` — Retrieve the reasoning trace for a session with optional filtering by `action_type` and `limit`
- `report_bug(category, summary, context, tool_called, error_payload)` — Agent-callable bug-report tool added 2026-05-19 for the AI-quantamental dogfooding strategy (also usable by any authenticated agent). Persists a JSON record `{report_id, timestamp_utc, agent_user_id, category, summary, context, tool_called, error_payload}` to S3 bucket `finlet-bug-reports` under prefix `bug-reports/YYYY/MM/DD/<report_id>.json` (configurable via `FINLET_BUG_REPORTS_BUCKET`). Categories: `unexpected_response`, `malformed_data`, `anomaly`, `tool_error`, `other`. Storage helper lives at `finlet/telemetry/bug_storage.py` and mirrors `GdprS3Storage.upload_archive` — boto3 `put_object` with `ContentType: application/json`, no `S3ParquetWriter` manifest discipline (manifest sidecars are for data-lake-shaped writes, not single-shot telemetry artifacts). **Scope: `finlet:read` (NOT a new `finlet:telemetry` scope)** — see `docs/decisions/ai-quantamental-subproject-v1.md` for the rationale. Filed reports are reviewed post-hoc by humans; no auto-triage / no public submission / no real-time alerting in v1.

`advance_time` automatically refreshes portfolio prices and fills pending orders after advancing the clock. If price refresh or order filling fails, it logs a warning and returns `fill_summary: {prices_updated: 0, orders_filled: 0}` alongside the clock result. Both `advance_time` and `freeze_time` MCP tools acquire `session._tick_lock` around state mutations, matching the REST clock endpoints and preventing race conditions from concurrent MCP calls.

**Layered locking in `advance_time` (audit C2, Phase 1 — 2026-05-07):** All three branches (single-step, `steps>1` batch, `target_date`) split into two phases under different lock scopes. The clock-step phase (`session.step()` / `session.step_to()`) runs **inside** an outer `async with session._tick_lock`, serializing two concurrent `advance_time` calls. The fill phase (`refresh_prices_and_fill_orders` → `Session.process_pending_orders`, plus persistence) runs **outside** the outer lock — `Session.process_pending_orders` already acquires `_tick_lock` internally, and `asyncio.Lock` is non-reentrant, so a naive single-lock wrap deadlocks. Two concurrent batches still cannot fill the same order twice — they queue at the inner lock. A new helper `_post_step_persist_and_fill(session, sid, state, trace_count_before)` in `finlet/mcp/server.py` factors the post-step half so the single-step and `steps>1` branches share one implementation. See `docs/decisions/advance-time-layered-locking.md`.

**Snapshot-clock isolation via `committed_time` (Codex bug `dc4daf5a`, 2026-05-22):** Responses that return BOTH a clock time AND a portfolio snapshot (or fill-summary, or order timestamps, or price-query ceiling) capture `committed_time = session.clock.get_time()` INSIDE the `_tick_lock` slice and thread it forward — live reads of `session.clock.get_time()` for response-shape fields after lock release are forbidden because a parallel `advance_time`/`step`/`step_to` can race the read and tear the response (outer `current_time` != inner `fill_summary.snapshot.timestamp` != `order.filled_at`). The `committed_time` kwarg is threaded through (a) `_post_step_persist_and_fill(..., committed_time=...)` (MCP, all 3 advance_time branches), (b) `refresh_prices_and_fill_orders(session, *, committed_time=...)` (clock service), and (c) `Session.process_pending_orders(prices, *, sim_time=...)` (core) — which drives the price-plugin ceiling, 30-day fallback start date, snapshot timestamp, DAY-order expiry checks, `order.filled_at` stamps, and the benchmark-progress log line. `Session.reject_unfillable_orders` is OUT OF SCOPE per Codex BLOCKER #3 (clock-service save-loop invariant). New backstop `_assert_clock_snapshot_consistency(result_dict)` in `finlet/mcp/server.py` runs at every `_post_step_persist_and_fill` + target-date + batched-steps return path; env-gated `FINLET_CLOCK_CONSISTENCY_ASSERT` (`raise` in CI/tests — set by default via `tests/conftest.py:pytest_configure` `os.environ.setdefault`; `log` in prod default). See `docs/decisions/advance-time-snapshot-isolation.md`.

**Batch advance (`advance_time`):** The MCP tool accepts two new optional parameters that wrap the REST `/sessions/{id}/clock/step-to` endpoint so agents can jump long distances in a single call instead of making hundreds of sequential hops:
- `steps: int = 1` — Advance by N intervals in a single batched call. Loops `clock_service.advance_session()` internally and aggregates fill totals. Mutually exclusive with `target_date`.
- `target_date: str | None = None` — Advance directly to a specific date (`YYYY-MM-DD`). Calls `session.step_to()` + `refresh_prices_and_fill_orders()` inline and returns a summary with `start`, `end`, `days_advanced`, and `prices_fetched`. Mutually exclusive with `steps > 1`. Invalid formats are rejected with an actionable error.

Agents reach this surface through the `advance_time` MCP tool — supplying `steps: int` for N intervals or `target_date: str` for direct date targeting (mutually exclusive). The REST surface mirrors via `POST /sessions/{id}/clock/step` (single step) and `POST /sessions/{id}/clock/step-to` (batched / target date). For large (>30 day) jumps the server uses a two-hop pattern — `skip_price_fetch=true` to T-1, then a normal `step-to` to T so the final advance still fills orders and refreshes prices.

**MCP durability parity:** All state-mutating MCP operations persist identically to their REST equivalents. `submit_order` persists the order, session, and trace entry. `cancel_order` persists the order and session. `advance_time` persists the session and snapshot. This ensures no data loss when agents interact via MCP instead of REST.

**MCP rate limiting (audit C1, H4 — Phase 2, 2026-05-07):** MCP data tools enforce the same per-user rate limits as REST by delegating to `market_service.route_query()`. The service fires the per-user market-data gate AND the per-user Finnhub plugin gate (for `news` / `fundamentals`) before the plugin call, and records the request after. The MCP `_query_plugin` envelope in `finlet/mcp/server.py` preserves `rate_limit_remaining` and `rate_limit_reset` from the service response — closing audit H4, which previously dropped those fields and forced agents to guess their remaining quota. 429 failures are converted via `ServiceError(...).to_mcp_shallow()` so existing MCP tests that pattern-match on `isinstance(result["error"], str)` keep working.

Each tool has a clear description helping LLMs understand when to use it, with example parameter values.

### API Module Structure

Large route and service files have been split into focused modules:

- `api/routes_auth.py` split into `routes_auth_credentials.py` (login, register, password reset) and `routes_auth_sessions.py` (session management, token refresh)
- `api/routes_email.py` split into `routes_email.py` (email routes), `routes_notifications.py` (notification routes), and `services/email_token_service.py` (token generation/verification)
- `api/routes_marketplace_developer.py` split into `routes_marketplace_onboarding.py` (developer onboarding) and `routes_marketplace_strategy.py` (strategy management)
- `api/email_service.py` split into `email_service.py` (orchestration) and `email_providers.py` (SES, console provider implementations)

### Service Layer (Phase 3 — 2026-04-01; cross-cutting gates absorbed in Phase 2 — 2026-05-07)

Routes follow the **Routes -> Services -> Repos** pattern: route handlers parse HTTP concerns (auth, request validation), delegate business logic to service functions, and return Pydantic response models. The billing domain (`routes_billing.py` -> `billing/service.py` -> `schemas/billing.py`) is the reference implementation.

**Phase 2 of MCP-First Migration (2026-05-07) sank the four cross-cutting gates into the service layer** so REST and MCP surfaces inherit identical gating by construction. Pre-Phase-2, the gates lived in route handlers and MCP tools called the service directly — `MCP -> service -> business logic` skipped every gate that was logically a billing/safety concern. This was a billing-bypass: per-tier session-creation limits, per-user trade rate, per-user market-data rate, and per-user Finnhub plugin rate did not apply when an agent reached Finlet via MCP instead of REST. After Phase 2, the gate fires inside the service; both surfaces consume the same `ServiceError`-shaped failure. See `docs/decisions/mcp-billing-bypass-closed.md` for the full audit C1 closure record.

**Cross-surface error envelope (`finlet.api.services.errors.ServiceError`):** frozen Pydantic model `ServiceError(code: int, message: str, details: dict | None)` with three converters — `to_http_exception()` for REST, `to_mcp_dict()` for the nested MCP envelope (`{"error": {"code", "message", "details"}}`), and `to_mcp_shallow()` for the legacy flat shape (`{"error": str}`) consumed by Phase 1 callers (`_resolve_session` and ~30 MCP tests that pattern-match `isinstance(result["error"], str)`). New MCP tools should default to `to_mcp_dict()`; the shallow form is back-compat only. See `docs/decisions/service-layer-error-envelope.md`.

**Service modules:**

| Service | Location | Responsibility |
|---------|----------|----------------|
| `session_service` | `api/services/session_service.py` | Session CRUD, `pause_session()`, `resume_session()`, `complete_session()`, response building. **Phase 2:** owns the per-tier session-creation rate gate (`check_session_creation_rate` + `record_session_creation`). REST and MCP both call the service; the gate fires inside. Session-create idempotency (24h replay cache, `Idempotency-Key` header) intentionally stays in `routes_session.py` — REST-specific defense-in-depth; FastMCP has no equivalent header transport over stdio. |
| `clock_service` | `api/services/clock_service.py` | Clock operations, `advance_session()` (step + refresh + persistence), `freeze_session()`, price refresh and order fills. **Position price fallback:** `refresh_prices_and_fill_orders()` unions the pending-order ticker set with the open-position ticker set before fetching quotes, and falls back to a 30-day history query for any ticker whose live quote returns empty. Position tickers fall back even when the per-ticker circuit breaker is OPEN, so portfolio valuation continues to update even when new orders cannot be placed against that symbol. A `position_price_fallback` structlog warning is emitted whenever a position's `current_price` came from history instead of a live quote. |
| `trade_service` | `api/services/trade_service.py` | Order submission with auto-fill, universe validation, atomic persistence. **Phase 2:** owns the per-user trade rate gate (`check_trade_rate` + `record_trade_request`) and the trade idempotency cache (`_idempotency_store`, module-level singleton). MCP `submit_order` delegates to the service and returns the rich `order_dict(...)` shape directly (commission / slippage_amount / total_cost) — closes audit H6, which previously stripped those cash-disclosure fields by calling `to_dict(result)` instead. |
| `market_service` | `api/services/market_service.py` | Plugin-routed market data queries with enforcer wrapping. **Phase 2:** owns the per-user market-data rate gate (`check_market_data_rate`) AND the per-user Finnhub plugin rate gate (`check_plugin_rate` for `news` / `fundamentals`). The frozenset constants `_NON_TEMPORAL_PLUGIN_TYPES`, `_NON_TEMPORAL_ACTIONS`, and `PLUGIN_RATE_LIMITED_TYPES` are owned here as the single source of truth — re-defining them in `routes_*.py` or `mcp/` is forbidden (rule codified in `.claude/rules/api-routes.md`). The MCP envelope returned by `_query_plugin` preserves `rate_limit_remaining` and `rate_limit_reset` — closes audit H4, which previously dropped those fields. |
| `settings_service` | `api/services/settings_service.py` | Profile CRUD, plugin config, API key management, notification preferences |
| `onboarding_service` | `marketplace/onboarding_service.py` | Developer onboarding orchestration, step enforcement, Stripe Connect flow |
| `admin_service` | `marketplace/admin_service.py` | Review queue management, approval/reject workflow, status transitions |
| `leaderboard_service` | `leaderboard/service.py` | Leaderboard cache management, profile ranking, benchmark job orchestration |

**Cross-surface gate parity (regression bar):** `tests/services/test_gate_unification.py` (Team E, Phase 2) asserts that REST and MCP share limiter state — a 429 raised on one surface immediately throws on the other. New gate-bearing service functions MUST extend this file with a parity case before merge. The four parity assertions (session-creation, trade rate, market-data rate, Finnhub plugin rate) are the hard regression bar against future drift.

### MCP Consolidation (Phase 3 — 2026-04-01)

The MCP `server.py` was reduced from 1,011 to ~645 lines by extracting duplicate tool implementations into focused modules and delegating to the service layer:

- **Removed duplicates:** `get_portfolio`, `get_equity_curve`, `get_trace`, `submit_order`, `cancel_order` — inline implementations in `server.py` replaced by imports from `tools_portfolio.py` and `tools_trading.py`
- **New delegation:** `pause_session`/`resume_session` delegate to `session_service`, `advance_time`/`freeze_time` delegate to `clock_service`
- **Auth extraction:** `_authenticate()` and `_get_session()` moved to `mcp/auth.py`
- **Instance extraction:** Shared MCP app instance moved to `mcp/_instance.py`

All MCP tools now delegate to the same service layer as REST endpoints, eliminating logic duplication and ensuring identical behavior.

### Response Models (Phase 3 — 2026-04-01)

75 API endpoints now have Pydantic `response_model` declarations via `finlet/api/schemas/` modules. Response shapes are validated by Pydantic on every request, generating accurate OpenAPI schema documentation.

**Schema modules (16 total):**

| Module | Endpoints Covered |
|--------|-------------------|
| `schemas/auth_credentials.py` | Register, login, password reset/set, /me, research network (8) |
| `schemas/auth_mfa.py` | MFA setup, verify, disable (pre-existing) |
| `schemas/auth_sessions.py` | Auth config, session create/delete/validate (4) |
| `schemas/billing.py` | Checkout, portal, subscription, usage, invoices (pre-existing) |
| `schemas/clock.py` | Clock state, step, step-to, freeze, play, stop (6) |
| `schemas/email.py` | Verify, reset, process reset, preferences (4) |
| `schemas/health.py` | Health check, plugin health, rate limits (3) |
| `schemas/leaderboard.py` | Rankings, submit, agent profile, scenarios (5) |
| `schemas/marketplace_admin.py` | Review queue, approve/reject/changes/suspend, create/submit strategy (9) |
| `schemas/marketplace_developer.py` | Developer request models (pre-existing) |
| `schemas/marketplace_onboarding.py` | Onboarding status, profile, register, compliance, Stripe, tax, guidelines (9) |
| `schemas/notifications.py` | Preferences, unsubscribe (3) |
| `schemas/portfolio.py` | Portfolio state, history, trace (3) |
| `schemas/session.py` | Session CRUD, configure, complete (6) |
| `schemas/settings.py` | Profile, password, API keys, plugins, notifications, export, delete (13) |
| `schemas/trade.py` | Order submit, list, detail, cancel (4) |

All schemas are re-exported via `finlet/api/schemas/__init__.py` with alias resolution for name conflicts (e.g., `ResetPasswordResponse` exists in both `auth_credentials` and `email` modules).

**Remaining (deferred):** 6 minor endpoints (admin cache, CSP reports, legal disclaimers) and special response types (SSE, metrics, market data JSONResponse) are out of scope.

### CLI (typer)

**v2.0.0 (2026-05-22) — Pure-MCP cutover.** The agentic CLI surface (`session create/list/delete/publish`, `benchmark start/progress/decrypt/visibility`, `advance`, `order`, `portfolio`, `status`) has been **deleted**. Agents drive Finlet through the MCP tool surface invoked by the agent host's MCP client; the `finlet` binary is now the minimal bootstrap shell that mints credentials, hosts the MCP stdio bridge, and manages plugin credentials and the local manual. See `docs/decisions/v2-pure-mcp-migration.md` for the rationale and scope.

The kept commands are:

- `finlet serve` — Start API server + serve dashboard. API URL is configurable via `FINLET_API_URL` environment variable (default: `https://finlet.dev`). Server dependencies are optional — in the thin client distribution, `finlet serve` prints a graceful error ("Server mode requires the full Finlet installation") instead of an ImportError traceback. Powers the prod EC2 unit (`systemctl restart finlet.service`).
- `finlet mcp serve` — Default stdio bridge to hosted `/mcp`. Agent hosts (Claude Desktop, Cursor, Codex CLI, Windsurf, VS Code MCP, custom) spawn this binary and exchange JSON-RPC over stdio. The CLI resolves `~/.finlet/credentials`, refreshes OAuth tokens near expiry, or falls back to `FINLET_API_KEY` for headless runs, then `finlet/mcp/stdio_proxy.py` forwards tool calls to hosted `/mcp` with an Authorization header. This is the canonical no-env client config.
- `finlet mcp serve --self-host` — Local FastMCP stdio server for operators running their own API/auth/database stack. Boots FastMCP, hydrates `auth_service._keys` via `auth_service.load_all()` BEFORE the runloop starts so the Bearer JWT validator's `get_by_id(claims.sub)` lookup succeeds in this fresh subprocess, and uses the same normalized credential fallback path as the hosted bridge. Logging is steered to `stderr` BEFORE importing `finlet.mcp.server` so JSON-RPC framing on `stdout` is not polluted by import-time log lines.
- `finlet register --email user@example.com` — Register a new account and receive an api_key. Calls `POST /auth/register` via httpx. The api_key is the headless / CI bootstrap credential; for interactive setup, prefer `finlet auth login` immediately after.
- `finlet auth login` — OAuth 2.1 + PKCE Authorization Code flow (Phase 4d, shipped 2026-05-09 — commit `061128a`). Spawns a loopback HTTP listener on a random ephemeral port per RFC 8252 §7.3, opens the system browser to `${FINLET_API_URL}/oauth/authorize?...&code_challenge=...&code_challenge_method=S256&resource=https://finlet.dev/mcp&client_id=finlet-cli`, captures the `?code=...&state=...` callback, exchanges the code at `POST ${FINLET_API_URL}/oauth/token` (PKCE verifier check, single-use), and persists `{access_token, refresh_token, expires_at}` to `~/.finlet/credentials` with POSIX mode 0600 enforced atomically via `os.open(path, O_CREAT|O_WRONLY|O_TRUNC, 0o600)`. The CLI ships a hardcoded `client_id = "finlet-cli"` (Option A — public OAuth client per RFC 7591, no `client_secret`, PKCE-only). Audit C4 invariant: verification only, never minting. Refresh-token rotation is out of scope for the MVP — when the 15-minute access token expires, the user re-runs `finlet auth login` to mint a fresh pair. See `docs/decisions/auth-login-cli-vs-api-key.md` (with Phase 4d addendum) and `docs/decisions/mcp-oauth-2-1-auth-model.md` §5 for the token-storage contract.
- `finlet auth logout` — Delete `~/.finlet/credentials` if present (idempotent otherwise). Does NOT call a server-side `/oauth/revoke` endpoint — server-side revocation is a future improvement; the refresh token's 90-day absolute lifetime + 30-day sliding-inactivity window per decision record §5 bounds the credential lifetime even without explicit revocation.
- `finlet auth status` — Report local credential state (present / mode / expiry). Exit code `EXIT_AUTH_REQUIRED = 2` when no credential is found so shell scripts can distinguish "no credential" from "API down."
- `finlet plugins list` — Show installed plugins and status via `GET /v1/plugins/health` (the same endpoint the dashboard's Plugin Health panel consumes). Operator/dashboard surface, not agent surface; there are no MCP tools for tenant plugin-credential reads/writes. Degrades gracefully (exit 1 + "Cannot connect" message) when the API is unreachable.
- `finlet plugins add finnhub --api-key=KEY` — PUTs to `/v1/settings/plugins`. Exit code `EXIT_AUTH_REQUIRED = 2` on auth-missing for shell-script integration.
- `finlet plugins remove <name>` — Clears credentials via empty PUT to `/v1/settings/plugins`. Surfaces the post-reload health status from the response. `PluginConfigUpdate.email` accepts empty string as a clear sentinel — see `docs/decisions/email-validator-empty-string-clear.md`.
- `finlet manual [topic]` — Local markdown topic viewer (offline). Topics: `quickstart`, `auth-model`, `session-lifecycle`, `plugin-matrix`, `transports`, `client-matrix`, `errors`. `--list` enumerates; `--format=json` emits the structured render contract from `finlet/manual/registry.py:topic_to_json`.
- `finlet --version` — Diagnostics.

The v1.0.1 cloud `/mcp` endpoint (FastMCP `streamable_http_app` mounted at `/mcp` on the FastAPI app and wrapped with `BearerContextMiddleware`) remains live for direct REST/MCP-over-HTTP consumers; that surface is unchanged. The v2.0.0 cutover only removes the human-facing CLI dispatch shim — the agent surface is unchanged.

**KEEP commands' auth path** continues to use the Bearer-first credential precedence in `_api_headers()` (CLI helper, shipped 2026-05-09 in Phase 4d/D1, commit `061128a`): if `~/.finlet/credentials` is present and parseable, the OAuth access token is sent as `Authorization: Bearer <jwt>`; otherwise the helper falls back to the `--api-key` flag or `FINLET_API_KEY` environment variable as `Authorization: Bearer <api_key>`. The CLI targets the server at `FINLET_API_URL` (default: `https://finlet.dev`). On every read, `_load_credentials()` re-checks the file's POSIX mode and raises `RuntimeError` if it has drifted to anything looser than 0600, with a remediation message naming `chmod 600` and `finlet auth logout && finlet auth login`. Errors from the API are printed as structured messages via `_print_error()` helper. **Structured error envelope precedence (audit H7, Phase 1 — 2026-05-07):** `_print_error` reads `error.message` first from the canonical server envelope `{"error": {"code", "message", "details"}}`, then falls back to legacy `detail`, then `response.text`, then `str(e)`. The `error.message` path is the canonical agent/CLI-readable surface — new error sites should populate it directly via the centralized envelope, not via custom shapes.

**MCP stdio credential refresh:** `_resolve_mcp_stdio_credential()` in `finlet/cli.py` is the credential getter consumed by `finlet mcp serve`. Before the hosted stdio proxy starts, it checks `expires_at - now()` against a 60-second safety margin; if the token is near expiry, `_refresh_oauth_credentials()` POSTs to `${FINLET_API_URL}/oauth/token` with `grant_type=refresh_token`, persists the rotated pair atomically to `~/.finlet/credentials` (mode 0600 preserved via `_write_credentials()` helper), and returns the fresh access token. If refresh fails but the current token is still valid, the bridge warns and uses it; if the token is expired, the user reruns `finlet auth login`. Headless runs fall back to `FINLET_API_KEY`.

**`finlet manual` subcommand (USER_MANUAL_OVERHAUL, 2026-05-15):** offline-first agent + operator documentation surface. The CLI ships seven topics (`quickstart`, `auth-model`, `session-lifecycle`, `transports`, `client-matrix`, `plugin-matrix`, `errors`) plus a generated index. Modes: `finlet manual` (list), `finlet manual --list`, `finlet manual <topic>` (render body), `finlet manual --search <kebab>` (kebab-case keyword search over titles + bodies), `finlet manual --format=json` (structured `{topic, version, sections, see_also}` render — locked schema), `finlet manual errors#<anchor>` (anchor-scoped render — same data, filtered by `<a id="...">` marker). Topics are Markdown files shipped inside the `finlet.manual` package (loaded via `importlib.resources.files`, equally at home in a source checkout and an installed wheel — see `pyproject.toml` `[tool.hatch.build]` `artifacts = ["finlet/manual/*.md"]`). 10 existing command docstrings gained see-also footers pointing at the relevant topic (e.g. `auth login` → `manual auth-model`, `order` → `manual errors#order-rejected`). The `mcp serve` docstring is reworded OAuth-first to match the post-Phase-4e auth contract. Errors topic is the canonical anchor namespace — see the Error Handling section below and `docs/decisions/error-anchor-convention.md`.

### Manual / Topic Registry (`finlet/manual/`)

The `finlet/manual/` package is the canonical knowledge base shipped inside every `pip install finlet`. Seven topic files, a deterministic generator, a frozen anchor namespace.

- **`registry.py`** — `TOPIC_REGISTRY: dict[str, TopicMeta]` is the load-bearing ordering. `TopicMeta` rows carry `name` (kebab-case CLI argument), `filename` (Markdown sibling), `summary` (one-sentence description for `--list`), `see_also` (cross-references). Module exposes four helpers: `list_topics()`, `get_topic(name)`, `search(query)`, `topic_to_json(name)` (structured `{topic, version, sections, see_also}`). `CONTENT_VERSION = "1"` bumps when the schema changes — agents can refuse stale renders.
- **Topic files** (Markdown, shipped via hatchling artifacts): `quickstart.md`, `auth-model.md`, `session-lifecycle.md`, `transports.md`, `client-matrix.md`, `plugin-matrix.md`, `errors.md`. Body lazy-loaded via `importlib.resources.files("finlet.manual") / filename`.
- **`errors.md` — 13 frozen kebab-case anchors.** Each anchor (`<a id="..."></a>` marker + `##` heading) is one recoverable error class: `rate-limit`, `expired-token`, `missing-bearer`, `missing-scope`, `missing-api-key`, `plugin-timeout`, `plugin-malformed`, `plugin-rate-limit`, `transport-mismatch`, `port-conflict`, `date-ceiling-violation`, `invalid-session`, `order-rejected`. The 13 IDs are frozen by snapshot test (`tests/test_manual.py`) — renaming is a breaking contract change. Every agent-facing error envelope across REST/billing/OAuth/MCP/plugins ends with the literal suffix `See: finlet manual errors#<anchor>` so a triage agent can route the same recovery doc regardless of which subsystem surfaced the failure. ~200 anchor-suffixed sites total. Decision record: `docs/decisions/error-anchor-convention.md`.
- **`generate_llms_txt.py`** — deterministic generator that renders `dashboard/llms.txt` from `TOPIC_REGISTRY`. Two modes: `--write` (regenerate in place; authoring path) and `--check` (re-render into a buffer + diff against on-disk; CI + pre-commit gate). Same registry + same content → same bytes including trailing newlines. Drift-gated at three layers: pre-commit hook (4th guard, after trusted-types / event-bus / form-dirty), CI lint step in `.github/workflows/ci.yml`, and the `--write` one-command remediation. Decision record: `docs/decisions/dashboard-llms-txt-regen-pipeline.md`.
- **Test gates.** `tests/test_manual.py` (snapshot + anchor freeze), `tests/test_manual_generate_llms_txt.py` (generator idempotency + drift detection), `tests/test_cli_help.py` (`finlet manual` subcommand contract), and per-surface `tests/api/test_error_anchors.py` + `tests/billing/test_error_anchors.py` + `tests/auth/oauth/test_error_anchors.py` + `tests/plugins/test_error_anchors.py` (every error envelope carries a valid `See: finlet manual errors#<anchor>` suffix).

### PyPI Thin Client Distribution

Finlet ships a thin client package to PyPI (`pip install finlet`) that provides the CLI and connects to finlet.dev without requiring the full server stack.

**Base dependencies (thin client):** `typer`, `httpx`, `mcp>=1.27.0`, `rich`. The `mcp` runtime (no `[auth]` extras) ships in base since v1.0.0 BLOCKER #1 (2026-05-11) so that `pip install finlet` produces a CLI that can spawn `finlet mcp serve` over stdio without requiring the `[server]` extras — the thin-client `finlet mcp` Typer sub-app no longer hits `ModuleNotFoundError: mcp` on import.

**Server dependencies (`pip install finlet[server]`):** `fastapi`, `uvicorn`, `sqlmodel`, `aiosqlite`, `mcp[auth]>=1.27.0` (auth extras add `joserfc` etc. for OAuth AS minting), `edgartools`, `fredapi`, `finnhub-python`, `alembic`, `structlog`, `stripe`, `pyarrow`, `boto3`, `pyotp`, `qrcode`, `cryptography`, `argon2-cffi`, `email-validator`, `markdown`.

**Wheel contents (thin client):** The wheel includes Python source under `finlet/`, including `finlet/mcp/stdio_proxy.py` and the manual topic files needed by the default hosted stdio bridge. Heavy server behavior is gated by extras and graceful import checks rather than by excluding source packages.

**Graceful degradation:** `finlet serve` and `finlet mcp serve --self-host` use `try/except ImportError` to detect missing server dependencies and print actionable messages instead of tracebacks. Phase 5 (2026-05-09) split the previous single `finlet mcp` command into a Typer sub-app — invocation is now `finlet mcp serve` (subcommand). The thin-client distribution ships the default hosted stdio bridge because `mcp>=1.27.0` is a base dependency; the local FastMCP server path remains behind `[server]` extras.

---

## Persistence

### Database

SQLite via `aiosqlite` + SQLModel. One database file per session: `~/.finlet/sessions/{session_id}/session.db`.

Engines are created once at startup via `init_engines()` and cached — not created per-request. WAL mode is enabled on all connections for concurrent read/write performance. Engines are disposed on shutdown via `dispose_engines()`.

**UTC repair on reload:** SQLite stores datetimes as text without timezone info. `ensure_utc()` (canonical in `finlet/utils/datetime.py`, imported as `_ensure_utc` in `persistence.py` for call-site compatibility) applies UTC timezone to all datetime fields (session timestamps, order timestamps, snapshot timestamps, trace timestamps) during reload. This prevents naive datetimes from escaping the persistence layer and causing aware/naive comparison failures in core domain logic. See `docs/decisions/utils-datetime-canonical.md` for the unification rationale.

Migrations are managed by Alembic. Auth DB migrations:
- `001_initial_schema` — Base tables
- `002_add_subscriptions` — Subscription/billing models
- `003_add_rate_limits` — Rate limit entries
- `004_add_mfa_fields` — MFA session and SMS OTP tables
- `009_add_password_fields` — `password_hash` column on `ApiKeyModel` (nullable, for email/password auth)
- `010_unique_email` — Unique constraint on `api_keys.email`. Requires deduplication of existing rows before running.
- `011_hash_session_tokens` — SHA-256 hashing of session tokens at rest. Converts `SessionTokenModel.session_token` from plaintext to hashed storage. Token is returned to the user on creation; DB stores only the hash. Matches the pattern already used for MFA tokens.

Session and global DB migrations (added 2026-04-01):
- `013_session_db_baseline` — Baseline migration for session DB schema (SessionModel, OrderModel, PositionModel, PortfolioSnapshotModel, TraceEntryModel)
- `014_add_session_public_columns` — Adds `public` BOOLEAN NOT NULL DEFAULT 0 INDEX + `public_anonymous` BOOLEAN NOT NULL DEFAULT 1 to `SessionModel`. Uses `op.batch_alter_table` with `render_as_batch=True` per `.claude/rules/database.md` (SQLite compatibility). Existing rows get the sane defaults (private + anonymized-when-publish). See `docs/decisions/session-public-visibility.md`.
- `014_global_db_baseline` — Baseline migration for global DB schema (including IdempotencyKeyModel)

Session DBs (`create_session_db()`) and the global DB (`create_global_db()`) now use `migrate_db()` instead of inline `table.create(checkfirst=True)`. Existing DBs are baseline-stamped on first run; new DBs are created via migration.

**Core Models (16 tables):**

| Model | Database | Purpose |
|-------|----------|---------|
| `SessionModel` | session DB | Session config, status, timestamps, and visibility flags (`public` BOOLEAN NOT NULL DEFAULT 0 INDEX + `public_anonymous` BOOLEAN NOT NULL DEFAULT 1, added by migration `014_add_session_public_columns`; see `docs/decisions/session-public-visibility.md`) |
| `OrderModel` | session DB | Orders with side, type, status, fill info, reasoning |
| `PositionModel` | session DB | Open positions per ticker |
| `PortfolioSnapshotModel` | session DB | Equity curve time series |
| `TraceEntryModel` | session DB | Reasoning trace log (DB-level immutability via SQLite BEFORE triggers — UPDATE and DELETE are blocked) |
| `ApiKeyModel` | auth DB | API keys (hashed), email, tier, MFA flags, password_hash (nullable, argon2id) |
| `SessionTokenModel` | auth DB | Session tokens (SHA-256 hashed at rest). Token is returned to the user on creation; only the hash is stored. |
| `SubscriptionModel` | auth DB | Stripe subscription state |
| `RateLimitEntry` | auth DB | Rate limits, email tokens, notification prefs (multi-purpose KV) |
| `MfaSessionModel` | auth DB | Pending MFA challenges (column `token_hash` stores hashed session tokens) |
| `PendingTotpSetupModel` | auth DB | Pending TOTP setup state (secret, backup codes) before user confirms enrollment |
| `SmsOtpModel` | auth DB | SMS OTP codes with expiry |
| `VerificationCodeModel` | auth DB | Email/forgot-key verification codes |
| `UserModel` | leaderboard DB | Leaderboard user profiles |
| `AgentProfileModel` | leaderboard DB | Agent profiles with composite scores |
| `ScenarioScoreModel` | leaderboard DB | Per-scenario benchmark scores |
| `BenchmarkJobModel` | leaderboard DB | Benchmark job status tracking |

**Marketplace Models (6 tables, separate DB, only created when marketplace enabled):**

| Model | Purpose |
|-------|---------|
| `DeveloperProfile` | Developer registration, verification status, Stripe Connect ID |
| `OnboardingProgress` | 7-step onboarding timestamp tracking |
| `ComplianceAttestation` | Signed attestations with IP, user-agent, version |
| `StrategyListing` | Strategy metadata, pricing, status (draft/in_review/published/suspended) |
| `AdminReview` | Review queue with approve/reject/changes_requested workflow |
| `DMCADesignatedAgent` | DMCA designated agent contact info |

### Plugin Config

Stored at `~/.finlet/plugins.json`. Contains API keys and enablement status. Never committed to git.

---

## Dashboard

> **2026-05-06 launch cut — read-only monitoring surface.** Finlet's launch user is an LLM agent invoking via CLI/MCP, not a human clicking through a SaaS UI. Per `docs/decisions/ui-removal-launch-cut.md`, all write-path UI was cut to `legacy/dashboard-ui/` (history-preserving git-mv) on 2026-05-06. The production dashboard is now a monitoring-only observer of agent-driven sessions: equity curve, positions table, trade log, sessions list, plugin health, leaderboard, and API key listing. Eight write-path API routes (POST `/sessions/{id}/trade/order`, PUT `/settings/profile`, PUT `/settings/password`, POST `/settings/api-keys`, DELETE `/settings/api-keys/{key_id}`, PUT `/settings/plugins`, PUT `/settings/notifications`, DELETE `/settings/account`) remain live in `finlet/api/` for CLI/MCP consumers — no UI consumes them. Refactor scope: `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`.

Multi-page web dashboard. Vanilla HTML + JavaScript + CSS. No build step.

Uses TradingView Lightweight Charts (free, MIT) for price/equity curves via CDN.

**Pages (post-2026-05-06 launch cut):**
1. **landing.html** — Public marketing page (hero, value props, CLI/MCP setup snippets, CTA). Shown to unauthenticated visitors instead of a login wall. Wired at `/` by the `_serve_root` handler in `finlet/api/app.py` (added 2026-05-10 by Team B launch-blockers, commit `88320b8`); authenticated visitors with a valid `finlet_session` cookie are 302-redirected to `/dashboard` (which serves `index.html`). The dashboard's own `auth-guard.js` handles the client-side check on `/dashboard` itself — `_serve_dashboard` serves `index.html` unconditionally.
2. **index.html** — Main monitoring dashboard: session selector (read-only — sessions created via CLI/MCP), overview panel, equity curve, positions table (read-only), order log (read-only; gained a Total Cost column 2026-05-03 in bug-hunt `20260503T230405Z2601` Team D for cash-disclosure — `<abbr>` header tooltip + cell-level `title=` for gross + commission + slippage breakdown), reasoning trace, plugin health.
3. **auth.html** — Registration and sign-in (cookie session) with email/password or Google OAuth. MFA challenge with 6-segment auto-advance input. Forgot password flow. Backup codes display.
4. **leaderboard.html** — Public agent rankings and benchmark results.
5. **api-keys.html** — API key listing (masked `fnlt_...xxxx` with name, created, last_used timestamps) with rotate flow + GitHub-style PAT framing (2026-05-13 SETTINGS_AND_BILLING_RESTORE Team B, commit `fc54973`). Originally added 2026-05-06 by Team C of the launch-cut refactor as a thin replacement for the cut `settings.html` (now in `legacy/dashboard-ui/`); served by `api-keys.js`.
6. **agent-guide.html** — Agent integration matrix (expanded 2026-05-15 by USER_MANUAL_OVERHAUL Team D). 8-tab client matrix covering Claude Desktop, Claude Code, Cursor, Codex, Windsurf, VS Code, Generic MCP, REST — each tab shows copy-pasteable OAuth-first connection config + transport-specific gotchas. Auth flow flipped OAuth-first (was api_key-first pre-Phase-4e); api_key remains documented as the headless/CI fallback. Five troubleshooting deep-links anchor at `finlet manual errors#<anchor>` for the most common failure classes (`#missing-bearer`, `#missing-scope`, `#rate-limit`, `#transport-mismatch`, `#invalid-session`). E2E coverage: `tests/e2e/journey-19-agent-guide.spec.ts`.
7. **setup.html** — Public setup page at `/setup` (no auth). Single progressive 6-step walkthrough (CLI-first path) covering registration, session creation, first action, and the three transport layers (REST API, MCP over HTTP, pip install thin client). REST API alternatives, MCP tool reference, and error-handling details are wrapped in collapsible `<details><summary>` sections. Pre-defined anchor IDs: `#rest-api`, `#mcp`, `#install`, `#first-action`.
8. **verify.html** — Email verification landing page. Reads the token from the URL and calls `POST /email/verify-token`.
9. **llms.txt** — Agent-parseable index at `/llms.txt` following the llms.txt specification (llmstxt.org). Plain markdown, under 100 lines. **Generated artifact, not authored** (USER_MANUAL_OVERHAUL, 2026-05-15). Rendered deterministically from `finlet/manual/registry.TOPIC_REGISTRY` by `python -m finlet.manual.generate_llms_txt --write`. Drift between the registry and the on-disk `dashboard/llms.txt` is gated at three layers: pre-commit (4th lint via `scripts/lint-llms-txt-fresh.sh`), CI lint job (`.github/workflows/ci.yml` runs `--check`), and the manual one-off remediation (`--write`). Adding a new manual topic is a 3-edit change: new `.md` file in `finlet/manual/`, new `TopicMeta` row in `registry.py`, run `--write`. Decision record: `docs/decisions/dashboard-llms-txt-regen-pipeline.md`.
10. **public.html** — Anonymous read-only view of a public session (added 2026-05-12 via Team B of the public-session-view ship). Served at `/sessions/{session_id}` and `/public/{session_id}` (Starlette `Route` inserts in `finlet/api/app.py`, same pattern as `_serve_pricing`). Polling-only against `/v1/public/sessions/{id}/*` endpoints — no SSE (SSE requires auth), no `finlet:*` event bus subscriptions. Imports render helpers from `dashboard/renderers.js` (extracted from `dashboard/app.js` so authenticated dashboard + public view share one render code path). All `innerHTML` writes wrapped through `trustedHTML(...)` per the pre-commit lint contract. Banner reads "Anonymous Finlet session" when `session.public_anonymous == True`, falls back to the owner-supplied `session.name` when `False`. See `docs/decisions/session-public-visibility.md`.
11. **settings.html** — Password change page (2026-05-13 SETTINGS_AND_BILLING_RESTORE Team A, commit `aad1b5b`). Restores the password-change flow that was CLI-only post-launch-cut; current/new-password form posts to `/v1/settings/password`. Served by `settings.js` + `settings.css`. Data-export and account-deletion UI explicitly deferred (items F, G in `docs/REMAINING_TASKS.md`) pending backend cascade work.
12. **billing.html** + **pricing.html** — Billing UI + Stripe Checkout wiring (2026-05-13 SETTINGS_AND_BILLING_RESTORE Team C, commit `83fe770`). `billing.html` shows current subscription state, links to Stripe Checkout for upgrades, and Stripe Customer Portal for self-serve cancel/invoice download. `pricing.html` is the public tier-comparison view (restored from legacy at the new production path). Signup→checkout deep-link via `auth.html?from=signup&intent=subscribe&tier=…` query-string round-trip handled in `auth.js`. URL allowlist enforced at `finlet/config.py:96` (`finlet.dev` + `localhost`); promo codes validated against `/v1/billing/validate-promo`.

**Cut to `legacy/dashboard-ui/` (preserved verbatim, restorable):** `trade-ticket.js`, `onboarding.{js,css}`, `marketplace.{html,js,css}`, `dialog-state-mirror.js`, `form-dirty-tracker.js`. The original `settings.{html,css}` (legacy write-path version with plugin config + delete-account + data-export), `billing.{html,js,css}`, and `pricing.html` were partially restored 2026-05-13 (password change + Stripe Checkout + public pricing) and partially remain legacy (plugin config UI, full data-export, delete-account cascade). See `legacy/README.md` for restore instructions and the security re-review requirement.

**Shared infrastructure (production, post-cut):**
- `shared-nav.js` — Shared navigation component injected into all pages via `initSharedNav()`. Renders header, nav links, user menu, and breadcrumbs. **API-key affordance umbrella (since 2026-05-07, refactor `aria-label-mismatch`, Team A commit `b9ccf4a` on `origin/main`):** the API-key button label is the closed enum of two surface ids (`API_KEY_AFFORDANCE_IDS = ['menu-copy-key', 'nav-drawer-copy-key']`) repainted by `_relabelAllApiKeyAffordances()` at three call sites — shared-nav mount, `mobile-nav.js#initMobileNav` mount, and the `auth:state-change` bus subscriber. Dual-label semantics (`docs/decisions/copy-api-key-dead-affordance.md`): `FinletAuth.getApiKey() → null` → "Manage API Key" + click navigates to `api-keys.html` (was `settings.html#api-keys` pre-2026-05-06 launch cut); `getApiKey() → non-null` → "Copy API Key" + click writes to clipboard. Adding a new surface is one entry in `API_KEY_AFFORDANCE_IDS`.
- `mobile-nav.js` — Hamburger menu + slide-out drawer for mobile viewports (< 768px). Integrates with `shared-nav.js`.
- `api-utils.js` — Shared HTTP client with auth headers (cookie auth preferred, API-key bearer fallback), `/v1/` API prefix, theme system utilities. CSRF token persisted to `sessionStorage('finlet_csrf')`, restored by `isAuthenticated()` on page load via `GET /auth/session/validate`.
- `empty-states.js` — Contextual empty state rendering for all dashboard panels. `showEmptyState(containerId, context)` / `hideEmptyState(containerId)`. Contexts: `no-sessions`, `no-orders`, `no-positions`, `no-data`, `no-session` (2026-05-06 bug-hunt `20260506T185234Z542e` Team A — distinguishes "no upstream session selected" from "session has zero plugins").
- `feedback.js` — Feedback widget bootstrap with `mailto:` fallback. Client error reporting flows through `reportClientError()` in `api-utils.js` to `/v1/client-errors`.
- `event-bus.js` — Dashboard event-bus (introduced 2026-04-28). Single module exposing the frozen surface `window.finletBus.subscribe(event, handler) → unsubscribe`, `window.finletBus.publish(event, payload)`, and `window.finletBus.getLastPublished(event) → payload | undefined`. Backed by `Map<event, Set<handler>>` plus an additive `Map<event, payload>` lastPublished cache. Subscriber errors caught per-handler so one bad subscriber cannot break siblings. **All cross-component dashboard wiring goes through this bus.** Direct `window.dispatchEvent(new CustomEvent('finlet:...'))` and `addEventListener('finlet:...')` are forbidden. Production event names post-cut: `portfolio:updated`, `order:filled`, `session:switched`, `auth:state-change`. Legacy event names (`profile:saved`, `strategy:saved`, `onboarding:step-completed`) remain enumerated in `dashboard/event-contract.md` for `legacy/dashboard-ui/` consumers but have no production publishers post-cut.
- `modal-controller.js` — Single authority for dashboard modal stacking, visibility, and pointer-events flow. Public API: `window.finletModal.open(id) → close-handle`, `window.finletModal.close(id)`, `window.finletModal.suppress(suppressor_id, while_open_id)`, `window.finletModal.topmost() → string | null`, `window.finletModal.isOpen(id) → boolean`. **All dashboard modals MUST be tagged with `data-modal-id="..."` and the `.fl-modal` CSS class**; the controller flips inline `style.display`, `style.zIndex`, `style.pointerEvents`, and the `.fl-modal--visible`/`.fl-modal--hidden` classes at open/close time. Per-modal hard-coded z-index values are forbidden — z-order is owned by the controller. See `docs/decisions/dashboard-modal-controller.md` for the visibility-via-class contract.
- **Defensive no-hyphenation contract on metric tile values (`dashboard/styles.css#.stat-value`)** — every dashboard metric tile that renders ASCII text into a fixed-width cell pins `hyphens: none; word-break: keep-all; overflow-wrap: normal; white-space: nowrap;` to defeat Chromium's auto-hyphenation glyph injection. The redundant property chain is load-bearing.
- **Test-enforced overflow contract on stat-card tiles (`dashboard/styles.css#.stat-card`, `#.stat-value`)** — Overview tile cards size to 184px desktop / 144px mobile with `text-overflow: clip` and `.stat-value { font-size: 16px }` inside the mobile breakpoint. Enforced by `tests/e2e/journey-sim-time-tile.spec.ts`. See `docs/decisions/stat-card-overflow-contract.md`.
- `app.js` — Main dashboard logic (sessions, clock controls, charts, plugin health). Uses SSE (`EventSource`) for real-time state updates. Falls back to REST polling after 3 SSE connection failures. SSE reconnection banner shown on disconnect with auto-retry countdown. All render functions call `showEmptyState()` when data arrays are empty. The `portfolio` SSE listener publishes `portfolio:updated` on `window.finletBus`; the `orders` SSE listener publishes `order:filled` on the zero-to-one `filledCount` transition. Publishes `session:switched` from `selectSession()` — the canonical session-activation site every flow funnels through (dropdown change, auto-select on first load, refresh-after-API/CLI/MCP-create). Out-of-band session creation (REST/CLI/MCP) flips the active session as soon as the next `fetchSessions()` lands.
- `leaderboard-submit.js` — "Submit to Leaderboard" modal form with agent name, description, model, strategy category dropdown, data sharing checkbox. Submits via `POST /leaderboard/submit`, polls job status via `GET /leaderboard/submit/{job_id}` (2s interval, 60 poll max), shows composite score on completion.
- Per-page JS files (production, read-only): `auth.js`, `leaderboard.js`, `api-keys.js` (read-only API-key listing, ~8% of pre-cut `settings.js`; the cut write-path settings.js lives in `legacy/dashboard-ui/`). The cut write-path JS (`trade-ticket.js`, `onboarding.js`, `dialog-state-mirror.js`, `form-dirty-tracker.js`, `billing.js`, `marketplace.js`, `settings.js`) lives in `legacy/dashboard-ui/`.
- **XSS escaping**: `auth.js` (`escapeHtml()`) escapes `& < > " '` in user-controlled strings.
- Per-page CSS files (production): `landing.css`, `auth.css`, `agent-guide.css`. The cut CSS (`onboarding.css`, `marketplace.css`, `billing.css`, legacy `settings.css`) lives in `legacy/dashboard-ui/`.

**Theme system:** Dark/Light/System via CSS custom properties on `:root[data-theme]`. Theme persisted in localStorage key `finlet_theme`.

**Mobile responsive:** Production pages work at 375px–768px. Header nav collapses into hamburger menu with slide-out drawer.

Read-only state via SSE (with REST polling fallback). Served as static files by FastAPI.

---

## Authentication & Authorization

### Email/Password Auth

Users can register and sign in with email + password. Passwords are hashed with **argon2id** via `argon2-cffi` (memory_cost=65536, time_cost=3, parallelism=4). The `password_hash` column on `ApiKeyModel` is nullable — existing users who registered before password support have no password and can set one from Settings or continue using API key / Google OAuth.

- `POST /auth/register` with `password` field creates an account with email + password
- `POST /auth/login` authenticates with email + password, returns session cookie (or MFA challenge if enabled)
- `authenticate_with_password()` iterates ALL `api_keys` rows matching the email — a user may have multiple rows (e.g., one via Google SSO with no password, another via email registration). The function skips rows with `password_hash = NULL` and tries the password against each row that has a hash, returning the first match. Previously it stopped at the first email match regardless of whether that row had a password.
- Password attempts are rate-limited via `RateLimitEntry` (3 per email per hour, 5 per IP per hour)
- `needs_rehash()` uses argon2-cffi's built-in check for transparent parameter upgrades

### API Key Auth

API keys are issued at registration and persisted to SQLite with an in-memory cache for fast lookups. Session tokens are SHA-256 hashed at rest — the raw token is returned to the client on creation but only the hash is stored in the database. Database compromise does not yield usable session tokens. All protected endpoints use the `require_user` dependency (dual auth: session cookie + Bearer token). `require_user` checks for a valid httpOnly session cookie first, then falls back to `Authorization: Bearer <key>` header. This applies to all route files — not just auth routes. The dashboard frontend prefers cookie-based auth (set at sign-in) and falls back to bearer token only when no cookie session exists. API keys are managed from the Settings page: users can create named keys (shown once with copy-once pattern), view masked keys (`fnlt_...xxxx`) with last-used timestamps, and revoke keys with confirmation. Session ownership is enforced — keys can only access sessions belonging to the same `user_id`.

The companion `optional_user` dependency (`finlet/auth/deps.py:_OptionalUser`) is used by anonymous-tolerant probes (notably `GET /v1/auth/session/validate`). Its contract is **anonymous-on-failure across all credential paths** — Bearer-missing returns `None`, cookie-missing returns `None`, and (since 2026-04-30, bug-hunt `20260430T222711Z3666` Team A, commit `47c7e79`) **cookie-present-but-stale also falls through to `None`** rather than raising 401. This matches the Bearer-token fall-through contract and avoids spamming the dashboard console with 401s on every page load when a browser holds a stale cookie. The security floor is preserved: Bearer tampering still raises 401 (no silent degradation for an explicitly-supplied invalid credential), and routes guarded by `require_user` continue to 401 expired cookies — only the `optional_user` / validate-probe path downgrades. Asymmetric paths within one dependency (one path falling through, another raising 401) are forbidden by convention; if a route needs hard 401 semantics, it uses `require_user`, not an asymmetric branch inside `optional_user`.

Registration is rate-limited to **5 per hour per IP** to prevent key generation abuse. Plugin-level rate limits (e.g., Finnhub 60/min) are passed through as `429` responses with reset timing.

**Rate limiting** is implemented in the `finlet/api/rate_limit/` package, split by concern:
- `rate_limit/core.py` — Base rate limiting logic and shared `safe_record_request()` utility
- `rate_limit/session.py` — Session-scoped rate limits
- `rate_limit/auth.py` — Auth endpoint rate limits (login, registration, password reset)
- `rate_limit/trading.py` — Trading endpoint rate limits
- `rate_limit/plugin.py` — Plugin call rate limits (per-user and global)

### Password Reset

Two independent password reset flows exist, both fully functional:

**Code-based flow** (via auth routes, reuses `store_verification_code()` / `verify_code()` from the MFA module):
1. `POST /auth/forgot-password` — sends 6-digit code to email. Anti-enumeration: always returns success regardless of whether the email exists.
2. `POST /auth/reset-password` — accepts email + code + new password. Rate-limited (3 per email per hour).

**Token-based flow** has been removed. Password reset is now handled exclusively by the code-based flow above.

### Multi-Factor Authentication

MFA logic lives in the `finlet/auth/mfa/` package (canonical implementation), structured as:
- `auth/mfa/exceptions.py` — MFA-specific exceptions
- `auth/mfa/totp.py` + `auth/mfa/totp_utils.py` — TOTP setup, verification, disable
- `auth/mfa/sms.py` — SMS OTP delivery and verification
- `auth/mfa/session.py` — MFA session/challenge management
- `auth/mfa/google.py` + `auth/mfa/google_validate.py` — Google authenticator integration
- `auth/mfa/recovery.py` + `auth/mfa/recovery_utils.py` — Recovery/backup code logic
- `auth/mfa/crypto.py` — MFA cryptographic utilities (moved from api/)

The `finlet/api/mfa/` package is a set of thin re-export shims that point to `auth/mfa/` — this preserves backward compatibility for existing importers while keeping the canonical implementation in the auth layer.

Two MFA methods, enforced at sign-in when enabled:

- **TOTP** (Time-based One-Time Password): Setup returns a QR code and secret for authenticator apps (via `pyotp`). TOTP secrets and backup codes are held in-memory during setup and only persisted to the database when `verify_totp_setup()` confirms the first valid code. This prevents orphaned MFA records if enrollment is abandoned.
- **SMS OTP**: E.164 phone number setup with AWS SNS (`boto3`). Code delivery, verification, disable, and re-send endpoints are fully implemented. SNS uses the EC2 instance role for auth — no vendor API keys required.

MFA status endpoint (`GET /mfa/status`) returns: `{ totp_enabled, sms_enabled, backup_codes_remaining, phone_number_masked }`.

MFA flow: `sign-in → MFA challenge (mfa_session token) → validate code → authenticated`.

### Google OAuth

Google Sign-In via ID token verification using full-page redirect flow (not popup — more reliable across browsers and survives popup blockers). Links a Google `sub` to the user account. Configured via `GOOGLE_CLIENT_ID` (loaded from SSM or env).

Handles edge cases:
- Email already registered without Google: accounts are linked automatically
- Google token expired/invalid: clear error message returned
- Google API unreachable: graceful fallback with specific error

### Forgot-Key Flow

Email-based API key recovery: sends a 6-digit verification code, verifies it, rotates the API key via `AuthService.rekey_user()`. The `rekey_user()` method atomically swaps the key hash on the existing row, preserving `user_id` and avoiding orphaned records. Google OAuth sign-in also uses `rekey_user()` for key rotation.

---

## Billing

Stripe integration via `finlet.billing.service`. Stripe configuration lives in `finlet/billing/stripe_config.py` (moved from `api/stripe_config` to fix a layering violation). The billing package is structured as:
- `billing/service.py` — Core billing service
- `billing/webhooks.py` — Stripe webhook handlers
- `billing/validators.py` — Billing validation logic
- `billing/stripe_config.py` — Stripe configuration and client setup

All Stripe interaction is centralized in these modules; route handlers are thin adapters.

- **Async Stripe calls**: All 6 blocking Stripe SDK calls (`Session.create`, `billing_portal.Session.create`, `Invoice.list`, `PromotionCode.list`, `Subscription.modify`, `checkout.Session.create`) are wrapped in `asyncio.to_thread()` to avoid blocking the event loop during slow Stripe responses.
- **Checkout**: Creates Stripe Checkout sessions for tier upgrades (free → builder/insights/enterprise). Redirect URLs validated against `FINLET_ALLOWED_REDIRECT_DOMAINS`.
- **Error handling**: Billing route errors use standard `HTTPException(status_code=502)` with the centralized error envelope, replacing the previous custom `_stripe_error_response()` helper. Error messages use `e.user_message` when available (Stripe's customer-facing message), with a generic fallback. Internal request IDs are never leaked to the client.
- **Webhooks**: Handles `checkout.session.completed`, subscription lifecycle events. Signature verified with `STRIPE_WEBHOOK_SECRET`.
- **Portal**: Stripe Customer Portal for self-service subscription management.
- **Subscriptions**: Status, tier, payment method info persisted to `SubscriptionModel`.
- **Invoices**: Fetched from Stripe API on demand.
- **Promo codes**: Validated against Stripe promotion codes.
- **Cancellation**: Downgrades to free tier.

---

## Email System

Configurable email service (`finlet.api.email_service`) with HTML + plaintext templates (`finlet.api.email_templates`).

**Delivery**: Production uses AWS SES via SMTP, sending from `noreply@finlet.dev` with DKIM signing. Fully live as of 2026-03-29. Configuration is loaded from SSM Parameter Store: `EMAIL_PROVIDER` (`smtp`), `SMTP_HOST` (`email-smtp.us-east-1.amazonaws.com`), `SMTP_PORT` (`587`), `SMTP_USER`, and `SMTP_PASS`. DNS records in Cloudflare: SES domain verification TXT, 3 DKIM CNAMEs, SPF (`v=spf1 include:amazonses.com ~all`), and DMARC (`v=DMARC1; p=quarantine`).

**IAM**: The EC2 role (`aws_iam_role.finlet`) includes the `finlet-ses-send-policy` granting `ses:SendEmail` and `ses:SendRawEmail` scoped to `arn:aws:ses:us-east-1:*:identity/finlet.dev`. Added in `deploy/aws/main.tf` (commit 6095564).

- **Verification**: Token-based email verification (24h expiry default). Sent on registration.
- **Password reset**: Token-based (1h expiry default). Anti-enumeration: always returns success regardless of whether the email exists. Password reset verification codes use `send_email_immediate()` (bypassing async task queue) to ensure delivery during the synchronous forgot-password flow.
- **Welcome**: Sent on registration with dashboard and docs links.
- **Notification preferences**: Per-user opt-in/out for session_complete, payment_receipts, plan_changes, usage_warnings, product_updates.
- **Unsubscribe**: One-click unsubscribe via long-lived token (365 days). Sets all notification preferences to false.

Tokens are stored hashed (SHA-256) in the auth database. Raw tokens are sent via email and never stored.

---

## Marketplace

Gated behind `FINLET_MARKETPLACE_ENABLED` feature flag. Separate SQLite database (`marketplace.db`).

### Developer Onboarding (7 steps, sequential, blocking)

1. Account creation (via `/auth/register`)
2. Developer registration (display name, company, website)
3. Compliance attestation (signed agreement with IP/user-agent audit trail)
4. Stripe Connect onboarding (for payouts)
5. W-9/W-8BEN tax form collection
6. Listing guidelines acknowledgment
7. First strategy admin review (triggered after strategy submission)

### Strategy Lifecycle

`draft → in_review → published | rejected → draft (resubmit)`. Admins can also `suspend` published strategies.

### Compliance Features

- **Prohibited claims scanning**: Automated scan of strategy content for prohibited financial claims (guaranteed returns, etc.) before submission. Returns `ScanVerdict` with flagged phrases. Split into `prohibited_patterns.py` (regex patterns, claim categories) and `claim_scanner.py` (scanning logic).
- **Tax**: Stripe Tax integration for pre-purchase tax calculation. FATCA withholding for non-US developers (30% default, treaty rates supported).
- **Tax forms**: W-9 (US) / W-8BEN (non-US) collection and validation via `TaxFormService`.
- **Geo-blocking**: `GeoBlockingMiddleware` blocks requests from OFAC-sanctioned countries and FCA risk jurisdictions. Uses MaxMind GeoIP database (or stub in dev). Config loaded from `finlet.marketplace.geo_config`.
- **Disclaimer injection**: `DisclaimerInjectionMiddleware` auto-injects financial disclaimers into marketplace API responses.
- **DMCA**: Designated agent info stored in `DMCADesignatedAgent` model.
- **Admin**: Admin user IDs loaded from `FINLET_ADMIN_USER_IDS` env var. Admin-only endpoints for review queue and moderation.

---

## Security Middleware

Middleware is applied in order in `create_app()`. Starlette processes middleware in LIFO order (last registered runs first on the request path, first on the response path). Registration order matters for correctness — see inline comments in `app.py`.

| Middleware | Location | Purpose |
|-----------|----------|---------|
| `CORSMiddleware` | FastAPI built-in | Configurable origins via `FINLET_CORS_ORIGINS`. Wildcard disables credentials (OWASP). |
| `RequestSizeLimitMiddleware` | `finlet.api.security_middleware` | Rejects bodies > 1 MB (configurable via `FINLET_MAX_REQUEST_BODY_BYTES`). Returns 413. |
| `CSRFMiddleware` | `finlet.api.security_middleware` | CSRF enforcement for cookie-authenticated state-changing requests. Exempt paths: `/v1/auth/login`, `/v1/auth/forgot-password`, `/v1/auth/forgot-password/verify`, `/v1/auth/reset-password`. All pre-authentication public POST endpoints must be in the exempt list since the client has no CSRF token before signing in. |
| `CSPNonceMiddleware` | `finlet.api.security_middleware` | Injects CSP `nonce` attributes into `<script>` tags in HTML responses. Registered before `SecurityHeadersMiddleware` so that in LIFO order, the nonce is generated first (by `SecurityHeadersMiddleware`) then injected into HTML (by `CSPNonceMiddleware`). |
| `SecurityHeadersMiddleware` | `finlet.api.security_middleware` | X-Frame-Options: DENY, X-Content-Type-Options: nosniff, CSP with per-request nonce, Referrer-Policy, Permissions-Policy. HSTS opt-in via `FINLET_HSTS_ENABLED`. Generates `request.state.csp_nonce` consumed by `CSPNonceMiddleware`. |
| `StaticCacheControlMiddleware` | `finlet.api.security_middleware` | Sets `Cache-Control: no-cache` on JS, CSS, and HTML responses. Forces browsers to revalidate with the server on every request (via `If-Modified-Since`), preventing stale assets after deployments while still benefiting from `304 Not Modified` caching. |
| `ConfigInjectionMiddleware` | `finlet.api.config_injection` | Injects server config (Google Client ID, feature flags) as `<script type="application/json" id="finlet-config">` into HTML responses. The injected tag includes the CSP nonce from `request.state.csp_nonce` to comply with the strict CSP policy. |
| `CorrelationIDMiddleware` | `finlet.api.middleware` | Reads/generates `X-Request-ID`, binds to structlog context, logs request lifecycle with latency. Validates incoming IDs (hex+hyphens, max 64 chars); replaces invalid values with a generated UUID. **As of 2026-05-10 (Team D / launch v1.0.0)**: also tags the active Sentry scope via `sentry_sdk.set_tag("request_id", ...)` once per request when `sentry_sdk.Hub.current.client is not None` — gated on `SENTRY_DSN` having been set at app boot, otherwise no-op. |
| `MFAWarningMiddleware` | `finlet.api.app` | Adds `X-Finlet-MFA-Warning` header to responses for paid-tier users who have not enabled MFA. |
| `GeoBlockingMiddleware` | `finlet.marketplace.geo_middleware` | Marketplace only. Blocks OFAC/FCA jurisdictions. MaxMind GeoIP or stub provider. |
| `DisclaimerInjectionMiddleware` | `finlet.marketplace.disclaimer_middleware` | Marketplace only. Injects financial disclaimers into responses. |

---

## Observability — Sentry SDK (Phase: launch v1.0.0 — 2026-05-10)

Per the launch v1.0.0 readiness execution (`docs/decisions/observability-v1-launch.md`, accepted 2026-05-10), Finlet wires **Sentry SDK with the FastAPI integration** for centralized error tracking on the production API surface. Goal: aggregate, group, and alert on uncaught exceptions in real time instead of grepping CloudWatch logs reverse-chronologically.

**Surface:**
- `finlet/api/app.py:_init_sentry()` — gated on the `SENTRY_DSN` env var being non-empty; called from `create_app()` BEFORE middleware registration so route-handler exceptions land on the Sentry scope. No-op when DSN is empty / unset (dev / CI / forks). Wired with `traces_sample_rate=0.0` (event-only, no transaction sampling on the free tier), `send_default_pii=False`, `environment=$FINLET_ENV`, `release=<pyproject version>`, and the `_sentry_before_send` PII-redaction hook.
- `finlet/api/app.py:_sentry_before_send` — strips `Authorization`, `Cookie`, `X-CSRF-Token` headers; drops the request body on `/v1/auth/*`, `/auth/*`, `/v1/billing/*` paths; scrubs email-shaped values, JWT-shaped tokens, and `flx_*` / `sk-ant-oat*` API-key shapes from breadcrumbs. Returns `None` to drop an event entirely if the redaction path raises.
- `finlet/api/middleware.py:CorrelationIDMiddleware.dispatch` — appends `sentry_sdk.set_tag("request_id", request_id)` so Sentry events are filterable by the same correlation ID that structlog and CloudWatch already use. Gated on `sentry_sdk.Hub.current.client is not None`.
- `tests/api/test_sentry_init.py` (NEW, 31 tests) — pins (a) DSN-unset → no init, (b) DSN-set → init called with expected kwargs, (c) bad DSN doesn't raise, (d) every PII-redaction branch (Auth header, Cookie, auth-route body, JWT/email/api-key in breadcrumb).

**Free-tier ceilings** (Sentry as of 2026-05): 5k errors/mo, 30-day retention, 10k traces (disabled — `traces_sample_rate=0.0`). v1.0.0 anticipated load: ≤1k errors/mo. Headroom: 5x. If exceeded, Team plan is $26/mo for 50k events.

**What Sentry does NOT replace:** `structlog` is still the primary log surface; CloudWatch log group `/finlet/prod/api` retains every line. Sentry layers on top — it captures a subset of structlog events (errors + unhandled exceptions) and adds aggregation, breadcrumbs, release-pinning, and alerting that CloudWatch does not provide natively.

**CSP allowlist** for Sentry is in `finlet/api/security_middleware.py:218,222` — `https://browser.sentry-cdn.com` (script-src) and `https://*.ingest.sentry.io` (connect-src). Allowlisted since the trusted-types refactor (2026-04-30) in anticipation of this wiring.

---

## SSM Integration

`finlet.ssm` provides `get_secret(name)` for loading secrets with a resolution chain:

1. AWS SSM Parameter Store: `{FINLET_SSM_PREFIX}/{name}` (SecureString, decrypted)
2. Environment variable: `name`
3. Default value (empty string)

Results are cached via `@lru_cache` for the process lifetime. SSM can be disabled with `FINLET_SSM_ENABLED=0` (for CI/local dev). Prefix defaults to `/finlet/prod`.

Used for: `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `GOOGLE_CLIENT_ID`, and other secrets that should not be in env vars in production.

---

## Configuration

All non-secret configuration is centralized in `finlet.config.Settings` (frozen dataclass, read from env vars at import time). Sub-configs:

| Config | Key env vars |
|--------|-------------|
| `LoggingConfig` | `FINLET_LOG_FORMAT` (json/console), `FINLET_LOG_LEVEL` |
| `CORSConfig` | `FINLET_CORS_ORIGINS` (comma-separated or `*`) |
| `SecurityConfig` | `FINLET_MAX_REQUEST_BODY_BYTES`, `FINLET_HSTS_ENABLED` |
| `RateLimitConfig` | `FINLET_RESET_RATE_LIMIT`, `FINLET_MARKET_DATA_RATE_LIMIT`, `FINLET_TRADE_RATE_LIMIT`, `plugin_rate_per_user_per_minute` (default 30), `plugin_rate_global_per_minute` (default 150) |
| `BillingConfig` | `FINLET_ALLOWED_REDIRECT_DOMAINS` |
| `AdminConfig` | `FINLET_ADMIN_USER_IDS` (comma-separated) |
| `MarketplaceConfig` | `FINLET_MARKETPLACE_ENABLED` |
| `SSMConfig` | `FINLET_SSM_ENABLED`, `FINLET_SSM_PREFIX`, `AWS_DEFAULT_REGION` |
| `PricePluginConfig` | `FINLET_PRICE_BUCKET` |
| `FundamentalsPluginConfig` | `FINLET_FUNDAMENTALS_BUCKET` |

Secrets go through `finlet.ssm.get_secret()` — not duplicated here.

---

## Shared Utilities (`finlet/utils/`)

Common utility functions extracted from scattered implementations across the codebase:

- `utils/time.py` — `utcnow()` returns timezone-aware UTC datetime. Single definition replacing duplicate `_utcnow()` implementations in `db/engine.py` and `marketplace/models.py`.
- `utils/ids.py` — `new_id()` generates consistent unique identifiers. Single definition replacing duplicate `_new_id()` implementations with inconsistent formats.
- `utils/dates.py` — `parse_datetime()` and `parse_datetime_utc()` consolidate scattered date parsing logic from plugins into a single shared utility.
- `utils/datetime.py` — `ensure_utc(dt: datetime | None) -> datetime | None` with `@overload`. Re-attaches UTC tzinfo when missing (SQLite drops tzinfo on reload). Stdlib-only leaf (no internal imports → safe from any layer). Consumed by `db/persistence.py`, `auth/service.py`, `auth/oauth/storage.py`, `leaderboard/benchmark_plugins.py` via the import-alias pattern `from finlet.utils.datetime import ensure_utc as _ensure_utc` (preserves the legacy `_ensure_utc` symbol for ~34 call sites + the `auth/__init__.py` re-export). Plugin-team copies in `finlet/plugins/{fundamentals,news,price,sentiment}_plugin.py` not yet migrated — see I5-followup in `docs/REMAINING_TASKS.md`. Decision record: `docs/decisions/utils-datetime-canonical.md`.

---

## Package Architecture & Layering

The codebase follows a strict layering model with no circular dependencies:

```
L0: core/, errors.py — Simulation engine (clock, portfolio, orders, trace, slippage), domain error hierarchy
L1: plugins/, db/, data/ — Data plugins, persistence, shared models, canonical concept definitions
L2: auth/, billing/ — Authentication, MFA, billing services
L3: api/ (incl. helpers/), mcp/, cli — REST API, MCP server, CLI (thin adapters)
```

**Key invariant:** Lower layers never import from higher layers. All three circular dependency chains that previously existed (`api <-> billing`, `auth <-> api`, `auth -> api -> billing -> auth`) have been broken by moving canonical business logic implementations down to the appropriate layer:

- `finlet/auth/security_alerts.py` — Security alert logic (moved from api/, canonical implementation)
- `finlet/auth/session_auth.py` — Session authentication logic (moved from api/, canonical implementation)
- MFA utilities moved from `api/` to `auth/mfa/` package

The corresponding `api/` modules (`api/security_alerts.py`, `api/session_auth.py`, `api/mfa/`) are now thin re-export shims that import from `auth/` and re-export symbols. This preserves backward compatibility for existing importers while enforcing clean layering.

The `api.auth` module's public API is stabilized with an explicit `__all__` exporting 21 symbols, reducing the fragility of this high-fan-in module (19 importers).

---

## Leaderboard

The leaderboard package has been split into focused modules: `api_strategy.py` (core strategy logic), `benchmark_plugin.py` (benchmark plugin), `validation.py` (validation logic), `benchmark_state.py` (MCP benchmark lifecycle), `benchmarks.py` (frozen scenario definitions), and `reporting.py` (benchmark result formatting and export).

The leaderboard ranks completed sessions by composite score across 5 weighted dimensions: Sharpe ratio, total return, max drawdown, consistency, and **reasoning quality** (0.15 weight). The reasoning quality score evaluates three aspects of agent reasoning from the trace: (a) fraction of decisions with non-empty reasoning text (coverage), (b) information queries per trade decision (research ratio), (c) diversity of query types across news, fundamentals, price, and economic data. Sessions with zero trace entries score 0.0 for reasoning. Weights are redistributed so all 5 dimensions sum to 1.0.

### Benchmark Blindness Invariant

Agent-facing API responses MUST NOT expose the identity of any benchmark scenario. Internally, scenarios have stable ids like `bull_run`, `covid_crash`, `2008_crisis` and human-readable names/descriptions ("Strong bull market driven by AI hype and tech earnings beats"). If an agent could read these, it could pattern-match on the regime and game evaluation by switching to a known-winning strategy for that regime.

**Boundary contract:** every place that serializes scenario data to an HTTP response goes through a redaction helper. Internal scoring/runner code (`finlet/leaderboard/runner.py`, `finlet/leaderboard/scoring.py`) keeps the real ids — they need them to look up scenario configuration. Only the API serialization layer redacts.

- `finlet/leaderboard/profiles.py` — `_blind_scenario_dump(score, idx)` wraps `ScenarioScore.model_dump()` and substitutes `scenario_id` with positional `scenario_<N>` (1-indexed by list position). Used by `AgentProfile.to_summary()` and `to_detail()`. Locked in by `journey-16-benchmark-blindness.spec.ts:49` (e2e) plus `tests/leaderboard/test_leaderboard.py::TestBenchmarkBlindnessRedaction` and `tests/api/test_leaderboard.py::TestLeaderboardBenchmarkBlindness`.
- `finlet/api/routes_leaderboard.py` — `GET /leaderboard/benchmarks` rebuilds each `BenchmarkScenarioInfo` with `id="scenario_<N>"`, `name="Scenario <N>"`, `description=""`. The schema's `start_time`/`end_time`/`universe`/`initial_capital` remain because they are also exposed by `start_benchmark` MCP tool to the agent under test (the agent legitimately needs to know the scenario period and tradable universe to operate). Locked in by `tests/api/test_leaderboard.py::TestLeaderboardBenchmarkBlindness::test_benchmarks_endpoint_redacts_scenario_names`.

**Adding a new scenario-related field:** if you add any field to a response schema that touches scenario identity, add a regression test that asserts the forbidden-string set (loaded from `BENCHMARK_SCENARIOS`) does not appear in the response body. The pre-push e2e smoke includes `journey-16` so a regression in the listing/detail endpoints is caught before push; the unit tests catch the `/benchmarks` endpoint and any future surface.

### Benchmark Flow (MCP-Driven)

The primary benchmark mechanism uses MCP tools to let an external AI agent trade through 5 frozen scenarios via the standard Finlet tool surface. The agent calls `start_benchmark`, trades using the existing MCP tools (`get_price_data`, `submit_order`, `advance_time`, `get_portfolio`, etc.), and calls `complete_session` after each scenario. No special "benchmark mode" tools are needed beyond `start_benchmark` and `get_benchmark_progress`.

**Interaction diagram:**

```
Agent                        Finlet MCP Server
  |                                |
  |-- start_benchmark(agent_name) --->
  |<-- session_id, date_range, universe, capital (scenario 1/5)
  |                                |
  |   [trade loop: get_price_data, submit_order, advance_time, ...]
  |                                |
  |-- complete_session() ---------->
  |<-- next_session_id, progress 2/5, new date_range
  |                                |
  |   [trade loop x4 more scenarios]
  |                                |
  |-- complete_session() ---------->  (5th scenario)
  |<-- composite_score, rank, per-scenario breakdown
```

#### `start_benchmark` MCP Tool

Defined in `finlet/mcp/tools_benchmark.py`. Parameters:

| Parameter | Required | Description |
|-----------|----------|-------------|
| `agent_name` | yes | Name of the AI agent being evaluated |
| `model_used` | no | LLM model powering the agent (e.g. "claude-sonnet-4-20250514") |
| `strategy_category` | no | "momentum", "mean-reversion", "fundamental", "hybrid", "other" |
| `description` | no | Brief description of the agent's approach |
| `data_sharing_opted_in` | no | Whether to share results on the public leaderboard (default false) |
| `api_key` | no | API key for authentication (omit for unauthenticated stdio access) |

The tool creates a `BenchmarkRun` via `benchmark_state.create_benchmark_run()`, then creates the first scenario session via `benchmark_state.create_scenario_session()`. Only one active (running) benchmark run per user is allowed at a time.

**Atomic rollback on scenario-session-create failure (MCP benchmark harness fix, 2026-05-19 — Team B):** `create_scenario_session` is wrapped in try/except inside `start_benchmark`. On exception, `delete_benchmark_run(run_id)` removes the just-persisted record from both `_active_runs` and SQLite atomically before the structured error envelope is returned. Without rollback, a failed `create_scenario_session` would leak a half-built `benchmark_run` with `current_session_id=None`, and the next `start_benchmark` call would trip the single-active-per-user guard against the leaked record. Sibling defense: `get_active_run_for_user()` now skips and deletes any candidate run where `status="running"` AND `current_session_id is None` AND `created_at < now-60s`, auto-recovering legacy orphans without manual DB intervention. See `docs/decisions/mcp-benchmark-fundamentals-coverage.md` D2.

**Dual-audience response pattern:** The tool response is split between agent-visible and human-visible content:
- **Agent-visible** (returned in the MCP tool response): `benchmark_run_id`, `session_id`, scenario number ("1 of 5"), date range, universe, initial capital, time step, and a generic instruction to trade using MCP tools. No scenario name, description, or regime hints.
- **Human-visible** (emitted via `structlog.info` to stderr/terminal): scenario name, description, progress ("1/5"), agent name, benchmark run ID. This appears in the Claude Code terminal, Codex output, etc., but is never part of the MCP tool response the agent receives.

#### `get_benchmark_progress` MCP Tool

Defined in `finlet/mcp/tools_benchmark.py`. Accepts only `api_key` (optional). Returns the current scenario number, total scenarios, remaining scenarios, and run status. Useful when an agent loses context mid-run. Does NOT reveal scenario names or descriptions.

#### Scenario Transition in `complete_session`

`finlet/api/services/session_service.py::complete_session()` is benchmark-aware. After completing a session normally (freezing clock, sealing trace, persisting state), it checks whether the session belongs to an active benchmark run via `benchmark_state.get_run_for_session(session.id)`.

**Mid-benchmark (scenarios 1-4):**
1. Extracts portfolio metrics from the completed session (`session.portfolio.get_metrics()`)
2. Computes reasoning score from the session trace via `scoring.compute_reasoning_score(session.trace.entries)`
3. Builds a `ScenarioResult` with sharpe, return_pct, max_drawdown, final_value, reasoning_score, trade_count, win_rate
4. Advances the benchmark run via `benchmark_state.advance_scenario()` (records result, bumps index, persists)
5. Logs `benchmark_scenario_complete` with a one-line summary via `format_scenario_summary_line()`
6. Creates the next scenario session via `benchmark_state.create_scenario_session()`
7. Returns an agent-blind transition response: `status: "benchmark_transition"`, completed and next session IDs, progress count, next session parameters (start_time, end_time, universe, initial_capital)

**Final scenario (scenario 5):**
1. Steps 1-5 same as above
2. Calls `benchmark_state.complete_benchmark()` which computes the composite score via `scoring.compute_composite_score()`
3. Posts results to the leaderboard via `leaderboard.service.record_benchmark_result()` which creates an `AgentProfile`, persists it, recalculates global rankings
4. Builds a formatted results table (plain ASCII for the MCP response, ANSI-colored for stderr) and an export dict via `reporting.py`
5. Returns: `status: "benchmark_complete"`, `run_id`, `composite_score`, `rank`, `agent_id`, per-scenario breakdown (index-based, no scenario names), `results_table` (plain ASCII), `export` (structured dict for JSON serialization)

**Idempotency, atomicity, and coherence guards (Codex bug `ce8de077`, 2026-05-19 — Teams A/B/C):** Before recording a `ScenarioResult`, `complete_session` runs three guards in order: (1) idempotency — if `benchmark_state.get_recorded_result_for_session(run, session.id)` returns a recorded result, return a `benchmark_transition` envelope rebuilt from the recorded data without re-advancing; (2) scenario/session coherence — assert `session.config.start_time == BENCHMARK_SCENARIOS[run.current_scenario_index].start_time` AND `...end_time == ...end_time`, refuse with `scenario_session_mismatch` on mismatch; (3) atomicity — wrap `advance_scenario` + `create_scenario_session` in try/except, call `benchmark_state.rollback_last_advance(run.run_id, scenario.id)` on failure and return `complete_session_failed_recoverable`. See "Benchmark Scenario Lifecycle Invariants" below and `docs/decisions/complete-session-benchmark-idempotency.md`.

#### Agent-Blind Design

The benchmark enforces a strict information barrier between what the agent sees and what the human operator sees:

| Data | Agent sees | Human sees |
|------|-----------|------------|
| Scenario name/ID | Never | Yes (structlog) |
| Scenario description | Never | Yes (structlog) |
| Regime hints | Never | Never |
| Date range | Yes | Yes |
| Universe/capital | Yes | Yes |
| Progress ("2/5") | Yes (index only) | Yes (with names) |
| Per-scenario scores | Yes (by index) | Yes (by name) |

This is the core differentiator of Finlet's benchmark vs. a simple backtest. Models have seen "COVID crash March 2020" in training data and could front-run without reasoning about price data. Blind design forces genuine reasoning from market data delivered through tools, rather than pattern-matching on scenario labels. Date awareness is intentionally not considered a leak -- the agent must still reason from price data to trade effectively.

#### Session-Level Blind Mode (extension 2026-05-22, exec-plan v12)

Session-level blind extends the same `T_NNNN` + `Day_N` mapping mechanism from the canonical 5-scenario benchmark surface to ANY session created via `create_session`. Agents dogfooding Finlet on ad-hoc custom periods + custom universes now get the same era-anonymization the canonical benchmark surface gives. Shipped 2026-05-22 via 7-team exec-plan (A→G) + 6 fix commits (Codex Team A P1+P2 catalog union/atomicity, Team A Round 2 scope-to-api-driven, Team A Round 4 BLOCKER unforgeable-marker, Team B P1 wall-clock audit redaction, Team D P1 CLI response echo, Team E test-quality). Combined smoke gate: 3468 passed. Decision record: `docs/decisions/session-level-blind-extends-create-session.md`.

**Entry point — `create_session(blind: bool = False)`.** MCP `mcp__finlet__create_session` is the canonical entry; REST `POST /v1/sessions` derives from it via the same service-layer helper. (The `finlet sessions create --blind` CLI surface that shipped in the original session-level-blind exec-plan was deleted in v2.0.0 — see `docs/decisions/v2-pure-mcp-migration.md`. Agents invoke `create_session(blind=True)` through their MCP client instead.) When `blind=True`, the service-layer `create_session` (in `finlet/api/services/session_service.py`):
1. Constructs the session with `name=""` placeholder.
2. Activates the session, then sets `session.name = f"blind-{session.id[:8]}"` (auto-name; user input on `name` is ignored).
3. Calls `BlindMapping = generate_mapping(normalized_universe, start_time, benchmark_ticker=...)` from `finlet/core/blind_mapping.py` — the SAME factory used by `create_scenario_session` for the benchmark path.
4. Attaches `session.blind_mapping = mapping` and `session.config.blind = True` BEFORE the first `await save_session(session)`. The DB row is never persisted in a half-built state where `blind=True` is set without a populated mapping.

**Universe — catalog membership enforced at the SERVICE layer; arbitrary 50-cap removed.** The previous `SessionCreateRequest.universe: Field(max_length=50)` is gone. Every requested ticker MUST appear in `_get_catalog()` (the UNION of `_UNIVERSE_SOURCES` — 270 tickers from `scripts/ticker_lists/us_equities.txt` + `scripts/ticker_lists/us_etfs.txt` — AND every `scenario.universe` ticker referenced by `BENCHMARK_SCENARIOS` in `finlet/leaderboard/benchmarks.py`). Off-catalog tickers get `"ticker '<X>' not in catalog — call list_available_tickers"`. The same check fires on `configure_session(universe=...)` for non-blind sessions (catalog enforcement was previously a `configure_session` back door; Codex Step 10h BLOCKER 5). Enforcement is SERVICE-LAYER only — the request-schema `validate_universe` validators in `finlet/api/routes_session.py` ran the per-ticker shape gate ONLY, NOT the catalog check (Codex Team A Round 4 reverted an earlier dual-enforcement design). Reason: Pydantic validators don't have access to the authenticated `UserRecord` (request context resolves AFTER schema validation), so they can't honour the catalog-bypass marker. Routing the bypass through the service layer keeps a single enforcement point where the bypass marker is in scope.

**Catalog bypass — unforgeable `UserRecord.is_internal_benchmark` marker (Codex BLOCKER follow-up, 2026-05-22).** Benchmark scenarios reference symbols (e.g. `BTC-USD`) that are deliberately absent from the discovery catalog, so the api-driven `ApiDrivenStrategy` runner needs a catalog bypass to submit scenario universes. The bypass is keyed off the `is_internal_benchmark: bool = False` field on `finlet.auth.service.UserRecord`. The flag is unforgeable because (a) it is NOT a column on `ApiKeyModel` (`_record_to_model` / `_model_to_record` never round-trip it through SQLite — DB-row injection or direct `UPDATE api_keys SET ...` cannot set it), (b) it is NOT exposed in `RegisterRequest`, `create_key`, or `register_with_password` signatures (every user-facing registration path leaves it at the default `False`), and (c) the ONLY path that can set it to `True` is `_inject_benchmark_api_key` in `finlet/leaderboard/api_strategy.py`, which builds the `UserRecord` directly and calls module-internal `AuthService.insert_record`. A prior version of this bypass keyed off `user.email == BENCHMARK_API_EMAIL` (literal `"benchmark@finlet.dev"`) — Codex caught that `/auth/register` normalises emails with `.strip().lower()` and does NOT blocklist any address, so any caller could register an account with that exact email and bypass the catalog. `BENCHMARK_API_EMAIL` is retained as a log-provenance constant only; the docstring warns against reusing it as an authz marker. Regression locked by `tests/api/test_session_create_blind.py::test_forged_benchmark_email_cannot_bypass_catalog` (mints a key via `create_api_key(email=BENCHMARK_API_EMAIL, ...)` and asserts POST /sessions returns 422) + `tests/leaderboard/test_api_strategy.py::test_injected_user_carries_internal_benchmark_marker`. Universe normalization (`list(dict.fromkeys(t.strip().upper() for t in universe if t.strip()))`) fires at service entry for both paths. Pricing tiers no longer cap universe size (`max_tickers=None` on Free and Builder in `finlet/billing/stripe_config.py`).

**`configure_session` atomicity — validate-then-mutate (Codex Team A P2, 2026-05-22).** `configure_session` validates ALL inputs BEFORE mutating any session state. The prior ordering assigned `session.name` first, then ran catalog validation on `universe` — when validation raised, the rename leaked into the in-memory session until the next reload. Now: catalog membership + `time_step` parse run first; only on clean validation do `name` / `universe` / `time_step` commit. Locked by `tests/services/test_session_service.py::TestConfigureSessionAtomicity::test_universe_validation_runs_before_name_mutation`.

**`configure_session` lockdown on blind sessions.** Both `universe` and `name` changes are rejected with 409 on blind sessions. The `BlindMapping` is built at create-time and changing the universe mid-session would either invalidate the mapping or require a re-seed that breaks the agent's deterministic `T_NNNN` ↔ real-ticker correspondence.

**`_blind_mapping_for(session)` single source of truth.** The helper that returns `session.blind_mapping if session.config.blind else None` is moved from `finlet/api/serializers.py` into `finlet/api/services/session_service.py` (Team A). `serializers.py` re-imports it for back-compat. Direction is forward: services → serializers (no circular import). All routes layer consumers (`routes_portfolio.py`, `routes_sse.py`, `routes_public_session.py`, `routes_session.py`) import via either module — the function object is identical because `serializers.py` only re-exports.

**MCP success-path wrapping.** Service helpers (`pause_session`, `resume_session`, `complete_session`) UNCHANGED. MCP tool wrappers call the service for state mutation, then re-derive a blinded response from the session object via `_blind_mapping_for(session)`. The non-benchmark `complete_session` MCP wrap is scoped to `response.get("status") == "COMPLETED"` only (uppercase, per `SessionStatus.COMPLETED.value`); the existing `benchmark_transition` AND `benchmark_complete` envelopes at `finlet/mcp/server.py` retain their own pre-existing blinding paths and are NOT overridden (Codex Step 10h BLOCKER 1 + Step 10i BLOCKER 1).

**`freeze_time` clock-tool gap closed.** `finlet/mcp/server.py::freeze_time` previously returned `_svc_freeze_session(session)` directly with REAL clock dates. `get_sim_time` already applied `_blind_clock_dict` and `advance_time` already applied `_blind_advance_result`. The session-level blind work closes the `freeze_time` gap and audits all other clock-touching MCP tools (`step_time`, `play`, `pause_clock` if present) for the same pattern.

**`SessionResponse.blind: bool` exposed at top level.** `session_response()` populates `d["blind"]` at the top level (mirroring the existing `d["public"]` line). `SessionConfigResponse.blind: bool = False` ensures the nested `config.blind` round-trips. The dashboard can render an "blind active" badge for owners as a follow-up dashboard-only PR.

**Wall-clock audit fields REDACTED (not blinded) on blind responses (Codex Team B P1, 2026-05-22).** `session.created_at` and `session.updated_at` are WALL-CLOCK audit timestamps, NOT simulation dates. Routing them through `apply_date(Day_N)` would be a real information leak: an agent with knowledge of today's wall-clock date + the emitted `Day_N` offset could compute `Day_1 = wall_clock_today - (Day_N - 1) days` and reverse-derive the blind session's real `config.start_time`. On blind responses, `session_response()` (and the `_apply_blind_to_response` walker for public-session payloads) replaces these fields with the literal sentinel string `"redacted"` as the FINAL post-processing step, AFTER any defensive blind transform — so future date-walking transforms inserted above cannot re-leak. Owner-view (non-blind) responses still emit real ISO-8601 timestamps. `SessionResponse.created_at` and `PublicSessionResponse.created_at` were retyped from `datetime` to `str` so the `"redacted"` sentinel validates through FastAPI's `response_model`. Locked by `TestSessionResponseBlind.test_blind_session_response_redacts_wall_clock_created_at` + `TestPublicSessionResponseWallClockRedaction.test_blind_public_session_redacts_created_at`.

**Reveal lifecycle = existing visibility flags.** No new `decrypt_session` MCP tool. Public viewer visibility is toggled via the EXISTING `set_session_visibility(public=True, public_anonymous=False)` surface — toggling `public_anonymous=False` reveals real universe + dates to public viewers; toggling back to `True` re-blinds them. No persisted `revealed_at` state, no `decrypted_universe` column, no new migration.

**Owner-surface audience mix preserved (NOT harmonized in this iteration).** HEAD's authenticated-owner behavior is MIXED: REAL on `routes_session.py` / `routes_portfolio.py::/portfolio` / `routes_clock.py` / `routes_trade.py`; BLINDED on `routes_portfolio.py::/trace` / `routes_market.py::*` / `routes_sse.py`. This work preserves the mix. Harmonizing it would require a new "owner-authenticated" axis on `_blind_mapping_for` and is deferred. See the decision record's "Deferred" section and the corrected audience matrix in `docs/brainstorms/SESSION_LEVEL_BLIND_REQUIREMENTS.md`.

**Leak-detection acceptance — both-and.** Tests exercise (a) `assert_no_real_blinded_data(payload, session.blind_mapping)` as a structural chokepoint on every owner-facing-but-blind-routed response AND (b) a serialized grep gate that asserts ZERO hits for every real ticker from the user universe + `benchmark_ticker` + `_KNOWN_BENCHMARK_TICKERS` entries + every ISO date string in `[start_time, end_time]`. Test fixtures monkeypatch `FINLET_BLIND_ASSERT=raise` so the chokepoint raises rather than silently logging. The `@blind_error_mapper`-decorated MCP tool list is enumerated dynamically from `mcp._tool_manager.list_tools()` at test runtime — current count is ~34 callsites; the test does not hard-code the number.

#### Auto-Resolve with COMPLETED Session Filtering

`finlet/mcp/auth.py::_default_session_id()` filters out sessions with `SessionStatus.COMPLETED` when auto-resolving which session to use. This is critical for benchmark transitions: when scenario 1's session is completed and scenario 2's session is created, all MCP tools that auto-resolve session_id (e.g., `submit_order`, `get_price_data`) automatically target the new active session without the agent needing to pass `session_id` explicitly. The agent experiences a seamless transition between scenarios.

**Benchmark-aware preference (MCP benchmark harness fix, 2026-05-19 — Team C):** `_default_session_id()` first probes `get_active_run_for_user(user_id)` and, if it returns a run with a valid `current_session_id` that resolves to a live session, prefers that session over any other non-completed session. This closes a silent correctness bug where a user with both a benchmark session AND an unrelated dev session would see auto-resolve pick the wrong portfolio for `submit_order`. Explicit `session_id=...` always wins; the benchmark-first preference only fires when the caller omits the parameter. Fallback to the existing "exactly one non-completed session" logic is preserved. See `docs/decisions/mcp-benchmark-fundamentals-coverage.md` D3.

**Stale-routing transparency (Codex bug `ce8de077`, 2026-05-19 — Team A):** When `active_run.current_session_id` is non-null but the resolved session is COMPLETED, deleted, or not owned by the caller (i.e. `candidate_sid NOT in owned`), `_default_session_id` now raises a structured `benchmark_routing_stale: benchmark <run_id> has current_session_id <sid> which is no longer active ...` error INSTEAD of falling through to the misleading "Multiple sessions active" ambiguity raise. The MCP wrapper (`auth.py::_resolve_session`) converts it to the standard structured-error envelope. Agents get an actionable next-step (complete or abandon the benchmark) instead of being pointed at an unrelated session and silently corrupting state. See `docs/decisions/complete-session-benchmark-idempotency.md` (Invariant 4).

#### Benchmark Scenario Lifecycle Invariants

The benchmark surface enforces seven production-code invariants that close out the Codex bug `ce8de077` failure cascade (CODEX_BUG_CE8DE077 batch, 2026-05-19 — Teams A/B/C). Invariants 1-6 + 8 are production-code enforced; the original Invariant 7 is a regression test, not a production-code invariant — shipped earlier in the prior Team D commit `7806da6`. The invariants live across the engine, leaderboard, and MCP layers; each is enforced at the layer closest to the bug surface. Decision record: `docs/decisions/complete-session-benchmark-idempotency.md`.

1. **`complete_session` is truly idempotent.** Calling `complete_session(s)` N times produces exactly ONE benchmark advancement. Enforced at `finlet/api/services/session_service.py::complete_session` (line 419) via `benchmark_state.get_recorded_result_for_session(run, session.id)` (`finlet/leaderboard/benchmark_state.py` (see lines 238, 295, 370, 505)). When a recorded result exists for `session.id`, the function returns a `benchmark_transition` envelope rebuilt from the recorded result — same shape as the first call would have returned — without re-running `bs_advance_scenario`.
2. **Atomic benchmark advancement OR rollback.** The `bs_advance_scenario` + `create_scenario_session` sequence in `complete_session` (line 419) is wrapped in try/except. On exception, calls `benchmark_state.rollback_last_advance(run.run_id, scenario.id)` (`finlet/leaderboard/benchmark_state.py` (see lines 238, 295, 370, 505)) which decrements `run.current_scenario_index`, removes the last `ScenarioResult`, and DELETEs the matching `BenchmarkScenarioResultModel` row via the new `delete_benchmark_scenario_result_by_run_and_scenario` helper (`finlet/db/leaderboard_persistence.py` (line 318)). Returns `{"error": {"code": "complete_session_failed_recoverable", ...}}`. At the leaderboard layer, `advance_scenario` (line 370) and `create_scenario_session` (line 505) snapshot pre-mutation state and roll back in-memory mutations on DB-write failure.
3. **Scenario/session coherence check.** Before recording a `ScenarioResult`, `complete_session` (line 419) asserts `session.config.start_time == BENCHMARK_SCENARIOS[run.current_scenario_index].start_time` AND `session.config.end_time == ...end_time`. On mismatch, returns `{"error": {"code": "scenario_session_mismatch", ...}}` and refuses to record. Prevents diverged state from silently corrupting the leaderboard.
4. **`_default_session_id` stale-routing transparency.** Covered in "Auto-Resolve with COMPLETED Session Filtering" above.
5. **`delete_session` refuses on benchmark-current.** `finlet/api/services/session_service.py::delete_session` (line 314) imports `get_run_for_session` and refuses with structured `session_is_benchmark_current` error when the session being deleted is a benchmark's `current_session_id`. Agents are directed to call `complete_session` (to advance the scenario) or `delete_benchmark_run` (to abandon the entire run) instead. Prevents silent benchmark-state corruption from delete-time mutation.
6. **Clock bounds on `Session` lifecycle.** `SessionConfig` (line 89) gains a Pydantic `model_validator(mode="after")` asserting `end_time is None OR start_time <= end_time`. `Session.complete()` (line 194) adds a clock-bounds defense: if `clock.get_time() > config.end_time`, logs `session_complete_clock_past_end` via `structlog` AND calls a new `SimClock.clamp_to_end()` (line 310) helper that idempotently sets `_current_time = _end_time` BEFORE the freeze. Defense-in-depth — the clamp keeps the persisted clock in bounds; the warning surfaces upstream regressions in the date ceiling enforcer or the clock-advance clamp.
8. **`_build_resume_hint` coherence guard.** `finlet/mcp/tools_benchmark.py::_build_resume_hint` (line 56) asserts `live_session.config.start_time == scenario.start_time` AND `live_session.config.end_time == scenario.end_time` after fetching the live session. On mismatch, returns `{"error": {"code": "benchmark_run_inconsistent_state", "run_id": ..., "scenario_index": ..., ...}}` envelope INSTEAD of the previous mixed `{scenario: {...}, clock: {...}}` payload. Surfaces diverged state explicitly everywhere `_build_resume_hint` is called (`start_benchmark` lockout, `get_benchmark_progress`).

**New structured-error codes (added to the `finlet/mcp/_errors.py::structured_error` family):** `benchmark_routing_stale`, `scenario_session_mismatch`, `complete_session_failed_recoverable`, `session_is_benchmark_current`, `benchmark_run_inconsistent_state`. All preserve the top-level `"error"` key per `docs/decisions/2026-05-19-mcp-structured-error-envelope.md`.

**New leaderboard primitives** (`finlet/leaderboard/benchmark_state.py` (see lines 238, 295, 370, 505)):
- `get_recorded_result_for_session(run: BenchmarkRun, session_id: str) -> ScenarioResult | None` — synchronous; scans `run.scenario_results` for a matching `session_id`. Used for Invariant 1 idempotency detection.
- `rollback_last_advance(run_id: str, scenario_id: str) -> None` — async, idempotent; reverts the last `advance_scenario` call (decrements index, pops `scenario_results`, DELETEs the persisted `BenchmarkScenarioResultModel` row). Used for Invariant 2 atomicity.

**New DB helper** (`finlet/db/leaderboard_persistence.py` (line 318)):
- `delete_benchmark_scenario_result_by_run_and_scenario(run_id: str, scenario_id: str) -> None` — idempotent SQL DELETE by composite key. Used by `rollback_last_advance`.

**New engine helper** (`finlet/core/clock.py` (line 310)):
- `SimClock.clamp_to_end() -> None` — idempotent; sets `_current_time = _end_time` when out-of-bounds. Used by `Session.complete()` for Invariant 6 defense-in-depth.

#### Benchmark State Model

`finlet/leaderboard/benchmark_state.py` manages benchmark lifecycle with in-memory state and write-through SQLite persistence. Follows the same hydrate-on-startup pattern as `leaderboard/service.py`.

**`BenchmarkRun` dataclass** (in-memory):
- `run_id`, `user_id`, `agent_name`, `model_used`, `strategy_category`, `description`
- `current_scenario_index` (0-based, incremented after each scenario)
- `status`: `"running"` | `"completed"` | `"failed"`
- `current_session_id`: tracks which simulation session is active
- `scenario_results`: list of `ScenarioResult` (sharpe, return_pct, max_drawdown, final_value, reasoning_score, trade_count, win_rate)
- `composite_score`: computed on completion
- `data_sharing_opted_in`: controls public leaderboard visibility

**Lifecycle:** created (via `create_benchmark_run`) -> running (scenarios advance via `advance_scenario`) -> completed (via `complete_benchmark`, which computes composite score)

**State cache:** `_active_runs: dict[str, BenchmarkRun]` keyed by run_id. Startup hydration via `load_benchmark_state()` loads all runs and their scenario results from SQLite.

**Key functions:**
- `create_benchmark_run()` -- creates run, enforces single-active-per-user, persists
- `get_active_run_for_user()` / `get_run_for_session()` -- lookup by user or session
- `advance_scenario()` -- records ScenarioResult, bumps index, persists
- `complete_benchmark()` -- computes composite score via `scoring.compute_composite_score()`, marks completed
- `create_scenario_session()` -- creates a simulation session from a frozen `BenchmarkScenario` definition, updates `current_session_id`

#### Scoring

`finlet/leaderboard/scoring.py` implements the composite scoring formula:

```
composite = 0.25 * normalized_sharpe
          + 0.20 * normalized_return
          + 0.25 * (1 - max_drawdown)
          + 0.15 * consistency
          + 0.15 * reasoning_quality
```

- **Sharpe** (25%): average Sharpe ratio across scenarios, sigmoid-clamped to [0,1] via `(avg_sharpe + 1.0) / 4.0`
- **Return** (20%): average total return %, sigmoid-clamped to [0,1] via `(avg_return + 0.5) / 2.0`
- **Drawdown** (25%): average max drawdown, inverted (lower is better)
- **Consistency** (15%): `1 - coefficient_of_variation` of per-scenario returns, clamped to [0,1]. Measures performance stability across diverse regimes
- **Reasoning quality** (15%): average of three sub-metrics from the trade trace: reasoning coverage (fraction of trades with reasoning text), research ratio (queries per trade, 5+ = perfect), query diversity (fraction of distinct query types used: search, price, fundamental, filing, economic)

For single-agent scoring (`compute_composite_score`), values are self-normalized. For global rankings (`recalculate_rankings`), all components are min-max normalized across all leaderboard entries before weighting.

#### Benchmark Reporting

`finlet/leaderboard/reporting.py` provides four standalone functions for rendering benchmark results:

- `format_results_table(scenario_results, composite_score, rank, agent_name)` — Plain ASCII table (no ANSI) suitable for MCP tool responses. Uses `rich.table.Table` with `Console(force_terminal=False)` to produce clean text.
- `format_results_table_colored(scenario_results, composite_score, rank, agent_name)` — ANSI-colored table for stderr/terminal output. Uses `rich.table.Table` with color styles for human readability.
- `build_export_dict(benchmark_run, profile, scenario_results)` — Structured dict for JSON serialization. Includes agent metadata, composite score, rank, and per-scenario breakdown with return, sharpe, drawdown, trade count, and win rate.
- `format_scenario_summary_line(scenario_index, total_scenarios, result)` — One-line structlog summary for scenario completion events.

**Integration points:**
- `session_service.complete_session()` calls `format_results_table()`, `format_results_table_colored()`, and `build_export_dict()` on benchmark completion. The plain table and export dict are included in the MCP response (`results_table` and `export` fields). The colored table is logged to stderr for the human operator.
- `session_service.complete_session()` calls `format_scenario_summary_line()` on each scenario completion, logged via `benchmark_scenario_complete` structlog event.
- The `export_benchmark_results` MCP tool calls `build_export_dict()` to re-export results for completed benchmark runs on demand.

**Live progress logging:** `clock_service.advance_session()` emits a `benchmark_progress` structlog event on each clock advance during an active benchmark. The log includes: `sim_date`, `portfolio_value`, `unrealized_pnl`, `open_positions`, and `scenario` progress (e.g., "2/5"). This gives the human operator a P&L snapshot on each time step without exposing any information to the agent.

**Enhanced scenario start logging:** `start_benchmark` emits a `benchmark_scenario_started` structlog event with `date_range` (formatted as "YYYY-MM-DD to YYYY-MM-DD") and `universe` (list of tickers) for human-visible context. This is emitted to stderr only -- never included in the MCP tool response to preserve the agent-blind design.

**`complete_session` route polymorphism:** The `POST /sessions/{session_id}/complete` route does not declare a `response_model`, allowing it to return polymorphic dict responses: standard session summary (non-benchmark), `benchmark_transition` (mid-benchmark), or `benchmark_complete` (final scenario with results table and export). All other session routes retain their `SessionResponse` response models.

#### DB Schema Additions

Two new tables in `~/.finlet/leaderboard.db` (`finlet/db/leaderboard_models.py`):

**`benchmark_runs`** (`BenchmarkRunModel`):
| Column | Type | Notes |
|--------|------|-------|
| `run_id` | str (PK) | UUID |
| `user_id` | str (indexed) | FK to users |
| `agent_name` | str | |
| `model_used` | str (nullable) | |
| `current_scenario_index` | int | 0-based |
| `status` | str | "running" / "completed" / "failed" |
| `current_session_id` | str (nullable) | Active session |
| `composite_score` | float (nullable) | Set on completion |
| `created_at` | datetime | UTC |
| `updated_at` | datetime | UTC |

**`benchmark_scenario_results`** (`BenchmarkScenarioResultModel`):
| Column | Type | Notes |
|--------|------|-------|
| `id` | str (PK) | UUID |
| `run_id` | str (indexed) | FK to benchmark_runs |
| `scenario_id` | str | e.g. "bull_run" |
| `session_id` | str (nullable) | Simulation session used |
| `sharpe` | float | |
| `return_pct` | float | |
| `max_drawdown` | float | |
| `final_value` | float | |
| `reasoning_score` | float | |

#### Frozen Benchmark Scenarios

`finlet/leaderboard/benchmarks.py` defines 5 frozen scenarios as `BenchmarkScenario` frozen dataclasses. All share the default universe (AAPL, MSFT, NVDA, AMZN, GOOGL, BTC-USD), $100k initial capital, and daily time steps:

1. **Bull Run** -- Oct 2023 to Mar 2024 (AI hype / tech earnings)
2. **COVID Crash** -- Feb 2020 to Apr 2020 (pandemic crash)
3. **Sideways Chop** -- Jun 2015 to Nov 2015 (range-bound market)
4. **VIX Blowup** -- Jan 2018 to Mar 2018 (Volmageddon)
5. **Recovery Rally** -- Apr 2020 to Sep 2020 (post-crash recovery)

Scenarios are immutable. Never modify existing benchmarks.

### Blind Benchmark Mode (V1 — 2026-05-19)

Pre-trained LLM agents recognize specific tickers (NVDA, BTC-USD, AAPL) and dates (2020-02 = COVID, 2023-10 = AI rally) and exploit that pre-training rather than reason from market data. Blind Benchmark V1 maps tickers → `T_NNNN` opaque ids and dates → `Day_N` relative offsets per-session, so the agent cannot recognize the regime from the labels alone. Sector/industry tags remain visible; structural reasoning is preserved, era-recognition is neutralized. Shipped via 6-team exec-plan (A→F + self-heal). Decision records: `docs/decisions/blind-benchmark-architecture.md`, `docs/decisions/blind-benchmark-sector-literal.md`, `docs/decisions/blind-benchmark-envelope-fields-must-blind.md`.

**Mapping primitives (`finlet/core/blind_mapping.py`):** `BlindMapping` Pydantic model carries the ticker map + `date_origin`. `generate_mapping(universe, scenario_start, *, seed=None)` derives the per-session mapping from `secrets.token_bytes(16)` salt (production) or a deterministic seed (tests). The salt is **discarded after derivation** — only the mapping persists. `apply_ticker` / `apply_date` are forward transforms; `reverse_ticker` / `reverse_date` are owner-side reveal transforms. `_TICKER_SECTOR_TABLE` holds the V1 embedded sector/industry literal for the 6-ticker default universe (see sector-literal decision record).

**Persistence:** `Session.blind_mapping: BlindMapping | None` is derived state. Round-trips through the `sessions.blind_mapping_json` TEXT column via migration `015_add_session_blind_mapping.py`. `SessionConfig.blind: bool` (default `False`) is the opt-in flag, propagated from `BenchmarkRun.blind` (migration `020_add_benchmark_run_blind.py`) when the benchmark runner calls `create_scenario_session`.

**Activation path:** `start_benchmark(blind=True)` MCP tool sets `BenchmarkRun.blind=True`. `leaderboard/benchmark_state.create_scenario_session` checks `run.blind` and, if set, calls `generate_mapping(...)`, attaches the result to `session.blind_mapping`, and flips `session.config.blind=True`. Cleanup paths defensively clear `session.blind_mapping = None` + `session.config.blind = False` to prevent stale mapping carry-over.

**Three-audience model:**

| Audience | Surface | Sees |
|---|---|---|
| Agent under evaluation | MCP data-plane tools AND owner-view tools (`submit_order`, `cancel_order`, `get_portfolio`, `get_equity_curve`, `get_trace`, `advance_time`, `get_sim_time`, `complete_session`) | Blinded — `T_NNNN` tickers + `Day_N` dates on body items, envelope fields, error responses, and the `complete_session` finalization payload. `search_news` short-circuits with `{error: "tool unavailable in blind benchmark"}`. |
| Session owner (authenticated) | REST `/v1/sessions/{id}/*` + dashboard | Real ticker symbols + real ISO dates. |
| Anonymous public viewer | `/v1/public/sessions/{id}/*` (Team D serializers) | Blinded — same `T_NNNN` + `Day_N` shapes as the agent. `PublicSessionResponse.blind: bool` flags the dashboard renderer. |

The dashboard public viewer offers a Reveal toggle (sessionStorage-backed, resets on refresh) that hot-swaps the endpoint family between `/v1/public/sessions/...` (blinded) and `/v1/sessions/...` (real). Only the session owner can swap to the authenticated family.

**Architectural layering — enforcer-first, transform-second (defense-in-depth):** `DateCeilingEnforcer` continues to operate on REAL dates. The blind transform is a service-layer concern in `finlet/api/services/market_service.py::_apply_blind_transform` (price / fundamentals / filings / economic field tables) and `apply_universe_blind_filter` (the universe ticker listing). Plugin signatures unchanged — plugins emit real shapes, the service layer rewrites items + envelope before serialization. News plugin output is short-circuited at the service layer via `_NEWS_BLIND_BLOCK_ENVELOPE` (V1 anonymization is regex-insufficient; V2 needs LLM rewrite).

**Envelope-level fields MUST blind:** The blind transform covers BOTH `items[]` and the surrounding envelope — `ceiling_applied`, `rate_limit_reset`, `earliest_available`, `cached_at`, and FRED's `realtime_end` / `realtime_start` are all wall-clock dates that leak the sim era if untransformed. Team F's grep gate (`tests/e2e/test_blind_benchmark_zero_leak.py`) caught 5 envelope leak paths during finalize that the field-level unit tests had missed; self-heal patched market_service.route_query's 4 envelope fields + economic transform's 2 fields + list_available_tickers's `cached_at`. See `docs/decisions/blind-benchmark-envelope-fields-must-blind.md`.

**Error envelopes + completion payload + availability metadata MUST blind (iter2 — 2026-05-20):** Three orthogonal leak classes closed after the 2026-05-20 blind-benchmark second dry-run (`codex_bugs_blind_iter2`, main SHA `0531fc3`). (1) **Error envelopes** — every `@mcp.tool` handler is now wrapped with `@blind_error_mapper` (`finlet/mcp/blind_error.py`, applied across `finlet/mcp/server.py` + `tools_trading.py` + `tools_portfolio.py` + `tools_benchmark.py` + `tools_session.py` + `tools_telemetry.py`); the decorator auto-blinds any `str(exc)` plus top-level `error` / `message` / `detail` string fields via boundary-layer regex when the resolved session is blind. Closes Codex bug `d1baf1b8` (advance_time overrun baked `session.end_time.isoformat()` into ValueError text). (2) **`complete_session` `benchmark_complete` payload** — `results_table` rendered from a shadow `ScenarioResult` list with `Scenario_N` ids; `export` built via `build_export_dict(blind_mapping=...)` blinds `scenarios[].scenario_id`, `scenarios[].session_id`, `created_at`, `completed_at`. See `finlet/mcp/server.py` + `finlet/leaderboard/reporting.py` + `finlet/api/services/session_service.py`. Closes Codex bug `ad919e11`. (3) **`list_available_tickers` metadata-vs-reality** — synthesized-fallback rows in `apply_universe_blind_filter` (`finlet/api/services/market_service.py`) now default `has_prices=True` (and `has_fundamentals=True`) because universe membership IS the positive availability signal; an opaque ticker visible in the listing IS queryable via `get_price_data`. Closes Codex bug `53c9eccb`. The zero-leak gate (`tests/e2e/test_blind_benchmark_zero_leak.py`) now adds three dedicated functions: `test_blind_benchmark_error_paths_zero_leak` (16 error cases across every owner-view tool), `test_blind_benchmark_complete_session_payload_zero_leak` (full 5-scenario walk-through of `results_table` + `export.scenarios[]`), `test_blind_benchmark_metadata_matches_reality` (cross-checks `has_prices` claim against `get_price_data` both directions). See `docs/decisions/blind-benchmark-envelope-fields-must-blind.md` Extension 2026-05-20 ("Error paths + completion payload + metadata cross-validation").

**Public-viewer wiring (Team D):** `_blind_mapping_for(session)` in `finlet/api/routes_public_session.py` returns `session.blind_mapping` iff `session.config.blind=True` AND mapping is populated; passes it as `blind_mapping=...` kwarg to `portfolio_data`, `history_data`, `list_orders_data`, `trace_data`. Serializers in `finlet/api/serializers.py` and `finlet/api/services/trade_service.py` apply ticker + date transforms uniformly when the kwarg is non-None; authenticated REST + SSE callers omit the kwarg and see real shapes. `PublicSessionResponse.blind: bool` exposes the blind state to the dashboard renderer.

**Owner-tools-via-MCP CLOSED (2026-05-20, Codex bug `50abd05e` + iter2):** A blind-benchmark AGENT calls MCP as the session owner (authenticated), so owner-view tools (`submit_order`, `cancel_order`, `get_portfolio`, `get_equity_curve`, `get_trace`, `advance_time`, `get_sim_time`, `complete_session`) MUST blind on blind sessions — the agent IS the owner. PR #117 (2026-05-20) shipped output blinding + opaque-ticker input reverse-mapping across all owner-view tools and extended the gate to exercise 14 owner-view surfaces. The iter2 follow-up (`codex_bugs_blind_iter2`, main `0531fc3`, 2026-05-20) extended hardening to error envelopes, the `complete_session` `benchmark_complete` finalization payload, and `list_available_tickers` availability metadata — see the "Error envelopes + completion payload + availability metadata MUST blind" paragraph above. `real_time` (wall-clock-now on trace entries) remains the documented exemption (no market-data signal; gate strips it before grep).

**File map:** `finlet/core/blind_mapping.py` (mapping primitives) · `finlet/core/session.py` (`SessionConfig.blind`, `Session.blind_mapping`) · `finlet/db/session_models.py` + `finlet/db/persistence.py` + migration `015` (persistence) · migration `020` (`BenchmarkRunModel.blind`) · `finlet/api/services/market_service.py` (transform + envelope) · `finlet/mcp/server.py` (universe filter wiring) · `finlet/mcp/tools_benchmark.py` + `finlet/cli.py` (start_benchmark blind flag) · `finlet/leaderboard/benchmark_state.py` (run/session blind state) · `finlet/api/services/session_service.py` + `finlet/api/serializers.py` + `finlet/api/services/trade_service.py` + `finlet/api/routes_public_session.py` + `finlet/api/schemas/session.py` (public viewer surface) · `dashboard/public.{html,js}` + `dashboard/renderers.js` + `dashboard/styles.css` (banner + Reveal toggle + Day_N x-axis) · `tests/e2e/test_blind_benchmark_zero_leak.py` + `tests/property/test_blind_mapping_invariants.py` + `tests/api/test_public_session_blind_grep.py` (gate + invariants + grep).

### Blind Benchmark Lifecycle (Codex bug `0558053d`, 2026-05-20)

The blind-export redesign exec-plan closed Codex bug `0558053d-aa73-47e4-bd00-4a09417568d6` (`export_benchmark_results` leaked real shape on blind runs) plus 3 live trace-leak surfaces found during recon (REST owner-auth, SSE owner-auth, persisted trace). The redesign also introduced an owner-driven post-completion lifecycle for `BenchmarkRun` (decrypt → publish) and four runtime/structural invariants that make the blind-shape contract fail-loud instead of silent-leak. Decision records: `docs/decisions/benchmark-run-decrypt-publish-gate.md`, `docs/decisions/blinded-trace-persistence.md`, `docs/decisions/blind-mapping-serializer-poison.md`.

**Lifecycle state machine** (`BenchmarkRun`):

```
running --(complete_session on scenario 5)--> completed
                                                  |
                              decrypt_benchmark_run|  (blind runs only)
                                                  v
                                              decrypted (decrypted_at IS NOT NULL)
                                                  |
                              set_benchmark_visibility(public=True)
                                                  v
                                              published (published=True, published_at set)
                                                  |
                              set_benchmark_visibility(public=False)
                                                  v
                                              unpublished (published=False, published_at preserved)
```

Non-blind runs (`run.blind=False`) skip the decrypt step entirely — `set_benchmark_visibility(public=True)` works directly because there is no mapping to unlock. Blind runs (`run.blind=True`) require `decrypted_at IS NOT NULL` before publish; `set_benchmark_visibility(public=True)` raises `ValueError("benchmark_run_publish_blocked: ...")` otherwise. See `docs/decisions/benchmark-run-decrypt-publish-gate.md`.

**Decrypt is irreversible; publish is reversible.** Once `decrypted_at` is set, future re-calls preserve the original timestamp (idempotent — audit-honest "when did the owner first unlock"). Publish toggles `published` freely; un-publishing does NOT clear `published_at` (audit-preserves "when was this last public").

**New columns on `BenchmarkRunModel`** (migration `021_add_benchmark_run_decrypt_publish.py`, idempotent PRAGMA-table_info guard mirroring 020):

| Column | Type | Notes |
|--------|------|-------|
| `decrypted_at` | datetime (nullable) | Set by `decrypt_benchmark_run`; preserved on idempotent re-call |
| `published` | bool (indexed, default False) | Owner-driven public visibility |
| `published_anonymous` | bool (default True) | If True, public response strips owner attribution |
| `published_at` | datetime (nullable) | Refreshes on every `set_benchmark_visibility(public=True)`; preserved across `public=False` |

**Immutability invariant** (Team B `baf2623`, single source of truth in `finlet/leaderboard/benchmark_state.py`):
- `_transition_status(run, new_status)` rejects leaving the terminal `"completed"` status (raises `ValueError` with `benchmark_run_immutable` prefix). Idempotent re-set to `"completed"` is legal.
- `assert_run_immutable(run)` raises `ValueError("benchmark_run_not_completed: ...")` when run is not in terminal state. Called by `decrypt_benchmark_run`, `set_benchmark_visibility`, and `export_benchmark_results` (the old inline `if run.status != "completed"` raise at `tools_benchmark.py:483-490` was a Team C TODO; Team D `6d6283d` removed it — `grep 'run.status != "completed"' finlet/mcp/tools_benchmark.py` returns 0 matches).

**Surfaces** (single service-layer code path in `finlet/api/services/benchmark_service.py`, consumed by REST + MCP per `.claude/rules/api-routes.md` §Service-layer parity):

| Action | MCP owner-auth | REST owner-auth | Anonymous public |
|--------|----------------|-----------------|------------------|
| Decrypt | `decrypt_benchmark_run(run_id)` | `POST /v1/benchmark-runs/{id}/decrypt` | (n/a) |
| Visibility | `set_benchmark_visibility(run_id, public=, anonymous=)` | `PATCH /v1/benchmark-runs/{id}/visibility` | (n/a) |
| Read | (via `export_benchmark_results`) | (owner sees full lifecycle state via `_run_response`) | `GET /v1/public/benchmark-runs/{id}` + `GET .../export` |

Owner-auth REST routes return 404 (not 403) on cross-user requests — info-leakage parity with `routes_public_session.py`. 409 on service-layer `ValueError` (not-completed / publish-blocked).

**Anonymous public export is decrypt-aware.** `GET /v1/public/benchmark-runs/{id}/export` renders blinded shape (`T_NNNN` / `Day_N`) if `run.decrypted_at IS NULL`; real shape (`AAPL` / `2024-01-01`) if `decrypted_at IS NOT NULL`. The `build_export_dict` invariant in `finlet/leaderboard/reporting.py` raises `ValueError("build_export_dict_invariant: ...")` when `benchmark_run.blind=True AND blind_mapping IS None AND benchmark_run.decrypted_at IS None` — preventing silent regression by a future caller that forgets `blind_mapping=`.

**Trace persistence is write-time blinded** (`finlet/db/persistence.py:save_trace_entry`, Team A `3bc7a56`). When `session.config.blind=True`, `entry.request_params` and `entry.response_summary` are walked through `apply_blind_to_trace_payload` (`finlet/core/blind_mapping.py`) BEFORE the JSON dump. All 5 call sites pass `blind_mapping=session.blind_mapping if session.config.blind else None`:
- `finlet/api/services/market_service.py:610` (plugin query persist)
- `finlet/api/services/trade_service.py:230/271/307` (order persist + reject + auto-fill)
- `finlet/api/services/clock_service.py:88` (`persist_new_traces` helper)

The read transforms (`serializers.trace_data`, `_blind_trace_payload`) remain in place as belt-and-braces — idempotent against already-blinded data, defense-in-depth against any future read surface that bypasses the write path. `timestamp_sim` stays as a real datetime (SQL `ORDER BY` requires monotonic ordering); render-time `apply_date` over the dict-converted entry produces the blinded shape for read surfaces. See `docs/decisions/blinded-trace-persistence.md`.

**REST + SSE owner-auth trace surfaces blind on blind sessions** (Team E `cc44af5`). `finlet/api/serializers.py` exposes `_blind_mapping_for(session)` as the single source of truth for "return the session's blind mapping iff blind mode is fully wired". `routes_portfolio.py:get_trace` and `routes_sse.py:_generate_events` both call `blind_mapping=_blind_mapping_for(session)`. Non-blind shape locked by `tests/e2e/test_session_trace_nonblind_shape.py` so future refactors of `trace_data` cannot drift the byte-for-byte authenticated-renderer shape.

**`BlindMapping` serializer poison** (Team A `3bc7a56`). `BlindMapping.__getstate__` raises `TypeError` — kills `pickle.dumps` and `copy.deepcopy`. Cannot leak via response embedding even if a future tool accidentally tried (`json.dumps` on `BlindMapping` would happily ship `reverse_ticker_map` to the agent — the structural guard is the runtime backstop, not a discipline-only policy). The legitimate persistence path (`model_dump_json` → `sessions.blind_mapping_json` column) is unaffected because Pydantic v2's JSON serializer reads `__pydantic_fields__` directly. Module-level `assert_not_in_response_dict(d)` helper recursively walks a payload and raises `TypeError` with a JSON-pointer-like path if any nested value is a `BlindMapping` — service-layer boundary backstop. See `docs/decisions/blind-mapping-serializer-poison.md`.

**Zero-leak gate extensions** (Team F `e9a04e7` Session 1 + `f12b19a` Session 2, full Codex bug `0558053d` acceptance suite): `tests/e2e/test_blind_benchmark_zero_leak.py` adds T1 (completed-run export grep), T2 (capturing-AsyncMock persistence stubs assert `blind_mapping=` was passed on every save_trace_entry call site), T3 (REST + SSE owner-auth trace coverage — new file `tests/e2e/test_blind_trace_read_paths.py`), T6 (extends Test 1 to agent-callable benchmark lifecycle tools), T7 (`test_codex_bug_0558053d_export_benchmark_results_zero_leak` discrete gate). Session 2 adds T4 (BenchmarkRun immutability invariant — `tests/e2e/test_benchmark_run_immutability.py`) and T5 (decrypt → publish lifecycle gate — `tests/e2e/test_benchmark_publish_gate.py` — publish-before-decrypt blocked on blind runs; non-blind shortcut preserved; visibility flip to private immediately 404s anonymous reader; FULL DECRYPTED export grep'd against real-ticker leaks).

**Architectural shipments — 7 numbered changes:**

1. **`build_export_dict` invariant** (Team C `3f4ae66`, relaxed Team D `6d6283d`): refuses `blind_mapping=None` on blind, not-yet-decrypted runs (was silent-leak, now raises `ValueError("build_export_dict_invariant: ...")`). Relaxation for `decrypted_at IS NOT NULL` runs allows anonymous public export to render real shape post-decrypt.
2. **`save_trace_entry` write-time blinding** (Team A `3bc7a56`): all 5 call sites pass `blind_mapping=` so traces persist in opaque-ticker form. Read surfaces apply idempotent re-transform.
3. **`BlindMapping` serializer poison** (Team A `3bc7a56`): `__getstate__` raises on pickle/deepcopy. Cannot leak via response embedding via a future accidental wrap.
4. **REST + SSE owner-auth trace blinding** (Team E `cc44af5`): `GET /sessions/{id}/trace` + SSE `trace` events blinded via `_blind_mapping_for(session)`. Non-blind shape locked.
5. **`BenchmarkRun` immutability invariant** (Team B `baf2623`): `_transition_status` rejects leaving terminal; `assert_run_immutable(run)` is the single source of truth. Old inline `run.status != "completed"` check removed.
6. **decrypt → publish two-step gate** (Team D `6d6283d`): new MCP tools `decrypt_benchmark_run` + `set_benchmark_visibility`; new REST routes `/v1/benchmark-runs/<id>/visibility` (owner) + `/v1/public/benchmark-runs/<id>` (anonymous); new CLI subcommands. Publish requires prior decrypt for blind runs only.
7. **Zero-leak gate extensions** (Team F `e9a04e7` + `f12b19a`): T1/T2/T3/T6/T7 (Session 1) + T4/T5 (Session 2) — full Codex bug `0558053d` acceptance suite.

### Blind-Benchmark SSE Chokepoint (Codex bug `a93a7ff2`, 2026-05-21)

The blind-sse-defense-in-depth exec-plan closed Codex bug `a93a7ff2-39c2-48cb-8ddf-6a794686f342` (`GET /v1/sessions/{id}/stream` leaked real tickers, real ISO dates, and the scenario label `bull_run` on blind benchmark sessions via the `session` / `clock` / `portfolio` / `history` / `orders` events). This was the third surface-by-surface blind-leak repair in this area; the chokepoint backstop is the architectural step-up that bounds the next regression at CI time instead of letting it ship and be caught by Codex. Decision records: `docs/decisions/blind-sse-event-blinding.md`, `docs/decisions/blind-mapping-scenario-and-universe.md`.

**Per-call-site wiring (primary).** All 6 SSE emit sites in `finlet/api/routes_sse.py:_generate_events` receive `blind_mapping=_blind_mapping_for(session)` (the single-source-of-truth helper in `finlet/api/serializers.py` introduced in the 2026-05-20 iteration):

| Event | Serializer | Module |
|---|---|---|
| `session` | `session_response(session, blind_mapping=)` | `finlet/api/services/session_service.py` (extended this PR) |
| `clock` | `clock_dict(session, blind_mapping=)` | `finlet/api/services/clock_service.py` (extended this PR) |
| `portfolio` | `_portfolio_data(session, blind_mapping=)` | `finlet/api/routes_sse.py` (already supported, was not being passed) |
| `history` | `_history_data(session, blind_mapping=)` | `finlet/api/routes_sse.py` (same) |
| `orders` | `list_orders(session, blind_mapping=)` | `finlet/api/services/trade_service.py` (extended this PR) |
| `trace` | `trace_data(session, blind_mapping=)` | `finlet/api/serializers.py` (already correct since Team E `cc44af5`) |

**Chokepoint backstop.** Module-level `assert_no_real_blinded_data(payload, mapping)` in `finlet/core/blind_mapping.py` — recursive walker over dict/list/scalar that raises `TypeError` (or logs `real_blind_data_leaked`) if any string value matches a key in `mapping.ticker_map` OR matches an ISO date within ±366 days of `mapping.date_origin`. Applied at `routes_sse.py:_generate_events` after building each event dict, before `_sse_event` formatting. Env-gated via `FINLET_BLIND_ASSERT`:

- `"raise"` — CI / e2e tests; halts on leak with JSON-pointer-like path.
- `"log"` (default) — prod; structured-log emit and continues so a backstop false-positive does not 500 a paying customer's SSE stream.

**New forward transforms on `BlindMapping`** to support scenario labels + universe lists (see `docs/decisions/blind-mapping-scenario-and-universe.md`):

- `apply_universe(real_universe: list[str]) -> list[str]` — vectorized `apply_ticker`.
- `apply_scenario(scenario_id: str) -> str` — SHA-256-derived `S_XXXX`; cached per-mapping in `scenario_map`.
- `apply_session_name(name: str) -> str` — regex `benchmark-<uuid>-<scenario_id>` substitutes scenario suffix via `apply_scenario`; pass-through on non-match.

`session.name` continues to persist on-disk raw (operator audit trail integrity); blinding applied at READ time in `session_response`. Mirrors existing pattern for `session.config`.

**How to add a new SSE event** (4-step checklist):

1. Pass `blind_mapping=_blind_mapping_for(session)` to the serializer (use the helper; do not re-implement the "is this session blind + fully wired" predicate).
2. Have the serializer accept `blind_mapping: BlindMapping | None = None` and apply blinding when non-None — use `apply_ticker` / `apply_date` / `apply_universe` / `apply_scenario` / `apply_session_name`. Never embed the `BlindMapping` object itself (see `docs/decisions/blind-mapping-serializer-poison.md`).
3. Include the event dict in the `assert_no_real_blinded_data` chokepoint loop in `_generate_events` so the walker sees it before `_sse_event` formatting.
4. Add the event type to the read loop in `tests/e2e/test_blind_benchmark_zero_leak.py` SSE subtest so the regex grep blob exercises it.

**File map:** `finlet/core/blind_mapping.py` (`apply_universe`, `apply_scenario`, `apply_session_name`, `assert_no_real_blinded_data`) · `finlet/api/routes_sse.py:_generate_events` (6 emit sites + chokepoint) · `finlet/api/services/session_service.py:session_response` (extended) · `finlet/api/services/clock_service.py:clock_dict` (extended) · `finlet/api/services/trade_service.py:list_orders` (extended) · `tests/e2e/test_blind_benchmark_zero_leak.py` (SSE subtest extension).

**Reference:** `docs/decisions/blind-sse-event-blinding.md` (full design rationale + reversal path).

### Legacy Benchmark Path (ApiDrivenStrategy) -- Deprecated

The `ApiDrivenStrategy` (`finlet/leaderboard/api_strategy.py`) and the `run_benchmark_job()` runner (`finlet/leaderboard/runner.py`) represent the original self-play benchmark mechanism. In this path, Finlet itself drives a Python strategy class against the REST API surface rather than an external AI agent making decisions through MCP tools.

This path is **deprecated** in favor of the MCP-driven benchmark flow described above. The MCP flow is the primary mechanism because it evaluates how the MODEL reasons and trades, not a Python strategy class. The `ApiDrivenStrategy` and `SelfPlayStrategy` remain in the codebase for backward compatibility but are not the recommended benchmark path.

**Multi-source benchmark enforcement (Phase 2):** `ApiDrivenStrategy` queries the full data surface during benchmark runs -- not just OHLCV prices. Every 5 steps, the strategy queries filings (EDGAR), economic indicators (FRED), and fundamentals (Finnhub), validating enforcer correctness on each response type. This ensures the Date Ceiling Enforcer is stress-tested against heterogeneous timestamp formats (`filing_date`, `date`, `published_at`) under production conditions.

**Benchmark mock plugins:** Three deterministic mock plugins (`finlet/leaderboard/benchmark_plugins.py`) provide non-price data during benchmarks without requiring API keys:
- `BenchmarkEdgarPlugin` -- returns 10-K, 10-Q, 8-K filings with `filing_date` timestamps
- `BenchmarkFredPlugin` -- returns GDP, UNRATE, CPIAUCSL observations with `date` timestamps
- `BenchmarkFinnhubPlugin` -- returns news headlines and fundamental metrics with `date` timestamps

All mock plugins are duck-typed (matching the `BenchmarkPricePlugin` pattern), not subclasses of `DataPlugin`. They return `PluginResponse`, respect `ceiling_time`, and generate deterministic data seeded by scenario ID. See `docs/decisions/benchmark-mock-duck-typing.md` for rationale.

**Cross-source enforcer validation:** 22 integration tests (`tests/plugins/test_cross_source_enforcement.py`) prove the enforcer correctly strips future data across all timestamp formats from EDGAR, FRED, and Finnhub. 12 E2E tests (`tests/leaderboard/test_benchmark_enforcement.py`) validate no future data leaks from any source during full benchmark runs.

Profiles and benchmark jobs are persisted to `~/.finlet/leaderboard.db` via SQLite.

Benchmark submissions are limited to **10 per day per user** to prevent abuse.

---

## Strategies (`strategies/`)

Top-level sibling to `finlet/` and `legacy/` holding non-pip strategy subprojects. The first (and currently only) tenant is `strategies/ai_quantamental/` — a dogfooding AI-quantamental rebalance bot that doubles as launch-video content material and a Finlet bug-finder. Shipped 2026-05-19 via 7-team exec-plan. Decision record: `docs/decisions/ai-quantamental-subproject-v1.md`.

**Layout (nested package form):**

```
strategies/ai_quantamental/
├── pyproject.toml          # distribution name "ai-quantamental"; classifier "Private :: Do Not Upload"
├── README.md
├── ai_quantamental/        # importable package (nested one level deep)
│   ├── __init__.py
│   ├── types.py            # Candidate, Portfolio, RebalanceResult dataclasses
│   ├── portfolio.py        # equal-weight constructor, intersection-collapse fallback
│   ├── metrics/            # derived ratios from raw EDGAR concepts
│   │   ├── ttm.py          # trailing-twelve-month rollups
│   │   ├── ratios.py       # P/E, P/B, gross profits/assets, ROE/ROIC, FCF yield, ...
│   │   └── fundamentals_client.py
│   ├── screens/            # two parallel rules-based screens + intersection
│   │   ├── quality.py      # Novy-Marx gross profits/assets primary
│   │   ├── momentum.py     # Jegadeesh-Titman 12-1 total return
│   │   └── intersection.py
│   ├── llm_tiebreaker/     # Claude-API narrowing pass on the ~30-name intersection
│   │   ├── tiebreaker.py   # graceful fallback to alphabetical when LLM call fails
│   │   ├── client.py
│   │   └── prompts.py
│   ├── backfill/           # 12-month historical backtest harness (launch-video material)
│   │   ├── driver.py       # month-by-month sim against sim clock
│   │   ├── output.py       # JSON/CSV trade log + equity curve + Markdown narrative
│   │   ├── spy_benchmark.py
│   │   ├── cli.py
│   │   └── __main__.py
│   └── live/               # forward-walk driver for monthly cron
│       ├── driver.py       # advance_time → screens → tiebreaker → submit_order
│       ├── output.py       # public-friendly Markdown + JSON to strategies/ai_quantamental/runs/
│       ├── cli.py
│       └── __main__.py
└── tests/                  # subproject-local pytest suite
```

The nested layout (`strategies/ai_quantamental/ai_quantamental/`) is deliberate: it lets `pyproject.toml` live INSIDE the subproject directory so the subproject ships with its own `[project]` metadata + `[tool.hatch.build.targets.wheel] packages = ["ai_quantamental"]` directive, while still presenting a clean `import ai_quantamental.screens.quality` from any sibling pip-installed venv. See `docs/decisions/ai-quantamental-subproject-v1.md`.

**Not in the Finlet pip wheel.** Hatchling's default `[tool.hatch.build.targets.wheel]` in the root `pyproject.toml` lists `packages = ["finlet"]` — anything outside that tree (including `strategies/`, `legacy/`, `scripts/`, `dashboard/`) is automatically excluded from the published `finlet-*.whl`. The subproject is installed by its own `pip install -e strategies/ai_quantamental` invocation (e.g. inside the GH Actions monthly cron). Future pip-packaging of `ai-quantamental` itself is deferred — for now it's developer-/CI-only.

**Ownership.** Path-scoped rules: `strategies/` → `strategies` team (see `CLAUDE.md` File Ownership table and `.claude/rules/file-ownership.md`). Each strategy is its own subproject root; cross-strategy abstractions are explicitly out of scope until a second strategy lands.

**Monthly rebalance cron.** Live operation is automated via `.github/workflows/quantamental-rebalance.yml` (`cron: '0 21 1 * *'` — 21:00 UTC on the 1st of each month, plus `workflow_dispatch` for ops dry-runs). The job `pip install -e .[ingest]` + `pip install -e strategies/ai_quantamental`, runs `python -m ai_quantamental.live rebalance --month YYYY-MM`, auto-commits the produced `strategies/ai_quantamental/runs/YYYY-MM.{md,json}` back to main as `finlet-bot[ai-quantamental]`, and opens a GitHub issue on failure. Idempotency marker lives at `s3://finlet-bug-reports/quantamental/last-rebalance.json` (re-uses Team B's `report_bug` S3 bucket — no second bucket needed). Bearer token for the live driver is supplied as `FINLET_OAUTH_BEARER` repo secret and AWS access via `AWS_DEPLOY_ROLE_ARN` OIDC role.

---

## Tech Stack

### Runtime Dependencies
| Package | Purpose |
|---------|---------|
| `fastapi` ≥0.115 | REST API |
| `uvicorn[standard]` ≥0.30 | ASGI server |
| `httpx` ≥0.27 | Async HTTP client (plugins) |
| `aiosqlite` ≥0.20 | Async SQLite driver |
| `sqlmodel` ≥0.0.22 | ORM (SQLAlchemy + Pydantic) |
| `mcp` ≥1.2 | FastMCP server SDK |
| `edgartools` ≥3.0 | SEC EDGAR filings |
| `fredapi` ≥0.5 | FRED economic data |
| `finnhub-python` ≥2.4 | News + fundamentals |
| `typer` ≥0.12 | CLI framework |
| `pydantic` ≥2.9 | Data validation |
| `alembic` ≥1.14 | Database migrations |
| `structlog` ≥24.1 | Structured logging (JSON in prod, console in dev) |
| `markdown` ≥3.6 | Legal page rendering |
| `stripe` ≥8.0 | Billing integration |
| `pyarrow` ≥15.0 | Parquet file reading (PricePlugin) |
| `boto3` ≥1.34 | AWS S3 + SSM access |
| `pyotp` ≥2.9 | TOTP MFA |
| `qrcode[pil]` ≥7.4 | QR code generation for TOTP setup |
| `cryptography` ≥42.0 | Token hashing, key derivation |
| `email-validator` ≥2.1 | Email format validation |
| `argon2-cffi` ≥23.1 | Password hashing (argon2id) |

### Optional Dependencies
| Package | Extra | Purpose |
|---------|-------|---------|
| `boto3` ≥1.34 | `sms` | SMS OTP delivery via AWS SNS |

### Dev Dependencies
`pytest`, `pytest-asyncio`, `pytest-cov`, `hypothesis` (property-based testing), `httpx` (test client), `ruff`, `mypy`, `pip-audit`, `bandit`, `types-Markdown`.

Dashboard JS unit tests run on Node's built-in test runner (`node --test`) — separate from the pytest suite so future agents do not assume the dashboard has zero JS tests. Production coverage: `tests/dashboard/event-bus.spec.js` (subscribe/publish/unsubscribe semantics, error isolation, snapshot-before-iterate, frozen surface; `getLastPublished` cases for never-published, most-recent-payload retention, argument validation). Playwright remains the primary end-to-end runner for read-only dashboard journeys (sessions list, equity curve render, plugin health load). Write-path Node specs (`form-dirty-tracker.spec.js`, `dialog-state-mirror.spec.js`) and write-path e2e journeys moved to `legacy/tests/dashboard/` and `legacy/tests/e2e/` in the 2026-05-06 launch cut.

### Integration Test Tier (`tests/integration/`)

Added 2026-05-09 in Phase 4d/D2 (commit `c013563`) as a new tier above `tests/api/` and `tests/mcp/` for true end-to-end flows that require a running HTTP/MCP server (not a `TestClient`). Covers OAuth Authorization Code flow, raw HTTP MCP-Inspector flow, and dual-accept regression — each test exercises the full stack from CLI invocation through `/oauth/authorize` + `/oauth/token` to a tool call against the live MCP server.

Three load-bearing fixtures in `tests/integration/conftest.py`:

- **`live_server`** (session-scoped) — runs the FastAPI app via `uvicorn` programmatically on a free loopback port. The lifespan context manager runs migrations, `init_engines`, and the auth + plugin bootstrap on the same path the production server takes. Boot is detected via a poll loop on `server.started` with a fallback HTTP probe against `/health` for robustness across uvicorn versions. Daemon thread for clean teardown. Programmatic threading (not subprocess) keeps fixture overhead under 1s per session.
- **`integration_home`** (session-scoped) — a tmp directory pointed at by `HOME` / `FINLET_DIR` so the lifespan-bootstrapped auth + leaderboard DBs and `~/.finlet/credentials` writes do not collide with the user's real home. Module-level `FINLET_DIR` / `AUTH_DB_PATH` / etc. constants in `finlet.config`, `finlet.db.engine`, and `finlet.db.models` are rebound to the tmp dir for each test, with originals restored on teardown.
- **`_redirect_home_for_session`** (function-scoped autouse) — ensures every integration test starts with a fresh `HOME` and a re-evaluated finlet path bundle. Function scope (not session) is intentional — a session-scoped autouse here would mutate the path constants for the ENTIRE pytest session and bleed into every downstream `tests/mcp/`, `tests/plugins/`, `tests/services/` test that runs after `tests/integration/`.

**structlog `cache_logger_on_first_use` workaround:** `finlet.logging.configure_logging()` calls `structlog.configure(..., cache_logger_on_first_use=True, wrap_for_formatter)`, which permanently freezes per-logger caches. Once a Finlet module logger has been used during the live-server lifespan, `structlog.testing.capture_logs()` in any later test cannot inject its tap into that logger's chain (cached loggers don't re-bind on subsequent `configure(...)` calls). The pragmatic workaround is layered:

1. `live_server` monkey-patches `structlog.configure` for the duration of `create_app()` to force `cache_logger_on_first_use=False`. Loggers used during create_app's plugin init dynamically rebuild their processor chain on every call, so future `capture_logs()` taps work.
2. `_redirect_home_for_session` calls `structlog.reset_defaults()` plus an explicit rebind of `finlet.mcp.bearer_context.logger = structlog.get_logger("finlet.mcp.bearer_context")` — the bearer_context module-level proxy was previously bound to the polluted JSON renderer chain and ignored `capture_logs()` even after `reset_defaults`.
3. `pytest_collection_modifyitems` forces `tests/integration/` items to collect LAST so any residual pollution can no longer bleed forward into capture_logs()-using tests in `tests/mcp/test_oauth_dual_accept.py` etc.

This is structural debt rather than a bug — the proper fix is removing `cache_logger_on_first_use=True` from `finlet/logging.py` after Phase 4e closes. See `docs/decisions/integration-test-structlog-workaround.md` and the inline rationale in `tests/integration/conftest.py`.

### Conventions
- **Python 3.12+**, async throughout, type hints everywhere
- **structlog** for logging — JSON output in production, console in dev, configured via `FINLET_LOG_FORMAT` and `FINLET_LOG_LEVEL` env vars
- All datetimes in **UTC** internally
- One file per module, no god files

---

## CI/CD

Two-workflow split (Action 3 of CI/deploy stability reform — refactored 2026-05-06; see `docs/decisions/ci-deploy-pr-gating.md`):

- **PRs to main → `.github/workflows/ci.yml`** runs a `lint` job (Python 3.12: ruff + mypy, once) followed by a `test` matrix (Python 3.12 + 3.13: pytest ≥60% coverage only). No e2e, no security, no deploy. v1.0.0 ops speedup (2026-05-11, commit `584ae7d`) extracted ruff+mypy out of the matrix so they run once instead of twice, enabled `setup-python` `cache: 'pip'` keyed on `pyproject.toml`, and dropped `fetch-depth: 0` (the full-history checkout was unused).
- **Pushes to main → `.github/workflows/deploy.yml`** runs `test` (matrix 3.12/3.13) + `security` (Gitleaks → Bandit → Semgrep JS → pip-audit-allowlist) → deploy via SSM. Push-only; never triggered by PR. Typical run time ~6-8 min.

`main` is branch-protected. Required status checks are `test (3.12)` and `test (3.13)` from `ci.yml`. Direct push to main is rejected — every commit on main has cleared the test matrix at PR time. Solo-dev policy: 0 required reviewers, no force-push, no deletion, allow auto-merge enabled. The exec-plan skill (`.claude/skills/exec-plan/skill.md`) pushes merges via `gh pr create → gh pr checks --watch → gh pr merge --rebase --delete-branch`.

**Why e2e was dropped from CI gating** (PR #14, commit `17821b0`): the bug-hunt loop kept finding 3+ new dashboard regressions per iteration while the CI e2e job was passing cleanly — the gate was paying ~12 min per run for near-zero marginal signal. Pre-push e2e smoke (`scripts/e2e-smoke.sh`, 6 journeys) is the local gate; the bug-hunt loop is the integration safety net post-deploy.

Job composition inside `deploy.yml`:

- **`security` job** runs on Python 3.12 only (single-version). Hosts gitleaks, bandit, semgrep, and pip-audit — none of which are interpreter-version-dependent. Splitting this out of the matrix halved security-check runtime and removed a class of false-positive flakiness from running the same scans twice. See `docs/decisions/security-job-extraction.md`.
- **`test` job** runs the matrix `python-version: ['3.12', '3.13']` for `pytest` only — the legitimate interpreter-compat surface. ruff and mypy run inside this matrix because they consume project source and the second pass takes seconds. (On the PR-gating `ci.yml`, the v1.0.0 ops speedup split lint+mypy into a single non-matrix `lint` job for ~50% wall-clock savings on PRs; the `deploy.yml` `test` job kept the duplicated lint pass for full-pipeline parity.)
- **`paths-ignore`** on `push` skips `deploy.yml` for `docs/**`, `*.md`, `.claude/**`, and `tests/e2e-ux-results/**` commits — eliminates doc-only deploy invocations that cannot affect runtime. (Action 2.)

Both `deploy.yml` and `ci.yml` use `uv sync --extra server --extra ingest --extra dev` for installs — pip + uv duplicate dependency installation was removed 2026-05-06 (the duplicate path silently desynchronized extras and caused journey-14/15 `ModuleNotFoundError: No module named 'structlog'` failures). The deploy job runs `uv run python -c "import structlog, sqlmodel, pandas, boto3"` as a fail-fast import probe before later steps.

Test artifacts (screenshots, traces) are uploaded via `actions/upload-artifact@v4`.

CVE allowlist lives at `.security/allowed-cves.yml` and is consumed by `scripts/pip-audit-allowlist.sh`. Each entry MUST include an `expires` date — when expiry passes, the CVE re-enters scope and CI fails until renewed. Replaces inline `--ignore-vuln` flags that were inert scar tissue. See `docs/decisions/cve-allowlist-with-expiry.md`.

Bandit skips test directories and ignores rules B101, B104, B105, B112, B311 (configured in `pyproject.toml`).

### PyPI Publishing (`pypi-publish.yml`)

Separate workflow at `.github/workflows/pypi-publish.yml`. Triggers on GitHub release tags (`v*`). Uses trusted publishing (OIDC) for PyPI authentication — no API tokens stored in secrets. Builds the thin client wheel via `hatch build`, validates the wheel contents (fails if any server module is present or file count exceeds 3), and publishes with `pypa/gh-action-pypi-publish`.

### AI Quantamental Monthly Rebalance (`quantamental-rebalance.yml`)

Separate workflow at `.github/workflows/quantamental-rebalance.yml` added 2026-05-19. Triggers on a monthly cron (`0 21 1 * *` — 21:00 UTC on the 1st of each month) plus `workflow_dispatch` with `dry_run` + `month` inputs for ops testing. The job installs Finlet core + `strategies/ai_quantamental`, configures AWS via the `AWS_DEPLOY_ROLE_ARN` OIDC role, runs `python -m ai_quantamental.live rebalance --month YYYY-MM`, then auto-commits the produced `strategies/ai_quantamental/runs/YYYY-MM.{md,json}` artefacts back to main as the `finlet-bot[ai-quantamental]` git identity. On failure, the job opens a GitHub issue labelled `ai-quantamental,automated` with a re-run pointer. Idempotency marker (`s3://finlet-bug-reports/quantamental/last-rebalance.json`) prevents a re-run inside the same month from double-trading. See `## Strategies` above for the full subproject overview.

### Deployment (SSM + deploy.sh)

Production deployment uses AWS Systems Manager (SSM) Send-Command to execute `deploy/deploy.sh` on the EC2 instance. The workflow step in `deploy.yml` handles the full lifecycle:

1. **SSM Send-Command**: Sends a shell command to the EC2 instance that bootstraps the environment and runs `deploy.sh`.
2. **Polling loop**: Polls `ssm get-command-invocation` every 15 seconds for up to 10 minutes (40 iterations). Replaces `aws ssm wait command-executed`, which has a ~2-minute default timeout — insufficient for deploys that include `pip install` and migrations.
3. **Log retrieval**: Always fetches SSM stdout/stderr before the workflow step exits, regardless of success or failure. This ensures deploy errors are visible in CI logs.
4. **Health check**: After SSM reports success, the workflow hits `https://finlet.dev/health` up to 6 times (10s apart) to confirm the service is live.

**SSM execution model**: SSM runs commands as `root`, but `/opt/finlet` is owned by user `finlet`. This creates several bootstrapping requirements that are handled both in the SSM command (in `deploy.yml`) and in `deploy.sh`:

| Requirement | Why | Where Fixed |
|---|---|---|
| `export HOME=${HOME:-/root}` | SSM root shell does not always set `$HOME`, breaking git config and SSH paths | `deploy.sh` + `deploy.yml` SSM command |
| `git config --global --add safe.directory /opt/finlet` | Git rejects operations in repos owned by a different user (root vs finlet) | `deploy.sh` + `deploy.yml` SSM command |
| `ssh-keyscan github.com` | Root's `~/.ssh/known_hosts` may not trust GitHub's host key | `deploy.sh` (SSH fallback) |
| `git remote set-url origin https://x-access-token:${GITHUB_TOKEN}@github.com/...` | Root has no SSH deploy key; HTTPS with `GITHUB_TOKEN` is used for git pull auth | `deploy.yml` SSM command only |

**Git auth**: The deploy uses HTTPS with `secrets.GITHUB_TOKEN` (short-lived, auto-provisioned by GitHub Actions) instead of SSH deploy keys. The token is injected into the remote URL by the SSM command before `deploy.sh` runs. See `docs/decisions/deploy-https-git-auth.md` for the decision record.

**Server install model**: `deploy.sh` and `rollback.sh` use `pip install -e ".[server]"` (editable install with server extras). This bypasses the hatch wheel target (which scopes the wheel to thin client files only) and gives the server access to the full source tree. See `docs/decisions/remove-hatch-wheel-whitelist.md` for the decision record.

**Rollback**: `deploy.sh` tags the current commit before pulling (`pre-deploy-{timestamp}-{commit}`), keeps the last 10 tags, and runs a health check after restart. If the health check fails, it invokes `deploy/rollback.sh` for automatic rollback.

## Skill Eval (Post-Execution Quality Gate)

Each development skill (brainstorm, debate, plan-features, exec-plan) can have an optional `eval.md` alongside its `skill.md` in `.claude/skills/[name]/`. Eval files contain binary pass/fail assertions that are checkable against execution artifacts (files, git log, task outputs). The `/exec-plan` skill runs a post-execution eval phase (Step 4.5, after doc updates, before TeamDelete) that spawns a lean eval agent to check assertions and append results to `docs/skill-eval-results.md`. Eval failures are observational — they are recorded but do not block execution completion. See `.claude/skills/exec-plan/skill.md` Step 4.5 for the full protocol.
