# Codex Adversarial Review — Consolidated

**Date:** 2026-04-14
**Scope:** 20 untracked artifacts across `docs/codex-audit/` and `scripts/ingest_repair_missing.py`
**Method:** 5 parallel Codex adversarial review runs, each scoped to a themed slice (auth/CSRF, data pipeline, API contracts, E2E/UX, audit meta)
**Overall verdict:** All 5 slices returned `needs-attention` (no-ship). 23 distinct findings at time of review; 24 after 2026-04-14 recon (P0 #1 demoted + #25 added).

Every review independently surfaced the same meta-pattern: **process-global mutable state + audit-hypothesis-as-patch + "fixes" that normalize broken behavior.**

> **2026-04-14 update:** P0 #1 demoted to P2 #24 after direct code verification. `require_user` (`finlet/auth/deps.py:119-144`) already enforces "Bearer present → Bearer only, no cookie fallback," which blocks the attack as described. Attack surface is not live. Recon also surfaced a separate low-severity finding at `DELETE /auth/session` (new P2 #25). Neither is a launch blocker. See updated sequencing below.

---

## P0 — Launch Blockers (ship → silent wrong / security hole)

| # | Severity | Location | One-liner |
|---|----------|----------|-----------|
| ~~1~~ | ~~high~~ | ~~`docs/codex-audit/03-auth-csrf.md:275-295`~~ | **DEMOTED 2026-04-14** — see P2 #24. `require_user` (`finlet/auth/deps.py:119-144`) already blocks the described attack: Bearer-header-present → Bearer only, no cookie fallback, 401 on invalid. Architectural fragility remains but no live bypass. |
| ~~2~~ | ~~critical~~ | ~~`docs/brainstorms/DATA_PIPELINE_REQUIREMENTS.md:51-56`~~ | ~~"Object exists" ≠ "partition complete." Consumers can't distinguish no-data from incomplete-ingest → silent eval corruption.~~ **2026-04-14 update:** Addressed by partition completeness invariant. Code landed on main (Teams A–H of the execution plan). Rollout: `FINLET_PARTITION_VALIDATION` defaults to OFF; flips to WARN/STRICT after backfill completes. See [`docs/decisions/partition-completeness-invariant.md`](../decisions/partition-completeness-invariant.md) and [`docs/brainstorms/DATA_PIPELINE_COMPLETENESS_EXECUTION_PLAN.md`](../brainstorms/DATA_PIPELINE_COMPLETENESS_EXECUTION_PLAN.md). NOT fully resolved — code shipped, rollout pending. |
| 3 | critical | `scripts/ingest_repair_missing.py:201-242` | `merge_into_s3()` rewrites full day partition with no ETag/lock/staging. Concurrent write = silent data loss. |
| 4 | high | `docs/codex-audit/06-missing-features.md:126-139` | `skip_price_fetch` persists equity snapshot with stale prices → benchmark/portfolio drift in stored state. |
| 5 | high | `docs/brainstorms/BENCHMARK_REPORTING_REQUIREMENTS.md:42-105` | Agent-visible scenario detail destroys blind-eval — the product's defining invariant. |

## P1 — Hard Scope Before Launch

| # | Severity | Location | One-liner |
|---|----------|----------|-----------|
| 6 | high | `docs/brainstorms/USER_FEEDBACK_FIXES_EXECUTION_PLAN.md:52-58` | `create_session()` resets global breakers → cross-session corruption, violates stated constraint. |
| 7 | high | `docs/codex-audit/01-broken-endpoints.md:83-94` | Circuit breaker is process-global; isolation treated as optional, not required. |
| 8 | high | `docs/brainstorms/AUTH_HARDENING_EXECUTION_PLAN.md:171-192` | 3-try MFA burn is per-session; attacker mints fresh sessions at will. |
| 9 | high | `scripts/ingest_repair_missing.py:104-119` | Gap detection uses one reference day — historical holes invisible. |
| 10 | high | `scripts/ingest_repair_missing.py:305-326` | Transient fetch failures checkpointed as completed; `--resume` turns outages into permanent holes. |
| 11 | high | `docs/brainstorms/USER_FEEDBACK_FIXES_EXECUTION_PLAN.md:171-188` | Hosted EDGAR identity is a process global — last tenant wins. Dangerous the moment user #2 arrives. |
| 12 | high | `docs/codex-audit/06-missing-features.md:236-265` | In-place session reset bypasses quotas, destroys audit trail, unseals completed traces. |

## P2 — Hardening Before Scale

| # | Severity | Location | One-liner |
|---|----------|----------|-----------|
| 13 | high | `docs/codex-audit/05-api-contracts.md:360-373` | `POST /sessions/{id}/complete` is unversioned polymorphic → client breakage on benchmark transitions. |
| 14 | high | `docs/codex-audit/02-circuit-breaker.md:390-397` | Thresholds/reset tuned on a failure bucket that conflates S3 misses + transport faults. |
| 15 | high | `docs/codex-audit/01-broken-endpoints.md:34-35` | Fix for news 404 allows docs-only cleanup → existing clients stay broken with no migration path. |
| 16 | medium | `docs/brainstorms/AUTH_HARDENING_REQUIREMENTS.md:15-69` | `sessionStorage` CSRF + session rotation = intermittent 403s in multi-tab/webview. |
| 17 | high | `scripts/ingest_repair_missing.py:49-58` | Repair depends on `curl_cffi` rate-limit bypass; conflicts with pipeline policy, brittle under provider hardening. |
| 18 | high | `docs/brainstorms/BENCHMARK_REPORTING_REQUIREMENTS.md:44-92` | Scorecard is vanity stats + uncalibrated reasoning score; no cost-adjustment or minimum-activity floor. |
| 19 | high | `docs/brainstorms/E2E_FIX_EXECUTION_PLAN.md:117-170` | Journey 8 asserts hidden-tier DOM as canonical → greens on known defect, will re-break when cleanup lands. |
| 24 | medium | `finlet/api/security_middleware.py:124-126` + `finlet/auth/deps.py:119-144` | **Demoted from P0 #1.** CSRF middleware trusts unvalidated `Authorization: Bearer` header to skip CSRF; safety depends on `require_user`'s implicit invariant (no cookie fallback when Bearer present). Not live — but implicit coupling. Fix: move CSRF enforcement post-auth into `require_user` so the decision uses the resolved auth method, not a header guess. |
| 25 | medium | `finlet/api/routes_auth_sessions.py:120-143` + `finlet/api/security_middleware.py` exempt list | **Discovered during P0 #1 recon.** `DELETE /auth/session` is CSRF-exempt by path AND has no auth dependency — reads cookie directly and revokes. Logout-CSRF: attacker site can silently log out any visitor with an active session. Low impact (no data/privilege exposure), industry-standard info/low severity. Fix: add `require_user` dep + restore CSRF (remove from exempt list). |

## P3 — Process Fixes (the root causes)

| # | Severity | Location | One-liner |
|---|----------|----------|-----------|
| 20 | high | `docs/brainstorms/CODEX_AUDIT_EXECUTION_PLAN.md:303-339` | Audit hypothesis → shipped security patch with no disconfirmation step. **This produced P0 #1.** Fix this first or the pile regenerates. |
| 21 | medium | `docs/brainstorms/CODEX_AUDIT_FIXES_EXECUTION_PLAN.md:94-142` | Post-audit work ordered by patch size, not blast radius — highest-risk item stays live longest. |
| 22 | medium | `docs/brainstorms/POST_AUDIT_FIX_PLAN.md:108-161` | Team K's ownership scope excludes `routes_market.py`, so the rate-limit bug can merge "fixed" and stay broken. |

## P4 — Small / Messaging

| # | Severity | Location | One-liner |
|---|----------|----------|-----------|
| 23 | medium | `docs/brainstorms/website_correctness_REQUIREMENTS.md:15-27` | Removes EDGAR/FRED from docs while the feedback plan adds hosted EDGAR config — product-doc mismatch. |

---

## Three Cross-Cutting Patterns

1. **Process-global mutable state is the dominant architectural defect** — circuit breakers (R3, R4), EDGAR identity (R4), agent-visible benchmark state (R5). Any remediation that doesn't add scope/tenant isolation keys will surface the same bug wearing new clothes.
2. **"Audit says X is broken → patch X" is running without a counterexample gate.** R5-3 names this explicitly. Bearer CSRF bypass (~~P0 #1~~ — itself an exhibit of this defect; the review flagged a live critical without checking `deps.py`'s mitigation), `skip_price_fetch` (P0 #4), in-place session reset (P1 #12) all share the pattern.
3. **Several proposed fixes normalize broken behavior** — Journey 8 E2E rewrite, `skip_price_fetch` persistence, same-ID session reset, partition overwrite. Per the project shipping rule, cut these — don't normalize them.

## Recommended Sequencing

1. ~~**Kill P0 #1 today** (Bearer skip is live).~~ — **DEMOTED 2026-04-14.** Verified in code: `finlet/auth/deps.py:119-144` already enforces "Bearer present → Bearer only, no cookie fallback." Attack as described is blocked. Tracked as P2 #24 (architectural coupling) and P2 #25 (logout CSRF, surfaced during recon).
2. **Fix P3 #20 before doing any P0 remediation work** — otherwise the same class of bug will re-ship while fixing this class. **P0 #1 itself is exhibit A of the disconfirmation gap** — review flagged as live critical without checking `deps.py`'s mitigation.
3. **Then work P0 → P1 → P2 in order.** P4 can wait.
4. **Re-order `CODEX_AUDIT_FIXES_EXECUTION_PLAN.md` by blast radius before executing any of it** (P3 #21) — currently scheduled such that the most dangerous item lands last.

---

## Per-Slice Verdicts (verbatim summaries)

### R1 — Auth / CSRF
> No-ship: the proposed auth hardening still contains an unsafe CSRF bypass pattern, treats MFA retry control as session-scoped theater, and ignores CSRF/session rotation failures in multi-tab clients.

### R2 — Data Pipeline & Availability
> No-ship: the pipeline still has no completeness invariant, and the repair path can miss gaps, treat failed fetches as repaired, and overwrite full daily partitions without atomicity.

### R3 — API Contracts / Circuit Breaker / Endpoints
> No-ship. The proposed endpoint and circuit-breaker fixes still rely on guessed breaker policy, leave shared-breaker blast radius largely intact, and do not define a backward-compatible API contract path for existing callers.

### R4 — E2E / UX / Website Correctness / Missing Features
> No-ship. These docs optimize for green tests and quieter complaints, but they currently encode cross-session state mutation, tenant-unsafe EDGAR behavior, and multiple 'correctness' changes that would normalize misleading or incorrect user-facing behavior.

### R5 — Audit Meta / Benchmarks / Post-Audit
> No-ship: the benchmark spec leaks benchmark internals and optimizes presentation metrics over trading validity, while the audit plans still turn unverified audit claims into partial or mis-scoped fix work. That is a remediation treadmill, not a reliable governance loop.
