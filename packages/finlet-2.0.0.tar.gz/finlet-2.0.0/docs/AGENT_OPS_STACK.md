# Agent Ops Stack — Handoff & Runbook

**Last updated:** 2026-04-20
**Purpose:** Self-hosted agent orchestration that delegates company operations (marketing, support, research, etc.) to AI agents while the founder stays CEO.
**Status:** Infrastructure LIVE. Phase 1 workflows (`ops-hello`, `bug-hunt`, `bug-fix`, `bug-verify`) imported inactive. Phase 3 ephemeral-CTO layer coming online: `cto-supervisor` workflow (Task #3) active and HMAC-protected; 4 skill-graph sub-workflows (`skill-brainstorm`, `skill-debate`, `skill-plan-features`, `skill-exec-plan` — Task #4) active and chain-smoke-tested end-to-end 2026-04-20 (brainstorm → debate → plan-features lineage verified via `cto_artifacts.stage_input_ref`). Task #5 (specialists + mergers) is next.

---

## TL;DR

A $14/mo Hetzner CPX21 in Ashburn runs n8n + Postgres + Caddy in Docker. Claude Code is installed on the host with the user's Max OAuth — a Python `claude-runner` systemd service exposes `claude -p` over HTTP:9099. n8n calls that endpoint via `host.docker.internal:9099`, so every agent invocation bills against the existing Max subscription (not the API). Discord webhooks are the human-visibility layer; Postgres (`ops.*` schema) is the inter-agent bus.

**Result:** agents orchestrate from n8n, execute with Claude Code, persist state in Postgres, surface to Discord. Zero marginal LLM billing.

---

## Current State

### Host

| Property | Value |
|---|---|
| Provider | Hetzner Cloud |
| Instance | CPX21 (3 vCPU, 4GB RAM, 80GB NVMe) |
| Location | Ashburn, VA (US-East) |
| Public IP | `87.99.156.168` |
| OS | Ubuntu 24.04 |
| Hardening | UFW (22/80/443 + `172.16.0.0/12 → :9099`), fail2ban, unattended-upgrades, 4GB swap |

### Docker services (on `finlet-ops` network)

| Container | Image | Purpose | Status |
|---|---|---|---|
| `ops-postgres` | `postgres:16-alpine` | n8n backend + `ops.*` tables | healthy |
| `ops-n8n` | `n8nio/n8n:latest` (2.16.1) | workflow engine | running |
| `ops-caddy` | `caddy:2-alpine` | reverse proxy, LE cert | running |

### Host services (systemd)

| Unit | Purpose |
|---|---|
| `claude-runner.service` | HTTP shim at `0.0.0.0:9099`, subprocess-runs `claude -p`. Accepts `skip_permissions: true` in the POST body to pass `--dangerously-skip-permissions` (required by `bug-fix-runner` so the worker can write files in its worktree). |
| `bug-hunt-runner.service` | Playwright probe + Postgres write on `0.0.0.0:9100` (endpoints: `/probe`, `/record`) |
| `bug-fix-runner.service` | Orchestrates the fix-a-bug loop **and** post-merge verify on `0.0.0.0:9101`. Endpoints: `/health`, `/fix`, `/verify-candidates`, `/finalize-verify`. Fix path: fetches bug from `ops.bugs`, opens a git worktree under `/opt/finlet-ops/worktrees/`, invokes claude-runner with a constrained fix prompt + `skip_permissions: true`, validates commits + scope cap (≤10 files) + tests (ruff/pytest; skipped gracefully when no Python touched or tooling missing), `git push` via SSH deploy key, `gh pr create` via PAT, updates `ops.bugs` (`status=in_review`, `pr_url`) + `ops.approval_queue` (`status=approved`), writes `ops.agent_runs`. Verify path (workflow #4): `/verify-candidates` shells `gh pr view` for every `in_review` bug and returns only those whose PR is `MERGED` within `(BUG_VERIFY_MIN_AGE_S, BUG_VERIFY_MAX_AGE_S)` (defaults 10min–7day). `/finalize-verify` is idempotent: if resolved, flips bug to `resolved`, removes worktree (`git worktree remove --force`), deletes local branch (`git branch -D`), deletes remote ref (`gh api DELETE` — 404 tolerated), logs `ops.agent_runs`. If not resolved, flips to `triaged` + triage_notes. Called with non-`in_review` bug → returns 200 `{status:"skipped"}`, no side-effects. |
| `docker.service` | Container runtime |
| `fail2ban.service` | SSH brute-force protection |

### Postgres schema (`ops` database, `ops` schema)

- `ops.bugs` — bug-hunt findings (severity, status, screenshot path, triage notes, PR url, metadata JSONB)
- `ops.agent_runs` — audit trail: every agent invocation with cost/model/input/output
- `ops.approval_queue` — human-in-loop gates (status, payload, response_source)
- `ops.cto_state` — in-flight orchestration state for the ephemeral CTO layer: one row per active task (task_id UUID PK, parent_task_id for tree, team_name, stage, status, context JSONB, correction_round 0-4, heartbeat/deadline/completed timestamps). `updated_at` auto-maintained by `ops.cto_state_touch_updated_at` trigger. Indexes cover status+updated_at, team_name+status, parent_task_id, and a partial index on last_heartbeat_at for stuck-task detection. Applied via `deploy/ops/migrations/001_cto_state.sql` on 2026-04-18.
- `ops.cto_decisions` — append-only decision/message log backing conversation replay across ephemeral CTO spawns (id BIGSERIAL PK, decided_at, task_id FK → cto_state ON DELETE SET NULL, event_type, event_summary, action, rationale, inputs/outputs JSONB). `tsv` is a GENERATED STORED tsvector weighting summary (A) / rationale (B) / action (C), with a GIN index for full-text search. Applied via `deploy/ops/migrations/002_cto_decisions.sql` on 2026-04-18.
- `ops.cto_handoff` — single-row "living handoff" table holding the current 7-day narrative markdown the ephemeral CTO reads on every spawn (id BOOLEAN PK fixed TRUE + CHECK singleton invariant, narrative TEXT, updated_at TIMESTAMPTZ, updated_by TEXT, version INTEGER ≥1). `cto_handoff_updated_at` trigger auto-sets `updated_at` and auto-bumps `version` on UPDATE unless the caller sets version explicitly (allows optimistic-concurrency `WHERE version = :expected` patterns). Canonical-for-humans copy lives at `docs/ops/CTO_HANDOFF.md`; this row is the runtime source. Applied via `deploy/ops/migrations/003_cto_handoff.sql` on 2026-04-20; seeded from the markdown file (`updated_by='manual_seed'`, version=1).
- `ops.cto_approvals` — async approval queue backing the CTO supervisor's escalate-to-user branch (Decision #3, 2026-04-20). Durable pending/approved/rejected/timed_out/auto_acted lifecycle; one row per severity ∈ {high, critical} escalation or workflow-fixer proposal. Columns: id BIGSERIAL PK, requested_at, task_id (FK → cto_state ON DELETE SET NULL), decision_id (FK → cto_decisions ON DELETE SET NULL), severity (CHECK), prompt_text, proposed_action JSONB, status, resolved_at, resolved_by, resolution_notes, discord_message_id. Partial index on pending rows for workflow-fixer's poll scan, plus status+time / FK-supporting / discord_message_id indexes. Applied via `deploy/ops/migrations/004_cto_approvals.sql` on 2026-04-20.
- `ops.cto_artifacts` — durable output-doc storage for the CTO skill-graph sub-workflows (`intake`, `brainstorm`, `debate`, `plan-features`, `exec-plan`). One row per sub-workflow invocation carrying the markdown body the next stage will read — replaces filesystem-backed brainstorm artifacts for automated CTO runs. Columns: id BIGSERIAL PK, ref UUID UNIQUE (external cross-workflow handle), task_id (FK → cto_state ON DELETE SET NULL), decision_id (FK → cto_decisions ON DELETE SET NULL), workflow_name (CHECK-enforced enum), stage_input_ref UUID (lineage pointer to prior stage, NULL for first stage), content TEXT, content_sha256 TEXT GENERATED ALWAYS AS (encode(sha256(content::bytea),'hex')) STORED (tamper-evident reasoning trace), metadata JSONB, created_at. Indexes: UNIQUE(ref), task_id, (workflow_name, created_at DESC), partial(stage_input_ref WHERE NOT NULL). Applied via `deploy/ops/migrations/005_cto_artifacts.sql` on 2026-04-20; enum pre-includes `intake` so Task #6 needs no schema change.

### n8n workflows

| ID | Name | Active | Notes |
|---|---|---|---|
| `T3XNqlThQ9O59WnL` | `ops-hello (pipeline verification)` | **false** | Manual trigger → claude-runner → Discord. Verified working. |
| `HOJRlxgzJH776bit` | `bug-hunt` | **false** | Cron (12h) → `bug-hunt-runner` `/probe` → claude-runner analyze → JS parse → IF → `/record` + Discord. Keep inactive; user activates manually. |
| `SyXpRL0XcSe3yYTW` | `bug-fix` | **false** | Manual trigger (with `bug_id` inputData) → Set Inputs → HTTP POST `host.docker.internal:9101/fix` → Code (Summarize) → Discord. Dry-run (executions 4+5) against bug `f4232774...` successful; keep inactive until the user is ready to wire approvals → workflow trigger. |
| `7EXsSTAITme7vuuX` | `bug-verify` | **false** | Schedule (6h) → HTTP POST `/verify-candidates` → IF `.candidates.length > 0` → SplitInBatches → HTTP POST `/probe` → HTTP POST claude-runner `/run` (sonnet, forces JSON `{resolved, reason}`) → Code parse → HTTP POST `/finalize-verify` → Code accumulator (workflow static data) → Code summarize → Discord. 0-candidates branch short-circuits to a "0 candidates" Discord post. Smoke-tested against 2-row scenario (OPEN canary + CLOSED synthetic → 0 candidates, exec 14); `/finalize-verify` direct-call smoke-tested with idempotency check. |
| `bdXgn8qqq1X4d8qb` | `cto-supervisor` | **true** | Webhook POST `/webhook/cto-supervisor` (HMAC-signed, `X-CTO-Signature: t=,v1=`) → Validate event (inline SHA-256/HMAC, 300s replay window) → parallel reads from `cto_state` / `cto_decisions` / `cto_handoff` → Pack LLM context (NO BULLSHIT prompt + opus default) → Claude decide via `host.docker.internal:9099/run` → Parse decision → Router switch → {log_only, post_to_discord, spawn_sub_workflow STUB, escalate_to_user STUB} → insert `cto_decisions` row → Respond JSON. Task #4/#5 extension points stubbed. Design: `docs/ops/cto-supervisor-DESIGN.md`. |
| `VBqjoTu8UOoFzvfL` | `skill-brainstorm` | **true** | Webhook POST `/webhook/skill-brainstorm` → HMAC validate → optional Fetch input artifact by ref → Resolve input doc → Build prompt (brainstorm system prompt, 5 required sections: Problem/User Goals/Scope Boundaries/Feasibility Notes/Open Questions) → Claude decide (opus via claude-runner) → Parse output (validates sections) → Write artifact (INSERT `cto_artifacts` + upsert `cto_state`) → Write decision (`event_type='brainstorm'`, `action='sub_workflow_result'`) → Respond. Smoke-tested 2026-04-20 (ref `5586b76b...`, 3499 chars). Design: `docs/ops/skill-graph-DESIGN.md`. |
| `0Ea0dcPz5zsfE7EZ` | `skill-debate` | **true** | Same graph shape as `skill-brainstorm`. System prompt: Critic Attacks / Defender Responses / Moderator Verdict / Citable Evidence. Smoke-tested 2026-04-20 reading brainstorm ref (ref `949265ba...`, 9552 chars, lineage chain verified). |
| `3LerWWJ3VyAEXNuU` | `skill-plan-features` | **true** | Same graph shape. System prompt: Goal / File Conflict Analysis / Dependency Graph / Task Breakdown / Merge Gates / Rollback Plan. Smoke-tested 2026-04-20 reading debate ref (ref `dbd4f6ce...`, 7264 chars). |
| `VQ3HnKrP9vcDuhGA` | `skill-exec-plan` | **true** | v1 STUB — single-LLM-call report enumerating "Tasks Dispatched" without actually spawning specialists (specialist workflows land in Task #5). Same graph shape. System prompt: Tasks Dispatched / Results / Merges Applied / Failures + Rollbacks. Built + activated + validated 2026-04-20; not smoke-tested live per Task #5 dependency. |

### Cloudflare

- Zone `finlet.dev` (ID `091b606ef8b0695eda89cda80711a2d1`)
- DNS `ops.finlet.dev` → `87.99.156.168`, **proxied (orange cloud)**
- LE cert acquired via HTTP-01 (works through CF proxy)
- Access policy: **NOT YET SET** (n8n auth is the only gate; add email-allowlist Access later)

---

## Access & Secrets

### Laptop (`/Users/justnau`)

| Path | Contents |
|---|---|
| `~/.finlet-ops/secrets.env` (600) | All secrets. **Source with `set -a; source ...; set +a`** |
| `~/.finlet-ops/deploy/` | `docker-compose.yml`, `Caddyfile`, `init-db.sql`, `claude-runner.py`, `claude-runner.service`, `workflow-ops-hello.json`, `workflow-bug-hunt.json`, `workflow-bug-fix.json`, `workflow-bug-verify.json`, `build-workflow-bug-verify.py`, `bug-hunt-runner/`, `bug-fix-runner/` |
| `~/.finlet-ops/cloud-init.yml` | Snapshot of what built the VPS |
| `~/.ssh/finlet_ops_ed25519` (600) | VPS SSH private key (Ed25519, no passphrase) |
| `~/.ssh/finlet_ops_known_hosts` | SSH known_hosts for the VPS (separate from main) |

### VPS (`ops@87.99.156.168`)

| Path | Contents |
|---|---|
| `/opt/finlet-ops/compose/docker-compose.yml` | Stack definition |
| `/opt/finlet-ops/compose/Caddyfile` | Reverse proxy config |
| `/opt/finlet-ops/compose/init-db.sql` | Postgres schema (runs on first DB init) |
| `/opt/finlet-ops/compose/.env` (600) | Passwords + webhook URLs consumed by compose |
| `/opt/finlet-ops/data/{postgres,n8n,caddy}` | Persistent volumes |
| `/opt/finlet-ops/claude-runner/server.py` | Python HTTP shim source |
| `/etc/systemd/system/claude-runner.service` | systemd unit |
| `/home/ops/.claude/.credentials.json` (600) | Claude Code OAuth (access ~8h, refresh ~months, auto-refreshed) |

### Secret keys (fields in `~/.finlet-ops/secrets.env`)

| Key | Type | Auth header |
|---|---|---|
| `HCLOUD_TOKEN` | Hetzner Cloud API token (R&W) | `Authorization: Bearer` (or `hcloud --context` via env) |
| `CF_API_KEY` + `CF_AUTH_EMAIL` + `CF_ZONE_ID` | Cloudflare **Global API Key** (prefix `cfk_` is normal) | `X-Auth-Key` + `X-Auth-Email` (**NOT Bearer**) |
| `ANCHOR_API_KEY` | Anchor Browser (free tier, `sk-*`) | `anchor-api-key: ...` |
| `DISCORD_WEBHOOK_BUGHUNT` | Discord channel webhook URL | none (push-only) |
| `N8N_API_KEY` | n8n public API JWT (long-lived) | `X-N8N-API-KEY: ...` |
| `POSTGRES_PASSWORD` | Postgres password (32-char random) | — |
| `N8N_ENCRYPTION_KEY` | n8n encryption at rest (32-byte hex) | — |

### External service tokens (not yet added)

Composio, Stripe, Gmail, LinkedIn, GitHub PAT — not in stack yet. When added, prefer **n8n Credentials** (encrypted in Postgres) over `.env` vars.

---

## Architecture

### Data flow

```
┌─────────────────────────────────────────────────────────────────┐
│ User's browser / Discord / cron                                 │
└──────┬──────────────────────────────────────────────────────────┘
       │ HTTPS
┌──────▼──────────────────────────────────────────────────────────┐
│ Cloudflare (proxied DNS, LE cert validation, Access TBD)        │
└──────┬──────────────────────────────────────────────────────────┘
       │
┌──────▼──────────────────────────────────────────────────────────┐
│ Caddy (HTTP/3, LE cert, reverse proxy, access log)              │
└──────┬──────────────────────────────────────────────────────────┘
       │ HTTP :5678
┌──────▼──────────────────────────────────────────────────────────┐
│ n8n (workflow engine, in Docker)                                │
│    ├─► Postgres (schema `public` = n8n; schema `ops` = agents) │
│    ├─► HTTP `host.docker.internal:9099` → claude-runner        │
│    ├─► HTTP Anchor Browser / Discord / future integrations     │
│    └─► ops.approval_queue + ops.bugs + ops.agent_runs           │
└──────┬──────────────────────────────────────────────────────────┘
       │ over Docker bridge (UFW rule allows 172.16.0.0/12 → :9099)
┌──────▼──────────────────────────────────────────────────────────┐
│ claude-runner (Python stdlib HTTP server, systemd, :9099)       │
│    └─► subprocess: `claude -p "<prompt>" --model <m>`          │
└──────┬──────────────────────────────────────────────────────────┘
       │ OAuth (auto-refresh)
┌──────▼──────────────────────────────────────────────────────────┐
│ Anthropic (via Max subscription, $0 marginal)                   │
└─────────────────────────────────────────────────────────────────┘
```

### Subagent communication tiers

Agents do **not** talk to each other through chat. The communication model:

1. **In-session** (Claude Code's `Agent` tool) — default for within-task delegation.
2. **Team coordination** (`TeamCreate` + `SendMessage`) — reserved for debate/critique loops only (per memory: `feedback_watchdog_agents.md`).
3. **Cross-session** — state lives in `ops.*` Postgres tables; n8n routes work between agents. **This is the default company-wide bus.**
4. **Human-in-loop** — Discord + n8n wait nodes + `ops.approval_queue`. Mandatory for outbound emails, production deploys, money-moving, PR merges.
5. **Real-time pub/sub** — Redis streams or Postgres LISTEN. **Not built yet.** Add only when fan-out patterns become real.

### Why this stack

- **Hetzner over AWS**: 3-5× cheaper for dedicated vCPUs; unmetered egress; blast-radius isolation from Finlet's AWS product infra.
- **n8n over Zapier/Make**: self-hosted (free), AI-node-native, 1000+ integrations, importable workflows via API.
- **Caddy over nginx/Traefik**: one-line auto-TLS via HTTP-01 through Cloudflare.
- **Discord over Slack**: free forever, per-agent bot identities via webhooks, no OAuth dance.
- **claude-runner on host, not container**: Claude Code auth lives in `/home/ops/.claude/`; mounting into a container complicates permissions. systemd is simpler.
- **Max subscription via OAuth, not API billing**: `claude -p` on the VPS consumes Max quota, not API tokens. Gray-area vs Anthropic ToS; user accepted.

---

## Cheat Sheet

### SSH
```bash
ssh -i ~/.ssh/finlet_ops_ed25519 ops@87.99.156.168
```

### Source secrets
```bash
set -a; source ~/.finlet-ops/secrets.env; set +a
```

### Stack management (run on VPS)
```bash
cd /opt/finlet-ops/compose
docker compose ps
docker compose logs -f n8n
docker compose logs -f caddy
docker compose up -d           # apply changes
docker compose restart n8n
```

### claude-runner
```bash
sudo systemctl status claude-runner
sudo systemctl restart claude-runner
sudo journalctl -u claude-runner -f
curl http://127.0.0.1:9099/health
```

### Test pipeline end-to-end (from n8n container)
```bash
docker exec ops-n8n sh -c \
  'wget -qO- --post-data='\''{"prompt":"say hi","timeout":60}'\'' \
   --header='\''Content-Type: application/json'\'' \
   http://host.docker.internal:9099/run'
```

### n8n API (from laptop)
```bash
set -a; source ~/.finlet-ops/secrets.env; set +a
curl -s -H "X-N8N-API-KEY: $N8N_API_KEY" https://ops.finlet.dev/api/v1/workflows | jq
curl -s -H "X-N8N-API-KEY: $N8N_API_KEY" https://ops.finlet.dev/api/v1/executions?limit=10 | jq
```

### Postgres direct access (on VPS)
```bash
docker exec -it ops-postgres psql -U ops -d ops
# inside psql:
\dn                                 # list schemas
\dt ops.*                           # list ops tables
SELECT id, source, status, severity, title FROM ops.bugs ORDER BY found_at DESC LIMIT 20;
SELECT id, agent_name, status, cost_usd, started_at FROM ops.agent_runs ORDER BY started_at DESC LIMIT 20;
SELECT id, category, status, created_at FROM ops.approval_queue WHERE status='pending';
```

### Cloudflare (from laptop)
```bash
set -a; source ~/.finlet-ops/secrets.env; set +a
# List DNS records on zone
curl -s -H "X-Auth-Key: $CF_API_KEY" -H "X-Auth-Email: $CF_AUTH_EMAIL" \
  "https://api.cloudflare.com/client/v4/zones/$CF_ZONE_ID/dns_records" | jq '.result[] | {name, type, content, proxied}'
```

### Hetzner (from laptop)
```bash
set -a; source ~/.finlet-ops/secrets.env; set +a
hcloud server list
hcloud server describe finlet-ops
# resize upward (brief downtime, same IP):
hcloud server change-type finlet-ops cpx31 --keep-disk
```

---

## Decisions (reference)

| Decision | Chosen | Why |
|---|---|---|
| VPS | Hetzner CPX21 Ashburn $14 | cheapest viable with dedicated cores + unmetered egress |
| Instance size | CPX21 (3/4GB) | start cheap, resize via `change-type` when memory pressure hits |
| Memory buffer | 4GB swap | swap buffers Playwright/Claude Code spikes |
| DB | Postgres 16 (shared with n8n) | single DB for stack simplicity; `ops.*` schema isolates agent tables |
| Reverse proxy | Caddy | auto-TLS, HTTP-01 through CF proxy |
| Observability channel | Discord webhooks | free, per-agent identity, no OAuth |
| LLM gateway | claude-runner (host) | uses Max OAuth, zero API billing |
| Routing | **Opus 4.7 only** (`claude-opus-4-7`) for every Claude call — Max 20x plan paid for; Sonnet benched 2026-04-26 (#1545); Haiku killed entirely 2026-04-26 (#1562). | model pinned per CTO v2 system prompt §AI Mgmt #10 |
| OAuth middleware | Composio (planned) | $29/mo when Gmail/Stripe/etc added |
| Observability/cost | Langfuse (planned) | self-host after RAM upgrade |

See also: research agents' output is **discarded** — only the decisions above are the record.

---

## Gotchas (already resolved)

1. **UFW blocks Docker bridges.** Add `sudo ufw allow from 172.16.0.0/12 to any port <host-port>` whenever a container needs to reach a host-local service.
2. **n8n blocks `$env.*` by default.** Set `N8N_BLOCK_ENV_ACCESS_IN_NODE=false` in compose. Long-term: migrate to n8n Credentials (encrypted in Postgres).
3. **Cloud-init `runcmd` doesn't brace-expand.** `mkdir -p /x/{a,b,c}` creates a literal `{a,b,c}` dir. Use individual `mkdir` or wrap in `sh -c`.
4. **`/login` is a REPL slash command**, not a shell command. `claude` to enter REPL, then `/login`.
5. **Cloudflare `cfk_*` key IS a Global API Key** (despite prefix). Use `X-Auth-Key` + `X-Auth-Email`, not Bearer.
6. **Slack `xoxe.xoxp-*` is a config token**, not a bot/user token. Can only edit app manifests. Doesn't post. (We switched to Discord.)
7. **Claude Code auto-refreshes tokens** on every invocation. As long as `claude` runs at least every ~few months, refresh token never expires.
8. **Caddy HTTP-01 works through Cloudflare proxy.** Cloudflare forwards LE challenge to origin; origin responds; CF returns to LE. No DNS-01 needed.
9. **n8n POST /workflows returned 200 AND jq error simultaneously.** Workflow had literal newlines in a string field — valid to n8n, invalid JSON to jq. Use Python json.load instead. (Created a duplicate workflow on retry; deleted one.)
10. **Playwright `install-deps` must run BEFORE `install chromium` on fresh Ubuntu 24.04** (first chromium install aborts at dep check).
11. **n8n 2.16.1 public API has no `POST /workflows/{id}/execute`** (returns 405). Manual execute is UI-only unless `n8n execute --id ...` is run via an alternate container (the running instance owns port 5679). For smoke testing, invoke backing services directly to validate logic end-to-end. **But:** the internal `POST /rest/workflows/{id}/run` works after cookie auth via `POST /rest/login` (body `{emailOrLdapLoginId, password}`). Pass `triggerToStartFrom.data.main[[{json:{bug_id:...}}]]` to inject data into the Manual Trigger. Verified 2026-04-17 (executions 4 + 5 of `bug-fix`).
12. **GitHub deploy keys can push branches but cannot open PRs.** `gh pr create` hits the REST API as an authenticated user. Use a PAT (or reuse the laptop's `gh auth token`) alongside the deploy key: deploy key for `git push` via SSH, PAT in `GH_TOKEN` env for `gh pr create`. Both are now stored in `/opt/finlet-ops/bug-fix-runner/.env`.
13. **claude-runner needed `--dangerously-skip-permissions`** for the bug-fix worker. Default `claude -p` asks for write permission on each file creation — in a non-interactive subprocess, the worker prints the prompt and exits without committing. Patched claude-runner to accept `skip_permissions: true` in the POST body; only `bug-fix-runner` sets it. Scope is bounded by the worktree directory + the runner's systemd `ReadWritePaths`.
14. **systemd `ProtectHome=read-only` fights `ReadWritePaths=/home/ops/.config`** — the path must exist before the service starts, otherwise the mount namespace setup fails with `status=226/NAMESPACE`. Pre-create `/home/ops/.config` and `/home/ops/.cache`.
15. **n8n Code node doesn't see the request body on HTTP error.** When the POST returns 4xx/5xx, n8n's httpRequest node (with `neverError: true`) passes only the response body forward. To stitch the upstream bug_id into the summary, pull it from `$('Set Inputs').first().json.bug_id` rather than `$json.bug_id`.
16. **Internal `/rest/workflows/{id}/run` needs `triggerToStartFrom`.** Empty `{}` body returns 400 `"executeManually was called with an unexpected payload"`. Pass `{"workflowData":{"id":...},"triggerToStartFrom":{"name":"Schedule Trigger","data":{"main":[[{"json":{}}]]}},"runData":{}}`. The trigger name must exactly match a trigger node in the workflow.
17. **n8n execution detail JSON contains unescaped control characters.** `json.loads(..., strict=False)` is required on Python 3.14 when parsing `/api/v1/executions/{id}?includeData=true` — the schedule trigger's "Readable date" field in runData can include characters that trip strict parsing. Does not affect workflow correctness, only inspection.
18. **SplitInBatches aggregation uses workflow static data.** To compute a single Discord summary after per-item iteration, write each iteration's result to `$getWorkflowStaticData('global').verifyRuns`, then read+clear in the next node. `$('nodeName').all()` only returns the last batch, not accumulated history across iterations in n8n 2.16.1.
19. **bug-verify merged window matters.** Finlet deploy is ~6min (GitHub Actions + SSM→EC2). Default `BUG_VERIFY_MIN_AGE_S=600` waits 10min post-merge so the fix is actually live before probing. If a PR merges and the deploy fails/stalls longer than `BUG_VERIFY_MAX_AGE_S` (7 days), the bug ages out and the verify loop never re-checks — in that case, flip the bug to `new` manually or extend the cap.
20. **Remote ref deletion 404 is expected.** When a PR is merged with "delete branch" checked, the remote branch is already gone by the time `/finalize-verify` runs. The runner swallows 404s (and "reference does not exist" messages) silently. Other gh errors surface in `cleanup.errors`.

---

## What's Next (prioritized)

### Immediate (the reason this stack exists)

**1. [DONE 2026-04-17] Build the bug-hunt workflow.** Imported as workflow `HOJRlxgzJH776bit` (inactive). Smoke-tested end-to-end against live backing services: probe on VPS returned 5-page result, claude-runner returned 4-bug JSON array, `/record` inserted 4 rows into `ops.bugs` + 1 critical queued in `ops.approval_queue`, Discord webhook returned 204. Built with local Playwright probe on `:9100` (replaces planned Anchor Browser path).

**2. [DONE 2026-04-17] Approval → worker → PR loop (workflow #3 `bug-fix`).** Imported as `SyXpRL0XcSe3yYTW` (inactive). Dry-run against bug `f4232774-5c14-4e77-91c2-600b6565c858` (Login 404): writable SSH deploy key installed on `justnau1020/finlet` (id `148913930`), repo cloned at `/opt/finlet-ops/finlet-repo`, `bug-fix-runner.service` built on `:9101`, claude-runner patched to accept `skip_permissions`. Worker agent produced a real fix (single-file `dashboard/login.html` redirect to `/auth.html`, +9 LOC) in a worktree, runner pushed, `gh` opened [PR #1](https://github.com/justnau1020/finlet/pull/1), `ops.bugs.status` flipped to `in_review`, `ops.approval_queue.response_source='bug-fix-runner'`, Discord posted via both manual trigger and n8n workflow (executions 4 + 5 returned `success`). **PR not merged — awaiting human review per hard constraint.**

**3. [DONE 2026-04-17] Worktree cleanup + verify-after-merge (workflow #4 `bug-verify`).** Imported as `7EXsSTAITme7vuuX` (inactive). Extended `bug-fix-runner` with two endpoints: `/verify-candidates` (enumerates `in_review` bugs whose PR is MERGED in the `(10min, 7day)` window via `gh pr view`) and `/finalize-verify` (idempotent: flips bug to `resolved` + prunes worktree/local+remote branch, or flips to `triaged` on persistent failure). Workflow graph: Schedule (6h) → candidates → IF → [SplitInBatches → probe → claude-runner sonnet → parse → finalize → accumulate → summarize] → Discord. Smoke test 1: 2-row scenario (canary `f4232774` OPEN + synthetic referencing CLOSED PR #3 → 0 candidates, execution 14 `success` in ~2s, Discord posted "considered 2, 0 candidates, reason=not_merged×2"). Smoke test 2: synthetic bug + direct `/finalize-verify resolved:true` → 200, bug flipped to `resolved`, `resolved_at` stamped, `agent_runs` row created (input.kind=`bug-verify`). Second call returned `status=skipped reason=not_in_review (current=resolved)` — idempotency confirmed. Cleanup ran best-effort (worktree/branch not present for synthetic → all false with no errors). PR #2 and bug `f4232774` untouched throughout.

**4. Migrate webhook URL + Anchor key + PAT to n8n Credentials** (replace `$env.*` and `.env` files). Long-term: PAT rotation via `gh auth refresh` automation.

**5. Cloudflare Access email-allowlist policy** for `ops.finlet.dev` (currently only n8n password auth).

### Near-term (next 2-4 weeks)
- Langfuse for cost/trace observability (self-host → probably need CPX31 upgrade).
- Composio if Gmail/Slack automation needed.
- Marketing department: install `coreyhaines31/marketingskills`, wire weekly blog+social cron.
- `/standup` skill producing Monday morning brief (git + Stripe MRR + Linear + top bugs).

### Medium-term
- Research department (competitor-watch).
- Support department (Plain + Fin AI routed via `ops.approval_queue`).
- Accounting prep (QuickBooks + receipt capture).

---

## Cost Ledger

| Line | Monthly | Notes |
|---|---|---|
| Claude Code Max 20x | $200 | existing |
| Gemini Pro | $20 | existing |
| **Hetzner CPX21 Ashburn** | **$14** | **NEW 2026-04-17** |
| Anchor Browser free | $0 | |
| Cloudflare | $0 | |
| Discord | $0 | |
| n8n self-host | $0 | |
| **Total** | **$234/mo** | $66 headroom under $300 target |

Projected with Composio + Langfuse: ~$263/mo. Still under budget.

---

## First Moves for a Fresh Claude Session

1. Read this doc.
2. Source secrets: `set -a; source ~/.finlet-ops/secrets.env; set +a`
3. Sanity check whole stack:
   ```bash
   ssh -i ~/.ssh/finlet_ops_ed25519 ops@87.99.156.168 \
     "systemctl is-active claude-runner; \
      docker compose -f /opt/finlet-ops/compose/docker-compose.yml ps; \
      curl -s http://127.0.0.1:9099/health"
   ```
4. Check n8n:
   ```bash
   curl -s -H "X-N8N-API-KEY: $N8N_API_KEY" https://ops.finlet.dev/api/v1/workflows | python3 -m json.tool
   curl -s -H "X-N8N-API-KEY: $N8N_API_KEY" https://ops.finlet.dev/api/v1/executions?limit=5 | python3 -m json.tool
   ```
5. If building the next workflow: reference deploy artifacts in `~/.finlet-ops/deploy/` — same pattern as `workflow-ops-hello.json`, imported via `POST /api/v1/workflows`.

**Don't re-read the research agent output.** The decisions distilled from it are in the "Decisions" table above. Research is discarded.
