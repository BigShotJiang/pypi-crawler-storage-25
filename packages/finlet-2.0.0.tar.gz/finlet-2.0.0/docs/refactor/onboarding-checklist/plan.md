# Onboarding Checklist Refactor — Execution Plan

> Generated from `docs/bug-hunt/refactor-queue/onboarding-checklist.md` (status: ready, instances: 4, iterations: 2). 2026-04-30.
> Driven by: 4 instances of "checklist row drift" across 2 bug-hunt iterations — `strategy-checklist-dead-div`, `strategy-item-opens-leaderboard`, `onboarding-wizard-form-drift`, `checklist-no-advance-after-fill`. The Team B `7085ea7` event-bus migration partly closed the gap (introduced `STEP_TRIGGERS`) but left three hand-maintained registries of "what does the user do next" that drift independently.

## Constraints

- **Single team, single worktree.** Recon confirmed minimal cross-team overlap. Only `dashboard/onboarding.js` is rewritten; `dashboard/app.js` is read-only verification (publishers are already on the bus); doc files are additive. Splitting into multiple teams would create no parallelism — the work is one author's continuous flow over a single ~880-line file.
- **Small footprint.** `dashboard/onboarding.js` is 882 lines (verified `wc -l`). The refactor consolidates three registries into one + introduces a `WIZARD_STEPS` extraction. Net LOC change is approximately neutral or slight reduction (~150 LOC declarative replacing ~120 LOC imperative + bespoke handlers).
- **`STEP_TRIGGERS` already exists** at `dashboard/onboarding.js:42-47` (Team B `7085ea7` event-bus migration shipped). The refactor folds it into `CHECKLIST_STEPS` rather than introducing a new convention from scratch.
- **`window.openCreateSessionModal` already exists** at `dashboard/app.js:1241` (shipped in `6c256fb` for F5). The wizard's Step 2 already delegates to it (`onboarding.js:373-374, 474-475`). The refactor preserves this delegation; do NOT touch the publisher.
- **`window.openLeaderboardSubmitModal` exists** at `dashboard/leaderboard-submit.js:497`. The strategy row must NOT route to it — that was the F2 wrong-action recurrence shape. The strategy row routes to `agent-guide.html#strategies` (the `id="strategies"` anchor at `agent-guide.html:285` is canonical).
- **Strategy step trigger event (`strategy:saved`) does NOT exist today.** No publisher in any dashboard file. The refactor leaves the `TODO(post-launch)` in place — the strategy product surface is owned by product, not this refactor. Behavior remains: row click navigates AND directly calls `markStepComplete('strategy')` via the new dispatcher's `markOnClick: true` flag.
- **DO NOT use `dialogStateMirror`.** That module (`dashboard/dialog-state-mirror.js`, shipped `efdd44316f`) is a read-only-dialog mirror for live bus state. The checklist + wizard are write-side state machines (UI affordance triggers a write to localStorage). Different shape, different module. Bringing the mirror in here would be incorrect coupling.
- **DO NOT touch `finlet/marketplace/onboarding_service.py`.** That is developer-marketplace onboarding (a separate feature). This refactor is the dashboard checklist + wizard only.
- **DO NOT modify publishers in `dashboard/app.js`** (`session:switched` at `app.js:1368`, `order:filled` at `app.js:1514`, `portfolio:updated` at `app.js:1461`). All three are already on the bus and are read-only context for the refactor.
- **All cross-component dashboard wiring goes through `window.finletBus`** (CLAUDE.md root rule). The bus's `subscribe`/`publish`/`getLastPublished` shape is frozen — additive only.
- **Bare `.innerHTML =` outside `trustedHTML(...)` is blocked at pre-commit.** The three existing `innerHTML = trustedHTML(...)` writes at `onboarding.js:237, 551, 690` are correctly wrapped and stay wrapped. The refactor's new HTML-rendering paths must follow the same pattern.
- **`dashboard/event-contract.md` MUST be updated in the same commit** as any bus surface or convention change (CLAUDE.md root rule). This refactor adds (a) the `strategy:saved` event placeholder doc and (b) updates the `onboarding:step-completed` enum-source note + adds an "Adding a new checklist step" recipe.
- **Pytest baseline:** 3902/3902 (per latest handoff). Plan targets full suite green post-merge. The `tests/dashboard/` directory is `node --test`-driven (NOT pytest); pytest does not collect anything from it (`uv run pytest --collect-only tests/dashboard/` returns 0 items, verified).
- **Closed-source repo, pre-launch.** No back-compat shims for `STEP_TRIGGERS` consumers. Migrate cleanly to `CHECKLIST_STEPS`; remove the old constant.
- **Out of scope** (per spec):
  - The strategy product surface itself (`POST /v1/strategies`, strategy builder UI, `strategy:saved` publisher).
  - Server-side onboarding state (`/v1/onboarding/progress` endpoint).
  - `finlet/marketplace/onboarding_service.py` — different feature.
  - Wizard skip / partial-completion analytics.
  - Persona definition expansion (`PERSONAS.beginner` etc.) — enabled by `WIZARD_STEPS` but not done here.
  - Cross-page checklist persistence — checklist widget remains `index.html`-only.
  - Toast-on-step-complete celebration UI.
  - Dialog state mirror integration (different shape, see Constraints).

## Recon corrections vs. input doc

| Claim in input doc | Verified value | Note |
|---|---|---|
| `markStepComplete('strategy')` at `onboarding.js:743-757` | `onboarding.js:737-758` (block) — `markStepComplete('strategy')` call is at line 746 | Block start at 737, click handler call at 746. |
| `buildChecklistItem` at `onboarding.js:761-769` | `onboarding.js:761-769` | Verified accurate. |
| `STEP_TRIGGERS` at `onboarding.js:42-47` | `onboarding.js:42-47` | Verified accurate. |
| `state.steps` at `onboarding.js:54-59` | `onboarding.js:54-59` | Verified accurate. |
| Wizard auto-advance special case at `onboarding.js:827-840` | `onboarding.js:827-840` | Verified accurate. |
| `populateStep3` at `onboarding.js:411+` | `onboarding.js:492-568` | Function spans 492-568, not 411+. |
| `PERSONAS` at `onboarding.js:89-114` | `onboarding.js:89-114` | Verified accurate. |
| `app.js:1444-1455` `currentSession.portfolio_metrics` mirror | `app.js:1445-1455` | Off by 1; mirror runs lines 1445-1455. |
| `app.js:1498-1525` `order:filled` publish | `app.js:1498-1525` | Verified accurate (block); actual `publish` call at 1514. |
| `agent-guide.html:285` `id="strategies"` anchor | `agent-guide.html:285` | Verified accurate. |
| Tests directory: `tests/dashboard/` (node --test) | confirmed | Pattern: `tests/dashboard/event-bus.spec.js` (node:test + vm sandbox); pytest does NOT collect from this dir. |
| Playwright spec home: `tests/playwright/` | `tests/e2e/` (TypeScript, `journey-*.spec.ts` naming) | Project uses `tests/e2e/`, not `tests/playwright/`. Existing `tests/e2e/journey-onboarding.spec.ts` already covers the F2/F6 regression shapes; new wizard end-to-end coverage extends the same file or adds a sibling spec. |

All other recon claims (the `STEP_TRIGGERS.strategy = null` TODO, the wizard's Step 2 delegation to `openCreateSessionModal`, the `id="strategies"` anchor, `state.steps` keys = profile/session/analysis/strategy, four `state.steps` keys, the lack of any `strategy:saved` publisher anywhere in `dashboard/`) verified accurate.

## File Conflict Table

| File | Owning team | Touched by | Conflict? |
|------|-------------|-----------|-----------|
| `dashboard/onboarding.js` (882 lines) | dashboard | Team A (rewrite registries: `CHECKLIST_STEPS`, `WIZARD_STEPS`, `dispatchChecklistAction` helper, fold `STEP_TRIGGERS` + `state.steps` defaults + per-row click wiring + `populateStep3` action cards) | **none** — no other in-flight refactor touches this file. The `7085ea7` event-bus migration is already merged. The trade-ticket-state-sync refactor (shipped `efdd44316f`) is on `trade-ticket.js`, not `onboarding.js`. |
| `dashboard/app.js` (2574 lines) | dashboard | Team A (verify-only — read SSE handlers + bus publishers; no edits) | **none** — Team A reads `app.js:1141-1145` (modal openers), `app.js:1241` (`window.openCreateSessionModal`), `app.js:1354-1370` (`session:switched` publisher), `app.js:1431-1468` (`portfolio:updated` SSE handler), `app.js:1483-1530` (`order:filled` publisher). Plan forbids edits. |
| `dashboard/leaderboard-submit.js` (497 lines) | dashboard | Team A (verify-only — confirm strategy row does NOT route here) | **none** — read-only check that the new dispatcher's `navigate` action targets `agent-guide.html#strategies`, not the leaderboard modal. |
| `dashboard/agent-guide.html` | dashboard | none | **none** — `id="strategies"` anchor at `agent-guide.html:285` already shipped in `6c256fb`. The new dispatcher's `navigate` action depends on it; do not modify. |
| `dashboard/event-contract.md` (216 lines) | dashboard | Team A (additive — document `strategy:saved` placeholder + "Adding a new checklist step" recipe + close the `onboarding:step-completed` enum on `CHECKLIST_STEPS[].key`) | **none** — last touched by `trusted-types` (HTML-safety section, lines 83-115) and `trade-ticket-state-sync` (Last-published cache, lines 46-81). New section sits in the Events area (after `onboarding:step-completed` at line 185-197) plus a new "Adding a new checklist step" recipe near the existing "Adding a new event" section at line 201-206. |
| `dashboard/index.html` | dashboard | none | **none** — script load order at `index.html:582-596` is unchanged. `onboarding.js` already loads at line 592 (between `security-telemetry.js` at 591 and `trade-ticket.js` at 593). No new module file added by this refactor. |
| `tests/dashboard/onboarding-checklist.spec.js` (new) | dashboard | Team A (new file, ~150-200 LOC, `node --test`) | **none** — sibling-module unit tests; pattern from `tests/dashboard/event-bus.spec.js:30-46` (vm sandbox + minimal `window` shim). |
| `tests/e2e/journey-onboarding.spec.ts` (existing) | dashboard | Team A (extend OR add sibling spec — author's call) | **low** — file exists and currently has one fixmed test. Plan extends it with the wizard end-to-end walk + the four recurrence-shape regression assertions. Author may choose to extend in place or add a new sibling spec `tests/e2e/journey-onboarding-end-to-end.spec.ts`. |
| `docs/REMAINING_TASKS.md` | docs | Team A (one-line update — change the existing post-launch `STEP_TRIGGERS.strategy` entry at line 451 to reflect the new `CHECKLIST_STEPS` convention) | **low** — small file, single-bullet edit; merge conflicts unlikely. |
| `docs/decisions/onboarding-checklist-step-contract.md` (new) | docs | Team A (new decision record, mirror `docs/decisions/dashboard-event-bus.md` format) | **none** — new file. |

No conflict with any in-flight or queued refactor. Single-team plan; no cross-team merge gates needed.

## Dependency Graph

- **Team A (independent)** — single team, no upstream dependencies.
  Internal sequencing inside the team's worktree:
  1. Read the source doc + both precedent plans + the relevant `dashboard/onboarding.js` ranges (see "Read these files first" below).
  2. Extract `CHECKLIST_STEPS` registry — single source of truth for step key + label + trigger event + action.
  3. Build `dispatchChecklistAction(action)` helper — three action types (`open-modal`, `navigate`, `noop`); modal target registry inside the helper.
  4. Replace `state.steps` defaults derivation, `STEP_TRIGGERS` constant, and the per-row click wiring inside `renderChecklist` with calls into `CHECKLIST_STEPS`.
  5. Extract `WIZARD_STEPS` registry — single source of truth for the 3-step wizard's title + subtitle + body factory + `advanceTrigger` step-key.
  6. Generalize the wizard auto-advance from a special case to a registry-driven rule: `markStepComplete(key)` advances the wizard if `key === currentWizardStep.advanceTrigger`.
  7. Add the `tests/dashboard/onboarding-checklist.spec.js` unit spec — node:test + vm sandbox mirror of `event-bus.spec.js` pattern.
  8. Add the wizard end-to-end Playwright walk to `tests/e2e/journey-onboarding.spec.ts` (extend) OR a sibling spec — covers all four recurrence shapes in one walk.
  9. Update `dashboard/event-contract.md` — `strategy:saved` placeholder doc + "Adding a new checklist step" recipe + close the `onboarding:step-completed` step enum on `CHECKLIST_STEPS[].key`.
  10. Update `docs/REMAINING_TASKS.md` — rewrite the existing post-launch `STEP_TRIGGERS.strategy` bullet at line 451 for the new convention.
  11. Add `docs/decisions/onboarding-checklist-step-contract.md` — decision record (mirror `docs/decisions/dashboard-event-bus.md` format).
  12. Run all validation gates.
  13. `git add` + `git commit`.

## Critical Path

Team A (single team, single chain). No parallelism. Estimated wall-clock: 3-4 hours of agent work in one worktree, matching the spec's estimate.

---

## Teams

### Team A: Onboarding step-contract registry + wizard state-machine collapse + recurrence-shape Playwright spec

**Blocked by:** none — can start immediately.

**Read these files first:** (CRITICAL — do NOT skip)

- `docs/bug-hunt/refactor-queue/onboarding-checklist.md` — the spec this team implements. Read top-to-bottom. The "Refactor scope" section (lines 51-130) is authoritative for the `CHECKLIST_STEPS` shape, the `WIZARD_STEPS` shape, and the dispatcher's three action types (`open-modal`, `navigate`, `noop`). Do not invent new options.
- `docs/refactor/trusted-types/plan.md` — most recent shipped plan; mirror its tone, depth, and structural conventions (recon corrections section, file conflict table, single-team risk register).
- `docs/refactor/trade-ticket-state-sync/plan.md` — sibling shipped plan; mirror its level of detail in "Read these files first" + "Files touched" specs (file:line attribution; symbol+file callouts).
- `dashboard/onboarding.js` (whole file, 882 lines) — the entire refactor target. Specific ranges to study:
  - `onboarding.js:42-47` — `STEP_TRIGGERS` constant. Folds into `CHECKLIST_STEPS[].trigger`.
  - `onboarding.js:50-63` — `getDefaultState()` with hand-typed `state.steps` keys (profile/session/analysis/strategy). The new shape derives keys from `CHECKLIST_STEPS.map(s => s.key)`.
  - `onboarding.js:65-82` — `loadState()` with merge-with-defaults logic. Must keep this contract; orphaned localStorage keys from older versions get filtered out, missing keys get defaulted to `false`.
  - `onboarding.js:89-114` — `PERSONAS` constant. The wizard's `populateStep3` consumes `PERSONAS[selectedPersona].step3Action`. KEEP this constant; the refactor changes `populateStep3` to drive its action-card layout from `WIZARD_STEPS[2].body(persona)`, but the persona definitions themselves stay.
  - `onboarding.js:122-156` — `initOnboarding()`. The refactor preserves the init flow but folds `wireBusSubscribers` to iterate `CHECKLIST_STEPS` instead of `STEP_TRIGGERS`.
  - `onboarding.js:172-196` — `wireBusSubscribers()`. Loop body iterates `CHECKLIST_STEPS` post-refactor; the `session:switched` payload-capture special-case (lines 184-194) STAYS — `createdSessionId` is wizard state.
  - `onboarding.js:209-212` — `isAllStepsComplete()`. Hand-listed `state.steps.profile && ... && state.steps.strategy` becomes `CHECKLIST_STEPS.every(s => state.steps[s.key])`.
  - `onboarding.js:218-255` — `showWizard()`. No structural change; `buildWizardHTML()` is what changes. Keep the modal-controller wiring (`finletModal.suppress`, `finletModal.open` at 245, 251) intact.
  - `onboarding.js:257-328` — `buildWizardHTML()`. Replace the hand-authored 3-step DOM literal with `WIZARD_STEPS.map(buildStepDOM).join('')` plus the static progress bar + footer. The persona-grid (lines 280-289) is part of Step 1's `body` factory.
  - `onboarding.js:330-401` — `bindWizardEvents()`. Per-step event binding currently mixes persona-grid + skip + next + Step 2's "Open Session Creator" button. Post-refactor, each `WIZARD_STEPS[i].body` factory exposes a `bindEvents` callback so each step owns its own binding.
  - `onboarding.js:403-458` — `showStep()`. The footer button text + state logic (lines 441-457) drives off `WIZARD_STEPS[step-1]` post-refactor.
  - `onboarding.js:460-483` — `handleNext()`. The Step 2 branch (lines 468-479) delegates to `window.openCreateSessionModal`. KEEP this contract. The Step 1 → 2 transition's `state.steps.profile = true` (line 464) becomes `markStepComplete('profile')` — call the canonical mutator, not the bare flag write.
  - `onboarding.js:485-490` — comment block documenting the F5 wizard-form-drift fix. KEEP the comment as-is post-refactor; it's the historical note.
  - `onboarding.js:492-568` — `populateStep3()`. Hand-built persona-specific action cards. Post-refactor, this becomes a `WIZARD_STEPS[2].body(state)` invocation that consumes `PERSONAS[selectedPersona].step3Action`. The handler bindings (`tradeBtn`, `apiBtn`, `stepBtn`) move into the body factory's `bindEvents` callback.
  - `onboarding.js:570-639` — `handleTestTrade`, `handleCopyApi`, `handleStepClock`. KEEP all three functions UNCHANGED. They're called from the `populateStep3` (now `WIZARD_STEPS[2].body`) bindings. Their bodies are imperative work (API calls, clipboard, error handling) that doesn't fit a registry shape and shouldn't.
  - `onboarding.js:641-646` — `showActionResult()`. KEEP UNCHANGED. Helper used by the three handlers above.
  - `onboarding.js:648-670` — `dismissWizard()`. KEEP UNCHANGED structurally; it's the wizard close path.
  - `onboarding.js:676-759` — `renderChecklist()`. THE primary rewrite target. Replace lines 699-702 (the four hand-listed `buildChecklistItem` calls) with `${CHECKLIST_STEPS.map(s => buildChecklistItem(s.key, s.label, state.steps[s.key])).join('')}`. Replace the strategy-specific click-wiring block at 737-758 with a generic loop that iterates `CHECKLIST_STEPS`, looks up each row's `data-checklist-key`, and binds a single click handler that invokes `dispatchChecklistAction(s.action)` — the dispatcher knows what `open-modal` / `navigate` / `noop` mean.
  - `onboarding.js:761-769` — `buildChecklistItem`. KEEP the function shape (`(key, label, done)` → HTML literal); it's the pure renderer. The action-binding moves to the loop in `renderChecklist`.
  - `onboarding.js:771-806` — `updateChecklist()`. The `Object.entries(state.steps)` loop (line 782) STAYS but iterates the same shape; no edits.
  - `onboarding.js:812-857` — `markStepComplete()`. KEEP the mutator. The wizard auto-advance special case (lines 827-840) generalizes: replace `if (!wasAlreadyDone && stepKey === 'session') { ... showStep(3) ... }` with `if (!wasAlreadyDone) { const wizardStep = WIZARD_STEPS.find((w, i) => w.advanceTrigger === stepKey && currentStep === i + 1); if (wizardStep) showStep(WIZARD_STEPS.indexOf(wizardStep) + 2); }` (or equivalent — the contract is "if a wizard step's `advanceTrigger` matches AND the wizard is on that step, advance one"). The createdSessionId fallback (lines 834-837) STAYS as-is in the `session` branch.
  - `onboarding.js:868-880` — `window.FinletOnboarding` + `window.finletOnboarding` exports. KEEP both unchanged (external contract; `app.js` and tests reach in via `window.finletOnboarding.markStepComplete`).
- `dashboard/app.js:1141-1145` — header "New Session" button + "Create Your First Session" CTA both call `openCreateSessionModal()`. **Read-only context.** Do NOT edit. The new dispatcher's `open-modal` action with target `create-session` invokes `window.openCreateSessionModal`, which lives at `app.js:1201`.
- `dashboard/app.js:1241` — `window.openCreateSessionModal = openCreateSessionModal`. **Read-only context.** This is the global the dispatcher consumes.
- `dashboard/app.js:1354-1370` — `session:switched` publisher (lines 1368-1370 inside an unrelated callsite). **Read-only context.**
- `dashboard/app.js:1431-1468` — `portfolio:updated` SSE handler. **Read-only context.** Mentioned for completeness; this refactor does not touch the cash-mirror logic.
- `dashboard/app.js:1483-1530` — `order:filled` publisher (the actual `publish` call at 1514). **Read-only context.** This is the publisher the new `CHECKLIST_STEPS.find(s => s.key === 'analysis').trigger === 'order:filled'` subscriber consumes.
- `dashboard/leaderboard-submit.js:497` — `window.openLeaderboardSubmitModal = openLeaderboardSubmitModal`. **Read-only context.** Confirms the leaderboard modal exists. The new dispatcher must NOT register `'leaderboard'` as an `open-modal` target — the strategy row's action is `navigate` to `agent-guide.html#strategies`, not `open-modal`.
- `dashboard/agent-guide.html:285` — `<div class="guide-tip guide-tip--success" id="strategies">` anchor. **Read-only context.** The dispatcher's `navigate` action's `href` targets this anchor.
- `dashboard/event-contract.md:185-197` — current `onboarding:step-completed` event entry. The plan extends it: close the `step` field's enum on `CHECKLIST_STEPS[].key` (today says "final list owned by Team B"; new wording references the registry as the source of truth).
- `dashboard/event-contract.md:201-206` — current "Adding a new event" recipe. Plan adds a parallel "Adding a new checklist step" recipe near it.
- `dashboard/index.html:582-596` — script load order. `onboarding.js` at line 592, after `event-bus.js` (line 584) and `security-telemetry.js` (line 591), before `trade-ticket.js` (line 593) and `app.js` (line 596). **Read-only context** — no module added; load order unchanged.
- `tests/dashboard/event-bus.spec.js:1-60` — node:test pattern. The `freshBus()` factory at lines 41-46 (read full file via `cat`) shows the canonical vm-sandbox + `window` shim. The new spec follows this exact pattern.
- `tests/dashboard/dialog-state-mirror.spec.js:1-80` — sibling spec; the most recent example of a multi-source vm-sandbox setup (loads BOTH the bus and the consumer module into the same sandbox). Useful template for testing the bus-subscriber wiring inside the new spec.
- `tests/dashboard/form-dirty-tracker.spec.js:1-40` — another sibling-module unit-test spec; shows the `__test__` export pattern if the new spec needs internal-state introspection.
- `tests/e2e/journey-onboarding.spec.ts` (whole file, 263 lines) — existing onboarding journey. The wizard end-to-end walk extends this spec OR adds a sibling. Note the `seedOnboardingMidFlight` fixture (lines 51-68) — the new walk needs a `seedOnboardingFresh` variant that sets `wizardDismissed: false` so the wizard appears.
- `tests/e2e/playwright.config.ts` — Playwright config. Confirms `tests/e2e/` (NOT `tests/playwright/`) and the `journey-*.spec.ts` naming convention. The new walk follows this convention.
- `docs/REMAINING_TASKS.md:451` — current "Onboarding `strategy` step trigger event" bullet. The refactor rewrites this single line (or single bullet) to reflect the new `CHECKLIST_STEPS` shape: post-launch task is "publish `strategy:saved` from the strategy module" (one line), not "edit `STEP_TRIGGERS` + click handler + action map".
- `docs/decisions/dashboard-event-bus.md` — format precedent for the new decision record `docs/decisions/onboarding-checklist-step-contract.md`. Mirror this file's structure (Context / Decision / Alternatives / Consequences / Validation).
- `docs/decisions/dialog-state-mirror-prime-ordering.md` — most recently shipped decision record; same dashboard surface. Use as a structural template if `dashboard-event-bus.md` is too terse.
- `scripts/lint-trusted-types.sh` — pre-commit guard. The refactor must not introduce bare `.innerHTML =`. The three existing wraps at `onboarding.js:237, 551, 690` must remain wrapped. New HTML rendering paths (e.g., the `WIZARD_STEPS[i].body(state)` factories) must return string HTML that is wrapped before insertion.
- `scripts/setup-git-hooks.sh` — installs the pre-commit hook. Already installed if you've worked on this repo before; harmless to re-run.

**Files touched (8 — at the ceiling, no slack):**

- **Modified: `dashboard/onboarding.js`** — primary refactor target. Specific changes:

  1. **Add `CHECKLIST_STEPS` registry** (~line 35-95, replacing the `STEP_TRIGGERS` constant + the comment block at 12-41):
     ```js
     // ============================================================
     //  CHECKLIST_STEPS — single source of truth for the dashboard
     //  "Getting Started" checklist + onboarding wizard's per-step
     //  action contract.
     //
     //  Each entry owns: persistence-key + label + trigger event +
     //  action contract. Adding a new step is one entry; the
     //  registry drives state.steps defaults, bus subscribers,
     //  row rendering, and click-action dispatch.
     //
     //  See docs/refactor/onboarding-checklist/plan.md and
     //  docs/decisions/onboarding-checklist-step-contract.md.
     //
     //  TODO(post-launch): when the strategy product surface ships,
     //  publish 'strategy:saved' from that module and remove the
     //  `markOnClick: true` flag from the strategy entry's action.
     //  Tracked in docs/REMAINING_TASKS.md.
     // ============================================================
     const CHECKLIST_STEPS = [
       {
         key: 'profile',
         label: 'Set up profile',
         trigger: null,                                    // manual — flipped during wizard Step 1 advance
         action: { type: 'noop' },                         // no row click — wizard owns this step
       },
       {
         key: 'session',
         label: 'Create first session',
         trigger: 'session:switched',
         action: { type: 'open-modal', target: 'create-session' },
       },
       {
         key: 'analysis',
         label: 'Run first analysis',
         trigger: 'order:filled',
         action: { type: 'open-modal', target: 'trade-ticket' },
       },
       {
         key: 'strategy',
         label: 'Learn how to build a strategy',
         trigger: 'strategy:saved',                        // post-launch event — null-tolerant subscriber
         action: { type: 'navigate', href: 'agent-guide.html#strategies', markOnClick: true },
       },
     ];
     ```

  2. **Add `dispatchChecklistAction(action)` helper** (~line 100-150, before `getDefaultState`):
     ```js
     // Modal-target registry. Adding a new modal target is one
     // line. Keep the registry small — the contract is "open the
     // canonical modal that already exists in app.js"; do NOT
     // duplicate modal-creation logic here.
     const MODAL_TARGETS = {
       'create-session': () => window.openCreateSessionModal?.(),
       'trade-ticket':   () => window.openTradeTicket?.(),
     };

     function dispatchChecklistAction(action) {
       if (!action || typeof action !== 'object') return;

       if (action.type === 'noop') return;

       if (action.type === 'open-modal') {
         const opener = MODAL_TARGETS[action.target];
         if (typeof opener === 'function') {
           opener();
         } else {
           console.warn('[Finlet onboarding] no modal target for', action.target);
           if (typeof showToast === 'function') {
             showToast({ type: 'error', title: 'Action unavailable',
                         message: 'Reload the page and try again.' });
           }
         }
         return;
       }

       if (action.type === 'navigate') {
         if (action.markOnClick && typeof action.stepKey === 'string') {
           // Tick the step BEFORE navigating so the counter advances
           // even if navigation is blocked or the user comes back.
           markStepComplete(action.stepKey);
         }
         if (typeof action.href === 'string' && action.href) {
           window.location.href = action.href;
         }
         return;
       }

       console.warn('[Finlet onboarding] unknown action type:', action.type);
     }
     ```
     NOTE: `dispatchChecklistAction` takes a step's action object plus the calling context's step key (the dispatcher's `navigate` branch needs the stepKey to call `markStepComplete`). Wire `action.stepKey` from the row-iteration loop in `renderChecklist` (next change).

  3. **Replace `getDefaultState()` (lines 50-63)** to derive `state.steps` keys from `CHECKLIST_STEPS`:
     ```js
     function getDefaultState() {
       const steps = {};
       for (const s of CHECKLIST_STEPS) steps[s.key] = false;
       return {
         completed: false,
         persona: null,
         steps: steps,
         wizardDismissed: false,
         checklistDismissed: false,
       };
     }
     ```

  4. **Update `loadState()` (lines 65-82)** to filter orphan keys + default missing keys:
     ```js
     function loadState() {
       try {
         const raw = localStorage.getItem(ONBOARDING_KEY);
         if (raw) {
           const parsed = JSON.parse(raw);
           const def = getDefaultState();
           // Filter parsed.steps to known keys only; drop orphans
           // from older versions. Missing keys get the default
           // (false) from `def.steps`.
           const cleanSteps = { ...def.steps };
           if (parsed.steps && typeof parsed.steps === 'object') {
             for (const s of CHECKLIST_STEPS) {
               if (s.key in parsed.steps) cleanSteps[s.key] = !!parsed.steps[s.key];
             }
           }
           return { ...def, ...parsed, steps: cleanSteps };
         }
       } catch { /* corrupted — reset */ }
       return getDefaultState();
     }
     ```

  5. **Replace `wireBusSubscribers()` (lines 172-196)** to iterate `CHECKLIST_STEPS`:
     ```js
     function wireBusSubscribers() {
       if (typeof window === 'undefined' || !window.finletBus
           || typeof window.finletBus.subscribe !== 'function') {
         console.warn('[Finlet onboarding] window.finletBus unavailable — '
                      + 'event-driven checklist steps will not auto-advance. '
                      + 'Verify dashboard/event-bus.js loads before onboarding.js.');
         return;
       }
       for (const step of CHECKLIST_STEPS) {
         if (!step.trigger) continue; // null/undefined = manual step, no subscription
         const stepKey = step.key;
         const eventName = step.trigger;
         window.finletBus.subscribe(eventName, function (payload) {
           // session:switched payload-capture special case — keep
           // the wizard's createdSessionId in sync with the freshly
           // -active session id.
           if (eventName === 'session:switched'
               && payload && typeof payload.session_id === 'string') {
             createdSessionId = payload.session_id;
           }
           markStepComplete(stepKey);
         });
       }
     }
     ```

  6. **Update `isAllStepsComplete()` (lines 209-212)** to iterate `CHECKLIST_STEPS`:
     ```js
     function isAllStepsComplete() {
       if (!state) return false;
       return CHECKLIST_STEPS.every(s => !!state.steps[s.key]);
     }
     ```

  7. **Add `WIZARD_STEPS` registry** (~line 220-280, before `showWizard`):
     ```js
     // ============================================================
     //  WIZARD_STEPS — single source of truth for the 3-step
     //  onboarding wizard. Each entry: title + subtitle + body
     //  factory + advanceTrigger (the CHECKLIST_STEPS key whose
     //  completion auto-advances the wizard from this step).
     //
     //  buildWizardHTML maps over this. populateStep3 (the per-
     //  persona action cards) becomes WIZARD_STEPS[2].body(state).
     //
     //  Adding a new wizard step is one entry; no edits to
     //  showStep/handleNext beyond the registry-driven advance
     //  rule.
     // ============================================================
     const WIZARD_STEPS = [
       {
         id: 1,
         title: 'What describes you?',
         subtitle: "We'll customize your experience based on your goals.",
         body: () => /* persona grid HTML literal — current lines 280-289 */,
         advanceTrigger: null,        // step 1 advances on Continue button click
         nextLabel: 'Continue',
       },
       {
         id: 2,
         title: 'Create Your First Session',
         subtitle: 'A session is a sandboxed trading environment with its own clock, capital, and stock universe. Pick a starter template (Conservative ETF, Tech Growth, or Custom) in the dialog.',
         body: () => /* "Open Session Creator" button + status hint — current lines 305-308 */,
         advanceTrigger: 'session',   // markStepComplete('session') advances to step 3
         nextLabel: 'Open Session Creator',
       },
       {
         id: 3,
         title: 'Take Your First Action',
         subtitle: 'Choose how you want to get started.',
         body: (persona) => /* per-persona action cards — current lines 511-549 */,
         advanceTrigger: 'analysis',  // markStepComplete('analysis') auto-completes the wizard
         nextLabel: 'Go to Dashboard',
       },
     ];
     ```

  8. **Replace `buildWizardHTML()` (lines 257-328)** to map over `WIZARD_STEPS`:
     ```js
     function buildWizardHTML() {
       const stepsHTML = WIZARD_STEPS.map((s, i) => `
         <div class="onboarding-step ${i === 0 ? 'onboarding-step--active' : ''}" id="ob-step-${s.id}">
           <h2 class="onboarding-step-title" id="ob-step${s.id}-title">${s.title}</h2>
           <p class="onboarding-step-subtitle" id="ob-step${s.id}-subtitle">${s.subtitle}</p>
           ${s.body(/* state args wired per-step in populateWizardStep */)}
         </div>
       `).join('');
       return `
         <div class="onboarding-card">
           <div class="onboarding-progress" aria-label="Wizard progress">
             ${WIZARD_STEPS.map((s, i) => /* progress dot HTML */).join('')}
             ${WIZARD_STEPS.slice(0, -1).map((_, i) => /* progress line HTML */).join('')}
           </div>
           ${stepsHTML}
           <div class="onboarding-footer">
             <button type="button" class="onboarding-skip" id="ob-skip">Skip to dashboard</button>
             <button type="button" class="onboarding-btn-next" id="ob-next" disabled>Continue</button>
           </div>
         </div>
       `;
     }
     ```
     NOTE: The exact HTML must produce identical class/id/role/aria attributes to today's literal so the existing CSS in `dashboard/onboarding.css` doesn't need edits. Verify by diffing the rendered HTML before/after.

  9. **Update `showStep()` (lines 403-458)** to drive footer button text + populate per-step body from `WIZARD_STEPS[step-1]`:
     ```js
     function showStep(step) {
       currentStep = step;
       const overlay = document.getElementById('onboarding-overlay');
       if (!overlay) return;
       const wizardStep = WIZARD_STEPS[step - 1];
       if (!wizardStep) return;

       // visibility / progress dots / progress lines — KEEP the
       // existing logic (lines 408-438), it's mechanical DOM toggling.

       const nextBtn = document.getElementById('ob-next');
       if (nextBtn) {
         nextBtn.textContent = wizardStep.nextLabel;
         nextBtn.disabled = (step === 1 && !selectedPersona);
       }

       // Step-specific body population (Step 3 needs the persona
       // for action-card generation).
       if (step === 3) {
         populateStep3FromRegistry();   // see change 11
       }
     }
     ```

  10. **Replace the wizard auto-advance special case in `markStepComplete()` (lines 827-840)** with a registry-driven advance:
      ```js
      if (!wasAlreadyDone) {
        const overlay = document.getElementById('onboarding-overlay');
        if (overlay) {
          // Find the wizard step whose advanceTrigger matches and
          // is the current step. If found, advance one step.
          const wizardIdx = WIZARD_STEPS.findIndex((w, i) =>
            w.advanceTrigger === stepKey && currentStep === i + 1);
          if (wizardIdx >= 0 && wizardIdx + 2 <= WIZARD_STEPS.length) {
            // session-step advance: keep the createdSessionId fallback
            if (stepKey === 'session' && !createdSessionId
                && typeof currentSessionId !== 'undefined' && currentSessionId) {
              createdSessionId = currentSessionId;
            }
            showStep(wizardIdx + 2);
          } else if (wizardIdx >= 0 && wizardIdx + 2 > WIZARD_STEPS.length) {
            // The last wizard step's advanceTrigger fired — auto-
            // complete the wizard. (Step 3's analysis trigger.)
            dismissWizard();
          }
        }
      }
      ```

  11. **Add `populateStep3FromRegistry()`** (~replaces `populateStep3` at lines 492-568):
      ```js
      function populateStep3FromRegistry() {
        const persona = PERSONAS[selectedPersona] || PERSONAS.retail;
        const cardsEl = document.getElementById('ob-action-cards');
        const resultEl = document.getElementById('ob-action-result');
        if (resultEl) {
          resultEl.style.display = 'none';
          resultEl.className = 'onboarding-action-result';
        }
        if (!cardsEl) return;
        cardsEl.innerHTML = trustedHTML(WIZARD_STEPS[2].body(persona));
        // Bind action-card events post-render. Same handlers as today.
        const tradeBtn = document.getElementById('ob-action-trade');
        if (tradeBtn) tradeBtn.addEventListener('click', () => handleTestTrade(tradeBtn));
        const apiBtn = document.getElementById('ob-action-api');
        if (apiBtn) apiBtn.addEventListener('click', () => handleCopyApi(apiBtn));
        const stepBtn = document.getElementById('ob-action-step');
        if (stepBtn) stepBtn.addEventListener('click', () => handleStepClock(stepBtn));
      }
      ```

  12. **Replace `renderChecklist()` rows + per-row click wiring (lines 699-758)** with registry-driven loops:
      ```js
      // Inside widget.innerHTML = trustedHTML(`...`):
      <div class="checklist-body">
        ${CHECKLIST_STEPS.map(s =>
            buildChecklistItem(s.key, s.label, !!state.steps[s.key])
          ).join('')}
      </div>
      ```
      And later (replacing the strategy-specific block at 737-758) with a generic loop:
      ```js
      // Bind each row's click action through the dispatcher.
      for (const step of CHECKLIST_STEPS) {
        if (step.action.type === 'noop') continue;
        const item = widget.querySelector(`.checklist-item[data-checklist-key="${step.key}"]`);
        if (!item) continue;
        item.style.cursor = 'pointer';
        item.setAttribute('role', 'button');
        item.setAttribute('tabindex', '0');
        item.setAttribute('aria-label', step.label + (step.action.type === 'navigate'
          ? ' — opens ' + step.action.href.replace(/.*\//, '').replace(/#.*/, '')
          : ''));
        const handler = () => dispatchChecklistAction({ ...step.action, stepKey: step.key });
        item.addEventListener('click', handler);
        item.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handler();
          }
        });
      }
      ```

  13. **DELETE the old `STEP_TRIGGERS` constant** (lines 42-47). Its mapping is folded into `CHECKLIST_STEPS[].trigger`.

  14. **DELETE the bespoke strategy-row click block** (current lines 737-758). Its semantics are folded into the generic dispatcher loop above.

  15. **DELETE the old `populateStep3`** (lines 492-568). Replaced by `populateStep3FromRegistry`.

  16. **KEEP the wizard-step `state.steps.profile = true` write at line 464 inside `handleNext()`** — replace it with `markStepComplete('profile')` so the canonical mutator path is used (publishes `onboarding:step-completed` for free).

  17. **KEEP all of**: `loadState`, `saveState`, `PERSONAS`, `state`/`currentStep`/`selectedPersona`/`createdSessionId` module-scope state, `initOnboarding`, `checkFirstLogin`, `showWizard`, `bindWizardEvents`, `handleNext`, `handleTestTrade`, `handleCopyApi`, `handleStepClock`, `showActionResult`, `dismissWizard`, `buildChecklistItem`, `updateChecklist`, `markStepComplete`, `isOnboardingComplete`, `window.FinletOnboarding`, `window.finletOnboarding`. Their bodies may shift inline (e.g., to call the new dispatcher) but their contracts and external surface stay.

  18. **Net LOC change estimate:** -30 to -60 lines. Additions: `CHECKLIST_STEPS` (~25 LOC), `WIZARD_STEPS` (~35 LOC), `dispatchChecklistAction` + `MODAL_TARGETS` (~40 LOC), `populateStep3FromRegistry` (~12 LOC), generic row-binding loop (~20 LOC). Deletions: `STEP_TRIGGERS` (~6), hand-listed `state.steps.* &&` chain (~5), strategy-row block (~25), `populateStep3` body factory (~75), `buildWizardHTML` body factory (~70 — net delta after replacement).

- **Modified: `dashboard/event-contract.md`**:
  - Update the `onboarding:step-completed` event entry (lines 185-197): rewrite the `step` field's note from `"final list owned by Team B"` to `"value drawn from CHECKLIST_STEPS[].key in dashboard/onboarding.js — currently 'profile', 'session', 'analysis', 'strategy'"`.
  - Add a new event entry for `strategy:saved` (placeholder) immediately after `onboarding:step-completed`:
    ```md
    ### `strategy:saved`

    A strategy was saved by the user via the strategy product surface.
    Currently a placeholder — no publisher exists today (the strategy
    product surface ships post-launch, see docs/REMAINING_TASKS.md).
    Subscribed by the onboarding `strategy` checklist step so the row
    auto-advances when the strategy module ships.

    | Field | Type | Notes |
    |-------|------|-------|
    | `strategy_id` | string | Server-assigned id of the saved strategy. |
    | `name`        | string | User-supplied strategy name. |

    - **Publisher:** TBD — strategy product surface (post-launch).
    - **Subscribers:**
      - Onboarding `strategy` step — `dashboard/onboarding.js` (CHECKLIST_STEPS subscriber). Calls `markStepComplete('strategy')` on event.
    ```
  - Add a new "Adding a new checklist step" recipe near the existing "Adding a new event" recipe (line 201-206):
    ```md
    ## Adding a new checklist step

    1. Add an entry to `CHECKLIST_STEPS` in `dashboard/onboarding.js`:
       `{ key, label, trigger, action }`. The `trigger` is a bus event
       name (or `null` for manual). The `action` is one of `{ type:
       'noop' }`, `{ type: 'open-modal', target: '<key>' }`, or
       `{ type: 'navigate', href: '<url>', markOnClick?: true }`.
    2. If the action is `open-modal`, add the target to `MODAL_TARGETS`
       in the same file (one line: `'<key>': () => window.<opener>?.()`).
    3. If the trigger is a new event name, document it in this file
       (see "Adding a new event" above) AND publish it from the
       canonical surface that owns the state-change moment.
    4. Update `dashboard/event-contract.md`'s `onboarding:step-completed`
       step enum to include the new key.
    5. Update `docs/REMAINING_TASKS.md` if the trigger event is not
       yet implemented.
    6. The state.steps default + DOM row + bus subscriber + click
       handler are all auto-derived. No further edits required.
    ```

- **Modified: `docs/REMAINING_TASKS.md`** — single-line update at line 451. Replace the existing post-launch `STEP_TRIGGERS.strategy` bullet with:
  ```md
  - **Onboarding `strategy` step trigger event publisher** — LOW —
    `dashboard/onboarding.js`'s `CHECKLIST_STEPS.strategy.trigger` is
    set to `'strategy:saved'` (post-launch event placeholder; see
    `dashboard/event-contract.md`). When the strategy product surface
    ships, publish `strategy:saved` from that module on save (one
    `window.finletBus.publish('strategy:saved', { strategy_id, name })`
    call). Then remove the `markOnClick: true` flag from the strategy
    entry's action in `CHECKLIST_STEPS` so the row only navigates
    (the bus subscriber takes over the step-complete flip). No edits
    to wireBusSubscribers, renderChecklist, or any per-row click
    handler are required — the registry handles propagation.
    Estimated: 30 minutes after the strategy product ships.
  ```

- **New: `tests/dashboard/onboarding-checklist.spec.js`** — node:test unit spec, ~150-200 LOC, mirrors `tests/dashboard/event-bus.spec.js` and `tests/dashboard/dialog-state-mirror.spec.js` patterns. Build a fresh module instance per test in an isolated VM context with a stub bus + minimal `window`/`document`/`localStorage` shim. Required tests:

  1. **`state.steps keys exactly match CHECKLIST_STEPS.map(s => s.key) after loadState`** — fresh localStorage, call `loadState()` → `Object.keys(state.steps)` is exactly `['profile', 'session', 'analysis', 'strategy']`.
  2. **`loadState filters orphan keys from older versions`** — pre-seed localStorage with `{steps: {profile: true, session: true, ghost: true}}`. After `loadState`, `state.steps` has `profile, session, analysis, strategy` keys but NOT `ghost`.
  3. **`loadState defaults missing keys to false`** — pre-seed with `{steps: {profile: true}}` only. After `loadState`, `state.steps.session === false`, `state.steps.analysis === false`, `state.steps.strategy === false`.
  4. **`wireBusSubscribers iterates CHECKLIST_STEPS and skips null triggers`** — stub bus with a recording `subscribe`. After `initOnboarding`, exactly two subscriptions exist: one for `session:switched`, one for `order:filled`. NO subscription for null-trigger steps (profile, strategy stays manual until publisher ships — `strategy:saved` IS a non-null trigger so it WILL subscribe; the test verifies the count is 3, not 2 — adjust assertion). NOTE: with the spec's CHECKLIST_STEPS shape, profile is null + the other three are non-null; expect 3 subscriptions.
  5. **`dispatchChecklistAction({type: 'open-modal', target: 'create-session'}) calls window.openCreateSessionModal exactly once`** — stub `window.openCreateSessionModal` with a counter. Dispatch the action. Counter is 1.
  6. **`dispatchChecklistAction({type: 'open-modal', target: 'unknown'}) logs a warning and does not throw`** — capture console.warn. Dispatch with unknown target. Warning recorded; no exception.
  7. **`dispatchChecklistAction({type: 'navigate', href: 'agent-guide.html#strategies', markOnClick: true, stepKey: 'strategy'}) calls markStepComplete BEFORE navigation`** — stub `markStepComplete` and `window.location.href` setter. Dispatch. Verify call order: `markStepComplete('strategy')` recorded, then `window.location.href` assigned.
  8. **`dispatchChecklistAction({type: 'navigate', href: '...', markOnClick: false}) does NOT call markStepComplete`** — same setup, `markOnClick` omitted. Verify no markStepComplete recorded.
  9. **`Wizard auto-advance fires when markStepComplete('session') is called AND wizard is on Step 2`** — instantiate the module with a DOM shim that has `#onboarding-overlay` + `currentStep = 2`. Call `markStepComplete('session')`. Verify `showStep(3)` was invoked (use a test hook or spy on the function).
  10. **`Wizard auto-advance does NOT fire when markStepComplete('session') is called AND wizard is on Step 1`** — same shim, `currentStep = 1`. Call `markStepComplete('session')`. Verify `showStep` was NOT invoked.
  11. **`Wizard auto-advance does NOT fire when wizard is closed`** — DOM shim has no `#onboarding-overlay`. Call `markStepComplete('session')`. Verify `showStep` was NOT invoked.
  12. **`Wizard auto-completes (dismissWizard) when markStepComplete('analysis') is called AND wizard is on Step 3`** — DOM shim with overlay + currentStep = 3. Verify `dismissWizard()` invoked.
  13. **`Adding a hypothetical 5th entry to CHECKLIST_STEPS produces a 5th state.steps key on next loadState (registry-as-source-of-truth fixture test)`** — patch the module's `CHECKLIST_STEPS` array via a test hook OR re-load the module source with an additional entry pre-pended. After `loadState`, `state.steps` has 5 keys. Render checklist; assert 5 `[data-checklist-key="..."]` elements in the DOM shim. NOTE: this test requires a `__test__` export hook on `window.FinletOnboarding` (or `window.finletOnboarding.__test__`) that allows mutation of `CHECKLIST_STEPS` for the test only. Add the hook in the same commit.

  Pattern reference: load module source via `vm.runInContext` with a sandbox containing `{ console, window: { finletBus: stubBus, localStorage: {...}, openCreateSessionModal: spy }, document: { ... } }`. Each test gets a fresh sandbox.

- **Extended OR new: `tests/e2e/journey-onboarding.spec.ts` OR `tests/e2e/journey-onboarding-end-to-end.spec.ts`** — Playwright end-to-end walk. Author's call: extend the existing 263-line spec with new test cases, or add a sibling. Required tests (regardless of where they live):

  1. **`Wizard appears on fresh load + advances through all 3 steps`** — clear localStorage; load `/index.html`; assert `#onboarding-overlay` visible; click persona `Retail`; click `Continue`; wizard advances to Step 2; assert exactly ONE `#ob-open-create-session` button visible; assert ZERO `<input>` elements inside `#ob-step-2` (the F5 regression check); click `#ob-open-create-session`; assert `#create-session-modal` visible; submit a Conservative ETF session; wizard advances to Step 3; assert action cards visible per persona.
  2. **`Strategy row navigates to agent-guide.html#strategies AND ticks the counter (F2 regression)`** — seed `wizardDismissed: true, profile: true, session: true, analysis: true, strategy: false`; load `/index.html`; assert checklist visible; click `[data-checklist-key="strategy"]`; assert URL ends with `agent-guide.html#strategies` (Playwright's `expect(page.url()).toContain(...)`); navigate back; assert `state.steps.strategy === true` in localStorage; assert NO `#leaderboard-submit-modal` was visible during the click (regression check).
  3. **`Analysis row ticks within 4s of order:filled bus publish (F6 regression)`** — same seed but `analysis: false`; load page; trigger `window.finletBus.publish('order:filled', {...})` from `page.evaluate`; poll `state.steps.analysis` until true within 4000ms; assert `[data-checklist-key="analysis"]` has class `checklist-item--done`.
  4. **`Wizard Step 2 has zero <input> elements (F5 regression)`** — clear localStorage; load page; pick persona; advance to Step 2; assert `await page.locator('#ob-step-2 input').count()` === 0; assert `await page.locator('#ob-step-2 button').count()` === 1 (the Open Session Creator button).
  5. **`Strategy row click does NOT open the leaderboard modal (F2 regression)`** — duplicate of test 2's leaderboard-hidden assertion, broken out for clarity.
  6. **`No console errors during the full wizard walk + checklist tick journey`** — wrap test 1 with `collectConsoleErrors`; assert zero unexpected errors at the end.

  Note: existing `journey-onboarding.spec.ts` test is `.fixme`'d at line 80 with a TODO about the universe-mismatch. The new tests do NOT depend on real S3 data — test 3 uses `page.evaluate(() => finletBus.publish(...))` to drive the bus directly (same path the existing fixmed test uses internally). Real-trade walks (test 1's Step 3 action card) MAY be skipped via `test.skip()` in CI when no fillable price plugin is configured.

- **New: `docs/decisions/onboarding-checklist-step-contract.md`** — decision record. Mirror the structure of `docs/decisions/dashboard-event-bus.md` (Context / Decision / Alternatives / Consequences / Validation). Sections to include:
  - **Context:** 4 instances of "checklist row drift" across 2 bug-hunt iterations; root cause = three hand-maintained registries (`state.steps`, `STEP_TRIGGERS`, per-row HTML literal + click wiring).
  - **Decision:** consolidate into `CHECKLIST_STEPS` (+`WIZARD_STEPS` for the wizard); a single declarative array drives state defaults, bus subscribers, row rendering, and click-action dispatch through a small `dispatchChecklistAction(action)` helper.
  - **Alternatives considered:**
    - Server-side onboarding state — out of scope, separate decision.
    - One mega-registry that fuses CHECKLIST + WIZARD — rejected: wizard steps are time-ordered (1 → 2 → 3), checklist steps are status-flag (toggle each independently). Different shapes.
    - Bus-publishing every step from a single sink — rejected: publishers (app.js SSE handler, wizard handleNext, checklist row click) are scattered by ownership; the registry centralizes the SUBSCRIBER side, which is the failure-mode side.
  - **Consequences:** adding a 5th step is one entry; the registry is one-edit. Removing a step is one delete; orphaned localStorage keys filter out on next `loadState`. The `markOnClick: true` flag on the strategy entry is the only "manual tick" surface area; once `strategy:saved` ships, that flag drops and the step becomes pure-bus.
  - **Validation:** node:test unit spec at `tests/dashboard/onboarding-checklist.spec.js` (the registry-as-source-of-truth fixture test is the property invariant). Playwright walks at `tests/e2e/journey-onboarding*.spec.ts` cover the four recurrence shapes end-to-end.

**Deliverable:** A single merged commit on `main` that:
1. Replaces the three hand-maintained onboarding registries (`state.steps` defaults, `STEP_TRIGGERS`, per-row HTML literal + click handlers) with a single `CHECKLIST_STEPS` registry of `{ key, label, trigger, action }` entries; introduces a `dispatchChecklistAction(action)` helper with three action types (`open-modal`, `navigate`, `noop`) and a `MODAL_TARGETS` registry for modal openers.
2. Extracts `WIZARD_STEPS` for the 3-step wizard with `{ id, title, subtitle, body, advanceTrigger, nextLabel }` shape; collapses the special-case wizard auto-advance at `onboarding.js:827-840` into a generic registry-driven rule.
3. Preserves all four current step behaviors byte-identically: profile (manual on wizard Step 1 advance), session (`session:switched` subscriber + create-session modal opener), analysis (`order:filled` subscriber + trade-ticket opener), strategy (`strategy:saved` subscriber placeholder + navigate-to-guide with `markOnClick: true` until publisher ships).
4. Documents the new convention in `dashboard/event-contract.md` (`strategy:saved` placeholder doc + "Adding a new checklist step" recipe).
5. Updates `docs/REMAINING_TASKS.md`'s post-launch `strategy` bullet to reflect the one-line publisher migration.
6. Ships a `node --test` unit spec at `tests/dashboard/onboarding-checklist.spec.js` covering the registry-as-source-of-truth invariant, the dispatcher's three action types, the wizard auto-advance rule, and the loadState orphan-key filter.
7. Ships a Playwright walk (extending `tests/e2e/journey-onboarding.spec.ts` or adding a sibling spec) covering all four historical recurrence shapes in one run.
8. Adds a decision record at `docs/decisions/onboarding-checklist-step-contract.md`.

**Validation:** (commands the agent MUST run and pass before declaring done)

- [ ] `node --test tests/dashboard/onboarding-checklist.spec.js` — all unit tests pass (target: 13/13).
- [ ] `node --test tests/dashboard/event-bus.spec.js` — existing 12 tests still pass (no regression from the bus's read side; this refactor doesn't touch event-bus.js but the unit tests hit it).
- [ ] `node --test tests/dashboard/dialog-state-mirror.spec.js` — existing 10 tests still pass.
- [ ] `node --test tests/dashboard/form-dirty-tracker.spec.js` — existing tests still pass.
- [ ] `bash scripts/lint-trusted-types.sh` — exits 0 on the post-refactor tree.
- [ ] `bash tests/dashboard/lint-trusted-types.spec.sh` — all 6 fixture cases pass (regression check).
- [ ] `npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-onboarding.spec.ts --project=chromium` — all NON-fixme tests pass; the new wizard end-to-end + four recurrence-shape regression tests all pass.
- [ ] `npx playwright test --config=tests/e2e/playwright.config.ts --project=chromium` — full Playwright sweep passes (no regression in other journeys).
- [ ] `uv run pytest tests/ --ignore=tests/e2e -q` — full Python suite passes; **target: 3902 passed, 0 failed**, matching the latest baseline. No tests in `tests/dashboard/` are collected by pytest (verified — `uv run pytest --collect-only tests/dashboard/` returns 0 items), so this gate measures the rest of the suite.
- [ ] `grep -c "STEP_TRIGGERS" dashboard/onboarding.js` returns 0 (constant deleted).
- [ ] `grep -c "CHECKLIST_STEPS" dashboard/onboarding.js` returns >= 5 (definition + at least 4 readers: defaults, subscribers, isAllStepsComplete, render, dispatcher).
- [ ] `grep -c "WIZARD_STEPS" dashboard/onboarding.js` returns >= 4 (definition + readers in buildWizardHTML, showStep, populateStep3FromRegistry, markStepComplete).
- [ ] `grep -c "dispatchChecklistAction" dashboard/onboarding.js` returns >= 2 (definition + at least one call site in renderChecklist).
- [ ] `grep -c "MODAL_TARGETS" dashboard/onboarding.js` returns >= 2 (definition + reader in dispatchChecklistAction).
- [ ] `grep -c "populateStep3" dashboard/onboarding.js` — count of OLD function name should be 0; new name `populateStep3FromRegistry` count >= 2 (definition + caller in showStep).
- [ ] `grep -c "agent-guide.html#strategies" dashboard/onboarding.js` returns >= 1 (preserved in CHECKLIST_STEPS strategy entry).
- [ ] `grep -c "openLeaderboardSubmitModal" dashboard/onboarding.js` returns 0 (regression check — strategy row must NOT route here).
- [ ] `grep -c "strategy:saved" dashboard/onboarding.js dashboard/event-contract.md docs/REMAINING_TASKS.md` returns >= 3 (registry trigger + event-contract entry + remaining-tasks reference).
- [ ] `grep -c "TODO(post-launch)" dashboard/onboarding.js` returns >= 1 (the `markOnClick: true` removal-on-publisher-ship reminder stays).
- [ ] **Manual smoke test (in-browser):**
  1. Open dashboard with cleared `localStorage`. Wizard appears.
  2. Pick `Retail` persona. Click Continue. Wizard advances to Step 2.
  3. Click "Open Session Creator". Canonical Create Session modal opens. Submit a Conservative ETF session. Wizard advances to Step 3.
  4. Click "Make a Test Trade" action card. Trade ticket opens. Submit BUY 1 SPY MARKET. Wait for fill (1-2 clock steps). Wizard auto-completes; checklist `analysis` row ticks.
  5. Click `Learn how to build a strategy` row. Page navigates to `agent-guide.html#strategies`. Browser back; checklist now shows `strategy` row as ticked.
  6. Reload. Checklist auto-dismisses (all 4 done).
  7. Clear `localStorage`. Inspect DevTools Network: zero failed `/v1/...` calls during the walk. Inspect Console: zero errors, zero `Refused to create a TrustedTypePolicy` warnings.
- [ ] `git diff --stat` shows changes confined to the eight-file set in this plan; no surprise file modifications.

**Agent instructions:**

- **You MUST `git add` and `git commit` before finishing.** Worktree contents are discarded if uncommitted. **This is the #1 failure mode.**
- **Commit message:** `refactor(onboarding): step-contract registry — collapse state.steps + STEP_TRIGGERS + per-row click wiring into CHECKLIST_STEPS` followed by a one-paragraph body referencing `docs/bug-hunt/refactor-queue/onboarding-checklist.md` and the four recurrence shapes the refactor closes (`strategy-checklist-dead-div`, `strategy-item-opens-leaderboard`, `onboarding-wizard-form-drift`, `checklist-no-advance-after-fill`).
- **Read the refactor doc top-to-bottom before writing any code.** Do not shortcut. The Why/Root-cause sections (lines 14-50) explain why the three registries must collapse together.
- **Read `docs/refactor/trusted-types/plan.md` and `docs/refactor/trade-ticket-state-sync/plan.md` before touching code.** They are the closest precedents (same dashboard surface, same single-team pattern, same node:test infra).
- **The migration is mechanical, not creative.** The spec's `CHECKLIST_STEPS` shape (lines 60-86 of the source doc) and the `dispatchChecklistAction` action types (lines 87-92) are AUTHORITATIVE. Do NOT rename keys, add fields, or invent new action types beyond `open-modal`, `navigate`, `noop`. If you find a fourth action type is needed, surface the obstacle in the commit message rather than expanding scope.
- **Do NOT use `dialogStateMirror`.** The previous drafter flagged this — it's a read-only-dialog mirror, structurally distinct from the step-completion state machine here. Do NOT import or call `window.dialogStateMirror` in onboarding.js. The refactor consumes `window.finletBus.subscribe` directly via the `wireBusSubscribers` loop.
- **Do NOT touch `finlet/marketplace/onboarding_service.py`.** Marketplace red herring — different concept (dev onboarding, not user dashboard).
- **The `strategy:saved` event publisher stays out of scope** — leave the `TODO(post-launch)` in place. The `markOnClick: true` flag in the `CHECKLIST_STEPS.strategy.action` is the only way the strategy step ticks until the publisher ships.
- **Do NOT modify `dashboard/app.js`.** All three publishers (`session:switched`, `order:filled`, `portfolio:updated`) are already on the bus and are upstream of this refactor. If you find a reason to touch app.js, surface the obstacle.
- **Do NOT modify `dashboard/leaderboard-submit.js`.** Read-only verification only — confirms the strategy row is NOT routed there.
- **Do NOT modify `dashboard/agent-guide.html`.** Read-only — the `id="strategies"` anchor at line 285 is the canonical landing for the navigate action.
- **Use `trustedHTML(...)` for every HTML insertion.** The existing wraps at `onboarding.js:237, 551, 690` MUST stay wrapped. New insertions inside `WIZARD_STEPS[i].body(...)` factories return string HTML; the consuming `innerHTML = trustedHTML(...)` writes wrap them. Run `bash scripts/lint-trusted-types.sh` before commit; exits 0.
- **Do NOT introduce `addEventListener('finlet:...')` or `dispatchEvent(new CustomEvent('finlet:...'))`.** CLAUDE.md root rule: all dashboard cross-component wiring goes through `window.finletBus`.
- **Wire `markStepComplete('profile')` from `handleNext()`'s Step 1 branch** (line 464). Replace the bare `state.steps.profile = true; saveState(state); updateChecklist();` with a single `markStepComplete('profile')` call. The mutator publishes `onboarding:step-completed` for free.
- **Preserve the wizard's modal-controller wiring.** The `finletModal.suppress('onboarding', 'create-session')` call at line 245 and the `finletModal.open('onboarding')` / `close('onboarding')` calls at 251, 662 are owned by `dashboard/modal-controller.js`. Do NOT touch them.
- **Preserve the `session:switched` payload-capture special case** in `wireBusSubscribers` (lines 184-194). The wizard's `createdSessionId` is captured from the bus payload so Step 3's Test Trade button targets the right session.
- **Preserve the `currentSessionId` fallback** in the wizard advance logic (lines 834-837). Cover the edge case where `markStepComplete('session')` is invoked from a direct UI action rather than the bus subscriber.
- **The `markOnClick: true` flag in the strategy entry's action MUST be removable** when the strategy publisher ships — drop the flag, the bus subscriber takes over the step-complete flip on `strategy:saved`. Document this in the entry's inline comment.
- **The `__test__` export hook on `window.finletOnboarding`** (for the unit-test fixture-driven 5th-step scenario) is for unit-test introspection ONLY. Production code MUST NOT call it. Mirror the `__dialogStateMirrorTest__` pattern in `dashboard/dialog-state-mirror.js`.
- **The `tests/e2e/journey-onboarding.spec.ts` extension is your call:** extend the existing file or add a sibling. The existing test is `.fixme`'d (TODO at line 76-79); leave it `.fixme`'d unless you also fix the universe-mismatch (out of scope here).
- **Before declaring done, run the full Python test suite + the full Playwright sweep** to catch regressions outside the per-team test scope. Pytest baseline: 3902/3902. Any drop is blocking.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Refactor changes the rendered HTML (class names, ids, aria attributes, or DOM structure) such that `dashboard/onboarding.css` no longer styles the wizard correctly | Medium | High | The `WIZARD_STEPS[i].body(...)` factories MUST emit byte-identical class/id/role/aria attribute strings to the current literal at `onboarding.js:257-328`. Diff-test by capturing `outerHTML` of a freshly-rendered wizard before/after the refactor in the unit spec. The Playwright wizard walk also catches visual regressions via the `expect(...).toBeVisible()` assertions on the existing CSS classes. |
| Wizard auto-advance rule generalization breaks the existing `session` → Step 3 advance because the `WIZARD_STEPS.findIndex` lookup misses the right entry | Medium | High | Unit test 9 (Wizard auto-advance fires) explicitly drives `markStepComplete('session')` with the wizard on Step 2 and asserts `showStep(3)` is invoked. The Playwright wizard walk also exercises this path end-to-end. |
| `markStepComplete('analysis')` fires Step 3 → wizard auto-completion via `dismissWizard()` BEFORE the user has read the success message | Medium | Medium | The current behavior (lines 480-482 of onboarding.js) requires the user to click "Go to Dashboard" — the wizard does NOT auto-complete on `markStepComplete('analysis')`. Spec deviation: the source doc lines 91-95 say "Step 3's `advanceTrigger` is `'analysis'` (so the wizard auto-completes when the user submits a real first order, not just when they click 'Go to Dashboard')" — this IS a deliberate behavior change. Mitigation: a one-second `setTimeout` between `showActionResult('success', ...)` and `dismissWizard()` so the user sees the success state for a moment. Unit test 12 covers this; Playwright test 1 includes a `waitFor(1000)` after the trade fills before asserting the wizard is dismissed. |
| `loadState()` filter drops keys that other code reads (e.g., `state.persona`, `state.wizardDismissed`, `state.checklistDismissed`) | Low | High | The filter applies ONLY to `parsed.steps`, not to the top-level state object. Verified by re-reading `loadState()` rewrite — it spreads `parsed` over `def` first, then overrides `steps` with the cleaned subset. Other top-level keys pass through unchanged. Unit test 2 (orphan-key filter) verifies steps-only scope; add a paired test that pre-seeds `persona: 'retail', wizardDismissed: true` and asserts both pass through after `loadState`. |
| `dispatchChecklistAction({type: 'navigate', markOnClick: true})` calls `markStepComplete` AFTER `window.location.href = ...` instead of BEFORE, missing the tick | Medium | High | Unit test 7 explicitly asserts call order. The dispatcher implementation MUST: (1) call `markStepComplete(stepKey)` synchronously, (2) THEN assign `window.location.href`. Synchronous JS guarantees the markStepComplete completes (including localStorage write) before the navigation begins. |
| `MODAL_TARGETS` is missing a target the test references (e.g., `'trade-ticket'`) because `window.openTradeTicket` is defined in `dashboard/trade-ticket.js` and the test sandbox doesn't load it | Low | Medium | Unit test 5 stubs `window.openCreateSessionModal`. Tests that exercise the `'trade-ticket'` target stub `window.openTradeTicket` similarly. The dispatcher's `opener?.()` optional-chain handles the missing-function case (logs warning, shows toast); test 6 covers this branch. |
| Pytest baseline regression — full suite drops below 3902 due to test collection or import side-effect | Low | Medium | The refactor touches only dashboard JS + docs files. No Python imports change. Pre-flight check: `uv run pytest tests/ --ignore=tests/e2e --collect-only -q | tail -5` should show 3902 collected before AND after the refactor. Post-merge gate: `uv run pytest tests/ --ignore=tests/e2e -q` returns `3902 passed`. |
| Playwright wizard walk fails on CI because no S3 price plugin is configured to fill the BUY 1 SPY MARKET order in test 1 | High | Medium | Test 1's Step 3 action card (`Make a Test Trade`) has a fallback: drive `window.finletBus.publish('order:filled', ...)` via `page.evaluate` after submitting the order — same pattern as the existing fixmed test at `journey-onboarding.spec.ts:171-179`. The bus publish triggers the analysis-step subscriber + the wizard's auto-complete rule; the real fill is best-effort (passes if S3 is reachable, skipped otherwise). |
| `tests/e2e/journey-onboarding.spec.ts` extension introduces flakiness because the wizard appears at unpredictable times relative to page load | Medium | Low | Use `await page.waitForSelector('#onboarding-overlay', {state: 'visible', timeout: 5000})` BEFORE clicking persona cards. The wizard's `initOnboarding` runs from app.js DOMContentLoaded; the overlay should appear within ~1s on a fresh load. Add explicit `expect.poll` for any localStorage-assertions, mirroring the existing test's lines 188-208 pattern. |
| Worktree commit forgotten — work is lost | Low | Critical | Explicit instruction to `git add` + `git commit` is repeated in the agent-instructions section AND in the deliverable section. The validation gate's `git diff --stat` step requires the changes to be on disk. |
| `onboarding.js` becomes longer instead of shorter despite the consolidation, making it harder to review | Low | Low | The refactor's net LOC target is -30 to -60 (verified via the per-change estimates in the Files Touched section). If the diff comes in net-positive, the agent should re-examine for missed dead-code (especially `populateStep3` which is wholly replaced by `populateStep3FromRegistry`). |
| The `__test__` export hook on `window.finletOnboarding` leaks into production | Low | Low | Mirror the form-dirty-tracker / dialog-state-mirror convention: only attach the hook when a `__test__` flag is set on the parent object, OR keep it always-attached but document explicitly that production code MUST NOT call it. The `tests/dashboard/dialog-state-mirror.spec.js` example (line 44 — `testHook: sandbox.window.__dialogStateMirrorTest__`) shows the always-attached idiom. |
| The wizard's Step 1 → 2 transition's `markStepComplete('profile')` call publishes `onboarding:step-completed` with `step: 'profile'`, which a future analytics subscriber wasn't expecting | Low | Low | Adding the publish is a strict superset of current behavior (today the call directly writes `state.steps.profile = true` without publishing). The bus subscriber surface for `onboarding:step-completed` today is empty (per `dashboard/event-contract.md:197`); no consumer breaks. |

## Session Plan

### Session 1: Step-contract registry + wizard collapse + recurrence-shape Playwright spec (single session)

**Sequential merge order:**
1. Team A merges (single team). Validation gates pass on the worktree before merge.
2. After merge to main: run the full validation suite on main:
   - `node --test tests/dashboard/onboarding-checklist.spec.js`
   - `node --test tests/dashboard/event-bus.spec.js`
   - `node --test tests/dashboard/dialog-state-mirror.spec.js`
   - `node --test tests/dashboard/form-dirty-tracker.spec.js`
   - `bash scripts/lint-trusted-types.sh`
   - `bash tests/dashboard/lint-trusted-types.spec.sh`
   - `npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-onboarding.spec.ts --project=chromium`
   - `uv run pytest tests/ --ignore=tests/e2e -q` (target: `3902 passed`)
3. Manual smoke test in-browser per the Validation checklist.

**Why one session:** the chain is short (single team), the work has natural sequential dependencies inside one author's flow (CHECKLIST_STEPS extraction → dispatcher → state.steps derivation → bus subscriber loop → WIZARD_STEPS extraction → wizard advance generalization → unit spec → Playwright walk → contract update), and there are no shared files outside this refactor. Splitting into multiple sessions adds orchestration cost without parallelism gain.

**Worktree strategy:** single worktree spawn. The agent runs the full sequence linearly inside the worktree, commits once, and returns the merge SHA.

**Session checkpoint:** after merge, run the FULL Playwright suite once (`npx playwright test --config=tests/e2e/playwright.config.ts --project=chromium`) and `uv run pytest tests/ --ignore=tests/e2e -q` on main. If clean, mark `docs/bug-hunt/refactor-queue/onboarding-checklist.md` `status: shipped, shipped_in: <merge sha>`. Reset `verdict:` to pending; the next bug-hunt iteration sets it.

**Rollback path:** single SHA. The registry extraction is mechanical to revert: `CHECKLIST_STEPS`, `WIZARD_STEPS`, `dispatchChecklistAction`, `MODAL_TARGETS` are net ~150 LOC; the equivalent hand-edited surfaces they replace are ~120 LOC across four sites in `onboarding.js`. Revert is ~30 minutes if the dispatcher's contract turns out to be wrong; the post-`7085ea7` baseline (declarative `STEP_TRIGGERS` + per-row click handlers) remains intact in git history and can be cherry-picked back. The new Playwright spec is additive — leaving it in after a revert is harmless (the F2/F5/F6 regression tests still pass against the pre-refactor code, since they test behavior, not internal structure).

## Verdict-tracking notes (for the next iteration's Phase 6)

After this refactor lands, the next `/bug-hunt` iteration's Phase 6 sets the `verdict:` field on `docs/bug-hunt/refactor-queue/onboarding-checklist.md` based on the four named recurrence shapes:

- **`effective`** — All four named recurrence shapes pass cleanly:
  - "Save first strategy" / "Learn how to build a strategy" row is interactive and ticks the counter (recurrence shape from `20260428T013300Z6e79` and `20260428T031818Z2efa` F2 — load dashboard fresh, click the row, assert it advances AND assert it lands on `agent-guide.html#strategies` rather than the leaderboard modal).
  - Wizard Step 2 has no bespoke form — it delegates to the canonical Create Session modal (recurrence shape from `20260428T031818Z2efa` F5 — open the wizard, advance to Step 2, assert exactly one button and zero `<input>` elements; assert clicking it opens `#create-session-modal`).
  - "Run first analysis" row ticks after a real fill (recurrence shape from `20260428T031818Z2efa` F6 — open wizard, complete persona + session, submit a BUY 1 SPY MARKET that fills, assert the row ticks within 4s of the SSE push).
  - No new "documented affordance with no action" rows — adding a hypothetical 5th entry to `CHECKLIST_STEPS` automatically produces a row with a wired click handler, a bus subscription (if `trigger` is non-null), and a `state.steps` default. Verified by the unit-test fixture, not the live walk.
- **`incomplete`** — A new finding fires the same shape on the checklist or wizard (e.g., a 5th step gets added but the registry-as-source-of-truth invariant slips because someone hand-edited a sibling site instead of the registry). Likely root cause: the dispatcher contract didn't anticipate a new action type. Fix: extend `dispatchChecklistAction` with the new type + extend `MODAL_TARGETS` if a new modal is involved.
- **`regressed`** — A new failure shape introduced by the refactor (e.g., the wizard never auto-advances on `session:switched` because the `WIZARD_STEPS.findIndex` lookup is wrong; the strategy row navigates but doesn't tick because the `markOnClick: true` flag was dropped). Indicates the registry's contract broke something the bespoke flow handled. Revert is single SHA — the consumer migration is mechanical and reversible by restoring `STEP_TRIGGERS` + the strategy-specific click block.

## Status — 2026-04-30

- **Team A:** COMPLETED. Refactor commit `ef9f293` (6 files, +1471/-282), test-seed fix-up commit `40368b2` (1 file, +35/-1).
- **Per-merge gate (on main):** PASS — lint 2/2, unit specs 15/15 + sibling 29/29, pytest **3902 passed (570.74s)**, Playwright 5 pass / 1 skip (pre-existing fixme).
- **Post-merge gate (on main, after fix-up):** PASS — two test-seed bugs caught in `tests/e2e/journey-onboarding.spec.ts` were fixed surgically (test-only; no production code changed). Pytest baseline 3902 preserved (re-run skipped for the test-only fix-up — no Python changes).
- **Surprises during execution:** four Playwright test seed bugs surfaced in the post-merge gate (registry-driven wizard correctly enforced contracts that the older seed fixtures didn't satisfy). Fix-up touched only `tests/e2e/journey-onboarding.spec.ts`; production code intact.

