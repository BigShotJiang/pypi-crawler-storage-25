# Trusted Types Convention — Execution Plan

> Generated from `docs/bug-hunt/refactor-queue/trusted-types.md`. Last updated: 2026-04-30.

## Constraints

- **Hard ordering constraint:** the lint broaden (`scripts/lint-trusted-types.sh`) and the eight `dashboard/*.html` wraps MUST land in the same commit/PR. The broadened lint surfaces the eight unwrapped sites; the wraps close them. Out-of-order merge would fail the lint gate on its own commit.
- The Trusted Types policy block in `dashboard/api-utils.js` lines 404-474 has not been modified by any of the three shipped refactors (`modal-stacking`, `dirty-state-tracker`, `trade-ticket-state-sync`) per the input doc's conflict table — verified via `event-contract.md:80` last-touched note. This refactor's additions are confined to lines 440-455 (default-policy callbacks) plus a new top-level `securitypolicyviolation` listener after the policy block.
- **Single-team refactor.** Seven files (under the 8-file ceiling). One worktree, one merge SHA.
- **CSP header is out of scope** (`security_middleware.py:214`). Do NOT touch.
- **Vendor JS is out of scope.** Keep the `// trusted-types-vendor-allowlist` marker on `dashboard/vendor/lightweight-charts.standalone.production.js`.

## Recon corrections (vs. input doc)

The following line cites in the input doc are off; the plan below uses the verified values.

| Claim in input doc | Verified value | Note |
|---|---|---|
| `reportClientError` at `api-utils.js:380-402` | `api-utils.js:386-402` | Function declaration starts at line 386, not 380. |
| `agent-guide.html:450-471` (precedent wrap pattern) | `agent-guide.html:448-456` and `:467-471` | Two separate `try/catch` arms each contain the wrap; both use the same `trustedHTML(...)` pattern shown at lines 450 and 468. |
| `routes_csp.py:40-64` (CSP report endpoint) | `routes_csp.py:40-64` | Verified accurate. |
| `routes_csp.py:67-84` (client-error report) | `routes_csp.py:67-84` | Verified accurate. |
| Tests live under `tests/playwright/` | `tests/e2e/` (Playwright, `.spec.ts`) | Project uses Playwright's TypeScript runner with `journey-*.spec.ts` naming; config at `tests/e2e/playwright.config.ts`. The new spec MUST be `.ts`, not `.js`. |
| `tests/dashboard/_fixtures/` exists | does not exist yet | Team must create the fixtures dir. Existing `tests/dashboard/` holds only `*.spec.js` files (event-bus, form-dirty-tracker, dialog-state-mirror). |

All other recon claims (the eight `verify.html`/`setup.html` line numbers, the policy block at `api-utils.js:413-458`, the lint glob at line 154, the `event-contract.md:83-89` HTML-safety section) verified accurate.

## File Conflict Table

| File | Touched by | Notes |
|---|---|---|
| `scripts/lint-trusted-types.sh` | Team A | none |
| `dashboard/verify.html` | Team A | none |
| `dashboard/setup.html` | Team A | none |
| `dashboard/api-utils.js` | Team A | additive — new code inside default-policy callbacks (lines 440-455) + new listener after line 458; does not touch named-policy block at 413-434 or `trustedHTML()` at 469 |
| `dashboard/event-contract.md` | Team A | additive — extends HTML-safety section at lines 83-89 |
| `tests/dashboard/lint-trusted-types.spec.sh` | Team A | new file |
| `tests/dashboard/_fixtures/*` | Team A | new fixture dir (5 files) |
| `tests/e2e/journey-trusted-types.spec.ts` | Team A | new file |

No conflicts with shipped refactors (`modal-stacking`, `dirty-state-tracker`, `trade-ticket-state-sync`) — confirmed against the input-doc's file conflict matrix.

## Dependency Graph

- **Team A** is the sole team. No blocking dependencies on other teams.

## Critical Path

- Team A → merge to main → run validation gate → done.

---

## Teams

### Team A: Trusted Types convention

**Blocked by:** none — can start immediately.

**Read these files first:** (CRITICAL — do NOT skip)

- `docs/bug-hunt/refactor-queue/trusted-types.md` — refactor scope, root-cause analysis, and break-even justification. The plan derives from this. **Read it first, top-to-bottom.**
- `scripts/lint-trusted-types.sh` (whole file, 180 lines) — current lint logic. Note the vendor-allowlist marker handling at line 93, the `find` glob at line 154 (`-name '*.js'` — broaden this), the awk state-machine at lines 116-153, and the failure-message block at lines 163-172.
- `dashboard/api-utils.js` lines 386-474 — `reportClientError` helper at 386-402 (sendBeacon to `/v1/telemetry/client-error`), Trusted Types policy block at 413-458 (`finlet-default` named policy 415-434, `default` policy 438-455), `trustedHTML()` wrap at 469-474.
- `dashboard/agent-guide.html` lines 448-471 — precedent for the `trustedHTML(...)` wrap pattern inside a `<script>` block. **Use this as the template for `verify.html` and `setup.html` wraps** — same call shape, same identity semantics.
- `finlet/api/security_middleware.py:214` — current CSP header (`trusted-types finlet-default default goog#html; require-trusted-types-for 'script'; report-uri /v1/csp-report`). DO NOT modify.
- `finlet/api/routes_csp.py:40-84` — existing CSP report endpoint at 40-64 (do not touch) and existing `client_error_report` endpoint at 67-84 (the new reporter POSTs to this; rate-limited at `_CLIENT_SECURITY_RATE_LIMIT = 20/60s`).
- `dashboard/event-contract.md:83-89` — current HTML-safety pattern doc; the section to extend.
- `tests/dashboard/event-bus.spec.js` lines 1-30 — pattern for node `--test`-style dashboard unit tests (this refactor's lint test is bash-driver-driven instead, but the same dir is the right home).
- `tests/e2e/playwright.config.ts` (whole file) — confirms `baseURL: 'http://localhost:8000'`, `storageState: 'tests/e2e/.auth/session.json'` (chromium project). The new spec needs to override `storageState: undefined` for the unauthed `/auth.html` portion of the test.

**Files touched (8 — at the ceiling, no slack):**

- **Modified: `scripts/lint-trusted-types.sh`** —
  - Broaden `find` glob (line 154): `find "$DASH_DIR" -type f \( -name '*.js' -o -name '*.html' \) -print0`.
  - Broaden sink regex (lines 138 and 144 inside the awk block): single combined regex `\.(innerHTML|outerHTML)[[:space:]]*=|\.insertAdjacentHTML[[:space:]]*\(|document\.write[[:space:]]*\(|\.createContextualFragment[[:space:]]*\(`.
  - Add an awk state-machine variable `in_script` that toggles on `<script` (case-insensitive) and off on `</script>`. For files matching `*.html`, the sink-regex check fires only when `in_script == 1`. For `*.js` files, `in_script` defaults to `1` (always-on) — implemented by setting `in_script = 1` in `BEGIN` if `FILENAME` ends in `.js`, else `0`.
  - Update error message at line 164: replace `bare .innerHTML write site(s)` with `bare HTML-sink write site(s) (innerHTML, outerHTML, insertAdjacentHTML, document.write, createContextualFragment)`.
  - Update the help-text at line 165: keep the `trustedHTML()` wrap recommendation; the `dashboard/api-utils.js:469` reference still holds.

- **Modified: `dashboard/verify.html`** — wrap four bare `statusEl.innerHTML = '...'` writes at lines 101, 120, 126, 133 in `trustedHTML(...)`. All four are static strings (no user data). Pattern: `statusEl.innerHTML = trustedHTML('<...>');`. Same wrap shape as `agent-guide.html:450`.

- **Modified: `dashboard/setup.html`** — wrap four bare `btn.innerHTML = '...'` writes at lines 397, 401, 415, 418 in `trustedHTML(...)`. Lines 397 and 415 are static SVG markup (the "Copied!" success state, identical to `agent-guide.html:450, 468`). Lines 401 and 418 reassign `btn.innerHTML = originalHTML` — wrap as `btn.innerHTML = trustedHTML(originalHTML);` (identity in non-TT browsers; TT-creates-from-string is the same shape as `agent-guide.html:454, 471`).

- **Modified: `dashboard/api-utils.js`** —
  - Inside the three `default` policy callbacks at lines 440-453 (`createHTML`, `createScript`, `createScriptURL`), add a paired `reportClientError({ type: 'trusted_types_violation', sink: 'createHTML' /* etc. */, message: input.substring(0, 120), source: (new Error()).stack ? (new Error()).stack.split('\n')[2] || '' : '' })` call. **Wrap each call in `try { ... } catch (_e) { /* never block render */ }`** — the existing `reportClientError` already has its own try/catch, but a defense-in-depth wrap inside the policy callback prevents any rare failure (e.g., stack-frame parsing edge case) from bubbling into the page-render path.
  - After line 458 (just before the closing `}` of the `if (window.trustedTypes && ...)` block, OR at module top-level — pick whichever is consistent with the existing global-error-handler at lines 477-485), add `document.addEventListener('securitypolicyviolation', function(e) { try { if (e.effectiveDirective === 'trusted-types' || e.violatedDirective === 'trusted-types') { reportClientError({ type: 'trusted_types_violation', sink: 'csp_securitypolicyviolation', message: (e.blockedURI || '') + ' ' + (e.sample || ''), source: e.sourceFile + ':' + e.lineNumber }); } } catch (_e) {} });`. This catches CSP-side violations (e.g., a third-party policy creation blocked by the allowlist) that the runtime `default` policy never sees.

- **Modified: `dashboard/event-contract.md`** — extend the HTML-safety section at lines 83-89 to:
  - Enumerate the broader sink list (`innerHTML`, `outerHTML`, `insertAdjacentHTML`, `document.write`, `createContextualFragment`) as covered by the lint.
  - Document the runtime violation reporter (default-policy `reportClientError` calls + `securitypolicyviolation` listener) as the production-telemetry fallback for any sink the lint missed.
  - Add a one-line note that `.html` files with inline `<script>` blocks are now scanned (case-insensitive `<script>...</script>` boundaries).
  - Keep the `dashboard/api-utils.js:469` cross-reference for `trustedHTML()`.

- **New: `tests/dashboard/lint-trusted-types.spec.sh`** — bash test driver. One function `assert_lint_exits()` that takes a fixture path and an expected exit code; runs `bash scripts/lint-trusted-types.sh --check $fixture_dir` (with `DASH_DIR` overridden via env var so the lint scans the fixture tree, not the real `dashboard/`) and asserts. Six cases:
  1. `_fixtures/bare-outer-html.js` → exit 1
  2. `_fixtures/bare-iah.js` → exit 1
  3. `_fixtures/bare-html-block.html` → exit 1
  4. `_fixtures/wrapped-iah.js` → exit 0
  5. `_fixtures/attribute-only.html` → exit 0
  6. `_fixtures/same-line-forgiveness.js` and `_fixtures/next-line-forgiveness.js` → exit 0 (preserves existing forgiveness behavior). NOTE: the lint script today reads `DASH_DIR="$REPO_ROOT/dashboard"` from a fixed path. The bash test driver will need to either (a) `export REPO_ROOT=<fixture root>` or (b) run the script from a temp tree. Pick (b) — copy `scripts/lint-trusted-types.sh` to a temp dir, set up `dashboard/` with the fixtures inside the temp tree, run from there. This isolates the test from the real codebase.

- **New: `tests/dashboard/_fixtures/*` (5 small files)** —
  - `bare-outer-html.js`: `el.outerHTML = '<x/>';` (one line, no wrap)
  - `bare-iah.js`: `el.insertAdjacentHTML('beforeend', '<x/>');` (one line, no wrap)
  - `bare-html-block.html`: `<html><body><script>el.innerHTML = '<x/>';</script></body></html>`
  - `wrapped-iah.js`: `el.insertAdjacentHTML('beforeend', trustedHTML('<x/>'));`
  - `attribute-only.html`: `<button onclick="alert(1)">click</button>` (NO `<script>` block; the `onclick` HTML attribute should NOT be flagged)
  - `same-line-forgiveness.js`: `el.innerHTML = trustedHTML('<x/>');`
  - `next-line-forgiveness.js`: two-line split `el.innerHTML =\n  trustedHTML('<x/>');`

- **New: `tests/e2e/journey-trusted-types.spec.ts`** — Playwright test (TypeScript, follows `journey-*.spec.ts` naming convention; lives in `tests/e2e/`, NOT `tests/playwright/`). Three test cases:
  1. **Default-policy reporter test:** load `/`, force a `default`-policy invocation via `page.evaluate(() => { const d = document.createElement('div'); d.innerHTML = '<i>force-default</i>'; })`, then `await page.waitForRequest(req => req.url().endsWith('/v1/telemetry/client-error'), { timeout: 2000 })` and assert the body contains `"type":"trusted_types_violation"`.
  2. **Console-clean dashboard load:** load `/`, capture `page.on('console', ...)` events, navigate `/auth.html`, `/setup.html`, `/verify.html`, assert zero `[Finlet] Trusted Types default policy invoked` messages and zero `Refused to create a TrustedTypePolicy` errors.
  3. **CSP-violation listener test:** load `/`, dispatch a synthetic `securitypolicyviolation` event with `effectiveDirective: 'trusted-types'` via `page.evaluate`, assert the same `/v1/telemetry/client-error` POST lands within 2 seconds. Use `storageState: undefined` for case 2's `/auth.html` portion (pre-auth page — the chromium project's default `storageState: 'tests/e2e/.auth/session.json'` would redirect the test through auth).

**Deliverable:** A single merged commit on `main` that:
1. Broadens the trusted-types lint to scan `.html` files (inside `<script>` blocks, case-insensitive) and to cover four additional DOM HTML sinks beyond `innerHTML` (`outerHTML`, `insertAdjacentHTML`, `document.write`, `createContextualFragment`).
2. Wraps the eight previously-unwrapped sites in `verify.html` (4 sites at lines 101, 120, 126, 133) and `setup.html` (4 sites at lines 397, 401, 415, 418) so the broadened lint passes on a clean tree.
3. Wires production telemetry for runtime Trusted Types violations via the existing `/v1/telemetry/client-error` endpoint (sendBeacon, rate-limited server-side).
4. Documents the broader convention in `dashboard/event-contract.md`.
5. Ships a bash-driven lint unit test + a Playwright spec asserting the new telemetry path.

**Validation:** (commands the agent MUST run and pass before declaring done)

- [ ] `bash scripts/lint-trusted-types.sh` — exits 0 on the post-refactor tree (sweep over real `dashboard/` after the eight wraps land).
- [ ] `bash tests/dashboard/lint-trusted-types.spec.sh` — all six fixture cases pass.
- [ ] **Pre-commit hook regression test:** run `bash scripts/setup-git-hooks.sh && cp dashboard/app.js /tmp/app.js.bak && printf '\nel.outerHTML = "<x/>";\n' >> dashboard/app.js && (git commit -am "should-be-blocked" 2>&1 | grep -i 'bare HTML-sink' && echo "blocked OK") && cp /tmp/app.js.bak dashboard/app.js`. Confirms the broadened lint blocks via the existing pre-commit hook.
- [ ] `uv run pytest tests/api/ -k "csp or telemetry or client_error" -x -q` — existing CSP and telemetry tests still pass.
- [ ] `cd tests/e2e && npx playwright test journey-trusted-types.spec.ts --project=chromium` — passes (assumes the dev server is running on `localhost:8000`).
- [ ] `cd tests/e2e && npx playwright test --project=chromium` — full journey suite still passes (no regressions from the verify.html/setup.html wraps or the `api-utils.js` reporter additions).
- [ ] **Manual smoke:** load `https://finlet.dev` (or `http://localhost:8000`) on a Chromium browser with DevTools open. Navigate `/`, `/auth.html`, `/setup.html`, `/verify.html`. Click the "Sign in with Google" button on `/auth.html`. Confirm: zero `[Finlet] Trusted Types default policy invoked` warnings, zero `Refused to create a TrustedTypePolicy` errors. Confirm at least one POST to `/v1/telemetry/client-error` if you intentionally fire a default-policy invocation from the DevTools console.
- [ ] `git diff --stat` shows changes confined to the eight-file set in this plan; no surprise file modifications.

**Agent instructions:**

- **You MUST `git add` and `git commit` the eight modified/new files before finishing.** Worktree contents are discarded if uncommitted. **This is the #1 failure mode.**
- **Commit message:** `refactor(trusted-types): broaden lint coverage + wrap inline-script sinks + wire violation telemetry` followed by a one-paragraph body referencing `docs/bug-hunt/refactor-queue/trusted-types.md` and listing the three coordinated changes.
- **Read the refactor doc top-to-bottom before writing any code.** Do not shortcut. The Why/Root-cause sections explain why each piece must land together.
- **Use the existing `trustedHTML(...)` wrap exactly as shown in `dashboard/agent-guide.html:450, 454, 468, 471`** — do NOT introduce a new helper. Do NOT modify `trustedHTML()` itself at `api-utils.js:469`.
- **The lint awk state-machine for HTML scoping must live INSIDE the existing scanner loop** — do NOT add a parallel scanner. Toggle `in_script` based on `<script`/`</script>` tags (case-insensitive). For `*.js` files, `in_script` defaults to `1`. Preserve the existing same-line / next-line `trustedHTML(` forgiveness rules.
- **The reporter calls in the policy callbacks MUST be wrapped in try/catch.** A telemetry failure must NEVER block page render. The existing `reportClientError` at `api-utils.js:386` already has internal try/catch, but a defense-in-depth wrap is required.
- **Before declaring done, run `bash scripts/lint-trusted-types.sh` against the real `dashboard/` tree** to confirm the eight wraps are actually correct AND no other unwrapped sites surfaced that the recon missed. If new sites surface, ADD wraps for them and re-run. Do NOT declare done with a non-zero exit.
- **DO NOT modify the CSP header** in `finlet/api/security_middleware.py`. Out of scope.
- **DO NOT replace the vendored `dashboard/vendor/lightweight-charts.standalone.production.js`.** Keep the existing `// trusted-types-vendor-allowlist` marker.
- **DO NOT touch the `esc()` helper or any user-data sanitization paths.** Out of scope.
- **DO NOT modify `dashboard/agent-guide.html`** — already correctly wrapped, used as the precedent template only.
- **The Playwright spec is `.ts` (TypeScript), not `.js`.** Look at `tests/e2e/journey-04-dashboard.spec.ts` for the project's idiomatic spec shape before writing the new one.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Broadened lint surfaces sites OUTSIDE `verify.html`/`setup.html` that the recon missed | Medium | Medium | Run `bash scripts/lint-trusted-types.sh` on the unmodified-but-broadened-lint tree first to enumerate ALL surfaced sites. Add wraps for any new sites before declaring scope. The plan's eight-file ceiling has slack only if no new sites surface. |
| New `securitypolicyviolation` listener fires on benign third-party policy creation events (e.g., Sentry, Google SSO) | Low | Low | Filter on `e.effectiveDirective === 'trusted-types'` AND known-good policy names — `goog#html` is in the CSP allowlist; the listener should NOT report on `effectiveDirective === 'script-src'` or other non-TT directives. Filter is one line in the listener. |
| Telemetry endpoint rate-limits the reporter on dashboard load (server-side `_CLIENT_SECURITY_RATE_LIMIT = 20/60s` per IP) | Low | Low | Use `sendBeacon` (already in `reportClientError` at `api-utils.js:398`) — fire-and-forget, browser handles backoff. The existing endpoint at `routes_csp.py:67-84` already drops malformed reports silently. |
| Awk state-machine mishandles edge cases: `<script type="module">`, self-closing `<script src="..."></script>` (no body), `<script>` blocks containing literal `</` strings | Medium | Medium | Fixture-driven test cases for `<script type="module">`, `<script src="..."></script>` (skip-no-body), and `<script>` blocks containing literal `'</'` strings inside template literals. Add at least one fixture per edge case to `_fixtures/`. The case-insensitive tag match must be anchored: `match $0 against /<script[^>]*>/` for open, `</script>/` for close. |
| The `find` glob change accidentally scans node_modules or vendored paths | Low | Medium | Confirm `DASH_DIR="$REPO_ROOT/dashboard"` excludes `node_modules` (it does — `dashboard/` does not contain a node_modules subdir per `find $DASH_DIR -type d -name node_modules` returning empty). Add explicit `-not -path '*/node_modules/*'` and `-not -path '*/vendor/*'` filters as defense-in-depth. The vendor allowlist marker check at line 93 also independently skips vendored files. |
| Playwright CI doesn't have an OAuth-real Google SSO so the "no `Refused to create a TrustedTypePolicy` errors" assertion can't exercise SSO interaction | Medium | Low | The CSP header is enforced by the document, not by the SSO interaction — the `auth.html` static load alone is enough to trigger Google's policy creation if it's bundled in. The SSO click is a soft assertion (skip if no network), not blocking. The default-policy reporter test (case 1) does NOT depend on SSO and is the primary signal. |
| `tests/dashboard/lint-trusted-types.spec.sh` overrides `DASH_DIR` via env var but the script today resolves it from script-location (`SCRIPT_DIR=$(...)`) — the override won't take | High | Medium | Test driver uses approach (b) from the plan — copy `scripts/lint-trusted-types.sh` to a temp tree, set up `<temp>/dashboard/` with fixtures, and run from there. The script's `REPO_ROOT="$SCRIPT_DIR/.."` resolution will then correctly target the temp dashboard. Avoids modifying the script for testability. |
| Worktree commit forgotten — work is lost | Low | Critical | Explicit instruction to `git add` + `git commit` is repeated in the agent-instructions section AND in the deliverable section. The validation gate's `git diff --stat` step requires the changes to be on disk. |

## Session Plan

### Session 1

- **Sequential:** Team A only — single team, no parallelism.
- **Merge order:** Team A merges directly to `main` after passing all validation gates listed above.
- **Per-merge gate:** the seven validation commands above MUST pass BEFORE merge. Any failure blocks the merge until fixed.
- **Session checkpoint (post-merge on main):** run the full Python test suite (`uv run pytest -x -q`) and the full Playwright sweep (`cd tests/e2e && npx playwright test --project=chromium`) on `main` after the Team A commit lands. Catches integration regressions that the per-merge gate missed.
- **Rollback path:** single SHA. `git revert <sha>` is mechanical — wraps are identity-in-browser, lint changes are ~30 LOC of awk + glob, reporter additions are ~25 LOC. Total revert is ~15 minutes if the convention turns out to be wrong. The named-policy + lint baseline that exists today remains intact under revert.

## Status — 2026-04-30

- **Team A:** COMPLETED. Worker commit `5686b0e7`, merged to main as `bbbf7cc3`.
- **Per-merge gate (on main):** PASS — lint sweep clean (0 sites), 6/6 fixture cases, pytest csp/telemetry/client_error 31/31 in 4.69s.
- **Session checkpoint:** PASS — full pytest sweep `uv run pytest tests/ --ignore=tests/e2e` returned **3902 passed, 0 failed in 569.64s** — exact match to pre-flight baseline, no regressions. Playwright static parse green (128 tests across 20 files compile, including 3 new `journey-trusted-types.spec.ts` cases). Full Playwright sweep deferred — dev server not running locally; the spec is parse-clean and will run on next CI/dev-server invocation.
- **Surprises during execution:** worker added a `<script src="api-utils.js">` tag to `dashboard/setup.html` (was missing — `trustedHTML()` helper unavailable otherwise). Within scope; flagged in the merge commit body.
