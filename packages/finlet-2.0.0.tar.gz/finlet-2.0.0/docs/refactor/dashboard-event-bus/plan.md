# Dashboard Event Bus Refactor — Execution Plan

> Generated from `docs/bug-hunt/POST_MORTEM_2026-04-28.md`. Last updated: 2026-04-28
>
> Source recurrence data: `docs/bug-hunt/ledger.jsonl` — 14 real-broken patches across two iterations, 10 of 14 (71%) clustered in onboarding-checklist / dashboard-state-sync / trusted-types categories.

## Constraints

**Hard constraints (from post-mortem):**
- No expansion of v1 scope. This is pure dashboard plumbing — no new product surface.
- Reversal must be possible via single merge-commit revert. The bus module is one file; consumer migrations are mechanical.
- The orchestrator does NOT re-litigate the refactor decision. The recurrence data justifies it.

**Discovered constraints (from recon):**
- **All 71 `.innerHTML =` write sites under `dashboard/` are already wrapped via `trustedHTML()`** (per `grep -r "\.innerHTML\s*=" dashboard --include="*.js" | grep -v vendor`). The lint guard in Team C is **preventative**, not retroactive. Goal: stop the *next* bare innerHTML from landing.
- **Only one `dispatchEvent(new CustomEvent(` site exists** (`dashboard/app.js:1416`) — single broadcast point, easy to redirect.
- **Only one `addEventListener('finlet:` consumer exists** (`dashboard/trade-ticket.js:138`) — Team C's surface is small.
- **No checklist rows currently in `dashboard/index.html`.** The four onboarding steps (`profile`, `session`, `analysis`, `strategy`) live inside the wizard modal at `dashboard/onboarding.js:145` (`overlay.innerHTML = trustedHTML(buildWizardHTML())`). Team B must decide whether to surface a persistent dashboard checklist or refactor the modal-internal step machine in place. **Default: refactor in place; do not add a new dashboard surface.** This keeps blast radius bounded.
- **Onboarding `strategy` step is dangling** — referenced at `onboarding.js:631`/`L642` but has no `state.steps.strategy` entry. Team B's state machine must either complete it or explicitly leave it as a no-op step with a TODO link to a follow-up.
- **No ESLint, no pre-commit hooks, no JS lint gate in CI.** Team C must establish JS lint infrastructure from scratch — choose grep-based pre-commit hook (lower setup cost) over full ESLint config unless ESLint is already pending elsewhere.
- **`dashboard/vendor/lightweight-charts.standalone.production.js` has no existing IIFE patch.** The post-mortem says "keeps its IIFE patch" — there is nothing to keep. Team C just adds the allowlist marker and lets the vendor file pass-through.
- Test infra: Playwright at `tests/e2e/playwright.config.ts`, sequential, 1 worker, 60s timeout. `journey-05-trade.spec.ts` covers Trade Ticket open/close but does NOT verify event propagation. No onboarding journey exists yet.

## File Conflict Table

| File | Touched by Teams | Notes |
|------|------------------|-------|
| `dashboard/event-bus.js` | A (new) | Foundation — must merge first |
| `dashboard/event-contract.md` | A (new) | Documentation companion to event-bus.js |
| `dashboard/app.js` | A | Replace `dispatchEvent` and `markStepComplete` reach-in with `bus.publish` |
| `dashboard/onboarding.js` | B | Step machine subscribes to bus events |
| `dashboard/index.html` | B | Add `data-trigger-event` attributes IF Team B surfaces a dashboard checklist; otherwise no change |
| `dashboard/trade-ticket.js` | C | Replace SSE add/remove dance with `bus.subscribe` + unsubscribe |
| `dashboard/api-utils.js` | C | No code change; reference target for the lint guard's allowlist comment |
| `.husky/pre-commit` or `scripts/lint-trusted-types.sh` | C (new) | Trusted-types pre-commit guard |
| `tests/e2e/journey-onboarding.spec.ts` | B (new) | Playwright validation for Team B |
| `tests/e2e/journey-05-trade.spec.ts` | C | Append cash-header drop assertion |
| `dashboard/event-bus.test.js` or `tests/dashboard/event-bus.spec.js` | A (new) | Unit tests for publish/subscribe |

**No shared files between Teams B and C.** Teams B and C can run in fully parallel worktrees after Team A merges.

## Dependency Graph

- **Team A** (independent) — can start immediately. Produces `event-bus.js` + contract doc + migrated `app.js`.
- **Team B** (blocked by A) — imports the bus to subscribe checklist steps to events.
- **Team C** (blocked by A) — imports the bus to subscribe Trade Ticket cash header to `portfolio:updated`.

## Critical Path

**Team A → (Team B ∥ Team C)**

Team A is the only sequential bottleneck. Once A merges, B and C run fully parallel — they share zero files.

Estimated wall-clock: 2.5–3.5h for A, then 2–3h for B/C in parallel = **~5–6.5h total agent time**.

---

## Teams

### Team A: Event Bus Convention + app.js Migration

**Blocked by:** none — can start immediately

**Read these files first:**
- `dashboard/app.js:1380` — current `EventSource` init for SSE; the bus's only legitimate inbound is here
- `dashboard/app.js:1416` — current `dispatchEvent(new CustomEvent('finlet:portfolio-update', detail))` site; replace with `bus.publish('portfolio:updated', detail)`
- `dashboard/app.js:1438-1465` — orders SSE handler block; the `markStepComplete('analysis')` reach-in at L1460-1461 is what bus subscriptions will replace (Team B consumes; Team A just emits)
- `dashboard/api-utils.js:469` — existing `trustedHTML()` wrapper; cite as the canonical pattern in the contract doc
- `docs/bug-hunt/POST_MORTEM_2026-04-28.md` — full motivation; the contract doc should reference this
- `dashboard/onboarding.js:708-712` — `markStepComplete()` definition; understand what payload Team B will need on `onboarding:step-completed`

**Files touched:**
- New: `dashboard/event-bus.js` — exports `bus` singleton with `subscribe(event, handler) → unsubscribe` and `publish(event, payload)`. Backed by `Map<event, Set<handler>>`. Expose only `window.finletBus` for hot-path consumers; do NOT leak `subscribe` / `publish` as bare globals. Subscriber errors are caught and `console.error`'d so one bad subscriber doesn't break the chain.
- New: `dashboard/event-contract.md` — enumerate every event name, payload shape, publisher, subscribers. Required initial events (extend as Team B/C land):
  - `portfolio:updated` — payload: full portfolio detail object from SSE; publisher: `app.js` SSE handler; subscribers: trade-ticket cash header (Team C), dashboard metrics (Team C extends).
  - `order:filled` — payload: `{ ticker, quantity, side, fill_price }`; publisher: `app.js` orders SSE handler; subscribers: onboarding `analysis` step (Team B).
  - `session:switched` — payload: `{ session_id }`; publisher: `app.js`; subscribers: TBD by Team B/C.
  - `onboarding:step-completed` — payload: `{ step }`; publisher: `onboarding.js` (Team B owns); subscribers: any analytics surface.
- New: `tests/dashboard/event-bus.spec.js` (or co-located `dashboard/event-bus.test.js` — match existing repo convention discovered by recon; if no convention exists, place under `tests/dashboard/`). Cover: subscribe receives published events, unsubscribe stops delivery, multiple subscribers all fire, throwing subscriber doesn't break sibling subscribers, publish with no subscribers is a no-op.
- Modified: `dashboard/app.js`
  - L1416: replace `window.dispatchEvent(new CustomEvent('finlet:portfolio-update', { detail }))` with `window.finletBus.publish('portfolio:updated', detail)`.
  - L1460-1461: replace `window.finletOnboarding?.markStepComplete?.('analysis')` reach-in with `window.finletBus.publish('order:filled', { /* fill detail */ })`. Team B's onboarding subscriber will call `markStepComplete('analysis')` itself.
  - Other 3 `window.finletOnboarding` references at L1334-1335: leave for Team B to migrate (those are inside onboarding.js territory or B's call sites).
- Modified: `dashboard/index.html` — add `<script src="event-bus.js"></script>` BEFORE `app.js` and `onboarding.js` and `trade-ticket.js`. Verify no cache-busting query string conventions break.

**Deliverable:** Every dashboard mutation publishes one event via `window.finletBus`. The single `dispatchEvent` site at `app.js:1416` is gone. The single `markStepComplete` reach-in at `app.js:1460-1461` is gone. `event-contract.md` documents the four initial event shapes. Unit tests prove pub/sub semantics.

**Validation:**
- [ ] `grep -rn "dispatchEvent(new CustomEvent" dashboard --include="*.js"` returns ZERO matches
- [ ] `grep -rn "window\.finletOnboarding" dashboard/app.js` returns ZERO matches in app.js (4 of 5 callsites removed; `onboarding.js:755-756` definition stays)
- [ ] `grep -rn "window\.finletBus" dashboard --include="*.js"` returns ≥2 matches (publish in app.js, exposure in event-bus.js)
- [ ] Unit tests pass: `node --test tests/dashboard/event-bus.spec.js` (or repo-equivalent invocation; if Vitest/Jest is added, document in test file's header comment)
- [ ] Manual: open dashboard, submit BUY 1 AAPL, verify in DevTools console: `window.finletBus.subscribe('portfolio:updated', console.log)` registered before order, then logged once on fill
- [ ] No new console errors / Trusted Types violations introduced (open dashboard, navigate all top-level pages)

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Worktree contents are lost on cleanup if uncommitted.
- Follow the existing module pattern in `dashboard/api-utils.js` (IIFE or top-level script — match the file you're co-locating with).
- Keep the bus module under 100 LOC. It is intentionally minimal.
- Do NOT use ES modules unless `dashboard/index.html` already loads scripts as `type="module"`. Recon report didn't find module loading; default to plain script tag.
- The contract doc is mandatory — Teams B and C cannot start without it. Make sure it lists payload shapes precisely.
- Commit message: `feat(dashboard): event bus convention + app.js migration to bus.publish`

---

### Team B: Onboarding State Machine on Bus

**Blocked by:** Team A merges to main (needs `event-bus.js` + contract)

**Read these files first:**
- `docs/refactor/dashboard-event-bus/plan.md` — this plan
- `dashboard/event-contract.md` — Team A's output; the events you can subscribe to
- `dashboard/event-bus.js` — Team A's output; how to call `subscribe`
- `dashboard/onboarding.js` (full file, 759 LOC) — current state. Pay particular attention to:
  - L105: `profile` step
  - L488, L530: `analysis` step references
  - L631, L642: `strategy` step references (NOTE: dangling — no `state.steps.strategy` entry)
  - L708-720: `markStepComplete(stepKey)` definition and state mutation
  - L721: `session` step (auto-advance)
  - L745-757: `window.finletOnboarding` exposure surface
- `dashboard/app.js:1334-1335` — remaining `window.finletOnboarding` reach-in callsites Team A left for you to migrate
- `dashboard/index.html` — current onboarding markup; modal-overlay only, NO persistent checklist rows. **Decision: refactor in place, do NOT add new dashboard surface.** If you disagree after reading the file, surface to user before proceeding.
- `docs/bug-hunt/POST_MORTEM_2026-04-28.md` — Team 2 section, especially the leaderboard-modal regression note

**Files touched:**
- Modified: `dashboard/onboarding.js`
  - Add a `STEP_TRIGGERS` table at module top: `{ profile: null /* manual */, session: null /* manual */, analysis: 'order:filled', strategy: TBD }`. The `null` values mean the step is advanced by direct UI action (existing flow), not by a bus event. Document `strategy` resolution: either wire it to a real event (e.g., `strategy:saved`) and add the missing `state.steps.strategy` entry, or document explicitly why it's intentionally manual.
  - At module init, iterate `STEP_TRIGGERS`. For each `event ≠ null`, call `window.finletBus.subscribe(event, () => markStepComplete(stepKey))`.
  - After `markStepComplete(stepKey)`, publish `onboarding:step-completed` with `{ step: stepKey }`.
  - Remove any code path where `app.js` calls `markStepComplete` directly. The orders SSE → analysis-step path now flows: `app.js` publishes `order:filled` → `onboarding.js` subscriber → `markStepComplete('analysis')` → publishes `onboarding:step-completed`.
  - Migrate the remaining `window.finletOnboarding` reach-ins from `app.js:1334-1335` to bus events. If those callsites are doing something the bus events above don't cover, define a new event in collaboration with the contract doc (update the doc).
- Modified: `dashboard/index.html` — only if Team B chooses to add persistent checklist rows. Default: NO change. If added, each row gets `data-trigger-event="<event-name>"` and the state machine wires them at boot. Document the decision in your commit message.
- New: `tests/e2e/journey-onboarding.spec.ts` — Playwright test:
  1. Fresh user, open dashboard.
  2. Assert checklist (or modal step indicator, depending on Team B's surface decision) shows step 2/4 after profile + session auto-advance complete.
  3. Submit BUY 10 AAPL via `/api/orders`. Wait for SSE.
  4. Assert checklist shows 3/4 within 2s of order fill notification.
  5. Assert NO `leaderboard` modal opens (regression guard from post-mortem).

**Deliverable:** Adding a new checklist step requires only declaring its trigger event in `STEP_TRIGGERS`. No bespoke per-row click wiring. The leaderboard-modal-on-wrong-row regression is structurally impossible because rows declare their target. `app.js` no longer reaches into onboarding.

**Validation:**
- [ ] `grep -rn "window\.finletOnboarding" dashboard/app.js` returns ZERO matches (Team A removed L1460-1461; you remove L1334-1335)
- [ ] `grep -rn "markStepComplete" dashboard/app.js` returns ZERO matches
- [ ] `grep -rn "STEP_TRIGGERS" dashboard/onboarding.js` returns ≥1 match
- [ ] `grep -rn "bus\.subscribe" dashboard/onboarding.js` returns ≥1 match (one per event-driven step)
- [ ] Playwright passes: `npx playwright test tests/e2e/journey-onboarding.spec.ts`
- [ ] Existing `journey-05-trade.spec.ts` still passes
- [ ] Manual: complete onboarding flow end-to-end; verify counter advances correctly at each step

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Use Team A's bus, do NOT define a parallel event mechanism.
- The dangling `strategy` step is YOUR decision: complete it OR mark it explicitly with a `// TODO(post-launch): strategy step pending product spec` comment AND update `event-contract.md` to reflect reality. Do not silently skip it.
- Match existing onboarding.js code style (vanilla JS, no ESM unless already in use).
- If you must add markup to `index.html`, justify the addition in your commit message AND update the contract doc.
- Commit message: `feat(dashboard): onboarding state machine on event bus`

---

### Team C: Trade Ticket on Bus + Trusted Types CI Guard

**Blocked by:** Team A merges to main (needs `event-bus.js` + contract)

**Read these files first:**
- `docs/refactor/dashboard-event-bus/plan.md` — this plan
- `dashboard/event-contract.md` — Team A's output
- `dashboard/event-bus.js` — Team A's output
- `dashboard/trade-ticket.js` (full file, 351 LOC) — current state. Pay particular attention to:
  - L12: `let tradeTicketPortfolioHandler = null` (module-scoped handler ref — replace with bus unsubscribe closure)
  - L16: `let tradeTicketCashSessionId = null` (invalidation hack — DELETE; bus delivers fresh state each publish)
  - L137-138: `addEventListener('finlet:portfolio-update', tradeTicketPortfolioHandler)` (replace with `bus.subscribe('portfolio:updated', ...)`)
  - L171-173: `removeEventListener(...)` on close (replace with calling the unsubscribe closure)
  - L182-193: `handlePortfolioUpdateForTicket(event)` handler — keep the body, swap the wrapping
- `dashboard/api-utils.js:469` — `trustedHTML()` wrapper (the lint guard's required wrap target)
- `dashboard/vendor/lightweight-charts.standalone.production.js` — vendor file; will need an explicit allowlist marker. NO existing IIFE patch — do not invent one.
- `tests/e2e/journey-05-trade.spec.ts` (244 LOC) — extend with cash-header drop assertion
- `docs/bug-hunt/POST_MORTEM_2026-04-28.md` — Team 3 section

**Files touched:**
- Modified: `dashboard/trade-ticket.js`
  - Replace L12 module-scoped `tradeTicketPortfolioHandler` with a closure-captured `unsubscribe` ref scoped to the open/close lifecycle.
  - DELETE L16 `tradeTicketCashSessionId` and any usages — the bus delivers fresh state per publish; invalidation guard is no longer needed.
  - On open (replacing L137-138): `unsubscribe = window.finletBus.subscribe('portfolio:updated', handlePortfolioUpdateForTicket)`.
  - On close (replacing L171-173): `unsubscribe?.(); unsubscribe = null`.
  - Keep `handlePortfolioUpdateForTicket` body — it already mutates `cashDisplay.textContent` correctly. Just adjust signature: it now receives the payload directly (not `event.detail`), since `bus.publish('portfolio:updated', detail)` passes payload as first arg.
- New: `scripts/lint-trusted-types.sh` — bash script. Greps `dashboard/` for `\.innerHTML\s*=` write sites. Excludes:
  - Any line containing `trustedHTML(` on the same line or the line above (multi-line `trustedHTML(\n...)` allowed)
  - Files containing the marker `// trusted-types-vendor-allowlist`
  - Specific path: `dashboard/vendor/lightweight-charts.standalone.production.js`
  - The lint guard implementation file itself
  - Returns exit code 1 with a clear error message listing offending file:line if any non-allowlisted bare innerHTML write is found.
- Modified: `dashboard/vendor/lightweight-charts.standalone.production.js` — prepend a single-line comment at the top: `// trusted-types-vendor-allowlist - see scripts/lint-trusted-types.sh`. No code modification.
- New: `.husky/pre-commit` (if husky is acceptable; otherwise: instructions in `scripts/lint-trusted-types.sh` header for manual install OR a simpler `git/hooks/pre-commit` checked into `scripts/git-hooks/pre-commit` with a setup script). Run `scripts/lint-trusted-types.sh` and block commit if it fails.
- Modified: `tests/e2e/journey-05-trade.spec.ts` — append a test:
  1. Open Trade Ticket panel.
  2. Capture initial "Available Cash" value.
  3. Submit a fill (BUY 1 AAPL @ market).
  4. Wait up to 2s for SSE → bus → handler.
  5. Assert "Available Cash" value decreased by approximately the fill cost (allow tolerance for slippage).
- Modified (lint smoke test): a temporary deliberately-broken commit on a throwaway branch should be tested to verify the pre-commit blocks it. **DO NOT push or merge that test commit.** Document the verification in your commit message.

**Deliverable:** Trade Ticket cash header always reflects fresh portfolio state, no module-scoped handler refs, no session-id invalidation hack. The next bare `.innerHTML =` insertion to `dashboard/` (excluding allowlisted vendor) is blocked at pre-commit time.

**Validation:**
- [ ] `grep -rn "tradeTicketPortfolioHandler" dashboard/` returns ZERO matches
- [ ] `grep -rn "tradeTicketCashSessionId" dashboard/` returns ZERO matches
- [ ] `grep -rn "addEventListener('finlet:" dashboard/` returns ZERO matches
- [ ] `grep -rn "bus\.subscribe" dashboard/trade-ticket.js` returns ≥1 match
- [ ] `bash scripts/lint-trusted-types.sh` exits 0 on current tree
- [ ] Smoke test: insert a bare `.innerHTML = '<div>x</div>'` into `dashboard/app.js` on a scratch branch, run the lint script, verify it exits 1 with a useful error. Then revert. Document this verification in commit message.
- [ ] Playwright passes: `npx playwright test tests/e2e/journey-05-trade.spec.ts`
- [ ] No existing tests broken: `npx playwright test --config tests/e2e/playwright.config.ts`

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Use Team A's bus, do NOT define a parallel mechanism.
- Choose grep-based pre-commit hook over ESLint config — recon found NO existing ESLint setup, and pulling ESLint in for a single rule is over-investment.
- Vendor file gets ONLY the marker comment; do NOT modify minified content.
- If husky / pre-commit infra already exists in repo (re-verify, recon found none), wire into it. Otherwise, leave a clear setup instruction in the lint script header.
- Commit message: `feat(dashboard): trade-ticket on event bus + trusted-types pre-commit guard`

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A's bus introduces error masking — a thrown subscriber kills sibling subscribers | Medium | High | Bus must `try/catch` around each handler call and `console.error` — covered in Team A spec, validated by unit test |
| Team B subscribes to `order:filled` before Team A's bus is loaded (script-tag ordering) | Medium | Medium | Team A's spec mandates `<script src="event-bus.js">` BEFORE `app.js` / `onboarding.js` / `trade-ticket.js` in `index.html`. Team B re-verifies on entry. |
| Onboarding `strategy` dangling step crashes the state machine | Medium | Medium | Team B explicitly handles or TODOs the dangling step. Validation grep confirms `STEP_TRIGGERS` covers all step keys referenced. |
| Pre-commit hook requires manual install — devs forget, drift returns | High | Medium | Team C documents a one-shot install script (`scripts/setup-git-hooks.sh`) and adds a CI check that runs the same lint on PRs as a backstop. |
| Vendor file allowlist is too broad — a future legit-bug-in-vendor goes undetected | Low | Low | Vendor allowlist is path-anchored to specific file, not a wildcard. Re-evaluate if vendor is updated. |
| Bus `Map<event, Set<handler>>` retains references after consumer DOM is gone — memory leak | Low | Low | Trade Ticket pattern (subscribe on open, unsubscribe on close) is the documented norm in `event-contract.md`. Long-lived subscribers (onboarding) are intentional. |
| Playwright onboarding test is flaky on SSE timing | Medium | Medium | Use `expect.poll(...).toBe(...)` with 2s timeout, not bare `waitForTimeout`. Team B follows existing journey-05 patterns. |
| Refactor regresses an unrelated dashboard surface (e.g., metrics page) | Medium | High | Each team runs full Playwright suite as part of validation, not just their targeted journey. |
| Team B decides to add persistent checklist HTML; scope balloons | Medium | Medium | Default explicitly stated: refactor in place. If Team B disagrees, surface to user before proceeding (codified in agent instructions). |

## Session Plan

### Session 1 — Foundation
**Sequential (only one team):** Team A
**Merge order:** A merges → targeted tests on main (`node --test tests/dashboard/event-bus.spec.js` + manual dashboard smoke) → Session 1 complete
**Session checkpoint:** `npx playwright test --config tests/e2e/playwright.config.ts` (full suite — must be green; this is the baseline before parallel work)

### Session 2 — Parallel Consumers
**Parallel (no shared files):** Teams B and C in independent worktrees
**Merge order:** Whichever finishes first merges first → targeted journey test on main → second merges → second targeted journey test on main → Session 2 complete
**Session checkpoint:** Full Playwright suite green. `grep -rn "dispatchEvent(new CustomEvent" dashboard/` → 0. `grep -rn "addEventListener('finlet:" dashboard/` → 0. `grep -rn "window\.finletOnboarding" dashboard/app.js` → 0.

**Total estimated wall-clock:** Session 1 (2.5–3.5h) + Session 2 (2–3h, parallel) = **~5–6.5h agent time**.

## Reversal Path

If the refactored bus produces worse bugs than the bespoke wiring, revert via merge commits in reverse order:
1. Revert Session 2 merges (Teams B and C) — restores bespoke wiring on those surfaces
2. Revert Session 1 merge (Team A) — removes the bus module and contract

Each revert is a single `git revert -m 1 <merge-commit>`. Total rollback: 30 minutes.

The bus module is one file; consumer migrations are mechanical. No data migrations, no schema changes, no external API changes — just JS in `dashboard/`.

---

## Quality Checklist (verified before delivery)

- [x] Every team has "Read these files first" with explicit line numbers
- [x] Every team has "You MUST git add + git commit" in agent instructions
- [x] Every team has specific validation commands (named greps, named test invocations)
- [x] File conflict table accounts for all shared files (zero shared between B and C — full parallelism)
- [x] No team touches >8 files (A: 5, B: 3, C: 6)
- [x] Dependencies match the file conflict table (A blocks B and C; B and C are independent)
- [x] Critical path is the longest chain (A → max(B, C); A is the only sequential bottleneck)
- [x] Session grouping respects all dependency constraints (Session 1 = A; Session 2 = B ∥ C)
- [x] All numeric claims grep-verified by recon agent (`.innerHTML =` count: 71; `dispatchEvent(new CustomEvent(`: 1; `addEventListener('finlet:`: 1; `markStepComplete` callsites: 13; ESLint: 0)

---

## Status — COMPLETED 2026-04-28

All three teams merged to `main` and validated.

| Team | Commit | Merge commit |
|------|--------|--------------|
| A: Event bus + app.js | `ac08c5e` | `631d1b1` |
| C: Trade-ticket on bus + lint guard | `aba36c2` | `c0d8edb` |
| B: Onboarding state machine | `7085ea7` | `798904c` |

**Final invariants on main:**
- `dispatchEvent(new CustomEvent` in `dashboard/`: 0
- `addEventListener('finlet:` in `dashboard/`: 0
- `window.finletOnboarding` in `dashboard/app.js`: 0
- `tradeTicketPortfolioHandler` / `tradeTicketCashSessionId`: 0 / 0
- `finletBus` refs in `dashboard/`: 23
- Pytest: 3883 passed, 0 failed (baseline match)
- Trusted-types lint: 0 violations on clean tree, blocks injected `.innerHTML =` at pre-commit

**Outstanding follow-ups (filed in `docs/REMAINING_TASKS.md`):**
- `STEP_TRIGGERS.strategy = null` until strategy product surface ships
- `pytest-timeout` not in `pyproject.toml` `[dependency-groups.dev]` (manual install needed in fresh envs)
