# Close patch-ineffective signals 2026-05-02 — Execution Plan

> Generated from `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md`. Last updated: 2026-05-02.

## Constraints

- **Team A MUST run a verification probe against `main` BEFORE any code change.** The original Signal 1 retest measured `deploy_sha=13af780d` (a docs commit), which predates the plugin-config-propagation refactor (`57ae3fe` + `fc58c4d` + `ab1f438`) now on `main`. If the retest envelope shows EDGAR `healthy` on `main`, Team A skips the `update_plugin` / `registry.reload` changes entirely and ships only the `plugins remove` CLI subcommand + tests. If EDGAR is still `unhealthy`, Team A files a fresh root-cause investigation before patching.
- All Validation subsections in this plan are reusable verbatim by the next bug-hunt iteration's Phase 5.5 retest envelope.
- File ownership is enforced per `.claude/rules/file-ownership.md`. Teams MUST stay within their owned paths.
- Each team commits its own work (`git add` + `git commit`) before signaling done. No team merges another's branch.
- Signal 2 and Signal 3 share zero dashboard files — they MUST run as independent worktrees, not coupled in a single worktree.
- `display: none` change in Signal 3 removes the slide-up transition; this is a deliberate UX trade (animation was hiding a bug).
- `else { markStepComplete('profile'); }` deletion in Signal 2 does NOT change wizard visibility for existing users — wizard gate is unchanged. Only the auto-tick is removed.

## File Conflict Table

| File | Touched by Teams |
|------|-----------------|
| `finlet/cli.py` | Team A only |
| `finlet/api/services/settings_service.py` | Team A only (docstring) |
| `tests/test_cli.py` | Team A only |
| `tests/api/test_routes_settings.py` | Team A only |
| `dashboard/onboarding.js` | Team B only |
| `tests/dashboard/onboarding-checklist.spec.js` | Team B only |
| `tests/playwright/onboarding-end-to-end.spec.js` | Team B only |
| `dashboard/settings.css` | Team C only |
| `dashboard/settings.html` | Team C only (comment-only) |
| `dashboard/form-dirty-tracker.js` | Team C only (JSDoc-only) |
| `tests/playwright/settings-dirty-banner.spec.js` | Team C only |

Zero overlaps across teams. All three teams can run in fully isolated worktrees.

## Dependency Graph

- Team A — independent (api / plugins / cli)
- Team B — independent (dashboard onboarding)
- Team C — independent (dashboard settings dirty banner)

## Critical Path

All teams parallel; no critical chain. The longest single team (Team A, ~1-2h including verification probe) sets the wall-clock floor.

---

## Teams

### Team A: Edgar Plugin Re-Probe + `plugins remove` CLI

**Blocked by:** none — independent

**Read these files first:**
- `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md` — Signal 1 section (lines 39-235)
- `finlet/cli.py:226-303` (`plugins list` command — pattern reference for `plugins remove`)
- `finlet/cli.py:306-368` (`plugins_add` command — pattern reference for `plugins remove`, including `_MISSING_API_KEY_MESSAGE`, `_AUTH_REJECTED_MESSAGE`, `httpx.ConnectError` paths, and `_api_headers` / `_print_error` reuse)
- `finlet/api/services/settings_service.py:212-344` (`update_plugin` — confirms empty-string `api_key` / `email` already triggers `registry.reload` + unhealthy status; docstring change only)
- `finlet/api/services/settings_service.py:226-229` (multi-tenant docstring — referenced by new `plugins remove` docstring)
- `finlet/api/services/settings_service.py:249-256` (empty-string handling — confirms the contract)
- `finlet/api/services/settings_service.py:291` (`registry.reload(plugin, config[plugin])`)
- `finlet/api/services/settings_service.py:303` (`registry.health_check_all()`)
- `finlet/api/services/settings_service.py:333-343` (response folds `health` key)
- `finlet/api/routes_settings.py:128-148` (`PUT /settings/plugins` endpoint shape)
- `finlet/plugins/registry.py:680-731` (`reload()` — `_reload_lock`, restoration on failure)
- `finlet/plugins/edgar_plugin.py:76-94` (EDGAR `initialize()` — identity lookup, returns False on missing)

**Files touched:**

- **`finlet/cli.py`** (modified) — add `@plugins_app.command("remove")` taking `name: str` arg + `api_key: str | None = typer.Option(... envvar="FINLET_API_KEY")`. Body PUTs to `/v1/settings/plugins` with `{"plugin": name, "enabled": False, "api_key": "", "email": ""}` and Bearer auth header. Surfaces `health.status` / `message` from response, mirroring `plugins_add`. Reuses `_MISSING_API_KEY_MESSAGE`, `_AUTH_REJECTED_MESSAGE`, `httpx.ConnectError` handlers, `_api_headers`, `_print_error`. Docstring documents that this clears credentials + disables for the calling user; does NOT unload the process-global plugin singleton (cross-references `settings_service.py:226-229`).
- **`finlet/api/services/settings_service.py`** (docstring only) — update `update_plugin` docstring to document the empty-string-clears contract that `plugins remove` relies on. No code change; current `settings_service.py:249-256` already does the right thing.
- **`tests/test_cli.py`** (modified) — new `TestPluginsRemoveCommand` class (or extend existing `TestPluginsCommands`):
  - Happy path: `plugins remove edgar` against stub server returning `{"status": "unhealthy", "health": {"status": "unhealthy", "message": "EDGAR plugin requires an identity..."}}`. Assert exit 0, stdout contains `Plugin 'edgar' status: unhealthy`.
  - Missing API key: `plugins remove` without `FINLET_API_KEY` exits non-zero with `_MISSING_API_KEY_MESSAGE`.
  - Network failure: `httpx.ConnectError` path matches `plugins_add` behavior.
  - Auth rejected: 401/403 emits `_AUTH_REJECTED_MESSAGE`.
- **`tests/api/test_routes_settings.py`** (modified) — extend `TestUpdatePluginEndpoint`: assert `PUT /settings/plugins` with `{plugin: "edgar", api_key: "", email: "", enabled: false}` returns 200 with `health.status == "unhealthy"` and non-empty `health.message`.

**NOT TOUCHED:** `finlet/api/routes_settings.py`, `finlet/api/schemas/settings.py`, `finlet/plugins/registry.py`, `finlet/plugins/base.py`, `finlet/plugins/edgar_plugin.py`, `dashboard/settings.js`.

**Deliverable:** A `finlet plugins remove <name>` CLI subcommand that PUTs through the existing settings endpoint to clear credentials + disable the plugin for the caller, plus the Signal 1 verification verdict (effective-on-main vs. requires-additional-fix).

**Validation:**

- **Pre-fix verification probe (RUN FIRST, BEFORE ANY CODE CHANGE):**
  ```yaml
  kind: cli-shell
  trigger: |
    export FINLET_API_KEY=$FINLET_TEST_API_KEY
    uv run python -m finlet plugins add edgar --email retest@example.com
  assertions:
    - cli_exit_code == 0
    - stdout contains "Plugin 'edgar' status:"
    - stdout does NOT contain "Restart server to apply"
    - within 3s of CLI exit, GET https://finlet.dev/v1/plugins/health (Authorization: Bearer $FINLET_TEST_API_KEY) returns a JSON array containing an item where name=="edgar" AND status=="healthy" AND message is null-or-empty
  branching:
    - if EDGAR healthy → skip update_plugin/registry changes; ship only plugins remove + tests; mark plugin-config-propagation refactor verdict=effective in same PR
    - if EDGAR unhealthy → file fresh root-cause investigation before patching
  ```
- **Unit (cli):** `plugins remove edgar` invokes `httpx.put` exactly once against `/v1/settings/plugins` with body `{"plugin": "edgar", "enabled": False, "api_key": "", "email": ""}` and `Authorization: Bearer <FINLET_API_KEY>` header. Exit 0 on 200, exit 1 on 401/403, exit 1 on `httpx.ConnectError`, exit 2 if `FINLET_API_KEY` unset.
- **Unit (settings_service):** `update_plugin(uid, plugin="edgar", email="")` returns `health.status == "unhealthy"`, `health.message` contains `"identity"`. No exception escapes.
- **API:** `PUT /v1/settings/plugins` body `{plugin: "edgar", email: "", api_key: "", enabled: false}` authenticated → 200 with `{status: "unhealthy", plugin: "edgar", health: {status: "unhealthy", ...}}`.
- **Cleanup retest envelope (post-deploy Phase 5.5 reuse):**
  ```yaml
  kind: cli-shell
  trigger: |
    export FINLET_API_KEY=$FINLET_TEST_API_KEY
    uv run python -m finlet plugins add edgar --email retest@example.com
  assertions:
    - cli_exit_code == 0
    - stdout contains "Plugin 'edgar' status:"
    - stdout does NOT contain "Restart server to apply"
    - within 3s of CLI exit, GET https://finlet.dev/v1/plugins/health returns edgar status=="healthy" AND message null-or-empty
  cleanup:
    - uv run python -m finlet plugins remove edgar
    - assert subsequent GET /v1/plugins/health shows edgar status=="unhealthy" with message containing "identity"
  ```
- **Test commands:**
  - `uv run pytest tests/test_cli.py::TestPluginsRemoveCommand -v`
  - `uv run pytest tests/api/test_routes_settings.py::TestUpdatePluginEndpoint -v`
  - `uv run ruff check finlet/cli.py finlet/api/services/settings_service.py tests/test_cli.py tests/api/test_routes_settings.py`
  - `uv run mypy finlet/cli.py finlet/api/services/settings_service.py`

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Run the pre-fix verification probe FIRST. Capture the EDGAR status and message. Branch your scope based on the result before any code edit.
- Follow existing patterns in `finlet/cli.py:306-368` (`plugins_add`) — reuse `_MISSING_API_KEY_MESSAGE`, `_AUTH_REJECTED_MESSAGE`, `_api_headers`, `_print_error`, `httpx.ConnectError` handling. Do NOT introduce new error-message constants.
- Update the `update_plugin` docstring even if the verification probe shows `effective` — the empty-string-clears contract documentation is needed regardless.
- If verification probe shows EDGAR effective, also touch `docs/bug-hunt/refactor-queue/plugin-config-propagation.md` to mark `verdict: effective` in the same commit. Surface the prod-deploy timing in the post-merge eval note.
- Keep `POST /v1/plugins/{name}/reload` as-is — explicitly out of scope for this refactor.
- Do not add a dashboard "remove plugin" button — explicitly out of scope.

---

### Team B: Profile Checklist Reach-In Deletion (`onboarding.js:382-385`)

**Blocked by:** none — independent

**Read these files first:**
- `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md` — Signal 2 section (lines 238-429)
- `dashboard/onboarding.js:359-388` (`initOnboarding` flow — the `if (!state.completed && !state.wizardDismissed) { checkFirstLogin().then(...) }` block)
- `dashboard/onboarding.js:376-387` (the exact regressing branch — verbatim quoted in the refactor doc)
- `dashboard/onboarding.js:431-440` (`checkFirstLogin` — confirms `sessions.length === 0` semantics)
- `dashboard/onboarding.js:692-705` (`handleNext()` Step-1 — carries the "do NOT mark 'profile' complete here" comment from prior Team D fix; reference for matching comment style)
- `dashboard/settings.js:279-291` (`saveProfile` publish gate — ensures `profile:saved` only fires when `display_name && bio` non-empty; do NOT modify)
- `docs/bug-hunt/refactor-queue/onboarding-checklist.md:191` ("the only legal site is the registry's auto-wired subscriber" — convention being enforced)
- `docs/decisions/onboarding-checklist-step-contract.md` (registry contract being respected)

**Files touched:**

- **`dashboard/onboarding.js`** (modified, lines 376-387) — delete the `else { markStepComplete('profile'); }` branch entirely. Replace with explanatory comment block ("Existing user — do NOT touch checklist state here. CHECKLIST_STEPS[0].trigger === 'profile:saved' is the only legal advance for the profile step. Marking on 'has-sessions' (this branch's old behavior) bypassed that invariant. Bug-hunt iter 20260501T234103Z1a49 (Team D) closed one of two reach-ins; this closes the second."). The `if (isFirstLogin) { showWizard(); }` branch is unchanged. Outer `if (!state.completed && !state.wizardDismissed)` gate is unchanged.
- **`tests/dashboard/onboarding-checklist.spec.js`** (modified, existing node --test file) — add two test cases:
  - `initOnboarding for existing user (has sessions) does NOT mark 'profile' step complete` — stub `apiFetch('/sessions')` → `[{id: 'sess-1'}]`, stub `localStorage.finlet_onboarding` → all-false steps, call `initOnboarding`, await microtask queue, assert `state.steps.profile === false` AND `localStorage.finlet_onboarding`'s `steps.profile === false`.
  - `markStepComplete('profile') only fires from the 'profile:saved' bus subscriber` — initialize registry subscribers, publish `'profile:saved'`, assert step ticks. Without publish, no other code path (including `checkFirstLogin` success → existing-user branch) ticks the step.
  - Existing test: stub `apiFetch('/sessions')` → `[]`, call `initOnboarding`, assert `showWizard` was called exactly once and `markStepComplete` was NOT called.
- **`tests/playwright/onboarding-end-to-end.spec.js`** (modified, existing Playwright spec) — add regression test:
  - Load dashboard fresh as existing user with one created session, no profile saved (`display_name=''`, `bio=''`). Wait 2s. Assert `localStorage.finlet_onboarding`'s `steps.profile === false`. Open the checklist; assert "Set up profile" row does NOT carry `checklist-item--done`.
  - Then navigate to Settings, fill `display_name + bio`, click Save Profile, assert bus publishes `profile:saved`, navigate back to dashboard, assert row IS now `--done`.

**NOT TOUCHED:** `dashboard/app.js`, `dashboard/settings.js` (the publish gate is already correct from prior Team D fix), `dashboard/checklist.js` (does not exist).

**Deliverable:** Profile checklist step is ticked exclusively via the `profile:saved` bus event published from `settings.js#saveProfile` when `display_name && bio` are non-empty. The existing-user `markStepComplete('profile')` reach-in is gone.

**Validation:**

- **Retest envelope (Phase 5.5 reuse):**
  ```yaml
  kind: playwright
  trigger: |
    1. Authenticate as test user with at least one created session.
    2. Verify Settings > Profile shows Display Name='' AND Bio=''.
       If not, edit them empty and save.
    3. Run in DevTools console: localStorage.setItem(
       'finlet_onboarding',
       JSON.stringify({completed: false, persona: null, wizardDismissed: true,
                       checklistDismissed: false,
                       steps: {profile: false, session: false,
                               analysis: false, strategy: false}})
       );
    4. Reload /index.html. Wait 3s for checkFirstLogin() to resolve.
  assertions:
    - "After reload, document.querySelector('[data-checklist-key=\"profile\"]') does NOT carry the class 'checklist-item--done'"
    - "JSON.parse(localStorage.finlet_onboarding).steps.profile === false"
    - "After save with display_name='Test' AND bio='Test bio' on Settings page (which publishes 'profile:saved'), the same selector NOW carries 'checklist-item--done' AND localStorage.steps.profile === true"
    - "0 console errors during the load"
  cleanup:
    - "On Settings > Profile, clear display_name and bio, click Save Profile."
    - "localStorage.removeItem('finlet_onboarding')"
  ```
- **Unit (`tests/dashboard/onboarding-checklist.spec.js`):**
  - Stub `apiFetch('/sessions')` → `[{id: 'sess-1'}]`. Stub `localStorage` → all-false steps. Call `initOnboarding`. Await microtasks. Assert `state.steps.profile === false`.
  - Stub `apiFetch('/sessions')` → `[]`. Call `initOnboarding`. Assert `showWizard` was called exactly once and `markStepComplete` was NOT called.
  - Publish `'profile:saved'` on the bus. Assert `state.steps.profile === true` AND `onboarding:step-completed` was published with `{step: 'profile'}`.
- **Test commands:**
  - `node --test tests/dashboard/onboarding-checklist.spec.js`
  - `npx playwright test tests/playwright/onboarding-end-to-end.spec.js`
  - `dashboard/lint-trusted-types.sh` if any HTML written (none expected in this scope)

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Follow existing comment-style in `dashboard/onboarding.js:692-705` (the `NOTE: do NOT mark 'profile' complete here` block from prior Team D fix). The new comment should reference both the prior Team D iter (`20260501T234103Z1a49`) and this one as closing-second-reach-in.
- Do NOT modify `dashboard/settings.js#saveProfile` publish gate — it is already correct.
- Do NOT modify the outer `if (!state.completed && !state.wizardDismissed)` gate — wizard visibility for new users must remain unchanged.
- Adhere to dashboard conventions per `.claude/rules/dashboard.md` if present, and `docs/decisions/onboarding-checklist-step-contract.md`. All checklist mutations MUST flow through the registry, not direct `markStepComplete` calls.

---

### Team C: Settings Dirty-Banner `display: none` Switch (`settings.css:870-891`)

**Blocked by:** none — independent

**Read these files first:**
- `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md` — Signal 3 section (lines 432-647)
- `dashboard/settings.html:541-545` (`<div class="unsaved-banner" id="unsaved-banner">` — confirm static rendering, attributes unchanged)
- `dashboard/settings.html:524-540` (IMPORTANT comment block above the banner — to be updated to describe new invariant)
- `dashboard/settings.css:870-891` (the regressing CSS block — `transform: translateY(100%)` + `transition`)
- `dashboard/form-dirty-tracker.js:66-76` (JSDoc block — to be updated)
- `dashboard/form-dirty-tracker.js:77-92` (`_updateBanner` — confirm `classList.toggle('unsaved-banner--visible', visible)` semantics; no code change needed)
- `docs/decisions/dashboard-form-dirty-tracker-registry.md` (form-dirty-tracker contract; no contract change here)
- Iter `20260501T234103Z1a49` Team C commit `87a37b6` (aria-hidden lockstep — kept as defense-in-depth)

**Files touched:**

- **`dashboard/settings.css`** (modified, lines 870-891) — replace `.unsaved-banner` rule's `transform: translateY(100%)` with `display: none`. Drop `transition: transform 0.3s ease`. Keep `position: fixed; bottom: 0; left: 0; right: 0;` plus padding/flex/spacing. Replace `.unsaved-banner--visible { transform: translateY(0); }` with `.unsaved-banner--visible { display: flex; }`. Add `.unsaved-banner { pointer-events: none; }` and `.unsaved-banner--visible { pointer-events: auto; }` as belt-and-suspenders.
- **`dashboard/form-dirty-tracker.js`** (JSDoc only, lines 66-76) — update the `_updateBanner` JSDoc to reflect that visual hide is now `display: none` (not `translateY`), and that `aria-hidden` is the secondary safety net. No code change in `_updateBanner` body.
- **`dashboard/settings.html`** (comment only, lines 524-540) — update the IMPORTANT block above the banner `<div>` to describe the new visual-hide-via-display-none invariant. The `data-testid`, role, `aria-live`, `aria-hidden` attributes on the `<div>` itself are unchanged.
- **`tests/playwright/settings-dirty-banner.spec.js`** (modified, or new file if existing one targets a different shape) — cold-load `/settings.html` as authenticated test user. Wait 2s (form-tracker init + rAF re-snapshot). Assert:
  - `getComputedStyle(unsavedBanner).display === 'none'`
  - Accessibility-tree snapshot does NOT contain `"You have unsaved changes"` (Playwright's `getByRole('status')` returns empty for the banner's role).
  - `unsavedBanner.matches(':focus-within') === false` (no focusable descendant).
  - Edit `#profile-name` (tracked field). Within 200ms: `getComputedStyle(unsavedBanner).display === 'flex'`. Snapshot finds banner text. Discard reachable via Tab.
  - Click Discard. Assert `display === 'none'`.
  - Click Save (no edits) — no-op no-banner round trip.
  - Edge: theme card click + frequency option click at cold load do NOT trip the banner (existing dirty-state-tracker v2 test continues to pass).

**NOT TOUCHED:** `dashboard/settings.js`, `dashboard/form-dirty-tracker.js` body (only the JSDoc).

**Deliverable:** Cold-loaded `/settings.html` shows the unsaved banner at `display: none` (removed from layout AND accessibility tree), and the banner appears only when a tracked field is dirty.

**Validation:**

- **Retest envelope (Phase 5.5 reuse):**
  ```yaml
  kind: playwright
  trigger: |
    1. Authenticate as test user (any account with non-empty profile).
    2. Cold-load https://finlet.dev/settings.html in a fresh tab.
    3. Wait 3s for form-tracker init + rAF re-snapshot.
    4. Take browser_snapshot of the page.
  assertions:
    - "getComputedStyle(document.getElementById('unsaved-banner')).display === 'none'"
    - "browser_snapshot text content does NOT contain 'You have unsaved changes'"
    - "browser_snapshot text content does NOT contain 'Discard'"
    - "browser_snapshot text content does NOT contain 'Save Changes' (other than as a section button label, not the banner button)"
    - "Tab-key navigation through the page does NOT focus #discard-changes-btn or #save-changes-btn while no field is dirty"
    - "After typing into #profile-name (a tracked field), within 200ms getComputedStyle(unsavedBanner).display === 'flex' AND browser_snapshot now contains 'You have unsaved changes'"
    - "After clicking #discard-changes-btn, getComputedStyle(unsavedBanner).display === 'none' again"
    - "0 console errors during the entire flow"
  cleanup:
    - "Click #discard-changes-btn if banner is visible"
    - "navigate away or close tab"
  ```
- **Playwright unit:** above assertions, plus synthetic-key edge cases (theme card, email-frequency option) — these continue to fire `setFieldDirty` only when not in `_loaderUpdating` guard, so cold load keeps banner at `display: none`.
- **Unit (form-dirty-tracker tests):** existing tests for `_updateBanner` continue to pass — they assert `classList.toggle` behavior, which is unchanged. The CSS change is invisible to the tracker module.
- **Test commands:**
  - `npx playwright test tests/playwright/settings-dirty-banner.spec.js`
  - `node --test tests/dashboard/form-dirty-tracker.spec.js` (if exists; verify _updateBanner tests still pass)
  - `dashboard/lint-trusted-types.sh` (no innerHTML writes expected in this scope)

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- Follow existing CSS patterns in `dashboard/settings.css` — no new CSS variables or naming conventions.
- Do NOT modify `dashboard/form-dirty-tracker.js` body — only the JSDoc block at lines 66-76. The `classList.toggle('unsaved-banner--visible', visible)` line drives the new CSS unchanged.
- Do NOT change `<div id="unsaved-banner">`'s `data-testid`, `role`, `aria-live`, or `aria-hidden` attributes. Only the comment block above the element.
- The slide-up transition is intentionally removed. Do not preserve it via `visibility: hidden` + transition tricks. Document the trade in the JSDoc update.
- Adhere to `docs/decisions/dashboard-form-dirty-tracker-registry.md` — the registry-driven dirty-tracking contract is unchanged by this fix.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A's pre-fix verification probe shows EDGAR `unhealthy` despite plugin-config-propagation refactor on `main` | Medium | High — would force Team A to expand scope to a fresh root-cause investigation | Pre-fix probe runs FIRST. If `unhealthy`, Team A files a separate issue and ships only `plugins remove` + tests. Does not block Teams B and C. |
| `display: none` change in Signal 3 breaks an unknown CSS selector chain (e.g., a sibling that depended on `.unsaved-banner` being in layout) | Low | Medium | Cold-load Playwright assertion catches layout shifts; existing dirty-state-tracker v2 test catches synthetic-key edge cases. |
| `markStepComplete('profile')` deletion in Signal 2 breaks an existing-user dashboard load that relied on the auto-tick to satisfy a downstream gate | Low | Medium | The downstream gates are `state.steps.session/analysis/strategy` for the wizard, not `profile`. Wizard outer gate (`!state.completed && !state.wizardDismissed`) is unchanged. New unit test asserts `showWizard` not called for existing user. |
| Two of three teams collide on `tests/playwright/` shared CI runner config | Low | Low | Each team's spec file is named distinctly (`onboarding-end-to-end.spec.js` vs. `settings-dirty-banner.spec.js`). No shared playwright.config.js modifications. |
| Team A's `plugins remove` CLI accidentally unloads a process-global EDGAR singleton, breaking other tenants on the same instance | Very Low | High | The `update_plugin` path explicitly does NOT unload the singleton — it clears creds + calls `registry.reload(plugin, config[plugin])` with empty config, which yields `_initialized=False` for the calling tenant only. Documented in `settings_service.py:226-229`. New CLI docstring restates the limitation. |
| Test environment doesn't have `FINLET_TEST_API_KEY` set for verification probe | Medium | Low | Team A surfaces the missing env var in its post-merge eval note; verification probe is gated on env presence. |

## Session Plan

### Session 1

**Parallel:** Teams A, B, C — zero shared files.

**Merge order:** Each team merges as ready, gated by its own targeted tests:
1. Team A: pre-fix verification probe → `pytest tests/test_cli.py::TestPluginsRemoveCommand` + `pytest tests/api/test_routes_settings.py::TestUpdatePluginEndpoint` + ruff + mypy → merge.
2. Team B: `node --test tests/dashboard/onboarding-checklist.spec.js` + `npx playwright test tests/playwright/onboarding-end-to-end.spec.js` → merge.
3. Team C: `npx playwright test tests/playwright/settings-dirty-banner.spec.js` → merge.

Order between teams is flexible — first team to green can merge first.

**Session checkpoint:** After all three merge, run the full test suite (`uv run pytest`, `node --test tests/dashboard/`, `npx playwright test`) on `main` to confirm no cross-team regression. Then deploy to `https://finlet.dev` and re-run the three retest envelopes (verbatim from each team's Validation subsection) as the post-deploy Phase 5.5 retest for the next bug-hunt iteration.

There is no Session 2 — no team's output blocks another.
