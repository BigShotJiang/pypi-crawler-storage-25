# Trade Ticket Panel Cash Mirror v2 — Execution Plan

> Generated from `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v2.md`. Last updated: 2026-05-02.
>
> Source doc honestly classifies this as a 5-line patch (not a true refactor); the refactor-queue slot exists only because the bug-hunt gate logic requires it. Plan is single-team accordingly.

## Constraints

- **Hard scope:** Close the `trade-ticket-stale-cash` patch-ineffective signal from iter `20260502T142726Z7b36` (deploy `433c01c`). The Phase 5.5 retest envelope from `docs/bug-hunt/20260502T142726Z7b36/triage.json` lines 24-36 IS the acceptance bar — do not declare done until the new e2e regression mirrors that envelope and passes locally.
- **Do NOT** introduce a new `panelStateMirror` module or generalize the always-on pattern. Source doc's "Convention-level variant" is explicitly out of scope (premature abstraction at one call site).
- **Do NOT** modify `dashboard/dialog-state-mirror.js`. The v1 mirror still owns open-time prime + shape-drift refetch + refuseClobber for the visible lifetime; the new always-on subscriber is purely a closed-panel backstop that composes orthogonally.
- **Do NOT** touch the publisher side (`dashboard/app.js:1442-1480` SSE handler, `dashboard/app.js:1494-1620` post-fill handler, `dashboard/trade-ticket.js:408-459` post-submit IIFE). Phase 5.5 retest assertion #4 confirmed publishers are correct; the gap is consumer-side.
- **Bus contract:** `window.finletBus.subscribe(event, handler)` returns an unsubscribe closure (idempotent); `getLastPublished(event)` returns the last payload or `undefined`. Defined at `dashboard/event-bus.js:55, 117`. New code MUST go through `window.finletBus`, not raw `addEventListener` (per `CLAUDE.md`).
- **paintCash contract:** `paintCash(cash: number)` at `dashboard/trade-ticket.js:20-25`, renders `$94,548.49` style via `Number.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})`. The new subscriber MUST feed it a `number`, not a pre-formatted string.
- **Test runner:** `node:test` (NOT jest/vitest). Convention is `.spec.js`. Sibling examples: `tests/dashboard/event-bus.spec.js`, `tests/dashboard/dialog-state-mirror.spec.js`, `tests/dashboard/trade-ticket-post-submit.spec.js`.

## File Conflict Table

| File | Touched by Teams |
|------|------------------|
| `dashboard/trade-ticket.js` | A |
| `tests/dashboard/trade-ticket-panel-mirror.spec.js` (NEW) | A |
| `tests/e2e/journey-05-trade.spec.ts` | A |

Single team — no inter-team file conflicts. No coupling with any in-flight refactor-queue doc (`plugin-config-propagation.md` is shipped + verdict=effective; `close-patch-ineffective-2026-05-02.md` is shipped + verdict=incomplete with this finding as the explicit forward-signal it acknowledged).

## Dependency Graph

- **Team A** (independent) — can start immediately.

## Critical Path

`Team A → done`

---

## Teams

### Team A: Trade Ticket panel always-on cash subscription + regression tests

**Blocked by:** none — can start immediately.

**Read these files first:** (CRITICAL — prevents implementing on stale assumptions)

- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v2.md` — full refactor scope, recommended variant, out-of-scope acknowledgements, validation envelope.
- `dashboard/trade-ticket.js:20-25` — `paintCash(cash)` definition (the function the new subscriber MUST call). Accepts `number`, formats `$94,548.49`.
- `dashboard/trade-ticket.js:31-113` — `initTradeTicket()` body. Body ends at line 113. The new always-on subscription block goes at the END of `initTradeTicket()` (after existing wiring, before the closing brace).
- `dashboard/trade-ticket.js:138-141` — `tradeTicketMirror` allocation site (so the agent SEES this is per-open, not page-lifetime — and understands why the new subscription is needed in addition).
- `dashboard/trade-ticket.js:161-207` — the v1 `dialogStateMirror({...})` block. **DO NOT MODIFY.** Read it to understand the per-open lifecycle the new subscriber composes with.
- `dashboard/trade-ticket.js:238-241` — `closeTradeTicket()` calls `tradeTicketMirror.close()` (unsubscribes). Read to confirm: between close → next open there are zero subscribers for `tt-cash-balance`.
- `dashboard/trade-ticket.js:379` — `submitTradeTicket()` calls `closeTradeTicket()` synchronously on submit-success, BEFORE the line 408-459 post-submit IIFE republishes. This is WHY the existing republish doesn't repaint the persistent DOM.
- `dashboard/trade-ticket.js:408-459` — post-submit IIFE (publish at line 449). Confirm: publish is correct; consumer is the gap.
- `dashboard/index.html:428, 435` — `<aside id="trade-ticket-panel">` at line 428 contains `<span id="tt-cash-balance">` at line 435. Persistent DOM, not destroy-on-close.
- `dashboard/app.js:1896-1945` — `renderPortfolio()`. Touches `#cash-value` (line 1909) — does NOT touch `#tt-cash-balance`. Confirm the gap: no other code path keeps the panel span fresh.
- `dashboard/app.js:1442-1480` — SSE `portfolio` handler that publishes `portfolio:updated` at line 1472. Read to confirm payload shape (`{ cash, total_value, ... }`) so the new subscriber can read `payload.cash`.
- `dashboard/app.js:1494-1620` — SSE `orders` post-fill handler that publishes `portfolio:updated` at line 1608. Confirm same payload shape.
- `dashboard/event-bus.js:36-130` — bus implementation. `subscribe` at line 55 returns unsubscribe closure. `getLastPublished` at line 117 returns last payload or `undefined`. Confirm both signatures before writing the call.
- `dashboard/dialog-state-mirror.js:1-100` — v1 mirror. Lifecycle docs at lines 19-41. **DO NOT MODIFY.** Read only to confirm the new subscriber composes orthogonally (separate listener slot in the bus subscriber map).
- `dashboard/event-contract.md` — current canonical contract for `portfolio:updated`. If the contract doesn't currently document the closed-panel-backstop expectation for `#tt-cash-balance`, add a one-line note (per CLAUDE.md: "update event-contract.md in the same commit if you add a new event name" — same-commit doc-touch principle applies to clarifying consumer guarantees too).
- `tests/dashboard/event-bus.spec.js`, `tests/dashboard/dialog-state-mirror.spec.js`, `tests/dashboard/trade-ticket-post-submit.spec.js` — sibling specs. Read for: how to stub `window.finletBus`, how to assert spy invocations under `node:test`, how to set up minimal DOM (jsdom or document-shim pattern used elsewhere).
- `tests/e2e/journey-05-trade.spec.ts:518-527` — existing simulated-fill block (`positions.SPY.quantity: 10`). The new e2e assertion goes immediately AFTER the fill is simulated AND the panel close path runs.
- `docs/bug-hunt/20260502T142726Z7b36/triage.json` (lines 24-36) — the Phase 5.5 retest envelope. The new e2e regression assertion shape MUST match this envelope.

**Files touched:**

- Modified: `dashboard/trade-ticket.js` — add a ~5-line block at the end of `initTradeTicket()` (after line 113's closing `}` is preceded by the new subscription). The block: (1) prime synchronously by reading `window.finletBus.getLastPublished('portfolio:updated')` — if the payload exists and `typeof payload.cash === 'number' && !Number.isNaN(payload.cash)`, call `paintCash(payload.cash)`; (2) install an always-on subscriber: `window.finletBus.subscribe('portfolio:updated', payload => { if (payload && typeof payload.cash === 'number' && !Number.isNaN(payload.cash)) paintCash(payload.cash); });`. Do NOT capture the unsubscribe closure — page-lifetime subscription, intentionally never torn down.
- Modified: `dashboard/event-contract.md` — one-line note under the `portfolio:updated` event clarifying that consumers MAY install always-on subscribers when their target DOM persists across panel-open/close cycles (referencing `tt-cash-balance` as the documented case). Same-commit principle.
- New: `tests/dashboard/trade-ticket-panel-mirror.spec.js` (~30-50 LOC) — `node:test` spec following the sibling-file pattern. Cases:
  - Stub `window.finletBus` (with `subscribe` + `publish` + `getLastPublished` shims).
  - Stub minimal DOM (document/element with `#tt-cash-balance` span; spy on `paintCash` if it's exported, otherwise spy on the span's `textContent` setter).
  - **Case 1:** publish `portfolio:updated { cash: 94846.45 }` BEFORE any `openTradeTicket()` call → spy invoked once with `94846.45` (the always-on subscriber catches it; mirror doesn't exist).
  - **Case 2:** publish AFTER `openTradeTicket()` + `closeTradeTicket()` cycle → spy invoked exactly once (no double-paint from a torn-down mirror; only the always-on subscriber fires).
  - **Case 3:** init runs while bus already has a prior `portfolio:updated` cached in `getLastPublished` with `{ cash: 87000 }` → after `initTradeTicket()`, spy was invoked synchronously once with `87000` (prime worked).
  - **Case 4:** publish with malformed payload (`{}`, `{ cash: null }`, `{ cash: NaN }`, `{ cash: '94846.45' }` string) → spy NOT invoked (guards hold).
- Modified: `tests/e2e/journey-05-trade.spec.ts` — after the simulated MARKET BUY 10 SPY fill block at lines 518-527 AND after a `closeTradeTicket()` close path runs, assert: `await page.locator('#tt-cash-balance').textContent()` parses to a number strictly less than `100000` AND equals `await page.locator('#cash-value').textContent()` (within rounding, comparing parsed numbers to `0.01` tolerance), measured within 3 seconds of the simulated `order:filled` SSE. ZERO console errors during the flow. If the existing test doesn't already exercise the close path between fill and read, add the close call.

**Deliverable:** A page-lifetime `portfolio:updated` subscription installed by `initTradeTicket()` keeps `#tt-cash-balance` in sync regardless of panel open/close state, validated by 4 unit cases + 1 e2e assertion mirroring the Phase 5.5 retest envelope.

**Validation:** (each command MUST exit 0; no "tests pass" without specifics)

- [ ] `node --test tests/dashboard/trade-ticket-panel-mirror.spec.js` — all 4 cases pass.
- [ ] `node --test tests/dashboard/dialog-state-mirror.spec.js tests/dashboard/event-bus.spec.js tests/dashboard/trade-ticket-post-submit.spec.js` — existing siblings still pass (no regression in v1 mirror).
- [ ] `bash scripts/lint-trusted-types.sh` — pre-commit lint guard passes (the new code has no `.innerHTML` writes, but run anyway since `dashboard/` was touched).
- [ ] `npx playwright test tests/e2e/journey-05-trade.spec.ts` — including the new closed-panel-cash assertion. **If Playwright env is not configured locally and this command would require >5 min setup, run as best-effort and document the skip in the commit message; the smoke retest in Phase 5.5 of the next bug-hunt iteration is the authoritative gate.**
- [ ] Manual eyeball: `git diff dashboard/trade-ticket.js` — net addition is ~5-8 lines inside `initTradeTicket()` only; no edits to the v1 mirror block (lines 161-207); no edits to `closeTradeTicket()` (lines 238-241); no edits to `submitTradeTicket()` (around line 379) or the post-submit IIFE (lines 408-459).

**Agent instructions:**

- You are working in a worktree-isolated copy of the repo (per `feedback_worktree_prompts.md` — repo root is the worktree path returned by your spawner; do NOT `cd /Users/justnau/finlet`, work where you were spawned).
- Read EVERY file in the "Read these files first" list before writing any code. The whole point of this fix is that the v1 abstraction was correct but missed one panel surface; you cannot afford to misread which lifecycle owns what.
- The fix is intentionally tiny (~5 lines of production code). Resist scope creep:
  - DO NOT touch `dashboard/dialog-state-mirror.js`.
  - DO NOT introduce a `panelStateMirror` module — the source doc's "Convention-level variant" is explicitly OUT of scope.
  - DO NOT modify the v1 mirror block (lines 161-207) or `closeTradeTicket()` (lines 238-241).
  - DO NOT touch any publisher (`app.js:1442-1480`, `app.js:1494-1620`, `trade-ticket.js:408-459`).
  - DO NOT remove the per-open mirror — it still owns open-time prime, shape-drift refetch, and refuseClobber for the visible lifetime.
- The new subscription is intentionally never unsubscribed. It lives for the page lifetime. Do NOT capture the returned closure into a variable that some teardown path might invoke.
- Bus access goes through `window.finletBus` (per `CLAUDE.md` — direct `addEventListener('finlet:...')` is forbidden).
- `paintCash` accepts a `number`. Validate `typeof payload.cash === 'number' && !Number.isNaN(payload.cash)` before calling. Do NOT format the value yourself; `paintCash` owns the format.
- For the e2e test addition: the existing `journey-05-trade.spec.ts` likely has its own fill-simulation harness (the `positions.SPY.quantity: 10` block at lines 518-527 suggests a mocked SSE feed). Use the same mechanism — do NOT introduce a new fill simulator.
- After implementation, run the validation commands. If `node --test` discovers a test-infra surprise (e.g., `paintCash` is module-private and not stubbable), pivot to spying on the DOM textContent setter; do NOT export `paintCash` just to make the test easier.
- If the e2e test cannot be run locally (Playwright not installed or no test browser), document the skip in your commit message body and confirm the assertion shape mirrors the Phase 5.5 retest envelope from `docs/bug-hunt/20260502T142726Z7b36/triage.json:24-36`.
- **You MUST `git add` + `git commit` before finishing.** Worktree agents that don't commit lose ALL their work when the worktree is cleaned up.
- Commit message format: `dashboard: trade-ticket panel always-on cash subscription (close trade-ticket-stale-cash recurrence; refactor-queue: trade-ticket-state-sync-v2.md)`. Body should reference the source doc, the Phase 5.5 retest envelope, and any validation skips.

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Agent over-engineers and creates `panelStateMirror.js` | Medium | High (rejects refactor doc's explicit OOS line; ships ~80 LOC dead infra) | Plan's "Agent instructions" repeats the OOS guard 3x; "Read these first" includes the source doc whose first heading is "Honest classification: 5-line patch". |
| Agent removes or modifies the v1 `dialogStateMirror` block | Low | High (breaks open-time prime + shape-drift refetch for the open-panel lifetime; introduces new bugs) | Explicit "DO NOT MODIFY" call-outs on `dialog-state-mirror.js`, lines 161-207, and `closeTradeTicket()`. |
| Agent captures unsubscribe closure into module state | Medium | Medium (intent is page-lifetime; if some future teardown path invokes it, the bug returns silently) | Explicit instruction: "DO NOT capture the returned closure into a variable." Test case 2 catches accidental teardown by asserting subscribe-still-fires-after-close-cycle. |
| Double-paint when both v1 mirror and new subscriber fire on the same publish (panel happens to be open during a publish) | Medium | Low (visual no-op — both write the same value through `paintCash`; one renders frame is consumed) | Acknowledged in source doc as orthogonal composition. Both call `paintCash(cash)` with the same payload field, so worst case is a redundant DOM write to the same value. Unit case 2 verifies single-paint on closed-panel publish; double-paint on open-panel publish is acceptable behavior. |
| `paintCash` is module-private and not test-spy-able from outside | Medium | Medium (forces an unwanted export OR forces test refactor) | Plan's agent instructions: pivot to spying on DOM textContent setter; do NOT export `paintCash` for test convenience. |
| Bus payload shape diverges between SSE handler (line 1472) and post-fill handler (line 1608) | Low | Medium (one path passes `payload.cash`, the other passes `payload.portfolio.cash` — guard `typeof payload.cash === 'number'` would silently skip one path) | Recon already confirmed both publishers pass the same shape (`{ cash, total_value, ... }`). Agent must read both publisher line ranges before writing the guard to confirm. If they diverge, the guard is the wrong fix; add `payload.portfolio?.cash` fallback. |
| e2e test cannot run locally (no Playwright env) | High | Low (the next bug-hunt iteration's Phase 5.5 retest catches it on prod) | Validation explicitly allows skip-with-doc; the Phase 5.5 retest is the authoritative gate either way. Don't block the merge on local Playwright. |
| Worktree agent forgets to `git commit` | Low (instructions repeat it) | Critical (ALL work lost when worktree is cleaned) | "You MUST git add + git commit before finishing" is bolded in agent instructions; `/exec-plan` enforcer also gates merge on commit existence. |

## Session Plan

### Session 1

**Sequential:** Team A (only team).

**Merge order:** Team A merges to main → targeted gate: `node --test tests/dashboard/trade-ticket-panel-mirror.spec.js tests/dashboard/dialog-state-mirror.spec.js tests/dashboard/event-bus.spec.js tests/dashboard/trade-ticket-post-submit.spec.js` → all pass.

**Session checkpoint after merge:** Full dashboard test suite — `node --test tests/dashboard/*.spec.js` exit 0. Full pre-commit lint stack (`bash scripts/lint-trusted-types.sh`) exit 0.

**Push:** After merge + checkpoint pass, push `main` to `origin`. Production deploy on push. The next bug-hunt iteration's Phase 5.5 (or the user manually re-running the retest envelope from `docs/bug-hunt/20260502T142726Z7b36/triage.json:24-36` against finlet.dev) is the authoritative effectiveness gate.

## Execution Status

- **Completed:** 2026-05-02
- **Spawn base SHA:** 5d6039c0ca96a085f06a112b04b0ed069923ec8d
- **Team A:** merged as commit c712d98 (no-ff merge: 1cd2b5b)
- **Validation:**
  - node --test tests/dashboard/trade-ticket-panel-mirror.spec.js — 4/4 pass
  - node --test tests/dashboard/*.spec.js (full) — 62/62 pass
  - bash scripts/lint-trusted-types.sh — 0 violations
  - npx playwright test tests/e2e/journey-05-trade.spec.ts — SKIPPED (Playwright env unavailable; the next bug-hunt iteration's Phase 5.5 retest is the authoritative gate)
- **Files changed:** dashboard/event-contract.md, dashboard/trade-ticket.js (+35 lines, ~13 LOC + comments), tests/dashboard/trade-ticket-panel-mirror.spec.js (NEW), tests/e2e/journey-05-trade.spec.ts (modified)
