You are Team D for the UI write-path launch cut refactor.

**Plan reference:** `/Users/justnau/finlet/docs/refactor/ui-cut/plan.md` (your full spec is in the "Team D" section).
**Source doc:** `/Users/justnau/finlet/docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`
**Baseline SHA:** `70bde71354ee20bb8f4aef12fb17abb8fb643904`

## Scope

git-mv 9 CUT e2e tests to `legacy/tests/e2e/`. Update `tests/e2e/playwright.config.ts` to exclude legacy/. Add npm script `test:legacy-e2e`. Reclassify `journey-12-forgot-password.spec.ts` based on whether it's auth-only (KEEP) or write-path (CUT).

**Important:** Finlet's Playwright config lives at `tests/e2e/playwright.config.ts`, NOT at repo root.

## Tasks (in order)

### 1. Reclassify `journey-12-forgot-password.spec.ts` BEFORE moving anything

Read the first 60 lines of `/Users/justnau/finlet/tests/e2e/journey-12-forgot-password.spec.ts`. Decide:
- If it tests ONLY the forgot-password / password-reset auth flow on `auth.html` / `verify.html` (KEEP pages), the test is auth-only → **KEEP** in production tests/. Document the call.
- If it touches settings.html, /settings, profile-edit, password-CHANGE flows on the (now cut) settings page → **CUT** to legacy.

Document the decision in your team's commit message.

### 2. git-mv the CUT e2e tests

Move ALL of these (8 confirmed CUT plus journey-12 if reclassified as CUT):

```bash
git mv tests/e2e/journey-05-trade.spec.ts legacy/tests/e2e/journey-05-trade.spec.ts
git mv tests/e2e/journey-06a-settings-profile.spec.ts legacy/tests/e2e/journey-06a-settings-profile.spec.ts
git mv tests/e2e/journey-06b-settings-plugins.spec.ts legacy/tests/e2e/journey-06b-settings-plugins.spec.ts
git mv tests/e2e/journey-06c-settings-billing.spec.ts legacy/tests/e2e/journey-06c-settings-billing.spec.ts
git mv tests/e2e/journey-06d-settings-danger-zone.spec.ts legacy/tests/e2e/journey-06d-settings-danger-zone.spec.ts
git mv tests/e2e/journey-08-billing.spec.ts legacy/tests/e2e/journey-08-billing.spec.ts
git mv tests/e2e/journey-onboarding.spec.ts legacy/tests/e2e/journey-onboarding.spec.ts
git mv tests/e2e/journey-modal-stacking.spec.ts legacy/tests/e2e/journey-modal-stacking.spec.ts
```

CONDITIONAL (only if reclassification → CUT):
```bash
git mv tests/e2e/journey-12-forgot-password.spec.ts legacy/tests/e2e/journey-12-forgot-password.spec.ts
```

### 3. Update `tests/e2e/playwright.config.ts` to exclude legacy/

Open `/Users/justnau/finlet/tests/e2e/playwright.config.ts`. Locate the `testDir` and `testMatch` (or `testIgnore`) configuration in the projects array OR top-level config. Add a `testIgnore` pattern that excludes anything under `legacy/`:

```typescript
testIgnore: ['**/legacy/**', '**/legacy/tests/**'],
```

Use whichever pattern fits the existing config style. If the existing config already has a `testIgnore`, append legacy patterns to it.

### 4. Update `package.json` scripts

Open `/Users/justnau/finlet/package.json`. Locate the existing `test:e2e` script. Add a sibling `test:legacy-e2e` script that explicitly runs the legacy e2e tests on demand:

Option A (simplest if config supports it):
```json
"test:legacy-e2e": "playwright test --config=tests/e2e/playwright.config.ts legacy/tests/e2e"
```

But the testIgnore in the config will block legacy paths. Cleaner: create `tests/e2e/legacy.playwright.config.ts` that REQUIRES legacy and IGNORES production:

Actually simplest — just create a one-line wrapper:
```json
"test:legacy-e2e": "playwright test --config=tests/e2e/legacy.playwright.config.ts"
```

Then create `tests/e2e/legacy.playwright.config.ts` that imports the main config and overrides `testDir` to `legacy/tests/e2e` and clears the `testIgnore`. Pattern depends on the existing config — read it first, then choose the simplest expression.

If you can't make legacy tests easily runnable (they'll mostly fail since the surfaces are gone), just make `test:legacy-e2e` echo a clear message: "Legacy e2e tests are archaeological — run individually via `npx playwright test --config=tests/e2e/playwright.config.ts <path>` if needed." That's fine; the script's purpose is to acknowledge they exist.

### 5. Validation

- `find tests/e2e -maxdepth 1 -name 'journey-{05,06a,06b,06c,06d,08,onboarding,modal-stacking}*'` → NO results
- `find legacy/tests/e2e -maxdepth 1 -name 'journey-{05,06a,06b,06c,06d,08,onboarding,modal-stacking}*'` → at least 8 results (9 if journey-12 was reclassified CUT)
- `journey-12-forgot-password.spec.ts` location matches the reclassification decision; commit message documents the call
- `git log --follow legacy/tests/e2e/journey-05-trade.spec.ts | head -5` returns full pre-move history
- `npx playwright test --list --config=tests/e2e/playwright.config.ts | grep -E 'legacy/' || echo "ok no legacy listed"` → returns "ok no legacy listed" (production discovery does NOT include legacy)
- `npm run test:legacy-e2e -- --list 2>&1 | head` → either lists legacy tests or echoes the archaeological message

### 6. Commit

You MUST commit. Suggested commits:

1. `[Team D]: git-mv 8/9 CUT e2e tests to legacy/tests/e2e/ (journey-12 reclassified as <KEEP|CUT> because <reason>)`
2. `[Team D]: exclude legacy/ from playwright default test discovery + add test:legacy-e2e script`

## CRITICAL RULES

- Read `docs/KNOWN_FAILURES.md` first.
- Read the plan's "Read these files first" list BEFORE editing.
- Use `git mv` for ALL relocates (preserves --follow history).
- You MUST `git add` and `git commit` ALL changes before finishing.
- Commit messages MUST start with `[Team D]:`.
- Do NOT touch dashboard/ (Teams A/B/C).
- Do NOT touch CI/scripts/.gitattributes (Team G).
- Do NOT touch docs/ (Team F).

## When done, report

```
DONE
commits: [list of SHAs]
journey_12_classification: KEEP|CUT
moved_e2e_tests: [list of test files moved]
playwright_config_updated: yes/no (path used)
test_legacy_e2e_script_added: yes/no
validation: <each check yes/no>
notes: [anything else]
```

OR `BLOCKED + reason`.
