You are Team C for the UI write-path launch cut refactor.

**Plan reference:** `/Users/justnau/finlet/docs/refactor/ui-cut/plan.md` (your full spec is in the "Team C" section).
**Source doc:** `/Users/justnau/finlet/docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`
**Baseline SHA:** `70bde71354ee20bb8f4aef12fb17abb8fb643904` (your worktree was reset to this base — Team A merged + 2 fix commits)

## Scope

1. TRIM `dashboard/settings.js` → relocate to legacy/, extract `dashboard/api-keys.js` + `dashboard/api-keys.html`
2. TRIM `dashboard/leaderboard-submit.js` in place (snapshot to legacy/, remove modal section)
3. Add post-cut comment to `dashboard/modal-controller.js`

## Tasks (in order)

### 1. Snapshot + extraction for settings.js → api-keys.js

The full settings.js (1915 lines) moves to legacy/. The KEEP API-key listing logic gets extracted into a new minimal `dashboard/api-keys.js`.

```bash
git mv dashboard/settings.js legacy/dashboard-ui/settings.js
```

Now the original settings.js is at `legacy/dashboard-ui/settings.js`. Read its lines 684-716 (where `initApiKeys()` and `loadApiKeys()` live per recon) PLUS any helpers those functions call.

Create `dashboard/api-keys.js` (~150 lines, but write only what's needed). Content:
- The `initApiKeys()` and `loadApiKeys()` functions (or rename to a clean exported entry point if you prefer)
- Any helpers they depend on (look for `revokeKey`, `formatApiKey`, `maskKey`, etc.)
- A small DOMContentLoaded init or equivalent that wires the page

Top-of-file comment:
```javascript
// API keys management (read-only listing + revoke).
// Extracted from legacy/dashboard-ui/settings.js during 2026-05-06 launch cut.
// See docs/decisions/ui-removal-launch-cut.md.
```

If a helper is also used by a CUT function in legacy/dashboard-ui/settings.js, you can either inline a minimal copy in api-keys.js OR import it from `dashboard/api-utils.js` (KEEP) if it's already there. Prefer the import path if available.

### 2. Create `dashboard/api-keys.html`

A minimal page (~80 lines target, but write only what's needed). Lift the API-key DOM section from `legacy/dashboard-ui/settings.html` (the part that renders the API-key list and revoke button) OR write fresh — whichever is smaller.

Required includes (all KEEP files):
- `<link rel="stylesheet" href="styles.css">`
- `<script src="auth-guard.js">` — auth gating
- `<script src="shared-nav.js">` — nav
- `<script src="api-utils.js">` — shared utilities
- `<script src="api-keys.js">` — your new file

Page structure:
- Standard nav (handled by shared-nav.js auto-injection if that's the pattern; else include the nav HTML)
- A heading like "API Keys"
- A list/table div the api-keys.js will populate
- (Optional) a small "How to use these keys" link to the agent-guide.html

Title: `API Keys — Finlet`

### 3. TRIM `dashboard/leaderboard-submit.js` in place

Snapshot first:
```bash
cp dashboard/leaderboard-submit.js legacy/dashboard-ui/leaderboard-submit.js
git add legacy/dashboard-ui/leaderboard-submit.js
```

Add snapshot annotation at top of `legacy/dashboard-ui/leaderboard-submit.js`:
```javascript
// Pre-launch-cut snapshot of dashboard/leaderboard-submit.js (commit 70bde71, 2026-05-06).
// Production version trimmed; submit-modal removed. See docs/decisions/ui-removal-launch-cut.md.
```

Now edit `dashboard/leaderboard-submit.js` IN PLACE. Identify CUT regions (per recon: line ~21 modal init, line ~36 close handler, line ~60 form submit). Find the function-block boundaries and remove the modal-related code (~115 lines per 23% estimate). KEEP the table-rendering portion (~382 lines).

Add a TODO at top of the trimmed file:
```javascript
// TODO(2026-05-06): rename to leaderboard-table.js — submit-modal logic moved
// to legacy/dashboard-ui/leaderboard-submit.js during launch cut.
```

Target line count: ~380 (allow ±50). Original was 497.

### 4. Strip `<script>` reference to `leaderboard-submit.js` from `dashboard/leaderboard.html` if it ONLY pointed at the submit-modal portion

Open `dashboard/leaderboard.html`. The `<script src="leaderboard-submit.js">` tag should remain (the file still exists in dashboard/, just trimmed). But if leaderboard.html has any inline trigger to `openSubmitModal()` or similar that references the removed code, remove it. Most likely no edits needed to leaderboard.html.

### 5. Comment `dashboard/modal-controller.js`

Add a one-line comment at the very top (after any existing license/copyright header):

```javascript
// Modal controller — currently zero callers post-2026-05-06 launch cut. Retained for future read-only modal use. See docs/decisions/ui-removal-launch-cut.md.
```

Do NOT change any code in modal-controller.js — comment only.

### 6. Validation

- `find dashboard -maxdepth 1 -name 'settings.js'` → NO results
- `find legacy/dashboard-ui -maxdepth 1 -name 'settings.js'` → 1 result
- `git log --follow legacy/dashboard-ui/settings.js | head -5` → returns full pre-move history
- `dashboard/api-keys.js` exists, contains `loadApiKeys` (or your equivalent entry function), and has < 250 lines
- `dashboard/api-keys.html` exists, includes `<script src="api-keys.js">`, includes shared-nav.js + auth-guard.js
- `legacy/dashboard-ui/leaderboard-submit.js` exists with `wc -l` ≈ 499 (snapshot + 2 comment lines)
- `wc -l dashboard/leaderboard-submit.js` → roughly 380 ±50
- `grep -nE 'submit-modal|leaderboard-submit-modal|openSubmitModal' dashboard/leaderboard-submit.js` → ZERO matches
- `head -1 dashboard/modal-controller.js` shows the post-cut annotation
- Browser smoke test: load `http://localhost:8000/api-keys.html` — page renders, no console errors. (Auth state may be empty if no session; that's fine, just check it doesn't crash.)
- Browser smoke test: load `http://localhost:8000/leaderboard.html` — table still renders, no console errors.

### 7. Commit

You MUST commit. Suggested commits:

1. `[Team C]: git-mv settings.js → legacy + extract api-keys.js + create api-keys.html`
2. `[Team C]: snapshot leaderboard-submit.js + trim modal section in place`
3. `[Team C]: comment dashboard/modal-controller.js post-cut state`

Pre-commit hooks may fire. Should pass cleanly — your edits are removals + a new minimal file + a comment.

## CRITICAL RULES

- Read `docs/KNOWN_FAILURES.md` first.
- Read the plan's "Read these files first" list BEFORE editing.
- Follow existing code style.
- You MUST `git add` and `git commit` ALL changes before finishing.
- Commit messages MUST start with `[Team C]:`.
- Do NOT touch app.js, index.html (Team B).
- Do NOT touch event-contract.md (Team B).
- Do NOT touch tests/ (Team D / Team E).
- Browser smoke test on api-keys.html is REQUIRED before commit. If page doesn't render, fix before committing.

## When done, report

```
DONE
commits: [list of SHAs]
api_keys_js_line_count: <count>
api_keys_html_line_count: <count>
leaderboard_submit_js_line_count: <new count> (was 497)
modal_controller_comment_added: yes/no
legacy_snapshots_created: yes/no
browser_smoke_api_keys: pass/fail
browser_smoke_leaderboard: pass/fail
validation: <each check yes/no>
notes: [anything else]
```

OR `BLOCKED + reason`.
