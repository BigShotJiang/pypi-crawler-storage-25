You are Team H for the UI write-path launch cut refactor.

**Plan reference:** `/Users/justnau/finlet/docs/refactor/ui-cut/plan.md` (your full spec is in the "Team H" section).
**Source doc:** `/Users/justnau/finlet/docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`
**Baseline SHA:** `70bde71354ee20bb8f4aef12fb17abb8fb643904`

## Scope

Audit-only team. Verify each of the 8 write-path API routes has at least one CLI or MCP consumer. Output a report at `docs/bug-hunt/20260507T042257Z3c76/api_route_audit.md`. NO production code changes.

## Tasks (in order)

### 1. Identify the 8 write-path API routes

Per the surface map at `docs/bug-hunt/20260507T042257Z3c76/surface_map.md` lines 220-228:

1. `POST /api/sessions/<id>/orders` (or `/trade/order` — verify the actual path)
2. `PATCH /api/sessions/<id>/settings`
3. `POST /api/me/profile`
4. `POST /api/me/password`
5. `POST /api/me/plugins/<id>/install`
6. `PATCH /api/me/plugins/<id>/config`
7. `POST /api/subscriptions/plans/<id>` (or similar — billing/subscription change)
8. `POST /api/me/account/delete`

Confirm each route's exact path by searching `finlet/api/`:
```bash
grep -rEn '@(app|router)\.(post|patch|put|delete)' finlet/api/ | head -50
```

### 2. For each route, search for CLI consumers

Search `finlet/cli.py` and any other CLI command files for:
- HTTP calls matching the route path (look for `httpx.post`, `httpx.patch`, or service invocations)
- Function calls to a service that wraps the route

Example pattern:
```bash
grep -rEn '(httpx|requests)\.(post|patch|delete)' finlet/cli.py finlet/cli/ 2>/dev/null
```

Also check service-layer wrappers:
```bash
grep -rEn 'svc_(submit_order|update_settings|update_profile|change_password|install_plugin|config_plugin|change_plan|delete_account)' finlet/
```

### 3. For each route, search for MCP consumers

Search `finlet/mcp/`:
```bash
ls finlet/mcp/
grep -rEn '@mcp\.tool|async def.*submit|async def.*update|async def.*install|async def.*configure' finlet/mcp/
```

Match each MCP tool to the route it consumes.

### 4. Categorize each route

For each of the 8 routes, the verdict is:
- **CLI:** has a CLI command consumer (with command name like `finlet order`, `finlet settings update`, etc.)
- **MCP:** has an MCP tool consumer (with tool name like `submit_order`, `update_settings`, etc.)
- **CLI+MCP:** both
- **INDIRECT:** referenced by an internal service that's not exposed via CLI/MCP (e.g., a webhook handler) — needs review before deletion
- **ORPHANED:** no CLI, no MCP, no internal service uses it — candidate for follow-up deletion in a future iteration

### 5. Write the audit report

Create `docs/bug-hunt/20260507T042257Z3c76/api_route_audit.md`. Format:

```markdown
# API Route Audit — UI Write-Path Launch Cut Follow-up

> Generated: 2026-05-07. Baseline: <commit SHA>. Scope: 8 write-path routes flagged in `surface_map.md`.

## Methodology

Searched `finlet/cli.py`, `finlet/cli/` (if present), `finlet/mcp/`, and `finlet/api/` itself for consumers of each route.

Search patterns:
- CLI: `httpx.(post|patch|delete)` calls + named CLI commands
- MCP: `@mcp.tool` decorators delegating to services that match route handlers
- Internal: cross-references between modules

## Findings

### 1. `POST /api/sessions/<id>/orders` (or actual path)

**Consumers:**
- CLI: `finlet order` at `finlet/cli.py:604-650` (verified — POSTs to `/sessions/{session}/trade/order`)
- MCP: `submit_order` tool at `finlet/mcp/tools_trading.py:18-80` (verified)

**Verdict:** CLI+MCP. Route is actively used.

### 2. `PATCH /api/sessions/<id>/settings`

**Consumers:**
- ...

**Verdict:** ...

(repeat for all 8 routes)

## Summary

| Route | Verdict | Notes |
|-------|---------|-------|
| POST /api/sessions/<id>/orders | CLI+MCP | live |
| ... | ... | ... |

## Follow-up recommendations

- ORPHANED routes: <list, if any> → candidate for deletion in next refactor iteration
- INDIRECT routes: <list, if any> → require review before deletion
- Routes with sole CLI/MCP consumer (no redundant exposure): note any single-consumer dependencies that would benefit from a fallback path
```

### 6. Commit

```bash
git add docs/bug-hunt/20260507T042257Z3c76/api_route_audit.md
git commit -m "[Team H]: API route audit — 8 write-path routes categorized by CLI/MCP consumer"
```

## CRITICAL RULES

- Read `docs/KNOWN_FAILURES.md` first.
- This is AUDIT ONLY. Do NOT modify any source code (finlet/, dashboard/, tests/).
- Do NOT delete any routes — that's a future refactor's call.
- You MUST `git add` and `git commit` the audit report before finishing.
- Commit messages MUST start with `[Team H]:`.

## When done, report

```
DONE
commits: [list of SHAs]
routes_audited: 8
verdicts: <count of CLI+MCP / CLI-only / MCP-only / INDIRECT / ORPHANED>
report_path: docs/bug-hunt/20260507T042257Z3c76/api_route_audit.md
report_line_count: <count>
notes: [anything surprising — e.g., a route that turned out to be ORPHANED]
```

OR `BLOCKED + reason`.
