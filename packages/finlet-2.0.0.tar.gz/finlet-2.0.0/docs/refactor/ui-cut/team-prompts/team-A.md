You are Team A for the UI write-path launch cut refactor.

**Plan reference:** `/Users/justnau/finlet/docs/refactor/ui-cut/plan.md` (your full spec is in the "Team A" section).
**Source doc:** `/Users/justnau/finlet/docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`
**Baseline SHA:** `bb4a6b502603e770701a4ffbebcb8be595c514ab` (your worktree was reset to this base after spawn)

## Scope

Pre-cut safety net + scaffold `legacy/` + relocate 14 CUT dashboard files + strip stale `<script>`/`<link>` includes from KEEP HTMLs.

## Tasks (in order)

### 1. Create the pre-cut safety-net tag

```bash
git tag pre-ui-cut-2026-05-06
git push origin pre-ui-cut-2026-05-06
```

If `git push` of the tag fails (auth, network), STOP and report. Do NOT proceed without the safety net.

### 2. Scaffold `legacy/` directory structure

```bash
mkdir -p legacy/dashboard-ui legacy/tests/e2e
```

Then write `legacy/README.md` as a STUB (3-5 lines). Team F will replace with full content later. Stub content:

```markdown
# legacy/

Code cut from production for the 2026-05-06 launch. See:

- `docs/decisions/ui-removal-launch-cut.md` — decision record
- `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` — refactor scope

**Do NOT modify in place** — `scripts/lint-no-legacy-edits.sh` (Team G) blocks future edits. Restore via `git checkout pre-ui-cut-2026-05-06 -- dashboard/<file>` or copy from this directory.

(Full content authored by Team F in Session 3.)
```

### 3. git-mv the 14 CUT files from `dashboard/` to `legacy/dashboard-ui/`

Use `git mv` for each (preserves `--follow` history). Do NOT delete-and-recreate.

```bash
git mv dashboard/trade-ticket.js legacy/dashboard-ui/trade-ticket.js
git mv dashboard/onboarding.js legacy/dashboard-ui/onboarding.js
git mv dashboard/onboarding.css legacy/dashboard-ui/onboarding.css
git mv dashboard/settings.html legacy/dashboard-ui/settings.html
git mv dashboard/settings.css legacy/dashboard-ui/settings.css
git mv dashboard/billing.html legacy/dashboard-ui/billing.html
git mv dashboard/billing.js legacy/dashboard-ui/billing.js
git mv dashboard/billing.css legacy/dashboard-ui/billing.css
git mv dashboard/pricing.html legacy/dashboard-ui/pricing.html
git mv dashboard/marketplace.html legacy/dashboard-ui/marketplace.html
git mv dashboard/marketplace.js legacy/dashboard-ui/marketplace.js
git mv dashboard/marketplace.css legacy/dashboard-ui/marketplace.css
git mv dashboard/dialog-state-mirror.js legacy/dashboard-ui/dialog-state-mirror.js
git mv dashboard/form-dirty-tracker.js legacy/dashboard-ui/form-dirty-tracker.js
```

Note: `dashboard/settings.js` is NOT in this list — it's TRIM (Team C handles).

### 4. Strip stale `<script>`/`<link>` includes from KEEP HTMLs

For each KEEP HTML page (`dashboard/{landing,auth,leaderboard,verify,setup,agent-guide,index}.html`), grep for any `<script src=` or `<link href=` pointing at the 14 moved files. Strip those tags only.

For `dashboard/index.html`: per recon, the includes block is at lines ~582-596. Open the file, identify the `<script>` tags pointing at moved files, remove them. KEEP all other includes (app.js, modal-controller.js, shared-nav.js, etc.).

For other HTMLs: most have zero hits (they reference different files). Run `grep -EnH 'src="(trade-ticket|onboarding|dialog-state-mirror|form-dirty-tracker)\.js"|href="(onboarding|settings|billing|marketplace)\.css"|src="(billing|marketplace)\.js"' dashboard/{landing,auth,leaderboard,verify,setup,agent-guide,index}.html` to find them; strip what you find.

Do NOT touch panel content (e.g., `<dialog id="trade-ticket">` in index.html lines 426-473). That's Team B's scope. ONLY strip include tags.

### 5. Validation

Before commit, verify:

- [ ] `git tag --list pre-ui-cut-*` returns `pre-ui-cut-2026-05-06`
- [ ] `git ls-remote --tags origin pre-ui-cut-2026-05-06` returns the tag ref (push worked)
- [ ] `find dashboard -maxdepth 1 -type f \( -name 'trade-ticket.js' -o -name 'onboarding.js' -o -name 'onboarding.css' -o -name 'settings.html' -o -name 'settings.css' -o -name 'billing.html' -o -name 'billing.js' -o -name 'billing.css' -o -name 'pricing.html' -o -name 'marketplace.html' -o -name 'marketplace.js' -o -name 'marketplace.css' -o -name 'dialog-state-mirror.js' -o -name 'form-dirty-tracker.js' \)` returns NO results
- [ ] `find legacy/dashboard-ui -maxdepth 1 -type f` returns at least 14 results
- [ ] `git log --follow legacy/dashboard-ui/trade-ticket.js | head -5` returns full pre-move history
- [ ] `grep -rEn 'src="trade-ticket\.js"|src="onboarding\.js"|src="dialog-state-mirror\.js"|src="form-dirty-tracker\.js"|src="billing\.js"|src="marketplace\.js"|href="onboarding\.css"|href="settings\.css"|href="billing\.css"|href="marketplace\.css"' dashboard/*.html` returns ZERO matches
- [ ] `legacy/README.md` exists with stub content

### 6. Commit

You MUST commit before finishing. Suggested commits (one logical concern per commit):

1. `[Team A]: scaffold legacy/ + stub README`
2. `[Team A]: git-mv 14 CUT files dashboard/ → legacy/dashboard-ui/`
3. `[Team A]: strip stale <script>/<link> includes from KEEP HTMLs`

The pre-commit hook (`scripts/git-hooks/pre-commit`) may fire — it checks `dashboard/` for trusted-types and event-bus violations. Stripping `<script>` tags is a delete-only edit, should pass cleanly. If a hook fails, fix the root cause (do NOT use `--no-verify`).

## CRITICAL RULES

- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the plan's "Read these files first" list BEFORE writing any code.
- Follow existing patterns in the project.
- You MUST `git add` and `git commit` ALL your changes before finishing.
- Your commit messages MUST start with `[Team A]:`.
- If validation fails, fix and re-commit. Do not report DONE with failing validation.
- Do NOT touch any TRIM files (app.js, index.html panels, settings.js, leaderboard-submit.js, modal-controller.js) — those are Teams B and C.
- Do NOT modify event-contract.md (Team B).
- Do NOT touch tests/ (Team D).

## When done, report

```
DONE
commits: [list of SHAs]
moved_files: [list of 14 paths]
stale_includes_stripped: [list of HTML files with edits, with line counts of edits]
validation:
  tag_pushed: yes/no
  legacy_dashboard_ui_count: N
  follow_history_works: yes/no
  zero_stale_includes: yes/no
  legacy_readme_exists: yes/no
notes: [anything else]
```

OR `BLOCKED + reason` if you hit something you can't resolve.
