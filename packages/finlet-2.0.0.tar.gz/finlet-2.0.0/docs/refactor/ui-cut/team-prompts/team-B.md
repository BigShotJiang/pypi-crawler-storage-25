You are Team B for the UI write-path launch cut refactor.

**Plan reference:** `/Users/justnau/finlet/docs/refactor/ui-cut/plan.md` (your full spec is in the "Team B" section).
**Source doc:** `/Users/justnau/finlet/docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`
**Baseline SHA:** `70bde71354ee20bb8f4aef12fb17abb8fb643904` (your worktree was reset to this base after spawn — Team A merged, plus 2 follow-on test fix commits)

## Scope

TRIM the cross-page write-path code: `dashboard/app.js`, `dashboard/index.html` panels, and `dashboard/event-contract.md` event prune.

## Tasks (in order)

### 1. Snapshot the production files to `legacy/dashboard-ui/` BEFORE trimming

Copy-then-trim pattern (Path A from source doc). The two files (app.js, index.html) STAY at `dashboard/` after trimming, so use `cp` not `git mv`:

```bash
cp dashboard/app.js legacy/dashboard-ui/app.js
cp dashboard/index.html legacy/dashboard-ui/index.html
git add legacy/dashboard-ui/app.js legacy/dashboard-ui/index.html
```

Add a snapshot annotation comment at the TOP of each legacy file (preserve original content otherwise):

For `legacy/dashboard-ui/app.js` — prepend (the file is JavaScript):
```javascript
// Pre-launch-cut snapshot of dashboard/app.js (commit 70bde71, 2026-05-06).
// Production version trimmed to read-only surfaces. See docs/decisions/ui-removal-launch-cut.md.
```

For `legacy/dashboard-ui/index.html` — prepend with HTML comment:
```html
<!-- Pre-launch-cut snapshot of dashboard/index.html (commit 70bde71, 2026-05-06).
     Production version trimmed to read-only surfaces. See docs/decisions/ui-removal-launch-cut.md. -->
```

### 2. TRIM `dashboard/app.js` (~30% removal expected)

Identify CUT regions by grep:

```bash
grep -nE '(openTradeTicket|closeTradeTicket|order:filled|onboarding:step-completed|window\.finletOnboarding|finletOnboarding\?)' dashboard/app.js
```

For each match, find the function/block boundaries (look at the preceding `function` declaration or `if (...)` block) and remove the entire block. Do NOT leave orphaned helpers that only the removed code called — grep their callers; if zero callers post-trim, remove them too.

Specifically remove:
- `openTradeTicket` and `closeTradeTicket` functions + their event handlers
- Trade-ticket SSE branches (any code in event-stream handlers that re-renders trade-ticket state)
- `bus.subscribe('order:filled', ...)` and its handler
- `bus.subscribe('onboarding:step-completed', ...)` and its handler
- Any `window.finletOnboarding?.markStepComplete?.(...)` invocations
- Onboarding-related state machines that only exist to feed the now-removed UI

Do NOT remove:
- `bus.subscribe('portfolio:updated', ...)` (KEEP event)
- `bus.subscribe('session:switched', ...)` (KEEP event)
- `bus.subscribe('auth:state-change', ...)` (KEEP event)
- Any helpers that have remaining callers after the trim
- The session selector, equity chart wiring, positions-table wiring, plugin-health wiring
- Read-only order log code (the order log displays orders; it doesn't submit them)

After your edit, target line count is ~2080 (allow ±200). Original was 2970.

### 3. TRIM `dashboard/index.html` (~35% removal expected)

Per recon at HEAD `bb4a6b5` (pre-Team-A; line numbers may have drifted slightly after Team A's include-strip):

- Lines ~74-123: `id="session-details-panel"` (CUT) — REMOVE
- Lines ~426-473: `id="trade-ticket"` slide-out (CUT) — REMOVE
- Lines ~488-535: `id="leaderboard-submit-modal"` (CUT) — REMOVE
- Onboarding checklist DOM (search for `id="onboarding-checklist"`) — REMOVE
- All other CUT-only `<dialog>` elements — walk every `<dialog>` and remove if its only callers were in moved CUT files

KEEP:
- Nav, session selector
- Equity chart container
- Portfolio metrics tiles (cash, equity, etc.)
- Positions table
- Order log (read-only display)
- Plugin health
- Any `<dialog>` for read-only display (e.g., session-info viewer if it's read-only — review case by case)

Target line count: ~390 (allow ±50). Original was 598.

### 4. Prune `dashboard/event-contract.md`

Read the full file. Locate the H3 sections for the 4 PRUNE events and remove them entirely:

- `### \`order:filled\``
- `### \`onboarding:step-completed\``
- `### \`profile:saved\``
- `### \`strategy:saved\``

KEEP H3 sections for:
- `### \`portfolio:updated\``
- `### \`session:switched\``
- `### \`auth:state-change\``

Update the preamble paragraph to note the prune. Add a line near the top:

```markdown
> Pruned during 2026-05-06 launch cut. Removed events: `order:filled`, `onboarding:step-completed`, `profile:saved`, `strategy:saved` (consumers moved to `legacy/dashboard-ui/`). See `docs/decisions/ui-removal-launch-cut.md`.
```

### 5. Validation

- `grep -n 'openTradeTicket\|closeTradeTicket' dashboard/app.js` → ZERO matches
- `grep -nE "subscribe\('order:filled'|subscribe\('onboarding:step-completed'" dashboard/app.js` → ZERO matches
- `grep -n "window\.finletOnboarding\|finletOnboarding\?" dashboard/app.js` → ZERO matches
- `grep -nE 'id="trade-ticket"|id="onboarding-checklist"|id="leaderboard-submit-modal"|id="session-details-panel"' dashboard/index.html` → ZERO matches
- `wc -l dashboard/app.js` → roughly 2080 ±200
- `wc -l dashboard/index.html` → roughly 390 ±50
- `grep -nE "^### \`order:filled\`|^### \`onboarding:step-completed\`|^### \`profile:saved\`|^### \`strategy:saved\`" dashboard/event-contract.md` → ZERO matches
- `grep -nE "^### \`portfolio:updated\`|^### \`session:switched\`|^### \`auth:state-change\`" dashboard/event-contract.md` → 3 matches
- `legacy/dashboard-ui/app.js` exists with `wc -l` ≈ 2972 (snapshot + 2 comment lines)
- `legacy/dashboard-ui/index.html` exists with `wc -l` ≈ 600 (snapshot + 2 comment lines)
- `head -3 legacy/dashboard-ui/app.js` shows the snapshot annotation
- Browser smoke test: launch a local HTTP server and load `http://localhost:8000/index.html` — page should load WITHOUT JS console errors. (Use `python -m http.server 8000 --directory dashboard` from another shell, or whatever the dev server convention is.)

### 6. Commit

You MUST commit before finishing. Suggested commits:

1. `[Team B]: snapshot dashboard/app.js + index.html to legacy/dashboard-ui/`
2. `[Team B]: trim trade-ticket + onboarding handlers from dashboard/app.js`
3. `[Team B]: trim trade-ticket + onboarding + leaderboard-submit panels from dashboard/index.html`
4. `[Team B]: prune CUT-only events from dashboard/event-contract.md`

Pre-commit hooks (`lint-trusted-types.sh`, `lint-event-bus.sh`) WILL fire. Removing handlers and panels should not introduce new violations, but if a hook flags a violation it found in code that's still present (i.e., not your edit's fault), surface that — do NOT use `--no-verify`.

## CRITICAL RULES

- Read `docs/KNOWN_FAILURES.md` first.
- Read the plan's "Read these files first" list BEFORE editing.
- Follow existing code style in `dashboard/app.js`.
- You MUST `git add` and `git commit` ALL changes before finishing.
- Commit messages MUST start with `[Team B]:`.
- Do NOT touch settings.js, leaderboard-submit.js, modal-controller.js (Team C).
- Do NOT touch tests/ (Team D for e2e moves; Team E for assertion updates).
- Do NOT touch docs/ARCHITECTURE.md, README.md, CLAUDE.md (Team F).
- Do NOT touch CI/scripts/.gitattributes (Team G).
- Browser smoke test is REQUIRED before commit. If `index.html` doesn't load (or has JS console errors), fix before committing — broken main blocks downstream teams.

## When done, report

```
DONE
commits: [list of SHAs]
app_js_line_count: <new line count> (was 2970)
index_html_line_count: <new line count> (was 598)
event_contract_pruned: yes/no
legacy_snapshots_created: yes/no
browser_smoke: pass/fail (with screenshot or console log if fail)
validation: <each check from section 5 marked yes/no>
notes: [anything else]
```

OR `BLOCKED + reason` if you hit something you can't resolve.
