You are Team G for the UI write-path launch cut refactor.

**Plan reference:** `/Users/justnau/finlet/docs/refactor/ui-cut/plan.md` (your full spec is in the "Team G" section).
**Source doc:** `/Users/justnau/finlet/docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`
**Baseline SHA:** `7004eacd055d69656e18c52e097c468137be2d18` (your worktree was reset to this base)

## Scope

CI guards + pre-commit hook to lock down `legacy/`. Specifically:
1. New `scripts/lint-no-legacy-edits.sh` — pre-commit hook script blocking modifications under `legacy/`
2. Update `scripts/git-hooks/pre-commit` to call the new script
3. Update `scripts/setup-git-hooks.sh` if needed
4. Create `.gitattributes` for `legacy/**` (linguist-vendored, linguist-generated)
5. Update `.github/workflows/ci.yml` to add `--ignore=legacy/` for pytest
6. Verify `.github/workflows/deploy.yml` does NOT bundle `legacy/`

## Tasks (in order)

### 1. Read existing patterns

- `scripts/git-hooks/pre-commit` (full, ~87 lines) — the hook that orchestrates lint scripts
- `scripts/lint-trusted-types.sh` (full) — example lint script form
- `scripts/lint-event-bus.sh` (full) — another example
- `scripts/setup-git-hooks.sh` (full) — installer
- `.github/workflows/ci.yml` (full)
- `.github/workflows/deploy.yml` (full)

### 2. Create `scripts/lint-no-legacy-edits.sh`

Mirror the structure of `scripts/lint-trusted-types.sh` (shebang, --check arg, exit codes, error messages). Logic:

```bash
#!/usr/bin/env bash
set -euo pipefail

# Pre-commit guard: block modifications to files under legacy/.
# ADDED files (initial migration, restoration paths) are allowed.
# MODIFIED files are blocked.
#
# See docs/decisions/ui-removal-launch-cut.md.

CHECK_MODE=0
if [[ "${1:-}" == "--check" ]]; then
  CHECK_MODE=1
fi

# Get staged files filtered to MODIFICATIONS only (not adds/deletes/renames)
modified_legacy=$(git diff --cached --name-only --diff-filter=M | grep -E '^legacy/' || true)

if [[ -n "$modified_legacy" ]]; then
  echo "ERROR: Modifications to legacy/ are blocked by pre-commit guard."
  echo "Files staged for modification:"
  echo "$modified_legacy" | sed 's/^/  /'
  echo ""
  echo "If you need to update a legacy file:"
  echo "  1. Copy it to a NEW path under dashboard/ (or wherever it should live now)"
  echo "  2. Make your changes there"
  echo "  3. Stage and commit the new file"
  echo ""
  echo "See docs/decisions/ui-removal-launch-cut.md for context."
  exit 1
fi

if [[ $CHECK_MODE -eq 1 ]]; then
  exit 0
fi
```

Make it executable: `chmod +x scripts/lint-no-legacy-edits.sh`.

### 3. Test the script locally

Before committing, validate:

```bash
# Test 1: stage a MODIFICATION → expect block
echo "// test edit" >> legacy/dashboard-ui/trade-ticket.js
git add legacy/dashboard-ui/trade-ticket.js
bash scripts/lint-no-legacy-edits.sh --check  # expect non-zero exit + error message
git restore --staged legacy/dashboard-ui/trade-ticket.js
git restore legacy/dashboard-ui/trade-ticket.js  # discard the test edit

# Test 2: stage an ADDITION → expect pass
echo "test" > legacy/scratch-test.txt
git add legacy/scratch-test.txt
bash scripts/lint-no-legacy-edits.sh --check  # expect zero exit
git restore --staged legacy/scratch-test.txt
rm legacy/scratch-test.txt
```

If both tests pass, the guard logic is correct.

### 4. Wire into pre-commit hook

Update `scripts/git-hooks/pre-commit`. Read the existing pattern (lines 35-84 wrap trusted-types and event-bus checks). Append a third block that:
- Resolves the lint script path: `LINT_NO_LEGACY="$REPO_ROOT/scripts/lint-no-legacy-edits.sh"`
- Checks if the script is executable
- Calls `bash "$LINT_NO_LEGACY" --check` with appropriate fallback / error handling
- Captures exit code, exits non-zero if guard failed

Mirror the existing trusted-types / event-bus block structure exactly.

### 5. Update `scripts/setup-git-hooks.sh` if needed

The setup script likely symlinks the master pre-commit hook. The new lint script is invoked by the master hook, so it's auto-installed once the master is updated. Verify by reading `setup-git-hooks.sh` — if it's a simple symlink installer, no edit needed. If it explicitly enumerates lint scripts, add the new one.

### 6. Create `.gitattributes`

Repo root `.gitattributes` — file does NOT exist at HEAD. Create it:

```
legacy/** linguist-vendored
legacy/** linguist-generated=true
```

Test:
```bash
git check-attr --all -- legacy/dashboard-ui/trade-ticket.js
# expect: linguist-vendored: set, linguist-generated: true
```

### 7. Update `.github/workflows/ci.yml`

Read the file. Locate the pytest invocation (~line 38). Add `--ignore=legacy/` to the pytest args. ruff and mypy already scope to `finlet/` and `tests/` so they don't pick up legacy/ implicitly — but verify by reading the workflow.

If there's a Playwright e2e job in ci.yml or a sibling workflow, ensure it uses `--config=tests/e2e/playwright.config.ts` (which Team D already configured with `testIgnore: ['**/legacy/**']`).

### 8. Verify `.github/workflows/deploy.yml`

Read the deploy workflow. The dashboard/Cloudflare Pages deploy step should source from `dashboard/` (clean — no legacy/). If the deploy uses a broader glob, add an exclusion. If clean already, no edit needed.

### 9. Commit

You MUST commit. Suggested commits:

1. `[Team G]: scripts/lint-no-legacy-edits.sh — pre-commit guard for legacy/ modifications`
2. `[Team G]: wire lint-no-legacy-edits.sh into pre-commit hook + setup script`
3. `[Team G]: .gitattributes — mark legacy/** as vendored + generated for diff/lang stats`
4. `[Team G]: ci.yml + deploy.yml — exclude legacy/ from CI test discovery`

When you commit, the new pre-commit guard WILL fire on your own commits. Since you're ADDING files (not modifying legacy/), it should pass cleanly.

### 10. Validation

- `bash scripts/lint-no-legacy-edits.sh --check` returns 0 on a clean staging area
- Modifying a legacy file and running the guard returns non-zero with a clear error message
- Adding a new file under legacy/ and running the guard returns 0
- `cat .gitattributes` returns the two `legacy/**` rules
- `git check-attr --all -- legacy/dashboard-ui/trade-ticket.js` shows `linguist-vendored: set` and `linguist-generated: true`
- `grep -E 'pytest|--ignore=legacy' .github/workflows/ci.yml` confirms `--ignore=legacy/` is on the pytest line
- Deploy workflow does not bundle legacy/ (verify by reading the workflow's source paths)

## CRITICAL RULES

- Read `docs/KNOWN_FAILURES.md` first.
- You MUST `git add` and `git commit` ALL changes before finishing.
- Commit messages MUST start with `[Team G]:`.
- Do NOT modify any file under `legacy/` — your own guard would block it.
- Do NOT touch dashboard/, finlet/, tests/, docs/.
- The guard must allow ADDED files (the initial migration commits already landed; future restoration paths need ADDED to pass).

## When done, report

```
DONE
commits: [list of SHAs]
lint_script_path: scripts/lint-no-legacy-edits.sh
guard_test_block_modify: pass/fail
guard_test_allow_add: pass/fail
gitattributes_created: yes/no
ci_yml_updated: yes/no (line numbers)
deploy_yml_status: clean (legacy/ not bundled) | modified (legacy/ now excluded)
validation: <each check yes/no>
notes: [anything else]
```

OR `BLOCKED + reason`.
