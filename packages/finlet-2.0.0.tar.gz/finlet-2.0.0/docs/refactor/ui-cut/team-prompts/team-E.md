You are Team E for the UI write-path launch cut refactor.

**Plan reference:** `/Users/justnau/finlet/docs/refactor/ui-cut/plan.md` (your full spec is in the "Team E" section).
**Source doc:** `/Users/justnau/finlet/docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`
**Baseline SHA:** `7004eacd055d69656e18c52e097c468137be2d18` (your worktree was reset to this base — Sessions 1+2 all merged)

## Scope

Update assertions in remaining KEEP + INFRA Playwright e2e tests against the now-trimmed dashboard surface. Drop assertions that target removed DOM (e.g., `id="trade-ticket"`, "Manage Plugins" drawer item). Update assertions that point at moved-but-renamed surfaces.

## Tasks (in order)

### 1. Read context

- `tests/e2e/playwright.config.ts` — how the test runner discovers tests
- `tests/e2e/fixtures.ts` and `tests/e2e/helpers.ts` (if they exist) — shared test scaffolding

The remaining production e2e tests (Team D moved 8 to legacy/, kept journey-12-forgot-password as KEEP):

KEEP tests in `tests/e2e/`:
- journey-01-landing.spec.ts
- journey-02-signup.spec.ts
- journey-03-login.spec.ts
- journey-04-dashboard.spec.ts (likely has trade-ticket assertions to remove)
- journey-07-leaderboard.spec.ts
- journey-10-authguard.spec.ts
- journey-12-forgot-password.spec.ts
- journey-14-cli-session.spec.ts
- journey-15-cli-plugins.spec.ts
- journey-shared-nav.spec.ts (likely has Trade button assertions — Trade button removed in last fix commit)

INFRA tests:
- journey-09-mobile.spec.ts
- journey-11-keyboard.spec.ts
- journey-13-cli-serve.spec.ts
- journey-16-benchmark-blindness.spec.ts
- journey-17-csrf-hydration.spec.ts
- journey-sim-time-tile.spec.ts
- journey-trusted-types.spec.ts

### 2. Run the test suite and capture failures

```bash
cd /Users/justnau/finlet
npx playwright test --config=tests/e2e/playwright.config.ts --reporter=list 2>&1 | tee /tmp/team-e-test-run-1.log
```

If your worktree doesn't have Playwright browsers/dependencies installed yet, run `npx playwright install --with-deps` first (or whatever the project's install convention is — check package.json for setup scripts).

Capture which tests fail and the failure messages.

### 3. For each failure, decide

- **Removed surface** (e.g., trade ticket panel, onboarding checklist, settings tab) → REMOVE the assertion or its containing `test.describe` / `test.beforeEach` block. Surface is gone for good.
- **Moved surface** (e.g., API key list moved from settings.html to api-keys.html) → UPDATE the selector/assertion to point at the new location.
- **Stale state** (test expects something that's been refactored independently of the cut) → fix the assertion.

DO NOT add `test.skip` to mask failures. DO NOT replace assertions with `expect(true).toBe(true)`. If you encounter a failure you genuinely cannot explain (i.e., something that should still be in the trimmed surface but isn't), STOP and surface it — it may indicate Team B/C left something half-trimmed.

### 4. Re-run and verify green

After each fix, re-run the affected test file:
```bash
npx playwright test --config=tests/e2e/playwright.config.ts <path-to-test> --reporter=list
```

After all fixes, run the full production suite:
```bash
npx playwright test --config=tests/e2e/playwright.config.ts --reporter=list
```

Target: all production tests green.

### 5. Validation

- `npm run test:e2e` (or the equivalent) exits 0 with all production tests passing
- No new `test.skip` calls introduced
- No `expect(true).toBe(true)` or equivalent hollow assertions
- `git diff main -- tests/e2e/` shows assertion updates only — no new test files added or deleted

### 6. Commit

You MUST commit. Suggested commits:
- One commit per logical concern, e.g., `[Team E]: drop trade-ticket assertions from journey-04-dashboard`
- Or one consolidated commit if all changes are tightly coupled: `[Team E]: update e2e assertions against trimmed dashboard surface`

## CRITICAL RULES

- Read `docs/KNOWN_FAILURES.md` first.
- You MUST `git add` and `git commit` ALL changes before finishing.
- Commit messages MUST start with `[Team E]:`.
- Do NOT touch dashboard/, finlet/ (downstream changes belong in their own teams).
- Do NOT touch tests/ outside `tests/e2e/`.
- Do NOT touch CI/scripts/.gitattributes (Team G).
- Do NOT touch docs/.
- If a test failure points at a missing dashboard surface that you believe SHOULD still be present (i.e., a gap from B or C's trim), STOP and report — don't paper over it.

## When done, report

```
DONE
commits: [list of SHAs]
tests_run: <total count>
tests_failing_pre_fix: <count>
tests_failing_post_fix: 0
tests_modified: [list of test files with summary of edits]
new_test_skips: 0
hollow_assertions: 0
notes: [anything else — e.g., a failure that pointed at an unexpected gap]
```

OR `BLOCKED + reason`.
