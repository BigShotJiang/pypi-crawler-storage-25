You are Team F (body work) for the UI write-path launch cut refactor.

**Plan reference:** `/Users/justnau/finlet/docs/refactor/ui-cut/plan.md` (your full spec is in the "Team F" section).
**Source doc:** `/Users/justnau/finlet/docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`
**Baseline SHA:** `70bde71354ee20bb8f4aef12fb17abb8fb643904`

## Scope (BODY work only — ship-stamp deferred)

Update `docs/ARCHITECTURE.md`, `README.md`, `CLAUDE.md`, `docs/REMAINING_TASKS.md`, `docs/LESSONS.md`, replace `legacy/README.md` stub with full content. The FINAL ship-stamp commit on `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` (`status: shipped`) is **NOT** in your scope right now — that's done in Session 3 after ALL other teams merge.

## Tasks (in order)

### 1. `docs/ARCHITECTURE.md` — major revision

Read the file first. Locate sections describing UI write paths (onboarding wizard, trade ticket, settings forms, plugin install UI, billing UI, marketplace UI). Replace those with a "2026-05-06 launch cut" section that:

1. States the current product positioning: agentic trading evaluation harness, primary user is an LLM agent invoking via CLI/MCP.
2. Notes the cut reduced production dashboard to read-only monitoring surfaces (equity curve, positions table, trade log, sessions list, plugin health, leaderboard, API key listing).
3. Explains that 8 write-path API routes (POST orders, PATCH settings, etc.) remain in `finlet/api/` for CLI/MCP — no UI consumes them.
4. Points readers at `docs/decisions/ui-removal-launch-cut.md` and `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`.

Be concise. Replaced sections should result in fewer total lines, not more.

### 2. `README.md` — quickstart leads with CLI/MCP

Read README. Update the "What is Finlet" / "Getting Started" / "Quickstart" section to lead with CLI/MCP usage:

- Install via `pip install finlet` (or whatever the actual install path is — check `pyproject.toml` to confirm)
- First-run command: `finlet quickstart` or `finlet session create` (whichever is the canonical entry per the CLI)
- MCP setup: pointer to the agent-guide.html or docs/MCP_SETUP.md if such exists
- Web UI section reframed as: "Monitoring dashboard for your agent's sessions" — view at finlet.dev or run locally via `finlet serve`

Do NOT delete the "What is Finlet" section; just reorder/reframe to put CLI first.

### 3. `CLAUDE.md` — annotate dashboard invariants

Read `/Users/justnau/finlet/CLAUDE.md`. Lines 31-34 contain dashboard convention invariants:
- Line 31: trusted-types + event-bus invariants — KEEP unchanged (still active on read-only surfaces).
- Line 32: form-dirty-tracker convention referencing `dashboard/form-dirty-tracker.js` — annotate as `legacy/`-only.
- Line 33: dialog-state-mirror convention with trade-ticket render-on-read exception — annotate as `legacy/`-only.
- Line 34: onboarding registry convention — annotate as `legacy/`-only.

Do NOT delete the invariants. Add a parenthetical to each affected one:

Example annotation pattern:
> "(applies to `legacy/dashboard-ui/` only — production dashboard has no forms post-2026-05-06 launch cut)"

The reason: someone restoring legacy code in the future may need these invariants. The annotation marks them as conditional.

### 4. `docs/REMAINING_TASKS.md` — close UI-bug TODOs

Read REMAINING_TASKS.md. Add a section near the top (or in chronological order):

```markdown
## 2026-05-06 — UI write-path launch cut

Cut 14 dashboard JS/HTML/CSS files + ~30% of app.js + ~35% of index.html + ~92% of settings.js to `legacy/`. Production dashboard now read-only. See `docs/decisions/ui-removal-launch-cut.md` and `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`.

Closed by this cut:
- Trade-ticket state-sync TODOs (cut)
- Onboarding checklist registry maintenance (cut)
- Form-dirty-tracker / dialog-state-mirror invariant enforcement (legacy-only)
- Settings page modal stacking (cut)
- Marketplace + Billing UI bugs (cut)
- Plugin install/configure UI (cut)
- (any other related items found in REMAINING_TASKS.md)
```

Then grep the file for any TODO referencing trade-ticket, onboarding, settings-form, plugin-install-UI, billing UI, marketplace UI, etc., and either remove them OR mark as "closed by 2026-05-06 UI cut" with a date.

### 5. `docs/LESSONS.md` — append meta-lesson

Append at the end of LESSONS.md:

```markdown
## 2026-05-06 — When >90% of bugs cluster in a surface the launch user doesn't touch, cut the surface

Twelve refactors shipped against the dashboard write paths over ~24 bug-hunt iterations with a 50% verdict-effective rate. ~65 of 69 ledger entries lived in those surfaces. The launch user (an LLM agent invoking via CLI/MCP) never touched them. The structural fix was to cut the surfaces, not refactor them again. See `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` and `docs/decisions/ui-removal-launch-cut.md`.

The bug-hunt loop should treat "category cluster + non-target user" as a refactor-or-cut signal, not a "ship another patch" signal.
```

### 6. `legacy/README.md` — replace stub with full content

The file currently exists with stub content (Team A wrote it). Replace wholesale with full content:

```markdown
# legacy/

Code preserved from production for the 2026-05-06 launch cut. This directory exists so the cut code remains visible, walkable, and restorable — not just behind a git tag.

## Why this exists

The dashboard contained two unrelated product surfaces collapsed into one codebase: a read-only monitoring surface (KEEP) and a write-path SaaS surface (CUT for launch). The write-path SaaS surface was inaccessible to the launch user (an LLM agent invoking via CLI/MCP), but accumulated ~65 of 69 bug-hunt ledger findings. The structural fix was to cut the surface; preserving the code here protects optionality if the product direction shifts.

See:
- `docs/decisions/ui-removal-launch-cut.md` — decision record
- `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` — refactor scope
- `docs/bug-hunt/20260507T042257Z3c76/surface_map.md` — full file classification

## What's here

- `legacy/dashboard-ui/` — 14 CUT dashboard files (JS, HTML, CSS) + pre-trim snapshots of `app.js`, `index.html`, `leaderboard-submit.js`, and `settings.js`
- `legacy/tests/e2e/` — 9 CUT e2e journey tests (write-path flows)
- `legacy/tests/dashboard/` — 5 CUT Node unit tests for the moved dashboard modules

## How to restore

Two paths:

**Path A: directory copy**
```bash
cp -r legacy/dashboard-ui/<file> dashboard/<file>
```
Then re-add the `<script>` / `<link>` tags to the relevant HTML page and run validation.

**Path B: tag checkout**
```bash
git checkout pre-ui-cut-2026-05-06 -- dashboard/<file>
```
This restores the pre-cut state of a specific file. Tag was created and pushed to origin on 2026-05-06.

After restoring, run a security review (see below) and full test suite before merging.

## Do NOT modify

The `scripts/lint-no-legacy-edits.sh` pre-commit hook (installed by Team G) blocks future modifications under `legacy/`. Adding new files is allowed (the initial migration must remain replayable); modifying existing files is blocked.

To restore: copy or tag-checkout to a NEW path under `dashboard/` (or wherever) — do not edit the legacy file directly.

## Security note

This code was deployed and security-reviewed as of 2026-05-06. It has been frozen since. If you restore any file, you MUST run a fresh security review before re-deploying — security standards drift, dependencies update, and vulnerabilities accumulate. Do not assume frozen-as-secure.

Particular concerns to re-check on restore:
- XSS via DOM mutation (the moved files predate some of the trusted-types hardening work)
- Token / API-key leakage via legacy log statements
- CSRF token freshness for any restored write-path form
```

### 7. Validation

- `grep -nE 'trade ticket|trade-ticket|onboarding wizard|settings form|plugin install UI|billing UI' docs/ARCHITECTURE.md` → either zero matches OR matches inside the new "launch cut" section
- `head -40 README.md` shows CLI/MCP-led quickstart, NOT "go to finlet.dev and click Sign Up"
- `grep -nE 'form-dirty-tracker|dialog-state-mirror|trade-ticket-render-on-read|onboarding.*registries' CLAUDE.md` → matches include `legacy/` annotations
- `grep '2026-05-06' docs/REMAINING_TASKS.md` → at least 1 match (your new section)
- `tail -20 docs/LESSONS.md` shows the new meta-lesson paragraph
- `wc -l legacy/README.md` → roughly 50-80 lines (not a stub)
- `grep -c '^## ' legacy/README.md` → at least 4 (Why, What's here, How to restore, Do NOT modify, Security note)
- `grep '^status:' docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` → still `status: ready` (you do NOT change this in body work)

### 8. Commit

You MUST commit. Suggested commits:

1. `[Team F]: ARCHITECTURE.md — replace UI-write-path sections with launch-cut section`
2. `[Team F]: README.md — quickstart leads with CLI/MCP, web UI reframed as monitoring`
3. `[Team F]: CLAUDE.md — annotate dashboard invariants as legacy-only`
4. `[Team F]: REMAINING_TASKS.md — close UI-bug TODOs after launch cut`
5. `[Team F]: LESSONS.md — append meta-lesson on cut-vs-refactor signal`
6. `[Team F]: legacy/README.md — full content (Why, What's here, How to restore, security note)`

## CRITICAL RULES

- Read `docs/KNOWN_FAILURES.md` first.
- You MUST `git add` and `git commit` ALL changes before finishing.
- Commit messages MUST start with `[Team F]:`.
- Do NOT touch the queue doc `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` — that's the Session 3 ship-stamp.
- Do NOT touch any code (dashboard/, finlet/) — docs only.
- Do NOT touch tests/, CI, scripts.
- Do NOT modify pre-commit hooks.

## When done, report

```
DONE
commits: [list of SHAs]
docs_updated:
  - docs/ARCHITECTURE.md: <one-line summary of edit>
  - README.md: <one-line summary>
  - CLAUDE.md: <one-line summary>
  - docs/REMAINING_TASKS.md: <one-line summary>
  - docs/LESSONS.md: <one-line summary>
  - legacy/README.md: full content (replaced stub)
validation: <each check yes/no>
ship_stamp: deferred (Session 3, after all teams merge)
notes: [anything else]
```

OR `BLOCKED + reason`.
