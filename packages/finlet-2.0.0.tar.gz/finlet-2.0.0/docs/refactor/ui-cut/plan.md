# UI Write-Path Launch Cut — Execution Plan

> Generated from `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`. Baseline HEAD: `fbb5bb3`. Generated: 2026-05-07.

## Constraints

**Hard constraints (from source doc):**
- Cut code MUST be preserved at `legacy/dashboard-ui/` (visible directory), NOT just behind a git tag.
- A safety-net tag (`pre-ui-cut-2026-05-06`) MUST be created before any team starts work.
- Production `dashboard/` retains read-only monitoring surfaces (KEEP list); 15 CUT files relocate to `legacy/dashboard-ui/`.
- Write-path API routes in `finlet/api/` are NOT removed — they remain as the CLI/MCP write surface. Audit (Team H) only.
- `git log --follow` history MUST be preserved on all moves (use `git mv` for relocates; copy-then-trim pattern for TRIM files).

**Discovered constraints (from recon HEAD `fbb5bb3`):**
- `dashboard/index.html` is touched by both Team A (strip CUT-file `<script>` includes at lines ~582-596) AND Team B (trim CUT panels at lines 74-123, 426-473, 488-535). Hard sequence: A merges first.
- `dashboard/event-contract.md` documents 7 events; 3 KEEP (`portfolio:updated`, `session:switched`, `auth:state-change`), 4 PRUNE (`order:filled`, `onboarding:step-completed`, `profile:saved`, `strategy:saved`). Pruning happens in Team B alongside the index.html trim (cross-page cohesive change).
- `legacy/README.md` is created as a stub by Team A and replaced with full content by Team F. Sequential.
- `.gitattributes` does not exist at HEAD — Team G creates it.
- Pre-commit hook infrastructure exists at `scripts/git-hooks/pre-commit` (calls `lint-trusted-types.sh` line 53, `lint-event-bus.sh` line 77). Team G adds a third guard `lint-no-legacy-edits.sh` following the same pattern.
- `journey-12-forgot-password.spec.ts` classification is contested: source doc flags it for reclassification (auth-only → KEEP). Team D resolves during execution.
- Surface map has a cosmetic count drift: header claims 8 INFRA tests, body lists 7. Team D verifies the actual file list during execution.

## File Conflict Table

| File | Touched by Teams | Resolution |
|------|------------------|------------|
| `dashboard/index.html` | A (strip includes lines ~582-596), B (trim CUT panels lines 74-123, 426-473, 488-535) | Sequential — A merges first, B rebases onto A's merge. |
| `legacy/README.md` | A (creates stub), F (writes full content) | Sequential — F's commit overwrites A's stub. F runs in Session 3. |
| `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` | F (final ship-stamp commit) | Single-team — F's last commit, after all other teams merge. |
| `legacy/tests/e2e/` (dir scaffold) | A (creates), D (fills via git-mv) | Not a file conflict — A creates the directory, D adds files. |
| `legacy/dashboard-ui/` (dir scaffold) | A (creates), B+C (fill via copy/git-mv) | Not a file conflict — A creates the directory, B/C add files. |

All other shared paths are isolated to a single team. The dependency graph is driven primarily by the two row-1 + row-2 conflicts above.

## Dependency Graph

- **Team A** (Pre-cut tag + scaffold + git-mv 15 CUT + strip CUT includes) — independent, runs first.
- **Team B** (TRIM app.js + index.html panels + event-contract.md prune) — blocked by A (needs `legacy/dashboard-ui/` scaffold + index.html include strip merged).
- **Team C** (TRIM settings.js → api-keys.js + leaderboard-submit.js + modal-controller.js comment) — blocked by A (needs `legacy/dashboard-ui/` scaffold). Parallel with B (no shared files).
- **Team D** (git-mv 9 CUT e2e tests + playwright.config.ts) — blocked by A (needs `legacy/tests/e2e/` scaffold). Parallel with B and C.
- **Team E** (Update assertions in remaining KEEP+INFRA tests against trimmed surface) — blocked by A, B, C, D (all dashboard cuts must stabilize before assertions are tuned).
- **Team F** (Docs sweep + CLAUDE.md + ARCHITECTURE.md + README.md + LESSONS.md + REMAINING_TASKS.md + legacy/README.md full content + ledger close-out) — body work parallel with everything; final ship-stamp commit (`status: shipped` on the queue doc) waits for ALL other teams to merge.
- **Team G** (CI guards + pre-commit hook + .gitattributes + ci.yml + deploy.yml legacy/ exclusions) — blocked by A, B, C, D (legacy/ structure must be stable before installing the no-edit guard, otherwise legitimate migration commits would be blocked).
- **Team H** (API route audit, optional) — independent, parallel with everything. Output is a report, no production code change.

## Critical Path

`Team A → Team B → Team E → Team F (ship-stamp)`

Or equivalently: `A → C → E → F` and `A → D → E → F`. The longest sequential chain is 4 teams. Minimum execution time is bounded by A's git-mv + scaffold (Session 1), then B's TRIM (the largest TRIM, ~30% of 2970-line app.js + ~35% of 598-line index.html + event contract prune), then E's assertion updates (small mechanical fixes), then F's ship-stamp.

---

## Teams

### Team A: Pre-cut tag + scaffold legacy/ + git-mv 15 CUT files + strip CUT includes from KEEP HTMLs

**Blocked by:** none — runs first.

**Read these files first:**
- `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md:60-86` — Team A scope as drafted (this team is a faithful execution of those scope items).
- `docs/bug-hunt/20260507T042257Z3c76/surface_map.md` — cross-validation of the 15 CUT file list.
- `docs/decisions/ui-removal-launch-cut.md` — decision rationale for dir-not-tag-only preservation.
- `dashboard/index.html:582-596` — `<script>` includes block; locate which specific includes point at the 15 CUT files.

**Recon evidence:**

The 15 CUT files exist at `dashboard/` at HEAD `fbb5bb3` with line counts matching the surface map: `trade-ticket.js` (569), `onboarding.js` (1215), `onboarding.css` (554), `settings.html` (654), `settings.css` (1225), `billing.html` (459), `billing.js` (790), `billing.css` (1083), `pricing.html` (229), `marketplace.html` (139), `marketplace.js` (519), `marketplace.css` (613), `dialog-state-mirror.js` (233), `form-dirty-tracker.js` (366). (Settings.js at 1915 lines is TRIM, not CUT — Team C handles it.) (verified by recon agent against HEAD `fbb5bb3`.)

`dashboard/index.html` lines 582-596 contain the 15 `<script>` tags that load CUT files; this is the include block Team A must prune. The file's CUT panels (lines 74-123 session details, 426-473 trade ticket, 488-535 leaderboard-submit-modal) are out of scope for Team A — they belong to Team B's TRIM. (verified by recon agent against HEAD `fbb5bb3`.)

**Files touched:**
- New: `legacy/dashboard-ui/` (directory scaffold)
- New: `legacy/tests/e2e/` (directory scaffold for Team D to fill)
- New: `legacy/README.md` — stub content with pointer to decision record + queue doc + WARNING that this is preserved-but-deactivated code, full content authored by Team F in Session 3.
- Renamed (git-mv): `dashboard/trade-ticket.js` → `legacy/dashboard-ui/trade-ticket.js`
- Renamed (git-mv): `dashboard/onboarding.js` → `legacy/dashboard-ui/onboarding.js`
- Renamed (git-mv): `dashboard/onboarding.css` → `legacy/dashboard-ui/onboarding.css`
- Renamed (git-mv): `dashboard/settings.html` → `legacy/dashboard-ui/settings.html`
- Renamed (git-mv): `dashboard/settings.css` → `legacy/dashboard-ui/settings.css`
- Renamed (git-mv): `dashboard/billing.html` → `legacy/dashboard-ui/billing.html`
- Renamed (git-mv): `dashboard/billing.js` → `legacy/dashboard-ui/billing.js`
- Renamed (git-mv): `dashboard/billing.css` → `legacy/dashboard-ui/billing.css`
- Renamed (git-mv): `dashboard/pricing.html` → `legacy/dashboard-ui/pricing.html`
- Renamed (git-mv): `dashboard/marketplace.html` → `legacy/dashboard-ui/marketplace.html`
- Renamed (git-mv): `dashboard/marketplace.js` → `legacy/dashboard-ui/marketplace.js`
- Renamed (git-mv): `dashboard/marketplace.css` → `legacy/dashboard-ui/marketplace.css`
- Renamed (git-mv): `dashboard/dialog-state-mirror.js` → `legacy/dashboard-ui/dialog-state-mirror.js`
- Renamed (git-mv): `dashboard/form-dirty-tracker.js` → `legacy/dashboard-ui/form-dirty-tracker.js`
- Modified: `dashboard/index.html` — remove `<script>` and `<link>` tags pointing at any of the 14 moved files. Locate the includes block (~lines 582-596 per recon) and prune. Keep `<script>` tags for KEEP files (app.js, modal-controller.js, etc.).
- Modified: `dashboard/leaderboard.html`, `dashboard/auth.html`, `dashboard/landing.html`, `dashboard/verify.html`, `dashboard/setup.html`, `dashboard/agent-guide.html` — grep each for `<script src=` or `<link href=` pointing at any of the 14 moved CUT files; strip those tags. Most pages will have zero hits (they reference different file sets); index.html is the bulk.
- New tag: `pre-ui-cut-2026-05-06` (created BEFORE any moves, pushed to origin) — safety-net for restore.

**Sizing note (>8 files):** This team touches ~21 files but 14 are pure `git-mv` (clean rename diffs auto-recognized by git), 1 is a stub README, ~1-7 are mechanical include-strip edits in HTMLs (most HTMLs will have zero hits). The sizing rule's spirit is reviewable diffs; `git-mv` and pattern-find-and-delete edits do not bloat review surface. Splitting this team adds orchestration overhead for no review-surface benefit. Keeping unified.

**Deliverable:** A safety-net git tag exists locally and on origin; `legacy/dashboard-ui/` and `legacy/tests/e2e/` directories exist with a stub README; 14 CUT files (excluding settings.js which is TRIM in Team C) are relocated to `legacy/dashboard-ui/` with full git history preserved; KEEP HTML pages no longer reference any moved files in `<script>`/`<link>` tags. Production `dashboard/` is now a smaller surface, ready for Team B's panel trim.

**Validation:**
- [ ] `git tag --list pre-ui-cut-*` returns `pre-ui-cut-2026-05-06`.
- [ ] `git ls-remote --tags origin pre-ui-cut-2026-05-06` returns the tag ref.
- [ ] `find dashboard -maxdepth 1 -type f \( -name 'trade-ticket.js' -o -name 'onboarding.js' -o -name 'onboarding.css' -o -name 'settings.html' -o -name 'settings.css' -o -name 'billing.html' -o -name 'billing.js' -o -name 'billing.css' -o -name 'pricing.html' -o -name 'marketplace.html' -o -name 'marketplace.js' -o -name 'marketplace.css' -o -name 'dialog-state-mirror.js' -o -name 'form-dirty-tracker.js' \)` returns NO results (all moved).
- [ ] `find legacy/dashboard-ui -maxdepth 1 -type f` returns the 14 moved files.
- [ ] `git log --follow legacy/dashboard-ui/trade-ticket.js | head -5` returns full pre-move history (sanity-check `git log --follow` works).
- [ ] `grep -rn 'src="trade-ticket\.js\|src="onboarding\.js\|href="onboarding\.css\|src="dialog-state-mirror\.js\|src="form-dirty-tracker\.js' dashboard/*.html` returns zero matches (all stale includes stripped).
- [ ] `legacy/README.md` exists with stub content + WARNING + pointer to `docs/decisions/ui-removal-launch-cut.md` and the queue doc. Stub may be replaced by Team F.

**Agent instructions:**
- Tag FIRST, before any moves: `git tag pre-ui-cut-2026-05-06 main && git push origin pre-ui-cut-2026-05-06`. Capture the output. If the tag push fails (auth, network), STOP and surface the error — do not proceed with moves.
- Use `git mv` for ALL relocations; `mv` followed by `git add`/`rm` breaks `--follow` history.
- Strip includes by editing the HTML files in place. For `dashboard/index.html`, locate lines 582-596 (the `<script>` block per recon) and remove only the lines pointing at moved files. KEEP all other includes intact.
- For the other 6 KEEP HTML pages, run `grep -E 'src="(trade-ticket|onboarding|dialog-state-mirror|form-dirty-tracker)\.js"|href="(onboarding|settings|billing|marketplace)\.css"' dashboard/{auth,landing,leaderboard,verify,setup,agent-guide}.html` to find any references; strip what you find. Most should have zero hits.
- Author `legacy/README.md` as a stub (3-5 lines): "This directory holds dashboard code cut from production for the 2026-05-06 launch. See `docs/decisions/ui-removal-launch-cut.md` and `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md`. Do NOT modify in place — the `lint-no-legacy-edits.sh` pre-commit guard (Team G) will block. To restore: `git checkout pre-ui-cut-2026-05-06 -- dashboard/<file>` or copy from this directory. Full content authored by Team F."
- You MUST `git add` + `git commit` before finishing. Logical commit grouping: (1) tag (already pushed), (2) scaffold legacy/ + stub README, (3) git-mv 14 files, (4) strip stale includes from KEEP HTMLs. One commit per group is fine; more is fine; less than one commit is NOT (an uncommitted worktree loses all work on cleanup).
- Follow the source doc's git-mv approach exactly. Do NOT delete files and re-create them at the new path — that destroys `--follow` history.

---

### Team B: TRIM `dashboard/app.js` + `dashboard/index.html` panels + prune `dashboard/event-contract.md`

**Blocked by:** Team A merged. (Needs `legacy/dashboard-ui/` scaffold for the copy-original-to-legacy step; needs index.html include-strip merged to avoid line-range conflicts.)

**Read these files first:**
- `dashboard/app.js` (full, 2970 lines) — identify all `openTradeTicket`, `closeTradeTicket`, trade-ticket SSE branches, onboarding reach-ins (`window.finletOnboarding?.markStepComplete?.(...)`), and `order:filled` / `onboarding:step-completed` bus subscribers. Recon confirmed `order:filled` subscriber is at line 1562; the rest require a fresh grep at execution time.
- `dashboard/index.html:74-123` (session-details-panel — CUT), `:426-473` (trade-ticket slide-out — CUT), `:488-535` (leaderboard-submit-modal — CUT). Plus all `<dialog>` elements; classify each as CUT-only (remove) or INFRA-shared (keep, e.g., session-info modal, error toasts).
- `dashboard/event-contract.md` (full, 342 lines) — locate the 4 CUT-only event sections to prune; preserve the 3 KEEP event sections.
- `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md:87-111` — Team B scope as drafted.

**Recon evidence:**

`dashboard/app.js` is 2970 lines at HEAD `fbb5bb3` (verified via `wc -l`). Pattern grep confirms `openTradeTicket`, `closeTradeTicket`, and an `order:filled` bus subscriber at line 1562 are present in the file. Onboarding reach-ins of the form `window.finletOnboarding?.markStepComplete?.(...)` are present (count not enumerated by recon — agent must grep at execution). The CUT sections total ~30% of the file (~890 lines) per the source doc's estimate. (verified by recon agent against HEAD `fbb5bb3`.)

`dashboard/index.html` is 598 lines at HEAD `fbb5bb3`. CUT panel locations confirmed at lines 74-123 (session-details-panel), 426-473 (trade-ticket), 488-535 (leaderboard-submit-modal). Lines 582-596 are the `<script>` includes block (Team A's scope, expected to be stripped of CUT-file references before Team B runs). (verified by recon agent against HEAD `fbb5bb3`.)

`dashboard/event-contract.md` is 342 lines documenting 7 events. The 3 KEEP events (`portfolio:updated`, `session:switched`, `auth:state-change`) are consumed by KEEP surfaces (equity curve, app.js chart/metrics refresh, shared-nav.js user menu). The 4 PRUNE events (`order:filled`, `onboarding:step-completed`, `profile:saved`, `strategy:saved`) have only CUT-surface consumers (trade-ticket.js, onboarding.js sub-flows). (verified by recon agent against HEAD `fbb5bb3`.)

**Files touched:**
- New: `legacy/dashboard-ui/app.js` — copy of HEAD `dashboard/app.js` (2970 lines) with a top-of-file comment annotating: "Pre-launch-cut snapshot of dashboard/app.js (commit fbb5bb3, 2026-05-06). Production version trimmed to read-only surfaces. See docs/decisions/ui-removal-launch-cut.md."
- New: `legacy/dashboard-ui/index.html` — copy of HEAD `dashboard/index.html` (598 lines) with the same kind of top comment.
- Modified: `dashboard/app.js` — remove all CUT sections (`openTradeTicket`/`closeTradeTicket` and related handlers, trade-ticket SSE branches, onboarding-step-complete reach-ins, `order:filled` and `onboarding:step-completed` bus subscribers). Estimated ~30% of file removed.
- Modified: `dashboard/index.html` — remove session-details-panel (lines ~74-123), trade-ticket slide-out (lines ~426-473), leaderboard-submit-modal (lines ~488-535), onboarding-checklist DOM, and any other CUT-only `<dialog>` elements. Keep nav, session selector, equity chart, portfolio metrics, positions table, order log (read-only), plugin health.
- Modified: `dashboard/event-contract.md` — remove documentation sections for `order:filled`, `onboarding:step-completed`, `profile:saved`, `strategy:saved`. Update preamble to note: "Pruned during 2026-05-06 launch cut. Removed events: order:filled, onboarding:step-completed, profile:saved, strategy:saved (consumers moved to legacy/dashboard-ui/). See docs/decisions/ui-removal-launch-cut.md." Retain `portfolio:updated`, `session:switched`, `auth:state-change`.

**Deliverable:** `dashboard/app.js` no longer contains trade-ticket or onboarding write-path handlers; `dashboard/index.html` no longer contains CUT panels/modals; `dashboard/event-contract.md` documents only the 3 KEEP events. Pre-trim snapshots of app.js and index.html exist at `legacy/dashboard-ui/` for archaeology. Production read-only surfaces (equity curve, positions table, plugin health, session selector, nav) remain functional.

**Validation:**
- [ ] `grep -n 'openTradeTicket\|closeTradeTicket' dashboard/app.js` returns zero matches.
- [ ] `grep -n "subscribe('order:filled'\|subscribe('onboarding:step-completed'" dashboard/app.js` returns zero matches.
- [ ] `grep -n "window.finletOnboarding" dashboard/app.js` returns zero matches.
- [ ] `grep -nE 'id="trade-ticket"|id="onboarding-checklist"|id="leaderboard-submit-modal"|id="session-details-panel"' dashboard/index.html` returns zero matches.
- [ ] `wc -l dashboard/app.js` is significantly less than 2970 (target: ~2080, allow ±200).
- [ ] `wc -l dashboard/index.html` is significantly less than 598 (target: ~390, allow ±50).
- [ ] `grep -nE "^### \`order:filled\`|^### \`onboarding:step-completed\`|^### \`profile:saved\`|^### \`strategy:saved\`" dashboard/event-contract.md` returns zero matches (sections removed).
- [ ] `grep -nE "^### \`portfolio:updated\`|^### \`session:switched\`|^### \`auth:state-change\`" dashboard/event-contract.md` returns 3 matches (KEEP sections retained).
- [ ] `legacy/dashboard-ui/app.js` exists with `wc -l` ≈ 2970 (full pre-trim snapshot).
- [ ] `legacy/dashboard-ui/index.html` exists with `wc -l` ≈ 598.
- [ ] `head -3 legacy/dashboard-ui/app.js` shows the snapshot annotation comment.
- [ ] Production dashboard loads without console errors when accessed locally (smoke check; full e2e verification happens in Team E).

**Agent instructions:**
- Copy-then-trim pattern (Path A from source doc): `cp dashboard/app.js legacy/dashboard-ui/app.js && git add legacy/dashboard-ui/app.js`, then add the snapshot comment to the legacy file, then trim the in-place `dashboard/app.js`. Do NOT use `git mv` for app.js — it's TRIM, not CUT, and the production file stays.
- Same pattern for `dashboard/index.html`.
- For app.js trim: identify CUT regions by grepping for `openTradeTicket`, `closeTradeTicket`, `'order:filled'`, `'onboarding:step-completed'`, `window.finletOnboarding`. Find the function/block boundaries and remove cleanly. Do not leave orphaned helper functions that only the removed code called.
- For index.html trim: remove the four CUT regions (session-details-panel, trade-ticket, leaderboard-submit-modal, onboarding-checklist DOM). Walk all `<dialog>` elements; if a dialog's only callers are in moved CUT files, remove it. KEEP infrastructure dialogs that future read-only surfaces might use (e.g., generic error toast, session-info viewer).
- For event-contract.md prune: remove the 4 PRUNE event sections by H3 header. Update the preamble paragraph to reference the launch cut. Retain section ordering for the 3 KEEP events.
- You MUST `git add` + `git commit` before finishing. Suggested commits: (1) snapshot copies to legacy/, (2) app.js trim, (3) index.html trim, (4) event-contract.md prune. One commit per file is fine; minimum is one commit total.
- After your changes, run `python -m http.server 8000 --directory dashboard` (or whatever the dev server convention is) and load `http://localhost:8000/index.html` in a browser to confirm the page loads without console errors. If it does NOT load, fix before committing — broken main blocks all downstream teams.

---

### Team C: TRIM `dashboard/settings.js` (extract API keys) + `dashboard/leaderboard-submit.js` + comment `dashboard/modal-controller.js`

**Blocked by:** Team A merged. (Needs `legacy/dashboard-ui/` scaffold for the git-mv and copy targets.) Parallel with Team B (no shared files).

**Read these files first:**
- `dashboard/settings.js:684-716` — `initApiKeys()` and `loadApiKeys()` functions, the read-only API key listing logic to extract.
- `dashboard/leaderboard-submit.js:21,36,60` — submit-modal initialization, close handler, and form submit handler (CUT regions; identify boundaries for in-place trim).
- `dashboard/modal-controller.js` (full, 267 lines) — confirm it's standalone infra (no CUT-consumer-only state machines) and identify any imports that would become dead.
- `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md:87-111` (full Team B scope from source doc; my Team C is a sub-split).

**Recon evidence:**

`dashboard/settings.js` is 1915 lines at HEAD `fbb5bb3`. The API-key read-only logic spans `initApiKeys()` at line 684 and `loadApiKeys()` at line 716; these functions list keys, render masked values, and wire a revoke button. Both are read-only (DELETE-only, no create/update via UI). The other ~92% of the file is profile-edit, plugin-install/configure, billing, password-change, danger-zone — all CUT-class write-path forms. (verified by recon agent against HEAD `fbb5bb3`.)

`dashboard/leaderboard-submit.js` is 497 lines at HEAD `fbb5bb3`. The submit-modal logic occupies ~23% of the file (lines 21 init, 36 close, 60 form-submit) — these are the CUT regions. The remaining ~77% is leaderboard-table rendering and read-only consumers. (verified by recon agent against HEAD `fbb5bb3`.)

`dashboard/modal-controller.js` is 267 lines at HEAD `fbb5bb3` and contains no CUT-consumer-only state machines (head-of-file inspection confirms vanilla modal infra: open, close, focus-trap, escape-handler — all reusable). No imports point at CUT files. (verified by recon agent against HEAD `fbb5bb3`.)

**Files touched:**
- Renamed (git-mv): `dashboard/settings.js` → `legacy/dashboard-ui/settings.js` (full 1915-line file relocates).
- New: `dashboard/api-keys.js` — extracted API-key listing logic (~150 lines), derived from `legacy/dashboard-ui/settings.js:684-716` plus any helpers those functions call. Top-of-file comment explains origin.
- New: `dashboard/api-keys.html` — minimal page (target ~80 lines), nav include via shared-nav.js, hosts the API-key listing only. Replaces the API-key-management portion of the cut `settings.html`.
- New: `legacy/dashboard-ui/leaderboard-submit.js` — copy of HEAD `dashboard/leaderboard-submit.js` (497 lines) with snapshot comment.
- Modified: `dashboard/leaderboard-submit.js` — TRIM in place, remove the submit-modal CUT region (~115 lines per 23% estimate), keep the table-rendering logic. Note: filename retains "submit" but content no longer has a submit modal. Add a TODO comment near the top: "TODO: rename to leaderboard-table.js in a follow-up; submit logic moved to legacy/ on 2026-05-06."
- Modified: `dashboard/modal-controller.js` — add a one-line top comment: "Modal controller — currently zero callers post-2026-05-06 launch cut. Retained for future read-only modal use. See docs/decisions/ui-removal-launch-cut.md."

**Deliverable:** `dashboard/settings.js` no longer exists (relocated to legacy/); a minimal `dashboard/api-keys.js` + `dashboard/api-keys.html` pair exposes the only KEEP read-only surface from the original settings page (API key list + revoke). `dashboard/leaderboard-submit.js` is trimmed in place, table-rendering preserved, modal removed. `dashboard/modal-controller.js` has a comment marking its post-cut state.

**Validation:**
- [ ] `find dashboard -maxdepth 1 -name 'settings.js'` returns NO results.
- [ ] `find legacy/dashboard-ui -maxdepth 1 -name 'settings.js'` returns one result.
- [ ] `git log --follow legacy/dashboard-ui/settings.js | head -5` returns full pre-move history.
- [ ] `dashboard/api-keys.js` exists, contains `loadApiKeys` (or equivalent function), is referenced from `dashboard/api-keys.html`.
- [ ] `dashboard/api-keys.html` exists, includes `<script src="api-keys.js">`, includes shared-nav.js, has nav link styling consistent with other KEEP pages.
- [ ] `wc -l dashboard/api-keys.js` is roughly 100-200 (extraction, not whole-file copy).
- [ ] `legacy/dashboard-ui/leaderboard-submit.js` exists with `wc -l` ≈ 497.
- [ ] `wc -l dashboard/leaderboard-submit.js` is significantly less than 497 (target: ~380, allow ±50).
- [ ] `grep -nE 'submit-modal|leaderboard-submit-modal' dashboard/leaderboard-submit.js` returns zero matches.
- [ ] `head -1 dashboard/modal-controller.js` shows the post-cut annotation comment.
- [ ] Loading `http://localhost:8000/api-keys.html` in a browser shows the API-key listing without console errors (assumes a logged-in session; tester can use auth.js stub if needed).
- [ ] Loading `http://localhost:8000/leaderboard.html` still renders the table (handled by Team E end-to-end, but smoke-check here).

**Agent instructions:**
- Use `git mv dashboard/settings.js legacy/dashboard-ui/settings.js` (preserves `--follow`).
- For `api-keys.js` extraction: read `legacy/dashboard-ui/settings.js:684-716` AFTER the move, plus any helpers those functions call (look for shared utilities like `formatApiKey`, `revokeKey`, etc.). Copy ONLY the API-key-related code into the new `dashboard/api-keys.js`. If a helper is also used by a CUT function, you can re-derive a minimal copy in api-keys.js or import it from `dashboard/api-utils.js` if it exists there.
- For `api-keys.html`: lift the API-key DOM section from the now-legacy `settings.html` (or write fresh; whichever is smaller). Include `<script src="auth-guard.js">` (KEEP) and `<script src="shared-nav.js">` (KEEP) so nav + auth gating work consistently.
- For `leaderboard-submit.js` trim: `cp dashboard/leaderboard-submit.js legacy/dashboard-ui/leaderboard-submit.js && git add legacy/dashboard-ui/leaderboard-submit.js`, add the snapshot comment to the legacy file, then trim the in-place dashboard file. Identify the CUT region around lines 21, 36, 60 — find the modal-related function block boundaries and remove cleanly. Keep the table-rendering portion intact.
- Add the modal-controller.js comment as a single line near the top of the file (after any existing license/copyright header).
- You MUST `git add` + `git commit` before finishing. Suggested commits: (1) git-mv settings.js to legacy + create api-keys.js + create api-keys.html, (2) snapshot leaderboard-submit.js to legacy + trim in-place, (3) modal-controller.js comment.
- Browser smoke test on `api-keys.html` is REQUIRED before commit. If the page 500s or errors, fix before committing.

---

### Team D: git-mv 9 CUT e2e tests + update `playwright.config.ts`

**Blocked by:** Team A merged. (Needs `legacy/tests/e2e/` scaffold.) Parallel with Teams B and C (no shared files).

**Read these files first:**
- `tests/e2e/journey-12-forgot-password.spec.ts` (first 50 lines) — RECLASSIFICATION CHECK: source doc and surface map flag this for review. If the test exercises only the forgot-password / password-reset auth flow (no settings or trade UI), it should KEEP, not move. Decide during execution and document the call.
- `playwright.config.ts` (full) — locate the test path glob / project config; identify where to add a `testIgnore` for `legacy/tests/e2e/`.
- `package.json` — locate the existing `test:e2e` npm script; add a sibling `test:legacy-e2e` script for archaeological/restore use.
- `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md:118-136` — Team C scope from source doc (corresponds to my Team D, sub-split for sizing).
- `docs/bug-hunt/20260507T042257Z3c76/surface_map.md:167-176` — CUT e2e test list.

**Recon evidence:**

The 9 CUT e2e tests at HEAD `fbb5bb3` per surface map: `journey-05-trade.spec.ts`, `journey-06a-settings-profile.spec.ts`, `journey-06b-settings-plugins.spec.ts`, `journey-06c-settings-billing.spec.ts`, `journey-06d-settings-danger-zone.spec.ts`, `journey-08-billing.spec.ts`, `journey-12-forgot-password.spec.ts` (FLAGGED FOR RECLASSIFICATION), `journey-onboarding.spec.ts`, `journey-modal-stacking.spec.ts`. (verified by recon agent against HEAD `fbb5bb3`.)

**Files touched:**
- Renamed (git-mv): `tests/e2e/journey-05-trade.spec.ts` → `legacy/tests/e2e/journey-05-trade.spec.ts`
- Renamed (git-mv): `tests/e2e/journey-06a-settings-profile.spec.ts` → `legacy/tests/e2e/journey-06a-settings-profile.spec.ts`
- Renamed (git-mv): `tests/e2e/journey-06b-settings-plugins.spec.ts` → `legacy/tests/e2e/journey-06b-settings-plugins.spec.ts`
- Renamed (git-mv): `tests/e2e/journey-06c-settings-billing.spec.ts` → `legacy/tests/e2e/journey-06c-settings-billing.spec.ts`
- Renamed (git-mv): `tests/e2e/journey-06d-settings-danger-zone.spec.ts` → `legacy/tests/e2e/journey-06d-settings-danger-zone.spec.ts`
- Renamed (git-mv): `tests/e2e/journey-08-billing.spec.ts` → `legacy/tests/e2e/journey-08-billing.spec.ts`
- CONDITIONAL Renamed (git-mv): `tests/e2e/journey-12-forgot-password.spec.ts` → `legacy/tests/e2e/journey-12-forgot-password.spec.ts` — ONLY IF the test exercises settings/trade UI; if it's auth-only (forgot-password flow), KEEP it in place and note the reclassification decision in the commit message.
- Renamed (git-mv): `tests/e2e/journey-onboarding.spec.ts` → `legacy/tests/e2e/journey-onboarding.spec.ts`
- Renamed (git-mv): `tests/e2e/journey-modal-stacking.spec.ts` → `legacy/tests/e2e/journey-modal-stacking.spec.ts`
- Modified: `playwright.config.ts` — add `testIgnore: ['**/legacy/**']` (or equivalent for the playwright version in use) to the project config so default `npm run test:e2e` does not pick up legacy tests.
- Modified: `package.json` — add `test:legacy-e2e` script that explicitly targets `legacy/tests/e2e/` (e.g., `playwright test --config legacy.playwright.config.ts` or `playwright test legacy/tests/e2e`).

**Deliverable:** 8 or 9 CUT e2e tests are relocated to `legacy/tests/e2e/` with `--follow` history preserved; default `npm run test:e2e` runs only production tests; `npm run test:legacy-e2e` exists for explicit legacy-test invocation; reclassification decision on `journey-12-forgot-password` is documented in commit message.

**Validation:**
- [ ] `find tests/e2e -maxdepth 1 -name 'journey-{05,06a,06b,06c,06d,08,onboarding,modal-stacking}*'` returns NO results.
- [ ] `find legacy/tests/e2e -maxdepth 1 -name 'journey-{05,06a,06b,06c,06d,08,onboarding,modal-stacking}*'` returns 8 results.
- [ ] `journey-12-forgot-password.spec.ts` location matches the reclassification decision (KEEP at `tests/e2e/` if auth-only; MOVE to `legacy/tests/e2e/` if it touches settings UI). Commit message documents the call.
- [ ] `git log --follow legacy/tests/e2e/journey-05-trade.spec.ts | head -5` returns full pre-move history.
- [ ] `npm run test:e2e -- --list` (or playwright's discovery command) does NOT list any tests under `legacy/`.
- [ ] `npm run test:legacy-e2e -- --list` lists the moved tests (they may FAIL when run because the surfaces are gone; the script is for explicit invocation only — Team E does not enforce that legacy tests pass).

**Agent instructions:**
- Read the first 50 lines of `tests/e2e/journey-12-forgot-password.spec.ts` BEFORE moving anything. Decide: does it exercise auth-only (forgot-password flow on `auth.html`/`verify.html`) → KEEP, or does it touch settings/trade UI → CUT. Document the call in the team's commit message.
- Use `git mv` for ALL 8 (or 9) test relocates.
- For `playwright.config.ts`: open the file, locate the projects array or testDir + testMatch config, add `testIgnore: ['**/legacy/**', '**/legacy/tests/**']` (use whichever pattern fits the existing config style). If the existing config uses a different exclusion pattern, mirror it.
- For `package.json`: add `test:legacy-e2e` next to `test:e2e`. If `test:e2e` is `playwright test`, then `test:legacy-e2e` could be `playwright test legacy/tests/e2e --config legacy.playwright.config.ts` (which you'd also need to create as a thin wrapper) OR simpler: `playwright test --testIgnore '' legacy/tests/e2e` if the config supports per-invocation overrides. Choose the simplest approach that works with the project's playwright version.
- You MUST `git add` + `git commit` before finishing. Suggested commits: (1) git-mv 8-9 e2e tests, (2) playwright.config.ts + package.json updates.
- Run `npm run test:e2e -- --list` AFTER your config change to confirm the production test run no longer enumerates the moved tests. If it still does, the testIgnore pattern is wrong — fix before committing.

---

### Team E: Update assertions in remaining KEEP + INFRA tests against trimmed dashboard surface

**Blocked by:** Teams A, B, C, D all merged. (Trimmed dashboard surfaces and moved tests must all be in place before assertions are tuned.)

**Read these files first:**
- `tests/e2e/journey-04-dashboard.spec.ts` — likely contains assertions for trade-ticket button or session-details-panel visibility that no longer exists; needs updating.
- `tests/e2e/journey-09-mobile.spec.ts` — mobile drawer test may assert on "Manage Plugins" or other CUT drawer items; update or remove those assertions.
- All remaining `tests/e2e/journey-*.spec.ts` files (post-Team-D) — run `npm run test:e2e` and identify which tests fail against the trimmed dashboard. Fix each failing assertion to reference a KEEP surface.
- `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md:128-131` — Team C scope item 2-3 (KEEP/INFRA test verification + assertion updates).

**Recon evidence:**

The 9 KEEP e2e tests per surface map: `journey-01-landing`, `journey-02-signup`, `journey-03-login`, `journey-04-dashboard`, `journey-07-leaderboard`, `journey-10-authguard`, `journey-14-cli-session`, `journey-15-cli-plugins`, `journey-shared-nav`. The 7-8 INFRA e2e tests per surface map: `journey-09-mobile`, `journey-11-keyboard`, `journey-13-cli-serve`, `journey-16-benchmark-blindness`, `journey-17-csrf-hydration`, `journey-sim-time-tile`, `journey-trusted-types` (count drift between surface map header and body — Team D / E to verify actual count). Several KEEP/INFRA tests are expected to have stale assertions that referenced CUT-surface DOM. (verified by recon agent against HEAD `fbb5bb3`.)

**Files touched:**
- Modified (estimated 3-6 files based on which tests fail): `tests/e2e/journey-{04,09,…}.spec.ts` — update assertions that reference removed DOM (e.g., `id="trade-ticket"`, `aria-label="Manage Plugins"`, etc.) to either remove the assertion (if the surface is gone for good) or point at an equivalent KEEP surface.
- Possibly: deletion of test BLOCKS that exercise CUT-only flows within otherwise-KEEP tests (e.g., a `describe('trade ticket')` block inside `journey-04-dashboard.spec.ts` would be removed entirely; the rest of the test stays).

**Deliverable:** `npm run test:e2e` is fully green against the trimmed dashboard. No test is skipped; no assertion is updated to a hollow `expect(true).toBe(true)` placeholder. Each assertion either correctly tests a KEEP surface or is removed as part of the CUT.

**Validation:**
- [ ] `npm run test:e2e` exits 0 with all production tests passing.
- [ ] No new `test.skip` calls introduced (would mask regressions).
- [ ] No `expect(true).toBe(true)` or equivalent hollow assertions introduced.
- [ ] `git diff main -- tests/e2e/` shows assertion updates only — no test files added or deleted (those moves were Team D's scope).

**Agent instructions:**
- Run `npm run test:e2e` first and capture failures. Each failure points at a stale assertion.
- For each failure: read the failing assertion, decide whether (a) the surface it tests is GONE (remove the assertion or its containing `it`/`test` block), or (b) the surface MOVED to a KEEP location (update the selector/assertion to the new location), or (c) the test should fail and we need to update the dashboard (rare — Team B/C should have caught it; raise to user if you encounter this).
- Do NOT add `test.skip` to mask failures. Do NOT replace assertions with `expect(true).toBe(true)`.
- After every fix, re-run the affected test file to confirm green before moving to the next failure.
- Final pass: `npm run test:e2e` green end-to-end.
- You MUST `git add` + `git commit` before finishing. One commit per logical concern (e.g., "remove trade-ticket assertions from journey-04-dashboard") is fine.

---

### Team F: Documentation sweep + CLAUDE.md + ARCHITECTURE.md + README.md + LESSONS.md + REMAINING_TASKS.md + legacy/README.md full content + ledger close-out

**Blocked by:** Body work has no blockers and runs in parallel with A/B/C/D/G. The FINAL ship-stamp commit on `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` (`status: shipped`) waits for ALL other teams (A, B, C, D, E, G) to merge.

**Read these files first:**
- `docs/ARCHITECTURE.md` — locate sections describing UI write paths (onboarding wizard, trade ticket, settings forms, plugin install UI, billing UI, marketplace UI). Major revision.
- `README.md` — quickstart section currently leads with web UI; update to lead with CLI/MCP.
- `CLAUDE.md:31-34` — convention block referencing form-dirty-tracker, dialog-state-mirror, onboarding registries, trade-ticket render-on-read. Annotate each as `legacy/`-only or remove.
- `docs/REMAINING_TASKS.md` — locate UI-bug TODOs the cut retires; mark closed.
- `docs/LESSONS.md` — append meta-lesson at end.
- `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md:140-164` — Team D scope from source doc (corresponds to my Team F).
- `legacy/README.md` (after Team A merges) — stub content to replace with full content.

**Recon evidence:**

`/Users/justnau/finlet/CLAUDE.md` is 104 lines at HEAD `fbb5bb3`. Lines 31-34 contain the dashboard convention block: line 31 is the trusted-types + event-bus invariants (KEEP — still active); line 32 is the form-dirty-tracker convention referencing `dashboard/form-dirty-tracker.js` (which moves to legacy/); line 33 is the dialog-state-mirror convention with the trade-ticket render-on-read exception (`docs/decisions/trade-ticket-render-on-read.md` — exception becomes legacy); line 34 is the onboarding checklist + wizard step registry convention (modules move to legacy/). (verified by recon agent against HEAD `fbb5bb3`.)

**Files touched:**
- Modified: `docs/ARCHITECTURE.md` — major revision. Replace UI-write-path descriptions with a "2026-05-06 launch cut" section explaining the agent-first positioning, point at `docs/decisions/ui-removal-launch-cut.md`. Note that 8 write-path API routes still exist for CLI/MCP but no UI consumes them.
- Modified: `README.md` — quickstart leads with `npm install -g finlet && finlet quickstart` (or whatever the current install path is). Web-UI section reframed as "monitoring dashboard for your agent's sessions."
- Modified: `CLAUDE.md` — update lines 32-34 dashboard conventions: form-dirty-tracker invariant → "applies to `legacy/dashboard-ui/` only — production dashboard has no forms"; dialog-state-mirror invariant → same treatment, plus note that the trade-ticket render-on-read exception is legacy; onboarding registry invariant → same treatment. KEEP line 31 (trusted-types + event-bus invariants apply to read-only surfaces).
- Modified: `docs/REMAINING_TASKS.md` — add a "2026-05-06: UI write-path cut" section. Close any UI-bug TODOs the cut retires (grep the file for trade-ticket, onboarding, settings-form, plugin-install-UI references).
- Modified: `docs/LESSONS.md` — append: "When >90% of bug-hunt findings cluster in a UI surface that the launch user (an LLM agent) doesn't touch, the answer is to cut the surface, not refactor it. Twelve refactors with 50% effectiveness on the same dashboard cluster were the trigger. See docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md."
- Modified: `legacy/README.md` — replace Team A's stub with full content. Sections: "Why this exists" (link decision record), "What's here" (link surface map), "How to restore" (two paths: `cp -r legacy/dashboard-ui/foo dashboard/foo` OR `git checkout pre-ui-cut-2026-05-06 -- dashboard/foo`), "Do NOT modify" (the pre-commit guard from Team G blocks; explain why), "Security note" (legacy code frozen as of 2026-05-06, may not meet current security standards — security review required if restoring).
- Modified: `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` — set `status: shipped`, fill `shipped: 2026-05-07`, populate `shipped_in: <commit-sha-or-PR-ref>`. THIS COMMIT IS LAST — after all other teams have merged.

**Deliverable:** All affected docs reflect the post-cut reality; CLAUDE.md no longer claims invariants that point at moved modules without annotation; legacy/README.md guides future restorers; queue doc is stamped shipped.

**Validation:**
- [ ] `grep -nE 'trade ticket|trade-ticket|onboarding wizard|settings form|plugin install UI|billing UI' docs/ARCHITECTURE.md` returns either zero matches OR matches that are within the new "launch cut" section (not lingering production descriptions).
- [ ] `head -30 README.md` shows CLI/MCP-led quickstart, NOT "go to finlet.dev and click Sign Up".
- [ ] `grep -nE 'form-dirty-tracker|dialog-state-mirror|trade-ticket-render-on-read|onboarding.*registries' CLAUDE.md` returns matches that include "legacy/" annotations OR are removed entirely.
- [ ] `docs/REMAINING_TASKS.md` contains a "2026-05-06: UI write-path cut" section.
- [ ] `tail -20 docs/LESSONS.md` contains the new meta-lesson paragraph.
- [ ] `legacy/README.md` is no longer a stub — has all 5 sections (Why, What, How to restore, Do NOT modify, Security note).
- [ ] `grep '^status:' docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` returns `status: shipped` (final commit only).
- [ ] `grep '^shipped:' docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` returns `shipped: 2026-05-07`.

**Agent instructions:**
- Body work (ARCHITECTURE.md, README.md, CLAUDE.md, REMAINING_TASKS.md, LESSONS.md, legacy/README.md) can run in parallel with the other teams. Make those edits any time after Team A merges (legacy/README.md needs Team A's stub to replace).
- The ship-stamp commit on `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` is your LAST work item. Wait until you have confirmation that A, B, C, D, E, G have all merged. Then update the frontmatter and commit.
- For the body edits: be thorough but not verbose. If a doc section is replaced, write fewer paragraphs than were removed — the cut narrative is "less surface, more focus", not "ten more pages of architecture text".
- For CLAUDE.md: the simplest edit is to add a parenthetical to each affected invariant. E.g., "...(applies to `legacy/dashboard-ui/` only — production dashboard has no forms post-2026-05-06 launch cut)". Do NOT delete the invariants outright — they may apply if anyone restores from legacy/.
- You MUST `git add` + `git commit` before finishing. Suggested: one commit per doc file is fine; minimum is one commit total for body work + one commit for the final ship-stamp.

---

### Team G: CI guards + pre-commit hook + .gitattributes + ci.yml + deploy.yml legacy/ exclusions

**Blocked by:** Teams A, B, C, D all merged. (legacy/ structure must be stable; otherwise the migration commits get blocked by the new pre-commit guard.)

**Read these files first:**
- `scripts/git-hooks/pre-commit:35-84` — existing trusted-types and event-bus guards as the pattern to follow.
- `scripts/lint-trusted-types.sh` — minimal example of the lint script form.
- `scripts/lint-event-bus.sh` — same.
- `scripts/setup-git-hooks.sh` — installer to update for the new hook.
- `.github/workflows/ci.yml` (full, ~39 lines) — locate the pytest, ruff, mypy lines to add `--ignore=legacy/`.
- `.github/workflows/deploy.yml` — locate the dashboard-deploy step to verify legacy/ is not bundled.
- `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md:167-188` — Team E scope from source doc (corresponds to my Team G).

**Recon evidence:**

`/Users/justnau/finlet/scripts/git-hooks/pre-commit` is 87 lines at HEAD `fbb5bb3` and calls `bash "$LINT_SCRIPT" --check` at line 53 (trusted-types) and `bash "$LINT_BUS" --check` at line 77 (event-bus). Lines 35-60 wrap the trusted-types check in fallback logic; lines 62-84 wrap the event-bus check similarly. Pattern for adding a third guard is well-established. (verified by recon agent against HEAD `fbb5bb3`.)

`.github/workflows/ci.yml` at HEAD `fbb5bb3` runs `ruff check finlet/ tests/` (line 28; already scoped, no legacy yet), `mypy finlet/` (line 31; already scoped), and `pytest --cov=finlet` (line 38; coverage scoped to finlet/, but pytest itself may collect tests under legacy/ once the directory exists). Team G adds `--ignore=legacy/` to pytest. ruff and mypy already exclude legacy/ implicitly because their input paths (`finlet/`, `tests/`) don't include it. (verified by recon agent against HEAD `fbb5bb3`.)

`.gitattributes` does NOT exist at HEAD `fbb5bb3` — `cat .gitattributes` returned "No .gitattributes file found." Team G creates it. (verified by recon agent against HEAD `fbb5bb3`.)

**Files touched:**
- New: `scripts/lint-no-legacy-edits.sh` — pre-commit hook script. Logic: `git diff --cached --name-only --diff-filter=M | grep -E '^legacy/' && exit 1`. Note: `--diff-filter=M` means MODIFIED only, so initial migration commits (which have ADDED files under legacy/) pass. Mirror the structure of `lint-trusted-types.sh` (shebang, --check arg, exit codes).
- Modified: `scripts/git-hooks/pre-commit` — add a third guard call (mirroring lines 53 and 77) that invokes `lint-no-legacy-edits.sh`.
- Modified: `scripts/setup-git-hooks.sh` — install the new `lint-no-legacy-edits.sh` hook alongside existing ones (it's already symlinked via the master pre-commit, so this might just be a no-op confirmation; verify).
- New: `.gitattributes` — content: `legacy/** linguist-vendored\nlegacy/** linguist-generated=true\n`.
- Modified: `.github/workflows/ci.yml` — add `--ignore=legacy/` to the pytest command (line 38). Verify ruff (`finlet/ tests/`) and mypy (`finlet/`) still scope correctly post-migration. If npm test runs are added to ci.yml in the future, ensure they exclude legacy/tests/.
- Modified: `.github/workflows/deploy.yml` — verify the dashboard-build/deploy step does NOT bundle `legacy/`. If the deploy uses `dashboard/**` or `dashboard/` as the source, no change needed. If it uses a broader glob, add an exclusion.

**Deliverable:** Pre-commit hook blocks future modifications under legacy/ while allowing the current migration commits; CI does not collect legacy/ tests; deploy artifact does not include legacy/; `.gitattributes` collapses legacy/ diffs in PR review and excludes from language stats.

**Validation:**
- [ ] `git commit` with a STAGED MODIFICATION under `legacy/` is BLOCKED by pre-commit (test by adding a trivial change to `legacy/dashboard-ui/trade-ticket.js` and attempting commit; expect non-zero exit and clear error message).
- [ ] `git commit` with a STAGED ADDITION under `legacy/` SUCCEEDS (initial migration must remain replayable; test by creating `legacy/scratch.txt`, staging it, and attempting commit; expect success).
- [ ] `cat .gitattributes` returns the two `legacy/**` rules.
- [ ] `grep -E 'pytest|--ignore=legacy' .github/workflows/ci.yml` confirms `--ignore=legacy/` is on the pytest line.
- [ ] `gh workflow view ci.yml` (if gh CLI available) or a direct CI run on a feature branch passes without picking up legacy/ tests.
- [ ] Deployed dashboard at finlet.dev does NOT serve any path under `/legacy/` (post-deploy smoke test; if pre-deploy, just confirm the deploy artifact excludes legacy/ — `deploy.yml` source paths confirm).

**Agent instructions:**
- Author `scripts/lint-no-legacy-edits.sh` by reading `scripts/lint-trusted-types.sh` first and mirroring its structure. Use shebang `#!/usr/bin/env bash`, accept `--check` arg, exit non-zero with a clear error message on violation.
- Test the hook locally BEFORE committing: stage a modification to `legacy/dashboard-ui/trade-ticket.js`, run `bash scripts/lint-no-legacy-edits.sh --check`, expect non-zero exit. Then unstage and stage an ADDITION to `legacy/scratch.txt`, run again, expect zero exit.
- For pre-commit hook integration: read lines 35-84 of `scripts/git-hooks/pre-commit` and append a third block following the same pattern (LINT_SCRIPT_3, run, capture exit, etc.).
- For setup-git-hooks.sh: the existing setup symlinks the master pre-commit hook, which calls all three lint scripts. So the new lint script is auto-installed once the master hook is updated. Verify by re-running setup-git-hooks.sh and checking the symlink is intact.
- For .gitattributes: create at repo root with the two lines. Test by running `git check-attr --all -- legacy/dashboard-ui/trade-ticket.js` and confirming `linguist-vendored: set` and `linguist-generated: true` appear.
- For ci.yml: locate the pytest line and add `--ignore=legacy/` flag. Do NOT remove existing flags.
- For deploy.yml: read the deploy step. If the deploy source is `dashboard/` (clean), no change needed but verify. If broader, add exclusion.
- You MUST `git add` + `git commit` before finishing. Suggested commits: (1) lint script + pre-commit hook update + setup script verification, (2) .gitattributes, (3) ci.yml + deploy.yml updates.

---

### Team H: API route audit (optional, may defer to next iteration)

**Blocked by:** none — independent.

**Read these files first:**
- `finlet/api/` (all routes) — locate the 8 write-path routes flagged in the surface map.
- `finlet/cli.py` — search for HTTP calls or service invocations that point at each write-path route.
- `finlet/mcp/tools_*.py` — search for MCP tool definitions that consume each write-path route.
- `docs/bug-hunt/20260507T042257Z3c76/surface_map.md:220-228` — write-path route list.

**Recon evidence:**

The 8 write-path API routes per surface map: `POST /api/sessions/<id>/orders`, `PATCH /api/sessions/<id>/settings`, `POST /api/me/profile`, `POST /api/me/password`, `POST /api/me/plugins/<id>/install`, `PATCH /api/me/plugins/<id>/config`, `POST /api/subscriptions/plans/<id>`, `POST /api/me/account/delete`. Recon spot-checked two: `finlet/cli.py:604-650` defines the `order` CLI command which posts to `/sessions/{session}/trade/order` (one route confirmed live); `finlet/mcp/tools_trading.py:18-80` defines the `submit_order` MCP tool delegating to `svc_submit_order()`. The other 6 routes' consumer status is unverified — that's exactly what this audit produces. (verified by recon agent against HEAD `fbb5bb3`.)

**Files touched:**
- New: `docs/bug-hunt/20260507T042257Z3c76/api_route_audit.md` — report. One section per route. Each section: route path → consumer (CLI command name, MCP tool name, or "ORPHANED — no CLI/MCP consumer found"). For ORPHANED routes, recommend follow-up refactor in a future iteration.

**Deliverable:** Audit report at `docs/bug-hunt/20260507T042257Z3c76/api_route_audit.md` with one line per route categorizing its consumer status. Informs next /bug-hunt iteration's planning. NO production code changes in this team — audit only.

**Validation:**
- [ ] Report file exists.
- [ ] Report contains 8 sections, one per route.
- [ ] Each section has a verdict: CLI consumer (with command name) / MCP consumer (with tool name) / ORPHANED.
- [ ] Audit method documented at top of report (search patterns used, which files were grep'd).

**Agent instructions:**
- This team is OPTIONAL. If execution time is constrained, skip and queue for next iteration.
- For each route, search:
  - `finlet/cli.py` and other CLI command files for HTTP calls matching the route path (e.g., `/sessions/.+/orders`, `/me/profile`).
  - `finlet/mcp/tools_*.py` for MCP tool definitions that delegate to a service which calls the route.
- Categorize each route. For ambiguous cases (route is referenced by a service that's not exposed via CLI/MCP), flag as "INDIRECT — exposed via internal service; review before deletion."
- You MUST `git add` + `git commit` before finishing. One commit is fine.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A and Team B both touch `dashboard/index.html`; merge conflict if run in parallel | High if parallel | High (lost work, conflict resolution overhead) | Hard sequence A→B in dependency graph; A merges first, B rebases. Documented in File Conflict Table. |
| Pre-commit hook from Team G blocks legitimate migration commits | Low | Critical (would block the entire refactor mid-flight) | Hook uses `--diff-filter=M` (modifications only); ADDED files pass. Team G runs AFTER A/B/C/D merge so all migration commits are already on main before the guard activates. |
| `journey-12-forgot-password.spec.ts` misclassified — moved to legacy/ but should be KEEP | Medium | Medium (auth coverage gap) | Team D reads first 50 lines and decides; documents call in commit message. If wrong post-hoc, easy to git-mv back. |
| Cloudflare Pages cache serves old dashboard for up to 24h after deploy | High | Low (transient) | Accept the transition window; Team G can add a cache purge step in deploy.yml if desired. Out of scope for this iteration. |
| Existing user bookmarks to `/settings.html`, `/billing.html`, `/marketplace.html` 404 | Medium | Low (small launch user base) | 301 redirects are explicitly OUT OF SCOPE per source doc. Flag as a follow-up if user traffic warrants. |
| CI/deploy globs `dashboard/**` and breaks when an include resolves to a moved file | Low (Team A strips includes) | High | Team A validation includes the grep that confirms zero stale includes. Team E e2e tests catch any runtime breakage before merge. |
| Legacy code accumulates security debt that goes unscanned | Medium | Medium (only matters if restored) | Team F's `legacy/README.md` includes a "security review required if restoring" note. Periodic reminder is the only ongoing process needed. |
| `dashboard/api-keys.html` (new minimal page) breaks because shared-nav.js or auth-guard.js can't find their dependencies | Low | High (breaks API-key surface) | Team C smoke-tests `api-keys.html` in a browser before commit. Team E e2e adds an assertion (or extends `journey-shared-nav` to cover `api-keys.html`). |
| Team B trims a panel that an INFRA test depends on (e.g., a modal used by a keyboard test) | Medium | Medium (test breaks, fixable in Team E) | Team E's job IS to fix these. Expected outcome, not a blocker. |
| `legacy/dashboard-ui/app.js` snapshot is stale from the moment Team B trims the production version (no longer reflects HEAD pre-trim) | High (by design) | Low (this IS the design) | The snapshot's purpose is restorability to the 2026-05-06 state, not perpetual mirroring. Document in legacy/README.md. |
| Team F authors `legacy/README.md` content that conflicts with Team A's stub and overwrites in surprising ways | Low | Low | Team A's stub is intentionally minimal (3-5 lines); Team F's full content REPLACES wholesale. No merge conflict semantically. |

## Session Plan

### Session 1: Pre-cut foundation (Team A solo)

**Sequential:** Team A runs alone — it creates the safety-net tag, scaffolds `legacy/` structure, and relocates 14 CUT files. Every other team depends on this foundation.

**Merge order:** A merges first → targeted validation (run validation checklist from Team A's spec).

**Session checkpoint:** Confirm `git tag --list pre-ui-cut-2026-05-06` returns the tag, `legacy/dashboard-ui/` and `legacy/tests/e2e/` exist with stub README, all 14 CUT files relocated. Smoke-load `dashboard/index.html` in a browser (it should still load, just with some console errors about missing scripts — those clear in Session 2).

### Session 2: Parallel TRIM and test moves (Teams B, C, D, F-body, H)

**Parallel after Session 1:**
- Team B (TRIM app.js + index.html panels + event-contract.md prune)
- Team C (TRIM settings.js → api-keys.js + leaderboard-submit.js + modal-controller.js)
- Team D (git-mv 9 CUT e2e + playwright.config.ts)
- Team F-body (docs sweep, all body work; ship-stamp commit deferred to Session 3)
- Team H (optional API route audit)

**Each team merges independently.** Recommended merge order (low-risk to high-risk for fast rollback):
1. Team H (audit only, no production code)
2. Team D (test moves; minimal blast radius)
3. Team C (settings/leaderboard-submit/modal-controller — isolated files)
4. Team B (app.js + index.html — largest surgery)
5. Team F-body (docs)

**After each team merges:** run targeted validation from that team's spec. Failure → block next merge until resolved.

**Session checkpoint:** Full e2e test suite run (`npm run test:e2e`) — expected failures are exactly the assertions Team E will fix in Session 3. Document failure list. Browser smoke-test of `dashboard/index.html`, `dashboard/leaderboard.html`, `dashboard/api-keys.html` — all load without console errors.

### Session 3: Assertion fixes + CI guards + ledger close-out (Teams E, G, F-ship-stamp)

**Sequential and parallel mix:**
- Team E (fix assertions in remaining tests against trimmed surface) — runs first; once green, gate opens.
- Team G (CI guards + pre-commit hook + .gitattributes + ci.yml + deploy.yml exclusions) — parallel with E since they touch different files.
- Team F-ship-stamp (final commit on `docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` setting `status: shipped`) — runs LAST, after E and G merge.

**Merge order:** Either Team E or Team G can merge first (no shared files). Then the other. Then Team F-ship-stamp.

**Session checkpoint:** Full e2e green; `git commit` test of the legacy/ no-edit guard (modify a legacy file, expect block); deploy artifact spot-check (run `gh workflow view deploy.yml` or equivalent). Final: `grep '^status:' docs/bug-hunt/refactor-queue/ui-removal-launch-cut.md` returns `status: shipped`.

### Post-Session 3: Verdict gate (next /bug-hunt iteration)

The refactor's success is verified by the NEXT bug-hunt iteration's blind walk per the Validation criteria in the source doc:
1. Blind walk completes trade-placement task entirely via CLI/MCP, no UI fallback.
2. Zero new ledger entries in `dashboard-state-sync`, `onboarding-checklist`, `dirty-state-tracker`, `dead-affordance`, `modal-stacking`, `aria-label-mismatch`, `password-form-aria`, `price-discrepancy` categories.
3. Production dashboard at finlet.dev loads all KEEP surfaces.
4. CI green on main with legacy/ exclusions in place.
5. At least one new ledger entry surfaces a CLI or MCP bug (or zero new entries) — the bug-hunt focus shifts from UI to CLI/MCP discoverability.

If criteria 1 fails: cut was incomplete (verdict: `incomplete`, follow-up scope).
If criteria 2 fails: TRIM wasn't deep enough (verdict: `incomplete`).
If criteria 3 fails: regression (verdict: `regressed`, hotfix required).
