# Dirty-State Tracker Refactor — Execution Plan

> Generated from `docs/bug-hunt/refactor-queue/dirty-state-tracker.md`. 2026-04-28.
> Driven by recurrence-data: `dirty-state-tracker` cluster has 2 instances across 2 iterations under the new 2/2 refactor gate.
> Recon corrected the refactor doc on two points (see Constraints).

## Constraints

- **Single-file refactor.** Recon confirms `dashboard/settings.js` is the only consumer of `originalValues`/`dirtyFields` in the dashboard. No other page has form-dirty tracking. The "optional extraction to `dashboard/form-dirty-tracker.js`" step in the refactor doc is **skipped** — extracting a generic module without a second consumer is premature.
- **Discard button positioning is likely a non-bug.** Recon confirms the unsaved-changes banner is `position: fixed; bottom: 0; left: 0; right: 0;` in `settings.css`, so it does not scroll out of viewport. The handoff observation ("element is outside of the viewport" Playwright timeout) may have been a transient state during the banner's `transform: translateY(100%)` animation, or a different element entirely. The team must **verify empirically** in the browser before doing any CSS work — if the button IS reachable, the CSS fix is dropped.
- **The bug class is broader than the refactor doc claimed.** Recon found 4 broken tabs, not 2:
  - Broken (no post-load snapshot): Profile, Security, API Keys, Plugins
  - Working (already does post-load snapshot): Notifications (line 1115), Appearance (lines 1214–1217)
  - Static (no loader): Data & Privacy
  The fix pattern is already proven in Notifications/Appearance — propagate it to the 4 broken loaders.
- **No new innerHTML.** Trusted-types lint guard (`scripts/lint-trusted-types.sh`) won't flag this refactor (logic + optional CSS only).
- **Closed-source repo, pre-launch.** Don't extract abstractions for hypothetical future consumers.
- **Out of scope:**
  - `dashboard/form-dirty-tracker.js` extraction (no second consumer to justify).
  - Cross-page dirty-state warning ("are you sure you want to leave?").
  - Per-field validation messages.
  - Optimistic save / debounced autosave.

## File Conflict Table

| File | Touched by Teams |
|------|-----------------|
| `dashboard/settings.js` | A |
| `tests/e2e/journey-06-settings.spec.ts` | A |
| `dashboard/settings.css` | A (conditional — only if Discard button positioning bug verified) |

No shared files with the modal-stacking refactor or any other queued work. Single team.

## Dependency Graph

- **Team A (independent)** — starts immediately. No upstream dependencies.

## Critical Path

Team A (single team, single chain).

---

## Teams

### Team A: Per-loader snapshot pattern + cold-load regression tests

**Blocked by:** none — can start immediately.

**Read these files first:** (CRITICAL — do NOT skip)
- `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` — the spec this team implements (root cause, scope, break-even). NOTE: the doc's optional extraction step and Discard-button positioning fix are both reduced/removed in this plan per recon — read the Constraints section above.
- `docs/bug-hunt/20260428T031818Z2efa/` — first dirty-state-tracker iteration (`settings-dirty-banner-onload`, commit `c82caca`). This was the Profile-tab patch that introduced the rAF deferral.
- `docs/bug-hunt/20260428T163727Z4f4f/HANDOFF.md` (section "5. dirty-state-tracker") — Plugins-tab recurrence + the Discard button observation that recon disputes.
- `git show 1f9c126` — yesterday's rAF deferral fix. Understand WHY one frame was insufficient for the Plugins-tab loader chain (the answer: Plugins' cards render async after multiple awaits; rAF runs once, can't catch the deeper chain).
- `dashboard/settings.js:116-211` — current dirty-tracker implementation: `originalValues` (line 116), `initFormTracking()` (118–132), rAF deferral (153–165), `markDirty`/`markDirtyToggle` (168–192), `updateUnsavedBanner` (194–197), `discardChanges` (199–211).
- `dashboard/settings.js:1099-1127` — **`loadNotifications()` — the working pattern.** Note the post-load snapshot at line 1115. This is the template the broken loaders will copy.
- `dashboard/settings.js:1200-1218` — `loadAppearance()` — same working pattern (snapshot at 1214–1217).
- `dashboard/settings.js:252-272` — `loadProfile()` — broken, no snapshot.
- `dashboard/settings.js:971-1036` — `loadPlugins()` — broken, dynamically renders cards via template string + appendChild. Field IDs aren't known statically.
- `dashboard/settings.js:1350+` — `loadApiKeys()` and `loadMfaStatus()` — broken loaders.
- `dashboard/settings.html:120,220,280,324,336,403,480` — tab definitions (Profile, Security, API Keys, Plugins, Notifications, Appearance, Data & Privacy).
- `dashboard/settings.css` — banner positioning (search for `.unsaved-banner` and `.unsaved-banner--visible`). Confirm `position: fixed; bottom: 0` for the banner.
- `tests/e2e/journey-06-settings.spec.ts:88-103` — existing test pattern: `editing name triggers unsaved changes banner`. Use this as the structural template for the 4 new cold-load tests.

**Files touched:**

- **Modified:** `dashboard/settings.js`:
  - Add a helper near the dirty-tracker (place near line 150, after `originalValues` and before the rAF block):
    ```
    function snapshotFields(fieldIds) {
      // Re-reads current DOM values for the given field ids and updates
      // originalValues to match. Clears those ids from dirtyFields.
      // Triggers updateUnsavedBanner() at the end so the banner reflects
      // the new clean state.
    }
    function snapshotAllTracked() {
      // For loaders that render dynamic fields and don't know the id list
      // upfront. Iterates the currently-registered tracker field set and
      // re-snapshots all of them.
    }
    ```
  - Modify `loadProfile()` (~line 272, end of function): after the form is populated, call `snapshotFields(['name', 'email', 'bio', 'timezone'])`. Match the line-1115 pattern from `loadNotifications()`.
  - Modify `loadMfaStatus()` and `loadApiKeys()` (~line 1350+): after their respective population code, call `snapshotFields(...)` with the relevant ids (e.g., `['mfa_enabled']` for mfa, the dynamic api-key list ids for api-keys).
  - Modify `loadPlugins()` (~line 1036, end of function): after the plugin cards render and any inner async work resolves, call `snapshotAllTracked()`. The dynamic fields' ids aren't known statically; this picks up everything currently in the tracker's set.
  - **rAF deferral (lines 153–165):** keep as-is. The per-loader snapshot supersedes it functionally, but rAF was added defensively and removing it eagerly risks regression on tabs we didn't think to test. Re-evaluate removal in a future iteration if the per-loader snapshot proves sufficient.
  - **Important:** the `snapshotFields` / `snapshotAllTracked` helpers must call `updateUnsavedBanner()` at the end. Otherwise the banner stays visible until the next user input event fires.

- **Modified:** `tests/e2e/journey-06-settings.spec.ts`:
  - Add 4 new tests, each modeled on the lines 88–103 pattern but inverted (asserting the banner does NOT appear on cold load):
    1. `'Profile tab does not show unsaved-changes banner on cold load'`
    2. `'Security tab does not show unsaved-changes banner on cold load'`
    3. `'API Keys tab does not show unsaved-changes banner on cold load'`
    4. `'Plugins tab does not show unsaved-changes banner on cold load'`
  - Each test: navigate to `/settings.html`, `await page.waitForLoadState('networkidle')`, click the tab, wait 1000ms, assert `await page.locator('#unsaved-banner').evaluate(el => el.classList.contains('unsaved-banner--visible'))` is `false`.
  - Keep the existing "editing name triggers unsaved changes banner" test as a regression. After the refactor, editing must STILL trigger the banner.

- **Modified (CONDITIONAL):** `dashboard/settings.css`:
  - Only touch this file if empirical browser verification confirms the Discard button is genuinely off-viewport when the banner is open. Recon analysis says it shouldn't be (banner is `position: fixed; bottom: 0`). If the bug is real, the fix is anchoring the buttons inside the fixed banner with explicit `position: relative` and removing any conflicting absolute positioning.
  - If the bug is NOT reproducible, document this in the commit message: "Discard button positioning verified in-viewport; no settings.css change needed."

**Deliverable:** Loading any settings tab cold (Profile, Security, API Keys, Plugins) does NOT show the unsaved-changes banner. User edits still trigger the banner. Save and Discard flows are unchanged. The 4 broken tabs match the behavior of the 2 already-working tabs (Notifications, Appearance).

**Validation:**
- [ ] `npx playwright test tests/e2e/journey-06-settings.spec.ts` — all tests pass (the existing edit-triggers-banner test + 4 new cold-load tests = 5 minimum).
- [ ] `bash scripts/lint-trusted-types.sh` exits 0 (no innerHTML changes anyway, but verify).
- [ ] `grep -nE 'snapshotFields\(|snapshotAllTracked\(' dashboard/settings.js` returns ≥ 5 (1 helper definition each + at least 4 call sites in the broken loaders; Notifications/Appearance can be migrated to the helper but it's optional).
- [ ] **Manual smoke test (in-browser):**
  1. Open the dashboard, navigate to Settings.
  2. Click each tab in turn (Profile, Security, API Keys, Plugins, Notifications, Appearance).
  3. After each tab loads (≥1s), confirm no banner appears.
  4. Modify a field on each tab where applicable; confirm banner DOES appear.
  5. Click Discard; confirm the field reverts and banner disappears.
  6. With banner visible, scroll the page to its tallest extent; confirm Discard button remains in viewport (validates whether settings.css change is needed).
- [ ] `git log -1 --format=%B` — the commit message documents whether the Discard-button positioning fix was applied or skipped, with reasoning.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. The worktree is cleaned on exit; uncommitted work is lost.
- The pattern to copy is `loadNotifications()` at `dashboard/settings.js:1099-1127`, specifically the snapshot call at line 1115. Match its shape exactly: snapshot is called as the **last line** of the loader function, after API resolves and DOM is populated synchronously.
- For `loadPlugins()`: the loader renders cards async. You may need to `await` all card-rendering promises before calling `snapshotAllTracked()`. If `loadPlugins()` already awaits everything (which recon suggests it does — it uses `Promise.allSettled`), call snapshot at the very end. If you can't tell, add a `setTimeout(snapshot, 0)` to push past microtasks; document why in a comment.
- `snapshotFields(ids)` and `snapshotAllTracked()` must BOTH end by calling `updateUnsavedBanner()`. Otherwise the banner stays visible until the next input event.
- **Do NOT extract `dashboard/form-dirty-tracker.js`.** Recon confirmed settings.js is the only consumer. Extraction adds surface area for no benefit at v1.
- **Do NOT remove the rAF deferral (lines 153–165) eagerly.** It was defensive scaffolding; removing it risks unknown regressions. Leave it; future iteration can decide.
- **Discard button positioning:** verify empirically before changing CSS. If recon is right (banner is `position: fixed; bottom: 0`), the button is fine and you skip the CSS work entirely. If the handoff was right (button off-viewport), fix in settings.css. The COMMIT MESSAGE must record which path you took.
- The 4 new Playwright tests must use `page.locator('#unsaved-banner').evaluate(el => el.classList.contains('unsaved-banner--visible'))` — NOT `expect(banner).toBeVisible()`. The banner element exists in DOM at all times; visibility comes from the class.
- Do NOT touch any backend code (`finlet/api/`, `finlet/auth/`, etc.). Do NOT touch other dashboard files. The grep validation above will fail if you do.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| `snapshotFields` is called before the loader's fields are actually populated in the DOM (race condition repeats) | Medium | High | Pattern: snapshot is called as the LAST line of the loader after `await apiFetch()` and synchronous DOM population. This is the proven pattern from `loadNotifications()` line 1115. Validation: run journey-06 in CI 3 times to detect flakes. |
| `loadPlugins()` renders cards via `Promise.allSettled` — snapshot may run before cards are in DOM | Medium | High | Read `loadPlugins()` end-to-end. If it returns before `Promise.allSettled` resolves, the snapshot is wrong. If it awaits, snapshot is correct as last line. If unclear, use `await Promise.all(renderPromises); snapshotAllTracked();` explicitly. |
| Removing the rAF deferral breaks the Profile tab fix from `1f9c126` | Low | Medium | Plan explicitly says do NOT remove rAF. Risk only materializes if the agent ignores the instruction. |
| New Playwright tests are flaky in CI due to `waitForLoadState('networkidle')` timing | Medium | Low | Use 1000ms buffer after tab click. Match the structure of the existing test at lines 88–103 — it's stable. If flakes appear, increase to 2000ms or use a more specific wait condition. |
| Discard button CSS fix is applied unnecessarily, breaking banner layout | Medium | Medium | Plan requires empirical verification before any settings.css change. Commit message must record the decision. |
| `snapshotAllTracked` doesn't call `updateUnsavedBanner` and banner stays visible after snapshot | Medium | Medium | Explicit instruction in agent's spec. Validation grep: `grep -B1 -A5 'function snapshotAllTracked' dashboard/settings.js` should show `updateUnsavedBanner` in the body. |
| Refactor doc claimed an extraction step that this plan skips; agent reads doc before plan and does the extraction anyway | Low | Medium | Plan's "Read these first" lists the refactor doc but the Constraints section explicitly overrides. Agent must follow plan over doc. |

## Session Plan

### Session 1: Per-loader snapshot pattern (single session)

**Sequential:** Team A (only team).

**Merge order:**
1. Team A merges. Run `npx playwright test tests/e2e/journey-06-settings.spec.ts` on main. If green, validation passes.
2. Manual smoke test in-browser per the Validation checklist (cold-load all 6 tabs, edit each, discard, verify Discard button reachable).

**Session checkpoint:** full Playwright suite passes once on main (`npx playwright test`). If clean, mark `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` `status: shipped` (no `verdict:` yet — that's set on the next bug-hunt iteration).

## Verdict-tracking notes (for the next iteration's Phase 6)

After this refactor lands, the next `/bug-hunt` iteration's Phase 6 sets the `verdict:` field on `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` based on:
- **`effective`** — zero new `dirty-state-tracker` instances in the next triage.
- **`incomplete`** — a new finding fires the banner on a tab the refactor was supposed to fix (Profile/Security/API Keys/Plugins), OR fires on a NEW tab not covered by the refactor (e.g., Data & Privacy if a loader is added there). In both cases, the fix is to add `snapshotFields` to the missed loader.
- **`regressed`** — a NEW class of false-positive banner appears that wasn't in the prior triage (e.g., banner fires on input blur when nothing changed, or never disappears after Save). This would indicate the per-loader pattern broke something.
