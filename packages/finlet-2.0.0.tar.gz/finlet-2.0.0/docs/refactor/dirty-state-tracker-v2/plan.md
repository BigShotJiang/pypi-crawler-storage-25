# Dirty-State Tracker v2 Refactor — Execution Plan

> Generated from `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` + `docs/bug-hunt/handoff/HANDOFF-2026-04-29-dirty-state-tracker-v2.md`. 2026-04-29.
> Driven by: v1 verdict `incomplete` (set 2026-04-29 in iteration `20260429T052717Z1a13`). Refactor-gate fired 2/2 + forward signal.
> Recon corrected the handoff on five points (see Constraints).

## Constraints

- **The handoff is partly stale.** Recon corrected five facts:
  1. Gate location is `dashboard/settings.js:66-73`, NOT `:201` as the handoff claimed.
  2. All 6 loaders are ALREADY in the `Promise.allSettled` list as of commit `31c3255` (Team A patch from today's iteration). The "3 of 6 missing loaders" issue is already shipped-fixed in main. v2's job is to prevent the NEXT recurrence of the same hand-maintained-list failure mode, not to re-fix what just shipped.
  3. CSS file for the banner is `dashboard/settings.css`, NOT `dashboard/styles.css` as v1 scope doc and handoff implied.
  4. Banner is already `position: fixed; bottom: 0; left: 0; right: 0;` (`settings.css:871-897`). The "replace `position: absolute` with sticky bar" item from v1 scope was based on an incorrect premise. v1 plan made the same correction. v2 inherits it: skip CSS work unless empirical verification finds a real off-viewport bug.
  5. There are **7 settings tabs** but only **6 loader promises**. One tab (likely Data & Privacy, which v1 plan flagged as static / no loader) has no loader by design. This 7-vs-6 mismatch is exactly the failure mode v2 must eliminate — the registry pattern makes "no loader for this tab" explicit instead of a silent gap.
- **v2 is structural, not corrective.** The hand-maintained `Promise.allSettled` list is already complete today. The risk is forward — a tab added next month silently bypasses the gate. v2 replaces the list with a self-enumerating registry so this CANNOT happen again.
- **Module extraction is mandatory in v2.** v1 plan explicitly skipped this with the rationale "no second consumer." v2 reverses that decision per the handoff: the registry is the actual reusable unit, and a registry living inline in `settings.js` defeats the purpose. The extraction also lets us write isolated unit tests for the gate, which we cannot do today.
- **No new innerHTML.** Trusted-types lint guard (`scripts/lint-trusted-types.sh`) is logic-only territory.
- **Closed-source repo, pre-launch.** No backwards-compat shims, no deprecation warnings on the old inline pattern. Settings page is the only consumer; cut over cleanly.
- **Out of scope:**
  - Cross-page dirty-state warning ("are you sure you want to leave?").
  - Per-field validation messages.
  - Optimistic save / debounced autosave.
  - Migrating `loadNotifications()` / `loadAppearance()` to the registry (they already work via the existing `snapshotFields` pattern; mechanical migration only — see Risk Register).
  - Adding a real 4th-position tab to the production UI. The "4th-position verification" requirement is satisfied by a unit test that simulates a new registrant, NOT by shipping a real tab nobody asked for.

## File Conflict Table

| File | Touched by Teams |
|------|-----------------|
| `dashboard/settings.js` | A |
| `dashboard/form-dirty-tracker.js` (new) | A |
| `dashboard/settings.html` | A (only if `<script type="module">` import requires it; verify before editing) |
| `tests/e2e/journey-06-settings.spec.ts` | A |
| `tests/dashboard/test_form_dirty_tracker.spec.ts` (new, optional) | A |
| `dashboard/event-contract.md` | A (only if registry publishes events; default: don't) |

No shared files with any other queued refactor. Single team.

## Dependency Graph

- **Team A (independent)** — starts immediately. No upstream dependencies.

## Critical Path

Team A (single team, single chain).

---

## Teams

### Team A: Self-enumerating loader registry + module extraction

**Blocked by:** none — can start immediately.

**Read these files first:** (CRITICAL — do NOT skip; recon evidence below supersedes the handoff)

- `docs/bug-hunt/handoff/HANDOFF-2026-04-29-dirty-state-tracker-v2.md` — the handoff that triggered v2. Read sections "Next session" and "Why this refactor is right-sized." Note: line numbers in this doc are stale (see Constraints).
- `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` — original v1 scope. v2 plan supersedes the "optional extraction" and "sticky bar" items; everything else still informs context.
- `docs/refactor/dirty-state-tracker/plan.md` — v1 plan. Read it ENTIRELY. v2 reuses v1's per-loader snapshot pattern; only the gate mechanism and module home change.
- `git show 31c3255` — Team A's same-day patch that extended `Promise.allSettled` to all 6 loaders. v2's registry pattern obsoletes the hand-maintained list this commit just fixed.
- `git show 1f9c126` — yesterday's rAF deferral fix. The rAF block at `dashboard/settings.js:153-165` (or current line, see below) stays; do NOT remove it.
- `dashboard/settings.js:1-1592` — full file context. Specifically:
  - **State declarations** (lines 8-16): `dirtyFields`, `currentSection`, `_profileLoaded` … `_pluginsLoaded`, `_loaderUpdating`. ALL of this moves to `form-dirty-tracker.js` except `currentSection`.
  - **Promise.allSettled gate** (lines 66-73): the array-based hand-maintained gate. REPLACE with `await loaderRegistry.awaitAll()`.
  - **Tab switching DOMContentLoaded handler** (lines 80-112): tab clicks call `initFormTracker()` per tab? Confirm during execution. Do NOT change tab-switching behavior.
  - **`originalValues` baseline** (line 132): moves to module.
  - **`snapshotFields()` / `snapshotAllTracked()` helpers** (lines 146-174): move to module verbatim (they already work).
  - **`initFormTracking()`** (the function that owns the gate and rAF re-snapshot — exact line, find via grep): becomes the entry point exported by the module.
  - **rAF block** (lines 217-231 per recon, may shift after edit): keep as defensive scaffolding. Move with the gate.
  - **`markDirty` / `markDirtyToggle` / `updateUnsavedBanner` / `discardChanges`**: all move to module.
  - Loaders that need to register: `loadProfile`, `loadNotifications`, `loadAppearance`, `loadMfaStatus`, `loadApiKeys`, `loadPlugins`. Each must call `registerLoader(theirPromise)` at the start, instead of being captured by name in the hand-maintained array.
- `dashboard/settings.html:83-112` — tab buttons (7 tabs). Confirm whether `<script src="settings.js">` is a regular script or a `<script type="module">`. The extraction REQUIRES module imports; if settings.js is currently loaded as a non-module script, the HTML must be updated.
- `dashboard/settings.html:525-529` — banner element (`#unsaved-banner`).
- `dashboard/settings.css:871-897` — banner styling (already `position: fixed`; do NOT touch).
- `dashboard/event-bus.js` + `dashboard/event-contract.md` — for context only. v2 does NOT add bus events for the form tracker (single-page concern; no cross-component need). Do not modify event-contract.md unless you find a concrete cross-component subscriber, which recon confirmed does not exist.
- `tests/e2e/journey-06-settings.spec.ts:88-100` — existing dirty-state test. Use as structural template for cold-load assertions.
- `tests/e2e/journey-06-settings.spec.ts` (full file) — read end-to-end to understand the test patterns and fixtures.
- `scripts/lint-trusted-types.sh` — pre-commit guard. Confirm it doesn't false-flag the new module.

**Files touched:**

- **New:** `dashboard/form-dirty-tracker.js` — the extracted module. Exports the API below. ~150-200 lines.
  - **API surface** (final, do not deviate):
    ```js
    // Lifecycle
    export function initFormTracker({ bannerSelector, formSelector });
    //   Wires up listeners, awaits the registry gate, takes baseline snapshot,
    //   re-snapshots after loaders, manages the _loaderUpdating guard, calls
    //   updateBanner. Idempotent per page; safe to call once on DOMContentLoaded.

    // Registry (the v2 core)
    export function registerLoader(promise);
    //   Each load*() function calls this with its own in-flight promise, BEFORE
    //   awaiting it. The gate inside initFormTracker awaits Promise.allSettled
    //   of everything registered.

    // Snapshots (carried forward from v1)
    export function snapshotFields(fieldIds);
    export function snapshotAllTracked();
    //   Both end with updateBanner(). Loaders call after populating DOM.

    // Banner / discard (carried forward from v1)
    export function discardChanges();
    //   Called by the Discard button. Resets all dirty fields to originalValues,
    //   clears dirtyFields set, calls updateBanner.
    ```
  - **Internal state** (module-scoped, NOT exported):
    - `originalValues = {}` — current baseline
    - `dirtyFields = new Set()` — currently-dirty field ids
    - `loaderRegistry = []` — promises pushed by `registerLoader`
    - `_loaderUpdating = false` — guard (suppresses `markDirty` while DOM is unstable)
    - `bannerEl = null` — resolved once in `initFormTracker`
  - **Internal helpers** (NOT exported):
    - `markDirty(id)`, `markDirtyToggle(id)` — input-change handlers (still attached via `initFormTracker`).
    - `updateBanner()` — toggles `.unsaved-banner--visible` based on `dirtyFields.size`.
  - **The gate, inside `initFormTracker`**:
    ```js
    async function initFormTracker({ bannerSelector, formSelector }) {
      bannerEl = document.querySelector(bannerSelector);
      // ... attach input/change listeners on formSelector ...
      // baseline snapshot (sync DOM only):
      snapshotAllTracked();
      _loaderUpdating = true;
      await Promise.allSettled(loaderRegistry);
      // rAF re-snapshot pass — keeps defensive coverage from 1f9c126:
      await new Promise(r => requestAnimationFrame(r));
      snapshotAllTracked();
      _loaderUpdating = false;
      updateBanner();
    }
    ```
  - **Export `__test__` symbol** for unit testing:
    ```js
    export const __test__ = {
      reset: () => { originalValues = {}; dirtyFields = new Set(); loaderRegistry = []; _loaderUpdating = false; },
      getRegistry: () => [...loaderRegistry],
      getDirtyFields: () => new Set(dirtyFields),
    };
    ```
    This is the ONLY mechanism for tests to inspect/reset internal state. Do not export internal state directly.

- **Modified:** `dashboard/settings.js`:
  - Add at top: `import { initFormTracker, registerLoader, snapshotFields, snapshotAllTracked, discardChanges } from './form-dirty-tracker.js';`
  - Delete inline state declarations (lines 8-16 except `currentSection`), `originalValues` (line 132), `snapshotFields`/`snapshotAllTracked` (lines 146-174), `markDirty`/`markDirtyToggle`/`updateUnsavedBanner`/`discardChanges` (current lines, find via grep), `initFormTracking()` (current location), the rAF block (lines 217-231).
  - Replace the hand-maintained `Promise.allSettled` gate (lines 66-73) with the module's `initFormTracker({ bannerSelector: '#unsaved-banner', formSelector: '#settings-form' })` call inside the existing init flow. (Confirm form selector exists; if no form wrapper, use a sentinel selector that covers all tracked inputs.)
  - In each loader (`loadProfile`, `loadNotifications`, `loadAppearance`, `loadMfaStatus`, `loadApiKeys`, `loadPlugins`):
    - Capture the loader's in-flight promise at the top: `const p = (async () => { ... existing body ... })();`
    - Call `registerLoader(p)` immediately.
    - Return `p`.
    - Inside the body, retain the existing `snapshotFields([...])` or `snapshotAllTracked()` call as the LAST line after DOM population. Re-export from module is the same name.
  - Remove the named loader-promise variables (`_profileLoaded` etc.) — no longer needed since the registry owns enumeration.
  - Wire the Discard button click handler to the imported `discardChanges`.
  - **DO NOT** touch tab-switching logic (lines 80-112) beyond what's necessary to remove the now-unused promise variables.

- **Modified (CONDITIONAL):** `dashboard/settings.html`:
  - Only if the existing `<script src="settings.js">` is a non-module script. If it's already `<script type="module">`, no change needed. Verify with `grep -n 'settings.js' dashboard/settings.html`.
  - If conversion needed: change to `<script type="module" src="settings.js"></script>`. This may have other side effects (different scoping, defer-by-default); verify all globals settings.js currently exports to `window` are explicitly attached.

- **Modified:** `tests/e2e/journey-06-settings.spec.ts`:
  - Add 3 cold-load regression tests (one per recurrence shape named in the handoff verification). Each test: navigate to `/settings.html`, `await page.waitForLoadState('networkidle')`, click the relevant tab, wait 1000ms, assert banner does NOT have `.unsaved-banner--visible`:
    1. `'Profile tab does not show unsaved-changes banner on cold load'` (settings-dirty-banner-onload, iter 20260428T031818Z2efa)
    2. `'Plugins tab does not show unsaved-changes banner on cold load'` (iter 20260428T163727Z4f4f)
    3. `'Plugins tab does not show banner on cold load with throttled /plugins/health'` (iter 20260429T052717Z1a13). Use Playwright route interception to throttle the `/plugins/health` response by 500ms; assert banner still absent at 1500ms post-tab-click.
  - Use `await page.locator('#unsaved-banner').evaluate(el => el.classList.contains('unsaved-banner--visible'))` for the assertion — NOT `expect(banner).toBeVisible()`. The banner element exists in DOM at all times; visibility is class-based.
  - Keep the existing "editing name triggers unsaved changes banner" test (lines 88-100) as-is. Regression coverage.

- **New:** `tests/dashboard/test_form_dirty_tracker.spec.ts` — unit test for the registry pattern. The "4th-position auto-gating" verification lives here. ~50 lines.
  - Test 1: `registerLoader` adds to internal registry.
  - Test 2: `initFormTracker` awaits all registered loaders before declaring init complete (use a deliberately-slow promise; assert init does not resolve before that promise does).
  - Test 3: **The forward-signal test.** Register 6 loaders (matching today's settings count), then register a 7th loader AFTER initFormTracker has been called but BEFORE it finishes its gate. Assert the 7th loader IS awaited (i.e., the registry is consumed at gate-execution time, not module-load time). This is the regression test for the v1 failure mode.
  - Test 4: `snapshotFields(['x', 'y'])` clears `dirtyFields` for those ids and triggers `updateBanner`. Use the `__test__` export to inspect.
  - Test 5: `discardChanges` resets `dirtyFields` and `originalValues` to baseline.
  - Test runner: use whatever the dashboard test infra is — verify with `ls tests/dashboard/ 2>/dev/null` or `grep -r 'test_' dashboard/`. If no JS unit-test infra exists, add to `tests/e2e/journey-06-settings.spec.ts` as page.evaluate-driven assertions instead. **Document the chosen path in the commit message.**

**Deliverable:** `dashboard/form-dirty-tracker.js` exists as an importable module exposing `initFormTracker`, `registerLoader`, `snapshotFields`, `snapshotAllTracked`, `discardChanges`. `dashboard/settings.js` no longer holds inline form-tracker state. The hand-maintained `Promise.allSettled` array is replaced with `await Promise.allSettled(loaderRegistry)`. All 3 cold-load Playwright regressions pass. The forward-signal unit test (Test 3) passes. The settings page behaves identically from a user perspective.

**Validation:**
- [ ] `npx playwright test tests/e2e/journey-06-settings.spec.ts` — all tests pass (1 existing edit test + 3 new cold-load tests = 4 minimum).
- [ ] If unit-test infra path was chosen: `<chosen test runner command>` for `tests/dashboard/test_form_dirty_tracker.spec.ts` — 5 tests pass.
- [ ] If page.evaluate path was chosen: those assertions are inside the e2e tests above; counted in that 4-minimum.
- [ ] `bash scripts/lint-trusted-types.sh` exits 0.
- [ ] `grep -nE 'Promise\.allSettled\(\s*\[' dashboard/settings.js` returns ZERO matches (the hand-maintained array is gone).
- [ ] `grep -c 'registerLoader(' dashboard/settings.js` returns ≥ 6 (one call per loader function).
- [ ] `grep -c 'export function' dashboard/form-dirty-tracker.js` returns 5 (the public API surface).
- [ ] `wc -l dashboard/settings.js` is at least 100 lines smaller than pre-refactor (was 1592 per recon; expect ≤ ~1490).
- [ ] **Manual smoke test (in-browser):**
  1. Open dashboard, navigate to Settings.
  2. Click each of the 7 tabs in turn. After each loads (≥1s), confirm no banner.
  3. Modify a field on each tab; confirm banner appears.
  4. Click Discard; confirm field reverts and banner disappears.
  5. With banner visible, scroll to tallest extent; confirm Discard button stays in viewport.
  6. Throttle `/plugins/health` in DevTools (custom 500ms+ throttle); reload Settings → Plugins; confirm no false banner.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. The worktree is cleaned on exit; uncommitted work is lost.
- Read `docs/refactor/dirty-state-tracker/plan.md` (the v1 plan) end-to-end before touching code. v2 inherits ~70% of v1's reasoning.
- The registry pattern's correctness invariant: **`loaderRegistry` is consumed at gate-execution time, not module-load time.** The gate `await Promise.allSettled(loaderRegistry)` reads the array WHEN it runs, not WHEN the module is imported. This is what makes new loaders auto-gated. Test 3 enforces this.
- Each loader's existing `snapshotFields(...)` / `snapshotAllTracked()` call MUST remain the last line after DOM population. Do NOT remove or reorder.
- The `_loaderUpdating` guard (currently `dashboard/settings.js:16`) MUST be inside the module. Its lifecycle is: set true at gate start, false after rAF re-snapshot. `markDirty`/`markDirtyToggle` check it to suppress dirty marks during the unstable window. Do NOT decouple this guard from the gate logic.
- **DO NOT** add bus events for form-dirty state. Recon confirmed no cross-component subscribers; adding events is anticipatory abstraction.
- **DO NOT** migrate `loadNotifications` / `loadAppearance` away from the existing `snapshotFields` pattern — they already work. The migration is purely: import from new module instead of using inline definitions.
- **DO NOT** remove the rAF deferral. It moves with the gate to the module. Removing it eagerly risks regression.
- **DO NOT** add a real 4th tab to `settings.html`. The "4th-position verification" requirement is satisfied by Test 3 in the unit-test file (forward-signal test). If you cannot make Test 3 work in the chosen test infra, surface the obstacle in the commit message and add the assertion as an e2e test that registers a fake loader via `page.evaluate(() => window.__formTracker__test__.registerLoader(slowPromise))`.
- **DO NOT** touch backend code (`finlet/api/`, `finlet/auth/`, etc.). Validation will grep for it.
- The CSS file is `settings.css`, not `styles.css`. The handoff has the wrong filename. Do not touch CSS unless the manual smoke test step 5 fails.
- If you find that `<script src="settings.js">` is non-module and converting to module breaks an existing global, document the global in the commit message and either fix it or pause and surface to the executor.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Module conversion breaks existing globals settings.js exposes to `window.*` | Medium | High | Before extraction, grep `dashboard/settings.js` for `window.` assignments. Each must be explicit in the new module form. If found and risky, defer module conversion: keep the new file as a non-module script that runs first and assigns to `window.formDirtyTracker.*`, and have settings.js read from there. Document the chosen path. |
| Registry consumption timing — module load vs gate execution | Low | High | Test 3 (forward-signal test) is the regression. The pattern itself is mechanically correct; the failure mode is only if someone refactors the gate to capture the array at module-load time. Code-review-level concern. |
| `loadPlugins()` registers its promise but the cards finish rendering AFTER the promise resolves (microtask gap) | Medium | High | Loader's promise must encompass ALL async work, including card rendering. If `loadPlugins` currently returns before its inner `Promise.allSettled` of card-renders, wrap so the outer promise awaits the inner. Same risk v1 plan called out — same mitigation. |
| New unit-test infra doesn't exist; agent invents one | Medium | Medium | Agent instructions explicitly say: if no infra, fall back to `page.evaluate` inside e2e. Do not add a new test framework. |
| `_loaderUpdating` guard becomes out-of-sync with gate when split across module/caller boundary | Low | High | The guard MUST live entirely inside the module. The caller never touches it. Code review verifies. |
| The 7-vs-6 tab/loader mismatch (Data & Privacy has no loader) breaks the registry expectation | Low | Low | Tabs without loaders simply don't register. The registry awaits whatever IS registered; absence is correct. Add a comment in the Data & Privacy tab's section explaining "no loader by design." |
| Removing the `_*Loaded` named variables breaks something in tab-switching code that referenced them | Medium | Medium | Recon Q8 says tab-switching is at `dashboard/settings.js:80-112` and uses CSS display toggle; no recon evidence it reads the loader promises. Verify with `grep -nE '_(profile|notifications|appearance|mfa|apiKeys|plugins)Loaded' dashboard/settings.js` after the refactor — must return 0. |
| Module extraction creates a subtle init-order bug: settings.js runs before form-dirty-tracker.js is parsed | Low | Medium | If converted to ES modules, browser handles ordering. If kept as non-module, ensure `<script src="form-dirty-tracker.js">` precedes `<script src="settings.js">` in HTML. |
| Trusted-types lint guard false-flags the new module | Low | Low | The new module has no `innerHTML` writes; pure data + DOM read/write of `value`/`checked`. Lint should be clean. Run `bash scripts/lint-trusted-types.sh` once before committing. |
| The 4th-position registry test is added as an e2e test that adds a real visible tab to the production UI | Medium | Medium | Agent instructions explicitly forbid this. Test 3 uses `__test__.registerLoader` or `page.evaluate` injection only. PR review verifies no `settings.html` change beyond the script tag. |

## Session Plan

### Session 1: Module extraction + registry pattern (single session)

**Sequential:** Team A (only team).

**Merge order:**
1. Team A merges. Run `npx playwright test tests/e2e/journey-06-settings.spec.ts` on main. If green, validation passes.
2. Run unit tests (whichever infra path Team A chose). If green, the forward-signal regression is now permanently locked.
3. Manual smoke test in-browser per the Validation checklist.

**Session checkpoint:** Full Playwright suite passes once on main (`npx playwright test`). If clean, mark `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` `status: shipped, shipped_in: <merge sha>`. Reset `verdict:` to pending; the next bug-hunt iteration sets it.

## Verdict-tracking notes (for the next bug-hunt iteration)

After this refactor lands, the next `/bug-hunt` iteration's Phase 6 sets the `verdict:` field on `docs/bug-hunt/refactor-queue/dirty-state-tracker.md`:

- **`effective`** — All three named recurrence shapes (Profile cold-load, Plugins cold-load, throttled `/plugins/health` cold-load) pass cleanly in the next triage. No new `dirty-state-tracker` instances anywhere.
- **`incomplete`** — A new finding fires the banner on a tab the refactor was supposed to gate (any tab with a loader). Likely root cause: the loader doesn't call `registerLoader`. Fix: add the call.
- **`regressed`** — A new failure shape that didn't exist before v2 (e.g., banner stays visible after Save, banner fires on input blur with no change, init never completes). Indicates the registry pattern broke something the inline pattern handled. Revert is single SHA.

If a new tab is added in the next iteration and the dirty-banner doesn't fire on it incorrectly, that's POSITIVE evidence — the registry caught it without manual list maintenance. Note this in the iteration triage notes for v2's `verdict:` rationale.

## Completion

**Status:** SHIPPED
**Merged:** 2026-04-29 as `ed15c6c` on main
**Cherry-picked from:** worktree branch `worktree-agent-a357428c9b6b95827` commit `8eef0e2` (5 files only — see commit message for cherry-pick rationale).

**Validation:**
- Unit (`node --test tests/dashboard/form-dirty-tracker.spec.js`): 5/5 pass — Test 3 (forward-signal) is the v2 core invariant.
- Playwright (`tests/e2e/journey-06-settings.spec.ts`): 20/21 pass. The 1 fail is the pre-existing `settings API key create and revoke flow` regression (modal-stacking, OUT OF SCOPE for v2).
- Python (`uv run pytest -q --timeout=120`): 3903/3903 pass.
- lint-trusted-types: exit 0.

**Verdict-tracking:** `verdict:` field on `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` will be set by the next bug-hunt iteration's Phase 6 based on whether the 3 named recurrence shapes pass. Do NOT set it now.

**Deviations from plan:** All justified inline in the merge commit message. Summary: 6th export `setFieldDirty` for non-DOM dirty signals; drain-loop in `initFormTracker` (single Promise.allSettled would NOT have caught registry growth during await — Test 3 enforces the drain-loop); backward-compat `window.dirtyFields` and `window._loaderUpdating` getter shims to keep existing tests working under module conversion.

**Followup found during execution:**
- The Playwright config at `tests/e2e/playwright.config.ts` is not auto-discovered by `npx playwright test <file>` from repo root — runs need `--config=tests/e2e/playwright.config.ts` explicitly. Worth a runbook update so future agents don't waste runs on URL fixture errors.
