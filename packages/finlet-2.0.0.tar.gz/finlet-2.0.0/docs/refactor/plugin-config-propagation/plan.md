# Plugin Config Propagation — Execution Plan

> Generated from `docs/bug-hunt/refactor-queue/plugin-config-propagation.md`. Last updated: 2026-05-01.
>
> Source decision: bug-hunt iter `20260501T172055Z127b` shipped a hot-reload mechanism (`POST /v1/plugins/{name}/reload`, `PluginRegistry.reload`) that worked in isolation but didn't fix the user-visible bug because the CLI bypassed the existing authenticated config write path the dashboard already uses (`PUT /v1/settings/plugins`). Phase 5.5 retest against prod confirmed patch-ineffective. Codex adversarial review (2026-05-01) flagged that minting a new `POST /config` endpoint would be a third config write surface; the right move is to unify the CLI onto the existing endpoint and tighten that endpoint's response so failures aren't silently swallowed.

## Constraints

- **Pre-launch single-tenant assumption.** Per `finlet/api/services/settings_service.py:223-226` (existing docstring), EDGAR's `set_identity()` and other plugin global-state mutations are not isolated per user. Multi-tenant per-request isolation is **explicitly out of scope** — this refactor preserves the existing limitation. (If multi-tenant is required before launch, a separate refactor is needed first.)
- **Backward compatibility for dashboard.** The richer `PluginUpdateResponse` shape must be additive. Dashboard's existing handler at `dashboard/settings.js:1040, 1051` reads `result` but does not depend on any field beyond `status` — extending with `health` is safe. Verified by reading `settings.js:952-1054`.
- **Existing CLI users.** Any `~/.finlet/plugins.json` files written by older CLI versions must not break the new CLI. New CLI ignores the file (don't read, don't write); leaving stale files in place is acceptable.
- **Auth model.** `PUT /v1/settings/plugins` requires `Depends(require_user)` (`routes_settings.py:131`). The CLI must send `FINLET_API_KEY` as a Bearer token. Missing key → actionable error, not generic 401 surface.

## Execution Status
- Team A: COMPLETED at `31c7084` (merged to main as `57ae3fe`)
- Team B: COMPLETED at `54072ba` (merged to main as `fc58c4d`)
- Completion date: 2026-05-01

## File Conflict Table

### Shared File Conflicts
| File | Touched by Teams |
|------|-----------------|
| `finlet/api/schemas/settings.py` | A (extends `PluginUpdateResponse`) |
| `finlet/api/services/settings_service.py` | A (rewrites `update_plugin`) |
| `finlet/api/routes_settings.py` | A (no code change beyond response_model alignment) |
| `finlet/api/routes_health.py` | A (docstring-only on `/reload`) |
| `tests/api/test_routes_settings.py` | A (extends `TestPlugins` class) |
| `finlet/cli.py` | B (rewrites `plugins_add`, `plugins_list`) |
| `tests/test_cli.py` | B (rewrites `TestPluginsAddCommand`) |
| `docs/ARCHITECTURE.md` | A (documents the canonical write path) |

No file is touched by both teams. Sequential by dependency, not by file conflict.

## Dependency Graph

- **Team A** (independent) — owns the API contract. Can start immediately.
- **Team B** (blocked by A) — CLI must call the contract Team A defines (request body shape, response body shape). Tests stub the API; if the contract changes during A's work, B's stub assertions invalidate. Serialize.

```
Team A ──merge──► Team B ──merge──► (done)
```

## Critical Path

```
Team A → Team B
```

Two sequential merges. ~3-4h total agent time (2-3h Team A, 1h Team B).

---

## Teams

### Team A: Server-side write path + tests + docs

**Blocked by:** none — can start immediately.

**Read these files first:** (CRITICAL — prevents the agent from inventing a third config path or duplicating the `PluginHealthItem` schema)

- `docs/bug-hunt/refactor-queue/plugin-config-propagation.md` — full scope context, including out-of-scope acknowledgements.
- `finlet/api/routes_settings.py:128-145` — current `PUT /plugins` route. Pattern for `Depends(require_user)` and how `PluginUpdateResponse` is constructed.
- `finlet/api/services/settings_service.py:209-250` — current `update_plugin` body. Note `contextlib.suppress(Exception)` at line 247 and the bare `{"status": "updated", "plugin": plugin}` return at line 250 — these are what changes.
- `finlet/api/services/settings_service.py:223-226` — existing docstring acknowledging multi-user EDGAR limitation. Preserve it; do not delete.
- `finlet/api/schemas/settings.py:140-142` — current `PluginUpdateResponse` (just `status: str`, `plugin: str`). The new shape extends, does not replace.
- `finlet/api/schemas/health.py` — locate `PluginHealthItem`. Reuse this exact model in `PluginUpdateResponse`; do not redefine.
- `finlet/plugins/base.py:330` — `_reload_lock: asyncio.Lock` definition.
- `finlet/plugins/base.py:680-734` — `PluginRegistry.reload(name, config)`. Body acquires `_reload_lock`, clears `_initialized`, runs `initialize(config)`, resets per-plugin breakers. The new `update_plugin` must call this method instead of `target.initialize(...)` directly so it serializes against concurrent `/reload` callers.
- `finlet/plugins/base.py:694` — docstring noting `health_check_all` and `query_*` do **not** take the lock. This is intentional — `initialize()` mutates in place. The new code must NOT change this.
- `finlet/api/routes_health.py:138-205` — `POST /plugins/{name}/reload`. Just the docstring needs an update; no code change.
- `tests/api/test_routes_settings.py:547-740` — `TestPlugins` class. Existing tests at lines 570, 590, 611, 694, 714. The assertion `assert resp.json()["status"] == "updated"` at line 582 (and line 662) needs an update for the new richer response.

**Files touched (6):**

- Modified: `finlet/api/schemas/settings.py` — extend `PluginUpdateResponse` to include an optional `health: PluginHealthItem | None = None` and an optional `message: str | None = None`. Reuse `PluginHealthItem` directly via import from `finlet/api/schemas/health.py` — do not redefine the model.
- Modified: `finlet/api/services/settings_service.py` — rewrite `update_plugin` so it:
  1. Mutates `_user_plugin_config` exactly as today (per-user dict, EDGAR `email → identity` mapping preserved).
  2. Replaces `with contextlib.suppress(Exception): await target.initialize(...)` with `await registry.reload(plugin, config.get(plugin, {}))` — the registry method already takes the lock and resets breakers.
  3. After `reload`, calls `await registry.health_check_all()` and reads the matching plugin's `PluginHealthRecord` (via `health_check_all` returning a dict by name).
  4. Returns `{"status": "updated" | "unhealthy" | "degraded", "plugin": plugin, "health": <PluginHealthItem dict>, "message": <health.message or None>}`. Choose the top-level `status` from the post-reload health: `healthy → "updated"`, `degraded → "degraded"`, `unhealthy → "unhealthy"`. This keeps callers that only inspect `status` working (existing dashboard) while adding richness for the CLI.
  5. If `registry.reload` itself raises (not from `initialize`, but a true bug — e.g., unknown plugin), let it propagate to the route handler as an `HTTPException(404)` for unknown plugins, otherwise 500. Don't swallow.
- Modified: `finlet/api/routes_settings.py` — only the response_model + `PluginUpdateResponse(**data)` line at the bottom of the route (line ~137). The richer dict from `update_plugin` flows through without code change beyond updating the response_model fields.
- Modified: `finlet/api/routes_health.py` (lines ~140-152, docstring only) — update the `POST /plugins/{name}/reload` docstring to read: *"Reapply existing persisted plugin config without writing new config. For new config writes, use `PUT /v1/settings/plugins` (the canonical, authenticated write path used by the dashboard and CLI). This endpoint is the no-config-change kicker for ops/debug — it re-reads the server's `~/.finlet/plugins.json` and reinitializes the named plugin in place."*
- Modified: `tests/api/test_routes_settings.py` — under the existing `TestPlugins` class:
  1. Update `test_update_plugin_config` (line 570): assert `resp.json()` now contains `health` with `health.status` matching the post-reload state. The `status` top-level key is now derived from `health.status` (so for a happy path it's still `"updated"`).
  2. Update `test_update_plugin_enabled_only` (line 590): same shape update; if the plugin wasn't reloaded (no api_key/email change), `health` may be `None` — make the assertion conditional.
  3. Update `test_user_a_plugin_config_does_not_affect_user_b` (line 611): the per-user dict isolation invariant is preserved; the test should still pass after the rewrite. If it breaks, that's a real bug — investigate, do not paper over.
  4. New test: `test_update_plugin_edgar_with_email_returns_healthy` — PUT `{plugin: "edgar", email: "x@y.com"}` → assert `resp.json()["health"]["status"] == "healthy"` and the response is fully populated (no None on `health`). Stub the EDGAR plugin's `set_identity` to avoid hitting the SEC API in tests.
  5. New test: `test_update_plugin_edgar_without_email_returns_unhealthy` — PUT `{plugin: "edgar", api_key: ""}` (no email) → assert `resp.json()["health"]["status"] == "unhealthy"` and `resp.json()["status"] == "unhealthy"` and the message is non-empty. (No `contextlib.suppress` swallowing.)
  6. New test: `test_update_plugin_serializes_with_health_check` — concurrent `update_plugin` and `health_check_all` (use `asyncio.gather`) — neither sees a half-built plugin instance. Assert via the existing `_reload_lock` semantics; if this test cannot be written purely against the registry without monkeypatching internals, document why and skip — but try first.
- Modified: `docs/ARCHITECTURE.md` — add a one-paragraph "Plugin config write paths" subsection (place it near the existing routes documentation, or in a new "Plugin Configuration" section if neither exists). Content: per the scope doc — `PUT /v1/settings/plugins` is the canonical authenticated write surface (dashboard + CLI). `POST /v1/plugins/{name}/reload` is the no-config-change kicker. Legacy local `~/.finlet/plugins.json` is dev-only. Multi-tenant isolation is **not** delivered by this refactor — see `settings_service.py:223-226`.

**Deliverable:** `PUT /v1/settings/plugins` returns a `PluginUpdateResponse` with a populated `health: PluginHealthItem` field reflecting post-reload status. Init failures surface as `health.status == "unhealthy"` with a non-empty `message`, never as a silent `{"status": "updated"}`. Existing dashboard code continues to work unchanged (additive response).

**Validation:**
- [ ] `uv run pytest tests/api/test_routes_settings.py::TestPlugins -x -q` — all existing + 3 new tests pass.
- [ ] `uv run pytest tests/api/ -x -q` — full API suite still green (smoke for unintended regression).
- [ ] `uv run ruff check finlet/api/services/settings_service.py finlet/api/schemas/settings.py finlet/api/routes_settings.py finlet/api/routes_health.py` — clean.
- [ ] `uv run mypy finlet/api/services/settings_service.py finlet/api/schemas/settings.py finlet/api/routes_settings.py` — clean.
- [ ] `grep -c contextlib.suppress finlet/api/services/settings_service.py` — exactly **0** (the suppress on `target.initialize` is gone).
- [ ] Manual: launch local server (`uv run uvicorn finlet.api.app:app`), `curl -X PUT -H "Authorization: Bearer $FINLET_API_KEY" -H "Content-Type: application/json" -d '{"plugin":"edgar","email":"test@example.com"}' http://localhost:8000/v1/settings/plugins | jq .health.status` → prints `"healthy"`.

**Agent instructions:**
- You MUST `git add` all 6 modified files + `git commit` before finishing. Worktrees that don't commit lose all work.
- Commit message: `[Team A]: PUT /v1/settings/plugins returns post-reload PluginHealthItem; drop suppress(Exception)` — body summarizes the contract change and links to `docs/bug-hunt/refactor-queue/plugin-config-propagation.md`.
- Follow the existing patterns in `finlet/api/services/settings_service.py` for typing, logging (structlog), and error handling. Don't introduce new conventions.
- Preserve the existing docstring at `settings_service.py:223-226` verbatim — it's load-bearing for the multi-tenant out-of-scope acknowledgement.
- The `_reload_lock` semantics are documented at `finlet/plugins/base.py:694` — readers do NOT take the lock, this is intentional. Do not "fix" it.
- Do NOT touch `dashboard/settings.js`. The refactor is server-side only on this team.
- If you find that `health_check_all()` returns a different shape than the route handler expects (it returns `dict[str, PluginHealthRecord]` per `finlet/plugins/base.py`), do the conversion to `PluginHealthItem` in `update_plugin` directly — match the existing `routes_health.py:177-205` pattern.

---

### Team B: CLI redirect onto `PUT /v1/settings/plugins`

**Blocked by:** Team A merged to main (request and response contract must exist before CLI tests stub against it).

**Read these files first:**

- `docs/bug-hunt/refactor-queue/plugin-config-propagation.md` — scope context.
- `finlet/cli.py:286-335` — current `plugins_add`. Note the local-write block (lines 310-319) and the POST-reload block (lines 323-335). Both are deleted; replaced by a single `PUT /v1/settings/plugins` call.
- `finlet/cli.py:229-285` — current `plugins_list`. Note the local-config cross-reference at line 271 (`_load_plugins_config()`) and the `(configured)` marker at line 282. Both replaced by a single `GET /v1/settings/plugins` call (which returns masked configs per user) — see `finlet/api/routes_settings.py:119` (`GET /plugins`) for the response shape.
- `finlet/cli.py:218-226` — `_load_plugins_config` / `_save_plugins_config` helpers (the local-file IO). After this team, both helpers can be deleted (no callers); keep them for one release as dead code only if there's a packaging concern, otherwise remove.
- `finlet/cli.py:10-12` — `_API_URL` constant + `PLUGINS_CONFIG_PATH` import. Delete the `PLUGINS_CONFIG_PATH` import after removing all references.
- `finlet/api/schemas/settings.py` — the post-Team-A `PluginUpdateResponse` (with the `health` field). Use this to know what to read from the response.
- `tests/test_cli.py:728-870` — current `TestPluginsAddCommand`. Note:
  - Test at line 754 (`test_plugins_add_drops_restart_message_and_surfaces_live_status`) — keep, but stub `PUT /settings/plugins` instead of POST `/reload`.
  - Test at line 794 (`test_plugins_add_surfaces_unhealthy_status`) — keep, stub returns `health.status == "unhealthy"`.
  - Test at line 822 (`test_plugins_add_server_unreachable_writes_config_with_warning`) — UPDATE: the CLI no longer writes a local file. The test should assert "no local file written" AND a clear error printed. If the user explicitly wants offline-resilient local cache, that's a separate scope; for now, server-unreachable is a hard error.
  - Test at line 844 (`test_plugins_add_unknown_plugin_returns_404`) — keep, stub `PUT /settings/plugins` to return 404 (or 422; check what FastAPI returns for an unknown plugin in `update_plugin`).
  - Line 791: `assert called_url.endswith("/v1/plugins/edgar/reload")` — change to `assert called_url.endswith("/v1/settings/plugins")`.
  - Line 837: `assert (tmp_path / "plugins.json").exists()` — change to `assert not (tmp_path / "plugins.json").exists()` (CLI no longer writes locally).

**Files touched (2):**

- Modified: `finlet/cli.py`:
  - `plugins_add` (lines 286-335): replace local-write + POST `/reload` with a single `PUT /v1/settings/plugins` carrying `{"plugin": name, "api_key": api_key, "email": email, "enabled": True}` (omit None fields). Auth: `Authorization: Bearer $FINLET_API_KEY`. Surface response: read `response.json()["health"]["status"]` and `response.json()["health"]["message"]`, print `Plugin '{name}' status: {status}{suffix}`. Three error paths: missing `FINLET_API_KEY` (clear actionable message, exit 2), network error (existing message, exit 1), 401/403 (auth-failed message: "FINLET_API_KEY rejected — check `finlet auth login` or regenerate a key from the dashboard"), 4xx other (echo response body).
  - `plugins_list` (lines 229-285): replace `_load_plugins_config()` with `GET /v1/settings/plugins`, derive `(configured)` marker from the keys present in the server response. Keep the existing `/v1/plugins/health` call for status. Same 401/403 handling.
  - Delete `_load_plugins_config`, `_save_plugins_config`, and the `PLUGINS_CONFIG_PATH` import if no remaining callers (verify via `grep -c PLUGINS_CONFIG_PATH finlet/cli.py` after edits — should be **0**).
  - The `--server-api-key` flag on `plugins_add` (line 291-296) is now redundant with `FINLET_API_KEY` env. Drop the flag; keep the env var. Update the typer.Option help text.
- Modified: `tests/test_cli.py` (`TestPluginsAddCommand`, lines 728-870):
  - Update all 4 existing tests per the file:line notes above.
  - New test: `test_plugins_add_missing_api_key_exits_with_actionable_message` — invoke without `FINLET_API_KEY` in env, assert exit code 2 and stderr contains the actionable message.
  - New test: `test_plugins_list_uses_server_side_configured_marker` — stub `GET /v1/settings/plugins` to return `{"plugins": {"finnhub": {...}}}` and `GET /v1/plugins/health` to return the standard list, assert the CLI's stdout shows `finnhub (configured)` and not `edgar (configured)`.

**Deliverable:** `finlet plugins add edgar --email X` against `https://finlet.dev` (with `FINLET_API_KEY` set) PUTs to `/v1/settings/plugins` and prints `Plugin 'edgar' status: healthy — OK` (or `unhealthy` if EDGAR's init rejects). No local `~/.finlet/plugins.json` writes. End-to-end Phase 5.5 retest from laptop succeeds.

**Validation:**
- [ ] `uv run pytest tests/test_cli.py::TestPluginsAddCommand -x -q` — all 4 updated + 1 new tests pass.
- [ ] `uv run pytest tests/test_cli.py -x -q` — full CLI test suite still green.
- [ ] `uv run ruff check finlet/cli.py tests/test_cli.py` — clean.
- [ ] `uv run mypy finlet/cli.py` — clean.
- [ ] `grep -c PLUGINS_CONFIG_PATH finlet/cli.py` — exactly **0** (and same in `tests/test_cli.py` for any stale local-file fixture references).
- [ ] `grep -c '/v1/plugins/.*reload' finlet/cli.py` — exactly **0** (CLI no longer pokes `/reload`).
- [ ] Manual end-to-end (deferred to Phase 5.5 retest after merge): `FINLET_API_KEY=... finlet plugins add edgar --email retest@example.com` against `https://finlet.dev` → exit 0, stdout `Plugin 'edgar' status: healthy — OK`, then `curl https://finlet.dev/v1/plugins/health | jq '.[] | select(.name=="edgar") | .status'` → `"healthy"`.

**Agent instructions:**
- You MUST `git add` both files + `git commit` before finishing.
- Commit message: `[Team B]: finlet plugins add/list use PUT /v1/settings/plugins (drops local plugins.json writes)` — body summarizes the redirect and explicit deletion of `_load_plugins_config` / `_save_plugins_config` / `PLUGINS_CONFIG_PATH` import (if applicable).
- The CLI's existing `httpx` patterns at line 248-256 (used by `plugins_list`) are the template for the new HTTP call. Don't introduce a new HTTP client.
- Don't refactor unrelated CLI commands. Stay in `plugins_add` and `plugins_list`.
- Don't touch `finlet/config.py` (`PLUGINS_CONFIG_PATH` constant is still used by the server-side reload endpoint; only the CLI's import is removed).
- If you discover that `_load_plugins_config` / `_save_plugins_config` are imported by tests at `tests/test_cli.py:741, 744, 745, 749, 750`, those tests are for the OLD CLI behavior — delete the fixtures along with the helpers, do not preserve dead test code.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A's response shape change breaks dashboard | Low | High | Additive change only. `health` is optional and never replaces `status`. Verify in Team A by manually loading the dashboard against the local server post-merge. |
| `update_plugin` calling `registry.reload()` introduces a race not present today | Medium | Medium | `_reload_lock` already serializes. New tests cover concurrent reload + health_check. If the test fails to write cleanly, document and ship without (the lock is the same as `/reload`'s). |
| EDGAR `set_identity` global-state mutation is exposed by tests that previously coexisted because of `contextlib.suppress` | Low | Low | The suppress was hiding it; tests that depended on the suppress will break. Treat that as a real test signal — fix the test to set up the global state correctly, don't restore the suppress. |
| CLI tests previously passed because they asserted local file writes that are now gone — agent might leave them as `not exists` AND silently break the new flow | Medium | Medium | Validation includes `grep -c PLUGINS_CONFIG_PATH tests/test_cli.py` — non-zero count means dead fixtures left behind. |
| `FINLET_API_KEY` env var name changes existing user expectations | Low | Low | The CLI already accepted this env var via `--server-api-key, envvar="FINLET_API_KEY"`. Promoting it to required doesn't rename it. Document the requirement in `--help`. |
| `health_check_all()` mocking in API tests turns out to require deeper plugin-registry stubs than expected | Medium | Low | If stubbing is too invasive, a single integration test exercising the full path against a stub plugin (like `tests/api/test_plugin_health.py` already does) is acceptable. Don't over-mock. |
| Phase 5.5 retest after merge still fails because of an architectural surprise we missed | Low | High | If retest fails, the refactor's verdict on the next bug-hunt iteration becomes `incomplete`. The ledger captures it; the next iteration's gate triggers a follow-up scope. This is the designed feedback loop. |

## Session Plan

### Session 1 — Server-side contract (Team A only)

**Sequential:** Team A only.

**Merge order:** Team A → targeted test gate (`uv run pytest tests/api/test_routes_settings.py::TestPlugins -x -q`) → if green, merge to main.

**Session checkpoint:** Full test suite (`uv run pytest -x -q`) after merge. If a non-API test breaks, that's a regression — investigate before starting Session 2.

### Session 2 — CLI redirect (Team B only)

**Blocked by:** Session 1 merged to main.

**Sequential:** Team B only.

**Merge order:** Team B → targeted test gate (`uv run pytest tests/test_cli.py::TestPluginsAddCommand -x -q`) → if green, merge to main.

**Session checkpoint:** Full test suite + a manual `--help` smoke (`uv run finlet plugins --help`, `uv run finlet plugins add --help`) to confirm the dropped `--server-api-key` flag is gone and the help text mentions `FINLET_API_KEY`.

### Post-merge — Phase 5.5 deploy gate

After both merges are on main and CI deploys, the orchestrator runs the bug-hunt Phase 5.5 retest:

1. From laptop with `FINLET_API_KEY` set: `finlet plugins add edgar --email retest@example.com` against `https://finlet.dev` → exit 0, stdout `Plugin 'edgar' status: healthy — OK`.
2. `curl -H "Authorization: Bearer $FINLET_API_KEY" https://finlet.dev/v1/plugins/health | jq '.[] | select(.name=="edgar") | .status'` → `"healthy"`.

If both pass, this iteration's `pending_recurrences.jsonl` entry for `edgar-plugin-stale-after-cli-config` is marked resolved (the refactor doc's `verdict: effective` is set on the next bug-hunt run, after that iteration's triage confirms zero new instances of the same shape).

If retest fails, mark the doc's `verdict: incomplete` and surface the surviving sub-gap to the user. Do not auto-iterate.
