# Modal Stacking Refactor — Execution Plan

> Generated from `docs/bug-hunt/refactor-queue/modal-stacking.md`. 2026-04-28.
> Driven by recurrence-data: `modal-stacking` cluster has 2 instances across 2 iterations under the new 2/2 refactor gate.

## Constraints

- **Closed-source repo, pre-launch.** Don't introduce new global names beyond a single namespaced controller.
- **Trusted Types active.** No new `.innerHTML` writes; data attributes + classList only. `scripts/lint-trusted-types.sh` runs in pre-commit.
- **Existing event-bus pattern is the template.** New controller follows `dashboard/event-bus.js`'s shape (single `window.finlet*` singleton, idempotent attach).
- **Out of scope:**
  - `dashboard/trade-ticket.js` — slide-out sidebar, not a modal. Leave at z-index 1100.
  - `dashboard/error-boundary.js` — emergency overlay; must stay on top regardless of stack. Leave at z-index 500.
  - Modal animation/transitions — preserve current CSS. The controller doesn't own visual style.
  - Dialog focus-trapping (a11y) — separate concern; build later on top of this controller.
  - Server-driven toasts/notifications — toasts ≠ modals.
- **Belt-and-suspenders preservation.** Every modal currently has `style="display:none"` inline AT REST and `display=''` set on open. This is intentional (per the iteration `20260428T013300Z6e79` decision). The controller must preserve it — set `display=''` on open, `display='none'` on close.

## File Conflict Table

| File | Touched by Teams |
|------|-----------------|
| `dashboard/modal-controller.js` (new) | A |
| `dashboard/index.html` | A |
| `dashboard/billing.html` | A |
| `dashboard/marketplace.html` | A |
| `dashboard/styles.css` | A |
| `dashboard/app.js` | B |
| `dashboard/onboarding.js` | B |
| `dashboard/leaderboard-submit.js` | B |
| `dashboard/billing.js` | B |
| `dashboard/marketplace.js` | B |
| `tests/e2e/journey-modal-stacking.spec.ts` (new) | B |

No shared files between Teams A and B. Both teams can be in-flight in parallel worktrees, but B can't merge until A is on main (B imports A's API at runtime).

## Dependency Graph

- **Team A (independent)** — starts immediately
- **Team B (blocked by A merge)** — needs `dashboard/modal-controller.js` on main before Team B's worktree can lint or test

## Critical Path

Team A → Team B (single sequential chain)

---

## Teams

### Team A: Modal controller core + declarative markup

**Blocked by:** none — can start immediately.

**Read these files first:** (CRITICAL — do NOT skip)
- `docs/bug-hunt/refactor-queue/modal-stacking.md` — the spec this team implements (root cause, scope, break-even)
- `dashboard/event-bus.js` — module pattern reference. Match the shape: single window-attached singleton, idempotent attach guard, no leaked globals beyond `window.finletBus` / `window.finletModal`.
- `dashboard/event-contract.md` — doc/comment conventions used by the bus; follow the same style.
- `dashboard/styles.css` — current z-index landscape. Notably: `.modal-overlay` (300), `.session-details-panel` (300), `.nav-drawer` (300), `.onboarding-overlay` (500), `.error-boundary` (500), `.trade-ticket` (1100). The new `--modal-base-z` should sit above 500 but below 1099 (trade-ticket-backdrop).
- `dashboard/index.html` (lines 74, 361, 474, 486 — modal element sites; line 426 — trade-ticket aside, EXCLUDED; line 550 — error-boundary, EXCLUDED)
- `dashboard/billing.html:415` — billing modal markup
- `dashboard/marketplace.html` — marketplace modal markup
- `scripts/lint-trusted-types.sh` — confirm what the linter blocks; this team's diff is data-attributes + classList only, so it should pass clean

**Files touched:**
- **New:** `dashboard/modal-controller.js` — exports `window.finletModal` with this exact API:
  ```
  window.finletModal.open(id)              → returns close handle (function)
  window.finletModal.close(id)             → void (idempotent)
  window.finletModal.suppress(suppressor_id, while_open_id) → void
                                            // when `while_open_id` is in the open
                                            // stack, `suppressor_id` gets
                                            // pointer-events: none + z-index 0
  window.finletModal.topmost()             → string | null
  window.finletModal.isOpen(id)            → boolean
  ```
  Internal stack: `Array<string>`. On `open(id)`, push id, set element's `style.zIndex = stackBase + stack.length`, `style.pointerEvents = 'auto'`, `style.display = ''`, ensure `.fl-modal--visible` class added. All other modals in the stack get `pointerEvents = 'none'` and lower z-index. On `close(id)`, splice from stack, set `style.display = 'none'`, set `style.pointerEvents = 'none'`, remove `.fl-modal--visible`. Idempotent: `close` on a non-open modal is a no-op. Read `--modal-base-z` from `getComputedStyle(document.documentElement)`.

- **Modified:** `dashboard/index.html` — every modal element gets `data-modal-id="<unique-id>"` and the `fl-modal` class added to its existing class list. Specifically:
  - `#create-session-modal` → `data-modal-id="create-session"` + add `fl-modal`
  - `#delete-session-modal` → `data-modal-id="delete-session"` + add `fl-modal`
  - `#leaderboard-submit-modal` → `data-modal-id="leaderboard-submit"` + add `fl-modal`
  - `#session-details-panel` → `data-modal-id="session-details"` + add `fl-modal`
  - **DO NOT TOUCH:** `#error-boundary`, `.trade-ticket` aside, `.toast-container`, `.nav-drawer`, `.user-menu-dropdown`. These are excluded. The wizard overlay is dynamically created in `onboarding.js`; Team B handles it.

- **Modified:** `dashboard/billing.html:415` — billing's `.modal-overlay` gets `data-modal-id="billing-modal"` + `fl-modal` class.

- **Modified:** `dashboard/marketplace.html` — marketplace's `#modal-overlay` gets `data-modal-id="marketplace-modal"` + `fl-modal` class.

- **Modified:** `dashboard/styles.css`:
  - Add CSS custom property at `:root`: `--modal-base-z: 1000;` (above onboarding-overlay 500, below trade-ticket-backdrop 1099)
  - Add `.fl-modal { pointer-events: none; }` default. Do NOT set `display: none` here — the inline `style="display:none"` belt-and-suspenders pattern stays in HTML.
  - Keep all existing per-modal z-index values intact for now. The runtime controller wins via inline style. Don't remove the existing values — Team B will run a follow-up grep to confirm everything is migrated before any cleanup.

**Deliverable:** `window.finletModal` exists with documented API. All non-excluded modal elements carry `data-modal-id` + `.fl-modal`. CSS variable defined. **No JS open/close call site has been migrated yet** — the dashboard works exactly as before. This is a pure infrastructure-add merge; current modal flows are untouched.

**Validation:**
- [ ] `bash scripts/lint-trusted-types.sh` exits 0
- [ ] `grep -c 'data-modal-id' dashboard/index.html dashboard/billing.html dashboard/marketplace.html` returns ≥ 6 (4 in index.html + 1 each in billing/marketplace)
- [ ] `grep -E '^\s*--modal-base-z:' dashboard/styles.css` returns ≥ 1
- [ ] `grep -E 'window\.finletModal\s*=' dashboard/modal-controller.js` returns 1
- [ ] `npx playwright test tests/e2e/journey-onboarding.spec.ts tests/e2e/journey-04-dashboard.spec.ts tests/e2e/journey-07-leaderboard.spec.ts` — all pass (no behavior change yet; this confirms Team A didn't regress anything)
- [ ] No new `console.error` in any of those tests' captured logs
- [ ] `grep -E '(trade-ticket|error-boundary)' dashboard/modal-controller.js` returns 0 (out-of-scope elements not referenced)

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. The worktree is cleaned on exit; uncommitted work is lost.
- Wire `dashboard/modal-controller.js` into the dashboard load order. It must be loaded before any consumer (Team B) imports it. Easiest path: add a `<script>` tag in `dashboard/index.html` (and `dashboard/billing.html`, `dashboard/marketplace.html`) immediately after `event-bus.js` is loaded. Match the existing script-tag pattern.
- Idempotent attach: if `window.finletModal` already exists (e.g., script loaded twice), do NOT re-attach. Mirror `dashboard/event-bus.js`'s guard.
- Do NOT touch any consumer JS file in this team (`app.js`, `onboarding.js`, `leaderboard-submit.js`, `billing.js`, `marketplace.js`). Migrations are Team B's scope. Touching consumer JS here will create file-level merge conflict with Team B.
- The "belt-and-suspenders" `style="display:none"` inline values stay in HTML at rest. The controller sets `display=''` on open, `display='none'` on close.
- `.error-boundary` (line 550 in index.html) is OUT of scope. Do not give it a `data-modal-id`. It's an emergency overlay that must stay above the modal stack.
- `.trade-ticket` is OUT of scope. It's a slide-out aside, not a modal.

---

### Team B: Consumer migrations + stacking regression test

**Blocked by:** Team A's merge to main (Team B's worktree pulls from main and needs `dashboard/modal-controller.js` to exist).

**Read these files first:** (CRITICAL)
- `dashboard/modal-controller.js` (output of Team A) — the API you're calling
- `dashboard/event-bus.js` — bus subscribe/unsubscribe pattern (Team B's onboarding-suppression logic may need bus events)
- `dashboard/app.js:985-1005` — current `delete-session-modal` show/hide
- `dashboard/app.js:1197-1227` — current `openCreateSessionModal` / `closeCreateSessionModal`
- `dashboard/onboarding.js:218-235` — `showWizard()` — dynamic overlay creation
- `dashboard/onboarding.js` (search for `onboarding-overlay--hidden`, ~line 640) — current "Open Session Creator" suppression hack
- `dashboard/leaderboard-submit.js:129-159` — current open/close modal flow with transitionend dance
- `dashboard/billing.js:317-322` — `display = 'flex'` pattern (note: different from index.html modals)
- `dashboard/marketplace.js:335-340` — same pattern
- `tests/e2e/journey-onboarding.spec.ts` — pattern for new modal-stacking spec
- `tests/e2e/journey-07-leaderboard.spec.ts` — leaderboard flow assertions
- `docs/bug-hunt/20260428T163727Z4f4f/HANDOFF.md` — sections #1 (modal-stacking retest); the wizard-blocks-create-session bug is the canonical regression to validate against

**Files touched:**

- **Modified:** `dashboard/app.js`:
  - Lines ~985-1005 — replace delete-session show/hide with `window.finletModal.open('delete-session')` / `.close('delete-session')`. Drop the manual `display = ''` and `display = 'none'` lines.
  - Lines ~1197-1227 — same for create-session. Replace the 250ms `setTimeout` + class-toggle dance with `window.finletModal.open('create-session')`. Preserve the input.focus() call.
  - Search the rest of `app.js` for any remaining `style.display\s*=\s*['"](?:block|flex|none|'')` patterns and migrate them (or leave with a comment if they're non-modal — be explicit).

- **Modified:** `dashboard/onboarding.js`:
  - `showWizard()` (~218-235): when the wizard `<div>` is dynamically created, ALSO set `data-modal-id="onboarding"` and add `fl-modal` to its class list. Then call `window.finletModal.open('onboarding')` instead of `classList.add('onboarding-overlay--visible')`. Keep the visual-style class (`onboarding-overlay`) — it controls appearance, not visibility/stack.
  - `hideWizard()` / `closeWizard()`: call `window.finletModal.close('onboarding')` instead of `classList.remove`.
  - "Open Session Creator" handler (~640): replace the manual `classList.add('onboarding-overlay--hidden')` toggle with `window.finletModal.suppress('onboarding', 'create-session')`. The controller will auto-restore when create-session closes — drop any code that manually re-adds the wizard.

- **Modified:** `dashboard/leaderboard-submit.js`:
  - `openLeaderboardSubmitModal()` (~129-137): replace `display = ''` + `classList.add('--visible')` + `input.focus()` with `window.finletModal.open('leaderboard-submit')` followed by `input.focus()`.
  - `closeLeaderboardSubmitModal()` (~142-159): replace the `classList.remove` + transitionend listener + 250ms setTimeout dance with `window.finletModal.close('leaderboard-submit')`. The CSS transition still runs because the `--visible` class fade is preserved on `.fl-modal--visible` (Team A added that class).

- **Modified:** `dashboard/billing.js:317-322`:
  - Replace `modal.style.display = 'flex'` with `window.finletModal.open('billing-modal')`.
  - Replace `modal.style.display = 'none'` with `window.finletModal.close('billing-modal')`.

- **Modified:** `dashboard/marketplace.js:335-340`:
  - Same as billing.

- **New:** `tests/e2e/journey-modal-stacking.spec.ts`:
  - Spec 1 — wizard-blocks-create-session regression. Open onboarding wizard. Click "Open Session Creator." Use `page.evaluate(() => document.elementFromPoint(submitX, submitY))` to assert the result is the Create Session submit button (not the onboarding-overlay div). Click submit. Assert form submits.
  - Spec 2 — leaderboard-blocks-create-session (mirror of issue 1 in the ledger). Open Create Session, then attempt to open Submit-to-Leaderboard. Assert leaderboard submit is topmost; close it; assert create-session is reachable again.
  - Use `journey-onboarding.spec.ts` as the structural template.

**Deliverable:** Every modal in the dashboard opens/closes through `window.finletModal`. Stacking is correct (topmost is always interactive; lower modals are pointer-events:none and lower z-index). The wizard suppresses itself when create-session is open. Both regression cases from the ledger are covered by Playwright tests.

**Validation:**
- [ ] `bash scripts/lint-trusted-types.sh` exits 0
- [ ] `npx playwright test tests/e2e/journey-onboarding.spec.ts` passes (no regression)
- [ ] `npx playwright test tests/e2e/journey-04-dashboard.spec.ts` passes
- [ ] `npx playwright test tests/e2e/journey-07-leaderboard.spec.ts` passes
- [ ] `npx playwright test tests/e2e/journey-modal-stacking.spec.ts` passes (NEW)
- [ ] `grep -c 'finletModal\.' dashboard/app.js dashboard/onboarding.js dashboard/leaderboard-submit.js dashboard/billing.js dashboard/marketplace.js` returns ≥ 10 (at least open + close per modal × 5 modals)
- [ ] `grep -nE "style\.display\s*=\s*['\"](block|flex)" dashboard/app.js dashboard/onboarding.js dashboard/leaderboard-submit.js dashboard/billing.js dashboard/marketplace.js` returns 0 (all migrated)
- [ ] `grep -nE 'classList\.(add|remove|toggle)\([^)]*\-\-(visible|hidden)' dashboard/onboarding.js` returns 0 for `onboarding-overlay--visible` / `--hidden` (those are now controller-managed); other `--visible` toggles unrelated to modals are fine
- [ ] `grep -E '(modal-controller|finletModal)' dashboard/trade-ticket.js dashboard/error-boundary.js` returns 0 (out-of-scope files untouched)

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing
- Use the `window.finletModal` API exactly as documented in `dashboard/modal-controller.js`. Do NOT add new methods to it; if you need a method that doesn't exist, surface it back as a question rather than inventing one
- The wizard's dynamically-created element MUST be tagged with `data-modal-id="onboarding"` and `.fl-modal` AT CREATION TIME inside `onboarding.js:218-235` — the controller can't manage what doesn't have the tag
- For `modal.suppress(suppressor, target)`: the controller infers from the open stack — when `target` is open, `suppressor` is forced pointer-events:none. When `target` closes, `suppressor` is restored automatically. Don't manually toggle anything on the wizard during create-session open/close
- The new Playwright spec MUST use `document.elementFromPoint(...)` for the stacking assertion. Asserting visibility alone (e.g., `expect(submitBtn).toBeVisible()`) is what the bug-hunt iteration would have failed on — visibility passes, pointer-events failed silently. Use elementFromPoint as the truth source.
- Preserve `input.focus()` calls. The controller doesn't manage focus; consumers do.
- Don't touch `dashboard/modal-controller.js` (Team A's deliverable), `dashboard/trade-ticket.js`, or `dashboard/error-boundary.js`. The grep validations above will fail if you do.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A's z-index variable causes visual stacking regression on existing modals | Medium | Medium | Team A keeps all existing per-modal z-index values intact in CSS. The controller's runtime inline `z-index` overrides per-modal-on-open. After Team B migrates everything, a follow-up cleanup task can remove the old values. Validation: Playwright screenshot diff in journey-04-dashboard. |
| Wizard's dynamic overlay element doesn't get the `data-modal-id` attribute at creation | Medium | High | Team B's "agent instructions" call this out explicitly. Validation grep: `grep "data-modal-id=\"onboarding\"" dashboard/onboarding.js` returns ≥ 1. |
| `modal.suppress()` semantics drift between Team A's implementation and Team B's expectation | Medium | Medium | API documented in Team A's spec with exact behavior: while target is in stack, suppressor is pointer-events:none + lowered z-index. Team A writes a unit comment showing the exact behavior. Team B reads the controller before migrating. |
| Billing/marketplace pages don't have e2e coverage; regression goes unnoticed | High | Medium | Risk accepted — both pages are dashboard-adjacent surfaces with low pre-launch traffic. Team B's grep validations confirm migration completeness. If billing breaks post-merge, it's caught in the next bug-hunt iteration's blind walk. |
| Trade-ticket sidebar is accidentally pulled into the controller | Low | High | Both teams' instructions explicitly exclude trade-ticket. Validation grep on Team B catches violations: `grep finletModal dashboard/trade-ticket.js` returns 0. |
| Error-boundary overlay is accidentally pulled in | Low | High | Same as above. Validation grep included. |
| Existing tests' `expect(modal).toBeVisible()` assertions silently pass even when pointer-events is broken (the bug we're fixing) | Medium | High | New `journey-modal-stacking.spec.ts` uses `document.elementFromPoint(x,y)` for hit-testing, which is the truth source. This is the regression-prevention test. |
| 250ms close-transition setTimeout dance is needed for visual smoothness; controller may close too fast | Low | Low | The `.fl-modal--visible` class still drives the CSS transition (Team A defines it). The controller removes the class on close; CSS handles the fade-out. setTimeout removal is fine. |
| `dashboard/modal-controller.js` script-tag load order wrong | Medium | High | Team A wires the script tag explicitly in HTML. Validation: load `localhost:dashboard`, run `console.log(window.finletModal)` — should not be undefined. Add this assertion as a sanity check at the top of the new e2e spec. |

## Session Plan

### Session 1: Modal controller + migrations (single session)

**Sequential merge order:**
1. Team A merges first (controller core + declarative markup). Validation gates pass.
2. Team B merges second (consumer migrations + new e2e spec). Validation gates pass.

**Why one session:** the chain is short (two teams), the dependency is concrete (B imports A's runtime API), and there's no parallelism to exploit because all migrations need the controller to exist first. Bundling reduces handoff cost.

**Worktree strategy:** spawn both worktrees concurrently if /exec-plan supports concurrent-spawn-with-merge-gating. Team B's worktree won't pass its own validation until Team A is on main, so the natural ordering enforces itself.

**Session checkpoint:** after both merge, run the FULL Playwright suite (`npx playwright test`) and `bash scripts/lint-trusted-types.sh` once on main. If clean, mark `docs/bug-hunt/refactor-queue/modal-stacking.md` `status: shipped` (no `verdict:` yet — that's set on the next bug-hunt iteration).

## Verdict-tracking notes (for the next iteration's Phase 6)

After this refactor lands, the next `/bug-hunt` iteration's Phase 6 sets the `verdict:` field on `docs/bug-hunt/refactor-queue/modal-stacking.md` based on:
- **`effective`** — zero new `modal-stacking` instances in the next triage
- **`incomplete`** — a new `modal-stacking` finding with `same_root_cause_as` pointing to `modal-stacking-leaderboard` or the wizard-blocks-create-session retest, AND scope_hint indicates a file the refactor didn't migrate (e.g., `error-boundary.js` if it turns out to be in scope after all)
- **`regressed`** — a new finding in `dashboard/modal-controller.js` itself (a bug introduced by the refactor)
