# Trade Ticket State-Sync Refactor — Execution Plan

> Generated from `docs/bug-hunt/refactor-queue/trade-ticket-state-sync.md` (status: ready). 2026-04-29.
> Driven by: 3 instances across 3 bug-hunt iterations of the same "open-then-subscribe" race in the Trade Ticket dialog (`trade-ticket-stale-cash` 8838ff1, `trade-ticket-cash-dash` f8a8365, `trade-ticket-cash-stale-during-fill` 086c558).
> Recon corrected/confirmed the spec on five points (see Constraints).

## Constraints

- **Single team, single worktree.** Recon confirmed the spec's conflict table is exact: only four files are touched (`dashboard/dialog-state-mirror.js` new, `dashboard/trade-ticket.js`, `dashboard/api-utils.js`, `dashboard/event-contract.md`) and all are exclusive to this refactor. Splitting into two teams (e.g., bus extension + mirror module vs. consumer migration) would create no parallelism — the migration cannot start until both the bus extension and the mirror module are on disk, and the bus extension is ~5 lines. The work is one author's continuous flow. One team is correct.
- **`getLastPublished` does NOT exist on the bus today.** Recon confirmed `grep -rn "getLastPublished\|lastPublished" dashboard/` returns zero. The spec's "if not already present" hedge resolves to "must be added." This is a small additive surface change to `dashboard/event-bus.js` — it must NOT break the existing frozen-singleton + idempotent-attach contract (`dashboard/event-bus.js:84` `Object.freeze`).
- **`window.finletBus` lives in `dashboard/event-bus.js`, NOT `dashboard/api-utils.js`.** The spec scope says "modified: api-utils.js (add `getLastPublished`)" but recon confirmed the bus is entirely owned by `event-bus.js`. The plan corrects this: the bus surface extension goes in `dashboard/event-bus.js`. `api-utils.js` is NOT touched. Spec's conflict table needs updating in the same commit (acknowledged in plan, see Risk Register).
- **Bus is `Object.freeze`'d at construction.** Adding `getLastPublished` requires it to be defined on the object literal passed to `Object.freeze`, not bolted on after. The IIFE pattern at `dashboard/event-bus.js:27-88` is the canonical place; both the cache and the new method live inside it.
- **`portfolio:updated` is the only bus event subscribed by a dialog today.** Recon confirmed `grep -n "finletBus.subscribe" dashboard/*.js` returns exactly two consumers: `dashboard/trade-ticket.js:136` (the migration target) and `dashboard/onboarding.js:184` (a one-shot `markStepComplete` subscriber on `onboarding:step-completed` / `order:filled` / `session:switched`, NOT a dialog mirror). Onboarding is OUT of scope — its subscribe pattern is fire-once-and-mark-done, no open/close lifecycle.
- **The SSE `currentSession.portfolio_metrics` mirror at `dashboard/app.js:1445-1455` STAYS.** Commit `086c558` added it to close the mid-fill gap. The new mirror module READS from `currentSession.portfolio_metrics` via the `primeFromCache` callback; removing the mirror would re-open the gap. App.js is NOT in this refactor's scope (per spec) — touching it would expand blast radius.
- **`tests/dashboard/` already exists** with `event-bus.spec.js` and `form-dirty-tracker.spec.js`. Test runner is `node --test` (built-in node:test). Pattern: VM-isolated bus instance + minimal DOM shim. The new spec follows the same pattern — see Team A `Read these files first`.
- **All cross-component dashboard wiring goes through `window.finletBus`.** Direct `addEventListener('finlet:...')` is forbidden (CLAUDE.md root rule).
- **Bare `.innerHTML =` outside `trustedHTML(...)` is blocked at pre-commit.** This refactor writes only to `textContent` (cash header is already textContent in `trade-ticket.js:192,250,287`); no innerHTML risk.
- **`dashboard/event-contract.md` MUST be updated in the same commit** as any bus surface change.
- **Closed-source repo, pre-launch.** No back-compat shims. Migrate `trade-ticket.js` cleanly to the new module; do not preserve `seedCashFromSessionSummary` / direct `subscribe` paths.
- **Out of scope** (per spec):
  - Other dialogs that read REST state once and don't subscribe to a bus event (e.g., order-detail view).
  - Modal stacking / focus-trapping / animation timing.
  - SSE replay / connection-loss recovery (transport-layer concern owned by `app.js` SSE handler).
  - Form-dirty-tracker interaction (separate, recently-shipped registry).
  - Anticipatory migration of future dialogs to the mirror module — the refactor pays back on the 4th instance, not by mass-migrating today.

## File Conflict Table

| File | Touched by Teams |
|------|-----------------|
| `dashboard/dialog-state-mirror.js` (new) | A |
| `dashboard/event-bus.js` | A (add `getLastPublished` + lastPublished cache) |
| `dashboard/trade-ticket.js` | A (rewrite open()/close() to consume mirror) |
| `dashboard/event-contract.md` | A (document `getLastPublished` + lastPublished cache invariant) |
| `dashboard/index.html` | A (add `<script src="dialog-state-mirror.js">` between `event-bus.js` and `trade-ticket.js`) |
| `tests/dashboard/dialog-state-mirror.spec.js` (new) | A |

No shared files with any other queued refactor. Single-team plan; no cross-team merge gates needed.

**Note on spec deviation:** The spec's conflict table lists `dashboard/api-utils.js` as the bus extension home. Recon confirmed the bus lives in `dashboard/event-bus.js`, not `api-utils.js`. The plan moves the surface extension to `event-bus.js` and adds `dashboard/index.html` to the conflict table (one new `<script>` tag for module load order). `api-utils.js` is NOT touched.

## Dependency Graph

- **Team A (independent)** — single team, no upstream dependencies. Internal sequencing inside the team's worktree:
  1. Extend `dashboard/event-bus.js` with `lastPublished` cache + `getLastPublished(eventName)`.
  2. Add unit tests for the bus extension to `tests/dashboard/event-bus.spec.js` (additive — keep existing tests).
  3. Create `dashboard/dialog-state-mirror.js`.
  4. Create `tests/dashboard/dialog-state-mirror.spec.js` (the spec's "new property test").
  5. Rewrite `dashboard/trade-ticket.js` `openTradeTicket()` body to consume `dialogStateMirror({...})`.
  6. Add `<script src="dialog-state-mirror.js">` to `dashboard/index.html` between `event-bus.js` and `trade-ticket.js`.
  7. Update `dashboard/event-contract.md` with the new bus-surface section + `lastPublished` invariant.
  8. Run all validation gates.
  9. `git add` + `git commit`.

## Critical Path

Team A (single team, single chain). No parallelism. Estimated wall-clock: 2.5–3.5 hours of agent work in one worktree.

---

## Teams

### Team A: Dialog state-mirror module + bus surface extension + trade-ticket migration

**Blocked by:** none — can start immediately.

**Read these files first:** (CRITICAL — do NOT skip)

- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync.md` — the spec this team implements. Note: spec lists `api-utils.js` as the bus extension home; the plan corrects this to `event-bus.js` (see Constraints). The proposed `dialogStateMirror({...})` signature in the spec (lines 47-56) is authoritative; do not invent new options.
- `dashboard/event-bus.js:27-88` — full IIFE. The `lastPublished` cache + `getLastPublished` go inside this IIFE so they share the same closure as `subscribe`/`publish`. The `Object.freeze` at line 84 must include the new method.
- `dashboard/event-contract.md:18-45` — public API surface section. Add a new subsection documenting `getLastPublished(eventName)` + `lastPublished` cache invariant (one entry per event name, replaced on each publish, returns `undefined` if no publish has happened).
- `dashboard/event-contract.md:50-65` — the `portfolio:updated` event entry. Add a "Last-published cache" sub-bullet pointing to the new mirror-module consumer.
- `dashboard/trade-ticket.js:1-14` (module-scope state: `tradeTicketOpen`, `tradeTicketCashBalance`, `tradeTicketBusUnsubscribe`) — module-scope state that gets folded into the mirror's lifecycle. After migration `tradeTicketBusUnsubscribe` is OWNED by the mirror's `close` handle; do not keep a parallel ref.
- `dashboard/trade-ticket.js:107-164` (`openTradeTicket()`): the body that gets rewritten. Specifically:
  - lines 119-123 — comment about dropping stale cached balance + setting `tradeTicketCashBalance = null`. Replace with mirror primeFromCache.
  - lines 132-139 — defensive unsubscribe + `bus.subscribe('portfolio:updated', handlePortfolioUpdateForTicket)`. Replace with `dialogStateMirror({...})` call. The mirror handles subscribe + unsubscribe.
  - line 150 — `seedCashFromSessionSummary()`. DELETE the call AND the function (lines 177-194); the mirror's `primeFromCache` + `onOpen` does this.
  - line 160 — `fetchCashBalance()`. KEEP the function (it's the canonical refetch path) but stop calling it from `openTradeTicket`; the mirror's `refetch` callback owns the call. The function itself remains because the mirror invokes it as a callback on shape-drift / transient-failure.
- `dashboard/trade-ticket.js:177-194` (`seedCashFromSessionSummary`): the function to DELETE. Its logic moves into the mirror's `primeFromCache` callback wired from the consumer.
- `dashboard/trade-ticket.js:199-219` (`closeTradeTicket()`): replace lines 215-218 (manual unsubscribe + null) with a call to the mirror's `close` handle returned by `dialogStateMirror({...})`. Stash the handle in module scope (replace `tradeTicketBusUnsubscribe` with `tradeTicketMirror`).
- `dashboard/trade-ticket.js:241-259` (`handlePortfolioUpdateForTicket`): the bus handler with the shape-drift fallback. KEEP its logic, but pass it as the `onUpdate` callback to the mirror. The fall-through to `fetchCashBalance()` becomes `refetch()` from the mirror's `onUpdate(payload, { refetch })` second arg. The function may be inlined into the mirror call site or kept as a module-scoped callback — agent's call.
- `dashboard/trade-ticket.js:264-298` (`fetchCashBalance()`): KEEP unchanged. The mirror's `refetch` callback wraps a call to this function. Do NOT change its body — it has tested defensive logic for slow-response stomp (`requestSessionId` snapshot at line 280, refuse-clobber at lines 288-293) that the mirror DOES NOT replicate; the mirror invokes it and trusts its return.
- `dashboard/app.js:1431-1468` — SSE `portfolio` event handler. **Read-only context.** This is the ONLY publisher of `portfolio:updated`. Note the `currentSession.portfolio_metrics` mirror block at 1445-1455 — `primeFromCache` reads from there. Do NOT modify `app.js`.
- `dashboard/index.html:582-594` — script load order. Current order:
  ```
  api-utils.js (582) → event-bus.js (584) → trade-ticket.js (591) → app.js (594)
  ```
  Insert `<script src="dialog-state-mirror.js">` between `event-bus.js` (584) and `trade-ticket.js` (591). Mirror imports nothing — it depends only on `window.finletBus.getLastPublished`, which exists once `event-bus.js` is parsed. `trade-ticket.js` calls `dialogStateMirror({...})`, which must exist before that script runs.
- `tests/dashboard/event-bus.spec.js:1-60` — existing bus unit-test pattern (VM-isolated `freshBus()` factory at lines 41-46). The new bus tests for `getLastPublished` follow this exact pattern. Add the new tests at the end of the file.
- `tests/dashboard/form-dirty-tracker.spec.js:1-40` — recently-shipped sibling-module unit-test pattern. The mirror's spec file follows the same `node --test` + minimal DOM shim shape. Use this as the structural template (NOT the e2e tests).
- `tests/e2e/journey-05-trade.spec.ts:389-476` — "available cash header never shows -- across open/close cycles" test (3 open/close cycles + poison-publish leak detector). Must continue to pass post-migration.
- `tests/e2e/journey-05-trade.spec.ts:488-552` — "available cash updates within 2s of bus portfolio:updated while dialog is open" test (well-formed publish + shape-drift fallback + still-open assertion). Must continue to pass post-migration.
- `tests/e2e/playwright.config.ts` — Playwright config location. Per `docs/refactor/dirty-state-tracker-v2/plan.md` "Followups", running `npx playwright test <file>` from repo root requires `--config=tests/e2e/playwright.config.ts`. Use the explicit `--config` flag in validation commands.
- `dashboard/event-contract.md:130-145` — "Adding a new event" / "Naming convention" sections. The bus-surface extension (a new METHOD, not a new event) needs its own section — add under "Public API surface" near the existing `subscribe` / `publish` doc. Naming: `getLastPublished` mirrors the existing camelCase.
- `scripts/lint-trusted-types.sh` — pre-commit guard. Confirm the new module + the rewritten consumer don't introduce raw `.innerHTML =`. Mirror module is data-only; consumer writes via `textContent`. Guard should pass clean.
- `docs/decisions/dashboard-event-bus.md` — context for the bus contract this refactor extends. Bus singleton is frozen, idempotent-attach, no bare globals. The `getLastPublished` extension preserves all three properties.
- `docs/refactor/dirty-state-tracker-v2/plan.md` — the most recent refactor plan that landed (commit `ed15c6c`). Read its "Constraints" and "Risk Register" for plan-doc style; in particular, follow its pattern for `__test__` symbol exports (cf. dirty-state-tracker plan lines 132-140) when exposing internal-state hooks for unit testing.

**Files touched:**

- **New:** `dashboard/dialog-state-mirror.js` — single module, ~120-150 LOC, exposes a single function on `window` (no module imports; vanilla script). Exact API:
  ```js
  // window.dialogStateMirror({...}) → { close, refetch }
  //
  // Subscribe to a bus event for the lifetime of an open dialog.
  // Behaviors (in order):
  //   1. On call: read `bus.getLastPublished(eventName)`. If a payload exists,
  //      call onOpen({ initialState: payload, refetch }) so the dialog paints
  //      with the most recent published value SYNCHRONOUSLY (closes the
  //      pre-publish gap from iter 20260428T031818Z2efa).
  //   2. If no published payload, call primeFromCache(). If it returns
  //      a value, call onOpen({ initialState: <primed>, refetch }) (closes
  //      the cold-open gap from iter 20260429T052717Z1a13 — the
  //      seedCashFromSessionSummary path).
  //   3. If neither yields a value, call onOpen({ initialState: undefined,
  //      refetch }) so the consumer can paint a placeholder. The refetch is
  //      always provided so the consumer can kick off a REST call if needed.
  //   4. Subscribe to the bus event for live updates. The subscription is
  //      attached BEFORE onOpen returns so a concurrent publish during the
  //      open() lifecycle lands on the live handler.
  //   5. On each bus publish: invoke onUpdate(payload, { refetch }). If
  //      onUpdate triggers a refetch (consumer's choice — typically when
  //      payload shape doesn't match what onUpdate expects), the mirror
  //      awaits the refetch and treats its result as the next "primed"
  //      value (calls onUpdate again with the refetched payload).
  //   6. On every onUpdate / refetch result: BEFORE invoking the consumer's
  //      paint, the mirror checks refuseClobber(currentValue, nextValue). If
  //      refuseClobber returns true, the mirror SKIPS the onUpdate call and
  //      leaves the lastPublished cache + last-applied-state untouched
  //      (closes the transient-failure gap from iter 20260428T031818Z2efa
  //      — fetchCashBalance failure stomping a known-good value with `--`).
  //   7. close() unsubscribes from the bus and calls onClose() if provided.
  //      Idempotent — calling close() twice is a no-op (matches event-bus
  //      unsubscribe idempotency).
  //
  // Required options:
  //   eventName       — string, the bus event to subscribe to
  //   onOpen          — fn({ initialState, refetch }) → void
  //   onUpdate        — fn(payload, { refetch }) → void
  //   primeFromCache  — fn() → initialState | undefined
  //   refetch         — fn() → Promise<initialState>
  //   refuseClobber   — fn(currentValue, nextValue) → boolean
  // Optional:
  //   onClose         — fn() → void (called from close())
  //
  // Returns: { close: fn() → void, refetch: fn() → Promise<void> }
  //
  // Internal state (module-private):
  //   appliedValue — last value the mirror let through to onUpdate / onOpen.
  //                  Used as the `currentValue` arg to refuseClobber.
  //   active       — boolean, false after close() to short-circuit late
  //                  bus publishes that race with close.
  //   unsubscribe  — closure returned by bus.subscribe()
  //
  // The module attaches itself once at load — `if (window.dialogStateMirror) return;`
  // mirrors the bus's idempotent-attach pattern.
  ```

  **Bare-globals discipline:** the module exposes `window.dialogStateMirror` (single function attached to window, NOT a singleton object with methods). Mirrors the `window.finletBus` pattern but for a factory function. The function returns a per-mirror handle `{ close, refetch }` so consumers don't need to manage subscriptions manually.

  **Internal `__test__` export:** for unit testing, the module also attaches `window.__dialogStateMirrorTest__` with `{ reset(): clear-all-handles, getActiveHandles(): [], }`. This is the ONLY mechanism for the unit test to inspect internal state. Mirrors the `__test__` pattern in `form-dirty-tracker.js`.

- **Modified:** `dashboard/event-bus.js`:
  - Inside the IIFE (between line 31 `const handlers` and line 33 `subscribe`):
    ```js
    /** @type {Map<string, *>} */
    const lastPublished = new Map();
    ```
  - Inside `publish` (line 62), AT THE TOP before the existing handler-iteration logic:
    ```js
    lastPublished.set(event, payload);
    ```
    This caches every publish, regardless of subscriber count. The cache mirrors the bus's "publish with no subscribers is a no-op" semantics — the cache is updated even if no one is listening, so a later subscriber can read the most recent value.
  - Add a new function inside the IIFE (after `publish`, before the `Object.freeze`):
    ```js
    function getLastPublished(event) {
      if (typeof event !== 'string' || !event) {
        throw new TypeError('finletBus.getLastPublished: event must be a non-empty string');
      }
      return lastPublished.has(event) ? lastPublished.get(event) : undefined;
    }
    ```
  - Update the `Object.freeze` call (line 84-87) to include the new method:
    ```js
    window.finletBus = Object.freeze({
        subscribe: subscribe,
        publish: publish,
        getLastPublished: getLastPublished,
    });
    ```
  - Update the docstring at lines 7-13 to mention `getLastPublished(event) → payload | undefined`.
  - Do NOT change `subscribe` or `publish` semantics — additive only.

- **Modified:** `dashboard/trade-ticket.js`:
  - Replace module-scope state. DELETE the `tradeTicketBusUnsubscribe` declaration (line 14) including its multi-line comment (lines 9-13). REPLACE with:
    ```js
    // Per-open mirror handle, set on open() and closed on close(). Owns the
    // bus subscription + last-applied-cash state for the dialog's lifetime.
    // See dashboard/dialog-state-mirror.js + docs/refactor/trade-ticket-state-sync/plan.md.
    let tradeTicketMirror = null;
    ```
  - Replace `openTradeTicket()` body. Lines 119-160 become:
    ```js
    tradeTicketCashBalance = null;
    
    // Defensive close — if a previous mirror is still live (open() somehow
    // called twice without close), tear it down before installing a new one.
    if (tradeTicketMirror) {
      tradeTicketMirror.close();
      tradeTicketMirror = null;
    }
    
    tradeTicketMirror = window.dialogStateMirror({
      eventName: 'portfolio:updated',
      primeFromCache: () => {
        const sess = (typeof currentSession !== 'undefined') ? currentSession : null;
        const cash = sess && sess.portfolio_metrics && typeof sess.portfolio_metrics.cash === 'number'
          ? sess.portfolio_metrics.cash
          : undefined;
        return (cash === undefined) ? undefined : { cash };
      },
      refetch: async () => {
        // fetchCashBalance returns void today; the mirror just needs SOMETHING
        // to await. Internally fetchCashBalance writes the cash to the DOM
        // directly, which means our onUpdate is a no-op for refetch results.
        // We return undefined so onUpdate's refuseClobber path treats it
        // identically to "no new value to apply."
        await fetchCashBalance();
        return undefined;
      },
      onOpen: ({ initialState, refetch }) => {
        if (initialState && typeof initialState.cash === 'number') {
          paintCash(initialState.cash);
        }
        // Always kick off a REST refetch on open, regardless of whether we
        // primed from cache or last-published. The refetch is the canonical
        // post-fill cash source — the bus may not have published since the
        // last fill if the dialog was closed during the SSE tick.
        refetch();
      },
      onUpdate: (payload, { refetch }) => {
        // Fast path — bus payload carries a numeric cash. Write inline.
        if (payload && typeof payload.cash === 'number' && !Number.isNaN(payload.cash)) {
          paintCash(payload.cash);
          return;
        }
        // Fallback — payload was missing / shape-drifted. Refresh from the
        // canonical /portfolio endpoint via fetchCashBalance.
        refetch();
      },
      refuseClobber: (currentValue, nextValue) => {
        // Refuse to clobber a known-good numeric cash with a non-numeric
        // placeholder. nextValue is `{cash: 'something'}` shape per onUpdate.
        if (currentValue && typeof currentValue.cash === 'number' &&
            (!nextValue || typeof nextValue.cash !== 'number')) {
          return true;
        }
        return false;
      },
    });
    ```
  - Add a small helper `paintCash(cash)` near the top of the file (after the module-scope state declarations) that wraps the textContent write currently duplicated in `seedCashFromSessionSummary` and `handlePortfolioUpdateForTicket`:
    ```js
    function paintCash(cash) {
      const cashDisplay = document.getElementById('tt-cash-balance');
      if (!cashDisplay) return;
      tradeTicketCashBalance = cash;
      cashDisplay.textContent = '$' + Number(cash).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    ```
  - DELETE `seedCashFromSessionSummary` (lines 177-194) AND its call from `openTradeTicket` (line 150). Functionality is now in `primeFromCache`.
  - DELETE `handlePortfolioUpdateForTicket` (lines 241-259). Functionality is now in `onUpdate`.
  - Replace `closeTradeTicket()` lines 215-218 with:
    ```js
    if (tradeTicketMirror) {
      tradeTicketMirror.close();
      tradeTicketMirror = null;
    }
    ```
  - KEEP `fetchCashBalance` (lines 264-298) UNCHANGED. The mirror's `refetch` calls it. Its `requestSessionId` snapshot + refuse-clobber-on-failure logic is still valid defense.
  - Net LOC change: -50 to -80 lines (deletions: `seedCashFromSessionSummary` ~17, `handlePortfolioUpdateForTicket` ~18, old open-body subscribe dance ~25; additions: `paintCash` ~7, new open-body call ~50).

- **Modified:** `dashboard/index.html`:
  - Insert `<script src="dialog-state-mirror.js"></script>` between line 584 (`event-bus.js`) and line 591 (`trade-ticket.js`). The exact line is between the existing `event-bus.js` script tag and `trade-ticket.js`. Match the existing indentation + tag style.
  - Verify with `grep -n "dialog-state-mirror" dashboard/index.html` returns exactly 1 line.

- **Modified:** `dashboard/event-contract.md`:
  - Update the "Public API surface" code block (lines 18-29) to document `getLastPublished`:
    ```js
    // Read the most recent payload published for an event, or undefined
    // if no publish has happened. Used by dialog-state-mirror.js so that
    // dialogs opened AFTER the most recent publish can prime synchronously.
    const last = window.finletBus.getLastPublished('portfolio:updated');
    ```
  - Add a new section between "Public API surface" (line 18-45) and "HTML safety pattern" (line 38-44) titled "Last-published cache" with bullets:
    - Each `publish(event, payload)` writes `payload` to an internal `Map<string, payload>` keyed by event name.
    - `getLastPublished(event)` returns the cached payload or `undefined`.
    - The cache is per-page (lives inside the bus IIFE closure). Page reload clears it.
    - Cache size is bounded by the number of distinct event names — currently 4 (`portfolio:updated`, `order:filled`, `session:switched`, `onboarding:step-completed`). No eviction policy needed.
    - Out of scope: payload TTL, multi-session cache invalidation. The `session:switched` event consumer (if any) is responsible for treating cached values as session-scoped.
  - Update the `portfolio:updated` event entry (line 50-65) Subscribers list:
    - Replace `Trade Ticket cash header — dashboard/trade-ticket.js (Team C)` with `Trade Ticket cash header — dashboard/trade-ticket.js (via dashboard/dialog-state-mirror.js)`.

- **New:** `tests/dashboard/dialog-state-mirror.spec.js` — node:test unit spec, ~150-200 lines, mirrors the structure of `tests/dashboard/event-bus.spec.js` and `tests/dashboard/form-dirty-tracker.spec.js`. Build a fresh module instance per test in an isolated VM context with a stub bus + stub `document` shim. Required tests:
  1. **`onOpen receives undefined initialState when no prior publish + no primeFromCache value`** — fresh bus, primeFromCache returns undefined, dialogStateMirror called → onOpen called once with `{initialState: undefined, refetch}`.
  2. **`onOpen receives last-published payload when bus.getLastPublished has a value`** — bus.publish('portfolio:updated', {cash: 95000}), then dialogStateMirror called → onOpen receives `{initialState: {cash: 95000}, refetch}`.
  3. **`onOpen falls back to primeFromCache when no last-published value`** — fresh bus, primeFromCache returns `{cash: 100000}`, dialogStateMirror called → onOpen receives `{initialState: {cash: 100000}, refetch}`.
  4. **`onUpdate fires when bus publishes after open`** — dialogStateMirror called, then bus.publish('portfolio:updated', {cash: 95000}) → onUpdate receives `{cash: 95000}, {refetch}`.
  5. **`refuseClobber prevents onUpdate when nextValue is a placeholder`** — refuseClobber returns true, bus.publish → onUpdate is NOT called for that publish; the previous applied value is retained.
  6. **`shape-drift triggers refetch through onUpdate`** — onUpdate receives a payload it doesn't recognize and calls `refetch()`. The mirror awaits refetch's resolved value and (if a new value comes back) calls onUpdate again with that value. Use a stub refetch that resolves to a known payload.
  7. **`close unsubscribes from the bus (no leaked listeners)`** — call mirror.close(), then bus.publish → onUpdate is NOT called. Verify `bus._handlers.get('portfolio:updated').size === 0` via `__test__` introspection on the bus stub.
  8. **`close is idempotent`** — calling mirror.close() twice does not throw.
  9. **`subscription is attached BEFORE onOpen returns`** — race test: synchronously inside the primeFromCache callback, call `bus.publish('portfolio:updated', {...})`. The publish during open MUST land on the mirror's onUpdate. (This is the test for the spec's "concurrent publish during open() lifecycle lands on the live handler" requirement.)
  10. **`window.__dialogStateMirrorTest__.reset() clears all live handles`** — the introspection hook works for cleanup between tests.

  **Test-runner sanity:** the file MUST run via `node --test tests/dashboard/dialog-state-mirror.spec.js` from the repo root with no extra deps. Match the require/vm pattern in `event-bus.spec.js:30-46`.

- **Modified:** `tests/dashboard/event-bus.spec.js`:
  - Add 3 new tests at the end of the file (additive — do NOT touch the existing 9 tests):
    1. **`getLastPublished returns undefined for never-published events`** — `bus.getLastPublished('foo:bar')` returns `undefined`.
    2. **`getLastPublished returns the most recent payload`** — `bus.publish('portfolio:updated', {cash: 100})` then `bus.publish('portfolio:updated', {cash: 200})` → `getLastPublished('portfolio:updated')` returns `{cash: 200}`.
    3. **`getLastPublished argument validation`** — `bus.getLastPublished('')` and `bus.getLastPublished(42)` throw TypeError; matches the existing subscribe/publish validation pattern.

**Deliverable:** `dashboard/dialog-state-mirror.js` exists and exposes `window.dialogStateMirror`. `dashboard/event-bus.js` adds `getLastPublished` + a per-event lastPublished cache. `dashboard/trade-ticket.js` consumes the mirror (no more `seedCashFromSessionSummary`, no more direct `bus.subscribe`/handler ref). `dashboard/event-contract.md` documents the new bus surface + cache invariant. The 3 named recurrence shapes (cold-open `--`, post-fill stale, mid-fill stale) all close through the mirror's combined behavior. Existing `journey-05-trade.spec.ts` tests pass without modification. New `tests/dashboard/dialog-state-mirror.spec.js` covers the property invariants. `tests/dashboard/event-bus.spec.js` extended with `getLastPublished` coverage.

**Validation:**

- [ ] `node --test tests/dashboard/dialog-state-mirror.spec.js` — all 10 tests pass.
- [ ] `node --test tests/dashboard/event-bus.spec.js` — all existing tests + 3 new `getLastPublished` tests pass (12 total minimum).
- [ ] `npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-05-trade.spec.ts` — all non-fixme tests pass. Specifically:
  - "trade ticket panel opens and shows cash balance"
  - "submit valid trade order and verify it appears in order log"
  - "available cash header never shows -- across open/close cycles" (the 3-cycle leak detector)
  - "available cash updates within 2s of bus portfolio:updated while dialog is open" (well-formed publish + shape-drift fallback)
- [ ] `bash scripts/lint-trusted-types.sh` exits 0.
- [ ] `grep -c "seedCashFromSessionSummary" dashboard/trade-ticket.js` returns 0 (function deleted).
- [ ] `grep -c "handlePortfolioUpdateForTicket" dashboard/trade-ticket.js` returns 0 (function deleted).
- [ ] `grep -c "tradeTicketBusUnsubscribe" dashboard/trade-ticket.js` returns 0 (state migrated).
- [ ] `grep -c "window.finletBus.subscribe" dashboard/trade-ticket.js` returns 0 (no direct bus subscribe in consumer).
- [ ] `grep -c "dialogStateMirror" dashboard/trade-ticket.js` returns 1 (exactly one mirror call site).
- [ ] `grep -c "getLastPublished" dashboard/event-bus.js` returns ≥ 2 (definition + freeze export).
- [ ] `grep -c "lastPublished" dashboard/event-bus.js` returns ≥ 3 (Map declaration + write inside publish + read inside getLastPublished).
- [ ] `grep -c "getLastPublished" dashboard/event-contract.md` returns ≥ 1 (documented).
- [ ] `grep -c "dialog-state-mirror.js" dashboard/index.html` returns 1 (script tag inserted).
- [ ] `grep -c "window.dialogStateMirror" dashboard/dialog-state-mirror.js` returns ≥ 1 (window attach).
- [ ] **Manual smoke test (in-browser):**
  1. Open dashboard, ensure a session is selected and clock has stepped at least once.
  2. Click Trade Ticket button. Cash header MUST display `$X` immediately (not `--`, not `Loading...`).
  3. Close the panel.
  4. Submit a market BUY (e.g., 1 SPY) via the panel; close on submit.
  5. Step the clock until the order fills (1-3 steps).
  6. Re-open the panel. Cash header MUST display the post-fill cash (lower than initial).
  7. Repeat open/close 3× more — header MUST stay correct on every reopen.
  8. With panel open, observe a fill (submit + step in another tab if needed). The header MUST update live.

**Agent instructions:**

- You MUST `git add` + `git commit` before finishing. The worktree is cleaned on exit; uncommitted work is lost.
- Commit message MUST reference the spec: `refactor(dashboard): trade-ticket state-sync — dialog-state-mirror module + bus lastPublished cache`. Body should mention the 3 recurrence iterations the refactor closes (`20260428T031818Z2efa`, `20260429T052717Z1a13`, `20260429T232205Z17ff`).
- Read `docs/refactor/dirty-state-tracker-v2/plan.md` end-to-end before touching code. It is the closest analogue (same dashboard surface, same single-team pattern, same `__test__` export idiom, same node:test infra).
- Read `dashboard/event-bus.js` end-to-end and `tests/dashboard/event-bus.spec.js:30-46` (the `freshBus()` factory) before extending the bus. The IIFE pattern + `Object.freeze` are non-negotiable.
- The `lastPublished` cache MUST be inside the bus IIFE closure, NOT a module-level Map. The bus's "no bare globals beyond `window.finletBus`" invariant (event-bus.js:23-24) is enforced by code review.
- The `dialog-state-mirror.js` script MUST attach `window.dialogStateMirror` idempotently — `if (window.dialogStateMirror) return;` at the top of the IIFE. Mirrors `dashboard/event-bus.js` line 27 `(function () {...})()`.
- The bus subscription inside `dialogStateMirror` MUST be attached BEFORE `onOpen` is invoked. Test 9 enforces this. The order in code is: cache-read → primeFromCache → bus.subscribe → onOpen call. NOT: onOpen call → bus.subscribe.
- Do NOT modify `dashboard/app.js`. The SSE handler's `currentSession.portfolio_metrics` mirror at `app.js:1445-1455` is upstream of this refactor and MUST stay. If you find a reason to touch `app.js`, surface the obstacle in the commit message rather than expanding scope.
- Do NOT modify `dashboard/api-utils.js`. The spec lists it but recon confirmed the bus is in `event-bus.js`. The plan corrects this; do not regress.
- Do NOT introduce `addEventListener('finlet:...')` or `dispatchEvent(new CustomEvent('finlet:...'))`. CLAUDE.md root rule.
- Do NOT introduce `.innerHTML =` writes. The cash header is `textContent` today and MUST stay `textContent`.
- The mirror's `__test__` export hook (`window.__dialogStateMirrorTest__`) is for unit-test introspection ONLY. Production code MUST NOT call it.
- The `refuseClobber` callback signature is `(currentValue, nextValue) => boolean`. `currentValue` is the LAST APPLIED value (whatever was last passed to `onOpen` or `onUpdate`'s consumer). `nextValue` is the candidate. Returning true means "skip this update." Document this in a comment at the top of the mirror module so future consumers don't get the polarity wrong.
- The migration is mechanical, not creative. The spec's `dialogStateMirror({...})` API in lines 47-56 of the spec is authoritative — don't rename options, don't add options, don't drop options.
- KEEP `fetchCashBalance` (lines 264-298 of trade-ticket.js) UNCHANGED. It has tested defensive logic the mirror doesn't replicate. The mirror calls it via `refetch`.
- `dashboard/event-contract.md` MUST be updated in the same commit. CLAUDE.md root rule.
- Do NOT touch backend code (`finlet/api/`, `finlet/auth/`, etc.). Validation will grep for it.
- Do NOT touch other dashboard JS files (`onboarding.js`, `leaderboard.js`, `app.js`, etc.). The migration is `trade-ticket.js` only — out-of-scope dialogs that subscribe to bus events are explicitly OUT OF SCOPE per the spec.
- If the unit test infra path doesn't allow `node --test` to find the spec (path resolution issue, missing fixtures), fall back to following the EXACT pattern in `tests/dashboard/event-bus.spec.js` — that proves out the working approach. Do not invent a new test framework.
- If the `Object.freeze` extension breaks an existing consumer (e.g., a test that introspects `window.finletBus` keys), surface the obstacle in the commit message and either fix the consumer or pause and surface to the executor.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| `Object.freeze` extension on `window.finletBus` breaks an existing consumer that introspects keys | Low | Medium | Recon: only existing consumers of the bus are `subscribe`/`publish` callers; no consumer reads bus keys. `getLastPublished` is additive. The frozen object's three-method shape replaces the two-method shape; no caller of `subscribe`/`publish` is affected. Validation grep: `grep -rn "Object.keys.*finletBus\|for.*in.*finletBus" dashboard/ tests/` returns 0. |
| `lastPublished` cache leaks unbounded memory if events proliferate | Low | Low | Recon: only 4 distinct event names exist (`portfolio:updated`, `order:filled`, `session:switched`, `onboarding:step-completed`). Cache size is bounded by event-name count, not publish count. Each publish OVERWRITES the cache for that event. No eviction needed. |
| `lastPublished` cache returns stale data across session switches (cross-session contamination) | Medium | Medium | The `portfolio:updated` payload is session-scoped on the publisher side (`app.js:1431-1455` — only publishes for `currentSessionId`). On session switch, the next portfolio SSE tick will overwrite the cache with fresh data. Worst case is a 1-second window where a just-switched session's dialog reads the OLD session's cash on first open before the SSE tick lands. Mitigation: trade-ticket's `openTradeTicket()` already calls `refetch()` (via mirror onOpen) on every open, which hits `/sessions/{currentSessionId}/portfolio` — the canonical session-scoped read. The cache is the prime; refetch is the truth. |
| `refuseClobber` polarity inverted by future consumer (returns true when they meant false) | Medium | High | Mitigation: the polarity is documented in a code comment at the top of the mirror module ("returns true to SKIP the update — the inverse of 'this update is allowed'"). The unit-test spec includes Test 5 which verifies the canonical `refuseClobber` returning true skips. Future consumers must follow the same convention. |
| Migration leaves a stale subscription handler if `closeTradeTicket` is called before `tradeTicketMirror` is set | Low | Medium | The mirror's `close()` is idempotent and the consumer guards with `if (tradeTicketMirror) { ... mirror.close(); tradeTicketMirror = null; }`. Defensive close at `openTradeTicket` start handles the double-open case. |
| Race: bus publishes between `getLastPublished` read and `bus.subscribe` attach inside the mirror | Low | High | Inside the mirror: `cache = bus.getLastPublished(eventName)` is synchronous; `bus.subscribe(...)` is synchronous; both run before `onOpen` is called. JS is single-threaded — no publish can race a synchronous read+subscribe sequence. The risk is theoretical only. Test 9 (subscription-attached-before-onOpen) verifies the contract. |
| Mirror's `refetch` callback in trade-ticket signature mismatch (mirror expects Promise<initialState>, trade-ticket's fetchCashBalance returns void) | Medium | Low | Per the agent instructions, the mirror's `refetch` is wrapped: `async () => { await fetchCashBalance(); return undefined; }`. The mirror's contract for refetch returning undefined is to treat it as "no new value to apply" — fetchCashBalance writes to the DOM directly, bypassing onUpdate. This is by design, not a bug; document it in the wrapper comment. |
| New `<script src="dialog-state-mirror.js">` tag is added in the wrong load-order position | Low | High | Position is precisely specified: between `event-bus.js` (line 584) and `trade-ticket.js` (line 591). `event-bus.js` MUST be first (mirror reads `window.finletBus.getLastPublished`); `trade-ticket.js` MUST be after (consumer calls `window.dialogStateMirror`). Validation: `grep -nA0 "dialog-state-mirror\|trade-ticket\|event-bus" dashboard/index.html` shows the order; manual review confirms before commit. |
| trusted-types lint guard false-flags the new module | Low | Low | Mirror writes only to internal state (Map, closures); the consumer writes only to `textContent`. No `.innerHTML` writes anywhere in the diff. Run `bash scripts/lint-trusted-types.sh` once before committing. |
| `tests/dashboard/dialog-state-mirror.spec.js` cannot stub the bus cleanly because the bus is loaded into `window.finletBus` and the mirror reads it at call time | Low | Medium | Pattern: build a stub bus inside each test (similar to `event-bus.spec.js:41-46` `freshBus()`), inject it as `sandbox.window.finletBus` BEFORE running the mirror module source via `vm.runInContext`. The mirror reads `window.finletBus` lazily when `dialogStateMirror({...})` is called, not at module-load time. |
| Plan's bus extension to `event-bus.js` (instead of `api-utils.js` per spec) blindsides the verdict-tracking step | Low | Low | The plan explicitly documents the deviation in the Constraints section + File Conflict Table. The next bug-hunt iteration's `verdict:` evaluation will find the bus surface in the canonical location and the spec's mention of `api-utils.js` is corrected by recon. |
| Existing `journey-05-trade.spec.ts:488-552` test has hard-coded `999999` poison value in `:455-456`; if mirror's `refuseClobber` is too aggressive (refuses ALL updates) the poison check would still pass but live updates would fail | Low | Medium | Test 5 in the new unit spec verifies `refuseClobber` only skips when nextValue is a placeholder (no numeric cash). The journey-05 test at `:517-527` publishes a well-formed `{cash: 94548.49, ...}` and asserts the header updates within 2s — this regression-blocks an over-aggressive refuseClobber. |

## Session Plan

### Session 1: Mirror module + bus extension + trade-ticket migration (single session)

**Sequential merge order:**
1. Team A merges (single team). Validation gates pass on the worktree before merge.
2. After merge to main: run the full validation suite on main:
   - `node --test tests/dashboard/dialog-state-mirror.spec.js`
   - `node --test tests/dashboard/event-bus.spec.js`
   - `npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-05-trade.spec.ts`
   - `bash scripts/lint-trusted-types.sh`
3. Manual smoke test in-browser per the Validation checklist.

**Why one session:** the chain is short (single team), the work has natural sequential dependencies inside one author's flow (bus extension → mirror module → consumer migration → contract update), and there are no shared files outside this refactor. Splitting into multiple sessions adds orchestration cost without parallelism gain.

**Worktree strategy:** single worktree spawn. The agent runs the full sequence linearly inside the worktree, commits once, and returns the merge SHA.

**Session checkpoint:** after merge, run the FULL Playwright suite once (`npx playwright test --config=tests/e2e/playwright.config.ts`) and `uv run pytest -q --timeout=120` on main. If clean, mark `docs/bug-hunt/refactor-queue/trade-ticket-state-sync.md` `status: shipped, shipped_in: <merge sha>`. Reset `verdict:` to pending; the next bug-hunt iteration sets it.

## Verdict-tracking notes (for the next iteration's Phase 6)

After this refactor lands, the next `/bug-hunt` iteration's Phase 6 sets the `verdict:` field on `docs/bug-hunt/refactor-queue/trade-ticket-state-sync.md` based on the three named recurrence shapes:

- **`effective`** — All three named recurrence shapes pass cleanly:
  - Trade Ticket "Available Cash" stale after fill (the `20260428T031818Z2efa` shape — open dialog, fill order, dialog header reflects post-fill cash within 2s).
  - Trade Ticket "Available Cash" stuck on `--` on first open (the `20260429T052717Z1a13` shape — open dialog, header shows `$X` synchronously, never `--`).
  - Trade Ticket "Available Cash" stale during fill while dialog stays open (the `20260429T232205Z17ff` shape — open dialog, BUY MARKET, dialog header tracks fill without close-and-reopen).
- **`incomplete`** — A new finding fires the same shape on Trade Ticket (e.g., header sticks at `--` under throttled `/portfolio`, or stale after a partial-fill SSE that the mirror's `onUpdate` doesn't recognize). Likely root cause: a payload shape the mirror's `refuseClobber` or `onUpdate` consumer didn't anticipate. Fix: extend the consumer's onUpdate handling.
- **`regressed`** — A new failure shape introduced by the refactor (e.g., the dialog never paints at all; the bus's `lastPublished` cache returns wrong session's data after switch; close() leaves a stacked subscription). Indicates the mirror's contract broke something the bespoke flow handled. Revert is single SHA — the consumer migration is mechanical and reversible by restoring `seedCashFromSessionSummary` + the direct subscribe path.
