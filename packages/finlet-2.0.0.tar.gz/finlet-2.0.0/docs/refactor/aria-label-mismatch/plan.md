# aria-label-mismatch — Execution Plan

> Generated from `docs/bug-hunt/refactor-queue/aria-label-mismatch.md`. Last updated: 2026-05-06.
> Recon baseline: HEAD `d4e847c`. Single-source recon (no `codex_recon.md` in input dir; PF-19 reconciliation no-op).
> Triggered by: `pending_recurrences.jsonl` entry `shared-nav-collapsed-label-stale` (iteration `20260506T185234Z542e`).

**Status:** COMPLETED 2026-05-07. Team A merged at commit `b9ccf4a` (on `origin/main`; local pre-rebase SHA was `18f54a8`). All validation passed (13 unit + 6 + 10 Playwright + 2 lint scripts).

## TL;DR

One team, one worktree, one PR. Refactor the API-key affordance label so a single helper drives every surface (`#menu-copy-key`, `#nav-drawer-copy-key`, and three reset-literal sites) and re-renders on `auth:state-change` bus events. Two upstream gaps the recon caught (one not in the scope doc):

1. **`auth:state-change` does not currently exist** on `window.finletBus`. The refactor MUST add a publisher in `dashboard/auth.js` (after `saveAuth` / `logout` / `setApiKey` mutations) AND document it in `dashboard/event-contract.md`.
2. **`dashboard/shared-nav.js:343` carries a third hardcoded `'Copy API Key'` literal** (clipboard-success reset on the desktop button) — the scope doc only enumerated `mobile-nav.js:188`. Both reset literals get swapped for `_relabelCopyApiKeyButton(...)` calls.

The 4 static HTML literals across `index.html` / `billing.html` / `leaderboard.html` / `settings.html` stay as graceful-degradation fallbacks (Option A in the scope doc) — the umbrella's mount-time pass overrides them before paint.

## Constraints

From the scope doc + recon evidence:

- **Dual-label semantics are load-bearing** (`docs/decisions/copy-api-key-dead-affordance.md`): button shows `"Copy API Key"` when `FinletAuth.getApiKey()` returns a non-null key (clipboard-write affordance, signup / just-rotated path); shows `"Manage API Key"` when `getApiKey()` returns null (redirect-to-Settings affordance, cookie-session path). The hash-only key storage invariant — server stores key hashes, cleartext is unrecoverable post-handshake — forces this dual semantics. The refactor MUST preserve which label shows when. Only the unification of surfaces changes.
- **File ownership** (`.claude/rules/file-ownership.md`): `dashboard/` → dashboard team. `tests/dashboard/` and `tests/e2e/` → dashboard team (convention). `docs/` → docs team. The dashboard team owns this entire refactor; the post-merge addendum to `docs/decisions/copy-api-key-dead-affordance.md` is a separate small docs-team PR (NOT in this plan's scope — see "Out of scope" below).
- **Event bus convention** (`CLAUDE.md` + `docs/decisions/dashboard-event-bus.md`): all cross-component dashboard wiring goes through `window.finletBus.subscribe(event, handler) → unsubscribe` and `window.finletBus.publish(event, payload)`. Direct `addEventListener('finlet:...')` and `dispatchEvent(new CustomEvent('finlet:...'))` are forbidden under `dashboard/` and blocked at pre-commit by `scripts/lint-event-bus.sh`.
- **Trusted Types** (`scripts/lint-trusted-types.sh`): bare `.innerHTML =` writes under `dashboard/` outside `trustedHTML(...)` wraps are blocked. The helper writes via `textContent` (text-safe); no Trusted Types changes needed.
- **Backwards compatibility on `_relabelCopyApiKeyButton`**: the existing 8 unit tests in `tests/dashboard/shared-nav.spec.js` call `env.sandbox._relabelCopyApiKeyButton()` with zero arguments. The new signature MUST accept zero args (defaulting to `#menu-copy-key`) so existing tests stay green AND add the parameterized form for the umbrella.
- **No server-side change.** Hash-only key storage invariant preserved end-to-end.

## File Conflict Table

Single team — no inter-team conflicts.

| File | Touched by Teams |
|------|-----------------|
| `dashboard/shared-nav.js` | A |
| `dashboard/mobile-nav.js` | A |
| `dashboard/auth.js` | A |
| `dashboard/event-contract.md` | A |
| `tests/dashboard/shared-nav.spec.js` | A |
| `tests/e2e/journey-shared-nav.spec.ts` | A |

Static HTML files (`dashboard/index.html`, `dashboard/billing.html`, `dashboard/leaderboard.html`, `dashboard/settings.html`) are NOT modified — the umbrella overrides their literal at mount time and they serve as graceful-degradation fallbacks per Option A.

## Dependency Graph

```
Team A (single team) ── can start immediately
```

No upstream blockers. The `auth:state-change` event publisher and consumer ship in the same team to avoid a stale "publisher exists but nothing subscribes" intermediate state.

## Critical Path

```
Team A → merge → micro-gate (unit + e2e + lint) → done
```

Single-team plan. Critical path is Team A.

---

## Teams

### Team A: Unify the API-key affordance label across desktop user-menu + mobile nav drawer

**Blocked by:** none — can start immediately.

**Read these files first:** (CRITICAL — verifies surgery surface against HEAD)

- `dashboard/shared-nav.js:198` — `_buildHeaderHTML` literal for `#menu-copy-key` button [why: confirm the static literal that the umbrella overrides at mount].
- `dashboard/shared-nav.js:288` — current mount-time call to `_relabelCopyApiKeyButton()` from `_initSharedUserMenu` [why: this call site stays — the umbrella replaces the helper invocation here].
- `dashboard/shared-nav.js:298` — current trigger-click gated call (`if (isOpen)`) [why: the gate is dead weight after this refactor — bus subscriber covers any case where a key is minted between page load and menu open. Delete the gate.].
- `dashboard/shared-nav.js:324-328` — desktop redirect path on cookie-session click [why: confirm semantics preserved; no changes needed here].
- `dashboard/shared-nav.js:343` — clipboard-success reset literal `copyKeyBtn.textContent = 'Copy API Key'` [why: a third drift site the scope doc missed — must be replaced with a helper call so the reset respects the current auth state].
- `dashboard/shared-nav.js:417-422` — current `_relabelCopyApiKeyButton()` body [why: the helper to parameterize. Must accept zero args (default to `#menu-copy-key`) AND accept an id-string OR an element argument].
- `dashboard/mobile-nav.js:34` — `drawerCopyKey = document.getElementById('nav-drawer-copy-key')` [why: confirm the drawer-button element is captured at mobile-nav init for use as the umbrella's mount-time target].
- `dashboard/mobile-nav.js:175-195` — drawer button click handler [why: line 188 reset literal must be replaced with a helper call; line 180 `desktopCopyKey.click()` proxy stays].
- `dashboard/auth.js` (full file, but specifically `saveAuth`, `logout`, `setApiKey` mutation sites) — the publisher must fire `bus.publish('auth:state-change', { hasKey })` after every mutation that changes `_inMemoryApiKey` truthiness.
- `dashboard/event-bus.js:55-130` — `subscribe` / `publish` / `getLastPublished` API surface [why: the new bus subscriber MUST use `window.finletBus.subscribe(...)` and retain the unsubscribe handle].
- `dashboard/event-contract.md` — current 6-event documentation [why: must add a 7th entry for `auth:state-change` in the same commit, per the bus convention].
- `docs/decisions/copy-api-key-dead-affordance.md` (main + 2026-05-06 addendum) — dual-label semantics decision record [why: the security invariant the refactor MUST preserve].
- `docs/decisions/dashboard-event-bus.md` — bus contract [why: confirm the subscribe/publish API is the only sanctioned entrypoint and that adding a new event requires updating event-contract.md in the same commit].
- `tests/dashboard/shared-nav.spec.js` — 8 existing unit tests (test names listed below) [why: existing tests MUST stay green; new tests extend coverage].
- `tests/e2e/journey-shared-nav.spec.ts` — single existing Playwright test [why: extend to cover BOTH surfaces × BOTH auth paths × BOTH lifecycle states + bus repaint].
- `tests/e2e/journey-09-mobile.spec.ts:60` — existing `#nav-drawer-copy-key` visibility assertion [why: must keep passing; no changes needed].

**Recon evidence (verified by recon agent against HEAD `d4e847c`):**

The current desktop-button `_buildHeaderHTML` literal:

```html dashboard/shared-nav.js:198-199
198  '<button class="user-menu-item" role="menuitem" id="menu-copy-key">Copy API Key</button>'
```

The current `_relabelCopyApiKeyButton` helper — zero-parameter, hard-codes `getElementById('menu-copy-key')`, dual-label logic via `FinletAuth.getApiKey()`:

```javascript dashboard/shared-nav.js:417-422
417  function _relabelCopyApiKeyButton() {
418    const btn = document.getElementById('menu-copy-key');
419    if (!btn) return;
420    const hasKey = FinletAuth && FinletAuth.getApiKey();
421    btn.textContent = hasKey ? 'Copy API Key' : 'Manage API Key';
422  }
```

The two existing call sites — mount-path call (load-bearing, replaced by umbrella) and gated open-path call (dead weight after refactor):

```javascript dashboard/shared-nav.js:288
288    _relabelCopyApiKeyButton();
```

```javascript dashboard/shared-nav.js:298
298    if (isOpen) {
       _relabelCopyApiKeyButton();
       }
```

The third drift site — clipboard-success reset literal on the DESKTOP button (NOT enumerated in the scope doc; recon caught this):

```javascript dashboard/shared-nav.js:343
343    copyKeyBtn.textContent = 'Copy API Key';
```

The mobile drawer click handler — proxies to the desktop button via `.click()` AND carries its own hardcoded reset literal at line 188:

```javascript dashboard/mobile-nav.js:175-195
175    if (desktopCopyKey) {
180        drawerCopyKey.addEventListener('click', (e) => {
           e.preventDefault();
           desktopCopyKey.click();
           });
       }
       // ... clipboard fallback path ...
188    drawerCopyKey.textContent = 'Copy API Key';
```

The four static HTML literal sites (identical literal, near-identical line offsets):

```html dashboard/index.html:68
68  <button class="nav-drawer-action" id="nav-drawer-copy-key" type="button">Copy API Key</button>
```

```html dashboard/billing.html:63
63  <button class="nav-drawer-action" id="nav-drawer-copy-key" type="button">Copy API Key</button>
```

```html dashboard/leaderboard.html:62
62  <button class="nav-drawer-action" id="nav-drawer-copy-key" type="button">Copy API Key</button>
```

```html dashboard/settings.html:63
63  <button class="nav-drawer-action" id="nav-drawer-copy-key" type="button">Copy API Key</button>
```

The bus contract — `subscribe` returns an unsubscribe function; `publish` caches the payload via `lastPublished` Map for late subscribers; `getLastPublished` reads the cache; the export is frozen:

```javascript dashboard/event-bus.js:55-130
function subscribe(event, handler) {
    if (typeof event !== 'string') { /* throws */ }
    if (typeof handler !== 'function') { /* throws */ }
    if (!handlers.has(event)) handlers.set(event, []);
    handlers.get(event).push(handler);
    return function unsubscribe() {
        const list = handlers.get(event);
        if (list) {
            const idx = list.indexOf(handler);
            if (idx >= 0) list.splice(idx, 1);
        }
    };
}
function publish(event, payload) {
    if (typeof event !== 'string') { /* throws */ }
    lastPublished.set(event, payload);
    const list = handlers.get(event);
    if (list && Array.isArray(list)) {
        list.forEach((fn) => { try { fn(payload); } catch (err) { console.error(...); } });
    }
}
function getLastPublished(event) { return lastPublished.get(event); }
window.finletBus = Object.freeze({ subscribe, publish, getLastPublished });
```

The current event-contract.md — `auth:state-change` IS NOT in the documented event set (verified by recon agent against HEAD `d4e847c`). The 6 documented events are: `portfolio:updated`, `order:filled`, `session:switched`, `onboarding:step-completed`, `profile:saved`, `strategy:saved`. There is no publisher for `auth:state-change` anywhere under `dashboard/`. The refactor MUST add the publisher in `dashboard/auth.js` AND a 7th entry in `event-contract.md` in the same commit.

The existing 8 unit tests in `tests/dashboard/shared-nav.spec.js` (verified by recon agent against HEAD `d4e847c`) — none reference `#nav-drawer-copy-key`:

1. `_relabelCopyApiKeyButton sets "Manage API Key" when getApiKey() returns null (cookie-session path)`
2. `_relabelCopyApiKeyButton sets "Copy API Key" when getApiKey() returns a non-null key (signup path)`
3. `_relabelCopyApiKeyButton defends against FinletAuth being undefined (sets "Manage API Key")`
4. `_relabelCopyApiKeyButton is a no-op when #menu-copy-key is absent`
5. `_initSharedUserMenu relabels on initial mount (cookie-session path)`
6. `_initSharedUserMenu relabels on initial mount (signup path)`
7. `_initSharedUserMenu trigger click re-runs relabel on open (idempotent)`
8. `_initSharedUserMenu trigger click on close does NOT re-relabel (only on open)`

The existing journey-shared-nav.spec.ts — single test, cookie-session × `#menu-copy-key` only (no `#nav-drawer-copy-key` assertion). The journey-09-mobile.spec.ts:60 asserts `#nav-drawer-copy-key` visible (existence-only, no label assertion).

**Files touched:**

- Modified: `dashboard/shared-nav.js`
  - Change `_relabelCopyApiKeyButton()` signature from zero-param to `_relabelCopyApiKeyButton(buttonOrId)` accepting either an element OR an id-string OR no arg (defaulting to `#menu-copy-key` to preserve the existing 8 unit tests' zero-arg call shape).
  - Add a new umbrella `_relabelAllApiKeyAffordances()` that iterates a known id list `['menu-copy-key', 'nav-drawer-copy-key']` and calls `_relabelCopyApiKeyButton(id)` for each. Missing ids are silent no-ops.
  - At line 288 (current mount call site): replace `_relabelCopyApiKeyButton()` with `_relabelAllApiKeyAffordances()`.
  - At line 298: delete the `if (isOpen) { _relabelCopyApiKeyButton(); }` block entirely. The bus subscriber covers the open-time case.
  - At line 343: replace `copyKeyBtn.textContent = 'Copy API Key'` with `_relabelCopyApiKeyButton(copyKeyBtn)`. The reset now respects the current auth state.
  - Add `window.finletBus.subscribe('auth:state-change', _relabelAllApiKeyAffordances)` inside `_initSharedUserMenu()` (after the umbrella mount-time call). Retain the unsubscribe handle on the module-private state for cleanup symmetry; if no cleanup hook exists today, the subscription persists for the page lifetime (acceptable — this is a singleton mount).
- Modified: `dashboard/mobile-nav.js`
  - At line 188: replace `drawerCopyKey.textContent = 'Copy API Key'` with `window.SharedNav._relabelCopyApiKeyButton(drawerCopyKey)` (or the equivalent module-export path — verify what `shared-nav.js` exports to `window` during the worktree; if it does not export the helper, expose it as part of this refactor so `mobile-nav.js` can call it).
  - Add a one-line call to `_relabelAllApiKeyAffordances()` from inside `initMobileNav()` (after `drawerCopyKey` is captured at line 34) so pages where mobile-nav initializes after shared-nav still get the drawer button relabeled at mount. Idempotent with the shared-nav umbrella's mount-time pass.
- Modified: `dashboard/auth.js`
  - After every mutation site that changes the truthiness of `_inMemoryApiKey` (functions: `saveAuth`, `logout`, `setApiKey` per the scope doc — verify the exact function names against HEAD during recon-read), add `window.finletBus.publish('auth:state-change', { hasKey: !!FinletAuth.getApiKey() })`. Use `FinletAuth.getApiKey()` (not the private variable directly) so the publisher reflects the same source-of-truth the helper reads.
- Modified: `dashboard/event-contract.md`
  - Add a 7th entry documenting `auth:state-change`: payload shape `{ hasKey: boolean }`; published by `dashboard/auth.js` after `saveAuth` / `logout` / `setApiKey`; subscribed by `dashboard/shared-nav.js` (the API-key affordance umbrella). Match the formatting of the existing 6 entries.
- Modified: `tests/dashboard/shared-nav.spec.js`
  - Existing 8 tests stay UNCHANGED — they pass with the new signature (zero-arg defaults to `#menu-copy-key`).
  - Add 5 new tests:
    - `_relabelCopyApiKeyButton('nav-drawer-copy-key')` relabels the drawer button's `textContent` to `"Manage API Key"` on cookie-session (apiKey null) and `"Copy API Key"` on signup (apiKey non-null).
    - `_relabelCopyApiKeyButton(elementShim)` accepts an element directly (idempotent with the id-string form).
    - `_relabelAllApiKeyAffordances()` iterates the known id list and relabels every present button. Missing ids are silent no-ops.
    - The `auth:state-change` bus subscriber, when fired with `{ hasKey: false }`, repaints both `#menu-copy-key` and `#nav-drawer-copy-key` to `"Manage API Key"` on the next tick. Use a sandbox-injected `window.finletBus` shim that the test invokes directly.
    - The desktop clipboard-success reset path (`shared-nav.js:343` site) calls `_relabelCopyApiKeyButton(copyKeyBtn)` — verified by asserting the button's textContent equals what the helper would produce for the current auth state (NOT the static `'Copy API Key'` literal). Drive the assertion through a sandbox-injected `navigator.clipboard.writeText` shim.
- Modified: `tests/e2e/journey-shared-nav.spec.ts`
  - Existing single test stays (`cookie-session path: #menu-copy-key reads 'Manage API Key' in BOTH collapsed and expanded states`).
  - Add 5 new test cases:
    - `cookie-session path × #nav-drawer-copy-key`: open hamburger, drawer becomes visible, drawer button reads `"Manage API Key"` (NOT `"Copy API Key"` — the regression). Click navigates to `settings.html#api-keys`. Also assert BEFORE the hamburger is opened that the drawer button's textContent is `"Manage API Key"` (the static-literal regression: button is in the DOM from page load).
    - `signup path × #menu-copy-key`: with a `beforeEach` that calls `FinletAuth.setApiKey('k_test_…')`, button reads `"Copy API Key"` in both collapsed and expanded states; click writes to clipboard.
    - `signup path × #nav-drawer-copy-key`: same as above for the drawer — `"Copy API Key"` in pre-open AND post-open drawer states; click triggers clipboard write via the desktop proxy.
    - `bus repaint on logout`: with the dashboard loaded on signup-path, simulate a logout (`FinletAuth.logout()` via `page.evaluate`); within 500ms BOTH buttons must repaint to `"Manage API Key"` without page reload.
    - `bus repaint on key-set`: with the dashboard loaded on cookie-session, simulate `FinletAuth.setApiKey('k_test_…')`; within 500ms BOTH buttons must repaint to `"Copy API Key"` without page reload.

**Deliverable:** The API-key affordance label is correct on both auth paths × both surfaces (desktop user-menu + mobile drawer) × both lifecycle states (collapsed/expanded for desktop; pre-open/post-open for drawer), and re-paints atomically on `auth:state-change` bus events. Adding a 5th dashboard page is zero edits to the affordance code (the umbrella runs on mount and finds whatever ids are present in the DOM); adding a 3rd surface is one entry in the umbrella's id list. The `pending_recurrences.jsonl` entry `shared-nav-collapsed-label-stale` becomes resolvable post-deploy.

**Validation:**

- [ ] `node --test tests/dashboard/shared-nav.spec.js` — all 13 tests pass (8 existing + 5 new).
- [ ] `npx playwright test tests/e2e/journey-shared-nav.spec.ts` — all 6 tests pass (1 existing + 5 new).
- [ ] `npx playwright test tests/e2e/journey-09-mobile.spec.ts` — existing visibility assertion still passes.
- [ ] `bash scripts/lint-event-bus.sh` — passes (the new bus subscription uses `window.finletBus.subscribe`, not `addEventListener('finlet:...')`).
- [ ] `bash scripts/lint-trusted-types.sh` — passes (no new `.innerHTML =` writes).
- [ ] Manual smoke (dev server): load `dashboard/index.html` cookie-session-cold; collapsed drawer button reads `"Manage API Key"` (open hamburger to verify); collapsed user-menu button reads `"Manage API Key"`; click drawer button → navigates to `settings.html#api-keys`. Then `FinletAuth.setApiKey('k_test_…')` in DevTools console; within 500ms both buttons repaint to `"Copy API Key"`.

**Agent instructions:**

- You MUST `git add` + `git commit` before finishing. Worktree work that isn't committed is lost when the worktree is torn down.
- Follow existing patterns in `dashboard/shared-nav.js` (the helper at lines 417-422 is the style model — terse, defensive against undefined `FinletAuth`, idempotent, uses `textContent` not `innerHTML`).
- Preserve the dual-label semantics from `docs/decisions/copy-api-key-dead-affordance.md`: `getApiKey()` non-null → `"Copy API Key"`; `getApiKey()` null → `"Manage API Key"`. The security invariant (hash-only key storage) is load-bearing — do NOT add any cleartext-key storage path or change the click-handler semantics.
- The umbrella's id list is the closed enum of surfaces the refactor manages. Code it as a top-level module constant (e.g., `const API_KEY_AFFORDANCE_IDS = ['menu-copy-key', 'nav-drawer-copy-key'];`) so future additions are one line.
- The bus subscription in `_initSharedUserMenu` does NOT need an unsubscribe in this iteration — `_initSharedUserMenu` is called once per page load and the bus is per-page; subscriptions persist for the page lifetime by design. Do NOT add a teardown hook; that's out of scope.
- `dashboard/event-contract.md` is mandatory — the bus convention (per `CLAUDE.md`) requires updating the contract file in the same commit when adding a new event. Place the new entry alphabetically or wherever the existing ordering convention dictates (read the file to determine).
- `dashboard/auth.js`: do NOT change the `getApiKey()` / `setApiKey()` / `saveAuth()` / `logout()` semantics; only ADD the `bus.publish('auth:state-change', { hasKey })` call after each mutation site. The publish call is additive and does not affect any existing consumer.
- The `tests/dashboard/shared-nav.spec.js` sandbox shim approach (vm.runInContext) is the established pattern. The new tests for the bus subscriber must inject a `window.finletBus` shim into the sandbox (matching the real bus's `subscribe` / `publish` / `getLastPublished` API surface) so the subscriber wires correctly under test.
- The Playwright tests in `tests/e2e/journey-shared-nav.spec.ts` use the existing test fixture pattern (read the existing single test for the auth-path setup convention). The signup-path setup likely needs `page.evaluate(() => FinletAuth.setApiKey('k_test_…'))` in a `beforeEach`.
- Do NOT modify the 4 static HTML files (`dashboard/index.html`, `dashboard/billing.html`, `dashboard/leaderboard.html`, `dashboard/settings.html`). The umbrella's mount-time pass overrides their literal before paint; leaving them as `"Copy API Key"` provides graceful-degradation if JS fails to load (the wrong label is better than a blank button).
- After commit: open a PR with the title `refactor: unify API-key affordance label across desktop user-menu + mobile drawer (closes shared-nav-collapsed-label-stale)`. The PR body MUST cite the scope doc (`docs/bug-hunt/refactor-queue/aria-label-mismatch.md`) and the decision record (`docs/decisions/copy-api-key-dead-affordance.md`).

## Out of scope (for this plan)

- **Decision-record addendum** to `docs/decisions/copy-api-key-dead-affordance.md` noting the helper's parameterization + bus subscription. This is a docs-team change (file ownership: `docs/` → docs). Handled by a separate small PR after this refactor merges. Mentioned here so the planner doesn't accidentally fold it into Team A's commit (file-ownership boundary).
- **Removing the static HTML literals** from the 4 dashboard pages. Option A in the scope doc explicitly recommends keeping them as graceful-degradation fallbacks. If the dashboard team later decides to remove them, that's a follow-up refactor (one sed-style sweep).
- **Refactoring `_buildHeaderHTML` literal at `dashboard/shared-nav.js:198`** to omit the static `"Copy API Key"` text. The umbrella's mount-time pass overrides this literal, so removing it is cosmetic — out of scope for this iteration.
- **Adding a `getLastPublished('auth:state-change')` prime-on-mount path** to handle late subscribers. Not needed: the umbrella's mount-time pass IS the prime — the bus subscriber only needs to fire on subsequent mutations, not on initial mount.
- **The earlier `freeze-btn-visible-text-stale` instance** (iter `20260505T234713Z0c8a`, commit `c6b72a7`) — listed in the scope doc's `instances: 2` count for category-recurrence accounting only. The freeze button lives on `dashboard/app.js` + `dashboard/index.html` in the clock-controls module; this refactor does NOT touch it. If the same shape appears a 3rd time, consider a broader umbrella for "auth-state-dependent labels" — but not now.

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Existing 8 unit tests break because the helper's signature change isn't backwards-compatible | Low | High | The agent instructions explicitly require zero-arg call to default to `#menu-copy-key`. The micro-gate runs `node --test tests/dashboard/shared-nav.spec.js` and fails the merge if any of the 8 existing tests regress. |
| `auth:state-change` publisher in `auth.js` fires too eagerly and causes a render storm | Low | Medium | Publish only after explicit auth-state mutations (`saveAuth` / `logout` / `setApiKey`), NOT on every property read. The umbrella is idempotent; even if it fires twice, the result is the same. |
| `mobile-nav.js` initializes BEFORE `shared-nav.js` and the umbrella isn't yet exported to `window.SharedNav` (or equivalent) | Medium | Medium | The agent instructions call this out: if `shared-nav.js` doesn't currently export the helper to `window`, expose it as part of this refactor. The mobile-nav umbrella call should defensively check existence (`window.SharedNav && window.SharedNav._relabelCopyApiKeyButton && ...`) and silently no-op if missing — the shared-nav mount-time pass will catch up when it loads. |
| The Playwright `bus repaint on logout` test is flaky because the 500ms window is too tight | Low | Low | Use Playwright's `expect(...).toHaveText(...)` with the default 5s timeout — DON'T pin to 500ms. The 500ms in the validation list is the user-visible budget; the test should use the framework's built-in retry. |
| `dashboard/event-contract.md` formatting drifts from the existing 6 entries | Low | Low | The agent reads the file before editing and matches the existing formatting convention. Pre-merge review catches any drift. |
| The PR triggers the convention-enforcement lint rule (PF-19 violation: missing codex_recon) | Negligible | None | This refactor is invoked OUTSIDE bug-hunt (`/plan-features --doc <refactor-queue file>`), so PF-19 reconciliation is a no-op by design. The plan body explicitly notes "Single-source recon (no `codex_recon.md` in input dir)." |
| Static HTML literals in the 4 dashboard pages cause user-visible flash of wrong label between page-paint and umbrella mount on slow connections | Low | Low | Acceptable per Option A. If post-deploy QA reports the flash as a real complaint, follow up by removing the literals (one sed-style sweep). The graceful-degradation argument outweighs the flash risk for the initial refactor. |

## Session Plan

### Session 1 — single-team merge

**Sequential:** Team A (no parallelism — single team).
**Merge order:** A merges first → micro-gate (`node --test tests/dashboard/shared-nav.spec.js` + `npx playwright test tests/e2e/journey-shared-nav.spec.ts` + `npx playwright test tests/e2e/journey-09-mobile.spec.ts` + `bash scripts/lint-event-bus.sh` + `bash scripts/lint-trusted-types.sh`) → done.
**Session checkpoint:** Full unit-test suite (`uv run pytest -x -q` for backend + `node --test` for frontend unit tests + Playwright e2e suite) after Team A merges.
**Deploy:** Standard deploy.yml push-only flow after PR merges to main.
**Post-deploy:** Manual smoke per the validation list above. If smoke confirms drawer button reads `"Manage API Key"` on cookie-session cold load, the `pending_recurrences.jsonl` entry `shared-nav-collapsed-label-stale` is resolvable.

## Quality Checklist

- [x] Every team has a "Read these files first" list.
- [x] Every team has "You MUST git add + git commit" in agent instructions.
- [x] Every team has specific validation commands (not "run tests").
- [x] File conflict table accounts for all shared files (single team — no inter-team conflicts).
- [x] No team touches >8 files (Team A touches 6 files).
- [x] Dependencies match the file conflict table (no hidden conflicts).
- [x] Critical path is actually the longest chain (single team — Team A).
- [x] Session grouping respects all dependency constraints.
- [x] Every "current state" claim in the team spec is backed by either a quoted-excerpt fenced block or a `(verified by recon agent against HEAD d4e847c)`-tagged paraphrase. (PF-18 compliance.)
- [x] No `codex_recon.md` exists in the input doc's parent directory; PF-19 reconciliation is a no-op (Claude recon is sole source). (PF-19 compliance.)
