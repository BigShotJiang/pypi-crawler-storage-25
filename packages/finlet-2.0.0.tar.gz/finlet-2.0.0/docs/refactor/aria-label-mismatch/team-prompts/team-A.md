# Team A — Unify the API-key affordance label across desktop user-menu + mobile nav drawer

You are Team A executing the aria-label-mismatch refactor. Single team, single worktree, one commit.

The execution plan lives at `/Users/justnau/finlet/docs/refactor/aria-label-mismatch/plan.md`. Read your team's spec there. Refactor scope doc at `/Users/justnau/finlet/docs/bug-hunt/refactor-queue/aria-label-mismatch.md` is the source-of-truth for the bug shape and constraints.

---

## CRITICAL RULES

- **Read `/Users/justnau/finlet/docs/KNOWN_FAILURES.md` first.** Do NOT report any test in that list as a regression — they are pre-existing failures that pre-flight has already marked with `@pytest.mark.xfail`.
- **Read the "Read these files first" list in your spec BEFORE writing any code.** Building on training-data assumptions instead of the actual codebase state is the #1 execution failure mode. Specifically read at minimum: `dashboard/shared-nav.js` (full file or at least lines 200-450 for the helper + relabel sites), `dashboard/mobile-nav.js` (full file), `dashboard/auth.js` (find `saveAuth`, `logout`, `setApiKey` and any other `_inMemoryApiKey` mutation sites), `dashboard/event-bus.js`, `dashboard/event-contract.md`, `docs/decisions/copy-api-key-dead-affordance.md` (main + 2026-05-06 addendum), `docs/decisions/dashboard-event-bus.md`, `tests/dashboard/shared-nav.spec.js` (full file — note its sandbox shim pattern), and `tests/e2e/journey-shared-nav.spec.ts`.
- **Follow existing patterns.** The helper at `dashboard/shared-nav.js:417-422` is the style model: terse, defensive against undefined `FinletAuth`, idempotent, uses `textContent` not `innerHTML`. Match it.
- **Preserve dual-label semantics.** From `docs/decisions/copy-api-key-dead-affordance.md`: `getApiKey()` non-null → `"Copy API Key"`; `getApiKey()` null → `"Manage API Key"`. The hash-only key storage invariant is load-bearing security. DO NOT change which label shows when. Only the unification of surfaces changes.
- **You MUST `git add` and `git commit` all your changes before finishing.** Worktree work that isn't committed is lost when the worktree is torn down. This rule is non-negotiable.
- **Your commit message MUST start with `[Team A]:`.** Example title: `[Team A]: dashboard: unify API-key affordance label via parameterized helper + auth:state-change bus subscriber`.
- **Run the validation commands from your spec before finishing.** If validation fails, fix the issue and re-commit. Do NOT report DONE while validation is failing.
- **Do NOT modify the 4 static HTML files** (`dashboard/index.html`, `dashboard/billing.html`, `dashboard/leaderboard.html`, `dashboard/settings.html`). Per Option A in the plan, the umbrella's mount-time pass overrides their literals; leaving them as `"Copy API Key"` is graceful-degradation if JS fails to load.
- **Do NOT modify `docs/decisions/copy-api-key-dead-affordance.md`.** Decision-record updates fall under the docs team (file-ownership). The post-merge addendum is a separate small PR.
- **Do NOT push to origin yourself.** The orchestrator handles the push-and-PR flow after merging your worktree to local main.

---

## Your spec (from plan.md)

### Read these files first

- `dashboard/shared-nav.js:198` — `_buildHeaderHTML` literal for `#menu-copy-key` button.
- `dashboard/shared-nav.js:288` — current mount-time call to `_relabelCopyApiKeyButton()` from `_initSharedUserMenu`.
- `dashboard/shared-nav.js:298` — current trigger-click gated call (`if (isOpen)`) — DELETE this gate; the bus subscriber covers any case where a key is minted between page load and menu open.
- `dashboard/shared-nav.js:324-328` — desktop redirect path on cookie-session click — confirm semantics preserved; no changes needed here.
- `dashboard/shared-nav.js:343` — clipboard-success reset literal `copyKeyBtn.textContent = 'Copy API Key'` — REPLACE with a helper call so the reset respects current auth state.
- `dashboard/shared-nav.js:417-422` — current `_relabelCopyApiKeyButton()` body — the helper to parameterize.
- `dashboard/mobile-nav.js:34` — `drawerCopyKey = document.getElementById('nav-drawer-copy-key')`.
- `dashboard/mobile-nav.js:175-195` — drawer button click handler — REPLACE the line-188 reset literal with a helper call; keep the line-180 `desktopCopyKey.click()` proxy.
- `dashboard/auth.js` (full file, but specifically `saveAuth`, `logout`, `setApiKey` and any other `_inMemoryApiKey` mutation sites) — ADD `bus.publish('auth:state-change', { hasKey: !!FinletAuth.getApiKey() })` after each mutation.
- `dashboard/event-bus.js:55-130` — confirm the `subscribe` / `publish` / `getLastPublished` API surface; the new bus subscriber MUST use `window.finletBus.subscribe(...)`.
- `dashboard/event-contract.md` — current 6-event documentation — ADD a 7th entry for `auth:state-change` in the same commit.
- `docs/decisions/copy-api-key-dead-affordance.md` — dual-label semantics decision record (security invariant).
- `docs/decisions/dashboard-event-bus.md` — bus contract.
- `tests/dashboard/shared-nav.spec.js` — 8 existing unit tests must stay green; new tests extend coverage.
- `tests/e2e/journey-shared-nav.spec.ts` — extend single existing test to cover BOTH surfaces × BOTH auth paths × BOTH lifecycle states + bus repaint.
- `tests/e2e/journey-09-mobile.spec.ts:60` — `#nav-drawer-copy-key` visibility assertion must keep passing.

### Recon evidence (verified by recon agent against HEAD `d4e847c`)

The current state of the helper, mount call, gated call, and clipboard reset literal:

```javascript dashboard/shared-nav.js:198-199
198  '<button class="user-menu-item" role="menuitem" id="menu-copy-key">Copy API Key</button>'
```

```javascript dashboard/shared-nav.js:288
288    _relabelCopyApiKeyButton();
```

```javascript dashboard/shared-nav.js:298
298    if (isOpen) {
       _relabelCopyApiKeyButton();
       }
```

```javascript dashboard/shared-nav.js:343
343    copyKeyBtn.textContent = 'Copy API Key';
```

```javascript dashboard/shared-nav.js:417-422
417  function _relabelCopyApiKeyButton() {
418    const btn = document.getElementById('menu-copy-key');
419    if (!btn) return;
420    const hasKey = FinletAuth && FinletAuth.getApiKey();
421    btn.textContent = hasKey ? 'Copy API Key' : 'Manage API Key';
422  }
```

The mobile drawer click handler — proxies to the desktop button via `.click()` AND carries its own hardcoded reset literal at line 188:

```javascript dashboard/mobile-nav.js:175-195
175    if (desktopCopyKey) {
180        drawerCopyKey.addEventListener('click', (e) => {
           e.preventDefault();
           desktopCopyKey.click();
           });
       }
       // ... clipboard fallback path ...
188    drawerCopyKey.textContent = 'Copy API Key';
```

The 4 static HTML literal sites (DO NOT MODIFY — they stay as graceful-degradation fallbacks):

```html dashboard/index.html:68
<button class="nav-drawer-action" id="nav-drawer-copy-key" type="button">Copy API Key</button>
```

(Same literal at `billing.html:63`, `leaderboard.html:62`, `settings.html:63`.)

The bus contract — `subscribe` returns an unsubscribe function; `publish` caches the payload; `window.finletBus` is frozen:

```javascript dashboard/event-bus.js:55-130
function subscribe(event, handler) { /* ... returns unsubscribe ... */ }
function publish(event, payload) { lastPublished.set(event, payload); /* invokes handlers */ }
function getLastPublished(event) { return lastPublished.get(event); }
window.finletBus = Object.freeze({ subscribe, publish, getLastPublished });
```

The current `event-contract.md` documents 6 events and does NOT include `auth:state-change`. There is no publisher in `dashboard/auth.js` for `auth:state-change`. Both gaps are filled by this refactor.

### Files touched

- Modified: `dashboard/shared-nav.js`
  - Change `_relabelCopyApiKeyButton()` signature from zero-param to `_relabelCopyApiKeyButton(buttonOrId)` accepting either an element OR an id-string OR no arg (defaulting to `#menu-copy-key` to preserve the existing 8 unit tests' zero-arg call shape).
  - Add a top-level constant `const API_KEY_AFFORDANCE_IDS = ['menu-copy-key', 'nav-drawer-copy-key'];` so future additions are one line.
  - Add a new umbrella `_relabelAllApiKeyAffordances()` that iterates `API_KEY_AFFORDANCE_IDS` and calls `_relabelCopyApiKeyButton(id)` for each. Missing ids are silent no-ops.
  - At line 288 (current mount call site): replace `_relabelCopyApiKeyButton()` with `_relabelAllApiKeyAffordances()`.
  - At line 298: delete the `if (isOpen) { _relabelCopyApiKeyButton(); }` block entirely. The bus subscriber covers the open-time case.
  - At line 343: replace `copyKeyBtn.textContent = 'Copy API Key'` with `_relabelCopyApiKeyButton(copyKeyBtn)`.
  - Add `window.finletBus.subscribe('auth:state-change', _relabelAllApiKeyAffordances)` inside `_initSharedUserMenu()` (after the umbrella mount-time call). The subscription persists for the page lifetime — no teardown hook needed.
  - Expose the helper to `window.SharedNav` (or equivalent module scope) so `mobile-nav.js` can call it. If a `window.SharedNav` namespace doesn't exist today, create a minimal one with at least `_relabelCopyApiKeyButton` and `_relabelAllApiKeyAffordances` exposed.

- Modified: `dashboard/mobile-nav.js`
  - At line 188: replace `drawerCopyKey.textContent = 'Copy API Key'` with a call to the parameterized helper (e.g. `window.SharedNav._relabelCopyApiKeyButton(drawerCopyKey)`). Defensively check existence (`window.SharedNav && window.SharedNav._relabelCopyApiKeyButton`) and fall back to a no-op if missing — the shared-nav mount-time pass will catch up.
  - Add a one-line call to `_relabelAllApiKeyAffordances()` (via the same window export) from inside `initMobileNav()` (after `drawerCopyKey` is captured at line 34) so pages where mobile-nav initializes after shared-nav still get the drawer button relabeled at mount.

- Modified: `dashboard/auth.js`
  - After every mutation site that changes the truthiness of `_inMemoryApiKey` (functions: `saveAuth`, `logout`, `setApiKey`), add `window.finletBus.publish('auth:state-change', { hasKey: !!FinletAuth.getApiKey() })`. Use `FinletAuth.getApiKey()` (not the private variable) so the publisher reflects the same source-of-truth the helper reads. Defensively guard with `window.finletBus && window.finletBus.publish`.

- Modified: `dashboard/event-contract.md`
  - Add a 7th entry documenting `auth:state-change`: payload shape `{ hasKey: boolean }`; published by `dashboard/auth.js` after `saveAuth` / `logout` / `setApiKey`; subscribed by `dashboard/shared-nav.js` (the API-key affordance umbrella). Match the formatting of the existing 6 entries (read the file to determine ordering and section style).

- Modified: `tests/dashboard/shared-nav.spec.js`
  - Existing 8 tests stay UNCHANGED — they pass with the new signature (zero-arg defaults to `#menu-copy-key`).
  - Add 5 new tests:
    - `_relabelCopyApiKeyButton('nav-drawer-copy-key')` relabels the drawer button's `textContent` to `"Manage API Key"` on cookie-session and `"Copy API Key"` on signup.
    - `_relabelCopyApiKeyButton(elementShim)` accepts an element directly (idempotent with the id-string form).
    - `_relabelAllApiKeyAffordances()` iterates the known id list and relabels every present button. Missing ids are silent no-ops.
    - The `auth:state-change` bus subscriber, when fired with `{ hasKey: false }`, repaints both `#menu-copy-key` and `#nav-drawer-copy-key` to `"Manage API Key"` on the next tick. Use a sandbox-injected `window.finletBus` shim that the test invokes directly.
    - The desktop clipboard-success reset path (line-343 site) calls the helper instead of using the static literal — verified by asserting the button's textContent equals what the helper would produce for the current auth state.

- Modified: `tests/e2e/journey-shared-nav.spec.ts`
  - Existing single test stays.
  - Add 5 new test cases:
    - `cookie-session × #nav-drawer-copy-key`: pre-open AND post-open drawer button reads `"Manage API Key"`. Click navigates to `settings.html#api-keys`.
    - `signup × #menu-copy-key`: with `beforeEach` setting `FinletAuth.setApiKey('k_test_…')`, button reads `"Copy API Key"` in both states; click writes to clipboard.
    - `signup × #nav-drawer-copy-key`: same — `"Copy API Key"` in pre-open AND post-open drawer states.
    - `bus repaint on logout`: signup-loaded dashboard → `FinletAuth.logout()` via `page.evaluate` → BOTH buttons must repaint to `"Manage API Key"`. Use Playwright's default 5s timeout via `expect(...).toHaveText(...)` — DO NOT pin to 500ms.
    - `bus repaint on key-set`: cookie-session-loaded dashboard → `FinletAuth.setApiKey('k_test_…')` → BOTH buttons must repaint to `"Copy API Key"`.

### Deliverable

The API-key affordance label is correct on both auth paths × both surfaces × both lifecycle states, and re-paints atomically on `auth:state-change` bus events. Adding a 5th dashboard page is zero edits to the affordance code; adding a 3rd surface is one entry in the umbrella's id list. The `pending_recurrences.jsonl` entry `shared-nav-collapsed-label-stale` becomes resolvable post-deploy.

### Validation

- [ ] `cd /Users/justnau/finlet && node --test tests/dashboard/shared-nav.spec.js` — all 13 tests pass (8 existing + 5 new).
- [ ] `cd /Users/justnau/finlet && npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-shared-nav.spec.ts` — all 6 tests pass (1 existing + 5 new). NOTE: Finlet's Playwright config lives at `tests/e2e/playwright.config.ts`, NOT at repo root. Always pass `--config=tests/e2e/playwright.config.ts` explicitly.
- [ ] `cd /Users/justnau/finlet && npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-09-mobile.spec.ts` — existing visibility assertion still passes.
- [ ] `bash /Users/justnau/finlet/scripts/lint-event-bus.sh` — passes.
- [ ] `bash /Users/justnau/finlet/scripts/lint-trusted-types.sh` — passes.

If you cannot run Playwright in your worktree environment (no dev server, no Playwright runtime) — explicitly note this in your DONE report. The orchestrator's micro-gate after merge will run them on main. Skip-with-explanation is acceptable; lying about a passing test is not.

### When done

Report back:
```
DONE
commit_sha: <40-char>
validation:
  - node --test tests/dashboard/shared-nav.spec.js: <X passed / Y failed>
  - playwright journey-shared-nav.spec.ts: <X passed / Y failed OR skipped: reason>
  - playwright journey-09-mobile.spec.ts: <X passed / Y failed OR skipped: reason>
  - lint-event-bus.sh: pass | fail
  - lint-trusted-types.sh: pass | fail
files_modified: <list>
notes: <anything the orchestrator should know>
```

Or if BLOCKED:
```
BLOCKED
reason: <what went wrong>
state: <what you did before getting stuck — files modified, commits made (if any)>
recommendation: <what should happen next>
```
