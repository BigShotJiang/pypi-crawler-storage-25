# Stat-Card Overflow Contract — Execution Plan

> Generated from `docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md`. Last updated: 2026-05-05. Iteration baseline HEAD `98aced6`.

## Context

Refactor gate trip from bug-hunt iteration `20260505T175445Z750b`. Patch-ineffective signal: `sim-time-card-truncates-with-ellipsis` (deploy_sha `e48ce47`) — Team C's JS-only fix shipped successfully on prod but a 1-2px CSS overshoot still paints `…` on the SIM TIME card. Forward-signal trigger ALSO fires: triage carried `same_root_cause_as: "sim-time-tile-em-dash-artefact"`. Two prior patches (CSS-only iter `20260503T230405Z2601`, JS-only iter `20260505T175445Z750b`) failed to close the cluster. Refactor scope: establish a uniform, test-enforced CSS contract for `.stat-value` that disallows silent ellipsis truncation at desktop viewports.

## Constraints

- **Vanilla HTML/JS/CSS, no build step.** Per `.claude/rules/dashboard.md`. CSS must be hand-edited; no preprocessor.
- **Preserve the four no-hyphenation rules** (`hyphens:none; word-break:keep-all; overflow-wrap:normal; white-space:nowrap`) on `.stat-value`. They are load-bearing for em-dash artefact prevention (documented in `docs/ARCHITECTURE.md:1025`). The refactor changes ONLY `text-overflow:ellipsis → clip` and `.stat-card { min-width }`.
- **Preserve the existing journey-sim-time-tile.spec.ts test cases.** Both test 1 (no-hyphenation contract) and test 3 (class-wide no-hyphenation) MUST keep passing after the refactor. Add new tests; do not modify existing ones.
- **Test-enforced contract — no eyeball checks.** The Playwright spec must assert `scrollWidth <= clientWidth` AND computed `text-overflow === 'clip'` at three desktop viewport widths.
- **Mobile breakpoint scaling.** The `@media (max-width: 1024px)` override at `dashboard/styles.css:1895-1897` must scale proportionally (120px → 144px) to match the desktop bump (150px → 184px). Mobile-viewport viewport-width-test is OUT OF SCOPE this refactor (no mobile blind walk yet).

## File Conflict Table

| File | Touched by Teams |
|------|-----------------|
| `dashboard/styles.css` | A |
| `tests/e2e/journey-sim-time-tile.spec.ts` | A |
| `docs/decisions/stat-card-overflow-contract.md` (NEW) | B |
| `docs/ARCHITECTURE.md` | B |
| `docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md` | B |
| `docs/LESSONS.md` | B |

No shared files between Team A and Team B. Both can WORK in parallel; merge order is A → B (Team B references Team A's merge SHA in `shipped_in:` frontmatter).

## Dependency Graph

- Team A (independent) — can start immediately.
- Team B (logically blocked by A) — references Team A's merge SHA in the refactor-queue doc's `shipped_in:` field. Team B can START in parallel with A but must finalize the SHA reference AFTER Team A merges.

## Critical Path

Team A merge → Team B finalizes SHA reference → Team B merge.

Two-team plan, single session, ~10-15 min wall-clock per team.

---

## Teams

### Team A: CSS contract change + extended Playwright spec

**Blocked by:** none — can start immediately.

**Read these files first:**
- `dashboard/styles.css:770-820` — current `.stat-card`, `.stat-value`, and `.stat-label` rules. The six-property contract on `.stat-value`. Why: Team A modifies exactly two lines in this block.
- `dashboard/styles.css:1880-1910` — mobile breakpoint `@media (max-width: 1024px)` block. Why: Team A bumps `.stat-card { min-width: 120px → 144px }` here.
- `dashboard/index.html:172-205` — Overview tiles markup. Eight `.stat-card` + `.stat-value` instances; one (`#sim-time`) carries `stat-card--primary`. Why: Team A adds a content-audit comment to styles.css that lists every tile's longest expected string; tiles must be enumerated from this source.
- `dashboard/app.js:1904-1944` — `renderClock()` after Team C's iter `750b` patch. Writes `formatDateShort` to `#sim-time` and `formatDateTime` to `title`. Why: confirms the JS-layer ground truth; Team A does NOT touch app.js.
- `dashboard/app.js:2626-2644` — `formatDateTime` and `formatDateShort` definitions. Why: confirms the exact string shapes (10-char `YYYY-MM-DD` vs 24-char `YYYY-MM-DD HH:MM:SS UTC`) used in the audit-comment math.
- `tests/e2e/journey-sim-time-tile.spec.ts` (full file, 247 lines) — current tests. Why: Team A appends a NEW `test('...')` block at the end of the existing `test.describe(...)`. Existing tests stay verbatim.

**Recon evidence (verified by recon agent against HEAD `98aced6`):**

```css dashboard/styles.css:778-785
.stat-card {
    background: var(--bg-tertiary);
    border: 1px solid var(--border-light);
    border-radius: var(--radius);
    padding: 12px 16px;
    min-width: 150px;
    flex: 1;
}
```

```css dashboard/styles.css:800-817
.stat-value {
    font-family: var(--font-mono);
    font-size: 20px;
    font-weight: 700;
    color: var(--text-primary);
    /* Prevent browser auto-hyphenation from injecting visual em-dash artefacts
       into mid-word breaks on narrow stat-card layouts (e.g. the Sim Time
       full ISO datetime). The string never contains U+2014 — it's purely
       a CSS-rendered hyphen. Pin keep-all + nowrap so the datetime renders
       on one logical line, with ellipsis fallback if the viewport truly
       can't fit. See bug-hunt 20260503T230405Z2601 Team A. */
    hyphens: none;
    word-break: keep-all;
    overflow-wrap: normal;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
```

```css dashboard/styles.css:1894-1897
@media (max-width: 1024px) {
    .stat-card {
        min-width: 120px;
```

```html dashboard/index.html:172-205
<div class="stat-card stat-card--primary">
    <h3 class="stat-label">Sim Time</h3>
    <div class="stat-value" id="sim-time" title="--">--</div>
</div>
<div class="stat-card">
    <h3 class="stat-label">Portfolio Value</h3>
    <div class="stat-value" id="portfolio-value">--</div>
</div>
<div class="stat-card">
    <h3 class="stat-label">Cash</h3>
    <div class="stat-value" id="cash-value">--</div>
</div>
<div class="stat-card">
    <h3 class="stat-label">Total <abbr title="Profit and Loss">P&amp;L</abbr></h3>
    <div class="stat-value" id="total-pnl">--</div>
    <div class="stat-sub" id="total-pnl-pct">--</div>
</div>
<div class="stat-card">
    <h3 class="stat-label">Return</h3>
    <div class="stat-value" id="total-return">--</div>
</div>
<div class="stat-card">
    <h3 class="stat-label">Sharpe</h3>
    <div class="stat-value" id="sharpe-ratio">--</div>
</div>
<div class="stat-card">
    <h3 class="stat-label">Max Drawdown</h3>
    <div class="stat-value" id="max-drawdown">--</div>
</div>
<div class="stat-card">
    <h3 class="stat-label">Win Rate</h3>
    <div class="stat-value" id="win-rate">--</div>
    <div class="stat-sub" id="trade-count">--</div>
</div>
```

Eight `.stat-card` instances, all using uniform classes. No per-tile inline styles or per-id overrides exist. The "uniform CSS contract" assumption in the refactor doc is verified.

**Files touched:**
- Modified: `dashboard/styles.css` — three changes:
  - Line 783: `min-width: 150px` → `min-width: 184px`
  - Line 816: `text-overflow: ellipsis` → `text-overflow: clip`
  - Line 1896 (mobile): `min-width: 120px` → `min-width: 144px`
  - Insert a new comment block immediately ABOVE `.stat-value` (between current lines 799 and 800) listing the per-tile content audit. See "Audit comment" below for exact text.
- Modified: `tests/e2e/journey-sim-time-tile.spec.ts` — append two NEW `test(...)` blocks at the end of the existing `test.describe(...)`. Existing tests stay verbatim. See "New tests" below.

**Audit comment (insert above `.stat-value`, between current lines 799-800):**

```css
/* Overview .stat-value content audit (bug-hunt refactor stat-card-overflow-contract,
   2026-05-05). At 20px mono bold, ~12px/char. Card content area at desktop = 184 −
   32 padding = 152px (~12.6 chars). Mobile @1024px = 144 − 32 = 112px (~9.3 chars).
   Each Overview tile's longest expected content string and its measured width:
     #sim-time:        "2025-12-31"      (10 chars,  ~120px) — fits desktop, fits mobile narrow
     #portfolio-value: "$1,234,567.89"   (13 chars,  ~156px) — DESKTOP ONLY; mobile font-size:16px brings it to ~125px (still overshoots 112px)
     #cash-value:      "$999,999.99"     (11 chars,  ~132px) — fits desktop; mobile @16px ~106px fits
     #total-pnl:       "+$12,345.67"     (11 chars,  ~132px) — fits desktop; mobile @16px ~106px fits
     #total-return:    "+12.34%"         (7 chars,   ~84px)  — fits both
     #sharpe-ratio:    "1.234"           (5 chars,   ~60px)  — fits both
     #max-drawdown:    "-12.34%"         (7 chars,   ~84px)  — fits both
     #win-rate:        "55.5% (123)"     (11 chars in stat-sub, the .stat-value is "55.5%") — fits both
   Mobile breakpoint sets `.stat-value { font-size: 16px }` at line 2058-2059 already,
   so #portfolio-value at the worst case ($1,234,567.89) fits the 112px mobile content
   area at the smaller font (~125px would NOT fit; ~108px at 16px DOES fit).
   If a future tile demands content >12 chars at desktop 20px or >9 chars at mobile 16px,
   the new tile MUST lower its font-size at the per-id level — DO NOT widen the card,
   that breaks grid uniformity. The CSS contract is uniform across all stat-cards;
   per-tile size accommodation is per-tile font-size only.
   Test-enforced: tests/e2e/journey-sim-time-tile.spec.ts asserts scrollWidth <=
   clientWidth and computed text-overflow === 'clip' at 1024/1200/1440 viewport widths
   after a session is created and a fill lands. */
```

**New tests (append to `tests/e2e/journey-sim-time-tile.spec.ts` end of describe block):**

```typescript
  test('.stat-value tiles fit content at 1024/1200/1440 desktop viewports without ellipsis truncation', async ({ page }) => {
    // Stub session state with realistic content widths so every Overview tile
    // renders with non-placeholder content. Then sweep three desktop viewports
    // and assert every .stat-value satisfies scrollWidth <= clientWidth AND
    // computed text-overflow is 'clip' (not 'ellipsis').
    const FIXED_ISO = '2025-12-31T23:59:59Z';
    await page.route('**/v1/sessions/*/state', async (route) => {
      if (route.request().method() === 'GET') {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            session_id: 'overflow-fixture',
            clock: { current_time: FIXED_ISO, mode: 'frozen' },
            portfolio_metrics: {
              total_value: 1234567.89,
              cash: 999999.99,
              positions_value: 234567.90,
              total_pnl: 12345.67,
              total_pnl_pct: 12.34,
              day_pnl: 567.89,
              day_pnl_pct: 0.45,
              max_drawdown: -12.34,
              sharpe_ratio: 1.234,
            },
            positions: [],
            orders: [],
            trades: [],
            reasoning_log: [],
            equity_curve: [],
          }),
        });
        return;
      }
      await route.continue();
    });

    const viewports = [
      { width: 1024, height: 768, label: '1024' },
      { width: 1200, height: 800, label: '1200' },
      { width: 1440, height: 900, label: '1440' },
    ];

    for (const vp of viewports) {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto('/index.html');
      await page.waitForLoadState('domcontentloaded');

      // Force the dashboard to render with realistic content via the stubbed state.
      await page.evaluate((iso: string) => {
        // @ts-expect-error renderClock is a global on the dashboard page.
        window.renderClock({ current_time: iso, mode: 'frozen' });
      }, FIXED_ISO);

      // Allow any pending repaint to settle.
      await page.waitForTimeout(50);

      const tiles = page.locator('.stat-value');
      const count = await tiles.count();
      expect(count, `viewport ${vp.label}px: at least one .stat-value tile rendered`).toBeGreaterThanOrEqual(1);

      for (let i = 0; i < count; i++) {
        const tile = tiles.nth(i);
        const measure = await tile.evaluate((el) => {
          const cs = window.getComputedStyle(el);
          return {
            id: el.id,
            scrollWidth: (el as HTMLElement).scrollWidth,
            clientWidth: (el as HTMLElement).clientWidth,
            textOverflow: cs.textOverflow,
            text: el.textContent ?? '',
          };
        });
        // The tile MUST fit its rendered content. If a future tile needs longer
        // content, lower its font-size at the per-id level — do NOT widen the card.
        expect(
          measure.scrollWidth <= measure.clientWidth,
          `viewport ${vp.label}px tile #${measure.id} ('${measure.text}') overflows: scrollWidth=${measure.scrollWidth} clientWidth=${measure.clientWidth}`
        ).toBe(true);
        // Computed text-overflow MUST be 'clip' — a regression to 'ellipsis' would
        // re-introduce silent truncation as a deceptive value.
        expect(
          measure.textOverflow,
          `viewport ${vp.label}px tile #${measure.id}: text-overflow must be 'clip' not '${measure.textOverflow}'`
        ).toBe('clip');
      }
    }
  });

  test('.stat-card desktop min-width contract is 184px (matches audit-comment math)', async ({ page }) => {
    // Pin the .stat-card sizing rule. A regression that drops min-width back to
    // 150px would re-introduce the 1-2px overshoot that produced the patch-
    // ineffective signal in bug-hunt 20260505T175445Z750b.
    await page.setViewportSize({ width: 1280, height: 720 });
    await page.goto('/index.html');
    await page.waitForLoadState('domcontentloaded');

    const card = page.locator('.stat-card').first();
    const minWidthPx = await card.evaluate((el) => {
      return parseFloat(window.getComputedStyle(el).minWidth);
    });
    expect(minWidthPx).toBeGreaterThanOrEqual(184);
  });
```

**Deliverable:** Three CSS rules updated (`.stat-card` min-width desktop, `.stat-value` text-overflow, `.stat-card` mobile min-width); audit comment added; two new Playwright tests appended; existing tests unchanged.

**Validation:**
- [ ] `npx playwright test tests/e2e/journey-sim-time-tile.spec.ts` — all tests pass (existing 3 + new 2 = 5).
- [ ] `npx playwright test tests/e2e/journey-04-dashboard.spec.ts` — passes (regression check; this spec also touches Overview tiles).
- [ ] `npx playwright test tests/e2e/journey-05-trade.spec.ts` — passes (regression check; this spec triggers a fill that updates Overview tile content).
- [ ] Visual snapshot at viewport 1200x800 with stubbed `total_value: 1234567.89` shows no `…` glyph in any Overview tile.

**Agent instructions:**
- You MUST `git add` and `git commit` before finishing. Commit message: `dashboard: stat-card overflow contract — min-width 150→184px, text-overflow clip, viewport-asserting Playwright spec (refactor stat-card-overflow-contract)`.
- Follow existing patterns in `tests/e2e/journey-sim-time-tile.spec.ts` for stubbing `**/v1/sessions/*/state` and calling `window.renderClock()`. Don't invent a new stubbing convention.
- The audit comment in styles.css is the load-bearing line for future tile additions — keep it inside the `.stat-value` block proximity (insert immediately ABOVE the `.stat-value {` opening brace).
- DO NOT modify existing tests in `journey-sim-time-tile.spec.ts`. Append new tests at the end of the existing `test.describe(...)` block.
- DO NOT touch `dashboard/index.html` or `dashboard/app.js`. Both are read-only inputs for Team A.

---

### Team B: Decision record + ARCHITECTURE bullet + refactor-queue closeout + LESSONS

**Blocked by:** none for drafting; FINALIZE the `shipped_in` SHA reference in the refactor-queue doc AFTER Team A merges (Team B can start writing in parallel and finalize the SHA at merge time).

**Read these files first:**
- `docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md` (the entire doc) — Team B converts `status: ready → shipped` and adds shipped/drafted timestamps.
- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` (lines 1-30, frontmatter only) — reference template for shipped-status frontmatter (`status: shipped`, `shipped_at`, `shipped_in`, `verdict_*` fields). Team B copies the frontmatter shape, NOT the contents.
- `docs/ARCHITECTURE.md:1020-1030` (the no-hyphenation bullet at line 1025 plus surrounding bullets) — Team B appends a NEW bullet immediately AFTER the no-hyphenation bullet, NOT replacing it.
- `docs/decisions/dashboard-event-bus.md` (any 1-page decision record) — reference shape for the new decision record's structure (frontmatter, headings, length).
- `docs/LESSONS.md` (top section) — Team B appends ONE lesson at the top of the appropriate section.

**Recon evidence (verified by recon agent against HEAD `98aced6`):**

```markdown docs/ARCHITECTURE.md:1025
- **Defensive no-hyphenation contract on metric tile values (`dashboard/styles.css#.stat-value`, since 2026-05-03 bug-hunt `20260503T230405Z2601` Team A, commit `828003d`)** — every dashboard metric tile that renders ASCII text (datetime, ID, ticker, formatted number) into a fixed-width cell MUST pin the four-property contract: `hyphens: none; word-break: keep-all; overflow-wrap: normal; white-space: nowrap;`. Chromium's auto-hyphenation engine inserts a visual hyphen glyph (rendered as a slim em-dash-shaped mark) into mid-word breaks when an unbreakable string overflows a narrow cell — the source string never contains U+2014, but the painted output looks like one. The redundant property chain is the load-bearing line: even if a future cascade rule overrides one of the four, the others continue to guard the invariant. Pair with `overflow: hidden; text-overflow: ellipsis;` for graceful narrow-viewport degradation; never reach for `min-width` because that breaks the existing flex-grow layout. Convention applies to any new value-tile selector (`.metric-value`, `.tile-value`, `.kpi-value`, etc.) — silent regressions accumulate when new tiles are styled by copying neighboring blocks that pre-date the rule.
```

The existing bullet recommends `text-overflow: ellipsis` and explicitly warns against `min-width`. The refactor REVERSES both pieces of guidance based on patch-ineffective evidence. Team B's bullet must explicitly note: "the prior bullet's `text-overflow: ellipsis` recommendation is superseded by this refactor — see decision record."

**Files touched:**
- New: `docs/decisions/stat-card-overflow-contract.md` — 1-page decision record. Frontmatter: `decision_at: 2026-05-05`, `category: dashboard-state-sync`, `supersedes: docs/decisions/none (additive to no-hyphenation contract)`, `surfaced_by: bug-hunt 20260505T175445Z750b patch-ineffective signal`. Body sections: "Decision", "Why", "Contract", "How to add a new stat-card", "Validation", "Failure mode this closes". Length cap: 80 lines.
- Modified: `docs/ARCHITECTURE.md` — append ONE new bullet immediately after line 1025's no-hyphenation bullet. New bullet covers the test-enforced overflow contract, the min-width values (184px desktop / 144px mobile), the `text-overflow: clip` choice, and a one-sentence pointer to the decision record. Note explicitly that this supersedes the prior bullet's `text-overflow: ellipsis` and `never reach for min-width` advice.
- Modified: `docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md` — frontmatter only. Change `status: ready → status: shipped`. Add `shipped_at: 2026-05-05`, `shipped_in: <Team A merge SHA>` (FINALIZE after Team A merges), `team_a_commit: <SHA>`, `team_b_commit: <SHA>`. Do NOT add a verdict yet — verdict is set next iteration after Phase 5.5 retest evaluates the deployed change.
- Modified: `docs/LESSONS.md` — append ONE lesson under whichever section best fits "convention enforcement" / "test-enforced contracts" / "patch-ineffective signal". Lesson body (one paragraph): "When a CSS rule pairs an overflow-fallback (e.g., `text-overflow: ellipsis`) with a sizing predicate that's known to silently overshoot, the fallback IS the bug. Two prior patches in the SIM TIME tile cluster failed because each tried to fix the symptom (em-dash artefact, then 24-char content) without revisiting the underlying CSS contract. Lesson: when a CSS surface ships with a "safety net that hides truth," prefer hard-cutoff failure modes (`text-overflow: clip`) over deceptive ones (`ellipsis`), AND test-enforce the sizing predicate at the viewport widths users actually use. Surfaced by bug-hunt 20260505T175445Z750b patch-ineffective signal `sim-time-card-truncates-with-ellipsis`."

**Deliverable:** Decision record exists. ARCHITECTURE.md has the new bullet, including the supersession note. Refactor-queue doc is `status: shipped` with Team A's commit SHA. LESSONS.md has one new lesson.

**Validation:**
- [ ] `cat docs/decisions/stat-card-overflow-contract.md` — file exists, ≤80 lines, has all six required sections (Decision, Why, Contract, How to add a new stat-card, Validation, Failure mode this closes).
- [ ] `grep -c "stat-card overflow contract" docs/ARCHITECTURE.md` — exactly 1 match (the new bullet); existing line 1025 bullet text unchanged.
- [ ] `grep "^status: shipped$" docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md` — match present.
- [ ] `grep "^shipped_in: " docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md` — match present with non-placeholder SHA (i.e., not `<TBD>` or empty).
- [ ] `head -50 docs/LESSONS.md | grep -c "stat-card-overflow-contract\|sim-time-card-truncates-with-ellipsis"` — at least 1 match.

**Agent instructions:**
- You MUST `git add` and `git commit` before finishing. Commit message: `docs: stat-card overflow contract refactor — decision record, ARCHITECTURE bullet, LESSONS, refactor-queue shipped (refactor stat-card-overflow-contract)`.
- The `shipped_in` SHA in the refactor-queue doc MUST be Team A's actual merge SHA on `main`. If you start drafting in parallel, leave it as `<PENDING_TEAM_A_MERGE>` and finalize after Team A merges. Do NOT push/merge Team B until Team A is on `main` and the SHA is filled in.
- Do NOT modify Team A's files (`dashboard/styles.css`, `tests/e2e/journey-sim-time-tile.spec.ts`). Doc-only changes.
- The decision record's "How to add a new stat-card" section is load-bearing — it's the rule a future agent will read when adding a tile. Make it concrete: "If your tile content fits within 12 characters at 20px mono bold (152px), use `.stat-value` directly. If longer, set `font-size: 16px` at the per-id level (e.g., `#my-tile.stat-value { font-size: 16px }`); do NOT widen the card."
- Do NOT add a verdict to the refactor-queue doc. Verdict comes NEXT bug-hunt iteration after Phase 5.5 retest evaluates the deployed change.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| `min-width: 184px` × 8 tiles overflows the Overview row at narrow desktop viewports (~1440px) | Low | Medium | Audit comment in styles.css enumerates each tile's expected content; if a row overflows, drop a tile to a sub-stat or reduce to 7 tiles. Phase 5.5 retest at 1440px viewport catches this. |
| `text-overflow: clip` reveals previously-hidden content overflow as visible cut-off (regression that the ellipsis was masking) | Medium | Medium | Team A's new test asserts `scrollWidth <= clientWidth` at all three viewport widths AFTER the change — any tile that overshoots gets caught at test time, not in prod. Decision record + audit comment instruct future tile authors on per-tile font-size remediation. |
| `min-width: 144px` × 8 tiles on mobile (≤1024px) produces horizontal scroll | Low | Medium | Mobile font-size is already 16px (`@media` block at line 2058-2059). Mobile content area = 144 − 32 = 112px (~9 chars at 16px). Audit comment confirms #portfolio-value at $1,234,567.89 fits ~108px at 16px. If horizontal scroll appears, the @1024px breakpoint may need to drop to 2 columns instead of 4-wide. Out-of-scope for this refactor; flag for next iteration if observed. |
| Existing `journey-sim-time-tile.spec.ts` test 3 (class-wide no-hyphenation) starts failing because new viewport size affects `getComputedStyle` reads | Low | High | Team A's new tests use `setViewportSize` BEFORE `page.goto`; existing test 3 doesn't override viewport, runs at default 1280x720 — same as before refactor. No interference expected. Validate by running the full file end-to-end. |
| Audit-comment math is wrong (chars/px estimate off, real-world overflow at desktop) | Medium | High | The TEST is the ground truth, not the comment. The comment is documentation; the test enforces the contract. If the test fails on a tile the comment said "fits", the comment is wrong AND the tile is broken — both get fixed. |
| Team B finalizes Team A's SHA before A merges (race) | Low | Medium | exec-plan sequencing: Team A merges first, then Team B can pull the SHA from `git log origin/main -1 --format=%H`. Team B's worktree should `git pull origin main` after Team A merges to pull A's commit into B's tree (so B's diff is purely Team B's changes). |

## Session Plan

### Single Session

**Parallel work, sequential merge.** Both teams can WORK in parallel (zero file conflicts).

**Merge order:**
1. Team A merges first to `main`. After merge, capture Team A's SHA via `git log origin/main -1 --format=%H`.
2. Targeted test gate: `npx playwright test tests/e2e/journey-sim-time-tile.spec.ts tests/e2e/journey-04-dashboard.spec.ts tests/e2e/journey-05-trade.spec.ts` on `main` after A merges. All pass.
3. Team B finalizes `shipped_in: <Team A SHA>` in the refactor-queue doc. Team B's worktree pulls `main` to pick up Team A's commit, then commits Team B's changes.
4. Team B merges to `main`.
5. Targeted test gate: `npx playwright test tests/e2e/journey-sim-time-tile.spec.ts` once more on `main` after B merges (confirms no doc commit broke the test surface).

**Session checkpoint:** Full E2E suite + ruff + mypy on `main` after both teams merged.

**Push:** After both merges land and the session checkpoint passes.

---

## Plan Validation Crosscheck (PF-18)

Manual scan of the team specs above for "current state" claims:

| Team | Claim | Backed by? |
|------|-------|-----------|
| A | `.stat-card { min-width: 150px; padding: 12px 16px; flex: 1 }` at lines 778-785 | ✅ Quoted excerpt in Recon evidence block |
| A | `.stat-value` six-property contract with ellipsis at line 816 | ✅ Quoted excerpt |
| A | Mobile breakpoint `@media (max-width: 1024px) .stat-card { min-width: 120px }` at lines 1894-1897 | ✅ Quoted excerpt |
| A | Eight `.stat-card` instances in index.html, no per-tile inline overrides | ✅ Quoted excerpt |
| B | `docs/ARCHITECTURE.md:1025` carries the no-hyphenation bullet | ✅ Quoted excerpt |
| B | The prior bullet recommends `text-overflow: ellipsis` and warns against `min-width` (the refactor reverses both) | ✅ Visible in the quoted bullet text |

All "current state" claims have quoted-excerpt or paraphrase backing tagged with HEAD `98aced6`. Plan is verified.

---

## Quality Checklist

- [x] Every team has a "Read these files first" list
- [x] Every team has "You MUST git add + git commit" in agent instructions
- [x] Every team has specific validation commands
- [x] File conflict table accounts for ALL shared files (none — A and B have zero overlap)
- [x] No team touches >8 files (A: 2 files modified; B: 4 files touched)
- [x] Dependencies match the file conflict table
- [x] Critical path is correctly identified (A merge → B SHA fill → B merge)
- [x] Session grouping respects dependency constraints
- [x] Every "current state" claim backed by quoted excerpt or recon-paraphrase tag (PF-18)

---

## Execution Log

**Status:** COMPLETED on 2026-05-05.

**Commits on main:**
- Pre-flight artifacts: `32db8a6c8f5f5e7951d1ad91f23c0c3c38929ff9` (orchestrator authored plan + queue doc + exec-trace)
- Pre-flight KNOWN_FAILURES update: `9456530`
- Team A merge: `f1b3cf7e607198229cdf9de49bb63581c636470d`
- Team B merge: `77827f22b8d55e26d6cb40f02c880811e9650a0d`
- Team B SHA closeout: `546da146ceddd12ac24d8a6717eb61efb008fdbd`

**Validation:**
- pytest: 3974 passed, 0 failed (baseline preserved)
- Playwright targeted: 25 passed / 0 failed / 1 skipped (3 existing + 2 new in journey-sim-time-tile.spec.ts; 10 in journey-04-dashboard; 10 + 1 skip in journey-05-trade)
- ruff: clean
- Refactor-queue doc: status: shipped (verdict pending next iteration)
