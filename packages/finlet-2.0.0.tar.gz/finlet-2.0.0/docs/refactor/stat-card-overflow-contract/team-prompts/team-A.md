You are Team A: CSS contract change + extended Playwright spec for the `stat-card-overflow-contract` refactor.

This refactor closes a patch-ineffective signal from bug-hunt iteration `20260505T175445Z750b`. Two prior patches (CSS-only iter `20260503T230405Z2601`, JS-only iter `20260505T175445Z750b`) failed to close the SIM TIME card truncation cluster. Your job: change the CSS contract so silent ellipsis truncation can no longer happen at desktop viewport widths, and append Playwright assertions that test-enforce the contract.

SPAWN BASE SHA: `32db8a6c8f5f5e7951d1ad91f23c0c3c38929ff9`. Your worktree was auto-reset to this SHA before you started; verify with `git rev-parse HEAD` if you suspect drift.

**Blocked by:** none — start immediately.

**Read these files first** (do this BEFORE writing any code):
- `dashboard/styles.css:770-820` — current `.stat-card`, `.stat-value`, `.stat-label` rules. The six-property contract on `.stat-value`.
- `dashboard/styles.css:1880-1910` — mobile breakpoint `@media (max-width: 1024px)` block.
- `dashboard/styles.css:2050-2070` — find the mobile `.stat-value { font-size: 16px }` override; confirm it exists and what line it's at (the audit comment math depends on it).
- `dashboard/index.html:172-205` — Overview tiles markup. Eight `.stat-card` + `.stat-value` instances; one (`#sim-time`) carries `stat-card--primary`.
- `dashboard/app.js:1904-1944` — `renderClock()`. Read-only — confirms the JS-layer ground truth post-Team-C-fix. Do NOT modify.
- `dashboard/app.js:2626-2644` — `formatDateTime` and `formatDateShort`. Read-only — confirms the exact string shapes the audit comment cites.
- `tests/e2e/journey-sim-time-tile.spec.ts` (entire file, 247 lines) — current tests. You're appending NEW tests at the end of the existing `test.describe(...)`; existing tests stay verbatim.
- `docs/KNOWN_FAILURES.md` — do NOT report any test in here as a regression.

**Recon evidence (verified by recon agent against HEAD `98aced6`, carried forward to spawn base `32db8a6`):**

Current `.stat-card` rule:
```css dashboard/styles.css:778-785
.stat-card {
    background: var(--bg-tertiary);
    border: 1px solid var(--border-light);
    border-radius: var(--radius);
    padding: 12px 16px;
    min-width: 150px;
    flex: 1;
}
```

Current `.stat-value` rule (note the ellipsis fallback at the bottom — that IS the bug):
```css dashboard/styles.css:800-817
.stat-value {
    font-family: var(--font-mono);
    font-size: 20px;
    font-weight: 700;
    color: var(--text-primary);
    /* Prevent browser auto-hyphenation from injecting visual em-dash artefacts ... */
    hyphens: none;
    word-break: keep-all;
    overflow-wrap: normal;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
```

Current mobile breakpoint:
```css dashboard/styles.css:1894-1897
@media (max-width: 1024px) {
    .stat-card {
        min-width: 120px;
```

**Files touched:**
- Modified: `dashboard/styles.css` — three line edits + one comment block insertion.
- Modified: `tests/e2e/journey-sim-time-tile.spec.ts` — append two NEW `test(...)` blocks at the end of the existing `test.describe(...)`. Existing tests stay verbatim.
- DO NOT touch: `dashboard/index.html`, `dashboard/app.js`, anything in `docs/`. Those are out of Team A scope.

### CSS changes (exact edits)

1. **`dashboard/styles.css` line 783** (`.stat-card { ... min-width: 150px; ... }`):
   Change `min-width: 150px;` → `min-width: 184px;`

2. **`dashboard/styles.css` line 816** (`.stat-value { ... text-overflow: ellipsis; }`):
   Change `text-overflow: ellipsis;` → `text-overflow: clip;`

3. **`dashboard/styles.css` line 1896** (mobile `@media (max-width: 1024px) .stat-card { min-width: 120px; }`):
   Change `min-width: 120px;` → `min-width: 144px;`

4. **Insert comment block** immediately ABOVE the `.stat-value {` opening brace (between current line 799 and line 800). Exact text:

```css
/* Overview .stat-value content audit (bug-hunt refactor stat-card-overflow-contract,
   2026-05-05). At 20px mono bold, ~12px/char. Card content area at desktop = 184 −
   32 padding = 152px (~12.6 chars). Mobile @<=1024px = 144 − 32 = 112px (~7 chars at
   16px font). Each Overview tile's longest expected content string and its measured
   width:
     #sim-time:        "2025-12-31"      (10 chars,  ~120px) — fits desktop, fits mobile
     #portfolio-value: "$1,234,567.89"   (13 chars,  ~156px) — fits desktop;
                                           mobile @16px font ~108px fits 112px area
     #cash-value:      "$999,999.99"     (11 chars,  ~132px) — fits desktop;
                                           mobile @16px ~92px fits
     #total-pnl:       "+$12,345.67"     (11 chars,  ~132px) — fits both
     #total-return:    "+12.34%"         (7 chars,   ~84px)  — fits both
     #sharpe-ratio:    "1.234"           (5 chars,   ~60px)  — fits both
     #max-drawdown:    "-12.34%"         (7 chars,   ~84px)  — fits both
     #win-rate:        "55.5%"           (5 chars,   ~60px)  — fits both
   Mobile breakpoint sets `.stat-value { font-size: 16px }` further down in this file
   (~line 2058-2060) — confirm exact line during edit; that font-size scale-down is
   what makes the 13-char #portfolio-value content fit the 112px mobile area.
   If a future tile demands content >12 chars at desktop 20px, the new tile MUST lower
   its font-size at the per-id level (e.g. `#my-tile.stat-value { font-size: 16px }`);
   do NOT widen the card per-tile, that breaks grid uniformity.
   Test-enforced: tests/e2e/journey-sim-time-tile.spec.ts asserts scrollWidth <=
   clientWidth and computed text-overflow === 'clip' at 1024/1200/1440 viewport widths
   after a session is created and a fill lands. */
```

### New Playwright tests (append to journey-sim-time-tile.spec.ts)

Append BOTH of these `test(...)` blocks at the end of the existing `test.describe(...)` (i.e., immediately before the final closing `});` of the describe block). Existing tests must remain verbatim.

```typescript
  test('.stat-value tiles fit content at 1024/1200/1440 desktop viewports without ellipsis truncation', async ({ page }) => {
    // Stub session state with realistic content widths so every Overview tile
    // renders with non-placeholder content. Then sweep three desktop viewports
    // and assert every .stat-value satisfies scrollWidth <= clientWidth AND
    // computed text-overflow is 'clip' (not 'ellipsis').
    const FIXED_ISO = '2025-12-31T23:59:59Z';
    await page.route('**/v1/sessions/*/state', async (route) => {
      if (route.request().method() === 'GET') {
        await route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            session_id: 'overflow-fixture',
            clock: { current_time: FIXED_ISO, mode: 'frozen' },
            portfolio_metrics: {
              total_value: 1234567.89,
              cash: 999999.99,
              positions_value: 234567.90,
              total_pnl: 12345.67,
              total_pnl_pct: 12.34,
              day_pnl: 567.89,
              day_pnl_pct: 0.45,
              max_drawdown: -12.34,
              sharpe_ratio: 1.234,
            },
            positions: [],
            orders: [],
            trades: [],
            reasoning_log: [],
            equity_curve: [],
          }),
        });
        return;
      }
      await route.continue();
    });

    const viewports = [
      { width: 1024, height: 768, label: '1024' },
      { width: 1200, height: 800, label: '1200' },
      { width: 1440, height: 900, label: '1440' },
    ];

    for (const vp of viewports) {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await page.goto('/index.html');
      await page.waitForLoadState('domcontentloaded');

      // Force the dashboard to render with realistic content via the stubbed state.
      await page.evaluate((iso: string) => {
        // @ts-expect-error renderClock is a global on the dashboard page.
        window.renderClock({ current_time: iso, mode: 'frozen' });
      }, FIXED_ISO);

      // Allow any pending repaint to settle.
      await page.waitForTimeout(50);

      const tiles = page.locator('.stat-value');
      const count = await tiles.count();
      expect(count, `viewport ${vp.label}px: at least one .stat-value tile rendered`).toBeGreaterThanOrEqual(1);

      for (let i = 0; i < count; i++) {
        const tile = tiles.nth(i);
        const measure = await tile.evaluate((el) => {
          const cs = window.getComputedStyle(el);
          return {
            id: el.id,
            scrollWidth: (el as HTMLElement).scrollWidth,
            clientWidth: (el as HTMLElement).clientWidth,
            textOverflow: cs.textOverflow,
            text: el.textContent ?? '',
          };
        });
        expect(
          measure.scrollWidth <= measure.clientWidth,
          `viewport ${vp.label}px tile #${measure.id} ('${measure.text}') overflows: scrollWidth=${measure.scrollWidth} clientWidth=${measure.clientWidth}`
        ).toBe(true);
        expect(
          measure.textOverflow,
          `viewport ${vp.label}px tile #${measure.id}: text-overflow must be 'clip' not '${measure.textOverflow}'`
        ).toBe('clip');
      }
    }
  });

  test('.stat-card desktop min-width contract is 184px (matches audit-comment math)', async ({ page }) => {
    // Pin the .stat-card sizing rule. A regression that drops min-width back to
    // 150px would re-introduce the 1-2px overshoot that produced the patch-
    // ineffective signal in bug-hunt 20260505T175445Z750b.
    await page.setViewportSize({ width: 1280, height: 720 });
    await page.goto('/index.html');
    await page.waitForLoadState('domcontentloaded');

    const card = page.locator('.stat-card').first();
    const minWidthPx = await card.evaluate((el) => {
      return parseFloat(window.getComputedStyle(el).minWidth);
    });
    expect(minWidthPx).toBeGreaterThanOrEqual(184);
  });
```

### Validation (run before declaring DONE)

Run all three commands; ALL must pass:

1. **Targeted Playwright file (the one you modified):**
   ```bash
   cd /Users/justnau/finlet && npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-sim-time-tile.spec.ts
   ```
   Expect: 5 tests pass (existing 3 + new 2).

2. **Regression check on dashboard E2E:**
   ```bash
   cd /Users/justnau/finlet && npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-04-dashboard.spec.ts
   ```
   Expect: all pass. (KNOWN_FAILURES.md may already mark some as xfail; respect those.)

3. **Regression check on trade flow E2E:**
   ```bash
   cd /Users/justnau/finlet && npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-05-trade.spec.ts
   ```
   Expect: all pass.

If any assertion in command 1 fails, FIX before declaring DONE — debug by checking which `.stat-value` tile overshoots at which viewport and whether the audit comment's measurement is wrong vs the CSS constants are wrong. Do not declare DONE with a failing test.

### Commit + report

After validation passes:
```bash
git -C <your-worktree-path> add dashboard/styles.css tests/e2e/journey-sim-time-tile.spec.ts
git -C <your-worktree-path> commit -m "[Team A]: stat-card overflow contract — min-width 150→184px, text-overflow clip, viewport-asserting Playwright spec (refactor stat-card-overflow-contract)"
```

Report format:
```
DONE
commit_sha: <sha>
worktree_branch: <branch name from `git -C <wt> branch --show-current`>
worktree_path: <your worktree path>
validation:
  journey-sim-time-tile.spec.ts: <X passed / Y failed>
  journey-04-dashboard.spec.ts: <X passed / Y failed>
  journey-05-trade.spec.ts: <X passed / Y failed>
notes: <anything the orchestrator should know>
```

OR:
```
BLOCKED
reason: <what went wrong, what you tried, what's needed>
```

CRITICAL RULES:
- Read `docs/KNOWN_FAILURES.md` BEFORE running any test gate. Don't report known failures as regressions.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns in `tests/e2e/journey-sim-time-tile.spec.ts` for stubbing `**/v1/sessions/*/state`. Don't invent new stubbing convention.
- The audit comment in styles.css is the load-bearing line for future tile additions — keep it INSIDE the `.stat-value` block proximity (immediately ABOVE the `.stat-value {` opening brace).
- DO NOT modify existing tests in journey-sim-time-tile.spec.ts. Append new tests at the end of the existing `test.describe(...)`.
- DO NOT touch `dashboard/index.html`, `dashboard/app.js`, or anything in `docs/`.
- You MUST `git add` and `git commit` before finishing. Commit message must start with `[Team A]:`.
