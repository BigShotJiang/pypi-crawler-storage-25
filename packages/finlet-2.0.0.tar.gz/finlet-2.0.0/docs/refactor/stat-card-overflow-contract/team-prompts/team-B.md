You are Team B: decision record + ARCHITECTURE bullet + refactor-queue closeout + LESSONS for the `stat-card-overflow-contract` refactor.

This refactor closes a patch-ineffective signal from bug-hunt iteration `20260505T175445Z750b`. Team A has already merged the CSS contract change + extended Playwright spec. Your job: doc-only — capture the decision, append to the architecture rules, mark the refactor-queue doc shipped, and add the lesson to LESSONS.md.

SPAWN BASE SHA: `f1b3cf7e607198229cdf9de49bb63581c636470d` (the orchestrator pre-injected this — equals Team A's merge SHA on `main`). Your worktree was auto-reset to this SHA after spawn.

TEAM A MERGE SHA (for `shipped_in:` field): `f1b3cf7e607198229cdf9de49bb63581c636470d` (same as your spawn base).

**Blocked by:** Team A merged on main first (already done before you spawn).

**Read these files first** (do this BEFORE writing any docs):
- `docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md` (full doc) — you convert `status: ready → shipped` and add shipped/team timestamps.
- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` (lines 1-30, frontmatter only) — reference template for shipped-status frontmatter shape.
- `docs/ARCHITECTURE.md:1020-1032` (the no-hyphenation bullet at line 1025 plus surrounding bullets) — you append a NEW bullet AFTER the no-hyphenation bullet, NOT replacing it. Note the existing bullet's `text-overflow: ellipsis` recommendation and its "never reach for min-width" warning — your new bullet must explicitly note it supersedes both.
- `docs/decisions/dashboard-event-bus.md` OR any 1-page decision record in `docs/decisions/` — reference shape for the new decision record's structure.
- `docs/LESSONS.md` (top section / first ~40 lines) — find the right section header to append your new lesson under (likely "convention enforcement", "test-enforced contracts", or whichever section is closest).
- `docs/KNOWN_FAILURES.md` — do NOT report any test in here as a regression.

**Recon evidence (verified by recon agent against HEAD `98aced6`):**

Existing no-hyphenation bullet at `docs/ARCHITECTURE.md:1025`:
```markdown docs/ARCHITECTURE.md:1025
- **Defensive no-hyphenation contract on metric tile values (`dashboard/styles.css#.stat-value`, since 2026-05-03 bug-hunt `20260503T230405Z2601` Team A, commit `828003d`)** — every dashboard metric tile that renders ASCII text (datetime, ID, ticker, formatted number) into a fixed-width cell MUST pin the four-property contract: `hyphens: none; word-break: keep-all; overflow-wrap: normal; white-space: nowrap;`. ... Pair with `overflow: hidden; text-overflow: ellipsis;` for graceful narrow-viewport degradation; never reach for `min-width` because that breaks the existing flex-grow layout. ...
```

This bullet's `text-overflow: ellipsis` advice and `never reach for min-width` warning are SUPERSEDED by the new bullet you'll append. The text-overflow change (`ellipsis → clip`) and min-width bump (150→184px desktop / 120→144px mobile) ARE the refactor.

**Files touched:**

1. **NEW:** `docs/decisions/stat-card-overflow-contract.md` — 1-page decision record.
2. **Modified:** `docs/ARCHITECTURE.md` — append ONE new bullet after line 1025's no-hyphenation bullet.
3. **Modified:** `docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md` — frontmatter only: status ready→shipped, add shipped_at/shipped_in/team_a_commit/team_b_commit fields.
4. **Modified:** `docs/LESSONS.md` — append ONE new lesson at the top of the appropriate section.

DO NOT modify Team A's files (`dashboard/styles.css`, `tests/e2e/journey-sim-time-tile.spec.ts`).

### 1. Decision record (NEW: `docs/decisions/stat-card-overflow-contract.md`)

Required structure (≤80 lines total; aim for ~60):

```markdown
---
decision_at: 2026-05-05
category: dashboard-state-sync
supersedes_advice_in: docs/ARCHITECTURE.md:1025 (no-hyphenation bullet — text-overflow:ellipsis recommendation, never-min-width warning)
surfaced_by: bug-hunt 20260505T175445Z750b patch-ineffective signal `sim-time-card-truncates-with-ellipsis`
related_refactor_doc: docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md
shipped_in: f1b3cf7e607198229cdf9de49bb63581c636470d
---

# Decision: Stat-Card Overflow Contract

## Decision

Overview `.stat-card` and `.stat-value` adopt a hard-fitting size contract:
- `.stat-card { min-width: 184px }` at desktop (`@media (min-width: 1025px)`)
- `.stat-card { min-width: 144px }` at mobile (`@media (max-width: 1024px)`)
- `.stat-value { text-overflow: clip }` (was `ellipsis`)
- Test-enforced: `tests/e2e/journey-sim-time-tile.spec.ts` asserts `scrollWidth <= clientWidth` AND `getComputedStyle().textOverflow === 'clip'` at 1024/1200/1440 viewport widths after a session is created and a fill lands.

## Why

Two prior patches (CSS-only iter `20260503T230405Z2601`, JS-only iter `20260505T175445Z750b`) failed to close the SIM TIME card truncation cluster. The 150px min-width × 32px padding = 118px content area was 1-2px too narrow for `2025-05-05` rendered at 20px mono bold (~120px). The previous `text-overflow: ellipsis` fallback turned a 1-2px overshoot into a deceptive `…` glyph that hid the actual value from the user. Hard-cutoff (`clip`) is louder than deceptive truncation: a regression that overshoots the test assertion fails loudly, not silently.

## Contract

Two invariants enforced by `tests/e2e/journey-sim-time-tile.spec.ts`:
1. **Every `.stat-value` element on the dashboard fits its content** at desktop viewports (1024px / 1200px / 1440px). `scrollWidth <= clientWidth`. No silent truncation.
2. **Computed `text-overflow` is always `'clip'`**. A regression to `'ellipsis'` would re-introduce the deceptive-truncation failure mode this refactor closes.

## How to add a new stat-card

1. Pick the longest realistic content string the tile will ever render. Measure (or estimate) its width at 20px mono bold (~12px/char).
2. **If it fits within ~150px (i.e., ≤12 characters):** use `.stat-value` directly. The existing `min-width: 184px` + 32px padding + ~12.6 character headroom accommodates it.
3. **If it's longer than ~12 characters:** add a per-id font-size override at 16px (e.g., `#my-tile.stat-value { font-size: 16px }`). Do NOT widen the card per-tile — that breaks the grid uniformity and makes the audit-comment math wrong.
4. Update the audit comment in `dashboard/styles.css` immediately above `.stat-value {` with the new tile's expected content and measurement.
5. Add the new tile to the Playwright stub in `tests/e2e/journey-sim-time-tile.spec.ts` (the `portfolio_metrics` fixture in the viewport-sweep test) so the contract test exercises realistic content for it.

## Validation

The refactor passes if and only if:
- New Playwright spec passes at 1024/1200/1440 viewports.
- Existing `journey-sim-time-tile.spec.ts` em-dash regression test still passes.
- Visual check on `https://finlet.dev/index.html` post-deploy: SIM TIME card shows the full date, no `…`, no glyph cutoff.

## Failure mode this closes

A user views the dashboard. The SIM TIME card silently shows `2025-05-…` with a CSS-painted ellipsis that the user assumes is the actual value. The user has no way to know they're being lied to without hovering for the title-attribute tooltip. With `text-overflow: clip` and the test-enforced `scrollWidth <= clientWidth` invariant, this failure mode is impossible: any tile that overshoots fails the test at CI time, before reaching prod; if a tile DOES overshoot in prod, the user sees a hard cutoff that's a visible bug, not a silent lie.
```

### 2. ARCHITECTURE.md bullet (append AFTER the no-hyphenation bullet at line 1025)

Append immediately after the existing bullet (so it appears as the next list item). Exact text to append:

```markdown
- **Test-enforced overflow contract on stat-card tiles (`dashboard/styles.css#.stat-card`, `dashboard/styles.css#.stat-value`, since 2026-05-05 refactor `stat-card-overflow-contract`, commits `f1b3cf7e607198229cdf9de49bb63581c636470d` + `<TEAM_B_MERGE_SHA>`)** — Overview tile cards size to 184px desktop / 144px mobile, with `text-overflow: clip` (was `ellipsis`). The four no-hyphenation properties from the prior bullet remain load-bearing; the overflow safety-net changes from "deceptive ellipsis" to "hard cutoff" so a sizing regression fails loudly instead of silently. The overflow contract is enforced by `tests/e2e/journey-sim-time-tile.spec.ts`: every `.stat-value` on the dashboard must satisfy `scrollWidth <= clientWidth` AND `getComputedStyle().textOverflow === 'clip'` at 1024/1200/1440 viewport widths after a session is created and a fill lands. **Supersedes** the prior bullet's `text-overflow: ellipsis` recommendation and `never reach for min-width` warning — patch-ineffective evidence from bug-hunt `20260505T175445Z750b` showed both pieces of advice, applied uniformly, produced silent truncation at 1-2px overshoot. Convention for adding new tiles: if content fits within ~12 characters at 20px mono bold, use `.stat-value` directly; if longer, lower the per-id font-size (e.g., `#my-tile.stat-value { font-size: 16px }`) — do NOT widen the card per-tile, that breaks grid uniformity. Decision record: `docs/decisions/stat-card-overflow-contract.md`.
```

After your commit, you'll know your own merge SHA — leave `<TEAM_B_MERGE_SHA>` as the literal placeholder in YOUR commit; the orchestrator will not patch it. (The bullet is still complete and parsable; the orchestrator can rewrite the placeholder later if needed, but it's not a blocker.)

### 3. Refactor-queue doc closeout

Modify `docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md` frontmatter ONLY. Body content stays unchanged.

Change the frontmatter from:
```yaml
status: ready
category: dashboard-state-sync
drafted: 2026-05-05
drafted_in: bug-hunt-gate-trip-20260505T175445Z750b-pending-recurrence
trigger: patch-ineffective + forward-signal
instances: 2
iterations: [20260503T230405Z2601, 20260505T175445Z750b]
related_ledger_entries: [sim-time-tile-em-dash-artefact, sim-time-card-truncates-with-ellipsis]
prior_patches:
  ...
deploy_blocked: false
break_even: ...
```

To (preserve everything; add new shipped fields, change status):
```yaml
status: shipped
shipped_at: 2026-05-05
shipped_in: f1b3cf7e607198229cdf9de49bb63581c636470d
team_a_commit: f1b3cf7e607198229cdf9de49bb63581c636470d
team_b_commit: <will-be-this-commit-once-it-lands; safe to leave as TBD or fill at commit-time>
category: dashboard-state-sync
drafted: 2026-05-05
drafted_in: bug-hunt-gate-trip-20260505T175445Z750b-pending-recurrence
trigger: patch-ineffective + forward-signal
instances: 2
iterations: [20260503T230405Z2601, 20260505T175445Z750b]
related_ledger_entries: [sim-time-tile-em-dash-artefact, sim-time-card-truncates-with-ellipsis]
prior_patches:
  ...
deploy_blocked: false
break_even: ...
```

DO NOT add a `verdict:` field — verdict is set NEXT bug-hunt iteration after Phase 5.5 retest evaluates the deployed change.

### 4. LESSONS.md append

Find the most appropriate top-level section in `docs/LESSONS.md` (likely "convention enforcement", "test-enforced contracts", or "patch-ineffective signals"). Append ONE new lesson at the TOP of that section. Exact text:

```markdown
**[2026-05-05] When a CSS rule pairs an overflow fallback with a sizing predicate that's known to silently overshoot, the fallback IS the bug.** Two consecutive patches in the SIM TIME tile cluster (CSS-only iter `20260503T230405Z2601` to fix em-dash artefacts; JS-only iter `20260505T175445Z750b` to shorten the rendered string) both relied on `.stat-value { text-overflow: ellipsis }` as a "safety net". The safety net was the bug — a 1-2px overshoot at the realistic content width painted `…` and hid the truth from the user. **Lesson:** when a CSS surface ships with a "safety net that hides truth," prefer hard-cutoff failure modes (`text-overflow: clip`) over deceptive ones (`ellipsis`). And test-enforce the sizing predicate at the viewport widths users actually use (1024/1200/1440 desktop) — `scrollWidth <= clientWidth` is the only reliable invariant for "this tile is sized to its content." Surfaced by bug-hunt `20260505T175445Z750b` patch-ineffective signal; closed by refactor `stat-card-overflow-contract` (commits `f1b3cf7e607198229cdf9de49bb63581c636470d` + `<TEAM_B_MERGE_SHA>`).
```

### Validation (run before declaring DONE)

```bash
# 1. Decision record exists and is well-formed.
ls -la docs/decisions/stat-card-overflow-contract.md
wc -l docs/decisions/stat-card-overflow-contract.md  # expect ≤ 80

# 2. ARCHITECTURE bullet appended.
grep -c "stat-card overflow contract" docs/ARCHITECTURE.md  # expect 1

# 3. Refactor-queue doc is shipped.
grep "^status: shipped$" docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md  # expect match
grep "^shipped_in:" docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md  # expect match with non-placeholder SHA

# 4. LESSONS lesson appended.
head -100 docs/LESSONS.md | grep -c "stat-card-overflow-contract\|sim-time-card-truncates"  # expect ≥ 1
```

### Commit + report

After all four file changes:
```bash
cd $(git rev-parse --show-toplevel)
git add docs/decisions/stat-card-overflow-contract.md docs/ARCHITECTURE.md docs/bug-hunt/refactor-queue/stat-card-overflow-contract.md docs/LESSONS.md
git commit -m "[Team B]: stat-card overflow contract refactor — decision record, ARCHITECTURE bullet, LESSONS, refactor-queue shipped (refactor stat-card-overflow-contract)"
```

Report:
```
DONE
commit_sha: <sha>
worktree_branch: <branch>
worktree_path: <pwd>
validation:
  decision_record_lines: <N>
  architecture_bullet_count: <should be 1>
  refactor_queue_status: shipped
  lessons_added: 1
notes: <anything>
```

OR `BLOCKED` + reason.

CRITICAL RULES:
- DO NOT modify any file under `dashboard/` or `tests/`.
- DO NOT add a `verdict:` field to the refactor-queue doc — that comes next iteration.
- The decision record's "How to add a new stat-card" section is load-bearing — keep it concrete and actionable.
- You MUST `git add` and `git commit` before finishing. Commit must start with `[Team B]:`.
