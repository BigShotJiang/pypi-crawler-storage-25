You are Team A: password-form-aria residual + pending_recurrences migration.

## Plan reference
Spawn-base SHA: `09043faf1ea620ba2437cff55f69652a79937be7`. Read your full team spec at `/Users/justnau/finlet/docs/refactor/convention-enforcement-2026-05-05/plan.md` (search for "### Team A:"). The plan contains your "Read these files first" list, recon evidence, files-touched, deliverable, validation, and agent instructions.

You are working in a git worktree forked from `09043fa`. Your branch is the worktree's auto-created branch.

## Critical rules
- Read `docs/KNOWN_FAILURES.md` first — do NOT report those as issues. The 1 Playwright failure listed there (journey-06-settings.spec.ts:714 modal close-after-submit) is pre-existing and out of your scope.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns. The plugin-card hidden-username-peer pattern is the reference (commit `b08ddb8`). Run `git show b08ddb8 -- dashboard/settings.html dashboard/settings.js` to see the exact attributes.
- You MUST `git add` and `git commit` all your changes before finishing. Worktree work is lost on cleanup if uncommitted.
- Your commit message must start with `[Team A]:`. Suggested full message: `[Team A]: hidden username peer for delete-account-form (close password-form-aria residual + migrate legacy pending_recurrences entry)`.
- Run validation commands from your spec before finishing.
- If validation fails, fix the issue and re-commit (separate commit is fine; squash isn't required).

## Your scope (verbatim from plan.md, do NOT improvise beyond this)

### Files to modify
1. **`dashboard/settings.html`** — insert hidden username peer immediately after `<form id="delete-account-form" onsubmit="return false;" autocomplete="off">` opening tag at line 559. The peer must have these exact attributes:
   ```html
   <input type="text" id="delete-account-username-peer"
          name="username" hidden autocomplete="username"
          readonly tabindex="-1" aria-hidden="true" value="">
   ```
   Place it BEFORE the first `<div class="form-group">` (which is at line 560). Use 4-space indentation matching the surrounding `<form>` content.

2. **`dashboard/settings.js`** — locate the function that opens `#delete-account-modal`. Search for `delete-account-modal`, `openDeleteAccountModal`, or click handlers on `#delete-account-btn`. At the point the modal becomes visible, set `document.getElementById('delete-account-username-peer').value = currentUserEmail` IF a user-email value is reachable in client state (look for `currentUser`, `userEmail`, or similar). If no email is reachable, leave the peer's static `value=""` from HTML — the heuristic still passes. Do NOT introduce a new abstraction or refactor the modal-open code path.

3. **`tests/e2e/journey-06-settings.spec.ts`** — extend the existing console-warning assertion to cover the delete-account modal. Find the existing assertion that checks for zero `Password forms should have ... username fields` warnings on settings cold-load. After that block, add:
   - Click whatever opens `#delete-account-modal` (likely `#delete-account-btn` or text "Delete Account").
   - Wait for the modal: `await page.waitForSelector('#delete-account-modal:not([style*="display: none"])');` — adapt selector if the modal id differs.
   - Re-read accumulated console messages from the same listener; assert zero matches for `/Password forms should have .* username fields/`.
   - Click the cancel button (`#delete-cancel-btn` per the markup) to close the modal so the test cleanly tears down.
   Make the new assertion resilient to the modal not existing (skip-if-missing) — the test should not regress journey-06 even if the modal markup changes name.

4. **`docs/bug-hunt/pending_recurrences.jsonl`** — remove the single legacy-schema line. The file should become empty (0 lines, but not deleted — leave it as a 0-byte file).

5. **`docs/bug-hunt/pending_recurrences.resolved.jsonl`** — append a migrated entry per the schema in the plan. Use `pending-deploy` as the `deploy_sha` placeholder; Team C updates it post-deploy. Use this exact JSON line (single line, no pretty-printing):
   ```json
   {"patch_iteration_ts":"20260503T230405Z2601","finding_id":"settings-password-form-aria-residual-delete-account","category":"password-form-aria","retest_kind":"playwright","deploy_sha":"pending-deploy","evidence":"Original blind walk counted 9 password-form-aria warnings; iter 20260503 commit b08ddb8 closed 8 (plugin cards); residual 2 from #delete-account-form modal closed by this refactor. Same hidden-username-peer pattern replicated to settings.html line 559 (inside the form, before first form-group).","scope_files":"dashboard/settings.html, dashboard/settings.js","resolved_by":"convention-enforcement-2026-05-05.md (Team A)","resolved_at_ts":"convention-enforcement-2026-05-05","resolved_at_date":"2026-05-05","resolved_note":"Schema migration: original entry used legacy {iteration, team, bug, reason} keys; this entry restates with current spec schema."}
   ```

### Validation (run these before finishing; report results in your DONE message)
- [ ] `bash scripts/lint-trusted-types.sh --check` — exit 0
- [ ] `wc -l docs/bug-hunt/pending_recurrences.jsonl` — reports 0 (or empty file)
- [ ] `tail -1 docs/bug-hunt/pending_recurrences.resolved.jsonl | jq '.category'` — returns `"password-form-aria"`
- [ ] `grep -c "delete-account-username-peer" dashboard/settings.html` — returns 1
- [ ] `grep -c "delete-account-username-peer" dashboard/settings.js` — returns 1 (the value-set call) or 0 (if no email reachable)
- [ ] Optional (slow): `npx playwright test --config=tests/e2e/playwright.config.ts tests/e2e/journey-06-settings.spec.ts --reporter=line --timeout=60000` — passes or skips. If it fails on something OTHER than your new assertion, that's a pre-existing flake (note in DONE message but don't block).

## Out of scope
- Do not modify the visible password input or confirmation text input markup.
- Do not change CSS styling of the modal.
- Do not refactor the modal-open code path (just add the value-set line).
- Do not touch any file outside the 5 listed above.

## When done, report:
```
DONE
commit_sha: <your final commit SHA>
files_changed: <list>
validation_results:
  lint-trusted-types: <pass/fail>
  pending_recurrences_lines: <number>
  resolved_jsonl_last_category: <value>
  settings_html_peer_count: <number>
  settings_js_peer_count: <number>
  e2e_run: <pass/skip/fail/not-run + brief>
notes: <any caveats>
```

OR if blocked:
```
BLOCKED
reason: <what went wrong>
attempted: <what you tried>
suggestion: <how to proceed>
```
