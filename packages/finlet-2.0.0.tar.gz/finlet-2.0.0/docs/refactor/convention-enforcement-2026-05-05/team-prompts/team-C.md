You are Team C: Verdict refresh + pending_recurrences pruning.

## Plan reference
Spawn-base SHA: `beb37afcc1affd7f89fac07eee7e7012729646fd` (post-merge of Team A and Team B). Read your full team spec at `/Users/justnau/finlet/docs/refactor/convention-enforcement-2026-05-05/plan.md` (search for "### Team C:"). The plan contains your "Read these files first" list, recon evidence, files-touched, deliverable, validation, and agent instructions.

You are working in a git worktree forked from `beb37af`. Your branch is the worktree's auto-created branch.

## Critical rules
- Read `docs/KNOWN_FAILURES.md` first — do NOT report those as issues.
- Read the "Read these files first" list BEFORE writing any code:
  - `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` (full file, ~115 lines) — current verdict state and the `verdict_v2: effective` precedent.
  - `docs/bug-hunt/refactor-queue/onboarding-checklist.md` — current verdict state.
  - `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` — current verdict state and the v3.1 inline-patch context.
  - `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md` — current verdict state.
  - `docs/bug-hunt/pending_recurrences.resolved.jsonl` — verify each refactor's targeted findings are already there with `resolved_by` reference.
  - `.claude/skills/bug-hunt/SKILL.md` — Phase 6 sub-sections "Refactor outcome tracking" and "Pending-recurrences pruning" — this team applies that contract.
  - `dashboard/onboarding.js:380-395` — closed reach-ins (load-bearing for onboarding-checklist verdict_v2 evidence).
  - `dashboard/form-dirty-tracker.js:240-267` — v3 setFieldDirty guard (load-bearing for dirty-state-tracker verdict_v3 evidence).
- You MUST `git add` and `git commit` all your changes before finishing. Worktree work is lost on cleanup if uncommitted.
- Your commit message must start with `[Team C]:`. Suggested: `[Team C]: refresh verdicts on 4 shipped refactors + prune pending_recurrences + backfill deploy_sha`.
- Run validation commands from your spec before finishing.
- If validation fails, fix the issue and re-commit.

## Your scope (verbatim from plan.md)

### Files to modify

1. **`docs/bug-hunt/refactor-queue/dirty-state-tracker.md`** — append `verdict_v3: effective` block to frontmatter (between existing `verdict_v2_evidence` line and closing `---`). Evidence cites the ledger gap since `20260501T234103Z1a49` (commit `87a37b6`) and the in-code state of `dashboard/form-dirty-tracker.js:259-267`.

2. **`docs/bug-hunt/refactor-queue/onboarding-checklist.md`** — append `verdict_v2: effective` block. Evidence cites the ledger gap since `20260501T234103Z1a49` (commit `4924948`) and the in-code comment at `dashboard/onboarding.js:383-389`.

3. **`docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md`** — append `verdict_v3_1: effective` block. Evidence cites the ledger gap since `20260503T030227Z2009` (commit `8c55a90`, the v3.1 patch) and the resolved.jsonl entry that v3.1 closed.

4. **`docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md`** — append `verdict_v2: effective` block. Evidence cites the three resolved.jsonl entries (profile-checklist, settings-dirty-banner, edgar-plugin) and the absence of recurrence in the ledger since 2026-05-02.

5. **`docs/bug-hunt/pending_recurrences.jsonl`** — apply the per-spec pruning recipe for each newly-effective category. Most categories' pending entries are already in `resolved.jsonl`; the pruning will likely no-op. Run pruning for `dirty-state-tracker`, `onboarding-checklist`, `dashboard-state-sync` (filtered to trade-ticket entries via `scope_files` text), and any close-patch-ineffective categories. Use the exact `jq` invocation from `bug-hunt/SKILL.md` Phase 6.

6. **`docs/bug-hunt/pending_recurrences.resolved.jsonl`** — append any pruned entries with proper `resolved_by` references. Update Team A's migrated entry's `deploy_sha` from `pending-deploy` to the actual merge SHA from the deploy verification step IF the deploy is complete; otherwise leave `pending-deploy` and the orchestrator backfills.

### Verdict block format (exact YAML, mirror existing convention from `dirty-state-tracker.md`)

```yaml
verdict_vN: effective
verdict_vN_set_at: 2026-05-05
verdict_vN_set_in: convention-enforcement-2026-05-05
verdict_vN_evidence: "<2-3 sentences with finding_id + commit SHA + ledger gap evidence>"
```

`vN` is the next version after the most recent `verdict_*` field:
- `dirty-state-tracker.md` → `verdict_v3` (after `verdict_v2`)
- `onboarding-checklist.md` → `verdict_v2`
- `trade-ticket-state-sync-v3.md` → `verdict_v3_1`
- `close-patch-ineffective-2026-05-02.md` → `verdict_v2`

Do NOT delete or modify existing `verdict_*` fields. Only ADD new ones.

### Validation (run these before finishing; report results in your DONE message)

- [ ] Each of the 4 queue docs has a NEW verdict block at the END of its frontmatter (preserving prior verdict blocks).
- [ ] Each new verdict block cites at least one finding_id AND one commit SHA.
- [ ] `wc -l docs/bug-hunt/pending_recurrences.jsonl` is 0 (Team A removed the legacy entry; C's pruning does not add new entries to live).
- [ ] `jq -c '.' docs/bug-hunt/pending_recurrences.resolved.jsonl` parses every line cleanly.
- [ ] No regression in any queue doc's existing verdicts: `git diff origin/main -- docs/bug-hunt/refactor-queue/*.md` should show only ADDITIONS, not deletions of prior `verdict_*` keys.

### Special considerations

- The deploy SHA backfill: Team A's migrated resolved.jsonl entry has `"deploy_sha":"pending-deploy"`. If you can determine the actual deploy SHA via `gh run list --workflow="Deploy Finlet" --branch main --limit 1 --json conclusion,headSha`, update it. If deploy is in-flight or hasn't started yet, leave `pending-deploy` — the orchestrator will backfill post-deploy.
- Pruning recipe must be the exact one from SKILL.md Phase 6. Do not invent your own jq command.
- Each verdict block must have evidence text that includes (a) at least one finding_id from the ledger, (b) at least one commit SHA, and (c) ledger-gap reasoning ("no entries in the ledger after iteration X" or equivalent).

## Out of scope

- Don't modify the convention-enforcement-2026-05-05 refactor doc itself — orchestrator marks it `status: shipped` post-deploy.
- Don't touch the ledger.jsonl — verdicts go in queue docs, not the ledger.
- Don't refactor any code under `dashboard/` — this is a docs-only team.
- Don't backfill verdicts on refactor-queue docs not listed (Team C scope is the 4 named docs only).

## When done, report:
```
DONE
commit_sha: <your final commit SHA>
files_changed: <list>
validation_results:
  dirty_state_tracker_verdict_v3_added: <pass/fail>
  onboarding_checklist_verdict_v2_added: <pass/fail>
  trade_ticket_v3_1_added: <pass/fail>
  close_patch_ineffective_v2_added: <pass/fail>
  pending_recurrences_lines: <number>
  resolved_jsonl_parses_clean: <pass/fail>
  no_verdict_regressions: <pass/fail>
  deploy_sha_backfilled: <yes/no/in-flight>
notes: <any caveats>
```

OR if blocked:
```
BLOCKED
reason: <what went wrong>
attempted: <what you tried>
suggestion: <how to proceed>
```
