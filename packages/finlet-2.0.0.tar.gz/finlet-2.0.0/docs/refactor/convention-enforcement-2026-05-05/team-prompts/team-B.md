You are Team B: Event-bus lint guard + pre-commit wiring.

## Plan reference
Spawn-base SHA: `09043faf1ea620ba2437cff55f69652a79937be7`. Read your full team spec at `/Users/justnau/finlet/docs/refactor/convention-enforcement-2026-05-05/plan.md` (search for "### Team B:"). The plan contains your "Read these files first" list, recon evidence, files-touched, deliverable, validation, and agent instructions.

You are working in a git worktree forked from `09043fa`. Your branch is the worktree's auto-created branch.

## Critical rules
- Read `docs/KNOWN_FAILURES.md` first — do NOT report those as issues.
- Read the "Read these files first" list BEFORE writing any code:
  - `scripts/lint-trusted-types.sh` (full file) — your new script MUST mirror its shape.
  - `scripts/git-hooks/pre-commit` (full file, ~57 lines) — current invocation chain.
  - `dashboard/event-bus.js` — confirm the bus exposes `subscribe`, `publish`, `getLastPublished` and is the ONLY legitimate site for direct dispatch.
  - `docs/decisions/dashboard-event-bus.md` — current decision record; you'll add an Enforcement section.
- You MUST `git add` and `git commit` all your changes before finishing. Worktree work is lost on cleanup if uncommitted.
- Your commit message must start with `[Team B]:`. Suggested: `[Team B]: lint-event-bus.sh + pre-commit chain (codify dashboard-event-bus convention)`.
- Run validation commands from your spec before finishing.
- If validation fails, fix the issue and re-commit.

## Your scope (verbatim from plan.md)

### Files to create / modify

1. **NEW `scripts/lint-event-bus.sh`** — bash script that scans `dashboard/*.js` for direct event-bus bypass. Mirror the shape of `scripts/lint-trusted-types.sh` exactly:
   - Header doc-comment with sections: "What it scans", "Why", "Matching strategy", "Allowlist", "Usage", "Pre-commit hook install"
   - `set -uo pipefail` near the top
   - Resolve `SCRIPT_DIR`, `REPO_ROOT`, `DASH_DIR` the same way
   - `--check` flag handling for CI mode
   - `ALLOWLIST_MARKER='finlet-bus-lint-allowlist'`
   - File exclusions:
     - `dashboard/event-bus.js` itself (the bus's own implementation)
     - `dashboard/vendor/**` (third-party)
     - The lint script itself
   - Patterns to detect (use grep -E or awk; mirror trusted-types' style):
     - `addEventListener\s*\(\s*['"]finlet:`
     - `dispatchEvent\s*\(\s*new\s+CustomEvent\s*\(\s*['"]finlet:`
   - On violation: print `<file>:<line>: <line content>` and exit 1.
   - On clean: exit 0. In `--check` mode, terse output (just exit code matters).
   - File extension scope: `.js` AND `.html` files (inline `<script>` blocks may also dispatch — match trusted-types' approach to HTML files).

   Length target: 120-180 lines including header. Don't add new behaviors beyond the two grep patterns + exclusions.

2. **MODIFY `scripts/git-hooks/pre-commit`** — chain a second lint after the existing trusted-types invocation. Both must pass. Pattern:
   ```bash
   # ... existing trusted-types lint ...
   bash "$LINT_SCRIPT" --check
   status_tt=$?
   if (( status_tt != 0 )); then
       echo "" >&2
       echo "pre-commit: trusted-types lint failed. Run \`bash scripts/lint-trusted-types.sh\` for the full message." >&2
       exit "$status_tt"
   fi

   # NEW: event-bus lint
   LINT_BUS="$HOOK_DIR/../lint-event-bus.sh"
   if [[ ! -f "$LINT_BUS" ]]; then
       REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
       if [[ -n "$REPO_ROOT" ]] && [[ -f "$REPO_ROOT/scripts/lint-event-bus.sh" ]]; then
           LINT_BUS="$REPO_ROOT/scripts/lint-event-bus.sh"
       fi
   fi

   if [[ ! -f "$LINT_BUS" ]]; then
       echo "pre-commit: cannot locate scripts/lint-event-bus.sh — skipping event-bus lint" >&2
   else
       bash "$LINT_BUS" --check
       status_eb=$?
       if (( status_eb != 0 )); then
           echo "" >&2
           echo "pre-commit: event-bus lint failed. Run \`bash scripts/lint-event-bus.sh\` for the full message." >&2
           exit "$status_eb"
       fi
   fi

   exit 0
   ```
   Adapt this template to match the actual current pre-commit shape — DO NOT replace whole-file; insert the new block AFTER the trusted-types block and BEFORE the final `exit 0`. Preserve symlink-resolution semantics, the fallback via `git rev-parse --show-toplevel`, and the structured error messages.

3. **MODIFY `docs/decisions/dashboard-event-bus.md`** — add an "Enforcement" section. 5-10 lines max. Note that `scripts/lint-event-bus.sh` is the pre-commit guard. Cross-link to `scripts/lint-trusted-types.sh` as the sibling guard. Place the section after the existing convention statement, before any implementation notes (or at the end if structure allows). Don't rewrite the existing decision.

4. **MODIFY `docs/ARCHITECTURE.md`** — IF a "Lint guards", "Conventions", or similar section exists, add a one-line reference to event-bus lint alongside trusted-types. SKIP if no such section exists — don't invent a new section just for this. Use `grep -i "lint\|convention" docs/ARCHITECTURE.md` to check.

### Validation (run these before finishing; report results in your DONE message)
- [ ] `bash scripts/lint-event-bus.sh` exits 0 on the worktree state (zero violations on current main).
- [ ] `bash scripts/lint-event-bus.sh --check` exits 0.
- [ ] `bash scripts/lint-trusted-types.sh --check` still exits 0 (no regression).
- [ ] Synthetic violation test: temporarily create `/tmp/test-violation.js` with `window.addEventListener('finlet:foo', () => {})` and pass it via stdin or arguments to a local-only invocation; verify the script flags it. Then DELETE `/tmp/test-violation.js`. Don't commit any test-violation file.
- [ ] `bash scripts/setup-git-hooks.sh` re-runs cleanly without errors.
- [ ] `chmod +x` is set on the new script (run `chmod +x scripts/lint-event-bus.sh` and verify with `ls -l scripts/lint-event-bus.sh` showing `-rwxr-xr-x` or similar).

### Special considerations
- The current codebase has ZERO violations of this convention (verified by recon). Your script must NOT introduce false positives. Run it and confirm the exit-0 baseline before submitting.
- Mirror trusted-types' allowlist marker behavior: if a file contains `finlet-bus-lint-allowlist` (anywhere), exempt it. There are no expected exemptions today.
- Do NOT add the lint script to `package.json` or any other tooling chain — Finlet has no JS build step.
- HTML files: inline `<script>` blocks MAY contain bus calls. The trusted-types script handles HTML by scanning all of the file (not just script blocks); if you want script-block-only scanning, copy that approach. If easier, just scan the entire HTML file for the patterns — false positives in HTML attribute contexts are vanishingly rare for these specific patterns.

## Out of scope
- Don't modify event-bus.js or any dashboard/*.js consumer.
- Don't add new bus methods or change bus semantics.
- Don't add a `--fix` mode (the script is detect-only).
- Don't pre-commit-hook into running the full e2e suite or anything else; just the two lint scripts.

## When done, report:
```
DONE
commit_sha: <your final commit SHA>
files_changed: <list>
validation_results:
  lint_event_bus_clean: <pass/fail>
  lint_event_bus_check_mode: <pass/fail>
  lint_trusted_types_no_regression: <pass/fail>
  synthetic_violation_test: <pass/fail>
  setup_git_hooks_reruns: <pass/fail>
  chmod_x_set: <pass/fail>
new_script_loc: <line count of scripts/lint-event-bus.sh>
notes: <any caveats>
```

OR if blocked:
```
BLOCKED
reason: <what went wrong>
attempted: <what you tried>
suggestion: <how to proceed>
```
