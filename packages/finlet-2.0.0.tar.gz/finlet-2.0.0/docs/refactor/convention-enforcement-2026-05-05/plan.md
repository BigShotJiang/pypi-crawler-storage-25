# Convention Enforcement (2026-05-05) — Execution Plan

> Generated from `docs/bug-hunt/refactor-queue/convention-enforcement-2026-05-05.md`. Last updated: 2026-05-05. Iteration baseline SHA: `d159572c461f3501a5e83ef13ef5c4366f17c763`.

## Constraints

- **Pre-launch state.** Closed-source repo; the operational invariant is finlet.dev must stay green.
- **No build step.** Dashboard is vanilla HTML/JS/CSS. No new tooling chains, frameworks, or transpilation.
- **Pre-commit hook is symlink-driven.** Source files in `scripts/git-hooks/` are symlinked into `.git/hooks/` by `scripts/setup-git-hooks.sh`. Updates to source files take effect on next commit without re-running the installer.
- **Worktree-isolated agents.** Each team gets its own worktree. Workers must `git add` + `git commit` before finishing or work is lost on cleanup.
- **PF-18 enforced.** Every "current state" claim about file:line behavior in this plan is backed by either a quoted excerpt at HEAD or a `(verified by recon agent against HEAD d159572)` paraphrase.

## Execution Summary

All three teams COMPLETED on 2026-05-05.

| Team | Worktree commit | Merge commit |
|------|-----------------|--------------|
| A    | `b6e46aa0c2bdcb87a0764d2f7efaff1427298555` | (direct to main, no merge commit) |
| B    | `ac022f111306b8340dbe07dd9c4e77999f6755e4` | `beb37afcc1affd7f89fac07eee7e7012729646fd` |
| C    | `4a115732453799b000dad9ca9479d4b87f167583` | `7d840a74bafd450aeb4a45738aee550e562b2816` |

- Full pytest suite: 3980 passed (no failures), ~342s.
- `ruff check` clean post-merge — no fixup commit needed.
- KNOWN_FAILURES.md xfails tolerated.

## File Conflict Table

| File | Touched by Teams |
|------|------------------|
| `dashboard/settings.html` | A |
| `dashboard/settings.js` | A |
| `tests/e2e/journey-06-settings.spec.ts` | A |
| `docs/bug-hunt/pending_recurrences.jsonl` | A, C (sequential — A migrates legacy entry, C runs pruning) |
| `docs/bug-hunt/pending_recurrences.resolved.jsonl` | A, C (sequential — A appends migrated entry, C appends pruning entries) |
| `scripts/lint-event-bus.sh` | B (NEW file) |
| `scripts/git-hooks/pre-commit` | B |
| `docs/decisions/dashboard-event-bus.md` | B |
| `docs/ARCHITECTURE.md` | B |
| `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` | C |
| `docs/bug-hunt/refactor-queue/onboarding-checklist.md` | C |
| `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` | C |
| `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md` | C |

**Two-file shared overlap:** `pending_recurrences.jsonl` and `pending_recurrences.resolved.jsonl` are touched by both A and C. Sequencing: **A merges first, C merges after.**

## Dependency Graph

- **Team A** — independent. Can start immediately.
- **Team B** — independent. Can start immediately.
- **Team C** — blocked by A on the two `pending_recurrences*.jsonl` files. C must rebase onto post-A `main` before merging.

A and B can work *and* merge in parallel (zero file overlap). C can work in parallel but must merge AFTER A.

## Critical Path

**Critical path: A → C** (because C touches the same two pending_recurrences files A modifies).

Team B is off the critical path entirely — it can land in parallel with either.

Estimated wall-clock: 30-45 min for A+B working concurrently, then 15-20 min for C, then deploy + verification.

---

## Teams

### Team A: password-form-aria residual + pending_recurrences migration

**Blocked by:** none — can start immediately.

**Read these files first:**

- `dashboard/settings.html:540-575` — modal markup for delete-account-modal; the modal-body structure shows where the hidden username peer must be inserted.
- `dashboard/settings.js` — search for the function that opens the delete-account modal (likely `openDeleteAccountModal()` or a click handler on `#delete-account-btn`); pattern the username-peer population after this call site.
- `tests/e2e/journey-06-settings.spec.ts` — current console-warning assertion structure; the new delete-account-modal assertion should mirror the existing pattern.
- `docs/bug-hunt/pending_recurrences.jsonl` — the one legacy-schema entry; needs to be migrated, not duplicated.
- Reference pattern (do NOT modify, just read): the plugin-card hidden-username-peer pattern that closed 8 of 9 warnings. Look at git log for commit `b08ddb8` and `git show b08ddb8 -- dashboard/settings.js dashboard/settings.html` to see the exact attributes of the hidden peer (`type='text' name='username' hidden autocomplete='username' readonly tabindex='-1' aria-hidden='true'`).

**Recon evidence (verified by recon agent against HEAD `d159572`):**

```html dashboard/settings.html:559-568
559                <form id="delete-account-form" onsubmit="return false;" autocomplete="off">
560                    <div class="form-group" style="margin-top: 16px;">
561                        <label class="form-label" for="delete-confirm-password">Enter your password to confirm</label>
562                        <input type="password" id="delete-confirm-password" class="form-input" placeholder="Your password" autocomplete="current-password">
563                    </div>
564                    <div class="form-group">
565                        <label class="form-label" for="delete-confirm-text">Type <strong>DELETE</strong> to confirm</label>
566                        <input type="text" id="delete-confirm-text" class="form-input" placeholder="DELETE">
567                    </div>
568                </form>
```

The `<form id="delete-account-form">` opens at line 559 and contains a password input at line 562. Chromium's password-autofill heuristic emits `Password forms should have ... username fields for accessibility` because no same-form sibling has `autocomplete="username"`. The fix replicates the plugin-card pattern (commit `b08ddb8`) — insert a hidden `<input type="text" name="username" hidden autocomplete="username" readonly tabindex="-1" aria-hidden="true">` immediately after the `<form>` opening tag, before the first `<div class="form-group">`. (verified by recon agent against HEAD `d159572`)

```json docs/bug-hunt/pending_recurrences.jsonl
{"iteration":"20260503T230405Z2601","team":"C","bug":"Settings page still emits 2 verbose 'Password forms should have ... username fields' warnings from the hidden #delete-account-form modal — Team C fix closed the 8 plugin-card warnings but did not extend the hidden username-peer pattern to the delete-account-form (out of scope per team_c_verify.md). Original blind report counted 9, fix reduced to 2, but a future blind walk will likely re-flag this same warning shape.","reason":"partial-fix: Team C's surgical fix on plugin cards closed 8/9 instances (the user-reported scope) but the residual delete-account-form needs the same hidden autocomplete=username peer to fully close the family of warnings. Recommend next iteration apply identical pattern to settings.html lines 534-552."}
```

This is the ONLY line in `pending_recurrences.jsonl` and uses the legacy schema (`iteration` / `team` / `bug` / `reason` instead of the current `patch_iteration_ts` / `finding_id` / `category` / `retest_kind` / `deploy_sha` / `evidence` / `scope_files`). The auto-prune logic in `bug-hunt/SKILL.md` Phase 6 cannot resolve this entry because it filters on `category` and `patch_iteration_ts`, which don't exist on this entry. Migrating the entry to the new schema in `resolved.jsonl` and removing it from the live file is the correct move. (verified by recon agent against HEAD `d159572`)

**Files touched:**

- Modified: `dashboard/settings.html` — insert hidden username peer immediately after `<form id="delete-account-form">` opening tag at line 559. The peer's `value=""` empty default is acceptable (Chromium's heuristic only requires presence + same-form proximity, not a populated value).
- Modified: `dashboard/settings.js` — locate the function that opens `#delete-account-modal` (likely a click handler on a "Delete Account" button or an exported `openDeleteAccountModal()` function). At the point the modal becomes visible, set `document.getElementById('delete-account-username-peer').value = currentUserEmail` if the email is reachable in client state. If no email is reachable, leave the field's static `value=""` from HTML — the heuristic still passes. The peer must be populated lazily-or-not-at-all because the heuristic check happens at form-paint time, not on submit.
- Modified: `tests/e2e/journey-06-settings.spec.ts` — extend the existing console-warning assertion to also cover the delete-account modal:
  - After the existing settings-page cold-load assertion, click the "Delete Account" trigger (whatever opens `#delete-account-modal`).
  - Wait for the modal to be visible.
  - Re-read accumulated console messages; assert zero matches for `/Password forms should have .* username fields/`.
  - Click the cancel button to close the modal so the test cleanly tears down.
- Modified: `docs/bug-hunt/pending_recurrences.jsonl` — remove the single legacy-schema line. Result: the file becomes empty (0 lines).
- Modified: `docs/bug-hunt/pending_recurrences.resolved.jsonl` — append a migrated entry per the schema in the source refactor doc (Team A section). The `deploy_sha` field should be filled in with the eventual merge SHA AFTER deploy verification — leave a placeholder `<DEPLOY_SHA>` and Team C's verdict-refresh pass updates it post-deploy.

**Deliverable:** After Team A merges, opening `#delete-account-modal` on a deployed `finlet.dev/settings.html` produces zero `Password forms should have ... username fields` console warnings. The legacy pending_recurrences entry is moved to the resolved file with proper schema.

**Validation:**
- [ ] `bash scripts/lint-trusted-types.sh --check` exits 0.
- [ ] `wc -l docs/bug-hunt/pending_recurrences.jsonl` reports 0.
- [ ] `tail -1 docs/bug-hunt/pending_recurrences.resolved.jsonl | jq '.category'` returns `"password-form-aria"`.
- [ ] Local Playwright dry-run: `npx playwright test tests/e2e/journey-06-settings.spec.ts --reporter=line` passes (settings cold-load + delete-account modal assertions).
- [ ] Manual grep: `grep -c "delete-account-username-peer" dashboard/settings.html` returns 1.
- [ ] Manual: open `dashboard/settings.html` in a Chromium browser, click "Delete Account" button, open DevTools console, confirm zero `Password forms should have...` warnings.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Worktree work is lost on cleanup if uncommitted.
- The hidden username peer's HTML attributes MUST match the plugin-card pattern exactly: `type="text" name="username" hidden autocomplete="username" readonly tabindex="-1" aria-hidden="true"`. Use `id="delete-account-username-peer"` (not `class`, since this is a single-instance peer not a per-card peer).
- Keep the hidden peer INSIDE the `<form>` element, before any visible inputs. Chromium's heuristic checks same-form proximity.
- Do NOT change the existing password input or confirmation text input markup — the fix is purely additive.
- For the settings.js change, read the file and find the existing modal-open code path — match its style. Do not introduce new abstractions.
- For the migrated resolved.jsonl entry, use this exact schema (replace `<DEPLOY_SHA>` with `pending-deploy` for now; Team C will update post-merge):
  ```json
  {"patch_iteration_ts":"20260503T230405Z2601","finding_id":"settings-password-form-aria-residual-delete-account","category":"password-form-aria","retest_kind":"playwright","deploy_sha":"pending-deploy","evidence":"Original blind walk counted 9 password-form-aria warnings; iter 20260503 commit b08ddb8 closed 8 (plugin cards); residual 2 from #delete-account-form modal closed by this refactor. Same hidden-username-peer pattern replicated to settings.html line 559 (inside the form, before first form-group).","scope_files":"dashboard/settings.html, dashboard/settings.js","resolved_by":"convention-enforcement-2026-05-05.md (Team A)","resolved_at_ts":"<this-iteration-ts>","resolved_at_date":"2026-05-05","resolved_note":"Schema migration: original entry used legacy {iteration, team, bug, reason} keys; this entry restates with current spec schema."}
  ```
- The commit message must reference `convention-enforcement-2026-05-05` and the `password-form-aria` category. Suggested: `fix(settings): hidden username peer for delete-account-form (close password-form-aria residual)`.

---

### Team B: Event-bus lint guard + pre-commit wiring

**Blocked by:** none — can start immediately. Zero file overlap with Team A or C.

**Read these files first:**

- `scripts/lint-trusted-types.sh:1-100` — script header, allowlist marker pattern, `--check` flag handling, exit semantics. The new `lint-event-bus.sh` should mirror this shape EXACTLY (header doc-comment, `set -uo pipefail`, `--check` flag, allowlist marker convention, `exit 1` on violation, `exit 0` on clean).
- `scripts/git-hooks/pre-commit` (full file, ~57 lines) — current invocation chain. The new lint must be added in series, not in parallel; both must pass for the commit to proceed.
- `dashboard/event-bus.js:1-150` — the bus API definition. The lint guard should NOT scan this file (it's the only legitimate site for `dispatchEvent`/`addEventListener` of `finlet:*` events).
- `docs/decisions/dashboard-event-bus.md` — current decision record; the lint guard codifies this.
- `CLAUDE.md` — search for "finletBus" — the rule that forbids direct dispatch is documented here.

**Recon evidence (verified by recon agent against HEAD `d159572`):**

```bash scripts/lint-trusted-types.sh:70-81
70  set -uo pipefail
71
72  # Resolve repo root from the script location (works for hooks too).
73  SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
74  REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
75  DASH_DIR="$REPO_ROOT/dashboard"
76  SELF_PATH="$SCRIPT_DIR/lint-trusted-types.sh"
77
78  CHECK_MODE=0
79  if [[ "${1:-}" == "--check" ]]; then
80      CHECK_MODE=1
81  fi
```

```bash scripts/lint-trusted-types.sh:88-107
88  ALLOWLIST_MARKER='trusted-types-vendor-allowlist'

105     if grep -q "$ALLOWLIST_MARKER" "$file" 2>/dev/null; then
106         continue
107     fi
```

```bash scripts/git-hooks/pre-commit:48-56
48  bash "$LINT_SCRIPT" --check
49  status=$?
50  if (( status != 0 )); then
51      echo "" >&2
52      echo "pre-commit: trusted-types lint failed. Run \`bash scripts/lint-trusted-types.sh\` for the full message." >&2
53      exit "$status"
54  fi
55
56  exit 0
```

Current pre-commit hook chains exactly one lint (trusted-types). To add event-bus lint without breaking trusted-types, change the early-exit pattern: capture status from each lint, accumulate, and exit non-zero if ANY failed. The clearest shape is two sequential invocations with separate status checks; only the first failure aborts (preserving "fail fast on first violation" behavior). (verified by recon agent against HEAD `d159572`)

```javascript dashboard/event-bus.js:55-130 (paraphrase)
```

The bus exposes three methods on `window.finletBus`: `subscribe(event, handler) → unsubscribe`, `publish(event, payload)`, and `getLastPublished(event)`. The frozen object is exported at lines 126-130. The lint guard's exclusion list MUST include `dashboard/event-bus.js` itself; otherwise the lint would flag the bus's own internal `addEventListener` / `dispatchEvent` calls. (verified by recon agent against HEAD `d159572`)

Grep evidence for current zero-violation state:
```
$ rg "dispatchEvent.*finlet:" dashboard/ --files-with-matches
(zero results)

$ rg "addEventListener.*'finlet:" dashboard/ --files-with-matches
(zero results)
```

The lint guard is purely defensive — it preserves the current zero-violation state across future PRs. (verified by recon agent against HEAD `d159572`)

**Files touched:**

- New: `scripts/lint-event-bus.sh` — bash script (~120-150 lines) that scans `dashboard/*.js` (excluding `dashboard/event-bus.js` and `dashboard/vendor/*`) for direct `addEventListener('finlet:` and `dispatchEvent(new CustomEvent('finlet:`. Allowlist marker: `// finlet-bus-lint-allowlist`. Header doc-comment must mirror lint-trusted-types.sh's structure: "What it scans", "Why", "Matching strategy", "Allowlist", "Usage", "Pre-commit hook install".
- Modified: `scripts/git-hooks/pre-commit` — chain a second lint invocation after the existing trusted-types call. Both must pass for the commit to proceed. Preserve symlink-resolution semantics; preserve the existing fallback (`git rev-parse --show-toplevel`).
- Modified: `docs/decisions/dashboard-event-bus.md` — add an "Enforcement" section near the top (after the rule statement, before the implementation notes) noting that `scripts/lint-event-bus.sh` is the pre-commit guard. Cross-link to `scripts/lint-trusted-types.sh` as the sibling guard.
- Optional: `docs/ARCHITECTURE.md` — if a "Lint guards" or "Conventions" section already exists, add the event-bus lint to the list. Skip if no such section exists (don't invent one).

**Deliverable:** After Team B merges, a commit that adds a direct `addEventListener('finlet:foo', ...)` in `dashboard/app.js` (or anywhere outside `event-bus.js`) is rejected by the pre-commit hook with a clear file:line message. The convention is unenforceable today; after this team, it's enforced.

**Validation:**
- [ ] `bash scripts/lint-event-bus.sh` exits 0 on current main (zero violations).
- [ ] `bash scripts/lint-event-bus.sh --check` returns clean exit code.
- [ ] Synthetic violation test (delete after): create `dashboard/test-violation.js` with `window.addEventListener('finlet:foo', () => {})` → script exits 1 with file:line. Then `rm dashboard/test-violation.js`. The agent's commit should NOT include the test-violation file.
- [ ] `bash scripts/setup-git-hooks.sh` re-runs cleanly; resulting `.git/hooks/pre-commit` is a symlink to the source file.
- [ ] After running setup-git-hooks: attempt to commit a synthetic violation (then revert the synthetic) — confirm the hook blocks it.
- [ ] Existing trusted-types lint still passes: `bash scripts/lint-trusted-types.sh --check` exits 0.

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing. Worktree cleanup will lose uncommitted work.
- New script MUST follow the lint-trusted-types.sh shape: same header doc-comment structure, same `set -uo pipefail`, same `--check` flag, same exit semantics, same allowlist-marker pattern. Do NOT invent a different convention.
- Allowlist marker comment text: `finlet-bus-lint-allowlist`. The grep check is identical to trusted-types' pattern.
- Patterns to detect (use grep with extended regex; this is the same approach as lint-trusted-types):
  - `addEventListener\s*\(\s*['"]finlet:`
  - `dispatchEvent\s*\(\s*new\s+CustomEvent\s*\(\s*['"]finlet:`
- File exclusions:
  - `dashboard/event-bus.js` (the bus itself)
  - `dashboard/vendor/**` (third-party code)
  - `dashboard/test*.js` files (per-test fixtures)
  - The lint script itself (`scripts/lint-event-bus.sh`)
- Do NOT add allowlist exemptions for production files. The current codebase has zero violations; a clean baseline is the starting state.
- For pre-commit: chain the new lint AFTER the existing trusted-types invocation. Capture each script's exit status separately. Print which lint failed if either does.
- Make `chmod +x` happen via the symlink installer (existing setup-git-hooks.sh handles this); do NOT manually `chmod +x scripts/lint-event-bus.sh` in a commit (file mode bits in git create cross-platform churn).
- Decision record update: short. Just one section heading + 3-5 sentences. Do not rewrite the decision; only ADD enforcement guidance.
- Suggested commit message: `chore(lint): add event-bus dispatch guard + pre-commit chain (codify dashboard-event-bus convention)`.

---

### Team C: Verdict refresh + pending_recurrences pruning

**Blocked by:** Team A (because C touches the same `pending_recurrences*.jsonl` files A modifies). C must rebase onto post-A `main` before merging.

**Read these files first:**

- `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` (full file, ~115 lines) — current verdict state and the existing `verdict_v2: effective` precedent for how multi-version verdicts are recorded.
- `docs/bug-hunt/refactor-queue/onboarding-checklist.md` — current verdict state.
- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` — current verdict state and the v3.1 inline-patch context.
- `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md` — current verdict state.
- `docs/bug-hunt/pending_recurrences.resolved.jsonl` — the existing entries; check that each refactor's targeted findings are already there with a `resolved_by` reference.
- `.claude/skills/bug-hunt/SKILL.md` — the "Refactor outcome tracking" and "Pending-recurrences pruning" sub-sections of Phase 6 — this team applies that contract.
- `dashboard/onboarding.js:380-395` — the comment block documenting closed reach-ins (load-bearing for the onboarding-checklist verdict_v2 evidence).
- `dashboard/form-dirty-tracker.js:240-267` — the v3 setFieldDirty guard (load-bearing for the dirty-state-tracker verdict_v3 evidence).

**Recon evidence (verified by recon agent against HEAD `d159572`):**

Ledger query results — `dirty-state-tracker` category:
```
$ jq -c 'select(.category == "dirty-state-tracker") | {iteration_ts, finding_id, commit}' docs/bug-hunt/ledger.jsonl
{"iteration_ts":"20260428T031818Z2efa","finding_id":"settings-dirty-banner-onload","commit":"c82caca"}
{"iteration_ts":"20260429T052717Z1a13","finding_id":"settings-dirty-banner","commit":"6a8d798"}
{"iteration_ts":"20260429T232205Z17ff","finding_id":"plugins-tab-dirty-banner-deploy-lag","commit":"ed15c6c"}
{"iteration_ts":"20260430T222711Z3666","finding_id":"settings-dirty-banner-synthetic-key-flash","commit":"dba4c83"}
{"iteration_ts":"20260501T234103Z1a49","finding_id":"settings-dirty-banner-onload","commit":"87a37b6"}
```

Latest entry is `20260501T234103Z1a49` (commit `87a37b6`). No new entries in subsequent iterations (`20260502T142726Z7b36`, `20260502T211937Z7ddd`, `20260503T030227Z2009`, `20260503T195318Z43db`, `20260503T230405Z2601`, `20260504T165106Z1ab2`). The v3 patch (commit `87a37b6`) closed the synthetic-key + aria-hidden axes. Combined with the in-code state of `dashboard/form-dirty-tracker.js:259-267` (setFieldDirty guard verified at HEAD), the verdict should be `verdict_v3: effective`. (verified by recon agent against HEAD `d159572`)

Ledger query results — `onboarding-checklist` category:
```
$ jq -c 'select(.category == "onboarding-checklist") | {iteration_ts, finding_id, commit}' docs/bug-hunt/ledger.jsonl
{"iteration_ts":"20260428T013300Z6e79","finding_id":"strategy-checklist-dead-div","commit":"4908f98"}
{"iteration_ts":"20260428T031818Z2efa","finding_id":"strategy-item-opens-leaderboard","commit":"6c256fb"}
{"iteration_ts":"20260428T031818Z2efa","finding_id":"onboarding-wizard-form-drift","commit":"6c256fb"}
{"iteration_ts":"20260428T031818Z2efa","finding_id":"checklist-no-advance-after-fill","commit":"6c256fb"}
{"iteration_ts":"refactor-2026-04-30","finding_id":"onboarding-checklist-refactor-shipped","commit":"40368b292c6bc17bc50eed33d104c544f13db142"}
{"iteration_ts":"20260430T222711Z3666","finding_id":"checklist-rest-cli-no-advance","commit":"91922c7"}
{"iteration_ts":"20260501T234103Z1a49","finding_id":"checklist-set-up-profile-auto-complete","commit":"4924948"}
```

Latest entry is `20260501T234103Z1a49` (commit `4924948`). No new entries in subsequent iterations. Combined with the in-code comment at `dashboard/onboarding.js:383-389` documenting both reach-ins as closed, the verdict should be `verdict_v2: effective`. (verified by recon agent against HEAD `d159572`)

Ledger query results — trade-ticket-related entries (categorized as `dashboard-state-sync`, filtered by summary text containing "trade-ticket" or "trade ticket" case-insensitive):
```
$ jq -c 'select(.category == "dashboard-state-sync" and (.summary | test("trade-?ticket"; "i"))) | {iteration_ts, finding_id, commit}' docs/bug-hunt/ledger.jsonl
{"iteration_ts":"20260503T030227Z2009","finding_id":"trade-ticket-stale-cash","commit":"8c55a90"}
```

Latest trade-ticket-tagged entry is `20260503T030227Z2009` (commit `8c55a90`, the v3.1 patch). No subsequent trade-ticket entries in the ledger. The resolved.jsonl already contains the patch-ineffective signal that v3.1 closed (`patch_iteration_ts:20260502T142726Z7b36`, `resolved_by: trade-ticket-state-sync-v3.1 (terminal repaintCash() at every publisher site — commit 8c55a90, bug-hunt 20260503T030227Z2009 Team A)`). The verdict on `trade-ticket-state-sync-v3.md` should be `verdict_v3_1: effective`. (verified by recon agent against HEAD `d159572`)

`close-patch-ineffective-2026-05-02.md` resolved.jsonl evidence:
```
$ jq -c 'select(.resolved_by | test("close-patch-ineffective-2026-05-02"; "i"))' docs/bug-hunt/pending_recurrences.resolved.jsonl
```
Three entries reference this doc as `resolved_by`:
- `profile-checklist-marks-on-persona` (onboarding-checklist) — resolved 2026-05-02
- `settings-dirty-banner-on-cold-load` (dirty-state-tracker) — resolved 2026-05-02
- `edgar-plugin-stale-after-cli-config` (dashboard-state-sync) — resolved 2026-05-02

All three are in the resolved file. None has a recurrence in the ledger after 2026-05-02. The verdict should be `verdict_v2: effective`. (verified by recon agent against HEAD `d159572`)

**Files touched:**

- Modified: `docs/bug-hunt/refactor-queue/dirty-state-tracker.md` — append `verdict_v3: effective`, `verdict_v3_set_at: 2026-05-05`, `verdict_v3_set_in: convention-enforcement-2026-05-05`, `verdict_v3_evidence: <text>` to the frontmatter (between the existing `verdict_v2_evidence` line and the closing `---`). Evidence cites the ledger gap since `20260501T234103Z1a49` and the in-code state of `dashboard/form-dirty-tracker.js:259-267`.
- Modified: `docs/bug-hunt/refactor-queue/onboarding-checklist.md` — append `verdict_v2: effective` block. Evidence cites the ledger gap since `20260501T234103Z1a49` (commit `4924948`) and the in-code comment at `dashboard/onboarding.js:383-389`.
- Modified: `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` — append `verdict_v3_1: effective` block. Evidence cites the ledger gap since `20260503T030227Z2009` (commit `8c55a90`) and the resolved.jsonl entry that v3.1 closed.
- Modified: `docs/bug-hunt/refactor-queue/close-patch-ineffective-2026-05-02.md` — append `verdict_v2: effective` block. Evidence cites the three resolved.jsonl entries (profile-checklist, settings-dirty-banner, edgar-plugin) and the absence of recurrence in the ledger since 2026-05-02.
- Modified: `docs/bug-hunt/pending_recurrences.jsonl` — apply the per-spec pruning recipe for each newly-effective category. Most categories' pending entries are already in `resolved.jsonl`; the pruning will likely no-op. Run pruning for `dirty-state-tracker`, `onboarding-checklist`, `dashboard-state-sync` (filtered to trade-ticket entries via `scope_files` text), and any close-patch-ineffective categories.
- Modified: `docs/bug-hunt/pending_recurrences.resolved.jsonl` — append any pruned entries with proper `resolved_by` references. Update Team A's migrated entry's `deploy_sha` from `pending-deploy` to the actual merge SHA from the deploy verification step (see "Cross-team coordination" below).

**Deliverable:** After Team C merges, four shipped queue docs have refreshed verdicts with evidence. The pending_recurrences pruning has been run per spec contract. The bug-hunt gate's count trigger no longer fires false alarms on closed clusters because the verdict trail is complete.

**Validation:**
- [ ] Each of the 4 queue docs has a NEW verdict block at the END of its frontmatter (preserving prior verdict blocks).
- [ ] Each new verdict block cites at least one finding_id AND one commit SHA.
- [ ] `wc -l docs/bug-hunt/pending_recurrences.jsonl` is 0 (Team A removed the legacy entry; C's pruning does not add new entries to live).
- [ ] `jq -c '.' docs/bug-hunt/pending_recurrences.resolved.jsonl` parses every line cleanly.
- [ ] No regression in any queue doc's existing verdicts (audit: `git diff origin/main -- docs/bug-hunt/refactor-queue/*.md` should show only ADDITIONS, not deletions of prior `verdict_*` keys).

**Agent instructions:**
- You MUST `git add` + `git commit` before finishing.
- This team REBASES onto post-A `main` before merging. Wait for A's merge SHA, then `git fetch origin main && git rebase origin/main` in the worktree.
- For each verdict block, use this exact frontmatter structure (mirroring existing convention from `dirty-state-tracker.md`):
  ```yaml
  verdict_vN: effective
  verdict_vN_set_at: 2026-05-05
  verdict_vN_set_in: convention-enforcement-2026-05-05
  verdict_vN_evidence: "<2-3 sentences with finding_id + commit SHA + ledger gap evidence>"
  ```
  where `vN` is the next version after the most recent `verdict_*` field. For `dirty-state-tracker.md`, that's `verdict_v3` (after `verdict_v2`). For `onboarding-checklist.md`, that's `verdict_v2`. For `trade-ticket-state-sync-v3.md`, that's `verdict_v3_1`. For `close-patch-ineffective-2026-05-02.md`, that's `verdict_v2`.
- Do NOT delete or modify existing `verdict_*` fields. Only ADD new ones.
- For the pruning recipe, use the exact `jq` invocation from `bug-hunt/SKILL.md` Phase 6. Do NOT invent a different command. Run once per newly-effective category.
- After A merges, update Team A's migrated resolved.jsonl entry's `deploy_sha` field from `pending-deploy` to the actual deploy SHA. Use `git log origin/main -- docs/bug-hunt/pending_recurrences.resolved.jsonl` to find the latest commit on resolved.jsonl, and use `gh run list --workflow="Deploy Finlet" --branch main --limit 1 --json conclusion,headSha` to find the deploy SHA. If deploy is still in progress when Team C runs, leave `pending-deploy` in place; the orchestrator updates it post-deploy.
- Suggested commit message: `docs(bug-hunt): refresh verdicts on 4 shipped refactors + prune pending_recurrences`.

---

## Cross-team coordination

**Sequencing:** A merges first → CI verifies trusted-types lint passes → B merges in parallel with A (no file overlap, can land before, after, or interleaved with A) → C rebases onto post-A main → C merges → CI verifies → deploy.

**Deploy SHA backfill:** Team A inserts `deploy_sha: "pending-deploy"` in the migrated resolved.jsonl entry. After all three teams merge AND the Deploy Finlet workflow run for the merge HEAD finishes successfully, the orchestrator amends the file (or Team C's merge can include the update if it's the last team to merge — preferred path).

**Rebase risk:** The two `pending_recurrences*.jsonl` files are line-oriented JSONL. A rebase conflict on these is mechanical — Team C re-applies its pruning + deploy_sha update on top of A's migration. The conflict resolution is "keep both A's append AND C's append; C may also need to update A's `deploy_sha` field if it's still the placeholder."

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Team A's hidden peer breaks the existing delete-account flow (e.g., autocomplete heuristic interferes with form submit) | Low | Medium | Hidden peer has `tabindex="-1" readonly aria-hidden="true"` — not focusable, not announced, not part of submit flow. Validation includes a manual test of the actual delete-account flow. |
| Team B's lint script has false positives on legitimate uses of finlet:* events | Low | Low | The grep patterns are specific to `addEventListener('finlet:` and `dispatchEvent(new CustomEvent('finlet:`. The bus's own internal usage is excluded (file allowlist). Allowlist marker handles any future legitimate exception. |
| Team B's pre-commit chain breaks existing trusted-types lint | Low | High | The chain pattern uses two sequential invocations with separate status checks. Validation includes `bash scripts/lint-trusted-types.sh --check` post-merge. Symlink installer is unchanged. |
| Team C's verdict refresh contradicts a future bug-hunt iteration | Medium | Low | Each verdict block cites specific evidence (finding_id, commit, ledger gap). If a future iteration finds a recurrence, it adds a new ledger entry; the verdict gets re-evaluated next iteration. The bookkeeping is the right snapshot for THIS moment — staleness is the failure mode it fixes. |
| Rebase conflict between A and C on pending_recurrences*.jsonl | High | Low | Mechanical conflict on JSONL files. Team C's instructions explicitly handle the rebase with the resolution strategy ("keep both A's append AND C's append"). |
| Deploy fails on the merge SHA (unrelated breakage) | Low | High | Phase 5.5 of bug-hunt skill handles this — retest skipped, no patch-ineffective signal emitted, the orchestrator surfaces the deploy failure. We then triage CI logs, fix, re-push. Self-heal protocol applies. |
| One of the 4 verdict refreshes is wrong (the pattern actually IS still recurring on prod) | Low | Medium | Each verdict cites a ledger gap as evidence. If prod actually has a recurrence not yet ledgered, the next blind walk will catch it and the verdict gets reverted to `incomplete`. The verdict refresh is the snapshot for this moment, not a permanent claim. |

## Session Plan

### Session 1 — Three-team parallel work + sequential merge

**Parallel work:** A, B, C all start at once in separate worktrees. C's actual file modifications can begin in parallel; the rebase happens at merge time.

**Merge order:**
1. **Team A merges first** (independent; touches `dashboard/`, `tests/e2e/`, and `pending_recurrences*.jsonl`).
   - Per-merge gate: `bash scripts/lint-trusted-types.sh --check` passes; `wc -l pending_recurrences.jsonl == 0`; `npx playwright test journey-06-settings.spec.ts --reporter=line` passes (smoke if full e2e is too slow).
2. **Team B merges in parallel** (zero file overlap with A or C; can merge before, after, or interleaved with A).
   - Per-merge gate: `bash scripts/lint-trusted-types.sh --check` AND `bash scripts/lint-event-bus.sh --check` both pass on main. `bash scripts/setup-git-hooks.sh` re-installs cleanly.
3. **Team C rebases onto post-A main, then merges.**
   - Per-merge gate: All four queue docs have new verdict blocks; pending_recurrences.jsonl still 0 lines; resolved.jsonl parses cleanly; `git diff origin/main -- docs/bug-hunt/refactor-queue/*.md` shows only additions.

**Session checkpoint after all three merge:**
- Push to origin/main.
- Wait for Deploy Finlet workflow run for the new HEAD SHA.
- On deploy success: run targeted retest against `https://finlet.dev/settings.html` for the password-form-aria assertion (open delete-account modal, confirm zero `Password forms should have...` warnings).
- On deploy success: backfill the `deploy_sha` field in the resolved.jsonl entry (orchestrator commit).
- On deploy failure: surface the failing job + test, dispatch self-heal subagent to triage and patch.

### Session 2 — Post-deploy verification

This is not a separate work session; it's the verification gate. The orchestrator polls Deploy Finlet workflow status, then runs the targeted Playwright check, then updates verdicts/refactor-queue docs as needed.

If verification fails (e.g., deploy succeeds but the password-form-aria warning is still present on prod), the self-heal protocol fires: spawn a recon agent to identify whether the patch landed correctly, whether the deploy actually rolled, and whether there's a CDN/cache layer issue. If a real bug exists in the patch, dispatch a fix agent.

---

## Quality Checklist

- [x] Every team has a "Read these files first" list with file:line cites.
- [x] Every team has "You MUST git add + git commit" in agent instructions.
- [x] Every team has specific validation commands.
- [x] File conflict table accounts for ALL shared files (the two pending_recurrences*.jsonl files are flagged as A→C sequential).
- [x] No team touches >8 files (A: 5, B: 4, C: 6).
- [x] Dependencies match the file conflict table (C blocked by A on pending_recurrences*.jsonl; A and B fully parallel).
- [x] Critical path is A → C (the only sequential chain).
- [x] Session grouping respects all dependency constraints.
- [x] Every "current state" claim about file:line behavior is backed by a quoted-excerpt fenced block or `(verified by recon agent against HEAD d159572)` paraphrase. (PF-18 satisfied.)

## PF-18 Plan Validation Scan Results

Scanned the rendered plan body for unverified "current state" claims using the regex from the skill spec:
```
grep -nE '(currently|current order|runs .* (BEFORE|AFTER)|increments at|the predicate at line)' plan.md
```

Matches found and verification status:

| Claim location | Claim text | Recon evidence present? |
|----|----|----|
| Team A "Recon evidence" | `<form id="delete-account-form">` opens at line 559... | YES — quoted excerpt at lines 559-568 |
| Team A "Recon evidence" | The auto-prune logic in `bug-hunt/SKILL.md` Phase 6 cannot resolve this entry | YES — quoted JSONL entry showing legacy schema |
| Team B "Recon evidence" | Current pre-commit hook chains exactly one lint | YES — quoted excerpt at lines 48-56 |
| Team B "Recon evidence" | The bus exposes three methods on `window.finletBus` | YES — paraphrase tagged `(verified by recon agent against HEAD d159572)` |
| Team C "Recon evidence" | Latest entry is `20260501T234103Z1a49`... No new entries in subsequent iterations | YES — full jq query results quoted |
| Team C "Recon evidence" | Three entries reference this doc as `resolved_by` | YES — jq query results listed |

All 6 "current state" claims are backed. **Plan passes PF-18 validation. Cleared for handoff to /exec-plan.**
