# Trade Ticket State Sync v3 — Execution Plan

> Generated from `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md`.
> Last updated: 2026-05-02
> Generator: `/plan-features` against v3 source doc.

## Constraints

**Hard constraints (from the v3 source doc and CLAUDE.md):**

- `git revert 1cd2b5b` MUST be the first operation. v2 is merged on `main` but deploy-blocked (run `25261964914` is the v2 deploy that failed; subsequent runs `25263179874` and `25263954836` continue to fail). v3 is applied on the post-revert base.
- The render-on-read pattern is non-negotiable: `paintCash(value)` is replaced by `repaintCash()` (no value arg) and a single canonical reader `getCanonicalCash()`. Bus events become repaint TRIGGERS, never value carriers.
- `tests/e2e/journey-05-trade.spec.ts:389` (`'available cash header never shows -- across open/close cycles'`) MUST stay green. The poison-cash assertion at `:447-463` MUST be preserved verbatim — adding new assertions in a sibling test, never modifying that block.
- `dashboard/event-contract.md` and `docs/decisions/trade-ticket-render-on-read.md` MUST be updated in the SAME commit as the code change (CLAUDE.md doc-touch rule, and `dashboard/event-contract.md` is explicitly named in CLAUDE.md as a same-commit requirement).
- All `bus.publish('portfolio:updated', ...)` callsites MUST atomically mutate `currentSession.portfolio_metrics.cash` BEFORE publishing — the v3 contract. Audited: see "Atomic-mutate-then-publish audit" below.
- No new module extraction. Single-consumer pattern; defer extraction to a `renderOnRead.js` module until a second instance appears (same break-even logic v1 used).

**Discovered constraints (from recon, this iteration):**

- Current `origin/main` HEAD: `c9b9fc58b6e486736290f558ef944694cfee79a7`.
- v2 merge SHA to revert: `1cd2b5b` (full: `1cd2b5ba677b05c3ab02a70d684cd14ea1bbbc6a`). Confirmed via `git show 1cd2b5b --stat`: it touched exactly `dashboard/event-contract.md` (+1), `dashboard/trade-ticket.js` (+35), `tests/dashboard/trade-ticket-panel-mirror.spec.js` (+268, new file), `tests/e2e/journey-05-trade.spec.ts` (+61, -1).
- The v2 merge is a TRUE merge commit (`Merge: 5d6039c c712d98`). `git revert 1cd2b5b` requires `-m 1` (mainline parent). The plan uses `git revert -m 1 1cd2b5b --no-edit`.
- Most-recent CI runs on main: `25263954836` (failed, 25m4s, push to main 2026-05-02T22:56), `25263179874` (failed, 23m30s), `25261964914` (failed — this is the v2 deploy run cited in the v3 doc, 24m26s). Two consecutive non-v3 deploys remain failing on main — the deploy-blocked state is real and ongoing.
- v2 spec file `tests/dashboard/trade-ticket-panel-mirror.spec.js` exists (10857 bytes, header confirms it is the always-on mirror tests). It will return automatically with `git revert -m 1 1cd2b5b` (the revert removes the file because it was net-added in the merge). The plan does NOT issue an explicit `rm` — the revert handles deletion.

## Source-doc anchor

The v3 source doc (`docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md`) has the authoritative reasoning. This plan only restates what the implementer needs as runnable steps. Section anchors in the source doc:

- `## Why we're here (3rd time on this surface)` — three-iteration history; v1 (`efdd44316`), iter 7b36 patch (`109686c`), v2 (`c712d98`/`1cd2b5b` merge).
- `## Root cause` — `#tt-cash-balance` has multiple write paths and no single read source; the panel doesn't own its read.
- `## Approach` — render-on-read; `getCanonicalCash()` over `currentSession.portfolio_metrics.cash` with bus-cache fallback; `repaintCash()` with no value arg; v2 always-on subscriber dropped.
- `## Files` — six file changes (modify trade-ticket.js, modify event-contract.md, new ADR, new unit spec, delete v2 spec, modify journey-05 e2e).
- `## Validation` — required-green tests (`journey-05:389`, iter 7b36 retest, all four existing trade specs) + new regression cases.
- `## Deploy-blocked handling` — revert v2 first; justification at lines 130-139 of the source doc.
- `## Risks` — five risks (atomic-mutate-then-publish, currentSession null, closed-panel paint of persistent DOM, future external consumer, decision-record drift).
- `## Out of scope` — no new module extraction; v1 mirror untouched; no other slide-out panel migration.

The plan does not re-derive these. It executes them.

## File Conflict Table

ONE team. There is no parallel-merge conflict surface. The table is included for completeness and for the orchestrator's per-team file-ownership trace.

| File | Touched by | Type |
|------|-----------|------|
| `dashboard/trade-ticket.js` | Team A | modify (revert removes v2 block; commit 2 adds `getCanonicalCash`/`repaintCash`, simplifies mirror handlers, transitions `fetchCashBalance` terminal write) |
| `dashboard/event-contract.md` | Team A | modify (revert removes v2 always-on bullet; commit 2 adds render-on-read note) |
| `docs/decisions/trade-ticket-render-on-read.md` | Team A | new (commit 2) |
| `tests/dashboard/trade-ticket-render-on-read.spec.js` | Team A | new (commit 2) |
| `tests/dashboard/trade-ticket-panel-mirror.spec.js` | Team A | deleted by revert (commit 1) |
| `tests/e2e/journey-05-trade.spec.ts` | Team A | modify (commit 2: new closed-panel-after-fill assertion; existing :447-463 untouched) |

Total: 6 files, all owned by `dashboard` team per `.claude/rules/file-ownership.md` (`dashboard/`) and `docs` team (`docs/`). Cross-ownership is acceptable for one team because there is no parallel team to coordinate against.

## Dependency Graph

- **Prerequisite (commit 1):** `git revert -m 1 1cd2b5b --no-edit`. Atomic. No team needed; the agent does it as the first commit on its worktree.
- **Team A (commit 2):** depends on commit 1. Applies all v3 changes per the source doc's "Files" section.

```
[origin/main c9b9fc5]
       |
       v
[commit 1: revert -m 1 1cd2b5b]   <- automatic message from git revert; do NOT edit
       |
       v
[commit 2: v3 render-on-read]      <- Team A's deliverable
       |
       v
[merge gate: validation]
       |
       v
[push to origin/main]
       |
       v
[deploy gate: gh run list --branch main --limit 1 must be success]
```

## Critical Path

Single team. Team A is the path. No parallelisation possible (and none desired — the source doc explicitly argues for one coherent commit, see `## Approach` and the `## Out of scope` no-extraction note).

---

## Teams

### Team A: Trade Ticket render-on-read v3 (revert v2 + new canonical reader)

**Blocked by:** none (the prerequisite revert is in-scope as commit 1 on the same worktree).

**Read these files first (in this order):**

- `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` — the source doc. Sections `## Approach`, `## Files`, `## Validation`, `## Risks`, `## Deploy-blocked handling`. Authoritative reasoning.
- `dashboard/trade-ticket.js:1-148` — current state. Specifically:
  - `paintCash(cash)` at `:20-25` (the function being replaced)
  - The v2 always-on subscriber block at `:114-147` (comment header `:114-134`; primer at `:135-140`; subscriber at `:141-147`). The whole block is removed by the revert.
- `dashboard/trade-ticket.js:153-252` — `openTradeTicket` and the per-open mirror block:
  - mirror primeFromCache reader at `:198-204`
  - onOpen `paintCash(initialState.cash)` callsite at `:216`
  - onUpdate `paintCash(payload.cash)` callsite at `:226`
- `dashboard/trade-ticket.js:282-316` — `fetchCashBalance`. Terminal write at `:305` (`cashDisplay.textContent = '$' + ...`) is what transitions to call `repaintCash()` — the function still mutates `tradeTicketCashBalance` and `currentSession.portfolio_metrics.cash` first, then calls `repaintCash()` to read-and-paint. (v3 doc cites `:282-316`; matches.)
- `dashboard/trade-ticket.js:343-507` — `submitTradeTicket` and the post-submit IIFE:
  - close call at `:414` (closes panel BEFORE the IIFE's republish — explains the iter 7b36 panel-rot)
  - IIFE block at `:443-494` (matches v3 cite)
  - mutation block at `:463-477` (v3 doc cites `:460-477`; the `:460-462` lines are the comment header opening the block — actual mutation code is at `:463-477`. Note this in the implementation; the IIFE structure is unchanged by v3, only its call to `paintCash` is replaced — actually NO, `paintCash` is not called inside this IIFE; the IIFE only mutates+publishes, the paint is by downstream subscribers. So the IIFE body is untouched by v3 except for any incidental cleanups.)
  - publish at `:484` (matches v3 cite)
- `dashboard/app.js:1441-1479` — SSE `portfolio` event handler. Atomic-mutate-then-publish pattern to PRESERVE; v3 codifies the existing pattern as a contract. (v3 cites `:1442-1478`; actual `:1441-1479` — close enough; `(v3 doc cited :1442-1478, actual current location :1441-1479)`.)
  - mutation: `:1456-1466` (matches v3 cite)
  - publish: `:1472`
- `dashboard/app.js:1569-1613` — SSE `orders` post-fill IIFE. Same atomic pattern. (v3 cites `:1572-1612`; actual outer guard starts at `:1569`, IIFE body `:1572-1613`. `(v3 doc cited :1572-1612, actual current location :1569-1613 outer; :1572-1613 IIFE body.)`)
  - mutation: `:1595-1605` `(v3 doc cited :1591-1604, actual current location :1595-1605 — 4-line offset from comment-header drift)`.
  - publish: `:1608`
- `dashboard/event-contract.md:122-140` — the `portfolio:updated` section. The always-on subscriber convention bullet to remove is at `:140` (matches v3 cite).
- `tests/e2e/journey-05-trade.spec.ts:389` — the regression test name. (Matches v3 cite.)
- `tests/e2e/journey-05-trade.spec.ts:442-475` — the close+reopen cycle block. The poison-publish-and-assert assertion at `:447-463` (matches v3 cite). DO NOT MODIFY.
- `tests/dashboard/trade-ticket-panel-mirror.spec.js` — full file (~268 LOC). Read once so the agent understands what contract v2 encoded and why v3 inverts it. The revert deletes this file; no manual rm needed.
- `docs/decisions/dashboard-event-bus.md` — the parent ADR for the bus. The new render-on-read decision record cross-links here. v3's policy ("payloads carry data; the panel's reader path never trusts them") is consistent with this ADR's positioning of the bus as a delivery layer.
- `CLAUDE.md` — the doc-touch rule (and the bullet specifying `dashboard/event-contract.md` must be updated in the same commit as bus changes).

**Files touched:**

- `dashboard/trade-ticket.js` — modified.
  - **Removed by commit 1** (via `git revert`): `:114-147` (v2 always-on subscriber comment + primer + subscribe block).
  - **Modified in commit 2:**
    - Replace `paintCash(cash)` at `:20-25` with TWO new functions: `getCanonicalCash()` (reads `currentSession.portfolio_metrics.cash` first, then `bus.getLastPublished('portfolio:updated').cash`, returns `undefined` otherwise) and `repaintCash()` (reads via `getCanonicalCash`, returns silently if no canonical or NaN, writes to `tradeTicketCashBalance` and `#tt-cash-balance.textContent`).
    - Update the `onOpen` callsite (current `:216`, post-revert line numbers will drift): replace `paintCash(initialState.cash)` with `repaintCash()`. The `if (initialState && typeof initialState.cash === 'number')` guard is no longer needed — `repaintCash()` is internally idempotent and self-guarding.
    - Update the `onUpdate` callsite (current `:226`): replace `if (payload && typeof payload.cash === 'number' && !Number.isNaN(payload.cash)) { paintCash(payload.cash); return; }` with `repaintCash(); return;` followed by the existing `refetch()` fallback. The payload value is intentionally ignored — the bus event is now ONLY a repaint trigger.
    - Update `fetchCashBalance` (`:282-316`): the terminal write at `:305` (`cashDisplay.textContent = '$' + ...`) becomes a call to `repaintCash()`. Before that call, the function must mutate the canonical store: `if (typeof currentSession !== 'undefined' && currentSession) { if (!currentSession.portfolio_metrics) currentSession.portfolio_metrics = {}; currentSession.portfolio_metrics.cash = cash; }`. This way `fetchCashBalance` becomes another atomic-mutate-then-paint publisher, consistent with the v3 contract.
- `dashboard/event-contract.md` — modified.
  - **Removed by commit 1** (via revert): the v2-added line at `:140` (always-on subscriber convention bullet).
  - **Modified in commit 2:** under the `portfolio:updated` section's existing bullets, ADD a new note:
    > **Render-on-read pattern (v3, supersedes v2):** the Trade Ticket cash header subscribes to this event ONLY for the open lifetime of the slide-out panel (via `dialog-state-mirror.js`). The subscriber's payload is a TRIGGER, not a value source — `repaintCash()` reads the canonical value from `currentSession.portfolio_metrics.cash` (with `getLastPublished('portfolio:updated').cash` as the cold-open backstop). Publishers MUST atomically mutate `currentSession.portfolio_metrics.cash` BEFORE calling `bus.publish('portfolio:updated', ...)` so the next reader path lands on a fresh canonical value. See `docs/decisions/trade-ticket-render-on-read.md`.
- `docs/decisions/trade-ticket-render-on-read.md` — new (commit 2). One page. Header `# Decision — Trade Ticket render-on-read (canonical store; bus events as triggers)`. Sections:
  - **Context:** three iterations on `#tt-cash-balance` (v1, iter 7b36, v2). v2 always-on subscriber regressed `journey-05:447-463`. Cite the v3 source doc and the parent ADR `docs/decisions/dashboard-event-bus.md`.
  - **Decision:** the panel owns its read. `getCanonicalCash()` is the only reader. `repaintCash()` is the only writer. Bus events trigger repaints; payloads are not trusted by the panel.
  - **Atomic-mutate-then-publish contract:** every `bus.publish('portfolio:updated', ...)` MUST be preceded by a write to `currentSession.portfolio_metrics.cash`. Audit by `grep -rn "bus.publish.'portfolio:updated" dashboard/` before merging any future change to this surface.
  - **Out of scope:** other panels, `renderOnRead.js` extraction, server contract.
  - **Why not a source predicate or dedicated event (v3 doc Approach scoring table):** new conventions lint can't enforce; the next forgetful publisher trips the test poison through.
- `tests/dashboard/trade-ticket-render-on-read.spec.js` — new (commit 2). Node `--test`, ~120 LOC. Cases per the v3 doc's Validation section:
  - `getCanonicalCash()` returns `currentSession.portfolio_metrics.cash` when set.
  - `getCanonicalCash()` falls back to `bus.getLastPublished('portfolio:updated').cash` when `currentSession.portfolio_metrics` is undefined.
  - `getCanonicalCash()` returns `undefined` when both sources are empty.
  - `repaintCash()` writes nothing when canonical is `undefined`.
  - `repaintCash()` writes nothing when canonical is `NaN`.
  - `bus.publish('portfolio:updated', { cash: 999999 })` while `currentSession.portfolio_metrics.cash === 94846.45` → `#tt-cash-balance.textContent === '$94,846.45'` (poison ignored — the contract).
  - `bus.publish('portfolio:updated', { cash: 88000 })` while `currentSession.portfolio_metrics.cash === 88000` → `repaintCash()` writes `'$88,000.00'`.
  - Test scaffolding: minimal jsdom or `globalThis.document` stub with a `<span id="tt-cash-balance">--</span>` element; minimal `window.finletBus` mock with `subscribe`/`publish`/`getLastPublished`. Pattern available in nearby specs (sibling files in `tests/dashboard/` already use `node --test`).
- `tests/dashboard/trade-ticket-panel-mirror.spec.js` — deleted by commit 1 (via `git revert`). The plan does NOT issue an explicit deletion — the revert removes the file because it was net-added in the v2 merge. After commit 1, `ls tests/dashboard/trade-ticket-panel-mirror.spec.js` MUST return "No such file."
- `tests/e2e/journey-05-trade.spec.ts` — modified (commit 2).
  - **DO NOT TOUCH `:447-463`** (the poison-publish-after-close assertion). This is the regression contract that v3 makes pass by construction; weakening it would invalidate the v3 design proof.
  - **ADD** a new test inside the same `describe` block (sibling to the existing test at `:389`) named something like `'closed-then-reopened panel after fill shows fresh cash within 3s'`. The new test:
    1. Runs a MARKET BUY 1 share trade through the existing trade flow (or reuses the helper that the iter 7b36 retest envelope already exposes).
    2. Waits for the `order:filled` SSE bus event (or `tradePanel` close confirmation, whichever the existing helper exposes).
    3. Calls `closeTradeTicket()` → `openTradeTicket()` within 3s.
    4. Asserts `#tt-cash-balance.textContent === #cash-value.textContent` within $0.01 (parse both, compute absolute diff).
  - The implementer should match the existing test's helper conventions (`openPanel()`, `closePanel()` from the test at `:389`).

**Prerequisite operation (commit 1):**

```
git revert -m 1 1cd2b5b --no-edit
```

- `-m 1` because `1cd2b5b` is a true merge commit (`Merge: 5d6039c c712d98`) — `-m 1` selects the mainline parent (`5d6039c`).
- `--no-edit` accepts the auto-generated revert message verbatim. DO NOT edit it; the orchestrator's per-team merge gate matches against the auto-generated revert message format.
- Post-revert verification (run BEFORE commit 2):
  - `grep -n "always-on" dashboard/trade-ticket.js` → returns 0 lines (the v2 subscriber comment block is gone).
  - `grep -n "Always-on subscriber convention" dashboard/event-contract.md` → returns 0 lines.
  - `ls tests/dashboard/trade-ticket-panel-mirror.spec.js` → "No such file or directory."
  - `git diff HEAD~1 HEAD --stat` → exactly 4 files (the same 4 files v2 touched, in reverse).

**Implementation operation (commit 2):**

All v3 changes (modifications + new files) in ONE commit. Commit message:

```
[Team A]: dashboard/trade-ticket: render-on-read v3 (canonical reader; close trade-ticket-stale-cash recurrence)

Source: docs/refactor/trade-ticket-state-sync-v3/plan.md
Doc:    docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md
ADR:    docs/decisions/trade-ticket-render-on-read.md (new)

Pattern: render-on-read. paintCash(cash) -> repaintCash() (no arg).
getCanonicalCash() reads currentSession.portfolio_metrics.cash with
bus last-published cache fallback. Bus events are repaint triggers,
not value carriers. The v2 always-on subscriber is gone (reverted in
commit 1). journey-05:447-463 poison-cash assertion passes by
construction — the panel never reads payload values.

Atomic-mutate-then-publish contract: every bus.publish('portfolio:updated', ...)
is preceded by a write to currentSession.portfolio_metrics.cash.
Audited 3 publishers (app.js:1472, app.js:1608, trade-ticket.js:484).

Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>
```

**Deliverable:** A two-commit chain on Team A's worktree, mergeable to main, that:

- Reverts v2 (commit 1).
- Lands the v3 render-on-read pattern (commit 2).
- Has all listed validation green.

**Validation (run in this order; ALL must pass before declaring done):**

- [ ] `git log --oneline -3` shows commit 2 on top, commit 1 (the revert) directly below, and `c9b9fc5` (current main) below that. Commits MUST be separate (not squashed).
- [ ] `grep -n 'paintCash(' dashboard/trade-ticket.js` returns ZERO matches (`paintCash` is gone; only `repaintCash()` and `getCanonicalCash()` remain).
- [ ] `grep -n 'finletBus.subscribe.*portfolio:updated' dashboard/trade-ticket.js` returns EXACTLY ONE match — and that match is inside `dialogStateMirror`'s per-open registration, NOT a top-level always-on subscriber. (Pre-v3 baseline: also 1 match in the per-open mirror; the v2 subscriber was an additional one. After v3: back to 1.)
- [ ] `ls tests/dashboard/trade-ticket-panel-mirror.spec.js` returns "No such file or directory."
- [ ] `cat docs/decisions/trade-ticket-render-on-read.md | head -5` includes a `# Decision —` line.
- [ ] `grep -n 'render-on-read' dashboard/event-contract.md` returns at least one match (the new note is present).
- [ ] `node --test tests/dashboard/trade-ticket-render-on-read.spec.js` passes (all cases above).
- [ ] `npx playwright test tests/e2e/journey-05-trade.spec.ts` — entire file green. Specifically the test at `:389` MUST pass — including the poison-publish-after-close at `:447-463` AND the new closed-then-reopened post-fill assertion.
- [ ] `bash scripts/lint-trusted-types.sh` passes (no `.innerHTML` drift in the diff; v3 uses only `textContent` on `#tt-cash-balance`).
- [ ] **Atomic-mutate-then-publish audit:** `grep -rn "finletBus.publish.'portfolio:updated" dashboard/` returns 3 matches. For EACH match, verify (manually or via test) that the same code path mutates `currentSession.portfolio_metrics.cash` BEFORE the `publish` call:
  - `dashboard/app.js:1472` — preceded by mutation at `:1456-1466`. CLEAN (verified during recon).
  - `dashboard/app.js:1608` — preceded by mutation at `:1595-1605`. CLEAN (verified during recon).
  - `dashboard/trade-ticket.js:484` (or whatever line it lands on post-revert+v3) — preceded by mutation at `:463-477`. CLEAN (verified during recon).
  - If a 4th publisher appears in the diff that does NOT mutate first, STOP and report. The v3 contract is violated.
- [ ] `git status` is clean before exiting the worktree.

**Agent instructions:**

- Work in the worktree assigned to you. Do not touch other branches.
- Commits MUST be split exactly as specified:
  - Commit 1: `git revert -m 1 1cd2b5b --no-edit` (auto-generated message; do not edit).
  - Commit 2: the v3 changes, with the commit message above (heredoc-passed).
- After both commits land, you MUST `git add` everything (no stragglers) and verify `git status` is clean before exiting your worktree.
- Per CLAUDE.md, the `dashboard/event-contract.md` and `docs/decisions/trade-ticket-render-on-read.md` updates MUST go in commit 2 alongside the code change. Do not split them into a separate commit.
- **Atomic-mutate-then-publish audit (Risk 1 from the v3 doc):** after the code change but before declaring done, run:
  ```
  grep -rn "finletBus.publish.'portfolio:updated" dashboard/
  ```
  Verify EVERY hit is preceded (in the same code path, within the same function or IIFE) by a write to `currentSession.portfolio_metrics.cash`. If a publisher is found that does not mutate first, STOP and report — that's a contract violation v3 cannot ignore. The pre-implementation audit (this plan, recon) found 3 clean publishers; if the count changes, investigate.
- Do NOT weaken or modify `tests/e2e/journey-05-trade.spec.ts:447-463` (the poison-cash assertion). The new closed-then-reopened post-fill assertion goes in a SIBLING test inside the same `describe` block, not by changing `:447-463`.
- If any validation fails after commit 2, do NOT amend — write commit 3 to fix and explain in the commit message. The orchestrator's merge gate accepts up to N≥2 commits per team.
- Decision-record drift guard (Risk 5): before declaring done, run `grep -l render-on-read docs/decisions/`. The new file must be present in the result.

---

## Risk Register

Sourced from the v3 doc's `## Risks` section (1-5). Each is restated with concrete mitigation tied to the validation steps above. No new risks invented.

**Risk 1 — `currentSession.portfolio_metrics.cash` not updated atomically with bus publish on some path.**
- Source-doc claim: 3 publishers audited as atomic-mutate-then-publish (`app.js:1472`, `app.js:1608`, `trade-ticket.js:484`).
- Recon-confirmed: same 3 publishers, same atomicity. See "Atomic-mutate-then-publish audit" verification step in Validation.
- Mitigation: the audit is a hard gate in Validation. If a 4th publisher appears in the diff or in any future change without a preceding mutation, the agent MUST stop and re-open this doc.

**Risk 2 — `currentSession` is null at first paint.**
- v1's `primeFromCache` already handles this; `repaintCash()` returns silently when `getCanonicalCash()` is undefined. The DOM keeps its initial `--` until either `currentSession` populates or the bus cache primes.
- Mitigation: explicit unit-spec case `getCanonicalCash() returns undefined when both sources are empty` and `repaintCash() writes nothing when canonical is undefined`.

**Risk 3 — `repaintCash` called from a closed panel paints the persistent DOM with stale-but-canonical cash.**
- Source doc explicitly classifies this as a non-issue: "stale-but-canonical" is "fresh as of the last publish." All publishers atomic-mutate-then-publish, so there is no race window where the canonical value disagrees with the just-published value.
- Mitigation: covered by Risk 1's audit. If any publisher emits a publish without mutating first, this risk activates — the audit catches it.

**Risk 4 — A future read-only consumer outside the panel reads `#tt-cash-balance.textContent` directly.**
- No such consumer exists today. journey-05's poison test reads `#tt-cash-balance.textContent` specifically to verify the inverse contract.
- Mitigation: documented in the new ADR as an out-of-scope concern. The right answer if a future consumer needs always-fresh cash is for THAT consumer to read `getCanonicalCash()` (or `currentSession.portfolio_metrics.cash`) directly, not to hook `#tt-cash-balance`.

**Risk 5 — Decision-record drift.**
- The new ADR `docs/decisions/trade-ticket-render-on-read.md` MUST land in the same commit as the code change (CLAUDE.md doc-touch rule).
- Mitigation: the plan's commit-2 file list explicitly includes the ADR. Validation step `cat docs/decisions/trade-ticket-render-on-read.md | head -5` enforces presence. Pre-merge audit `grep -l render-on-read docs/decisions/` is mandated in Agent instructions.

## Session Plan

### Session 1

- **Sequential:** Team A (only team). Two commits on the worktree (`git revert -m 1 1cd2b5b --no-edit` then v3 implementation), then merge to main, then per-merge gate validation.
- **Merge gate after Team A:** all "Validation" checkboxes above pass. Specifically:
  1. journey-05 e2e file green (including `:389` and `:447-463`).
  2. New `tests/dashboard/trade-ticket-render-on-read.spec.js` green.
  3. No `paintCash(` callsite remains anywhere in `dashboard/`.
  4. The atomic-mutate-then-publish audit returns exactly 3 clean publishers.
  5. ADR exists; event-contract.md note exists; v2 spec is gone.
- **Session checkpoint:** push to `origin/main`. Wait for `gh run list --branch main --limit 1` to show `conclusion: success`.
  - **If deploy fails the same way v2 failed (`journey-05-trade.spec.ts:389` red on the deployed build):** STOP. That is a v3 design failure, not a flaky test. Re-open `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md`, mark it `regressed`, do NOT retry. Trigger a v4 doc draft on the next bug-hunt iteration.
  - **If deploy fails for an unrelated reason** (e.g., infra timeout, package install): retry once. If it fails twice in a row, STOP and surface the failure to the orchestrator.

### Post-merge: refactor-queue housekeeping

After Team A's merge to `main` and a successful deploy:

- Edit `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v3.md` frontmatter:
  - `status: shipped`
  - `shipped_at: 2026-05-02`
  - `shipped_in: <merge SHA>`
- Edit `docs/bug-hunt/refactor-queue/trade-ticket-state-sync-v2.md` frontmatter — append a `superseded_by: trade-ticket-state-sync-v3.md` field.
- Verdict (`effective | incomplete | regressed`) is set in the NEXT bug-hunt iteration's triage; do NOT set it now.

(The above housekeeping is part of `/exec-plan`'s post-merge script, not Team A's deliverable. Documented here for the orchestrator.)
