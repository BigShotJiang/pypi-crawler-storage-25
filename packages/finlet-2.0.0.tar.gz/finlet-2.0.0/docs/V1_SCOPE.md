---
tags: [finlet, scope, v1, requirements]
keywords: Finlet V1, scope, MVP, requirements, launch checklist
priority: normal
---

# Finlet v1 Scope

> What's in, what's out, and why.

Finlet v1 is a **daily-timeframe, US-equities, long-only agent evaluation harness**. Every scope boundary below is an intentional design choice for this use case — not a gap waiting to be filled.

---

## Positioning

Finlet is not a backtester. As a backtester, it would lose to QuantConnect on every metric — data coverage, asset classes, speed, community size. As an **agent evaluation harness**, it has no direct product competitor.

The core question Finlet answers: *"Given the same information a human analyst would have had on this date, does my AI agent make sound decisions?"*

### Competitive Differentiators

| Capability | Finlet | Competitors |
|---|---|---|
| **Date Ceiling Enforcer** | Runtime defense-in-depth stripping of future data from every plugin response. Property-based tests prove no future item passes. | No equivalent. Backtesters trust the strategy code not to peek ahead. |
| **SHA-256 Reasoning Trace** | Every agent action logged with tamper-evident checksums — what was queried, what was returned, why the agent acted. | No backtester tracks agent reasoning. Academic benchmarks (AI-Trader, InvestorBench) log actions but without tamper detection. |
| **Cross-Scenario Leaderboard** | Standardized evaluation across multiple scenarios with composite scoring on returns, risk, drawdown, reasoning quality, and information efficiency. | No production tool evaluates agents across standardized scenarios with reasoning as a scoring dimension. |
| **MCP Native** | Purpose-built MCP surface so LLMs connect directly as trading agents. | QuantConnect has 60+ MCP endpoints, but wrapping a backtester — not an evaluation harness. Different product category. |

---

## What's In (v1)

### Timeframe
- **End-of-day (EOD) data only** — daily and weekly intervals
- **Why:** Agent evaluation on daily-timeframe reasoning is the core use case. Intraday tick data tests execution speed, not reasoning quality. Agents making daily allocation decisions don't need sub-second price resolution.

### Asset Coverage
- **US equities only** — stocks listed on major US exchanges
- **Why:** US equities have the deepest data coverage (S3 Parquet data lake for prices, news, fundamentals, and sentiment; SEC EDGAR filings; FRED economic indicators; Finnhub as fallback for news and fundamentals). Adding asset classes (options, futures, forex, crypto) without equivalent data quality would weaken evaluation integrity.

### Trading Model
- **Long-only** — buy and sell, no short selling
- **Why:** Long-only simplifies portfolio accounting and removes margin/borrow mechanics that are orthogonal to evaluating reasoning quality. An agent that can't reason well long-only won't reason better with shorts.

### Order Execution
- **No partial fills** — orders fill completely or not at all
- **Why:** Partial fill simulation requires order book depth data (Level 2) which is not available in EOD data. Simulating partial fills without real depth data would be theater, not evaluation.

- **No commission** — commission is set to 0
- **Why:** Commission modeling is straightforward to add (the `commission` field exists in `SessionConfig`) but adds noise to reasoning evaluation. Commission-aware optimization is an algorithm concern, not a reasoning concern.

- **Fixed slippage model** — 10 bps default, configurable per session
- **Why:** Simple, deterministic slippage prevents the evaluation from being gamed by order timing while remaining predictable for agents.

### Data Sources
- **S3 Parquet data lake (primary)** — historical OHLCV prices (Databento DBEQ.BASIC + Quandl WIKI), quarterly fundamentals, daily news headlines, and analyst sentiment. Default for `price`, `fundamentals`, `news`, and `sentiment` plugin types.
- **SEC EDGAR** — 10-K, 10-Q, 8-K, 13-F, Form 4 filings
- **FRED** — GDP, unemployment, CPI, interest rates (with ALFRED vintage dates for point-in-time accuracy)
- **Finnhub (fallback only)** — company news and fundamentals, used only when the S3 plugins are unavailable. Price queries do not route through Finnhub.

### Infrastructure
- **Authentication** — email/password, Google OAuth, API keys, MFA (TOTP + SMS)
- **Billing** — Stripe integration with free/builder/insights/enterprise tiers
- **Marketplace** — strategy listing, developer onboarding, admin moderation (behind feature flag)
- **Dashboard** — multi-page web UI with real-time SSE updates, TradingView charts
- **Leaderboard** — public agent rankings with composite scoring

---

## What's Out (v1)

### Live / Paper Trading
- **Not included.** Finlet is an evaluation harness, not a trading platform. Connecting to a broker would shift the product into a regulated space with different compliance requirements and away from the core value proposition.

### Intraday Data
- **Not included.** Tick-level and minute-bar data tests execution timing, not reasoning. The evaluation question is "did the agent make a sound decision with available information?" — not "did it react faster than other agents?"

### Multi-Asset (Options, Futures, Forex, Crypto)
- **Not included.** Each asset class requires different data sources, different portfolio accounting (margin, expiration, settlement), and different evaluation criteria. Adding them without equivalent data quality and accounting rigor would weaken evaluation integrity.

### Short Selling
- **Not included.** Short selling introduces margin requirements, borrow costs, and forced liquidation mechanics. These are execution concerns, not reasoning concerns. An agent's ability to reason about when to sell a position it owns is already tested by the long-only model.

### Partial Fills
- **Not included.** Realistic partial fill simulation requires order book depth data, which is not available at the EOD data level. Binary fill/no-fill is honest about what the data supports.

### Point-in-Time Fundamentals (Historical)
- **Limited.** Fundamentals data (balance sheets, income statements) is current, not historical point-in-time. Within 30 days of real time this is accurate; beyond 30 days the MCP tool rejects the request with an explanation. This is a known limitation documented in the reasoning trace with a `_data_warning` annotation.

---

## v1 Validation

- ~2,073 tests across 93 files, including property-based fuzzing with Hypothesis
- Property-based tests prove the Date Ceiling Enforcer never passes a future-dated item
- E2E tests cover the full workflow: register, create session, advance time, submit orders, check portfolio
- Plugin resilience tests cover timeout, 500, and malformed-data handling for all data sources
- CI pipeline: Gitleaks, ruff lint, Bandit, Semgrep, mypy, pip-audit, pytest

---

## Future Directions (Not Committed)

These are areas under consideration for future versions. None are committed or scheduled.

- Intraday intervals (1h, 15m, 5m) with appropriate data sources
- Additional asset classes with full accounting support
- Short selling with margin modeling
- Point-in-time fundamentals via historical snapshot data
- Real historical data for benchmark scenarios (replacing synthetic random walk)
- Live/paper trading integration (separate product surface)
