# Finlet Marketplace — Architecture Specification (v3)

> **Verified signals from AI trading agents.** The leaderboard doesn't care who you are.

The Finlet Marketplace is a signal relay and distribution platform built on top of Finlet's time-locked simulation engine. Strategy makers run their own AI trading agents, backtest them on Finlet's verifiable infrastructure, and publish trade signals to subscribers. Finlet never executes strategies — it **verifies** and **distributes**.

---

## Core Model: Trust + Relay

Finlet is not an execution platform. It is a **trust and distribution layer**.

```
Strategy Maker                    Finlet                         Buyer
(runs their own agent)     (verify + relay + pay)          (receives signals)
      │                           │                              │
      ├── backtest on Finlet ────►│ verified track record        │
      │   (date ceiling enforced) │ (can't be faked)             │
      │                           │                              │
      ├── signal: BUY AAPL $187 ─►│──── relay (<5s SLA) ───────►│
      │                           │                              │
      │                           │◄─── $X/mo subscription ─────┤
      │◄── payout (70%) ─────────┤     (Stripe Connect)         │
```

**Key principle:** Finlet never runs anyone's strategy. Finlet never pays for anyone's AI API calls. Strategy makers bear their own compute costs — they're already running these agents for their own trading. Publishing signals to Finlet is pure incremental revenue.

### Why This Architecture

| Alternative | Why not |
|------------|---------|
| **Downloadable config files** | Copy-and-cancel: buyer copies strategy, unsubscribes. Dead business model. |
| **Hosted execution** | Finlet pays AI API costs ($5-25/strategy/month), needs sandboxing, Docker containers, massive infra. |
| **Hosted + auto-trade** | All of the above + broker-dealer registration ($5-15K), compliance overhead. |
| **Signal relay (chosen)** | Zero execution cost, zero API cost, zero sandboxing, IP protected, strong margins. |

### What Finlet Provides

| Role | How |
|------|-----|
| **Verification** | Makers backtest on Finlet's time-locked simulation. Date ceiling enforcer guarantees track records can't be faked. This is the moat. |
| **Signal relay** | Maker pushes signals to Finlet API. Finlet fans out to all subscribers via webhook/push/dashboard within 5 seconds. |
| **Payments** | Stripe Connect handles subscriptions, revenue splits, payouts, and KYC. |
| **Performance tracking** | Compare live signals against backtested performance. Auto-flag divergence. |
| **Trust** | Leaderboard, reviews, verified track records. Buyers trust Finlet's verification, not the maker's claims. |

---

## Strategy Categories

Strategies are classified by holding period. Each category has different backtesting requirements for listing.

| Category | Typical hold | Min backtest period | Min trades | Rationale |
|----------|-------------|-------------------|------------|-----------|
| **Day Trading** | < 1 day | 90 days | 100 trades | Full quarter, statistical significance at 100+ trades. |
| **Long-term** | 30+ days | 5 years | 30 trades | Full market cycle. 30 trades is borderline but realistic for long-hold strategies. |

**Why these bars are high:** More friction for sellers, minimal friction for buyers. The simulation compresses years of backtesting into hours, so the time requirement costs makers compute time — not calendar time. Buyers see a listing and know: *"This survived 5 years and 30+ trades on time-locked data that can't be faked."*

Swing trading (1-30 day holds) is a planned future category.

---

## Signal Format

Signals use **progressive disclosure** — action first, details on demand.

### Top-level (always visible)

```
BUY   AAPL   $187.50   |   Confidence: 82%
```

### Expanded (click to reveal)

```
Risk Metrics
  Max drawdown:    4.2%
  Position size:   3% of portfolio
  Risk/reward:     1:2.8

Reasoning (if maker opted in)
  "AAPL showing strong support at $185 with RSI oversold on 4H timeframe.
   Earnings catalyst in 12 days. Sector rotation into tech accelerating."
```

**Reasoning is opt-in for the maker.** Showing reasoning builds buyer trust and differentiates the strategy, but it partially exposes the strategy logic. Makers choose whether to publish reasoning with each signal.

### Signal Schema

```python
class Signal(SQLModel, table=True):
    id: str                        # UUID
    strategy_id: str               # FK to StrategyListing
    ticker: str                    # e.g., "AAPL"
    direction: str                 # "BUY" | "SELL"
    price: float                   # Target price
    confidence: float | None       # 0.0-1.0, optional
    risk_metrics: dict | None      # Max drawdown, position size, risk/reward
    reasoning: str | None          # Only if maker opted in
    created_at: datetime           # Server-side timestamp (UTC)
    received_at: datetime          # When Finlet received it (UTC)
    delivered_at: datetime | None  # When fanout completed (UTC)
```

---

## Data Model

All marketplace data lives in a dedicated `marketplace.db` (SQLite via aiosqlite + SQLModel), separate from session databases.

### DeveloperProfile

```python
class DeveloperProfile(SQLModel, table=True):
    id: str                        # UUID
    user_id: str                   # FK to auth system
    display_name: str              # Public name
    bio: str | None                # Public bio
    stripe_account_id: str         # Stripe Connect account (KYC handled by Stripe)
    verified: bool                 # Stripe identity verification complete
    banned: bool                   # ID-banned from marketplace
    ban_reason: str | None
    created_at: datetime
    updated_at: datetime
```

### StrategyListing

```python
class StrategyListing(SQLModel, table=True):
    id: str                        # UUID
    developer_id: str              # FK to DeveloperProfile
    name: str                      # Strategy display name
    description: str               # Public description
    category: str                  # "day_trading" | "long_term"
    price_cents: int               # Monthly subscription price in cents (maker sets)
    status: str                    # "draft" | "backtesting" | "in_review" | "published" | "suspended"
    show_reasoning: bool           # Whether signals include reasoning text
    backtest_session_id: str       # FK to Finlet session used for verification
    backtest_metrics: dict         # Cached: sharpe, max_drawdown, win_rate, total_return, trade_count
    leaderboard_entry_id: str | None  # FK to leaderboard
    subscriber_count: int          # Cached count
    created_at: datetime
    updated_at: datetime
    published_at: datetime | None
```

### Subscription

```python
class Subscription(SQLModel, table=True):
    id: str                        # UUID
    buyer_user_id: str             # FK to auth system
    strategy_id: str               # FK to StrategyListing
    stripe_subscription_id: str    # Stripe subscription ID
    status: str                    # "active" | "paused" | "cancelled"
    webhook_url: str | None        # Buyer's webhook for signal delivery
    paused_reason: str | None      # e.g., "maker_offline"
    created_at: datetime
    cancelled_at: datetime | None
```

### Payout

```python
class Payout(SQLModel, table=True):
    id: str                        # UUID
    developer_id: str              # FK to DeveloperProfile
    amount_cents: int              # Payout amount
    stripe_transfer_id: str        # Stripe transfer ID
    period_start: datetime
    period_end: datetime
    status: str                    # "pending" | "paid" | "failed"
    created_at: datetime
```

### Review

```python
class Review(SQLModel, table=True):
    id: str                        # UUID
    strategy_id: str               # FK to StrategyListing
    buyer_user_id: str             # FK to auth system
    rating: int                    # 1-5
    comment: str | None
    verified_subscriber: bool      # True if reviewer has/had active subscription
    created_at: datetime
```

### FallbackContract

```python
class FallbackContract(SQLModel, table=True):
    id: str                        # UUID
    developer_id: str              # FK to DeveloperProfile
    category: str                  # "day_trading" | "long_term" — one fallback per category
    strategy_id: str               # FK to StrategyListing (the fallback strategy)
    retainer_cents: int            # Monthly retainer payment in cents
    fallback_rate_cents: int       # Per-minute rate when actively serving as fallback
    uptime_sla: float              # Required uptime (e.g., 0.999 = 99.9%)
    status: str                    # "active" | "breached" | "terminated"
    activated_minutes: int         # Total minutes served as fallback (billing counter)
    created_at: datetime
    updated_at: datetime
```

---

## API Endpoints

Base URL: `http://localhost:8000/marketplace`

All endpoints require authentication. Follow existing REST API patterns.

### Browse & Discovery

- `GET /marketplace/strategies` — List/search/filter strategies (category, price range, performance, sort)
- `GET /marketplace/strategies/{id}` — Strategy details + backtested metrics + live performance
- `GET /marketplace/strategies/{id}/signals` — Recent signals (subscribers only)
- `GET /marketplace/strategies/{id}/reviews` — Reviews and ratings
- `GET /marketplace/strategies/{id}/performance` — Backtested vs live performance comparison

### Subscriptions (Buyer)

- `POST /marketplace/strategies/{id}/subscribe` — Subscribe (creates Stripe subscription)
- `DELETE /marketplace/strategies/{id}/subscribe` — Cancel subscription
- `GET /marketplace/subscriptions` — List my active subscriptions
- `PUT /marketplace/subscriptions/{id}/webhook` — Set/update webhook URL for signal delivery

### Developer Portal

- `POST /marketplace/developer/register` — Register as maker (initiates Stripe Connect onboarding)
- `GET /marketplace/developer/profile` — My developer profile
- `PUT /marketplace/developer/profile` — Update profile
- `GET /marketplace/developer/strategies` — My strategy listings
- `POST /marketplace/developer/strategies` — Create new listing (draft)
- `PUT /marketplace/developer/strategies/{id}` — Update listing
- `POST /marketplace/developer/strategies/{id}/submit` — Submit for review (triggers backtest verification)
- `GET /marketplace/developer/revenue` — Revenue dashboard (earnings, subscribers, payouts)

### Signal Ingestion (Maker)

- `POST /marketplace/signals` — Push a new signal (authenticated by maker's API key)
- `GET /marketplace/signals/heartbeat` — Signal heartbeat status

### Fallback Management (Admin)

- `POST /marketplace/admin/fallback` — Create fallback contract (assign fallback strategist per category)
- `GET /marketplace/admin/fallback` — List active fallback contracts
- `PUT /marketplace/admin/fallback/{id}` — Update contract terms
- `DELETE /marketplace/admin/fallback/{id}` — Terminate fallback contract
- `GET /marketplace/admin/fallback/{id}/usage` — Fallback activation history and billing

### Admin / Moderation

- `GET /marketplace/admin/review-queue` — Strategies pending review
- `POST /marketplace/admin/strategies/{id}/approve` — Approve listing
- `POST /marketplace/admin/strategies/{id}/reject` — Reject with reason
- `POST /marketplace/admin/developers/{id}/ban` — Ban developer (freezes payouts)

### Error Handling

Follow existing patterns — specific, actionable error messages:
- `402` — Subscription required (buyer trying to access subscriber-only endpoint)
- `403` — Not strategy owner / not authorized
- `409` — Strategy already in review / already subscribed
- `422` — Backtest requirements not met (e.g., "Day trading strategies require minimum 90 days and 100 trades. Your backtest has 45 days and 67 trades.")
- `429` — Signal submission rate limit exceeded
- `503` — Stripe Connect unavailable

---

## Signal Relay System

### Ingestion

Makers push signals via authenticated API call:

```
POST /marketplace/signals
Authorization: Bearer <maker_api_key>

{
    "strategy_id": "...",
    "ticker": "AAPL",
    "direction": "BUY",
    "price": 187.50,
    "confidence": 0.82,
    "risk_metrics": {"max_drawdown": 0.042, "position_size": 0.03},
    "reasoning": "AAPL showing strong support at $185..."
}
```

Server timestamps the signal on receipt (`received_at`). The maker's local timestamp is logged but the server timestamp is authoritative.

### Distribution

Fanout to all active subscribers within **< 5 seconds SLA**:

1. Signal received → stored in `marketplace.db`
2. Query all active subscriptions for this strategy
3. For each subscriber:
   - If webhook configured → POST to webhook URL (async, with retry)
   - Always available via polling on `GET /marketplace/strategies/{id}/signals`
4. Record `delivered_at` timestamp

**Fallback routing:** When a fallback is active for a category, the fallback strategy's signals are also fanned out to all subscribers of offline strategies in that category. Fallback signals include a `fallback: true` flag and `original_strategy_id` so the buyer's system can distinguish them.

Future channels: WebSocket push, email digest (daily summary), mobile push notifications.

### Delivery Latency Tracking

For day trading strategies, latency matters. Track and display:
- `received_at - created_at` — maker-to-Finlet latency
- `delivered_at - received_at` — Finlet relay latency
- Average relay latency displayed on strategy listing page

---

## Heartbeat & Uptime Monitoring

### Maker Heartbeat

Makers are expected to submit a heartbeat or signal at regular intervals based on category:

| Category | Max silence before fallback | Max silence before auto-pause |
|----------|---------------------------|------------------------------|
| Day trading | 4 hours (market hours) | 24 hours |
| Long-term | 7 days | 30 days |

### Downtime Flow with Fallback

```
Normal:       Strategy "AlphaEdge" ──► signals to buyer
                   ↓ (silence threshold exceeded)
Fallback:     "Finlet SafeGuard" ──► signals to buyer (auto-switch)
                   ↓ (AlphaEdge comes back online)
Resume:       Strategy "AlphaEdge" ──► signals to buyer (auto-switch back)
```

1. Silence threshold exceeded → **activate fallback** for this category
2. Fallback strategy signals are relayed to all affected subscribers
3. Buyer notified: *"AlphaEdge is temporarily offline. Finlet SafeGuard signals are active until service resumes. Your subscription billing is unaffected."*
4. Maker notified: *"Your strategy has been inactive. Fallback signals are being served to your subscribers."*
5. Fallback activation minutes are logged for billing
6. If maker resumes within auto-pause window → auto-switch back to primary, notify buyer
7. If silence exceeds auto-pause threshold → pause subscriptions, pause billing, fallback stops

**Fallback signals are visually distinct** in the buyer dashboard — tagged with a "Fallback active" indicator so the buyer always knows the source.

### Fallback System

One **Official Fallback Partner** per strategy category. The fallback is not a regular marketplace strategy — it operates under a special contract with different terms.

#### Fallback Design Philosophy

The fallback's job is **not to make money — it's to not lose money.** Fallback strategies must be deliberately conservative:

| Category | Fallback profile |
|----------|-----------------|
| Day trading | Conservative, low-drawdown, high-frequency. Capital preservation, not alpha generation. |
| Long-term | Broad index-tracking signals. Boring and safe. |

A buyer subscribed to an aggressive day trading strategy should not suddenly receive high-risk signals from a fallback with a completely different risk profile. The fallback is a backup goalkeeper — keep the ball out of the net until the starter returns.

#### Fallback Contract Terms

Unlike regular makers (70/30 rev share, self-serve), fallback partners operate under a negotiated contract:

| Term | Details |
|------|---------|
| **Compensation** | Monthly retainer + per-minute rate when actively serving as fallback |
| **SLA** | 99.9% uptime commitment. Breach → contract termination. |
| **Infrastructure** | Redundant signal generation, automated monitoring, no single point of failure |
| **Exclusivity** | One fallback per category. The value proposition is guaranteed exposure to every subscriber on the platform during any downtime event. |
| **Backtesting** | Must pass the same category-specific backtest requirements as regular strategies |
| **Selection** | Chosen by Finlet based on track record, reliability, and conservative risk profile |

#### What the Fallback Partner Gets

The fallback gets something no regular marketplace maker can buy: **guaranteed distribution to every subscriber on the platform** during downtime. Every time any strategy in their category goes offline, their signals fill the gap. This is massive exposure for building reputation and driving their own marketplace subscriptions.

---

## Risk Mitigations

### Front-running Prevention

- Server-side timestamps on all signals (maker cannot backdate)
- Log delta between signal generation and API submission
- ToS prohibits front-running: maker must not trade on a signal before publishing
- Violation = permanent ban + payout freeze (Stripe Connect account deactivated)
- Maker's real identity is on file via Stripe KYC

### Identity & Accountability

- **Stripe Connect onboarding** handles all KYC: government ID, tax info (W-9/W-8BEN), bank account
- ID-ban = Stripe account deactivated + Finlet account banned
- Escalation path to legal if needed (real identity on file)
- Zero additional cost — KYC is baked into Stripe's platform

### Signal Quality Monitoring

- Track live signal performance vs backtested track record
- Auto-flag strategies where live performance diverges > 2 standard deviations from backtested metrics
- Divergence flag visible to buyers on strategy listing
- Severe divergence → auto-suspend listing pending review

### IP Protection

- Strategy logic never leaves the maker's infrastructure
- Buyers receive signals (ticker, direction, price) — not the underlying reasoning engine
- Reasoning text is opt-in and controlled by the maker
- Reverse-engineering AI-driven strategies from signals alone is impractical — the reasoning is opaque

---

## Revenue Model

### Pricing

- **Maker sets their own price** — market-driven pricing
- No Finlet-imposed price floor or ceiling
- Monthly subscription billing via Stripe

### Revenue Split

| Recipient | Share |
|-----------|-------|
| Strategy maker | 70% |
| Finlet platform | 30% |

### Payouts

- Processed via Stripe Connect transfers
- Weekly payout cycle
- $25 minimum payout threshold
- Payout frozen if maker is under review or banned

### Refunds

- No free trials — the leaderboard and public backtested performance serve as evaluation
- Refund requests handled per Stripe's standard dispute process
- Auto-refund if strategy is suspended within first 7 days of a subscriber's billing cycle

---

## Leaderboard Integration

The existing leaderboard is the marketplace's **discovery and trust engine**.

### Verification Flow

1. Maker builds strategy, runs backtesting sessions on Finlet
2. Date ceiling enforcer guarantees no future data leakage — track record is honest
3. Backtest results automatically populate leaderboard entry
4. Leaderboard entry links to marketplace listing (if published)
5. Buyer sees leaderboard → clicks through to strategy → subscribes

### Live Performance Tracking

Once a strategy is published and sending live signals:
- Live signal performance tracked alongside backtested performance
- Both displayed on the strategy listing page
- Divergence between backtested and live is flagged

### Language Requirements

Per SEC AI-washing enforcement and legal requirements:
- All performance references use **"simulated performance"** or **"backtested results"**
- Never say a strategy "outperformed the market" without "in simulation"
- Required disclaimer on all performance displays:

> Past simulated performance does not guarantee future results. Backtested results have inherent limitations: they are designed with the benefit of hindsight, do not reflect actual trading, and cannot account for all factors that affect real market conditions including liquidity, slippage, and market impact.

---

## MCP Tools

New MCP tools for AI agents to interact with the marketplace:

- `search_strategies` — Browse/filter strategies by category, performance, price
- `get_strategy_details` — Get strategy listing details and metrics
- `get_latest_signals` — Get recent signals for a subscribed strategy
- `list_my_subscriptions` — List active subscriptions

Each tool includes clear descriptions and example parameters following existing MCP patterns.

---

## Regulatory Compliance Checklist

Pre-launch legal requirements (from LEGAL_AUDIT.md + marketplace legal analysis):

| Requirement | Status | Est. Cost |
|-------------|--------|-----------|
| Securities counsel opinion on relay/signal model | Required | $5-10K |
| Developer Agreement (strategy makers) | Required | $2-4K (attorney) |
| Marketplace Terms of Service | Required | $2-3K (attorney) |
| Financial disclaimers on all performance displays | Required | $0 |
| Finnhub commercial license upgrade | Required | $49+/month |
| FRED attribution in all data responses | Required | $0 (dev time) |
| US-only launch (EU AI Act compliance deferred) | Recommended | $0 |
| Privacy Policy + data deletion endpoints | Required | $1-2K + dev time |
| DMCA/IP dispute policy | Required | $1-2K (attorney) |

---

## Implementation Priority

### Phase 1 — Foundation (P0 security fixes + data model)

- Fix IDOR: session-to-user ownership checks
- Fix CORS: explicit origin allowlist
- Add auth to all endpoints
- Create `marketplace.db` schema
- Stripe Connect integration

### Phase 2 — Maker Portal

- Developer registration + Stripe onboarding
- Strategy listing CRUD
- Backtest verification flow
- Signal ingestion API

### Phase 3 — Buyer Experience

- Strategy browsing/search/filter
- Subscription flow (Stripe)
- Signal delivery (webhook + polling)
- Signal dashboard

### Phase 4 — Trust & Safety

- Heartbeat monitoring + fallback auto-switch
- Fallback contract management + activation billing
- Live vs backtested divergence detection
- Front-running detection
- Admin moderation tools
- Review/rating system

### Phase 5 — Growth

- Leaderboard ↔ marketplace cross-linking
- MCP tools for AI agent discovery
- Swing trading category
- Additional signal delivery channels (WebSocket, email digest)
