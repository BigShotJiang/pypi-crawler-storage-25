# Finlet — User Manual (Operator + Agent Reference)

> **Canonical source:** the pip-installed CLI manual at `finlet manual`
> (rendered from `finlet/manual/*.md` — the in-tree Markdown files
> shipped with the wheel). This file is the doc-team-owned operator
> reference for cross-cutting clarifications that haven't yet been
> folded into the CLI manual topics. Topics here may be promoted to
> CLI topics in a future cut; until then, both files are consulted.

To browse all available topics from the command line:

```
finlet manual           # topic index
finlet manual quickstart
finlet manual errors    # stable error-anchor catalog
finlet manual --search benchmark
```

CLI topics live in `finlet/manual/`:

- `quickstart.md` — copy-paste setup walkthrough
- `auth-model.md` — OAuth + api_key dual-accept semantics
- `client-matrix.md` — CLI / SDK / MCP coverage
- `plugin-matrix.md` — plugin envelopes + rate-limit anchors
- `transports.md` — stdio / HTTP / SSE transports
- `session-lifecycle.md` — session-state machine
- `errors.md` — stable error-anchor catalog

---

## Benchmark workflow

The benchmark workflow drives a multi-scenario evaluation against your
trading agent. A `benchmark_run` is created via `start_benchmark`, owns
N scenario sessions (each running its own blind universe + clock), and
transitions through `running` → `completed` → optionally `decrypted` →
optionally `published`. See `docs/decisions/benchmark-run-decrypt-publish-gate.md`
for the full state machine and gating invariants.

### Mid-run export wording — `benchmark_run_not_completed` precedence

**Calling `export_benchmark_results` while the run is still in a
non-terminal status (e.g., `running`) returns the error code
`benchmark_run_not_completed` — NOT `assert_run_immutable`.** This is
intentional: the terminal-state check fires before the immutability
assertion, so a non-completed run is reported with the precondition
violation (it is not yet `completed`, so there is nothing to export)
rather than the immutability guard (which is about not mutating a
**completed-and-already-shipped** run). The two error codes are not
interchangeable:

- `benchmark_run_not_completed` — the run hasn't reached terminal
  state yet. Complete the benchmark first by running the remaining
  scenarios via `advance_time` + `complete_session`, then retry the
  export.
- `assert_run_immutable` — the run IS in terminal state but a caller
  is attempting to mutate it (e.g., re-set `status`, or `decrypt` a
  terminal run that's already been published in an incompatible way).
  This is reserved for write-paths against a completed-and-already-
  exported run.

Source of truth: `finlet/leaderboard/reporting.py:build_export_dict`
fires the terminal-state check first; `assert_run_immutable` in
`finlet/leaderboard/benchmark_state.py` is the immutability guard.
A test in `tests/e2e/test_blind_benchmark_zero_leak.py` accepts
EITHER error code as valid mid-run response (per Team C's
`e128990` adjustment in the 2026-05-21 blind-SSE iteration). Codex
retests of mid-run export wording should treat
`benchmark_run_not_completed` as the expected mid-run response and
NOT re-file as a `[5]`-style finding.

### Blind benchmark mode

When `start_benchmark` is called with `blind=True` (the default for
the platform leaderboard), each scenario session runs with a
per-session `BlindMapping` — ticker symbols are substituted with
opaque `T_NNNN` ids and wall-clock dates with `Day_N` offsets so
the agent under evaluation cannot anchor `Day_N` to the actual
calendar.

Two parent rules apply to every response surface that flows out of
a blind session:

1. **Envelope + body fields blind.** Any new ticker or wall-clock-date
   field added to a response surface MUST route through
   `apply_ticker` / `apply_date` from `finlet.core.blind_mapping` —
   not just the items list, the envelope too. See
   `docs/decisions/blind-benchmark-envelope-fields-must-blind.md`.
2. **`benchmark_ticker` is mapped.** The default `benchmark_ticker
   = "SPY"` is now seeded into the per-session `ticker_map` at
   `generate_mapping` time, so `apply_ticker("SPY", mapping)`
   substantively maps `SPY → T_NNNN`. See
   `docs/decisions/blind-benchmark-ticker-must-blind.md` (2026-05-21,
   reverses the prior "SPY is universal" design).

For the full owner-driven lifecycle (`decrypt` + `set_visibility`),
see `docs/decisions/benchmark-run-decrypt-publish-gate.md` and the
ARCHITECTURE.md "Blind Benchmark Lifecycle" subsection.
