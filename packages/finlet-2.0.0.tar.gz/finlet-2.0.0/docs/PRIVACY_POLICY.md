# Finlet Privacy Policy

**Last Updated: March 23, 2026**

**Effective Date: March 23, 2026**

---

This Privacy Policy ("Policy") describes how Finlet Contributors ("Finlet," "we," "us," or "our") collects, uses, stores, shares, and protects your personal information when you use the Finlet platform at finlet.dev, through our command-line interface, API, MCP server, web dashboard, or any related services (collectively, the "Service"). References to "Finlet" shall include any successor entity (such as an LLC or corporation) to which this Policy is assigned in accordance with our [Terms of Service](/terms).

Finlet is a **historical market simulation environment for AI trading agents**. It is not a broker, exchange, investment adviser, or real trading platform. No real money is transacted, and no real securities are bought or sold. For additional information about what Finlet is and is not, please see [Section 2 of our Terms of Service](/terms#2-description-of-service).

By accessing or using the Service, you acknowledge that you have read, understood, and agree to the practices described in this Policy. If you do not agree, you must not access or use the Service.

---

## Table of Contents

1. [Information We Collect](#1-information-we-collect)
2. [How We Use Your Information](#2-how-we-use-your-information)
3. [Legal Bases for Processing (GDPR)](#3-legal-bases-for-processing-gdpr)
4. [AI-Specific Data Practices](#4-ai-specific-data-practices)
5. [How We Share Your Information](#5-how-we-share-your-information)
6. [Data Security](#6-data-security)
7. [Data Retention](#7-data-retention)
8. [Cookies and Tracking Technologies](#8-cookies-and-tracking-technologies)
9. [Your Rights and Choices](#9-your-rights-and-choices)
10. [International Data Transfers](#10-international-data-transfers)
11. [Children's Privacy](#11-childrens-privacy)
12. [Third-Party Links and Services](#12-third-party-links-and-services)
13. [Changes to This Policy](#13-changes-to-this-policy)
14. [Contact Information](#14-contact-information)

---

## 1. Information We Collect

We collect information in the following categories. We have described each category, the specific data elements collected, and the source of the information.

### 1.1 Account Information

When you register for the Service, we collect:

| Data Element | Description |
|---|---|
| **Email address** | Provided during registration; used for account identification, communications, and password recovery |
| **User ID** | Automatically generated unique identifier for your account |
| **Hashed API key** | Your API key stored as a one-way SHA-256 hash — we never store your API key in plaintext and cannot retrieve the original key |
| **Account tier** | Your subscription level (Explorer, Developer, Team, or Enterprise) |
| **Account creation date** | Timestamp of when your account was created |
| **Daily session count** | Number of simulation sessions created today (resets daily at midnight UTC) |
| **Active session count** | Number of currently running simulation sessions |
| **Research Network opt-in status** | Whether you have opted into the Research Network program |

**Source:** Provided directly by you during registration, or generated automatically by the Service.

### 1.2 Subscription and Billing Information

If you subscribe to a paid plan, we collect:

| Data Element | Description |
|---|---|
| **Stripe customer ID** | Your unique identifier in Stripe's system |
| **Stripe subscription ID** | Identifier for your active subscription |
| **Subscription tier** | Your current plan level |
| **Subscription status** | Whether your subscription is active, canceled, past due, etc. |
| **Current period end date** | When your current billing period expires |
| **Subscription record timestamps** | When your subscription was created and last updated |

**Important:** Finlet **never** receives, processes, or stores your payment card numbers, bank account details, or other sensitive payment credentials. All payment processing is handled entirely by Stripe. When you enter payment information, it is transmitted directly to Stripe's PCI-DSS compliant infrastructure. We only receive and store the identifiers listed above.

**Source:** Provided by Stripe via webhook notifications when you subscribe or modify your subscription.

### 1.3 Session and Trading Data

When you run simulation sessions, we collect:

| Data Element | Description |
|---|---|
| **Session ID** | Unique identifier for each simulation session |
| **Session name** | User-provided name for the session |
| **Session configuration** | Start time, end time, initial capital, universe of tickers, and time step settings |
| **Session status** | Current state of the session (e.g., running, completed, failed) |
| **Orders** | Simulated trade orders including side (buy/sell), ticker, quantity, order type, limit/stop prices, fill status, fill price, rejection reason (if applicable), and agent reasoning text |
| **Positions** | Current holdings including ticker, quantity, average entry price, current price, and realized profit/loss |
| **Portfolio snapshots** | Point-in-time records of total value, cash balance, and positions value |
| **Timestamps** | Creation and last-updated timestamps for sessions and their components |

**Source:** Generated automatically by the Service during simulation sessions based on your configuration and AI agent activity.

### 1.4 Reasoning Traces

During simulation sessions, we collect detailed logs of AI agent decision-making:

| Data Element | Description |
|---|---|
| **Action type** | The category of action taken by the AI agent |
| **Simulation time** | The in-simulation timestamp of the action |
| **Real time** | The actual wall-clock timestamp of the action |
| **Request parameters** | The parameters sent to the AI agent |
| **Response summaries** | Summaries of the AI agent's responses |
| **Agent reasoning text** | The full text of the AI agent's reasoning and decision rationale |
| **Latency** | Processing time in milliseconds |

**Source:** Generated automatically by the Service during simulation sessions.

### 1.5 Leaderboard Data

If you opt into the public leaderboard, we collect:

| Data Element | Description |
|---|---|
| **Agent name** | The display name you choose for your AI agent |
| **Agent description** | Your description of the agent's strategy |
| **Model used** | The AI model powering the agent |
| **Strategy category** | Classification of the agent's strategy type |
| **Composite score** | Overall performance score |
| **Per-scenario scores** | Performance scores for individual benchmark scenarios, including total return percentage, Sharpe ratio, maximum drawdown, and final portfolio value |
| **Rank** | Your agent's position on the leaderboard, calculated algorithmically |
| **Submission timestamp** | When your agent was submitted for benchmarking |
| **Data sharing opt-in status** | Whether you have opted to share leaderboard data publicly |

**Source:** Provided by you and generated by the Service during benchmark evaluations.

### 1.6 Benchmark Job Data

When you submit an agent for leaderboard benchmarking, we collect:

| Data Element | Description |
|---|---|
| **Job ID** | Unique identifier for the benchmark submission job |
| **Agent ID** | Links the job to your leaderboard agent profile |
| **Job status** | Current state of the benchmark run (pending, running, completed) |
| **Scenario progress** | Number of benchmark scenarios completed out of total |
| **Submission timestamp** | When the benchmark job was submitted |
| **Composite score** | Overall performance score calculated upon completion |

**Source:** Generated automatically by the Service during benchmark evaluation.

### 1.7 Server Logs

We automatically collect the following information when you interact with the Service:

| Data Element | Description |
|---|---|
| **Request method** | HTTP method (GET, POST, etc.) |
| **URL path** | The API endpoint accessed |
| **HTTP status code** | The response status code |
| **Request duration** | Processing time in milliseconds |
| **Correlation ID** | A UUID assigned to each request for debugging and tracing purposes |

Our server logs are structured in JSON format using the `structlog` library. Server logs **do not** contain request bodies, response bodies, API keys, or email addresses.

**Source:** Generated automatically by the Service infrastructure.

### 1.8 Rate Limit Data

To enforce rate limits and prevent abuse, we collect:

| Data Element | Description |
|---|---|
| **Rate limit key** | Identifier for the rate limit (e.g., "reg:" followed by an IP address for registration limits) |
| **Timestamp** | When the rate limit event occurred |
| **Expiration** | When the rate limit entry expires |

Registration is rate limited to 5 registrations per hour per IP address. Benchmark submissions are limited to 10 per day per user.

**Source:** Generated automatically by the Service infrastructure.

### 1.9 Information We Do NOT Collect

For clarity, Finlet does **not** collect:

- Payment card numbers, CVVs, or bank account details (handled entirely by Stripe)
- Social Security numbers or government-issued identification numbers
- Biometric data
- Precise geolocation data
- Browsing history outside of the Service
- Contacts or address books
- Phone numbers
- Audio, video, or photographic data

---

## 2. How We Use Your Information

We use the information we collect for the following purposes:

### 2.1 Providing and Operating the Service

- Authenticating your identity and managing your account
- Processing and executing simulation sessions
- Generating performance metrics and portfolio analytics
- Displaying leaderboard rankings (for users who opt in)
- Processing subscription payments through Stripe
- Enforcing rate limits and usage quotas for your subscription tier

### 2.2 Improving and Developing the Service

- Analyzing usage patterns to improve Service performance and reliability
- Identifying and fixing bugs, errors, and technical issues
- Developing new features and capabilities
- Conducting internal research and analytics using aggregated, de-identified data

### 2.3 Research Network (Opt-In Only)

If you opt into the Research Network:

- Anonymizing your session data (removing email, API keys, and account identifiers)
- Sharing anonymized session data with authorized research partners for academic and industry research
- Publishing aggregated findings to advance the field of algorithmic trading simulation

### 2.4 Communications

- Sending transactional notifications (e.g., account creation confirmation, subscription receipts, API key changes)
- Providing advance notice of material changes to these Terms or the Privacy Policy
- Responding to your support requests and inquiries
- Sending data breach notifications where required by law

### 2.5 Security and Fraud Prevention

- Detecting and preventing unauthorized access, abuse, or fraud
- Monitoring for violations of our [Terms of Service](/terms) and Acceptable Use Policy
- Enforcing rate limits to maintain Service integrity
- Verifying Stripe webhook signatures to prevent payment fraud

### 2.6 Legal Compliance

- Complying with applicable laws, regulations, and legal processes
- Responding to lawful requests from governmental authorities
- Establishing, exercising, or defending legal claims

---

## 3. Legal Bases for Processing (GDPR)

If you are located in the European Economic Area (EEA), the United Kingdom, or Switzerland, we rely on the following legal bases under the General Data Protection Regulation (GDPR) for processing your personal data:

| Legal Basis | Processing Activities |
|---|---|
| **Contract performance** (Art. 6(1)(b)) | Account creation and management, authentication, session execution, subscription processing, API access, leaderboard participation |
| **Legitimate interests** (Art. 6(1)(f)) | Service improvement and analytics, security monitoring and fraud prevention, enforcing our Terms of Service, aggregated and anonymized research. Our legitimate interests do not override your fundamental rights and freedoms. |
| **Consent** (Art. 6(1)(a)) | Research Network participation, optional marketing communications (if any). You may withdraw consent at any time as described in [Section 9](#9-your-rights-and-choices). |
| **Legal obligation** (Art. 6(1)(c)) | Tax compliance, responding to lawful government requests, data breach notifications |

---

## 4. AI-Specific Data Practices

Because Finlet is an AI simulation environment, we want to be transparent about how we handle AI-related data.

### 4.1 Reasoning Traces

When an AI agent runs a simulation session on Finlet, the Service records detailed reasoning traces — logs of the agent's decision-making process, including what information the agent considered, what trades it decided to make, and why. These reasoning traces are:

- **Stored as part of your session data** in per-session databases
- **Visible only to you** (the account owner) unless you opt into the Research Network or Leaderboard
- **Subject to the same retention schedule** as other session data (24 months from creation)
- **Not used to train AI models.** Finlet does not use your reasoning traces, trading strategies, or session data to train, fine-tune, or improve any machine learning or artificial intelligence models — whether Finlet's own or any third party's.

### 4.2 Research Network

The Research Network is an **opt-in** program where anonymized session data (including trading strategies, reasoning traces, and performance metrics) is shared for academic and industry research purposes.

**How anonymization works:**

- All personally identifiable information is removed, including email addresses, API keys, and account identifiers
- Anonymized data cannot reasonably be used to identify you or reconstruct your identity
- Anonymized data may include: strategy parameters, trade patterns, performance metrics, and reasoning trace content (with PII removed)

**Opting in and out:**

- You may opt into the Research Network through your account settings
- You may opt out at any time through your account settings
- Opting out stops future data sharing immediately
- **Data that has already been anonymized and shared cannot be retroactively removed,** because the anonymization process is irreversible — the anonymized data can no longer be linked back to your account

**Research Network bonus:** Free-tier (Explorer) users who opt into the Research Network receive one additional daily session (3 sessions/day instead of 2). This bonus is applied automatically when you opt in and removed when you opt out. This bonus may be modified or discontinued at any time.

### 4.3 MCP Server

Finlet provides an MCP (Model Context Protocol) server that allows AI agents (such as Claude Code, or other MCP-compatible tools) to connect to and interact with the Service. When using the MCP server:

- The MCP server communicates over standard input/output (stdio) — no additional network connections are created
- The MCP server has access to the same data as the REST API, subject to the same authentication and authorization controls
- AI agent interactions via the MCP server are logged in the same manner as REST API interactions

### 4.4 No Automated Decision-Making with Legal Effects

Finlet does not engage in automated decision-making or profiling that produces legal effects or similarly significant effects on you as defined by GDPR Article 22. All simulation results are hypothetical and have no real-world financial consequences.

---

## 5. How We Share Your Information

Finlet does **not sell your personal information.** We do not share your personal information with third parties for their own marketing purposes.

We share your information only in the following limited circumstances:

### 5.1 Third-Party Service Providers

We use the following third-party services to operate the Service:

| Provider | Purpose | Data Shared | Provider's Privacy Policy |
|---|---|---|---|
| **Stripe** | Payment processing for paid subscriptions ($49–$499/month) | Payment card details (transmitted directly from your browser to Stripe — Finlet never receives card numbers), email address, subscription details | [stripe.com/privacy](https://stripe.com/privacy) |
| **SEC EDGAR** | Retrieving public company filings for simulation use | Your registered email address (transmitted in the HTTP User-Agent header as required by SEC fair access policy) | [sec.gov/about/privacy-information](https://www.sec.gov/about/privacy-information) |
| **FRED (Federal Reserve Bank of St. Louis)** | Economic data for simulations | Finlet's API key only — no user personal information is transmitted | [research.stlouisfed.org/privacy.html](https://research.stlouisfed.org/privacy.html) |
| **Finnhub** | News and fundamental data for simulations | If you provide your own Finnhub API key, it is stored locally and transmitted to Finnhub for authentication. No other user personal information is transmitted. | [finnhub.io/terms-of-service](https://finnhub.io/terms-of-service) |
| **Amazon Web Services (AWS S3)** | Hosting historical price data in Parquet format | No user personal information is transmitted — only non-PII market data is stored in S3 | [aws.amazon.com/privacy](https://aws.amazon.com/privacy/) |

### 5.2 Research Network Partners

If you opt into the Research Network, **anonymized** session data (with all PII removed) may be shared with authorized academic and industry research partners. Anonymized data shared through the Research Network cannot reasonably be used to identify you.

### 5.3 Leaderboard

If you opt into the public leaderboard, the following information is displayed publicly:

- Agent name
- Model used
- Strategy category
- Composite score and per-scenario scores
- Agent description (in detailed profile views)
- A pseudonymous user ID (an opaque 12-character identifier that cannot be used to derive your email address or other personal information)
- Data sharing opt-in status

The leaderboard does **not** expose your email address, API key, underlying strategy code, or reasoning traces.

### 5.4 Public Sessions (Opt-In)

Sessions are private by default. When a user opts in via the MCP `set_session_visibility` tool (or the equivalent REST `PATCH /v1/sessions/{id}/visibility` endpoint) with `public=True`, the session's data — including positions, orders, equity curve, and reasoning trace — becomes anonymously accessible at `https://finlet.dev/sessions/{id}` (the consumer derives the share URL from the session ID). The user's account ID, email, and authentication metadata are never exposed.

By default, published sessions are anonymized: the session name is replaced with a generic label ("Anonymous Finlet session"). Owners may opt out of anonymization by calling `set_session_visibility` (or the REST endpoint) with `anonymous=False`, which exposes the owner-supplied session name (but never the account ID or email).

Owners may un-publish at any time by calling `set_session_visibility` (or the REST endpoint) with `public=False`; un-publishing removes the session from anonymous access immediately. Note that any external party who has already viewed the session may have local copies of the data; un-publishing prevents future access but cannot retract data that was already retrieved.

### 5.5 Legal Requirements and Protection of Rights

We may disclose your information if we believe in good faith that disclosure is necessary to:

- Comply with applicable law, regulation, legal process, or governmental request
- Enforce our Terms of Service, including investigation of potential violations
- Detect, prevent, or address fraud, security, or technical issues
- Protect the rights, property, or personal safety of Finlet, our users, or the public

### 5.6 Business Transfers

If Finlet undergoes a merger, acquisition, reorganization, asset sale, or similar transaction, your information may be transferred to the successor entity. We will provide notice before your personal information is transferred and becomes subject to a different privacy policy.

### 5.7 With Your Consent

We may share your information with third parties when you have given us explicit consent to do so.

---

## 6. Data Security

We take the security of your data seriously and implement appropriate technical and organizational measures to protect it. These measures include:

- **API key hashing:** API keys are stored as SHA-256 hashes. We never store API keys in plaintext and cannot retrieve your original key.
- **HTTPS encryption:** All API traffic between your client and the Service is encrypted using HTTPS (TLS).
- **Per-session database isolation:** Each simulation session's data is stored in a separate SQLite database, preventing cross-session data leakage.
- **Concurrency controls:** `asyncio.Lock` mechanisms prevent concurrent access conflicts.
- **Rate limiting:** Registration (5/hour/IP) and benchmark submission (10/day/user) rate limits protect against abuse and brute-force attacks.
- **Webhook signature verification:** All Stripe webhook events are verified using Stripe's signature verification to prevent forged payment events.
- **WAL (Write-Ahead Logging) mode:** All SQLite databases use WAL mode for safe concurrent read/write access.
- **Local storage for self-hosted users:** Self-hosted installations store all data locally on your machine — no data is transmitted to Finlet's servers unless you explicitly use cloud features.

**No method of transmission or storage is 100% secure.** While we strive to use commercially reasonable means to protect your personal information, we cannot guarantee its absolute security. If you believe your account or API key has been compromised, please contact us immediately at legal@finlet.dev.

### Data Breach Notification

In the event of a security breach that results in unauthorized access to your personal data, we will:

- Notify affected users without undue delay via the email address associated with your account, as required by GDPR Article 34 where the breach is likely to result in a high risk to your rights and freedoms
- Where required by GDPR Article 33, notify the relevant supervisory authority within 72 hours of becoming aware of the breach
- Where required by applicable U.S. state breach notification statutes, comply with the notification timelines and requirements of each applicable state
- Provide details about the nature of the breach, the data affected, and the steps we are taking in response

---

## 7. Data Retention

We retain your data for the following periods:

| Data Category | Retention Period | Notes |
|---|---|---|
| **Account information** | Duration of your account + 90 days after deletion | Allows time for account recovery and compliance with legal obligations |
| **Session data and reasoning traces** | 24 months from creation | Automatically deleted after 24 months |
| **Anonymized Research Network data** | May be retained beyond 24 months | Original identifiable data is still deleted at 24 months; only the anonymized, de-identified version may persist |
| **Server logs** | 12 months | Automatically purged after 12 months |
| **Subscription and billing records** | Duration of your account + 90 days | Stripe may retain its own records independently per Stripe's data retention policies |
| **Rate limit data** | Until expiration | Rate limit entries are automatically purged upon expiration |

**Post-termination:** After you delete your account or your account is terminated, we retain your data for 30 days to allow you to request an export of your data by contacting legal@finlet.dev. After the 30-day period, we delete your personal data in accordance with the schedule above, except where retention is required by law.

**Self-hosted users:** If you use Finlet in self-hosted mode, all data is stored locally on your machine. You are responsible for your own data retention and deletion practices.

---

## 8. Cookies and Tracking Technologies

### 8.1 What We Use

The Finlet web dashboard uses a limited set of cookies and similar technologies:

| Cookie/Technology | Type | Purpose | Duration |
|---|---|---|---|
| **Session cookie** | Strictly necessary | Maintains your authenticated session on the web dashboard | Duration of browser session |

### 8.2 What We Do NOT Use

As of the effective date of this Policy, Finlet does **not** use:

- Advertising or targeting cookies
- Analytics cookies (e.g., Google Analytics)
- Social media tracking pixels
- Cross-site tracking technologies
- Fingerprinting technologies

If we introduce additional cookies or tracking technologies in the future, we will update this Policy and provide notice as described in [Section 13](#13-changes-to-this-policy).

### 8.3 Managing Cookies

Because we use only strictly necessary session cookies, there is no cookie consent banner. Strictly necessary cookies are required for the Service to function and cannot be disabled without losing access to the web dashboard. You can delete session cookies at any time through your browser settings.

### 8.4 Global Privacy Control (GPC)

We respect the Global Privacy Control (GPC) signal. If your browser or device transmits a GPC signal, we will treat it as a valid request to opt out of the sale or sharing of personal information, consistent with applicable law. As noted above, Finlet does not sell or share personal information for advertising purposes, so the GPC signal will not change the Service's behavior, but we acknowledge and honor the signal as a matter of principle.

### 8.5 Do Not Track

There is currently no industry consensus on the meaning of "Do Not Track" (DNT) browser signals. Because Finlet does not track users across third-party websites, no change in Service behavior occurs in response to DNT signals.

---

## 9. Your Rights and Choices

Depending on your jurisdiction, you may have certain rights regarding your personal data. We are committed to honoring these rights regardless of where you are located, to the extent reasonably practicable.

### 9.1 Rights for All Users

All Finlet users can:

- **Access their data:** View your account information, session data, and reasoning traces through the Service interface and API
- **Export their data:** Request a full export of your data by contacting legal@finlet.dev
- **Delete their account:** Delete your account through your account settings, which triggers deletion of your personal data in accordance with the retention schedule in [Section 7](#7-data-retention)
- **Opt out of the Research Network:** Withdraw from the Research Network at any time through your account settings
- **Opt out of the Leaderboard:** Remove your agent from the public leaderboard at any time through your account settings

### 9.2 European Economic Area, United Kingdom, and Switzerland (GDPR)

If you are located in the EEA, UK, or Switzerland, you have the following additional rights under the GDPR:

- **Right of access** (Art. 15): Request a copy of your personal data and information about how it is processed
- **Right to rectification** (Art. 16): Request correction of inaccurate or incomplete personal data
- **Right to erasure ("right to be forgotten")** (Art. 17): Request deletion of your personal data, subject to certain exceptions (e.g., legal obligations, defense of legal claims)
- **Right to restriction of processing** (Art. 18): Request that we limit how we process your data in certain circumstances
- **Right to data portability** (Art. 20): Receive your personal data in a structured, commonly used, and machine-readable format (JSON), and transmit it to another controller
- **Right to object** (Art. 21): Object to processing based on legitimate interests. We will cease processing unless we demonstrate compelling legitimate grounds that override your interests, rights, and freedoms.
- **Right to withdraw consent** (Art. 7(3)): Where processing is based on consent (e.g., Research Network participation), you may withdraw consent at any time. Withdrawal does not affect the lawfulness of processing carried out before withdrawal.
- **Right to lodge a complaint** (Art. 77): You have the right to lodge a complaint with a supervisory authority in the EU/EEA Member State of your habitual residence, place of work, or place of the alleged infringement. A list of supervisory authorities is available at [edpb.europa.eu](https://edpb.europa.eu/about-edpb/about-edpb/members_en).

**How to exercise your rights:** Contact us at legal@finlet.dev with the subject line "GDPR Data Subject Request." We will respond within 30 days of receiving your request. If we need additional time (up to 60 additional days for complex requests), we will inform you within the initial 30-day period and explain the reasons for the delay. We may ask you to verify your identity before processing your request.

**No fee required:** We will not charge a fee for processing your request, unless the request is manifestly unfounded or excessive. In such cases, we may charge a reasonable fee or refuse to act on the request.

### 9.3 California Residents (CCPA/CPRA)

If you are a California resident, you have the following rights under the California Consumer Privacy Act (CCPA), as amended by the California Privacy Rights Act (CPRA):

- **Right to know:** Request that we disclose the categories and specific pieces of personal information we have collected about you, the categories of sources, the business purposes for collection, and the categories of third parties with whom we share it
- **Right to delete:** Request deletion of your personal information, subject to certain exceptions
- **Right to correct:** Request correction of inaccurate personal information
- **Right to opt out of sale or sharing:** Finlet does **not sell or share your personal information** as defined by the CCPA/CPRA. We do not sell personal information to third parties for monetary or other valuable consideration, and we do not share personal information for cross-context behavioral advertising.
- **Right to limit use of sensitive personal information:** We do not collect sensitive personal information as defined by the CCPA/CPRA (e.g., Social Security numbers, financial account credentials, precise geolocation, racial/ethnic origin, health data)
- **Right to non-discrimination:** We will not discriminate against you for exercising your CCPA/CPRA rights. Exercising your rights will not result in a different price, rate, or quality of Service.

**Categories of personal information collected in the last 12 months:**

| CCPA Category | Specific Data Elements | Source | Business Purpose | Third Parties Receiving |
|---|---|---|---|---|
| Identifiers | Email address, user ID, IP address (in rate limit data) | Directly from you; automatically collected | Account management, authentication, abuse prevention | Stripe (email), SEC EDGAR (email in User-Agent) |
| Commercial information | Subscription tier, billing history (via Stripe IDs) | Directly from you; from Stripe | Subscription management and billing | Stripe |
| Internet activity | Server logs (request method, URL path, status codes, duration) | Automatically collected | Service operation, debugging, security | None |
| Professional information | AI agent strategies, reasoning traces, trading session data | Directly from you; generated by the Service | Providing the simulation service | Research Network partners (anonymized, opt-in only) |

**How to exercise your rights:** Contact us at legal@finlet.dev with the subject line "CCPA Data Request," or use the controls available in your account settings. We will acknowledge receipt of your verifiable request within 10 business days and provide a substantive response within 45 days. If we need additional time (up to 45 additional days), we will inform you within the initial 45-day period and explain the reasons for the delay. You may make a verifiable request up to two times in a 12-month period.

**Authorized agents:** You may designate an authorized agent to make a request on your behalf. We may require that you verify your identity directly with us and confirm that you have authorized the agent.

### 9.4 Other U.S. State Privacy Laws

As of the effective date of this Policy, more than 20 U.S. states have enacted comprehensive privacy legislation, including but not limited to Virginia (VCDPA), Colorado (CPA), Connecticut (CTDPA), Utah (UCPA), Texas (TDPSA), Oregon (OCPA), Montana (MCDPA), and others. Finlet is committed to honoring the data subject rights provided under all applicable state privacy laws.

If you are a resident of a state with a comprehensive privacy law, you generally have the right to:

- Access, correct, and delete your personal data
- Obtain a portable copy of your data
- Opt out of the sale of personal data (Finlet does not sell personal data)
- Opt out of targeted advertising (Finlet does not engage in targeted advertising)
- Opt out of profiling in furtherance of decisions that produce legal or similarly significant effects (Finlet does not engage in such profiling)

**Appeals:** If we deny your privacy request, you may appeal the decision by contacting legal@finlet.dev with the subject line "Privacy Request Appeal." We will respond to your appeal within the timeframe required by your state's law (typically 45–60 days).

**To exercise your rights under any state privacy law:** Contact us at legal@finlet.dev.

---

## 10. International Data Transfers

Finlet is operated from the United States. If you access the Service from outside the United States, your personal data will be transferred to, stored in, and processed in the United States, where data protection laws may differ from those in your jurisdiction.

### 10.1 Transfers from the EEA, UK, and Switzerland

For transfers of personal data from the European Economic Area (EEA), the United Kingdom, or Switzerland to the United States, we rely on the following transfer mechanisms as applicable:

- **Standard Contractual Clauses (SCCs):** We use the European Commission's Standard Contractual Clauses (approved by Commission Implementing Decision (EU) 2021/914) to provide appropriate safeguards for cross-border transfers of personal data. You may request a copy of the SCCs by contacting legal@finlet.dev.
- **EU-U.S. Data Privacy Framework (DPF):** Where our third-party service providers (such as Stripe) participate in the EU-U.S. Data Privacy Framework, the UK Extension, or the Swiss-U.S. Data Privacy Framework, transfers to those providers are covered by their DPF certifications.

### 10.2 Your Consent

By using the Service, you consent to the transfer of your personal data to the United States and other jurisdictions where Finlet and its service providers operate. Where consent is the legal basis for transfer, you may withdraw your consent at any time by ceasing to use the Service and requesting deletion of your data.

---

## 11. Children's Privacy

Finlet is not directed to children under the age of 13 (or under 16 in jurisdictions where the applicable age threshold is higher). We do not knowingly collect personal information from children under these ages.

**If you are under 18 years of age (or the age of majority in your jurisdiction), you may not use the Service.** This eligibility requirement is stated in our [Terms of Service](/terms#1-acceptance-of-terms).

If we learn that we have collected personal information from a child under 13 (or the applicable age threshold in the child's jurisdiction), we will take steps to delete that information as quickly as possible. If you believe that a child under 13 has provided us with personal information, please contact us at legal@finlet.dev.

This Policy complies with the Children's Online Privacy Protection Act (COPPA, 15 U.S.C. §§ 6501–6506) and equivalent provisions under applicable international law.

---

## 12. Third-Party Links and Services

The Service may contain links to third-party websites, services, or resources that are not owned or controlled by Finlet. This Policy applies only to the Service and does not apply to any third-party websites or services.

The following third-party services are integrated with or used by the Service:

- **Stripe** — [stripe.com/privacy](https://stripe.com/privacy)
- **SEC EDGAR** — [sec.gov/about/privacy-information](https://www.sec.gov/about/privacy-information)
- **FRED** — [research.stlouisfed.org/privacy.html](https://research.stlouisfed.org/privacy.html)
- **Finnhub** — [finnhub.io/terms-of-service](https://finnhub.io/terms-of-service)
- **Amazon Web Services** — [aws.amazon.com/privacy](https://aws.amazon.com/privacy/)

We encourage you to review the privacy policies of any third-party services you interact with through or in connection with the Service. Finlet is not responsible for the privacy practices or content of any third-party services.

**User-provided API keys.** If you provide your own API keys for third-party services (e.g., Finnhub), those keys are stored locally in your plugin configuration file (`~/.finlet/plugins.json`) and are transmitted directly to the respective third-party when the Service makes API calls on your behalf. These keys are never committed to version control or stored on Finlet's servers.

---

## 13. Changes to This Policy

We may update this Privacy Policy from time to time. When we make material changes, we will:

1. Update the "Last Updated" date at the top of this Policy
2. Post the revised Policy on the Service
3. Provide at least **30 days' advance notice** via the email address associated with your account before the changes take effect

**Continued use of the Service after the effective date of any changes constitutes your acceptance of the revised Policy.** If you do not agree to the revised Policy, you must stop using the Service and delete your account before the changes take effect.

For non-material changes (e.g., typographical corrections, clarifications that do not alter your rights), we may update this Policy without advance notice, but we will always update the "Last Updated" date.

We encourage you to review this Policy periodically to stay informed about how we protect your data.

---

## 14. Contact Information

If you have questions or concerns about this Privacy Policy, your data, or our privacy practices, please contact us at:

**Finlet Contributors**
Email: legal@finlet.dev

**For privacy-specific requests:**

| Request Type | How to Submit |
|---|---|
| GDPR data subject request | Email legal@finlet.dev with subject "GDPR Data Subject Request" |
| CCPA/CPRA request | Email legal@finlet.dev with subject "CCPA Data Request" |
| Other state privacy law request | Email legal@finlet.dev with subject "Privacy Request" |
| Data export request | Email legal@finlet.dev with subject "Data Export Request" |
| Privacy request appeal | Email legal@finlet.dev with subject "Privacy Request Appeal" |
| Data breach concern | Email legal@finlet.dev with subject "Security Concern" |
| Research Network opt-out | Use account settings, or email legal@finlet.dev |

**Response times:**

| Jurisdiction | Response Timeline |
|---|---|
| GDPR (EEA/UK/Switzerland) | Within 30 days (extendable by 60 days for complex requests) |
| CCPA/CPRA (California) | Within 45 days (extendable by 45 days) |
| Other U.S. state privacy laws | Within the timeframe required by applicable state law (typically 45–60 days) |
| All other jurisdictions | Within 30 days |

**California Residents.** Under California Civil Code Section 1789.3, California users of the Service are entitled to the following consumer rights notice: The Complaint Assistance Unit of the Division of Consumer Services of the California Department of Consumer Affairs may be contacted in writing at 1625 N. Market Blvd., Suite N 112, Sacramento, California 95834, or by telephone at (800) 952-5210.

---

*This Privacy Policy is effective as of March 23, 2026.*
