---
tags: [finlet, core, time-engine, simulation, clock]
keywords: SimClock, simulation clock, time engine, date ceiling, enforcer, DateCeilingEnforcer, look-ahead bias, future data leakage
aliases: [time engine, sim clock, date ceiling enforcer]
priority: normal
---

# Finlet Time Engine — SimClock + Date Ceiling Enforcer

## SimClock (`finlet/core/clock.py`)

The heart of Finlet. Controls what data agents can see.

### Three Operational Modes

| Mode | Behavior |
|------|----------|
| FROZEN | Clock stopped. Agent makes unlimited queries at current time. No implicit advancement. |
| STEPPING | Advances by fixed interval on explicit `step()` call. |
| CONTINUOUS | Advances in real-time at configurable speed multiplier (e.g., 2x). |

**Key invariant:** Clock ONLY moves forward on explicit command. Never implicitly.

### Methods
- `freeze()`, `step(interval)`, `step_to(datetime)`, `play(speed)`, `get_time()`
- `skip_non_market(dt)` — Fast-forward past weekends/after-hours
- `is_market_open(dt)` — NYSE market hours (9:30-16:00 ET, handles DST)

### NYSE Holiday Support
Algorithmically computed for 2010-2035 using Meeus/Jones/Butcher Easter algorithm. Covers all 9 NYSE holidays.

### Timezone Safety
All 5 clock entry points enforce timezone awareness via `_require_aware()`. Naive datetimes rejected with ValueError. All internal times stored in UTC.

## Date Ceiling Enforcer (`finlet/core/enforcer.py`)

**Every piece of data from a plugin passes through this.** Most critical safety mechanism.

### Rules
1. All timestamps in response data must be <= current sim clock time
2. Items after ceiling are stripped
3. Items without timestamps excluded by default
4. Stripped count logged internally but NEVER exposed to agent (would leak info about future data existence)
5. Recognized timestamp keys: timestamp, date, datetime, filed_at, filedAt, filing_date, published_at, created_at, time

### PluginResponse Model
Contains: items, source, query_params, ceiling_applied, items_pre_filter, items_post_filter, error, rate_limit_remaining, rate_limit_reset, metadata

### Enforcement Points
- REST services: `market_service.route_query()`, `trade_service`, `clock_service`
- MCP tools: `submit_order` (auto-fill), `advance_time` (price refresh)
- Defense-in-depth: plugins filter first, then core enforcer re-filters
