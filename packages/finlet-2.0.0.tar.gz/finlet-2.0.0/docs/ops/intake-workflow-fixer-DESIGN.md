# intake + workflow-fixer — Design

> Written: 2026-04-21 (CTO Orchestration Phase 3 / Task #6)
> Status: MVP — both workflows active; workflow-fixer proposes patches but does NOT apply them (apply half lands in Task #8).
> Depends on: migrations 001–006 + 007 (this task); `cto-supervisor` (`bdXgn8qqq1X4d8qb`); `CTO_WEBHOOK_HMAC_SECRET`; `N8N_INTERNAL_JWT` (provisioned this task).

---

## 1. Scope

Two meta-workflows complete the supervisor's perimeter.

| Workflow | Role |
|---|---|
| `intake` | Hybrid classifier. Machine-typed signals pass through verbatim; free-form human text gets classified by opus. Both branches write an artifact, call the supervisor, write a decision, and respond. |
| `workflow-fixer` | Diagnoses a failing target workflow and PROPOSES minimal prompt/tool patches. Writes an `ops.cto_approvals` row + Discord notification; does NOT apply patches. Apply half lives in Task #8 (heartbeat cron polling pending rows). |

Both workflows follow the skill-graph / specialist shape: HMAC webhook → Validate event → work → write artifact → write decision → respond. No code emission, no repo mutation.

## 2. intake workflow

### Input contract

```json
POST /webhook/intake
Content-Type: application/json
X-CTO-Signature: t=<unix>,v1=<hex_hmac_sha256>

{
  "signal_origin": "machine" | "human",
  "signal_type": "bug_hunt_signal | bug_verify_signal | team_completion | heartbeat_tick | digest_tick | self_compact_tick",  // required if machine
  "payload": { ... },
  "source": "bug-hunt | cron | discord-relay | ...",
  "hmac_authenticated": true
}
```

- Machine branch (`signal_origin='machine'`): no LLM call. `signal_type` must match an enum (see below). Structured YAML is written directly.
- Human branch (`signal_origin='human'`): opus classifier produces a strict-schema JSON classification with a `cited_signal` field (NO BULLSHIT).

### Graph shape

```
Webhook (rawBody)
  → Validate event (HMAC + shape; accepts BOTH signal_origin values)
      ├─ error ─→ auth_rejected insert → respond 401
      └─ ok
  → Branch on signal_origin (Switch)
      │
      ├─ machine
      │   → Validate signal_type enum (Code)
      │   → Build machine artifact YAML (Code)  ──┐
      │                                            │
      ├─ human                                     │
      │   → Build classifier prompt (Code)         │
      │   → Classify (HTTP → claude-runner, opus)  │
      │   → Parse classification (Code, enforces cited_signal + banned fields) ─┘
      │
  → Write artifact (Postgres INSERT ops.cto_artifacts, workflow_name='intake')
  → Sign supervisor call (Code: HMAC + fetch → /webhook/cto-supervisor)
  → Write decision (Postgres INSERT ops.cto_decisions)
  → Respond
```

14 nodes total: Webhook, Validate event, Switch, MachineValidate, MachineBuild, HumanBuildPrompt, HumanClassify, HumanParse, WriteArtifact, CallSupervisor, WriteDecision, Respond, AuthInsert, AuthRespond. The two branches converge at WriteArtifact.

### Machine branch

Allowed `signal_type` values (enum enforced in the MachineValidate node):

```
bug_hunt_signal, bug_verify_signal, team_completion,
heartbeat_tick, digest_tick, self_compact_tick
```

No LLM call. Fast path — total < 2s end-to-end.

Machine artifact content (YAML frontmatter then a one-line body, stored verbatim in `ops.cto_artifacts.content`):

```yaml
---
intake_schema_version: 1
signal_origin: machine
signal_type: <the validated signal_type>
source: <the request source>
payload_preview: <JSON-stringified payload, first 400 chars>
received_at: <triggered_at | now>
---
machine signal routed; supervisor triggered.
```

Supervisor call: `event_type = signal_type` (already in the supervisor's ALLOWED set for all 6 machine signal_types).

Decision row:
- `event_type = 'intake_signal'`
- `action = 'intake_routed_machine'`
- `rationale = 'machine signal signal_type=<x>, source=<y>, payload_preview=<first 120 chars>'`

### Human branch

Classifier system prompt (loaded verbatim in HumanBuildPrompt):

```
You are the INTAKE classifier of the Finlet CTO ops stack.

GOVERNING PRINCIPLES (non-negotiable):
1. NO BULLSHIT. Every field you emit must be grounded in the input text.
   The cited_signal field MUST quote a specific fragment of the raw input
   that drove the classification. A cited_signal that does not appear
   verbatim in the raw input is a contract violation and will be rejected.
2. YOU NEVER EMIT CODE, DIFFS, PATCHES, FILE CONTENTS. Your output is the
   structured JSON object below — nothing else, no prose, no markdown fences.
3. CLASSIFY ONLY. You do not act, plan, or dispatch. You label the signal
   and propose the next workflow; the supervisor decides what actually runs.
4. TONE: terse. Summary <=200 chars, entity lists compact.

OUTPUT SCHEMA (all fields required):
{
  "classified_type": "bug_report | feature_request | status_query | complaint | spam | unknown",
  "severity": "info | low | medium | high | critical",
  "summary": "<=200 chars",
  "extracted_entities": {
    "mentioned_files": ["..."],
    "mentioned_components": ["..."],
    "user_intent": "<string>"
  },
  "suggested_next_workflow": "brainstorm | debate | plan-features | exec-plan | log_only | escalate",
  "cited_signal": "<verbatim fragment of the raw input that drove the classification>"
}

BANNED OUTPUT FIELDS (auto-reject on presence): code, diff, patch, file_contents.
```

Parse/validator (HumanParse node):
- Extracts JSON, strips fences.
- Verifies `classified_type`, `severity`, `suggested_next_workflow` are in their respective enums.
- Verifies `cited_signal` is a non-empty string and is a substring of the original raw text (case-insensitive, normalised whitespace). Rejection → demote to `classified_type='unknown', severity='info', suggested_next_workflow='log_only'` + rationale "classifier_rejected: cited_signal not found in input".
- Rejects any of the banned fields; on violation → same demotion path.

Human artifact content (stored verbatim in `ops.cto_artifacts.content`):

```
---
intake_schema_version: 1
signal_origin: human
source: <source>
received_at: <triggered_at | now>
classified_type: <x>
severity: <x>
summary: <x>
cited_signal: <x>
suggested_next_workflow: <x>
extracted_entities:
  mentioned_files: [...]
  mentioned_components: [...]
  user_intent: <x>
---
# Raw input
<original payload.text, verbatim>
```

Supervisor call: `event_type = 'intake_signal'`. The classification object is passed in `payload.classification` so the supervisor's LLM can see it.

Decision row:
- `event_type = 'intake_signal'`
- `action = 'intake_routed_human'`
- `rationale = 'human signal classified=<x>/<severity>; cited: \"<cited_signal[:120]>\"'`

### Shared supervisor call (CallSupervisor node)

Signs with the same `CTO_WEBHOOK_HMAC_SECRET` as the caller used. Inline JS SHA-256/HMAC copied verbatim from the supervisor's Validate event node (functions `sha256Bytes`, `hmacSha256`, etc). POST to `http://localhost:5678/webhook/cto-supervisor` (container-local) with signed body. Captures HTTP status into `supervisor_triggered` boolean for the response + audit row.

### Shared response shape

```json
{
  "ok": true,
  "artifact_ref": "<uuid>",
  "classification": { ... } | null,          // non-null only on human branch
  "supervisor_triggered": true | false,
  "decision_id": 42
}
```

## 3. workflow-fixer workflow

### Input contract

```json
POST /webhook/workflow-fixer
Content-Type: application/json
X-CTO-Signature: t=<unix>,v1=<hex_hmac_sha256>

{
  "target_workflow_id": "<n8n workflow id>",
  "failure_context": {
    "summary": "<string>",
    "failing_executions": [ ... ],        // optional list of {executionId, error, ...}
    "correction_rounds": 2
  },
  "parent_task_id": "<uuid | null>",
  "hmac_authenticated": true
}
```

### Graph shape

```
Webhook (rawBody)
  → Validate event (HMAC + shape; custom validator, does NOT use supervisor's ALLOWED set)
      ├─ error ─→ auth_rejected insert → respond 401
      └─ ok
  → Fetch target workflow    (HTTP GET n8n API, X-N8N-API-KEY=$env.N8N_INTERNAL_JWT)
  → Fetch failing executions (HTTP GET n8n API, ?workflowId=&status=error&limit=5)
  → Build prompt             (Code: structure + errors + failure_context → prompt)
  → Propose patches          (HTTP → claude-runner, opus, timeout 180)
  → Parse + validate         (Code: strict schema, banned fields, risk mapping)
  → Write artifact           (Postgres INSERT ops.cto_artifacts, workflow_name='workflow-fixer')
  → Write approval           (Postgres INSERT ops.cto_approvals, status='pending')
  → Post Discord             (HTTP POST DISCORD_WEBHOOK_BUGHUNT)
  → Write decision           (Postgres INSERT ops.cto_decisions)
  → Respond
```

11 nodes on the happy path + 2 for auth_rejected = 13 total.

### Node details

**Fetch target workflow** — HTTP Request, `GET http://localhost:5678/api/v1/workflows/{{ target_workflow_id }}` with header `X-N8N-API-KEY: {{ $env.N8N_INTERNAL_JWT }}`. Timeout 30s, retryOnFail once.

**Fetch failing executions** — HTTP Request, `GET http://localhost:5678/api/v1/executions?workflowId={{ target_workflow_id }}&status=error&limit=5` with same auth. `continueOnFail: true` — if executions fetch fails (e.g. zero history), we still proceed with workflow structure alone.

**Build prompt** — Code node. Combines:
1. The workflow JSON structure (nodes array).
2. Up to 5 failing execution error summaries.
3. The caller's `failure_context.summary` and `correction_rounds`.
4. The system prompt below.

System prompt (verbatim):

```
You are the WORKFLOW-FIXER, a meta-workflow of the Finlet CTO ops stack.

GOVERNING PRINCIPLES (non-negotiable):
1. NO BULLSHIT. Each proposed_patch MUST cite the specific node_id and
   field that's wrong, and the failing_execution or symptom in the
   input that motivated it. "I would have done it this way" without a
   cited failure is a contract violation.
2. MINIMAL. Propose the smallest change that plausibly fixes the failure:
   system_prompt edits, tool/node additions, validator tightening. Do
   NOT propose wholesale rewrites, architectural refactors, or changes
   to nodes that are not implicated by the failure signal.
3. STRUCTURED PROPOSAL ONLY. You emit the JSON schema below. You do NOT
   emit shell, code, diffs for repo files, migration SQL, or credentials.
4. RISK HONESTY. Rate risk_level based on blast radius: low=prompt
   tweak on a single node; medium=tool/parameter change; high=anything
   that touches auth, credentials, or node topology (add/remove).
5. TONE: terse, decisive.

OUTPUT SCHEMA (strict JSON, no markdown, no prose):
{
  "diagnosis": "<string, <=500 chars>",
  "proposed_patches": [
    {
      "node_id": "<id from current workflow JSON>",
      "field": "system_prompt | json_body | parameters | <specific path>",
      "before_excerpt": "<current value excerpt, <=200 chars>",
      "after_excerpt":  "<proposed value excerpt, <=200 chars>",
      "rationale": "<string citing the failure signal>"
    }
  ],
  "risk_level": "low | medium | high",
  "estimated_blast_radius": "<string, <=200 chars>"
}

BANNED OUTPUT FIELDS (auto-reject): code, diff, patch, file_contents,
commit_message, sql_migration, shell_command.
```

**Parse + validate** — Code node. Parses JSON, verifies `diagnosis` non-empty, `proposed_patches` is a non-empty array, each patch has the 5 required fields. Banned fields present → replace entire decision with `{diagnosis: 'fixer_schema_violation: <reasons>', proposed_patches: [], risk_level: 'high', estimated_blast_radius: 'n/a'}` and flag `_fixer_error=true` in metadata (so the downstream writer knows to mark the approval `critical`).

**Write artifact** — Postgres INSERT ops.cto_artifacts with `workflow_name='workflow-fixer'`, `content=<YAML frontmatter (diagnosis + patch summary + risk) + markdown body>`, `metadata=<model id, target_workflow_id, patch_count, risk_level>`.

**Write approval** — Postgres INSERT ops.cto_approvals with:
- `severity = 'high'` when `risk_level IN ('low','medium')`, `'critical'` when `risk_level='high'` or fixer_error.
- `prompt_text = 'workflow-fixer proposes ' || patch_count || ' patches to ' || target_workflow_id || ' (risk=' || risk_level || '): ' || left(diagnosis, 400)`.
- `proposed_action = jsonb with { target_workflow_id, patches, risk_level, blast_radius, parent_task_id }`.
- `status = 'pending'`.
- Approval token generated via `gen_random_uuid()` and returned.
- `task_id = parent_task_id` (may be null).

**Post Discord** — HTTP POST to `DISCORD_WEBHOOK_BUGHUNT` with content `[WORKFLOW-FIXER APPROVAL NEEDED] ID: <approval_token_short> | <diagnosis_preview_200_chars> | risk=<risk_level>, patches=<n>, target=<target_workflow_id>. Reply: APPROVE <token_short> / REJECT <token_short>.`. `continueOnFail: true` — Discord going down must not drop the audit trail.

**Write decision** — Postgres INSERT ops.cto_decisions with `event_type='workflow_fixer_request'`, `action='workflow_fixer_proposed'`, `rationale='proposed ' || patch_count || ' minimal patches for ' || target_workflow_id || '; ' || correction_rounds || ' failing rounds motivated this; cited executions: ' || coalesce(failing_execution_count,0) || '; risk=' || risk_level`. `outputs.approval_token_short` + `approval_id` captured.

**Respond** — 200 JSON:

```json
{
  "ok": true,
  "artifact_ref": "<uuid>",
  "approval_id": 42,
  "approval_token_short": "abc12345",
  "patch_count": 3,
  "risk_level": "low",
  "discord_posted": true,
  "decision_id": 123
}
```

### What it does NOT do (MVP)

- Does NOT apply patches. Writes approval row, exits.
- Does NOT poll for approved rows. That's Task #8 (heartbeat cron).
- Does NOT modify the target workflow.

## 4. Validate event — adaptations vs supervisor

Both workflows copy the supervisor's HMAC validator verbatim with two adaptations:

1. `intake` removes the `event_type` allow-list check (intake has its own contract keyed on `signal_origin`). Instead it validates: `signal_origin IN {'machine','human'}`, `payload` is object, `source` is non-empty, and if machine: `signal_type IN <intake enum>`.
2. `workflow-fixer` removes the `event_type` allow-list check. Instead it validates: `target_workflow_id` is a non-empty string, `failure_context` is an object with `summary` (non-empty string), `failure_context.correction_rounds` is an integer.

All other auth pieces (timestamp window, signature, `auth_rejected` audit row, 401 response) are identical.

## 5. Schema extension — migration 007

`ops.cto_artifacts.workflow_name` CHECK constraint extends to include `workflow-fixer` (intake already allowed via migration 005). Idempotent DROP-then-ADD.

## 6. New event types emitted to ops.cto_decisions

(Free-text column, no schema enforcement. Documented here for downstream consumers.)

| event_type | Emitted by | Action | When |
|---|---|---|---|
| `intake_signal` | `intake` | `intake_routed_machine` / `intake_routed_human` | every intake invocation |
| `workflow_fixer_request` | `workflow-fixer` | `workflow_fixer_proposed` | every successful fixer invocation |
| `workflow_fixer_applied` | Task #8 (heartbeat cron) | `workflow_fixer_applied` | future — on approval + apply |
| `workflow_fixer_rejected` | Task #8 (heartbeat cron) | `workflow_fixer_rejected` | future — on rejection |

## 7. Security / auth

- `CTO_WEBHOOK_HMAC_SECRET` (env): HMAC signer for all three webhooks (supervisor, intake, workflow-fixer) + downstream supervisor call from intake.
- `N8N_INTERNAL_JWT` (env, newly provisioned): long-lived n8n API JWT (267 chars, HS256). Read-only usage: `GET /api/v1/workflows/:id`, `GET /api/v1/executions?workflowId=&status=error`. Stored in `/opt/finlet-ops/compose/.env`, injected into `ops-n8n` container via `docker-compose.yml` `environment:` block. Source: the n8n API key already configured for `n8n-mcp` in `~/.claude.json` (laptop-side MCP client). Reused to avoid provisioning a second key.

Rotation plan: same as `CTO_WEBHOOK_HMAC_SECRET` — manual rotation; regenerate in n8n UI → Settings → API → revoke old, update .env, recreate container.

## 8. Gotchas carried forward

- n8n task runner still blocks `require('crypto')`. HMAC-SHA256 impl is the same pure-JS block copied from supervisor.
- Respond to Webhook node: `typeVersion: 1.1` for n8n 2.16 matches the supervisor's Respond. (Spec in handoff says ≥1.5 but supervisor works at 1.1. Use 1.1 for consistency.)
- `onError: continueErrorOutput` on Validate event routes error to `main[1]`, connected to `auth_rejected: insert`.
- Postgres insert uses the single-JSON-parameter `queryReplacement` pattern (not positional `$1,$2,...`) to dodge comma-in-string footguns.
- HMAC "Reason: unknown" bug deferred (not in scope).
- `cto_artifacts.content_sha256` is GENERATED — never included in INSERT column list.
- Container-local hostname for webhook-to-webhook calls: `http://localhost:5678/webhook/<path>`.
- Container-local hostname for n8n REST API: `http://localhost:5678/api/v1/...`.

## 9. Smoke test protocol

### Test 1 (intake human)

```bash
SECRET="$CTO_WEBHOOK_HMAC_SECRET"
BODY='{"signal_origin":"human","payload":{"text":"the price plugin is returning stale data after midnight, my portfolio valuations are wrong"},"source":"smoke-human","hmac_authenticated":true}'
T=$(date +%s)
SIG=$(printf '%s.%s' "$T" "$BODY" | openssl dgst -sha256 -hmac "$SECRET" -r | awk '{print $1}')
curl -sS -X POST https://ops.finlet.dev/webhook/intake \
  -H 'Content-Type: application/json' \
  -H "X-CTO-Signature: t=$T,v1=$SIG" \
  --data-raw "$BODY"
```

Assert:
1. HTTP 200, `ok:true`, `classification.classified_type='bug_report'`, `severity` ∈ {medium, high, critical}.
2. `ops.cto_artifacts` row: `workflow_name='intake'`, content contains both the raw text + YAML frontmatter + classification.
3. `cited_signal` is a verbatim fragment of the input (i.e. substring of the original text).
4. `ops.cto_decisions`: `event_type='intake_signal'`, `action='intake_routed_human'`, rationale names the cited fragment.
5. Supervisor triggered: one additional `cto_decisions` row with `action IN ('log_only','post_to_discord','spawn_sub_workflow','escalate_to_user')` matching the supervisor's output.

### Test 2 (intake machine)

```bash
BODY='{"signal_origin":"machine","signal_type":"bug_hunt_signal","payload":{"bug_id":"smoke-42","severity":"medium","title":"test bug"},"source":"smoke-machine","hmac_authenticated":true}'
# ... signed ...
```

Assert: HTTP 200, artifact row without LLM content, `action='intake_routed_machine'`, end-to-end wallclock < 2s.

### Test 3 (workflow-fixer happy path)

Target: the supervisor itself (`bdXgn8qqq1X4d8qb`). Verify no side effects on the supervisor.

```bash
BODY='{"target_workflow_id":"bdXgn8qqq1X4d8qb","failure_context":{"summary":"supervisor HMAC rejection messages say Reason: unknown instead of the specific failure cause (stale timestamp / bad signature / missing header)","failing_executions":[],"correction_rounds":2},"parent_task_id":null,"hmac_authenticated":true}'
# ... signed ...
```

Assert:
1. HTTP 200, `approval_id` + `approval_token_short` populated.
2. `cto_artifacts` row with `workflow_name='workflow-fixer'`, patch_count ≥ 1.
3. `cto_approvals` row, status='pending', `proposed_action` JSONB carries the patches.
4. `cto_decisions` row, action='workflow_fixer_proposed'.
5. Discord HTTP status 204 or 200 (on success — `continueOnFail` covers failure).
6. Target workflow unchanged: `n8n_get_workflow` updatedAt matches pre-test value.

## 10. Open questions / deviations

- Handoff spec said `Respond to Webhook typeVersion ≥ 1.5` but the live supervisor uses 1.1 and works. MVP uses 1.1 for cross-workflow consistency.
- Handoff D3 suggested using `mcp__n8n__n8n_get_workflow` for fetching target workflow — not possible inside n8n task runner. HTTP against REST API is the viable path; JWT auth documented here.
- Intake human branch has no `retryOnFail` on the classifier HTTP call — a transient LLM failure results in `classified_type='unknown'` via the demotion path. Acceptable MVP: fail loud via the decision row, the supervisor's next invocation on the next signal will still run.
- No poll-resume mechanism yet. Task #8 cron is the resume half.
