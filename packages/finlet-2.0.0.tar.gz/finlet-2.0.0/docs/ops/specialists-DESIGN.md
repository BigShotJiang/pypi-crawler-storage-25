# Specialist + Merger Workflows — Design

> Written: 2026-04-20 (CTO Orchestration Phase 3 / Task #5)
> Status: MVP — scaffolds the decision/artifact flow; no repo mutation.
> Applies to: `specialist-{swe,devops,security,frontend-security,ai-research}` and their `-merger` peers.

---

## 1. Scope of the MVP

This MVP does **not** mutate the Finlet repo. It scaffolds the proposal/validation flow that real repo mutation will plug into in a later integration task (outside Task #5). Specialists PROPOSE structured changes; mergers VALIDATE those proposals against deterministic rules. No git ops, no shell ops, no test execution.

The pattern is a direct analogue of the 4 skill-graph workflows (`brainstorm`/`debate`/`plan-features`/`exec-plan`) — HMAC-gated webhook → fetch input artifact → LLM call → parse/validate → write artifact + decision → respond. The only novelty vs. skill-graph is the specialist-to-merger chain: the specialist fires the merger via a signed webhook at the end of its happy path, and the merger's LLM step is replaced by a deterministic rule-based Code node (no LLM — mergers are deterministic by design).

## 2. Pair list (5 specialist + 5 merger = 10 workflows)

| Pair | Specialist | Merger | Charter | Allowed paths |
|---|---|---|---|---|
| 1 | `specialist-swe` | `specialist-swe-merger` | `capability.swe.md` | `finlet/core/**`, `finlet/plugins/**`, `finlet/api/**` (non-auth non-billing), `finlet/mcp/**`, `finlet/cli.py`, `finlet/leaderboard/**`, `finlet/marketplace/**`, `dashboard/**` (non-security), `tests/**` (matching scopes), `docs/**` |
| 2 | `specialist-devops` | `specialist-devops-merger` | `capability.devops.md` | `deploy/**` (non `.github/workflows/**`), `docs/ops/**`, `docs/lessons.md`, `docs/RUNBOOK.md` |
| 3 | `specialist-security` | `specialist-security-merger` | `capability.security.md` | **Reports only** — may touch `docs/decisions/**` and `docs/KNOWN_FAILURES.md`. Cannot write code. Dispatches patches via CTO→SWE. |
| 4 | `specialist-frontend-security` | `specialist-frontend-security-merger` | `capability.frontend-security.md` | `dashboard/**` only |
| 5 | `specialist-ai-research` | `specialist-ai-research-merger` | `capability.ai-research.md` | `docs/**`, `notebooks/**` only |

Scope repositioning per handoff D3: `specialist-solutions` is intake (Task #6), not Task #5 — this doc covers 5 pairs, not 6.

## 3. Specialist shape (identical across all 5)

Nodes (12 total), left-to-right:

1. **Webhook** (`n8n-nodes-base.webhook@2.1`) — POST `/webhook/specialist-<name>`, `rawBody: true`, `responseMode: responseNode`, `onError: continueRegularOutput`.
2. **Validate event** (`n8n-nodes-base.code@2`, `onError: continueErrorOutput`) — HMAC validator copied verbatim from skill-graph. Required input body fields: `{task_id, parent_task_id?, input_doc_ref?, input_doc_content?}`. At least one of `input_doc_ref` or `input_doc_content` must be non-null. Rejects → `main[1]`.
3. **Fetch input artifact** (`n8n-nodes-base.postgres@2.5`, `continueOnFail: true`) — `SELECT ref, workflow_name, content, content_sha256, metadata FROM ops.cto_artifacts WHERE ref = $1::uuid`. If `input_doc_ref` is null, returns no rows (fine — inline content path is used).
4. **Resolve input doc** (`n8n-nodes-base.code@2`) — picks row-content or inline content; carries `validated` block forward.
5. **Build prompt** (`n8n-nodes-base.code@2`) — composes the specialist's system prompt (see §5) + the input doc.
6. **Claude decide** (`n8n-nodes-base.httpRequest@4.2`) — `POST http://host.docker.internal:9099/run`, `model: opus`, `timeout: 180`. `retryOnFail: true`, `maxTries: 2`.
7. **Parse output** (`n8n-nodes-base.code@2`) — extracts YAML frontmatter between `---` fences; emits `violations[]` for malformed / missing required fields / unknown operation values.
8. **Write artifact** (`n8n-nodes-base.postgres@2.5`) — `INSERT INTO ops.cto_artifacts (workflow_name='specialist-<name>', content=<full LLM output>, metadata=<model/violations/ref/etc>)`. Returns `artifact_ref`, `artifact_id`, `content_sha256`. Uses the same single-JSON `queryReplacement` pattern as skill-graph.
9. **Write decision** (`n8n-nodes-base.postgres@2.5`) — `INSERT INTO ops.cto_decisions (event_type='specialist-<name>', action='sub_workflow_result', rationale=<cites input + violations>, inputs, outputs)`. Returns `id`.
10. **Trigger merger** (`n8n-nodes-base.code@2` — signs the HMAC + calls `fetch` against the merger webhook path) — sends `{proposal_artifact_ref, parent_task_id}` to `/webhook/specialist-<name>-merger`. Signs with the SAME `CTO_WEBHOOK_HMAC_SECRET` from the n8n env (pure-JS SHA-256/HMAC, same impl as Validate event). The merger fire is fire-and-forget; specialist does NOT wait on merger response (but captures HTTP status as `merger_triggered: true|false`).
11. **Respond** (`n8n-nodes-base.respondToWebhook@1.5`, `responseCode: 200`) — body `{ok, proposal_artifact_ref, merger_triggered, decision_id}`.
12. **auth_rejected: insert** + **auth_rejected: respond 401** (`postgres` + `respondToWebhook`) — identical pattern to skill-graph, tagged with the specialist workflow name.

Node IDs use the prefix `spec-<tag>-` where `<tag>` is a 3-letter short name: `swe`, `dev`, `sec`, `fse`, `air`. Example: `spec-swe-0000-0000-0000-000000000007`.

## 4. Merger shape (identical across all 5)

Nodes (10 total), left-to-right:

1. **Webhook** (`POST /webhook/specialist-<name>-merger`) — same config as specialist.
2. **Validate event** — same HMAC verbatim. Required body fields: `{proposal_artifact_ref, parent_task_id?}`.
3. **Fetch proposal artifact** (`postgres`) — `SELECT content, metadata FROM ops.cto_artifacts WHERE ref = $1::uuid`.
4. **Parse proposal** (`code`) — strips YAML frontmatter, parses into an object. Rejects if malformed with `decision: rejected` + `failures: ['malformed_frontmatter: ...']`.
5. **Run validators** (`code`) — deterministic rule battery (§6). Emits `{decision: approved|rejected|needs_revision, validators_run, failures, warnings}`.
6. **Write decision artifact** (`postgres`) — `INSERT INTO ops.cto_artifacts (workflow_name='specialist-<name>-merger', content=<decision yaml + summary>, stage_input_ref=<proposal_ref>)`.
7. **Write decision row** (`postgres`) — `INSERT INTO ops.cto_decisions (event_type='specialist-<name>-merger', action='merge_decision', rationale=<validator summary>, inputs, outputs)`.
8. **Respond** (`respondToWebhook`, 200) — body `{ok, decision, decision_artifact_ref, decision_id}`.
9. **auth_rejected: insert** + **auth_rejected: respond 401** — same as specialist.

No LLM call in mergers. That's deliberate — mergers are the deterministic gate.

## 5. Specialist system prompts

Each prompt is composed from `CAPABILITY_INDEX.md` + the capability's charter + the shared preamble below. The preamble is identical across specialists; only the role/scope/allowlist/examples differ.

### Shared preamble (verbatim, same in every specialist)

```
You are a specialist worker in the Finlet CTO skill graph.

GOVERNING PRINCIPLES (non-negotiable):
1. NO BULLSHIT. Every proposal you emit must cite measurable signal from the
   input task — a concrete file path, a specific line count, a named bug
   symptom, a benchmark delta, or a test that would cover it. Never taste.
   "I would have done it this way" is a contract violation.
2. YOU NEVER EXECUTE CODE. Your output is a STRUCTURED PROPOSAL (YAML
   frontmatter + markdown summary). You may emit diffs as TEXT inside the
   `proposed_diff` field, but the diff is NOT applied here — the merger
   workflow (and later, the integration task) decides what lands.
3. YOU NEVER EMIT: shell commands, secret values, live credentials, schema
   migrations outside your scope, modifications to other specialists'
   allowed paths.
4. OUTPUT SCHEMA is strict YAML frontmatter between --- fences, followed by
   a human-readable markdown summary. Missing required fields = rejected.
5. TONE: confident, terse, decisive. Answer first, reasoning after. No
   hedging.

YOUR ALLOWED PATH PREFIXES (reject work that falls outside):
  {specialist-specific allowlist from capability charter}

YOUR FORBIDDEN PATH PREFIXES (always reject, even if asked):
  .github/**, deploy/ (only devops specialist may touch; other specialists
  must reject), finlet/auth/**, finlet/billing/**, finlet/db/migrations/**,
  .env*, anything matching *credentials*, *secret*, *token*.

OUTPUT (exactly this YAML frontmatter, then markdown summary):
---
proposal_schema_version: 1
specialist: <your-name>
files_to_change:
  - path: <relative path from repo root>
    operation: create | modify | delete
    proposed_diff: |
      <unified diff for modify; full content for create; empty for delete>
    rationale: <why this change, citing input signal>
tests_to_add:
  - path: <test file path>
    content: |
      <test code>
risks: [<risk strings>]
estimated_lines_added: <int>
estimated_lines_removed: <int>
---
# Summary
<human-readable paragraph, under 500 words, citing specific parts of the
input task>
## What I changed and why
<bulleted cross-reference between files_to_change[].path and the input>
## Risks and known gaps
<bulleted, cites the risks[] field>

NO OTHER SECTIONS. NO STRAY CODE BLOCKS outside proposed_diff / content.
NO "Conclusion".
```

Per-specialist role + scope blocks (inlined above where `{allowlist}` appears):

- **swe**: "bugs, refactors, test fixes, small features in Finlet's engine/plugins/API/CLI (non-auth, non-billing)". Allow: `finlet/core/**`, `finlet/plugins/**`, `finlet/api/**` (not `finlet/api/auth`, not `finlet/api/billing`), `finlet/mcp/**`, `finlet/cli.py`, `finlet/leaderboard/**`, `finlet/marketplace/**`, `finlet/utils/**`, `dashboard/**`, `tests/**`, `docs/**`. Forbid: `finlet/auth/**`, `finlet/billing/**`, `finlet/db/migrations/**`, `finlet/core/enforcer.py` (date-ceiling is load-bearing; always escalate).
- **devops**: "ops-box infra, systemd, docker, Caddy, n8n, Hetzner. NO AWS / Terraform / Cloudflare (ops box lacks CLIs)". Allow: `deploy/ops/**`, `deploy/aws/**` (read-only proposal; execution routes through user dev host), `docs/ops/**`, `docs/RUNBOOK.md`, `docs/lessons.md`. Forbid: `.github/**` (workflows are ops-managed but restricted to devops via explicit routing; MVP rejects to keep blast radius small), `finlet/**`.
- **security**: "CVE triage, advisory analysis, credential-leak response — REPORTS ONLY". Allow: `docs/decisions/**`, `docs/KNOWN_FAILURES.md`. Forbid: anything outside those paths (security dispatches patches via CTO→SWE; security never patches directly).
- **frontend-security**: "CSP, XSS, cookies, CORS, Playwright client-side findings". Allow: `dashboard/**` only. Forbid: `finlet/**`, `deploy/**`.
- **ai-research**: "paper tracking, model release analysis, prompt regression, benchmark proposals — PROPOSALS ONLY". Allow: `docs/**`, `notebooks/**`. Forbid: any code file under `finlet/**`, `dashboard/**`, `deploy/**`, `tests/**`.

## 6. Merger validators (MVP, deterministic, no LLM)

Each validator returns `{pass: bool, failure_reason?: string, warning_reason?: string}`. Validators run in order; all failures are collected; final `decision` is:
- `rejected` if any `pass=false` with `severity: hard`;
- `needs_revision` if `pass=false` with `severity: soft` (only the test-presence warning);
- `approved` if all hard validators pass and warnings are only soft.

MVP validator list (ordered):

1. **schema_validity** (hard) — required fields present + types correct. Missing `files_to_change`, malformed YAML, wrong types → fail.
2. **banned_paths** (hard) — reject if any `files_to_change[].path` matches `^(\.github/|deploy/(?!ops/)|finlet/auth/|finlet/billing/|finlet/db/migrations/|\.env|.*credentials.*|.*secret.*|.*token.*)`. Devops is a carve-out for `deploy/ops/**`; other specialists are still rejected on any `deploy/` touch.
3. **per_specialist_allowlist** (hard) — each specialist has an allowlist regex (list below). Every path in `files_to_change` must match at least one allowlist pattern.
4. **size_cap** (hard) — `estimated_lines_added + estimated_lines_removed > 500` → reject.
5. **test_presence** (soft — warning, not reject) — if `files_to_change` contains any `operation ∈ {create, modify}` AND `tests_to_add` is empty → `warning: 'no tests proposed for code changes'`.

### Per-specialist allowlists (regex strings evaluated with `RegExp`)

- `swe`: `^(finlet/core/|finlet/plugins/|finlet/api/(?!auth/|billing/)|finlet/mcp/|finlet/cli\.py|finlet/leaderboard/|finlet/marketplace/|finlet/utils/|dashboard/|tests/|docs/)`
- `devops`: `^(deploy/ops/|deploy/aws/|docs/ops/|docs/RUNBOOK\.md|docs/lessons\.md)`
- `security`: `^(docs/decisions/|docs/KNOWN_FAILURES\.md)`
- `frontend-security`: `^(dashboard/)`
- `ai-research`: `^(docs/|notebooks/)`

Additionally, `swe` and `ai-research` have a named-file exclusion: any path containing `enforcer.py` → reject (hard) with reason `date_ceiling_enforcer_load_bearing`.

## 7. Specialist→Merger trigger

The specialist fires the merger at step 10 via a pure-JS webhook call. Pattern:

- Compute the webhook target from n8n env: `WEBHOOK_BASE = $env.N8N_WEBHOOK_URL || 'http://ops-n8n:5678/webhook'` (container-local hostname; ops-n8n container talks to itself via localhost in prod).
- Build payload: `{proposal_artifact_ref: <just-inserted ref>, parent_task_id: <from validated>}`.
- Compute `t = floor(now/1000)`, `rawBody = JSON.stringify(payload)`, `v1 = hex(hmacSha256(SECRET, t + '.' + rawBody))`.
- POST with headers `X-CTO-Signature: t=<t>,v1=<v1>` and `Content-Type: application/json`.
- Use Node's `fetch` (globally available in n8n Code nodes as of 2.16+); fire-and-forget timeout 5s; capture HTTP status into `merger_triggered` boolean.

The specialist does NOT wait on the merger's decision — that's what the merger's decision artifact is for. The next stage (integration task, outside MVP) will subscribe to merger artifacts via state/decision polling.

## 8. Cross-cutting

- All 10 workflows copy the `Validate event` Code node's HMAC logic verbatim from `skill-brainstorm`. The shared secret env var is `CTO_WEBHOOK_HMAC_SECRET`.
- Postgres credential is the shared `ops-postgres` (id `cQZd1wW1MLtHoMTH`).
- All 10 workflows use `settings.executionOrder: 'v1'` (n8n default) and no cron triggers (webhook-only).
- All workflows created ACTIVE; built via `mcp__n8n__*` tools only.

## 9. Out-of-scope (explicitly deferred)

- **Applying the proposal to the repo.** MVP does not touch the Finlet repo. A separate integration task will: (a) subscribe to `approved` merger decisions, (b) spawn the `bug-fix-runner` (port 9101) to write the diff to a worktree, (c) run ruff/mypy/pytest gates, (d) open the PR. Until that lands, specialist+merger pairs produce decisions into `ops.cto_artifacts` and `ops.cto_decisions` — that's it.
- **The 2-round correction loop** (Principle 5 of the mandate). MVP captures a single round. Retry routing is a separate task.
- **Cross-specialist handoffs** (e.g., security → swe for a dep bump). That routing lives in the `exec-plan` workflow, not here.
- **The `specialist-solutions` pair** — per handoff D3, solutions is the `intake` workflow (Task #6), not a specialist-of-a-plan.

## 10. Naming + paths

- Workflow names: exact strings as listed in §2 column "Specialist" and "Merger".
- Webhook paths: `/webhook/<workflow-name>` (n8n's default path convention).
- SQL event_type on decision rows: exact workflow name string (`specialist-swe`, `specialist-swe-merger`).
- Artifact `workflow_name` column: exact workflow name string. Migration 006 gates this.

---

## Appendix A: Decision log

- **D1**: Mergers are deterministic (no LLM). Rationale: mergers are the gate; taste-based merge calls defeat the whole NO BULLSHIT principle. LLM belongs upstream where judgment is actually needed.
- **D2**: MVP does not mutate the repo. Rationale: decoupling the proposal/decision path from the apply path lets us smoke-test routing without risking a bad diff landing. The apply path is a separate task with different failure-mode risk.
- **D3**: Specialist fires merger via HMAC-signed webhook (not via n8n's internal Execute Workflow node). Rationale: same HMAC gate applies uniformly to every workflow ingress — no "internal" bypass. Also future-proofs against splitting workflows onto separate n8n instances.
- **D4**: Per-specialist allowlist is enforced by the merger (deterministic regex), not the specialist's LLM prompt. Rationale: prompt-based allowlists drift under model regression; regex in the merger's Code node is load-bearing and auditable.
