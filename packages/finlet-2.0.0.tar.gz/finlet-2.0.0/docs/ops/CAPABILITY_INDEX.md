# Capability Index — Workflow & Specialist Routing

CTO consults this before delegating. CTO orchestrates **top-level workflows**; those workflows dispatch **specialists**. CTO never touches code and never calls a specialist directly.

---

## House Rules (MUST follow — non-negotiable, applies every invocation)

### Direct communication
- MUST state decisions plainly. Answer first, reasoning after.
- MUST NOT hedge when evidence is clear. If uncertain, state the probability band or the specific evidence gap.
- MUST keep outputs terse. No preamble, no filler, no emoji unless asked.

### Evidence before action
- MUST verify claims against current state before acting. Memory and docs may be stale.
- MUST search (web or code) before asserting technical facts not in immediate context.
- MUST NOT trust any prior agent's self-report without independent verification (query ops.agent_runs, re-probe, re-read).

### Delegation and parallelism
- MUST run independent tasks in parallel. Sequential only with documented dependency.
- CTO MUST delegate specialist work to sub-workflows. Capabilities MUST delegate cross-domain work up to CTO.
- MUST NOT do heavy work inline when a sub-agent, tool, or runner can be dispatched.

### Pre-action checklist (every non-reversible action)
1. Identify which capability owns the action. If unclear, escalate to CTO.
2. Check escalation triggers (see Judgment section). If any match, stop and escalate.
3. Estimate blast radius: local / shared state / production / billing / user-facing.
4. Name the rollback path before executing. If no rollback exists, escalate.
5. Log intent to ops.agent_runs with parent_run_id.
6. Execute.
7. Verify observed state matches intent. If not, roll back and log.

### Post-action verification
- MUST re-query state after any write. Do not trust tool output alone.
- MUST log outcome to ops.agent_runs with status=success|failed|partial.
- MUST NOT mark a task complete without verifying the downstream effect.

### Documentation
- MUST update affected docs before closing a task. Stale docs mislead future agents.
- MUST add a decision record under docs/decisions/ for non-trivial calls (anything that constrains future options).

### Scope discipline
- MUST NOT expand scope beyond the invocation signal. One signal, one action.
- MUST NOT add error handling, fallbacks, abstractions, or "while I'm here" cleanup not required by the signal.
- If a finding implicates a different capability's domain, stop and escalate.

### Budget discipline
- MUST respect the monthly spend ceiling in CTO_MANDATE.md.
- MUST escalate any proposed spend above the per-action ceiling.
- MUST log every billable action (API calls, service spin-ups) to ops.agent_runs with cost estimate.

### Honesty under pressure
- MUST state when evidence is weak. "I don't know" beats a confident wrong answer.
- MUST surface counter-evidence during its own reasoning, not hide it.
- MUST NOT rationalize past decisions to preserve consistency. If a prior call was wrong, say so.

---

## Architecture — Two Tiers

**Tier 1 — Top-level workflows (CTO orchestrates these, and only these):**
- `brainstorm` — guided ideation + feasibility research. Writes `requirements.md`. Invoked when user signals an idea with no shape yet.
- `debate` — adversarial 5-agent critique of an existing plan or artifact. Writes `readiness-report.md`. Invoked to stress-test before commit.
- `plan-features` — reads prior-stage doc, produces file-conflict-aware execution plan. Writes `execution-plan.md`. Invoked before any non-trivial build.
- `exec-plan` — reads `execution-plan.md`, spawns specialists in worktrees, enforces sequential merge gates. Outputs merged commits. **This is the only workflow that calls specialists.**
- `bug-hunt` — scans codebase / logs / prod state, writes `ops.bugs` rows graded info/low/med/high/critical. Invoked on schedule or on user request.
- `bug-verify` — re-probes a claimed fix against live state and closes or re-opens the `ops.bugs` row. Invoked after any `exec-plan` that touched a bug.
- `workflow-fixer` — meta, **user-approval-gated**. Edits the workflow definitions themselves when the correction loop fails. Invoked only after 2 failed CTO↔team rounds.

**Tier 2 — Specialists (spawned by `exec-plan`, never by CTO):**
Each charter at `docs/ops/capabilities/capability.<name>.md`. Each specialist is paired with a **merge-agent** that runs in a fresh context, fixes small errors, re-runs tests, and merges the worktree. Naming: `specialist-<name>` writes, `specialist-<name>-merger` reviews and merges.

| Specialist | Merge-agent | Charter | Scope |
|------------|-------------|---------|-------|
| `specialist-swe` | `specialist-swe-merger` | `capability.swe.md` | Engine, plugins, API, CLI (non-auth, non-billing) |
| `specialist-devops` | `specialist-devops-merger` | `capability.devops.md` | Ops-box infra, systemd, docker, Caddy, n8n, Hetzner |
| `specialist-security` | `specialist-security-merger` | `capability.security.md` | CVE triage, dep advisories, secret leaks (reports + dispatches, does not patch) |
| `specialist-frontend-security` | `specialist-frontend-security-merger` | `capability.frontend-security.md` | CSP, XSS, cookie, CORS, Playwright client-side findings |
| `specialist-ai-research` | `specialist-ai-research-merger` | `capability.ai-research.md` | Model releases, framework research, prompt regression analysis |
| `specialist-solutions` | `specialist-solutions-merger` | `capability.solutions.md` | User-facing signals (Gmail, Discord DMs, bug reports) |

---

## Routing Table — Trigger → CTO's Top-Level Workflow → Eventual Specialists

First match wins. Auth/billing/Stripe rows beat every other row.

| # | Trigger | Path | CTO invokes | Eventual specialists |
|---|---------|------|-------------|----------------------|
| 1 | Bug/PR touching `finlet/auth/**` | **escalate** | none | none |
| 2 | Bug/PR touching `finlet/billing/**` | **escalate** | none | none |
| 3 | Stripe price/plan/webhook/coupon edit | **escalate** | none | none |
| 4 | New feature, architectural change, work >50 LOC | full chain | `brainstorm → debate → plan-features → exec-plan` | chosen by `exec-plan` from plan's file map |
| 5 | Existing plan needs stress test before build | partial chain | `debate → plan-features → exec-plan` | chosen by `exec-plan` |
| 6 | Plan already exists (doc present) | partial chain | `exec-plan` | chosen by `exec-plan` |
| 7 | `bug-hunt` finding severity critical / high (non-auth, non-billing) | short path | `exec-plan` with single-spec plan | `specialist-swe` + merger (or frontend-security if CSP/XSS) |
| 8 | `bug-hunt` finding severity med / low / info | direct | `exec-plan` with single-spec plan | one specialist + its merger |
| 9 | Typo, one-line fix, rename, doc-only tweak | direct | `exec-plan` with single-spec plan | one specialist + its merger |
| 10 | systemd/docker/Caddy/n8n/Hetzner ops incident | direct | `exec-plan` | `specialist-devops` + merger |
| 11 | CVE advisory, pip-audit, Dependabot | direct | `exec-plan` | `specialist-security` + merger (dispatches swe merge via same plan) |
| 12 | Credential/secret leak | direct + escalate | `exec-plan` (rotate) | `specialist-security` + `specialist-devops` + mergers |
| 13 | Model release, framework paper, prompt regression | direct | `exec-plan` (research-only plan) | `specialist-ai-research` + merger |
| 14 | Gmail ticket, Discord DM, user bug report | direct | `exec-plan` (intake plan) | `specialist-solutions` + merger |
| 15 | After any `exec-plan` that touched a bug | direct | `bug-verify` | none (re-probes, updates `ops.bugs`) |
| 16 | 2 CTO↔team rounds failed on same workflow | meta | `workflow-fixer` (**user approval required**) | none (edits workflow defs) |
| 17 | User DM to CTO, scheduled review cron | CTO-only | none | none |
| 18 | **Unmatched** | **escalate** | none | none |

**Size heuristic for rows 4 vs 9:** CTO estimates LOC + surface area. >50 LOC OR crosses >1 module OR introduces new API surface → full chain. Otherwise direct.

---

## Separation of Duties

Each stage is a different agent reading the **prior stage's output doc**, not conversation.
`brainstorm` writes `requirements.md` → `plan-features` reads it → writes `execution-plan.md` → `exec-plan` reads it → specialists write code in worktrees → merge-agents read worktree diffs + test output → merge.

No stage re-interprets another stage's intent from chat. If the doc is ambiguous, the downstream agent refuses and kicks back up.

---

## Correction Loop

1. Specialist writes code → merge-agent finds failure → returns to specialist (round 1).
2. Specialist fixes → merge-agent re-checks → still failing → returns again (round 2).
3. After 2 failed rounds, CTO routes the entire workflow to `workflow-fixer` with **user approval required**.
4. Post-fix, 2 more rounds allowed.
5. Still failing → escalate to user with full trace.

---

## Judgment

### Scope
This file is the router. Domain judgment lives in per-capability charters (`docs/ops/capabilities/capability.*.md`). Decision rules and spend ceilings live in `CTO_MANDATE.md`.

### Escalation triggers (for editing this file)
- MUST add a row when the same signal escalates twice for the same reason.
- MUST NOT add a row that silently expands autonomous scope. Rows moving a trigger from "escalate" to "auto-route" require user approval.
- MUST NOT remove an existing `escalate` row without user approval.

### Decision examples

1. User: "Let's build a portfolio sharing feature." → row 4 → CTO invokes `brainstorm`. `brainstorm` writes `requirements.md`. CTO invokes `debate`, then `plan-features`, then `exec-plan`. `exec-plan` dispatches `specialist-swe` + `specialist-frontend-security` based on the plan's file map.
2. `bug-hunt` finds `critical: NoneType in /portfolio` in `finlet/api/routes/portfolio.py` → row 7 → CTO invokes `exec-plan` with a single-spec plan → `specialist-swe` fixes, `specialist-swe-merger` merges. `bug-verify` closes the row.
3. `bug-hunt` finds `critical: /login 500` in `finlet/auth/**` → row 1 → escalate. Never dispatched.
4. Typo in `docs/README.md` → row 9 → `exec-plan` with one-step plan → `specialist-swe` + merger.
5. Playwright probe: `CSP violation on /dashboard` → row 7 (frontend-security branch) → `specialist-frontend-security` + merger.
6. User DMs CTO "status on N+1 bug?" → row 17 → CTO queries `ops.bugs`, replies. No workflow.
7. Two rounds fail on `exec-plan` for the same plan → row 16 → CTO pauses, asks user to approve `workflow-fixer`.

### Output schema
This file has no output. It is consulted, not invoked.

### Memory namespace
None. Stateless reference; reloaded every run.

### Validation
Routing test must feed N synthetic triggers and assert (a) which top-level workflow CTO invokes, (b) which specialists `exec-plan` eventually dispatches. Drift on either = table is stale.
