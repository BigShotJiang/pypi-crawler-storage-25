# Incident — bug-hunt cron silent failure, 2026-04-19 to 2026-04-22

**Severity**: S3 (silent failure of a non-customer-facing cron for 72h)
**Status**: Resolved 2026-04-22 16:43 UTC
**Author**: Claude (Phase 3 session)

## Summary

The `bug-hunt` n8n workflow, scheduled to run every 12 hours on the ops box, errored on every execution from 2026-04-19 16:00 UTC through 2026-04-22 16:00 UTC — eight consecutive failures (execution IDs 19, 20, 21, 56, 57, 75, 76). Every failure was HTTP 401 from Anthropic's API on the `claude analyze` HTTP Request node. Two independent defects compounded. First, the `/home/ops/.claude/.credentials.json` Claude Code Max OAuth token had gone stale — the Max-plan flow refreshes lazily on CLI invocation, and no other process on the box was exercising that credential file between the 12-hour cron fires. Second, the node hardcoded `model: 'sonnet'` despite Decision #1 of 2026-04-20 migrating the ops stack to opus via `$vars.CTO_MODEL`; the supervisor was updated in that decision but Phase 1 workflows were not swept. The failure was invisible because no alerting was wired to n8n execution errors. Discovery happened out-of-band during the Task #7 bug-hunt → CTO migration on 2026-04-22, when the agent attempted a live smoke of the rewired workflow.

## Impact

- **0 bugs triaged** from `bug-hunt` during the 72-hour window. The workflow's job is to sweep the Finlet codebase for latent defects on a 12-hour cadence and queue findings for human approval; none of that happened.
- **0 Discord posts** to `#bug-hunt` during the window. This channel is the primary human-facing audit surface for the bug-hunt loop. A quiet channel was indistinguishable from a working channel with no new findings, which is exactly the failure mode a silent cron produces.
- Pending approvals queue on the `bug_hunt_approvals` Postgres table went stale — nothing new was inserted, and the oldest unreviewed item grew 72h older without any indication anywhere that the intake side had stopped.
- Task #7's live end-to-end validation (bug-hunt → CTO rewire) was blocked until the auth issue was resolved. Estimated delay to Task #7: ~90 minutes, mostly spent diagnosing whether the 401 was a recent regression or a pre-existing condition.
- No customer-facing surface was affected. No data loss. No revenue impact. The ops stack is an internal tool; the blast radius was entirely internal audit visibility.

## Timeline

All timestamps UTC.

| Time                | Event                                                                                                 |
|---------------------|-------------------------------------------------------------------------------------------------------|
| 2026-04-19 16:00    | Exec 19 — first known failure in the examined window. HTTP 401 on `claude analyze`.                   |
| 2026-04-20 04:00    | Exec 20 — 401.                                                                                        |
| 2026-04-20 16:00    | Exec 21 — 401.                                                                                        |
| 2026-04-20 19:22    | User Decision #1 applied: `cto-supervisor` switched from hardcoded sonnet → `$vars.CTO_MODEL` (opus). Scope was supervisor only; `bug-hunt` NOT updated. |
| 2026-04-21 04:00    | Exec 56 — 401.                                                                                        |
| 2026-04-21 16:00    | Exec 57 — 401.                                                                                        |
| 2026-04-22 04:00    | Exec 75 — 401.                                                                                        |
| 2026-04-22 16:00    | Exec 76 — 401. Eighth consecutive failure.                                                            |
| 2026-04-22 ~16:30   | Task #7 agent, attempting a live smoke of the rewired bug-hunt, surfaced the 401 chain.               |
| 2026-04-22 16:43    | Fix applied: `claude analyze` node `jsonBody.model` patched from `'sonnet'` → `$vars.CTO_MODEL \|\| 'opus'`; OAuth creds refreshed as part of the fix. |
| 2026-04-22 16:43    | Exec 77 — manual smoke succeeded. opus returned 4 bugs in 11.94 s; full downstream chain (triage, approval, Discord post) fired.  |

## Root cause

Dual, compounding. Both were necessary to explain the observed behavior; neither alone is sufficient.

**Cause 1 — stale Claude Code Max OAuth credentials at `/home/ops/.claude/.credentials.json`.**

The Claude Code Max OAuth flow issues short-lived access tokens and long-lived refresh tokens. Access tokens refresh lazily — refresh fires only when the `claude` CLI (or an equivalent SDK call) is invoked and detects an expired or near-expiring access token. `cto-supervisor` runs on a cadence tight enough to keep the access token warm; every invocation of the supervisor's `claude` call triggers the refresh check, which kept `/home/ops/.claude/.credentials.json` updated throughout the incident window.

`bug-hunt` fires every 12 hours on its cron. This cadence is wider than the effective access-token lifetime. At each fire, the `claude analyze` node sent its HTTP request carrying an expired access token, and Anthropic's gateway responded with HTTP 401. Because `bug-hunt` was the only consumer of that credential file on that cadence, and because `cto-supervisor`'s refresh activity wrote back to the same file but didn't retroactively heal any in-flight 401s, `bug-hunt` hit the same stale state on every fire.

Key mechanism: the 12h cron fire, the HTTP request, and the 401 response all happen inside the `claude analyze` node's synchronous execution. There is no retry-with-refresh in the node. A 401 is terminal for that execution.

**Cause 2 — model alias drift on the `claude analyze` node.**

`bug-hunt` was authored with `"model": "sonnet"` hardcoded in the `jsonBody` of the HTTP Request node feeding `claude-runner`. Decision #1 of 2026-04-20 migrated `cto-supervisor` to `"model": "={{ $vars.CTO_MODEL || 'opus' }}"`, but the update was scoped strictly to the supervisor workflow. `bug-hunt`, `bug-verify`, `intake`, and `workflow-fixer` all retained their hardcoded model strings. The `'sonnet'` literal was now stale relative to the project's declared standard as of Decision #1.

This cause was latent during the 72h window because cause (1) prevented any execution from reaching the point where the model string was read server-side. Had cause (1) been absent, the node would have continued running against sonnet rather than the current opus standard, and every downstream consumer would have desynced further as the stack evolved.

**How the causes compounded.**

Cause (1) was the proximate failure — it was the reason every execution returned 401. Cause (2) was a latent correctness bug that would have surfaced the moment cause (1) was fixed without also addressing cause (2): `bug-hunt` would have started running green but against the wrong model. The remediation addressed both simultaneously so the incident wouldn't resurface the next time OAuth drifted, and so the workflow would be conformed to the post-Decision-#1 standard.

## Detection

Out-of-band. The Task #7 agent, executing the bug-hunt → CTO migration on 2026-04-22, attempted a live smoke of the rewired workflow and found the `claude analyze` node returning 401 on the first request. Inspecting the last eight executions via `mcp__n8n__n8n_executions` revealed the three-day silent failure streak — every execution since 2026-04-19 16:00 UTC had failed at the same node with the same status code.

This was **not** caught by monitoring:

- No alert fired. The ops stack has no alerting path wired to n8n execution failures.
- No dashboard lit up. There is no dashboard for workflow-execution health on the ops box.
- No human noticed that bug-hunt Discord posts had stopped. The `#bug-hunt` channel had been silent for 72h, but silence is the default state when the workflow finds nothing — indistinguishable from failure without an out-of-band heartbeat.
- No one was actively reviewing the pending-approvals queue during the window.

The only reason the incident was discovered inside 72 hours is that Task #7 happened to need a live bug-hunt run. Without that unrelated work, the failure could have continued indefinitely. The detection path was retroactive luck, not process.

## Remediation

Applied 2026-04-22 16:43 UTC. Two actions in the same fix window, applied together because either alone would have left a latent defect:

1. **OAuth refresh.** Invoked the `claude` CLI on the ops box as the `ops` user, which triggered the lazy refresh against the refresh token still present in the credentials file. A new access token was written back to `/home/ops/.claude/.credentials.json`. No re-authentication was needed — the refresh token was still valid; the access token had simply expired for lack of use.
2. **Node patch.** The `claude analyze` node's `jsonBody` was edited via n8n's partial-update API (`n8n_update_partial_workflow`). Exact change:
   - Before: `"model": "sonnet"`
   - After: `"model": "={{ $vars.CTO_MODEL || 'opus' }}"`

The partial-update path auto-sanitizes touched nodes, so the patch did not require a full workflow rewrite. n8n's `$vars.CTO_MODEL` was already set at the instance level as part of Decision #1's rollout on 2026-04-20; this change simply made `bug-hunt` consume it.

Verification: exec 77 (manual trigger, same instant as the fix) returned 4 bugs from opus in 11.94 s, and the full downstream chain (triage, approval-queue insert, Discord post) executed end-to-end without error. The first automatic cron fire after the fix (exec 78 at 2026-04-23 04:00 UTC) will be the true regression gate — at the time of writing this postmortem, that fire has not yet occurred.

## Contributing factors

- **No alerting on cron-workflow failures.** n8n accumulated five-plus consecutive failures on a single workflow with no human-facing alarm. The ops box has Postgres (for structured queries against `execution_entity`), Discord webhooks (proven-working channel), and n8n's own built-in error-workflow hook all available as alerting substrate. None were wired. This is a pure configuration gap; the infrastructure to page a human exists and works.
- **Log spam masks signal.** The ops-box n8n logs are noisy with `dbTime.getTime` deprecation warnings on every cron tick. Unrelated to this incident by mechanism, but it reduces the signal-to-noise ratio badly enough that skimming logs is not a productive diagnostic habit on this instance. If someone had glanced at logs during the window, the deprecation noise would have buried the 401 lines.
- **Drift between supervisor and Phase 1 workflows.** Decision #1 (2026-04-20) updated `cto-supervisor` only. Phase 1 workflows (`bug-hunt`, `bug-verify`, `intake`, `workflow-fixer`) still had hardcoded model strings. Every future change to the supervisor's model or vars convention creates the same drift vector until the whole Phase 1 family is conformed. The next time the standard moves, the same set of workflows will be wrong again unless the sweep becomes part of the decision-application discipline.
- **OAuth refresh depends on continuous usage.** The Claude Code Max OAuth model assumes the `claude` CLI is invoked frequently enough to keep access tokens warm. Long-idle workflows (≥12h cadence) break this assumption invisibly. There is no warning, no log, no metric — the token simply stops working between the point it expires and the point someone invokes the CLI.
- **No heartbeat.** Nothing on the ops box keeps the credential file warm independent of workflow cadence. `cto-supervisor` happens to run often enough to maintain warmth for its own invocation path, but that's an accidental property of its cadence, not a deliberate design. Any workflow with a tighter-than-12h cadence is incidentally protected; anything looser is exposed.
- **Single source of OAuth truth.** All ops-box workflows share one `/home/ops/.claude/.credentials.json`. A single stale token silently breaks every consumer. No per-workflow credential, no fallback path, no retry-with-refresh logic in the HTTP Request nodes.

## Preventive actions

1. **[Task #8 — pending]** Add a 5-minute heartbeat cron that makes a minimal `claude-runner` call each tick. The heartbeat serves two purposes: (a) keep `/home/ops/.claude/.credentials.json` continuously refreshed so no workflow ever hits a stale access token; (b) provide the canary signal for cron-failure alerting (any missed tick becomes a page). The minimal call should be a trivial prompt (e.g., `"ok"`) against the smallest available model so cost stays negligible. Acceptance: heartbeat runs green for 48 consecutive hours after rollout.
2. **[Task #10 — pending]** Sweep every Phase 1 workflow that invokes `claude-runner` and replace hardcoded `model: 'sonnet'` / `model: 'opus'` with `$vars.CTO_MODEL || 'opus'`. Confirmed targets: `bug-verify.evaluate`, `intake.Classify`, `workflow-fixer.Propose_patches`. Same expression, same default, same vars source as `cto-supervisor` and the now-fixed `bug-hunt`. Acceptance: `grep -c "model.*sonnet\|model.*opus"` across the Phase 1 workflow JSON should return zero literal hardcodes; every match must be an expression reference.
3. **[Pending — no task yet]** Wire a cron-failure alerting path. Two viable options: (a) n8n's built-in error-workflow hook pointing at a dedicated workflow that posts to `#ops-alerts` Discord; (b) the heartbeat from item 1 runs a Postgres query against `execution_entity` looking for workflows with ≥2 consecutive errors in the last 30 minutes and posts to Discord. Option (a) is per-execution and catches every failure; option (b) is debounced and catches patterns. Prefer (b) because it filters out transient one-off errors that don't warrant paging, but (a) may be a cheap complementary add. Acceptance: a synthetic failure in any workflow produces a Discord alert within 5 minutes.
4. **[Pending]** Document the `$vars.CTO_MODEL` convention in `docs/AGENT_OPS_STACK.md` so future workflow authors default to the vars-driven pattern rather than copying a hardcoded model string from whichever workflow they first crib from. Include an explicit anti-pattern callout: hardcoded model strings in `jsonBody` are banned; all model selection must go through `$vars` or workflow-level parameters.
5. **[Pending]** Add a `decision-broadcast` checklist to the ops-stack decision application flow. When a decision changes the supervisor's model, vars, or credential convention, the applier must grep all Phase 1 workflows for the old pattern and patch them in the same change. This incident's cause (2) was a pure process gap — the mechanism existed to do the sweep, but no one was required to.

## Lessons learned

**Silent cron failures are the default, not the exception.**
If a workflow can fail without paging a human, it will, and nobody will notice for days. Every cron must have either a monotonically-updating heartbeat or a failure-count alert wired before it goes live. "I'll add alerting later" is how you lose three days of output. The cost of wiring a Discord webhook at workflow-creation time is roughly ten minutes; the cost of finding a three-day gap retroactively is substantially higher.

**Lazy-refresh OAuth is a liability for long-idle workloads.**
The Claude Code Max flow works well for interactive use because humans invoke the CLI constantly and the refresh hook fires often enough to keep access tokens warm. For cron-driven workloads with ≥1h cadence, the token-refresh assumption breaks quietly. The remedies are: (a) keep the credential warm with a fast-cadence heartbeat (this incident's chosen path via Task #8); (b) swap to a credential that doesn't require continuous activity, e.g., a real Anthropic API key with a long-lived secret; (c) wrap the `claude-runner` HTTP node with explicit refresh-then-retry logic. Option (a) is cheapest; option (b) is most robust but requires provisioning separate billing.

**Decisions that update a "standard" must broadcast to all consumers in the same PR.**
Decision #1 updated the supervisor and implicitly declared `$vars.CTO_MODEL || 'opus'` as the ops-stack standard. But four Phase 1 workflows still had the old literal, and nobody swept them. A decision that changes convention must include the full grep-and-replace across every workflow that uses the affected interface, in the same change that lands the decision. Scoped fixes are a leak path — they create the illusion of standards adoption without the actual coverage.

**The canary for "is this automation alive" must be independent of the automation itself.**
`bug-hunt` runs every 12h. If `bug-hunt`'s own output is the signal that `bug-hunt` is alive, a dead `bug-hunt` produces no signal. The heartbeat must be on a tighter cadence than anything it monitors, and its failure path must not depend on the thing that failed. The Task #8 heartbeat at 5 minutes is correctly tighter than every current Phase 1 cadence and uses a separate execution path through `claude-runner`.

**Out-of-band discovery is retroactive luck, not process.**
This incident was caught because Task #7 happened to need a live `bug-hunt` run. Without that unrelated work, the failure could have continued indefinitely — or until someone noticed the Discord channel had been silent for weeks. Relying on unrelated work touching a surface to surface its bugs is not a detection strategy. Treat the absence of an independent signal as equivalent to no monitoring at all, even if the surface is "visible" in principle.

## Appendix A — Execution IDs

Full list of failing executions in the window, chronological:

| Exec ID | Timestamp (UTC)      | Status   | Failing node           | Error code |
|---------|----------------------|----------|------------------------|------------|
| 19      | 2026-04-19 16:00     | error    | `claude analyze`       | HTTP 401   |
| 20      | 2026-04-20 04:00     | error    | `claude analyze`       | HTTP 401   |
| 21      | 2026-04-20 16:00     | error    | `claude analyze`       | HTTP 401   |
| 56      | 2026-04-21 04:00     | error    | `claude analyze`       | HTTP 401   |
| 57      | 2026-04-21 16:00     | error    | `claude analyze`       | HTTP 401   |
| 75      | 2026-04-22 04:00     | error    | `claude analyze`       | HTTP 401   |
| 76      | 2026-04-22 16:00     | error    | `claude analyze`       | HTTP 401   |
| 77      | 2026-04-22 16:43     | success  | — (manual smoke after fix) | 4 bugs returned from opus in 11.94 s; full downstream chain fired |

Gap between exec IDs 21 → 56 and 57 → 75 is other workflows' executions on the same n8n instance (shared ID counter), not missing `bug-hunt` runs. `cto-supervisor` and a few other scheduled jobs account for the intermediate IDs; those were unaffected because their own cadences kept their respective credential paths warm and they don't share the `bug-hunt` model alias.

Observation: every failure was at the same node (`claude analyze`), with the same HTTP status (401), with the same latency signature (sub-second reject from Anthropic's gateway). The uniformity is itself evidence that a monitoring rule as simple as "any workflow with ≥2 consecutive failures on the same node in the last 30 minutes" would have fired on exec 20 (2026-04-20 04:00 UTC) and reduced the incident duration from 72h to ~12h.

## Appendix B — Related follow-ups

- **Task #8 — heartbeat cron.** 5-minute `claude-runner` canary; the direct preventive action for cause (1) of this incident. Status: pending. Owner: ops. Expected rollout: within 48h of this postmortem.
- **Task #10 — mandate tightening.** Sweep `$vars.CTO_MODEL || 'opus'` into `bug-verify.evaluate`, `intake.Classify`, `workflow-fixer.Propose_patches`. Direct preventive action for cause (2). Status: pending. Owner: ops. Can be applied as a single partial-update batch via `n8n_update_partial_workflow`.
- **Intake URL bug (surfaced during Task #7).** Separately, Task #7's live validation uncovered a URL-construction bug in the `intake` workflow unrelated to this 401 chain. Tracked under Task #7's own follow-ups; referenced here only to note that incident-adjacent investigation often surfaces additional defects, which is a feature of incident postmortems, not a scope creep risk.
- **Cron-failure alerting.** Not yet ticketed. Candidate for Task #11; recommended to piggyback on the heartbeat from Task #8 so there's a single Postgres query path and a single Discord post path. Query sketch: `SELECT workflowId, COUNT(*) FROM execution_entity WHERE status = 'error' AND startedAt > NOW() - INTERVAL '30 min' GROUP BY workflowId HAVING COUNT(*) >= 2`.
- **Supervisor/Phase-1 broadcast discipline.** Convention update for `docs/AGENT_OPS_STACK.md`: any change to `cto-supervisor`'s model, vars, or credential-selection pattern must include the equivalent change across all Phase 1 workflows in the same PR. Status: pending. This is a documentation change plus a checklist addition to the decision-application flow.
- **OAuth credential model review.** Longer-term: evaluate whether the ops stack should move from shared Claude Code Max OAuth to a dedicated Anthropic API key for machine workloads. Max is designed for interactive human use; machine crons would be better served by a credential that doesn't require continuous activity to stay valid. Decision deferred — flagged here for revisit if heartbeat-based mitigation proves insufficient over the next 30 days.
