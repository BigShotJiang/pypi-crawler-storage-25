# cto-supervisor — Design

> The BRAIN of the ephemeral-CTO orchestration layer. Per-event process: read state → decide → write state + decision → exit.
> Built: 2026-04-20 (Task #3 of CTO Orchestration Phase 3, MVP vertical slice).
> Status: `discord_user_msg` path fully wired end-to-end. Other 7 branches stubbed (log + TODO comments) for Tasks 4–8 to plug into.
> Decisions applied 2026-04-20 (live workflow `bdXgn8qqq1X4d8qb`, not yet in git):
>   - **#1** Model default: `opus` (claude-opus-4-7), was `sonnet`.
>   - **#3** Escalation UX: async approval queue (`ops.cto_approvals` table) — no `sendAndWait` blocking.
>   - **#4** Webhook auth: HMAC-SHA256 shared-secret signatures (`X-CTO-Signature`).

---

## 1. Role in the stack

`cto-supervisor` is invoked for every event that might wake the CTO. It never writes code, never merges, never greps files. Its only job: look at state, pick an action from a tiny closed enum, log the decision, exit. Every heavy action (spawn a skill-graph workflow, escalate, run a specialist) is a **future sub-workflow call** that will plug into the `spawn_sub_workflow` branch once Tasks 4–8 land.

MVP today handles one real branch (`discord_user_msg` → `log_only` or `post_to_discord`). The other triggers are enum-validated at the webhook boundary so crons and team-completion signals can hit this workflow immediately when Tasks 4–8 fire.

## 2. Workflow graph

```
                                                   ┌───────────────────────┐
                        ┌──► log_only branch   ──► │ decisions: insert row │ ──► Respond
                        │                          └───────────────────────┘
                        │
                        ├──► post_to_discord ──► Discord HTTP  ──► decisions insert ──► Respond
                        │
Webhook ──► Validate ──► Read state (SQL x3) ──► Claude decide ──► Parse ──► Router (Switch)
                        │                                                          │
                        ├──► spawn_sub_workflow  ──► sign + prepare ──► POST to target ──► insert decision ──► Respond
                        │                           (HMAC sign)        (20s timeout,       (success ⇒
                        │                                               continueRegular)    sub_workflow_spawned
                        │                                                                   failure ⇒
                        │                                                                   sub_workflow_spawn_failed,
                        │                                                                   severity=high)
                        │
                        └──► escalate_to_user    (STUB: decisions insert + Discord [STUB ESCALATION]) ──► Respond
```

Node list (in order):

1. `Webhook` — `POST /webhook/cto-supervisor`. Accepts JSON body with `event_type`, `payload`, `source`, `triggered_at`. `responseMode=responseNode` so we can reply with the decision.
2. `Validate event` (Code node) — (1) HMAC validates the request per Decision #4 (see "Auth — HMAC signed webhooks" below); on failure routes to the error-output branch which writes an `auth_rejected` audit row and returns HTTP 401. (2) On success, enum-checks `event_type` ∈ {`discord_user_msg`, `team_completion`, `bug_hunt_signal`, `bug_verify_signal`, `heartbeat_tick`, `digest_tick`, `self_compact_tick`, `intake_signal`}. Normalises `triggered_at` to ISO-8601. Rejects missing fields. Emits `{event_type, payload, source, triggered_at, request_id}` downstream. `onError: continueErrorOutput` wires the error path.
3. `Read cto_state` (Postgres, `FOR UPDATE SKIP LOCKED`) — up to 20 rows where `status IN ('pending','in_progress','paused')` ORDER BY `updated_at DESC` LIMIT 20. Uses `SKIP LOCKED` so concurrent spawns don't block each other on rows already being decided on. Per handoff gotcha #6.
4. `Read cto_decisions` (Postgres) — last 10 rows ORDER BY `decided_at DESC` LIMIT 10.
5. `Read cto_handoff` (Postgres) — SELECT narrative, version, updated_at FROM ops.cto_handoff LIMIT 1.
6. `Pack LLM context` (Code) — merges state snapshots + event + mandate system prompt + JSON schema reminder into a single `prompt` string.
7. `Claude decide` (HTTP Request) — POST to `http://host.docker.internal:9099/run` with model from workflow variable `CTO_MODEL` (default: `opus`, mapped by Claude CLI to `claude-opus-4-7` per Decision #1). Same pattern as Phase 1 bug-hunt's `claude analyze`. Uses ops' Max-OAuth-backed shim — zero API billing. Per-request override is possible via `$vars.CTO_MODEL`; unit/integration tests pin to specific full model IDs for reproducibility.
8. `Parse decision` (Code) — strips markdown fences, `JSON.parse`, validates action_type enum + required fields, throws on malformed (the error path also inserts a `cto_decisions` row via the noop-fallback in node #10, so audit log is never skipped).
9. `Router` (Switch) — 4 outputs keyed on `$json.decision.action_type`.
10. **log_only branch** — single `decisions: log_only insert` Postgres node.
11. **post_to_discord branch** — `Discord post` HTTP Request → `decisions: discord insert` Postgres node.
12. **spawn_sub_workflow branch** (live dispatch — Task #9a, 2026-04-22). Three nodes, replacing the prior STUB:
    - `spawn: sign + prepare` (Code) — reads `$('Parse decision').first().json.decision.sub_workflow_name` + `sub_workflow_inputs`, re-checks both against the allow-list, computes raw body `JSON.stringify(inputs)` + `t = floor(now/1000)` + `v1 = hex(hmacSha256(CTO_WEBHOOK_HMAC_SECRET, t + '.' + body))`, emits `{target_url, signed_body, signature_header, signature_t, target_workflow_name, decision, event, state_snapshot, sub_workflow_inputs}`. **Throws** (failing the execution) if `CTO_WEBHOOK_HMAC_SECRET` is unset — we never send unsigned. Same inline pure-JS SHA-256/HMAC implementation as `Validate event` (n8n task runner blocks `require('crypto')` and `crypto.subtle`). Target URL defaults to `http://ops-n8n:5678/webhook/<target>` (container-local, overridable via `$env.N8N_WEBHOOK_URL`).
    - `spawn: POST to target` (HTTP Request, typeVersion 4.4) — `method: POST`, `url: {{ $json.target_url }}`, body `{{ $json.signed_body }}`, header `X-CTO-Signature: {{ $json.signature_header }}`, **timeout 20 s** (specialists do long LLM calls; 10 s is too tight, but longer than 20 s wastes supervisor cycles when the specialist is going to run for 30–180 s regardless), `onError: continueRegularOutput` (axios timeout / ECONNABORTED / 4xx / 5xx all fall through to the insert node as an error item).
    - `spawn: insert decision` (Postgres) — writes exactly one `ops.cto_decisions` row. The `queryReplacement` is a self-invoking expression that inspects `$json`: if `statusCode >= 400` or an `error` field is present, writes `event_type='sub_workflow_spawn_failed'`, `action='spawn_failed'`, `outputs.severity='high'`, rationale citing the failure mode (`http_NNN` / `network_error` / `timeout_or_unknown`) and the original LLM rationale; otherwise writes `event_type='sub_workflow_spawned'`, `action='spawn_sub_workflow'`, `outputs.target_status`, `outputs.target_response_preview` (first 100 chars of body). Both paths emit exactly one row and flow to `Respond`.

    The sign-side HMAC pattern mirrors the specialist→merger `Sign merger` node (same algorithm, same header shape). Failed dispatches are logged at severity=high but NOT retried here — retry lives in the correction loop (Task #10 / `workflow-fixer`).
13. **escalate_to_user branch** (STUB, non-blocking per Decision #3) — INSERT row into `ops.cto_approvals` (status=`pending`, token generated server-side via `gen_random_uuid()`), THEN post `[STUB ESCALATION]` message to Discord with the short token ID, AND write `cto_decisions` row with `event_type='stub_escalation'`. No `sendAndWait` — the workflow exits immediately. A separate poll-and-resume mechanism (Task #6 workflow-fixer) will read pending rows and resume paused tasks once the user responds. See "Async approval queue" below.
14. `Respond` (Respond to Webhook) — returns 200 with `{decision_id, action, rationale_preview}`.

All 4 decision-branch endpoints converge into `Respond`, so the response always mirrors what was logged.

### 2a. spawn_sub_workflow dispatch (added 2026-04-22, Task #9a)

The live dispatch replaces the prior STUB with three responsibilities split across three nodes:

- **Target selection** — the LLM picks `sub_workflow_name` from a closed enum of ten workflows (`intake`, `brainstorm`, `debate`, `plan-features`, `exec-plan`, and the five `specialist-*` pairs' entry points). The `Parse decision` validator and the `sign + prepare` Code node both enforce the allow-list; an out-of-enum value demotes the decision to `log_only` with a `supervisor_schema_violation` rationale (no dispatch on ambiguous output).
- **Input passing** — the LLM also emits `sub_workflow_inputs` as a non-null, non-array object conforming to the target's webhook contract. All targets share the same contract shape (`{task_id?, parent_task_id?, input_doc_ref? or input_doc_content? (one required), triggered_by?}`), so the system prompt in `Pack LLM context` documents both the contract and a concrete example. The supervisor then signs `JSON.stringify(inputs)` with `CTO_WEBHOOK_HMAC_SECRET` and POSTs to `https://ops.finlet.dev/webhook/<target>` (container-local `http://ops-n8n:5678/webhook/<target>` by default).
- **Error handling** — failed dispatches (timeout > 20 s, HTTP 4xx / 5xx, connection errors) are logged with `event_type='sub_workflow_spawn_failed'`, `action='spawn_failed'`, `severity='high'` in `ops.cto_decisions`. The supervisor does NOT retry; retry is the correction loop's concern (`workflow-fixer`, Task #10). Because specialist webhooks auto-trigger their paired merger on completion, a successful dispatch means `specialist-<name>` AND `specialist-<name>-merger` will each write an `ops.cto_artifacts` row within ~30 s of the supervisor's return.

One action per decision — the LLM is instructed (system prompt rule #7) to emit exactly one `action_type` per invocation; batch spawns are not permitted.

## 3. Webhook contract

**Request**:
```json
POST /webhook/cto-supervisor
Content-Type: application/json
{
  "event_type": "discord_user_msg",
  "payload": { "text": "status?", "user": "justin", "channel_id": "..." },
  "source": "discord-relay|cron|team-completion-hook|intake|...",
  "triggered_at": "2026-04-20T19:30:00Z"
}
```

**Response** (HTTP 200):
```json
{
  "ok": true,
  "decision_id": 123,
  "action": "post_to_discord",
  "severity": "info",
  "rationale_preview": "cto_state has 0 active tasks; user asked for status — reply..."
}
```

**Response on validation failure** (HTTP 400): `{ "ok": false, "error": "event_type not recognized: foo_bar" }`. No `cto_decisions` row written — the validator rejects before state reads.

**Response on LLM/parse failure** (HTTP 200 with `action='log_only'`): we always write a `cto_decisions` row even on parse failure, with `event_type='supervisor_error'` and the raw LLM output in `outputs`. Hard constraint #4: every invocation writes exactly one row.

## 4. State-read contract (SQL)

```sql
-- Read cto_state
SELECT task_id, parent_task_id, team_name, stage, status, description,
       context, correction_round, created_at, updated_at, last_heartbeat_at
FROM ops.cto_state
WHERE status IN ('pending','in_progress','paused')
ORDER BY updated_at DESC
LIMIT 20
FOR UPDATE SKIP LOCKED;  -- per handoff gotcha #6

-- Read cto_decisions
SELECT id, decided_at, task_id, event_type, event_summary, action, rationale
FROM ops.cto_decisions
ORDER BY decided_at DESC
LIMIT 10;

-- Read cto_handoff
SELECT narrative, version, updated_at
FROM ops.cto_handoff
LIMIT 1;
```

`FOR UPDATE SKIP LOCKED` on `cto_state` is the handoff gotcha #6 mitigation: if another supervisor spawn is actively deciding on task X, this spawn skips task X rather than blocking. Trade-off: this spawn may miss a concurrent task row for one cycle. Acceptable — heartbeat cron re-surfaces stale rows.

## 5. LLM system prompt (verbatim)

The prompt is injected into the `claude-runner` `/run` POST body, preceding the event and state payload. Full text:

```
You are the Finlet CTO supervisor, an ephemeral orchestration process.

GOVERNING PRINCIPLES (non-negotiable):
1. NO BULLSHIT. Every decision must cite concrete signal — a specific row,
   metric, log line, message text, or state field. Never taste. If you cannot
   name the signal in your rationale, choose action_type=log_only and explain
   why no action is warranted.
2. YOU NEVER WRITE CODE, NEVER READ FILES, NEVER RUN SHELL COMMANDS. You are
   pure orchestrator. Your only outputs are: (a) a decision on which branch
   to fire, (b) a rationale, (c) structured inputs for the chosen branch.
3. YOU NEVER EMIT CODE OR FILE DIFFS. Any such output is a contract violation
   and will be rejected.
4. ROUTING: if an event matches an existing in-flight task in cto_state, prefer
   updating that task's state over spawning a new one. Only spawn a new task
   when the event introduces work that is not already in flight.
5. ESCALATION: reserved for product-vision questions, hard gates (severity
   critical, credential leaks, budget breaches, prod downtime), and explicit
   user asks that the CTO is not authorised to decide.
6. TONE: confident, terse, decisive. Answer first, reasoning after. No hedging.

YOUR INPUT contains: triggering event, up to 20 active cto_state rows, last 10
cto_decisions rows, and the current cto_handoff narrative.

YOUR OUTPUT is a single JSON object matching the schema below, wrapped in NO
prose, NO markdown fences, NO apology. Parse failures are a contract violation.

OUTPUT SCHEMA (all fields required unless marked nullable):
{
  "action_type": "log_only" | "post_to_discord" | "spawn_sub_workflow" | "escalate_to_user",
  "rationale": "<string, must cite a concrete signal from the inputs>",
  "severity": "info" | "low" | "medium" | "high" | "critical",
  "discord_message": <string or null>,                // required if action_type=post_to_discord or escalate_to_user
  "sub_workflow_name": <string or null>,              // required if action_type=spawn_sub_workflow; must be one of the known top-level workflows
  "sub_workflow_inputs": <object or null>,            // required if action_type=spawn_sub_workflow
  "task_state_update": <object or null>,              // nullable; when set, matches ops.cto_state columns
  "event_summary": "<string, <=200 chars, human-readable one-liner>"
}

KNOWN TOP-LEVEL WORKFLOWS (for sub_workflow_name; most not yet built):
  brainstorm, debate, plan-features, exec-plan,
  bug-hunt, bug-verify, workflow-fixer, intake

IF IN DOUBT, choose log_only with a rationale explaining the uncertainty. You
will be invoked again on the next relevant signal.
```

This prompt is stored verbatim in the `Pack LLM context` Code node and prepended to every LLM call. Edits to the prompt take effect on next invocation (per mandate line 3). The structured JSON schema prevents code emission by construction — `action_type` is a closed enum with no `emit_code` option.

## 6. LLM JSON output schema

```json
{
  "action_type": "log_only | post_to_discord | spawn_sub_workflow | escalate_to_user",
  "rationale": "string (must cite a concrete signal)",
  "severity": "info | low | medium | high | critical",
  "discord_message": "string | null",
  "sub_workflow_name": "string | null (one of: brainstorm, debate, plan-features, exec-plan, bug-hunt, bug-verify, workflow-fixer, intake)",
  "sub_workflow_inputs": "object | null",
  "task_state_update": "object | null (fields: task_id, team_name, stage, status, description, context, correction_round)",
  "event_summary": "string (<=200 chars)"
}
```

Validator (`Parse decision` node) enforces:
- `action_type` is one of the 4 literals
- `rationale` is a non-empty string
- `severity` is one of the 5 literals
- If `action_type == "post_to_discord"` or `"escalate_to_user"` → `discord_message` is non-empty
- If `action_type == "spawn_sub_workflow"` → `sub_workflow_name` and `sub_workflow_inputs` are non-null
- `event_summary` is ≤200 chars (truncated if longer)
- No field named `code`, `diff`, `patch`, `file_contents`, or `commit_message` — auto-reject (code-emission guard)

Malformed output routes to a `log_only` fallback row with `event_type='supervisor_error'`.

## 7. Decision router logic

Switch node keyed on `$json.decision.action_type`. Output 0..3 map to the 4 branches. Default (no match) never fires because the validator rejects unknown values upstream, but a 5th synthetic output writes a `cto_decisions` row with `event_type='supervisor_router_fallthrough'` to honour hard constraint #4.

## 8. cto_decisions insert contract

Every branch ends with a Postgres `executeQuery` node using a **single-JSON-parameter** pattern (not positional `$1,$2,...` with comma-separated `queryReplacement` — that pattern breaks when any string contains a comma, as observed in the initial smoke test).

```sql
WITH p AS (SELECT $1::jsonb AS d)
INSERT INTO ops.cto_decisions
  (decided_at, task_id, event_type, event_summary, action, rationale, inputs, outputs)
SELECT NOW(), NULL,
       d->>'event_type',
       d->>'event_summary',
       '<branch_action_literal>',
       d->>'rationale',
       (d->'inputs')::jsonb,
       (d->'outputs')::jsonb
FROM p
RETURNING id;
```

The node's `queryReplacement` is a single `JSON.stringify({event_type, event_summary, rationale, inputs, outputs})` expression. Postgres parses the whole payload server-side — no comma-parsing footgun.

Values populated per branch:

| Branch | task_id | event_type | action | outputs |
|---|---|---|---|---|
| log_only | from `task_state_update.task_id` (or null) | mirror inbound `event_type` | `log_only` | `{decision, branch: "log_only"}` |
| post_to_discord | from `task_state_update.task_id` (or null) | mirror inbound | `post_to_discord` | `{decision, branch, discord_status_code}` |
| spawn_sub_workflow (success) | null | `sub_workflow_spawned` | `spawn_sub_workflow` | `{decision, branch, target_workflow_name, target_status, target_response_preview}` |
| spawn_sub_workflow (failure) | null | `sub_workflow_spawn_failed` | `spawn_failed` | `{decision, branch, target_workflow_name, target_status, target_response_preview, error, severity: 'high'}` |
| escalate_to_user (STUB) | null | `stub_escalation` | `stub:escalate_to_user` | `{decision, branch, stub: true, discord_status_code}` |
| router_fallthrough | null | `supervisor_router_fallthrough` | `noop` | `{reason: "no router branch matched", decision}` |

`inputs` always carries the original event payload plus a small snapshot of state counts: `{event: {...original...}, state_snapshot: {active_tasks: N, recent_decisions: M, handoff_version: V}}`.

tsvector is generated column — populates automatically on insert.

## 9. Task-state writes

Only `log_only` and `post_to_discord` branches write to `cto_state` (MVP). When the LLM returns a non-null `task_state_update`, the branch runs an UPSERT matched on `task_id`:

```sql
INSERT INTO ops.cto_state (task_id, team_name, stage, status, description, context, correction_round)
VALUES (COALESCE($1, gen_random_uuid()), $2, $3, $4, $5, $6::jsonb, $7)
ON CONFLICT (task_id) DO UPDATE SET
  team_name = EXCLUDED.team_name,
  stage = EXCLUDED.stage,
  status = EXCLUDED.status,
  description = EXCLUDED.description,
  context = EXCLUDED.context,
  correction_round = EXCLUDED.correction_round,
  last_heartbeat_at = NOW()
RETURNING task_id;
```

If `task_state_update` is null, no `cto_state` write. This is MVP-simple; future iterations will write more aggressively from the `spawn_sub_workflow` branch once Tasks 4–8 land.

## 10. Extension points (Tasks 4–8 plug in here)

| Task | What plugs in | Where |
|---|---|---|
| Task 4 (skill-graph workflows) | **Landed in Task #9a (2026-04-22)** — the STUB is replaced with the 3-node real dispatch path (`sign + prepare` → `POST to target` → `insert decision`). Each target workflow (`intake` / `brainstorm` / `debate` / `plan-features` / `exec-plan` / `specialist-*`) exposes an HMAC-gated webhook; the supervisor signs the LLM-built `sub_workflow_inputs` payload and POSTs. | Real dispatch in the `spawn_sub_workflow` branch (nodes 12a–12c in the graph above). |
| Task 5 (specialists + mergers) | Spawned by `exec-plan` transitively. Supervisor never calls them directly — only the top-level workflow. | No change needed here. |
| Task 6 (workflow-fixer + intake) | Same `spawn_sub_workflow` extension point; intake is invoked by `intake_signal` event type, workflow-fixer by correction-loop logic inside `exec-plan`. | STUB node. |
| Task 7 (bug-hunt/bug-verify re-route) | Those workflows start POSTing to `POST /webhook/cto-supervisor` with `event_type=bug_hunt_signal` / `bug_verify_signal` instead of their own downstream effects. | Webhook + enum already in place. |
| Task 8 (cron workflows) | Each cron is a n8n Schedule Trigger → HTTP POST to the supervisor webhook with `event_type=heartbeat_tick` / `digest_tick` / `self_compact_tick`. Supervisor's LLM decides what to do based on state. | Webhook + enum already in place. |

**The webhook contract is the seam.** All Tasks 4–8 plug into it without re-shaping the supervisor graph.

## 11. Auth — HMAC signed webhooks (Decision #4, 2026-04-20)

All requests to `POST /webhook/cto-supervisor` MUST include an `X-CTO-Signature` header. Unsigned requests, requests with malformed/expired/mismatched signatures return **HTTP 401** and write a row to `ops.cto_decisions` with `event_type='auth_rejected'`, `action='log_only'`, rationale quoting the specific failure reason (missing header, bad timestamp, signature mismatch, etc.).

### Spec

- **Shared secret**: 32 bytes (64 hex chars), generated on the ops box via `openssl rand -hex 32`. Stored in `/opt/finlet-ops/compose/.env` as `CTO_WEBHOOK_HMAC_SECRET=<hex>` and injected into the `ops-n8n` container via `docker-compose.yml` (`CTO_WEBHOOK_HMAC_SECRET: ${CTO_WEBHOOK_HMAC_SECRET}` under `environment:`). Accessed in the `Validate event` Code node via `$env.CTO_WEBHOOK_HMAC_SECRET`.
- **Header format**: `X-CTO-Signature: t=<unix_ts_seconds>,v1=<hex_hmac_sha256>`
- **Signed payload**: `f"{t}.{raw_body}"` — Unix timestamp as ASCII digits, a single `.`, then the raw request body bytes.
- **Replay window**: `|now - t| <= 300` seconds (5 minutes). Exceeding the window is an auth rejection.
- **Algorithm**: `HMAC-SHA256(secret, signed_payload)`, rendered as lowercase hex.
- **Constant-time compare**: XOR-folding loop (the n8n task runner blocks `require('crypto')` and does not expose `crypto.subtle` globally — a pure-JS SHA-256 + HMAC is embedded in `Validate event`).

### Reference signer (Python)

```python
import hmac, hashlib, time

secret = "<64-hex>"           # CTO_WEBHOOK_HMAC_SECRET
raw_body = '{"event_type":"heartbeat_tick","payload":{},"source":"cron",' \
           '"triggered_at":"2026-04-20T21:00:00Z"}'
t = int(time.time())
sig = hmac.new(secret.encode(), f"{t}.{raw_body}".encode(), hashlib.sha256).hexdigest()
# POST with:
#   Content-Type: application/json
#   X-CTO-Signature: t={t},v1={sig}
#   body = raw_body (unchanged)
```

### Reference signer (bash)

```sh
SECRET="<64-hex>"
BODY='{"event_type":"heartbeat_tick","payload":{},"source":"cron","triggered_at":"2026-04-20T21:00:00Z"}'
T=$(date +%s)
SIG=$(printf '%s.%s' "$T" "$BODY" | openssl dgst -sha256 -hmac "$SECRET" -r | awk '{print $1}')
curl -sS -X POST https://ops.finlet.dev/webhook/cto-supervisor \
  -H 'Content-Type: application/json' \
  -H "X-CTO-Signature: t=$T,v1=$SIG" \
  --data-raw "$BODY"
```

All downstream callers (cron workflows, sub-workflows posting back, the intake workflow) MUST sign. Provision the same secret into any container or systemd unit that will POST.

### Provisioning locations (live)

| Location | Mechanism | Status |
|---|---|---|
| `/opt/finlet-ops/compose/.env` on ops box | `CTO_WEBHOOK_HMAC_SECRET=<hex>` | provisioned 2026-04-20 |
| `ops-n8n` container | injected via `docker-compose.yml` `environment:` | provisioned; validated `$env.CTO_WEBHOOK_HMAC_SECRET` readable inside Validate event |
| Future cron workflows (Task #8) | to provision via same env var | pending Task #8 |

### Rotation plan

Generate a new secret, append as `CTO_WEBHOOK_HMAC_SECRET_NEW`, update `Validate event` to accept both secrets for a grace window, roll callers, then remove the old. Not automated — manual for now.

## 12. Async approval queue (Decision #3, 2026-04-20)

Escalations (severity ∈ {high, critical}) and workflow-fixer proposals use `ops.cto_approvals` as a durable queue. The supervisor never blocks on Discord `sendAndWait`. It writes a pending row, posts a Discord message containing the short-form token, and exits.

### Schema (migration `004_cto_approvals.sql`)

```sql
CREATE TABLE ops.cto_approvals (
    id                   BIGSERIAL    PRIMARY KEY,
    requested_at         TIMESTAMPTZ  NOT NULL DEFAULT now(),
    task_id              UUID         REFERENCES ops.cto_state(task_id)     ON DELETE SET NULL,
    decision_id          BIGINT       REFERENCES ops.cto_decisions(id)      ON DELETE SET NULL,
    severity             TEXT         NOT NULL
        CHECK (severity IN ('high','critical')),
    prompt_text          TEXT         NOT NULL,
    proposed_action      JSONB        NOT NULL,
    status               TEXT         NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending','approved','rejected','timed_out','auto_acted')),
    resolved_at          TIMESTAMPTZ,
    resolved_by          TEXT,                     -- Discord user ID or 'cron_timeout' / 'cron_auto_act'
    resolution_notes     TEXT,
    discord_message_id   TEXT                      -- for reaction-based resolution
);
-- Partial index for pending queue scans (workflow-fixer poll).
CREATE INDEX idx_cto_approvals_pending_requested_at
  ON ops.cto_approvals (requested_at) WHERE status = 'pending';
```

Plus three FK-supporting indexes + a status+time timeline index + a partial index on `discord_message_id`.

### Supervisor write path (current, STUB)

The `escalate: STUB insert` Postgres node runs a CTE that:
1. Generates `approval_token` via `gen_random_uuid()` (pgcrypto).
2. INSERTs into `ops.cto_approvals` (status=`pending`, severity coerced to `high` if LLM returned something softer, `proposed_action` JSONB captured from the LLM output).
3. INSERTs into `ops.cto_decisions` (audit row) with `event_type='stub_escalation'`, `action='stub:escalate_to_user'`, `outputs` carrying `{approval_id, approval_token, decision, branch, stub: true}`.
4. Returns `{approval_id, decision_id, approval_token, approval_token_short}` to the next node.

The `escalate: STUB discord` HTTP Request node then posts `[STUB ESCALATION] <msg> | severity=<sev> | rationale: <...> | Approve ✅ / Reject ❌ — ID: <approval_token_short>` to Discord. Workflow exits via the existing `Respond` node.

### Resume path (Task #6, workflow-fixer)

TBD — decision pending between:
1. **Discord reaction resolver**: Discord bot watches for ✅ / ❌ reactions on messages matching `discord_message_id`, resolves the row on reaction.
2. **Slash command**: `/cto-approve <token>` or `/cto-reject <token>` posted to Discord, resolver workflow reads & updates.
3. **Web UI**: minimal page at `ops.finlet.dev/approvals` listing pending rows with buttons.

The row is durable regardless of resume mechanism. Timeouts (`status='timed_out'`) will be swept by a cron that nulls out rows older than N hours — configurable in the mandate.

### Auto-act severity gate

Decisions with severity ∈ {info, low, medium} do NOT enter the queue — the supervisor acts immediately (log_only / post_to_discord / spawn_sub_workflow). Only high + critical go through the queue. This matches `project_cto_governance` memory: auto-fix {high, medium, low, info}, only critical escalates live — tightened here to ALSO queue severity=high because high-impact changes deserve user visibility even when pre-approved by the mandate.

## 13. Known limitations (v1)

1. **LLM call is not cached.** Every invocation pays for a full prompt+completion. At 5-min heartbeat cadence, this is ~288 calls/day — at ~500 tok/call, ~144k tok/day. Using Max OAuth via claude-runner shim → $0 marginal. When we switch to Anthropic API (if Max OAuth is deprecated or rate-limited), add prompt caching.
2. **`FOR UPDATE SKIP LOCKED` can starve a row forever** if every spawn races on it. Not a realistic failure mode at current scale (single-digit concurrent spawns). Heartbeat cron re-surfaces any row whose `last_heartbeat_at` exceeds the deadline.
3. **`cto_handoff` is single-row.** We read it as gospel. A future task will have self-compact cron rewrite it daily; until then, it stays at version=1 manual_seed, which is fine for MVP.
4. **Three Postgres queries per invocation is fine at current scale** but grows with event rate. Batching into a single query-of-queries is a Phase 4 optimisation.
5. **No structured trace/observability layer.** Every decision lands in `ops.cto_decisions` which is queryable but not tool-friendly. Langfuse is on the roadmap (docs/AGENT_OPS_STACK.md).
6. **MVP stubs the three non-MVP branches.** If the LLM picks `spawn_sub_workflow` or `escalate_to_user` before Tasks 4–8 land, the user sees a `[STUB ESCALATION]` Discord post (for escalate) or a silent `stub_spawn_attempted` row (for spawn). That is intentional — fails loud for escalate, fails quiet for spawn.
7. **Inline pure-JS SHA-256/HMAC in `Validate event`.** Adds ~60 lines and is O(len) per request. Fine for bodies up to tens of KB. If the n8n task runner ever exposes `crypto.subtle` globally or un-blocks `require('crypto')`, swap it out.

## 14. Open questions (still unresolved)

- **Discord channel split**: single `#cto` channel vs separate `#cto-digest` / `#cto-escalations` / `#cto-errors`. Deferred — will decide after first live digest landing.

## 15. Smoke test protocol

**Signed happy path** (should return HTTP 200 + `{ok:true, decision_id, action, severity, rationale_preview}`):

```bash
SECRET="<CTO_WEBHOOK_HMAC_SECRET>"
BODY='{"event_type":"discord_user_msg","payload":{"text":"status?","user":"test"},"source":"smoke-test","triggered_at":"2026-04-20T21:00:00Z"}'
T=$(date +%s)
SIG=$(printf '%s.%s' "$T" "$BODY" | openssl dgst -sha256 -hmac "$SECRET" -r | awk '{print $1}')
curl -sS -X POST https://ops.finlet.dev/webhook/cto-supervisor \
  -H 'Content-Type: application/json' \
  -H "X-CTO-Signature: t=$T,v1=$SIG" \
  --data-raw "$BODY"
```

Assert (a) HTTP 200, (b) response has `decision_id > 0`, (c) exactly 1 new `cto_decisions` row with action ∈ {log_only, post_to_discord}, (d) LLM rationale cites the inbound text, (e) claude-runner returned `model: "opus"` in its response JSON.

**Unsigned rejection path** (should return HTTP 401 + `{ok:false, error:"auth_rejected", decision_id}`):

```bash
curl -sS -X POST https://ops.finlet.dev/webhook/cto-supervisor \
  -H 'Content-Type: application/json' \
  --data-raw '{"event_type":"discord_user_msg","payload":{"text":"probe"},"source":"unauth","triggered_at":"2026-04-20T21:00:00Z"}'
```

Assert (a) HTTP 401, (b) `cto_decisions` row with `event_type='auth_rejected'`, `action='log_only'`, rationale names the specific failure ("missing X-CTO-Signature header", "signature mismatch", "timestamp outside 300s replay window", etc.).

**Additional rejection variants** to cover in integration tests:
- Expired timestamp: sign with `t = now - 500` → expect 401 with "timestamp outside 300s replay window".
- Bad signature: send valid `t` but random 64-hex `v1` → expect 401 with "signature mismatch".
- Malformed header: `X-CTO-Signature: garbage` → expect 401 with "malformed signature header".

All four cases verified live on workflow `bdXgn8qqq1X4d8qb` on 2026-04-20 — see `cto_decisions` rows 11–15 (pending formal cleanup).
