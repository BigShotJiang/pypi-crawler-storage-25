# cron workflows — Design

> Written: 2026-04-20 (CTO Orchestration Phase 3 / Task #8)
> Status: MVP — 3 workflows active; heartbeat runs every 5 min to keep claude-runner OAuth warm.
> Depends on: migrations 001–005; `cto-supervisor` (`bdXgn8qqq1X4d8qb`); `CTO_WEBHOOK_HMAC_SECRET`; `DISCORD_WEBHOOK_CTO`; `N8N_INTERNAL_JWT`.

---

## 1. Scope

Three scheduled workflows cover the supervisor's self-maintenance surface.

| Workflow | Cadence | Role |
|---|---|---|
| `cron-digest-hourly` | `0 * * * *` | Reads the prior hour's `cto_decisions` and posts a ≤15-line summary to `#cto-decisions`. |
| `cron-heartbeat-5min` | `*/5 * * * *` | Keeps claude-runner OAuth warm, surfaces stale `cto_state` tasks, polls `cto_approvals` for approved patches and applies them. |
| `cron-self-compact-24h` | `0 0 * * *` | Rewrites `ops.cto_handoff.narrative` from the last 24h of decisions. |

Each cron emits exactly one `cto_decisions` audit row per tick (plus additional rows for substantive actions — applied patches, escalations, etc.). No workflow posts to Discord without a corresponding `cto_decisions` row.

All three workflows add a secondary `Webhook` trigger (path `/<workflow-name>/test`) so `mcp__n8n__n8n_test_workflow` can fire them manually. Production uses the `Schedule Trigger`. Both triggers connect into the same downstream graph via a shared `Merge` (or independent fan-in into the first shared node, depending on workflow).

## 2. cron-digest-hourly

### Input

`Schedule Trigger` (`0 * * * *`) OR `Webhook` POST to `/webhook/cron-digest-hourly/test` (no auth, internal only — smoke path).

### Graph shape

```
Schedule (0 * * * *) ──┐
                        ├─→ Read decisions (Postgres: last-hour rows)
Webhook /test ─────────┘        ↓
                          Branch on row count (If: rows.length == 0)
                          ├─ no rows ─→ log_tick_noop (decisions insert) → Respond
                          └─ has rows ─→ Build digest prompt (Code)
                                              → Digest LLM (HTTP → claude-runner, opus)
                                              → Parse digest output (Code: strip fences, cap 15 lines)
                                              → Post Discord (HTTP POST DISCORD_WEBHOOK_CTO)
                                              → Write decision (Postgres: digest_tick row)
                                              → Respond
```

9 nodes on happy path + 2 for no-rows shortcut = 11 total.

### Read decisions node (SQL)

```sql
SELECT id,
       decided_at,
       event_type,
       action,
       left(event_summary, 300) AS event_summary,
       outputs->>'severity' AS severity
FROM ops.cto_decisions
WHERE decided_at >= now() - interval '1 hour'
ORDER BY decided_at DESC
```

### No-rows branch

Skips Discord entirely. Writes one `cto_decisions` row:
- `event_type = 'digest_tick'`
- `action = 'log_only'`
- `event_summary = 'hourly digest: 0 rows in prior hour; no Discord post'`
- `rationale = 'quiet hour. No decisions to summarize.'`

### Digest prompt (system prompt)

```
You are producing a CTO decision digest.

GOVERNING PRINCIPLES (non-negotiable):
1. NO BULLSHIT. Do not invent decisions not in the data. Every line must
   cite one or more specific decision IDs from the input rows.
2. LEAD WITH SEVERITY. If any row has severity=high or critical, put it
   on line 1.
3. TONE: terse, scannable, Discord-friendly.

LENGTH CONTRACT:
- <=15 lines total.
- 1 line per distinct decision cluster (multiple rows on same subject may
  collapse into 1 line).
- If the input has >15 distinct clusters, produce the top 14 by severity/
  recency, and close with one line: "See `#cto-decisions` history for N more items."

OUTPUT FORMAT: raw Discord markdown. No preamble, no postamble, no JSON,
no code fences. Just the <=15 lines, separated by newlines.

BANNED OUTPUT: code, diffs, patches, file contents, SQL.
```

Prompt body: the system prompt followed by `==== INPUT ROWS (${rows.length}) ====\n${JSON.stringify(rows, null, 2)}\n==== YOUR DIGEST ====\n`.

### Parse digest output (Code node)

- Trim whitespace, strip any accidental markdown fences.
- Split on newlines; keep first 15 non-empty lines.
- If parse yields empty, fall back to `digest unavailable (LLM returned empty); ${rows.length} rows in prior hour, IDs: ${rowIds.join(', ')}`.
- Returns `{ content, line_count, row_count }`.

### Discord post

`POST $env.DISCORD_WEBHOOK_CTO` with:

```json
{ "content": "**CTO Hourly Digest — <UTC ISO>**\n\n<digest_body>" }
```

Header uses a neutral prefix (no emoji) so Discord special-char escaping stays clean. Timeout 30s. `continueOnFail: true` — Discord outage must not lose the audit row.

### Write decision

Postgres insert (same single-JSON-parameter pattern as supervisor):

- `event_type = 'digest_tick'`
- `action = 'digest_posted'` (or `'digest_post_failed'` if Discord status >= 400)
- `event_summary = 'hourly digest: ${row_count} rows → ${line_count} lines → Discord status ${status}'`
- `rationale = 'summarized IDs: ${rowIds.slice(0, 20).join(\",\")}' + (rowIds.length > 20 ? ' (+more)' : '')'`
- `inputs = { rows_count, row_ids_first_50, tick_ts }`
- `outputs = { discord_status, digest_content, line_count }`

### Respond

200 JSON: `{ ok: true, rows_summarized, line_count, discord_status, decision_id }`.

## 3. cron-heartbeat-5min

### Input

`Schedule Trigger` (`*/5 * * * *`) OR `Webhook` POST to `/webhook/cron-heartbeat-5min/test`.

### Graph shape

Three independent branches fan out from the trigger; each branch terminates independently (no shared output merge — parallel execution).

```
Schedule (*/5 * * * *) ──┐
                          ├─→ A: ping claude-runner   → if OK: write heartbeat_tick decision
Webhook /test ──────────┘              └─→ if 401: write heartbeat_oauth_stale + post Discord
                          │
                          ├─→ B: find stale cto_state rows → for each: write heartbeat_stale_task decision
                          │
                          └─→ C: poll approved cto_approvals → for each:
                                  apply patches via n8n REST → on OK: update approval + write workflow_fixer_applied
                                                             → on fail: update approval + write workflow_fixer_apply_failed + Discord
```

16 nodes approximate (A=3-4, B=2-3, C=5-6, +shared trigger/webhook/respond).

### Branch A — OAuth warm ping

1. **Ping claude-runner** — HTTP POST `http://host.docker.internal:9099/run`, body `{"prompt":"ping","model":$vars.CTO_MODEL || 'opus',"max_tokens":10,"timeout":30}`, timeout 45s, `continueOnFail: true`. We don't care about the response body — we care about the HTTP status and whether the response contains an OAuth-stale indicator.
2. **Check result** — Code node: inspect response. If `statusCode == 401` OR `stderr` contains "Invalid bearer token" / "OAuth" / "expired", flag `oauth_stale = true`.
3. **Branch on oauth_stale** — IF node.
   - OK path: write `cto_decisions` row `event_type='heartbeat_tick'`, `action='heartbeat_ok'`, rationale cites latency ms + model.
   - Stale path: write `cto_decisions` row `event_type='heartbeat_oauth_stale'`, `action='escalate_to_user'`, `severity='critical'` (in outputs JSONB), AND POST Discord with `[CRITICAL] CTO heartbeat: claude-runner OAuth stale. 401/OAuth failure on ping. Rotate Max plan session or restart claude-runner.`.

### Branch B — stale cto_state detection

1. **Find stale rows** — Postgres:
   ```sql
   SELECT task_id, team_name, stage, status, last_heartbeat_at,
          description, correction_round
   FROM ops.cto_state
   WHERE status IN ('pending','in_progress')
     AND last_heartbeat_at < now() - interval '15 minutes'
   ORDER BY last_heartbeat_at ASC
   LIMIT 50
   ```
2. **For each stale row** — SplitInBatches (batch size 1). For each item:
   - Write `cto_decisions` row `event_type='heartbeat_stale_task'`, `action='log_only'`, `event_summary='stale task: ${team_name}/${stage} task_id=${task_id}, last heartbeat ${minutes_ago}m ago'`, `rationale='heartbeat surfaced stale task. task_id=${task_id}; team=${team_name}; stage=${stage}; status=${status}; correction_round=${correction_round}. Real nudging deferred to Task #9/#10.'`

No Discord posts from branch B (log-only per spec).

### Branch C — apply approved workflow-fixer patches

1. **Poll approved approvals** — Postgres:
   ```sql
   SELECT id, task_id, decision_id, severity, proposed_action, resolved_at, resolved_by
   FROM ops.cto_approvals
   WHERE status = 'approved'
     AND resolved_at > now() - interval '1 hour'
   ORDER BY resolved_at ASC
   LIMIT 10
   ```
2. **SplitInBatches (1)** — iterate.
3. **Extract patch batch** — Code: parse `proposed_action` JSONB, pull `target_workflow_id` and `patches[]`, validate each patch has `node_id`, `field`, `after_excerpt`. Reject whole approval if malformed → flag `apply_failed: schema`.
4. **Fetch target workflow** — HTTP GET `http://localhost:5678/api/v1/workflows/{{ target_workflow_id }}`, header `X-N8N-API-KEY: {{ $env.N8N_INTERNAL_JWT }}`.
5. **Apply patches** — Code node: walk `nodes[]`, match on `node_id`, apply field updates (mutate system_prompt / json_body / parameters string fields). Track `applied_count` and `skipped_count` (node not found → skip + log).
6. **PUT updated workflow** — HTTP PUT `http://localhost:5678/api/v1/workflows/{{ target_workflow_id }}`, body = mutated workflow JSON. `continueOnFail: true`.
7. **Branch on PUT result** — IF node.
   - OK path: UPDATE `cto_approvals SET status='applied'`, write `cto_decisions` row `event_type='workflow_fixer_applied'`, `action='workflow_fixer_applied'`, `event_summary='applied ${applied_count} patches to ${target_workflow_id} (approval ${id})'`, AND post Discord confirmation.
   - Fail path: UPDATE `cto_approvals SET status='apply_failed'`, write `cto_decisions` row `event_type='workflow_fixer_apply_failed'` with `severity='high'` in outputs, AND post Discord `[HIGH] workflow-fixer apply failed: approval ${id}, target ${target_workflow_id}, error: ${error}`.

### Why no shared LLM call for B/C

Branch A is the only LLM call (and only so we stress the OAuth session). B and C are deterministic — LLM cost for routine heartbeat work is waste.

## 4. cron-self-compact-24h

### Input

`Schedule Trigger` (`0 0 * * *` UTC) OR `Webhook` POST to `/webhook/cron-self-compact-24h/test`.

### Graph shape

```
Schedule (0 0 * * *) ──┐
                        ├─→ Read current handoff (Postgres SELECT ops.cto_handoff)
Webhook /test ─────────┘       → Read last-24h decisions (Postgres)
                               → Read active tasks count (Postgres)
                               → Build compact prompt (Code)
                               → Compact LLM (HTTP → claude-runner, opus, timeout 300)
                               → Parse narrative (Code: strip fences, length guard)
                               → Update handoff (Postgres UPDATE — explicit version bump)
                               → Write decision (Postgres: self_compact_tick)
                               → Respond
```

10 nodes.

### Read queries

```sql
-- Current handoff
SELECT narrative, version, updated_at, updated_by FROM ops.cto_handoff WHERE id = true;

-- Last 24h decisions
SELECT id, decided_at, event_type, action,
       left(event_summary, 400) AS event_summary,
       left(rationale, 400) AS rationale,
       outputs->>'severity' AS severity
FROM ops.cto_decisions
WHERE decided_at >= now() - interval '24 hours'
ORDER BY decided_at DESC
LIMIT 500;

-- Active tasks count
SELECT count(*) AS active_count
FROM ops.cto_state
WHERE status IN ('pending','in_progress','paused');
```

### Compact prompt (system prompt)

```
You are compacting the Finlet CTO handoff narrative.

GOVERNING PRINCIPLES (non-negotiable):
1. NO BULLSHIT. Every statement about last-24h activity must cite at
   least one decision ID from the input. Citations use the form
   `decision #42` (plain text, no markdown link).
2. MINIMAL LOSS. The current narrative contains status context the next
   CTO spawn depends on. Integrate last-24h activity WITHOUT dropping
   prior context that remains relevant.
3. YOU DO NOT EMIT CODE, DIFFS, PATCHES, or FILE CONTENTS.

OUTPUT FORMAT: pure markdown. ~150 lines target. Sections in this order:

## Status
<one paragraph: what's the system doing RIGHT NOW, citing active task count>

## Last 24h Activity
<bulleted or short-paragraph summary, grouped by theme, citing decision IDs>

## Active Tasks
<list from the active_state rows if any, keyed by task_id and team_name>

## Open Approvals
<summarize any pending cto_approvals rows the input mentions>

## Known Issues
<carry forward from prior narrative's Known Issues + anything critical from
 last 24h>

## Next Actions
<what the next CTO spawn should prioritise, 3-7 bullets>

OUTPUT ONLY MARKDOWN. No preamble, no JSON, no code fences around the whole
thing.
```

Prompt body: the system prompt + `==== CURRENT NARRATIVE (version ${version}) ====\n${narrative}\n\n==== LAST 24H DECISIONS (${decisions.length} rows) ====\n${JSON.stringify(decisions, null, 2)}\n\n==== ACTIVE TASK COUNT ====\n${active_count}\n\n==== YOUR NEW NARRATIVE ====\n`.

### Parse narrative

- Strip `^```markdown?\\n` and trailing `\\n```$` if present.
- Verify non-empty; if empty, fall back to `# CTO Handoff\n\n## Status\nCompact failed at ${ISO_TIMESTAMP}: LLM returned empty. Prior narrative retained. See decision for details.`.
- Optional length guard: if output > 30KB, truncate to first 30KB + `\n\n[truncated at 30KB]`.
- Return `{ narrative, length, version_next }`.

### Update handoff (SQL)

Pre-empt the trigger's auto-bump by setting `version` explicitly:

```sql
UPDATE ops.cto_handoff
SET narrative = $1::text,
    updated_by = 'self_compact_cron',
    version = (SELECT version FROM ops.cto_handoff WHERE id = true) + 1
WHERE id = true
RETURNING version, length(narrative) AS narrative_len;
```

Per migration 003's trigger logic, when `NEW.version != OLD.version` the trigger does NOT re-bump. This keeps us at exactly +1 per tick.

### Write decision

- `event_type = 'self_compact_tick'`
- `action = 'log_only'`
- `event_summary = '24h self-compact: handoff v${new_version}, ${decisions.length} decisions summarised, narrative ${new_length}B'`
- `rationale = 'compacted narrative from v${old_version} to v${new_version}. input: ${decisions.length} decisions over 24h, ${active_count} active tasks. cited decision IDs: ${sample_cited_ids.join(\",\")}'`
- `outputs = { old_version, new_version, old_length, new_length, decisions_count }`

## 5. Shared conventions

### Postgres credential

All Postgres nodes reuse the existing `ops-postgres` credential (id `cQZd1wW1MLtHoMTH`) — same as supervisor/intake/workflow-fixer.

### Insert pattern

Single-JSON-parameter `executeQuery` (not positional):

```sql
WITH p AS (SELECT $1::jsonb AS d)
INSERT INTO ops.cto_decisions (decided_at, task_id, event_type, event_summary, action, rationale, inputs, outputs)
SELECT NOW(), NULL,
       d->>'event_type', d->>'event_summary',
       d->>'action',     d->>'rationale',
       (d->'inputs')::jsonb,
       (d->'outputs')::jsonb
FROM p
RETURNING id
```

`queryReplacement` = `={{ JSON.stringify({ event_type, event_summary, action, rationale, inputs, outputs }) }}`.

### Model reference

All LLM calls use `$vars.CTO_MODEL || 'opus'` for forward-compat with the supervisor and to survive the Max OAuth deprecation plan.

### Webhook test triggers

Each workflow has a plain `n8n-nodes-base.webhook` (no HMAC) at path `/webhook/cron-<name>/test`, authPresentation `none`, httpMethod `POST`. Fired only by `mcp__n8n__n8n_test_workflow` + local curl for validation. Production path is the Schedule Trigger. This sidesteps the cron-only testability gotcha (memory `feedback_n8n_schedule_trigger_testability.md`).

### respondToWebhook nodes

`typeVersion: 1.1` for cross-workflow consistency with supervisor/intake.

### Error handling

- Discord POSTs: `continueOnFail: true`, `retryOnFail: true`, `maxTries: 2`.
- claude-runner calls: `retryOnFail: true`, `maxTries: 2`, `waitBetweenTries: 2000`.
- Postgres writes: no retry (idempotency not guaranteed on duplicate row).
- n8n REST API calls: `retryOnFail: true`, `maxTries: 2`.

## 6. What these cron workflows do NOT do (MVP)

- **Heartbeat branch B does not nudge stale teams.** It only logs. Real nudging (webhook POST to the supervising team workflow) is Task #9/#10.
- **Heartbeat branch C does not apply patches for rejected approvals.** Rejection path (update `status='rejected'`) is a separate workflow to be built.
- **Self-compact does NOT sync the git copy** at `docs/ops/CTO_HANDOFF.md`. n8n container can't push to git. A separate tool (systemd timer on a host machine with repo access, or a manual sync command) syncs later. Follow-up open.
- **Digest does not paginate beyond 15 lines.** The ">15 items" case appends one "see #cto-decisions history for N more" line, not a separate Discord message.
- **Heartbeat A does not rotate OAuth.** It only detects staleness and escalates. Rotation is user-driven (Max plan session refresh or claude-runner restart).

## 7. Gotchas

1. **n8n task runner blocks `require('crypto')`, `fetch`, `AbortController`.** Code nodes use `this.helpers.request` (when available) or rely on separate HTTP Request nodes.
2. **Schedule Trigger does not accept `$json` from an upstream caller.** The webhook-test path provides payload; the Schedule path provides an empty object. Downstream nodes must tolerate both (default to `{}`).
3. **Self-compact UPDATE must set `version` explicitly.** If `version` is unchanged in the SET clause, the migration 003 trigger auto-bumps by +1 AS WELL. Setting `version = old + 1` is idempotent-against-trigger.
4. **Heartbeat branch A's `continueOnFail: true` is load-bearing.** Without it, a claude-runner outage kills the whole heartbeat run and branches B/C silently skip.
5. **Apply patches walker is STRING-FIRST.** It only mutates string fields on nodes (system_prompt, json_body, jsCode, parameters.*). It does NOT add/remove nodes or restructure connections. If a patch specifies a non-string target, we log and skip that patch (and record apply_failed if all patches skip).
6. **Self-compact narrative size guard.** If LLM returns >30KB, we truncate rather than reject. A future version may reject + retry.
7. **Digest must JSON-escape the LLM output** inside `{"content": "..."}` when building the Discord POST body. Use `JSON.stringify({ content: header + '\n\n' + digest_body })` not manual string concat.
8. **Schedule ordering**: digest at `:00`, heartbeat at `:00, :05, :10, ...` — these overlap at top of hour. Each writes to `cto_decisions` without locking, so no contention. Self-compact at `00:00 UTC` overlaps with both; acceptable because self-compact reads the already-written rows.
9. **Heartbeat C approval query uses 1-hour window.** Approvals resolved >1 hour ago are considered stale-enough that a re-apply would be weird. If the user approves but we miss the window, the approval stays `approved` forever (harmless; visible in `cto_approvals` backlog).

## 8. Smoke test protocol

### Smoke 1 — digest

1. Insert 2 synthetic `cto_decisions` rows via Postgres:
   ```sql
   INSERT INTO ops.cto_decisions (decided_at, event_type, event_summary, action, rationale, outputs)
   VALUES (now() - interval '5 minutes', 'test_smoke', 'smoke row 1 for digest', 'log_only', 'synthetic test for cron-digest smoke', '{"severity":"medium"}'::jsonb),
          (now() - interval '2 minutes', 'test_smoke', 'smoke row 2 for digest', 'log_only', 'synthetic test for cron-digest smoke', '{"severity":"high"}'::jsonb);
   ```
2. Trigger: `mcp__n8n__n8n_test_workflow` on the digest workflow, webhook path `/webhook/cron-digest-hourly/test`, empty payload.
3. Assert:
   - Discord message posted to `#cto-decisions` with ≤15 lines, header includes UTC timestamp.
   - Digest body references severity=high row on line 1.
   - New `cto_decisions` row with `event_type='digest_tick'`, `action='digest_posted'`, `event_summary` includes row count.

### Smoke 2 — heartbeat

1. Trigger: `mcp__n8n__n8n_test_workflow` on heartbeat, webhook path `/webhook/cron-heartbeat-5min/test`, empty payload.
2. Assert:
   - Branch A: `heartbeat_tick` row written, NO `heartbeat_oauth_stale` row.
   - Branch B: log rows for any stale `cto_state` rows (there are 7 rows in the table; exact stale count depends on last_heartbeat_at).
   - Branch C: approvals #1 and #2 stay `pending` (no rows are `status='approved'` yet, so the SELECT returns 0 rows and no apply happens).
3. Verify claude-runner call took <10s (fast OAuth-fresh response).

### Smoke 3 — self-compact

1. Trigger: `mcp__n8n__n8n_test_workflow` on self-compact, webhook path `/webhook/cron-self-compact-24h/test`, empty payload.
2. Assert:
   - `ops.cto_handoff.version` increments by exactly 1 (pre: v1, post: v2).
   - New narrative length >0.
   - Narrative references 1-2 decision IDs from last 24h (spot check).
   - New `cto_decisions` row with `event_type='self_compact_tick'`, event_summary includes version + length.

## 9. Activation plan

1. Build + validate all 3 workflows. Leave `active: false`.
2. Smoke test each via webhook trigger.
3. On smoke-2 pass: activate `cron-heartbeat-5min` IMMEDIATELY (keeps OAuth warm; it's the single most critical cron).
4. On smoke-1 pass: activate `cron-digest-hourly`.
5. On smoke-3 pass: activate `cron-self-compact-24h`.

## 10. Open follow-ups

- Git-copy sync for `docs/ops/CTO_HANDOFF.md` — needs a host-side tool with repo-write access. Candidates: (a) systemd timer on laptop pulling the narrative via Postgres connection + committing, (b) GitHub Actions cron that SSHes to ops-postgres + commits.
- Branch B real nudging: when a stale task is detected, POST to the owning team's webhook to trigger status resync.
- Rejection path for branch C: handle `status='rejected'` approvals (UPDATE + audit, no apply).
- Discord pagination for >15-line digests: follow-up message chain in Discord instead of the one-line overflow hint.
- Langfuse observability once the trace layer lands.
