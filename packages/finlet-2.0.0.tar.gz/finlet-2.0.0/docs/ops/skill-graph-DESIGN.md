# skill-graph — Design (MVP)

> Ports the user's four Claude Code skills (`brainstorm`, `debate`, `plan-features`, `exec-plan`) to n8n webhook workflows.
> Built: 2026-04-20 (Task #4 of CTO Orchestration Phase 3).
> Status: MVP single-LLM-call vertical slice. Faithful to the skill *logic*; multi-round / multi-agent orchestration collapsed to single passes until Task #5 lands the specialists.
> Supersedes filesystem-backed brainstorm artifacts for automated CTO runs — human-invoked `/brainstorm` etc. still write to disk.

---

## 1. Workflow inventory

| Workflow | n8n ID | Webhook path | Input doc | Output doc | Active |
|---|---|---|---|---|---|
| `skill-brainstorm`    | (set on create) | `/webhook/skill-brainstorm`    | raw user signal markdown              | `requirements.md`      | yes |
| `skill-debate`        | (set on create) | `/webhook/skill-debate`        | `requirements.md` (by `ref`)          | `readiness-report.md`  | yes |
| `skill-plan-features` | (set on create) | `/webhook/skill-plan-features` | `readiness-report.md` + (optional) `requirements.md` | `execution-plan.md` | yes |
| `skill-exec-plan`     | (set on create) | `/webhook/skill-exec-plan`     | `execution-plan.md` (by `ref`)        | `execution-report.md`  | yes |

All four are webhook-triggered, HMAC-validated, opus-default. All four write exactly one `ops.cto_artifacts` row and exactly one `ops.cto_decisions` row per invocation. Deviations are contract violations.

```
raw signal ──► skill-brainstorm ──► requirements.md ──► skill-debate ──► readiness-report.md
                                                                              │
                                                                              ▼
                                         execution-plan.md ◄── skill-plan-features
                                                   │
                                                   ▼
                                            skill-exec-plan ──► execution-report.md (STUB v1)
```

## 2. Shared graph shape (all 4 workflows)

```
Webhook (rawBody) ──► Validate HMAC+input ──► Resolve input artifact (if ref) ──►
  Build prompt ──► Claude decide (opus via host.docker.internal:9099) ──►
    Parse + validate sections ──► Write cto_artifacts row ──►
      Write cto_decisions row ──► Respond JSON

(Validate error output) ──► auth_rejected insert ──► respond 401
```

10 nodes each:
1. `Webhook` — POST, `responseMode=responseNode`, `options.rawBody=true` (raw bytes land in `binary.data.data` base64, required for HMAC).
2. `Validate event` — Code node, inline pure-JS SHA-256 + HMAC (supervisor's verbatim). Checks header, replay window, signature, then validates the input schema (see §4). `onError: continueErrorOutput` wires the 401 path.
3. `Resolve input doc` — Code node. If `input_doc_ref` is set, reads the referenced artifact row; otherwise uses `input_doc_content`. One node does both so the prompt-builder sees a single shape.
4. `Build prompt` — Code node. Embeds the workflow-specific system prompt (see §3), the input doc, and the output schema reminder. Returns `{ prompt, model, task_id, parent_task_id, stage_input_ref }`.
5. `Claude decide` — HTTP POST to `http://host.docker.internal:9099/run` with `{ prompt, model: 'opus', timeout: 180 }`. Mirrors supervisor's node byte-for-byte (Decision #1 default opus). `retryOnFail: true, maxTries: 2, waitBetweenTries: 2000`.
6. `Parse output` — Code node. Strips markdown fences, validates all required sections are present (see §3), computes length + preview.
7. `Write artifact` — Postgres `executeQuery`. Single CTE that INSERTs into `ops.cto_artifacts` and `ops.cto_state` (upsert) in one round-trip. Returns `{ artifact_id, artifact_ref, task_id }`.
8. `Write decision` — Postgres `executeQuery`. INSERTs one `ops.cto_decisions` row using the single-JSON-parameter pattern from the supervisor. `event_type = <workflow name>`, `action = 'sub_workflow_result'`.
9. `Respond` — 200 JSON `{ ok, task_id, output_doc_ref, output_doc_preview, decision_id }`.
10. (on error path from node 2) `auth_rejected: insert` + `respond 401` — copied from supervisor.

## 3. Workflow system prompts

All four prompts MUST contain verbatim:

```
GOVERNING PRINCIPLES (non-negotiable):
1. NO BULLSHIT. Every section you write must cite the specific part of the
   input you are responding to — quote a line, name a section, or cite a
   concrete claim. Never taste. Never ungrounded speculation.
2. YOU NEVER WRITE CODE, NEVER EMIT FILE DIFFS, NEVER RUN SHELL COMMANDS.
   Your output is markdown prose only. Code blocks for non-illustrative
   purposes are a contract violation.
3. OUTPUT IS WELL-FORMED MARKDOWN with the exact named sections listed below.
   Missing a section is a contract violation and will be rejected.
4. TONE: confident, terse, decisive. Answer first, reasoning after. No hedging.
```

Plus workflow-specific role + section list:

### `skill-brainstorm`

```
ROLE: You are the BRAINSTORM stage of the Finlet CTO skill graph. You take a
raw user signal (a bug report, a feature idea, a pain point) and produce a
requirements doc that the DEBATE stage will attack.

INPUT: Raw user signal in markdown (may be a single sentence or a multi-
paragraph description).

OUTPUT (exact section headings, in order):
## Problem
  One paragraph naming the problem in the user's own language. Quote the
  part of the input you are restating.
## User Goals
  Bullet list of user-facing goals the feature or fix should achieve. Each
  bullet cites the input text that implies it.
## Scope Boundaries
  Bullet list of what is IN scope AND what is explicitly OUT of scope. Out-
  of-scope items prevent the plan stage from gold-plating.
## Feasibility Notes
  3-5 bullets on whether the stack already has the pieces (positive or
  negative), with cited file paths or architectural components when known.
  If you do not know, write "unknown — debate stage must investigate" —
  do NOT invent.
## Open Questions
  Bullet list of decisions the next stage must resolve. Each is phrased as
  a direct question.

NO OTHER SECTIONS. NO CODE. NO STRAY PROSE. NO "Conclusion".

v1 COLLAPSE NOTE: the Claude Code /brainstorm skill runs 3 parallel research
agents (feasibility / prior-art / conflict-check). In v1 you perform all
three perspectives in one pass and label each finding in Feasibility Notes.
Multi-agent split lands in Task #5.
```

### `skill-debate`

```
ROLE: You are the DEBATE stage of the Finlet CTO skill graph. You take a
requirements doc and adversarially stress-test it. Your output is a readiness
report the PLAN stage will act on.

INPUT: A requirements.md document produced by the brainstorm stage (fed to
you verbatim). You read ONLY this document — not the brainstorm
conversation, not any other stage.

OUTPUT (exact section headings, in order):
## Critic Attacks
  Numbered list of concrete attacks on the requirements. Each attack:
   - Quotes the part of requirements.md it attacks (use blockquote).
   - Names the risk or gap in plain terms.
   - Cites any concrete evidence (a competitor feature, a prior decision,
     a technical limitation). "I think" or "probably" without evidence is
     a contract violation.
## Defender Responses
  Numbered list mapping 1:1 to Critic Attacks. Each response either:
   - Defends the requirement by citing evidence the critic missed; or
   - Concedes and proposes a concrete patch ("change X to Y because Z").
## Moderator Verdict (GO / HOLD / KILL)
  Exactly one of GO, HOLD, or KILL on the first line, followed by 2-3
  sentences of justification. No "GO with caveats" — pick one.
## Citable Evidence
  Bullet list of every concrete signal cited above — file paths, URLs,
  decision-record names, prior-decision rationales. Deduplicated. This is
  the NO BULLSHIT audit trail for this stage.

NO OTHER SECTIONS. NO CODE. NO STRAY PROSE.

v1 COLLAPSE NOTE: the Claude Code /debate skill runs 5 agents across 3
rounds (arch-critic, comp-critic, code-defender, industry-defender,
moderator). In v1 you perform the single-pass synthesis covering all five
perspectives. Multi-agent split lands in Task #5.
```

### `skill-plan-features`

```
ROLE: You are the PLAN-FEATURES stage of the Finlet CTO skill graph. You
take a readiness report (and optionally the original requirements) and
produce an execution plan the EXEC-PLAN stage will dispatch against.

INPUT: A readiness-report.md (primary) and optionally a requirements.md
(context). You read ONLY these documents — not the debate conversation.

OUTPUT (exact section headings, in order):
## Goal
  One-paragraph restatement of what this execution will deliver, quoting
  the verdict line from the readiness report.
## File Conflict Analysis
  Markdown table: | File | Touched by specialists |. If exact file paths
  are unknown, cite the modules by name (e.g., `finlet/auth/`) and mark
  the cell "unknown — specialist to resolve".
## Dependency Graph (DAG)
  Plain-text DAG showing which tasks block which. Use arrow notation:
  Task 1 ── Task 3 ──┐
                     ├── Task 5
  Task 2 ── Task 4 ──┘
## Task Breakdown (per specialist)
  Numbered list. Each task has:
   - "Specialist: <one of: swe / devops / security / frontend-security /
     ai-research / solutions>"
   - "Blocked by: Task N, M, ... | none"
   - "Files touched: ..."
   - "Deliverable: one sentence"
   - "Validation: specific command or check"
   - Team names do NOT ship as letter codes in v1 — use Task N.
## Merge Gates
  Bullet list describing the per-task merge gate (usually "full pytest +
  ruff + mypy after each merge"), plus any task-specific extra gates.
## Rollback Plan
  Bullet list naming the revert path for each task that touches
  production code or infrastructure. If none, write "No rollback required —
  no production-impacting changes".

NO OTHER SECTIONS. NO CODE. NO STRAY PROSE. NO "Confidence: high".

v1 COLLAPSE NOTE: the Claude Code /plan-features skill runs Explore-agent
recon before planning. In v1 you make best-effort inferences from the
readiness report alone and explicitly mark unknowns. Recon agent integration
lands in Task #5.
```

### `skill-exec-plan` (STUB behavior in v1)

```
ROLE: You are the EXEC-PLAN stage of the Finlet CTO skill graph. In v1 you
do NOT spawn specialists. Instead, you read the execution plan and produce
an execution report that enumerates what WOULD be dispatched if the
specialists existed.

INPUT: An execution-plan.md document produced by the plan-features stage.

OUTPUT (exact section headings, in order):
## Tasks Dispatched
  Numbered list. For each task in the plan's "Task Breakdown", write:
   - "Task N → specialist-<name>: <deliverable>"
   - "STUB: specialist-<name> not yet built (see Task #5)."
## Results
  For each task, write: "PENDING — specialist not yet built" in v1.
## Merges Applied
  "None — no specialists ran."
## Failures + Rollbacks
  "None observed (nothing executed)."

v1 DESIGN NOTE: when Task #5 lands, this workflow's "Tasks Dispatched"
section will be produced by the real sub-workflow dispatcher (Execute
Workflow nodes per specialist), and "Results" will be populated from
their returns. The output-doc section structure is intentionally stable
across v1 → v2 so upstream consumers (the CTO supervisor's spawn_sub_workflow
branch) do not need to change.
```

## 4. Input / output contracts

Request (signed with HMAC, same as supervisor):
```json
POST /webhook/skill-<name>
Content-Type: application/json
X-CTO-Signature: t=<unix>,v1=<hex_hmac_sha256>
{
  "task_id": "<uuid or null>",
  "parent_task_id": "<uuid or null>",
  "input_doc_ref": "<uuid or null>",       // if set, read from ops.cto_artifacts.ref
  "input_doc_content": "<markdown or null>", // used if input_doc_ref is null
  "triggered_by": "supervisor | user | test | <other>",
  "hmac_authenticated": true
}
```

Either `input_doc_ref` or `input_doc_content` MUST be non-null. Both null → 400.

Response (200 happy path):
```json
{
  "ok": true,
  "task_id": "<uuid>",
  "output_doc_ref": "<uuid>",
  "output_doc_preview": "<first 400 chars of markdown>",
  "decision_id": 42
}
```

Response (401 auth rejection): `{ "ok": false, "error": "auth_rejected" }`.
Response (400 schema rejection): `{ "ok": false, "error": "<specific failure>" }` — section missing, banned field present, etc.
Response (500 LLM/parse failure): a `cto_decisions` row with `event_type='<workflow>_error'` is still written. The workflow never swallows errors silently.

## 5. Artifact storage schema

`ops.cto_artifacts` (migration 005). Key fields:

| Column | Purpose |
|---|---|
| `ref` | UUID external handle. The only value that crosses workflow boundaries. |
| `task_id` | FK → `cto_state.task_id`. Which in-flight task produced this. |
| `decision_id` | FK → `cto_decisions.id`. Audit-row linkage. |
| `workflow_name` | CHECK-enforced to `{intake, brainstorm, debate, plan-features, exec-plan}`. |
| `stage_input_ref` | UUID of the PRIOR stage's artifact. NULL for intake / brainstorm first-stage runs. |
| `content` | Raw markdown body. No JSON wrapping, no base64. |
| `content_sha256` | STORED GENERATED `encode(sha256(content::bytea), 'hex')`. Tamper-evident. |
| `metadata` | JSONB for model id, token counts, prompt version, etc. |
| `created_at` | Default `now()`. |

Indexes: `ref` (UNIQUE), `task_id`, `(workflow_name, created_at DESC)`, `stage_input_ref` (partial WHERE NOT NULL for lineage walks).

`intake` is included in the enum even though the workflow is not yet built (Task #6) — avoids a schema change when intake ships.

## 6. Separation-of-duties rules (enforced by construction)

Every skill workflow reads EXACTLY two things: the input artifact and its own system prompt. It DOES NOT read:
- `ops.cto_decisions` — no prior-conversation context bleeds in.
- `ops.cto_handoff` — not its job to carry cross-stage narrative.
- Other artifacts (except `plan-features` which explicitly takes the optional requirements ref).
- The caller's input beyond `input_doc_ref` / `input_doc_content`.

This is the mandate's principle #4 implemented as a Postgres query set, not a policy. A workflow that wanted to read `cto_decisions` would have to add a new Postgres node — visible in the diff, catchable in review.

## 7. Model choice

All four workflows default to `opus` (Decision #1 on the supervisor). Per-request override possible via workflow variable `SKILL_MODEL`, but MVP pins to opus for output quality. The `claude-runner` shim (`host.docker.internal:9099/run`) already maps opus → `claude-opus-4-7` and uses the ops Max-OAuth session — $0 marginal cost.

## 8. Smoke test protocol

### Single-workflow test (brainstorm)

```bash
SECRET="$CTO_WEBHOOK_HMAC_SECRET"
BODY='{"triggered_by":"smoke-test","hmac_authenticated":true,"input_doc_content":"Users cannot tell why their agent portfolio lost money — need an explainability view showing which trades drove the biggest P&L swings and why the agent made them."}'
T=$(date +%s)
SIG=$(printf '%s.%s' "$T" "$BODY" | openssl dgst -sha256 -hmac "$SECRET" -r | awk '{print $1}')
curl -sS -X POST https://ops.finlet.dev/webhook/skill-brainstorm \
  -H 'Content-Type: application/json' \
  -H "X-CTO-Signature: t=$T,v1=$SIG" \
  --data-raw "$BODY"
```

Assertions:
1. HTTP 200, response has `ok: true` + `output_doc_ref` UUID + `decision_id > 0`.
2. `SELECT workflow_name, length(content), substring(content_sha256,1,12) FROM ops.cto_artifacts ORDER BY id DESC LIMIT 1;` → `brainstorm, >500, <12-hex>`.
3. The content contains ALL of: `## Problem`, `## User Goals`, `## Scope Boundaries`, `## Feasibility Notes`, `## Open Questions`.
4. `SELECT event_type, action, substring(rationale,1,120) FROM ops.cto_decisions ORDER BY id DESC LIMIT 1;` → `brainstorm, sub_workflow_result, <rationale mentioning the input>`.

### Chain test (brainstorm → debate → plan-features)

1. Run the brainstorm test above. Capture `output_doc_ref` as `BRAINSTORM_REF`.
2. POST to `/webhook/skill-debate` with `{"input_doc_ref": "$BRAINSTORM_REF", "triggered_by":"smoke-test","hmac_authenticated":true}`. Capture `DEBATE_REF`.
3. POST to `/webhook/skill-plan-features` with `{"input_doc_ref": "$DEBATE_REF", "triggered_by":"smoke-test","hmac_authenticated":true}`. Capture `PLAN_REF`.
4. Verify lineage:
   ```sql
   SELECT a.workflow_name, a.stage_input_ref, b.workflow_name AS prior_stage
   FROM ops.cto_artifacts a
   LEFT JOIN ops.cto_artifacts b ON a.stage_input_ref = b.ref
   ORDER BY a.id DESC LIMIT 3;
   ```
   Expected rows:
   - `plan-features, <DEBATE_REF>, debate`
   - `debate, <BRAINSTORM_REF>, brainstorm`
   - `brainstorm, NULL, NULL`

### `skill-exec-plan` (deferred smoke)

Build + activate + validate the workflow, but DO NOT run it live. v1 stub behavior makes a live smoke useless — it would just emit "STUB: specialist not yet built" for every task. The first real smoke happens after Task #5 lands the specialists.

## 9. Known v1 limitations

1. **Single LLM call per stage.** Collapses brainstorm's 3 parallel research agents, debate's 5-agent 3-round loop, and plan-features' Explore-recon → synthesis split into a single opus pass. Faithful to the skill logic, not to the skill architecture. Multi-agent orchestration lands in Task #5.
2. **`skill-exec-plan` is stubbed.** Produces a plan-of-dispatches, not actual dispatches. Once Task #5 builds the six specialist + six merger workflows, `exec-plan` becomes an orchestration node that Execute-Workflow-dispatches per task.
3. **No Explore agent recon.** `skill-plan-features` infers file paths and conflicts from the readiness report's citations. Whenever those citations are thin, the output explicitly says "unknown — specialist to resolve". This is a known lossy collapse.
4. **No pre-flight test run.** `skill-exec-plan` in v1 does not run `pytest` before emitting a plan — there is no live exec anyway. Pre-flight logic moves in with Task #5.
5. **No post-execution eval.** Skill `eval.md` checks (from the human `/exec-plan` skill) are not enforced in v1. Eval ports in Task #5 alongside the specialists.
6. **Same-workflow retries.** If `Claude decide` fails twice with timeout, the workflow returns 500 and writes a `<workflow>_error` decision. No auto-retry at the supervisor level — the LLM is re-called next time the supervisor wakes on a relevant signal.
7. **Artifact content length unbounded.** `content TEXT` can hold anything up to PG's 1GB TOAST limit. Anecdotally opus emits 1-4KB for brainstorm outputs. If a future stage balloons to 100KB+, add a length cap in the `Write artifact` node.
8. **Content SHA-256 is after-the-fact.** The signature is on the DB row, not on the HTTP response. A compromised n8n process could emit one content and write another. Acceptable for MVP; post-launch we can hash in the JS parser and compare against the STORED GENERATED column.
9. **No vectorization / semantic search.** Nothing indexes artifact content for retrieval. If we need "find me all brainstorms that touched auth" later, add a `tsv` GENERATED column + GIN index — same pattern as `cto_decisions`.

## 10. Extension points for Task #5+

| Task | Extension |
|---|---|
| Task #5 — specialists + mergers | `skill-exec-plan` node 5 (`Claude decide`) gets replaced by a `Dispatch per task` loop that calls `Execute Workflow` per `specialist-<name>` + paired `specialist-<name>-merger`. Existing artifact + decision writes become summaries of the fan-out. |
| Task #6 — workflow-fixer + intake | `intake` ports into the shared graph shape (§2) with `workflow_name='intake'`. workflow-fixer is separate (operates on prompts, not artifacts) and does not use this graph. |
| Task #7 — bug-hunt / bug-verify through CTO | No change to skill-graph. Bug-hunt emits a `bug_hunt_signal` to the supervisor which decides whether to spawn `skill-brainstorm` via the (Task #5-landed) real spawn path. |
| Task #8 — cron workflows | No change. Crons send `heartbeat_tick` / `digest_tick` / `self_compact_tick` to the supervisor, never to skill-graph workflows directly. |

## 11. Why this graph (design rationale)

**Why webhooks and not Execute-Workflow?** The supervisor's `spawn_sub_workflow` branch will dispatch these by webhook (Task #5). Using the webhook boundary today means the signed-request + HMAC auth + audit-row invariants are the same seam the supervisor uses — no private API to maintain.

**Why a table, not S3?** Three reasons.
1. Transactional integrity: artifact row + decision row + state row in one DB commit. S3 would need a 2-phase handshake.
2. SHA-256 tamper-evidence is free via STORED GENERATED. S3 checksums are there but would require a post-read compute.
3. Local to the n8n host — no Hetzner → AWS egress, no credential proliferation. At expected sizes (single-digit KB per artifact, single-digit artifacts per day) we never hit Postgres storage pressure.

**Why opus and not sonnet?** Per Decision #1 on the supervisor: these skills produce the scaffolding that specialists will execute against. Output quality pays off downstream many times over. Max-OAuth makes cost moot.

**Why a single LLM call instead of faithful multi-agent?** Two reasons.
1. Validate the graph BEFORE scaling to 11+ agents (4 skill graphs × multi-agent + 6 specialists + 6 mergers). Graph stability first, agent multiplicity second.
2. The multi-agent collapse is *lossy* but *truthful*. A prompt that says "perform all five debate perspectives in one pass" produces a weaker output than five adversarial agents would — but it is a weaker OUTPUT, not a weaker GRAPH. The graph can carry the multi-agent version unchanged in v2.

## 12. Open decisions punted to user

- **Does `skill-plan-features` get read access to the original `requirements.md` by default, or only when the caller provides a secondary ref?** Current design: optional. If the debate stage's readiness report is missing citations, plan-features has to ask for requirements. Alternative: always pass requirements too (costs one artifact lookup per invocation).
- **Should `skill-exec-plan` block user's Discord visibility until Task #5 lands specialists?** Current: no — the workflow activates and returns a stub report. The user sees "[STUB] specialist not yet built" in any digest line that traces to exec-plan. Alternative: disable the exec-plan webhook path (deactivate) until Task #5.
- **Prompt versioning**: `metadata.prompt_version` is a freeform string. Should we enforce semver? Put a `cto_prompts` table to track changes? Defer — premature until we actually iterate a prompt.
