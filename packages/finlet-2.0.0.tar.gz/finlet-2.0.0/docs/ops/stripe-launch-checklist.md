# Stripe Launch Checklist

> Owner: ops + CEO. Single-page pre-launch verification of production Stripe configuration.
> Threat model: silent fallback to sandbox price IDs (`finlet/billing/stripe_config.py:29-30`) — missing prod price IDs in SSM is silent (sandbox default returned), missing prod secrets is loud (raises). Both paths must be probed.
> Scope: the 4 SSM parameters that gate paid checkout for launch tiers (Free, Developer $29, Team $99). Enterprise tier is post-PMF (`docs/ops/CTO_MANDATE.md` §1) and not in scope here.

---

## 1. The 4 SSM parameters

All four MUST hold prod values before launch. SSM prefix: `/finlet/prod`. Region: `us-east-1`.

| Logical name (read by code) | SSM parameter path | Sandbox fallback at `finlet/billing/stripe_config.py` |
|---|---|---|
| `STRIPE_SECRET_KEY` | `/finlet/prod/STRIPE_SECRET_KEY` | none — raises if missing (`stripe_config.py:24`) |
| `STRIPE_WEBHOOK_SECRET` | `/finlet/prod/STRIPE_WEBHOOK_SECRET` | none — raises if missing (`stripe_config.py:25`) |
| `STRIPE_PRICE_DEVELOPER` | `/finlet/prod/STRIPE_PRICE_DEVELOPER` | `price_1TEZK7Be9UXIAtbIqvsFvVH3` (sandbox, `stripe_config.py:29`) |
| `STRIPE_PRICE_TEAM` | `/finlet/prod/STRIPE_PRICE_TEAM` | `price_1TEZK8Be9UXIAtbIyQQyJtR2` (sandbox, `stripe_config.py:30`) |

Resolution order is `SSM → env var → default` (`finlet/ssm.py:90-118`). Values are LRU-cached for the process lifetime — restart `finlet.service` after any SSM mutation.

---

## 2. Verify each parameter is set in SSM

Run from a host with AWS credentials that can read `/finlet/prod/*` (deploy IAM role or the user's laptop with `aws sso login`).

```bash
aws ssm get-parameter \
  --region us-east-1 \
  --name /finlet/prod/STRIPE_SECRET_KEY \
  --with-decryption \
  --query "Parameter.Value" \
  --output text
```

```bash
aws ssm get-parameter \
  --region us-east-1 \
  --name /finlet/prod/STRIPE_WEBHOOK_SECRET \
  --with-decryption \
  --query "Parameter.Value" \
  --output text
```

```bash
aws ssm get-parameter \
  --region us-east-1 \
  --name /finlet/prod/STRIPE_PRICE_DEVELOPER \
  --with-decryption \
  --query "Parameter.Value" \
  --output text
```

```bash
aws ssm get-parameter \
  --region us-east-1 \
  --name /finlet/prod/STRIPE_PRICE_TEAM \
  --with-decryption \
  --query "Parameter.Value" \
  --output text
```

**Pass criteria** (each check is independent — all four must pass):

- `STRIPE_SECRET_KEY` starts with `sk_live_` (NOT `sk_test_`).
- `STRIPE_WEBHOOK_SECRET` starts with `whsec_` and matches the webhook endpoint registered in the Stripe Dashboard (Live mode → Developers → Webhooks).
- `STRIPE_PRICE_DEVELOPER` is NOT `price_1TEZK7Be9UXIAtbIqvsFvVH3` (the sandbox default). Confirm in the Stripe Dashboard (Live mode → Products → Developer $29/mo) that the price ID matches.
- `STRIPE_PRICE_TEAM` is NOT `price_1TEZK8Be9UXIAtbIyQQyJtR2` (the sandbox default). Confirm in the Stripe Dashboard (Live mode → Products → Team $99/mo) that the price ID matches.

If `aws ssm get-parameter` returns `ParameterNotFound` for any of the 4, treat that parameter as MISSING and use the set-templates in §3.

---

## 3. Set parameter templates

Run only for parameters that failed §2. Replace the `--value` placeholder with the real Stripe value (Live mode keys + price IDs from the Stripe Dashboard).

```bash
aws ssm put-parameter \
  --region us-east-1 \
  --name /finlet/prod/STRIPE_SECRET_KEY \
  --type SecureString \
  --value "sk_live_REPLACE_ME" \
  --overwrite
```

```bash
aws ssm put-parameter \
  --region us-east-1 \
  --name /finlet/prod/STRIPE_WEBHOOK_SECRET \
  --type SecureString \
  --value "whsec_REPLACE_ME" \
  --overwrite
```

```bash
aws ssm put-parameter \
  --region us-east-1 \
  --name /finlet/prod/STRIPE_PRICE_DEVELOPER \
  --type SecureString \
  --value "price_REPLACE_ME" \
  --overwrite
```

```bash
aws ssm put-parameter \
  --region us-east-1 \
  --name /finlet/prod/STRIPE_PRICE_TEAM \
  --type SecureString \
  --value "price_REPLACE_ME" \
  --overwrite
```

After mutation, restart the API service so the LRU cache in `finlet/ssm.py` re-fetches:

```bash
ssh ubuntu@finlet.dev sudo systemctl restart finlet.service
ssh ubuntu@finlet.dev sudo systemctl status finlet.service --no-pager | head -20
```

Then re-run the §2 reads to confirm the new values are returned by SSM.

---

## 4. Runtime verification (exercise `get_secret()` against real SSM)

A green §2 only proves SSM holds the values. This step proves the running app actually loads them. Run on the production host (or any host with the production AWS credentials and `FINLET_SSM_ENABLED=1`):

```bash
ssh ubuntu@finlet.dev "cd /opt/finlet && uv run python -c \
  \"from finlet.billing.stripe_config import STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, STRIPE_PRICE_DEVELOPER, STRIPE_PRICE_TEAM; \
   print('SECRET_KEY_PREFIX:', STRIPE_SECRET_KEY[:7]); \
   print('WEBHOOK_PREFIX:', STRIPE_WEBHOOK_SECRET[:6]); \
   print('PRICE_DEVELOPER:', STRIPE_PRICE_DEVELOPER); \
   print('PRICE_TEAM:', STRIPE_PRICE_TEAM)\""
```

**Pass criteria:**

- `SECRET_KEY_PREFIX` is `sk_live`. Anything else (`sk_test`, empty) is a fail.
- `WEBHOOK_PREFIX` is `whsec_`.
- `PRICE_DEVELOPER` is NOT `price_1TEZK7Be9UXIAtbIqvsFvVH3`. Sandbox value = silent fallback fired = SSM not loaded for this param.
- `PRICE_TEAM` is NOT `price_1TEZK8Be9UXIAtbIyQQyJtR2`. Same reasoning.

If §2 passes but §4 returns sandbox prices, the SSM client failed to initialize at app boot — check `journalctl -u finlet.service` for `ssm_no_credentials` / `ssm_param_error` / `ssm_client_unavailable` log lines.

---

## 5. Manual prod-checkout test procedure

Agents cannot swipe real cards. The user (CEO) executes this with a personal card and refunds within 10 minutes.

**Pre-flight:**

- §2 + §4 both pass.
- Stripe Dashboard is in **Live mode** (toggle top-right). Test mode results are not valid for launch sign-off.
- A clean browser session (incognito / private window). Cookies and localStorage from prior dev sessions can mask auth bugs.

**Steps:**

1. Open `https://finlet.dev` in a clean incognito window.
2. Sign up with a real email (CEO's). Verify email if required by the app.
3. Navigate to the upgrade flow → choose **Developer $29/mo**.
4. Confirm the Stripe Checkout page shows:
   - Amount: **$29.00 USD** (NOT $99 — that would be a wrong price ID).
   - Product description matches "Developer" tier.
   - URL bar shows `checkout.stripe.com` (NOT `checkout.stripe.com/c/test_...` — the `/test_` segment indicates test mode).
5. Complete checkout with a real card.
6. Within 30 seconds, the dashboard tier should reflect **Developer**. If it does not, check:
   - `journalctl -u finlet.service` for `webhook_subscription_no_user` warnings (signals webhook didn't reach the app or `STRIPE_WEBHOOK_SECRET` mismatch).
   - Stripe Dashboard → Developers → Webhooks → recent deliveries → status `200 OK`.
7. Capture the Stripe `pi_*` payment intent ID from the email receipt or the Stripe Dashboard → Payments tab.

**Refund (within 10 minutes of the charge):**

1. Stripe Dashboard → Payments → find the `pi_*` intent → **Refund payment** → full refund.
2. Confirm webhook fires (`charge.refunded` → `payment_intent.payment_failed` is NOT expected; `customer.subscription.updated` should fire with `status=canceled` after step 3).
3. In the dashboard, the user's tier should drop back to **Free** within 30 seconds (driven by `handle_subscription_deleted` in `finlet/billing/webhooks.py`).

**Do NOT:**

- Use Stripe's documented test cards (`4242 4242 4242 4242`, etc.) on the live endpoint — they will be declined and pollute the live ledger with test attempts. Test cards are only valid in Stripe Test mode; this checklist exercises Live mode.
- Include real CVVs or full PANs in any commit, screenshot, log, or Discord message.
- Skip the refund step. A live charge that isn't refunded inside the 10-minute window is harder to reconcile and (depending on the card network) may settle and accrue interchange fees.

---

## 6. Sign-off

The launch is gated on every box below being checked by the CEO with the date and the Stripe payment intent ID where applicable.

- [ ] §2: All 4 SSM `get-parameter` reads return non-sandbox values.
  - Date: ___________  Initials: ___
- [ ] §4: Runtime `python -c "from finlet.billing.stripe_config import ..."` printed `sk_live`, `whsec_`, and non-sandbox price IDs on the production host.
  - Date: ___________  Initials: ___
- [ ] §5: Manual checkout completed end-to-end. Tier flipped to Developer in dashboard within 30 s.
  - Date: ___________  Initials: ___  Stripe `pi_*`: ___________________________
- [ ] §5: Refund completed inside 10-minute window. Tier flipped back to Free in dashboard within 30 s.
  - Date: ___________  Initials: ___  Refund `re_*`: ___________________________
- [ ] Stripe Dashboard webhook delivery for the test transaction shows `200 OK` (Developers → Webhooks → recent deliveries).
  - Date: ___________  Initials: ___

Once all 5 boxes are signed: production Stripe is verified ready for launch.

---

## Appendix: failure-mode quick-reference

| Symptom | Likely cause | Where to look |
|---|---|---|
| §2 returns `ParameterNotFound` for a price | SSM never set | Run §3 set-template, then §2 again. |
| §2 returns prod values but §4 returns sandbox | SSM client failed to init at app boot | `journalctl -u finlet.service \| grep -E 'ssm_(no_credentials\|param_error\|client_unavailable)'` |
| §5 step 4 shows `$99` for the Developer flow | `STRIPE_PRICE_DEVELOPER` and `STRIPE_PRICE_TEAM` swapped in SSM | Re-run §2 + cross-check against the Stripe Dashboard product page for each tier. |
| §5 step 6 dashboard tier never flips | Webhook signature mismatch (`STRIPE_WEBHOOK_SECRET` is wrong) OR webhook endpoint URL mismatch | Stripe Dashboard → Developers → Webhooks → recent deliveries → click the failed event → response body. |
| §5 step 4 URL contains `/c/test_` | Stripe Dashboard is in Test mode, OR `STRIPE_SECRET_KEY` is `sk_test_*` | Toggle Stripe Dashboard to Live mode + re-run §2 + §4. |
