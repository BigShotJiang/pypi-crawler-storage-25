You are Team A (v2.0.0 Pure-MCP Migration).

**Plan:** `/Users/justnau/finlet/docs/brainstorms/V2_PURE_MCP_EXECUTION_PLAN.md` — read your full spec (lines 208-338).

**Mission:** CLI surgery — delete dropped commands + dead helpers + rewrite module docstring.

**Blocked by:** none — start immediately.

## Read these files first
- `finlet/cli.py:1-30` (module docstring — REWRITE; describes deleted v1.0.1 dispatch model)
- `finlet/cli.py:30-70` (imports — `asyncio` line 30 + `_AsyncioTimeoutError` line 64 both dead; `EXIT_AUTH_REQUIRED` line 45 is ALIVE — keep)
- `finlet/cli.py:217-260` (`_resolve_bearer_token` — dead after deletion)
- `finlet/cli.py:386-466` (`_dispatch_mcp_tool` + envelope plumbing — all dead)
- `finlet/cli.py:491-530` (Typer app init + sub-typer registrations)
- `finlet/cli.py:535-568` (`finlet serve` — KEEP)
- `finlet/cli.py:881-1096` (plugins commands — KEEP; use `EXIT_AUTH_REQUIRED` at 984, 1056)
- `finlet/cli.py:1340-1360` (inline comment at 1347 — references `_resolve_bearer_token`; clean it)
- `finlet/cli.py:1561-1610` (`auth status` — KEEP; uses `EXIT_AUTH_REQUIRED`)
- `finlet/cli.py:1565-1580` (audit for dispatch refs around 1573)
- `finlet/cli.py:1927-2035` (`finlet mcp serve` — KEEP)
- `finlet/cli_mcp_client.py` (DELETE entire file)

## Files touched
**Modified:** `finlet/cli.py`:
- **Rewrite module docstring (lines 1-30)** to describe v2.0.0 surface: serve, register, auth login/logout/status, plugins list/add/remove, mcp serve, manual. NO mention of session/order/portfolio/etc.
- Delete commands at lines 584-706 (session sub-app), 711-864 (benchmark sub-app), 1614-1691 (advance), 1696-1782 (order), 1787-1878 (portfolio), 1883-1921 (status).
- Delete dead helpers: `_dispatch_mcp_tool` (386-433), `_translate_mcp_error` (363-384), `_emit_envelope` (~436), `_AUTH_REQUIRED_MARKERS`, `_AUTH_REQUIRED_HINT`, `_resolve_bearer_token` (217), `_AsyncioTimeoutError` alias (64), top-level `import asyncio` (30), `_normalize_start_iso` (~573 — verify dead).
- **DO NOT delete `EXIT_AUTH_REQUIRED` (line 45)** — alive, used by `plugins_add` (984), `plugins_remove` (1056), `auth_status` (1598+).
- Delete sub-typer `session_app` (516) + `benchmark_app` (520-525) + their `app.add_typer(...)` lines.
- Delete `from finlet.cli_mcp_client import ...` import (line 39).
- Clean stale inline comment at `cli.py:1347` (references `_resolve_bearer_token` auto-refresh — function won't exist). Either remove OR rewrite to point at `_write_credentials` directly. **NOTE: it's an INLINE COMMENT, not a docstring.**
- Audit `cli.py:1573` and surrounding for similar stale refs.

**Deleted:** `finlet/cli_mcp_client.py` (entire file — use `git rm`).

## Deliverable
After this team finishes, `finlet --help` shows ONLY: `serve`, `mcp` (sub-cmd `serve`), `auth` (login/logout/status), `register`, `plugins` (list/add/remove), `manual`, `--version`. NO session/benchmark/advance/order/portfolio/status commands. DEAD set gone; ALIVE set (`EXIT_AUTH_REQUIRED`) remains.

## Validation
```bash
python -c "import finlet.cli; from finlet.cli import app"   # must succeed
python -m finlet.cli --help 2>&1 | grep -E '^\s+(session|benchmark|advance|order|portfolio|status)\b'   # nothing
python -m finlet.cli --help 2>&1 | grep -E '^\s+(serve|mcp|auth|register|plugins|manual)\b'   # all 6
python -m finlet.cli mcp serve --help   # exit 0
grep -rn "from finlet.cli_mcp_client" finlet/   # nothing
grep -nE "_dispatch_mcp_tool|_resolve_bearer_token|_AsyncioTimeoutError|_AUTH_REQUIRED_MARKERS|_AUTH_REQUIRED_HINT|_emit_envelope|_translate_mcp_error" finlet/cli.py   # nothing
grep -nE "^import asyncio|^from asyncio" finlet/cli.py   # nothing
grep -nE "EXIT_AUTH_REQUIRED" finlet/cli.py   # definition + ≥3 consumers
grep -nE "v1\.0\.1|MCP-over-HTTP|MCP-dispatched|dispatch contract" finlet/cli.py   # nothing (module docstring rewritten)
ruff check finlet/cli.py   # passes
git status   # cli.py modified + cli_mcp_client.py deleted
```

## Agent instructions
- You MUST `git add finlet/cli.py` and `git rm finlet/cli_mcp_client.py` and `git commit` before finishing.
- After deletion, run `ruff check finlet/` and remove any newly-unused imports.
- After deletion, grep for orphan refs to deleted symbols. Clean stale docstrings/comments — including module docstring (1-30) and inline comment at 1347.
- **Do NOT delete `EXIT_AUTH_REQUIRED`.** Verify with `grep -c "EXIT_AUTH_REQUIRED" finlet/cli.py` ≥4.
- Do NOT modify ANY MCP tool source files (`finlet/mcp/`).
- Do NOT touch `tests/` (Team B's lane).
- Do NOT touch docs or `dashboard/llms.txt` (Team C's lane).
- Do NOT touch `dashboard/*.html` (Team D's lane).
- Commit message: `[Team A v2.0.0]: delete CLI convenience commands + dead helpers; rewrite module docstring`.

## CRITICAL RULES
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns in those files.
- You MUST `git add`/`git rm` and `git commit` all your changes before finishing.
- Your commit message must start with `[Team A v2.0.0]:`.
- Run the validation commands above before finishing.
- If validation fails, fix and re-commit.

When done, report: DONE + commit hash + validation results.
OR: BLOCKED + what went wrong.
