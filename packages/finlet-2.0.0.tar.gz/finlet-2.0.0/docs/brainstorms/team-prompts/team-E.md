You are Team E (v2.0.0 Pure-MCP Migration) — CAPSTONE.

**Plan:** `/Users/justnau/finlet/docs/brainstorms/V2_PURE_MCP_EXECUTION_PLAN.md` — read your full spec (lines 628-729).

**Mission:** Version bump + CHANGELOG repair.

**Blocked by:** Teams A, B, C, D — all merged. You are the capstone.

## Read these files first
- `pyproject.toml:1-20` — `[project]` table; current `version = "1.1.0"` at line 3.
- `CHANGELOG.md` FULL FILE — current section ordering: `[1.0.4]` line 8, `[1.0.3]` line 43, `[Unreleased]` line 53 (contents are 2026-05-22 session-level-blind work, NOT 1.1.0 USER_MANUAL_OVERHAUL), `[1.0.2]` line 164, `[1.0.1]` line 174, `[1.0.0]` line 193, `[0.1.1]` line 319.
- `CHANGELOG.md:53-163` — read the FULL `[Unreleased]` body. Step 10b BLOCKER-4 says this is 2026-05-22 session-level-blind content, NOT 2026-05-16 USER_MANUAL_OVERHAUL.
- `.github/workflows/pypi-publish.yml` — Trusted Publishing via OIDC; triggers on `release: published`, `push.tags: ['v*']`, `workflow_dispatch`.
- `docs/REMAINING_TASKS.md` — search for "USER_MANUAL_OVERHAUL" or "1.1.0" or "2026-05-16" to find v1.1.0 contents to author the missing entry.
- Memory `[[project-user-manual-overhaul-shipped]]` — v1.1.0 SHIPPED 2026-05-16 via PR #87 (`9a88842`).
- Memory `[[project-session-level-blind-shipped]]` — session-level blind SHIPPED 2026-05-22 prod sha `27d96ca` PR #134.

## CHANGELOG repair strategy (Step 10b BLOCKER-4)

Final desired ordering (top to bottom):

| Position | Section | Date | Content source |
|---|---|---|---|
| 1 | `[2.0.0]` | 2026-05-22 | (a) Pure-MCP removals from this exec-plan. (b) Session-level-blind work currently misplaced in `[Unreleased]` — fold in. |
| 2 | `[1.1.0]` | 2026-05-16 | NEW entry. USER_MANUAL_OVERHAUL — author from REMAINING_TASKS + memory (PR #87 `9a88842`). |
| 3 | `[1.0.4]` | 2026-05-12 | Existing — keep. |
| 4 | `[1.0.3]` | 2026-05-11 | Existing — keep. |
| 5 | `[1.0.2]` | 2026-05-11 | Existing — keep. |
| 6 | `[1.0.1]` | 2026-05-11 | Existing — keep. |
| 7 | `[1.0.0]` | 2026-05-10 | Existing — keep. |
| 8 | `[0.1.1]` | <prior> | Existing — keep. |

### Steps:
1. **Read** the full body of `[Unreleased]` (lines 53-163). Save the content — it goes into `[2.0.0]`.
2. **Delete** the misplaced `[Unreleased]` header at line 53 along with its contents.
3. **Author `[1.1.0] - 2026-05-16`** by reading `docs/REMAINING_TASKS.md` for USER_MANUAL_OVERHAUL closure references (memory: PR #87 `9a88842`). Sections: `### Added` (manual overhaul, `finlet manual` CLI command), `### Changed` (operator surfacing), `### PR references`.
4. **Author `[2.0.0] - 2026-05-22`** with these groupings:
   - `### Added` — session-level blind work from the saved `[Unreleased]` content.
   - `### Removed` — 12 CLI commands + helpers from this exec-plan (session/list/delete/publish, benchmark/start/progress/decrypt/visibility, advance, order, portfolio, status; finlet/cli_mcp_client.py; _dispatch_mcp_tool + envelope helpers).
   - `### Changed` — CLI surface reduced to MCP-bootstrap minimum (6 command families: serve, register, auth, plugins, mcp serve, manual).
   - `### Migration notes` — agents use MCP; wire `finlet mcp serve` into Claude Desktop / Codex CLI / Generic MCP Client. Zero PyPI consumers per pre-launch context; no deprecation period.
   - `### PR references` — this PR + the session-level-blind PR (#134 if final).
5. **Prepend** `[2.0.0]` at top, then `[1.1.0]` immediately below, then existing `[1.0.4]` through `[0.1.1]` unchanged.

## Files touched
- **Modified `pyproject.toml`** — bump `version = "1.1.0"` → `version = "2.0.0"` at line 3.
- **Modified `CHANGELOG.md`** — execute the repair strategy above.

## Deliverable
Repo at v2.0.0, CHANGELOG ordering clean, ready for tag push.

## Validation
```bash
grep "^version = " pyproject.toml   # version = "2.0.0"
grep -nE "^## \[" CHANGELOG.md   # [2.0.0] → [1.1.0] → [1.0.4] → ... → [0.1.1]
# No [Unreleased] section anywhere
! grep -q "^## \[Unreleased\]" CHANGELOG.md && echo "✓ no Unreleased"
# [2.0.0] has both session-level blind AND CLI removals
grep -A2 "^## \[2.0.0\]" CHANGELOG.md   # shows ### Added (blind) AND ### Removed (12 cmds)
# [1.1.0] has USER_MANUAL_OVERHAUL
grep -A2 "^## \[1.1.0\]" CHANGELOG.md   # shows ### Added mentioning USER_MANUAL_OVERHAUL or `finlet manual` + PR #87
# Build smoke
hatch build   # produces wheel + sdist
unzip -l dist/finlet-2.0.0-*.whl | grep -E "finlet/(cli|mcp|api|core|plugins)"   # key modules present
unzip -l dist/finlet-2.0.0-*.whl | grep "finlet/cli_mcp_client.py"   # NOT present
uv run python -m pip install --force-reinstall dist/finlet-2.0.0-*.whl --target /tmp/test-install   # smoke install
uv run pytest tests/ -x --ignore=tests/e2e --ignore=tests/playwright   # passes (Team B trimmed)
uv run ruff check .   # passes
uv run python -m finlet.manual.generate_llms_txt --check   # exit 0
git status   # ONLY pyproject.toml and CHANGELOG.md modified
```

## Agent instructions
- You MUST `git add pyproject.toml CHANGELOG.md` and `git commit` before finishing.
- Do NOT push the v2.0.0 tag yourself. Tag push is user-driven (final manual step after this PR merges).
- BEFORE editing CHANGELOG.md, READ the full file end-to-end + read `docs/REMAINING_TASKS.md` for USER_MANUAL_OVERHAUL evidence.
- The `[Unreleased]` section is NOT v1.1.0 content. It's 2026-05-22 session-level-blind work. Fold it into `[2.0.0]` alongside the pure-MCP removals (same-day ship).
- Author `[1.1.0]` from independent evidence (REMAINING_TASKS + memory) since there's no existing CHANGELOG entry for it.
- Match CHANGELOG voice/density to existing `## [1.0.0]` entry — terse, technical, with PR # links.
- Verify `hatch build` smoke locally before commit.
- Do NOT modify any other file. NOT finlet/, NOT tests/, NOT docs/, NOT dashboard/, NOT manual/.
- Commit message: `[Team E v2.0.0]: bump 2.0.0 + CHANGELOG repair (add [1.1.0] from manual-overhaul evidence; fold [Unreleased] into [2.0.0])`.

## CRITICAL RULES
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message must start with `[Team E v2.0.0]:`.
- Run the validation commands above before finishing.

When done, report: DONE + commit hash + validation results.
OR: BLOCKED + what went wrong.
