You are Team C (v2.0.0 Pure-MCP Migration).

**Plan:** `/Users/justnau/finlet/docs/brainstorms/V2_PURE_MCP_EXECUTION_PLAN.md` — read your full spec (lines 455-568).

**Mission:** Server-side docs + manual registry + generator + README + llms.txt regen.

**Blocked by:** none — independent, parallel with A/B/D.

**Coordination requirement:** Team C and Team D both rewrite onboarding narratives. BOTH MUST use the "Canonical v2 onboarding script" section of the plan (lines 29-89) as source of truth. JSON snippets, Codex CLI command, and example agent prompt are VERBATIM — no paraphrasing.

## Read these files first
- "Canonical v2 onboarding script" section of the plan (lines 29-89) — SOURCE OF TRUTH
- `finlet/manual/quickstart.md` — references `finlet session create` (line 41), `finlet session advance` (line 55), `finlet trade order` (line 56), `finlet portfolio` (line 57)
- `finlet/manual/client-matrix.md` — references `finlet session create` (line 68)
- `finlet/manual/session-lifecycle.md` — audit for CLI refs
- `finlet/manual/generate_llms_txt.py` (FULL FILE ~210 lines): imports `TOPIC_REGISTRY` from `registry.py:25` and emits hardcoded sections ("Agent Instructions", stdio config). **The hardcoded text inside this file IS Team C's surface.** Look at hardcoded MCP-over-HTTP recommendations + `FINLET_API_KEY` references.
- `finlet/manual/registry.py` (FULL FILE): `TOPIC_REGISTRY` is a dict of topic metadata (title, summary, url). `summary` field shows up in `dashboard/llms.txt`. Update topic summaries to MCP-first language.
- `dashboard/llms.txt` (current state): hardcoded sections like "Start with the hosted MCP-over-HTTP path", `fnlt_<key>`, `FINLET_API_KEY`. ALL come from `generate_llms_txt.py` hardcoded text, NOT manual `.md` files.
- `docs/ARCHITECTURE.md:1104-1116, 1870-1871, 1017, 1803, 137`
- `docs/PRIVACY_POLICY.md:332, 334, 336`
- `docs/launch/templates.md:53`
- `docs/decisions/cli-mcp-http-dispatch.md` — current dispatch contract (mark Superseded)
- `docs/decisions/cli-mcp-stdio-auth.md` — already Superseded at top (audit only)
- `docs/decisions/` (read 2-3 existing decision records for house style)
- `README.md:78-110, 348-360` — quickstart + CLI reference sections with live dropped-command examples
- `.github/workflows/ci.yml:65-69` — llms.txt drift gate

## Files touched
- **Modified `finlet/manual/quickstart.md`** — depict Canonical v2 onboarding script. Drop CLI examples. Show EXACT MCP client config snippets + example agent prompt.
- **Modified `finlet/manual/client-matrix.md`** — replace line 68 with Canonical script's config snippets.
- **Modified `finlet/manual/session-lifecycle.md`** — rewrite any CLI refs.
- **Modified `finlet/manual/registry.py`** (Step 10b BLOCKER-2): update topic `summary` fields to MCP-first language. E.g.: `quickstart` summary currently "Five-step copy-paste setup: install, register, login, create session, trade." → rewrite as "Five-step MCP-first setup: install, register, login, wire MCP client into agent host, dialog with agent." Similarly for `session-lifecycle`, `client-matrix`, `transports`.
- **Modified `finlet/manual/generate_llms_txt.py`** (Step 10b BLOCKER-2): rewrite hardcoded "Agent Instructions" block at end. Lead with `finlet mcp serve` stdio path as PRIMARY way to integrate. Remove/de-emphasize `https://finlet.dev/mcp` hosted-HTTP recommendation. Remove `FINLET_API_KEY` from recommended quickstart (stays as fallback for CI/headless per `mcp serve` docstring but NOT the lede).
- **Modified `docs/ARCHITECTURE.md`** — collapse CLI surface section (1104-1116) to only kept commands. Update visibility refs (137), batch-advance (1017), blind activation (1803), benchmark surface table (1870-1871). Lead with MCP tool + REST endpoint; remove CLI mentions.
- **Modified `docs/PRIVACY_POLICY.md`** — rewrite lines 332/334/336 to lead with `set_session_visibility` MCP tool + REST endpoint. Document consumer-side share URL derivation: `https://finlet.dev/sessions/{id}`.
- **Modified `docs/launch/templates.md:53`** — rewrite to depict Canonical v2 onboarding script.
- **Modified `README.md`** — rewrite quickstart (lines 78-110) and CLI reference (lines 348-360) to match Canonical script. PyPI readme — quality bar is high.
- **New `docs/decisions/v2-pure-mcp-migration.md`** — match house style. Include: motivation, scope (kept vs dropped), migration notes (zero PyPI consumers per `[[project-pre-launch-no-customers]]`), consumer-side share-URL derivation.
- **Modified `docs/decisions/cli-mcp-http-dispatch.md`** — add `Status: Superseded by docs/decisions/v2-pure-mcp-migration.md (2026-05-22)` at top.
- **Regenerated `dashboard/llms.txt`** — after editing registry.py + generate_llms_txt.py, RUN `python -m finlet.manual.generate_llms_txt --write` to regen. Verify with `--check` (exit 0). Commit regen alongside source edits.

## Deliverable
- `grep -rnE 'finlet (session|benchmark|order|portfolio|status|advance|trade)( |$)' docs/ARCHITECTURE.md docs/PRIVACY_POLICY.md docs/launch/templates.md finlet/manual/ README.md` returns no hits.
- `python -m finlet.manual.generate_llms_txt --check` exits 0.
- `dashboard/llms.txt` "Agent Instructions" reflects MCP-first onboarding (stdio primary, no `FINLET_API_KEY` lede).
- All operational documentation references Canonical v2 onboarding script.
- `docs/decisions/v2-pure-mcp-migration.md` exists.

## Validation
```bash
grep -rnE 'finlet (session|benchmark|order|portfolio|status|advance|trade)( |$)' docs/ARCHITECTURE.md docs/PRIVACY_POLICY.md docs/launch/templates.md finlet/manual/ README.md   # no hits (forensic snapshots out of scope)
python -m finlet.manual.generate_llms_txt --check   # exit 0
grep -E "FINLET_API_KEY|hosted MCP-over-HTTP" dashboard/llms.txt   # minimal (no longer lede)
grep -E '"command": "finlet", "args": \["mcp", "serve"\]' dashboard/llms.txt   # finds stdio config
ls docs/decisions/v2-pure-mcp-migration.md   # exists
head -3 docs/decisions/cli-mcp-http-dispatch.md   # has Status: Superseded
git status   # dashboard/llms.txt modified (regen)
```

**Cross-surface narrative check:** the JSON snippet in `finlet/manual/quickstart.md` matches the snippet in `dashboard/setup.html` (Team D's output) verbatim — same indentation, same key order.

## Agent instructions
- You MUST `git add` and `git commit` before finishing.
- Both your rewrites and Team D's MUST depict the Canonical v2 onboarding script VERBATIM — no paraphrasing.
- For `docs/PRIVACY_POLICY.md`: user-facing legal text — preserve behavioral claims.
- For `docs/decisions/v2-pure-mcp-migration.md`: read 2-3 existing decision records first.
- For `finlet/manual/quickstart.md`: bundled in the wheel; rewrite as "agent-first" per Canonical script.
- For `README.md`: PyPI readme; quality bar is high.
- **For `finlet/manual/generate_llms_txt.py`**: Python code, not Markdown. Edit hardcoded strings carefully. Run `python -m finlet.manual.generate_llms_txt --write` after edits to verify output.
- **For `finlet/manual/registry.py`**: update topic `summary` strings to MCP-first language. Don't reorder topics.
- After editing registry.py + generate_llms_txt.py, RUN `python -m finlet.manual.generate_llms_txt --write` to regen `dashboard/llms.txt`. Commit regen alongside source edits. CI's `--check` gate will fail otherwise.
- Do NOT modify `finlet/cli.py` or any source outside `finlet/manual/` (Team A's lane).
- Do NOT modify `tests/` (Team B's lane).
- Do NOT modify `dashboard/*.html` (Team D's lane). ONLY `dashboard/llms.txt` (your regen output).
- Do NOT modify `pyproject.toml` or `CHANGELOG.md` (Team E's lane).
- Commit message: `[Team C v2.0.0]: rewrite manual + registry + generator + docs + README for MCP-first; regen dashboard/llms.txt`.

## CRITICAL RULES
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the "Read these files first" list BEFORE writing any content.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message must start with `[Team C v2.0.0]:`.
- Run the validation commands above before finishing.

When done, report: DONE + commit hash + validation results.
OR: BLOCKED + what went wrong.
