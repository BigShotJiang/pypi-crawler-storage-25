You are **Team F: Docs + decision record + CHANGELOG + requirements doc** for /exec-plan execution of `docs/brainstorms/SESSION_LEVEL_BLIND_EXECUTION_PLAN.md`.

**Blocked by:** none. Parallel to all teams.

## Read these files FIRST

- `docs/brainstorms/SESSION_LEVEL_BLIND_REQUIREMENTS.md` — audience matrix to update
- `docs/brainstorms/SESSION_LEVEL_BLIND_EXECUTION_PLAN.md` — full plan, especially "Audience contract" + "Constraints" sections
- `docs/ARCHITECTURE.md` around line 1620 (blind-benchmark section) — to extend with session-level entry point
- `CHANGELOG.md` — to add an `## [Unreleased]` entry

**ALSO read** `docs/KNOWN_FAILURES.md`.

## Files touched

- **Modified: `docs/brainstorms/SESSION_LEVEL_BLIND_REQUIREMENTS.md`**
  - Update the audience matrix to match the v12 plan's "Audience contract" section (preserves HEAD's mixed audience behavior — REST routes_session = REAL for owner, MCP + portfolio /trace + SSE + market routes = BLINDED for owner).
  - Drop any "reveal lifecycle" claims (deferred).
  - Add a "Deferred ideas" entry covering reveal lifecycle + benchmark-current ValueError ID leak (Step 10k STRONG 1) + benchmark-only routes_benchmark.py (out of scope).

- **Modified: `docs/ARCHITECTURE.md`**
  - Extend the blind-benchmark section (around line 1620) to document the session-level entry point (`create_session(blind=True)`), auto-name policy (`blind-{session.id[:8]}`), catalog enforcement (270-ticker us_equities + us_etfs + benchmark tickers), and the MCP/REST audience contract.

- **New: `docs/decisions/session-level-blind-extends-create-session.md`**
  - Document the decisions: blind kwarg on create_session (MCP canonical), auto-name permanent, catalog enforcement, no reveal lifecycle, MCP success-wrap pattern, `_blind_mapping_for` lives in session_service.py.

- **Modified: `CHANGELOG.md`**
  - Add `## [Unreleased]` entry summarizing session-level blind mode (creator-facing capability, no breaking changes, auto-name policy).

## CRITICAL RULES

- ONE commit, exact message: `[Team F]: docs + decision record + CHANGELOG + requirements audience-matrix correction for session-level blind (v9 plan)`
- NO code or tests.
- DO NOT touch source files.
- DO NOT spawn subagents.
- ALWAYS use `git -C $(pwd) <op>`.
- Keep the decision record concise — 200-400 lines max, focused on the *why* not the *what*.

## When done

```
TEAM F: DONE
commit=<sha>
files:
  requirements_doc_updated: yes/no
  architecture_extended: yes/no
  decision_record_created: yes/no
  changelog_entry_added: yes/no
notes=<one line>
```

OR:
```
TEAM F: BLOCKED
reason=<short>
details=<longer>
```
