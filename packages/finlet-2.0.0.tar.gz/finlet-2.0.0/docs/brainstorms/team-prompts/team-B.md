You are Team B (v2.0.0 Pure-MCP Migration).

**Plan:** `/Users/justnau/finlet/docs/brainstorms/V2_PURE_MCP_EXECUTION_PLAN.md` — read your full spec (lines 341-451).

**Mission:** Test cleanup — trim CLI tests + 4 new MCP-side assertions on `set_session_visibility`.

**Blocked by:** Team A merged (now on main). Pre-flight + Team A's CLI surgery have landed. Team A deleted `_dispatch_mcp_tool`, `finlet/cli_mcp_client.py`, and the 12 dropped commands.

## Read these files first
- `tests/test_cli.py:1-50` — imports include `from finlet.cli_mcp_client import MCPDispatchError` at line 29 (NOW INVALID — Team A deleted that module)
- `tests/test_cli.py` (full file, 2131 lines) — enumerate test classes
- `tests/test_cli.py:441-505` — `session_publish` flag-mapping tests (3 tests for dropped command)
- `tests/test_cli_benchmark.py` (204 lines) — 3 test classes (`TestBenchmarkCLIHelp`, `TestBenchmarkStartDispatch`, `TestBenchmarkProgressDispatch`) all test dropped commands → DELETE entirely
- `tests/test_cli_help.py` (102 lines) — help-text snapshot; UPDATE to reflect new command surface
- `tests/test_cli_oauth_login.py` (507 lines) — OAuth flow tests; KEEP unmodified
- `tests/api/test_cli_mcp_client.py` — tests `cli_mcp_client.py` which Team A DELETED → DELETE entirely
- `tests/mcp/test_create_session_blind.py:147` — blind create output (KEEP)
- `tests/mcp/test_start_benchmark_blind.py:188` — benchmark blind (KEEP)
- `tests/mcp/test_submit_order_validation.py:124` — submit_order input validation (KEEP)
- `tests/mcp/test_concurrency.py:156` — advance_time concurrency (KEEP)
- `tests/mcp/test_decrypt_visibility_tools.py:226` — benchmark visibility (WILL be augmented by Team B for session visibility)
- `tests/mcp/test_session_lifecycle_blind.py:288` — session lifecycle blind output (KEEP)
- `finlet/mcp/tools_session.py:43-105` — `set_session_visibility` MCP tool (READ to confirm: `public: bool`, `anonymous: bool = True` are INPUT params)
- `finlet/api/schemas/session.py:79-101` — `SessionResponse` schema; OUTPUT field is `public_anonymous: bool` (line 101), NOT `anonymous` (Step 10b BLOCKER-3)
- `finlet/api/services/session_service.py:133-198` — `set_visibility` service-layer implementation

## Files touched
- **Modified `tests/test_cli.py`** — TRIM to only kept-command tests. KEEP: auth login/logout/status, register, plugins list/add/remove, manual, mcp serve smoke, root callback + version callback tests, generic CLI behaviors. DELETE: session_create/list/delete/publish tests, advance/order/portfolio/status tests, the `from finlet.cli_mcp_client import MCPDispatchError` import (line 29), any test referencing dropped symbols.
- **Deleted `tests/test_cli_benchmark.py`** (use `git rm`).
- **Modified `tests/test_cli_help.py`** — update help-text snapshot to reflect new command surface (6 commands: serve, register, auth, plugins, mcp, manual).
- **Deleted `tests/api/test_cli_mcp_client.py`** (use `git rm`).
- **Modified `tests/mcp/test_decrypt_visibility_tools.py`** — ADD 4 explicit assertions for `set_session_visibility` (Step 10b BLOCKER-3 — correct schema keys `public_anonymous` NOT `anonymous`):
  1. `set_session_visibility(public=True, anonymous=True)` → `result["public"] == True` AND `result["public_anonymous"] == True`.
  2. `set_session_visibility(public=True, anonymous=False)` → `result["public"] == True` AND `result["public_anonymous"] == False` (attributed flow).
  3. `set_session_visibility(public=False, anonymous=True)` → `result["public"] == False` AND `result["public_anonymous"] == True` (unpublish flow; CLI always passed anonymous=True per cli.py:692).
  4. Anti-shape-drift: assert `"share_url" not in result` (consumer derives URL as `https://finlet.dev/sessions/{id}`; tool shape must NOT silently add this field).
- **Modified (audit only)** — `tests/mcp/test_create_session_blind.py`, `tests/mcp/test_start_benchmark_blind.py`, `tests/mcp/test_submit_order_validation.py`, `tests/mcp/test_concurrency.py`, `tests/mcp/test_session_lifecycle_blind.py` — confirm coverage; no edits unless gaps surface.

## Test fixture hygiene (Step 10b STRONG-3)
Any new test fixture for OAuth tokens / api_keys / session IDs MUST use obviously fake values matching the existing pattern in `tests/mcp/`:
- JWTs: `header.payload.signature` (3 dots, not realistic `eyJ...` base64)
- API keys: `fnlt_test_key_<short>` (NEVER realistic `fnlt_<32hex>`)
- Session IDs: `test-session-001` or `aaaaaaaaaaaaaa` (NEVER realistic UUID-shaped 12-char hex)

Protects gitleaks scanning. See `[[feedback-doc-examples-must-be-low-entropy]]`.

## Deliverable
After this team finishes, `pytest tests/ -x` passes. No coverage regressions. CLI test files contain ONLY tests for kept commands. Explicit MCP-side coverage exists for `set_session_visibility` with correct schema keys.

## Validation
```bash
uv run pytest tests/test_cli.py -x    # passes (no ImportError)
uv run pytest tests/test_cli_help.py -x   # passes (snapshot updated)
uv run pytest tests/test_cli_oauth_login.py -x   # passes (unmodified)
uv run pytest tests/mcp/test_decrypt_visibility_tools.py -x   # passes with 4 new assertions
grep -c "result\[.public_anonymous.\]" tests/mcp/test_decrypt_visibility_tools.py   # ≥3
grep -c '"share_url" not in result' tests/mcp/test_decrypt_visibility_tools.py   # ≥1
uv run pytest tests/mcp/ -x   # passes
uv run pytest tests/ -x --ignore=tests/e2e --ignore=tests/playwright   # passes end-to-end (may take ~10min)
grep -rE 'eyJ[A-Za-z0-9_-]{20,}|fnlt_[a-f0-9]{32}' tests/mcp/test_decrypt_visibility_tools.py   # nothing (no realistic-looking secrets)
git status   # 2 deletions + 3-4 modifications
```

## Agent instructions
- You MUST `git add` (+ `git rm` for deletions) and `git commit` before finishing.
- New MCP-side assertions MUST use `result["public_anonymous"]` (the actual response schema field), NOT `result["anonymous"]` (the INPUT param name). Verify by reading `finlet/api/schemas/session.py:79-101` before writing assertions.
- New test fixtures MUST use obviously-fake values (see "Test fixture hygiene" above). DO NOT use realistic `eyJ...` JWTs or `fnlt_<32hex>` api_keys.
- Do NOT modify `finlet/` source (Team A's lane, already merged).
- Do NOT modify `finlet/mcp/` tools (strict no-shape-change rule).
- Do NOT modify docs, dashboard, or `finlet/manual/` (Team C/D lanes).
- Do NOT modify `pyproject.toml` or `CHANGELOG.md` (Team E's lane).
- Commit message: `[Team B v2.0.0]: trim CLI tests; add 4 MCP assertions on set_session_visibility (public + public_anonymous + no-share-url)`.

## CRITICAL RULES
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the "Read these files first" list BEFORE writing any code.
- You MUST `git add`/`git rm` and `git commit` all your changes before finishing.
- Your commit message must start with `[Team B v2.0.0]:`.
- Run the validation commands above before finishing.

When done, report: DONE + commit hash + validation results.
OR: BLOCKED + what went wrong.
