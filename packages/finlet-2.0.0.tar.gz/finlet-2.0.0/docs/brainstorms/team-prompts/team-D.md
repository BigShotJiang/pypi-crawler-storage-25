You are Team D (v2.0.0 Pure-MCP Migration).

**Plan:** `/Users/justnau/finlet/docs/brainstorms/V2_PURE_MCP_EXECUTION_PLAN.md` — read your full spec (lines 572-624).

**Mission:** Dashboard frontend rewrite (HTML content + data-copy attributes ONLY). No JS/CSS/structural changes.

**Blocked by:** none — independent, parallel with A/B/C.

**Coordination requirement:** Team D and Team C both rewrite onboarding narratives. BOTH MUST use the "Canonical v2 onboarding script" section of the plan (lines 29-89) as source of truth. JSON snippets, Codex CLI command, and example agent prompt are VERBATIM — no paraphrasing.

## Read these files first
- "Canonical v2 onboarding script" section of the plan (lines 29-89) — SOURCE OF TRUTH
- `dashboard/index.html:91, 105` — landing page "first run" hint
- `dashboard/setup.html:228, 233, 284` — onboarding setup with copy-button + REST-CLI example
- `dashboard/setup.html:37` — explicit reference to the manual as source of truth (narrative-coupling point — Team C is writing that manual)
- `dashboard/agent-guide.html:876, 881, 903, 908` — agent-guide blocks with copy-buttons
- `README.md:111` — establishes dashboard as read-only monitoring (confirms copy/text-only constraint)
- `dashboard/setup.html` full file — search for `<button class="btn-copy"` elements to understand how `data-copy` attributes are read by inline JS (do NOT modify the JS; just understand it so HTML escaping is correct)

## HTML attribute escaping (Step 10b STRONG-2)
`data-copy` attributes are used by inline JS to populate clipboard. The Canonical agent-prompt example contains single quotes around `'my-first-sim'`. Existing `data-copy` attributes use SINGLE quotes (`data-copy='...'`) so embedded single quotes WILL break attribute parsing. v3 requires either:
- Switching new `data-copy` attributes to DOUBLE quotes (`data-copy="..."`) so single-quoted prompt content embeds cleanly, OR
- HTML-escaping single quotes inside the data-copy value as `&#39;`.

**Recommended:** double-quote attributes + use double-quoted JSON inside (Claude Desktop JSON uses double quotes — single quotes only appear in agent prompt example, which is rendered as plain text not JSON).

## Files touched
- **Modified `dashboard/index.html`** — replace lines 91, 105 with MCP-shaped examples from the Canonical v2 onboarding script. Keep layout/CSS/JS unchanged. Only swap inner content of `<code>` and `<p class="first-run-hint">` blocks.
- **Modified `dashboard/setup.html`** — replace lines 228 (`data-copy` attribute), 233 (`<pre><code>` block), 284 (CLI example paragraph) with content from Canonical script. Preserve `<button class="btn-copy">` structure; only swap `data-copy` attribute values + `aria-label`s + visible code-block text.
- **Modified `dashboard/agent-guide.html`** — replace lines 876 (data-copy), 881 (code block), 903 (data-copy), 908 (code block) with Canonical-script content. Same constraints.

## Deliverable
Dashboard pages contain ZERO references to `finlet session create`, `finlet order`, `finlet portfolio`, etc. Onboarding flow guides users through Canonical v2 onboarding script — identical narrative to `finlet/manual/quickstart.md` (Team C's output).

## Validation
```bash
grep -rnE 'finlet (session|benchmark|order|portfolio|status|advance|trade)( |$)' dashboard/*.html   # no hits
python3 -c "from html.parser import HTMLParser; HTMLParser().feed(open('dashboard/setup.html').read())"   # parses without errors
git diff dashboard/*.html   # replaced code-block content + data-copy/aria-label updates — no JS/CSS/structural changes
git status   # ONLY dashboard/*.html modified by you (NOT dashboard/llms.txt)
```

**Copy-button smoke test (Step 10b STRONG-2):** Open `dashboard/setup.html` in a browser, click each `<button class="btn-copy">` element, paste clipboard content into a text editor. Verify pasted content matches the visible `<code>` block EXACTLY — no truncation from broken HTML attribute parsing, no `&quot;` artifacts in the paste, no extra whitespace. If you can't open a browser, at minimum verify the HTML parses cleanly (above).

**Cross-surface narrative check:** the Claude Desktop JSON snippet in `dashboard/setup.html` matches the snippet in `finlet/manual/quickstart.md` (Team C's output) verbatim.

## Agent instructions
- You MUST `git add` and `git commit` before finishing.
- **Copy/text + data-copy attributes only.** No JS/CSS/write-flow changes. Preserve all `class=`, `id=`, structural HTML, and inline JS unchanged.
- For Canonical script's JSON snippets: keep them as JSON (double-quoted keys/values). For `data-copy` attribute parents, use DOUBLE quotes (`data-copy="..."`) so embedded JSON parses cleanly.
- For example agent prompt with single quotes around `'my-first-sim'`: prompt is plain text. If embedding in `data-copy="..."` (double-quoted), single quotes are fine. Do NOT switch quote styles around it.
- Update `aria-label` attributes for accessibility.
- Do NOT modify dashboard JS or CSS.
- Do NOT touch `dashboard/llms.txt` (Team C's regen output).
- Do NOT touch any files outside `dashboard/`.
- Commit message: `[Team D v2.0.0]: rewrite dashboard HTML examples + data-copy attributes for MCP-first onboarding`.

## CRITICAL RULES
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the "Read these files first" list BEFORE writing any code.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message must start with `[Team D v2.0.0]:`.
- Run the validation commands above before finishing.

When done, report: DONE + commit hash + validation results.
OR: BLOCKED + what went wrong.
