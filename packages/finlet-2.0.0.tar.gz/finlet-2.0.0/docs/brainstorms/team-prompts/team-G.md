You are **Team G: Frontend + billing cap removal** for /exec-plan execution of `docs/brainstorms/SESSION_LEVEL_BLIND_EXECUTION_PLAN.md`.

**Blocked by:** none. Parallel with Team A.

## Read these files FIRST

- `dashboard/app.js` — find the `tickers.length > 50` check
- `dashboard/index.html` near line 342 — form hint text
- `dashboard/pricing.html` lines 147, 162 — Free + Builder tier copy
- `finlet/billing/stripe_config.py` — tier definitions; look at `max_tickers` for FREE and BUILDER

**ALSO read `docs/KNOWN_FAILURES.md`** before running tests.

## Files touched

- **Modified: `dashboard/app.js`**
  - Remove the `tickers.length > 50` check entirely.
- **Modified: `dashboard/index.html`** (line 342 area)
  - Replace the existing form hint with EXACTLY: `"Enter ticker symbols separated by commas (must be in catalog)"`.
- **Modified: `dashboard/pricing.html`**
  - Free (around line 147): replace ticker-count copy with EXACTLY: `"Unlimited tickers per session"`.
  - Builder (around line 162): same EXACTLY: `"Unlimited tickers per session"`.
- **Modified: `finlet/billing/stripe_config.py`**
  - Set `max_tickers=None` for FREE and BUILDER tiers.
  - Audit any tier-comparison logic that branches on `max_tickers is not None`. Update such logic so `None` means "unlimited" (no cap) rather than "no tickers" (zero).

## Out of scope

- Legacy `legacy/dashboard-ui/` — do NOT touch.
- Other tiers (PRO, ENTERPRISE, etc.) — only Free + Builder.

## Validation (MUST run before reporting DONE)

```bash
cd $(git rev-parse --show-toplevel)
uv run pytest tests/billing -x --no-header -q
uv run ruff check finlet/billing/stripe_config.py
# Sanity grep — no `> 50` ticker cap left in dashboard
grep -n "tickers.length > 50" dashboard/app.js && echo "FAIL: cap still present" || echo "OK: cap removed"
# Sanity grep — pricing copy updated
grep -c "Unlimited tickers per session" dashboard/pricing.html
```

All must pass.

## CRITICAL RULES

- Read `docs/KNOWN_FAILURES.md` first — do NOT report those as issues.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message MUST be EXACTLY: `[Team G]: nuke universe cap across dashboard + Free/Builder pricing + billing config`
- Run the validation commands above and verify all pass before finishing.
- DO NOT spawn subagents.
- DO NOT push to remote.
- DO NOT touch `legacy/dashboard-ui/`.
- ALWAYS use `git -C $(pwd) <op>` for git ops since you're in a worktree.

## Worktree rules

You are running in an isolated git worktree. ALL git operations MUST run in your current working directory (your worktree branch). Use `git status`, `git add`, `git commit`, `git log` directly — do NOT cd to other directories.

## When done

Report in this exact format:
```
TEAM G: DONE
commit=<sha>
validation:
  test_billing: PASS/FAIL (counts)
  ruff: PASS/FAIL
  dashboard_cap_removed: PASS/FAIL
  pricing_copy: PASS/FAIL (count of matches)
notes=<one-line summary>
```

OR:
```
TEAM G: BLOCKED
reason=<short>
details=<longer>
```
