# Session-Level Blind Mode — Execution Plan (v12)

> Generated from `docs/brainstorms/SESSION_LEVEL_BLIND_REQUIREMENTS.md` (v2, post-Codex Step 1.5).
> Baseline SHA: `b1a305f` (HEAD at 2026-05-22).
> v12 = v11 with Step 10k fixes (1 BLOCKER + 3 STRONGs + 3 NITs).
> Codex review history: Steps 1.5, 10a-10k. Each pass was a fresh `Agent(subagent_type=codex:codex-rescue)` spawn with a unique agentId and fresh `codex exec` CLI thread.

## Status: SHIPPED 2026-05-22

All 7 teams (A, B, C, D, E, F, G) merged on main. 6 post-merge Codex-review fix commits landed. Final smoke pass: 3468 passed, 1 skipped, 1 xfailed.

### Team commit SHAs

| Team | Atomic commit | Merge commit | Scope |
|---|---|---|---|
| A | `93a1a50` | `15206c7` | `session_service.create_session(blind=...)` + auto-name + `_blind_mapping_for` unification + configure blocks + benchmark `_skip_catalog_check` + `routes_session` line-222-225 deletion |
| B | `34e00e9` | `61e161f` | MCP `create_session(blind=...)` + wrap session-touching success paths + close `freeze_time` clock-leak gap |
| C | `dc74c11` | `f7a3e7d` | REST blind request field + `SessionConfigResponse.blind` + remove `max_length=50` + catalog validator |
| D | `8b95fbf` | `1ae575f` | CLI `--blind`/`--no-blind` flag for session create |
| E | `15a4f08` | `b3d5372` | Full leak-gate suite + persistence spy + configure blocks + owner-REST audience-matrix regression + tier-removed regression |
| F | `8150125` | `78eb1ac` | Docs + decision record + CHANGELOG + audience-matrix correction |
| G | `bcc9ecf` | `2aa3810` | Nuke universe cap across dashboard + Free/Builder pricing + billing config |

### Post-merge fix commits (6 from Codex review rounds)

| Fix SHA | Team | Severity | Root cause |
|---|---|---|---|
| `427ad87` | A | P1+P2 | Catalog extension for `BENCHMARK_SCENARIOS` + `configure_session` atomicity |
| `ff79ab7` | B | P1 | Redact wall-clock audit fields in blind `session_response` (Day_N on `created_at` leaks Day_1) |
| `a5f8693` | D | P1 | CLI `session_create` prints response `config.universe` not local `--universe` input (blind leak) |
| `f60a7ec` | E | 3 STRONGs | Bound-import patch, `advance_time` sweep, real pause/resume reload |
| `620d825` | A | Round 2 STRONG | Scope benchmark catalog bypass to api-driven path only (global union exposed BENCHMARK tickers to all users) |
| `e33cfb0` | A | BLOCKER | Gate benchmark catalog bypass on unforgeable API key marker (`user.email` is user-controlled via `/auth/register`) |

Finalize commits: `8e4971b` (ruff `--fix` cleanup) + `bcb0a92` (eval-trace artifacts).

## Scope summary

1. Add `blind: bool` kwarg to `create_session` (MCP canonical, REST + CLI derived).
2. Auto-generate `session.name = "blind-{session.id[:8]}"` at creation when `blind=True`; user input ignored. Permanent — `configure_session(name=...)` rejected.
3. Reject `configure_session(universe=...)` on blind sessions; for non-blind, validate catalog membership.
4. Reuse existing BlindMapping plumbing. No new MCP tools. No new decrypt tool.
5. Remove the arbitrary 50-ticker cap. Enforce catalog membership instead.
6. Wrap MCP session-touching success responses through `_blind_mapping_for(session)` — including the clock-tool gap (`freeze_time`).
7. Match HEAD's existing mixed audience behavior. Reveal lifecycle deferred.

## Constraints (authoritative — teams defer here when team specs disagree)

### Audience contract (matches HEAD as of `b1a305f`)

| Audience | Surface | Behavior on blind session | HEAD evidence |
|---|---|---|---|
| Authenticated owner | REST `routes_session.py` create, get, list, configure, visibility | **REAL** — no `blind_mapping` injected | `routes_session.py:185, 195, 240, 257` use `session_response(s)` plain. `tests/api/test_public_session_blind.py:429-468` locks the authenticated `GET /sessions/{id}` shape; Team E adds regression coverage for the remaining ones. |
| Authenticated owner | REST `POST /v1/sessions/{id}/complete` | **MOSTLY REAL — benchmark_complete blinded** (v12 — Codex Step 10k BLOCKER 1). Service payload paths: (a) non-benchmark blind → REAL `session_response(session)` at `session_service.py:730-732`; (b) benchmark_transition → REAL `next_session.config.{start_time, end_time, universe}` at `session_service.py:898`, **transition envelope blinding only fires in MCP** at `server.py:572` — REST gets the REAL transition payload; (c) benchmark_complete → BLINDED at service level via `benchmark_blind_mapping` at `session_service.py:943-987`. Route at `routes_session.py:260-277` returns service result directly. | |
| Authenticated owner | REST `DELETE /v1/sessions/{id}` | **N/A success path** — delete confirmation only (`{"status": "deleted", "id": ...}` at `routes_session.py:207-208`). **Error path caveat (Codex Step 10k STRONG 1):** benchmark-current deletion raises `ValueError` with session/run IDs at `session_service.py:555`, not caught by REST route — leaks IDs (not tickers/dates/name) in error envelope + server logs. Out of scope for this work; existing benchmark behavior. | `SessionDeleteResponse` schema |
| Authenticated owner | REST `GET /v1/sessions/{id}/orders` + `GET /v1/sessions/{id}/orders/{order_id}` | Trading data (not session metadata). Today returns `list_orders(session, filter_status)` (`routes_session.py:287-303`) and `get_order(...)` (`:306-320`) without `blind_mapping`. Codex Step 10j STRONG 2 flagged that v10 only listed the list-orders alias; v11 covers both. Owner sees REAL today; matches HEAD's mixed split. | |
| Authenticated owner | REST `routes_portfolio.py` `/portfolio`, `/portfolio/history` | **REAL** | `routes_portfolio.py:32-95` return real |
| Authenticated owner | REST `routes_portfolio.py` `/trace` | **BLINDED** | `routes_portfolio.py:98-103` passes `blind_mapping=_blind_mapping_for(session)` |
| Authenticated owner | REST `routes_clock.py`, `routes_trade.py` | **REAL** | `routes_clock.py:51-52`, `routes_trade.py:141`, no `blind_mapping` |
| Authenticated owner | REST `routes_market.py` (`/price`, `/fundamentals`, `/filings`, `/search-news` etc.) | **BLINDED** | Market routes call `_route_query_with_rate_limit(...)` (e.g. price return at `routes_market.py:140`); ultimately `route_query` blinds via `market_service.py:732` (news short-circuit) and `:865` (items transform) when `session.config.blind`. (Codex Step 10j NIT 2 — route paths are `/price` not `/prices` and `/search-news` not `/news`.) |
| Authenticated owner | REST `routes_benchmark.py` (`PATCH /benchmark-runs/{id}/visibility`, `POST /benchmark-runs/{id}/decrypt`) | **OUT OF SCOPE** for this work (v12) — benchmark-only routes for the existing `BenchmarkRun` decrypt lifecycle (not session-level blind). Mounted at `finlet/api/app.py:720-723`. Codex Step 10j STRONG 3 flagged that v10 didn't list these; v11 acknowledges out-of-scope and Team E does not add coverage for them. | |
| Authenticated owner | REST `routes_sse.py` SSE | **BLINDED** | `routes_sse.py:113-125` passes `blind_mapping=_blind_mapping_for(session)` |
| Agent (MCP tools) | All session-touching MCP tools | **BLINDED** (v9 Team B closes the gaps that exist in HEAD today) | Team B wraps success returns through `_blind_mapping_for(session)` |
| Public anonymous viewer (`public=True, public_anonymous=True`) | All five public surfaces | **BLINDED** | Existing `session_service.py:257-258` blind transform |
| Public attributed viewer (`public=True, public_anonymous=False`) | All five public surfaces | **Universe + dates blinded** (existing); **name safe by construction** via v9 auto-name at creation | Same blind transform; auto-name closes the attributed-name leak |

**v9 does NOT** harmonize HEAD's mix. Owner sees some REST surfaces real and some blinded today; v9 preserves that. Reveal lifecycle deferred.

### Other constraints

- **MCP-first architecture preserved.** MCP `create_session` is canonical; REST + CLI derived. CLI already dispatches via MCP (`finlet/cli.py:604`).
- **Reuse existing blind plumbing.** Do NOT fork `generate_mapping` / `BlindMapping` / `apply_ticker` / `apply_date` / `assert_no_real_blinded_data` / `_blind_mapping_for` / `@blind_error_mapper` / `_KNOWN_BENCHMARK_TICKERS` / `_blind_clock_dict` / `_blind_advance_result`.
- **Existing `start_benchmark(blind=True)` flow stays green.** Verified by `tests/leaderboard/test_*blind*`, `tests/mcp/test_start_benchmark_blind.py`, `tests/e2e/test_blind_benchmark_zero_leak.py`.
- **Universe cap nuked** (per user 2026-05-22): remove hardcoded `max_length=50` from `SessionCreateRequest.universe` + `SessionConfigureRequest.universe`; set `max_tickers=None` for all four tiers; remove dashboard `tickers.length > 50` check; remove "1-50" form hint; update Free + Builder pricing cards.
- **Catalog membership enforced** on BOTH create AND configure paths (Codex Step 10h BLOCKER 5): `universe ⊆ catalog` (270 tickers from `scripts/ticker_lists/us_equities.txt` + `us_etfs.txt` per `_UNIVERSE_SOURCES`). Off-catalog rejected: `"ticker '<X>' not in catalog — call list_available_tickers"`. Benchmark exemption via `_skip_catalog_check: bool = False` private kwarg passed by `create_scenario_session`.
- **Universe normalization** at service entry: `list(dict.fromkeys(t.strip().upper() for t in universe if t.strip()))` — strip whitespace, uppercase, drop empties, dedup preserving first-seen.
- **Auto-name at CREATION for blind sessions.** HEAD `Session.__init__` signature is `Session(config, session_id=None, user_id=None, name="")` per `finlet/core/session.py:149-151` (positional + kw, allocates id from `session_id or uuid4().hex[:12]`, name defaults to `""`). Service builds session with `name=""` placeholder, then immediately after constructor returns sets `session.name = f"blind-{session.id[:8]}"` if `blind=True`. Done BEFORE `await save_session(session)`.
- **Attach BlindMapping BEFORE first `save_session`.** Order:
  ```python
  session = Session(config, user_id=user.id, name=("" if blind else name))
  session.activate()
  if blind:
      session.name = f"blind-{session.id[:8]}"
      mapping = generate_mapping(normalized_universe, start, benchmark_ticker=benchmark_ticker)
      session.blind_mapping = mapping
      session.config.blind = True
  await create_session_db(session.id)
  await save_session(session)
  ```
- **`configure_session` blocks on blind sessions:** reject `universe` change AND `name` change with 409. For NON-blind sessions: validate `universe ⊆ catalog` before assigning (Codex Step 10h BLOCKER 5).
- **MCP success-path wrapping pattern.** Service helpers (pause/resume/complete) UNCHANGED. MCP tool wrappers call service for state mutation, then re-derive blinded response from session object. For `complete_session` MCP wrap: ONLY non-benchmark completion path gets the new wrap; `benchmark_transition` AND `benchmark_complete` envelopes have their own existing blinding at `server.py:567+, 620+` — DO NOT override them (Codex Step 10h BLOCKER 1).
- **Clock-tool gap (`freeze_time`).** `finlet/mcp/server.py:1557` returns `_svc_freeze_session(session)` directly with real clock dates. `get_sim_time` already applies `_blind_clock_dict`; `advance_time` already applies `_blind_advance_result`. Team B audits all clock-touching MCP tools and applies the appropriate existing helper. Known gap: `freeze_time`. Recon at apply time for `step_time`, `play`, `pause_clock` if present.
- **`_blind_mapping_for` is the single source of truth.** Move the helper from `finlet/api/serializers.py:277` into `finlet/api/services/session_service.py`. `serializers.py` re-imports it. Direction: services → serializers does NOT exist today (only serializers → models); having the helper IN session_service.py means serializers can import from services (forward direction). Team A's move keeps the import graph sane.
- **`d["blind"]` at top level of `session_response()`.** Mirror existing `d["public"]` line. Populates `SessionResponse.blind` declared at `finlet/api/schemas/session.py:88`. Team C adds `blind: bool = False` to `SessionConfigResponse` so the nested `config.blind` round-trips.
- **Day_N anchors at Day_1** per `finlet/core/blind_mapping.py:768` (`apply_date` doc: "Day_1 corresponds to mapping.date_origin").
- **No `_skip_catalog_check` smuggling.** REST request models don't have `extra="forbid"`; safety comes from explicit field forwarding in the handler at `routes_session.py:127-139` (only known kwargs passed). MCP/CLI signatures explicit. Test asserts.
- **Tests with `FINLET_BLIND_ASSERT=raise`.** Fixtures MUST `monkeypatch.setenv("FINLET_BLIND_ASSERT", "raise")` so `assert_no_real_blinded_data` raises instead of logging.
- **DB round-trip spy patch target:** `finlet.api.services.session_service.save_session` (bound import).
- **Pre-launch + post-Stripe-live:** `tests/billing/` + `tests/auth/` + rate-gate tests retain green.
- **Feature 2 (landing-page news copy) EXCLUDED** — separate Edit.

## File Conflict Table

| File | Touched by Teams |
|---|---|
| `finlet/api/services/session_service.py` | A |
| `finlet/api/serializers.py` | A |
| `finlet/leaderboard/benchmark_state.py` | A (single-line `_skip_catalog_check=True` at line 639) |
| `finlet/api/routes_session.py` | A (line 222-225 deletion AND configure handler's service call adds `name=body.name`) + C (request schemas + create handler + visibility handler) |
| `finlet/api/schemas/session.py` | C |
| `finlet/mcp/server.py` | B |
| `finlet/mcp/tools_session.py` | B |
| `finlet/cli.py` | D |
| `finlet/billing/stripe_config.py` | G |
| `dashboard/app.js`, `dashboard/index.html`, `dashboard/pricing.html` | G |
| `tests/...` (Team E scope) | E |
| `docs/brainstorms/SESSION_LEVEL_BLIND_REQUIREMENTS.md`, `docs/ARCHITECTURE.md`, `docs/decisions/session-level-blind-extends-create-session.md` (new), `CHANGELOG.md` | F |

**`routes_session.py` shared between A and C — LINE-DISJOINT.** Team A edits the configure handler body ONLY (lines 222-225 deletion + add `name=body.name` to existing `configure_session(...)` service call); Team C edits the request schemas (49-90) + create handler + visibility handler. Same function (configure_route) touched by A's body change and C's leaves-alone — no content conflict.

**Eliminating B-C parallel leak window (Codex Step 10h BLOCKER 4):** Team C exposes the `blind` REST field; until Team B's MCP wrappers ship, MCP success paths for the new blind sessions would leak. v9 forces **B → C** in the dependency graph (B blocks C).

## Dependency Graph

- **A** blocks B, C, D, E.
- **B** blocked by A. **Blocks C.**
- **C** blocked by A + B.
- **D** blocked by B.
- **E** blocked by A+B+C+D+G.
- **F** independent.
- **G** parallel to A.

**Critical path:** A → B → C → D → E (linear; C now serialized after B).

F parallel to all. G parallel to A.

---

## Team A: Service-layer foundation

**Blocked by:** none.

**Read these files first:**
- `finlet/api/services/session_service.py:37-110` — `session_response()` builder
- `finlet/api/services/session_service.py:380-470` — `create_session`
- `finlet/api/services/session_service.py:580-618` — `configure_session`
- `finlet/api/services/session_service.py:620-735` — `pause_session` / `resume_session` / `complete_session` (UNCHANGED in v9)
- `finlet/api/serializers.py:277-300` — `_blind_mapping_for(session)`
- `finlet/core/session.py:149-160` — `Session.__init__` signature
- `finlet/leaderboard/benchmark_state.py:639` — benchmark `create_session(...)` call site
- `finlet/api/routes_session.py:210-240` — configure handler

**Recon evidence (verified against HEAD `b1a305f`):**

```python finlet/core/session.py:149-160
    def __init__(
        self, config: SessionConfig, session_id: str | None = None, user_id: str | None = None, name: str = ""
    ) -> None:
        self.id = session_id or uuid4().hex[:12]
        self.user_id = user_id
        self.name = name
        self.config = config
        self._status = SessionStatus.CREATED
        self.created_at = datetime.now(timezone.utc)
```

```python finlet/api/services/session_service.py:597-598
    if universe is not None:
        session.config.universe = universe
```

```python finlet/api/routes_session.py:222-228
    session = get_user_session(session_id, user)

    # Handle name update before delegating to service
    if body.name is not None:
        session.name = body.name

    try:
        session = await configure_session(
            session,
            universe=body.universe,
            ...
```

**Files touched:**

- Modified: `finlet/api/services/session_service.py`:
  1. Move `_blind_mapping_for` here from `serializers.py:277`. `serializers.py` re-imports it (forward services→serializers direction is fine; HEAD has serializers → models direction; new direction is additive).
  2. Add to `create_session`: `blind: bool = False`, `_skip_catalog_check: bool = False`.
  3. Universe normalization at entry: `list(dict.fromkeys(t.strip().upper() for t in universe if t.strip()))`.
  4. Catalog check (skipped when `_skip_catalog_check=True`): cache catalog at module level on first call from `_load_universe()`. Reject off-catalog: `ValidationError(f"ticker '{ticker}' not in catalog — call list_available_tickers")`.
  5. Empty-universe-with-blind reject: `if blind and not normalized_universe: raise ValidationError("blind sessions require a non-empty universe")`.
  6. Build session: `session = Session(config, user_id=user.id, name=("" if blind else name))`. Activate. THEN if `blind`: override name + generate + attach mapping + set config.blind = True. THEN `await create_session_db + save_session`.
  7. Update `session_response()` builder: add `d["blind"] = bool(session.config.blind)` at top level (mirror `d["public"]`). Nothing else changes.
  8. Block `configure_session(universe=...)` on blind: raise `ValueError("Universe changes are forbidden on blind sessions — recreate the session to change universe.")`.
  9. **For NON-blind `configure_session(universe=...)`**: apply catalog membership check (Codex Step 10h BLOCKER 5). Reject off-catalog. Reuse the same module-level catalog cache.
  10. Add `name: str | None = None` kwarg to service `configure_session`. Block name change on blind: `raise ValueError("Name changes are forbidden on blind sessions — auto-generated name is permanent.")`. Apply name when supplied AND non-blind.
  11. `pause_session`, `resume_session`, `complete_session` UNCHANGED.
- Modified: `finlet/leaderboard/benchmark_state.py`:
  - Line 639: append `_skip_catalog_check=True` to the `create_session(...)` kwargs.
- Modified: `finlet/api/routes_session.py`:
  - Configure handler: delete lines 222-225 (the `if body.name is not None: session.name = body.name`). Modify the existing `service.configure_session(...)` call to pass `name=body.name`. Net effect: route configure name + universe through service, in one merge.

**Deliverable:** Service `create_session(blind=...)` produces auto-named blind sessions with persisted BlindMapping + catalog-validated normalized universe. `configure_session` blocks blind-session mutations; enforces catalog on non-blind universe changes. Benchmark exempted via `_skip_catalog_check`. Route handler stops duplicating the rename logic.

**Validation:**
- [ ] `pytest tests/services/test_session_service.py -x --no-header -q` passes
- [ ] `pytest tests/leaderboard/ -x --no-header -q` passes
- [ ] `pytest tests/api/test_complete_session_blind.py -x --no-header -q` passes
- [ ] `ruff check finlet/api/services/session_service.py finlet/api/serializers.py finlet/leaderboard/benchmark_state.py finlet/api/routes_session.py` clean
- [ ] `python -c "from finlet.api.services.session_service import _blind_mapping_for; print('ok')"` imports clean

**Agent instructions:**
- ONE commit: `[Team A]: session_service create_session(blind=...) + auto-name + _blind_mapping_for unification + configure blocks + benchmark _skip_catalog_check + routes_session line-222-225 deletion + service name passthrough in configure handler`.
- `_blind_mapping_for` MUST be defined before `session_response`.
- DO NOT touch `finlet/core/session.py`, `finlet/db/persistence.py`, `finlet/mcp/`, `finlet/cli.py`, `dashboard/`, or `finlet/billing/`.
- DO NOT change pause/resume/complete service return shapes.
- `_skip_catalog_check` is private (leading-underscore); never exposed to public surfaces.
- Catalog cache: `_CATALOG: set[str] | None = None` module-level; populate lazily on first call via `_load_universe()`.

---

## Team B: MCP — `create_session(blind=...)` + wrap session-touching success paths + close `freeze_time` clock-leak gap

**Blocked by:** Team A merged.

**Read these files first:**
- `finlet/mcp/server.py:118-160` — existing `_blind_clock_dict` + `_blind_advance_result` helpers
- `finlet/mcp/server.py:268-385` — `create_session`
- `finlet/mcp/server.py:386-440` — `list_sessions` (line 437)
- `finlet/mcp/server.py:441-475` — `get_session` (line 462)
- `finlet/mcp/server.py:515-635` — `complete_session` (existing `benchmark_transition` + `benchmark_complete` envelope blinding at lines 567+ and 620+)
- `finlet/mcp/server.py:639-715` — `pause_session` (line 672) / `resume_session` (line 711)
- `finlet/mcp/server.py:1096-1130` — `get_sim_time` (already blind-aware via `_blind_clock_dict`)
- `finlet/mcp/server.py:1134-1355` — `advance_time` (already blind-aware via `_maybe_blind`)
- `finlet/mcp/server.py:1527-1560` — `freeze_time` (LEAKS — returns `_svc_freeze_session(session)` raw)
- `finlet/mcp/tools_session.py:45-100` — `set_session_visibility` (line ~96)
- `finlet/mcp/blind_error.py:268-300` — `@blind_error_mapper` (error shapes only)

**Files touched:**

- Modified: `finlet/mcp/server.py`:
  - `create_session` tool: add `blind: bool = False` param between `slippage_bps` and `api_key`. Update Args docstring. Pass `blind=blind` to service. Tail return → `session_response(session, blind_mapping=_blind_mapping_for(session))`.
  - `list_sessions`: `results.append(session_response(s, blind_mapping=_blind_mapping_for(s)))`.
  - `get_session`: `return session_response(session, blind_mapping=_blind_mapping_for(session))`.
  - `pause_session`: call `await _svc_pause_session(session)`, discard return, then `return session_response(session, blind_mapping=_blind_mapping_for(session))`.
  - `resume_session`: same pattern.
  - `complete_session`: **Surgical wrap only on the non-benchmark completion path** (Codex Step 10h BLOCKER 1 + Step 10i BLOCKER 1):
    ```python
    response = await _svc_complete_session(session, user_record)
    # Existing benchmark_transition blind handling at line 567+ stays
    # Existing benchmark_complete blind handling at line 620+ stays
    # NEW: wrap only the non-benchmark "COMPLETED" case
    # HEAD uses uppercase: SessionStatus.COMPLETED = "COMPLETED" (finlet/core/session.py:37)
    if response.get("status") == "COMPLETED" and _blind_mapping_for(session) is not None:
        return session_response(session, blind_mapping=_blind_mapping_for(session))
    return response
    ```
    Status string is `"COMPLETED"` (uppercase) per `SessionStatus.COMPLETED.value`. Do NOT match on absence of `benchmark_transition` — that would also catch `benchmark_complete` which has its own envelope blinding.
  - `freeze_time` (line 1557): `result = await _svc_freeze_session(session); if session.config.blind and session.blind_mapping is not None: result = _blind_clock_dict(result, session.blind_mapping); return result`.
  - Audit other clock-touching MCP tools at apply time: `step_time`, `play`, `pause_clock` if they exist. Apply `_blind_clock_dict` consistently.
  - **Audit ALL `@mcp.tool()`-registered tools** (Codex Step 10i STRONG 2 + Step 10j STRONG 4 + Step 10k STRONG 2). Each falls into one of three buckets:
    - **Already blind-aware in HEAD (no change):** `get_portfolio`, `get_equity_curve`, `get_trace` (manual blinding in `tools_portfolio.py`); `submit_order`, `cancel_order` (`tools_trading.py:82+`); `list_available_tickers` (`server.py:967-1088`, blind filter at 1059-1071); market tools at `server.py:719+` (route through `route_query` which blinds via `market_service.py:732/865`); `get_sim_time` (uses `_blind_clock_dict`); `advance_time` (uses `_maybe_blind`/`_blind_advance_result`).
    - **Needs-fix (Team B scope):** `create_session`, `list_sessions`, `get_session`, `pause_session`, `resume_session`, `complete_session` (non-benchmark COMPLETED case only), `set_session_visibility`, `freeze_time` + any other clock tool found during audit.
    - **Out of scope (don't touch):** benchmark-specific tools (`start_benchmark`, `get_benchmark_progress`, `export_benchmark_results`, `delete_benchmark_run` in `tools_benchmark.py`); `report_bug` (`tools_telemetry.py:78`, no session payload). `delete_session` returns `{"status": "deleted", ...}` — safe in success; error-path leak is benchmark-specific and out of scope.
    - Document each tool's bucket in commit body.
  - Top of file: import `_blind_mapping_for` from `finlet.api.services.session_service`.
- Modified: `finlet/mcp/tools_session.py`:
  - `set_session_visibility`: `return session_response(session, blind_mapping=_blind_mapping_for(session))`.
  - Import `_blind_mapping_for`.

**Deliverable:** Every MCP session-touching success path returns blinded responses for blind sessions. Clock-tool gap (`freeze_time` + any audited siblings) closed. Existing `benchmark_transition` + `benchmark_complete` envelope blinding preserved unchanged.

**Validation:**
- [ ] `pytest tests/mcp/test_mcp_server.py -k "create_session or list_sessions or get_session or pause_session or resume_session or complete_session or freeze_time" -x --no-header -q` passes
- [ ] `pytest tests/mcp/test_tools_session.py -k visibility -x --no-header -q` passes (recon exact filename at apply)
- [ ] `ruff check finlet/mcp/server.py finlet/mcp/tools_session.py` clean
- [ ] FastMCP introspection: `python -c "from finlet.mcp.server import mcp; t = mcp._tool_manager.get_tool('create_session'); assert 'blind' in t.parameters['properties']"` succeeds

**Agent instructions:**
- ONE commit: `[Team B]: MCP create_session(blind=...) + wrap session-touching success paths + close freeze_time clock-leak gap`.
- DO NOT modify `@blind_error_mapper`.
- DO NOT change service helper signatures or return shapes.
- For `complete_session` wrap: explicitly check `response.get("status") == "COMPLETED"` (uppercase — matches `SessionStatus.COMPLETED.value`) — do NOT use "not benchmark_transition" as the gate.
- Audit all `@mcp.tool()` decorated functions for raw `_svc_X` returns — fix any clock/session leaks. Document each fix in commit body.

---

## Team C: REST — request fields, response schema, cap removal, catalog validator

**Blocked by:** Team B merged (Codex Step 10h BLOCKER 4 — no parallel with B).

**Files touched:**

- Modified: `finlet/api/routes_session.py`:
  1. Add `blind: bool = Field(False, description="When True, create a blind session: agent (MCP) sees opaque T_NNNN tickers and Day_N dates; owner sees real on REST routes_session.")` to `SessionCreateRequest`.
  2. Remove `max_length=50` from `SessionCreateRequest.universe` (line 54) AND `SessionConfigureRequest.universe` (line 75).
  3. Catalog membership validator `@field_validator("universe")` on both request models (with `if v is None: return v` passthrough on configure). Reject off-catalog.
  4. `POST /v1/sessions` handler: pass `blind=body.blind` to `session_service.create_session(...)`.
  5. Visibility handler unchanged from HEAD (owner sees real).
  6. Configure handler — Team A already deletes lines 222-225 AND adds `name=body.name` to the service call. Team C does NOT touch the configure handler body.
- Modified: `finlet/api/schemas/session.py`:
  - Add `blind: bool = False` to `SessionConfigResponse`.

**Validation:**
- [ ] `pytest tests/api/test_sessions.py tests/core/test_session_configure.py -x --no-header -q` passes
- [ ] `ruff check finlet/api/routes_session.py finlet/api/schemas/session.py` clean
- [ ] OpenAPI: `jq '.components.schemas.SessionCreateRequest.properties.blind'` shows field
- [ ] OpenAPI: `jq '.components.schemas.SessionConfigResponse.properties.blind'` shows field
- [ ] Smoke: POST `/v1/sessions` with 100 catalog tickers succeeds; off-catalog returns 422

**Agent instructions:**
- ONE commit: `[Team C]: REST blind request field + SessionConfigResponse.blind + remove max_length=50 + catalog validator`.
- Default `blind` field MUST be `False`.
- `body.blind` not `payload.blind`.
- DO NOT inject `blind_mapping` into REST responses — owner sees real.
- DO NOT touch the configure handler body — Team A owns it.

---

## Team D: CLI `--blind` flag

**Blocked by:** Team B merged.

**Files touched:**

- Modified: `finlet/cli.py`:
  - Add `blind: bool = typer.Option(False, "--blind/--no-blind", help="Create a blind session: agent sees opaque tickers and Day_N dates.")` to `session_create`.
  - Add `"blind": blind` to args dict.

**Validation:**
- [ ] `pytest tests/test_cli.py -k session_create -x --no-header -q` passes
- [ ] `finlet session create --help | grep -- '--blind'` shows the flag

---

## Team E: Tests

**Blocked by:** A + B + C + D + G merged.

**Files touched (new):**

- `tests/api/test_session_create_blind.py`:
  - Positive create + auto-name override + DB-spy persistence + universe normalization + empty-universe reject + off-catalog reject + `_skip_catalog_check` smuggle-test + non-blind regression.
- `tests/api/test_session_configure_blind.py`:
  - Blind universe + name rejection (409).
  - **Non-blind universe catalog rejection** (Codex Step 10h BLOCKER 5): `configure_session(non_blind, universe=["FAKE"])` rejects.
  - Non-blind happy path still works.
- `tests/mcp/test_create_session_blind.py`:
  - MCP create returns top-level `blind == True` + blinded `config.universe` + auto-name.
  - FastMCP introspection (`mcp._tool_manager.get_tool('create_session').parameters['properties']` contains `'blind'`).
- `tests/mcp/test_session_lifecycle_blind.py`:
  - `get_session`, `list_sessions`, `pause_session`, `resume_session`, `set_session_visibility`, `complete_session` (non-benchmark path), `freeze_time` MCP tools all return blinded for blind sessions.
  - `complete_session` benchmark path still blinds via existing envelope code (regression).
  - Owner REST regression: `routes_session` (create/get/list/configure/visibility — all REAL) + `routes_portfolio` (/portfolio + /history) + `routes_clock` + `routes_trade` + orders aliases at `:287` AND `:306` return REAL for blind sessions.
  - `POST /v1/sessions/{id}/complete` regression: NON-benchmark blind returns REAL session_response; benchmark blind transitions return existing benchmark_complete envelope (preserved). Test both branches.
  - `DELETE /v1/sessions/{id}`: returns `{"status": "deleted", "id": ...}` only — no metadata leak; verify no `config.universe` or session.name in response.
  - Owner REST `routes_portfolio /trace` + `routes_sse` + `routes_market` return BLINDED for blind sessions.
- `tests/e2e/test_session_level_blind_zero_leak.py`:
  - Fixture: `monkeypatch.setenv("FINLET_BLIND_ASSERT", "raise")`.
  - Dual-axis per MCP tool: `assert_no_real_blinded_data(response_dict, mapping)` on structured dict + substring scan on `json.dumps(response, default=str)`.
  - `search_terms`: real universe + `benchmark_ticker` + `_KNOWN_BENCHMARK_TICKERS` + ISO dates in session window.
  - Explicit per-tool valid args (modeled on `test_blind_benchmark_zero_leak.py:714+`).
  - Coverage check: enumerate `mcp._tool_manager.list_tools()`; assert every `@blind_error_mapper` + clock-touching tool has a case.
  - Sweep axes: full lifecycle, error paths, `complete_session` non-benchmark, SSE event sweep, `/portfolio/trace`, `freeze_time`.
  - Negative self-test: force `session.blind_mapping = None`; assert leak gate fails loudly.
  - **Pause/resume reload regression** for the `persist_session` gap.
- `tests/billing/test_tier_max_tickers_removed.py`: all four tiers `max_tickers is None`.
- **Delete or update** `tests/api/test_input_validation.py::test_configure_universe_too_many_returns_422` (Codex Step 10i STRONG 3): HEAD expects 51 tickers to fail with 422. With v9's cap removal, this test breaks. Action: either DELETE the test (universe is now catalog-bounded, not numerically-bounded) OR repurpose it to assert that 51 off-catalog tickers fail. Recommendation: repurpose with `["FAKE1", "FAKE2", ...]` to test catalog rejection.
- `tests/leaderboard/test_benchmark_state.py` (additive): assert `_skip_catalog_check=True` is passed in `create_scenario_session`'s `create_session` call.
- `tests/test_cli.py` (additive): `finlet session create --blind` smoke.

**Validation:**
- [ ] `FINLET_BLIND_ASSERT=raise pytest tests/api/test_session_create_blind.py tests/api/test_session_configure_blind.py tests/mcp/test_create_session_blind.py tests/mcp/test_session_lifecycle_blind.py tests/e2e/test_session_level_blind_zero_leak.py -x --no-header -q` passes
- [ ] `pytest tests/e2e/test_blind_benchmark_zero_leak.py -x --no-header -q` passes (regression)
- [ ] `pytest tests/billing tests/auth -x --no-header -q` passes
- [ ] `pytest tests/leaderboard/test_benchmark_state.py -x --no-header -q` passes
- [ ] `pytest tests/test_cli.py -k session_create -x --no-header -q` passes

**Agent instructions:**
- ONE commit: `[Team E]: full leak-gate suite + persistence spy + configure blocks + owner-REST audience-matrix regression + tier-removed regression`.
- Use `mcp._tool_manager.list_tools()` for FastMCP introspection.
- `monkeypatch.setenv("FINLET_BLIND_ASSERT", "raise")` in every leak-gate fixture.
- Spy patch target: `finlet.api.services.session_service.save_session`.

---

## Team F: Docs + decision record + CHANGELOG + requirements doc

**Blocked by:** none.

**Files touched:**

- Modified: `docs/brainstorms/SESSION_LEVEL_BLIND_REQUIREMENTS.md`: update audience matrix to match v9 constraints section (HEAD's mixed audience behavior). Drop reveal-lifecycle claims. Add "Deferred ideas" entry.
- Modified: `docs/ARCHITECTURE.md`: extend blind-benchmark section around line 1620 to document session-level entry point + auto-name policy + catalog enforcement.
- New: `docs/decisions/session-level-blind-extends-create-session.md`: decisions.
- Modified: `CHANGELOG.md`: `## [Unreleased]` entry.

**Agent instructions:** ONE commit: `[Team F]: docs + decision record + CHANGELOG + requirements audience-matrix correction for session-level blind (v9 plan)`. No code or tests.

---

## Team G: Frontend + billing cap removal

**Blocked by:** none. Parallel to Team A.

**Files touched:**

- `dashboard/app.js`: remove `tickers.length > 50` check.
- `dashboard/index.html:342`: replace form hint with `"Enter ticker symbols separated by commas (must be in catalog)"`.
- `dashboard/pricing.html`: Free (line 147) + Builder (line 162) → `"Unlimited tickers per session"`.
- `finlet/billing/stripe_config.py`: set `max_tickers=None` for FREE and BUILDER; audit any tier-comparison logic that branches on `max_tickers is not None`.

**Validation:**
- [ ] `pytest tests/billing -x --no-header -q` passes
- [ ] Dashboard form submits with 100-ticker universe
- [ ] Pricing renders new copy

**Agent instructions:** ONE commit: `[Team G]: nuke universe cap across dashboard + Free/Builder pricing + billing config`. Legacy `legacy/dashboard-ui/` OUT OF SCOPE.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| `_blind_mapping_for` import-cycle | Low | Medium | Helper lives in `session_service.py`; `serializers.py` re-imports. Forward direction. |
| Owner can't customize blind session name | High | Low | Trade-off accepted. Closes name-leak class. |
| Owner can't see real portfolio/trace/SSE/market for blind sessions | Medium | Low | Matches HEAD. Reveal lifecycle deferred. |
| `_skip_catalog_check` smuggling via REST body | Low | Medium | Handler at `routes_session.py:127-139` forwards explicit kwargs only. Team E asserts. |
| Off-catalog rejection breaks power-user workflows | Low | Medium | HEAD's `_validate_coverage` silently skipped; v9's explicit reject is clearer. |
| Universe normalization doesn't handle ZWSP/BOM | Low | Low | Catalog rejection is the backstop. |
| `persist_session` doesn't write `blind_mapping_json` — pause/resume cycle may drop mapping (existing bug) | Medium | High | Team E pause/resume reload regression test surfaces. Existing benchmark fragility out of scope. |
| Existing benchmark blind path attaches mapping AFTER `create_session` returns (out of scope) | Acknowledged | Medium | Unchanged in v9. Tests pass today. New session-level path attaches inside service (item 6) so the new code is robust. |
| `complete_session` MCP wrap mis-scoped (would override `benchmark_complete`) | Resolved | n/a | v9 scopes wrap to `response.get("status") == "COMPLETED"` only (uppercase). Benchmark envelopes untouched. |
| `freeze_time` clock-leak gap remained from HEAD | Resolved | n/a | Team B explicitly fixes + audits other clock tools. |
| Catalog enforcement bypass on non-blind `configure_session(universe=...)` | Resolved | n/a | Team A item 9 adds catalog check on non-blind configure too. |
| Merge-order leak between Team C (REST exposes `blind`) and Team B (MCP wraps) | Resolved | n/a | Dependency graph forces B → C. C cannot ship until B has wrapped MCP responses. |
| `complete_session` MCP status case mismatch (`"completed"` vs `"COMPLETED"`) | Resolved | n/a | v10 corrects to uppercase `"COMPLETED"` per `SessionStatus.COMPLETED.value` (Codex Step 10i BLOCKER 1). |
| Existing `tests/api/test_input_validation.py::test_configure_universe_too_many_returns_422` breaks with cap removal | Resolved | n/a | Team E repurposes the test to assert catalog rejection on 51 off-catalog tickers (Codex Step 10i STRONG 3). |

## Session Plan

### Session 1 — Foundation (A + G parallel)
**Checkpoint:** `pytest tests/services tests/api tests/leaderboard tests/billing -k blind -x --no-header -q` passes.

### Session 2 — Surfaces (B first, then C, then D)
B → C → D linear (B blocks C per BLOCKER 4 resolution).
**Checkpoint:** REST + MCP + CLI accept `blind`; OpenAPI shows fields; `freeze_time` no longer leaks.

### Session 3 — Tests + Docs (E + F parallel)
**Checkpoint:** Full test suite green INCLUDING leak gates with `FINLET_BLIND_ASSERT=raise`.

---

## Codex review history

7 prior passes (Steps 1.5, 10a-10g) on v1-v7; one pass (Step 10h) on v8. v1-v7 amended incrementally — accumulated stale text caused late iterations to flag internal contradictions. v8 was a clean rewrite that resolved the contradictions but surfaced 5 substantive new findings (real architectural gaps, not cruft). v9 incorporates all 5.

v9 → Step 10i for fresh review.
