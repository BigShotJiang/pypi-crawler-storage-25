# v2.0.0 Pure-MCP Migration — Execution Plan

> Generated 2026-05-22 from inline brief (`/plan-features` invocation in main chat).
> Baseline SHA: `fb2637c` (HEAD on `main`).
> Version: **v3** (post-Step-10a + Step-10b; all v1 + v2 BLOCKERs amended in place, STRONG-SUGGESTIONs integrated, NITs captured).
>
> **Status:** EXECUTED 2026-05-22. All 5 teams (A/B/C/D/E) merged. Codex per-merge BLOCKERs all cleared via fix-on-main cycles. See `docs/brainstorms/codex-diff-reviews/` for verdicts.

## Motivation

Drop Finlet's human-facing CLI subcommands that duplicate MCP tools. Keep only the minimal CLI needed for MCP to function. Eliminate the entire CLI/MCP drift class of bugs (most recently surfaced by Codex 2026-05-22 — `finlet session create` printed real tickers in blind mode because the CLI carried its own divergent display logic).

Finlet's positioning is **"agentic trading evaluation harness, NOT a human trading sim."** A human-facing CLI is off-mission. With zero customers (pre-launch — see `[[project-pre-launch-no-customers]]`), this is a free move; post-launch it would be a v2.0.0 breaking change with migration friction.

**Scope honesty (Step 10a STRONG-1):** This work fixes the CLI surface of the drift problem, NOT the broader drift across docs/dashboard/llms.txt/architecture-records. That broader drift is what makes Teams C and D rewrite work necessary in this same plan. Going forward, future contributors should write to ONE canonical onboarding source (see "Canonical v2 onboarding script" below) and let downstream surfaces consume it, rather than maintaining parallel narratives.

## Constraints

- **No MCP tool shape changes.** This work is strictly subtractive on the CLI side. If a dropped CLI command exposes a feature with no MCP equivalent, FLAG IT — do not silently add a new MCP tool to fill the gap. (Decision deferred to a separate plan.) Specifically: the CLI's `session publish` command previously printed a share URL; after deletion, the URL is derived by the consumer as `https://finlet.dev/sessions/{id}` — do NOT modify `set_session_visibility` to return a `share_url` field.
- **No regression in functionality reachable via MCP.** Every behavior the dropped CLI commands exposed must remain reachable via MCP tools. Cross-check explicitly in Team B with the named MCP test files in Team B's spec.
- **No test coverage regression.** Tests being deleted must have equivalent assertions in `tests/mcp/`, or unique paths must be ported BEFORE the CLI test file is dropped.
- **No write-path expansion in the dashboard.** README at line 111 establishes the dashboard as read-only monitoring; write paths go through CLI or MCP. Team D's HTML rewrites are content/copy only — no JS, CSS, or write-flow changes.
- **`finlet serve` (uvicorn API+dashboard server) is KEPT.** It powers prod EC2 (`systemctl restart finlet.service` per `[[feedback-finlet-systemd-unit-name]]`).
- **`finlet mcp serve` is KEPT.** Stdio entry point that MCP clients (Claude Desktop, Generic MCP Client, future Codex/Cursor integrations) spawn.
- **`finlet plugins` is KEPT.** Operator surface for local plugin filesystem management — REST-only (uses `_api_headers` at `finlet/cli.py:880, 904, 996, 1069`, NOT `_dispatch_mcp_tool`). The plugins commands consume `EXIT_AUTH_REQUIRED` (at cli.py:984, 1056) — see Team A scope for the alive-vs-dead distinction.
- **`finlet manual` is KEPT.** Local markdown topic viewer; useful offline; low maintenance burden.
- **`finlet auth login/logout/status` + `finlet register` are KEPT.** OAuth bootstrap flow; agents can't open browsers.
- **v2.0.0 PyPI release is the capstone deliverable.** PyPI publish workflow (`.github/workflows/pypi-publish.yml`) auto-publishes on `push.tags: ['v*']`.
- **Two-pass Codex review (Step 10a + 10b) is a hard gate** before exec-plan handoff. Both passes complete; handoff is v3.

## Canonical v2 onboarding script

Teams C and D MUST both depict this EXACT flow when rewriting examples. Diverging from this script creates the same parallel-narrative drift this whole migration is meant to eliminate. Step 10b STRONG-1: snippets are concrete (exact JSON / exact commands), not summarized.

### The flow

```text
1. pip install finlet              # gets v2.0.0+ from PyPI
2. finlet auth login               # browser OAuth bootstrap → ~/.finlet/credentials
3. Wire `finlet mcp serve` into your agent host:
   - Claude Desktop: add the JSON block below to claude_desktop_config.json
   - Codex CLI: run the codex command below
   - Generic MCP Client: use the JSON block below (it follows the MCP standard)
4. Open the agent host. Ask:
     "Create a session named 'my-first-sim' starting 2024-01-02 with $100,000
      capital and tickers AAPL, MSFT, GOOGL. Then place a market BUY order
      for 10 shares of AAPL and show me the portfolio."
5. The agent invokes the MCP tools (create_session, submit_order,
   get_portfolio) and reports back.
```

### Exact config snippets (use these verbatim — no paraphrasing)

**Claude Desktop** — add to `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) under `mcpServers`:

```json
{
  "mcpServers": {
    "finlet": {
      "command": "finlet",
      "args": ["mcp", "serve"]
    }
  }
}
```

**Codex CLI** — run from your terminal:

```sh
codex mcp add finlet -- finlet mcp serve
```

**Generic MCP Client (Cursor, Windsurf, custom)** — point your client at the stdio server with the same JSON schema:

```json
{
  "command": "finlet",
  "args": ["mcp", "serve"]
}
```

### Example agent prompt (use verbatim)

```text
Create a session named 'my-first-sim' starting 2024-01-02 with $100,000
capital and tickers AAPL, MSFT, GOOGL. Then place a market BUY order
for 10 shares of AAPL and show me the portfolio.
```

Team C bakes this into `finlet/manual/quickstart.md` as the primary quickstart. Team D bakes it into `dashboard/setup.html` and `dashboard/agent-guide.html` as the visual onboarding. README's quickstart section collapses to a pointer at this script.

## What's being dropped (12 commands + dead helpers)

| Command | File:Line | MCP equivalent |
|---|---|---|
| `finlet session create` | `finlet/cli.py:585` | `create_session` |
| `finlet session list` | `finlet/cli.py:630` | `list_sessions` |
| `finlet session delete` | `finlet/cli.py:652` | `delete_session` |
| `finlet session publish` | `finlet/cli.py:670` | `set_session_visibility` |
| `finlet benchmark start` | `finlet/cli.py:712` | `start_benchmark` |
| `finlet benchmark progress` | `finlet/cli.py:770` | `get_benchmark_progress` |
| `finlet benchmark decrypt` | `finlet/cli.py:795` | `decrypt_benchmark_run` |
| `finlet benchmark visibility` | `finlet/cli.py:820` | `set_benchmark_visibility` |
| `finlet advance` | `finlet/cli.py:1615` | `advance_time` |
| `finlet order` | `finlet/cli.py:1697` | `submit_order` |
| `finlet portfolio` | `finlet/cli.py:1788` | `get_portfolio` |
| `finlet status` | `finlet/cli.py:1884` | `get_session` |

### Dead helpers (Team A deletion scope)

The DEAD set — only consumed by `_dispatch_mcp_tool` or `_emit_envelope` (themselves dead):
- `_dispatch_mcp_tool` (`finlet/cli.py:386-433`)
- `_translate_mcp_error` (`finlet/cli.py:363-384`)
- `_emit_envelope` (`finlet/cli.py:436+`)
- `_resolve_bearer_token` (`finlet/cli.py:217`) — only live caller is `_dispatch_mcp_tool` at line 411
- `_AUTH_REQUIRED_MARKERS` and `_AUTH_REQUIRED_HINT` — only consumed by `_emit_envelope`
- `_AsyncioTimeoutError = asyncio.TimeoutError` alias (`finlet/cli.py:64`) — only used inside `_dispatch_mcp_tool` at line 422
- Top-level `import asyncio` (`finlet/cli.py:30`) — only consumer is the alias above
- `session_app` (`finlet/cli.py:516`) + `benchmark_app` (`finlet/cli.py:520-525`) sub-typer apps + their `app.add_typer(...)` registrations
- `_normalize_start_iso` (`finlet/cli.py:573`, verify dead in Team A)
- `finlet/cli_mcp_client.py` (entire file — only consumers are `cli.py:39`, `tests/test_cli.py:29`, `tests/api/test_cli_mcp_client.py`)

The ALIVE set — used by KEPT commands; **DO NOT delete** (Step 10b BLOCKER-1):
- `EXIT_AUTH_REQUIRED = 2` (`finlet/cli.py:45`) — consumed by `plugins_add` (`cli.py:984`), `plugins_remove` (`cli.py:1056`), and `auth_status` (per Codex Step 10b). Keep the constant; Team A's grep gate excludes it.

### Stale docs/comments in `finlet/cli.py` (Team A sweep)

After deletions, the following stale prose references deleted symbols and must be cleaned:
- **Module docstring at `finlet/cli.py:1-30`** (Step 10b NIT-3): describes "v1.0.1 (CLI MCP-over-HTTP) routes session / advance / order / portfolio / status through the cloud `/mcp` HTTP endpoint" — entirely stale after v2.0.0. Rewrite to describe the kept surface only.
- **Inline comment at `finlet/cli.py:1347`** (Step 10b NIT-1; clarified — it's an inline comment, not a docstring): references `_resolve_bearer_token` auto-refresh path. After deletion, remove the comment or rewrite to point at the live credential-write path inside `_write_credentials` itself.
- **Docstring/comment around `finlet/cli.py:1573`** (audit): may reference dispatch helpers.
- Any remaining references to `_dispatch_mcp_tool`, `_resolve_bearer_token`, `_AsyncioTimeoutError`, `_emit_envelope`, `_translate_mcp_error` in docstrings/comments.

## What's being kept

| Command | File:Line | Purpose |
|---|---|---|
| `finlet serve` | `finlet/cli.py:535-568` | uvicorn API+dashboard server (prod EC2) |
| `finlet mcp serve` | `finlet/cli.py:1927-2035` | stdio MCP server (MCP clients spawn this) |
| `finlet auth login` | `finlet/cli.py:1476` | OAuth 2.1 + PKCE browser bootstrap |
| `finlet auth logout` | `finlet/cli.py:1544` | clear `~/.finlet/credentials` |
| `finlet auth status` | `finlet/cli.py:1561` | report local credential state (uses `EXIT_AUTH_REQUIRED`) |
| `finlet register` | `finlet/cli.py:1102` | user signup |
| `finlet plugins list/add/remove` | `finlet/cli.py:881-1096` | REST plugin filesystem mgmt (uses `EXIT_AUTH_REQUIRED`) |
| `finlet manual` | `finlet/cli.py:2042-2156` | local markdown topic viewer |
| `finlet --version` | callback at `finlet/cli.py:468` | diagnostics |

---

## File Conflict Table

| File | Touched by Teams | Operation |
|---|---|---|
| `finlet/cli.py` | A | modify (heavy deletion + module docstring rewrite) |
| `finlet/cli_mcp_client.py` | A | delete |
| `tests/test_cli.py` | B | modify (trim) |
| `tests/test_cli_benchmark.py` | B | delete |
| `tests/test_cli_help.py` | B | modify (update snapshot) |
| `tests/api/test_cli_mcp_client.py` | B | delete |
| `tests/mcp/test_decrypt_visibility_tools.py` | B | modify (add 3 flag-semantics + 1 anti-shape-drift assertions) |
| `tests/mcp/*.py` (audit) | B | confirm coverage; modify only if gaps found |
| `finlet/manual/quickstart.md` | C | modify |
| `finlet/manual/client-matrix.md` | C | modify |
| `finlet/manual/session-lifecycle.md` | C | audit + maybe modify |
| `finlet/manual/registry.py` | C | **modify (Step 10b BLOCKER-2 — source of llms.txt topic summaries)** |
| `finlet/manual/generate_llms_txt.py` | C | **modify (Step 10b BLOCKER-2 — hardcoded llms.txt sections live here)** |
| `docs/ARCHITECTURE.md` | C | modify (CLI section) |
| `docs/PRIVACY_POLICY.md` | C | modify |
| `docs/launch/templates.md` | C | modify |
| `docs/decisions/v2-pure-mcp-migration.md` | C | new |
| `docs/decisions/cli-mcp-http-dispatch.md` | C | modify (mark Superseded) |
| `README.md` | C | rewrite quickstart + CLI reference sections |
| `dashboard/llms.txt` | C | regen via `python -m finlet.manual.generate_llms_txt --write` |
| `dashboard/index.html` | D | modify (rewrite CLI examples) |
| `dashboard/setup.html` | D | modify |
| `dashboard/agent-guide.html` | D | modify |
| `pyproject.toml` | E | modify (version bump) |
| `CHANGELOG.md` | E | modify (add [1.1.0] + [2.0.0], absorb [Unreleased]) |

**File conflict carve-out (Step 10a BLOCKER-1):** `dashboard/llms.txt` lives under `dashboard/` (Team D's broad ownership) but is GENERATED from `finlet/manual/registry.py` + hardcoded text in `finlet/manual/generate_llms_txt.py`. The file is not hand-editable; `.github/workflows/ci.yml:65-69` enforces drift via `python -m finlet.manual.generate_llms_txt --check`. **Team C owns the regen** because they own the source. Team D MUST NOT touch `dashboard/llms.txt` — only `dashboard/*.html`. No actual write conflict because they touch different files; the carve-out is for ownership clarity.

**llms.txt content source (Step 10b BLOCKER-2 correction):** The previous v2 spec said "Team C edits manuals → regens dashboard/llms.txt." That causality was wrong. The generator at `finlet/manual/generate_llms_txt.py:25` imports `from finlet.manual.registry import TOPIC_REGISTRY` and emits topic SUMMARIES + HARDCODED sections (Agent Instructions, API Endpoints, MCP transport recommendations). Editing manual `.md` bodies does NOT change llms.txt content. Team C must edit `registry.py` topic descriptions AND/OR `generate_llms_txt.py` hardcoded sections to fix llms.txt MCP-first.

---

## Dependency Graph

- **Team A** (CLI surgery + module-docstring rewrite) — independent → can start immediately.
- **Team B** (test cleanup + 4 new MCP-side assertions) — blocked by A (test files import from modules A deletes).
- **Team C** (server-side docs + manual registry + generator + README + llms.txt regen) — independent → parallel with A, B, D. Must reference the Canonical v2 onboarding script.
- **Team D** (dashboard frontend HTML) — independent → parallel with A, B, C. Must reference the Canonical v2 onboarding script.
- **Team E** (version bump + CHANGELOG repair) — blocked by A, B, C, D (capstone).

```
A ──┬─→ B ─────────────┐
    │                  │
    └─→ (parallel) ─→  E
C ──────────────────→  E
D ──────────────────→  E
```

## Critical Path

**A → B → E** (three sequential merges minimum). C and D parallelize against the A→B chain.

---

## Teams

### Team A: CLI surgery — delete dropped commands + dead helpers + rewrite module docstring

**Blocked by:** none — can start immediately.

**Read these files first:**
- `finlet/cli.py:1-30` — module docstring (will be rewritten — describes deleted v1.0.1 dispatch model)
- `finlet/cli.py:30-70` — imports (`asyncio` at line 30, `_AsyncioTimeoutError` at line 64 — both dead) and `EXIT_AUTH_REQUIRED` at line 45 (ALIVE — keep)
- `finlet/cli.py:217-260` — `_resolve_bearer_token` (dead-after-deletion)
- `finlet/cli.py:386-466` — `_dispatch_mcp_tool` + envelope plumbing (all dead)
- `finlet/cli.py:491-530` — Typer app init + sub-typer registrations
- `finlet/cli.py:535-568` — `finlet serve` command (KEEP)
- `finlet/cli.py:881-1096` — plugins commands (KEEP; use `EXIT_AUTH_REQUIRED` at 984, 1056)
- `finlet/cli.py:1340-1360` — inline comment at line 1347 references `_resolve_bearer_token` auto-refresh (stale after deletion; this is an inline comment, NOT a docstring per Step 10b NIT-1)
- `finlet/cli.py:1561-1610` — `auth status` command (KEEP; uses `EXIT_AUTH_REQUIRED`)
- `finlet/cli.py:1565-1580` — docstring/comment around 1573 (audit for dispatch refs)
- `finlet/cli.py:1927-2035` — `finlet mcp serve` command (KEEP)
- `finlet/cli_mcp_client.py` — entire file (to be deleted)
- `docs/decisions/cli-mcp-http-dispatch.md` — current transport contract (Team C marks Superseded)

**Recon evidence (verified against HEAD `fb2637c`):**

The 13 `_dispatch_mcp_tool(...)` call sites are all in the dropped commands:

```text finlet/cli.py callers of _dispatch_mcp_tool
386:def _dispatch_mcp_tool(...)
610:    envelope = _dispatch_mcp_tool("create_session", args, api_key=api_key)
637:    envelope = _dispatch_mcp_tool("list_sessions", {}, api_key=api_key)
660:    envelope = _dispatch_mcp_tool(...)  # delete_session
698:    envelope = _dispatch_mcp_tool("set_session_visibility", args, api_key=api_key)
758:    envelope = _dispatch_mcp_tool("start_benchmark", args, api_key=api_key)
781:    envelope = _dispatch_mcp_tool("get_benchmark_progress", {}, api_key=api_key)
811:    envelope = _dispatch_mcp_tool("decrypt_benchmark_run", args, api_key=api_key)
854:    envelope = _dispatch_mcp_tool("set_benchmark_visibility", args, api_key=api_key)
1677:   envelope = _dispatch_mcp_tool("advance_time", args, api_key=api_key)
1771:   envelope = _dispatch_mcp_tool("submit_order", args, api_key=api_key)
1809:   envelope = _dispatch_mcp_tool(...)  # get_portfolio
1903:   envelope = _dispatch_mcp_tool(...)  # get_session (status command)
```

`EXIT_AUTH_REQUIRED` is ALIVE — verified against HEAD `fb2637c`:

```text grep -nE "EXIT_AUTH_REQUIRED" finlet/cli.py
45:EXIT_AUTH_REQUIRED = 2
448:    :data:`EXIT_AUTH_REQUIRED` (2) so shell scripts can distinguish  ← inside _emit_envelope docstring (dead)
461:        exit_code = EXIT_AUTH_REQUIRED if is_auth_failure else on_error_exit  ← inside _emit_envelope (dead)
984:        raise typer.Exit(2)   ← plugins_add (KEPT; should use EXIT_AUTH_REQUIRED but raises literal 2)
1056:       raise typer.Exit(2)   ← plugins_remove (KEPT; same)
```

Codex Step 10b also identified `auth_status` (cli.py:1561-1610) as raising `EXIT_AUTH_REQUIRED`. The constant has live consumers and MUST stay.

`_resolve_bearer_token` callers (verified against HEAD `fb2637c`):

```text finlet/cli.py callers of _resolve_bearer_token
217:def _resolve_bearer_token(api_key: str | None) -> str | None:
411:    bearer = _resolve_bearer_token(api_key)                                ← inside _dispatch_mcp_tool (dies)
1347:        # auto-refresh path in :func:`_resolve_bearer_token` to rotate    ← stale inline comment in auth_login
```

After deleting `_dispatch_mcp_tool` (which owns the only live call at 411), `_resolve_bearer_token` has zero live callers. The reference at `cli.py:1347` is an inline comment (NOT a docstring per Step 10b NIT-1) — Team A removes the comment OR rewrites it to point at the live credential-write path in `_write_credentials`.

`_AsyncioTimeoutError` + top-level `asyncio` (verified against HEAD `fb2637c`):

```text finlet/cli.py
30:import asyncio
64:_AsyncioTimeoutError = asyncio.TimeoutError
422:    except (TimeoutError, _AsyncioTimeoutError) as exc:  ← inside _dispatch_mcp_tool
```

Only consumer is `_dispatch_mcp_tool`'s timeout handler. Delete the alias AND the top-level import.

Module docstring at `finlet/cli.py:1-30` (verified against HEAD `fb2637c`):

```text finlet/cli.py:1-30
1:"""CLI entrypoint — finlet serve / session / plugins / mcp.
3:v1.0.1 (CLI MCP-over-HTTP) routes session / advance / order /
4:portfolio / status through the cloud ``/mcp`` HTTP endpoint via
5:``mcp.client.streamable_http.streamablehttp_client``.  See
6:``docs/decisions/cli-mcp-http-dispatch.md`` for the dispatch contract.
```

This describes a command surface that no longer exists. Rewrite to describe the v2.0.0 kept surface (serve, register, auth, plugins, mcp serve, manual).

`finlet/cli_mcp_client.py` is imported only by:

```text grep -rn "from finlet.cli_mcp_client"
finlet/cli.py:39:from finlet.cli_mcp_client import MCPDispatchError, call_tool_sync
tests/test_cli.py:29:from finlet.cli_mcp_client import MCPDispatchError
tests/api/test_cli_mcp_client.py:26:from finlet.cli_mcp_client import (...)
```

`cli.py:39` import dies with the dispatch helper; the test files are Team B's responsibility. Safe to delete.

**Files touched:**
- Modified: `finlet/cli.py`:
  - **Rewrite module docstring (lines 1-30)** to describe v2.0.0 surface: serve, register, auth login/logout/status, plugins list/add/remove, mcp serve, manual. Mention `finlet/cli.py` is the typer entry point. No mention of session/order/portfolio/etc.
  - Delete commands at lines 584-706 (session sub-app commands), 711-864 (benchmark sub-app commands), 1614-1691 (advance), 1696-1782 (order), 1787-1878 (portfolio), 1883-1921 (status).
  - Delete dead helpers: `_dispatch_mcp_tool` (386-433), `_translate_mcp_error` (363-384), `_emit_envelope` (~436), `_AUTH_REQUIRED_MARKERS`, `_AUTH_REQUIRED_HINT`, `_resolve_bearer_token` (217), `_AsyncioTimeoutError` alias (64), top-level `import asyncio` (30), `_normalize_start_iso` (~573, verify dead).
  - **DO NOT delete `EXIT_AUTH_REQUIRED` (line 45)** — alive, used by `plugins_add` (984), `plugins_remove` (1056), `auth_status` (1598+). Note that `plugins_add` and `plugins_remove` currently raise the literal `2` (`raise typer.Exit(2)`); they should ideally use `EXIT_AUTH_REQUIRED` for clarity but that's beyond v2.0.0 scope — leave as-is.
  - Delete sub-typer `session_app` (516) + `benchmark_app` (520-525) + their `app.add_typer(...)` lines.
  - Delete the `from finlet.cli_mcp_client import ...` import (line 39).
  - Clean stale inline comment at `cli.py:1347` (referencing `_resolve_bearer_token` auto-refresh — the function won't exist after deletion). Either remove the comment or rewrite to point at `_write_credentials` directly.
  - Audit `cli.py:1573` and surrounding for similar stale refs.
- Deleted: `finlet/cli_mcp_client.py` (entire file).

**Deliverable:** After this team finishes, `finlet --help` shows ONLY: `serve`, `mcp` (with sub-command `serve`), `auth` (with `login`/`logout`/`status`), `register`, `plugins` (with `list`/`add`/`remove`), `manual`, `--version`. No `session`, `benchmark`, `advance`, `order`, `portfolio`, or `status` commands. The DEAD set is gone; the ALIVE set (`EXIT_AUTH_REQUIRED`) remains. Module docstring describes v2.0.0 surface only.

**Validation:**
- [ ] `python -c "import finlet.cli; from finlet.cli import app"` succeeds (no import errors).
- [ ] `python -m finlet.cli --help 2>&1 | grep -E '^\s+(session|benchmark|advance|order|portfolio|status)\b'` returns nothing.
- [ ] `python -m finlet.cli --help 2>&1 | grep -E '^\s+(serve|mcp|auth|register|plugins|manual)\b'` returns all 6 expected commands.
- [ ] `python -m finlet.cli mcp serve --help` exits 0.
- [ ] `grep -rn "from finlet.cli_mcp_client" finlet/` returns nothing.
- [ ] `grep -nE "_dispatch_mcp_tool|_resolve_bearer_token|_AsyncioTimeoutError|_AUTH_REQUIRED_MARKERS|_AUTH_REQUIRED_HINT|_emit_envelope|_translate_mcp_error" finlet/cli.py` returns nothing.
- [ ] `grep -nE "^import asyncio|^from asyncio" finlet/cli.py` returns nothing.
- [ ] `grep -nE "EXIT_AUTH_REQUIRED" finlet/cli.py` returns the definition at line ~45 + ≥3 consumer usages (KEPT — alive).
- [ ] `grep -nE "v1\\.0\\.1|MCP-over-HTTP|MCP-dispatched|dispatch contract" finlet/cli.py` returns nothing (module docstring is rewritten).
- [ ] `ruff check finlet/cli.py` passes.
- [ ] `git status` shows `finlet/cli.py` modified, `finlet/cli_mcp_client.py` deleted.

**Agent instructions:**
- You MUST `git add finlet/cli.py` and `git rm finlet/cli_mcp_client.py` and `git commit` before finishing.
- After deletion, run `ruff check finlet/` and remove any newly-unused imports.
- After deletion, grep for orphan refs to deleted symbols and clean stale docstrings/comments — including the module docstring (lines 1-30) and the inline comment at line 1347.
- **Do NOT delete `EXIT_AUTH_REQUIRED`.** It's alive. Verify with `grep -c "EXIT_AUTH_REQUIRED" finlet/cli.py` — should be ≥4 (definition + ≥3 consumers).
- Do NOT modify ANY MCP tool source files (`finlet/mcp/`).
- Do NOT touch `tests/` — that's Team B's lane.
- Do NOT touch docs or `dashboard/llms.txt` — that's Team C's lane.
- Do NOT touch `dashboard/*.html` — that's Team D's lane.
- Commit message: `[Team A v2.0.0]: delete CLI convenience commands + dead helpers; rewrite module docstring`.

---

### Team B: Test cleanup — trim CLI tests + 4 named MCP-side assertions on session_visibility

**Blocked by:** Team A (Team A's deletion of `_dispatch_mcp_tool` and `finlet/cli_mcp_client.py` makes Team B's existing test imports fail).

**Read these files first:**
- `tests/test_cli.py:1-50` — imports (`from finlet.cli_mcp_client import MCPDispatchError` at line 29 will be invalid after A)
- `tests/test_cli.py` (full file, 2131 lines) — enumerate test classes
- `tests/test_cli.py:441-505` — `session_publish` flag-mapping tests (`test_session_publish_dispatches_set_session_visibility_tool`, `test_session_publish_attributed_flag`, `test_session_publish_unpublish_flag`)
- `tests/test_cli_benchmark.py` (204 lines) — 3 test classes (`TestBenchmarkCLIHelp`, `TestBenchmarkStartDispatch`, `TestBenchmarkProgressDispatch`) all test dropped commands → delete entirely
- `tests/test_cli_help.py` (102 lines) — help-text snapshot; update to reflect new command surface
- `tests/test_cli_oauth_login.py` (507 lines) — OAuth flow tests; KEEP unmodified
- `tests/api/test_cli_mcp_client.py` — tests `cli_mcp_client.py` which Team A deleted → delete entirely
- `tests/mcp/test_create_session_blind.py:147` — blind create output (KEEP)
- `tests/mcp/test_start_benchmark_blind.py:188` — benchmark blind (KEEP)
- `tests/mcp/test_submit_order_validation.py:124` — submit_order input validation (KEEP)
- `tests/mcp/test_concurrency.py:156` — advance_time concurrency (KEEP)
- `tests/mcp/test_decrypt_visibility_tools.py:226` — benchmark visibility (will be augmented by Team B for session visibility)
- `tests/mcp/test_session_lifecycle_blind.py:288` — session lifecycle blind output (KEEP)
- `finlet/mcp/tools_session.py:43-105` — `set_session_visibility` MCP tool (read to confirm: `public: bool`, `anonymous: bool = True` are INPUT params)
- `finlet/api/schemas/session.py:79-101` — `SessionResponse` schema; the OUTPUT field is `public_anonymous: bool` (line 101), NOT `anonymous` (Step 10b BLOCKER-3)
- `finlet/api/services/session_service.py:133-198` — `set_visibility` service-layer implementation; persists `public_anonymous` distinctly

**Recon evidence (verified against HEAD `fb2637c`):**

```text tests/test_cli_benchmark.py classes
class TestBenchmarkCLIHelp:
class TestBenchmarkStartDispatch:
class TestBenchmarkProgressDispatch:
```

All three exercise the benchmark CLI commands Team A is deleting. File-level delete.

`tests/test_cli.py:29`:

```python tests/test_cli.py:29
from finlet.cli_mcp_client import MCPDispatchError
```

After Team A merges, this `ImportError`s and pytest collection fails. Team B trims the file.

`set_session_visibility` MCP tool INPUT params at `finlet/mcp/tools_session.py:43-48`:

```python finlet/mcp/tools_session.py:43-48
43  async def set_session_visibility(
44      ...
45      session_id: str,
47      public: bool,
48      anonymous: bool = True,
```

`SessionResponse` OUTPUT schema at `finlet/api/schemas/session.py:79-101` (Step 10b BLOCKER-3):

```python finlet/api/schemas/session.py
79  class SessionResponse(BaseModel):
        ...
100     public: bool = False
101     public_anonymous: bool = True   ← OUTPUT field is `public_anonymous`, NOT `anonymous`
```

CLI behavior of `--unpublish` at `finlet/cli.py:692`:

```python finlet/cli.py:670-705 (excerpted)
670  def session_publish(...):
        ...
692      if unpublish:
            # CLI always passes anonymous=True on --unpublish (preserves anonymity preference)
            args = {"session_id": session_id, "public": False, "anonymous": True}
```

So the CLI's `--unpublish` always passed `anonymous=True`; MCP tests must assert this is preserved.

(verified by recon agent against HEAD `fb2637c` via inline reads of cli.py:669-706, test_cli.py:441-497, tools_session.py:43-50, schemas/session.py:79-105, services/session_service.py:133-198)

**Files touched:**
- Modified: `tests/test_cli.py` — trim to only kept-command tests. KEEP: auth login/logout/status tests, register tests, plugins list/add/remove tests, manual tests, mcp serve smoke tests, root callback + version callback tests, generic CLI behaviors. DELETE: session_create/list/delete/publish tests, advance/order/portfolio/status tests, the `from finlet.cli_mcp_client import MCPDispatchError` import (line 29), any test referencing dropped symbols.
- Deleted: `tests/test_cli_benchmark.py` (use `git rm`).
- Modified: `tests/test_cli_help.py` — update help-text snapshot to reflect new command surface.
- Deleted: `tests/api/test_cli_mcp_client.py` (use `git rm`).
- Modified: `tests/mcp/test_decrypt_visibility_tools.py` — add 4 explicit assertions for `set_session_visibility` (Step 10b BLOCKER-3 — correct schema keys):
  1. `set_session_visibility(public=True, anonymous=True)` → `result["public"] == True` AND `result["public_anonymous"] == True`.
  2. `set_session_visibility(public=True, anonymous=False)` → `result["public"] == True` AND `result["public_anonymous"] == False` (attributed flow).
  3. `set_session_visibility(public=False, anonymous=True)` → `result["public"] == False` AND `result["public_anonymous"] == True` (unpublish flow; CLI always passed anonymous=True per cli.py:692).
  4. Anti-shape-drift: assert `"share_url" not in result` (consumer derives URL as `https://finlet.dev/sessions/{id}`; tool shape must NOT silently add this field).
- Modified (audit only): `tests/mcp/test_create_session_blind.py`, `tests/mcp/test_start_benchmark_blind.py`, `tests/mcp/test_submit_order_validation.py`, `tests/mcp/test_concurrency.py`, `tests/mcp/test_session_lifecycle_blind.py` — confirm coverage; no edits required unless gaps surface.

**Test fixture hygiene (Step 10b STRONG-3):** Any new test fixture for OAuth tokens / api_keys / session IDs MUST use obviously fake values matching the existing pattern in `tests/mcp/`:
- JWTs: `header.payload.signature` (3 dots, not realistic `eyJ...` base64)
- API keys: `fnlt_test_key_<short>` (NEVER realistic `fnlt_<32hex>`)
- Session IDs: `test-session-001` or `aaaaaaaaaaaaaa` (NEVER realistic UUID-shaped 12-char hex)

This protects gitleaks scanning (see `[[feedback-doc-examples-must-be-low-entropy]]`).

**Deliverable:** After this team finishes, `pytest tests/ -x` passes. No coverage regressions. CLI test files contain ONLY tests for kept commands. Explicit MCP-side coverage exists for `set_session_visibility` with correct schema keys (`public_anonymous`, not `anonymous`).

**Validation:**
- [ ] `pytest tests/test_cli.py -x` passes (no `ImportError`).
- [ ] `pytest tests/test_cli_help.py -x` passes (snapshot updated).
- [ ] `pytest tests/test_cli_oauth_login.py -x` passes (unmodified).
- [ ] `pytest tests/mcp/test_decrypt_visibility_tools.py -x` passes with the 4 new assertions; grep test body for `result["public_anonymous"]` ≥3 times AND `"share_url" not in result` ≥1 time.
- [ ] `pytest tests/mcp/ -x` passes.
- [ ] `pytest tests/ -x --ignore=tests/e2e --ignore=tests/playwright` passes end-to-end.
- [ ] `grep -rE 'eyJ[A-Za-z0-9_-]{20,}|fnlt_[a-f0-9]{32}' tests/mcp/test_decrypt_visibility_tools.py` returns nothing (no realistic-looking secrets in new fixtures).
- [ ] `git status` shows 2 deletions + 3-4 modifications.

**Agent instructions:**
- You MUST `git add` (+ `git rm` for deletions) and `git commit` before finishing.
- New MCP-side assertions MUST use `result["public_anonymous"]` (the actual response schema field), NOT `result["anonymous"]` (the INPUT param name). Verify by reading `finlet/api/schemas/session.py:79-101` before writing assertions.
- New test fixtures MUST use obviously-fake values (see "Test fixture hygiene" above). DO NOT use realistic `eyJ...` JWTs or `fnlt_<32hex>` api_keys.
- Do NOT modify `finlet/` source — Team A's lane.
- Do NOT modify `finlet/mcp/` tools — strict no-shape-change rule.
- Commit message: `[Team B v2.0.0]: trim CLI tests; add 4 MCP assertions on set_session_visibility (public + public_anonymous + no-share-url)`.

---

### Team C: Server-side docs + manual registry + generator + README + llms.txt regen

**Blocked by:** none — independent. Can run parallel with A, B, D.

**Coordination requirement:** Team C and Team D both rewrite onboarding narratives. BOTH MUST use the "Canonical v2 onboarding script" section of this plan as the source of truth. Specifically: the JSON snippets, the Codex CLI command, and the example agent prompt are VERBATIM. No paraphrasing.

**Read these files first:**
- The "Canonical v2 onboarding script" section above (use as source of truth)
- `finlet/manual/quickstart.md` — references `finlet session create` (line 41), `finlet session advance` (line 55), `finlet trade order` (line 56), `finlet portfolio` (line 57)
- `finlet/manual/client-matrix.md` — references `finlet session create` (line 68)
- `finlet/manual/session-lifecycle.md` — audit for CLI refs
- `finlet/manual/generate_llms_txt.py` (Step 10b BLOCKER-2 — full file, ~210 lines): the generator imports `TOPIC_REGISTRY` from `finlet/manual/registry.py:25` and emits hardcoded sections including "## Agent Instructions" and the stdio config snippet. **The hardcoded text inside this file IS Team C's surface.** Specifically look at the hardcoded MCP-over-HTTP recommendations and `FINLET_API_KEY` references that need MCP-first language.
- `finlet/manual/registry.py` (Step 10b BLOCKER-2 — full file): `TOPIC_REGISTRY` is a dict of topic metadata (title, summary, url). The `summary` field is what shows up in `dashboard/llms.txt`. Update topic summaries to MCP-first language where they currently mention CLI commands.
- `dashboard/llms.txt` (current state — read to see what's there now): has hardcoded sections like "Start with the hosted MCP-over-HTTP path", `fnlt_<key>` references, `FINLET_API_KEY` env var. These all come from `generate_llms_txt.py` hardcoded text, NOT manual `.md` files.
- `docs/ARCHITECTURE.md:1104-1116, 1870-1871, 1017, 1803, 137`
- `docs/PRIVACY_POLICY.md:332, 334, 336`
- `docs/launch/templates.md:53`
- `docs/decisions/cli-mcp-http-dispatch.md` — current dispatch contract (to be Superseded)
- `docs/decisions/cli-mcp-stdio-auth.md` — already Superseded at top per Step 10b NIT-2 (audit only)
- `docs/decisions/` directory — read 2-3 existing decision records to internalize house style
- `README.md:78-110, 348-360` — quickstart + CLI reference sections with live dropped-command examples
- `.github/workflows/ci.yml:65-69` — llms.txt drift gate

**Recon evidence (verified against HEAD `fb2637c`):**

`finlet/manual/quickstart.md` contains four dropped-command references:

```text grep finlet/manual/quickstart.md
41:finlet session create \
55:finlet session advance --steps 1
56:finlet trade order --ticker AAPL --side BUY --qty 100 --type MARKET
57:finlet portfolio
```

The `finlet trade order` at line 56 is a GHOST command — `finlet trade` was never real (historical closure in `docs/REMAINING_TASKS.md:546`).

`README.md` contains live dropped-command examples at lines 85, 92, 100, 352, 357. README is the PyPI package readme (`readme = "README.md"` in pyproject.toml).

`generate_llms_txt.py:25` imports from registry (Step 10b BLOCKER-2):

```python finlet/manual/generate_llms_txt.py:25
25  from finlet.manual.registry import TOPIC_REGISTRY
```

`dashboard/llms.txt` current "Agent Instructions" section (excerpt):

```text dashboard/llms.txt (current)
## Agent Instructions
- Start with the hosted MCP-over-HTTP path — `https://finlet.dev/mcp` with OAuth Bearer.
- Default REST API base: https://finlet.dev/v1
- MCP transport accepts OAuth Bearer ... or api_key Bearer ... (dual-accept compat).
- ...
- Stdio fallback: `{"command": "finlet", "args": ["mcp", "serve"]}` with `FINLET_API_KEY` in env
```

This text lives in `generate_llms_txt.py` (hardcoded) and references the v1.x model where the CLI dispatched via cloud MCP-over-HTTP. After v2.0.0, this is wrong on multiple levels: dual-accept api_key path was sunset (per `[[project-mcp-first-phase4_shipped]]`), stdio is the PRIMARY (not fallback) path for agent integration, and `FINLET_API_KEY` is not the recommended auth path (OAuth Bearer is).

`docs/decisions/cli-mcp-stdio-auth.md:1` (Step 10b NIT-2):

```text docs/decisions/cli-mcp-stdio-auth.md:1
1: Status: Superseded by docs/decisions/cli-mcp-http-dispatch.md (...)
```

Already Superseded — Team C's audit step finds this and leaves it alone.

(verified by recon agent against HEAD `fb2637c` via inline reads of generate_llms_txt.py, registry.py, llms.txt, decisions/cli-mcp-stdio-auth.md)

**Files touched:**
- Modified: `finlet/manual/quickstart.md` — rewrite to depict the Canonical v2 onboarding script. Drop the `finlet session create`/`session advance`/`trade order`/`portfolio` CLI examples. Show the exact MCP client config snippets + example agent prompt from the script.
- Modified: `finlet/manual/client-matrix.md` — replace line 68 with the Canonical script's config snippets (Claude Desktop JSON + Codex CLI command + Generic JSON).
- Modified (audit): `finlet/manual/session-lifecycle.md` — rewrite any CLI refs.
- **Modified: `finlet/manual/registry.py`** (Step 10b BLOCKER-2): update topic summaries to MCP-first language. Specifically: `quickstart` summary currently says "Five-step copy-paste setup: install, register, login, create session, trade." → rewrite as "Five-step MCP-first setup: install, register, login, wire MCP client into your agent host, dialog with the agent." Similarly for `session-lifecycle`, `client-matrix`, `transports`.
- **Modified: `finlet/manual/generate_llms_txt.py`** (Step 10b BLOCKER-2): rewrite the hardcoded sections — specifically the "Agent Instructions" block at the end. Lead with `finlet mcp serve` stdio path as the PRIMARY way to integrate; remove or de-emphasize the `https://finlet.dev/mcp` hosted-HTTP recommendation (hosted HTTP is still available for direct REST consumers but is no longer the default agent-onboarding path); remove `FINLET_API_KEY` from the recommended quickstart (it stays as a fallback for CI/headless per `mcp serve` docstring but is not the lede).
- Modified: `docs/ARCHITECTURE.md` — collapse CLI surface section (1104-1116) to only kept commands. Update visibility refs (137), batch-advance (1017), blind activation (1803), benchmark surface table (1870-1871). Lead with MCP tool + REST endpoint; remove CLI mentions.
- Modified: `docs/PRIVACY_POLICY.md` — rewrite lines 332/334/336 to lead with `set_session_visibility` MCP tool + REST endpoint. Document consumer-side share URL derivation: `https://finlet.dev/sessions/{id}`.
- Modified: `docs/launch/templates.md:53` — rewrite to depict the Canonical v2 onboarding script.
- Modified: `README.md` — rewrite quickstart (lines 78-110) and CLI reference (lines 348-360) to match the Canonical script. README ships to PyPI as the package readme.
- New: `docs/decisions/v2-pure-mcp-migration.md` — decision record. Match house style. Include: motivation, scope (kept vs dropped), migration notes (zero PyPI consumers per `[[project-pre-launch-no-customers]]`), consumer-side share-URL derivation.
- Modified: `docs/decisions/cli-mcp-http-dispatch.md` — add `Status: Superseded by docs/decisions/v2-pure-mcp-migration.md (2026-05-22)` annotation at top.
- Regenerated: `dashboard/llms.txt` — after editing registry.py + generate_llms_txt.py, run `python -m finlet.manual.generate_llms_txt --write` to regen. Verify with `--check` (exit 0). Commit the regen alongside the source edits.

**Deliverable:** After this team finishes:
- `grep -rnE 'finlet (session|benchmark|order|portfolio|status|advance|trade)( |$)' docs/ARCHITECTURE.md docs/PRIVACY_POLICY.md docs/launch/templates.md finlet/manual/ README.md` returns no hits.
- `python -m finlet.manual.generate_llms_txt --check` exits 0.
- `dashboard/llms.txt` "Agent Instructions" section reflects MCP-first onboarding (stdio primary, no `FINLET_API_KEY` lede).
- All operational documentation references the Canonical v2 onboarding script.
- `docs/decisions/v2-pure-mcp-migration.md` exists.

**Validation:**
- [ ] `grep -rnE 'finlet (session|benchmark|order|portfolio|status|advance|trade)( |$)' docs/ARCHITECTURE.md docs/PRIVACY_POLICY.md docs/launch/templates.md finlet/manual/ README.md` returns no hits (forensic snapshots in `docs/REMAINING_TASKS.md`, `docs/LESSONS.md`, `docs/brainstorms/`, `docs/launch/blind-agent-coldstart-report-*.md` are out of scope).
- [ ] `python -m finlet.manual.generate_llms_txt --check` exits 0.
- [ ] `grep -E "FINLET_API_KEY|hosted MCP-over-HTTP" dashboard/llms.txt` shows minimal mentions (no longer the lede; api_key remains documented as CI fallback).
- [ ] `grep -E '"command": "finlet", "args": \["mcp", "serve"\]' dashboard/llms.txt` finds the stdio config snippet (now primary).
- [ ] `docs/decisions/v2-pure-mcp-migration.md` exists and matches `docs/decisions/cli-mcp-http-dispatch.md` style.
- [ ] `docs/decisions/cli-mcp-http-dispatch.md` has `Status: Superseded by ...` line at top.
- [ ] After Team A merges, `python -m finlet.cli manual quickstart` renders cleanly.
- [ ] `git status` includes `dashboard/llms.txt` as a modified file (regen output).
- [ ] **Cross-surface narrative check (Step 10b STRONG-4):** the JSON snippet in `finlet/manual/quickstart.md` matches the JSON snippet in `dashboard/setup.html` (Team D's output) verbatim — same indentation, same key order. Spot-check by `diff <(grep -A4 'claude_desktop_config' finlet/manual/quickstart.md) <(grep -A4 'claude_desktop_config' dashboard/setup.html)`.

**Agent instructions:**
- You MUST `git add` and `git commit` before finishing.
- Both your rewrites and Team D's MUST depict the Canonical v2 onboarding script VERBATIM — no paraphrasing of JSON snippets, the Codex command, or the example agent prompt.
- For `docs/PRIVACY_POLICY.md`: user-facing legal text — preserve behavioral claims.
- For `docs/decisions/v2-pure-mcp-migration.md`: read 2-3 existing decision records first.
- For `finlet/manual/quickstart.md`: bundled in the wheel; rewrite as "agent-first" per the Canonical script.
- For `README.md`: PyPI readme; quality bar is high.
- **For `finlet/manual/generate_llms_txt.py`**: this is Python code, not Markdown. Edit the hardcoded strings carefully. Run `python -m finlet.manual.generate_llms_txt --write` after edits to verify output is what you intended.
- **For `finlet/manual/registry.py`**: update topic `summary` strings to MCP-first language. Don't reorder topics.
- After editing registry.py + generate_llms_txt.py, RUN `python -m finlet.manual.generate_llms_txt --write` to regen `dashboard/llms.txt`. Commit the regen alongside the source edits. CI's `--check` gate will fail otherwise.
- Do NOT modify `finlet/cli.py` or any source outside `finlet/manual/` — that was Team A's lane.
- Do NOT modify `tests/` — Team B's lane.
- Do NOT modify `dashboard/*.html` — Team D's lane. ONLY `dashboard/llms.txt` (which is regen output you own).
- Do NOT modify `pyproject.toml` or `CHANGELOG.md` — Team E's lane (capstone).
- Commit message: `[Team C v2.0.0]: rewrite manual + registry + generator + docs + README for MCP-first; regen dashboard/llms.txt`.

---

### Team D: Dashboard frontend rewrite (HTML content + data-copy attributes only)

**Blocked by:** none — independent. Can run parallel with A, B, C.

**Coordination requirement:** Team D and Team C both rewrite onboarding narratives. BOTH MUST use the "Canonical v2 onboarding script" section of this plan as the source of truth. The JSON snippets, the Codex CLI command, and the example agent prompt are VERBATIM — no paraphrasing.

**Read these files first:**
- The "Canonical v2 onboarding script" section above (use as source of truth)
- `dashboard/index.html:91, 105` — landing page "first run" hint
- `dashboard/setup.html:228, 233, 284` — onboarding setup with copy-button + REST-CLI example
- `dashboard/setup.html:37` — explicit reference to the manual as source of truth (narrative-coupling point — Team C is writing that manual)
- `dashboard/agent-guide.html:876, 881, 903, 908` — agent-guide blocks with copy-buttons
- `README.md:111` — establishes dashboard as read-only monitoring (confirms copy/text-only constraint)
- `dashboard/setup.html` full file — search for any `<button class="btn-copy"` elements to understand how `data-copy` attributes are read by inline JS (do NOT modify the JS; just understand it so HTML escaping is correct)

**Recon evidence (verified against HEAD `fb2637c`):**

Same as v2 — 9 lines across `dashboard/index.html`, `dashboard/setup.html`, `dashboard/agent-guide.html` containing CLI examples.

**HTML attribute escaping (Step 10b STRONG-2):** `data-copy` attributes are used by inline JS to populate the clipboard. The Canonical agent-prompt example contains single quotes around `'my-first-sim'`. The existing `data-copy` attributes in the codebase use SINGLE quotes (`data-copy='...'`) so embedded single quotes WILL break the attribute parsing. v3 requires either:
- Switching the new `data-copy` attributes to DOUBLE quotes (`data-copy="..."`) so single-quoted prompt content embeds cleanly, OR
- HTML-escaping single quotes inside the data-copy value as `&#39;`.

Recommended: double-quote attributes + use double-quoted JSON inside (since the Claude Desktop JSON uses double quotes — single quotes only appear in the agent prompt example, which is rendered as plain text not JSON).

**Files touched:**
- Modified: `dashboard/index.html` — replace lines 91, 105 with MCP-shaped examples from the Canonical v2 onboarding script. Keep layout/CSS/JS unchanged. Only swap inner content of `<code>` and `<p class="first-run-hint">` blocks.
- Modified: `dashboard/setup.html` — replace lines 228 (data-copy attribute), 233 (`<pre><code>` block), 284 (CLI example paragraph) with content from the Canonical script. Preserve `<button class="btn-copy">` structure; only swap `data-copy` attribute values + `aria-label`s + visible code-block text.
- Modified: `dashboard/agent-guide.html` — replace lines 876 (data-copy), 881 (code block), 903 (data-copy), 908 (code block) with Canonical-script content. Same constraints.

**Deliverable:** Dashboard pages contain ZERO references to `finlet session create`, `finlet order`, `finlet portfolio`, etc. Onboarding flow guides users through the Canonical v2 onboarding script — identical narrative to `finlet/manual/quickstart.md` (Team C's output).

**Validation:**
- [ ] `grep -rnE 'finlet (session|benchmark|order|portfolio|status|advance|trade)( |$)' dashboard/*.html` returns no hits.
- [ ] `dashboard/index.html`, `dashboard/setup.html`, `dashboard/agent-guide.html` each open in a browser without broken layout.
- [ ] **Copy-button smoke test (Step 10b STRONG-2):** Open `dashboard/setup.html` in a browser, click each `<button class="btn-copy">` element, paste clipboard content into a text editor. Verify pasted content matches the visible `<code>` block EXACTLY — no truncation from broken HTML attribute parsing, no `&quot;` artifacts in the paste, no extra whitespace.
- [ ] `python3 -c "from html.parser import HTMLParser; HTMLParser().feed(open('dashboard/setup.html').read())"` parses without errors (catches malformed HTML attribute escaping).
- [ ] `git diff dashboard/*.html` shows replaced code-block content + data-copy/aria-label updates — no JS/CSS/structural HTML changes.
- [ ] `git status` shows ONLY `dashboard/*.html` modified by Team D (not `dashboard/llms.txt`).
- [ ] **Cross-surface narrative check:** the Claude Desktop JSON snippet in `dashboard/setup.html` matches the snippet in `finlet/manual/quickstart.md` (Team C) verbatim.

**Agent instructions:**
- You MUST `git add` and `git commit` before finishing.
- **Copy/text + data-copy attributes only.** No JS/CSS/write-flow changes. Preserve all `class=`, `id=`, structural HTML, and inline JS unchanged.
- For the Canonical script's JSON snippets: keep them as JSON (with double-quoted keys/values). For `data-copy` attribute parents, use DOUBLE quotes (`data-copy="..."`) so embedded JSON parses cleanly.
- For the example agent prompt with single quotes around `'my-first-sim'`: the prompt is plain text. If embedding in a `data-copy="..."` (double-quoted) attribute, the single quotes are fine. Do NOT switch quote styles around it.
- Smoke-test the copy buttons by opening the page locally and clicking each button. If you can't open a browser, at minimum verify the HTML parses with `python3 -c "from html.parser import HTMLParser; HTMLParser().feed(open('dashboard/setup.html').read())"`.
- For replacement content: depict the Canonical v2 onboarding script. Copy the Claude Desktop JSON / Codex CLI command / Generic JSON VERBATIM.
- Update `aria-label` attributes for accessibility.
- Do NOT modify dashboard JS or CSS.
- Do NOT touch `dashboard/llms.txt` — Team C's regen output.
- Do NOT touch any files outside `dashboard/`.
- Commit message: `[Team D v2.0.0]: rewrite dashboard HTML examples + data-copy attributes for MCP-first onboarding`.

---

### Team E: Version bump + CHANGELOG repair (capstone)

**Blocked by:** Teams A, B, C, D — all must merge first.

**Read these files first:**
- `pyproject.toml:1-20` — `[project]` table; current `version = "1.1.0"` at line 3.
- `CHANGELOG.md` FULL FILE — current section ordering: `[1.0.4]` line 8, `[1.0.3]` line 43, `[Unreleased]` line 53 (Step 10b BLOCKER-4: contents are 2026-05-22 session-level-blind work, NOT 1.1.0 USER_MANUAL_OVERHAUL), `[1.0.2]` line 164, `[1.0.1]` line 174, `[1.0.0]` line 193, `[0.1.1]` line 319.
- `CHANGELOG.md:53-163` — read the FULL `[Unreleased]` body. Confirms Step 10b BLOCKER-4: this is 2026-05-22 session-level-blind content.
- `.github/workflows/pypi-publish.yml` — Trusted Publishing via OIDC; triggers on `release: published`, `push.tags: ['v*']`, `workflow_dispatch`.
- `docs/REMAINING_TASKS.md` — search for "USER_MANUAL_OVERHAUL" or "1.1.0" or "2026-05-16" to find the v1.1.0 contents to author the missing entry.
- `[[project-user-manual-overhaul-shipped]]` memory — v1.1.0 SHIPPED 2026-05-16 via PR #87 (`9a88842`).
- `[[project-session-level-blind-shipped]]` memory — session-level blind SHIPPED 2026-05-22 prod sha `27d96ca` PR #134.

**Recon evidence (verified against HEAD `fb2637c`):**

```toml pyproject.toml
3: version = "1.1.0"
5: readme = "README.md"
```

```text CHANGELOG.md section ordering
8:## [1.0.4] — 2026-05-12
43:## [1.0.3] — 2026-05-11
53:## [Unreleased]
164:## [1.0.2] — 2026-05-11
174:## [1.0.1] — 2026-05-11
193:## [1.0.0] - 2026-05-10
319:## [0.1.1] - <prior>
```

```text CHANGELOG.md:53-66 (Unreleased contents — Step 10b BLOCKER-4)
53:## [Unreleased]
54:
55:### Added (session-level blind mode — 2026-05-22 exec-plan v12)
56:
57:- **`create_session(blind: bool = False)`** across MCP (canonical
58:  `mcp__finlet__create_session`), REST (`POST /v1/sessions`), and CLI
59:  (`finlet sessions create --blind`). When `True`, the session is created
60:  ...
```

The `[Unreleased]` section is 2026-05-22 session-level-blind work — NOT the 2026-05-16 USER_MANUAL_OVERHAUL that constitutes v1.1.0. So `[Unreleased]` cannot be simply renamed to `[1.1.0]`.

(verified by recon agent against HEAD `fb2637c` via `grep -nE "^## \[" CHANGELOG.md` + read of CHANGELOG lines 53-75)

**CHANGELOG repair strategy (Step 10b BLOCKER-4):**

Final desired ordering (top to bottom):

| Position | Section | Date | Source of content |
|---|---|---|---|
| 1 | `[2.0.0]` | 2026-05-22 | (a) Pure-MCP removals from this exec-plan (added/changed/removed/migration). (b) Session-level-blind work currently misplaced in `[Unreleased]` — fold these in alongside removals since both ship 2026-05-22. |
| 2 | `[1.1.0]` | 2026-05-16 | NEW entry. USER_MANUAL_OVERHAUL contents — author from `docs/REMAINING_TASKS.md` evidence + memory `[[project-user-manual-overhaul-shipped]]` (PR #87 `9a88842`). |
| 3 | `[1.0.4]` | 2026-05-12 | Existing — keep at line 8 position. |
| 4 | `[1.0.3]` | 2026-05-11 | Existing — keep at line 43 position. |
| 5 | `[1.0.2]` | 2026-05-11 | Existing — keep at line 164 position. |
| 6 | `[1.0.1]` | 2026-05-11 | Existing — keep at line 174 position. |
| 7 | `[1.0.0]` | 2026-05-10 | Existing — keep at line 193 position. |
| 8 | `[0.1.1]` | <prior> | Existing — keep at line 319 position. |

Steps:
1. **Read** the full body of `[Unreleased]` (lines 53-163). Save the content — it goes into `[2.0.0]`.
2. **Delete** the misplaced `[Unreleased]` header at line 53 along with its contents.
3. **Author `[1.1.0] - 2026-05-16`** by reading `docs/REMAINING_TASKS.md` for USER_MANUAL_OVERHAUL closure references (memory says PR #87 `9a88842`). Sections: `### Added` (manual overhaul, `finlet manual` CLI command), `### Changed` (operator surfacing), `### PR references`.
4. **Author `[2.0.0] - 2026-05-22`** with three groupings:
   - `### Added` — session-level blind work from the saved `[Unreleased]` content.
   - `### Removed` — 12 CLI commands + helpers from this exec-plan.
   - `### Changed` — CLI surface reduced to MCP-bootstrap minimum.
   - `### Migration notes` — agents use MCP; wire `finlet mcp serve` into Claude Desktop / Codex CLI / Generic MCP Client. Zero PyPI consumers per `[[project-pre-launch-no-customers]]`; no deprecation period.
   - `### PR references` — this PR + the session-level-blind PR (#134 if its number is final).
5. **Prepend** `[2.0.0]` at top, then `[1.1.0]` immediately below, then existing `[1.0.4]` through `[0.1.1]` unchanged.

**Files touched:**
- Modified: `pyproject.toml` — bump `version = "1.1.0"` → `version = "2.0.0"` at line 3.
- Modified: `CHANGELOG.md` — execute the repair strategy above.

**Deliverable:** Repo at v2.0.0, CHANGELOG ordering clean, ready for tag push.

**Validation:**
- [ ] `grep "^version = " pyproject.toml` returns `version = "2.0.0"`.
- [ ] `grep -nE "^## \[" CHANGELOG.md` shows ordering: `[2.0.0] (2026-05-22) → [1.1.0] (2026-05-16) → [1.0.4] → [1.0.3] → [1.0.2] → [1.0.1] → [1.0.0] → [0.1.1]`.
- [ ] CHANGELOG has NO `[Unreleased]` section.
- [ ] `grep -A2 "^## \[2.0.0\]" CHANGELOG.md` shows BOTH a `### Added` mentioning session-level blind AND a `### Removed` mentioning the 12 dropped CLI commands.
- [ ] `grep -A2 "^## \[1.1.0\]" CHANGELOG.md` shows `### Added` mentioning USER_MANUAL_OVERHAUL or `finlet manual` and PR #87.
- [ ] `hatch build` succeeds — wheel + sdist produced.
- [ ] `unzip -l dist/finlet-2.0.0-*.whl | grep -E "finlet/(cli|mcp|api|core|plugins)"` confirms all key modules present; `finlet/cli_mcp_client.py` absent.
- [ ] `python -m pip install --force-reinstall dist/finlet-2.0.0-*.whl && finlet --help` shows trimmed command surface.
- [ ] `pytest tests/ -x` passes.
- [ ] `ruff check .` passes.
- [ ] `python -m finlet.manual.generate_llms_txt --check` exits 0.
- [ ] `git status` shows ONLY `pyproject.toml` and `CHANGELOG.md` modified.

**Agent instructions:**
- You MUST `git add pyproject.toml CHANGELOG.md` and `git commit` before finishing.
- Do NOT push the v2.0.0 tag yourself. Tag push is user-driven (final manual step after this PR merges).
- BEFORE editing CHANGELOG.md, READ the full file end-to-end + read `docs/REMAINING_TASKS.md` for USER_MANUAL_OVERHAUL evidence.
- The `[Unreleased]` section is NOT v1.1.0 content. It's 2026-05-22 session-level-blind work. Fold it into `[2.0.0]` alongside the pure-MCP removals (since they ship same-day).
- Author `[1.1.0]` from independent evidence (REMAINING_TASKS + memory) since there's no existing CHANGELOG entry for it.
- Match CHANGELOG voice/density to existing `## [1.0.0]` entry — terse, technical, with PR # links.
- Verify `hatch build` smoke locally before commit.
- Do NOT modify any other file.
- Commit message: `[Team E v2.0.0]: bump 2.0.0 + CHANGELOG repair (add [1.1.0] from manual-overhaul evidence; fold [Unreleased] into [2.0.0])`.

---

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Team A deletes `EXIT_AUTH_REQUIRED` and breaks `auth status` + `plugins` | Eliminated post-v3 fix | High | v3 explicitly KEEPS `EXIT_AUTH_REQUIRED`; Team A grep gate excludes it. |
| `dashboard/llms.txt` content not actually fixed by manual edits | Eliminated post-v3 fix | High | v3 Team C scope includes `registry.py` and `generate_llms_txt.py` (the actual content sources). |
| Team B asserts wrong response key (`anonymous` instead of `public_anonymous`) | Eliminated post-v3 fix | High | v3 Team B explicitly uses `result["public_anonymous"]` per `schemas/session.py:101`. |
| CHANGELOG `[Unreleased]` rename produces wrong 1.1.0 content | Eliminated post-v3 fix | Medium | v3 Team E folds `[Unreleased]` into `[2.0.0]` (correct date) AND authors `[1.1.0]` from `docs/REMAINING_TASKS.md` evidence. |
| Hidden CLI-unique behavior not in MCP | Low | High | Team B's coverage requirements name specific MCP test files (Step 10a STRONG-4). |
| `set_session_visibility` flag semantics drift | Low | High | Team B explicitly adds 4 assertions including anti-shape-drift (no `share_url`). |
| MCP tool shape drift snuck into v2.0.0 | Low | High | Plan explicitly prohibits MCP tool changes. Team B anti-shape-drift assertion catches it. |
| `dashboard/llms.txt` drift fails CI | Low | Medium | Team C owns the regen + validation. |
| README ships broken examples to PyPI | Low post-fix | High | Team C rewrites README quickstart + CLI reference sections explicitly. |
| CHANGELOG repair produces inconsistent ordering | Low post-fix | Medium | v3 spells out target ordering in a table. |
| Team C and Team D rewrite divergent onboarding narratives | Low post-fix | Medium | Canonical script is concrete (verbatim JSON/commands). Cross-surface narrative check in both teams' validation. |
| Team A leaves orphan symbols/imports | Low | Medium | `ruff check` + grep validation catches orphans. v3 includes explicit module docstring rewrite. |
| `finlet trade order` ghost reference remains | Low | Low | Team C validation grep includes `trade`. |
| HTML attribute parsing breaks copy buttons | Low post-fix | Medium | v3 Team D uses double-quoted `data-copy` attributes + smoke test in validation. |
| New test fixtures use realistic-looking secrets (gitleaks risk) | Low | Medium | v3 Team B explicit fake-fixture rule + gitleaks-friendly grep validation. |
| Hatch wheel build fails on cli_mcp_client deletion | Low | Medium | Team E validation includes `hatch build` smoke. |
| PyPI publish workflow doesn't fire on v2.0.0 tag | Very Low | Medium | Workflow triggers on `push.tags: ['v*']`. `workflow_dispatch` fallback. |
| Stale `~/.cache/pip` returns v1.x on PyPI cache lag | Low | Low | Pre-launch, zero customers — no impact. |

## Session Plan

### Session 1 — Parallel surgery + docs (A, C, D)

**Parallel teams:** A (CLI surgery + module docstring rewrite), C (server-side docs + manual registry + generator + README + llms.txt), D (dashboard frontend HTML). All touch disjoint file sets.

**Merge order:** A first (gates Team B). C and D can merge in any order. Recommended:
- A → tests → C → tests → D → tests

**Per-merge gate:** `pytest tests/ -x --ignore=tests/e2e --ignore=tests/playwright` after each team merges. For C: also `python -m finlet.manual.generate_llms_txt --check` exits 0 AND `grep -E "FINLET_API_KEY|hosted MCP-over-HTTP" dashboard/llms.txt` shows MCP-first dispositions.

**Cross-surface narrative gate (after both C and D merge):** verify Claude Desktop JSON snippet in `finlet/manual/quickstart.md` matches the one in `dashboard/setup.html` verbatim. If they diverge, one of the teams paraphrased the Canonical script — re-open whichever team's PR with the diff.

**Session checkpoint:** Full test suite + `ruff check .` + llms.txt check + cross-surface narrative check after all three merged.

### Session 2 — Test cleanup (B)

**Sequential:** Team B alone (blocked by A).

**Per-merge gate:** `pytest tests/ -x` (full suite, no ignores).

**Session checkpoint:** Full test suite green; `grep -rn "from finlet.cli_mcp_client" tests/` returns nothing; the 4 new `set_session_visibility` assertions pass; no realistic-looking secrets in new fixtures.

### Session 3 — Capstone (E)

**Sequential:** Team E alone (blocked by A, B, C, D).

**Per-merge gate:** `pytest tests/ -x` + `hatch build` + `ruff check .` + smoke install of built wheel + CHANGELOG ordering check + 1.1.0 entry presence check + 2.0.0 entry presence check.

**Session checkpoint:** Repo at v2.0.0, CHANGELOG ordering verified clean, ready for tag push.

**Post-merge (user-driven):**
- User runs `git tag v2.0.0 && git push --tags` to trigger `.github/workflows/pypi-publish.yml`.
- Verify PyPI publish: `pip install --upgrade finlet && finlet --version` shows 2.0.0.
- Smoke test: fresh venv → `pip install finlet==2.0.0 && finlet auth login` → wire `finlet mcp serve` into a Claude Desktop config → ask the agent to create a session against finlet.dev prod.

---

## Codex review (Step 10a) — v1 findings + v2 responses

**Reviewed:** v1 of this plan against HEAD `fb2637c` (codex CLI v0.128.0, `model_reasoning_effort="high"`, tokens used 4,149,195).

### BLOCKERs (5) — all amended in v2

| # | v1 finding (Codex) | v2 response |
|---|---|---|
| 1 | Conflict table is false: Team C edits manual `.md`; CI gates regen of `dashboard/llms.txt`; Team D owns `dashboard/`. Hidden file conflict. | Added `dashboard/llms.txt` to File Conflict Table under Team C with explicit carve-out. Team C scope expanded to include regen. Team D forbidden from touching `dashboard/llms.txt`. |
| 2 | CHANGELOG model wrong. Plan claimed most recent entry was `[1.0.0]`; actual ordering has `[Unreleased]` misplaced between 1.0.3 and 1.0.2; no `[1.1.0]` entry despite pyproject at 1.1.0. | Team E spec rewritten to two-step repair: rename `[Unreleased]` → `[1.1.0]` AND reposition, then prepend `[2.0.0]`. |
| 3 | README has live dropped-command examples at lines 85, 92, 100, 352, 357 (PyPI package readme). v1 plan said "spot-check + minor edits." | Team C scope expanded to "rewrite quickstart + CLI reference sections." README in File Conflict Table. |
| 4 | Team B doesn't pin MCP equivalence for `session publish` flag semantics. | Team B adds 3 explicit MCP-side flag-semantics assertions + anti-shape-drift. |
| 5 | Plan tells teams to read forbidden `.claude/` files. | Removed both `.claude/` refs from Team A and Team D read lists. |

### STRONG-SUGGESTIONs (5) — all integrated in v2

| # | v1 finding (Codex) | v2 response |
|---|---|---|
| 1 | Root cause broader than CLI/MCP drift. | Added "Scope honesty" note in Motivation. |
| 2 | C/D not narrative-independent. | Added "Canonical v2 onboarding script" section; both teams required to depict it. |
| 3 | Team A deletion list misses stale helper/comment fallout. | Team A scope expanded with file:line; added stale-comment audit. |
| 4 | Team B audit was vague. | Team B "Read these files first" names 5 MCP test files explicitly. |
| 5 | Docs grep misses `finlet trade order`. | Plan validation grep expanded to include `trade`. |

### NITs (2) — captured, not BLOCKER

| # | v1 finding (Codex) | v2 response |
|---|---|---|
| 1 | Dashboard should be edited copy-only. | Added "Copy/text only" constraint to Team D + Constraints section. |
| 2 | `finlet plugins` dispatch risk is clean. | No change needed; confirmation noted in Constraints. |

## Codex review (Step 10b) — v2 findings + v3 responses

**Reviewed:** v2 of this plan against HEAD `fb2637c` (codex CLI v0.128.0, `model_reasoning_effort="high"`, tokens used 2,528,726).

### BLOCKERs (4) — all amended in v3

| # | v2 finding (Codex) | v3 response |
|---|---|---|
| 1 | Team A's expanded deletion list included `EXIT_AUTH_REQUIRED` as dead. **Actually alive** — used by `auth_status` (`cli.py:1598-1604`), `plugins_add` (`cli.py:984`), `plugins_remove` (`cli.py:1056`). If Team A deletes it literally, kept commands break. | v3 "Dead helpers" section explicitly splits DEAD set from ALIVE set. `EXIT_AUTH_REQUIRED` moved to ALIVE list — Team A keeps it. Validation gate excludes it from the orphan-grep. Constraint added to "What's being kept" section noting plugins commands use it. |
| 2 | Team C's `llms.txt` fix is structurally false. v2 said "edit manuals + regen." Actual generator at `finlet/manual/generate_llms_txt.py:25` reads `TOPIC_REGISTRY` from `finlet/manual/registry.py` + hardcoded sections in the generator itself. Editing manual `.md` bodies doesn't change llms.txt. | v3 expands Team C scope to include `finlet/manual/registry.py` (topic summaries) AND `finlet/manual/generate_llms_txt.py` (hardcoded "Agent Instructions" + stdio config sections). Added explicit `llms.txt content source` callout in File Conflict Table. Validation now greps llms.txt content for MCP-first dispositions, not just `--check` exit code. |
| 3 | Team B's new visibility assertions target the wrong surface. v2 asserted `result["anonymous"]` — but actual schema field is `public_anonymous` (`schemas/session.py:101`). Also `--unpublish` CLI always passed `anonymous=True` (`cli.py:692`); v2's third assertion didn't pin this. | v3 Team B spec: 4 assertions using `result["public_anonymous"]` (correct key), with the unpublish case explicitly asserting `public_anonymous=True` (matching CLI behavior). Plus anti-shape-drift assertion `"share_url" not in result`. |
| 4 | Team E's CHANGELOG repair misclassifies `[Unreleased]`. v2 said rename to `[1.1.0]` if contents match USER_MANUAL_OVERHAUL. Actual `[Unreleased]` body is 2026-05-22 session-level-blind work, NOT 2026-05-16 USER_MANUAL_OVERHAUL. | v3 Team E strategy rewrites: fold `[Unreleased]` into NEW `[2.0.0]` entry (correct date — both ship 2026-05-22); author NEW `[1.1.0]` entry from `docs/REMAINING_TASKS.md` evidence + memory `[[project-user-manual-overhaul-shipped]]`. Final ordering table specified explicitly. |

### STRONG-SUGGESTIONs (4) — all integrated in v3

| # | v2 finding (Codex) | v3 response |
|---|---|---|
| 1 | Canonical v2 onboarding script not concrete enough — leaves room for C/D divergence. | v3 Canonical section now has EXACT Claude Desktop JSON, EXACT Codex CLI command, EXACT Generic MCP JSON, EXACT example agent prompt. Both teams instructed to use VERBATIM. |
| 2 | Team D's `data-copy` update is behavior, not inert copy. Quote escaping matters. | v3 Team D spec calls out HTML attribute escaping: use DOUBLE-quoted `data-copy="..."` so embedded JSON's double quotes need escaping but single quotes in the agent-prompt example work cleanly. Added copy-button smoke test + HTML-parser sanity check to validation. |
| 3 | New MCP tests could use realistic-looking JWTs / api_keys → gitleaks risk. | v3 Team B "Test fixture hygiene" section: explicit fake-pattern rules (`header.payload.signature`, `fnlt_test_key_<short>`, etc.) + grep gate forbidding `eyJ...` JWTs or realistic `fnlt_<32hex>` patterns in new fixtures. |
| 4 | `llms.txt --check` won't catch C/D narrative divergence. | v3 Session Plan adds a cross-surface narrative gate after both teams merge: diff the Claude Desktop JSON snippet in `finlet/manual/quickstart.md` against the one in `dashboard/setup.html`. Both teams' validation also includes this check. |

### NITs (4) — captured, not BLOCKER

| # | v2 finding (Codex) | v3 response |
|---|---|---|
| 1 | `cli.py:1347` is an inline comment, not a docstring — word precisely. | v3 Team A spec clarifies: "inline comment, NOT a docstring." |
| 2 | `docs/decisions/cli-mcp-stdio-auth.md` already Superseded. Team C audit instruction is fine. | v3 retains "audit; if not already Superseded" with confirmation note. |
| 3 | Module docstring at `cli.py:1-30` describes deleted command families. Team A's sweep should include it. | v3 Team A spec explicitly rewrites the module docstring; validation greps for `v1.0.1|MCP-over-HTTP|MCP-dispatched|dispatch contract` in cli.py and expects no hits. |
| 4 | No silently-skipped Step 10a STRONG. | No action required; confirmation noted. |

---

**Plan version:** v3. Step 10a + 10b complete. Handoff is THIS document. No Step 10c per `[[feedback-two-pass-codex-review]]`.
