# Codex retest follow-ups — SESSION_LEVEL_BLIND (prod sha 27d96ca)

## Retest summary (run 2026-05-22 post-deploy)

8 of 9 claimed fixes PASS with all variations on the deployed SHA.

| # | Fix | Original | Variations | Status |
|---|---|---|---|---|
| 1 | Session-level blind kwarg | PASS | 4 PASS | clean |
| 2 | Wall-clock audit redaction | PASS | 4 PASS | clean |
| 3 | MCP session-touching wrap | PASS | 5 PASS | clean |
| 4 | freeze_time clock leak | PASS | 3 PASS | clean |
| 5 | Service-layer catalog enforcement | PASS | 4 PASS | clean |
| 6 | Unforgeable benchmark bypass | PASS | 4 PASS | clean |
| 7 | configure_session atomicity | PASS | 3 PASS | clean |
| 8 | CLI `--blind` flag | PASS | 3 PASS, **1 FAIL** | partial |
| 9 | Universe cap removed | PASS | 4 PASS | clean |

Hygiene sweep: PASS (owner/user_id leakage clean, MCP error envelope path sanitation intact).

## Partial-fix defect

### CLI blind-mode fallback can leak real tickers

**File:** `finlet/cli.py:624`

**Defect class:** Defensive fallback leaks the very data the fix was meant to hide.

**Repro:**
```python
# Mock the MCP envelope to simulate a blind response that omits config.universe
mock_envelope = {
    "id": "sid-blind",
    "name": "blind-sid",
    "config": {
        "start_time": "Day_1",
        "initial_capital": 100000,
        "blind": True,
        # NOTE: no "universe" key — server didn't include it
    }
}
# Then run:
finlet session create --blind --universe AAPL,MSFT --name foo --start 2024-01-01 --capital 100000
```

**Expected:** Blind mode must never echo local input. Either suppress the `Universe:` line entirely, or display a blind-aware placeholder like `Universe: <blind>`.

**Actual:** CLI prints `Universe: AAPL, MSFT` (real tickers leaked).

**Root cause:** The Team D fix at `cli.py:624` was:
```python
universe_to_show = config.get("universe") or tickers
```
The `or tickers` fallback fires when `config.get("universe")` is missing/empty. For a blind session, this is exactly the wrong fallback — server-omitted universe should NOT fall back to user-supplied real tickers.

**Suggested fix:**
```python
# Detect blind mode first; never fall back to local input if blind.
is_blind = config.get("blind") is True or data.get("blind") is True
if is_blind:
    universe_to_show = config.get("universe") or []  # never fall back to local
else:
    universe_to_show = config.get("universe") or tickers
if universe_to_show:
    typer.echo(f"  Universe: {', '.join(universe_to_show)}")
elif is_blind:
    typer.echo("  Universe: <blind>")
```

Add a regression test in `tests/test_cli.py`: simulate the malformed-blind-envelope case, assert no real tickers in stdout.

## Recommendation

Pick up as a one-line fix in the next /exec-plan iteration (or hot-fix directly — this is a narrow CLI defect with no impact on deployed REST/MCP surfaces). Not blocking — production paths return `config.universe` correctly per the retest's PASS on variations 1-3 of Fix #8.

## Methodology note

Codex did NOT make live HTTP calls to prod (no authenticated context). Retest was code-level adversarial review of local SHA 27d96ca (== prod git_sha). Test suite re-verified in same run: `134 passed`.
