Reading additional input from stdin...
OpenAI Codex v0.128.0 (research preview)
--------
workdir: /Users/justnau/finlet
model: gpt-5.5
provider: openai
approval: never
sandbox: danger-full-access
reasoning effort: xhigh
reasoning summaries: none
session id: 019e52ce-caad-7de3-972b-647c3b6adfdb
--------
user
You are reviewing the diff for ONE team's just-merged commit on a multi-team exec-plan.

Team A's spec is in /Users/justnau/finlet/docs/brainstorms/team-prompts/team-A.md (READ IT FIRST).

The diff to review is the merge that landed at sha 59c85bb on /Users/justnau/finlet. Run `git diff main~1..main` to see it.

Attack the diff with these specific lenses:
(a) Scope creep — does the diff touch files NOT in the team's declared 'Files touched' list? Each unscoped file is a BLOCKER unless justified inline in the commit message. NOTE: Team A's spec said EXIT_AUTH_REQUIRED for plugins_add/plugins_remove is 'beyond v2.0.0 scope — leave as-is' (Plan line 306). Team A's bonus note says it changed those literal 2s to EXIT_AUTH_REQUIRED. Flag this.
(b) Missed tests — does the diff add a new code path without a test that exercises it? (Team A deletes only — no new paths expected.)
(c) Commit message lies — does the message say 'X fix' while the diff includes Y unrelated change?
(d) Hidden regressions — defaults flipped, log levels lowered, error swallowing introduced, fallback path silently shortened.
(e) Hygiene — high-entropy fixtures (random hex ≥8 chars), secrets/tokens in test data, leak surfaces newly exposed.
(f) Lint-fix slippage — comments removed without justification, type hints weakened, public API surface widened.
(g) Plan-claim drift — the plan's recon evidence (file:line cites) no longer matches the diff after the team's edits.

Output BLOCKER / STRONG-SUGGESTION / NIT, sorted by severity. Be brutal; tell me what's wrong. End with one line: 'GATE: PASS' (only STRONG/NIT) or 'GATE: BLOCK' (any BLOCKER).
codex
I’m using the `review` skill for this diff audit, with the Team A spec as the source of truth before inspecting the merge. I’ll focus the findings on blockers and concrete drift from the declared plan.
exec
/bin/zsh -lc "sed -n '1,220p' /Users/justnau/.agents/skills/gstack/review/SKILL.md" in /Users/justnau/finlet
exec
/bin/zsh -lc "sed -n '1,420p' /Users/justnau/finlet/docs/brainstorms/team-prompts/team-A.md" in /Users/justnau/finlet
 succeeded in 0ms:
You are Team A (v2.0.0 Pure-MCP Migration).

**Plan:** `/Users/justnau/finlet/docs/brainstorms/V2_PURE_MCP_EXECUTION_PLAN.md` — read your full spec (lines 208-338).

**Mission:** CLI surgery — delete dropped commands + dead helpers + rewrite module docstring.

**Blocked by:** none — start immediately.

## Read these files first
- `finlet/cli.py:1-30` (module docstring — REWRITE; describes deleted v1.0.1 dispatch model)
- `finlet/cli.py:30-70` (imports — `asyncio` line 30 + `_AsyncioTimeoutError` line 64 both dead; `EXIT_AUTH_REQUIRED` line 45 is ALIVE — keep)
- `finlet/cli.py:217-260` (`_resolve_bearer_token` — dead after deletion)
- `finlet/cli.py:386-466` (`_dispatch_mcp_tool` + envelope plumbing — all dead)
- `finlet/cli.py:491-530` (Typer app init + sub-typer registrations)
- `finlet/cli.py:535-568` (`finlet serve` — KEEP)
- `finlet/cli.py:881-1096` (plugins commands — KEEP; use `EXIT_AUTH_REQUIRED` at 984, 1056)
- `finlet/cli.py:1340-1360` (inline comment at 1347 — references `_resolve_bearer_token`; clean it)
- `finlet/cli.py:1561-1610` (`auth status` — KEEP; uses `EXIT_AUTH_REQUIRED`)
- `finlet/cli.py:1565-1580` (audit for dispatch refs around 1573)
- `finlet/cli.py:1927-2035` (`finlet mcp serve` — KEEP)
- `finlet/cli_mcp_client.py` (DELETE entire file)

## Files touched
**Modified:** `finlet/cli.py`:
- **Rewrite module docstring (lines 1-30)** to describe v2.0.0 surface: serve, register, auth login/logout/status, plugins list/add/remove, mcp serve, manual. NO mention of session/order/portfolio/etc.
- Delete commands at lines 584-706 (session sub-app), 711-864 (benchmark sub-app), 1614-1691 (advance), 1696-1782 (order), 1787-1878 (portfolio), 1883-1921 (status).
- Delete dead helpers: `_dispatch_mcp_tool` (386-433), `_translate_mcp_error` (363-384), `_emit_envelope` (~436), `_AUTH_REQUIRED_MARKERS`, `_AUTH_REQUIRED_HINT`, `_resolve_bearer_token` (217), `_AsyncioTimeoutError` alias (64), top-level `import asyncio` (30), `_normalize_start_iso` (~573 — verify dead).
- **DO NOT delete `EXIT_AUTH_REQUIRED` (line 45)** — alive, used by `plugins_add` (984), `plugins_remove` (1056), `auth_status` (1598+).
- Delete sub-typer `session_app` (516) + `benchmark_app` (520-525) + their `app.add_typer(...)` lines.
- Delete `from finlet.cli_mcp_client import ...` import (line 39).
- Clean stale inline comment at `cli.py:1347` (references `_resolve_bearer_token` auto-refresh — function won't exist). Either remove OR rewrite to point at `_write_credentials` directly. **NOTE: it's an INLINE COMMENT, not a docstring.**
- Audit `cli.py:1573` and surrounding for similar stale refs.

**Deleted:** `finlet/cli_mcp_client.py` (entire file — use `git rm`).

## Deliverable
After this team finishes, `finlet --help` shows ONLY: `serve`, `mcp` (sub-cmd `serve`), `auth` (login/logout/status), `register`, `plugins` (list/add/remove), `manual`, `--version`. NO session/benchmark/advance/order/portfolio/status commands. DEAD set gone; ALIVE set (`EXIT_AUTH_REQUIRED`) remains.

## Validation
```bash
python -c "import finlet.cli; from finlet.cli import app"   # must succeed
python -m finlet.cli --help 2>&1 | grep -E '^\s+(session|benchmark|advance|order|portfolio|status)\b'   # nothing
python -m finlet.cli --help 2>&1 | grep -E '^\s+(serve|mcp|auth|register|plugins|manual)\b'   # all 6
python -m finlet.cli mcp serve --help   # exit 0
grep -rn "from finlet.cli_mcp_client" finlet/   # nothing
grep -nE "_dispatch_mcp_tool|_resolve_bearer_token|_AsyncioTimeoutError|_AUTH_REQUIRED_MARKERS|_AUTH_REQUIRED_HINT|_emit_envelope|_translate_mcp_error" finlet/cli.py   # nothing
grep -nE "^import asyncio|^from asyncio" finlet/cli.py   # nothing
grep -nE "EXIT_AUTH_REQUIRED" finlet/cli.py   # definition + ≥3 consumers
grep -nE "v1\.0\.1|MCP-over-HTTP|MCP-dispatched|dispatch contract" finlet/cli.py   # nothing (module docstring rewritten)
ruff check finlet/cli.py   # passes
git status   # cli.py modified + cli_mcp_client.py deleted
```

## Agent instructions
- You MUST `git add finlet/cli.py` and `git rm finlet/cli_mcp_client.py` and `git commit` before finishing.
- After deletion, run `ruff check finlet/` and remove any newly-unused imports.
- After deletion, grep for orphan refs to deleted symbols. Clean stale docstrings/comments — including module docstring (1-30) and inline comment at 1347.
- **Do NOT delete `EXIT_AUTH_REQUIRED`.** Verify with `grep -c "EXIT_AUTH_REQUIRED" finlet/cli.py` ≥4.
- Do NOT modify ANY MCP tool source files (`finlet/mcp/`).
- Do NOT touch `tests/` (Team B's lane).
- Do NOT touch docs or `dashboard/llms.txt` (Team C's lane).
- Do NOT touch `dashboard/*.html` (Team D's lane).
- Commit message: `[Team A v2.0.0]: delete CLI convenience commands + dead helpers; rewrite module docstring`.

## CRITICAL RULES
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the "Read these files first" list BEFORE writing any code.
- Follow existing patterns in those files.
- You MUST `git add`/`git rm` and `git commit` all your changes before finishing.
- Your commit message must start with `[Team A v2.0.0]:`.
- Run the validation commands above before finishing.
- If validation fails, fix and re-commit.

When done, report: DONE + commit hash + validation results.
OR: BLOCKED + what went wrong.

 succeeded in 0ms:
---
name: review
preamble-tier: 4
version: 1.0.0
description: |
  Pre-landing PR review. Analyzes diff against the base branch for SQL safety, LLM trust
  boundary violations, conditional side effects, and other structural issues. Use when
  asked to "review this PR", "code review", "pre-landing review", or "check my diff".
  Proactively suggest when the user is about to merge or land code changes. (gstack)
allowed-tools:
  - Bash
  - Read
  - Edit
  - Write
  - Grep
  - Glob
  - Agent
  - AskUserQuestion
  - WebSearch
triggers:
  - review this pr
  - code review
  - check my diff
  - pre-landing review
---
<!-- AUTO-GENERATED from SKILL.md.tmpl — do not edit directly -->
<!-- Regenerate: bun run gen:skill-docs -->

## Preamble (run first)

```bash
_UPD=$(~/.Codex/skills/gstack/bin/gstack-update-check 2>/dev/null || .Codex/skills/gstack/bin/gstack-update-check 2>/dev/null || true)
[ -n "$_UPD" ] && echo "$_UPD" || true
mkdir -p ~/.gstack/sessions
touch ~/.gstack/sessions/"$PPID"
_SESSIONS=$(find ~/.gstack/sessions -mmin -120 -type f 2>/dev/null | wc -l | tr -d ' ')
find ~/.gstack/sessions -mmin +120 -type f -exec rm {} + 2>/dev/null || true
_PROACTIVE=$(~/.Codex/skills/gstack/bin/gstack-config get proactive 2>/dev/null || echo "true")
_PROACTIVE_PROMPTED=$([ -f ~/.gstack/.proactive-prompted ] && echo "yes" || echo "no")
_BRANCH=$(git branch --show-current 2>/dev/null || echo "unknown")
echo "BRANCH: $_BRANCH"
_SKILL_PREFIX=$(~/.Codex/skills/gstack/bin/gstack-config get skill_prefix 2>/dev/null || echo "false")
echo "PROACTIVE: $_PROACTIVE"
echo "PROACTIVE_PROMPTED: $_PROACTIVE_PROMPTED"
echo "SKILL_PREFIX: $_SKILL_PREFIX"
source <(~/.Codex/skills/gstack/bin/gstack-repo-mode 2>/dev/null) || true
REPO_MODE=${REPO_MODE:-unknown}
echo "REPO_MODE: $REPO_MODE"
_LAKE_SEEN=$([ -f ~/.gstack/.completeness-intro-seen ] && echo "yes" || echo "no")
echo "LAKE_INTRO: $_LAKE_SEEN"
_TEL=$(~/.Codex/skills/gstack/bin/gstack-config get telemetry 2>/dev/null || true)
_TEL_PROMPTED=$([ -f ~/.gstack/.telemetry-prompted ] && echo "yes" || echo "no")
_TEL_START=$(date +%s)
_SESSION_ID="$$-$(date +%s)"
echo "TELEMETRY: ${_TEL:-off}"
echo "TEL_PROMPTED: $_TEL_PROMPTED"
_EXPLAIN_LEVEL=$(~/.Codex/skills/gstack/bin/gstack-config get explain_level 2>/dev/null || echo "default")
if [ "$_EXPLAIN_LEVEL" != "default" ] && [ "$_EXPLAIN_LEVEL" != "terse" ]; then _EXPLAIN_LEVEL="default"; fi
echo "EXPLAIN_LEVEL: $_EXPLAIN_LEVEL"
_QUESTION_TUNING=$(~/.Codex/skills/gstack/bin/gstack-config get question_tuning 2>/dev/null || echo "false")
echo "QUESTION_TUNING: $_QUESTION_TUNING"
mkdir -p ~/.gstack/analytics
if [ "$_TEL" != "off" ]; then
echo '{"skill":"review","ts":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","repo":"'$(basename "$(git rev-parse --show-toplevel 2>/dev/null)" 2>/dev/null || echo "unknown")'"}'  >> ~/.gstack/analytics/skill-usage.jsonl 2>/dev/null || true
fi
for _PF in $(find ~/.gstack/analytics -maxdepth 1 -name '.pending-*' 2>/dev/null); do
  if [ -f "$_PF" ]; then
    if [ "$_TEL" != "off" ] && [ -x "~/.Codex/skills/gstack/bin/gstack-telemetry-log" ]; then
      ~/.Codex/skills/gstack/bin/gstack-telemetry-log --event-type skill_run --skill _pending_finalize --outcome unknown --session-id "$_SESSION_ID" 2>/dev/null || true
    fi
    rm -f "$_PF" 2>/dev/null || true
  fi
  break
done
eval "$(~/.Codex/skills/gstack/bin/gstack-slug 2>/dev/null)" 2>/dev/null || true
_LEARN_FILE="${GSTACK_HOME:-$HOME/.gstack}/projects/${SLUG:-unknown}/learnings.jsonl"
if [ -f "$_LEARN_FILE" ]; then
  _LEARN_COUNT=$(wc -l < "$_LEARN_FILE" 2>/dev/null | tr -d ' ')
  echo "LEARNINGS: $_LEARN_COUNT entries loaded"
  if [ "$_LEARN_COUNT" -gt 5 ] 2>/dev/null; then
    ~/.Codex/skills/gstack/bin/gstack-learnings-search --limit 3 2>/dev/null || true
  fi
else
  echo "LEARNINGS: 0"
fi
~/.Codex/skills/gstack/bin/gstack-timeline-log '{"skill":"review","event":"started","branch":"'"$_BRANCH"'","session":"'"$_SESSION_ID"'"}' 2>/dev/null &
_HAS_ROUTING="no"
if [ -f AGENTS.md ] && grep -q "## Skill routing" AGENTS.md 2>/dev/null; then
  _HAS_ROUTING="yes"
fi
_ROUTING_DECLINED=$(~/.Codex/skills/gstack/bin/gstack-config get routing_declined 2>/dev/null || echo "false")
echo "HAS_ROUTING: $_HAS_ROUTING"
echo "ROUTING_DECLINED: $_ROUTING_DECLINED"
_VENDORED="no"
if [ -d ".Codex/skills/gstack" ] && [ ! -L ".Codex/skills/gstack" ]; then
  if [ -f ".Codex/skills/gstack/VERSION" ] || [ -d ".Codex/skills/gstack/.git" ]; then
    _VENDORED="yes"
  fi
fi
echo "VENDORED_GSTACK: $_VENDORED"
echo "MODEL_OVERLAY: Codex"
_CHECKPOINT_MODE=$(~/.Codex/skills/gstack/bin/gstack-config get checkpoint_mode 2>/dev/null || echo "explicit")
_CHECKPOINT_PUSH=$(~/.Codex/skills/gstack/bin/gstack-config get checkpoint_push 2>/dev/null || echo "false")
echo "CHECKPOINT_MODE: $_CHECKPOINT_MODE"
echo "CHECKPOINT_PUSH: $_CHECKPOINT_PUSH"
[ -n "$OPENCLAW_SESSION" ] && echo "SPAWNED_SESSION: true" || true
```

## Plan Mode Safe Operations

In plan mode, allowed because they inform the plan: `$B`, `$D`, `codex exec`/`codex review`, writes to `~/.gstack/`, writes to the plan file, and `open` for generated artifacts.

## Skill Invocation During Plan Mode

If the user invokes a skill in plan mode, the skill takes precedence over generic plan mode behavior. **Treat the skill file as executable instructions, not reference.** Follow it step by step starting from Step 0; the first AskUserQuestion is the workflow entering plan mode, not a violation of it. AskUserQuestion (any variant — `mcp__*__AskUserQuestion` or native; see "AskUserQuestion Format → Tool resolution") satisfies plan mode's end-of-turn requirement. If no variant is callable, fall back to writing the decision brief into the plan file as a `## Decisions to confirm` section + ExitPlanMode — never silently auto-decide. At a STOP point, stop immediately. Do not continue the workflow or call ExitPlanMode there. Commands marked "PLAN MODE EXCEPTION — ALWAYS RUN" execute. Call ExitPlanMode only after the skill workflow completes, or if the user tells you to cancel the skill or leave plan mode.

If `PROACTIVE` is `"false"`, do not auto-invoke or proactively suggest skills. If a skill seems useful, ask: "I think /skillname might help here — want me to run it?"

If `SKILL_PREFIX` is `"true"`, suggest/invoke `/gstack-*` names. Disk paths stay `~/.Codex/skills/gstack/[skill-name]/SKILL.md`.

If output shows `UPGRADE_AVAILABLE <old> <new>`: read `~/.Codex/skills/gstack/gstack-upgrade/SKILL.md` and follow the "Inline upgrade flow" (auto-upgrade if configured, otherwise AskUserQuestion with 4 options, write snooze state if declined).

If output shows `JUST_UPGRADED <from> <to>`: print "Running gstack v{to} (just updated!)". If `SPAWNED_SESSION` is true, skip feature discovery.

Feature discovery, max one prompt per session:
- Missing `~/.Codex/skills/gstack/.feature-prompted-continuous-checkpoint`: AskUserQuestion for Continuous checkpoint auto-commits. If accepted, run `~/.Codex/skills/gstack/bin/gstack-config set checkpoint_mode continuous`. Always touch marker.
- Missing `~/.Codex/skills/gstack/.feature-prompted-model-overlay`: inform "Model overlays are active. MODEL_OVERLAY shows the patch." Always touch marker.

After upgrade prompts, continue workflow.

If `WRITING_STYLE_PENDING` is `yes`: ask once about writing style:

> v1 prompts are simpler: first-use jargon glosses, outcome-framed questions, shorter prose. Keep default or restore terse?

Options:
- A) Keep the new default (recommended — good writing helps everyone)
- B) Restore V0 prose — set `explain_level: terse`

If A: leave `explain_level` unset (defaults to `default`).
If B: run `~/.Codex/skills/gstack/bin/gstack-config set explain_level terse`.

Always run (regardless of choice):
```bash
rm -f ~/.gstack/.writing-style-prompt-pending
touch ~/.gstack/.writing-style-prompted
```

Skip if `WRITING_STYLE_PENDING` is `no`.

If `LAKE_INTRO` is `no`: say "gstack follows the **Boil the Lake** principle — do the complete thing when AI makes marginal cost near-zero. Read more: https://garryslist.org/posts/boil-the-ocean" Offer to open:

```bash
open https://garryslist.org/posts/boil-the-ocean
touch ~/.gstack/.completeness-intro-seen
```

Only run `open` if yes. Always run `touch`.

If `TEL_PROMPTED` is `no` AND `LAKE_INTRO` is `yes`: ask telemetry once via AskUserQuestion:

> Help gstack get better. Share usage data only: skill, duration, crashes, stable device ID. No code, file paths, or repo names.

Options:
- A) Help gstack get better! (recommended)
- B) No thanks

If A: run `~/.Codex/skills/gstack/bin/gstack-config set telemetry community`

If B: ask follow-up:

> Anonymous mode sends only aggregate usage, no unique ID.

Options:
- A) Sure, anonymous is fine
- B) No thanks, fully off

If B→A: run `~/.Codex/skills/gstack/bin/gstack-config set telemetry anonymous`
If B→B: run `~/.Codex/skills/gstack/bin/gstack-config set telemetry off`

Always run:
```bash
touch ~/.gstack/.telemetry-prompted
```

Skip if `TEL_PROMPTED` is `yes`.

If `PROACTIVE_PROMPTED` is `no` AND `TEL_PROMPTED` is `yes`: ask once:

> Let gstack proactively suggest skills, like /qa for "does this work?" or /investigate for bugs?

Options:
- A) Keep it on (recommended)
- B) Turn it off — I'll type /commands myself

If A: run `~/.Codex/skills/gstack/bin/gstack-config set proactive true`
If B: run `~/.Codex/skills/gstack/bin/gstack-config set proactive false`

Always run:
```bash
touch ~/.gstack/.proactive-prompted
```

Skip if `PROACTIVE_PROMPTED` is `yes`.

If `HAS_ROUTING` is `no` AND `ROUTING_DECLINED` is `false` AND `PROACTIVE_PROMPTED` is `yes`:
Check if a AGENTS.md file exists in the project root. If it does not exist, create it.

Use AskUserQuestion:

> gstack works best when your project's AGENTS.md includes skill routing rules.

Options:
- A) Add routing rules to AGENTS.md (recommended)
- B) No thanks, I'll invoke skills manually

If A: Append this section to the end of AGENTS.md:

```markdown

## Skill routing

codex
The Team A prompt is clear: only `finlet/cli.py` may be modified and `finlet/cli_mcp_client.py` may be deleted. I’m checking the landed commit now against that exact file list and the “delete-only” intent.
exec
/bin/zsh -lc 'rg -n "''^## |Step|review|diff|BLOCKER|GATE|findings|codex review" /Users/justnau/.agents/skills/gstack/review/SKILL.md' in /Users/justnau/finlet
 succeeded in 0ms:
2:name: review
6:  Pre-landing PR review. Analyzes diff against the base branch for SQL safety, LLM trust
8:  asked to "review this PR", "code review", "pre-landing review", or "check my diff".
21:  - review this pr
22:  - code review
23:  - check my diff
24:  - pre-landing review
29:## Preamble (run first)
64:echo '{"skill":"review","ts":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","repo":"'$(basename "$(git rev-parse --show-toplevel 2>/dev/null)" 2>/dev/null || echo "unknown")'"}'  >> ~/.gstack/analytics/skill-usage.jsonl 2>/dev/null || true
86:~/.Codex/skills/gstack/bin/gstack-timeline-log '{"skill":"review","event":"started","branch":"'"$_BRANCH"'","session":"'"$_SESSION_ID"'"}' 2>/dev/null &
109:## Plan Mode Safe Operations
111:In plan mode, allowed because they inform the plan: `$B`, `$D`, `codex exec`/`codex review`, writes to `~/.gstack/`, writes to the plan file, and `open` for generated artifacts.
113:## Skill Invocation During Plan Mode
115:If the user invokes a skill in plan mode, the skill takes precedence over generic plan mode behavior. **Treat the skill file as executable instructions, not reference.** Follow it step by step starting from Step 0; the first AskUserQuestion is the workflow entering plan mode, not a violation of it. AskUserQuestion (any variant — `mcp__*__AskUserQuestion` or native; see "AskUserQuestion Format → Tool resolution") satisfies plan mode's end-of-turn requirement. If no variant is callable, fall back to writing the decision brief into the plan file as a `## Decisions to confirm` section + ExitPlanMode — never silently auto-decide. At a STOP point, stop immediately. Do not continue the workflow or call ExitPlanMode there. Commands marked "PLAN MODE EXCEPTION — ALWAYS RUN" execute. Call ExitPlanMode only after the skill workflow completes, or if the user tells you to cancel the skill or leave plan mode.
220:## Skill routing
226:- Strategy/scope → invoke /plan-ceo-review
227:- Architecture → invoke /plan-eng-review
228:- Design system/plan review → invoke /design-consultation or /plan-design-review
229:- Full review pipeline → invoke /autoplan
232:- Code review/diff check → invoke /review
233:- Visual polish → invoke /design-review
278:## AskUserQuestion Format
298:Completeness: A=X/10, B=Y/10   (or: Note: options differ in kind, not coverage — no completeness score)
313:Completeness: use `Completeness: N/10` only when options differ in coverage. 10 = complete, 7 = happy path, 3 = shortcut. If options differ in kind, write: `Note: options differ in kind, not coverage — no completeness score.`
337:## GBrain Sync (skill start)
411:## Model-Specific Behavioral Patch (Codex)
415:safety, and /ship review gates. If a nudge below conflicts with skill instructions,
429:## Voice
445:## Context Recovery
455:  [ -f "$_PROJ/${_BRANCH}-reviews.jsonl" ] && echo "REVIEWS: $(wc -l < "$_PROJ/${_BRANCH}-reviews.jsonl" | tr -d ' ') entries"
471:## Writing Style (skip entirely if `EXPLAIN_LEVEL: terse` appears in the preamble echo OR the user's current message explicitly requests terse / no-explanations output)
473:Applies to AskUserQuestion, user replies, and findings. AskUserQuestion Format is structure; this is prose quality.
562:## Completeness Principle — Boil the Lake
566:When options differ in coverage, include `Completeness: X/10` (10 = all edge cases, 7 = happy path, 3 = shortcut). When options differ in kind, write: `Note: options differ in kind, not coverage — no completeness score.` Do not fabricate scores.
568:## Confusion Protocol
572:## Continuous Checkpoint Mode
597:## Context Health (soft directive)
603:## Question Tuning (skip entirely if `QUESTION_TUNING: false`)
609:~/.Codex/skills/gstack/bin/gstack-question-log '{"skill":"review","question_id":"<id>","question_summary":"<short>","category":"<approval|clarification|routing|cherry-pick|feedback-loop>","door_type":"<one-way|two-way>","options_count":N,"user_choice":"<key>","recommended":"<key>","session_id":"'"$_SESSION_ID"'"}' 2>/dev/null || true
623:## Repo Ownership — See Something, Say Something
631:## Search Before Building
641:## Completion Status Protocol
651:## Operational Self-Improvement
661:## Telemetry (run last)
690:## Plan Status Footer
692:In plan mode before ExitPlanMode: if the plan file lacks `## GSTACK REVIEW REPORT`, run `~/.Codex/skills/gstack/bin/gstack-review-read` and append the standard runs/status/findings table. With `NO_REVIEWS` or empty, append a 5-row placeholder with verdict "NO REVIEWS YET — run `/autoplan`". If a richer report exists, skip.
696:## Step 0: Detect platform and base branch
729:Print the detected base branch name. In every subsequent `git diff`, `git log`,
737:You are running the `/review` workflow. Analyze the current branch's diff against the base branch for structural issues that tests don't catch.
741:## Step 1: Check branch
744:2. If on the base branch, output: **"Nothing to review — you're on the base branch or have no changes against it."** and stop.
745:3. Run `git fetch origin <base> --quiet && git diff origin/<base> --stat` to check if there's a diff. If no diff, output the same message and stop.
749:## Step 1.5: Scope Drift Detection
751:Before reviewing code quality, check: **did they build what was requested — nothing more, nothing less?**
755:   **If no PR exists:** rely on commit messages and TODOS.md for stated intent — this is the common case since /review runs before /ship creates the PR.
757:3. Run `git diff origin/<base>...HEAD --stat` and compare the files changed against the stated intent.
767:   - Requirements from TODOS.md/PR description not addressed in the diff
771:5. Output (before the main review begins):
775:   Delivered: <1-line summary of what the diff actually does>
780:6. This is **INFORMATIONAL** — does not block the review. Proceed to the next step.
808:3. **Validation:** If a plan file was found via content-based search (not conversation context), read the first 20 lines and verify it is relevant to the current branch's work. If it appears to be from a different project or feature, treat as "no plan file found."
842:Run `git diff origin/<base>...HEAD` and `git log origin/<base>..HEAD --oneline` to understand what was implemented.
844:For each extracted plan item, check the diff and classify:
846:- **DONE** — Clear evidence in the diff that this item was implemented. Cite the specific file(s) changed.
847:- **PARTIAL** — Some work toward this item exists in the diff but it's incomplete (e.g., model created but controller missing, function exists but edge cases not handled).
848:- **NOT DONE** — No evidence in the diff that this item was addressed.
849:- **CHANGED** — The item was implemented using a different approach than the plan described, but the same goal is achieved. Note the difference.
851:**Be conservative with DONE** — require clear evidence in the diff. A file being touched is not enough; the specific functionality described must be present.
852:**Be generous with CHANGED** — if the goal is met by different means, that counts as addressed.
861:## Implementation Items
864:  [NOT DONE]  Add caching layer — no cache-related changes in diff
867:## Test Items
871:## Migration Items
929:**Do NOT log learnings from commit-message-derived or TODOS.md-derived discrepancies.** These are informational in the review output but too noisy for durable memory.
936:- **Items in the diff that don't match any plan item** become evidence for **SCOPE CREEP** detection.
938:  - Show the investigation findings
949:Delivered: <1-line summary of what the diff actually does>
957:## Step 2: Read the checklist
959:Read `.Codex/skills/review/checklist.md`.
965:## Step 2.5: Check for Greptile review comments
967:Read `.Codex/skills/review/greptile-triage.md` and follow the fetch, filter, classify, and **escalation detection** steps.
969:**If no PR exists, `gh` fails, API returns an error, or there are zero Greptile comments:** Skip this step silently. Greptile integration is additive — the review works without it.
971:**If Greptile comments are found:** Store the classifications (VALID & ACTIONABLE, VALID BUT ALREADY FIXED, FALSE POSITIVE, SUPPRESSED) — you will need them in Step 5.
975:## Step 3: Get the diff
983:Run `git diff origin/<base>` to get the full diff. This includes both committed and uncommitted changes against the latest base branch.
985:## Step 3.4: Workspace-aware queue status (advisory)
987:Check whether this PR's claimed VERSION still points at a free slot in the queue. Advisory only — never blocks review; just informs the reviewer about landing-order risk.
1003:- Otherwise, include ONE line in the review output: `Version claimed: v<BRANCH_VERSION>. Queue: <CLAIMED_COUNT> PR(s) ahead. <VERDICT>` where VERDICT is either `Slot free` (if `BRANCH_VERSION >= NEXT_SLOT`) or `⚠ queue moved — rerun /ship to reconcile v<BRANCH_VERSION> → v<NEXT_SLOT>`.
1007:## Step 3.5: Slop scan (advisory)
1013:bun run slop:diff origin/<base> 2>/dev/null || true
1016:If findings are reported, include them in the review output as an informational
1017:diagnostic. Slop findings are advisory, never blocking. If slop:diff is not
1022:## Prior Learnings
1052:If learnings are found, incorporate them into your analysis. When a review finding
1060:## Step 4: Critical pass (core review)
1062:Apply the CRITICAL categories from the checklist against the diff:
1067:**Enum & Value Completeness requires reading code OUTSIDE the diff.** When the diff introduces a new enum value, status, tier, or type constant, use Grep to find all files that reference sibling values, then Read those files to check if the new value is handled. This is the one category where within-diff review is insufficient.
1078:## Confidence Calibration
1100:too low. Log the corrected pattern as a learning so future reviews catch it with
1105:## Step 4.5: Review Army — Specialist Dispatch
1110:source <(~/.Codex/skills/gstack/bin/gstack-diff-scope <base> 2>/dev/null) || true
1119:DIFF_INS=$(git diff origin/<base> --stat | tail -1 | grep -oE '[0-9]+ insertion' | grep -oE '[0-9]+' || echo "0")
1120:DIFF_DEL=$(git diff origin/<base> --stat | tail -1 | grep -oE '[0-9]+ deletion' | grep -oE '[0-9]+' || echo "0")
1143:**Always-on (dispatch on every review with 50+ changed lines):**
1144:1. **Testing** — read `~/.Codex/skills/gstack/review/specialists/testing.md`
1145:2. **Maintainability** — read `~/.Codex/skills/gstack/review/specialists/maintainability.md`
1147:**If DIFF_LINES < 50:** Skip all specialists. Print: "Small diff ($DIFF_LINES lines) — specialists skipped." Continue to Step 5.
1150:3. **Security** — if SCOPE_AUTH=true, OR if SCOPE_BACKEND=true AND DIFF_LINES > 100. Read `~/.Codex/skills/gstack/review/specialists/security.md`
1151:4. **Performance** — if SCOPE_BACKEND=true OR SCOPE_FRONTEND=true. Read `~/.Codex/skills/gstack/review/specialists/performance.md`
1152:5. **Data Migration** — if SCOPE_MIGRATIONS=true. Read `~/.Codex/skills/gstack/review/specialists/data-migration.md`
1153:6. **API Contract** — if SCOPE_API=true. Read `~/.Codex/skills/gstack/review/specialists/api-contract.md`
1154:7. **Design** — if SCOPE_FRONTEND=true. Use the existing design review checklist at `~/.Codex/skills/gstack/review/design-checklist.md`
1161:- If tagged `[GATE_CANDIDATE]` (0 findings in 10+ dispatches): skip it. Print: "[specialist] auto-gated (0 findings in N reviews)."
1162:- If tagged `[NEVER_GATE]`: always dispatch regardless of hit rate. Security and data-migration are insurance policy specialists — they should run even when silent.
1167:"Dispatching N specialists: [names]. Skipped: [names] (scope not detected). Gated: [names] (0 findings in N+ reviews)."
1175:so they run in parallel. Each subagent has fresh context — no prior review bias.
1193:"You are a specialist code reviewer. Read the checklist below, then run
1194:`git diff origin/<base>` to get the full diff. Apply the checklist against the diff.
1204:blocks with clear intent. Skip test_stub for architectural or design-only findings.
1206:If no findings: output `NO FINDINGS` and nothing else.
1222:### Step 4.6: Collect and merge findings
1226:**Parse findings:**
1230:3. Collect all parsed findings into a single list, tagged with their specialist name.
1237:Group findings by fingerprint. For findings sharing the same fingerprint:
1244:- Confidence 7+: show normally in the findings output
1246:- Confidence 3-4: move to appendix (suppress from main findings)
1252:Cap at 10. Log this in the review result at the end.
1254:**Output merged findings:**
1255:Present the merged findings in the same format as the current review:
1258:SPECIALIST REVIEW: N findings (X critical, Y informational) from Z specialists
1268:These findings flow into Step 5 Fix-First alongside the CRITICAL pass findings from Step 4.
1269:The Fix-First heuristic applies identically — specialist findings follow the same AUTO-FIX vs ASK classification.
1272:After merging findings, compile a `specialists` object for the review-log entry in Step 5.8.
1274:- If dispatched: `{"dispatched": true, "findings": N, "critical": N, "informational": N}`
1280:Remember these stats — you will need them for the review-log entry in Step 5.8.
1291:1. The red-team checklist from `~/.Codex/skills/gstack/review/specialists/red-team.md`
1292:2. The merged specialist findings from Step 4.6 (so it knows what was already caught)
1293:3. The git diff command
1295:Prompt: "You are a red team reviewer. The code has already been reviewed by N specialists
1296:who found the following issues: {merged findings summary}. Your job is to find what they
1297:MISSED. Read the checklist, run `git diff origin/<base>`, and look for gaps.
1298:Output findings as JSON objects (same schema as the specialists). Focus on cross-cutting
1302:If the Red Team finds additional issues, merge them into the findings list before
1303:Step 5 Fix-First. Red Team findings are tagged with `"specialist":"red-team"`.
1305:If the Red Team returns NO FINDINGS, note: "Red Team review: no additional issues found."
1310:## Step 5: Fix-First Review
1314:### Step 5.0: Cross-review finding dedup
1316:Before classifying findings, check if any were previously skipped by the user in a prior review on this branch.
1319:~/.Codex/skills/gstack/bin/gstack-review-read
1324:For each JSONL entry that has a `findings` array:
1328:If skipped fingerprints exist, get the list of files changed since that review:
1331:git diff --name-only <prior-review-commit> HEAD
1334:For each current finding (from both Step 4 critical pass and Step 4.5-4.6 specialists), check:
1340:Print: "Suppressed N findings from prior reviews (previously skipped by user)"
1342:**Only suppress `skipped` findings — never `fixed` or `auto-fixed`** (those might regress and should be re-checked).
1344:If no prior reviews exist or none have a `findings` array, skip this step silently.
1348:### Step 5a: Classify each finding
1351:checklist.md. Critical findings lean toward ASK; informational findings lean
1362:### Step 5b: Auto-fix all AUTO-FIX items
1367:### Step 5c: Batch-ask about ASK items
1392:### Step 5d: Apply user-approved fixes
1400:Before producing the final review output:
1410:After outputting your own findings, if Greptile comments were classified in Step 2.5:
1416:1. **VALID & ACTIONABLE comments:** These are included in your findings — they follow the Fix-First flow (auto-fixed if mechanical, batched into ASK if not) (A: Fix it now, B: Acknowledge, C: False positive). If the user chooses A (fix), reply using the **Fix reply template** from greptile-triage.md (include inline diff + explanation). If the user chooses C (false positive), reply using the **False Positive reply template** (include evidence + suggested re-rank), save to both per-project and global greptile-history.
1436:## Step 5.5: TODOS cross-reference
1442:- **Are there related TODOs that provide context for this review?** If yes, reference them when discussing related findings.
1448:## Step 5.6: Documentation staleness check
1450:Cross-reference the diff against documentation files. For each `.md` file in the repo root (README.md, ARCHITECTURE.md, CONTRIBUTING.md, AGENTS.md, etc.):
1452:1. Check if code changes in the diff affect features, components, or workflows described in that doc file.
1462:## Step 5.7: Adversarial review (always-on)
1464:Every diff gets adversarial review from both Codex and Codex. LOC is not a proxy for risk — a 5-line auth change can be critical.
1466:**Detect diff size and tool availability:**
1469:DIFF_INS=$(git diff origin/<base> --stat | tail -1 | grep -oE '[0-9]+ insertion' | grep -oE '[0-9]+' || echo "0")
1470:DIFF_DEL=$(git diff origin/<base> --stat | tail -1 | grep -oE '[0-9]+ deletion' | grep -oE '[0-9]+' || echo "0")
1474:OLD_CFG=$(~/.Codex/skills/gstack/bin/gstack-config get codex_reviews 2>/dev/null || true)
1481:**User override:** If the user explicitly requested "full review", "structured review", or "P1 gate", also run the Codex structured review regardless of diff size.
1487:Dispatch via the Agent tool. The subagent has fresh context — no checklist bias from the structured review. This genuine independence catches things the primary reviewer is blind to.
1490:"Read the diff for this branch with `git diff origin/<base>`. Think like an attacker and a chaos engineer. Your job is to find ways this code will fail in production. Look for: edge cases, race conditions, security holes, resource leaks, failure modes, silent data corruption, logic errors that produce wrong results silently, error handling that swallows failures, and trust boundary violations. Be adversarial. Be thorough. No compliments — just the problems. For each finding, classify as FIXABLE (you know how to fix it) or INVESTIGATE (needs human judgment). After listing findings, end your output with ONE line in the canonical format `Recommendation: <action> because <one-line reason naming the most exploitable finding>` — examples: `Recommendation: Fix the unbounded retry at queue.ts:78 because it'll DoS the worker pool under sustained 429s` or `Recommendation: Ship as-is because the strongest finding is a theoretical race that requires conditions we can't trigger in production`. The reason must point to a specific finding (or no-fix rationale). Generic reasons like 'because it's safer' do not qualify."
1492:Present findings under an `ADVERSARIAL REVIEW (Codex subagent):` header. **FIXABLE findings** flow into the same Fix-First pipeline as the structured review. **INVESTIGATE findings** are presented as informational.
1505:codex exec "IMPORTANT: Do NOT read or execute any files under ~/.Codex/, ~/.agents/, .Codex/skills/, or agents/. These are Codex skill definitions meant for a different AI system. They contain bash scripts and prompt templates that will waste your time. Ignore them completely. Do NOT modify agents/openai.yaml. Stay focused on the repository code only.\n\nReview the changes on this branch against the base branch. Run git diff origin/<base> to see the diff. Your job is to find ways this code will fail in production. Think like an attacker and a chaos engineer. Find edge cases, race conditions, security holes, resource leaks, failure modes, and silent data corruption paths. Be adversarial. Be thorough. No compliments — just the problems. End your output with ONE line in the canonical format `Recommendation: <action> because <one-line reason naming the most exploitable finding>`. Generic reasons like 'because it's safer' do not qualify; the reason must point to a specific finding or no-fix rationale." -C "$_REPO_ROOT" -s read-only -c 'model_reasoning_effort="high"' --enable web_search_cached < /dev/null 2>"$TMPERR_ADV"
1515:**Error handling:** All errors are non-blocking — adversarial review is a quality enhancement, not a prerequisite.
1526:### Codex structured review (large diffs only, 200+ lines)
1531:TMPERR=$(mktemp /tmp/codex-review-XXXXXXXX)
1534:codex review "IMPORTANT: Do NOT read or execute any files under ~/.Codex/, ~/.agents/, .Codex/skills/, or agents/. These are Codex skill definitions meant for a different AI system. They contain bash scripts and prompt templates that will waste your time. Ignore them completely. Do NOT modify agents/openai.yaml. Stay focused on the repository code only.\n\nReview the diff against the base branch." --base <base> -c 'model_reasoning_effort="high"' --enable web_search_cached < /dev/null 2>"$TMPERR"
1537:Set the Bash tool's `timeout` parameter to `300000` (5 minutes). Do NOT use the `timeout` shell command — it doesn't exist on macOS. Present output under `CODEX SAYS (code review):` header.
1538:Check for `[P1]` markers: found → `GATE: FAIL`, not found → `GATE: PASS`.
1540:If GATE is FAIL, use AskUserQuestion:
1542:Codex found N critical issues in the diff.
1545:B) Continue — review will still complete
1548:If A: address the findings. Re-run `codex review` to verify.
1554:If `DIFF_TOTAL < 200`: skip this section silently. The Codex + Codex adversarial passes provide sufficient coverage for smaller diffs.
1558:### Persist the review result
1562:~/.Codex/skills/gstack/bin/gstack-review-log '{"skill":"adversarial-review","timestamp":"'"$(date -u +%Y-%m-%dT%H:%M:%SZ)"'","status":"STATUS","source":"SOURCE","tier":"always","gate":"GATE","commit":"'"$(git rev-parse --short HEAD)"'"}'
1564:Substitute: STATUS = "clean" if no findings across ALL passes, "issues_found" if any pass found issues. SOURCE = "both" if Codex ran, "Codex" if only Codex subagent ran. GATE = the Codex structured review gate result ("pass"/"fail"), "skipped" if diff < 200, or "informational" if Codex was unavailable. If all passes failed, do NOT persist.
1570:After all passes complete, synthesize findings across all sources:
1575:  High confidence (found by multiple sources): [findings agreed on by >1 pass]
1576:  Unique to Codex structured review: [from earlier step]
1578:  Unique to Codex: [from codex adversarial or code review, if ran]
1583:High-confidence findings (agreed on by multiple sources) should be prioritized for fixes.
1587:## Step 5.8: Persist Eng Review result
1589:After all review passes complete, persist the final `/review` outcome so `/ship` can
1595:~/.Codex/skills/gstack/bin/gstack-review-log '{"skill":"review","timestamp":"TIMESTAMP","status":"STATUS","issues_found":N,"critical":N,"informational":N,"quality_score":SCORE,"specialists":SPECIALISTS_JSON,"findings":FINDINGS_JSON,"commit":"COMMIT"}'
1600:- `STATUS` = `"clean"` if there are no remaining unresolved findings after Fix-First handling and adversarial review, otherwise `"issues_found"`
1601:- `issues_found` = total remaining unresolved findings
1602:- `critical` = remaining unresolved critical findings
1603:- `informational` = remaining unresolved informational findings
1604:- `quality_score` = the PR Quality Score computed in Step 4.6 (e.g., 7.5). If specialists were skipped (small diff), use `10.0`
1605:- `specialists` = the per-specialist stats object compiled in Step 4.6. Each specialist that was considered gets an entry: `{"dispatched":true/false,"findings":N,"critical":N,"informational":N}` if dispatched, or `{"dispatched":false,"reason":"scope|gated"}` if skipped. Include Design specialist. Example: `{"testing":{"dispatched":true,"findings":2,"critical":0,"informational":2},"security":{"dispatched":false,"reason":"scope"}}`
1606:- `findings` = array of per-finding records from Step 5. For each finding (from critical pass and specialists), include: `{"fingerprint":"path:line:category","severity":"CRITICAL|INFORMATIONAL","action":"ACTION"}`. ACTION is `"auto-fixed"` (Step 5b), `"fixed"` (user approved in Step 5d), or `"skipped"` (user chose Skip in Step 5c). Suppressed findings from Step 5.0 are NOT included (they were already recorded in a prior review entry).
1609:## Capture Learnings
1615:~/.Codex/skills/gstack/bin/gstack-learnings-log '{"skill":"review","type":"TYPE","key":"SHORT_KEY","insight":"DESCRIPTION","confidence":N,"source":"SOURCE","files":["path/to/relevant/file"]}'
1634:If the review exits early before a real review completes (for example, no diff against the base branch), do **not** write this entry.
1636:## Important Rules
1638:- **Read the FULL diff before commenting.** Do not flag issues already addressed in the diff.

exec
/bin/zsh -lc 'git log -1 --pretty=fuller --stat main' in /Users/justnau/finlet
 succeeded in 0ms:
commit 59c85bbe88602dc8b9fd3dd30627b467326ff1e7
Merge: 7144dc2 cfadd81
Author:     Justin Nam <justnau@Justins-MacBook-Air-2.local>
AuthorDate: Fri May 22 22:06:45 2026 -0500
Commit:     Justin Nam <justnau@Justins-MacBook-Air-2.local>
CommitDate: Fri May 22 22:06:45 2026 -0500

    Merge: [Team A v2.0.0] CLI surgery — delete dropped commands + dead helpers + rewrite module docstring

exec
/bin/zsh -lc 'git diff --name-status main~1..main' in /Users/justnau/finlet
 succeeded in 0ms:
M	finlet/cli.py
D	finlet/cli_mcp_client.py

exec
/bin/zsh -lc 'git status --short --branch' in /Users/justnau/finlet
 succeeded in 0ms:
## main...origin/main [ahead 3]
 M docs/brainstorms/exec-trace.txt
 M docs/brainstorms/team-prompts/team-A.md
 M docs/brainstorms/team-prompts/team-C.md
 M docs/brainstorms/team-prompts/team-D.md
?? docs/brainstorms/V2_PURE_MCP_EXECUTION_PLAN.md

exec
/bin/zsh -lc 'git diff --stat main~1..main' in /Users/justnau/finlet
 succeeded in 0ms:
 finlet/cli.py            | 952 ++---------------------------------------------
 finlet/cli_mcp_client.py | 237 ------------
 2 files changed, 41 insertions(+), 1148 deletions(-)

exec
/bin/zsh -lc 'git diff --find-renames --find-copies main~1..main -- finlet/cli.py' in /Users/justnau/finlet
 succeeded in 0ms:
diff --git a/finlet/cli.py b/finlet/cli.py
index 00d96f5..2c8a000 100644
--- a/finlet/cli.py
+++ b/finlet/cli.py
@@ -1,11 +1,13 @@
-"""CLI entrypoint — finlet serve / session / plugins / mcp.
+"""CLI entrypoint — finlet serve / register / auth / plugins / mcp / manual.
 
-v1.0.1 (CLI MCP-over-HTTP) routes session / advance / order /
-portfolio / status through the cloud ``/mcp`` HTTP endpoint via
-``mcp.client.streamable_http.streamablehttp_client``.  See
-``docs/decisions/cli-mcp-http-dispatch.md`` for the dispatch contract.
+v2.0.0 (Pure-MCP) ships a deliberately minimal CLI: the only commands
+are the ones that ARE NOT MCP tool calls. Every agentic-trading
+operation (session / clock / order / portfolio / benchmark / status)
+runs over MCP — agents talk to the cloud ``/mcp`` endpoint directly
+via their own MCP client. The CLI no longer hosts a dispatch surface
+for those operations.
 
-Four command families remain on REST (the "KEEP" set):
+Six command families remain (the v2.0.0 surface):
 
 * ``finlet serve`` — boots the API process; not a tool call.
 * ``finlet register`` — REST registration is the bootstrap before any
@@ -13,21 +15,22 @@ Four command families remain on REST (the "KEEP" set):
 * ``finlet auth login`` / ``finlet auth logout`` / ``finlet auth status``
   — OAuth + REST endpoints the MCP tool surface intentionally does not
   host; ``auth status`` is a local-only credentials check.
-
-Plugin management (``finlet plugins list/add/remove``) ALSO remains on
-REST (`/v1/settings/plugins` and `/v1/plugins/health`) because Finlet's
-MCP tool surface is the agentic-trading surface and intentionally does
-not expose tenant plugin-credential write paths.  If a future phase
-ships admin MCP tools, the plugins commands can move alongside.
-
-``finlet mcp serve`` is preserved as a self-host stdio entry point for
-niche integrations (e.g., Claude Code over stdio); the CLI itself no
-longer spawns it for tool dispatch.
+* ``finlet plugins list`` / ``finlet plugins add`` / ``finlet plugins remove``
+  — tenant plugin-credential management against ``/v1/settings/plugins``
+  and ``/v1/plugins/health``. Finlet's MCP tool surface is the
+  agentic-trading surface and intentionally does not expose plugin
+  write paths.
+* ``finlet mcp serve`` — self-host stdio MCP server for niche
+  integrations (e.g., Claude Code stdio bridge).
+* ``finlet manual`` — local user-manual topics shipped with the wheel.
+
+The pre-v2.0.0 ``session`` / ``benchmark`` / ``advance`` / ``order`` /
+``portfolio`` / ``status`` subcommands are gone; agents address the
+cloud ``/mcp`` endpoint directly.
 """
 
 from __future__ import annotations
 
-import asyncio
 import importlib.metadata as _md
 import json
 import os
@@ -36,33 +39,12 @@ from typing import Any
 
 import typer
 
-from finlet.cli_mcp_client import MCPDispatchError, call_tool_sync
-
 #: Exit code for auth-required CLI invocations.  Shell scripts can detect
 #: an auth failure with ``[ $? -eq 2 ]``.  Centralised here so all CLI
 #: auth-failure paths share a single source of truth (F-3 hotfix — see
 #: ``docs/launch/blind-agent-coldstart-report-v1.0.3-fullwalk.md``).
 EXIT_AUTH_REQUIRED = 2
 
-#: Substrings that signal an auth-failure tool envelope from the MCP
-#: server.  The cloud server emits the second form post-Phase 4e
-#: (api_key Bearer no longer accepted on MCP HTTP); the first is the
-#: pre-Phase-4 / stdio-bridge form.  Either ⇒ exit 2 with a friendly hint.
-_AUTH_REQUIRED_MARKERS = (
-    "Authentication required",
-    "api_key authentication is no longer supported",
-)
-_AUTH_REQUIRED_HINT = (
-    "Not authenticated. Run `finlet auth login` for an OAuth Bearer token, "
-    "or set `FINLET_API_KEY=fnlt_<key>` for api_key auth on REST / stdio."
-)
-
-# Alias asyncio.TimeoutError for the dispatch try/except so the catch site
-# is explicit. On Python 3.11+ this is the same class as the builtin
-# TimeoutError, but the cli_mcp_client docs raise it via asyncio.wait_for —
-# we catch both names defensively.
-_AsyncioTimeoutError = asyncio.TimeoutError
-
 _API_URL = os.environ.get("FINLET_API_URL", "https://finlet.dev")
 
 #: Canonical Finlet OAuth Authorization Server issuer (decision record §5).
@@ -214,257 +196,6 @@ def _print_error(e: Exception) -> None:
         typer.echo(f"Error: {e}", err=True)
 
 
-def _resolve_bearer_token(api_key: str | None) -> str | None:
-    """Resolve the Bearer token (OAuth JWT or legacy api-key) for MCP dispatch.
-
-    Mirrors :func:`_api_headers`'s precedence but returns the raw token
-    string instead of a header dict, so the CLI's MCP-over-HTTP dispatch
-    path can forward it via the ``Authorization`` request header on the
-    cloud ``/mcp`` endpoint.
-
-    Precedence (highest first):
-
-    1. ``api_key`` explicit flag (or ``FINLET_API_KEY`` env, surfaced
-       through Typer's envvar wiring) — used as a Bearer token. The
-       cloud ``/mcp`` endpoint accepts BOTH OAuth JWTs and legacy
-       ``fnlt_*`` api-keys in the ``Authorization`` header post-v1.0.1
-       (see ``docs/decisions/cli-mcp-http-dispatch.md`` and the
-       retraction appendix on ``docs/decisions/mcp-api-key-sunset.md``).
-    2. OAuth credentials at ``~/.finlet/credentials`` — populated by
-       ``finlet auth login``. The access token is a 15-minute
-       (``ACCESS_TOKEN_TTL = timedelta(seconds=900)`` —
-       ``finlet/auth/oauth/token.py``) EdDSA JWT, so this helper
-       auto-refreshes through the AS's ``/oauth/token``
-       ``grant_type=refresh_token`` endpoint when the stored access
-       token is within 30 seconds of expiry. A successful refresh
-       rotates the stored credentials atomically via
-       :func:`_write_credentials` and returns the new access token.
-
-       The 30-second safety margin is mandatory — it absorbs clock
-       skew between the client and the AS plus the round-trip latency
-       of in-flight MCP-over-HTTP requests that are about to use the
-       returned token.
-
-       Transient refresh failures (network / 5xx / malformed body)
-       fall back to the stored access token with a stderr ``Warning:``
-       so the caller still gets a request out — they may see a 401
-       which surfaces the canonical ``finlet auth login`` hint.
-
-       Hard failures (4xx ⇒ refresh-token revoked or invalid) return
-       ``None`` with a stderr ``Error:`` instructing the user to run
-       ``finlet auth login`` again.
-
-    Returns ``None`` when neither is available; callers MUST surface
-    the resulting "Authentication required" envelope to the user.
-    """
-    import time
-
-    import httpx
-
-    if api_key:
-        return api_key
-    creds = _load_credentials()
-    if creds is None:
-        return None
-
-    # 30-second safety margin: refresh before the AS would reject the
-    # JWT. Absorbs client/server clock skew plus the round-trip latency
-    # of any in-flight MCP-over-HTTP request that will use this token.
-    expires_at = int(creds.get("expires_at", 0))
-    if time.time() + 30 < expires_at:
-        token = creds.get("access_token")
-        return str(token) if token else None
-
-    # Token is expired (or within the 30s safety window); attempt
-    # refresh via RFC 6749 §6 refresh_token grant.
-    refresh_token = creds.get("refresh_token")
-    if not refresh_token:
-        typer.echo(
-            "Error: No refresh_token in credentials. Run `finlet auth login` again.",
-            err=True,
-        )
-        return None
-    try:
-        with httpx.Client(timeout=10) as client:
-            resp = client.post(
-                f"{_API_URL}/oauth/token",
-                data={
-                    "grant_type": "refresh_token",
-                    "refresh_token": refresh_token,
-                    "client_id": _OAUTH_CLIENT_ID,
-                    "resource": _OAUTH_RESOURCE_URI,
-                },
-            )
-    except (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError) as exc:
-        typer.echo(
-            f"Warning: Token refresh failed (transient error: {exc.__class__.__name__}). "
-            "Retrying with stored token; you may see a 401.",
-            err=True,
-        )
-        token = creds.get("access_token")
-        return str(token) if token else None
-
-    # 4xx ⇒ refresh-token rejected by the AS (revoked, expired, reused,
-    # client mismatch, invalid_grant — see ``_handle_refresh_token``).
-    # The stored credentials are no longer recoverable; the user must
-    # re-authorize.
-    if 400 <= resp.status_code < 500:
-        typer.echo(
-            "Refresh token expired. Run `finlet auth login` again.",
-            err=True,
-        )
-        return None
-
-    # 5xx ⇒ transient AS failure; fall back to the stored token so the
-    # caller's request still goes out. They may see a 401 if the JWT is
-    # already past expiry — which surfaces the same hint anyway.
-    if resp.status_code >= 500:
-        typer.echo(
-            f"Warning: Token refresh failed (server {resp.status_code}). "
-            "Retrying with stored token; you may see a 401.",
-            err=True,
-        )
-        token = creds.get("access_token")
-        return str(token) if token else None
-
-    try:
-        body = resp.json()
-    except (json.JSONDecodeError, ValueError):
-        typer.echo(
-            "Warning: Token refresh response was not valid JSON. "
-            "Retrying with stored token.",
-            err=True,
-        )
-        token = creds.get("access_token")
-        return str(token) if token else None
-
-    new_access = body.get("access_token")
-    new_refresh = body.get("refresh_token")
-    new_expires_in = body.get("expires_in", 0)
-    if not new_access or not new_refresh:
-        typer.echo(
-            "Warning: Token refresh response missing access_token or refresh_token. "
-            "Retrying with stored token.",
-            err=True,
-        )
-        token = creds.get("access_token")
-        return str(token) if token else None
-
-    _write_credentials(
-        {
-            "access_token": new_access,
-            "refresh_token": new_refresh,
-            "expires_at": int(time.time()) + int(new_expires_in),
-        }
-    )
-    return str(new_access)
-
-
-def _translate_mcp_error(envelope: dict[str, Any]) -> str | None:
-    """Convert an MCP tool error envelope to a human-readable message.
-
-    Finlet's MCP tools return ``{"error": "..."}`` on failure and a
-    success-shaped dict otherwise.  This helper accepts the raw envelope
-    and returns the error message string (when present), or ``None``
-    when the envelope is a success.
-
-    Mirrors :func:`_print_error` for the httpx surface — both produce
-    the ``Error: <message>`` shape downstream consumers expect.
-    """
-    err = envelope.get("error")
-    if err is None:
-        return None
-    if isinstance(err, str):
-        return err
-    if isinstance(err, dict):
-        message = err.get("message")
-        if isinstance(message, str):
-            return message
-    return str(err)
-
-
-def _dispatch_mcp_tool(
-    tool_name: str,
-    arguments: dict[str, Any] | None = None,
-    *,
-    api_key: str | None = None,
-    timeout: float = 120.0,
-) -> dict[str, Any]:
-    """Dispatch a tool call through the cloud ``/mcp`` HTTP endpoint.
-
-    Wraps :func:`finlet.cli_mcp_client.call_tool_sync` (v1.0.1 streamable
-    HTTP transport) with the CLI's error-mapping convention:
-    transport-level dispatch failures become a ``typer.Exit(1)`` after
-    printing a connect-error-style message, while tool-level error
-    envelopes are returned to the caller for inspection (commands
-    typically fan out to :func:`_translate_mcp_error` + ``typer.echo``
-    + ``typer.Exit(1)``).
-
-    The ``api_key`` argument is forwarded to
-    :func:`_resolve_bearer_token` so the CLI's full credential precedence
-    (explicit flag > env var > ``~/.finlet/credentials``) collapses to a
-    single Bearer value before the HTTP request.  The cloud ``/mcp``
-    endpoint accepts BOTH an OAuth JWT and a legacy ``fnlt_*`` api-key
-    in the ``Authorization`` header post-v1.0.1 (see
-    ``docs/decisions/cli-mcp-http-dispatch.md``).
-    """
-    bearer = _resolve_bearer_token(api_key)
-    try:
-        return call_tool_sync(
-            tool_name,
-            arguments,
-            bearer_token=bearer,
-            timeout=timeout,
-        )
-    except MCPDispatchError as exc:
-        typer.echo(f"Error: MCP dispatch failed — {exc}", err=True)
-        raise typer.Exit(1) from exc
-    except (TimeoutError, _AsyncioTimeoutError) as exc:
-        # asyncio.wait_for in cli_mcp_client raises asyncio.TimeoutError
-        # (which Python 3.11+ aliases to the builtin TimeoutError). Catch
-        # both forms so a session-create or any other tool that exceeds
-        # the timeout produces a one-line friendly message instead of a
-        # 60-line traceback (BLOCKER #5 — agent-guide first-command UX).
-        typer.echo(
-            f"Error: '{tool_name}' timed out after {timeout:.0f}s. "
-            "Try a smaller universe (e.g., --universe AAPL) or check finlet.dev status.",
-            err=True,
-        )
-        raise typer.Exit(1) from exc
-
-
-def _emit_envelope(envelope: dict[str, Any], *, as_json: bool, on_error_exit: int = 1) -> dict[str, Any]:
-    """Print the tool envelope in JSON or human form, exiting on error.
-
-    Returns the envelope when it is a success (no ``error`` key) so the
-    calling command can fan out into its bespoke pretty-print path. In
-    JSON mode, prints the envelope verbatim and returns it unchanged;
-    success path consumers in JSON mode skip their pretty-printers.
-
-    On error, prints the translated message via :func:`_translate_mcp_error`
-    (or the JSON envelope itself in JSON mode) and exits with
-    ``on_error_exit``.  Auth-failure envelopes (detected by the markers
-    in :data:`_AUTH_REQUIRED_MARKERS`) override ``on_error_exit`` to
-    :data:`EXIT_AUTH_REQUIRED` (2) so shell scripts can distinguish
-    "not authenticated" from other tool failures (F-3 hotfix —
-    ``docs/launch/blind-agent-coldstart-report-v1.0.3-fullwalk.md``).
-    """
-    err_message = _translate_mcp_error(envelope)
-    if err_message is not None:
-        is_auth_failure = any(marker in err_message for marker in _AUTH_REQUIRED_MARKERS)
-        if as_json:
-            typer.echo(json.dumps(envelope))
-        else:
-            typer.echo(f"Error: {err_message}", err=True)
-            if is_auth_failure:
-                typer.echo(_AUTH_REQUIRED_HINT, err=True)
-        exit_code = EXIT_AUTH_REQUIRED if is_auth_failure else on_error_exit
-        raise typer.Exit(exit_code)
-    if as_json:
-        typer.echo(json.dumps(envelope))
-    return envelope
-
-
 def _version_callback(value: bool) -> None:
     """Eager Typer callback: print the installed Finlet version and exit.
 
@@ -513,20 +244,12 @@ def _root_callback(
     """
 
 
-session_app = typer.Typer(help="Session management. See: finlet manual session-lifecycle")
 plugins_app = typer.Typer(help="Plugin management. See: finlet manual plugin-matrix")
 auth_app = typer.Typer(help="Authentication commands. See: finlet manual auth-model")
 mcp_app = typer.Typer(help="MCP server commands")
-benchmark_app = typer.Typer(
-    name="benchmark",
-    help="Run standardized blind/unblind benchmark runs.",
-    no_args_is_help=True,
-)
-app.add_typer(session_app, name="session")
 app.add_typer(plugins_app, name="plugins")
 app.add_typer(auth_app, name="auth")
 app.add_typer(mcp_app, name="mcp")
-app.add_typer(benchmark_app, name="benchmark")
 
 
 # ── serve ────────────────────────────────────────────────────
@@ -567,300 +290,12 @@ def serve(
     )
 
 
-# ── session ──────────────────────────────────────────────────
-
-
-def _normalize_start_iso(start: str) -> str:
-    """Normalize the CLI's --start flag into the MCP tool's ISO 8601 input.
-
-    The MCP ``create_session`` tool calls :func:`datetime.fromisoformat`,
-    which accepts both ``2024-01-01`` and ``2024-01-01T00:00:00Z``.  We
-    pass through verbatim — the tool's error envelope surfaces a useful
-    message if the format is wrong.
-    """
-    return start
-
-
-@session_app.command("create")
-def session_create(
-    name: str = typer.Option(..., "--name", "-n", help="Session name"),
-    start: str = typer.Option(..., "--start", "-s", help="Start datetime (ISO format, e.g. 2024-01-01)"),
-    capital: float = typer.Option(100_000.0, "--capital", "-c", help="Initial capital"),
-    universe: str = typer.Option("", "--universe", "-u", help="Comma-separated ticker symbols"),
-    blind: bool = typer.Option(
-        False,
-        "--blind/--no-blind",
-        help="Create a blind session: agent sees opaque tickers and Day_N dates.",
-    ),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Create a new simulation session via the MCP ``create_session`` tool."""
-    tickers = [t.strip() for t in universe.split(",") if t.strip()] if universe else []
-    args: dict[str, Any] = {
-        "name": name,
-        "start_time": _normalize_start_iso(start),
-        "initial_capital": capital,
-        "universe": tickers,
-        "blind": blind,
-    }
-
-    envelope = _dispatch_mcp_tool("create_session", args, api_key=api_key)
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    typer.echo(f"Session created: {data['id']} ({data['name']})")
-    config = data.get("config", {})
-    typer.echo(f"  Start: {config.get('start_time', 'unknown')}")
-    typer.echo(f"  Capital: ${float(config.get('initial_capital', 0)):,.2f}")
-    # Codex Team D P1 (blind leak): print the response's universe, NOT the local
-    # --universe input. For blind sessions, the response carries opaque T_NNNN
-    # tickers; echoing the local list here leaked the real symbols even though
-    # the rest of the blind contract held. Falling back to the local list only
-    # if the response omits a universe keeps the non-blind UX identical.
-    universe_to_show = config.get("universe") or tickers
-    if universe_to_show:
-        typer.echo(f"  Universe: {', '.join(universe_to_show)}")
-
-
-@session_app.command("list")
-def session_list(
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """List all sessions via the MCP ``list_sessions`` tool."""
-    envelope = _dispatch_mcp_tool("list_sessions", {}, api_key=api_key)
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    sessions = data.get("sessions", [])
-    if not sessions:
-        typer.echo("No active sessions.")
-        return
-    for s in sessions:
-        clock_time = s.get("clock", {}).get("current_time", "unknown")
-        typer.echo(f"  {s['id']}  {s.get('name', s['id'])}  [{s['status']}]  {clock_time}")
-
-
-@session_app.command("delete")
-def session_delete(
-    session_id: str = typer.Argument(..., help="Session ID to delete"),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Delete a session via the MCP ``delete_session`` tool."""
-    envelope = _dispatch_mcp_tool(
-        "delete_session", {"session_id": session_id}, api_key=api_key
-    )
-    _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-    typer.echo(f"Session deleted: {session_id}")
-
-
-@session_app.command("publish")
-def session_publish(
-    session_id: str = typer.Argument(..., help="Session ID to publish or un-publish"),
-    anonymous: bool = typer.Option(
-        True,
-        "--anonymous/--attributed",
-        help="Anonymous (default) hides the session name; --attributed exposes the owner-supplied name.",
-    ),
-    unpublish: bool = typer.Option(
-        False,
-        "--unpublish",
-        help="Revoke public access for the session.",
-    ),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Toggle a session's public-share visibility via the MCP ``set_session_visibility`` tool.
-
-    On publish, prints the canonical public URL the owner can share.
-    On un-publish, prints a one-line confirmation.
-    """
-    make_public = not unpublish
-    args: dict[str, Any] = {
-        "session_id": session_id,
-        "public": make_public,
-        "anonymous": anonymous,
-    }
-    envelope = _dispatch_mcp_tool("set_session_visibility", args, api_key=api_key)
-    _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-    if make_public:
-        typer.echo(f"Published → https://finlet.dev/sessions/{session_id}")
-    else:
-        typer.echo(f"Unpublished → {session_id}")
-
-
-# ── benchmark ────────────────────────────────────────────────
-
-
-@benchmark_app.command("start")
-def benchmark_start(
-    agent_name: str = typer.Option(..., "--agent-name", help="Name of the agent being evaluated"),
-    model_used: str | None = typer.Option(
-        None, "--model-used", help="LLM model powering the agent (e.g. claude-sonnet-4-20250514)"
-    ),
-    strategy_category: str | None = typer.Option(
-        None,
-        "--strategy-category",
-        help="Strategy type: momentum | mean-reversion | fundamental | hybrid | other",
-    ),
-    description: str | None = typer.Option(
-        None, "--description", help="Brief description of the agent's approach"
-    ),
-    blind: bool = typer.Option(
-        False,
-        "--blind/--no-blind",
-        help=(
-            "Run as a blind benchmark — agent sees opaque T_NNNN tickers and "
-            "Day_N dates instead of real symbols / ISO dates. Default --no-blind."
-        ),
-    ),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Start a standardized benchmark run via the MCP ``start_benchmark`` tool.
-
-    Examples:
-      finlet benchmark start --agent-name my-bot
-      finlet benchmark start --agent-name my-bot --blind
-      finlet benchmark start --agent-name my-bot --model-used claude-sonnet-4-20250514
-
-    See: finlet manual benchmark-lifecycle
-    """
-    args: dict[str, Any] = {
-        "agent_name": agent_name,
-        "blind": blind,
-    }
-    if model_used is not None:
-        args["model_used"] = model_used
-    if strategy_category is not None:
-        args["strategy_category"] = strategy_category
-    if description is not None:
-        args["description"] = description
-
-    envelope = _dispatch_mcp_tool("start_benchmark", args, api_key=api_key)
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    run_id = data.get("benchmark_run_id", "?")
-    session_id = data.get("session_id", "?")
-    scenario_label = data.get("scenario", "?")
-    typer.echo(f"Benchmark started: run={run_id} session={session_id} scenario={scenario_label}")
-
-
-@benchmark_app.command("progress")
-def benchmark_progress(
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Show the active benchmark run's progress via the MCP ``get_benchmark_progress`` tool.
-
-    Useful when the agent loses context mid-run — returns the canonical resume hint
-    (scenario number, universe, dates, current clock + portfolio).
-    """
-    envelope = _dispatch_mcp_tool("get_benchmark_progress", {}, api_key=api_key)
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    run_id = data.get("benchmark_run_id", "?")
-    session_id = data.get("session_id", "?")
-    scenario = data.get("scenario") or {}
-    current = scenario.get("current", "?")
-    total = scenario.get("total", "?")
-    typer.echo(f"Benchmark progress: run={run_id} session={session_id} scenario={current}/{total}")
-
-
-@benchmark_app.command("decrypt")
-def benchmark_decrypt(
-    benchmark_run_id: str = typer.Argument(..., help="Benchmark run ID to decrypt"),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Unlock a completed benchmark run's blind mapping via the MCP
-    ``decrypt_benchmark_run`` tool.
-
-    After decrypting, subsequent ``finlet benchmark export`` calls AND the
-    anonymous public-export surface return REAL tickers/dates instead of
-    opaque ``T_NNNN`` / ``Day_N``. Idempotent — calling twice preserves the
-    original decrypt timestamp.
-    """
-    args: dict[str, Any] = {"benchmark_run_id": benchmark_run_id}
-    envelope = _dispatch_mcp_tool("decrypt_benchmark_run", args, api_key=api_key)
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-    decrypted_at = data.get("decrypted_at", "?")
-    typer.echo(f"Decrypted → run={benchmark_run_id} decrypted_at={decrypted_at}")
-
-
-@benchmark_app.command("visibility")
-def benchmark_visibility(
-    benchmark_run_id: str = typer.Argument(..., help="Benchmark run ID to publish or un-publish"),
-    anonymous: bool = typer.Option(
-        True,
-        "--anonymous/--attributed",
-        help=(
-            "Anonymous (default) hides the agent name; --attributed exposes the "
-            "owner-supplied agent_name."
-        ),
-    ),
-    unpublish: bool = typer.Option(
-        False,
-        "--unpublish",
-        help="Revoke public access for the benchmark run.",
-    ),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Toggle a benchmark run's public-share visibility via the MCP
-    ``set_benchmark_visibility`` tool.
-
-    On publish, prints the canonical public URL the owner can share.
-    On un-publish, prints a one-line confirmation. Publishing requires
-    a prior ``finlet benchmark decrypt`` call — the service rejects
-    ``--no-unpublish`` on a still-blinded run.
-    """
-    make_public = not unpublish
-    args: dict[str, Any] = {
-        "benchmark_run_id": benchmark_run_id,
-        "public": make_public,
-        "anonymous": anonymous,
-    }
-    envelope = _dispatch_mcp_tool("set_benchmark_visibility", args, api_key=api_key)
-    _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-    if make_public:
-        typer.echo(
-            f"Published → https://finlet.dev/benchmark-runs/{benchmark_run_id}"
-        )
-    else:
-        typer.echo(f"Unpublished → {benchmark_run_id}")
+# REMOVED in v2.0.0: session sub-app + benchmark sub-app.
+# Agents call the MCP tools (create_session / list_sessions /
+# delete_session / set_session_visibility / start_benchmark /
+# get_benchmark_progress / decrypt_benchmark_run /
+# set_benchmark_visibility) directly through their MCP client.
+# See `finlet manual quickstart`.
 
 
 # ── plugins ──────────────────────────────────────────────────
@@ -981,7 +416,7 @@ def plugins_add(
     finlet_key = os.environ.get("FINLET_API_KEY")
     if not finlet_key:
         typer.echo(_MISSING_API_KEY_MESSAGE, err=True)
-        raise typer.Exit(2)
+        raise typer.Exit(EXIT_AUTH_REQUIRED)
 
     body: dict[str, object] = {"plugin": name, "enabled": True}
     if api_key is not None:
@@ -1053,7 +488,7 @@ def plugins_remove(
     finlet_key = api_key or os.environ.get("FINLET_API_KEY")
     if not finlet_key:
         typer.echo(_MISSING_API_KEY_MESSAGE, err=True)
-        raise typer.Exit(2)
+        raise typer.Exit(EXIT_AUTH_REQUIRED)
 
     body: dict[str, object] = {
         "plugin": name,
@@ -1343,9 +778,9 @@ def _run_oauth_login_flow() -> int:
 
         # ----- Persist credentials at mode 0600 -----
         # Atomic write contract (decision record §5) lives in
-        # :func:`_write_credentials`, which is also reused by the
-        # auto-refresh path in :func:`_resolve_bearer_token` to rotate
-        # tokens in place when the AS issues a new pair.
+        # :func:`_write_credentials`. v2.0.0 dropped the CLI's MCP
+        # dispatch path, so token refresh is now an MCP-client concern;
+        # this helper persists the initial pair issued by the AS.
         _write_credentials(
             {
                 "access_token": access_token,
@@ -1572,14 +1007,15 @@ def auth_status() -> None:
 
     Auth-failure paths exit :data:`EXIT_AUTH_REQUIRED` (2) so shell
     scripts can distinguish "not authenticated" from other CLI errors
-    (F-3 hotfix — matches the MCP tool-dispatch surface in
-    :func:`_emit_envelope`).
+    (F-3 hotfix); the same exit code is shared by
+    :func:`plugins_add` / :func:`plugins_remove` when ``FINLET_API_KEY``
+    is missing.
 
     This is a purely local check — does NOT ping the server. Use this
     command to verify the local credentials state before assuming
     authenticated CLI commands will succeed. Server-side rejection
     (e.g., the refresh token was revoked from the dashboard) is only
-    surfaced when an actual tool call dispatches.
+    surfaced when an authenticated MCP / REST call is made.
     """
     import time
 
@@ -1608,316 +1044,10 @@ def auth_status() -> None:
     typer.echo(f"Logged in. Token expires in {remaining_minutes} minutes.")
 
 
-# ── advance ─────────────────────────────────────────────────
-
-
-@app.command()
-def advance(
-    session: str = typer.Option(..., "--session", "-s", help="Session ID"),
-    days: int | None = typer.Option(
-        None,
-        "--days",
-        "-d",
-        help="Advance by N days in a single batched call (uses MCP advance_time steps)",
-    ),
-    to: str | None = typer.Option(
-        None,
-        "--to",
-        help="Advance to a specific date (YYYY-MM-DD). Mutually exclusive with --days.",
-    ),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Advance the simulation clock via the MCP ``advance_time`` tool.
-
-    Without flags, advances by one ``1d`` step.  ``--days N`` advances
-    by N daily intervals in a single batched call.  ``--to YYYY-MM-DD``
-    advances directly to that date via the tool's ``target_date``
-    parameter.  Flags are mutually exclusive.
-
-    Examples:
-      finlet advance --session sess_abc123
-      finlet advance --session sess_abc123 --days 5
-      finlet advance --session sess_abc123 --to 2024-06-30
-
-    See: finlet manual session-lifecycle
-    """
-    if days is not None and to is not None:
-        typer.echo("Error: --days and --to are mutually exclusive.", err=True)
-        raise typer.Exit(2)
-
-    if days is not None and days <= 0:
-        typer.echo("Error: --days must be a positive integer.", err=True)
-        raise typer.Exit(2)
-
-    if to is not None:
-        # Validate the format client-side so the user sees an immediate
-        # error rather than a tool-layer envelope. The tool itself does
-        # the same check; mirroring it here avoids the subprocess-spawn
-        # tax on a guaranteed-bad input.
-        try:
-            from datetime import datetime as _dt
-
-            _dt.strptime(to, "%Y-%m-%d")
-        except ValueError:
-            typer.echo(
-                f"Error: --to must be in YYYY-MM-DD format, got '{to}'.",
-                err=True,
-            )
-            raise typer.Exit(2)
-
-    args: dict[str, Any] = {"session_id": session, "interval": "1d"}
-    if to is not None:
-        args["target_date"] = to
-    elif days is not None:
-        args["steps"] = days
-
-    envelope = _dispatch_mcp_tool("advance_time", args, api_key=api_key)
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    typer.echo("Clock advanced:")
-    typer.echo(f"  Current time: {data.get('current_time', 'unknown')}")
-    typer.echo(f"  Mode: {data.get('mode', 'unknown')}")
-    fill_summary = data.get("fill_summary") or {}
-    if fill_summary:
-        typer.echo(
-            f"  Fills: {fill_summary.get('orders_filled', 0)} orders, "
-            f"{fill_summary.get('prices_updated', 0)} prices updated"
-        )
-
-
-# ── order ───────────────────────────────────────────────────
-
-
-@app.command()
-def order(
-    session: str = typer.Option(..., "--session", "-s", help="Session ID"),
-    ticker: str = typer.Option(..., "--ticker", "-t", help="Ticker symbol (e.g. AAPL)"),
-    side: str = typer.Option(..., "--side", help="BUY or SELL"),
-    quantity: float = typer.Option(..., "--quantity", "-q", help="Number of shares"),
-    order_type: str = typer.Option("MARKET", "--type", help="MARKET, LIMIT, or STOP"),
-    limit_price: float | None = typer.Option(None, "--limit-price", help="Limit price (required for LIMIT orders)"),
-    stop_price: float | None = typer.Option(None, "--stop-price", help="Stop price (required for STOP orders)"),
-    time_in_force: str = typer.Option("GTC", "--time-in-force", "--tif", help="DAY or GTC (currently MCP path always uses GTC)"),
-    reasoning: str | None = typer.Option(None, "--reasoning", help="Agent reasoning for this order"),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Submit a trade order via the MCP ``submit_order`` tool.
-
-    Supports MARKET (no price flags), LIMIT (requires ``--limit-price``),
-    and STOP (requires ``--stop-price``) orders. Client-side validation
-    rejects the most common operator footguns — LIMIT/STOP without a
-    price, or MARKET with a stray price — before the network round-trip.
-    ``--time-in-force`` is preserved for ergonomic stability but the
-    service-layer always defaults to GTC.
-
-    Examples:
-      finlet order --session sess_abc123 --ticker AAPL --side BUY --quantity 10
-      finlet order --session sess_abc123 --ticker AAPL --side BUY --quantity 10 --type LIMIT --limit-price 175.50
-
-    See: finlet manual session-lifecycle
-    """
-    # Client-side price validation per --type (H12). Catches the most common
-    # operator footgun (LIMIT/STOP without a price) BEFORE any network call,
-    # so the user sees an actionable client error instead of a tool-envelope
-    # round-trip plus a subprocess-spawn tax.
-    normalized_type = order_type.upper()
-    if normalized_type == "LIMIT":
-        if limit_price is None or limit_price <= 0:
-            raise typer.BadParameter(
-                "LIMIT orders require --limit-price > 0.",
-                param_hint="--limit-price",
-            )
-    elif normalized_type == "STOP":
-        if stop_price is None or stop_price <= 0:
-            raise typer.BadParameter(
-                "STOP orders require --stop-price > 0.",
-                param_hint="--stop-price",
-            )
-    elif normalized_type == "MARKET" and (
-        (limit_price is not None and limit_price != 0)
-        or (stop_price is not None and stop_price != 0)
-    ):
-        raise typer.BadParameter(
-            "MARKET orders must not specify --limit-price or --stop-price.",
-            param_hint="--type",
-        )
-
-    args: dict[str, Any] = {
-        "session_id": session,
-        "ticker": ticker,
-        "side": side.upper(),
-        "quantity": quantity,
-        "order_type": normalized_type,
-    }
-    if limit_price is not None:
-        args["limit_price"] = limit_price
-    if stop_price is not None:
-        args["stop_price"] = stop_price
-    if reasoning is not None:
-        args["reasoning"] = reasoning
-    # NOTE: ``time_in_force`` is not exposed by the MCP ``submit_order`` tool;
-    # the service-layer defaults to GTC. The CLI flag is preserved for
-    # ergonomic stability but is currently a no-op on the MCP dispatch path.
-    _ = time_in_force  # explicit ack of the unused flag for future extension.
-
-    envelope = _dispatch_mcp_tool("submit_order", args, api_key=api_key)
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    typer.echo("Order submitted:")
-    typer.echo(f"  ID: {data.get('id', 'unknown')}")
-    typer.echo(f"  Status: {data.get('status', 'unknown')}")
-    fill_price = data.get("fill_price")
-    if fill_price is not None:
-        typer.echo(f"  Fill price: ${fill_price:,.2f}")
-
-
-# ── portfolio ───────────────────────────────────────────────
-
-
-@app.command()
-def portfolio(
-    session: str = typer.Option(..., "--session", "-s", help="Session ID"),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Show portfolio positions, cash, and P&L via the MCP ``get_portfolio`` tool.
-
-    Renders an at-clock-time snapshot — positions with current market
-    value + unrealized P&L, cash balance, total portfolio value, and
-    aggregate order metrics. Output uses rich tables when available
-    and falls back to plain text otherwise. Pass ``--json`` to emit
-    the raw MCP envelope for programmatic consumers.
-
-    Examples:
-      finlet portfolio --session sess_abc123
-      finlet portfolio --session sess_abc123 --json
-
-    See: finlet manual session-lifecycle
-    """
-    envelope = _dispatch_mcp_tool(
-        "get_portfolio", {"session_id": session}, api_key=api_key
-    )
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    positions = data.get("positions", {})
-    cash = data.get("cash", 0.0)
-    total_value = data.get("total_value", 0.0)
-    unrealized_pnl = data.get("unrealized_pnl", 0.0)
-    metrics = data.get("metrics", {})
-
-    # Try rich table, fall back to plain text
-    try:
-        from rich.console import Console
-        from rich.table import Table
-
-        console = Console()
-
-        table = Table(title="Portfolio")
-        table.add_column("Ticker", style="cyan")
-        table.add_column("Quantity", justify="right")
-        table.add_column("Avg Entry", justify="right", style="dim")
-        table.add_column("Current Price", justify="right")
-        table.add_column("Market Value", justify="right")
-        table.add_column("Unrealized P&L", justify="right")
-
-        for pos in positions.values():
-            pnl = pos.get("unrealized_pnl", 0.0)
-            pnl_style = "green" if pnl >= 0 else "red"
-            table.add_row(
-                pos.get("ticker", "?"),
-                f"{pos.get('quantity', 0):.2f}",
-                f"${pos.get('avg_entry_price', 0):.2f}",
-                f"${pos.get('current_price', 0):.2f}",
-                f"${pos.get('market_value', 0):,.2f}",
-                f"[{pnl_style}]${pnl:,.2f}[/{pnl_style}]",
-            )
-
-        console.print(table)
-        console.print(f"  Cash: ${cash:,.2f}")
-        console.print(f"  Total value: ${total_value:,.2f}")
-        pnl_label = f"${unrealized_pnl:,.2f}" if unrealized_pnl >= 0 else f"-${abs(unrealized_pnl):,.2f}"
-        console.print(f"  Unrealized P&L: {pnl_label}")
-        if metrics:
-            console.print(
-                f"  Orders: {metrics.get('total_orders', 0)} total, {metrics.get('filled_orders', 0)} filled"
-            )
-    except ImportError:
-        # Plain text fallback
-        typer.echo("Portfolio:")
-        if positions:
-            typer.echo(f"  {'Ticker':<8} {'Qty':>8} {'Avg Entry':>10} {'Price':>10} {'Value':>12} {'P&L':>12}")
-            typer.echo(f"  {'-' * 8} {'-' * 8} {'-' * 10} {'-' * 10} {'-' * 12} {'-' * 12}")
-            for pos in positions.values():
-                typer.echo(
-                    f"  {pos.get('ticker', '?'):<8} "
-                    f"{pos.get('quantity', 0):>8.2f} "
-                    f"${pos.get('avg_entry_price', 0):>9.2f} "
-                    f"${pos.get('current_price', 0):>9.2f} "
-                    f"${pos.get('market_value', 0):>11,.2f} "
-                    f"${pos.get('unrealized_pnl', 0):>11,.2f}"
-                )
-        else:
-            typer.echo("  No positions.")
-        typer.echo(f"  Cash: ${cash:,.2f}")
-        typer.echo(f"  Total value: ${total_value:,.2f}")
-        typer.echo(f"  Unrealized P&L: ${unrealized_pnl:,.2f}")
-
-
-# ── status ──────────────────────────────────────────────────
-
-
-@app.command()
-def status(
-    session: str = typer.Option(..., "--session", "-s", help="Session ID"),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Show session status via the MCP ``get_session`` tool.
-
-    Reports the session ID, name, lifecycle status, simulation clock
-    (current sim time + mode — FROZEN / STEPPING / CONTINUOUS), the
-    configured universe, and the initial capital. Pass ``--json`` to
-    emit the raw MCP envelope for programmatic consumers.
-
-    Examples:
-      finlet status --session sess_abc123
-
-    See: finlet manual session-lifecycle
-    """
-    envelope = _dispatch_mcp_tool(
-        "get_session", {"session_id": session}, api_key=api_key
-    )
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    typer.echo(f"Session: {data.get('name', data.get('id', 'unknown'))}")
-    typer.echo(f"  ID: {data.get('id', 'unknown')}")
-    typer.echo(f"  Status: {data.get('status', 'unknown')}")
-    clock = data.get("clock", {})
-    typer.echo(f"  Sim time: {clock.get('current_time', 'unknown')}")
-    typer.echo(f"  Mode: {clock.get('mode', 'unknown')}")
-    config = data.get("config", {})
-    universe = config.get("universe", [])
-    if universe:
-        typer.echo(f"  Universe: {', '.join(universe)}")
-    typer.echo(f"  Capital: ${config.get('initial_capital', 0):,.2f}")
+# REMOVED in v2.0.0: top-level advance / order / portfolio / status.
+# Agents call the MCP tools (advance_time / submit_order / get_portfolio /
+# get_session) directly through their MCP client. See
+# `finlet manual quickstart`.
 
 
 # ── mcp ──────────────────────────────────────────────────────
@@ -1983,7 +1113,7 @@ def mcp_serve() -> None:
         from finlet.logging import configure_logging
     except ImportError:
         typer.echo("Error: Local MCP server requires the full Finlet installation.", err=True)
-        typer.echo("Use MCP-over-HTTP with finlet.dev instead.", err=True)
+        typer.echo("Point your MCP client at https://finlet.dev/mcp instead.", err=True)
         typer.echo("Install server with: pip install finlet[server]", err=True)
         raise typer.Exit(1)
     configure_logging()
@@ -2005,7 +1135,7 @@ def mcp_serve() -> None:
         from finlet.mcp.server import mcp as mcp_server
     except ImportError:
         typer.echo("Error: Local MCP server requires the full Finlet installation.", err=True)
-        typer.echo("Use MCP-over-HTTP with finlet.dev instead.", err=True)
+        typer.echo("Point your MCP client at https://finlet.dev/mcp instead.", err=True)
         typer.echo("Install server with: pip install finlet[server]", err=True)
         raise typer.Exit(1)
 

exec
/bin/zsh -lc 'git diff --find-renames --find-copies main~1..main -- finlet/cli_mcp_client.py' in /Users/justnau/finlet
exec
/bin/zsh -lc 'git show --format=fuller --name-status --find-renames main' in /Users/justnau/finlet
 succeeded in 0ms:
commit 59c85bbe88602dc8b9fd3dd30627b467326ff1e7
Merge: 7144dc2 cfadd81
Author:     Justin Nam <justnau@Justins-MacBook-Air-2.local>
AuthorDate: Fri May 22 22:06:45 2026 -0500
Commit:     Justin Nam <justnau@Justins-MacBook-Air-2.local>
CommitDate: Fri May 22 22:06:45 2026 -0500

    Merge: [Team A v2.0.0] CLI surgery — delete dropped commands + dead helpers + rewrite module docstring


 succeeded in 0ms:
diff --git a/finlet/cli_mcp_client.py b/finlet/cli_mcp_client.py
deleted file mode 100644
index 7bd1ae3..0000000
--- a/finlet/cli_mcp_client.py
+++ /dev/null
@@ -1,237 +0,0 @@
-"""CLI → MCP client wrapper (HTTP streamable transport).
-
-v1.0.1 entry point for every non-KEEP CLI command. Opens a streamable
-HTTP MCP session against the cloud ``/mcp`` endpoint (default
-``https://finlet.dev/mcp``), calls a single tool, and returns the result
-envelope.
-
-Design contract (decision record ``docs/decisions/cli-mcp-http-dispatch.md``):
-
-* **Transport.** ``mcp.client.streamable_http.streamablehttp_client`` —
-  the modern HTTP+SSE MCP transport.  No subprocess spawn; no stdio
-  framing; no PyPI ``[server]`` extras dependency.  Base ``mcp`` install
-  ships ``mcp.client.streamable_http`` directly, so the CLI wheel is
-  sufficient (see ``docs/plans/EXECUTION_PLAN_V1_0_1_HOTFIX.md`` BLOCKER #A).
-* **Endpoint.** Resolved from ``FINLET_API_URL`` env (default
-  ``https://finlet.dev``); the MCP mount is at ``/mcp`` on the same host
-  as the REST API.
-* **Auth.** The Bearer token is forwarded via the ``Authorization``
-  request header.  Token may be EITHER an OAuth JWT (from
-  ``finlet auth login``) OR a legacy ``fnlt_*`` api-key — both are
-  accepted by the cloud ``/mcp`` endpoint post-Phase-4e-retraction
-  (see ``docs/decisions/mcp-api-key-sunset.md`` retraction appendix).
-  When ``bearer_token`` is ``None``, no ``Authorization`` header is
-  sent; the server-side gate surfaces "Authentication required" through
-  the standard tool envelope.
-* **Lifecycle.** Per-command HTTP session.  Each CLI invocation opens a
-  fresh transport, runs the MCP ``initialize`` handshake, dispatches a
-  single tool, and tears the transport down.  No persistent multiplexing
-  in v1.0.1; future work may pool the transport across multi-tool
-  workflows.
-
-The wrapper is a thin async helper backed by a synchronous
-:func:`call_tool_sync` shim. Typer command handlers are sync; we run
-the async client via :func:`asyncio.run` per command. Each invocation
-is independent — no shared state between commands.
-"""
-
-from __future__ import annotations
-
-import asyncio
-import json
-import os
-from collections.abc import Mapping
-from contextlib import AsyncExitStack
-from typing import Any
-
-from mcp.client.session import ClientSession
-from mcp.client.streamable_http import streamablehttp_client
-
-
-class MCPDispatchError(RuntimeError):
-    """Raised when the CLI's MCP HTTP dispatch fails before tool dispatch.
-
-    Wraps connection errors, MCP handshake failures, and protocol-level
-    issues. Tool-level error envelopes (the ``{"error": "..."}`` shape Finlet
-    tools return) are NOT exceptions — they pass through as the call result
-    so the caller can translate them with :func:`finlet.cli._translate_mcp_error`.
-    """
-
-
-def _summarize(exc: BaseException, *, max_depth: int = 4) -> str:
-    """Flatten an anyio task-group ``ExceptionGroup`` into a one-line summary.
-
-    The MCP SDK's streamablehttp transport runs reads/writes in an anyio
-    task group; transport errors arrive as a BaseExceptionGroup whose
-    repr() expands to ~100 lines of asyncio/anyio/httpx frames. The CLI's
-    error envelope must stay one line so the user sees a clean message,
-    not a debugger dump. Walk the first child of each ExceptionGroup up
-    to ``max_depth`` deep and return ``"<ExcType>: <message>"``.
-    """
-    cur: BaseException | None = exc
-    for _ in range(max_depth):
-        if isinstance(cur, BaseExceptionGroup) and cur.exceptions:
-            cur = cur.exceptions[0]
-            continue
-        break
-    if cur is None:
-        return f"{type(exc).__name__}: <empty exception group>"
-    msg = str(cur).strip().splitlines()[0] if str(cur).strip() else "<no message>"
-    return f"{type(cur).__name__}: {msg}"
-
-
-def _resolve_api_url() -> str:
-    """Resolve the Finlet API base URL from the environment.
-
-    Reads ``FINLET_API_URL`` (default ``https://finlet.dev``) and strips
-    any trailing slash so the ``/mcp`` suffix appends cleanly. The CLI
-    points at the same host as the REST API — the MCP mount is the
-    ``/mcp`` path prefix on that host, wired in by Team A's
-    ``finlet/api/app.py`` mount.
-    """
-    return os.environ.get("FINLET_API_URL", "https://finlet.dev").rstrip("/")
-
-
-def _decode_tool_result(raw_content: list[Any]) -> dict[str, Any]:
-    """Decode FastMCP's TextContent list into the tool's dict envelope.
-
-    FastMCP serializes a tool's ``dict[str, Any]`` return value as a
-    single :class:`mcp.types.TextContent` whose ``text`` field is the
-    JSON-encoded dict. We round-trip that back to the dict shape every
-    Finlet tool body returns, so the CLI's ``_translate_mcp_error`` and
-    pretty-printers see the same surface they would in-process.
-
-    If the tool returns multiple content items or a non-text payload,
-    we fall back to a synthetic envelope so the caller still has a
-    parseable object.
-    """
-    if not raw_content:
-        return {}
-    first = raw_content[0]
-    text = getattr(first, "text", None)
-    if not isinstance(text, str):
-        return {"error": f"MCP tool returned unexpected content type: {type(first).__name__}"}
-    try:
-        decoded = json.loads(text)
-    except json.JSONDecodeError:
-        # Tools always return JSON-serialisable dicts; a plain-string
-        # response indicates a tool error or shape change. Surface the
-        # raw text in the error envelope so the caller has something to
-        # print.
-        return {"error": f"MCP tool returned non-JSON: {text!r}"}
-    if not isinstance(decoded, dict):
-        return {"error": f"MCP tool returned non-dict JSON: {decoded!r}"}
-    return decoded
-
-
-async def call_tool_async(
-    tool_name: str,
-    arguments: Mapping[str, Any] | None = None,
-    *,
-    bearer_token: str | None = None,
-    timeout: float = 120.0,
-) -> dict[str, Any]:
-    """Open an HTTP MCP session, call a single tool, return the result dict.
-
-    Args:
-        tool_name: The MCP tool to invoke (e.g. ``"list_sessions"``,
-            ``"submit_order"``). Must be a tool registered on the cloud
-            ``finlet`` FastMCP instance mounted at ``/mcp``.
-        arguments: Keyword arguments for the tool. ``None`` is treated
-            as an empty dict.
-        bearer_token: The OAuth access token (raw JWT) or legacy api-key
-            to forward in the ``Authorization`` header. The header is
-            sent as ``Bearer <token>``. ``None`` sends no Authorization
-            header — every authenticated tool returns the documented
-            "Authentication required" envelope.
-        timeout: Hard ceiling on the entire tool call (seconds),
-            including transport setup and MCP handshake.
-
-    Returns:
-        The tool's response dict. Tool-level errors are encoded in the
-        dict (``{"error": "..."}``) — they do NOT raise.
-
-    Raises:
-        MCPDispatchError: When the HTTP transport fails to connect or
-            the MCP handshake fails before the tool dispatches. The
-            message is human-readable; ``finlet.cli._translate_mcp_error``
-            is the consumer that renders it.
-        asyncio.TimeoutError: When ``timeout`` elapses before the tool
-            returns. The transport is force-closed by the
-            ``streamablehttp_client`` exit stack.
-    """
-    args = dict(arguments or {})
-    url = f"{_resolve_api_url()}/mcp"
-    headers: dict[str, str] = {}
-    if bearer_token:
-        headers["Authorization"] = f"Bearer {bearer_token}"
-
-    async def _drive() -> dict[str, Any]:
-        async with AsyncExitStack() as stack:
-            try:
-                transport = await stack.enter_async_context(
-                    streamablehttp_client(url, headers=headers)
-                )
-            except Exception as exc:
-                raise MCPDispatchError(
-                    f"Cannot connect to Finlet MCP at {url}: {exc}"
-                ) from exc
-            read_stream, write_stream, _ = transport
-            session = await stack.enter_async_context(
-                ClientSession(read_stream, write_stream)
-            )
-            try:
-                await session.initialize()
-            except BaseException as exc:  # noqa: BLE001 — anyio ExceptionGroup unwrap
-                # streamablehttp_client routes server errors (HTTP 4xx/5xx,
-                # malformed JSON-RPC, transport drops) up through an anyio
-                # task-group ExceptionGroup. Catching BaseException
-                # collapses the noisy stack into a single clean
-                # MCPDispatchError that finlet.cli._translate_mcp_error
-                # renders for the user. Preserves the v1.0.0 HIGH#5 clean-
-                # stream invariant on the HTTP dispatch path.
-                raise MCPDispatchError(
-                    f"MCP handshake failed against {url}: {_summarize(exc)}"
-                ) from exc
-            try:
-                result = await session.call_tool(tool_name, args)
-            except BaseException as exc:  # noqa: BLE001 — same anyio ExceptionGroup unwrap
-                raise MCPDispatchError(
-                    f"MCP tool '{tool_name}' dispatch failed: {_summarize(exc)}"
-                ) from exc
-            return _decode_tool_result(list(result.content))
-        # Unreachable — AsyncExitStack guarantees the body returns or raises.
-        raise AssertionError("call_tool_async exited without returning")
-
-    return await asyncio.wait_for(_drive(), timeout=timeout)
-
-
-def call_tool_sync(
-    tool_name: str,
-    arguments: Mapping[str, Any] | None = None,
-    *,
-    bearer_token: str | None = None,
-    timeout: float = 120.0,
-) -> dict[str, Any]:
-    """Synchronous facade for :func:`call_tool_async`.
-
-    Typer command handlers are sync. This shim runs the async client
-    via :func:`asyncio.run` so each command stays a normal Python
-    function. ``asyncio.run`` requires no running loop, which holds
-    for every Typer-dispatched command (Typer uses a sync entry point).
-    """
-    return asyncio.run(
-        call_tool_async(
-            tool_name,
-            arguments,
-            bearer_token=bearer_token,
-            timeout=timeout,
-        )
-    )
-
-
-__all__ = [
-    "MCPDispatchError",
-    "call_tool_async",
-    "call_tool_sync",
-]

exec
/bin/zsh -lc 'git diff --unified=0 main~1..main -- finlet/cli.py' in /Users/justnau/finlet
exec
/bin/zsh -lc "sed -n '208,338p' docs/brainstorms/V2_PURE_MCP_EXECUTION_PLAN.md" in /Users/justnau/finlet
 succeeded in 0ms:
### Team A: CLI surgery — delete dropped commands + dead helpers + rewrite module docstring

**Blocked by:** none — can start immediately.

**Read these files first:**
- `finlet/cli.py:1-30` — module docstring (will be rewritten — describes deleted v1.0.1 dispatch model)
- `finlet/cli.py:30-70` — imports (`asyncio` at line 30, `_AsyncioTimeoutError` at line 64 — both dead) and `EXIT_AUTH_REQUIRED` at line 45 (ALIVE — keep)
- `finlet/cli.py:217-260` — `_resolve_bearer_token` (dead-after-deletion)
- `finlet/cli.py:386-466` — `_dispatch_mcp_tool` + envelope plumbing (all dead)
- `finlet/cli.py:491-530` — Typer app init + sub-typer registrations
- `finlet/cli.py:535-568` — `finlet serve` command (KEEP)
- `finlet/cli.py:881-1096` — plugins commands (KEEP; use `EXIT_AUTH_REQUIRED` at 984, 1056)
- `finlet/cli.py:1340-1360` — inline comment at line 1347 references `_resolve_bearer_token` auto-refresh (stale after deletion; this is an inline comment, NOT a docstring per Step 10b NIT-1)
- `finlet/cli.py:1561-1610` — `auth status` command (KEEP; uses `EXIT_AUTH_REQUIRED`)
- `finlet/cli.py:1565-1580` — docstring/comment around 1573 (audit for dispatch refs)
- `finlet/cli.py:1927-2035` — `finlet mcp serve` command (KEEP)
- `finlet/cli_mcp_client.py` — entire file (to be deleted)
- `docs/decisions/cli-mcp-http-dispatch.md` — current transport contract (Team C marks Superseded)

**Recon evidence (verified against HEAD `fb2637c`):**

The 13 `_dispatch_mcp_tool(...)` call sites are all in the dropped commands:

```text finlet/cli.py callers of _dispatch_mcp_tool
386:def _dispatch_mcp_tool(...)
610:    envelope = _dispatch_mcp_tool("create_session", args, api_key=api_key)
637:    envelope = _dispatch_mcp_tool("list_sessions", {}, api_key=api_key)
660:    envelope = _dispatch_mcp_tool(...)  # delete_session
698:    envelope = _dispatch_mcp_tool("set_session_visibility", args, api_key=api_key)
758:    envelope = _dispatch_mcp_tool("start_benchmark", args, api_key=api_key)
781:    envelope = _dispatch_mcp_tool("get_benchmark_progress", {}, api_key=api_key)
811:    envelope = _dispatch_mcp_tool("decrypt_benchmark_run", args, api_key=api_key)
854:    envelope = _dispatch_mcp_tool("set_benchmark_visibility", args, api_key=api_key)
1677:   envelope = _dispatch_mcp_tool("advance_time", args, api_key=api_key)
1771:   envelope = _dispatch_mcp_tool("submit_order", args, api_key=api_key)
1809:   envelope = _dispatch_mcp_tool(...)  # get_portfolio
1903:   envelope = _dispatch_mcp_tool(...)  # get_session (status command)
```

`EXIT_AUTH_REQUIRED` is ALIVE — verified against HEAD `fb2637c`:

```text grep -nE "EXIT_AUTH_REQUIRED" finlet/cli.py
45:EXIT_AUTH_REQUIRED = 2
448:    :data:`EXIT_AUTH_REQUIRED` (2) so shell scripts can distinguish  ← inside _emit_envelope docstring (dead)
461:        exit_code = EXIT_AUTH_REQUIRED if is_auth_failure else on_error_exit  ← inside _emit_envelope (dead)
984:        raise typer.Exit(2)   ← plugins_add (KEPT; should use EXIT_AUTH_REQUIRED but raises literal 2)
1056:       raise typer.Exit(2)   ← plugins_remove (KEPT; same)
```

Codex Step 10b also identified `auth_status` (cli.py:1561-1610) as raising `EXIT_AUTH_REQUIRED`. The constant has live consumers and MUST stay.

`_resolve_bearer_token` callers (verified against HEAD `fb2637c`):

```text finlet/cli.py callers of _resolve_bearer_token
217:def _resolve_bearer_token(api_key: str | None) -> str | None:
411:    bearer = _resolve_bearer_token(api_key)                                ← inside _dispatch_mcp_tool (dies)
1347:        # auto-refresh path in :func:`_resolve_bearer_token` to rotate    ← stale inline comment in auth_login
```

After deleting `_dispatch_mcp_tool` (which owns the only live call at 411), `_resolve_bearer_token` has zero live callers. The reference at `cli.py:1347` is an inline comment (NOT a docstring per Step 10b NIT-1) — Team A removes the comment OR rewrites it to point at the live credential-write path in `_write_credentials`.

`_AsyncioTimeoutError` + top-level `asyncio` (verified against HEAD `fb2637c`):

```text finlet/cli.py
30:import asyncio
64:_AsyncioTimeoutError = asyncio.TimeoutError
422:    except (TimeoutError, _AsyncioTimeoutError) as exc:  ← inside _dispatch_mcp_tool
```

Only consumer is `_dispatch_mcp_tool`'s timeout handler. Delete the alias AND the top-level import.

Module docstring at `finlet/cli.py:1-30` (verified against HEAD `fb2637c`):

```text finlet/cli.py:1-30
1:"""CLI entrypoint — finlet serve / session / plugins / mcp.
3:v1.0.1 (CLI MCP-over-HTTP) routes session / advance / order /
4:portfolio / status through the cloud ``/mcp`` HTTP endpoint via
5:``mcp.client.streamable_http.streamablehttp_client``.  See
6:``docs/decisions/cli-mcp-http-dispatch.md`` for the dispatch contract.
```

This describes a command surface that no longer exists. Rewrite to describe the v2.0.0 kept surface (serve, register, auth, plugins, mcp serve, manual).

`finlet/cli_mcp_client.py` is imported only by:

```text grep -rn "from finlet.cli_mcp_client"
finlet/cli.py:39:from finlet.cli_mcp_client import MCPDispatchError, call_tool_sync
tests/test_cli.py:29:from finlet.cli_mcp_client import MCPDispatchError
tests/api/test_cli_mcp_client.py:26:from finlet.cli_mcp_client import (...)
```

`cli.py:39` import dies with the dispatch helper; the test files are Team B's responsibility. Safe to delete.

**Files touched:**
- Modified: `finlet/cli.py`:
  - **Rewrite module docstring (lines 1-30)** to describe v2.0.0 surface: serve, register, auth login/logout/status, plugins list/add/remove, mcp serve, manual. Mention `finlet/cli.py` is the typer entry point. No mention of session/order/portfolio/etc.
  - Delete commands at lines 584-706 (session sub-app commands), 711-864 (benchmark sub-app commands), 1614-1691 (advance), 1696-1782 (order), 1787-1878 (portfolio), 1883-1921 (status).
  - Delete dead helpers: `_dispatch_mcp_tool` (386-433), `_translate_mcp_error` (363-384), `_emit_envelope` (~436), `_AUTH_REQUIRED_MARKERS`, `_AUTH_REQUIRED_HINT`, `_resolve_bearer_token` (217), `_AsyncioTimeoutError` alias (64), top-level `import asyncio` (30), `_normalize_start_iso` (~573, verify dead).
  - **DO NOT delete `EXIT_AUTH_REQUIRED` (line 45)** — alive, used by `plugins_add` (984), `plugins_remove` (1056), `auth_status` (1598+). Note that `plugins_add` and `plugins_remove` currently raise the literal `2` (`raise typer.Exit(2)`); they should ideally use `EXIT_AUTH_REQUIRED` for clarity but that's beyond v2.0.0 scope — leave as-is.
  - Delete sub-typer `session_app` (516) + `benchmark_app` (520-525) + their `app.add_typer(...)` lines.
  - Delete the `from finlet.cli_mcp_client import ...` import (line 39).
  - Clean stale inline comment at `cli.py:1347` (referencing `_resolve_bearer_token` auto-refresh — the function won't exist after deletion). Either remove the comment or rewrite to point at `_write_credentials` directly.
  - Audit `cli.py:1573` and surrounding for similar stale refs.
- Deleted: `finlet/cli_mcp_client.py` (entire file).

**Deliverable:** After this team finishes, `finlet --help` shows ONLY: `serve`, `mcp` (with sub-command `serve`), `auth` (with `login`/`logout`/`status`), `register`, `plugins` (with `list`/`add`/`remove`), `manual`, `--version`. No `session`, `benchmark`, `advance`, `order`, `portfolio`, or `status` commands. The DEAD set is gone; the ALIVE set (`EXIT_AUTH_REQUIRED`) remains. Module docstring describes v2.0.0 surface only.

**Validation:**
- [ ] `python -c "import finlet.cli; from finlet.cli import app"` succeeds (no import errors).
- [ ] `python -m finlet.cli --help 2>&1 | grep -E '^\s+(session|benchmark|advance|order|portfolio|status)\b'` returns nothing.
- [ ] `python -m finlet.cli --help 2>&1 | grep -E '^\s+(serve|mcp|auth|register|plugins|manual)\b'` returns all 6 expected commands.
- [ ] `python -m finlet.cli mcp serve --help` exits 0.
- [ ] `grep -rn "from finlet.cli_mcp_client" finlet/` returns nothing.
- [ ] `grep -nE "_dispatch_mcp_tool|_resolve_bearer_token|_AsyncioTimeoutError|_AUTH_REQUIRED_MARKERS|_AUTH_REQUIRED_HINT|_emit_envelope|_translate_mcp_error" finlet/cli.py` returns nothing.
- [ ] `grep -nE "^import asyncio|^from asyncio" finlet/cli.py` returns nothing.
- [ ] `grep -nE "EXIT_AUTH_REQUIRED" finlet/cli.py` returns the definition at line ~45 + ≥3 consumer usages (KEPT — alive).
- [ ] `grep -nE "v1\\.0\\.1|MCP-over-HTTP|MCP-dispatched|dispatch contract" finlet/cli.py` returns nothing (module docstring is rewritten).
- [ ] `ruff check finlet/cli.py` passes.
- [ ] `git status` shows `finlet/cli.py` modified, `finlet/cli_mcp_client.py` deleted.

**Agent instructions:**
- You MUST `git add finlet/cli.py` and `git rm finlet/cli_mcp_client.py` and `git commit` before finishing.
- After deletion, run `ruff check finlet/` and remove any newly-unused imports.
- After deletion, grep for orphan refs to deleted symbols and clean stale docstrings/comments — including the module docstring (lines 1-30) and the inline comment at line 1347.
- **Do NOT delete `EXIT_AUTH_REQUIRED`.** It's alive. Verify with `grep -c "EXIT_AUTH_REQUIRED" finlet/cli.py` — should be ≥4 (definition + ≥3 consumers).
- Do NOT modify ANY MCP tool source files (`finlet/mcp/`).
- Do NOT touch `tests/` — that's Team B's lane.
- Do NOT touch docs or `dashboard/llms.txt` — that's Team C's lane.
- Do NOT touch `dashboard/*.html` — that's Team D's lane.
- Commit message: `[Team A v2.0.0]: delete CLI convenience commands + dead helpers; rewrite module docstring`.


 succeeded in 0ms:
diff --git a/finlet/cli.py b/finlet/cli.py
index 00d96f5..2c8a000 100644
--- a/finlet/cli.py
+++ b/finlet/cli.py
@@ -1 +1 @@
-"""CLI entrypoint — finlet serve / session / plugins / mcp.
+"""CLI entrypoint — finlet serve / register / auth / plugins / mcp / manual.
@@ -3,4 +3,6 @@
-v1.0.1 (CLI MCP-over-HTTP) routes session / advance / order /
-portfolio / status through the cloud ``/mcp`` HTTP endpoint via
-``mcp.client.streamable_http.streamablehttp_client``.  See
-``docs/decisions/cli-mcp-http-dispatch.md`` for the dispatch contract.
+v2.0.0 (Pure-MCP) ships a deliberately minimal CLI: the only commands
+are the ones that ARE NOT MCP tool calls. Every agentic-trading
+operation (session / clock / order / portfolio / benchmark / status)
+runs over MCP — agents talk to the cloud ``/mcp`` endpoint directly
+via their own MCP client. The CLI no longer hosts a dispatch surface
+for those operations.
@@ -8 +10 @@ portfolio / status through the cloud ``/mcp`` HTTP endpoint via
-Four command families remain on REST (the "KEEP" set):
+Six command families remain (the v2.0.0 surface):
@@ -16,10 +18,12 @@ Four command families remain on REST (the "KEEP" set):
-
-Plugin management (``finlet plugins list/add/remove``) ALSO remains on
-REST (`/v1/settings/plugins` and `/v1/plugins/health`) because Finlet's
-MCP tool surface is the agentic-trading surface and intentionally does
-not expose tenant plugin-credential write paths.  If a future phase
-ships admin MCP tools, the plugins commands can move alongside.
-
-``finlet mcp serve`` is preserved as a self-host stdio entry point for
-niche integrations (e.g., Claude Code over stdio); the CLI itself no
-longer spawns it for tool dispatch.
+* ``finlet plugins list`` / ``finlet plugins add`` / ``finlet plugins remove``
+  — tenant plugin-credential management against ``/v1/settings/plugins``
+  and ``/v1/plugins/health``. Finlet's MCP tool surface is the
+  agentic-trading surface and intentionally does not expose plugin
+  write paths.
+* ``finlet mcp serve`` — self-host stdio MCP server for niche
+  integrations (e.g., Claude Code stdio bridge).
+* ``finlet manual`` — local user-manual topics shipped with the wheel.
+
+The pre-v2.0.0 ``session`` / ``benchmark`` / ``advance`` / ``order`` /
+``portfolio`` / ``status`` subcommands are gone; agents address the
+cloud ``/mcp`` endpoint directly.
@@ -30 +33,0 @@ from __future__ import annotations
-import asyncio
@@ -39,2 +41,0 @@ import typer
-from finlet.cli_mcp_client import MCPDispatchError, call_tool_sync
-
@@ -47,19 +47,0 @@ EXIT_AUTH_REQUIRED = 2
-#: Substrings that signal an auth-failure tool envelope from the MCP
-#: server.  The cloud server emits the second form post-Phase 4e
-#: (api_key Bearer no longer accepted on MCP HTTP); the first is the
-#: pre-Phase-4 / stdio-bridge form.  Either ⇒ exit 2 with a friendly hint.
-_AUTH_REQUIRED_MARKERS = (
-    "Authentication required",
-    "api_key authentication is no longer supported",
-)
-_AUTH_REQUIRED_HINT = (
-    "Not authenticated. Run `finlet auth login` for an OAuth Bearer token, "
-    "or set `FINLET_API_KEY=fnlt_<key>` for api_key auth on REST / stdio."
-)
-
-# Alias asyncio.TimeoutError for the dispatch try/except so the catch site
-# is explicit. On Python 3.11+ this is the same class as the builtin
-# TimeoutError, but the cli_mcp_client docs raise it via asyncio.wait_for —
-# we catch both names defensively.
-_AsyncioTimeoutError = asyncio.TimeoutError
-
@@ -217,251 +198,0 @@ def _print_error(e: Exception) -> None:
-def _resolve_bearer_token(api_key: str | None) -> str | None:
-    """Resolve the Bearer token (OAuth JWT or legacy api-key) for MCP dispatch.
-
-    Mirrors :func:`_api_headers`'s precedence but returns the raw token
-    string instead of a header dict, so the CLI's MCP-over-HTTP dispatch
-    path can forward it via the ``Authorization`` request header on the
-    cloud ``/mcp`` endpoint.
-
-    Precedence (highest first):
-
-    1. ``api_key`` explicit flag (or ``FINLET_API_KEY`` env, surfaced
-       through Typer's envvar wiring) — used as a Bearer token. The
-       cloud ``/mcp`` endpoint accepts BOTH OAuth JWTs and legacy
-       ``fnlt_*`` api-keys in the ``Authorization`` header post-v1.0.1
-       (see ``docs/decisions/cli-mcp-http-dispatch.md`` and the
-       retraction appendix on ``docs/decisions/mcp-api-key-sunset.md``).
-    2. OAuth credentials at ``~/.finlet/credentials`` — populated by
-       ``finlet auth login``. The access token is a 15-minute
-       (``ACCESS_TOKEN_TTL = timedelta(seconds=900)`` —
-       ``finlet/auth/oauth/token.py``) EdDSA JWT, so this helper
-       auto-refreshes through the AS's ``/oauth/token``
-       ``grant_type=refresh_token`` endpoint when the stored access
-       token is within 30 seconds of expiry. A successful refresh
-       rotates the stored credentials atomically via
-       :func:`_write_credentials` and returns the new access token.
-
-       The 30-second safety margin is mandatory — it absorbs clock
-       skew between the client and the AS plus the round-trip latency
-       of in-flight MCP-over-HTTP requests that are about to use the
-       returned token.
-
-       Transient refresh failures (network / 5xx / malformed body)
-       fall back to the stored access token with a stderr ``Warning:``
-       so the caller still gets a request out — they may see a 401
-       which surfaces the canonical ``finlet auth login`` hint.
-
-       Hard failures (4xx ⇒ refresh-token revoked or invalid) return
-       ``None`` with a stderr ``Error:`` instructing the user to run
-       ``finlet auth login`` again.
-
-    Returns ``None`` when neither is available; callers MUST surface
-    the resulting "Authentication required" envelope to the user.
-    """
-    import time
-
-    import httpx
-
-    if api_key:
-        return api_key
-    creds = _load_credentials()
-    if creds is None:
-        return None
-
-    # 30-second safety margin: refresh before the AS would reject the
-    # JWT. Absorbs client/server clock skew plus the round-trip latency
-    # of any in-flight MCP-over-HTTP request that will use this token.
-    expires_at = int(creds.get("expires_at", 0))
-    if time.time() + 30 < expires_at:
-        token = creds.get("access_token")
-        return str(token) if token else None
-
-    # Token is expired (or within the 30s safety window); attempt
-    # refresh via RFC 6749 §6 refresh_token grant.
-    refresh_token = creds.get("refresh_token")
-    if not refresh_token:
-        typer.echo(
-            "Error: No refresh_token in credentials. Run `finlet auth login` again.",
-            err=True,
-        )
-        return None
-    try:
-        with httpx.Client(timeout=10) as client:
-            resp = client.post(
-                f"{_API_URL}/oauth/token",
-                data={
-                    "grant_type": "refresh_token",
-                    "refresh_token": refresh_token,
-                    "client_id": _OAUTH_CLIENT_ID,
-                    "resource": _OAUTH_RESOURCE_URI,
-                },
-            )
-    except (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError) as exc:
-        typer.echo(
-            f"Warning: Token refresh failed (transient error: {exc.__class__.__name__}). "
-            "Retrying with stored token; you may see a 401.",
-            err=True,
-        )
-        token = creds.get("access_token")
-        return str(token) if token else None
-
-    # 4xx ⇒ refresh-token rejected by the AS (revoked, expired, reused,
-    # client mismatch, invalid_grant — see ``_handle_refresh_token``).
-    # The stored credentials are no longer recoverable; the user must
-    # re-authorize.
-    if 400 <= resp.status_code < 500:
-        typer.echo(
-            "Refresh token expired. Run `finlet auth login` again.",
-            err=True,
-        )
-        return None
-
-    # 5xx ⇒ transient AS failure; fall back to the stored token so the
-    # caller's request still goes out. They may see a 401 if the JWT is
-    # already past expiry — which surfaces the same hint anyway.
-    if resp.status_code >= 500:
-        typer.echo(
-            f"Warning: Token refresh failed (server {resp.status_code}). "
-            "Retrying with stored token; you may see a 401.",
-            err=True,
-        )
-        token = creds.get("access_token")
-        return str(token) if token else None
-
-    try:
-        body = resp.json()
-    except (json.JSONDecodeError, ValueError):
-        typer.echo(
-            "Warning: Token refresh response was not valid JSON. "
-            "Retrying with stored token.",
-            err=True,
-        )
-        token = creds.get("access_token")
-        return str(token) if token else None
-
-    new_access = body.get("access_token")
-    new_refresh = body.get("refresh_token")
-    new_expires_in = body.get("expires_in", 0)
-    if not new_access or not new_refresh:
-        typer.echo(
-            "Warning: Token refresh response missing access_token or refresh_token. "
-            "Retrying with stored token.",
-            err=True,
-        )
-        token = creds.get("access_token")
-        return str(token) if token else None
-
-    _write_credentials(
-        {
-            "access_token": new_access,
-            "refresh_token": new_refresh,
-            "expires_at": int(time.time()) + int(new_expires_in),
-        }
-    )
-    return str(new_access)
-
-
-def _translate_mcp_error(envelope: dict[str, Any]) -> str | None:
-    """Convert an MCP tool error envelope to a human-readable message.
-
-    Finlet's MCP tools return ``{"error": "..."}`` on failure and a
-    success-shaped dict otherwise.  This helper accepts the raw envelope
-    and returns the error message string (when present), or ``None``
-    when the envelope is a success.
-
-    Mirrors :func:`_print_error` for the httpx surface — both produce
-    the ``Error: <message>`` shape downstream consumers expect.
-    """
-    err = envelope.get("error")
-    if err is None:
-        return None
-    if isinstance(err, str):
-        return err
-    if isinstance(err, dict):
-        message = err.get("message")
-        if isinstance(message, str):
-            return message
-    return str(err)
-
-
-def _dispatch_mcp_tool(
-    tool_name: str,
-    arguments: dict[str, Any] | None = None,
-    *,
-    api_key: str | None = None,
-    timeout: float = 120.0,
-) -> dict[str, Any]:
-    """Dispatch a tool call through the cloud ``/mcp`` HTTP endpoint.
-
-    Wraps :func:`finlet.cli_mcp_client.call_tool_sync` (v1.0.1 streamable
-    HTTP transport) with the CLI's error-mapping convention:
-    transport-level dispatch failures become a ``typer.Exit(1)`` after
-    printing a connect-error-style message, while tool-level error
-    envelopes are returned to the caller for inspection (commands
-    typically fan out to :func:`_translate_mcp_error` + ``typer.echo``
-    + ``typer.Exit(1)``).
-
-    The ``api_key`` argument is forwarded to
-    :func:`_resolve_bearer_token` so the CLI's full credential precedence
-    (explicit flag > env var > ``~/.finlet/credentials``) collapses to a
-    single Bearer value before the HTTP request.  The cloud ``/mcp``
-    endpoint accepts BOTH an OAuth JWT and a legacy ``fnlt_*`` api-key
-    in the ``Authorization`` header post-v1.0.1 (see
-    ``docs/decisions/cli-mcp-http-dispatch.md``).
-    """
-    bearer = _resolve_bearer_token(api_key)
-    try:
-        return call_tool_sync(
-            tool_name,
-            arguments,
-            bearer_token=bearer,
-            timeout=timeout,
-        )
-    except MCPDispatchError as exc:
-        typer.echo(f"Error: MCP dispatch failed — {exc}", err=True)
-        raise typer.Exit(1) from exc
-    except (TimeoutError, _AsyncioTimeoutError) as exc:
-        # asyncio.wait_for in cli_mcp_client raises asyncio.TimeoutError
-        # (which Python 3.11+ aliases to the builtin TimeoutError). Catch
-        # both forms so a session-create or any other tool that exceeds
-        # the timeout produces a one-line friendly message instead of a
-        # 60-line traceback (BLOCKER #5 — agent-guide first-command UX).
-        typer.echo(
-            f"Error: '{tool_name}' timed out after {timeout:.0f}s. "
-            "Try a smaller universe (e.g., --universe AAPL) or check finlet.dev status.",
-            err=True,
-        )
-        raise typer.Exit(1) from exc
-
-
-def _emit_envelope(envelope: dict[str, Any], *, as_json: bool, on_error_exit: int = 1) -> dict[str, Any]:
-    """Print the tool envelope in JSON or human form, exiting on error.
-
-    Returns the envelope when it is a success (no ``error`` key) so the
-    calling command can fan out into its bespoke pretty-print path. In
-    JSON mode, prints the envelope verbatim and returns it unchanged;
-    success path consumers in JSON mode skip their pretty-printers.
-
-    On error, prints the translated message via :func:`_translate_mcp_error`
-    (or the JSON envelope itself in JSON mode) and exits with
-    ``on_error_exit``.  Auth-failure envelopes (detected by the markers
-    in :data:`_AUTH_REQUIRED_MARKERS`) override ``on_error_exit`` to
-    :data:`EXIT_AUTH_REQUIRED` (2) so shell scripts can distinguish
-    "not authenticated" from other tool failures (F-3 hotfix —
-    ``docs/launch/blind-agent-coldstart-report-v1.0.3-fullwalk.md``).
-    """
-    err_message = _translate_mcp_error(envelope)
-    if err_message is not None:
-        is_auth_failure = any(marker in err_message for marker in _AUTH_REQUIRED_MARKERS)
-        if as_json:
-            typer.echo(json.dumps(envelope))
-        else:
-            typer.echo(f"Error: {err_message}", err=True)
-            if is_auth_failure:
-                typer.echo(_AUTH_REQUIRED_HINT, err=True)
-        exit_code = EXIT_AUTH_REQUIRED if is_auth_failure else on_error_exit
-        raise typer.Exit(exit_code)
-    if as_json:
-        typer.echo(json.dumps(envelope))
-    return envelope
-
-
@@ -516 +246,0 @@ def _root_callback(
-session_app = typer.Typer(help="Session management. See: finlet manual session-lifecycle")
@@ -520,6 +249,0 @@ mcp_app = typer.Typer(help="MCP server commands")
-benchmark_app = typer.Typer(
-    name="benchmark",
-    help="Run standardized blind/unblind benchmark runs.",
-    no_args_is_help=True,
-)
-app.add_typer(session_app, name="session")
@@ -529 +252,0 @@ app.add_typer(mcp_app, name="mcp")
-app.add_typer(benchmark_app, name="benchmark")
@@ -570,294 +293,6 @@ def serve(
-# ── session ──────────────────────────────────────────────────
-
-
-def _normalize_start_iso(start: str) -> str:
-    """Normalize the CLI's --start flag into the MCP tool's ISO 8601 input.
-
-    The MCP ``create_session`` tool calls :func:`datetime.fromisoformat`,
-    which accepts both ``2024-01-01`` and ``2024-01-01T00:00:00Z``.  We
-    pass through verbatim — the tool's error envelope surfaces a useful
-    message if the format is wrong.
-    """
-    return start
-
-
-@session_app.command("create")
-def session_create(
-    name: str = typer.Option(..., "--name", "-n", help="Session name"),
-    start: str = typer.Option(..., "--start", "-s", help="Start datetime (ISO format, e.g. 2024-01-01)"),
-    capital: float = typer.Option(100_000.0, "--capital", "-c", help="Initial capital"),
-    universe: str = typer.Option("", "--universe", "-u", help="Comma-separated ticker symbols"),
-    blind: bool = typer.Option(
-        False,
-        "--blind/--no-blind",
-        help="Create a blind session: agent sees opaque tickers and Day_N dates.",
-    ),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Create a new simulation session via the MCP ``create_session`` tool."""
-    tickers = [t.strip() for t in universe.split(",") if t.strip()] if universe else []
-    args: dict[str, Any] = {
-        "name": name,
-        "start_time": _normalize_start_iso(start),
-        "initial_capital": capital,
-        "universe": tickers,
-        "blind": blind,
-    }
-
-    envelope = _dispatch_mcp_tool("create_session", args, api_key=api_key)
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    typer.echo(f"Session created: {data['id']} ({data['name']})")
-    config = data.get("config", {})
-    typer.echo(f"  Start: {config.get('start_time', 'unknown')}")
-    typer.echo(f"  Capital: ${float(config.get('initial_capital', 0)):,.2f}")
-    # Codex Team D P1 (blind leak): print the response's universe, NOT the local
-    # --universe input. For blind sessions, the response carries opaque T_NNNN
-    # tickers; echoing the local list here leaked the real symbols even though
-    # the rest of the blind contract held. Falling back to the local list only
-    # if the response omits a universe keeps the non-blind UX identical.
-    universe_to_show = config.get("universe") or tickers
-    if universe_to_show:
-        typer.echo(f"  Universe: {', '.join(universe_to_show)}")
-
-
-@session_app.command("list")
-def session_list(
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """List all sessions via the MCP ``list_sessions`` tool."""
-    envelope = _dispatch_mcp_tool("list_sessions", {}, api_key=api_key)
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    sessions = data.get("sessions", [])
-    if not sessions:
-        typer.echo("No active sessions.")
-        return
-    for s in sessions:
-        clock_time = s.get("clock", {}).get("current_time", "unknown")
-        typer.echo(f"  {s['id']}  {s.get('name', s['id'])}  [{s['status']}]  {clock_time}")
-
-
-@session_app.command("delete")
-def session_delete(
-    session_id: str = typer.Argument(..., help="Session ID to delete"),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Delete a session via the MCP ``delete_session`` tool."""
-    envelope = _dispatch_mcp_tool(
-        "delete_session", {"session_id": session_id}, api_key=api_key
-    )
-    _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-    typer.echo(f"Session deleted: {session_id}")
-
-
-@session_app.command("publish")
-def session_publish(
-    session_id: str = typer.Argument(..., help="Session ID to publish or un-publish"),
-    anonymous: bool = typer.Option(
-        True,
-        "--anonymous/--attributed",
-        help="Anonymous (default) hides the session name; --attributed exposes the owner-supplied name.",
-    ),
-    unpublish: bool = typer.Option(
-        False,
-        "--unpublish",
-        help="Revoke public access for the session.",
-    ),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Toggle a session's public-share visibility via the MCP ``set_session_visibility`` tool.
-
-    On publish, prints the canonical public URL the owner can share.
-    On un-publish, prints a one-line confirmation.
-    """
-    make_public = not unpublish
-    args: dict[str, Any] = {
-        "session_id": session_id,
-        "public": make_public,
-        "anonymous": anonymous,
-    }
-    envelope = _dispatch_mcp_tool("set_session_visibility", args, api_key=api_key)
-    _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-    if make_public:
-        typer.echo(f"Published → https://finlet.dev/sessions/{session_id}")
-    else:
-        typer.echo(f"Unpublished → {session_id}")
-
-
-# ── benchmark ────────────────────────────────────────────────
-
-
-@benchmark_app.command("start")
-def benchmark_start(
-    agent_name: str = typer.Option(..., "--agent-name", help="Name of the agent being evaluated"),
-    model_used: str | None = typer.Option(
-        None, "--model-used", help="LLM model powering the agent (e.g. claude-sonnet-4-20250514)"
-    ),
-    strategy_category: str | None = typer.Option(
-        None,
-        "--strategy-category",
-        help="Strategy type: momentum | mean-reversion | fundamental | hybrid | other",
-    ),
-    description: str | None = typer.Option(
-        None, "--description", help="Brief description of the agent's approach"
-    ),
-    blind: bool = typer.Option(
-        False,
-        "--blind/--no-blind",
-        help=(
-            "Run as a blind benchmark — agent sees opaque T_NNNN tickers and "
-            "Day_N dates instead of real symbols / ISO dates. Default --no-blind."
-        ),
-    ),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Start a standardized benchmark run via the MCP ``start_benchmark`` tool.
-
-    Examples:
-      finlet benchmark start --agent-name my-bot
-      finlet benchmark start --agent-name my-bot --blind
-      finlet benchmark start --agent-name my-bot --model-used claude-sonnet-4-20250514
-
-    See: finlet manual benchmark-lifecycle
-    """
-    args: dict[str, Any] = {
-        "agent_name": agent_name,
-        "blind": blind,
-    }
-    if model_used is not None:
-        args["model_used"] = model_used
-    if strategy_category is not None:
-        args["strategy_category"] = strategy_category
-    if description is not None:
-        args["description"] = description
-
-    envelope = _dispatch_mcp_tool("start_benchmark", args, api_key=api_key)
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    run_id = data.get("benchmark_run_id", "?")
-    session_id = data.get("session_id", "?")
-    scenario_label = data.get("scenario", "?")
-    typer.echo(f"Benchmark started: run={run_id} session={session_id} scenario={scenario_label}")
-
-
-@benchmark_app.command("progress")
-def benchmark_progress(
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Show the active benchmark run's progress via the MCP ``get_benchmark_progress`` tool.
-
-    Useful when the agent loses context mid-run — returns the canonical resume hint
-    (scenario number, universe, dates, current clock + portfolio).
-    """
-    envelope = _dispatch_mcp_tool("get_benchmark_progress", {}, api_key=api_key)
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    run_id = data.get("benchmark_run_id", "?")
-    session_id = data.get("session_id", "?")
-    scenario = data.get("scenario") or {}
-    current = scenario.get("current", "?")
-    total = scenario.get("total", "?")
-    typer.echo(f"Benchmark progress: run={run_id} session={session_id} scenario={current}/{total}")
-
-
-@benchmark_app.command("decrypt")
-def benchmark_decrypt(
-    benchmark_run_id: str = typer.Argument(..., help="Benchmark run ID to decrypt"),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Unlock a completed benchmark run's blind mapping via the MCP
-    ``decrypt_benchmark_run`` tool.
-
-    After decrypting, subsequent ``finlet benchmark export`` calls AND the
-    anonymous public-export surface return REAL tickers/dates instead of
-    opaque ``T_NNNN`` / ``Day_N``. Idempotent — calling twice preserves the
-    original decrypt timestamp.
-    """
-    args: dict[str, Any] = {"benchmark_run_id": benchmark_run_id}
-    envelope = _dispatch_mcp_tool("decrypt_benchmark_run", args, api_key=api_key)
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-    decrypted_at = data.get("decrypted_at", "?")
-    typer.echo(f"Decrypted → run={benchmark_run_id} decrypted_at={decrypted_at}")
-
-
-@benchmark_app.command("visibility")
-def benchmark_visibility(
-    benchmark_run_id: str = typer.Argument(..., help="Benchmark run ID to publish or un-publish"),
-    anonymous: bool = typer.Option(
-        True,
-        "--anonymous/--attributed",
-        help=(
-            "Anonymous (default) hides the agent name; --attributed exposes the "
-            "owner-supplied agent_name."
-        ),
-    ),
-    unpublish: bool = typer.Option(
-        False,
-        "--unpublish",
-        help="Revoke public access for the benchmark run.",
-    ),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Toggle a benchmark run's public-share visibility via the MCP
-    ``set_benchmark_visibility`` tool.
-
-    On publish, prints the canonical public URL the owner can share.
-    On un-publish, prints a one-line confirmation. Publishing requires
-    a prior ``finlet benchmark decrypt`` call — the service rejects
-    ``--no-unpublish`` on a still-blinded run.
-    """
-    make_public = not unpublish
-    args: dict[str, Any] = {
-        "benchmark_run_id": benchmark_run_id,
-        "public": make_public,
-        "anonymous": anonymous,
-    }
-    envelope = _dispatch_mcp_tool("set_benchmark_visibility", args, api_key=api_key)
-    _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-    if make_public:
-        typer.echo(
-            f"Published → https://finlet.dev/benchmark-runs/{benchmark_run_id}"
-        )
-    else:
-        typer.echo(f"Unpublished → {benchmark_run_id}")
+# REMOVED in v2.0.0: session sub-app + benchmark sub-app.
+# Agents call the MCP tools (create_session / list_sessions /
+# delete_session / set_session_visibility / start_benchmark /
+# get_benchmark_progress / decrypt_benchmark_run /
+# set_benchmark_visibility) directly through their MCP client.
+# See `finlet manual quickstart`.
@@ -984 +419 @@ def plugins_add(
-        raise typer.Exit(2)
+        raise typer.Exit(EXIT_AUTH_REQUIRED)
@@ -1056 +491 @@ def plugins_remove(
-        raise typer.Exit(2)
+        raise typer.Exit(EXIT_AUTH_REQUIRED)
@@ -1346,3 +781,3 @@ def _run_oauth_login_flow() -> int:
-        # :func:`_write_credentials`, which is also reused by the
-        # auto-refresh path in :func:`_resolve_bearer_token` to rotate
-        # tokens in place when the AS issues a new pair.
+        # :func:`_write_credentials`. v2.0.0 dropped the CLI's MCP
+        # dispatch path, so token refresh is now an MCP-client concern;
+        # this helper persists the initial pair issued by the AS.
@@ -1575,2 +1010,3 @@ def auth_status() -> None:
-    (F-3 hotfix — matches the MCP tool-dispatch surface in
-    :func:`_emit_envelope`).
+    (F-3 hotfix); the same exit code is shared by
+    :func:`plugins_add` / :func:`plugins_remove` when ``FINLET_API_KEY``
+    is missing.
@@ -1582 +1018 @@ def auth_status() -> None:
-    surfaced when an actual tool call dispatches.
+    surfaced when an authenticated MCP / REST call is made.
@@ -1611,310 +1047,4 @@ def auth_status() -> None:
-# ── advance ─────────────────────────────────────────────────
-
-
-@app.command()
-def advance(
-    session: str = typer.Option(..., "--session", "-s", help="Session ID"),
-    days: int | None = typer.Option(
-        None,
-        "--days",
-        "-d",
-        help="Advance by N days in a single batched call (uses MCP advance_time steps)",
-    ),
-    to: str | None = typer.Option(
-        None,
-        "--to",
-        help="Advance to a specific date (YYYY-MM-DD). Mutually exclusive with --days.",
-    ),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Advance the simulation clock via the MCP ``advance_time`` tool.
-
-    Without flags, advances by one ``1d`` step.  ``--days N`` advances
-    by N daily intervals in a single batched call.  ``--to YYYY-MM-DD``
-    advances directly to that date via the tool's ``target_date``
-    parameter.  Flags are mutually exclusive.
-
-    Examples:
-      finlet advance --session sess_abc123
-      finlet advance --session sess_abc123 --days 5
-      finlet advance --session sess_abc123 --to 2024-06-30
-
-    See: finlet manual session-lifecycle
-    """
-    if days is not None and to is not None:
-        typer.echo("Error: --days and --to are mutually exclusive.", err=True)
-        raise typer.Exit(2)
-
-    if days is not None and days <= 0:
-        typer.echo("Error: --days must be a positive integer.", err=True)
-        raise typer.Exit(2)
-
-    if to is not None:
-        # Validate the format client-side so the user sees an immediate
-        # error rather than a tool-layer envelope. The tool itself does
-        # the same check; mirroring it here avoids the subprocess-spawn
-        # tax on a guaranteed-bad input.
-        try:
-            from datetime import datetime as _dt
-
-            _dt.strptime(to, "%Y-%m-%d")
-        except ValueError:
-            typer.echo(
-                f"Error: --to must be in YYYY-MM-DD format, got '{to}'.",
-                err=True,
-            )
-            raise typer.Exit(2)
-
-    args: dict[str, Any] = {"session_id": session, "interval": "1d"}
-    if to is not None:
-        args["target_date"] = to
-    elif days is not None:
-        args["steps"] = days
-
-    envelope = _dispatch_mcp_tool("advance_time", args, api_key=api_key)
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    typer.echo("Clock advanced:")
-    typer.echo(f"  Current time: {data.get('current_time', 'unknown')}")
-    typer.echo(f"  Mode: {data.get('mode', 'unknown')}")
-    fill_summary = data.get("fill_summary") or {}
-    if fill_summary:
-        typer.echo(
-            f"  Fills: {fill_summary.get('orders_filled', 0)} orders, "
-            f"{fill_summary.get('prices_updated', 0)} prices updated"
-        )
-
-
-# ── order ───────────────────────────────────────────────────
-
-
-@app.command()
-def order(
-    session: str = typer.Option(..., "--session", "-s", help="Session ID"),
-    ticker: str = typer.Option(..., "--ticker", "-t", help="Ticker symbol (e.g. AAPL)"),
-    side: str = typer.Option(..., "--side", help="BUY or SELL"),
-    quantity: float = typer.Option(..., "--quantity", "-q", help="Number of shares"),
-    order_type: str = typer.Option("MARKET", "--type", help="MARKET, LIMIT, or STOP"),
-    limit_price: float | None = typer.Option(None, "--limit-price", help="Limit price (required for LIMIT orders)"),
-    stop_price: float | None = typer.Option(None, "--stop-price", help="Stop price (required for STOP orders)"),
-    time_in_force: str = typer.Option("GTC", "--time-in-force", "--tif", help="DAY or GTC (currently MCP path always uses GTC)"),
-    reasoning: str | None = typer.Option(None, "--reasoning", help="Agent reasoning for this order"),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Submit a trade order via the MCP ``submit_order`` tool.
-
-    Supports MARKET (no price flags), LIMIT (requires ``--limit-price``),
-    and STOP (requires ``--stop-price``) orders. Client-side validation
-    rejects the most common operator footguns — LIMIT/STOP without a
-    price, or MARKET with a stray price — before the network round-trip.
-    ``--time-in-force`` is preserved for ergonomic stability but the
-    service-layer always defaults to GTC.
-
-    Examples:
-      finlet order --session sess_abc123 --ticker AAPL --side BUY --quantity 10
-      finlet order --session sess_abc123 --ticker AAPL --side BUY --quantity 10 --type LIMIT --limit-price 175.50
-
-    See: finlet manual session-lifecycle
-    """
-    # Client-side price validation per --type (H12). Catches the most common
-    # operator footgun (LIMIT/STOP without a price) BEFORE any network call,
-    # so the user sees an actionable client error instead of a tool-envelope
-    # round-trip plus a subprocess-spawn tax.
-    normalized_type = order_type.upper()
-    if normalized_type == "LIMIT":
-        if limit_price is None or limit_price <= 0:
-            raise typer.BadParameter(
-                "LIMIT orders require --limit-price > 0.",
-                param_hint="--limit-price",
-            )
-    elif normalized_type == "STOP":
-        if stop_price is None or stop_price <= 0:
-            raise typer.BadParameter(
-                "STOP orders require --stop-price > 0.",
-                param_hint="--stop-price",
-            )
-    elif normalized_type == "MARKET" and (
-        (limit_price is not None and limit_price != 0)
-        or (stop_price is not None and stop_price != 0)
-    ):
-        raise typer.BadParameter(
-            "MARKET orders must not specify --limit-price or --stop-price.",
-            param_hint="--type",
-        )
-
-    args: dict[str, Any] = {
-        "session_id": session,
-        "ticker": ticker,
-        "side": side.upper(),
-        "quantity": quantity,
-        "order_type": normalized_type,
-    }
-    if limit_price is not None:
-        args["limit_price"] = limit_price
-    if stop_price is not None:
-        args["stop_price"] = stop_price
-    if reasoning is not None:
-        args["reasoning"] = reasoning
-    # NOTE: ``time_in_force`` is not exposed by the MCP ``submit_order`` tool;
-    # the service-layer defaults to GTC. The CLI flag is preserved for
-    # ergonomic stability but is currently a no-op on the MCP dispatch path.
-    _ = time_in_force  # explicit ack of the unused flag for future extension.
-
-    envelope = _dispatch_mcp_tool("submit_order", args, api_key=api_key)
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    typer.echo("Order submitted:")
-    typer.echo(f"  ID: {data.get('id', 'unknown')}")
-    typer.echo(f"  Status: {data.get('status', 'unknown')}")
-    fill_price = data.get("fill_price")
-    if fill_price is not None:
-        typer.echo(f"  Fill price: ${fill_price:,.2f}")
-
-
-# ── portfolio ───────────────────────────────────────────────
-
-
-@app.command()
-def portfolio(
-    session: str = typer.Option(..., "--session", "-s", help="Session ID"),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Show portfolio positions, cash, and P&L via the MCP ``get_portfolio`` tool.
-
-    Renders an at-clock-time snapshot — positions with current market
-    value + unrealized P&L, cash balance, total portfolio value, and
-    aggregate order metrics. Output uses rich tables when available
-    and falls back to plain text otherwise. Pass ``--json`` to emit
-    the raw MCP envelope for programmatic consumers.
-
-    Examples:
-      finlet portfolio --session sess_abc123
-      finlet portfolio --session sess_abc123 --json
-
-    See: finlet manual session-lifecycle
-    """
-    envelope = _dispatch_mcp_tool(
-        "get_portfolio", {"session_id": session}, api_key=api_key
-    )
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    positions = data.get("positions", {})
-    cash = data.get("cash", 0.0)
-    total_value = data.get("total_value", 0.0)
-    unrealized_pnl = data.get("unrealized_pnl", 0.0)
-    metrics = data.get("metrics", {})
-
-    # Try rich table, fall back to plain text
-    try:
-        from rich.console import Console
-        from rich.table import Table
-
-        console = Console()
-
-        table = Table(title="Portfolio")
-        table.add_column("Ticker", style="cyan")
-        table.add_column("Quantity", justify="right")
-        table.add_column("Avg Entry", justify="right", style="dim")
-        table.add_column("Current Price", justify="right")
-        table.add_column("Market Value", justify="right")
-        table.add_column("Unrealized P&L", justify="right")
-
-        for pos in positions.values():
-            pnl = pos.get("unrealized_pnl", 0.0)
-            pnl_style = "green" if pnl >= 0 else "red"
-            table.add_row(
-                pos.get("ticker", "?"),
-                f"{pos.get('quantity', 0):.2f}",
-                f"${pos.get('avg_entry_price', 0):.2f}",
-                f"${pos.get('current_price', 0):.2f}",
-                f"${pos.get('market_value', 0):,.2f}",
-                f"[{pnl_style}]${pnl:,.2f}[/{pnl_style}]",
-            )
-
-        console.print(table)
-        console.print(f"  Cash: ${cash:,.2f}")
-        console.print(f"  Total value: ${total_value:,.2f}")
-        pnl_label = f"${unrealized_pnl:,.2f}" if unrealized_pnl >= 0 else f"-${abs(unrealized_pnl):,.2f}"
-        console.print(f"  Unrealized P&L: {pnl_label}")
-        if metrics:
-            console.print(
-                f"  Orders: {metrics.get('total_orders', 0)} total, {metrics.get('filled_orders', 0)} filled"
-            )
-    except ImportError:
-        # Plain text fallback
-        typer.echo("Portfolio:")
-        if positions:
-            typer.echo(f"  {'Ticker':<8} {'Qty':>8} {'Avg Entry':>10} {'Price':>10} {'Value':>12} {'P&L':>12}")
-            typer.echo(f"  {'-' * 8} {'-' * 8} {'-' * 10} {'-' * 10} {'-' * 12} {'-' * 12}")
-            for pos in positions.values():
-                typer.echo(
-                    f"  {pos.get('ticker', '?'):<8} "
-                    f"{pos.get('quantity', 0):>8.2f} "
-                    f"${pos.get('avg_entry_price', 0):>9.2f} "
-                    f"${pos.get('current_price', 0):>9.2f} "
-                    f"${pos.get('market_value', 0):>11,.2f} "
-                    f"${pos.get('unrealized_pnl', 0):>11,.2f}"
-                )
-        else:
-            typer.echo("  No positions.")
-        typer.echo(f"  Cash: ${cash:,.2f}")
-        typer.echo(f"  Total value: ${total_value:,.2f}")
-        typer.echo(f"  Unrealized P&L: ${unrealized_pnl:,.2f}")
-
-
-# ── status ──────────────────────────────────────────────────
-
-
-@app.command()
-def status(
-    session: str = typer.Option(..., "--session", "-s", help="Session ID"),
-    api_key: str | None = typer.Option(
-        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
-    ),
-    as_json: bool = typer.Option(False, "--json", help="Emit the raw MCP tool envelope as JSON"),
-) -> None:
-    """Show session status via the MCP ``get_session`` tool.
-
-    Reports the session ID, name, lifecycle status, simulation clock
-    (current sim time + mode — FROZEN / STEPPING / CONTINUOUS), the
-    configured universe, and the initial capital. Pass ``--json`` to
-    emit the raw MCP envelope for programmatic consumers.
-
-    Examples:
-      finlet status --session sess_abc123
-
-    See: finlet manual session-lifecycle
-    """
-    envelope = _dispatch_mcp_tool(
-        "get_session", {"session_id": session}, api_key=api_key
-    )
-    data = _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-
-    typer.echo(f"Session: {data.get('name', data.get('id', 'unknown'))}")
-    typer.echo(f"  ID: {data.get('id', 'unknown')}")
-    typer.echo(f"  Status: {data.get('status', 'unknown')}")
-    clock = data.get("clock", {})
-    typer.echo(f"  Sim time: {clock.get('current_time', 'unknown')}")
-    typer.echo(f"  Mode: {clock.get('mode', 'unknown')}")
-    config = data.get("config", {})
-    universe = config.get("universe", [])
-    if universe:
-        typer.echo(f"  Universe: {', '.join(universe)}")
-    typer.echo(f"  Capital: ${config.get('initial_capital', 0):,.2f}")
+# REMOVED in v2.0.0: top-level advance / order / portfolio / status.
+# Agents call the MCP tools (advance_time / submit_order / get_portfolio /
+# get_session) directly through their MCP client. See
+# `finlet manual quickstart`.
@@ -1986 +1116 @@ def mcp_serve() -> None:
-        typer.echo("Use MCP-over-HTTP with finlet.dev instead.", err=True)
+        typer.echo("Point your MCP client at https://finlet.dev/mcp instead.", err=True)
@@ -2008 +1138 @@ def mcp_serve() -> None:
-        typer.echo("Use MCP-over-HTTP with finlet.dev instead.", err=True)
+        typer.echo("Point your MCP client at https://finlet.dev/mcp instead.", err=True)

exec
/bin/zsh -lc "nl -ba finlet/cli.py | sed -n '1,120p;390,510p;760,1030p;1090,1150p'" in /Users/justnau/finlet
 succeeded in 0ms:
     1	"""CLI entrypoint — finlet serve / register / auth / plugins / mcp / manual.
     2	
     3	v2.0.0 (Pure-MCP) ships a deliberately minimal CLI: the only commands
     4	are the ones that ARE NOT MCP tool calls. Every agentic-trading
     5	operation (session / clock / order / portfolio / benchmark / status)
     6	runs over MCP — agents talk to the cloud ``/mcp`` endpoint directly
     7	via their own MCP client. The CLI no longer hosts a dispatch surface
     8	for those operations.
     9	
    10	Six command families remain (the v2.0.0 surface):
    11	
    12	* ``finlet serve`` — boots the API process; not a tool call.
    13	* ``finlet register`` — REST registration is the bootstrap before any
    14	  OAuth credential exists.
    15	* ``finlet auth login`` / ``finlet auth logout`` / ``finlet auth status``
    16	  — OAuth + REST endpoints the MCP tool surface intentionally does not
    17	  host; ``auth status`` is a local-only credentials check.
    18	* ``finlet plugins list`` / ``finlet plugins add`` / ``finlet plugins remove``
    19	  — tenant plugin-credential management against ``/v1/settings/plugins``
    20	  and ``/v1/plugins/health``. Finlet's MCP tool surface is the
    21	  agentic-trading surface and intentionally does not expose plugin
    22	  write paths.
    23	* ``finlet mcp serve`` — self-host stdio MCP server for niche
    24	  integrations (e.g., Claude Code stdio bridge).
    25	* ``finlet manual`` — local user-manual topics shipped with the wheel.
    26	
    27	The pre-v2.0.0 ``session`` / ``benchmark`` / ``advance`` / ``order`` /
    28	``portfolio`` / ``status`` subcommands are gone; agents address the
    29	cloud ``/mcp`` endpoint directly.
    30	"""
    31	
    32	from __future__ import annotations
    33	
    34	import importlib.metadata as _md
    35	import json
    36	import os
    37	import sys
    38	from typing import Any
    39	
    40	import typer
    41	
    42	#: Exit code for auth-required CLI invocations.  Shell scripts can detect
    43	#: an auth failure with ``[ $? -eq 2 ]``.  Centralised here so all CLI
    44	#: auth-failure paths share a single source of truth (F-3 hotfix — see
    45	#: ``docs/launch/blind-agent-coldstart-report-v1.0.3-fullwalk.md``).
    46	EXIT_AUTH_REQUIRED = 2
    47	
    48	_API_URL = os.environ.get("FINLET_API_URL", "https://finlet.dev")
    49	
    50	#: Canonical Finlet OAuth Authorization Server issuer (decision record §5).
    51	#: The CLI talks to ``${FINLET_API_URL}`` for OAuth endpoints — same host
    52	#: as the resource server, so localhost / staging deployments work without
    53	#: rebinding the issuer. The audience binding (RFC 8707) is the resource
    54	#: indicator below, NOT the issuer.
    55	_OAUTH_RESOURCE_URI = "https://finlet.dev/mcp"
    56	
    57	#: MVP client identity (decision record §1, §3). Hardcoded constant —
    58	#: the CLI ships as a public-by-default OAuth client. First-run DCR
    59	#: (Option B) is documented as a future improvement; the MVP avoids the
    60	#: complexity of persisting a registered ``client_id`` and the round-trip
    61	#: latency of the first registration call.
    62	_OAUTH_CLIENT_ID = "finlet-cli"
    63	
    64	#: CLI scopes requested at /authorize. Mirrors the four-scope contract
    65	#: locked by the Phase 4a decision record (§1) and B2's metadata
    66	#: handler (``SUPPORTED_SCOPES``). ``finlet:admin`` is intentionally NOT
    67	#: requested by the CLI — admin scope is reserved for explicit operator
    68	#: workflows and would not be approved on a typical agent flow.
    69	_DEFAULT_OAUTH_SCOPES = "finlet:read finlet:trade finlet:benchmark"
    70	
    71	
    72	def _credentials_path() -> str:
    73	    """Return the absolute path to ``~/.finlet/credentials``.
    74	
    75	    Resolves from ``$HOME`` via :func:`os.path.expanduser`, so tests can
    76	    redirect the path by monkeypatching ``HOME`` to a tmp directory.
    77	    """
    78	    return os.path.expanduser("~/.finlet/credentials")
    79	
    80	
    81	def _load_credentials() -> dict[str, Any] | None:
    82	    """Read OAuth credentials from ``~/.finlet/credentials``.
    83	
    84	    Returns ``None`` when the file does not exist (caller must fall back
    85	    to ``--api-key`` or raise an error). Raises :class:`RuntimeError`
    86	    when the file's mode bits are looser than ``0o600`` on POSIX systems
    87	    — an explicit fail-loud contract per audit C4 + the Phase 4a
    88	    decision record (§5 — token storage at mode 0600).
    89	
    90	    Windows (``sys.platform == "win32"``) skips the mode check because
    91	    POSIX permission bits are not the cross-platform convention there.
    92	    """
    93	    path = _credentials_path()
    94	    if not os.path.exists(path):
    95	        return None
    96	    if sys.platform != "win32":
    97	        mode = os.stat(path).st_mode & 0o777
    98	        if mode != 0o600:
    99	            raise RuntimeError(
   100	                f"Credentials file {path} has insecure mode {oct(mode)} — "
   101	                "expected 0600. Run `chmod 600 ~/.finlet/credentials` or "
   102	                "`finlet auth logout && finlet auth login`."
   103	            )
   104	    with open(path) as f:
   105	        data: dict[str, Any] = json.load(f)
   106	    return data
   107	
   108	
   109	def _write_credentials(payload: dict[str, Any]) -> None:
   110	    """Persist OAuth credentials to ``~/.finlet/credentials`` at mode 0600.
   111	
   112	    Atomic write contract (decision record §5): the file is created with
   113	    ``O_CREAT|O_WRONLY|O_TRUNC + 0o600`` so it never exists with looser
   114	    bits. A re-``chmod`` after write defends against a pre-existing
   115	    file's mode bits sneaking past the open-create semantics — most
   116	    platforms apply the mode on creation only, not on truncation of an
   117	    existing file.
   118	
   119	    Windows (``sys.platform == "win32"``) lacks POSIX mode bits and
   120	    relies on the user's NTFS ACLs in the home directory (decision
   390	        status = p.get("status", "unknown")
   391	        local_marker = " (configured)" if name in configured else ""
   392	        typer.echo(f"  {name:18s}  [{ptype:30s}]  {status}{local_marker}")
   393	
   394	
   395	@plugins_app.command("add")
   396	def plugins_add(
   397	    name: str = typer.Argument(..., help="Plugin name (e.g. 'finnhub', 'fred')"),
   398	    api_key: str | None = typer.Option(None, "--api-key", "-k", help="API key for the plugin"),
   399	    email: str | None = typer.Option(None, "--email", "-e", help="Email (for EDGAR User-Agent)"),
   400	) -> None:
   401	    """Configure a plugin with API key or settings.
   402	
   403	    Writes the plugin config via the canonical, authenticated server
   404	    endpoint ``PUT /v1/settings/plugins`` — the same path the dashboard
   405	    settings page uses. The server hot-reloads the plugin in place and
   406	    returns the post-reload health status, which the CLI prints so the
   407	    caller knows whether their config was accepted (e.g. EDGAR reports
   408	    ``unhealthy`` if no email / identity was supplied).
   409	
   410	    Authentication uses ``FINLET_API_KEY`` from the environment (a
   411	    Finlet account API key, NOT a third-party plugin key). The CLI no
   412	    longer writes a local ``~/.finlet/plugins.json``.
   413	    """
   414	    import httpx
   415	
   416	    finlet_key = os.environ.get("FINLET_API_KEY")
   417	    if not finlet_key:
   418	        typer.echo(_MISSING_API_KEY_MESSAGE, err=True)
   419	        raise typer.Exit(EXIT_AUTH_REQUIRED)
   420	
   421	    body: dict[str, object] = {"plugin": name, "enabled": True}
   422	    if api_key is not None:
   423	        body["api_key"] = api_key
   424	    if email is not None:
   425	        body["email"] = email
   426	
   427	    try:
   428	        resp = httpx.put(
   429	            f"{_API_URL}/v1/settings/plugins",
   430	            json=body,
   431	            headers=_api_headers(finlet_key),
   432	            timeout=30,
   433	        )
   434	        resp.raise_for_status()
   435	        data = resp.json()
   436	    except httpx.ConnectError:
   437	        typer.echo(
   438	            "Error: Cannot connect to Finlet server. Run 'finlet serve' first or "
   439	            "set FINLET_API_URL to a reachable host.",
   440	            err=True,
   441	        )
   442	        raise typer.Exit(1)
   443	    except httpx.HTTPStatusError as e:
   444	        if e.response.status_code in (401, 403):
   445	            typer.echo(_AUTH_REJECTED_MESSAGE, err=True)
   446	            raise typer.Exit(1)
   447	        _print_error(e)
   448	        raise typer.Exit(1)
   449	    except httpx.HTTPError as e:
   450	        typer.echo(f"Error: Could not write plugin config: {e}", err=True)
   451	        raise typer.Exit(1)
   452	
   453	    health = data.get("health") or {}
   454	    status = health.get("status") or data.get("status", "unknown")
   455	    message = health.get("message") or data.get("message") or ""
   456	    suffix = f" — {message}" if message else ""
   457	    typer.echo(f"Plugin '{name}' status: {status}{suffix}")
   458	
   459	
   460	@plugins_app.command("remove")
   461	def plugins_remove(
   462	    name: str = typer.Argument(
   463	        ..., help="Plugin name to remove (clears credentials and disables for the calling user)"
   464	    ),
   465	    api_key: str | None = typer.Option(
   466	        None, "--api-key", "-k", envvar="FINLET_API_KEY", help="API key for authentication"
   467	    ),
   468	) -> None:
   469	    """Clear credentials and disable a plugin for the calling user.
   470	
   471	    PUTs ``{plugin: <name>, api_key: "", email: "", enabled: False}`` to
   472	    ``/v1/settings/plugins``. The server-side ``update_plugin`` handler
   473	    treats empty strings as "clear" and calls ``registry.reload()`` with
   474	    the cleared config, which yields ``_initialized=False`` for the
   475	    calling tenant. This does NOT unload the process-global plugin
   476	    singleton — other tenants on the same instance retain their configs
   477	    (see ``finlet/api/services/settings_service.py:226-229`` for the
   478	    multi-tenant contract).
   479	
   480	    Authentication uses ``FINLET_API_KEY`` from the environment (a
   481	    Finlet account API key, NOT a third-party plugin key). On success,
   482	    the CLI prints the post-reload health status so the caller can
   483	    confirm the plugin reports ``unhealthy`` (cleared) without a second
   484	    round-trip.
   485	    """
   486	    import httpx
   487	
   488	    finlet_key = api_key or os.environ.get("FINLET_API_KEY")
   489	    if not finlet_key:
   490	        typer.echo(_MISSING_API_KEY_MESSAGE, err=True)
   491	        raise typer.Exit(EXIT_AUTH_REQUIRED)
   492	
   493	    body: dict[str, object] = {
   494	        "plugin": name,
   495	        "enabled": False,
   496	        "api_key": "",
   497	        "email": "",
   498	    }
   499	
   500	    try:
   501	        resp = httpx.put(
   502	            f"{_API_URL}/v1/settings/plugins",
   503	            json=body,
   504	            headers=_api_headers(finlet_key),
   505	            timeout=30,
   506	        )
   507	        resp.raise_for_status()
   508	        data = resp.json()
   509	    except httpx.ConnectError:
   510	        typer.echo(
   760	            typer.echo(
   761	                "Error: Token endpoint returned non-JSON body.",
   762	                err=True,
   763	            )
   764	            return 1
   765	
   766	        access_token = token_data.get("access_token")
   767	        refresh_token = token_data.get("refresh_token")
   768	        expires_in = token_data.get("expires_in", 0)
   769	        if not access_token or not refresh_token:
   770	            typer.echo(
   771	                "Error: Token endpoint response missing access_token or "
   772	                "refresh_token field.",
   773	                err=True,
   774	            )
   775	            return 1
   776	
   777	        expires_at = int(time.time()) + int(expires_in)
   778	
   779	        # ----- Persist credentials at mode 0600 -----
   780	        # Atomic write contract (decision record §5) lives in
   781	        # :func:`_write_credentials`. v2.0.0 dropped the CLI's MCP
   782	        # dispatch path, so token refresh is now an MCP-client concern;
   783	        # this helper persists the initial pair issued by the AS.
   784	        _write_credentials(
   785	            {
   786	                "access_token": access_token,
   787	                "refresh_token": refresh_token,
   788	                "expires_at": expires_at,
   789	            }
   790	        )
   791	        creds_path = _credentials_path()
   792	
   793	        typer.echo("Login successful!")
   794	        typer.echo(f"  Credentials saved to {creds_path} (mode 0600)")
   795	        typer.echo(
   796	            f"  Access token expires in {int(expires_in)} seconds; "
   797	            "the CLI will pick it up automatically on subsequent commands."
   798	        )
   799	        return 0
   800	    finally:
   801	        server.shutdown()
   802	        server.server_close()
   803	
   804	
   805	def _verify_api_key_credential(api_key: str) -> int:
   806	    """Verify an API key against the live server.
   807	
   808	    The legacy ``--api-key`` mode of ``finlet auth login`` performs a
   809	    credential-verification round-trip — it does NOT mint a new API
   810	    key. Audit C4 (`docs/decisions/auth-login-cli-vs-api-key.md`)
   811	    locked this invariant: login is verification, not minting.
   812	
   813	    The verification call hits ``GET /v1/settings/plugins`` (the same
   814	    authenticated endpoint ``finlet plugins list`` cross-references for
   815	    the configured-marker), which returns 401/403 for an invalid key
   816	    and a JSON body for a valid one. Any 2xx response means the key
   817	    works; the body shape is irrelevant.
   818	    """
   819	    import httpx
   820	
   821	    try:
   822	        resp = httpx.get(
   823	            f"{_API_URL}/v1/settings/plugins",
   824	            headers=_api_headers(api_key),
   825	            timeout=10,
   826	        )
   827	    except httpx.ConnectError:
   828	        typer.echo("Error: Cannot connect to Finlet server.", err=True)
   829	        return 1
   830	
   831	    if resp.status_code in (401, 403):
   832	        typer.echo(_AUTH_REJECTED_MESSAGE, err=True)
   833	        return 1
   834	    if resp.status_code >= 400:
   835	        try:
   836	            err = httpx.HTTPStatusError(
   837	                message=f"HTTP {resp.status_code}",
   838	                request=resp.request if hasattr(resp, "request") else None,  # type: ignore[arg-type]
   839	                response=resp,
   840	            )
   841	            _print_error(err)
   842	        except Exception:
   843	            typer.echo(
   844	                f"Error: API key verification failed with HTTP {resp.status_code}.",
   845	                err=True,
   846	            )
   847	        return 1
   848	
   849	    typer.echo("API key verified.")
   850	    typer.echo("  The provided FINLET_API_KEY authenticates against the server.")
   851	    typer.echo("")
   852	    typer.echo(
   853	        "Note: `finlet auth login --api-key=...` verifies an existing key — it "
   854	        "does not mint a new one. Issue keys from the dashboard, or run "
   855	        "`finlet register` for first-time setup. OAuth (no flag) is the "
   856	        "canonical agent-auth path on the MCP HTTP surface; `--api-key` is "
   857	        "preserved as a convenience for confirming an existing FINLET_API_KEY "
   858	        "works against Finlet's REST surface."
   859	    )
   860	    return 0
   861	
   862	
   863	def _verify_email_password_credential(email: str, password: str) -> int:
   864	    """Verify email + password against ``POST /auth/login``.
   865	
   866	    The legacy email/password mode of ``finlet auth login`` calls the
   867	    canonical credential-verification endpoint, prints the user
   868	    identity + tier on success, and reminds the caller that the CLI
   869	    authenticates via ``FINLET_API_KEY`` (a separate credential). Audit
   870	    C4 lineage: login does NOT mint a new API key on this path either.
   871	    """
   872	    import httpx
   873	
   874	    body = {"email": email, "password": password}
   875	
   876	    try:
   877	        resp = httpx.post(f"{_API_URL}/auth/login", json=body, timeout=10)
   878	        resp.raise_for_status()
   879	        data = resp.json()
   880	    except httpx.ConnectError:
   881	        typer.echo("Error: Cannot connect to Finlet server.", err=True)
   882	        return 1
   883	    except httpx.HTTPStatusError as e:
   884	        _print_error(e)
   885	        return 1
   886	
   887	    if data.get("mfa_required"):
   888	        methods = ", ".join(data.get("mfa_methods") or []) or "totp"
   889	        typer.echo("MFA required to complete login.")
   890	        typer.echo(f"  Methods: {methods}")
   891	        typer.echo(
   892	            "Submit your code via POST /auth/mfa/validate (use the dashboard "
   893	            "or your authenticator app)."
   894	        )
   895	        return 0
   896	
   897	    typer.echo("Login successful!")
   898	    typer.echo(f"  User: {data.get('email', email)}")
   899	    typer.echo(f"  Tier: {data.get('tier', 'free')}")
   900	    typer.echo("")
   901	    typer.echo(
   902	        "Login establishes a session for the dashboard. CLI commands "
   903	        "authenticate via FINLET_API_KEY — set it from a previously-issued "
   904	        "API key:"
   905	    )
   906	    typer.echo("  export FINLET_API_KEY=fk_...")
   907	    return 0
   908	
   909	
   910	@auth_app.command("login")
   911	def auth_login(
   912	    email: str | None = typer.Option(None, "--email", "-e", help="Account email address (legacy email/password mode)"),
   913	    password: str | None = typer.Option(
   914	        None,
   915	        "--password",
   916	        "-p",
   917	        help="Account password (legacy email/password mode; prompted if --email is supplied without it)",
   918	    ),
   919	    api_key: str | None = typer.Option(
   920	        None,
   921	        "--api-key",
   922	        "-k",
   923	        envvar="FINLET_API_KEY",
   924	        help="Verify an existing API key (legacy mode). Verification only; no key is minted.",
   925	    ),
   926	) -> None:
   927	    """Sign in to Finlet.
   928	
   929	    Three modes, gated by which flag (if any) is supplied:
   930	
   931	    * No flags → **OAuth Authorization Code Flow with PKCE** (RFC 7636).
   932	      Opens the user's browser to ``/oauth/authorize``, captures the
   933	      code on a loopback redirect (RFC 8252 §7.3), exchanges it at
   934	      ``/oauth/token`` for a 15-minute EdDSA JWT access token + opaque
   935	      refresh token, and persists both at ``~/.finlet/credentials``
   936	      (mode 0600). Subsequent CLI commands authenticate via the
   937	      access token automatically. This is the canonical agent-auth
   938	      path post-Phase 4 (see ``docs/decisions/mcp-oauth-2-1-auth-model.md``).
   939	    * ``--api-key=<key>`` → verify an existing API key. The CLI calls
   940	      an authenticated endpoint and reports whether the key works.
   941	      Audit C4 lineage: this path does NOT mint a new API key.
   942	      Convenience mode: confirm an existing ``FINLET_API_KEY`` value
   943	      authenticates against Finlet's REST surface.
   944	    * ``--email`` + ``--password`` → verify email + password. Calls
   945	      ``POST /auth/login``, returns user identity + tier, reminds the
   946	      caller that the CLI authenticates via ``FINLET_API_KEY``.
   947	      Establishes a dashboard session cookie via the server response.
   948	
   949	    The OAuth path is the default; the two legacy paths are explicit
   950	    opt-ins for credential-verification workflows.
   951	    """
   952	    if api_key is not None:
   953	        exit_code = _verify_api_key_credential(api_key)
   954	        if exit_code != 0:
   955	            raise typer.Exit(exit_code)
   956	        return
   957	
   958	    if email is not None:
   959	        # Prompt for password only when --email is supplied without --password.
   960	        if password is None:
   961	            password = typer.prompt("Password", hide_input=True)
   962	        exit_code = _verify_email_password_credential(email, password)
   963	        if exit_code != 0:
   964	            raise typer.Exit(exit_code)
   965	        return
   966	
   967	    if password is not None and email is None:
   968	        raise typer.BadParameter(
   969	            "--password requires --email. To run OAuth login, omit both flags."
   970	        )
   971	
   972	    # No flags → OAuth Authorization Code Flow.
   973	    exit_code = _run_oauth_login_flow()
   974	    if exit_code != 0:
   975	        raise typer.Exit(exit_code)
   976	
   977	
   978	@auth_app.command("logout")
   979	def auth_logout() -> None:
   980	    """Delete locally stored OAuth credentials.
   981	
   982	    Removes ``~/.finlet/credentials`` if present, idempotent otherwise.
   983	    Does NOT revoke the refresh token at the server — server-side
   984	    revocation is a future improvement (the refresh token expires
   985	    naturally at its absolute lifetime per Phase 4a decision record §5).
   986	    """
   987	    path = _credentials_path()
   988	    if os.path.exists(path):
   989	        os.remove(path)
   990	        typer.echo(f"Logged out — removed {path}")
   991	    else:
   992	        typer.echo("Already logged out (no credentials file found).")
   993	
   994	
   995	@auth_app.command("status")
   996	def auth_status() -> None:
   997	    """Report current authentication state from local credentials file.
   998	
   999	    Reads ``~/.finlet/credentials`` and reports one of:
  1000	
  1001	    * **Not logged in** — file missing or empty. Exit 2.
  1002	    * **Logged in** — file present and ``expires_at`` is in the future.
  1003	      Exit 0. Reports how many minutes remain until token expiry.
  1004	    * **Token expired** — file present but ``expires_at`` <= now.
  1005	      Exit 2. Suggests running ``finlet auth login`` to refresh.
  1006	    * **Credentials file unreadable** (e.g., insecure mode). Exit 1.
  1007	
  1008	    Auth-failure paths exit :data:`EXIT_AUTH_REQUIRED` (2) so shell
  1009	    scripts can distinguish "not authenticated" from other CLI errors
  1010	    (F-3 hotfix); the same exit code is shared by
  1011	    :func:`plugins_add` / :func:`plugins_remove` when ``FINLET_API_KEY``
  1012	    is missing.
  1013	
  1014	    This is a purely local check — does NOT ping the server. Use this
  1015	    command to verify the local credentials state before assuming
  1016	    authenticated CLI commands will succeed. Server-side rejection
  1017	    (e.g., the refresh token was revoked from the dashboard) is only
  1018	    surfaced when an authenticated MCP / REST call is made.
  1019	    """
  1020	    import time
  1021	
  1022	    try:
  1023	        creds = _load_credentials()
  1024	    except RuntimeError as exc:
  1025	        # ``_load_credentials`` raises on insecure file mode; surface
  1026	        # the message verbatim so the user sees the same actionable hint
  1027	        # other CLI commands print on the same condition.  Exit 1 — this
  1028	        # is a configuration error, not a missing-credential auth failure.
  1029	        typer.echo(f"Error: {exc}", err=True)
  1030	        raise typer.Exit(1) from exc
  1090	       JWT ``sub`` claim to a ``UserRecord``; without it, the validator's
  1091	       ``get_by_id`` would always miss in this fresh-process subprocess and
  1092	       the tool would return the documented "Authentication required"
  1093	       envelope on every call.
  1094	    3. Hand stdout to FastMCP via ``mcp_server.run(transport="stdio")``.
  1095	
  1096	    The FastAPI app boots this same cache via its lifespan handler;
  1097	    stdio mode skips the lifespan, so the CLI's MCP entry point owns
  1098	    it.
  1099	
  1100	    Examples:
  1101	      finlet mcp serve
  1102	
  1103	    See: finlet manual transports
  1104	    """
  1105	    # STEP 1: configure logging BEFORE importing finlet.mcp.server.  The
  1106	    # server import binds ``logger = structlog.get_logger()`` at module
  1107	    # top (finlet/mcp/server.py:77) and transitively re-binds the same
  1108	    # in dozens of other modules (finlet/auth/service.py, finlet/core/*,
  1109	    # etc.).  ``structlog.configure(..., cache_logger_on_first_use=True)``
  1110	    # snapshots the wrapper on first use, so we MUST configure before any
  1111	    # of those bindings is exercised.
  1112	    try:
  1113	        from finlet.logging import configure_logging
  1114	    except ImportError:
  1115	        typer.echo("Error: Local MCP server requires the full Finlet installation.", err=True)
  1116	        typer.echo("Point your MCP client at https://finlet.dev/mcp instead.", err=True)
  1117	        typer.echo("Install server with: pip install finlet[server]", err=True)
  1118	        raise typer.Exit(1)
  1119	    configure_logging()
  1120	
  1121	    # Defense-in-depth: even if some third-party import bypasses structlog
  1122	    # and prints to stdout directly, the stdio transport STILL expects
  1123	    # JSONRPC there.  We capture the real stdout BEFORE FastMCP grabs
  1124	    # ``sys.stdout.buffer`` and rebind the Python-level ``sys.stdout`` to
  1125	    # ``sys.stderr`` so subsequent ``print()`` calls land on stderr.
  1126	    # FastMCP's ``stdio_server`` reads ``sys.stdout.buffer`` ONCE at run
  1127	    # time — by then ``sys.stdout`` points at stderr, but we restore it
  1128	    # for that single read so JSONRPC writes go to the right pipe.
  1129	    # (See finlet/mcp/server.py docstring; the recon path is
  1130	    # docs/plans/EXECUTION_PLAN_V1_0_0_BLIND_WALK_FIXES.md HIGH #5.)
  1131	    _real_stdout = sys.stdout
  1132	    sys.stdout = sys.stderr
  1133	
  1134	    try:
  1135	        from finlet.mcp.server import mcp as mcp_server
  1136	    except ImportError:
  1137	        typer.echo("Error: Local MCP server requires the full Finlet installation.", err=True)
  1138	        typer.echo("Point your MCP client at https://finlet.dev/mcp instead.", err=True)
  1139	        typer.echo("Install server with: pip install finlet[server]", err=True)
  1140	        raise typer.Exit(1)
  1141	
  1142	    # Hydrate the auth_service cache so JWT ``sub`` → UserRecord lookups
  1143	    # succeed in the subprocess.  ``load_all()`` is idempotent and runs
  1144	    # the migration if the auth.db schema is behind.
  1145	    import asyncio as _asyncio
  1146	
  1147	    from finlet.auth.service import auth_service
  1148	
  1149	    try:
  1150	        _asyncio.run(auth_service.load_all())

exec
/bin/zsh -lc "rg -n \"EXIT_AUTH_REQUIRED|MCP-over-HTTP|v1\\.0\\.1|dispatch contract|_resolve_bearer_token|_dispatch_mcp_tool|_emit_envelope|_translate_mcp_error|_AsyncioTimeoutError|session_app|benchmark_app|@app.command\\(|@plugins_app.command|@auth_app.command|@mcp_app.command|def (advance|order|portfolio|status|session_|benchmark_)\" finlet/cli.py" in /Users/justnau/finlet
 succeeded in 0ms:
46:EXIT_AUTH_REQUIRED = 2
258:@app.command()
315:@plugins_app.command("list")
395:@plugins_app.command("add")
419:        raise typer.Exit(EXIT_AUTH_REQUIRED)
460:@plugins_app.command("remove")
491:        raise typer.Exit(EXIT_AUTH_REQUIRED)
536:@app.command()
910:@auth_app.command("login")
978:@auth_app.command("logout")
995:@auth_app.command("status")
1008:    Auth-failure paths exit :data:`EXIT_AUTH_REQUIRED` (2) so shell
1034:        raise typer.Exit(EXIT_AUTH_REQUIRED)
1040:        raise typer.Exit(EXIT_AUTH_REQUIRED)
1056:@mcp_app.command("serve")
1171:@app.command()

codex
The first hard mismatch is already visible: the commit changed the `plugins add/remove` exit literals even though the plan explicitly called that “beyond v2.0.0 scope — leave as-is.” I’m also checking help output and orphan references so the final review is evidence-backed.
exec
/bin/zsh -lc 'python -c "import finlet.cli; from finlet.cli import app"' in /Users/justnau/finlet
 exited 127 in 0ms:
zsh:1: command not found: python

exec
/bin/zsh -lc "python -m finlet.cli --help 2>&1 | grep -E '"'^'"\\s+(session|benchmark|advance|order|portfolio|status)\\b'" in /Users/justnau/finlet
 exited 1 in 0ms:
exec
/bin/zsh -lc "python -m finlet.cli --help 2>&1 | grep -E '"'^'"\\s+(serve|mcp|auth|register|plugins|manual)\\b'" in /Users/justnau/finlet
 exited 1 in 0ms:
exec
/bin/zsh -lc 'python -m finlet.cli mcp serve --help' in /Users/justnau/finlet
 exited 127 in 0ms:
zsh:1: command not found: python

codex
The validation commands as written use `python`, but this shell has no `python` binary. I’m switching to the repo’s available interpreter path rather than treating that as a product failure.
exec
/bin/zsh -lc 'command -v python3' in /Users/justnau/finlet
 succeeded in 0ms:
/opt/homebrew/bin/python3

exec
/bin/zsh -lc "sed -n '1,220p' pyproject.toml" in /Users/justnau/finlet
 succeeded in 0ms:
[project]
name = "finlet"
version = "1.1.0"
description = "A historical market simulation environment for testing AI trading agent reasoning against real market data."
readme = "README.md"
license = "LicenseRef-Proprietary"
requires-python = ">=3.12"
authors = [
    { name = "Finlet Contributors" },
]
keywords = ["trading", "ai", "simulation", "backtesting", "mcp", "llm", "agent"]
classifiers = [
    "Development Status :: 4 - Beta",
    "Framework :: FastAPI",
    "Intended Audience :: Developers",
    "License :: Other/Proprietary License",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "Topic :: Office/Business :: Financial :: Investment",
]

dependencies = [
    "typer>=0.12",
    "httpx>=0.27",
    "mcp>=1.27.0",
    "rich>=13.0",
]

[project.urls]
Homepage = "https://finlet.dev"
Repository = "https://github.com/justnau1020/finlet"
Documentation = "https://finlet.dev/agent-guide.html"
Issues = "https://github.com/justnau1020/finlet/issues"

[project.optional-dependencies]
server = [
    "fastapi>=0.115",
    "uvicorn[standard]>=0.30",
    "aiosqlite>=0.20",
    "sqlmodel>=0.0.22",
    "greenlet>=3.0",
    "mcp[auth]>=1.27.0",
    "joserfc>=1.0",
    "edgartools>=3.0",
    "fredapi>=0.5",
    "finnhub-python>=2.4",
    "pydantic[email]>=2.9",
    "alembic>=1.14",
    "structlog>=24.1",
    "markdown>=3.6",
    "stripe>=8.0",
    "pyarrow>=15.0",
    "boto3>=1.34",
    "pyotp>=2.9",
    "qrcode[pil]>=7.4",
    "cryptography>=46.0.6",
    "argon2-cffi>=23.1.0",
    "sentry-sdk[fastapi]>=2.0.0",
]
ingest = [
    "yfinance>=0.2.36",
    "curl-cffi>=0.15.0",  # pin: CVE-2026-33752 in <0.15 (transitive via yfinance)
    "pandas>=2.0",
    "pyarrow>=15.0",
    "boto3>=1.34",
    "structlog>=24.1",
    "httpx>=0.27",
    "beautifulsoup4>=4.12",
    "tenacity>=8.2",
    # SEC EDGAR + FRED + Databento — used by scripts/ingest_edgar.py,
    # scripts/ingest_fred.py, scripts/ingest_prices.py respectively.
    # Previously only listed in [server] but they are pure ingest deps
    # that the ingest cron workflows must install without pulling the
    # full server runtime. See .github/workflows/ingest-{prices,daily}.yml.
    "edgartools>=3.0",
    "fredapi>=0.5",
    "databento>=0.50",
]
sms = [
    "boto3>=1.34",
]
dev = [
    "pytest>=8.3",
    "pytest-asyncio>=0.25",
    "pytest-xdist>=3.5",
    "httpx>=0.27",
    "ruff>=0.8",
    "mypy>=1.13",
    "types-Markdown>=3.6",
    "mypy-boto3-s3>=1.34",
    "pip-audit>=2.7",
    "pytest-cov>=6.0",
    "bandit>=1.7",
    "hypothesis>=6.100",
]

[project.scripts]
finlet = "finlet.cli:app"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

# Hatchling auto-includes Python source under ``finlet/`` in the wheel,
# but Markdown topic files inside ``finlet/manual/`` are NOT Python source
# and would be excluded by default.  The targeted directive below ships
# every ``finlet/manual/*.md`` alongside the package so
# ``importlib.resources.files("finlet.manual").read_text(...)`` works from
# an installed wheel.  See ``finlet/manual/registry.py`` for the loader.
[tool.hatch.build.targets.wheel]
artifacts = ["finlet/manual/*.md"]


# ── Ruff ─────────────────────────────────────────────────────
[tool.ruff]
target-version = "py312"
line-length = 120
exclude = [".claude/skills/"]

[tool.ruff.lint]
select = ["E", "F", "I", "UP", "B", "SIM"]
ignore = [
    "E501",    # line too long — handled by formatter
    "B008",    # do not perform function call in argument defaults (FastAPI Depends)
    "B904",    # raise-without-from-inside-except — too noisy for error wrappers
    "SIM108",  # use ternary operator — reduces readability in complex cases
    "UP007",   # use X | Y for union — already used where appropriate
    "UP017",   # datetime.UTC alias — timezone.utc is clearer and more widely used
    "UP042",   # StrEnum — str+Enum pattern is deliberate for Pydantic compatibility
]

[tool.ruff.lint.isort]
known-first-party = ["finlet"]

# ── Mypy ─────────────────────────────────────────────────────
# Note: mypy's cache_dir defaults to ".mypy_cache" in the current working
# directory. The CI pipelines (.github/workflows/{ci,deploy}.yml) cache
# this path explicitly via actions/cache@v4 to skip ~15s of repeat type
# checking. Don't override cache_dir here or the cache key will go stale.
[tool.mypy]
python_version = "3.12"
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = false
check_untyped_defs = true

[[tool.mypy.overrides]]
module = [
    "finnhub.*",
    "edgar.*",
    "fredapi.*",
    "pyarrow.*",
    "mcp.*",
    "uvicorn.*",
    "aiosqlite.*",
    "sqlmodel.*",
    "sqlalchemy.*",
    "boto3.*",
    "botocore.*",
    "structlog.*",
    "alembic.*",
    "stripe.*",
    "pyotp.*",
    "qrcode.*",
    "yfinance.*",
    "pandas",
    "pandas.*",
    "cryptography.*",
    "argon2.*",
    "yfinance.*",
]
ignore_missing_imports = true
follow_untyped_imports = true

# ── Pytest ───────────────────────────────────────────────────
[tool.pytest.ini_options]
asyncio_mode = "auto"
# pytest-xdist parallelization is OFF by default (single-threaded local
# runs). CI workflows pass `-n auto --dist=loadfile` explicitly via
# pytest CLI flags — see `.github/workflows/ci.yml` and
# `.github/workflows/deploy.yml`.
#
# Why gated, not pyproject-default:
#   The session-scoped `live_server` fixture in
#   `tests/integration/conftest.py` boots uvicorn under a 30s deadline.
#   The fixture is already flaky on data-heavy dev machines (see the
#   2026-05-10 entry in `docs/KNOWN_FAILURES.md` — "local-environment
#   data-volume flake"); under xdist parallelism on the same machine,
#   CPU contention pushes more workers past the deadline more often.
#   CI runners are clean and the data-volume issue does not apply, so
#   xdist runs cleanly in CI but is opt-in locally.
#
# Local fast runs (when you know the data-volume flake is not your
# enemy): `pytest -n auto --dist=loadfile` from the repo root.
#
# `--dist=loadfile` is REQUIRED whenever `-n auto` is used:
#   • Keeps tests in the same file on the same worker so the
#     session-scoped `live_server` is booted once per file, not once
#     per worker.
#   • `tests/integration/conftest.py::pytest_collection_modifyitems`
#     pins integration tests to run LAST (to avoid structlog cache
#     pollution bleeding into capture_logs tests). Per-worker
#     collection ordering is preserved under loadfile distribution.
addopts = ""

# ── Bandit ───────────────────────────────────────────────────
[tool.bandit]
exclude_dirs = ["tests"]
skips = ["B101", "B104", "B105", "B112", "B311"]

[dependency-groups]
dev = [
    "complexipy>=5.2.0",
    "deptry>=0.25.1",
    "pre-commit>=4.5.1",
    "pytest-timeout>=2.3",
    "ty>=0.0.25",
]

exec
/bin/zsh -lc 'command -v uv || true' in /Users/justnau/finlet
 succeeded in 0ms:
/opt/homebrew/bin/uv

exec
/bin/zsh -lc "rg --files -g 'pyproject.toml' -g 'uv.lock' -g 'poetry.lock' -g 'requirements*.txt' -g 'Makefile'" in /Users/justnau/finlet
 succeeded in 0ms:
uv.lock
pyproject.toml
strategies/ai_quantamental/pyproject.toml

exec
/bin/zsh -lc 'uv run python -c "import finlet.cli; from finlet.cli import app"' in /Users/justnau/finlet
 succeeded in 0ms:
exec
/bin/zsh -lc "uv run python -m finlet.cli --help 2>&1 | grep -E '"'^'"\\s+(session|benchmark|advance|order|portfolio|status)\\b'" in /Users/justnau/finlet
 exited 1 in 0ms:
exec
/bin/zsh -lc "uv run python -m finlet.cli --help 2>&1 | grep -E '"'^'"\\s+(serve|mcp|auth|register|plugins|manual)\\b'" in /Users/justnau/finlet
 exited 1 in 0ms:
exec
/bin/zsh -lc 'uv run python -m finlet.cli mcp serve --help' in /Users/justnau/finlet
 succeeded in 0ms:
exec
/bin/zsh -lc "rg -n \"from finlet\\.cli_mcp_client|_dispatch_mcp_tool|_resolve_bearer_token|_AsyncioTimeoutError|_AUTH_REQUIRED_MARKERS|_AUTH_REQUIRED_HINT|_emit_envelope|_translate_mcp_error\" finlet tests" in /Users/justnau/finlet
 succeeded in 0ms:
tests/test_cli.py:29:from finlet.cli_mcp_client import MCPDispatchError
tests/test_cli.py:536:        site in `_dispatch_mcp_tool` converts the timeout into:
tests/test_cli.py:1744:# ─── _translate_mcp_error helper ────────────────────────────────────
tests/test_cli.py:1751:        from finlet.cli import _translate_mcp_error
tests/test_cli.py:1753:        assert _translate_mcp_error({"error": "boom"}) == "boom"
tests/test_cli.py:1756:        from finlet.cli import _translate_mcp_error
tests/test_cli.py:1758:        assert _translate_mcp_error({"id": "sid", "name": "Alpha"}) is None
tests/test_cli.py:1761:        from finlet.cli import _translate_mcp_error
tests/test_cli.py:1764:        assert _translate_mcp_error(envelope) == "human-readable"
tests/test_cli.py:1767:        from finlet.cli import _translate_mcp_error
tests/test_cli.py:1771:        result = _translate_mcp_error(envelope)
tests/test_cli.py:1776:# ─── _resolve_bearer_token helper ───────────────────────────────────
tests/test_cli.py:1783:        from finlet.cli import _resolve_bearer_token
tests/test_cli.py:1785:        assert _resolve_bearer_token("fk_explicit") == "fk_explicit"
tests/test_cli.py:1788:        from finlet.cli import _resolve_bearer_token
tests/test_cli.py:1793:        assert _resolve_bearer_token(None) is None
tests/test_cli.py:1801:        from finlet.cli import _resolve_bearer_token
tests/test_cli.py:1809:        # branch in ``_resolve_bearer_token`` does not fire — this test
tests/test_cli.py:1824:        assert _resolve_bearer_token(None) == "jwt-payload"
tests/test_cli.py:1828:    def test_resolve_bearer_token_not_expired_returns_existing(
tests/test_cli.py:1841:        from finlet.cli import _resolve_bearer_token
tests/test_cli.py:1865:            token = _resolve_bearer_token(None)
tests/test_cli.py:1870:    def test_resolve_bearer_token_expired_refreshes_and_writes(
tests/test_cli.py:1879:        from finlet.cli import _resolve_bearer_token
tests/test_cli.py:1917:            token = _resolve_bearer_token(None)
tests/test_cli.py:1939:    def test_resolve_bearer_token_refresh_400_returns_none(
tests/test_cli.py:1948:        from finlet.cli import _resolve_bearer_token
tests/test_cli.py:1981:            token = _resolve_bearer_token(None)
tests/test_cli.py:1988:    def test_resolve_bearer_token_refresh_network_error_falls_back(
tests/test_cli.py:1997:        from finlet.cli import _resolve_bearer_token
tests/test_cli.py:2023:            token = _resolve_bearer_token(None)
tests/test_cli.py:2039:# ─── _emit_envelope helper ──────────────────────────────────────────
tests/test_cli.py:2046:        from finlet.cli import _emit_envelope
tests/test_cli.py:2049:        result = _emit_envelope(envelope, as_json=False)
tests/test_cli.py:2057:        from finlet.cli import _emit_envelope
tests/test_cli.py:2060:        result = _emit_envelope(envelope, as_json=True)
tests/test_cli.py:2068:        from finlet.cli import _emit_envelope
tests/test_cli.py:2071:            _emit_envelope({"error": "fail"}, as_json=False)
tests/test_cli.py:2081:        from finlet.cli import _emit_envelope
tests/test_cli.py:2085:            _emit_envelope(envelope, as_json=True)
tests/api/test_cli_mcp_client.py:26:from finlet.cli_mcp_client import (
tests/api/test_cli_mcp_client.py:130:        from finlet.cli_mcp_client import call_tool_async
tests/api/test_cli_mcp_client.py:196:        from finlet.cli_mcp_client import call_tool_async
tests/api/test_cli_mcp_client.py:244:        from finlet.cli_mcp_client import call_tool_async
tests/api/test_cli_mcp_client.py:291:        from finlet.cli_mcp_client import call_tool_async
tests/api/test_cli_mcp_client.py:337:        from finlet.cli_mcp_client import call_tool_async

exec
/bin/zsh -lc "git grep -nE \"v1\\.0\\.1|MCP-over-HTTP|MCP-dispatched|dispatch contract\" main -- finlet/cli.py" in /Users/justnau/finlet
 exited 1 in 0ms:
exec
/bin/zsh -lc 'uv run ruff check finlet/cli.py' in /Users/justnau/finlet
 succeeded in 0ms:
All checks passed!

exec
/bin/zsh -lc "uv run python -m finlet.cli --help 2>&1 | sed -n '1,220p'" in /Users/justnau/finlet
 succeeded in 0ms:
exec
/bin/zsh -lc 'tail -n 80 finlet/cli.py' in /Users/justnau/finlet
 succeeded in 0ms:
    * ``finlet manual`` — print the topic index.
    * ``finlet manual quickstart`` — copy-paste setup walkthrough.
    * ``finlet manual --search bearer`` — hits across every topic.
    * ``finlet manual errors --format=json`` — structured anchors for tooling.

    The text path respects the ``PAGER`` env var (falls back to rich's
    pager).  ``--format=json`` and non-tty stdout disable the pager so
    pipelines stay unbuffered.
    """

    # Late import so ``finlet --help`` doesn't pay the registry import cost.
    from finlet.manual import (  # noqa: PLC0415
        get_topic,
        list_topics,
        topic_to_json,
    )
    from finlet.manual import search as registry_search  # noqa: PLC0415

    if format_ not in ("text", "json"):
        typer.echo(
            f"Unknown --format='{format_}'. Choose 'text' or 'json'.",
            err=True,
        )
        raise typer.Exit(code=2)

    force_plain = (format_ == "json") or (not sys.stdout.isatty())

    # ── search mode ────────────────────────────────────────
    if search is not None:
        hits = registry_search(search)
        if format_ == "json":
            typer.echo(json.dumps({"query": search, "hits": [{"topic": n, "snippet": s} for n, s in hits]}, indent=2))
            return
        if not hits:
            typer.echo(f"No hits for '{search}'.")
            return
        for name, snippet in hits:
            typer.echo(f"  {name}: {snippet}")
        return

    # ── list / index mode ──────────────────────────────────
    if list_ or topic is None:
        topics = list_topics()
        if format_ == "json":
            typer.echo(json.dumps({"topics": [{"name": n, "summary": s} for n, s in topics]}, indent=2))
            return
        typer.echo("Finlet user manual — available topics:")
        typer.echo("")
        for name, summary in topics:
            typer.echo(f"  {name:<20} {summary}")
        typer.echo("")
        typer.echo("Render one with `finlet manual <topic>`; add --format=json for tooling.")
        return

    # ── topic render ───────────────────────────────────────
    try:
        if format_ == "json":
            payload = topic_to_json(topic)
            typer.echo(json.dumps(payload, indent=2))
            return
        body = get_topic(topic)
    except KeyError:
        typer.echo(
            f"Topic '{topic}' not found. Run `finlet manual --list` to see available topics.",
            err=True,
        )
        raise typer.Exit(code=2) from None

    # Pager-aware text render — only when stdout is a tty.
    if force_plain:
        typer.echo(body)
        return
    try:
        from rich.console import Console  # noqa: PLC0415

        console = Console()
        with console.pager(styles=False):
            console.print(body)
    except ImportError:
        typer.echo(body)

exec
/bin/zsh -lc "uv run finlet --help 2>&1 | sed -n '1,240p'" in /Users/justnau/finlet
 succeeded in 0ms:
                                                                                
 Usage: finlet [OPTIONS] COMMAND [ARGS]...                                      
                                                                                
 Finlet — Integrated Testing Environment for AI Trading Agent Reasoning         
                                                                                
╭─ Options ────────────────────────────────────────────────────────────────────╮
│ --version                     Print the installed Finlet version and exit.   │
│ --install-completion          Install completion for the current shell.      │
│ --show-completion             Show completion for the current shell, to copy │
│                               it or customize the installation.              │
│ --help                        Show this message and exit.                    │
╰──────────────────────────────────────────────────────────────────────────────╯
╭─ Commands ───────────────────────────────────────────────────────────────────╮
│ serve     Start the API server and serve the dashboard.                      │
│ register  Register a new account and receive an API key.                     │
│ manual    Print Finlet user-manual topics.                                   │
│ plugins   Plugin management. See: finlet manual plugin-matrix                │
│ auth      Authentication commands. See: finlet manual auth-model             │
│ mcp       MCP server commands                                                │
╰──────────────────────────────────────────────────────────────────────────────╯


exec
/bin/zsh -lc "uv run finlet --help 2>&1 | grep -E '"'^'"\\s+(session|benchmark|advance|order|portfolio|status)\\b'" in /Users/justnau/finlet
 exited 1 in 0ms:
exec
/bin/zsh -lc "uv run finlet --help 2>&1 | grep -E '"'^'"\\s+(serve|mcp|auth|register|plugins|manual)\\b'" in /Users/justnau/finlet
 exited 1 in 0ms:
exec
/bin/zsh -lc 'git show --format=fuller --no-patch cfadd81' in /Users/justnau/finlet
 succeeded in 0ms:
commit cfadd81ee2c792b73eb6f1a900fb3840b9749d9c
Author:     Justin Nam <justnau@Justins-MacBook-Air-2.local>
AuthorDate: Fri May 22 22:04:53 2026 -0500
Commit:     Justin Nam <justnau@Justins-MacBook-Air-2.local>
CommitDate: Fri May 22 22:04:53 2026 -0500

    [Team A v2.0.0]: delete CLI convenience commands + dead helpers; rewrite module docstring
    
    Removes the v1.0.1 CLI MCP-over-HTTP dispatch surface and its
    convenience commands. Agents now address the cloud /mcp endpoint
    directly through their own MCP client.
    
    Surface AFTER v2.0.0:
    - finlet serve / register / auth (login/logout/status) /
      plugins (list/add/remove) / mcp serve / manual
    
    Removed:
    - session sub-app (create/list/delete/publish)
    - benchmark sub-app (start/progress/decrypt/visibility)
    - top-level advance / order / portfolio / status
    - finlet/cli_mcp_client.py (entire file)
    - _dispatch_mcp_tool / _translate_mcp_error / _emit_envelope /
      _resolve_bearer_token / _AUTH_REQUIRED_MARKERS / _AUTH_REQUIRED_HINT /
      _AsyncioTimeoutError alias / top-level 'import asyncio' /
      _normalize_start_iso
    - session_app + benchmark_app Typer sub-apps + their add_typer calls
    - 'from finlet.cli_mcp_client import ...' import
    - stale module docstring describing the deleted dispatch model
    - stale inline reference at the OAuth login path to _resolve_bearer_token
    
    Kept:
    - EXIT_AUTH_REQUIRED (now used by plugins_add, plugins_remove,
      auth_status x 2 — 6 hits total including def + docstring)

exec
/bin/zsh -lc 'git log --graph --decorate --oneline --parents -5 main' in /Users/justnau/finlet
exec
/bin/zsh -lc 'git show --format=fuller --name-status --stat cfadd81' in /Users/justnau/finlet
 succeeded in 0ms:
*   59c85bb 7144dc2 cfadd81 (HEAD -> main) Merge: [Team A v2.0.0] CLI surgery — delete dropped commands + dead helpers + rewrite module docstring
|\  
| * cfadd81 7144dc2 (worktree-agent-a055449a65a2df2af) [Team A v2.0.0]: delete CLI convenience commands + dead helpers; rewrite module docstring
|/  
* 7144dc2 fb2637c exec-plan: pre-flight for v2 pure-MCP — update KNOWN_FAILURES
* fb2637c 27d96ca (origin/main, origin/HEAD) exec-plan: codex retest follow-up — CLI blind-mode fallback partial-fix defect (cli.py:624)
* 27d96ca 3d9f50e docs: post-ship updates for session-level blind (ARCHITECTURE + REMAINING_TASKS + decisions + KNOWN_FAILURES)

 succeeded in 0ms:
commit cfadd81ee2c792b73eb6f1a900fb3840b9749d9c
Author:     Justin Nam <justnau@Justins-MacBook-Air-2.local>
AuthorDate: Fri May 22 22:04:53 2026 -0500
Commit:     Justin Nam <justnau@Justins-MacBook-Air-2.local>
CommitDate: Fri May 22 22:04:53 2026 -0500

    [Team A v2.0.0]: delete CLI convenience commands + dead helpers; rewrite module docstring
    
    Removes the v1.0.1 CLI MCP-over-HTTP dispatch surface and its
    convenience commands. Agents now address the cloud /mcp endpoint
    directly through their own MCP client.
    
    Surface AFTER v2.0.0:
    - finlet serve / register / auth (login/logout/status) /
      plugins (list/add/remove) / mcp serve / manual
    
    Removed:
    - session sub-app (create/list/delete/publish)
    - benchmark sub-app (start/progress/decrypt/visibility)
    - top-level advance / order / portfolio / status
    - finlet/cli_mcp_client.py (entire file)
    - _dispatch_mcp_tool / _translate_mcp_error / _emit_envelope /
      _resolve_bearer_token / _AUTH_REQUIRED_MARKERS / _AUTH_REQUIRED_HINT /
      _AsyncioTimeoutError alias / top-level 'import asyncio' /
      _normalize_start_iso
    - session_app + benchmark_app Typer sub-apps + their add_typer calls
    - 'from finlet.cli_mcp_client import ...' import
    - stale module docstring describing the deleted dispatch model
    - stale inline reference at the OAuth login path to _resolve_bearer_token
    
    Kept:
    - EXIT_AUTH_REQUIRED (now used by plugins_add, plugins_remove,
      auth_status x 2 — 6 hits total including def + docstring)

M	finlet/cli.py
D	finlet/cli_mcp_client.py

exec
/bin/zsh -lc 'git cat-file -p 59c85bbe88602dc8b9fd3dd30627b467326ff1e7' in /Users/justnau/finlet
 succeeded in 0ms:
tree 1e6ed9882dfe0466cefd3a060d416fb2f34cc6fa
parent 7144dc27a81770dc9ef0cdbde720080868821beb
parent cfadd81ee2c792b73eb6f1a900fb3840b9749d9c
author Justin Nam <justnau@Justins-MacBook-Air-2.local> 1779505605 -0500
committer Justin Nam <justnau@Justins-MacBook-Air-2.local> 1779505605 -0500

Merge: [Team A v2.0.0] CLI surgery — delete dropped commands + dead helpers + rewrite module docstring

exec
/bin/zsh -lc "git diff main~1..main --unified=0 | rg '"'^'"\\+' | rg -n '[0-9a-fA-F]{8,}|fnlt_|fk_|sk_|token|secret|password|api_key|refresh_token|access_token'" in /Users/justnau/finlet
 succeeded in 0ms:
31:+        # dispatch path, so token refresh is now an MCP-client concern;

exec
/bin/zsh -lc "git diff main~1..main --unified=0 | rg '"'^'"\\+' | sed -n '1,220p'" in /Users/justnau/finlet
 succeeded in 0ms:
+++ b/finlet/cli.py
+"""CLI entrypoint — finlet serve / register / auth / plugins / mcp / manual.
+v2.0.0 (Pure-MCP) ships a deliberately minimal CLI: the only commands
+are the ones that ARE NOT MCP tool calls. Every agentic-trading
+operation (session / clock / order / portfolio / benchmark / status)
+runs over MCP — agents talk to the cloud ``/mcp`` endpoint directly
+via their own MCP client. The CLI no longer hosts a dispatch surface
+for those operations.
+Six command families remain (the v2.0.0 surface):
+* ``finlet plugins list`` / ``finlet plugins add`` / ``finlet plugins remove``
+  — tenant plugin-credential management against ``/v1/settings/plugins``
+  and ``/v1/plugins/health``. Finlet's MCP tool surface is the
+  agentic-trading surface and intentionally does not expose plugin
+  write paths.
+* ``finlet mcp serve`` — self-host stdio MCP server for niche
+  integrations (e.g., Claude Code stdio bridge).
+* ``finlet manual`` — local user-manual topics shipped with the wheel.
+
+The pre-v2.0.0 ``session`` / ``benchmark`` / ``advance`` / ``order`` /
+``portfolio`` / ``status`` subcommands are gone; agents address the
+cloud ``/mcp`` endpoint directly.
+# REMOVED in v2.0.0: session sub-app + benchmark sub-app.
+# Agents call the MCP tools (create_session / list_sessions /
+# delete_session / set_session_visibility / start_benchmark /
+# get_benchmark_progress / decrypt_benchmark_run /
+# set_benchmark_visibility) directly through their MCP client.
+# See `finlet manual quickstart`.
+        raise typer.Exit(EXIT_AUTH_REQUIRED)
+        raise typer.Exit(EXIT_AUTH_REQUIRED)
+        # :func:`_write_credentials`. v2.0.0 dropped the CLI's MCP
+        # dispatch path, so token refresh is now an MCP-client concern;
+        # this helper persists the initial pair issued by the AS.
+    (F-3 hotfix); the same exit code is shared by
+    :func:`plugins_add` / :func:`plugins_remove` when ``FINLET_API_KEY``
+    is missing.
+    surfaced when an authenticated MCP / REST call is made.
+# REMOVED in v2.0.0: top-level advance / order / portfolio / status.
+# Agents call the MCP tools (advance_time / submit_order / get_portfolio /
+# get_session) directly through their MCP client. See
+# `finlet manual quickstart`.
+        typer.echo("Point your MCP client at https://finlet.dev/mcp instead.", err=True)
+        typer.echo("Point your MCP client at https://finlet.dev/mcp instead.", err=True)
+++ /dev/null

exec
/bin/zsh -lc "git diff main~1..main -- finlet/cli.py | rg -n '"'^[-+]'"\\s*#|"'^[-+]'"\\s*\"\"\"|"'^[-+]'"\\s*def |"'^[-+]'"\\s*class |"'^[-+]'"\\s*raise typer.Exit|"'^[-+]'"\\s*typer.echo'" in /Users/justnau/finlet
 succeeded in 0ms:
6:-"""CLI entrypoint — finlet serve / session / plugins / mcp.
7:+"""CLI entrypoint — finlet serve / register / auth / plugins / mcp / manual.
71:-#: Substrings that signal an auth-failure tool envelope from the MCP
72:-#: server.  The cloud server emits the second form post-Phase 4e
73:-#: (api_key Bearer no longer accepted on MCP HTTP); the first is the
74:-#: pre-Phase-4 / stdio-bridge form.  Either ⇒ exit 2 with a friendly hint.
84:-# Alias asyncio.TimeoutError for the dispatch try/except so the catch site
85:-# is explicit. On Python 3.11+ this is the same class as the builtin
86:-# TimeoutError, but the cli_mcp_client docs raise it via asyncio.wait_for —
87:-# we catch both names defensively.
97:-def _resolve_bearer_token(api_key: str | None) -> str | None:
98:-    """Resolve the Bearer token (OAuth JWT or legacy api-key) for MCP dispatch.
139:-    """
150:-    # 30-second safety margin: refresh before the AS would reject the
151:-    # JWT. Absorbs client/server clock skew plus the round-trip latency
152:-    # of any in-flight MCP-over-HTTP request that will use this token.
158:-    # Token is expired (or within the 30s safety window); attempt
159:-    # refresh via RFC 6749 §6 refresh_token grant.
162:-        typer.echo(
179:-        typer.echo(
187:-    # 4xx ⇒ refresh-token rejected by the AS (revoked, expired, reused,
188:-    # client mismatch, invalid_grant — see ``_handle_refresh_token``).
189:-    # The stored credentials are no longer recoverable; the user must
190:-    # re-authorize.
192:-        typer.echo(
198:-    # 5xx ⇒ transient AS failure; fall back to the stored token so the
199:-    # caller's request still goes out. They may see a 401 if the JWT is
200:-    # already past expiry — which surfaces the same hint anyway.
202:-        typer.echo(
213:-        typer.echo(
225:-        typer.echo(
243:-def _translate_mcp_error(envelope: dict[str, Any]) -> str | None:
244:-    """Convert an MCP tool error envelope to a human-readable message.
253:-    """
266:-def _dispatch_mcp_tool(
273:-    """Dispatch a tool call through the cloud ``/mcp`` HTTP endpoint.
290:-    """
300:-        typer.echo(f"Error: MCP dispatch failed — {exc}", err=True)
301:-        raise typer.Exit(1) from exc
303:-        # asyncio.wait_for in cli_mcp_client raises asyncio.TimeoutError
304:-        # (which Python 3.11+ aliases to the builtin TimeoutError). Catch
305:-        # both forms so a session-create or any other tool that exceeds
306:-        # the timeout produces a one-line friendly message instead of a
307:-        # 60-line traceback (BLOCKER #5 — agent-guide first-command UX).
308:-        typer.echo(
313:-        raise typer.Exit(1) from exc
316:-def _emit_envelope(envelope: dict[str, Any], *, as_json: bool, on_error_exit: int = 1) -> dict[str, Any]:
317:-    """Print the tool envelope in JSON or human form, exiting on error.
331:-    """
336:-            typer.echo(json.dumps(envelope))
338:-            typer.echo(f"Error: {err_message}", err=True)
340:-                typer.echo(_AUTH_REQUIRED_HINT, err=True)
342:-        raise typer.Exit(exit_code)
344:-        typer.echo(json.dumps(envelope))
376:-# ── session ──────────────────────────────────────────────────
379:-def _normalize_start_iso(start: str) -> str:
380:-    """Normalize the CLI's --start flag into the MCP tool's ISO 8601 input.
386:-    """
391:-def session_create(
406:-    """Create a new simulation session via the MCP ``create_session`` tool."""
421:-    typer.echo(f"Session created: {data['id']} ({data['name']})")
423:-    typer.echo(f"  Start: {config.get('start_time', 'unknown')}")
424:-    typer.echo(f"  Capital: ${float(config.get('initial_capital', 0)):,.2f}")
425:-    # Codex Team D P1 (blind leak): print the response's universe, NOT the local
426:-    # --universe input. For blind sessions, the response carries opaque T_NNNN
427:-    # tickers; echoing the local list here leaked the real symbols even though
428:-    # the rest of the blind contract held. Falling back to the local list only
429:-    # if the response omits a universe keeps the non-blind UX identical.
432:-        typer.echo(f"  Universe: {', '.join(universe_to_show)}")
436:-def session_list(
442:-    """List all sessions via the MCP ``list_sessions`` tool."""
450:-        typer.echo("No active sessions.")
454:-        typer.echo(f"  {s['id']}  {s.get('name', s['id'])}  [{s['status']}]  {clock_time}")
458:-def session_delete(
465:-    """Delete a session via the MCP ``delete_session`` tool."""
472:-    typer.echo(f"Session deleted: {session_id}")
476:-def session_publish(
493:-    """Toggle a session's public-share visibility via the MCP ``set_session_visibility`` tool.
497:-    """
509:-        typer.echo(f"Published → https://finlet.dev/sessions/{session_id}")
511:-        typer.echo(f"Unpublished → {session_id}")
514:-# ── benchmark ────────────────────────────────────────────────
518:-def benchmark_start(
544:-    """Start a standardized benchmark run via the MCP ``start_benchmark`` tool.
552:-    """
572:-    typer.echo(f"Benchmark started: run={run_id} session={session_id} scenario={scenario_label}")
576:-def benchmark_progress(
582:-    """Show the active benchmark run's progress via the MCP ``get_benchmark_progress`` tool.
586:-    """
597:-    typer.echo(f"Benchmark progress: run={run_id} session={session_id} scenario={current}/{total}")
601:-def benchmark_decrypt(
608:-    """Unlock a completed benchmark run's blind mapping via the MCP
615:-    """
622:-    typer.echo(f"Decrypted → run={benchmark_run_id} decrypted_at={decrypted_at}")
626:-def benchmark_visibility(
646:-    """Toggle a benchmark run's public-share visibility via the MCP
653:-    """
665:-        typer.echo(
669:-        typer.echo(f"Unpublished → {benchmark_run_id}")
670:+# REMOVED in v2.0.0: session sub-app + benchmark sub-app.
671:+# Agents call the MCP tools (create_session / list_sessions /
672:+# delete_session / set_session_visibility / start_benchmark /
673:+# get_benchmark_progress / decrypt_benchmark_run /
674:+# set_benchmark_visibility) directly through their MCP client.
675:+# See `finlet manual quickstart`.
683:-        raise typer.Exit(2)
684:+        raise typer.Exit(EXIT_AUTH_REQUIRED)
692:-        raise typer.Exit(2)
693:+        raise typer.Exit(EXIT_AUTH_REQUIRED)
701:-        # :func:`_write_credentials`, which is also reused by the
702:-        # auto-refresh path in :func:`_resolve_bearer_token` to rotate
703:-        # tokens in place when the AS issues a new pair.
704:+        # :func:`_write_credentials`. v2.0.0 dropped the CLI's MCP
705:+        # dispatch path, so token refresh is now an MCP-client concern;
706:+        # this helper persists the initial pair issued by the AS.
733:-# ── advance ─────────────────────────────────────────────────
737:-def advance(
755:-    """Advance the simulation clock via the MCP ``advance_time`` tool.
768:-    """
770:-        typer.echo("Error: --days and --to are mutually exclusive.", err=True)
771:-        raise typer.Exit(2)
774:-        typer.echo("Error: --days must be a positive integer.", err=True)
775:-        raise typer.Exit(2)
778:-        # Validate the format client-side so the user sees an immediate
779:-        # error rather than a tool-layer envelope. The tool itself does
780:-        # the same check; mirroring it here avoids the subprocess-spawn
781:-        # tax on a guaranteed-bad input.
787:-            typer.echo(
791:-            raise typer.Exit(2)
804:-    typer.echo("Clock advanced:")
805:-    typer.echo(f"  Current time: {data.get('current_time', 'unknown')}")
806:-    typer.echo(f"  Mode: {data.get('mode', 'unknown')}")
809:-        typer.echo(
815:-# ── order ───────────────────────────────────────────────────
819:-def order(
834:-    """Submit a trade order via the MCP ``submit_order`` tool.
848:-    """
849:-    # Client-side price validation per --type (H12). Catches the most common
850:-    # operator footgun (LIMIT/STOP without a price) BEFORE any network call,
851:-    # so the user sees an actionable client error instead of a tool-envelope
852:-    # round-trip plus a subprocess-spawn tax.
888:-    # NOTE: ``time_in_force`` is not exposed by the MCP ``submit_order`` tool;
889:-    # the service-layer defaults to GTC. The CLI flag is preserved for
890:-    # ergonomic stability but is currently a no-op on the MCP dispatch path.
898:-    typer.echo("Order submitted:")
899:-    typer.echo(f"  ID: {data.get('id', 'unknown')}")
900:-    typer.echo(f"  Status: {data.get('status', 'unknown')}")
903:-        typer.echo(f"  Fill price: ${fill_price:,.2f}")
906:-# ── portfolio ───────────────────────────────────────────────
910:-def portfolio(
917:-    """Show portfolio positions, cash, and P&L via the MCP ``get_portfolio`` tool.
930:-    """
944:-    # Try rich table, fall back to plain text
981:-        # Plain text fallback
982:-        typer.echo("Portfolio:")
984:-            typer.echo(f"  {'Ticker':<8} {'Qty':>8} {'Avg Entry':>10} {'Price':>10} {'Value':>12} {'P&L':>12}")
985:-            typer.echo(f"  {'-' * 8} {'-' * 8} {'-' * 10} {'-' * 10} {'-' * 12} {'-' * 12}")
987:-                typer.echo(
996:-            typer.echo("  No positions.")
997:-        typer.echo(f"  Cash: ${cash:,.2f}")
998:-        typer.echo(f"  Total value: ${total_value:,.2f}")
999:-        typer.echo(f"  Unrealized P&L: ${unrealized_pnl:,.2f}")
1002:-# ── status ──────────────────────────────────────────────────
1006:-def status(
1013:-    """Show session status via the MCP ``get_session`` tool.
1024:-    """
1032:-    typer.echo(f"Session: {data.get('name', data.get('id', 'unknown'))}")
1033:-    typer.echo(f"  ID: {data.get('id', 'unknown')}")
1034:-    typer.echo(f"  Status: {data.get('status', 'unknown')}")
1036:-    typer.echo(f"  Sim time: {clock.get('current_time', 'unknown')}")
1037:-    typer.echo(f"  Mode: {clock.get('mode', 'unknown')}")
1041:-        typer.echo(f"  Universe: {', '.join(universe)}")
1042:-    typer.echo(f"  Capital: ${config.get('initial_capital', 0):,.2f}")
1043:+# REMOVED in v2.0.0: top-level advance / order / portfolio / status.
1044:+# Agents call the MCP tools (advance_time / submit_order / get_portfolio /
1045:+# get_session) directly through their MCP client. See
1046:+# `finlet manual quickstart`.
1054:-        typer.echo("Use MCP-over-HTTP with finlet.dev instead.", err=True)
1055:+        typer.echo("Point your MCP client at https://finlet.dev/mcp instead.", err=True)
1063:-        typer.echo("Use MCP-over-HTTP with finlet.dev instead.", err=True)
1064:+        typer.echo("Point your MCP client at https://finlet.dev/mcp instead.", err=True)

exec
/bin/zsh -lc 'git diff main~1..main --check' in /Users/justnau/finlet
 succeeded in 0ms:
exec
/bin/zsh -lc "nl -ba docs/brainstorms/V2_PURE_MCP_EXECUTION_PLAN.md | sed -n '290,318p'" in /Users/justnau/finlet
 succeeded in 0ms:
   290	
   291	`finlet/cli_mcp_client.py` is imported only by:
   292	
   293	```text grep -rn "from finlet.cli_mcp_client"
   294	finlet/cli.py:39:from finlet.cli_mcp_client import MCPDispatchError, call_tool_sync
   295	tests/test_cli.py:29:from finlet.cli_mcp_client import MCPDispatchError
   296	tests/api/test_cli_mcp_client.py:26:from finlet.cli_mcp_client import (...)
   297	```
   298	
   299	`cli.py:39` import dies with the dispatch helper; the test files are Team B's responsibility. Safe to delete.
   300	
   301	**Files touched:**
   302	- Modified: `finlet/cli.py`:
   303	  - **Rewrite module docstring (lines 1-30)** to describe v2.0.0 surface: serve, register, auth login/logout/status, plugins list/add/remove, mcp serve, manual. Mention `finlet/cli.py` is the typer entry point. No mention of session/order/portfolio/etc.
   304	  - Delete commands at lines 584-706 (session sub-app commands), 711-864 (benchmark sub-app commands), 1614-1691 (advance), 1696-1782 (order), 1787-1878 (portfolio), 1883-1921 (status).
   305	  - Delete dead helpers: `_dispatch_mcp_tool` (386-433), `_translate_mcp_error` (363-384), `_emit_envelope` (~436), `_AUTH_REQUIRED_MARKERS`, `_AUTH_REQUIRED_HINT`, `_resolve_bearer_token` (217), `_AsyncioTimeoutError` alias (64), top-level `import asyncio` (30), `_normalize_start_iso` (~573, verify dead).
   306	  - **DO NOT delete `EXIT_AUTH_REQUIRED` (line 45)** — alive, used by `plugins_add` (984), `plugins_remove` (1056), `auth_status` (1598+). Note that `plugins_add` and `plugins_remove` currently raise the literal `2` (`raise typer.Exit(2)`); they should ideally use `EXIT_AUTH_REQUIRED` for clarity but that's beyond v2.0.0 scope — leave as-is.
   307	  - Delete sub-typer `session_app` (516) + `benchmark_app` (520-525) + their `app.add_typer(...)` lines.
   308	  - Delete the `from finlet.cli_mcp_client import ...` import (line 39).
   309	  - Clean stale inline comment at `cli.py:1347` (referencing `_resolve_bearer_token` auto-refresh — the function won't exist after deletion). Either remove the comment or rewrite to point at `_write_credentials` directly.
   310	  - Audit `cli.py:1573` and surrounding for similar stale refs.
   311	- Deleted: `finlet/cli_mcp_client.py` (entire file).
   312	
   313	**Deliverable:** After this team finishes, `finlet --help` shows ONLY: `serve`, `mcp` (with sub-command `serve`), `auth` (with `login`/`logout`/`status`), `register`, `plugins` (with `list`/`add`/`remove`), `manual`, `--version`. No `session`, `benchmark`, `advance`, `order`, `portfolio`, or `status` commands. The DEAD set is gone; the ALIVE set (`EXIT_AUTH_REQUIRED`) remains. Module docstring describes v2.0.0 surface only.
   314	
   315	**Validation:**
   316	- [ ] `python -c "import finlet.cli; from finlet.cli import app"` succeeds (no import errors).
   317	- [ ] `python -m finlet.cli --help 2>&1 | grep -E '^\s+(session|benchmark|advance|order|portfolio|status)\b'` returns nothing.
   318	- [ ] `python -m finlet.cli --help 2>&1 | grep -E '^\s+(serve|mcp|auth|register|plugins|manual)\b'` returns all 6 expected commands.

exec
/bin/zsh -lc "nl -ba docs/brainstorms/team-prompts/team-A.md | sed -n '1,90p'" in /Users/justnau/finlet
 succeeded in 0ms:
     1	You are Team A (v2.0.0 Pure-MCP Migration).
     2	
     3	**Plan:** `/Users/justnau/finlet/docs/brainstorms/V2_PURE_MCP_EXECUTION_PLAN.md` — read your full spec (lines 208-338).
     4	
     5	**Mission:** CLI surgery — delete dropped commands + dead helpers + rewrite module docstring.
     6	
     7	**Blocked by:** none — start immediately.
     8	
     9	## Read these files first
    10	- `finlet/cli.py:1-30` (module docstring — REWRITE; describes deleted v1.0.1 dispatch model)
    11	- `finlet/cli.py:30-70` (imports — `asyncio` line 30 + `_AsyncioTimeoutError` line 64 both dead; `EXIT_AUTH_REQUIRED` line 45 is ALIVE — keep)
    12	- `finlet/cli.py:217-260` (`_resolve_bearer_token` — dead after deletion)
    13	- `finlet/cli.py:386-466` (`_dispatch_mcp_tool` + envelope plumbing — all dead)
    14	- `finlet/cli.py:491-530` (Typer app init + sub-typer registrations)
    15	- `finlet/cli.py:535-568` (`finlet serve` — KEEP)
    16	- `finlet/cli.py:881-1096` (plugins commands — KEEP; use `EXIT_AUTH_REQUIRED` at 984, 1056)
    17	- `finlet/cli.py:1340-1360` (inline comment at 1347 — references `_resolve_bearer_token`; clean it)
    18	- `finlet/cli.py:1561-1610` (`auth status` — KEEP; uses `EXIT_AUTH_REQUIRED`)
    19	- `finlet/cli.py:1565-1580` (audit for dispatch refs around 1573)
    20	- `finlet/cli.py:1927-2035` (`finlet mcp serve` — KEEP)
    21	- `finlet/cli_mcp_client.py` (DELETE entire file)
    22	
    23	## Files touched
    24	**Modified:** `finlet/cli.py`:
    25	- **Rewrite module docstring (lines 1-30)** to describe v2.0.0 surface: serve, register, auth login/logout/status, plugins list/add/remove, mcp serve, manual. NO mention of session/order/portfolio/etc.
    26	- Delete commands at lines 584-706 (session sub-app), 711-864 (benchmark sub-app), 1614-1691 (advance), 1696-1782 (order), 1787-1878 (portfolio), 1883-1921 (status).
    27	- Delete dead helpers: `_dispatch_mcp_tool` (386-433), `_translate_mcp_error` (363-384), `_emit_envelope` (~436), `_AUTH_REQUIRED_MARKERS`, `_AUTH_REQUIRED_HINT`, `_resolve_bearer_token` (217), `_AsyncioTimeoutError` alias (64), top-level `import asyncio` (30), `_normalize_start_iso` (~573 — verify dead).
    28	- **DO NOT delete `EXIT_AUTH_REQUIRED` (line 45)** — alive, used by `plugins_add` (984), `plugins_remove` (1056), `auth_status` (1598+).
    29	- Delete sub-typer `session_app` (516) + `benchmark_app` (520-525) + their `app.add_typer(...)` lines.
    30	- Delete `from finlet.cli_mcp_client import ...` import (line 39).
    31	- Clean stale inline comment at `cli.py:1347` (references `_resolve_bearer_token` auto-refresh — function won't exist). Either remove OR rewrite to point at `_write_credentials` directly. **NOTE: it's an INLINE COMMENT, not a docstring.**
    32	- Audit `cli.py:1573` and surrounding for similar stale refs.
    33	
    34	**Deleted:** `finlet/cli_mcp_client.py` (entire file — use `git rm`).
    35	
    36	## Deliverable
    37	After this team finishes, `finlet --help` shows ONLY: `serve`, `mcp` (sub-cmd `serve`), `auth` (login/logout/status), `register`, `plugins` (list/add/remove), `manual`, `--version`. NO session/benchmark/advance/order/portfolio/status commands. DEAD set gone; ALIVE set (`EXIT_AUTH_REQUIRED`) remains.
    38	
    39	## Validation
    40	```bash
    41	python -c "import finlet.cli; from finlet.cli import app"   # must succeed
    42	python -m finlet.cli --help 2>&1 | grep -E '^\s+(session|benchmark|advance|order|portfolio|status)\b'   # nothing
    43	python -m finlet.cli --help 2>&1 | grep -E '^\s+(serve|mcp|auth|register|plugins|manual)\b'   # all 6
    44	python -m finlet.cli mcp serve --help   # exit 0
    45	grep -rn "from finlet.cli_mcp_client" finlet/   # nothing
    46	grep -nE "_dispatch_mcp_tool|_resolve_bearer_token|_AsyncioTimeoutError|_AUTH_REQUIRED_MARKERS|_AUTH_REQUIRED_HINT|_emit_envelope|_translate_mcp_error" finlet/cli.py   # nothing
    47	grep -nE "^import asyncio|^from asyncio" finlet/cli.py   # nothing
    48	grep -nE "EXIT_AUTH_REQUIRED" finlet/cli.py   # definition + ≥3 consumers
    49	grep -nE "v1\.0\.1|MCP-over-HTTP|MCP-dispatched|dispatch contract" finlet/cli.py   # nothing (module docstring rewritten)
    50	ruff check finlet/cli.py   # passes
    51	git status   # cli.py modified + cli_mcp_client.py deleted
    52	```
    53	
    54	## Agent instructions
    55	- You MUST `git add finlet/cli.py` and `git rm finlet/cli_mcp_client.py` and `git commit` before finishing.
    56	- After deletion, run `ruff check finlet/` and remove any newly-unused imports.
    57	- After deletion, grep for orphan refs to deleted symbols. Clean stale docstrings/comments — including module docstring (1-30) and inline comment at 1347.
    58	- **Do NOT delete `EXIT_AUTH_REQUIRED`.** Verify with `grep -c "EXIT_AUTH_REQUIRED" finlet/cli.py` ≥4.
    59	- Do NOT modify ANY MCP tool source files (`finlet/mcp/`).
    60	- Do NOT touch `tests/` (Team B's lane).
    61	- Do NOT touch docs or `dashboard/llms.txt` (Team C's lane).
    62	- Do NOT touch `dashboard/*.html` (Team D's lane).
    63	- Commit message: `[Team A v2.0.0]: delete CLI convenience commands + dead helpers; rewrite module docstring`.
    64	
    65	## CRITICAL RULES
    66	- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
    67	- Read the "Read these files first" list BEFORE writing any code.
    68	- Follow existing patterns in those files.
    69	- You MUST `git add`/`git rm` and `git commit` all your changes before finishing.
    70	- Your commit message must start with `[Team A v2.0.0]:`.
    71	- Run the validation commands above before finishing.
    72	- If validation fails, fix and re-commit.
    73	
    74	When done, report: DONE + commit hash + validation results.
    75	OR: BLOCKED + what went wrong.

exec
/bin/zsh -lc "git diff --unified=3 main~1..main -- finlet/cli.py | sed -n '1,120p;660,720p;1038,1068p'" in /Users/justnau/finlet
 succeeded in 0ms:
diff --git a/finlet/cli.py b/finlet/cli.py
index 00d96f5..2c8a000 100644
--- a/finlet/cli.py
+++ b/finlet/cli.py
@@ -1,11 +1,13 @@
-"""CLI entrypoint — finlet serve / session / plugins / mcp.
+"""CLI entrypoint — finlet serve / register / auth / plugins / mcp / manual.
 
-v1.0.1 (CLI MCP-over-HTTP) routes session / advance / order /
-portfolio / status through the cloud ``/mcp`` HTTP endpoint via
-``mcp.client.streamable_http.streamablehttp_client``.  See
-``docs/decisions/cli-mcp-http-dispatch.md`` for the dispatch contract.
+v2.0.0 (Pure-MCP) ships a deliberately minimal CLI: the only commands
+are the ones that ARE NOT MCP tool calls. Every agentic-trading
+operation (session / clock / order / portfolio / benchmark / status)
+runs over MCP — agents talk to the cloud ``/mcp`` endpoint directly
+via their own MCP client. The CLI no longer hosts a dispatch surface
+for those operations.
 
-Four command families remain on REST (the "KEEP" set):
+Six command families remain (the v2.0.0 surface):
 
 * ``finlet serve`` — boots the API process; not a tool call.
 * ``finlet register`` — REST registration is the bootstrap before any
@@ -13,21 +15,22 @@ Four command families remain on REST (the "KEEP" set):
 * ``finlet auth login`` / ``finlet auth logout`` / ``finlet auth status``
   — OAuth + REST endpoints the MCP tool surface intentionally does not
   host; ``auth status`` is a local-only credentials check.
-
-Plugin management (``finlet plugins list/add/remove``) ALSO remains on
-REST (`/v1/settings/plugins` and `/v1/plugins/health`) because Finlet's
-MCP tool surface is the agentic-trading surface and intentionally does
-not expose tenant plugin-credential write paths.  If a future phase
-ships admin MCP tools, the plugins commands can move alongside.
-
-``finlet mcp serve`` is preserved as a self-host stdio entry point for
-niche integrations (e.g., Claude Code over stdio); the CLI itself no
-longer spawns it for tool dispatch.
+* ``finlet plugins list`` / ``finlet plugins add`` / ``finlet plugins remove``
+  — tenant plugin-credential management against ``/v1/settings/plugins``
+  and ``/v1/plugins/health``. Finlet's MCP tool surface is the
+  agentic-trading surface and intentionally does not expose plugin
+  write paths.
+* ``finlet mcp serve`` — self-host stdio MCP server for niche
+  integrations (e.g., Claude Code stdio bridge).
+* ``finlet manual`` — local user-manual topics shipped with the wheel.
+
+The pre-v2.0.0 ``session`` / ``benchmark`` / ``advance`` / ``order`` /
+``portfolio`` / ``status`` subcommands are gone; agents address the
+cloud ``/mcp`` endpoint directly.
 """
 
 from __future__ import annotations
 
-import asyncio
 import importlib.metadata as _md
 import json
 import os
@@ -36,33 +39,12 @@ from typing import Any
 
 import typer
 
-from finlet.cli_mcp_client import MCPDispatchError, call_tool_sync
-
 #: Exit code for auth-required CLI invocations.  Shell scripts can detect
 #: an auth failure with ``[ $? -eq 2 ]``.  Centralised here so all CLI
 #: auth-failure paths share a single source of truth (F-3 hotfix — see
 #: ``docs/launch/blind-agent-coldstart-report-v1.0.3-fullwalk.md``).
 EXIT_AUTH_REQUIRED = 2
 
-#: Substrings that signal an auth-failure tool envelope from the MCP
-#: server.  The cloud server emits the second form post-Phase 4e
-#: (api_key Bearer no longer accepted on MCP HTTP); the first is the
-#: pre-Phase-4 / stdio-bridge form.  Either ⇒ exit 2 with a friendly hint.
-_AUTH_REQUIRED_MARKERS = (
-    "Authentication required",
-    "api_key authentication is no longer supported",
-)
-_AUTH_REQUIRED_HINT = (
-    "Not authenticated. Run `finlet auth login` for an OAuth Bearer token, "
-    "or set `FINLET_API_KEY=fnlt_<key>` for api_key auth on REST / stdio."
-)
-
-# Alias asyncio.TimeoutError for the dispatch try/except so the catch site
-# is explicit. On Python 3.11+ this is the same class as the builtin
-# TimeoutError, but the cli_mcp_client docs raise it via asyncio.wait_for —
-# we catch both names defensively.
-_AsyncioTimeoutError = asyncio.TimeoutError
-
 _API_URL = os.environ.get("FINLET_API_URL", "https://finlet.dev")
 
 #: Canonical Finlet OAuth Authorization Server issuer (decision record §5).
@@ -214,257 +196,6 @@ def _print_error(e: Exception) -> None:
         typer.echo(f"Error: {e}", err=True)
 
 
-def _resolve_bearer_token(api_key: str | None) -> str | None:
-    """Resolve the Bearer token (OAuth JWT or legacy api-key) for MCP dispatch.
-
-    Mirrors :func:`_api_headers`'s precedence but returns the raw token
-    string instead of a header dict, so the CLI's MCP-over-HTTP dispatch
-    path can forward it via the ``Authorization`` request header on the
-    cloud ``/mcp`` endpoint.
-
-    Precedence (highest first):
-
-    1. ``api_key`` explicit flag (or ``FINLET_API_KEY`` env, surfaced
-       through Typer's envvar wiring) — used as a Bearer token. The
-       cloud ``/mcp`` endpoint accepts BOTH OAuth JWTs and legacy
-       ``fnlt_*`` api-keys in the ``Authorization`` header post-v1.0.1
-       (see ``docs/decisions/cli-mcp-http-dispatch.md`` and the
-       retraction appendix on ``docs/decisions/mcp-api-key-sunset.md``).
-    2. OAuth credentials at ``~/.finlet/credentials`` — populated by
-       ``finlet auth login``. The access token is a 15-minute
-       (``ACCESS_TOKEN_TTL = timedelta(seconds=900)`` —
-       ``finlet/auth/oauth/token.py``) EdDSA JWT, so this helper
-       auto-refreshes through the AS's ``/oauth/token``
-       ``grant_type=refresh_token`` endpoint when the stored access
-       token is within 30 seconds of expiry. A successful refresh
-       rotates the stored credentials atomically via
-    envelope = _dispatch_mcp_tool("set_benchmark_visibility", args, api_key=api_key)
-    _emit_envelope(envelope, as_json=as_json)
-    if as_json:
-        return
-    if make_public:
-        typer.echo(
-            f"Published → https://finlet.dev/benchmark-runs/{benchmark_run_id}"
-        )
-    else:
-        typer.echo(f"Unpublished → {benchmark_run_id}")
+# REMOVED in v2.0.0: session sub-app + benchmark sub-app.
+# Agents call the MCP tools (create_session / list_sessions /
+# delete_session / set_session_visibility / start_benchmark /
+# get_benchmark_progress / decrypt_benchmark_run /
+# set_benchmark_visibility) directly through their MCP client.
+# See `finlet manual quickstart`.
 
 
 # ── plugins ──────────────────────────────────────────────────
@@ -981,7 +416,7 @@ def plugins_add(
     finlet_key = os.environ.get("FINLET_API_KEY")
     if not finlet_key:
         typer.echo(_MISSING_API_KEY_MESSAGE, err=True)
-        raise typer.Exit(2)
+        raise typer.Exit(EXIT_AUTH_REQUIRED)
 
     body: dict[str, object] = {"plugin": name, "enabled": True}
     if api_key is not None:
@@ -1053,7 +488,7 @@ def plugins_remove(
     finlet_key = api_key or os.environ.get("FINLET_API_KEY")
     if not finlet_key:
         typer.echo(_MISSING_API_KEY_MESSAGE, err=True)
-        raise typer.Exit(2)
+        raise typer.Exit(EXIT_AUTH_REQUIRED)
 
     body: dict[str, object] = {
         "plugin": name,
@@ -1343,9 +778,9 @@ def _run_oauth_login_flow() -> int:
 
         # ----- Persist credentials at mode 0600 -----
         # Atomic write contract (decision record §5) lives in
-        # :func:`_write_credentials`, which is also reused by the
-        # auto-refresh path in :func:`_resolve_bearer_token` to rotate
-        # tokens in place when the AS issues a new pair.
+        # :func:`_write_credentials`. v2.0.0 dropped the CLI's MCP
+        # dispatch path, so token refresh is now an MCP-client concern;
+        # this helper persists the initial pair issued by the AS.
         _write_credentials(
             {
                 "access_token": access_token,
@@ -1572,14 +1007,15 @@ def auth_status() -> None:
 
     Auth-failure paths exit :data:`EXIT_AUTH_REQUIRED` (2) so shell
     scripts can distinguish "not authenticated" from other CLI errors
-    (F-3 hotfix — matches the MCP tool-dispatch surface in
-    :func:`_emit_envelope`).
+    (F-3 hotfix); the same exit code is shared by
+    :func:`plugins_add` / :func:`plugins_remove` when ``FINLET_API_KEY``
+    is missing.
 
     This is a purely local check — does NOT ping the server. Use this
-    config = data.get("config", {})
-    universe = config.get("universe", [])
-    if universe:
-        typer.echo(f"  Universe: {', '.join(universe)}")
-    typer.echo(f"  Capital: ${config.get('initial_capital', 0):,.2f}")
+# REMOVED in v2.0.0: top-level advance / order / portfolio / status.
+# Agents call the MCP tools (advance_time / submit_order / get_portfolio /
+# get_session) directly through their MCP client. See
+# `finlet manual quickstart`.
 
 
 # ── mcp ──────────────────────────────────────────────────────
@@ -1983,7 +1113,7 @@ def mcp_serve() -> None:
         from finlet.logging import configure_logging
     except ImportError:
         typer.echo("Error: Local MCP server requires the full Finlet installation.", err=True)
-        typer.echo("Use MCP-over-HTTP with finlet.dev instead.", err=True)
+        typer.echo("Point your MCP client at https://finlet.dev/mcp instead.", err=True)
         typer.echo("Install server with: pip install finlet[server]", err=True)
         raise typer.Exit(1)
     configure_logging()
@@ -2005,7 +1135,7 @@ def mcp_serve() -> None:
         from finlet.mcp.server import mcp as mcp_server
     except ImportError:
         typer.echo("Error: Local MCP server requires the full Finlet installation.", err=True)
-        typer.echo("Use MCP-over-HTTP with finlet.dev instead.", err=True)
+        typer.echo("Point your MCP client at https://finlet.dev/mcp instead.", err=True)
         typer.echo("Install server with: pip install finlet[server]", err=True)
         raise typer.Exit(1)
 

exec
/bin/zsh -lc "git show --format='%H%n%B' --no-patch cfadd81 | nl -ba | sed -n '1,80p'" in /Users/justnau/finlet
 succeeded in 0ms:
     1	cfadd81ee2c792b73eb6f1a900fb3840b9749d9c
     2	[Team A v2.0.0]: delete CLI convenience commands + dead helpers; rewrite module docstring
     3	
     4	Removes the v1.0.1 CLI MCP-over-HTTP dispatch surface and its
     5	convenience commands. Agents now address the cloud /mcp endpoint
     6	directly through their own MCP client.
     7	
     8	Surface AFTER v2.0.0:
     9	- finlet serve / register / auth (login/logout/status) /
    10	  plugins (list/add/remove) / mcp serve / manual
    11	
    12	Removed:
    13	- session sub-app (create/list/delete/publish)
    14	- benchmark sub-app (start/progress/decrypt/visibility)
    15	- top-level advance / order / portfolio / status
    16	- finlet/cli_mcp_client.py (entire file)
    17	- _dispatch_mcp_tool / _translate_mcp_error / _emit_envelope /
    18	  _resolve_bearer_token / _AUTH_REQUIRED_MARKERS / _AUTH_REQUIRED_HINT /
    19	  _AsyncioTimeoutError alias / top-level 'import asyncio' /
    20	  _normalize_start_iso
    21	- session_app + benchmark_app Typer sub-apps + their add_typer calls
    22	- 'from finlet.cli_mcp_client import ...' import
    23	- stale module docstring describing the deleted dispatch model
    24	- stale inline reference at the OAuth login path to _resolve_bearer_token
    25	
    26	Kept:
    27	- EXIT_AUTH_REQUIRED (now used by plugins_add, plugins_remove,
    28	  auth_status x 2 — 6 hits total including def + docstring)
    29	

exec
/bin/zsh -lc "sed -n '1,260p' docs/KNOWN_FAILURES.md" in /Users/justnau/finlet
 succeeded in 0ms:
# Known Test Failures
> Last updated: 2026-05-23 by pre-flight check (exec-plan `V2_PURE_MCP_EXECUTION_PLAN`) — pre-spawn HEAD = `fb2637c` (post 2026-05-22 SESSION_LEVEL_BLIND v12 SHIPPED at `27d96ca` + cli.py:624 blind-mode fallback partial-fix exec-plan stage at `fb2637c`). Pre-flight ran in SMOKE mode (6-pass targeted pytest split, matching the established 2026-05-19/2026-05-22 pattern). Full-suite invocation skipped per documented dev-machine aiosqlite asyncio-teardown stall pattern; CI single-thread is the authoritative gate per `feedback_pr_gated_ci.md`. Combined SMOKE totals: pass-1 `tests/mcp/ tests/leaderboard/ tests/db/` → **950 passed, 1 xfailed in 126.29s**; pass-2 `tests/core/ tests/plugins/ tests/auth/ --ignore=tests/auth/oauth` → **1437 passed in 111.37s**; pass-3 `tests/api/ tests/services/ tests/gdpr/ tests/test_cli.py tests/test_cli_help.py tests/test_cli_benchmark.py` → **1999 passed, 1 skipped in 227.16s**; pass-4 `tests/auth/oauth/test_e2e_authcode_flow.py` (the 6 xfail-tracked tests in isolation) → **6 xpassed in 66.94s** (markers kept with `strict=False` per the established convention — the underlying aiosqlite asyncio-teardown race is known-intermittent under full-suite teardown pressure and removing markers would re-arm the gate next time the race surfaces); pass-5 `tests/billing/ tests/marketplace/ tests/telemetry/ tests/integration/ tests/property/ tests/test_cli_oauth_login.py tests/test_manual.py tests/test_manual_generate_llms_txt.py` → **471 passed in 16.24s**; pass-6 `tests/auth/ --ignore=tests/auth/oauth tests/dashboard/ tests/ingestion/ tests/scripts/ tests/fixtures/ tests/deploy/` → **642 passed in 183.02s**. Total **5499 passed, 1 skipped, 1 xfailed, 6 xpassed, 0 failed** across the six pytest invocations. The 6 xpassed are the OAuth e2e tests in `tests/auth/oauth/test_e2e_authcode_flow.py` lines 143/299/339/392/454/467 — verified xfail markers in place via grep. The 1 xfailed is `test_create_session_with_readonly_jwt_returns_insufficient_scope` at `tests/mcp/test_scope_enforcement.py:650` (StreamableHTTPSessionManager singleton conflict) — marker behaves as xfailed as expected. No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 5-team exec-plan to land v2.0.0 pure-MCP CLI cutover — Team A (`finlet/cli.py` surgery: rip server-side dispatch + benchmark-CLI removal + `finlet mcp serve` retain), Team C (server-side docs cleanup + `finlet/manual/` content + `dashboard/llms.txt` regen + `finlet/manual/registry.py` + `finlet/manual/generate_llms_txt.py`), Team D (`dashboard/index.html` + `dashboard/setup.html` + `dashboard/agent-guide.html` + new client-matrix integrations), Team B (`tests/test_cli.py` + `tests/test_cli_benchmark.py` + `tests/test_cli_help.py` + `tests/api/test_cli_mcp_client.py` + 4 new MCP assertions in `tests/mcp/test_decrypt_visibility_tools.py`), Team E (capstone: `pyproject.toml` version bump to 2.0.0 + `CHANGELOG.md` repair + `docs/launch/templates.md` + `docs/decisions/cli-mcp-http-dispatch.md` + `README.md` + `docs/ARCHITECTURE.md` + `docs/PRIVACY_POLICY.md`).
>
> Last updated: 2026-05-22 by post-merge close-out (exec-plan `SESSION_LEVEL_BLIND` v12 SHIPPED) — terminal HEAD = `e33cfb0` (post 7-team A-G merge + 6 cascading fix commits: Codex Team A P1+P2 `427ad87` catalog union + atomicity reorder, Team B P1 `ff79ab7` wall-clock audit redaction, Team D P1 `a5f8693` CLI response echo, Team E `f60a7ec` 3 STRONGs test quality, Team A Round 2 `620d825` scope-bypass-to-api-driven-only, Round 4 BLOCKER `e33cfb0` unforgeable `UserRecord.is_internal_benchmark` marker). Combined smoke gate: **3468 passed, 0 failed**. No new failures introduced, no xfail markers added or removed. Pre-existing 6 OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` (aiosqlite asyncio teardown race) verified in place at lines 143/299/339/392/454/467. Pre-existing 1 xfail in `tests/mcp/test_scope_enforcement.py:650` (StreamableHTTPSessionManager singleton conflict) verified in place. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope was a forward-only feature add (session-level blind opt-in via `create_session(blind=True)`); none of the surface-area changes touch the xfailed test paths.
>
> Last updated: 2026-05-22 by pre-flight check (exec-plan `SESSION_LEVEL_BLIND`) — pre-spawn HEAD = `dba6564` (prep commit on top of `b1a305f` post-Codex-3pack ARCHITECTURE+REMAINING_TASKS doc sync). Pre-flight ran in SMOKE mode (scope-limited pytest on `tests/api tests/mcp tests/leaderboard tests/billing tests/core tests/services` with `--ignore=tests/auth/oauth`) because the full-suite invocation hit the documented `tail -50` pipe-buffering + full-suite-timeout pattern from prior entries (KNOWN_FAILURES 2026-05-19, 2026-05-15) on this dev machine, and the subsequent retry was forced inline-synchronous per the harness reconnect. Smoke ran cleanly in 340.45s: **3195 passed, 1 skipped, 1 xfailed, 0 failed, 15119 warnings**. The 15119 warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change). The 1 xfailed is the `test_create_session_with_readonly_jwt_returns_insufficient_scope` entry below (StreamableHTTPSessionManager singleton conflict) — marker in place at `tests/mcp/test_scope_enforcement.py:650`, behaves as xfailed as expected. The 6 OAuth e2e xfail markers in `tests/auth/oauth/test_e2e_authcode_flow.py` were verified in place at lines 143/299/339/392/454/467 via grep but their surface was excluded from this smoke run (well-tested in prior pre-flights, ignored to avoid the aiosqlite teardown stall under full-suite pressure). No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 5-team exec-plan to introduce session-level blinding (REST + MCP + dashboard fairness/no-leak) — Team A (session_service.py blind opt-in via create_session + `_blind` field + `_compute_blind_mapping` helper + serializer plumbing through `session_response`), Team B (REST routes blind-flag wiring in `routes_session.py` + new `tests/api/test_session_create_blind.py` + `test_session_configure_blind.py` + `test_complete_session_blind.py`), Team C (MCP tools_session.py blind wiring in `mcp/server.py` + `mcp/tools_session.py` + new `tests/mcp/test_create_session_blind.py` + `test_session_lifecycle_blind.py`), Team D (CLI + benchmark_state.py blind plumbing through `cli.py` + `leaderboard/benchmark_state.py` + new `tests/billing/test_tier_max_tickers_removed.py` + repurpose `tests/api/test_input_validation.py::test_configure_universe_too_many_returns_422`), Team E (regression coverage: extend `tests/api/test_public_session_blind.py` + NEW `tests/e2e/test_session_level_blind_zero_leak.py` + dashboard `app.js`/`index.html`/`pricing.html` integration).
>
> Last updated: 2026-05-21 by pre-flight check (exec-plan `codex-bugs-4pack-v2`) — pre-spawn HEAD = `677f569` (post `6a79802` exec-plan staging commit, on top of PRs landed since the 2026-05-21 blind-sse-defense-in-depth baseline: bug-11cb2f16 scope flip + bug-4fa9160a input-validation gate + bug-79c7b578 MCP envelope hygiene + bug-b25eba4d lint cleanups). Pre-flight ran the full-suite (`uv run pytest tests/ -q --timeout=120 --ignore=tests/strategies --tb=no -p no:randomly`) and it completed cleanly in 651.44s (0:10:51): **5477 passed, 1 skipped, 6 xpassed, 0 failed, 15215 warnings**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate next time the race surfaces. The 15215 warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change) plus `websockets.legacy` deprecation noise from uvicorn (pre-existing). No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Test count grew +238 since the 2026-05-21 blind-sse baseline (5239 → 5477) reflecting the 4 Codex bug exec-plans landed since (bug-11cb2f16, bug-4fa9160a, bug-79c7b578, bug-b25eba4d); no failures introduced. Iteration scope: 4-team exec-plan to close 12 Codex bug-hunt findings + gitleaks hotfix — Team A2 (scope test hardening + transport-level test in `tests/mcp/test_scope_enforcement.py`), Team B2 (earliest-* semantics + docstrings + no-session discovery cap-to-now in `finlet/api/services/market_service.py` + `finlet/api/routes_market.py` + `finlet/mcp/server.py` + `tests/e2e/test_date_ceiling_zero_leak.py`), Team C2 (submit_order persist atomicity + inf/nan gate + test rename in `finlet/api/services/trade_service.py` + `finlet/mcp/tools_trading.py` + `finlet/api/routes_trade.py` + `tests/mcp/test_submit_order_validation.py` + new `tests/api/test_trade_service_atomicity.py`), Team D2 (FastMCP boundary wrapper for pydantic ValidationError + sanitize_paths key scrub + gitleaks hotfix in NEW `finlet/mcp/_fastmcp_patches.py` + `finlet/mcp/error_envelope.py` + `finlet/mcp/server.py` + `tests/mcp/test_error_envelope_hygiene.py` + `tests/mcp/test_scope_enforcement.py:60`).
>
> Last updated: 2026-05-21 by pre-flight check (exec-plan `2026-05-21-blind-sse-defense-in-depth`) — pre-spawn HEAD = `2e443d5` (post PR `2e443d5` chore(ci): move test (3.13) to PR gate + drop duplicate post-merge runs, on top of `914cd3f` blind-export exec-plan COMPLETED marker + PR #118 `abb86bd` Codex bugs blind-iter2 ship). Pre-flight ran the full-suite (`uv run pytest tests/ -q --timeout=120 --no-header -p no:randomly`) and it completed cleanly in 594.86s (0:09:54): **5239 passed, 1 skipped, 6 xpassed, 0 failed, 15180 warnings**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate next time the race surfaces. The 15180 warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change) plus `websockets.legacy` deprecation noise from uvicorn (pre-existing). No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Test count grew +69 since the 2026-05-20 baseline (5170 → 5239) reflecting the 3 new test files Team F shipped in the blind-export iteration; no failures introduced. Iteration scope: 4-team exec-plan to close SSE/REST trace + benchmark-completed envelope leak surfaces left after the 2026-05-20 blind-export iteration (Codex bug `0558053d` follow-up) — Team A (BlindMapping serializer-poison hardening + missing `tests/core/test_blind_mapping.py`), Team B (SSE trace/benchmark-completed envelope blinding in `finlet/api/routes_sse.py` + `finlet/api/services/{session,clock,trade}_service.py`), Team C (benchmark_state + reporting publish-gate hardening), Team D (zero-leak gate extension to live SSE event surface).
>
> Last updated: 2026-05-20 by pre-flight check (exec-plan `EXEC_PLAN_BLIND_EXPORT_2026_05_20`) — pre-spawn HEAD = `766ef43` (post PR #118 `abb86bd` Codex bugs `d1baf1b8`+`ad919e11`+`53c9eccb` blind-iter2 ship + watchdog-cron exec-plan tweak). Pre-flight ran the full-suite (`uv run pytest tests/ -q --timeout=120 --tb=no -p no:cacheprovider`) and it completed cleanly in 559.41s (0:09:19): **5170 passed, 1 skipped, 6 xpassed, 0 failed, 15139 warnings**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate next time the race surfaces. The 15139 warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change) plus `websockets.legacy` deprecation noise from uvicorn (pre-existing). No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 7 teams closing the live blind-benchmark export/trace leak surfaces (Codex bug `0558053d-aa73-47e4-bd00-4a09417568d6`) — Team A (BlindMapping serializer-poison + pre-persist trace blinding across `finlet/core/blind_mapping.py` + `finlet/db/persistence.py` + 5 `save_trace_entry` call sites in `finlet/api/services/{market,trade,clock}_service.py`), Team B (BenchmarkRunModel new columns `decrypted_at`/`published`/`published_anonymous`/`published_at` + migration 021 + immutability invariant in `finlet/db/leaderboard_models.py` + `finlet/db/leaderboard_persistence.py` + `finlet/leaderboard/benchmark_state.py`), Team C (export_benchmark_results A1 fix + reporting defensive raise in `finlet/mcp/tools_benchmark.py:436-516` + `finlet/leaderboard/reporting.py`), Team D (decrypt + visibility tools + public benchmark router NEW in `finlet/api/services/benchmark_service.py` + `finlet/api/routes_public_benchmark.py` + `finlet/api/routes_benchmark.py` + `finlet/api/schemas/benchmark.py` + `finlet/api/deprecation.py` + `finlet/cli.py`), Team E (REST + SSE trace blinding in `finlet/api/routes_portfolio.py` + `finlet/api/routes_sse.py` + `finlet/api/serializers.py` + `finlet/api/routes_public_session.py` re-export), Team F (zero-leak gate extension + 3 new test files in `tests/e2e/`), Team G (docs + 3 new decision records + ARCHITECTURE.md + REMAINING_TASKS.md + CLAUDE.md).
>
> 2026-05-20 (post-merge note, exec-plan `codex_bugs_blind_iter2`): 6 OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` ran as XPASS during the finalize full-suite gate; xfail markers RETAINED because root cause (aiosqlite asyncio-teardown race) is unaddressed — these may regress on the next run.
>
> Last updated: 2026-05-20 by pre-flight check (exec-plan `codex_bugs_blind_iter2_EXECUTION_PLAN`) — pre-spawn HEAD = `73009e2` (post PR #117 Codex bug 50abd05e ship — blind-leak iter1 closure). Pre-flight ran the full-suite (`uv run pytest tests/ -q --timeout=120 --tb=no -p no:cacheprovider`) and it completed cleanly in 484.89s (0:08:04): **5116 passed, 1 skipped, 6 xpassed, 0 failed, 15170 warnings**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate next time the race surfaces. The 15170 warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change) plus `websockets.legacy` deprecation noise from uvicorn (pre-existing). No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 4 teams closing 3 Codex-reported blind-leak surfaces from the 2026-05-20 second dry-run — Team A (`list_available_tickers` metadata-vs-reality correctness fix in `finlet/api/services/market_service.py`), Team B (`@blind_error_mapper` decorator across `finlet/mcp/server.py` + `tools_trading.py` + `tools_portfolio.py` + `tools_benchmark.py` + `tools_session.py` + `tools_telemetry.py` to auto-blind every tool's error response), Team C (`complete_session` benchmark_complete payload blinding in `finlet/mcp/server.py` + `finlet/leaderboard/reporting.py` + `finlet/api/services/session_service.py`), Team D (extend `tests/e2e/test_blind_benchmark_zero_leak.py` to exercise error paths, completion payloads, and metadata cross-validation + extend `docs/decisions/blind-benchmark-envelope-fields-must-blind.md`).
>
> Last updated: 2026-05-19 by pre-flight check (exec-plan `CODEX_BUG_CE8DE077_EXECUTION_PLAN`) — pre-spawn HEAD = `54d0da7` (orchestrator setup commit, post `949c93b` fundamentals hero-save shipment at PR #111). Pre-flight ran the full-suite (`uv run pytest tests/ -q --timeout=120 -p no:xdist`) and it completed cleanly in 1226.28s (0:20:26): **4943 passed, 1 skipped, 6 xpassed, 9 errors**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate next time the race surfaces. The 9 errors are the documented local-environment data-volume flake from `tests/integration/test_mcp_oauth_e2e.py` — same root cause as the 2026-05-10 entry below (`live_server` session-scope fixture times out at 30s under the inline-benchmark-startup load on this dev machine, ~hundred-plus `benchmark-*` session_loaded events). Verified post-run: `test_oauth_login_writes_credentials_at_mode_0600` passes in 29.65s when run in isolation. NOT a regression — CI single-thread on the same SHA passes them. xfail markers are NOT added because the failures are at fixture setup (xfail wraps the test body, not the fixture), and the established convention (2026-05-10 entry below) is to document them here without marking, since CI is the authoritative gate per `feedback_pr_gated_ci.md`. No new failures, no entries added to the table, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: cascading fixes for Codex bug ce8de077 across `finlet/api/services/session_service.py` + `finlet/mcp/server.py` + `finlet/mcp/auth.py` + `finlet/mcp/tools_benchmark.py` + `finlet/leaderboard/benchmark_state.py` + `finlet/leaderboard/benchmarks.py` + `finlet/db/leaderboard_models.py` + `finlet/db/leaderboard_persistence.py` + `finlet/core/session.py` + `finlet/core/clock.py` + corresponding tests.
>
> Last updated: 2026-05-19 by pre-flight check (exec-plan `FUNDAMENTALS_HERO_SAVE_EXECUTION_PLAN`) — main HEAD = `6a3bba5` (orchestrator setup commit). Pre-flight ran in SMOKE mode (4-pass targeted pytest split, matching the established 2026-05-19 pre-flight pattern). The full-suite invocation reproduced the documented aiosqlite asyncio-teardown hang stall — killed after early stall, retried with 4-pass split per `feedback_pr_gated_ci.md` (CI single-thread is the trusted full-suite gate). Combined SMOKE totals across 4 pytest invocations: pass-1 `tests/mcp/ tests/leaderboard/ tests/db/` → **671 passed in 125.52s**; pass-2 `tests/core/ tests/plugins/ tests/auth/ --ignore=tests/auth/oauth` → **1307 passed in 238.27s**; pass-3 `tests/api/ tests/services/ tests/gdpr/ tests/test_cli.py` → **1774 passed, 1 skipped in 206.36s**; pass-4 `tests/auth/oauth/test_e2e_authcode_flow.py` (the 6 xfail-tracked tests in isolation) → **6 xpassed in 175.19s** (markers kept with `strict=False` per the established convention — the underlying aiosqlite asyncio-teardown race is known-intermittent under full-suite teardown pressure and removing markers would re-arm the gate next time the race surfaces). Total **3758 passed, 1 skipped, 6 xpassed, 0 failed** across the four pytest invocations. No new failures, no new xfail markers added, no entries removed. Pre-existing 6 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False` markers verified in place via grep. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: fundamentals_s3 hero-save coverage fix across `finlet/plugins/fundamentals_plugin.py` + `finlet/ingestion/s3_writer.py` + `scripts/ingest_fundamentals.py` + `finlet/api/services/market_service.py` + corresponding test files.
>
> Last updated: 2026-05-19 by pre-flight check (exec-plan `MCP_BENCHMARK_HARNESS_FIX_EXECUTION_PLAN`) — spawn-base SHA = `241cabc` (`main`). Pre-flight ran in SMOKE mode (4-pass targeted pytest split, matching prior 2026-05-19 pre-flight pattern) — the full-suite invocation `uv run pytest tests/ -q --timeout=60 --ignore=tests/e2e -x` reproduced the documented aiosqlite asyncio-teardown hang at ~38% (the `XXXXXX` block of OAuth xfails surfaces the worker-thread "Event loop is closed" race, which then stalls subsequent tests indefinitely past the budget). CI single-thread is the trusted full-suite gate per `feedback_pr_gated_ci.md` and `feedback_pyproject_comment_stale_about_ci_xdist`. Combined SMOKE totals across 4 pytest invocations: pass-1 `tests/mcp/ tests/leaderboard/ tests/db/` → **664 passed in 117.17s**; pass-2 `tests/core/ tests/plugins/ tests/auth/ --ignore=tests/auth/oauth` → **1307 passed in 221.61s**; pass-3 `tests/api/ tests/services/ tests/gdpr/ tests/test_cli.py` → **1767 passed, 1 skipped in 203.71s**; pass-4 `tests/auth/oauth/test_e2e_authcode_flow.py` (the 6 xfail-tracked tests in isolation) → **6 xpassed in 164.79s** (markers kept with `strict=False` per the established convention — the underlying aiosqlite asyncio-teardown race is known-intermittent under full-suite teardown pressure and removing markers would re-arm the gate next time the race surfaces). Total **3744 passed, 1 skipped, 6 xpassed, 0 failed** across the four pytest invocations. e2e collection-only smoke on `tests/e2e/` confirms `tests/e2e/test_benchmark_flow.py` (6 tests) collects cleanly; full e2e run deferred (slow live-server fixture). No new failures, no new xfail markers added, no entries removed. Pre-existing 6 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False` markers verified in place via grep. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 4 cascading MCP benchmark bug fixes across `finlet/api/services/session_service.py`, `finlet/mcp/tools_benchmark.py`, `finlet/leaderboard/benchmark_state.py`, `finlet/db/leaderboard_persistence.py`, `finlet/mcp/auth.py`, `finlet/telemetry/bug_storage.py` + corresponding tests.
>
> Last updated: 2026-05-19 by pre-flight check (exec-plan `MCP_BENCHMARK_FIXES_EXECUTION_PLAN`) — pre-spawn HEAD = `1b53d97` (post `60ac154` /mcp dual-accept generator regen, on top of `2da10fc` /mcp dual-accept reality alignment merge). Pre-flight ran in SMOKE mode (4-pass targeted pytest split, matching the documented 2026-05-19 prior pre-flight pattern) rather than full-suite, because the dev machine's documented full-suite hang under aiosqlite asyncio-teardown pressure (see 2026-05-10 and 2026-05-15 entries below) reproduced again here: `uv run pytest tests/ -q --timeout=120 -p no:xdist` stalled at ~52% past the 900s budget; CI is the trusted full-suite gate per `feedback_pr_gated_ci.md`. Combined SMOKE totals: pass-1 `tests/mcp/ tests/leaderboard/ tests/db/` → **655 passed in 116.62s**; pass-2 `tests/core/ tests/plugins/ tests/auth/ --ignore=tests/auth/oauth` → **1294 passed in 229.52s**; pass-3 `tests/api/ tests/services/ tests/gdpr/ tests/test_cli.py` → **1767 passed, 1 skipped in 204.36s**; pass-4 `tests/auth/oauth/test_e2e_authcode_flow.py` (the 6 xfail-tracked tests in isolation) → **6 xpassed in 161.56s** (kept marked with `strict=False` per the established convention — the underlying aiosqlite asyncio-teardown race is known-intermittent under full-suite teardown pressure and removing markers would re-arm the gate next time the race surfaces). Total **3722 passed, 1 skipped, 6 xpassed, 0 failed** across the four pytest invocations. The `tests/auth/oauth/` directory-level surface (broader than the 6-test e2e file) was tried but timed out at 300s in the wider iteration (`EXIT: 124`) — same aiosqlite teardown pattern; the 6 in-scope xfails passed before the stall. No new failures, no new xfail markers added, no entries removed. Pre-existing 6 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False`. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 4 parallel teams — Team A (MCP benchmark tooling: `finlet/mcp/tools_benchmark.py` + `finlet/leaderboard/benchmarks.py` + `finlet/leaderboard/benchmark_state.py` + `finlet/db/persistence.py` + `tests/mcp/test_tools_benchmark.py`), Team B (`finlet/core/clock.py` + `tests/core/test_clock.py` + `tests/core/test_clock_step_integration.py`), Team C (`finlet/plugins/fundamentals_plugin.py` + `finlet/plugins/base.py` + `tests/plugins/test_fundamentals_plugin.py` + `tests/plugins/test_fundamentals_backfill.py`), Team D (`finlet/core/session.py` + `finlet/api/services/session_service.py` + `tests/db/test_persistence.py` + `tests/leaderboard/test_benchmark_state.py`).
>
> Last updated: 2026-05-19 (post-merge close-out — exec-plan `AI_QUANTAMENTAL_STRATEGY_EXECUTION_PLAN` 7-team shipment landed). No entries added or removed this iteration. The 6 pre-existing OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False`; pre-existing Hypothesis portfolio-rounding flake unchanged. Shipment introduced no new pytest failures, no new xfail markers; subproject tests live under `strategies/ai_quantamental/tests/` (own pytest invocation, excluded from the root pytest gate).
>
> Last updated: 2026-05-19 by pre-flight check (exec-plan `AI_QUANTAMENTAL_STRATEGY_EXECUTION_PLAN`) — main HEAD = `b34f99b` (post pre-flight artifact commit on top of `3c506ce` RFC 8414 OAuth metadata alias). Pre-flight ran in SMOKE mode (3-pass targeted pytest on `tests/api/ tests/mcp/ tests/leaderboard/ tests/test_cli.py` + `tests/auth/ --ignore=tests/auth/oauth` + `tests/core/ tests/plugins/ tests/services/ tests/gdpr/`) rather than full-suite, because the dev machine's documented data-volume flake on `tests/integration/` (see 2026-05-10 entry below) makes full-suite gating unreliable here and the full-suite `uv run pytest tests/ --timeout=120 --ignore=tests/e2e` invocation hung at ~31% with aiosqlite asyncio teardown timeouts (same pattern as prior pre-flights). CI is the trusted full-suite gate per `feedback_pr_gated_ci.md`. Combined SMOKE totals: pass-1 (api+mcp+leaderboard+cli) **2152 passed, 1 skipped in 294.46s**, pass-2 (auth no-oauth) **103 passed in 182.85s**, pass-3 (core+plugins+services+gdpr) **1386 passed in 34.51s** — total **3641 passed, 1 skipped, 0 failed** across the three pytest invocations. The `tests/auth/oauth/` surface was not gated in this pre-flight because the 6 pre-existing aiosqlite-asyncio-teardown xfails below already cover that surface and standalone re-checks on this dev machine consistently surface the same teardown race. Lint not gated this iteration (deferred to per-team validation). No new failures, no new xfail markers added, no entries removed. Pre-existing 6 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False`. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 6-session execution — Team A (quantamental scaffolding), Team B (`report_bug` MCP tool), Team C (derived-metric helpers), Team D (screens + portfolio), Team E (historical backfill simulator — launch video material), Team F (LLM tiebreaker), Team G (live driver + GH Actions monthly cron).
>
> Last updated: 2026-05-15 by pre-flight check (exec-plan `USER_MANUAL_OVERHAUL_EXECUTION_PLAN`) — main HEAD = `48121cc` (post PR #84 detached-instance regression-test merge on top of PR #83 Stripe live-mode activation at `f3781cd`). Pytest full-suite run (`uv run pytest tests/ -q --timeout=120 -p no:cacheprovider`): **4657 passed, 6 xpassed, 14692 warnings in 913.22s (0:15:13)**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate on the same race next time it surfaces. No new failures, no new xfail markers added, no entries removed this iteration. Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table) remains unchanged. Iteration scope: 7-team execution — Team A (Manual Foundation: NEW `finlet/manual/` package + `finlet/cli.py` `manual` command + `pyproject.toml` hatchling include + `.github/workflows/ci.yml` paths-ignore include override + `README.md:66` args fix), Team B1 (CLI docstring see-also footers in `finlet/cli.py` + `tests/test_cli_help.py` NEW), Team B2 (REST API + Billing envelope suffixes across `finlet/api/routes_*.py` + `finlet/billing/service.py` + new tests), Team B3 (MCP envelope suffixes + `_AUTH_REQUIRED_MESSAGE` dedup + `finlet/api/deprecation.py` `/mcp` whitelist + new tests), Team B4 (OAuth modeled envelope suffixes across `finlet/auth/oauth/*.py` + new tests), Team C (Plugin envelope suffixes across 4 named plugins + `tests/plugins/test_error_anchors.py` NEW), Team D (Dashboard polish: `dashboard/agent-guide.html` 8-tab expansion + `dashboard/setup.html` Phase-5 voice pass + `dashboard/llms.txt` regen + `scripts/git-hooks/pre-commit` 4th guard + `scripts/lint-llms-txt-fresh.sh` NEW + `tests/e2e/journey-19-agent-guide.spec.ts` NEW).
>
> Last updated: 2026-05-14 by pre-flight check (exec-plan `GDPR_EXPORT_F_EXECUTION_PLAN`) — main HEAD = `84161f4` (post pre-flight cleanup commit clearing stale team-prompts on top of `278b242` GDPR-F plan stage). Pytest full-suite run (`timeout 1100 uv run pytest tests/ -q --timeout=120 -x -p no:cacheprovider`): **4493 passed, 6 xpassed, 14674 warnings in 820.97s (13:40)**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate on the same race next time it surfaces. No new failures, no new xfail markers added, no entries removed this iteration. Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table) remains unchanged. Iteration scope: GDPR Article 20 data export (Item F) — async job, ZIP-per-table JSONL archive, S3 24h lifecycle, presigned URL, OAuth Bearer-only, audit table, per-team file ownership across new `finlet/gdpr/` package + `finlet/db/auth_models.py` + `finlet/api/app.py` + `finlet/api/routes_settings.py` + service/schema cleanups.
>
> Last updated: 2026-05-14 by pre-flight check (exec-plan `HYGIENE_BATCH_2026_05_13`) — main HEAD = `3391f0b` (post PR #74 SETTINGS_AND_BILLING_RESTORE merge). Pre-flight ran in SMOKE mode (targeted pytest on `tests/api/ tests/auth/ tests/mcp/ tests/leaderboard/ tests/test_cli.py`) rather than full-suite, because the dev machine's data-volume flake on `tests/integration/` (documented in the 2026-05-10 entry below) makes full-suite gate unreliable here and CI is the trusted full-suite gate. The combined surface was split into two passes to stay under the per-invocation timeout cap: pass-1 `tests/api/ tests/mcp/ tests/leaderboard/ tests/test_cli.py` ran **2036 passed, 0 failed, 0 xfail, 0 skipped in 276.43s**, and pass-2 `tests/auth/ --ignore=tests/auth/oauth` ran **103 passed, 0 failed, 0 xfail, 0 skipped in 150.71s** — total **2139 passed, 0 failed, 0 xfail, 0 skipped in 427.14s** across the two pytest invocations. The `tests/auth/oauth/` surface was not gated in this pre-flight because the 6 pre-existing aiosqlite-asyncio-teardown xfails below already cover that surface and the 180s standalone re-check on this dev machine timed out mid-run after ~70 cases (63 dots + 6 X + 1 dot) without any new failures observed — same pattern documented under 2026-05-10/2026-05-11. Lint: clean (`ruff check finlet/ tests/`). The `--timeout=120` flag from the original pre-flight instruction was dropped because `pytest-timeout` is the K6 work item this iteration is shipping — it is not yet installed at `3391f0b`, so the flag errored out and was removed from the invocation. No new failures introduced, no new xfail markers added, no entries removed. Pre-existing 6 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False`. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: single Team A — K6 (`pyproject.toml` dev dep), K5 (journey-14/15 e2e), I5 (`_ensure_utc` canonicalization to `finlet/utils/datetime.py`), I8 (13 vague-error rewrites across `finlet/api/services/settings_service.py` + `finlet/api/routes_auth_credentials.py` + `finlet/api/routes_auth_sessions.py` + `finlet/api/routes_marketplace_admin.py`).
>
> Last updated: 2026-05-13 by pre-flight check (exec-plan `PUBLIC_SESSION_VIEW_FOLLOWUPS_EXEC_PLAN`) — main HEAD = `cd21911` (post PR #70 ci-cost-cuts merge). Pre-flight ran in DEFERRED mode — full pytest skipped because (a) the local pytest invocation `uv run pytest tests/ -q --tb=no` ran for 14 minutes past the configured 600s `timeout(1)` cap with the output buffered behind `tail -20` (the pipe held all output until exit, so wall-time visibility was zero); the runtime killed it at the pre-flight budget. (b) main is unchanged from the 2026-05-12 PR #70 surface for the API/MCP/CLI areas the followups touch (this iteration's Team A is `dashboard/landing.html` line-241 placeholder substitution, Team B is `tests/e2e/` smoke + helper additions, Team C is `finlet/api/app.py` + `finlet/api/routes_session.py` + `finlet/api/deprecation.py` API-routes-rules pruning); the underlying public-session view tests on `tests/api/test_public_session.py` (Phase A green at PR #65 squash 37ea32f) remain in scope. (c) The 4 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) below remain unchanged with `strict=False`. (d) Pre-existing Hypothesis portfolio-rounding flake unchanged. (e) PR-gated CI is the trusted full-suite gate per `feedback_pr_gated_ci.md` — local dev-machine pytest is documented to flake on `tests/integration/` data-volume issues. No new failures observed pre-launch; no entries added/removed/promoted this iteration. Iteration scope: 3 sequential teams — Team A landing CTA placeholder fix, Team B e2e smoke + Playwright fixture/helper additions, Team C api-routes-rules canonicalization + deprecation cleanup.
>
> Last updated: 2026-05-12 by pre-flight check (exec-plan `PUBLIC_SESSION_VIEW_EXEC_PLAN`) — main HEAD = `a876229` (origin/main, post PR #64 handoff doc merge, on top of PR #63 dashboard empty-states + pricing at `4b829b7`). Pre-flight ran in DEFERRED mode — full pytest skipped because (a) main is unchanged from the 2026-05-11 v1.0.1 baseline below for the API/MCP/CLI surface; (b) per-team validation in the public-session view exec-plan runs targeted pytest gates that cover the surgery surface (`tests/api/test_public_session*.py`, `tests/db/test_session_migration_014.py`, `tests/test_cli.py`); (c) the documented `tests/integration/` data-volume flake from the 2026-05-10 entry below still applies, and the per-team gates avoid that path. No new xfail markers added, no entries removed this iteration. Pre-existing 4 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False`. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Iteration scope: 3 sequential teams per the plan doc — Team A backend (`finlet/db/`, `finlet/api/`, `finlet/mcp/`, `finlet/cli.py`, `tests/api/`, `tests/db/`, `tests/test_cli.py`); Team B frontend (`dashboard/public.html` NEW, `dashboard/public.js` NEW, `dashboard/renderers.js` NEW, refactor `dashboard/app.js`, `dashboard/landing.html` nav + CTA, `finlet/api/app.py` static-route inserts); Team C docs (`docs/ARCHITECTURE.md`, `docs/decisions/session-public-visibility.md` NEW, `docs/REMAINING_TASKS.md`, `docs/PRIVACY_POLICY.md`, `.claude/rules/api-routes.md`).
>
> Last updated: 2026-05-11 by pre-flight check (v1.0.1 hotfix exec-plan `EXECUTION_PLAN_V1_0_1_HOTFIX`) — main HEAD = `cbff2e1` (origin/main, post v1.0.0 finalize PR #52). Pre-flight ran in SMOKE mode (lint + targeted pytest on `tests/test_cli.py tests/api/ tests/mcp/`) rather than full-suite, because the dev machine's data-volume flake on `tests/integration/` (documented in the 2026-05-10 entry below) makes a full-suite gate unreliable here and CI is the trusted gate for full coverage. Lint clean (`ruff check finlet/ tests/`). Smoke pytest: **1745 passed, 0 failed, 1532 warnings in 178.53s**. The warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change). Targeted OAuth e2e re-verify: `tests/auth/oauth/test_e2e_authcode_flow.py` → **4 xpassed in 104.14s** (the same 4 tests xfail-tracked below; preserved with `strict=False` per the convention documented in the 2026-05-10 entry — passed today on this machine but kept marked because the underlying aiosqlite asyncio-teardown race is known-intermittent). No new failures, no new xfail markers added, no entries removed this iteration. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. v1.0.1 scope: Team A (`finlet/api/app.py` + `finlet/mcp/auth.py` + new `tests/mcp/test_http_endpoint.py` + `tests/api/test_mcp_mount.py`), Team B (`finlet/cli_mcp_client.py` + `finlet/cli.py` + `tests/api/test_cli_mcp_client.py` NEW + `tests/test_cli.py`), Team C (`dashboard/agent-guide.html` + `dashboard/setup.html` + `dashboard/landing.html`).
>
> Last updated: 2026-05-10 by pre-flight check (exec-plan `V1_0_0_BLIND_WALK_FIXES` + Team H) — main HEAD = `f679447` (origin/main, post-bandit-hotfix; production deployed). Pytest full-suite run: **4409 passed, 4 xpassed, 12 errors in 875s**. The 4 xpassed are the existing `tests/auth/oauth/test_e2e_authcode_flow.py` entries below — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline below) and removing the markers would re-arm the gate on the same race the next time it surfaces. The 12 errors are all OAuth integration tests in `tests/integration/test_cli_stdio_e2e.py` + `tests/integration/test_mcp_oauth_e2e.py` — they all fail at the `live_server` session-scope fixture with `RuntimeError: live_server failed to come up on 127.0.0.1:<port> within 30s` after migrations and ~hundred-plus `benchmark-*` session_loaded events run inline during boot. This is a **local-environment data-volume flake** (the heavy benchmark dataset on this dev machine pushes startup past the 30s deadline), NOT a regression — CI run `25638684433` (workflow `CI`, branch `hotfix/bandit-b110-nosec`, 2026-05-10 20:15Z, on top of the same `f679447` tree) reports **4421 passed, 4 xpassed, 0 errors** on both py3.12 and py3.13 matrices for the identical tests. No new xfail markers added; no entries removed. Pre-existing Hypothesis portfolio-rounding flake remains unchanged.
>
> Last updated: 2026-05-09 by pre-flight check (exec-plan `MCP_FIRST_PHASE_5_CLI_STDIO`) — main HEAD = `24379ee` (post Phase 4e close-out). Pre-flight identified an aiosqlite + asyncio-loop teardown race in 4 OAuth e2e tests (`tests/auth/oauth/test_e2e_authcode_flow.py`) that ERROR with `RuntimeError: Event loop is closed` in the full-suite gate (the `aiosqlite._connection_worker_thread` outlives the test's asyncio loop, then the next test's loop closure surfaces the worker's pending `set_result`/`set_exception` call as the documented RuntimeError). The 4 tests are xfail'd (`strict=False`) so they continue to be exercised but don't fail the gate; isolated runs with `--timeout=120` still pass them (4/4 in 80.66s). No api_key/Bearer surface failures, no Phase 5 surface contamination — issue is pre-existing pytest async-teardown noise (in scope under tighter timeouts) NOT a regression from Phase 4e or any prior phase. Pytest baseline preserved (4356/4360 passing + 4 xfail).
>
> Last updated: 2026-05-09 (post-merge close-out) — exec-plan `MCP_FIRST_PHASE_4_OAUTH` sub-phase 4e shipped via single team merge (E1 `75223ba` bearer-only cutover + Phase 4 SHIPPED) plus finalize commits `4420745` (plan doc update — E1 SHIPPED + Session 5 checkpoint) and `6e76489` (eval-trace artifacts). **No entries added or removed this iteration.** Phase 4e closes the originally-planned 90-day dual-accept window: the api_key fallthrough is removed from `finlet/mcp/bearer_context.py:resolve_credential` and `finlet/mcp/auth.py:_authenticate_oauth_or_key`, and api_key on MCP tools now returns the documented Phase 4e rejection envelope (`{"error": "api_key authentication is no longer supported on MCP tools. Run 'finlet auth login' to obtain an OAuth Bearer token. See docs/MCP_OAUTH_MIGRATION.md."}`) as a 401. To preserve test-time call-site stability without leaking dual-accept logic into production, `tests/conftest.py` adds an autouse `_legacy_api_key_test_shim` fixture (sentinel-based; legacy MCP unit tests authenticating via `api_key=<key>` arguments keep working) — opt-out via `@pytest.mark.no_api_key_shim` on Phase 4e cutover tests. Post-merge full pytest gate: **4360 passed, 0 failed** (per E1's report, with the targeted 49/49 post-merge gate confirming new tests). No new failures introduced, no xfail markers added, no pre-existing failure tracked in this file resolved. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Pytest baseline updated upward (Phase 4e adds `tests/integration/test_mcp_oauth_e2e.py::TestGroup3BearerOnly` + `tests/conftest.py` shim coverage).
>
> Last updated: 2026-05-09 (post-merge close-out) — exec-plan `MCP_FIRST_PHASE_4_OAUTH` sub-phase 4c shipped via four sequential team merges (C1 `39afe87` JWT validator + `require_oauth` + 90-day sunset decision record, C2 `45024bb` MCP auth Bearer path + Surprise A/B cleanup, C3 `cebd327` 16 MCP tools dual-accept, C4 `ce97aa9` scope enforcement + UserTier mapping) plus one post-merge fixup `ff6909e` updating 3 test stubs (`tests/services/test_gate_unification.py` + `tests/api/test_benchmark_progress.py` + `tests/api/test_bug8_limit_stop_fills.py`) for the Option A 3-tuple migration in `resolve_credential` (caught by gate, not pre-merge validation). **No entries added or removed this iteration.** Phase 4c adds the Resource Server surface: `finlet/auth/oauth/jwt_validator.py` (NEW, joserfc EdDSA-pinned), `finlet/auth/deps.py` (`require_oauth` injector), `finlet/mcp/auth.py` (`_authenticate_oauth_or_key` + `enforce_scope`), `finlet/mcp/bearer_context.py` (NEW, ContextVar middleware + `resolve_credential` 3-tuple), and 16 MCP tools wired across `finlet/mcp/server.py` + `finlet/mcp/tools_benchmark.py` + `finlet/mcp/tools_portfolio.py` + `finlet/mcp/tools_trading.py`. New tests under `tests/mcp/test_oauth_jwt_validator.py`, `tests/mcp/test_oauth_dual_accept.py`, `tests/mcp/test_mcp_auth_oauth_path.py`, `tests/mcp/test_scope_enforcement.py`. Post-fixup gate: targeted on `tests/api/ tests/mcp/ tests/services/ tests/auth/` — **1929 passed, 0 failed** (10:25). Full CI-matching gate (post-fixup): in flight at close-out time. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Pytest baseline updated upward (Phase 4c adds the OAuth tests above).
>
> Last updated: 2026-05-08 (post-merge close-out) — exec-plan `MCP_FIRST_PHASE_4_OAUTH` sub-phase 4b shipped via four sequential team merges (B1 `0ba1717` data layer, B2 `471790d` AS endpoints, B3 `36d06bd` DCR, B4 `6a3adf3` router wiring); **no entries added or removed this iteration**. Phase 4b adds the OAuth Authorization Server surface (`finlet/auth/oauth/` package + migration `014_add_oauth_clients.py` + `pyproject.toml` adds `mcp[auth]>=1.27.0` and `joserfc>=1.0`) plus new tests in `tests/auth/oauth/`. Post-B4 full pytest gate: **4239 passed, 0 failed** (orchestrator confirmed). No new failures introduced, no xfail markers added, no pre-existing failure tracked in this file resolved. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Pytest baseline updated upward (Phase 4b adds tests under `tests/auth/oauth/`).
>
> Last updated: 2026-05-08 (post-merge close-out) — exec-plan `MCP_FIRST_PHASE_4_OAUTH` Team A1 merged to main (commit `e248382`); **no entries added or removed this iteration** (Phase 4a is pure docs — adds `docs/decisions/mcp-oauth-2-1-auth-model.md` decision record only; no Python source or test changes, no new pytest failures, no xfail markers, no resolved pre-existing failure tracked in this file). Test collection-only smoke: 4110 tests collect without import errors. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Pytest baseline preserved per the Phase 3 pre-flight refresh below.

> Last updated: 2026-05-08 by pre-flight check (exec-plan `MCP_FIRST_PHASE_3`) — main HEAD = `57f9ab3` (post Phase 2 close-out). Pytest baseline 4072/4072 passing (full suite, `uv run pytest tests/ -q --timeout=120`, 435.98s). No FAILED, no ERROR, no xfail markers needed. 75 warnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py` + aiosqlite `_connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown noise, no behavior change). Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table below) remains unchanged. Phase 3 scope (3-team plan: A middleware refinement, B docs, C tests) — deprecation-header policy refinement; no Python source changes anticipated outside `finlet/api/app.py` middleware + `tests/api/test_api_versioning.py`. No xfail markers added — full suite is green.

> Last updated: 2026-05-07 (post-merge close-out) — exec-plan `MCP_FIRST_PHASE_2` Teams A/B/C/D/E merged to main (final commit `82959df`); **no entries added or removed this iteration** (Phase 2 closes audit C1/H4/H6 and adds new tests in `tests/services/` but introduced no new pytest failures, no xfail markers, and resolved no pre-existing failure tracked in this file). Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Pytest baseline preserved per the pre-flight refresh below.

> Last updated: 2026-05-07 by pre-flight check (exec-plan `MCP_FIRST_PHASE_2`) — main HEAD = `ed19e91` (post Phase 2 plan-doc commit, on top of Phase 1 close-out at `d08dd3d`). Pytest baseline 4000/4000 passing (full suite, `uv run pytest tests/ -q --timeout=120 --maxfail=200 -p no:cacheprovider`, 395.18s). No FAILED, no ERROR, no xfail markers needed. 63 warnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py` + aiosqlite `_connection_worker_thread` "Event loop is closed" cleanup + starlette per-request-cookies deprecation; pre-existing async-teardown noise, no behavior change). Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table below) remains unchanged. Phase 2 scope per `docs/plans/exec-plans/MCP_FIRST_PHASE_2_EXEC_PLAN.md` (5 worktree spawns): Team A (`finlet/api/services/errors.py` NEW + `finlet/mcp/auth.py` validate_session_id parity + `tests/services/test_errors.py` NEW + `tests/mcp/test_mcp_auth.py` extension); Team B (`finlet/api/services/session_service.py` + `finlet/api/routes_session.py` + `finlet/mcp/server.py` session-tool block + new `tests/services/test_session_service.py` + `tests/mcp/test_mcp_server.py` extension); Team C (`finlet/api/services/trade_service.py` + `finlet/api/routes_trade.py` + `finlet/mcp/tools_trading.py` + new `tests/services/test_trade_service.py` + `tests/mcp/test_mcp_trading.py` extension — closes audit H6); Team D (`finlet/api/services/market_service.py` + `finlet/api/routes_market.py` + `finlet/mcp/server.py` plugin-query block + new `tests/services/test_market_service.py` + `tests/mcp/test_mcp_server.py` extension — closes audit H4 + C1); Team E (new `tests/services/test_gate_unification.py` cross-surface parity tests). No xfail markers added — full suite is green.

> Last updated: 2026-05-07 by pre-flight check (exec-plan `MCP_FIRST_PHASE_1`) — main HEAD = `d08dd3d` (post bug-hunt `20260507T163535Z3ac5` close-out + this iteration's plan-doc commit). Pytest baseline 3976/3976 passing (full suite, `uv run pytest tests/ -q --timeout=120`, 389.97s). No FAILED, no ERROR, no xfail markers needed. 72 warnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py` + aiosqlite `_connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown noise, no behavior change). Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table below) remains unchanged. No Playwright known-fail entries — `journey-06c-settings-billing.spec.ts:44` was permanently closed by the 2026-05-06 UI write-path launch cut (see Resolved section). Iteration scope (3 worktree spawns): Team A MCP correctness (`finlet/mcp/server.py`, `finlet/mcp/auth.py`, `finlet/mcp/tools_portfolio.py`, `finlet/mcp/tools_trading.py`, `tests/mcp/test_mcp_auth.py`, `tests/mcp/test_mcp_server.py` — audit findings C2/C3/H7); Team B CLI envelope (`finlet/cli.py`, `finlet/api/routes_auth_credentials.py`, `finlet/api/app.py`, `tests/test_cli.py` — audit findings C4/H8/H12); Team C benchmark log redaction (`finlet/leaderboard/runner.py`, `finlet/mcp/tools_benchmark.py`, `finlet/core/session.py` — audit findings H9). No xfail markers added — full suite is green.

> Last updated: 2026-05-07 by pre-flight check (bug-hunt `20260507T163535Z3ac5`) — main HEAD = `23505f4` (post ui-removal-launch-cut close-out + skill-eval-results commit). Pytest baseline 3976/3976 passing (full suite, `uv run pytest tests/ -q --timeout=120 -p no:cacheprovider`, 388.64s). No FAILED, no ERROR, no xfail markers needed. 71 warnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py` + aiosqlite `_connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown noise, no behavior change). Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table below) remains unchanged. No Playwright known-fail entries — `journey-06c-settings-billing.spec.ts:44` was permanently closed by the 2026-05-06 UI write-path launch cut (see Resolved section). Iteration scope per `docs/bug-hunt/20260507T163535Z3ac5/plan.md`: Team A dashboard copy fixes (`dashboard/api-keys.html`, `dashboard/api-keys.js`, `dashboard/agent-guide.html`, `dashboard/index.html`, `dashboard/setup.html` — replace `finlet auth register` with `finlet register` + setup.html post-signup-key-reveal copy fix); Team B session-creation modal default name (`dashboard/app.js`, `dashboard/index.html`, `tests/e2e/journey-04-dashboard.spec.ts`); Team C plugin permanent-degraded honest-copy (`finlet/plugins/news_plugin.py`, `finlet/plugins/sentiment_plugin.py`, `tests/plugins/test_news_plugin.py`, `tests/plugins/test_sentiment_plugin.py`); Team D favicon (`dashboard/favicon.ico` NEW or `finlet/api/app.py` redirect); Team F docs sync.
>
> Last updated: 2026-05-07 by pre-flight check (ui-removal-launch-cut) — main HEAD = `b3bc368` (post bug-hunt `20260507T042257Z3c76` close-out + aria-label-mismatch refactor docs/eval). Pytest baseline 3974/3974 passing (full suite, `uv run pytest tests/ -q --timeout=120 -p no:cacheprovider --ignore=tests/e2e`, 383.35s). No FAILED, no ERROR, no xfail markers needed. 83 warnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup + aiosqlite connection-worker thread "Event loop is closed" cleanup; pre-existing async-teardown noise, no behavior change). Pre-existing Playwright known-fail (`journey-06c-settings-billing.spec.ts:44` — "settings API key create and revoke flow") and Hypothesis portfolio-rounding flake remain unchanged — both are out of pytest gating scope. Iteration scope per `docs/refactor/ui-cut/plan.md`: 14 CUT dashboard files (trade-ticket.js, onboarding.{js,css}, settings.{html,css}, billing.{html,js,css}, pricing.html, marketplace.{html,js,css}, dialog-state-mirror.js, form-dirty-tracker.js), 5 TRIM dashboard files (app.js, index.html, settings.js, leaderboard-submit.js, modal-controller.js), event-contract.md prune, 9 CUT e2e tests (journey-{05-trade,06a-settings-profile,06b-settings-plugins,06c-settings-billing,06d-settings-danger-zone,08-billing,12-forgot-password,onboarding,modal-stacking}.spec.ts), CI guards, docs sweep. No Python touched in product paths (Team H optional API-route audit; Teams E-G touch tests/, scripts/, .github/, docs/).

> Last updated: 2026-05-06 by pre-flight check (bug-hunt `20260506T185234Z542e`) — main HEAD = `a851358` (post bug-hunt `20260506T154910Z0b41` close-out). Pytest baseline 3980/3980 passing (full suite, `uv run pytest tests/ -q --timeout=120`, 365.96s). No FAILED, no ERROR, no xfail markers needed. 72 RuntimeWarnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py` + 1 aiosqlite event-loop-closed in test teardown; pre-existing async-teardown noise, no behavior change). Pre-existing Playwright known-fail file path updated: `journey-06-settings.spec.ts:714` → `journey-06c-settings-billing.spec.ts:44` (the file was split into 4 surfaces in commit `96a5849` — see Known Failures table); test name unchanged ("settings API key create and revoke flow"). Hypothesis portfolio-rounding flake unchanged. Both Playwright entries remain out of pytest gating scope. Iteration scope per plan: `dashboard/app.js`, `dashboard/shared-nav.js`, `dashboard/onboarding.js`, `dashboard/index.html`, `dashboard/event-contract.md`, `docs/decisions/copy-api-key-dead-affordance.md`, plus Playwright extensions in `tests/e2e/journey-04-dashboard.spec.ts`, `tests/e2e/journey-05-trade.spec.ts`, `tests/e2e/journey-onboarding.spec.ts`. No Python touched.

> Last updated: 2026-05-06 by pre-flight check (bug-hunt `20260506T154910Z0b41`) — main HEAD = `4d620b1` (post bug-hunt `20260506T061637Z6594` Phase 5.5 close-out). Pytest baseline 3980/3980 passing (full suite, `uv run pytest tests/ -q --timeout=120 -x`, 362.32s). No FAILED, no ERROR, no xfail markers needed. 71 RuntimeWarnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py`; pre-existing async-teardown noise, no behavior change). Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis portfolio-rounding flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (`dashboard/onboarding.js`), Team D (docs + refactor-queue), and Team E (ledger) worktree spawns. Iteration scope is dashboard-JS + docs only; no Python touched.

> Last updated: 2026-05-06 by pre-flight check (CI/deploy stability reform — `docs/handoffs/2026-05-06-ci-deploy-execution-plan.md`) — main HEAD = `bee289c` (post `b458041` audit handoff + `bee289c` doc-archive cleanup commit). Pytest baseline 3974/3974 passing (full suite, `pytest tests/ -q --timeout=120 --tb=line --ignore=tests/e2e`, 353.12s). No FAILED, no ERROR, no xfail markers needed. 77 RuntimeWarnings remain (`aiosqlite._connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown flake in test fixtures, no behavior change). Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis portfolio-rounding flake remain unchanged — both are out of pytest gating scope for this exec-plan's Teams A (deploy-pin), B (smoke-extend), C (pre-push-fix), D (cve-allowlist), E (settings-split) worktree spawns.

> Last updated: 2026-05-05 by pre-flight check (bug-hunt `20260505T234713Z0c8a`) — main HEAD = `84074be` (post bug-hunt `20260505T213116Z45f1` close-out). Pytest baseline 3974/3974 passing (full suite, `uv run pytest tests/ -q --timeout=120 --tb=no --ignore=tests/e2e`, 344.54s). No FAILED, no ERROR, no xfail markers needed. 73 RuntimeWarnings remain (`aiosqlite._connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown flake in test fixtures, no behavior change). Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis portfolio-rounding flake remain unchanged — both are out of pytest gating scope for this iteration's dashboard worktree spawns (`dashboard/settings.js`, `dashboard/onboarding.js`, `dashboard/app.js`, `dashboard/index.html`).

> Last updated: 2026-05-05 (post-merge close-out) — bug-hunt `20260505T213116Z45f1` Teams A/B/C/D merged to main; **no entries removed this iteration** (no pre-existing failure in this file was resolved by the four shipped fixes — Team A `dashboard/app.js`, Team B `dashboard/modal-controller.js` + `dashboard/styles.css`, Team C `dashboard/trade-ticket.js`, Team D `dashboard/settings.js` — and no new Python failures introduced; the pre-existing `journey-06-settings.spec.ts:714` Playwright known-fail and Hypothesis portfolio-rounding flake remain unchanged). Pytest baseline preserved (3974/3974 passing per pre-flight refresh below).

> Last updated: 2026-05-05 by pre-flight check (bug-hunt `20260505T213116Z45f1`) — main HEAD = `bdeb62d` (post stat-card-overflow-contract refactor close-out). Pytest baseline 3974/3974 passing (full suite, `uv run pytest tests/ -q --timeout=120 --tb=short --ignore=tests/e2e`, 341.64s). No FAILED, no ERROR, no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (Order Log fee disclosure in `dashboard/app.js`), Team B (modal-controller hide non-top stack members in `dashboard/modal-controller.js` + `dashboard/styles.css`), Team C (trade-ticket close panel-class removal in `dashboard/trade-ticket.js`), and Team D (testPlugin DOM update in `dashboard/settings.js`) worktree spawns. 74 RuntimeWarnings remain (`aiosqlite._connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown flake in test fixtures, no behavior change).

> Last updated: 2026-05-05 by pre-flight check (refactor `stat-card-overflow-contract`) — main HEAD = `98aced6` (post Phase 5.5 retest artifacts for bug-hunt `20260505T175445Z750b`). Pytest baseline 3974/3974 passing (full suite, `uv run pytest tests/ -q --timeout=120 --ignore=tests/e2e`, 342.37s). No FAILED, no ERROR, no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (CSS contract: stat-card grid + tile overflow guards in `dashboard/styles.css` + `dashboard/index.html`) and Team B (docs: `docs/ARCHITECTURE.md` stat-card invariant + `docs/decisions/stat-card-overflow-contract.md` + `docs/LESSONS.md` entry) worktree spawns. Playwright tests skipped in pytest run; Team A's `tests/e2e/journey-sim-time-tile.spec.ts` extension will be exercised via `npx playwright test` in per-team validation.

> Last updated: 2026-05-05 (post-merge close-out) — bug-hunt `20260505T175445Z750b` outcome: 2 fixes merged (Team B + Team C), 1 demoted (Team A). Pre-flight pytest baseline 3974/3974 passing (recorded by the prior iteration's pre-flight refresh under `convention-enforcement-2026-05-05`); this iteration added zero Python tests (Team B added one Playwright regression to `tests/e2e/journey-04-dashboard.spec.ts`; Team C added one Playwright case to `tests/e2e/journey-sim-time-tile.spec.ts`; Team A shipped no code), so the Python pytest baseline is preserved at 3974/3974. Team A (commit `545e1de`) is verify-only — no code modified. Team B (commit `edc5ce7`, merge `548eac3`) is dashboard-JS + Playwright only — `dashboard/app.js` (hidden-anchor LineSeries on equity chart) + `tests/e2e/journey-04-dashboard.spec.ts` (`equity curve Y-axis spans meaningful range with low-variance data` regression); 10/10 journey-04 pass including the pre-existing buffered-history-replay regression. Team C (commit `125f2b2`, merge `f1d6581`) is dashboard-JS + dashboard-HTML + Playwright only — `dashboard/app.js` (`renderClock()` writes `formatDateShort` to `#sim-time` + sets `title=` to `formatDateTime`), `dashboard/index.html` (line 174 gains initial `title="--"`), `tests/e2e/journey-sim-time-tile.spec.ts` (3/3 pass with new date-only + title= contract); `dashboard/styles.css` UNCHANGED. No new pytest failures introduced this iteration; no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged.

> Last updated: 2026-05-05 (post-merge close-out) — bug-hunt `20260505T142400Z3330` Teams A/B/E merged to main + Phase 5.5 retest passed on deploy SHA `95d6562`. Team A (commit `b5dc82f`, merge `30a1d9c`) is dashboard-JS only — `dashboard/app.js` (`pnlArrow`/`pnlClass`/`formatPct` rounded-then-classify + Max Drawdown re-routed through helpers) and `tests/e2e/journey-05-trade.spec.ts` (post-fill no-arrow / no-`-0.00` / no-`pnl-negative` assertion); no Python touched. Team B (commit `f7d932a`, merge `c1edc8c`) is dashboard-JS only — `dashboard/app.js` (`formatLatency` helper, 5 explicit branches, short-circuit `null` for non-finite) and `tests/e2e/journey-04-dashboard.spec.ts` (canonical-format-set assertion); no Python touched. Team E (merge `548ddb4`) is ledger-only; +2 lines on `docs/bug-hunt/ledger.jsonl`. Three e2e fix-forwards landed post-deploy (`0e1e35b` first-text-node read, `47cd784` drop value-pinning + stub SSE, `95d6562` drop SSE stub — cards render via real SSE) — none touch product code. No new pytest failures introduced this iteration; no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged. Pytest baseline preserved.

> Last updated: 2026-05-05 by pre-flight check (refactor `convention-enforcement-2026-05-05`) — main HEAD = `4264779` (post pre-flight commit of plan + exec-trace + refactor-queue doc on top of `d159572` benchmark-blindness invariant docs). Pytest baseline 3974/3974 passing (full suite, `uv run pytest tests/ -q --timeout=120 --tb=no --ignore=tests/e2e`, 349.43s). No FAILED, no ERROR, no xfail markers needed. 88 RuntimeWarnings remain (`aiosqlite._connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown flake in test fixtures, no behavior change). Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (event-bus enforcement lint), Team B (form-dirty-tracker registry rollout), and Team C (onboarding registry rollout) worktree spawns.

> Last updated: 2026-05-04 by pre-flight check (bug-hunt `20260504T165106Z1ab2`) — main HEAD = `9c3843e` (post `0b33271` ci pre-push smoke + `d30e51a` settings.js backtick escape). Pytest baseline 3969/3969 passing (full suite, `uv run pytest tests/ -q --timeout=120`, 319.28s). No FAILED, no ERROR, no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (leaderboard schema/UI) + Team B (CLI session-create idempotency reorder) worktree spawns.

> Last updated: 2026-05-03 (post-merge close-out) — bug-hunt `20260503T195318Z43db` Teams A/B merged to main. Team A (commit `4c4e7da`, fix `713e3d5`) added `GET /v1/sessions/{id}/orders` + `GET /v1/sessions/{id}/orders/{oid}` aliases in `finlet/api/routes_session.py` plus `tests/api/test_orders.py` (7 new tests, all pass). Team B (commit `0baa8d5`, fix `056b417`) is dashboard-JS only — `dashboard/shared-nav.js` modified for the cookie-session-path redirect + dynamic relabel; the mobile drawer button inherits via existing `.click()` proxy in `dashboard/mobile-nav.js`; no Python touched; trusted-types lint passed. No new pytest failures introduced this iteration; no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged. Pytest baseline preserved.

> Last updated: 2026-05-03 by pre-flight check (bug-hunt `20260503T195318Z43db`) — main HEAD = `3420145` (Phase 5.5 retest close-out for prior iteration `20260503T030227Z2009`). Pytest baseline 3949/3949 passing (full suite, `uv run pytest tests/ -q --timeout=120 -x --ignore=tests/e2e`, 308.90s). No FAILED, no ERROR, no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (server-side route alias) + Team B (dashboard click-handler) worktree spawns.

> Last updated: 2026-05-03 by pre-flight check (bug-hunt `20260503T030227Z2009`) — main HEAD = `7cda296` (Team B merge close-out). Pytest baseline 3955/3955 passing (full suite, `uv run pytest tests/ -q --timeout=120`). No FAILED, no ERROR, no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's dashboard-only worktree spawns.

> No new failures introduced by bug-hunt `20260503T030227Z2009` (Teams A/B). Team A (trade-ticket render-on-read v3.1 terminal `repaintCash()` at every publisher site, commit `8c55a90`) is dashboard-JS only — `dashboard/trade-ticket.js` + `dashboard/app.js` modified plus extension to `tests/dashboard/trade-ticket-post-submit.spec.js` (node `--test`); the v3 atomic-mutate-then-publish contract is preserved (terminal `repaintCash()` is appended after publish at all 3 publisher sites); no Python touched; trusted-types lint passed; 7/7 trade-ticket-post-submit + 71/71 full dashboard test suite pass. Team B (Settings Ingest refetch gate-on-server-state-change, commit `cbd8340`) is dashboard-JS + Playwright only — `dashboard/settings.js` modified plus extension to `tests/e2e/journey-06-settings.spec.ts`; the `_pluginNeedsIngest()` predicate is unchanged (gate logic is purely additive — snapshot pre-click `[data-plugin-message]` text, recursive poll capped at 30 ticks, refetch when text drifts or cap reached); no Python touched; 27/27 journey-06-settings tests pass. The pre-existing journey-06-settings:714 known-fail entry remains the sole Playwright known-fail and is unchanged this iteration. Pytest baseline preserved.

> No new failures introduced by bug-hunt `20260502T211937Z7ddd` (Teams A/B). Team A (Settings Ingest button row-level pending state, commit `c489d53`) is dashboard-JS + dashboard-CSS only — `dashboard/settings.js` + `dashboard/settings.css` modified; the existing `loadPlugins()` render contract is preserved (transient `apiFetch` null preserves render); no Python touched; trusted-types lint passed. Team B (dashboard plugin-health widget default-status alignment, commit `4837c7f`) is dashboard-JS + dashboard-CSS only — `dashboard/app.js` + `dashboard/styles.css` modified; the canonical `GET /v1/plugins/health` endpoint contract is unchanged; one-line default-value swap at `dashboard/app.js:2212` aligns with `dashboard/settings.js:1040` ('unknown' instead of 'healthy'); no Python touched; trusted-types lint passed. The pre-existing journey-06-settings:714 known-fail entry remains the sole Playwright known-fail and is unchanged this iteration. Pytest baseline preserved.

> No new failures introduced by bug-hunt `20260502T142726Z7b36` (Teams A/B/C). Team A (Trade Ticket post-submit refetch+republish, commit `109686c`) is dashboard-JS + Playwright only — added `tests/dashboard/trade-ticket-post-submit.spec.js` (node `--test`) and extended `tests/e2e/journey-05-trade.spec.ts`; no Python touched. Team B (probe-message sanitization across price/news/fundamentals plugins + new `POST /v1/plugins/{name}/ingest` stub at `finlet/api/routes_plugins.py`, commit `ad0adb0`) added new test file `tests/api/test_plugins_ingest.py` covering the 202+job_id path and 404-for-unknown-plugin path, plus extensions to `tests/api/test_plugin_health.py` and `tests/plugins/test_price_plugin.py` for the sanitized error wording; the existing `routes_health._check_price_data_status` translator continues to map `"S3 unreachable"` → `s3_unreachable` (pinned wording is part of the response contract). Team C (Settings consume canonical `/v1/plugins/health` + Ingest button, commit `2d200db`) is dashboard-JS/HTML/CSS only — extended `tests/e2e/journey-06-settings.spec.ts` with the new Ingest-button affordance assertion; no Python touched. Pytest baseline preserved.

> No new failures introduced by refactor `close-patch-ineffective-2026-05-02` (Teams A/B/C). Team A (plugins remove CLI + email validator empty-string clear, commit `6c72541`) added 4 new `TestPluginsRemoveCommand` tests + 1 new `TestPlugins.test_update_plugin_clears_credentials_with_empty_strings` — 19/19 in the targeted gate; ruff + mypy pass. Team B (onboarding.js:382-385 profile reach-in deletion, commit `076189c`) is dashboard-JS only — added 3 new tests in `tests/dashboard/onboarding-checklist.spec.js` (23/23 pass). Team C (settings.css unsaved-banner display:none switch, commit `e4cdb5e`) is dashboard CSS/HTML/JSDoc only — form-dirty-tracker unit tests 6/6 still pass; new Playwright spec at `tests/playwright/settings-dirty-banner.spec.js` NOT auto-discovered by the existing `tests/e2e/playwright.config.ts` (`testDir: '.'`); session-checkpoint Phase 5.5 retest envelope will exercise live-site cold-load. Pytest baseline preserved.

> No new failures introduced by bug-hunt `20260501T234103Z1a49` (Teams A/B/C/D/E). Team A (engine equity-curve snapshot-on-fill, commit `29e9ac5`) added 3 new tests in `tests/core/test_session.py` + `tests/api/test_portfolio.py`; existing 3902 pytest baseline preserved. Team B (dashboard SSE republish portfolio:updated, commit `3a2bf46`) is dashboard-JS + Playwright only; new assertion in `tests/e2e/journey-05-trade.spec.ts`. Team C (settings dirty-banner aria-hidden sync + synthetic-key gate, commit `87a37b6`) is dashboard only; new cold-load Playwright test in `tests/e2e/journey-06-settings.spec.ts`. Team D (onboarding `profile:saved` outcome event, commit `4924948`) is dashboard-JS only; new tests in `tests/dashboard/onboarding-checklist.spec.js`. Team E (price plugin S3-reachability probe + 60s probe cache, commit `76f4724`) added 3 new tests in `tests/api/test_plugin_health.py` + `tests/plugins/test_price_plugin.py`. Pytest baseline preserved.

> No new failures introduced by bug-hunt `20260501T172055Z127b` (Teams A/B). Team A (EDGAR plugin hot-reload + actionable CLI message, commit `1a07a1e`) added 4 new tests in `tests/test_cli.py::TestPluginsAddCommand` and 3 new tests in `tests/api/test_plugin_health.py::TestPluginReload`; full plugin/registry suite 756/756 + combined CLI+plugin-health spot 61/61 passed. Team B (settings password-form wrap, commit `ce5fa52`) is dashboard-HTML/JS only — `dashboard/settings.html` + `dashboard/settings.js` were edited; trusted-types lint passed; dashboard pytest selection 5/5 passed. Findings 1 (portfolio AttributeError) and 4 (plugins list mismatch) shipped no code change this iteration — both are pypi-release-lag artifacts (already fixed in main at `cc6cddf` and `1a3c17e`); see `docs/decisions/pypi-release-cadence.md`. Pytest baseline preserved.

> No new failures introduced by bug-hunt `20260430T222711Z3666` (Teams A/B/C/D). Team A (auth `_OptionalUser` cookie-fall-through, commit `47c7e79`) updated 2 existing tests in `tests/api/test_session_auth.py` to match the new contract (validate-probe stale-cookie returns anonymous, not 401) and extended `tests/auth/test_session_validate_probe.py` with parity coverage. Team B (CLI idempotency + plugins-list parity, commit `1616ade`) added 4 new tests in `tests/test_cli.py`; spot-check across 86 adjacent API tests (sessions/idempotency/plugin-health) passed. Team C (form-dirty-tracker pre-clear, commit `dba4c83`) is dashboard-JS only — Test 6 in `tests/dashboard/form-dirty-tracker.spec.js` reproduces the bug without the fix and passes with it. Team D (selectSession publish, commit `91922c7`) added 2 tests in `tests/dashboard/onboarding-checklist.spec.js`; node `--test` 17/17 + sibling 30/30; pytest spot-check on idempotency/e2e session 10/10. Pytest baseline preserved.

> No new failures introduced by the trusted-types refactor. Pytest baseline (3902/3902 passing) preserved through the merge. The refactor scope (lint script + dashboard `*.html` files + `api-utils.js` reporter + Playwright telemetry spec) does not touch Python — pytest count is stable.

Python suite: 0 failures out of 3902 tests (full suite, `uv run pytest tests/ -q --timeout=120 --ignore=tests/e2e`, 569.62s). Pre-flight verified 2026-04-30 ahead of trusted-types refactor exec-plan; post-merge baseline preserved. Pre-flight base SHA: `5a579a7` (main HEAD = `plan: trusted-types refactor`). No new pytest failures, no xfail markers needed. 60 RuntimeWarnings remain (auth service AsyncMock cleanup; pre-existing, no behavior change).

Playwright `journey-06c-settings-billing.spec.ts:44` ("settings API key create and revoke flow"): closed by the 2026-05-06 UI write-path launch cut. The test (and all four `journey-06{a,b,c,d}-settings-*.spec.ts` surfaces) covered `dashboard/settings.html`, which was cut to `legacy/dashboard-ui/settings.html` and `legacy/tests/e2e/journey-06{a,b,c,d}-*.spec.ts` on 2026-05-06. The flaky modal-stacking interaction is no longer in production scope — `dashboard/api-keys.html` (the read-only replacement) does not host a create-key form. If the legacy spec is ever revived for restoration smoke tests, run via `tests/e2e/legacy.playwright.config.ts`.

## Known Failures (xfailed)

| Test | File | Reason | Since |
|------|------|--------|-------|
| test_e2e_authcode_flow_against_live_fastapi_app | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-09 |
| test_authorize_without_login_redirects_to_login_with_next | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-09 |
| test_authorize_with_bearer_runs_existing_flow | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-14 |
| test_authorize_with_session_cookie_runs_existing_flow | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-14 |
| test_token_endpoint_unsupported_grant_type | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-09 |
| test_token_endpoint_emits_no_deprecation_headers | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-09 |
| test_create_session_with_readonly_jwt_returns_insufficient_scope | `tests/mcp/test_scope_enforcement.py` | StreamableHTTPSessionManager singleton conflict with sibling MCP-HTTP tests in the same process (test_http_endpoint / test_oauth_dual_accept). Test passes deterministically in isolation. The session-manager is process-global by design in mcp[auth] 1.27.0; running two `create_app()` calls in one process re-invokes `.run()` which raises RuntimeError. Marked xfail strict=False — sibling unit tests provide load-bearing scope coverage. | 2026-05-21 |

## Known Flakes

| Test | File | Reason | Since |
|------|------|--------|-------|
| Hypothesis portfolio rounding properties | `tests/core/test_property_based.py` | Hypothesis occasionally generates extreme float sequences that expose sub-penny rounding drift after many buy/sell cycles. Cash rounding to 2dp (commit aa451d9) mitigates but does not eliminate all edge cases under property-based fuzzing. Flake rate is very low (<1% of runs). | 2026-03-29 |

## Resolved

`tests/e2e/journey-06-settings.spec.ts:289` — settings API key create and revoke flow. `dashboard/settings.html` migrated to the post-modal-stacking `class="modal-overlay fl-modal"` + `data-modal-id` convention, with `openModal/closeModal` in `settings.js` now thin wrappers around `window.finletModal.open/close`. Two collateral fixes shipped in the same merge: dirty-state tracker now skips inputs inside `.modal-overlay` (the Create-Key modal name field was triggering the unsaved-changes banner), and the journey-06 submit-button fallback selector was scoped to `#create-key-modal`. 16/16 settings tests now passed (commit `b3cb2f1`, fix `ac8e0b2`) at the time. Resolved 2026-04-28. **Note 2026-04-29:** regression resurfaced (line `:444` after additions). **Note 2026-05-06:** entry permanently closed by UI write-path launch cut — `dashboard/settings.html` and the `journey-06{a,b,c,d}-settings-*.spec.ts` surfaces were git-mv'd to `legacy/dashboard-ui/` and `legacy/tests/e2e/`. The create-key modal is no longer hosted in production; production `dashboard/api-keys.html` is read-only.

CLI smoke tests in `tests/e2e/journey-14-cli-session.spec.ts` (5 tests) and `tests/e2e/journey-15-cli-plugins.spec.ts` (7 tests) -- The specs invoked a bare `finlet` binary via `execSync`, which only resolves when `.venv/bin/` is on the spawn PATH; full-suite Playwright runs without venv-activated PATH all failed at the `Command failed: finlet ...` step. Switched the invocation to `uv run python -m finlet`, centralised behind a `FINLET_CLI` constant in `tests/e2e/helpers.ts`. `uv run` resolves the project venv from `pyproject.toml` / `uv.lock` independent of PATH state, and `python -m finlet` invokes the package's `__main__` module with identical behaviour to the binary. All 12 tests now pass (verified via `npx playwright test tests/e2e/journey-14-cli-session.spec.ts tests/e2e/journey-15-cli-plugins.spec.ts --reporter=line`). Fixed in commit `38f9726`. Resolved as of 2026-04-28.

FIELD_AUDIT_FIXES sprint (2026-04-10): Per-ticker circuit breaker scoping (Team A), position price history fallback under open breakers (Team B), percentage-scale portfolio metrics (Team C), batch time advance in CLI and MCP (Team D), `GET /market/tickers` + `list_available_tickers` MCP tool (Team E), fundamentals cache TTL invalidation + atomic S3 downloads (Team F), setup page consolidation (Team G). All fixed; +33 new tests shipped (3522 -> 3555 total).

User Feedback Fixes sprint (2026-04-09): Circuit breaker state bleeding between sessions (Team A), MARKET orders silently queuing as PENDING when price plugin errored (Team B), CLI `portfolio` command crashing on dict iteration (Team C), `_query_history()` silently returning empty on no data (Team D). All fixed; new tests added.

E2E Playwright failures in `journey-04-dashboard.spec.ts` and `journey-08-billing.spec.ts` -- Stale assertions referencing marketplace nav and hidden billing tiers that were removed in commit `451af35`. Fixed by removing the stale assertions (commit `e30a830`). Resolved as of 2026-04-06.

`ModuleNotFoundError: finlet.api` on production server -- `[tool.hatch.build.targets.wheel]` in `pyproject.toml` had an `only-include` whitelist that excluded all subpackages (`api/`, `core/`, `plugins/`, etc.). The server installed the wheel via `pip install -e .` and got only the three thin-client files. Fixed by removing the `only-include` section entirely (commit `1d4b247`). See `docs/decisions/remove-hatch-wheel-whitelist.md`. Resolved as of 2026-04-06.

`test_get_session_found` (`tests/mcp/test_mcp_server.py`) -- Previously failed due to stale `finlet.mcp.auth` module reference. Now passes. Resolved as of 2026-04-02.

`test_different_user_agent_triggers_warning`, `test_different_ip_triggers_warning`, `test_both_ip_and_ua_change_triggers_two_warnings` (`tests/api/test_session_fingerprint.py`) -- Previously xfail due to structlog `capture_logs()` not intercepting warnings. Now pass; xfail markers removed. Resolved as of 2026-04-02.

`test_value_equation_after_buy_sell` (`tests/core/test_property_based.py:81`) -- Floating-point comparison bug where `cost > self._cash` rejected orders when cost == cash. Fixed with epsilon tolerance (commits 5bb8e67, b0f53e2).

The 14 `tests/leaderboard/test_api_driven_strategy.py` failures (`KeyError: 'benchmark_price'`) were caused by `BenchmarkPricePlugin` not being registered in `PluginRegistry` circuit breakers. Fixed by handling plugins without circuit breaker registration in `query_plugin()` (commit c7a7687).

exec
/bin/zsh -lc "nl -ba finlet/cli.py | sed -n '240,310p;1038,1142p'" in /Users/justnau/finlet
 succeeded in 0ms:
   240	
   241	    Typer requires a callback on the root ``Typer()`` app to surface
   242	    top-level options.  This callback intentionally does nothing else;
   243	    real work is delegated to subcommands.
   244	    """
   245	
   246	
   247	plugins_app = typer.Typer(help="Plugin management. See: finlet manual plugin-matrix")
   248	auth_app = typer.Typer(help="Authentication commands. See: finlet manual auth-model")
   249	mcp_app = typer.Typer(help="MCP server commands")
   250	app.add_typer(plugins_app, name="plugins")
   251	app.add_typer(auth_app, name="auth")
   252	app.add_typer(mcp_app, name="mcp")
   253	
   254	
   255	# ── serve ────────────────────────────────────────────────────
   256	
   257	
   258	@app.command()
   259	def serve(
   260	    host: str = typer.Option("0.0.0.0", envvar="FINLET_HOST", help="Bind address"),
   261	    port: int = typer.Option(8000, envvar="FINLET_PORT", help="Port number"),
   262	    reload: bool = typer.Option(False, help="Enable auto-reload for development"),
   263	) -> None:
   264	    """Start the API server and serve the dashboard.
   265	
   266	    Boots uvicorn against ``finlet.api.app:create_app`` (factory mode)
   267	    on ``$FINLET_HOST:$FINLET_PORT`` — defaults to ``0.0.0.0:8000``.
   268	    The dashboard SPA mounts under ``/`` and the REST + MCP HTTP
   269	    surfaces under ``/v1/...`` + ``/mcp``. ``--reload`` is dev-only.
   270	
   271	    Examples:
   272	      finlet serve
   273	      finlet serve --port 9000 --reload
   274	
   275	    See: finlet manual transports
   276	    """
   277	    try:
   278	        import uvicorn
   279	    except ImportError:
   280	        typer.echo("Error: Server mode requires the full Finlet installation.", err=True)
   281	        typer.echo("Install with: pip install finlet[server]", err=True)
   282	        raise typer.Exit(1)
   283	
   284	    uvicorn.run(
   285	        "finlet.api.app:create_app",
   286	        factory=True,
   287	        host=host,
   288	        port=port,
   289	        reload=reload,
   290	    )
   291	
   292	
   293	# REMOVED in v2.0.0: session sub-app + benchmark sub-app.
   294	# Agents call the MCP tools (create_session / list_sessions /
   295	# delete_session / set_session_visibility / start_benchmark /
   296	# get_benchmark_progress / decrypt_benchmark_run /
   297	# set_benchmark_visibility) directly through their MCP client.
   298	# See `finlet manual quickstart`.
   299	
   300	
   301	# ── plugins ──────────────────────────────────────────────────
   302	
   303	
   304	_MISSING_API_KEY_MESSAGE = (
   305	    "Error: FINLET_API_KEY is not set. The Finlet server requires an "
   306	    "authenticated key to write plugin config. Set it with: "
   307	    "export FINLET_API_KEY=fk_... (regenerate from the dashboard if lost)."
   308	)
   309	_AUTH_REJECTED_MESSAGE = (
   310	    "Error: FINLET_API_KEY rejected — check `finlet auth login` or "
  1038	    if expires_at <= now:
  1039	        typer.echo("Token expired. Run `finlet auth login`.")
  1040	        raise typer.Exit(EXIT_AUTH_REQUIRED)
  1041	
  1042	    remaining_seconds = expires_at - now
  1043	    remaining_minutes = remaining_seconds // 60
  1044	    typer.echo(f"Logged in. Token expires in {remaining_minutes} minutes.")
  1045	
  1046	
  1047	# REMOVED in v2.0.0: top-level advance / order / portfolio / status.
  1048	# Agents call the MCP tools (advance_time / submit_order / get_portfolio /
  1049	# get_session) directly through their MCP client. See
  1050	# `finlet manual quickstart`.
  1051	
  1052	
  1053	# ── mcp ──────────────────────────────────────────────────────
  1054	
  1055	
  1056	@mcp_app.command("serve")
  1057	def mcp_serve() -> None:
  1058	    """Start MCP server over stdio (for Claude Code / Generic MCP Client).
  1059	
  1060	    Boots a self-host MCP server reading JSONRPC on stdin and writing
  1061	    JSONRPC on stdout.  The subprocess reads ``FINLET_OAUTH_BEARER``
  1062	    (preferred — ``finlet auth login`` mints a JWT; matches the
  1063	    post-Phase-4e Claude Desktop and Generic MCP Client configs) from
  1064	    its environment to authenticate tool calls.  ``FINLET_API_KEY`` is
  1065	    accepted as a fallback for CI / headless environments — the stdio
  1066	    bridge translates the api_key internally to the MCP HTTP surface.
  1067	
  1068	    Boot sequence:
  1069	
  1070	    1. ``configure_logging()`` FIRST — installs the stdlib ``StreamHandler``
  1071	       on ``sys.stderr`` and wires structlog through it.  Anything the
  1072	       subprocess writes to stdout pollutes the JSONRPC framing the client
  1073	       reads on the same pipe (the client's :func:`stdio_client` reader
  1074	       parses every stdout line as JSONRPC and emits a
  1075	       ``Failed to parse JSONRPC message from server`` + pydantic
  1076	       ``ValidationError`` traceback on the user's terminal when a line is
  1077	       not valid JSON).  Default structlog has no configuration and uses a
  1078	       ``PrintLoggerFactory`` writing to ``sys.stdout`` — every
  1079	       ``logger.info(...)`` / ``logger.warning(...)`` call site in
  1080	       :mod:`finlet.mcp.server`, :mod:`finlet.auth.service`, and the
  1081	       transitive import graph would corrupt the JSONRPC stream during a
  1082	       real tool call.  Calling :func:`configure_logging` here BEFORE the
  1083	       :mod:`finlet.mcp.server` import (and therefore before any
  1084	       module-top ``structlog.get_logger()`` binding is first used) routes
  1085	       all structured logs through stdlib to stderr, leaving stdout
  1086	       exclusively for FastMCP's JSONRPC writer.
  1087	    2. Load the in-memory ``auth_service`` cache from the SQLite
  1088	       ``auth.db``.  The cache is the source of truth
  1089	       ``finlet/mcp/auth.py:_authenticate_oauth_or_key`` consults to map a
  1090	       JWT ``sub`` claim to a ``UserRecord``; without it, the validator's
  1091	       ``get_by_id`` would always miss in this fresh-process subprocess and
  1092	       the tool would return the documented "Authentication required"
  1093	       envelope on every call.
  1094	    3. Hand stdout to FastMCP via ``mcp_server.run(transport="stdio")``.
  1095	
  1096	    The FastAPI app boots this same cache via its lifespan handler;
  1097	    stdio mode skips the lifespan, so the CLI's MCP entry point owns
  1098	    it.
  1099	
  1100	    Examples:
  1101	      finlet mcp serve
  1102	
  1103	    See: finlet manual transports
  1104	    """
  1105	    # STEP 1: configure logging BEFORE importing finlet.mcp.server.  The
  1106	    # server import binds ``logger = structlog.get_logger()`` at module
  1107	    # top (finlet/mcp/server.py:77) and transitively re-binds the same
  1108	    # in dozens of other modules (finlet/auth/service.py, finlet/core/*,
  1109	    # etc.).  ``structlog.configure(..., cache_logger_on_first_use=True)``
  1110	    # snapshots the wrapper on first use, so we MUST configure before any
  1111	    # of those bindings is exercised.
  1112	    try:
  1113	        from finlet.logging import configure_logging
  1114	    except ImportError:
  1115	        typer.echo("Error: Local MCP server requires the full Finlet installation.", err=True)
  1116	        typer.echo("Point your MCP client at https://finlet.dev/mcp instead.", err=True)
  1117	        typer.echo("Install server with: pip install finlet[server]", err=True)
  1118	        raise typer.Exit(1)
  1119	    configure_logging()
  1120	
  1121	    # Defense-in-depth: even if some third-party import bypasses structlog
  1122	    # and prints to stdout directly, the stdio transport STILL expects
  1123	    # JSONRPC there.  We capture the real stdout BEFORE FastMCP grabs
  1124	    # ``sys.stdout.buffer`` and rebind the Python-level ``sys.stdout`` to
  1125	    # ``sys.stderr`` so subsequent ``print()`` calls land on stderr.
  1126	    # FastMCP's ``stdio_server`` reads ``sys.stdout.buffer`` ONCE at run
  1127	    # time — by then ``sys.stdout`` points at stderr, but we restore it
  1128	    # for that single read so JSONRPC writes go to the right pipe.
  1129	    # (See finlet/mcp/server.py docstring; the recon path is
  1130	    # docs/plans/EXECUTION_PLAN_V1_0_0_BLIND_WALK_FIXES.md HIGH #5.)
  1131	    _real_stdout = sys.stdout
  1132	    sys.stdout = sys.stderr
  1133	
  1134	    try:
  1135	        from finlet.mcp.server import mcp as mcp_server
  1136	    except ImportError:
  1137	        typer.echo("Error: Local MCP server requires the full Finlet installation.", err=True)
  1138	        typer.echo("Point your MCP client at https://finlet.dev/mcp instead.", err=True)
  1139	        typer.echo("Install server with: pip install finlet[server]", err=True)
  1140	        raise typer.Exit(1)
  1141	
  1142	    # Hydrate the auth_service cache so JWT ``sub`` → UserRecord lookups

exec
/bin/zsh -lc "git diff main~1..main --name-only | while read f; do printf '%s\\n' \""'$f"; done' in /Users/justnau/finlet
 succeeded in 0ms:
finlet/cli.py
finlet/cli_mcp_client.py

exec
/bin/zsh -lc 'git diff --numstat main~1..main' in /Users/justnau/finlet
 succeeded in 0ms:
41	911	finlet/cli.py
0	237	finlet/cli_mcp_client.py

exec
/bin/zsh -lc 'git grep -n "raise typer.Exit(EXIT_AUTH_REQUIRED)" main -- finlet/cli.py' in /Users/justnau/finlet
 succeeded in 0ms:
main:finlet/cli.py:419:        raise typer.Exit(EXIT_AUTH_REQUIRED)
main:finlet/cli.py:491:        raise typer.Exit(EXIT_AUTH_REQUIRED)
main:finlet/cli.py:1034:        raise typer.Exit(EXIT_AUTH_REQUIRED)
main:finlet/cli.py:1040:        raise typer.Exit(EXIT_AUTH_REQUIRED)

codex
BLOCKER: `plugins_add` / `plugins_remove` were changed despite explicit “leave as-is” scope. Plan line 306 says replacing literal `2` with `EXIT_AUTH_REQUIRED` is beyond v2.0.0 scope; diff does exactly that at [finlet/cli.py](/Users/justnau/finlet/finlet/cli.py:419) and [finlet/cli.py](/Users/justnau/finlet/finlet/cli.py:491). The commit body even advertises the drift: “now used by plugins_add, plugins_remove,” but does not justify overriding the plan.

BLOCKER: module docstring violates the spec’s “NO mention of session/order/portfolio/etc.” requirement. Team prompt line 25 and plan line 303 require the rewritten docstring to describe only the kept v2.0.0 surface, but [finlet/cli.py](/Users/justnau/finlet/finlet/cli.py:3) still names `session`, `order`, `portfolio`, `benchmark`, and `status` in the new docstring. That is plan-claim drift, not just wording.

STRONG-SUGGESTION: commit message underspecifies unrelated behavior changes. The merge subject says delete commands/helpers and rewrite the docstring, but the diff also changes `finlet mcp serve` missing-server fallback text at [finlet/cli.py](/Users/justnau/finlet/finlet/cli.py:1116) and [finlet/cli.py](/Users/justnau/finlet/finlet/cli.py:1138). Maybe harmless, but it is not called out in the merge commit and is outside the requested “delete dead surface” work.

NIT: the diff leaves tombstone comments for deleted command blocks at [finlet/cli.py](/Users/justnau/finlet/finlet/cli.py:293) and [finlet/cli.py](/Users/justnau/finlet/finlet/cli.py:1047). They do not add runtime paths, but this is not really “delete only” cleanup and keeps deleted command names embedded in the CLI module.

Validation notes: changed files are only `finlet/cli.py` and deleted `finlet/cli_mcp_client.py`; `uv run python -c "import finlet.cli; from finlet.cli import app"` passed; `uv run ruff check finlet/cli.py` passed. No high-entropy fixture/secrets found in added lines.

GATE: BLOCK
tokens used
110,541
BLOCKER: `plugins_add` / `plugins_remove` were changed despite explicit “leave as-is” scope. Plan line 306 says replacing literal `2` with `EXIT_AUTH_REQUIRED` is beyond v2.0.0 scope; diff does exactly that at [finlet/cli.py](/Users/justnau/finlet/finlet/cli.py:419) and [finlet/cli.py](/Users/justnau/finlet/finlet/cli.py:491). The commit body even advertises the drift: “now used by plugins_add, plugins_remove,” but does not justify overriding the plan.

BLOCKER: module docstring violates the spec’s “NO mention of session/order/portfolio/etc.” requirement. Team prompt line 25 and plan line 303 require the rewritten docstring to describe only the kept v2.0.0 surface, but [finlet/cli.py](/Users/justnau/finlet/finlet/cli.py:3) still names `session`, `order`, `portfolio`, `benchmark`, and `status` in the new docstring. That is plan-claim drift, not just wording.

STRONG-SUGGESTION: commit message underspecifies unrelated behavior changes. The merge subject says delete commands/helpers and rewrite the docstring, but the diff also changes `finlet mcp serve` missing-server fallback text at [finlet/cli.py](/Users/justnau/finlet/finlet/cli.py:1116) and [finlet/cli.py](/Users/justnau/finlet/finlet/cli.py:1138). Maybe harmless, but it is not called out in the merge commit and is outside the requested “delete dead surface” work.

NIT: the diff leaves tombstone comments for deleted command blocks at [finlet/cli.py](/Users/justnau/finlet/finlet/cli.py:293) and [finlet/cli.py](/Users/justnau/finlet/finlet/cli.py:1047). They do not add runtime paths, but this is not really “delete only” cleanup and keeps deleted command names embedded in the CLI module.

Validation notes: changed files are only `finlet/cli.py` and deleted `finlet/cli_mcp_client.py`; `uv run python -c "import finlet.cli; from finlet.cli import app"` passed; `uv run ruff check finlet/cli.py` passed. No high-entropy fixture/secrets found in added lines.

GATE: BLOCK

---

## Fix-on-main resolution (sha 6244346)

BLOCKER 1 (EXIT_AUTH_REQUIRED in plugins_*) → REVERTED at cli.py:417 + cli.py:489 (literal 2).
BLOCKER 2 (docstring naming dropped commands) → STRIPPED; closing paragraph replaced with pointer at CHANGELOG + docs/decisions/v2-pure-mcp-migration.md.
STRONG-SUGGESTION (mcp serve fallback echo copy change) → NOT REVERTED; logged for final-summary triage.
NIT (tombstone comments at cli.py:293 + cli.py:1047) → LEFT IN PLACE; informative tombstones.
