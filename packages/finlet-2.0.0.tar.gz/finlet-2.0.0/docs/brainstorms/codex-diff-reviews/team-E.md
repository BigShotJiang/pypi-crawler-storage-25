Reading additional input from stdin...
OpenAI Codex v0.128.0 (research preview)
--------
workdir: /Users/justnau/finlet
model: gpt-5.5
provider: openai
approval: never
sandbox: danger-full-access
reasoning effort: xhigh
reasoning summaries: none
session id: 019e5309-dacb-7dd3-ae69-961b61e9890e
--------
user
You are reviewing the diff for ONE team's just-merged commit on a multi-team exec-plan.

Team E's spec is in /Users/justnau/finlet/docs/brainstorms/team-prompts/team-E.md (READ IT FIRST).

The diff to review is the just-merged Team E (CAPSTONE) work at sha e98f637 on /Users/justnau/finlet. Run `git -C /Users/justnau/finlet show e98f637 --stat` for file list, then read individual file diffs as needed.

Attack the diff with these specific lenses:
(a) Scope creep — does the diff touch files NOT in Team E's declared scope (pyproject.toml + CHANGELOG.md ONLY)? Any other file is a BLOCKER.
(b) Version correctness — pyproject.toml line 3 says version = "2.0.0" (not 2.0.1, not v2.0.0, not 1.1.0).
(c) CHANGELOG section ordering — must be [2.0.0] (2026-05-22) → [1.1.0] (2026-05-16) → [1.0.4] → [1.0.3] → [1.0.2] → [1.0.1] → [1.0.0] → [0.1.1]. NO [Unreleased] header anywhere.
(d) [2.0.0] section content — must have:
    - ### Added — session-level blind work (the content folded from [Unreleased])
    - ### Removed — the 12 CLI commands deleted by Team A (session create/list/delete/publish, benchmark start/progress/decrypt/visibility, advance, order, portfolio, status) + cli_mcp_client.py + _dispatch_mcp_tool + helpers
    - ### Changed — CLI surface trim to 6 kept families (serve, register, auth, plugins, mcp, manual)
    - ### Migration notes — pre-launch zero-customer no-deprecation; wire finlet mcp serve into Claude Desktop / Codex CLI / Generic MCP
    - PR references
(e) [1.1.0] section content — must reference USER_MANUAL_OVERHAUL or 'finlet manual' CLI command AND PR #87 (sha 9a88842). Date is 2026-05-16.
(f) Voice/density — matches existing [1.0.0] entry style (terse, technical, PR links).
(g) Build smoke — hatch build would produce a valid wheel? (Check the package config in pyproject.toml hasn't broken.)
(h) Plan-claim drift — does the CHANGELOG accurately reflect what shipped vs what the plan said?

Output BLOCKER / STRONG-SUGGESTION / NIT, sorted by severity. End with 'GATE: PASS' (only STRONG/NIT) or 'GATE: BLOCK' (any BLOCKER).
codex
I’ll use the `review` skill for the code-review framing, and I’m reading Team E’s prompt first as requested before inspecting the commit.
exec
/bin/zsh -lc "sed -n '1,240p' docs/brainstorms/team-prompts/team-E.md" in /Users/justnau/finlet
 succeeded in 0ms:
You are Team E (v2.0.0 Pure-MCP Migration) — CAPSTONE.

**Plan:** `/Users/justnau/finlet/docs/brainstorms/V2_PURE_MCP_EXECUTION_PLAN.md` — read your full spec (lines 628-729).

**Mission:** Version bump + CHANGELOG repair.

**Blocked by:** Teams A, B, C, D — all merged. You are the capstone.

## Read these files first
- `pyproject.toml:1-20` — `[project]` table; current `version = "1.1.0"` at line 3.
- `CHANGELOG.md` FULL FILE — current section ordering: `[1.0.4]` line 8, `[1.0.3]` line 43, `[Unreleased]` line 53 (contents are 2026-05-22 session-level-blind work, NOT 1.1.0 USER_MANUAL_OVERHAUL), `[1.0.2]` line 164, `[1.0.1]` line 174, `[1.0.0]` line 193, `[0.1.1]` line 319.
- `CHANGELOG.md:53-163` — read the FULL `[Unreleased]` body. Step 10b BLOCKER-4 says this is 2026-05-22 session-level-blind content, NOT 2026-05-16 USER_MANUAL_OVERHAUL.
- `.github/workflows/pypi-publish.yml` — Trusted Publishing via OIDC; triggers on `release: published`, `push.tags: ['v*']`, `workflow_dispatch`.
- `docs/REMAINING_TASKS.md` — search for "USER_MANUAL_OVERHAUL" or "1.1.0" or "2026-05-16" to find v1.1.0 contents to author the missing entry.
- Memory `[[project-user-manual-overhaul-shipped]]` — v1.1.0 SHIPPED 2026-05-16 via PR #87 (`9a88842`).
- Memory `[[project-session-level-blind-shipped]]` — session-level blind SHIPPED 2026-05-22 prod sha `27d96ca` PR #134.

## CHANGELOG repair strategy (Step 10b BLOCKER-4)

Final desired ordering (top to bottom):

| Position | Section | Date | Content source |
|---|---|---|---|
| 1 | `[2.0.0]` | 2026-05-22 | (a) Pure-MCP removals from this exec-plan. (b) Session-level-blind work currently misplaced in `[Unreleased]` — fold in. |
| 2 | `[1.1.0]` | 2026-05-16 | NEW entry. USER_MANUAL_OVERHAUL — author from REMAINING_TASKS + memory (PR #87 `9a88842`). |
| 3 | `[1.0.4]` | 2026-05-12 | Existing — keep. |
| 4 | `[1.0.3]` | 2026-05-11 | Existing — keep. |
| 5 | `[1.0.2]` | 2026-05-11 | Existing — keep. |
| 6 | `[1.0.1]` | 2026-05-11 | Existing — keep. |
| 7 | `[1.0.0]` | 2026-05-10 | Existing — keep. |
| 8 | `[0.1.1]` | <prior> | Existing — keep. |

### Steps:
1. **Read** the full body of `[Unreleased]` (lines 53-163). Save the content — it goes into `[2.0.0]`.
2. **Delete** the misplaced `[Unreleased]` header at line 53 along with its contents.
3. **Author `[1.1.0] - 2026-05-16`** by reading `docs/REMAINING_TASKS.md` for USER_MANUAL_OVERHAUL closure references (memory: PR #87 `9a88842`). Sections: `### Added` (manual overhaul, `finlet manual` CLI command), `### Changed` (operator surfacing), `### PR references`.
4. **Author `[2.0.0] - 2026-05-22`** with these groupings:
   - `### Added` — session-level blind work from the saved `[Unreleased]` content.
   - `### Removed` — 12 CLI commands + helpers from this exec-plan (session/list/delete/publish, benchmark/start/progress/decrypt/visibility, advance, order, portfolio, status; finlet/cli_mcp_client.py; _dispatch_mcp_tool + envelope helpers).
   - `### Changed` — CLI surface reduced to MCP-bootstrap minimum (6 command families: serve, register, auth, plugins, mcp serve, manual).
   - `### Migration notes` — agents use MCP; wire `finlet mcp serve` into Claude Desktop / Codex CLI / Generic MCP Client. Zero PyPI consumers per pre-launch context; no deprecation period.
   - `### PR references` — this PR + the session-level-blind PR (#134 if final).
5. **Prepend** `[2.0.0]` at top, then `[1.1.0]` immediately below, then existing `[1.0.4]` through `[0.1.1]` unchanged.

## Files touched
- **Modified `pyproject.toml`** — bump `version = "1.1.0"` → `version = "2.0.0"` at line 3.
- **Modified `CHANGELOG.md`** — execute the repair strategy above.

## Deliverable
Repo at v2.0.0, CHANGELOG ordering clean, ready for tag push.

## Validation
```bash
grep "^version = " pyproject.toml   # version = "2.0.0"
grep -nE "^## \[" CHANGELOG.md   # [2.0.0] → [1.1.0] → [1.0.4] → ... → [0.1.1]
# No [Unreleased] section anywhere
! grep -q "^## \[Unreleased\]" CHANGELOG.md && echo "✓ no Unreleased"
# [2.0.0] has both session-level blind AND CLI removals
grep -A2 "^## \[2.0.0\]" CHANGELOG.md   # shows ### Added (blind) AND ### Removed (12 cmds)
# [1.1.0] has USER_MANUAL_OVERHAUL
grep -A2 "^## \[1.1.0\]" CHANGELOG.md   # shows ### Added mentioning USER_MANUAL_OVERHAUL or `finlet manual` + PR #87
# Build smoke
hatch build   # produces wheel + sdist
unzip -l dist/finlet-2.0.0-*.whl | grep -E "finlet/(cli|mcp|api|core|plugins)"   # key modules present
unzip -l dist/finlet-2.0.0-*.whl | grep "finlet/cli_mcp_client.py"   # NOT present
uv run python -m pip install --force-reinstall dist/finlet-2.0.0-*.whl --target /tmp/test-install   # smoke install
uv run pytest tests/ -x --ignore=tests/e2e --ignore=tests/playwright   # passes (Team B trimmed)
uv run ruff check .   # passes
uv run python -m finlet.manual.generate_llms_txt --check   # exit 0
git status   # ONLY pyproject.toml and CHANGELOG.md modified
```

## Agent instructions
- You MUST `git add pyproject.toml CHANGELOG.md` and `git commit` before finishing.
- Do NOT push the v2.0.0 tag yourself. Tag push is user-driven (final manual step after this PR merges).
- BEFORE editing CHANGELOG.md, READ the full file end-to-end + read `docs/REMAINING_TASKS.md` for USER_MANUAL_OVERHAUL evidence.
- The `[Unreleased]` section is NOT v1.1.0 content. It's 2026-05-22 session-level-blind work. Fold it into `[2.0.0]` alongside the pure-MCP removals (same-day ship).
- Author `[1.1.0]` from independent evidence (REMAINING_TASKS + memory) since there's no existing CHANGELOG entry for it.
- Match CHANGELOG voice/density to existing `## [1.0.0]` entry — terse, technical, with PR # links.
- Verify `hatch build` smoke locally before commit.
- Do NOT modify any other file. NOT finlet/, NOT tests/, NOT docs/, NOT dashboard/, NOT manual/.
- Commit message: `[Team E v2.0.0]: bump 2.0.0 + CHANGELOG repair (add [1.1.0] from manual-overhaul evidence; fold [Unreleased] into [2.0.0])`.

## CRITICAL RULES
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- You MUST `git add` and `git commit` all your changes before finishing.
- Your commit message must start with `[Team E v2.0.0]:`.
- Run the validation commands above before finishing.

When done, report: DONE + commit hash + validation results.
OR: BLOCKED + what went wrong.

codex
Team E’s declared write scope is narrow: only `pyproject.toml` and `CHANGELOG.md`, with a hard requirement to remove `[Unreleased]`, add `2.0.0` and `1.1.0`, and keep the build config intact. I’m loading the review workflow now, then I’ll inspect the merged commit and verify the changelog claims against the plan.
exec
/bin/zsh -lc "sed -n '1,220p' /Users/justnau/.agents/skills/review/SKILL.md" in /Users/justnau/finlet
 exited 1 in 0ms:
sed: /Users/justnau/.agents/skills/review/SKILL.md: No such file or directory

exec
/bin/zsh -lc "sed -n '1,220p' /Users/justnau/.agents/skills/gstack/review/SKILL.md" in /Users/justnau/finlet
 succeeded in 0ms:
---
name: review
preamble-tier: 4
version: 1.0.0
description: |
  Pre-landing PR review. Analyzes diff against the base branch for SQL safety, LLM trust
  boundary violations, conditional side effects, and other structural issues. Use when
  asked to "review this PR", "code review", "pre-landing review", or "check my diff".
  Proactively suggest when the user is about to merge or land code changes. (gstack)
allowed-tools:
  - Bash
  - Read
  - Edit
  - Write
  - Grep
  - Glob
  - Agent
  - AskUserQuestion
  - WebSearch
triggers:
  - review this pr
  - code review
  - check my diff
  - pre-landing review
---
<!-- AUTO-GENERATED from SKILL.md.tmpl — do not edit directly -->
<!-- Regenerate: bun run gen:skill-docs -->

## Preamble (run first)

```bash
_UPD=$(~/.Codex/skills/gstack/bin/gstack-update-check 2>/dev/null || .Codex/skills/gstack/bin/gstack-update-check 2>/dev/null || true)
[ -n "$_UPD" ] && echo "$_UPD" || true
mkdir -p ~/.gstack/sessions
touch ~/.gstack/sessions/"$PPID"
_SESSIONS=$(find ~/.gstack/sessions -mmin -120 -type f 2>/dev/null | wc -l | tr -d ' ')
find ~/.gstack/sessions -mmin +120 -type f -exec rm {} + 2>/dev/null || true
_PROACTIVE=$(~/.Codex/skills/gstack/bin/gstack-config get proactive 2>/dev/null || echo "true")
_PROACTIVE_PROMPTED=$([ -f ~/.gstack/.proactive-prompted ] && echo "yes" || echo "no")
_BRANCH=$(git branch --show-current 2>/dev/null || echo "unknown")
echo "BRANCH: $_BRANCH"
_SKILL_PREFIX=$(~/.Codex/skills/gstack/bin/gstack-config get skill_prefix 2>/dev/null || echo "false")
echo "PROACTIVE: $_PROACTIVE"
echo "PROACTIVE_PROMPTED: $_PROACTIVE_PROMPTED"
echo "SKILL_PREFIX: $_SKILL_PREFIX"
source <(~/.Codex/skills/gstack/bin/gstack-repo-mode 2>/dev/null) || true
REPO_MODE=${REPO_MODE:-unknown}
echo "REPO_MODE: $REPO_MODE"
_LAKE_SEEN=$([ -f ~/.gstack/.completeness-intro-seen ] && echo "yes" || echo "no")
echo "LAKE_INTRO: $_LAKE_SEEN"
_TEL=$(~/.Codex/skills/gstack/bin/gstack-config get telemetry 2>/dev/null || true)
_TEL_PROMPTED=$([ -f ~/.gstack/.telemetry-prompted ] && echo "yes" || echo "no")
_TEL_START=$(date +%s)
_SESSION_ID="$$-$(date +%s)"
echo "TELEMETRY: ${_TEL:-off}"
echo "TEL_PROMPTED: $_TEL_PROMPTED"
_EXPLAIN_LEVEL=$(~/.Codex/skills/gstack/bin/gstack-config get explain_level 2>/dev/null || echo "default")
if [ "$_EXPLAIN_LEVEL" != "default" ] && [ "$_EXPLAIN_LEVEL" != "terse" ]; then _EXPLAIN_LEVEL="default"; fi
echo "EXPLAIN_LEVEL: $_EXPLAIN_LEVEL"
_QUESTION_TUNING=$(~/.Codex/skills/gstack/bin/gstack-config get question_tuning 2>/dev/null || echo "false")
echo "QUESTION_TUNING: $_QUESTION_TUNING"
mkdir -p ~/.gstack/analytics
if [ "$_TEL" != "off" ]; then
echo '{"skill":"review","ts":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","repo":"'$(basename "$(git rev-parse --show-toplevel 2>/dev/null)" 2>/dev/null || echo "unknown")'"}'  >> ~/.gstack/analytics/skill-usage.jsonl 2>/dev/null || true
fi
for _PF in $(find ~/.gstack/analytics -maxdepth 1 -name '.pending-*' 2>/dev/null); do
  if [ -f "$_PF" ]; then
    if [ "$_TEL" != "off" ] && [ -x "~/.Codex/skills/gstack/bin/gstack-telemetry-log" ]; then
      ~/.Codex/skills/gstack/bin/gstack-telemetry-log --event-type skill_run --skill _pending_finalize --outcome unknown --session-id "$_SESSION_ID" 2>/dev/null || true
    fi
    rm -f "$_PF" 2>/dev/null || true
  fi
  break
done
eval "$(~/.Codex/skills/gstack/bin/gstack-slug 2>/dev/null)" 2>/dev/null || true
_LEARN_FILE="${GSTACK_HOME:-$HOME/.gstack}/projects/${SLUG:-unknown}/learnings.jsonl"
if [ -f "$_LEARN_FILE" ]; then
  _LEARN_COUNT=$(wc -l < "$_LEARN_FILE" 2>/dev/null | tr -d ' ')
  echo "LEARNINGS: $_LEARN_COUNT entries loaded"
  if [ "$_LEARN_COUNT" -gt 5 ] 2>/dev/null; then
    ~/.Codex/skills/gstack/bin/gstack-learnings-search --limit 3 2>/dev/null || true
  fi
else
  echo "LEARNINGS: 0"
fi
~/.Codex/skills/gstack/bin/gstack-timeline-log '{"skill":"review","event":"started","branch":"'"$_BRANCH"'","session":"'"$_SESSION_ID"'"}' 2>/dev/null &
_HAS_ROUTING="no"
if [ -f AGENTS.md ] && grep -q "## Skill routing" AGENTS.md 2>/dev/null; then
  _HAS_ROUTING="yes"
fi
_ROUTING_DECLINED=$(~/.Codex/skills/gstack/bin/gstack-config get routing_declined 2>/dev/null || echo "false")
echo "HAS_ROUTING: $_HAS_ROUTING"
echo "ROUTING_DECLINED: $_ROUTING_DECLINED"
_VENDORED="no"
if [ -d ".Codex/skills/gstack" ] && [ ! -L ".Codex/skills/gstack" ]; then
  if [ -f ".Codex/skills/gstack/VERSION" ] || [ -d ".Codex/skills/gstack/.git" ]; then
    _VENDORED="yes"
  fi
fi
echo "VENDORED_GSTACK: $_VENDORED"
echo "MODEL_OVERLAY: Codex"
_CHECKPOINT_MODE=$(~/.Codex/skills/gstack/bin/gstack-config get checkpoint_mode 2>/dev/null || echo "explicit")
_CHECKPOINT_PUSH=$(~/.Codex/skills/gstack/bin/gstack-config get checkpoint_push 2>/dev/null || echo "false")
echo "CHECKPOINT_MODE: $_CHECKPOINT_MODE"
echo "CHECKPOINT_PUSH: $_CHECKPOINT_PUSH"
[ -n "$OPENCLAW_SESSION" ] && echo "SPAWNED_SESSION: true" || true
```

## Plan Mode Safe Operations

In plan mode, allowed because they inform the plan: `$B`, `$D`, `codex exec`/`codex review`, writes to `~/.gstack/`, writes to the plan file, and `open` for generated artifacts.

## Skill Invocation During Plan Mode

If the user invokes a skill in plan mode, the skill takes precedence over generic plan mode behavior. **Treat the skill file as executable instructions, not reference.** Follow it step by step starting from Step 0; the first AskUserQuestion is the workflow entering plan mode, not a violation of it. AskUserQuestion (any variant — `mcp__*__AskUserQuestion` or native; see "AskUserQuestion Format → Tool resolution") satisfies plan mode's end-of-turn requirement. If no variant is callable, fall back to writing the decision brief into the plan file as a `## Decisions to confirm` section + ExitPlanMode — never silently auto-decide. At a STOP point, stop immediately. Do not continue the workflow or call ExitPlanMode there. Commands marked "PLAN MODE EXCEPTION — ALWAYS RUN" execute. Call ExitPlanMode only after the skill workflow completes, or if the user tells you to cancel the skill or leave plan mode.

If `PROACTIVE` is `"false"`, do not auto-invoke or proactively suggest skills. If a skill seems useful, ask: "I think /skillname might help here — want me to run it?"

If `SKILL_PREFIX` is `"true"`, suggest/invoke `/gstack-*` names. Disk paths stay `~/.Codex/skills/gstack/[skill-name]/SKILL.md`.

If output shows `UPGRADE_AVAILABLE <old> <new>`: read `~/.Codex/skills/gstack/gstack-upgrade/SKILL.md` and follow the "Inline upgrade flow" (auto-upgrade if configured, otherwise AskUserQuestion with 4 options, write snooze state if declined).

If output shows `JUST_UPGRADED <from> <to>`: print "Running gstack v{to} (just updated!)". If `SPAWNED_SESSION` is true, skip feature discovery.

Feature discovery, max one prompt per session:
- Missing `~/.Codex/skills/gstack/.feature-prompted-continuous-checkpoint`: AskUserQuestion for Continuous checkpoint auto-commits. If accepted, run `~/.Codex/skills/gstack/bin/gstack-config set checkpoint_mode continuous`. Always touch marker.
- Missing `~/.Codex/skills/gstack/.feature-prompted-model-overlay`: inform "Model overlays are active. MODEL_OVERLAY shows the patch." Always touch marker.

After upgrade prompts, continue workflow.

If `WRITING_STYLE_PENDING` is `yes`: ask once about writing style:

> v1 prompts are simpler: first-use jargon glosses, outcome-framed questions, shorter prose. Keep default or restore terse?

Options:
- A) Keep the new default (recommended — good writing helps everyone)
- B) Restore V0 prose — set `explain_level: terse`

If A: leave `explain_level` unset (defaults to `default`).
If B: run `~/.Codex/skills/gstack/bin/gstack-config set explain_level terse`.

Always run (regardless of choice):
```bash
rm -f ~/.gstack/.writing-style-prompt-pending
touch ~/.gstack/.writing-style-prompted
```

Skip if `WRITING_STYLE_PENDING` is `no`.

If `LAKE_INTRO` is `no`: say "gstack follows the **Boil the Lake** principle — do the complete thing when AI makes marginal cost near-zero. Read more: https://garryslist.org/posts/boil-the-ocean" Offer to open:

```bash
open https://garryslist.org/posts/boil-the-ocean
touch ~/.gstack/.completeness-intro-seen
```

Only run `open` if yes. Always run `touch`.

If `TEL_PROMPTED` is `no` AND `LAKE_INTRO` is `yes`: ask telemetry once via AskUserQuestion:

> Help gstack get better. Share usage data only: skill, duration, crashes, stable device ID. No code, file paths, or repo names.

Options:
- A) Help gstack get better! (recommended)
- B) No thanks

If A: run `~/.Codex/skills/gstack/bin/gstack-config set telemetry community`

If B: ask follow-up:

> Anonymous mode sends only aggregate usage, no unique ID.

Options:
- A) Sure, anonymous is fine
- B) No thanks, fully off

If B→A: run `~/.Codex/skills/gstack/bin/gstack-config set telemetry anonymous`
If B→B: run `~/.Codex/skills/gstack/bin/gstack-config set telemetry off`

Always run:
```bash
touch ~/.gstack/.telemetry-prompted
```

Skip if `TEL_PROMPTED` is `yes`.

If `PROACTIVE_PROMPTED` is `no` AND `TEL_PROMPTED` is `yes`: ask once:

> Let gstack proactively suggest skills, like /qa for "does this work?" or /investigate for bugs?

Options:
- A) Keep it on (recommended)
- B) Turn it off — I'll type /commands myself

If A: run `~/.Codex/skills/gstack/bin/gstack-config set proactive true`
If B: run `~/.Codex/skills/gstack/bin/gstack-config set proactive false`

Always run:
```bash
touch ~/.gstack/.proactive-prompted
```

Skip if `PROACTIVE_PROMPTED` is `yes`.

If `HAS_ROUTING` is `no` AND `ROUTING_DECLINED` is `false` AND `PROACTIVE_PROMPTED` is `yes`:
Check if a AGENTS.md file exists in the project root. If it does not exist, create it.

Use AskUserQuestion:

> gstack works best when your project's AGENTS.md includes skill routing rules.

Options:
- A) Add routing rules to AGENTS.md (recommended)
- B) No thanks, I'll invoke skills manually

If A: Append this section to the end of AGENTS.md:

```markdown

## Skill routing

exec
/bin/zsh -lc 'rg -n "''^## Workflow|Review|Findings|Step|STOP|diff|Output" /Users/justnau/.agents/skills/gstack/review/SKILL.md' in /Users/justnau/finlet
 succeeded in 0ms:
6:  Pre-landing PR review. Analyzes diff against the base branch for SQL safety, LLM trust
8:  asked to "review this PR", "code review", "pre-landing review", or "check my diff".
23:  - check my diff
115:If the user invokes a skill in plan mode, the skill takes precedence over generic plan mode behavior. **Treat the skill file as executable instructions, not reference.** Follow it step by step starting from Step 0; the first AskUserQuestion is the workflow entering plan mode, not a violation of it. AskUserQuestion (any variant — `mcp__*__AskUserQuestion` or native; see "AskUserQuestion Format → Tool resolution") satisfies plan mode's end-of-turn requirement. If no variant is callable, fall back to writing the decision brief into the plan file as a `## Decisions to confirm` section + ExitPlanMode — never silently auto-decide. At a STOP point, stop immediately. Do not continue the workflow or call ExitPlanMode there. Commands marked "PLAN MODE EXCEPTION — ALWAYS RUN" execute. Call ExitPlanMode only after the skill workflow completes, or if the user tells you to cancel the skill or leave plan mode.
232:- Code review/diff check → invoke /review
298:Completeness: A=X/10, B=Y/10   (or: Note: options differ in kind, not coverage — no completeness score)
313:Completeness: use `Completeness: N/10` only when options differ in coverage. 10 = complete, 7 = happy path, 3 = shortcut. If options differ in kind, write: `Note: options differ in kind, not coverage — no completeness score.`
414:**subordinate** to skill workflow, STOP points, AskUserQuestion gates, plan-mode
566:When options differ in coverage, include `Completeness: X/10` (10 = all edge cases, 7 = happy path, 3 = shortcut). When options differ in kind, write: `Note: options differ in kind, not coverage — no completeness score.` Do not fabricate scores.
570:For high-stakes ambiguity (architecture, data model, destructive scope, missing context), STOP. Name it in one sentence, present 2-3 options with tradeoffs, and ask. Do not use for routine coding or obvious changes.
601:If you are looping on the same diagnostic, same file, or failed fix variants, STOP and reassess. Consider escalation or /context-save. Progress summaries must NEVER mutate git state.
696:## Step 0: Detect platform and base branch
729:Print the detected base branch name. In every subsequent `git diff`, `git log`,
735:# Pre-Landing PR Review
737:You are running the `/review` workflow. Analyze the current branch's diff against the base branch for structural issues that tests don't catch.
741:## Step 1: Check branch
745:3. Run `git fetch origin <base> --quiet && git diff origin/<base> --stat` to check if there's a diff. If no diff, output the same message and stop.
749:## Step 1.5: Scope Drift Detection
757:3. Run `git diff origin/<base>...HEAD --stat` and compare the files changed against the stated intent.
767:   - Requirements from TODOS.md/PR description not addressed in the diff
771:5. Output (before the main review begins):
775:   Delivered: <1-line summary of what the diff actually does>
808:3. **Validation:** If a plan file was found via content-based search (not conversation context), read the first 20 lines and verify it is relevant to the current branch's work. If it appears to be from a different project or feature, treat as "no plan file found."
828:- Review report sections (`## GSTACK REVIEW REPORT`)
830:- CEO Review Decisions sections (these record choices, not work items)
842:Run `git diff origin/<base>...HEAD` and `git log origin/<base>..HEAD --oneline` to understand what was implemented.
844:For each extracted plan item, check the diff and classify:
846:- **DONE** — Clear evidence in the diff that this item was implemented. Cite the specific file(s) changed.
847:- **PARTIAL** — Some work toward this item exists in the diff but it's incomplete (e.g., model created but controller missing, function exists but edge cases not handled).
848:- **NOT DONE** — No evidence in the diff that this item was addressed.
849:- **CHANGED** — The item was implemented using a different approach than the plan described, but the same goal is achieved. Note the difference.
851:**Be conservative with DONE** — require clear evidence in the diff. A file being touched is not enough; the specific functionality described must be present.
852:**Be generous with CHANGED** — if the goal is met by different means, that counts as addressed.
854:### Output Format
864:  [NOT DONE]  Add caching layer — no cache-related changes in diff
905:Output for each discrepancy:
936:- **Items in the diff that don't match any plan item** become evidence for **SCOPE CREEP** detection.
949:Delivered: <1-line summary of what the diff actually does>
957:## Step 2: Read the checklist
961:**If the file cannot be read, STOP and report the error.** Do not proceed without the checklist.
965:## Step 2.5: Check for Greptile review comments
971:**If Greptile comments are found:** Store the classifications (VALID & ACTIONABLE, VALID BUT ALREADY FIXED, FALSE POSITIVE, SUPPRESSED) — you will need them in Step 5.
975:## Step 3: Get the diff
983:Run `git diff origin/<base>` to get the full diff. This includes both committed and uncommitted changes against the latest base branch.
985:## Step 3.4: Workspace-aware queue status (advisory)
1007:## Step 3.5: Slop scan (advisory)
1013:bun run slop:diff origin/<base> 2>/dev/null || true
1017:diagnostic. Slop findings are advisory, never blocking. If slop:diff is not
1060:## Step 4: Critical pass (core review)
1062:Apply the CRITICAL categories from the checklist against the diff:
1063:SQL & Data Safety, Race Conditions & Concurrency, LLM Output Trust Boundary, Shell Injection, Enum & Value Completeness.
1067:**Enum & Value Completeness requires reading code OUTSIDE the diff.** When the diff introduces a new enum value, status, tier, or type constant, use Grep to find all files that reference sibling values, then Read those files to check if the new value is handled. This is the one category where within-diff review is insufficient.
1105:## Step 4.5: Review Army — Specialist Dispatch
1110:source <(~/.Codex/skills/gstack/bin/gstack-diff-scope <base> 2>/dev/null) || true
1119:DIFF_INS=$(git diff origin/<base> --stat | tail -1 | grep -oE '[0-9]+ insertion' | grep -oE '[0-9]+' || echo "0")
1120:DIFF_DEL=$(git diff origin/<base> --stat | tail -1 | grep -oE '[0-9]+ deletion' | grep -oE '[0-9]+' || echo "0")
1147:**If DIFF_LINES < 50:** Skip all specialists. Print: "Small diff ($DIFF_LINES lines) — specialists skipped." Continue to Step 5.
1194:`git diff origin/<base>` to get the full diff. Apply the checklist against the diff.
1222:### Step 4.6: Collect and merge findings
1254:**Output merged findings:**
1268:These findings flow into Step 5 Fix-First alongside the CRITICAL pass findings from Step 4.
1272:After merging findings, compile a `specialists` object for the review-log entry in Step 5.8.
1280:Remember these stats — you will need them for the review-log entry in Step 5.8.
1292:2. The merged specialist findings from Step 4.6 (so it knows what was already caught)
1293:3. The git diff command
1297:MISSED. Read the checklist, run `git diff origin/<base>`, and look for gaps.
1298:Output findings as JSON objects (same schema as the specialists). Focus on cross-cutting
1303:Step 5 Fix-First. Red Team findings are tagged with `"specialist":"red-team"`.
1310:## Step 5: Fix-First Review
1314:### Step 5.0: Cross-review finding dedup
1331:git diff --name-only <prior-review-commit> HEAD
1334:For each current finding (from both Step 4 critical pass and Step 4.5-4.6 specialists), check:
1346:Output a summary header: `Pre-Landing Review: N issues (X critical, Y informational)`
1348:### Step 5a: Classify each finding
1360:already exists, append the new test. Output: `[FIXED + TEST] [file:line] Problem -> fix + test at [test_path]`
1362:### Step 5b: Auto-fix all AUTO-FIX items
1367:### Step 5c: Batch-ask about ASK items
1392:### Step 5d: Apply user-approved fixes
1394:Apply fixes for items where the user chose "Fix." Output what was fixed.
1410:After outputting your own findings, if Greptile comments were classified in Step 2.5:
1416:1. **VALID & ACTIONABLE comments:** These are included in your findings — they follow the Fix-First flow (auto-fixed if mechanical, batched into ASK if not) (A: Fix it now, B: Acknowledge, C: False positive). If the user chooses A (fix), reply using the **Fix reply template** from greptile-triage.md (include inline diff + explanation). If the user chooses C (false positive), reply using the **False Positive reply template** (include evidence + suggested re-rank), save to both per-project and global greptile-history.
1436:## Step 5.5: TODOS cross-reference
1448:## Step 5.6: Documentation staleness check
1450:Cross-reference the diff against documentation files. For each `.md` file in the repo root (README.md, ARCHITECTURE.md, CONTRIBUTING.md, AGENTS.md, etc.):
1452:1. Check if code changes in the diff affect features, components, or workflows described in that doc file.
1462:## Step 5.7: Adversarial review (always-on)
1464:Every diff gets adversarial review from both Codex and Codex. LOC is not a proxy for risk — a 5-line auth change can be critical.
1466:**Detect diff size and tool availability:**
1469:DIFF_INS=$(git diff origin/<base> --stat | tail -1 | grep -oE '[0-9]+ insertion' | grep -oE '[0-9]+' || echo "0")
1470:DIFF_DEL=$(git diff origin/<base> --stat | tail -1 | grep -oE '[0-9]+ deletion' | grep -oE '[0-9]+' || echo "0")
1481:**User override:** If the user explicitly requested "full review", "structured review", or "P1 gate", also run the Codex structured review regardless of diff size.
1490:"Read the diff for this branch with `git diff origin/<base>`. Think like an attacker and a chaos engineer. Your job is to find ways this code will fail in production. Look for: edge cases, race conditions, security holes, resource leaks, failure modes, silent data corruption, logic errors that produce wrong results silently, error handling that swallows failures, and trust boundary violations. Be adversarial. Be thorough. No compliments — just the problems. For each finding, classify as FIXABLE (you know how to fix it) or INVESTIGATE (needs human judgment). After listing findings, end your output with ONE line in the canonical format `Recommendation: <action> because <one-line reason naming the most exploitable finding>` — examples: `Recommendation: Fix the unbounded retry at queue.ts:78 because it'll DoS the worker pool under sustained 429s` or `Recommendation: Ship as-is because the strongest finding is a theoretical race that requires conditions we can't trigger in production`. The reason must point to a specific finding (or no-fix rationale). Generic reasons like 'because it's safer' do not qualify."
1505:codex exec "IMPORTANT: Do NOT read or execute any files under ~/.Codex/, ~/.agents/, .Codex/skills/, or agents/. These are Codex skill definitions meant for a different AI system. They contain bash scripts and prompt templates that will waste your time. Ignore them completely. Do NOT modify agents/openai.yaml. Stay focused on the repository code only.\n\nReview the changes on this branch against the base branch. Run git diff origin/<base> to see the diff. Your job is to find ways this code will fail in production. Think like an attacker and a chaos engineer. Find edge cases, race conditions, security holes, resource leaks, failure modes, and silent data corruption paths. Be adversarial. Be thorough. No compliments — just the problems. End your output with ONE line in the canonical format `Recommendation: <action> because <one-line reason naming the most exploitable finding>`. Generic reasons like 'because it's safer' do not qualify; the reason must point to a specific finding or no-fix rationale." -C "$_REPO_ROOT" -s read-only -c 'model_reasoning_effort="high"' --enable web_search_cached < /dev/null 2>"$TMPERR_ADV"
1526:### Codex structured review (large diffs only, 200+ lines)
1534:codex review "IMPORTANT: Do NOT read or execute any files under ~/.Codex/, ~/.agents/, .Codex/skills/, or agents/. These are Codex skill definitions meant for a different AI system. They contain bash scripts and prompt templates that will waste your time. Ignore them completely. Do NOT modify agents/openai.yaml. Stay focused on the repository code only.\n\nReview the diff against the base branch." --base <base> -c 'model_reasoning_effort="high"' --enable web_search_cached < /dev/null 2>"$TMPERR"
1542:Codex found N critical issues in the diff.
1554:If `DIFF_TOTAL < 200`: skip this section silently. The Codex + Codex adversarial passes provide sufficient coverage for smaller diffs.
1564:Substitute: STATUS = "clean" if no findings across ALL passes, "issues_found" if any pass found issues. SOURCE = "both" if Codex ran, "Codex" if only Codex subagent ran. GATE = the Codex structured review gate result ("pass"/"fail"), "skipped" if diff < 200, or "informational" if Codex was unavailable. If all passes failed, do NOT persist.
1587:## Step 5.8: Persist Eng Review result
1590:recognize that Eng Review was run on this branch.
1604:- `quality_score` = the PR Quality Score computed in Step 4.6 (e.g., 7.5). If specialists were skipped (small diff), use `10.0`
1605:- `specialists` = the per-specialist stats object compiled in Step 4.6. Each specialist that was considered gets an entry: `{"dispatched":true/false,"findings":N,"critical":N,"informational":N}` if dispatched, or `{"dispatched":false,"reason":"scope|gated"}` if skipped. Include Design specialist. Example: `{"testing":{"dispatched":true,"findings":2,"critical":0,"informational":2},"security":{"dispatched":false,"reason":"scope"}}`
1606:- `findings` = array of per-finding records from Step 5. For each finding (from critical pass and specialists), include: `{"fingerprint":"path:line:category","severity":"CRITICAL|INFORMATIONAL","action":"ACTION"}`. ACTION is `"auto-fixed"` (Step 5b), `"fixed"` (user approved in Step 5d), or `"skipped"` (user chose Skip in Step 5c). Suppressed findings from Step 5.0 are NOT included (they were already recorded in a prior review entry).
1634:If the review exits early before a real review completes (for example, no diff against the base branch), do **not** write this entry.
1638:- **Read the FULL diff before commenting.** Do not flag issues already addressed in the diff.

exec
/bin/zsh -lc "sed -n '628,729p' docs/brainstorms/V2_PURE_MCP_EXECUTION_PLAN.md" in /Users/justnau/finlet
 succeeded in 0ms:
### Team E: Version bump + CHANGELOG repair (capstone)

**Blocked by:** Teams A, B, C, D — all must merge first.

**Read these files first:**
- `pyproject.toml:1-20` — `[project]` table; current `version = "1.1.0"` at line 3.
- `CHANGELOG.md` FULL FILE — current section ordering: `[1.0.4]` line 8, `[1.0.3]` line 43, `[Unreleased]` line 53 (Step 10b BLOCKER-4: contents are 2026-05-22 session-level-blind work, NOT 1.1.0 USER_MANUAL_OVERHAUL), `[1.0.2]` line 164, `[1.0.1]` line 174, `[1.0.0]` line 193, `[0.1.1]` line 319.
- `CHANGELOG.md:53-163` — read the FULL `[Unreleased]` body. Confirms Step 10b BLOCKER-4: this is 2026-05-22 session-level-blind content.
- `.github/workflows/pypi-publish.yml` — Trusted Publishing via OIDC; triggers on `release: published`, `push.tags: ['v*']`, `workflow_dispatch`.
- `docs/REMAINING_TASKS.md` — search for "USER_MANUAL_OVERHAUL" or "1.1.0" or "2026-05-16" to find the v1.1.0 contents to author the missing entry.
- `[[project-user-manual-overhaul-shipped]]` memory — v1.1.0 SHIPPED 2026-05-16 via PR #87 (`9a88842`).
- `[[project-session-level-blind-shipped]]` memory — session-level blind SHIPPED 2026-05-22 prod sha `27d96ca` PR #134.

**Recon evidence (verified against HEAD `fb2637c`):**

```toml pyproject.toml
3: version = "1.1.0"
5: readme = "README.md"
```

```text CHANGELOG.md section ordering
8:## [1.0.4] — 2026-05-12
43:## [1.0.3] — 2026-05-11
53:## [Unreleased]
164:## [1.0.2] — 2026-05-11
174:## [1.0.1] — 2026-05-11
193:## [1.0.0] - 2026-05-10
319:## [0.1.1] - <prior>
```

```text CHANGELOG.md:53-66 (Unreleased contents — Step 10b BLOCKER-4)
53:## [Unreleased]
54:
55:### Added (session-level blind mode — 2026-05-22 exec-plan v12)
56:
57:- **`create_session(blind: bool = False)`** across MCP (canonical
58:  `mcp__finlet__create_session`), REST (`POST /v1/sessions`), and CLI
59:  (`finlet sessions create --blind`). When `True`, the session is created
60:  ...
```

The `[Unreleased]` section is 2026-05-22 session-level-blind work — NOT the 2026-05-16 USER_MANUAL_OVERHAUL that constitutes v1.1.0. So `[Unreleased]` cannot be simply renamed to `[1.1.0]`.

(verified by recon agent against HEAD `fb2637c` via `grep -nE "^## \[" CHANGELOG.md` + read of CHANGELOG lines 53-75)

**CHANGELOG repair strategy (Step 10b BLOCKER-4):**

Final desired ordering (top to bottom):

| Position | Section | Date | Source of content |
|---|---|---|---|
| 1 | `[2.0.0]` | 2026-05-22 | (a) Pure-MCP removals from this exec-plan (added/changed/removed/migration). (b) Session-level-blind work currently misplaced in `[Unreleased]` — fold these in alongside removals since both ship 2026-05-22. |
| 2 | `[1.1.0]` | 2026-05-16 | NEW entry. USER_MANUAL_OVERHAUL contents — author from `docs/REMAINING_TASKS.md` evidence + memory `[[project-user-manual-overhaul-shipped]]` (PR #87 `9a88842`). |
| 3 | `[1.0.4]` | 2026-05-12 | Existing — keep at line 8 position. |
| 4 | `[1.0.3]` | 2026-05-11 | Existing — keep at line 43 position. |
| 5 | `[1.0.2]` | 2026-05-11 | Existing — keep at line 164 position. |
| 6 | `[1.0.1]` | 2026-05-11 | Existing — keep at line 174 position. |
| 7 | `[1.0.0]` | 2026-05-10 | Existing — keep at line 193 position. |
| 8 | `[0.1.1]` | <prior> | Existing — keep at line 319 position. |

Steps:
1. **Read** the full body of `[Unreleased]` (lines 53-163). Save the content — it goes into `[2.0.0]`.
2. **Delete** the misplaced `[Unreleased]` header at line 53 along with its contents.
3. **Author `[1.1.0] - 2026-05-16`** by reading `docs/REMAINING_TASKS.md` for USER_MANUAL_OVERHAUL closure references (memory says PR #87 `9a88842`). Sections: `### Added` (manual overhaul, `finlet manual` CLI command), `### Changed` (operator surfacing), `### PR references`.
4. **Author `[2.0.0] - 2026-05-22`** with three groupings:
   - `### Added` — session-level blind work from the saved `[Unreleased]` content.
   - `### Removed` — 12 CLI commands + helpers from this exec-plan.
   - `### Changed` — CLI surface reduced to MCP-bootstrap minimum.
   - `### Migration notes` — agents use MCP; wire `finlet mcp serve` into Claude Desktop / Codex CLI / Generic MCP Client. Zero PyPI consumers per `[[project-pre-launch-no-customers]]`; no deprecation period.
   - `### PR references` — this PR + the session-level-blind PR (#134 if its number is final).
5. **Prepend** `[2.0.0]` at top, then `[1.1.0]` immediately below, then existing `[1.0.4]` through `[0.1.1]` unchanged.

**Files touched:**
- Modified: `pyproject.toml` — bump `version = "1.1.0"` → `version = "2.0.0"` at line 3.
- Modified: `CHANGELOG.md` — execute the repair strategy above.

**Deliverable:** Repo at v2.0.0, CHANGELOG ordering clean, ready for tag push.

**Validation:**
- [ ] `grep "^version = " pyproject.toml` returns `version = "2.0.0"`.
- [ ] `grep -nE "^## \[" CHANGELOG.md` shows ordering: `[2.0.0] (2026-05-22) → [1.1.0] (2026-05-16) → [1.0.4] → [1.0.3] → [1.0.2] → [1.0.1] → [1.0.0] → [0.1.1]`.
- [ ] CHANGELOG has NO `[Unreleased]` section.
- [ ] `grep -A2 "^## \[2.0.0\]" CHANGELOG.md` shows BOTH a `### Added` mentioning session-level blind AND a `### Removed` mentioning the 12 dropped CLI commands.
- [ ] `grep -A2 "^## \[1.1.0\]" CHANGELOG.md` shows `### Added` mentioning USER_MANUAL_OVERHAUL or `finlet manual` and PR #87.
- [ ] `hatch build` succeeds — wheel + sdist produced.
- [ ] `unzip -l dist/finlet-2.0.0-*.whl | grep -E "finlet/(cli|mcp|api|core|plugins)"` confirms all key modules present; `finlet/cli_mcp_client.py` absent.
- [ ] `python -m pip install --force-reinstall dist/finlet-2.0.0-*.whl && finlet --help` shows trimmed command surface.
- [ ] `pytest tests/ -x` passes.
- [ ] `ruff check .` passes.
- [ ] `python -m finlet.manual.generate_llms_txt --check` exits 0.
- [ ] `git status` shows ONLY `pyproject.toml` and `CHANGELOG.md` modified.

**Agent instructions:**
- You MUST `git add pyproject.toml CHANGELOG.md` and `git commit` before finishing.
- Do NOT push the v2.0.0 tag yourself. Tag push is user-driven (final manual step after this PR merges).
- BEFORE editing CHANGELOG.md, READ the full file end-to-end + read `docs/REMAINING_TASKS.md` for USER_MANUAL_OVERHAUL evidence.
- The `[Unreleased]` section is NOT v1.1.0 content. It's 2026-05-22 session-level-blind work. Fold it into `[2.0.0]` alongside the pure-MCP removals (since they ship same-day).
- Author `[1.1.0]` from independent evidence (REMAINING_TASKS + memory) since there's no existing CHANGELOG entry for it.
- Match CHANGELOG voice/density to existing `## [1.0.0]` entry — terse, technical, with PR # links.
- Verify `hatch build` smoke locally before commit.
- Do NOT modify any other file.
- Commit message: `[Team E v2.0.0]: bump 2.0.0 + CHANGELOG repair (add [1.1.0] from manual-overhaul evidence; fold [Unreleased] into [2.0.0])`.

exec
/bin/zsh -lc "sed -n '1,220p' docs/KNOWN_FAILURES.md" in /Users/justnau/finlet
 succeeded in 0ms:
# Known Test Failures
> Last updated: 2026-05-23 by pre-flight check (exec-plan `V2_PURE_MCP_EXECUTION_PLAN`) — pre-spawn HEAD = `fb2637c` (post 2026-05-22 SESSION_LEVEL_BLIND v12 SHIPPED at `27d96ca` + cli.py:624 blind-mode fallback partial-fix exec-plan stage at `fb2637c`). Pre-flight ran in SMOKE mode (6-pass targeted pytest split, matching the established 2026-05-19/2026-05-22 pattern). Full-suite invocation skipped per documented dev-machine aiosqlite asyncio-teardown stall pattern; CI single-thread is the authoritative gate per `feedback_pr_gated_ci.md`. Combined SMOKE totals: pass-1 `tests/mcp/ tests/leaderboard/ tests/db/` → **950 passed, 1 xfailed in 126.29s**; pass-2 `tests/core/ tests/plugins/ tests/auth/ --ignore=tests/auth/oauth` → **1437 passed in 111.37s**; pass-3 `tests/api/ tests/services/ tests/gdpr/ tests/test_cli.py tests/test_cli_help.py tests/test_cli_benchmark.py` → **1999 passed, 1 skipped in 227.16s**; pass-4 `tests/auth/oauth/test_e2e_authcode_flow.py` (the 6 xfail-tracked tests in isolation) → **6 xpassed in 66.94s** (markers kept with `strict=False` per the established convention — the underlying aiosqlite asyncio-teardown race is known-intermittent under full-suite teardown pressure and removing markers would re-arm the gate next time the race surfaces); pass-5 `tests/billing/ tests/marketplace/ tests/telemetry/ tests/integration/ tests/property/ tests/test_cli_oauth_login.py tests/test_manual.py tests/test_manual_generate_llms_txt.py` → **471 passed in 16.24s**; pass-6 `tests/auth/ --ignore=tests/auth/oauth tests/dashboard/ tests/ingestion/ tests/scripts/ tests/fixtures/ tests/deploy/` → **642 passed in 183.02s**. Total **5499 passed, 1 skipped, 1 xfailed, 6 xpassed, 0 failed** across the six pytest invocations. The 6 xpassed are the OAuth e2e tests in `tests/auth/oauth/test_e2e_authcode_flow.py` lines 143/299/339/392/454/467 — verified xfail markers in place via grep. The 1 xfailed is `test_create_session_with_readonly_jwt_returns_insufficient_scope` at `tests/mcp/test_scope_enforcement.py:650` (StreamableHTTPSessionManager singleton conflict) — marker behaves as xfailed as expected. No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 5-team exec-plan to land v2.0.0 pure-MCP CLI cutover — Team A (`finlet/cli.py` surgery: rip server-side dispatch + benchmark-CLI removal + `finlet mcp serve` retain), Team C (server-side docs cleanup + `finlet/manual/` content + `dashboard/llms.txt` regen + `finlet/manual/registry.py` + `finlet/manual/generate_llms_txt.py`), Team D (`dashboard/index.html` + `dashboard/setup.html` + `dashboard/agent-guide.html` + new client-matrix integrations), Team B (`tests/test_cli.py` + `tests/test_cli_benchmark.py` + `tests/test_cli_help.py` + `tests/api/test_cli_mcp_client.py` + 4 new MCP assertions in `tests/mcp/test_decrypt_visibility_tools.py`), Team E (capstone: `pyproject.toml` version bump to 2.0.0 + `CHANGELOG.md` repair + `docs/launch/templates.md` + `docs/decisions/cli-mcp-http-dispatch.md` + `README.md` + `docs/ARCHITECTURE.md` + `docs/PRIVACY_POLICY.md`).
>
> Last updated: 2026-05-22 by post-merge close-out (exec-plan `SESSION_LEVEL_BLIND` v12 SHIPPED) — terminal HEAD = `e33cfb0` (post 7-team A-G merge + 6 cascading fix commits: Codex Team A P1+P2 `427ad87` catalog union + atomicity reorder, Team B P1 `ff79ab7` wall-clock audit redaction, Team D P1 `a5f8693` CLI response echo, Team E `f60a7ec` 3 STRONGs test quality, Team A Round 2 `620d825` scope-bypass-to-api-driven-only, Round 4 BLOCKER `e33cfb0` unforgeable `UserRecord.is_internal_benchmark` marker). Combined smoke gate: **3468 passed, 0 failed**. No new failures introduced, no xfail markers added or removed. Pre-existing 6 OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` (aiosqlite asyncio teardown race) verified in place at lines 143/299/339/392/454/467. Pre-existing 1 xfail in `tests/mcp/test_scope_enforcement.py:650` (StreamableHTTPSessionManager singleton conflict) verified in place. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope was a forward-only feature add (session-level blind opt-in via `create_session(blind=True)`); none of the surface-area changes touch the xfailed test paths.
>
> Last updated: 2026-05-22 by pre-flight check (exec-plan `SESSION_LEVEL_BLIND`) — pre-spawn HEAD = `dba6564` (prep commit on top of `b1a305f` post-Codex-3pack ARCHITECTURE+REMAINING_TASKS doc sync). Pre-flight ran in SMOKE mode (scope-limited pytest on `tests/api tests/mcp tests/leaderboard tests/billing tests/core tests/services` with `--ignore=tests/auth/oauth`) because the full-suite invocation hit the documented `tail -50` pipe-buffering + full-suite-timeout pattern from prior entries (KNOWN_FAILURES 2026-05-19, 2026-05-15) on this dev machine, and the subsequent retry was forced inline-synchronous per the harness reconnect. Smoke ran cleanly in 340.45s: **3195 passed, 1 skipped, 1 xfailed, 0 failed, 15119 warnings**. The 15119 warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change). The 1 xfailed is the `test_create_session_with_readonly_jwt_returns_insufficient_scope` entry below (StreamableHTTPSessionManager singleton conflict) — marker in place at `tests/mcp/test_scope_enforcement.py:650`, behaves as xfailed as expected. The 6 OAuth e2e xfail markers in `tests/auth/oauth/test_e2e_authcode_flow.py` were verified in place at lines 143/299/339/392/454/467 via grep but their surface was excluded from this smoke run (well-tested in prior pre-flights, ignored to avoid the aiosqlite teardown stall under full-suite pressure). No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 5-team exec-plan to introduce session-level blinding (REST + MCP + dashboard fairness/no-leak) — Team A (session_service.py blind opt-in via create_session + `_blind` field + `_compute_blind_mapping` helper + serializer plumbing through `session_response`), Team B (REST routes blind-flag wiring in `routes_session.py` + new `tests/api/test_session_create_blind.py` + `test_session_configure_blind.py` + `test_complete_session_blind.py`), Team C (MCP tools_session.py blind wiring in `mcp/server.py` + `mcp/tools_session.py` + new `tests/mcp/test_create_session_blind.py` + `test_session_lifecycle_blind.py`), Team D (CLI + benchmark_state.py blind plumbing through `cli.py` + `leaderboard/benchmark_state.py` + new `tests/billing/test_tier_max_tickers_removed.py` + repurpose `tests/api/test_input_validation.py::test_configure_universe_too_many_returns_422`), Team E (regression coverage: extend `tests/api/test_public_session_blind.py` + NEW `tests/e2e/test_session_level_blind_zero_leak.py` + dashboard `app.js`/`index.html`/`pricing.html` integration).
>
> Last updated: 2026-05-21 by pre-flight check (exec-plan `codex-bugs-4pack-v2`) — pre-spawn HEAD = `677f569` (post `6a79802` exec-plan staging commit, on top of PRs landed since the 2026-05-21 blind-sse-defense-in-depth baseline: bug-11cb2f16 scope flip + bug-4fa9160a input-validation gate + bug-79c7b578 MCP envelope hygiene + bug-b25eba4d lint cleanups). Pre-flight ran the full-suite (`uv run pytest tests/ -q --timeout=120 --ignore=tests/strategies --tb=no -p no:randomly`) and it completed cleanly in 651.44s (0:10:51): **5477 passed, 1 skipped, 6 xpassed, 0 failed, 15215 warnings**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate next time the race surfaces. The 15215 warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change) plus `websockets.legacy` deprecation noise from uvicorn (pre-existing). No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Test count grew +238 since the 2026-05-21 blind-sse baseline (5239 → 5477) reflecting the 4 Codex bug exec-plans landed since (bug-11cb2f16, bug-4fa9160a, bug-79c7b578, bug-b25eba4d); no failures introduced. Iteration scope: 4-team exec-plan to close 12 Codex bug-hunt findings + gitleaks hotfix — Team A2 (scope test hardening + transport-level test in `tests/mcp/test_scope_enforcement.py`), Team B2 (earliest-* semantics + docstrings + no-session discovery cap-to-now in `finlet/api/services/market_service.py` + `finlet/api/routes_market.py` + `finlet/mcp/server.py` + `tests/e2e/test_date_ceiling_zero_leak.py`), Team C2 (submit_order persist atomicity + inf/nan gate + test rename in `finlet/api/services/trade_service.py` + `finlet/mcp/tools_trading.py` + `finlet/api/routes_trade.py` + `tests/mcp/test_submit_order_validation.py` + new `tests/api/test_trade_service_atomicity.py`), Team D2 (FastMCP boundary wrapper for pydantic ValidationError + sanitize_paths key scrub + gitleaks hotfix in NEW `finlet/mcp/_fastmcp_patches.py` + `finlet/mcp/error_envelope.py` + `finlet/mcp/server.py` + `tests/mcp/test_error_envelope_hygiene.py` + `tests/mcp/test_scope_enforcement.py:60`).
>
> Last updated: 2026-05-21 by pre-flight check (exec-plan `2026-05-21-blind-sse-defense-in-depth`) — pre-spawn HEAD = `2e443d5` (post PR `2e443d5` chore(ci): move test (3.13) to PR gate + drop duplicate post-merge runs, on top of `914cd3f` blind-export exec-plan COMPLETED marker + PR #118 `abb86bd` Codex bugs blind-iter2 ship). Pre-flight ran the full-suite (`uv run pytest tests/ -q --timeout=120 --no-header -p no:randomly`) and it completed cleanly in 594.86s (0:09:54): **5239 passed, 1 skipped, 6 xpassed, 0 failed, 15180 warnings**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate next time the race surfaces. The 15180 warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change) plus `websockets.legacy` deprecation noise from uvicorn (pre-existing). No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Test count grew +69 since the 2026-05-20 baseline (5170 → 5239) reflecting the 3 new test files Team F shipped in the blind-export iteration; no failures introduced. Iteration scope: 4-team exec-plan to close SSE/REST trace + benchmark-completed envelope leak surfaces left after the 2026-05-20 blind-export iteration (Codex bug `0558053d` follow-up) — Team A (BlindMapping serializer-poison hardening + missing `tests/core/test_blind_mapping.py`), Team B (SSE trace/benchmark-completed envelope blinding in `finlet/api/routes_sse.py` + `finlet/api/services/{session,clock,trade}_service.py`), Team C (benchmark_state + reporting publish-gate hardening), Team D (zero-leak gate extension to live SSE event surface).
>
> Last updated: 2026-05-20 by pre-flight check (exec-plan `EXEC_PLAN_BLIND_EXPORT_2026_05_20`) — pre-spawn HEAD = `766ef43` (post PR #118 `abb86bd` Codex bugs `d1baf1b8`+`ad919e11`+`53c9eccb` blind-iter2 ship + watchdog-cron exec-plan tweak). Pre-flight ran the full-suite (`uv run pytest tests/ -q --timeout=120 --tb=no -p no:cacheprovider`) and it completed cleanly in 559.41s (0:09:19): **5170 passed, 1 skipped, 6 xpassed, 0 failed, 15139 warnings**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate next time the race surfaces. The 15139 warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change) plus `websockets.legacy` deprecation noise from uvicorn (pre-existing). No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 7 teams closing the live blind-benchmark export/trace leak surfaces (Codex bug `0558053d-aa73-47e4-bd00-4a09417568d6`) — Team A (BlindMapping serializer-poison + pre-persist trace blinding across `finlet/core/blind_mapping.py` + `finlet/db/persistence.py` + 5 `save_trace_entry` call sites in `finlet/api/services/{market,trade,clock}_service.py`), Team B (BenchmarkRunModel new columns `decrypted_at`/`published`/`published_anonymous`/`published_at` + migration 021 + immutability invariant in `finlet/db/leaderboard_models.py` + `finlet/db/leaderboard_persistence.py` + `finlet/leaderboard/benchmark_state.py`), Team C (export_benchmark_results A1 fix + reporting defensive raise in `finlet/mcp/tools_benchmark.py:436-516` + `finlet/leaderboard/reporting.py`), Team D (decrypt + visibility tools + public benchmark router NEW in `finlet/api/services/benchmark_service.py` + `finlet/api/routes_public_benchmark.py` + `finlet/api/routes_benchmark.py` + `finlet/api/schemas/benchmark.py` + `finlet/api/deprecation.py` + `finlet/cli.py`), Team E (REST + SSE trace blinding in `finlet/api/routes_portfolio.py` + `finlet/api/routes_sse.py` + `finlet/api/serializers.py` + `finlet/api/routes_public_session.py` re-export), Team F (zero-leak gate extension + 3 new test files in `tests/e2e/`), Team G (docs + 3 new decision records + ARCHITECTURE.md + REMAINING_TASKS.md + CLAUDE.md).
>
> 2026-05-20 (post-merge note, exec-plan `codex_bugs_blind_iter2`): 6 OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` ran as XPASS during the finalize full-suite gate; xfail markers RETAINED because root cause (aiosqlite asyncio-teardown race) is unaddressed — these may regress on the next run.
>
> Last updated: 2026-05-20 by pre-flight check (exec-plan `codex_bugs_blind_iter2_EXECUTION_PLAN`) — pre-spawn HEAD = `73009e2` (post PR #117 Codex bug 50abd05e ship — blind-leak iter1 closure). Pre-flight ran the full-suite (`uv run pytest tests/ -q --timeout=120 --tb=no -p no:cacheprovider`) and it completed cleanly in 484.89s (0:08:04): **5116 passed, 1 skipped, 6 xpassed, 0 failed, 15170 warnings**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate next time the race surfaces. The 15170 warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change) plus `websockets.legacy` deprecation noise from uvicorn (pre-existing). No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 4 teams closing 3 Codex-reported blind-leak surfaces from the 2026-05-20 second dry-run — Team A (`list_available_tickers` metadata-vs-reality correctness fix in `finlet/api/services/market_service.py`), Team B (`@blind_error_mapper` decorator across `finlet/mcp/server.py` + `tools_trading.py` + `tools_portfolio.py` + `tools_benchmark.py` + `tools_session.py` + `tools_telemetry.py` to auto-blind every tool's error response), Team C (`complete_session` benchmark_complete payload blinding in `finlet/mcp/server.py` + `finlet/leaderboard/reporting.py` + `finlet/api/services/session_service.py`), Team D (extend `tests/e2e/test_blind_benchmark_zero_leak.py` to exercise error paths, completion payloads, and metadata cross-validation + extend `docs/decisions/blind-benchmark-envelope-fields-must-blind.md`).
>
> Last updated: 2026-05-19 by pre-flight check (exec-plan `CODEX_BUG_CE8DE077_EXECUTION_PLAN`) — pre-spawn HEAD = `54d0da7` (orchestrator setup commit, post `949c93b` fundamentals hero-save shipment at PR #111). Pre-flight ran the full-suite (`uv run pytest tests/ -q --timeout=120 -p no:xdist`) and it completed cleanly in 1226.28s (0:20:26): **4943 passed, 1 skipped, 6 xpassed, 9 errors**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate next time the race surfaces. The 9 errors are the documented local-environment data-volume flake from `tests/integration/test_mcp_oauth_e2e.py` — same root cause as the 2026-05-10 entry below (`live_server` session-scope fixture times out at 30s under the inline-benchmark-startup load on this dev machine, ~hundred-plus `benchmark-*` session_loaded events). Verified post-run: `test_oauth_login_writes_credentials_at_mode_0600` passes in 29.65s when run in isolation. NOT a regression — CI single-thread on the same SHA passes them. xfail markers are NOT added because the failures are at fixture setup (xfail wraps the test body, not the fixture), and the established convention (2026-05-10 entry below) is to document them here without marking, since CI is the authoritative gate per `feedback_pr_gated_ci.md`. No new failures, no entries added to the table, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: cascading fixes for Codex bug ce8de077 across `finlet/api/services/session_service.py` + `finlet/mcp/server.py` + `finlet/mcp/auth.py` + `finlet/mcp/tools_benchmark.py` + `finlet/leaderboard/benchmark_state.py` + `finlet/leaderboard/benchmarks.py` + `finlet/db/leaderboard_models.py` + `finlet/db/leaderboard_persistence.py` + `finlet/core/session.py` + `finlet/core/clock.py` + corresponding tests.
>
> Last updated: 2026-05-19 by pre-flight check (exec-plan `FUNDAMENTALS_HERO_SAVE_EXECUTION_PLAN`) — main HEAD = `6a3bba5` (orchestrator setup commit). Pre-flight ran in SMOKE mode (4-pass targeted pytest split, matching the established 2026-05-19 pre-flight pattern). The full-suite invocation reproduced the documented aiosqlite asyncio-teardown hang stall — killed after early stall, retried with 4-pass split per `feedback_pr_gated_ci.md` (CI single-thread is the trusted full-suite gate). Combined SMOKE totals across 4 pytest invocations: pass-1 `tests/mcp/ tests/leaderboard/ tests/db/` → **671 passed in 125.52s**; pass-2 `tests/core/ tests/plugins/ tests/auth/ --ignore=tests/auth/oauth` → **1307 passed in 238.27s**; pass-3 `tests/api/ tests/services/ tests/gdpr/ tests/test_cli.py` → **1774 passed, 1 skipped in 206.36s**; pass-4 `tests/auth/oauth/test_e2e_authcode_flow.py` (the 6 xfail-tracked tests in isolation) → **6 xpassed in 175.19s** (markers kept with `strict=False` per the established convention — the underlying aiosqlite asyncio-teardown race is known-intermittent under full-suite teardown pressure and removing markers would re-arm the gate next time the race surfaces). Total **3758 passed, 1 skipped, 6 xpassed, 0 failed** across the four pytest invocations. No new failures, no new xfail markers added, no entries removed. Pre-existing 6 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False` markers verified in place via grep. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: fundamentals_s3 hero-save coverage fix across `finlet/plugins/fundamentals_plugin.py` + `finlet/ingestion/s3_writer.py` + `scripts/ingest_fundamentals.py` + `finlet/api/services/market_service.py` + corresponding test files.
>
> Last updated: 2026-05-19 by pre-flight check (exec-plan `MCP_BENCHMARK_HARNESS_FIX_EXECUTION_PLAN`) — spawn-base SHA = `241cabc` (`main`). Pre-flight ran in SMOKE mode (4-pass targeted pytest split, matching prior 2026-05-19 pre-flight pattern) — the full-suite invocation `uv run pytest tests/ -q --timeout=60 --ignore=tests/e2e -x` reproduced the documented aiosqlite asyncio-teardown hang at ~38% (the `XXXXXX` block of OAuth xfails surfaces the worker-thread "Event loop is closed" race, which then stalls subsequent tests indefinitely past the budget). CI single-thread is the trusted full-suite gate per `feedback_pr_gated_ci.md` and `feedback_pyproject_comment_stale_about_ci_xdist`. Combined SMOKE totals across 4 pytest invocations: pass-1 `tests/mcp/ tests/leaderboard/ tests/db/` → **664 passed in 117.17s**; pass-2 `tests/core/ tests/plugins/ tests/auth/ --ignore=tests/auth/oauth` → **1307 passed in 221.61s**; pass-3 `tests/api/ tests/services/ tests/gdpr/ tests/test_cli.py` → **1767 passed, 1 skipped in 203.71s**; pass-4 `tests/auth/oauth/test_e2e_authcode_flow.py` (the 6 xfail-tracked tests in isolation) → **6 xpassed in 164.79s** (markers kept with `strict=False` per the established convention — the underlying aiosqlite asyncio-teardown race is known-intermittent under full-suite teardown pressure and removing markers would re-arm the gate next time the race surfaces). Total **3744 passed, 1 skipped, 6 xpassed, 0 failed** across the four pytest invocations. e2e collection-only smoke on `tests/e2e/` confirms `tests/e2e/test_benchmark_flow.py` (6 tests) collects cleanly; full e2e run deferred (slow live-server fixture). No new failures, no new xfail markers added, no entries removed. Pre-existing 6 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False` markers verified in place via grep. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 4 cascading MCP benchmark bug fixes across `finlet/api/services/session_service.py`, `finlet/mcp/tools_benchmark.py`, `finlet/leaderboard/benchmark_state.py`, `finlet/db/leaderboard_persistence.py`, `finlet/mcp/auth.py`, `finlet/telemetry/bug_storage.py` + corresponding tests.
>
> Last updated: 2026-05-19 by pre-flight check (exec-plan `MCP_BENCHMARK_FIXES_EXECUTION_PLAN`) — pre-spawn HEAD = `1b53d97` (post `60ac154` /mcp dual-accept generator regen, on top of `2da10fc` /mcp dual-accept reality alignment merge). Pre-flight ran in SMOKE mode (4-pass targeted pytest split, matching the documented 2026-05-19 prior pre-flight pattern) rather than full-suite, because the dev machine's documented full-suite hang under aiosqlite asyncio-teardown pressure (see 2026-05-10 and 2026-05-15 entries below) reproduced again here: `uv run pytest tests/ -q --timeout=120 -p no:xdist` stalled at ~52% past the 900s budget; CI is the trusted full-suite gate per `feedback_pr_gated_ci.md`. Combined SMOKE totals: pass-1 `tests/mcp/ tests/leaderboard/ tests/db/` → **655 passed in 116.62s**; pass-2 `tests/core/ tests/plugins/ tests/auth/ --ignore=tests/auth/oauth` → **1294 passed in 229.52s**; pass-3 `tests/api/ tests/services/ tests/gdpr/ tests/test_cli.py` → **1767 passed, 1 skipped in 204.36s**; pass-4 `tests/auth/oauth/test_e2e_authcode_flow.py` (the 6 xfail-tracked tests in isolation) → **6 xpassed in 161.56s** (kept marked with `strict=False` per the established convention — the underlying aiosqlite asyncio-teardown race is known-intermittent under full-suite teardown pressure and removing markers would re-arm the gate next time the race surfaces). Total **3722 passed, 1 skipped, 6 xpassed, 0 failed** across the four pytest invocations. The `tests/auth/oauth/` directory-level surface (broader than the 6-test e2e file) was tried but timed out at 300s in the wider iteration (`EXIT: 124`) — same aiosqlite teardown pattern; the 6 in-scope xfails passed before the stall. No new failures, no new xfail markers added, no entries removed. Pre-existing 6 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False`. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 4 parallel teams — Team A (MCP benchmark tooling: `finlet/mcp/tools_benchmark.py` + `finlet/leaderboard/benchmarks.py` + `finlet/leaderboard/benchmark_state.py` + `finlet/db/persistence.py` + `tests/mcp/test_tools_benchmark.py`), Team B (`finlet/core/clock.py` + `tests/core/test_clock.py` + `tests/core/test_clock_step_integration.py`), Team C (`finlet/plugins/fundamentals_plugin.py` + `finlet/plugins/base.py` + `tests/plugins/test_fundamentals_plugin.py` + `tests/plugins/test_fundamentals_backfill.py`), Team D (`finlet/core/session.py` + `finlet/api/services/session_service.py` + `tests/db/test_persistence.py` + `tests/leaderboard/test_benchmark_state.py`).
>
> Last updated: 2026-05-19 (post-merge close-out — exec-plan `AI_QUANTAMENTAL_STRATEGY_EXECUTION_PLAN` 7-team shipment landed). No entries added or removed this iteration. The 6 pre-existing OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False`; pre-existing Hypothesis portfolio-rounding flake unchanged. Shipment introduced no new pytest failures, no new xfail markers; subproject tests live under `strategies/ai_quantamental/tests/` (own pytest invocation, excluded from the root pytest gate).
>
> Last updated: 2026-05-19 by pre-flight check (exec-plan `AI_QUANTAMENTAL_STRATEGY_EXECUTION_PLAN`) — main HEAD = `b34f99b` (post pre-flight artifact commit on top of `3c506ce` RFC 8414 OAuth metadata alias). Pre-flight ran in SMOKE mode (3-pass targeted pytest on `tests/api/ tests/mcp/ tests/leaderboard/ tests/test_cli.py` + `tests/auth/ --ignore=tests/auth/oauth` + `tests/core/ tests/plugins/ tests/services/ tests/gdpr/`) rather than full-suite, because the dev machine's documented data-volume flake on `tests/integration/` (see 2026-05-10 entry below) makes full-suite gating unreliable here and the full-suite `uv run pytest tests/ --timeout=120 --ignore=tests/e2e` invocation hung at ~31% with aiosqlite asyncio teardown timeouts (same pattern as prior pre-flights). CI is the trusted full-suite gate per `feedback_pr_gated_ci.md`. Combined SMOKE totals: pass-1 (api+mcp+leaderboard+cli) **2152 passed, 1 skipped in 294.46s**, pass-2 (auth no-oauth) **103 passed in 182.85s**, pass-3 (core+plugins+services+gdpr) **1386 passed in 34.51s** — total **3641 passed, 1 skipped, 0 failed** across the three pytest invocations. The `tests/auth/oauth/` surface was not gated in this pre-flight because the 6 pre-existing aiosqlite-asyncio-teardown xfails below already cover that surface and standalone re-checks on this dev machine consistently surface the same teardown race. Lint not gated this iteration (deferred to per-team validation). No new failures, no new xfail markers added, no entries removed. Pre-existing 6 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False`. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 6-session execution — Team A (quantamental scaffolding), Team B (`report_bug` MCP tool), Team C (derived-metric helpers), Team D (screens + portfolio), Team E (historical backfill simulator — launch video material), Team F (LLM tiebreaker), Team G (live driver + GH Actions monthly cron).
>
> Last updated: 2026-05-15 by pre-flight check (exec-plan `USER_MANUAL_OVERHAUL_EXECUTION_PLAN`) — main HEAD = `48121cc` (post PR #84 detached-instance regression-test merge on top of PR #83 Stripe live-mode activation at `f3781cd`). Pytest full-suite run (`uv run pytest tests/ -q --timeout=120 -p no:cacheprovider`): **4657 passed, 6 xpassed, 14692 warnings in 913.22s (0:15:13)**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate on the same race next time it surfaces. No new failures, no new xfail markers added, no entries removed this iteration. Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table) remains unchanged. Iteration scope: 7-team execution — Team A (Manual Foundation: NEW `finlet/manual/` package + `finlet/cli.py` `manual` command + `pyproject.toml` hatchling include + `.github/workflows/ci.yml` paths-ignore include override + `README.md:66` args fix), Team B1 (CLI docstring see-also footers in `finlet/cli.py` + `tests/test_cli_help.py` NEW), Team B2 (REST API + Billing envelope suffixes across `finlet/api/routes_*.py` + `finlet/billing/service.py` + new tests), Team B3 (MCP envelope suffixes + `_AUTH_REQUIRED_MESSAGE` dedup + `finlet/api/deprecation.py` `/mcp` whitelist + new tests), Team B4 (OAuth modeled envelope suffixes across `finlet/auth/oauth/*.py` + new tests), Team C (Plugin envelope suffixes across 4 named plugins + `tests/plugins/test_error_anchors.py` NEW), Team D (Dashboard polish: `dashboard/agent-guide.html` 8-tab expansion + `dashboard/setup.html` Phase-5 voice pass + `dashboard/llms.txt` regen + `scripts/git-hooks/pre-commit` 4th guard + `scripts/lint-llms-txt-fresh.sh` NEW + `tests/e2e/journey-19-agent-guide.spec.ts` NEW).
>
> Last updated: 2026-05-14 by pre-flight check (exec-plan `GDPR_EXPORT_F_EXECUTION_PLAN`) — main HEAD = `84161f4` (post pre-flight cleanup commit clearing stale team-prompts on top of `278b242` GDPR-F plan stage). Pytest full-suite run (`timeout 1100 uv run pytest tests/ -q --timeout=120 -x -p no:cacheprovider`): **4493 passed, 6 xpassed, 14674 warnings in 820.97s (13:40)**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate on the same race next time it surfaces. No new failures, no new xfail markers added, no entries removed this iteration. Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table) remains unchanged. Iteration scope: GDPR Article 20 data export (Item F) — async job, ZIP-per-table JSONL archive, S3 24h lifecycle, presigned URL, OAuth Bearer-only, audit table, per-team file ownership across new `finlet/gdpr/` package + `finlet/db/auth_models.py` + `finlet/api/app.py` + `finlet/api/routes_settings.py` + service/schema cleanups.
>
> Last updated: 2026-05-14 by pre-flight check (exec-plan `HYGIENE_BATCH_2026_05_13`) — main HEAD = `3391f0b` (post PR #74 SETTINGS_AND_BILLING_RESTORE merge). Pre-flight ran in SMOKE mode (targeted pytest on `tests/api/ tests/auth/ tests/mcp/ tests/leaderboard/ tests/test_cli.py`) rather than full-suite, because the dev machine's data-volume flake on `tests/integration/` (documented in the 2026-05-10 entry below) makes full-suite gate unreliable here and CI is the trusted full-suite gate. The combined surface was split into two passes to stay under the per-invocation timeout cap: pass-1 `tests/api/ tests/mcp/ tests/leaderboard/ tests/test_cli.py` ran **2036 passed, 0 failed, 0 xfail, 0 skipped in 276.43s**, and pass-2 `tests/auth/ --ignore=tests/auth/oauth` ran **103 passed, 0 failed, 0 xfail, 0 skipped in 150.71s** — total **2139 passed, 0 failed, 0 xfail, 0 skipped in 427.14s** across the two pytest invocations. The `tests/auth/oauth/` surface was not gated in this pre-flight because the 6 pre-existing aiosqlite-asyncio-teardown xfails below already cover that surface and the 180s standalone re-check on this dev machine timed out mid-run after ~70 cases (63 dots + 6 X + 1 dot) without any new failures observed — same pattern documented under 2026-05-10/2026-05-11. Lint: clean (`ruff check finlet/ tests/`). The `--timeout=120` flag from the original pre-flight instruction was dropped because `pytest-timeout` is the K6 work item this iteration is shipping — it is not yet installed at `3391f0b`, so the flag errored out and was removed from the invocation. No new failures introduced, no new xfail markers added, no entries removed. Pre-existing 6 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False`. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: single Team A — K6 (`pyproject.toml` dev dep), K5 (journey-14/15 e2e), I5 (`_ensure_utc` canonicalization to `finlet/utils/datetime.py`), I8 (13 vague-error rewrites across `finlet/api/services/settings_service.py` + `finlet/api/routes_auth_credentials.py` + `finlet/api/routes_auth_sessions.py` + `finlet/api/routes_marketplace_admin.py`).
>
> Last updated: 2026-05-13 by pre-flight check (exec-plan `PUBLIC_SESSION_VIEW_FOLLOWUPS_EXEC_PLAN`) — main HEAD = `cd21911` (post PR #70 ci-cost-cuts merge). Pre-flight ran in DEFERRED mode — full pytest skipped because (a) the local pytest invocation `uv run pytest tests/ -q --tb=no` ran for 14 minutes past the configured 600s `timeout(1)` cap with the output buffered behind `tail -20` (the pipe held all output until exit, so wall-time visibility was zero); the runtime killed it at the pre-flight budget. (b) main is unchanged from the 2026-05-12 PR #70 surface for the API/MCP/CLI areas the followups touch (this iteration's Team A is `dashboard/landing.html` line-241 placeholder substitution, Team B is `tests/e2e/` smoke + helper additions, Team C is `finlet/api/app.py` + `finlet/api/routes_session.py` + `finlet/api/deprecation.py` API-routes-rules pruning); the underlying public-session view tests on `tests/api/test_public_session.py` (Phase A green at PR #65 squash 37ea32f) remain in scope. (c) The 4 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) below remain unchanged with `strict=False`. (d) Pre-existing Hypothesis portfolio-rounding flake unchanged. (e) PR-gated CI is the trusted full-suite gate per `feedback_pr_gated_ci.md` — local dev-machine pytest is documented to flake on `tests/integration/` data-volume issues. No new failures observed pre-launch; no entries added/removed/promoted this iteration. Iteration scope: 3 sequential teams — Team A landing CTA placeholder fix, Team B e2e smoke + Playwright fixture/helper additions, Team C api-routes-rules canonicalization + deprecation cleanup.
>
> Last updated: 2026-05-12 by pre-flight check (exec-plan `PUBLIC_SESSION_VIEW_EXEC_PLAN`) — main HEAD = `a876229` (origin/main, post PR #64 handoff doc merge, on top of PR #63 dashboard empty-states + pricing at `4b829b7`). Pre-flight ran in DEFERRED mode — full pytest skipped because (a) main is unchanged from the 2026-05-11 v1.0.1 baseline below for the API/MCP/CLI surface; (b) per-team validation in the public-session view exec-plan runs targeted pytest gates that cover the surgery surface (`tests/api/test_public_session*.py`, `tests/db/test_session_migration_014.py`, `tests/test_cli.py`); (c) the documented `tests/integration/` data-volume flake from the 2026-05-10 entry below still applies, and the per-team gates avoid that path. No new xfail markers added, no entries removed this iteration. Pre-existing 4 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False`. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Iteration scope: 3 sequential teams per the plan doc — Team A backend (`finlet/db/`, `finlet/api/`, `finlet/mcp/`, `finlet/cli.py`, `tests/api/`, `tests/db/`, `tests/test_cli.py`); Team B frontend (`dashboard/public.html` NEW, `dashboard/public.js` NEW, `dashboard/renderers.js` NEW, refactor `dashboard/app.js`, `dashboard/landing.html` nav + CTA, `finlet/api/app.py` static-route inserts); Team C docs (`docs/ARCHITECTURE.md`, `docs/decisions/session-public-visibility.md` NEW, `docs/REMAINING_TASKS.md`, `docs/PRIVACY_POLICY.md`, `.claude/rules/api-routes.md`).
>
> Last updated: 2026-05-11 by pre-flight check (v1.0.1 hotfix exec-plan `EXECUTION_PLAN_V1_0_1_HOTFIX`) — main HEAD = `cbff2e1` (origin/main, post v1.0.0 finalize PR #52). Pre-flight ran in SMOKE mode (lint + targeted pytest on `tests/test_cli.py tests/api/ tests/mcp/`) rather than full-suite, because the dev machine's data-volume flake on `tests/integration/` (documented in the 2026-05-10 entry below) makes a full-suite gate unreliable here and CI is the trusted gate for full coverage. Lint clean (`ruff check finlet/ tests/`). Smoke pytest: **1745 passed, 0 failed, 1532 warnings in 178.53s**. The warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change). Targeted OAuth e2e re-verify: `tests/auth/oauth/test_e2e_authcode_flow.py` → **4 xpassed in 104.14s** (the same 4 tests xfail-tracked below; preserved with `strict=False` per the convention documented in the 2026-05-10 entry — passed today on this machine but kept marked because the underlying aiosqlite asyncio-teardown race is known-intermittent). No new failures, no new xfail markers added, no entries removed this iteration. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. v1.0.1 scope: Team A (`finlet/api/app.py` + `finlet/mcp/auth.py` + new `tests/mcp/test_http_endpoint.py` + `tests/api/test_mcp_mount.py`), Team B (`finlet/cli_mcp_client.py` + `finlet/cli.py` + `tests/api/test_cli_mcp_client.py` NEW + `tests/test_cli.py`), Team C (`dashboard/agent-guide.html` + `dashboard/setup.html` + `dashboard/landing.html`).
>
> Last updated: 2026-05-10 by pre-flight check (exec-plan `V1_0_0_BLIND_WALK_FIXES` + Team H) — main HEAD = `f679447` (origin/main, post-bandit-hotfix; production deployed). Pytest full-suite run: **4409 passed, 4 xpassed, 12 errors in 875s**. The 4 xpassed are the existing `tests/auth/oauth/test_e2e_authcode_flow.py` entries below — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline below) and removing the markers would re-arm the gate on the same race the next time it surfaces. The 12 errors are all OAuth integration tests in `tests/integration/test_cli_stdio_e2e.py` + `tests/integration/test_mcp_oauth_e2e.py` — they all fail at the `live_server` session-scope fixture with `RuntimeError: live_server failed to come up on 127.0.0.1:<port> within 30s` after migrations and ~hundred-plus `benchmark-*` session_loaded events run inline during boot. This is a **local-environment data-volume flake** (the heavy benchmark dataset on this dev machine pushes startup past the 30s deadline), NOT a regression — CI run `25638684433` (workflow `CI`, branch `hotfix/bandit-b110-nosec`, 2026-05-10 20:15Z, on top of the same `f679447` tree) reports **4421 passed, 4 xpassed, 0 errors** on both py3.12 and py3.13 matrices for the identical tests. No new xfail markers added; no entries removed. Pre-existing Hypothesis portfolio-rounding flake remains unchanged.
>
> Last updated: 2026-05-09 by pre-flight check (exec-plan `MCP_FIRST_PHASE_5_CLI_STDIO`) — main HEAD = `24379ee` (post Phase 4e close-out). Pre-flight identified an aiosqlite + asyncio-loop teardown race in 4 OAuth e2e tests (`tests/auth/oauth/test_e2e_authcode_flow.py`) that ERROR with `RuntimeError: Event loop is closed` in the full-suite gate (the `aiosqlite._connection_worker_thread` outlives the test's asyncio loop, then the next test's loop closure surfaces the worker's pending `set_result`/`set_exception` call as the documented RuntimeError). The 4 tests are xfail'd (`strict=False`) so they continue to be exercised but don't fail the gate; isolated runs with `--timeout=120` still pass them (4/4 in 80.66s). No api_key/Bearer surface failures, no Phase 5 surface contamination — issue is pre-existing pytest async-teardown noise (in scope under tighter timeouts) NOT a regression from Phase 4e or any prior phase. Pytest baseline preserved (4356/4360 passing + 4 xfail).
>
> Last updated: 2026-05-09 (post-merge close-out) — exec-plan `MCP_FIRST_PHASE_4_OAUTH` sub-phase 4e shipped via single team merge (E1 `75223ba` bearer-only cutover + Phase 4 SHIPPED) plus finalize commits `4420745` (plan doc update — E1 SHIPPED + Session 5 checkpoint) and `6e76489` (eval-trace artifacts). **No entries added or removed this iteration.** Phase 4e closes the originally-planned 90-day dual-accept window: the api_key fallthrough is removed from `finlet/mcp/bearer_context.py:resolve_credential` and `finlet/mcp/auth.py:_authenticate_oauth_or_key`, and api_key on MCP tools now returns the documented Phase 4e rejection envelope (`{"error": "api_key authentication is no longer supported on MCP tools. Run 'finlet auth login' to obtain an OAuth Bearer token. See docs/MCP_OAUTH_MIGRATION.md."}`) as a 401. To preserve test-time call-site stability without leaking dual-accept logic into production, `tests/conftest.py` adds an autouse `_legacy_api_key_test_shim` fixture (sentinel-based; legacy MCP unit tests authenticating via `api_key=<key>` arguments keep working) — opt-out via `@pytest.mark.no_api_key_shim` on Phase 4e cutover tests. Post-merge full pytest gate: **4360 passed, 0 failed** (per E1's report, with the targeted 49/49 post-merge gate confirming new tests). No new failures introduced, no xfail markers added, no pre-existing failure tracked in this file resolved. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Pytest baseline updated upward (Phase 4e adds `tests/integration/test_mcp_oauth_e2e.py::TestGroup3BearerOnly` + `tests/conftest.py` shim coverage).
>
> Last updated: 2026-05-09 (post-merge close-out) — exec-plan `MCP_FIRST_PHASE_4_OAUTH` sub-phase 4c shipped via four sequential team merges (C1 `39afe87` JWT validator + `require_oauth` + 90-day sunset decision record, C2 `45024bb` MCP auth Bearer path + Surprise A/B cleanup, C3 `cebd327` 16 MCP tools dual-accept, C4 `ce97aa9` scope enforcement + UserTier mapping) plus one post-merge fixup `ff6909e` updating 3 test stubs (`tests/services/test_gate_unification.py` + `tests/api/test_benchmark_progress.py` + `tests/api/test_bug8_limit_stop_fills.py`) for the Option A 3-tuple migration in `resolve_credential` (caught by gate, not pre-merge validation). **No entries added or removed this iteration.** Phase 4c adds the Resource Server surface: `finlet/auth/oauth/jwt_validator.py` (NEW, joserfc EdDSA-pinned), `finlet/auth/deps.py` (`require_oauth` injector), `finlet/mcp/auth.py` (`_authenticate_oauth_or_key` + `enforce_scope`), `finlet/mcp/bearer_context.py` (NEW, ContextVar middleware + `resolve_credential` 3-tuple), and 16 MCP tools wired across `finlet/mcp/server.py` + `finlet/mcp/tools_benchmark.py` + `finlet/mcp/tools_portfolio.py` + `finlet/mcp/tools_trading.py`. New tests under `tests/mcp/test_oauth_jwt_validator.py`, `tests/mcp/test_oauth_dual_accept.py`, `tests/mcp/test_mcp_auth_oauth_path.py`, `tests/mcp/test_scope_enforcement.py`. Post-fixup gate: targeted on `tests/api/ tests/mcp/ tests/services/ tests/auth/` — **1929 passed, 0 failed** (10:25). Full CI-matching gate (post-fixup): in flight at close-out time. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Pytest baseline updated upward (Phase 4c adds the OAuth tests above).
>
> Last updated: 2026-05-08 (post-merge close-out) — exec-plan `MCP_FIRST_PHASE_4_OAUTH` sub-phase 4b shipped via four sequential team merges (B1 `0ba1717` data layer, B2 `471790d` AS endpoints, B3 `36d06bd` DCR, B4 `6a3adf3` router wiring); **no entries added or removed this iteration**. Phase 4b adds the OAuth Authorization Server surface (`finlet/auth/oauth/` package + migration `014_add_oauth_clients.py` + `pyproject.toml` adds `mcp[auth]>=1.27.0` and `joserfc>=1.0`) plus new tests in `tests/auth/oauth/`. Post-B4 full pytest gate: **4239 passed, 0 failed** (orchestrator confirmed). No new failures introduced, no xfail markers added, no pre-existing failure tracked in this file resolved. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Pytest baseline updated upward (Phase 4b adds tests under `tests/auth/oauth/`).
>
> Last updated: 2026-05-08 (post-merge close-out) — exec-plan `MCP_FIRST_PHASE_4_OAUTH` Team A1 merged to main (commit `e248382`); **no entries added or removed this iteration** (Phase 4a is pure docs — adds `docs/decisions/mcp-oauth-2-1-auth-model.md` decision record only; no Python source or test changes, no new pytest failures, no xfail markers, no resolved pre-existing failure tracked in this file). Test collection-only smoke: 4110 tests collect without import errors. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Pytest baseline preserved per the Phase 3 pre-flight refresh below.

> Last updated: 2026-05-08 by pre-flight check (exec-plan `MCP_FIRST_PHASE_3`) — main HEAD = `57f9ab3` (post Phase 2 close-out). Pytest baseline 4072/4072 passing (full suite, `uv run pytest tests/ -q --timeout=120`, 435.98s). No FAILED, no ERROR, no xfail markers needed. 75 warnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py` + aiosqlite `_connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown noise, no behavior change). Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table below) remains unchanged. Phase 3 scope (3-team plan: A middleware refinement, B docs, C tests) — deprecation-header policy refinement; no Python source changes anticipated outside `finlet/api/app.py` middleware + `tests/api/test_api_versioning.py`. No xfail markers added — full suite is green.

> Last updated: 2026-05-07 (post-merge close-out) — exec-plan `MCP_FIRST_PHASE_2` Teams A/B/C/D/E merged to main (final commit `82959df`); **no entries added or removed this iteration** (Phase 2 closes audit C1/H4/H6 and adds new tests in `tests/services/` but introduced no new pytest failures, no xfail markers, and resolved no pre-existing failure tracked in this file). Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Pytest baseline preserved per the pre-flight refresh below.

> Last updated: 2026-05-07 by pre-flight check (exec-plan `MCP_FIRST_PHASE_2`) — main HEAD = `ed19e91` (post Phase 2 plan-doc commit, on top of Phase 1 close-out at `d08dd3d`). Pytest baseline 4000/4000 passing (full suite, `uv run pytest tests/ -q --timeout=120 --maxfail=200 -p no:cacheprovider`, 395.18s). No FAILED, no ERROR, no xfail markers needed. 63 warnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py` + aiosqlite `_connection_worker_thread` "Event loop is closed" cleanup + starlette per-request-cookies deprecation; pre-existing async-teardown noise, no behavior change). Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table below) remains unchanged. Phase 2 scope per `docs/plans/exec-plans/MCP_FIRST_PHASE_2_EXEC_PLAN.md` (5 worktree spawns): Team A (`finlet/api/services/errors.py` NEW + `finlet/mcp/auth.py` validate_session_id parity + `tests/services/test_errors.py` NEW + `tests/mcp/test_mcp_auth.py` extension); Team B (`finlet/api/services/session_service.py` + `finlet/api/routes_session.py` + `finlet/mcp/server.py` session-tool block + new `tests/services/test_session_service.py` + `tests/mcp/test_mcp_server.py` extension); Team C (`finlet/api/services/trade_service.py` + `finlet/api/routes_trade.py` + `finlet/mcp/tools_trading.py` + new `tests/services/test_trade_service.py` + `tests/mcp/test_mcp_trading.py` extension — closes audit H6); Team D (`finlet/api/services/market_service.py` + `finlet/api/routes_market.py` + `finlet/mcp/server.py` plugin-query block + new `tests/services/test_market_service.py` + `tests/mcp/test_mcp_server.py` extension — closes audit H4 + C1); Team E (new `tests/services/test_gate_unification.py` cross-surface parity tests). No xfail markers added — full suite is green.

> Last updated: 2026-05-07 by pre-flight check (exec-plan `MCP_FIRST_PHASE_1`) — main HEAD = `d08dd3d` (post bug-hunt `20260507T163535Z3ac5` close-out + this iteration's plan-doc commit). Pytest baseline 3976/3976 passing (full suite, `uv run pytest tests/ -q --timeout=120`, 389.97s). No FAILED, no ERROR, no xfail markers needed. 72 warnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py` + aiosqlite `_connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown noise, no behavior change). Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table below) remains unchanged. No Playwright known-fail entries — `journey-06c-settings-billing.spec.ts:44` was permanently closed by the 2026-05-06 UI write-path launch cut (see Resolved section). Iteration scope (3 worktree spawns): Team A MCP correctness (`finlet/mcp/server.py`, `finlet/mcp/auth.py`, `finlet/mcp/tools_portfolio.py`, `finlet/mcp/tools_trading.py`, `tests/mcp/test_mcp_auth.py`, `tests/mcp/test_mcp_server.py` — audit findings C2/C3/H7); Team B CLI envelope (`finlet/cli.py`, `finlet/api/routes_auth_credentials.py`, `finlet/api/app.py`, `tests/test_cli.py` — audit findings C4/H8/H12); Team C benchmark log redaction (`finlet/leaderboard/runner.py`, `finlet/mcp/tools_benchmark.py`, `finlet/core/session.py` — audit findings H9). No xfail markers added — full suite is green.

> Last updated: 2026-05-07 by pre-flight check (bug-hunt `20260507T163535Z3ac5`) — main HEAD = `23505f4` (post ui-removal-launch-cut close-out + skill-eval-results commit). Pytest baseline 3976/3976 passing (full suite, `uv run pytest tests/ -q --timeout=120 -p no:cacheprovider`, 388.64s). No FAILED, no ERROR, no xfail markers needed. 71 warnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py` + aiosqlite `_connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown noise, no behavior change). Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table below) remains unchanged. No Playwright known-fail entries — `journey-06c-settings-billing.spec.ts:44` was permanently closed by the 2026-05-06 UI write-path launch cut (see Resolved section). Iteration scope per `docs/bug-hunt/20260507T163535Z3ac5/plan.md`: Team A dashboard copy fixes (`dashboard/api-keys.html`, `dashboard/api-keys.js`, `dashboard/agent-guide.html`, `dashboard/index.html`, `dashboard/setup.html` — replace `finlet auth register` with `finlet register` + setup.html post-signup-key-reveal copy fix); Team B session-creation modal default name (`dashboard/app.js`, `dashboard/index.html`, `tests/e2e/journey-04-dashboard.spec.ts`); Team C plugin permanent-degraded honest-copy (`finlet/plugins/news_plugin.py`, `finlet/plugins/sentiment_plugin.py`, `tests/plugins/test_news_plugin.py`, `tests/plugins/test_sentiment_plugin.py`); Team D favicon (`dashboard/favicon.ico` NEW or `finlet/api/app.py` redirect); Team F docs sync.
>
> Last updated: 2026-05-07 by pre-flight check (ui-removal-launch-cut) — main HEAD = `b3bc368` (post bug-hunt `20260507T042257Z3c76` close-out + aria-label-mismatch refactor docs/eval). Pytest baseline 3974/3974 passing (full suite, `uv run pytest tests/ -q --timeout=120 -p no:cacheprovider --ignore=tests/e2e`, 383.35s). No FAILED, no ERROR, no xfail markers needed. 83 warnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup + aiosqlite connection-worker thread "Event loop is closed" cleanup; pre-existing async-teardown noise, no behavior change). Pre-existing Playwright known-fail (`journey-06c-settings-billing.spec.ts:44` — "settings API key create and revoke flow") and Hypothesis portfolio-rounding flake remain unchanged — both are out of pytest gating scope. Iteration scope per `docs/refactor/ui-cut/plan.md`: 14 CUT dashboard files (trade-ticket.js, onboarding.{js,css}, settings.{html,css}, billing.{html,js,css}, pricing.html, marketplace.{html,js,css}, dialog-state-mirror.js, form-dirty-tracker.js), 5 TRIM dashboard files (app.js, index.html, settings.js, leaderboard-submit.js, modal-controller.js), event-contract.md prune, 9 CUT e2e tests (journey-{05-trade,06a-settings-profile,06b-settings-plugins,06c-settings-billing,06d-settings-danger-zone,08-billing,12-forgot-password,onboarding,modal-stacking}.spec.ts), CI guards, docs sweep. No Python touched in product paths (Team H optional API-route audit; Teams E-G touch tests/, scripts/, .github/, docs/).

> Last updated: 2026-05-06 by pre-flight check (bug-hunt `20260506T185234Z542e`) — main HEAD = `a851358` (post bug-hunt `20260506T154910Z0b41` close-out). Pytest baseline 3980/3980 passing (full suite, `uv run pytest tests/ -q --timeout=120`, 365.96s). No FAILED, no ERROR, no xfail markers needed. 72 RuntimeWarnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py` + 1 aiosqlite event-loop-closed in test teardown; pre-existing async-teardown noise, no behavior change). Pre-existing Playwright known-fail file path updated: `journey-06-settings.spec.ts:714` → `journey-06c-settings-billing.spec.ts:44` (the file was split into 4 surfaces in commit `96a5849` — see Known Failures table); test name unchanged ("settings API key create and revoke flow"). Hypothesis portfolio-rounding flake unchanged. Both Playwright entries remain out of pytest gating scope. Iteration scope per plan: `dashboard/app.js`, `dashboard/shared-nav.js`, `dashboard/onboarding.js`, `dashboard/index.html`, `dashboard/event-contract.md`, `docs/decisions/copy-api-key-dead-affordance.md`, plus Playwright extensions in `tests/e2e/journey-04-dashboard.spec.ts`, `tests/e2e/journey-05-trade.spec.ts`, `tests/e2e/journey-onboarding.spec.ts`. No Python touched.

> Last updated: 2026-05-06 by pre-flight check (bug-hunt `20260506T154910Z0b41`) — main HEAD = `4d620b1` (post bug-hunt `20260506T061637Z6594` Phase 5.5 close-out). Pytest baseline 3980/3980 passing (full suite, `uv run pytest tests/ -q --timeout=120 -x`, 362.32s). No FAILED, no ERROR, no xfail markers needed. 71 RuntimeWarnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py`; pre-existing async-teardown noise, no behavior change). Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis portfolio-rounding flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (`dashboard/onboarding.js`), Team D (docs + refactor-queue), and Team E (ledger) worktree spawns. Iteration scope is dashboard-JS + docs only; no Python touched.

> Last updated: 2026-05-06 by pre-flight check (CI/deploy stability reform — `docs/handoffs/2026-05-06-ci-deploy-execution-plan.md`) — main HEAD = `bee289c` (post `b458041` audit handoff + `bee289c` doc-archive cleanup commit). Pytest baseline 3974/3974 passing (full suite, `pytest tests/ -q --timeout=120 --tb=line --ignore=tests/e2e`, 353.12s). No FAILED, no ERROR, no xfail markers needed. 77 RuntimeWarnings remain (`aiosqlite._connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown flake in test fixtures, no behavior change). Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis portfolio-rounding flake remain unchanged — both are out of pytest gating scope for this exec-plan's Teams A (deploy-pin), B (smoke-extend), C (pre-push-fix), D (cve-allowlist), E (settings-split) worktree spawns.

> Last updated: 2026-05-05 by pre-flight check (bug-hunt `20260505T234713Z0c8a`) — main HEAD = `84074be` (post bug-hunt `20260505T213116Z45f1` close-out). Pytest baseline 3974/3974 passing (full suite, `uv run pytest tests/ -q --timeout=120 --tb=no --ignore=tests/e2e`, 344.54s). No FAILED, no ERROR, no xfail markers needed. 73 RuntimeWarnings remain (`aiosqlite._connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown flake in test fixtures, no behavior change). Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis portfolio-rounding flake remain unchanged — both are out of pytest gating scope for this iteration's dashboard worktree spawns (`dashboard/settings.js`, `dashboard/onboarding.js`, `dashboard/app.js`, `dashboard/index.html`).

> Last updated: 2026-05-05 (post-merge close-out) — bug-hunt `20260505T213116Z45f1` Teams A/B/C/D merged to main; **no entries removed this iteration** (no pre-existing failure in this file was resolved by the four shipped fixes — Team A `dashboard/app.js`, Team B `dashboard/modal-controller.js` + `dashboard/styles.css`, Team C `dashboard/trade-ticket.js`, Team D `dashboard/settings.js` — and no new Python failures introduced; the pre-existing `journey-06-settings.spec.ts:714` Playwright known-fail and Hypothesis portfolio-rounding flake remain unchanged). Pytest baseline preserved (3974/3974 passing per pre-flight refresh below).

> Last updated: 2026-05-05 by pre-flight check (bug-hunt `20260505T213116Z45f1`) — main HEAD = `bdeb62d` (post stat-card-overflow-contract refactor close-out). Pytest baseline 3974/3974 passing (full suite, `uv run pytest tests/ -q --timeout=120 --tb=short --ignore=tests/e2e`, 341.64s). No FAILED, no ERROR, no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (Order Log fee disclosure in `dashboard/app.js`), Team B (modal-controller hide non-top stack members in `dashboard/modal-controller.js` + `dashboard/styles.css`), Team C (trade-ticket close panel-class removal in `dashboard/trade-ticket.js`), and Team D (testPlugin DOM update in `dashboard/settings.js`) worktree spawns. 74 RuntimeWarnings remain (`aiosqlite._connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown flake in test fixtures, no behavior change).

> Last updated: 2026-05-05 by pre-flight check (refactor `stat-card-overflow-contract`) — main HEAD = `98aced6` (post Phase 5.5 retest artifacts for bug-hunt `20260505T175445Z750b`). Pytest baseline 3974/3974 passing (full suite, `uv run pytest tests/ -q --timeout=120 --ignore=tests/e2e`, 342.37s). No FAILED, no ERROR, no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (CSS contract: stat-card grid + tile overflow guards in `dashboard/styles.css` + `dashboard/index.html`) and Team B (docs: `docs/ARCHITECTURE.md` stat-card invariant + `docs/decisions/stat-card-overflow-contract.md` + `docs/LESSONS.md` entry) worktree spawns. Playwright tests skipped in pytest run; Team A's `tests/e2e/journey-sim-time-tile.spec.ts` extension will be exercised via `npx playwright test` in per-team validation.

> Last updated: 2026-05-05 (post-merge close-out) — bug-hunt `20260505T175445Z750b` outcome: 2 fixes merged (Team B + Team C), 1 demoted (Team A). Pre-flight pytest baseline 3974/3974 passing (recorded by the prior iteration's pre-flight refresh under `convention-enforcement-2026-05-05`); this iteration added zero Python tests (Team B added one Playwright regression to `tests/e2e/journey-04-dashboard.spec.ts`; Team C added one Playwright case to `tests/e2e/journey-sim-time-tile.spec.ts`; Team A shipped no code), so the Python pytest baseline is preserved at 3974/3974. Team A (commit `545e1de`) is verify-only — no code modified. Team B (commit `edc5ce7`, merge `548eac3`) is dashboard-JS + Playwright only — `dashboard/app.js` (hidden-anchor LineSeries on equity chart) + `tests/e2e/journey-04-dashboard.spec.ts` (`equity curve Y-axis spans meaningful range with low-variance data` regression); 10/10 journey-04 pass including the pre-existing buffered-history-replay regression. Team C (commit `125f2b2`, merge `f1d6581`) is dashboard-JS + dashboard-HTML + Playwright only — `dashboard/app.js` (`renderClock()` writes `formatDateShort` to `#sim-time` + sets `title=` to `formatDateTime`), `dashboard/index.html` (line 174 gains initial `title="--"`), `tests/e2e/journey-sim-time-tile.spec.ts` (3/3 pass with new date-only + title= contract); `dashboard/styles.css` UNCHANGED. No new pytest failures introduced this iteration; no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged.

> Last updated: 2026-05-05 (post-merge close-out) — bug-hunt `20260505T142400Z3330` Teams A/B/E merged to main + Phase 5.5 retest passed on deploy SHA `95d6562`. Team A (commit `b5dc82f`, merge `30a1d9c`) is dashboard-JS only — `dashboard/app.js` (`pnlArrow`/`pnlClass`/`formatPct` rounded-then-classify + Max Drawdown re-routed through helpers) and `tests/e2e/journey-05-trade.spec.ts` (post-fill no-arrow / no-`-0.00` / no-`pnl-negative` assertion); no Python touched. Team B (commit `f7d932a`, merge `c1edc8c`) is dashboard-JS only — `dashboard/app.js` (`formatLatency` helper, 5 explicit branches, short-circuit `null` for non-finite) and `tests/e2e/journey-04-dashboard.spec.ts` (canonical-format-set assertion); no Python touched. Team E (merge `548ddb4`) is ledger-only; +2 lines on `docs/bug-hunt/ledger.jsonl`. Three e2e fix-forwards landed post-deploy (`0e1e35b` first-text-node read, `47cd784` drop value-pinning + stub SSE, `95d6562` drop SSE stub — cards render via real SSE) — none touch product code. No new pytest failures introduced this iteration; no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged. Pytest baseline preserved.

> Last updated: 2026-05-05 by pre-flight check (refactor `convention-enforcement-2026-05-05`) — main HEAD = `4264779` (post pre-flight commit of plan + exec-trace + refactor-queue doc on top of `d159572` benchmark-blindness invariant docs). Pytest baseline 3974/3974 passing (full suite, `uv run pytest tests/ -q --timeout=120 --tb=no --ignore=tests/e2e`, 349.43s). No FAILED, no ERROR, no xfail markers needed. 88 RuntimeWarnings remain (`aiosqlite._connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown flake in test fixtures, no behavior change). Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (event-bus enforcement lint), Team B (form-dirty-tracker registry rollout), and Team C (onboarding registry rollout) worktree spawns.

> Last updated: 2026-05-04 by pre-flight check (bug-hunt `20260504T165106Z1ab2`) — main HEAD = `9c3843e` (post `0b33271` ci pre-push smoke + `d30e51a` settings.js backtick escape). Pytest baseline 3969/3969 passing (full suite, `uv run pytest tests/ -q --timeout=120`, 319.28s). No FAILED, no ERROR, no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (leaderboard schema/UI) + Team B (CLI session-create idempotency reorder) worktree spawns.

> Last updated: 2026-05-03 (post-merge close-out) — bug-hunt `20260503T195318Z43db` Teams A/B merged to main. Team A (commit `4c4e7da`, fix `713e3d5`) added `GET /v1/sessions/{id}/orders` + `GET /v1/sessions/{id}/orders/{oid}` aliases in `finlet/api/routes_session.py` plus `tests/api/test_orders.py` (7 new tests, all pass). Team B (commit `0baa8d5`, fix `056b417`) is dashboard-JS only — `dashboard/shared-nav.js` modified for the cookie-session-path redirect + dynamic relabel; the mobile drawer button inherits via existing `.click()` proxy in `dashboard/mobile-nav.js`; no Python touched; trusted-types lint passed. No new pytest failures introduced this iteration; no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged. Pytest baseline preserved.

> Last updated: 2026-05-03 by pre-flight check (bug-hunt `20260503T195318Z43db`) — main HEAD = `3420145` (Phase 5.5 retest close-out for prior iteration `20260503T030227Z2009`). Pytest baseline 3949/3949 passing (full suite, `uv run pytest tests/ -q --timeout=120 -x --ignore=tests/e2e`, 308.90s). No FAILED, no ERROR, no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (server-side route alias) + Team B (dashboard click-handler) worktree spawns.

> Last updated: 2026-05-03 by pre-flight check (bug-hunt `20260503T030227Z2009`) — main HEAD = `7cda296` (Team B merge close-out). Pytest baseline 3955/3955 passing (full suite, `uv run pytest tests/ -q --timeout=120`). No FAILED, no ERROR, no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's dashboard-only worktree spawns.

> No new failures introduced by bug-hunt `20260503T030227Z2009` (Teams A/B). Team A (trade-ticket render-on-read v3.1 terminal `repaintCash()` at every publisher site, commit `8c55a90`) is dashboard-JS only — `dashboard/trade-ticket.js` + `dashboard/app.js` modified plus extension to `tests/dashboard/trade-ticket-post-submit.spec.js` (node `--test`); the v3 atomic-mutate-then-publish contract is preserved (terminal `repaintCash()` is appended after publish at all 3 publisher sites); no Python touched; trusted-types lint passed; 7/7 trade-ticket-post-submit + 71/71 full dashboard test suite pass. Team B (Settings Ingest refetch gate-on-server-state-change, commit `cbd8340`) is dashboard-JS + Playwright only — `dashboard/settings.js` modified plus extension to `tests/e2e/journey-06-settings.spec.ts`; the `_pluginNeedsIngest()` predicate is unchanged (gate logic is purely additive — snapshot pre-click `[data-plugin-message]` text, recursive poll capped at 30 ticks, refetch when text drifts or cap reached); no Python touched; 27/27 journey-06-settings tests pass. The pre-existing journey-06-settings:714 known-fail entry remains the sole Playwright known-fail and is unchanged this iteration. Pytest baseline preserved.

> No new failures introduced by bug-hunt `20260502T211937Z7ddd` (Teams A/B). Team A (Settings Ingest button row-level pending state, commit `c489d53`) is dashboard-JS + dashboard-CSS only — `dashboard/settings.js` + `dashboard/settings.css` modified; the existing `loadPlugins()` render contract is preserved (transient `apiFetch` null preserves render); no Python touched; trusted-types lint passed. Team B (dashboard plugin-health widget default-status alignment, commit `4837c7f`) is dashboard-JS + dashboard-CSS only — `dashboard/app.js` + `dashboard/styles.css` modified; the canonical `GET /v1/plugins/health` endpoint contract is unchanged; one-line default-value swap at `dashboard/app.js:2212` aligns with `dashboard/settings.js:1040` ('unknown' instead of 'healthy'); no Python touched; trusted-types lint passed. The pre-existing journey-06-settings:714 known-fail entry remains the sole Playwright known-fail and is unchanged this iteration. Pytest baseline preserved.

> No new failures introduced by bug-hunt `20260502T142726Z7b36` (Teams A/B/C). Team A (Trade Ticket post-submit refetch+republish, commit `109686c`) is dashboard-JS + Playwright only — added `tests/dashboard/trade-ticket-post-submit.spec.js` (node `--test`) and extended `tests/e2e/journey-05-trade.spec.ts`; no Python touched. Team B (probe-message sanitization across price/news/fundamentals plugins + new `POST /v1/plugins/{name}/ingest` stub at `finlet/api/routes_plugins.py`, commit `ad0adb0`) added new test file `tests/api/test_plugins_ingest.py` covering the 202+job_id path and 404-for-unknown-plugin path, plus extensions to `tests/api/test_plugin_health.py` and `tests/plugins/test_price_plugin.py` for the sanitized error wording; the existing `routes_health._check_price_data_status` translator continues to map `"S3 unreachable"` → `s3_unreachable` (pinned wording is part of the response contract). Team C (Settings consume canonical `/v1/plugins/health` + Ingest button, commit `2d200db`) is dashboard-JS/HTML/CSS only — extended `tests/e2e/journey-06-settings.spec.ts` with the new Ingest-button affordance assertion; no Python touched. Pytest baseline preserved.

> No new failures introduced by refactor `close-patch-ineffective-2026-05-02` (Teams A/B/C). Team A (plugins remove CLI + email validator empty-string clear, commit `6c72541`) added 4 new `TestPluginsRemoveCommand` tests + 1 new `TestPlugins.test_update_plugin_clears_credentials_with_empty_strings` — 19/19 in the targeted gate; ruff + mypy pass. Team B (onboarding.js:382-385 profile reach-in deletion, commit `076189c`) is dashboard-JS only — added 3 new tests in `tests/dashboard/onboarding-checklist.spec.js` (23/23 pass). Team C (settings.css unsaved-banner display:none switch, commit `e4cdb5e`) is dashboard CSS/HTML/JSDoc only — form-dirty-tracker unit tests 6/6 still pass; new Playwright spec at `tests/playwright/settings-dirty-banner.spec.js` NOT auto-discovered by the existing `tests/e2e/playwright.config.ts` (`testDir: '.'`); session-checkpoint Phase 5.5 retest envelope will exercise live-site cold-load. Pytest baseline preserved.

> No new failures introduced by bug-hunt `20260501T234103Z1a49` (Teams A/B/C/D/E). Team A (engine equity-curve snapshot-on-fill, commit `29e9ac5`) added 3 new tests in `tests/core/test_session.py` + `tests/api/test_portfolio.py`; existing 3902 pytest baseline preserved. Team B (dashboard SSE republish portfolio:updated, commit `3a2bf46`) is dashboard-JS + Playwright only; new assertion in `tests/e2e/journey-05-trade.spec.ts`. Team C (settings dirty-banner aria-hidden sync + synthetic-key gate, commit `87a37b6`) is dashboard only; new cold-load Playwright test in `tests/e2e/journey-06-settings.spec.ts`. Team D (onboarding `profile:saved` outcome event, commit `4924948`) is dashboard-JS only; new tests in `tests/dashboard/onboarding-checklist.spec.js`. Team E (price plugin S3-reachability probe + 60s probe cache, commit `76f4724`) added 3 new tests in `tests/api/test_plugin_health.py` + `tests/plugins/test_price_plugin.py`. Pytest baseline preserved.

> No new failures introduced by bug-hunt `20260501T172055Z127b` (Teams A/B). Team A (EDGAR plugin hot-reload + actionable CLI message, commit `1a07a1e`) added 4 new tests in `tests/test_cli.py::TestPluginsAddCommand` and 3 new tests in `tests/api/test_plugin_health.py::TestPluginReload`; full plugin/registry suite 756/756 + combined CLI+plugin-health spot 61/61 passed. Team B (settings password-form wrap, commit `ce5fa52`) is dashboard-HTML/JS only — `dashboard/settings.html` + `dashboard/settings.js` were edited; trusted-types lint passed; dashboard pytest selection 5/5 passed. Findings 1 (portfolio AttributeError) and 4 (plugins list mismatch) shipped no code change this iteration — both are pypi-release-lag artifacts (already fixed in main at `cc6cddf` and `1a3c17e`); see `docs/decisions/pypi-release-cadence.md`. Pytest baseline preserved.

> No new failures introduced by bug-hunt `20260430T222711Z3666` (Teams A/B/C/D). Team A (auth `_OptionalUser` cookie-fall-through, commit `47c7e79`) updated 2 existing tests in `tests/api/test_session_auth.py` to match the new contract (validate-probe stale-cookie returns anonymous, not 401) and extended `tests/auth/test_session_validate_probe.py` with parity coverage. Team B (CLI idempotency + plugins-list parity, commit `1616ade`) added 4 new tests in `tests/test_cli.py`; spot-check across 86 adjacent API tests (sessions/idempotency/plugin-health) passed. Team C (form-dirty-tracker pre-clear, commit `dba4c83`) is dashboard-JS only — Test 6 in `tests/dashboard/form-dirty-tracker.spec.js` reproduces the bug without the fix and passes with it. Team D (selectSession publish, commit `91922c7`) added 2 tests in `tests/dashboard/onboarding-checklist.spec.js`; node `--test` 17/17 + sibling 30/30; pytest spot-check on idempotency/e2e session 10/10. Pytest baseline preserved.

> No new failures introduced by the trusted-types refactor. Pytest baseline (3902/3902 passing) preserved through the merge. The refactor scope (lint script + dashboard `*.html` files + `api-utils.js` reporter + Playwright telemetry spec) does not touch Python — pytest count is stable.

Python suite: 0 failures out of 3902 tests (full suite, `uv run pytest tests/ -q --timeout=120 --ignore=tests/e2e`, 569.62s). Pre-flight verified 2026-04-30 ahead of trusted-types refactor exec-plan; post-merge baseline preserved. Pre-flight base SHA: `5a579a7` (main HEAD = `plan: trusted-types refactor`). No new pytest failures, no xfail markers needed. 60 RuntimeWarnings remain (auth service AsyncMock cleanup; pre-existing, no behavior change).

Playwright `journey-06c-settings-billing.spec.ts:44` ("settings API key create and revoke flow"): closed by the 2026-05-06 UI write-path launch cut. The test (and all four `journey-06{a,b,c,d}-settings-*.spec.ts` surfaces) covered `dashboard/settings.html`, which was cut to `legacy/dashboard-ui/settings.html` and `legacy/tests/e2e/journey-06{a,b,c,d}-*.spec.ts` on 2026-05-06. The flaky modal-stacking interaction is no longer in production scope — `dashboard/api-keys.html` (the read-only replacement) does not host a create-key form. If the legacy spec is ever revived for restoration smoke tests, run via `tests/e2e/legacy.playwright.config.ts`.

## Known Failures (xfailed)

| Test | File | Reason | Since |
|------|------|--------|-------|
| test_e2e_authcode_flow_against_live_fastapi_app | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-09 |
| test_authorize_without_login_redirects_to_login_with_next | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-09 |
| test_authorize_with_bearer_runs_existing_flow | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-14 |
| test_authorize_with_session_cookie_runs_existing_flow | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-14 |
| test_token_endpoint_unsupported_grant_type | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-09 |
| test_token_endpoint_emits_no_deprecation_headers | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-09 |
| test_create_session_with_readonly_jwt_returns_insufficient_scope | `tests/mcp/test_scope_enforcement.py` | StreamableHTTPSessionManager singleton conflict with sibling MCP-HTTP tests in the same process (test_http_endpoint / test_oauth_dual_accept). Test passes deterministically in isolation. The session-manager is process-global by design in mcp[auth] 1.27.0; running two `create_app()` calls in one process re-invokes `.run()` which raises RuntimeError. Marked xfail strict=False — sibling unit tests provide load-bearing scope coverage. | 2026-05-21 |

## Known Flakes

| Test | File | Reason | Since |
|------|------|--------|-------|
| Hypothesis portfolio rounding properties | `tests/core/test_property_based.py` | Hypothesis occasionally generates extreme float sequences that expose sub-penny rounding drift after many buy/sell cycles. Cash rounding to 2dp (commit aa451d9) mitigates but does not eliminate all edge cases under property-based fuzzing. Flake rate is very low (<1% of runs). | 2026-03-29 |

## Resolved

`tests/e2e/journey-06-settings.spec.ts:289` — settings API key create and revoke flow. `dashboard/settings.html` migrated to the post-modal-stacking `class="modal-overlay fl-modal"` + `data-modal-id` convention, with `openModal/closeModal` in `settings.js` now thin wrappers around `window.finletModal.open/close`. Two collateral fixes shipped in the same merge: dirty-state tracker now skips inputs inside `.modal-overlay` (the Create-Key modal name field was triggering the unsaved-changes banner), and the journey-06 submit-button fallback selector was scoped to `#create-key-modal`. 16/16 settings tests now passed (commit `b3cb2f1`, fix `ac8e0b2`) at the time. Resolved 2026-04-28. **Note 2026-04-29:** regression resurfaced (line `:444` after additions). **Note 2026-05-06:** entry permanently closed by UI write-path launch cut — `dashboard/settings.html` and the `journey-06{a,b,c,d}-settings-*.spec.ts` surfaces were git-mv'd to `legacy/dashboard-ui/` and `legacy/tests/e2e/`. The create-key modal is no longer hosted in production; production `dashboard/api-keys.html` is read-only.

CLI smoke tests in `tests/e2e/journey-14-cli-session.spec.ts` (5 tests) and `tests/e2e/journey-15-cli-plugins.spec.ts` (7 tests) -- The specs invoked a bare `finlet` binary via `execSync`, which only resolves when `.venv/bin/` is on the spawn PATH; full-suite Playwright runs without venv-activated PATH all failed at the `Command failed: finlet ...` step. Switched the invocation to `uv run python -m finlet`, centralised behind a `FINLET_CLI` constant in `tests/e2e/helpers.ts`. `uv run` resolves the project venv from `pyproject.toml` / `uv.lock` independent of PATH state, and `python -m finlet` invokes the package's `__main__` module with identical behaviour to the binary. All 12 tests now pass (verified via `npx playwright test tests/e2e/journey-14-cli-session.spec.ts tests/e2e/journey-15-cli-plugins.spec.ts --reporter=line`). Fixed in commit `38f9726`. Resolved as of 2026-04-28.

FIELD_AUDIT_FIXES sprint (2026-04-10): Per-ticker circuit breaker scoping (Team A), position price history fallback under open breakers (Team B), percentage-scale portfolio metrics (Team C), batch time advance in CLI and MCP (Team D), `GET /market/tickers` + `list_available_tickers` MCP tool (Team E), fundamentals cache TTL invalidation + atomic S3 downloads (Team F), setup page consolidation (Team G). All fixed; +33 new tests shipped (3522 -> 3555 total).

User Feedback Fixes sprint (2026-04-09): Circuit breaker state bleeding between sessions (Team A), MARKET orders silently queuing as PENDING when price plugin errored (Team B), CLI `portfolio` command crashing on dict iteration (Team C), `_query_history()` silently returning empty on no data (Team D). All fixed; new tests added.

E2E Playwright failures in `journey-04-dashboard.spec.ts` and `journey-08-billing.spec.ts` -- Stale assertions referencing marketplace nav and hidden billing tiers that were removed in commit `451af35`. Fixed by removing the stale assertions (commit `e30a830`). Resolved as of 2026-04-06.

`ModuleNotFoundError: finlet.api` on production server -- `[tool.hatch.build.targets.wheel]` in `pyproject.toml` had an `only-include` whitelist that excluded all subpackages (`api/`, `core/`, `plugins/`, etc.). The server installed the wheel via `pip install -e .` and got only the three thin-client files. Fixed by removing the `only-include` section entirely (commit `1d4b247`). See `docs/decisions/remove-hatch-wheel-whitelist.md`. Resolved as of 2026-04-06.

`test_get_session_found` (`tests/mcp/test_mcp_server.py`) -- Previously failed due to stale `finlet.mcp.auth` module reference. Now passes. Resolved as of 2026-04-02.

`test_different_user_agent_triggers_warning`, `test_different_ip_triggers_warning`, `test_both_ip_and_ua_change_triggers_two_warnings` (`tests/api/test_session_fingerprint.py`) -- Previously xfail due to structlog `capture_logs()` not intercepting warnings. Now pass; xfail markers removed. Resolved as of 2026-04-02.

`test_value_equation_after_buy_sell` (`tests/core/test_property_based.py:81`) -- Floating-point comparison bug where `cost > self._cash` rejected orders when cost == cash. Fixed with epsilon tolerance (commits 5bb8e67, b0f53e2).

The 14 `tests/leaderboard/test_api_driven_strategy.py` failures (`KeyError: 'benchmark_price'`) were caused by `BenchmarkPricePlugin` not being registered in `PluginRegistry` circuit breakers. Fixed by handling plugins without circuit breaker registration in `query_plugin()` (commit c7a7687).

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet show e98f637 --stat' in /Users/justnau/finlet
 succeeded in 0ms:
commit e98f637438b23b6f3d44520d34f52645ddb92861
Author: Justin Nam <justnau@Justins-MacBook-Air-2.local>
Date:   Fri May 22 23:12:40 2026 -0500

    [Team E v2.0.0]: bump 2.0.0 + CHANGELOG repair (add [1.1.0] from manual-overhaul evidence; fold [Unreleased] into [2.0.0])

 CHANGELOG.md   | 312 +++++++++++++++++++++++++++++++++++++--------------------
 pyproject.toml |   2 +-
 2 files changed, 202 insertions(+), 112 deletions(-)

codex
The stat confirms the commit only modified the two declared files, so scope is clean at the file-list level. I’m now reading the actual diff and the rendered changelog sections so I can check ordering, required bullets, and whether the packaging metadata still builds the expected wheel.
exec
/bin/zsh -lc 'git -C /Users/justnau/finlet rev-parse HEAD' in /Users/justnau/finlet
 succeeded in 0ms:
86813d6de81ab560aab00b582444dc8b49b88b67

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet show e98f637 -- pyproject.toml' in /Users/justnau/finlet
 succeeded in 0ms:
commit e98f637438b23b6f3d44520d34f52645ddb92861
Author: Justin Nam <justnau@Justins-MacBook-Air-2.local>
Date:   Fri May 22 23:12:40 2026 -0500

    [Team E v2.0.0]: bump 2.0.0 + CHANGELOG repair (add [1.1.0] from manual-overhaul evidence; fold [Unreleased] into [2.0.0])

diff --git a/pyproject.toml b/pyproject.toml
index bc4a609..e4cd56f 100644
--- a/pyproject.toml
+++ b/pyproject.toml
@@ -1,6 +1,6 @@
 [project]
 name = "finlet"
-version = "1.1.0"
+version = "2.0.0"
 description = "A historical market simulation environment for testing AI trading agent reasoning against real market data."
 readme = "README.md"
 license = "LicenseRef-Proprietary"

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet show e98f637 -- CHANGELOG.md' in /Users/justnau/finlet
 succeeded in 0ms:
commit e98f637438b23b6f3d44520d34f52645ddb92861
Author: Justin Nam <justnau@Justins-MacBook-Air-2.local>
Date:   Fri May 22 23:12:40 2026 -0500

    [Team E v2.0.0]: bump 2.0.0 + CHANGELOG repair (add [1.1.0] from manual-overhaul evidence; fold [Unreleased] into [2.0.0])

diff --git a/CHANGELOG.md b/CHANGELOG.md
index 2df739a..c73a20a 100644
--- a/CHANGELOG.md
+++ b/CHANGELOG.md
@@ -5,6 +5,207 @@ All notable changes to Finlet are documented in this file.
 The format is based on [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/),
 and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).
 
+## [2.0.0] — 2026-05-22
+
+Pure-MCP cutover. The CLI no longer dispatches agentic commands over
+MCP-over-HTTP; agents address the cloud `/mcp` endpoint directly through
+their own MCP client (Claude Desktop, Claude Code, Codex CLI, Cursor,
+Windsurf, generic MCP client). The local CLI keeps only the operator
+surface (`register`, `auth`, `plugins`, `serve`, `mcp serve`, `manual`)
+plus the `finlet mcp serve` stdio bridge for clients that wire stdio
+subprocesses. Ships alongside the session-level blind mode landed
+2026-05-22 in PR [#134](https://github.com/finlet-dev/finlet/pull/134).
+
+### Added (session-level blind mode — 2026-05-22)
+
+- **`create_session(blind: bool = False)`** across MCP (canonical
+  `mcp__finlet__create_session`), REST (`POST /v1/sessions`), and CLI
+  (`finlet sessions create --blind`). When `True`, the session is
+  created with `name = "blind-{session.id[:8]}"` (auto-generated,
+  immutable), a `BlindMapping` is attached BEFORE the first
+  `save_session`, and every `@blind_error_mapper`-decorated MCP tool
+  returns `T_NNNN` tickers + `Day_N` dates for that session. Same
+  plumbing as the canonical 5-scenario benchmark blind path
+  (`BlindMapping`, `assert_no_real_blinded_data`,
+  `_KNOWN_BENCHMARK_TICKERS`, SSE/trace blinding). MCP-first; REST +
+  CLI derive from MCP. Decision record:
+  `docs/decisions/session-level-blind-extends-create-session.md`.
+  Architecture: `docs/ARCHITECTURE.md` → "Session-Level Blind Mode".
+- **`SessionResponse.blind: bool`** populated at the top level of
+  `session_response()` (mirrors the existing `public` field).
+  Dashboards can render an owner-side "blind active" badge as a
+  follow-up.
+- **`freeze_time` MCP tool now blinds the clock response** for blind
+  sessions. Closes a gap where `get_sim_time` and `advance_time`
+  blinded but `freeze_time` returned real clock dates. Other
+  clock-touching MCP tools audited for the same pattern.
+
+### Changed (session-level blind mode — 2026-05-22)
+
+- **Hardcoded 50-ticker per-session universe cap removed.** Catalog
+  membership is the gate now: every requested ticker MUST be in
+  `_UNIVERSE_SOURCES` (270 tickers — 199 US equities + 71 US ETFs).
+  Off-catalog tickers get `"ticker '<X>' not in catalog — call
+  list_available_tickers"`. Same check fires on
+  `configure_session(universe=...)` for non-blind sessions (Codex
+  Step 10h BLOCKER 5 closed the back door). Pricing tiers update:
+  Free + Builder advertise "Unlimited tickers per session";
+  `max_tickers=None` on both tiers in
+  `finlet/billing/stripe_config.py`.
+- **`configure_session` lockdown on blind sessions.** Both `universe`
+  and `name` changes are rejected with 409 for blind sessions. The
+  `BlindMapping` is built at create-time; changing the universe
+  mid-session would invalidate the `T_NNNN` ↔ real-ticker
+  correspondence the agent has been working with.
+- **`_blind_mapping_for(session)` moved** from
+  `finlet/api/serializers.py` into
+  `finlet/api/services/session_service.py` (single source of truth).
+  `serializers.py` re-imports it. Direction is forward (services →
+  serializers).
+
+### Changed (CLI surface — pure-MCP cutover)
+
+- **CLI surface reduced to the MCP-bootstrap minimum.** Six command
+  families survive: `finlet serve`, `finlet register`, `finlet auth`
+  (`login` / `logout` / `status`), `finlet plugins` (`list` / `add` /
+  `remove`), `finlet mcp serve`, `finlet manual`. Agentic commands
+  are addressed through an MCP client directly against
+  `https://finlet.dev/mcp` (or the `finlet mcp serve` stdio bridge
+  for stdio-only clients). Operator and onboarding commands remain
+  local; agent dispatch leaves the CLI.
+- **Dashboard agent-guide rewritten for MCP-first onboarding.** The
+  8-tab client matrix in `dashboard/agent-guide.html` now leads with
+  the cloud `/mcp` endpoint plus `Authorization: Bearer` (OAuth or
+  api_key). Copy-paste setup blocks emit canonical config for Claude
+  Desktop, Claude Code, Codex CLI, Cursor, Windsurf, VS Code, generic
+  MCP client, and REST.
+- **`finlet manual quickstart` aligned to the canonical 5-step
+  MCP-first script.** The CLI walkthrough (and the `finlet/manual/`
+  package) match what `dashboard/agent-guide.html` and
+  `dashboard/llms.txt` advertise; the generator (`finlet.manual.
+  generate_llms_txt --check`) is the drift gate.
+
+### Removed
+
+- **CLI agentic dispatch surface.** Deleted commands (12 entry points
+  across 3 sub-apps + top-level):
+  - `session` sub-app — `create`, `list`, `delete`, `publish`.
+  - `benchmark` sub-app — `start`, `progress`, `decrypt`,
+    `visibility`.
+  - Top-level — `advance`, `order`, `portfolio`, `status`.
+- **`finlet/cli_mcp_client.py`** (entire module) — the v1.0.1
+  MCP-over-HTTP dispatcher and its `MCPDispatchError` surface. Agents
+  now own their own MCP client.
+- **Internal CLI helpers** retired alongside the dispatcher:
+  `_dispatch_mcp_tool`, `_translate_mcp_error`, `_emit_envelope`,
+  `_resolve_bearer_token`, `_AUTH_REQUIRED_MARKERS`,
+  `_AUTH_REQUIRED_HINT`, `_AsyncioTimeoutError`,
+  `_normalize_start_iso`, the top-level `import asyncio`, the
+  `session_app` + `benchmark_app` Typer sub-apps and their
+  `add_typer` registrations, and the
+  `from finlet.cli_mcp_client import ...` import.
+- **Stale module docstring** describing the deleted dispatch model
+  rewritten to reflect the v2.0.0 operator-only surface.
+
+### Migration notes
+
+- **Wire agents directly to `https://finlet.dev/mcp`.** Pure-MCP
+  clients (Claude Desktop, Claude Code, Codex CLI, Cursor, Windsurf,
+  generic MCP) authenticate with `Authorization: Bearer <jwt>` (OAuth
+  AS-minted) or `Authorization: Bearer fnlt_<api_key>`. The 8-tab
+  matrix in `dashboard/agent-guide.html` and `finlet manual
+  client-matrix` document the copy-paste config blocks.
+- **Stdio-only clients keep using `finlet mcp serve`.** The bundled
+  stdio bridge translates `FINLET_API_KEY` / `FINLET_OAUTH_BEARER`
+  into the MCP `initialize` handshake. `finlet/cli.py` still wires
+  `mcp serve`; only the per-tool convenience commands left.
+- **Scripts that called `finlet session create`, `finlet order`,
+  `finlet portfolio`, `finlet advance`, `finlet status`, `finlet
+  benchmark *` migrate to calling MCP tools directly** (any MCP
+  client SDK, or `curl` against `/mcp` with a JSON-RPC body). Tool
+  names + argument shapes are unchanged.
+- **No deprecation period.** Zero PyPI consumers exist on the v1.x
+  CLI dispatch path at cutover time (pre-launch, no customers); the
+  removal lands directly. See `[[project-pre-launch-no-customers]]`.
+
+### PR references
+
+- v2.0.0 pure-MCP cutover (this PR) — CLI surgery (Team A), CLI test
+  trim + MCP visibility assertions (Team B), manual + registry +
+  llms.txt regen (Team C), dashboard HTML examples + data-copy
+  attributes (Team D), version bump + CHANGELOG repair (Team E,
+  capstone).
+- Session-level blind mode — PR [#134](https://github.com/finlet-dev/finlet/pull/134)
+  (2026-05-22, prod sha `27d96ca`).
+
+## [1.1.0] — 2026-05-16
+
+USER_MANUAL_OVERHAUL ship. The `finlet manual` CLI subcommand and the
+~200-anchor error-envelope convention become reachable to any operator
+who `pip install finlet`. Minor (not patch) because the surface is
+additive and user-visible.
+
+### Added
+
+- **`finlet manual` CLI subcommand** — seven topics (`quickstart`,
+  `auth-model`, `session-lifecycle`, `transports`, `client-matrix`,
+  `plugin-matrix`, `errors`) with `--list` / `--search` /
+  `--format=json` modes and anchor-scoped lookups (e.g. `finlet
+  manual errors#missing-bearer`). Hatchling artifacts directive
+  `[tool.hatch.build.targets.wheel] artifacts = ["finlet/manual/*.md"]`
+  ships the topic files inside the wheel; loader is
+  `importlib.resources.files("finlet.manual")`.
+- **Error-anchor convention** — 13 frozen kebab-case anchor IDs in
+  `finlet/manual/errors.md`; ~200 error envelopes across REST,
+  billing, OAuth, MCP, and named plugins suffix-appended with
+  `See: finlet manual errors#<anchor>`.
+- **`_AUTH_REQUIRED_MESSAGE` constant** in `finlet/mcp/auth.py`
+  dedups the 19-site MCP auth-required surface.
+- **Per-surface contract gates** —
+  `tests/api/test_error_anchors.py`,
+  `tests/billing/test_error_anchors.py`,
+  `tests/auth/oauth/test_error_anchors.py`,
+  `tests/plugins/test_error_anchors.py`.
+- **`dashboard/llms.txt` regen pipeline + freshness guard** —
+  deterministic generator in `finlet/manual/generate_llms_txt.py`
+  with `--write` / `--check` modes. Three-layer drift gate:
+  pre-commit hook (`scripts/lint-llms-txt-fresh.sh`), CI lint step
+  (`.github/workflows/ci.yml`), and `--write` remediation.
+- **CLI command see-also footers** — 10 `finlet` command docstrings
+  gained `See: finlet manual <topic>` footers in their `--help`
+  output.
+
+### Changed
+
+- **`dashboard/agent-guide.html` rewritten as an 8-tab matrix** —
+  Claude Desktop, Claude Code, Cursor, Codex, Windsurf, VS Code,
+  Generic MCP, REST. OAuth-first auth flip (was api_key-first
+  pre-Phase-4e); api_key documented as headless/CI fallback. Five
+  troubleshooting deep-links anchor at `finlet manual errors#<anchor>`.
+- **`README.md:66` MCP config fix** — `args: ["mcp"]` →
+  `args: ["mcp", "serve"]` (matches the Phase-5 Typer sub-app
+  rename).
+- **`finlet/api/deprecation.py` `/mcp(/.*)?$` whitelist** —
+  prevents the legacy deprecation-header middleware from tagging MCP
+  paths as deprecated alongside `/v1/` routes.
+- **`.github/workflows/ci.yml`** flipped from `paths-ignore` to a
+  positive paths allowlist to keep gates dormant on doc-only PRs.
+
+### Architecture
+
+- New decision records: `docs/decisions/error-anchor-convention.md`
+  and `docs/decisions/dashboard-llms-txt-regen-pipeline.md`.
+
+### PR references
+
+- USER_MANUAL_OVERHAUL ship — PR [#85](https://github.com/finlet-dev/finlet/pull/85)
+  (`734da2e`, merged 2026-05-15).
+- gitleaks deploy-fix — PR [#86](https://github.com/finlet-dev/finlet/pull/86)
+  (`d0461d6`).
+- `release: bump to v1.1.0` — PR [#87](https://github.com/finlet-dev/finlet/pull/87)
+  (`9a88842`, PyPI publish run `25955438689`).
+- E2E gate — `tests/e2e/journey-19-agent-guide.spec.ts`.
+
 ## [1.0.4] — 2026-05-12
 
 ### Fixed
@@ -50,117 +251,6 @@ Per v1.0.3 blind-walk findings
   block would have seen "MCP server crashed immediately" because bare
   `finlet mcp` prints help and exits 0. Docs-only patch; no PyPI re-publish.
 
-## [Unreleased]
-
-### Added (session-level blind mode — 2026-05-22 exec-plan v12)
-
-- **`create_session(blind: bool = False)`** across MCP (canonical
-  `mcp__finlet__create_session`), REST (`POST /v1/sessions`), and CLI
-  (`finlet sessions create --blind`). When `True`, the session is created
-  with `name = "blind-{session.id[:8]}"` (auto-generated, immutable), a
-  `BlindMapping` is attached BEFORE the first `save_session`, and every
-  `@blind_error_mapper`-decorated MCP tool returns `T_NNNN` tickers + `Day_N`
-  dates for that session. Same plumbing as the canonical 5-scenario benchmark
-  blind path (`BlindMapping`, `assert_no_real_blinded_data`,
-  `_KNOWN_BENCHMARK_TICKERS`, SSE/trace blinding). MCP-first; REST + CLI
-  derive from MCP. Decision record:
-  `docs/decisions/session-level-blind-extends-create-session.md`.
-  Architecture: `docs/ARCHITECTURE.md` → "Session-Level Blind Mode" at
-  ~line 1620.
-- **`SessionResponse.blind: bool`** populated at the top level of
-  `session_response()` (mirrors the existing `public` field). Dashboards
-  can render an owner-side "blind active" badge as a follow-up.
-- **`freeze_time` MCP tool now blinds the clock response** for blind
-  sessions. Closes a gap in HEAD where `get_sim_time` and `advance_time`
-  blinded but `freeze_time` returned real clock dates. Other clock-touching
-  MCP tools (`step_time`, `play`, `pause_clock` if present) audited for the
-  same pattern.
-
-### Changed (session-level blind mode — 2026-05-22 exec-plan v12)
-
-- **Hardcoded 50-ticker per-session universe cap removed.** Catalog
-  membership is the gate now: every requested ticker MUST be in
-  `_UNIVERSE_SOURCES` (270 tickers — 199 US equities + 71 US ETFs). Off-
-  catalog tickers get `"ticker '<X>' not in catalog — call
-  list_available_tickers"`. Same check fires on `configure_session(universe=...)`
-  for non-blind sessions (Codex Step 10h BLOCKER 5 closed the back door).
-  Pricing tiers update: Free + Builder advertise "Unlimited tickers per
-  session"; `max_tickers=None` on both tiers in `finlet/billing/stripe_config.py`.
-- **`configure_session` lockdown on blind sessions.** Both `universe`
-  and `name` changes are rejected with 409 for blind sessions. The
-  `BlindMapping` is built at create-time; changing the universe mid-session
-  would invalidate the `T_NNNN` ↔ real-ticker correspondence the agent has
-  been working with.
-- **`_blind_mapping_for(session)` moved** from `finlet/api/serializers.py`
-  into `finlet/api/services/session_service.py` (single source of truth).
-  `serializers.py` re-imports it. Direction is forward (services →
-  serializers).
-
-### Documentation (session-level blind mode — 2026-05-22 exec-plan v12)
-
-- **Audience matrix corrected** in
-  `docs/brainstorms/SESSION_LEVEL_BLIND_REQUIREMENTS.md`. The v2 doc
-  oversimplified the "Authenticated owner" column to "Real everywhere";
-  the v3 correction reflects HEAD's MIXED owner behavior (REAL on
-  `routes_session.py` / `routes_portfolio.py::/portfolio` / `routes_clock.py`
-  / `routes_trade.py`; BLINDED on `routes_portfolio.py::/trace` /
-  `routes_market.py::*` / `routes_sse.py`). This work preserves the mix —
-  harmonization is deferred and tracked in the requirements doc's
-  "Deferred Ideas" section.
-- **Decision record** `docs/decisions/session-level-blind-extends-create-session.md`
-  locks the extend-vs-fork choice, the auto-name policy, the catalog-
-  enforcement decision, the visibility-flags-as-reveal-lifecycle model, and
-  the scope boundary against owner-surface harmonization.
-
-### Fixed (blind-walk follow-up)
-
-The 2026-05-10 blind-agent cold-start re-walk of the v1.0.0 release candidate
-(see `docs/launch/blind-agent-coldstart-report-v1.0.0.md`) surfaced ten launch
-blockers / regressions in the documented happy path. Teams A-G deliver the
-fixes; each entry below is a stub that the responsible team will expand with
-the shipped remediation as their PR lands.
-
-- BLOCKER #1 — `pip install finlet` does not install `mcp`, so every v1.0.0
-  CLI command crashes with `ModuleNotFoundError` at module load. Fix: move
-  the client-side `mcp` import out of the `server` extras (or lazy-import
-  inside Typer command handlers).
-- BLOCKER #2 — `finlet auth login` is rejected by the prod OAuth server with
-  `invalid_client: Unknown client_id='finlet-cli'`. Fix: seed a static
-  `finlet-cli` OAuth client on the prod Authorization Server (or land
-  first-run Dynamic Client Registration in the CLI).
-- HIGH #3 — `dashboard/agent-guide.html` documents REST examples against
-  `http://localhost:8000` instead of `https://finlet.dev`, contradicting
-  `dashboard/setup.html`. Fix: rewrite agent-guide REST examples to use the
-  SaaS URL (or split into SaaS / self-host pages).
-- HIGH #4 — the documented `finlet register` → `export FINLET_API_KEY=...`
-  → `finlet session create` happy path is dead on the v1.0.0 MCP tool surface
-  (Phase 4e closed the api_key bearer fallthrough). Fix: either keep api_key
-  working on the CLI's MCP-stdio forwarding path, or update docs to require
-  `finlet auth login` after `finlet register`.
-- HIGH #5 — the spawned `finlet mcp serve` subprocess emits structured logs
-  on stdout, polluting the JSONRPC channel and surfacing a 13-line pydantic
-  traceback before every user-friendly error. Fix: route the subprocess's
-  structured logs to stderr.
-- HIGH #6 — `dashboard/api-keys.html` is read-only and tells the user to
-  `finlet register`, but that creates a sibling account rather than minting
-  on the logged-in identity. Fix: add an in-product "Generate New Key"
-  affordance bound to the cookie-authenticated user.
-- MEDIUM #7 — `POST /v1/sessions` via the dashboard cookie-auth path takes
-  26.9s end-to-end vs ~250ms for the REST + api_key path. Fix: investigate
-  the cookie-route warmup / plugin-health probe and either eliminate the
-  delay or add a progress UI.
-- MEDIUM #8 — `dashboard/agent-guide.html`'s Claude Desktop config block
-  uses the literal placeholder `"your_api_key_here"`, which copy-pasters
-  miss replacing. Fix: add a callout banner instructing users to substitute
-  their actual key.
-- MEDIUM #9 — `dashboard/api-keys.html` shows "No API keys yet" with no
-  affordance to mint one. Fix: add the Generate / Reveal / Revoke flow tied
-  to the logged-in identity (overlaps with HIGH #6).
-- LOW #10 — `dashboard/auth.html` defaults to the "Sign In" tab even when
-  arrived from the "Get Started Free" / "Create Free Account" CTA. Fix:
-  read URL hash or referrer to default to "Create Account" for sign-up
-  inbound links.
-
 ## [1.0.2] — 2026-05-11
 
 ### Fixed (v1.0.1 blind-walk follow-up)

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet status --short' in /Users/justnau/finlet
 succeeded in 0ms:
 M docs/brainstorms/codex-diff-reviews/team-A.md
 M docs/brainstorms/codex-diff-reviews/team-B.md
 M docs/brainstorms/codex-diff-reviews/team-C.md
 M docs/brainstorms/codex-diff-reviews/team-D.md
 M docs/brainstorms/exec-trace.txt
 M docs/brainstorms/team-prompts/team-A.md
 M docs/brainstorms/team-prompts/team-B.md
 M docs/brainstorms/team-prompts/team-C.md
 M docs/brainstorms/team-prompts/team-D.md
 M docs/brainstorms/team-prompts/team-E.md
 M uv.lock
?? docs/brainstorms/V2_PURE_MCP_EXECUTION_PLAN.md

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet grep -n "''^## '"\\[\" e98f637 -- CHANGELOG.md" in /Users/justnau/finlet
 succeeded in 0ms:
e98f637:CHANGELOG.md:8:## [2.0.0] — 2026-05-22
e98f637:CHANGELOG.md:141:## [1.1.0] — 2026-05-16
e98f637:CHANGELOG.md:209:## [1.0.4] — 2026-05-12
e98f637:CHANGELOG.md:244:## [1.0.3] — 2026-05-11
e98f637:CHANGELOG.md:254:## [1.0.2] — 2026-05-11
e98f637:CHANGELOG.md:264:## [1.0.1] — 2026-05-11
e98f637:CHANGELOG.md:283:## [1.0.0] - 2026-05-10
e98f637:CHANGELOG.md:409:## [0.1.1] - <prior>

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet grep -n "Unreleased" e98f637 -- CHANGELOG.md' in /Users/justnau/finlet
 exited 1 in 0ms:
exec
/bin/zsh -lc "git -C /Users/justnau/finlet grep -n \"session create\\|session/list\\|benchmark start\\|benchmark/progress\\|advance\\|order\\|portfolio\\|status\\|cli_mcp_client\\|_dispatch_mcp_tool\\|Migration notes\\|Claude Desktop\\|Codex CLI\\|Generic MCP\\|PR references\\|USER_MANUAL_OVERHAUL\\|9a88842\\|#87\" e98f637 -- CHANGELOG.md" in /Users/justnau/finlet
 succeeded in 0ms:
e98f637:CHANGELOG.md:12:their own MCP client (Claude Desktop, Claude Code, Codex CLI, Cursor,
e98f637:CHANGELOG.md:39:  sessions. Closes a gap where `get_sim_time` and `advance_time`
e98f637:CHANGELOG.md:70:  (`login` / `logout` / `status`), `finlet plugins` (`list` / `add` /
e98f637:CHANGELOG.md:80:  Desktop, Claude Code, Codex CLI, Cursor, Windsurf, VS Code, generic
e98f637:CHANGELOG.md:95:  - Top-level — `advance`, `order`, `portfolio`, `status`.
e98f637:CHANGELOG.md:96:- **`finlet/cli_mcp_client.py`** (entire module) — the v1.0.1
e98f637:CHANGELOG.md:100:  `_dispatch_mcp_tool`, `_translate_mcp_error`, `_emit_envelope`,
e98f637:CHANGELOG.md:106:  `from finlet.cli_mcp_client import ...` import.
e98f637:CHANGELOG.md:110:### Migration notes
e98f637:CHANGELOG.md:113:  clients (Claude Desktop, Claude Code, Codex CLI, Cursor, Windsurf,
e98f637:CHANGELOG.md:122:- **Scripts that called `finlet session create`, `finlet order`,
e98f637:CHANGELOG.md:123:  `finlet portfolio`, `finlet advance`, `finlet status`, `finlet
e98f637:CHANGELOG.md:131:### PR references
e98f637:CHANGELOG.md:143:USER_MANUAL_OVERHAUL ship. The `finlet manual` CLI subcommand and the
e98f637:CHANGELOG.md:181:  Claude Desktop, Claude Code, Cursor, Codex, Windsurf, VS Code,
e98f637:CHANGELOG.md:182:  Generic MCP, REST. OAuth-first auth flip (was api_key-first
e98f637:CHANGELOG.md:199:### PR references
e98f637:CHANGELOG.md:201:- USER_MANUAL_OVERHAUL ship — PR [#85](https://github.com/finlet-dev/finlet/pull/85)
e98f637:CHANGELOG.md:205:- `release: bump to v1.1.0` — PR [#87](https://github.com/finlet-dev/finlet/pull/87)
e98f637:CHANGELOG.md:206:  (`9a88842`, PyPI publish run `25955438689`).
e98f637:CHANGELOG.md:227:  applied to `finlet auth status` (not-logged-in / token-expired).
e98f637:CHANGELOG.md:232:  (preferred, matches the published Claude Desktop and Generic MCP
e98f637:CHANGELOG.md:248:- `dashboard/agent-guide.html` — Generic MCP Client config block now uses
e98f637:CHANGELOG.md:249:  `["mcp", "serve"]` subcommand (matches the Claude Desktop block fixed in
e98f637:CHANGELOG.md:257:- **CLI traceback regression (BLOCKER #B v1.0.1):** `finlet/cli_mcp_client.py` now catches `BaseException` around `session.initialize()` and `session.call_tool()` and collapses anyio task-group `ExceptionGroup` instances into a single-line `MCPDispatchError`. Restores the v1.0.0 HIGH#5 clean-stream invariant on the HTTP dispatch path.
e98f637:CHANGELOG.md:258:- **Claude Desktop config (HIGH #22 NEW):** `dashboard/agent-guide.html` Claude Desktop config block now passes `"args": ["mcp", "serve"]` (the actual self-host stdio command) instead of the bare `"args": ["mcp"]` which only printed help and exited.
e98f637:CHANGELOG.md:270:- **Agent-guide MCP-auth contradiction (HIGH #12):** Reconciled — narrative + Claude Desktop config block now agree.
e98f637:CHANGELOG.md:273:- **Undocumented trade-submit shape (MED #16):** Added `POST /v1/sessions/{id}/trade/order` curl example with the correct `ticker` field.
e98f637:CHANGELOG.md:274:- **`finlet trade submit` ghost (MED #17):** Docs corrected to reference the actual `finlet order` command.
e98f637:CHANGELOG.md:277:- `finlet auth status` command — reports local credential state without a server ping.
e98f637:CHANGELOG.md:294:  (`submit_order`, `cancel_order`, `list_orders`), portfolio queries, market
e98f637:CHANGELOG.md:311:- **CLI MCP-over-stdio dispatch**: `finlet session create/list/get`,
e98f637:CHANGELOG.md:312:  `finlet trade submit/cancel`, `finlet portfolio`, and `finlet orders` now
e98f637:CHANGELOG.md:362:### Migration notes
e98f637:CHANGELOG.md:379:- **`time_in_force=DAY` on `submit_order`**: the CLI flag is preserved
e98f637:CHANGELOG.md:384:### PR references

exec
/bin/zsh -lc "git -C /Users/justnau/finlet show e98f637:CHANGELOG.md | nl -ba | sed -n '1,260p'" in /Users/justnau/finlet
 succeeded in 0ms:
     1	# Changelog
     2	
     3	All notable changes to Finlet are documented in this file.
     4	
     5	The format is based on [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/),
     6	and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).
     7	
     8	## [2.0.0] — 2026-05-22
     9	
    10	Pure-MCP cutover. The CLI no longer dispatches agentic commands over
    11	MCP-over-HTTP; agents address the cloud `/mcp` endpoint directly through
    12	their own MCP client (Claude Desktop, Claude Code, Codex CLI, Cursor,
    13	Windsurf, generic MCP client). The local CLI keeps only the operator
    14	surface (`register`, `auth`, `plugins`, `serve`, `mcp serve`, `manual`)
    15	plus the `finlet mcp serve` stdio bridge for clients that wire stdio
    16	subprocesses. Ships alongside the session-level blind mode landed
    17	2026-05-22 in PR [#134](https://github.com/finlet-dev/finlet/pull/134).
    18	
    19	### Added (session-level blind mode — 2026-05-22)
    20	
    21	- **`create_session(blind: bool = False)`** across MCP (canonical
    22	  `mcp__finlet__create_session`), REST (`POST /v1/sessions`), and CLI
    23	  (`finlet sessions create --blind`). When `True`, the session is
    24	  created with `name = "blind-{session.id[:8]}"` (auto-generated,
    25	  immutable), a `BlindMapping` is attached BEFORE the first
    26	  `save_session`, and every `@blind_error_mapper`-decorated MCP tool
    27	  returns `T_NNNN` tickers + `Day_N` dates for that session. Same
    28	  plumbing as the canonical 5-scenario benchmark blind path
    29	  (`BlindMapping`, `assert_no_real_blinded_data`,
    30	  `_KNOWN_BENCHMARK_TICKERS`, SSE/trace blinding). MCP-first; REST +
    31	  CLI derive from MCP. Decision record:
    32	  `docs/decisions/session-level-blind-extends-create-session.md`.
    33	  Architecture: `docs/ARCHITECTURE.md` → "Session-Level Blind Mode".
    34	- **`SessionResponse.blind: bool`** populated at the top level of
    35	  `session_response()` (mirrors the existing `public` field).
    36	  Dashboards can render an owner-side "blind active" badge as a
    37	  follow-up.
    38	- **`freeze_time` MCP tool now blinds the clock response** for blind
    39	  sessions. Closes a gap where `get_sim_time` and `advance_time`
    40	  blinded but `freeze_time` returned real clock dates. Other
    41	  clock-touching MCP tools audited for the same pattern.
    42	
    43	### Changed (session-level blind mode — 2026-05-22)
    44	
    45	- **Hardcoded 50-ticker per-session universe cap removed.** Catalog
    46	  membership is the gate now: every requested ticker MUST be in
    47	  `_UNIVERSE_SOURCES` (270 tickers — 199 US equities + 71 US ETFs).
    48	  Off-catalog tickers get `"ticker '<X>' not in catalog — call
    49	  list_available_tickers"`. Same check fires on
    50	  `configure_session(universe=...)` for non-blind sessions (Codex
    51	  Step 10h BLOCKER 5 closed the back door). Pricing tiers update:
    52	  Free + Builder advertise "Unlimited tickers per session";
    53	  `max_tickers=None` on both tiers in
    54	  `finlet/billing/stripe_config.py`.
    55	- **`configure_session` lockdown on blind sessions.** Both `universe`
    56	  and `name` changes are rejected with 409 for blind sessions. The
    57	  `BlindMapping` is built at create-time; changing the universe
    58	  mid-session would invalidate the `T_NNNN` ↔ real-ticker
    59	  correspondence the agent has been working with.
    60	- **`_blind_mapping_for(session)` moved** from
    61	  `finlet/api/serializers.py` into
    62	  `finlet/api/services/session_service.py` (single source of truth).
    63	  `serializers.py` re-imports it. Direction is forward (services →
    64	  serializers).
    65	
    66	### Changed (CLI surface — pure-MCP cutover)
    67	
    68	- **CLI surface reduced to the MCP-bootstrap minimum.** Six command
    69	  families survive: `finlet serve`, `finlet register`, `finlet auth`
    70	  (`login` / `logout` / `status`), `finlet plugins` (`list` / `add` /
    71	  `remove`), `finlet mcp serve`, `finlet manual`. Agentic commands
    72	  are addressed through an MCP client directly against
    73	  `https://finlet.dev/mcp` (or the `finlet mcp serve` stdio bridge
    74	  for stdio-only clients). Operator and onboarding commands remain
    75	  local; agent dispatch leaves the CLI.
    76	- **Dashboard agent-guide rewritten for MCP-first onboarding.** The
    77	  8-tab client matrix in `dashboard/agent-guide.html` now leads with
    78	  the cloud `/mcp` endpoint plus `Authorization: Bearer` (OAuth or
    79	  api_key). Copy-paste setup blocks emit canonical config for Claude
    80	  Desktop, Claude Code, Codex CLI, Cursor, Windsurf, VS Code, generic
    81	  MCP client, and REST.
    82	- **`finlet manual quickstart` aligned to the canonical 5-step
    83	  MCP-first script.** The CLI walkthrough (and the `finlet/manual/`
    84	  package) match what `dashboard/agent-guide.html` and
    85	  `dashboard/llms.txt` advertise; the generator (`finlet.manual.
    86	  generate_llms_txt --check`) is the drift gate.
    87	
    88	### Removed
    89	
    90	- **CLI agentic dispatch surface.** Deleted commands (12 entry points
    91	  across 3 sub-apps + top-level):
    92	  - `session` sub-app — `create`, `list`, `delete`, `publish`.
    93	  - `benchmark` sub-app — `start`, `progress`, `decrypt`,
    94	    `visibility`.
    95	  - Top-level — `advance`, `order`, `portfolio`, `status`.
    96	- **`finlet/cli_mcp_client.py`** (entire module) — the v1.0.1
    97	  MCP-over-HTTP dispatcher and its `MCPDispatchError` surface. Agents
    98	  now own their own MCP client.
    99	- **Internal CLI helpers** retired alongside the dispatcher:
   100	  `_dispatch_mcp_tool`, `_translate_mcp_error`, `_emit_envelope`,
   101	  `_resolve_bearer_token`, `_AUTH_REQUIRED_MARKERS`,
   102	  `_AUTH_REQUIRED_HINT`, `_AsyncioTimeoutError`,
   103	  `_normalize_start_iso`, the top-level `import asyncio`, the
   104	  `session_app` + `benchmark_app` Typer sub-apps and their
   105	  `add_typer` registrations, and the
   106	  `from finlet.cli_mcp_client import ...` import.
   107	- **Stale module docstring** describing the deleted dispatch model
   108	  rewritten to reflect the v2.0.0 operator-only surface.
   109	
   110	### Migration notes
   111	
   112	- **Wire agents directly to `https://finlet.dev/mcp`.** Pure-MCP
   113	  clients (Claude Desktop, Claude Code, Codex CLI, Cursor, Windsurf,
   114	  generic MCP) authenticate with `Authorization: Bearer <jwt>` (OAuth
   115	  AS-minted) or `Authorization: Bearer fnlt_<api_key>`. The 8-tab
   116	  matrix in `dashboard/agent-guide.html` and `finlet manual
   117	  client-matrix` document the copy-paste config blocks.
   118	- **Stdio-only clients keep using `finlet mcp serve`.** The bundled
   119	  stdio bridge translates `FINLET_API_KEY` / `FINLET_OAUTH_BEARER`
   120	  into the MCP `initialize` handshake. `finlet/cli.py` still wires
   121	  `mcp serve`; only the per-tool convenience commands left.
   122	- **Scripts that called `finlet session create`, `finlet order`,
   123	  `finlet portfolio`, `finlet advance`, `finlet status`, `finlet
   124	  benchmark *` migrate to calling MCP tools directly** (any MCP
   125	  client SDK, or `curl` against `/mcp` with a JSON-RPC body). Tool
   126	  names + argument shapes are unchanged.
   127	- **No deprecation period.** Zero PyPI consumers exist on the v1.x
   128	  CLI dispatch path at cutover time (pre-launch, no customers); the
   129	  removal lands directly. See `[[project-pre-launch-no-customers]]`.
   130	
   131	### PR references
   132	
   133	- v2.0.0 pure-MCP cutover (this PR) — CLI surgery (Team A), CLI test
   134	  trim + MCP visibility assertions (Team B), manual + registry +
   135	  llms.txt regen (Team C), dashboard HTML examples + data-copy
   136	  attributes (Team D), version bump + CHANGELOG repair (Team E,
   137	  capstone).
   138	- Session-level blind mode — PR [#134](https://github.com/finlet-dev/finlet/pull/134)
   139	  (2026-05-22, prod sha `27d96ca`).
   140	
   141	## [1.1.0] — 2026-05-16
   142	
   143	USER_MANUAL_OVERHAUL ship. The `finlet manual` CLI subcommand and the
   144	~200-anchor error-envelope convention become reachable to any operator
   145	who `pip install finlet`. Minor (not patch) because the surface is
   146	additive and user-visible.
   147	
   148	### Added
   149	
   150	- **`finlet manual` CLI subcommand** — seven topics (`quickstart`,
   151	  `auth-model`, `session-lifecycle`, `transports`, `client-matrix`,
   152	  `plugin-matrix`, `errors`) with `--list` / `--search` /
   153	  `--format=json` modes and anchor-scoped lookups (e.g. `finlet
   154	  manual errors#missing-bearer`). Hatchling artifacts directive
   155	  `[tool.hatch.build.targets.wheel] artifacts = ["finlet/manual/*.md"]`
   156	  ships the topic files inside the wheel; loader is
   157	  `importlib.resources.files("finlet.manual")`.
   158	- **Error-anchor convention** — 13 frozen kebab-case anchor IDs in
   159	  `finlet/manual/errors.md`; ~200 error envelopes across REST,
   160	  billing, OAuth, MCP, and named plugins suffix-appended with
   161	  `See: finlet manual errors#<anchor>`.
   162	- **`_AUTH_REQUIRED_MESSAGE` constant** in `finlet/mcp/auth.py`
   163	  dedups the 19-site MCP auth-required surface.
   164	- **Per-surface contract gates** —
   165	  `tests/api/test_error_anchors.py`,
   166	  `tests/billing/test_error_anchors.py`,
   167	  `tests/auth/oauth/test_error_anchors.py`,
   168	  `tests/plugins/test_error_anchors.py`.
   169	- **`dashboard/llms.txt` regen pipeline + freshness guard** —
   170	  deterministic generator in `finlet/manual/generate_llms_txt.py`
   171	  with `--write` / `--check` modes. Three-layer drift gate:
   172	  pre-commit hook (`scripts/lint-llms-txt-fresh.sh`), CI lint step
   173	  (`.github/workflows/ci.yml`), and `--write` remediation.
   174	- **CLI command see-also footers** — 10 `finlet` command docstrings
   175	  gained `See: finlet manual <topic>` footers in their `--help`
   176	  output.
   177	
   178	### Changed
   179	
   180	- **`dashboard/agent-guide.html` rewritten as an 8-tab matrix** —
   181	  Claude Desktop, Claude Code, Cursor, Codex, Windsurf, VS Code,
   182	  Generic MCP, REST. OAuth-first auth flip (was api_key-first
   183	  pre-Phase-4e); api_key documented as headless/CI fallback. Five
   184	  troubleshooting deep-links anchor at `finlet manual errors#<anchor>`.
   185	- **`README.md:66` MCP config fix** — `args: ["mcp"]` →
   186	  `args: ["mcp", "serve"]` (matches the Phase-5 Typer sub-app
   187	  rename).
   188	- **`finlet/api/deprecation.py` `/mcp(/.*)?$` whitelist** —
   189	  prevents the legacy deprecation-header middleware from tagging MCP
   190	  paths as deprecated alongside `/v1/` routes.
   191	- **`.github/workflows/ci.yml`** flipped from `paths-ignore` to a
   192	  positive paths allowlist to keep gates dormant on doc-only PRs.
   193	
   194	### Architecture
   195	
   196	- New decision records: `docs/decisions/error-anchor-convention.md`
   197	  and `docs/decisions/dashboard-llms-txt-regen-pipeline.md`.
   198	
   199	### PR references
   200	
   201	- USER_MANUAL_OVERHAUL ship — PR [#85](https://github.com/finlet-dev/finlet/pull/85)
   202	  (`734da2e`, merged 2026-05-15).
   203	- gitleaks deploy-fix — PR [#86](https://github.com/finlet-dev/finlet/pull/86)
   204	  (`d0461d6`).
   205	- `release: bump to v1.1.0` — PR [#87](https://github.com/finlet-dev/finlet/pull/87)
   206	  (`9a88842`, PyPI publish run `25955438689`).
   207	- E2E gate — `tests/e2e/journey-19-agent-guide.spec.ts`.
   208	
   209	## [1.0.4] — 2026-05-12
   210	
   211	### Fixed
   212	
   213	Per v1.0.3 blind-walk findings
   214	(`docs/launch/blind-agent-coldstart-report-v1.0.3-fullwalk.md`):
   215	
   216	- **F-1 (HIGH)** `dashboard/agent-guide.html` — "Auth path" tip no longer
   217	  claims MCP-over-HTTP accepts `Authorization: Bearer fnlt_<api_key>`.
   218	  Phase 4e shipped Bearer-only (OAuth JWT) enforcement on the MCP HTTP
   219	  surface; the dashboard now correctly directs api_key clients to either
   220	  the REST API at `https://finlet.dev/v1/...` or the bundled
   221	  `finlet mcp serve` stdio bridge (which translates `FINLET_API_KEY`
   222	  internally).
   223	- **F-3 (MEDIUM)** CLI exits `EXIT_AUTH_REQUIRED` (2) on MCP auth
   224	  failures with a friendlier "Run `finlet auth login` or set
   225	  `FINLET_API_KEY=fnlt_<key>`" hint, instead of exit 0. Shell scripts
   226	  can now detect auth-failed invocations. Same exit-code semantics
   227	  applied to `finlet auth status` (not-logged-in / token-expired).
   228	- **F-4 (LOW)** `/dashboard/` (with trailing slash) no longer 404s —
   229	  both `/dashboard` and `/dashboard/` resolve to the same handler.
   230	  Same fix applied to `/login`, `/login/`, `/pricing`, `/pricing/`.
   231	- **F-5 (LOW)** `finlet mcp serve --help` reconciles `FINLET_API_KEY`
   232	  (preferred, matches the published Claude Desktop and Generic MCP
   233	  Client configs) and `FINLET_OAUTH_BEARER` (also accepted).
   234	- **F-6 (LOW)** `finlet auth login --help` drops the "90-day dual-accept
   235	  window" framing (that window was retracted pre-launch in v1.0.1) —
   236	  `--api-key` mode reframed as a convenience for confirming an
   237	  existing `FINLET_API_KEY` against Finlet's REST surface.
   238	
   239	### Added
   240	
   241	- **F-2 (MEDIUM)** `finlet --version` flag — prints the installed
   242	  version via `importlib.metadata.version("finlet")` and exits 0.
   243	
   244	## [1.0.3] — 2026-05-11
   245	
   246	### Fixed
   247	
   248	- `dashboard/agent-guide.html` — Generic MCP Client config block now uses
   249	  `["mcp", "serve"]` subcommand (matches the Claude Desktop block fixed in
   250	  v1.0.2). Cursor / Cline / Continue users following the Generic config
   251	  block would have seen "MCP server crashed immediately" because bare
   252	  `finlet mcp` prints help and exits 0. Docs-only patch; no PyPI re-publish.
   253	
   254	## [1.0.2] — 2026-05-11
   255	
   256	### Fixed (v1.0.1 blind-walk follow-up)
   257	- **CLI traceback regression (BLOCKER #B v1.0.1):** `finlet/cli_mcp_client.py` now catches `BaseException` around `session.initialize()` and `session.call_tool()` and collapses anyio task-group `ExceptionGroup` instances into a single-line `MCPDispatchError`. Restores the v1.0.0 HIGH#5 clean-stream invariant on the HTTP dispatch path.
   258	- **Claude Desktop config (HIGH #22 NEW):** `dashboard/agent-guide.html` Claude Desktop config block now passes `"args": ["mcp", "serve"]` (the actual self-host stdio command) instead of the bare `"args": ["mcp"]` which only printed help and exited.
   259	- **Module `__version__` drift:** `finlet/__init__.py` bumped to "1.0.2" to match `pyproject.toml`. (v1.0.1 shipped with `__version__` stuck at "1.0.0".)
   260	

exec
/bin/zsh -lc "git -C /Users/justnau/finlet show e98f637:CHANGELOG.md | nl -ba | sed -n '260,430p'" in /Users/justnau/finlet
 succeeded in 0ms:
   260	
   261	### Ops
   262	- `.gitleaksignore` allowlists 3 v1.0.1 false-positives (test fixture + 2 doc examples) — unblocks the Deploy Finlet security gate.
   263	
   264	## [1.0.1] — 2026-05-11
   265	
   266	### Fixed
   267	- **CLI MCP dispatch — BLOCKER #A:** CLI now dispatches MCP-over-HTTP to `https://finlet.dev/mcp` instead of spawning a local `finlet mcp serve` subprocess. Removes the requirement to install `[server]` extras and eliminates JWKS validation failures from cloud-issued tokens hitting locally-spawned servers.
   268	- **API key auth on MCP — BLOCKER #B:** Retracted Phase 4e api_key sunset (pre-launch, zero customers). Both OAuth Bearer JWT and api_key Bearer (`fnlt_*`) now accepted on `/mcp`.
   269	- **JSONRPC stream pollution (HIGH #11):** Side-effect of removing the local subprocess spawn — no stderr/stdout from a child can corrupt the JSONRPC channel.
   270	- **Agent-guide MCP-auth contradiction (HIGH #12):** Reconciled — narrative + Claude Desktop config block now agree.
   271	- **Free-tier concurrency claim (HIGH #13):** Marketing updated from "4 sessions per day" to "1 concurrent simulation" to match enforced policy.
   272	- **CLI install footprint (MED #15):** Base `pip install finlet` is now sufficient — `[server]` extras moved to a Self-host (optional) subsection.
   273	- **Undocumented trade-submit shape (MED #16):** Added `POST /v1/sessions/{id}/trade/order` curl example with the correct `ticker` field.
   274	- **`finlet trade submit` ghost (MED #17):** Docs corrected to reference the actual `finlet order` command.
   275	
   276	### Added
   277	- `finlet auth status` command — reports local credential state without a server ping.
   278	- `tests/mcp/test_http_endpoint.py` — integration suite for the cloud /mcp endpoint covering OAuth + api_key Bearer + no-auth paths.
   279	
   280	### Architecture
   281	- New decision record `docs/decisions/cli-mcp-http-dispatch.md`; superseded `cli-mcp-stdio-auth.md`; retracted `mcp-api-key-sunset.md` Phase 4e closure.
   282	
   283	## [1.0.0] - 2026-05-10
   284	
   285	Launch release. The 1.0.0 line consolidates the MCP-First migration (Phases 1–5)
   286	into a single shipped surface: a FastMCP server exposing 16 agent-facing tools, an
   287	OAuth 2.1 Authorization Server with Dynamic Client Registration and Resource Indicators,
   288	Bearer-only authentication on the MCP tool surface, and a CLI that dispatches every
   289	agentic command through a spawned `finlet mcp serve` subprocess over stdio.
   290	
   291	### Added
   292	
   293	- **MCP server with 16 tools** covering session lifecycle, trading
   294	  (`submit_order`, `cancel_order`, `list_orders`), portfolio queries, market
   295	  data lookups, and benchmark execution. The server is exposed under
   296	  `finlet/mcp/` and mounts on the same FastAPI app that hosts the REST surface.
   297	- **OAuth 2.1 Authorization Server** with Dynamic Client Registration
   298	  (RFC 7591), Resource Indicators (RFC 8707), PKCE-only authorization-code
   299	  flow, and EdDSA-signed JWT access tokens. Endpoints under `/oauth/*`:
   300	  `authorize`, `token`, `register`, `jwks`, `metadata`. Backed by
   301	  `finlet/auth/oauth/` with four new tables (`oauth_clients`, `oauth_codes`,
   302	  `oauth_refresh_tokens`, `oauth_keys`) introduced via migration `014`.
   303	- **OAuth Resource Server** in `finlet/mcp/auth.py` and
   304	  `finlet/mcp/bearer_context.py`: every authenticated MCP tool resolves
   305	  identity through `resolve_credential`, validates the JWT via
   306	  `joserfc` pinned to EdDSA, and enforces per-tool scope gates inside
   307	  the user's `UserTier`.
   308	- **CLI OAuth login**: `finlet auth login` performs the browser-based
   309	  authorization-code-with-PKCE flow and stores the resulting Bearer token
   310	  at `~/.finlet/credentials` with mode 0600. `finlet auth logout` clears it.
   311	- **CLI MCP-over-stdio dispatch**: `finlet session create/list/get`,
   312	  `finlet trade submit/cancel`, `finlet portfolio`, and `finlet orders` now
   313	  spawn `python -m finlet mcp serve` per command and dispatch JSON-RPC tool
   314	  calls over stdio. Bearer tokens are forwarded into the subprocess via the
   315	  `FINLET_OAUTH_BEARER` environment variable. See
   316	  `docs/decisions/cli-mcp-stdio-auth.md`.
   317	- **Service-layer parity gates** (`finlet/api/services/`): `session_service`,
   318	  `trade_service`, `market_service`, and the unified `errors` module ensure
   319	  REST and MCP tool surfaces apply identical validation, ownership, and
   320	  error-envelope contracts.
   321	- **API versioning + deprecation header policy** on the REST surface,
   322	  refined in Phase 3 to align response timing and policy semantics across
   323	  middleware paths.
   324	
   325	### Changed
   326	
   327	- **CLI auth flow**: `finlet` agentic commands no longer accept an
   328	  `--api-key` flag for MCP-bound calls. The CLI loads a Bearer JWT from
   329	  `~/.finlet/credentials` (or `FINLET_OAUTH_BEARER` env), passes it
   330	  through to the spawned `finlet mcp serve` subprocess, and the subprocess
   331	  authenticates the JWT via `_authenticate_oauth_or_key`.
   332	- **CLI dispatch transport**: agentic commands moved from REST HTTP to
   333	  spawned MCP subprocess over stdio. The 4 keep-list commands (`serve`,
   334	  `register`, `auth login`, `auth logout`) remain bit-identical. Plugin
   335	  management (`plugins list/add/remove`) continues to call the REST
   336	  surface — operator surface, not agent surface.
   337	- **MCP tool authentication contract**: every MCP tool now expects a Bearer
   338	  JWT minted by the Finlet OAuth AS. The HTTP transport reads the token
   339	  via `BearerContextMiddleware`; the stdio transport reads
   340	  `FINLET_OAUTH_BEARER` from the subprocess env. Per-request precedence
   341	  is unchanged: ContextVar wins on HTTP, env var fires only when the
   342	  ContextVar is empty (the stdio case).
   343	- **Authentication-required envelope** for MCP tools: a missing or invalid
   344	  Bearer token returns the documented `{"error": "Authentication required"}`
   345	  envelope as a 401. Previously this surfaced as a generic auth error.
   346	
   347	### Removed
   348	
   349	- **`api_key` authentication on the MCP tool surface**. Phase 4c shipped a
   350	  90-day api_key dual-accept window alongside Bearer; Phase 4e retracted
   351	  that window pre-launch (no consumers had migrated, see
   352	  `docs/decisions/mcp-api-key-sunset.md` Retraction 2026-05-09).
   353	  `api_key=<key>` arguments now return:
   354	  `{"error": "api_key authentication is no longer supported on MCP tools.
   355	  Run 'finlet auth login' to obtain an OAuth Bearer token. See
   356	  docs/MCP_OAUTH_MIGRATION.md."}` as a 401. The api_key fallthrough is
   357	  gone from `finlet/mcp/bearer_context.py:resolve_credential` and
   358	  `finlet/mcp/auth.py:_authenticate_oauth_or_key`.
   359	- **`finlet auth register` legacy alias**. The agentic onboarding flow
   360	  is now `finlet register` (account) followed by `finlet auth login` (token).
   361	
   362	### Migration notes
   363	
   364	- **Upgrading from 0.1.x**: run `finlet auth login` to obtain a Bearer
   365	  token. The api_key auth path is removed in 1.0.0; any agent or script
   366	  passing `api_key=<key>` to MCP tools will receive a 401 with the
   367	  cutover-message envelope above. The CLI's agentic commands handle
   368	  Bearer-token forwarding automatically; no manual env-var management
   369	  is required for interactive use.
   370	- **Direct MCP tool consumers** (custom HTTP clients): swap the
   371	  `Authorization: ApiKey <key>` header (or `api_key` argument) for
   372	  `Authorization: Bearer <jwt>` where the JWT is minted by
   373	  `POST /oauth/token` on the Finlet AS. Resource Indicator must be the
   374	  Finlet MCP resource per RFC 8707.
   375	- **CLI scripts that parsed REST JSON**: agentic commands now return
   376	  MCP tool envelopes (JSON-RPC result format) rather than raw FastAPI
   377	  JSON bodies. Operator commands (`plugins list/add/remove`) are
   378	  unchanged.
   379	- **`time_in_force=DAY` on `submit_order`**: the CLI flag is preserved
   380	  for ergonomic stability but is silently dropped on the MCP path
   381	  because the MCP tool does not currently expose it. Tracked under
   382	  Phase 5 polish.
   383	
   384	### PR references
   385	
   386	- Phase 5 — CLI MCP-over-stdio rewire: PR [#37](https://github.com/finlet-dev/finlet/pull/37)
   387	  (squash `d8e13dd`, 2026-05-10).
   388	- Phase 4e — Bearer-only cutover (api_key sunset): atomic commit
   389	  `cebd327` series (Team E1, 2026-05-09 — sunset clock retracted
   390	  pre-launch with no consumers; no PR).
   391	- Phase 4d — CLI OAuth login + 0600 credential storage: PR [#35](https://github.com/finlet-dev/finlet/pull/35)
   392	  (2026-05-09).
   393	- Phase 4c — OAuth Resource Server + 16 MCP tools dual-accept + scope
   394	  enforcement: PR [#34](https://github.com/finlet-dev/finlet/pull/34)
   395	  (2026-05-08).
   396	- Phase 4b — OAuth Authorization Server (5 endpoints, 4 tables, EdDSA
   397	  JWT minting): PR [#33](https://github.com/finlet-dev/finlet/pull/33)
   398	  (2026-05-08).
   399	- Phase 4a — OAuth 2.1 + DCR + Resource Indicators decision record:
   400	  PR [#32](https://github.com/finlet-dev/finlet/pull/32) (2026-05-08).
   401	- Phase 3 — Deprecation-header policy refinement on the REST API
   402	  versioning surface: PR [#31](https://github.com/finlet-dev/finlet/pull/31)
   403	  (2026-05-08).
   404	- Phase 2 (service-layer parity) and Phase 1 (MCP correctness, CLI
   405	  envelope, benchmark log redaction) shipped via sequential team
   406	  commits to `main` ahead of Phase 3; see git history under
   407	  `[Team A]`/`[Team B]`/`[Team C]` prefixes 2026-05-07.
   408	
   409	## [0.1.1] - <prior>
   410	
   411	Prior pre-launch state. See git history for details.

codex
The changelog ordering and required section content are lining up so far: no `[Unreleased]`, `2.0.0` then `1.1.0`, and the CLI removals and migration notes are present. I’m doing one build-oriented pass now from the target commit itself so the dirty working tree and newer HEAD do not skew the packaging check.
exec
/bin/zsh -lc 'git -C /Users/justnau/finlet diff e98f637''^ e98f637 --name-status' in /Users/justnau/finlet
 succeeded in 0ms:
M	CHANGELOG.md
M	pyproject.toml

exec
/bin/zsh -lc "git -C /Users/justnau/finlet show e98f637:pyproject.toml | nl -ba | sed -n '1,220p'" in /Users/justnau/finlet
 succeeded in 0ms:
     1	[project]
     2	name = "finlet"
     3	version = "2.0.0"
     4	description = "A historical market simulation environment for testing AI trading agent reasoning against real market data."
     5	readme = "README.md"
     6	license = "LicenseRef-Proprietary"
     7	requires-python = ">=3.12"
     8	authors = [
     9	    { name = "Finlet Contributors" },
    10	]
    11	keywords = ["trading", "ai", "simulation", "backtesting", "mcp", "llm", "agent"]
    12	classifiers = [
    13	    "Development Status :: 4 - Beta",
    14	    "Framework :: FastAPI",
    15	    "Intended Audience :: Developers",
    16	    "License :: Other/Proprietary License",
    17	    "Programming Language :: Python :: 3.12",
    18	    "Programming Language :: Python :: 3.13",
    19	    "Topic :: Office/Business :: Financial :: Investment",
    20	]
    21	
    22	dependencies = [
    23	    "typer>=0.12",
    24	    "httpx>=0.27",
    25	    "mcp>=1.27.0",
    26	    "rich>=13.0",
    27	]
    28	
    29	[project.urls]
    30	Homepage = "https://finlet.dev"
    31	Repository = "https://github.com/justnau1020/finlet"
    32	Documentation = "https://finlet.dev/agent-guide.html"
    33	Issues = "https://github.com/justnau1020/finlet/issues"
    34	
    35	[project.optional-dependencies]
    36	server = [
    37	    "fastapi>=0.115",
    38	    "uvicorn[standard]>=0.30",
    39	    "aiosqlite>=0.20",
    40	    "sqlmodel>=0.0.22",
    41	    "greenlet>=3.0",
    42	    "mcp[auth]>=1.27.0",
    43	    "joserfc>=1.0",
    44	    "edgartools>=3.0",
    45	    "fredapi>=0.5",
    46	    "finnhub-python>=2.4",
    47	    "pydantic[email]>=2.9",
    48	    "alembic>=1.14",
    49	    "structlog>=24.1",
    50	    "markdown>=3.6",
    51	    "stripe>=8.0",
    52	    "pyarrow>=15.0",
    53	    "boto3>=1.34",
    54	    "pyotp>=2.9",
    55	    "qrcode[pil]>=7.4",
    56	    "cryptography>=46.0.6",
    57	    "argon2-cffi>=23.1.0",
    58	    "sentry-sdk[fastapi]>=2.0.0",
    59	]
    60	ingest = [
    61	    "yfinance>=0.2.36",
    62	    "curl-cffi>=0.15.0",  # pin: CVE-2026-33752 in <0.15 (transitive via yfinance)
    63	    "pandas>=2.0",
    64	    "pyarrow>=15.0",
    65	    "boto3>=1.34",
    66	    "structlog>=24.1",
    67	    "httpx>=0.27",
    68	    "beautifulsoup4>=4.12",
    69	    "tenacity>=8.2",
    70	    # SEC EDGAR + FRED + Databento — used by scripts/ingest_edgar.py,
    71	    # scripts/ingest_fred.py, scripts/ingest_prices.py respectively.
    72	    # Previously only listed in [server] but they are pure ingest deps
    73	    # that the ingest cron workflows must install without pulling the
    74	    # full server runtime. See .github/workflows/ingest-{prices,daily}.yml.
    75	    "edgartools>=3.0",
    76	    "fredapi>=0.5",
    77	    "databento>=0.50",
    78	]
    79	sms = [
    80	    "boto3>=1.34",
    81	]
    82	dev = [
    83	    "pytest>=8.3",
    84	    "pytest-asyncio>=0.25",
    85	    "pytest-xdist>=3.5",
    86	    "httpx>=0.27",
    87	    "ruff>=0.8",
    88	    "mypy>=1.13",
    89	    "types-Markdown>=3.6",
    90	    "mypy-boto3-s3>=1.34",
    91	    "pip-audit>=2.7",
    92	    "pytest-cov>=6.0",
    93	    "bandit>=1.7",
    94	    "hypothesis>=6.100",
    95	]
    96	
    97	[project.scripts]
    98	finlet = "finlet.cli:app"
    99	
   100	[build-system]
   101	requires = ["hatchling"]
   102	build-backend = "hatchling.build"
   103	
   104	# Hatchling auto-includes Python source under ``finlet/`` in the wheel,
   105	# but Markdown topic files inside ``finlet/manual/`` are NOT Python source
   106	# and would be excluded by default.  The targeted directive below ships
   107	# every ``finlet/manual/*.md`` alongside the package so
   108	# ``importlib.resources.files("finlet.manual").read_text(...)`` works from
   109	# an installed wheel.  See ``finlet/manual/registry.py`` for the loader.
   110	[tool.hatch.build.targets.wheel]
   111	artifacts = ["finlet/manual/*.md"]
   112	
   113	
   114	# ── Ruff ─────────────────────────────────────────────────────
   115	[tool.ruff]
   116	target-version = "py312"
   117	line-length = 120
   118	exclude = [".claude/skills/"]
   119	
   120	[tool.ruff.lint]
   121	select = ["E", "F", "I", "UP", "B", "SIM"]
   122	ignore = [
   123	    "E501",    # line too long — handled by formatter
   124	    "B008",    # do not perform function call in argument defaults (FastAPI Depends)
   125	    "B904",    # raise-without-from-inside-except — too noisy for error wrappers
   126	    "SIM108",  # use ternary operator — reduces readability in complex cases
   127	    "UP007",   # use X | Y for union — already used where appropriate
   128	    "UP017",   # datetime.UTC alias — timezone.utc is clearer and more widely used
   129	    "UP042",   # StrEnum — str+Enum pattern is deliberate for Pydantic compatibility
   130	]
   131	
   132	[tool.ruff.lint.isort]
   133	known-first-party = ["finlet"]
   134	
   135	# ── Mypy ─────────────────────────────────────────────────────
   136	# Note: mypy's cache_dir defaults to ".mypy_cache" in the current working
   137	# directory. The CI pipelines (.github/workflows/{ci,deploy}.yml) cache
   138	# this path explicitly via actions/cache@v4 to skip ~15s of repeat type
   139	# checking. Don't override cache_dir here or the cache key will go stale.
   140	[tool.mypy]
   141	python_version = "3.12"
   142	warn_return_any = true
   143	warn_unused_configs = true
   144	disallow_untyped_defs = false
   145	check_untyped_defs = true
   146	
   147	[[tool.mypy.overrides]]
   148	module = [
   149	    "finnhub.*",
   150	    "edgar.*",
   151	    "fredapi.*",
   152	    "pyarrow.*",
   153	    "mcp.*",
   154	    "uvicorn.*",
   155	    "aiosqlite.*",
   156	    "sqlmodel.*",
   157	    "sqlalchemy.*",
   158	    "boto3.*",
   159	    "botocore.*",
   160	    "structlog.*",
   161	    "alembic.*",
   162	    "stripe.*",
   163	    "pyotp.*",
   164	    "qrcode.*",
   165	    "yfinance.*",
   166	    "pandas",
   167	    "pandas.*",
   168	    "cryptography.*",
   169	    "argon2.*",
   170	    "yfinance.*",
   171	]
   172	ignore_missing_imports = true
   173	follow_untyped_imports = true
   174	
   175	# ── Pytest ───────────────────────────────────────────────────
   176	[tool.pytest.ini_options]
   177	asyncio_mode = "auto"
   178	# pytest-xdist parallelization is OFF by default (single-threaded local
   179	# runs). CI workflows pass `-n auto --dist=loadfile` explicitly via
   180	# pytest CLI flags — see `.github/workflows/ci.yml` and
   181	# `.github/workflows/deploy.yml`.
   182	#
   183	# Why gated, not pyproject-default:
   184	#   The session-scoped `live_server` fixture in
   185	#   `tests/integration/conftest.py` boots uvicorn under a 30s deadline.
   186	#   The fixture is already flaky on data-heavy dev machines (see the
   187	#   2026-05-10 entry in `docs/KNOWN_FAILURES.md` — "local-environment
   188	#   data-volume flake"); under xdist parallelism on the same machine,
   189	#   CPU contention pushes more workers past the deadline more often.
   190	#   CI runners are clean and the data-volume issue does not apply, so
   191	#   xdist runs cleanly in CI but is opt-in locally.
   192	#
   193	# Local fast runs (when you know the data-volume flake is not your
   194	# enemy): `pytest -n auto --dist=loadfile` from the repo root.
   195	#
   196	# `--dist=loadfile` is REQUIRED whenever `-n auto` is used:
   197	#   • Keeps tests in the same file on the same worker so the
   198	#     session-scoped `live_server` is booted once per file, not once
   199	#     per worker.
   200	#   • `tests/integration/conftest.py::pytest_collection_modifyitems`
   201	#     pins integration tests to run LAST (to avoid structlog cache
   202	#     pollution bleeding into capture_logs tests). Per-worker
   203	#     collection ordering is preserved under loadfile distribution.
   204	addopts = ""
   205	
   206	# ── Bandit ───────────────────────────────────────────────────
   207	[tool.bandit]
   208	exclude_dirs = ["tests"]
   209	skips = ["B101", "B104", "B105", "B112", "B311"]
   210	
   211	[dependency-groups]
   212	dev = [
   213	    "complexipy>=5.2.0",
   214	    "deptry>=0.25.1",
   215	    "pre-commit>=4.5.1",
   216	    "pytest-timeout>=2.3",
   217	    "ty>=0.0.25",
   218	]

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet diff e98f637''^ e98f637 -- pyproject.toml' in /Users/justnau/finlet
 succeeded in 0ms:
diff --git a/pyproject.toml b/pyproject.toml
index bc4a609..e4cd56f 100644
--- a/pyproject.toml
+++ b/pyproject.toml
@@ -1,6 +1,6 @@
 [project]
 name = "finlet"
-version = "1.1.0"
+version = "2.0.0"
 description = "A historical market simulation environment for testing AI trading agent reasoning against real market data."
 readme = "README.md"
 license = "LicenseRef-Proprietary"

exec
/bin/zsh -lc 'tmp=$(mktemp -d /tmp/finlet-e98f637-review.XXXXXX)
git -C /Users/justnau/finlet worktree add --detach "$tmp" e98f637
printf '"'%s\\n' \""'$tmp"' in /Users/justnau/finlet
 succeeded in 177ms:
HEAD is now at e98f637 [Team E v2.0.0]: bump 2.0.0 + CHANGELOG repair (add [1.1.0] from manual-overhaul evidence; fold [Unreleased] into [2.0.0])
/tmp/finlet-e98f637-review.9RIJFh

exec
/bin/zsh -lc 'hatch build' in /tmp/finlet-e98f637-review.9RIJFh
 succeeded in 1494ms:
Creating environment: hatch-build
Checking dependencies
Syncing dependencies
Inspecting build dependencies
──────────────────────────────────── sdist ─────────────────────────────────────
dist/finlet-2.0.0.tar.gz
──────────────────────────────────── wheel ─────────────────────────────────────
dist/finlet-2.0.0-py3-none-any.whl

exec
/bin/zsh -lc 'unzip -l dist/finlet-2.0.0-py3-none-any.whl | grep -E "finlet/(cli|mcp|api|core|plugins)"' in /tmp/finlet-e98f637-review.9RIJFh
 succeeded in 0ms:
    50826  02-02-2020 00:00   finlet/cli.py
       31  02-02-2020 00:00   finlet/api/__init__.py
    51522  02-02-2020 00:00   finlet/api/app.py
     3597  02-02-2020 00:00   finlet/api/auth.py
     4067  02-02-2020 00:00   finlet/api/config_injection.py
    17346  02-02-2020 00:00   finlet/api/deprecation.py
     1107  02-02-2020 00:00   finlet/api/deps.py
     6428  02-02-2020 00:00   finlet/api/email_config.py
     8529  02-02-2020 00:00   finlet/api/email_providers.py
    11295  02-02-2020 00:00   finlet/api/email_service.py
     3422  02-02-2020 00:00   finlet/api/idempotency.py
     3808  02-02-2020 00:00   finlet/api/middleware.py
    17798  02-02-2020 00:00   finlet/api/routes_account.py
     2584  02-02-2020 00:00   finlet/api/routes_admin.py
    20563  02-02-2020 00:00   finlet/api/routes_auth_credentials.py
    11293  02-02-2020 00:00   finlet/api/routes_auth_mfa.py
     6817  02-02-2020 00:00   finlet/api/routes_auth_sessions.py
     4514  02-02-2020 00:00   finlet/api/routes_benchmark.py
     6653  02-02-2020 00:00   finlet/api/routes_billing.py
     8236  02-02-2020 00:00   finlet/api/routes_clock.py
     4516  02-02-2020 00:00   finlet/api/routes_csp.py
     4462  02-02-2020 00:00   finlet/api/routes_email.py
     9435  02-02-2020 00:00   finlet/api/routes_health.py
     5484  02-02-2020 00:00   finlet/api/routes_leaderboard.py
     5897  02-02-2020 00:00   finlet/api/routes_legal.py
    32268  02-02-2020 00:00   finlet/api/routes_market.py
     9753  02-02-2020 00:00   finlet/api/routes_marketplace_admin.py
    12585  02-02-2020 00:00   finlet/api/routes_marketplace_compliance.py
     4717  02-02-2020 00:00   finlet/api/routes_marketplace_onboarding.py
     8002  02-02-2020 00:00   finlet/api/routes_marketplace_strategy.py
     5512  02-02-2020 00:00   finlet/api/routes_metrics.py
     7332  02-02-2020 00:00   finlet/api/routes_notifications.py
     3231  02-02-2020 00:00   finlet/api/routes_plugins.py
     4069  02-02-2020 00:00   finlet/api/routes_portfolio.py
    11933  02-02-2020 00:00   finlet/api/routes_public_benchmark.py
     6424  02-02-2020 00:00   finlet/api/routes_public_session.py
    15491  02-02-2020 00:00   finlet/api/routes_session.py
     8103  02-02-2020 00:00   finlet/api/routes_settings.py
     8374  02-02-2020 00:00   finlet/api/routes_sse.py
     7541  02-02-2020 00:00   finlet/api/routes_trade.py
      636  02-02-2020 00:00   finlet/api/security_alerts.py
    14411  02-02-2020 00:00   finlet/api/security_middleware.py
    15912  02-02-2020 00:00   finlet/api/serializers.py
      990  02-02-2020 00:00   finlet/api/session_auth.py
      915  02-02-2020 00:00   finlet/api/state.py
     1320  02-02-2020 00:00   finlet/api/email_templates/__init__.py
    16934  02-02-2020 00:00   finlet/api/email_templates/auth.py
     8573  02-02-2020 00:00   finlet/api/email_templates/base.py
    12989  02-02-2020 00:00   finlet/api/email_templates/billing.py
    10070  02-02-2020 00:00   finlet/api/email_templates/security.py
     2714  02-02-2020 00:00   finlet/api/email_templates/session.py
        0  02-02-2020 00:00   finlet/api/helpers/__init__.py
     9554  02-02-2020 00:00   finlet/api/helpers/coverage_rollup.py
     1540  02-02-2020 00:00   finlet/api/mfa/__init__.py
     3327  02-02-2020 00:00   finlet/api/mfa/google.py
     3804  02-02-2020 00:00   finlet/api/mfa/recovery.py
     2954  02-02-2020 00:00   finlet/api/mfa/session.py
     3942  02-02-2020 00:00   finlet/api/mfa/sms.py
     2458  02-02-2020 00:00   finlet/api/mfa/totp.py
     2278  02-02-2020 00:00   finlet/api/rate_limit/__init__.py
     7047  02-02-2020 00:00   finlet/api/rate_limit/auth.py
     3791  02-02-2020 00:00   finlet/api/rate_limit/core.py
     9607  02-02-2020 00:00   finlet/api/rate_limit/deletion.py
     4197  02-02-2020 00:00   finlet/api/rate_limit/export.py
     4951  02-02-2020 00:00   finlet/api/rate_limit/plugin.py
     3807  02-02-2020 00:00   finlet/api/rate_limit/session.py
     5927  02-02-2020 00:00   finlet/api/rate_limit/trading.py
     7690  02-02-2020 00:00   finlet/api/schemas/__init__.py
     8675  02-02-2020 00:00   finlet/api/schemas/account.py
     4413  02-02-2020 00:00   finlet/api/schemas/auth_credentials.py
     1583  02-02-2020 00:00   finlet/api/schemas/auth_mfa.py
     2403  02-02-2020 00:00   finlet/api/schemas/auth_sessions.py
     3366  02-02-2020 00:00   finlet/api/schemas/benchmark.py
     2097  02-02-2020 00:00   finlet/api/schemas/billing.py
      895  02-02-2020 00:00   finlet/api/schemas/clock.py
     1325  02-02-2020 00:00   finlet/api/schemas/email.py
      815  02-02-2020 00:00   finlet/api/schemas/health.py
     3915  02-02-2020 00:00   finlet/api/schemas/leaderboard.py
     2637  02-02-2020 00:00   finlet/api/schemas/marketplace_admin.py
     4705  02-02-2020 00:00   finlet/api/schemas/marketplace_developer.py
     4059  02-02-2020 00:00   finlet/api/schemas/marketplace_onboarding.py
      942  02-02-2020 00:00   finlet/api/schemas/notifications.py
     2337  02-02-2020 00:00   finlet/api/schemas/portfolio.py
     5391  02-02-2020 00:00   finlet/api/schemas/session.py
     5082  02-02-2020 00:00   finlet/api/schemas/settings.py
     2187  02-02-2020 00:00   finlet/api/schemas/trade.py
        0  02-02-2020 00:00   finlet/api/services/__init__.py
     8453  02-02-2020 00:00   finlet/api/services/benchmark_service.py
    18486  02-02-2020 00:00   finlet/api/services/clock_service.py
     5163  02-02-2020 00:00   finlet/api/services/email_token_service.py
     3463  02-02-2020 00:00   finlet/api/services/errors.py
    47664  02-02-2020 00:00   finlet/api/services/market_service.py
    62663  02-02-2020 00:00   finlet/api/services/session_service.py
    17724  02-02-2020 00:00   finlet/api/services/settings_service.py
    32739  02-02-2020 00:00   finlet/api/services/trade_service.py
     1358  02-02-2020 00:00   finlet/core/__init__.py
    37279  02-02-2020 00:00   finlet/core/blind_mapping.py
    18142  02-02-2020 00:00   finlet/core/clock.py
     5183  02-02-2020 00:00   finlet/core/enforcer.py
    10120  02-02-2020 00:00   finlet/core/orders.py
    15940  02-02-2020 00:00   finlet/core/portfolio.py
    28315  02-02-2020 00:00   finlet/core/session.py
     2631  02-02-2020 00:00   finlet/core/slippage.py
     5452  02-02-2020 00:00   finlet/core/trace.py
       33  02-02-2020 00:00   finlet/mcp/__init__.py
     2333  02-02-2020 00:00   finlet/mcp/_errors.py
     4981  02-02-2020 00:00   finlet/mcp/_fastmcp_patches.py
      367  02-02-2020 00:00   finlet/mcp/_instance.py
    15201  02-02-2020 00:00   finlet/mcp/auth.py
    12927  02-02-2020 00:00   finlet/mcp/bearer_context.py
    16952  02-02-2020 00:00   finlet/mcp/blind_error.py
     8290  02-02-2020 00:00   finlet/mcp/error_envelope.py
    71130  02-02-2020 00:00   finlet/mcp/server.py
    41357  02-02-2020 00:00   finlet/mcp/tools_benchmark.py
    13466  02-02-2020 00:00   finlet/mcp/tools_portfolio.py
     4485  02-02-2020 00:00   finlet/mcp/tools_session.py
     9085  02-02-2020 00:00   finlet/mcp/tools_telemetry.py
    14312  02-02-2020 00:00   finlet/mcp/tools_trading.py
     1035  02-02-2020 00:00   finlet/plugins/__init__.py
    31876  02-02-2020 00:00   finlet/plugins/base.py
     5630  02-02-2020 00:00   finlet/plugins/cache.py
    11013  02-02-2020 00:00   finlet/plugins/econ_fetchers.py
    13447  02-02-2020 00:00   finlet/plugins/econ_plugin.py
     4316  02-02-2020 00:00   finlet/plugins/econ_sources.py
    15415  02-02-2020 00:00   finlet/plugins/edgar_plugin.py
    20843  02-02-2020 00:00   finlet/plugins/finnhub_plugin.py
    24705  02-02-2020 00:00   finlet/plugins/fred_plugin.py
    57882  02-02-2020 00:00   finlet/plugins/fundamentals_plugin.py
    17647  02-02-2020 00:00   finlet/plugins/news_plugin.py
    43395  02-02-2020 00:00   finlet/plugins/price_plugin.py
    17637  02-02-2020 00:00   finlet/plugins/sentiment_plugin.py

exec
/bin/zsh -lc 'unzip -l dist/finlet-2.0.0-py3-none-any.whl | grep "finlet/cli_mcp_client.py"' in /tmp/finlet-e98f637-review.9RIJFh
 exited 1 in 0ms:
exec
/bin/zsh -lc "unzip -l dist/finlet-2.0.0-py3-none-any.whl | grep \"finlet/manual/.*\\.md\"" in /tmp/finlet-e98f637-review.9RIJFh
 succeeded in 0ms:
     3708  02-02-2020 00:00   finlet/manual/auth-model.md
     3093  02-02-2020 00:00   finlet/manual/client-matrix.md
     7859  02-02-2020 00:00   finlet/manual/errors.md
     3450  02-02-2020 00:00   finlet/manual/plugin-matrix.md
     2771  02-02-2020 00:00   finlet/manual/quickstart.md
     3937  02-02-2020 00:00   finlet/manual/session-lifecycle.md
     3611  02-02-2020 00:00   finlet/manual/transports.md

exec
/bin/zsh -lc "unzip -p dist/finlet-2.0.0-py3-none-any.whl finlet-2.0.0.dist-info/METADATA | sed -n '1,30p'" in /tmp/finlet-e98f637-review.9RIJFh
 succeeded in 0ms:
Metadata-Version: 2.4
Name: finlet
Version: 2.0.0
Summary: A historical market simulation environment for testing AI trading agent reasoning against real market data.
Project-URL: Homepage, https://finlet.dev
Project-URL: Repository, https://github.com/justnau1020/finlet
Project-URL: Documentation, https://finlet.dev/agent-guide.html
Project-URL: Issues, https://github.com/justnau1020/finlet/issues
Author: Finlet Contributors
License-Expression: LicenseRef-Proprietary
License-File: LICENSE
Keywords: agent,ai,backtesting,llm,mcp,simulation,trading
Classifier: Development Status :: 4 - Beta
Classifier: Framework :: FastAPI
Classifier: Intended Audience :: Developers
Classifier: License :: Other/Proprietary License
Classifier: Programming Language :: Python :: 3.12
Classifier: Programming Language :: Python :: 3.13
Classifier: Topic :: Office/Business :: Financial :: Investment
Requires-Python: >=3.12
Requires-Dist: httpx>=0.27
Requires-Dist: mcp>=1.27.0
Requires-Dist: rich>=13.0
Requires-Dist: typer>=0.12
Provides-Extra: dev
Requires-Dist: bandit>=1.7; extra == 'dev'
Requires-Dist: httpx>=0.27; extra == 'dev'
Requires-Dist: hypothesis>=6.100; extra == 'dev'
Requires-Dist: mypy-boto3-s3>=1.34; extra == 'dev'
Requires-Dist: mypy>=1.13; extra == 'dev'

exec
/bin/zsh -lc "git -C /Users/justnau/finlet grep -n \"v2.0.0 pure-MCP cutover\\|Session-level blind mode\\|PR \\[#\" e98f637 -- CHANGELOG.md" in /Users/justnau/finlet
 succeeded in 0ms:
e98f637:CHANGELOG.md:17:2026-05-22 in PR [#134](https://github.com/finlet-dev/finlet/pull/134).
e98f637:CHANGELOG.md:133:- v2.0.0 pure-MCP cutover (this PR) — CLI surgery (Team A), CLI test
e98f637:CHANGELOG.md:138:- Session-level blind mode — PR [#134](https://github.com/finlet-dev/finlet/pull/134)
e98f637:CHANGELOG.md:201:- USER_MANUAL_OVERHAUL ship — PR [#85](https://github.com/finlet-dev/finlet/pull/85)
e98f637:CHANGELOG.md:203:- gitleaks deploy-fix — PR [#86](https://github.com/finlet-dev/finlet/pull/86)
e98f637:CHANGELOG.md:205:- `release: bump to v1.1.0` — PR [#87](https://github.com/finlet-dev/finlet/pull/87)
e98f637:CHANGELOG.md:386:- Phase 5 — CLI MCP-over-stdio rewire: PR [#37](https://github.com/finlet-dev/finlet/pull/37)
e98f637:CHANGELOG.md:391:- Phase 4d — CLI OAuth login + 0600 credential storage: PR [#35](https://github.com/finlet-dev/finlet/pull/35)
e98f637:CHANGELOG.md:394:  enforcement: PR [#34](https://github.com/finlet-dev/finlet/pull/34)
e98f637:CHANGELOG.md:397:  JWT minting): PR [#33](https://github.com/finlet-dev/finlet/pull/33)
e98f637:CHANGELOG.md:400:  PR [#32](https://github.com/finlet-dev/finlet/pull/32) (2026-05-08).
e98f637:CHANGELOG.md:402:  versioning surface: PR [#31](https://github.com/finlet-dev/finlet/pull/31)

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet log --oneline --decorate -n 12 e98f637' in /Users/justnau/finlet
 succeeded in 0ms:
e98f637 (worktree-agent-a06d45ac8a2d4df7b) [Team E v2.0.0]: bump 2.0.0 + CHANGELOG repair (add [1.1.0] from manual-overhaul evidence; fold [Unreleased] into [2.0.0])
3957bab [Team C v2.0.0 fix-on-main]: invert test_manual_generate_llms_txt assertion — stdio is the v2.0.0 lede
05189f2 Merge: [Team B v2.0.0] trim CLI tests; add 4 MCP assertions on set_session_visibility
014329f (worktree-agent-ac344962ac027859f) [Team B v2.0.0]: trim CLI tests; add 4 MCP assertions on set_session_visibility (public + public_anonymous + no-share-url)
f69c169 [Team D v2.0.0 fix-on-main]: multi-line data-copy + canonical prompt in agent-guide Step 2
af6e759 Merge: [Team D v2.0.0] rewrite dashboard HTML examples + data-copy attributes for MCP-first onboarding
41cb07d [Team C v2.0.0 fix-on-main]: align quickstart + registry + llms.txt to canonical 5-step script
9f5ef34 Merge: [Team C v2.0.0] rewrite manual + registry + generator + docs + README for MCP-first; regen dashboard/llms.txt
6244346 [Team A v2.0.0 fix-on-main]: revert plugins_* EXIT_AUTH_REQUIRED scope creep + strip docstring of dropped-cmd names
59c85bb Merge: [Team A v2.0.0] CLI surgery — delete dropped commands + dead helpers + rewrite module docstring
cfadd81 (worktree-agent-a055449a65a2df2af) [Team A v2.0.0]: delete CLI convenience commands + dead helpers; rewrite module docstring
0ac4241 (worktree-agent-a1fd70c2e913223a2) [Team C v2.0.0]: rewrite manual + registry + generator + docs + README for MCP-first; regen dashboard/llms.txt

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet worktree remove /tmp/finlet-e98f637-review.9RIJFh' in /Users/justnau/finlet
 succeeded in 150ms:
codex
BLOCKER

- None.

STRONG-SUGGESTION

- [CHANGELOG.md:21](/Users/justnau/finlet/CHANGELOG.md:21): The folded session-level blind entry still says the feature exists via CLI `finlet sessions create --blind`, while the same `2.0.0` section later removes `session create`. Historically true for PR #134, but ambiguous for final `2.0.0` users. Clarify that v2 users should use MCP/REST, or note the CLI path existed only before the pure-MCP cutover.

NIT

- [CHANGELOG.md:133](/Users/justnau/finlet/CHANGELOG.md:133): The `2.0.0` PR reference says “this PR” without an actual PR number/link/merge sha. Existing `[1.0.0]` style uses concrete PR links, so fill this in when known.

Validation: `git show e98f637 --stat` touched only `CHANGELOG.md` and `pyproject.toml`; `pyproject.toml` line 3 is `version = "2.0.0"`; changelog ordering is correct and has no `[Unreleased]`; `hatch build` from a detached `e98f637` worktree produced `finlet-2.0.0` sdist and wheel, with key packages present and `finlet/cli_mcp_client.py` absent.

GATE: PASS
tokens used
81,495
BLOCKER

- None.

STRONG-SUGGESTION

- [CHANGELOG.md:21](/Users/justnau/finlet/CHANGELOG.md:21): The folded session-level blind entry still says the feature exists via CLI `finlet sessions create --blind`, while the same `2.0.0` section later removes `session create`. Historically true for PR #134, but ambiguous for final `2.0.0` users. Clarify that v2 users should use MCP/REST, or note the CLI path existed only before the pure-MCP cutover.

NIT

- [CHANGELOG.md:133](/Users/justnau/finlet/CHANGELOG.md:133): The `2.0.0` PR reference says “this PR” without an actual PR number/link/merge sha. Existing `[1.0.0]` style uses concrete PR links, so fill this in when known.

Validation: `git show e98f637 --stat` touched only `CHANGELOG.md` and `pyproject.toml`; `pyproject.toml` line 3 is `version = "2.0.0"`; changelog ordering is correct and has no `[Unreleased]`; `hatch build` from a detached `e98f637` worktree produced `finlet-2.0.0` sdist and wheel, with key packages present and `finlet/cli_mcp_client.py` absent.

GATE: PASS

---
## Verdict: GATE PASS (0 BLOCKER, 1 STRONG, 1 NIT)

STRONG-SUGGESTION (logged for triage): CHANGELOG.md:21 — folded session-level blind entry advertises 'finlet sessions create --blind' CLI flag while the same [2.0.0] section removes 'session create'. Historically accurate for PR #134's intermediate state but ambiguous for v2.0.0 PyPI consumers (who never get the CLI flag). Recommend clarifying as 'pre-pure-MCP cutover, MCP/REST only in v2.0.0' or rewording to MCP/REST. NOT FIXED — defer to either documentation pass or doc-update agent.

NIT (deferred): CHANGELOG.md:133 — '2.0.0' PR reference says 'this PR' without concrete number/link/merge SHA. Will be filled in when the PR is created (Step 4 substep 4).
