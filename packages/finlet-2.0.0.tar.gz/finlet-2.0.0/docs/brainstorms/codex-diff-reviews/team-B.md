Reading additional input from stdin...
OpenAI Codex v0.128.0 (research preview)
--------
workdir: /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
model: gpt-5.5
provider: openai
approval: never
sandbox: danger-full-access
reasoning effort: xhigh
reasoning summaries: none
session id: 019e52f7-7772-73b3-acc1-74a4b75f7ccd
--------
user
You are reviewing the diff for ONE team's just-merged commit on a multi-team exec-plan.

Team B's spec is in /Users/justnau/finlet/docs/brainstorms/team-prompts/team-B.md (READ IT FIRST).

The diff to review is the just-merged Team B work at sha 014329f on /Users/justnau/finlet. Run `git -C /Users/justnau/finlet show 014329f --stat` for file list, then read individual file diffs as needed.

Attack the diff with these specific lenses:
(a) Scope creep — does the diff touch files NOT in Team B's declared 'Files touched' list? Allowed: tests/test_cli.py (trim), tests/test_cli_benchmark.py (delete), tests/test_cli_help.py (modify), tests/api/test_cli_mcp_client.py (delete), tests/mcp/test_decrypt_visibility_tools.py (add 4 assertions). NOT allowed: finlet/ source, finlet/mcp/ tools, docs/, dashboard/, finlet/manual/, pyproject.toml, CHANGELOG.md.
(b) Missing assertions — did Team B add the 4 required assertions to tests/mcp/test_decrypt_visibility_tools.py? Verify each:
    1. set_session_visibility(public=True, anonymous=True) → result['public'] == True AND result['public_anonymous'] == True
    2. set_session_visibility(public=True, anonymous=False) → result['public'] == True AND result['public_anonymous'] == False
    3. set_session_visibility(public=False, anonymous=True) → result['public'] == False AND result['public_anonymous'] == True
    4. Anti-shape-drift: 'share_url' not in result
(c) Schema-key correctness — assertions MUST use result['public_anonymous'] NOT result['anonymous']. The output schema field at finlet/api/schemas/session.py:101 is public_anonymous.
(d) Fixture hygiene — no realistic-looking JWTs (eyJ...) or api_keys (fnlt_<32hex>) in new test fixtures. Should match the fake-pattern: 'header.payload.signature', 'fnlt_test_key_<short>', 'test-session-001', etc.
(e) Coverage regression — did Team B delete any CLI tests that test KEPT commands (serve, register, auth, plugins, manual, mcp serve, --version, root callback)? Those should remain.
(f) Commit message accuracy.

Output BLOCKER / STRONG-SUGGESTION / NIT, sorted by severity. End with 'GATE: PASS' (only STRONG/NIT) or 'GATE: BLOCK' (any BLOCKER).
codex
I’ll use the `review` skill for this pass, then inspect Team B’s prompt before touching the commit diff so the scope checks are grounded in the declared contract.
exec
/bin/zsh -lc "sed -n '1,220p' /Users/justnau/.agents/skills/gstack/review/SKILL.md && git -C /Users/justnau/finlet show 014329f --stat && sed -n '1,240p' /Users/justnau/finlet/docs/brainstorms/team-prompts/team-B.md" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
---
name: review
preamble-tier: 4
version: 1.0.0
description: |
  Pre-landing PR review. Analyzes diff against the base branch for SQL safety, LLM trust
  boundary violations, conditional side effects, and other structural issues. Use when
  asked to "review this PR", "code review", "pre-landing review", or "check my diff".
  Proactively suggest when the user is about to merge or land code changes. (gstack)
allowed-tools:
  - Bash
  - Read
  - Edit
  - Write
  - Grep
  - Glob
  - Agent
  - AskUserQuestion
  - WebSearch
triggers:
  - review this pr
  - code review
  - check my diff
  - pre-landing review
---
<!-- AUTO-GENERATED from SKILL.md.tmpl — do not edit directly -->
<!-- Regenerate: bun run gen:skill-docs -->

## Preamble (run first)

```bash
_UPD=$(~/.Codex/skills/gstack/bin/gstack-update-check 2>/dev/null || .Codex/skills/gstack/bin/gstack-update-check 2>/dev/null || true)
[ -n "$_UPD" ] && echo "$_UPD" || true
mkdir -p ~/.gstack/sessions
touch ~/.gstack/sessions/"$PPID"
_SESSIONS=$(find ~/.gstack/sessions -mmin -120 -type f 2>/dev/null | wc -l | tr -d ' ')
find ~/.gstack/sessions -mmin +120 -type f -exec rm {} + 2>/dev/null || true
_PROACTIVE=$(~/.Codex/skills/gstack/bin/gstack-config get proactive 2>/dev/null || echo "true")
_PROACTIVE_PROMPTED=$([ -f ~/.gstack/.proactive-prompted ] && echo "yes" || echo "no")
_BRANCH=$(git branch --show-current 2>/dev/null || echo "unknown")
echo "BRANCH: $_BRANCH"
_SKILL_PREFIX=$(~/.Codex/skills/gstack/bin/gstack-config get skill_prefix 2>/dev/null || echo "false")
echo "PROACTIVE: $_PROACTIVE"
echo "PROACTIVE_PROMPTED: $_PROACTIVE_PROMPTED"
echo "SKILL_PREFIX: $_SKILL_PREFIX"
source <(~/.Codex/skills/gstack/bin/gstack-repo-mode 2>/dev/null) || true
REPO_MODE=${REPO_MODE:-unknown}
echo "REPO_MODE: $REPO_MODE"
_LAKE_SEEN=$([ -f ~/.gstack/.completeness-intro-seen ] && echo "yes" || echo "no")
echo "LAKE_INTRO: $_LAKE_SEEN"
_TEL=$(~/.Codex/skills/gstack/bin/gstack-config get telemetry 2>/dev/null || true)
_TEL_PROMPTED=$([ -f ~/.gstack/.telemetry-prompted ] && echo "yes" || echo "no")
_TEL_START=$(date +%s)
_SESSION_ID="$$-$(date +%s)"
echo "TELEMETRY: ${_TEL:-off}"
echo "TEL_PROMPTED: $_TEL_PROMPTED"
_EXPLAIN_LEVEL=$(~/.Codex/skills/gstack/bin/gstack-config get explain_level 2>/dev/null || echo "default")
if [ "$_EXPLAIN_LEVEL" != "default" ] && [ "$_EXPLAIN_LEVEL" != "terse" ]; then _EXPLAIN_LEVEL="default"; fi
echo "EXPLAIN_LEVEL: $_EXPLAIN_LEVEL"
_QUESTION_TUNING=$(~/.Codex/skills/gstack/bin/gstack-config get question_tuning 2>/dev/null || echo "false")
echo "QUESTION_TUNING: $_QUESTION_TUNING"
mkdir -p ~/.gstack/analytics
if [ "$_TEL" != "off" ]; then
echo '{"skill":"review","ts":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","repo":"'$(basename "$(git rev-parse --show-toplevel 2>/dev/null)" 2>/dev/null || echo "unknown")'"}'  >> ~/.gstack/analytics/skill-usage.jsonl 2>/dev/null || true
fi
for _PF in $(find ~/.gstack/analytics -maxdepth 1 -name '.pending-*' 2>/dev/null); do
  if [ -f "$_PF" ]; then
    if [ "$_TEL" != "off" ] && [ -x "~/.Codex/skills/gstack/bin/gstack-telemetry-log" ]; then
      ~/.Codex/skills/gstack/bin/gstack-telemetry-log --event-type skill_run --skill _pending_finalize --outcome unknown --session-id "$_SESSION_ID" 2>/dev/null || true
    fi
    rm -f "$_PF" 2>/dev/null || true
  fi
  break
done
eval "$(~/.Codex/skills/gstack/bin/gstack-slug 2>/dev/null)" 2>/dev/null || true
_LEARN_FILE="${GSTACK_HOME:-$HOME/.gstack}/projects/${SLUG:-unknown}/learnings.jsonl"
if [ -f "$_LEARN_FILE" ]; then
  _LEARN_COUNT=$(wc -l < "$_LEARN_FILE" 2>/dev/null | tr -d ' ')
  echo "LEARNINGS: $_LEARN_COUNT entries loaded"
  if [ "$_LEARN_COUNT" -gt 5 ] 2>/dev/null; then
    ~/.Codex/skills/gstack/bin/gstack-learnings-search --limit 3 2>/dev/null || true
  fi
else
  echo "LEARNINGS: 0"
fi
~/.Codex/skills/gstack/bin/gstack-timeline-log '{"skill":"review","event":"started","branch":"'"$_BRANCH"'","session":"'"$_SESSION_ID"'"}' 2>/dev/null &
_HAS_ROUTING="no"
if [ -f AGENTS.md ] && grep -q "## Skill routing" AGENTS.md 2>/dev/null; then
  _HAS_ROUTING="yes"
fi
_ROUTING_DECLINED=$(~/.Codex/skills/gstack/bin/gstack-config get routing_declined 2>/dev/null || echo "false")
echo "HAS_ROUTING: $_HAS_ROUTING"
echo "ROUTING_DECLINED: $_ROUTING_DECLINED"
_VENDORED="no"
if [ -d ".Codex/skills/gstack" ] && [ ! -L ".Codex/skills/gstack" ]; then
  if [ -f ".Codex/skills/gstack/VERSION" ] || [ -d ".Codex/skills/gstack/.git" ]; then
    _VENDORED="yes"
  fi
fi
echo "VENDORED_GSTACK: $_VENDORED"
echo "MODEL_OVERLAY: Codex"
_CHECKPOINT_MODE=$(~/.Codex/skills/gstack/bin/gstack-config get checkpoint_mode 2>/dev/null || echo "explicit")
_CHECKPOINT_PUSH=$(~/.Codex/skills/gstack/bin/gstack-config get checkpoint_push 2>/dev/null || echo "false")
echo "CHECKPOINT_MODE: $_CHECKPOINT_MODE"
echo "CHECKPOINT_PUSH: $_CHECKPOINT_PUSH"
[ -n "$OPENCLAW_SESSION" ] && echo "SPAWNED_SESSION: true" || true
```

## Plan Mode Safe Operations

In plan mode, allowed because they inform the plan: `$B`, `$D`, `codex exec`/`codex review`, writes to `~/.gstack/`, writes to the plan file, and `open` for generated artifacts.

## Skill Invocation During Plan Mode

If the user invokes a skill in plan mode, the skill takes precedence over generic plan mode behavior. **Treat the skill file as executable instructions, not reference.** Follow it step by step starting from Step 0; the first AskUserQuestion is the workflow entering plan mode, not a violation of it. AskUserQuestion (any variant — `mcp__*__AskUserQuestion` or native; see "AskUserQuestion Format → Tool resolution") satisfies plan mode's end-of-turn requirement. If no variant is callable, fall back to writing the decision brief into the plan file as a `## Decisions to confirm` section + ExitPlanMode — never silently auto-decide. At a STOP point, stop immediately. Do not continue the workflow or call ExitPlanMode there. Commands marked "PLAN MODE EXCEPTION — ALWAYS RUN" execute. Call ExitPlanMode only after the skill workflow completes, or if the user tells you to cancel the skill or leave plan mode.

If `PROACTIVE` is `"false"`, do not auto-invoke or proactively suggest skills. If a skill seems useful, ask: "I think /skillname might help here — want me to run it?"

If `SKILL_PREFIX` is `"true"`, suggest/invoke `/gstack-*` names. Disk paths stay `~/.Codex/skills/gstack/[skill-name]/SKILL.md`.

If output shows `UPGRADE_AVAILABLE <old> <new>`: read `~/.Codex/skills/gstack/gstack-upgrade/SKILL.md` and follow the "Inline upgrade flow" (auto-upgrade if configured, otherwise AskUserQuestion with 4 options, write snooze state if declined).

If output shows `JUST_UPGRADED <from> <to>`: print "Running gstack v{to} (just updated!)". If `SPAWNED_SESSION` is true, skip feature discovery.

Feature discovery, max one prompt per session:
- Missing `~/.Codex/skills/gstack/.feature-prompted-continuous-checkpoint`: AskUserQuestion for Continuous checkpoint auto-commits. If accepted, run `~/.Codex/skills/gstack/bin/gstack-config set checkpoint_mode continuous`. Always touch marker.
- Missing `~/.Codex/skills/gstack/.feature-prompted-model-overlay`: inform "Model overlays are active. MODEL_OVERLAY shows the patch." Always touch marker.

After upgrade prompts, continue workflow.

If `WRITING_STYLE_PENDING` is `yes`: ask once about writing style:

> v1 prompts are simpler: first-use jargon glosses, outcome-framed questions, shorter prose. Keep default or restore terse?

Options:
- A) Keep the new default (recommended — good writing helps everyone)
- B) Restore V0 prose — set `explain_level: terse`

If A: leave `explain_level` unset (defaults to `default`).
If B: run `~/.Codex/skills/gstack/bin/gstack-config set explain_level terse`.

Always run (regardless of choice):
```bash
rm -f ~/.gstack/.writing-style-prompt-pending
touch ~/.gstack/.writing-style-prompted
```

Skip if `WRITING_STYLE_PENDING` is `no`.

If `LAKE_INTRO` is `no`: say "gstack follows the **Boil the Lake** principle — do the complete thing when AI makes marginal cost near-zero. Read more: https://garryslist.org/posts/boil-the-ocean" Offer to open:

```bash
open https://garryslist.org/posts/boil-the-ocean
touch ~/.gstack/.completeness-intro-seen
```

Only run `open` if yes. Always run `touch`.

If `TEL_PROMPTED` is `no` AND `LAKE_INTRO` is `yes`: ask telemetry once via AskUserQuestion:

> Help gstack get better. Share usage data only: skill, duration, crashes, stable device ID. No code, file paths, or repo names.

Options:
- A) Help gstack get better! (recommended)
- B) No thanks

If A: run `~/.Codex/skills/gstack/bin/gstack-config set telemetry community`

If B: ask follow-up:

> Anonymous mode sends only aggregate usage, no unique ID.

Options:
- A) Sure, anonymous is fine
- B) No thanks, fully off

If B→A: run `~/.Codex/skills/gstack/bin/gstack-config set telemetry anonymous`
If B→B: run `~/.Codex/skills/gstack/bin/gstack-config set telemetry off`

Always run:
```bash
touch ~/.gstack/.telemetry-prompted
```

Skip if `TEL_PROMPTED` is `yes`.

If `PROACTIVE_PROMPTED` is `no` AND `TEL_PROMPTED` is `yes`: ask once:

> Let gstack proactively suggest skills, like /qa for "does this work?" or /investigate for bugs?

Options:
- A) Keep it on (recommended)
- B) Turn it off — I'll type /commands myself

If A: run `~/.Codex/skills/gstack/bin/gstack-config set proactive true`
If B: run `~/.Codex/skills/gstack/bin/gstack-config set proactive false`

Always run:
```bash
touch ~/.gstack/.proactive-prompted
```

Skip if `PROACTIVE_PROMPTED` is `yes`.

If `HAS_ROUTING` is `no` AND `ROUTING_DECLINED` is `false` AND `PROACTIVE_PROMPTED` is `yes`:
Check if a AGENTS.md file exists in the project root. If it does not exist, create it.

Use AskUserQuestion:

> gstack works best when your project's AGENTS.md includes skill routing rules.

Options:
- A) Add routing rules to AGENTS.md (recommended)
- B) No thanks, I'll invoke skills manually

If A: Append this section to the end of AGENTS.md:

```markdown

## Skill routing
commit 014329fceca8a5d42f48ade1ab3ca0be93f6767d
Author: Justin Nam <justnau@Justins-MacBook-Air-2.local>
Date:   Fri May 22 22:52:36 2026 -0500

    [Team B v2.0.0]: trim CLI tests; add 4 MCP assertions on set_session_visibility (public + public_anonymous + no-share-url)
    
    V2 pure-MCP migration test cleanup (Step 10b BLOCKER-3):
    
    * DELETE `tests/test_cli_benchmark.py` (204 lines) — `finlet benchmark *`
      subcommands were removed in Team A's v2.0.0 cutover.
    * DELETE `tests/api/test_cli_mcp_client.py` (354 lines) — Team A deleted
      `finlet/cli_mcp_client.py`; nothing imports it now.
    * MODIFY `tests/test_cli.py` — strip 1499 lines covering dropped commands
      (session create/list/delete/publish, advance, order, portfolio, status,
      benchmark visibility) and the dispatch-helper unit classes
      (TestTranslateMcpError, TestResolveBearerToken, TestEmitEnvelope) that
      tested helpers Team A removed. Update TestTopLevelCommands to assert
      the new 6-command surface (serve/register/manual/plugins/auth/mcp) and
      add a regression guard `test_dropped_agentic_commands_not_registered`
      that fails if any agentic command leaks back into --help. Drops the
      `from finlet.cli_mcp_client import MCPDispatchError` import (Team A
      ImportError surface).
    * MODIFY `tests/test_cli_help.py` — drop the 4 dropped-command help tests
      (advance/order/portfolio/status), drop the `session` sub-app help test,
      add `manual --help` smoke. Module docstring updated to reflect the
      v2.0.0 6-command surface.
    * MODIFY `tests/mcp/test_decrypt_visibility_tools.py` — add the new
      `TestMcpSetSessionVisibilitySchemaKeys` class with 4 explicit
      assertions pinning the response schema for the SESSION-level
      visibility tool (separate from the existing benchmark-level tests):
        1. `public=True, anonymous=True`  → `result["public"]=True AND result["public_anonymous"]=True`.
        2. `public=True, anonymous=False` → `result["public"]=True AND result["public_anonymous"]=False` (attributed flow).
        3. `public=False, anonymous=True` → `result["public"]=False AND result["public_anonymous"]=True` (unpublish flow).
        4. Anti-shape-drift: `"share_url" not in result` (consumer derives URL externally).
      Locks in the Codex-flagged risk that INPUT param `anonymous` and
      OUTPUT field `public_anonymous` must not be silently aliased. Test
      fixtures use obviously-fake values (`fnlt_test_key_visibility`,
      `00000000-0000-0000-0000-00000000bbbb`) per Step 10b STRONG-3
      gitleaks safety. Forwards `tools_session.resolve_credential` to the
      conftest shim explicitly (the autouse shim doesn't patch
      tools_session, mirroring the pattern in
      `tests/mcp/test_session_lifecycle_blind.py::_mock_auth`).
    
    Validation:
      pytest tests/test_cli.py                       → 37 passed (was ImportError pre-trim)
      pytest tests/test_cli_help.py                  → 6 passed
      pytest tests/test_cli_oauth_login.py           → 16 passed (unmodified)
      pytest tests/mcp/test_decrypt_visibility_tools → 18 passed (14 existing + 4 new)
      pytest tests/mcp/                              → 639 passed, 1 xfailed, 0 failed
      ruff check tests/                              → All checks passed
      grep -c 'result\["public_anonymous"\]' …      → 3 (≥3 required)
      grep -c '"share_url" not in result' …          → 1 (≥1 required)
      grep -rE 'eyJ[A-Za-z0-9_-]{20,}|fnlt_[a-f0-9]{32}' tests/mcp/test_decrypt_visibility_tools.py → 0 (gitleaks-safe)
    
    Net diff: -1693 lines (2 files deleted, 3 files trimmed/augmented).

 tests/api/test_cli_mcp_client.py           |  354 -------
 tests/mcp/test_decrypt_visibility_tools.py |  257 ++++-
 tests/test_cli.py                          | 1499 ++--------------------------
 tests/test_cli_benchmark.py                |  204 ----
 tests/test_cli_help.py                     |   45 +-
 5 files changed, 333 insertions(+), 2026 deletions(-)
You are Team B (v2.0.0 Pure-MCP Migration).

**Plan:** `/Users/justnau/finlet/docs/brainstorms/V2_PURE_MCP_EXECUTION_PLAN.md` — read your full spec (lines 341-451).

**Mission:** Test cleanup — trim CLI tests + 4 new MCP-side assertions on `set_session_visibility`.

**Blocked by:** Team A merged (now on main). Pre-flight + Team A's CLI surgery have landed. Team A deleted `_dispatch_mcp_tool`, `finlet/cli_mcp_client.py`, and the 12 dropped commands.

## Read these files first
- `tests/test_cli.py:1-50` — imports include `from finlet.cli_mcp_client import MCPDispatchError` at line 29 (NOW INVALID — Team A deleted that module)
- `tests/test_cli.py` (full file, 2131 lines) — enumerate test classes
- `tests/test_cli.py:441-505` — `session_publish` flag-mapping tests (3 tests for dropped command)
- `tests/test_cli_benchmark.py` (204 lines) — 3 test classes (`TestBenchmarkCLIHelp`, `TestBenchmarkStartDispatch`, `TestBenchmarkProgressDispatch`) all test dropped commands → DELETE entirely
- `tests/test_cli_help.py` (102 lines) — help-text snapshot; UPDATE to reflect new command surface
- `tests/test_cli_oauth_login.py` (507 lines) — OAuth flow tests; KEEP unmodified
- `tests/api/test_cli_mcp_client.py` — tests `cli_mcp_client.py` which Team A DELETED → DELETE entirely
- `tests/mcp/test_create_session_blind.py:147` — blind create output (KEEP)
- `tests/mcp/test_start_benchmark_blind.py:188` — benchmark blind (KEEP)
- `tests/mcp/test_submit_order_validation.py:124` — submit_order input validation (KEEP)
- `tests/mcp/test_concurrency.py:156` — advance_time concurrency (KEEP)
- `tests/mcp/test_decrypt_visibility_tools.py:226` — benchmark visibility (WILL be augmented by Team B for session visibility)
- `tests/mcp/test_session_lifecycle_blind.py:288` — session lifecycle blind output (KEEP)
- `finlet/mcp/tools_session.py:43-105` — `set_session_visibility` MCP tool (READ to confirm: `public: bool`, `anonymous: bool = True` are INPUT params)
- `finlet/api/schemas/session.py:79-101` — `SessionResponse` schema; OUTPUT field is `public_anonymous: bool` (line 101), NOT `anonymous` (Step 10b BLOCKER-3)
- `finlet/api/services/session_service.py:133-198` — `set_visibility` service-layer implementation

## Files touched
- **Modified `tests/test_cli.py`** — TRIM to only kept-command tests. KEEP: auth login/logout/status, register, plugins list/add/remove, manual, mcp serve smoke, root callback + version callback tests, generic CLI behaviors. DELETE: session_create/list/delete/publish tests, advance/order/portfolio/status tests, the `from finlet.cli_mcp_client import MCPDispatchError` import (line 29), any test referencing dropped symbols.
- **Deleted `tests/test_cli_benchmark.py`** (use `git rm`).
- **Modified `tests/test_cli_help.py`** — update help-text snapshot to reflect new command surface (6 commands: serve, register, auth, plugins, mcp, manual).
- **Deleted `tests/api/test_cli_mcp_client.py`** (use `git rm`).
- **Modified `tests/mcp/test_decrypt_visibility_tools.py`** — ADD 4 explicit assertions for `set_session_visibility` (Step 10b BLOCKER-3 — correct schema keys `public_anonymous` NOT `anonymous`):
  1. `set_session_visibility(public=True, anonymous=True)` → `result["public"] == True` AND `result["public_anonymous"] == True`.
  2. `set_session_visibility(public=True, anonymous=False)` → `result["public"] == True` AND `result["public_anonymous"] == False` (attributed flow).
  3. `set_session_visibility(public=False, anonymous=True)` → `result["public"] == False` AND `result["public_anonymous"] == True` (unpublish flow; CLI always passed anonymous=True per cli.py:692).
  4. Anti-shape-drift: assert `"share_url" not in result` (consumer derives URL as `https://finlet.dev/sessions/{id}`; tool shape must NOT silently add this field).
- **Modified (audit only)** — `tests/mcp/test_create_session_blind.py`, `tests/mcp/test_start_benchmark_blind.py`, `tests/mcp/test_submit_order_validation.py`, `tests/mcp/test_concurrency.py`, `tests/mcp/test_session_lifecycle_blind.py` — confirm coverage; no edits unless gaps surface.

## Test fixture hygiene (Step 10b STRONG-3)
Any new test fixture for OAuth tokens / api_keys / session IDs MUST use obviously fake values matching the existing pattern in `tests/mcp/`:
- JWTs: `header.payload.signature` (3 dots, not realistic `eyJ...` base64)
- API keys: `fnlt_test_key_<short>` (NEVER realistic `fnlt_<32hex>`)
- Session IDs: `test-session-001` or `aaaaaaaaaaaaaa` (NEVER realistic UUID-shaped 12-char hex)

Protects gitleaks scanning. See `[[feedback-doc-examples-must-be-low-entropy]]`.

## Deliverable
After this team finishes, `pytest tests/ -x` passes. No coverage regressions. CLI test files contain ONLY tests for kept commands. Explicit MCP-side coverage exists for `set_session_visibility` with correct schema keys.

## Validation
```bash
uv run pytest tests/test_cli.py -x    # passes (no ImportError)
uv run pytest tests/test_cli_help.py -x   # passes (snapshot updated)
uv run pytest tests/test_cli_oauth_login.py -x   # passes (unmodified)
uv run pytest tests/mcp/test_decrypt_visibility_tools.py -x   # passes with 4 new assertions
grep -c "result\[.public_anonymous.\]" tests/mcp/test_decrypt_visibility_tools.py   # ≥3
grep -c '"share_url" not in result' tests/mcp/test_decrypt_visibility_tools.py   # ≥1
uv run pytest tests/mcp/ -x   # passes
uv run pytest tests/ -x --ignore=tests/e2e --ignore=tests/playwright   # passes end-to-end (may take ~10min)
grep -rE 'eyJ[A-Za-z0-9_-]{20,}|fnlt_[a-f0-9]{32}' tests/mcp/test_decrypt_visibility_tools.py   # nothing (no realistic-looking secrets)
git status   # 2 deletions + 3-4 modifications
```

## Agent instructions
- You MUST `git add` (+ `git rm` for deletions) and `git commit` before finishing.
- New MCP-side assertions MUST use `result["public_anonymous"]` (the actual response schema field), NOT `result["anonymous"]` (the INPUT param name). Verify by reading `finlet/api/schemas/session.py:79-101` before writing assertions.
- New test fixtures MUST use obviously-fake values (see "Test fixture hygiene" above). DO NOT use realistic `eyJ...` JWTs or `fnlt_<32hex>` api_keys.
- Do NOT modify `finlet/` source (Team A's lane, already merged).
- Do NOT modify `finlet/mcp/` tools (strict no-shape-change rule).
- Do NOT modify docs, dashboard, or `finlet/manual/` (Team C/D lanes).
- Do NOT modify `pyproject.toml` or `CHANGELOG.md` (Team E's lane).
- Commit message: `[Team B v2.0.0]: trim CLI tests; add 4 MCP assertions on set_session_visibility (public + public_anonymous + no-share-url)`.

## CRITICAL RULES
- Read `docs/KNOWN_FAILURES.md` first — do NOT report these as issues.
- Read the "Read these files first" list BEFORE writing any code.
- You MUST `git add`/`git rm` and `git commit` all your changes before finishing.
- Your commit message must start with `[Team B v2.0.0]:`.
- Run the validation commands above before finishing.

When done, report: DONE + commit hash + validation results.
OR: BLOCKED + what went wrong.

codex
The declared file list is narrow: two test deletions plus three test modifications, with all source, docs, dashboard, manual, pyproject, and changelog off-limits. I’ve got the stat now; next I’m reading the targeted diffs and the exact schema/tool spots needed to verify the assertion keys.
exec
/bin/zsh -lc 'rg -n "''^(##|###|Step|Workflow|Review|Output|Findings|GATE)" /Users/justnau/.agents/skills/gstack/review/SKILL.md' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
29:## Preamble (run first)
109:## Plan Mode Safe Operations
113:## Skill Invocation During Plan Mode
220:## Skill routing
278:## AskUserQuestion Format
280:### Tool resolution (read first)
288:### Format
323:### Self-check before emitting
337:## GBrain Sync (skill start)
411:## Model-Specific Behavioral Patch (Codex)
429:## Voice
445:## Context Recovery
471:## Writing Style (skip entirely if `EXPLAIN_LEVEL: terse` appears in the preamble echo OR the user's current message explicitly requests terse / no-explanations output)
562:## Completeness Principle — Boil the Lake
568:## Confusion Protocol
572:## Continuous Checkpoint Mode
597:## Context Health (soft directive)
603:## Question Tuning (skip entirely if `QUESTION_TUNING: false`)
623:## Repo Ownership — See Something, Say Something
631:## Search Before Building
641:## Completion Status Protocol
651:## Operational Self-Improvement
661:## Telemetry (run last)
690:## Plan Status Footer
696:## Step 0: Detect platform and base branch
741:## Step 1: Check branch
749:## Step 1.5: Scope Drift Detection
784:### Plan File Discovery
814:### Actionable Item Extraction
840:### Cross-Reference Against Diff
854:### Output Format
861:## Implementation Items
867:## Test Items
871:## Migration Items
879:### Fallback Intent Sources (when no plan file found)
892:### Investigation Depth
905:Output for each discrepancy:
912:### Learnings Logging (plan-file discrepancies only)
931:### Integration with Scope Drift Detection
957:## Step 2: Read the checklist
965:## Step 2.5: Check for Greptile review comments
975:## Step 3: Get the diff
985:## Step 3.4: Workspace-aware queue status (advisory)
1007:## Step 3.5: Slop scan (advisory)
1022:## Prior Learnings
1060:## Step 4: Critical pass (core review)
1078:## Confidence Calibration
1105:## Step 4.5: Review Army — Specialist Dispatch
1107:### Detect stack and scope
1133:### Read specialist hit rates (adaptive gating)
1139:### Select specialists
1156:### Adaptive gating
1171:### Dispatch specialists in parallel
1222:### Step 4.6: Collect and merge findings
1284:### Red Team dispatch (conditional)
1298:Output findings as JSON objects (same schema as the specialists). Focus on cross-cutting
1303:Step 5 Fix-First. Red Team findings are tagged with `"specialist":"red-team"`.
1310:## Step 5: Fix-First Review
1314:### Step 5.0: Cross-review finding dedup
1346:Output a summary header: `Pre-Landing Review: N issues (X critical, Y informational)`
1348:### Step 5a: Classify each finding
1362:### Step 5b: Auto-fix all AUTO-FIX items
1367:### Step 5c: Batch-ask about ASK items
1392:### Step 5d: Apply user-approved fixes
1398:### Verification of claims
1408:### Greptile comment resolution
1436:## Step 5.5: TODOS cross-reference
1448:## Step 5.6: Documentation staleness check
1462:## Step 5.7: Adversarial review (always-on)
1485:### Codex adversarial subagent (always runs)
1498:### Codex adversarial challenge (always runs when available)
1526:### Codex structured review (large diffs only, 200+ lines)
1558:### Persist the review result
1568:### Cross-model synthesis
1587:## Step 5.8: Persist Eng Review result
1609:## Capture Learnings
1636:## Important Rules

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet show --name-only --format=fuller 014329f' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
commit 014329fceca8a5d42f48ade1ab3ca0be93f6767d
Author:     Justin Nam <justnau@Justins-MacBook-Air-2.local>
AuthorDate: Fri May 22 22:52:36 2026 -0500
Commit:     Justin Nam <justnau@Justins-MacBook-Air-2.local>
CommitDate: Fri May 22 22:52:36 2026 -0500

    [Team B v2.0.0]: trim CLI tests; add 4 MCP assertions on set_session_visibility (public + public_anonymous + no-share-url)
    
    V2 pure-MCP migration test cleanup (Step 10b BLOCKER-3):
    
    * DELETE `tests/test_cli_benchmark.py` (204 lines) — `finlet benchmark *`
      subcommands were removed in Team A's v2.0.0 cutover.
    * DELETE `tests/api/test_cli_mcp_client.py` (354 lines) — Team A deleted
      `finlet/cli_mcp_client.py`; nothing imports it now.
    * MODIFY `tests/test_cli.py` — strip 1499 lines covering dropped commands
      (session create/list/delete/publish, advance, order, portfolio, status,
      benchmark visibility) and the dispatch-helper unit classes
      (TestTranslateMcpError, TestResolveBearerToken, TestEmitEnvelope) that
      tested helpers Team A removed. Update TestTopLevelCommands to assert
      the new 6-command surface (serve/register/manual/plugins/auth/mcp) and
      add a regression guard `test_dropped_agentic_commands_not_registered`
      that fails if any agentic command leaks back into --help. Drops the
      `from finlet.cli_mcp_client import MCPDispatchError` import (Team A
      ImportError surface).
    * MODIFY `tests/test_cli_help.py` — drop the 4 dropped-command help tests
      (advance/order/portfolio/status), drop the `session` sub-app help test,
      add `manual --help` smoke. Module docstring updated to reflect the
      v2.0.0 6-command surface.
    * MODIFY `tests/mcp/test_decrypt_visibility_tools.py` — add the new
      `TestMcpSetSessionVisibilitySchemaKeys` class with 4 explicit
      assertions pinning the response schema for the SESSION-level
      visibility tool (separate from the existing benchmark-level tests):
        1. `public=True, anonymous=True`  → `result["public"]=True AND result["public_anonymous"]=True`.
        2. `public=True, anonymous=False` → `result["public"]=True AND result["public_anonymous"]=False` (attributed flow).
        3. `public=False, anonymous=True` → `result["public"]=False AND result["public_anonymous"]=True` (unpublish flow).
        4. Anti-shape-drift: `"share_url" not in result` (consumer derives URL externally).
      Locks in the Codex-flagged risk that INPUT param `anonymous` and
      OUTPUT field `public_anonymous` must not be silently aliased. Test
      fixtures use obviously-fake values (`fnlt_test_key_visibility`,
      `00000000-0000-0000-0000-00000000bbbb`) per Step 10b STRONG-3
      gitleaks safety. Forwards `tools_session.resolve_credential` to the
      conftest shim explicitly (the autouse shim doesn't patch
      tools_session, mirroring the pattern in
      `tests/mcp/test_session_lifecycle_blind.py::_mock_auth`).
    
    Validation:
      pytest tests/test_cli.py                       → 37 passed (was ImportError pre-trim)
      pytest tests/test_cli_help.py                  → 6 passed
      pytest tests/test_cli_oauth_login.py           → 16 passed (unmodified)
      pytest tests/mcp/test_decrypt_visibility_tools → 18 passed (14 existing + 4 new)
      pytest tests/mcp/                              → 639 passed, 1 xfailed, 0 failed
      ruff check tests/                              → All checks passed
      grep -c 'result\["public_anonymous"\]' …      → 3 (≥3 required)
      grep -c '"share_url" not in result' …          → 1 (≥1 required)
      grep -rE 'eyJ[A-Za-z0-9_-]{20,}|fnlt_[a-f0-9]{32}' tests/mcp/test_decrypt_visibility_tools.py → 0 (gitleaks-safe)
    
    Net diff: -1693 lines (2 files deleted, 3 files trimmed/augmented).

tests/api/test_cli_mcp_client.py
tests/mcp/test_decrypt_visibility_tools.py
tests/test_cli.py
tests/test_cli_benchmark.py
tests/test_cli_help.py

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet show --find-renames --find-copies --stat --summary 014329f' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
commit 014329fceca8a5d42f48ade1ab3ca0be93f6767d
Author: Justin Nam <justnau@Justins-MacBook-Air-2.local>
Date:   Fri May 22 22:52:36 2026 -0500

    [Team B v2.0.0]: trim CLI tests; add 4 MCP assertions on set_session_visibility (public + public_anonymous + no-share-url)
    
    V2 pure-MCP migration test cleanup (Step 10b BLOCKER-3):
    
    * DELETE `tests/test_cli_benchmark.py` (204 lines) — `finlet benchmark *`
      subcommands were removed in Team A's v2.0.0 cutover.
    * DELETE `tests/api/test_cli_mcp_client.py` (354 lines) — Team A deleted
      `finlet/cli_mcp_client.py`; nothing imports it now.
    * MODIFY `tests/test_cli.py` — strip 1499 lines covering dropped commands
      (session create/list/delete/publish, advance, order, portfolio, status,
      benchmark visibility) and the dispatch-helper unit classes
      (TestTranslateMcpError, TestResolveBearerToken, TestEmitEnvelope) that
      tested helpers Team A removed. Update TestTopLevelCommands to assert
      the new 6-command surface (serve/register/manual/plugins/auth/mcp) and
      add a regression guard `test_dropped_agentic_commands_not_registered`
      that fails if any agentic command leaks back into --help. Drops the
      `from finlet.cli_mcp_client import MCPDispatchError` import (Team A
      ImportError surface).
    * MODIFY `tests/test_cli_help.py` — drop the 4 dropped-command help tests
      (advance/order/portfolio/status), drop the `session` sub-app help test,
      add `manual --help` smoke. Module docstring updated to reflect the
      v2.0.0 6-command surface.
    * MODIFY `tests/mcp/test_decrypt_visibility_tools.py` — add the new
      `TestMcpSetSessionVisibilitySchemaKeys` class with 4 explicit
      assertions pinning the response schema for the SESSION-level
      visibility tool (separate from the existing benchmark-level tests):
        1. `public=True, anonymous=True`  → `result["public"]=True AND result["public_anonymous"]=True`.
        2. `public=True, anonymous=False` → `result["public"]=True AND result["public_anonymous"]=False` (attributed flow).
        3. `public=False, anonymous=True` → `result["public"]=False AND result["public_anonymous"]=True` (unpublish flow).
        4. Anti-shape-drift: `"share_url" not in result` (consumer derives URL externally).
      Locks in the Codex-flagged risk that INPUT param `anonymous` and
      OUTPUT field `public_anonymous` must not be silently aliased. Test
      fixtures use obviously-fake values (`fnlt_test_key_visibility`,
      `00000000-0000-0000-0000-00000000bbbb`) per Step 10b STRONG-3
      gitleaks safety. Forwards `tools_session.resolve_credential` to the
      conftest shim explicitly (the autouse shim doesn't patch
      tools_session, mirroring the pattern in
      `tests/mcp/test_session_lifecycle_blind.py::_mock_auth`).
    
    Validation:
      pytest tests/test_cli.py                       → 37 passed (was ImportError pre-trim)
      pytest tests/test_cli_help.py                  → 6 passed
      pytest tests/test_cli_oauth_login.py           → 16 passed (unmodified)
      pytest tests/mcp/test_decrypt_visibility_tools → 18 passed (14 existing + 4 new)
      pytest tests/mcp/                              → 639 passed, 1 xfailed, 0 failed
      ruff check tests/                              → All checks passed
      grep -c 'result\["public_anonymous"\]' …      → 3 (≥3 required)
      grep -c '"share_url" not in result' …          → 1 (≥1 required)
      grep -rE 'eyJ[A-Za-z0-9_-]{20,}|fnlt_[a-f0-9]{32}' tests/mcp/test_decrypt_visibility_tools.py → 0 (gitleaks-safe)
    
    Net diff: -1693 lines (2 files deleted, 3 files trimmed/augmented).

 tests/api/test_cli_mcp_client.py           |  354 -------
 tests/mcp/test_decrypt_visibility_tools.py |  257 ++++-
 tests/test_cli.py                          | 1499 ++--------------------------
 tests/test_cli_benchmark.py                |  204 ----
 tests/test_cli_help.py                     |   45 +-
 5 files changed, 333 insertions(+), 2026 deletions(-)
 delete mode 100644 tests/api/test_cli_mcp_client.py
 delete mode 100644 tests/test_cli_benchmark.py

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet show 014329f -- tests/mcp/test_decrypt_visibility_tools.py' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
commit 014329fceca8a5d42f48ade1ab3ca0be93f6767d
Author: Justin Nam <justnau@Justins-MacBook-Air-2.local>
Date:   Fri May 22 22:52:36 2026 -0500

    [Team B v2.0.0]: trim CLI tests; add 4 MCP assertions on set_session_visibility (public + public_anonymous + no-share-url)
    
    V2 pure-MCP migration test cleanup (Step 10b BLOCKER-3):
    
    * DELETE `tests/test_cli_benchmark.py` (204 lines) — `finlet benchmark *`
      subcommands were removed in Team A's v2.0.0 cutover.
    * DELETE `tests/api/test_cli_mcp_client.py` (354 lines) — Team A deleted
      `finlet/cli_mcp_client.py`; nothing imports it now.
    * MODIFY `tests/test_cli.py` — strip 1499 lines covering dropped commands
      (session create/list/delete/publish, advance, order, portfolio, status,
      benchmark visibility) and the dispatch-helper unit classes
      (TestTranslateMcpError, TestResolveBearerToken, TestEmitEnvelope) that
      tested helpers Team A removed. Update TestTopLevelCommands to assert
      the new 6-command surface (serve/register/manual/plugins/auth/mcp) and
      add a regression guard `test_dropped_agentic_commands_not_registered`
      that fails if any agentic command leaks back into --help. Drops the
      `from finlet.cli_mcp_client import MCPDispatchError` import (Team A
      ImportError surface).
    * MODIFY `tests/test_cli_help.py` — drop the 4 dropped-command help tests
      (advance/order/portfolio/status), drop the `session` sub-app help test,
      add `manual --help` smoke. Module docstring updated to reflect the
      v2.0.0 6-command surface.
    * MODIFY `tests/mcp/test_decrypt_visibility_tools.py` — add the new
      `TestMcpSetSessionVisibilitySchemaKeys` class with 4 explicit
      assertions pinning the response schema for the SESSION-level
      visibility tool (separate from the existing benchmark-level tests):
        1. `public=True, anonymous=True`  → `result["public"]=True AND result["public_anonymous"]=True`.
        2. `public=True, anonymous=False` → `result["public"]=True AND result["public_anonymous"]=False` (attributed flow).
        3. `public=False, anonymous=True` → `result["public"]=False AND result["public_anonymous"]=True` (unpublish flow).
        4. Anti-shape-drift: `"share_url" not in result` (consumer derives URL externally).
      Locks in the Codex-flagged risk that INPUT param `anonymous` and
      OUTPUT field `public_anonymous` must not be silently aliased. Test
      fixtures use obviously-fake values (`fnlt_test_key_visibility`,
      `00000000-0000-0000-0000-00000000bbbb`) per Step 10b STRONG-3
      gitleaks safety. Forwards `tools_session.resolve_credential` to the
      conftest shim explicitly (the autouse shim doesn't patch
      tools_session, mirroring the pattern in
      `tests/mcp/test_session_lifecycle_blind.py::_mock_auth`).
    
    Validation:
      pytest tests/test_cli.py                       → 37 passed (was ImportError pre-trim)
      pytest tests/test_cli_help.py                  → 6 passed
      pytest tests/test_cli_oauth_login.py           → 16 passed (unmodified)
      pytest tests/mcp/test_decrypt_visibility_tools → 18 passed (14 existing + 4 new)
      pytest tests/mcp/                              → 639 passed, 1 xfailed, 0 failed
      ruff check tests/                              → All checks passed
      grep -c 'result\["public_anonymous"\]' …      → 3 (≥3 required)
      grep -c '"share_url" not in result' …          → 1 (≥1 required)
      grep -rE 'eyJ[A-Za-z0-9_-]{20,}|fnlt_[a-f0-9]{32}' tests/mcp/test_decrypt_visibility_tools.py → 0 (gitleaks-safe)
    
    Net diff: -1693 lines (2 files deleted, 3 files trimmed/augmented).

diff --git a/tests/mcp/test_decrypt_visibility_tools.py b/tests/mcp/test_decrypt_visibility_tools.py
index dce4fea..b7dffc6 100644
--- a/tests/mcp/test_decrypt_visibility_tools.py
+++ b/tests/mcp/test_decrypt_visibility_tools.py
@@ -10,18 +10,28 @@ Validates the blind-export redesign post-completion lifecycle:
 * Ownership: cross-user requests return ``benchmark_run_not_found`` (no leak).
 * Mid-flight runs: both tools return ``benchmark_run_not_completed``.
 * Tools registered in :mod:`finlet.mcp.server` for FastMCP discovery.
+
+Also pins the v2.0.0 schema-key contract for the SESSION-level visibility
+tool (``set_session_visibility`` in :mod:`finlet.mcp.tools_session`) — see
+the four ``TestMcpSetSessionVisibilitySchemaKeys`` tests below. These were
+added by Team B (V2_PURE_MCP_EXECUTION_PLAN Step 10b BLOCKER-3) to lock
+in that the MCP tool's success envelope uses ``public_anonymous`` (the
+OUTPUT schema field at :class:`finlet.api.schemas.session.SessionResponse`)
+NOT ``anonymous`` (the INPUT param name) — a Codex-flagged shape-drift
+risk between the request body and the response.
 """
 
 from __future__ import annotations
 
 import hashlib
-from datetime import datetime, timezone
+from datetime import datetime, timedelta, timezone
 from typing import Any
 from unittest.mock import AsyncMock
 
 import pytest
 
 from finlet.auth.service import AuthService, UserRecord, UserTier
+from finlet.core.session import Session, SessionConfig
 from finlet.leaderboard.benchmark_state import (
     BenchmarkRun,
     ScenarioResult,
@@ -37,6 +47,9 @@ from finlet.mcp.tools_benchmark import (
 from finlet.mcp.tools_benchmark import (
     set_benchmark_visibility as mcp_set_benchmark_visibility,
 )
+from finlet.mcp.tools_session import (
+    set_session_visibility as mcp_set_session_visibility,
+)
 
 # ── Constants ───────────────────────────────────────────────────
 
@@ -370,6 +383,248 @@ async def test_visibility_anonymous_default_true(monkeypatch: Any) -> None:
     assert result["published_anonymous"] is True
 
 
+# ── set_session_visibility — Step 10b BLOCKER-3 schema-key assertions ──
+#
+# v2.0.0 pure-MCP migration (Team B) adds explicit MCP-side coverage for
+# ``set_session_visibility`` (the SESSION-level visibility tool, separate
+# from ``set_benchmark_visibility``).  Pins the response shape so a future
+# refactor cannot silently rename ``public_anonymous`` (output) to match
+# the input param name ``anonymous`` — a Codex-flagged schema-drift risk
+# captured in the V2_PURE_MCP_EXECUTION_PLAN Step 10b review.
+#
+# Tool spec:
+#   set_session_visibility(session_id, public, anonymous=True, api_key) → dict
+#   • input param: ``anonymous: bool`` (signals "anonymous attribution")
+#   • output field: ``public_anonymous: bool`` (matches SessionResponse)
+#
+# The four tests below cover the full publish / unpublish flag matrix
+# plus an anti-shape-drift guard that ``share_url`` does NOT appear in
+# the response (the dashboard / agent derives the share URL externally
+# as ``https://finlet.dev/sessions/{id}``).
+
+
+# Obviously-fake test fixtures — gitleaks-safe per Step 10b STRONG-3.
+SESSION_VISIBILITY_API_KEY = "fnlt_test_key_visibility"
+SESSION_VISIBILITY_USER_ID = "session-vis-user"
+
+# UUID-shaped session_id that passes ``validate_session_id`` regex BUT is
+# obviously a test fixture (14-character all-zeros payload, NOT a real
+# uuid4-generated value).
+SESSION_VISIBILITY_SESSION_ID = "00000000-0000-0000-0000-00000000bbbb"
+
+_SESSION_VISIBILITY_USER = UserRecord(
+    id=SESSION_VISIBILITY_USER_ID,
+    email="set-session-vis@finlet.dev",
+    tier=UserTier.FREE,
+    created_at=datetime(2024, 1, 1, tzinfo=timezone.utc),
+)
+
+_SESSION_VISIBILITY_BASE_TIME = datetime(2024, 1, 2, 14, 30, tzinfo=timezone.utc)
+
+
+def _mock_session_visibility_auth(monkeypatch: Any) -> None:
+    """Plant SESSION_VISIBILITY_API_KEY into a fake AuthService for MCP auth.
+
+    Mirrors the propagation pattern in
+    ``tests/mcp/test_session_lifecycle_blind.py::_mock_auth`` — the root
+    conftest's ``_legacy_api_key_test_shim`` patches the binding on
+    server / tools_portfolio / tools_trading / tools_benchmark but NOT
+    tools_session, which was added later (Public Session View, 2026-05-12).
+    Without this forward, ``set_session_visibility`` hits the Phase 4e
+    Bearer-only production rejection envelope.
+    """
+    _SESSION_VISIBILITY_USER.sessions_today = 0
+    _SESSION_VISIBILITY_USER.active_sessions = 0
+    fake_service = AuthService()
+    key_hash = hashlib.sha256(SESSION_VISIBILITY_API_KEY.encode()).hexdigest()
+    fake_service.insert_record(key_hash, _SESSION_VISIBILITY_USER)
+    monkeypatch.setattr("finlet.mcp.auth.auth_service", fake_service)
+    monkeypatch.setattr("finlet.auth.service.auth_service", fake_service)
+
+    from finlet.mcp import bearer_context as _bc
+
+    monkeypatch.setattr(
+        "finlet.mcp.tools_session.resolve_credential", _bc.resolve_credential
+    )
+
+
+def _make_visibility_session(
+    *,
+    user_id: str = SESSION_VISIBILITY_USER_ID,
+    session_id: str = SESSION_VISIBILITY_SESSION_ID,
+    public: bool = False,
+    anonymous: bool = True,
+) -> Session:
+    """Construct a non-blind session for set_session_visibility coverage.
+
+    Non-blind (``blind=False``) so the response passes through
+    :func:`session_response` with ``blind_mapping=None`` — owner-view
+    shape preserved, matches the Phase 4e Bearer-only contract.
+    """
+    config = SessionConfig(
+        start_time=_SESSION_VISIBILITY_BASE_TIME,
+        end_time=_SESSION_VISIBILITY_BASE_TIME + timedelta(days=30),
+        initial_capital=100_000.0,
+        universe=["AAPL", "MSFT"],
+        time_step="1d",
+        blind=False,
+        public=public,
+        public_anonymous=anonymous,
+    )
+    session = Session(
+        config,
+        session_id=session_id,
+        user_id=user_id,
+        name="visibility-test-session",
+    )
+    session.activate()
+    return session
+
+
+class TestMcpSetSessionVisibilitySchemaKeys:
+    """Pin v2.0.0 contract: response uses ``public_anonymous`` NOT ``anonymous``.
+
+    Step 10b BLOCKER-3 — the INPUT param is named ``anonymous`` but the
+    OUTPUT field on :class:`finlet.api.schemas.session.SessionResponse` is
+    ``public_anonymous``.  A reasonable-looking refactor that aliases the
+    response key to ``anonymous`` would drift the contract silently — these
+    tests catch that.
+    """
+
+    @pytest.mark.asyncio
+    async def test_publish_anonymous_emits_public_anonymous_true(
+        self, monkeypatch: pytest.MonkeyPatch
+    ) -> None:
+        """``public=True, anonymous=True`` → ``public AND public_anonymous`` both True."""
+        _mock_session_visibility_auth(monkeypatch)
+        sessions_map: dict[str, Session] = {}
+        monkeypatch.setattr("finlet.mcp.auth.get_sessions", lambda: sessions_map)
+        monkeypatch.setattr(
+            "finlet.api.services.session_service.persist_session", AsyncMock()
+        )
+
+        session = _make_visibility_session()
+        sessions_map[session.id] = session
+
+        result = await mcp_set_session_visibility(
+            session_id=session.id,
+            public=True,
+            anonymous=True,
+            api_key=SESSION_VISIBILITY_API_KEY,
+        )
+
+        assert "error" not in result, f"Unexpected error: {result}"
+        assert result["public"] is True
+        assert result["public_anonymous"] is True
+        # The INPUT param name ``anonymous`` must NOT appear as a top-level
+        # output key — the response schema field is ``public_anonymous``.
+        assert "anonymous" not in result, (
+            f"Response leaked INPUT param name ``anonymous`` as a top-level "
+            f"key — should be ``public_anonymous`` only (schema drift): {result}"
+        )
+
+    @pytest.mark.asyncio
+    async def test_publish_attributed_emits_public_anonymous_false(
+        self, monkeypatch: pytest.MonkeyPatch
+    ) -> None:
+        """``public=True, anonymous=False`` (attributed flow) → ``public_anonymous`` False."""
+        _mock_session_visibility_auth(monkeypatch)
+        sessions_map: dict[str, Session] = {}
+        monkeypatch.setattr("finlet.mcp.auth.get_sessions", lambda: sessions_map)
+        monkeypatch.setattr(
+            "finlet.api.services.session_service.persist_session", AsyncMock()
+        )
+
+        session = _make_visibility_session()
+        sessions_map[session.id] = session
+
+        result = await mcp_set_session_visibility(
+            session_id=session.id,
+            public=True,
+            anonymous=False,
+            api_key=SESSION_VISIBILITY_API_KEY,
+        )
+
+        assert "error" not in result, f"Unexpected error: {result}"
+        assert result["public"] is True
+        assert result["public_anonymous"] is False
+
+    @pytest.mark.asyncio
+    async def test_unpublish_default_anonymous_true(
+        self, monkeypatch: pytest.MonkeyPatch
+    ) -> None:
+        """``public=False, anonymous=True`` (unpublish flow per cli.py:692).
+
+        The CLI always passed ``anonymous=True`` on the dropped
+        ``finlet session unpublish`` path; agents now hit this directly
+        via MCP. ``public_anonymous`` should still surface in the
+        response as ``True`` (the anonymity preference is persisted even
+        when ``public=False`` so re-publishing later restores it).
+        """
+        _mock_session_visibility_auth(monkeypatch)
+        sessions_map: dict[str, Session] = {}
+        monkeypatch.setattr("finlet.mcp.auth.get_sessions", lambda: sessions_map)
+        monkeypatch.setattr(
+            "finlet.api.services.session_service.persist_session", AsyncMock()
+        )
+
+        # Seed the session pre-published so the unpublish path is
+        # semantically meaningful — set_visibility flips public=False
+        # on a previously-public session.
+        session = _make_visibility_session(public=True, anonymous=True)
+        sessions_map[session.id] = session
+
+        result = await mcp_set_session_visibility(
+            session_id=session.id,
+            public=False,
+            anonymous=True,
+            api_key=SESSION_VISIBILITY_API_KEY,
+        )
+
+        assert "error" not in result, f"Unexpected error: {result}"
+        assert result["public"] is False
+        assert result["public_anonymous"] is True
+
+    @pytest.mark.asyncio
+    async def test_response_does_not_include_share_url(
+        self, monkeypatch: pytest.MonkeyPatch
+    ) -> None:
+        """Anti-shape-drift: response MUST NOT include ``share_url``.
+
+        The dashboard / agent derives the public URL externally as
+        ``https://finlet.dev/sessions/{id}`` — embedding it in the MCP
+        response would couple the tool shape to the deployment URL and
+        violate the contract pinned in
+        :class:`finlet.api.schemas.session.SessionResponse`.  This
+        assertion locks the absence so a well-intentioned helper that
+        adds ``d["share_url"] = ...`` to ``session_response`` is caught
+        at PR time.
+        """
+        _mock_session_visibility_auth(monkeypatch)
+        sessions_map: dict[str, Session] = {}
+        monkeypatch.setattr("finlet.mcp.auth.get_sessions", lambda: sessions_map)
+        monkeypatch.setattr(
+            "finlet.api.services.session_service.persist_session", AsyncMock()
+        )
+
+        session = _make_visibility_session()
+        sessions_map[session.id] = session
+
+        result = await mcp_set_session_visibility(
+            session_id=session.id,
+            public=True,
+            anonymous=True,
+            api_key=SESSION_VISIBILITY_API_KEY,
+        )
+
+        assert "error" not in result, f"Unexpected error: {result}"
+        assert "share_url" not in result, (
+            f"Response leaked ``share_url`` key (shape-drift) — consumers "
+            f"derive the URL as ``https://finlet.dev/sessions/{{id}}`` "
+            f"externally; the MCP tool shape MUST NOT include it: {result}"
+        )
+
+
 # ── Tools registered for FastMCP discovery ──────────────────────
 
 

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet show 014329f -- tests/test_cli.py' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
commit 014329fceca8a5d42f48ade1ab3ca0be93f6767d
Author: Justin Nam <justnau@Justins-MacBook-Air-2.local>
Date:   Fri May 22 22:52:36 2026 -0500

    [Team B v2.0.0]: trim CLI tests; add 4 MCP assertions on set_session_visibility (public + public_anonymous + no-share-url)
    
    V2 pure-MCP migration test cleanup (Step 10b BLOCKER-3):
    
    * DELETE `tests/test_cli_benchmark.py` (204 lines) — `finlet benchmark *`
      subcommands were removed in Team A's v2.0.0 cutover.
    * DELETE `tests/api/test_cli_mcp_client.py` (354 lines) — Team A deleted
      `finlet/cli_mcp_client.py`; nothing imports it now.
    * MODIFY `tests/test_cli.py` — strip 1499 lines covering dropped commands
      (session create/list/delete/publish, advance, order, portfolio, status,
      benchmark visibility) and the dispatch-helper unit classes
      (TestTranslateMcpError, TestResolveBearerToken, TestEmitEnvelope) that
      tested helpers Team A removed. Update TestTopLevelCommands to assert
      the new 6-command surface (serve/register/manual/plugins/auth/mcp) and
      add a regression guard `test_dropped_agentic_commands_not_registered`
      that fails if any agentic command leaks back into --help. Drops the
      `from finlet.cli_mcp_client import MCPDispatchError` import (Team A
      ImportError surface).
    * MODIFY `tests/test_cli_help.py` — drop the 4 dropped-command help tests
      (advance/order/portfolio/status), drop the `session` sub-app help test,
      add `manual --help` smoke. Module docstring updated to reflect the
      v2.0.0 6-command surface.
    * MODIFY `tests/mcp/test_decrypt_visibility_tools.py` — add the new
      `TestMcpSetSessionVisibilitySchemaKeys` class with 4 explicit
      assertions pinning the response schema for the SESSION-level
      visibility tool (separate from the existing benchmark-level tests):
        1. `public=True, anonymous=True`  → `result["public"]=True AND result["public_anonymous"]=True`.
        2. `public=True, anonymous=False` → `result["public"]=True AND result["public_anonymous"]=False` (attributed flow).
        3. `public=False, anonymous=True` → `result["public"]=False AND result["public_anonymous"]=True` (unpublish flow).
        4. Anti-shape-drift: `"share_url" not in result` (consumer derives URL externally).
      Locks in the Codex-flagged risk that INPUT param `anonymous` and
      OUTPUT field `public_anonymous` must not be silently aliased. Test
      fixtures use obviously-fake values (`fnlt_test_key_visibility`,
      `00000000-0000-0000-0000-00000000bbbb`) per Step 10b STRONG-3
      gitleaks safety. Forwards `tools_session.resolve_credential` to the
      conftest shim explicitly (the autouse shim doesn't patch
      tools_session, mirroring the pattern in
      `tests/mcp/test_session_lifecycle_blind.py::_mock_auth`).
    
    Validation:
      pytest tests/test_cli.py                       → 37 passed (was ImportError pre-trim)
      pytest tests/test_cli_help.py                  → 6 passed
      pytest tests/test_cli_oauth_login.py           → 16 passed (unmodified)
      pytest tests/mcp/test_decrypt_visibility_tools → 18 passed (14 existing + 4 new)
      pytest tests/mcp/                              → 639 passed, 1 xfailed, 0 failed
      ruff check tests/                              → All checks passed
      grep -c 'result\["public_anonymous"\]' …      → 3 (≥3 required)
      grep -c '"share_url" not in result' …          → 1 (≥1 required)
      grep -rE 'eyJ[A-Za-z0-9_-]{20,}|fnlt_[a-f0-9]{32}' tests/mcp/test_decrypt_visibility_tools.py → 0 (gitleaks-safe)
    
    Net diff: -1693 lines (2 files deleted, 3 files trimmed/augmented).

diff --git a/tests/test_cli.py b/tests/test_cli.py
index 0d7e176..3c351d6 100644
--- a/tests/test_cli.py
+++ b/tests/test_cli.py
@@ -1,32 +1,37 @@
 """Tests for Finlet CLI commands.
 
-Phase 5 (CLI MCP-over-stdio rewire) split the CLI surface in two:
-
-* **KEEP commands** (``serve``, ``register``, ``auth login``, ``auth logout``,
-  ``plugins list/add/remove``) continue to call REST via httpx.  Their tests
-  mock httpx as before.
-
-* **Migrated commands** (``session create/list/delete``, ``advance``, ``order``,
-  ``portfolio``, ``status``) dispatch through ``finlet.cli_mcp_client``.  Their
-  tests mock :func:`finlet.cli_mcp_client.call_tool_sync` so the test stays
-  fast (no subprocess spawn) and asserts the tool dispatch contract.
-
-The integration-tier tests at ``tests/integration/test_cli_stdio_e2e.py``
-exercise the real subprocess + live server end-to-end.
+v2.0.0 (pure-MCP migration, 2026-05-23) shrank the CLI surface to operator
+commands only:
+
+* ``serve`` (REST/MCP server bootstrap)
+* ``register`` (one-shot account creation, calls REST)
+* ``manual`` (offline manual viewer, no I/O)
+* sub-app ``plugins`` — ``list`` / ``add`` / ``remove`` (operator plugin admin)
+* sub-app ``auth`` — ``login`` / ``logout`` / ``status`` (OAuth credential mgmt)
+* sub-app ``mcp`` — ``serve`` (run MCP server over stdio)
+
+All agentic-trading commands (``session create/list/delete/publish``,
+``advance``, ``order``, ``portfolio``, ``status``, ``benchmark *``) were
+removed in Team A's v2.0.0 cutover — agents now drive Finlet directly
+through the MCP surface. The corresponding test classes
+(``TestSessionCommandsViaMCP``, ``TestBenchmarkVisibilityCommandsViaMCP``,
+``TestAdvanceCommandViaMCP``, ``TestOrderCommandViaMCP``,
+``TestPortfolioCommandViaMCP``, ``TestStatusCommandViaMCP``) and the
+dispatch-helper classes (``TestTranslateMcpError``,
+``TestResolveBearerToken``, ``TestEmitEnvelope``) were dropped from this
+file alongside ``finlet/cli_mcp_client.py``. The MCP-side coverage for
+the dropped commands lives in ``tests/mcp/*``.
 """
 
 from __future__ import annotations
 
 import re
-from typing import Any
 from unittest.mock import MagicMock, patch
 
 import httpx
-import pytest
 from typer.testing import CliRunner
 
 from finlet.cli import app
-from finlet.cli_mcp_client import MCPDispatchError
 
 runner = CliRunner()
 
@@ -52,1077 +57,7 @@ def _mock_response(status_code: int = 200, json_data: dict | None = None, text:
     return resp
 
 
-# ─── Migrated commands (MCP-over-stdio) ─────────────────────────────
-
-
-class TestSessionCommandsViaMCP:
-    """``finlet session create / list / delete`` dispatch through ``call_tool_sync``."""
-
-    def test_session_subcommands_registered(self):
-        """Verify create, list, and delete subcommands are registered."""
-        result = runner.invoke(app, ["session", "--help"])
-        assert result.exit_code == 0
-        output = _strip_ansi(result.output)
-        assert "create" in output
-        assert "list" in output
-        assert "delete" in output
-
-    def test_session_delete_requires_argument(self):
-        """Delete command should fail without a session_id argument."""
-        result = runner.invoke(app, ["session", "delete"])
-        assert result.exit_code != 0
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_create_dispatches_create_session_tool(self, mock_call: MagicMock) -> None:
-        """``session create`` builds the right argument shape and prints the tool envelope."""
-        mock_call.return_value = {
-            "id": "sid-abc",
-            "name": "Demo",
-            "config": {"start_time": "2024-01-01T00:00:00+00:00", "initial_capital": 100_000.0},
-        }
-        result = runner.invoke(
-            app,
-            [
-                "session",
-                "create",
-                "--name",
-                "Demo",
-                "--start",
-                "2024-01-01",
-                "--api-key",
-                "fk_test",
-            ],
-        )
-        assert result.exit_code == 0, result.output
-        mock_call.assert_called_once()
-        tool_name, tool_args = mock_call.call_args.args[0], mock_call.call_args.args[1]
-        assert tool_name == "create_session"
-        assert tool_args["name"] == "Demo"
-        assert tool_args["start_time"] == "2024-01-01"
-        assert tool_args["initial_capital"] == 100_000.0
-        assert tool_args["universe"] == []
-        # Bearer JWT (or api_key fallback) is forwarded as a kwarg.
-        assert mock_call.call_args.kwargs.get("bearer_token") == "fk_test"
-        assert "sid-abc" in result.output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_create_universe_split(self, mock_call: MagicMock) -> None:
-        """``--universe`` is split on commas + trimmed before tool dispatch."""
-        mock_call.return_value = {
-            "id": "sid-x",
-            "name": "Multi",
-            "config": {"start_time": "2024-01-01T00:00:00+00:00", "initial_capital": 50_000.0},
-        }
-        result = runner.invoke(
-            app,
-            [
-                "session",
-                "create",
-                "--name",
-                "Multi",
-                "--start",
-                "2024-01-01",
-                "--capital",
-                "50000",
-                "--universe",
-                "AAPL, MSFT,GOOGL ",
-                "--api-key",
-                "fk_test",
-            ],
-        )
-        assert result.exit_code == 0, result.output
-        tool_args = mock_call.call_args.args[1]
-        assert tool_args["universe"] == ["AAPL", "MSFT", "GOOGL"]
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_create_blind_cli_does_not_echo_real_tickers(
-        self, mock_call: MagicMock
-    ) -> None:
-        """Codex Team D P1 BLOCKER — CLI must not print real tickers for blind sessions.
-
-        Regression: ``session create --blind --universe AAPL,MSFT`` used to echo
-        the local ``tickers`` list ("AAPL, MSFT") even though the response config
-        carried opaque ``T_NNNN`` ids. The CLI now prints the response's
-        ``config['universe']`` so the blind contract holds end-to-end.
-        """
-        mock_call.return_value = {
-            "id": "sid-blind",
-            "name": "blind-test",
-            "config": {
-                "start_time": "Day_1",
-                "initial_capital": 100_000.0,
-                "universe": ["T_0001", "T_0002"],
-                "blind": True,
-            },
-        }
-        result = runner.invoke(
-            app,
-            [
-                "session",
-                "create",
-                "--name",
-                "blind-test",
-                "--start",
-                "2024-01-01",
-                "--capital",
-                "100000",
-                "--universe",
-                "AAPL,MSFT",
-                "--blind",
-                "--api-key",
-                "fk_test",
-            ],
-        )
-        assert result.exit_code == 0, result.output
-        stdout = _strip_ansi(result.output)
-        # The real tickers passed via --universe MUST NOT appear in CLI output.
-        assert "AAPL" not in stdout, f"Real ticker leaked to CLI stdout: {stdout!r}"
-        assert "MSFT" not in stdout, f"Real ticker leaked to CLI stdout: {stdout!r}"
-        # The opaque ids from the response config MUST appear instead.
-        assert "T_0001" in stdout, f"Opaque ticker missing from CLI stdout: {stdout!r}"
-        assert "T_0002" in stdout, f"Opaque ticker missing from CLI stdout: {stdout!r}"
-        # The blind start_time placeholder also flows through.
-        assert "Day_1" in stdout
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_create_non_blind_universe_uses_response_config(
-        self, mock_call: MagicMock
-    ) -> None:
-        """Non-blind sessions still render the universe — from the response, not local input."""
-        mock_call.return_value = {
-            "id": "sid-clear",
-            "name": "clear",
-            "config": {
-                "start_time": "2024-01-01T00:00:00+00:00",
-                "initial_capital": 100_000.0,
-                "universe": ["AAPL", "MSFT"],
-            },
-        }
-        result = runner.invoke(
-            app,
-            [
-                "session",
-                "create",
-                "--name",
-                "clear",
-                "--start",
-                "2024-01-01",
-                "--universe",
-                "AAPL,MSFT",
-                "--api-key",
-                "fk_test",
-            ],
-        )
-        assert result.exit_code == 0, result.output
-        stdout = _strip_ansi(result.output)
-        assert "Universe: AAPL, MSFT" in stdout
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_create_falls_back_to_local_universe_if_response_omits(
-        self, mock_call: MagicMock
-    ) -> None:
-        """Back-compat: when response config has no ``universe`` key, fall back to local input.
-
-        Protects the non-blind UX in case an older server build doesn't echo the
-        universe back; the fallback NEVER applies to blind sessions because the
-        blind server contract always includes ``universe`` with opaque ids.
-        """
-        mock_call.return_value = {
-            "id": "sid-legacy",
-            "name": "legacy",
-            "config": {
-                "start_time": "2024-01-01T00:00:00+00:00",
-                "initial_capital": 100_000.0,
-                # no 'universe' key
-            },
-        }
-        result = runner.invoke(
-            app,
-            [
-                "session",
-                "create",
-                "--name",
-                "legacy",
-                "--start",
-                "2024-01-01",
-                "--universe",
-                "AAPL,MSFT",
-                "--api-key",
-                "fk_test",
-            ],
-        )
-        assert result.exit_code == 0, result.output
-        stdout = _strip_ansi(result.output)
-        assert "Universe: AAPL, MSFT" in stdout
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_create_json_mode(self, mock_call: MagicMock) -> None:
-        """``--json`` prints the raw envelope verbatim."""
-        envelope = {"id": "sid-json", "name": "JSON", "config": {"start_time": "x", "initial_capital": 1.0}}
-        mock_call.return_value = envelope
-        result = runner.invoke(
-            app,
-            ["session", "create", "--name", "JSON", "--start", "2024-01-01", "--json", "--api-key", "fk_test"],
-        )
-        assert result.exit_code == 0, result.output
-        # Output must be the JSON envelope, not the human-readable form.
-        import json as _json
-
-        assert _json.loads(result.stdout) == envelope
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_create_blind_flag_forwarded_to_mcp_tool(
-        self, mock_call: MagicMock
-    ) -> None:
-        """v12 Team E smoke: ``--blind`` flips ``blind=True`` in the MCP tool args.
-
-        Companion to ``test_session_create_blind_cli_does_not_echo_real_tickers``
-        (which asserts the rendered output) — this test pins the wire shape:
-        the CLI dispatches via ``call_tool_sync('create_session', args)`` and
-        the ``args`` dict must carry ``blind: True`` (per Team D's CLI patch).
-
-        Without this assertion, a future regression that drops the
-        ``--blind`` flag from the Typer signature would still pass the
-        rendered-output test (the CLI's render path is independent of the
-        MCP-call path) — this gate catches that loophole.
-        """
-        mock_call.return_value = {
-            "id": "sid-smoke",
-            "name": "blind-sid-smok",
-            "config": {
-                "start_time": "Day_1",
-                "initial_capital": 100_000.0,
-                "universe": ["T_0001"],
-                "blind": True,
-            },
-        }
-        result = runner.invoke(
-            app,
-            [
-                "session",
-                "create",
-                "--name",
-                "ignored",
-                "--start",
-                "2024-01-01",
-                "--universe",
-                "AAPL",
-                "--blind",
-                "--api-key",
-                "fk_test",
-            ],
-        )
-        assert result.exit_code == 0, result.output
-        tool_args = mock_call.call_args.args[1]
-        # The MCP tool must see ``blind=True`` in its kwargs dict.
-        assert tool_args.get("blind") is True, (
-            f"CLI --blind flag was NOT forwarded to MCP tool args: {tool_args!r}"
-        )
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_create_no_blind_flag_defaults_to_false(
-        self, mock_call: MagicMock
-    ) -> None:
-        """v12 Team E smoke: omitting ``--blind`` defaults the tool arg to False.
-
-        Regression: a CLI default flip would silently start every session
-        in blind mode without anyone noticing — this gate pins the
-        opt-in semantics.
-        """
-        mock_call.return_value = {
-            "id": "sid-noblind",
-            "name": "no-blind",
-            "config": {
-                "start_time": "2024-01-01T00:00:00+00:00",
-                "initial_capital": 100_000.0,
-                "universe": ["AAPL"],
-            },
-        }
-        result = runner.invoke(
-            app,
-            [
-                "session",
-                "create",
-                "--name",
-                "no-blind",
-                "--start",
-                "2024-01-01",
-                "--universe",
-                "AAPL",
-                "--api-key",
-                "fk_test",
-            ],
-        )
-        assert result.exit_code == 0, result.output
-        tool_args = mock_call.call_args.args[1]
-        # When --blind is NOT passed, the MCP tool arg must be False.
-        # (Either explicit False, or absent — the MCP tool defaults to False.)
-        assert tool_args.get("blind", False) is False, (
-            f"CLI defaulted --blind to True: tool_args={tool_args!r}"
-        )
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_list_renders_human_output(self, mock_call: MagicMock) -> None:
-        """``session list`` formats sessions from the tool envelope."""
-        mock_call.return_value = {
-            "sessions": [
-                {
-                    "id": "sid-1",
-                    "name": "Alpha",
-                    "status": "ACTIVE",
-                    "clock": {"current_time": "2024-01-15T00:00:00+00:00"},
-                },
-            ],
-            "count": 1,
-        }
-        result = runner.invoke(app, ["session", "list", "--api-key", "fk_test"])
-        assert result.exit_code == 0, result.output
-        assert "sid-1" in result.output
-        assert "Alpha" in result.output
-        assert "ACTIVE" in result.output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_list_empty(self, mock_call: MagicMock) -> None:
-        """Empty sessions list prints the no-active-sessions message."""
-        mock_call.return_value = {"sessions": [], "count": 0}
-        result = runner.invoke(app, ["session", "list", "--api-key", "fk_test"])
-        assert result.exit_code == 0, result.output
-        assert "No active sessions" in result.output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_list_error_envelope_exits(self, mock_call: MagicMock) -> None:
-        """Auth-required envelopes exit ``EXIT_AUTH_REQUIRED`` (2) with the hint.
-
-        Pre-v1.0.4 this asserted exit 1.  v1.0.4 promoted auth-failure
-        envelopes to exit 2 so shell scripts can detect "not
-        authenticated" distinctly from other tool failures (F-3 hotfix
-        per ``docs/launch/blind-agent-coldstart-report-v1.0.3-fullwalk.md``).
-        """
-        mock_call.return_value = {"error": "Authentication required. Provide an api_key ..."}
-        result = runner.invoke(app, ["session", "list"])
-        assert result.exit_code == 2
-        assert "Authentication required" in result.output
-        # The friendly hint should appear alongside the raw error.
-        assert "finlet auth login" in result.output
-        assert "FINLET_API_KEY" in result.output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_list_api_key_sunset_envelope_exits_auth(self, mock_call: MagicMock) -> None:
-        """The Phase-4e api_key-sunset envelope also exits ``EXIT_AUTH_REQUIRED``.
-
-        This is the form the cloud MCP HTTP surface emits when an
-        api_key Bearer was sent — see F-1 in the v1.0.3 blind walk.
-        """
-        mock_call.return_value = {
-            "error": (
-                "api_key authentication is no longer supported on MCP tools. "
-                "Run 'finlet auth login' to obtain an OAuth Bearer token."
-            )
-        }
-        result = runner.invoke(app, ["session", "list"])
-        assert result.exit_code == 2
-        assert "no longer supported" in result.output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_delete_dispatches_delete_session_tool(self, mock_call: MagicMock) -> None:
-        """``session delete <sid>`` calls ``delete_session`` with session_id."""
-        mock_call.return_value = {"status": "deleted", "id": "sid-target"}
-        result = runner.invoke(
-            app,
-            ["session", "delete", "sid-target", "--api-key", "fk_test"],
-        )
-        assert result.exit_code == 0, result.output
-        tool_name, tool_args = mock_call.call_args.args[0], mock_call.call_args.args[1]
-        assert tool_name == "delete_session"
-        assert tool_args == {"session_id": "sid-target"}
-        assert "sid-target" in result.output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_publish_dispatches_set_session_visibility_tool(
-        self, mock_call: MagicMock
-    ) -> None:
-        """``session publish <sid>`` calls ``set_session_visibility`` with public=True, anonymous=True."""
-        mock_call.return_value = {
-            "id": "sid-pub",
-            "name": "Demo",
-            "public": True,
-            "public_anonymous": True,
-            "config": {},
-        }
-        result = runner.invoke(
-            app,
-            ["session", "publish", "sid-pub", "--api-key", "fk_test"],
-        )
-        assert result.exit_code == 0, result.output
-        tool_name, tool_args = mock_call.call_args.args[0], mock_call.call_args.args[1]
-        assert tool_name == "set_session_visibility"
-        assert tool_args["session_id"] == "sid-pub"
-        assert tool_args["public"] is True
-        assert tool_args["anonymous"] is True
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_publish_attributed_flag(self, mock_call: MagicMock) -> None:
-        """``--attributed`` flips the anonymous flag to False."""
-        mock_call.return_value = {
-            "id": "sid-attr",
-            "name": "Demo",
-            "public": True,
-            "public_anonymous": False,
-            "config": {},
-        }
-        result = runner.invoke(
-            app,
-            ["session", "publish", "sid-attr", "--attributed", "--api-key", "fk_test"],
-        )
-        assert result.exit_code == 0, result.output
-        tool_args = mock_call.call_args.args[1]
-        assert tool_args["anonymous"] is False
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_publish_unpublish_flag(self, mock_call: MagicMock) -> None:
-        """``--unpublish`` sends ``public=False`` and prints the unpublish confirmation."""
-        mock_call.return_value = {
-            "id": "sid-unp",
-            "name": "Demo",
-            "public": False,
-            "public_anonymous": True,
-            "config": {},
-        }
-        result = runner.invoke(
-            app,
-            ["session", "publish", "sid-unp", "--unpublish", "--api-key", "fk_test"],
-        )
-        assert result.exit_code == 0, result.output
-        tool_args = mock_call.call_args.args[1]
-        assert tool_args["public"] is False
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_session_publish_json_mode(self, mock_call: MagicMock) -> None:
-        """``--json`` prints the raw envelope verbatim."""
-        envelope = {
-            "id": "sid-json",
-            "name": "JSON",
-            "public": True,
-            "public_anonymous": True,
-            "config": {},
-        }
-        mock_call.return_value = envelope
-        result = runner.invoke(
-            app,
-            ["session", "publish", "sid-json", "--json", "--api-key", "fk_test"],
-        )
-        assert result.exit_code == 0, result.output
-        import json as _json
-
-        assert _json.loads(result.stdout) == envelope
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_dispatch_failure_exits(self, mock_call: MagicMock) -> None:
-        """An HTTP-transport dispatch failure surfaces as exit 1 with an actionable message."""
-        mock_call.side_effect = MCPDispatchError(
-            "Cannot connect to Finlet MCP at https://finlet.dev/mcp: refused"
-        )
-        result = runner.invoke(app, ["session", "list", "--api-key", "fk_test"])
-        assert result.exit_code == 1
-        assert "MCP dispatch failed" in result.output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_dispatch_timeout_friendly_error(self, mock_call: MagicMock) -> None:
-        """Timeout from MCP dispatch surfaces as a one-line friendly message, not a traceback.
-
-        BLOCKER #5 (launch-blockers handoff): the agent-guide first-command
-        with a 3-ticker universe was hitting the 120s timeout and emitting
-        a raw asyncio.TimeoutError traceback. This test asserts the catch
-        site in `_dispatch_mcp_tool` converts the timeout into:
-          - exit code 1
-          - a one-line "Error: '<tool>' timed out..." message
-          - NO Python traceback in stdout/stderr
-        """
-
-        mock_call.side_effect = TimeoutError()
-        result = runner.invoke(
-            app,
-            [
-                "session",
-                "create",
-                "--name",
-                "first-session",
-                "--start",
-                "2024-01-01",
-                "--capital",
-                "100000",
-                "--universe",
-                "AAPL,GOOGL,MSFT",
-                "--api-key",
-                "fk_test",
-            ],
-        )
-        assert result.exit_code == 1
-        # Friendly message, not a traceback
-        assert "timed out after" in result.output
-        assert "create_session" in result.output or "Try a smaller universe" in result.output
-        # Negative: should NOT include a Python traceback marker
-        assert "Traceback" not in result.output
-        assert "asyncio.TimeoutError" not in result.output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_dispatch_builtin_timeout_also_caught(self, mock_call: MagicMock) -> None:
-        """Builtin TimeoutError (Python 3.11+ alias) is also caught by the dispatch envelope."""
-        mock_call.side_effect = TimeoutError()
-        result = runner.invoke(app, ["session", "list", "--api-key", "fk_test"])
-        assert result.exit_code == 1
-        assert "timed out after" in result.output
-        assert "Traceback" not in result.output
-
-
-class TestBenchmarkVisibilityCommandsViaMCP:
-    """``finlet benchmark visibility`` + ``finlet benchmark decrypt`` (Team D)."""
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_benchmark_decrypt_dispatches_decrypt_tool(
-        self, mock_call: MagicMock
-    ) -> None:
-        mock_call.return_value = {
-            "run_id": "run-xyz",
-            "decrypted_at": "2026-05-20T12:00:00+00:00",
-        }
-        result = runner.invoke(
-            app, ["benchmark", "decrypt", "run-xyz", "--api-key", "fk_test"]
-        )
-        assert result.exit_code == 0, result.output
-        tool_name, tool_args = (
-            mock_call.call_args.args[0],
-            mock_call.call_args.args[1],
-        )
-        assert tool_name == "decrypt_benchmark_run"
-        assert tool_args == {"benchmark_run_id": "run-xyz"}
-        assert "Decrypted" in result.output
-        assert "run-xyz" in result.output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_benchmark_visibility_publish_default_anonymous(
-        self, mock_call: MagicMock
-    ) -> None:
-        mock_call.return_value = {
-            "run_id": "run-pub",
-            "published": True,
-            "published_anonymous": True,
-            "published_at": "2026-05-20T12:01:00+00:00",
-        }
-        result = runner.invoke(
-            app,
-            ["benchmark", "visibility", "run-pub", "--api-key", "fk_test"],
-        )
-        assert result.exit_code == 0, result.output
-        tool_name, tool_args = (
-            mock_call.call_args.args[0],
-            mock_call.call_args.args[1],
-        )
-        assert tool_name == "set_benchmark_visibility"
-        assert tool_args["benchmark_run_id"] == "run-pub"
-        assert tool_args["public"] is True
-        assert tool_args["anonymous"] is True
-        assert "Published" in result.output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_benchmark_visibility_attributed_flag(
-        self, mock_call: MagicMock
-    ) -> None:
-        """``--attributed`` flips the anonymous flag to False."""
-        mock_call.return_value = {
-            "run_id": "run-attr",
-            "published": True,
-            "published_anonymous": False,
-        }
-        result = runner.invoke(
-            app,
-            [
-                "benchmark",
-                "visibility",
-                "run-attr",
-                "--attributed",
-                "--api-key",
-                "fk_test",
-            ],
-        )
-        assert result.exit_code == 0, result.output
-        tool_args = mock_call.call_args.args[1]
-        assert tool_args["anonymous"] is False
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_benchmark_visibility_unpublish_flag(
-        self, mock_call: MagicMock
-    ) -> None:
-        """``--unpublish`` sends ``public=False`` and prints the unpublish confirmation."""
-        mock_call.return_value = {
-            "run_id": "run-unp",
-            "published": False,
-            "published_anonymous": True,
-        }
-        result = runner.invoke(
-            app,
-            [
-                "benchmark",
-                "visibility",
-                "run-unp",
-                "--unpublish",
-                "--api-key",
-                "fk_test",
-            ],
-        )
-        assert result.exit_code == 0, result.output
-        tool_args = mock_call.call_args.args[1]
-        assert tool_args["public"] is False
-        assert "Unpublished" in result.output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_benchmark_visibility_json_mode_emits_envelope(
-        self, mock_call: MagicMock
-    ) -> None:
-        envelope = {
-            "run_id": "run-json",
-            "published": True,
-            "published_anonymous": True,
-        }
-        mock_call.return_value = envelope
-        result = runner.invoke(
-            app,
-            [
-                "benchmark",
-                "visibility",
-                "run-json",
-                "--json",
-                "--api-key",
-                "fk_test",
-            ],
-        )
-        assert result.exit_code == 0, result.output
-        import json as _json
-
-        assert _json.loads(result.stdout) == envelope
-
-
-class TestAdvanceCommandViaMCP:
-    """``finlet advance`` dispatches through MCP ``advance_time``."""
-
-    def test_advance_help_carries_session_flag(self):
-        """Advance command shows --session and --api-key flags."""
-        result = runner.invoke(app, ["advance", "--help"])
-        assert result.exit_code == 0
-        output = _strip_ansi(result.output)
-        assert "--session" in output
-        assert "--api-key" in output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_advance_default_one_step(self, mock_call: MagicMock) -> None:
-        """No flag → tool dispatch with interval=1d, steps=1 (default)."""
-        mock_call.return_value = {
-            "current_time": "2024-01-02T00:00:00+00:00",
-            "mode": "STEPPING",
-            "fill_summary": {"prices_updated": 0, "orders_filled": 0},
-        }
-        result = runner.invoke(app, ["advance", "--session", "sid-123", "--api-key", "fk_test"])
-        assert result.exit_code == 0, result.output
-        tool_name, tool_args = mock_call.call_args.args[0], mock_call.call_args.args[1]
-        assert tool_name == "advance_time"
-        assert tool_args["session_id"] == "sid-123"
-        assert tool_args["interval"] == "1d"
-        assert "steps" not in tool_args  # default single-step
-        assert "target_date" not in tool_args
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_advance_days_passes_steps(self, mock_call: MagicMock) -> None:
-        """``--days N`` → tool dispatch with steps=N."""
-        mock_call.return_value = {
-            "current_time": "2024-01-31T00:00:00+00:00",
-            "mode": "STEPPING",
-            "steps_advanced": 30,
-        }
-        result = runner.invoke(
-            app,
-            ["advance", "--session", "sid-123", "--days", "30", "--api-key", "fk_test"],
-        )
-        assert result.exit_code == 0, result.output
-        tool_args = mock_call.call_args.args[1]
-        assert tool_args["steps"] == 30
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_advance_to_passes_target_date(self, mock_call: MagicMock) -> None:
-        """``--to YYYY-MM-DD`` → tool dispatch with target_date=YYYY-MM-DD."""
-        mock_call.return_value = {
-            "current_time": "2025-01-01T00:00:00+00:00",
-            "mode": "STEPPING",
-            "fill_summary": {"prices_updated": 0, "orders_filled": 0},
-        }
-        result = runner.invoke(
-            app,
-            ["advance", "--session", "sid-123", "--to", "2025-01-01", "--api-key", "fk_test"],
-        )
-        assert result.exit_code == 0, result.output
-        tool_args = mock_call.call_args.args[1]
-        assert tool_args["target_date"] == "2025-01-01"
-
-    def test_advance_days_and_to_mutually_exclusive(self):
-        """Providing both --days and --to should fail."""
-        result = runner.invoke(
-            app,
-            [
-                "advance",
-                "--session",
-                "sid-123",
-                "--days",
-                "5",
-                "--to",
-                "2025-01-01",
-                "--api-key",
-                "fk_test",
-            ],
-        )
-        assert result.exit_code != 0
-        assert "mutually exclusive" in result.output
-
-    def test_advance_to_invalid_format(self):
-        """--to with a non-YYYY-MM-DD string should fail."""
-        result = runner.invoke(
-            app,
-            ["advance", "--session", "sid-123", "--to", "not-a-date", "--api-key", "fk_test"],
-        )
-        assert result.exit_code != 0
-        assert "YYYY-MM-DD" in result.output
-
-    def test_advance_requires_session(self):
-        """Advance should fail without --session."""
-        result = runner.invoke(app, ["advance"])
-        assert result.exit_code != 0
-
-
-class TestOrderCommandViaMCP:
-    """``finlet order`` dispatches through MCP ``submit_order``."""
-
-    def test_order_help(self):
-        result = runner.invoke(app, ["order", "--help"])
-        assert result.exit_code == 0
-        output = _strip_ansi(result.output)
-        for flag in (
-            "--session",
-            "--ticker",
-            "--side",
-            "--quantity",
-            "--type",
-            "--limit-price",
-            "--stop-price",
-            "--time-in-force",
-            "--reasoning",
-            "--api-key",
-        ):
-            assert flag in output, f"expected {flag!r} in --help"
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_order_market_buy_dispatches_submit_order(self, mock_call: MagicMock) -> None:
-        """MARKET BUY → tool dispatch with the canonical args."""
-        mock_call.return_value = {
-            "id": "order-abc",
-            "status": "FILLED",
-            "fill_price": 150.25,
-        }
-        result = runner.invoke(
-            app,
-            [
-                "order",
-                "--session",
-                "sid-123",
-                "--ticker",
-                "AAPL",
-                "--side",
-                "BUY",
-                "--quantity",
-                "10",
-                "--api-key",
-                "fk_test",
-            ],
-        )
-        assert result.exit_code == 0, result.output
-        tool_name, tool_args = mock_call.call_args.args[0], mock_call.call_args.args[1]
-        assert tool_name == "submit_order"
-        assert tool_args["session_id"] == "sid-123"
-        assert tool_args["ticker"] == "AAPL"
-        assert tool_args["side"] == "BUY"
-        assert tool_args["quantity"] == 10
-        assert tool_args["order_type"] == "MARKET"
-        assert "limit_price" not in tool_args
-        assert "stop_price" not in tool_args
-        assert "150.25" in result.output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_order_limit_passes_limit_price(self, mock_call: MagicMock) -> None:
-        """LIMIT → limit_price is forwarded; stop_price omitted."""
-        mock_call.return_value = {"id": "order-def", "status": "PENDING"}
-        result = runner.invoke(
-            app,
-            [
-                "order",
-                "--session",
-                "sid-123",
-                "--ticker",
-                "TSLA",
-                "--side",
-                "SELL",
-                "--quantity",
-                "5",
-                "--type",
-                "LIMIT",
-                "--limit-price",
-                "200.00",
-                "--api-key",
-                "fk_test",
-            ],
-        )
-        assert result.exit_code == 0, result.output
-        tool_args = mock_call.call_args.args[1]
-        assert tool_args["order_type"] == "LIMIT"
-        assert tool_args["limit_price"] == 200.0
-        assert "stop_price" not in tool_args
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_order_with_reasoning_forwards_field(self, mock_call: MagicMock) -> None:
-        mock_call.return_value = {"id": "order-r", "status": "FILLED", "fill_price": 50.0}
-        result = runner.invoke(
-            app,
-            [
-                "order",
-                "--session",
-                "sid-123",
-                "--ticker",
-                "MSFT",
-                "--side",
-                "BUY",
-                "--quantity",
-                "20",
-                "--reasoning",
-                "Strong earnings expected",
-                "--api-key",
-                "fk_test",
-            ],
-        )
-        assert result.exit_code == 0, result.output
-        tool_args = mock_call.call_args.args[1]
-        assert tool_args["reasoning"] == "Strong earnings expected"
-
-    def test_order_limit_requires_price_client_side(self):
-        """LIMIT without --limit-price fails with BadParameter before any subprocess spawn (H12)."""
-        with patch("finlet.cli.call_tool_sync") as mock_call:
-            result = runner.invoke(
-                app,
-                [
-                    "order",
-                    "--session",
-                    "sid-x",
-                    "--ticker",
-                    "AAPL",
-                    "--side",
-                    "BUY",
-                    "--quantity",
-                    "1",
-                    "--type",
-                    "LIMIT",
-                    "--api-key",
-                    "fk_test",
-                ],
-            )
-            mock_call.assert_not_called()
-        assert result.exit_code != 0
-        assert "limit-price" in _strip_ansi(result.output).lower()
-
-    def test_order_stop_requires_price_client_side(self):
-        """STOP without --stop-price fails with BadParameter before any subprocess spawn (H12)."""
-        with patch("finlet.cli.call_tool_sync") as mock_call:
-            result = runner.invoke(
-                app,
-                [
-                    "order",
-                    "--session",
-                    "sid-x",
-                    "--ticker",
-                    "AAPL",
-                    "--side",
-                    "SELL",
-                    "--quantity",
-                    "1",
-                    "--type",
-                    "STOP",
-                    "--api-key",
-                    "fk_test",
-                ],
-            )
-            mock_call.assert_not_called()
-        assert result.exit_code != 0
-        assert "stop-price" in _strip_ansi(result.output).lower()
-
-    def test_order_market_with_limit_price_rejected(self):
-        """MARKET orders must not carry --limit-price (H12)."""
-        with patch("finlet.cli.call_tool_sync") as mock_call:
-            result = runner.invoke(
-                app,
-                [
-                    "order",
-                    "--session",
-                    "sid-x",
-                    "--ticker",
-                    "AAPL",
-                    "--side",
-                    "BUY",
-                    "--quantity",
-                    "1",
-                    "--type",
-                    "MARKET",
-                    "--limit-price",
-                    "150.00",
-                    "--api-key",
-                    "fk_test",
-                ],
-            )
-            mock_call.assert_not_called()
-        assert result.exit_code != 0
-
-
-class TestPortfolioCommandViaMCP:
-    """``finlet portfolio`` dispatches through MCP ``get_portfolio``."""
-
-    def test_portfolio_help(self):
-        result = runner.invoke(app, ["portfolio", "--help"])
-        assert result.exit_code == 0
-        assert "--session" in _strip_ansi(result.output)
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_portfolio_with_positions_plain_text(self, mock_call: MagicMock) -> None:
-        mock_call.return_value = {
-            "positions": {
-                "AAPL": {
-                    "ticker": "AAPL",
-                    "quantity": 10.0,
-                    "avg_entry_price": 150.0,
-                    "current_price": 155.0,
-                    "market_value": 1550.0,
-                    "unrealized_pnl": 50.0,
-                },
-            },
-            "cash": 98_450.0,
-            "total_value": 100_000.0,
-            "unrealized_pnl": 50.0,
-            "metrics": {"total_orders": 1, "filled_orders": 1},
-        }
-
-        # Force plain-text fallback path so we don't depend on rich's exact
-        # output. Patch the rich imports to ImportError.
-        import builtins
-
-        real_import = builtins.__import__
-
-        def mock_import(name: str, *args: Any, **kwargs: Any) -> Any:
-            if name in ("rich.console", "rich.table"):
-                raise ImportError("no rich")
-            return real_import(name, *args, **kwargs)
-
-        with patch("builtins.__import__", side_effect=mock_import):
-            result = runner.invoke(app, ["portfolio", "--session", "sid-123", "--api-key", "fk_test"])
-        assert result.exit_code == 0, result.output
-        assert "AAPL" in result.output
-        assert "98,450.00" in result.output
-        # Verify the tool dispatch arguments.
-        tool_name, tool_args = mock_call.call_args.args[0], mock_call.call_args.args[1]
-        assert tool_name == "get_portfolio"
-        assert tool_args == {"session_id": "sid-123"}
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_portfolio_empty_positions(self, mock_call: MagicMock) -> None:
-        mock_call.return_value = {
-            "positions": {},
-            "cash": 100_000.0,
-            "total_value": 100_000.0,
-            "unrealized_pnl": 0.0,
-            "metrics": {},
-        }
-        import builtins
-
-        real_import = builtins.__import__
-
-        def mock_import(name: str, *args: Any, **kwargs: Any) -> Any:
-            if name in ("rich.console", "rich.table"):
-                raise ImportError("no rich")
-            return real_import(name, *args, **kwargs)
-
-        with patch("builtins.__import__", side_effect=mock_import):
-            result = runner.invoke(app, ["portfolio", "--session", "sid-123", "--api-key", "fk_test"])
-        assert result.exit_code == 0, result.output
-        assert "No positions" in result.output
-        assert "100,000.00" in result.output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_portfolio_error_envelope_exits(self, mock_call: MagicMock) -> None:
-        mock_call.return_value = {"error": "Session 'bad-id' not found."}
-        result = runner.invoke(app, ["portfolio", "--session", "bad-id", "--api-key", "fk_test"])
-        assert result.exit_code == 1
-        assert "not found" in result.output
-
-    def test_portfolio_requires_session(self):
-        result = runner.invoke(app, ["portfolio"])
-        assert result.exit_code != 0
-
-
-class TestStatusCommandViaMCP:
-    """``finlet status`` dispatches through MCP ``get_session``."""
-
-    def test_status_help(self):
-        result = runner.invoke(app, ["status", "--help"])
-        assert result.exit_code == 0
-        assert "--session" in _strip_ansi(result.output)
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_status_renders_human_output(self, mock_call: MagicMock) -> None:
-        mock_call.return_value = {
-            "id": "sid-123",
-            "name": "Test Session",
-            "status": "ACTIVE",
-            "clock": {"current_time": "2024-01-15T00:00:00+00:00", "mode": "STEPPING"},
-            "config": {
-                "universe": ["AAPL", "MSFT", "GOOGL"],
-                "initial_capital": 100_000.0,
-            },
-        }
-        result = runner.invoke(app, ["status", "--session", "sid-123", "--api-key", "fk_test"])
-        assert result.exit_code == 0, result.output
-        tool_name, tool_args = mock_call.call_args.args[0], mock_call.call_args.args[1]
-        assert tool_name == "get_session"
-        assert tool_args == {"session_id": "sid-123"}
-        assert "Test Session" in result.output
-        assert "sid-123" in result.output
-        assert "ACTIVE" in result.output
-        assert "AAPL" in result.output
-        assert "100,000.00" in result.output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_status_empty_universe_omits_line(self, mock_call: MagicMock) -> None:
-        mock_call.return_value = {
-            "id": "sid-456",
-            "name": "Empty Session",
-            "status": "ACTIVE",
-            "clock": {"current_time": "2024-01-01T00:00:00+00:00", "mode": "FROZEN"},
-            "config": {"universe": [], "initial_capital": 50_000.0},
-        }
-        result = runner.invoke(app, ["status", "--session", "sid-456", "--api-key", "fk_test"])
-        assert result.exit_code == 0, result.output
-        assert "Empty Session" in result.output
-        assert "Universe:" not in result.output
-
-    @patch("finlet.cli.call_tool_sync")
-    def test_status_error_envelope_exits(self, mock_call: MagicMock) -> None:
-        mock_call.return_value = {"error": "Session 'bad-id' not found."}
-        result = runner.invoke(app, ["status", "--session", "bad-id", "--api-key", "fk_test"])
-        assert result.exit_code == 1
-        assert "not found" in result.output
-
-
-# ─── KEEP commands (REST via httpx, unchanged) ───────────────────────
+# ─── register ────────────────────────────────────────────────────────
 
 
 class TestRegisterCommand:
@@ -1166,6 +101,9 @@ class TestRegisterCommand:
         assert result.exit_code != 0
 
 
+# ─── auth login ─────────────────────────────────────────────────────
+
+
 class TestAuthLoginCommand:
     def test_auth_login_help(self):
         """``finlet auth login --help`` exposes --email/-e and --password/-p."""
@@ -1299,6 +237,9 @@ class TestAuthLoginCommand:
         assert "Cannot connect" in result.output
 
 
+# ─── auth status ────────────────────────────────────────────────────
+
+
 class TestAuthStatusCommand:
     """``finlet auth status`` reads ``~/.finlet/credentials`` and reports state.
 
@@ -1410,6 +351,9 @@ class TestAuthStatusCommand:
         assert "Token expired" in result.output
 
 
+# ─── _print_error envelope precedence ───────────────────────────────
+
+
 class TestPrintErrorEnvelope:
     """Tests for the H7 fix: ``_print_error`` prefers structured ``error.message`` over legacy ``detail``."""
 
@@ -1463,6 +407,9 @@ class TestPrintErrorEnvelope:
         assert "raw-server-error-text" in result.output
 
 
+# ─── plugins list/add/remove ─────────────────────────────────────────
+
+
 class TestPluginsListCommand:
     """``finlet plugins list`` continues to call REST (not MCP-migrated).
 
@@ -1708,14 +655,44 @@ class TestPluginsRemoveCommand:
 
 
 class TestTopLevelCommands:
+    """v2.0.0 pure-MCP CLI surface: 6 commands only.
+
+    All agentic-trading commands (``session``, ``advance``, ``order``,
+    ``portfolio``, ``status``, ``benchmark``) were removed in the v2.0.0
+    cutover. Agents now drive Finlet through the MCP surface directly.
+    """
+
     def test_all_commands_registered(self):
         """Verify all expected top-level commands appear in --help."""
         result = runner.invoke(app, ["--help"])
         assert result.exit_code == 0
         output = _strip_ansi(result.output)
-        for cmd in ("register", "advance", "order", "portfolio", "status", "session", "plugins", "auth", "mcp"):
+        for cmd in ("serve", "register", "manual", "plugins", "auth", "mcp"):
             assert cmd in output, f"Command '{cmd}' not found in --help output"
 
+    def test_dropped_agentic_commands_not_registered(self):
+        """The v2.0.0 cutover removed agentic CLI commands — verify they're absent.
+
+        Agents now invoke the MCP tools directly (``mcp__finlet__*`` namespace);
+        the CLI no longer ships a parallel surface. Listed verbatim from
+        Team A's deletion list so future regressions on a partial re-add
+        surface here.
+        """
+        result = runner.invoke(app, ["--help"])
+        assert result.exit_code == 0
+        output = _strip_ansi(result.output)
+        # session create/list/delete/publish, advance, order, portfolio,
+        # status, benchmark — these are top-level command names; the
+        # `--help` output renders them as standalone tokens in the
+        # Commands panel. The substring check is intentionally narrow
+        # (whitespace-bounded) so we don't false-match on copy in a
+        # description column.
+        for dropped in (" advance ", " order ", " portfolio ", " status ", " benchmark ", " session "):
+            assert dropped not in output, (
+                f"Dropped agentic command {dropped.strip()!r} still appears "
+                f"in --help (v2.0.0 cutover regression)"
+            )
+
     def test_mcp_serve_subcommand_registered(self):
         """``finlet mcp serve`` is the new entry point (renamed from ``finlet mcp``)."""
         result = runner.invoke(app, ["mcp", "--help"])
@@ -1741,352 +718,6 @@ class TestTopLevelCommands:
         assert "finlet mcp" in output or "Missing command" in output or "command" in output.lower()
 
 
-# ─── _translate_mcp_error helper ────────────────────────────────────
-
-
-class TestTranslateMcpError:
-    """Direct unit tests for the human-readable error translator."""
-
-    def test_string_error(self):
-        from finlet.cli import _translate_mcp_error
-
-        assert _translate_mcp_error({"error": "boom"}) == "boom"
-
-    def test_no_error(self):
-        from finlet.cli import _translate_mcp_error
-
-        assert _translate_mcp_error({"id": "sid", "name": "Alpha"}) is None
-
-    def test_dict_error_with_message(self):
-        from finlet.cli import _translate_mcp_error
-
-        envelope = {"error": {"code": "unauth", "message": "human-readable"}}
-        assert _translate_mcp_error(envelope) == "human-readable"
-
-    def test_dict_error_no_message(self):
-        from finlet.cli import _translate_mcp_error
-
-        envelope = {"error": {"code": "unknown"}}
-        # Falls back to str(dict).
-        result = _translate_mcp_error(envelope)
-        assert result is not None
-        assert "code" in result
-
-
-# ─── _resolve_bearer_token helper ───────────────────────────────────
-
-
-class TestResolveBearerToken:
-    """Unit tests for the credential precedence helper."""
-
-    def test_explicit_api_key_wins(self):
-        from finlet.cli import _resolve_bearer_token
-
-        assert _resolve_bearer_token("fk_explicit") == "fk_explicit"
-
-    def test_returns_none_when_no_credentials(self, monkeypatch, tmp_path):
-        from finlet.cli import _resolve_bearer_token
-
-        monkeypatch.setenv("HOME", str(tmp_path))
-        monkeypatch.delenv("USERPROFILE", raising=False)
-        # No api_key, no creds file.
-        assert _resolve_bearer_token(None) is None
-
-    def test_loads_credentials_file(self, monkeypatch, tmp_path):
-        import json as _json
-        import os as _os
-        import sys as _sys
-        import time as _time
-
-        from finlet.cli import _resolve_bearer_token
-
-        monkeypatch.setenv("HOME", str(tmp_path))
-        monkeypatch.delenv("USERPROFILE", raising=False)
-        creds_dir = tmp_path / ".finlet"
-        creds_dir.mkdir()
-        creds_path = creds_dir / "credentials"
-        # ``expires_at`` set 10 minutes in the future so the auto-refresh
-        # branch in ``_resolve_bearer_token`` does not fire — this test
-        # only validates that the stored access token is returned
-        # verbatim when present and non-expired.
-        future_expiry = int(_time.time()) + 600
-        with open(creds_path, "w") as f:
-            _json.dump(
-                {
-                    "access_token": "jwt-payload",
-                    "refresh_token": "rt",
-                    "expires_at": future_expiry,
-                },
-                f,
-            )
-        if _sys.platform != "win32":
-            _os.chmod(creds_path, 0o600)
-        assert _resolve_bearer_token(None) == "jwt-payload"
-
-    # ─── auto-refresh contract ──────────────────────────────────────
-
-    def test_resolve_bearer_token_not_expired_returns_existing(
-        self, monkeypatch, tmp_path
-    ):
-        """Non-expired stored token is returned as-is; no HTTP call is made.
-
-        The 30-second safety margin still leaves a 10-minute future
-        ``expires_at`` comfortably in the "no refresh" branch.
-        """
-        import json as _json
-        import os as _os
-        import sys as _sys
-        import time as _time
-
-        from finlet.cli import _resolve_bearer_token
-
-        monkeypatch.setenv("HOME", str(tmp_path))
-        monkeypatch.delenv("USERPROFILE", raising=False)
-        creds_dir = tmp_path / ".finlet"
-        creds_dir.mkdir()
-        creds_path = creds_dir / "credentials"
-        future_expiry = int(_time.time()) + 600  # 10 min in the future
-        with open(creds_path, "w") as f:
-            _json.dump(
-                {
-                    "access_token": "jwt-fresh",
-                    "refresh_token": "rt-fresh",
-                    "expires_at": future_expiry,
-                },
-                f,
-            )
-        if _sys.platform != "win32":
-            _os.chmod(creds_path, 0o600)
-
-        # Patch ``httpx.Client`` so any unexpected HTTP call surfaces
-        # loudly as a test failure rather than going out to the network.
-        client_factory = MagicMock(side_effect=AssertionError("unexpected HTTP call"))
-        with patch("httpx.Client", client_factory):
-            token = _resolve_bearer_token(None)
-
-        assert token == "jwt-fresh"
-        client_factory.assert_not_called()
-
-    def test_resolve_bearer_token_expired_refreshes_and_writes(
-        self, monkeypatch, tmp_path
-    ):
-        """Expired token triggers POST /oauth/token; rotated creds persist."""
-        import json as _json
-        import os as _os
-        import sys as _sys
-        import time as _time
-
-        from finlet.cli import _resolve_bearer_token
-
-        monkeypatch.setenv("HOME", str(tmp_path))
-        monkeypatch.delenv("USERPROFILE", raising=False)
-        creds_dir = tmp_path / ".finlet"
-        creds_dir.mkdir()
-        creds_path = creds_dir / "credentials"
-        past_expiry = int(_time.time()) - 60  # 1 min in the past
-        with open(creds_path, "w") as f:
-            _json.dump(
-                {
-                    "access_token": "jwt-old",
-                    "refresh_token": "rt-old",
-                    "expires_at": past_expiry,
-                },
-                f,
-            )
-        if _sys.platform != "win32":
-            _os.chmod(creds_path, 0o600)
-
-        # Mock httpx.Client as a context manager whose .post returns a
-        # 200 with rotated tokens.
-        refresh_response = _mock_response(
-            200,
-            {
-                "access_token": "jwt-new",
-                "refresh_token": "rt-new",
-                "expires_in": 900,
-                "token_type": "Bearer",
-                "scope": "finlet:read finlet:trade finlet:benchmark",
-            },
-        )
-        mock_client = MagicMock()
-        mock_client.__enter__.return_value = mock_client
-        mock_client.__exit__.return_value = False
-        mock_client.post.return_value = refresh_response
-
-        with patch("httpx.Client", return_value=mock_client) as client_factory:
-            token = _resolve_bearer_token(None)
-
-        assert token == "jwt-new"
-        client_factory.assert_called_once()
-        mock_client.post.assert_called_once()
-        # The refresh-token grant payload must include the refresh_token,
-        # client_id and resource indicator per RFC 6749 §6 + RFC 8707.
-        _, kwargs = mock_client.post.call_args
-        data = kwargs.get("data") or {}
-        assert data.get("grant_type") == "refresh_token"
-        assert data.get("refresh_token") == "rt-old"
-        assert data.get("client_id") == "finlet-cli"
-        assert data.get("resource") == "https://finlet.dev/mcp"
-
-        # Credentials file rotated to the new pair atomically.
-        with open(creds_path) as f:
-            persisted = _json.load(f)
-        assert persisted["access_token"] == "jwt-new"
-        assert persisted["refresh_token"] == "rt-new"
-        # ``expires_at`` was recomputed as now + expires_in.
-        assert persisted["expires_at"] >= int(_time.time()) + 800
-
-    def test_resolve_bearer_token_refresh_400_returns_none(
-        self, monkeypatch, tmp_path, capsys: pytest.CaptureFixture[str]
-    ):
-        """4xx from /oauth/token ⇒ refresh-token revoked; returns None."""
-        import json as _json
-        import os as _os
-        import sys as _sys
-        import time as _time
-
-        from finlet.cli import _resolve_bearer_token
-
-        monkeypatch.setenv("HOME", str(tmp_path))
-        monkeypatch.delenv("USERPROFILE", raising=False)
-        creds_dir = tmp_path / ".finlet"
-        creds_dir.mkdir()
-        creds_path = creds_dir / "credentials"
-        past_expiry = int(_time.time()) - 60
-        with open(creds_path, "w") as f:
-            _json.dump(
-                {
-                    "access_token": "jwt-old",
-                    "refresh_token": "rt-revoked",
-                    "expires_at": past_expiry,
-                },
-                f,
-            )
-        if _sys.platform != "win32":
-            _os.chmod(creds_path, 0o600)
-
-        refresh_response = _mock_response(
-            400,
-            {
-                "error": "invalid_grant",
-                "error_description": "Refresh token is invalid, expired, or inactive.",
-            },
-        )
-        mock_client = MagicMock()
-        mock_client.__enter__.return_value = mock_client
-        mock_client.__exit__.return_value = False
-        mock_client.post.return_value = refresh_response
-
-        with patch("httpx.Client", return_value=mock_client):
-            token = _resolve_bearer_token(None)
-
-        assert token is None
-        captured = capsys.readouterr()
-        assert "Refresh token expired" in captured.err
-        assert "finlet auth login" in captured.err
-
-    def test_resolve_bearer_token_refresh_network_error_falls_back(
-        self, monkeypatch, tmp_path, capsys: pytest.CaptureFixture[str]
-    ):
-        """Transient network error ⇒ fall back to stored access token."""
-        import json as _json
-        import os as _os
-        import sys as _sys
-        import time as _time
-
-        from finlet.cli import _resolve_bearer_token
-
-        monkeypatch.setenv("HOME", str(tmp_path))
-        monkeypatch.delenv("USERPROFILE", raising=False)
-        creds_dir = tmp_path / ".finlet"
-        creds_dir.mkdir()
-        creds_path = creds_dir / "credentials"
-        past_expiry = int(_time.time()) - 60
-        with open(creds_path, "w") as f:
-            _json.dump(
-                {
-                    "access_token": "jwt-stale",
-                    "refresh_token": "rt-stale",
-                    "expires_at": past_expiry,
-                },
-                f,
-            )
-        if _sys.platform != "win32":
-            _os.chmod(creds_path, 0o600)
-
-        mock_client = MagicMock()
-        mock_client.__enter__.return_value = mock_client
-        mock_client.__exit__.return_value = False
-        mock_client.post.side_effect = httpx.ConnectError("nameserver lookup failed")
-
-        with patch("httpx.Client", return_value=mock_client):
-            token = _resolve_bearer_token(None)
-
-        # Stale fallback: the caller still gets to make their HTTP
-        # attempt; the AS will return a 401 surfacing the canonical
-        # ``finlet auth login`` hint downstream.
-        assert token == "jwt-stale"
-        captured = capsys.readouterr()
-        assert "Warning" in captured.err
-        assert "transient" in captured.err
-        # Credentials file was NOT rewritten — the stale tokens remain.
-        with open(creds_path) as f:
-            persisted = _json.load(f)
-        assert persisted["access_token"] == "jwt-stale"
-        assert persisted["refresh_token"] == "rt-stale"
-
-
-# ─── _emit_envelope helper ──────────────────────────────────────────
-
-
-class TestEmitEnvelope:
-    """Unit tests for the JSON / human-readable envelope dispatcher."""
-
-    def test_human_success_returns_data(self, capsys: pytest.CaptureFixture[str]):
-        from finlet.cli import _emit_envelope
-
-        envelope = {"id": "sid"}
-        result = _emit_envelope(envelope, as_json=False)
-        assert result == envelope
-        # No stdout side effect on success in human mode.
-        assert capsys.readouterr().out == ""
-
-    def test_json_success_prints_envelope(self, capsys: pytest.CaptureFixture[str]):
-        import json as _json
-
-        from finlet.cli import _emit_envelope
-
-        envelope = {"id": "sid", "value": 1.5}
-        result = _emit_envelope(envelope, as_json=True)
-        assert result == envelope
-        captured = capsys.readouterr()
-        assert _json.loads(captured.out) == envelope
-
-    def test_human_error_exits(self, capsys: pytest.CaptureFixture[str]):
-        import typer
-
-        from finlet.cli import _emit_envelope
-
-        with pytest.raises(typer.Exit) as excinfo:
-            _emit_envelope({"error": "fail"}, as_json=False)
-        assert excinfo.value.exit_code == 1
-        captured = capsys.readouterr()
-        assert "Error: fail" in captured.err
-
-    def test_json_error_emits_envelope_and_exits(self, capsys: pytest.CaptureFixture[str]):
-        import json as _json
-
-        import typer
-
-        from finlet.cli import _emit_envelope
-
-        envelope = {"error": "fail"}
-        with pytest.raises(typer.Exit):
-            _emit_envelope(envelope, as_json=True)
-        captured = capsys.readouterr()
-        assert _json.loads(captured.out) == envelope
-
-
 # ─── Root flags (F-2 hotfix) ─────────────────────────────────────────
 
 

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet show 014329f -- tests/test_cli_help.py' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
commit 014329fceca8a5d42f48ade1ab3ca0be93f6767d
Author: Justin Nam <justnau@Justins-MacBook-Air-2.local>
Date:   Fri May 22 22:52:36 2026 -0500

    [Team B v2.0.0]: trim CLI tests; add 4 MCP assertions on set_session_visibility (public + public_anonymous + no-share-url)
    
    V2 pure-MCP migration test cleanup (Step 10b BLOCKER-3):
    
    * DELETE `tests/test_cli_benchmark.py` (204 lines) — `finlet benchmark *`
      subcommands were removed in Team A's v2.0.0 cutover.
    * DELETE `tests/api/test_cli_mcp_client.py` (354 lines) — Team A deleted
      `finlet/cli_mcp_client.py`; nothing imports it now.
    * MODIFY `tests/test_cli.py` — strip 1499 lines covering dropped commands
      (session create/list/delete/publish, advance, order, portfolio, status,
      benchmark visibility) and the dispatch-helper unit classes
      (TestTranslateMcpError, TestResolveBearerToken, TestEmitEnvelope) that
      tested helpers Team A removed. Update TestTopLevelCommands to assert
      the new 6-command surface (serve/register/manual/plugins/auth/mcp) and
      add a regression guard `test_dropped_agentic_commands_not_registered`
      that fails if any agentic command leaks back into --help. Drops the
      `from finlet.cli_mcp_client import MCPDispatchError` import (Team A
      ImportError surface).
    * MODIFY `tests/test_cli_help.py` — drop the 4 dropped-command help tests
      (advance/order/portfolio/status), drop the `session` sub-app help test,
      add `manual --help` smoke. Module docstring updated to reflect the
      v2.0.0 6-command surface.
    * MODIFY `tests/mcp/test_decrypt_visibility_tools.py` — add the new
      `TestMcpSetSessionVisibilitySchemaKeys` class with 4 explicit
      assertions pinning the response schema for the SESSION-level
      visibility tool (separate from the existing benchmark-level tests):
        1. `public=True, anonymous=True`  → `result["public"]=True AND result["public_anonymous"]=True`.
        2. `public=True, anonymous=False` → `result["public"]=True AND result["public_anonymous"]=False` (attributed flow).
        3. `public=False, anonymous=True` → `result["public"]=False AND result["public_anonymous"]=True` (unpublish flow).
        4. Anti-shape-drift: `"share_url" not in result` (consumer derives URL externally).
      Locks in the Codex-flagged risk that INPUT param `anonymous` and
      OUTPUT field `public_anonymous` must not be silently aliased. Test
      fixtures use obviously-fake values (`fnlt_test_key_visibility`,
      `00000000-0000-0000-0000-00000000bbbb`) per Step 10b STRONG-3
      gitleaks safety. Forwards `tools_session.resolve_credential` to the
      conftest shim explicitly (the autouse shim doesn't patch
      tools_session, mirroring the pattern in
      `tests/mcp/test_session_lifecycle_blind.py::_mock_auth`).
    
    Validation:
      pytest tests/test_cli.py                       → 37 passed (was ImportError pre-trim)
      pytest tests/test_cli_help.py                  → 6 passed
      pytest tests/test_cli_oauth_login.py           → 16 passed (unmodified)
      pytest tests/mcp/test_decrypt_visibility_tools → 18 passed (14 existing + 4 new)
      pytest tests/mcp/                              → 639 passed, 1 xfailed, 0 failed
      ruff check tests/                              → All checks passed
      grep -c 'result\["public_anonymous"\]' …      → 3 (≥3 required)
      grep -c '"share_url" not in result' …          → 1 (≥1 required)
      grep -rE 'eyJ[A-Za-z0-9_-]{20,}|fnlt_[a-f0-9]{32}' tests/mcp/test_decrypt_visibility_tools.py → 0 (gitleaks-safe)
    
    Net diff: -1693 lines (2 files deleted, 3 files trimmed/augmented).

diff --git a/tests/test_cli_help.py b/tests/test_cli_help.py
index 0a8df9a..aeb8366 100644
--- a/tests/test_cli_help.py
+++ b/tests/test_cli_help.py
@@ -7,19 +7,18 @@ output width (see ``feedback_rich_help_width_brittleness.md``). The
 canonical pattern mirrored verbatim from
 ``tests/test_cli_oauth_login.py:494-498``.
 
-The set of 10 commands here corresponds to the See-also footers Team B1
-added to ``finlet/cli.py`` for the User Manual Overhaul exec-plan:
+v2.0.0 (pure-MCP cutover, 2026-05-23) removed the agentic-trading CLI
+commands (``advance`` / ``order`` / ``portfolio`` / ``status`` /
+``session``) — agents now drive Finlet through the MCP surface. The
+remaining 6 commands with See-also footers Team B1 added to
+``finlet/cli.py`` for the User Manual Overhaul exec-plan are:
 
 * ``serve`` — see ``finlet manual transports``
 * ``register`` — see ``finlet manual auth-model``
-* ``advance`` — see ``finlet manual session-lifecycle``
-* ``order`` — see ``finlet manual session-lifecycle``
-* ``portfolio`` — see ``finlet manual session-lifecycle``
-* ``status`` — see ``finlet manual session-lifecycle``
-* ``session`` (sub-app help) — see ``finlet manual session-lifecycle``
 * ``plugins`` (sub-app help) — see ``finlet manual plugin-matrix``
 * ``auth`` (sub-app help) — see ``finlet manual auth-model``
 * ``mcp serve`` — see ``finlet manual transports``
+* ``manual`` — offline manual viewer (no footer; self-documenting)
 """
 
 from __future__ import annotations
@@ -49,7 +48,7 @@ def home_sandbox(tmp_path, monkeypatch):
 
 
 class TestCliHelpFootered:
-    """Exit-code-only ``--help`` smokes for the 10 footered commands."""
+    """Exit-code-only ``--help`` smokes for the v2.0.0 6-command surface."""
 
     def test_serve_help(self, home_sandbox):
         """``finlet serve --help`` works (subcommand registered)."""
@@ -61,31 +60,6 @@ class TestCliHelpFootered:
         result = runner.invoke(app, ["register", "--help"])
         assert result.exit_code == 0
 
-    def test_advance_help(self, home_sandbox):
-        """``finlet advance --help`` works (subcommand registered)."""
-        result = runner.invoke(app, ["advance", "--help"])
-        assert result.exit_code == 0
-
-    def test_order_help(self, home_sandbox):
-        """``finlet order --help`` works (subcommand registered)."""
-        result = runner.invoke(app, ["order", "--help"])
-        assert result.exit_code == 0
-
-    def test_portfolio_help(self, home_sandbox):
-        """``finlet portfolio --help`` works (subcommand registered)."""
-        result = runner.invoke(app, ["portfolio", "--help"])
-        assert result.exit_code == 0
-
-    def test_status_help(self, home_sandbox):
-        """``finlet status --help`` works (subcommand registered)."""
-        result = runner.invoke(app, ["status", "--help"])
-        assert result.exit_code == 0
-
-    def test_session_subapp_help(self, home_sandbox):
-        """``finlet session --help`` works (sub-app registered)."""
-        result = runner.invoke(app, ["session", "--help"])
-        assert result.exit_code == 0
-
     def test_plugins_subapp_help(self, home_sandbox):
         """``finlet plugins --help`` works (sub-app registered)."""
         result = runner.invoke(app, ["plugins", "--help"])
@@ -100,3 +74,8 @@ class TestCliHelpFootered:
         """``finlet mcp serve --help`` works (subcommand registered)."""
         result = runner.invoke(app, ["mcp", "serve", "--help"])
         assert result.exit_code == 0
+
+    def test_manual_help(self, home_sandbox):
+        """``finlet manual --help`` works (subcommand registered)."""
+        result = runner.invoke(app, ["manual", "--help"])
+        assert result.exit_code == 0

exec
/bin/zsh -lc "sed -n '1,220p' /Users/justnau/finlet/docs/KNOWN_FAILURES.md" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
# Known Test Failures
> Last updated: 2026-05-23 by pre-flight check (exec-plan `V2_PURE_MCP_EXECUTION_PLAN`) — pre-spawn HEAD = `fb2637c` (post 2026-05-22 SESSION_LEVEL_BLIND v12 SHIPPED at `27d96ca` + cli.py:624 blind-mode fallback partial-fix exec-plan stage at `fb2637c`). Pre-flight ran in SMOKE mode (6-pass targeted pytest split, matching the established 2026-05-19/2026-05-22 pattern). Full-suite invocation skipped per documented dev-machine aiosqlite asyncio-teardown stall pattern; CI single-thread is the authoritative gate per `feedback_pr_gated_ci.md`. Combined SMOKE totals: pass-1 `tests/mcp/ tests/leaderboard/ tests/db/` → **950 passed, 1 xfailed in 126.29s**; pass-2 `tests/core/ tests/plugins/ tests/auth/ --ignore=tests/auth/oauth` → **1437 passed in 111.37s**; pass-3 `tests/api/ tests/services/ tests/gdpr/ tests/test_cli.py tests/test_cli_help.py tests/test_cli_benchmark.py` → **1999 passed, 1 skipped in 227.16s**; pass-4 `tests/auth/oauth/test_e2e_authcode_flow.py` (the 6 xfail-tracked tests in isolation) → **6 xpassed in 66.94s** (markers kept with `strict=False` per the established convention — the underlying aiosqlite asyncio-teardown race is known-intermittent under full-suite teardown pressure and removing markers would re-arm the gate next time the race surfaces); pass-5 `tests/billing/ tests/marketplace/ tests/telemetry/ tests/integration/ tests/property/ tests/test_cli_oauth_login.py tests/test_manual.py tests/test_manual_generate_llms_txt.py` → **471 passed in 16.24s**; pass-6 `tests/auth/ --ignore=tests/auth/oauth tests/dashboard/ tests/ingestion/ tests/scripts/ tests/fixtures/ tests/deploy/` → **642 passed in 183.02s**. Total **5499 passed, 1 skipped, 1 xfailed, 6 xpassed, 0 failed** across the six pytest invocations. The 6 xpassed are the OAuth e2e tests in `tests/auth/oauth/test_e2e_authcode_flow.py` lines 143/299/339/392/454/467 — verified xfail markers in place via grep. The 1 xfailed is `test_create_session_with_readonly_jwt_returns_insufficient_scope` at `tests/mcp/test_scope_enforcement.py:650` (StreamableHTTPSessionManager singleton conflict) — marker behaves as xfailed as expected. No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 5-team exec-plan to land v2.0.0 pure-MCP CLI cutover — Team A (`finlet/cli.py` surgery: rip server-side dispatch + benchmark-CLI removal + `finlet mcp serve` retain), Team C (server-side docs cleanup + `finlet/manual/` content + `dashboard/llms.txt` regen + `finlet/manual/registry.py` + `finlet/manual/generate_llms_txt.py`), Team D (`dashboard/index.html` + `dashboard/setup.html` + `dashboard/agent-guide.html` + new client-matrix integrations), Team B (`tests/test_cli.py` + `tests/test_cli_benchmark.py` + `tests/test_cli_help.py` + `tests/api/test_cli_mcp_client.py` + 4 new MCP assertions in `tests/mcp/test_decrypt_visibility_tools.py`), Team E (capstone: `pyproject.toml` version bump to 2.0.0 + `CHANGELOG.md` repair + `docs/launch/templates.md` + `docs/decisions/cli-mcp-http-dispatch.md` + `README.md` + `docs/ARCHITECTURE.md` + `docs/PRIVACY_POLICY.md`).
>
> Last updated: 2026-05-22 by post-merge close-out (exec-plan `SESSION_LEVEL_BLIND` v12 SHIPPED) — terminal HEAD = `e33cfb0` (post 7-team A-G merge + 6 cascading fix commits: Codex Team A P1+P2 `427ad87` catalog union + atomicity reorder, Team B P1 `ff79ab7` wall-clock audit redaction, Team D P1 `a5f8693` CLI response echo, Team E `f60a7ec` 3 STRONGs test quality, Team A Round 2 `620d825` scope-bypass-to-api-driven-only, Round 4 BLOCKER `e33cfb0` unforgeable `UserRecord.is_internal_benchmark` marker). Combined smoke gate: **3468 passed, 0 failed**. No new failures introduced, no xfail markers added or removed. Pre-existing 6 OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` (aiosqlite asyncio teardown race) verified in place at lines 143/299/339/392/454/467. Pre-existing 1 xfail in `tests/mcp/test_scope_enforcement.py:650` (StreamableHTTPSessionManager singleton conflict) verified in place. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope was a forward-only feature add (session-level blind opt-in via `create_session(blind=True)`); none of the surface-area changes touch the xfailed test paths.
>
> Last updated: 2026-05-22 by pre-flight check (exec-plan `SESSION_LEVEL_BLIND`) — pre-spawn HEAD = `dba6564` (prep commit on top of `b1a305f` post-Codex-3pack ARCHITECTURE+REMAINING_TASKS doc sync). Pre-flight ran in SMOKE mode (scope-limited pytest on `tests/api tests/mcp tests/leaderboard tests/billing tests/core tests/services` with `--ignore=tests/auth/oauth`) because the full-suite invocation hit the documented `tail -50` pipe-buffering + full-suite-timeout pattern from prior entries (KNOWN_FAILURES 2026-05-19, 2026-05-15) on this dev machine, and the subsequent retry was forced inline-synchronous per the harness reconnect. Smoke ran cleanly in 340.45s: **3195 passed, 1 skipped, 1 xfailed, 0 failed, 15119 warnings**. The 15119 warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change). The 1 xfailed is the `test_create_session_with_readonly_jwt_returns_insufficient_scope` entry below (StreamableHTTPSessionManager singleton conflict) — marker in place at `tests/mcp/test_scope_enforcement.py:650`, behaves as xfailed as expected. The 6 OAuth e2e xfail markers in `tests/auth/oauth/test_e2e_authcode_flow.py` were verified in place at lines 143/299/339/392/454/467 via grep but their surface was excluded from this smoke run (well-tested in prior pre-flights, ignored to avoid the aiosqlite teardown stall under full-suite pressure). No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 5-team exec-plan to introduce session-level blinding (REST + MCP + dashboard fairness/no-leak) — Team A (session_service.py blind opt-in via create_session + `_blind` field + `_compute_blind_mapping` helper + serializer plumbing through `session_response`), Team B (REST routes blind-flag wiring in `routes_session.py` + new `tests/api/test_session_create_blind.py` + `test_session_configure_blind.py` + `test_complete_session_blind.py`), Team C (MCP tools_session.py blind wiring in `mcp/server.py` + `mcp/tools_session.py` + new `tests/mcp/test_create_session_blind.py` + `test_session_lifecycle_blind.py`), Team D (CLI + benchmark_state.py blind plumbing through `cli.py` + `leaderboard/benchmark_state.py` + new `tests/billing/test_tier_max_tickers_removed.py` + repurpose `tests/api/test_input_validation.py::test_configure_universe_too_many_returns_422`), Team E (regression coverage: extend `tests/api/test_public_session_blind.py` + NEW `tests/e2e/test_session_level_blind_zero_leak.py` + dashboard `app.js`/`index.html`/`pricing.html` integration).
>
> Last updated: 2026-05-21 by pre-flight check (exec-plan `codex-bugs-4pack-v2`) — pre-spawn HEAD = `677f569` (post `6a79802` exec-plan staging commit, on top of PRs landed since the 2026-05-21 blind-sse-defense-in-depth baseline: bug-11cb2f16 scope flip + bug-4fa9160a input-validation gate + bug-79c7b578 MCP envelope hygiene + bug-b25eba4d lint cleanups). Pre-flight ran the full-suite (`uv run pytest tests/ -q --timeout=120 --ignore=tests/strategies --tb=no -p no:randomly`) and it completed cleanly in 651.44s (0:10:51): **5477 passed, 1 skipped, 6 xpassed, 0 failed, 15215 warnings**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate next time the race surfaces. The 15215 warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change) plus `websockets.legacy` deprecation noise from uvicorn (pre-existing). No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Test count grew +238 since the 2026-05-21 blind-sse baseline (5239 → 5477) reflecting the 4 Codex bug exec-plans landed since (bug-11cb2f16, bug-4fa9160a, bug-79c7b578, bug-b25eba4d); no failures introduced. Iteration scope: 4-team exec-plan to close 12 Codex bug-hunt findings + gitleaks hotfix — Team A2 (scope test hardening + transport-level test in `tests/mcp/test_scope_enforcement.py`), Team B2 (earliest-* semantics + docstrings + no-session discovery cap-to-now in `finlet/api/services/market_service.py` + `finlet/api/routes_market.py` + `finlet/mcp/server.py` + `tests/e2e/test_date_ceiling_zero_leak.py`), Team C2 (submit_order persist atomicity + inf/nan gate + test rename in `finlet/api/services/trade_service.py` + `finlet/mcp/tools_trading.py` + `finlet/api/routes_trade.py` + `tests/mcp/test_submit_order_validation.py` + new `tests/api/test_trade_service_atomicity.py`), Team D2 (FastMCP boundary wrapper for pydantic ValidationError + sanitize_paths key scrub + gitleaks hotfix in NEW `finlet/mcp/_fastmcp_patches.py` + `finlet/mcp/error_envelope.py` + `finlet/mcp/server.py` + `tests/mcp/test_error_envelope_hygiene.py` + `tests/mcp/test_scope_enforcement.py:60`).
>
> Last updated: 2026-05-21 by pre-flight check (exec-plan `2026-05-21-blind-sse-defense-in-depth`) — pre-spawn HEAD = `2e443d5` (post PR `2e443d5` chore(ci): move test (3.13) to PR gate + drop duplicate post-merge runs, on top of `914cd3f` blind-export exec-plan COMPLETED marker + PR #118 `abb86bd` Codex bugs blind-iter2 ship). Pre-flight ran the full-suite (`uv run pytest tests/ -q --timeout=120 --no-header -p no:randomly`) and it completed cleanly in 594.86s (0:09:54): **5239 passed, 1 skipped, 6 xpassed, 0 failed, 15180 warnings**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate next time the race surfaces. The 15180 warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change) plus `websockets.legacy` deprecation noise from uvicorn (pre-existing). No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Test count grew +69 since the 2026-05-20 baseline (5170 → 5239) reflecting the 3 new test files Team F shipped in the blind-export iteration; no failures introduced. Iteration scope: 4-team exec-plan to close SSE/REST trace + benchmark-completed envelope leak surfaces left after the 2026-05-20 blind-export iteration (Codex bug `0558053d` follow-up) — Team A (BlindMapping serializer-poison hardening + missing `tests/core/test_blind_mapping.py`), Team B (SSE trace/benchmark-completed envelope blinding in `finlet/api/routes_sse.py` + `finlet/api/services/{session,clock,trade}_service.py`), Team C (benchmark_state + reporting publish-gate hardening), Team D (zero-leak gate extension to live SSE event surface).
>
> Last updated: 2026-05-20 by pre-flight check (exec-plan `EXEC_PLAN_BLIND_EXPORT_2026_05_20`) — pre-spawn HEAD = `766ef43` (post PR #118 `abb86bd` Codex bugs `d1baf1b8`+`ad919e11`+`53c9eccb` blind-iter2 ship + watchdog-cron exec-plan tweak). Pre-flight ran the full-suite (`uv run pytest tests/ -q --timeout=120 --tb=no -p no:cacheprovider`) and it completed cleanly in 559.41s (0:09:19): **5170 passed, 1 skipped, 6 xpassed, 0 failed, 15139 warnings**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate next time the race surfaces. The 15139 warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change) plus `websockets.legacy` deprecation noise from uvicorn (pre-existing). No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 7 teams closing the live blind-benchmark export/trace leak surfaces (Codex bug `0558053d-aa73-47e4-bd00-4a09417568d6`) — Team A (BlindMapping serializer-poison + pre-persist trace blinding across `finlet/core/blind_mapping.py` + `finlet/db/persistence.py` + 5 `save_trace_entry` call sites in `finlet/api/services/{market,trade,clock}_service.py`), Team B (BenchmarkRunModel new columns `decrypted_at`/`published`/`published_anonymous`/`published_at` + migration 021 + immutability invariant in `finlet/db/leaderboard_models.py` + `finlet/db/leaderboard_persistence.py` + `finlet/leaderboard/benchmark_state.py`), Team C (export_benchmark_results A1 fix + reporting defensive raise in `finlet/mcp/tools_benchmark.py:436-516` + `finlet/leaderboard/reporting.py`), Team D (decrypt + visibility tools + public benchmark router NEW in `finlet/api/services/benchmark_service.py` + `finlet/api/routes_public_benchmark.py` + `finlet/api/routes_benchmark.py` + `finlet/api/schemas/benchmark.py` + `finlet/api/deprecation.py` + `finlet/cli.py`), Team E (REST + SSE trace blinding in `finlet/api/routes_portfolio.py` + `finlet/api/routes_sse.py` + `finlet/api/serializers.py` + `finlet/api/routes_public_session.py` re-export), Team F (zero-leak gate extension + 3 new test files in `tests/e2e/`), Team G (docs + 3 new decision records + ARCHITECTURE.md + REMAINING_TASKS.md + CLAUDE.md).
>
> 2026-05-20 (post-merge note, exec-plan `codex_bugs_blind_iter2`): 6 OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` ran as XPASS during the finalize full-suite gate; xfail markers RETAINED because root cause (aiosqlite asyncio-teardown race) is unaddressed — these may regress on the next run.
>
> Last updated: 2026-05-20 by pre-flight check (exec-plan `codex_bugs_blind_iter2_EXECUTION_PLAN`) — pre-spawn HEAD = `73009e2` (post PR #117 Codex bug 50abd05e ship — blind-leak iter1 closure). Pre-flight ran the full-suite (`uv run pytest tests/ -q --timeout=120 --tb=no -p no:cacheprovider`) and it completed cleanly in 484.89s (0:08:04): **5116 passed, 1 skipped, 6 xpassed, 0 failed, 15170 warnings**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate next time the race surfaces. The 15170 warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change) plus `websockets.legacy` deprecation noise from uvicorn (pre-existing). No new failures, no new xfail markers added, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 4 teams closing 3 Codex-reported blind-leak surfaces from the 2026-05-20 second dry-run — Team A (`list_available_tickers` metadata-vs-reality correctness fix in `finlet/api/services/market_service.py`), Team B (`@blind_error_mapper` decorator across `finlet/mcp/server.py` + `tools_trading.py` + `tools_portfolio.py` + `tools_benchmark.py` + `tools_session.py` + `tools_telemetry.py` to auto-blind every tool's error response), Team C (`complete_session` benchmark_complete payload blinding in `finlet/mcp/server.py` + `finlet/leaderboard/reporting.py` + `finlet/api/services/session_service.py`), Team D (extend `tests/e2e/test_blind_benchmark_zero_leak.py` to exercise error paths, completion payloads, and metadata cross-validation + extend `docs/decisions/blind-benchmark-envelope-fields-must-blind.md`).
>
> Last updated: 2026-05-19 by pre-flight check (exec-plan `CODEX_BUG_CE8DE077_EXECUTION_PLAN`) — pre-spawn HEAD = `54d0da7` (orchestrator setup commit, post `949c93b` fundamentals hero-save shipment at PR #111). Pre-flight ran the full-suite (`uv run pytest tests/ -q --timeout=120 -p no:xdist`) and it completed cleanly in 1226.28s (0:20:26): **4943 passed, 1 skipped, 6 xpassed, 9 errors**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate next time the race surfaces. The 9 errors are the documented local-environment data-volume flake from `tests/integration/test_mcp_oauth_e2e.py` — same root cause as the 2026-05-10 entry below (`live_server` session-scope fixture times out at 30s under the inline-benchmark-startup load on this dev machine, ~hundred-plus `benchmark-*` session_loaded events). Verified post-run: `test_oauth_login_writes_credentials_at_mode_0600` passes in 29.65s when run in isolation. NOT a regression — CI single-thread on the same SHA passes them. xfail markers are NOT added because the failures are at fixture setup (xfail wraps the test body, not the fixture), and the established convention (2026-05-10 entry below) is to document them here without marking, since CI is the authoritative gate per `feedback_pr_gated_ci.md`. No new failures, no entries added to the table, no entries removed. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: cascading fixes for Codex bug ce8de077 across `finlet/api/services/session_service.py` + `finlet/mcp/server.py` + `finlet/mcp/auth.py` + `finlet/mcp/tools_benchmark.py` + `finlet/leaderboard/benchmark_state.py` + `finlet/leaderboard/benchmarks.py` + `finlet/db/leaderboard_models.py` + `finlet/db/leaderboard_persistence.py` + `finlet/core/session.py` + `finlet/core/clock.py` + corresponding tests.
>
> Last updated: 2026-05-19 by pre-flight check (exec-plan `FUNDAMENTALS_HERO_SAVE_EXECUTION_PLAN`) — main HEAD = `6a3bba5` (orchestrator setup commit). Pre-flight ran in SMOKE mode (4-pass targeted pytest split, matching the established 2026-05-19 pre-flight pattern). The full-suite invocation reproduced the documented aiosqlite asyncio-teardown hang stall — killed after early stall, retried with 4-pass split per `feedback_pr_gated_ci.md` (CI single-thread is the trusted full-suite gate). Combined SMOKE totals across 4 pytest invocations: pass-1 `tests/mcp/ tests/leaderboard/ tests/db/` → **671 passed in 125.52s**; pass-2 `tests/core/ tests/plugins/ tests/auth/ --ignore=tests/auth/oauth` → **1307 passed in 238.27s**; pass-3 `tests/api/ tests/services/ tests/gdpr/ tests/test_cli.py` → **1774 passed, 1 skipped in 206.36s**; pass-4 `tests/auth/oauth/test_e2e_authcode_flow.py` (the 6 xfail-tracked tests in isolation) → **6 xpassed in 175.19s** (markers kept with `strict=False` per the established convention — the underlying aiosqlite asyncio-teardown race is known-intermittent under full-suite teardown pressure and removing markers would re-arm the gate next time the race surfaces). Total **3758 passed, 1 skipped, 6 xpassed, 0 failed** across the four pytest invocations. No new failures, no new xfail markers added, no entries removed. Pre-existing 6 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False` markers verified in place via grep. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: fundamentals_s3 hero-save coverage fix across `finlet/plugins/fundamentals_plugin.py` + `finlet/ingestion/s3_writer.py` + `scripts/ingest_fundamentals.py` + `finlet/api/services/market_service.py` + corresponding test files.
>
> Last updated: 2026-05-19 by pre-flight check (exec-plan `MCP_BENCHMARK_HARNESS_FIX_EXECUTION_PLAN`) — spawn-base SHA = `241cabc` (`main`). Pre-flight ran in SMOKE mode (4-pass targeted pytest split, matching prior 2026-05-19 pre-flight pattern) — the full-suite invocation `uv run pytest tests/ -q --timeout=60 --ignore=tests/e2e -x` reproduced the documented aiosqlite asyncio-teardown hang at ~38% (the `XXXXXX` block of OAuth xfails surfaces the worker-thread "Event loop is closed" race, which then stalls subsequent tests indefinitely past the budget). CI single-thread is the trusted full-suite gate per `feedback_pr_gated_ci.md` and `feedback_pyproject_comment_stale_about_ci_xdist`. Combined SMOKE totals across 4 pytest invocations: pass-1 `tests/mcp/ tests/leaderboard/ tests/db/` → **664 passed in 117.17s**; pass-2 `tests/core/ tests/plugins/ tests/auth/ --ignore=tests/auth/oauth` → **1307 passed in 221.61s**; pass-3 `tests/api/ tests/services/ tests/gdpr/ tests/test_cli.py` → **1767 passed, 1 skipped in 203.71s**; pass-4 `tests/auth/oauth/test_e2e_authcode_flow.py` (the 6 xfail-tracked tests in isolation) → **6 xpassed in 164.79s** (markers kept with `strict=False` per the established convention — the underlying aiosqlite asyncio-teardown race is known-intermittent under full-suite teardown pressure and removing markers would re-arm the gate next time the race surfaces). Total **3744 passed, 1 skipped, 6 xpassed, 0 failed** across the four pytest invocations. e2e collection-only smoke on `tests/e2e/` confirms `tests/e2e/test_benchmark_flow.py` (6 tests) collects cleanly; full e2e run deferred (slow live-server fixture). No new failures, no new xfail markers added, no entries removed. Pre-existing 6 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False` markers verified in place via grep. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 4 cascading MCP benchmark bug fixes across `finlet/api/services/session_service.py`, `finlet/mcp/tools_benchmark.py`, `finlet/leaderboard/benchmark_state.py`, `finlet/db/leaderboard_persistence.py`, `finlet/mcp/auth.py`, `finlet/telemetry/bug_storage.py` + corresponding tests.
>
> Last updated: 2026-05-19 by pre-flight check (exec-plan `MCP_BENCHMARK_FIXES_EXECUTION_PLAN`) — pre-spawn HEAD = `1b53d97` (post `60ac154` /mcp dual-accept generator regen, on top of `2da10fc` /mcp dual-accept reality alignment merge). Pre-flight ran in SMOKE mode (4-pass targeted pytest split, matching the documented 2026-05-19 prior pre-flight pattern) rather than full-suite, because the dev machine's documented full-suite hang under aiosqlite asyncio-teardown pressure (see 2026-05-10 and 2026-05-15 entries below) reproduced again here: `uv run pytest tests/ -q --timeout=120 -p no:xdist` stalled at ~52% past the 900s budget; CI is the trusted full-suite gate per `feedback_pr_gated_ci.md`. Combined SMOKE totals: pass-1 `tests/mcp/ tests/leaderboard/ tests/db/` → **655 passed in 116.62s**; pass-2 `tests/core/ tests/plugins/ tests/auth/ --ignore=tests/auth/oauth` → **1294 passed in 229.52s**; pass-3 `tests/api/ tests/services/ tests/gdpr/ tests/test_cli.py` → **1767 passed, 1 skipped in 204.36s**; pass-4 `tests/auth/oauth/test_e2e_authcode_flow.py` (the 6 xfail-tracked tests in isolation) → **6 xpassed in 161.56s** (kept marked with `strict=False` per the established convention — the underlying aiosqlite asyncio-teardown race is known-intermittent under full-suite teardown pressure and removing markers would re-arm the gate next time the race surfaces). Total **3722 passed, 1 skipped, 6 xpassed, 0 failed** across the four pytest invocations. The `tests/auth/oauth/` directory-level surface (broader than the 6-test e2e file) was tried but timed out at 300s in the wider iteration (`EXIT: 124`) — same aiosqlite teardown pattern; the 6 in-scope xfails passed before the stall. No new failures, no new xfail markers added, no entries removed. Pre-existing 6 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False`. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 4 parallel teams — Team A (MCP benchmark tooling: `finlet/mcp/tools_benchmark.py` + `finlet/leaderboard/benchmarks.py` + `finlet/leaderboard/benchmark_state.py` + `finlet/db/persistence.py` + `tests/mcp/test_tools_benchmark.py`), Team B (`finlet/core/clock.py` + `tests/core/test_clock.py` + `tests/core/test_clock_step_integration.py`), Team C (`finlet/plugins/fundamentals_plugin.py` + `finlet/plugins/base.py` + `tests/plugins/test_fundamentals_plugin.py` + `tests/plugins/test_fundamentals_backfill.py`), Team D (`finlet/core/session.py` + `finlet/api/services/session_service.py` + `tests/db/test_persistence.py` + `tests/leaderboard/test_benchmark_state.py`).
>
> Last updated: 2026-05-19 (post-merge close-out — exec-plan `AI_QUANTAMENTAL_STRATEGY_EXECUTION_PLAN` 7-team shipment landed). No entries added or removed this iteration. The 6 pre-existing OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False`; pre-existing Hypothesis portfolio-rounding flake unchanged. Shipment introduced no new pytest failures, no new xfail markers; subproject tests live under `strategies/ai_quantamental/tests/` (own pytest invocation, excluded from the root pytest gate).
>
> Last updated: 2026-05-19 by pre-flight check (exec-plan `AI_QUANTAMENTAL_STRATEGY_EXECUTION_PLAN`) — main HEAD = `b34f99b` (post pre-flight artifact commit on top of `3c506ce` RFC 8414 OAuth metadata alias). Pre-flight ran in SMOKE mode (3-pass targeted pytest on `tests/api/ tests/mcp/ tests/leaderboard/ tests/test_cli.py` + `tests/auth/ --ignore=tests/auth/oauth` + `tests/core/ tests/plugins/ tests/services/ tests/gdpr/`) rather than full-suite, because the dev machine's documented data-volume flake on `tests/integration/` (see 2026-05-10 entry below) makes full-suite gating unreliable here and the full-suite `uv run pytest tests/ --timeout=120 --ignore=tests/e2e` invocation hung at ~31% with aiosqlite asyncio teardown timeouts (same pattern as prior pre-flights). CI is the trusted full-suite gate per `feedback_pr_gated_ci.md`. Combined SMOKE totals: pass-1 (api+mcp+leaderboard+cli) **2152 passed, 1 skipped in 294.46s**, pass-2 (auth no-oauth) **103 passed in 182.85s**, pass-3 (core+plugins+services+gdpr) **1386 passed in 34.51s** — total **3641 passed, 1 skipped, 0 failed** across the three pytest invocations. The `tests/auth/oauth/` surface was not gated in this pre-flight because the 6 pre-existing aiosqlite-asyncio-teardown xfails below already cover that surface and standalone re-checks on this dev machine consistently surface the same teardown race. Lint not gated this iteration (deferred to per-team validation). No new failures, no new xfail markers added, no entries removed. Pre-existing 6 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False`. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: 6-session execution — Team A (quantamental scaffolding), Team B (`report_bug` MCP tool), Team C (derived-metric helpers), Team D (screens + portfolio), Team E (historical backfill simulator — launch video material), Team F (LLM tiebreaker), Team G (live driver + GH Actions monthly cron).
>
> Last updated: 2026-05-15 by pre-flight check (exec-plan `USER_MANUAL_OVERHAUL_EXECUTION_PLAN`) — main HEAD = `48121cc` (post PR #84 detached-instance regression-test merge on top of PR #83 Stripe live-mode activation at `f3781cd`). Pytest full-suite run (`uv run pytest tests/ -q --timeout=120 -p no:cacheprovider`): **4657 passed, 6 xpassed, 14692 warnings in 913.22s (0:15:13)**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate on the same race next time it surfaces. No new failures, no new xfail markers added, no entries removed this iteration. Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table) remains unchanged. Iteration scope: 7-team execution — Team A (Manual Foundation: NEW `finlet/manual/` package + `finlet/cli.py` `manual` command + `pyproject.toml` hatchling include + `.github/workflows/ci.yml` paths-ignore include override + `README.md:66` args fix), Team B1 (CLI docstring see-also footers in `finlet/cli.py` + `tests/test_cli_help.py` NEW), Team B2 (REST API + Billing envelope suffixes across `finlet/api/routes_*.py` + `finlet/billing/service.py` + new tests), Team B3 (MCP envelope suffixes + `_AUTH_REQUIRED_MESSAGE` dedup + `finlet/api/deprecation.py` `/mcp` whitelist + new tests), Team B4 (OAuth modeled envelope suffixes across `finlet/auth/oauth/*.py` + new tests), Team C (Plugin envelope suffixes across 4 named plugins + `tests/plugins/test_error_anchors.py` NEW), Team D (Dashboard polish: `dashboard/agent-guide.html` 8-tab expansion + `dashboard/setup.html` Phase-5 voice pass + `dashboard/llms.txt` regen + `scripts/git-hooks/pre-commit` 4th guard + `scripts/lint-llms-txt-fresh.sh` NEW + `tests/e2e/journey-19-agent-guide.spec.ts` NEW).
>
> Last updated: 2026-05-14 by pre-flight check (exec-plan `GDPR_EXPORT_F_EXECUTION_PLAN`) — main HEAD = `84161f4` (post pre-flight cleanup commit clearing stale team-prompts on top of `278b242` GDPR-F plan stage). Pytest full-suite run (`timeout 1100 uv run pytest tests/ -q --timeout=120 -x -p no:cacheprovider`): **4493 passed, 6 xpassed, 14674 warnings in 820.97s (13:40)**. The 6 xpassed are the existing OAuth e2e xfails in `tests/auth/oauth/test_e2e_authcode_flow.py` — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline) and removing the markers would re-arm the gate on the same race next time it surfaces. No new failures, no new xfail markers added, no entries removed this iteration. Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table) remains unchanged. Iteration scope: GDPR Article 20 data export (Item F) — async job, ZIP-per-table JSONL archive, S3 24h lifecycle, presigned URL, OAuth Bearer-only, audit table, per-team file ownership across new `finlet/gdpr/` package + `finlet/db/auth_models.py` + `finlet/api/app.py` + `finlet/api/routes_settings.py` + service/schema cleanups.
>
> Last updated: 2026-05-14 by pre-flight check (exec-plan `HYGIENE_BATCH_2026_05_13`) — main HEAD = `3391f0b` (post PR #74 SETTINGS_AND_BILLING_RESTORE merge). Pre-flight ran in SMOKE mode (targeted pytest on `tests/api/ tests/auth/ tests/mcp/ tests/leaderboard/ tests/test_cli.py`) rather than full-suite, because the dev machine's data-volume flake on `tests/integration/` (documented in the 2026-05-10 entry below) makes full-suite gate unreliable here and CI is the trusted full-suite gate. The combined surface was split into two passes to stay under the per-invocation timeout cap: pass-1 `tests/api/ tests/mcp/ tests/leaderboard/ tests/test_cli.py` ran **2036 passed, 0 failed, 0 xfail, 0 skipped in 276.43s**, and pass-2 `tests/auth/ --ignore=tests/auth/oauth` ran **103 passed, 0 failed, 0 xfail, 0 skipped in 150.71s** — total **2139 passed, 0 failed, 0 xfail, 0 skipped in 427.14s** across the two pytest invocations. The `tests/auth/oauth/` surface was not gated in this pre-flight because the 6 pre-existing aiosqlite-asyncio-teardown xfails below already cover that surface and the 180s standalone re-check on this dev machine timed out mid-run after ~70 cases (63 dots + 6 X + 1 dot) without any new failures observed — same pattern documented under 2026-05-10/2026-05-11. Lint: clean (`ruff check finlet/ tests/`). The `--timeout=120` flag from the original pre-flight instruction was dropped because `pytest-timeout` is the K6 work item this iteration is shipping — it is not yet installed at `3391f0b`, so the flag errored out and was removed from the invocation. No new failures introduced, no new xfail markers added, no entries removed. Pre-existing 6 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False`. Pre-existing Hypothesis portfolio-rounding flake unchanged. Iteration scope: single Team A — K6 (`pyproject.toml` dev dep), K5 (journey-14/15 e2e), I5 (`_ensure_utc` canonicalization to `finlet/utils/datetime.py`), I8 (13 vague-error rewrites across `finlet/api/services/settings_service.py` + `finlet/api/routes_auth_credentials.py` + `finlet/api/routes_auth_sessions.py` + `finlet/api/routes_marketplace_admin.py`).
>
> Last updated: 2026-05-13 by pre-flight check (exec-plan `PUBLIC_SESSION_VIEW_FOLLOWUPS_EXEC_PLAN`) — main HEAD = `cd21911` (post PR #70 ci-cost-cuts merge). Pre-flight ran in DEFERRED mode — full pytest skipped because (a) the local pytest invocation `uv run pytest tests/ -q --tb=no` ran for 14 minutes past the configured 600s `timeout(1)` cap with the output buffered behind `tail -20` (the pipe held all output until exit, so wall-time visibility was zero); the runtime killed it at the pre-flight budget. (b) main is unchanged from the 2026-05-12 PR #70 surface for the API/MCP/CLI areas the followups touch (this iteration's Team A is `dashboard/landing.html` line-241 placeholder substitution, Team B is `tests/e2e/` smoke + helper additions, Team C is `finlet/api/app.py` + `finlet/api/routes_session.py` + `finlet/api/deprecation.py` API-routes-rules pruning); the underlying public-session view tests on `tests/api/test_public_session.py` (Phase A green at PR #65 squash 37ea32f) remain in scope. (c) The 4 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) below remain unchanged with `strict=False`. (d) Pre-existing Hypothesis portfolio-rounding flake unchanged. (e) PR-gated CI is the trusted full-suite gate per `feedback_pr_gated_ci.md` — local dev-machine pytest is documented to flake on `tests/integration/` data-volume issues. No new failures observed pre-launch; no entries added/removed/promoted this iteration. Iteration scope: 3 sequential teams — Team A landing CTA placeholder fix, Team B e2e smoke + Playwright fixture/helper additions, Team C api-routes-rules canonicalization + deprecation cleanup.
>
> Last updated: 2026-05-12 by pre-flight check (exec-plan `PUBLIC_SESSION_VIEW_EXEC_PLAN`) — main HEAD = `a876229` (origin/main, post PR #64 handoff doc merge, on top of PR #63 dashboard empty-states + pricing at `4b829b7`). Pre-flight ran in DEFERRED mode — full pytest skipped because (a) main is unchanged from the 2026-05-11 v1.0.1 baseline below for the API/MCP/CLI surface; (b) per-team validation in the public-session view exec-plan runs targeted pytest gates that cover the surgery surface (`tests/api/test_public_session*.py`, `tests/db/test_session_migration_014.py`, `tests/test_cli.py`); (c) the documented `tests/integration/` data-volume flake from the 2026-05-10 entry below still applies, and the per-team gates avoid that path. No new xfail markers added, no entries removed this iteration. Pre-existing 4 OAuth-e2e xfails (`tests/auth/oauth/test_e2e_authcode_flow.py`) remain with `strict=False`. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Iteration scope: 3 sequential teams per the plan doc — Team A backend (`finlet/db/`, `finlet/api/`, `finlet/mcp/`, `finlet/cli.py`, `tests/api/`, `tests/db/`, `tests/test_cli.py`); Team B frontend (`dashboard/public.html` NEW, `dashboard/public.js` NEW, `dashboard/renderers.js` NEW, refactor `dashboard/app.js`, `dashboard/landing.html` nav + CTA, `finlet/api/app.py` static-route inserts); Team C docs (`docs/ARCHITECTURE.md`, `docs/decisions/session-public-visibility.md` NEW, `docs/REMAINING_TASKS.md`, `docs/PRIVACY_POLICY.md`, `.claude/rules/api-routes.md`).
>
> Last updated: 2026-05-11 by pre-flight check (v1.0.1 hotfix exec-plan `EXECUTION_PLAN_V1_0_1_HOTFIX`) — main HEAD = `cbff2e1` (origin/main, post v1.0.0 finalize PR #52). Pre-flight ran in SMOKE mode (lint + targeted pytest on `tests/test_cli.py tests/api/ tests/mcp/`) rather than full-suite, because the dev machine's data-volume flake on `tests/integration/` (documented in the 2026-05-10 entry below) makes a full-suite gate unreliable here and CI is the trusted gate for full coverage. Lint clean (`ruff check finlet/ tests/`). Smoke pytest: **1745 passed, 0 failed, 1532 warnings in 178.53s**. The warnings are the documented `aiosqlite._connection_worker_thread` "Event loop is closed" async-teardown noise (pre-existing, no behavior change). Targeted OAuth e2e re-verify: `tests/auth/oauth/test_e2e_authcode_flow.py` → **4 xpassed in 104.14s** (the same 4 tests xfail-tracked below; preserved with `strict=False` per the convention documented in the 2026-05-10 entry — passed today on this machine but kept marked because the underlying aiosqlite asyncio-teardown race is known-intermittent). No new failures, no new xfail markers added, no entries removed this iteration. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. v1.0.1 scope: Team A (`finlet/api/app.py` + `finlet/mcp/auth.py` + new `tests/mcp/test_http_endpoint.py` + `tests/api/test_mcp_mount.py`), Team B (`finlet/cli_mcp_client.py` + `finlet/cli.py` + `tests/api/test_cli_mcp_client.py` NEW + `tests/test_cli.py`), Team C (`dashboard/agent-guide.html` + `dashboard/setup.html` + `dashboard/landing.html`).
>
> Last updated: 2026-05-10 by pre-flight check (exec-plan `V1_0_0_BLIND_WALK_FIXES` + Team H) — main HEAD = `f679447` (origin/main, post-bandit-hotfix; production deployed). Pytest full-suite run: **4409 passed, 4 xpassed, 12 errors in 875s**. The 4 xpassed are the existing `tests/auth/oauth/test_e2e_authcode_flow.py` entries below — they passed in this run but are kept with `strict=False` xfail markers in place because the underlying aiosqlite asyncio-teardown race is known-intermittent (see 2026-05-09 baseline below) and removing the markers would re-arm the gate on the same race the next time it surfaces. The 12 errors are all OAuth integration tests in `tests/integration/test_cli_stdio_e2e.py` + `tests/integration/test_mcp_oauth_e2e.py` — they all fail at the `live_server` session-scope fixture with `RuntimeError: live_server failed to come up on 127.0.0.1:<port> within 30s` after migrations and ~hundred-plus `benchmark-*` session_loaded events run inline during boot. This is a **local-environment data-volume flake** (the heavy benchmark dataset on this dev machine pushes startup past the 30s deadline), NOT a regression — CI run `25638684433` (workflow `CI`, branch `hotfix/bandit-b110-nosec`, 2026-05-10 20:15Z, on top of the same `f679447` tree) reports **4421 passed, 4 xpassed, 0 errors** on both py3.12 and py3.13 matrices for the identical tests. No new xfail markers added; no entries removed. Pre-existing Hypothesis portfolio-rounding flake remains unchanged.
>
> Last updated: 2026-05-09 by pre-flight check (exec-plan `MCP_FIRST_PHASE_5_CLI_STDIO`) — main HEAD = `24379ee` (post Phase 4e close-out). Pre-flight identified an aiosqlite + asyncio-loop teardown race in 4 OAuth e2e tests (`tests/auth/oauth/test_e2e_authcode_flow.py`) that ERROR with `RuntimeError: Event loop is closed` in the full-suite gate (the `aiosqlite._connection_worker_thread` outlives the test's asyncio loop, then the next test's loop closure surfaces the worker's pending `set_result`/`set_exception` call as the documented RuntimeError). The 4 tests are xfail'd (`strict=False`) so they continue to be exercised but don't fail the gate; isolated runs with `--timeout=120` still pass them (4/4 in 80.66s). No api_key/Bearer surface failures, no Phase 5 surface contamination — issue is pre-existing pytest async-teardown noise (in scope under tighter timeouts) NOT a regression from Phase 4e or any prior phase. Pytest baseline preserved (4356/4360 passing + 4 xfail).
>
> Last updated: 2026-05-09 (post-merge close-out) — exec-plan `MCP_FIRST_PHASE_4_OAUTH` sub-phase 4e shipped via single team merge (E1 `75223ba` bearer-only cutover + Phase 4 SHIPPED) plus finalize commits `4420745` (plan doc update — E1 SHIPPED + Session 5 checkpoint) and `6e76489` (eval-trace artifacts). **No entries added or removed this iteration.** Phase 4e closes the originally-planned 90-day dual-accept window: the api_key fallthrough is removed from `finlet/mcp/bearer_context.py:resolve_credential` and `finlet/mcp/auth.py:_authenticate_oauth_or_key`, and api_key on MCP tools now returns the documented Phase 4e rejection envelope (`{"error": "api_key authentication is no longer supported on MCP tools. Run 'finlet auth login' to obtain an OAuth Bearer token. See docs/MCP_OAUTH_MIGRATION.md."}`) as a 401. To preserve test-time call-site stability without leaking dual-accept logic into production, `tests/conftest.py` adds an autouse `_legacy_api_key_test_shim` fixture (sentinel-based; legacy MCP unit tests authenticating via `api_key=<key>` arguments keep working) — opt-out via `@pytest.mark.no_api_key_shim` on Phase 4e cutover tests. Post-merge full pytest gate: **4360 passed, 0 failed** (per E1's report, with the targeted 49/49 post-merge gate confirming new tests). No new failures introduced, no xfail markers added, no pre-existing failure tracked in this file resolved. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Pytest baseline updated upward (Phase 4e adds `tests/integration/test_mcp_oauth_e2e.py::TestGroup3BearerOnly` + `tests/conftest.py` shim coverage).
>
> Last updated: 2026-05-09 (post-merge close-out) — exec-plan `MCP_FIRST_PHASE_4_OAUTH` sub-phase 4c shipped via four sequential team merges (C1 `39afe87` JWT validator + `require_oauth` + 90-day sunset decision record, C2 `45024bb` MCP auth Bearer path + Surprise A/B cleanup, C3 `cebd327` 16 MCP tools dual-accept, C4 `ce97aa9` scope enforcement + UserTier mapping) plus one post-merge fixup `ff6909e` updating 3 test stubs (`tests/services/test_gate_unification.py` + `tests/api/test_benchmark_progress.py` + `tests/api/test_bug8_limit_stop_fills.py`) for the Option A 3-tuple migration in `resolve_credential` (caught by gate, not pre-merge validation). **No entries added or removed this iteration.** Phase 4c adds the Resource Server surface: `finlet/auth/oauth/jwt_validator.py` (NEW, joserfc EdDSA-pinned), `finlet/auth/deps.py` (`require_oauth` injector), `finlet/mcp/auth.py` (`_authenticate_oauth_or_key` + `enforce_scope`), `finlet/mcp/bearer_context.py` (NEW, ContextVar middleware + `resolve_credential` 3-tuple), and 16 MCP tools wired across `finlet/mcp/server.py` + `finlet/mcp/tools_benchmark.py` + `finlet/mcp/tools_portfolio.py` + `finlet/mcp/tools_trading.py`. New tests under `tests/mcp/test_oauth_jwt_validator.py`, `tests/mcp/test_oauth_dual_accept.py`, `tests/mcp/test_mcp_auth_oauth_path.py`, `tests/mcp/test_scope_enforcement.py`. Post-fixup gate: targeted on `tests/api/ tests/mcp/ tests/services/ tests/auth/` — **1929 passed, 0 failed** (10:25). Full CI-matching gate (post-fixup): in flight at close-out time. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Pytest baseline updated upward (Phase 4c adds the OAuth tests above).
>
> Last updated: 2026-05-08 (post-merge close-out) — exec-plan `MCP_FIRST_PHASE_4_OAUTH` sub-phase 4b shipped via four sequential team merges (B1 `0ba1717` data layer, B2 `471790d` AS endpoints, B3 `36d06bd` DCR, B4 `6a3adf3` router wiring); **no entries added or removed this iteration**. Phase 4b adds the OAuth Authorization Server surface (`finlet/auth/oauth/` package + migration `014_add_oauth_clients.py` + `pyproject.toml` adds `mcp[auth]>=1.27.0` and `joserfc>=1.0`) plus new tests in `tests/auth/oauth/`. Post-B4 full pytest gate: **4239 passed, 0 failed** (orchestrator confirmed). No new failures introduced, no xfail markers added, no pre-existing failure tracked in this file resolved. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Pytest baseline updated upward (Phase 4b adds tests under `tests/auth/oauth/`).
>
> Last updated: 2026-05-08 (post-merge close-out) — exec-plan `MCP_FIRST_PHASE_4_OAUTH` Team A1 merged to main (commit `e248382`); **no entries added or removed this iteration** (Phase 4a is pure docs — adds `docs/decisions/mcp-oauth-2-1-auth-model.md` decision record only; no Python source or test changes, no new pytest failures, no xfail markers, no resolved pre-existing failure tracked in this file). Test collection-only smoke: 4110 tests collect without import errors. Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Pytest baseline preserved per the Phase 3 pre-flight refresh below.

> Last updated: 2026-05-08 by pre-flight check (exec-plan `MCP_FIRST_PHASE_3`) — main HEAD = `57f9ab3` (post Phase 2 close-out). Pytest baseline 4072/4072 passing (full suite, `uv run pytest tests/ -q --timeout=120`, 435.98s). No FAILED, no ERROR, no xfail markers needed. 75 warnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py` + aiosqlite `_connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown noise, no behavior change). Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table below) remains unchanged. Phase 3 scope (3-team plan: A middleware refinement, B docs, C tests) — deprecation-header policy refinement; no Python source changes anticipated outside `finlet/api/app.py` middleware + `tests/api/test_api_versioning.py`. No xfail markers added — full suite is green.

> Last updated: 2026-05-07 (post-merge close-out) — exec-plan `MCP_FIRST_PHASE_2` Teams A/B/C/D/E merged to main (final commit `82959df`); **no entries added or removed this iteration** (Phase 2 closes audit C1/H4/H6 and adds new tests in `tests/services/` but introduced no new pytest failures, no xfail markers, and resolved no pre-existing failure tracked in this file). Pre-existing Hypothesis portfolio-rounding flake remains unchanged. Pytest baseline preserved per the pre-flight refresh below.

> Last updated: 2026-05-07 by pre-flight check (exec-plan `MCP_FIRST_PHASE_2`) — main HEAD = `ed19e91` (post Phase 2 plan-doc commit, on top of Phase 1 close-out at `d08dd3d`). Pytest baseline 4000/4000 passing (full suite, `uv run pytest tests/ -q --timeout=120 --maxfail=200 -p no:cacheprovider`, 395.18s). No FAILED, no ERROR, no xfail markers needed. 63 warnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py` + aiosqlite `_connection_worker_thread` "Event loop is closed" cleanup + starlette per-request-cookies deprecation; pre-existing async-teardown noise, no behavior change). Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table below) remains unchanged. Phase 2 scope per `docs/plans/exec-plans/MCP_FIRST_PHASE_2_EXEC_PLAN.md` (5 worktree spawns): Team A (`finlet/api/services/errors.py` NEW + `finlet/mcp/auth.py` validate_session_id parity + `tests/services/test_errors.py` NEW + `tests/mcp/test_mcp_auth.py` extension); Team B (`finlet/api/services/session_service.py` + `finlet/api/routes_session.py` + `finlet/mcp/server.py` session-tool block + new `tests/services/test_session_service.py` + `tests/mcp/test_mcp_server.py` extension); Team C (`finlet/api/services/trade_service.py` + `finlet/api/routes_trade.py` + `finlet/mcp/tools_trading.py` + new `tests/services/test_trade_service.py` + `tests/mcp/test_mcp_trading.py` extension — closes audit H6); Team D (`finlet/api/services/market_service.py` + `finlet/api/routes_market.py` + `finlet/mcp/server.py` plugin-query block + new `tests/services/test_market_service.py` + `tests/mcp/test_mcp_server.py` extension — closes audit H4 + C1); Team E (new `tests/services/test_gate_unification.py` cross-surface parity tests). No xfail markers added — full suite is green.

> Last updated: 2026-05-07 by pre-flight check (exec-plan `MCP_FIRST_PHASE_1`) — main HEAD = `d08dd3d` (post bug-hunt `20260507T163535Z3ac5` close-out + this iteration's plan-doc commit). Pytest baseline 3976/3976 passing (full suite, `uv run pytest tests/ -q --timeout=120`, 389.97s). No FAILED, no ERROR, no xfail markers needed. 72 warnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py` + aiosqlite `_connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown noise, no behavior change). Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table below) remains unchanged. No Playwright known-fail entries — `journey-06c-settings-billing.spec.ts:44` was permanently closed by the 2026-05-06 UI write-path launch cut (see Resolved section). Iteration scope (3 worktree spawns): Team A MCP correctness (`finlet/mcp/server.py`, `finlet/mcp/auth.py`, `finlet/mcp/tools_portfolio.py`, `finlet/mcp/tools_trading.py`, `tests/mcp/test_mcp_auth.py`, `tests/mcp/test_mcp_server.py` — audit findings C2/C3/H7); Team B CLI envelope (`finlet/cli.py`, `finlet/api/routes_auth_credentials.py`, `finlet/api/app.py`, `tests/test_cli.py` — audit findings C4/H8/H12); Team C benchmark log redaction (`finlet/leaderboard/runner.py`, `finlet/mcp/tools_benchmark.py`, `finlet/core/session.py` — audit findings H9). No xfail markers added — full suite is green.

> Last updated: 2026-05-07 by pre-flight check (bug-hunt `20260507T163535Z3ac5`) — main HEAD = `23505f4` (post ui-removal-launch-cut close-out + skill-eval-results commit). Pytest baseline 3976/3976 passing (full suite, `uv run pytest tests/ -q --timeout=120 -p no:cacheprovider`, 388.64s). No FAILED, no ERROR, no xfail markers needed. 71 warnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py` + aiosqlite `_connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown noise, no behavior change). Pre-existing Hypothesis portfolio-rounding flake (in Known Flakes table below) remains unchanged. No Playwright known-fail entries — `journey-06c-settings-billing.spec.ts:44` was permanently closed by the 2026-05-06 UI write-path launch cut (see Resolved section). Iteration scope per `docs/bug-hunt/20260507T163535Z3ac5/plan.md`: Team A dashboard copy fixes (`dashboard/api-keys.html`, `dashboard/api-keys.js`, `dashboard/agent-guide.html`, `dashboard/index.html`, `dashboard/setup.html` — replace `finlet auth register` with `finlet register` + setup.html post-signup-key-reveal copy fix); Team B session-creation modal default name (`dashboard/app.js`, `dashboard/index.html`, `tests/e2e/journey-04-dashboard.spec.ts`); Team C plugin permanent-degraded honest-copy (`finlet/plugins/news_plugin.py`, `finlet/plugins/sentiment_plugin.py`, `tests/plugins/test_news_plugin.py`, `tests/plugins/test_sentiment_plugin.py`); Team D favicon (`dashboard/favicon.ico` NEW or `finlet/api/app.py` redirect); Team F docs sync.
>
> Last updated: 2026-05-07 by pre-flight check (ui-removal-launch-cut) — main HEAD = `b3bc368` (post bug-hunt `20260507T042257Z3c76` close-out + aria-label-mismatch refactor docs/eval). Pytest baseline 3974/3974 passing (full suite, `uv run pytest tests/ -q --timeout=120 -p no:cacheprovider --ignore=tests/e2e`, 383.35s). No FAILED, no ERROR, no xfail markers needed. 83 warnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup + aiosqlite connection-worker thread "Event loop is closed" cleanup; pre-existing async-teardown noise, no behavior change). Pre-existing Playwright known-fail (`journey-06c-settings-billing.spec.ts:44` — "settings API key create and revoke flow") and Hypothesis portfolio-rounding flake remain unchanged — both are out of pytest gating scope. Iteration scope per `docs/refactor/ui-cut/plan.md`: 14 CUT dashboard files (trade-ticket.js, onboarding.{js,css}, settings.{html,css}, billing.{html,js,css}, pricing.html, marketplace.{html,js,css}, dialog-state-mirror.js, form-dirty-tracker.js), 5 TRIM dashboard files (app.js, index.html, settings.js, leaderboard-submit.js, modal-controller.js), event-contract.md prune, 9 CUT e2e tests (journey-{05-trade,06a-settings-profile,06b-settings-plugins,06c-settings-billing,06d-settings-danger-zone,08-billing,12-forgot-password,onboarding,modal-stacking}.spec.ts), CI guards, docs sweep. No Python touched in product paths (Team H optional API-route audit; Teams E-G touch tests/, scripts/, .github/, docs/).

> Last updated: 2026-05-06 by pre-flight check (bug-hunt `20260506T185234Z542e`) — main HEAD = `a851358` (post bug-hunt `20260506T154910Z0b41` close-out). Pytest baseline 3980/3980 passing (full suite, `uv run pytest tests/ -q --timeout=120`, 365.96s). No FAILED, no ERROR, no xfail markers needed. 72 RuntimeWarnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py` + 1 aiosqlite event-loop-closed in test teardown; pre-existing async-teardown noise, no behavior change). Pre-existing Playwright known-fail file path updated: `journey-06-settings.spec.ts:714` → `journey-06c-settings-billing.spec.ts:44` (the file was split into 4 surfaces in commit `96a5849` — see Known Failures table); test name unchanged ("settings API key create and revoke flow"). Hypothesis portfolio-rounding flake unchanged. Both Playwright entries remain out of pytest gating scope. Iteration scope per plan: `dashboard/app.js`, `dashboard/shared-nav.js`, `dashboard/onboarding.js`, `dashboard/index.html`, `dashboard/event-contract.md`, `docs/decisions/copy-api-key-dead-affordance.md`, plus Playwright extensions in `tests/e2e/journey-04-dashboard.spec.ts`, `tests/e2e/journey-05-trade.spec.ts`, `tests/e2e/journey-onboarding.spec.ts`. No Python touched.

> Last updated: 2026-05-06 by pre-flight check (bug-hunt `20260506T154910Z0b41`) — main HEAD = `4d620b1` (post bug-hunt `20260506T061637Z6594` Phase 5.5 close-out). Pytest baseline 3980/3980 passing (full suite, `uv run pytest tests/ -q --timeout=120 -x`, 362.32s). No FAILED, no ERROR, no xfail markers needed. 71 RuntimeWarnings remain (auth service `AsyncMock` coroutine-never-awaited cleanup in `tests/auth/test_service.py`; pre-existing async-teardown noise, no behavior change). Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis portfolio-rounding flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (`dashboard/onboarding.js`), Team D (docs + refactor-queue), and Team E (ledger) worktree spawns. Iteration scope is dashboard-JS + docs only; no Python touched.

> Last updated: 2026-05-06 by pre-flight check (CI/deploy stability reform — `docs/handoffs/2026-05-06-ci-deploy-execution-plan.md`) — main HEAD = `bee289c` (post `b458041` audit handoff + `bee289c` doc-archive cleanup commit). Pytest baseline 3974/3974 passing (full suite, `pytest tests/ -q --timeout=120 --tb=line --ignore=tests/e2e`, 353.12s). No FAILED, no ERROR, no xfail markers needed. 77 RuntimeWarnings remain (`aiosqlite._connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown flake in test fixtures, no behavior change). Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis portfolio-rounding flake remain unchanged — both are out of pytest gating scope for this exec-plan's Teams A (deploy-pin), B (smoke-extend), C (pre-push-fix), D (cve-allowlist), E (settings-split) worktree spawns.

> Last updated: 2026-05-05 by pre-flight check (bug-hunt `20260505T234713Z0c8a`) — main HEAD = `84074be` (post bug-hunt `20260505T213116Z45f1` close-out). Pytest baseline 3974/3974 passing (full suite, `uv run pytest tests/ -q --timeout=120 --tb=no --ignore=tests/e2e`, 344.54s). No FAILED, no ERROR, no xfail markers needed. 73 RuntimeWarnings remain (`aiosqlite._connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown flake in test fixtures, no behavior change). Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis portfolio-rounding flake remain unchanged — both are out of pytest gating scope for this iteration's dashboard worktree spawns (`dashboard/settings.js`, `dashboard/onboarding.js`, `dashboard/app.js`, `dashboard/index.html`).

> Last updated: 2026-05-05 (post-merge close-out) — bug-hunt `20260505T213116Z45f1` Teams A/B/C/D merged to main; **no entries removed this iteration** (no pre-existing failure in this file was resolved by the four shipped fixes — Team A `dashboard/app.js`, Team B `dashboard/modal-controller.js` + `dashboard/styles.css`, Team C `dashboard/trade-ticket.js`, Team D `dashboard/settings.js` — and no new Python failures introduced; the pre-existing `journey-06-settings.spec.ts:714` Playwright known-fail and Hypothesis portfolio-rounding flake remain unchanged). Pytest baseline preserved (3974/3974 passing per pre-flight refresh below).

> Last updated: 2026-05-05 by pre-flight check (bug-hunt `20260505T213116Z45f1`) — main HEAD = `bdeb62d` (post stat-card-overflow-contract refactor close-out). Pytest baseline 3974/3974 passing (full suite, `uv run pytest tests/ -q --timeout=120 --tb=short --ignore=tests/e2e`, 341.64s). No FAILED, no ERROR, no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (Order Log fee disclosure in `dashboard/app.js`), Team B (modal-controller hide non-top stack members in `dashboard/modal-controller.js` + `dashboard/styles.css`), Team C (trade-ticket close panel-class removal in `dashboard/trade-ticket.js`), and Team D (testPlugin DOM update in `dashboard/settings.js`) worktree spawns. 74 RuntimeWarnings remain (`aiosqlite._connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown flake in test fixtures, no behavior change).

> Last updated: 2026-05-05 by pre-flight check (refactor `stat-card-overflow-contract`) — main HEAD = `98aced6` (post Phase 5.5 retest artifacts for bug-hunt `20260505T175445Z750b`). Pytest baseline 3974/3974 passing (full suite, `uv run pytest tests/ -q --timeout=120 --ignore=tests/e2e`, 342.37s). No FAILED, no ERROR, no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (CSS contract: stat-card grid + tile overflow guards in `dashboard/styles.css` + `dashboard/index.html`) and Team B (docs: `docs/ARCHITECTURE.md` stat-card invariant + `docs/decisions/stat-card-overflow-contract.md` + `docs/LESSONS.md` entry) worktree spawns. Playwright tests skipped in pytest run; Team A's `tests/e2e/journey-sim-time-tile.spec.ts` extension will be exercised via `npx playwright test` in per-team validation.

> Last updated: 2026-05-05 (post-merge close-out) — bug-hunt `20260505T175445Z750b` outcome: 2 fixes merged (Team B + Team C), 1 demoted (Team A). Pre-flight pytest baseline 3974/3974 passing (recorded by the prior iteration's pre-flight refresh under `convention-enforcement-2026-05-05`); this iteration added zero Python tests (Team B added one Playwright regression to `tests/e2e/journey-04-dashboard.spec.ts`; Team C added one Playwright case to `tests/e2e/journey-sim-time-tile.spec.ts`; Team A shipped no code), so the Python pytest baseline is preserved at 3974/3974. Team A (commit `545e1de`) is verify-only — no code modified. Team B (commit `edc5ce7`, merge `548eac3`) is dashboard-JS + Playwright only — `dashboard/app.js` (hidden-anchor LineSeries on equity chart) + `tests/e2e/journey-04-dashboard.spec.ts` (`equity curve Y-axis spans meaningful range with low-variance data` regression); 10/10 journey-04 pass including the pre-existing buffered-history-replay regression. Team C (commit `125f2b2`, merge `f1d6581`) is dashboard-JS + dashboard-HTML + Playwright only — `dashboard/app.js` (`renderClock()` writes `formatDateShort` to `#sim-time` + sets `title=` to `formatDateTime`), `dashboard/index.html` (line 174 gains initial `title="--"`), `tests/e2e/journey-sim-time-tile.spec.ts` (3/3 pass with new date-only + title= contract); `dashboard/styles.css` UNCHANGED. No new pytest failures introduced this iteration; no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged.

> Last updated: 2026-05-05 (post-merge close-out) — bug-hunt `20260505T142400Z3330` Teams A/B/E merged to main + Phase 5.5 retest passed on deploy SHA `95d6562`. Team A (commit `b5dc82f`, merge `30a1d9c`) is dashboard-JS only — `dashboard/app.js` (`pnlArrow`/`pnlClass`/`formatPct` rounded-then-classify + Max Drawdown re-routed through helpers) and `tests/e2e/journey-05-trade.spec.ts` (post-fill no-arrow / no-`-0.00` / no-`pnl-negative` assertion); no Python touched. Team B (commit `f7d932a`, merge `c1edc8c`) is dashboard-JS only — `dashboard/app.js` (`formatLatency` helper, 5 explicit branches, short-circuit `null` for non-finite) and `tests/e2e/journey-04-dashboard.spec.ts` (canonical-format-set assertion); no Python touched. Team E (merge `548ddb4`) is ledger-only; +2 lines on `docs/bug-hunt/ledger.jsonl`. Three e2e fix-forwards landed post-deploy (`0e1e35b` first-text-node read, `47cd784` drop value-pinning + stub SSE, `95d6562` drop SSE stub — cards render via real SSE) — none touch product code. No new pytest failures introduced this iteration; no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged. Pytest baseline preserved.

> Last updated: 2026-05-05 by pre-flight check (refactor `convention-enforcement-2026-05-05`) — main HEAD = `4264779` (post pre-flight commit of plan + exec-trace + refactor-queue doc on top of `d159572` benchmark-blindness invariant docs). Pytest baseline 3974/3974 passing (full suite, `uv run pytest tests/ -q --timeout=120 --tb=no --ignore=tests/e2e`, 349.43s). No FAILED, no ERROR, no xfail markers needed. 88 RuntimeWarnings remain (`aiosqlite._connection_worker_thread` "Event loop is closed" cleanup; pre-existing async-teardown flake in test fixtures, no behavior change). Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (event-bus enforcement lint), Team B (form-dirty-tracker registry rollout), and Team C (onboarding registry rollout) worktree spawns.

> Last updated: 2026-05-04 by pre-flight check (bug-hunt `20260504T165106Z1ab2`) — main HEAD = `9c3843e` (post `0b33271` ci pre-push smoke + `d30e51a` settings.js backtick escape). Pytest baseline 3969/3969 passing (full suite, `uv run pytest tests/ -q --timeout=120`, 319.28s). No FAILED, no ERROR, no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (leaderboard schema/UI) + Team B (CLI session-create idempotency reorder) worktree spawns.

> Last updated: 2026-05-03 (post-merge close-out) — bug-hunt `20260503T195318Z43db` Teams A/B merged to main. Team A (commit `4c4e7da`, fix `713e3d5`) added `GET /v1/sessions/{id}/orders` + `GET /v1/sessions/{id}/orders/{oid}` aliases in `finlet/api/routes_session.py` plus `tests/api/test_orders.py` (7 new tests, all pass). Team B (commit `0baa8d5`, fix `056b417`) is dashboard-JS only — `dashboard/shared-nav.js` modified for the cookie-session-path redirect + dynamic relabel; the mobile drawer button inherits via existing `.click()` proxy in `dashboard/mobile-nav.js`; no Python touched; trusted-types lint passed. No new pytest failures introduced this iteration; no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged. Pytest baseline preserved.

> Last updated: 2026-05-03 by pre-flight check (bug-hunt `20260503T195318Z43db`) — main HEAD = `3420145` (Phase 5.5 retest close-out for prior iteration `20260503T030227Z2009`). Pytest baseline 3949/3949 passing (full suite, `uv run pytest tests/ -q --timeout=120 -x --ignore=tests/e2e`, 308.90s). No FAILED, no ERROR, no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's Team A (server-side route alias) + Team B (dashboard click-handler) worktree spawns.

> Last updated: 2026-05-03 by pre-flight check (bug-hunt `20260503T030227Z2009`) — main HEAD = `7cda296` (Team B merge close-out). Pytest baseline 3955/3955 passing (full suite, `uv run pytest tests/ -q --timeout=120`). No FAILED, no ERROR, no xfail markers needed. Pre-existing Playwright known-fail (`journey-06-settings.spec.ts:714`) and Hypothesis flake remain unchanged — both are out of pytest gating scope for this iteration's dashboard-only worktree spawns.

> No new failures introduced by bug-hunt `20260503T030227Z2009` (Teams A/B). Team A (trade-ticket render-on-read v3.1 terminal `repaintCash()` at every publisher site, commit `8c55a90`) is dashboard-JS only — `dashboard/trade-ticket.js` + `dashboard/app.js` modified plus extension to `tests/dashboard/trade-ticket-post-submit.spec.js` (node `--test`); the v3 atomic-mutate-then-publish contract is preserved (terminal `repaintCash()` is appended after publish at all 3 publisher sites); no Python touched; trusted-types lint passed; 7/7 trade-ticket-post-submit + 71/71 full dashboard test suite pass. Team B (Settings Ingest refetch gate-on-server-state-change, commit `cbd8340`) is dashboard-JS + Playwright only — `dashboard/settings.js` modified plus extension to `tests/e2e/journey-06-settings.spec.ts`; the `_pluginNeedsIngest()` predicate is unchanged (gate logic is purely additive — snapshot pre-click `[data-plugin-message]` text, recursive poll capped at 30 ticks, refetch when text drifts or cap reached); no Python touched; 27/27 journey-06-settings tests pass. The pre-existing journey-06-settings:714 known-fail entry remains the sole Playwright known-fail and is unchanged this iteration. Pytest baseline preserved.

> No new failures introduced by bug-hunt `20260502T211937Z7ddd` (Teams A/B). Team A (Settings Ingest button row-level pending state, commit `c489d53`) is dashboard-JS + dashboard-CSS only — `dashboard/settings.js` + `dashboard/settings.css` modified; the existing `loadPlugins()` render contract is preserved (transient `apiFetch` null preserves render); no Python touched; trusted-types lint passed. Team B (dashboard plugin-health widget default-status alignment, commit `4837c7f`) is dashboard-JS + dashboard-CSS only — `dashboard/app.js` + `dashboard/styles.css` modified; the canonical `GET /v1/plugins/health` endpoint contract is unchanged; one-line default-value swap at `dashboard/app.js:2212` aligns with `dashboard/settings.js:1040` ('unknown' instead of 'healthy'); no Python touched; trusted-types lint passed. The pre-existing journey-06-settings:714 known-fail entry remains the sole Playwright known-fail and is unchanged this iteration. Pytest baseline preserved.

> No new failures introduced by bug-hunt `20260502T142726Z7b36` (Teams A/B/C). Team A (Trade Ticket post-submit refetch+republish, commit `109686c`) is dashboard-JS + Playwright only — added `tests/dashboard/trade-ticket-post-submit.spec.js` (node `--test`) and extended `tests/e2e/journey-05-trade.spec.ts`; no Python touched. Team B (probe-message sanitization across price/news/fundamentals plugins + new `POST /v1/plugins/{name}/ingest` stub at `finlet/api/routes_plugins.py`, commit `ad0adb0`) added new test file `tests/api/test_plugins_ingest.py` covering the 202+job_id path and 404-for-unknown-plugin path, plus extensions to `tests/api/test_plugin_health.py` and `tests/plugins/test_price_plugin.py` for the sanitized error wording; the existing `routes_health._check_price_data_status` translator continues to map `"S3 unreachable"` → `s3_unreachable` (pinned wording is part of the response contract). Team C (Settings consume canonical `/v1/plugins/health` + Ingest button, commit `2d200db`) is dashboard-JS/HTML/CSS only — extended `tests/e2e/journey-06-settings.spec.ts` with the new Ingest-button affordance assertion; no Python touched. Pytest baseline preserved.

> No new failures introduced by refactor `close-patch-ineffective-2026-05-02` (Teams A/B/C). Team A (plugins remove CLI + email validator empty-string clear, commit `6c72541`) added 4 new `TestPluginsRemoveCommand` tests + 1 new `TestPlugins.test_update_plugin_clears_credentials_with_empty_strings` — 19/19 in the targeted gate; ruff + mypy pass. Team B (onboarding.js:382-385 profile reach-in deletion, commit `076189c`) is dashboard-JS only — added 3 new tests in `tests/dashboard/onboarding-checklist.spec.js` (23/23 pass). Team C (settings.css unsaved-banner display:none switch, commit `e4cdb5e`) is dashboard CSS/HTML/JSDoc only — form-dirty-tracker unit tests 6/6 still pass; new Playwright spec at `tests/playwright/settings-dirty-banner.spec.js` NOT auto-discovered by the existing `tests/e2e/playwright.config.ts` (`testDir: '.'`); session-checkpoint Phase 5.5 retest envelope will exercise live-site cold-load. Pytest baseline preserved.

> No new failures introduced by bug-hunt `20260501T234103Z1a49` (Teams A/B/C/D/E). Team A (engine equity-curve snapshot-on-fill, commit `29e9ac5`) added 3 new tests in `tests/core/test_session.py` + `tests/api/test_portfolio.py`; existing 3902 pytest baseline preserved. Team B (dashboard SSE republish portfolio:updated, commit `3a2bf46`) is dashboard-JS + Playwright only; new assertion in `tests/e2e/journey-05-trade.spec.ts`. Team C (settings dirty-banner aria-hidden sync + synthetic-key gate, commit `87a37b6`) is dashboard only; new cold-load Playwright test in `tests/e2e/journey-06-settings.spec.ts`. Team D (onboarding `profile:saved` outcome event, commit `4924948`) is dashboard-JS only; new tests in `tests/dashboard/onboarding-checklist.spec.js`. Team E (price plugin S3-reachability probe + 60s probe cache, commit `76f4724`) added 3 new tests in `tests/api/test_plugin_health.py` + `tests/plugins/test_price_plugin.py`. Pytest baseline preserved.

> No new failures introduced by bug-hunt `20260501T172055Z127b` (Teams A/B). Team A (EDGAR plugin hot-reload + actionable CLI message, commit `1a07a1e`) added 4 new tests in `tests/test_cli.py::TestPluginsAddCommand` and 3 new tests in `tests/api/test_plugin_health.py::TestPluginReload`; full plugin/registry suite 756/756 + combined CLI+plugin-health spot 61/61 passed. Team B (settings password-form wrap, commit `ce5fa52`) is dashboard-HTML/JS only — `dashboard/settings.html` + `dashboard/settings.js` were edited; trusted-types lint passed; dashboard pytest selection 5/5 passed. Findings 1 (portfolio AttributeError) and 4 (plugins list mismatch) shipped no code change this iteration — both are pypi-release-lag artifacts (already fixed in main at `cc6cddf` and `1a3c17e`); see `docs/decisions/pypi-release-cadence.md`. Pytest baseline preserved.

> No new failures introduced by bug-hunt `20260430T222711Z3666` (Teams A/B/C/D). Team A (auth `_OptionalUser` cookie-fall-through, commit `47c7e79`) updated 2 existing tests in `tests/api/test_session_auth.py` to match the new contract (validate-probe stale-cookie returns anonymous, not 401) and extended `tests/auth/test_session_validate_probe.py` with parity coverage. Team B (CLI idempotency + plugins-list parity, commit `1616ade`) added 4 new tests in `tests/test_cli.py`; spot-check across 86 adjacent API tests (sessions/idempotency/plugin-health) passed. Team C (form-dirty-tracker pre-clear, commit `dba4c83`) is dashboard-JS only — Test 6 in `tests/dashboard/form-dirty-tracker.spec.js` reproduces the bug without the fix and passes with it. Team D (selectSession publish, commit `91922c7`) added 2 tests in `tests/dashboard/onboarding-checklist.spec.js`; node `--test` 17/17 + sibling 30/30; pytest spot-check on idempotency/e2e session 10/10. Pytest baseline preserved.

> No new failures introduced by the trusted-types refactor. Pytest baseline (3902/3902 passing) preserved through the merge. The refactor scope (lint script + dashboard `*.html` files + `api-utils.js` reporter + Playwright telemetry spec) does not touch Python — pytest count is stable.

Python suite: 0 failures out of 3902 tests (full suite, `uv run pytest tests/ -q --timeout=120 --ignore=tests/e2e`, 569.62s). Pre-flight verified 2026-04-30 ahead of trusted-types refactor exec-plan; post-merge baseline preserved. Pre-flight base SHA: `5a579a7` (main HEAD = `plan: trusted-types refactor`). No new pytest failures, no xfail markers needed. 60 RuntimeWarnings remain (auth service AsyncMock cleanup; pre-existing, no behavior change).

Playwright `journey-06c-settings-billing.spec.ts:44` ("settings API key create and revoke flow"): closed by the 2026-05-06 UI write-path launch cut. The test (and all four `journey-06{a,b,c,d}-settings-*.spec.ts` surfaces) covered `dashboard/settings.html`, which was cut to `legacy/dashboard-ui/settings.html` and `legacy/tests/e2e/journey-06{a,b,c,d}-*.spec.ts` on 2026-05-06. The flaky modal-stacking interaction is no longer in production scope — `dashboard/api-keys.html` (the read-only replacement) does not host a create-key form. If the legacy spec is ever revived for restoration smoke tests, run via `tests/e2e/legacy.playwright.config.ts`.

## Known Failures (xfailed)

| Test | File | Reason | Since |
|------|------|--------|-------|
| test_e2e_authcode_flow_against_live_fastapi_app | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-09 |
| test_authorize_without_login_redirects_to_login_with_next | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-09 |
| test_authorize_with_bearer_runs_existing_flow | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-14 |
| test_authorize_with_session_cookie_runs_existing_flow | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-14 |
| test_token_endpoint_unsupported_grant_type | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-09 |
| test_token_endpoint_emits_no_deprecation_headers | `tests/auth/oauth/test_e2e_authcode_flow.py` | aiosqlite asyncio teardown — RuntimeError: Event loop is closed | 2026-05-09 |
| test_create_session_with_readonly_jwt_returns_insufficient_scope | `tests/mcp/test_scope_enforcement.py` | StreamableHTTPSessionManager singleton conflict with sibling MCP-HTTP tests in the same process (test_http_endpoint / test_oauth_dual_accept). Test passes deterministically in isolation. The session-manager is process-global by design in mcp[auth] 1.27.0; running two `create_app()` calls in one process re-invokes `.run()` which raises RuntimeError. Marked xfail strict=False — sibling unit tests provide load-bearing scope coverage. | 2026-05-21 |

## Known Flakes

| Test | File | Reason | Since |
|------|------|--------|-------|
| Hypothesis portfolio rounding properties | `tests/core/test_property_based.py` | Hypothesis occasionally generates extreme float sequences that expose sub-penny rounding drift after many buy/sell cycles. Cash rounding to 2dp (commit aa451d9) mitigates but does not eliminate all edge cases under property-based fuzzing. Flake rate is very low (<1% of runs). | 2026-03-29 |

## Resolved

`tests/e2e/journey-06-settings.spec.ts:289` — settings API key create and revoke flow. `dashboard/settings.html` migrated to the post-modal-stacking `class="modal-overlay fl-modal"` + `data-modal-id` convention, with `openModal/closeModal` in `settings.js` now thin wrappers around `window.finletModal.open/close`. Two collateral fixes shipped in the same merge: dirty-state tracker now skips inputs inside `.modal-overlay` (the Create-Key modal name field was triggering the unsaved-changes banner), and the journey-06 submit-button fallback selector was scoped to `#create-key-modal`. 16/16 settings tests now passed (commit `b3cb2f1`, fix `ac8e0b2`) at the time. Resolved 2026-04-28. **Note 2026-04-29:** regression resurfaced (line `:444` after additions). **Note 2026-05-06:** entry permanently closed by UI write-path launch cut — `dashboard/settings.html` and the `journey-06{a,b,c,d}-settings-*.spec.ts` surfaces were git-mv'd to `legacy/dashboard-ui/` and `legacy/tests/e2e/`. The create-key modal is no longer hosted in production; production `dashboard/api-keys.html` is read-only.

CLI smoke tests in `tests/e2e/journey-14-cli-session.spec.ts` (5 tests) and `tests/e2e/journey-15-cli-plugins.spec.ts` (7 tests) -- The specs invoked a bare `finlet` binary via `execSync`, which only resolves when `.venv/bin/` is on the spawn PATH; full-suite Playwright runs without venv-activated PATH all failed at the `Command failed: finlet ...` step. Switched the invocation to `uv run python -m finlet`, centralised behind a `FINLET_CLI` constant in `tests/e2e/helpers.ts`. `uv run` resolves the project venv from `pyproject.toml` / `uv.lock` independent of PATH state, and `python -m finlet` invokes the package's `__main__` module with identical behaviour to the binary. All 12 tests now pass (verified via `npx playwright test tests/e2e/journey-14-cli-session.spec.ts tests/e2e/journey-15-cli-plugins.spec.ts --reporter=line`). Fixed in commit `38f9726`. Resolved as of 2026-04-28.

FIELD_AUDIT_FIXES sprint (2026-04-10): Per-ticker circuit breaker scoping (Team A), position price history fallback under open breakers (Team B), percentage-scale portfolio metrics (Team C), batch time advance in CLI and MCP (Team D), `GET /market/tickers` + `list_available_tickers` MCP tool (Team E), fundamentals cache TTL invalidation + atomic S3 downloads (Team F), setup page consolidation (Team G). All fixed; +33 new tests shipped (3522 -> 3555 total).

User Feedback Fixes sprint (2026-04-09): Circuit breaker state bleeding between sessions (Team A), MARKET orders silently queuing as PENDING when price plugin errored (Team B), CLI `portfolio` command crashing on dict iteration (Team C), `_query_history()` silently returning empty on no data (Team D). All fixed; new tests added.

E2E Playwright failures in `journey-04-dashboard.spec.ts` and `journey-08-billing.spec.ts` -- Stale assertions referencing marketplace nav and hidden billing tiers that were removed in commit `451af35`. Fixed by removing the stale assertions (commit `e30a830`). Resolved as of 2026-04-06.

`ModuleNotFoundError: finlet.api` on production server -- `[tool.hatch.build.targets.wheel]` in `pyproject.toml` had an `only-include` whitelist that excluded all subpackages (`api/`, `core/`, `plugins/`, etc.). The server installed the wheel via `pip install -e .` and got only the three thin-client files. Fixed by removing the `only-include` section entirely (commit `1d4b247`). See `docs/decisions/remove-hatch-wheel-whitelist.md`. Resolved as of 2026-04-06.

`test_get_session_found` (`tests/mcp/test_mcp_server.py`) -- Previously failed due to stale `finlet.mcp.auth` module reference. Now passes. Resolved as of 2026-04-02.

`test_different_user_agent_triggers_warning`, `test_different_ip_triggers_warning`, `test_both_ip_and_ua_change_triggers_two_warnings` (`tests/api/test_session_fingerprint.py`) -- Previously xfail due to structlog `capture_logs()` not intercepting warnings. Now pass; xfail markers removed. Resolved as of 2026-04-02.

`test_value_equation_after_buy_sell` (`tests/core/test_property_based.py:81`) -- Floating-point comparison bug where `cost > self._cash` rejected orders when cost == cash. Fixed with epsilon tolerance (commits 5bb8e67, b0f53e2).

The 14 `tests/leaderboard/test_api_driven_strategy.py` failures (`KeyError: 'benchmark_price'`) were caused by `BenchmarkPricePlugin` not being registered in `PluginRegistry` circuit breakers. Fixed by handling plugins without circuit breaker registration in `query_plugin()` (commit c7a7687).

exec
/bin/zsh -lc "nl -ba /Users/justnau/finlet/tests/mcp/test_decrypt_visibility_tools.py | sed -n '383,635p'" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
   383	    assert result["published_anonymous"] is True
   384	
   385	
   386	# ── set_session_visibility — Step 10b BLOCKER-3 schema-key assertions ──
   387	#
   388	# v2.0.0 pure-MCP migration (Team B) adds explicit MCP-side coverage for
   389	# ``set_session_visibility`` (the SESSION-level visibility tool, separate
   390	# from ``set_benchmark_visibility``).  Pins the response shape so a future
   391	# refactor cannot silently rename ``public_anonymous`` (output) to match
   392	# the input param name ``anonymous`` — a Codex-flagged schema-drift risk
   393	# captured in the V2_PURE_MCP_EXECUTION_PLAN Step 10b review.
   394	#
   395	# Tool spec:
   396	#   set_session_visibility(session_id, public, anonymous=True, api_key) → dict
   397	#   • input param: ``anonymous: bool`` (signals "anonymous attribution")
   398	#   • output field: ``public_anonymous: bool`` (matches SessionResponse)
   399	#
   400	# The four tests below cover the full publish / unpublish flag matrix
   401	# plus an anti-shape-drift guard that ``share_url`` does NOT appear in
   402	# the response (the dashboard / agent derives the share URL externally
   403	# as ``https://finlet.dev/sessions/{id}``).
   404	
   405	
   406	# Obviously-fake test fixtures — gitleaks-safe per Step 10b STRONG-3.
   407	SESSION_VISIBILITY_API_KEY = "fnlt_test_key_visibility"
   408	SESSION_VISIBILITY_USER_ID = "session-vis-user"
   409	
   410	# UUID-shaped session_id that passes ``validate_session_id`` regex BUT is
   411	# obviously a test fixture (14-character all-zeros payload, NOT a real
   412	# uuid4-generated value).
   413	SESSION_VISIBILITY_SESSION_ID = "00000000-0000-0000-0000-00000000bbbb"
   414	
   415	_SESSION_VISIBILITY_USER = UserRecord(
   416	    id=SESSION_VISIBILITY_USER_ID,
   417	    email="set-session-vis@finlet.dev",
   418	    tier=UserTier.FREE,
   419	    created_at=datetime(2024, 1, 1, tzinfo=timezone.utc),
   420	)
   421	
   422	_SESSION_VISIBILITY_BASE_TIME = datetime(2024, 1, 2, 14, 30, tzinfo=timezone.utc)
   423	
   424	
   425	def _mock_session_visibility_auth(monkeypatch: Any) -> None:
   426	    """Plant SESSION_VISIBILITY_API_KEY into a fake AuthService for MCP auth.
   427	
   428	    Mirrors the propagation pattern in
   429	    ``tests/mcp/test_session_lifecycle_blind.py::_mock_auth`` — the root
   430	    conftest's ``_legacy_api_key_test_shim`` patches the binding on
   431	    server / tools_portfolio / tools_trading / tools_benchmark but NOT
   432	    tools_session, which was added later (Public Session View, 2026-05-12).
   433	    Without this forward, ``set_session_visibility`` hits the Phase 4e
   434	    Bearer-only production rejection envelope.
   435	    """
   436	    _SESSION_VISIBILITY_USER.sessions_today = 0
   437	    _SESSION_VISIBILITY_USER.active_sessions = 0
   438	    fake_service = AuthService()
   439	    key_hash = hashlib.sha256(SESSION_VISIBILITY_API_KEY.encode()).hexdigest()
   440	    fake_service.insert_record(key_hash, _SESSION_VISIBILITY_USER)
   441	    monkeypatch.setattr("finlet.mcp.auth.auth_service", fake_service)
   442	    monkeypatch.setattr("finlet.auth.service.auth_service", fake_service)
   443	
   444	    from finlet.mcp import bearer_context as _bc
   445	
   446	    monkeypatch.setattr(
   447	        "finlet.mcp.tools_session.resolve_credential", _bc.resolve_credential
   448	    )
   449	
   450	
   451	def _make_visibility_session(
   452	    *,
   453	    user_id: str = SESSION_VISIBILITY_USER_ID,
   454	    session_id: str = SESSION_VISIBILITY_SESSION_ID,
   455	    public: bool = False,
   456	    anonymous: bool = True,
   457	) -> Session:
   458	    """Construct a non-blind session for set_session_visibility coverage.
   459	
   460	    Non-blind (``blind=False``) so the response passes through
   461	    :func:`session_response` with ``blind_mapping=None`` — owner-view
   462	    shape preserved, matches the Phase 4e Bearer-only contract.
   463	    """
   464	    config = SessionConfig(
   465	        start_time=_SESSION_VISIBILITY_BASE_TIME,
   466	        end_time=_SESSION_VISIBILITY_BASE_TIME + timedelta(days=30),
   467	        initial_capital=100_000.0,
   468	        universe=["AAPL", "MSFT"],
   469	        time_step="1d",
   470	        blind=False,
   471	        public=public,
   472	        public_anonymous=anonymous,
   473	    )
   474	    session = Session(
   475	        config,
   476	        session_id=session_id,
   477	        user_id=user_id,
   478	        name="visibility-test-session",
   479	    )
   480	    session.activate()
   481	    return session
   482	
   483	
   484	class TestMcpSetSessionVisibilitySchemaKeys:
   485	    """Pin v2.0.0 contract: response uses ``public_anonymous`` NOT ``anonymous``.
   486	
   487	    Step 10b BLOCKER-3 — the INPUT param is named ``anonymous`` but the
   488	    OUTPUT field on :class:`finlet.api.schemas.session.SessionResponse` is
   489	    ``public_anonymous``.  A reasonable-looking refactor that aliases the
   490	    response key to ``anonymous`` would drift the contract silently — these
   491	    tests catch that.
   492	    """
   493	
   494	    @pytest.mark.asyncio
   495	    async def test_publish_anonymous_emits_public_anonymous_true(
   496	        self, monkeypatch: pytest.MonkeyPatch
   497	    ) -> None:
   498	        """``public=True, anonymous=True`` → ``public AND public_anonymous`` both True."""
   499	        _mock_session_visibility_auth(monkeypatch)
   500	        sessions_map: dict[str, Session] = {}
   501	        monkeypatch.setattr("finlet.mcp.auth.get_sessions", lambda: sessions_map)
   502	        monkeypatch.setattr(
   503	            "finlet.api.services.session_service.persist_session", AsyncMock()
   504	        )
   505	
   506	        session = _make_visibility_session()
   507	        sessions_map[session.id] = session
   508	
   509	        result = await mcp_set_session_visibility(
   510	            session_id=session.id,
   511	            public=True,
   512	            anonymous=True,
   513	            api_key=SESSION_VISIBILITY_API_KEY,
   514	        )
   515	
   516	        assert "error" not in result, f"Unexpected error: {result}"
   517	        assert result["public"] is True
   518	        assert result["public_anonymous"] is True
   519	        # The INPUT param name ``anonymous`` must NOT appear as a top-level
   520	        # output key — the response schema field is ``public_anonymous``.
   521	        assert "anonymous" not in result, (
   522	            f"Response leaked INPUT param name ``anonymous`` as a top-level "
   523	            f"key — should be ``public_anonymous`` only (schema drift): {result}"
   524	        )
   525	
   526	    @pytest.mark.asyncio
   527	    async def test_publish_attributed_emits_public_anonymous_false(
   528	        self, monkeypatch: pytest.MonkeyPatch
   529	    ) -> None:
   530	        """``public=True, anonymous=False`` (attributed flow) → ``public_anonymous`` False."""
   531	        _mock_session_visibility_auth(monkeypatch)
   532	        sessions_map: dict[str, Session] = {}
   533	        monkeypatch.setattr("finlet.mcp.auth.get_sessions", lambda: sessions_map)
   534	        monkeypatch.setattr(
   535	            "finlet.api.services.session_service.persist_session", AsyncMock()
   536	        )
   537	
   538	        session = _make_visibility_session()
   539	        sessions_map[session.id] = session
   540	
   541	        result = await mcp_set_session_visibility(
   542	            session_id=session.id,
   543	            public=True,
   544	            anonymous=False,
   545	            api_key=SESSION_VISIBILITY_API_KEY,
   546	        )
   547	
   548	        assert "error" not in result, f"Unexpected error: {result}"
   549	        assert result["public"] is True
   550	        assert result["public_anonymous"] is False
   551	
   552	    @pytest.mark.asyncio
   553	    async def test_unpublish_default_anonymous_true(
   554	        self, monkeypatch: pytest.MonkeyPatch
   555	    ) -> None:
   556	        """``public=False, anonymous=True`` (unpublish flow per cli.py:692).
   557	
   558	        The CLI always passed ``anonymous=True`` on the dropped
   559	        ``finlet session unpublish`` path; agents now hit this directly
   560	        via MCP. ``public_anonymous`` should still surface in the
   561	        response as ``True`` (the anonymity preference is persisted even
   562	        when ``public=False`` so re-publishing later restores it).
   563	        """
   564	        _mock_session_visibility_auth(monkeypatch)
   565	        sessions_map: dict[str, Session] = {}
   566	        monkeypatch.setattr("finlet.mcp.auth.get_sessions", lambda: sessions_map)
   567	        monkeypatch.setattr(
   568	            "finlet.api.services.session_service.persist_session", AsyncMock()
   569	        )
   570	
   571	        # Seed the session pre-published so the unpublish path is
   572	        # semantically meaningful — set_visibility flips public=False
   573	        # on a previously-public session.
   574	        session = _make_visibility_session(public=True, anonymous=True)
   575	        sessions_map[session.id] = session
   576	
   577	        result = await mcp_set_session_visibility(
   578	            session_id=session.id,
   579	            public=False,
   580	            anonymous=True,
   581	            api_key=SESSION_VISIBILITY_API_KEY,
   582	        )
   583	
   584	        assert "error" not in result, f"Unexpected error: {result}"
   585	        assert result["public"] is False
   586	        assert result["public_anonymous"] is True
   587	
   588	    @pytest.mark.asyncio
   589	    async def test_response_does_not_include_share_url(
   590	        self, monkeypatch: pytest.MonkeyPatch
   591	    ) -> None:
   592	        """Anti-shape-drift: response MUST NOT include ``share_url``.
   593	
   594	        The dashboard / agent derives the public URL externally as
   595	        ``https://finlet.dev/sessions/{id}`` — embedding it in the MCP
   596	        response would couple the tool shape to the deployment URL and
   597	        violate the contract pinned in
   598	        :class:`finlet.api.schemas.session.SessionResponse`.  This
   599	        assertion locks the absence so a well-intentioned helper that
   600	        adds ``d["share_url"] = ...`` to ``session_response`` is caught
   601	        at PR time.
   602	        """
   603	        _mock_session_visibility_auth(monkeypatch)
   604	        sessions_map: dict[str, Session] = {}
   605	        monkeypatch.setattr("finlet.mcp.auth.get_sessions", lambda: sessions_map)
   606	        monkeypatch.setattr(
   607	            "finlet.api.services.session_service.persist_session", AsyncMock()
   608	        )
   609	
   610	        session = _make_visibility_session()
   611	        sessions_map[session.id] = session
   612	
   613	        result = await mcp_set_session_visibility(
   614	            session_id=session.id,
   615	            public=True,
   616	            anonymous=True,
   617	            api_key=SESSION_VISIBILITY_API_KEY,
   618	        )
   619	
   620	        assert "error" not in result, f"Unexpected error: {result}"
   621	        assert "share_url" not in result, (
   622	            f"Response leaked ``share_url`` key (shape-drift) — consumers "
   623	            f"derive the URL as ``https://finlet.dev/sessions/{{id}}`` "
   624	            f"externally; the MCP tool shape MUST NOT include it: {result}"
   625	        )
   626	
   627	
   628	# ── Tools registered for FastMCP discovery ──────────────────────
   629	
   630	
   631	def test_tools_registered_on_server() -> None:
   632	    """Verify both tools are importable from finlet.mcp.server (FastMCP discovery)."""
   633	    from finlet.mcp import server  # noqa: F401
   634	
   635	    assert hasattr(server, "decrypt_benchmark_run")

exec
/bin/zsh -lc "nl -ba /Users/justnau/finlet/finlet/api/schemas/session.py | sed -n '79,110p'" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
    79	class SessionResponse(BaseModel):
    80	    """Response for a single session (create, get, configure, complete).
    81	
    82	    ``created_at`` is typed ``str`` (not ``datetime``) so blind sessions
    83	    can return the literal ``"redacted"`` sentinel — the wall-clock
    84	    timestamp is a real information leak on blind sessions (agent + today
    85	    + Day_N → real ``config.start_time``), so the service layer
    86	    substitutes ``"redacted"`` for blind responses. Owner-view responses
    87	    still emit a real ISO-8601 timestamp. See Codex Team B P1 BLOCKER
    88	    fix (2026-05-22) in :func:`finlet.api.services.session_service.session_response`.
    89	    """
    90	
    91	    id: str
    92	    name: str
    93	    status: str
    94	    created_at: str
    95	    config: SessionConfigResponse
    96	    clock: ClockStateResponse
    97	    portfolio_metrics: PortfolioMetricsResponse
    98	    pending_orders: int
    99	    trace_count: int
   100	    public: bool = False
   101	    public_anonymous: bool = True
   102	    blind: bool = False
   103	
   104	
   105	class SessionDeleteResponse(BaseModel):
   106	    """Response for session deletion."""
   107	
   108	    status: str
   109	    id: str
   110	

exec
/bin/zsh -lc "nl -ba /Users/justnau/finlet/finlet/mcp/tools_session.py | sed -n '43,115p'" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
    43	@mcp.tool()
    44	@blind_error_mapper
    45	async def set_session_visibility(
    46	    session_id: str,
    47	    public: bool,
    48	    anonymous: bool = True,
    49	    api_key: str | None = None,
    50	) -> dict[str, Any]:
    51	    """Toggle a session's public-share visibility.
    52	
    53	    Args:
    54	        session_id: Session ID (required — no auto-resolve for safety).
    55	        public: ``True`` makes the session readable at
    56	            ``GET /v1/public/sessions/{id}/...`` without authentication.
    57	            ``False`` revokes public access.
    58	        anonymous: When ``public=True``, controls whether the public
    59	            response shows the literal name ``"Anonymous Finlet session"``
    60	            (``True`` — default) or the owner-supplied ``session.name``
    61	            (``False``).  Ignored display-wise when ``public=False``, but
    62	            still persisted so re-publishing later restores the
    63	            preference without an extra round-trip.
    64	        api_key: API key for authentication (OAuth Bearer preferred).
    65	
    66	    Returns the post-mutation session summary in the same shape as
    67	    ``get_session`` — owner-facing, NOT redacted.
    68	    """
    69	    auth = await resolve_credential(
    70	        "set_session_visibility",
    71	        _extract_bearer_from_context(),
    72	        api_key,
    73	    )
    74	    if isinstance(auth, dict):
    75	        return auth
    76	    user_id, _auth_method, claims = auth
    77	
    78	    user_record = _resolve_user_record(user_id)
    79	    if user_record is None:
    80	        return {"error": _AUTH_REQUIRED_MESSAGE}
    81	
    82	    # finlet:trade — visibility flip is a state mutation that changes the
    83	    # agent's external footprint.  Read-only OAuth clients should not be
    84	    # able to publish (or un-publish) sessions silently.
    85	    try:
    86	        enforce_scope(claims, "finlet:trade", user_record)
    87	    except ValueError as exc:
    88	        return {"error": str(exc)}
    89	
    90	    resolved = _resolve_session(session_id, user_id)
    91	    if isinstance(resolved, dict):
    92	        return resolved
    93	    session, _sid = resolved
    94	
    95	    await set_visibility(session, public=public, anonymous=anonymous)
    96	    # SESSION_LEVEL blind: wrap the post-mutation summary through the
    97	    # per-session blind_mapping so blind sessions emit opaque tickers +
    98	    # ``Day_N`` dates on the agent-facing surface. Non-blind sessions get
    99	    # ``None`` and pass through unchanged (preserves the owner-facing
   100	    # shape that REST routes consume).
   101	    return session_response(session, blind_mapping=_blind_mapping_for(session))

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet diff-tree --no-commit-id --name-status -r 014329f' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
D	tests/api/test_cli_mcp_client.py
M	tests/mcp/test_decrypt_visibility_tools.py
M	tests/test_cli.py
D	tests/test_cli_benchmark.py
M	tests/test_cli_help.py

exec
/bin/zsh -lc 'rg -n "''^(class |def test_|    def test_)" /Users/justnau/finlet/tests/test_cli.py /Users/justnau/finlet/tests/test_cli_help.py' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
/Users/justnau/finlet/tests/test_cli_help.py:50:class TestCliHelpFootered:
/Users/justnau/finlet/tests/test_cli_help.py:53:    def test_serve_help(self, home_sandbox):
/Users/justnau/finlet/tests/test_cli_help.py:58:    def test_register_help(self, home_sandbox):
/Users/justnau/finlet/tests/test_cli_help.py:63:    def test_plugins_subapp_help(self, home_sandbox):
/Users/justnau/finlet/tests/test_cli_help.py:68:    def test_auth_subapp_help(self, home_sandbox):
/Users/justnau/finlet/tests/test_cli_help.py:73:    def test_mcp_serve_help(self, home_sandbox):
/Users/justnau/finlet/tests/test_cli_help.py:78:    def test_manual_help(self, home_sandbox):
/Users/justnau/finlet/tests/test_cli.py:63:class TestRegisterCommand:
/Users/justnau/finlet/tests/test_cli.py:64:    def test_register_help(self):
/Users/justnau/finlet/tests/test_cli.py:71:    def test_register_success(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:85:    def test_register_duplicate_email(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:92:    def test_register_connection_error(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:98:    def test_register_requires_email(self):
/Users/justnau/finlet/tests/test_cli.py:107:class TestAuthLoginCommand:
/Users/justnau/finlet/tests/test_cli.py:108:    def test_auth_login_help(self):
/Users/justnau/finlet/tests/test_cli.py:117:    def test_auth_login_success(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:148:    def test_auth_login_mfa_required(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:176:    def test_auth_login_rate_limited(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:203:    def test_auth_login_invalid_credentials(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:230:    def test_auth_login_connection_error(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:243:class TestAuthStatusCommand:
/Users/justnau/finlet/tests/test_cli.py:250:    def test_auth_status_help(self):
/Users/justnau/finlet/tests/test_cli.py:256:    def test_auth_status_no_credentials_file(self, monkeypatch, tmp_path):
/Users/justnau/finlet/tests/test_cli.py:271:    def test_auth_status_logged_in_with_valid_token(self, monkeypatch, tmp_path):
/Users/justnau/finlet/tests/test_cli.py:300:    def test_auth_status_expired_token(self, monkeypatch, tmp_path):
/Users/justnau/finlet/tests/test_cli.py:329:    def test_auth_status_missing_expires_at(self, monkeypatch, tmp_path):
/Users/justnau/finlet/tests/test_cli.py:357:class TestPrintErrorEnvelope:
/Users/justnau/finlet/tests/test_cli.py:361:    def test_print_error_prefers_error_message(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:380:    def test_print_error_fallback_to_detail(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:391:    def test_print_error_handles_malformed_json(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:413:class TestPluginsListCommand:
/Users/justnau/finlet/tests/test_cli.py:422:    def test_plugins_list_reports_dashboard_plugin_set(self, mock_get: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:466:    def test_plugins_list_connection_error(self, mock_get: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:473:class TestPluginsAddCommand:
/Users/justnau/finlet/tests/test_cli.py:477:    def test_plugins_add_drops_restart_message_and_surfaces_live_status(
/Users/justnau/finlet/tests/test_cli.py:515:    def test_plugins_add_unhealthy_status(self, mock_put: MagicMock, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:539:    def test_plugins_add_server_unreachable_exits_one(self, mock_put: MagicMock, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:547:    def test_plugins_add_unknown_plugin_returns_404(self, mock_put: MagicMock, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:556:    def test_plugins_add_missing_api_key_exits_two(self, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:565:    def test_plugins_list_uses_server_side_configured_marker(self, mock_get: MagicMock, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:592:class TestPluginsRemoveCommand:
/Users/justnau/finlet/tests/test_cli.py:594:    def test_plugins_remove_happy_path_surfaces_unhealthy_status(
/Users/justnau/finlet/tests/test_cli.py:629:    def test_plugins_remove_missing_api_key_exits_two(self, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:638:    def test_plugins_remove_network_failure_returns_exit_one(self, mock_put: MagicMock, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:646:    def test_plugins_remove_auth_rejected_returns_exit_one(self, mock_put: MagicMock, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:657:class TestTopLevelCommands:
/Users/justnau/finlet/tests/test_cli.py:665:    def test_all_commands_registered(self):
/Users/justnau/finlet/tests/test_cli.py:673:    def test_dropped_agentic_commands_not_registered(self):
/Users/justnau/finlet/tests/test_cli.py:696:    def test_mcp_serve_subcommand_registered(self):
/Users/justnau/finlet/tests/test_cli.py:703:    def test_legacy_finlet_mcp_no_longer_top_level(self):
/Users/justnau/finlet/tests/test_cli.py:724:class TestRootFlags:
/Users/justnau/finlet/tests/test_cli.py:734:    def test_version_flag_prints_version_and_exits_zero(self) -> None:
/Users/justnau/finlet/tests/test_cli.py:749:    def test_help_lists_version_flag(self) -> None:

codex
The commit only changes the five allowed test paths. The new MCP tests do hit `public_anonymous` and avoid `anonymous`, so I’m now checking the subtler coverage lens: whether trimming removed tests for commands that survived the CLI cutover.
exec
/bin/zsh -lc 'rg -n "manual|serve|mcp|version|callback|auth|plugins|register|session|advance|order|portfolio|status|benchmark" /Users/justnau/finlet/tests/test_cli.py /Users/justnau/finlet/tests/test_cli_help.py' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
/Users/justnau/finlet/tests/test_cli_help.py:8:``tests/test_cli_oauth_login.py:494-498``.
/Users/justnau/finlet/tests/test_cli_help.py:11:commands (``advance`` / ``order`` / ``portfolio`` / ``status`` /
/Users/justnau/finlet/tests/test_cli_help.py:12:``session``) — agents now drive Finlet through the MCP surface. The
/Users/justnau/finlet/tests/test_cli_help.py:16:* ``serve`` — see ``finlet manual transports``
/Users/justnau/finlet/tests/test_cli_help.py:17:* ``register`` — see ``finlet manual auth-model``
/Users/justnau/finlet/tests/test_cli_help.py:18:* ``plugins`` (sub-app help) — see ``finlet manual plugin-matrix``
/Users/justnau/finlet/tests/test_cli_help.py:19:* ``auth`` (sub-app help) — see ``finlet manual auth-model``
/Users/justnau/finlet/tests/test_cli_help.py:20:* ``mcp serve`` — see ``finlet manual transports``
/Users/justnau/finlet/tests/test_cli_help.py:21:* ``manual`` — offline manual viewer (no footer; self-documenting)
/Users/justnau/finlet/tests/test_cli_help.py:38:    Mirrors the fixture in ``tests/test_cli_oauth_login.py`` — invoking
/Users/justnau/finlet/tests/test_cli_help.py:39:    ``--help`` on auth-aware commands triggers credential-path expansion;
/Users/justnau/finlet/tests/test_cli_help.py:53:    def test_serve_help(self, home_sandbox):
/Users/justnau/finlet/tests/test_cli_help.py:54:        """``finlet serve --help`` works (subcommand registered)."""
/Users/justnau/finlet/tests/test_cli_help.py:55:        result = runner.invoke(app, ["serve", "--help"])
/Users/justnau/finlet/tests/test_cli_help.py:58:    def test_register_help(self, home_sandbox):
/Users/justnau/finlet/tests/test_cli_help.py:59:        """``finlet register --help`` works (subcommand registered)."""
/Users/justnau/finlet/tests/test_cli_help.py:60:        result = runner.invoke(app, ["register", "--help"])
/Users/justnau/finlet/tests/test_cli_help.py:63:    def test_plugins_subapp_help(self, home_sandbox):
/Users/justnau/finlet/tests/test_cli_help.py:64:        """``finlet plugins --help`` works (sub-app registered)."""
/Users/justnau/finlet/tests/test_cli_help.py:65:        result = runner.invoke(app, ["plugins", "--help"])
/Users/justnau/finlet/tests/test_cli_help.py:68:    def test_auth_subapp_help(self, home_sandbox):
/Users/justnau/finlet/tests/test_cli_help.py:69:        """``finlet auth --help`` works (sub-app registered)."""
/Users/justnau/finlet/tests/test_cli_help.py:70:        result = runner.invoke(app, ["auth", "--help"])
/Users/justnau/finlet/tests/test_cli_help.py:73:    def test_mcp_serve_help(self, home_sandbox):
/Users/justnau/finlet/tests/test_cli_help.py:74:        """``finlet mcp serve --help`` works (subcommand registered)."""
/Users/justnau/finlet/tests/test_cli_help.py:75:        result = runner.invoke(app, ["mcp", "serve", "--help"])
/Users/justnau/finlet/tests/test_cli_help.py:78:    def test_manual_help(self, home_sandbox):
/Users/justnau/finlet/tests/test_cli_help.py:79:        """``finlet manual --help`` works (subcommand registered)."""
/Users/justnau/finlet/tests/test_cli_help.py:80:        result = runner.invoke(app, ["manual", "--help"])
/Users/justnau/finlet/tests/test_cli.py:6:* ``serve`` (REST/MCP server bootstrap)
/Users/justnau/finlet/tests/test_cli.py:7:* ``register`` (one-shot account creation, calls REST)
/Users/justnau/finlet/tests/test_cli.py:8:* ``manual`` (offline manual viewer, no I/O)
/Users/justnau/finlet/tests/test_cli.py:9:* sub-app ``plugins`` — ``list`` / ``add`` / ``remove`` (operator plugin admin)
/Users/justnau/finlet/tests/test_cli.py:10:* sub-app ``auth`` — ``login`` / ``logout`` / ``status`` (OAuth credential mgmt)
/Users/justnau/finlet/tests/test_cli.py:11:* sub-app ``mcp`` — ``serve`` (run MCP server over stdio)
/Users/justnau/finlet/tests/test_cli.py:13:All agentic-trading commands (``session create/list/delete/publish``,
/Users/justnau/finlet/tests/test_cli.py:14:``advance``, ``order``, ``portfolio``, ``status``, ``benchmark *``) were
/Users/justnau/finlet/tests/test_cli.py:22:file alongside ``finlet/cli_mcp_client.py``. The MCP-side coverage for
/Users/justnau/finlet/tests/test_cli.py:23:the dropped commands lives in ``tests/mcp/*``.
/Users/justnau/finlet/tests/test_cli.py:44:def _mock_response(status_code: int = 200, json_data: dict | None = None, text: str = "") -> MagicMock:
/Users/justnau/finlet/tests/test_cli.py:47:    resp.status_code = status_code
/Users/justnau/finlet/tests/test_cli.py:50:    resp.raise_for_status = MagicMock()
/Users/justnau/finlet/tests/test_cli.py:51:    if status_code >= 400:
/Users/justnau/finlet/tests/test_cli.py:52:        resp.raise_for_status.side_effect = httpx.HTTPStatusError(
/Users/justnau/finlet/tests/test_cli.py:53:            message=f"HTTP {status_code}",
/Users/justnau/finlet/tests/test_cli.py:60:# ─── register ────────────────────────────────────────────────────────
/Users/justnau/finlet/tests/test_cli.py:64:    def test_register_help(self):
/Users/justnau/finlet/tests/test_cli.py:66:        result = runner.invoke(app, ["register", "--help"])
/Users/justnau/finlet/tests/test_cli.py:71:    def test_register_success(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:79:        result = runner.invoke(app, ["register", "--email", "test@example.com"])
/Users/justnau/finlet/tests/test_cli.py:85:    def test_register_duplicate_email(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:86:        mock_post.return_value = _mock_response(409, {"detail": "Email already registered"})
/Users/justnau/finlet/tests/test_cli.py:87:        result = runner.invoke(app, ["register", "--email", "dupe@example.com"])
/Users/justnau/finlet/tests/test_cli.py:89:        assert "Email already registered" in result.output
/Users/justnau/finlet/tests/test_cli.py:92:    def test_register_connection_error(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:94:        result = runner.invoke(app, ["register", "--email", "test@example.com"])
/Users/justnau/finlet/tests/test_cli.py:98:    def test_register_requires_email(self):
/Users/justnau/finlet/tests/test_cli.py:100:        result = runner.invoke(app, ["register"])
/Users/justnau/finlet/tests/test_cli.py:104:# ─── auth login ─────────────────────────────────────────────────────
/Users/justnau/finlet/tests/test_cli.py:108:    def test_auth_login_help(self):
/Users/justnau/finlet/tests/test_cli.py:109:        """``finlet auth login --help`` exposes --email/-e and --password/-p."""
/Users/justnau/finlet/tests/test_cli.py:110:        result = runner.invoke(app, ["auth", "login", "--help"])
/Users/justnau/finlet/tests/test_cli.py:117:    def test_auth_login_success(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:132:                "auth",
/Users/justnau/finlet/tests/test_cli.py:148:    def test_auth_login_mfa_required(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:155:                "mfa_session": "mfa-token-abc",
/Users/justnau/finlet/tests/test_cli.py:162:                "auth",
/Users/justnau/finlet/tests/test_cli.py:176:    def test_auth_login_rate_limited(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:191:                "auth",
/Users/justnau/finlet/tests/test_cli.py:203:    def test_auth_login_invalid_credentials(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:209:                    "code": "unauthorized",
/Users/justnau/finlet/tests/test_cli.py:218:                "auth",
/Users/justnau/finlet/tests/test_cli.py:230:    def test_auth_login_connection_error(self, mock_post: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:234:            ["auth", "login", "--email", "user@example.com", "--password", "x"],
/Users/justnau/finlet/tests/test_cli.py:240:# ─── auth status ────────────────────────────────────────────────────
/Users/justnau/finlet/tests/test_cli.py:244:    """``finlet auth status`` reads ``~/.finlet/credentials`` and reports state.
/Users/justnau/finlet/tests/test_cli.py:246:    Purely local check — does NOT ping the server. Used as a quick
/Users/justnau/finlet/tests/test_cli.py:247:    "am I logged in?" pre-flight before running authenticated commands.
/Users/justnau/finlet/tests/test_cli.py:250:    def test_auth_status_help(self):
/Users/justnau/finlet/tests/test_cli.py:251:        """``finlet auth status --help`` is registered as a subcommand."""
/Users/justnau/finlet/tests/test_cli.py:252:        result = runner.invoke(app, ["auth", "status", "--help"])
/Users/justnau/finlet/tests/test_cli.py:254:        assert "status" in _strip_ansi(result.output).lower()
/Users/justnau/finlet/tests/test_cli.py:256:    def test_auth_status_no_credentials_file(self, monkeypatch, tmp_path):
/Users/justnau/finlet/tests/test_cli.py:259:        Pre-v1.0.4 this asserted exit 1; F-3 promoted auth-failure paths
/Users/justnau/finlet/tests/test_cli.py:261:        authenticated" distinctly from other CLI errors.
/Users/justnau/finlet/tests/test_cli.py:266:        result = runner.invoke(app, ["auth", "status"])
/Users/justnau/finlet/tests/test_cli.py:269:        assert "finlet auth login" in result.output
/Users/justnau/finlet/tests/test_cli.py:271:    def test_auth_status_logged_in_with_valid_token(self, monkeypatch, tmp_path):
/Users/justnau/finlet/tests/test_cli.py:291:        result = runner.invoke(app, ["auth", "status"])
/Users/justnau/finlet/tests/test_cli.py:300:    def test_auth_status_expired_token(self, monkeypatch, tmp_path):
/Users/justnau/finlet/tests/test_cli.py:324:        result = runner.invoke(app, ["auth", "status"])
/Users/justnau/finlet/tests/test_cli.py:327:        assert "finlet auth login" in result.output
/Users/justnau/finlet/tests/test_cli.py:329:    def test_auth_status_missing_expires_at(self, monkeypatch, tmp_path):
/Users/justnau/finlet/tests/test_cli.py:349:        result = runner.invoke(app, ["auth", "status"])
/Users/justnau/finlet/tests/test_cli.py:374:        result = runner.invoke(app, ["register", "--email", "x@example.com"])
/Users/justnau/finlet/tests/test_cli.py:386:        result = runner.invoke(app, ["register", "--email", "x@example.com"])
/Users/justnau/finlet/tests/test_cli.py:394:        resp.status_code = 500
/Users/justnau/finlet/tests/test_cli.py:396:        resp.text = "raw-server-error-text"
/Users/justnau/finlet/tests/test_cli.py:397:        resp.raise_for_status = MagicMock(
/Users/justnau/finlet/tests/test_cli.py:405:        result = runner.invoke(app, ["register", "--email", "x@example.com"])
/Users/justnau/finlet/tests/test_cli.py:407:        assert "raw-server-error-text" in result.output
/Users/justnau/finlet/tests/test_cli.py:410:# ─── plugins list/add/remove ─────────────────────────────────────────
/Users/justnau/finlet/tests/test_cli.py:414:    """``finlet plugins list`` continues to call REST (not MCP-migrated).
/Users/justnau/finlet/tests/test_cli.py:417:    trading surface MCP tools expose. See ``docs/decisions/cli-mcp-stdio-auth.md``
/Users/justnau/finlet/tests/test_cli.py:422:    def test_plugins_list_reports_dashboard_plugin_set(self, mock_get: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:423:        """CLI must report the same 8-plugin set + statuses the API does."""
/Users/justnau/finlet/tests/test_cli.py:425:            {"name": "price", "type": "price", "status": "healthy", "message": ""},
/Users/justnau/finlet/tests/test_cli.py:429:                "status": "healthy",
/Users/justnau/finlet/tests/test_cli.py:432:            {"name": "news_s3", "type": "news", "status": "healthy", "message": ""},
/Users/justnau/finlet/tests/test_cli.py:433:            {"name": "sentiment", "type": "sentiment", "status": "healthy", "message": ""},
/Users/justnau/finlet/tests/test_cli.py:437:                "status": "degraded",
/Users/justnau/finlet/tests/test_cli.py:440:            {"name": "fred", "type": "economic", "status": "healthy", "message": ""},
/Users/justnau/finlet/tests/test_cli.py:441:            {"name": "econ", "type": "economic", "status": "degraded", "message": ""},
/Users/justnau/finlet/tests/test_cli.py:442:            {"name": "edgar", "type": "filings", "status": "unhealthy", "message": "503"},
/Users/justnau/finlet/tests/test_cli.py:444:        settings_payload = {"plugins": {}}
/Users/justnau/finlet/tests/test_cli.py:447:            if url.endswith("/v1/plugins/health"):
/Users/justnau/finlet/tests/test_cli.py:449:            if url.endswith("/v1/settings/plugins"):
/Users/justnau/finlet/tests/test_cli.py:455:        result = runner.invoke(app, ["plugins", "list", "--api-key", "fk_test"])
/Users/justnau/finlet/tests/test_cli.py:460:            assert p["status"] in output
/Users/justnau/finlet/tests/test_cli.py:463:        assert any(u.endswith("/v1/plugins/health") for u in called_urls), called_urls
/Users/justnau/finlet/tests/test_cli.py:466:    def test_plugins_list_connection_error(self, mock_get: MagicMock):
/Users/justnau/finlet/tests/test_cli.py:468:        result = runner.invoke(app, ["plugins", "list"])
/Users/justnau/finlet/tests/test_cli.py:477:    def test_plugins_add_drops_restart_message_and_surfaces_live_status(
/Users/justnau/finlet/tests/test_cli.py:484:                "status": "updated",
/Users/justnau/finlet/tests/test_cli.py:489:                    "status": "healthy",
/Users/justnau/finlet/tests/test_cli.py:498:        result = runner.invoke(app, ["plugins", "add", "edgar", "--email", "x@y.com"])
/Users/justnau/finlet/tests/test_cli.py:501:        assert "Restart server" not in out
/Users/justnau/finlet/tests/test_cli.py:505:        assert called_url.endswith("/v1/settings/plugins"), called_url
/Users/justnau/finlet/tests/test_cli.py:512:        assert not (tmp_path / "plugins.json").exists()
/Users/justnau/finlet/tests/test_cli.py:515:    def test_plugins_add_unhealthy_status(self, mock_put: MagicMock, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:520:                "status": "unhealthy",
/Users/justnau/finlet/tests/test_cli.py:525:                    "status": "unhealthy",
/Users/justnau/finlet/tests/test_cli.py:534:        result = runner.invoke(app, ["plugins", "add", "edgar"])
/Users/justnau/finlet/tests/test_cli.py:539:    def test_plugins_add_server_unreachable_exits_one(self, mock_put: MagicMock, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:542:        result = runner.invoke(app, ["plugins", "add", "edgar", "--email", "x@y.com"])
/Users/justnau/finlet/tests/test_cli.py:547:    def test_plugins_add_unknown_plugin_returns_404(self, mock_put: MagicMock, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:550:            404, {"detail": "No plugin named 'edger' is registered."}
/Users/justnau/finlet/tests/test_cli.py:552:        result = runner.invoke(app, ["plugins", "add", "edger", "--email", "x@y.com"])
/Users/justnau/finlet/tests/test_cli.py:556:    def test_plugins_add_missing_api_key_exits_two(self, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:558:        result = runner.invoke(app, ["plugins", "add", "edgar", "--email", "x@y.com"])
/Users/justnau/finlet/tests/test_cli.py:565:    def test_plugins_list_uses_server_side_configured_marker(self, mock_get: MagicMock, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:568:            {"name": "finnhub", "type": "fundamentals", "status": "healthy", "message": ""},
/Users/justnau/finlet/tests/test_cli.py:569:            {"name": "edgar", "type": "filings", "status": "unhealthy", "message": "no identity"},
/Users/justnau/finlet/tests/test_cli.py:571:        settings_payload = {"plugins": {"finnhub": {"api_key": "abcd...", "enabled": True}}}
/Users/justnau/finlet/tests/test_cli.py:574:            if url.endswith("/v1/plugins/health"):
/Users/justnau/finlet/tests/test_cli.py:576:            if url.endswith("/v1/settings/plugins"):
/Users/justnau/finlet/tests/test_cli.py:581:        result = runner.invoke(app, ["plugins", "list"])
/Users/justnau/finlet/tests/test_cli.py:594:    def test_plugins_remove_happy_path_surfaces_unhealthy_status(
/Users/justnau/finlet/tests/test_cli.py:601:                "status": "unhealthy",
/Users/justnau/finlet/tests/test_cli.py:606:                    "status": "unhealthy",
/Users/justnau/finlet/tests/test_cli.py:615:        result = runner.invoke(app, ["plugins", "remove", "edgar"])
/Users/justnau/finlet/tests/test_cli.py:618:        assert "Plugin 'edgar' status: unhealthy" in out
/Users/justnau/finlet/tests/test_cli.py:620:        assert called_url.endswith("/v1/settings/plugins"), called_url
/Users/justnau/finlet/tests/test_cli.py:629:    def test_plugins_remove_missing_api_key_exits_two(self, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:631:        result = runner.invoke(app, ["plugins", "remove", "edgar"])
/Users/justnau/finlet/tests/test_cli.py:638:    def test_plugins_remove_network_failure_returns_exit_one(self, mock_put: MagicMock, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:641:        result = runner.invoke(app, ["plugins", "remove", "edgar"])
/Users/justnau/finlet/tests/test_cli.py:646:    def test_plugins_remove_auth_rejected_returns_exit_one(self, mock_put: MagicMock, monkeypatch):
/Users/justnau/finlet/tests/test_cli.py:649:        result = runner.invoke(app, ["plugins", "remove", "edgar"])
/Users/justnau/finlet/tests/test_cli.py:660:    All agentic-trading commands (``session``, ``advance``, ``order``,
/Users/justnau/finlet/tests/test_cli.py:661:    ``portfolio``, ``status``, ``benchmark``) were removed in the v2.0.0
/Users/justnau/finlet/tests/test_cli.py:665:    def test_all_commands_registered(self):
/Users/justnau/finlet/tests/test_cli.py:670:        for cmd in ("serve", "register", "manual", "plugins", "auth", "mcp"):
/Users/justnau/finlet/tests/test_cli.py:673:    def test_dropped_agentic_commands_not_registered(self):
/Users/justnau/finlet/tests/test_cli.py:676:        Agents now invoke the MCP tools directly (``mcp__finlet__*`` namespace);
/Users/justnau/finlet/tests/test_cli.py:684:        # session create/list/delete/publish, advance, order, portfolio,
/Users/justnau/finlet/tests/test_cli.py:685:        # status, benchmark — these are top-level command names; the
/Users/justnau/finlet/tests/test_cli.py:690:        for dropped in (" advance ", " order ", " portfolio ", " status ", " benchmark ", " session "):
/Users/justnau/finlet/tests/test_cli.py:696:    def test_mcp_serve_subcommand_registered(self):
/Users/justnau/finlet/tests/test_cli.py:697:        """``finlet mcp serve`` is the new entry point (renamed from ``finlet mcp``)."""
/Users/justnau/finlet/tests/test_cli.py:698:        result = runner.invoke(app, ["mcp", "--help"])
/Users/justnau/finlet/tests/test_cli.py:701:        assert "serve" in output
/Users/justnau/finlet/tests/test_cli.py:703:    def test_legacy_finlet_mcp_no_longer_top_level(self):
/Users/justnau/finlet/tests/test_cli.py:704:        """``finlet mcp`` (no subcommand) is now a Typer group, not a leaf command.
/Users/justnau/finlet/tests/test_cli.py:706:        Phase 5 moved the previous leaf ``mcp`` command under ``mcp serve``.
/Users/justnau/finlet/tests/test_cli.py:707:        Calling ``finlet mcp`` with no subcommand should fail (exit non-zero)
/Users/justnau/finlet/tests/test_cli.py:708:        with a "missing command" message rather than starting the server.
/Users/justnau/finlet/tests/test_cli.py:710:        result = runner.invoke(app, ["mcp"], catch_exceptions=False)
/Users/justnau/finlet/tests/test_cli.py:713:        # server" — exit code is non-zero AND the help message mentions the
/Users/justnau/finlet/tests/test_cli.py:717:        # Should reference "finlet mcp" (the group) in the help / error path.
/Users/justnau/finlet/tests/test_cli.py:718:        assert "finlet mcp" in output or "Missing command" in output or "command" in output.lower()
/Users/justnau/finlet/tests/test_cli.py:727:    F-2 of the v1.0.3 blind walk surfaced that ``finlet --version``
/Users/justnau/finlet/tests/test_cli.py:729:    it through an eager callback that reads
/Users/justnau/finlet/tests/test_cli.py:730:    :func:`importlib.metadata.version` so the published wheel metadata
/Users/justnau/finlet/tests/test_cli.py:734:    def test_version_flag_prints_version_and_exits_zero(self) -> None:
/Users/justnau/finlet/tests/test_cli.py:735:        """``finlet --version`` prints the installed version and exits 0.
/Users/justnau/finlet/tests/test_cli.py:738:        :mod:`importlib.metadata` resolves the version against the dev
/Users/justnau/finlet/tests/test_cli.py:741:        version-bump cadence (otherwise every patch release would need
/Users/justnau/finlet/tests/test_cli.py:744:        result = runner.invoke(app, ["--version"])
/Users/justnau/finlet/tests/test_cli.py:746:        # Output should contain at least one digit (a version number).
/Users/justnau/finlet/tests/test_cli.py:749:    def test_help_lists_version_flag(self) -> None:
/Users/justnau/finlet/tests/test_cli.py:750:        """``finlet --help`` exits cleanly with the ``--version`` option registered.
/Users/justnau/finlet/tests/test_cli.py:752:        The literal ``--version`` substring is intentionally NOT asserted:
/Users/justnau/finlet/tests/test_cli.py:757:        :meth:`test_version_flag_prints_version_and_exits_zero`; this
/Users/justnau/finlet/tests/test_cli.py:759:        ``--version`` callback breaks ``--help`` rendering altogether.

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet show 014329f''^:tests/test_cli.py | rg -n "''^(class |    def test_)|manual|serve|mcp|version|root|callback"' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
5:* **KEEP commands** (``serve``, ``register``, ``auth login``, ``auth logout``,
10:  ``portfolio``, ``status``) dispatch through ``finlet.cli_mcp_client``.  Their
11:  tests mock :func:`finlet.cli_mcp_client.call_tool_sync` so the test stays
15:exercise the real subprocess + live server end-to-end.
29:from finlet.cli_mcp_client import MCPDispatchError
58:class TestSessionCommandsViaMCP:
61:    def test_session_subcommands_registered(self):
70:    def test_session_delete_requires_argument(self):
76:    def test_session_create_dispatches_create_session_tool(self, mock_call: MagicMock) -> None:
109:    def test_session_create_universe_split(self, mock_call: MagicMock) -> None:
138:    def test_session_create_blind_cli_does_not_echo_real_tickers(
188:    def test_session_create_non_blind_universe_uses_response_config(
221:    def test_session_create_falls_back_to_local_universe_if_response_omits(
226:        Protects the non-blind UX in case an older server build doesn't echo the
228:        blind server contract always includes ``universe`` with opaque ids.
259:    def test_session_create_json_mode(self, mock_call: MagicMock) -> None:
274:    def test_session_create_blind_flag_forwarded_to_mcp_tool(
323:    def test_session_create_no_blind_flag_defaults_to_false(
365:    def test_session_list_renders_human_output(self, mock_call: MagicMock) -> None:
385:    def test_session_list_empty(self, mock_call: MagicMock) -> None:
393:    def test_session_list_error_envelope_exits(self, mock_call: MagicMock) -> None:
410:    def test_session_list_api_key_sunset_envelope_exits_auth(self, mock_call: MagicMock) -> None:
427:    def test_session_delete_dispatches_delete_session_tool(self, mock_call: MagicMock) -> None:
441:    def test_session_publish_dispatches_set_session_visibility_tool(
464:    def test_session_publish_attributed_flag(self, mock_call: MagicMock) -> None:
482:    def test_session_publish_unpublish_flag(self, mock_call: MagicMock) -> None:
500:    def test_session_publish_json_mode(self, mock_call: MagicMock) -> None:
520:    def test_dispatch_failure_exits(self, mock_call: MagicMock) -> None:
523:            "Cannot connect to Finlet MCP at https://finlet.dev/mcp: refused"
530:    def test_dispatch_timeout_friendly_error(self, mock_call: MagicMock) -> None:
536:        site in `_dispatch_mcp_tool` converts the timeout into:
569:    def test_dispatch_builtin_timeout_also_caught(self, mock_call: MagicMock) -> None:
578:class TestBenchmarkVisibilityCommandsViaMCP:
582:    def test_benchmark_decrypt_dispatches_decrypt_tool(
603:    def test_benchmark_visibility_publish_default_anonymous(
628:    def test_benchmark_visibility_attributed_flag(
653:    def test_benchmark_visibility_unpublish_flag(
679:    def test_benchmark_visibility_json_mode_emits_envelope(
705:class TestAdvanceCommandViaMCP:
708:    def test_advance_help_carries_session_flag(self):
717:    def test_advance_default_one_step(self, mock_call: MagicMock) -> None:
734:    def test_advance_days_passes_steps(self, mock_call: MagicMock) -> None:
750:    def test_advance_to_passes_target_date(self, mock_call: MagicMock) -> None:
765:    def test_advance_days_and_to_mutually_exclusive(self):
784:    def test_advance_to_invalid_format(self):
793:    def test_advance_requires_session(self):
799:class TestOrderCommandViaMCP:
802:    def test_order_help(self):
821:    def test_order_market_buy_dispatches_submit_order(self, mock_call: MagicMock) -> None:
857:    def test_order_limit_passes_limit_price(self, mock_call: MagicMock) -> None:
887:    def test_order_with_reasoning_forwards_field(self, mock_call: MagicMock) -> None:
911:    def test_order_limit_requires_price_client_side(self):
936:    def test_order_stop_requires_price_client_side(self):
961:    def test_order_market_with_limit_price_rejected(self):
988:class TestPortfolioCommandViaMCP:
991:    def test_portfolio_help(self):
997:    def test_portfolio_with_positions_plain_text(self, mock_call: MagicMock) -> None:
1037:    def test_portfolio_empty_positions(self, mock_call: MagicMock) -> None:
1061:    def test_portfolio_error_envelope_exits(self, mock_call: MagicMock) -> None:
1067:    def test_portfolio_requires_session(self):
1072:class TestStatusCommandViaMCP:
1075:    def test_status_help(self):
1081:    def test_status_renders_human_output(self, mock_call: MagicMock) -> None:
1104:    def test_status_empty_universe_omits_line(self, mock_call: MagicMock) -> None:
1118:    def test_status_error_envelope_exits(self, mock_call: MagicMock) -> None:
1128:class TestRegisterCommand:
1129:    def test_register_help(self):
1136:    def test_register_success(self, mock_post: MagicMock):
1150:    def test_register_duplicate_email(self, mock_post: MagicMock):
1157:    def test_register_connection_error(self, mock_post: MagicMock):
1163:    def test_register_requires_email(self):
1169:class TestAuthLoginCommand:
1170:    def test_auth_login_help(self):
1179:    def test_auth_login_success(self, mock_post: MagicMock):
1210:    def test_auth_login_mfa_required(self, mock_post: MagicMock):
1238:    def test_auth_login_rate_limited(self, mock_post: MagicMock):
1265:    def test_auth_login_invalid_credentials(self, mock_post: MagicMock):
1292:    def test_auth_login_connection_error(self, mock_post: MagicMock):
1302:class TestAuthStatusCommand:
1305:    Purely local check — does NOT ping the server. Used as a quick
1309:    def test_auth_status_help(self):
1315:    def test_auth_status_no_credentials_file(self, monkeypatch, tmp_path):
1330:    def test_auth_status_logged_in_with_valid_token(self, monkeypatch, tmp_path):
1359:    def test_auth_status_expired_token(self, monkeypatch, tmp_path):
1388:    def test_auth_status_missing_expires_at(self, monkeypatch, tmp_path):
1413:class TestPrintErrorEnvelope:
1417:    def test_print_error_prefers_error_message(self, mock_post: MagicMock):
1436:    def test_print_error_fallback_to_detail(self, mock_post: MagicMock):
1447:    def test_print_error_handles_malformed_json(self, mock_post: MagicMock):
1452:        resp.text = "raw-server-error-text"
1463:        assert "raw-server-error-text" in result.output
1466:class TestPluginsListCommand:
1470:    trading surface MCP tools expose. See ``docs/decisions/cli-mcp-stdio-auth.md``
1475:    def test_plugins_list_reports_dashboard_plugin_set(self, mock_get: MagicMock):
1519:    def test_plugins_list_connection_error(self, mock_get: MagicMock):
1526:class TestPluginsAddCommand:
1530:    def test_plugins_add_drops_restart_message_and_surfaces_live_status(
1554:        assert "Restart server" not in out
1568:    def test_plugins_add_unhealthy_status(self, mock_put: MagicMock, monkeypatch):
1592:    def test_plugins_add_server_unreachable_exits_one(self, mock_put: MagicMock, monkeypatch):
1600:    def test_plugins_add_unknown_plugin_returns_404(self, mock_put: MagicMock, monkeypatch):
1609:    def test_plugins_add_missing_api_key_exits_two(self, monkeypatch):
1618:    def test_plugins_list_uses_server_side_configured_marker(self, mock_get: MagicMock, monkeypatch):
1645:class TestPluginsRemoveCommand:
1647:    def test_plugins_remove_happy_path_surfaces_unhealthy_status(
1682:    def test_plugins_remove_missing_api_key_exits_two(self, monkeypatch):
1691:    def test_plugins_remove_network_failure_returns_exit_one(self, mock_put: MagicMock, monkeypatch):
1699:    def test_plugins_remove_auth_rejected_returns_exit_one(self, mock_put: MagicMock, monkeypatch):
1710:class TestTopLevelCommands:
1711:    def test_all_commands_registered(self):
1716:        for cmd in ("register", "advance", "order", "portfolio", "status", "session", "plugins", "auth", "mcp"):
1719:    def test_mcp_serve_subcommand_registered(self):
1720:        """``finlet mcp serve`` is the new entry point (renamed from ``finlet mcp``)."""
1721:        result = runner.invoke(app, ["mcp", "--help"])
1724:        assert "serve" in output
1726:    def test_legacy_finlet_mcp_no_longer_top_level(self):
1727:        """``finlet mcp`` (no subcommand) is now a Typer group, not a leaf command.
1729:        Phase 5 moved the previous leaf ``mcp`` command under ``mcp serve``.
1730:        Calling ``finlet mcp`` with no subcommand should fail (exit non-zero)
1731:        with a "missing command" message rather than starting the server.
1733:        result = runner.invoke(app, ["mcp"], catch_exceptions=False)
1736:        # server" — exit code is non-zero AND the help message mentions the
1740:        # Should reference "finlet mcp" (the group) in the help / error path.
1741:        assert "finlet mcp" in output or "Missing command" in output or "command" in output.lower()
1744:# ─── _translate_mcp_error helper ────────────────────────────────────
1747:class TestTranslateMcpError:
1750:    def test_string_error(self):
1751:        from finlet.cli import _translate_mcp_error
1753:        assert _translate_mcp_error({"error": "boom"}) == "boom"
1755:    def test_no_error(self):
1756:        from finlet.cli import _translate_mcp_error
1758:        assert _translate_mcp_error({"id": "sid", "name": "Alpha"}) is None
1760:    def test_dict_error_with_message(self):
1761:        from finlet.cli import _translate_mcp_error
1764:        assert _translate_mcp_error(envelope) == "human-readable"
1766:    def test_dict_error_no_message(self):
1767:        from finlet.cli import _translate_mcp_error
1771:        result = _translate_mcp_error(envelope)
1779:class TestResolveBearerToken:
1782:    def test_explicit_api_key_wins(self):
1787:    def test_returns_none_when_no_credentials(self, monkeypatch, tmp_path):
1795:    def test_loads_credentials_file(self, monkeypatch, tmp_path):
1828:    def test_resolve_bearer_token_not_expired_returns_existing(
1870:    def test_resolve_bearer_token_expired_refreshes_and_writes(
1929:        assert data.get("resource") == "https://finlet.dev/mcp"
1939:    def test_resolve_bearer_token_refresh_400_returns_none(
1988:    def test_resolve_bearer_token_refresh_network_error_falls_back(
2020:        mock_client.post.side_effect = httpx.ConnectError("nameserver lookup failed")
2042:class TestEmitEnvelope:
2045:    def test_human_success_returns_data(self, capsys: pytest.CaptureFixture[str]):
2054:    def test_json_success_prints_envelope(self, capsys: pytest.CaptureFixture[str]):
2065:    def test_human_error_exits(self, capsys: pytest.CaptureFixture[str]):
2076:    def test_json_error_emits_envelope_and_exits(self, capsys: pytest.CaptureFixture[str]):
2093:class TestRootFlags:
2096:    F-2 of the v1.0.3 blind walk surfaced that ``finlet --version``
2098:    it through an eager callback that reads
2099:    :func:`importlib.metadata.version` so the published wheel metadata
2103:    def test_version_flag_prints_version_and_exits_zero(self) -> None:
2104:        """``finlet --version`` prints the installed version and exits 0.
2107:        :mod:`importlib.metadata` resolves the version against the dev
2110:        version-bump cadence (otherwise every patch release would need
2113:        result = runner.invoke(app, ["--version"])
2115:        # Output should contain at least one digit (a version number).
2118:    def test_help_lists_version_flag(self) -> None:
2119:        """``finlet --help`` exits cleanly with the ``--version`` option registered.
2121:        The literal ``--version`` substring is intentionally NOT asserted:
2126:        :meth:`test_version_flag_prints_version_and_exits_zero`; this
2128:        ``--version`` callback breaks ``--help`` rendering altogether.

exec
/bin/zsh -lc "rg -n \"@(app|.*)\\.command|add_typer|Typer\\(\" /Users/justnau/finlet/finlet/cli.py" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
220:app = typer.Typer(
239:    Typer requires a callback on the root ``Typer()`` app to surface
245:plugins_app = typer.Typer(help="Plugin management. See: finlet manual plugin-matrix")
246:auth_app = typer.Typer(help="Authentication commands. See: finlet manual auth-model")
247:mcp_app = typer.Typer(help="MCP server commands")
248:app.add_typer(plugins_app, name="plugins")
249:app.add_typer(auth_app, name="auth")
250:app.add_typer(mcp_app, name="mcp")
256:@app.command()
313:@plugins_app.command("list")
393:@plugins_app.command("add")
458:@plugins_app.command("remove")
534:@app.command()
908:@auth_app.command("login")
976:@auth_app.command("logout")
993:@auth_app.command("status")
1054:@mcp_app.command("serve")
1169:@app.command()

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet show 014329f''^:tests/test_cli_help.py | rg -n "''^(class |    def test_)|manual|serve|mcp|version|root|callback|advance|order|portfolio|status|session"' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
13:* ``serve`` — see ``finlet manual transports``
14:* ``register`` — see ``finlet manual auth-model``
15:* ``advance`` — see ``finlet manual session-lifecycle``
16:* ``order`` — see ``finlet manual session-lifecycle``
17:* ``portfolio`` — see ``finlet manual session-lifecycle``
18:* ``status`` — see ``finlet manual session-lifecycle``
19:* ``session`` (sub-app help) — see ``finlet manual session-lifecycle``
20:* ``plugins`` (sub-app help) — see ``finlet manual plugin-matrix``
21:* ``auth`` (sub-app help) — see ``finlet manual auth-model``
22:* ``mcp serve`` — see ``finlet manual transports``
51:class TestCliHelpFootered:
54:    def test_serve_help(self, home_sandbox):
55:        """``finlet serve --help`` works (subcommand registered)."""
56:        result = runner.invoke(app, ["serve", "--help"])
59:    def test_register_help(self, home_sandbox):
64:    def test_advance_help(self, home_sandbox):
65:        """``finlet advance --help`` works (subcommand registered)."""
66:        result = runner.invoke(app, ["advance", "--help"])
69:    def test_order_help(self, home_sandbox):
70:        """``finlet order --help`` works (subcommand registered)."""
71:        result = runner.invoke(app, ["order", "--help"])
74:    def test_portfolio_help(self, home_sandbox):
75:        """``finlet portfolio --help`` works (subcommand registered)."""
76:        result = runner.invoke(app, ["portfolio", "--help"])
79:    def test_status_help(self, home_sandbox):
80:        """``finlet status --help`` works (subcommand registered)."""
81:        result = runner.invoke(app, ["status", "--help"])
84:    def test_session_subapp_help(self, home_sandbox):
85:        """``finlet session --help`` works (sub-app registered)."""
86:        result = runner.invoke(app, ["session", "--help"])
89:    def test_plugins_subapp_help(self, home_sandbox):
94:    def test_auth_subapp_help(self, home_sandbox):
99:    def test_mcp_serve_help(self, home_sandbox):
100:        """``finlet mcp serve --help`` works (subcommand registered)."""
101:        result = runner.invoke(app, ["mcp", "serve", "--help"])

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet diff 014329f''^ 014329f -- tests/test_cli.py tests/test_cli_help.py tests/test_cli_benchmark.py tests/api/test_cli_mcp_client.py | rg -n "''^-.*(serve|register|auth|plugins|manual|mcp|version|callback)|''^[-+].*(def test_|class )"' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
exec
/bin/zsh -lc 'git -C /Users/justnau/finlet diff 014329f''^ 014329f -- tests/mcp/test_decrypt_visibility_tools.py | rg -n "eyJ[A-Za-z0-9_-]{20,}|fnlt_[a-f0-9]{32}|fnlt_|SESSION_VISIBILITY_SESSION_ID|test-session|header'"\\.payload\\.signature|public_anonymous|anonymous\\]|share_url\"" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
14:+in that the MCP tool's success envelope uses ``public_anonymous`` (the
54:+# refactor cannot silently rename ``public_anonymous`` (output) to match
61:+#   • output field: ``public_anonymous: bool`` (matches SessionResponse)
64:+# plus an anti-shape-drift guard that ``share_url`` does NOT appear in
70:+SESSION_VISIBILITY_API_KEY = "fnlt_test_key_visibility"
76:+SESSION_VISIBILITY_SESSION_ID = "00000000-0000-0000-0000-00000000bbbb"
117:+    session_id: str = SESSION_VISIBILITY_SESSION_ID,
135:+        public_anonymous=anonymous,
141:+        name="visibility-test-session",
148:+    """Pin v2.0.0 contract: response uses ``public_anonymous`` NOT ``anonymous``.
152:+    ``public_anonymous``.  A reasonable-looking refactor that aliases the
158:+    async def test_publish_anonymous_emits_public_anonymous_true(
161:+        """``public=True, anonymous=True`` → ``public AND public_anonymous`` both True."""
181:+        assert result["public_anonymous"] is True
183:+        # output key — the response schema field is ``public_anonymous``.
186:+            f"key — should be ``public_anonymous`` only (schema drift): {result}"
190:+    async def test_publish_attributed_emits_public_anonymous_false(
193:+        """``public=True, anonymous=False`` (attributed flow) → ``public_anonymous`` False."""
213:+        assert result["public_anonymous"] is False
223:+        via MCP. ``public_anonymous`` should still surface in the
249:+        assert result["public_anonymous"] is True
252:+    async def test_response_does_not_include_share_url(
255:+        """Anti-shape-drift: response MUST NOT include ``share_url``.
263:+        adds ``d["share_url"] = ...`` to ``session_response`` is caught
284:+        assert "share_url" not in result, (
285:+            f"Response leaked ``share_url`` key (shape-drift) — consumers "

 succeeded in 0ms:
4:--- a/tests/api/test_cli_mcp_client.py
7:-"""Unit tests for ``finlet.cli_mcp_client`` (v1.0.1 HTTP transport).
9:-The wrapper is the CLI's bridge to the cloud ``/mcp`` endpoint via
15:-* ``call_tool_async`` POSTs to ``{API_URL}/mcp`` with the right
32:-from finlet.cli_mcp_client import (
39:-class TestResolveApiUrl:
42:-    def test_default_when_env_not_set(self, monkeypatch: pytest.MonkeyPatch) -> None:
46:-    def test_env_override(self, monkeypatch: pytest.MonkeyPatch) -> None:
50:-    def test_strips_trailing_slash(self, monkeypatch: pytest.MonkeyPatch) -> None:
51:-        """``/mcp`` is appended directly — trailing slash on base URL is stripped."""
55:-    def test_strips_multiple_trailing_slashes(self, monkeypatch: pytest.MonkeyPatch) -> None:
60:-class TestDecodeToolResult:
64:-        """Build a minimal stand-in for ``mcp.types.TextContent``."""
69:-    def test_decode_dict_envelope(self) -> None:
77:-    def test_decode_error_envelope(self) -> None:
78:-        """The Finlet error envelope is preserved end-to-end."""
85:-    def test_decode_empty_content(self) -> None:
89:-    def test_decode_non_text_content_returns_error_envelope(self) -> None:
97:-    def test_decode_non_json_payload_surfaces_error(self) -> None:
104:-    def test_decode_non_dict_json_surfaces_error(self) -> None:
113:-class TestMCPDispatchError:
116:-    def test_exception_message_round_trips(self) -> None:
117:-        exc = MCPDispatchError("Cannot connect to Finlet MCP at https://finlet.dev/mcp: refused")
121:-class TestCallToolAsyncDispatch:
125:-    async def test_call_tool_async_round_trips(self, monkeypatch: pytest.MonkeyPatch) -> None:
135:-        import finlet.cli_mcp_client as _client_mod
136:-        from finlet.cli_mcp_client import call_tool_async
148:-            # streamablehttp_client returns (read_stream, write_stream, get_session_id_callback)
151:-        class FakeSession:
189:-        # POSTs to the default ``finlet.dev/mcp`` endpoint.
190:-        assert captured["url"] == "https://finlet.dev/mcp"
195:-    async def test_no_bearer_token_omits_authorization_header(
201:-        import finlet.cli_mcp_client as _client_mod
202:-        from finlet.cli_mcp_client import call_tool_async
213:-        class FakeSession:
243:-    async def test_api_url_env_override_respected(
249:-        import finlet.cli_mcp_client as _client_mod
250:-        from finlet.cli_mcp_client import call_tool_async
261:-        class FakeSession:
287:-        assert captured["url"] == "http://localhost:8000/mcp"
290:-    async def test_api_url_strips_trailing_slash(
296:-        import finlet.cli_mcp_client as _client_mod
297:-        from finlet.cli_mcp_client import call_tool_async
307:-        class FakeSession:
333:-        assert captured["url"] == "https://staging.finlet.dev/mcp"
336:-    async def test_connection_failure_raises_dispatch_error(
342:-        import finlet.cli_mcp_client as _client_mod
343:-        from finlet.cli_mcp_client import call_tool_async
359:-        assert "https://finlet.dev/mcp" in msg
370:-* **KEEP commands** (``serve``, ``register``, ``auth login``, ``auth logout``,
371:-  ``plugins list/add/remove``) continue to call REST via httpx.  Their tests
375:-  ``portfolio``, ``status``) dispatch through ``finlet.cli_mcp_client``.  Their
376:-  tests mock :func:`finlet.cli_mcp_client.call_tool_sync` so the test stays
380:-exercise the real subprocess + live server end-to-end.
415:-from finlet.cli_mcp_client import MCPDispatchError
426:-class TestSessionCommandsViaMCP:
429:-    def test_session_subcommands_registered(self):
430:-        """Verify create, list, and delete subcommands are registered."""
438:-    def test_session_delete_requires_argument(self):
444:-    def test_session_create_dispatches_create_session_tool(self, mock_call: MagicMock) -> None:
477:-    def test_session_create_universe_split(self, mock_call: MagicMock) -> None:
506:-    def test_session_create_blind_cli_does_not_echo_real_tickers(
556:-    def test_session_create_non_blind_universe_uses_response_config(
589:-    def test_session_create_falls_back_to_local_universe_if_response_omits(
594:-        Protects the non-blind UX in case an older server build doesn't echo the
596:-        blind server contract always includes ``universe`` with opaque ids.
627:-    def test_session_create_json_mode(self, mock_call: MagicMock) -> None:
642:-    def test_session_create_blind_flag_forwarded_to_mcp_tool(
691:-    def test_session_create_no_blind_flag_defaults_to_false(
733:-    def test_session_list_renders_human_output(self, mock_call: MagicMock) -> None:
753:-    def test_session_list_empty(self, mock_call: MagicMock) -> None:
761:-    def test_session_list_error_envelope_exits(self, mock_call: MagicMock) -> None:
764:-        Pre-v1.0.4 this asserted exit 1.  v1.0.4 promoted auth-failure
766:-        authenticated" distinctly from other tool failures (F-3 hotfix
774:-        assert "finlet auth login" in result.output
778:-    def test_session_list_api_key_sunset_envelope_exits_auth(self, mock_call: MagicMock) -> None:
786:-                "api_key authentication is no longer supported on MCP tools. "
787:-                "Run 'finlet auth login' to obtain an OAuth Bearer token."
795:-    def test_session_delete_dispatches_delete_session_tool(self, mock_call: MagicMock) -> None:
809:-    def test_session_publish_dispatches_set_session_visibility_tool(
832:-    def test_session_publish_attributed_flag(self, mock_call: MagicMock) -> None:
850:-    def test_session_publish_unpublish_flag(self, mock_call: MagicMock) -> None:
868:-    def test_session_publish_json_mode(self, mock_call: MagicMock) -> None:
888:-    def test_dispatch_failure_exits(self, mock_call: MagicMock) -> None:
891:-            "Cannot connect to Finlet MCP at https://finlet.dev/mcp: refused"
898:-    def test_dispatch_timeout_friendly_error(self, mock_call: MagicMock) -> None:
904:-        site in `_dispatch_mcp_tool` converts the timeout into:
937:-    def test_dispatch_builtin_timeout_also_caught(self, mock_call: MagicMock) -> None:
946:-class TestBenchmarkVisibilityCommandsViaMCP:
950:-    def test_benchmark_decrypt_dispatches_decrypt_tool(
971:-    def test_benchmark_visibility_publish_default_anonymous(
996:-    def test_benchmark_visibility_attributed_flag(
1021:-    def test_benchmark_visibility_unpublish_flag(
1047:-    def test_benchmark_visibility_json_mode_emits_envelope(
1073:-class TestAdvanceCommandViaMCP:
1076:-    def test_advance_help_carries_session_flag(self):
1085:-    def test_advance_default_one_step(self, mock_call: MagicMock) -> None:
1102:-    def test_advance_days_passes_steps(self, mock_call: MagicMock) -> None:
1118:-    def test_advance_to_passes_target_date(self, mock_call: MagicMock) -> None:
1133:-    def test_advance_days_and_to_mutually_exclusive(self):
1152:-    def test_advance_to_invalid_format(self):
1161:-    def test_advance_requires_session(self):
1167:-class TestOrderCommandViaMCP:
1170:-    def test_order_help(self):
1189:-    def test_order_market_buy_dispatches_submit_order(self, mock_call: MagicMock) -> None:
1225:-    def test_order_limit_passes_limit_price(self, mock_call: MagicMock) -> None:
1255:-    def test_order_with_reasoning_forwards_field(self, mock_call: MagicMock) -> None:
1279:-    def test_order_limit_requires_price_client_side(self):
1304:-    def test_order_stop_requires_price_client_side(self):
1329:-    def test_order_market_with_limit_price_rejected(self):
1356:-class TestPortfolioCommandViaMCP:
1359:-    def test_portfolio_help(self):
1365:-    def test_portfolio_with_positions_plain_text(self, mock_call: MagicMock) -> None:
1405:-    def test_portfolio_empty_positions(self, mock_call: MagicMock) -> None:
1429:-    def test_portfolio_error_envelope_exits(self, mock_call: MagicMock) -> None:
1435:-    def test_portfolio_requires_session(self):
1440:-class TestStatusCommandViaMCP:
1443:-    def test_status_help(self):
1449:-    def test_status_renders_human_output(self, mock_call: MagicMock) -> None:
1472:-    def test_status_empty_universe_omits_line(self, mock_call: MagicMock) -> None:
1486:-    def test_status_error_envelope_exits(self, mock_call: MagicMock) -> None:
1554:-        for cmd in ("register", "advance", "order", "portfolio", "status", "session", "plugins", "auth", "mcp"):
1558:+    def test_dropped_agentic_commands_not_registered(self):
1588:-# ─── _translate_mcp_error helper ────────────────────────────────────
1591:-class TestTranslateMcpError:
1594:-    def test_string_error(self):
1595:-        from finlet.cli import _translate_mcp_error
1597:-        assert _translate_mcp_error({"error": "boom"}) == "boom"
1599:-    def test_no_error(self):
1600:-        from finlet.cli import _translate_mcp_error
1602:-        assert _translate_mcp_error({"id": "sid", "name": "Alpha"}) is None
1604:-    def test_dict_error_with_message(self):
1605:-        from finlet.cli import _translate_mcp_error
1607:-        envelope = {"error": {"code": "unauth", "message": "human-readable"}}
1608:-        assert _translate_mcp_error(envelope) == "human-readable"
1610:-    def test_dict_error_no_message(self):
1611:-        from finlet.cli import _translate_mcp_error
1615:-        result = _translate_mcp_error(envelope)
1623:-class TestResolveBearerToken:
1626:-    def test_explicit_api_key_wins(self):
1631:-    def test_returns_none_when_no_credentials(self, monkeypatch, tmp_path):
1639:-    def test_loads_credentials_file(self, monkeypatch, tmp_path):
1672:-    def test_resolve_bearer_token_not_expired_returns_existing(
1714:-    def test_resolve_bearer_token_expired_refreshes_and_writes(
1717:-        """Expired token triggers POST /oauth/token; rotated creds persist."""
1773:-        assert data.get("resource") == "https://finlet.dev/mcp"
1783:-    def test_resolve_bearer_token_refresh_400_returns_none(
1786:-        """4xx from /oauth/token ⇒ refresh-token revoked; returns None."""
1830:-        assert "finlet auth login" in captured.err
1832:-    def test_resolve_bearer_token_refresh_network_error_falls_back(
1864:-        mock_client.post.side_effect = httpx.ConnectError("nameserver lookup failed")
1871:-        # ``finlet auth login`` hint downstream.
1886:-class TestEmitEnvelope:
1889:-    def test_human_success_returns_data(self, capsys: pytest.CaptureFixture[str]):
1898:-    def test_json_success_prints_envelope(self, capsys: pytest.CaptureFixture[str]):
1909:-    def test_human_error_exits(self, capsys: pytest.CaptureFixture[str]):
1920:-    def test_json_error_emits_envelope_and_exits(self, capsys: pytest.CaptureFixture[str]):
1948:-* ``finlet benchmark --help`` exits 0 and registers ``start`` + ``progress``.
1974:-class TestBenchmarkCLIHelp:
1977:-    def test_benchmark_help_succeeds(self) -> None:
1982:-    def test_benchmark_start_help_succeeds(self) -> None:
1993:-    def test_benchmark_progress_help_succeeds(self) -> None:
1999:-class TestBenchmarkStartDispatch:
2003:-    def test_benchmark_start_dispatches_with_blind_false_default(
2038:-    def test_benchmark_start_dispatches_with_blind_true_when_flagged(
2072:-    def test_benchmark_start_dispatches_with_optional_metadata(
2114:-class TestBenchmarkProgressDispatch:
2118:-    def test_benchmark_progress_dispatches_tool(self, mock_call: MagicMock) -> None:
2145:-        # No arguments beyond auth.
2165:-* ``advance`` — see ``finlet manual session-lifecycle``
2166:-* ``order`` — see ``finlet manual session-lifecycle``
2167:-* ``portfolio`` — see ``finlet manual session-lifecycle``
2168:-* ``status`` — see ``finlet manual session-lifecycle``
2169:-* ``session`` (sub-app help) — see ``finlet manual session-lifecycle``
2190:-    def test_advance_help(self, home_sandbox):
2191:-        """``finlet advance --help`` works (subcommand registered)."""
2195:-    def test_order_help(self, home_sandbox):
2196:-        """``finlet order --help`` works (subcommand registered)."""
2200:-    def test_portfolio_help(self, home_sandbox):
2201:-        """``finlet portfolio --help`` works (subcommand registered)."""
2205:-    def test_status_help(self, home_sandbox):
2206:-        """``finlet status --help`` works (subcommand registered)."""
2210:-    def test_session_subapp_help(self, home_sandbox):
2211:-        """``finlet session --help`` works (sub-app registered)."""
2223:+    def test_manual_help(self, home_sandbox):

exec
/bin/zsh -lc "nl -ba /Users/justnau/finlet/finlet/cli.py | sed -n '220,285p'" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
   220	app = typer.Typer(
   221	    name="finlet",
   222	    help="Finlet — Integrated Testing Environment for AI Trading Agent Reasoning",
   223	    no_args_is_help=True,
   224	)
   225	
   226	
   227	@app.callback()
   228	def _root_callback(
   229	    version: bool | None = typer.Option(  # noqa: ARG001 — callback owns the side-effect.
   230	        None,
   231	        "--version",
   232	        callback=_version_callback,
   233	        is_eager=True,
   234	        help="Print the installed Finlet version and exit.",
   235	    ),
   236	) -> None:
   237	    """Finlet root callback — hosts the ``--version`` flag.
   238	
   239	    Typer requires a callback on the root ``Typer()`` app to surface
   240	    top-level options.  This callback intentionally does nothing else;
   241	    real work is delegated to subcommands.
   242	    """
   243	
   244	
   245	plugins_app = typer.Typer(help="Plugin management. See: finlet manual plugin-matrix")
   246	auth_app = typer.Typer(help="Authentication commands. See: finlet manual auth-model")
   247	mcp_app = typer.Typer(help="MCP server commands")
   248	app.add_typer(plugins_app, name="plugins")
   249	app.add_typer(auth_app, name="auth")
   250	app.add_typer(mcp_app, name="mcp")
   251	
   252	
   253	# ── serve ────────────────────────────────────────────────────
   254	
   255	
   256	@app.command()
   257	def serve(
   258	    host: str = typer.Option("0.0.0.0", envvar="FINLET_HOST", help="Bind address"),
   259	    port: int = typer.Option(8000, envvar="FINLET_PORT", help="Port number"),
   260	    reload: bool = typer.Option(False, help="Enable auto-reload for development"),
   261	) -> None:
   262	    """Start the API server and serve the dashboard.
   263	
   264	    Boots uvicorn against ``finlet.api.app:create_app`` (factory mode)
   265	    on ``$FINLET_HOST:$FINLET_PORT`` — defaults to ``0.0.0.0:8000``.
   266	    The dashboard SPA mounts under ``/`` and the REST + MCP HTTP
   267	    surfaces under ``/v1/...`` + ``/mcp``. ``--reload`` is dev-only.
   268	
   269	    Examples:
   270	      finlet serve
   271	      finlet serve --port 9000 --reload
   272	
   273	    See: finlet manual transports
   274	    """
   275	    try:
   276	        import uvicorn
   277	    except ImportError:
   278	        typer.echo("Error: Server mode requires the full Finlet installation.", err=True)
   279	        typer.echo("Install with: pip install finlet[server]", err=True)
   280	        raise typer.Exit(1)
   281	
   282	    uvicorn.run(
   283	        "finlet.api.app:create_app",
   284	        factory=True,
   285	        host=host,

exec
/bin/zsh -lc "nl -ba /Users/justnau/finlet/finlet/cli.py | sed -n '520,565p'" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
   520	    except httpx.HTTPError as e:
   521	        typer.echo(f"Error: Could not clear plugin config: {e}", err=True)
   522	        raise typer.Exit(1)
   523	
   524	    health = data.get("health") or {}
   525	    status = health.get("status") or data.get("status", "unknown")
   526	    message = health.get("message") or data.get("message") or ""
   527	    suffix = f" — {message}" if message else ""
   528	    typer.echo(f"Plugin '{name}' status: {status}{suffix}")
   529	
   530	
   531	# ── register ────────────────────────────────────────────────
   532	
   533	
   534	@app.command()
   535	def register(
   536	    email: str = typer.Option(..., "--email", "-e", help="Email address for registration"),
   537	) -> None:
   538	    """Register a new account and receive an API key.
   539	
   540	    Calls ``POST /auth/register`` against the configured Finlet server
   541	    and prints the returned api_key + tier. The key is shown ONCE — it
   542	    cannot be retrieved later. For OAuth-based authentication post-
   543	    registration (the canonical agent-auth path), follow up with
   544	    ``finlet auth login``; the api_key remains a fallback for REST
   545	    clients and CI/headless environments.
   546	
   547	    Examples:
   548	      finlet register --email alice@example.com
   549	
   550	    See: finlet manual auth-model
   551	    """
   552	    import httpx
   553	
   554	    body = {"email": email}
   555	
   556	    try:
   557	        resp = httpx.post(f"{_API_URL}/auth/register", json=body, timeout=10)
   558	        resp.raise_for_status()
   559	        data = resp.json()
   560	        api_key = data.get("api_key", "")
   561	        typer.echo("Registration successful!")
   562	        typer.echo(f"  API Key: {api_key}")
   563	        typer.echo(f"  Tier: {data.get('tier', 'free')}")
   564	        typer.echo("")
   565	        typer.echo("Save your key — it cannot be retrieved later:")

exec
/bin/zsh -lc "nl -ba /Users/justnau/finlet/finlet/cli.py | sed -n '900,1015p'" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
   900	        "Login establishes a session for the dashboard. CLI commands "
   901	        "authenticate via FINLET_API_KEY — set it from a previously-issued "
   902	        "API key:"
   903	    )
   904	    typer.echo("  export FINLET_API_KEY=fk_...")
   905	    return 0
   906	
   907	
   908	@auth_app.command("login")
   909	def auth_login(
   910	    email: str | None = typer.Option(None, "--email", "-e", help="Account email address (legacy email/password mode)"),
   911	    password: str | None = typer.Option(
   912	        None,
   913	        "--password",
   914	        "-p",
   915	        help="Account password (legacy email/password mode; prompted if --email is supplied without it)",
   916	    ),
   917	    api_key: str | None = typer.Option(
   918	        None,
   919	        "--api-key",
   920	        "-k",
   921	        envvar="FINLET_API_KEY",
   922	        help="Verify an existing API key (legacy mode). Verification only; no key is minted.",
   923	    ),
   924	) -> None:
   925	    """Sign in to Finlet.
   926	
   927	    Three modes, gated by which flag (if any) is supplied:
   928	
   929	    * No flags → **OAuth Authorization Code Flow with PKCE** (RFC 7636).
   930	      Opens the user's browser to ``/oauth/authorize``, captures the
   931	      code on a loopback redirect (RFC 8252 §7.3), exchanges it at
   932	      ``/oauth/token`` for a 15-minute EdDSA JWT access token + opaque
   933	      refresh token, and persists both at ``~/.finlet/credentials``
   934	      (mode 0600). Subsequent CLI commands authenticate via the
   935	      access token automatically. This is the canonical agent-auth
   936	      path post-Phase 4 (see ``docs/decisions/mcp-oauth-2-1-auth-model.md``).
   937	    * ``--api-key=<key>`` → verify an existing API key. The CLI calls
   938	      an authenticated endpoint and reports whether the key works.
   939	      Audit C4 lineage: this path does NOT mint a new API key.
   940	      Convenience mode: confirm an existing ``FINLET_API_KEY`` value
   941	      authenticates against Finlet's REST surface.
   942	    * ``--email`` + ``--password`` → verify email + password. Calls
   943	      ``POST /auth/login``, returns user identity + tier, reminds the
   944	      caller that the CLI authenticates via ``FINLET_API_KEY``.
   945	      Establishes a dashboard session cookie via the server response.
   946	
   947	    The OAuth path is the default; the two legacy paths are explicit
   948	    opt-ins for credential-verification workflows.
   949	    """
   950	    if api_key is not None:
   951	        exit_code = _verify_api_key_credential(api_key)
   952	        if exit_code != 0:
   953	            raise typer.Exit(exit_code)
   954	        return
   955	
   956	    if email is not None:
   957	        # Prompt for password only when --email is supplied without --password.
   958	        if password is None:
   959	            password = typer.prompt("Password", hide_input=True)
   960	        exit_code = _verify_email_password_credential(email, password)
   961	        if exit_code != 0:
   962	            raise typer.Exit(exit_code)
   963	        return
   964	
   965	    if password is not None and email is None:
   966	        raise typer.BadParameter(
   967	            "--password requires --email. To run OAuth login, omit both flags."
   968	        )
   969	
   970	    # No flags → OAuth Authorization Code Flow.
   971	    exit_code = _run_oauth_login_flow()
   972	    if exit_code != 0:
   973	        raise typer.Exit(exit_code)
   974	
   975	
   976	@auth_app.command("logout")
   977	def auth_logout() -> None:
   978	    """Delete locally stored OAuth credentials.
   979	
   980	    Removes ``~/.finlet/credentials`` if present, idempotent otherwise.
   981	    Does NOT revoke the refresh token at the server — server-side
   982	    revocation is a future improvement (the refresh token expires
   983	    naturally at its absolute lifetime per Phase 4a decision record §5).
   984	    """
   985	    path = _credentials_path()
   986	    if os.path.exists(path):
   987	        os.remove(path)
   988	        typer.echo(f"Logged out — removed {path}")
   989	    else:
   990	        typer.echo("Already logged out (no credentials file found).")
   991	
   992	
   993	@auth_app.command("status")
   994	def auth_status() -> None:
   995	    """Report current authentication state from local credentials file.
   996	
   997	    Reads ``~/.finlet/credentials`` and reports one of:
   998	
   999	    * **Not logged in** — file missing or empty. Exit 2.
  1000	    * **Logged in** — file present and ``expires_at`` is in the future.
  1001	      Exit 0. Reports how many minutes remain until token expiry.
  1002	    * **Token expired** — file present but ``expires_at`` <= now.
  1003	      Exit 2. Suggests running ``finlet auth login`` to refresh.
  1004	    * **Credentials file unreadable** (e.g., insecure mode). Exit 1.
  1005	
  1006	    Auth-failure paths exit :data:`EXIT_AUTH_REQUIRED` (2) so shell
  1007	    scripts can distinguish "not authenticated" from other CLI errors
  1008	    (F-3 hotfix); the same exit code is shared by
  1009	    :func:`plugins_add` / :func:`plugins_remove` when ``FINLET_API_KEY``
  1010	    is missing.
  1011	
  1012	    This is a purely local check — does NOT ping the server. Use this
  1013	    command to verify the local credentials state before assuming
  1014	    authenticated CLI commands will succeed. Server-side rejection
  1015	    (e.g., the refresh token was revoked from the dashboard) is only

exec
/bin/zsh -lc "nl -ba /Users/justnau/finlet/finlet/cli.py | sed -n '1040,1075p'" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
  1040	    remaining_seconds = expires_at - now
  1041	    remaining_minutes = remaining_seconds // 60
  1042	    typer.echo(f"Logged in. Token expires in {remaining_minutes} minutes.")
  1043	
  1044	
  1045	# REMOVED in v2.0.0: top-level advance / order / portfolio / status.
  1046	# Agents call the MCP tools (advance_time / submit_order / get_portfolio /
  1047	# get_session) directly through their MCP client. See
  1048	# `finlet manual quickstart`.
  1049	
  1050	
  1051	# ── mcp ──────────────────────────────────────────────────────
  1052	
  1053	
  1054	@mcp_app.command("serve")
  1055	def mcp_serve() -> None:
  1056	    """Start MCP server over stdio (for Claude Code / Generic MCP Client).
  1057	
  1058	    Boots a self-host MCP server reading JSONRPC on stdin and writing
  1059	    JSONRPC on stdout.  The subprocess reads ``FINLET_OAUTH_BEARER``
  1060	    (preferred — ``finlet auth login`` mints a JWT; matches the
  1061	    post-Phase-4e Claude Desktop and Generic MCP Client configs) from
  1062	    its environment to authenticate tool calls.  ``FINLET_API_KEY`` is
  1063	    accepted as a fallback for CI / headless environments — the stdio
  1064	    bridge translates the api_key internally to the MCP HTTP surface.
  1065	
  1066	    Boot sequence:
  1067	
  1068	    1. ``configure_logging()`` FIRST — installs the stdlib ``StreamHandler``
  1069	       on ``sys.stderr`` and wires structlog through it.  Anything the
  1070	       subprocess writes to stdout pollutes the JSONRPC framing the client
  1071	       reads on the same pipe (the client's :func:`stdio_client` reader
  1072	       parses every stdout line as JSONRPC and emits a
  1073	       ``Failed to parse JSONRPC message from server`` + pydantic
  1074	       ``ValidationError`` traceback on the user's terminal when a line is
  1075	       not valid JSON).  Default structlog has no configuration and uses a

exec
/bin/zsh -lc "nl -ba /Users/justnau/finlet/finlet/cli.py | sed -n '1155,1195p'" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
  1155	            f"Warning: auth_service bootstrap failed ({type(exc).__name__}: {exc}); "
  1156	            "tool auth resolutions will likely fail.",
  1157	            err=True,
  1158	        )
  1159	
  1160	    # Restore the real stdout for FastMCP's stdio transport, which wraps
  1161	    # ``sys.stdout.buffer`` once at run-loop start to write JSONRPC frames.
  1162	    sys.stdout = _real_stdout
  1163	    mcp_server.run(transport="stdio")
  1164	
  1165	
  1166	# ── manual ───────────────────────────────────────────────────
  1167	
  1168	
  1169	@app.command()
  1170	def manual(
  1171	    topic: str | None = typer.Argument(
  1172	        None,
  1173	        help="Topic name (e.g., quickstart, auth-model, errors). Omit to print the index.",
  1174	    ),
  1175	    list_: bool = typer.Option(
  1176	        False,
  1177	        "--list",
  1178	        "-l",
  1179	        help="Print the topic index (name + one-line summary) and exit.",
  1180	    ),
  1181	    search: str | None = typer.Option(
  1182	        None,
  1183	        "--search",
  1184	        "-s",
  1185	        help="Substring search across topic titles + bodies; returns (name, snippet) hits.",
  1186	    ),
  1187	    format_: str = typer.Option(
  1188	        "text",
  1189	        "--format",
  1190	        "-f",
  1191	        help="Output format: 'text' (Markdown body) or 'json' (structured render).",
  1192	    ),
  1193	) -> None:
  1194	    """Print Finlet user-manual topics.
  1195	

exec
/bin/zsh -lc "nl -ba /Users/justnau/finlet/tests/test_cli.py | sed -n '657,765p'" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
   657	class TestTopLevelCommands:
   658	    """v2.0.0 pure-MCP CLI surface: 6 commands only.
   659	
   660	    All agentic-trading commands (``session``, ``advance``, ``order``,
   661	    ``portfolio``, ``status``, ``benchmark``) were removed in the v2.0.0
   662	    cutover. Agents now drive Finlet through the MCP surface directly.
   663	    """
   664	
   665	    def test_all_commands_registered(self):
   666	        """Verify all expected top-level commands appear in --help."""
   667	        result = runner.invoke(app, ["--help"])
   668	        assert result.exit_code == 0
   669	        output = _strip_ansi(result.output)
   670	        for cmd in ("serve", "register", "manual", "plugins", "auth", "mcp"):
   671	            assert cmd in output, f"Command '{cmd}' not found in --help output"
   672	
   673	    def test_dropped_agentic_commands_not_registered(self):
   674	        """The v2.0.0 cutover removed agentic CLI commands — verify they're absent.
   675	
   676	        Agents now invoke the MCP tools directly (``mcp__finlet__*`` namespace);
   677	        the CLI no longer ships a parallel surface. Listed verbatim from
   678	        Team A's deletion list so future regressions on a partial re-add
   679	        surface here.
   680	        """
   681	        result = runner.invoke(app, ["--help"])
   682	        assert result.exit_code == 0
   683	        output = _strip_ansi(result.output)
   684	        # session create/list/delete/publish, advance, order, portfolio,
   685	        # status, benchmark — these are top-level command names; the
   686	        # `--help` output renders them as standalone tokens in the
   687	        # Commands panel. The substring check is intentionally narrow
   688	        # (whitespace-bounded) so we don't false-match on copy in a
   689	        # description column.
   690	        for dropped in (" advance ", " order ", " portfolio ", " status ", " benchmark ", " session "):
   691	            assert dropped not in output, (
   692	                f"Dropped agentic command {dropped.strip()!r} still appears "
   693	                f"in --help (v2.0.0 cutover regression)"
   694	            )
   695	
   696	    def test_mcp_serve_subcommand_registered(self):
   697	        """``finlet mcp serve`` is the new entry point (renamed from ``finlet mcp``)."""
   698	        result = runner.invoke(app, ["mcp", "--help"])
   699	        assert result.exit_code == 0
   700	        output = _strip_ansi(result.output)
   701	        assert "serve" in output
   702	
   703	    def test_legacy_finlet_mcp_no_longer_top_level(self):
   704	        """``finlet mcp`` (no subcommand) is now a Typer group, not a leaf command.
   705	
   706	        Phase 5 moved the previous leaf ``mcp`` command under ``mcp serve``.
   707	        Calling ``finlet mcp`` with no subcommand should fail (exit non-zero)
   708	        with a "missing command" message rather than starting the server.
   709	        """
   710	        result = runner.invoke(app, ["mcp"], catch_exceptions=False)
   711	        # Typer's no-args behavior on a sub-typer is to print "Missing command"
   712	        # and exit 2.  The contract being asserted is "did NOT start the MCP
   713	        # server" — exit code is non-zero AND the help message mentions the
   714	        # subgroup shape.
   715	        assert result.exit_code != 0, result.output
   716	        output = _strip_ansi(result.output)
   717	        # Should reference "finlet mcp" (the group) in the help / error path.
   718	        assert "finlet mcp" in output or "Missing command" in output or "command" in output.lower()
   719	
   720	
   721	# ─── Root flags (F-2 hotfix) ─────────────────────────────────────────
   722	
   723	
   724	class TestRootFlags:
   725	    """Root-level Typer options exposed on ``finlet --<flag>``.
   726	
   727	    F-2 of the v1.0.3 blind walk surfaced that ``finlet --version``
   728	    was unimplemented (Typer "No such option" + exit 2).  v1.0.4 wires
   729	    it through an eager callback that reads
   730	    :func:`importlib.metadata.version` so the published wheel metadata
   731	    is the single source of truth.
   732	    """
   733	
   734	    def test_version_flag_prints_version_and_exits_zero(self) -> None:
   735	        """``finlet --version`` prints the installed version and exits 0.
   736	
   737	        The CliRunner intentionally does NOT install Finlet — but
   738	        :mod:`importlib.metadata` resolves the version against the dev
   739	        install ``pip install -e .`` runs from. We assert the exit
   740	        code + a non-empty stdout to keep the test stable across the
   741	        version-bump cadence (otherwise every patch release would need
   742	        a coupled test update).
   743	        """
   744	        result = runner.invoke(app, ["--version"])
   745	        assert result.exit_code == 0, result.output
   746	        # Output should contain at least one digit (a version number).
   747	        assert any(ch.isdigit() for ch in result.output), result.output
   748	
   749	    def test_help_lists_version_flag(self) -> None:
   750	        """``finlet --help`` exits cleanly with the ``--version`` option registered.
   751	
   752	        The literal ``--version`` substring is intentionally NOT asserted:
   753	        rich-click renders the options panel at the active terminal width
   754	        (CI defaults to ``COLUMNS=80``) and truncates option names with
   755	        an ellipsis when the panel is narrower than the longest row.
   756	        The functional behavior of the flag is already covered by
   757	        :meth:`test_version_flag_prints_version_and_exits_zero`; this
   758	        test exists to catch the regression where adding the eager
   759	        ``--version`` callback breaks ``--help`` rendering altogether.
   760	        """
   761	        result = runner.invoke(app, ["--help"])
   762	        assert result.exit_code == 0, result.output

exec
/bin/zsh -lc 'rg -n "def validate_session_id|validate_session_id|session_id.*regex|SESSION_ID" /Users/justnau/finlet/finlet /Users/justnau/finlet/tests/mcp/test_decrypt_visibility_tools.py' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
/Users/justnau/finlet/tests/mcp/test_decrypt_visibility_tools.py:410:# UUID-shaped session_id that passes ``validate_session_id`` regex BUT is
/Users/justnau/finlet/tests/mcp/test_decrypt_visibility_tools.py:413:SESSION_VISIBILITY_SESSION_ID = "00000000-0000-0000-0000-00000000bbbb"
/Users/justnau/finlet/tests/mcp/test_decrypt_visibility_tools.py:454:    session_id: str = SESSION_VISIBILITY_SESSION_ID,
/Users/justnau/finlet/finlet/manual/errors.md:168:or has been deleted. Reference: `finlet/mcp/auth.py:validate_session_id`
/Users/justnau/finlet/finlet/manual/session-lifecycle.md:77:(`finlet/mcp/auth.py:validate_session_id`).
/Users/justnau/finlet/finlet/mcp/blind_error.py:99:_SESSION_ID_PARAM = "session_id"
/Users/justnau/finlet/finlet/mcp/blind_error.py:213:    if _SESSION_ID_PARAM not in param_names:
/Users/justnau/finlet/finlet/mcp/blind_error.py:218:    if _SESSION_ID_PARAM in kwargs:
/Users/justnau/finlet/finlet/mcp/blind_error.py:219:        candidate = kwargs[_SESSION_ID_PARAM]
/Users/justnau/finlet/finlet/mcp/blind_error.py:225:    idx = param_names.index(_SESSION_ID_PARAM)
/Users/justnau/finlet/finlet/api/deps.py:10:from finlet.db.models import validate_session_id
/Users/justnau/finlet/finlet/api/deps.py:20:        validate_session_id(session_id)
/Users/justnau/finlet/finlet/db/engine.py:131:_SESSION_ID_RE = re.compile(r"^[a-f0-9][a-f0-9-]{0,63}$")
/Users/justnau/finlet/finlet/db/engine.py:134:def validate_session_id(session_id: str) -> str:
/Users/justnau/finlet/finlet/db/engine.py:140:    if not _SESSION_ID_RE.match(session_id):
/Users/justnau/finlet/finlet/db/engine.py:146:    validate_session_id(session_id)
/Users/justnau/finlet/finlet/db/engine.py:228:    validate_session_id(session_id)
/Users/justnau/finlet/finlet/db/models.py:71:    validate_session_id,
/Users/justnau/finlet/finlet/db/models.py:176:    "validate_session_id",
/Users/justnau/finlet/finlet/gdpr/deleters/sessions.py:41:    validate_session_id,
/Users/justnau/finlet/finlet/gdpr/deleters/sessions.py:58:    directories whose names fail ``validate_session_id``, sessions
/Users/justnau/finlet/finlet/gdpr/deleters/sessions.py:72:            validate_session_id(session_id)
/Users/justnau/finlet/finlet/db/persistence.py:421:    skipped via ``validate_session_id`` so they don't propagate
/Users/justnau/finlet/finlet/db/persistence.py:436:        # ``tmp-junk/`` left behind by a crashed migration); ``validate_session_id``
/Users/justnau/finlet/finlet/db/persistence.py:441:            from finlet.db.models import validate_session_id
/Users/justnau/finlet/finlet/db/persistence.py:443:            validate_session_id(session_id)
/Users/justnau/finlet/finlet/db/persistence.py:472:    from finlet.db.models import validate_session_id
/Users/justnau/finlet/finlet/db/persistence.py:474:    validate_session_id(session_id)
/Users/justnau/finlet/finlet/gdpr/walkers/sessions.py:39:    validate_session_id,
/Users/justnau/finlet/finlet/gdpr/walkers/sessions.py:242:        # validate_session_id regex; otherwise it's a stray dir and
/Users/justnau/finlet/finlet/gdpr/walkers/sessions.py:245:            validate_session_id(session_id)
/Users/justnau/finlet/finlet/mcp/auth.py:10:from finlet.db.models import validate_session_id
/Users/justnau/finlet/finlet/mcp/auth.py:223:        validate_session_id(session_id)
/Users/justnau/finlet/finlet/api/routes_public_session.py:46:from finlet.db.models import validate_session_id
/Users/justnau/finlet/finlet/api/routes_public_session.py:75:        validate_session_id(session_id)

exec
/bin/zsh -lc 'rg -n "auth logout|logout" /Users/justnau/finlet/tests/test_cli.py /Users/justnau/finlet/tests/test_cli_help.py /Users/justnau/finlet/tests/test_cli_oauth_login.py' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
/Users/justnau/finlet/tests/test_cli.py:10:* sub-app ``auth`` — ``login`` / ``logout`` / ``status`` (OAuth credential mgmt)
/Users/justnau/finlet/tests/test_cli_oauth_login.py:9:* The ``finlet auth logout`` subcommand.
/Users/justnau/finlet/tests/test_cli_oauth_login.py:417:# auth logout
/Users/justnau/finlet/tests/test_cli_oauth_login.py:422:    def test_logout_deletes_file(self, home_sandbox):
/Users/justnau/finlet/tests/test_cli_oauth_login.py:423:        """``finlet auth logout`` removes ~/.finlet/credentials."""
/Users/justnau/finlet/tests/test_cli_oauth_login.py:431:        result = runner.invoke(app, ["auth", "logout"])
/Users/justnau/finlet/tests/test_cli_oauth_login.py:437:    def test_logout_no_file(self, home_sandbox):
/Users/justnau/finlet/tests/test_cli_oauth_login.py:438:        """``finlet auth logout`` is idempotent — no-op when no file present."""
/Users/justnau/finlet/tests/test_cli_oauth_login.py:441:        result = runner.invoke(app, ["auth", "logout"])
/Users/justnau/finlet/tests/test_cli_oauth_login.py:495:    def test_auth_logout_help(self, home_sandbox):
/Users/justnau/finlet/tests/test_cli_oauth_login.py:496:        """``finlet auth logout --help`` works (subcommand registered)."""
/Users/justnau/finlet/tests/test_cli_oauth_login.py:497:        result = runner.invoke(app, ["auth", "logout", "--help"])

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet diff 014329f''^ 014329f -- tests/mcp/test_decrypt_visibility_tools.py | sed -n '"'1,320p'" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
diff --git a/tests/mcp/test_decrypt_visibility_tools.py b/tests/mcp/test_decrypt_visibility_tools.py
index dce4fea..b7dffc6 100644
--- a/tests/mcp/test_decrypt_visibility_tools.py
+++ b/tests/mcp/test_decrypt_visibility_tools.py
@@ -10,18 +10,28 @@ Validates the blind-export redesign post-completion lifecycle:
 * Ownership: cross-user requests return ``benchmark_run_not_found`` (no leak).
 * Mid-flight runs: both tools return ``benchmark_run_not_completed``.
 * Tools registered in :mod:`finlet.mcp.server` for FastMCP discovery.
+
+Also pins the v2.0.0 schema-key contract for the SESSION-level visibility
+tool (``set_session_visibility`` in :mod:`finlet.mcp.tools_session`) — see
+the four ``TestMcpSetSessionVisibilitySchemaKeys`` tests below. These were
+added by Team B (V2_PURE_MCP_EXECUTION_PLAN Step 10b BLOCKER-3) to lock
+in that the MCP tool's success envelope uses ``public_anonymous`` (the
+OUTPUT schema field at :class:`finlet.api.schemas.session.SessionResponse`)
+NOT ``anonymous`` (the INPUT param name) — a Codex-flagged shape-drift
+risk between the request body and the response.
 """
 
 from __future__ import annotations
 
 import hashlib
-from datetime import datetime, timezone
+from datetime import datetime, timedelta, timezone
 from typing import Any
 from unittest.mock import AsyncMock
 
 import pytest
 
 from finlet.auth.service import AuthService, UserRecord, UserTier
+from finlet.core.session import Session, SessionConfig
 from finlet.leaderboard.benchmark_state import (
     BenchmarkRun,
     ScenarioResult,
@@ -37,6 +47,9 @@ from finlet.mcp.tools_benchmark import (
 from finlet.mcp.tools_benchmark import (
     set_benchmark_visibility as mcp_set_benchmark_visibility,
 )
+from finlet.mcp.tools_session import (
+    set_session_visibility as mcp_set_session_visibility,
+)
 
 # ── Constants ───────────────────────────────────────────────────
 
@@ -370,6 +383,248 @@ async def test_visibility_anonymous_default_true(monkeypatch: Any) -> None:
     assert result["published_anonymous"] is True
 
 
+# ── set_session_visibility — Step 10b BLOCKER-3 schema-key assertions ──
+#
+# v2.0.0 pure-MCP migration (Team B) adds explicit MCP-side coverage for
+# ``set_session_visibility`` (the SESSION-level visibility tool, separate
+# from ``set_benchmark_visibility``).  Pins the response shape so a future
+# refactor cannot silently rename ``public_anonymous`` (output) to match
+# the input param name ``anonymous`` — a Codex-flagged schema-drift risk
+# captured in the V2_PURE_MCP_EXECUTION_PLAN Step 10b review.
+#
+# Tool spec:
+#   set_session_visibility(session_id, public, anonymous=True, api_key) → dict
+#   • input param: ``anonymous: bool`` (signals "anonymous attribution")
+#   • output field: ``public_anonymous: bool`` (matches SessionResponse)
+#
+# The four tests below cover the full publish / unpublish flag matrix
+# plus an anti-shape-drift guard that ``share_url`` does NOT appear in
+# the response (the dashboard / agent derives the share URL externally
+# as ``https://finlet.dev/sessions/{id}``).
+
+
+# Obviously-fake test fixtures — gitleaks-safe per Step 10b STRONG-3.
+SESSION_VISIBILITY_API_KEY = "fnlt_test_key_visibility"
+SESSION_VISIBILITY_USER_ID = "session-vis-user"
+
+# UUID-shaped session_id that passes ``validate_session_id`` regex BUT is
+# obviously a test fixture (14-character all-zeros payload, NOT a real
+# uuid4-generated value).
+SESSION_VISIBILITY_SESSION_ID = "00000000-0000-0000-0000-00000000bbbb"
+
+_SESSION_VISIBILITY_USER = UserRecord(
+    id=SESSION_VISIBILITY_USER_ID,
+    email="set-session-vis@finlet.dev",
+    tier=UserTier.FREE,
+    created_at=datetime(2024, 1, 1, tzinfo=timezone.utc),
+)
+
+_SESSION_VISIBILITY_BASE_TIME = datetime(2024, 1, 2, 14, 30, tzinfo=timezone.utc)
+
+
+def _mock_session_visibility_auth(monkeypatch: Any) -> None:
+    """Plant SESSION_VISIBILITY_API_KEY into a fake AuthService for MCP auth.
+
+    Mirrors the propagation pattern in
+    ``tests/mcp/test_session_lifecycle_blind.py::_mock_auth`` — the root
+    conftest's ``_legacy_api_key_test_shim`` patches the binding on
+    server / tools_portfolio / tools_trading / tools_benchmark but NOT
+    tools_session, which was added later (Public Session View, 2026-05-12).
+    Without this forward, ``set_session_visibility`` hits the Phase 4e
+    Bearer-only production rejection envelope.
+    """
+    _SESSION_VISIBILITY_USER.sessions_today = 0
+    _SESSION_VISIBILITY_USER.active_sessions = 0
+    fake_service = AuthService()
+    key_hash = hashlib.sha256(SESSION_VISIBILITY_API_KEY.encode()).hexdigest()
+    fake_service.insert_record(key_hash, _SESSION_VISIBILITY_USER)
+    monkeypatch.setattr("finlet.mcp.auth.auth_service", fake_service)
+    monkeypatch.setattr("finlet.auth.service.auth_service", fake_service)
+
+    from finlet.mcp import bearer_context as _bc
+
+    monkeypatch.setattr(
+        "finlet.mcp.tools_session.resolve_credential", _bc.resolve_credential
+    )
+
+
+def _make_visibility_session(
+    *,
+    user_id: str = SESSION_VISIBILITY_USER_ID,
+    session_id: str = SESSION_VISIBILITY_SESSION_ID,
+    public: bool = False,
+    anonymous: bool = True,
+) -> Session:
+    """Construct a non-blind session for set_session_visibility coverage.
+
+    Non-blind (``blind=False``) so the response passes through
+    :func:`session_response` with ``blind_mapping=None`` — owner-view
+    shape preserved, matches the Phase 4e Bearer-only contract.
+    """
+    config = SessionConfig(
+        start_time=_SESSION_VISIBILITY_BASE_TIME,
+        end_time=_SESSION_VISIBILITY_BASE_TIME + timedelta(days=30),
+        initial_capital=100_000.0,
+        universe=["AAPL", "MSFT"],
+        time_step="1d",
+        blind=False,
+        public=public,
+        public_anonymous=anonymous,
+    )
+    session = Session(
+        config,
+        session_id=session_id,
+        user_id=user_id,
+        name="visibility-test-session",
+    )
+    session.activate()
+    return session
+
+
+class TestMcpSetSessionVisibilitySchemaKeys:
+    """Pin v2.0.0 contract: response uses ``public_anonymous`` NOT ``anonymous``.
+
+    Step 10b BLOCKER-3 — the INPUT param is named ``anonymous`` but the
+    OUTPUT field on :class:`finlet.api.schemas.session.SessionResponse` is
+    ``public_anonymous``.  A reasonable-looking refactor that aliases the
+    response key to ``anonymous`` would drift the contract silently — these
+    tests catch that.
+    """
+
+    @pytest.mark.asyncio
+    async def test_publish_anonymous_emits_public_anonymous_true(
+        self, monkeypatch: pytest.MonkeyPatch
+    ) -> None:
+        """``public=True, anonymous=True`` → ``public AND public_anonymous`` both True."""
+        _mock_session_visibility_auth(monkeypatch)
+        sessions_map: dict[str, Session] = {}
+        monkeypatch.setattr("finlet.mcp.auth.get_sessions", lambda: sessions_map)
+        monkeypatch.setattr(
+            "finlet.api.services.session_service.persist_session", AsyncMock()
+        )
+
+        session = _make_visibility_session()
+        sessions_map[session.id] = session
+
+        result = await mcp_set_session_visibility(
+            session_id=session.id,
+            public=True,
+            anonymous=True,
+            api_key=SESSION_VISIBILITY_API_KEY,
+        )
+
+        assert "error" not in result, f"Unexpected error: {result}"
+        assert result["public"] is True
+        assert result["public_anonymous"] is True
+        # The INPUT param name ``anonymous`` must NOT appear as a top-level
+        # output key — the response schema field is ``public_anonymous``.
+        assert "anonymous" not in result, (
+            f"Response leaked INPUT param name ``anonymous`` as a top-level "
+            f"key — should be ``public_anonymous`` only (schema drift): {result}"
+        )
+
+    @pytest.mark.asyncio
+    async def test_publish_attributed_emits_public_anonymous_false(
+        self, monkeypatch: pytest.MonkeyPatch
+    ) -> None:
+        """``public=True, anonymous=False`` (attributed flow) → ``public_anonymous`` False."""
+        _mock_session_visibility_auth(monkeypatch)
+        sessions_map: dict[str, Session] = {}
+        monkeypatch.setattr("finlet.mcp.auth.get_sessions", lambda: sessions_map)
+        monkeypatch.setattr(
+            "finlet.api.services.session_service.persist_session", AsyncMock()
+        )
+
+        session = _make_visibility_session()
+        sessions_map[session.id] = session
+
+        result = await mcp_set_session_visibility(
+            session_id=session.id,
+            public=True,
+            anonymous=False,
+            api_key=SESSION_VISIBILITY_API_KEY,
+        )
+
+        assert "error" not in result, f"Unexpected error: {result}"
+        assert result["public"] is True
+        assert result["public_anonymous"] is False
+
+    @pytest.mark.asyncio
+    async def test_unpublish_default_anonymous_true(
+        self, monkeypatch: pytest.MonkeyPatch
+    ) -> None:
+        """``public=False, anonymous=True`` (unpublish flow per cli.py:692).
+
+        The CLI always passed ``anonymous=True`` on the dropped
+        ``finlet session unpublish`` path; agents now hit this directly
+        via MCP. ``public_anonymous`` should still surface in the
+        response as ``True`` (the anonymity preference is persisted even
+        when ``public=False`` so re-publishing later restores it).
+        """
+        _mock_session_visibility_auth(monkeypatch)
+        sessions_map: dict[str, Session] = {}
+        monkeypatch.setattr("finlet.mcp.auth.get_sessions", lambda: sessions_map)
+        monkeypatch.setattr(
+            "finlet.api.services.session_service.persist_session", AsyncMock()
+        )
+
+        # Seed the session pre-published so the unpublish path is
+        # semantically meaningful — set_visibility flips public=False
+        # on a previously-public session.
+        session = _make_visibility_session(public=True, anonymous=True)
+        sessions_map[session.id] = session
+
+        result = await mcp_set_session_visibility(
+            session_id=session.id,
+            public=False,
+            anonymous=True,
+            api_key=SESSION_VISIBILITY_API_KEY,
+        )
+
+        assert "error" not in result, f"Unexpected error: {result}"
+        assert result["public"] is False
+        assert result["public_anonymous"] is True
+
+    @pytest.mark.asyncio
+    async def test_response_does_not_include_share_url(
+        self, monkeypatch: pytest.MonkeyPatch
+    ) -> None:
+        """Anti-shape-drift: response MUST NOT include ``share_url``.
+
+        The dashboard / agent derives the public URL externally as
+        ``https://finlet.dev/sessions/{id}`` — embedding it in the MCP
+        response would couple the tool shape to the deployment URL and
+        violate the contract pinned in
+        :class:`finlet.api.schemas.session.SessionResponse`.  This
+        assertion locks the absence so a well-intentioned helper that
+        adds ``d["share_url"] = ...`` to ``session_response`` is caught
+        at PR time.
+        """
+        _mock_session_visibility_auth(monkeypatch)
+        sessions_map: dict[str, Session] = {}
+        monkeypatch.setattr("finlet.mcp.auth.get_sessions", lambda: sessions_map)
+        monkeypatch.setattr(
+            "finlet.api.services.session_service.persist_session", AsyncMock()
+        )
+
+        session = _make_visibility_session()
+        sessions_map[session.id] = session
+
+        result = await mcp_set_session_visibility(
+            session_id=session.id,
+            public=True,
+            anonymous=True,
+            api_key=SESSION_VISIBILITY_API_KEY,
+        )
+
+        assert "error" not in result, f"Unexpected error: {result}"
+        assert "share_url" not in result, (
+            f"Response leaked ``share_url`` key (shape-drift) — consumers "
+            f"derive the URL as ``https://finlet.dev/sessions/{{id}}`` "
+            f"externally; the MCP tool shape MUST NOT include it: {result}"
+        )
+
+
 # ── Tools registered for FastMCP discovery ──────────────────────
 
 

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet diff 014329f''^ 014329f -- tests/test_cli.py | rg -n "''^[-+].*(auth_logout|logout|auth status|auth login|register|plugins|manual|serve|mcp serve|version|RootFlags|TestAuth|TestPlugins|TestRegister|TestTopLevel|TestRoot)"' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
10:-* **KEEP commands** (``serve``, ``register``, ``auth login``, ``auth logout``,
11:-  ``plugins list/add/remove``) continue to call REST via httpx.  Their tests
20:-exercise the real subprocess + live server end-to-end.
24:+* ``serve`` (REST/MCP server bootstrap)
25:+* ``register`` (one-shot account creation, calls REST)
26:+* ``manual`` (offline manual viewer, no I/O)
27:+* sub-app ``plugins`` — ``list`` / ``add`` / ``remove`` (operator plugin admin)
28:+* sub-app ``auth`` — ``login`` / ``logout`` / ``status`` (OAuth credential mgmt)
29:+* sub-app ``mcp`` — ``serve`` (run MCP server over stdio)
69:-    def test_session_subcommands_registered(self):
70:-        """Verify create, list, and delete subcommands are registered."""
234:-        Protects the non-blind UX in case an older server build doesn't echo the
236:-        blind server contract always includes ``universe`` with opaque ids.
414:-        assert "finlet auth login" in result.output
427:-                "Run 'finlet auth login' to obtain an OAuth Bearer token."
1134:+# ─── register ────────────────────────────────────────────────────────
1142:+# ─── auth login ─────────────────────────────────────────────────────
1152:+# ─── auth status ────────────────────────────────────────────────────
1172:+# ─── plugins list/add/remove ─────────────────────────────────────────
1194:-        for cmd in ("register", "advance", "order", "portfolio", "status", "session", "plugins", "auth", "mcp"):
1195:+        for cmd in ("serve", "register", "manual", "plugins", "auth", "mcp"):
1198:+    def test_dropped_agentic_commands_not_registered(self):
1470:-        assert "finlet auth login" in captured.err
1504:-        mock_client.post.side_effect = httpx.ConnectError("nameserver lookup failed")
1511:-        # ``finlet auth login`` hint downstream.

exec
/bin/zsh -lc "git -C /Users/justnau/finlet grep -n \"auth logout\\|logout\" 014329f"'^ -- tests/test_cli.py tests/test_cli_help.py tests/test_cli_oauth_login.py' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
014329f^:tests/test_cli.py:5:* **KEEP commands** (``serve``, ``register``, ``auth login``, ``auth logout``,
014329f^:tests/test_cli_oauth_login.py:9:* The ``finlet auth logout`` subcommand.
014329f^:tests/test_cli_oauth_login.py:417:# auth logout
014329f^:tests/test_cli_oauth_login.py:422:    def test_logout_deletes_file(self, home_sandbox):
014329f^:tests/test_cli_oauth_login.py:423:        """``finlet auth logout`` removes ~/.finlet/credentials."""
014329f^:tests/test_cli_oauth_login.py:431:        result = runner.invoke(app, ["auth", "logout"])
014329f^:tests/test_cli_oauth_login.py:437:    def test_logout_no_file(self, home_sandbox):
014329f^:tests/test_cli_oauth_login.py:438:        """``finlet auth logout`` is idempotent — no-op when no file present."""
014329f^:tests/test_cli_oauth_login.py:441:        result = runner.invoke(app, ["auth", "logout"])
014329f^:tests/test_cli_oauth_login.py:495:    def test_auth_logout_help(self, home_sandbox):
014329f^:tests/test_cli_oauth_login.py:496:        """``finlet auth logout --help`` works (subcommand registered)."""
014329f^:tests/test_cli_oauth_login.py:497:        result = runner.invoke(app, ["auth", "logout", "--help"])

exec
/bin/zsh -lc "grep -c 'result\\[\"public_anonymous\"\\]' /Users/justnau/finlet/tests/mcp/test_decrypt_visibility_tools.py" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
3

exec
/bin/zsh -lc "grep -c '\"share_url\" not in result' /Users/justnau/finlet/tests/mcp/test_decrypt_visibility_tools.py" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
1

exec
/bin/zsh -lc 'git -C /Users/justnau/finlet diff 014329f''^ 014329f -- tests/mcp/test_decrypt_visibility_tools.py | rg -n "'"\\+.*(eyJ[A-Za-z0-9_-]{20,}|fnlt_[a-f0-9]{32})\" || true" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
exec
/bin/zsh -lc 'git -C /Users/justnau/finlet diff --check 014329f''^ 014329f' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
exec
/bin/zsh -lc 'git -C /Users/justnau/finlet diff 014329f''^ 014329f -- tests/mcp/test_decrypt_visibility_tools.py | rg -n "'"\\+.*result\\[\\\"anonymous\\\"\\]|\\+.*result\\['anonymous'\\]\" || true" in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
exec
/bin/zsh -lc 'git -C /Users/justnau/finlet status --short' in /Users/justnau/finlet/.claude/worktrees/agent-ac344962ac027859f
 succeeded in 0ms:
 M docs/brainstorms/codex-diff-reviews/team-A.md
 M docs/brainstorms/codex-diff-reviews/team-C.md
 M docs/brainstorms/codex-diff-reviews/team-D.md
 M docs/brainstorms/exec-trace.txt
 M docs/brainstorms/team-prompts/team-A.md
 M docs/brainstorms/team-prompts/team-B.md
 M docs/brainstorms/team-prompts/team-C.md
 M docs/brainstorms/team-prompts/team-D.md
 M docs/brainstorms/team-prompts/team-E.md
?? docs/brainstorms/V2_PURE_MCP_EXECUTION_PLAN.md

codex
The hygiene grep is clean for `eyJ...` and `fnlt_<32hex>`, and the exact assertion counts match the spec: three `result["public_anonymous"]` checks plus one `"share_url" not in result`. I’m running the narrow affected test set now so the gate can distinguish static review from actual verification.
exec
/bin/zsh -lc 'uv run pytest tests/test_cli.py tests/test_cli_help.py tests/test_cli_oauth_login.py tests/mcp/test_decrypt_visibility_tools.py -q' in /Users/justnau/finlet
 succeeded in 3419ms:
........................................................................ [ 93%]
.....                                                                    [100%]
77 passed in 2.50s

codex
NIT [fixture hygiene]: [tests/mcp/test_decrypt_visibility_tools.py](/Users/justnau/finlet/tests/mcp/test_decrypt_visibility_tools.py:413) uses a UUID-shaped session fixture (`00000000-0000-0000-0000-00000000bbbb`). It is low-entropy and does not match the forbidden JWT/API-key patterns, so not blocking, but `aaaaaaaaaaaaaa` would better match Team B’s fake-fixture guidance while still passing `validate_session_id`.

No BLOCKER or STRONG-SUGGESTION findings.

Verified:
- Scope limited to the 5 allowed test files.
- All 4 required `set_session_visibility` assertions are present and use `result["public_anonymous"]`.
- No `result["anonymous"]` assertion added.
- No `eyJ...` JWTs or `fnlt_<32hex>` API keys added.
- Kept CLI command coverage remains for serve/register/auth/plugins/manual/mcp/root/version surfaces.
- Commit message matches the diff.
- Targeted tests passed: `77 passed in 2.50s`.

GATE: PASS
tokens used
118,696
NIT [fixture hygiene]: [tests/mcp/test_decrypt_visibility_tools.py](/Users/justnau/finlet/tests/mcp/test_decrypt_visibility_tools.py:413) uses a UUID-shaped session fixture (`00000000-0000-0000-0000-00000000bbbb`). It is low-entropy and does not match the forbidden JWT/API-key patterns, so not blocking, but `aaaaaaaaaaaaaa` would better match Team B’s fake-fixture guidance while still passing `validate_session_id`.

No BLOCKER or STRONG-SUGGESTION findings.

Verified:
- Scope limited to the 5 allowed test files.
- All 4 required `set_session_visibility` assertions are present and use `result["public_anonymous"]`.
- No `result["anonymous"]` assertion added.
- No `eyJ...` JWTs or `fnlt_<32hex>` API keys added.
- Kept CLI command coverage remains for serve/register/auth/plugins/manual/mcp/root/version surfaces.
- Commit message matches the diff.
- Targeted tests passed: `77 passed in 2.50s`.

GATE: PASS

---
## Verdict: GATE PASS (no BLOCKER, no STRONG, 1 NIT)

NIT (logged, not fixed): UUID-shaped session fixture '00000000-0000-0000-0000-00000000bbbb' at tests/mcp/test_decrypt_visibility_tools.py:413. Codex notes it's low-entropy and doesn't match forbidden patterns; suggested 'aaaaaaaaaaaaaa' for stricter fake-fixture compliance. Non-blocking — pattern matches existing test_session_lifecycle_blind.py fixtures.

## Cross-session test fix (sha 3957bab)
Team B's full-suite gate after merge caught test_manual_generate_llms_txt.py::test_body_advertises_hosted_mcp_first failing — Team C had inverted the lede in llms.txt but the test still asserted hosted-MCP-first. Fix-on-main at 3957bab renamed to test_body_advertises_stdio_mcp_first and inverted the ordering assertion. Targeted re-run: 7/7 pass.
