# Session-Level Blind Mode — Requirements (v2, post-Codex Step 1.5)

> v1 brainstormed: 2026-05-22
> v2 amended: 2026-05-22 after Codex Step 1.5 adversarial review (6 BLOCKERs, 5 STRONG-SUGGESTIONs, 3 NITs)
> Status: Ready for `/plan-features` Step 2 recon
> Source: live conversation 2026-05-22; verifications by Explore + general-purpose research agents + Codex adversarial review

## Context

User's original ask was to edit landing-page copy: remove "news" claims (believed post-launch) and add blind benchmarking as a hero-level differentiator on the basis that "Finlet's whole point is blind benchmarking, users can pick any time period, blind is toggleable on any session."

Research verified three of four claims do NOT match current code:

- Blind is NOT toggleable on `create_session` — only via `start_benchmark`. No `blind` field on `SessionCreateRequest` (`finlet/api/routes_session.py:49-70`), no blind kwarg in MCP `create_session` (`finlet/mcp/server.py:270-281`), no blind kwarg in service-layer `create_session` (`finlet/api/services/session_service.py:383-396`).
- Custom-period blind is NOT supported — `start_benchmark` accepts only `(agent_name, blind)` (`finlet/mcp/tools_benchmark.py:243-312`) and iterates 5 hardcoded scenarios in `BENCHMARK_SCENARIOS` (`finlet/leaderboard/benchmarks.py:41-95`).
- Blind benchmark is positioned as "the core differentiator of Finlet's **benchmark** vs. a simple backtest" (`docs/ARCHITECTURE.md:1620`), not as the core of the product. `README.md:9-11` leads with "An evaluation harness for AI trading agents" / "Test your AI agent's reasoning."
- 6-ticker universe (`finlet/leaderboard/benchmarks.py:32-39` — AAPL, MSFT, NVDA, AMZN, GOOGL, BTC-USD) IS correct for blind/benchmark; non-blind user sessions support up to 50 user-chosen tickers (`finlet/api/routes_session.py:54` `max_length=50`) drawn from a CATALOG of 270 tickers (199 US equities + 71 US ETFs; crypto excluded per `_UNIVERSE_SOURCES` in `finlet/api/routes_market.py:294`). Two distinct numbers: 50 = per-session universe cap; 270 = total catalog size (what `list_available_tickers` returns).

User selected **Path B**: build session-level blind, then advertise. Landing-page hero rewrite is deferred until the feature ships. (Feature 2 — landing-page news copy softening — has been REMOVED from this planning input per Codex STRONG-SUGGESTION 11; ship as a separate trivial Edit, not a planned feature.)

## Primary user story (added per Codex STRONG-SUGGESTION 8)

> "As an AI-trading-agent developer dogfooding Finlet, I want to give my agent a custom blind session — over any period, with any universe I choose — so I can stress-test agent reasoning under symbol/date anonymization on ad-hoc scenarios, not only the 5 canonical benchmark scenarios. As the session owner, I always see real tickers and dates in my own dashboard / REST; my agent (via MCP) always sees `T_NNNN` / `Day_N`. When I opt the session public-anonymous (existing flag), public viewers see the blinded view; when I opt public-non-anonymous, the session is revealed. No new decrypt lifecycle is required — visibility flags ARE the reveal lifecycle."

This user story drives every downstream behavior decision below.

## Audience-specific blind behavior (added per Codex BLOCKER 1; v3 correction 2026-05-22 — see note)

> **v3 correction (2026-05-22, Team F, post-exec-plan v12):** The v2 matrix below oversimplified the "Authenticated owner" column to "Real everywhere." HEAD `b1a305f` reality is MIXED — owner sees REAL on some REST surfaces and BLINDED on others (`/trace`, `/market/*`, `/sse`). This work PRESERVES that mix; it does NOT harmonize. The authoritative surface-by-surface breakdown lives in the exec-plan v12 "Audience contract" table (`docs/brainstorms/SESSION_LEVEL_BLIND_EXECUTION_PLAN.md` lines 21-38). The matrix below has been corrected to the HEAD-accurate summary; refer to the plan for per-route detail. The reveal-lifecycle claim has been narrowed accordingly — visibility flags ARE the public-viewer reveal mechanism, but they do NOT harmonize owner-surface inconsistency (that work is deferred — see "Deferred Ideas" entry below).

| Surface | Authenticated owner | Agent (MCP, owner-authed, custom blind session) | Anonymous public viewer (session opted `public=True, public_anonymous=True`) | Public non-anonymous viewer (`public=True, public_anonymous=False`) |
|---|---|---|---|---|
| REST `routes_session.py` (`GET /v1/sessions/{id}`, list, create, configure, visibility) | Real tickers + ISO dates | n/a (REST is owner/dashboard) | Blinded (`T_NNNN`, `Day_N`) — via `routes_public_session.py` | Real |
| REST `routes_portfolio.py` (`/portfolio`, `/portfolio/history`) | Real | n/a | Blinded | Real |
| REST `routes_portfolio.py::/trace` | **Blinded** (HEAD passes `blind_mapping=_blind_mapping_for(session)`) | n/a | Blinded | Real |
| REST `routes_clock.py`, `routes_trade.py` | Real | n/a | Blinded | Real |
| REST `routes_market.py` (`/price`, `/fundamentals`, `/filings`, `/search-news`) | **Blinded** (HEAD blinds for any `session.config.blind=True`, including owner audience) | n/a | Blinded | Real |
| REST `routes_sse.py` SSE | **Blinded** (HEAD passes `blind_mapping=_blind_mapping_for(session)`) | n/a | Blinded | Real |
| REST `POST /v1/sessions/{id}/complete` | Mostly REAL — `benchmark_complete` envelope blinded at service layer; `benchmark_transition` envelope blinding fires in MCP only (REST gets real transition); non-benchmark completion returns REAL `session_response(session)` | n/a | Blinded | Real |
| MCP tools (`get_session`, `get_portfolio`, `get_price_data`, `get_fundamentals`, `submit_order`, `get_trace`, etc.) | n/a (MCP is the agent surface) | Blinded (`T_NNNN`, `Day_N`) — all `@blind_error_mapper`-decorated tools enumerated dynamically at test time (current footnote: ~34 callsites) | Blinded (anonymous public reads use the same MCP-style blind) | Real |
| MCP `complete_session` | n/a | Blinded final summary (envelope MUST mirror benchmark `complete_session` blind contract; non-benchmark path scoped to `status == "COMPLETED"`) | Blinded | Real |
| MCP clock tools (`get_sim_time`, `advance_time`, `freeze_time`) | n/a | Blinded — `freeze_time` gap closed in this work (Team B); `get_sim_time` + `advance_time` already blinded in HEAD | Blinded | Real |
| Persisted trace (replay) | Blinded if replayed through agent surface; real if owner exports via owner-route | Blinded | Blinded | Real |
| CLI (`finlet sessions get`, etc.) | Dispatches MCP — see MCP rows above | n/a | n/a | n/a |
| Exports / owner-route decrypt artifact (benchmark-only) | Real (owner-routed) | n/a | n/a | n/a |

**Reveal lifecycle (replaces Codex BLOCKER 2; narrowed 2026-05-22):** there is NO new decrypt lifecycle for custom blind sessions. Public viewer visibility is controlled by the EXISTING `session.config.public` + `session.config.public_anonymous` flags via the EXISTING `set_session_visibility` MCP/REST/CLI surface — toggling `public_anonymous=False` reveals to public viewers; toggling back to `True` re-blinds public viewers. No persisted `revealed_at` state needed.

**The owner-surface inconsistency above (REAL on `routes_session.py` / `routes_portfolio.py::/portfolio` / `routes_clock.py` / `routes_trade.py`; BLINDED on `routes_portfolio.py::/trace` / `routes_market.py` / `routes_sse.py`) is NOT corrected by the visibility flags** — visibility flags toggle public-viewer behavior only. Harmonizing the owner surfaces would require a new "owner-authenticated" axis on `_blind_mapping_for` and is deferred to a future iteration (see Deferred Ideas).

**Implication for `decrypt_benchmark_run` analogue:** REMOVED from scope. The original v1 requirement "Owner can decrypt their own custom-blind session post-completion (analogue to `decrypt_benchmark_run`)" is REPLACED with "Owner sees real on some surfaces today (per the matrix above); visibility toggle is the public-viewer reveal mechanism — no new tool."

## Day_N edge-case contract (added per Codex BLOCKER 3)

- `start_time` is REQUIRED and validated existing (no change).
- `end_time` MAY be omitted (per `finlet/core/session.py:63-64` — already `Optional`). Day_N anchors on the session's `start_time` as Day_0 and advances as the simulation clock advances. There is no length cap added; Day_N renders correctly for any duration.
- Multi-year sessions (e.g., 10-year backtest) are explicitly supported. Day_3650 is the blinded label for "10 years after Day_0" — no information leak beyond "the session ran for that long," which the owner controls by their input.
- Timezone: all internal datetimes are UTC (per project convention). Day_N is computed in UTC. If a user passes a timezone-aware `start_time`, it is normalized to UTC before Day_0 anchoring (existing behavior).
- Negative Day_N or Day_N > session duration is impossible at runtime (clock never moves backward; clock cannot exceed end_time when set).

## complete_session blind contract (added per Codex BLOCKER 4)

- `complete_session` for a custom blind session MUST return blinded envelope identical in shape to the canonical benchmark `complete_session` blind path.
- Required blinded fields in `complete_session` response: `final_value` (real, scalar), `positions[].ticker` (`T_NNNN`), `trades[].ticker` (`T_NNNN`), `trades[].timestamp` (`Day_N`), `trades[].entry_date` / `exit_date` (`Day_N`), `equity_curve[].timestamp` (`Day_N`), any envelope-level `start_time` / `end_time` / `latest_date` / `as_of_date` keys (`Day_N`), `benchmark_ticker` (`T_NNNN`).
- The chokepoint helper `assert_no_real_blinded_data` MUST pass on the entire serialized payload.
- Plus the broader leak-detector (see BLOCKER 5 resolution below).

## Test plan — leak detection (added per Codex BLOCKER 5)

The acceptance gate for "leak-free" is BOTH-AND, not OR:

1. **Structural chokepoint:** `assert_no_real_blinded_data(payload, session.blind_mapping)` MUST return cleanly on every owner-facing-but-blind-routed response in tests.
2. **Serialized grep gate:** the test extends `tests/e2e/test_blind_benchmark_zero_leak.py` (the canonical grep gate per `.claude/rules/core-engine.md` "Blind mapping" section). Every `@blind_error_mapper`-decorated MCP tool MUST be exercised against a custom blind session; the serialized JSON response is `grep`'d for:
   - Every real ticker from the user-supplied universe (must produce 0 hits)
   - Every benchmark/reference ticker that the session touches (`benchmark_ticker`, currently always `SPY` — must produce 0 hits; mirrors PR #117 invariant from `_KNOWN_BENCHMARK_TICKERS`)
   - Real ISO date strings within the session's date range (must produce 0 hits)
3. **Envelope sweep:** mirror the gate added in PR #117 (Codex bug 50abd05e) which exercises 14 owner-view tools for envelope-level leaks; extended to cover the new session-level blind entry point.
4. **SSE + trace replay:** Server-Sent Event payloads AND persisted-trace replays against a custom blind session pass the same two-axis gate.

## Tool coverage — dynamic enumeration (added per Codex BLOCKER 6)

The v1 requirement "All 17 `@blind_error_mapper`-decorated MCP tools" is REPLACED with: "All `@blind_error_mapper`-decorated MCP tools, enumerated dynamically at test runtime from the MCP server registry, MUST pass leak gates for a custom blind session. Current count is ~34 callsites across `finlet/mcp/server.py`, `finlet/mcp/tools_session.py`, `finlet/mcp/tools_portfolio.py`, `finlet/mcp/tools_trading.py`, `finlet/mcp/tools_benchmark.py`, `finlet/mcp/tools_telemetry.py`; precise count is for recon to confirm and the test to derive at runtime."

## Constraints

- Existing `start_benchmark(blind=True)` flow stays green — no regressions to canonical 5-scenario benchmark blind. Concrete acceptance: every test under `tests/leaderboard/test_*blind*` and `tests/mcp/test_*blind*` and `tests/e2e/test_blind_benchmark_zero_leak.py` continues to pass with zero modification to assertions about benchmark behavior.
- Codex adversarial review must pass at all 5 plan-features / exec-plan checkpoints (Steps 1.5, 10a, 10b in plan-features; Step 2 per-merge and Step 4.5 retest in exec-plan).
- All `@blind_error_mapper`-decorated MCP tools (dynamically enumerated, see BLOCKER 6 resolution) continue leak-free for custom blind sessions.
- No new MCP tool surface for the create path — extend existing `create_session` signature (per Codex STRONG-SUGGESTION 9, softened: "avoid introducing a separate `create_blind_session`; planner may justify a new tool if extension proves more invasive than addition, but the default is extension"). New tools MAY be added for adjacent concerns if planning surfaces a clean reason (e.g., a `decrypt_session` tool if the visibility-flag-as-reveal approach proves insufficient — currently NOT expected per BLOCKER 2 resolution).
- Pre-launch but post-Stripe-live (per `project_stripe_live_activation_done.md`) — don't break paid-GA / billing paths. Concrete acceptance: `tests/billing/`, `tests/auth/`, and rate-gate tests under `tests/api/` retain green; existing session creation rate limits (`check_session_creation`) apply identically to blind and non-blind sessions.
- Reuse existing blind plumbing (`ticker_map`, `@blind_error_mapper`, SSE blinding, persisted-trace blinding, `assert_no_real_blinded_data` chokepoint, `_KNOWN_BENCHMARK_TICKERS` frozenset, `BlindMapping` class) — don't fork it. New code shares the SAME `create_scenario_session`-style ticker_map attachment logic, refactored to a shared helper if the benchmark path is touched at all.
- MCP-first architecture preserved (per Codex STRONG-SUGGESTION 7 + `docs/ARCHITECTURE.md:601-603`): MCP `create_session` is the CANONICAL behavior contract. REST `POST /v1/sessions` and CLI `finlet sessions create` are required to preserve parity but their behavior is derived from / dispatched through MCP (CLI already dispatches via MCP per `finlet/cli.py:584-604`).

## Features

### 1. Session-level blind mode

**Description:** Add `blind: bool` (default `False`) to `create_session` across MCP (`mcp__finlet__create_session`, canonical), REST (`POST /v1/sessions`, derived), and CLI (`finlet sessions create`, dispatches MCP). When `True`, attach a `BlindMapping` to the session covering (a) the user's chosen universe (up to 50 tickers, existing cap) PLUS (b) `session.config.benchmark_ticker` PLUS (c) any other tracked reference symbols flowing through session/portfolio/history/orders/SSE/trace payloads (per Codex STRONG-SUGGESTION 10 — mirror the PR #126 invariant). Day_N mapping anchors on `start_time`. All subsequent MCP tool calls on that session return blinded data via existing plumbing; owner REST/dashboard sees real (authenticated); public viewers see blinded or real per existing `public` + `public_anonymous` flags.

**Success criteria (concrete, testable):**
1. REST `SessionCreateRequest` (`finlet/api/routes_session.py:49-70`) accepts `blind: bool = False`. `POST /v1/sessions` with `{"blind": true, "universe": [...], "start_time": ..., "end_time": ...}` returns 201 with a session whose `config.blind == True` and `blind_mapping` is populated.
2. MCP `create_session` (`finlet/mcp/server.py:270-281`) accepts `blind: bool = False`. `mcp__finlet__create_session(blind=True, universe=[...], start_time=..., end_time=...)` returns a session response with the same shape.
3. Service-layer `create_session` (`finlet/api/services/session_service.py:383-396`) accepts `blind: bool = False`. Internally, when `blind=True`, it constructs a `BlindMapping` for the session covering: user universe (uppercased + deduped per NIT 2), `session.config.benchmark_ticker`, plus any tracked reference symbols listed in the BlindMapping invariant.
4. CLI `finlet sessions create` accepts `--blind` (boolean flag, default False). CLI flag syntax decision: `--blind` over `--mode blind` (matches existing flag idiom in `finlet/cli.py`).
5. ALL `@blind_error_mapper`-decorated MCP tools (dynamically enumerated at test time) return `T_NNNN` tickers and `Day_N` dates only, when called against a custom blind session. Verified by BOTH the structural chokepoint AND the serialized grep gate (BLOCKER 5 resolution).
6. News plugin continues short-circuiting in blind sessions (existing policy unchanged; locate at `finlet/plugins/news_*.py` and verify the existing blind-short-circuit branch still triggers for `session.config.blind == True`).
7. `complete_session` for a custom blind session returns the blinded envelope contract above (BLOCKER 4 resolution).
8. Visibility flags as reveal lifecycle: toggling `set_session_visibility(public_anonymous=False)` on a completed custom blind session reveals the real universe + dates to anonymous public viewers; toggling back re-blinds.
9. Existing `start_benchmark(blind=True)` flow remains green — all canonical benchmark-blind tests pass without modification.
10. Test coverage spans EVERY axis: positive create flow (REST/MCP/CLI), leak assertions on every owner-facing-but-blind-routed response body, error envelope blinding, SSE event payloads, persisted trace payloads, `complete_session` payload, post-completion `set_session_visibility` toggles. Negative-test the "no leak" gate by intentionally bypassing blind plumbing in a fixture and confirming the gate fails loudly.
11. No regression in paid-GA / billing tests (per Constraints above).

**Out of scope:**
- Leaderboard integration — custom blind sessions never appear on the leaderboard (scenario-locked); requires explicit `BenchmarkRun` entry which custom blind sessions do not produce.
- News policy changes — short-circuit unchanged.
- Landing page copy rewrite — deferred to a follow-up brainstorm once feature ships.
- Adding a separate `create_blind_session` MCP tool — extension only, per softened constraint (planner may justify but bar is high).
- Adding a `decrypt_session` MCP tool — existing visibility flags handle reveal (BLOCKER 2 resolution).
- Database migration for new `revealed_at` / `decrypted_universe` columns — not needed under the visibility-flag-as-reveal model.

**Research notes (re-verified for v2):**
- Existing benchmark blind enters via `start_benchmark` (`finlet/mcp/tools_benchmark.py:243-312`) → `create_scenario_session` in `finlet/leaderboard/benchmark_state.py`. New custom-blind path should share the ticker_map / Day_N attachment logic — recon to determine whether refactor-to-shared-helper or layer-on-top is the right shape.
- `SessionConfig.blind` already exists at `finlet/core/session.py:91` (the field is plumbed; only the *entry point* is missing).
- `set_session_visibility` already exists as the reveal surface: MCP at `finlet/mcp/tools_session.py:45`, REST at `finlet/api/routes_session.py:244`, CLI at `finlet/cli.py:675`.
- `_DEFAULT_UNIVERSE` at `finlet/leaderboard/benchmarks.py:32-39` (6 tickers); custom blind sessions use the caller's universe up to the existing 50-cap.
- Universe cap of 50 enforced at `finlet/api/routes_session.py:54` — applies identically to non-blind and custom blind.
- ARCHITECTURE.md:1620 documents agent-blinding as benchmark differentiator (now extending to all sessions opt-in).
- Adversarial-review history: 5+ rounds of Codex blind-bug fixes (ce8de077, 50abd05e, d1baf1b8 / ad919e11 / 53c9eccb, a93a7ff2, 2cd01283); most recent 2026-05-22. Every new entry point to blind plumbing is new surface for the same class of leak bug.
- Universe normalization (NIT 2 resolution): tickers MUST be uppercased and deduped at service-layer entry before blind-mapping seeding. Existing non-blind path also benefits from this normalization — recon to confirm current behavior at `finlet/api/routes_session.py:63-70`.

**Open decisions (for planner — explicitly NOT decisions in this requirements doc, deferred to Step 2 recon + Step 3 team decomposition):**
- Refactor existing benchmark-blind path to share new code, or layer custom-blind on top without touching benchmark path — depends on diff-size and risk surfaced by recon.
- Whether `complete_session` for non-benchmark custom blind needs a service-layer change to pass `blind_mapping` into `session_response()`, or whether MCP-layer envelope blinding (mirror of `finlet/mcp/server.py:572-634`) is preferred.
- Whether the existing news short-circuit logic key on `session.config.blind` OR a derived `session.has_blind_mapping` predicate.
- Whether to expose `blind` in the session response shape (allowing dashboard to show a "blind active" badge for owners) — informational only.

### 2. Landing page news copy softening — REMOVED from this planning input

Per Codex STRONG-SUGGESTION 11, the trivial 3-line landing.html edit is REMOVED from this brainstorm doc to avoid mixing marketing-copy work with architecture work. It ships separately as a direct Edit (5-minute task), not a planned feature. The 3 specific edits (Line 7 meta description, Line 37 hero subtitle, Line 90 "Real Data Sources" card) remain on the user's todo list as a follow-up; this doc no longer plans for them.

## Deferred Ideas

- **Landing page hero rewrite featuring session-level blind** — deferred until Feature 1 ships so copy can describe what actually works.
- **Custom-period blind on leaderboard** — out of scope for v1; leaderboard stays scenario-locked.
- **News-included blind sessions** (allowing news in blind with explicit leak caveat) — deferred; v1 keeps short-circuit unchanged.
- **Repositioning README / top-level pitch around blind benchmarking** — deferred; current "evaluation harness" framing stands.
- **`decrypt_session` MCP tool** — explicitly deferred (BLOCKER 2 resolution: not needed under visibility-flag-as-reveal model). Reconsider if planner / exec-plan surfaces a concrete user-facing gap.
- **Owner-visible "blind active" badge in dashboard** — UX nicety, not load-bearing for feature acceptance. `SessionResponse.blind: bool` is populated by this work so the badge can land as a follow-up dashboard-only PR.
- **Owner-surface audience harmonization (added 2026-05-22, Team F)** — HEAD's owner-surface behavior is MIXED: REAL on `routes_session.py` / `routes_portfolio.py::/portfolio` / `routes_clock.py` / `routes_trade.py`; BLINDED on `routes_portfolio.py::/trace` / `routes_market.py` / `routes_sse.py`. This work preserves that mix to keep blast radius bounded. A future iteration can introduce an "owner-authenticated" axis on `_blind_mapping_for` so all owner-routed REST surfaces return REAL consistently. Decision record `docs/decisions/session-level-blind-extends-create-session.md` (Out-of-Scope + Deferred sections) tracks the boundary.

## Killed Ideas

- **Strip news mentions entirely from landing page** — superseded by 3-line soften (which is now REMOVED from this planning input, see Feature 2 section).
- **Path A: hero blind benchmarking against today's 5-scenario reality only** — replaced with Path B (build first, then advertise).
- **Hero-level blind copy before session-level blind feature exists** — would ship claims the code cannot back.
- **`decrypt_benchmark_run` analogue for custom blind sessions** — KILLED in v2 (Codex BLOCKER 2 resolution). Owner always sees real on owner surfaces; public visibility uses existing `set_session_visibility`. No new decrypt machinery.

## Codex review (Step 1.5) — v1 findings + v2 responses

| # | Finding | Type | v2 response |
|---|---|---|---|
| 1 | Audience-specific blind behavior not specified (line 33 collapses 3 audiences) | BLOCKER | Added explicit audience-behavior matrix above; owner=real, agent/anonymous=blinded |
| 2 | Session-level decrypt lifecycle doesn't exist; `decrypt_benchmark_run` doesn't analogize to `Session` | BLOCKER | Reframed: owner already sees real (authenticated); visibility flags ARE the reveal lifecycle. `decrypt_session` removed from scope |
| 3 | Day_N undefined for open-ended / multi-year / timezone-shifted sessions | BLOCKER | Added Day_N edge-case contract: anchors on `start_time` (Day_0); end_time may be omitted; UTC normalization; no length cap |
| 4 | `complete_session` blind contract undefined for non-benchmark path | BLOCKER | Added complete_session blind contract spec: blinded envelope shape mirrors benchmark, leak gates apply |
| 5 | `assert_no_real_blinded_data` alone insufficient as zero-leak gate | BLOCKER | Test plan now requires BOTH structural chokepoint AND serialized grep gate (per `test_blind_benchmark_zero_leak.py` pattern); negative-test the gate itself |
| 6 | "All 17 tools" count is stale; actual is ~34 | BLOCKER | Replaced with dynamic enumeration at test runtime; "~34" footnote-only |
| 7 | REST/MCP/CLI co-equal conflicts with MCP-first architecture | STRONG-SUGGESTION | Constraint now states "MCP canonical; REST + CLI derived/dispatched"; CLI already dispatches per `finlet/cli.py:584-604` |
| 8 | Missing primary user story driving design | STRONG-SUGGESTION | Added explicit user story section above |
| 9 | "No new MCP tool" locks in implementation prematurely | STRONG-SUGGESTION | Softened: "avoid by default; planner may justify a new tool if extension is more invasive" |
| 10 | ticker_map must cover benchmark/reference symbols, not just user universe | STRONG-SUGGESTION | Success criterion 3 now explicitly enumerates universe + `benchmark_ticker` + tracked reference symbols; mirrors PR #126 invariant |
| 11 | Feature 2 (landing copy) mixed into architecture planning | STRONG-SUGGESTION | Feature 2 REMOVED from this planning input; ships as separate direct Edit |
| 12 | Landing-page line numbers brittle, "reframe" lacks concrete text | NIT | Moot — Feature 2 removed |
| 13 | Universe normalization (uppercase/dedup) unspecified | NIT | Research notes now require uppercase + dedup at service-layer entry |
| 14 | Billing/paid-GA acceptance test unspecified | NIT | Constraints now name `tests/billing/`, `tests/auth/`, rate-gate tests as the gate |

## Hidden risks (Codex)

- Session-level reveal lifecycle: ADDRESSED — visibility flags ARE the lifecycle; no migration needed.
- Public-session anonymity semantics collision: ADDRESSED — audience-behavior matrix above explicitly handles `public=True, public_anonymous=True/False` for blind sessions.
- Legacy sessions with `blind=True` + `blind_mapping=None`: planner / recon to verify that creating a custom blind session ALWAYS produces a populated `blind_mapping` on the session (no path that sets `blind=True` without also seeding mapping). Hard invariant for Step 2 recon.
