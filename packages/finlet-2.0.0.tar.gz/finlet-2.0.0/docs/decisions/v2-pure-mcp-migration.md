# Decision: v2.0.0 Pure-MCP Migration — Delete Human-Facing CLI Surface

**Date:** 2026-05-22
**Status:** Accepted (supersedes [`cli-mcp-http-dispatch.md`](./cli-mcp-http-dispatch.md))
**Source:** v2.0.0 Pure-MCP Migration exec-plan. Triggered by Codex bug-hunt finding 2026-05-22 — `finlet session create` printed real tickers in blind mode because the CLI carried its own divergent display logic separate from the MCP tool's blind-aware path.

## Context

Finlet ships a CLI (`finlet/cli.py`) and an MCP tool surface (`finlet/mcp/`). Twelve CLI subcommands (`session create/list/delete/publish`, `benchmark start/progress/decrypt/visibility`, `advance`, `order`, `portfolio`, `status`) duplicate MCP tools — the CLI dispatches through `_dispatch_mcp_tool` to the cloud `/mcp` endpoint and re-renders the response into a human-readable format. Every duplication is a drift opportunity: the CLI's display logic, error mapping, and envelope decoration must keep pace with the MCP tool's behavior. When they drift, the symptom is a bug like 2026-05-22's — the MCP tool correctly blinded tickers, but the CLI's display path lifted them back from a divergent field.

Finlet's positioning is explicit: **"agentic trading evaluation harness, NOT a human trading sim."** A human-facing CLI for session-create / order / advance / portfolio is off-mission. Agents drive Finlet through the MCP tool surface invoked by their host (Claude Desktop, Codex CLI, Cursor, Windsurf, generic MCP). The CLI's role is bootstrapping: mint credentials, host the MCP stdio bridge, manage plugin credentials, expose the local manual.

The pre-launch zero-customer mandate (`[[project-pre-launch-no-customers]]`) makes this a free move. Post-launch, deleting twelve CLI commands would be a v2.0.0 breaking change with migration friction. Pre-launch, there are no consumers to migrate — the cost is one PyPI version bump.

## Decision

**Delete the twelve human-facing agentic CLI commands and the dispatch shim that powered them. Keep only the minimal CLI needed for MCP to function and for operators to bootstrap.**

### Dropped (12 commands + supporting infrastructure)

| Command | MCP equivalent |
|---|---|
| `finlet session create` | `create_session` |
| `finlet session list` | `list_sessions` |
| `finlet session delete` | `delete_session` |
| `finlet session publish` | `set_session_visibility` |
| `finlet benchmark start` | `start_benchmark` |
| `finlet benchmark progress` | `get_benchmark_progress` |
| `finlet benchmark decrypt` | `decrypt_benchmark_run` |
| `finlet benchmark visibility` | `set_benchmark_visibility` |
| `finlet advance` | `advance_time` |
| `finlet order` | `submit_order` |
| `finlet portfolio` | `get_portfolio` |
| `finlet status` | `get_session` |

Supporting deletions: `_dispatch_mcp_tool`, `_translate_mcp_error`, `_emit_envelope`, `_resolve_bearer_token`, `_AUTH_REQUIRED_MARKERS`, `_AUTH_REQUIRED_HINT`, `_AsyncioTimeoutError` alias, top-level `import asyncio`, `session_app` / `benchmark_app` sub-typer apps, `finlet/cli_mcp_client.py` (entire file).

### Kept

| Command | Purpose |
|---|---|
| `finlet serve` | uvicorn API + dashboard server (prod EC2 unit) |
| `finlet mcp serve` | stdio MCP server — agent hosts spawn this |
| `finlet auth login` | OAuth 2.1 + PKCE browser bootstrap |
| `finlet auth logout` | clear `~/.finlet/credentials` |
| `finlet auth status` | report local credential state |
| `finlet register` | mint a bootstrap api_key (CI / headless) |
| `finlet plugins list/add/remove` | REST plugin filesystem management |
| `finlet manual [topic]` | local markdown topic viewer |
| `finlet --version` | diagnostics |

`EXIT_AUTH_REQUIRED = 2` stays — `plugins_add`, `plugins_remove`, and `auth_status` are alive consumers.

### Scope honesty

This migration fixes the CLI surface of the drift problem, NOT the broader drift across docs / dashboard / llms.txt / architecture records. That broader drift is what makes the documentation rewrites (Team C) and dashboard HTML rewrites (Team D) necessary in this same plan. Going forward, future contributors should write to ONE canonical onboarding source (the "Canonical v2 onboarding script" in the plan doc) and let downstream surfaces consume it, rather than maintaining parallel narratives.

### Constraints

* **No MCP tool shape changes.** This work is strictly subtractive on the CLI side. If a dropped CLI command exposes a feature with no MCP equivalent, FLAG IT — do not silently add a new MCP tool to fill the gap. The CLI's `session publish` command previously printed a share URL; after deletion, the URL is derived by the consumer as `https://finlet.dev/sessions/{id}` — `set_session_visibility` is NOT modified to return a `share_url` field.
* **No regression in functionality reachable via MCP.** Every behavior the dropped CLI commands exposed remains reachable via MCP tools.
* **No test coverage regression.** Tests being deleted have equivalent assertions in `tests/mcp/`, or unique paths are ported BEFORE the CLI test file is dropped.
* **No write-path expansion in the dashboard.** The dashboard remains read-only monitoring post-2026-05-06. Dashboard HTML rewrites are content/copy only — no JS, CSS, or write-flow changes.

## Rationale

### Why delete instead of mark-deprecated?

Pre-launch with zero customers, soft-deprecation buys nothing. A deprecation window exists to give consumers time to migrate; here there are no consumers, so the window is dead weight that adds maintenance burden (the duplicated logic stays around, the drift surface stays open) for zero migration benefit. The v2.0.0 cutover is a clean delete.

### Why now, not v1.1?

The 2026-05-22 Codex bug (`finlet session create` printing real tickers in blind mode) is the concrete failure mode this delete prevents. Every additional release on the dual-surface architecture is another chance for the same class of drift bug. With zero customers, the breaking change cost is ~0 — there is no reason to defer.

### Why keep `finlet mcp serve` as a stdio entry point?

Agent hosts spawn it. Claude Desktop, Codex CLI, Cursor, Windsurf, and custom MCP clients all consume the stdio transport. The cloud `/mcp` HTTP mount is also live (per [`cli-mcp-http-dispatch.md`](./cli-mcp-http-dispatch.md), unchanged) for direct REST/MCP-over-HTTP integrations, but the stdio path is the primary agent-onboarding shape because it's how the major agent hosts expect to wire a tool server.

### Why keep `finlet plugins list/add/remove` on REST?

Plugin credential management is operator surface, not agentic-trading surface. The MCP tool catalog deliberately does NOT expose tenant plugin credential reads/writes — there is no `add_plugin_credential` MCP tool. The CLI's plugins commands consume `_api_headers` (REST direct), NOT `_dispatch_mcp_tool`, so they are unaffected by the dispatch-shim deletion. They use `EXIT_AUTH_REQUIRED = 2` for shell-script integration.

### Why is the share URL derived on the consumer side instead of returned by `set_session_visibility`?

Adding a `share_url` field to the MCP tool response would couple the tool's contract to the deployment's hostname. Consumers know the hostname (`https://finlet.dev`) and know the session ID (returned by the tool). String concatenation is the right tool for the job. An anti-shape-drift test asserts `"share_url" not in result` to prevent silent future regression.

### Why two-pass Codex review before exec-plan handoff?

The 2026-05-22 plan-features 7-BLOCKER catch (Codex review v1 → v2) validated the two-pass structure. Both passes are now hard gates in the plan-features skill (PF-20 + PF-21). For this v2.0.0 migration: Codex review v1 → v2 caught one BLOCKER on `EXIT_AUTH_REQUIRED` accidentally being grouped with the dead helpers (it's alive — used by `plugins_add`/`plugins_remove`/`auth_status`); v2 → v3 caught the canonical-onboarding-script schema mismatch (the new MCP-side assertion test used `result["anonymous"]` when the response shape is `result["public_anonymous"]`).

## Migration Notes

Zero PyPI consumers per `[[project-pre-launch-no-customers]]`. No migration guide is published — the v2.0.0 release notes document the kept surface and point at the MCP tool catalog. The 90-day dual-accept window from `[[project-mcp-first-phase4_shipped]]` was retracted because it served the same zero-consumer audience.

Consumer-side share-URL derivation pattern: `https://finlet.dev/sessions/{session_id}`. Documented in `finlet/manual/quickstart.md`, `docs/PRIVACY_POLICY.md` §5.4, and the anonymous public-session route group (`/v1/public/sessions/{id}/*`).

## Alternatives Considered

1. **Keep the CLI as a thin wrapper around MCP-over-HTTP.** Rejected — the drift surface is the issue, not the dispatch mechanism. As long as the CLI re-renders responses for human display, it has a divergent display path that can lift fields the MCP tool blinded. The 2026-05-22 Codex bug was exactly this.
2. **Move display logic into a shared library consumed by both CLI and MCP tool.** Rejected — adds a new abstraction layer to fix a problem that disappears when the CLI is deleted. Pre-launch, the right answer is the simpler one.
3. **Mark the twelve commands as deprecated with a Sunset header / stderr warning, delete in v3.0.0.** Rejected — see "Why delete instead of mark-deprecated" above. With zero consumers, deprecation adds maintenance with no migration benefit.
4. **Add `share_url` to `set_session_visibility` response.** Rejected — couples MCP tool contract to deployment hostname. Consumer derivation is the right shape; anti-shape-drift test enforces it.
5. **Defer to post-launch and live with the drift bug class.** Rejected — every release on the dual-surface architecture is another drift opportunity. Pre-launch is the cheapest possible time to make this cut.

## References

* `docs/decisions/cli-mcp-http-dispatch.md` — the now-superseded CLI MCP-over-HTTP dispatch architecture. Cloud `/mcp` mount itself remains live for direct consumers; only the human-facing CLI dispatch shim is deleted.
* `docs/decisions/cli-mcp-stdio-auth.md` — already-superseded predecessor (2026-05-11 v1.0.1).
* `docs/decisions/session-public-visibility.md` — the public session visibility contract the consumer-side share-URL derivation depends on.
* `docs/decisions/mcp-canonical-surface.md` — MCP is the canonical agent surface; this migration brings the CLI in line with that decision.
* `docs/decisions/blind-benchmark-architecture.md` — the blind-mode contract whose CLI-side divergence triggered the 2026-05-22 Codex bug.
* `docs/decisions/ui-removal-launch-cut.md` — 2026-05-06 dashboard write-path cut; the v2.0.0 cutover completes the MCP-as-canonical move started there.
* `[[project-pre-launch-no-customers]]` — pre-launch zero-customer mandate that makes the breaking change cost ~0.
