# Decision: yfinance as Interim Data Source

**Date:** 2026-04-03
**Status:** Accepted
**Source:** Data Pipeline Implementation, Team A

## Context

Finlet needs historical and daily OHLCV data, quarterly financials, news headlines, and analyst sentiment for US equities and crypto. The existing PricePlugin reads from an S3 data lake populated by Databento (licensed provider), but we needed to extend coverage to fundamentals, news, and sentiment -- and provide a zero-cost data source for development and pre-revenue operation.

Licensed data providers evaluated:

| Provider | Coverage | Cost | Notes |
|----------|----------|------|-------|
| Databento | Prices only (equities + crypto) | ~$100/mo+ | Already in use for prices |
| Finnhub Business | News + fundamentals | ~$49/mo | Free tier is dev/test only per ToS |
| Polygon.io | Full market data | $79-299/mo | Comprehensive but expensive pre-revenue |
| yfinance | Prices, fundamentals, news, sentiment | $0 | Yahoo Finance scraping library; no commercial license required |

## Decision

Use **yfinance** as the interim data source for all 4 data types (prices, fundamentals, news, sentiment) during pre-revenue operation. The ingestion framework is designed so that swapping to a licensed provider requires changing only the ingestion module -- S3 schemas, plugins, and the enforcer are unchanged.

### Cost Rationale

- Pre-revenue: $0/month (yfinance is free)
- Post-revenue: migrate to Finnhub Business ($49/mo) for news + fundamentals, keep Databento for prices, add Polygon for depth
- The S3 data lake acts as a normalization layer -- downstream code never knows which upstream provider generated the data

### yfinance Limitations

1. **No guaranteed SLA** -- Yahoo can throttle or block at any time
2. **Filing dates are estimated** -- yfinance quarterly financials use `period_end + 45 days` as the filing date estimate (SEC 10-Q deadline for large accelerated filers). Actual filing dates are usually earlier. For precise filing dates, cross-reference with SEC EDGAR.
3. **News coverage is limited** -- yfinance returns a small set of recent headlines per ticker, not a comprehensive archive
4. **Rate limits are implicit** -- no documented rate limit; scripts use batch throttling (2s between batches, 0.5s between tickers) as courtesy delays

### Migration Path

When revenue justifies licensed data:

1. Write a new `DataIngester` implementation (e.g., `PolygonProvider`) in `finlet/ingestion/`
2. Update ingestion scripts to use the new provider
3. Re-run bulk ingestion to backfill S3 with higher-quality data
4. **No changes needed to:** S3 Parquet schemas, plugins, enforcer, API, MCP tools, or dashboard

The `DataIngester` ABC (`finlet/ingestion/base.py`) enforces a canonical schema for prices:

```
date: date32, ticker: string, open: float64, high: float64, low: float64, close: float64, volume: int64
```

Any new provider must produce this schema. The `validate_table()` method on the ABC catches schema violations at ingestion time.

## Consequences

- Zero data cost during development and pre-revenue operation
- Filing date estimates may differ from actual SEC filing dates by up to 45 days (conservative)
- News coverage is shallower than Finnhub or Polygon
- yfinance data quality is adequate for agent evaluation (testing reasoning, not precise execution)
- Migration to licensed providers is a single-module swap with no downstream changes
