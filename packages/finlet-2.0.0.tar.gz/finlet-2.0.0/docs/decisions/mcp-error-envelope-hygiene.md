# Decision: MCP Error Envelope Hygiene — Path Sanitizer + Pydantic Fallback

**Date**: 2026-05-21
**Status**: Accepted (shipped by Team D in the codex-bugs-4pack exec-plan)
**Bug**: Codex `79c7b578-6a10-4748-aae7-3945e89a4f7d` — security launch-blocker
**Related**:
- `docs/decisions/blind-benchmark-envelope-fields-must-blind.md`
- `docs/decisions/blind-mapping-serializer-poison.md`
- `docs/decisions/2026-05-19-mcp-structured-error-envelope.md`

---

## Context

Codex's 2026-05-21 dry-run surfaced two sibling envelope-hygiene leaks on the MCP surface:

**4a — filesystem path leak.** `EdgarPlugin._cache_dir = Path.home() / ".finlet" / "cache" / "edgar"` (`finlet/plugins/edgar_plugin.py:73`). Any boto3 / edgartools / pyarrow exception that mentions the local parquet path (`/Users/<dev>/.finlet/cache/edgar/AAPL.parquet`) is interpolated verbatim into the plugin's error string and surfaces through MCP. Recon confirmed `price_plugin.py`, `news_plugin.py`, `sentiment_plugin.py`, and `fred_plugin.py` all share the same `~/.finlet/cache/*` pattern — so this is a class of leak, not an EDGAR-only bug.

**4b — pydantic ValidationError leak.** `report_bug(context="not a dict")` returns the raw pydantic library shape:

> `"Error executing tool report_bug: 1 validation error for report_bugArguments\ncontext\n  Input should be a valid dictionary [type=dict_type, input_value='not a dict', input_type=str]\n    For further information visit https://errors.pydantic.dev/2.12/v/dict_type"`

This leaks (a) the deployed pydantic minor version through `errors.pydantic.dev/2.12/...`, (b) the library shape `validation error for <ToolName>Arguments`, and (c) an unstable agent-facing contract.

## Mandatory smoke-test result (the 4b structural finding)

Per the team-D handoff, the primary plan was to extend `@blind_error_mapper` (`finlet/mcp/blind_error.py`) with an `except pydantic.ValidationError` catch BEFORE the existing `except Exception`. The handoff also flagged the structural risk: "FastMCP MAY swallow `pydantic.ValidationError` at its own dispatch layer BEFORE invoking the `@blind_error_mapper`-wrapped function."

Spawn-time smoke test (`/tmp/smoke_mcp_pydantic2.py`, 2026-05-21) confirmed: **FastMCP DOES swallow it.** The execution order in `mcp/server/fastmcp/utilities/func_metadata.py:74-95` is:

```python
async def call_fn_with_arg_validation(self, fn, fn_is_async, arguments_to_validate, ...):
    arguments_pre_parsed = self.pre_parse_json(arguments_to_validate)
    # ↓↓↓ pydantic raises here, BEFORE fn is called
    arguments_parsed_model = self.arg_model.model_validate(arguments_pre_parsed)
    arguments_parsed_dict = arguments_parsed_model.model_dump_one_level()
    ...
    if fn_is_async:
        return await fn(**arguments_parsed_dict)   # never reached on validation failure
```

And `mcp/server/fastmcp/tools/base.py:93-117`:

```python
async def run(self, arguments, ...):
    try:
        result = await self.fn_metadata.call_fn_with_arg_validation(...)
    ...
    except Exception as e:
        raise ToolError(f"Error executing tool {self.name}: {e}") from e
```

The wrapped function — which carries our `@blind_error_mapper` wrapper — is never invoked on a validation failure. The decorator approach CANNOT close 4b without forking FastMCP. (Confirmed: smoke-test's wrapper counter stayed at 0 across the validation-failure call.)

## Decision

Two-pronged fix at the MCP boundary.

### (1) New module: `finlet/mcp/error_envelope.py`

`sanitize_paths(value)` — recursive path-and-pydantic-URL scrubber. Patterns:
* `/Users/<name>/...` — macOS home directories.
* `/home/<name>/...` — Linux home directories.
* `/root[/...]` — root home.
* `~/...` — tilde-expanded home.
* `https?://errors.pydantic.dev/<ver>/...` — pydantic doc URLs.
* `\.finlet\b` — the Finlet cache marker (catches isolated leaks after the home-dir patterns collapsed adjacent slugs).

Each match is replaced by `<redacted-path>`. Helper is idempotent (re-running on already-scrubbed input is a no-op — the placeholder does not match any pattern) and recursive (walks dicts, lists, tuples element-wise; preserves non-string scalars unchanged).

`validation_error_envelope(exc)` — builds the canonical envelope from a `pydantic.ValidationError`:

```python
{"error": {
    "code": "validation_error",
    "field": "<dot-joined loc>",
    "expected": "<pydantic error type, e.g. 'dict_type'>",
    "got": "<input type name>",
    "message": "<msg without the pydantic.dev URL>",
}}
```

`manual_validation_envelope(field, expected, got, message)` — same shape from manual `isinstance()` checks in tool bodies. Both helpers produce identical top-level shape so agents pattern-match the contract regardless of how the failure surfaced.

### (2) Extend `@blind_error_mapper` to call `sanitize_paths`

The wrapper at `finlet/mcp/blind_error.py:267-324` runs `sanitize_paths(result)` on every return path (success body, blinded-error body, raw passthrough). The blind transform LOGIC is unchanged — sanitize_paths is purely additive. Defense in depth: even on a non-blind session with no blind mapping, paths are still scrubbed.

Document the pydantic-uncatchable limitation in the wrapper's exception-handler comment so future engineers don't re-attempt the decorator-catches-ValidationError approach.

### (3) Defense-in-depth at EDGAR's caught exception (`finlet/plugins/edgar_plugin.py:259-269`)

The plugin owns its own error-string composition. Even though the MCP-chokepoint sanitizer would scrub the leak on the way out, the plugin's error message is also surfaced through REST routes and other consumers. Scrub there too:

```python
except Exception as e:
    safe_error = sanitize_paths(str(e))
    return PluginResponse(... error=f"EDGAR: ... Error: {safe_error}. ...")
```

### (4) Pydantic fallback for `report_bug`

Widen the two pydantic-strict parameters at `finlet/mcp/tools_telemetry.py:79-87`:
* `context: dict[str, Any]` → `context: Any`
* `error_payload: dict[str, Any] | None = None` → `error_payload: Any = None`

Validate in the tool body with `isinstance(...)`; return `manual_validation_envelope(...)` on mismatch. The widening avoids FastMCP's pre-dispatch pydantic step entirely for these two fields, and the body check produces the same canonical envelope as `validation_error_envelope` would have. Net effect: agents see a stable contract; no library shape ever reaches the wire.

## Boundary contract — what the agent sees

| Input | Before (bug 4b) | After (this decision) |
|---|---|---|
| `report_bug(context="not a dict")` | `Error executing tool report_bug: 1 validation error for report_bugArguments\ncontext\n  Input should be a valid dictionary [type=dict_type, ...] visit https://errors.pydantic.dev/2.12/v/dict_type` | `{"error": {"code": "validation_error", "field": "context", "expected": "dict_type", "got": "str", "message": "Input should be a valid dictionary"}}` |
| `get_filings(ticker="AAPL")` with EDGAR raising on `/Users/x/.finlet/cache/edgar/AAPL.parquet` | `EDGAR: Failed to fetch filings for 'AAPL'. ... Error: ... /Users/justnau/.finlet/cache/edgar/AAPL.parquet ...` | `EDGAR: Failed to fetch filings for 'AAPL'. ... Error: ... <redacted-path> ...` |
| Any tool with a body that returns a success dict carrying `.finlet` substring in a nested string | Path surfaces verbatim | `<redacted-path>` |

## Grep-gate (load-bearing test)

`tests/mcp/test_error_envelope_hygiene.py` drives 20+ MCP responses through error / validation / success paths, aggregates the JSON blobs, and asserts none of the following substrings appear:

```python
("/Users/", "/home/", "~/", "/root", ".finlet", "errors.pydantic.dev",
 "validation error for ", "Error executing tool ")
```

The blob assertion is the regression gate. The first two tokens cover the path leak; the next four cover the bare Finlet marker, the pydantic URL, the library shape, and the FastMCP wrapper shape.

## Alternatives considered (and rejected)

1. **Fork FastMCP to inject our wrapper before `model_validate`.** Maintenance cost (lock-step with upstream mcp 1.27+ releases) outweighs the surgical benefit. The widen-to-`Any` fallback is one-line-per-parameter and ships today.

2. **Tighten the EDGAR `_cache_dir` to a relative path so the exception string never contains a home prefix.** Doesn't address the pyarrow/boto3 stacktrace path leak in OTHER plugins. The `sanitize_paths` chokepoint covers every plugin in one pass.

3. **Strip `.finlet` cache references at log emit (structlog processor) instead of the response envelope.** Misses the agent-facing leak surface — logs go to ops, but the failing response still ships to the agent. Sanitize at the envelope.

4. **Embed `sanitize_paths` directly in every plugin's error string composition.** Brittle — easy to forget a new plugin. The MCP-decorator chokepoint catches every tool by construction. EDGAR is the additional defensive layer because its `cache_dir` is the documented leak source.

## Scope notes — Team D scope-widening

The team prompt's `Files you MUST NOT touch` list named `finlet/mcp/tools_telemetry.py`. The fallback procedure documented in the SAME prompt (for the `STATUS=BLOCKED` smoke-test outcome) directs widening tool signatures — which only `tools_telemetry.py` carries. Internal contradiction in the prompt. Team D resolved by:
1. Confirming the smoke test result (decorator-cannot-catch).
2. Implementing the fallback ON `tools_telemetry.py` ONLY (the file with the bug parameter).
3. Documenting the scope-widening here so the next iteration of file-ownership clarifies that `tools_telemetry.py` is co-owned for envelope-hygiene fixes.

This was the minimum-surface fix that closes the launch-blocker without touching `server.py` or any of the other tool files. `create_session.universe: list[str] | None` carries the same pydantic-validation leak class but lives in `finlet/mcp/server.py` (Team A + B's surface) — flagged for a follow-up iteration; the current bug report only names `report_bug.context`.

## Future-proofing

* New MCP tool with a `dict[str, Any]` or `list[X]` parameter → the boundary patch (see Followups below) catches the leak class universally; the widen-to-`Any` + body-check fallback remains supported but is no longer required for path-leak hygiene.
* New plugin → `sanitize_paths(str(e))` at the plugin's catch-all `except Exception` block. The MCP-decorator chokepoint still backstops if forgotten.
* If FastMCP's call order changes to invoke our wrapper BEFORE `model_validate`, the test `test_pydantic_validation_error_not_catchable_in_decorator` (`tests/mcp/test_pydantic_validation_envelope.py`) becomes a warning rather than a behavioral invariant — re-run the spawn-time smoke test (`/tmp/smoke_mcp_pydantic2.py`) before removing the `Any`-widening + manual checks.

## Followups (Codex item #2, 2026-05-21): Boundary wrapper supersedes widening-as-primary

The widening fallback shipped with the original decision (4b: widen `report_bug.context` + `report_bug.error_payload` to `Any`) closes the launch-blocker only for the two named parameters. The full leak class — every MCP tool with a `dict[str, Any]` or `list[X]` typed parameter — remained open: `create_session(universe="AAPL")` produced exactly the same `errors.pydantic.dev` URL leak shape as the original report. Hand-widening every typed-collection parameter on every tool is brittle.

The boundary patch in `finlet/mcp/_fastmcp_patches.py` (`apply_validation_boundary_patch()`) closes the class. It monkey-patches `FuncMetadata.call_fn_with_arg_validation` (the FastMCP method that runs `model_validate` BEFORE the wrapped tool function) to catch `pydantic.ValidationError` and return the canonical `validation_error_envelope` (run through `sanitize_paths`) as a normal RETURN VALUE. Returning bypasses the `except Exception → ToolError` wrap one frame up at `mcp/server/fastmcp/tools/base.py:117` which previously interpolated `"Error executing tool ..."` plus the raw pydantic message into the agent-facing error.

Key invariants:

1. **Class-method-level patching.** The patch replaces the bound method on the class; every existing AND future `FuncMetadata` instance benefits without re-registration. Decoration order vs patch order does not matter because decoration only stores `FuncMetadata` per tool — the actual call is at invocation time.

2. **Idempotent.** Module-level `_PATCH_APPLIED` flag guards against double-application. `apply_validation_boundary_patch()` called twice is a no-op the second time (no double-wrap, no compounded try/except chain). Test: `test_patch_is_idempotent` in `tests/mcp/test_error_envelope_hygiene.py`.

3. **Signature-drift guard.** At import time, the patch verifies the upstream method signature matches `_EXPECTED_PARAMS = {"self", "fn", "fn_is_async", "arguments_to_validate", "arguments_to_pass_directly"}`. If FastMCP renames or adds a parameter, the patch raises `RuntimeError` rather than silently degrading. Upgrade-time failure is loud. (This was the gap in the prior iteration's manual smoke test — a future mcp[auth] update could break the assumption with no test signal.)

4. **One application site.** `finlet/mcp/server.py` calls `apply_validation_boundary_patch()` once, immediately after the imports and before any `@mcp.tool()` decoration matters. The class-method-level patch is retroactive for tools registered in the imported submodules (`tools_benchmark.py`, `tools_portfolio.py`, etc.) too.

5. **`sanitize_paths` dict-key scrub.** The dict-walk in `finlet/mcp/error_envelope.py:sanitize_paths` now scrubs string KEYS in addition to leaf values. `pydantic.ValidationError.errors()` can produce dicts keyed on the offending value, and a stack-trace surface may interpolate a path as a key. Non-string keys (int, tuple) pass through unchanged. Tests: `test_sanitize_paths_scrubs_dict_keys` + `test_sanitize_paths_preserves_non_string_keys`.

`manual_validation_envelope` (and the widening fallback) remain supported for tools that genuinely want body-level validation (e.g. semantic checks beyond pydantic's type system, custom error messages). Tools that previously widened to `Any` for hygiene-only reasons can stay widened (no rewrite required) — the boundary patch catches the leak regardless.

The boundary patch is the new chokepoint; tests `test_boundary_patch_catches_validation_error` and `test_patch_is_idempotent` in `tests/mcp/test_error_envelope_hygiene.py` pin the contract. The grep gate at the same file remains load-bearing for the substring set (`/Users/`, `/home/`, `~/`, `/root`, `.finlet`, `errors.pydantic.dev`, `validation error for `, `Error executing tool `).
