# Decision: Onboarding Checklist Step Contract (`CHECKLIST_STEPS` registry)

**Date**: 2026-04-30
**Status**: Accepted

---

## Context

Across two consecutive bug-hunt iterations (`20260428T013300Z6e79`, `20260428T031818Z2efa`), four real-broken instances landed against the dashboard "Getting Started" checklist + onboarding wizard:

1. `strategy-checklist-dead-div` — checklist row with no click handler.
2. `strategy-item-opens-leaderboard` — wrong-action wiring for the strategy row.
3. `onboarding-wizard-form-drift` — wizard's Step 2 carried a bespoke session form duplicating the canonical Create Session modal.
4. `checklist-no-advance-after-fill` — analysis row never advanced after a real fill.

Three of the four landed in the same iteration. Same shape every time: a documented step in the checklist or wizard fails because the affordance, the action, and the persisted state are wired by hand at three different sites — and any one of the three can drift independently.

The `7085ea7` event-bus migration partly closed the gap by introducing `STEP_TRIGGERS` (a declarative table mapping step keys to bus event names). That moved the "subscriber wiring" off bespoke reach-ins (`window.finletOnboarding.markStepComplete(...)`) onto a `Map<step, event>` table. But it stopped short of three things:

- It did not extract a "checklist row contract" (label + action + step-key + completion-event). Each row was still hand-wired with a bespoke click handler and a hand-edited HTML literal.
- It did not formalize the wizard's per-step shape. Step 3's persona-specific action cards lived in `populateStep3()` with no shared contract.
- It did not address the `strategy` step's missing trigger event — that step was `null` in `STEP_TRIGGERS`, with a TODO comment that survived two iterations.

A 5th instance was the near-certainty. Adding a 4th persona path or a new checklist row required editing `state.steps` defaults, `STEP_TRIGGERS`, `buildChecklistItem` callsites, and the per-row click handler block — four touch points, no enforced contract.

---

## Decision

Consolidate the three hand-maintained registries (`state.steps` defaults, `STEP_TRIGGERS`, per-row HTML literal + click wiring) into a single declarative `CHECKLIST_STEPS` array in `dashboard/onboarding.js`. Add a parallel `WIZARD_STEPS` registry for the 3-step onboarding wizard. Drive all four sites (state, subscribers, render, click-action) from the registry through a small `dispatchChecklistAction(action)` helper.

### 1. `CHECKLIST_STEPS` shape

```js
const CHECKLIST_STEPS = [
  {
    key: 'profile',
    label: 'Set up profile',
    trigger: null,                                    // manual; wizard owns
    action: { type: 'noop' },
  },
  {
    key: 'session',
    label: 'Create first session',
    trigger: 'session:switched',
    action: { type: 'open-modal', target: 'create-session' },
  },
  {
    key: 'analysis',
    label: 'Run first analysis',
    trigger: 'order:filled',
    action: { type: 'open-modal', target: 'trade-ticket' },
  },
  {
    key: 'strategy',
    label: 'Learn how to build a strategy',
    trigger: 'strategy:saved',                         // post-launch event placeholder
    action: { type: 'navigate', href: 'agent-guide.html#strategies', markOnClick: true },
  },
];
```

`state.steps` defaults derive from `CHECKLIST_STEPS.map(s => s.key)`. `wireBusSubscribers` iterates the registry and skips `trigger === null` entries. `renderChecklist` maps the registry into rows and wires each row's click through `dispatchChecklistAction(step.action)`. `isAllStepsComplete` uses `CHECKLIST_STEPS.every(s => state.steps[s.key])`.

### 2. `dispatchChecklistAction(action)` — three action types

```js
{ type: 'noop' }                                    // wizard owns this step; no row-click effect
{ type: 'open-modal', target: '<key>' }             // invoke MODAL_TARGETS[target]
{ type: 'navigate', href: '<url>', markOnClick?: true }  // assign window.location.href; optionally mark first
```

Modal targets registered in `MODAL_TARGETS` map (one line per modal). Adding a new modal target is one line; the dispatcher's `open-modal` branch handles it automatically. The `navigate` branch's `markOnClick` flag is the only "manual tick" surface area; once `strategy:saved` ships, drop the flag and the row becomes pure-bus.

### 3. `WIZARD_STEPS` shape

```js
const WIZARD_STEPS = [
  { id: 1, title, subtitle, body: () => '...', advanceTrigger: null,        nextLabel: 'Continue' },
  { id: 2, title, subtitle, body: () => '...', advanceTrigger: 'session',   nextLabel: 'Open Session Creator' },
  { id: 3, title, subtitle, body: () => '...', advanceTrigger: 'analysis',  nextLabel: 'Go to Dashboard' },
];
```

`buildWizardHTML()` maps over `WIZARD_STEPS` to produce the progress bar, step containers, and footer. `showStep(N)` reads `WIZARD_STEPS[N-1]` for the footer button label + state. `markStepComplete(stepKey)` advances the wizard when `WIZARD_STEPS.findIndex(w === currentStep && w.advanceTrigger === stepKey) >= 0` — the special-case "if step is `session` AND wizard is on Step 2" collapses into the registry-driven rule.

### 4. CSS contract

Each `WIZARD_STEPS[i].body(...)` factory emits byte-identical `class`/`id`/`role`/`aria` attributes to the legacy hand-authored literal so `dashboard/onboarding.css` continues to apply unchanged. The Playwright wizard walk asserts the existing CSS classes are visible after the refactor.

---

## Alternatives Considered

**Server-side onboarding state.** Out of scope here. The 4 instances are entirely client-side; persistence is per-browser via `localStorage`. If we later decide cross-device sync is worth the cost, that is a separate decision.

**One mega-registry that fuses CHECKLIST + WIZARD.** Rejected. Wizard steps are time-ordered (1 → 2 → 3); checklist steps are status-flag (toggle each independently). The two have different lifecycles — combining them would force every change to consider both.

**Bus-publishing every step from a single sink.** Rejected. The publishers (app.js SSE handler, wizard `handleNext`, checklist row click) are scattered by ownership. Centralizing the SUBSCRIBER side closes the failure mode (the one that recurred 4 times); centralizing the publisher side would require touching every owner-domain on every change.

**Keeping `STEP_TRIGGERS` and adding a separate "row action registry".** Rejected. That preserves the multi-registry shape that produced the drift in the first place. Single source of truth is the explicit goal.

---

## Consequences

### Positive

- **Adding a checklist step is one entry.** The registry is the only edit site. `state.steps` defaults, bus subscribers, row rendering, and click-action dispatch are auto-derived.
- **Removing a step is one delete.** Orphaned `localStorage` keys filter out on next `loadState` (the load merges `parsed.steps` against `CHECKLIST_STEPS.map(s => s.key)` and drops anything not in the registry).
- **The post-launch `strategy:saved` migration is a one-line change.** Drop `markOnClick: true` from the strategy entry; the bus subscriber takes over the step-complete flip on the publisher's first fire.
- **Wizard auto-advance generalizes.** Adding a 4th wizard step that auto-completes on `markStepComplete('newKey')` is one entry — no edits to `markStepComplete` or `showStep`.
- **Single revertable SHA.** The registry extraction is mechanical; rollback restores `STEP_TRIGGERS` + the bespoke strategy-row block from git history in ~30 minutes.

### Negative

- **The `__finletOnboardingTest__` introspection hook is exposed in production.** Mirrors the `__dialogStateMirrorTest__` pattern (also exposed in production but documented as test-only). Production code MUST NOT call it. The risk is convention-enforced, not language-enforced.
- **Behavior change on Step 3 auto-completion.** Pre-refactor, the wizard required the user to click "Go to Dashboard" after a fill. Post-refactor, `markStepComplete('analysis')` while the wizard is on Step 3 auto-dismisses the wizard after a 1-second delay (so the success message stays visible briefly). This is a deliberate UX change covered by Risk Register row 3.
- **Wizard auto-advance from the bus path.** A `markStepComplete('analysis')` published via the bus while the wizard is showing Step 3 will dismiss the wizard. In practice this is the desired flow (the user submitted a real fill, so the wizard is done). If it surfaces a regression we can gate the auto-dismiss to only fire when the trigger came from a UI action rather than a bus event.

---

## Validation

- **Unit:** `tests/dashboard/onboarding-checklist.spec.js` (15 tests, `node --test`). Covers the registry-as-source-of-truth invariant (test 13: adding a 5th entry to `CHECKLIST_STEPS` produces a 5th `state.steps` key + a 5th bus subscription on the next `wireBusSubscribers`), the dispatcher's three action types (tests 5-8), `loadState`'s orphan-key filter (test 2), and the wizard auto-advance + auto-dismiss rules (tests 9-12).
- **Sibling-spec regression:** `tests/dashboard/event-bus.spec.js`, `tests/dashboard/dialog-state-mirror.spec.js`, `tests/dashboard/form-dirty-tracker.spec.js` all continue to pass.
- **Lint:** `bash scripts/lint-trusted-types.sh` exits 0 (no bare `.innerHTML =` writes; the three existing `trustedHTML(...)` wraps stay wrapped).
- **Pytest baseline:** 3902/3902 preserved (no Python imports change; the refactor is pure JS + docs).
- **Playwright:** `tests/e2e/journey-onboarding.spec.ts` extended to cover the four historical recurrence shapes — F2 (strategy row navigates to `agent-guide.html#strategies` and ticks the counter, never opens the leaderboard modal), F5 (wizard Step 2 has zero `<input>` elements + delegates to the canonical Create Session modal), F6 (analysis row ticks within 4s of `order:filled`), and the new step-contract walk (wizard appears on fresh load, advances through all 3 steps, action cards visible per persona).
- **Grep gates:** `grep -c "STEP_TRIGGERS" dashboard/onboarding.js` returns 0 (constant deleted); `grep -c "CHECKLIST_STEPS" dashboard/onboarding.js` ≥ 5 (definition + readers); `grep -c "WIZARD_STEPS" dashboard/onboarding.js` ≥ 4; `grep -c "openLeaderboardSubmitModal" dashboard/onboarding.js` returns 0 (regression check).

---

## References

- Source: `docs/bug-hunt/refactor-queue/onboarding-checklist.md` (drafted 2026-04-30).
- Plan: `docs/refactor/onboarding-checklist/plan.md`.
- Recurrence ledger: `docs/bug-hunt/ledger.jsonl` (entries `strategy-checklist-dead-div`, `strategy-item-opens-leaderboard`, `onboarding-wizard-form-drift`, `checklist-no-advance-after-fill`).
- Predecessor decision: `docs/decisions/dashboard-event-bus.md` (event-bus convention; this decision builds on it).
- Sibling pattern: `docs/decisions/dialog-state-mirror-prime-ordering.md` (same dashboard surface, similar registry/contract shape).
- Implementation: `dashboard/onboarding.js`, `dashboard/event-contract.md` (`strategy:saved` placeholder + "Adding a new checklist step" recipe).
- Tests: `tests/dashboard/onboarding-checklist.spec.js`, `tests/e2e/journey-onboarding.spec.ts`.
