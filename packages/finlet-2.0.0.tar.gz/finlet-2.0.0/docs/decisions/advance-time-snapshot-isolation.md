# Decision: `advance_time` Snapshot Isolation via Pinned `committed_time`

**Date:** 2026-05-22
**Status:** Accepted
**Source:** Codex bug `dc4daf5a` — Team B of the 2026-05-22 3-pack execution plan
**Related:** [`advance-time-layered-locking.md`](./advance-time-layered-locking.md) (C2 audit, lock topology)

## Context

After the Phase 1 audit fix (decision record above), every `advance_time` branch
serializes its lock-free clock-step phase under `session._tick_lock` to protect
clock state. The downstream fill phase
(`refresh_prices_and_fill_orders` → `Session.process_pending_orders` → portfolio
mutation) runs **outside** the outer lock — re-acquiring `_tick_lock` inside
`process_pending_orders` would deadlock, since `asyncio.Lock` is non-reentrant.

That fix protects clock mutation but leaves a **response-internal-consistency**
race window. Each branch read `session.clock.get_time()` **after lock release**
to populate response-shape fields:

- Single-step / batched: `_post_step_persist_and_fill` issued a live
  `session.clock.get_time()` for the snapshot timestamp at
  `clock_service.py:318` (live in `session.portfolio.snapshot(...)`).
- Target-date: `mcp/server.py:1267` did a post-lock live read for `end_time`.
- Price ceiling: `clock_service.py:147` (`ceiling_time = session.clock.get_time()`)
  drove plugin queries + the enforcer + the 30-day history fallback start date.

A parallel `advance_time` call could mutate `session.clock` between any of those
reads, producing a torn response where outer `current_time` /
`end_time` did not match `fill_summary.snapshot.timestamp` and individual
`order.filled_at` stamps came from a different sim time than the caller's own
step. Agents that reason about "the price at the time of fill" would see
contradictory data inside a single response. Codex flagged this with `dc4daf5a`
as BLOCKERS #4 (`ceiling_time` live read) and #5 (`end_time` live read).

Naively widening the outer `_tick_lock` to cover the fill phase reproduces the
deadlock from the Phase 1 audit — same root cause that drove the layered-locking
split in the first place.

## Decision

**Capture-at-commit, not lock-widening.** Each branch captures a
`committed_time = session.clock.get_time()` **inside** the outer `_tick_lock`
slice and threads it through every downstream clock-derived field via a new
kwarg-only signature on three surfaces:

1. **`Session.process_pending_orders(prices, *, sim_time: datetime | None = None)`**
   — when `sim_time` is supplied, the inner lock uses it for DAY-order expiry
   checks, `order_book.process_pending_orders(prices, sim_time)`, portfolio
   mutation, `order.filled_at` stamps, and the equity snapshot. When `None`,
   falls back to a live read (preserves backward compat for non-response-shaping
   callers like the leaderboard runner).

2. **`clock_service.refresh_prices_and_fill_orders(session, *, committed_time: datetime | None = None)`**
   — when `committed_time` is supplied, drives the price-plugin ceiling, the
   30-day history fallback `start_date`, the post-fill
   `session.portfolio.snapshot(...)` timestamp, and the `sim_time=` kwarg
   propagated into `Session.process_pending_orders`. When `None`, live read.

3. **`clock_service.advance_session(session, session_id, seconds, *, committed_time=None)`**
   — REST-facing helper; same pinning semantics + benchmark-progress log line
   pins to `committed_time` when supplied.

Each `advance_time` branch in `finlet/mcp/server.py` is updated:

- **Single-step:** `committed_time = session.clock.get_time()` immediately after
  `session.step(...)`, **inside** the lock; passed into
  `_post_step_persist_and_fill(..., committed_time=committed_time)`.
- **Batched (`steps > 1`):** per-iteration pin; the LAST iteration's pinned
  value drives the response's `current_time` and `fill_summary.snapshot.timestamp`.
- **Target-date:** `end_time = session.clock.get_time()` immediately after
  `session.step_to(...)`, **inside** the lock; passed into
  `refresh_prices_and_fill_orders(..., committed_time=end_time)` (replaces the
  live read at `clock_service.py:147` for this branch's flow).

REST mirrors MCP: `routes_clock.py:step_clock` and `step_to_clock` wrap their
`session.step()` / `session.step_to()` call in `async with session._tick_lock:`,
pin `committed_time` inside the lock, then call
`refresh_prices_and_fill_orders(session, committed_time=committed_time)`
**outside** the lock. `session.step()` does **not** re-acquire `_tick_lock`
(verified at HEAD `ad73508`), so the outer wrap is deadlock-safe. The wrap is
intentionally scoped to `step()` / `step_to()` only — wrapping
`refresh_prices_and_fill_orders` re-enters the inner lock and deadlocks.

## Backstop

`finlet/mcp/server.py:_assert_clock_snapshot_consistency(result_dict)` is the
env-gated drift detector:

```python
mode = os.getenv("FINLET_CLOCK_CONSISTENCY_ASSERT", "log")
if outer != snap_ts and mode == "raise":
    raise RuntimeError(...)
```

`tests/conftest.py:pytest_configure` `setdefault`s the env to `raise` so every
test treats a drift as a hard failure. Production never sets the var, so the
default `log` mode keeps user-facing tools resilient against any latent edge.
Called at every `_post_step_persist_and_fill` return + every target-date branch
return + every batched-steps branch return.

## Out of Scope

- **`Session.reject_unfillable_orders`** — Codex BLOCKER #3. Currently reads a
  live `self.clock.get_time()` at `finlet/core/session.py:604`. NOT touched in
  this iteration; a separate fix needs to pin `sim_time` through the
  rejection-trace path AND audit the call sites in `clock_service.py` (lines
  252-256, 279-282) that pass via `await session.reject_unfillable_orders(...)`.
- **`finlet/leaderboard/runner.py`** — `process_pending_orders(prices)` callers
  do not response-shape, so they continue to use the live-read fallback. This is
  intentional: not every caller benefits from pinning.

## Consequences

- New concurrency test
  `tests/mcp/test_concurrency.py::TestAdvanceTimeConcurrency::test_concurrent_advance_response_internal_consistency`
  fires `asyncio.gather(advance, advance)` and asserts response-internal
  consistency on every return + `filled_at` match.
- New REST parity test `tests/api/test_routes_clock_concurrency.py` mirrors the
  pattern for `step_clock` and `step_to_clock`.
- The backstop catches regressions where someone re-introduces a live
  `session.clock.get_time()` for a response-shape field. The grep gate is
  whatever future audit checks `session.clock.get_time()` references in
  `clock_service.py` / `mcp/server.py`.
- REST and MCP are now serialization-equivalent for clock-step + fill paths.

## Alternatives Considered

1. **Widen `_tick_lock` to cover the fill phase.** Rejected — re-entrance
   deadlock at `process_pending_orders`. This is the exact failure mode the
   Phase 1 layered-locking fix solved.
2. **Make `_tick_lock` re-entrant via an `asyncio.RLock`-equivalent counter.**
   Rejected — same trade-off as the layered-locking decision: adds a custom
   primitive when an explicit kwarg-pin is simpler.
3. **Always read `session.clock.get_time()` only once inside the lock and
   stuff it into a module-global.** Rejected — global mutable state across
   concurrent advance_time calls reintroduces the race in a different shape.
4. **Hard-fail (raise) by default in prod.** Rejected — agent-facing responses
   should not 500 on a drift detection that's a latent regression hint, not a
   correctness violation for the read-only call paths. CI sets `raise`; prod
   sets `log` (default).

## Related Bugs

- `dc4daf5a` — original Codex finding (this fix).
- `9a85b8bd`, `9a7d7f07` — co-shipped in the 2026-05-22 3-pack (different teams,
  different surfaces).
